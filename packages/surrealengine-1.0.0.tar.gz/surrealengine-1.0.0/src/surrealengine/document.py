"""Document classes for object-document mapping with SurrealDB.

This module provides the foundation for defining and working with documents
in SurrealDB using an Object-Document Mapper (ODM) pattern. It includes
the base Document class, RelationDocument for graph relationships, and
supporting metaclasses for field processing and schema generation.

Classes:
    DocumentMetaclass: Metaclass for processing field definitions
    Document: Base class for all database documents
    RelationDocument: Base class for graph relation documents
    HybridDocument: Document with backend-specific field handling
"""
import json
import datetime
import logging
from dataclasses import field as dataclass_field, make_dataclass
from typing import Any, Dict, List, Optional, Type, Union
from .query import QuerySet, RelationQuerySet, QuerySetDescriptor
from .fields import Field, RecordIDField, ReferenceField, DictField
from .connection import ConnectionRegistry
from .context import get_active_connection
from .exceptions import ValidationError
from surrealdb import RecordID
from .signals import (
    pre_init, post_init, pre_save, pre_save_post_validation, post_save,
    pre_delete, post_delete, pre_bulk_insert, post_bulk_insert, SIGNAL_SUPPORT
)
from .materialized_view import MaterializedView


# Set up logging
logger = logging.getLogger(__name__)


# Robust import for SDK datetime wrapper
try:
    from surrealdb.data.types.datetime import IsoDateTimeWrapper  # new path
except Exception:  # pragma: no cover
    try:
        from surrealdb.types import IsoDateTimeWrapper  # older path
    except Exception:
        IsoDateTimeWrapper = None

def _iso_from_wrapper(w) -> str:
    if w is None:
        return ""
    s = getattr(w, "dt", None)
    if isinstance(s, datetime.datetime):
        return s.isoformat()
    if isinstance(s, str):
        return s
    s2 = getattr(w, "iso", None)
    if isinstance(s2, str):
        return s2
    return str(w)

# Universal HTTP-safe serializer for outgoing payloads
def serialize_http_safe(value: Any):
    """Recursively process values for SurrealDB SDK.

    Convert IsoDateTimeWrapper back to raw datetime - the SDK handles that better.
    """
    import datetime as _dt

    try:
        from surrealdb.data.types.datetime import IsoDateTimeWrapper as _Iso
    except Exception:
        try:
            from surrealdb.types import IsoDateTimeWrapper as _Iso
        except Exception:
            _Iso = None
    
    # Pass through primitives and datetime unchanged
    if value is None or isinstance(value, (str, int, float, bool, _dt.datetime)):
        return value

    # Convert IsoDateTimeWrapper/Datetime back to datetime
    try:
        from surrealdb import Datetime
        if isinstance(value, Datetime):
            if hasattr(value, 'inner') and isinstance(value.inner, _dt.datetime):
                return value.inner
            if hasattr(value, 'dt') and isinstance(value.dt, _dt.datetime):
                return value.dt
            return value 
    except ImportError:
        pass

    if _Iso and isinstance(value, _Iso):
        dt_val = getattr(value, 'dt', None)
        if isinstance(dt_val, _dt.datetime):
            return dt_val
        iso_val = getattr(value, 'iso', None)
        if isinstance(iso_val, str):
            try:
                return _dt.datetime.fromisoformat(iso_val.replace('Z', '+00:00'))
            except Exception:
                pass
        return value

    # Recursively handle collections
    if isinstance(value, list):
        return [serialize_http_safe(v) for v in value]
    if isinstance(value, dict):
        return {k: serialize_http_safe(v) for k, v in value.items()}

    # Stringify RecordID for HTTP
    try:
        from surrealdb import RecordID
        if isinstance(value, RecordID):
            return str(value)
    except ImportError:
        pass

    # Pass through everything else unchanged
    return value


def serialize_db_safe(value: Any) -> Any:
    """Recursively convert objects to representations safe for the SurrealDB driver (preserving RecordID/datetime)."""
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    try:
        from surrealdb import Datetime, RecordID
        if isinstance(value, (Datetime, RecordID)):
            return value
    except ImportError:
        pass
    if IsoDateTimeWrapper and isinstance(value, IsoDateTimeWrapper):
        dt_val = getattr(value, 'dt', None)
        if isinstance(dt_val, datetime.datetime):
            return dt_val
        iso_val = getattr(value, 'iso', None)
        if isinstance(iso_val, str):
            try:
                return datetime.datetime.fromisoformat(iso_val.replace('Z', '+00:00'))
            except Exception:
                pass
    if isinstance(value, datetime.datetime):
        return value
    if isinstance(value, list):
        return [serialize_db_safe(v) for v in value]
    if isinstance(value, dict):
        return {k: serialize_db_safe(v) for k, v in value.items()}
    return value



def _serialize_for_surreal(value: Any) -> str:
    """Serialize Python values to SurrealDB-friendly literal strings."""
    # Datetime wrappers and datetime objects
    try:
        from surrealdb import Datetime
        if isinstance(value, Datetime):
            dt = None
            if hasattr(value, 'inner') and isinstance(value.inner, datetime.datetime):
                dt = value.inner
            elif hasattr(value, 'dt') and isinstance(value.dt, datetime.datetime):
                dt = value.dt
            
            if dt:
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=datetime.timezone.utc)
                iso = dt.isoformat().replace("+00:00", "Z")
                return f"d'{iso}'"
            return str(value)
    except ImportError:
        pass

    if IsoDateTimeWrapper is not None and isinstance(value, IsoDateTimeWrapper):
        iso = _iso_from_wrapper(value).replace("+00:00", "Z")
        return f"d'{iso}'"
    if isinstance(value, datetime.datetime):
        dt = value if value.tzinfo is not None else value.replace(tzinfo=datetime.timezone.utc)
        iso = dt.isoformat().replace("+00:00", "Z")
        return f"d'{iso}'"

    if isinstance(value, RecordID):
        return str(value)

    if hasattr(value, 'id') and hasattr(value, '_get_collection_name'):
        if isinstance(value.id, RecordID):
            return str(value.id)
        doc_id = str(value.id)
        if ':' in doc_id:
            return doc_id
        return f"{value._get_collection_name()}:{doc_id}"

    # Already a Surreal datetime literal
    if isinstance(value, str):
        if value.startswith("d'") and value.endswith("'"):
            return value
        return json.dumps(value)

    if value is None:
        return "none"

    if isinstance(value, list):
        return '[' + ', '.join(_serialize_for_surreal(v) for v in value) + ']'
    if isinstance(value, tuple):
        return '[' + ', '.join(_serialize_for_surreal(v) for v in value) + ']'
    if isinstance(value, dict):
        items = []
        for k, v in value.items():
            items.append(json.dumps(str(k)) + ": " + _serialize_for_surreal(v))
        return '{' + ', '.join(items) + '}'

    try:
        return json.dumps(value)
    except TypeError:
        return json.dumps(str(value))


class DocumentMetaclass(type):
    """Metaclass for Document classes.

    This metaclass processes field attributes in Document classes to create
    a structured schema. It handles field inheritance, field naming, and
    metadata configuration.

    Attributes:
        _meta: Dictionary of metadata for the document class
        _fields: Dictionary of fields for the document class
        _fields_ordered: List of field names in order of definition
        _registry: Dictionary mapping collection names to Document classes

    """

    _registry: Dict[str, Type] = {}

    def __new__(mcs, name: str, bases: tuple, attrs: Dict[str, Any]) -> Type:
        """Create a new Document class.

        This method processes the class attributes to create a structured schema.
        It handles field inheritance, field naming, and metadata configuration.

        Args:
            name: Name of the class being created
            bases: Tuple of base classes
            attrs: Dictionary of class attributes

        Returns:
            The new Document class

        """
        # Skip processing for the base Document class
        if name == 'Document' and attrs.get('__module__') == __name__:
            return super().__new__(mcs, name, bases, attrs)

        # Get or create _meta
        meta = attrs.get('Meta', type('Meta', (), {}))
        attrs['_meta'] = {
            'collection': getattr(meta, 'collection', name.lower()),
            'indexes': getattr(meta, 'indexes', []),
            'id_field': getattr(meta, 'id_field', 'id'),
            'strict': getattr(meta, 'strict', True),
            'time_series': getattr(meta, 'time_series', False),
            'time_field': getattr(meta, 'time_field', None),
            'abstract': getattr(meta, 'abstract', False),
            'events': getattr(meta, 'events', []),
            # DEFINE SEQUENCE support
            'sequence': getattr(meta, 'sequence', None),
            'sequence_start': getattr(meta, 'sequence_start', 1),
            'sequence_batch': getattr(meta, 'sequence_batch', 1),
        }

        # Process fields
        fields: Dict[str, Field] = {}
        fields_ordered: List[str] = []

        # Inherit fields from parent classes
        for base in bases:
            if hasattr(base, '_fields'):
                fields.update(base._fields)
                fields_ordered.extend(base._fields_ordered)

        # Add fields from current class
        for attr_name, attr_value in list(attrs.items()):
            if isinstance(attr_value, Field):
                fields[attr_name] = attr_value
                fields_ordered.append(attr_name)

                # Set field name
                attr_value.name = attr_name

                # Set db_field if not set
                if not attr_value.db_field:
                    attr_value.db_field = attr_name

                # We keep the field in attrs so it can function as a descriptor
                # del attrs[attr_name]

        attrs['_fields'] = fields
        attrs['_fields_ordered'] = fields_ordered

        # Create the new class
        new_class = super().__new__(mcs, name, bases, attrs)

        # Assign owner document to fields
        for field_name, field in new_class._fields.items():
            field.owner_document = new_class

        # Register signal receivers defined in the class
        if attrs.get('__module__') != __name__:  # Skip for Document class itself
            for attr_name, attr_value in attrs.items():
                if callable(attr_value) and hasattr(attr_value, '_signal_receiver'):
                    signal, sig_kwargs = attr_value._signal_receiver
                    
                    # Create a wrapper that delegates to the instance method
                    # We capture attr_name because attr_value might be unbound or decorated further
                    def make_handler(method_name):
                        def signal_handler(sender, document=None, field=None, **kwargs):
                            # Handle document signals
                            if document is not None:
                                method = getattr(document, method_name)
                                return method(**kwargs)
                            # Handle field signals (if ever used on document methods)
                            # If field signal, 'field' arg is passed. But method is on Document?
                            # Use case unclear, skipping implementation for field signals on doc methods for now.
                            return None
                        return signal_handler

                    handler = make_handler(attr_name)
                    # Connect with weak=False to ensure the handler persists (since it's a closure)
                    signal.connect(handler, sender=new_class, weak=False)

        # Register the class in the global registry
        collection = new_class._meta.get('collection')
        if collection:
            DocumentMetaclass._registry[collection] = new_class

        return new_class



class CallableRelationship:
    """Proxy that behaves like a QuerySet but can be called to refine the relation target.
    
    returned by: document.rel.edge_name
    usage:
      - await document.rel.edge_name              (wildcard ->edge->?)
      - await document.rel.edge_name(User)        (specific ->edge->user)
    """

    def __init__(self, queryset, edge_name: str):
        self._qs = queryset
        self._edge_name = edge_name
        # Default behavior: ->edge->?
        self._default_qs = queryset.out(edge_name)

    def __call__(self, target: Any = None):
        if target is None:
            return self._default_qs
            
        # Refine target using standard QuerySet graph traversal logic
        # This will automatically find the trailing `->?` and substitute
        # the model's collection name, whilst applying our Base_table fix.
        return self._default_qs.out(target)

    def __getattr__(self, name):
        return getattr(self._default_qs, name)
        
    def __iter__(self):
        return iter(self._default_qs)
        
    def __await__(self):
        return self._default_qs.__await__()
        
    def __repr__(self):
        return repr(self._default_qs)


class RelationshipAccessor:
    """Helper for magic relation access via .rel property.
    
    Allows syntax like: 
    - document.rel.knows.all()
    - document.rel.knows(User).all()
    """

    def __init__(self, document):
        self._document = document

    def __getattr__(self, name: str):
        """Dynamic access to relations.
        
        Args:
            name: The name of the relation/edge to traverse.
            
        Returns:
            A CallableRelationship proxy that defaults to wildcard traversal but can be called with a target.

        """
        # Get a fresh QuerySet for the document's class
        qs = self._document.__class__.objects
        
        # Filter to this specific document
        qs = qs.filter(id=self._document.id)
        
        # Return the callable proxy
        return CallableRelationship(qs, name)


class Document(metaclass=DocumentMetaclass):
    """Base class for all documents.
    
    This class provides the foundation for all document models in the ORM.
    It includes methods for CRUD operations, validation, and serialization.

    Attributes:
        objects: QuerySetDescriptor for querying documents of this class
        _data: Dictionary of field values
        _changed_fields: List of field names that have been changed
        _fields: Dictionary of fields for this document class (class attribute)
        _fields_ordered: List of field names in order of definition (class attribute)
        _meta: Dictionary of metadata for this document class (class attribute)

    Meta Options:
        The Meta inner class can be used to configure various document options:

        - **collection** (str): Name of the database collection/table. Defaults to lowercase class name.
        - **indexes** (List[Dict]): List of index definitions. Each index dict can contain:
          - keys (List[str]): Field names to include in the index
          - unique (bool): Whether the index enforces uniqueness (default: False)
          - name (str): Custom name for the index
          - type (str): Index type (e.g., "search" for full-text search)
        - **id_field** (str): Name of the ID field. Defaults to "id".
        - **strict** (bool): Whether to enforce strict field validation. Defaults to True.
          When False, allows dynamic fields not defined in the schema.
        - **time_series** (bool): Whether this is a time series table. Defaults to False.
        - **time_field** (str): Field to use for time series timestamp. Required when time_series is True.
        - **abstract** (bool): Whether this document is abstract. Abstract documents are not registered
          with the database and are meant to be inherited.

    Example::

        class User(Document):
            name = StringField(required=True)
            email = StringField(indexed=True, unique=True)
            
            class Meta:
                collection = "users"
                indexes = [
                    {"fields": ["email"], "unique": True},
                    {"fields": ["name", "created_at"]}
                ]

    """

    objects = QuerySetDescriptor()
    id = RecordIDField()

    @property
    def rel(self) -> 'RelationshipAccessor':
        """Magic relation accessor.
        
        Provides fluent access to graph relations.
        Example: user.rel.knows.out(Person)
        """
        return RelationshipAccessor(self)

    def __init__(self, **values: Any) -> None:
        """Initialize a new Document.

        Args:
            **values: Field values to set on the document

        Raises:
            AttributeError: If strict mode is enabled and an unknown field is provided

        """
        if 'id' not in self._fields:
            id_field = RecordIDField()
            id_field.name = 'id'
            id_field.db_field = 'id'
            id_field.owner_document = self.__class__
            self._fields['id'] = id_field

        # Trigger pre_init signal
        if SIGNAL_SUPPORT:
            pre_init.send(self.__class__, document=self, values=values)

        self._data: Dict[str, Any] = {}
        self._changed_fields: List[str] = []
        self._original_data: Dict[str, Any] = {}  # Track original values for change detection

        # Set default values
        for field_name, field in self._fields.items():
            value = field.default
            if callable(value):
                value = value()
            self._data[field_name] = value

            # Register parent for tracked objects
            if hasattr(value, '_set_parent') and callable(value._set_parent):
                value._set_parent(self, field_name)

        # Set values from kwargs
        for key, value in values.items():
            if key in self._fields:
                setattr(self, key, value)
            elif self._meta.get('strict', True):
                raise AttributeError(f"Unknown field: {key}")

        # For new documents, mark as clean after initialization
        # since initial value setting shouldn't count as "changes"
        if not self.id:  # New document
            self.mark_clean()

        # Trigger post_init signal
        if SIGNAL_SUPPORT:
            post_init.send(self.__class__, document=self)

    def __getattr__(self, name: str) -> Any:
        """Get a field value.

        This method is called when an attribute is not found through normal lookup.
        It checks if the attribute is a field and returns its value if it is.

        Args:
            name: Name of the attribute to get

        Returns:
            The field value

        Raises:
            AttributeError: If the attribute is not a field

        """
        # Guard against recursion during deepcopy / pickling when _data or _fields
        # haven't been set yet. __getattr__ is only called when normal attribute
        # lookup fails, so if _data itself is missing we must not access self._data.
        if '_data' not in self.__dict__ or '_fields' not in self.__class__.__dict__ and '_fields' not in self.__dict__:
            raise AttributeError(f"'{self.__class__.__name__}' object has no attribute '{name}'")

        if name in self._fields:
            # Return the value directly from _data instead of the field instance
            _val = self._data.get(name)
            if name == 'id' and _val is None:
                from .exceptions import DocumentNotSavedError
                raise DocumentNotSavedError(
                    f"{self.__class__.__name__} has no ID yet — call save() first."
                )
            return _val

        
        # Also check _data for dynamic fields (e.g. from aggregations)
        if name in self._data:
            return self._data[name]
            
        raise AttributeError(f"'{self.__class__.__name__}' object has no attribute '{name}'")

    def __contains__(self, key: str) -> bool:
        """Check if a field exists."""
        return key in self._fields or key in self._data

    def __getitem__(self, key: str) -> Any:
        """Get a field value using dictionary syntax."""
        try:
            if key in self._fields:
                return self._data.get(key)
            return self._data[key]
        except KeyError:
            raise KeyError(f"'{self.__class__.__name__}' object has no field '{key}'")

    def __setitem__(self, key: str, value: Any) -> None:
        """Set a field value using dictionary syntax."""
        if key in self._fields:
            setattr(self, key, value)
        else:
            self._data[key] = value

    def __setattr__(self, name: str, value: Any) -> None:
        """Set a field value.

        This method is called when an attribute is set. It checks if the attribute
        is a field and validates the value if it is.

        Args:
            name: Name of the attribute to set
            value: Value to set

        """
        if name.startswith('_'):
            super().__setattr__(name, value)
        elif name in self._fields:
            field = self._fields[name]
            # Store original value before changing (if not already tracked)
            if name not in self._changed_fields and hasattr(self, '_original_data'):
                self._original_data[name] = self._data.get(name)
            
            validated_value = field.validate(value)
            self._data[name] = validated_value
            
            # Register parent for tracked objects
            if hasattr(validated_value, '_set_parent') and callable(validated_value._set_parent):
                validated_value._set_parent(self, name)
                
            if name not in self._changed_fields:
                self._changed_fields.append(name)
        else:
            super().__setattr__(name, value)



    @classmethod
    def _get_collection_name(cls) -> str:
        """Return the collection name for this document.

        Returns:
            The collection name

        """
        return cls._meta.get('collection')

    # ================================
    # ENHANCED CHANGE TRACKING METHODS
    # ================================
    
    def has_changed(self, field: str = None) -> bool:
        """Check if the document or a specific field has changed.
        
        Args:
            field: Optional field name to check. If None, checks if any field changed.
            
        Returns:
            True if the document/field has changed, False otherwise
            
        Examples:
            >>> user = User(name="John", age=30)
            >>> await user.save()
            >>> user.age = 31
            >>> user.has_changed()  # True
            >>> user.has_changed('age')  # True 
            >>> user.has_changed('name')  # False

        """
        if field:
            return field in self._changed_fields
        return len(self._changed_fields) > 0
    
    def get_changes(self) -> Dict[str, Any]:
        """Get a dictionary of all changed fields and their new values.
        
        Returns:
            Dictionary mapping field names to their new values
            
        Examples:
            >>> user.age = 31
            >>> user.name = "Jane"
            >>> user.get_changes()  # {'age': 31, 'name': 'Jane'}

        """
        return {field: self._data.get(field) for field in self._changed_fields}
    
    def get_original_value(self, field: str) -> Any:
        """Get the original value of a field before any changes.
        
        Args:
            field: Name of the field
            
        Returns:
            The original value of the field
            
        Examples:
            >>> user.age = 31  # was 30
            >>> user.get_original_value('age')  # 30

        """
        return self._original_data.get(field)
    
    def revert_changes(self, fields: List[str] = None) -> None:
        """Revert changes to original values.
        
        Args:
            fields: Optional list of field names to revert. If None, reverts all changes.
            
        Examples:
            >>> user.age = 31
            >>> user.name = "Jane" 
            >>> user.revert_changes(['age'])  # Only revert age
            >>> user.revert_changes()  # Revert all changes

        """
        if fields:
            # Revert specific fields
            for field in fields:
                if field in self._changed_fields and field in self._original_data:
                    self._data[field] = self._original_data[field]
                    self._changed_fields.remove(field)
        else:
            # Revert all changes
            for field in list(self._changed_fields):
                if field in self._original_data:
                    self._data[field] = self._original_data[field]
            self._changed_fields.clear()
    
    @property
    def is_dirty(self) -> bool:
        """Check if the document has unsaved changes.
        
        Returns:
            True if there are unsaved changes, False otherwise
            
        Examples:
            >>> user.is_dirty  # False
            >>> user.age = 31
            >>> user.is_dirty  # True
            >>> await user.save()
            >>> user.is_dirty  # False

        """
        return len(self._changed_fields) > 0
    
    @property
    def is_clean(self) -> bool:
        """Check if the document has no unsaved changes.
        
        Returns:
            True if there are no unsaved changes, False otherwise

        """
        return len(self._changed_fields) == 0
    
    @property
    def dirty_fields(self) -> List[str]:
        """Get list of field names that have been changed.
        
        Returns:
            List of field names with unsaved changes
            
        Examples:
            >>> user.age = 31
            >>> user.name = "Jane"
            >>> user.dirty_fields  # ['age', 'name']

        """
        return self._changed_fields.copy()
    
    def mark_clean(self) -> None:
        """Mark the document as clean (no pending changes).
        
        This updates the original data to match current data and clears changed fields.
        Usually called automatically after successful save operations.
        """
        self._changed_fields.clear()
        if hasattr(self, '_original_data'):
            self._original_data = self._data.copy()

    def _mark_field_changed(self, field_name: str) -> None:
        """Mark a field as changed.
        
        This is called by tracked nested objects (EmbeddedDocument, TrackedList, TrackedDict)
        when they are modified in place.
        """
        if field_name not in self._fields:
            return
            
        # Store original value if not already tracked
        if field_name not in self._changed_fields and hasattr(self, '_original_data'):
            # For mutable objects, we might be storing a reference to the now-changed object.
            # Ideally we'd have a deep copy from before, but 'original_data' usually captures
            # state at load time. If we modify in place, 'original_data' might also reflect change
            # if it's a shared reference. 
            # For now, just ensuring it's in _changed_fields is the priority.
            if field_name not in self._original_data:
                 self._original_data[field_name] = self._data.get(field_name)

        if field_name not in self._changed_fields:
            self._changed_fields.append(field_name)
    
    def get_changed_data_for_update(self) -> Dict[str, Any]:
        """Get only the changed fields formatted for database update.
        
        Returns:
            Dictionary of changed fields in database format
            
        This is used internally for optimized updates that only send changed fields.

        """
        if not self._changed_fields:
            return {}
        
        # Get changed data and convert to DB format
        changed_data = {}
        for field_name in self._changed_fields:
            # Note: We don't skip the 'id' field here anymore because:
            # 1. SurrealDB handles it properly in upsert operations
            # 2. The ID might be stored as a string and needed for queries
            # 3. Skipping it can break RecordID-based queries
            if field_name in self._fields:
                field = self._fields[field_name]
                value = self._data.get(field_name)
                changed_data[field.db_field or field_name] = field.to_db(value)
            else:
                changed_data[field_name] = self._data.get(field_name)
        
        return changed_data

    def validate(self) -> None:
        """Validate all fields.

        This method validates all fields in the document against their
        validation rules.

        Raises:
            ValidationError: If a field fails validation

        """
        for field_name, field in self._fields.items():
            value = self._data.get(field_name)
            field.validate(value)

    def to_dict(self) -> Dict[str, Any]:
        """Convert the document to a dictionary.

        This method converts the document to a dictionary containing all
        field values including the document ID. It ensures that RecordID
        objects are properly converted to strings for JSON serialization.
        It also recursively converts embedded documents to dictionaries.

        Returns:
            Dictionary of field values including ID

        """
        result = {}
        for k, v in self._data.items():
            # Convert RecordID objects to strings
            if isinstance(v, RecordID):
                result[k] = str(v)
            # Handle embedded documents by recursively calling to_dict()
            elif hasattr(v, 'to_dict') and callable(v.to_dict):
                result[k] = v.to_dict()
            # Handle lists that might contain RecordIDs or embedded documents
            elif isinstance(v, list):
                result[k] = [
                    item.to_dict() if hasattr(item, 'to_dict') and callable(item.to_dict)
                    else str(item) if isinstance(item, RecordID)
                    else item
                    for item in v
                ]
            # Handle dicts that might contain RecordIDs or embedded documents
            elif isinstance(v, dict):
                result[k] = {
                    key: val.to_dict() if hasattr(val, 'to_dict') and callable(val.to_dict)
                    else str(val) if isinstance(val, RecordID)
                    else val
                    for key, val in v.items()
                }
            else:
                result[k] = v
        return result

    def to_db(self) -> Dict[str, Any]:
        """Convert the document to a database-friendly dictionary.

        This method converts the document to a dictionary suitable for
        storage in the database. It applies field-specific conversions
        and includes only non-None values unless the field is required.

        Returns:
            Dictionary of field values for the database

        """
        result = {}
        for field_name, field in self._fields.items():
            value = self._data.get(field_name)
            # Only include the field if:
            # 1. The value is not None, OR
            # 2. The field is required (in which case we send None to let DB validate)
            # But skip 'id' field if it's None (it will be auto-generated)
            if field_name == 'id' and value is None:
                continue
            if value is not None:
                db_field = field.db_field or field_name
                result[db_field] = field.to_db(value)
            elif field.required:
                db_field = field.db_field or field_name
                result[db_field] = field.to_db(value)
        return result

    @classmethod
    def from_db(cls, data: Any, dereference: bool = False, partial: bool = False) -> 'Document':
        """Create a document instance from database data.

        Args:
            data: Data from the database (dictionary, string, RecordID, etc.)
            dereference: Whether to dereference references (default: False)
            partial: Whether the data is a partial document (default: False)

        Returns:
            A new document instance with change tracking initialized (clean state).
            Nested tracked objects (Lists, Dicts, EmbeddedDocuments) are automatically linked.

        """
        # Create an empty instance without triggering signals
        instance = cls.__new__(cls)

        # Initialize _data, _changed_fields, and _original_data
        instance._data = {}
        instance._changed_fields = []
        instance._original_data = {}

        # Add id field if not present
        if 'id' not in instance._fields:
            instance._fields['id'] = RecordIDField()

        # If not partial, set default values
        if not partial:
            for field_name, field in instance._fields.items():
                value = field.default
                if callable(value):
                    value = value()
                instance._data[field_name] = value

        # If data is a dictionary, update with database values
        if isinstance(data, dict):
            # First, handle fields with db_field mapping
            for field_name, field in instance._fields.items():
                db_field = field.db_field or field_name
                if db_field in data:
                    # Pass the dereference parameter to from_db if the field supports it
                    if hasattr(field, 'from_db') and 'dereference' in field.from_db.__code__.co_varnames:
                        instance._data[field_name] = field.from_db(data[db_field], dereference=dereference)
                    else:
                        instance._data[field_name] = field.from_db(data[db_field])

            # Then, handle fields without db_field mapping (for backward compatibility)
            # and extra fields if strict mode is disabled
            for key, value in data.items():
                if key in instance._fields:
                    field = instance._fields[key]
                    # Pass the dereference parameter to from_db if the field supports it
                    if hasattr(field, 'from_db') and 'dereference' in field.from_db.__code__.co_varnames:
                        instance._data[key] = field.from_db(value, dereference=dereference)
                    else:
                        instance._data[key] = field.from_db(value)
                elif not instance._meta.get('strict', True):
                    # In non-strict mode, store unknown fields directly
                    instance._data[key] = value
        # If data is a RecordID or string, set it as the ID
        elif isinstance(data, (RecordID, str)):
            instance._data['id'] = data
        # For other types, try to convert to string and set as ID
        else:
            try:
                instance._data['id'] = str(data)
            except (TypeError, ValueError):
                # If conversion fails, just use the data as is
                pass
        
        # Register parent for tracked objects in _data
        for key, value in instance._data.items():
             if hasattr(value, '_set_parent') and callable(value._set_parent):
                value._set_parent(instance, key)

        # Initialize original data for change tracking
        from copy import deepcopy
        instance._original_data = deepcopy(instance._data)
        
        return instance

    def resolve_references(self, depth: int = 1) -> Union['Document', Any]:
        """Resolve all references in this document using FETCH.
        
        Polyglot method: executes synchronously if the connection is synchronous,
        otherwise returns an awaitable.

        Args:
            depth: Maximum depth of reference resolution (default: 1)

        Returns:
            The document instance with resolved references (or awaitable resolving to it)

        """
        # Get active connection to determine mode
        connection = get_active_connection()
        if not connection.is_async():
            return self.resolve_references_sync(depth=depth)

        return self._resolve_references_async(depth=depth)

    async def _resolve_references_async(self, depth: int = 1) -> 'Document':
        """Internal async implementation of resolve_references()."""
        if depth <= 0 or not self.id:
            return self

        # Detect IncomingReferenceField fields
        try:
            from .fields.reference import IncomingReferenceField as _IRF
        except ImportError:
            _IRF = None

        # Build FETCH clause for all reference fields
        fetch_fields = []
        for field_name, field in self._fields.items():
            if isinstance(field, ReferenceField) and getattr(self, field_name):
                fetch_fields.append(field_name)
            elif _IRF and isinstance(field, _IRF):
                fetch_fields.append(field_name)
        
        if not fetch_fields:
            return self

        # Use FETCH to resolve references in a single query
        connection = get_active_connection(async_mode=True)
        
        try:
            # Use FETCH with a WHERE clause instead of selecting from specific record
            fetch_query = f"SELECT * FROM {self.__class__._get_collection_name()} WHERE id = {self.id} FETCH {', '.join(fetch_fields)}"
            result = await connection.client.query(fetch_query)
            if result and result[0]:
                # Update this document with fetched data
                fetched_data = result[0][0]
                updated_doc = self.from_db(fetched_data)
                
                # Copy the resolved references to this instance
                for field_name in fetch_fields:
                    if hasattr(updated_doc, field_name):
                        setattr(self, field_name, getattr(updated_doc, field_name))
                
                # If depth > 1, recursively resolve references in fetched documents
                if depth > 1:
                    for field_name in fetch_fields:
                        referenced_doc = getattr(self, field_name, None)
                        if referenced_doc:
                            if isinstance(referenced_doc, list):
                                for item in referenced_doc:
                                    if hasattr(item, 'resolve_references'):
                                        await item.resolve_references(depth=depth-1)
                            elif hasattr(referenced_doc, 'resolve_references'):
                                await referenced_doc.resolve_references(depth=depth-1)
        except Exception:
            # Fall back to manual resolution if FETCH fails
            for field_name, field in self._fields.items():
                if isinstance(field, ReferenceField) and getattr(self, field_name):
                    ref_id = getattr(self, field_name)
                    if isinstance(ref_id, str) and ':' in ref_id:
                        referenced_doc = await field.document_type.get(id=ref_id, dereference=True)
                        if referenced_doc and depth > 1:
                            await referenced_doc.resolve_references(depth=depth-1)
                        setattr(self, field_name, referenced_doc)
                    elif isinstance(ref_id, RecordID):
                        ref_id_str = str(ref_id)
                        referenced_doc = await field.document_type.get(id=ref_id_str, dereference=True)
                        if referenced_doc and depth > 1:
                            await referenced_doc.resolve_references(depth=depth-1)
                        setattr(self, field_name, referenced_doc)
                elif _IRF and isinstance(field, _IRF):
                    # Manual resolution for incoming references if FETCH fails
                    # This is handled naturally by the field's __get__ if we didn't FETCH
                    pass

        return self

    def resolve_references_sync(self, depth: int = 1) -> 'Document':
        """Resolve all references in this document synchronously using FETCH.

        This method uses SurrealDB's FETCH clause to efficiently resolve references
        instead of making individual queries for each reference.

        Args:
            depth: Maximum depth of reference resolution (default: 1)

        Returns:
            The document instance with resolved references

        """
        if depth <= 0 or not self.id:
            return self

        # Detect IncomingReferenceField fields
        try:
            from .fields.reference import IncomingReferenceField as _IRF
        except ImportError:
            _IRF = None

        # Build FETCH clause for all reference fields
        fetch_fields = []
        for field_name, field in self._fields.items():
            if isinstance(field, ReferenceField) and getattr(self, field_name):
                fetch_fields.append(field_name)
            elif _IRF and isinstance(field, _IRF):
                fetch_fields.append(field_name)
        
        if not fetch_fields:
            return self

        # Use FETCH to resolve references in a single query
        connection = ConnectionRegistry.get_default_connection(async_mode=False)
        
        try:
            # Use FETCH with a WHERE clause instead of selecting from specific record
            fetch_query = f"SELECT * FROM {self.__class__._get_collection_name()} WHERE id = {self.id} FETCH {', '.join(fetch_fields)}"
            result = connection.client.query(fetch_query)
            if result and result[0]:
                # Update this document with fetched data
                fetched_data = result[0][0]
                updated_doc = self.from_db(fetched_data)
                
                # Copy the resolved references to this instance
                for field_name in fetch_fields:
                    if hasattr(updated_doc, field_name):
                        setattr(self, field_name, getattr(updated_doc, field_name))
                
                # If depth > 1, recursively resolve references in fetched documents
                if depth > 1:
                    for field_name in fetch_fields:
                        referenced_doc = getattr(self, field_name, None)
                        if referenced_doc:
                            if isinstance(referenced_doc, list):
                                for item in referenced_doc:
                                    if hasattr(item, 'resolve_references_sync'):
                                        item.resolve_references_sync(depth=depth-1)
                            elif hasattr(referenced_doc, 'resolve_references_sync'):
                                referenced_doc.resolve_references_sync(depth=depth-1)
        except Exception:
            # Fall back to manual resolution if FETCH fails
            for field_name, field in self._fields.items():
                if isinstance(field, ReferenceField) and getattr(self, field_name):
                    ref_id = getattr(self, field_name)
                    if isinstance(ref_id, str) and ':' in ref_id:
                        referenced_doc = field.document_type.get_sync(id=ref_id, dereference=True)
                        if referenced_doc and depth > 1:
                            referenced_doc.resolve_references_sync(depth=depth-1)
                        setattr(self, field_name, referenced_doc)
                    elif isinstance(ref_id, RecordID):
                        ref_id_str = str(ref_id)
                        referenced_doc = field.document_type.get_sync(id=ref_id_str, dereference=True)
                        if referenced_doc and depth > 1:
                            referenced_doc.resolve_references_sync(depth=depth-1)
                        setattr(self, field_name, referenced_doc)
                elif _IRF and isinstance(field, _IRF):
                    # Manual resolution for incoming references if FETCH fails
                    pass

        return self

    @classmethod
    def get(cls, id: Any, dereference: bool = False, dereference_depth: int = 1, **kwargs: Any) -> Union['Document', Any]:
        """Get a document by ID with optional dereferencing using FETCH.
        
        Polyglot method: executes synchronously if the connection is synchronous,
        otherwise returns an awaitable.

        Args:
            id: The ID of the document to retrieve
            dereference: Whether to resolve references (default: False)
            dereference_depth: Maximum depth of reference resolution (default: 1)
            **kwargs: Additional arguments to pass to the get method

        Returns:
            The document instance (or awaitable resolving to it)

        """
        # Get active connection logic is handled by objects.get for simple cases,
        # but here we need to know if we should call get_sync or _get_async
        # We can check which connection QuerySet would use.
        connection = get_active_connection()
        if not connection.is_async():
            return cls.get_sync(id=id, dereference=dereference, dereference_depth=dereference_depth, **kwargs)

        return cls._get_async(id=id, dereference=dereference, dereference_depth=dereference_depth, **kwargs)

    @classmethod
    async def _get_async(cls, id: Any, dereference: bool = False, dereference_depth: int = 1, **kwargs: Any) -> 'Document':
        """Internal async implementation of get()."""
        if not dereference:
            # No dereferencing needed, use regular get
            return await cls.objects.get(id=id, **kwargs)
        
        # Detect IncomingReferenceField fields
        try:
            from .fields.reference import IncomingReferenceField as _IRF
        except ImportError:
            _IRF = None

        # Build FETCH clause for reference fields
        fetch_fields = []
        for field_name, field in cls._fields.items():
            if isinstance(field, ReferenceField):
                fetch_fields.append(field_name)
            elif _IRF and isinstance(field, _IRF):
                fetch_fields.append(field_name)
        
        if fetch_fields:
            # Use FETCH to resolve references in the initial query
            connection = ConnectionRegistry.get_default_connection(async_mode=True)
            
            # Handle ID format - both strings and RecordID objects
            if (isinstance(id, str) and ':' in id) or isinstance(id, RecordID):
                record_id = str(id)  # Convert RecordID to string
            else:
                record_id = f"{cls._get_collection_name()}:{id}"
            
            try:
                # Use FETCH on the entire collection, then filter
                fetch_query = f"SELECT * FROM {cls._get_collection_name()} FETCH {', '.join(fetch_fields)}"
                result = await connection.client.query(fetch_query)
                if not result or not result[0]:
                    from .exceptions import DoesNotExist
                    raise DoesNotExist(f"Object with ID '{id}' does not exist.")
                
                # Handle both single document and list of documents
                documents = result[0]
                target_doc = None
                
                # If documents is a single dict, wrap it in a list
                if isinstance(documents, dict):
                    documents = [documents]
                
                # Find the document with the matching ID
                for doc_data in documents:
                    if isinstance(doc_data, dict) and str(doc_data.get('id')) == record_id:
                        target_doc = doc_data
                        break
                
                if not target_doc:
                    from .exceptions import DoesNotExist
                    raise DoesNotExist(f"Object with ID '{id}' does not exist.")
                
                document = cls.from_db(target_doc)
                
                # If dereference_depth > 1, recursively resolve deeper references
                if dereference_depth > 1:
                    await document.resolve_references(depth=dereference_depth)
                
                return document
            except Exception as e:
                # Fall back to regular get with manual dereferencing
                logger.error(f"Error getting document {id}: {e}")
                raise
        
        # Fallback to original method
        document = await cls.objects.get(id=id, **kwargs)
        if dereference and dereference_depth > 1 and document:
            await document.resolve_references(depth=dereference_depth)
        return document

    @classmethod
    def get_sync(cls, id: Any, dereference: bool = False, dereference_depth: int = 1, **kwargs: Any) -> 'Document':
        """Get a document by ID with optional dereferencing synchronously using FETCH.

        This method retrieves a document by ID and optionally resolves references
        using SurrealDB's FETCH clause for efficient reference resolution.

        Args:
            id: The ID of the document to retrieve
            dereference: Whether to resolve references (default: False)
            dereference_depth: Maximum depth of reference resolution (default: 1)
            **kwargs: Additional arguments to pass to the get method

        Returns:
            The document instance with optionally resolved references

        """
        if not dereference:
            # No dereferencing needed, use regular get
            return cls.objects.get_sync(id=id, **kwargs)
        
        # Detect IncomingReferenceField fields
        try:
            from .fields.reference import IncomingReferenceField as _IRF
        except ImportError:
            _IRF = None

        # Build FETCH clause for reference fields
        fetch_fields = []
        for field_name, field in cls._fields.items():
            if isinstance(field, ReferenceField):
                fetch_fields.append(field_name)
            elif _IRF and isinstance(field, _IRF):
                fetch_fields.append(field_name)
        
        if fetch_fields:
            # Use FETCH to resolve references in the initial query
            connection = ConnectionRegistry.get_default_connection(async_mode=False)
            
            # Handle ID format - both strings and RecordID objects
            if (isinstance(id, str) and ':' in id) or isinstance(id, RecordID):
                record_id = str(id)  # Convert RecordID to string
            else:
                record_id = f"{cls._get_collection_name()}:{id}"
            
            try:
                # Use FETCH on the entire collection, then filter
                fetch_query = f"SELECT * FROM {cls._get_collection_name()} FETCH {', '.join(fetch_fields)}"
                result = connection.client.query(fetch_query)
                if not result or not result[0]:
                    from .exceptions import DoesNotExist
                    raise DoesNotExist(f"Object with ID '{id}' does not exist.")
                
                # Handle both single document and list of documents
                documents = result[0]
                target_doc = None
                
                # If documents is a single dict, wrap it in a list
                if isinstance(documents, dict):
                    documents = [documents]
                
                # Find the document with the matching ID
                for doc_data in documents:
                    if isinstance(doc_data, dict) and str(doc_data.get('id')) == record_id:
                        target_doc = doc_data
                        break
                
                if not target_doc:
                    from .exceptions import DoesNotExist
                    raise DoesNotExist(f"Object with ID '{id}' does not exist.")
                
                document = cls.from_db(target_doc)
                
                # If dereference_depth > 1, recursively resolve deeper references
                if dereference_depth > 1:
                    document.resolve_references_sync(depth=dereference_depth)
                
                return document
            except Exception:
                # Fall back to regular get with manual dereferencing
                pass
        
        # Fallback to original method
        document = cls.objects.get_sync(id=id, **kwargs)
        if dereference and dereference_depth > 1 and document:
            document.resolve_references_sync(depth=dereference_depth)
        return document

    def update(self, connection: Optional[Any] = None, **kwargs) -> Union['Document', Any]:
        """Update the document with new data.
        
        Polyglot method: executes synchronously if the connection is synchronous,
        otherwise returns an awaitable.

        Args:
            connection: The database connection to use (optional)
            **kwargs: Fields to update

        Returns:
            The updated document instance (or awaitable resolving to it)

        """
        # Determine target connection
        target_connection = connection or get_active_connection()
        
        if not target_connection.is_async():
            return self.update_sync(connection=target_connection, **kwargs)

        return self._update_async(connection=target_connection, **kwargs)

    async def _update_async(self, connection: Optional[Any] = None, **kwargs) -> 'Document':
        """Internal async implementation of update()."""
        # Trigger pre_save signal
        if SIGNAL_SUPPORT:
            pre_save.send(self.__class__, document=self)

        if connection is None:
            connection = get_active_connection(async_mode=True)

        # Update fields from kwargs
        for key, value in kwargs.items():
            setattr(self, key, value)

        self.validate()
        
        if not self.id:
            raise ValidationError("Cannot update a document without an ID.")

        # Get changed data
        data = self.get_changed_data_for_update()
        if not data:
            return self
            
        data = serialize_http_safe(data)
        
        # Use merge for partial update
        result = await connection.client.merge(self.id, data)
        
        # Update the current instance with the returned data
        if result:
            doc_data = result[0] if isinstance(result, list) and result else result
            if isinstance(doc_data, dict):
                self._data.update(doc_data)
                # Parse fields
                for field_name, field in self._fields.items():
                    if field_name in doc_data:
                        val = field.from_db(doc_data[field_name])
                        self._data[field_name] = val
                        
                        # Register parent for tracked objects
                        if hasattr(val, '_set_parent') and callable(val._set_parent):
                            val._set_parent(self, field_name)
        else:
            from .exceptions import DoesNotExist
            raise DoesNotExist(f"Document with ID {self.id} does not exist.")
        
        # Trigger post_save signal
        if SIGNAL_SUPPORT:
            post_save.send(self.__class__, document=self, created=False)

        self.mark_clean()
        return self

    def update_sync(self, connection: Optional[Any] = None, **kwargs) -> 'Document':
        """Update the document with new data synchronously.

        Args:
            connection: The database connection to use (optional)
            **kwargs: Fields to update

        Returns:
            The updated document instance

        """
        # Trigger pre_save signal
        if SIGNAL_SUPPORT:
            pre_save.send(self.__class__, document=self)

        if connection is None:
            connection = get_active_connection(async_mode=False)

        # Update fields from kwargs
        for key, value in kwargs.items():
            setattr(self, key, value)

        self.validate()
        
        if not self.id:
            raise ValidationError("Cannot update a document without an ID.")

        # Get changed data
        data = self.get_changed_data_for_update()
        if not data:
            return self
            
        data = serialize_http_safe(data)
        
        # Use merge for partial update
        result = connection.client.merge(self.id, data)
        
        # Update the current instance with the returned data
        if result:
            doc_data = result[0] if isinstance(result, list) and result else result
            if isinstance(doc_data, dict):
                self._data.update(doc_data)
                # Parse fields
                for field_name, field in self._fields.items():
                    if field_name in doc_data:
                        val = field.from_db(doc_data[field_name])
                        self._data[field_name] = val
                        
                        # Register parent for tracked objects
                        if hasattr(val, '_set_parent') and callable(val._set_parent):
                            val._set_parent(self, field_name)
        else:
            from .exceptions import DoesNotExist
            raise DoesNotExist(f"Document with ID {self.id} does not exist.")
        
        # Trigger post_save signal
        if SIGNAL_SUPPORT:
            post_save.send(self.__class__, document=self, created=False)

        self.mark_clean()
        return self

    def save(self, connection: Optional[Any] = None) -> Union['Document', Any]:
        """Save the document to the database.
        
        Polyglot method: executes synchronously if the connection is synchronous,
        otherwise returns an awaitable.

        Args:
            connection: The connection to use (optional)

        Returns:
            The saved document instance (or awaitable resolving to it)

        """
        # Determine target connection
        target_connection = connection or get_active_connection(async_mode=None)
        
        if not target_connection.is_async():
            return self.save_sync(connection=target_connection)

        return self._save_async(connection=target_connection)

    async def _save_async(self, connection: Optional[Any] = None) -> 'Document':
        """Internal async implementation of save()."""
        # Trigger pre_save signal
        if SIGNAL_SUPPORT:
            pre_save.send(self.__class__, document=self)

        if connection is None:
            connection = get_active_connection(async_mode=True)

        # Execute pre-save model validation
        if hasattr(self, 'clean') and callable(self.clean):
            self.clean()

        self.validate()

        # Update existing document if possible
        if self.id and self._changed_fields:
            data = self.get_changed_data_for_update()
            if data:
                from .exceptions import DoesNotExist
                try:
                    return await self.update(connection=connection, **data)
                except DoesNotExist:
                    # Document doesn't exist, proceed to create
                    pass
        
        if self.id and not self._changed_fields:
            return self

        # Create new document
        # Trigger pre_save_post_validation signal
        if SIGNAL_SUPPORT:
            pre_save_post_validation.send(self.__class__, document=self)

        # Auto-assign ID from sequence when Meta.sequence is configured and no id set yet
        seq_name = self._meta.get('sequence') if hasattr(self, '_meta') else None
        if seq_name and not self.id:
            try:
                from surrealdb import RecordID as _RecordID
                _seq_result = await connection.client.query(
                    f"RETURN sequence::nextval('{seq_name}')"
                )
                _seq_val = _seq_result[0] if isinstance(_seq_result, list) else _seq_result
                self._data['id'] = _RecordID(self._get_collection_name(), int(_seq_val))
            except Exception as _seq_err:
                pass  # Fall through to let SurrealDB assign a random id

        # Auto-fill any SequenceField values that haven't been set yet
        from .fields.additional import SequenceField as _SequenceField
        for _fname, _field in self._fields.items():
            if isinstance(_field, _SequenceField) and self._data.get(_fname) is None:
                try:
                    _sf_result = await connection.client.query(
                        f"RETURN sequence::nextval('{_field.sequence}')"
                    )
                    _sf_val = _sf_result[0] if isinstance(_sf_result, list) else _sf_result
                    self._data[_fname] = int(_sf_val)
                except Exception:
                    pass

        data = self.to_db()
        safe_data = serialize_http_safe(data)

        # If id was pre-assigned (e.g. from sequence), create at that specific record
        if self.id:
            result = await connection.client.upsert(
                self._data['id'],
                safe_data
            )
        else:
            result = await connection.client.create(
                self._get_collection_name(),
                safe_data
            )
        
        # Update the current instance with the returned data
        if result:
            doc_data = result[0] if isinstance(result, list) and result else result
            if isinstance(doc_data, dict):
                self._data.update(doc_data)
                if 'id' in doc_data:
                    self._data['id'] = doc_data['id']
                for field_name, field in self._fields.items():
                    if field_name in doc_data:
                        val = field.from_db(doc_data[field_name])
                        self._data[field_name] = val
                        
                        # Register parent for tracked objects
                        if hasattr(val, '_set_parent') and callable(val._set_parent):
                            val._set_parent(self, field_name)
        else:
            from .exceptions import DocumentNotSavedError
            raise DocumentNotSavedError(f"Failed to save {self.__class__.__name__} to database.")
        
        # Trigger post_save signal
        if SIGNAL_SUPPORT:
            post_save.send(self.__class__, document=self, created=True)

        self.mark_clean()
        return self

    def save_sync(self, connection: Optional[Any] = None) -> 'Document':
        """Save the document to the database synchronously.

        This method saves the document to the database, either creating
        a new document or updating an existing one based on whether the
        document has an ID.

        Args:
            connection: The database connection to use (optional)

        Returns:
            The saved document instance

        Raises:
            ValidationError: If the document fails validation

        """
        # Trigger pre_save signal
        if SIGNAL_SUPPORT:
            pre_save.send(self.__class__, document=self)

        if connection is None:
            connection = get_active_connection(async_mode=False)

        # Execute pre-save model validation
        if hasattr(self, 'clean') and callable(self.clean):
            self.clean()

        self.validate()
        
        # Smart save: use only changed fields for existing documents
        if self.id and self._changed_fields:
            data = self.get_changed_data_for_update()
            if data:
                from .exceptions import DoesNotExist
                try:
                    return self.update_sync(connection=connection, **data)
                except DoesNotExist:
                    pass
        
        # If we have an ID but no changes, we don't need to do anything
        if self.id and not self._changed_fields:
            return self

        # Create new document
        # Trigger pre_save_post_validation signal
        if SIGNAL_SUPPORT:
            pre_save_post_validation.send(self.__class__, document=self)

        # Auto-assign ID from sequence when Meta.sequence is configured and no id set yet
        seq_name = self._meta.get('sequence') if hasattr(self, '_meta') else None
        if seq_name and not self.id:
            try:
                from surrealdb import RecordID as _RecordID
                _seq_result = connection.client.query(
                    f"RETURN sequence::nextval('{seq_name}')"
                )
                _seq_val = _seq_result[0] if isinstance(_seq_result, list) else _seq_result
                self._data['id'] = _RecordID(self._get_collection_name(), int(_seq_val))
            except Exception as _seq_err:
                pass  # Fall through to let SurrealDB assign a random id

        # Auto-fill any SequenceField values that haven't been set yet
        from .fields.additional import SequenceField as _SequenceField
        for _fname, _field in self._fields.items():
            if isinstance(_field, _SequenceField) and self._data.get(_fname) is None:
                try:
                    _sf_result = connection.client.query(
                        f"RETURN sequence::nextval('{_field.sequence}')"
                    )
                    _sf_val = _sf_result[0] if isinstance(_sf_result, list) else _sf_result
                    self._data[_fname] = int(_sf_val)
                except Exception:
                    pass

        data = self.to_db()
        data = serialize_http_safe(data)

        # If id was pre-assigned (e.g. from sequence), create at that specific record
        if self.id:
            result = connection.client.upsert(
                self._data['id'],
                data
            )
        else:
            result = connection.client.create(
                self._get_collection_name(),
                data
            )

        # Update the current instance with the returned data
        if result:
            if isinstance(result, list) and result:
                doc_data = result[0]
            else:
                doc_data = result

            # Update the instance's _data with the returned document
            if isinstance(doc_data, dict):
                # First update the raw data
                self._data.update(doc_data)

                # Make sure to capture the ID if it's a new document
                if 'id' in doc_data:
                    self._data['id'] = doc_data['id']

                # Then properly convert each field using its from_db method
                for field_name, field in self._fields.items():
                    if field_name in doc_data:
                        val = field.from_db(doc_data[field_name])
                        self._data[field_name] = val
                        
                        # Register parent for tracked objects
                        if hasattr(val, '_set_parent') and callable(val._set_parent):
                            val._set_parent(self, field_name)
        else:
            from .exceptions import DocumentNotSavedError
            raise DocumentNotSavedError(f"Failed to save {self.__class__.__name__} to database.")

        # Trigger post_save signal
        if SIGNAL_SUPPORT:
            post_save.send(self.__class__, document=self, created=True)

        # Mark document as clean after successful save
        self.mark_clean()

        return self

    def delete(self, connection: Optional[Any] = None) -> Union[bool, Any]:
        """Delete the document from the database.
        
        Polyglot method: executes synchronously if the connection is synchronous,
        otherwise returns an awaitable.

        Args:
            connection: The database connection to use (optional)

        Returns:
            True if deleted (or awaitable resolving to it)

        """
        # Determine target connection
        target_connection = connection or get_active_connection(async_mode=None)
        
        if not target_connection.is_async():
            return self.delete_sync(connection=target_connection)

        return self._delete_async(connection=target_connection)

    async def _delete_async(self, connection: Optional[Any] = None) -> bool:
        """Internal async implementation of delete()."""
        # Trigger pre_delete signal
        if SIGNAL_SUPPORT:
            pre_delete.send(self.__class__, document=self)

        if connection is None:
            connection = get_active_connection(async_mode=True)
        if not self.id:
            raise ValueError("Cannot delete a document without an ID")

        await connection.client.delete(f"{self.id}")

        # Trigger post_delete signal
        if SIGNAL_SUPPORT:
            post_delete.send(self.__class__, document=self)

        return True

    def delete_sync(self, connection: Optional[Any] = None) -> bool:
        """Delete the document from the database synchronously.

        This method deletes the document from the database.

        Args:
            connection: The database connection to use (optional)

        Returns:
            True if the document was deleted

        Raises:
            ValueError: If the document doesn't have an ID

        """
        # Trigger pre_delete signal
        if SIGNAL_SUPPORT:
            pre_delete.send(self.__class__, document=self)

        if connection is None:
            connection = get_active_connection(async_mode=False)
        if not self.id:
            raise ValueError("Cannot delete a document without an ID")

        connection.client.delete(f"{self.id}")

        # Trigger post_delete signal
        if SIGNAL_SUPPORT:
            post_delete.send(self.__class__, document=self)

        return True

    def refresh(self, connection: Optional[Any] = None) -> Union['Document', Any]:
        """Refresh the document from the database.
        
        Polyglot method: executes synchronously if the connection is synchronous,
        otherwise returns an awaitable.

        Args:
            connection: The database connection to use (optional)

        Returns:
            The refreshed document instance (or awaitable resolving to it)

        """
        # Determine target connection
        target_connection = connection or get_active_connection(async_mode=None)
        
        if not target_connection.is_async():
            return self.refresh_sync(connection=target_connection)

        return self._refresh_async(connection=target_connection)

    async def _refresh_async(self, connection: Optional[Any] = None) -> 'Document':
        """Internal async implementation of refresh()."""
        if connection is None:
            connection = get_active_connection(async_mode=True)
        if not self.id:
            raise ValueError("Cannot refresh a document without an ID")

        # Detect IncomingReferenceField fields so we can add FETCH clauses
        try:
            from .fields.reference import IncomingReferenceField as _IRF
            fetch_fields = [
                field.db_field or fname
                for fname, field in self._fields.items()
                if isinstance(field, _IRF)
            ]
        except ImportError:
            fetch_fields = []

        if fetch_fields:
            fetch_clause = ", ".join(fetch_fields)
            raw = await connection.client.query(
                f"SELECT * FROM {self.id} FETCH {fetch_clause}"
            )
            # query() returns a list of result rows
            if raw and isinstance(raw, list):
                doc = raw[0] if isinstance(raw[0], dict) else (raw[0].get('result', [{}])[0] if hasattr(raw[0], 'get') else {})
            else:
                doc = {}
        else:
            result = await connection.client.select(f"{self.id}")
            if result:
                doc = result[0] if isinstance(result, list) and result else result
            else:
                doc = {}

        if doc:
            for field_name, field in self._fields.items():
                db_field = field.db_field or field_name
                if db_field in doc:
                    val = field.from_db(doc[db_field])
                    self._data[field_name] = val

                    # Register parent for tracked objects
                    if hasattr(val, '_set_parent') and callable(val._set_parent):
                        val._set_parent(self, field_name)

            # Reset change tracking after refresh
            from copy import deepcopy
            self._original_data = deepcopy(self._data)
            self._changed_fields = []
        return self

    def refresh_sync(self, connection: Optional[Any] = None) -> 'Document':
        """Refresh the document from the database synchronously."""
        if connection is None:
            connection = get_active_connection(async_mode=False)
        if not self.id:
            raise ValueError("Cannot refresh a document without an ID")

        # Detect IncomingReferenceField fields so we can add FETCH clauses
        try:
            from .fields.reference import IncomingReferenceField as _IRF
            fetch_fields = [
                field.db_field or fname
                for fname, field in self._fields.items()
                if isinstance(field, _IRF)
            ]
        except ImportError:
            fetch_fields = []

        if fetch_fields:
            fetch_clause = ", ".join(fetch_fields)
            raw = connection.client.query(
                f"SELECT * FROM {self.id} FETCH {fetch_clause}"
            )
            if raw and isinstance(raw, list):
                doc = raw[0] if isinstance(raw[0], dict) else (raw[0].get('result', [{}])[0] if hasattr(raw[0], 'get') else {})
            else:
                doc = {}
        else:
            result = connection.client.select(f"{self.id}")
            if result:
                doc = result[0] if isinstance(result, list) and result else result
            else:
                doc = {}

        if doc:
            for field_name, field in self._fields.items():
                db_field = field.db_field or field_name
                if db_field in doc:
                    val = field.from_db(doc[db_field])
                    self._data[field_name] = val

                    # Register parent for tracked objects
                    if hasattr(val, '_set_parent') and callable(val._set_parent):
                        val._set_parent(self, field_name)

            # Reset change tracking after refresh
            from copy import deepcopy
            self._original_data = deepcopy(self._data)
            self._changed_fields = []
        return self

    @classmethod
    def relates(cls, relation_name: str) -> callable:
        """Get a RelationQuerySet for a specific relation.

        This method returns a function that creates a RelationQuerySet for
        the specified relation name. The function can be called with an
        optional connection parameter.

        Args:
            relation_name: Name of the relation

        Returns:
            Function that creates a RelationQuerySet

        """

        def relation_query_builder(connection: Optional[Any] = None) -> RelationQuerySet:
            """Create a RelationQuerySet for the specified relation.

            Args:
                connection: The database connection to use (optional)

            Returns:
                A RelationQuerySet for the relation

            """
            if connection is None:
                connection = ConnectionRegistry.get_default_connection()
            return RelationQuerySet(cls, connection, relation=relation_name)

        return relation_query_builder

    def fetch_relation(self, relation_name: str, target_document: Optional[Type] = None,
                       relation_document: Optional[Type] = None, connection: Optional[Any] = None,
                       **filters: Any) -> Union[List[Any], Any]:
        """Fetch related documents.
        
        Polyglot method: executes synchronously if the connection is synchronous,
        otherwise returns an awaitable.

        Args:
            relation_name: Name of the relation
            target_document: The document class of the target documents (optional)
            relation_document: The document class representing the relation (optional)
            connection: The database connection to use (optional)
            **filters: Filters to apply to the related documents

        Returns:
            List of related documents (or awaitable resolving to it)

        """
        # Determine target connection
        target_connection = connection or get_active_connection()
        
        if not target_connection.is_async():
            return self.fetch_relation_sync(
                relation_name, target_document, relation_document, connection=target_connection, **filters
            )

        return self._fetch_relation_async(
            relation_name, target_document, relation_document, connection=target_connection, **filters
        )

    async def _fetch_relation_async(self, relation_name: str, target_document: Optional[Type] = None,
                              relation_document: Optional[Type] = None, connection: Optional[Any] = None,
                              **filters: Any) -> List[Any]:
        """Internal async implementation of fetch_relation()."""
        if connection is None:
            connection = get_active_connection(async_mode=True)
        relation_query = RelationQuerySet(self.__class__, connection, relation=relation_name)
        result = await relation_query.get_related(self, target_document, **filters)

        # If relation_document is specified, convert the relation records to RelationDocument instances
        if relation_document and not target_document:
            return [relation_document.from_db(record) for record in result]

        return result

    def fetch_relation_sync(self, relation_name: str, target_document: Optional[Type] = None,
                            relation_document: Optional[Type] = None, connection: Optional[Any] = None,
                            **filters: Any) -> List[Any]:
        """Fetch related documents synchronously.

        This method fetches documents related to this document through
        the specified relation.

        Args:
            relation_name: Name of the relation
            target_document: The document class of the target documents (optional)
            relation_document: The document class representing the relation (optional)
            connection: The database connection to use (optional)
            **filters: Filters to apply to the related documents

        Returns:
            List of related documents, relation documents, or relation records

        """
        if connection is None:
            connection = get_active_connection(async_mode=False)
        relation_query = RelationQuerySet(self.__class__, connection, relation=relation_name)
        result = relation_query.get_related_sync(self, target_document, **filters)

        # If relation_document is specified, convert the relation records to RelationDocument instances
        if relation_document and not target_document:
            return [relation_document.from_db(record) for record in result]

        return result

    def resolve_relation(self, relation_name: str, target_document_class: Optional[Type] = None,
                         relation_document: Optional[Type] = None, connection: Optional[Any] = None) -> Union[List[Any], Any]:
        """Resolve related documents from a relation fetch result.
        
        Polyglot method: executes synchronously if the connection is synchronous,
        otherwise returns an awaitable.

        Args:
            relation_name: Name of the relation to resolve
            target_document_class: Class of the target document (optional)
            relation_document: The document class representing the relation (optional)
            connection: Database connection to use (optional)

        Returns:
            List of resolved document instances (or awaitable resolving to it)

        """
        # Determine target connection
        target_connection = connection or get_active_connection()
        
        if not target_connection.is_async():
            return self.resolve_relation_sync(
                relation_name, target_document_class, relation_document, connection=target_connection
            )

        return self._resolve_relation_async(
            relation_name, target_document_class, relation_document, connection=target_connection
        )

    async def _resolve_relation_async(self, relation_name: str, target_document_class: Optional[Type] = None,
                                relation_document: Optional[Type] = None, connection: Optional[Any] = None) -> List[Any]:
        """Internal async implementation of resolve_relation()."""
        if connection is None:
            connection = get_active_connection(async_mode=True)

        # If relation_document is specified, convert the relation records to RelationDocument instances
        if relation_document and not target_document_class:
            return await self.fetch_relation(relation_name, relation_document=relation_document, connection=connection)

        # First fetch the relation data
        relation_data = await self.fetch_relation(relation_name, connection=connection)
        if not relation_data:
            return []

        resolved_documents = []
        if isinstance(relation_data, dict) and 'related' in relation_data and isinstance(relation_data['related'],
                                                                                         list):
            for related_id in relation_data['related']:
                if isinstance(related_id, RecordID):
                    collection = related_id.table_name
                    record_id = related_id.id

                    # Fetch the actual document
                    try:
                        result = await connection.client.select(related_id)
                        if result and isinstance(result, list):
                            doc = result[0]
                        else:
                            doc = result

                        if doc:
                            resolved_documents.append(doc)
                    except Exception as e:
                        logger.error(f"Error resolving document {collection}:{record_id}: {str(e)}")

        return resolved_documents

    def resolve_relation_sync(self, relation_name: str, target_document_class: Optional[Type] = None,
                              relation_document: Optional[Type] = None, connection: Optional[Any] = None) -> List[Any]:
        """Resolve related documents from a relation fetch result synchronously.

        This method resolves related documents from a relation fetch result.
        It fetches the relation data and then resolves each related document.

        Args:
            relation_name: Name of the relation to resolve
            target_document_class: Class of the target document (optional)
            relation_document: The document class representing the relation (optional)
            connection: Database connection to use (optional)

        Returns:
            List of resolved document instances

        """
        if connection is None:
            connection = get_active_connection(async_mode=False)

        # If relation_document is specified, convert the relation records to RelationDocument instances
        if relation_document and not target_document_class:
            return self.fetch_relation_sync(relation_name, relation_document=relation_document, connection=connection)

        # First fetch the relation data
        relation_data = self.fetch_relation_sync(relation_name, connection=connection)
        if not relation_data:
            return []

        resolved_documents = []
        if isinstance(relation_data, dict) and 'related' in relation_data and isinstance(relation_data['related'],
                                                                                         list):
            for related_id in relation_data['related']:
                if isinstance(related_id, RecordID):
                    collection = related_id.table_name
                    record_id = related_id.id

                    # Fetch the actual document
                    try:
                        result = connection.client.select(related_id)
                        if result and isinstance(result, list):
                            doc = result[0]
                        else:
                            doc = result

                        if doc:
                            resolved_documents.append(doc)
                    except Exception as e:
                        logger.error(f"Error resolving document {collection}:{record_id}: {str(e)}")

        return resolved_documents

    def relate_to(self, relation_name: str, target_instance: Any,
                  connection: Optional[Any] = None, **attrs: Any) -> Union[Optional[Any], Any]:
        """Create a relation to another document.
        
        Polyglot method: executes synchronously if the connection is synchronous,
        otherwise returns an awaitable.

        Args:
            relation_name: Name of the relation
            target_instance: The document instance to relate to
            connection: The database connection to use (optional)
            **attrs: Attributes to set on the relation

        Returns:
            The created relation record or None (or awaitable resolving to it)

        """
        # Determine target connection
        target_connection = connection or get_active_connection()
        
        if not target_connection.is_async():
            return self.relate_to_sync(
                relation_name, target_instance, connection=target_connection, **attrs
            )

        return self._relate_to_async(
            relation_name, target_instance, connection=target_connection, **attrs
        )

    async def _relate_to_async(self, relation_name: str, target_instance: Any,
                         connection: Optional[Any] = None, **attrs: Any) -> Optional[Any]:
        """Internal async implementation of relate_to()."""
        if connection is None:
            connection = get_active_connection(async_mode=True)
        relation_query = RelationQuerySet(self.__class__, connection, relation=relation_name)
        return await relation_query.relate(self, target_instance, **attrs)

    def relate_to_sync(self, relation_name: str, target_instance: Any,
                       connection: Optional[Any] = None, **attrs: Any) -> Optional[Any]:
        """Create a relation to another document synchronously.

        This method creates a relation from this document to another document.

        Args:
            relation_name: Name of the relation
            target_instance: The document instance to relate to
            connection: The database connection to use (optional)
            **attrs: Attributes to set on the relation

        Returns:
            The created relation record or None if creation failed

        """
        if connection is None:
            connection = get_active_connection(async_mode=False)
        relation_query = RelationQuerySet(self.__class__, connection, relation=relation_name)
        return relation_query.relate_sync(self, target_instance, **attrs)

    def update_relation_to(self, relation_name: str, target_instance: Any,
                           connection: Optional[Any] = None, **attrs: Any) -> Union[Optional[Any], Any]:
        """Update a relation to another document.
        
        Polyglot method: executes synchronously if the connection is synchronous,
        otherwise returns an awaitable.

        Args:
            relation_name: Name of the relation
            target_instance: The document instance the relation is to
            connection: The database connection to use (optional)
            **attrs: Attributes to update on the relation

        Returns:
            The updated relation record or None (or awaitable resolving to it)

        """
        # Determine target connection
        target_connection = connection or get_active_connection()
        
        if not target_connection.is_async():
            return self.update_relation_to_sync(
                relation_name, target_instance, connection=target_connection, **attrs
            )

        return self._update_relation_to_async(
            relation_name, target_instance, connection=target_connection, **attrs
        )

    async def _update_relation_to_async(self, relation_name: str, target_instance: Any,
                                  connection: Optional[Any] = None, **attrs: Any) -> Optional[Any]:
        """Internal async implementation of update_relation_to()."""
        if connection is None:
            connection = get_active_connection(async_mode=True)
        relation_query = RelationQuerySet(self.__class__, connection, relation=relation_name)
        return await relation_query.update_relation(self, target_instance, **attrs)

    def update_relation_to_sync(self, relation_name: str, target_instance: Any,
                                connection: Optional[Any] = None, **attrs: Any) -> Optional[Any]:
        """Update a relation to another document synchronously.

        This method updates a relation from this document to another document.

        Args:
            relation_name: Name of the relation
            target_instance: The document instance the relation is to
            connection: The database connection to use (optional)
            **attrs: Attributes to update on the relation

        Returns:
            The updated relation record or None if update failed

        """
        if connection is None:
            connection = get_active_connection(async_mode=False)
        relation_query = RelationQuerySet(self.__class__, connection, relation=relation_name)
        return relation_query.update_relation_sync(self, target_instance, **attrs)

    def delete_relation_to(self, relation_name: str, target_instance: Optional[Any] = None,
                           connection: Optional[Any] = None) -> Union[int, Any]:
        """Delete a relation to another document.
        
        Polyglot method: executes synchronously if the connection is synchronous,
        otherwise returns an awaitable.

        Args:
            relation_name: Name of the relation
            target_instance: The document instance the relation is to (optional)
            connection: The database connection to use (optional)

        Returns:
            Number of deleted relations (or awaitable resolving to it)

        """
        # Determine target connection
        target_connection = connection or get_active_connection()
        
        if not target_connection.is_async():
            return self.delete_relation_to_sync(
                relation_name, target_instance, connection=target_connection
            )

        return self._delete_relation_to_async(
            relation_name, target_instance, connection=target_connection
        )

    async def _delete_relation_to_async(self, relation_name: str, target_instance: Optional[Any] = None,
                                  connection: Optional[Any] = None) -> int:
        """Internal async implementation of delete_relation_to()."""
        if connection is None:
            connection = get_active_connection(async_mode=True)
        relation_query = RelationQuerySet(self.__class__, connection, relation=relation_name)
        return await relation_query.delete_relation(self, target_instance)

    def delete_relation_to_sync(self, relation_name: str, target_instance: Optional[Any] = None,
                                connection: Optional[Any] = None) -> int:
        """Delete a relation to another document synchronously.

        This method deletes a relation from this document to another document.
        If target_instance is not provided, it deletes all relations with the
        specified name from this document.

        Args:
            relation_name: Name of the relation
            target_instance: The document instance the relation is to (optional)
            connection: The database connection to use (optional)

        Returns:
            Number of deleted relations

        """
        if connection is None:
            connection = get_active_connection(async_mode=False)
        relation_query = RelationQuerySet(self.__class__, connection, relation=relation_name)
        return relation_query.delete_relation_sync(self, target_instance)

    def traverse_path(self, path_spec: str, target_document: Optional[Type] = None,
                      connection: Optional[Any] = None, **filters: Any) -> Union[List[Any], Any]:
        """Traverse a path in the graph.
        
        Polyglot method: executes synchronously if the connection is synchronous,
        otherwise returns an awaitable.

        Args:
            path_spec: String describing the path to traverse
            target_document: The document class to return instances of (optional)
            connection: The database connection to use (optional)
            **filters: Filters to apply to the results

        Returns:
            List of documents or path results (or awaitable resolving to it)

        Raises:
            ValueError: If the document is not saved

        """
        # Determine target connection
        target_connection = connection or get_active_connection()
        
        if not target_connection.is_async():
            return self.traverse_path_sync(
                path_spec, target_document, connection=target_connection, **filters
            )

        return self._traverse_path_async(
            path_spec, target_document, connection=target_connection, **filters
        )

    async def _traverse_path_async(self, path_spec: str, target_document: Optional[Type] = None,
                             connection: Optional[Any] = None, **filters: Any) -> List[Any]:
        """Internal async implementation of traverse_path()."""
        if connection is None:
            connection = get_active_connection(async_mode=True)
        if not self.id:
            raise ValueError(f"Cannot traverse from unsaved {self.__class__.__name__}")

        start_id = f"{self.__class__._get_collection_name()}:{self.id}"

        if target_document:
            end_collection = target_document._get_collection_name()
            query = f"SELECT * FROM {end_collection} WHERE {path_spec}{start_id}"
        else:
            query = f"SELECT {path_spec} as path FROM {start_id}"

        # Add additional filters if provided
        if filters:
            conditions = []
            for field, value in filters.items():
                from .surrealql import escape_literal
                conditions.append(f"{field} = {escape_literal(value)}")

            if target_document:
                query += f" AND {' AND '.join(conditions)}"
            else:
                query += f" WHERE {' AND '.join(conditions)}"

        result = await connection.client.query(query)

        if not result or not result[0]:
            return []

        # Process results based on query type
        if target_document:
            # Return list of related document instances
            return [target_document.from_db(doc) for doc in result[0]]
        else:
            # Return raw path results
            return result[0]

    def traverse_path_sync(self, path_spec: str, target_document: Optional[Type] = None,
                           connection: Optional[Any] = None, **filters: Any) -> List[Any]:
        """Traverse a path in the graph synchronously.

        This method traverses a path in the graph starting from this document.
        The path_spec is a string like "->[watched]->->[acted_in]->" which describes
        a path through the graph.

        Args:
            path_spec: String describing the path to traverse
            target_document: The document class to return instances of (optional)
            connection: The database connection to use (optional)
            **filters: Filters to apply to the results

        Returns:
            List of documents or path results

        Raises:
            ValueError: If the document is not saved

        """
        if connection is None:
            connection = get_active_connection(async_mode=False)
        if not self.id:
            raise ValueError(f"Cannot traverse from unsaved {self.__class__.__name__}")

        start_id = f"{self.__class__._get_collection_name()}:{self.id}"

        if target_document:
            end_collection = target_document._get_collection_name()
            query = f"SELECT * FROM {end_collection} WHERE {path_spec}{start_id}"
        else:
            query = f"SELECT {path_spec} as path FROM {start_id}"

        # Add additional filters if provided
        if filters:
            conditions = []
            for field, value in filters.items():
                from .surrealql import escape_literal
                conditions.append(f"{field} = {escape_literal(value)}")

            if target_document:
                query += f" AND {' AND '.join(conditions)}"
            else:
                query += f" WHERE {' AND '.join(conditions)}"

        result = connection.client.query(query)

        if not result or not result[0]:
            return []

        # Process results based on query type
        if target_document:
            # Return list of related document instances
            return [target_document.from_db(doc) for doc in result[0]]
        else:
            # Return raw path results
            return result[0]

    @classmethod
    def bulk_create(cls, documents: List[Any], batch_size: int = 1000,
                    validate: bool = True, return_documents: bool = True, connection: Optional[Any] = None) -> \
            Union[Union[List[Any], int], Any]:
        """Create multiple documents in batches.
        
        Polyglot method: executes synchronously if the connection is synchronous,
        otherwise returns an awaitable.

        Args:
            documents: List of documents to create
            batch_size: Number of documents per batch
            validate: Whether to validate documents before creation
            return_documents: Whether to return created documents

        Returns:
            List of created documents or count (or awaitable resolving to it)

        """
        # Determine target connection
        target_connection = connection or get_active_connection()
        
        if not target_connection.is_async():
            return cls.bulk_create_sync(
                documents, 
                batch_size=batch_size, 
                validate=validate, 
                return_documents=return_documents,
                connection=target_connection
            )

        return cls._bulk_create_async(
            documents, 
            batch_size=batch_size, 
            validate=validate, 
            return_documents=return_documents,
            connection=target_connection
        )

    @classmethod
    async def _bulk_create_async(cls, documents: List[Any], batch_size: int = 1000,
                           validate: bool = True, return_documents: bool = True, connection: Optional[Any] = None) -> \
            Union[List[Any], int]:
        """Internal async implementation of bulk_create()."""
        results = []
        total_count = 0

        # Process documents in batches
        for i in range(0, len(documents), batch_size):
            batch = documents[i:i + batch_size]

            if validate:
                # Perform validation without using asyncio.gather since validate is not async
                for doc in batch:
                    doc.validate()

            # Convert batch to DB representation
            data = [doc.to_db() for doc in batch]

            # Create the documents in the database
            collection = batch[0]._get_collection_name()
            if connection is None:
                connection = get_active_connection(async_mode=True)
            created = await connection.client.insert(collection, data)

            if created:
                if return_documents:
                    # Convert created records back to documents
                    for record in created:
                        doc = cls.from_db(record)
                        results.append(doc)
                total_count += len(created)

        return results if return_documents else total_count

    @classmethod
    def bulk_create_sync(cls, documents: List[Any], batch_size: int = 1000,
                         validate: bool = True, return_documents: bool = True,
                         connection: Optional[Any] = None) -> Union[List[Any], int]:
        """Create multiple documents in a single operation synchronously.

        This method creates multiple documents in a single operation, processing
        them in batches for better performance. It can optionally validate the
        documents and return the created documents.

        Args:
            documents: List of Document instances to create
            batch_size: Number of documents per batch (default: 1000)
            validate: Whether to validate documents (default: True)
            return_documents: Whether to return created documents (default: True)
            connection: The database connection to use (optional)

        Returns:
            List of created documents with their IDs set if return_documents=True,
            otherwise returns the count of created documents

        """
        # Trigger pre_bulk_insert signal
        if SIGNAL_SUPPORT:
            pre_bulk_insert.send(cls, documents=documents)

        if connection is None:
            connection = get_active_connection(async_mode=False)

        result = cls.objects(connection).bulk_create_sync(
            documents,
            batch_size=batch_size,
            validate=validate,
            return_documents=return_documents
        )

        # Trigger post_bulk_insert signal
        if SIGNAL_SUPPORT:
            post_bulk_insert.send(cls, documents=documents, loaded=return_documents)

        return result

    @classmethod
    def create_index(cls, index_name: str, fields: List[str], unique: bool = False,
                     search: bool = False, analyzer: Optional[str] = None,
                     comment: Optional[str] = None, connection: Optional[Any] = None,
                     **kwargs) -> Union[None, Any]:
        """Create an index on the document's collection.
        
        Polyglot method: executes synchronously if the connection is synchronous,
        otherwise returns an awaitable.

        Args:
            index_name: Name of the index
            fields: List of field names to include in the index
            unique: Whether the index should enforce uniqueness
            search: Whether the index is a search index
            analyzer: Analyzer to use for search indexes
            comment: Optional comment for the index
            connection: Optional connection to use

        """
        # Determine target connection
        target_connection = connection or get_active_connection()
        
        if not target_connection.is_async():
            return cls.create_index_sync(
                index_name, fields, unique, search, analyzer, comment, connection=target_connection, **kwargs
            )

        return cls._create_index_async(
            index_name, fields, unique, search, analyzer, comment, connection=target_connection, **kwargs
        )

    @classmethod
    async def _create_index_async(cls, index_name: str, fields: List[str], unique: bool = False,
                            search: bool = False, analyzer: Optional[str] = None,
                            comment: Optional[str] = None, connection: Optional[Any] = None,
                            **kwargs) -> None:
        """Internal async implementation of create_index()."""
        if connection is None:
            connection = get_active_connection(async_mode=True)

        collection_name = cls._get_collection_name()
        fields_str = ", ".join(fields)

        # Build the index definition
        query = f"DEFINE INDEX {index_name} ON {collection_name} FIELDS {fields_str}"

        # Add index type
        if unique:
            query += " UNIQUE"
        elif search:
            if analyzer:
                if hasattr(analyzer, 'to_sql'):
                    try:
                        await connection.client.query(analyzer.to_sql())
                    except Exception as e:
                        if "already exists" not in str(e).lower() and "parse error" not in str(e).lower():
                            raise e
                    analyzer_str = getattr(analyzer, 'name', str(analyzer))
                else:
                    analyzer_str = str(analyzer)
                query += f" FULLTEXT ANALYZER {analyzer_str}"
            else:
                query += " FULLTEXT ANALYZER ascii"
            if kwargs.get('bm25'):
                query += " BM25"
            if kwargs.get('highlights'):
                query += " HIGHLIGHTS"
        elif kwargs.get('dimension'):
            # HNSW Vector Index
            dim = kwargs['dimension']
            query += f" HNSW DIMENSION {dim}"
            
            if kwargs.get('dist'):
                query += f" DIST {kwargs['dist']}"
            if kwargs.get('m'):
                query += f" M {kwargs['m']}"
            if kwargs.get('efc'):
                query += f" EFC {kwargs['efc']}"
            if kwargs.get('m0'):
                query += f" M0 {kwargs['m0']}"
            if kwargs.get('lm'):
                query += f" LM {kwargs['lm']}"

        # Add comment if provided
        if comment:
            safe_comment = str(comment).replace('\\', '\\\\').replace('"', '\\"')
            query += f' COMMENT "{safe_comment}"'

        # Execute the query
        try:
            await connection.client.query(query)
        except Exception as e:
            if search and "Parse error" in str(e):
                # Fallback to SurrealDB 2.x syntax for memory and older servers
                fallback_query = query.replace("FULLTEXT ANALYZER", "SEARCH ANALYZER")
                
                # SurrealDB 2.x needs HIGHLIGHTS before BM25
                if "BM25 HIGHLIGHTS" in fallback_query:
                    fallback_query = fallback_query.replace("BM25 HIGHLIGHTS", "HIGHLIGHTS BM25")
                elif "BM25" in fallback_query and "HIGHLIGHTS" in fallback_query:
                    fallback_query = fallback_query.replace(" BM25", "").replace(" HIGHLIGHTS", "")
                    fallback_query += " HIGHLIGHTS BM25"
                    
                await connection.client.query(fallback_query)
            else:
                raise e

    @classmethod
    def create_index_sync(cls, index_name: str, fields: List[str], unique: bool = False,
                          search: bool = False, analyzer: Optional[str] = None,
                          comment: Optional[str] = None, connection: Optional[Any] = None,
                          **kwargs) -> None:
        """Create an index on the document's collection synchronously.

        Args:
            index_name: Name of the index
            fields: List of field names to include in the index
            unique: Whether the index should enforce uniqueness
            search: Whether the index is a search index
            analyzer: Analyzer to use for search indexes
            comment: Optional comment for the index
            connection: Optional connection to use
            **kwargs: Additional index options (dimension, dist, bm25, highlights, etc.)

        """
        if connection is None:
            connection = get_active_connection(async_mode=False)

        collection_name = cls._get_collection_name()
        fields_str = ", ".join(fields)

        # Build the index definition
        query = f"DEFINE INDEX {index_name} ON {collection_name} FIELDS {fields_str}"

        # Add index type
        if unique:
            query += " UNIQUE"
        elif search:
            if analyzer:
                if hasattr(analyzer, 'to_sql'):
                    try:
                        connection.client.query(analyzer.to_sql())
                    except Exception as e:
                        if "already exists" not in str(e).lower() and "parse error" not in str(e).lower():
                            raise e
                    analyzer_str = getattr(analyzer, 'name', str(analyzer))
                else:
                    analyzer_str = str(analyzer)
                query += f" FULLTEXT ANALYZER {analyzer_str}"
            else:
                query += " FULLTEXT ANALYZER ascii"
            if kwargs.get('bm25'):
                query += " BM25"
            if kwargs.get('highlights'):
                query += " HIGHLIGHTS"
        elif kwargs.get('dimension'):
            # HNSW Vector Index
            dim = kwargs['dimension']
            query += f" HNSW DIMENSION {dim}"
            
            if kwargs.get('dist'):
                query += f" DIST {kwargs['dist']}"
            if kwargs.get('m'):
                query += f" M {kwargs['m']}"
            if kwargs.get('efc'):
                query += f" EFC {kwargs['efc']}"
            if kwargs.get('m0'):
                query += f" M0 {kwargs['m0']}"
            if kwargs.get('lm'):
                query += f" LM {kwargs['lm']}"

        # Add comment if provided
        if comment:
            safe_comment = str(comment).replace('\\', '\\\\').replace('"', '\\"')
            query += f' COMMENT "{safe_comment}"'

        # Execute the query
        try:
            connection.client.query(query)
        except Exception as e:
            if search and "Parse error" in str(e):
                # Fallback to SurrealDB 2.x syntax for memory and older servers
                fallback_query = query.replace("FULLTEXT ANALYZER", "SEARCH ANALYZER")
                
                # SurrealDB 2.x needs HIGHLIGHTS before BM25
                if "BM25 HIGHLIGHTS" in fallback_query:
                    fallback_query = fallback_query.replace("BM25 HIGHLIGHTS", "HIGHLIGHTS BM25")
                elif "BM25" in fallback_query and "HIGHLIGHTS" in fallback_query:
                    fallback_query = fallback_query.replace(" BM25", "").replace(" HIGHLIGHTS", "")
                    fallback_query += " HIGHLIGHTS BM25"
                    
                connection.client.query(fallback_query)
            else:
                raise e

    @classmethod
    def create_indexes(cls, connection: Optional[Any] = None) -> Union[None, Any]:
        """Create all indexes defined for this document class.
        
        Polyglot method: executes synchronously if the connection is synchronous,
        otherwise returns an awaitable.

        Args:
            connection: Optional connection to use

        """
        # Determine target connection
        target_connection = connection or get_active_connection()
        
        if not target_connection.is_async():
            return cls.create_indexes_sync(connection=target_connection)

        return cls._create_indexes_async(connection=target_connection)

    @classmethod
    async def _create_indexes_async(cls, connection: Optional[Any] = None) -> None:
        """Internal async implementation of create_indexes()."""
        if connection is None:
            connection = get_active_connection(async_mode=True)

        # Track processed multi-field indexes to avoid duplicates
        processed_multi_field_indexes = set()

        # Create indexes defined in Meta.indexes
        if hasattr(cls, '_meta') and 'indexes' in cls._meta and cls._meta['indexes']:
            for index_def in cls._meta['indexes']:
                # Handle different index definition formats
                if isinstance(index_def, dict):
                    # Dictionary format with options
                    index_name = index_def.get('name')
                    fields = index_def.get('fields', [])
                    unique = index_def.get('unique', False)
                    search = index_def.get('search', False)
                    analyzer = index_def.get('analyzer')
                    bm25 = index_def.get('bm25', False)
                    highlights = index_def.get('highlights', False)
                    comment = index_def.get('comment')
                elif isinstance(index_def, tuple) and len(index_def) >= 2:
                    # Tuple format (name, fields, [unique])
                    index_name = index_def[0]
                    fields = index_def[1] if isinstance(index_def[1], list) else [index_def[1]]
                    unique = index_def[2] if len(index_def) > 2 else False
                    search = False
                    analyzer = None
                    bm25 = False
                    highlights = False
                    comment = None
                else:
                    # Skip invalid index definitions
                    continue

                await cls.create_index(
                    index_name=index_name,
                    fields=fields,
                    unique=unique,
                    search=search,
                    analyzer=analyzer,
                    bm25=bm25,
                    highlights=highlights,
                    comment=comment,
                    connection=connection,
                    **{k: v for k, v in index_def.items() if k not in ['name', 'fields', 'unique', 'search', 'analyzer', 'bm25', 'highlights', 'comment']} if isinstance(index_def, dict) else {}
                )

                # Mark this index as processed to avoid duplicates
                if fields:
                    processed_multi_field_indexes.add(tuple(sorted(fields)))

        # Create indexes for fields marked as indexed
        for field_name, field_obj in cls._fields.items():
            if getattr(field_obj, 'indexed', False):
                db_field_name = field_obj.db_field or field_name

                # Check if this is a multi-field index
                index_with = getattr(field_obj, 'index_with', None)
                if index_with and isinstance(index_with, list) and len(index_with) > 0:
                    # Get the actual field names for the index_with fields
                    index_with_fields = []
                    for with_field_name in index_with:
                        if with_field_name in cls._fields:
                            with_field_obj = cls._fields[with_field_name]
                            with_db_field_name = with_field_obj.db_field or with_field_name
                            index_with_fields.append(with_db_field_name)
                        else:
                            # If the field doesn't exist, use the name as is
                            index_with_fields.append(with_field_name)

                    # Generate a unique identifier for this multi-field index
                    # Sort fields to ensure consistent ordering
                    all_fields = sorted([db_field_name] + index_with_fields)
                    index_key = tuple(all_fields)

                    # Skip if we've already processed this combination
                    if index_key in processed_multi_field_indexes:
                        continue

                    # Mark this combination as processed
                    processed_multi_field_indexes.add(index_key)

                    # Generate a default index name
                    index_name = f"{cls._get_collection_name()}_{'_'.join(all_fields)}_idx"

                    # Get index options
                    unique = getattr(field_obj, 'unique', False)
                    search = getattr(field_obj, 'search', False)
                    analyzer = getattr(field_obj, 'analyzer', None)
                    bm25 = getattr(field_obj, 'bm25', False)
                    highlights = getattr(field_obj, 'highlights', False)

                    # Create the multi-field index
                    await cls.create_index(
                        index_name=index_name,
                        fields=all_fields,
                        unique=unique,
                        search=search,
                        analyzer=analyzer,
                        bm25=bm25,
                        highlights=highlights,
                        connection=connection
                    )
                else:
                    # Create a single-field index
                    # Skip if we've already processed this field
                    if (db_field_name,) in processed_multi_field_indexes:
                        continue

                    # Mark this field as processed
                    processed_multi_field_indexes.add((db_field_name,))

                    # Generate a default index name
                    index_name = f"{cls._get_collection_name()}_{field_name}_idx"

                    # Get index options
                    unique = getattr(field_obj, 'unique', False)
                    search = getattr(field_obj, 'search', False)
                    analyzer = getattr(field_obj, 'analyzer', None)
                    bm25 = getattr(field_obj, 'bm25', False)
                    highlights = getattr(field_obj, 'highlights', False)

                    # Create the single-field index
                    await cls.create_index(
                        index_name=index_name,
                        fields=[db_field_name],
                        unique=unique,
                        search=search,
                        analyzer=analyzer,
                        bm25=bm25,
                        highlights=highlights,
                        connection=connection
                    )

    @classmethod
    def create_indexes_sync(cls, connection: Optional[Any] = None) -> None:
        """Create all indexes defined for this document class synchronously.

        This method creates indexes defined in the Meta class and also creates
        indexes for fields marked as indexed.

        Args:
            connection: Optional connection to use

        """
        if connection is None:
            connection = get_active_connection(async_mode=False)

        # Track processed multi-field indexes to avoid duplicates
        processed_multi_field_indexes = set()

        # Create indexes defined in Meta.indexes
        if hasattr(cls, '_meta') and 'indexes' in cls._meta and cls._meta['indexes']:
            for index_def in cls._meta['indexes']:
                # Handle different index definition formats
                if isinstance(index_def, dict):
                    # Dictionary format with options
                    index_name = index_def.get('name')
                    fields = index_def.get('fields', [])
                    unique = index_def.get('unique', False)
                    search = index_def.get('search', False)
                    analyzer = index_def.get('analyzer')
                    bm25 = index_def.get('bm25', False)
                    highlights = index_def.get('highlights', False)
                    comment = index_def.get('comment')
                elif isinstance(index_def, tuple) and len(index_def) >= 2:
                    # Tuple format (name, fields, [unique])
                    index_name = index_def[0]
                    fields = index_def[1] if isinstance(index_def[1], list) else [index_def[1]]
                    unique = index_def[2] if len(index_def) > 2 else False
                    search = False
                    analyzer = None
                    bm25 = False
                    highlights = False
                    comment = None
                else:
                    # Skip invalid index definitions
                    continue

                cls.create_index_sync(
                    index_name=index_name,
                    fields=fields,
                    unique=unique,
                    search=search,
                    analyzer=analyzer,
                    bm25=bm25,
                    highlights=highlights,
                    comment=comment,
                    connection=connection,
                    **{k: v for k, v in index_def.items() if k not in ['name', 'fields', 'unique', 'search', 'analyzer', 'bm25', 'highlights', 'comment']} if isinstance(index_def, dict) else {}
                )

                # Mark this index as processed to avoid duplicates
                if fields:
                    processed_multi_field_indexes.add(tuple(sorted(fields)))

        # Create indexes for fields marked as indexed
        for field_name, field_obj in cls._fields.items():
            if getattr(field_obj, 'indexed', False):
                db_field_name = field_obj.db_field or field_name

                # Check if this is a multi-field index
                index_with = getattr(field_obj, 'index_with', None)
                if index_with and isinstance(index_with, list) and len(index_with) > 0:
                    # Get the actual field names for the index_with fields
                    index_with_fields = []
                    for with_field_name in index_with:
                        if with_field_name in cls._fields:
                            with_field_obj = cls._fields[with_field_name]
                            with_db_field_name = with_field_obj.db_field or with_field_name
                            index_with_fields.append(with_db_field_name)
                        else:
                            # If the field doesn't exist, use the name as is
                            index_with_fields.append(with_field_name)

                    # Generate a unique identifier for this multi-field index
                    # Sort fields to ensure consistent ordering
                    all_fields = sorted([db_field_name] + index_with_fields)
                    index_key = tuple(all_fields)

                    # Skip if we've already processed this combination
                    if index_key in processed_multi_field_indexes:
                        continue

                    # Mark this combination as processed
                    processed_multi_field_indexes.add(index_key)

                    # Generate a default index name
                    index_name = f"{cls._get_collection_name()}_{'_'.join(all_fields)}_idx"

                    # Get index options
                    unique = getattr(field_obj, 'unique', False)
                    search = getattr(field_obj, 'search', False)
                    analyzer = getattr(field_obj, 'analyzer', None)
                    bm25 = getattr(field_obj, 'bm25', False)
                    highlights = getattr(field_obj, 'highlights', False)

                    # Create the multi-field index
                    cls.create_index_sync(
                        index_name=index_name,
                        fields=all_fields,
                        unique=unique,
                        search=search,
                        analyzer=analyzer,
                        bm25=bm25,
                        highlights=highlights,
                        connection=connection
                    )
                else:
                    # Create a single-field index
                    # Skip if we've already processed this field
                    if (db_field_name,) in processed_multi_field_indexes:
                        continue

                    # Mark this field as processed
                    processed_multi_field_indexes.add((db_field_name,))

                    # Generate a default index name
                    index_name = f"{cls._get_collection_name()}_{field_name}_idx"

                    # Get index options
                    unique = getattr(field_obj, 'unique', False)
                    search = getattr(field_obj, 'search', False)
                    analyzer = getattr(field_obj, 'analyzer', None)
                    bm25 = getattr(field_obj, 'bm25', False)
                    highlights = getattr(field_obj, 'highlights', False)

                    # Create the single-field index
                    cls.create_index_sync(
                        index_name=index_name,
                        fields=[db_field_name],
                        unique=unique,
                        search=search,
                        analyzer=analyzer,
                        bm25=bm25,
                        highlights=highlights,
                        connection=connection
                    )

    @classmethod
    def create_events(cls, connection: Optional[Any] = None) -> Union[None, Any]:
        """Create events defined in Meta.events.

        Polyglot method: executes synchronously if the active connection is synchronous,
        otherwise returns an awaitable.

        Args:
            connection: Optional connection to use

        Returns:
            None (or awaitable resolving to None)

        """
        target_connection = connection or get_active_connection(async_mode=None)
        if not target_connection.is_async():
            return cls.create_events_sync(connection=target_connection)
        return cls._create_events_async(connection=target_connection)

    @classmethod
    async def _create_events_async(cls, connection: Optional[Any] = None) -> None:
        """Create events defined in Meta.events asynchronously (internal)."""
        if not hasattr(cls, '_meta') or not cls._meta.get('events'):
            return

        if connection is None:
            connection = get_active_connection(async_mode=True)

        collection_name = cls._get_collection_name()

        for event in cls._meta['events']:
            if hasattr(event, 'to_sql'):
                query = event.to_sql(collection_name)
                await connection.client.query(query)

    @classmethod
    def create_events_sync(cls, connection: Optional[Any] = None) -> None:
        """Create events defined in Meta.events synchronously.
        
        Args:
            connection: Optional connection to use

        """
        if not hasattr(cls, '_meta') or not cls._meta.get('events'):
            return

        if connection is None:
            connection = get_active_connection(async_mode=False)
            
        collection_name = cls._get_collection_name()
        
        for event in cls._meta['events']:
            if hasattr(event, 'to_sql'):
                query = event.to_sql(collection_name)
                connection.client.query(query)

    @classmethod
    def _get_field_type_for_surreal(cls, field: Field) -> str:
        """Get the SurrealDB type for a field.

        Args:
            field: The field to get the type for

        Returns:
            The SurrealDB type as a string

        """
        from .fields import (
            StringField, IntField, FloatField, BooleanField,
            DateTimeField, ListField, DictField, SetField, ReferenceField,
            GeometryField, RelationField, DecimalField, DurationField,
            BytesField, RegexField, OptionField, FutureField,
            UUIDField, TableField, RecordIDField, EmbeddedField
        )
        from .fields.additional import SequenceField as _SequenceField

        # 1. Resolve Base Type
        if isinstance(field, _SequenceField):
            field_type = "int"
        elif isinstance(field, StringField):
            field_type = "string"
        elif isinstance(field, IntField):
            field_type = "int"
        elif isinstance(field, FloatField):
            field_type = "float"
        elif isinstance(field, DecimalField):
            field_type = "decimal"
        elif isinstance(field, BooleanField):
            field_type = "bool"
        elif isinstance(field, DateTimeField):
            field_type = "datetime"
        elif isinstance(field, DurationField):
            field_type = "duration"
        elif isinstance(field, SetField):
            if field.field_type:
                inner_type = cls._get_field_type_for_surreal(field.field_type)
                field_type = f"set<{inner_type}>"
            else:
                field_type = "set"
        elif isinstance(field, ListField):
            if field.field_type:
                inner_type = cls._get_field_type_for_surreal(field.field_type)
                field_type = f"array<{inner_type}>"
            else:
                field_type = "array"
        elif isinstance(field, DictField):
            # Use object FLEXIBLE for DictField in SurrealDB 3.0 if flexible=True
            if getattr(field, 'flexible', True):
                field_type = "object FLEXIBLE"
            else:
                field_type = "object"
        elif isinstance(field, EmbeddedField):
            if getattr(field, 'flexible', False):
                field_type = "object FLEXIBLE"
            else:
                field_type = "object"
        elif isinstance(field, ReferenceField):
            target_cls = field.document_type
            if hasattr(target_cls, '_meta') and target_cls._meta:
                try:
                    target_collection = target_cls._get_collection_name()
                    field_type = f"record<{target_collection}>"
                except Exception:
                    field_type = "record"
            else:
                field_type = "record"
        elif isinstance(field, RelationField):
            target_cls = field.to_document
            if hasattr(target_cls, '_meta') and target_cls._meta:
                try:
                    target_collection = target_cls._get_collection_name()
                    field_type = f"record<{target_collection}>"
                except Exception:
                    field_type = "record"
            else:
                field_type = "record"
        elif isinstance(field, GeometryField):
            field_type = "geometry"
        elif isinstance(field, BytesField):
            field_type = "bytes"
        elif isinstance(field, RegexField):
            field_type = "regex"
        elif isinstance(field, OptionField):
            if field.field_type:
                # Recursively get inner type but DON'T wrap here, we handle it below
                field_type = cls._get_field_type_for_surreal(field.field_type)
            else:
                field_type = "any"
        elif isinstance(field, UUIDField):
            field_type = "uuid"
        elif isinstance(field, TableField):
            field_type = "table"
        elif isinstance(field, RecordIDField):
            target = getattr(field, 'table_name', None)
            field_type = f"record<{target}>" if target else "record"
        elif isinstance(field, FutureField):
            field_type = "any"
        elif hasattr(field, 'get_surreal_type'):
            field_type = field.get_surreal_type()
        else:
            field_type = "any"

        # 2. Apply Option Wrapping
        # Non-required fields should be wrapped in option<> unless already optional or complex/flexible objects
        if not field.required and field_type != "any":
            # Don't double wrap or wrap flexible objects (which are inherently optional)
            if not field_type.startswith("option<") and not field_type.startswith("object"):
                return f"option<{field_type}>"

        return field_type

    @classmethod
    def create_table(cls, connection: Optional[Any] = None, schemafull: bool = True) -> Union[None, Any]:
        """Create the table for this document class.

        Polyglot method: executes synchronously if the active connection is synchronous,
        otherwise returns an awaitable.

        Args:
            connection: Optional connection to use
            schemafull: Whether to create a SCHEMAFULL table (default: True)

        Returns:
            None (or awaitable resolving to None)

        """
        # Get target connection
        connection = connection or get_active_connection(async_mode=None)
        if not connection.is_async():
            return cls.create_table_sync(connection, schemafull)
        return cls._create_table_async(connection, schemafull)

    @classmethod
    async def _create_table_async(cls, connection: Optional[Any] = None, schemafull: bool = True) -> None:
        """Create the table for this document class asynchronously.

        Args:
            connection: Optional connection to use
            schemafull: Whether to create a SCHEMAFULL table (default: True)

        """
        if connection is None:
            connection = ConnectionRegistry.get_default_connection(async_mode=True)

        collection_name = cls._get_collection_name()

        # Create the table — RelationDocument subclasses need TYPE RELATION
        schema_type = "SCHEMAFULL" if schemafull else "SCHEMALESS"
        # Import here to avoid circular import; RelationDocument is defined later in this module
        try:
            is_relation = issubclass(cls, RelationDocument) and cls is not RelationDocument
        except NameError:
            is_relation = cls.__name__ != 'RelationDocument' and any(
                b.__name__ == 'RelationDocument' for b in cls.__mro__
            )
        table_type = "TYPE RELATION " if is_relation else ""
        query = f"DEFINE TABLE {collection_name} {table_type}{schema_type}"

        # Check if this is a time series table
        is_time_series = False
        time_field = None

        # Check if the Meta class has time_series and time_field attributes
        if hasattr(cls, '_meta'):
            is_time_series = cls._meta.get('time_series', False)
            time_field = cls._meta.get('time_field')

        # If time_series is True but time_field is not specified, try to find a TimeSeriesField
        if is_time_series and not time_field:
            for field_name, field in cls._fields.items():
                if field.__class__.__name__ == 'TimeSeriesField':
                    time_field = field.db_field
                    break

        # Add time series configuration if applicable
        if is_time_series and time_field:
            query += f" TYPE TIMESTAMP TIMEFIELD {time_field}"

        # Add comment if available
        if hasattr(cls, '__doc__') and cls.__doc__:
            # Collapse newlines/extra spaces, escape backslash and double-quote for SurrealDB
            doc = ' '.join(cls.__doc__.strip().split())
            doc = doc.replace('\\', '\\\\').replace('"', '\\"')
            if doc:
                query += f' COMMENT "{doc}"'

        await connection.client.query(query)

        # Emit DEFINE SEQUENCE if configured in Meta
        seq_name = cls._meta.get('sequence') if hasattr(cls, '_meta') else None
        if seq_name:
            seq_start = cls._meta.get('sequence_start', 1)
            seq_batch = cls._meta.get('sequence_batch', 1)
            seq_query = (
                f"DEFINE SEQUENCE IF NOT EXISTS {seq_name} "
                f"BATCH {seq_batch} START {seq_start}"
            )
            await connection.client.query(seq_query)

        # Emit DEFINE SEQUENCE for any SequenceField on this model
        from .fields.additional import SequenceField as _SequenceField
        for _fname, _field in cls._fields.items():
            if isinstance(_field, _SequenceField):
                _sq = (
                    f"DEFINE SEQUENCE IF NOT EXISTS {_field.sequence} "
                    f"BATCH {_field.batch} START {_field.start}"
                )
                await connection.client.query(_sq)

        for field_name, field in cls._fields.items():
            # Skip id field as it's handled by SurrealDB
            if field_name == cls._meta.get('id_field', 'id'):
                continue

            # Only define fields if schemafull or if field is explicitly marked for schema definition
            if schemafull or field.define_schema:

                # 1. Base Statement
                field_type = cls._get_field_type_for_surreal(field)
                
                # SurrealDB 3.0 syntax for Fields:
                # DEFINE FIELD name ON table [TYPE type] [COMPUTED expr] ...
                # Note: TYPE keyword is usually required even for specialized object types.
                # If it's a computed field, TYPE clause is optional but allowed.
                field_query = f"DEFINE FIELD {field.db_field} ON {collection_name} TYPE {field_type}"

                if getattr(field, 'computation_expression', None):
                    # For computed fields, the pattern is usually TYPE any COMPUTED ... OR just omit TYPE if any.
                    # Based on user feedback, TYPE [any] COMPUTED ... is the safest order.
                    field_query += f" COMPUTED {field.computation_expression}"
                # Sets Deduplication
                if getattr(field, '_is_set', False):
                    field_query += " VALUE $value.distinct()"
                # Reference
                elif getattr(field, 'reference', False):
                    field_query += " REFERENCE"
                # Default value
                elif field.default is not None and not callable(field.default):
                    def _literal(val):
                        if isinstance(val, str):
                            s = val.replace('\\', r'\\').replace('"', r'\"')
                            return f'"{s}"'
                        if isinstance(val, bool):
                            return 'true' if val else 'false'
                        return str(val)
                    field_query += f" DEFAULT {_literal(field.default)}"

                # Field comment
                if getattr(field, 'comment', None):
                    c = field.comment.replace('\\', r'\\').replace('"', r'\"')
                    # SurrealQL docs: field COMMENT supports string literal; we use double quotes safely
                    field_query += f" COMMENT \"{c}\""

                await connection.client.query(field_query)

                # Handle Embedded fields
                try:
                    from .fields.embedded import EmbeddedField
                except ImportError:
                    EmbeddedField = None

                if EmbeddedField and isinstance(field, EmbeddedField) and schemafull:
                    await cls._define_embedded_fields(connection, collection_name, field.db_field or field_name, field.document_type)

        # Create indexes
        await cls.create_indexes(connection)
        
        # Create events
        await cls.create_events(connection)

    @classmethod
    async def _define_embedded_fields(cls, connection, collection_name: str, parent_path: str, doc_cls: Type):
        """Recursively define schema for embedded fields."""
        for name, field in doc_cls._fields.items():
            db_field = field.db_field or name
            full_path = f"{parent_path}.{db_field}"
            
            # types
            surreal_type = cls._get_field_type_for_surreal(field)
            
            # Construct query
            query = f"DEFINE FIELD {full_path} ON {collection_name} TYPE {surreal_type}"
            
            # Constraints
            exprs = []
            if field.required:
                exprs.append("$value != NONE")
                
            # Add type-specific constraints (simplified version of main loop)
            # We can refactor to share logic later, for now adding key constraints
            
            try:
                from .fields.scalar import StringField, NumberField
            except Exception:
                StringField = NumberField = None

            if StringField and isinstance(field, StringField):
                if getattr(field, 'min_length', None) is not None:
                    exprs.append(f"string::len($value) >= {int(field.min_length)}")
                if getattr(field, 'max_length', None) is not None:
                     exprs.append(f"string::len($value) <= {int(field.max_length)}")
                if getattr(field, 'choices', None):
                     vals = []
                     for v in field.choices:
                         if isinstance(v, str):
                             s = v.replace('\\', r'\\').replace('"', r'\"')
                             vals.append(f'"{s}"')
                         else:
                             vals.append(str(v).lower() if isinstance(v, bool) else str(v))
                     exprs.append(f"$value IN [{', '.join(vals)}]")

            if exprs:
                query += " ASSERT " + " AND ".join(exprs)
                
            await connection.client.query(query)
            
            # Recurse
            try:
                from .fields.embedded import EmbeddedField
            except ImportError:
                EmbeddedField = None
                
            if EmbeddedField and isinstance(field, EmbeddedField):
                await cls._define_embedded_fields(connection, collection_name, full_path, field.document_type)



    @classmethod
    def create_table_sync(cls, connection: Optional[Any] = None, schemafull: bool = True) -> None:
        """Create the table for this document class synchronously."""
        if connection is None:
            from .connection import ConnectionRegistry
            connection = ConnectionRegistry.get_default_connection(async_mode=False)

        collection_name = cls._get_collection_name()

        # Create the table — RelationDocument subclasses need TYPE RELATION
        schema_type = "SCHEMAFULL" if schemafull else "SCHEMALESS"
        try:
            is_relation = issubclass(cls, RelationDocument) and cls is not RelationDocument
        except NameError:
            is_relation = cls.__name__ != 'RelationDocument' and any(
                b.__name__ == 'RelationDocument' for b in cls.__mro__
            )
        table_type = "TYPE RELATION " if is_relation else ""
        query = f"DEFINE TABLE {collection_name} {table_type}{schema_type}"

        # Check if this is a time series table
        is_time_series = False
        time_field = None

        # Check if the Meta class has time_series and time_field attributes
        if hasattr(cls, '_meta'):
            is_time_series = cls._meta.get('time_series', False)
            time_field = cls._meta.get('time_field')

        # If time_series is True but time_field is not specified, try to find a TimeSeriesField
        if is_time_series and not time_field:
            for field_name, field in cls._fields.items():
                if field.__class__.__name__ == 'TimeSeriesField':
                    time_field = field.db_field
                    break

        # Add time series configuration if applicable
        if is_time_series and time_field:
            query += f" TYPE TIMESTAMP TIMEFIELD {time_field}"

        # Add comment if available
        if hasattr(cls, '__doc__') and cls.__doc__:
            # Collapse newlines/extra spaces, escape backslash and double-quote for SurrealDB
            doc = ' '.join(cls.__doc__.strip().split())
            doc = doc.replace('\\', '\\\\').replace('"', '\\"')
            if doc:
                query += f' COMMENT "{doc}"'
        connection.client.query(query)

        # Emit DEFINE SEQUENCE if configured in Meta
        seq_name = cls._meta.get('sequence') if hasattr(cls, '_meta') else None
        if seq_name:
            seq_start = cls._meta.get('sequence_start', 1)
            seq_batch = cls._meta.get('sequence_batch', 1)
            seq_query = (
                f"DEFINE SEQUENCE IF NOT EXISTS {seq_name} "
                f"BATCH {seq_batch} START {seq_start}"
            )
            connection.client.query(seq_query)

        # Emit DEFINE SEQUENCE for any SequenceField on this model
        from .fields.additional import SequenceField as _SequenceField
        for _fname, _field in cls._fields.items():
            if isinstance(_field, _SequenceField):
                _sq = (
                    f"DEFINE SEQUENCE IF NOT EXISTS {_field.sequence} "
                    f"BATCH {_field.batch} START {_field.start}"
                )
                connection.client.query(_sq)

        # Create fields if schemafull or if field is marked with define_schema=True
        for field_name, field in cls._fields.items():
            # Skip id field as it's handled by SurrealDB
            if field_name == cls._meta.get('id_field', 'id'):
                continue

            # Only define fields if schemafull or if field is explicitly marked for schema definition
            if schemafull or field.define_schema:
                # 1. Base Statement
                field_type = cls._get_field_type_for_surreal(field)

                field_query = f"DEFINE FIELD {field.db_field} ON {collection_name} TYPE {field_type}"

                if getattr(field, 'computation_expression', None):
                    field_query += f" COMPUTED {field.computation_expression}"

                # Build constraints
                exprs = []
                if field.required:
                    exprs.append("$value != NONE")
                try:
                    from .fields.scalar import StringField, NumberField
                    from .fields.specialized import ChoiceField
                except Exception:
                    StringField = NumberField = ChoiceField = None  # type: ignore

                # StringField constraints
                if StringField and isinstance(field, StringField):
                    if getattr(field, 'min_length', None) is not None:
                        exprs.append(f"string::len($value) >= {int(field.min_length)}")
                    if getattr(field, 'max_length', None) is not None:
                        exprs.append(f"string::len($value) <= {int(field.max_length)}")
                    if getattr(field, 'regex_pattern', None):
                        from .surrealql import escape_literal
                        pattern = field.regex_pattern
                        exprs.append(f"string::matches($value, {escape_literal(pattern)})")
                    if getattr(field, 'choices', None):
                        vals = []
                        for v in field.choices:
                            if isinstance(v, str):
                                s = v.replace('\\', r'\\').replace('"', r'\"')
                                vals.append(f'"{s}"')
                            else:
                                vals.append(str(v).lower() if isinstance(v, bool) else str(v))
                        exprs.append(f"$value IN [{', '.join(vals)}]")

                # Number constraints (NumberField and subclasses)
                if NumberField and isinstance(field, NumberField):
                    if getattr(field, 'min_value', None) is not None:
                        exprs.append(f"$value >= {field.min_value}")
                    if getattr(field, 'max_value', None) is not None:
                        exprs.append(f"$value <= {field.max_value}")

                # ChoiceField constraints
                if ChoiceField and isinstance(field, ChoiceField):
                    vals = []
                    for v in field.values:
                        if isinstance(v, str):
                            s = v.replace('\\', r'\\').replace('"', r'\"')
                            vals.append(f'"{s}"')
                        else:
                            vals.append(str(v).lower() if isinstance(v, bool) else str(v))
                    exprs.append(f"$value IN [{', '.join(vals)}]")

                if exprs:
                    field_query += " ASSERT " + " AND ".join(exprs)

                # Computed / Incoming Reference
                if getattr(field, 'computation_expression', None):
                    field_query += f" COMPUTED {field.computation_expression}"
                # Sets Deduplication
                if getattr(field, '_is_set', False):
                    field_query += " VALUE $value.distinct()"
                # Reference
                elif getattr(field, 'reference', False):
                    field_query += " REFERENCE"
                # Default value
                elif field.default is not None and not callable(field.default):
                    def _literal(val):
                        if isinstance(val, str):
                            s = val.replace('\\', r'\\').replace('"', r'\"')
                            return f'"{s}"'
                        if isinstance(val, bool):
                            return 'true' if val else 'false'
                        return str(val)
                    field_query += f" DEFAULT {_literal(field.default)}"

                # Field comment
                if getattr(field, 'comment', None):
                    c = field.comment.replace('\\', r'\\').replace('"', r'\"')
                    field_query += f" COMMENT \"{c}\""

                connection.client.query(field_query)

                # Handle nested fields for DictField with explicit schema
                if isinstance(field, DictField) and schemafull and field.schema:
                    for sub_key, sub_field in field.schema.items():
                        sub_field_type = cls._get_field_type_for_surreal(sub_field)
                        nested_field_query = f"DEFINE FIELD {field.db_field}.{sub_key} ON {collection_name} TYPE {sub_field_type}"
                        connection.client.query(nested_field_query)

        # Create indexes
        cls.create_indexes_sync(connection)
        
        # Create events
        cls.create_events_sync(connection)

    @classmethod
    def to_dataclass(cls):
        """Convert the document class to a dataclass.

        This method creates a dataclass based on the document's fields.
        It uses the field names, types, and whether they are required.
        Required fields have no default value, making them required during initialization.
        Non-required fields use None as default if they don't define one.
        A __post_init__ method is added to validate all fields after initialization.

        Returns:
            A dataclass type based on the document's fields

        """
        fields = [('id', Optional[str], dataclass_field(default=None))]
        # Process fields
        for field_name, field_obj in cls._fields.items():
            # Skip id field as it's handled separately
            if field_name == cls._meta.get('id_field', 'id'):
                continue
            # For required fields, don't provide a default value
            if field_obj.required:
                fields.insert(0, (field_name, field_obj.py_type))
            # For fields with a non-callable default, use that default
            elif field_obj.default is not None and not callable(field_obj.default):
                fields.append((field_name, field_obj.py_type, dataclass_field(default=field_obj.default)))
            # For other fields, use None as default
            else:
                fields.append((field_name, field_obj.py_type, dataclass_field(default=None)))

        # Define the __post_init__ method to validate fields
        def post_init(self):
            """Validate all fields after initialization."""
            for field_name, field_obj in cls._fields.items():
                value = getattr(self, field_name, None)
                field_obj.validate(value)

        # Create the dataclass using make_dataclass
        return make_dataclass(
            cls_name=f"{cls.__name__}_Dataclass",
            fields=fields,
            namespace={"__post_init__": post_init}
        )

    @classmethod
    def create_materialized_view(cls, name: str, query: QuerySet, refresh_interval: str = None, 
                                 aggregations=None, select_fields=None, **kwargs):
        """Create a materialized view based on a query.

        This method creates a materialized view in SurrealDB based on a query.
        Materialized views are precomputed views of data that can be used to
        improve query performance for frequently accessed aggregated data.

        Args:
            name: The name of the materialized view
            query: The query that defines the materialized view
            refresh_interval: The interval at which the view is refreshed (e.g., "1h", "30m")
            aggregations: Dictionary of field names and aggregation functions
            select_fields: List of fields to select (if None, selects all fields)
            **kwargs: Additional keyword arguments to pass to the MaterializedView constructor

        Returns:
            A MaterializedView instance

        """
        from .materialized_view import Count, Mean, Sum, Min, Max, ArrayCollect

        # Process aggregations if provided as keyword arguments
        if aggregations is None:
            aggregations = {}

        # Check for aggregation functions in kwargs
        for key, value in kwargs.items():
            if key.startswith('count_'):
                field_name = key[6:]  # Remove 'count_' prefix
                aggregations[field_name] = Count()
            elif key.startswith('mean_'):
                field_name = key[5:]  # Remove 'mean_' prefix
                field = kwargs.get(key)
                aggregations[field_name] = Mean(field)
            elif key.startswith('sum_'):
                field_name = key[4:]  # Remove 'sum_' prefix
                field = kwargs.get(key)
                aggregations[field_name] = Sum(field)
            elif key.startswith('min_'):
                field_name = key[4:]  # Remove 'min_' prefix
                field = kwargs.get(key)
                aggregations[field_name] = Min(field)
            elif key.startswith('max_'):
                field_name = key[4:]  # Remove 'max_' prefix
                field = kwargs.get(key)
                aggregations[field_name] = Max(field)
            elif key.startswith('collect_'):
                field_name = key[8:]  # Remove 'collect_' prefix
                field = kwargs.get(key)
                aggregations[field_name] = ArrayCollect(field)

        return MaterializedView(name, query, refresh_interval, cls, aggregations, select_fields)

    @classmethod
    def _get_document_class_for_collection(cls, collection_name: str) -> Optional[Type['Document']]:
        """Get the document class for a collection name.

        This method looks up the document class for a given collection name
        in the document registry. If no class is found, it returns None.

        Args:
            collection_name: The name of the collection

        Returns:
            The document class for the collection, or None if not found

        """
        # Initialize the document registry if it doesn't exist
        if not hasattr(cls, '_document_registry'):
            cls._document_registry = {}

            # Populate the registry with all existing document classes
            def register_subclasses(doc_class):
                for subclass in doc_class.__subclasses__():
                    if hasattr(subclass, '_meta') and not subclass._meta.get('abstract', False):
                        collection = subclass._meta.get('collection')
                        if collection:
                            cls._document_registry[collection] = subclass
                    register_subclasses(subclass)

            # Start with Document subclasses
            register_subclasses(cls)

        # Handle RecordID objects
        if isinstance(collection_name, RecordID):
            collection_name = collection_name.table_name

        # Handle string IDs in the format "collection:id"
        elif isinstance(collection_name, str) and ':' in collection_name:
            collection_name = collection_name.split(':', 1)[0]

        # Look up the document class in the registry
        return cls._document_registry.get(collection_name)

# Fix for Document.id field: The metaclass skips processing the base Document class,
# so the id field doesn't get its name/db_field set. We set them manually here.
if hasattr(Document, 'id') and hasattr(Document.id, 'name'):
    Document.id.name = 'id'
    Document.id.db_field = 'id'

class RelationDocument(Document):
    """A Document that represents a relationship between two documents.

    RelationDocuments should be used to model relationships with additional attributes.
    They can be used with Document.relates(), Document.fetch_relation(), and Document.resolve_relation().
    """

    class Meta:
        """Meta options for RelationDocument."""

        abstract = True

    in_document = ReferenceField(Document, required=True, db_field="in")
    out_document = ReferenceField(Document, required=True, db_field="out")

    def save(self, connection: Optional[Any] = None) -> Union['RelationDocument', Any]:
        """Save the relation document.
        
        Polyglot method: executes synchronously if the active connection is synchronous,
        otherwise returns an awaitable.

        This overrides the default Document.save() to use RELATE statement
        which is required for proper graph edge creation.
        """
        # Get the connection (implicit context or default async)
        connection = connection or get_active_connection(async_mode=None)

        if not connection.is_async():
            return self.save_sync(connection)

        async def _save_async(conn):
            # Trigger pre_save
            if SIGNAL_SUPPORT:
                pre_save.send(self.__class__, document=self)

            self.validate()
            
            # If we have an ID and no changes, return self
            if self.id and not self._changed_fields:
                return self
                
            # If updating existing relation (has ID)
            if self.id:
                # For updates, we can verify if it's a simple update or if in/out changed
                # But SurrealDB relations are edges - modifying in/out usually implies a new edge
                # For now, fallback to super().save() for updates as generic UPDATE works for content
                return await super(RelationDocument, self).save(conn)

            # Creating new relation
            if not self.in_document or not self.out_document:
                raise ValueError("RelationDocument must have both in_document and out_document set")

            # Prepare attributes (exclude in/out/id)
            attrs = {}
            for field_name, field in self._fields.items():
                if field_name in ['in_document', 'out_document', 'id']:
                    continue
                val = getattr(self, field_name)
                if val is not None:
                    attrs[field_name] = val
                    
            # Use existing create_relation logic
            # We can't use create_relation directly because it creates a new instance
            # We want to update THIS instance
            
            # Get relation name
            relation_name = self.get_relation_name()
            
            # We need to construct the RELATE query manually or use RelationQuerySet
            # Let's use RelationQuerySet to match create_relation behavior
            from .query.relation import RelationQuerySet
            qs = RelationQuerySet(self.in_document.__class__, conn, relation=relation_name)
            
            # create_relation logic uses .relate() which returns the record dict
            record = await qs.relate(self.in_document, self.out_document, **attrs)
            
            if record:
                self._data.update(record)
                if 'id' in record:
                    self._data['id'] = record['id']
                # Re-hydrate fields
                for field_name, field in self._fields.items():
                    if field.db_field in record:
                        self._data[field_name] = field.from_db(record[field.db_field])
            
            # Trigger post_save
            if SIGNAL_SUPPORT:
                post_save.send(self.__class__, document=self, created=True)
                
            self.mark_clean()
            return self

        return _save_async(connection)

    def save_sync(self, connection: Optional[Any] = None) -> 'RelationDocument':
        """Save the relation document synchronously.
        
        This overrides the default Document.save_sync() to use RELATE statement.
        """
        if SIGNAL_SUPPORT:
            pre_save.send(self.__class__, document=self)

        if connection is None:
            connection = ConnectionRegistry.get_default_connection(async_mode=False)
            
        self.validate()
        
        if self.id and not self._changed_fields:
            return self
            
        if self.id:
            return super().save_sync(connection)

        if not self.in_document or not self.out_document:
            raise ValueError("RelationDocument must have both in_document and out_document set")

        attrs = {}
        for field_name, field in self._fields.items():
            if field_name in ['in_document', 'out_document', 'id']:
                continue
            val = getattr(self, field_name)
            if val is not None:
                attrs[field_name] = val
                
        relation_name = self.get_relation_name()
        from .query.relation import RelationQuerySet
        qs = RelationQuerySet(self.in_document.__class__, connection, relation=relation_name)
        
        record = qs.relate_sync(self.in_document, self.out_document, **attrs)
        
        if record:
            self._data.update(record)
            if 'id' in record:
                self._data['id'] = record['id']
            for field_name, field in self._fields.items():
                if field.db_field in record:
                    self._data[field_name] = field.from_db(record[field.db_field])
        
        if SIGNAL_SUPPORT:
            post_save.send(self.__class__, document=self, created=True)
            
        self.mark_clean()
        return self

    @classmethod
    def get_relation_name(cls) -> str:
        """Get the name of the relation.

        By default, this is the lowercase name of the class.
        Override this method to customize the relation name.

        Returns:
            The name of the relation

        """
        return cls._meta.get('collection')

    @classmethod
    def relates(cls, from_document: Optional[Type] = None, to_document: Optional[Type] = None) -> callable:
        """Get a RelationQuerySet for this relation.

        This method returns a function that creates a RelationQuerySet for
        this relation. The function can be called with an optional connection parameter.

        Args:
            from_document: The document class the relation is from (optional)
            to_document: The document class the relation is to (optional)

        Returns:
            Function that creates a RelationQuerySet

        """
        relation_name = cls.get_relation_name()

        def relation_query_builder(connection: Optional[Any] = None) -> 'RelationQuerySet':
            """Create a RelationQuerySet for this relation.

            Args:
                connection: The database connection to use (optional)

            Returns:
                A RelationQuerySet for the relation

            """
            if connection is None:
                connection = ConnectionRegistry.get_default_connection()
            return RelationQuerySet(from_document or Document, connection, relation=relation_name)

        return relation_query_builder

    @classmethod
    def create_relation(cls, from_instance: Any, to_instance: Any, **attrs: Any) -> Union['RelationDocument', Any]:
        """Create a relation between two instances.

        Polyglot method: executes synchronously if the active connection is synchronous,
        otherwise returns an awaitable.

        Args:
            from_instance: The instance to create the relation from
            to_instance: The instance to create the relation to
            **attrs: Attributes to set on the relation

        Returns:
            A RelationDocument instance representing the relationship (or awaitable resolving to it)

        Raises:
            ValueError: If either instance is not saved

        """
        connection = get_active_connection(async_mode=None)
        if not connection.is_async():
            return cls.create_relation_sync(from_instance, to_instance, **attrs)
        return cls._create_relation_async(from_instance, to_instance, **attrs)

    @classmethod
    async def _create_relation_async(cls, from_instance: Any, to_instance: Any, **attrs: Any) -> 'RelationDocument':
        """Create a relation between two instances asynchronously (internal).

        Args:
            from_instance: The instance to create the relation from
            to_instance: The instance to create the relation to
            **attrs: Attributes to set on the relation

        Returns:
            A RelationDocument instance representing the relationship

        Raises:
            ValueError: If either instance is not saved

        """
        if not from_instance.id:
            raise ValueError(f"Cannot create relation from unsaved {from_instance.__class__.__name__}")

        if not to_instance.id:
            raise ValueError(f"Cannot create relation to unsaved {to_instance.__class__.__name__}")

        # Create the relation using Document.relate_to
        relation = await from_instance.relate_to(cls.get_relation_name(), to_instance, **attrs)

        # Create a RelationDocument instance from the relation data
        relation_doc = cls(
            in_document=from_instance,
            out_document=to_instance,
            **attrs
        )

        # Set the ID from the relation
        if relation and 'id' in relation:
            from surrealdb import RecordID
            if isinstance(relation['id'], RecordID):
                relation_doc.id = f"{relation['id'].table_name}:{relation['id'].id}"
            else:
                relation_doc.id = relation['id']

        return relation_doc

    @classmethod
    def create_relation_sync(cls, from_instance: Any, to_instance: Any, **attrs: Any) -> 'RelationDocument':
        """Create a relation between two instances synchronously.

        This method creates a relation between two document instances and
        returns a RelationDocument instance representing the relationship.

        Args:
            from_instance: The instance to create the relation from
            to_instance: The instance to create the relation to
            **attrs: Attributes to set on the relation

        Returns:
            A RelationDocument instance representing the relationship

        Raises:
            ValueError: If either instance is not saved

        """
        if not from_instance.id:
            raise ValueError(f"Cannot create relation from unsaved {from_instance.__class__.__name__}")

        if not to_instance.id:
            raise ValueError(f"Cannot create relation to unsaved {to_instance.__class__.__name__}")

        # Create the relation using Document.relate_to_sync
        relation = from_instance.relate_to_sync(cls.get_relation_name(), to_instance, **attrs)

        # Create a RelationDocument instance from the relation data
        relation_doc = cls(
            in_document=from_instance,
            out_document=to_instance,
            **attrs
        )

        # Set the ID from the relation
        if relation and 'id' in relation:
            from surrealdb import RecordID
            if isinstance(relation['id'], RecordID):
                relation_doc.id = f"{relation['id'].table_name}:{relation['id'].id}"
            else:
                relation_doc.id = relation['id']

        return relation_doc

    @classmethod
    def bulk_relate(
        cls,
        edges: list,
        connection: Optional[Any] = None,
    ) -> Union[list, Any]:
        """Create multiple relation edges in a single DB round-trip.

        Polyglot method: executes synchronously if the active connection is synchronous,
        otherwise returns an awaitable.

        Uses ``INSERT RELATION INTO`` which is significantly faster than calling
        ``create_relation()`` N times when creating many edges at once.

        Args:
            edges: A list of dicts, each with at least ``"in"`` and ``"out"`` keys.
                   Values may be document instances (must be saved) or RecordID / id-string.
                   Additional keys become edge attributes.

                   Example::

                       # async context
                       await Follows.bulk_relate([
                           {"in": alice, "out": bob,  "since_year": 2020},
                           {"in": bob,   "out": dave, "since_year": 2021},
                       ])

                       # sync context (same call)
                       Follows.bulk_relate([...])

            connection: Optional explicit connection.

        Returns:
            List of ``RelationDocument`` instances with ``.id`` populated (or awaitable).

        Raises:
            ValueError: If an edge is missing ``"in"`` or ``"out"``, or references an
                        unsaved document instance.
        """
        target_connection = connection or get_active_connection(async_mode=None)
        if not target_connection.is_async():
            return cls.bulk_relate_sync(edges, connection=target_connection)
        return cls._bulk_relate_async(edges, connection=target_connection)

    @classmethod
    async def _bulk_relate_async(
        cls,
        edges: list,
        connection: Optional[Any] = None,
    ) -> list:
        """Create multiple relation edges asynchronously (internal).

        Args:
            edges: A list of dicts, each with at least ``"in"`` and ``"out"`` keys.
            connection: Optional explicit connection.

        Returns:
            List of ``RelationDocument`` instances with ``.id`` populated.
        """
        if connection is None:
            connection = ConnectionRegistry.get_default_connection(async_mode=True)

        table = cls.get_relation_name()
        from surrealdb import RecordID as _RID

        def _to_id(val: Any) -> str:
            """Resolve a document, RecordID, or id-string to a SurrealQL RecordID token."""
            if hasattr(val, '_data') and not isinstance(val, _RID):
                _id = val._data.get('id')
                if not _id:
                    raise ValueError(
                        f"Cannot bulk_relate: {val.__class__.__name__} instance is not saved (id is None)"
                    )
                return str(_id)
            if isinstance(val, _RID):
                table = getattr(val, 'table', getattr(val, 'table_name', None))
                rid_id = getattr(val, 'id', getattr(val, 'record_id', None))
                return f"{table}:{rid_id}"
            return str(val)

        def _val_to_sql(v: Any) -> str:
            """Serialise a scalar value to an inline SurrealQL literal."""
            if isinstance(v, bool):
                return "true" if v else "false"
            if isinstance(v, (int, float)):
                return str(v)
            if v is None:
                return "NONE"
            if isinstance(v, _RID):
                table = getattr(v, 'table', getattr(v, 'table_name', None))
                rid_id = getattr(v, 'id', getattr(v, 'record_id', None))
                return f"{table}:{rid_id}"
            # Strings and anything else: quote and escape
            escaped = str(v).replace("\\", "\\\\").replace('"', '\\"')
            return f'"{escaped}"'

        if not edges:
            return []

        rows_sql = []
        for i, edge in enumerate(edges):
            if not isinstance(edge, dict):
                raise ValueError(f"Edge at index {i} must be a dict, got {type(edge)}")
            if 'in' not in edge or 'out' not in edge:
                raise ValueError(f"Edge at index {i} must have 'in' and 'out' keys")

            in_id  = _to_id(edge['in'])
            out_id = _to_id(edge['out'])

            # Build the extra fields portion
            extras = {}
            for k, v in edge.items():
                if k in ('in', 'out'):
                    continue
                # Serialise through model descriptor if available
                field = cls._fields.get(k)
                if field is not None:
                    try:
                        v = field.to_db(v)
                    except Exception:
                        pass
                extras[k] = v

            extra_pairs = ", ".join(
                f"{k}: {_val_to_sql(v)}" for k, v in extras.items()
            )
            if extra_pairs:
                rows_sql.append(f"{{in: {in_id}, out: {out_id}, {extra_pairs}}}")
            else:
                rows_sql.append(f"{{in: {in_id}, out: {out_id}}}")

        sql = f"INSERT RELATION INTO {table} [{', '.join(rows_sql)}]"
        raw = await connection.client.query(sql)

        results = []
        if raw and isinstance(raw, list):
            for item in raw:
                if isinstance(item, dict) and 'id' in item:
                    doc = cls.from_db(item)
                else:
                    doc = cls()
                    doc._data['id'] = str(item) if item else None
                results.append(doc)
        elif isinstance(raw, dict) and 'id' in raw:
            # Single-record result (one edge)
            results.append(cls.from_db(raw))
        return results

    @classmethod
    def bulk_relate_sync(
        cls,
        edges: list,
        connection: Optional[Any] = None,
    ) -> list:
        """Synchronous version of :meth:`bulk_relate`.

        Create multiple relation edges in a single ``INSERT RELATION INTO`` round-trip.

        Args:
            edges: See :meth:`bulk_relate` for edge format.
            connection: Optional explicit sync connection.

        Returns:
            List of ``RelationDocument`` instances with ``.id`` populated.
        """
        if connection is None:
            connection = ConnectionRegistry.get_default_connection(async_mode=False)

        table = cls.get_relation_name()
        from surrealdb import RecordID as _RID

        def _to_id(val: Any) -> str:
            if hasattr(val, '_data') and not isinstance(val, _RID):
                _id = val._data.get('id')
                if not _id:
                    raise ValueError(
                        f"Cannot bulk_relate_sync: {val.__class__.__name__} instance is not saved"
                    )
                return str(_id)
            if isinstance(val, _RID):
                table = getattr(val, 'table', getattr(val, 'table_name', None))
                rid_id = getattr(val, 'id', getattr(val, 'record_id', None))
                return f"{table}:{rid_id}"
            return str(val)

        def _val_to_sql(v: Any) -> str:
            if isinstance(v, bool):
                return "true" if v else "false"
            if isinstance(v, (int, float)):
                return str(v)
            if v is None:
                return "NONE"
            if isinstance(v, _RID):
                table = getattr(v, 'table', getattr(v, 'table_name', None))
                rid_id = getattr(v, 'id', getattr(v, 'record_id', None))
                return f"{table}:{rid_id}"
            escaped = str(v).replace("\\", "\\\\").replace('"', '\\"')
            return f'"{escaped}"'

        if not edges:
            return []

        rows_sql = []
        for i, edge in enumerate(edges):
            if not isinstance(edge, dict):
                raise ValueError(f"Edge at index {i} must be a dict, got {type(edge)}")
            if 'in' not in edge or 'out' not in edge:
                raise ValueError(f"Edge at index {i} must have 'in' and 'out' keys")

            in_id  = _to_id(edge['in'])
            out_id = _to_id(edge['out'])

            extras = {}
            for k, v in edge.items():
                if k in ('in', 'out'):
                    continue
                field = cls._fields.get(k)
                if field is not None:
                    try:
                        v = field.to_db(v)
                    except Exception:
                        pass
                extras[k] = v

            extra_pairs = ", ".join(
                f"{k}: {_val_to_sql(v)}" for k, v in extras.items()
            )
            if extra_pairs:
                rows_sql.append(f"{{in: {in_id}, out: {out_id}, {extra_pairs}}}")
            else:
                rows_sql.append(f"{{in: {in_id}, out: {out_id}}}")

        sql = f"INSERT RELATION INTO {table} [{', '.join(rows_sql)}]"
        raw = connection.client.query(sql)

        results = []
        if raw and isinstance(raw, list):
            for item in raw:
                if isinstance(item, dict) and 'id' in item:
                    doc = cls.from_db(item)
                else:
                    doc = cls()
                    doc._data['id'] = str(item) if item else None
                results.append(doc)
        elif isinstance(raw, dict) and 'id' in raw:
            results.append(cls.from_db(raw))
        return results


    @classmethod
    def find_by_in_document(cls, in_doc, **additional_filters):
        """Query RelationDocument by in_document field.

        Polyglot method: returns a QuerySet backed by the active connection, whether
        sync or async.  Chain ``.all()`` / ``.get()`` etc. on the returned QuerySet
        to execute the query.

        Args:
            in_doc: The document instance or ID to filter by
            **additional_filters: Additional filters to apply

        Returns:
            QuerySet filtered by in_document

        """
        connection = get_active_connection(async_mode=None)
        if connection is None or not connection.is_async():
            return cls.find_by_in_document_sync(in_doc, **additional_filters)
        queryset = QuerySet(cls, connection)
        # Normalize in_doc to a plain ID value
        if isinstance(in_doc, Document):
            in_doc = in_doc.id
        elif isinstance(in_doc, RecordID):
            in_doc = str(in_doc)
        elif isinstance(in_doc, dict) and in_doc.get('id'):
            in_doc = in_doc['id']
        filters = {'in': in_doc, **additional_filters}
        return queryset.filter(**filters)

    @classmethod
    def find_by_in_document_sync(cls, in_doc, **additional_filters):
        """Query RelationDocument by in_document field synchronously.

        Args:
            in_doc: The document instance or ID to filter by
            **additional_filters: Additional filters to apply

        Returns:
            QuerySet filtered by in_document

        """
        connection = ConnectionRegistry.get_default_connection(async_mode=False)
        queryset = QuerySet(cls, connection)
        # Normalize in_doc to a plain ID value
        if isinstance(in_doc, Document):
            in_doc = in_doc.id
        elif isinstance(in_doc, RecordID):
            in_doc = str(in_doc)
        elif isinstance(in_doc, dict) and in_doc.get('id'):
            in_doc = in_doc['id']
        filters = {'in': in_doc, **additional_filters}
        return queryset.filter(**filters)

    @classmethod
    def find_by_in_documents(cls, in_docs, **additional_filters):
        """Query RelationDocument where the `in` reference is any of the provided records (polyglot).

        Polyglot method: executes synchronously if the active connection is synchronous,
        otherwise returns an awaitable.

        Args:
            in_docs: Iterable of items; each item may be a Document instance, RecordID, 'table:id' string, or dict with 'id'.
            **additional_filters: Any additional filters to apply to the query.

        Returns:
            QuerySet filtered by in__in (or awaitable)

        """
        # Get the active connection (will try async first if available)
        connection = get_active_connection(async_mode=None)
        
        if connection is None:
            # Fallback if no context connection
            try:
                connection = ConnectionRegistry.get_default_async_connection()
            except RuntimeError:
                connection = ConnectionRegistry.get_default_sync_connection()
        
        if not connection.is_async():
            return cls.find_by_in_documents_sync(in_docs, **additional_filters)
            
        queryset = QuerySet(cls, connection)

        def _norm(v):
            if isinstance(v, Document):
                return v.id
            if isinstance(v, RecordID):
                return str(v)
            if isinstance(v, dict) and v.get('id'):
                return v['id']
            return v

        in_ids = [ _norm(v) for v in in_docs if v ]
        filters = { 'in__in': in_ids, **additional_filters }
        return queryset.filter(**filters)

    @classmethod
    def find_by_in_documents_sync(cls, in_docs, **additional_filters):
        """Synchronous version of find_by_in_documents.

        Args:
            in_docs: Iterable of items; each item may be a Document instance, RecordID, 'table:id' string, or dict with 'id'.
            **additional_filters: Any additional filters to apply to the query.

        Returns:
            QuerySet filtered by in__in

        """
        # Get the default sync connection
        connection = ConnectionRegistry.get_default_connection(async_mode=False)
        queryset = QuerySet(cls, connection)

        def _norm(v):
            if isinstance(v, Document):
                return v.id
            if isinstance(v, RecordID):
                return str(v)
            if isinstance(v, dict) and v.get('id'):
                return v['id']
            return v

        in_ids = [ _norm(v) for v in in_docs if v ]
        filters = { 'in__in': in_ids, **additional_filters }
        return queryset.filter(**filters)

    def resolve_out(self, connection=None):
        """Resolve the out_document field.

        Polyglot method: executes synchronously if the active connection is synchronous,
        otherwise returns an awaitable.

        Args:
            connection: Database connection to use (optional)

        Returns:
            The resolved out_document instance (or awaitable)

        """
        # If out_document is already a document instance, return it
        if isinstance(self.out_document, Document):
            return self.out_document

        # Get the connection if not provided
        if connection is None:
            connection = get_active_connection(async_mode=None)
            if connection is None:
                # Fallback if no context connection
                try:
                    connection = ConnectionRegistry.get_default_async_connection()
                except RuntimeError:
                    connection = ConnectionRegistry.get_default_sync_connection()

        if not connection.is_async():
            return self.resolve_out_sync(connection)

        async def _resolve_async(conn):
            # Helper to hydrate doc from registry
            def _hydrate(doc):
                if not isinstance(doc, dict):
                    return doc
                if 'id' not in doc:
                    return doc
                val = doc['id']
                table = None
                if hasattr(val, 'table_name'):
                    table = val.table_name
                elif isinstance(val, str) and ':' in val:
                    table = val.split(':')[0]
                if table:
                    doc_cls = DocumentMetaclass._registry.get(table)
                    if doc_cls:
                        return doc_cls.from_db(doc)
                return doc
            
            # If out_document is a string ID, fetch the document
            if isinstance(self.out_document, str) and ':' in self.out_document:
                try:
                    # Fetch the document using the ID
                    result = await conn.client.select(self.out_document)

                    # Process the result
                    if result:
                        if isinstance(result, list) and result:
                            doc = result[0]
                        else:
                            doc = result

                        return _hydrate(doc)
                except Exception as e:
                    logger.error(f"Error resolving out_document {self.out_document}: {str(e)}")

            elif isinstance(self.out_document, RecordID):
                try:
                    result = await conn.client.select(self.out_document)
                    if result:
                        if isinstance(result, list) and result:
                            doc = result[0]
                        else:
                            doc = result

                        return _hydrate(doc)
                except Exception as e:
                    logger.error(f"Error resolving out_document {self.out_document}: {str(e)}")

            # Return the current value if resolution failed
            return self.out_document
            
        return _resolve_async(connection)

    def resolve_out_sync(self, connection=None):
        """Resolve the out_document field synchronously.

        This method resolves the out_document field if it's currently just an ID reference.
        If the out_document is already a document instance, it returns it directly.

        Args:
            connection: Database connection to use (optional)

        Returns:
            The resolved out_document instance

        """
        # If out_document is already a document instance, return it
        if isinstance(self.out_document, Document):
            return self.out_document

        # Get the connection if not provided
        if connection is None:
            connection = ConnectionRegistry.get_default_connection(async_mode=False)

        # If out_document is a string ID, fetch the document
        if isinstance(self.out_document, str) and ':' in self.out_document:
            try:
                # Fetch the document using the ID
                result = connection.client.select(self.out_document)

                # Process the result
                if result:
                    if isinstance(result, list) and result:
                        doc = result[0]
                    else:
                        doc = result
                    
                    if doc:
                        # Hydrate if we have the target document class
                        if hasattr(self, 'out_document_class'):
                            return self.out_document_class.from_db(doc)
                        elif self._meta.get('out_document_type'):
                            return self._meta['out_document_type'].from_db(doc)

                        # Try to resolve class from registry based on 'id'
                        if isinstance(doc, dict) and 'id' in doc:
                            try:
                                val = doc['id']
                                table = None
                                if hasattr(val, 'table_name'):
                                     table = val.table_name
                                else:
                                     table = str(val).split(':')[0]

                                if table:
                                    doc_cls = DocumentMetaclass._registry.get(table)
                                    if doc_cls:
                                        return doc_cls.from_db(doc)
                            except Exception:
                                pass

                        return doc
            except Exception as e:
                logger.error(f"Error resolving out_document {self.out_document}: {str(e)}")

        elif isinstance(self.out_document, RecordID):
            try:
                result = connection.client.select(self.out_document)
                if result:
                    if isinstance(result, list) and result:
                        doc = result[0]
                    else:
                        doc = result
                    
                    if doc:
                         # Hydrate if we have the target document class
                        if hasattr(self, 'out_document_class'):
                            return self.out_document_class.from_db(doc)
                        elif self._meta.get('out_document_type'):
                            return self._meta['out_document_type'].from_db(doc)
                        
                        # Try to resolve class from registry based on RecordID (self.out_document.table_name)
                        table = None
                        if hasattr(self.out_document, 'table_name'):
                            table = self.out_document.table_name
                        elif 'id' in doc:
                             # Check if ID in doc is RecordID
                            val = doc['id']
                            if hasattr(val, 'table_name'):
                                table = val.table_name
                            else:
                                table = str(val).split(':')[0]
                        
                        if table:
                            doc_cls = DocumentMetaclass._registry.get(table)
                            if doc_cls:
                                return doc_cls.from_db(doc)

                        return doc
            except Exception as e:
                logger.error(f"Error resolving out_document {self.out_document}: {str(e)}")

        # Return the current value if resolution failed
        return self.out_document
''