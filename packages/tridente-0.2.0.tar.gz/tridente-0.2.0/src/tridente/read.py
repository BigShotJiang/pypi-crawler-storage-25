"""Typed read-path helpers (get_entity, search).

These run on top of `Tridente._request_json` and wrap the raw-dict
responses into the hand-written Pydantic models from `tridente.models`.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Final

from tridente.entity_ref import parse_entity_ref
from tridente.models import Entity, RuntimeBundle, SearchResponse, SkillBundle

if TYPE_CHECKING:
    from tridente.client import Tridente

SEARCH_MODES: Final[tuple[str, ...]] = ("fts", "semantic")


async def get_entity(client: Tridente, entity_ref: str) -> Entity:
    parsed = parse_entity_ref(entity_ref)
    body = await client._request_json(
        "GET",
        f"/entities/by-ref/{parsed.kind}/{parsed.namespace}/{parsed.name}",
    )
    if not isinstance(body, dict):
        raise TypeError(f"Expected object response, got {type(body).__name__}")
    data = body.get("data")
    if not isinstance(data, dict):
        raise TypeError(f"Expected 'data' object in entity response, got {type(data).__name__}")
    return Entity.model_validate(data)


async def search(
    client: Tridente,
    query: str,
    *,
    mode: str | None = None,
    kind: str | None = None,
    maturity: str | None = None,
    risk_level: str | None = None,
    owner_team: str | None = None,
    page: int | None = None,
    limit: int | None = None,
) -> SearchResponse:
    if not query or not query.strip():
        raise ValueError("search query is required")
    if mode is not None and mode not in SEARCH_MODES:
        raise ValueError(f"mode must be one of {SEARCH_MODES}, got {mode!r}")

    params: dict[str, Any] = {"q": query}
    if mode is not None:
        params["mode"] = mode
    if kind is not None:
        params["kind"] = kind
    if maturity is not None:
        params["maturity"] = maturity
    if risk_level is not None:
        params["risk_level"] = risk_level
    if owner_team is not None:
        params["owner_team"] = owner_team
    if page is not None:
        params["page"] = page
    if limit is not None:
        params["limit"] = limit

    body = await client._request_json("GET", "/search", params=params)
    if not isinstance(body, dict):
        raise TypeError(f"Expected object response, got {type(body).__name__}")
    return SearchResponse.model_validate(body)


async def get_skill_bundle(
    client: Tridente,
    entity_ref: str,
    *,
    version: str | None = None,
    preview: bool = False,
) -> SkillBundle:
    entity = await client.get_entity_raw(entity_ref)
    if entity.get("kind") != "skill":
        raise ValueError("get_skill_bundle requires a kind: skill entity_ref")
    entity_id = entity.get("id")
    if not isinstance(entity_id, str):
        raise TypeError("Expected entity response to include string id")
    params: dict[str, Any] = {}
    if version is not None:
        params["version"] = version
    if preview:
        params["preview"] = "true"
    body = await client._request_json(
        "GET",
        f"/entities/{entity_id}/skill-bundle",
        params=params,
    )
    if not isinstance(body, dict):
        raise TypeError(f"Expected object response, got {type(body).__name__}")
    data = body.get("data")
    if not isinstance(data, dict):
        raise TypeError(
            f"Expected 'data' object in skill bundle response, got {type(data).__name__}"
        )
    return SkillBundle.model_validate(data)


async def get_runtime_bundle(
    client: Tridente,
    entity_ref: str,
    *,
    version: str | None = None,
    preview: bool = False,
) -> RuntimeBundle:
    entity = await client.get_entity_raw(entity_ref)
    if entity.get("kind") != "agent":
        raise ValueError("get_runtime_bundle requires a kind: agent entity_ref")
    entity_id = entity.get("id")
    if not isinstance(entity_id, str):
        raise TypeError("Expected entity response to include string id")
    params: dict[str, Any] = {}
    if version is not None:
        params["version"] = version
    if preview:
        params["preview"] = "true"
    body = await client._request_json(
        "GET",
        f"/entities/{entity_id}/runtime-bundle",
        params=params,
    )
    if not isinstance(body, dict):
        raise TypeError(f"Expected object response, got {type(body).__name__}")
    data = body.get("data")
    if not isinstance(data, dict):
        raise TypeError(
            f"Expected 'data' object in runtime bundle response, got {type(data).__name__}"
        )
    return RuntimeBundle.model_validate(data)
