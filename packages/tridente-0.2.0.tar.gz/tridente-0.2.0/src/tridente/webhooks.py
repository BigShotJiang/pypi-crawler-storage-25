"""Webhook signature helpers for Tridente receivers."""

from __future__ import annotations

import hmac
import time
from hashlib import sha256


def _payload_bytes(payload: str | bytes) -> bytes:
    if isinstance(payload, bytes):
        return payload
    return payload.encode("utf-8")


def create_webhook_signature(*, secret: str, timestamp: int, payload: str | bytes) -> str:
    signed_payload = str(timestamp).encode("utf-8") + b"." + _payload_bytes(payload)
    digest = hmac.new(secret.encode("utf-8"), signed_payload, sha256).hexdigest()
    return digest


def verify_webhook_signature(
    *,
    secret: str,
    timestamp: int,
    payload: str | bytes,
    signature: str,
    tolerance_seconds: int = 300,
    now: int | None = None,
) -> bool:
    current_time = int(time.time()) if now is None else now
    if abs(current_time - timestamp) > tolerance_seconds:
        return False

    expected = create_webhook_signature(
        secret=secret,
        timestamp=timestamp,
        payload=payload,
    )
    return hmac.compare_digest(expected, signature)
