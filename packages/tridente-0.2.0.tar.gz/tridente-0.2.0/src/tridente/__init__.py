"""Tridente Python SDK.

Public API surface. Everything users import from `tridente` is re-exported
here. Submodules (e.g. `tridente.client`, `tridente.events`) are
implementation; importing from them directly is supported but not
guaranteed to remain stable across versions.
"""

from __future__ import annotations

try:
    from tridente._version import __version__
except ImportError:  # pragma: no cover
    __version__ = "0.0.0+local"

from tridente.client import Tridente, get_global_client, init, reset_global_client
from tridente.connectors import ExternalAgent, slugify_name, to_manifest
from tridente.entity_ref import ENTITY_KINDS, EntityRef, parse_entity_ref
from tridente.errors import (
    ApiError,
    ClosedClientError,
    ConfigError,
    TridenteError,
)
from tridente.events import (
    HEARTBEAT_STATUSES,
    USAGE_EVENT_TYPES,
    RunContext,
    flush,
    flush_sync,
    report_cost,
    report_cost_async,
    report_heartbeat,
    report_heartbeat_async,
    report_usage,
    report_usage_async,
    run,
    run_async,
    track,
)
from tridente.models import (
    Entity,
    EntityFacets,
    PaginationMeta,
    RuntimeBundle,
    RuntimeBundleFile,
    RuntimeStatus,
    SearchResponse,
    SkillBundle,
    SkillBundleFile,
)
from tridente.webhooks import create_webhook_signature, verify_webhook_signature

__all__ = [
    "ENTITY_KINDS",
    "HEARTBEAT_STATUSES",
    "USAGE_EVENT_TYPES",
    "ApiError",
    "ClosedClientError",
    "ConfigError",
    "Entity",
    "EntityFacets",
    "EntityRef",
    "ExternalAgent",
    "PaginationMeta",
    "RunContext",
    "RuntimeBundle",
    "RuntimeBundleFile",
    "RuntimeStatus",
    "SearchResponse",
    "SkillBundle",
    "SkillBundleFile",
    "Tridente",
    "TridenteError",
    "__version__",
    "create_webhook_signature",
    "flush",
    "flush_sync",
    "get_global_client",
    "init",
    "parse_entity_ref",
    "report_cost",
    "report_cost_async",
    "report_heartbeat",
    "report_heartbeat_async",
    "report_usage",
    "report_usage_async",
    "reset_global_client",
    "run",
    "run_async",
    "slugify_name",
    "to_manifest",
    "track",
    "verify_webhook_signature",
]
