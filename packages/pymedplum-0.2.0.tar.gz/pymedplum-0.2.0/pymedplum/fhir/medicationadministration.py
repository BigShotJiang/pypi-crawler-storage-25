# This is a generated file — do not edit manually.
# See NOTICE for attribution (HL7 FHIR R4 / @medplum/fhirtypes / PyMedplum)
# and LICENSE for terms.
# SPDX-License-Identifier: Apache-2.0

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Literal

from pydantic import Field

from pymedplum.fhir.base import MedplumFHIRBase

if TYPE_CHECKING:
    from pymedplum.fhir.annotation import Annotation
    from pymedplum.fhir.codeableconcept import CodeableConcept
    from pymedplum.fhir.extension import Extension
    from pymedplum.fhir.identifier import Identifier
    from pymedplum.fhir.meta import Meta
    from pymedplum.fhir.narrative import Narrative
    from pymedplum.fhir.period import Period
    from pymedplum.fhir.quantity import Quantity
    from pymedplum.fhir.ratio import Ratio
    from pymedplum.fhir.reference import Reference


class MedicationAdministration(MedplumFHIRBase):
    """Describes the event of a patient consuming or otherwise being
    administered a medication. This may be as simple as swallowing a tablet
    or it may be a long running infusion. Related resources tie this event
    to the authorizing prescription, and the specific encounter between
    patient and health care practitioner.
    """

    resource_type: Literal["MedicationAdministration"] = Field(
        default="MedicationAdministration", alias="resourceType"
    )

    id: str | None = Field(
        default=None,
        description="The logical id of the resource, as used in the URL for the resource. Once assigned, this value never changes.",
    )
    meta: Meta | None = Field(
        default=None,
        description="The metadata about the resource. This is content that is maintained by the infrastructure. Changes to the content might not always be associated with version changes to the resource.",
    )
    implicit_rules: str | None = Field(
        default=None,
        alias="implicitRules",
        description="A reference to a set of rules that were followed when the resource was constructed, and which must be understood when processing the content. Often, this is a reference to an implementation guide that defines the special rules along with other profiles etc.",
    )
    language: str | None = Field(
        default=None, description="The base language in which the resource is written."
    )
    text: Narrative | None = Field(
        default=None,
        description="A human-readable narrative that contains a summary of the resource and can be used to represent the content of the resource to a human. The narrative need not encode all the structured data, but is required to contain sufficient detail to make it &quot;clinically safe&quot; for a human to just read the narrative. Resource definitions may define what content should be represented in the narrative to ensure clinical safety.",
    )
    contained: list[dict[str, Any]] | None = Field(
        default=None,
        description="These resources do not have an independent existence apart from the resource that contains them - they cannot be identified independently, and nor can they have their own independent transaction scope.",
    )
    extension: list[Extension] | None = Field(
        default=None,
        description="May be used to represent additional information that is not part of the basic definition of the resource. To make the use of extensions safe and manageable, there is a strict set of governance applied to the definition and use of extensions. Though any implementer can define an extension, there is a set of requirements that SHALL be met as part of the definition of the extension.",
    )
    modifier_extension: list[Extension] | None = Field(
        default=None,
        alias="modifierExtension",
        description="May be used to represent additional information that is not part of the basic definition of the resource and that modifies the understanding of the element that contains it and/or the understanding of the containing element's descendants. Usually modifier elements provide negation or qualification. To make the use of extensions safe and manageable, there is a strict set of governance applied to the definition and use of extensions. Though any implementer is allowed to define an extension, there is a set of requirements that SHALL be met as part of the definition of the extension. Applications processing a resource are required to check for modifier extensions. Modifier extensions SHALL NOT change the meaning of any elements on Resource or DomainResource (including cannot change the meaning of modifierExtension itself).",
    )
    identifier: list[Identifier] | None = Field(
        default=None,
        description="Identifiers associated with this Medication Administration that are defined by business processes and/or used to refer to it when a direct URL reference to the resource itself is not appropriate. They are business identifiers assigned to this resource by the performer or other systems and remain constant as the resource is updated and propagates from server to server.",
    )
    instantiates: list[str] | None = Field(
        default=None,
        description="A protocol, guideline, orderset, or other definition that was adhered to in whole or in part by this event.",
    )
    part_of: list[Reference] | None = Field(
        default=None,
        alias="partOf",
        description="A larger event of which this particular event is a component or step.",
    )
    status: Literal[
        "in-progress",
        "not-done",
        "on-hold",
        "completed",
        "entered-in-error",
        "stopped",
        "unknown",
    ] = Field(
        default=...,
        description="Will generally be set to show that the administration has been completed. For some long running administrations such as infusions, it is possible for an administration to be started but not completed or it may be paused while some other process is under way.",
    )
    status_reason: list[CodeableConcept] | None = Field(
        default=None,
        alias="statusReason",
        description="A code indicating why the administration was not performed.",
    )
    category: CodeableConcept | None = Field(
        default=None,
        description="Indicates where the medication is expected to be consumed or administered.",
    )
    medication_codeable_concept: CodeableConcept | None = Field(
        default=None,
        alias="medicationCodeableConcept",
        description="Identifies the medication that was administered. This is either a link to a resource representing the details of the medication or a simple attribute carrying a code that identifies the medication from a known list of medications.",
    )
    medication_reference: Reference | None = Field(
        default=None,
        alias="medicationReference",
        description="Identifies the medication that was administered. This is either a link to a resource representing the details of the medication or a simple attribute carrying a code that identifies the medication from a known list of medications.",
    )
    subject: Reference = Field(
        default=...,
        description="The person or animal or group receiving the medication.",
    )
    context: Reference | None = Field(
        default=None,
        description="The visit, admission, or other contact between patient and health care provider during which the medication administration was performed.",
    )
    supporting_information: list[Reference] | None = Field(
        default=None,
        alias="supportingInformation",
        description="Additional information (for example, patient height and weight) that supports the administration of the medication.",
    )
    effective_date_time: str | None = Field(
        default=None,
        alias="effectiveDateTime",
        description="A specific date/time or interval of time during which the administration took place (or did not take place, when the 'notGiven' attribute is true). For many administrations, such as swallowing a tablet the use of dateTime is more appropriate.",
    )
    effective_period: Period | None = Field(
        default=None,
        alias="effectivePeriod",
        description="A specific date/time or interval of time during which the administration took place (or did not take place, when the 'notGiven' attribute is true). For many administrations, such as swallowing a tablet the use of dateTime is more appropriate.",
    )
    performer: list[MedicationAdministrationPerformer] | None = Field(
        default=None,
        description="Indicates who or what performed the medication administration and how they were involved.",
    )
    reason_code: list[CodeableConcept] | None = Field(
        default=None,
        alias="reasonCode",
        description="A code indicating why the medication was given.",
    )
    reason_reference: list[Reference] | None = Field(
        default=None,
        alias="reasonReference",
        description="Condition or observation that supports why the medication was administered.",
    )
    request: Reference | None = Field(
        default=None,
        description="The original request, instruction or authority to perform the administration.",
    )
    device: list[Reference] | None = Field(
        default=None,
        description="The device used in administering the medication to the patient. For example, a particular infusion pump.",
    )
    note: list[Annotation] | None = Field(
        default=None,
        description="Extra information about the medication administration that is not conveyed by the other attributes.",
    )
    dosage: MedicationAdministrationDosage | None = Field(
        default=None,
        description="Describes the medication dosage information details e.g. dose, rate, site, route, etc.",
    )
    event_history: list[Reference] | None = Field(
        default=None,
        alias="eventHistory",
        description="A summary of the events of interest that have occurred, such as when the administration was verified.",
    )


class MedicationAdministrationDosage(MedplumFHIRBase):
    """Describes the medication dosage information details e.g. dose, rate,
    site, route, etc.
    """

    id: str | None = Field(
        default=None,
        description="Unique id for the element within a resource (for internal references). This may be any string value that does not contain spaces.",
    )
    extension: list[Extension] | None = Field(
        default=None,
        description="May be used to represent additional information that is not part of the basic definition of the element. To make the use of extensions safe and manageable, there is a strict set of governance applied to the definition and use of extensions. Though any implementer can define an extension, there is a set of requirements that SHALL be met as part of the definition of the extension.",
    )
    modifier_extension: list[Extension] | None = Field(
        default=None,
        alias="modifierExtension",
        description="May be used to represent additional information that is not part of the basic definition of the element and that modifies the understanding of the element in which it is contained and/or the understanding of the containing element's descendants. Usually modifier elements provide negation or qualification. To make the use of extensions safe and manageable, there is a strict set of governance applied to the definition and use of extensions. Though any implementer can define an extension, there is a set of requirements that SHALL be met as part of the definition of the extension. Applications processing a resource are required to check for modifier extensions. Modifier extensions SHALL NOT change the meaning of any elements on Resource or DomainResource (including cannot change the meaning of modifierExtension itself).",
    )
    text: str | None = Field(
        default=None,
        description="Free text dosage can be used for cases where the dosage administered is too complex to code. When coded dosage is present, the free text dosage may still be present for display to humans. The dosage instructions should reflect the dosage of the medication that was administered.",
    )
    site: CodeableConcept | None = Field(
        default=None,
        description="A coded specification of the anatomic site where the medication first entered the body. For example, &quot;left arm&quot;.",
    )
    route: CodeableConcept | None = Field(
        default=None,
        description="A code specifying the route or physiological path of administration of a therapeutic agent into or onto the patient. For example, topical, intravenous, etc.",
    )
    method: CodeableConcept | None = Field(
        default=None,
        description="A coded value indicating the method by which the medication is intended to be or was introduced into or on the body. This attribute will most often NOT be populated. It is most commonly used for injections. For example, Slow Push, Deep IV.",
    )
    dose: Quantity | None = Field(
        default=None,
        description="The amount of the medication given at one administration event. Use this value when the administration is essentially an instantaneous event such as a swallowing a tablet or giving an injection.",
    )
    rate_ratio: Ratio | None = Field(
        default=None,
        alias="rateRatio",
        description="Identifies the speed with which the medication was or will be introduced into the patient. Typically, the rate for an infusion e.g. 100 ml per 1 hour or 100 ml/hr. May also be expressed as a rate per unit of time, e.g. 500 ml per 2 hours. Other examples: 200 mcg/min or 200 mcg/1 minute; 1 liter/8 hours.",
    )
    rate_quantity: Quantity | None = Field(
        default=None,
        alias="rateQuantity",
        description="Identifies the speed with which the medication was or will be introduced into the patient. Typically, the rate for an infusion e.g. 100 ml per 1 hour or 100 ml/hr. May also be expressed as a rate per unit of time, e.g. 500 ml per 2 hours. Other examples: 200 mcg/min or 200 mcg/1 minute; 1 liter/8 hours.",
    )


class MedicationAdministrationPerformer(MedplumFHIRBase):
    """Indicates who or what performed the medication administration and how
    they were involved.
    """

    id: str | None = Field(
        default=None,
        description="Unique id for the element within a resource (for internal references). This may be any string value that does not contain spaces.",
    )
    extension: list[Extension] | None = Field(
        default=None,
        description="May be used to represent additional information that is not part of the basic definition of the element. To make the use of extensions safe and manageable, there is a strict set of governance applied to the definition and use of extensions. Though any implementer can define an extension, there is a set of requirements that SHALL be met as part of the definition of the extension.",
    )
    modifier_extension: list[Extension] | None = Field(
        default=None,
        alias="modifierExtension",
        description="May be used to represent additional information that is not part of the basic definition of the element and that modifies the understanding of the element in which it is contained and/or the understanding of the containing element's descendants. Usually modifier elements provide negation or qualification. To make the use of extensions safe and manageable, there is a strict set of governance applied to the definition and use of extensions. Though any implementer can define an extension, there is a set of requirements that SHALL be met as part of the definition of the extension. Applications processing a resource are required to check for modifier extensions. Modifier extensions SHALL NOT change the meaning of any elements on Resource or DomainResource (including cannot change the meaning of modifierExtension itself).",
    )
    function: CodeableConcept | None = Field(
        default=None,
        description="Distinguishes the type of involvement of the performer in the medication administration.",
    )
    actor: Reference = Field(
        default=...,
        description="Indicates who or what performed the medication administration.",
    )
