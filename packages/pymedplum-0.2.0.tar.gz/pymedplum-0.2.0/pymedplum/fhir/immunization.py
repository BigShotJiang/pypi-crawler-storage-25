# This is a generated file — do not edit manually.
# See NOTICE for attribution (HL7 FHIR R4 / @medplum/fhirtypes / PyMedplum)
# and LICENSE for terms.
# SPDX-License-Identifier: Apache-2.0

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Literal

from pydantic import Field

from pymedplum.fhir.base import MedplumFHIRBase

if TYPE_CHECKING:
    from pymedplum.fhir.annotation import Annotation
    from pymedplum.fhir.codeableconcept import CodeableConcept
    from pymedplum.fhir.extension import Extension
    from pymedplum.fhir.identifier import Identifier
    from pymedplum.fhir.meta import Meta
    from pymedplum.fhir.narrative import Narrative
    from pymedplum.fhir.quantity import Quantity
    from pymedplum.fhir.reference import Reference


class Immunization(MedplumFHIRBase):
    """Describes the event of a patient being administered a vaccine or a
    record of an immunization as reported by a patient, a clinician or
    another party.
    """

    resource_type: Literal["Immunization"] = Field(
        default="Immunization", alias="resourceType"
    )

    id: str | None = Field(
        default=None,
        description="The logical id of the resource, as used in the URL for the resource. Once assigned, this value never changes.",
    )
    meta: Meta | None = Field(
        default=None,
        description="The metadata about the resource. This is content that is maintained by the infrastructure. Changes to the content might not always be associated with version changes to the resource.",
    )
    implicit_rules: str | None = Field(
        default=None,
        alias="implicitRules",
        description="A reference to a set of rules that were followed when the resource was constructed, and which must be understood when processing the content. Often, this is a reference to an implementation guide that defines the special rules along with other profiles etc.",
    )
    language: str | None = Field(
        default=None, description="The base language in which the resource is written."
    )
    text: Narrative | None = Field(
        default=None,
        description="A human-readable narrative that contains a summary of the resource and can be used to represent the content of the resource to a human. The narrative need not encode all the structured data, but is required to contain sufficient detail to make it &quot;clinically safe&quot; for a human to just read the narrative. Resource definitions may define what content should be represented in the narrative to ensure clinical safety.",
    )
    contained: list[dict[str, Any]] | None = Field(
        default=None,
        description="These resources do not have an independent existence apart from the resource that contains them - they cannot be identified independently, and nor can they have their own independent transaction scope.",
    )
    extension: list[Extension] | None = Field(
        default=None,
        description="May be used to represent additional information that is not part of the basic definition of the resource. To make the use of extensions safe and manageable, there is a strict set of governance applied to the definition and use of extensions. Though any implementer can define an extension, there is a set of requirements that SHALL be met as part of the definition of the extension.",
    )
    modifier_extension: list[Extension] | None = Field(
        default=None,
        alias="modifierExtension",
        description="May be used to represent additional information that is not part of the basic definition of the resource and that modifies the understanding of the element that contains it and/or the understanding of the containing element's descendants. Usually modifier elements provide negation or qualification. To make the use of extensions safe and manageable, there is a strict set of governance applied to the definition and use of extensions. Though any implementer is allowed to define an extension, there is a set of requirements that SHALL be met as part of the definition of the extension. Applications processing a resource are required to check for modifier extensions. Modifier extensions SHALL NOT change the meaning of any elements on Resource or DomainResource (including cannot change the meaning of modifierExtension itself).",
    )
    identifier: list[Identifier] | None = Field(
        default=None,
        description="A unique identifier assigned to this immunization record.",
    )
    status: Literal["completed", "entered-in-error", "not-done"] = Field(
        default=...,
        description="Indicates the current status of the immunization event.",
    )
    status_reason: CodeableConcept | None = Field(
        default=None,
        alias="statusReason",
        description="Indicates the reason the immunization event was not performed.",
    )
    vaccine_code: CodeableConcept = Field(
        default=...,
        alias="vaccineCode",
        description="Vaccine that was administered or was to be administered.",
    )
    patient: Reference = Field(
        default=...,
        description="The patient who either received or did not receive the immunization.",
    )
    encounter: Reference | None = Field(
        default=None,
        description="The visit or admission or other contact between patient and health care provider the immunization was performed as part of.",
    )
    occurrence_date_time: str | None = Field(
        default=None,
        alias="occurrenceDateTime",
        description="Date vaccine administered or was to be administered.",
    )
    occurrence_string: str | None = Field(
        default=None,
        alias="occurrenceString",
        description="Date vaccine administered or was to be administered.",
    )
    recorded: str | None = Field(
        default=None,
        description="The date the occurrence of the immunization was first captured in the record - potentially significantly after the occurrence of the event.",
    )
    primary_source: bool | None = Field(
        default=None,
        alias="primarySource",
        description="An indication that the content of the record is based on information from the person who administered the vaccine. This reflects the context under which the data was originally recorded.",
    )
    report_origin: CodeableConcept | None = Field(
        default=None,
        alias="reportOrigin",
        description="The source of the data when the report of the immunization event is not based on information from the person who administered the vaccine.",
    )
    location: Reference | None = Field(
        default=None,
        description="The service delivery location where the vaccine administration occurred.",
    )
    manufacturer: Reference | None = Field(
        default=None, description="Name of vaccine manufacturer."
    )
    lot_number: str | None = Field(
        default=None,
        alias="lotNumber",
        description="Lot number of the vaccine product.",
    )
    expiration_date: str | None = Field(
        default=None, alias="expirationDate", description="Date vaccine batch expires."
    )
    site: CodeableConcept | None = Field(
        default=None, description="Body site where vaccine was administered."
    )
    route: CodeableConcept | None = Field(
        default=None,
        description="The path by which the vaccine product is taken into the body.",
    )
    dose_quantity: Quantity | None = Field(
        default=None,
        alias="doseQuantity",
        description="The quantity of vaccine product that was administered.",
    )
    performer: list[ImmunizationPerformer] | None = Field(
        default=None, description="Indicates who performed the immunization event."
    )
    note: list[Annotation] | None = Field(
        default=None,
        description="Extra information about the immunization that is not conveyed by the other attributes.",
    )
    reason_code: list[CodeableConcept] | None = Field(
        default=None,
        alias="reasonCode",
        description="Reasons why the vaccine was administered.",
    )
    reason_reference: list[Reference] | None = Field(
        default=None,
        alias="reasonReference",
        description="Condition, Observation or DiagnosticReport that supports why the immunization was administered.",
    )
    is_subpotent: bool | None = Field(
        default=None,
        alias="isSubpotent",
        description="Indication if a dose is considered to be subpotent. By default, a dose should be considered to be potent.",
    )
    subpotent_reason: list[CodeableConcept] | None = Field(
        default=None,
        alias="subpotentReason",
        description="Reason why a dose is considered to be subpotent.",
    )
    education: list[ImmunizationEducation] | None = Field(
        default=None,
        description="Educational material presented to the patient (or guardian) at the time of vaccine administration.",
    )
    program_eligibility: list[CodeableConcept] | None = Field(
        default=None,
        alias="programEligibility",
        description="Indicates a patient's eligibility for a funding program.",
    )
    funding_source: CodeableConcept | None = Field(
        default=None,
        alias="fundingSource",
        description="Indicates the source of the vaccine actually administered. This may be different than the patient eligibility (e.g. the patient may be eligible for a publically purchased vaccine but due to inventory issues, vaccine purchased with private funds was actually administered).",
    )
    reaction: list[ImmunizationReaction] | None = Field(
        default=None,
        description="Categorical data indicating that an adverse event is associated in time to an immunization.",
    )
    protocol_applied: list[ImmunizationProtocolApplied] | None = Field(
        default=None,
        alias="protocolApplied",
        description="The protocol (set of recommendations) being followed by the provider who administered the dose.",
    )


class ImmunizationEducation(MedplumFHIRBase):
    """Educational material presented to the patient (or guardian) at the time
    of vaccine administration.
    """

    id: str | None = Field(
        default=None,
        description="Unique id for the element within a resource (for internal references). This may be any string value that does not contain spaces.",
    )
    extension: list[Extension] | None = Field(
        default=None,
        description="May be used to represent additional information that is not part of the basic definition of the element. To make the use of extensions safe and manageable, there is a strict set of governance applied to the definition and use of extensions. Though any implementer can define an extension, there is a set of requirements that SHALL be met as part of the definition of the extension.",
    )
    modifier_extension: list[Extension] | None = Field(
        default=None,
        alias="modifierExtension",
        description="May be used to represent additional information that is not part of the basic definition of the element and that modifies the understanding of the element in which it is contained and/or the understanding of the containing element's descendants. Usually modifier elements provide negation or qualification. To make the use of extensions safe and manageable, there is a strict set of governance applied to the definition and use of extensions. Though any implementer can define an extension, there is a set of requirements that SHALL be met as part of the definition of the extension. Applications processing a resource are required to check for modifier extensions. Modifier extensions SHALL NOT change the meaning of any elements on Resource or DomainResource (including cannot change the meaning of modifierExtension itself).",
    )
    document_type: str | None = Field(
        default=None,
        alias="documentType",
        description="Identifier of the material presented to the patient.",
    )
    reference: str | None = Field(
        default=None,
        description="Reference pointer to the educational material given to the patient if the information was on line.",
    )
    publication_date: str | None = Field(
        default=None,
        alias="publicationDate",
        description="Date the educational material was published.",
    )
    presentation_date: str | None = Field(
        default=None,
        alias="presentationDate",
        description="Date the educational material was given to the patient.",
    )


class ImmunizationPerformer(MedplumFHIRBase):
    """Indicates who performed the immunization event."""

    id: str | None = Field(
        default=None,
        description="Unique id for the element within a resource (for internal references). This may be any string value that does not contain spaces.",
    )
    extension: list[Extension] | None = Field(
        default=None,
        description="May be used to represent additional information that is not part of the basic definition of the element. To make the use of extensions safe and manageable, there is a strict set of governance applied to the definition and use of extensions. Though any implementer can define an extension, there is a set of requirements that SHALL be met as part of the definition of the extension.",
    )
    modifier_extension: list[Extension] | None = Field(
        default=None,
        alias="modifierExtension",
        description="May be used to represent additional information that is not part of the basic definition of the element and that modifies the understanding of the element in which it is contained and/or the understanding of the containing element's descendants. Usually modifier elements provide negation or qualification. To make the use of extensions safe and manageable, there is a strict set of governance applied to the definition and use of extensions. Though any implementer can define an extension, there is a set of requirements that SHALL be met as part of the definition of the extension. Applications processing a resource are required to check for modifier extensions. Modifier extensions SHALL NOT change the meaning of any elements on Resource or DomainResource (including cannot change the meaning of modifierExtension itself).",
    )
    function: CodeableConcept | None = Field(
        default=None,
        description="Describes the type of performance (e.g. ordering provider, administering provider, etc.).",
    )
    actor: Reference = Field(
        default=...,
        description="The practitioner or organization who performed the action.",
    )


class ImmunizationProtocolApplied(MedplumFHIRBase):
    """The protocol (set of recommendations) being followed by the provider who
    administered the dose.
    """

    id: str | None = Field(
        default=None,
        description="Unique id for the element within a resource (for internal references). This may be any string value that does not contain spaces.",
    )
    extension: list[Extension] | None = Field(
        default=None,
        description="May be used to represent additional information that is not part of the basic definition of the element. To make the use of extensions safe and manageable, there is a strict set of governance applied to the definition and use of extensions. Though any implementer can define an extension, there is a set of requirements that SHALL be met as part of the definition of the extension.",
    )
    modifier_extension: list[Extension] | None = Field(
        default=None,
        alias="modifierExtension",
        description="May be used to represent additional information that is not part of the basic definition of the element and that modifies the understanding of the element in which it is contained and/or the understanding of the containing element's descendants. Usually modifier elements provide negation or qualification. To make the use of extensions safe and manageable, there is a strict set of governance applied to the definition and use of extensions. Though any implementer can define an extension, there is a set of requirements that SHALL be met as part of the definition of the extension. Applications processing a resource are required to check for modifier extensions. Modifier extensions SHALL NOT change the meaning of any elements on Resource or DomainResource (including cannot change the meaning of modifierExtension itself).",
    )
    series: str | None = Field(
        default=None,
        description="One possible path to achieve presumed immunity against a disease - within the context of an authority.",
    )
    authority: Reference | None = Field(
        default=None,
        description="Indicates the authority who published the protocol (e.g. ACIP) that is being followed.",
    )
    target_disease: list[CodeableConcept] | None = Field(
        default=None,
        alias="targetDisease",
        description="The vaccine preventable disease the dose is being administered against.",
    )
    dose_number_positive_int: int | None = Field(
        default=None,
        alias="doseNumberPositiveInt",
        description="Nominal position in a series.",
    )
    dose_number_string: str | None = Field(
        default=None,
        alias="doseNumberString",
        description="Nominal position in a series.",
    )
    series_doses_positive_int: int | None = Field(
        default=None,
        alias="seriesDosesPositiveInt",
        description="The recommended number of doses to achieve immunity.",
    )
    series_doses_string: str | None = Field(
        default=None,
        alias="seriesDosesString",
        description="The recommended number of doses to achieve immunity.",
    )


class ImmunizationReaction(MedplumFHIRBase):
    """Categorical data indicating that an adverse event is associated in time
    to an immunization.
    """

    id: str | None = Field(
        default=None,
        description="Unique id for the element within a resource (for internal references). This may be any string value that does not contain spaces.",
    )
    extension: list[Extension] | None = Field(
        default=None,
        description="May be used to represent additional information that is not part of the basic definition of the element. To make the use of extensions safe and manageable, there is a strict set of governance applied to the definition and use of extensions. Though any implementer can define an extension, there is a set of requirements that SHALL be met as part of the definition of the extension.",
    )
    modifier_extension: list[Extension] | None = Field(
        default=None,
        alias="modifierExtension",
        description="May be used to represent additional information that is not part of the basic definition of the element and that modifies the understanding of the element in which it is contained and/or the understanding of the containing element's descendants. Usually modifier elements provide negation or qualification. To make the use of extensions safe and manageable, there is a strict set of governance applied to the definition and use of extensions. Though any implementer can define an extension, there is a set of requirements that SHALL be met as part of the definition of the extension. Applications processing a resource are required to check for modifier extensions. Modifier extensions SHALL NOT change the meaning of any elements on Resource or DomainResource (including cannot change the meaning of modifierExtension itself).",
    )
    date: str | None = Field(
        default=None, description="Date of reaction to the immunization."
    )
    detail: Reference | None = Field(
        default=None, description="Details of the reaction."
    )
    reported: bool | None = Field(default=None, description="Self-reported indicator.")
