# This is a generated file — do not edit manually.
# See NOTICE for attribution (HL7 FHIR R4 / @medplum/fhirtypes / PyMedplum)
# and LICENSE for terms.
# SPDX-License-Identifier: Apache-2.0

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Literal

from pydantic import Field

from pymedplum.fhir.base import MedplumFHIRBase

if TYPE_CHECKING:
    from pymedplum.fhir.codeableconcept import CodeableConcept
    from pymedplum.fhir.coding import Coding
    from pymedplum.fhir.contactpoint import ContactPoint
    from pymedplum.fhir.extension import Extension
    from pymedplum.fhir.meta import Meta
    from pymedplum.fhir.narrative import Narrative
    from pymedplum.fhir.reference import Reference


class MessageHeader(MedplumFHIRBase):
    """The header for a message exchange that is either requesting or
    responding to an action. The reference(s) that are the subject of the
    action as well as other information related to the action are typically
    transmitted in a bundle in which the MessageHeader resource instance is
    the first resource in the bundle.
    """

    resource_type: Literal["MessageHeader"] = Field(
        default="MessageHeader", alias="resourceType"
    )

    id: str | None = Field(
        default=None,
        description="The logical id of the resource, as used in the URL for the resource. Once assigned, this value never changes.",
    )
    meta: Meta | None = Field(
        default=None,
        description="The metadata about the resource. This is content that is maintained by the infrastructure. Changes to the content might not always be associated with version changes to the resource.",
    )
    implicit_rules: str | None = Field(
        default=None,
        alias="implicitRules",
        description="A reference to a set of rules that were followed when the resource was constructed, and which must be understood when processing the content. Often, this is a reference to an implementation guide that defines the special rules along with other profiles etc.",
    )
    language: str | None = Field(
        default=None, description="The base language in which the resource is written."
    )
    text: Narrative | None = Field(
        default=None,
        description="A human-readable narrative that contains a summary of the resource and can be used to represent the content of the resource to a human. The narrative need not encode all the structured data, but is required to contain sufficient detail to make it &quot;clinically safe&quot; for a human to just read the narrative. Resource definitions may define what content should be represented in the narrative to ensure clinical safety.",
    )
    contained: list[dict[str, Any]] | None = Field(
        default=None,
        description="These resources do not have an independent existence apart from the resource that contains them - they cannot be identified independently, and nor can they have their own independent transaction scope.",
    )
    extension: list[Extension] | None = Field(
        default=None,
        description="May be used to represent additional information that is not part of the basic definition of the resource. To make the use of extensions safe and manageable, there is a strict set of governance applied to the definition and use of extensions. Though any implementer can define an extension, there is a set of requirements that SHALL be met as part of the definition of the extension.",
    )
    modifier_extension: list[Extension] | None = Field(
        default=None,
        alias="modifierExtension",
        description="May be used to represent additional information that is not part of the basic definition of the resource and that modifies the understanding of the element that contains it and/or the understanding of the containing element's descendants. Usually modifier elements provide negation or qualification. To make the use of extensions safe and manageable, there is a strict set of governance applied to the definition and use of extensions. Though any implementer is allowed to define an extension, there is a set of requirements that SHALL be met as part of the definition of the extension. Applications processing a resource are required to check for modifier extensions. Modifier extensions SHALL NOT change the meaning of any elements on Resource or DomainResource (including cannot change the meaning of modifierExtension itself).",
    )
    event_coding: Coding | None = Field(
        default=None,
        alias="eventCoding",
        description="Code that identifies the event this message represents and connects it with its definition. Events defined as part of the FHIR specification have the system value &quot;http://terminology.hl7.org/CodeSystem/message-events&quot;. Alternatively uri to the EventDefinition.",
    )
    event_uri: str | None = Field(
        default=None,
        alias="eventUri",
        description="Code that identifies the event this message represents and connects it with its definition. Events defined as part of the FHIR specification have the system value &quot;http://terminology.hl7.org/CodeSystem/message-events&quot;. Alternatively uri to the EventDefinition.",
    )
    destination: list[MessageHeaderDestination] | None = Field(
        default=None,
        description="The destination application which the message is intended for.",
    )
    sender: Reference | None = Field(
        default=None,
        description="Identifies the sending system to allow the use of a trust relationship.",
    )
    enterer: Reference | None = Field(
        default=None,
        description="The person or device that performed the data entry leading to this message. When there is more than one candidate, pick the most proximal to the message. Can provide other enterers in extensions.",
    )
    author: Reference | None = Field(
        default=None,
        description="The logical author of the message - the person or device that decided the described event should happen. When there is more than one candidate, pick the most proximal to the MessageHeader. Can provide other authors in extensions.",
    )
    source: MessageHeaderSource = Field(
        default=...,
        description="The source application from which this message originated.",
    )
    responsible: Reference | None = Field(
        default=None,
        description="The person or organization that accepts overall responsibility for the contents of the message. The implication is that the message event happened under the policies of the responsible party.",
    )
    reason: CodeableConcept | None = Field(
        default=None,
        description="Coded indication of the cause for the event - indicates a reason for the occurrence of the event that is a focus of this message.",
    )
    response: MessageHeaderResponse | None = Field(
        default=None,
        description="Information about the message that this message is a response to. Only present if this message is a response.",
    )
    focus: list[Reference] | None = Field(
        default=None,
        description="The actual data of the message - a reference to the root/focus class of the event.",
    )
    definition: str | None = Field(
        default=None,
        description="Permanent link to the MessageDefinition for this message.",
    )


class MessageHeaderDestination(MedplumFHIRBase):
    """The destination application which the message is intended for."""

    id: str | None = Field(
        default=None,
        description="Unique id for the element within a resource (for internal references). This may be any string value that does not contain spaces.",
    )
    extension: list[Extension] | None = Field(
        default=None,
        description="May be used to represent additional information that is not part of the basic definition of the element. To make the use of extensions safe and manageable, there is a strict set of governance applied to the definition and use of extensions. Though any implementer can define an extension, there is a set of requirements that SHALL be met as part of the definition of the extension.",
    )
    modifier_extension: list[Extension] | None = Field(
        default=None,
        alias="modifierExtension",
        description="May be used to represent additional information that is not part of the basic definition of the element and that modifies the understanding of the element in which it is contained and/or the understanding of the containing element's descendants. Usually modifier elements provide negation or qualification. To make the use of extensions safe and manageable, there is a strict set of governance applied to the definition and use of extensions. Though any implementer can define an extension, there is a set of requirements that SHALL be met as part of the definition of the extension. Applications processing a resource are required to check for modifier extensions. Modifier extensions SHALL NOT change the meaning of any elements on Resource or DomainResource (including cannot change the meaning of modifierExtension itself).",
    )
    name: str | None = Field(
        default=None, description="Human-readable name for the target system."
    )
    target: Reference | None = Field(
        default=None,
        description="Identifies the target end system in situations where the initial message transmission is to an intermediary system.",
    )
    endpoint: str = Field(
        default=..., description="Indicates where the message should be routed to."
    )
    receiver: Reference | None = Field(
        default=None,
        description="Allows data conveyed by a message to be addressed to a particular person or department when routing to a specific application isn't sufficient.",
    )


class MessageHeaderResponse(MedplumFHIRBase):
    """Information about the message that this message is a response to. Only
    present if this message is a response.
    """

    id: str | None = Field(
        default=None,
        description="Unique id for the element within a resource (for internal references). This may be any string value that does not contain spaces.",
    )
    extension: list[Extension] | None = Field(
        default=None,
        description="May be used to represent additional information that is not part of the basic definition of the element. To make the use of extensions safe and manageable, there is a strict set of governance applied to the definition and use of extensions. Though any implementer can define an extension, there is a set of requirements that SHALL be met as part of the definition of the extension.",
    )
    modifier_extension: list[Extension] | None = Field(
        default=None,
        alias="modifierExtension",
        description="May be used to represent additional information that is not part of the basic definition of the element and that modifies the understanding of the element in which it is contained and/or the understanding of the containing element's descendants. Usually modifier elements provide negation or qualification. To make the use of extensions safe and manageable, there is a strict set of governance applied to the definition and use of extensions. Though any implementer can define an extension, there is a set of requirements that SHALL be met as part of the definition of the extension. Applications processing a resource are required to check for modifier extensions. Modifier extensions SHALL NOT change the meaning of any elements on Resource or DomainResource (including cannot change the meaning of modifierExtension itself).",
    )
    identifier: str = Field(
        default=...,
        description="The MessageHeader.id of the message to which this message is a response.",
    )
    code: Literal["ok", "transient-error", "fatal-error"] = Field(
        default=...,
        description="Code that identifies the type of response to the message - whether it was successful or not, and whether it should be resent or not.",
    )
    details: Reference | None = Field(
        default=None, description="Full details of any issues found in the message."
    )


class MessageHeaderSource(MedplumFHIRBase):
    """The source application from which this message originated."""

    id: str | None = Field(
        default=None,
        description="Unique id for the element within a resource (for internal references). This may be any string value that does not contain spaces.",
    )
    extension: list[Extension] | None = Field(
        default=None,
        description="May be used to represent additional information that is not part of the basic definition of the element. To make the use of extensions safe and manageable, there is a strict set of governance applied to the definition and use of extensions. Though any implementer can define an extension, there is a set of requirements that SHALL be met as part of the definition of the extension.",
    )
    modifier_extension: list[Extension] | None = Field(
        default=None,
        alias="modifierExtension",
        description="May be used to represent additional information that is not part of the basic definition of the element and that modifies the understanding of the element in which it is contained and/or the understanding of the containing element's descendants. Usually modifier elements provide negation or qualification. To make the use of extensions safe and manageable, there is a strict set of governance applied to the definition and use of extensions. Though any implementer can define an extension, there is a set of requirements that SHALL be met as part of the definition of the extension. Applications processing a resource are required to check for modifier extensions. Modifier extensions SHALL NOT change the meaning of any elements on Resource or DomainResource (including cannot change the meaning of modifierExtension itself).",
    )
    name: str | None = Field(
        default=None, description="Human-readable name for the source system."
    )
    software: str | None = Field(
        default=None,
        description="May include configuration or other information useful in debugging.",
    )
    version: str | None = Field(
        default=None,
        description="Can convey versions of multiple systems in situations where a message passes through multiple hands.",
    )
    contact: ContactPoint | None = Field(
        default=None,
        description="An e-mail, phone, website or other contact point to use to resolve issues with message communications.",
    )
    endpoint: str = Field(
        default=...,
        description="Identifies the routing target to send acknowledgements to.",
    )
