# This is a generated file — do not edit manually.
# See NOTICE for attribution (HL7 FHIR R4 / @medplum/fhirtypes / PyMedplum)
# and LICENSE for terms.
# SPDX-License-Identifier: Apache-2.0

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

from pydantic import Field

from pymedplum.fhir.base import MedplumFHIRBase

if TYPE_CHECKING:
    from pymedplum.fhir.address import Address
    from pymedplum.fhir.age import Age
    from pymedplum.fhir.annotation import Annotation
    from pymedplum.fhir.attachment import Attachment
    from pymedplum.fhir.codeableconcept import CodeableConcept
    from pymedplum.fhir.coding import Coding
    from pymedplum.fhir.contactdetail import ContactDetail
    from pymedplum.fhir.contactpoint import ContactPoint
    from pymedplum.fhir.contributor import Contributor
    from pymedplum.fhir.count import Count
    from pymedplum.fhir.datarequirement import DataRequirement
    from pymedplum.fhir.distance import Distance
    from pymedplum.fhir.dosage import Dosage
    from pymedplum.fhir.duration import Duration
    from pymedplum.fhir.expression import Expression
    from pymedplum.fhir.extension import Extension
    from pymedplum.fhir.humanname import HumanName
    from pymedplum.fhir.identifier import Identifier
    from pymedplum.fhir.meta import Meta
    from pymedplum.fhir.money import Money
    from pymedplum.fhir.parameterdefinition import ParameterDefinition
    from pymedplum.fhir.period import Period
    from pymedplum.fhir.quantity import Quantity
    from pymedplum.fhir.range import Range
    from pymedplum.fhir.ratio import Ratio
    from pymedplum.fhir.reference import Reference
    from pymedplum.fhir.relatedartifact import RelatedArtifact
    from pymedplum.fhir.sampleddata import SampledData
    from pymedplum.fhir.signature import Signature
    from pymedplum.fhir.timing import Timing
    from pymedplum.fhir.triggerdefinition import TriggerDefinition
    from pymedplum.fhir.usagecontext import UsageContext


class ElementDefinition(MedplumFHIRBase):
    """Captures constraints on each element within the resource, profile, or extension."""

    id: str | None = Field(
        default=None,
        description="Unique id for the element within a resource (for internal references). This may be any string value that does not contain spaces.",
    )
    extension: list[Extension] | None = Field(
        default=None,
        description="May be used to represent additional information that is not part of the basic definition of the element. To make the use of extensions safe and manageable, there is a strict set of governance applied to the definition and use of extensions. Though any implementer can define an extension, there is a set of requirements that SHALL be met as part of the definition of the extension.",
    )
    modifier_extension: list[Extension] | None = Field(
        default=None,
        alias="modifierExtension",
        description="May be used to represent additional information that is not part of the basic definition of the element and that modifies the understanding of the element in which it is contained and/or the understanding of the containing element's descendants. Usually modifier elements provide negation or qualification. To make the use of extensions safe and manageable, there is a strict set of governance applied to the definition and use of extensions. Though any implementer can define an extension, there is a set of requirements that SHALL be met as part of the definition of the extension. Applications processing a resource are required to check for modifier extensions. Modifier extensions SHALL NOT change the meaning of any elements on Resource or DomainResource (including cannot change the meaning of modifierExtension itself).",
    )
    path: str = Field(
        default=...,
        description="The path identifies the element and is expressed as a &quot;.&quot;-separated list of ancestor elements, beginning with the name of the resource or extension.",
    )
    representation: (
        list[Literal["xmlAttr", "xmlText", "typeAttr", "cdaText", "xhtml"]] | None
    ) = Field(
        default=None,
        description="Codes that define how this element is represented in instances, when the deviation varies from the normal case.",
    )
    slice_name: str | None = Field(
        default=None,
        alias="sliceName",
        description="The name of this element definition slice, when slicing is working. The name must be a token with no dots or spaces. This is a unique name referring to a specific set of constraints applied to this element, used to provide a name to different slices of the same element.",
    )
    slice_is_constraining: bool | None = Field(
        default=None,
        alias="sliceIsConstraining",
        description="If true, indicates that this slice definition is constraining a slice definition with the same name in an inherited profile. If false, the slice is not overriding any slice in an inherited profile. If missing, the slice might or might not be overriding a slice in an inherited profile, depending on the sliceName.",
    )
    label: str | None = Field(
        default=None,
        description="A single preferred label which is the text to display beside the element indicating its meaning or to use to prompt for the element in a user display or form.",
    )
    code: list[Coding] | None = Field(
        default=None,
        description="A code that has the same meaning as the element in a particular terminology.",
    )
    slicing: ElementDefinitionSlicing | None = Field(
        default=None,
        description="Indicates that the element is sliced into a set of alternative definitions (i.e. in a structure definition, there are multiple different constraints on a single element in the base resource). Slicing can be used in any resource that has cardinality ..* on the base resource, or any resource with a choice of types. The set of slices is any elements that come after this in the element sequence that have the same path, until a shorter path occurs (the shorter path terminates the set).",
    )
    short: str | None = Field(
        default=None,
        description="A concise description of what this element means (e.g. for use in autogenerated summaries).",
    )
    definition: str | None = Field(
        default=None,
        description="Provides a complete explanation of the meaning of the data element for human readability. For the case of elements derived from existing elements (e.g. constraints), the definition SHALL be consistent with the base definition, but convey the meaning of the element in the particular context of use of the resource. (Note: The text you are reading is specified in ElementDefinition.definition).",
    )
    comment: str | None = Field(
        default=None,
        description="Explanatory notes and implementation guidance about the data element, including notes about how to use the data properly, exceptions to proper use, etc. (Note: The text you are reading is specified in ElementDefinition.comment).",
    )
    requirements: str | None = Field(
        default=None,
        description="This element is for traceability of why the element was created and why the constraints exist as they do. This may be used to point to source materials or specifications that drove the structure of this element.",
    )
    alias: list[str] | None = Field(
        default=None,
        description="Identifies additional names by which this element might also be known.",
    )
    min: int | float | None = Field(
        default=None,
        description="The minimum number of times this element SHALL appear in the instance.",
    )
    max: str | None = Field(
        default=None,
        description="The maximum number of times this element is permitted to appear in the instance.",
    )
    base: ElementDefinitionBase | None = Field(
        default=None,
        description="Information about the base definition of the element, provided to make it unnecessary for tools to trace the deviation of the element through the derived and related profiles. When the element definition is not the original definition of an element - i.g. either in a constraint on another type, or for elements from a super type in a snap shot - then the information in provided in the element definition may be different to the base definition. On the original definition of the element, it will be same.",
    )
    content_reference: str | None = Field(
        default=None,
        alias="contentReference",
        description="Identifies an element defined elsewhere in the definition whose content rules should be applied to the current element. ContentReferences bring across all the rules that are in the ElementDefinition for the element, including definitions, cardinality constraints, bindings, invariants etc.",
    )
    type: list[ElementDefinitionType] | None = Field(
        default=None,
        description="The data type or resource that the value of this element is permitted to be.",
    )
    default_value_base64_binary: str | None = Field(
        default=None,
        alias="defaultValueBase64Binary",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_boolean: bool | None = Field(
        default=None,
        alias="defaultValueBoolean",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_canonical: str | None = Field(
        default=None,
        alias="defaultValueCanonical",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_code: str | None = Field(
        default=None,
        alias="defaultValueCode",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_date: str | None = Field(
        default=None,
        alias="defaultValueDate",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_date_time: str | None = Field(
        default=None,
        alias="defaultValueDateTime",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_decimal: float | None = Field(
        default=None,
        alias="defaultValueDecimal",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_id: str | None = Field(
        default=None,
        alias="defaultValueId",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_instant: str | None = Field(
        default=None,
        alias="defaultValueInstant",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_integer: int | None = Field(
        default=None,
        alias="defaultValueInteger",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_markdown: str | None = Field(
        default=None,
        alias="defaultValueMarkdown",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_oid: str | None = Field(
        default=None,
        alias="defaultValueOid",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_positive_int: int | None = Field(
        default=None,
        alias="defaultValuePositiveInt",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_string: str | None = Field(
        default=None,
        alias="defaultValueString",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_time: str | None = Field(
        default=None,
        alias="defaultValueTime",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_unsigned_int: int | None = Field(
        default=None,
        alias="defaultValueUnsignedInt",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_uri: str | None = Field(
        default=None,
        alias="defaultValueUri",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_url: str | None = Field(
        default=None,
        alias="defaultValueUrl",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_uuid: str | None = Field(
        default=None,
        alias="defaultValueUuid",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_address: Address | None = Field(
        default=None,
        alias="defaultValueAddress",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_age: Age | None = Field(
        default=None,
        alias="defaultValueAge",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_annotation: Annotation | None = Field(
        default=None,
        alias="defaultValueAnnotation",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_attachment: Attachment | None = Field(
        default=None,
        alias="defaultValueAttachment",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_codeable_concept: CodeableConcept | None = Field(
        default=None,
        alias="defaultValueCodeableConcept",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_coding: Coding | None = Field(
        default=None,
        alias="defaultValueCoding",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_contact_point: ContactPoint | None = Field(
        default=None,
        alias="defaultValueContactPoint",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_count: Count | None = Field(
        default=None,
        alias="defaultValueCount",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_distance: Distance | None = Field(
        default=None,
        alias="defaultValueDistance",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_duration: Duration | None = Field(
        default=None,
        alias="defaultValueDuration",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_human_name: HumanName | None = Field(
        default=None,
        alias="defaultValueHumanName",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_identifier: Identifier | None = Field(
        default=None,
        alias="defaultValueIdentifier",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_money: Money | None = Field(
        default=None,
        alias="defaultValueMoney",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_period: Period | None = Field(
        default=None,
        alias="defaultValuePeriod",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_quantity: Quantity | None = Field(
        default=None,
        alias="defaultValueQuantity",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_range: Range | None = Field(
        default=None,
        alias="defaultValueRange",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_ratio: Ratio | None = Field(
        default=None,
        alias="defaultValueRatio",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_reference: Reference | None = Field(
        default=None,
        alias="defaultValueReference",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_sampled_data: SampledData | None = Field(
        default=None,
        alias="defaultValueSampledData",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_signature: Signature | None = Field(
        default=None,
        alias="defaultValueSignature",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_timing: Timing | None = Field(
        default=None,
        alias="defaultValueTiming",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_contact_detail: ContactDetail | None = Field(
        default=None,
        alias="defaultValueContactDetail",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_contributor: Contributor | None = Field(
        default=None,
        alias="defaultValueContributor",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_data_requirement: DataRequirement | None = Field(
        default=None,
        alias="defaultValueDataRequirement",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_expression: Expression | None = Field(
        default=None,
        alias="defaultValueExpression",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_parameter_definition: ParameterDefinition | None = Field(
        default=None,
        alias="defaultValueParameterDefinition",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_related_artifact: RelatedArtifact | None = Field(
        default=None,
        alias="defaultValueRelatedArtifact",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_trigger_definition: TriggerDefinition | None = Field(
        default=None,
        alias="defaultValueTriggerDefinition",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_usage_context: UsageContext | None = Field(
        default=None,
        alias="defaultValueUsageContext",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_dosage: Dosage | None = Field(
        default=None,
        alias="defaultValueDosage",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    default_value_meta: Meta | None = Field(
        default=None,
        alias="defaultValueMeta",
        description="The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').",
    )
    meaning_when_missing: str | None = Field(
        default=None,
        alias="meaningWhenMissing",
        description="The Implicit meaning that is to be understood when this element is missing (e.g. 'when this element is missing, the period is ongoing').",
    )
    order_meaning: str | None = Field(
        default=None,
        alias="orderMeaning",
        description="If present, indicates that the order of the repeating element has meaning and describes what that meaning is. If absent, it means that the order of the element has no meaning.",
    )
    fixed_base64_binary: str | None = Field(
        default=None,
        alias="fixedBase64Binary",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_boolean: bool | None = Field(
        default=None,
        alias="fixedBoolean",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_canonical: str | None = Field(
        default=None,
        alias="fixedCanonical",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_code: str | None = Field(
        default=None,
        alias="fixedCode",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_date: str | None = Field(
        default=None,
        alias="fixedDate",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_date_time: str | None = Field(
        default=None,
        alias="fixedDateTime",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_decimal: float | None = Field(
        default=None,
        alias="fixedDecimal",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_id: str | None = Field(
        default=None,
        alias="fixedId",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_instant: str | None = Field(
        default=None,
        alias="fixedInstant",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_integer: int | None = Field(
        default=None,
        alias="fixedInteger",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_markdown: str | None = Field(
        default=None,
        alias="fixedMarkdown",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_oid: str | None = Field(
        default=None,
        alias="fixedOid",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_positive_int: int | None = Field(
        default=None,
        alias="fixedPositiveInt",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_string: str | None = Field(
        default=None,
        alias="fixedString",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_time: str | None = Field(
        default=None,
        alias="fixedTime",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_unsigned_int: int | None = Field(
        default=None,
        alias="fixedUnsignedInt",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_uri: str | None = Field(
        default=None,
        alias="fixedUri",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_url: str | None = Field(
        default=None,
        alias="fixedUrl",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_uuid: str | None = Field(
        default=None,
        alias="fixedUuid",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_address: Address | None = Field(
        default=None,
        alias="fixedAddress",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_age: Age | None = Field(
        default=None,
        alias="fixedAge",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_annotation: Annotation | None = Field(
        default=None,
        alias="fixedAnnotation",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_attachment: Attachment | None = Field(
        default=None,
        alias="fixedAttachment",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_codeable_concept: CodeableConcept | None = Field(
        default=None,
        alias="fixedCodeableConcept",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_coding: Coding | None = Field(
        default=None,
        alias="fixedCoding",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_contact_point: ContactPoint | None = Field(
        default=None,
        alias="fixedContactPoint",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_count: Count | None = Field(
        default=None,
        alias="fixedCount",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_distance: Distance | None = Field(
        default=None,
        alias="fixedDistance",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_duration: Duration | None = Field(
        default=None,
        alias="fixedDuration",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_human_name: HumanName | None = Field(
        default=None,
        alias="fixedHumanName",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_identifier: Identifier | None = Field(
        default=None,
        alias="fixedIdentifier",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_money: Money | None = Field(
        default=None,
        alias="fixedMoney",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_period: Period | None = Field(
        default=None,
        alias="fixedPeriod",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_quantity: Quantity | None = Field(
        default=None,
        alias="fixedQuantity",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_range: Range | None = Field(
        default=None,
        alias="fixedRange",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_ratio: Ratio | None = Field(
        default=None,
        alias="fixedRatio",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_reference: Reference | None = Field(
        default=None,
        alias="fixedReference",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_sampled_data: SampledData | None = Field(
        default=None,
        alias="fixedSampledData",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_signature: Signature | None = Field(
        default=None,
        alias="fixedSignature",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_timing: Timing | None = Field(
        default=None,
        alias="fixedTiming",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_contact_detail: ContactDetail | None = Field(
        default=None,
        alias="fixedContactDetail",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_contributor: Contributor | None = Field(
        default=None,
        alias="fixedContributor",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_data_requirement: DataRequirement | None = Field(
        default=None,
        alias="fixedDataRequirement",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_expression: Expression | None = Field(
        default=None,
        alias="fixedExpression",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_parameter_definition: ParameterDefinition | None = Field(
        default=None,
        alias="fixedParameterDefinition",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_related_artifact: RelatedArtifact | None = Field(
        default=None,
        alias="fixedRelatedArtifact",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_trigger_definition: TriggerDefinition | None = Field(
        default=None,
        alias="fixedTriggerDefinition",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_usage_context: UsageContext | None = Field(
        default=None,
        alias="fixedUsageContext",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_dosage: Dosage | None = Field(
        default=None,
        alias="fixedDosage",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    fixed_meta: Meta | None = Field(
        default=None,
        alias="fixedMeta",
        description="Specifies a value that SHALL be exactly the value for this element in the instance. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.",
    )
    pattern_base64_binary: str | None = Field(
        default=None,
        alias="patternBase64Binary",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_boolean: bool | None = Field(
        default=None,
        alias="patternBoolean",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_canonical: str | None = Field(
        default=None,
        alias="patternCanonical",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_code: str | None = Field(
        default=None,
        alias="patternCode",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_date: str | None = Field(
        default=None,
        alias="patternDate",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_date_time: str | None = Field(
        default=None,
        alias="patternDateTime",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_decimal: float | None = Field(
        default=None,
        alias="patternDecimal",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_id: str | None = Field(
        default=None,
        alias="patternId",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_instant: str | None = Field(
        default=None,
        alias="patternInstant",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_integer: int | None = Field(
        default=None,
        alias="patternInteger",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_markdown: str | None = Field(
        default=None,
        alias="patternMarkdown",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_oid: str | None = Field(
        default=None,
        alias="patternOid",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_positive_int: int | None = Field(
        default=None,
        alias="patternPositiveInt",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_string: str | None = Field(
        default=None,
        alias="patternString",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_time: str | None = Field(
        default=None,
        alias="patternTime",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_unsigned_int: int | None = Field(
        default=None,
        alias="patternUnsignedInt",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_uri: str | None = Field(
        default=None,
        alias="patternUri",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_url: str | None = Field(
        default=None,
        alias="patternUrl",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_uuid: str | None = Field(
        default=None,
        alias="patternUuid",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_address: Address | None = Field(
        default=None,
        alias="patternAddress",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_age: Age | None = Field(
        default=None,
        alias="patternAge",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_annotation: Annotation | None = Field(
        default=None,
        alias="patternAnnotation",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_attachment: Attachment | None = Field(
        default=None,
        alias="patternAttachment",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_codeable_concept: CodeableConcept | None = Field(
        default=None,
        alias="patternCodeableConcept",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_coding: Coding | None = Field(
        default=None,
        alias="patternCoding",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_contact_point: ContactPoint | None = Field(
        default=None,
        alias="patternContactPoint",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_count: Count | None = Field(
        default=None,
        alias="patternCount",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_distance: Distance | None = Field(
        default=None,
        alias="patternDistance",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_duration: Duration | None = Field(
        default=None,
        alias="patternDuration",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_human_name: HumanName | None = Field(
        default=None,
        alias="patternHumanName",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_identifier: Identifier | None = Field(
        default=None,
        alias="patternIdentifier",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_money: Money | None = Field(
        default=None,
        alias="patternMoney",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_period: Period | None = Field(
        default=None,
        alias="patternPeriod",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_quantity: Quantity | None = Field(
        default=None,
        alias="patternQuantity",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_range: Range | None = Field(
        default=None,
        alias="patternRange",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_ratio: Ratio | None = Field(
        default=None,
        alias="patternRatio",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_reference: Reference | None = Field(
        default=None,
        alias="patternReference",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_sampled_data: SampledData | None = Field(
        default=None,
        alias="patternSampledData",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_signature: Signature | None = Field(
        default=None,
        alias="patternSignature",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_timing: Timing | None = Field(
        default=None,
        alias="patternTiming",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_contact_detail: ContactDetail | None = Field(
        default=None,
        alias="patternContactDetail",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_contributor: Contributor | None = Field(
        default=None,
        alias="patternContributor",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_data_requirement: DataRequirement | None = Field(
        default=None,
        alias="patternDataRequirement",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_expression: Expression | None = Field(
        default=None,
        alias="patternExpression",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_parameter_definition: ParameterDefinition | None = Field(
        default=None,
        alias="patternParameterDefinition",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_related_artifact: RelatedArtifact | None = Field(
        default=None,
        alias="patternRelatedArtifact",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_trigger_definition: TriggerDefinition | None = Field(
        default=None,
        alias="patternTriggerDefinition",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_usage_context: UsageContext | None = Field(
        default=None,
        alias="patternUsageContext",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_dosage: Dosage | None = Field(
        default=None,
        alias="patternDosage",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    pattern_meta: Meta | None = Field(
        default=None,
        alias="patternMeta",
        description="Specifies a value that the value in the instance SHALL follow - that is, any value in the pattern must be found in the instance. Other additional values may be found too. This is effectively constraint by example. When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly. When pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] array must (recursively) match at least one element from the instance array. When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e., 1. If primitive: it must match exactly the pattern value 2. If a complex object: it must match (recursively) the pattern value 3. If an array: it must match (recursively) the pattern value.",
    )
    example: list[ElementDefinitionExample] | None = Field(
        default=None,
        description="A sample value for this element demonstrating the type of information that would typically be found in the element.",
    )
    min_value_date: str | None = Field(
        default=None,
        alias="minValueDate",
        description="The minimum allowed value for the element. The value is inclusive. This is allowed for the types date, dateTime, instant, time, decimal, integer, and Quantity.",
    )
    min_value_date_time: str | None = Field(
        default=None,
        alias="minValueDateTime",
        description="The minimum allowed value for the element. The value is inclusive. This is allowed for the types date, dateTime, instant, time, decimal, integer, and Quantity.",
    )
    min_value_instant: str | None = Field(
        default=None,
        alias="minValueInstant",
        description="The minimum allowed value for the element. The value is inclusive. This is allowed for the types date, dateTime, instant, time, decimal, integer, and Quantity.",
    )
    min_value_time: str | None = Field(
        default=None,
        alias="minValueTime",
        description="The minimum allowed value for the element. The value is inclusive. This is allowed for the types date, dateTime, instant, time, decimal, integer, and Quantity.",
    )
    min_value_decimal: float | None = Field(
        default=None,
        alias="minValueDecimal",
        description="The minimum allowed value for the element. The value is inclusive. This is allowed for the types date, dateTime, instant, time, decimal, integer, and Quantity.",
    )
    min_value_integer: int | None = Field(
        default=None,
        alias="minValueInteger",
        description="The minimum allowed value for the element. The value is inclusive. This is allowed for the types date, dateTime, instant, time, decimal, integer, and Quantity.",
    )
    min_value_positive_int: int | None = Field(
        default=None,
        alias="minValuePositiveInt",
        description="The minimum allowed value for the element. The value is inclusive. This is allowed for the types date, dateTime, instant, time, decimal, integer, and Quantity.",
    )
    min_value_unsigned_int: int | None = Field(
        default=None,
        alias="minValueUnsignedInt",
        description="The minimum allowed value for the element. The value is inclusive. This is allowed for the types date, dateTime, instant, time, decimal, integer, and Quantity.",
    )
    min_value_quantity: Quantity | None = Field(
        default=None,
        alias="minValueQuantity",
        description="The minimum allowed value for the element. The value is inclusive. This is allowed for the types date, dateTime, instant, time, decimal, integer, and Quantity.",
    )
    max_value_date: str | None = Field(
        default=None,
        alias="maxValueDate",
        description="The maximum allowed value for the element. The value is inclusive. This is allowed for the types date, dateTime, instant, time, decimal, integer, and Quantity.",
    )
    max_value_date_time: str | None = Field(
        default=None,
        alias="maxValueDateTime",
        description="The maximum allowed value for the element. The value is inclusive. This is allowed for the types date, dateTime, instant, time, decimal, integer, and Quantity.",
    )
    max_value_instant: str | None = Field(
        default=None,
        alias="maxValueInstant",
        description="The maximum allowed value for the element. The value is inclusive. This is allowed for the types date, dateTime, instant, time, decimal, integer, and Quantity.",
    )
    max_value_time: str | None = Field(
        default=None,
        alias="maxValueTime",
        description="The maximum allowed value for the element. The value is inclusive. This is allowed for the types date, dateTime, instant, time, decimal, integer, and Quantity.",
    )
    max_value_decimal: float | None = Field(
        default=None,
        alias="maxValueDecimal",
        description="The maximum allowed value for the element. The value is inclusive. This is allowed for the types date, dateTime, instant, time, decimal, integer, and Quantity.",
    )
    max_value_integer: int | None = Field(
        default=None,
        alias="maxValueInteger",
        description="The maximum allowed value for the element. The value is inclusive. This is allowed for the types date, dateTime, instant, time, decimal, integer, and Quantity.",
    )
    max_value_positive_int: int | None = Field(
        default=None,
        alias="maxValuePositiveInt",
        description="The maximum allowed value for the element. The value is inclusive. This is allowed for the types date, dateTime, instant, time, decimal, integer, and Quantity.",
    )
    max_value_unsigned_int: int | None = Field(
        default=None,
        alias="maxValueUnsignedInt",
        description="The maximum allowed value for the element. The value is inclusive. This is allowed for the types date, dateTime, instant, time, decimal, integer, and Quantity.",
    )
    max_value_quantity: Quantity | None = Field(
        default=None,
        alias="maxValueQuantity",
        description="The maximum allowed value for the element. The value is inclusive. This is allowed for the types date, dateTime, instant, time, decimal, integer, and Quantity.",
    )
    max_length: int | float | None = Field(
        default=None,
        alias="maxLength",
        description="Indicates the maximum length in characters that is permitted to be present in conformant instances and which is expected to be supported by conformant consumers that support the element.",
    )
    condition: list[str] | None = Field(
        default=None,
        description="A reference to an invariant that may make additional statements about the cardinality or value in the instance.",
    )
    constraint: list[ElementDefinitionConstraint] | None = Field(
        default=None,
        description="Formal constraints such as co-occurrence and other constraints that can be computationally evaluated within the context of the instance.",
    )
    must_support: bool | None = Field(
        default=None,
        alias="mustSupport",
        description="If true, implementations that produce or consume resources SHALL provide &quot;support&quot; for the element in some meaningful way. If false, the element may be ignored and not supported. If false, whether to populate or use the data element in any way is at the discretion of the implementation.",
    )
    is_modifier: bool | None = Field(
        default=None,
        alias="isModifier",
        description="If true, the value of this element affects the interpretation of the element or resource that contains it, and the value of the element cannot be ignored. Typically, this is used for status, negation and qualification codes. The effect of this is that the element cannot be ignored by systems: they SHALL either recognize the element and process it, and/or a pre-determination has been made that it is not relevant to their particular system.",
    )
    is_modifier_reason: str | None = Field(
        default=None,
        alias="isModifierReason",
        description="Explains how that element affects the interpretation of the resource or element that contains it.",
    )
    is_summary: bool | None = Field(
        default=None,
        alias="isSummary",
        description="Whether the element should be included if a client requests a search with the parameter _summary=true.",
    )
    binding: ElementDefinitionBinding | None = Field(
        default=None,
        description="Binds to a value set if this element is coded (code, Coding, CodeableConcept, Quantity), or the data types (string, uri).",
    )
    mapping: list[ElementDefinitionMapping] | None = Field(
        default=None,
        description="Identifies a concept from an external specification that roughly corresponds to this element.",
    )


class ElementDefinitionBase(MedplumFHIRBase):
    """Information about the base definition of the element, provided to make
    it unnecessary for tools to trace the deviation of the element through
    the derived and related profiles. When the element definition is not the
    original definition of an element - i.g. either in a constraint on
    another type, or for elements from a super type in a snap shot - then
    the information in provided in the element definition may be different
    to the base definition. On the original definition of the element, it
    will be same.
    """

    id: str | None = Field(
        default=None,
        description="Unique id for the element within a resource (for internal references). This may be any string value that does not contain spaces.",
    )
    extension: list[Extension] | None = Field(
        default=None,
        description="May be used to represent additional information that is not part of the basic definition of the element. To make the use of extensions safe and manageable, there is a strict set of governance applied to the definition and use of extensions. Though any implementer can define an extension, there is a set of requirements that SHALL be met as part of the definition of the extension.",
    )
    path: str = Field(
        default=...,
        description="The Path that identifies the base element - this matches the ElementDefinition.path for that element. Across FHIR, there is only one base definition of any element - that is, an element definition on a [StructureDefinition](structuredefinition.html#) without a StructureDefinition.base.",
    )
    min: int | float = Field(
        default=...,
        description="Minimum cardinality of the base element identified by the path.",
    )
    max: str = Field(
        default=...,
        description="Maximum cardinality of the base element identified by the path.",
    )


class ElementDefinitionBinding(MedplumFHIRBase):
    """Binds to a value set if this element is coded (code, Coding,
    CodeableConcept, Quantity), or the data types (string, uri).
    """

    id: str | None = Field(
        default=None,
        description="Unique id for the element within a resource (for internal references). This may be any string value that does not contain spaces.",
    )
    extension: list[Extension] | None = Field(
        default=None,
        description="May be used to represent additional information that is not part of the basic definition of the element. To make the use of extensions safe and manageable, there is a strict set of governance applied to the definition and use of extensions. Though any implementer can define an extension, there is a set of requirements that SHALL be met as part of the definition of the extension.",
    )
    strength: Literal["required", "extensible", "preferred", "example"] = Field(
        default=...,
        description="Indicates the degree of conformance expectations associated with this binding - that is, the degree to which the provided value set must be adhered to in the instances.",
    )
    description: str | None = Field(
        default=None,
        description="Describes the intended use of this particular set of codes.",
    )
    value_set: str | None = Field(
        default=None,
        alias="valueSet",
        description="Refers to the value set that identifies the set of codes the binding refers to.",
    )


class ElementDefinitionConstraint(MedplumFHIRBase):
    """Formal constraints such as co-occurrence and other constraints that can
    be computationally evaluated within the context of the instance.
    """

    id: str | None = Field(
        default=None,
        description="Unique id for the element within a resource (for internal references). This may be any string value that does not contain spaces.",
    )
    extension: list[Extension] | None = Field(
        default=None,
        description="May be used to represent additional information that is not part of the basic definition of the element. To make the use of extensions safe and manageable, there is a strict set of governance applied to the definition and use of extensions. Though any implementer can define an extension, there is a set of requirements that SHALL be met as part of the definition of the extension.",
    )
    key: str = Field(
        default=...,
        description="Allows identification of which elements have their cardinalities impacted by the constraint. Will not be referenced for constraints that do not affect cardinality.",
    )
    requirements: str | None = Field(
        default=None,
        description="Description of why this constraint is necessary or appropriate.",
    )
    severity: Literal["error", "warning"] = Field(
        default=...,
        description="Identifies the impact constraint violation has on the conformance of the instance.",
    )
    human: str = Field(
        default=...,
        description="Text that can be used to describe the constraint in messages identifying that the constraint has been violated.",
    )
    expression: str | None = Field(
        default=None,
        description="A [FHIRPath](fhirpath.html) expression of constraint that can be executed to see if this constraint is met.",
    )
    xpath: str | None = Field(
        default=None,
        description="An XPath expression of constraint that can be executed to see if this constraint is met.",
    )
    source: str | None = Field(
        default=None,
        description="A reference to the original source of the constraint, for traceability purposes.",
    )


class ElementDefinitionExample(MedplumFHIRBase):
    """A sample value for this element demonstrating the type of information
    that would typically be found in the element.
    """

    id: str | None = Field(
        default=None,
        description="Unique id for the element within a resource (for internal references). This may be any string value that does not contain spaces.",
    )
    extension: list[Extension] | None = Field(
        default=None,
        description="May be used to represent additional information that is not part of the basic definition of the element. To make the use of extensions safe and manageable, there is a strict set of governance applied to the definition and use of extensions. Though any implementer can define an extension, there is a set of requirements that SHALL be met as part of the definition of the extension.",
    )
    label: str = Field(
        default=...,
        description="Describes the purpose of this example amoung the set of examples.",
    )
    value_base64_binary: str | None = Field(
        default=None,
        alias="valueBase64Binary",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_boolean: bool | None = Field(
        default=None,
        alias="valueBoolean",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_canonical: str | None = Field(
        default=None,
        alias="valueCanonical",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_code: str | None = Field(
        default=None,
        alias="valueCode",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_date: str | None = Field(
        default=None,
        alias="valueDate",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_date_time: str | None = Field(
        default=None,
        alias="valueDateTime",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_decimal: float | None = Field(
        default=None,
        alias="valueDecimal",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_id: str | None = Field(
        default=None,
        alias="valueId",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_instant: str | None = Field(
        default=None,
        alias="valueInstant",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_integer: int | None = Field(
        default=None,
        alias="valueInteger",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_markdown: str | None = Field(
        default=None,
        alias="valueMarkdown",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_oid: str | None = Field(
        default=None,
        alias="valueOid",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_positive_int: int | None = Field(
        default=None,
        alias="valuePositiveInt",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_string: str | None = Field(
        default=None,
        alias="valueString",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_time: str | None = Field(
        default=None,
        alias="valueTime",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_unsigned_int: int | None = Field(
        default=None,
        alias="valueUnsignedInt",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_uri: str | None = Field(
        default=None,
        alias="valueUri",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_url: str | None = Field(
        default=None,
        alias="valueUrl",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_uuid: str | None = Field(
        default=None,
        alias="valueUuid",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_address: Address | None = Field(
        default=None,
        alias="valueAddress",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_age: Age | None = Field(
        default=None,
        alias="valueAge",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_annotation: Annotation | None = Field(
        default=None,
        alias="valueAnnotation",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_attachment: Attachment | None = Field(
        default=None,
        alias="valueAttachment",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_codeable_concept: CodeableConcept | None = Field(
        default=None,
        alias="valueCodeableConcept",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_coding: Coding | None = Field(
        default=None,
        alias="valueCoding",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_contact_point: ContactPoint | None = Field(
        default=None,
        alias="valueContactPoint",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_count: Count | None = Field(
        default=None,
        alias="valueCount",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_distance: Distance | None = Field(
        default=None,
        alias="valueDistance",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_duration: Duration | None = Field(
        default=None,
        alias="valueDuration",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_human_name: HumanName | None = Field(
        default=None,
        alias="valueHumanName",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_identifier: Identifier | None = Field(
        default=None,
        alias="valueIdentifier",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_money: Money | None = Field(
        default=None,
        alias="valueMoney",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_period: Period | None = Field(
        default=None,
        alias="valuePeriod",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_quantity: Quantity | None = Field(
        default=None,
        alias="valueQuantity",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_range: Range | None = Field(
        default=None,
        alias="valueRange",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_ratio: Ratio | None = Field(
        default=None,
        alias="valueRatio",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_reference: Reference | None = Field(
        default=None,
        alias="valueReference",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_sampled_data: SampledData | None = Field(
        default=None,
        alias="valueSampledData",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_signature: Signature | None = Field(
        default=None,
        alias="valueSignature",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_timing: Timing | None = Field(
        default=None,
        alias="valueTiming",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_contact_detail: ContactDetail | None = Field(
        default=None,
        alias="valueContactDetail",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_contributor: Contributor | None = Field(
        default=None,
        alias="valueContributor",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_data_requirement: DataRequirement | None = Field(
        default=None,
        alias="valueDataRequirement",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_expression: Expression | None = Field(
        default=None,
        alias="valueExpression",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_parameter_definition: ParameterDefinition | None = Field(
        default=None,
        alias="valueParameterDefinition",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_related_artifact: RelatedArtifact | None = Field(
        default=None,
        alias="valueRelatedArtifact",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_trigger_definition: TriggerDefinition | None = Field(
        default=None,
        alias="valueTriggerDefinition",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_usage_context: UsageContext | None = Field(
        default=None,
        alias="valueUsageContext",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_dosage: Dosage | None = Field(
        default=None,
        alias="valueDosage",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )
    value_meta: Meta | None = Field(
        default=None,
        alias="valueMeta",
        description="The actual value for the element, which must be one of the types allowed for this element.",
    )


class ElementDefinitionMapping(MedplumFHIRBase):
    """Identifies a concept from an external specification that roughly
    corresponds to this element.
    """

    id: str | None = Field(
        default=None,
        description="Unique id for the element within a resource (for internal references). This may be any string value that does not contain spaces.",
    )
    extension: list[Extension] | None = Field(
        default=None,
        description="May be used to represent additional information that is not part of the basic definition of the element. To make the use of extensions safe and manageable, there is a strict set of governance applied to the definition and use of extensions. Though any implementer can define an extension, there is a set of requirements that SHALL be met as part of the definition of the extension.",
    )
    identity: str = Field(
        default=..., description="An internal reference to the definition of a mapping."
    )
    language: str | None = Field(
        default=None,
        description="Identifies the computable language in which mapping.map is expressed.",
    )
    map: str = Field(
        default=...,
        description="Expresses what part of the target specification corresponds to this element.",
    )
    comment: str | None = Field(
        default=None,
        description="Comments that provide information about the mapping or its use.",
    )


class ElementDefinitionSlicing(MedplumFHIRBase):
    """Indicates that the element is sliced into a set of alternative
    definitions (i.e. in a structure definition, there are multiple
    different constraints on a single element in the base resource). Slicing
    can be used in any resource that has cardinality ..* on the base
    resource, or any resource with a choice of types. The set of slices is
    any elements that come after this in the element sequence that have the
    same path, until a shorter path occurs (the shorter path terminates the
    set).
    """

    id: str | None = Field(
        default=None,
        description="Unique id for the element within a resource (for internal references). This may be any string value that does not contain spaces.",
    )
    extension: list[Extension] | None = Field(
        default=None,
        description="May be used to represent additional information that is not part of the basic definition of the element. To make the use of extensions safe and manageable, there is a strict set of governance applied to the definition and use of extensions. Though any implementer can define an extension, there is a set of requirements that SHALL be met as part of the definition of the extension.",
    )
    discriminator: list[ElementDefinitionSlicingDiscriminator] | None = Field(
        default=None,
        description="Designates which child elements are used to discriminate between the slices when processing an instance. If one or more discriminators are provided, the value of the child elements in the instance data SHALL completely distinguish which slice the element in the resource matches based on the allowed values for those elements in each of the slices.",
    )
    description: str | None = Field(
        default=None,
        description="A human-readable text description of how the slicing works. If there is no discriminator, this is required to be present to provide whatever information is possible about how the slices can be differentiated.",
    )
    ordered: bool | None = Field(
        default=None,
        description="If the matching elements have to occur in the same order as defined in the profile.",
    )
    rules: Literal["closed", "open", "openAtEnd"] = Field(
        default=...,
        description="Whether additional slices are allowed or not. When the slices are ordered, profile authors can also say that additional slices are only allowed at the end.",
    )


class ElementDefinitionSlicingDiscriminator(MedplumFHIRBase):
    """Designates which child elements are used to discriminate between the
    slices when processing an instance. If one or more discriminators are
    provided, the value of the child elements in the instance data SHALL
    completely distinguish which slice the element in the resource matches
    based on the allowed values for those elements in each of the slices.
    """

    id: str | None = Field(
        default=None,
        description="Unique id for the element within a resource (for internal references). This may be any string value that does not contain spaces.",
    )
    extension: list[Extension] | None = Field(
        default=None,
        description="May be used to represent additional information that is not part of the basic definition of the element. To make the use of extensions safe and manageable, there is a strict set of governance applied to the definition and use of extensions. Though any implementer can define an extension, there is a set of requirements that SHALL be met as part of the definition of the extension.",
    )
    type: Literal["value", "exists", "pattern", "type", "profile"] = Field(
        default=...,
        description="How the element value is interpreted when discrimination is evaluated.",
    )
    path: str = Field(
        default=...,
        description="A FHIRPath expression, using [the simple subset of FHIRPath](fhirpath.html#simple), that is used to identify the element on which discrimination is based.",
    )


class ElementDefinitionType(MedplumFHIRBase):
    """The data type or resource that the value of this element is permitted to be."""

    id: str | None = Field(
        default=None,
        description="Unique id for the element within a resource (for internal references). This may be any string value that does not contain spaces.",
    )
    extension: list[Extension] | None = Field(
        default=None,
        description="May be used to represent additional information that is not part of the basic definition of the element. To make the use of extensions safe and manageable, there is a strict set of governance applied to the definition and use of extensions. Though any implementer can define an extension, there is a set of requirements that SHALL be met as part of the definition of the extension.",
    )
    code: str = Field(
        default=...,
        description="URL of Data type or Resource that is a(or the) type used for this element. References are URLs that are relative to http://hl7.org/fhir/StructureDefinition e.g. &quot;string&quot; is a reference to http://hl7.org/fhir/StructureDefinition/string. Absolute URLs are only allowed in logical models.",
    )
    profile: list[str] | None = Field(
        default=None,
        description="Identifies a profile structure or implementation Guide that applies to the datatype this element refers to. If any profiles are specified, then the content must conform to at least one of them. The URL can be a local reference - to a contained StructureDefinition, or a reference to another StructureDefinition or Implementation Guide by a canonical URL. When an implementation guide is specified, the type SHALL conform to at least one profile defined in the implementation guide.",
    )
    target_profile: list[str] | None = Field(
        default=None,
        alias="targetProfile",
        description="Used when the type is &quot;Reference&quot; or &quot;canonical&quot;, and identifies a profile structure or implementation Guide that applies to the target of the reference this element refers to. If any profiles are specified, then the content must conform to at least one of them. The URL can be a local reference - to a contained StructureDefinition, or a reference to another StructureDefinition or Implementation Guide by a canonical URL. When an implementation guide is specified, the target resource SHALL conform to at least one profile defined in the implementation guide.",
    )
    aggregation: list[Literal["contained", "referenced", "bundled"]] | None = Field(
        default=None,
        description="If the type is a reference to another resource, how the resource is or can be aggregated - is it a contained resource, or a reference, and if the context is a bundle, is it included in the bundle.",
    )
    versioning: Literal["either", "independent", "specific"] | None = Field(
        default=None,
        description="Whether this reference needs to be version specific or version independent, or whether either can be used.",
    )
