"""Tests for RemoveFutureImports recipe."""

from rewrite.test import RecipeSpec, python

from openrewrite_migrate_python.migrate.future_imports import RemoveFutureImports

class TestRemoveFutureImports:
    """Tests for RemoveFutureImports recipe."""

    def test_removes_print_function(self):
        spec = RecipeSpec(recipe=RemoveFutureImports())
        spec.rewrite_run(
            python(
                "from __future__ import print_function",
                "",
            )
        )

    def test_removes_division(self):
        spec = RecipeSpec(recipe=RemoveFutureImports())
        spec.rewrite_run(
            python(
                "from __future__ import division",
                "",
            )
        )

    def test_removes_unicode_literals(self):
        spec = RecipeSpec(recipe=RemoveFutureImports())
        spec.rewrite_run(
            python(
                "from __future__ import unicode_literals",
                "",
            )
        )

    def test_removes_absolute_import(self):
        spec = RecipeSpec(recipe=RemoveFutureImports())
        spec.rewrite_run(
            python(
                "from __future__ import absolute_import",
                "",
            )
        )

    def test_removes_generators(self):
        spec = RecipeSpec(recipe=RemoveFutureImports())
        spec.rewrite_run(
            python(
                "from __future__ import generators",
                "",
            )
        )

    def test_removes_nested_scopes(self):
        spec = RecipeSpec(recipe=RemoveFutureImports())
        spec.rewrite_run(
            python(
                "from __future__ import nested_scopes",
                "",
            )
        )

    def test_removes_with_statement(self):
        spec = RecipeSpec(recipe=RemoveFutureImports())
        spec.rewrite_run(
            python(
                "from __future__ import with_statement",
                "",
            )
        )

    def test_removes_multiple_obsolete(self):
        spec = RecipeSpec(recipe=RemoveFutureImports())
        spec.rewrite_run(
            python(
                "from __future__ import print_function, division, unicode_literals",
                "",
            )
        )

    def test_keeps_annotations(self):
        spec = RecipeSpec(recipe=RemoveFutureImports())
        spec.rewrite_run(
            python("from __future__ import annotations")
        )

    def test_removes_obsolete_keeps_annotations(self):
        spec = RecipeSpec(recipe=RemoveFutureImports())
        spec.rewrite_run(
            python(
                "from __future__ import print_function, annotations",
                "from __future__ import annotations",
            )
        )

    def test_keeps_annotations_first_removes_trailing(self):
        """When kept import comes first, trailing obsolete imports are removed."""
        spec = RecipeSpec(recipe=RemoveFutureImports())
        spec.rewrite_run(
            python(
                "from __future__ import annotations, division",
                "from __future__ import annotations",
            )
        )

    def test_no_change_non_future_import(self):
        spec = RecipeSpec(recipe=RemoveFutureImports())
        spec.rewrite_run(
            python("from os import path")
        )

    def test_no_change_regular_import(self):
        spec = RecipeSpec(recipe=RemoveFutureImports())
        spec.rewrite_run(
            python("import os")
        )
