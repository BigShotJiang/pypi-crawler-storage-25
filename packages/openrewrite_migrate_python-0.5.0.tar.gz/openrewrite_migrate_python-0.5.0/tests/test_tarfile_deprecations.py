"""Tests for tarfile.filemode → stat.filemode replacement recipe."""

from rewrite.test import RecipeSpec, python

from openrewrite_migrate_python.migrate.tarfile_deprecations import ReplaceTarfileFilemode

class TestReplaceTarfileFilemode:
    """Tests for ReplaceTarfileFilemode recipe."""

    def test_replaces_tarfile_filemode_call(self):
        spec = RecipeSpec(recipe=ReplaceTarfileFilemode())
        spec.rewrite_run(
            python(
                """
                import tarfile
                mode_str = tarfile.filemode(mode)
                """,
                """
                import tarfile
                mode_str = stat.filemode(mode)
                """,
            )
        )

    def test_replaces_tarfile_filemode_field_access(self):
        spec = RecipeSpec(recipe=ReplaceTarfileFilemode())
        spec.rewrite_run(
            python(
                """
                import tarfile
                f = tarfile.filemode
                """,
                """
                import tarfile
                f = stat.filemode
                """,
            )
        )

    def test_no_change_when_already_stat(self):
        spec = RecipeSpec(recipe=ReplaceTarfileFilemode())
        spec.rewrite_run(
            python(
                """
                import stat
                mode = stat.filemode(0o755)
                """
            )
        )

    def test_no_change_when_different_module(self):
        spec = RecipeSpec(recipe=ReplaceTarfileFilemode())
        spec.rewrite_run(
            python("mode = other.filemode(0o755)")
        )
