"""Tests for platform.popen() → subprocess.check_output() replacement recipe."""

from rewrite.test import RecipeSpec, python

from openrewrite_migrate_python.migrate.platform_deprecations import ReplacePlatformPopen

class TestReplacePlatformPopen:
    """Tests for ReplacePlatformPopen recipe."""

    def test_replaces_platform_popen(self):
        spec = RecipeSpec(recipe=ReplacePlatformPopen())
        spec.rewrite_run(
            python(
                """
                import platform
                output = platform.popen('ls')
                """,
                """
                import platform
                output = subprocess.check_output('ls', shell=True)
                """,
            )
        )

    def test_no_change_when_not_platform_popen(self):
        spec = RecipeSpec(recipe=ReplacePlatformPopen())
        spec.rewrite_run(
            python(
                """
                import os
                output = os.popen('ls').read()
                """
            )
        )

    def test_no_change_when_already_subprocess(self):
        spec = RecipeSpec(recipe=ReplacePlatformPopen())
        spec.rewrite_run(
            python(
                """
                import subprocess
                output = subprocess.check_output('ls', shell=True)
                """
            )
        )
