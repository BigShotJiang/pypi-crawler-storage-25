"""Tests for re.template() / re.TEMPLATE deprecation recipe."""

from rewrite.test import RecipeSpec, python

from openrewrite_migrate_python.migrate.re_deprecations import ReplaceReTemplate

class TestReplaceReTemplate:
    """Tests for ReplaceReTemplate recipe."""

    def test_replaces_re_template_call(self):
        spec = RecipeSpec(recipe=ReplaceReTemplate())
        spec.rewrite_run(
            python(
                """
                import re
                pattern = re.template(r'\\d+')
                """,
                """
                import re
                pattern = re.compile(r'\\d+')
                """,
            )
        )

    def test_marks_re_TEMPLATE_constant(self):
        spec = RecipeSpec(recipe=ReplaceReTemplate())
        spec.rewrite_run(
            python(
                """
                import re
                flags = re.TEMPLATE
                """,
                """
                import re
                flags = /*~~(re.TEMPLATE was deprecated in Python 3.11 and removed in 3.13.)~~>*/re.TEMPLATE
                """,
            )
        )

    def test_marks_re_T_constant(self):
        spec = RecipeSpec(recipe=ReplaceReTemplate())
        spec.rewrite_run(
            python(
                """
                import re
                flags = re.T
                """,
                """
                import re
                flags = /*~~(re.T was deprecated in Python 3.11 and removed in 3.13.)~~>*/re.T
                """,
            )
        )

    def test_no_change_when_using_compile(self):
        spec = RecipeSpec(recipe=ReplaceReTemplate())
        spec.rewrite_run(
            python(
                """
                import re
                pattern = re.compile(r'\\d+')
                """
            )
        )

    def test_no_change_when_different_module(self):
        spec = RecipeSpec(recipe=ReplaceReTemplate())
        spec.rewrite_run(
            python("pattern = other.template(r'\\d+')")
        )
