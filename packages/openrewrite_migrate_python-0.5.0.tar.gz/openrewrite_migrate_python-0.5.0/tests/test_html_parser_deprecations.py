"""Tests for HTMLParser.unescape() → html.unescape() replacement recipe."""

from rewrite.test import RecipeSpec, python

from openrewrite_migrate_python.migrate.html_parser_deprecations import (
    ReplaceHtmlParserUnescape,
)

class TestReplaceHtmlParserUnescape:
    """Tests for ReplaceHtmlParserUnescape recipe."""

    def test_replaces_parser_unescape(self):
        spec = RecipeSpec(recipe=ReplaceHtmlParserUnescape())
        spec.rewrite_run(
            python(
                """
                from html.parser import HTMLParser
                parser = HTMLParser()
                text = parser.unescape(html_text)
                """,
                """
                from html.parser import HTMLParser
                parser = HTMLParser()
                text = html.unescape(html_text)
                """,
            )
        )

    def test_no_change_when_using_html_unescape(self):
        spec = RecipeSpec(recipe=ReplaceHtmlParserUnescape())
        spec.rewrite_run(
            python(
                """
                import html
                text = html.unescape(html_text)
                """
            )
        )

    def test_no_change_when_no_select(self):
        spec = RecipeSpec(recipe=ReplaceHtmlParserUnescape())
        spec.rewrite_run(
            python(
                """
                def unescape(s):
                    return s
                text = unescape(html_text)
                """
            )
        )

    def test_replaces_with_dynamic_import(self):
        """Type attribution resolves through importlib.import_module."""
        spec = RecipeSpec(recipe=ReplaceHtmlParserUnescape())
        spec.rewrite_run(
            python(
                """
                import importlib
                mod = importlib.import_module('html.parser')
                parser = mod.HTMLParser()
                text = parser.unescape(html_text)
                """,
                """
                import importlib
                mod = importlib.import_module('html.parser')
                parser = mod.HTMLParser()
                text = html.unescape(html_text)
                """,
            )
        )

    def test_no_change_with_typo_in_dynamic_import(self):
        """Typo in module string — type attribution can't resolve, no transform."""
        spec = RecipeSpec(recipe=ReplaceHtmlParserUnescape())
        spec.rewrite_run(
            python(
                """
                import importlib
                mod = importlib.import_module('htmll.parser')
                parser = mod.HTMLParser()
                text = parser.unescape(html_text)
                """
            )
        )
