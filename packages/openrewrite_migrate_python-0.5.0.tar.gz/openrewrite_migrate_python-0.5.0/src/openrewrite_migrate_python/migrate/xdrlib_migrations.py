"""
Recipes for migrating from the deprecated xdrlib module.

The xdrlib module was deprecated in Python 3.11 (PEP 594) and removed
in Python 3.13.

Alternatives:
- Use `struct` module for binary data packing/unpacking
- Use third-party libraries for XDR protocol support

See: https://peps.python.org/pep-0594/
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.python.tree import MultiImport, Import
from rewrite.java.tree import Identifier, FieldAccess
from ._markers import mark_deprecated

# Define category path: Python > Migrate > Python 3.13
_Python313 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.13"),
]


def _get_import_name(import_node: Any) -> Optional[str]:
    """Extract the module name from an import node's qualid."""
    qualid = import_node.qualid
    if isinstance(qualid, FieldAccess):
        return qualid.name.simple_name
    if isinstance(qualid, Identifier):
        return qualid.simple_name
    return None


@categorize(_Python313)
class FindXdrlibModule(Recipe):
    """
    Find imports of the deprecated `xdrlib` module.

    The `xdrlib` module (XDR data encoding/decoding) was deprecated in
    Python 3.11 and removed in Python 3.13 as part of PEP 594.

    Alternatives:
    - Use `struct` module for binary data packing
    - Use third-party XDR libraries if needed

    See: https://peps.python.org/pep-0594/
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.FindXdrlibModule"

    @property
    def display_name(self) -> str:
        return "Find deprecated `xdrlib` module usage"

    @property
    def description(self) -> str:
        return (
            "The `xdrlib` module was deprecated in Python 3.11 and removed in "
            "Python 3.13. Use `struct` module for binary packing/unpacking."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.13", "PEP 594"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_multi_import(
                self, multi: MultiImport, p: ExecutionContext
            ) -> Optional[MultiImport]:
                multi = super().visit_multi_import(multi, p)

                from_part = multi.from_
                if from_part is not None:
                    if isinstance(from_part, Identifier) and from_part.simple_name == "xdrlib":
                        return mark_deprecated(
                            multi,
                            "The `xdrlib` module was removed in Python 3.13. "
                            "Use `struct` module for binary packing."
                        )
                else:
                    for import_node in multi.names:
                        name = _get_import_name(import_node)
                        if name == "xdrlib":
                            return mark_deprecated(
                                multi,
                                "The `xdrlib` module was removed in Python 3.13. "
                                "Use `struct` module for binary packing."
                            )

                return multi

            def visit_import(
                self, import_stmt: Import, p: ExecutionContext
            ) -> Optional[Import]:
                import_stmt = super().visit_import(import_stmt, p)
                if self.cursor.first_enclosing(MultiImport) is not None:
                    return import_stmt
                name = _get_import_name(import_stmt)
                if name == "xdrlib":
                    return mark_deprecated(
                        import_stmt,
                        "The `xdrlib` module was removed in Python 3.13. "
                        "Use `struct` module for binary packing."
                    )
                return import_stmt

        return Visitor()
