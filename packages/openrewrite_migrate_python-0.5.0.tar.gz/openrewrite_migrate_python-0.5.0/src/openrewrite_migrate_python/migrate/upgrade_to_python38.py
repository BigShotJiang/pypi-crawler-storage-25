"""Composite recipe for upgrading to Python 3.8."""

from typing import List

from rewrite import Recipe
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.recipes import ChangeImport

# Define category path: Python > Migrate
_Migrate = [*Python, CategoryDescriptor(display_name="Migrate")]


@categorize(_Migrate)
class UpgradeToPython38(Recipe):
    """
    Migrate deprecated APIs and detect legacy patterns for Python 3.8 compatibility.

    This composite recipe applies migrations for code targeting Python 3.8.

    Key changes:
    - Replace `time.clock()` with `time.perf_counter()`
    - Replace `cgi.escape()` with `html.escape()`
    - Replace `cgi.parse_qs()` / `cgi.parse_qsl()` with `urllib.parse` equivalents
    - Replace `platform.popen()` with `subprocess.check_output()`
    - Replace `tarfile.filemode` with `stat.filemode`
    - Remove obsolete `__future__` imports (print_function, division, etc.)
    - Detect removed `macpath` module usage
    - Detect removed `sys.set_coroutine_wrapper()` / `sys.get_coroutine_wrapper()`
    - Detect legacy string formatting (% formatting, str.format())
    - Detect deprecated `functools.cmp_to_key()` usage

    See: https://docs.python.org/3/whatsnew/3.8.html
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.UpgradeToPython38"

    @property
    def display_name(self) -> str:
        return "Upgrade to Python 3.8"

    @property
    def description(self) -> str:
        return (
            "Migrate deprecated APIs and detect legacy patterns for Python 3.8 compatibility."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.8"]

    def recipe_list(self) -> List[Recipe]:
        """Return the list of recipes to apply for Python 3.8 upgrade."""
        from .cgi_parse_deprecations import ReplaceCgiParseQs, ReplaceCgiParseQsl
        from .functools_deprecations import FindFunctoolsCmpToKey
        from .future_imports import RemoveFutureImports
        from .macpath_deprecations import FindMacpathModule
        from .platform_deprecations import ReplacePlatformPopen
        from .string_formatting import ReplacePercentFormatWithFString, ReplaceStrFormatWithFString
        from .sys_deprecations import FindSysCoroutineWrapper
        from .tarfile_deprecations import ReplaceTarfileFilemode
        return [
            # Auto-fix: time.clock() -> time.perf_counter()
            ChangeImport(old_module="time", old_name="clock", new_module="time", new_name="perf_counter"),
            # Auto-fix: cgi.escape() -> html.escape()
            ChangeImport(old_module="cgi", old_name="escape", new_module="html"),
            # Auto-fix: cgi.parse_qs() -> urllib.parse.parse_qs() (from import form)
            ChangeImport(old_module="cgi", old_name="parse_qs", new_module="urllib.parse"),
            # Auto-fix: cgi.parse_qsl() -> urllib.parse.parse_qsl() (from import form)
            ChangeImport(old_module="cgi", old_name="parse_qsl", new_module="urllib.parse"),
            # Auto-fix: cgi.parse_qs() / cgi.parse_qsl() (qualified call form)
            ReplaceCgiParseQs(),
            ReplaceCgiParseQsl(),
            # Auto-fix: platform.popen() -> subprocess.check_output()
            ReplacePlatformPopen(),
            # Detect removed macpath module
            FindMacpathModule(),
            # Auto-fix: tarfile.filemode -> stat.filemode
            ReplaceTarfileFilemode(),
            # Auto-fix: from tarfile import filemode -> from stat import filemode
            ChangeImport(old_module="tarfile", old_name="filemode", new_module="stat"),
            # Detect removed sys.set_coroutine_wrapper()/get_coroutine_wrapper()
            FindSysCoroutineWrapper(),

            # String formatting migrations
            ReplaceStrFormatWithFString(),
            ReplacePercentFormatWithFString(),
            # functools.cmp_to_key deprecated
            FindFunctoolsCmpToKey(),
            # Remove obsolete __future__ imports
            RemoveFutureImports(),
        ]
