"""
Recipe for finding imports of the removed macpath module.

The macpath module was deprecated in Python 3.7 and removed in Python 3.8.

See: https://docs.python.org/3/whatsnew/3.8.html#api-and-feature-removals
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.python.tree import MultiImport, Import
from rewrite.java.tree import FieldAccess, Identifier
from ._markers import mark_deprecated

# Define category path: Python > Migrate > Python 3.8
_Python38 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.8"),
]


def _get_import_name(import_node: Any) -> Optional[str]:
    """Extract the module name from an import node's qualid."""
    qualid = import_node.qualid
    if isinstance(qualid, FieldAccess):
        return qualid.name.simple_name
    if isinstance(qualid, Identifier):
        return qualid.simple_name
    return None


@categorize(_Python38)
class FindMacpathModule(Recipe):
    """
    Find imports of the removed `macpath` module.

    The `macpath` module was deprecated in Python 3.7 and removed in Python 3.8.
    Use `os.path` instead.

    Example:
        Before:
            import macpath

        After:
            import os.path
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.FindMacpathModule"

    @property
    def display_name(self) -> str:
        return "Find removed `macpath` module usage"

    @property
    def description(self) -> str:
        return (
            "The `macpath` module was removed in Python 3.8. "
            "Use `os.path` instead."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.8", "macpath"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_multi_import(
                self, multi: MultiImport, p: ExecutionContext
            ) -> Optional[MultiImport]:
                multi = super().visit_multi_import(multi, p)

                from_part = multi.from_
                if from_part is not None:
                    if isinstance(from_part, Identifier) and from_part.simple_name == "macpath":
                        return mark_deprecated(
                            multi,
                            "The `macpath` module was removed in Python 3.8. "
                            "Use `os.path` instead."
                        )
                else:
                    for import_node in multi.names:
                        name = _get_import_name(import_node)
                        if name == "macpath":
                            return mark_deprecated(
                                multi,
                                "The `macpath` module was removed in Python 3.8. "
                                "Use `os.path` instead."
                            )

                return multi

            def visit_import(
                self, import_stmt: Import, p: ExecutionContext
            ) -> Optional[Import]:
                import_stmt = super().visit_import(import_stmt, p)
                if self.cursor.first_enclosing(MultiImport) is not None:
                    return import_stmt
                name = _get_import_name(import_stmt)
                if name == "macpath":
                    return mark_deprecated(
                        import_stmt,
                        "The `macpath` module was removed in Python 3.8. "
                        "Use `os.path` instead."
                    )
                return import_stmt

        return Visitor()
