"""
Recipes for migrating deprecated sys module functions.

Deprecated and removed functions:
- sys.set_coroutine_wrapper() - deprecated 3.7, removed 3.8
- sys.get_coroutine_wrapper() - deprecated 3.7, removed 3.8

See: https://docs.python.org/3/whatsnew/3.8.html#api-and-feature-removals
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import Identifier, MethodInvocation
from ._markers import mark_deprecated

# Define category path: Python > Migrate > Python 3.8
_Python38 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.8"),
]


@categorize(_Python38)
class FindSysCoroutineWrapper(Recipe):
    """
    Find usages of removed `sys.set_coroutine_wrapper()` and `sys.get_coroutine_wrapper()`.

    These functions were deprecated in Python 3.7 and removed in Python 3.8.

    Example:
        Before:
            import sys
            sys.set_coroutine_wrapper(wrapper)
            old = sys.get_coroutine_wrapper()
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.FindSysCoroutineWrapper"

    @property
    def display_name(self) -> str:
        return "Find removed `sys.set_coroutine_wrapper()` / `sys.get_coroutine_wrapper()`"

    @property
    def description(self) -> str:
        return (
            "`sys.set_coroutine_wrapper()` and `sys.get_coroutine_wrapper()` were "
            "deprecated in Python 3.7 and removed in Python 3.8."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.8", "sys"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        removed_functions = {"set_coroutine_wrapper", "get_coroutine_wrapper"}

        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name not in removed_functions:
                    return method

                select = method.select
                if not isinstance(select, Identifier):
                    return method
                if select.simple_name != "sys":
                    return method

                return mark_deprecated(
                    method,
                    f"sys.{method.name.simple_name}() was removed in Python 3.8."
                )

        return Visitor()
