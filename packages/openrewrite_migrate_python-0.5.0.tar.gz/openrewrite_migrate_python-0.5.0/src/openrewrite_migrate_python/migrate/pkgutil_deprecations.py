"""
Recipes for migrating deprecated pkgutil module functions.

Several pkgutil functions were deprecated in Python 3.12:

- pkgutil.find_loader() -> importlib.util.find_spec()
- pkgutil.get_loader() -> importlib.util.find_spec()

See: https://docs.python.org/3/library/pkgutil.html
"""

from typing import Any, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import Identifier, MethodInvocation
from ._markers import mark_deprecated

# Define category path: Python > Migrate > Python 3.12
_Python312 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.12"),
]


def _is_pkgutil_method(method: MethodInvocation, method_name: str) -> bool:
    """
    Check if this is a pkgutil.method_name() call using type attribution.
    """
    if not isinstance(method.name, Identifier):
        return False
    if method.name.simple_name != method_name:
        return False

    if not method.method_type or not method.method_type.declaring_type:
        return False
    dt = method.method_type.declaring_type
    if not hasattr(dt, '_fully_qualified_name'):
        return False
    fqn = str(dt._fully_qualified_name)
    return 'pkgutil' in fqn


@categorize(_Python312)
class ReplacePkgutilFindLoader(Recipe):
    """
    Find and migrate `pkgutil.find_loader()` calls to `importlib.util.find_spec()`.

    The `pkgutil.find_loader()` function was deprecated in Python 3.12.
    The recommended replacement is `importlib.util.find_spec()`.

    Note: The return types differ - `find_loader()` returns a loader while
    `find_spec()` returns a ModuleSpec. Code may need additional changes.

    Example:
        Before:
            import pkgutil
            loader = pkgutil.find_loader('mymodule')

        After:
            import importlib.util
            spec = importlib.util.find_spec('mymodule')
            loader = spec.loader if spec else None
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplacePkgutilFindLoader"

    @property
    def display_name(self) -> str:
        return "Replace `pkgutil.find_loader()` with `importlib.util.find_spec()`"

    @property
    def description(self) -> str:
        return (
            "The `pkgutil.find_loader()` function was deprecated in Python 3.12. "
            "Replace with `importlib.util.find_spec()`. Note: returns ModuleSpec, use .loader for loader."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if _is_pkgutil_method(method, "find_loader"):
                    return mark_deprecated(
                        method,
                        "pkgutil.find_loader() is deprecated",
                        "Replace with importlib.util.find_spec() (Python 3.12+)"
                    )

                return method

        return Visitor()


@categorize(_Python312)
class ReplacePkgutilGetLoader(Recipe):
    """
    Find and migrate `pkgutil.get_loader()` calls to `importlib.util.find_spec()`.

    The `pkgutil.get_loader()` function was deprecated in Python 3.12.
    The recommended replacement is `importlib.util.find_spec()`.

    Example:
        Before:
            import pkgutil
            loader = pkgutil.get_loader('mymodule')

        After:
            import importlib.util
            spec = importlib.util.find_spec('mymodule')
            loader = spec.loader if spec else None
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplacePkgutilGetLoader"

    @property
    def display_name(self) -> str:
        return "Replace `pkgutil.get_loader()` with `importlib.util.find_spec()`"

    @property
    def description(self) -> str:
        return (
            "The `pkgutil.get_loader()` function was deprecated in Python 3.12. "
            "Replace with `importlib.util.find_spec()`. Note: returns ModuleSpec, use .loader for loader."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if _is_pkgutil_method(method, "get_loader"):
                    return mark_deprecated(
                        method,
                        "pkgutil.get_loader() is deprecated",
                        "Replace with importlib.util.find_spec() (Python 3.12+)"
                    )

                return method

        return Visitor()
