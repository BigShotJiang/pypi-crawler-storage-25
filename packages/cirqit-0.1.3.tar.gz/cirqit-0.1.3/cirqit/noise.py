"""
cirqit.noise - Quantum noise models (pure NumPy)
Applies noise via Kraus operators to the statevector.
"""

import numpy as np


class NoiseModel:
    def __init__(self):
        self.gate_errors = {}      # {gate_name: NoiseChannel}
        self.qubit_errors = {}     # {qubit_index: NoiseChannel}
        self.readout_error = None  # ReadoutError

    def add_gate_error(self, gate_name: str, channel):
        self.gate_errors[gate_name.lower()] = channel

    def add_qubit_error(self, qubit: int, channel):
        self.qubit_errors[qubit] = channel

    def add_readout_error(self, p0_given_1: float, p1_given_0: float):
        self.readout_error = ReadoutError(p0_given_1, p1_given_0)

    def apply_gate_noise(self, gate_name: str, statevec, qubit: int):
        channel = self.gate_errors.get(gate_name.lower())
        if channel:
            channel.apply(statevec, qubit)

    def apply_qubit_noise(self, statevec, qubit: int):
        channel = self.qubit_errors.get(qubit)
        if channel:
            channel.apply(statevec, qubit)

    def apply_readout_noise(self, counts: dict) -> dict:
        if not self.readout_error:
            return counts
        return self.readout_error.apply(counts)

    def __repr__(self):
        lines = ["NoiseModel:"]
        for g, c in self.gate_errors.items():
            lines.append(f"  Gate '{g}': {c}")
        for q, c in self.qubit_errors.items():
            lines.append(f"  Qubit {q}: {c}")
        if self.readout_error:
            lines.append(f"  Readout: {self.readout_error}")
        return "\n".join(lines)


# ─── Noise Channels ──────────────────────────────────────────────────────────

class DepolarizingChannel:
    """Single-qubit depolarizing noise: p/4 * (I + X + Y + Z mix)"""
    def __init__(self, prob: float):
        assert 0 <= prob <= 1
        self.prob = prob

    def apply(self, statevec, qubit: int):
        if np.random.random() < self.prob:
            choice = np.random.choice(['x', 'y', 'z'])
            from .gates import X, Y, Z
            gate_map = {'x': X(), 'y': Y(), 'z': Z()}
            statevec.apply_single(gate_map[choice], qubit)

    def __repr__(self):
        return f"Depolarizing(p={self.prob})"


class BitFlipChannel:
    """Bit flip error: applies X with probability p"""
    def __init__(self, prob: float):
        assert 0 <= prob <= 1
        self.prob = prob

    def apply(self, statevec, qubit: int):
        if np.random.random() < self.prob:
            from .gates import X
            statevec.apply_single(X(), qubit)

    def __repr__(self):
        return f"BitFlip(p={self.prob})"


class PhaseFlipChannel:
    """Phase flip error: applies Z with probability p"""
    def __init__(self, prob: float):
        assert 0 <= prob <= 1
        self.prob = prob

    def apply(self, statevec, qubit: int):
        if np.random.random() < self.prob:
            from .gates import Z
            statevec.apply_single(Z(), qubit)

    def __repr__(self):
        return f"PhaseFlip(p={self.prob})"


class AmplitudeDampingChannel:
    """Amplitude damping: models energy relaxation T1"""
    def __init__(self, gamma: float):
        assert 0 <= gamma <= 1
        self.gamma = gamma
        self.K0 = np.array([[1, 0], [0, np.sqrt(1 - gamma)]], dtype=complex)
        self.K1 = np.array([[0, np.sqrt(gamma)], [0, 0]], dtype=complex)

    def apply(self, statevec, qubit: int):
        # Apply stochastically via Kraus
        state = statevec.state.copy()
        n = statevec.n_qubits
        # Build full Kraus
        from .gates import I
        def expand(K):
            ops = [I() if q != qubit else K for q in range(n)]
            full = ops[0]
            for op in ops[1:]:
                full = np.kron(full, op)
            return full

        K0_full = expand(self.K0)
        K1_full = expand(self.K1)
        p0 = np.real(state.conj() @ K0_full.T.conj() @ K0_full @ state)
        p1 = np.real(state.conj() @ K1_full.T.conj() @ K1_full @ state)
        total = p0 + p1
        if total < 1e-10:
            return
        choice = np.random.choice([0, 1], p=[p0/total, p1/total])
        if choice == 0:
            new = K0_full @ state
        else:
            new = K1_full @ state
        norm = np.linalg.norm(new)
        if norm > 1e-10:
            statevec.state = new / norm

    def __repr__(self):
        return f"AmplitudeDamping(gamma={self.gamma})"


class PhaseDampingChannel:
    """Phase damping: models dephasing T2"""
    def __init__(self, gamma: float):
        assert 0 <= gamma <= 1
        self.gamma = gamma
        self.K0 = np.array([[1, 0], [0, np.sqrt(1 - gamma)]], dtype=complex)
        self.K1 = np.array([[0, 0], [0, np.sqrt(gamma)]], dtype=complex)

    def apply(self, statevec, qubit: int):
        from .gates import I
        state = statevec.state.copy()
        n = statevec.n_qubits

        def expand(K):
            ops = [I() if q != qubit else K for q in range(n)]
            full = ops[0]
            for op in ops[1:]:
                full = np.kron(full, op)
            return full

        K0_full = expand(self.K0)
        K1_full = expand(self.K1)
        p0 = np.real(state.conj() @ K0_full.T.conj() @ K0_full @ state)
        p1 = np.real(state.conj() @ K1_full.T.conj() @ K1_full @ state)
        total = p0 + p1
        if total < 1e-10:
            return
        choice = np.random.choice([0, 1], p=[p0/total, p1/total])
        new = (K0_full if choice == 0 else K1_full) @ state
        norm = np.linalg.norm(new)
        if norm > 1e-10:
            statevec.state = new / norm

    def __repr__(self):
        return f"PhaseDamping(gamma={self.gamma})"


class ThermalRelaxationChannel:
    """Combined T1/T2 thermal relaxation noise"""
    def __init__(self, t1: float, t2: float, gate_time: float):
        assert t2 <= 2 * t1, "T2 must be <= 2*T1"
        self.t1 = t1
        self.t2 = t2
        self.gate_time = gate_time
        self.gamma1 = 1 - np.exp(-gate_time / t1)
        self.gamma2 = 1 - np.exp(-gate_time / t2)
        self._amp = AmplitudeDampingChannel(self.gamma1)
        self._phase = PhaseDampingChannel(self.gamma2)

    def apply(self, statevec, qubit: int):
        self._amp.apply(statevec, qubit)
        self._phase.apply(statevec, qubit)

    def __repr__(self):
        return f"ThermalRelaxation(T1={self.t1}, T2={self.t2}, t_gate={self.gate_time})"


class ReadoutError:
    """Measurement readout flip errors"""
    def __init__(self, p0_given_1: float = 0.0, p1_given_0: float = 0.0):
        self.p0_given_1 = p0_given_1  # prob of reading 0 when state is |1>
        self.p1_given_0 = p1_given_0  # prob of reading 1 when state is |0>

    def apply(self, counts: dict) -> dict:
        noisy = {}
        for bitstring, count in counts.items():
            for _ in range(count):
                new_bits = ""
                for b in bitstring:
                    if b == '0' and np.random.random() < self.p1_given_0:
                        new_bits += '1'
                    elif b == '1' and np.random.random() < self.p0_given_1:
                        new_bits += '0'
                    else:
                        new_bits += b
                noisy[new_bits] = noisy.get(new_bits, 0) + 1
        return noisy

    def __repr__(self):
        return f"ReadoutError(p01={self.p1_given_0}, p10={self.p0_given_1})"


# ─── Preset noise models ──────────────────────────────────────────────────────

def ideal():
    """No noise"""
    return NoiseModel()

def basic_depolarizing(p: float = 0.01):
    """Simple depolarizing on all single-qubit gates"""
    nm = NoiseModel()
    for g in ['h', 'x', 'y', 'z', 's', 't', 'rx', 'ry', 'rz']:
        nm.add_gate_error(g, DepolarizingChannel(p))
    return nm

def realistic(p_gate: float = 0.005, p_readout: float = 0.02):
    """Realistic noise: depolarizing + readout error"""
    nm = basic_depolarizing(p_gate)
    nm.add_readout_error(p_readout, p_readout)
    return nm
