"""
cirqit.visualize
================
Production-quality visualization:
  - draw_ascii      : Qiskit-style unicode text diagram
  - draw_matplotlib : IBM-style professional circuit diagram
  - plot_histogram  : Single & multi-series bar chart
  - plot_bloch_sphere: Bloch sphere
"""

import numpy as np


# ═══════════════════════════════════════════════════════════════
# ASCII TEXT DIAGRAM  (Qiskit style)
# ═══════════════════════════════════════════════════════════════

def draw_ascii(operations, n_qubits, measured_qubits):
    """
    Render circuit as Qiskit-style unicode ASCII diagram.
    Returns a string — never prints directly.
    """
    T, M, B = 0, 1, 2   # row indices: top, mid, bot

    # ── Cell constructors ────────────────────────────────────
    def gate_cell(label):
        w = max(3, len(label) + 2)
        return ['┌' + '─'*w + '┐',
                '┤' + label.center(w) + '├',
                '└' + '─'*w + '┘'], w + 2

    def wire_cell(w):
        return [' '*w, '─'*w, ' '*w], w

    def ctrl_cell(w):
        p = w // 2
        return [' '*p + '│' + ' '*(w-p-1),
                '─'*p + '■' + '─'*(w-p-1),
                ' '*p + '│' + ' '*(w-p-1)], w

    def vline_cell(w):
        p = w // 2
        return [' '*p + '│' + ' '*(w-p-1),
                '─'*p + '┼' + '─'*(w-p-1),
                ' '*p + '│' + ' '*(w-p-1)], w

    def swap_cell(w):
        p = w // 2
        return [' '*p + '│' + ' '*(w-p-1),
                '─'*p + 'X' + '─'*(w-p-1),
                ' '*p + '│' + ' '*(w-p-1)], w

    def meas_cell():
        return ['┌─┐', '┤M├', '└─┘'], 3

    # ── Build columns ────────────────────────────────────────
    columns = []

    for op in operations:
        name   = op['name'].upper()
        qbits  = op['qubits']
        params = op.get('params', [])
        if name in ('BARRIER', 'RESET'):
            continue

        if len(qbits) == 1:
            q = qbits[0]
            if params:
                label = f"{name}({','.join(f'{p:.2f}' for p in params)})"
            else:
                label = name
            gc, w = gate_cell(label)
            wc, _ = wire_cell(w)
            col   = [gc if i == q else wc for i in range(n_qubits)]
            columns.append(col)

        elif len(qbits) == 2:
            ctrl, tgt = qbits
            mn, mx    = min(ctrl, tgt), max(ctrl, tgt)

            if name in ('SWAP', 'ISWAP'):
                w  = 5
                sc = swap_cell(w)[0]
                vl = vline_cell(w)[0]
                wc = wire_cell(w)[0]
                col = [sc if i in (ctrl,tgt) else
                       vl if mn < i < mx else wc
                       for i in range(n_qubits)]
            else:
                tgt_lbl = 'X' if name in ('CNOT','CX') else name
                gc, w   = gate_cell(tgt_lbl)
                cc      = ctrl_cell(w)[0]
                vl      = vline_cell(w)[0]
                wc      = wire_cell(w)[0]
                col = [cc if i == ctrl else
                       gc if i == tgt  else
                       vl if mn < i < mx else wc
                       for i in range(n_qubits)]
            columns.append(col)

        elif len(qbits) >= 3:
            ctrls, tgt = qbits[:-1], qbits[-1]
            tgt_lbl = 'X' if name in ('CCX','TOFFOLI','CCNOT') else name
            gc, w   = gate_cell(tgt_lbl)
            cc      = ctrl_cell(w)[0]
            vl      = vline_cell(w)[0]
            wc      = wire_cell(w)[0]
            mn, mx  = min(qbits), max(qbits)
            col = [cc if i in ctrls else
                   gc if i == tgt   else
                   vl if mn < i < mx else wc
                   for i in range(n_qubits)]
            columns.append(col)

    # ── Measurement column ───────────────────────────────────
    if measured_qubits:
        mc, w  = meas_cell()
        wc, _  = wire_cell(w)
        col    = [mc if i in measured_qubits else wc
                  for i in range(n_qubits)]
        columns.append(col)

    # ── Render rows ──────────────────────────────────────────
    lbl_w = max(len(f'q{i}: ') for i in range(n_qubits))
    rows  = []
    for i in range(n_qubits):
        top = ' ' * lbl_w + '  '
        mid = f'q{i}: '.ljust(lbl_w) + '──'
        bot = ' ' * lbl_w + '  '
        for col in columns:
            cell = col[i]
            top += cell[T]; mid += cell[M]; bot += cell[B]
        mid += '─'
        rows += [top, mid, bot]

    return '\n'.join(rows)


# ═══════════════════════════════════════════════════════════════
# MATPLOTLIB DIAGRAM  (IBM / Qiskit style)
# ═══════════════════════════════════════════════════════════════

# Gate colour palette  (facecolor, textcolor)
_GATE_CLR = {
    'H'      : ('#6929C4', '#FFFFFF'),
    'X'      : ('#1192E8', '#FFFFFF'),
    'Y'      : ('#9F1853', '#FFFFFF'),
    'Z'      : ('#198038', '#FFFFFF'),
    'S'      : ('#005D5D', '#FFFFFF'),
    'T'      : ('#B28600', '#FFFFFF'),
    'SDG'    : ('#005D5D', '#FFFFFF'),
    'TDG'    : ('#B28600', '#FFFFFF'),
    'SX'     : ('#EE538B', '#FFFFFF'),
    'I'      : ('#8D8D8D', '#FFFFFF'),
    'RX'     : ('#00539A', '#FFFFFF'),
    'RY'     : ('#6929C4', '#FFFFFF'),
    'RZ'     : ('#007D79', '#FFFFFF'),
    'P'      : ('#007D79', '#FFFFFF'),
    'U'      : ('#6929C4', '#FFFFFF'),
    'CX'     : ('#FA4D56', '#FFFFFF'),
    'CNOT'   : ('#FA4D56', '#FFFFFF'),
    'CY'     : ('#9F1853', '#FFFFFF'),
    'CZ'     : ('#198038', '#FFFFFF'),
    'CRX'    : ('#00539A', '#FFFFFF'),
    'CRY'    : ('#6929C4', '#FFFFFF'),
    'CRZ'    : ('#007D79', '#FFFFFF'),
    'CP'     : ('#007D79', '#FFFFFF'),
    'SWAP'   : ('#FA4D56', '#FFFFFF'),
    'ISWAP'  : ('#EE538B', '#FFFFFF'),
    'CCX'    : ('#FF832B', '#FFFFFF'),
    'TOFFOLI': ('#FF832B', '#FFFFFF'),
    'CSWAP'  : ('#FF832B', '#FFFFFF'),
    'RESET'  : ('#8D8D8D', '#FFFFFF'),
    'DEFAULT': ('#6929C4', '#FFFFFF'),
}


def draw_matplotlib(operations, n_qubits, measured_qubits,
                    figsize=None, title=''):
    """
    IBM/Qiskit-style circuit diagram matching reference image:
    - Blue gate boxes
    - CNOT target = ⊕ circle with plus
    - Measurement = dark box with arc+needle meter
    - Classical double-line with numbered drop arrows
    - Returns Figure only — never calls plt.show()
    """
    try:
        import matplotlib.pyplot as plt
        from matplotlib.patches import FancyBboxPatch
    except ImportError:
        raise ImportError("pip install matplotlib")

    COL_W = 1.0
    ROW_H = 1.0
    BOX_W = 0.70
    BOX_H = 0.52
    GATE_FC = '#5B8DDE'
    GATE_EC = '#FFFFFF'
    GATE_TC = '#FFFFFF'
    WIRE_C  = '#000000'
    CTRL_C  = '#5B8DDE'

    # ── Column layout ────────────────────────────────────────
    col_ops = []; bar_xs = []; cx = 1.2
    for op in operations:
        nm = op['name'].upper()
        if nm == 'BARRIER':
            bar_xs.append(cx - 0.3); continue
        col_ops.append((cx, op)); cx += COL_W

    meas_x  = cx
    total_w = meas_x + COL_W + 0.6

    if figsize is None:
        figsize = (max(7, total_w * 0.9), n_qubits * ROW_H + 0.1)

    fig, ax = plt.subplots(figsize=figsize)
    fig.patch.set_facecolor('#FFFFFF')
    ax.set_facecolor('#FFFFFF')
    ax.set_xlim(-0.2, total_w)
    ax.set_ylim(-1.5, n_qubits * ROW_H - 0.15)
    ax.axis('off')
    ax.set_aspect('equal')

    def qy(q):
        return (n_qubits - 1 - q) * ROW_H

    # Title — always centered, tight to circuit
    t = title or f'{n_qubits}-Qubit Circuit'
    fig.suptitle(t, fontsize=13, fontweight='bold',
                 color='#111111', fontfamily='monospace',
                 ha='center', x=0.5, y=1.05)

    # ── Qubit wires ──────────────────────────────────────────
    for q in range(n_qubits):
        y = qy(q)
        ax.plot([0.0, total_w-0.1], [y, y],
                color=WIRE_C, lw=1.6, zorder=1,
                solid_capstyle='round')
        ax.text(-0.12, y, f'$q_{q}$',
                ha='right', va='center', fontsize=10,
                color='#2255AA', fontweight='bold')

    # ── Classical double-line ─────────────────────────────────
    n_cb = len(measured_qubits)
    cy   = -0.85
    if n_cb > 0:
        ax.plot([0.0, total_w-0.1], [cy+0.055, cy+0.055],
                color='#888888', lw=1.4, zorder=1)
        ax.plot([0.0, total_w-0.1], [cy-0.055, cy-0.055],
                color='#888888', lw=1.4, zorder=1)
        ax.text(-0.12, cy, 'c',
                ha='right', va='center', fontsize=10,
                color='#444444', fontweight='bold')
        ax.plot([0.05, 0.22], [cy-0.12, cy+0.12],
                color='#888888', lw=1.6, zorder=2)
        ax.text(0.25, cy+0.17, str(n_cb),
                ha='left', va='center',
                fontsize=8, color='#555555')

    # ── Barriers ─────────────────────────────────────────────
    for bx in bar_xs:
        ax.fill_betweenx(
            [qy(n_qubits-1)-0.45, qy(0)+0.45],
            bx-0.06, bx+0.06,
            color='#AAAAAA', alpha=0.5, zorder=2)

    # ── Gate helpers ─────────────────────────────────────────
    def _box(x, q, label, fc=GATE_FC, tc=GATE_TC, params=None):
        y   = qy(q)
        lbl = label
        if params:
            lbl = f"{label}\n({','.join(f'{p:.2f}' for p in params)})"
        ax.add_patch(FancyBboxPatch(
            (x-BOX_W/2+0.025, y-BOX_H/2-0.025), BOX_W, BOX_H,
            boxstyle='round,pad=0.05',
            facecolor='#00000015', edgecolor='none', zorder=3))
        ax.add_patch(FancyBboxPatch(
            (x-BOX_W/2, y-BOX_H/2), BOX_W, BOX_H,
            boxstyle='round,pad=0.05',
            facecolor=fc, edgecolor=GATE_EC,
            linewidth=1.5, zorder=4))
        fs = 9 if '\n' not in lbl else 6.5
        ax.text(x, y, lbl, ha='center', va='center',
                fontsize=fs, fontweight='bold', color=tc,
                zorder=5, fontfamily='monospace')

    def _ctrl(x, q):
        ax.plot(x, qy(q), 'o', color=CTRL_C,
                markersize=13, zorder=5,
                markeredgecolor='white', markeredgewidth=1.2)

    def _vline(x, q0, q1):
        y0, y1 = qy(q0), qy(q1)
        ax.plot([x, x], [min(y0,y1), max(y0,y1)],
                color=CTRL_C, lw=2.0, zorder=3)

    def _cnot_tgt(x, q):
        y = qy(q); r = 0.22
        ax.add_patch(plt.Circle((x, y), r, color=CTRL_C, zorder=4))
        ax.plot([x-r, x+r], [y, y], color='white', lw=2.0, zorder=5)
        ax.plot([x, x], [y-r, y+r], color='white', lw=2.0, zorder=5)

    def _swap_x(x, q):
        y = qy(q); d = 0.18
        ax.plot([x-d,x+d],[y-d,y+d], color=CTRL_C, lw=2.5, zorder=5)
        ax.plot([x-d,x+d],[y+d,y-d], color=CTRL_C, lw=2.5, zorder=5)

    def _measure(x, q, idx):
        y   = qy(q)
        # Shadow
        ax.add_patch(FancyBboxPatch(
            (x-BOX_W/2+0.025, y-BOX_H/2-0.025), BOX_W, BOX_H,
            boxstyle='round,pad=0.05',
            facecolor='#00000020', edgecolor='none', zorder=3))
        # Dark box
        ax.add_patch(FancyBboxPatch(
            (x-BOX_W/2, y-BOX_H/2), BOX_W, BOX_H,
            boxstyle='round,pad=0.05',
            facecolor='#1A1A2E', edgecolor='#6699DD',
            linewidth=2.0, zorder=4))
        # Meter arc
        r   = 0.155; cy0 = y - 0.04
        th  = np.linspace(np.pi, 0, 50)
        ax.plot(x + r*np.cos(th), cy0 + r*np.sin(th),
                color='#FFFFFF', lw=1.6, zorder=5)
        # Needle
        ax.annotate('',
                    xy=(x+r*0.68, cy0+r*0.68),
                    xytext=(x, cy0),
                    arrowprops=dict(arrowstyle='->',
                                   color='#FFFFFF', lw=1.4),
                    zorder=5)
        # Drop arrow to classical wire
        ax.annotate('',
                    xy=(x, cy+0.08),
                    xytext=(x, y-BOX_H/2-0.02),
                    arrowprops=dict(arrowstyle='->',
                                   color='#888888', lw=1.3),
                    zorder=3)
        # Bit index at classical wire
        ax.text(x, cy-0.22, str(idx),
                ha='center', va='top',
                fontsize=8, color='#444444', fontweight='bold')

    # ── Draw operations ──────────────────────────────────────
    for (x, op) in col_ops:
        nm    = op['name'].upper()
        qbits = op['qubits']
        params= op.get('params', [])

        if len(qbits) == 1:
            _box(x, qbits[0], nm, params=params or None)
        elif len(qbits) == 2:
            ctrl, tgt = qbits
            _vline(x, min(ctrl,tgt), max(ctrl,tgt))
            if nm in ('CNOT','CX'):
                _ctrl(x, ctrl); _cnot_tgt(x, tgt)
            elif nm in ('SWAP','ISWAP'):
                _swap_x(x, ctrl); _swap_x(x, tgt)
            else:
                _ctrl(x, ctrl)
                _box(x, tgt, nm[1:] if nm.startswith('C') else nm,
                     params=params or None)
        elif len(qbits) >= 3:
            ctrls, tgt = qbits[:-1], qbits[-1]
            _vline(x, min(qbits), max(qbits))
            for c in ctrls: _ctrl(x, c)
            if nm in ('CCX','TOFFOLI','CCNOT'):
                _cnot_tgt(x, tgt)
            else:
                _box(x, tgt, nm, params=params or None)

    # ── Measurements — each qubit gets its own column ────────
    MEAS_COL_W = COL_W * 0.85
    for idx, q in enumerate(sorted(measured_qubits)):
        mx = meas_x + idx * MEAS_COL_W
        _measure(mx, q, idx)
    # Extend wires to cover all measurement columns
    extra = len(measured_qubits) * MEAS_COL_W
    for q in range(n_qubits):
        y = qy(q)
        ax.plot([total_w - 0.1, total_w - 0.1 + extra],
                [y, y], color=WIRE_C, lw=1.6, zorder=1,
                solid_capstyle='round')
    # Extend classical wire too
    if n_cb > 0:
        for offset in (+0.055, -0.055):
            ax.plot([total_w - 0.1, total_w - 0.1 + extra],
                    [cy + offset, cy + offset],
                    color='#888888', lw=1.4, zorder=1)
    ax.set_xlim(-0.2, total_w + extra + 0.3)

    plt.tight_layout(pad=0.0, rect=[0, 0, 1, 0.93])
    return fig   # never calls plt.show()


def plot_histogram(counts, title='Measurement Results',
                   figsize=None, series_label=None,
                   series_color=None, xlabel='Basis State',
                   ylabel='Probability'):
    """
    Plot measurement histogram.

    Parameters
    ----------
    counts       : dict or list[dict]
                   - dict               → single series
                   - list of dicts      → multi-series comparison
    title        : str
    figsize      : tuple or None
    series_label : list[str]  labels for multi-series
    series_color : list[str]  colors for multi-series
    xlabel       : str
    ylabel       : str

    Returns
    -------
    matplotlib Figure
    """
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        raise ImportError("pip install matplotlib")

    # Normalise to list-of-dicts
    if isinstance(counts, dict):
        series_list  = [counts]
        series_label = series_label or ['Results']
        series_color = series_color or ['#6929C4']
    else:
        series_list  = counts
        n = len(series_list)
        series_label = series_label or [f'Series {i+1}' for i in range(n)]
        series_color = (series_color or
                        ['#1192E8','#FA4D56','#198038',
                         '#FF832B','#9F1853','#007D79'])[:n]

    # All states union
    all_states = sorted({k for s in series_list for k in s})
    n_states   = len(all_states)
    n_series   = len(series_list)

    if figsize is None:
        figsize = (max(7, n_states * n_series * 0.55 + 2), 5)

    fig, ax = plt.subplots(figsize=figsize)
    fig.patch.set_facecolor('#FFFFFF')
    ax.set_facecolor('#FAFAFA')

    x     = np.arange(n_states)
    bar_w = 0.75 / n_series
    max_v = 0

    for si, (sdata, slbl, scol) in enumerate(
            zip(series_list, series_label, series_color)):
        total  = sum(sdata.values()) or 1
        vals   = [sdata.get(st, 0) for st in all_states]
        probs  = [v / total * 100 for v in vals]
        offset = (si - (n_series - 1) / 2) * bar_w
        bars   = ax.bar(x + offset, probs, bar_w * 0.90,
                        label=slbl, color=scol,
                        edgecolor='white', linewidth=0.8,
                        alpha=0.95, zorder=3)
        max_v  = max(max_v, max(probs, default=0))
        for bar, pct in zip(bars, probs):
            if pct > 0.5:
                ax.text(bar.get_x() + bar.get_width() / 2,
                        bar.get_height() + 0.8,
                        f'{pct:.1f}%',
                        ha='center', va='bottom',
                        fontsize=8, fontweight='bold',
                        color='#222222')

    ax.set_xticks(x)
    ax.set_xticklabels(all_states, fontsize=9,
                       fontweight='bold', rotation=45, ha='right')
    ax.set_xlabel(xlabel, fontsize=11, labelpad=8, color='#333333')
    ax.set_ylabel(ylabel + ' (%)', fontsize=11,
                  labelpad=8, color='#333333')
    ax.set_title(title, fontsize=13, fontweight='bold',
                 color='#111111', pad=12)
    ax.set_ylim(0, min(115, max_v * 1.20))
    ax.yaxis.grid(True, color='#DDDDDD', lw=0.8, zorder=0)
    ax.set_axisbelow(True)
    for sp in ['top', 'right']:
        ax.spines[sp].set_visible(False)
    for sp in ['left', 'bottom']:
        ax.spines[sp].set_color('#CCCCCC')
    ax.tick_params(colors='#444444', length=3)

    if n_series > 1:
        ax.legend(loc='upper right', fontsize=9,
                  framealpha=0.92, edgecolor='#CCCCCC',
                  facecolor='#FFFFFF')

    plt.tight_layout()
    return fig   # ← never calls plt.show() here


# ═══════════════════════════════════════════════════════════════
# BLOCH SPHERE
# ═══════════════════════════════════════════════════════════════

def plot_bloch_sphere(bx: float, by: float, bz: float,
                      qubit: int = 0):
    """
    Plot Bloch sphere for a single qubit.
    Returns matplotlib Figure.
    """
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        raise ImportError("pip install matplotlib")

    fig = plt.figure(figsize=(6, 6))
    ax  = fig.add_subplot(111, projection='3d')
    ax.set_facecolor('#FFFFFF')
    fig.patch.set_facecolor('#FFFFFF')

    # Sphere wireframe
    u, v = np.mgrid[0:2*np.pi:40j, 0:np.pi:20j]
    ax.plot_wireframe(
        np.cos(u)*np.sin(v),
        np.sin(u)*np.sin(v),
        np.cos(v),
        color='#BBCCDD', alpha=0.30, lw=0.5)

    # Axis lines + labels
    for vec, lbl, col in [
        ([1,0,0], '|+⟩', '#888888'), ([-1,0,0], '|−⟩', '#888888'),
        ([0,1,0], '|i+⟩','#888888'), ([0,-1,0], '|i−⟩','#888888'),
        ([0,0,1], '|0⟩', '#0077BB'), ([0,0,-1], '|1⟩', '#CC2222'),
    ]:
        ax.plot([0,vec[0]], [0,vec[1]], [0,vec[2]],
                color='#AAAAAA', lw=0.8, alpha=0.6)
        ax.text(vec[0]*1.22, vec[1]*1.22, vec[2]*1.22,
                lbl, color=col, fontsize=9,
                ha='center', fontweight='bold')

    # Bloch vector
    ax.quiver(0,0,0, bx,by,bz,
              color='#FA4D56', lw=2.5,
              arrow_length_ratio=0.15)
    ax.scatter([bx],[by],[bz],
               color='#FA4D56', s=60, zorder=5)

    # Projections
    for seg in [([bx,bx],[by,by],[0,bz]),
                ([bx,bx],[0,by],[0,0]),
                ([0,bx],[0,0],[0,0])]:
        ax.plot(*seg, color='#AAAAAA', lw=0.8, ls='--')

    ax.set_title(f'Bloch Sphere — q{qubit}',
                 fontsize=11, fontweight='bold', color='#222222')
    for lim in (ax.set_xlim, ax.set_ylim, ax.set_zlim):
        lim([-1.3, 1.3])
    ax.tick_params(colors='#AAAAAA', labelsize=7)
    for pane in (ax.xaxis.pane, ax.yaxis.pane, ax.zaxis.pane):
        pane.fill = False

    plt.tight_layout()
    return fig   # ← never calls plt.show() here
