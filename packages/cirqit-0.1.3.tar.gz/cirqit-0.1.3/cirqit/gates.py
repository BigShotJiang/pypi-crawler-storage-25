"""
cirqit.gates - All quantum gate matrices (pure NumPy backend)
"""

import numpy as np

# ─── Single-Qubit Gates ───────────────────────────────────────────────────────

def I():
    return np.eye(2, dtype=complex)

def X():
    return np.array([[0, 1], [1, 0]], dtype=complex)

def Y():
    return np.array([[0, -1j], [1j, 0]], dtype=complex)

def Z():
    return np.array([[1, 0], [0, -1]], dtype=complex)

def H():
    return np.array([[1, 1], [1, -1]], dtype=complex) / np.sqrt(2)

def S():
    return np.array([[1, 0], [0, 1j]], dtype=complex)

def T():
    return np.array([[1, 0], [0, np.exp(1j * np.pi / 4)]], dtype=complex)

def Sdg():
    return np.array([[1, 0], [0, -1j]], dtype=complex)

def Tdg():
    return np.array([[1, 0], [0, np.exp(-1j * np.pi / 4)]], dtype=complex)

def RX(theta):
    return np.array([
        [np.cos(theta / 2), -1j * np.sin(theta / 2)],
        [-1j * np.sin(theta / 2), np.cos(theta / 2)]
    ], dtype=complex)

def RY(theta):
    return np.array([
        [np.cos(theta / 2), -np.sin(theta / 2)],
        [np.sin(theta / 2),  np.cos(theta / 2)]
    ], dtype=complex)

def RZ(theta):
    return np.array([
        [np.exp(-1j * theta / 2), 0],
        [0, np.exp(1j * theta / 2)]
    ], dtype=complex)

def P(phi):
    """Phase gate"""
    return np.array([[1, 0], [0, np.exp(1j * phi)]], dtype=complex)

def U(theta, phi, lam):
    """General single-qubit unitary U3"""
    return np.array([
        [np.cos(theta/2), -np.exp(1j*lam)*np.sin(theta/2)],
        [np.exp(1j*phi)*np.sin(theta/2), np.exp(1j*(phi+lam))*np.cos(theta/2)]
    ], dtype=complex)

def SX():
    """Square-root X gate"""
    return np.array([[1+1j, 1-1j], [1-1j, 1+1j]], dtype=complex) / 2

# ─── Two-Qubit Gates ──────────────────────────────────────────────────────────

def CNOT():
    return np.array([
        [1, 0, 0, 0],
        [0, 1, 0, 0],
        [0, 0, 0, 1],
        [0, 0, 1, 0]
    ], dtype=complex)

def CZ():
    return np.array([
        [1, 0, 0, 0],
        [0, 1, 0, 0],
        [0, 0, 1, 0],
        [0, 0, 0, -1]
    ], dtype=complex)

def CY():
    return np.array([
        [1, 0,  0,  0],
        [0, 1,  0,  0],
        [0, 0,  0, -1j],
        [0, 0,  1j, 0]
    ], dtype=complex)

def SWAP():
    return np.array([
        [1, 0, 0, 0],
        [0, 0, 1, 0],
        [0, 1, 0, 0],
        [0, 0, 0, 1]
    ], dtype=complex)

def iSWAP():
    return np.array([
        [1, 0,  0,  0],
        [0, 0,  1j, 0],
        [0, 1j, 0,  0],
        [0, 0,  0,  1]
    ], dtype=complex)

def CRX(theta):
    rx = RX(theta)
    m = np.eye(4, dtype=complex)
    m[2:, 2:] = rx
    return m

def CRY(theta):
    ry = RY(theta)
    m = np.eye(4, dtype=complex)
    m[2:, 2:] = ry
    return m

def CRZ(theta):
    rz = RZ(theta)
    m = np.eye(4, dtype=complex)
    m[2:, 2:] = rz
    return m

def CP(phi):
    """Controlled phase gate"""
    m = np.eye(4, dtype=complex)
    m[3, 3] = np.exp(1j * phi)
    return m

# ─── Three-Qubit Gates ────────────────────────────────────────────────────────

def Toffoli():
    """CCX / Toffoli gate"""
    m = np.eye(8, dtype=complex)
    m[6, 6] = 0; m[6, 7] = 1
    m[7, 7] = 0; m[7, 6] = 1
    return m

def Fredkin():
    """CSWAP / Fredkin gate"""
    m = np.eye(8, dtype=complex)
    m[5, 5] = 0; m[5, 6] = 1
    m[6, 6] = 0; m[6, 5] = 1
    return m

# ─── Gate Registry ────────────────────────────────────────────────────────────

GATE_REGISTRY = {
    'i': I, 'x': X, 'y': Y, 'z': Z,
    'h': H, 's': S, 't': T, 'sdg': Sdg, 'tdg': Tdg,
    'sx': SX,
    'rx': RX, 'ry': RY, 'rz': RZ, 'p': P, 'u': U,
    'cnot': CNOT, 'cx': CNOT, 'cz': CZ, 'cy': CY,
    'swap': SWAP, 'iswap': iSWAP,
    'crx': CRX, 'cry': CRY, 'crz': CRZ, 'cp': CP,
    'ccx': Toffoli, 'toffoli': Toffoli,
    'cswap': Fredkin, 'fredkin': Fredkin,
}
