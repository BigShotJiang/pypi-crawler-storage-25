# ⚛️ CirQit

**A pure NumPy quantum circuit simulator — no Qiskit, no PennyLane, no heavy deps.**

```bash
pip install cirqit
```

---

## Features

- ✅ 20+ quantum gates (H, X, Y, Z, CNOT, Toffoli, RX, RY, RZ, SWAP, iSWAP, CZ, CRX, CRY, CRZ, CP, U3, SX, P...)
- ✅ Custom statevector simulator (pure NumPy backend)
- ✅ Noise models: Depolarizing, BitFlip, PhaseFlip, AmplitudeDamping, PhaseDamping, ThermalRelaxation, ReadoutError
- ✅ ASCII + Matplotlib circuit visualization
- ✅ Measurement histogram plots
- ✅ Bloch sphere visualization
- ✅ Built-in algorithms: Bell, GHZ, QFT, Grover, Deutsch-Jozsa, Bernstein-Vazirani, Teleportation, Phase Estimation
- ✅ Circuit composition, inverse, copy
- ✅ Custom unitary gate support
- ✅ Only requires `numpy` + `matplotlib`

---

## Quick Start

```python
from cirqit import QuantumCircuit

# Bell state
qc = QuantumCircuit(2)
qc.h(0)
qc.cnot(0, 1)
qc.measure_all()

result = qc.run(shots=1024)
print(result)
# {'00': 512, '11': 512}

qc.draw()           # ASCII circuit
qc.draw('mpl')      # Matplotlib circuit
qc.plot_histogram(result)
```

---

## Gates

```python
qc = QuantumCircuit(3)

# Single-qubit
qc.h(0)          # Hadamard
qc.x(1)          # Pauli-X
qc.y(2)          # Pauli-Y
qc.z(0)          # Pauli-Z
qc.s(1)          # S gate
qc.t(2)          # T gate
qc.sx(0)         # √X gate
qc.rx(1.57, 0)   # Rotation-X
qc.ry(0.78, 1)   # Rotation-Y
qc.rz(3.14, 2)   # Rotation-Z
qc.p(1.57, 0)    # Phase gate
qc.u(1.57, 0.78, 1.57, 1)  # U3 gate

# Two-qubit
qc.cnot(0, 1)    # CNOT
qc.cz(0, 1)      # Controlled-Z
qc.swap(1, 2)    # SWAP
qc.crx(1.57, 0, 1)  # Controlled-RX

# Three-qubit
qc.ccx(0, 1, 2)  # Toffoli
qc.cswap(0, 1, 2)  # Fredkin
```

---

## Noise Models

```python
from cirqit.noise import NoiseModel, DepolarizingChannel, AmplitudeDampingChannel

nm = NoiseModel()
nm.add_gate_error('h', DepolarizingChannel(0.01))
nm.add_gate_error('x', AmplitudeDampingChannel(0.05))
nm.add_readout_error(p0_given_1=0.02, p1_given_0=0.02)

qc = QuantumCircuit(2)
qc.h(0).cnot(0, 1).measure_all()
qc.set_noise_model(nm)

noisy_result = qc.run(shots=2048)

# Presets
from cirqit.noise import basic_depolarizing, realistic
nm = realistic(p_gate=0.005, p_readout=0.02)
```

---

## Built-in Algorithms

```python
from cirqit.algorithms import (
    bell_state, ghz_state, qft, grover_diffusion,
    deutsch_jozsa, bernstein_vazirani, teleportation,
    phase_estimation, random_circuit
)

# Bell state
bell = bell_state('00')
bell.measure_all()
print(bell.run(1024))

# QFT on 4 qubits
qft4 = qft(4)
print(qft4)

# Deutsch-Jozsa
dj = deutsch_jozsa('balanced', n=3)
print(dj.run(1))

# Bernstein-Vazirani — find secret string
bv = bernstein_vazirani('1011')
print(bv.run(shots=1))
```

---

## Statevector & Bloch Sphere

```python
qc = QuantumCircuit(1)
qc.h(0)

sv = qc.statevector()
print(sv)
# StateVector (1 qubits):
#   |0⟩: 0.7071+0.0000j  (p=0.5000)
#   |1⟩: 0.7071+0.0000j  (p=0.5000)

qc.plot_bloch(qubit=0)
```

---

## Circuit Operations

```python
# Inverse
inv = qc.inverse()

# Compose
combined = qc.compose(other_circuit)

# Info
print(qc.depth())
print(qc.count_ops())
print(qc.probabilities())
```

---

## License

MIT © Muhammad
