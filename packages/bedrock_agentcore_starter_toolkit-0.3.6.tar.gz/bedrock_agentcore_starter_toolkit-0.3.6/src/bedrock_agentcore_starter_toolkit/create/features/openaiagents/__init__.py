"""OpenAI Agents Templates."""
