"""Strands SDK Templates."""
