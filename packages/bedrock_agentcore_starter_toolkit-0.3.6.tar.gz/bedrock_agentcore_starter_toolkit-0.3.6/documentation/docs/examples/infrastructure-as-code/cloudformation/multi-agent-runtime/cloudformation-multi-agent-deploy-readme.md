{% include-markdown "https://raw.githubusercontent.com/awslabs/amazon-bedrock-agentcore-samples/refs/heads/main/04-infrastructure-as-code/cloudformation/multi-agent-runtime/README.md" start="#" %}
