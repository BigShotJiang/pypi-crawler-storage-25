"""Archetype renderer — converts SlideArchetype to PresentationML XML.

Produces a complete ``p:sld`` element tree from a :class:`SlideArchetype`
definition and a :class:`SlideGrid`.  Uses existing fill and shape helper
primitives; never duplicates XML-building logic.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from lxml import etree

from tokenmoulds.archetypes.shape_dsl import ConnectorDef, ShapeDef, SlideArchetype
from tokenmoulds.design.units import pt_to_hundredths as _pt_to_hundredths
from tokenmoulds.emitters.pptx_shape_helpers import A_NS, PRESENTATIONML_NS

if TYPE_CHECKING:
    from tokenmoulds.archetypes.shape_dsl import TextBody
    from tokenmoulds.design.page_geometry import SlideGrid

P_NS = PRESENTATIONML_NS


class ArchetypeRenderer:
    """Converts a :class:`SlideArchetype` into an lxml element tree."""

    def render(
        self,
        archetype: SlideArchetype,
        grid: SlideGrid,
        resolved_regions: dict[str, tuple[int, int, int, int]] | None = None,
    ) -> etree._Element:
        """Build a complete ``p:sld`` element tree."""
        return self._render_tree(archetype, grid, resolved_regions, root_tag="sld")

    def render_layout(
        self,
        archetype: SlideArchetype,
        grid: SlideGrid,
        resolved_regions: dict[str, tuple[int, int, int, int]] | None = None,
    ) -> etree._Element:
        """Build a complete ``p:sldLayout`` element tree for the layout gallery."""
        root = self._render_tree(
            archetype, grid, resolved_regions, root_tag="sldLayout"
        )
        root.set("type", "cust")
        root.set("preserve", "1")
        clr_map = etree.SubElement(root, f"{{{P_NS}}}clrMapOvr")
        etree.SubElement(clr_map, f"{{{A_NS}}}masterClrMapping")
        return root

    def _render_tree(
        self,
        archetype: SlideArchetype,
        grid: SlideGrid,
        resolved_regions: dict[str, tuple[int, int, int, int]] | None,
        root_tag: str,
    ) -> etree._Element:
        """Build a ``p:sld`` or ``p:sldLayout`` element tree."""
        rects = self._resolve_regions(archetype, grid, resolved_regions)

        root = etree.Element(f"{{{P_NS}}}{root_tag}")
        c_sld = etree.SubElement(root, f"{{{P_NS}}}cSld")
        c_sld.set("name", archetype.display_name)
        sp_tree = etree.SubElement(c_sld, f"{{{P_NS}}}spTree")

        # Group shape properties (required, id=1)
        nv_grp = etree.SubElement(sp_tree, f"{{{P_NS}}}nvGrpSpPr")
        etree.SubElement(nv_grp, f"{{{P_NS}}}cNvPr", id="1", name="")
        etree.SubElement(nv_grp, f"{{{P_NS}}}cNvGrpSpPr")
        etree.SubElement(nv_grp, f"{{{P_NS}}}nvPr")
        grp_sp_pr = etree.SubElement(sp_tree, f"{{{P_NS}}}grpSpPr")
        xfrm = etree.SubElement(grp_sp_pr, f"{{{A_NS}}}xfrm")
        etree.SubElement(xfrm, f"{{{A_NS}}}off", x="0", y="0")
        etree.SubElement(xfrm, f"{{{A_NS}}}ext", cx="0", cy="0")
        etree.SubElement(xfrm, f"{{{A_NS}}}chOff", x="0", y="0")
        etree.SubElement(xfrm, f"{{{A_NS}}}chExt", cx="0", cy="0")

        shape_id = 2
        for item in archetype.shapes:
            rect = rects.get(item.region)
            if rect is None:
                continue
            if isinstance(item, ShapeDef):
                self._emit_shape(sp_tree, item, rect, shape_id)
            elif isinstance(item, ConnectorDef):
                self._emit_connector(sp_tree, item, rect, shape_id)
            shape_id += 1

        return root

    # ------------------------------------------------------------------
    # Region resolution
    # ------------------------------------------------------------------

    @staticmethod
    def _resolve_regions(
        archetype: SlideArchetype,
        grid: SlideGrid,
        resolved_regions: dict[str, tuple[int, int, int, int]] | None,
    ) -> dict[str, tuple[int, int, int, int]]:
        rects: dict[str, tuple[int, int, int, int]] = {}
        for name, pos in archetype.regions.items():
            if resolved_regions and name in resolved_regions:
                rects[name] = resolved_regions[name]
            else:
                rects[name] = grid.cell_rect(
                    pos.col, pos.row, pos.col_span, pos.row_span
                )
        return rects

    # ------------------------------------------------------------------
    # Shape emission
    # ------------------------------------------------------------------

    def _emit_shape(
        self,
        parent: etree._Element,
        shape: ShapeDef,
        rect: tuple[int, int, int, int],
        shape_id: int,
    ) -> etree._Element:
        sp = etree.SubElement(parent, f"{{{P_NS}}}sp")

        # nvSpPr
        nv = etree.SubElement(sp, f"{{{P_NS}}}nvSpPr")
        etree.SubElement(nv, f"{{{P_NS}}}cNvPr", id=str(shape_id), name=shape.name)
        c_nv_sp_pr = etree.SubElement(nv, f"{{{P_NS}}}cNvSpPr")
        if shape.no_group:
            etree.SubElement(c_nv_sp_pr, f"{{{A_NS}}}spLocks", noGrp="1")
        nv_pr = etree.SubElement(nv, f"{{{P_NS}}}nvPr")
        if shape.ph_type is not None or shape.ph_idx is not None:
            ph = etree.SubElement(nv_pr, f"{{{P_NS}}}ph")
            if shape.ph_type is not None:
                ph.set("type", shape.ph_type)
            if shape.ph_idx is not None:
                ph.set("idx", shape.ph_idx)

        # spPr
        sp_pr = etree.SubElement(sp, f"{{{P_NS}}}spPr")
        x, y, cx, cy = rect
        xfrm = etree.SubElement(sp_pr, f"{{{A_NS}}}xfrm")
        etree.SubElement(xfrm, f"{{{A_NS}}}off", x=str(x), y=str(y))
        etree.SubElement(xfrm, f"{{{A_NS}}}ext", cx=str(cx), cy=str(cy))
        prst = etree.SubElement(sp_pr, f"{{{A_NS}}}prstGeom", prst=shape.kind)
        etree.SubElement(prst, f"{{{A_NS}}}avLst")

        if shape.no_fill:
            etree.SubElement(sp_pr, f"{{{A_NS}}}noFill")
        if shape.no_outline:
            ln = etree.SubElement(sp_pr, f"{{{A_NS}}}ln")
            etree.SubElement(ln, f"{{{A_NS}}}noFill")

        # txBody
        if shape.text is not None:
            self._emit_text_body(sp, shape.text)

        return sp

    def _emit_connector(
        self,
        parent: etree._Element,
        conn: ConnectorDef,
        rect: tuple[int, int, int, int],
        shape_id: int,
    ) -> etree._Element:
        cxn = etree.SubElement(parent, f"{{{P_NS}}}cxnSp")

        # nvCxnSpPr
        nv = etree.SubElement(cxn, f"{{{P_NS}}}nvCxnSpPr")
        etree.SubElement(nv, f"{{{P_NS}}}cNvPr", id=str(shape_id), name=conn.name)
        etree.SubElement(nv, f"{{{P_NS}}}cNvCxnSpPr")
        etree.SubElement(nv, f"{{{P_NS}}}nvPr")

        # spPr
        sp_pr = etree.SubElement(cxn, f"{{{P_NS}}}spPr")
        x, y, cx, cy = rect
        xfrm_attrs: dict[str, str] = {}
        if conn.flip_h:
            xfrm_attrs["flipH"] = "1"
        if conn.flip_v:
            xfrm_attrs["flipV"] = "1"
        xfrm = etree.SubElement(sp_pr, f"{{{A_NS}}}xfrm", **xfrm_attrs)
        etree.SubElement(xfrm, f"{{{A_NS}}}off", x=str(x), y=str(y))
        etree.SubElement(xfrm, f"{{{A_NS}}}ext", cx=str(cx), cy=str(cy))
        prst = etree.SubElement(sp_pr, f"{{{A_NS}}}prstGeom", prst=conn.kind)
        etree.SubElement(prst, f"{{{A_NS}}}avLst")

        # Line style
        width_emu = int(conn.width_pt * 12700)
        ln = etree.SubElement(sp_pr, f"{{{A_NS}}}ln", w=str(width_emu))
        fill = etree.SubElement(ln, f"{{{A_NS}}}solidFill")
        etree.SubElement(fill, f"{{{A_NS}}}schemeClr", val=conn.color)
        etree.SubElement(ln, f"{{{A_NS}}}tailEnd", type="arrow")

        return cxn

    # ------------------------------------------------------------------
    # Text body
    # ------------------------------------------------------------------

    def _emit_text_body(self, parent: etree._Element, text: TextBody) -> etree._Element:
        tx_body = etree.SubElement(parent, f"{{{P_NS}}}txBody")
        body_pr = etree.SubElement(tx_body, f"{{{A_NS}}}bodyPr")
        body_pr.set("anchor", text.anchor)
        if text.word_wrap:
            body_pr.set("wrap", "square")
        etree.SubElement(tx_body, f"{{{A_NS}}}lstStyle")

        for para in text.paragraphs:
            p = etree.SubElement(tx_body, f"{{{A_NS}}}p")
            p_pr = etree.SubElement(p, f"{{{A_NS}}}pPr")
            p_pr.set("algn", para.align)

            for run in para.runs:
                r = etree.SubElement(p, f"{{{A_NS}}}r")
                r_pr = etree.SubElement(r, f"{{{A_NS}}}rPr")
                r_pr.set("lang", "en-US")
                r_pr.set("sz", str(_pt_to_hundredths(run.size_pt)))
                if run.bold:
                    r_pr.set("b", "1")
                if run.italic:
                    r_pr.set("i", "1")
                color_fill = etree.SubElement(r_pr, f"{{{A_NS}}}solidFill")
                etree.SubElement(color_fill, f"{{{A_NS}}}schemeClr", val=run.color)
                t = etree.SubElement(r, f"{{{A_NS}}}t")
                t.text = run.text

            etree.SubElement(p, f"{{{A_NS}}}endParaRPr", lang="en-US")

        return tx_body
