"""Semantic normalization for long-form header/footer content."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterator, Literal, Mapping, TypeAlias


@dataclass(frozen=True)
class LiteralText:
    """Literal text content with no field semantics."""

    text: str


@dataclass(frozen=True)
class PageNumber:
    """Current page number field."""


@dataclass(frozen=True)
class PageCount:
    """Total document page count field."""


@dataclass(frozen=True)
class RunningHeading:
    """Running heading reference derived from a STYLEREF payload."""

    reference: str
    level: int = 1


@dataclass(frozen=True)
class DocumentTitle:
    """Resolved document title placeholder."""


@dataclass(frozen=True)
class SheetName:
    """Current worksheet name field."""


@dataclass(frozen=True)
class CurrentDate:
    """Current date field."""


@dataclass(frozen=True)
class CurrentTime:
    """Current time field."""


@dataclass(frozen=True)
class FileName:
    """Current file name field."""


SemanticContentItem: TypeAlias = (
    LiteralText
    | PageNumber
    | PageCount
    | RunningHeading
    | DocumentTitle
    | SheetName
    | CurrentDate
    | CurrentTime
    | FileName
)

LegacyContentTokenKind: TypeAlias = Literal[
    "page",
    "numpages",
    "styleref",
    "document_title",
    "text",
]
LegacyContentToken: TypeAlias = tuple[LegacyContentTokenKind, str]


@dataclass(frozen=True)
class SemanticContent:
    """Canonical semantic representation for a content slot."""

    items: tuple[SemanticContentItem, ...] = ()

    def __iter__(self) -> Iterator[SemanticContentItem]:
        return iter(self.items)


SemanticContentInput: TypeAlias = str | None | SemanticContent


def _heading_level(reference: str) -> int:
    digits = "".join(ch for ch in reference if ch.isdigit())
    if digits:
        return int(digits)
    return 1


def parse_semantic_content(spec: str | None) -> SemanticContent:
    """Normalize a legacy content slot string into semantic items."""
    if not spec:
        return SemanticContent()

    stripped = spec.strip()
    upper = stripped.upper()

    if upper == "PAGE OF NUMPAGES":
        return SemanticContent((PageNumber(), LiteralText(" of "), PageCount()))
    if upper == "PAGE":
        return SemanticContent((PageNumber(),))
    if upper == "NUMPAGES":
        return SemanticContent((PageCount(),))
    if upper == "DATE":
        return SemanticContent((CurrentDate(),))
    if upper == "TIME":
        return SemanticContent((CurrentTime(),))
    if upper == "FILENAME":
        return SemanticContent((FileName(),))
    if upper == "SHEETNAME":
        return SemanticContent((SheetName(),))
    if stripped.startswith("STYLEREF:"):
        reference = stripped[len("STYLEREF:") :]
        return SemanticContent((RunningHeading(reference, _heading_level(reference)),))
    if stripped == "{document.title}":
        return SemanticContent((DocumentTitle(),))

    return SemanticContent((LiteralText(spec),))


def ensure_semantic_content(content: SemanticContentInput) -> SemanticContent:
    """Return semantic content unchanged or parse a legacy string spec."""
    if isinstance(content, SemanticContent):
        return content
    return parse_semantic_content(content)


def _semantic_item_from_authored(raw: object) -> SemanticContentItem:
    if not isinstance(raw, Mapping):
        raise ValueError(f"semantic item must be an object, got {type(raw).__name__}")

    kind = raw.get("kind")
    if not isinstance(kind, str):
        raise ValueError("semantic item missing string 'kind'")

    if kind == "literal_text":
        text = raw.get("text", "")
        if not isinstance(text, str):
            raise ValueError("literal_text item requires string 'text'")
        return LiteralText(text)

    if kind == "page_number":
        return PageNumber()
    if kind == "page_count":
        return PageCount()
    if kind == "document_title":
        return DocumentTitle()
    if kind == "sheet_name":
        return SheetName()
    if kind == "current_date":
        return CurrentDate()
    if kind == "current_time":
        return CurrentTime()
    if kind == "file_name":
        return FileName()

    if kind == "running_heading":
        source = raw.get("source", "heading")
        if source != "heading":
            raise ValueError(
                f"running_heading only supports source='heading', got {source!r}"
            )
        reference = raw.get("reference")
        if reference is not None and not isinstance(reference, str):
            raise ValueError("running_heading 'reference' must be a string")

        level_raw = raw.get("level")
        if level_raw is None:
            level = _heading_level(reference) if reference is not None else 1
        elif isinstance(level_raw, int) and level_raw > 0:
            level = level_raw
        else:
            raise ValueError("running_heading 'level' must be a positive integer")

        heading_ref = reference or f"Heading{level}"
        return RunningHeading(reference=heading_ref, level=level)

    raise ValueError(f"unsupported semantic kind {kind!r}")


def parse_authored_semantic_content(value: object) -> SemanticContent:
    """Parse either legacy string content or structured semantic items."""
    if value is None:
        return SemanticContent()
    if isinstance(value, SemanticContent):
        return value
    if isinstance(value, str):
        return parse_semantic_content(value)
    if isinstance(value, Mapping):
        return SemanticContent((_semantic_item_from_authored(value),))
    if isinstance(value, list):
        return SemanticContent(
            tuple(_semantic_item_from_authored(item) for item in value)
        )
    raise ValueError(
        "content value must be a string, semantic item object, or list of items"
    )


def _legacy_text_for_item(item: SemanticContentItem) -> str:
    if isinstance(item, LiteralText):
        return item.text
    if isinstance(item, CurrentDate):
        return "DATE"
    if isinstance(item, CurrentTime):
        return "TIME"
    if isinstance(item, FileName):
        return "FILENAME"
    if isinstance(item, SheetName):
        return "SHEETNAME"
    return ""


def to_legacy_content_tokens(content: SemanticContent) -> list[LegacyContentToken]:
    """Project semantic items onto the legacy Word/ODF token tuple API."""
    tokens: list[LegacyContentToken] = []
    for item in content:
        if isinstance(item, PageNumber):
            tokens.append(("page", ""))
        elif isinstance(item, PageCount):
            tokens.append(("numpages", ""))
        elif isinstance(item, RunningHeading):
            tokens.append(("styleref", item.reference))
        elif isinstance(item, DocumentTitle):
            tokens.append(("document_title", ""))
        else:
            tokens.append(("text", _legacy_text_for_item(item)))
    return tokens


def to_legacy_content_spec(content: SemanticContent) -> str | None:
    """Serialize semantic content onto the legacy slot-string surface.

    This is a compatibility view for callers that still expect the old
    string-based slot DSL. It is not used as the canonical IR form.
    """
    if not content.items:
        return None

    def _part(item: SemanticContentItem) -> str:
        if isinstance(item, LiteralText):
            return item.text
        if isinstance(item, PageNumber):
            return "PAGE"
        if isinstance(item, PageCount):
            return "NUMPAGES"
        if isinstance(item, RunningHeading):
            return f"STYLEREF:{item.reference}"
        if isinstance(item, DocumentTitle):
            return "{document.title}"
        if isinstance(item, SheetName):
            return "SHEETNAME"
        if isinstance(item, CurrentDate):
            return "DATE"
        if isinstance(item, CurrentTime):
            return "TIME"
        if isinstance(item, FileName):
            return "FILENAME"
        raise ValueError(f"unsupported semantic item {item!r}")

    return "".join(_part(item) for item in content.items)


def parse_legacy_content_tokens(spec: SemanticContentInput) -> list[LegacyContentToken]:
    """Compatibility wrapper for the historical tuple-token API."""
    return to_legacy_content_tokens(ensure_semantic_content(spec))
