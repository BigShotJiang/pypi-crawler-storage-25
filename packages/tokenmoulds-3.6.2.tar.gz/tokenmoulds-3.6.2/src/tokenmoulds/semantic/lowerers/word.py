"""Word lowering for semantic header/footer content."""

from __future__ import annotations

from tokenmoulds.semantic.content import (
    CurrentDate,
    CurrentTime,
    DocumentTitle,
    FileName,
    LegacyContentToken as ContentToken,
    LegacyContentTokenKind,
    LiteralText,
    PageCount,
    PageNumber,
    RunningHeading,
    SemanticContentInput,
    SheetName,
    ensure_semantic_content,
    to_legacy_content_tokens,
)
from tokenmoulds.semantic.capabilities import capability_for
from tokenmoulds.semantic.provenance import LoweringDecision, LoweringResult

ContentTokenKind = LegacyContentTokenKind


def _rendered_for_word_item(item: object) -> dict[str, object]:
    if isinstance(item, PageNumber):
        return {"token": "page", "value": ""}
    if isinstance(item, PageCount):
        return {"token": "numpages", "value": ""}
    if isinstance(item, RunningHeading):
        return {"token": "styleref", "value": item.reference}
    if isinstance(item, DocumentTitle):
        return {"token": "document_title", "value": ""}
    if isinstance(item, LiteralText):
        return {"token": "text", "value": item.text}
    if isinstance(item, SheetName):
        return {"token": "text", "value": "SHEETNAME"}
    if isinstance(item, CurrentDate):
        return {"token": "text", "value": "DATE"}
    if isinstance(item, CurrentTime):
        return {"token": "text", "value": "TIME"}
    if isinstance(item, FileName):
        return {"token": "text", "value": "FILENAME"}
    raise TypeError(f"Unsupported semantic item {item!r}")


def lower_word_content(
    content: SemanticContentInput,
) -> LoweringResult[tuple[ContentToken, ...]]:
    """Lower semantic content to Word compatibility tokens with provenance."""
    semantic = ensure_semantic_content(content)
    decisions = tuple(
        LoweringDecision(
            kind=capability_for("word", item).kind,
            mode=capability_for("word", item).mode,
            rendered=_rendered_for_word_item(item),
            reason=capability_for("word", item).reason,
        )
        for item in semantic
    )
    return LoweringResult(
        rendered=tuple(to_legacy_content_tokens(semantic)),
        decisions=decisions,
    )


def lower_word_content_tokens(content: SemanticContentInput) -> list[ContentToken]:
    """Lower semantic content to the historical Word/ODF token tuple API."""
    return list(lower_word_content(content).rendered)
