"""Default slide layout region generation."""

from __future__ import annotations

from typing import Any

from tokenmoulds.design.page_geometry import SlideGrid

def compute_default_slide_regions(
    grid_or_baseline: SlideGrid | float,
    *,
    brand_tone: float = 0.5,
) -> dict[str, Any]:
    """Compute grid-coordinate layout recipes for standard and semantic layouts.

    Args:
        grid_or_baseline: A ``SlideGrid`` to compute for, or a baseline EMU
            value (in which case a default 16:9 reference grid is created).
        brand_tone: Brand tone (0.0 = conservative, 0.5 = balanced,
            1.0 = expressive).  Modulates zone boundaries per the spec:
            title height, gutter, footer size, and title-slide positioning.

    Each region is a dict of ``{col, row, col_span, row_span}`` in grid
    units.  These are concrete values computed from the grid dimensions
    — layers can override any value.
    """
    if isinstance(grid_or_baseline, SlideGrid):
        grid = grid_or_baseline
    else:
        from tokenmoulds.design.page_geometry import create_slide_grid

        grid = create_slide_grid(9144000, 5143500, int(grid_or_baseline))

    t = max(0.0, min(1.0, brand_tone))
    C, R = grid.columns, grid.rows

    # --- Shared zone boundaries (brand-tone-modulated) ---
    # Conservative(0): min(7, R//4)  Balanced(0.5): min(6, R//4)  Expressive(1): min(5, R//4)
    title_rows = min(int(7 - 2 * t), R // 4)
    # Conservative(0): 2  Balanced(0.5): 1  Expressive(1): 1
    gutter = 2 if t < 0.25 else 1
    # Conservative(0): 2  Balanced(0.5): 2  Expressive(1): 1
    footer_rows = 1 if t > 0.75 else 2
    body_start = title_rows + gutter
    body_rows = R - body_start
    # Body excluding footer zone
    body_content_rows = body_rows - footer_rows - 1
    footer_start = R - footer_rows

    half_cols = C // 2
    two_thirds = C * 2 // 3
    one_third = C - two_thirds

    def _r(col: int, row: int, cs: int, rs: int) -> dict[str, int]:
        return {"col": col, "row": row, "col_span": cs, "row_span": rs}

    # Incidental placeholders (date / footer / slide number)
    third = C // 3
    incidentals = {
        "date": _r(0, footer_start, third, footer_rows),
        "footer": _r(third, footer_start, third, footer_rows),
        "slide_num": _r(2 * third, footer_start, C - 2 * third, footer_rows),
    }

    # --- Title Slide (brand-tone-modulated) ---
    # Conservative(0): centered R/2-span/2  Balanced(0.5): golden R*0.38  Expressive(1): upper R/4
    _ctr_frac = 0.5 - 0.25 * t  # 0.5 → 0.38 → 0.25
    ctr_start = max(2, int(R * _ctr_frac - R * (1 / 3 + t / 6) / 2))
    # Conservative(0): R*1/3  Balanced(0.5): R*2/5  Expressive(1): R*1/2
    ctr_span = max(4, int(R * (1 / 3 + t / 6)))
    sub_start = ctr_start + ctr_span + 1
    sub_span = max(4, R // 6)

    # --- Section Header (brand-tone-modulated) ---
    # Conservative(0): R/3  Balanced(0.5): R/4  Expressive(1): R/5
    _sec_frac = 1 / 3 - t / 15  # 0.333 → 0.267 → 0.200
    sec_start = max(2, int(R * _sec_frac))
    sec_span = R * 9 // 20
    desc_start = sec_start + sec_span
    desc_span = max(4, R // 5)

    # --- Comparison: labels + content ---
    label_rows = min(3, body_rows // 6)
    content_gap = 1
    content_start = body_start + label_rows + content_gap
    content_rows = body_rows - label_rows - content_gap

    hero_overlay_cols = max(5, min(C - 3, two_thirds))
    hero_title_start = max(3, R // 7)
    hero_title_span = max(6, R * 3 // 10)
    hero_subtitle_start = hero_title_start + hero_title_span + 1
    hero_subtitle_span = max(4, min(R // 6, max(4, footer_start - hero_subtitle_start)))
    hero_kicker_row = max(2, hero_title_start - 2)
    hero_footer_band_start = max(footer_start - 1, hero_subtitle_start + 1)
    hero_footer_band_rows = max(2, R - hero_footer_band_start)

    section_title_start = max(2, R // 5)
    section_title_span = max(5, R // 5)
    section_body_start = section_title_start + section_title_span + 1
    section_body_span = max(4, min(R // 6, footer_start - section_body_start))

    card_start_row = body_start
    card_gap = 1
    card_height = max(4, (body_content_rows - card_gap) // 2)
    card_width = max(3, (C - card_gap) // 2)
    card_right_col = C - card_width
    card_second_row = min(
        R - footer_rows - card_height, card_start_row + card_height + card_gap
    )

    return {
        "title_slide": {
            "title": _r(0, ctr_start, C, ctr_span),
            "subtitle": _r(0, sub_start, C, sub_span),
            **incidentals,
        },
        "title_content": {
            "title": _r(0, 0, C, title_rows),
            "body": _r(0, body_start, C, body_content_rows),
            **incidentals,
        },
        "section_header": {
            "title": _r(0, sec_start, C, sec_span),
            "body": _r(0, desc_start, C, desc_span),
            **incidentals,
        },
        "two_content": {
            "title": _r(0, 0, C, title_rows),
            "body_left": _r(0, body_start, half_cols, body_content_rows),
            "body_right": _r(half_cols, body_start, C - half_cols, body_content_rows),
            **incidentals,
        },
        "comparison": {
            "title": _r(0, 0, C, title_rows),
            "label_left": _r(0, body_start, half_cols, label_rows),
            "content_left": _r(0, content_start, half_cols, content_rows),
            "label_right": _r(half_cols, body_start, C - half_cols, label_rows),
            "content_right": _r(half_cols, content_start, C - half_cols, content_rows),
            **incidentals,
        },
        "title_only": {
            "title": _r(0, 0, C, title_rows),
            **incidentals,
        },
        "blank": {
            **incidentals,
        },
        "content_caption": {
            "title": _r(0, 0, C, title_rows),
            "content": _r(0, body_start, two_thirds, body_content_rows),
            "caption": _r(two_thirds, body_start, one_third, body_content_rows),
            **incidentals,
        },
        "picture_caption": {
            "title": _r(0, 0, C, title_rows),
            "picture": _r(0, body_start, two_thirds, body_content_rows),
            "caption": _r(two_thirds, body_start, one_third, body_content_rows),
            **incidentals,
        },
        "vertical_text": {
            "title": _r(0, 0, C, title_rows),
            "body": _r(0, body_start, C, body_content_rows),
            **incidentals,
        },
        "vertical_title": {
            "title": _r(C - one_third, 0, one_third, R - footer_rows - 1),
            "body": _r(0, 0, two_thirds, R - footer_rows - 1),
            **incidentals,
        },
        # --- Extended standard layouts ---
        "title_alt": {
            "title": _r(0, ctr_start, C, ctr_span),
            "subtitle": _r(0, sub_start, C, sub_span),
            **incidentals,
        },
        "text": {
            "title": _r(0, 0, C, title_rows),
            "body": _r(0, body_start, C, body_content_rows),
            **incidentals,
        },
        "two_column_text": {
            "title": _r(0, 0, C, title_rows),
            "body_left": _r(0, body_start, half_cols, body_content_rows),
            "body_right": _r(half_cols, body_start, C - half_cols, body_content_rows),
            **incidentals,
        },
        "table": {
            "title": _r(0, 0, C, title_rows),
            "table": _r(0, body_start, C, body_content_rows),
            **incidentals,
        },
        "text_and_chart": {
            "title": _r(0, 0, C, title_rows),
            "text": _r(0, body_start, half_cols, body_content_rows),
            "chart": _r(half_cols, body_start, C - half_cols, body_content_rows),
            **incidentals,
        },
        "chart_and_text": {
            "title": _r(0, 0, C, title_rows),
            "chart": _r(0, body_start, half_cols, body_content_rows),
            "text": _r(half_cols, body_start, C - half_cols, body_content_rows),
            **incidentals,
        },
        "diagram": {
            "title": _r(0, 0, C, title_rows),
            "diagram": _r(0, body_start, C, body_content_rows),
            **incidentals,
        },
        "chart": {
            "title": _r(0, 0, C, title_rows),
            "chart": _r(0, body_start, C, body_content_rows),
            **incidentals,
        },
        "text_and_clipart": {
            "title": _r(0, 0, C, title_rows),
            "text": _r(0, body_start, half_cols, body_content_rows),
            "clipart": _r(half_cols, body_start, C - half_cols, body_content_rows),
            **incidentals,
        },
        "clipart_and_text": {
            "title": _r(0, 0, C, title_rows),
            "clipart": _r(0, body_start, half_cols, body_content_rows),
            "text": _r(half_cols, body_start, C - half_cols, body_content_rows),
            **incidentals,
        },
        "text_and_media": {
            "title": _r(0, 0, C, title_rows),
            "text": _r(0, body_start, half_cols, body_content_rows),
            "media": _r(half_cols, body_start, C - half_cols, body_content_rows),
            **incidentals,
        },
        "media_and_text": {
            "title": _r(0, 0, C, title_rows),
            "media": _r(0, body_start, half_cols, body_content_rows),
            "text": _r(half_cols, body_start, C - half_cols, body_content_rows),
            **incidentals,
        },
        "text_and_object": {
            "title": _r(0, 0, C, title_rows),
            "text": _r(0, body_start, half_cols, body_content_rows),
            "object": _r(half_cols, body_start, C - half_cols, body_content_rows),
            **incidentals,
        },
        "object_and_text": {
            "title": _r(0, 0, C, title_rows),
            "object": _r(0, body_start, half_cols, body_content_rows),
            "text": _r(half_cols, body_start, C - half_cols, body_content_rows),
            **incidentals,
        },
        "object_only": {
            "title": _r(0, 0, C, title_rows),
            "object": _r(0, body_start, C, body_content_rows),
            **incidentals,
        },
        "object_over_text": {
            "title": _r(0, 0, C, title_rows),
            "object": _r(0, body_start, C, body_content_rows // 2),
            "text": _r(
                0,
                body_start + body_content_rows // 2,
                C,
                body_content_rows - body_content_rows // 2,
            ),
            **incidentals,
        },
        "text_over_object": {
            "title": _r(0, 0, C, title_rows),
            "text": _r(0, body_start, C, body_content_rows // 2),
            "object": _r(
                0,
                body_start + body_content_rows // 2,
                C,
                body_content_rows - body_content_rows // 2,
            ),
            **incidentals,
        },
        "text_and_two_objects": {
            "title": _r(0, 0, C, title_rows),
            "text": _r(0, body_start, one_third, body_content_rows),
            "object_top": _r(one_third, body_start, two_thirds, body_content_rows // 2),
            "object_bottom": _r(
                one_third,
                body_start + body_content_rows // 2,
                two_thirds,
                body_content_rows - body_content_rows // 2,
            ),
            **incidentals,
        },
        "two_objects_and_text": {
            "title": _r(0, 0, C, title_rows),
            "object_top": _r(0, body_start, two_thirds, body_content_rows // 2),
            "object_bottom": _r(
                0,
                body_start + body_content_rows // 2,
                two_thirds,
                body_content_rows - body_content_rows // 2,
            ),
            "text": _r(two_thirds, body_start, one_third, body_content_rows),
            **incidentals,
        },
        "two_objects_over_text": {
            "title": _r(0, 0, C, title_rows),
            "object_left": _r(0, body_start, half_cols, body_content_rows * 2 // 3),
            "object_right": _r(
                half_cols, body_start, C - half_cols, body_content_rows * 2 // 3
            ),
            "text": _r(
                0,
                body_start + body_content_rows * 2 // 3,
                C,
                body_content_rows - body_content_rows * 2 // 3,
            ),
            **incidentals,
        },
        "four_objects": {
            "title": _r(0, 0, C, title_rows),
            "object_tl": _r(0, body_start, half_cols, body_content_rows // 2),
            "object_tr": _r(
                half_cols, body_start, C - half_cols, body_content_rows // 2
            ),
            "object_bl": _r(
                0,
                body_start + body_content_rows // 2,
                half_cols,
                body_content_rows - body_content_rows // 2,
            ),
            "object_br": _r(
                half_cols,
                body_start + body_content_rows // 2,
                C - half_cols,
                body_content_rows - body_content_rows // 2,
            ),
            **incidentals,
        },
        "object_and_two_objects": {
            "title": _r(0, 0, C, title_rows),
            "object_large": _r(0, body_start, half_cols, body_content_rows),
            "object_top": _r(
                half_cols, body_start, C - half_cols, body_content_rows // 2
            ),
            "object_bottom": _r(
                half_cols,
                body_start + body_content_rows // 2,
                C - half_cols,
                body_content_rows - body_content_rows // 2,
            ),
            **incidentals,
        },
        "two_objects_and_object": {
            "title": _r(0, 0, C, title_rows),
            "object_top": _r(0, body_start, half_cols, body_content_rows // 2),
            "object_bottom": _r(
                0,
                body_start + body_content_rows // 2,
                half_cols,
                body_content_rows - body_content_rows // 2,
            ),
            "object_large": _r(half_cols, body_start, C - half_cols, body_content_rows),
            **incidentals,
        },
        "large_object": {
            "title": _r(0, 0, C, title_rows),
            "content": _r(0, body_start, C, body_content_rows),
            **incidentals,
        },
        "clipart_and_vertical_text": {
            "title": _r(0, 0, C, title_rows),
            "clipart": _r(0, body_start, half_cols, body_content_rows),
            "text": _r(half_cols, body_start, C - half_cols, body_content_rows),
            **incidentals,
        },
        "vertical_title_text_chart": {
            "title": _r(C - one_third, 0, one_third, R - footer_rows - 1),
            "content": _r(0, 0, two_thirds, R - footer_rows - 1),
            **incidentals,
        },
        "hero_cover": {
            "background": _r(0, 0, C, R),
            "overlay": _r(0, 0, hero_overlay_cols, R),
            "kicker": _r(0, hero_kicker_row, max(3, hero_overlay_cols - 2), 2),
            "title": _r(
                0, hero_title_start, max(4, hero_overlay_cols - 1), hero_title_span
            ),
            "subtitle": _r(
                0,
                hero_subtitle_start,
                max(4, hero_overlay_cols - 2),
                hero_subtitle_span,
            ),
            "footer_band": _r(0, hero_footer_band_start, C, hero_footer_band_rows),
            **incidentals,
        },
        "section_statement": {
            "background": _r(0, 0, C, R),
            "band": _r(0, 0, one_third, R),
            "title": _r(
                one_third, section_title_start, C - one_third, section_title_span
            ),
            "body": _r(one_third, section_body_start, C - one_third, section_body_span),
            **incidentals,
        },
        "card_matrix": {
            "title": _r(0, 0, C, title_rows),
            "card_1": _r(0, card_start_row, card_width, card_height),
            "card_2": _r(card_right_col, card_start_row, card_width, card_height),
            "card_3": _r(0, card_second_row, card_width, card_height),
            "card_4": _r(card_right_col, card_second_row, card_width, card_height),
            "body": _r(
                0, footer_start - max(3, footer_rows + 1), C, max(3, footer_rows + 1)
            ),
            **incidentals,
        },
    }
