"""Resolve tokenized slide layout recipes to EMU placeholder positions."""

from __future__ import annotations

from collections.abc import Iterator
from typing import Any

from tokenmoulds.design.page_geometry import SlideGrid
from tokenmoulds.dtcg.layout_recipe_catalog import (
    PPTX_PLACEHOLDER_MAP,
    PPTX_TO_LAYOUT_TYPE,
    SEMANTIC_LAYOUT_SPECS,
    SemanticLayoutSpec,
)

def get_semantic_layout_spec(layout_name: str) -> SemanticLayoutSpec | None:
    """Return semantic layout metadata for non-standard slide archetypes."""

    return SEMANTIC_LAYOUT_SPECS.get(layout_name)


def get_semantic_layout_spec_for_pptx_layout_number(
    layout_number: int,
) -> SemanticLayoutSpec | None:
    """Return the semantic layout spec assigned to a PPTX layout part number."""

    for spec in SEMANTIC_LAYOUT_SPECS.values():
        if spec.pptx_layout_number == layout_number:
            return spec
    return None


def get_semantic_layout_names() -> tuple[str, ...]:
    """Return the known semantic slide archetype names."""

    return tuple(SEMANTIC_LAYOUT_SPECS)

#: Incidental region names excluded from ODF layout resolution.
_INCIDENTAL_REGIONS: frozenset[str] = frozenset({"date", "footer", "slide_num"})


def _iter_content_regions(
    regions: dict[str, dict[str, Any]],
    *,
    include_incidentals: bool = True,
) -> Iterator[tuple[str, int, int, int, int]]:
    """Yield ``(region_name, col, row, col_span, row_span)`` for valid regions."""
    for name, data in regions.items():
        if name.startswith("$"):
            continue
        if not include_incidentals and name in _INCIDENTAL_REGIONS:
            continue
        if not isinstance(data, dict) or "col" not in data:
            continue
        yield (
            name,
            int(data["col"]),
            int(data["row"]),
            int(data["col_span"]),
            int(data["row_span"]),
        )


def resolve_layout_recipe(
    layout_type: str,
    regions: dict[str, dict[str, Any]],
    grid: SlideGrid,
) -> dict[tuple[str | None, str | None], tuple[int, int, int, int]]:
    """Resolve a single layout's region tokens to PPTX placeholder positions.

    Args:
        layout_type: Token layout type name (e.g. ``"title_slide"``).
        regions: Dict of region name → ``{col, row, col_span, row_span}``.
        grid: The slide grid for converting coordinates to EMU.

    Returns:
        Mapping of ``(ph_type, ph_idx)`` → ``(x, y, cx, cy)`` in EMU,
        suitable for patching PPTX slide layout XML.
    """
    ph_map = PPTX_PLACEHOLDER_MAP.get(layout_type, {})
    result: dict[tuple[str | None, str | None], tuple[int, int, int, int]] = {}

    for region_name, col, row, cs, rs in _iter_content_regions(regions):
        if region_name not in ph_map:
            continue
        result[ph_map[region_name]] = grid.cell_rect(col, row, cs, rs)

    return result


def resolve_all_layout_recipes(
    slide_regions: dict[str, Any],
    grid: SlideGrid,
) -> dict[str, dict[tuple[str | None, str | None], tuple[int, int, int, int]]]:
    """Resolve all layout recipes from the token tree.

    Args:
        slide_regions: The ``layout.slide.regions`` token subtree, keyed
            by layout type name.
        grid: The slide grid for the target aspect ratio.

    Returns:
        Mapping of token layout type → placeholder positions dict.
    """
    result: dict[
        str, dict[tuple[str | None, str | None], tuple[int, int, int, int]]
    ] = {}

    for layout_type in PPTX_PLACEHOLDER_MAP:
        regions = slide_regions.get(layout_type)
        if regions is None or not isinstance(regions, dict):
            continue
        recipe = resolve_layout_recipe(layout_type, regions, grid)
        if recipe:
            result[layout_type] = recipe

    return result


def resolve_for_pptx_layout_type(
    pptx_type: str,
    slide_regions: dict[str, Any],
    grid: SlideGrid,
) -> dict[tuple[str | None, str | None], tuple[int, int, int, int]]:
    """Resolve layout recipe for a PPTX layout type string.

    This is the drop-in replacement for ``_compute_layout_positions()``
    in supertheme.py.

    Args:
        pptx_type: PPTX layout type attribute (e.g. ``"title"``, ``"obj"``).
        slide_regions: The ``layout.slide.regions`` token subtree.
        grid: The slide grid for the target aspect ratio.

    Returns:
        Mapping of ``(ph_type, ph_idx)`` → ``(x, y, cx, cy)`` in EMU.
        Returns empty dict if the layout type has no recipe.
    """
    layout_type = PPTX_TO_LAYOUT_TYPE.get(pptx_type)
    if layout_type is None:
        return {}

    regions = slide_regions.get(layout_type)
    if regions is None or not isinstance(regions, dict):
        return {}

    return resolve_layout_recipe(layout_type, regions, grid)


def resolve_layout_by_name(
    layout_type: str,
    regions: dict[str, dict[str, Any]],
    grid: SlideGrid,
) -> dict[str, tuple[int, int, int, int]]:
    """Resolve a layout's regions to EMU positions keyed by region name.

    Unlike ``resolve_layout_recipe()`` which keys by PPTX (ph_type, ph_idx),
    this returns positions keyed by the token region name (e.g. ``"title"``,
    ``"body"``).  Used by ODF emitters and the IR design bridge.

    Incidental regions (date, footer, slide_num) are excluded since ODF
    handles these differently.
    """
    return {
        name: grid.cell_rect(col, row, cs, rs)
        for name, col, row, cs, rs in _iter_content_regions(
            regions, include_incidentals=False
        )
    }
