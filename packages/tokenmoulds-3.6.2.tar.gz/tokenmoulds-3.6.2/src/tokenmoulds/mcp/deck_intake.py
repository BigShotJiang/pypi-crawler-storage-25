"""Clarification contract for underspecified deck requests.

MCP clients often receive vague prompts like "make me slides".  This module
keeps that failure mode polite and structured: ask for content intent, not for
PowerPoint implementation details.
"""

from __future__ import annotations

from typing import Any

DEFAULT_TITLE = "Untitled Presentation"
MAX_INTAKE_QUESTIONS = 3


def deck_clarification_if_needed(
    arguments: dict[str, Any],
) -> dict[str, Any] | None:
    """Return a structured clarification request when deck content is missing."""
    slides = arguments.get("slides")
    markdown = arguments.get("markdown") or arguments.get("content")
    if _has_slide_content(slides) or _has_text(markdown):
        return None

    title = str(arguments.get("title") or DEFAULT_TITLE).strip()
    questions = _intake_questions(arguments, title)
    return {
        "needs_clarification": True,
        "action": "create_powerpoint_document",
        "ask_user": _ask_user(title),
        "questions": questions,
        "guidance_for_llm": (
            "Ask these questions in one concise message. Do not ask the user "
            "to choose layouts, placeholders, grids, slide masters, or cloned "
            "layout strategy unless they are explicitly designing a template."
        ),
        "accepted_inputs": [
            "markdown deck brief using # for title, ## for slides, and ### for grouped sections",
            "slides with layout and placeholder content",
            "short source notes plus audience and approximate slide count",
        ],
    }


def _has_slide_content(slides: Any) -> bool:
    if not isinstance(slides, list) or not slides:
        return False
    return any(isinstance(slide, dict) and bool(slide) for slide in slides)


def _has_text(value: Any) -> bool:
    return isinstance(value, str) and bool(value.strip())


def _has_meaningful_title(title: str) -> bool:
    return bool(title) and title != DEFAULT_TITLE


def _intake_questions(arguments: dict[str, Any], title: str) -> list[str]:
    questions: list[str] = []
    if _has_meaningful_title(title):
        questions.append(f"What source notes should I use for {title}?")
    else:
        questions.append(
            "What should the deck be about, and what source notes should I use?"
        )

    if not _has_text(arguments.get("audience")):
        questions.append("Who is the audience?")

    if not arguments.get("slide_count"):
        questions.append("How many slides do you want?")

    return questions[:MAX_INTAKE_QUESTIONS]


def _ask_user(title: str) -> str:
    if _has_meaningful_title(title):
        return (
            f"I can make {title}. To avoid inventing content, I need a short "
            "brief first."
        )
    return (
        "I can make the deck. To avoid inventing content, I need a short "
        "brief first."
    )
