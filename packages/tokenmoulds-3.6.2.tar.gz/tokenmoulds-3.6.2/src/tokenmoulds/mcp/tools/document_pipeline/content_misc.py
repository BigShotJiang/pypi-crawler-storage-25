"""Excel, ODF, and markdown content injection helpers."""

from __future__ import annotations

import zipfile
from io import BytesIO
from typing import Any, Dict, List

def _inject_excel_content(
    template_bytes: bytes,
    sheets: List[Dict[str, Any]],
) -> bytes:
    """Inject sheet data into Excel template.

    Note: Full sheet data injection requires modifying sheet XML.
    This is a placeholder that converts template to workbook.
    """
    input_zip = BytesIO(template_bytes)
    output_zip = BytesIO()

    with zipfile.ZipFile(input_zip, "r") as zin:
        with zipfile.ZipFile(
            output_zip, "w", zipfile.ZIP_DEFLATED, compresslevel=9
        ) as zout:
            for item in zin.namelist():
                data = zin.read(item)
                if item == "[Content_Types].xml":
                    data = data.replace(
                        b"spreadsheetml.template.main+xml",
                        b"spreadsheetml.sheet.main+xml",
                    )
                zout.writestr(item, data)

    return output_zip.getvalue()


# ============================================================================
# ODF Content Injection (Writer/Impress)
# ============================================================================


def _inject_writer_content(
    template_bytes: bytes,
    content_blocks: List[Dict[str, Any]],
) -> bytes:
    """Inject content into ODF Writer template.

    ODF uses content.xml instead of word/document.xml.
    """
    # For now, just return the template as-is (converted to .odt)
    # Full ODF injection would modify content.xml
    return template_bytes


def _inject_impress_content(
    template_bytes: bytes,
    slides: List[Dict[str, Any]],
) -> bytes:
    """Inject slides into ODF Impress template."""
    # For now, just return the template as-is
    return template_bytes


# ============================================================================
# Utility Functions
# ============================================================================


def _parse_markdown_to_blocks(markdown: str) -> List[Dict[str, Any]]:
    """Parse markdown content into content blocks.

    Uses mistune for full GFM (GitHub Flavored Markdown) support:
    - Headings (# ## ### ####)
    - Paragraphs with inline formatting (bold, italic, strikethrough, code)
    - Bullet lists (- *)
    - Numbered lists (1. 2.)
    - Tables (GFM)
    - Code blocks (```)
    - Block quotes (>)
    - Horizontal rules (---)
    - Links [text](url)
    """
    from tokenmoulds.mcp.markdown import markdown_to_blocks

    return markdown_to_blocks(markdown)
