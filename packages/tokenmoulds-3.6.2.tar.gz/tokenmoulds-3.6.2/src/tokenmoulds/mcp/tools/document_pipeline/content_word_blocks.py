"""Word block rendering helpers for MCP document tools."""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

from lxml import etree

from tokenmoulds.emitters import TemplateResolver
from tokenmoulds.mcp.tools.token_utils import escape_xml as _escape_xml

WORD_NSMAP = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}

def _render_word_content_block(
    block: Dict[str, Any],
    templates: TemplateResolver,
    style_context: Dict[str, Any],
) -> List[etree._Element]:
    """Render a content block to Word XML elements."""
    block_type = block.get("type", "paragraph")
    runs = _get_runs_from_block(block)
    text = _get_text_from_block(block)
    items = block.get("items", [])
    rows = block.get("rows", [])
    level = block.get("indent", block.get("level", 0))

    # Check if we have formatted runs
    has_formatting = "runs" in block and any(
        r.get("bold")
        or r.get("italic")
        or r.get("strikethrough")
        or r.get("code")
        or r.get("link")
        for r in block.get("runs", [])
    )

    if block_type == "title":
        if has_formatting:
            return [_render_word_paragraph_with_runs(templates, runs, "Title")]
        return [_render_word_heading(templates, "Title", text)]

    elif block_type in ("heading1", "heading2", "heading3", "heading4"):
        level_num = block_type[-1]
        if has_formatting:
            return [
                _render_word_paragraph_with_runs(templates, runs, f"Heading{level_num}")
            ]
        return [_render_word_heading(templates, f"Heading{level_num}", text)]

    elif block_type == "paragraph":
        if has_formatting:
            return [_render_word_paragraph_with_runs(templates, runs, "BodyText")]
        return [_render_word_paragraph(templates, text)]

    elif block_type in ("quote", "block_quote"):
        if has_formatting:
            return [_render_word_paragraph_with_runs(templates, runs, "Quote")]
        return [_render_word_heading(templates, "Quote", text)]

    elif block_type == "code_block":
        # Use a monospace style if available
        return [_render_word_heading(templates, "Code", text)]

    elif block_type == "bullet_list":
        # Handle new format with runs
        if runs:
            return [
                _render_word_list_item_with_runs(
                    templates, runs, numbered=False, level=level
                )
            ]
        return _render_word_list(templates, items, numbered=False, level=level)

    elif block_type == "numbered_list":
        if runs:
            return [
                _render_word_list_item_with_runs(
                    templates, runs, numbered=True, level=level
                )
            ]
        return _render_word_list(templates, items, numbered=True, level=level)

    elif block_type == "table":
        table_style = style_context.get("table_style", "LightGrid-Accent1")
        return [_render_word_table_with_runs(templates, rows, table_style)]

    elif block_type == "horizontal_rule":
        return [_render_word_horizontal_rule()]

    elif block_type == "page_break":
        return [_render_word_page_break()]

    return []


def _render_word_heading(
    templates: TemplateResolver, style_id: str, text: str
) -> etree._Element:
    """Render a heading using template."""
    xml = templates.read_text("paragraph_heading.xml")
    xml = xml.replace("${STYLE_ID}", style_id)
    xml = xml.replace("${TEXT}", text)
    return etree.fromstring(xml.encode("utf-8"))


class HyperlinkTracker:
    """Tracks hyperlinks for relationship generation."""

    def __init__(self):
        self.links: List[Dict[str, str]] = []
        self.images: List[Dict[str, Any]] = []
        self._next_id = 100  # Start at rId100 to avoid conflicts

    def add_link(self, url: str) -> str:
        """Add a hyperlink and return its relationship ID."""
        rid = f"rId{self._next_id}"
        self._next_id += 1
        self.links.append({"id": rid, "url": url})
        return rid

    def add_image(self, url: str, data: bytes, ext: str) -> str:
        """Add an image and return its relationship ID."""
        rid = f"rId{self._next_id}"
        self._next_id += 1
        filename = f"image{len(self.images) + 1}.{ext}"
        self.images.append(
            {
                "id": rid,
                "url": url,
                "data": data,
                "filename": filename,
            }
        )
        return rid


# Global tracker for current document (reset per document)
_hyperlink_tracker: Optional[HyperlinkTracker] = None


def start_hyperlink_tracking() -> HyperlinkTracker:
    """Create a tracker for the current Word document."""
    global _hyperlink_tracker
    _hyperlink_tracker = HyperlinkTracker()
    return _hyperlink_tracker


def get_hyperlink_tracker() -> Optional[HyperlinkTracker]:
    """Return the tracker for the current Word document, if one exists."""
    return _hyperlink_tracker


def clear_hyperlink_tracking() -> None:
    """Clear the tracker for the current Word document."""
    global _hyperlink_tracker
    _hyperlink_tracker = None


def _fetch_image(url: str) -> Optional[Tuple[bytes, str]]:
    """Fetch image from URL or file path.

    Returns (data, extension) or None if failed.
    """
    import urllib.request
    from pathlib import Path

    try:
        # Check if it's a local file
        if url.startswith("/") or url.startswith("file://"):
            path = Path(url.replace("file://", ""))
            if path.exists():
                ext = path.suffix.lstrip(".").lower()
                if ext in ("jpg", "jpeg"):
                    ext = "jpeg"
                elif ext == "png":
                    ext = "png"
                else:
                    ext = "png"  # Default
                return path.read_bytes(), ext

        # Fetch from URL
        req = urllib.request.Request(url, headers={"User-Agent": "TokenMoulds/1.0"})
        with urllib.request.urlopen(req, timeout=10) as response:
            data = response.read()
            content_type = response.headers.get("Content-Type", "")

            if "png" in content_type:
                ext = "png"
            elif "jpeg" in content_type or "jpg" in content_type:
                ext = "jpeg"
            elif "gif" in content_type:
                ext = "gif"
            else:
                # Guess from URL
                if ".png" in url.lower():
                    ext = "png"
                elif ".gif" in url.lower():
                    ext = "gif"
                else:
                    ext = "jpeg"

            return data, ext

    except Exception:
        return None


def _render_inline_image_xml(rid: str, alt: str, cx: int, cy: int) -> str:
    """Render an inline image as OOXML drawing element."""
    W_NS = WORD_NSMAP["w"]
    R_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    WP_NS = "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"
    A_NS = "http://schemas.openxmlformats.org/drawingml/2006/main"
    PIC_NS = "http://schemas.openxmlformats.org/drawingml/2006/picture"

    # Generate unique IDs
    import random

    doc_id = random.randint(1, 999999)

    return f"""<w:r xmlns:w="{W_NS}">
        <w:drawing>
            <wp:inline xmlns:wp="{WP_NS}" distT="0" distB="0" distL="0" distR="0">
                <wp:extent cx="{cx}" cy="{cy}"/>
                <wp:docPr id="{doc_id}" name="{alt}"/>
                <a:graphic xmlns:a="{A_NS}">
                    <a:graphicData uri="{PIC_NS}">
                        <pic:pic xmlns:pic="{PIC_NS}">
                            <pic:nvPicPr>
                                <pic:cNvPr id="{doc_id}" name="{alt}"/>
                                <pic:cNvPicPr/>
                            </pic:nvPicPr>
                            <pic:blipFill>
                                <a:blip xmlns:r="{R_NS}" r:embed="{rid}"/>
                                <a:stretch><a:fillRect/></a:stretch>
                            </pic:blipFill>
                            <pic:spPr>
                                <a:xfrm>
                                    <a:off x="0" y="0"/>
                                    <a:ext cx="{cx}" cy="{cy}"/>
                                </a:xfrm>
                                <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
                            </pic:spPr>
                        </pic:pic>
                    </a:graphicData>
                </a:graphic>
            </wp:inline>
        </w:drawing>
    </w:r>"""


def _render_runs_xml(runs: List[Dict[str, Any]]) -> str:
    """Render a list of text runs with formatting to OOXML.

    Each run can have: text, bold, italic, strikethrough, code, link
    """
    global _hyperlink_tracker
    W_NS = WORD_NSMAP["w"]
    R_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    parts = []

    for run in runs:
        text = _escape_xml(run.get("text", ""))
        if not text:
            continue

        # Build run properties
        rpr_parts = []
        if run.get("bold"):
            rpr_parts.append(f'<w:b xmlns:w="{W_NS}"/>')
        if run.get("italic"):
            rpr_parts.append(f'<w:i xmlns:w="{W_NS}"/>')
        if run.get("strikethrough"):
            rpr_parts.append(f'<w:strike xmlns:w="{W_NS}"/>')
        if run.get("code"):
            rpr_parts.append(
                f'<w:rFonts xmlns:w="{W_NS}" w:ascii="Consolas" w:hAnsi="Consolas"/>'
            )
            rpr_parts.append(f'<w:shd xmlns:w="{W_NS}" w:val="clear" w:fill="E8E8E8"/>')

        # Links get blue underline style
        if run.get("link"):
            rpr_parts.append(f'<w:color xmlns:w="{W_NS}" w:val="0563C1"/>')
            rpr_parts.append(f'<w:u xmlns:w="{W_NS}" w:val="single"/>')

        rpr_xml = ""
        if rpr_parts:
            rpr_xml = f'<w:rPr xmlns:w="{W_NS}">' + "".join(rpr_parts) + "</w:rPr>"

        # Handle line breaks
        if run.get("linebreak"):
            parts.append(f'<w:r xmlns:w="{W_NS}">{rpr_xml}<w:br/></w:r>')
        elif run.get("image") and _hyperlink_tracker:
            # Render as inline image
            img_url = run.get("url", "")
            alt = _escape_xml(run.get("alt", "Image"))
            img_result = _fetch_image(img_url) if img_url else None

            if img_result:
                img_data, img_ext = img_result
                rid = _hyperlink_tracker.add_image(img_url, img_data, img_ext)
                # Default size: 4 inches wide, 4:3 aspect
                from tokenmoulds.design.layout_defaults import inline_image_emu

                cx, cy = inline_image_emu()
                parts.append(_render_inline_image_xml(rid, alt, cx, cy))
            else:
                # Fallback to placeholder text
                text_xml = f'<w:t xmlns:w="{W_NS}" xml:space="preserve">{text}</w:t>'
                parts.append(f'<w:r xmlns:w="{W_NS}">{rpr_xml}{text_xml}</w:r>')
        elif run.get("link") and _hyperlink_tracker:
            # Render as hyperlink
            url = run["link"]
            rid = _hyperlink_tracker.add_link(url)
            text_xml = f'<w:t xmlns:w="{W_NS}" xml:space="preserve">{text}</w:t>'
            run_xml = f'<w:r xmlns:w="{W_NS}">{rpr_xml}{text_xml}</w:r>'
            parts.append(
                f'<w:hyperlink xmlns:w="{W_NS}" xmlns:r="{R_NS}" r:id="{rid}">{run_xml}</w:hyperlink>'
            )
        else:
            text_xml = f'<w:t xmlns:w="{W_NS}" xml:space="preserve">{text}</w:t>'
            parts.append(f'<w:r xmlns:w="{W_NS}">{rpr_xml}{text_xml}</w:r>')

    return "".join(parts)


def _get_text_from_block(block: Dict[str, Any]) -> str:
    """Get plain text from block, handling both 'text' and 'runs' formats."""
    if "text" in block:
        return _escape_xml(block["text"])
    if "runs" in block:
        return "".join(_escape_xml(r.get("text", "")) for r in block["runs"])
    return ""


def _get_runs_from_block(block: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Get runs from block, converting 'text' to runs if needed."""
    if "runs" in block:
        return block["runs"]
    if "text" in block:
        return [{"text": block["text"]}]
    return []


def _render_word_paragraph(templates: TemplateResolver, text: str) -> etree._Element:
    """Render a body paragraph using template."""
    xml = templates.read_text("paragraph_body.xml")
    xml = xml.replace("${TEXT}", text)
    return etree.fromstring(xml.encode("utf-8"))


def _render_word_paragraph_with_runs(
    templates: TemplateResolver, runs: List[Dict[str, Any]], style: str = "BodyText"
) -> etree._Element:
    """Render a paragraph with formatted runs."""
    W_NS = WORD_NSMAP["w"]
    runs_xml = _render_runs_xml(runs)

    xml = f"""<w:p xmlns:w="{W_NS}">
        <w:pPr><w:pStyle w:val="{style}"/></w:pPr>
        {runs_xml}
    </w:p>"""
    return etree.fromstring(xml.encode("utf-8"))


def _render_word_list(
    templates: TemplateResolver,
    items: List[str],
    numbered: bool = False,
    level: int = 0,
) -> List[etree._Element]:
    """Render list items using template."""
    elements = []
    num_id = "2" if numbered else "1"

    for item in items:
        xml = templates.read_text("paragraph_list_item.xml")
        xml = xml.replace("${LEVEL}", str(level))
        xml = xml.replace("${NUM_ID}", num_id)
        xml = xml.replace("${TEXT}", _escape_xml(item))
        elements.append(etree.fromstring(xml.encode("utf-8")))

    return elements


def _render_word_list_item_with_runs(
    templates: TemplateResolver,
    runs: List[Dict[str, Any]],
    numbered: bool = False,
    level: int = 0,
) -> etree._Element:
    """Render a single list item with formatted runs."""
    W_NS = WORD_NSMAP["w"]
    num_id = "2" if numbered else "1"
    runs_xml = _render_runs_xml(runs)

    xml = f"""<w:p xmlns:w="{W_NS}">
        <w:pPr>
            <w:pStyle w:val="ListParagraph"/>
            <w:numPr>
                <w:ilvl w:val="{level}"/>
                <w:numId w:val="{num_id}"/>
            </w:numPr>
        </w:pPr>
        {runs_xml}
    </w:p>"""
    return etree.fromstring(xml.encode("utf-8"))


def _render_word_horizontal_rule() -> etree._Element:
    """Render a horizontal rule as a paragraph with bottom border."""
    W_NS = WORD_NSMAP["w"]
    xml = f"""<w:p xmlns:w="{W_NS}">
        <w:pPr>
            <w:pBdr>
                <w:bottom w:val="single" w:sz="6" w:space="1" w:color="auto"/>
            </w:pBdr>
        </w:pPr>
    </w:p>"""
    return etree.fromstring(xml.encode("utf-8"))


def _render_word_table_with_runs(
    templates: TemplateResolver,
    rows: List[List[Dict[str, Any]]],
    table_style: str,
) -> etree._Element:
    """Render a table with formatted cell content.

    Each cell is a dict with 'runs' and optional 'header' flag.
    """
    W_NS = WORD_NSMAP["w"]

    if not rows:
        return _render_word_paragraph(templates, "")

    # Calculate column count
    col_count = max(len(row) for row in rows) if rows else 1

    # Build table grid
    grid_cols = "".join('<w:gridCol w:w="2500"/>' for _ in range(col_count))

    # Build rows
    rows_xml = []
    for row in rows:
        cells_xml = []
        for cell in row:
            cell_runs = cell.get("runs", [])
            is_header = cell.get("header", False)

            # Add bold to header cells
            if is_header:
                cell_runs = [{"bold": True, **r} for r in cell_runs]

            runs_xml = _render_runs_xml(cell_runs)

            cell_xml = f"""<w:tc>
                <w:tcPr><w:tcW w:w="2500" w:type="dxa"/></w:tcPr>
                <w:p>
                    <w:pPr><w:pStyle w:val="TableText"/></w:pPr>
                    {runs_xml}
                </w:p>
            </w:tc>"""
            cells_xml.append(cell_xml)

        row_xml = f"<w:tr>{''.join(cells_xml)}</w:tr>"
        rows_xml.append(row_xml)

    table_xml = f"""<w:tbl xmlns:w="{W_NS}">
        <w:tblPr>
            <w:tblStyle w:val="{table_style}"/>
            <w:tblW w:w="5000" w:type="pct"/>
            <w:tblLook w:val="04A0" w:firstRow="1" w:lastRow="0" w:firstColumn="1" w:lastColumn="0" w:noHBand="0" w:noVBand="1"/>
        </w:tblPr>
        <w:tblGrid>{grid_cols}</w:tblGrid>
        {"".join(rows_xml)}
    </w:tbl>"""

    return etree.fromstring(table_xml.encode("utf-8"))


def _render_word_page_break() -> etree._Element:
    """Render a page break element."""
    xml = f"""<w:p xmlns:w="{WORD_NSMAP["w"]}">
        <w:r><w:br w:type="page"/></w:r>
    </w:p>"""
    return etree.fromstring(xml.encode("utf-8"))
