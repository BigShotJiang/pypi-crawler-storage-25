"""Word content injection for MCP document tools."""

from __future__ import annotations

import zipfile
from io import BytesIO
from typing import Any, Dict, List, Optional

from lxml import etree

from tokenmoulds.emitters import TemplateResolver
from tokenmoulds.mcp.tools.document_pipeline import content_word_blocks as word_blocks

WORD_NSMAP = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}

def _inject_word_content(
    template_bytes: bytes,
    content_blocks: List[Dict[str, Any]],
    style_context: Dict[str, Any],
    title: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> bytes:
    """Inject content blocks into a Word template.

    Follows the same pattern as the existing injector module.
    """
    if not content_blocks:
        return _convert_word_template_to_document(template_bytes)

    # Initialize hyperlink tracker for this document
    tracker = word_blocks.start_hyperlink_tracking()

    templates = TemplateResolver("word")

    input_zip = BytesIO(template_bytes)
    output_zip = BytesIO()

    with zipfile.ZipFile(input_zip, "r") as zin:
        with zipfile.ZipFile(
            output_zip, "w", zipfile.ZIP_DEFLATED, compresslevel=9
        ) as zout:
            for item in zin.namelist():
                data = zin.read(item)

                if item == "word/document.xml":
                    data = _inject_into_word_document(
                        data, content_blocks, templates, style_context
                    )
                elif item == "word/_rels/document.xml.rels":
                    # Add hyperlink and image relationships
                    data = _inject_relationships(
                        data, tracker.links, tracker.images
                    )
                elif item == "[Content_Types].xml":
                    data = _update_content_types(data, tracker.images)
                elif item == "docProps/core.xml" and metadata:
                    data = _inject_word_metadata(data, title, metadata)

                zout.writestr(item, data)

            # Write images to word/media/
            for img in tracker.images:
                img_path = f"word/media/{img['filename']}"
                zout.writestr(img_path, img["data"])

    # Reset tracker
    word_blocks.clear_hyperlink_tracking()

    return output_zip.getvalue()


def _convert_word_template_to_document(template_bytes: bytes) -> bytes:
    """Convert Word template to document format without content changes."""
    input_zip = BytesIO(template_bytes)
    output_zip = BytesIO()

    with zipfile.ZipFile(input_zip, "r") as zin:
        with zipfile.ZipFile(
            output_zip, "w", zipfile.ZIP_DEFLATED, compresslevel=9
        ) as zout:
            for item in zin.namelist():
                data = zin.read(item)
                if item == "[Content_Types].xml":
                    data = _update_content_types(data, [])  # No images
                zout.writestr(item, data)

    return output_zip.getvalue()


def _inject_relationships(
    rels_xml: bytes,
    links: List[Dict[str, str]],
    images: List[Dict[str, Any]],
) -> bytes:
    """Add hyperlink and image relationships to document.xml.rels."""
    if not links and not images:
        return rels_xml

    RELS_NS = "http://schemas.openxmlformats.org/package/2006/relationships"
    root = etree.fromstring(rels_xml)

    # Add hyperlink relationships
    for link in links:
        rel = etree.SubElement(root, f"{{{RELS_NS}}}Relationship")
        rel.set("Id", link["id"])
        rel.set(
            "Type",
            "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink",
        )
        rel.set("Target", link["url"])
        rel.set("TargetMode", "External")

    # Add image relationships
    for img in images:
        rel = etree.SubElement(root, f"{{{RELS_NS}}}Relationship")
        rel.set("Id", img["id"])
        rel.set(
            "Type",
            "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image",
        )
        rel.set("Target", f"media/{img['filename']}")

    return etree.tostring(root, xml_declaration=True, encoding="UTF-8")


def _update_content_types(
    content_types_xml: bytes, images: List[Dict[str, Any]]
) -> bytes:
    """Update Content_Types.xml for template->document conversion and image types."""
    xml_str = content_types_xml.decode("utf-8")

    # Convert template to document
    xml_str = xml_str.replace(
        "wordprocessingml.template.main+xml", "wordprocessingml.document.main+xml"
    )

    # Add image content type extensions if we have images
    if images:
        CT_NS = "http://schemas.openxmlformats.org/package/2006/content-types"
        root = etree.fromstring(xml_str.encode("utf-8"))

        # Collect unique extensions
        extensions_needed = set()
        for img in images:
            ext = img["filename"].rsplit(".", 1)[-1].lower()
            extensions_needed.add(ext)

        # Check which extensions already exist
        existing_extensions = set()
        for default in root.findall(f"{{{CT_NS}}}Default"):
            ext = default.get("Extension", "").lower()
            existing_extensions.add(ext)

        # Add missing extension types
        mime_types = {
            "png": "image/png",
            "jpeg": "image/jpeg",
            "jpg": "image/jpeg",
            "gif": "image/gif",
            "bmp": "image/bmp",
            "tiff": "image/tiff",
        }

        for ext in extensions_needed:
            if ext not in existing_extensions:
                mime = mime_types.get(ext, "application/octet-stream")
                default = etree.SubElement(root, f"{{{CT_NS}}}Default")
                default.set("Extension", ext)
                default.set("ContentType", mime)

        return etree.tostring(root, xml_declaration=True, encoding="UTF-8")

    return xml_str.encode("utf-8")


def _inject_into_word_document(
    doc_xml: bytes,
    content_blocks: List[Dict[str, Any]],
    templates: TemplateResolver,
    style_context: Dict[str, Any],
) -> bytes:
    """Inject content blocks into document.xml."""
    root = etree.fromstring(doc_xml)
    body = root.find(".//w:body", WORD_NSMAP)

    if body is None:
        return doc_xml

    # Preserve sectPr
    sect_pr = body.find("w:sectPr", WORD_NSMAP)

    # Remove existing paragraphs
    for p in body.findall("w:p", WORD_NSMAP):
        body.remove(p)

    # Add content blocks
    for block in content_blocks:
        elements = word_blocks._render_word_content_block(block, templates, style_context)
        for el in elements:
            body.append(el)

    # Ensure sectPr is at the end
    if sect_pr is not None:
        body.remove(sect_pr)
        body.append(sect_pr)

    return etree.tostring(root, xml_declaration=True, encoding="UTF-8")

def _inject_word_metadata(
    core_xml: bytes,
    title: Optional[str],
    metadata: Dict[str, Any],
) -> bytes:
    """Inject metadata into docProps/core.xml."""
    # Parse and modify core properties
    root = etree.fromstring(core_xml)

    # Namespace for Dublin Core elements
    DC_NS = "http://purl.org/dc/elements/1.1/"

    dc = f"{{{DC_NS}}}"

    # Update or add elements
    if title:
        title_el = root.find(f".//{dc}title")
        if title_el is not None:
            title_el.text = title

    if "author" in metadata:
        creator_el = root.find(f".//{dc}creator")
        if creator_el is not None:
            creator_el.text = metadata["author"]

    if "subject" in metadata:
        subject_el = root.find(f".//{dc}subject")
        if subject_el is not None:
            subject_el.text = metadata["subject"]

    return etree.tostring(root, xml_declaration=True, encoding="UTF-8")
