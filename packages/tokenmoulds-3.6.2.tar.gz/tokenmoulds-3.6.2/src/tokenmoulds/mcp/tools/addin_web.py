"""Office web add-in generation tools."""

from __future__ import annotations

import json
from typing import Any, Dict, List, TYPE_CHECKING

from tokenmoulds.mcp.tools.addin_common import _sanitize_filename
from tokenmoulds.mcp.tools.token_utils import escape_xml as _escape_xml

if TYPE_CHECKING:
    from tokenmoulds.mcp.server import TokenMouldsServer

CREATE_WEB_ADDIN_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "name": {
            "type": "string",
            "description": "Add-in display name",
        },
        "id": {
            "type": "string",
            "description": "Add-in GUID (auto-generated if not provided)",
        },
        "description": {
            "type": "string",
            "description": "Add-in description",
        },
        "target": {
            "type": "string",
            "enum": ["word", "excel", "powerpoint", "outlook"],
            "description": "Target Office application",
        },
        "source_url": {
            "type": "string",
            "description": "URL where add-in web app is hosted",
        },
        "permissions": {
            "type": "array",
            "items": {
                "type": "string",
                "enum": [
                    "ReadDocument",
                    "WriteDocument",
                    "ReadAllDocument",
                    "ReadWriteDocument",
                ],
            },
            "description": "Required permissions",
        },
        "commands": {
            "type": "array",
            "description": "Ribbon commands",
            "items": {
                "type": "object",
                "properties": {
                    "id": {"type": "string"},
                    "label": {"type": "string"},
                    "icon": {"type": "string"},
                    "action": {"type": "string"},
                },
                "required": ["id", "label", "action"],
            },
        },
        "brand_name": {
            "type": "string",
            "description": "Brand for styling",
        },
    },
    "required": ["name", "target", "source_url"],
}

async def create_web_addin(
    arguments: Dict[str, Any],
    server: "TokenMouldsServer",
) -> Dict[str, Any]:
    """Create an Office Web Add-in manifest.

    Generates a manifest.xml file for Office Web Add-ins that can be
    sideloaded or published to AppSource.

    Args:
        arguments: Tool arguments
        server: TokenMouldsServer instance

    Returns:
        Result with manifest path and project structure
    """
    name = arguments.get("name")
    if not name:
        return {"error": "Missing required 'name' parameter"}

    target = arguments.get("target")
    if not target:
        return {"error": "Missing required 'target' parameter"}

    source_url = arguments.get("source_url")
    if not source_url:
        return {"error": "Missing required 'source_url' parameter"}

    description = arguments.get("description", f"{name} Add-in")
    addin_id = arguments.get("id") or _generate_guid()
    permissions = arguments.get("permissions", ["ReadWriteDocument"])
    commands = arguments.get("commands", [])
    # Create output directory
    safe_name = _sanitize_filename(name)
    output_dir = server.output_path / f"{safe_name}-webaddin"
    output_dir.mkdir(parents=True, exist_ok=True)

    try:
        # Generate manifest
        manifest_xml = _generate_web_addin_manifest(
            name=name,
            addin_id=addin_id,
            description=description,
            target=target,
            source_url=source_url,
            permissions=permissions,
            commands=commands,
        )

        # Write manifest
        manifest_path = output_dir / "manifest.xml"
        manifest_path.write_text(manifest_xml, encoding="utf-8")

        # Generate package.json for npm-based development
        package_json = _generate_package_json(name, description)
        (output_dir / "package.json").write_text(
            json.dumps(package_json, indent=2),
            encoding="utf-8",
        )

        # Generate README
        readme = _generate_webaddin_readme(name, target, source_url)
        (output_dir / "README.md").write_text(readme, encoding="utf-8")

        return {
            "success": True,
            "action": "create_web_addin",
            "output_dir": str(output_dir.absolute()),
            "manifest_path": str(manifest_path.absolute()),
            "addin_id": addin_id,
            "name": name,
            "description": description,
            "target": target,
            "source_url": source_url,
            "permissions": permissions,
            "commands_count": len(commands),
            "files_created": ["manifest.xml", "package.json", "README.md"],
            "message": f"Created Office Web Add-in project for {target.title()}.",
            "next_steps": [
                "Review and customize manifest.xml",
                "Deploy your web app to the source_url",
                "Sideload the add-in for testing",
            ],
        }

    except Exception as e:
        return {
            "error": f"Failed to create web add-in: {str(e)}",
            "name": name,
        }


def _generate_guid() -> str:
    """Generate a random GUID for add-in ID."""
    import uuid

    return str(uuid.uuid4())


def _generate_web_addin_manifest(
    name: str,
    addin_id: str,
    description: str,
    target: str,
    source_url: str,
    permissions: List[str],
    commands: List[Dict[str, Any]],
) -> str:
    """Generate Office Web Add-in manifest XML."""
    # Host mapping — includes outlook which isn't in _ADDIN_FORMATS
    _HOSTS = {
        "word": "Document",
        "excel": "Workbook",
        "powerpoint": "Presentation",
        "outlook": "Mailbox",
    }
    host = _HOSTS.get(target, "Document")

    # Permission set
    permission_set = permissions[0] if permissions else "ReadWriteDocument"

    manifest = f'''<?xml version="1.0" encoding="UTF-8"?>
<OfficeApp
    xmlns="http://schemas.microsoft.com/office/appforoffice/1.1"
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xmlns:bt="http://schemas.microsoft.com/office/officeappbasictypes/1.0"
    xmlns:ov="http://schemas.microsoft.com/office/taskpaneappversionoverrides"
    xsi:type="TaskPaneApp">

    <Id>{addin_id}</Id>
    <Version>1.0.0.0</Version>
    <ProviderName>TokenMoulds</ProviderName>
    <DefaultLocale>en-US</DefaultLocale>
    <DisplayName DefaultValue="{_escape_xml(name)}"/>
    <Description DefaultValue="{_escape_xml(description)}"/>

    <IconUrl DefaultValue="{source_url}/assets/icon-32.png"/>
    <HighResolutionIconUrl DefaultValue="{source_url}/assets/icon-64.png"/>
    <SupportUrl DefaultValue="{source_url}/support"/>

    <Hosts>
        <Host Name="{host}"/>
    </Hosts>

    <DefaultSettings>
        <SourceLocation DefaultValue="{source_url}/taskpane.html"/>
    </DefaultSettings>

    <Permissions>{permission_set}</Permissions>

</OfficeApp>
'''
    return manifest


def _generate_package_json(name: str, description: str) -> Dict[str, Any]:
    """Generate package.json for web add-in project."""
    safe_name = name.lower().replace(" ", "-")
    return {
        "name": safe_name,
        "version": "1.0.0",
        "description": description,
        "main": "index.js",
        "scripts": {
            "start": "office-addin-debugging start manifest.xml",
            "stop": "office-addin-debugging stop manifest.xml",
            "validate": "office-addin-manifest validate manifest.xml",
            "build": "webpack --mode production",
            "dev": "webpack serve --mode development",
        },
        "dependencies": {
            "@microsoft/office-js": "^1.1.0",
        },
        "devDependencies": {
            "office-addin-debugging": "^4.0.0",
            "office-addin-manifest": "^1.0.0",
            "webpack": "^5.0.0",
            "webpack-cli": "^5.0.0",
            "webpack-dev-server": "^4.0.0",
        },
        "author": "TokenMoulds",
        "license": "MIT",
    }


def _generate_webaddin_readme(name: str, target: str, source_url: str) -> str:
    """Generate README for web add-in project."""
    return f"""# {name}

Office Web Add-in for {target.title()}, generated by TokenMoulds.

## Setup

1. Install dependencies:
   ```bash
   npm install
   ```

2. Deploy your web app to: `{source_url}`

3. Validate the manifest:
   ```bash
   npm run validate
   ```

4. Sideload for testing:
   ```bash
   npm run start
   ```

## Project Structure

- `manifest.xml` - Office Add-in manifest
- `package.json` - Node.js dependencies
- `src/` - Add your web app source here

## Resources

- [Office Add-ins documentation](https://docs.microsoft.com/office/dev/add-ins/)
- [Script Lab](https://aka.ms/getscriptlab) - Prototype add-in ideas

Generated by TokenMoulds MCP Server.
"""
