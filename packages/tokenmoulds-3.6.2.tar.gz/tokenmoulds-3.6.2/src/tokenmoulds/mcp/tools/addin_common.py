"""Shared helpers for add-in signing tools."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from tokenmoulds.mcp.server import TokenMouldsServer

def _get_certificates_dir(server: "TokenMouldsServer") -> Path:
    """Get the certificates directory."""
    certs_dir = server.cache_manager.cache_root / "certificates"
    certs_dir.mkdir(parents=True, exist_ok=True)
    return certs_dir

def _sanitize_filename(name: str) -> str:
    """Replace non-alphanumeric characters (except ``-`` and ``_``) with ``_``."""
    return "".join(c if c.isalnum() or c in "-_" else "_" for c in name)


def _escape_openssl_subject_value(value: str) -> str:
    """Escape a value for use in OpenSSL's slash-delimited subject string.

    In the ``/CN=.../O=...`` format, ``\\`` and ``/`` inside field values
    must be escaped so OpenSSL doesn't misparse them as field separators
    or escape characters.
    """
    return value.replace("\\", "\\\\").replace("/", "\\/")
