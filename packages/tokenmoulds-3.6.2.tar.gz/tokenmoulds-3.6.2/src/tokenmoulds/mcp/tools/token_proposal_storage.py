"""Persistence and mutation helpers for token proposal tools."""

from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timezone
import json
from pathlib import Path
import re
from typing import Any

from tokenmoulds.dtcg.generator import TokenGenerator
from tokenmoulds.mcp.tools.brand_modifier import _extract_current_inputs
from tokenmoulds.mcp.tools.design_modifier import (
    FIGURE_STYLES,
    HEADING_SPACING,
    SCALE_RATIOS,
    TRACKING_CURVES,
    _apply_design_overlay,
)
from tokenmoulds.semantic.content import parse_authored_semantic_content
_LONG_FORM_GROUP_KEYS = (
    "page_geometry",
    "margin_presets",
    "headers",
    "footers",
    "sections",
)
_SEMANTIC_PATH = re.compile(
    r"^(headers|footers)\.([^.]+)\.content\.(left|center|right|outer|inner)$"
)
_BRAND_INPUT_PATHS = {
    "brand_tone",
    "content_density",
    "locale",
    "base_grid_pt",
    "base_colors.primary",
    "base_colors.secondary",
    "font_pair.sans",
    "font_pair.serif",
}
_PARAMETRIC_VALIDATORS: dict[str, set[Any] | type] = {
    "scale_ratio": set(SCALE_RATIOS),
    "tracking_curve": set(TRACKING_CURVES),
    "heading_spacing": set(HEADING_SPACING),
    "figure_style": set(FIGURE_STYLES),
    "optical_margin": bool,
    "small_caps": {"opentype", "synthesized", "none"},
}
_SAFE_IDENTIFIER = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]*$")


def _slug(value: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
    return slug or "proposal"


def _make_proposal_id(brand_name: str) -> str:
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    return f"tokprop-{_slug(brand_name)}-{timestamp}"


def _require_safe_identifier(value: str, *, field_name: str) -> str:
    if (
        not value
        or value in {".", ".."}
        or Path(value).is_absolute()
        or "/" in value
        or "\\" in value
        or _SAFE_IDENTIFIER.fullmatch(value) is None
    ):
        raise ValueError(f"invalid_{field_name}:{value}")
    return value


def _get_nested(mapping: dict[str, Any], path: str) -> Any:
    current: Any = mapping
    for part in path.split("."):
        if not isinstance(current, dict) or part not in current:
            return None
        current = current[part]
    return current


def _set_nested(mapping: dict[str, Any], path: str, value: Any) -> None:
    parts = path.split(".")
    current = mapping
    for part in parts[:-1]:
        nested = current.get(part)
        if not isinstance(nested, dict):
            nested = {}
            current[part] = nested
        current = nested
    current[parts[-1]] = value


def _unwrap(value: Any) -> Any:
    if isinstance(value, dict) and "$value" in value:
        return value["$value"]
    return value


def _preserve_manual_groups(
    source_tokens: dict[str, Any],
    generated_tokens: dict[str, Any],
) -> dict[str, Any]:
    for key in _LONG_FORM_GROUP_KEYS:
        if key in source_tokens:
            generated_tokens[key] = deepcopy(source_tokens[key])
    return generated_tokens


def _apply_semantic_change(
    tokens: dict[str, Any],
    *,
    path: str,
    value: Any,
) -> tuple[Any, Any]:
    match = _SEMANTIC_PATH.match(path)
    if match is None:
        raise ValueError(f"invalid_path:{path}")

    group_name, entry_name, slot = match.groups()
    group = tokens.get(group_name)
    if not isinstance(group, dict) or entry_name not in group:
        raise ValueError(f"invalid_path:{path}")

    if isinstance(value, str) and "&" in value:
        raise ValueError(f"unsafe_renderer_syntax:{path}")
    normalized = parse_authored_semantic_content(value)
    if not normalized.items:
        raise ValueError(f"invalid_value:{path}")

    entry = group[entry_name]
    before = None
    legacy_key = f"content_{slot}"
    if legacy_key in entry:
        before = _unwrap(entry.get(legacy_key))
        entry.pop(legacy_key, None)
    content = entry.get("content")
    if isinstance(content, dict) and "$value" in content:
        content = _unwrap(content)
    if not isinstance(content, dict):
        content = {}
    if slot in content:
        before = _unwrap(content.get(slot))
    content[slot] = {"$value": value}
    entry["content"] = content
    return before, value


def _validate_parametric_value(path: str, value: Any) -> None:
    validator = _PARAMETRIC_VALIDATORS.get(path)
    if validator is None:
        raise ValueError(f"invalid_path:{path}")
    if validator is bool:
        if not isinstance(value, bool):
            raise ValueError(f"invalid_value:{path}")
        return
    if value not in validator:
        raise ValueError(f"invalid_value:{path}")


def _proposal_dir(output_root: Path, proposal_id: str) -> Path:
    return output_root / "review" / proposal_id


def _proposal_file(output_root: Path, proposal_id: str, filename: str) -> Path:
    return _proposal_dir(output_root, proposal_id) / filename


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def _load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _persist_json_artifact(
    payload: dict[str, Any],
    *,
    output_root: Path,
    proposal_id: str,
    filename: str,
) -> Path:
    artifact_path = _proposal_file(output_root, proposal_id, filename)
    _write_json(artifact_path, payload)
    return artifact_path


def _persist_proposal(
    proposal: dict[str, Any],
    *,
    output_root: Path,
) -> Path:
    return _persist_json_artifact(
        proposal,
        output_root=output_root,
        proposal_id=proposal["proposal_id"],
        filename="proposal.json",
    )


def _persist_resolved_tokens(
    proposal_id: str,
    *,
    output_root: Path,
    resolved_tokens: dict[str, Any],
) -> Path:
    return _persist_json_artifact(
        resolved_tokens,
        output_root=output_root,
        proposal_id=proposal_id,
        filename="resolved-tokens.json",
    )


def _build_proposal_candidate(
    arguments: dict[str, Any],
    server: Any,
    *,
    brand_name: str,
    current_tokens: dict[str, Any],
) -> dict[str, Any]:
    current_inputs = _extract_current_inputs(current_tokens)
    proposed_inputs = deepcopy(current_inputs)
    existing_overlay = deepcopy(
        getattr(server, "design_overlays", {}).get(brand_name, {})
    )
    proposed_overlay = deepcopy(existing_overlay)
    proposed_metadata: dict[str, Any] = {}
    proposed_tokens = deepcopy(current_tokens)
    token_diff: list[dict[str, Any]] = []
    extra_warnings: list[str] = []

    for change in arguments["changes"]:
        kind = change.get("kind")
        path = change.get("path")
        value = change.get("value")
        if not isinstance(kind, str) or not isinstance(path, str):
            raise ValueError("invalid_change")

        if kind == "brand_input_update":
            if path not in _BRAND_INPUT_PATHS:
                raise ValueError(f"invalid_path:{path}")
            before = _get_nested(proposed_inputs, path)
            _set_nested(proposed_inputs, path, value)
            token_diff.append({"path": path, "before": before, "after": value})
        elif kind == "parametric_update":
            _validate_parametric_value(path, value)
            before = proposed_overlay.get(path)
            proposed_overlay[path] = value
            token_diff.append({"path": path, "before": before, "after": value})
        elif kind == "semantic_update":
            before, after = _apply_semantic_change(
                proposed_tokens,
                path=path,
                value=value,
            )
            token_diff.append({"path": path, "before": before, "after": after})
        elif kind == "metadata_update":
            before = proposed_metadata.get(path)
            proposed_metadata[path] = value
            token_diff.append(
                {"path": f"metadata.{path}", "before": before, "after": value}
            )
            extra_warnings.append(
                f"metadata.{path}: metadata updates are stored in the proposal artifact only"
            )
        elif kind == "comment":
            extra_warnings.append(f"comment:{path}")
        else:
            raise ValueError(f"invalid_kind:{kind}")

    try:
        generated_tokens = TokenGenerator().generate(proposed_inputs)
    except Exception as exc:  # pragma: no cover - generator owns specifics
        raise RuntimeError(str(exc)) from exc

    proposed_tokens = _preserve_manual_groups(proposed_tokens, generated_tokens)
    if proposed_overlay:
        _apply_design_overlay(proposed_tokens, proposed_overlay)

    return {
        "current_inputs": current_inputs,
        "proposed_inputs": proposed_inputs,
        "proposed_overlay": proposed_overlay,
        "proposed_metadata": proposed_metadata,
        "proposed_tokens": proposed_tokens,
        "token_diff": token_diff,
        "extra_warnings": extra_warnings,
    }


def _resolve_artifact_paths(
    arguments: dict[str, Any], server: Any
) -> tuple[Path, Path, Path]:
    proposal_id = arguments.get("proposal_id")
    review_id = arguments.get("review_id")
    file_path = arguments.get("file_path")
    provided = sum(
        1 for value in (proposal_id, review_id, file_path) if value is not None
    )
    if provided != 1:
        raise ValueError(
            "Provide exactly one of 'proposal_id', 'review_id', or 'file_path'."
        )

    output_root = Path(getattr(server, "output_path", Path("./generated")))
    if proposal_id is not None:
        artifact_dir = _proposal_dir(
            output_root,
            _require_safe_identifier(str(proposal_id), field_name="proposal_id"),
        )
    elif review_id is not None:
        artifact_dir = _proposal_dir(
            output_root,
            _require_safe_identifier(str(review_id), field_name="review_id"),
        )
    else:
        candidate = Path(str(file_path))
        artifact_dir = candidate.parent if candidate.suffix == ".json" else candidate

    return (
        artifact_dir / "proposal.json",
        artifact_dir / "review-bundle.json",
        artifact_dir / "resolved-tokens.json",
    )


def _load_proposal_artifacts(
    arguments: dict[str, Any], server: Any
) -> tuple[dict[str, Any], dict[str, Any] | None, Path, Path, Path]:
    proposal_path, review_bundle_path, resolved_tokens_path = _resolve_artifact_paths(
        arguments, server
    )
    if not proposal_path.exists():
        raise FileNotFoundError(f"Proposal artifact not found: {proposal_path}")

    proposal = _load_json(proposal_path)
    review_bundle = (
        _load_json(review_bundle_path) if review_bundle_path.exists() else None
    )
    return (
        proposal,
        review_bundle,
        proposal_path,
        review_bundle_path,
        resolved_tokens_path,
    )


def _set_proposal_state(
    proposal: dict[str, Any],
    review_bundle: dict[str, Any] | None,
    *,
    state: str,
    reason: str | None = None,
) -> None:
    timestamp = datetime.now(timezone.utc).isoformat()
    proposal["state"] = state
    if state == "applied":
        proposal.setdefault("applied_at", timestamp)
        proposal.pop("rejected_at", None)
        proposal.pop("rejection_reason", None)
    elif state == "rejected":
        proposal.setdefault("rejected_at", timestamp)
        if reason:
            proposal["rejection_reason"] = reason

    if review_bundle is not None:
        review_bundle["proposal_state"] = state
        if state == "applied":
            review_bundle["applied_at"] = proposal["applied_at"]
            review_bundle.pop("rejected_at", None)
            review_bundle.pop("rejection_reason", None)
        elif state == "rejected":
            review_bundle["rejected_at"] = proposal["rejected_at"]
            if reason:
                review_bundle["rejection_reason"] = reason


def _persist_brand_tokens_to_source(
    server: Any,
    *,
    brand_name: str,
    tokens: dict[str, Any],
) -> Path:
    token_files = getattr(server, "brand_token_files", None)
    if not isinstance(token_files, dict):
        raise FileNotFoundError(
            f"No source token file is registered for '{brand_name}'."
        )

    token_path = token_files.get(brand_name)
    if token_path is None:
        raise FileNotFoundError(
            f"No source token file is registered for '{brand_name}'."
        )

    source_path = Path(token_path)
    source_path.parent.mkdir(parents=True, exist_ok=True)
    source_path.write_text(json.dumps(tokens, indent=2), encoding="utf-8")
    token_files[brand_name] = source_path
    return source_path


def _proposal_history_path(source_path: Path) -> Path:
    return source_path.with_name(f"{source_path.stem}.proposal-history.jsonl")


def _append_jsonl(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(payload, sort_keys=True))
        handle.write("\n")


def _append_persisted_apply_audit(
    *,
    proposal: dict[str, Any],
    review_bundle: dict[str, Any] | None,
    proposal_path: Path,
    review_bundle_path: Path,
    source_path: Path,
) -> Path:
    history_path = _proposal_history_path(source_path)
    payload = {
        "ts": datetime.now(timezone.utc).isoformat(),
        "event": "token_proposal.apply_persisted",
        "proposal_id": proposal.get("proposal_id"),
        "review_id": proposal.get("review_id"),
        "brand_name": (proposal.get("target") or {}).get("brand"),
        "intent_summary": proposal.get("intent_summary"),
        "confidence": proposal.get("confidence"),
        "impact_scope": proposal.get("impact_scope", []),
        "uncertainties": proposal.get("uncertainties", []),
        "source_token_path": str(source_path),
        "proposal_path": str(proposal_path),
        "review_bundle_path": str(review_bundle_path),
        "token_diff": (review_bundle or {}).get("token_diff", []),
    }
    _append_jsonl(history_path, payload)
    return history_path
