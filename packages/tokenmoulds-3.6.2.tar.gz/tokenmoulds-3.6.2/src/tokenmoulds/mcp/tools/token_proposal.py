"""Proposal tools for persisted token review artifacts."""

from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from tokenmoulds.mcp.tools.token_proposal_storage import (
    _append_persisted_apply_audit,
    _build_proposal_candidate,
    _load_json,
    _load_proposal_artifacts,
    _make_proposal_id,
    _persist_brand_tokens_to_source,
    _persist_proposal,
    _persist_resolved_tokens,
    _require_safe_identifier,
    _set_proposal_state,
    _write_json,
)
from tokenmoulds.mcp.tools.review_bundle import (
    build_proposal_review_bundle,
    persist_review_bundle,
)

PROPOSE_TOKEN_CHANGES_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "proposal_id": {
            "type": "string",
            "description": "Optional stable proposal identifier. Auto-generated when omitted.",
        },
        "target": {
            "type": "object",
            "properties": {
                "brand": {
                    "type": "string",
                    "description": "Target brand. Defaults to the active brand.",
                },
                "layer": {
                    "type": "string",
                    "description": "Target logical layer label. Stored for review only.",
                },
            },
        },
        "intent_summary": {
            "type": "string",
            "description": "Natural-language summary of the intended token change.",
        },
        "changes": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "kind": {
                        "type": "string",
                        "enum": [
                            "brand_input_update",
                            "semantic_update",
                            "parametric_update",
                            "metadata_update",
                            "comment",
                        ],
                    },
                    "path": {"type": "string"},
                    "value": {},
                },
                "required": ["kind", "path"],
            },
            "minItems": 1,
        },
        "rationale": {
            "type": "array",
            "items": {"type": "string"},
        },
        "confidence": {
            "type": "string",
            "enum": ["low", "medium", "high"],
        },
        "uncertainties": {
            "type": "array",
            "items": {"type": "string"},
        },
    },
    "required": ["intent_summary", "changes"],
}

APPLY_TOKEN_PROPOSAL_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "proposal_id": {
            "type": "string",
            "description": "Proposal identifier under generated/review/<proposal_id>/",
        },
        "review_id": {
            "type": "string",
            "description": "Alias for proposal_id when using review artifact identifiers.",
        },
        "file_path": {
            "type": "string",
            "description": "Path to proposal.json, review-bundle.json, or the proposal artifact directory.",
        },
        "persist_to_source": {
            "type": "boolean",
            "description": "When true, also write the applied tokens back to the known source token file for the brand.",
        },
    },
}

REJECT_TOKEN_PROPOSAL_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "proposal_id": {
            "type": "string",
            "description": "Proposal identifier under generated/review/<proposal_id>/",
        },
        "review_id": {
            "type": "string",
            "description": "Alias for proposal_id when using review artifact identifiers.",
        },
        "file_path": {
            "type": "string",
            "description": "Path to proposal.json, review-bundle.json, or the proposal artifact directory.",
        },
        "reason": {
            "type": "string",
            "description": "Optional rejection reason stored in the proposal artifact.",
        },
    },
}

async def propose_token_changes(
    arguments: dict[str, Any], server: Any
) -> dict[str, Any]:
    """Validate and persist a token proposal without mutating active tokens."""
    target = arguments.get("target") or {}
    brand_name = target.get("brand") or getattr(server, "active_brand", None)
    if not brand_name:
        return {"error": "No active brand. Load or set a brand first."}

    current_tokens = getattr(server, "loaded_tokens", {}).get(brand_name)
    if current_tokens is None:
        return {"error": f"Brand '{brand_name}' not loaded."}

    if not arguments.get("changes"):
        return {"error": "Proposal must include at least one change."}

    proposal_id = arguments.get("proposal_id") or _make_proposal_id(brand_name)
    try:
        proposal_id = _require_safe_identifier(
            str(proposal_id), field_name="proposal_id"
        )
    except ValueError as exc:
        error = str(exc)
        code, detail = error.split(":", 1)
        return {"error": code, "detail": detail}
    try:
        candidate = _build_proposal_candidate(
            arguments,
            server,
            brand_name=brand_name,
            current_tokens=current_tokens,
        )
    except ValueError as exc:
        error = str(exc)
        if ":" in error:
            code, detail = error.split(":", 1)
            return {"error": code, "detail": detail}
        return {"error": error}
    except RuntimeError as exc:
        return {"error": "invalid_value", "detail": str(exc)}

    review_bundle = build_proposal_review_bundle(
        proposal_id=proposal_id,
        brand_name=brand_name,
        summary=str(arguments.get("intent_summary") or "Token proposal"),
        token_diff=candidate["token_diff"],
        token_payload=candidate["proposed_tokens"],
        extra_warnings=candidate["extra_warnings"],
    )

    impact_scope = sorted(review_bundle["format_impact"].keys())
    created_at = datetime.now(timezone.utc).isoformat()
    proposal = {
        "proposal_id": proposal_id,
        "review_id": proposal_id,
        "created_at": created_at,
        "target": {
            "brand": brand_name,
            "layer": target.get("layer", "session"),
        },
        "intent_summary": arguments.get("intent_summary"),
        "changes": arguments["changes"],
        "rationale": arguments.get("rationale", []),
        "confidence": arguments.get("confidence", "medium"),
        "uncertainties": arguments.get("uncertainties", []),
        "impact_scope": impact_scope,
        "state": "validated",
        "metadata_updates": candidate["proposed_metadata"],
        "inputs_applied": candidate["proposed_inputs"],
        "design_overlay": candidate["proposed_overlay"],
    }

    output_root = Path(getattr(server, "output_path", Path("./generated")))
    resolved_tokens_path = _persist_resolved_tokens(
        proposal_id,
        output_root=output_root,
        resolved_tokens=candidate["proposed_tokens"],
    )
    proposal["resolved_tokens_path"] = str(resolved_tokens_path)
    proposal_path = _persist_proposal(proposal, output_root=output_root)
    review_bundle_path = persist_review_bundle(review_bundle, output_root=output_root)
    review_bundle["artifact_path"] = str(review_bundle_path)

    return {
        "success": True,
        "proposal_id": proposal_id,
        "proposal_path": str(proposal_path),
        "review_bundle_path": str(review_bundle_path),
        "proposal": proposal,
        "review_bundle": review_bundle,
        "confidence": proposal["confidence"],
        "uncertainties": proposal["uncertainties"],
        "impact_scope": impact_scope,
    }


async def apply_token_proposal(
    arguments: dict[str, Any], server: Any
) -> dict[str, Any]:
    """Apply a persisted token proposal to the in-memory brand state."""
    try:
        (
            proposal,
            review_bundle,
            proposal_path,
            review_bundle_path,
            resolved_tokens_path,
        ) = _load_proposal_artifacts(arguments, server)
    except (ValueError, FileNotFoundError) as exc:
        return {"error": str(exc)}

    proposal_id = str(proposal.get("proposal_id") or proposal.get("review_id") or "")
    brand_name = str((proposal.get("target") or {}).get("brand") or "")
    if not brand_name:
        return {"error": "Proposal artifact missing target brand."}
    if proposal.get("state") == "rejected":
        return {"error": "proposal_rejected", "detail": proposal_id}

    if resolved_tokens_path.exists():
        resolved_tokens = _load_json(resolved_tokens_path)
    else:
        current_tokens = getattr(server, "loaded_tokens", {}).get(brand_name)
        if current_tokens is None:
            return {
                "error": f"Brand '{brand_name}' not loaded and resolved tokens are missing."
            }
        try:
            candidate = _build_proposal_candidate(
                {"changes": proposal.get("changes", [])},
                server,
                brand_name=brand_name,
                current_tokens=current_tokens,
            )
        except ValueError as exc:
            return {"error": str(exc)}
        except RuntimeError as exc:
            return {"error": "invalid_value", "detail": str(exc)}
        resolved_tokens = candidate["proposed_tokens"]
        output_root = Path(getattr(server, "output_path", Path("./generated")))
        resolved_tokens_path = _persist_resolved_tokens(
            proposal_id,
            output_root=output_root,
            resolved_tokens=resolved_tokens,
        )
        proposal["resolved_tokens_path"] = str(resolved_tokens_path)
        proposal.setdefault("inputs_applied", candidate["proposed_inputs"])
        proposal.setdefault("design_overlay", candidate["proposed_overlay"])

    persisted_to_source = False
    persisted_source_path: str | None = None
    source_audit_path: str | None = None
    audit_appended = False
    if arguments.get("persist_to_source"):
        try:
            persisted_path = _persist_brand_tokens_to_source(
                server,
                brand_name=brand_name,
                tokens=resolved_tokens,
            )
        except FileNotFoundError as exc:
            return {"error": "source_token_file_not_found", "detail": str(exc)}
        persisted_to_source = True
        persisted_source_path = str(persisted_path)
        existing_audit_path = proposal.get("source_audit_path")
        existing_source_path = proposal.get("source_token_path")
        if (
            proposal.get("source_persisted_at")
            and existing_audit_path
            and existing_source_path == persisted_source_path
        ):
            source_audit_path = str(existing_audit_path)
        else:
            try:
                history_path = _append_persisted_apply_audit(
                    proposal=proposal,
                    review_bundle=review_bundle,
                    proposal_path=proposal_path,
                    review_bundle_path=review_bundle_path,
                    source_path=persisted_path,
                )
            except OSError as exc:
                return {
                    "error": "source_audit_write_failed",
                    "detail": str(exc),
                    "persisted_source_path": persisted_source_path,
                }
            source_audit_path = str(history_path)
            audit_appended = True

    if not hasattr(server, "loaded_tokens"):
        server.loaded_tokens = {}
    server.loaded_tokens[brand_name] = deepcopy(resolved_tokens)

    if not hasattr(server, "design_overlays"):
        server.design_overlays = {}
    server.design_overlays[brand_name] = deepcopy(proposal.get("design_overlay", {}))

    if getattr(server, "active_brand", None) is None:
        server.active_brand = brand_name

    cache_cleared = False
    try:
        if hasattr(server, "cache_manager") and server.cache_manager is not None:
            server.cache_manager.invalidate(brand_name)
            cache_cleared = True
    except Exception:
        cache_cleared = False

    already_applied = proposal.get("state") == "applied"
    _set_proposal_state(proposal, review_bundle, state="applied")
    if persisted_to_source:
        timestamp = datetime.now(timezone.utc).isoformat()
        proposal["source_token_path"] = persisted_source_path
        proposal["source_audit_path"] = source_audit_path
        proposal.setdefault("source_persisted_at", timestamp)
        if review_bundle is not None:
            review_bundle["source_token_path"] = persisted_source_path
            review_bundle["source_audit_path"] = source_audit_path
            review_bundle.setdefault(
                "source_persisted_at", proposal["source_persisted_at"]
            )
    _write_json(proposal_path, proposal)
    if review_bundle is not None:
        _write_json(review_bundle_path, review_bundle)
        review_bundle["artifact_path"] = str(review_bundle_path)

    return {
        "success": True,
        "action": "apply_token_proposal",
        "proposal_id": proposal_id,
        "brand": brand_name,
        "already_applied": already_applied,
        "persisted_to_source": persisted_to_source,
        "persisted_source_path": persisted_source_path,
        "source_audit_path": source_audit_path,
        "audit_appended": audit_appended,
        "cache_cleared": cache_cleared,
        "proposal_path": str(proposal_path),
        "review_bundle_path": (
            str(review_bundle_path) if review_bundle is not None else None
        ),
        "proposal": proposal,
        "review_bundle": review_bundle,
        "message": f"Applied proposal '{proposal_id}' to brand '{brand_name}'.",
    }


async def reject_token_proposal(
    arguments: dict[str, Any], server: Any
) -> dict[str, Any]:
    """Reject a persisted token proposal without mutating live tokens."""
    try:
        proposal, review_bundle, proposal_path, review_bundle_path, _ = (
            _load_proposal_artifacts(arguments, server)
        )
    except (ValueError, FileNotFoundError) as exc:
        return {"error": str(exc)}

    proposal_id = str(proposal.get("proposal_id") or proposal.get("review_id") or "")
    brand_name = str((proposal.get("target") or {}).get("brand") or "")
    if proposal.get("state") == "applied":
        return {"error": "proposal_applied", "detail": proposal_id}

    already_rejected = proposal.get("state") == "rejected"
    if not already_rejected:
        _set_proposal_state(
            proposal,
            review_bundle,
            state="rejected",
            reason=arguments.get("reason"),
        )
        _write_json(proposal_path, proposal)
        if review_bundle is not None:
            _write_json(review_bundle_path, review_bundle)
            review_bundle["artifact_path"] = str(review_bundle_path)

    return {
        "success": True,
        "action": "reject_token_proposal",
        "proposal_id": proposal_id,
        "brand": brand_name,
        "already_rejected": already_rejected,
        "proposal_path": str(proposal_path),
        "review_bundle_path": (
            str(review_bundle_path) if review_bundle is not None else None
        ),
        "proposal": proposal,
        "review_bundle": review_bundle,
        "message": f"Rejected proposal '{proposal_id}' for brand '{brand_name}'.",
    }
