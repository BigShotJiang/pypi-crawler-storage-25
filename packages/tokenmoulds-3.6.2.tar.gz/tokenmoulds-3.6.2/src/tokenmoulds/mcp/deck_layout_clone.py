"""Materialize clone-required deck layouts as PresentationML layout parts."""

from __future__ import annotations

from dataclasses import dataclass
from math import ceil
from typing import Any

from lxml import etree

from tokenmoulds.archetypes.renderer import ArchetypeRenderer
from tokenmoulds.archetypes.shape_dsl import (
    ConnectorDef,
    GridPos,
    ShapeDef,
    SlideArchetype,
)
from tokenmoulds.design.page_geometry import create_slide_grid
from tokenmoulds.mcp.layout_registry import LayoutInfo


@dataclass(frozen=True)
class DynamicLayout:
    """A cloned layout generated during deck package assembly."""

    name: str
    display_name: str
    layout_number: int
    placeholder_map: dict[str, tuple[str | None, str | None]]
    layout_xml: bytes

    @property
    def layout_info(self) -> LayoutInfo:
        return LayoutInfo(
            name=self.name,
            display_name=self.display_name,
            family="cloned",
            slots=tuple(self.placeholder_map),
            description=f"Generated cloned layout derived during deck planning: {self.name}",
        )


def build_dynamic_layouts(
    slides: list[dict[str, Any]],
    *,
    slide_width: int,
    slide_height: int,
    baseline_emu: int = 152400,
    first_layout_number: int = 201,
) -> dict[str, DynamicLayout]:
    """Build dynamic cloned layouts required by slide decisions."""
    layouts: dict[str, DynamicLayout] = {}
    next_number = first_layout_number

    for slide in slides:
        decision = slide.get("layout_decision")
        if not isinstance(decision, dict):
            continue
        if decision.get("strategy") != "clone_required":
            continue

        clone_name = str(decision.get("clone_name") or "generated_clone")
        if clone_name in layouts:
            continue

        slots = tuple(
            slot
            for slot in decision.get("required_slots", ())
            if isinstance(slot, str) and slot
        )
        layout = _build_dynamic_layout(
            clone_name,
            slots,
            clone_source=str(decision.get("clone_source") or ""),
            layout_number=next_number,
            slide_width=slide_width,
            slide_height=slide_height,
            baseline_emu=baseline_emu,
        )
        layouts[clone_name] = layout
        next_number += 1

    return layouts


def _build_dynamic_layout(
    name: str,
    slots: tuple[str, ...],
    *,
    clone_source: str,
    layout_number: int,
    slide_width: int,
    slide_height: int,
    baseline_emu: int,
) -> DynamicLayout:
    content_slots = tuple(slot for slot in slots if slot != "title")
    if _is_process_clone(clone_source, content_slots):
        return _build_process_dynamic_layout(
            name,
            content_slots,
            layout_number=layout_number,
            slide_width=slide_width,
            slide_height=slide_height,
            baseline_emu=baseline_emu,
        )

    return _build_generic_dynamic_layout(
        name,
        content_slots,
        layout_number=layout_number,
        slide_width=slide_width,
        slide_height=slide_height,
        baseline_emu=baseline_emu,
    )


def _build_generic_dynamic_layout(
    name: str,
    content_slots: tuple[str, ...],
    *,
    layout_number: int,
    slide_width: int,
    slide_height: int,
    baseline_emu: int,
) -> DynamicLayout:
    regions: dict[str, GridPos] = {"title": GridPos(0, 0, 12, 4)}
    shapes: list[ShapeDef | ConnectorDef] = [_title_shape()]
    placeholder_map: dict[str, tuple[str | None, str | None]] = {
        "title": ("title", None)
    }

    for idx, slot in enumerate(content_slots, start=1):
        regions[slot] = _content_region(idx - 1, len(content_slots))
        ph_idx = str(19 + idx)
        shapes.append(
            ShapeDef(
                name=slot.replace("_", " ").title(),
                region=slot,
                ph_idx=ph_idx,
                no_outline=True,
            )
        )
        placeholder_map[slot] = (None, ph_idx)

    archetype = SlideArchetype(
        name=name,
        display_name=name.replace("_", " ").title(),
        regions=regions,
        shapes=tuple(shapes),
        decorative_regions=frozenset(content_slots),
        fallback_standard_layout="blank",
    )
    grid = create_slide_grid(slide_width, slide_height, baseline_emu, columns=12)
    root = ArchetypeRenderer().render_layout(archetype, grid)
    layout_xml = etree.tostring(root, encoding="UTF-8", xml_declaration=True)
    return DynamicLayout(
        name=name,
        display_name=archetype.display_name,
        layout_number=layout_number,
        placeholder_map=placeholder_map,
        layout_xml=layout_xml,
    )


def _build_process_dynamic_layout(
    name: str,
    content_slots: tuple[str, ...],
    *,
    layout_number: int,
    slide_width: int,
    slide_height: int,
    baseline_emu: int,
) -> DynamicLayout:
    regions: dict[str, GridPos] = {"title": GridPos(0, 0, 12, 4)}
    shapes: list[ShapeDef | ConnectorDef] = [_title_shape()]
    placeholder_map: dict[str, tuple[str | None, str | None]] = {
        "title": ("title", None)
    }
    content_regions = _process_content_regions(len(content_slots))

    for idx, (slot, region) in enumerate(
        zip(content_slots, content_regions, strict=True),
        start=1,
    ):
        regions[slot] = region
        ph_idx = str(19 + idx)
        shapes.append(
            ShapeDef(
                name=f"Step {idx}",
                region=slot,
                kind="roundRect",
                ph_idx=ph_idx,
                fill_region=slot,
                no_outline=True,
            )
        )
        placeholder_map[slot] = (None, ph_idx)

        if idx < len(content_regions):
            next_region = content_regions[idx]
            connector_region, connector = _process_connector(
                idx,
                region,
                next_region,
            )
            regions[connector.region] = connector_region
            shapes.append(connector)

    archetype = SlideArchetype(
        name=name,
        display_name=f"{len(content_slots)}-Step Process",
        regions=regions,
        shapes=tuple(shapes),
        decorative_regions=frozenset(content_slots),
        fallback_standard_layout="blank",
    )
    grid = create_slide_grid(slide_width, slide_height, baseline_emu, columns=12)
    root = ArchetypeRenderer().render_layout(archetype, grid)
    layout_xml = etree.tostring(root, encoding="UTF-8", xml_declaration=True)
    return DynamicLayout(
        name=name,
        display_name=archetype.display_name,
        layout_number=layout_number,
        placeholder_map=placeholder_map,
        layout_xml=layout_xml,
    )


def _title_shape() -> ShapeDef:
    return ShapeDef(
        name="Title",
        region="title",
        ph_type="title",
        no_fill=True,
        no_group=True,
    )


def _content_region(index: int, count: int) -> GridPos:
    if count <= 0:
        return GridPos(0, 5, 12, 24)

    columns = min(3, count)
    rows = ceil(count / columns)
    col_span = max(2, (12 - (columns - 1)) // columns)
    row_span = max(4, (25 - (rows - 1)) // rows)
    row = index // columns
    col = index % columns
    return GridPos(
        col * (col_span + 1),
        5 + row * (row_span + 1),
        col_span,
        row_span,
    )


def _is_process_clone(clone_source: str, content_slots: tuple[str, ...]) -> bool:
    return (
        bool(content_slots)
        and clone_source.startswith("process_")
        and all(slot.startswith(("group_", "step_")) for slot in content_slots)
    )


def _process_content_regions(count: int) -> tuple[GridPos, ...]:
    if count <= 0:
        return ()
    if count == 1:
        return (GridPos(0, 6, 12, 22),)
    if count == 2:
        return (GridPos(0, 6, 5, 22), GridPos(7, 6, 5, 22))
    if count == 3:
        return (
            GridPos(0, 6, 3, 22),
            GridPos(4, 6, 3, 22),
            GridPos(8, 6, 3, 22),
        )
    if count == 4:
        return (
            GridPos(0, 6, 2, 22),
            GridPos(3, 6, 2, 22),
            GridPos(6, 6, 2, 22),
            GridPos(9, 6, 2, 22),
        )

    columns = 3 if count <= 6 else 4
    rows = ceil(count / columns)
    col_gap = 1
    row_gap = 2
    start_row = 6
    col_span = max(2, (12 - col_gap * (columns - 1)) // columns)
    row_span = max(2, (24 - row_gap * (rows - 1)) // rows)

    regions: list[GridPos] = []
    for index in range(count):
        row = index // columns
        col = index % columns
        regions.append(
            GridPos(
                col * (col_span + col_gap),
                start_row + row * (row_span + row_gap),
                col_span,
                row_span,
            )
        )
    return tuple(regions)


def _process_arrow_region(left: GridPos, right: GridPos) -> GridPos:
    col = left.col + left.col_span
    col_span = max(1, right.col - col)
    row_span = max(1, min(6, left.row_span // 2))
    row = left.row + max(0, (left.row_span - row_span) // 2)
    return GridPos(col, row, col_span, row_span)


def _process_connector(
    index: int,
    current: GridPos,
    next_region: GridPos,
) -> tuple[GridPos, ConnectorDef]:
    name = f"Arrow {index}-{index + 1}"
    if current.row == next_region.row:
        region_name = f"arrow_{index}"
        return (
            _process_arrow_region(current, next_region),
            ConnectorDef(name=name, region=region_name, color="accent1"),
        )

    region_name = f"wrap_arrow_{index}"
    current_exit_col = current.col + current.col_span
    next_entry_col = next_region.col
    return (
        _process_wrap_arrow_region(current, next_region),
        ConnectorDef(
            name=name,
            region=region_name,
            kind="bentConnector3",
            color="accent1",
            flip_h=current_exit_col > next_entry_col,
        ),
    )


def _process_wrap_arrow_region(current: GridPos, next_region: GridPos) -> GridPos:
    current_exit_col = current.col + current.col_span
    next_entry_col = next_region.col
    left_col = min(current_exit_col, next_entry_col)
    right_col = max(current_exit_col, next_entry_col)
    top_row = current.row + max(1, current.row_span // 2)
    bottom_row = next_region.row + max(1, next_region.row_span // 2)
    return GridPos(
        left_col,
        top_row,
        max(1, right_col - left_col),
        max(1, bottom_row - top_row),
    )
