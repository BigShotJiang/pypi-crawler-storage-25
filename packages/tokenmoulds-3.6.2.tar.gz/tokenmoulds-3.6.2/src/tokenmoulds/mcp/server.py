"""TokenMoulds MCP Server - Full Pipeline Document Generation.

Provides Model Context Protocol server for AI-powered Office document generation.
All documents are generated through the complete TokenMoulds pipeline with:
- Font embedding (always enabled)
- ISO 29500 / ODF compliance
- WCAG accessibility
- Full style coverage (276 Word styles, etc.)
- Template caching and persistence

No bundled fallbacks - every document flows from TokenMoulds-generated templates.
"""

from __future__ import annotations

import asyncio
import json
import os
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Optional

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent

from tokenmoulds.mcp.cache import TemplateCacheManager
from tokenmoulds.mcp.server_support_mixin import ServerSupportMixin
from tokenmoulds.mcp.server_tools_mixin import ServerToolsMixin

# Add-in and macro tools

# Brand management tools

# Brand modification (level 2 AI control)

# Design modification (level 3 AI control)

# Document creation tools (full pipeline - no bundled fallbacks)

# Template generation tools
from tokenmoulds.mcp.tools.user_context import (
    infer_brand_from_email,
)

# Validation

# Path to vendored fonts (None — must be configured explicitly)
VENDORED_FONTS_PATH: Path | None = None


class TokenMouldsServer(ServerToolsMixin, ServerSupportMixin):
    """MCP Server for TokenMoulds document generation.

    Full pipeline server with:
    - Brand extraction from URL (CSS → Design Tokens)
    - Recipe building from minimal inputs
    - Template generation for all formats (Word, PowerPoint, Excel, LibreOffice, Google Docs, Themes)
    - Document creation with content injection
    - Template caching and persistence
    - ISO 29500 / ODF validation
    - Font embedding (always enabled)
    """

    def __init__(
        self,
        tokens_path: Optional[Path] = None,
        brands_path: Optional[Path] = None,
        output_path: Path = Path("./generated"),
        cache_path: Optional[Path] = None,
        fonts_dir: Optional[Path] = None,
    ) -> None:
        """Initialize the TokenMoulds MCP server.

        Args:
            tokens_path: Path to design tokens directory
            brands_path: Path to multi-brand directory (alternative to tokens_path)
            output_path: Directory for generated documents
            cache_path: Directory for template cache (default: ~/.tokenmoulds/cache)
            fonts_dir: Directory for vendored fonts
        """
        self.tokens_path = tokens_path
        self.brands_path = brands_path
        self.output_path = Path(output_path)
        self.output_path.mkdir(parents=True, exist_ok=True)

        # Font directory
        self.fonts_dir = fonts_dir or VENDORED_FONTS_PATH

        # Template cache manager
        self.cache_manager = TemplateCacheManager(cache_path)

        # Active brand configuration
        self.active_brand: Optional[str] = None
        self.loaded_tokens: Dict[str, Any] = {}
        self.brand_token_files: Dict[str, Path] = {}
        self.design_overlays: Dict[str, Dict[str, Any]] = {}

        # User context (email, domain, inferred brand)
        self.user_context: Optional[Dict[str, Any]] = None

        # Auto-detect user from environment
        self._auto_detected_email: Optional[str] = None
        self._auto_init_task: Optional[asyncio.Task] = None

        # Load initial tokens if provided
        if tokens_path and tokens_path.exists():
            self._load_tokens_from_directory(tokens_path, "default")

        # Load brands if multi-brand directory provided
        if brands_path and brands_path.exists():
            self._load_brands_from_directory(brands_path)

        # Create MCP server
        self.server = Server("tokenmoulds")
        self._register_tools()
        self._register_handlers()

    def _load_tokens_from_directory(self, path: Path, brand_name: str) -> None:
        """Load tokens from a directory."""
        # Look for .tokens.json files (DTCG format)
        token_files = list(path.glob("*.tokens.json"))
        if token_files:
            token_file = token_files[0]
            with open(token_file, "r", encoding="utf-8") as f:
                self.loaded_tokens[brand_name] = json.load(f)
            self.brand_token_files[brand_name] = token_file
            if self.active_brand is None:
                self.active_brand = brand_name
            return

        # Fall back to legacy JSON
        json_files = list(path.glob("*-design-tokens.json"))
        if json_files:
            token_file = json_files[0]
            with open(token_file, "r", encoding="utf-8") as f:
                self.loaded_tokens[brand_name] = json.load(f)
            self.brand_token_files[brand_name] = token_file
            if self.active_brand is None:
                self.active_brand = brand_name

    def _load_brands_from_directory(self, path: Path) -> None:
        """Load multiple brands from a directory structure."""
        for brand_dir in path.iterdir():
            if brand_dir.is_dir():
                self._load_tokens_from_directory(brand_dir, brand_dir.name)

    def _detect_user_email(self) -> Optional[str]:
        """Detect user email from environment.

        Checks in order:
        1. Git global config (git config --global user.email)
        2. Git local config (git config user.email)
        3. Environment variables (EMAIL, GIT_AUTHOR_EMAIL)

        Returns:
            Email address if found, None otherwise
        """
        # Try git global config first
        try:
            result = subprocess.run(
                ["git", "config", "--global", "user.email"],
                capture_output=True,
                text=True,
                timeout=2,
            )
            if result.returncode == 0 and result.stdout.strip():
                return result.stdout.strip()
        except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
            pass

        # Try git local config
        try:
            result = subprocess.run(
                ["git", "config", "user.email"],
                capture_output=True,
                text=True,
                timeout=2,
            )
            if result.returncode == 0 and result.stdout.strip():
                return result.stdout.strip()
        except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
            pass

        # Try environment variables
        for var in ("EMAIL", "GIT_AUTHOR_EMAIL", "GIT_COMMITTER_EMAIL"):
            email = os.environ.get(var)
            if email and "@" in email:
                return email

        return None

    async def _auto_initialize_brand(self) -> None:
        """Auto-initialize brand from detected user email.

        Runs in background during server startup. Non-blocking.
        """
        email = self._detect_user_email()
        if not email:
            return

        self._auto_detected_email = email

        # Import here to avoid circular imports
        from tokenmoulds.mcp.tools.user_context import (
            extract_brand_name_from_domain,
            extract_domain_from_email,
        )

        domain = extract_domain_from_email(email)
        if not domain:
            return

        brand_name = extract_brand_name_from_domain(domain)

        # Set initial user context
        self.user_context = {
            "email": email,
            "domain": domain,
            "organization": brand_name,
            "brand_name": brand_name,
            "auto_detected": True,
        }

        # Try to infer brand from website (this may fail for some domains)
        try:
            result = await infer_brand_from_email({"domain": domain}, self)
            if result.get("success"):
                self.user_context["brand_loaded"] = True
                self.user_context["brand_source"] = "website"
        except Exception:
            # Brand inference failed - that's OK, user can manually set up
            self.user_context["brand_loaded"] = False
            self.user_context["brand_source"] = None


    def _register_handlers(self) -> None:
        """Register tool call handlers."""

        @self.server.call_tool()
        async def call_tool(name: str, arguments: Dict[str, Any]) -> List[TextContent]:
            """Handle tool calls."""
            try:
                result = await self._dispatch_tool(name, arguments)
                return [TextContent(type="text", text=json.dumps(result, indent=2))]

            except Exception as e:
                error_result = {"error": str(e), "tool": name}
                return [
                    TextContent(type="text", text=json.dumps(error_result, indent=2))
                ]


    async def run(self) -> None:
        """Run the MCP server with stdio transport."""
        # Start brand auto-initialization in background (non-blocking)
        self._auto_init_task = asyncio.create_task(self._auto_initialize_brand())

        async with stdio_server() as (read_stream, write_stream):
            await self.server.run(
                read_stream,
                write_stream,
                self.server.create_initialization_options(),
            )


def create_server(
    tokens_path: Optional[Path] = None,
    brands_path: Optional[Path] = None,
    output_path: Path = Path("./generated"),
    cache_path: Optional[Path] = None,
    fonts_dir: Optional[Path] = None,
) -> TokenMouldsServer:
    """Create a TokenMoulds MCP server instance.

    Args:
        tokens_path: Path to design tokens directory
        brands_path: Path to multi-brand directory
        output_path: Directory for generated documents
        cache_path: Directory for template cache
        fonts_dir: Directory for vendored fonts

    Returns:
        Configured TokenMouldsServer instance
    """
    return TokenMouldsServer(
        tokens_path=tokens_path,
        brands_path=brands_path,
        output_path=output_path,
        cache_path=cache_path,
        fonts_dir=fonts_dir,
    )


def run_server(
    tokens_path: Optional[Path] = None,
    brands_path: Optional[Path] = None,
    output_path: Path = Path("./generated"),
    cache_path: Optional[Path] = None,
    fonts_dir: Optional[Path] = None,
) -> None:
    """Run the TokenMoulds MCP server.

    Args:
        tokens_path: Path to design tokens directory
        brands_path: Path to multi-brand directory
        output_path: Directory for generated documents
        cache_path: Directory for template cache
        fonts_dir: Directory for vendored fonts
    """
    server = create_server(
        tokens_path=tokens_path,
        brands_path=brands_path,
        output_path=output_path,
        cache_path=cache_path,
        fonts_dir=fonts_dir,
    )
    asyncio.run(server.run())
