"""Tool registration and dispatch mixin for TokenMoulds MCP server."""

from __future__ import annotations

from typing import Any, Dict, List

from mcp.types import Tool


# Add-in and macro tools
from tokenmoulds.mcp.tools.addin_certificates import (
    GENERATE_CERTIFICATE_SCHEMA,
    LIST_CERTIFICATES_SCHEMA,
    generate_self_signed_certificate,
    list_certificates,
)
from tokenmoulds.mcp.tools.addin_signer import (
    CREATE_VBA_ADDIN_SCHEMA,
    create_vba_addin,
)
from tokenmoulds.mcp.tools.addin_web import (
    CREATE_WEB_ADDIN_SCHEMA,
    create_web_addin,
)

# Brand management tools
from tokenmoulds.mcp.tools.brand_manager import (
    BUILD_RECIPE_SCHEMA,
    EXTRACT_BRAND_SCHEMA,
    LIST_BRANDS_SCHEMA,
    LOAD_BRAND_SCHEMA,
    SET_ACTIVE_BRAND_SCHEMA,
    build_recipe_from_inputs,
    extract_brand_from_url,
    list_brands,
    load_brand,
    set_active_brand,
)

# Brand modification (level 2 AI control)
from tokenmoulds.mcp.tools.brand_modifier import (
    MODIFY_BRAND_SCHEMA,
    modify_brand,
)

# Design modification (level 3 AI control)
from tokenmoulds.mcp.tools.design_modifier import (
    MODIFY_DESIGN_SCHEMA,
    modify_design,
)

# Document creation tools (full pipeline - no bundled fallbacks)
from tokenmoulds.mcp.tools.document_creator import (
    create_excel_document,
    create_impress_document,
    create_powerpoint_document,
    create_word_document,
    create_writer_document,
)
from tokenmoulds.mcp.tools.document_creator_schemas import (
    CREATE_EXCEL_DOCUMENT_SCHEMA,
    CREATE_IMPRESS_DOCUMENT_SCHEMA,
    CREATE_POWERPOINT_DOCUMENT_SCHEMA,
    CREATE_WORD_DOCUMENT_SCHEMA,
    CREATE_WRITER_DOCUMENT_SCHEMA,
)
from tokenmoulds.mcp.tools.review_proposal import (
    LIST_TOKEN_PROPOSALS_SCHEMA,
    REVIEW_TOKEN_PROPOSAL_SCHEMA,
    list_token_proposals,
    review_token_proposal,
)

# Template generation tools
from tokenmoulds.mcp.tools.template_generator import (
    generate_excel_template,
    generate_google_docs_template,
    generate_impress_template,
    generate_powerpoint_template,
    generate_theme,
    generate_word_template,
    generate_writer_template,
)
from tokenmoulds.mcp.tools.template_generator_batch import generate_all_templates
from tokenmoulds.mcp.tools.template_generator_schemas import (
    GENERATE_ALL_TEMPLATES_SCHEMA,
    GENERATE_EXCEL_TEMPLATE_SCHEMA,
    GENERATE_GOOGLE_DOCS_TEMPLATE_SCHEMA,
    GENERATE_IMPRESS_TEMPLATE_SCHEMA,
    GENERATE_POWERPOINT_TEMPLATE_SCHEMA,
    GENERATE_THEME_SCHEMA,
    GENERATE_WORD_TEMPLATE_SCHEMA,
    GENERATE_WRITER_TEMPLATE_SCHEMA,
)
from tokenmoulds.mcp.tools.token_proposal import (
    APPLY_TOKEN_PROPOSAL_SCHEMA,
    PROPOSE_TOKEN_CHANGES_SCHEMA,
    REJECT_TOKEN_PROPOSAL_SCHEMA,
    apply_token_proposal,
    propose_token_changes,
    reject_token_proposal,
)
from tokenmoulds.mcp.tools.user_context import (
    GET_USER_CONTEXT_SCHEMA,
    INFER_BRAND_SCHEMA,
    SET_USER_CONTEXT_SCHEMA,
    get_user_context,
    infer_brand_from_email,
    set_user_context,
)


class ServerToolsMixin:
    def _register_tools(self) -> None:
        """Register all MCP tools."""

        @self.server.list_tools()
        async def list_tools() -> List[Tool]:
            """List all available tools."""
            return [
                # ============================================================
                # USER CONTEXT TOOLS
                # ============================================================
                Tool(
                    name="set_user_context",
                    description="Set user context from email. Automatically extracts domain, infers brand name, and fetches brand from organization's website CSS.",
                    inputSchema=SET_USER_CONTEXT_SCHEMA,
                ),
                Tool(
                    name="infer_brand_from_email",
                    description="Infer brand by fetching website CSS from email domain. user@democorp.com → https://democorp.com → extract colors/fonts → brand tokens ready.",
                    inputSchema=INFER_BRAND_SCHEMA,
                ),
                Tool(
                    name="get_user_context",
                    description="Get current user context including email, domain, and active brand.",
                    inputSchema=GET_USER_CONTEXT_SCHEMA,
                ),
                # ============================================================
                # BRAND MANAGEMENT TOOLS
                # ============================================================
                Tool(
                    name="extract_brand_from_url",
                    description="Extract brand colors, fonts, and styling from a website URL. Generates complete DTCG design tokens with derivation formulas. Full pipeline: URL → CSS → Brand → Recipe → Tokens.",
                    inputSchema=EXTRACT_BRAND_SCHEMA,
                ),
                Tool(
                    name="build_recipe_from_inputs",
                    description="Build DTCG design tokens from minimal inputs (colors, fonts, parameters). Creates a complete token system with formulas, page layouts, and 100+ paragraph/character styles.",
                    inputSchema=BUILD_RECIPE_SCHEMA,
                ),
                Tool(
                    name="load_brand",
                    description="Load existing design tokens from a directory. Supports DTCG (*.tokens.json) and legacy (*-design-tokens.json) formats.",
                    inputSchema=LOAD_BRAND_SCHEMA,
                ),
                Tool(
                    name="list_brands",
                    description="List all loaded and cached brands with their status and available templates.",
                    inputSchema=LIST_BRANDS_SCHEMA,
                ),
                Tool(
                    name="set_active_brand",
                    description="Set the active brand for template and document generation.",
                    inputSchema=SET_ACTIVE_BRAND_SCHEMA,
                ),
                Tool(
                    name="modify_brand",
                    description="Modify the active brand's design tokens. Apply a curated preset (corporate, startup, editorial, academic, creative) and/or override individual values (brand_tone, primary_color, font_sans, etc.). Re-derives all 4,576 tokens and invalidates the template cache so the next create_document/create_presentation uses the updated brand. This is level 2 AI control — change the design system, not just content.",
                    inputSchema=MODIFY_BRAND_SCHEMA,
                ),
                Tool(
                    name="modify_design",
                    description="Adjust typographic formulas via curated presets. Scale ratio (minor_second to golden_ratio), tracking curve (tight/neutral/loose), heading spacing (compact/standard/dramatic), figure style, optical margin, small caps mode. This is level 3 AI control — change the typographic algebra without touching individual values. Design overlays persist through modify_brand calls.",
                    inputSchema=MODIFY_DESIGN_SCHEMA,
                ),
                Tool(
                    name="review_token_proposal",
                    description="Read a stored token review bundle by review_id or file_path. This is the first review surface over persisted curated-control artifacts and aligns with the future proposal workflow.",
                    inputSchema=REVIEW_TOKEN_PROPOSAL_SCHEMA,
                ),
                Tool(
                    name="propose_token_changes",
                    description="Validate and persist a token proposal without mutating the active brand. Produces proposal.json plus review-bundle.json under generated/review/<proposal_id>/.",
                    inputSchema=PROPOSE_TOKEN_CHANGES_SCHEMA,
                ),
                Tool(
                    name="apply_token_proposal",
                    description="Apply a persisted token proposal to the in-memory brand state and mark the proposal artifact as applied.",
                    inputSchema=APPLY_TOKEN_PROPOSAL_SCHEMA,
                ),
                Tool(
                    name="reject_token_proposal",
                    description="Reject a persisted token proposal without mutating live tokens, and mark the stored proposal artifact as rejected.",
                    inputSchema=REJECT_TOKEN_PROPOSAL_SCHEMA,
                ),
                Tool(
                    name="list_token_proposals",
                    description="List stored token review bundles under generated/review/, optionally filtered by brand or action.",
                    inputSchema=LIST_TOKEN_PROPOSALS_SCHEMA,
                ),
                # ============================================================
                # TEMPLATE GENERATION TOOLS
                # ============================================================
                Tool(
                    name="generate_word_template",
                    description="Generate Word template (.dotx) with 276 themed styles. Full TokenMoulds pipeline with font embedding, ISO 29500 compliance, zero Office defaults.",
                    inputSchema=GENERATE_WORD_TEMPLATE_SCHEMA,
                ),
                Tool(
                    name="generate_powerpoint_template",
                    description="Generate PowerPoint template (.potx) with professional table styles, theme colors, and font embedding. ISO 29500 compliant.",
                    inputSchema=GENERATE_POWERPOINT_TEMPLATE_SCHEMA,
                ),
                Tool(
                    name="generate_excel_template",
                    description="Generate Excel template (.xltx) with themed cell styles and colors.",
                    inputSchema=GENERATE_EXCEL_TEMPLATE_SCHEMA,
                ),
                Tool(
                    name="generate_writer_template",
                    description="Generate LibreOffice Writer template (.ott) with ODF-compliant styles.",
                    inputSchema=GENERATE_WRITER_TEMPLATE_SCHEMA,
                ),
                Tool(
                    name="generate_impress_template",
                    description="Generate LibreOffice Impress template (.otp) with ODF-compliant slides.",
                    inputSchema=GENERATE_IMPRESS_TEMPLATE_SCHEMA,
                ),
                Tool(
                    name="generate_google_docs_template",
                    description="Generate Google Docs-compatible template (.dotx optimized for Google Workspace import).",
                    inputSchema=GENERATE_GOOGLE_DOCS_TEMPLATE_SCHEMA,
                ),
                Tool(
                    name="generate_theme",
                    description="Generate standalone Office theme (.thmx) that can be applied to any Office document.",
                    inputSchema=GENERATE_THEME_SCHEMA,
                ),
                Tool(
                    name="generate_all_templates",
                    description="Generate all template formats for a brand in one call (Word, PowerPoint, Excel, Writer, Impress, Google Docs, Theme).",
                    inputSchema=GENERATE_ALL_TEMPLATES_SCHEMA,
                ),
                # ============================================================
                # DOCUMENT CREATION TOOLS
                # All documents from TokenMoulds templates (with generic fallback)
                # ============================================================
                Tool(
                    name="create_word_document",
                    description="Create a professionally styled Word document (.docx) with content. Full TokenMoulds pipeline with 276 themed styles. Uses brand template or generic TokenMoulds template.",
                    inputSchema=CREATE_WORD_DOCUMENT_SCHEMA,
                ),
                Tool(
                    name="create_powerpoint_document",
                    description=(
                        "Create a styled PowerPoint presentation (.pptx). "
                        "For ordinary 'make slides' requests, pass markdown/content "
                        "and let TokenMoulds plan layouts. If source content is "
                        "missing, the tool returns a polite clarification prompt; "
                        "ask about brief, audience, and slide count, not grids or placeholders."
                    ),
                    inputSchema=CREATE_POWERPOINT_DOCUMENT_SCHEMA,
                ),
                Tool(
                    name="create_excel_document",
                    description="Create a styled Excel workbook (.xlsx) with sheets. Uses TokenMoulds template for themed cell styles.",
                    inputSchema=CREATE_EXCEL_DOCUMENT_SCHEMA,
                ),
                Tool(
                    name="create_writer_document",
                    description="Create a LibreOffice Writer document (.odt) with ODF-compliant styling.",
                    inputSchema=CREATE_WRITER_DOCUMENT_SCHEMA,
                ),
                Tool(
                    name="create_impress_document",
                    description="Create a LibreOffice Impress presentation (.odp) with ODF-compliant styling.",
                    inputSchema=CREATE_IMPRESS_DOCUMENT_SCHEMA,
                ),
                # ============================================================
                # ADD-IN AND MACRO TOOLS
                # Macros are codebases - they deserve the same rigor
                # ============================================================
                Tool(
                    name="create_vba_addin",
                    description="Create a VBA add-in (.docm/.xlam/.ppam) with optional code signing. Macros are codebases - treated with same rigor.",
                    inputSchema=CREATE_VBA_ADDIN_SCHEMA,
                ),
                Tool(
                    name="create_web_addin",
                    description="Create an Office Web Add-in manifest and project structure. For modern Office.js add-ins.",
                    inputSchema=CREATE_WEB_ADDIN_SCHEMA,
                ),
                Tool(
                    name="generate_certificate",
                    description="Generate a self-signed code signing certificate for development. Use organizational certificates for production.",
                    inputSchema=GENERATE_CERTIFICATE_SCHEMA,
                ),
                Tool(
                    name="list_certificates",
                    description="List available code signing certificates.",
                    inputSchema=LIST_CERTIFICATES_SCHEMA,
                ),
                # ============================================================
                # DISCOVERY TOOLS
                # ============================================================
                Tool(
                    name="list_layouts",
                    description="List available slide layouts for presentations. Returns layout names, display names, placeholder slot names, and descriptions. Use this to discover which layouts exist and what content slots each one accepts.",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "family": {
                                "type": "string",
                                "enum": ["core", "semantic", "consulting", "general"],
                                "description": "Filter by layout family (optional, returns all if omitted)",
                            },
                        },
                    },
                ),
                Tool(
                    name="list_styles",
                    description="List available document styles for Word/Writer documents. Returns style names, types (heading/paragraph/list/table/code), and descriptions. Use this to discover which styles to use when creating documents.",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "type_filter": {
                                "type": "string",
                                "enum": [
                                    "heading",
                                    "paragraph",
                                    "list",
                                    "table",
                                    "code",
                                    "inline",
                                ],
                                "description": "Filter by style type (optional, returns all if omitted)",
                            },
                        },
                    },
                ),
                # ============================================================
                # CACHE & VALIDATION TOOLS
                # ============================================================
                Tool(
                    name="validate_template",
                    description="Validate a template for ISO 29500 (OOXML) or ODF compliance. Checks structure, content types, relationships.",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "file_path": {
                                "type": "string",
                                "description": "Path to template file to validate",
                            },
                            "strict_mode": {
                                "type": "boolean",
                                "default": True,
                                "description": "Use strict ISO 29500 validation",
                            },
                            "extract_structure": {
                                "type": "boolean",
                                "default": False,
                                "description": "Return template structure details",
                            },
                        },
                        "required": ["file_path"],
                    },
                ),
                Tool(
                    name="clear_template_cache",
                    description="Clear cached templates for a brand or all brands.",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "brand": {
                                "type": "string",
                                "description": "Brand to clear (optional, clears all if not specified)",
                            },
                        },
                    },
                ),
                Tool(
                    name="list_cached_templates",
                    description="List all cached templates with metadata (size, fonts, validation status).",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "brand": {
                                "type": "string",
                                "description": "Filter by brand (optional)",
                            },
                        },
                    },
                ),
            ]

    async def _dispatch_tool(
        self, name: str, arguments: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Dispatch tool call to appropriate handler."""

        # User context
        if name == "set_user_context":
            return await set_user_context(arguments, self)
        elif name == "infer_brand_from_email":
            return await infer_brand_from_email(arguments, self)
        elif name == "get_user_context":
            return await get_user_context(arguments, self)

        # Brand management
        elif name == "extract_brand_from_url":
            return await extract_brand_from_url(arguments, self)
        elif name == "build_recipe_from_inputs":
            return await build_recipe_from_inputs(arguments, self)
        elif name == "load_brand":
            return await load_brand(arguments, self)
        elif name == "list_brands":
            return await list_brands(arguments, self)
        elif name == "set_active_brand":
            return await set_active_brand(arguments, self)
        elif name == "modify_brand":
            return await modify_brand(arguments, self)
        elif name == "modify_design":
            return await modify_design(arguments, self)
        elif name == "review_token_proposal":
            return await review_token_proposal(arguments, self)
        elif name == "propose_token_changes":
            return await propose_token_changes(arguments, self)
        elif name == "apply_token_proposal":
            return await apply_token_proposal(arguments, self)
        elif name == "reject_token_proposal":
            return await reject_token_proposal(arguments, self)
        elif name == "list_token_proposals":
            return await list_token_proposals(arguments, self)

        # Template generation
        elif name == "generate_word_template":
            return await generate_word_template(arguments, self)
        elif name == "generate_powerpoint_template":
            return await generate_powerpoint_template(arguments, self)
        elif name == "generate_excel_template":
            return await generate_excel_template(arguments, self)
        elif name == "generate_writer_template":
            return await generate_writer_template(arguments, self)
        elif name == "generate_impress_template":
            return await generate_impress_template(arguments, self)
        elif name == "generate_google_docs_template":
            return await generate_google_docs_template(arguments, self)
        elif name == "generate_theme":
            return await generate_theme(arguments, self)
        elif name == "generate_all_templates":
            return await generate_all_templates(arguments, self)

        # Document creation (full pipeline - no bundled fallbacks)
        elif name == "create_word_document":
            return await create_word_document(arguments, self)
        elif name == "create_powerpoint_document":
            return await create_powerpoint_document(arguments, self)
        elif name == "create_excel_document":
            return await create_excel_document(arguments, self)
        elif name == "create_writer_document":
            return await create_writer_document(arguments, self)
        elif name == "create_impress_document":
            return await create_impress_document(arguments, self)

        # Add-in and macro tools
        elif name == "create_vba_addin":
            return await create_vba_addin(arguments, self)
        elif name == "create_web_addin":
            return await create_web_addin(arguments, self)
        elif name == "generate_certificate":
            return await generate_self_signed_certificate(arguments, self)
        elif name == "list_certificates":
            return await list_certificates(arguments, self)

        # Discovery
        elif name == "list_layouts":
            return await self._list_layouts(arguments)
        elif name == "list_styles":
            return await self._list_styles(arguments)

        # Cache & Validation
        elif name == "validate_template":
            return await self._validate_template(arguments)
        elif name == "clear_template_cache":
            return await self._clear_cache(arguments)
        elif name == "list_cached_templates":
            return await self._list_cache(arguments)

        else:
            return {"error": f"Unknown tool: {name}"}
