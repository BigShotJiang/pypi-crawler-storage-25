"""Document IR construction for the build pipeline."""

from __future__ import annotations

import structlog

from tokenmoulds.design.engine import DesignResolutionEngine, LineHeightMode
from tokenmoulds.dtcg.font_metrics import extract_font_metrics
from tokenmoulds.ir import DocumentIR
from tokenmoulds.ir import build_document_ir as _build_document_ir_legacy
from tokenmoulds.ir.design_bridge import create_document_ir_from_design
from tokenmoulds.pipeline_models import BuildConfig

logger = structlog.get_logger(__name__)

def _extract_font_pair(tokens: dict) -> dict[str, str]:
    """Extract font_pair from resolved tokens."""
    typography = tokens.get("typography", {})
    fonts = typography.get("fonts", {})
    if fonts:
        return dict(fonts)
    # Fall back to inputs section
    inputs = tokens.get("inputs", {})
    font_pair = inputs.get("font_pair", {})
    if font_pair:
        return dict(font_pair)
    return {"sans": "Inter", "serif": "Inter"}


def _extract_base_colors(tokens: dict) -> dict[str, str]:
    """Extract base colors from resolved tokens."""
    inputs = tokens.get("inputs", {})
    base_colors = inputs.get("base_colors", {})
    if base_colors:
        return dict(base_colors)
    colors = tokens.get("colors", {})
    palette = colors.get("palette", {})
    primary = palette.get("primary", {}).get("base", "#2563EB")
    secondary = palette.get("secondary", {}).get("base", "#DC2626")
    return {"primary": primary, "secondary": secondary}


def _extract_brand_tone(tokens: dict) -> float:
    """Extract brand_tone from resolved tokens."""
    inputs = tokens.get("inputs", {})
    return float(inputs.get("brand_tone", tokens.get("brand_tone", 0.5)))


def _extract_content_density(tokens: dict) -> float:
    """Extract content_density from resolved tokens."""
    inputs = tokens.get("inputs", {})
    return float(inputs.get("content_density", 0.4))


def _build_color_theme(tokens: dict):
    """Build ColorTheme from resolved token payload."""
    from tokenmoulds.design.color_defaults import (
        DEFAULT_PRIMARY,
        DEFAULT_SECONDARY,
        DEFAULT_THEME_MAPPING,
    )
    from tokenmoulds.ir import ColorTheme

    colors = tokens.get("colors", {})
    theme_map = colors.get("theme_mapping", {})
    if not theme_map:
        theme_map = dict(DEFAULT_THEME_MAPPING)
        theme_map["accent1"] = (
            colors.get("palette", {}).get("primary", {}).get("base", DEFAULT_PRIMARY)
        )
        theme_map["accent2"] = (
            colors.get("palette", {})
            .get("secondary", {})
            .get("base", DEFAULT_SECONDARY)
        )

    return ColorTheme(
        dk1=theme_map["dk1"],
        lt1=theme_map["lt1"],
        dk2=theme_map["dk2"],
        lt2=theme_map["lt2"],
        accent1=theme_map["accent1"],
        accent2=theme_map["accent2"],
        accent3=theme_map["accent3"],
        accent4=theme_map["accent4"],
        accent5=theme_map["accent5"],
        accent6=theme_map["accent6"],
        hyperlink=theme_map.get("hlink", theme_map["accent1"]),
        hyperlink_followed=theme_map.get("folHlink", theme_map["accent2"]),
    )


def _build_document_ir(
    tokens: dict,
    config: BuildConfig,
) -> DocumentIR:
    """Build DocumentIR via DesignResolutionEngine (Path B).

    Falls back to legacy Path A if Path B fails (e.g., missing font
    metrics), so the pipeline never produces worse output than before.
    """
    font_pair = _extract_font_pair(tokens)
    brand_tone = _extract_brand_tone(tokens)
    content_density = _extract_content_density(tokens)
    color_theme = _build_color_theme(tokens)

    try:
        font_metrics = extract_font_metrics(
            font_pair=font_pair,
            font_metrics_cache=None,
            fonts_dir=str(config.fonts_dir) if config.fonts_dir else None,
        )
    except (ValueError, RuntimeError) as exc:
        logger.warning(
            "Font metrics unavailable, falling back to legacy IR builder",
            error=str(exc),
        )
        return _build_document_ir_legacy(tokens, config.org_id, config.locale)

    # Build DesignResolutionEngine inputs
    from tokenmoulds.dtcg.generator import (
        _BrandAdapter,
        _FontConfigAdapter,
        _FontMetricsAdapter,
        _select_scale_ratio,
    )
    from tokenmoulds.fonts.superfamilies import resolve_monospace

    primary_metrics = font_metrics["primary"]
    serif_metrics = font_metrics.get("serif", primary_metrics)

    body_family = (
        font_pair.get("body")
        or font_pair.get("minor")
        or font_pair.get("sans")
        or "Inter"
    )
    heading_family = (
        font_pair.get("heading")
        or font_pair.get("major")
        or font_pair.get("serif")
        or body_family
    )
    mono_family = font_pair.get("mono") or "Courier New"
    try:
        mono_family = resolve_monospace(
            body_family, heading_family, font_pair.get("mono")
        )
    except Exception:
        pass

    body_adapter = _FontMetricsAdapter(
        x_height=primary_metrics["x_height"],
        units_per_em=primary_metrics["units_per_em"],
        cap_height=primary_metrics["cap_height"],
        ascender=primary_metrics["ascender"],
        descender=primary_metrics["descender"],
    )
    heading_adapter = _FontMetricsAdapter(
        x_height=serif_metrics["x_height"],
        units_per_em=serif_metrics["units_per_em"],
        cap_height=serif_metrics["cap_height"],
        ascender=serif_metrics["ascender"],
        descender=serif_metrics["descender"],
    )
    font_config = _FontConfigAdapter(
        body=body_adapter,
        heading=heading_adapter,
        _body_family=body_family,
        _heading_family=heading_family,
        _mono_family=mono_family,
    )
    brand = _BrandAdapter(tone=brand_tone, density=content_density)
    scale_ratio = _select_scale_ratio(brand_tone)

    engine = DesignResolutionEngine(
        fonts=font_config,
        brand=brand,
        locale=config.locale,
        colors={},
        base_font_size_pt=config.base_font_size_pt,
        scale_ratio=scale_ratio,
        line_height_mode=LineHeightMode.SNAPPED,
    )
    design = engine.resolve()

    document_ir = create_document_ir_from_design(
        design,
        org_id=config.org_id,
        locale=config.locale,
        body_font=body_family,
        heading_font=heading_family,
        monospace_font=mono_family,
        color_theme=color_theme,
    )

    if any(
        key in tokens
        for key in ("page_geometry", "margin_presets", "sections", "headers", "footers")
    ):
        from tokenmoulds.design.units.conversion import emu_to_pt
        from tokenmoulds.dtcg.long_form_resolver import resolve_long_form

        long_form_bundle = resolve_long_form(
            tokens, baseline_pt=emu_to_pt(document_ir.typography.baseline_emu)
        )
        document_ir.long_form_sections = long_form_bundle["sections"]
        document_ir.header_footer_registry = long_form_bundle["header_footer_registry"]

    return document_ir
