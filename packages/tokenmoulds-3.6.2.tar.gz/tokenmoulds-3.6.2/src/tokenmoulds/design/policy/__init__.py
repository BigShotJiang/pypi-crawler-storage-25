"""Policy system for design decisions.

Provides a pluggable policy engine for making consistent design decisions
across typography, color, spacing, and accessibility domains.

Example:
    from tokenmoulds.design.policy import PolicyEngine, load_policy

    engine = PolicyEngine()
    engine.set_policy("accessible")
    context = engine.evaluate()

    base_size = context.get_option("typography", "base_size_pt")
"""

from typing import Any as _Any

from tokenmoulds._lazy import lazy_dir, resolve_lazy_symbol_or_module

__all__ = [
    # Engine
    "PolicyEngine",
    "PolicyContext",
    "PolicyProvider",
    # Rules
    "Policy",
    "POLICY_PRESETS",
    "DEFAULT_POLICY",
    "load_policy",
    "merge_policy",
    # Targets
    "PolicyTarget",
    "TargetRegistry",
    "TYPOGRAPHY_TARGET",
    "COLOR_TARGET",
    "SPACING_TARGET",
    "FONT_EMBEDDING_TARGET",
    "ACCESSIBILITY_TARGET",
    # Options
    "TYPOGRAPHY_OPTIONS",
    "COLOR_OPTIONS",
    "SPACING_OPTIONS",
    "FONT_EMBEDDING_OPTIONS",
    "ACCESSIBILITY_OPTIONS",
    # Submodules
    "engine",
    "rules",
    "targets",
]

_symbol_map = {
    # engine.py
    "PolicyEngine": "engine",
    "PolicyContext": "engine",
    "PolicyProvider": "engine",
    # rules.py
    "Policy": "rules",
    "POLICY_PRESETS": "rules",
    "DEFAULT_POLICY": "rules",
    "load_policy": "rules",
    "merge_policy": "rules",
    "TYPOGRAPHY_OPTIONS": "rules",
    "COLOR_OPTIONS": "rules",
    "SPACING_OPTIONS": "rules",
    "FONT_EMBEDDING_OPTIONS": "rules",
    "ACCESSIBILITY_OPTIONS": "rules",
    # targets.py
    "PolicyTarget": "targets",
    "TargetRegistry": "targets",
    "TYPOGRAPHY_TARGET": "targets",
    "COLOR_TARGET": "targets",
    "SPACING_TARGET": "targets",
    "FONT_EMBEDDING_TARGET": "targets",
    "ACCESSIBILITY_TARGET": "targets",
}

_module_map = {
    "engine": "engine",
    "rules": "rules",
    "targets": "targets",
}


def __getattr__(name: str) -> _Any:
    return resolve_lazy_symbol_or_module(
        name,
        module_globals=globals(),
        package=__name__,
        symbol_modules=_symbol_map,
        module_aliases=_module_map,
    )


def __dir__() -> list[str]:
    return lazy_dir(globals(), __all__)
