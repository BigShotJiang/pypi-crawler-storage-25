"""Template format constants.

Centralises the stringly-typed format identifiers used across
validation, emitters, and test helpers.
"""


class Format:
    """Known template format identifiers."""

    WORD = "word"
    WORD_TEMPLATE = "word_template"
    POWERPOINT = "powerpoint"
    POWERPOINT_TEMPLATE = "powerpoint_template"
    EXCEL = "excel"
    EXCEL_TEMPLATE = "excel_template"
    THEME = "theme"
    # ODF formats
    WRITER = "writer"
    IMPRESS = "impress"
    CALC = "calc"
    # Catch-all
    UNKNOWN = "unknown"

    OOXML_FORMATS = frozenset(
        {
            WORD,
            WORD_TEMPLATE,
            POWERPOINT,
            POWERPOINT_TEMPLATE,
            EXCEL,
            EXCEL_TEMPLATE,
            THEME,
        }
    )

    ODF_FORMATS = frozenset({WRITER, IMPRESS, CALC})

    ALL = OOXML_FORMATS | ODF_FORMATS
