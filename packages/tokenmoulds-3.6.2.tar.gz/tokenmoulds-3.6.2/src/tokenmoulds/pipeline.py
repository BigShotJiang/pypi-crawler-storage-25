"""Shared build pipeline for template generation.

All entrypoints (CLI, MCP, GitHub workflows) call ``build()`` instead
of implementing their own token → IR → emit → validate flow.

Routes through ``DesignResolutionEngine`` (IR Path B) for richer
typography with OpenType features, baseline-grid-snapped spacing,
and modular type scales.

See ADR 027 (F2) and the BuildPipeline spec.
"""

from __future__ import annotations

import time
from datetime import datetime as _datetime
from datetime import timezone
from pathlib import Path
from typing import Any

import structlog

from tokenmoulds import __version__ as _PIPELINE_VERSION
from tokenmoulds.dtcg.converter import convert_from_dtcg
from tokenmoulds.dtcg.generator import TokenGenerator
from tokenmoulds.dtcg.layered_adapter import adapt_dtcg_layers
from tokenmoulds.dtcg.parser import parse_tokens
from tokenmoulds.dtcg.reference_resolver import resolve_references
from tokenmoulds.ir import DocumentIR
from tokenmoulds.pipeline_ir import _build_document_ir
from tokenmoulds.pipeline_models import (
    BuildBatchConfig,
    BuildConfig,
    BuildProvenance,
    BuildResult,
)
from tokenmoulds.semantic.collectors import collect_header_footer_semantic_provenance
from tokenmoulds.semantic.provenance import SemanticProvenance

logger = structlog.get_logger(__name__)


# =============================================================================
# Format → Emitter Dispatch
# =============================================================================

# Maps output format extension to (module_path, class_name, supports_fonts)
_EMITTER_REGISTRY: dict[str, tuple[str, str, bool]] = {
    "potx": ("tokenmoulds.emitters.powerpoint", "PowerPointEmitter", True),
    "dotx": ("tokenmoulds.emitters.word", "WordDocumentEmitter", True),
    "xltx": ("tokenmoulds.emitters.excel", "ExcelEmitter", False),
    "otp": ("tokenmoulds.emitters.odf", "ImpressTemplateEmitter", False),
    "ott": ("tokenmoulds.emitters.odf", "WriterTemplateEmitter", False),
    "ots": ("tokenmoulds.emitters.odf", "CalcTemplateEmitter", False),
    "odg": ("tokenmoulds.emitters.odf", "DrawTemplateEmitter", False),
    "gdocs": ("tokenmoulds.emitters.google_docs", "GoogleDocsEmitter", True),
    "gdoc": ("tokenmoulds.emitters.google_docs", "GoogleDocsDocumentEmitter", False),
}


def _get_emitter_class(fmt: str):
    """Lazy-import and return the emitter class for a format."""
    import importlib

    if fmt not in _EMITTER_REGISTRY:
        raise ValueError(
            f"Unknown output format: {fmt!r}. "
            f"Available: {sorted(_EMITTER_REGISTRY.keys())}"
        )
    module_path, class_name, _ = _EMITTER_REGISTRY[fmt]
    module = importlib.import_module(module_path)
    return getattr(module, class_name)


# =============================================================================
# Token Resolution
# =============================================================================


def _resolve_tokens(config: BuildConfig, _depth: int = 0) -> dict:
    """Resolve tokens from whichever source is provided in config."""
    if config.repository is not None:
        if _depth > 0:
            raise ValueError("Recursive GitHub resolution not supported")

        import shutil

        from tokenmoulds.brand.github import GitHubSource, resolve_github_source
        from tokenmoulds.brand.manifest import manifest_to_build_config

        source = GitHubSource(
            repository=config.repository,
            ref=config.ref or "main",
            path=config.manifest_path or "brand-manifest.yaml",
        )
        manifest, tmp_dir = resolve_github_source(source)
        try:
            derived_config = manifest_to_build_config(manifest, tmp_dir)
            return _resolve_tokens(derived_config, _depth + 1)
        finally:
            shutil.rmtree(tmp_dir, ignore_errors=True)

    if config.token_payload is not None:
        return config.token_payload

    if config.brand_inputs is not None:
        return TokenGenerator().generate(config.brand_inputs)

    if config.layers_dir is not None or config.layers_manifest is not None:
        result = adapt_dtcg_layers(
            layers_dir=config.layers_dir,
            manifest_path=config.layers_manifest,
        )
        return result.payload

    if config.tokens_file is not None:
        token_file = parse_tokens(config.tokens_file)
        resolved, _resolutions, _warnings = resolve_references(token_file, strict=False)
        return convert_from_dtcg(resolved)

    raise ValueError(
        "BuildConfig must provide one of: token_payload, tokens_file, "
        "layers_dir/layers_manifest, or brand_inputs"
    )


# =============================================================================
# IR Construction (Path B — DesignResolutionEngine)
# =============================================================================




# =============================================================================
# Emission
# =============================================================================


def _create_style_resolver(tokens: dict, document_ir: DocumentIR):
    """Create a StyleResolver for Word formats."""
    try:
        from tokenmoulds.styles.factory import create_style_resolver_from_tokens

        body_color = document_ir.body_style.color
        heading_color = body_color
        if document_ir.heading_styles:
            heading_color = document_ir.heading_styles[0].color

        return create_style_resolver_from_tokens(
            tokens, body_color=body_color, heading_color=heading_color
        )
    except Exception as exc:
        logger.debug("StyleResolver creation failed: %s", exc)
        return None


def _emit_format(
    fmt: str,
    document_ir: DocumentIR,
    tokens: dict,
    config: BuildConfig,
) -> bytes:
    """Emit a single format and return raw bytes."""
    emitter_cls = _get_emitter_class(fmt)
    _, _, supports_fonts = _EMITTER_REGISTRY[fmt]

    kwargs: dict[str, Any] = {}
    if config.template_root is not None:
        kwargs["template_root"] = str(config.template_root)

    if supports_fonts:
        kwargs["embed_fonts"] = config.embed_fonts
        if config.fonts_dir:
            kwargs["fonts_dir"] = config.fonts_dir

    # Word formats need a StyleResolver
    if fmt in ("dotx", "ott"):
        resolver = _create_style_resolver(tokens, document_ir)
        if resolver is not None:
            kwargs["style_resolver"] = resolver

    if fmt in ("potx", "pptx"):
        from tokenmoulds.archetypes.catalog import CONSULTING_FAMILY, GENERAL_FAMILY

        kwargs["layout_families"] = [CONSULTING_FAMILY, GENERAL_FAMILY]

    emitter = emitter_cls(document_ir, **kwargs)
    try:
        return emitter.build_package()
    except Exception:
        if "style_resolver" in kwargs:
            # Retry without StyleResolver if it caused the failure
            del kwargs["style_resolver"]
            emitter = emitter_cls(document_ir, **kwargs)
            return emitter.build_package()
        raise


# =============================================================================
# Validation
# =============================================================================


def _validate_artifact(fmt: str, data: bytes) -> list:
    """Validate a template artifact in-process. Returns list of issues."""
    try:
        from openxml_audit import FileFormat, OpenXmlValidator, ValidationSeverity

        ooxml_formats = {"potx", "dotx", "xltx", "thmx"}
        if fmt not in ooxml_formats:
            return []

        import tempfile

        with tempfile.NamedTemporaryFile(suffix=f".{fmt}", delete=False) as f:
            f.write(data)
            tmp_path = f.name

        try:
            validator = OpenXmlValidator(file_format=FileFormat.OFFICE_2019)
            result = validator.validate(tmp_path)
            return [
                {
                    "type": str(e.error_type),
                    "description": e.description,
                    "part": e.part_uri,
                    "path": e.path,
                    "severity": str(e.severity),
                }
                for e in result.errors
                if e.severity == ValidationSeverity.ERROR
            ]
        finally:
            Path(tmp_path).unlink(missing_ok=True)

    except ImportError:
        logger.debug("openxml_audit not available, skipping validation for %s", fmt)
        return []
    except Exception as exc:
        logger.warning("Validation failed for %s: %s", fmt, exc)
        return [{"type": "error", "description": str(exc)}]


# =============================================================================
# Main Build Function
# =============================================================================


def build(config: BuildConfig) -> BuildResult:
    """Execute the canonical build pipeline.

    Steps:
        1. Resolve tokens from whichever source is provided
        2. Build DocumentIR via DesignResolutionEngine (Path B)
        3. For each output format: emit → validate
        4. Return BuildResult with all artifacts

    All entrypoints (CLI, MCP, GitHub workflows) should call this
    function instead of implementing their own build flow.
    """
    start = time.monotonic()
    build_timestamp = _datetime.now(timezone.utc).isoformat()

    try:
        # Step 0: License check (optional — free tier works without)
        if config.license_id:
            try:
                from tokenmoulds.licensing import (
                    LicenseValidationError,
                    resolve_license_context,
                )
                from tokenmoulds.licensing.client import LicenseValidator
            except ImportError as exc:
                return BuildResult(
                    success=False,
                    error=f"Licensing module not available: {exc}",
                    timing_ms=(time.monotonic() - start) * 1000,
                )
            try:
                license_ctx = resolve_license_context(
                    license_id=config.license_id,
                    license_repo=config.license_repo,
                )
                license_result = LicenseValidator().validate(license_ctx)
                logger.info(
                    "License validated",
                    license_id=license_result.license_id,
                    plan=license_result.plan,
                )
            except LicenseValidationError as exc:
                return BuildResult(
                    success=False,
                    error=f"License validation failed: {exc}",
                    timing_ms=(time.monotonic() - start) * 1000,
                )

        # Step 1: Resolve tokens
        tokens = _resolve_tokens(config)

        # Step 2: Build IR via Path B (DesignResolutionEngine)
        document_ir = _build_document_ir(tokens, config)
        semantic_provenance: tuple[SemanticProvenance, ...] = ()
        if config.emit_semantic_provenance:
            semantic_provenance = collect_header_footer_semantic_provenance(
                tokens,
                header_footer_registry=document_ir.header_footer_registry,
                org_id=config.org_id,
            )

        # Step 3: Emit each format
        artifacts: dict[str, bytes] = {}
        validation_results: dict[str, list] = {}

        for fmt in config.output_formats:
            try:
                data = _emit_format(fmt, document_ir, tokens, config)
                artifacts[fmt] = data

                # Step 4: Validate if requested
                if config.validate:
                    issues = _validate_artifact(fmt, data)
                    if issues:
                        validation_results[fmt] = issues
            except Exception as exc:
                logger.error("Failed to emit %s: %s", fmt, exc)
                return BuildResult(
                    success=False,
                    error=f"Emission failed for {fmt}: {exc}",
                    document_ir=document_ir,
                    token_payload=tokens,
                    semantic_provenance=semantic_provenance,
                    timing_ms=(time.monotonic() - start) * 1000,
                )

        elapsed = round((time.monotonic() - start) * 1000, 1)

        provenance = BuildProvenance(
            org_id=config.org_id,
            timestamp=build_timestamp,
            token_source=config.token_source_label(),
            output_formats=list(config.output_formats),
            pipeline_version=_PIPELINE_VERSION,
            timing_ms=elapsed,
        )

        return BuildResult(
            success=True,
            artifacts=artifacts,
            validation_results=validation_results,
            document_ir=document_ir,
            token_payload=tokens,
            provenance=provenance,
            semantic_provenance=semantic_provenance,
            timing_ms=elapsed,
        )

    except Exception as exc:
        logger.error("Build pipeline failed: %s", exc, exc_info=True)
        return BuildResult(
            success=False,
            error=str(exc),
            timing_ms=(time.monotonic() - start) * 1000,
        )


# =============================================================================
# Batch Build
# =============================================================================

def build_batch(config: BuildBatchConfig) -> list[BuildResult]:
    """Build multiple brands with parallel execution.

    Args:
        config: Batch configuration with list of brand configs.

    Returns:
        List of BuildResult, one per brand, in the same order as input.
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed

    results: dict[int, BuildResult] = {}

    def _build_one(idx: int, brand_config: BuildConfig) -> tuple[int, BuildResult]:
        result = build(brand_config)
        if config.progress_callback:
            config.progress_callback(brand_config.org_id, result)
        return idx, result

    with ThreadPoolExecutor(max_workers=config.max_concurrency) as pool:
        futures = {
            pool.submit(_build_one, i, bc): i for i, bc in enumerate(config.brands)
        }
        for future in as_completed(futures):
            idx, result = future.result()
            results[idx] = result

    return [results[i] for i in range(len(config.brands))]
