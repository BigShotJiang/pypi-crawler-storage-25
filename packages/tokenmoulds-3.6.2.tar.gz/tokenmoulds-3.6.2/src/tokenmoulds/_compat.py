"""Shared compatibility utilities and optional dependency flags.

Centralises try/except imports so each module can do::

    from tokenmoulds._compat import httpx, HAS_HTTPX
    from tokenmoulds._compat import HAS_SVG2OOXML
"""

from __future__ import annotations


def strip_hex(color: str) -> str:
    """Strip ``#`` prefix and uppercase a hex color string."""
    return color.lstrip("#").upper()


try:
    import httpx

    HAS_HTTPX = True
except ImportError:
    httpx = None  # type: ignore[assignment]
    HAS_HTTPX = False

try:
    from svg2ooxml.public import SVGParser  # noqa: F401

    HAS_SVG2OOXML = True
except ImportError:
    HAS_SVG2OOXML = False
