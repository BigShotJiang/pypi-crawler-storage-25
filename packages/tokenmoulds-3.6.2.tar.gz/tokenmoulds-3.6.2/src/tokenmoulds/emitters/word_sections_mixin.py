"""Word emitter mixin for settings, document layout, and numbering customization."""

from __future__ import annotations

from typing import TYPE_CHECKING

from lxml import etree

from tokenmoulds.emitters.ooxml_base import EmbeddedFont
from tokenmoulds.emitters.word_headers import HeaderFooterBundle, HeaderFooterEmitter
from tokenmoulds.emitters.word_sect_pr import build_sect_pr
from tokenmoulds.emitters.word_sections_layout_mixin import WordSectionsLayoutMixin
from tokenmoulds.emitters.word_sections_packaging_mixin import (
    WordSectionsPackagingMixin,
)
from tokenmoulds.emitters.word_shared import NSMAP, W
from tokenmoulds.emitters.xml_helpers import (
    clone_template_element,
    remove_template_elements,
    replace_placeholders,
)
from tokenmoulds.ir import (
    DocumentIR,
    DocumentSettings,
)

if TYPE_CHECKING:
    from tokenmoulds.emitters import TemplateResolver


_HEADER_CONTENT_TYPE = (
    "application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml"
)
_FOOTER_CONTENT_TYPE = (
    "application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"
)
_HEADER_REL_TYPE = (
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/header"
)
_FOOTER_REL_TYPE = (
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer"
)


class WordSectionsMixin(WordSectionsLayoutMixin, WordSectionsPackagingMixin):
    # Declare attributes provided by the host class (OOXMLBaseEmitter / WordDocumentEmitter)
    document: DocumentIR
    allow_opentype_features: bool
    templates: "TemplateResolver"
    embed_fonts: bool
    embedded_fonts: list[EmbeddedFont]
    _long_form_bundle_cache: HeaderFooterBundle | None

    def _get_document_title(self) -> str:  # provided by host emitter class
        raise NotImplementedError

    def _customize_settings(self, data: bytes) -> bytes:
        """Customize settings.xml with document-wide typography settings.

        SSOT: The template already contains all settings elements. This method
        only modifies attribute values.
        """
        root = etree.fromstring(data)
        settings = self.document.document_settings

        self._apply_hyphenation_settings_ssot(root, settings)
        self._apply_tab_settings_ssot(root, settings)
        self._apply_compatibility_settings_ssot(root, settings)
        self._apply_even_odd_headers_ssot(root)

        return etree.tostring(root, xml_declaration=True, encoding="UTF-8")

    def _get_long_form_bundle(self) -> HeaderFooterBundle | None:
        """Lazily build the long-form header/footer bundle, cached per emit.

        Returns None when the document has no long-form sections.  The
        bundle carries its own rId maps — the emitter doesn't track any
        extra state.
        """
        if self._long_form_bundle_cache is not None:
            return self._long_form_bundle_cache
        if not self.document.long_form_sections:
            return None
        emitter = HeaderFooterEmitter(document_title=self._get_document_title())
        self._long_form_bundle_cache = emitter.build_packaged_entries(
            self.document.long_form_sections
        )
        return self._long_form_bundle_cache

    def _apply_even_odd_headers_ssot(self, root: etree._Element) -> None:
        """Emit ``<w:evenAndOddHeaders/>`` when any long-form section uses it.

        Word requires this toggle in settings.xml for even-page headers and
        footers to render; without it, the ``type="even"`` references on
        ``w:sectPr`` are silently ignored.
        """
        if not any(s.odd_even_different for s in self.document.long_form_sections):
            return
        if root.find("w:evenAndOddHeaders", NSMAP) is not None:
            return
        # ECMA-376 CT_Settings has a strict child order.  ``evenAndOddHeaders``
        # sits at schema position ~47, after ``doNotHyphenateCaps`` (43) and
        # before ``characterSpacingControl`` (57).  Find the first successor
        # that exists in the template and insert before it.
        element = etree.Element(f"{W}evenAndOddHeaders")
        for successor_name in (
            "w:characterSpacingControl",
            "w:compat",
            "w:themeFontLang",
            "w:clrSchemeMapping",
        ):
            successor = root.find(successor_name, NSMAP)
            if successor is not None:
                successor.addprevious(element)
                return
        root.append(element)

    def _apply_hyphenation_settings_ssot(
        self, root: etree._Element, settings: DocumentSettings
    ) -> None:
        """Apply hyphenation settings to settings.xml.

        SSOT: The template already has hyphenation elements. Only modify values.
        """
        # Auto hyphenation - template has <w:autoHyphenation w:val="1"/>
        auto_hyph = root.find("w:autoHyphenation", NSMAP)
        if auto_hyph is not None:
            auto_hyph.set(f"{W}val", "1" if settings.auto_hyphenation else "0")

        # Hyphenation zone - template has <w:hyphenationZone w:val="360"/>
        hyph_zone = root.find("w:hyphenationZone", NSMAP)
        if hyph_zone is not None:
            hyph_zone.set(f"{W}val", str(settings.hyphenation_zone_twips))

        # Consecutive hyphen limit - template has <w:consecutiveHyphenLimit w:val="0"/>
        consec = root.find("w:consecutiveHyphenLimit", NSMAP)
        if consec is not None:
            consec.set(f"{W}val", str(settings.consecutive_hyphen_limit))

        # Don't hyphenate caps - template has <w:doNotHyphenateCaps w:val="1"/>
        no_caps = root.find("w:doNotHyphenateCaps", NSMAP)
        if no_caps is not None:
            no_caps.set(f"{W}val", "1" if not settings.hyphenate_caps else "0")

    def _apply_tab_settings_ssot(
        self, root: etree._Element, settings: DocumentSettings
    ) -> None:
        """Apply default tab stop setting.

        SSOT: The template already has <w:defaultTabStop w:val="540"/>.
        """
        tab_stop = root.find("w:defaultTabStop", NSMAP)
        if tab_stop is not None:
            tab_stop.set(f"{W}val", str(settings.default_tab_stop_twips))

    def _apply_compatibility_settings_ssot(
        self, root: etree._Element, settings: DocumentSettings
    ) -> None:
        """Apply compatibility settings.

        SSOT: The template already has compat/compatSetting elements.
        """
        compat = root.find("w:compat", NSMAP)
        if compat is None:
            return

        # Find and update the enableOpenTypeFeatures setting
        for cs in compat.findall("w:compatSetting", NSMAP):
            if cs.get(f"{W}name") == "enableOpenTypeFeatures":
                # Update existing element's value
                if self.allow_opentype_features and settings.enable_opentype_features:
                    cs.set(f"{W}val", "1")
                else:
                    cs.set(f"{W}val", "0")
                break

    # =========================================================================
    # DOCUMENT.XML - Content and Layout
    # =========================================================================

    def _customize_document(self, data: bytes) -> bytes:
        """Customize document.xml with sample content and layout."""
        root = etree.fromstring(data)

        # Add sample content to demonstrate the template
        self._add_sample_content(root)

        # Apply section properties (margins, columns, grid)
        self._apply_section_properties(root)

        # Strip any remaining data-template markers and elements with
        # unresolved ${...} placeholders (e.g., table template rows)
        import re

        _PLACEHOLDER_RE = re.compile(r"\$\{[^}]+\}")
        for el in list(root.iter()):
            if "data-template" in el.attrib:
                parent = el.getparent()
                if parent is not None:
                    parent.remove(el)
                    continue
            # Remove elements with placeholder attribute values
            for attr_val in el.attrib.values():
                if isinstance(attr_val, bytes):
                    attr_val = attr_val.decode("utf-8", errors="ignore")
                if _PLACEHOLDER_RE.search(attr_val):
                    parent = el.getparent()
                    if parent is not None:
                        parent.remove(el)
                    break

        return etree.tostring(root, xml_declaration=True, encoding="UTF-8")

    def _add_sample_content(self, root: etree._Element) -> None:
        """Add sample content to document body for template preview.

        Long-form documents get their content from
        :meth:`_apply_long_form_sections`, which builds one heading + body
        paragraph per section so each section anchors on real content.
        """
        body = root.find(".//w:body", NSMAP)
        if body is None:
            return

        # Remove any existing sample paragraphs; sectPr stays.
        sect_pr = body.find("w:sectPr", NSMAP)
        for p in body.findall("w:p", NSMAP):
            body.remove(p)

        # Long-form path fills the body itself with per-section content.
        if self.document.long_form_sections:
            if sect_pr is not None:
                body.remove(sect_pr)
                body.append(sect_pr)
            return

        # Short-form path: one heading + one body paragraph.
        ssot_template = self.templates.read_tree("document.xml")

        heading_el = clone_template_element(ssot_template, "paragraph_heading")
        replace_placeholders(
            heading_el,
            {
                "STYLE_ID": "Heading1",
                "TEXT": f"{self.document.org_id} Template",
                "OUTLINE_LEVEL": "0",
                "BOOKMARK_ID": "1",
            },
        )
        remove_template_elements(heading_el)
        body.insert(0, heading_el)

        body_el = clone_template_element(ssot_template, "paragraph_body")
        replace_placeholders(
            body_el,
            {
                "STYLE_ID": "BodyText",
                "TEXT": "TokenMoulds Document IR powers this body copy.",
            },
        )
        remove_template_elements(body_el)
        body.insert(1, body_el)

        if sect_pr is not None:
            body.remove(sect_pr)
            body.append(sect_pr)

    def _apply_section_properties(self, root: etree._Element) -> None:
        """Apply section properties (page size, margins, columns, grid).

        When ``DocumentIR.long_form_sections`` is non-empty, the new long-form
        sectPr builder drives the body's sectPr tree — one intermediate
        section-break paragraph per section except the last, plus a final
        ``w:sectPr`` for the last section, each wired to header/footer
        relationships allocated by :meth:`_get_long_form_bundle`.

        Otherwise, when ``DocumentIR.sections`` is non-empty, intermediate
        sections are inserted as section-break paragraphs before the body's
        final ``w:sectPr`` using the legacy SectionSettings path.

        When both are empty the top-level ``page_geometry``,
        ``section_columns``, and ``document_grid`` are applied to the
        single final section as before.
        """
        body = root.find(".//w:body", NSMAP)
        if body is None:
            return
        final_sect_pr = body.find("w:sectPr", NSMAP)
        if final_sect_pr is None:
            return

        if self.document.long_form_sections:
            self._apply_long_form_sections(body, final_sect_pr)
            return

        sections = self.document.sections

        if sections:
            # Multi-section: insert intermediate section breaks
            ssot_template = self.templates.read_tree("document.xml")

            # All sections except the last produce a section-break paragraph
            for section in sections[:-1]:
                self._insert_section_break(body, final_sect_pr, ssot_template, section)

            # Last section drives the final w:sectPr
            last = sections[-1]
            self._apply_section_settings_to_sect_pr(
                final_sect_pr,
                page_geometry=last.page_geometry or self.document.page_geometry,
                columns=last.columns or self.document.section_columns,
                grid=last.grid or self.document.document_grid,
            )
        else:
            # Single section — use top-level settings
            self._apply_section_settings_to_sect_pr(
                final_sect_pr,
                page_geometry=self.document.page_geometry,
                columns=self.document.section_columns,
                grid=self.document.document_grid,
            )

    def _apply_long_form_sections(
        self,
        body: etree._Element,
        final_sect_pr: etree._Element,
    ) -> None:
        """Wire long-form sections into the body with per-section content.

        Each section gets a heading + body paragraph.  Intermediate
        sections attach their ``w:sectPr`` to the body paragraph's
        ``pPr`` — the default ``w:type="nextPage"`` break forces the
        next section to start on a fresh physical page.  The final
        section's content is followed by the body-level ``w:sectPr``.
        """
        bundle = self._get_long_form_bundle()
        if bundle is None:
            return

        sections = self.document.long_form_sections
        document_has_odd_even = any(s.odd_even_different for s in sections)

        ssot_template = self.templates.read_tree("document.xml")
        # Resolve the two template paragraphs once; the loop deep-copies
        # them instead of walking the document.xml tree every iteration.
        heading_tmpl = self._find_template_paragraph(ssot_template, "paragraph_heading")
        body_tmpl = self._find_template_paragraph(ssot_template, "paragraph_body")

        insert_index = list(body).index(final_sect_pr)
        for index, section in enumerate(sections):
            heading_el, body_el = self._build_section_paragraphs(
                section,
                index,
                heading_tmpl=heading_tmpl,
                body_tmpl=body_tmpl,
            )
            is_final = index == len(sections) - 1
            if not is_final:
                self._attach_section_pr(
                    body_el,
                    section,
                    bundle=bundle,
                    document_has_odd_even=document_has_odd_even,
                )
            body.insert(insert_index, heading_el)
            insert_index += 1
            body.insert(insert_index, body_el)
            insert_index += 1

        new_final = build_sect_pr(
            sections[-1],
            header_rid_map=bundle.header_rid_map,
            footer_rid_map=bundle.footer_rid_map,
            document_has_odd_even=document_has_odd_even,
        )
        parent = final_sect_pr.getparent()
        if parent is not None:
            parent.replace(final_sect_pr, new_final)
