"""Package-level PowerPoint emitter customizations."""

from __future__ import annotations

import logging
from copy import deepcopy
from typing import Dict, List

from lxml import etree

logger = logging.getLogger(__name__)

from tokenmoulds.emitters.ooxml_base import EmbeddedFont
from tokenmoulds.emitters.xml_helpers import (
    clone_template_element,
    remove_template_elements,
    replace_placeholders,
)

PRESENTATIONML_NS = "http://schemas.openxmlformats.org/presentationml/2006/main"
PACKAGE_REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"
SLIDE_LAYOUT_REL_TYPE = (
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout"
)
THEME_REL_TYPE = (
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme"
)
STANDARD_LAYOUT_NUMBER_BY_NAME = {
    "title_slide": 1,
    "title_content": 2,
    "section_header": 3,
    "two_content": 4,
    "comparison": 5,
    "title_only": 6,
    "blank": 7,
    "content_caption": 8,
    "picture_caption": 9,
    "vertical_text": 10,
    "vertical_title": 11,
}
IMAGE_REL_TYPE = (
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image"
)


class PowerPointPackageMixin:
    def _customize_content_types_ssot(self, data: bytes) -> bytes:
        """Customize [Content_Types].xml by appending proper XML elements."""
        from lxml import etree as ET

        CT_NS = "http://schemas.openxmlformats.org/package/2006/content-types"
        root = self.templates.read_tree("ssot/content_types.xml")

        # Swap content type for .pptx output
        if self._output_format == "pptx":
            for override in root.findall(f"{{{CT_NS}}}Override"):
                ct = override.get("ContentType", "")
                if "template.main+xml" in ct:
                    override.set(
                        "ContentType",
                        ct.replace("template.main+xml", "presentation.main+xml"),
                    )

        # Remove placeholder text if present (may be in text or tail)
        for elem in root.iter():
            if elem.text and "${EXTRA_CONTENT_TYPES}" in elem.text:
                elem.text = (
                    elem.text.replace("${EXTRA_CONTENT_TYPES}", "").strip() or None
                )
            if elem.tail and "${EXTRA_CONTENT_TYPES}" in elem.tail:
                elem.tail = (
                    elem.tail.replace("${EXTRA_CONTENT_TYPES}", "").strip() or None
                )

        # Append slide layout content types as proper elements
        for layout_number in self.DEFAULT_SLIDE_LAYOUT_NUMBERS[1:]:
            override = ET.SubElement(root, f"{{{CT_NS}}}Override")
            override.set(
                "PartName",
                f"/ppt/slideLayouts/slideLayout{layout_number}.xml",
            )
            override.set(
                "ContentType",
                "application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml",
            )

        # Append media content types
        existing_defaults = {
            default.get("Extension")
            for default in root.findall(f"{{{CT_NS}}}Default")
            if default.get("Extension")
        }
        for asset in self._slide_media_assets:
            extension = asset.archive_path.rsplit(".", 1)[-1].lower()
            if extension in existing_defaults:
                continue
            default = ET.SubElement(root, f"{{{CT_NS}}}Default")
            default.set("Extension", extension)
            default.set("ContentType", asset.content_type)
            existing_defaults.add(extension)

        # Append font content type if embedding
        if self.embed_fonts and self.embedded_fonts:
            default = ET.SubElement(root, f"{{{CT_NS}}}Default")
            default.set("Extension", "fntdata")
            default.set("ContentType", "application/x-fontdata")

        from tokenmoulds.emitters.xml_helpers_template import serialize_tree

        return serialize_tree(root)

    def _customize_presentation_ssot(self, data: bytes) -> bytes:
        """Customize ppt/presentation.xml via SSOT clone pattern.

        Uses the SSOT pattern: presentation.xml contains example elements with
        data-template markers. We clone these examples for dynamic content,
        then remove the original templates.
        """
        # PresentationML namespace
        P_NS = "http://schemas.openxmlformats.org/presentationml/2006/main"
        R_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"

        # Load the presentation template (contains example font elements)
        root = self.templates.read_tree("ssot/presentation.xml")
        slide_width, slide_height = self._get_slide_dimensions_emu()
        replace_placeholders(
            root,
            {
                "SLIDE_WIDTH": str(slide_width),
                "SLIDE_HEIGHT": str(slide_height),
            },
        )

        # Populate slide master ID list (required for valid PPTX)
        # Clone the template element and set proper values
        sld_master_lst = root.find(f"{{{P_NS}}}sldMasterIdLst")
        if sld_master_lst is not None:
            master_clone = clone_template_element(root, "sld_master_id")
            if master_clone is not None:
                master_clone.set("id", "2147483648")  # Standard starting ID
                master_clone.set(f"{{{R_NS}}}id", "rId1")
                sld_master_lst.append(master_clone)

        # Populate slide ID list (required for valid PPTX)
        sld_id_lst = root.find(f"{{{P_NS}}}sldIdLst")
        if sld_id_lst is not None:
            slide_clone = clone_template_element(root, "sld_id")
            if slide_clone is not None:
                slide_clone.set("id", "256")  # Standard starting ID for slides
                slide_clone.set(f"{{{R_NS}}}id", "rId2")
                sld_id_lst.append(slide_clone)

        # Remove optional empty lists (notes master, handout master, custom shows)
        for list_name in ["notesMasterIdLst", "handoutMasterIdLst", "custShowLst"]:
            lst_el = root.find(f"{{{P_NS}}}{list_name}")
            if lst_el is not None:
                # Remove if empty (only has template children that will be removed)
                has_non_template_children = any(
                    "data-template" not in child.attrib for child in lst_el
                )
                if not has_non_template_children:
                    root.remove(lst_el)

        # Remove optional elements that have unresolved placeholders
        for el_name in ["smartTags", "photoAlbum", "kinsoku", "custDataLst"]:
            el = root.find(f"{{{P_NS}}}{el_name}")
            if el is not None:
                root.remove(el)

        # Build embedded font list using clone pattern
        if self.embed_fonts and self.embedded_fonts:
            self._build_embedded_fonts_from_template(root)
        else:
            # No fonts to embed - remove the entire embeddedFontLst element
            font_lst = root.find(f"{{{P_NS}}}embeddedFontLst")
            if font_lst is not None:
                root.remove(font_lst)

        # Remove all template example elements from final output
        remove_template_elements(root)

        return self._serialize_tree(root)

    def _build_embedded_fonts_from_template(self, root: etree._Element) -> None:
        """Build embeddedFontLst using SSOT clone pattern.

        Clones example elements from the template to create font entries.
        """
        # PresentationML namespace
        P_NS = "http://schemas.openxmlformats.org/presentationml/2006/main"

        # Find the embeddedFontLst element
        font_lst = root.find(f"{{{P_NS}}}embeddedFontLst")
        if font_lst is None:
            return

        # Remove data-template attribute from the list itself (we keep it)
        if "data-template" in font_lst.attrib:
            del font_lst.attrib["data-template"]

        # Group fonts by family name
        fonts_by_family: Dict[str, List[EmbeddedFont]] = {}
        for font in self.embedded_fonts:
            if font.family_name not in fonts_by_family:
                fonts_by_family[font.family_name] = []
            fonts_by_family[font.family_name].append(font)

        # Clone embedded font entries for each family
        for family_name, fonts in fonts_by_family.items():
            # Clone the embedded font template
            embed_clone = clone_template_element(root, "embedded_font")

            # Set font metadata
            font_el = embed_clone.find(f"{{{P_NS}}}font")
            if font_el is not None:
                font_el.set("typeface", family_name)
                font_el.set("panose", "020B0604020202020204")  # Generic sans-serif
                font_el.set("pitchFamily", "34")  # Variable pitch, Swiss
                font_el.set("charset", "0")  # ANSI

            # Remove template style reference children (we'll add the ones we need)
            for child in list(embed_clone):
                if child.get("data-template") in (
                    "regular",
                    "bold",
                    "italic",
                    "bold_italic",
                ):
                    embed_clone.remove(child)

            # Add font style references for each font variant
            for font in fonts:
                if font.is_bold and font.is_italic:
                    ref_clone = clone_template_element(root, "bold_italic")
                elif font.is_bold:
                    ref_clone = clone_template_element(root, "bold")
                elif font.is_italic:
                    ref_clone = clone_template_element(root, "italic")
                else:
                    ref_clone = clone_template_element(root, "regular")

                replace_placeholders(ref_clone, {"REL_ID": font.relationship_id})
                embed_clone.append(ref_clone)

            font_lst.append(embed_clone)

    def _customize_presentation_rels_ssot(self, data: bytes) -> bytes:
        """Customize ppt/_rels/presentation.xml.rels via SSOT clone pattern."""
        # Load the relationships template
        root = self.templates.read_tree("ssot/presentation_rels.xml")

        # Clone and add font relationships
        if self.embed_fonts and self.embedded_fonts:
            for font in self.embedded_fonts:
                rel_clone = clone_template_element(root, "font_relationship")
                replace_placeholders(
                    rel_clone,
                    {
                        "REL_ID": font.relationship_id,
                        "FILENAME": font.fntdata_filename,
                    },
                )
                root.append(rel_clone)

        # Remove template elements
        remove_template_elements(root)

        return self._serialize_tree(root)

    def _customize_slide_master_rels_ssot(self, data: bytes) -> bytes:
        """Customize the slide master relationships for the full layout set."""
        root = self.templates.read_tree("ssot/slide_master_rels.xml")
        template_relationships = root.findall(f"{{{PACKAGE_REL_NS}}}Relationship")
        layout_template = next(
            rel
            for rel in template_relationships
            if rel.get("Type") == SLIDE_LAYOUT_REL_TYPE
        )
        theme_relationship = next(
            rel for rel in template_relationships if rel.get("Type") == THEME_REL_TYPE
        )

        for rel in template_relationships:
            root.remove(rel)

        for rel_index, layout_number in enumerate(
            self.DEFAULT_SLIDE_LAYOUT_NUMBERS, start=1
        ):
            layout_relationship = deepcopy(layout_template)
            layout_relationship.set("Id", f"rId{rel_index}")
            layout_relationship.set(
                "Target", f"../slideLayouts/slideLayout{layout_number}.xml"
            )
            root.append(layout_relationship)

        theme_rel_id = len(self.DEFAULT_SLIDE_LAYOUT_NUMBERS) + 1
        theme_relationship = deepcopy(theme_relationship)
        theme_relationship.set("Id", f"rId{theme_rel_id}")
        root.append(theme_relationship)

        return self._serialize_tree(root)

    def _customize_theme_ssot(self, data: bytes) -> bytes:
        """Customize theme via lxml DOM manipulation with cached template.

        Uses read_tree() for cached parsing, then applies color and font
        schemes via XPath.
        """
        root = self.templates.read_tree("ssot/theme.xml")
        theme = self.document.color_theme
        typo = self.document.typography

        # Use pure black/white for dk1/lt1 if configured
        if self.use_pure_text_colors:
            self._set_color_value(root, "dk1", "000000")
            self._set_color_value(root, "lt1", "FFFFFF")
        else:
            self._set_color_value(root, "dk1", theme.dk1)
            self._set_color_value(root, "lt1", theme.lt1)

        # Set accent colors
        self._set_color_value(root, "dk2", theme.dk2)
        self._set_color_value(root, "lt2", theme.lt2)
        self._set_color_value(root, "accent1", theme.accent1)
        self._set_color_value(root, "accent2", theme.accent2)
        self._set_color_value(root, "accent3", theme.accent3)
        self._set_color_value(root, "accent4", theme.accent4)
        self._set_color_value(root, "accent5", theme.accent5)
        self._set_color_value(root, "accent6", theme.accent6)
        self._set_color_value(root, "hlink", theme.hyperlink)
        self._set_color_value(root, "folHlink", theme.hyperlink_followed)

        # Set font schemes
        self._set_font_typeface(root, "majorFont", "latin", typo.heading_font)
        self._set_font_typeface(root, "minorFont", "latin", typo.body_font)

        # Add extra color schemes if provided
        if self.extra_color_themes:
            self._add_extra_color_schemes(root)
            logger.info(f"Added {len(self.extra_color_themes)} extra color themes")

        # Remove template markers from final output
        remove_template_elements(root)

        return self._serialize_tree(root)
