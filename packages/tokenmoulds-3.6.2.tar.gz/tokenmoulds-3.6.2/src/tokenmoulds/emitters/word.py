"""Word document emitter that renders the Document IR into a DOTX template.

SSOT Architecture:
==================
All XML structure comes from xml-structures/ecma-376/wordprocessingml/ as the
Single Source of Truth. The emitter loads templates and modifies attribute
values - it never constructs new XML elements programmatically.

For dynamic content (e.g., paragraphs, font entries), template fragments are
loaded, values substituted, parsed, and inserted into the document.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Dict, Literal


from tokenmoulds.emitters.ooxml_base import OOXMLBaseEmitter
from tokenmoulds.emitters.word_sections_mixin import WordSectionsMixin
from tokenmoulds.emitters.word_styles_mixin import WordStyleMixin
from tokenmoulds.ir import (
    DocumentIR,
)
from tokenmoulds.styles.resolver import StyleResolver

logger = logging.getLogger(__name__)


# =============================================================================
# WORD DOCUMENT EMITTER
# =============================================================================


class WordDocumentEmitter(WordStyleMixin, WordSectionsMixin, OOXMLBaseEmitter):
    """Build Word templates from the canonical Document IR.

    Uses a known-good base template and modifies specific style values
    based on the Document IR, preserving Word-required internal structures.

    Inherits from OOXMLBaseEmitter which provides:
    - ZIP package building pattern
    - Font embedding infrastructure (ODTTF format)
    - Theme customization (color scheme, font scheme)
    - Core properties metadata

    Word-specific features:
    - Basic typography (fonts, sizes, colors, spacing)
    - Advanced typography (kerning, tracking; OpenType features suppressed for OOXML)
    - Paragraph control (justification, indentation, keep-with-next)
    - Document settings (hyphenation, tab stops)
    - Numbering definitions (bullets, numbered lists)
    """

    def __init__(
        self,
        document: DocumentIR,
        template_root: Path | str | None = None,
        embed_fonts: bool = False,
        fonts_dir: Path | str | None = None,
        style_resolver: StyleResolver | None = None,
        use_pure_text_colors: bool = True,
    ) -> None:
        super().__init__(
            document=document,
            template_root=template_root,
            embed_fonts=embed_fonts,
            fonts_dir=fonts_dir,
            use_pure_text_colors=use_pure_text_colors,
        )
        self.style_resolver = style_resolver
        self.allow_opentype_features = True
        self._long_form_bundle_cache = None

    # =========================================================================
    # SSOT PACKAGE STRUCTURE
    # =========================================================================

    # Word package structure: archive path -> template name
    PACKAGE_STRUCTURE = {
        "[Content_Types].xml": "content_types.xml",
        "_rels/.rels": "package_rels.xml",
        "word/document.xml": "document.xml",
        "word/styles.xml": "styles.xml",
        "word/stylesWithEffects.xml": "styles.xml",
        "word/settings.xml": "settings.xml",
        "word/numbering.xml": "numbering.xml",
        "word/fontTable.xml": "fontTable.xml",
        "word/webSettings.xml": "webSettings.xml",
        "word/theme/theme1.xml": "theme.xml",
        "word/_rels/document.xml.rels": "document_rels.xml",
        "docProps/core.xml": "docprops_core.xml",
        "docProps/app.xml": "docprops_app.xml",
    }

    # =========================================================================
    # ABSTRACT METHOD IMPLEMENTATIONS (from OOXMLBaseEmitter)
    # =========================================================================

    def _get_format_key(self) -> str:
        """Return 'word' for template resolution."""
        return "word"

    def _get_package_structure(self) -> Dict[str, str]:
        """Return the Word package structure for SSOT building."""
        return self.PACKAGE_STRUCTURE

    def _get_document_title(self) -> str:
        """Return document title for metadata."""
        return f"{self.document.org_id} Template"

    def _get_font_embedding_format(self) -> Literal["odttf", "eot", "none"]:
        """Return 'odttf' - Word uses GUID-obfuscated fonts."""
        return "odttf"

    def _get_font_entries_path(self) -> str:
        """Return path prefix for embedded fonts."""
        return "word/fonts/"

    def _should_customize_entry(self, entry_path: str) -> bool:
        """Check if entry needs customization."""
        # All entries that need IR values applied
        customizable = {
            "[Content_Types].xml",
            "word/styles.xml",
            "word/stylesWithEffects.xml",
            "word/settings.xml",
            "word/theme/theme1.xml",
            "word/document.xml",
            "word/numbering.xml",
            "word/fontTable.xml",
            "word/_rels/document.xml.rels",
            "docProps/core.xml",
            "docProps/app.xml",
        }
        return entry_path in customizable

    def _customize_entry(self, entry_path: str, data: bytes) -> bytes | None:
        """Customize specific ZIP entry with Document IR values.

        For SSOT approach, this modifies attribute values in the template XML.
        Templates with ${PLACEHOLDER} syntax are substituted before parsing.
        """
        if entry_path == "[Content_Types].xml":
            return self._customize_content_types(data)
        elif entry_path in ("word/styles.xml", "word/stylesWithEffects.xml"):
            return self._customize_styles(data)
        elif entry_path == "word/settings.xml":
            return self._customize_settings(data)
        elif entry_path == "word/theme/theme1.xml":
            return self._customize_theme(data)
        elif entry_path == "word/document.xml":
            return self._customize_document(data)
        elif entry_path == "word/numbering.xml":
            return self._customize_numbering(data)
        elif entry_path == "word/fontTable.xml":
            return self._customize_font_table(data)
        elif entry_path == "word/_rels/document.xml.rels":
            return self._customize_document_rels(data)
        elif entry_path == "docProps/core.xml":
            return self._customize_core_props_ssot(data)
        elif entry_path == "docProps/app.xml":
            return self._customize_app_props_ssot(data)
        return data

    def _customize_core_props_ssot(self, data: bytes) -> bytes:
        """Customize core properties using SSOT template substitution."""
        timestamp = self._utc_timestamp()
        content = data.decode("utf-8")
        content = content.replace("${TITLE}", self._get_document_title())
        content = content.replace("${CREATOR}", "TokenMoulds")
        content = content.replace("${MODIFIER}", "TokenMoulds")
        content = content.replace("${TIMESTAMP}", timestamp)
        return content.encode("utf-8")

    def _customize_app_props_ssot(self, data: bytes) -> bytes:
        """Customize app properties using SSOT template substitution."""
        content = data.decode("utf-8")
        content = content.replace("${APPLICATION}", "TokenMoulds")
        content = content.replace("${COMPANY}", self.document.org_id)
        return content.encode("utf-8")

    def _get_font_metadata_entries(self) -> list:
        """Return Word font relationships as PackagedEntry list."""
        from tokenmoulds.packaging.types import PackagedEntry

        if self.embedded_fonts:
            rels_data = self._build_font_relationships()
            return [
                PackagedEntry(
                    archive_path="word/_rels/fontTable.xml.rels",
                    data=rels_data,
                )
            ]
        return []

    def _get_additional_packaged_entries(self):
        """Emit long-form header/footer PackagedEntries."""
        bundle = self._get_long_form_bundle()
        if bundle is None:
            return []
        return list(bundle.entries)

    # =========================================================================
    # STYLES.XML - Style Definitions (SSOT approach)
    # =========================================================================


    # =========================================================================
