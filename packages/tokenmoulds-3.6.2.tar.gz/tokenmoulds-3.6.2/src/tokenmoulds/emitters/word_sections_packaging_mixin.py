"""Packaging, font-table, and numbering helpers for Word sections."""

from __future__ import annotations

from typing import TYPE_CHECKING

from lxml import etree

from tokenmoulds.emitters.ooxml_base import EmbeddedFont
from tokenmoulds.emitters.word_headers import HeaderFooterBundle
from tokenmoulds.emitters.word_shared import NSMAP, W
from tokenmoulds.emitters.xml_helpers import (
    clone_template_element,
    remove_template_elements,
    replace_placeholders,
)
from tokenmoulds.ir import DocumentIR

if TYPE_CHECKING:
    from tokenmoulds.emitters import TemplateResolver

_HEADER_CONTENT_TYPE = (
    "application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml"
)
_FOOTER_CONTENT_TYPE = (
    "application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"
)
_HEADER_REL_TYPE = (
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/header"
)
_FOOTER_REL_TYPE = (
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer"
)


class WordSectionsPackagingMixin:
    document: DocumentIR
    templates: "TemplateResolver"
    embed_fonts: bool
    embedded_fonts: list[EmbeddedFont]
    _long_form_bundle_cache: HeaderFooterBundle | None

    def _customize_content_types(self, data: bytes) -> bytes:
        """Customize [Content_Types].xml."""
        # Change to template content type
        data = data.replace(
            b"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml",
            b"application/vnd.openxmlformats-officedocument.wordprocessingml.template.main+xml",
        )

        ns = "http://schemas.openxmlformats.org/package/2006/content-types"
        needs_parse = (self.embed_fonts and self.embedded_fonts) or bool(
            self.document.long_form_sections
        )
        if not needs_parse:
            return data

        root = etree.fromstring(data)

        # Add odttf content type if embedding fonts
        if self.embed_fonts and self.embedded_fonts:
            existing = root.find(f'.//{{{ns}}}Default[@Extension="odttf"]')
            if existing is None:
                default = etree.Element(f"{{{ns}}}Default")
                default.set("Extension", "odttf")
                default.set(
                    "ContentType",
                    "application/vnd.openxmlformats-officedocument.obfuscatedFont",
                )
                root.insert(0, default)

        bundle = self._get_long_form_bundle()
        if bundle is not None:
            existing_parts = {
                o.get("PartName") for o in root.findall(f"{{{ns}}}Override")
            }
            for entry in bundle.entries:
                part_name = "/" + entry.archive_path
                if part_name in existing_parts:
                    continue
                override = etree.SubElement(root, f"{{{ns}}}Override")
                override.set("PartName", part_name)
                override.set(
                    "ContentType",
                    _HEADER_CONTENT_TYPE
                    if "header" in entry.archive_path
                    else _FOOTER_CONTENT_TYPE,
                )

        return etree.tostring(root, xml_declaration=True, encoding="UTF-8")

    def _customize_document_rels(self, data: bytes) -> bytes:
        """Inject long-form header/footer relationships into document.xml.rels."""
        bundle = self._get_long_form_bundle()
        if bundle is None or not bundle.entries:
            return data

        ns = "http://schemas.openxmlformats.org/package/2006/relationships"
        root = etree.fromstring(data)
        existing_ids = {r.get("Id") for r in root.findall(f"{{{ns}}}Relationship")}

        def _add_rel(rid: str, rel_type: str, target: str) -> None:
            if rid in existing_ids:
                return
            rel = etree.SubElement(root, f"{{{ns}}}Relationship")
            rel.set("Id", rid)
            rel.set("Type", rel_type)
            rel.set("Target", target)

        for name, archive_path in bundle.header_part_for.items():
            _add_rel(
                bundle.header_rid_map[name],
                _HEADER_REL_TYPE,
                archive_path.removeprefix("word/"),
            )
        for name, archive_path in bundle.footer_part_for.items():
            _add_rel(
                bundle.footer_rid_map[name],
                _FOOTER_REL_TYPE,
                archive_path.removeprefix("word/"),
            )

        return etree.tostring(root, xml_declaration=True, encoding="UTF-8")

    def _customize_font_table(self, data: bytes) -> bytes:
        """Customize fontTable.xml with font names and embedded font references.

        Always substitutes ${HEADING_FONT} and ${BODY_FONT} placeholders.
        When fonts are embedded, clones template entries for each font.
        """
        # Always resolve font name placeholders
        context = {
            "HEADING_FONT": self.document.typography.heading_font,
            "BODY_FONT": self.document.typography.body_font,
        }
        root = etree.fromstring(data)
        replace_placeholders(root, context)

        if not self.embedded_fonts:
            # Strip any remaining data-template elements
            for el in list(root.iter()):
                if "data-template" in el.attrib:
                    parent = el.getparent()
                    if parent is not None:
                        parent.remove(el)
            return etree.tostring(root, xml_declaration=True, encoding="UTF-8")

        # Load SSOT template for cloning font entries and embed elements
        ssot_template = self.templates.read_tree("fontTable.xml")

        # Group embedded fonts by family
        fonts_by_family: dict[str, list[EmbeddedFont]] = {}
        for font in self.embedded_fonts:
            if font.family_name not in fonts_by_family:
                fonts_by_family[font.family_name] = []
            fonts_by_family[font.family_name].append(font)

        for family_name, fonts in fonts_by_family.items():
            # Find or create font element
            font_el = root.find(f'.//w:font[@w:name="{family_name}"]', NSMAP)
            if font_el is None:
                # Clone font entry from SSOT template
                font_el = clone_template_element(ssot_template, "font_entry")
                replace_placeholders(
                    font_el,
                    {
                        "FONT_NAME": family_name,
                        "FAMILY": "swiss",
                        "PITCH": "variable",
                        "CHARSET": "00",
                        "PANOSE": "00000000000000000000",
                        "USB0": "00000000",
                        "USB1": "00000000",
                        "USB2": "00000000",
                        "USB3": "00000000",
                        "CSB0": "00000000",
                        "CSB1": "00000000",
                    },
                )
                # Remove template embed elements (we'll add the ones we need)
                for child in list(font_el):
                    if child.get("data-template") in (
                        "embed_regular",
                        "embed_bold",
                        "embed_italic",
                        "embed_bold_italic",
                    ):
                        font_el.remove(child)
                # Also remove other template placeholder children
                for child in list(font_el):
                    if "data-template" in child.attrib:
                        font_el.remove(child)
                root.append(font_el)

            # Add embedded font references by cloning from SSOT template
            for font in fonts:
                if font.is_bold and font.is_italic:
                    embed_el = clone_template_element(
                        ssot_template, "embed_bold_italic"
                    )
                elif font.is_bold:
                    embed_el = clone_template_element(ssot_template, "embed_bold")
                elif font.is_italic:
                    embed_el = clone_template_element(ssot_template, "embed_italic")
                else:
                    embed_el = clone_template_element(ssot_template, "embed_regular")

                replace_placeholders(
                    embed_el,
                    {
                        "REL_ID": font.relationship_id,
                        "FONT_KEY": "{" + font.font_key + "}",
                        "SUBSETTED": "0",
                    },
                )
                font_el.append(embed_el)

        remove_template_elements(root)
        return etree.tostring(root, xml_declaration=True, encoding="UTF-8")

    def _build_font_relationships(self) -> bytes:
        """Build word/_rels/fontTable.xml.rels file.

        Uses SSOT clone pattern: loads font_table_rels.xml template with
        data-template markers, clones relationship entries for each font.
        """
        # Load SSOT template
        root = self.templates.read_tree("font_table_rels.xml")

        # Clone relationship for each embedded font
        for font in self.embedded_fonts:
            rel_clone = clone_template_element(root, "font_relationship")
            replace_placeholders(
                rel_clone,
                {
                    "REL_ID": font.relationship_id,
                    "FILENAME": font.odttf_filename,
                },
            )
            root.append(rel_clone)

        # Remove template elements
        remove_template_elements(root)

        return etree.tostring(root, xml_declaration=True, encoding="UTF-8")

    # =========================================================================
    # NUMBERING.XML - List Styles
    # =========================================================================

    def _customize_numbering(self, data: bytes) -> bytes:
        """Customize numbering.xml with typographically correct list styles.

        Implements best practices:
        - Hanging indent: bullet/number hangs, text aligns cleanly
        - Bullet character: small bullet (•), not heavy circle
        - Number alignment: right-align for proper digit alignment
        - Nested bullets: differentiated by character (•, –, ·)
        - Spacing: tighter between items than paragraphs
        """
        root = etree.fromstring(data)
        list_style = self.document.list_style

        if list_style is None:
            return data

        # Find or create abstract numbering definitions
        # abstractNumId 0 = bullet list, abstractNumId 1 = numbered list

        self._customize_bullet_list(root, list_style)
        self._customize_numbered_list(root, list_style)

        return etree.tostring(root, xml_declaration=True, encoding="UTF-8")

    def _customize_bullet_list(self, root: etree._Element, list_style) -> None:
        """Customize bullet list definition (abstractNumId typically 1)."""
        # Find bullet list abstract num (look for one with bullet format)
        for abstract_num in root.findall("w:abstractNum", NSMAP):
            # Check first level for bullet
            lvl = abstract_num.find('w:lvl[@w:ilvl="0"]', NSMAP)
            if lvl is not None:
                num_fmt = lvl.find("w:numFmt", NSMAP)
                if num_fmt is not None and num_fmt.get(f"{W}val") == "bullet":
                    self._apply_bullet_levels(abstract_num, list_style)
                    break

    def _customize_numbered_list(self, root: etree._Element, list_style) -> None:
        """Customize numbered list definition."""
        for abstract_num in root.findall("w:abstractNum", NSMAP):
            lvl = abstract_num.find('w:lvl[@w:ilvl="0"]', NSMAP)
            if lvl is not None:
                num_fmt = lvl.find("w:numFmt", NSMAP)
                if num_fmt is not None and num_fmt.get(f"{W}val") == "decimal":
                    self._apply_numbered_levels(abstract_num, list_style)
                    break

    def _apply_bullet_levels(self, abstract_num: etree._Element, list_style) -> None:
        """Apply bullet list styling to all levels."""
        bullet_chars = (
            list_style.nested_bullet_chars
            if hasattr(list_style, "nested_bullet_chars")
            else ("•", "–", "·")
        )

        for lvl in abstract_num.findall("w:lvl", NSMAP):
            ilvl = int(lvl.get(f"{W}ilvl", "0"))

            # Set bullet character based on level
            bullet_char = bullet_chars[min(ilvl, len(bullet_chars) - 1)]
            lvl_text = lvl.find("w:lvlText", NSMAP)
            if lvl_text is not None:
                lvl_text.set(f"{W}val", bullet_char)

            # Set bullet font
            rpr = lvl.find("w:rPr", NSMAP)
            if rpr is None:
                rpr = etree.SubElement(lvl, f"{W}rPr")
            rfonts = rpr.find("w:rFonts", NSMAP)
            if rfonts is None:
                rfonts = etree.SubElement(rpr, f"{W}rFonts")

            # Use Symbol font for bullet, or body font for dashes/dots
            bullet_font = (
                list_style.bullet_font
                if hasattr(list_style, "bullet_font")
                else "Symbol"
            )
            if bullet_char in ("–", "·", "-"):
                bullet_font = self.document.body_style.font_family
            rfonts.set(f"{W}ascii", bullet_font)
            rfonts.set(f"{W}hAnsi", bullet_font)

            # Apply indentation
            self._apply_list_indent(lvl, list_style, ilvl)

    def _apply_numbered_levels(self, abstract_num: etree._Element, list_style) -> None:
        """Apply numbered list styling to all levels."""
        for lvl in abstract_num.findall("w:lvl", NSMAP):
            ilvl = int(lvl.get(f"{W}ilvl", "0"))

            # Right-align numbers for proper digit alignment
            lvl_jc = lvl.find("w:lvlJc", NSMAP)
            if lvl_jc is None:
                lvl_jc = etree.SubElement(lvl, f"{W}lvlJc")

            number_alignment = (
                list_style.number_alignment
                if hasattr(list_style, "number_alignment")
                else "right"
            )
            lvl_jc.set(f"{W}val", number_alignment)

            # Use tabular figures if available (via run properties)
            rpr = lvl.find("w:rPr", NSMAP)
            if rpr is None:
                rpr = etree.SubElement(lvl, f"{W}rPr")

            # Set font to body font for consistent appearance
            rfonts = rpr.find("w:rFonts", NSMAP)
            if rfonts is None:
                rfonts = etree.SubElement(rpr, f"{W}rFonts")
            rfonts.set(f"{W}ascii", self.document.body_style.font_family)
            rfonts.set(f"{W}hAnsi", self.document.body_style.font_family)

            # Apply indentation
            self._apply_list_indent(lvl, list_style, ilvl)

    def _apply_list_indent(self, lvl: etree._Element, list_style, ilvl: int) -> None:
        """Apply proper indentation for list level."""
        ppr = lvl.find("w:pPr", NSMAP)
        if ppr is None:
            ppr = etree.SubElement(lvl, f"{W}pPr")

        ind = ppr.find("w:ind", NSMAP)
        if ind is None:
            ind = etree.SubElement(ppr, f"{W}ind")

        # Calculate indent based on level
        base_indent = list_style.indent_twips
        indent_per_level = (
            list_style.effective_indent_per_level
            if hasattr(list_style, "effective_indent_per_level")
            else base_indent
        )
        hanging = list_style.hanging_twips

        # Left indent increases with each level
        left_indent = base_indent + (ilvl * indent_per_level)

        ind.set(f"{W}left", str(left_indent))
        ind.set(f"{W}hanging", str(hanging))
