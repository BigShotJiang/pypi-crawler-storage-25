"""Draw ODF emitter."""

from __future__ import annotations

import io
import zipfile
from pathlib import Path
from typing import TYPE_CHECKING

from tokenmoulds.design.units import emu_to_pt
from tokenmoulds.emitters.odf_base import OdfBaseEmitter

if TYPE_CHECKING:
    from tokenmoulds.ir import DocumentIR

class DrawTemplateEmitter(OdfBaseEmitter):
    """LibreOffice Draw template emitter (.otg).

    Generates ODF graphics templates with:
    - Drawing page styles
    - Graphic object styles
    - Text styles for shapes
    - OpenType features (ligatures, stylistic sets, etc.)

    Inherits from OdfBaseEmitter (→ BaseEmitter).
    """

    MIMETYPE = "application/vnd.oasis.opendocument.graphics-template"

    def __init__(
        self,
        document: DocumentIR,
        template_root: Path | str | None = None,
        use_pure_text_colors: bool = True,
        enable_opentype_features: bool = True,
    ) -> None:
        """Initialize Draw template emitter.

        Args:
            document: Document IR with style information
            template_root: Optional override for template resolution
            use_pure_text_colors: If True, use pure black/white for text
            enable_opentype_features: If True, enable OpenType features
        """
        super().__init__(
            "draw",
            document,
            template_root,
            use_pure_text_colors=use_pure_text_colors,
            enable_opentype_features=enable_opentype_features,
        )

    def build_package(self) -> bytes:
        """Build the Draw template package."""
        buffer = io.BytesIO()
        title_text = f"{self.document.org_id} Graphics Template"
        body_text = (
            f"Body font: {self.document.body_style.font_family} "
            f"{self.document.body_style.font_size_pt:.1f}pt with accent {self.document.color_theme.accent1}."
        )
        heading_style = (
            self.document.heading_styles[0]
            if self.document.heading_styles
            else self.document.body_style
        )

        # Compute page dimensions from page_geometry or presentation_layout
        if self.document.page_geometry is not None:
            pg = self.document.page_geometry
            page_width_pt = emu_to_pt(pg.width_emu)
            page_height_pt = emu_to_pt(pg.height_emu)
            margin_pt = emu_to_pt(pg.margins.left)
            orientation = "landscape" if pg.width_emu > pg.height_emu else "portrait"
        else:
            layout = self.document.presentation_layout
            page_width_pt = emu_to_pt(layout.slide_width)
            page_height_pt = emu_to_pt(layout.slide_height)
            margin_pt = 72.0  # 1 inch fallback
            orientation = (
                "landscape" if layout.slide_width > layout.slide_height else "portrait"
            )

        frame_width_pt = page_width_pt - 2 * margin_pt
        frame_height_pt = page_height_pt * 0.2  # 20% of page for text frame

        styles_context = {
            "BODY_FONT": self.document.body_style.font_family,
            "HEADING_FONT": self.document.typography.heading_font,
            "BODY_SIZE": f"{self.document.body_style.font_size_pt:.1f}",
            "HEADING_SIZE": f"{heading_style.font_size_pt:.1f}",
            "BODY_COLOR": self.document.body_style.color,
            "HEADING_COLOR": heading_style.color,
            "ACCENT1": self.document.color_theme.accent1,
            "ACCENT2": self.document.color_theme.accent2,
            "PAGE_WIDTH": f"{page_width_pt:.2f}",
            "PAGE_HEIGHT": f"{page_height_pt:.2f}",
            "MARGIN": f"{margin_pt:.2f}",
            "ORIENTATION": orientation,
        }

        content_context = {
            "TITLE": title_text,
            "BODY": body_text,
            "WIDTH": f"{frame_width_pt:.2f}",
            "HEIGHT": f"{frame_height_pt:.2f}",
            "MARGIN": f"{margin_pt:.2f}",
        }

        with zipfile.ZipFile(
            buffer, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9
        ) as archive:
            archive.writestr(
                "mimetype", self.MIMETYPE, compress_type=zipfile.ZIP_STORED
            )
            archive.writestr(
                "content.xml",
                self._render("content.xml", context=content_context),
            )
            archive.writestr(
                "styles.xml",
                self._render("styles.xml", context=styles_context),
            )
            self._write_common_entries(archive, title=title_text)
        return buffer.getvalue()
