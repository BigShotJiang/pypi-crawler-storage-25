"""Low-level Word run and paragraph property helpers."""

from __future__ import annotations

from lxml import etree

from tokenmoulds.emitters.word_shared import NSMAP, W14, W
from tokenmoulds.ir import (
    CharacterTypography,
    LineSpacing,
    OpenTypeFeatures,
    ParagraphControl,
    ParagraphIndent,
)


class WordStyleTypographyMixin:
    def _update_style(self, root: etree._Element, style_id: str, style_data) -> None:
        """Update a paragraph style with new values including advanced typography."""
        # Find the style element
        style_el = root.find(f'.//w:style[@w:styleId="{style_id}"]', NSMAP)
        if style_el is None:
            return

        # Update run properties (character-level)
        rpr = style_el.find("w:rPr", NSMAP)
        if rpr is None:
            rpr = etree.SubElement(style_el, f"{W}rPr")

        self._apply_run_properties(rpr, style_data)

        # Update paragraph properties
        ppr = style_el.find("w:pPr", NSMAP)
        if ppr is None:
            ppr = etree.SubElement(style_el, f"{W}pPr")

        self._apply_paragraph_properties(ppr, style_data)

    def _apply_run_properties(self, rpr: etree._Element, style_data) -> None:
        """Apply all run (character-level) properties to an rPr element."""
        # Basic font properties
        self._apply_font_properties(rpr, style_data)

        # Bold
        if hasattr(style_data, "bold") and style_data.bold:
            if rpr.find("w:b", NSMAP) is None:
                etree.SubElement(rpr, f"{W}b")

        # Italic
        if hasattr(style_data, "italic") and style_data.italic:
            if rpr.find("w:i", NSMAP) is None:
                etree.SubElement(rpr, f"{W}i")

        # Advanced character typography
        if hasattr(style_data, "character"):
            self._apply_character_typography(rpr, style_data.character)

    def _apply_font_properties(self, rpr: etree._Element, style_data) -> None:
        """Apply basic font properties (font family, size, color)."""
        # Font family
        rfonts = rpr.find("w:rFonts", NSMAP)
        if rfonts is None:
            rfonts = etree.SubElement(rpr, f"{W}rFonts")
        font = style_data.font_family
        rfonts.set(f"{W}ascii", font)
        rfonts.set(f"{W}hAnsi", font)

        # Size (half-points)
        sz = rpr.find("w:sz", NSMAP)
        if sz is None:
            sz = etree.SubElement(rpr, f"{W}sz")
        sz.set(f"{W}val", str(int(style_data.font_size_pt * 2)))

        # Complex script size (same as regular)
        szCs = rpr.find("w:szCs", NSMAP)
        if szCs is None:
            szCs = etree.SubElement(rpr, f"{W}szCs")
        szCs.set(f"{W}val", str(int(style_data.font_size_pt * 2)))

        # Color
        color = rpr.find("w:color", NSMAP)
        if color is None:
            color = etree.SubElement(rpr, f"{W}color")
        color.set(f"{W}val", style_data.color.lstrip("#").upper())

    def _apply_character_typography(
        self, rpr: etree._Element, char: CharacterTypography
    ) -> None:
        """Apply advanced character-level typography settings."""
        # Character spacing (tracking)
        if char.tracking_twips != 0:
            spacing = rpr.find("w:spacing", NSMAP)
            if spacing is None:
                spacing = etree.SubElement(rpr, f"{W}spacing")
            spacing.set(f"{W}val", str(char.tracking_twips))

        # Kerning threshold (0 = always kern, which is modern best practice)
        self._apply_kerning(rpr, char.kern_threshold_half_pt)

        # Character scaling (condensed/expanded)
        if char.character_scale_pct != 100:
            w_elem = rpr.find("w:w", NSMAP)
            if w_elem is None:
                w_elem = etree.SubElement(rpr, f"{W}w")
            w_elem.set(f"{W}val", str(char.character_scale_pct))

        # Small caps
        if char.small_caps:
            if rpr.find("w:smallCaps", NSMAP) is None:
                etree.SubElement(rpr, f"{W}smallCaps")

        # All caps
        if char.all_caps:
            if rpr.find("w:caps", NSMAP) is None:
                etree.SubElement(rpr, f"{W}caps")

        # OpenType features
        self._apply_opentype_features(rpr, char.opentype)

    def _apply_kerning(self, rpr: etree._Element, threshold_half_pt: int) -> None:
        """Apply kerning with specified threshold."""
        kern = rpr.find("w:kern", NSMAP)
        if kern is None:
            kern = etree.SubElement(rpr, f"{W}kern")
        kern.set(f"{W}val", str(threshold_half_pt))

    def _apply_opentype_features(
        self, rpr: etree._Element, opentype: OpenTypeFeatures
    ) -> None:
        """Apply Word 2010+ OpenType feature elements (w14 namespace)."""
        if not self.allow_opentype_features:
            for tag in (
                "ligatures",
                "numForm",
                "numSpacing",
                "stylisticSets",
                "cntxtAlts",
            ):
                existing = rpr.find(f"w14:{tag}", NSMAP)
                if existing is not None:
                    rpr.remove(existing)
            return
        # Ligatures
        if opentype.ligatures != "none":
            lig = rpr.find("w14:ligatures", NSMAP)
            if lig is None:
                lig = etree.SubElement(rpr, f"{W14}ligatures")
            lig.set(f"{W14}val", opentype.ligatures)

        # Number form (lining vs oldstyle figures)
        if opentype.number_form != "default":
            numForm = rpr.find("w14:numForm", NSMAP)
            if numForm is None:
                numForm = etree.SubElement(rpr, f"{W14}numForm")
            numForm.set(f"{W14}val", opentype.number_form)

        # Number spacing (proportional vs tabular)
        if opentype.number_spacing != "default":
            numSpacing = rpr.find("w14:numSpacing", NSMAP)
            if numSpacing is None:
                numSpacing = etree.SubElement(rpr, f"{W14}numSpacing")
            numSpacing.set(f"{W14}val", opentype.number_spacing)

        # Stylistic sets (ss01-ss20)
        if opentype.stylistic_sets:
            stylSets = rpr.find("w14:stylisticSets", NSMAP)
            if stylSets is None:
                stylSets = etree.SubElement(rpr, f"{W14}stylisticSets")
            for ss_num in opentype.stylistic_sets:
                if 1 <= ss_num <= 20:
                    styleSet = etree.SubElement(stylSets, f"{W14}styleSet")
                    styleSet.set(f"{W14}id", str(ss_num))

        # Contextual alternates
        if opentype.contextual_alternates:
            cntxtAlts = rpr.find("w14:cntxtAlts", NSMAP)
            if cntxtAlts is None:
                cntxtAlts = etree.SubElement(rpr, f"{W14}cntxtAlts")
            cntxtAlts.set(f"{W14}val", "1")

    def _apply_paragraph_properties(self, ppr: etree._Element, style_data) -> None:
        """Apply all paragraph-level properties to a pPr element."""
        # Basic spacing (before/after)
        self._apply_paragraph_spacing(
            ppr, style_data.spacing, getattr(style_data, "line_spacing", None)
        )

        # Indentation
        if hasattr(style_data, "indent"):
            self._apply_paragraph_indent(ppr, style_data.indent)

        # Paragraph control (justification, keep-with-next, etc.)
        if hasattr(style_data, "control"):
            self._apply_paragraph_control(ppr, style_data.control)

    def _apply_paragraph_spacing(
        self, ppr: etree._Element, spacing, line_spacing: LineSpacing | None
    ) -> None:
        """Apply paragraph spacing (before, after, line)."""
        spacing_el = ppr.find("w:spacing", NSMAP)
        if spacing_el is None:
            spacing_el = etree.SubElement(ppr, f"{W}spacing")

        spacing_el.set(f"{W}before", str(spacing.before_twips))
        spacing_el.set(f"{W}after", str(spacing.after_twips))

        # Line spacing
        if line_spacing and not line_spacing.is_default:
            spacing_el.set(f"{W}line", str(line_spacing.value_twips))
            spacing_el.set(f"{W}lineRule", line_spacing.rule)

    def _apply_paragraph_indent(
        self, ppr: etree._Element, indent: ParagraphIndent
    ) -> None:
        """Apply paragraph indentation."""
        if indent.is_default:
            return

        ind = ppr.find("w:ind", NSMAP)
        if ind is None:
            ind = etree.SubElement(ppr, f"{W}ind")

        if indent.left_twips != 0:
            ind.set(f"{W}left", str(indent.left_twips))
        if indent.right_twips != 0:
            ind.set(f"{W}right", str(indent.right_twips))
        if indent.first_line_twips != 0:
            ind.set(f"{W}firstLine", str(indent.first_line_twips))
        elif indent.hanging_twips != 0:
            ind.set(f"{W}hanging", str(indent.hanging_twips))

    def _apply_paragraph_control(
        self, ppr: etree._Element, control: ParagraphControl
    ) -> None:
        """Apply paragraph control settings (justification, keep-with-next, etc.)."""
        # Justification
        if control.justification != "left":
            jc = ppr.find("w:jc", NSMAP)
            if jc is None:
                jc = etree.SubElement(ppr, f"{W}jc")
            jc.set(f"{W}val", control.justification)

        # Contextual spacing
        if control.contextual_spacing:
            if ppr.find("w:contextualSpacing", NSMAP) is None:
                etree.SubElement(ppr, f"{W}contextualSpacing")

        # Keep with next
        if control.keep_with_next:
            if ppr.find("w:keepNext", NSMAP) is None:
                etree.SubElement(ppr, f"{W}keepNext")

        # Keep lines together
        if control.keep_lines_together:
            if ppr.find("w:keepLines", NSMAP) is None:
                etree.SubElement(ppr, f"{W}keepLines")

        # Widow/orphan control (default is on, so only add if off)
        if not control.widow_orphan_control:
            widowControl = ppr.find("w:widowControl", NSMAP)
            if widowControl is None:
                widowControl = etree.SubElement(ppr, f"{W}widowControl")
            widowControl.set(f"{W}val", "0")

        # Suppress auto hyphens
        if control.suppress_auto_hyphens:
            if ppr.find("w:suppressAutoHyphens", NSMAP) is None:
                etree.SubElement(ppr, f"{W}suppressAutoHyphens")
