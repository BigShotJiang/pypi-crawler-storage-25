"""ODF page-layout and master-page builders for long-form Writer documents.

Two things live here:

1. :func:`build_page_layout` — produces ``<style:page-layout>`` elements
   from a :class:`NamedPageGeometry` + :class:`NamedMargins`.  These go
   into Writer's ``office:automatic-styles`` section.
2. :func:`build_master_page` — produces ``<style:master-page>`` elements
   paired with a page layout and carrying the section's headers and
   footers.  These go into Writer's ``office:master-styles`` section.

The master page pairs with the page layout by name.  Sections that use
``odd_even_different=True`` emit both ``<style:header>``/``<style:footer>``
(the default/odd side) and ``<style:header-left>``/``<style:footer-left>``
(the even side).  Mirror margins set ``style:page-usage="mirrored"`` on
the master page so Writer flips left/right margins across facing pages.

Content slot strings in :class:`HeaderFooterConfig` are parsed via the
shared :func:`parse_content_spec` (Task 5) and rendered into ODF text
fields: ``STYLEREF:Heading1`` → ``<text:chapter>``, ``PAGE`` →
``<text:page-number>``, ``NUMPAGES`` → ``<text:page-count>``,
``{document.title}`` → ``<text:title>``.

Unit convention — **pt throughout**.  The IR is pt; ODF emits cm in
``fo:`` attributes; :func:`pt_to_cm_str` is the only conversion that
happens in this module, at the serialization boundary.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from lxml import etree

from tokenmoulds.design.layout_defaults import DEFAULT_BASELINE_PT
from tokenmoulds.design.units.conversion import pt_to_cm
from tokenmoulds.emitters.odf_helpers import ODF_NSMAP, q
from tokenmoulds.ir.long_form import (
    HeaderFooterConfig,
    LongFormSection,
    NamedMargins,
    NamedPageGeometry,
    PageNumberConfig,
    PageNumberFormat,
)
from tokenmoulds.semantic.content import SemanticContentInput
from tokenmoulds.semantic.lowerers.writer import append_writer_content


# ODF ``style:num-format`` values for each IR ``PageNumberFormat``.
# The spec allows "1", "a", "A", "i", "I", or empty (none).
_NUM_FORMAT_ODF: dict[PageNumberFormat, str] = {
    "decimal": "1",
    "lowerLetter": "a",
    "upperLetter": "A",
    "lowerRoman": "i",
    "upperRoman": "I",
    "none": "",
}


def _odf_num_format(fmt: PageNumberFormat) -> str:
    return _NUM_FORMAT_ODF.get(fmt, "1")


def pt_to_cm_str(points: float) -> str:
    """Format a pt value as an ODF ``fo:`` cm attribute string.

    Exact values render as ``"21cm"``, fractional as ``"20.99cm"``,
    zero as ``"0cm"``.  Rounded to 4 decimal places, trailing zeros
    and trailing decimal point trimmed.
    """
    cm = round(pt_to_cm(points), 4)
    if cm == int(cm):
        return f"{int(cm)}cm"
    text = f"{cm:.4f}".rstrip("0").rstrip(".")
    return f"{text}cm"


def build_page_layout(
    name: str,
    geometry: NamedPageGeometry,
    margins: NamedMargins,
    *,
    page_number: PageNumberConfig | None = None,
    columns: int = 1,
    column_gap_pt: float = 36.0,
    header_height_pt: float | None = None,
    footer_height_pt: float | None = None,
) -> etree._Element:
    """Build a ``<style:page-layout>`` element.

    Parity with Word's ``w:sectPr``:

    - ``margins.resolve_left()`` / ``resolve_right()`` handle the
      mirror-margin case — for a book layout with ``inner > outer``, the
      ``fo:margin-left`` attribute ends up larger than ``fo:margin-right``.
      The caller's Task 9 master-page wiring sets ``style:page-usage`` on
      the master page itself to signal the facing-page flip.
    - ``page_number.format`` → ``style:num-format`` (``"1"`` for decimal,
      ``"i"`` for lowerRoman, etc.).  Omitted for ``"none"``.
    - ``columns > 1`` → ``<style:columns>`` child with ``fo:column-count``
      and ``fo:column-gap``.  Matches Word's ``w:cols``.
    - ``header_height_pt`` / ``footer_height_pt`` → ``style:header-height``
      / ``style:footer-height``.  Defaults to 2× baseline (matches the
      legacy short-form path in ``writer.py::_set_page_layout_props``).
    """
    layout = etree.Element(q("style", "page-layout"), nsmap=ODF_NSMAP)
    layout.set(q("style", "name"), name)

    props = etree.SubElement(layout, q("style", "page-layout-properties"))
    props.set(q("fo", "page-width"), pt_to_cm_str(geometry.width_pt))
    props.set(q("fo", "page-height"), pt_to_cm_str(geometry.height_pt))
    props.set(q("style", "print-orientation"), geometry.orientation)

    props.set(q("fo", "margin-top"), pt_to_cm_str(margins.top_pt))
    props.set(q("fo", "margin-bottom"), pt_to_cm_str(margins.bottom_pt))
    props.set(q("fo", "margin-left"), pt_to_cm_str(margins.resolve_left()))
    props.set(q("fo", "margin-right"), pt_to_cm_str(margins.resolve_right()))

    # Header/footer box heights — mirror the legacy short-form path in
    # writer.py::_set_page_layout_props, which uses 2× baseline grid
    # (see design.layout_defaults.word_fallback_header_footer_twips).
    # With the 12pt default baseline this yields 24pt ≈ 0.85cm.
    default_hf = DEFAULT_BASELINE_PT * 2
    hh = header_height_pt if header_height_pt is not None else default_hf
    fh = footer_height_pt if footer_height_pt is not None else default_hf
    props.set(q("style", "header-height"), pt_to_cm_str(hh))
    props.set(q("style", "footer-height"), pt_to_cm_str(fh))

    if page_number is not None:
        num_fmt = _odf_num_format(page_number.format)
        if num_fmt:
            props.set(q("style", "num-format"), num_fmt)

    # Multi-column layout.  ODF expresses columns as a child of
    # page-layout-properties, unlike Word which puts cols at sectPr level.
    if columns > 1:
        cols_el = etree.SubElement(props, q("style", "columns"))
        cols_el.set(q("fo", "column-count"), str(columns))
        cols_el.set(q("fo", "column-gap"), pt_to_cm_str(column_gap_pt))

    return layout


# ---------------------------------------------------------------------------
# Master page builder
# ---------------------------------------------------------------------------


def _render_content_spec(
    paragraph: etree._Element,
    spec: SemanticContentInput,
    *,
    document_title: str,
) -> None:
    """Lower semantic content into a Writer paragraph."""
    append_writer_content(paragraph, spec, document_title=document_title)


def _build_header_footer_paragraph(
    tag: str,
    config: HeaderFooterConfig,
    *,
    document_title: str,
    is_even_page: bool = False,
) -> etree._Element:
    """Build a ``<style:header>``/``<style:footer>`` (or ``-left`` variant).

    A header/footer paragraph in ODF has three physical positions —
    left, center, right — separated by tab stops.  :class:`HeaderFooterConfig`
    exposes five logical slots: ``content_left``, ``content_center``,
    ``content_right``, ``content_outer``, ``content_inner``.  The builder
    projects the logical slots onto the three physical positions:

    - ``content_center`` always renders in the center position.
    - On odd (right-hand) pages, physical-left is ``content_inner`` if set,
      else ``content_left``; physical-right is ``content_outer`` if set,
      else ``content_right``.  Rationale: on a right-hand page, the inner
      edge is the LEFT side and the outer edge is the RIGHT side.
    - On even (left-hand) pages — when ``is_even_page=True`` — the flip
      reverses: physical-left is ``content_outer`` if set, else
      ``content_left``; physical-right is ``content_inner`` if set, else
      ``content_right``.  This matches how facing pages in a book present
      their outer edges.

    A config that uses only ``content_left``/``center``/``content_right``
    renders identically on odd and even pages.  A book config that uses
    only ``content_outer``/``center``/``content_inner`` gets the correct
    outer-edge positioning on both sides.  Mixing is allowed but the
    outer/inner slots take precedence when they're set.
    """
    element = etree.Element(q("style", tag))
    paragraph = etree.SubElement(element, q("text", "p"))
    paragraph.set(q("text", "style-name"), config.style)

    if is_even_page:
        # Even (left) page: outer = physically left, inner = physically right
        phys_left = config.outer if config.outer is not None else config.left
        phys_right = config.inner if config.inner is not None else config.right
    else:
        # Odd (right) or non-mirror page: inner = physically left,
        # outer = physically right
        phys_left = config.inner if config.inner is not None else config.left
        phys_right = config.outer if config.outer is not None else config.right

    slots = [phys_left, config.center, phys_right]
    first = True
    for spec in slots:
        if spec is None:
            continue
        if not first:
            etree.SubElement(paragraph, q("text", "tab"))
        _render_content_spec(paragraph, spec, document_title=document_title)
        first = False
    return element


def build_master_page(
    name: str,
    page_layout_name: str,
    section: LongFormSection,
    *,
    document_title: str = "",
) -> etree._Element:
    """Build a ``<style:master-page>`` element for a long-form section.

    Pairs with a page layout by name.  Emits headers/footers from the
    section's config, handles odd/even via ``-left`` variants, and sets
    ``style:page-usage="mirrored"`` when the margins are mirrored.
    """
    master = etree.Element(q("style", "master-page"), nsmap=ODF_NSMAP)
    master.set(q("style", "name"), name)
    master.set(q("style", "page-layout-name"), page_layout_name)
    if section.margins.mirror:
        master.set(q("style", "page-usage"), "mirrored")

    # Default (odd-page / single) header
    default_header = section.header_ref or section.header_ref_odd
    if default_header is not None:
        master.append(
            _build_header_footer_paragraph(
                "header", default_header, document_title=document_title
            )
        )

    # Even-page header when odd/even is on — outer/inner slots flip
    if section.odd_even_different and section.header_ref_even is not None:
        master.append(
            _build_header_footer_paragraph(
                "header-left",
                section.header_ref_even,
                document_title=document_title,
                is_even_page=True,
            )
        )

    # Default (odd-page / single) footer
    default_footer = section.footer_ref or section.footer_ref_odd
    if default_footer is not None:
        master.append(
            _build_header_footer_paragraph(
                "footer", default_footer, document_title=document_title
            )
        )

    # Even-page footer when odd/even is on — outer/inner slots flip
    if section.odd_even_different and section.footer_ref_even is not None:
        master.append(
            _build_header_footer_paragraph(
                "footer-left",
                section.footer_ref_even,
                document_title=document_title,
                is_even_page=True,
            )
        )

    return master


# ---------------------------------------------------------------------------
# Section transition styles
# ---------------------------------------------------------------------------
#
# ODF signals "start a new section on a new master page" by setting
# ``style:master-page-name`` on a paragraph style and applying that style
# to the first paragraph of the section.  One dedicated "section-first"
# style per section avoids polluting shared styles like Heading1.
#
# Naming convention:
# - section-first style name: ``P_{section_name}_First``
# - master-page name:          ``Section_{section_name}`` (with spaces →
#   underscores, first letter titlecased per word)
#
# Both functions live in this module so the Writer emitter only has one
# import path for the full long-form master-page pipeline.


_ODF_NAME_SAFE = re.compile(r"[^A-Za-z0-9_]+")


def odf_name(raw: str) -> str:
    """Sanitize a string for use as an ODF ``style:name`` attribute.

    ODF style names can contain letters, digits, and underscores.
    Everything else collapses to a single underscore, matching the
    convention Writer uses when generating its own styles.
    """
    return _ODF_NAME_SAFE.sub("_", raw).strip("_")


def _master_page_name_for(section_name: str) -> str:
    """Return the master-page name used by the default convention.

    ``front_matter`` → ``Section_front_matter``.  Callers can override
    by passing an explicit ``master_page_name`` to
    :func:`build_section_first_style`.
    """
    return f"Section_{odf_name(section_name)}"


def build_section_first_style(
    section_name: str,
    master_page_name: str,
    *,
    parent_style_name: str = "Standard",
) -> etree._Element:
    """Build a ``<style:style>`` for the first paragraph of a section.

    The returned style carries ``style:master-page-name`` on its
    paragraph-properties.  When Writer renders content.xml and sees a
    paragraph using this style, it starts a new page and applies the
    referenced master page — that's the ODF section-transition
    mechanism.
    """
    style = etree.Element(q("style", "style"), nsmap=ODF_NSMAP)
    style.set(q("style", "name"), f"P_{odf_name(section_name)}_First")
    style.set(q("style", "family"), "paragraph")
    style.set(q("style", "parent-style-name"), parent_style_name)

    props = etree.SubElement(style, q("style", "paragraph-properties"))
    props.set(q("style", "master-page-name"), master_page_name)

    return style


@dataclass
class SectionTransitionBundle:
    """Result of :func:`build_section_transition_styles`.

    - ``styles`` — the ``<style:style>`` elements to drop into
      ``office:automatic-styles``
    - ``style_for_section`` — maps ``section.name`` to the generated
      style-name, so the Writer emitter can apply it to the first
      paragraph of each section's content
    - ``master_page_for_section`` — maps ``section.name`` to the master
      page name the style points at, so callers can build the matching
      :func:`build_master_page` elements
    """

    styles: list[etree._Element] = field(default_factory=list)
    style_for_section: dict[str, str] = field(default_factory=dict)
    master_page_for_section: dict[str, str] = field(default_factory=dict)


def build_section_transition_styles(
    sections: list[LongFormSection],
) -> SectionTransitionBundle:
    """Build one section-first paragraph style per section with stable naming.

    The master-page names it generates match :func:`_master_page_name_for`
    so callers can pair each generated transition style with a master
    page built via :func:`build_master_page` without any extra bookkeeping.
    """
    bundle = SectionTransitionBundle()
    for section in sections:
        master_name = _master_page_name_for(section.name)
        style_el = build_section_first_style(section.name, master_name)
        # build_section_first_style sets style:name unconditionally, so
        # this lookup is guaranteed to return a str — narrow for pyright.
        style_name = style_el.get(q("style", "name"))
        assert style_name is not None
        bundle.styles.append(style_el)
        bundle.style_for_section[section.name] = style_name
        bundle.master_page_for_section[section.name] = master_name
    return bundle
