"""Base class for all document emitters.

Defines the common interface that all emitters must implement.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from tokenmoulds.ir import DocumentIR


class BaseEmitter(ABC):
    """Abstract base class for all document emitters.

    All emitters consume a DocumentIR and produce bytes representing
    a document package (OOXML, ODF, etc.).
    """

    def __init__(
        self,
        document: "DocumentIR",
        template_root: Path | str | None = None,
    ) -> None:
        """Initialize the emitter.

        Args:
            document: The Document IR containing all style/typography information
            template_root: Optional override path for XML templates
        """
        self.document = document
        self.template_root = template_root

    @abstractmethod
    def build_package(self) -> bytes:
        """Build the output package.

        Returns:
            bytes: The complete document package
        """
        pass
