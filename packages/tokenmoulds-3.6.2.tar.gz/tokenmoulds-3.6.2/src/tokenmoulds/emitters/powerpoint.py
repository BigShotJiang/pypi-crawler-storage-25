"""PowerPoint template emitter built from the Document IR.

Uses SSOT (Single Source of Truth) pattern: XML structure from xml-structures/,
Python modifies attribute values via lxml DOM manipulation with cached templates.

Supports:
- Theme customization (colors, fonts) via lxml DOM manipulation
- Built-in table styles controlled via theme colors (Brandwares method)
- Table text defaults via slide master otherStyle
- Multiple color themes via extraClrSchemeLst
- Font embedding (EOT format) via template fragments

Note on table styles: Built-in Office table styles (like "Medium Style 2 - Accent 1")
reference theme colors. By setting clrScheme colors, we control how these styles look.
We use a minimal tableStyles.xml that just specifies the default style GUID.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Literal

from lxml import etree

from tokenmoulds.archetypes.renderer import ArchetypeRenderer
from tokenmoulds.archetypes.shape_dsl import LayoutFamily
from tokenmoulds.emitters.ooxml_base import OOXMLBaseEmitter
from tokenmoulds.emitters.pptx_layout_mixin import PowerPointLayoutMixin
from tokenmoulds.emitters.pptx_master_mixin import PowerPointMasterMixin
from tokenmoulds.emitters.pptx_media_mixin import PowerPointMediaMixin
from tokenmoulds.emitters.pptx_package_mixin import PowerPointPackageMixin
from tokenmoulds.emitters.pptx_semantic_mixin import PowerPointSemanticSlideMixin
from tokenmoulds.ir import ColorTheme, DocumentIR
from tokenmoulds.packaging import PackagedEntry

logger = logging.getLogger(__name__)

PRESENTATIONML_NS = "http://schemas.openxmlformats.org/presentationml/2006/main"
PACKAGE_REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"
SLIDE_LAYOUT_REL_TYPE = (
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout"
)
THEME_REL_TYPE = (
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme"
)
_DEFAULT_SLIDE_LAYOUT_NUMBERS = tuple(range(1, 41))
STANDARD_LAYOUT_NUMBER_BY_NAME = {
    "title_slide": 1,
    "title_content": 2,
    "section_header": 3,
    "two_content": 4,
    "comparison": 5,
    "title_only": 6,
    "blank": 7,
    "content_caption": 8,
    "picture_caption": 9,
    "vertical_text": 10,
    "vertical_title": 11,
}


def _build_default_slide_layout_structure() -> Dict[str, str]:
    """Return the shipped PowerPoint default slide layout parts."""
    structure: Dict[str, str] = {}
    for layout_number in _DEFAULT_SLIDE_LAYOUT_NUMBERS:
        structure[f"ppt/slideLayouts/slideLayout{layout_number}.xml"] = (
            f"ssot/slide_layouts/slideLayout{layout_number}.xml"
        )
        structure[f"ppt/slideLayouts/_rels/slideLayout{layout_number}.xml.rels"] = (
            "ssot/slide_layout_rels.xml"
        )
    return structure


@dataclass
class ExtraColorTheme:
    """Additional color theme for extraClrSchemeLst."""

    name: str
    theme: ColorTheme


IMAGE_REL_TYPE = (
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image"
)


class PowerPointEmitter(
    PowerPointMasterMixin,
    PowerPointPackageMixin,
    PowerPointMediaMixin,
    PowerPointSemanticSlideMixin,
    PowerPointLayoutMixin,
    OOXMLBaseEmitter,
):
    """Build PowerPoint templates from the canonical Document IR.

    Uses SSOT pattern: XML structure comes from xml-structures/ecma-376/presentationml/,
    Python only substitutes template variables. Never creates elements with etree.

    PowerPoint-specific features:
    - Built-in table styles controlled via theme colors (Brandwares method)
    - Table text defaults via slide master otherStyle
    - Multiple color themes via extraClrSchemeLst (light/dark mode)
    - Font embedding (EOT format) via template fragments
    """

    DEFAULT_SLIDE_LAYOUT_NUMBERS = _DEFAULT_SLIDE_LAYOUT_NUMBERS

    # PowerPoint package structure: archive path -> template name
    # Template names are relative to the spec templates folder
    PACKAGE_STRUCTURE: Dict[str, str] = {
        "[Content_Types].xml": "ssot/content_types.xml",
        "_rels/.rels": "ssot/package_rels.xml",
        "ppt/presentation.xml": "ssot/presentation.xml",
        "ppt/_rels/presentation.xml.rels": "ssot/presentation_rels.xml",
        "ppt/theme/theme1.xml": "ssot/theme.xml",
        "ppt/slideMasters/slideMaster1.xml": "ssot/slide_master.xml",
        "ppt/slideMasters/_rels/slideMaster1.xml.rels": "ssot/slide_master_rels.xml",
        **_build_default_slide_layout_structure(),
        "ppt/slides/slide1.xml": "ssot/slide.xml",
        "ppt/slides/_rels/slide1.xml.rels": "ssot/slide_rels.xml",
        "ppt/tableStyles.xml": "ssot/table_styles.xml",
        "ppt/presProps.xml": "ssot/pres_props.xml",
        "ppt/viewProps.xml": "ssot/view_props.xml",
        "docProps/core.xml": "ssot/docprops_core.xml",
        "docProps/app.xml": "ssot/docprops_app.xml",
    }

    def __init__(
        self,
        document: DocumentIR,
        template_root: Path | str | None = None,
        embed_fonts: bool = False,
        fonts_dir: Path | str | None = None,
        extra_color_themes: List[ExtraColorTheme] | None = None,
        use_pure_text_colors: bool = True,
        output_format: Literal["potx", "pptx"] = "potx",
        layout_families: List[LayoutFamily] | None = None,
    ) -> None:
        self._output_format = output_format
        self._layout_families = layout_families or []
        super().__init__(
            document=document,
            template_root=template_root,
            embed_fonts=embed_fonts,
            fonts_dir=fonts_dir,
            use_pure_text_colors=use_pure_text_colors,
        )
        self.extra_color_themes = extra_color_themes or []
        self._init_media(document.presentation_layout.decoration)
        if self._layout_families:
            archetype_numbers = tuple(
                family.layout_number_start + i
                for family in self._layout_families
                for i in range(len(family.archetypes))
            )
            self.DEFAULT_SLIDE_LAYOUT_NUMBERS = (
                _DEFAULT_SLIDE_LAYOUT_NUMBERS + archetype_numbers
            )

    # =========================================================================
    # ABSTRACT METHOD IMPLEMENTATIONS (from OOXMLBaseEmitter)
    # =========================================================================

    def _get_format_key(self) -> str:
        """Return 'powerpoint' for template resolution."""
        return "powerpoint"

    def _get_base_template_path(self) -> Path:
        """Not used - SSOT builds from xml-structures."""
        return Path()

    def _get_package_structure(self) -> Dict[str, str]:
        """Return the package structure mapping archive paths to template names."""
        return self.PACKAGE_STRUCTURE

    def _get_document_title(self) -> str:
        """Return document title for metadata."""
        return f"{self.document.org_id} Presentation"

    def _get_font_embedding_format(self) -> Literal["odttf", "eot", "none"]:
        """Return 'eot' - PowerPoint uses EOT format fonts."""
        return "eot"

    def _get_font_entries_path(self) -> str:
        """Return path prefix for embedded fonts."""
        return "ppt/fonts/"

    def _get_initial_rel_id(self) -> int:
        """Return 20 to avoid conflicts with existing PowerPoint relationships."""
        return 20

    def _should_customize_entry(self, entry_path: str) -> bool:
        """Check if entry needs customization."""
        return entry_path in (
            "[Content_Types].xml",
            "ppt/presentation.xml",
            "ppt/_rels/presentation.xml.rels",
            "ppt/theme/theme1.xml",
            "ppt/slideMasters/slideMaster1.xml",
            "ppt/slideMasters/_rels/slideMaster1.xml.rels",
            "ppt/slides/slide1.xml",
            "ppt/slides/_rels/slide1.xml.rels",
            "ppt/tableStyles.xml",
            "docProps/core.xml",
            "docProps/app.xml",
        ) or (
            entry_path.startswith("ppt/slideLayouts/slideLayout")
            and entry_path.endswith(".xml")
            and not entry_path.endswith(".rels")
        )

    def _customize_entry(self, entry_path: str, data: bytes) -> bytes | None:
        """Customize specific ZIP entry via template substitution."""
        if entry_path == "[Content_Types].xml":
            return self._customize_content_types_ssot(data)
        elif entry_path == "ppt/presentation.xml":
            return self._customize_presentation_ssot(data)
        elif entry_path == "ppt/_rels/presentation.xml.rels":
            return self._customize_presentation_rels_ssot(data)
        elif entry_path == "ppt/theme/theme1.xml":
            return self._customize_theme_ssot(data)
        elif entry_path == "ppt/slideMasters/slideMaster1.xml":
            return self._customize_slide_master_ssot(data)
        elif entry_path == "ppt/slideMasters/_rels/slideMaster1.xml.rels":
            return self._customize_slide_master_rels_ssot(data)
        elif entry_path.startswith(
            "ppt/slideLayouts/slideLayout"
        ) and entry_path.endswith(".xml"):
            return self._customize_slide_layout_ssot(entry_path, data)
        elif entry_path == "ppt/slides/slide1.xml":
            return self._customize_slide_ssot(data)
        elif entry_path == "ppt/slides/_rels/slide1.xml.rels":
            return self._customize_slide_rels_ssot(data)
        elif entry_path == "ppt/tableStyles.xml":
            return self._customize_table_styles_ssot(data)
        elif entry_path == "docProps/core.xml":
            return self._customize_core_props_ssot(data)
        elif entry_path == "docProps/app.xml":
            return self._customize_app_props_ssot(data)
        return data

    def _get_font_metadata_entries(self) -> list:
        """PowerPoint handles font metadata in presentation.xml, not separately."""
        return []

    def _get_additional_packaged_entries(self) -> list[PackagedEntry]:
        """Resolve semantic slide media assets and archetype layouts."""
        self._prepare_semantic_media_assets()
        entries = [
            PackagedEntry(asset.archive_path, asset.data)
            for asset in self._slide_media_assets
        ]
        entries.extend(self._build_archetype_layout_entries())
        return entries

    @property
    def _archetype_layout_numbers(self) -> tuple[int, ...]:
        """Layout numbers assigned to archetype families."""
        return tuple(
            family.layout_number_start + i
            for family in self._layout_families
            for i in range(len(family.archetypes))
        )

    def _build_archetype_layout_entries(self) -> list[PackagedEntry]:
        """Render LayoutFamily archetypes as slideLayout XML parts."""
        if not self._layout_families:
            return []
        from tokenmoulds.design.page_geometry import create_slide_grid

        slide_width, slide_height = self._get_slide_dimensions_emu()
        baseline_emu = int(self.document.typography.baseline_emu or 152400)
        grid = create_slide_grid(
            slide_width_emu=slide_width,
            slide_height_emu=slide_height,
            baseline_grid_emu=baseline_emu,
        )
        renderer = ArchetypeRenderer()
        rels_xml = self.templates.read_text("ssot/slide_layout_rels.xml").encode(
            "utf-8"
        )
        entries: list[PackagedEntry] = []
        for family in self._layout_families:
            for index, archetype in enumerate(family.archetypes):
                layout_number = family.layout_number_start + index
                root = renderer.render_layout(archetype, grid)
                xml_bytes = etree.tostring(root, encoding="UTF-8", xml_declaration=True)
                entries.append(
                    PackagedEntry(
                        f"ppt/slideLayouts/slideLayout{layout_number}.xml",
                        xml_bytes,
                    )
                )
                entries.append(
                    PackagedEntry(
                        f"ppt/slideLayouts/_rels/slideLayout{layout_number}.xml.rels",
                        rels_xml,
                    )
                )
        return entries

    # =========================================================================
    # SSOT CUSTOMIZATIONS (DOM-based with cached templates)
    # =========================================================================
