"""Semantic slide rendering mixin for the PowerPoint emitter.

Provides data-driven rendering of semantic slide archetypes (hero cover,
section statement, card matrix) using :class:`SemanticSlideDescriptor`
constants.  Also handles decorative fill application and illustration
embedding.
"""

from __future__ import annotations

from dataclasses import dataclass

from lxml import etree

from tokenmoulds.dtcg.layout_recipe_resolver import get_semantic_layout_spec
from tokenmoulds.emitters.pptx_shape_helpers import (
    PRESENTATIONML_NS,
    append_no_outline,
    assign_group_shape_ids,
    read_shape_rect,
    set_group_rect,
    shape_bounds_in_group,
)
from tokenmoulds.emitters.xml_helpers import replace_placeholders
from tokenmoulds.emitters.xml_helpers_fills import emit_fill, emit_illustration_group


# ---------------------------------------------------------------------------
# Semantic slide descriptors
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class SemanticSlideDescriptor:
    """Everything needed to render a semantic slide from its SSOT template.

    Each semantic layout archetype is expressed as data rather than a
    dedicated method.  The mixin uses a single render path for all of them.
    """

    template_name: str
    regions: tuple[str, ...]
    placeholder_context_map: dict[str, str]
    named_shapes: dict[str, str]
    extra_context: dict[str, str]


_HERO_DESCRIPTOR = SemanticSlideDescriptor(
    template_name="ssot/slide_hero.xml",
    # Order matters: title before kicker (kicker fallback depends on title rect)
    regions=("background", "overlay", "title", "kicker", "subtitle"),
    placeholder_context_map={
        "background": "BACKGROUND",
        "overlay": "OVERLAY",
        "kicker": "KICKER",
        "title": "TITLE",
        "subtitle": "SUBTITLE",
    },
    named_shapes={"background": "Hero Background 1", "overlay": "Hero Overlay 2"},
    extra_context={
        "SLIDE_KICKER": "{org_id_upper}",
        "SLIDE_SUBTITLE": "Token-driven hero cover layout",
    },
)

_SECTION_STATEMENT_DESCRIPTOR = SemanticSlideDescriptor(
    template_name="ssot/slide_section_statement.xml",
    regions=("background", "band", "title", "body"),
    placeholder_context_map={
        "background": "BACKGROUND",
        "band": "BAND",
        "title": "TITLE",
        "body": "BODY",
    },
    named_shapes={"background": "Section Background 1", "band": "Section Band 2"},
    extra_context={
        "SLIDE_BODY": "A token-driven section divider for semantic slide galleries",
    },
)

_CARD_MATRIX_DESCRIPTOR = SemanticSlideDescriptor(
    template_name="ssot/slide_card_matrix.xml",
    regions=("title", "body", "card_1", "card_2", "card_3", "card_4"),
    placeholder_context_map={
        "title": "TITLE",
        "body": "BODY",
        "card_1": "CARD1",
        "card_2": "CARD2",
        "card_3": "CARD3",
        "card_4": "CARD4",
    },
    named_shapes={
        "card_1": "Card Surface 1",
        "card_2": "Card Surface 2",
        "card_3": "Card Surface 3",
        "card_4": "Card Surface 4",
    },
    extra_context={
        "SLIDE_TITLE": "{org_id} Capabilities",
        "SLIDE_BODY": "Four reusable card surfaces driven by semantic regions",
    },
)

_SEMANTIC_SLIDE_DESCRIPTORS: dict[str, SemanticSlideDescriptor] = {
    "ssot/slide_hero.xml": _HERO_DESCRIPTOR,
    "ssot/slide_section_statement.xml": _SECTION_STATEMENT_DESCRIPTOR,
    "ssot/slide_card_matrix.xml": _CARD_MATRIX_DESCRIPTOR,
}


# ---------------------------------------------------------------------------
# Mixin
# ---------------------------------------------------------------------------


class PowerPointSemanticSlideMixin:
    """Mixin providing descriptor-driven semantic slide rendering."""

    @property
    def _baseline_emu(self) -> int:
        return int(self.document.typography.baseline_emu or 152400)  # type: ignore[attr-defined]

    def _region_fallback(
        self,
        region_name: str,
        baseline_emu: int,
        slide_width: int,
        slide_height: int,
        resolved: dict[str, tuple[int, int, int, int]],
    ) -> tuple[int, int, int, int]:
        """Compute a sensible fallback rect for a region."""
        if region_name == "background":
            return (0, 0, slide_width, slide_height)
        if region_name == "overlay":
            return (0, 0, slide_width * 2 // 3, slide_height)
        if region_name == "band":
            return (0, 0, max(slide_width // 3, baseline_emu * 8), slide_height)
        if region_name == "kicker" and "title" in resolved:
            t = resolved["title"]
            return (
                t[0],
                max(baseline_emu * 2, t[1] - baseline_emu * 2),
                min(t[2], slide_width // 3),
                baseline_emu * 2,
            )
        kind = {"title": "title", "subtitle": "body", "body": "body"}.get(region_name)
        if kind:
            for ph in self.document.presentation_layout.placeholders:  # type: ignore[attr-defined]
                if ph.kind == kind:
                    return (ph.x, ph.y, ph.cx, ph.cy)
        return (baseline_emu * 2, baseline_emu * 6, slide_width // 3, slide_height // 4)

    def _customize_semantic_slide_ssot(
        self, descriptor: SemanticSlideDescriptor
    ) -> bytes:
        """Render any semantic slide archetype from its descriptor."""
        root = self.templates.read_tree(descriptor.template_name)  # type: ignore[attr-defined]
        slide_width, slide_height = self._get_slide_dimensions_emu()  # type: ignore[attr-defined]
        baseline_emu = self._baseline_emu

        resolved: dict[str, tuple[int, int, int, int]] = {}
        for region_name in descriptor.regions:
            fallback = self._region_fallback(
                region_name, baseline_emu, slide_width, slide_height, resolved
            )
            resolved[region_name] = self._seed_layout_region_rect(region_name, fallback)

        context: dict[str, str] = {}
        for region_name, rect in resolved.items():
            prefix = descriptor.placeholder_context_map.get(region_name)
            if prefix:
                x, y, cx, cy = rect
                context[f"{prefix}_X"] = str(x)
                context[f"{prefix}_Y"] = str(y)
                context[f"{prefix}_CX"] = str(cx)
                context[f"{prefix}_CY"] = str(cy)

        org_id = self.document.org_id  # type: ignore[attr-defined]
        for key, value in descriptor.extra_context.items():
            context[key] = value.format(
                org_id=org_id,
                org_id_upper=org_id.replace("-", " ").upper(),
            )
        context.setdefault("SLIDE_TITLE", f"{org_id} Template")
        context.setdefault("SLIDE_BODY", "")

        replace_placeholders(root, context)

        for region_name, shape_name in descriptor.named_shapes.items():
            self._apply_fill_to_named_shape(
                root,
                shape_name=shape_name,
                fill_tokens=self._selected_decorative_fill(region_name),
            )

        return self._serialize_tree(root)  # type: ignore[attr-defined]

    def _customize_slide_ssot(self, data: bytes) -> bytes:
        """Customize slide via DOM-based placeholder replacement."""
        semantic_spec = get_semantic_layout_spec(self._seed_layout_name())  # type: ignore[attr-defined]
        if semantic_spec is not None and semantic_spec.seed_template_name:
            descriptor = _SEMANTIC_SLIDE_DESCRIPTORS.get(
                semantic_spec.seed_template_name
            )
            if descriptor is not None:
                return self._customize_semantic_slide_ssot(descriptor)
        context = {
            "SLIDE_TITLE": f"{self.document.org_id} Template",  # type: ignore[attr-defined]
            "SLIDE_CONTENT": "Sample slide content",
        }
        return self._render_tree("ssot/slide.xml", context)  # type: ignore[attr-defined]

    # ------------------------------------------------------------------
    # Fill application helpers
    # ------------------------------------------------------------------

    def _seed_layout_region_rect(
        self, name: str, fallback: tuple[int, int, int, int]
    ) -> tuple[int, int, int, int]:
        """Return the selected layout region rectangle or a fallback."""
        resolved = self._resolved_regions_for_layout(self._seed_layout_name()).get(name)  # type: ignore[attr-defined]
        if resolved is None:
            return fallback
        return resolved

    def _selected_decorative_fill(self, region_name: str) -> dict[str, object] | None:
        """Return decorative fill tokens for the selected semantic slide."""
        decoration = self.document.presentation_layout.decoration  # type: ignore[attr-defined]
        if region_name in decoration.decorative_fills:
            return decoration.decorative_fills[region_name]
        if region_name == "background":
            return decoration.background_fill
        if region_name == "overlay":
            return decoration.overlay_fill
        return None

    def _apply_fill_to_named_shape(
        self,
        root: etree._Element,
        *,
        shape_name: str,
        fill_tokens: dict[str, object] | None,
    ) -> None:
        """Apply fill tokens to a named slide shape."""
        if fill_tokens is None:
            return
        shapes = root.xpath(
            f".//p:sp[p:nvSpPr/p:cNvPr[@name='{shape_name}']]",
            namespaces={"p": PRESENTATIONML_NS},
        )
        if not shapes:
            return
        shape: etree._Element = shapes[0]  # type: ignore[assignment]
        if fill_tokens.get("type") == "illustration":
            self._replace_shape_with_illustration(
                root,
                shape=shape,
                shape_name=shape_name,
                fill_tokens=fill_tokens,
            )
            return
        sp_pr: etree._Element | None = shape.find(f"{{{PRESENTATIONML_NS}}}spPr")  # type: ignore[assignment]
        if sp_pr is None:
            return
        emit_fill(sp_pr, fill_tokens)
        append_no_outline(sp_pr)

    def _replace_shape_with_illustration(
        self,
        root: etree._Element,
        *,
        shape: etree._Element,
        shape_name: str,
        fill_tokens: dict[str, object],
    ) -> None:
        """Replace a decorative placeholder shape with an illustration group."""
        shape_xml = fill_tokens.get("shape_xml")
        if not shape_xml:
            sp_pr = shape.find(f"{{{PRESENTATIONML_NS}}}spPr")
            if sp_pr is None:
                return
            emit_fill(sp_pr, fill_tokens)
            append_no_outline(sp_pr)
            return

        parent = shape.getparent()
        if parent is None:
            return
        target_rect = read_shape_rect(shape)
        if target_rect is None:
            return
        insertion_index = parent.index(shape)
        parent.remove(shape)
        group_shape = emit_illustration_group(parent, str(shape_xml))
        parent.remove(group_shape)
        parent.insert(insertion_index, group_shape)

        assign_group_shape_ids(
            root, group_shape, base_name=f"{shape_name} Illustration"
        )
        source_bounds = shape_bounds_in_group(group_shape)
        set_group_rect(
            group_shape,
            target_rect=target_rect,
            source_bounds=source_bounds,
        )
