"""Cell-style and table-style helpers for SpreadsheetML stylesheets."""

from __future__ import annotations

from typing import List, Tuple

from lxml import etree

from tokenmoulds.emitters.excel_constants import (
    SSML_NS,
    _BUILTIN_ACCENT1,
    _BUILTIN_ACCENT1_20,
    _BUILTIN_ACCENT1_40,
    _BUILTIN_ACCENT1_60,
    _BUILTIN_ACCENT2,
    _BUILTIN_ACCENT2_20,
    _BUILTIN_ACCENT2_40,
    _BUILTIN_ACCENT2_60,
    _BUILTIN_ACCENT3,
    _BUILTIN_ACCENT3_20,
    _BUILTIN_ACCENT3_40,
    _BUILTIN_ACCENT3_60,
    _BUILTIN_ACCENT4,
    _BUILTIN_ACCENT4_20,
    _BUILTIN_ACCENT4_40,
    _BUILTIN_ACCENT4_60,
    _BUILTIN_ACCENT5,
    _BUILTIN_ACCENT5_20,
    _BUILTIN_ACCENT5_40,
    _BUILTIN_ACCENT5_60,
    _BUILTIN_ACCENT6,
    _BUILTIN_ACCENT6_20,
    _BUILTIN_ACCENT6_40,
    _BUILTIN_ACCENT6_60,
    _BUILTIN_BAD,
    _BUILTIN_CALCULATION,
    _BUILTIN_CHECK_CELL,
    _BUILTIN_COMMA,
    _BUILTIN_COMMA_0,
    _BUILTIN_CURRENCY,
    _BUILTIN_EXPLANATORY,
    _BUILTIN_FOLLOWED_HYPERLINK,
    _BUILTIN_GOOD,
    _BUILTIN_HEADING1,
    _BUILTIN_HEADING2,
    _BUILTIN_HEADING3,
    _BUILTIN_HEADING4,
    _BUILTIN_HYPERLINK,
    _BUILTIN_INPUT,
    _BUILTIN_NEUTRAL,
    _BUILTIN_NORMAL,
    _BUILTIN_NOTE,
    _BUILTIN_OUTPUT,
    _BUILTIN_PERCENT,
    _BUILTIN_TITLE,
    _BUILTIN_TOTAL,
    _BUILTIN_WARNING,
    _THEME_ACCENT1,
    _THEME_ACCENT2,
    _THEME_ACCENT3,
    _THEME_ACCENT4,
    _THEME_ACCENT5,
    _THEME_ACCENT6,
    _THEME_LT1,
    _TINT_20,
)


def _sub(parent: etree._Element, tag: str, **attribs: str) -> etree._Element:
    """Create a sub-element with attributes."""
    el = etree.SubElement(parent, tag)
    for k, v in attribs.items():
        el.set(k, v)
    return el


class _StyleSheetTablesMixin:
    def _build_cell_styles(self) -> None:
        self._cell_styles = [
            ("Normal", "0", _BUILTIN_NORMAL),
            ("Title", "1", _BUILTIN_TITLE),
            ("Heading 1", "2", _BUILTIN_HEADING1),
            ("Heading 2", "3", _BUILTIN_HEADING2),
            ("Heading 3", "4", _BUILTIN_HEADING3),
            ("Heading 4", "5", _BUILTIN_HEADING4),
            ("Total", "6", _BUILTIN_TOTAL),
            ("Note", "7", _BUILTIN_NOTE),
            ("Explanatory Text", "8", _BUILTIN_EXPLANATORY),
            ("Hyperlink", "9", _BUILTIN_HYPERLINK),
            ("Followed Hyperlink", "10", _BUILTIN_FOLLOWED_HYPERLINK),
        ]

        # Accent styles: 6 accents × 4 variants
        accent_names = [
            "Accent1",
            "Accent2",
            "Accent3",
            "Accent4",
            "Accent5",
            "Accent6",
        ]
        accent_builtins = [
            (
                _BUILTIN_ACCENT1,
                _BUILTIN_ACCENT1_20,
                _BUILTIN_ACCENT1_40,
                _BUILTIN_ACCENT1_60,
            ),
            (
                _BUILTIN_ACCENT2,
                _BUILTIN_ACCENT2_20,
                _BUILTIN_ACCENT2_40,
                _BUILTIN_ACCENT2_60,
            ),
            (
                _BUILTIN_ACCENT3,
                _BUILTIN_ACCENT3_20,
                _BUILTIN_ACCENT3_40,
                _BUILTIN_ACCENT3_60,
            ),
            (
                _BUILTIN_ACCENT4,
                _BUILTIN_ACCENT4_20,
                _BUILTIN_ACCENT4_40,
                _BUILTIN_ACCENT4_60,
            ),
            (
                _BUILTIN_ACCENT5,
                _BUILTIN_ACCENT5_20,
                _BUILTIN_ACCENT5_40,
                _BUILTIN_ACCENT5_60,
            ),
            (
                _BUILTIN_ACCENT6,
                _BUILTIN_ACCENT6_20,
                _BUILTIN_ACCENT6_40,
                _BUILTIN_ACCENT6_60,
            ),
        ]
        xf_base = 11  # first accent cellStyleXf
        for i, (name, builtins) in enumerate(zip(accent_names, accent_builtins)):
            xf_offset = xf_base + i * 4
            self._cell_styles.append((name, str(xf_offset), builtins[0]))
            self._cell_styles.append((f"20% - {name}", str(xf_offset + 1), builtins[1]))
            self._cell_styles.append((f"40% - {name}", str(xf_offset + 2), builtins[2]))
            self._cell_styles.append((f"60% - {name}", str(xf_offset + 3), builtins[3]))

        # Semantic styles
        self._cell_styles.extend(
            [
                ("Good", "35", _BUILTIN_GOOD),
                ("Bad", "36", _BUILTIN_BAD),
                ("Neutral", "37", _BUILTIN_NEUTRAL),
                ("Input", "38", _BUILTIN_INPUT),
                ("Output", "39", _BUILTIN_OUTPUT),
                ("Calculation", "40", _BUILTIN_CALCULATION),
                ("Check Cell", "41", _BUILTIN_CHECK_CELL),
                ("Warning Text", "42", _BUILTIN_WARNING),
            ]
        )

        # Number format styles
        self._cell_styles.extend(
            [
                ("Comma", "43", _BUILTIN_COMMA),
                ("Comma [0]", "44", _BUILTIN_COMMA_0),
                ("Currency", "45", _BUILTIN_CURRENCY),
                ("Percent", "46", _BUILTIN_PERCENT),
            ]
        )

    # -- Table styles ---------------------------------------------------------

    def _build_table_styles(self, root: etree._Element) -> None:
        """Add 6 accent table styles to the stylesheet.

        Each table style has: headerRow, firstRowStripe, secondRowStripe,
        totalRow, firstColumn, lastColumn — all using theme-linked colors.
        """
        accent_names = [
            "Accent1",
            "Accent2",
            "Accent3",
            "Accent4",
            "Accent5",
            "Accent6",
        ]
        accent_themes = [
            _THEME_ACCENT1,
            _THEME_ACCENT2,
            _THEME_ACCENT3,
            _THEME_ACCENT4,
            _THEME_ACCENT5,
            _THEME_ACCENT6,
        ]

        # We need dxfs (differential formatting) for table style elements
        dxfs_el = _sub(root, "dxfs", count=str(len(accent_themes) * 6))

        dxf_idx = 0
        table_style_entries: List[Tuple[str, List[Tuple[str, int]]]] = []

        for accent_name, theme_idx in zip(accent_names, accent_themes):
            elements: List[Tuple[str, int]] = []

            # headerRow: solid accent fill, white text, bold
            dxf = etree.SubElement(dxfs_el, "dxf")
            font = etree.SubElement(dxf, "font")
            _sub(font, "b", val="1")
            _sub(font, "color", theme=_THEME_LT1)
            fill = etree.SubElement(dxf, "fill")
            pf = _sub(fill, "patternFill", patternType="solid")
            _sub(pf, "fgColor", theme=theme_idx)
            _sub(pf, "bgColor", theme=theme_idx)
            elements.append(("headerRow", dxf_idx))
            dxf_idx += 1

            # firstRowStripe: light tint
            dxf = etree.SubElement(dxfs_el, "dxf")
            fill = etree.SubElement(dxf, "fill")
            pf = _sub(fill, "patternFill", patternType="solid")
            _sub(pf, "fgColor", theme=theme_idx, tint=_TINT_20)
            _sub(pf, "bgColor", theme=theme_idx, tint=_TINT_20)
            elements.append(("firstRowStripe", dxf_idx))
            dxf_idx += 1

            # secondRowStripe: white (no fill)
            dxf = etree.SubElement(dxfs_el, "dxf")
            elements.append(("secondRowStripe", dxf_idx))
            dxf_idx += 1

            # totalRow: bold, top border
            dxf = etree.SubElement(dxfs_el, "dxf")
            font = etree.SubElement(dxf, "font")
            _sub(font, "b", val="1")
            border = etree.SubElement(dxf, "border")
            top = _sub(border, "top", style="thin")
            _sub(top, "color", theme=theme_idx)
            elements.append(("totalRow", dxf_idx))
            dxf_idx += 1

            # firstColumn + lastColumn: bold
            for col_key in ("firstColumnStripe", "secondColumnStripe"):
                dxf = etree.SubElement(dxfs_el, "dxf")
                font = etree.SubElement(dxf, "font")
                _sub(font, "b", val="1")
                elements.append((col_key, dxf_idx))
                dxf_idx += 1

            table_style_entries.append((f"TokenMoulds {accent_name}", elements))

        # tableStyles element
        ts_el = _sub(
            root,
            "tableStyles",
            count=str(len(table_style_entries)),
            defaultTableStyle=table_style_entries[0][0],
            defaultPivotStyle="PivotStyleLight16",
        )
        for style_name, elements in table_style_entries:
            ts = _sub(
                ts_el,
                "tableStyle",
                name=style_name,
                count=str(len(elements)),
                pivot="0",
                table="1",
            )
            for element_type, dxf_id in elements:
                _sub(ts, "tableStyleElement", type=element_type, dxfId=str(dxf_id))

    # -- Serialization --------------------------------------------------------

    def _serialize(self) -> bytes:
        root = etree.Element("styleSheet", xmlns=SSML_NS)

        # numFmts (custom formats for non-US locales)
        if self._numfmts:
            nf_el = _sub(root, "numFmts", count=str(len(self._numfmts)))
            for fmt_id, fmt_code in self._numfmts:
                _sub(nf_el, "numFmt", numFmtId=fmt_id, formatCode=fmt_code)

        # fonts
        fonts_el = _sub(root, "fonts", count=str(len(self._fonts)))
        for f in self._fonts:
            fonts_el.append(f)

        # fills
        fills_el = _sub(root, "fills", count=str(len(self._fills)))
        for f in self._fills:
            fills_el.append(f)

        # borders
        borders_el = _sub(root, "borders", count=str(len(self._borders)))
        for b in self._borders:
            borders_el.append(b)

        # cellStyleXfs
        csxf_el = _sub(root, "cellStyleXfs", count=str(len(self._cell_style_xfs)))
        for xf in self._cell_style_xfs:
            csxf_el.append(xf)

        # cellXfs
        cxf_el = _sub(root, "cellXfs", count=str(len(self._cell_xfs)))
        for xf in self._cell_xfs:
            cxf_el.append(xf)

        # cellStyles
        cs_el = _sub(root, "cellStyles", count=str(len(self._cell_styles)))
        for name, xf_id, builtin_id in self._cell_styles:
            _sub(cs_el, "cellStyle", name=name, xfId=xf_id, builtinId=builtin_id)

        # dxfs + tableStyles
        self._build_table_styles(root)

        return etree.tostring(root, xml_declaration=False, encoding="unicode").encode(
            "utf-8"
        )
