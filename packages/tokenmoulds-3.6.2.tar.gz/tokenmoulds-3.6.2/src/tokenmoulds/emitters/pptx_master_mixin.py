"""Slide-master PowerPoint emitter customizations."""

from __future__ import annotations

import logging
from copy import deepcopy
from pathlib import Path
from typing import Dict

from lxml import etree

from tokenmoulds.design.units import pt_to_hundredths, twips_to_emu
from tokenmoulds.dtcg.layout_recipe_resolver import get_semantic_layout_spec
from tokenmoulds.emitters.xml_helpers import (
    A_NS,
    R_NS,
    clone_template_element,
    replace_placeholders,
)
from tokenmoulds.ir import SlidePlaceholder
from tokenmoulds.themes.tables import (
    TableStyleGenerator,
    TableTextTokens,
    derive_table_style_from_brand_tone,
)

PRESENTATIONML_NS = "http://schemas.openxmlformats.org/presentationml/2006/main"
PACKAGE_REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"
SLIDE_LAYOUT_REL_TYPE = (
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout"
)
THEME_REL_TYPE = (
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme"
)
STANDARD_LAYOUT_NUMBER_BY_NAME = {
    "title_slide": 1,
    "title_content": 2,
    "section_header": 3,
    "two_content": 4,
    "comparison": 5,
    "title_only": 6,
    "blank": 7,
    "content_caption": 8,
    "picture_caption": 9,
    "vertical_text": 10,
    "vertical_title": 11,
}
IMAGE_REL_TYPE = (
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image"
)

logger = logging.getLogger(__name__)


class PowerPointMasterMixin:
    def _add_extra_color_schemes(self, root: etree._Element) -> None:
        """Add extra color schemes using SSOT clone pattern.

        Uses the clone_template_element pattern to create extra color schemes
        from the template in ssot/theme.xml rather than programmatic element
        creation. This maintains SSOT consistency across all emitters.
        """
        ns = {"a": A_NS}

        # Find the extraClrSchemeLst element
        extra_lst = self._find_element(root, ".//a:extraClrSchemeLst", ns)
        if extra_lst is None:
            return

        for extra_theme in self.extra_color_themes:
            theme = extra_theme.theme

            # Clone the extra color scheme template
            extra_scheme = clone_template_element(root, "extra_color_scheme")

            # Replace all placeholders with theme colors
            replace_placeholders(
                extra_scheme,
                {
                    "SCHEME_NAME": extra_theme.name,
                    "DK1": theme.dk1.lstrip("#").upper(),
                    "LT1": theme.lt1.lstrip("#").upper(),
                    "DK2": theme.dk2.lstrip("#").upper(),
                    "LT2": theme.lt2.lstrip("#").upper(),
                    "ACCENT1": theme.accent1.lstrip("#").upper(),
                    "ACCENT2": theme.accent2.lstrip("#").upper(),
                    "ACCENT3": theme.accent3.lstrip("#").upper(),
                    "ACCENT4": theme.accent4.lstrip("#").upper(),
                    "ACCENT5": theme.accent5.lstrip("#").upper(),
                    "ACCENT6": theme.accent6.lstrip("#").upper(),
                    "HLINK": theme.hyperlink.lstrip("#").upper(),
                    "FOLHLINK": theme.hyperlink_followed.lstrip("#").upper(),
                },
            )

            extra_lst.append(extra_scheme)

    def _customize_slide_master_ssot(self, data: bytes) -> bytes:
        """Customize slide master via DOM-based placeholder replacement.

        All values come from the Document IR (SSOT pattern).
        Trivial unit conversions: pt → hundredths, twips → EMU.
        """

        # =================================================================
        # Extract IR values
        # =================================================================
        typo = self.document.typography
        layout = self.document.presentation_layout
        list_style = self.document.list_style
        body_style = self.document.body_style

        # =================================================================
        # Build substitution dictionary
        # =================================================================
        subs: Dict[str, str] = {}

        # --- Locale ---
        subs["LANG"] = self.document.locale

        # --- Kerning (used across all text styles) ---
        # Half-points * 50 = hundredths (8hp = 400 hundredths)
        subs["KERN_THRESHOLD"] = str(body_style.character.kern_threshold_half_pt * 50)

        # --- Tab size (EMU) ---
        subs["TAB_SIZE"] = str(
            self.document.document_settings.default_tab_stop_twips * 635
        )

        # --- Text insets (EMU) ---
        # Default PowerPoint insets: 91440 EMU (0.1") left/right, 45720 EMU (0.05") top/bottom
        subs["TEXT_INSET_LEFT"] = str(91440)
        subs["TEXT_INSET_TOP"] = str(45720)
        subs["TEXT_INSET_RIGHT"] = str(91440)
        subs["TEXT_INSET_BOTTOM"] = str(45720)

        # --- Title placeholder geometry (EMU) ---
        title_ph = self._resolve_master_placeholder("title")
        if title_ph:
            subs["TITLE_X"] = str(title_ph.x)
            subs["TITLE_Y"] = str(title_ph.y)
            subs["TITLE_WIDTH"] = str(title_ph.cx)
            subs["TITLE_HEIGHT"] = str(title_ph.cy)
        else:
            # Fallback to standard dimensions
            subs["TITLE_X"] = "457200"
            subs["TITLE_Y"] = "274638"
            subs["TITLE_WIDTH"] = "8229600"
            subs["TITLE_HEIGHT"] = "1143000"

        # --- Body placeholder geometry (EMU) ---
        body_ph = self._resolve_master_placeholder("body")
        if body_ph:
            subs["BODY_X"] = str(body_ph.x)
            subs["BODY_Y"] = str(body_ph.y)
            subs["BODY_WIDTH"] = str(body_ph.cx)
            subs["BODY_HEIGHT"] = str(body_ph.cy)
        else:
            # Fallback to standard dimensions
            subs["BODY_X"] = "457200"
            subs["BODY_Y"] = "1600200"
            subs["BODY_WIDTH"] = "8229600"
            subs["BODY_HEIGHT"] = "4525963"

        # --- Title font size (hundredths of a point) ---
        title_pt = typo.size_map_pt.get("h1", 44.0)
        subs["TITLE_FONT_SIZE"] = str(pt_to_hundredths(title_pt))

        # --- Body font sizes for levels (hundredths of a point) ---
        # Use modular scale from typography scheme, fallback to standard sizes
        subs["BODY_L1_FONT_SIZE"] = str(
            pt_to_hundredths(typo.size_map_pt.get("h3", 32.0))
        )
        subs["BODY_L2_FONT_SIZE"] = str(
            pt_to_hundredths(typo.size_map_pt.get("h4", 28.0))
        )
        subs["BODY_L3_FONT_SIZE"] = str(
            pt_to_hundredths(typo.size_map_pt.get("h5", 24.0))
        )

        # --- Body list margins (EMU) ---
        # Convert list indentation from twips to EMU
        base_indent = list_style.indent_twips
        subs["BODY_L1_MAR_LEFT"] = str(twips_to_emu(base_indent))
        subs["BODY_L2_MAR_LEFT"] = str(
            twips_to_emu(base_indent + list_style.effective_indent_per_level)
        )
        subs["BODY_L3_MAR_LEFT"] = str(
            twips_to_emu(base_indent + 2 * list_style.effective_indent_per_level)
        )

        # --- Body list hanging indents (EMU) ---
        hanging = list_style.hanging_twips
        subs["BODY_L1_INDENT"] = str(twips_to_emu(hanging))
        subs["BODY_L2_INDENT"] = str(twips_to_emu(hanging))
        subs["BODY_L3_INDENT"] = str(twips_to_emu(hanging))

        # --- Body spacing (percentage × 1000) ---
        # 20000 = 20% of line height
        subs["BODY_SPACE_BEFORE"] = "20000"

        # --- Bullet characters ---
        bullets = list_style.nested_bullet_chars
        subs["BULLET_L1_CHAR"] = bullets[0] if len(bullets) > 0 else "•"
        subs["BULLET_L2_CHAR"] = bullets[1] if len(bullets) > 1 else "–"
        subs["BULLET_L3_CHAR"] = bullets[2] if len(bullets) > 2 else "•"

        # --- Bullet font ---
        subs["BULLET_FONT"] = list_style.bullet_font or "Arial"
        subs["BULLET_PITCH_FAMILY"] = "34"  # Variable pitch, Swiss family
        subs["BULLET_CHARSET"] = "0"  # ANSI

        # --- Table defaults (otherStyle) ---
        # Use body style for tables (table_style was removed from IR)
        subs["TABLE_FONT_SIZE"] = str(pt_to_hundredths(body_style.font_size_pt))
        subs["TABLE_FONT"] = body_style.font_family

        # =================================================================
        # Extended typography settings (from Document IR)
        # =================================================================

        # --- RTL and locale settings ---
        locale_settings = self.document.locale_settings
        subs["RTL"] = "1" if locale_settings.rtl else "0"
        subs["EA_LN_BRK"] = "1" if locale_settings.ea_ln_brk else "0"
        subs["LATIN_LN_BRK"] = "1" if locale_settings.latin_ln_brk else "0"
        subs["HANGING_PUNCT"] = "1" if locale_settings.hanging_punct else "0"

        # --- Text alignment ---
        alignment = self.document.text_alignment
        subs["TITLE_ALIGN"] = alignment.title_horizontal
        subs["BODY_ALIGN"] = alignment.body_horizontal
        subs["TITLE_ANCHOR"] = alignment.title_vertical
        subs["BODY_ANCHOR"] = alignment.body_vertical

        # --- Tracking / letter spacing (hundredths of EMU) ---
        # Convert from 1/100 em to EMU (at body size: 1em = body_size_pt * 12700 EMU)
        tracking = self.document.tracking
        # For PowerPoint, tracking is in hundredths of a point (like font size)
        # Title uses display tracking, body uses body tracking
        subs["TITLE_TRACKING"] = str(tracking.display * 10)  # Approximate conversion
        subs["BODY_TRACKING"] = str(tracking.body * 10)

        # --- Font fallbacks for international text ---
        fallback = self.document.fallback_fonts
        subs["EA_FONT"] = fallback.ea_font
        subs["CS_FONT"] = fallback.cs_font

        # --- Body font: use baked variant if available ---
        baked_body = next(
            (f.family_name for f in self.embedded_fonts if "Body" in f.family_name),
            None,
        )
        subs["BODY_LATIN_TYPEFACE"] = baked_body if baked_body else "+mn-lt"

        # =================================================================
        root = self.templates.read_tree("ssot/slide_master.xml")
        replace_placeholders(root, subs)

        layout_id_list = root.find(f"{{{PRESENTATIONML_NS}}}sldLayoutIdLst")
        if layout_id_list is not None:
            existing_layouts = layout_id_list.findall(
                f"{{{PRESENTATIONML_NS}}}sldLayoutId"
            )
            layout_template = existing_layouts[0] if existing_layouts else None
            for layout in existing_layouts:
                layout_id_list.remove(layout)

            if layout_template is not None:
                base_layout_id = 2147483649
                for rel_index, _layout_number in enumerate(
                    self.DEFAULT_SLIDE_LAYOUT_NUMBERS
                ):
                    layout_ref = deepcopy(layout_template)
                    layout_ref.set("id", str(base_layout_id + rel_index))
                    layout_ref.set(f"{{{R_NS}}}id", f"rId{rel_index + 1}")
                    layout_id_list.append(layout_ref)

        return self._serialize_tree(root)

    def _resolve_master_placeholder(self, kind: str):
        """Return title/body placeholder geometry for slide-master inheritance."""
        layout = self.document.presentation_layout
        if self._should_recompute_master_placeholders():
            recomputed = self._build_master_placeholders_for_current_slide()
            return next((p for p in recomputed if p.kind == kind), None)
        return next((p for p in layout.placeholders if p.kind == kind), None)

    def _should_recompute_master_placeholders(self) -> bool:
        """Detect stale master placeholders after slide-size-only overrides."""
        from tokenmoulds.design.layout_defaults import (
            SLIDE_4_3_HEIGHT_EMU,
            SLIDE_4_3_WIDTH_EMU,
            SLIDE_16_9_HEIGHT_EMU,
            SLIDE_16_9_WIDTH_EMU,
        )

        if self.document.page_geometry is not None:
            return False

        slide_width, slide_height = self._get_slide_dimensions_emu()
        has_legacy_table = any(
            placeholder.kind == "table"
            for placeholder in self.document.presentation_layout.placeholders
        )
        default_size = (
            (SLIDE_4_3_WIDTH_EMU, SLIDE_4_3_HEIGHT_EMU)
            if has_legacy_table
            else (SLIDE_16_9_WIDTH_EMU, SLIDE_16_9_HEIGHT_EMU)
        )
        return (slide_width, slide_height) != default_size

    def _build_master_placeholders_for_current_slide(self):
        """Recompute generic title/body placeholders from the current slide size."""
        from tokenmoulds.design.page_geometry import create_slide_grid
        from tokenmoulds.dtcg.layout_recipe_defaults import compute_default_slide_regions
        from tokenmoulds.dtcg.layout_recipe_resolver import resolve_layout_by_name

        slide_width, slide_height = self._get_slide_dimensions_emu()
        baseline_emu = self._baseline_emu
        grid = create_slide_grid(
            slide_width_emu=slide_width,
            slide_height_emu=slide_height,
            baseline_grid_emu=baseline_emu,
        )
        regions = compute_default_slide_regions(grid)
        positions = resolve_layout_by_name(
            "title_content", regions.get("title_content", {}), grid
        )
        tx, ty, tw, th = positions["title"]
        bx, by, bw, bh = positions["body"]
        return [
            SlidePlaceholder(kind="title", x=tx, y=ty, cx=tw, cy=th, text_style="h1"),
            SlidePlaceholder(kind="body", x=bx, y=by, cx=bw, cy=bh, text_style="body"),
        ]

    def _seed_layout_name(self) -> str:
        """Return the selected seeded slide layout name."""
        return getattr(
            self.document.presentation_layout, "layout_name", "title_content"
        )

    def _resolve_seed_slide_layout_number(self) -> int:
        """Return the slide layout part number for the seeded sample slide."""
        layout_name = self._seed_layout_name()
        semantic_spec = get_semantic_layout_spec(layout_name)
        if semantic_spec is not None:
            if semantic_spec.pptx_layout_number is not None:
                return semantic_spec.pptx_layout_number
            layout_name = semantic_spec.fallback_standard_layout
        return STANDARD_LAYOUT_NUMBER_BY_NAME.get(layout_name, 2)

    def _customize_slide_rels_ssot(self, data: bytes) -> bytes:
        """Point the seeded slide at the requested standard or semantic layout."""
        root = self.templates.read_tree("ssot/slide_rels.xml")
        relationship = root.find(f"{{{PACKAGE_REL_NS}}}Relationship")
        if relationship is not None:
            relationship.set(
                "Target",
                f"../slideLayouts/slideLayout{self._resolve_seed_slide_layout_number()}.xml",
            )
        for relationship_id, archive_path in self._slide_media_relationships:
            rel = etree.SubElement(root, f"{{{PACKAGE_REL_NS}}}Relationship")
            rel.set("Id", relationship_id)
            rel.set("Type", IMAGE_REL_TYPE)
            rel.set("Target", f"../media/{Path(archive_path).name}")
        return self._serialize_tree(root)

    def _customize_table_styles_ssot(self, data: bytes) -> bytes:
        """Generate typographically correct table styles derived from brand tone.

        Creates table styles following typographic principles:
        - No outer vertical borders
        - Horizontal rules only (top, header separator, bottom)
        - Header and banding intensity based on brand_tone

        All colors reference theme tokens so styles adapt to brand colors.
        """
        # Create text tokens from document typography
        text_tokens = TableTextTokens(
            font_family=self.document.typography.body_font,
            body_size_pt=self.document.body_style.font_size_pt,
            header_size_pt=self.document.body_style.font_size_pt + 1.0,
            header_bold=True,
        )
        generator = TableStyleGenerator(text_tokens)

        # Derive table style from brand tone
        table_style = derive_table_style_from_brand_tone(
            brand_tone=self.document.brand_tone,
            border_width_pt=0.75,
        )

        # Generate tableStyles.xml
        table_styles_bytes = generator.generate_table_styles_xml(
            [table_style],
            table_style.style_id,
        )

        logger.info(
            f"Generated typographically correct table style "
            f"(brand_tone={self.document.brand_tone:.2f})"
        )
        return table_styles_bytes

    def _customize_core_props_ssot(self, data: bytes) -> bytes:
        """Customize core properties via DOM-based placeholder replacement."""
        timestamp = self._utc_timestamp()
        context = {
            "TITLE": self._get_document_title(),
            "CREATOR": "TokenMoulds",
            "MODIFIER": "TokenMoulds",
            "TIMESTAMP": timestamp,
        }
        return self._render_tree("ssot/docprops_core.xml", context)

    def _customize_app_props_ssot(self, data: bytes) -> bytes:
        """Customize app properties via DOM-based placeholder replacement."""
        context = {
            "APPLICATION": "TokenMoulds",
            "COMPANY": self.document.org_id,
        }
        return self._render_tree("ssot/docprops_app.xml", context)
