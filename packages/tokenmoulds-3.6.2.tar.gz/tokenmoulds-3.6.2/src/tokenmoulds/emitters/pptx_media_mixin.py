"""Media asset resolution mixin for the PowerPoint emitter.

Handles photo downloads (Pexels), illustration fetches (unDraw), and
media relationship registration before package assembly.
"""

from __future__ import annotations

import logging
from copy import deepcopy
from typing import TYPE_CHECKING

from tokenmoulds.packaging import MediaAsset

if TYPE_CHECKING:
    from tokenmoulds.ir import SemanticSlideDecoration

logger = logging.getLogger(__name__)


class PowerPointMediaMixin:
    """Mixin providing media asset resolution for semantic slide fills."""

    _base_decoration: SemanticSlideDecoration
    _slide_media_assets: list[MediaAsset]
    _slide_media_relationships: list[tuple[str, str]]

    def _init_media(self, decoration: SemanticSlideDecoration) -> None:
        """Initialise media state — call from ``__init__``."""
        self._base_decoration = deepcopy(decoration)
        self._slide_media_assets = []
        self._slide_media_relationships = []

    def _prepare_semantic_media_assets(self) -> None:
        """Resolve photo and illustration assets for the selected semantic slide."""
        layout = self.document.presentation_layout  # type: ignore[attr-defined]
        layout.decoration = deepcopy(self._base_decoration)
        self._slide_media_assets = []
        self._slide_media_relationships = []

        prepared: dict[str, dict[str, object]] = {}
        for region_name, fill_tokens in layout.decoration.decorative_fills.items():
            prepared[region_name] = self._prepare_fill_asset(region_name, fill_tokens)

        layout.decoration.decorative_fills = prepared
        layout.decoration.background_fill = prepared.get("background")
        layout.decoration.overlay_fill = prepared.get("overlay")

    def _prepare_fill_asset(
        self,
        region_name: str,
        fill_tokens: dict[str, object],
    ) -> dict[str, object]:
        """Resolve emitter-side assets required by a semantic decorative fill."""
        prepared = deepcopy(fill_tokens)
        fill_type = str(prepared.get("type", ""))

        if fill_type == "photo" and not prepared.get("relationship_id"):
            from tokenmoulds.media.pexels import (
                PexelsUnavailableError,
                download_photo,
                search_photos,
            )

            try:
                image_url = prepared.get("url")
                if not image_url:
                    query = str(prepared.get("query", "")).strip()
                    if not query:
                        raise PexelsUnavailableError("photo fill is missing a query")
                    color = prepared.get("color")
                    results = search_photos(
                        query,
                        color=str(color) if isinstance(color, str) else None,
                        orientation=str(prepared.get("orientation", "landscape")),
                        per_page=1,
                    )
                    if not results:
                        raise PexelsUnavailableError(
                            f"no photo results for query {query!r}"
                        )
                    image_url = results[0].url
                image_bytes = download_photo(
                    str(image_url),
                    preset=str(prepared.get("preset", "presentation_bg")),
                )
                prepared["relationship_id"] = self._register_slide_media_asset(
                    region_name=region_name,
                    data=image_bytes,
                    extension="jpg",
                    content_type="image/jpeg",
                )
            except Exception as exc:
                logger.warning(
                    "Failed to resolve photo fill for %s on %s: %s",
                    region_name,
                    self._seed_layout_name(),  # type: ignore[attr-defined]
                    exc,
                )

        if fill_type == "illustration" and not prepared.get("shape_xml"):
            from tokenmoulds.media.undraw import (
                IllustrationUnavailableError,
                fetch_illustration,
            )

            try:
                name = str(prepared.get("name", "")).strip()
                if not name:
                    raise IllustrationUnavailableError(
                        "illustration fill is missing a name"
                    )
                color_map = prepared.get("color_map")
                theme_color = prepared.get("color")
                prepared["shape_xml"] = fetch_illustration(
                    name,
                    theme_color=(
                        str(theme_color)
                        if isinstance(theme_color, str)
                        and not str(theme_color).startswith("#")
                        else "accent1"
                    ),
                    color_map=color_map if isinstance(color_map, dict) else None,
                )
            except Exception as exc:
                logger.warning(
                    "Failed to resolve illustration fill for %s on %s: %s",
                    region_name,
                    self._seed_layout_name(),  # type: ignore[attr-defined]
                    exc,
                )

        return prepared

    def _register_slide_media_asset(
        self,
        *,
        region_name: str,
        data: bytes,
        extension: str,
        content_type: str,
    ) -> str:
        """Register a media asset and return the slide relationship id."""
        asset_index = len(self._slide_media_assets) + 1
        archive_path = f"ppt/media/{region_name}_{asset_index}.{extension}"
        relationship_id = f"rId{len(self._slide_media_relationships) + 2}"
        self._slide_media_assets.append(
            MediaAsset(
                archive_path=archive_path,
                data=data,
                content_type=content_type,
                source=region_name,
            )
        )
        self._slide_media_relationships.append((relationship_id, archive_path))
        return relationship_id
