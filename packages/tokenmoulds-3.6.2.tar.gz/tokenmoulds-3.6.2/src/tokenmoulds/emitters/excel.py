"""Excel template emitter from the Document IR.

Uses SSOT (Single Source of Truth) pattern: XML structure from xml-structures/,
Python modifies attribute values via lxml DOM manipulation with cached templates.
Excel does not support font embedding, so font-related hooks are no-ops.

Cell styles generated:
- Normal (body font, body size)
- Title, Heading 1-4 (heading font, scaled sizes)
- Total (body font, bold, top border)
- Note, Explanatory Text (body font, smaller/italic)
- Accent 1-6, 20%/40%/60% tints (themed fills)
- Comma, Currency, Percent (number formats)
- Hyperlink, Followed Hyperlink
- Good, Bad, Neutral (semantic colors)
- Input, Output, Calculation, Check Cell, Warning Text

Table styles: 6 accent variants with header row, banded rows, total row.
Locale-aware: page setup (A4/Letter), margins, number formats, header/footer.
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, Literal


from tokenmoulds.emitters.excel_stylesheet import (
    _StyleSheetBuilder,
)
from tokenmoulds.emitters.excel_helpers import (
    _quote_sheet_name_for_formula,
)
from tokenmoulds.emitters.excel_workbook_mixin import ExcelWorkbookMixin
from tokenmoulds.emitters.ooxml_base import OOXMLBaseEmitter
from tokenmoulds.emitters.xml_helpers import (
    replace_placeholders,
    serialize_tree,
)
from tokenmoulds.ir import DocumentIR
from tokenmoulds.ir.excel_layout import ExcelSheet




class ExcelEmitter(ExcelWorkbookMixin, OOXMLBaseEmitter):
    """Build Excel workbooks from the Document IR.

    Generates themed cell styles visible in Excel's Home > Cell Styles gallery:
    - Title, Heading 1-4 (heading font, scaled from type scale)
    - 6 accent colors × 4 variants (solid, 20%, 40%, 60%)
    - Good/Bad/Neutral semantic styles
    - Input/Output/Calculation/Check Cell/Warning
    - Comma, Currency, Percent number formats
    - Hyperlink, Followed Hyperlink
    - Note, Explanatory Text, Total
    """

    PACKAGE_STRUCTURE: Dict[str, str] = {
        "[Content_Types].xml": "templates/content_types.xml",
        "_rels/.rels": "templates/package_rels.xml",
        "xl/workbook.xml": "templates/workbook.xml",
        "xl/styles.xml": "templates/styles.xml",
        "xl/worksheets/sheet1.xml": "templates/worksheet.xml",
        "xl/worksheets/_rels/sheet1.xml.rels": "templates/worksheet_rels.xml",
        "xl/tables/table1.xml": "templates/table.xml",
        "xl/drawings/drawing1.xml": "templates/drawing.xml",
        "xl/drawings/_rels/drawing1.xml.rels": "templates/drawing_rels.xml",
        "xl/charts/chart1.xml": "templates/chart.xml",
        "xl/theme/theme1.xml": "templates/theme.xml",
        "xl/_rels/workbook.xml.rels": "templates/workbook_rels.xml",
        "docProps/core.xml": "templates/docprops_core.xml",
        "docProps/app.xml": "templates/docprops_app.xml",
    }

    # Sample table wired into the worksheet. A:C, 1 header + 3 data rows.
    # Numeric values in column B drive the accent-colored sample chart.
    _TABLE_NAME = "SummaryTable"
    _TABLE_REF = "A1:C4"
    _TABLE_STYLE = "TokenMoulds Accent1"
    _TABLE_COLUMNS = ("Quarter", "Revenue", "Notes")
    _SAMPLE_CATEGORIES = ("Q1", "Q2", "Q3")
    _SAMPLE_VALUES = (120.0, 180.0, 240.0)
    _SAMPLE_NOTES = ("Baseline quarter", "Launch uplift", "Scale phase")

    def __init__(
        self,
        document: DocumentIR,
        template_root: Path | str | None = None,
        use_pure_text_colors: bool = True,
    ) -> None:
        super().__init__(
            document=document,
            template_root=template_root,
            embed_fonts=False,
            fonts_dir=None,
            use_pure_text_colors=use_pure_text_colors,
        )

    def _get_format_key(self) -> str:
        return "excel"

    def _get_base_template_path(self) -> Path:
        return Path()

    def _get_package_structure(self) -> Dict[str, str]:
        return self.PACKAGE_STRUCTURE

    def _get_document_title(self) -> str:
        return f"{self.document.org_id} Workbook"

    def _get_font_embedding_format(self) -> Literal["odttf", "eot", "none"]:
        return "none"

    def _get_font_entries_path(self) -> str:
        return ""

    def _resolved_sheets(self) -> list[ExcelSheet]:
        """Return the list of sheets to emit, auto-filling a primary when empty.

        - Empty IR list = single implicit primary sheet named after org_id.
        - Non-empty IR list = sheets[0] is treated as the primary (gets the
          table + chart) and sheets[1:] are rendered as simple content sheets.
        """
        configured = self.document.excel_sheets
        if configured:
            return list(configured)
        return [ExcelSheet(name=self.document.org_id, role="primary")]

    def _is_multi_sheet(self) -> bool:
        return len(self._resolved_sheets()) > 1

    def _should_customize_entry(self, entry_path: str) -> bool:
        base = {
            "xl/theme/theme1.xml",
            "xl/styles.xml",
            "xl/worksheets/sheet1.xml",
            "xl/tables/table1.xml",
            "xl/charts/chart1.xml",
            "xl/workbook.xml",
            "docProps/core.xml",
            "docProps/app.xml",
        }
        if self._is_multi_sheet():
            base.add("xl/_rels/workbook.xml.rels")
            base.add("[Content_Types].xml")
        return entry_path in base

    def _customize_entry(self, entry_path: str, data: bytes) -> bytes | None:
        if entry_path == "xl/theme/theme1.xml":
            return self._customize_theme_ssot(data)
        elif entry_path == "xl/styles.xml":
            return self._customize_styles(data)
        elif entry_path == "xl/worksheets/sheet1.xml":
            return self._customize_worksheet_ssot(data)
        elif entry_path == "xl/tables/table1.xml":
            return self._customize_table_ssot(data)
        elif entry_path == "xl/charts/chart1.xml":
            return self._customize_chart_ssot(data)
        elif entry_path == "xl/workbook.xml":
            return self._customize_workbook_ssot(data)
        elif entry_path == "xl/_rels/workbook.xml.rels":
            return self._customize_workbook_rels_ssot(data)
        elif entry_path == "[Content_Types].xml":
            return self._customize_content_types_ssot(data)
        elif entry_path == "docProps/core.xml":
            return self._customize_core_props_ssot(data)
        elif entry_path == "docProps/app.xml":
            return self._customize_app_props_ssot(data)
        return data

    def _customize_table_ssot(self, data: bytes) -> bytes:
        context = {
            "TABLE_NAME": self._TABLE_NAME,
            "TABLE_REF": self._TABLE_REF,
            "TABLE_STYLE": self._TABLE_STYLE,
            "COL1": self._TABLE_COLUMNS[0],
            "COL2": self._TABLE_COLUMNS[1],
            "COL3": self._TABLE_COLUMNS[2],
        }
        root = self.templates.read_tree("templates/table.xml")
        replace_placeholders(root, context)
        return serialize_tree(root, xml_declaration=False)

    def _customize_chart_ssot(self, data: bytes) -> bytes:
        cats = self._SAMPLE_CATEGORIES
        vals = self._SAMPLE_VALUES
        sheet_ref = _quote_sheet_name_for_formula(self._resolved_sheets()[0].name)
        context = {
            "CHART_TITLE": f"{self.document.org_id.title()} Quarterly Revenue",
            "SERIES_NAME": self._TABLE_COLUMNS[1],
            "SERIES_REF": f"{sheet_ref}!$B$1",
            "CAT_REF": f"{sheet_ref}!$A$2:$A$4",
            "VAL_REF": f"{sheet_ref}!$B$2:$B$4",
            "CAT1": cats[0],
            "CAT2": cats[1],
            "CAT3": cats[2],
            "VAL1": f"{vals[0]:g}",
            "VAL2": f"{vals[1]:g}",
            "VAL3": f"{vals[2]:g}",
        }
        root = self.templates.read_tree("templates/chart.xml")
        replace_placeholders(root, context)
        return serialize_tree(root, xml_declaration=False)

    # build_package() inherited from OOXMLBaseEmitter

    # =========================================================================
    # STYLE GENERATION
    # =========================================================================

    def _customize_styles(self, data: bytes) -> bytes:
        """Generate styles.xml with full cell style library."""
        return _StyleSheetBuilder(self.document).build()

    # =========================================================================
    # SSOT CUSTOMIZATIONS
    # =========================================================================
