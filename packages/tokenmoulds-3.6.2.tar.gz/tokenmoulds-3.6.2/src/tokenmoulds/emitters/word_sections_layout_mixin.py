"""Section layout helpers for the Word sections mixin."""

from __future__ import annotations

from lxml import etree

from tokenmoulds.design.layout_defaults import (
    word_fallback_header_footer_twips,
    word_fallback_margin_twips,
)
from tokenmoulds.design.page_geometry import PageGeometry
from tokenmoulds.design.units import TWIPS_PER_INCH, emu_to_twips
from tokenmoulds.emitters.word_sect_pr import build_sect_pr
from tokenmoulds.emitters.word_shared import NSMAP, W
from tokenmoulds.emitters.xml_helpers import (
    clone_template_element,
    remove_template_elements,
    replace_placeholders,
)
from tokenmoulds.ir import DocumentGrid, SectionColumns, SectionSettings


class WordSectionsLayoutMixin:
    @staticmethod
    def _find_template_paragraph(
        ssot_template: etree._Element, template_name: str
    ) -> etree._Element:
        """Find a data-template paragraph by name.

        Used to resolve heading/body paragraph templates once before a
        loop that clones them N times — avoids an xpath walk per clone.
        """
        el = ssot_template.find(f'.//*[@data-template="{template_name}"]')
        if el is None:
            raise ValueError(f"template element {template_name!r} not found")
        return el

    def _build_section_paragraphs(
        self,
        section,  # LongFormSection
        index: int,
        *,
        heading_tmpl: etree._Element,
        body_tmpl: etree._Element,
    ) -> tuple[etree._Element, etree._Element]:
        """Clone + fill the heading/body paragraphs for one long-form section.

        Reads ``section.sample_heading`` / ``section.sample_body`` for the
        content copy, falling back to a generic "Section name" template
        when they're not set.
        """
        heading_el = self._clone_paragraph_template(heading_tmpl)
        replace_placeholders(
            heading_el,
            {
                "STYLE_ID": "Heading1",
                "TEXT": section.sample_heading
                or section.name.replace("_", " ").title(),
                "OUTLINE_LEVEL": "0",
                "BOOKMARK_ID": str(index + 1),
            },
        )
        remove_template_elements(heading_el)

        body_el = self._clone_paragraph_template(body_tmpl)
        replace_placeholders(
            body_el,
            {
                "STYLE_ID": "BodyText",
                "TEXT": section.sample_body
                or f"Sample content for the {section.name} section.",
            },
        )
        remove_template_elements(body_el)

        return heading_el, body_el

    @staticmethod
    def _clone_paragraph_template(template: etree._Element) -> etree._Element:
        """Deep-copy a data-template paragraph and strip its marker.

        The marker strip is load-bearing: ``remove_template_elements``
        later walks the tree and deletes any element still carrying the
        ``data-template`` attribute, so the clone root must be stripped
        first or the whole paragraph disappears.
        """
        import copy

        clone = copy.deepcopy(template)
        if "data-template" in clone.attrib:
            del clone.attrib["data-template"]
        return clone

    def _attach_section_pr(
        self,
        body_el: etree._Element,
        section,  # LongFormSection
        *,
        bundle,  # HeaderFooterBundle
        document_has_odd_even: bool,
    ) -> None:
        """Attach a section's sectPr to its body paragraph's pPr.

        Marks the paragraph as the last paragraph of the section — Word
        reads the sectPr and starts the next section on a new page.
        """
        sect_pr_el = build_sect_pr(
            section,
            header_rid_map=bundle.header_rid_map,
            footer_rid_map=bundle.footer_rid_map,
            document_has_odd_even=document_has_odd_even,
        )
        ppr = body_el.find(f"{W}pPr")
        if ppr is None:
            ppr = etree.Element(f"{W}pPr")
            body_el.insert(0, ppr)
        ppr.append(sect_pr_el)

    def _apply_section_settings_to_sect_pr(
        self,
        sect_pr: etree._Element,
        *,
        page_geometry: object | None,
        columns: SectionColumns,
        grid: DocumentGrid,
    ) -> None:
        """Apply page size, margins, columns, and grid to a w:sectPr."""
        geom = page_geometry if isinstance(page_geometry, PageGeometry) else None
        self._apply_page_size(sect_pr, geom)
        self._apply_page_margins(sect_pr, geom)

        if not columns.is_single_column:
            self._apply_section_columns(sect_pr, columns)

        if not grid.is_default:
            self._apply_document_grid(sect_pr, grid)

    def _insert_section_break(
        self,
        body: etree._Element,
        final_sect_pr: etree._Element,
        ssot_template: etree._Element,
        section: SectionSettings,
    ) -> None:
        """Insert a section-break paragraph before the final sectPr."""
        geom = section.page_geometry or self.document.page_geometry

        if isinstance(geom, PageGeometry):
            page_w = str(emu_to_twips(geom.width_emu))
            page_h = str(emu_to_twips(geom.height_emu))
            orient = "landscape" if geom.is_landscape else "portrait"
            m_top = str(emu_to_twips(geom.margins.top))
            m_bot = str(emu_to_twips(geom.margins.bottom))
            m_left = str(emu_to_twips(geom.margins.left))
            m_right = str(emu_to_twips(geom.margins.right))
            if geom.baseline_grid_emu > 0:
                hf = str(emu_to_twips(geom.baseline_grid_emu * 2))
            else:
                hf = str(emu_to_twips(geom.margins.top) // 3)
        else:
            # Fallback: Letter portrait with grid-derived margins
            page_w = str(int(8.5 * TWIPS_PER_INCH))  # 12240
            page_h = str(int(11.0 * TWIPS_PER_INCH))  # 15840
            orient = "portrait"
            m_val = str(word_fallback_margin_twips())
            m_top = m_bot = m_left = m_right = m_val
            hf = str(word_fallback_header_footer_twips())

        break_para = clone_template_element(ssot_template, "section_break")
        replace_placeholders(
            break_para,
            {
                "SECTION_TYPE": section.break_type,
                "PAGE_WIDTH": page_w,
                "PAGE_HEIGHT": page_h,
                "ORIENTATION": orient,
                "MARGIN_TOP": m_top,
                "MARGIN_RIGHT": m_right,
                "MARGIN_BOTTOM": m_bot,
                "MARGIN_LEFT": m_left,
                "HEADER_DIST": hf,
                "FOOTER_DIST": hf,
                "GUTTER": "0",
            },
        )

        # Insert before the final sectPr
        body.insert(list(body).index(final_sect_pr), break_para)

    def _apply_page_size(
        self,
        sect_pr: etree._Element,
        geom: object | None = None,
    ) -> None:
        """Apply page size and orientation from page geometry.

        Sets ``w:pgSz`` width, height, and orientation.  When no geometry
        is available the template defaults (Letter portrait) are kept.
        """
        if not isinstance(geom, PageGeometry):
            return

        pg_sz = sect_pr.find("w:pgSz", NSMAP)
        if pg_sz is None:
            return

        pg_sz.set(f"{W}w", str(emu_to_twips(geom.width_emu)))
        pg_sz.set(f"{W}h", str(emu_to_twips(geom.height_emu)))
        pg_sz.set(f"{W}orient", "landscape" if geom.is_landscape else "portrait")

    def _apply_page_margins(
        self,
        sect_pr: etree._Element,
        geom: object | None = None,
    ) -> None:
        """Apply page margins from page geometry.

        Uses grid-computed margins from ``PageGeometry`` when available,
        with a 2-grid-line header/footer distance.  Falls back to
        baseline × 4 margins when no geometry is provided.
        """
        pg_mar = sect_pr.find("w:pgMar", NSMAP)
        if pg_mar is None:
            return

        if isinstance(geom, PageGeometry):
            top = emu_to_twips(geom.margins.top)
            bottom = emu_to_twips(geom.margins.bottom)
            left = emu_to_twips(geom.margins.left)
            right = emu_to_twips(geom.margins.right)
            # Header/footer distance: 2 baseline grid lines, or 1/3 margin
            if geom.baseline_grid_emu > 0:
                hf = emu_to_twips(geom.baseline_grid_emu * 2)
            else:
                hf = top // 3
        else:
            # Fallback: grid-derived professional margins
            top = bottom = left = right = word_fallback_margin_twips()
            hf = word_fallback_header_footer_twips()

        pg_mar.set(f"{W}top", str(top))
        pg_mar.set(f"{W}bottom", str(bottom))
        pg_mar.set(f"{W}left", str(left))
        pg_mar.set(f"{W}right", str(right))
        pg_mar.set(f"{W}header", str(hf))
        pg_mar.set(f"{W}footer", str(hf))

    def _apply_section_columns(
        self, sect_pr: etree._Element, columns: SectionColumns
    ) -> None:
        """Apply column layout to section."""
        cols = sect_pr.find("w:cols", NSMAP)
        if cols is None:
            cols = etree.SubElement(sect_pr, f"{W}cols")

        cols.set(f"{W}num", str(columns.num_columns))
        cols.set(f"{W}space", str(columns.space_twips))

        if columns.equal_width:
            cols.set(f"{W}equalWidth", "1")
        else:
            cols.set(f"{W}equalWidth", "0")
            # Add individual column definitions
            for col_def in columns.columns:
                col = etree.SubElement(cols, f"{W}col")
                col.set(f"{W}w", str(col_def.width_twips))
                if col_def.space_twips > 0:
                    col.set(f"{W}space", str(col_def.space_twips))

        if columns.separator:
            cols.set(f"{W}sep", "1")

    def _apply_document_grid(self, sect_pr: etree._Element, grid: DocumentGrid) -> None:
        """Apply document grid settings for baseline alignment."""
        doc_grid = sect_pr.find("w:docGrid", NSMAP)
        if doc_grid is None:
            doc_grid = etree.SubElement(sect_pr, f"{W}docGrid")

        doc_grid.set(f"{W}type", grid.grid_type)
        doc_grid.set(f"{W}linePitch", str(grid.line_pitch_twips))

        if grid.char_space_twips > 0:
            doc_grid.set(f"{W}charSpace", str(grid.char_space_twips))
