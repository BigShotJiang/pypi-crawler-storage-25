"""Impress ODF emitter."""

from __future__ import annotations

import io
import zipfile
from pathlib import Path
from typing import TYPE_CHECKING
from xml.sax.saxutils import escape

from tokenmoulds.design.units import emu_to_pt, twips_to_pt
from tokenmoulds.emitters.odf_base import OdfBaseEmitter

if TYPE_CHECKING:
    from tokenmoulds.ir import DocumentIR
from tokenmoulds.emitters.odf_helpers import (
    DEFAULT_TABLE_BORDER_COLOR,
    DEFAULT_TABLE_BORDER_WIDTH_PT,
    DEFAULT_TABLE_PADDING_X_PT,
    DEFAULT_TABLE_PADDING_Y_PT,
)

class ImpressTemplateEmitter(OdfBaseEmitter):
    """LibreOffice Impress template emitter (.otp).

    Generates ODF presentation templates with:
    - Slide layouts with placeholder positioning
    - Text styles (title, body, lists)
    - Table styles with accent variants
    - OpenType features (ligatures, stylistic sets, etc.)

    Inherits from OdfBaseEmitter (→ BaseEmitter).
    """

    MIMETYPE = "application/vnd.oasis.opendocument.presentation-template"

    def __init__(
        self,
        document: DocumentIR,
        template_root: Path | str | None = None,
        use_pure_text_colors: bool = True,
        enable_opentype_features: bool = True,
    ) -> None:
        """Initialize Impress template emitter.

        Args:
            document: Document IR with style information
            template_root: Optional override for template resolution
            use_pure_text_colors: If True, use pure black/white for text
            enable_opentype_features: If True, enable OpenType features
        """
        super().__init__(
            "impress",
            document,
            template_root,
            use_pure_text_colors=use_pure_text_colors,
            enable_opentype_features=enable_opentype_features,
        )

    def build_package(self) -> bytes:
        buffer = io.BytesIO()
        title_text = f"{self.document.org_id} Presentation"
        body_text = (
            f"Body text uses {self.document.body_style.font_family} "
            f"{self.document.body_style.font_size_pt:.1f}pt with accent {self.document.color_theme.accent2}."
        )
        title_rect = self._placeholder_rect("title", prefix="TITLE")
        body_rect = self._placeholder_rect("body", prefix="BODY")
        table_rect = self._placeholder_rect("table", prefix="TABLE")
        list_items = self._body_list_items()
        table_rows = self._table_rows()
        hyperlink_label = (
            f"{self.document.org_id.lower()}.brand/{self.document.locale.lower()}"
        )
        styles_context = self._styles_context()
        content_context = {
            "TITLE": title_text,
            "BODY": body_text,
            "HYPERLINK_LABEL": hyperlink_label,
            **title_rect,
            **body_rect,
            **table_rect,
        }
        for idx, value in enumerate(list_items, start=1):
            content_context[f"LIST_ITEM_{idx}"] = value
        for row_idx, row in enumerate(table_rows, start=1):
            for col_idx, value in enumerate(row, start=1):
                content_context[f"TABLE_ROW{row_idx}_COL{col_idx}"] = value
        with zipfile.ZipFile(
            buffer, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9
        ) as archive:
            archive.writestr(
                "mimetype", self.MIMETYPE, compress_type=zipfile.ZIP_STORED
            )
            archive.writestr(
                "content.xml",
                self._render("content.xml", context=content_context),
            )
            archive.writestr(
                "styles.xml",
                self._render("styles.xml", context=styles_context),
            )
            self._write_common_entries(archive, title=title_text)
        return buffer.getvalue()

    def _placeholder_rect(self, kind: str, *, prefix: str) -> dict[str, str]:
        layout = self.document.presentation_layout
        fallback = layout.placeholders[0] if layout.placeholders else None
        placeholder = next((p for p in layout.placeholders if p.kind == kind), fallback)
        if placeholder is None:
            return {
                f"{prefix}_X": "0.00",
                f"{prefix}_Y": "0.00",
                f"{prefix}_WIDTH": "0.00",
                f"{prefix}_HEIGHT": "0.00",
            }
        return {
            f"{prefix}_X": f"{emu_to_pt(placeholder.x):.2f}",
            f"{prefix}_Y": f"{emu_to_pt(placeholder.y):.2f}",
            f"{prefix}_WIDTH": f"{emu_to_pt(placeholder.cx):.2f}",
            f"{prefix}_HEIGHT": f"{emu_to_pt(placeholder.cy):.2f}",
        }

    def _body_list_items(self) -> list[str]:
        items = [
            f"Heading font: {self.document.typography.heading_font}",
            f"Body font: {self.document.body_style.font_family}",
            f"Accent palette: {self.document.color_theme.accent1} / {self.document.color_theme.accent2}",
            f"Locale: {self.document.locale}",
        ]
        return [escape(item) for item in items]

    def _table_rows(self) -> list[tuple[str, ...]]:
        # Derive table font size from body style (table_style was removed from IR)
        table_font_size = self.document.body_style.font_size_pt
        rows = [
            ("Org", self.document.org_id, self.document.locale),
            ("Primary Accent", self.document.color_theme.accent1, "Theme color"),
            (
                "Heading Font",
                self.document.typography.heading_font,
                f"{table_font_size:.1f}pt tables",
            ),
        ]
        return [tuple(escape(value) for value in row) for row in rows]

    def _styles_context(self) -> dict[str, str]:
        heading_style = (
            self.document.heading_styles[0]
            if self.document.heading_styles
            else self.document.body_style
        )
        list_margin = f"{twips_to_pt(self.document.list_style.indent_twips):.2f}pt"
        list_indent = f"{twips_to_pt(self.document.list_style.hanging_twips):.2f}pt"

        # Derive table properties from body style and color theme
        # (table_style was removed from DocumentIR, now uses DTCG tokens)
        table_font_family = self.document.body_style.font_family
        table_font_size = self.document.body_style.font_size_pt

        table_border = (
            f"{DEFAULT_TABLE_BORDER_WIDTH_PT:.2f}pt solid {DEFAULT_TABLE_BORDER_COLOR}"
        )
        padding_x_pt = DEFAULT_TABLE_PADDING_X_PT
        padding_y_pt = DEFAULT_TABLE_PADDING_Y_PT

        # Header uses lt2 color, body uses lt1 color from color theme
        header_fill = self.document.color_theme.lt2
        body_fill = self.document.color_theme.lt1

        layout = self.document.presentation_layout
        slide_width = f"{emu_to_pt(layout.slide_width):.2f}"
        slide_height = f"{emu_to_pt(layout.slide_height):.2f}"

        return {
            "SLIDE_WIDTH": slide_width,
            "SLIDE_HEIGHT": slide_height,
            "HEADING_FONT": self.document.typography.heading_font,
            "BODY_FONT": self.document.body_style.font_family,
            "TITLE_COLOR": self.document.color_theme.accent1,
            "BODY_COLOR": self.document.body_style.color,
            "TITLE_FONT": self.document.typography.heading_font,
            "TITLE_SIZE": f"{heading_style.font_size_pt:.1f}",
            "BODY_SIZE": f"{self.document.body_style.font_size_pt:.1f}",
            "LINK_COLOR": self.document.hyperlink_style.link_color,
            "VISITED_LINK_COLOR": self.document.hyperlink_style.visited_color,
            "LIST_MARGIN": list_margin,
            "LIST_INDENT": list_indent,
            "TABLE_HEADER_FILL": header_fill,
            "TABLE_BODY_FILL": body_fill,
            "TABLE_BORDER": table_border,
            "TABLE_PADDING_X": padding_x_pt,
            "TABLE_PADDING_Y": padding_y_pt,
            "TABLE_FONT": table_font_family,
            "TABLE_FONT_SIZE": f"{table_font_size:.1f}",
            "TABLE_HEADER_TEXT_COLOR": heading_style.color,
            "TABLE_TEXT_COLOR": self.document.body_style.color,
            # Presentation frame padding from grid (≈ 0.5× list hanging indent)
            "FRAME_PADDING": f"{twips_to_pt(self.document.list_style.hanging_twips):.2f}",
            **self._layout_position_vars(),
        }

    def _layout_position_vars(self) -> dict[str, str]:
        """Compute per-layout placeholder position template variables.

        Returns variables like ``AL1T_TITLE_X``, ``AL2T_BODY_WIDTH`` etc.
        for all defined ODF layout types.
        """
        from tokenmoulds.design.page_geometry import create_slide_grid
        from tokenmoulds.dtcg.layout_recipe_catalog import LAYOUT_TYPE_TO_ODF
        from tokenmoulds.dtcg.layout_recipe_defaults import compute_default_slide_regions
        from tokenmoulds.dtcg.layout_recipe_resolver import resolve_layout_by_name

        from tokenmoulds.design.layout_defaults import DEFAULT_BASELINE_EMU

        layout = self.document.presentation_layout
        grid = create_slide_grid(
            layout.slide_width, layout.slide_height, DEFAULT_BASELINE_EMU
        )
        regions = compute_default_slide_regions(grid)
        result: dict[str, str] = {}

        for layout_type, (odf_name, _display) in LAYOUT_TYPE_TO_ODF.items():
            layout_regions = regions.get(layout_type, {})
            positions = resolve_layout_by_name(layout_type, layout_regions, grid)

            for region_name, (x, y, cx, cy) in positions.items():
                prefix = f"{odf_name}_{region_name.upper()}"
                result[f"{prefix}_X"] = f"{emu_to_pt(x):.2f}"
                result[f"{prefix}_Y"] = f"{emu_to_pt(y):.2f}"
                result[f"{prefix}_WIDTH"] = f"{emu_to_pt(cx):.2f}"
                result[f"{prefix}_HEIGHT"] = f"{emu_to_pt(cy):.2f}"

        return result
