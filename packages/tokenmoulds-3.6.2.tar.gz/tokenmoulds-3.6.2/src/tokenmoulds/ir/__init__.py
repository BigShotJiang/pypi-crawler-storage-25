"""Document Intermediate Representation for template generation.

This package provides the canonical data structures used to represent
document typography, colors, and styles that are then rendered by
format-specific emitters (Word, Excel, PowerPoint, ODF).
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from tokenmoulds._lazy import lazy_dir, resolve_lazy_attribute

if TYPE_CHECKING:
    from tokenmoulds.ir.builder import build_document_ir
    from tokenmoulds.ir.design_bridge import (
        create_document_ir_from_design,
        create_document_ir_from_policy,
        resolved_design_to_body_style,
        resolved_design_to_heading_styles,
        resolved_design_to_list_style,
        resolved_design_to_quote_style,
        resolved_design_to_typography_scheme,
    )
    from tokenmoulds.ir.geometry import (
        Margin,
        Matrix2D,
        Point,
        Rect,
        Size,
        bounding_box,
    )
    from tokenmoulds.ir.model import (
        CharacterTypography,
        ColorAnalysis,
        ColorTheme,
        DocumentGrid,
        DocumentIR,
        DocumentSettings,
        FallbackFonts,
        HeadingStyle,
        HyperlinkStyle,
        LineSpacing,
        ListStyle,
        LocaleSettings,
        OpenTypeFeatures,
        ParagraphControl,
        ParagraphIndent,
        ParagraphSpacing,
        ParagraphStyle,
        PresentationLayout,
        QuoteStyle,
        SectionColumns,
        SectionSettings,
        SemanticSlideDecoration,
        SlidePlaceholder,
        TextAlignment,
        TrackingSettings,
        TypographyScheme,
    )


_LAZY_IMPORTS: dict[str, tuple[str, str]] = {
    # Model classes
    "ColorAnalysis": (".model", "ColorAnalysis"),
    "ColorTheme": (".model", "ColorTheme"),
    "DocumentIR": (".model", "DocumentIR"),
    "DocumentGrid": (".model", "DocumentGrid"),
    "DocumentSettings": (".model", "DocumentSettings"),
    "FallbackFonts": (".model", "FallbackFonts"),
    "HeadingStyle": (".model", "HeadingStyle"),
    "HyperlinkStyle": (".model", "HyperlinkStyle"),
    "CharacterTypography": (".model", "CharacterTypography"),
    "LineSpacing": (".model", "LineSpacing"),
    "ListStyle": (".model", "ListStyle"),
    "LocaleSettings": (".model", "LocaleSettings"),
    "OpenTypeFeatures": (".model", "OpenTypeFeatures"),
    "ParagraphControl": (".model", "ParagraphControl"),
    "ParagraphIndent": (".model", "ParagraphIndent"),
    "ParagraphSpacing": (".model", "ParagraphSpacing"),
    "ParagraphStyle": (".model", "ParagraphStyle"),
    "PresentationLayout": (".model", "PresentationLayout"),
    "SemanticSlideDecoration": (".model", "SemanticSlideDecoration"),
    "QuoteStyle": (".model", "QuoteStyle"),
    "SectionColumns": (".model", "SectionColumns"),
    "SectionSettings": (".model", "SectionSettings"),
    "SlidePlaceholder": (".model", "SlidePlaceholder"),
    "TextAlignment": (".model", "TextAlignment"),
    "TrackingSettings": (".model", "TrackingSettings"),
    "TypographyScheme": (".model", "TypographyScheme"),
    # Excel layout
    "ExcelSheet": (".excel_layout", "ExcelSheet"),
    # Geometry
    "Point": (".geometry", "Point"),
    "Size": (".geometry", "Size"),
    "Rect": (".geometry", "Rect"),
    "Margin": (".geometry", "Margin"),
    "Matrix2D": (".geometry", "Matrix2D"),
    "bounding_box": (".geometry", "bounding_box"),
    # Design bridge
    "create_document_ir_from_design": (
        ".design_bridge",
        "create_document_ir_from_design",
    ),
    "create_document_ir_from_policy": (
        ".design_bridge",
        "create_document_ir_from_policy",
    ),
    "resolved_design_to_typography_scheme": (
        ".design_bridge",
        "resolved_design_to_typography_scheme",
    ),
    "resolved_design_to_body_style": (
        ".design_bridge",
        "resolved_design_to_body_style",
    ),
    "resolved_design_to_heading_styles": (
        ".design_bridge",
        "resolved_design_to_heading_styles",
    ),
    "resolved_design_to_list_style": (
        ".design_bridge",
        "resolved_design_to_list_style",
    ),
    "resolved_design_to_quote_style": (
        ".design_bridge",
        "resolved_design_to_quote_style",
    ),
    # Builder
    "build_document_ir": (".builder", "build_document_ir"),
}

__all__ = [
    # Model classes
    "ColorAnalysis",
    "ColorTheme",
    "DocumentIR",
    "DocumentGrid",
    "DocumentSettings",
    "FallbackFonts",
    "HeadingStyle",
    "HyperlinkStyle",
    "CharacterTypography",
    "LineSpacing",
    "ListStyle",
    "LocaleSettings",
    "OpenTypeFeatures",
    "ParagraphControl",
    "ParagraphIndent",
    "ParagraphSpacing",
    "ParagraphStyle",
    "PresentationLayout",
    "SemanticSlideDecoration",
    "QuoteStyle",
    "SectionColumns",
    "SectionSettings",
    "SlidePlaceholder",
    "TextAlignment",
    "TrackingSettings",
    "TypographyScheme",
    # Excel layout
    "ExcelSheet",
    # Geometry primitives
    "Point",
    "Size",
    "Rect",
    "Margin",
    "Matrix2D",
    "bounding_box",
    # Design bridge functions
    "create_document_ir_from_design",
    "create_document_ir_from_policy",
    "resolved_design_to_typography_scheme",
    "resolved_design_to_body_style",
    "resolved_design_to_heading_styles",
    "resolved_design_to_list_style",
    "resolved_design_to_quote_style",
    # Builder
    "build_document_ir",
]


def __getattr__(name: str) -> Any:
    return resolve_lazy_attribute(
        name,
        module_globals=globals(),
        package=__package__ or __name__,
        lazy_imports=_LAZY_IMPORTS,
        populate_siblings=True,
    )


def __dir__() -> list[str]:
    return lazy_dir(globals(), __all__)
