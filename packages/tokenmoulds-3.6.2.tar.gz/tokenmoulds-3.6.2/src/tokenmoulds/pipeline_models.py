"""Build pipeline configuration and result models."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Literal

from tokenmoulds.ir import DocumentIR
from tokenmoulds.semantic.provenance import SemanticProvenance

TokenSource = Literal[
    "payload", "brand_inputs", "layers", "tokens_file", "github", "unknown"
]

@dataclass
class BuildConfig:
    """Configuration for a single build pipeline invocation.

    Provide exactly one token source: ``token_payload``, ``tokens_file``,
    ``layers_dir`` / ``layers_manifest``, or ``brand_inputs``.
    """

    # Required
    org_id: str
    output_formats: list[str]

    # Token source (one of these)
    token_payload: dict | None = None
    tokens_file: Path | None = None
    layers_dir: Path | None = None
    layers_manifest: Path | None = None
    brand_inputs: dict | None = None

    # Build controls
    locale: str = "US"
    template_root: Path | None = None
    fonts_dir: Path | None = None
    embed_fonts: bool = True
    validate: bool = True
    emit_semantic_provenance: bool = False

    # Design engine controls
    policy: str = "default"
    base_font_size_pt: float = 11.0
    base_grid_pt: float = 0  # 0 = auto-select from font metrics

    # GitHub brand source (optional — ADR 026 F3)
    repository: str | None = None
    ref: str | None = None
    manifest_path: str | None = None

    # License (optional — free tier works without)
    license_id: str | None = None
    license_repo: str | None = None

    def token_source_label(self) -> TokenSource:
        """Canonical label for provenance; mirrors _resolve_tokens() priority."""
        if self.repository is not None:
            return "github"
        if self.token_payload is not None:
            return "payload"
        if self.brand_inputs is not None:
            return "brand_inputs"
        if self.layers_dir is not None or self.layers_manifest is not None:
            return "layers"
        if self.tokens_file is not None:
            return "tokens_file"
        return "unknown"


@dataclass
class BuildProvenance:
    """Build metadata for reproducibility and audit."""

    org_id: str
    timestamp: str  # ISO 8601
    token_source: TokenSource
    output_formats: list[str] = field(default_factory=list)
    pipeline_version: str = ""
    timing_ms: float = 0


@dataclass
class BuildResult:
    """Result of a build pipeline invocation."""

    success: bool
    artifacts: dict[str, bytes] = field(default_factory=dict)
    validation_results: dict[str, list] = field(default_factory=dict)
    document_ir: DocumentIR | None = None
    token_payload: dict | None = None
    provenance: BuildProvenance | None = None
    semantic_provenance: tuple[SemanticProvenance, ...] = ()
    error: str | None = None
    timing_ms: float = 0

    def to_build_result_dict(self) -> dict:
        """Serialize for build-result.json."""
        result: dict[str, Any] = {
            "success": self.success,
            "timing_ms": self.timing_ms,
            "formats": sorted(self.artifacts.keys()),
            "artifact_sizes": {fmt: len(data) for fmt, data in self.artifacts.items()},
        }
        if self.error:
            result["error"] = self.error
        if self.provenance:
            result["provenance"] = asdict(self.provenance)
        if self.semantic_provenance:
            result["semantic_provenance"] = [
                asdict(entry) for entry in self.semantic_provenance
            ]
        if self.validation_results:
            result["validation_summary"] = {
                fmt: len(issues) for fmt, issues in self.validation_results.items()
            }
        return result

    def to_validation_report_dict(self) -> dict:
        """Serialize for validation-report.json."""
        return {
            "success": self.success,
            "formats_validated": sorted(self.validation_results.keys()),
            "total_issues": sum(len(v) for v in self.validation_results.values()),
            "results": {
                fmt: issues for fmt, issues in sorted(self.validation_results.items())
            },
        }

    def to_build_result_json(self, indent: int = 2) -> str:
        """Serialize build result as JSON string."""
        return json.dumps(self.to_build_result_dict(), indent=indent)

    def to_validation_report_json(self, indent: int = 2) -> str:
        """Serialize validation report as JSON string."""
        return json.dumps(self.to_validation_report_dict(), indent=indent)

@dataclass
class BuildBatchConfig:
    """Configuration for building multiple brands in parallel."""

    brands: list[BuildConfig]
    max_concurrency: int = 4
    progress_callback: Any = None  # Callable[[str, BuildResult], None] | None
