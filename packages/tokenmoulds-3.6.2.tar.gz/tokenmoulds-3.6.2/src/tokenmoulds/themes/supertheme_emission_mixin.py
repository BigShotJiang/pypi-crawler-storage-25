"""Emission and thumbnail helpers for SuperTheme packages."""

from __future__ import annotations

import io
import zipfile
from pathlib import Path
from string import Template
from typing import TYPE_CHECKING, Any, Dict, List

from lxml import etree

from tokenmoulds.colors.parser import hex_to_rgb_tuple
from tokenmoulds.design.page_geometry import SlideGrid, create_slide_grid
from tokenmoulds.design.units import pt_to_emu
from tokenmoulds.themes.aspect_ratios import AspectRatio
from tokenmoulds.themes.supertheme_thumbnails import build_thumbnail_payloads
from tokenmoulds.themes.thumbnail_generator import generate_thumbnails_from_pptx

if TYPE_CHECKING:
    from tokenmoulds.themes.supertheme import SuperThemeVariant


class SuperThemeEmissionMixin:
    def _create_sample_pptx_for_thumbnail(
        self,
        variant: SuperThemeVariant,
        output_path: Path,
    ) -> bool:
        """Create a sample PPTX with the variant's theme for thumbnail capture.

        Args:
            variant: The SuperTheme variant with colors/fonts
            output_path: Path to write the sample PPTX

        Returns:
            True if successful, False otherwise
        """
        try:
            from pptx import Presentation  # type: ignore[import-not-found]
            from pptx.dml.color import RGBColor  # type: ignore[import-not-found]
            from pptx.enum.shapes import MSO_SHAPE  # type: ignore[import-not-found]
            from pptx.util import Emu, Inches, Pt  # type: ignore[import-not-found]

            prs = Presentation()

            # Set slide size to match variant
            prs.slide_width = Emu(variant.width_emu)
            prs.slide_height = Emu(variant.height_emu)

            # Add a blank slide
            slide_layout = prs.slide_layouts[6]  # Blank layout
            slide = prs.slides.add_slide(slide_layout)

            # Add a large rectangle with accent1 color as header
            color_rgb = hex_to_rgb_tuple(variant.accent1)
            sw = int(prs.slide_width or 0)
            sh = int(prs.slide_height or 0)

            shape = slide.shapes.add_shape(
                MSO_SHAPE.RECTANGLE, Emu(0), Emu(0), Emu(sw), Emu(int(sh * 0.33))
            )
            shape.fill.solid()
            shape.fill.fore_color.rgb = RGBColor(*color_rgb)
            shape.line.fill.background()

            # Add title text in lt1 color
            lt1_rgb = hex_to_rgb_tuple(variant.lt1)
            textbox_width = Emu(sw - int(Inches(1)))

            textbox = slide.shapes.add_textbox(
                Inches(0.5), Inches(0.3), textbox_width, Inches(1.5)
            )
            tf = textbox.text_frame
            p = tf.paragraphs[0]
            p.text = variant.design_name
            p.font.size = Pt(44)
            p.font.bold = True
            p.font.color.rgb = RGBColor(*lt1_rgb)
            p.font.name = variant.major_font

            # Add content area with accent color blocks
            content_top = int(sh * 0.40)
            content_height = int(sh * 0.35)
            block_width = int((sw - int(Inches(2))) / 3)

            # Three accent color blocks
            accent_colors = [
                hex_to_rgb_tuple(variant.accent1),
                hex_to_rgb_tuple(variant.accent2),
                hex_to_rgb_tuple(variant.accent3),
            ]

            for i, accent_rgb in enumerate(accent_colors):
                box_left = int(Inches(0.5)) + i * (block_width + int(Inches(0.25)))
                box = slide.shapes.add_shape(
                    MSO_SHAPE.ROUNDED_RECTANGLE,
                    Emu(box_left),
                    Emu(content_top),
                    Emu(block_width),
                    Emu(content_height),
                )
                box.fill.solid()
                box.fill.fore_color.rgb = RGBColor(*accent_rgb)
                box.line.fill.background()

            prs.save(str(output_path))
            return True

        except ImportError:
            # python-pptx not available
            return False
        except Exception:
            return False

    def _generate_thumbnails(self, variant: SuperThemeVariant) -> Dict[str, bytes]:
        """Generate thumbnail images for a variant.

        If soffice thumbnails are enabled and LibreOffice is available,
        generates real thumbnails by creating a sample PPTX and rendering it.
        Otherwise, falls back to placeholder thumbnails.

        Returns a dict mapping filename to JPEG bytes:
        - themeThumbnail.jpeg (64x48)
        - auxiliaryThemeThumbnail.jpeg (85x48)
        - auxiliaryThemeThumbnailMedium.jpeg (124x70)
        - docProps/thumbnail.jpeg (341x192) - package thumbnail
        """
        # Try soffice-based thumbnails if enabled
        if self._use_soffice_thumbnails and self._check_soffice_available():
            try:
                import tempfile

                with tempfile.TemporaryDirectory() as temp_dir:
                    temp_path = Path(temp_dir)
                    pptx_path = temp_path / "sample.pptx"

                    if self._create_sample_pptx_for_thumbnail(variant, pptx_path):
                        thumbnails = generate_thumbnails_from_pptx(pptx_path)
                        if thumbnails:
                            return thumbnails
            except Exception:
                pass  # Fall through to placeholder generation

        # Fall back to placeholder thumbnails
        color = hex_to_rgb_tuple(variant.accent1)

        return build_thumbnail_payloads(color)

    def _build_variant_manager(self, variants: List[SuperThemeVariant]) -> str:
        """Build themeVariantManager.xml.

        All variants are listed here. rId1 corresponds to the base theme,
        rId2+ correspond to variant folders.
        """
        variant_template = self._read_template("theme_variant.xml")
        variant_entries = []

        for i, variant in enumerate(variants):
            entry = Template(variant_template).safe_substitute(
                VARIANT_NAME=variant.name,
                VARIANT_GUID=variant.guid,
                WIDTH_EMU=str(variant.width_emu),
                HEIGHT_EMU=str(variant.height_emu),
                REL_ID=f"rId{i + 1}",
            )
            variant_entries.append(entry)

        manager_template = self._read_template("theme_variant_manager.xml")
        return Template(manager_template).safe_substitute(
            THEME_VARIANTS="".join(variant_entries),
        )

    def _build_variant_manager_rels(self, variants: List[SuperThemeVariant]) -> str:
        """Build themeVariantManager.xml.rels.

        The first relationship (rId1) points to the base theme.
        Subsequent relationships point to variant folders (variant1, variant2, etc.).
        """
        relationships = []

        # rId1 points to base theme (used by first variant)
        relationships.append(
            '  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="/theme/theme/themeManager.xml"/>'
        )

        # rId2+ point to variant folders for remaining variants
        for i, variant in enumerate(variants[1:], start=1):
            folder_num = i  # variant1 for first additional variant, etc.
            relationships.append(
                f'  <Relationship Id="rId{i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="/themeVariants/variant{folder_num}/theme/theme/themeManager.xml"/>'
            )

        rels_template = self._read_template("variant_manager_rels.xml")
        return Template(rels_template).safe_substitute(
            VARIANT_RELATIONSHIPS="\n".join(relationships),
        )

    def _get_slide_layout_xml(
        self,
        layout_index: int,
        layout_type: str,
        layout_name: str,
        slide_grid: SlideGrid | None = None,
        slide_regions: dict[str, Any] | None = None,
    ) -> str:
        """Get slideLayout XML from template or build minimal fallback.

        Uses SSOT templates for layouts 1-9 (slide_layouts/slideLayout{n}.xml).
        Falls back to minimal template for layouts 10-11 (vertTx, vertTitleAndTx).

        When a ``slide_grid`` is provided, all explicit ``<a:xfrm>`` placeholder
        positions are snapped to the baseline grid so that every dimension is a
        clean multiple of the grid module.

        Args:
            layout_index: 1-based layout index
            layout_type: Layout type attribute (e.g., 'title', 'obj')
            layout_name: Layout display name (e.g., 'Title Slide')
            slide_grid: Optional grid for snapping placeholder positions

        Returns:
            Complete slideLayout XML string
        """
        # Use SSOT templates for layouts 1-9
        if layout_index <= 9:
            template_path = f"slide_layouts/slideLayout{layout_index}.xml"
            xml_str = self._read_template(template_path)
            if slide_grid is not None:
                xml_str = self._apply_layout_recipe(
                    xml_str, layout_type, slide_grid, slide_regions
                )
            return xml_str

        # Fallback to minimal template for layouts 10-11 (vertical layouts)
        return f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<p:sldLayout xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"
             xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"
             xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
             type="{layout_type}" preserve="1">
  <p:cSld name="{layout_name}">
    <p:spTree>
      <p:nvGrpSpPr>
        <p:cNvPr id="1" name=""/>
        <p:cNvGrpSpPr/>
        <p:nvPr/>
      </p:nvGrpSpPr>
      <p:grpSpPr>
        <a:xfrm>
          <a:off x="0" y="0"/>
          <a:ext cx="0" cy="0"/>
          <a:chOff x="0" y="0"/>
          <a:chExt cx="0" cy="0"/>
        </a:xfrm>
      </p:grpSpPr>
    </p:spTree>
  </p:cSld>
  <p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr>
</p:sldLayout>"""

    @staticmethod
    def _apply_layout_recipe(
        xml_str: str,
        layout_type: str,
        grid: SlideGrid,
        slide_regions: dict[str, Any] | None = None,
    ) -> str:
        """Apply layout recipe to compute placeholder positions.

        When *slide_regions* is provided, positions come from the
        token-driven recipes.  Each placeholder is identified by its
        ``<p:ph type="..." idx="..."/>`` attributes and matched against
        the recipe.  Shapes without a recipe entry have their existing
        explicit positions snapped to the grid.
        """
        P_NS = "http://schemas.openxmlformats.org/presentationml/2006/main"
        A_NS_STR = "http://schemas.openxmlformats.org/drawingml/2006/main"
        root = etree.fromstring(xml_str.encode("utf-8"))

        if slide_regions is not None:
            from tokenmoulds.dtcg.layout_recipe_resolver import (
                resolve_for_pptx_layout_type,
            )

            recipe = resolve_for_pptx_layout_type(layout_type, slide_regions, grid)
        else:
            recipe = {}

        for sp in root.iter(f"{{{P_NS}}}sp"):
            # Find placeholder identity
            ph = sp.find(f".//{{{P_NS}}}ph")
            if ph is None:
                continue

            ph_type = ph.get("type")  # None if absent
            ph_idx = ph.get("idx")  # None if absent

            # Find the xfrm element
            sp_pr = sp.find(f"{{{P_NS}}}spPr")
            if sp_pr is None:
                continue
            xfrm = sp_pr.find(f"{{{A_NS_STR}}}xfrm")

            key = (ph_type, ph_idx)
            if key in recipe:
                # Apply formulaic position from recipe
                x, y, cx, cy = recipe[key]

                if xfrm is None:
                    # Create xfrm for placeholders that need explicit pos
                    xfrm = etree.SubElement(sp_pr, f"{{{A_NS_STR}}}xfrm")
                    etree.SubElement(xfrm, f"{{{A_NS_STR}}}off")
                    etree.SubElement(xfrm, f"{{{A_NS_STR}}}ext")

                off = xfrm.find(f"{{{A_NS_STR}}}off")
                ext = xfrm.find(f"{{{A_NS_STR}}}ext")
                if off is None or ext is None:
                    continue

                off.set("x", str(x))
                off.set("y", str(y))
                ext.set("cx", str(cx))
                ext.set("cy", str(cy))

            elif xfrm is not None:
                # No recipe entry — snap existing explicit position to grid
                off = xfrm.find(f"{{{A_NS_STR}}}off")
                ext = xfrm.find(f"{{{A_NS_STR}}}ext")
                if off is None or ext is None:
                    continue
                ox = int(off.get("x", "0"))
                oy = int(off.get("y", "0"))
                ocx = int(ext.get("cx", "0"))
                ocy = int(ext.get("cy", "0"))
                if ocx == 0 and ocy == 0:
                    continue
                nx, ny, ncx, ncy = grid.snap_position(ox, oy, ocx, ocy)
                # Clamp to slide bounds
                if nx + ncx > grid.slide_width_emu:
                    ncx = grid.slide_width_emu - nx
                if ny + ncy > grid.slide_height_emu:
                    ncy = grid.slide_height_emu - ny
                off.set("x", str(nx))
                off.set("y", str(ny))
                ext.set("cx", str(ncx))
                ext.set("cy", str(ncy))

        return etree.tostring(
            root, xml_declaration=True, encoding="UTF-8", standalone=True
        ).decode("utf-8")

    def _build_base_slide_layout_content_types(self) -> str:
        """Build content type entries for base theme slideLayouts."""
        entries = []
        for i in range(1, len(self.SLIDE_LAYOUT_TYPES) + 1):
            entries.append(
                f'  <Override PartName="/theme/slideLayouts/slideLayout{i}.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml"/>'
            )
        return "\n".join(entries)

    def _build_content_types(self, variants: List[SuperThemeVariant]) -> str:
        """Build [Content_Types].xml.

        Only variant folders for variants[1:] are included (first variant uses base theme).
        """
        ct_template = self._read_template("variant_content_type.xml")
        variant_types = []

        # Only create content types for variant folders (variants[1:])
        for i, variant in enumerate(variants[1:], start=1):
            folder_num = i  # variant1 for first additional variant
            ct = Template(ct_template).safe_substitute(
                VARIANT_ID=str(folder_num),
            )
            variant_types.append(ct)

        types_template = self._read_template("content_types.xml")
        return Template(types_template).safe_substitute(
            BASE_SLIDE_LAYOUT_CONTENT_TYPES=self._build_base_slide_layout_content_types(),
            VARIANT_CONTENT_TYPES="".join(variant_types),
        )

    def emit(self) -> bytes:
        """Generate SuperTheme package as bytes.

        Returns:
            Bytes content of the SuperTheme archive

        Raises:
            ValueError: If no design variants or aspect ratios configured
        """
        if not self.design_variants:
            raise ValueError("No design variants configured")
        if not self.aspect_ratio_keys:
            raise ValueError("No aspect ratios configured")

        variants = self._build_variants()
        buffer = io.BytesIO()

        with zipfile.ZipFile(
            buffer, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9
        ) as zf:
            # Core package files
            zf.writestr("[Content_Types].xml", self._build_content_types(variants))
            zf.writestr("_rels/.rels", self._read_template("package_rels.xml"))

            # Theme variant manager
            zf.writestr(
                "themeVariants/themeVariantManager.xml",
                self._build_variant_manager(variants),
            )
            zf.writestr(
                "themeVariants/_rels/themeVariantManager.xml.rels",
                self._build_variant_manager_rels(variants),
            )

            # Pre-compute static templates (reused across default theme + variants)
            theme_manager_xml = self._read_template("theme_manager.xml")
            theme_manager_rels_xml = self._read_template("theme_manager_rels.xml")
            presentation_rels_xml = self._read_template("presentation_rels.xml")
            slide_master_template = self._read_template("slide_master.xml")
            slide_master_rels_xml = self._read_template("slide_master_rels.xml")
            slide_layout_rels = self._read_template("slide_layout_rels.xml")
            variant_rels_xml = self._read_template("variant_rels.xml")

            # Build slide layouts per-aspect-ratio with grid-snapped positions.
            # Different aspect ratios need different placeholder positions.
            _DEFAULT_GRID_PT = 12  # Standard presentation baseline grid
            _grid_emu = pt_to_emu(_DEFAULT_GRID_PT)
            _layout_cache: Dict[str, list[str]] = {}

            def _layouts_for_ar(ar: AspectRatio) -> list[str]:
                if ar.key in _layout_cache:
                    return _layout_cache[ar.key]
                grid = create_slide_grid(ar.width_emu, ar.height_emu, _grid_emu)
                # Use provided regions or compute defaults for this grid
                regions = self.slide_regions
                if regions is None:
                    from tokenmoulds.dtcg.layout_recipe_defaults import (
                        compute_default_slide_regions,
                    )

                    regions = compute_default_slide_regions(grid)
                layouts = [
                    self._get_slide_layout_xml(
                        i,
                        layout_type,
                        layout_name,
                        slide_grid=grid,
                        slide_regions=regions,
                    )
                    for i, (layout_type, layout_name) in enumerate(
                        self.SLIDE_LAYOUT_TYPES, 1
                    )
                ]
                _layout_cache[ar.key] = layouts
                return layouts

            # Default theme (first variant)
            default_variant = variants[0]
            zf.writestr("theme/theme/themeManager.xml", theme_manager_xml)
            zf.writestr(
                "theme/theme/_rels/themeManager.xml.rels", theme_manager_rels_xml
            )
            zf.writestr(
                "theme/theme/theme1.xml", self._build_theme_xml(default_variant)
            )
            zf.writestr(
                "theme/presentation.xml", self._build_presentation_xml(default_variant)
            )
            zf.writestr("theme/_rels/presentation.xml.rels", presentation_rels_xml)
            zf.writestr(
                "theme/slideMasters/slideMaster1.xml",
                Template(slide_master_template).safe_substitute(
                    MASTER_NAME=f"{default_variant.design_name} Master"
                ),
            )
            zf.writestr(
                "theme/slideMasters/_rels/slideMaster1.xml.rels",
                slide_master_rels_xml,
            )

            # Default theme slideLayouts (grid-snapped per aspect ratio)
            default_layouts = _layouts_for_ar(default_variant.aspect_ratio)
            for i, layout_xml in enumerate(default_layouts, 1):
                zf.writestr(f"theme/slideLayouts/slideLayout{i}.xml", layout_xml)
                zf.writestr(
                    f"theme/slideLayouts/_rels/slideLayout{i}.xml.rels",
                    slide_layout_rels,
                )

            # Default theme thumbnails
            default_thumbnails = self._generate_thumbnails(default_variant)
            zf.writestr(
                "theme/theme/themeThumbnail.jpeg",
                default_thumbnails["themeThumbnail.jpeg"],
            )
            zf.writestr(
                "theme/theme/auxiliaryThemeThumbnail.jpeg",
                default_thumbnails["auxiliaryThemeThumbnail.jpeg"],
            )
            zf.writestr(
                "theme/theme/auxiliaryThemeThumbnailMedium.jpeg",
                default_thumbnails["auxiliaryThemeThumbnailMedium.jpeg"],
            )
            zf.writestr("docProps/thumbnail.jpeg", default_thumbnails["thumbnail.jpeg"])

            # Additional variants (variants[1:] - first variant uses base theme)
            # variant_id is 1-based, so variant folder numbering: variant.variant_id - 1
            for variant in variants[1:]:
                folder_num = variant.variant_id - 1  # variant1 for 2nd variant, etc.
                base_dir = f"themeVariants/variant{folder_num}"

                # Variant theme and presentation
                zf.writestr(
                    f"{base_dir}/theme/theme/themeManager.xml", theme_manager_xml
                )
                zf.writestr(
                    f"{base_dir}/theme/theme/_rels/themeManager.xml.rels",
                    theme_manager_rels_xml,
                )
                zf.writestr(
                    f"{base_dir}/theme/theme/theme1.xml", self._build_theme_xml(variant)
                )
                zf.writestr(
                    f"{base_dir}/theme/presentation.xml",
                    self._build_presentation_xml(variant),
                )
                zf.writestr(
                    f"{base_dir}/theme/_rels/presentation.xml.rels",
                    presentation_rels_xml,
                )

                # Variant slide master
                zf.writestr(
                    f"{base_dir}/theme/slideMasters/slideMaster1.xml",
                    Template(slide_master_template).safe_substitute(
                        MASTER_NAME=f"{variant.name} Master"
                    ),
                )
                zf.writestr(
                    f"{base_dir}/theme/slideMasters/_rels/slideMaster1.xml.rels",
                    slide_master_rels_xml,
                )

                # Variant slideLayouts (grid-snapped per aspect ratio)
                variant_layouts = _layouts_for_ar(variant.aspect_ratio)
                for i, layout_xml in enumerate(variant_layouts, 1):
                    zf.writestr(
                        f"{base_dir}/theme/slideLayouts/slideLayout{i}.xml",
                        layout_xml,
                    )
                    zf.writestr(
                        f"{base_dir}/theme/slideLayouts/_rels/slideLayout{i}.xml.rels",
                        slide_layout_rels,
                    )

                # Variant thumbnails
                variant_thumbnails = self._generate_thumbnails(variant)
                zf.writestr(
                    f"{base_dir}/theme/theme/themeThumbnail.jpeg",
                    variant_thumbnails["themeThumbnail.jpeg"],
                )
                zf.writestr(
                    f"{base_dir}/theme/theme/auxiliaryThemeThumbnail.jpeg",
                    variant_thumbnails["auxiliaryThemeThumbnail.jpeg"],
                )
                zf.writestr(
                    f"{base_dir}/theme/theme/auxiliaryThemeThumbnailMedium.jpeg",
                    variant_thumbnails["auxiliaryThemeThumbnailMedium.jpeg"],
                )
                zf.writestr(
                    f"{base_dir}/docProps/thumbnail.jpeg",
                    variant_thumbnails["thumbnail.jpeg"],
                )

                # Variant relationships
                zf.writestr(f"{base_dir}/_rels/.rels", variant_rels_xml)

        buffer.seek(0)
        return buffer.getvalue()

    def save(self, path: str | Path) -> None:
        """Save SuperTheme to disk.

        Args:
            path: Output file path (should end with .thmx)
        """
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(self.emit())
