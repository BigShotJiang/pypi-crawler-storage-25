"""SuperTheme patch and extraction utilities.

Round-trip operations on existing SuperTheme packages: extract design
variants from a ``.thmx`` file, modify colors/fonts, and repack.
Orthogonal to :class:`SuperThemeEmitter` which builds from scratch.
"""

from __future__ import annotations

import io
import zipfile
from pathlib import Path
from typing import TYPE_CHECKING, Dict, List, Optional

from lxml import etree

if TYPE_CHECKING:
    from tokenmoulds.themes.supertheme import DesignVariant

from tokenmoulds.colors.parser import hex_to_rgb_tuple
from tokenmoulds.emitters.xml_helpers import (
    A_NS,
    THEMEML_NS,
    find_element,
    find_elements,
    normalize_hex_color,
    parse_xml,
    serialize_tree,
    set_color_slot,
    set_scheme_name,
    set_theme_name,
)
from tokenmoulds.themes.supertheme_thumbnails import build_thumbnail_payloads

THEME1_SUFFIX = "theme/theme/theme1.xml"


# ---------------------------------------------------------------------------
# XML parsing utilities
# ---------------------------------------------------------------------------


def register_theme_namespaces() -> None:
    """Register namespace prefixes for clean serialization."""
    etree.register_namespace("a", A_NS)
    etree.register_namespace("thm15", THEMEML_NS)


def parse_theme_variant_vids(manager_xml: str) -> List[str]:
    """Parse variant IDs from themeVariantManager.xml."""
    root = parse_xml(manager_xml)
    ns = {"t": THEMEML_NS}
    vids: List[str] = []
    for node in find_elements(root, ".//t:themeVariant", ns):
        vid = node.attrib.get("vid")
        if vid and vid not in vids:
            vids.append(vid)
    return vids


def parse_theme_variant_names(manager_xml: str) -> Dict[str, str]:
    """Parse variant names from themeVariantManager.xml."""
    root = parse_xml(manager_xml)
    ns = {"t": THEMEML_NS}
    names: Dict[str, str] = {}
    for node in find_elements(root, ".//t:themeVariant", ns):
        vid = node.attrib.get("vid")
        name = node.attrib.get("name")
        if vid and name:
            names[vid] = name
    return names


def extract_theme_family_vid(root: etree._Element) -> Optional[str]:
    """Extract theme family VID from theme element."""
    ns = {"thm15": THEMEML_NS}
    family = find_element(root, ".//thm15:themeFamily", ns)
    if family is None:
        return None
    return family.attrib.get("vid")


def _hex_to_rgb(hex_color: str) -> tuple[int, int, int]:
    """Convert hex color to RGB tuple."""
    return hex_to_rgb_tuple(hex_color, fallback=(128, 128, 128))


# ---------------------------------------------------------------------------
# Theme XML mutation
# ---------------------------------------------------------------------------


def update_theme_colors(root: etree._Element, variant: DesignVariant) -> None:
    """Update all theme colors from a DesignVariant."""
    ns = {"a": A_NS}
    clr_scheme = find_element(root, ".//a:clrScheme", ns)
    if clr_scheme is None:
        return
    colors = {
        "dk1": variant.dk1,
        "lt1": variant.lt1,
        "dk2": variant.dk2,
        "lt2": variant.lt2,
        "accent1": variant.accent1,
        "accent2": variant.accent2,
        "accent3": variant.accent3,
        "accent4": variant.accent4,
        "accent5": variant.accent5,
        "accent6": variant.accent6,
        "hlink": variant.hlink,
        "folHlink": variant.folHlink,
    }
    for slot_name, value in colors.items():
        slot = clr_scheme.find(f"a:{slot_name}", ns)
        if slot is not None:
            set_color_slot(slot, value)


def update_theme_fonts(root: etree._Element, variant: DesignVariant) -> None:
    """Update theme fonts from a DesignVariant."""
    ns = {"a": A_NS}
    font_scheme = find_element(root, ".//a:fontScheme", ns)
    if font_scheme is None:
        return

    def _update(tag: str, font_name: str) -> None:
        group = font_scheme.find(f"a:{tag}", ns)
        if group is None:
            return
        latin = group.find("a:latin", ns)
        if latin is not None:
            latin.set("typeface", font_name)

    _update("majorFont", variant.major_font)
    _update("minorFont", variant.minor_font)


def update_theme_names(root: etree._Element, variant: DesignVariant) -> None:
    """Update theme and scheme names from a DesignVariant."""
    set_theme_name(root, variant.name)
    set_scheme_name(root, "clrScheme", variant.name)
    set_scheme_name(root, "fontScheme", variant.name)
    set_scheme_name(root, "fmtScheme", variant.name)


def _render_theme_xml(root: etree._Element) -> bytes:
    register_theme_namespaces()
    return serialize_tree(root)


def _apply_variant_to_theme_xml(
    theme_xml: bytes,
    variant_map: Dict[str, DesignVariant],
    *,
    update_names: bool,
) -> bytes:
    root = parse_xml(theme_xml.decode("utf-8-sig"))
    vid = extract_theme_family_vid(root)
    variant = variant_map.get(vid) if vid else None
    if variant is None:
        variant = next(iter(variant_map.values()))
    update_theme_colors(root, variant)
    update_theme_fonts(root, variant)
    if update_names:
        update_theme_names(root, variant)
    return _render_theme_xml(root)


# ---------------------------------------------------------------------------
# Variant extraction
# ---------------------------------------------------------------------------


def design_variant_from_theme_xml(theme_xml: str, name: str) -> DesignVariant:
    """Extract DesignVariant from theme XML."""
    from tokenmoulds.themes.supertheme import DesignVariant

    root = parse_xml(theme_xml)
    ns = {"a": A_NS}
    defaults = DesignVariant(name=name)
    clr_scheme = find_element(root, ".//a:clrScheme", ns)

    def read_color(slot: str, fallback: str) -> str:
        if clr_scheme is None:
            return fallback
        node = clr_scheme.find(f"a:{slot}", ns)
        if node is None:
            return fallback
        sys = node.find("a:sysClr", ns)
        if sys is not None:
            last = sys.attrib.get("lastClr")
            return normalize_hex_color(last) if last else fallback
        srgb = node.find("a:srgbClr", ns)
        if srgb is not None:
            val = srgb.attrib.get("val")
            return normalize_hex_color(val) if val else fallback
        return fallback

    font_scheme = find_element(root, ".//a:fontScheme", ns)
    major_font = defaults.major_font
    minor_font = defaults.minor_font
    if font_scheme is not None:
        major = font_scheme.find("a:majorFont/a:latin", ns)
        minor = font_scheme.find("a:minorFont/a:latin", ns)
        if major is not None and major.attrib.get("typeface"):
            major_font = major.attrib["typeface"]
        if minor is not None and minor.attrib.get("typeface"):
            minor_font = minor.attrib["typeface"]

    return DesignVariant(
        name=name,
        dk1=read_color("dk1", defaults.dk1),
        lt1=read_color("lt1", defaults.lt1),
        dk2=read_color("dk2", defaults.dk2),
        lt2=read_color("lt2", defaults.lt2),
        accent1=read_color("accent1", defaults.accent1),
        accent2=read_color("accent2", defaults.accent2),
        accent3=read_color("accent3", defaults.accent3),
        accent4=read_color("accent4", defaults.accent4),
        accent5=read_color("accent5", defaults.accent5),
        accent6=read_color("accent6", defaults.accent6),
        hlink=read_color("hlink", defaults.hlink),
        folHlink=read_color("folHlink", defaults.folHlink),
        major_font=str(major_font),
        minor_font=str(minor_font),
    )


def _collect_theme_xml_by_vid(zf: zipfile.ZipFile) -> Dict[str, str]:
    theme_xml_by_vid: Dict[str, str] = {}
    for name in zf.namelist():
        if not name.endswith(THEME1_SUFFIX):
            continue
        theme_xml = zf.read(name).decode("utf-8-sig")
        root = parse_xml(theme_xml)
        vid = extract_theme_family_vid(root)
        if vid and vid not in theme_xml_by_vid:
            theme_xml_by_vid[vid] = theme_xml
    return theme_xml_by_vid


def extract_design_variants_from_supertheme(path: str | Path) -> List[DesignVariant]:
    """Extract design variants from an existing SuperTheme package."""
    path = Path(path)
    with zipfile.ZipFile(path) as zf:
        manager_xml = zf.read("themeVariants/themeVariantManager.xml").decode(
            "utf-8-sig"
        )
        vid_order = parse_theme_variant_vids(manager_xml)
        vid_names = parse_theme_variant_names(manager_xml)
        theme_xml_by_vid = _collect_theme_xml_by_vid(zf)

    variants: List[DesignVariant] = []
    for index, vid in enumerate(vid_order, start=1):
        theme_xml = theme_xml_by_vid.get(vid)
        if theme_xml is None:
            continue
        name = vid_names.get(vid, f"Design {index}")
        variants.append(design_variant_from_theme_xml(theme_xml, name))
    return variants


# ---------------------------------------------------------------------------
# Patching
# ---------------------------------------------------------------------------


def _map_design_variants_to_vids(
    vids: List[str], design_variants: List[DesignVariant]
) -> Dict[str, DesignVariant]:
    if not design_variants:
        raise ValueError("No design variants provided")
    if len(design_variants) == 1:
        return {vid: design_variants[0] for vid in vids}
    if len(design_variants) < len(vids):
        raise ValueError(
            f"Need at least {len(vids)} design variants to patch this SuperTheme"
        )
    return {vid: design_variants[index] for index, vid in enumerate(vids)}


def _collect_variant_by_prefix(
    zf: zipfile.ZipFile, variant_map: Dict[str, DesignVariant]
) -> Dict[str, DesignVariant]:
    default_variant = next(iter(variant_map.values()))
    variants: Dict[str, DesignVariant] = {}
    for name in zf.namelist():
        if not name.endswith(THEME1_SUFFIX):
            continue
        theme_xml = zf.read(name).decode("utf-8-sig")
        root = parse_xml(theme_xml)
        vid = extract_theme_family_vid(root)
        if vid is None:
            continue
        variant = variant_map.get(vid, default_variant)
        prefix = name[: -len(THEME1_SUFFIX)]
        variants[prefix] = variant
    return variants


def _build_thumbnail_replacements(
    zf: zipfile.ZipFile, variant_map: Dict[str, DesignVariant]
) -> Dict[str, bytes]:
    names = set(zf.namelist())
    replacements: Dict[str, bytes] = {}
    for prefix, variant in _collect_variant_by_prefix(zf, variant_map).items():
        color = _hex_to_rgb(variant.accent1)
        thumbnails = build_thumbnail_payloads(color)
        theme_prefix = f"{prefix}theme/theme/"
        for key in (
            "themeThumbnail.jpeg",
            "auxiliaryThemeThumbnail.jpeg",
            "auxiliaryThemeThumbnailMedium.jpeg",
        ):
            path = f"{theme_prefix}{key}"
            if path in names:
                replacements[path] = thumbnails[key]
        doc_path = f"{prefix}docProps/thumbnail.jpeg"
        if doc_path in names:
            replacements[doc_path] = thumbnails["thumbnail.jpeg"]
    return replacements


def patch_supertheme(
    base_path: str | Path,
    design_variants: List[DesignVariant],
    output_path: Optional[str | Path] = None,
    *,
    update_theme_names: bool = False,
    update_thumbnails: bool = False,
) -> bytes:
    """Patch an existing SuperTheme with new colors/fonts."""
    base_path = Path(base_path)
    with zipfile.ZipFile(base_path) as zf:
        manager_xml = zf.read("themeVariants/themeVariantManager.xml").decode(
            "utf-8-sig"
        )
        vids = parse_theme_variant_vids(manager_xml)
        variant_map = _map_design_variants_to_vids(vids, design_variants)
        thumbnail_replacements = (
            _build_thumbnail_replacements(zf, variant_map) if update_thumbnails else {}
        )

        buffer = io.BytesIO()
        with zipfile.ZipFile(
            buffer, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9
        ) as out:
            for info in zf.infolist():
                data = zf.read(info.filename)
                if info.filename.endswith(THEME1_SUFFIX):
                    data = _apply_variant_to_theme_xml(
                        data, variant_map, update_names=update_theme_names
                    )
                elif update_thumbnails and info.filename in thumbnail_replacements:
                    data = thumbnail_replacements[info.filename]
                out.writestr(info.filename, data)

    buffer.seek(0)
    data = buffer.getvalue()
    if output_path:
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_bytes(data)
    return data


def patch_supertheme_from_source(
    base_path: str | Path,
    source_path: str | Path,
    output_path: Optional[str | Path] = None,
    *,
    update_theme_names: bool = False,
    update_thumbnails: bool = False,
) -> bytes:
    """Patch a SuperTheme using design variants extracted from another package."""
    design_variants = extract_design_variants_from_supertheme(source_path)
    return patch_supertheme(
        base_path,
        design_variants,
        output_path=output_path,
        update_theme_names=update_theme_names,
        update_thumbnails=update_thumbnails,
    )
