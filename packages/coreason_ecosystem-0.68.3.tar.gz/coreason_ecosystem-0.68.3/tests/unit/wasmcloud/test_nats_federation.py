# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: https://github.com/CoReason-AI/coreason-ecosystem

from coreason_ecosystem.wasmcloud.nats_federation import NATSFederationProxy


def test_scan_dlp_clean() -> None:
    """Verify that a clean string contains no DLP violations."""
    res = NATSFederationProxy._scan_dlp(
        "This is a completely safe and clean string with no credentials."
    )
    assert res["clean"] is True
    assert len(res["violations"]) == 0


def test_scan_dlp_violations() -> None:
    """Verify that sensitive patterns are caught by the DLP scanner."""
    # 1. Test SSN
    res_ssn = NATSFederationProxy._scan_dlp("User SSN: 000-12-3456")
    assert res_ssn["clean"] is False
    assert "ssn" in res_ssn["violations"]

    # 2. Test Credit Card
    res_cc = NATSFederationProxy._scan_dlp("Visa: 4111111111111111")
    assert res_cc["clean"] is False
    assert "credit_card" in res_cc["violations"]

    # 3. Test SSH Private Key
    res_ssh = NATSFederationProxy._scan_dlp("-----BEGIN OPENSSH PRIVATE KEY-----\nMOCK")
    assert res_ssh["clean"] is False
    assert "ssh_private_key" in res_ssh["violations"]

    # 4. Test Vault Token
    res_vault = NATSFederationProxy._scan_dlp(
        "My vault token is hvs.a1b2c3d4e5f6g7h8i9j0k1l2m3n4"
    )
    assert res_vault["clean"] is False
    assert "vault_token" in res_vault["violations"]

    # 5. Test AWS Key
    res_aws = NATSFederationProxy._scan_dlp("Access: AKIAIOSFODNN7EXAMPLE")
    assert res_aws["clean"] is False
    assert "aws_access_key" in res_aws["violations"]
