# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-ecosystem>

"""Tests for coreason_ecosystem.orchestration.oci_registry_api module.

Covers CapabilityDiscoveryResult model and OCIRegistryQueryAPI including
discover, async_discover, _scan_ledger, and _scan_registry methods.
Uses monkeypatch, tmp_path, and real fake objects — no unittest.mock.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import pytest
import httpx

from coreason_ecosystem.orchestration.oci_registry_api import (
    CapabilityDiscoveryResult,
    OCIRegistryQueryAPI,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class FakeHttpxResponse:
    """Fake response for httpx.Client and httpx.AsyncClient."""

    def __init__(self, data: dict[str, Any], status_code: int = 200) -> None:
        self._data = data
        self.status_code = status_code

    def json(self) -> dict[str, Any]:
        return self._data

    def raise_for_status(self) -> None:
        if self.status_code >= 400:
            raise httpx.HTTPStatusError("HTTP Error", request=None, response=None)  # type: ignore[arg-type]

    async def __aenter__(self) -> "FakeHttpxResponse":
        return self

    async def __aexit__(self, *args: Any) -> None:
        pass


# ---------------------------------------------------------------------------
# CapabilityDiscoveryResult model tests
# ---------------------------------------------------------------------------


class TestCapabilityDiscoveryResult:
    """Tests for the CapabilityDiscoveryResult pydantic model."""

    def test_all_fields(self) -> None:
        result = CapabilityDiscoveryResult(
            urn="urn:coreason:solver:test",
            oci_uri="ghcr.io/coreason-ai/test:v1",
            version="v1.2.3",
            description="A test solver",
            license_tier="commercial",
            tags=["ml", "solver"],
        )
        assert result.urn == "urn:coreason:solver:test"
        assert result.oci_uri == "ghcr.io/coreason-ai/test:v1"
        assert result.version == "v1.2.3"
        assert result.description == "A test solver"
        assert result.license_tier == "commercial"
        assert result.tags == ["ml", "solver"]

    def test_defaults(self) -> None:
        result = CapabilityDiscoveryResult(
            urn="urn:coreason:solver:min",
            oci_uri="ghcr.io/test:latest",
        )
        assert result.version == "latest"
        assert result.description == ""
        assert result.license_tier == "prosperity-3.0"
        assert result.tags == []

    def test_serialization_roundtrip(self) -> None:
        result = CapabilityDiscoveryResult(
            urn="urn:coreason:solver:rt",
            oci_uri="ghcr.io/rt:v2",
            tags=["a", "b"],
        )
        data = result.model_dump()
        restored = CapabilityDiscoveryResult(**data)
        assert restored.urn == result.urn
        assert restored.tags == result.tags

    def test_empty_tags(self) -> None:
        result = CapabilityDiscoveryResult(
            urn="urn:test",
            oci_uri="ghcr.io/test",
            tags=[],
        )
        assert result.tags == []


# ---------------------------------------------------------------------------
# OCIRegistryQueryAPI.__init__ tests
# ---------------------------------------------------------------------------


class TestOCIRegistryQueryAPIInit:
    """Tests for OCIRegistryQueryAPI initialization."""

    def test_explicit_params(self) -> None:
        api = OCIRegistryQueryAPI(
            registry_url="custom.registry.io/org",
            ledger_path="/path/to/ledger.yaml",
        )
        assert api.registry_url == "custom.registry.io/org"
        assert api.ledger_path == "/path/to/ledger.yaml"

    def test_defaults_from_env(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("COREASON_OCI_REGISTRY", "env.registry.io/test")
        api = OCIRegistryQueryAPI()
        assert api.registry_url == "env.registry.io/test"
        assert api.ledger_path is None

    def test_defaults_fallback(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("COREASON_OCI_REGISTRY", raising=False)
        api = OCIRegistryQueryAPI()
        assert api.registry_url == "ghcr.io/coreason-ai"

    def test_explicit_overrides_env(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("COREASON_OCI_REGISTRY", "env.io")
        api = OCIRegistryQueryAPI(registry_url="explicit.io")
        assert api.registry_url == "explicit.io"


# ---------------------------------------------------------------------------
# OCIRegistryQueryAPI._scan_ledger tests
# ---------------------------------------------------------------------------


class TestScanLedger:
    """Tests for the _scan_ledger method using real YAML files."""

    def test_scan_ledger_happy_path(self, tmp_path: Path) -> None:
        import yaml

        ledger_content = {
            "capabilities": [
                {
                    "urn": "urn:coreason:solver:alpha",
                    "oci_uri": "ghcr.io/coreason-ai/alpha:latest",
                    "version": "1.0.0",
                    "description": "Alpha solver",
                    "license_tier": "prosperity-3.0",
                    "tags": ["ml"],
                },
                {
                    "urn": "urn:coreason:solver:beta",
                    "oci_uri": "ghcr.io/coreason-ai/beta:latest",
                    "version": "2.0.0",
                    "description": "Beta solver",
                    "license_tier": "commercial",
                    "tags": ["production"],
                },
            ]
        }
        ledger_file = tmp_path / "ledger.yaml"
        ledger_file.write_text(yaml.dump(ledger_content), encoding="utf-8")

        api = OCIRegistryQueryAPI(ledger_path=str(ledger_file))
        results = api._scan_ledger("urn:coreason:")

        assert len(results) == 2
        assert results[0].urn == "urn:coreason:solver:alpha"
        assert results[0].version == "1.0.0"
        assert results[1].urn == "urn:coreason:solver:beta"
        assert results[1].license_tier == "commercial"

    def test_scan_ledger_urn_prefix_filter(self, tmp_path: Path) -> None:
        import yaml

        ledger_content = {
            "capabilities": [
                {"urn": "urn:coreason:solver:match", "oci_uri": "a"},
                {"urn": "urn:other:solver:no-match", "oci_uri": "b"},
            ]
        }
        ledger_file = tmp_path / "ledger.yaml"
        ledger_file.write_text(yaml.dump(ledger_content), encoding="utf-8")

        api = OCIRegistryQueryAPI(ledger_path=str(ledger_file))
        results = api._scan_ledger("urn:coreason:")
        assert len(results) == 1
        assert results[0].urn == "urn:coreason:solver:match"

    def test_scan_ledger_nonexistent_file(self, tmp_path: Path) -> None:
        api = OCIRegistryQueryAPI(ledger_path=str(tmp_path / "does_not_exist.yaml"))
        results = api._scan_ledger("urn:coreason:")
        assert results == []

    def test_scan_ledger_no_ledger_path(self) -> None:
        api = OCIRegistryQueryAPI(ledger_path=None)
        results = api._scan_ledger("urn:coreason:")
        assert results == []

    def test_scan_ledger_empty_yaml(self, tmp_path: Path) -> None:
        ledger_file = tmp_path / "empty.yaml"
        ledger_file.write_text("", encoding="utf-8")

        api = OCIRegistryQueryAPI(ledger_path=str(ledger_file))
        results = api._scan_ledger("urn:coreason:")
        assert results == []

    def test_scan_ledger_no_capabilities_key(self, tmp_path: Path) -> None:
        import yaml

        ledger_file = tmp_path / "no_caps.yaml"
        ledger_file.write_text(yaml.dump({"other": []}), encoding="utf-8")

        api = OCIRegistryQueryAPI(ledger_path=str(ledger_file))
        results = api._scan_ledger("urn:coreason:")
        assert results == []

    def test_scan_ledger_malformed_yaml(self, tmp_path: Path) -> None:
        ledger_file = tmp_path / "malformed.yaml"
        ledger_file.write_text("{{invalid yaml::", encoding="utf-8")

        api = OCIRegistryQueryAPI(ledger_path=str(ledger_file))
        # Should not raise, just return empty
        results = api._scan_ledger("urn:coreason:")
        assert results == []

    def test_scan_ledger_missing_fields_defaults(self, tmp_path: Path) -> None:
        import yaml

        ledger_content = {
            "capabilities": [
                {
                    "urn": "urn:coreason:solver:minimal",
                    # oci_uri not provided -> defaults to ""
                }
            ]
        }
        ledger_file = tmp_path / "minimal.yaml"
        ledger_file.write_text(yaml.dump(ledger_content), encoding="utf-8")

        api = OCIRegistryQueryAPI(ledger_path=str(ledger_file))
        results = api._scan_ledger("urn:coreason:")
        assert len(results) == 1
        assert results[0].oci_uri == ""
        assert results[0].version == "latest"
        assert results[0].description == ""


# ---------------------------------------------------------------------------
# OCIRegistryQueryAPI._scan_registry tests
# ---------------------------------------------------------------------------


class TestScanRegistry:
    """Tests for the _scan_registry method using monkeypatched httpx."""

    def test_scan_registry_happy_path(self, monkeypatch: pytest.MonkeyPatch) -> None:
        api = OCIRegistryQueryAPI(registry_url="ghcr.io/coreason-ai")
        monkeypatch.delenv("COREASON_OCI_TOKEN", raising=False)

        def fake_get(*args: Any, **kwargs: Any) -> FakeHttpxResponse:
            return FakeHttpxResponse(
                {
                    "repositories": [
                        "coreason-ai/coreason-solver-alpha",
                        "coreason-ai/coreason-solver-beta",
                        "other-org/other-repo",
                    ]
                }
            )

        monkeypatch.setattr(httpx.Client, "get", fake_get)

        results = api._scan_registry("urn:coreason:")
        assert len(results) == 2
        urns = {r.urn for r in results}
        assert "urn:coreason:solver:coreason-solver-alpha" in urns
        assert "urn:coreason:solver:coreason-solver-beta" in urns

    def test_scan_registry_with_auth_token(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("COREASON_OCI_TOKEN", "my-secret-token")
        api = OCIRegistryQueryAPI(registry_url="ghcr.io/coreason-ai")

        captured_headers: list[Any] = []

        def fake_get(
            self_client: Any,
            url: str,
            headers: dict[str, str] | None = None,
            **kwargs: Any,
        ) -> FakeHttpxResponse:
            captured_headers.append(headers)
            return FakeHttpxResponse({"repositories": []})

        monkeypatch.setattr(httpx.Client, "get", fake_get)

        api._scan_registry("urn:coreason:")

        assert len(captured_headers) == 1
        assert captured_headers[0].get("Authorization") == "Bearer my-secret-token"

    def test_scan_registry_no_auth_token(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("COREASON_OCI_TOKEN", raising=False)
        api = OCIRegistryQueryAPI(registry_url="ghcr.io/coreason-ai")

        captured_headers: list[Any] = []

        def fake_get(
            self_client: Any,
            url: str,
            headers: dict[str, str] | None = None,
            **kwargs: Any,
        ) -> FakeHttpxResponse:
            captured_headers.append(headers)
            return FakeHttpxResponse({"repositories": []})

        monkeypatch.setattr(httpx.Client, "get", fake_get)

        api._scan_registry("urn:coreason:")
        assert captured_headers[0].get("Authorization") is None

    def test_scan_registry_connection_error(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        api = OCIRegistryQueryAPI(registry_url="ghcr.io/coreason-ai")

        def fake_get(*args: Any, **kwargs: Any) -> Any:
            raise httpx.RequestError("unreachable")

        monkeypatch.setattr(httpx.Client, "get", fake_get)

        # Should not raise, just return empty
        results = api._scan_registry("urn:coreason:")
        assert results == []

    def test_scan_registry_urn_prefix_filter(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        api = OCIRegistryQueryAPI(registry_url="ghcr.io/coreason-ai")
        monkeypatch.delenv("COREASON_OCI_TOKEN", raising=False)

        def fake_get(*args: Any, **kwargs: Any) -> FakeHttpxResponse:
            return FakeHttpxResponse(
                {"repositories": ["coreason-ai/coreason-solver-test"]}
            )

        monkeypatch.setattr(httpx.Client, "get", fake_get)

        # Use a prefix that doesn't match
        results = api._scan_registry("urn:other:")
        assert results == []

    def test_scan_registry_oci_uri_format(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        api = OCIRegistryQueryAPI(registry_url="ghcr.io/coreason-ai")
        monkeypatch.delenv("COREASON_OCI_TOKEN", raising=False)

        def fake_get(*args: Any, **kwargs: Any) -> FakeHttpxResponse:
            return FakeHttpxResponse(
                {"repositories": ["coreason-ai/coreason-solver-x"]}
            )

        monkeypatch.setattr(httpx.Client, "get", fake_get)

        results = api._scan_registry("urn:coreason:")
        assert len(results) == 1
        assert (
            results[0].oci_uri
            == "ghcr.io/coreason-ai/coreason-ai/coreason-solver-x:latest"
        )
        assert results[0].tags == ["auto-discovered"]

    def test_scan_registry_empty_catalog(self, monkeypatch: pytest.MonkeyPatch) -> None:
        api = OCIRegistryQueryAPI(registry_url="ghcr.io/coreason-ai")
        monkeypatch.delenv("COREASON_OCI_TOKEN", raising=False)

        def fake_get(*args: Any, **kwargs: Any) -> FakeHttpxResponse:
            return FakeHttpxResponse({"repositories": []})

        monkeypatch.setattr(httpx.Client, "get", fake_get)

        results = api._scan_registry("urn:coreason:")
        assert results == []


# ---------------------------------------------------------------------------
# OCIRegistryQueryAPI.discover & async_discover tests
# ---------------------------------------------------------------------------


class TestDiscover:
    """Tests for the discover and async_discover methods."""

    def test_discover_from_ledger_only(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        import yaml

        ledger_content = {
            "capabilities": [
                {
                    "urn": "urn:coreason:solver:ledger-cap",
                    "oci_uri": "ghcr.io/test:v1",
                    "tags": ["ml"],
                    "license_tier": "prosperity-3.0",
                }
            ]
        }
        ledger_file = tmp_path / "ledger.yaml"
        ledger_file.write_text(yaml.dump(ledger_content), encoding="utf-8")

        def fake_get(*args: Any, **kwargs: Any) -> FakeHttpxResponse:
            return FakeHttpxResponse({"repositories": []})

        monkeypatch.setattr(httpx.Client, "get", fake_get)
        monkeypatch.delenv("COREASON_OCI_TOKEN", raising=False)

        api = OCIRegistryQueryAPI(
            registry_url="ghcr.io/coreason-ai",
            ledger_path=str(ledger_file),
        )
        results = api.discover()
        assert len(results) == 1
        assert results[0].urn == "urn:coreason:solver:ledger-cap"

    @pytest.mark.asyncio
    async def test_async_discover_from_ledger_only(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        import yaml

        ledger_content = {
            "capabilities": [
                {
                    "urn": "urn:coreason:solver:ledger-cap-async",
                    "oci_uri": "ghcr.io/test:v1",
                    "tags": ["ml"],
                    "license_tier": "prosperity-3.0",
                }
            ]
        }
        ledger_file = tmp_path / "ledger.yaml"
        ledger_file.write_text(yaml.dump(ledger_content), encoding="utf-8")

        async def fake_async_get(*args: Any, **kwargs: Any) -> FakeHttpxResponse:
            return FakeHttpxResponse({"repositories": []})

        monkeypatch.setattr(httpx.AsyncClient, "get", fake_async_get)
        monkeypatch.delenv("COREASON_OCI_TOKEN", raising=False)

        api = OCIRegistryQueryAPI(
            registry_url="ghcr.io/coreason-ai",
            ledger_path=str(ledger_file),
        )
        results = await api.async_discover()
        assert len(results) == 1
        assert results[0].urn == "urn:coreason:solver:ledger-cap-async"

    def test_discover_from_registry_only(self, monkeypatch: pytest.MonkeyPatch) -> None:
        def fake_get(*args: Any, **kwargs: Any) -> FakeHttpxResponse:
            return FakeHttpxResponse({"repositories": ["org/coreason-solver-reg"]})

        monkeypatch.setattr(httpx.Client, "get", fake_get)
        monkeypatch.delenv("COREASON_OCI_TOKEN", raising=False)

        api = OCIRegistryQueryAPI(registry_url="ghcr.io/coreason-ai")
        results = api.discover()
        assert len(results) == 1
        assert results[0].urn == "urn:coreason:solver:coreason-solver-reg"

    @pytest.mark.asyncio
    async def test_async_discover_from_registry_only(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        async def fake_async_get(*args: Any, **kwargs: Any) -> FakeHttpxResponse:
            return FakeHttpxResponse(
                {"repositories": ["org/coreason-solver-reg-async"]}
            )

        monkeypatch.setattr(httpx.AsyncClient, "get", fake_async_get)
        monkeypatch.delenv("COREASON_OCI_TOKEN", raising=False)

        api = OCIRegistryQueryAPI(registry_url="ghcr.io/coreason-ai")
        results = await api.async_discover()
        assert len(results) == 1
        assert results[0].urn == "urn:coreason:solver:coreason-solver-reg-async"

    def test_discover_deduplication(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        import yaml

        ledger_content = {
            "capabilities": [
                {
                    "urn": "urn:coreason:solver:coreason-solver-dup",
                    "oci_uri": "ghcr.io/test:v1",
                }
            ]
        }
        ledger_file = tmp_path / "ledger.yaml"
        ledger_file.write_text(yaml.dump(ledger_content), encoding="utf-8")

        def fake_get(*args: Any, **kwargs: Any) -> FakeHttpxResponse:
            return FakeHttpxResponse({"repositories": ["org/coreason-solver-dup"]})

        monkeypatch.setattr(httpx.Client, "get", fake_get)
        monkeypatch.delenv("COREASON_OCI_TOKEN", raising=False)

        api = OCIRegistryQueryAPI(
            registry_url="ghcr.io/coreason-ai",
            ledger_path=str(ledger_file),
        )
        results = api.discover()
        assert len(results) == 1
        assert results[0].oci_uri == "ghcr.io/test:v1"

    def test_discover_filter_by_license_tier(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        import yaml

        ledger_content = {
            "capabilities": [
                {
                    "urn": "urn:coreason:solver:free",
                    "oci_uri": "a",
                    "license_tier": "prosperity-3.0",
                },
                {
                    "urn": "urn:coreason:solver:paid",
                    "oci_uri": "b",
                    "license_tier": "commercial",
                },
            ]
        }
        ledger_file = tmp_path / "ledger.yaml"
        ledger_file.write_text(yaml.dump(ledger_content), encoding="utf-8")

        def fake_get(*args: Any, **kwargs: Any) -> FakeHttpxResponse:
            return FakeHttpxResponse({"repositories": []})

        monkeypatch.setattr(httpx.Client, "get", fake_get)
        monkeypatch.delenv("COREASON_OCI_TOKEN", raising=False)

        api = OCIRegistryQueryAPI(
            registry_url="ghcr.io/coreason-ai",
            ledger_path=str(ledger_file),
        )
        results = api.discover(license_tier="commercial")
        assert len(results) == 1
        assert results[0].urn == "urn:coreason:solver:paid"

    def test_discover_filter_by_tags(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        import yaml

        ledger_content = {
            "capabilities": [
                {
                    "urn": "urn:coreason:solver:tagged",
                    "oci_uri": "a",
                    "tags": ["ml", "production"],
                },
                {
                    "urn": "urn:coreason:solver:untagged",
                    "oci_uri": "b",
                    "tags": ["experimental"],
                },
            ]
        }
        ledger_file = tmp_path / "ledger.yaml"
        ledger_file.write_text(yaml.dump(ledger_content), encoding="utf-8")

        def fake_get(*args: Any, **kwargs: Any) -> FakeHttpxResponse:
            return FakeHttpxResponse({"repositories": []})

        monkeypatch.setattr(httpx.Client, "get", fake_get)
        monkeypatch.delenv("COREASON_OCI_TOKEN", raising=False)

        api = OCIRegistryQueryAPI(
            registry_url="ghcr.io/coreason-ai",
            ledger_path=str(ledger_file),
        )
        results = api.discover(tags=["ml"])
        assert len(results) == 1
        assert results[0].urn == "urn:coreason:solver:tagged"

    def test_discover_filter_by_tags_intersection(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        import yaml

        ledger_content = {
            "capabilities": [
                {
                    "urn": "urn:coreason:solver:multi",
                    "oci_uri": "a",
                    "tags": ["alpha", "beta"],
                },
            ]
        }
        ledger_file = tmp_path / "ledger.yaml"
        ledger_file.write_text(yaml.dump(ledger_content), encoding="utf-8")

        def fake_get(*args: Any, **kwargs: Any) -> FakeHttpxResponse:
            return FakeHttpxResponse({"repositories": []})

        monkeypatch.setattr(httpx.Client, "get", fake_get)
        monkeypatch.delenv("COREASON_OCI_TOKEN", raising=False)

        api = OCIRegistryQueryAPI(
            registry_url="ghcr.io/coreason-ai",
            ledger_path=str(ledger_file),
        )
        results = api.discover(tags=["beta", "gamma"])
        assert len(results) == 1

    def test_discover_no_results(self, monkeypatch: pytest.MonkeyPatch) -> None:
        def fake_get(*args: Any, **kwargs: Any) -> FakeHttpxResponse:
            return FakeHttpxResponse({"repositories": []})

        monkeypatch.setattr(httpx.Client, "get", fake_get)
        monkeypatch.delenv("COREASON_OCI_TOKEN", raising=False)

        api = OCIRegistryQueryAPI(registry_url="ghcr.io/coreason-ai")
        results = api.discover()
        assert results == []

    def test_discover_urn_prefix_filter(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        import yaml

        ledger_content = {
            "capabilities": [
                {
                    "urn": "urn:coreason:solver:match",
                    "oci_uri": "a",
                },
                {
                    "urn": "urn:other:solver:no-match",
                    "oci_uri": "b",
                },
            ]
        }
        ledger_file = tmp_path / "ledger.yaml"
        ledger_file.write_text(yaml.dump(ledger_content), encoding="utf-8")

        def fake_get(*args: Any, **kwargs: Any) -> FakeHttpxResponse:
            return FakeHttpxResponse({"repositories": []})

        monkeypatch.setattr(httpx.Client, "get", fake_get)
        monkeypatch.delenv("COREASON_OCI_TOKEN", raising=False)

        api = OCIRegistryQueryAPI(
            registry_url="ghcr.io/coreason-ai",
            ledger_path=str(ledger_file),
        )
        results = api.discover(urn_prefix="urn:coreason:")
        assert len(results) == 1
        assert results[0].urn == "urn:coreason:solver:match"

    def test_discover_combined_filters(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        import yaml

        ledger_content = {
            "capabilities": [
                {
                    "urn": "urn:coreason:solver:a",
                    "oci_uri": "x",
                    "license_tier": "commercial",
                    "tags": ["prod"],
                },
                {
                    "urn": "urn:coreason:solver:b",
                    "oci_uri": "y",
                    "license_tier": "commercial",
                    "tags": ["dev"],
                },
                {
                    "urn": "urn:coreason:solver:c",
                    "oci_uri": "z",
                    "license_tier": "prosperity-3.0",
                    "tags": ["prod"],
                },
            ]
        }
        ledger_file = tmp_path / "ledger.yaml"
        ledger_file.write_text(yaml.dump(ledger_content), encoding="utf-8")

        def fake_get(*args: Any, **kwargs: Any) -> FakeHttpxResponse:
            return FakeHttpxResponse({"repositories": []})

        monkeypatch.setattr(httpx.Client, "get", fake_get)
        monkeypatch.delenv("COREASON_OCI_TOKEN", raising=False)

        api = OCIRegistryQueryAPI(
            registry_url="ghcr.io/coreason-ai",
            ledger_path=str(ledger_file),
        )
        results = api.discover(license_tier="commercial", tags=["prod"])
        assert len(results) == 1
        assert results[0].urn == "urn:coreason:solver:a"

    def test_discover_no_ledger_path_skips_ledger_scan(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        def fake_get(*args: Any, **kwargs: Any) -> FakeHttpxResponse:
            return FakeHttpxResponse({"repositories": ["org/coreason-solver-only"]})

        monkeypatch.setattr(httpx.Client, "get", fake_get)
        monkeypatch.delenv("COREASON_OCI_TOKEN", raising=False)

        api = OCIRegistryQueryAPI(
            registry_url="ghcr.io/coreason-ai",
            ledger_path=None,
        )
        results = api.discover()
        assert len(results) == 1

    def test_discover_registry_error_returns_ledger_results(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        import yaml

        ledger_content = {
            "capabilities": [
                {
                    "urn": "urn:coreason:solver:ledger-only",
                    "oci_uri": "a",
                }
            ]
        }
        ledger_file = tmp_path / "ledger.yaml"
        ledger_file.write_text(yaml.dump(ledger_content), encoding="utf-8")

        def fake_get(*args: Any, **kwargs: Any) -> Any:
            raise httpx.RequestError("registry down")

        monkeypatch.setattr(httpx.Client, "get", fake_get)
        monkeypatch.delenv("COREASON_OCI_TOKEN", raising=False)

        api = OCIRegistryQueryAPI(
            registry_url="ghcr.io/coreason-ai",
            ledger_path=str(ledger_file),
        )
        results = api.discover()
        assert len(results) == 1
        assert results[0].urn == "urn:coreason:solver:ledger-only"

    @pytest.mark.asyncio
    async def test_async_discover_registry_error_returns_ledger_results(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        import yaml

        ledger_content = {
            "capabilities": [
                {
                    "urn": "urn:coreason:solver:ledger-only-async",
                    "oci_uri": "a",
                }
            ]
        }
        ledger_file = tmp_path / "ledger.yaml"
        ledger_file.write_text(yaml.dump(ledger_content), encoding="utf-8")

        async def fake_async_get(*args: Any, **kwargs: Any) -> Any:
            raise httpx.RequestError("registry down")

        monkeypatch.setattr(httpx.AsyncClient, "get", fake_async_get)
        monkeypatch.delenv("COREASON_OCI_TOKEN", raising=False)

        api = OCIRegistryQueryAPI(
            registry_url="ghcr.io/coreason-ai",
            ledger_path=str(ledger_file),
        )
        results = await api.async_discover()
        assert len(results) == 1
        assert results[0].urn == "urn:coreason:solver:ledger-only-async"
