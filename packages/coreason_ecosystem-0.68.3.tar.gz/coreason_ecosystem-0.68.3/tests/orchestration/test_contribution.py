# Copyright (c) 2026 CoReason, Inc.
from typer.testing import CliRunner
from coreason_ecosystem.cli import app
from coreason_ecosystem.orchestration.contribution import (
    TenantContributionStats,
    calculate_anti_abuse_multiplier,
    evaluate_royalty_split,
)
from coreason_ecosystem.utils.urn_authority_client import LedgerEntry

runner = CliRunner()


def test_contribution_stats_model() -> None:
    stats = TenantContributionStats(
        tenant_cid="urn:tenant:test-cid",
        uptime_hours=100.0,
        bandwidth_gb=50.0,
        pvv_validations=5,
        deficit_credits=1000.0,
    )
    # score = 100 * 1.0 + 50 * 0.5 + 5 * 10.0 + 1000 * 0.1 = 100 + 25 + 50 + 100 = 275
    assert stats.reputation_score == 275.0
    assert stats.reputation_tier == "Contributor"

    assert (
        TenantContributionStats(tenant_cid="x", pvv_validations=60).reputation_tier
        == "Expert"
    )
    assert "Verified Publisher" in stats.badges
    assert "Silver Sandbox" in stats.badges
    assert "Gold Verification" not in stats.badges
    assert "Real Verified" not in stats.badges

    verified_stats = TenantContributionStats(
        tenant_cid="urn:tenant:test-cid", id_verified=True
    )
    assert "Real Verified" in verified_stats.badges


def test_anti_abuse_multiplier() -> None:
    assert calculate_anti_abuse_multiplier(1) == 1.0
    assert calculate_anti_abuse_multiplier(2) == 1.0 / 1.05
    assert calculate_anti_abuse_multiplier(10) == 1.0 / 1.45


def test_royalty_split_eval() -> None:
    shares = {"did:key:author1": 60.0, "did:key:author2": 40.0}

    # 1. No self dealing, 1 call
    res = evaluate_royalty_split(
        payout_amount=100.0,
        shares=shares,
        caller_cid="urn:tenant:other",
        provider_did="did:key:author1",
        consecutive_calls=1,
    )
    assert res == {"did:key:author1": 60.0, "did:key:author2": 40.0}

    # 2. Self dealing split to 0
    res_self = evaluate_royalty_split(
        payout_amount=100.0,
        shares=shares,
        caller_cid="urn:tenant:author1",
        provider_did="did:key:author1",
        consecutive_calls=1,
    )
    assert res_self == {"did:key:author1": 0.0, "did:key:author2": 40.0}


def test_cli_contribution_stats() -> None:
    result = runner.invoke(
        app, ["contribution", "stats", "--uptime", "10", "--bandwidth", "20"]
    )
    assert result.exit_code == 0
    assert "COCONUT MESH PARTICIPANT STATUS" in result.output
    assert "Uptime Hours" in result.output


def test_cli_contribution_calculate_splits(monkeypatch) -> None:
    # Mock cached_load_ledger and resolve_urn to avoid relying on package default index.yaml
    mock_entry = LedgerEntry(
        urn="urn:coreason:solver:test_mcp",
        oci_uri="ghcr.io/test-mcp:v1",
        authorized_signer_did="did:key:author1",
        tenant_cid="urn:tenant:test",
        royalty_shares={"did:key:author1": 100},
    )

    def mock_load(path=None):
        return [mock_entry]

    def mock_resolve(urn, ledger):
        return mock_entry

    import coreason_ecosystem.utils.urn_authority_client as loader_module

    monkeypatch.setattr(loader_module, "cached_load_ledger", mock_load)
    monkeypatch.setattr(loader_module, "resolve_urn", mock_resolve)

    result = runner.invoke(
        app,
        [
            "contribution",
            "calculate-splits",
            "urn:coreason:solver:test_mcp",
            "--payout",
            "100",
            "--calls",
            "2",
        ],
    )
    assert result.exit_code == 0
    assert "Invocation calculations for urn:coreason:solver:test_mcp" in result.output
    assert "Anti-Abuse Decay Multiplier" in result.output
