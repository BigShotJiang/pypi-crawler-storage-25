# Copyright (c) 2026 CoReason, Inc.
# All rights reserved.

import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any, Literal

from coreason_manifest.spec.ontology import CoreasonBaseState
from pydantic import Field


# ────────────────────────────────────────────────────────────────────
# Exceptions
# ────────────────────────────────────────────────────────────────────


class TopologicalSeveranceEvent(Exception):
    """Raised when signature verification fails or a URN cannot be resolved."""

    pass


# ────────────────────────────────────────────────────────────────────
# Data Models
# ────────────────────────────────────────────────────────────────────


class MCPRegistryRef(CoreasonBaseState):
    namespace: str = Field(
        description="The reverse-DNS namespace (e.g. io.github.username/server).",
        max_length=256,
    )
    registry_url: str = Field(
        description="The URL of the MCP Registry.",
        default="https://registry.modelcontextprotocol.io",
        max_length=512,
    )
    verified: bool = Field(
        description="Whether this capability has been Cosign verified against the registry.",
        default=True,
    )


class LedgerEntry(CoreasonBaseState):
    urn: str = Field(
        description="The CoReason Uniform Resource Name for this capability.",
        max_length=256,
    )
    oci_uri: str = Field(
        description="The OCI artifact URI (e.g. ghcr.io/coreason-ai/solver:v1).",
        max_length=512,
    )
    authorized_signer_did: str = Field(
        description="The W3C DID of the authorized signer (e.g. did:key:z6Mk...).",
        max_length=256,
    )
    tenant_cid: str = Field(
        description="The tenant capability identifier for zero-trust multi-tenancy isolation.",
        default="urn:tenant:coreason:global:authority",
        max_length=256,
    )
    mcp_registry: MCPRegistryRef | None = Field(
        description="Optional cross-reference to the public MCP Registry.",
        default=None,
    )
    license_tier: Literal["prosperity-3.0", "commercial"] = Field(
        description="The licensing class under which this capability was registered.",
        default="prosperity-3.0",
    )
    dependencies: list[str] = Field(
        description="The list of capability dependency URNs that this tool relies on.",
        default_factory=list,
    )
    royalty_shares: dict[str, int] = Field(
        description="The mapping of authorized did:key signers to their percentage of execution royalties.",
        default_factory=dict,
    )
    payment_splitter_address: str | None = Field(
        description="The deployed Hyperledger Besu EVM contract address of the OpenZeppelin PaymentSplitter.",
        default=None,
        max_length=256,
    )


class VerifiedCapabilityReceipt(CoreasonBaseState):
    urn: str = Field(
        description="The resolved CoReason URN.",
        max_length=256,
    )
    oci_uri: str = Field(
        description="The cryptographically verified OCI artifact URI.",
        max_length=512,
    )
    authorized_signer_did: str = Field(
        description="The DID of the signer whose Cosign signature was verified.",
        max_length=256,
    )
    license_tier: Literal["prosperity-3.0", "commercial"] = Field(
        description="The licensing class of this capability.",
        default="prosperity-3.0",
    )


# ────────────────────────────────────────────────────────────────────
# Path Resolution
# ────────────────────────────────────────────────────────────────────

# The default path to index.yaml in the adjacent coreason-urn-authority repo
_DEFAULT_LEDGER_PATH = (
    Path(__file__).resolve().parents[4]
    / "coreason-urn-authority"
    / "src"
    / "coreason_urn_authority"
    / "ledger"
    / "index.yaml"
)


def get_rust_binary_path() -> str:
    # 1. Env Var override
    if "COREASON_URN_AUTHORITY_BINARY" in os.environ:
        return os.environ["COREASON_URN_AUTHORITY_BINARY"]

    # 2. Check sibling workspace relative target paths
    sibling_authority_dir = (
        Path(__file__).resolve().parents[4] / "coreason-urn-authority"
    )
    if sibling_authority_dir.exists():
        for folder in ("release", "debug"):
            for ext in (".exe", ""):
                p = sibling_authority_dir / "target" / folder / f"urn-authority{ext}"
                if p.exists():
                    return str(p.resolve())

    # 3. Fallback to system PATH
    return "urn-authority"


def run_rust_cli(args: list[str]) -> subprocess.CompletedProcess[str]:
    binary = get_rust_binary_path()
    try:
        env = os.environ.copy()
        if "PYTHON" not in env:
            env["PYTHON"] = sys.executable

        res = subprocess.run(
            [binary] + args,
            capture_output=True,
            text=True,
            check=False,
            env=env,
        )
        return res
    except FileNotFoundError as e:
        raise RuntimeError(
            f"Rust binary '{binary}' not found. Please compile the Rust crate using 'cargo build --release'."
        ) from e


# ────────────────────────────────────────────────────────────────────
# API Implementation
# ────────────────────────────────────────────────────────────────────


def load_ledger(ledger_path: Path | None = None) -> list[LedgerEntry]:
    path = ledger_path or _DEFAULT_LEDGER_PATH
    args = ["list", "--json"]
    if path:
        args.extend(["--ledger-path", str(path)])

    res = run_rust_cli(args)
    if res.returncode != 0:
        err_msg = res.stderr.strip() or res.stdout.strip()
        if err_msg.startswith("Error: "):
            err_msg = err_msg[len("Error: ") :]
        raise TopologicalSeveranceEvent(err_msg)

    try:
        data = json.loads(res.stdout)
        return [LedgerEntry.model_validate(cap) for cap in data]
    except Exception as e:
        raise TopologicalSeveranceEvent(
            f"Malformed ledger format parsing JSON from Rust: {e}"
        ) from e


def resolve_urn(urn: str, ledger: list[LedgerEntry]) -> LedgerEntry:
    for entry in ledger:
        if entry.urn == urn:
            return entry

    available = [e.urn for e in ledger]
    raise TopologicalSeveranceEvent(
        f"URN '{urn}' not found in OCI Ledger. Available URNs: {available}"
    )


class _LedgerCache:
    def __init__(self) -> None:
        self._entries: dict[str, list[LedgerEntry]] = {}
        self._mtimes: dict[str, float] = {}

    def get(self, path: Path | None = None) -> list[LedgerEntry]:
        resolved_path = path or _DEFAULT_LEDGER_PATH
        resolved = str(resolved_path.resolve())

        try:
            current_mtime = resolved_path.stat().st_mtime
        except OSError:
            return load_ledger(path)

        cached_mtime = self._mtimes.get(resolved)
        if cached_mtime is not None and cached_mtime == current_mtime:
            return self._entries[resolved]

        entries = load_ledger(path)
        self._entries[resolved] = entries
        self._mtimes[resolved] = current_mtime
        return entries

    def invalidate(self, path: Path | None = None) -> None:
        if path is None:
            self._entries.clear()
            self._mtimes.clear()
        else:
            resolved = str(path.resolve())
            self._entries.pop(resolved, None)
            self._mtimes.pop(resolved, None)


_ledger_cache = _LedgerCache()


def cached_load_ledger(ledger_path: Path | None = None) -> list[LedgerEntry]:
    return _ledger_cache.get(ledger_path)


def resolve_capability(
    urn: str,
    *,
    ledger_path: Path | None = None,
    runner: Any = None,
) -> VerifiedCapabilityReceipt:
    path = ledger_path or _DEFAULT_LEDGER_PATH
    args = ["resolve", urn, "--json"]
    if path:
        args.extend(["--ledger-path", str(path)])

    res = run_rust_cli(args)
    if res.returncode != 0:
        err_msg = res.stderr.strip() or res.stdout.strip()
        if err_msg.startswith("Error: "):
            err_msg = err_msg[len("Error: ") :]
        raise TopologicalSeveranceEvent(err_msg)

    try:
        data = json.loads(res.stdout)
        return VerifiedCapabilityReceipt.model_validate(data)
    except Exception as e:
        raise TopologicalSeveranceEvent(
            f"Malformed capability receipt JSON from Rust: {e}"
        ) from e


def append_to_ledger(
    ledger_path: Path,
    urn: str,
    oci_uri: str,
    did: str,
    tenant_cid: str = "urn:tenant:coreason:global:authority",
    mcp_namespace: str | None = None,
) -> None:
    args = [
        "promote",
        "--urn",
        urn,
        "--oci-uri",
        oci_uri,
        "--did",
        did,
        "--tenant-cid",
        tenant_cid,
        "--ledger-path",
        str(ledger_path),
        "--skip-git",
    ]
    if mcp_namespace:
        args.extend(["--mcp-namespace", mcp_namespace])

    res = run_rust_cli(args)
    if res.returncode != 0:
        err_msg = res.stderr.strip() or res.stdout.strip()
        if err_msg.startswith("Error: "):
            err_msg = err_msg[len("Error: ") :]
        raise TopologicalSeveranceEvent(err_msg)
