# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-ecosystem>

"""OPA Role-Check Middleware for FastAPI Gateway (#251).

Enforces access policies via Open Policy Agent (OPA) validation
at the network boundary, replacing client-side role-gating.
"""

from __future__ import annotations

import hashlib
import json
import os
import time
from typing import Any
import httpx


class OPAPolicyDecision:
    """Represents an OPA policy evaluation result."""

    __slots__ = ("allowed", "reason", "evaluated_rules")

    def __init__(
        self, allowed: bool, reason: str = "", evaluated_rules: list[str] | None = None
    ) -> None:
        self.allowed = allowed
        self.reason = reason
        self.evaluated_rules = evaluated_rules or []


class OPARoleCheckMiddleware:
    """FastAPI middleware that evaluates requests against OPA policies.

    Queries a running OPA sidecar (or embedded Rego evaluator) to determine
    if a request is authorized based on JWT claims, resource path, and action.
    """

    _MAX_CACHE_SIZE = 1024

    def __init__(
        self,
        opa_url: str | None = None,
        policy_path: str = "v1/data/coreason/authz/allow",
        default_deny: bool = True,
        cache_ttl_seconds: float | None = None,
    ) -> None:
        self.opa_url = opa_url or os.environ.get("OPA_URL", "http://localhost:8181")
        self.policy_path = policy_path
        self.default_deny = default_deny
        if cache_ttl_seconds is not None:
            self.cache_ttl_seconds = cache_ttl_seconds
        else:
            self.cache_ttl_seconds = float(
                os.environ.get("OPA_CACHE_TTL_SECONDS", "30")
            )
        self._cache: dict[str, tuple[float, OPAPolicyDecision]] = {}

    def evaluate(
        self,
        *,
        method: str,
        path: str,
        jwt_claims: dict[str, Any] | None = None,
        tenant_cid: str = "",
    ) -> OPAPolicyDecision:
        """Evaluate an access request against OPA policies.

        Args:
            method: HTTP method (GET, POST, etc.)
            path: Request path (/api/v1/...)
            jwt_claims: Decoded JWT claims from the request
            tenant_cid: The tenant identifier

        Returns:
            OPAPolicyDecision with the authorization result.
        """
        sanitized_claims = self._sanitize_claims(jwt_claims or {})
        input_doc = {
            "input": {
                "method": method.upper(),
                "path": path.strip("/").split("/"),
                "tenant_cid": tenant_cid,
                "claims": sanitized_claims,
                "roles": sanitized_claims.get("roles", []),
            }
        }

        query_url = f"{self.opa_url.rstrip('/')}/{self.policy_path}"

        # Sprint D: D3 — TTL cache for identical inputs
        if self.cache_ttl_seconds > 0:
            cache_key = hashlib.sha256(
                json.dumps(input_doc, sort_keys=True).encode()
            ).hexdigest()
            cached = self._cache.get(cache_key)
            if cached is not None:
                cached_time, cached_decision = cached
                if (time.monotonic() - cached_time) < self.cache_ttl_seconds:
                    return cached_decision
                # Expired — remove stale entry
                del self._cache[cache_key]
        else:
            cache_key = None

        try:
            with httpx.Client(timeout=2.0) as client:
                resp = client.post(
                    query_url,
                    json=input_doc,
                    headers={"Content-Type": "application/json"},
                )
                resp.raise_for_status()
                result = resp.json()
                allowed = result.get("result", False)
                decision = OPAPolicyDecision(
                    allowed=bool(allowed),
                    reason="OPA policy evaluation"
                    if allowed
                    else "Denied by OPA policy",
                    evaluated_rules=[self.policy_path],
                )
        except Exception as e:
            # Default-deny on OPA communication failure
            if self.default_deny:
                decision = OPAPolicyDecision(
                    allowed=False,
                    reason=f"OPA evaluation failed (default-deny): {e}",
                )
            else:
                decision = OPAPolicyDecision(
                    allowed=True,
                    reason=f"OPA evaluation failed (default-allow): {e}",
                )

        # Store in cache if enabled
        if cache_key is not None:
            # Evict oldest entries if cache is full
            if len(self._cache) >= self._MAX_CACHE_SIZE:
                oldest_key = next(iter(self._cache))
                del self._cache[oldest_key]
            self._cache[cache_key] = (time.monotonic(), decision)

        return decision

    async def async_evaluate(
        self,
        *,
        method: str,
        path: str,
        jwt_claims: dict[str, Any] | None = None,
        tenant_cid: str = "",
    ) -> OPAPolicyDecision:
        """Evaluate an access request asynchronously against OPA policies.

        Args:
            method: HTTP method (GET, POST, etc.)
            path: Request path (/api/v1/...)
            jwt_claims: Decoded JWT claims from the request
            tenant_cid: The tenant identifier

        Returns:
            OPAPolicyDecision with the authorization result.
        """
        sanitized_claims = self._sanitize_claims(jwt_claims or {})
        input_doc = {
            "input": {
                "method": method.upper(),
                "path": path.strip("/").split("/"),
                "tenant_cid": tenant_cid,
                "claims": sanitized_claims,
                "roles": sanitized_claims.get("roles", []),
            }
        }

        query_url = f"{self.opa_url.rstrip('/')}/{self.policy_path}"

        if self.cache_ttl_seconds > 0:
            cache_key = hashlib.sha256(
                json.dumps(input_doc, sort_keys=True).encode()
            ).hexdigest()
            cached = self._cache.get(cache_key)
            if cached is not None:
                cached_time, cached_decision = cached
                if (time.monotonic() - cached_time) < self.cache_ttl_seconds:
                    return cached_decision
                del self._cache[cache_key]
        else:
            cache_key = None

        try:
            async with httpx.AsyncClient(timeout=2.0) as client:
                resp = await client.post(
                    query_url,
                    json=input_doc,
                    headers={"Content-Type": "application/json"},
                )
                resp.raise_for_status()
                result = resp.json()
                allowed = result.get("result", False)
                decision = OPAPolicyDecision(
                    allowed=bool(allowed),
                    reason="OPA policy evaluation"
                    if allowed
                    else "Denied by OPA policy",
                    evaluated_rules=[self.policy_path],
                )
        except Exception as e:
            if self.default_deny:
                decision = OPAPolicyDecision(
                    allowed=False,
                    reason=f"OPA evaluation failed (default-deny): {e}",
                )
            else:
                decision = OPAPolicyDecision(
                    allowed=True,
                    reason=f"OPA evaluation failed (default-allow): {e}",
                )

        if cache_key is not None:
            if len(self._cache) >= self._MAX_CACHE_SIZE:
                oldest_key = next(iter(self._cache))
                del self._cache[oldest_key]
            self._cache[cache_key] = (time.monotonic(), decision)

        return decision

    def clear_cache(self) -> None:
        """Clear the policy decision cache.

        Call this when OPA policies are reloaded or updated.
        """
        self._cache.clear()

    @staticmethod
    def _sanitize_claims(
        claims: dict[str, Any], *, max_depth: int = 3, _depth: int = 0
    ) -> dict[str, Any]:
        """Sanitize JWT claims by limiting nesting depth.

        Prevents oversized or adversarial JWT payloads from consuming
        excessive memory in the OPA input document.

        Args:
            claims: The raw JWT claims dict.
            max_depth: Maximum nesting depth (default 3).

        Returns:
            A sanitized copy of the claims dict.
        """
        if _depth >= max_depth:
            return {}
        result: dict[str, Any] = {}
        for key, value in claims.items():
            if isinstance(value, dict):
                result[key] = OPARoleCheckMiddleware._sanitize_claims(
                    value, max_depth=max_depth, _depth=_depth + 1
                )
            elif isinstance(value, list):
                # Keep lists but truncate nested dicts within them
                result[key] = [
                    OPARoleCheckMiddleware._sanitize_claims(
                        item, max_depth=max_depth, _depth=_depth + 1
                    )
                    if isinstance(item, dict)
                    else item
                    for item in value
                ]
            else:
                result[key] = value
        return result

    def create_rego_policy(self) -> str:
        """Generate the baseline Rego policy for CoReason authorization.

        Returns:
            A string containing the Rego policy document.
        """
        return """package coreason.authz

import future.keywords.if
import future.keywords.in

default allow := false

# Allow health checks
allow if {
    input.path[0] == "health"
}

# Allow authenticated users with valid roles
allow if {
    count(input.claims) > 0
    "operator" in input.roles
}

# Allow tenant-scoped access
allow if {
    count(input.claims) > 0
    input.tenant_cid != ""
    input.claims.tenant_cid == input.tenant_cid
}

# Deny cross-tenant access
deny if {
    input.claims.tenant_cid != input.tenant_cid
    input.tenant_cid != ""
}
"""
