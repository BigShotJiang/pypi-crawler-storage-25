# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-ecosystem>

"""x5c Intermediate Certificate Chain Verification (#246).

Validates JWT tokens signed with intermediate certificates by
extracting the x5c header claim and verifying the certificate chain
back to the trusted root CA.
"""

from __future__ import annotations

import base64

from coreason_manifest.spec.ontology import CoreasonBaseState
from pydantic import Field


class CertificateChainReceipt(CoreasonBaseState):
    """Frozen receipt proving x5c certificate chain verification."""

    issuer_cn: str = Field(description="Common Name of the issuing certificate")
    subject_cn: str = Field(description="Common Name of the signing certificate")
    chain_depth: int = Field(description="Number of certificates in the chain")
    root_ca_fingerprint: str = Field(description="SHA-256 fingerprint of the root CA")


def verify_x5c_chain(
    x5c_chain: list[str],
    trusted_root_pems: list[str] | None = None,
) -> CertificateChainReceipt:
    """Verify an x5c certificate chain from a JWT header.

    The x5c claim contains a chain of DER-encoded X.509 certificates
    (base64-encoded, without PEM headers). The first certificate is
    the signing certificate; the last is closest to the root.

    Args:
        x5c_chain: List of base64-encoded DER certificates from JWT x5c header.
        trusted_root_pems: Optional list of PEM-encoded trusted root CA certs.

    Returns:
        CertificateChainReceipt on successful verification.

    Raises:
        ValueError: If the chain is empty, malformed, or untrusted.
    """
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes

    if not x5c_chain:
        raise ValueError("Empty x5c certificate chain")

    # Parse all certificates in the chain
    certs = []
    for i, cert_b64 in enumerate(x5c_chain):
        try:
            cert_der = base64.b64decode(cert_b64)
            cert = x509.load_der_x509_certificate(cert_der)
            certs.append(cert)
        except Exception as e:
            raise ValueError(f"Failed to parse certificate at index {i}: {e}") from e

    import datetime

    now = datetime.datetime.now(datetime.timezone.utc)

    # 1. Verify date validity on all certificates in the chain
    for i, cert in enumerate(certs):
        if now < cert.not_valid_before_utc or now > cert.not_valid_after_utc:
            raise ValueError(f"Certificate at depth {i} is expired or not yet valid")

    # 2. Verify signature and CA constraints on parent certificates
    for i in range(len(certs) - 1):
        child = certs[i]
        parent = certs[i + 1]

        # Verify signature
        try:
            parent.public_key().verify(  # type: ignore[union-attr,call-arg]
                child.signature,
                child.tbs_certificate_bytes,
                child.signature_algorithm_parameters,  # type: ignore[arg-type]
            )
        except Exception as e:
            raise ValueError(
                f"Certificate chain verification failed at depth {i}: {e}"
            ) from e

        # Verify parent is a CA
        try:
            basic_constraints = parent.extensions.get_extension_for_class(
                x509.BasicConstraints
            ).value
            if not basic_constraints.ca:
                raise ValueError(f"Parent certificate at depth {i + 1} is not a CA")
        except x509.ExtensionNotFound:
            raise ValueError(
                f"Parent certificate at depth {i + 1} is missing BasicConstraints extension"
            )

        # Verify parent KeyUsage if extension is present
        try:
            key_usage = parent.extensions.get_extension_for_class(x509.KeyUsage).value
            if not key_usage.key_cert_sign:
                raise ValueError(
                    f"Parent certificate at depth {i + 1} does not have keyCertSign usage enabled"
                )
        except x509.ExtensionNotFound:
            pass

    # Verify against trusted root if provided
    if trusted_root_pems:
        root_cert = certs[-1]
        root_trusted = False
        for root_pem in trusted_root_pems:
            trusted = x509.load_pem_x509_certificate(root_pem.encode())
            if trusted.fingerprint(hashes.SHA256()) == root_cert.fingerprint(
                hashes.SHA256()
            ):
                root_trusted = True
                break
        if not root_trusted:
            raise ValueError("Root certificate is not in the trusted CA store")

    signing_cert = certs[0]
    root_cert = certs[-1]

    def _extract_cn(cert: x509.Certificate) -> str:
        for attr in cert.subject:
            if attr.oid == x509.oid.NameOID.COMMON_NAME:
                return str(attr.value)
        return "unknown"

    return CertificateChainReceipt(
        issuer_cn=_extract_cn(root_cert),
        subject_cn=_extract_cn(signing_cert),
        chain_depth=len(certs),
        root_ca_fingerprint=root_cert.fingerprint(hashes.SHA256()).hex(),
    )


def extract_x5c_from_jwt(jwt_token: str) -> list[str]:
    """Extract x5c chain from a JWT header.

    Args:
        jwt_token: Raw JWT string.

    Returns:
        List of base64-encoded DER certificates.
    """
    import json

    parts = jwt_token.split(".")
    if len(parts) < 2:
        raise ValueError("Invalid JWT format")

    header_b64 = parts[0] + "=" * (4 - len(parts[0]) % 4)
    header = json.loads(base64.urlsafe_b64decode(header_b64))

    x5c = header.get("x5c", [])
    if not isinstance(x5c, list) or not all(isinstance(x, str) for x in x5c):
        raise ValueError("JWT header does not contain a valid x5c claim")

    return x5c
