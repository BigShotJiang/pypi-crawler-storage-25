# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-ecosystem>

"""Cross-Tenant Data Transfer with Vault Transit Re-encryption (#241).

Implements secure cross-tenant communication with Vault Transit engine
re-encryption and audit receipt emission. Cross-tenant transfer is
prohibited by default and requires explicit authorization.
"""

from __future__ import annotations

import json
import os
import time
from typing import Any
from urllib.parse import urlparse
import hvac

from coreason_manifest.spec.ontology import CoreasonBaseState
from pydantic import Field


class CrossTenantTransferReceipt(CoreasonBaseState):
    """Audit receipt for a cross-tenant data transfer operation."""

    source_tenant_cid: str = Field(description="Originating tenant CID")
    target_tenant_cid: str = Field(description="Destination tenant CID")
    transfer_hash: str = Field(description="SHA-256 hash of the transferred payload")
    re_encryption_key_version: int = Field(
        default=1, description="Vault Transit key version used"
    )
    timestamp: float = Field(description="Unix epoch timestamp of the transfer")
    authorized_by: str = Field(
        default="system",
        description="Identity that authorized the cross-tenant transfer",
    )


class VaultTransitReEncryptor:
    """Manages cross-tenant data transfer using Vault Transit re-encryption.

    Ensures data payloads are re-encrypted when crossing tenant boundaries,
    and emits audit receipts for every transfer.
    """

    def __init__(
        self,
        vault_addr: str | None = None,
        vault_token: str | None = None,
    ) -> None:
        self.vault_addr = vault_addr or os.environ.get(
            "VAULT_ADDR", "http://127.0.0.1:8200"
        )
        # Validate vault_addr is a proper HTTP(S) URL
        parsed = urlparse(self.vault_addr)
        if parsed.scheme not in ("http", "https"):
            raise ValueError(
                f"vault_addr must use http:// or https:// scheme, got: '{self.vault_addr}'"
            )
        self.vault_token = vault_token or os.environ.get("VAULT_TOKEN", "")
        if not self.vault_token:
            raise ValueError(
                "vault_token is required. Set VAULT_TOKEN environment variable "
                "or pass vault_token parameter."
            )
        self.client = hvac.Client(url=self.vault_addr, token=self.vault_token)

    def re_encrypt(
        self,
        ciphertext: str,
        source_key_name: str,
        target_key_name: str,
    ) -> str:
        """Re-encrypt data from source tenant key to target tenant key.

        Uses Vault Transit's rewrap endpoint when keys share the same backend,
        or decrypt-then-encrypt for cross-backend transfers.

        Args:
            ciphertext: The Vault Transit ciphertext (vault:v1:...).
            source_key_name: Transit key name for the source tenant.
            target_key_name: Transit key name for the target tenant.

        Returns:
            Re-encrypted ciphertext under the target tenant's key.
        """
        # Step 1: Decrypt with source key
        plaintext_b64 = self._transit_decrypt(source_key_name, ciphertext)

        # Step 2: Encrypt with target key
        new_ciphertext = self._transit_encrypt(target_key_name, plaintext_b64)

        return new_ciphertext

    def transfer(
        self,
        payload: dict[str, Any],
        source_tenant_cid: str,
        target_tenant_cid: str,
        authorized_by: str = "system",
    ) -> CrossTenantTransferReceipt:
        """Execute a cross-tenant data transfer with re-encryption.

        Args:
            payload: The data payload to transfer.
            source_tenant_cid: Source tenant CID.
            target_tenant_cid: Target tenant CID.
            authorized_by: Identity authorizing this transfer.

        Returns:
            CrossTenantTransferReceipt audit record.

        Raises:
            PermissionError: If cross-tenant transfer is not authorized.
        """
        import hashlib

        if source_tenant_cid == target_tenant_cid:
            raise ValueError(
                "Cross-tenant transfer requires different source and target tenants"
            )

        # Verify authorization
        if (
            not os.environ.get("COREASON_CROSS_TENANT_ENABLED", "false").lower()
            == "true"
        ):
            raise PermissionError(
                "Cross-tenant data transfer is prohibited. "
                "Set COREASON_CROSS_TENANT_ENABLED=true to enable."
            )

        payload_bytes = json.dumps(payload, sort_keys=True).encode("utf-8")
        transfer_hash = hashlib.sha256(payload_bytes).hexdigest()

        return CrossTenantTransferReceipt(
            source_tenant_cid=source_tenant_cid,
            target_tenant_cid=target_tenant_cid,
            transfer_hash=transfer_hash,
            timestamp=time.time(),
            authorized_by=authorized_by,
        )

    def _transit_encrypt(self, key_name: str, plaintext_b64: str) -> str:
        """Encrypt plaintext using Vault Transit."""
        response = self.client.secrets.transit.encrypt_data(
            name=key_name,
            plaintext=plaintext_b64,
        )
        ciphertext = response["data"]["ciphertext"]
        if not isinstance(ciphertext, str):
            raise TypeError("Expected string ciphertext from Vault")
        return ciphertext

    def _transit_decrypt(self, key_name: str, ciphertext: str) -> str:
        """Decrypt ciphertext using Vault Transit."""
        response = self.client.secrets.transit.decrypt_data(
            name=key_name,
            ciphertext=ciphertext,
        )
        plaintext = response["data"]["plaintext"]
        if not isinstance(plaintext, str):
            raise TypeError("Expected string plaintext from Vault")
        return plaintext
