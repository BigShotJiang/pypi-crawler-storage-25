wit_bindgen::generate!({
    world: "openshell-translator",
    path: "wit",
});

use serde::{Deserialize, Serialize};
use serde_json::Value;

use exports::wasmcloud::messaging::handler::Guest;
use wasmcloud::messaging::types::BrokerMessage;
use wasmcloud::messaging::consumer::publish;

use wasi::http::outgoing_handler::handle;
use wasi::http::types::{
    Fields, OutgoingRequest, Method, Scheme
};

// JSON-RPC 2.0 structures
#[derive(Deserialize, Debug)]
struct JsonRpcRequest {
    jsonrpc: String,
    method: String,
    params: Params,
    id: Value,
}

#[derive(Deserialize, Debug)]
struct Params {
    name: String,
    arguments: Arguments,
    #[serde(default)]
    security_context: Option<InboundSecurityContext>,
}

#[derive(Deserialize, Debug)]
struct Arguments {
    script: String,
}

#[derive(Deserialize, Debug)]
struct InboundSecurityContext {
    #[serde(default)]
    authorized: bool,
    spiffe_id: Option<String>,
    verified_capability_receipt: Option<Value>,
}

#[derive(Serialize, Debug)]
struct SecurityContext {
    authorized: bool,
    spiffe_id: String,
    verified_capability_receipt: Value,
}

#[derive(Serialize, Debug)]
struct OpenShellRequest {
    security_context: SecurityContext,
    script_payload: String,
}

#[derive(Serialize, Debug)]
struct JsonRpcResponse {
    jsonrpc: String,
    result: Value,
    id: Value,
}

#[derive(Serialize, Debug)]
struct JsonRpcErrorResponse {
    jsonrpc: String,
    error: JsonRpcError,
    id: Value,
}

#[derive(Serialize, Debug)]
struct JsonRpcError {
    code: i32,
    message: String,
}

struct OpenShellTranslator;

impl Guest for OpenShellTranslator {
    fn handle_message(msg: BrokerMessage) -> Result<(), String> {
        // If there's no reply-to, we don't need to do anything since it's fire-and-forget
        let reply_to = match msg.reply_to {
            Some(ref r) if !r.is_empty() => r.clone(),
            _ => return Ok(()),
        };

        // Decode incoming payload
        let req_str = match String::from_utf8(msg.body) {
            Ok(s) => s,
            Err(e) => return send_error(&reply_to, Value::Null, -32700, format!("Invalid UTF-8: {}", e)),
        };

        let request: JsonRpcRequest = match serde_json::from_str(&req_str) {
            Ok(req) => req,
            Err(e) => return send_error(&reply_to, Value::Null, -32600, format!("Invalid JSON-RPC: {}", e)),
        };

        // ── Security Context Extraction & Validation ──────────
        let sec = match request.params.security_context {
            Some(ref s) => s,
            None => {
                return send_error(
                    &reply_to,
                    request.id,
                    -32001,
                    "Security Exception: Inbound script execution is unauthorized.".to_string(),
                );
            }
        };

        if !sec.authorized {
            return send_error(
                &reply_to,
                request.id,
                -32001,
                "Security Exception: Inbound script execution is unauthorized.".to_string(),
            );
        }

        let spiffe_id = match sec.spiffe_id {
            Some(ref sid) if sid.starts_with("spiffe://coreason.ai/") => sid.clone(),
            _ => {
                return send_error(
                    &reply_to,
                    request.id,
                    -32002,
                    "Security Exception: Invalid or missing SPIFFE identity context.".to_string(),
                );
            }
        };

        let receipt = match sec.verified_capability_receipt {
            Some(ref r) => r.clone(),
            None => {
                return send_error(
                    &reply_to,
                    request.id,
                    -32003,
                    "Security Exception: Missing required VerifiedCapabilityReceipt.".to_string(),
                );
            }
        };

        // Perform translation to OpenShell structure
        let openshell_payload = OpenShellRequest {
            security_context: SecurityContext {
                authorized: true,
                spiffe_id,
                verified_capability_receipt: receipt,
            },
            script_payload: request.params.arguments.script,
        };

        let openshell_req_body = match serde_json::to_vec(&openshell_payload) {
            Ok(b) => b,
            Err(e) => return send_error(&reply_to, request.id, -32603, format!("Serialization error: {}", e)),
        };

        // Dispatch HTTP request to OpenShell Manager via wasi:http
        let response_body = match call_openshell(&openshell_req_body) {
            Ok(body) => body,
            Err(e) => return send_error(&reply_to, request.id, -32603, format!("OpenShell execution failed: {}", e)),
        };

        // Decode the OpenShell response
        let openshell_res_val: Value = match serde_json::from_slice(&response_body) {
            Ok(v) => v,
            Err(e) => return send_error(&reply_to, request.id, -32603, format!("Invalid response from OpenShell: {}", e)),
        };

        // Construct standard JSON-RPC response
        let rpc_res = JsonRpcResponse {
            jsonrpc: "2.0".to_string(),
            result: openshell_res_val,
            id: request.id,
        };

        let reply_body = match serde_json::to_vec(&rpc_res) {
            Ok(b) => b,
            Err(e) => return send_error(&reply_to, Value::Null, -32603, format!("Response serialization error: {}", e)),
        };

        // Publish reply back to NATS
        let reply_msg = BrokerMessage {
            subject: reply_to,
            body: reply_body,
            reply_to: None,
        };

        publish(&reply_msg)
    }
}

fn send_error(reply_to: &str, id: Value, code: i32, message: String) -> Result<(), String> {
    let err_res = JsonRpcErrorResponse {
        jsonrpc: "2.0".to_string(),
        error: JsonRpcError { code, message },
        id,
    };
    if let Ok(body) = serde_json::to_vec(&err_res) {
        let _ = publish(&BrokerMessage {
            subject: reply_to.to_string(),
            body,
            reply_to: None,
        });
    }
    Ok(())
}

fn call_openshell(body: &[u8]) -> Result<Vec<u8>, String> {
    use wasi::http::types::OutgoingBody;

    let headers = Fields::new();
    headers.set(&"content-type".to_string(), &[b"application/json".to_vec()])
        .map_err(|_| "Failed to set headers".to_string())?;

    let req = OutgoingRequest::new(headers);
    req.set_method(&Method::Post)
        .map_err(|_| "Failed to set method".to_string())?;
    req.set_path_with_query(Some("/v1/mcp/execute"))
        .map_err(|_| "Failed to set path".to_string())?;
    req.set_scheme(Some(&Scheme::Http))
        .map_err(|_| "Failed to set scheme".to_string())?;
    req.set_authority(Some("openshell-manager:8080"))
        .map_err(|_| "Failed to set authority".to_string())?;

    let req_body = req.body()
        .map_err(|_| "Failed to get request body".to_string())?;

    let out_stream = req_body.write()
        .map_err(|_| "Failed to get request output stream".to_string())?;

    out_stream.blocking_write_and_flush(body)
        .map_err(|_| "Failed to write body".to_string())?;

    // Drop stream to finish request body writing
    drop(out_stream);

    OutgoingBody::finish(req_body, None)
        .map_err(|_| "Failed to finish request body".to_string())?;

    let future_res = handle(req, None)
        .map_err(|e| format!("Request handle error: {:?}", e))?;

    // Wait for the response to resolve.
    let response = loop {
        if let Some(res) = future_res.get() {
            break res;
        }
    };

    let incoming_res = response
        .map_err(|_| "Failed to receive response".to_string())?
        .map_err(|e| format!("Response error: {:?}", e))?;

    if incoming_res.status() != 200 {
        return Err(format!("OpenShell returned non-200 status: {}", incoming_res.status()));
    }

    let res_body = incoming_res.consume()
        .map_err(|_| "Failed to get response body".to_string())?;

    let in_stream = res_body.stream()
        .map_err(|_| "Failed to get response input stream".to_string())?;

    let mut response_data = Vec::new();
    loop {
        match in_stream.read(65536) {
            Ok(chunk) => {
                if chunk.is_empty() {
                    break;
                }
                response_data.extend(chunk);
            }
            Err(_) => break,
        }
    }

    Ok(response_data)
}


export!(OpenShellTranslator);

