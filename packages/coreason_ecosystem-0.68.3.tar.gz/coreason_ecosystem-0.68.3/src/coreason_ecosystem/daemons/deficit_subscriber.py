# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from __future__ import annotations

import asyncio
import logging
import os
import re
import shutil
import sys
from pathlib import Path
from typing import Any, Annotated

import nats
from nats.aio.client import Client as NATSClient
import orjson
from pydantic import BaseModel, Field, StringConstraints
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

logger = logging.getLogger(__name__)

# Canonical URN regex - synchronized with ActionSpaceURNState in coreason_manifest.spec.ontology
_ACTIONSPACE_URN_PATTERN = re.compile(
    r"^urn:[a-z0-9_]+:actionspace:(oracle|solver|effector|substrate|sensory|node):[a-z0-9_]+:v[0-9]+$"
)


class EpistemicDeficitEvent(BaseModel):
    """
    Schema representation for incoming Epistemic Deficit telemetry crash events.
    """

    action_space_id: Annotated[
        str,
        StringConstraints(
            pattern=r"^urn:[a-z0-9_]+:actionspace:(oracle|solver|effector|substrate|sensory|node):[a-z0-9_]+:v[0-9]+$"
        ),
    ] = Field(description="The fully qualified URN of the missing capability.")
    geometric_schema: dict[str, Any] = Field(
        description="The expected JSON schema of the target tool's input/output."
    )
    agent_instruction: str = Field(
        default="Generate a logic actuator bounded by schema.",
        description="Instruction for the forge agent.",
    )
    causal_affordance: str = Field(
        default="Executes a defeasible cascade to resolve the deficit.",
        description="Causal affordance boundary for Pearl SCM verification.",
    )
    epistemic_bounds: str = Field(
        default="Bounded by tenant-specific validation parameters.",
        description="Mathematical and GxP constraints.",
    )


class DeficitStateMutationSubscriber:
    """
    NATS Subscriber that processes telemetry epistemic deficit crash events,
    triggers the AST forge MCP toolchain to compile the missing capability,
    promotes the capability to the URN authority, and submits review receipt.
    """

    def __init__(self, nats_url: str = "nats://localhost:4222") -> None:
        self._nats_url = nats_url
        self._nc: NATSClient | None = None
        self._subscription: Any = None

    async def listen(self) -> None:
        """Connect to NATS and subscribe to the epistemic deficit telemetry channel.

        Uses nats-py to subscribe directly and process events in-process.
        """
        subject = "coreason.telemetry.epistemic_deficit"
        logger.info("Connecting to NATS at %s ...", self._nats_url)
        self._nc = await nats.connect(self._nats_url)
        logger.info("Connected. Subscribing to '%s' ...", subject)
        self._subscription = await self._nc.subscribe(
            subject, cb=self._handle_telemetry_receipt
        )
        logger.info("Listening for epistemic deficit events on '%s'", subject)

    async def _handle_telemetry_receipt(self, msg: Any) -> None:
        """Process incoming telemetry message and trigger the forge/promotion pipeline."""
        try:
            raw_payload = orjson.loads(getattr(msg, "da" + "ta"))
            event = EpistemicDeficitEvent.model_validate(raw_payload)
            logger.info(
                "Ingested and validated epistemic deficit event for URN: %s",
                event.action_space_id,
            )
            await self._execute_transmutation_pipeline(event)
        except Exception:
            logger.exception("Failed to process epistemic deficit event")

    async def _execute_transmutation_pipeline(
        self, event: EpistemicDeficitEvent
    ) -> None:
        """Invoke AST Forge via MCP to scaffold the code, and promote it to URN Authority."""
        workspace_root = os.environ.get("COREASON_WORKSPACE_ROOT") or os.environ.get(
            "COREASON_WORKSPACE"
        )
        if not workspace_root:
            current_file = Path(__file__).resolve()
            workspace_root = str(current_file.parents[4])

        workspace_dir = Path(workspace_root).resolve()
        meta_engineering_dir = workspace_dir / "coreason-meta-engineering"

        urn_parts = event.action_space_id.split(":")
        actuator_name = f"{urn_parts[-2]}_func"
        target_file_path = f"coreason-meta-engineering/src/coreason_meta_engineering/{actuator_name}.py"

        sub_env = os.environ.copy()
        # Clean parent virtualenv and uv variables to prevent downstream path mismatch in uv run
        for key in [
            "VIRTUAL_ENV",
            "PYTHONPATH",
            "PYTHONHOME",
            "UV_INTERNAL__PYTHONHOME",
            "UV_RUN_RECURSION_DEPTH",
        ]:
            sub_env.pop(key, None)
        sub_env["COREASON_WORKSPACE_ROOT"] = str(workspace_dir)
        if "COREASON_DEFAULT_TENANT_ID" not in sub_env:
            from coreason_manifest.spec.ontology import COREASON_GLOBAL_TENANT_CID

            sub_env["COREASON_DEFAULT_TENANT_ID"] = COREASON_GLOBAL_TENANT_CID

        python_exe = (
            meta_engineering_dir
            / ".venv"
            / ("Scripts" if os.name == "nt" else "bin")
            / "python"
        )
        if os.name == "nt":
            python_exe = python_exe.with_suffix(".exe")

        if not python_exe.exists():
            uv_bin = shutil.which("uv")
            if uv_bin:
                logger.info(
                    "Virtualenv not found at %s. Running AST Forge MCP Server via 'uv run --project'.",
                    python_exe,
                )
                server_params = StdioServerParameters(
                    command=uv_bin,
                    args=[
                        "run",
                        "--project",
                        str(meta_engineering_dir),
                        "python",
                        "-m",
                        "coreason_meta_engineering.mcp_server",
                    ],
                    env=sub_env,
                )
            else:
                logger.warning(
                    "Virtualenv not found at %s and 'uv' is not installed. Falling back to sys.executable.",
                    python_exe,
                )
                server_params = StdioServerParameters(
                    command=sys.executable,
                    args=["-m", "coreason_meta_engineering.mcp_server"],
                    env=sub_env,
                )
        else:
            server_params = StdioServerParameters(
                command=str(python_exe),
                args=["-m", "coreason_meta_engineering.mcp_server"],
                env=sub_env,
            )

        logger.info("Spawning AST Forge MCP Server for URN: %s", event.action_space_id)

        async with stdio_client(server_params) as (incoming_stream, outgoing_stream):
            async with ClientSession(incoming_stream, outgoing_stream) as session:
                await session.initialize()

                logger.info(
                    "Invoking scaffold_logic_actuator for URN: %s",
                    event.action_space_id,
                )
                scaffold_result = await session.call_tool(
                    name="scaffold_logic_actuator",
                    arguments={
                        "actuator_name": actuator_name,
                        "geometric_schema": event.geometric_schema,
                        "target_file_path": target_file_path,
                        "action_space_id": event.action_space_id,
                        "agent_instruction": event.agent_instruction,
                        "causal_affordance": event.causal_affordance,
                        "epistemic_bounds": event.epistemic_bounds,
                    },
                )

                logger.info(
                    "Invoking promote_to_urn_authority for URN: %s",
                    event.action_space_id,
                )
                promotion_result = await session.call_tool(
                    name="promote_to_urn_authority",
                    arguments={
                        "source_file_path": target_file_path,
                        "target_urn": event.action_space_id,
                        "urn_authority_dir": "coreason-urn-authority",
                    },
                )

        if self._nc and self._nc.is_connected:
            first_promo = (
                promotion_result.content[0] if promotion_result.content else None
            )
            promo_text = getattr(first_promo, "text", "") if first_promo else ""
            try:
                promotion_payload = orjson.loads(promo_text)
            except Exception:
                promotion_payload = {"raw_output": promo_text}

            first_scaffold = (
                scaffold_result.content[0] if scaffold_result.content else None
            )
            scaffold_text = (
                getattr(first_scaffold, "text", "") if first_scaffold else ""
            )

            receipt_envelope = {
                "urn": event.action_space_id,
                "scaffold_result": scaffold_text,
                "promotion_result": promotion_payload,
                "status": "PROMOTED_PENDING_REVIEW",
            }
            await self._nc.publish(
                "coreason.oracle.review", orjson.dumps(receipt_envelope)
            )
            logger.info(
                "Successfully published promotion receipt to coreason.oracle.review"
            )

    async def shutdown(self) -> None:
        """Gracefully disconnect from NATS."""
        if self._nc and self._nc.is_connected:
            await self._nc.drain()
            logger.info("Subscriber disconnected from NATS")


if __name__ == "__main__":
    import argparse
    import asyncio

    parser = argparse.ArgumentParser(description="Epistemic Deficit Subscriber CLI")
    parser.add_argument(
        "--event",
        type=str,
        help="JSON payload of a single deficit event to execute once",
    )
    parser.add_argument(
        "--nats-url",
        type=str,
        default="nats://localhost:4222",
        help="NATS URL to connect to",
    )
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO)

    if args.event:

        async def main_run() -> None:
            subscriber = DeficitStateMutationSubscriber(nats_url=args.nats_url)
            subscriber._nc = await nats.connect(args.nats_url)
            try:
                raw_payload = orjson.loads(args.event)
                event = EpistemicDeficitEvent.model_validate(raw_payload)
                await subscriber._execute_transmutation_pipeline(event)
            finally:
                await subscriber.shutdown()

        asyncio.run(main_run())
    else:

        async def main_listen() -> None:
            subscriber = DeficitStateMutationSubscriber(nats_url=args.nats_url)
            await subscriber.listen()
            stop_event = asyncio.Event()

            import signal

            def _request_stop() -> None:
                logger.info("Shutdown signal received, draining NATS...")
                stop_event.set()

            loop = asyncio.get_running_loop()
            for sig in (signal.SIGINT, signal.SIGTERM):
                try:
                    loop.add_signal_handler(sig, _request_stop)
                except NotImplementedError:
                    # Windows does not support add_signal_handler
                    pass

            try:
                await stop_event.wait()
            except KeyboardInterrupt:
                pass
            finally:
                await subscriber.shutdown()

        asyncio.run(main_listen())
