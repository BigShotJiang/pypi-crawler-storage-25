# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: https://github.com/CoReason-AI/coreason-ecosystem

import asyncio
import importlib.metadata
import sys
from typing import Any

import typer
from rich.console import Console

console = Console()


def global_excepthook(
    exc_type: type[BaseException],
    exc_value: BaseException,
    exc_traceback: Any,
) -> None:  # pragma: no cover
    from coreason_ecosystem.utils.logger import logger

    # 1. Log the critical error to the mesh (JSON + OTLP)
    logger.opt(exception=(exc_type, exc_value, exc_traceback)).critical(
        f"Fatal Execution Error: {exc_value}"
    )

    # 2. Print to the operator's terminal
    console.print(f"[bold red]✗ Fatal Execution Error:[/bold red] {exc_value}")
    sys.exit(1)


sys.excepthook = global_excepthook  # pragma: no cover


def version_callback(value: bool) -> None:
    if value:
        try:
            version = importlib.metadata.version("coreason-ecosystem")
        except importlib.metadata.PackageNotFoundError:
            version = "unknown (local development)"
        console.print(f"[bold cyan]CoReason Ecosystem[/bold cyan] v{version}")
        raise typer.Exit()


# We need to initialize the app first
app = typer.Typer(help="CoReason Meta-Orchestrator Control Plane")


@app.callback()
def cli_callback(
    version: bool | None = typer.Option(
        None,
        "--version",
        "-V",
        help="Show the active hypervisor version.",
        callback=version_callback,
        is_eager=True,
    ),
) -> None:
    """The Autopoietic Hypervisor for the Tripartite Cybernetic Manifold."""
    pass


# We must import the commands after 'console' and 'app' are defined,
# but to avoid circular dependencies where submodules import 'console'
# from cli.py, 'console' is defined above first.
from pathlib import Path  # noqa: E402
from coreason_ecosystem.orchestration.isomorphism_probe import execute_oracle_diagnostic  # noqa: E402
from coreason_ecosystem.orchestration.sync import execute_sync  # noqa: E402
from coreason_ecosystem.orchestration.up import execute_up  # noqa: E402
from coreason_ecosystem.orchestration.init import execute_init  # noqa: E402
from coreason_ecosystem.fleet.daemon import AutonomicFleetManager  # noqa: E402

fleet_app = typer.Typer()
app.add_typer(
    fleet_app, name="fleet", help="Manage the autonomic Cognitive Entity compute fleet."
)


@fleet_app.command("start")
def fleet_start(
    max_budget_hr: float = typer.Option(5.0, help="Max budget per hour"),
    polling_interval: int = typer.Option(10, help="Polling interval in seconds"),
) -> None:  # pragma: no cover
    templates_path = Path.cwd() / "infrastructure" / "ephemeral"
    manager = AutonomicFleetManager(
        max_budget_hr=max_budget_hr,
        polling_interval_sec=polling_interval,
        templates_path=templates_path.resolve(),
    )
    asyncio.run(manager.start())


deficit_app = typer.Typer()
app.add_typer(
    deficit_app,
    name="deficit-subscriber",
    help="Manage the epistemic deficit resolution subscriber daemon.",
)


@deficit_app.command("start")
def deficit_subscriber_start(
    nats_url: str = typer.Option("nats://localhost:4222", help="The NATS server URL."),
) -> None:  # pragma: no cover
    """Start the decoupled epistemic deficit subscriber daemon."""
    from coreason_ecosystem.daemons.deficit_subscriber import (
        DeficitStateMutationSubscriber,
    )

    subscriber = DeficitStateMutationSubscriber(nats_url=nats_url)

    async def _run_subscriber() -> None:
        await subscriber.listen()
        while True:
            await asyncio.sleep(3600)

    try:
        asyncio.run(_run_subscriber())
    except KeyboardInterrupt:
        console.print("[yellow]Daemon interrupted by operator.[/yellow]")
        asyncio.run(subscriber.shutdown())


@app.command(
    name="init",
    help="Interactively initialize the CoReason Ecosystem workspace, detecting host architecture and auto-configuring parameters.",
)
def init(
    target_dir: str = typer.Option(
        ".", "--target-dir", "-t", help="Target configuration directory"
    ),
) -> None:
    """Interactively initialize the CoReason Ecosystem workspace."""

    async def _run() -> None:
        await execute_init(target_dir)

    asyncio.run(_run())


@app.command(name="up")
def up() -> None:
    """Implement Idempotent DAG Resolution for the Swarm infrastructure."""

    async def _run() -> None:  # pragma: no cover
        await execute_up()

    asyncio.run(_run())


@app.command(name="doctor")
def doctor() -> None:
    """Prove Ontological Isomorphism across the Tripartite Manifold."""

    async def _run() -> None:
        await execute_oracle_diagnostic()

    asyncio.run(_run())


@app.command(
    name="sync",
    help="Autonomically heal Ontological Drift by synchronizing schemas, recompiling capabilities, and restarting the daemon.",
)
def sync() -> None:
    """Autonomically heal Ontological Drift."""

    async def _run() -> None:
        await execute_sync()

    asyncio.run(_run())


docs_app = typer.Typer(help="Epistemic Documentation Pipeline")
app.add_typer(docs_app, name="docs")

license_app = typer.Typer(help="Sovereign Commercial License Management")
app.add_typer(license_app, name="license")

registry_app = typer.Typer(help="Sovereign OCI Artifact Registry & URN Management")
app.add_typer(registry_app, name="registry")

contribution_app = typer.Typer(
    help="Manage and inspect tenant mesh contribution metrics, rankings, and anti-abuse scoring"
)
app.add_typer(contribution_app, name="contribution")


@registry_app.command("list")
def registry_list(
    ledger_path: str = typer.Option(
        None,
        "--ledger-path",
        help="Path to a custom ledger index.yaml",
    ),
) -> None:
    """List all URNs registered in the OCI Artifact Ledger."""
    from coreason_ecosystem.utils.urn_authority_client import (
        load_ledger,
        _DEFAULT_LEDGER_PATH,
        TopologicalSeveranceEvent,
    )

    path = Path(ledger_path) if ledger_path else _DEFAULT_LEDGER_PATH
    try:
        entries = load_ledger(path)
    except TopologicalSeveranceEvent as e:
        console.print(f"[bold red]Error Loading Ledger:[/bold red] {e}")
        raise typer.Exit(code=1)

    if not entries:
        console.print("No capabilities registered in the ledger.")
        return

    console.print(
        f"\n[bold cyan]--- OCI Artifact Ledger ({len(entries)} capabilities) ---[/bold cyan]"
    )
    for entry in entries:
        console.print(f"  [bold]{entry.urn}[/bold]")
        console.print(f"    OCI Artifact: [green]{entry.oci_uri}[/green]")
        console.print(f"    Signer DID:   [dim]{entry.authorized_signer_did}[/dim]")
        console.print(f"    Tenant CID:   [dim]{entry.tenant_cid}[/dim]")
        console.print()


@registry_app.command("resolve")
def registry_resolve(
    urn: str = typer.Argument(..., help="The CoReason URN to resolve"),
    ledger_path: str = typer.Option(
        None,
        "--ledger-path",
        help="Path to a custom ledger index.yaml",
    ),
) -> None:
    """Resolve a URN to its verified OCI artifact URI."""
    from coreason_ecosystem.utils.urn_authority_client import (
        resolve_capability,
        _DEFAULT_LEDGER_PATH,
        TopologicalSeveranceEvent,
    )

    path = Path(ledger_path) if ledger_path else _DEFAULT_LEDGER_PATH
    try:
        receipt = resolve_capability(urn, ledger_path=path)
    except TopologicalSeveranceEvent as e:
        console.print(f"[bold red]Resolution Error:[/bold red] {e}")
        raise typer.Exit(code=1)

    console.print("\n[bold green]✔ Verified Capability Receipt[/bold green]")
    console.print(f"  [bold]URN:[/bold]    {receipt.urn}")
    console.print(f"  [bold]OCI:[/bold]    {receipt.oci_uri}")
    console.print(f"  [bold]Signer:[/bold] {receipt.authorized_signer_did}")
    console.print(f"  [bold]Tenant:[/bold] {receipt.tenant_cid}")


@registry_app.command("promote")
def registry_promote(
    urn: str = typer.Option(
        ..., help="The URN to register/promote (e.g. urn:coreason:actionspace:...)"
    ),
    oci_uri: str = typer.Option(..., help="The OCI artifact URI path"),
    did: str = typer.Option(
        ..., help="The authorized signer W3C DID (e.g. did:key:z6Mk...)"
    ),
    tenant_cid: str = typer.Option(
        "urn:tenant:coreason:global:authority",
        help="Tenant CID isolation key",
    ),
    mcp_namespace: str = typer.Option(
        None,
        help="Optional reverse-DNS namespace",
    ),
    ledger_path: str = typer.Option(
        None,
        "--ledger-path",
        help="Path to a custom ledger index.yaml",
    ),
    skip_git: bool = typer.Option(
        False,
        "--skip-git",
        help="Skip Git release checkout/commit/branch workflow.",
    ),
) -> None:
    """Promote/register a URN in the distributed URN database ledger."""
    from coreason_ecosystem.utils.urn_authority_client import (
        _DEFAULT_LEDGER_PATH,
        append_to_ledger,
    )
    import subprocess

    if not urn.startswith("urn:coreason:"):
        console.print(
            "[bold red]Error:[/bold red] URN must follow the 'urn:coreason:' schema."
        )
        raise typer.Exit(code=1)
    if not did.startswith("did:key:"):
        console.print(
            "[bold red]Error:[/bold red] Signer DID must follow the 'did:key:' format."
        )
        raise typer.Exit(code=1)

    path = Path(ledger_path) if ledger_path else _DEFAULT_LEDGER_PATH
    safe_urn = urn.replace(":", "-")
    branch_name = f"promote/{safe_urn}"

    console.print(f"Promoting [bold cyan]{urn}[/bold cyan] to ledger at {path}")

    # Checkout new branch
    if not skip_git:
        try:
            subprocess.run(
                ["git", "checkout", "-b", branch_name], check=True, cwd=path.parent
            )
        except subprocess.CalledProcessError as e:
            console.print(
                f"[bold red]Git Error:[/bold red] failed to create branch: {e}"
            )
            raise typer.Exit(code=1)

    # Append to ledger
    try:
        append_to_ledger(
            ledger_path=path,
            urn=urn,
            oci_uri=oci_uri,
            did=did,
            tenant_cid=tenant_cid,
            mcp_namespace=mcp_namespace,
        )
    except Exception as e:
        console.print(f"[bold red]Ledger Promotion Error:[/bold red] {e}")
        raise typer.Exit(code=1)

    # Commit changes
    if not skip_git:
        try:
            subprocess.run(["git", "add", path.name], check=True, cwd=path.parent)
            subprocess.run(
                ["git", "commit", "-m", f"feat: promote {urn}"],
                check=True,
                cwd=path.parent,
            )
        except subprocess.CalledProcessError as e:
            console.print(
                f"[bold red]Git Error:[/bold red] failed to stage/commit ledger: {e}"
            )
            raise typer.Exit(code=1)

    if skip_git:
        console.print("\n[bold green]✔ Promotion Completed Successfully[/bold green]")
        console.print("Locally updated ledger file. Git release lifecycle skipped.")
    else:
        console.print("\n[bold green]✔ Promotion Staged Successfully[/bold green]")
        console.print(
            f"Locally committed to branch: [bold cyan]{branch_name}[/bold cyan]"
        )
        console.print("\nTo complete the GitOps Release Protocol, execute:")
        console.print(f"  git push origin {branch_name}")
        console.print(
            '  gh pr create --title "feat: promote capability" --body "Human Oracle Review Requested."'
        )
        console.print(
            "Once approved and merged, the URN will be resolvable natively by the global mesh."
        )


@license_app.command("install")
def license_install(
    jwt_string: str = typer.Argument(
        ..., help="The cryptographically signed JWT License Token."
    ),
) -> None:
    """Install and mathematically verify a Commercial License JWT."""
    import subprocess
    import sys
    import shutil
    from pathlib import Path

    # Determine command to run
    # 1. Try if coreason-chronometer is in PATH
    if shutil.which("coreason-chronometer"):
        cmd = ["coreason-chronometer", "install-license", jwt_string]
    else:
        # 2. Fall back to cargo run --manifest-path ...
        current_file = Path(__file__).resolve()
        manifest_path = (
            current_file.parent / "daemons" / "coreason-chronometer" / "Cargo.toml"
        )
        if not manifest_path.exists():
            manifest_path = Path(
                "src/coreason_ecosystem/daemons/coreason-chronometer/Cargo.toml"
            )

        cmd = [
            "cargo",
            "run",
            "--manifest-path",
            str(manifest_path),
            "--release",
            "--",
            "install-license",
            jwt_string,
        ]

    try:
        res = subprocess.run(cmd, capture_output=True, text=True, check=True)
        if res.stdout:
            console.print(res.stdout.strip())
    except subprocess.CalledProcessError as e:
        err_msg = e.stderr.strip() if e.stderr else str(e)
        console.print(f"[bold red]✗ License Installation Failed:[/bold red] {err_msg}")
        sys.exit(1)


@docs_app.command(name="build")
def build_docs_cmd() -> None:
    """Generate dynamic MkDocs documentation from the ontological schema and ledger."""
    try:
        from coreason_ecosystem.docs_generator import generate_dynamic_docs

        generate_dynamic_docs()
    except Exception as e:
        console.print(f"[bold red]Documentation Pipeline Failed:[/bold red] {e}")


@app.command(name="pi")
def pi_terminal() -> None:
    """Launch the pi.dev Sovereign Developer Console."""
    import subprocess  # nosec: B404

    console.print("[bold green]Launching the pi.dev Kinetic Harness...[/bold green]")
    try:
        # We invoke the pi.dev CLI natively using npx
        subprocess.run(["npx", "@mariozechner/pi-coding-agent"], check=True)  # nosec: B603, B607
    except FileNotFoundError:
        console.print(
            "[bold red]Error:[/bold red] Node.js and npx are required to launch pi.dev."
        )
    except subprocess.CalledProcessError as e:
        console.print(
            f"[bold red]Pi terminal exited with code {e.returncode}[/bold red]"
        )


@contribution_app.command("stats")
def contribution_stats(
    tenant_cid: str = typer.Option(
        None,
        "--tenant-cid",
        help="Optional target tenant CID (defaults to environment or config)",
    ),
    uptime: float = typer.Option(
        120.0, "--uptime", help="Simulated uptime hours share"
    ),
    bandwidth: float = typer.Option(
        45.0, "--bandwidth", help="Simulated routed bandwidth (GB)"
    ),
    validations: int = typer.Option(
        12, "--validations", help="Simulated PVV validations signed"
    ),
    credits: float = typer.Option(
        2400.0, "--credits", help="Simulated Deficit Credits balance"
    ),
) -> None:
    """Show the tenant contribution stats, Kaggle-style rank, and OpenSSF certified badges."""
    from coreason_ecosystem.orchestration.contribution import TenantContributionStats

    import os

    is_verified = bool(os.getenv("COREASON_VERIFICATION_KEY"))
    cid = tenant_cid or "urn:tenant:coreason:user-node"
    stats = TenantContributionStats(
        tenant_cid=cid,
        uptime_hours=uptime,
        bandwidth_gb=bandwidth,
        pvv_validations=validations,
        deficit_credits=credits,
        id_verified=is_verified,
    )

    console.print(
        "\n[bold cyan]┌────────────────────────────────────────────────────────┐[/bold cyan]"
    )
    console.print(
        "[bold cyan]│[/bold cyan] [bold white]COCONUT MESH PARTICIPANT STATUS[/bold white]                   [bold cyan]│[/bold cyan]"
    )
    console.print(
        "[bold cyan]├────────────────────────────────────────────────────────┤[/bold cyan]"
    )
    console.print(
        f"[bold cyan]│[/bold cyan] Tenant CID:   [dim]{stats.tenant_cid:38s}[/dim] [bold cyan]│[/bold cyan]"
    )
    console.print(
        f"[bold cyan]│[/bold cyan] Reputation Score: [yellow]{stats.reputation_score:34.2f}[/yellow] [bold cyan]│[/bold cyan]"
    )
    console.print(
        f"[bold cyan]│[/bold cyan] Mesh Rank Tier:   [bold magenta]{stats.reputation_tier:34s}[/bold magenta] [bold cyan]│[/bold cyan]"
    )
    console.print(
        "[bold cyan]├────────────────────────────────────────────────────────┤[/bold cyan]"
    )
    console.print(
        f"[bold cyan]│[/bold cyan] Uptime Hours:     [green]{stats.uptime_hours:34.1f}[/green] [bold cyan]│[/bold cyan]"
    )
    console.print(
        f"[bold cyan]│[/bold cyan] Bandwidth Routed: [green]{stats.bandwidth_gb:34.1f} GB[/green] [bold cyan]│[/bold cyan]"
    )
    console.print(
        f"[bold cyan]│[/bold cyan] PVV Validations:  [green]{stats.pvv_validations:34d}[/green] [bold cyan]│[/bold cyan]"
    )
    console.print(
        f"[bold cyan]│[/bold cyan] Deficit Credits:  [green]{stats.deficit_credits:34.2f}[/green] [bold cyan]│[/bold cyan]"
    )
    console.print(
        "[bold cyan]├────────────────────────────────────────────────────────┤[/bold cyan]"
    )
    console.print(
        "[bold cyan]│[/bold cyan] [bold white]Certified Badges Earned:[/bold white]                               [bold cyan]│[/bold cyan]"
    )
    for badge in stats.badges:
        console.print(
            f"[bold cyan]│[/bold cyan]   ⭐ [bold green]{badge:47s}[/bold green] [bold cyan]│[/bold cyan]"
        )
    if not stats.badges:
        console.print(
            f"[bold cyan]│[/bold cyan]   [dim]{'None (Novice)':49s}[/dim] [bold cyan]│[/bold cyan]"
        )
    console.print(
        "[bold cyan]└────────────────────────────────────────────────────────┘[/bold cyan]\n"
    )


@contribution_app.command("calculate-splits")
def contribution_calculate_splits(
    urn: str = typer.Argument(..., help="URN of the capability to invoke"),
    payout: float = typer.Option(
        100.0, "--payout", help="Base payout amount in credits"
    ),
    calls: int = typer.Option(
        1, "--calls", help="Consecutive calls by the same tenant"
    ),
    caller_cid: str = typer.Option(
        "urn:tenant:user", "--caller-cid", help="Caller tenant CID"
    ),
) -> None:
    """Simulate topological URN execution split with anti-abuse decay logic."""
    from coreason_ecosystem.orchestration.contribution import evaluate_royalty_split
    from coreason_ecosystem.utils.urn_authority_client import (
        cached_load_ledger,
        resolve_urn,
        TopologicalSeveranceEvent,
    )

    try:
        ledger = cached_load_ledger()
        entry = resolve_urn(urn, ledger)
    except TopologicalSeveranceEvent as e:
        console.print(f"[bold red]Error resolving URN:[/bold red] {e}")
        raise typer.Exit(code=1)

    shares = entry.royalty_shares or {entry.authorized_signer_did: 100}

    distributions = evaluate_royalty_split(
        payout_amount=payout,
        shares={k: float(v) for k, v in shares.items()},
        caller_cid=caller_cid,
        provider_did=entry.authorized_signer_did,
        consecutive_calls=calls,
    )

    console.print(f"\n[bold green]✔ Invocation calculations for {urn}[/bold green]")
    console.print(f"  Base Payout:  [yellow]{payout} credits[/yellow]")
    console.print(f"  Caller CID:   [dim]{caller_cid}[/dim]")
    console.print(f"  Consecutive invocations: [cyan]{calls}[/cyan]")

    from coreason_ecosystem.orchestration.contribution import (
        calculate_anti_abuse_multiplier,
    )

    mult = calculate_anti_abuse_multiplier(calls)
    console.print(
        f"  Anti-Abuse Decay Multiplier: [bold magenta]{mult * 100:.2f}%[/bold magenta]"
    )
    console.print(
        f"  Final Adjusted Payout: [bold yellow]{payout * mult:.4f} credits[/bold yellow]"
    )

    console.print("\n[bold white]Topological Distribution Tree:[/bold white]")
    for did, amt in distributions.items():
        share_pct = shares.get(did, 100)
        console.print(
            f"  ├── {did} ({share_pct}% split) ──► [bold green]+{amt:.4f} credits[/bold green]"
        )
    console.print()


def main() -> None:  # pragma: no cover
    """Entry point for the CLI."""
    app()


if __name__ == "__main__":  # pragma: no cover
    main()
