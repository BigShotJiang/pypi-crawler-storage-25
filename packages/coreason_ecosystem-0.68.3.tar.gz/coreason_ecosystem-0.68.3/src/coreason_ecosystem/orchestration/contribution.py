# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license

"""CoReason Contribution Scoring, Badging, and Anti-Abuse Decay Engine."""

from __future__ import annotations

from typing import Literal
from pydantic import BaseModel, Field

# Define Type Aliases
ReputationTier = Literal["Novice", "Contributor", "Expert", "Master", "Grandmaster"]


class TenantContributionStats(BaseModel):
    """Represents the contribution metrics and reputation state of a tenant."""

    tenant_cid: str = Field(description="The cryptographic identity of the tenant.")
    uptime_hours: float = Field(
        default=0.0, description="Uptime hours contributed to public mesh."
    )
    bandwidth_gb: float = Field(
        default=0.0, description="Network data routed in gigabytes."
    )
    pvv_validations: int = Field(
        default=0, description="Count of PVV quality validation checks signed."
    )
    deficit_credits: float = Field(
        default=0.0, description="Accumulated utility token credit balance."
    )
    id_verified: bool = Field(
        default=False,
        description="Whether the tenant identity has been verified by CoReason, Inc. via Amazon Key Store.",
    )

    @property
    def reputation_score(self) -> float:
        """Computes the overall raw reputation score based on weights."""
        return (
            self.uptime_hours * 1.0
            + self.bandwidth_gb * 0.5
            + self.pvv_validations * 10.0
            + self.deficit_credits * 0.1
        )

    @property
    def reputation_tier(self) -> ReputationTier:
        """Determines the Kaggle-style reputation tier based on contribution metrics."""
        score = self.reputation_score
        if score >= 5000:
            return "Grandmaster"
        if score >= 2000:
            return "Master"
        if score >= 500:
            return "Expert"
        if score >= 50:
            return "Contributor"
        return "Novice"

    @property
    def badges(self) -> list[str]:
        """Evaluates OpenSSF-style badges earned by the tenant's node configuration."""
        earned: list[str] = []
        if self.tenant_cid != "urn:tenant:coreason:global:authority":
            earned.append("Verified Publisher")
        if self.id_verified:
            earned.append("Real Verified")
        if self.uptime_hours > 0:
            earned.append("Silver Sandbox")
        if self.pvv_validations >= 10:
            earned.append("Gold Verification")
        return earned


def calculate_anti_abuse_multiplier(
    consecutive_calls: int,
    *,
    lambda_param: float = 0.05,
) -> float:
    """Calculates the diminishing returns multiplier to prevent wash executions.

    Formula: M(N) = 1 / (1 + lambda * (N - 1))
    """
    if consecutive_calls <= 1:
        return 1.0
    return 1.0 / (1.0 + lambda_param * (consecutive_calls - 1))


def evaluate_royalty_split(
    *,
    payout_amount: float,
    shares: dict[str, float],
    caller_cid: str,
    provider_did: str,
    consecutive_calls: int = 1,
    lambda_param: float = 0.05,
) -> dict[str, float]:
    """Computes the final royalty split distributions for a URN invocation,

    applying same-tenant diminishing returns decay and self-dealing exclusions.
    """
    # 1. Calculate same-tenant abuse multiplier
    multiplier = calculate_anti_abuse_multiplier(
        consecutive_calls, lambda_param=lambda_param
    )
    adjusted_payout = payout_amount * multiplier

    # 2. Check self-dealing (Zero-Loop Rule)
    provider_suffix = provider_did.split(":")[-1]
    self_dealing = provider_suffix in caller_cid

    distributions: dict[str, float] = {}
    for payee_did, share_pct in shares.items():
        raw_share = adjusted_payout * (share_pct / 100.0)

        # Zero-Loop Rule: exclude payee if self-dealing
        payee_suffix = payee_did.split(":")[-1]
        if self_dealing and payee_suffix in caller_cid:
            distributions[payee_did] = 0.0
        else:
            distributions[payee_did] = round(raw_share, 4)

    return distributions
