# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-ecosystem>

"""License Tier Metadata in Capability Ledger (#255).

Adds license_class tracking to the capability ledger, preventing
unauthorized execution of premium capabilities.
"""

from __future__ import annotations

from typing import Any, Literal

from coreason_manifest.spec.ontology import CoreasonBaseState
from pydantic import Field


class CapabilityLedgerEntry(CoreasonBaseState):
    """A capability entry with license tier metadata."""

    capability_urn: str = Field(description="The URN of the capability")
    oci_uri: str = Field(description="The OCI artifact URI")
    license_class: Literal["prosperity-3.0", "commercial", "research"] = Field(
        default="prosperity-3.0",
        description="License classification governing execution rights",
    )
    minimum_tier: Literal["free", "standard", "enterprise"] = Field(
        default="free",
        description="Minimum tenant tier required to execute this capability",
    )
    cost_per_invocation: float = Field(
        default=0.0,
        description="Thermodynamic cost per invocation in compute units",
    )
    authorized_signer_did: str = Field(
        default="",
        description="DID of the authorized signer for Cosign verification",
    )


class CapabilityLedger:
    """Manages the capability ledger with license tier enforcement."""

    def __init__(self) -> None:
        self._entries: dict[str, CapabilityLedgerEntry] = {}

    def register(self, entry: CapabilityLedgerEntry) -> None:
        """Register or update a capability in the ledger."""
        self._entries[entry.capability_urn] = entry

    def lookup(self, capability_urn: str) -> CapabilityLedgerEntry | None:
        """Look up a capability by URN."""
        return self._entries.get(capability_urn)

    def check_access(
        self,
        capability_urn: str,
        tenant_tier: str,
        tenant_license: str = "prosperity-3.0",
    ) -> bool:
        """Check if a tenant has access to a capability based on license tier.

        Args:
            capability_urn: The capability URN to check.
            tenant_tier: The tenant's subscription tier (free, standard, enterprise).
            tenant_license: The tenant's license class.

        Returns:
            True if access is granted.
        """
        try:
            from coreason_ecosystem.utils.urn_authority_client import (
                get_rust_binary_path,
            )
            import subprocess
            import tempfile
            import yaml
            import os

            binary = get_rust_binary_path()
            capabilities_list = []
            for e in self._entries.values():
                dump = e.model_dump()
                # Translate fields for Rust LedgerEntry format
                dump["urn"] = dump.pop("capability_urn")
                dump["license_tier"] = dump.pop("license_class", "prosperity-3.0")
                capabilities_list.append(dump)

            with tempfile.NamedTemporaryFile(
                suffix=".yaml", mode="w", delete=False, encoding="utf-8"
            ) as tf:
                yaml.dump({"capabilities": capabilities_list}, tf)
                temp_path = tf.name

            try:
                res = subprocess.run(
                    [
                        binary,
                        "ledger-check-access",
                        "--ledger-path",
                        temp_path,
                        "--urn",
                        capability_urn,
                        "--tenant-tier",
                        tenant_tier,
                        "--tenant-license",
                        tenant_license,
                    ],
                    capture_output=True,
                    text=True,
                    check=False,
                )
                try:
                    os.unlink(temp_path)
                except Exception:
                    pass
                if res.returncode == 0:
                    return res.stdout.strip() == "true"
                else:
                    return False
            except Exception:
                try:
                    os.unlink(temp_path)
                except Exception:
                    pass
                raise
        except Exception as e:
            raise RuntimeError(
                f"Failed to run Rust ledger-check-access CLI: {e}"
            ) from e

    def list_capabilities(
        self,
        *,
        license_class: str | None = None,
        minimum_tier: str | None = None,
    ) -> list[CapabilityLedgerEntry]:
        """List capabilities with optional filtering."""
        results = list(self._entries.values())
        if license_class:
            results = [e for e in results if e.license_class == license_class]
        if minimum_tier:
            results = [e for e in results if e.minimum_tier == minimum_tier]
        return results

    def to_dict(self) -> dict[str, Any]:
        """Serialize the ledger to a dictionary."""
        return {urn: entry.model_dump() for urn, entry in self._entries.items()}
