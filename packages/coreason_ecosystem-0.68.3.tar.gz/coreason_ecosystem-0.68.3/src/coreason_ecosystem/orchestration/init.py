# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license

import sys
import os
import platform
import subprocess
import shutil
import json
from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.prompt import Prompt, Confirm
from rich.progress import Progress, SpinnerColumn, TextColumn

console = Console()


def get_ram_gb() -> float:
    """Detect system memory RAM in Gigabytes, executing via Rust CLI."""
    from coreason_ecosystem.utils.urn_authority_client import get_rust_binary_path
    import tempfile

    binary = get_rust_binary_path()
    with tempfile.TemporaryDirectory() as td:
        res = subprocess.run(
            [
                binary,
                "init-workspace",
                "--target-path",
                td,
                "--categories",
                "",
                "--kyc",
                "{}",
            ],
            capture_output=True,
            text=True,
            check=True,
        )
        data = json.loads(res.stdout)
        return float(data["ram_gb"])


def detect_gpu() -> bool:
    """Check for NVIDIA GPU availability via Rust CLI."""
    from coreason_ecosystem.utils.urn_authority_client import get_rust_binary_path
    import tempfile

    binary = get_rust_binary_path()
    with tempfile.TemporaryDirectory() as td:
        res = subprocess.run(
            [
                binary,
                "init-workspace",
                "--target-path",
                td,
                "--categories",
                "",
                "--kyc",
                "{}",
            ],
            capture_output=True,
            text=True,
            check=True,
        )
        data = json.loads(res.stdout)
        return bool(data["has_gpu"])


def calculate_tenant_cid(kyc: dict[str, str]) -> tuple[str, str]:
    """Calculate the corporate tenant CID via Rust CLI."""
    from coreason_ecosystem.utils.urn_authority_client import get_rust_binary_path
    import tempfile

    binary = get_rust_binary_path()
    with tempfile.TemporaryDirectory() as td:
        res = subprocess.run(
            [
                binary,
                "init-workspace",
                "--target-path",
                td,
                "--categories",
                "",
                "--kyc",
                json.dumps(kyc),
            ],
            capture_output=True,
            text=True,
            check=True,
        )
        data = json.loads(res.stdout)
        return data["canonical_kyc"], data["tenant_cid"]


def generate_egress_rules(target_path: Path, selected_categories: list[str]) -> None:
    """Generate egress rules and Squid configurations via Rust CLI."""
    from coreason_ecosystem.utils.urn_authority_client import get_rust_binary_path

    binary = get_rust_binary_path()
    subprocess.run(
        [
            binary,
            "init-workspace",
            "--target-path",
            str(target_path.resolve()),
            "--categories",
            ",".join(selected_categories),
            "--kyc",
            "{}",
        ],
        capture_output=True,
        text=True,
        check=True,
    )


async def execute_init(target_dir: str) -> None:
    """Interactively initialize workspace infrastructure matching host characteristics."""
    console.print(
        Panel.fit(
            "[bold cyan]CoReason Ecosystem Control Plane Init Wizard[/bold cyan]\n"
            "[dim]Autoconfiguring macroscopic topology & capability boundaries[/dim]",
            border_style="cyan",
        )
    )

    # Phase 1: Host Diagnostics Checking
    console.print("\n[bold]🔍 Phase 1: Detecting Host substrate...[/bold]")
    os_name = platform.system()
    arch_name = platform.machine()
    cpu_cores = os.cpu_count() or 4
    ram_gb = get_ram_gb()
    has_gpu = detect_gpu()
    docker_ok = shutil.which("docker") is not None

    table = Table(title="Substrate Specifications Audit", box=None)
    table.add_column("Property", style="cyan", width=25)
    table.add_column("Value / Status", style="white")
    table.add_row("Operating System", f"[green]✔ {os_name}[/green]")
    table.add_row("Architecture", f"[green]✔ {arch_name}[/green]")
    table.add_row("CPU Cores", f"[green]{cpu_cores} Cores[/green]")
    table.add_row("System RAM", f"[green]{ram_gb:.2f} GB[/green]")
    table.add_row(
        "NVIDIA Hardware Accel",
        "[green]✔ Detected[/green]" if has_gpu else "[yellow]⚠ None detected[/yellow]",
    )
    table.add_row(
        "Docker Engine Subsystem",
        "[green]✔ Available[/green]" if docker_ok else "[red]✘ Missing[/red]",
    )
    console.print(table)

    # Phase 2: Accept license
    console.print("\n[bold]⚙ Phase 2: License Consent...[/bold]")
    console.print(
        "This software is dual-licensed under the [bold]Prosperity Public License 3.0.0[/bold].\n"
        "Commercial use beyond a 30-day trial requires a separate commercial license.\n"
        "No warranties of any kind are offered."
    )
    if not Confirm.ask("Do you accept the license and warranty terms?", default=True):
        console.print(
            "[bold red]❌ Setup aborted. You must accept the terms to initialize.[/bold red]"
        )
        sys.exit(1)

    # Phase 3: Setup Variables & Questions
    console.print("\n[bold]🔒 Phase 3: Configuration & Boundaries Q&A...[/bold]")

    # 1. Environment Name
    env_name = Prompt.ask(
        "Enter target deployment environment name",
        choices=["local", "staging", "production"],
        default="local",
    )

    # 2. Tenant ID
    if Confirm.ask("Use default CoReason, Inc. Tenant credentials?", default=True):
        tenant_cid = "889955217295c2bfef2d6812071b633b0819477e67f57853febf116f69f30531"
    else:
        console.print(
            "\nEnter corporate KYC registration inputs to derive your unique tenant_cid:"
        )
        legal_name = Prompt.ask("  Legal Name of Corporation")
        jurisdiction = Prompt.ask("  Jurisdiction of Incorporation (e.g. US-DE)")
        file_number = Prompt.ask("  Registration File Number")
        date_of_inc = Prompt.ask("  Date of Incorporation (YYYY-MM-DD)")
        kyc_data = {
            "legal_name": legal_name.strip(),
            "jurisdiction": jurisdiction.strip(),
            "file_number": file_number.strip(),
            "date_of_incorporation": date_of_inc.strip(),
        }
        _, tenant_cid = calculate_tenant_cid(kyc_data)
        console.print(
            f"[green]✔ Derived tenant_cid: [bold cyan]{tenant_cid}[/bold cyan][/green]"
        )

    # 3. Egress Permissions
    console.print("\nOutbound Egress Profile:")
    console.print("  1. Air-Gapped / Sovereign - Complete network isolation")
    console.print(
        "  2. Hybrid / Model Egress - Core state isolated, gateway proxy whitelisted"
    )
    console.print("  3. Fully Connected - Direct internet access")
    egress_choice = Prompt.ask(
        "Select profile number", choices=["1", "2", "3"], default="1"
    )
    egress_profiles = {"1": "air-gapped", "2": "hybrid", "3": "connected"}
    selected_egress = egress_profiles[egress_choice]

    use_local_proxy = False
    selected_categories = []
    custom_vars: dict[str, str] = {
        "EPISTEMIC_MERKLE_ROOT": tenant_cid,
        "HTTP_PROXY": "",
        "HTTPS_PROXY": "",
        "NO_PROXY": "localhost,127.0.0.1,temporal,postgres,sglang,dex,envoy,coreason-runtime,coreason-worker",
    }

    if selected_egress == "hybrid":
        console.print("\n🔧 Configure Egress Whitelist Categories:")
        categories = [
            ("registries", "Container Registries (Docker Hub, GHCR)"),
            ("huggingface", "Model Weight Downloads (Hugging Face)"),
            ("oidc", "Identity Providers (Okta, Entra, Google)"),
            ("cognitive", "Cloud Cognitive APIs (OpenAI, Vertex AI, Bedrock)"),
        ]
        for cat_id, cat_desc in categories:
            if Confirm.ask(f"  Authorize egress for {cat_desc}?", default=True):
                selected_categories.append(cat_id)

        if Confirm.ask(
            "\nAre you deploying behind an existing corporate HTTP/HTTPS proxy?",
            default=False,
        ):
            http_proxy = Prompt.ask("  Enter corporate HTTP Proxy URL")
            https_proxy = Prompt.ask(
                "  Enter corporate HTTPS Proxy URL", default=http_proxy
            )
            no_proxy = Prompt.ask(
                "  Enter Proxy Bypass list (NO_PROXY)", default=custom_vars["NO_PROXY"]
            )
            custom_vars["HTTP_PROXY"] = http_proxy
            custom_vars["HTTPS_PROXY"] = https_proxy
            custom_vars["NO_PROXY"] = no_proxy
        else:
            if Confirm.ask(
                "\nDeploy a local whitelisting proxy (Squid) to enforce rules in the mesh?",
                default=True,
            ):
                use_local_proxy = True
                if not selected_categories:
                    selected_categories = [
                        "registries",
                        "huggingface",
                        "oidc",
                        "cognitive",
                    ]
                custom_vars["HTTP_PROXY"] = "http://egress-proxy:3128"
                custom_vars["HTTPS_PROXY"] = "http://egress-proxy:3128"

    # 4. Inbound Exposure
    console.print("\n🔓 Inbound Port Exposure Configuration:")
    if Confirm.ask(
        "Restrict exposed platform ports to loopback (127.0.0.1) for secure VPC isolation?",
        default=True,
    ):
        custom_vars["COREASON_BIND_IP"] = "127.0.0.1"
        console.print(
            "[green]✔ Services will only bind to loopback (127.0.0.1).[/green]"
        )
    else:
        custom_vars["COREASON_BIND_IP"] = "0.0.0.0"
        console.print(
            "[yellow]⚠ Services will bind to 0.0.0.0 (exposed to local VPC network).[/yellow]"
        )

    # 5. Resource sizing recommendations based on cores/memory
    recommended_cpus = max(1.0, float(cpu_cores) / 2.0)
    recommended_memory = f"{max(2, int(ram_gb / 4))}G"
    custom_vars["RUNTIME_CPUS"] = str(recommended_cpus)
    custom_vars["RUNTIME_MEMORY"] = recommended_memory

    # Target Path Resolution
    target_path = Path(target_dir).resolve()
    if not target_path.exists():
        target_path.mkdir(parents=True, exist_ok=True)

    # Phase 4: Deploy configurations
    console.print("\n[bold]📦 Phase 4: Generating mesh configuration outputs...[/bold]")

    # Locate templates relative to package location
    source_template_dir = (
        Path(__file__).resolve().parent.parent.parent.parent
        / "infrastructure"
        / "local"
    )
    if not source_template_dir.exists():
        # Fallback to current working directory lookup
        source_template_dir = Path("infrastructure/local")

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        transient=True,
    ) as progress:
        # 1. Copy static templates
        progress.add_task(description="Deploying platform configs...", total=None)
        files_to_copy = [
            "envoy.yaml",
            "dex-config.yaml",
            "capabilities.matrix.yaml",
            "otel-collector-config.yaml",
            "redpanda-connect-pipeline.yaml",
        ]
        for f_name in files_to_copy:
            src_file = source_template_dir / f_name
            if src_file.exists():
                shutil.copy(src_file, target_path / f_name)

        # 2. Copy and customize compose.yaml
        compose_template = source_template_dir / "compose.yaml"
        compose_target = target_path / "compose.yaml"

        if compose_template.exists():
            with open(compose_template, "r", encoding="utf-8") as f:
                content = f.read()

            # Apply Bind IP to all port exposures
            content = content.replace(
                '- "8000:8000"', '- "${COREASON_BIND_IP}:8000:8000"'
            )
            content = content.replace(
                '- "7233:7233"', '- "${COREASON_BIND_IP}:7233:7233"'
            )
            content = content.replace(
                '- "5556:5556"', '- "${COREASON_BIND_IP}:5556:5556"'
            )
            content = content.replace('- "80:80"', '- "${COREASON_BIND_IP}:80:80"')
            content = content.replace(
                '- "3000:3000"', '- "${COREASON_BIND_IP}:3000:3000"'
            )
            content = content.replace(
                '- "8200:8200"', '- "${COREASON_BIND_IP}:8200:8200"'
            )
            content = content.replace(
                '- "19530:19530"', '- "${COREASON_BIND_IP}:19530:19530"'
            )
            content = content.replace(
                '- "7474:7474"', '- "${COREASON_BIND_IP}:7474:7474"'
            )
            content = content.replace(
                '- "7687:7687"', '- "${COREASON_BIND_IP}:7687:7687"'
            )
            content = content.replace(
                '- "9000:9000"', '- "${COREASON_BIND_IP}:9000:9000"'
            )
            content = content.replace(
                '- "4317:4317"', '- "${COREASON_BIND_IP}:4317:4317"'
            )
            content = content.replace(
                '- "4318:4318"', '- "${COREASON_BIND_IP}:4318:4318"'
            )

            # Inject proxy environment blocks into runtime and worker
            proxy_block = """      - HTTP_PROXY=${HTTP_PROXY}
      - HTTPS_PROXY=${HTTPS_PROXY}
      - NO_PROXY=${NO_PROXY}"""
            content = content.replace(
                "    environment:\n      - EPISTEMIC_MERKLE_ROOT=${EPISTEMIC_MERKLE_ROOT}",
                "    environment:\n      - EPISTEMIC_MERKLE_ROOT=${EPISTEMIC_MERKLE_ROOT}\n"
                + proxy_block,
            )
            content = content.replace(
                "    environment:\r\n      - EPISTEMIC_MERKLE_ROOT=${EPISTEMIC_MERKLE_ROOT}",
                "    environment:\r\n      - EPISTEMIC_MERKLE_ROOT=${EPISTEMIC_MERKLE_ROOT}\r\n"
                + proxy_block,
            )

            if use_local_proxy:
                # Add local squid proxy container and egress-network
                squid_service = """
  # Local whitelisting proxy (Squid)
  egress-proxy:
    image: ubuntu/squid:latest
    restart: on-failure
    volumes:
      - ./egress-whitelist.squid.conf:/etc/squid/squid.conf:ro
    networks:
      - swarm-mesh
      - egress-network
"""
                content = content.replace("networks:", squid_service + "\nnetworks:")
                content = content.replace(
                    "networks:\n  swarm-mesh:\n    internal: true\n  sensory-gateway:",
                    "networks:\n  swarm-mesh:\n    internal: true\n  sensory-gateway:\n  egress-network:\n    driver: bridge\n  sensory-gateway:",
                )
            else:
                if selected_egress == "hybrid":
                    content = content.replace(
                        "sensory-gateway:\n  wasmcloud-lattice:",
                        "sensory-gateway:\n    internal: false\n  wasmcloud-lattice:",
                    )
                elif selected_egress == "connected":
                    content = content.replace("internal: true", "internal: false")

            with open(compose_target, "w", encoding="utf-8") as f:
                f.write(content)

        # 3. Generate whitelists
        if use_local_proxy and selected_categories:
            generate_egress_rules(target_path, selected_categories)

        # 4. Generate .env file
        env_lines = []
        for k, v in custom_vars.items():
            env_lines.append(f"{k}={v}")

        # Add CPU/memory settings
        env_lines.append(f"RUNTIME_CPUS={recommended_cpus}")
        env_lines.append(f"RUNTIME_MEMORY={recommended_memory}")
        env_lines.append(f"ENV_MODE={env_name}")
        env_lines.append("COREASON_MASTER_GATEWAY_URL=http://wasmcloud:8000")

        with open(target_path / ".env", "w", encoding="utf-8") as f:
            f.write("\n".join(env_lines) + "\n")

    console.print(
        Panel(
            f"[bold green]🎉 SUCCESS: CoReason Ecosystem configured for '{env_name}'![/bold green]\n\n"
            f"📂 [bold]Target Directory:[/bold] {target_path}\n"
            f"🔐 [bold]Epistemic Root (Tenant):[/bold] {tenant_cid}\n"
            f"🌐 [bold]Bind IP Exposure:[/bold] {custom_vars['COREASON_BIND_IP']}\n"
            f"⚡ [bold]CPUs Allocated:[/bold] {recommended_cpus} Cores (System Max: {cpu_cores})\n"
            f"💾 [bold]Memory Limit:[/bold] {recommended_memory} (System Max: {ram_gb:.1f}GB)\n\n"
            "You can now sync capabilities and resolve container topologies using:\n"
            "  [bold cyan]coreason-ecosystem sync[/bold cyan]\n"
            "  [bold cyan]coreason-ecosystem up[/bold cyan]",
            border_style="green",
            title="Initialization Dashboard",
        )
    )
