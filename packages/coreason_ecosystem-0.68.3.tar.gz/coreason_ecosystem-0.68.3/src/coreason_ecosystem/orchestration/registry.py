# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-ecosystem>


import asyncio
import importlib.metadata
import logging
import os
import sys
from pathlib import Path

logger = logging.getLogger(__name__)


async def calculate_epistemic_root(project_path: Path) -> str:
    """Calculate the Epistemic Merkle Root.

    This runs the optimized Rust CLI binary subcommand 'epistemic-root' under the hood.
    Raises RuntimeError if the Rust execution fails.
    """
    try:
        from coreason_ecosystem.utils.urn_authority_client import get_rust_binary_path

        binary = get_rust_binary_path()

        # Get local manifest version
        try:
            manifest_version = importlib.metadata.version("coreason-manifest")
        except importlib.metadata.PackageNotFoundError:
            manifest_version = "unknown"

        env = os.environ.copy()
        if "PYTHON" not in env:
            env["PYTHON"] = sys.executable

        args = [
            binary,
            "epistemic-root",
            "--project-path",
            str(project_path.resolve()),
            "--manifest-version",
            manifest_version,
        ]

        proc = await asyncio.create_subprocess_exec(
            *args,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=env,
        )
        stdout_bytes, stderr_bytes = await proc.communicate()
        if proc.returncode == 0:
            return stdout_bytes.decode("utf-8").strip()

        raise RuntimeError(
            f"Rust epistemic-root calculation failed (exit code {proc.returncode}): {stderr_bytes.decode('utf-8').strip()}"
        )
    except Exception as e:
        if isinstance(e, RuntimeError):
            raise e
        raise RuntimeError(f"Failed to run Rust epistemic-root CLI: {e}") from e


def write_registry_lock(project_path: Path, root_hash: str) -> None:
    """Write the registry lock file with the given Merkle root."""
    import json

    lock_path = project_path / ".coreason" / "registry.lock"
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    out = {"epistemic_root": root_hash}
    lock_path.write_text(json.dumps(out, indent=2), encoding="utf-8")


def read_registry_lock(project_path: Path) -> str | None:
    """Read the registry lock file and return the Merkle root if it exists."""
    import json

    lock_path = project_path / ".coreason" / "registry.lock"
    if lock_path.exists():
        try:
            data = json.loads(lock_path.read_text(encoding="utf-8"))
            return str(data.get("epistemic_root"))
        except json.JSONDecodeError, ValueError:
            return lock_path.read_text(encoding="utf-8").strip()
    return None
