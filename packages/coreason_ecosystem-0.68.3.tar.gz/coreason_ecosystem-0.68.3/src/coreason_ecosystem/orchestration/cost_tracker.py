# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-ecosystem>

"""Thermodynamic Cost Tracking Database and Schema (#253).

Tracks compute expenditures (token costs, GPU time, API calls)
per tenant for billing enforcement and resource governance.
"""

from __future__ import annotations

import time
from typing import Any

from coreason_manifest.spec.ontology import CoreasonBaseState
from pydantic import Field


class ThermodynamicCostRecord(CoreasonBaseState):
    """A single cost record for a workflow execution."""

    tenant_cid: str = Field(description="Tenant identifier")
    workflow_id: str = Field(description="The Temporal workflow ID")
    agent_cid: str = Field(default="", description="Agent that incurred the cost")
    input_tokens: int = Field(default=0, description="Input tokens consumed")
    output_tokens: int = Field(default=0, description="Output tokens generated")
    total_tokens: int = Field(default=0, description="Total tokens (input + output)")
    cost_usd: float = Field(default=0.0, description="Estimated cost in USD")
    gpu_seconds: float = Field(default=0.0, description="GPU compute seconds used")
    timestamp: float = Field(
        default_factory=time.time, description="Unix epoch timestamp"
    )


class ThermodynamicCostTracker:
    """Tracks and enforces thermodynamic (compute) cost limits per tenant.

    Provides SQL schema for PostgreSQL persistence and in-memory
    tracking for real-time budget enforcement.
    """

    POSTGRES_SCHEMA = """
    CREATE TABLE IF NOT EXISTS thermodynamic_costs (
        id BIGSERIAL PRIMARY KEY,
        tenant_cid VARCHAR(128) NOT NULL,
        workflow_id VARCHAR(256) NOT NULL,
        agent_cid VARCHAR(256) DEFAULT '',
        input_tokens INTEGER DEFAULT 0,
        output_tokens INTEGER DEFAULT 0,
        total_tokens INTEGER DEFAULT 0,
        cost_usd NUMERIC(12, 6) DEFAULT 0.0,
        gpu_seconds NUMERIC(12, 4) DEFAULT 0.0,
        timestamp TIMESTAMPTZ DEFAULT NOW(),
        CONSTRAINT idx_tenant_workflow UNIQUE (tenant_cid, workflow_id, timestamp)
    );

    CREATE INDEX IF NOT EXISTS idx_costs_tenant ON thermodynamic_costs(tenant_cid);
    CREATE INDEX IF NOT EXISTS idx_costs_timestamp ON thermodynamic_costs(timestamp);

    -- Materialized view for tenant billing summaries
    CREATE MATERIALIZED VIEW IF NOT EXISTS tenant_cost_summary AS
    SELECT
        tenant_cid,
        SUM(total_tokens) as total_tokens,
        SUM(cost_usd) as total_cost_usd,
        SUM(gpu_seconds) as total_gpu_seconds,
        COUNT(*) as total_invocations,
        MAX(timestamp) as last_activity
    FROM thermodynamic_costs
    GROUP BY tenant_cid;
    """

    def __init__(self, budget_limit_usd: float = 100.0) -> None:
        self.budget_limit_usd = budget_limit_usd
        self._records: list[ThermodynamicCostRecord] = []
        self._tenant_totals: dict[str, float] = {}

    def record_cost(self, record: ThermodynamicCostRecord) -> None:
        """Record a cost event.

        Raises:
            ValueError: If the cost is negative.
            PermissionError: If the tenant has exceeded their budget.
        """
        try:
            from coreason_ecosystem.utils.urn_authority_client import (
                get_rust_binary_path,
            )
            import subprocess
            import json

            records_json = json.dumps([r.model_dump() for r in self._records])
            new_record_json = json.dumps(record.model_dump())

            binary = get_rust_binary_path()
            res = subprocess.run(
                [
                    binary,
                    "cost-tracker-verify",
                    "--budget",
                    str(self.budget_limit_usd),
                    "--records-json",
                    records_json,
                    "--new-record-json",
                    new_record_json,
                ],
                capture_output=True,
                text=True,
                check=False,
            )
            if res.returncode == 0:
                updated_data = json.loads(res.stdout)
                self._records = [ThermodynamicCostRecord(**r) for r in updated_data]
                self._tenant_totals = {}
                for r in self._records:
                    self._tenant_totals[r.tenant_cid] = (
                        self._tenant_totals.get(r.tenant_cid, 0.0) + r.cost_usd
                    )
                return
            else:
                err_msg = res.stderr.strip()
                if "budget exceeded" in err_msg.lower():
                    raise PermissionError(err_msg)
                else:
                    raise ValueError(err_msg)
        except (ValueError, PermissionError) as e:
            raise e
        except Exception as e:
            raise RuntimeError(
                f"Failed to run Rust cost-tracker-verify CLI: {e}"
            ) from e

    def get_tenant_total(self, tenant_cid: str) -> float:
        """Get total cost for a tenant."""
        return self._tenant_totals.get(tenant_cid, 0.0)

    def get_tenant_records(self, tenant_cid: str) -> list[ThermodynamicCostRecord]:
        """Get all cost records for a tenant."""
        return [r for r in self._records if r.tenant_cid == tenant_cid]

    def get_summary(self) -> dict[str, Any]:
        """Get billing summary across all tenants."""
        return {
            tenant: {
                "total_cost_usd": total,
                "budget_remaining_usd": self.budget_limit_usd - total,
                "invocations": len(
                    [r for r in self._records if r.tenant_cid == tenant]
                ),
            }
            for tenant, total in self._tenant_totals.items()
        }
