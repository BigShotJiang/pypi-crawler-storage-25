"""SemanticGuard Python SDK -- drop-in wrapper for the OpenAI Python client."""

from __future__ import annotations

import logging
import os
from typing import Any, Dict, Optional, Set

import openai

logger = logging.getLogger(__name__)

_RETRYABLE_STATUSES: Set[int] = {429, 500, 502, 503, 504}

_DEFAULT_BASE_URLS: Dict[str, str] = {
    "openai": "https://api.openai.com/v1",
}


class SemanticGuard:
    """Wraps an OpenAI-compatible client to route requests through the
    SemanticGuard gateway for intelligent caching, cost tracking, and
    analytics.

    Args:
        api_key: Your SemanticGuard API key (``sg-...``).
        gateway_url: Base URL of your SemanticGuard instance.
            Defaults to ``SEMANTICGUARD_URL`` env var, then ``https://www.semanticguard.dev``.
        fail_open: When ``True``, gateway errors (429/5xx) automatically
            retry against the original provider.
        gateway_timeout: Timeout in seconds for gateway requests
            (default 10.0).
    """

    _DEFAULT_GATEWAY_URL = "https://www.semanticguard.dev"

    def __init__(
        self,
        api_key: str,
        gateway_url: Optional[str] = None,
        fail_open: bool = False,
        gateway_timeout: float = 10.0,
    ) -> None:
        self.api_key = api_key
        resolved = gateway_url or os.environ.get("SEMANTICGUARD_URL") or self._DEFAULT_GATEWAY_URL
        self.gateway_url = resolved.rstrip("/")
        self.fail_open = fail_open
        self.gateway_timeout = gateway_timeout

    def _base_url(self) -> str:
        return self.gateway_url + "/api/proxy/v1"

    def _base_headers(self, project: Optional[str] = None) -> Dict[str, str]:
        headers: Dict[str, str] = {"x-sg-api-key": self.api_key}
        if project is not None:
            headers["x-sg-project"] = project
        return headers

    def wrap_openai(
        self,
        client: openai.OpenAI,
        project: Optional[str] = None,
    ) -> openai.OpenAI:
        """Return a new :class:`openai.OpenAI` client whose requests are
        routed through the SemanticGuard gateway.

        The original *client* is not modified. A new instance is created with
        the same API key but with ``base_url`` and ``default_headers``
        overridden.

        Args:
            client: An existing ``OpenAI`` client to wrap.
            project: Optional project tag sent as ``x-sg-project``.
        """
        return openai.OpenAI(
            api_key=client.api_key,
            base_url=self._base_url(),
            default_headers=self._base_headers(project),
            timeout=self.gateway_timeout,
        )

    def wrap_azure(
        self,
        client: Any,
        resource: str,
        deployment: str,
        project: Optional[str] = None,
    ) -> openai.OpenAI:
        """Return a new :class:`openai.OpenAI` client configured for Azure
        OpenAI via the SemanticGuard gateway.

        Azure-specific details (resource name, deployment) are forwarded as
        custom headers so the gateway can reconstruct the upstream request.

        Args:
            client: An existing ``AzureOpenAI`` client (used only for
                its API key).
            resource: Azure resource name.
            deployment: Azure deployment name.
            project: Optional project tag sent as ``x-sg-project``.
        """
        headers = self._base_headers(project)
        headers["x-sg-provider"] = "azure"
        headers["x-sg-azure-resource"] = resource
        headers["x-sg-azure-deployment"] = deployment

        return openai.OpenAI(
            api_key=client.api_key,
            base_url=self._base_url(),
            default_headers=headers,
            timeout=self.gateway_timeout,
        )

    def wrap_bedrock(
        self,
        client: openai.OpenAI,
        aws_access_key: str,
        aws_secret_key: str,
        region: str,
        project: Optional[str] = None,
    ) -> openai.OpenAI:
        """Return a new :class:`openai.OpenAI` client configured for AWS
        Bedrock via the SemanticGuard gateway.

        AWS credentials and region are forwarded as custom headers so the
        gateway can sign upstream requests.

        Args:
            client: An existing ``OpenAI`` client (used only for its
                API key).
            aws_access_key: AWS access key ID.
            aws_secret_key: AWS secret access key.
            region: AWS region (e.g. ``us-east-1``).
            project: Optional project tag sent as ``x-sg-project``.
        """
        headers = self._base_headers(project)
        headers["x-sg-provider"] = "bedrock"
        headers["x-sg-aws-access-key"] = aws_access_key
        headers["x-sg-aws-secret-key"] = aws_secret_key
        headers["x-sg-aws-region"] = region

        return openai.OpenAI(
            api_key=client.api_key,
            base_url=self._base_url(),
            default_headers=headers,
            timeout=self.gateway_timeout,
        )

    def chat(
        self,
        client: openai.OpenAI,
        project: Optional[str] = None,
        original_base_url: Optional[str] = None,
        **kwargs: Any,
    ) -> Any:
        """Call ``chat.completions.create`` with automatic fail-open.

        When :attr:`fail_open` is ``True`` and the gateway returns a
        retryable error (429 or 5xx), the request is retried directly
        against the original provider.

        Args:
            client: An existing ``OpenAI`` client (unwrapped).
            project: Optional project tag sent as ``x-sg-project``.
            original_base_url: The provider's base URL to fall back to.
                Defaults to ``https://api.openai.com/v1``.
            **kwargs: Arguments forwarded to
                ``chat.completions.create``.
        """
        wrapped = self.wrap_openai(client, project=project)

        try:
            return wrapped.chat.completions.create(**kwargs)
        except openai.APIStatusError as exc:
            if not self.fail_open:
                raise
            if exc.status_code not in _RETRYABLE_STATUSES:
                raise

            fallback_url = original_base_url or _DEFAULT_BASE_URLS.get(
                "openai", "https://api.openai.com/v1"
            )
            logger.warning(
                "SemanticGuard gateway returned %s, failing open to %s",
                exc.status_code,
                fallback_url,
            )

            fallback = openai.OpenAI(
                api_key=client.api_key,
                base_url=fallback_url,
            )
            return fallback.chat.completions.create(**kwargs)
        except openai.APIConnectionError:
            if not self.fail_open:
                raise

            fallback_url = original_base_url or _DEFAULT_BASE_URLS.get(
                "openai", "https://api.openai.com/v1"
            )
            logger.warning(
                "SemanticGuard gateway connection failed, failing open to %s",
                fallback_url,
            )

            fallback = openai.OpenAI(
                api_key=client.api_key,
                base_url=fallback_url,
            )
            return fallback.chat.completions.create(**kwargs)
