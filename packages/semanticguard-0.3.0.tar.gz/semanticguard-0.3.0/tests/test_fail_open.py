"""Tests for SemanticGuard fail-open behaviour."""

from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock, patch

import openai
import pytest

from semanticguard import SemanticGuard


@pytest.fixture
def sg_fail_open() -> SemanticGuard:
    return SemanticGuard(
        api_key="sg-test-key",
        gateway_url="https://example.com",
        fail_open=True,
        gateway_timeout=5.0,
    )


@pytest.fixture
def sg_no_fail_open() -> SemanticGuard:
    return SemanticGuard(
        api_key="sg-test-key",
        gateway_url="https://example.com",
        fail_open=False,
    )


def test_fail_open_defaults() -> None:
    sg = SemanticGuard(api_key="sg-k", gateway_url="https://example.com")
    assert sg.fail_open is False
    assert sg.gateway_timeout == 10.0


def test_fail_open_constructor_params() -> None:
    sg = SemanticGuard(
        api_key="sg-k",
        gateway_url="https://example.com",
        fail_open=True,
        gateway_timeout=5.0,
    )
    assert sg.fail_open is True
    assert sg.gateway_timeout == 5.0


def test_chat_retries_on_500(sg_fail_open: SemanticGuard) -> None:
    client = openai.OpenAI(api_key="sk-fake")
    mock_response = MagicMock()

    with patch.object(
        openai.resources.chat.completions.Completions,
        "create",
        side_effect=[
            openai.InternalServerError(
                message="gateway error",
                response=MagicMock(status_code=500),
                body=None,
            ),
            mock_response,
        ],
    ):
        result = sg_fail_open.chat(client, model="gpt-4o", messages=[])

    assert result is mock_response


def test_chat_retries_on_429(sg_fail_open: SemanticGuard) -> None:
    client = openai.OpenAI(api_key="sk-fake")
    mock_response = MagicMock()

    with patch.object(
        openai.resources.chat.completions.Completions,
        "create",
        side_effect=[
            openai.RateLimitError(
                message="rate limited",
                response=MagicMock(status_code=429),
                body=None,
            ),
            mock_response,
        ],
    ):
        result = sg_fail_open.chat(client, model="gpt-4o", messages=[])

    assert result is mock_response


def test_chat_retries_on_502(sg_fail_open: SemanticGuard) -> None:
    client = openai.OpenAI(api_key="sk-fake")
    mock_response = MagicMock()

    with patch.object(
        openai.resources.chat.completions.Completions,
        "create",
        side_effect=[
            openai.APIStatusError(
                message="bad gateway",
                response=MagicMock(status_code=502),
                body=None,
            ),
            mock_response,
        ],
    ):
        result = sg_fail_open.chat(client, model="gpt-4o", messages=[])

    assert result is mock_response


def test_chat_does_not_retry_on_400(sg_fail_open: SemanticGuard) -> None:
    client = openai.OpenAI(api_key="sk-fake")

    with patch.object(
        openai.resources.chat.completions.Completions,
        "create",
        side_effect=openai.BadRequestError(
            message="bad request",
            response=MagicMock(status_code=400),
            body=None,
        ),
    ):
        with pytest.raises(openai.BadRequestError):
            sg_fail_open.chat(client, model="gpt-4o", messages=[])


def test_chat_raises_when_fail_open_disabled(
    sg_no_fail_open: SemanticGuard,
) -> None:
    client = openai.OpenAI(api_key="sk-fake")

    with patch.object(
        openai.resources.chat.completions.Completions,
        "create",
        side_effect=openai.InternalServerError(
            message="gateway error",
            response=MagicMock(status_code=500),
            body=None,
        ),
    ):
        with pytest.raises(openai.InternalServerError):
            sg_no_fail_open.chat(client, model="gpt-4o", messages=[])


def test_chat_retries_on_connection_error(
    sg_fail_open: SemanticGuard,
) -> None:
    client = openai.OpenAI(api_key="sk-fake")
    mock_response = MagicMock()

    with patch.object(
        openai.resources.chat.completions.Completions,
        "create",
        side_effect=[
            openai.APIConnectionError(request=MagicMock()),
            mock_response,
        ],
    ):
        result = sg_fail_open.chat(client, model="gpt-4o", messages=[])

    assert result is mock_response


def test_chat_connection_error_raises_when_disabled(
    sg_no_fail_open: SemanticGuard,
) -> None:
    client = openai.OpenAI(api_key="sk-fake")

    with patch.object(
        openai.resources.chat.completions.Completions,
        "create",
        side_effect=openai.APIConnectionError(request=MagicMock()),
    ):
        with pytest.raises(openai.APIConnectionError):
            sg_no_fail_open.chat(client, model="gpt-4o", messages=[])


def test_chat_uses_custom_base_url(sg_fail_open: SemanticGuard) -> None:
    client = openai.OpenAI(api_key="sk-fake")
    mock_response = MagicMock()

    with patch.object(
        openai.resources.chat.completions.Completions,
        "create",
        side_effect=[
            openai.InternalServerError(
                message="err",
                response=MagicMock(status_code=500),
                body=None,
            ),
            mock_response,
        ],
    ):
        result = sg_fail_open.chat(
            client,
            model="gpt-4o",
            messages=[],
            original_base_url="https://custom-openai.example.com/v1",
        )

    assert result is mock_response


def test_wrap_openai_sets_timeout() -> None:
    sg = SemanticGuard(
        api_key="sg-k",
        gateway_url="https://example.com",
        gateway_timeout=7.5,
    )
    wrapped = sg.wrap_openai(openai.OpenAI(api_key="sk-fake"))
    assert wrapped.timeout == 7.5
