"""Unit tests for the SemanticGuard wrapper (no network calls)."""

from __future__ import annotations

import openai
import pytest

from semanticguard import SemanticGuard


@pytest.fixture
def sg() -> SemanticGuard:
    return SemanticGuard(api_key="sg-test-key", gateway_url="https://example.com")


def test_base_url(sg: SemanticGuard) -> None:
    wrapped = sg.wrap_openai(openai.OpenAI(api_key="sk-fake"))
    assert str(wrapped.base_url) == "https://example.com/api/proxy/v1/"


def test_sg_api_key_header(sg: SemanticGuard) -> None:
    wrapped = sg.wrap_openai(openai.OpenAI(api_key="sk-fake"))
    assert wrapped._custom_headers["x-sg-api-key"] == "sg-test-key"


def test_project_header(sg: SemanticGuard) -> None:
    wrapped = sg.wrap_openai(openai.OpenAI(api_key="sk-fake"), project="proj-1")
    assert wrapped._custom_headers["x-sg-project"] == "proj-1"


def test_no_project_header_when_omitted(sg: SemanticGuard) -> None:
    wrapped = sg.wrap_openai(openai.OpenAI(api_key="sk-fake"))
    assert "x-sg-project" not in wrapped._custom_headers


def test_preserves_api_key(sg: SemanticGuard) -> None:
    wrapped = sg.wrap_openai(openai.OpenAI(api_key="sk-original"))
    assert wrapped.api_key == "sk-original"


def test_trailing_slash_stripped() -> None:
    sg = SemanticGuard(api_key="sg-k", gateway_url="https://example.com/")
    wrapped = sg.wrap_openai(openai.OpenAI(api_key="sk-x"))
    assert str(wrapped.base_url) == "https://example.com/api/proxy/v1/"


def test_wrap_azure(sg: SemanticGuard) -> None:
    wrapped = sg.wrap_azure(
        openai.OpenAI(api_key="az-key"),
        resource="my-resource",
        deployment="gpt-4o",
    )
    assert str(wrapped.base_url) == "https://example.com/api/proxy/v1/"
    assert wrapped._custom_headers["x-sg-provider"] == "azure"
    assert wrapped._custom_headers["x-sg-azure-resource"] == "my-resource"
    assert wrapped._custom_headers["x-sg-azure-deployment"] == "gpt-4o"
    assert wrapped._custom_headers["x-sg-api-key"] == "sg-test-key"


def test_wrap_bedrock(sg: SemanticGuard) -> None:
    wrapped = sg.wrap_bedrock(
        openai.OpenAI(api_key="not-used"),
        aws_access_key="AKIATEST",
        aws_secret_key="secret",
        region="us-east-1",
    )
    assert str(wrapped.base_url) == "https://example.com/api/proxy/v1/"
    assert wrapped._custom_headers["x-sg-provider"] == "bedrock"
    assert wrapped._custom_headers["x-sg-aws-access-key"] == "AKIATEST"
    assert wrapped._custom_headers["x-sg-aws-secret-key"] == "secret"
    assert wrapped._custom_headers["x-sg-aws-region"] == "us-east-1"


def test_wrap_azure_with_project(sg: SemanticGuard) -> None:
    wrapped = sg.wrap_azure(
        openai.OpenAI(api_key="az-key"),
        resource="res",
        deployment="dep",
        project="my-proj",
    )
    assert wrapped._custom_headers["x-sg-project"] == "my-proj"


def test_wrap_bedrock_with_project(sg: SemanticGuard) -> None:
    wrapped = sg.wrap_bedrock(
        openai.OpenAI(api_key="x"),
        aws_access_key="A",
        aws_secret_key="S",
        region="eu-west-1",
        project="br-proj",
    )
    assert wrapped._custom_headers["x-sg-project"] == "br-proj"
