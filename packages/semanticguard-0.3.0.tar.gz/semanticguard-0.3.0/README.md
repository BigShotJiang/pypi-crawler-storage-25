# semanticguard

Drop-in Python wrapper for the [OpenAI Python SDK](https://github.com/openai/openai-python) that routes requests through the [SemanticGuard](https://semanticguard.dev) gateway for intelligent caching, cost tracking, and analytics.

## Installation

```bash
pip install semanticguard
```

## Quick start

```python
from openai import OpenAI
from semanticguard import SemanticGuard

sg = SemanticGuard(api_key="sg-...", gateway_url="https://semanticguard.dev")
client = sg.wrap_openai(OpenAI(api_key="sk-..."))

# Use the client exactly as you normally would
response = client.chat.completions.create(
    model="gpt-4o",
    messages=[{"role": "user", "content": "Hello!"}],
)
```

## Azure OpenAI

```python
from openai import AzureOpenAI
from semanticguard import SemanticGuard

sg = SemanticGuard(api_key="sg-...", gateway_url="https://semanticguard.dev")
azure = AzureOpenAI(api_key="...", api_version="2024-02-01",
                     azure_endpoint="https://my-resource.openai.azure.com")
client = sg.wrap_azure(azure, resource="my-resource", deployment="gpt-4o")
```

## AWS Bedrock

```python
from openai import OpenAI
from semanticguard import SemanticGuard

sg = SemanticGuard(api_key="sg-...", gateway_url="https://semanticguard.dev")
client = sg.wrap_bedrock(
    OpenAI(api_key="not-used"),
    aws_access_key="AKIA...",
    aws_secret_key="...",
    region="us-east-1",
)
```

## Project tagging

Pass a `project` argument to any wrapper to tag requests:

```python
client = sg.wrap_openai(OpenAI(api_key="sk-..."), project="my-project")
```

## License

MIT
