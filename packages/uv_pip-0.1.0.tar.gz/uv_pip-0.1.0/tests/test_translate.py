import pytest

from uv_pip.cli import translate


class TestPassthroughVersionStrings:
    """Package specifiers must pass through verbatim — do not parse or escape."""

    def test_gte(self):
        assert translate(["install", "requests>=2.28"]) == [
            "install",
            "requests>=2.28",
        ]

    def test_range(self):
        assert translate(["install", "requests>=2.28,<3.0"]) == [
            "install",
            "requests>=2.28,<3.0",
        ]

    def test_exact(self):
        assert translate(["install", "numpy==1.26.0"]) == [
            "install",
            "numpy==1.26.0",
        ]

    def test_compatible(self):
        assert translate(["install", "flask~=3.0"]) == ["install", "flask~=3.0"]

    def test_not_equal(self):
        assert translate(["install", "django!=4.2.0"]) == [
            "install",
            "django!=4.2.0",
        ]

    def test_extras(self):
        assert translate(["install", "requests[security]>=2.28"]) == [
            "install",
            "requests[security]>=2.28",
        ]

    def test_extras_multiple(self):
        assert translate(["install", "requests[security,socks]>=2.28,<3"]) == [
            "install",
            "requests[security,socks]>=2.28,<3",
        ]

    def test_vcs_git(self):
        assert translate(
            ["install", "git+https://github.com/psf/requests.git@v2.31.0"]
        ) == ["install", "git+https://github.com/psf/requests.git@v2.31.0"]

    def test_local_path(self):
        assert translate(["install", "./mypkg"]) == ["install", "./mypkg"]

    def test_editable_local(self):
        assert translate(["install", "-e", "./mypkg"]) == [
            "install",
            "-e",
            "./mypkg",
        ]

    def test_url_wheel(self):
        assert translate(
            ["install", "https://example.com/pkg-1.0-py3-none-any.whl"]
        ) == ["install", "https://example.com/pkg-1.0-py3-none-any.whl"]

    def test_pep508_direct_ref(self):
        assert translate(
            ["install", "pkg @ git+https://github.com/org/pkg.git"]
        ) == ["install", "pkg @ git+https://github.com/org/pkg.git"]


class TestStrip:
    def test_uninstall_y(self):
        assert translate(["uninstall", "-y", "foo"]) == ["uninstall", "foo"]

    def test_uninstall_yes(self):
        assert translate(["uninstall", "--yes", "foo"]) == ["uninstall", "foo"]

    def test_disable_pip_version_check(self):
        assert translate(
            ["install", "--disable-pip-version-check", "foo"]
        ) == ["install", "foo"]

    def test_strip_with_value(self):
        assert translate(["install", "--timeout", "30", "foo"]) == [
            "install",
            "foo",
        ]

    def test_strip_with_value_eq(self):
        assert translate(["install", "--timeout=30", "foo"]) == ["install", "foo"]


class TestRename:
    def test_no_cache_dir(self):
        assert translate(["install", "--no-cache-dir", "foo"]) == [
            "install",
            "--no-cache",
            "foo",
        ]

    def test_trusted_host_space(self):
        assert translate(["install", "--trusted-host", "pypi.org", "foo"]) == [
            "install",
            "--allow-insecure-host",
            "pypi.org",
            "foo",
        ]

    def test_trusted_host_eq(self):
        assert translate(["install", "--trusted-host=pypi.org", "foo"]) == [
            "install",
            "--allow-insecure-host=pypi.org",
            "foo",
        ]

    def test_platform(self):
        assert translate(["install", "--platform", "linux_x86_64", "foo"]) == [
            "install",
            "--python-platform",
            "linux_x86_64",
            "foo",
        ]

    def test_no_color_splits(self):
        assert translate(["--no-color", "list"]) == ["--color", "never", "list"]


class TestPackageListFlags:
    def test_no_binary_all(self):
        assert translate(["install", "--no-binary", ":all:", "foo"]) == [
            "install",
            "--no-binary",
            "foo",
        ]

    def test_no_binary_none(self):
        assert translate(["install", "--no-binary", ":none:", "foo"]) == [
            "install",
            "foo",
        ]

    def test_no_binary_list(self):
        assert translate(["install", "--no-binary", "foo,bar", "baz"]) == [
            "install",
            "--no-binary-package",
            "foo",
            "--no-binary-package",
            "bar",
            "baz",
        ]

    def test_no_binary_eq(self):
        assert translate(["install", "--no-binary=foo", "baz"]) == [
            "install",
            "--no-binary-package",
            "foo",
            "baz",
        ]

    def test_only_binary_all(self):
        assert translate(["install", "--only-binary", ":all:", "foo"]) == [
            "install",
            "--only-binary",
            "foo",
        ]


class TestErrorFlags:
    def test_user_errors(self):
        with pytest.raises(SystemExit) as exc:
            translate(["install", "--user", "foo"])
        assert exc.value.code == 2

    def test_ignore_installed_errors(self):
        with pytest.raises(SystemExit):
            translate(["install", "--ignore-installed", "foo"])

    def test_short_I_errors(self):
        with pytest.raises(SystemExit):
            translate(["install", "-I", "foo"])


class TestShortClusters:
    def test_Uv(self):
        assert translate(["-Uv", "install", "foo"]) == [
            "-U",
            "-v",
            "install",
            "foo",
        ]

    def test_vv(self):
        assert translate(["-vv", "install", "foo"]) == [
            "-v",
            "-v",
            "install",
            "foo",
        ]

    def test_value_taking_not_expanded(self):
        # -ri would mean `-r -i` but `-i` takes a value; leave the cluster alone.
        assert translate(["-ri", "reqs.txt", "install"]) == [
            "-ri",
            "reqs.txt",
            "install",
        ]


class TestPassthroughFlags:
    """Flags uv pip accepts identically — must not be mutated."""

    @pytest.mark.parametrize(
        "flag",
        [
            "--no-deps",
            "--dry-run",
            "--pre",
            "--force-reinstall",
            "--require-hashes",
            "--no-build-isolation",
            "--break-system-packages",
            "--no-index",
            "-U",
            "--upgrade",
            "-v",
            "-q",
        ],
    )
    def test_flag_passes_through(self, flag):
        assert translate(["install", flag, "foo"]) == ["install", flag, "foo"]

    def test_config_settings(self):
        assert translate(
            ["install", "-C", "editable_mode=compat", "-e", "./pkg"]
        ) == ["install", "-C", "editable_mode=compat", "-e", "./pkg"]

    def test_requirements_file(self):
        assert translate(["install", "-r", "requirements.txt"]) == [
            "install",
            "-r",
            "requirements.txt",
        ]

    def test_constraint_file(self):
        assert translate(["install", "-c", "constraints.txt", "foo"]) == [
            "install",
            "-c",
            "constraints.txt",
            "foo",
        ]

    def test_index_url(self):
        assert translate(
            ["install", "--index-url", "https://pypi.example.com", "foo"]
        ) == ["install", "--index-url", "https://pypi.example.com", "foo"]
