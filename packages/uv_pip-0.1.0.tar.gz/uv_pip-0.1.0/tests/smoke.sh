#!/usr/bin/env bash
# End-to-end smoke test: exercise the installed `pip` shim against a real venv.
# Verifies version-specifier strings, extras, VCS URLs, and requirements files
# survive shell quoting + shim translation untouched.
set -euo pipefail

HERE="$(cd "$(dirname "$0")/.." && pwd)"
VENV="$HERE/.venv-smoke"
PIP="$VENV/bin/pip"

cleanup() { rm -rf "$VENV" /tmp/uv-pip-reqs.txt; }
trap cleanup EXIT

echo "=== setup ==="
uv venv "$VENV" --quiet
uv pip install -e "$HERE" --python "$VENV/bin/python" --quiet

echo "=== --version ==="
"$PIP" --version

echo "=== install requests>=2.28,<3.0 ==="
"$PIP" install --quiet 'requests>=2.28,<3.0'
"$PIP" show requests | head -2

echo "=== install with extras: requests[socks]>=2.28 ==="
"$PIP" install --quiet 'requests[socks]>=2.28'
"$PIP" show PySocks | head -1

echo "=== install exact: idna==3.11 (downgrade via ==) ==="
"$PIP" install --quiet 'idna==3.11'
"$PIP" show idna | head -2

echo "=== uninstall with -y ==="
"$PIP" uninstall -y requests idna charset-normalizer urllib3 certifi PySocks

echo "=== -r requirements.txt ==="
cat >/tmp/uv-pip-reqs.txt <<'EOF'
six>=1.16
idna>=3,<4
EOF
"$PIP" install --quiet -r /tmp/uv-pip-reqs.txt
"$PIP" list | grep -E '^(six|idna)'

echo "=== --no-cache-dir rename ==="
"$PIP" install --no-cache-dir --dry-run 'charset-normalizer>=3'

echo "=== --dry-run VCS ==="
"$PIP" install --dry-run 'git+https://github.com/psf/requests.git@v2.31.0'

echo "=== --no-color rename ==="
"$PIP" --no-color list >/dev/null

echo "=== error path: --user exits non-zero ==="
if "$PIP" install --user foo 2>/dev/null; then
    echo "FAIL: --user should have errored"
    exit 1
fi

echo "=== error path: pip download exits non-zero ==="
if "$PIP" download foo 2>/dev/null; then
    echo "FAIL: pip download should have errored"
    exit 1
fi

echo
echo "ALL SMOKE TESTS PASSED"
