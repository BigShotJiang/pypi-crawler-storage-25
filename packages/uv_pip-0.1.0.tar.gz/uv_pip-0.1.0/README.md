# uv-pip

Shim that routes `pip` to `uv pip`.

## Install

```bash
uv pip install uv-pip
```

## Use

```bash
pip install requests      # runs `uv pip install requests`
pip list                  # runs `uv pip list`
```

## How it works

`uv-pip` exposes a `pip` console script that `exec`s into `uv pip` with the original arguments. Signals, stdio, and exit codes pass through unchanged.

Requires `uv` on `PATH`.

## Gotchas

- If real `pip` already installed in the same environment, entry-point order decides which wins. Intended for `uv venv` without `--seed`.
- `uv pip` does not implement every flag of stock pip. Tools that parse `pip --version` output may break.
