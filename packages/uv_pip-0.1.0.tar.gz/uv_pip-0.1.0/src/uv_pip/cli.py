import os
import shutil
import sys
from typing import List, Optional

from uv_pip import __version__


ENV_SUBCOMMANDS = {
    "install",
    "uninstall",
    "list",
    "show",
    "freeze",
    "check",
    "sync",
    "tree",
}

SUBCMD_UNSUPPORTED = {
    "download": "`pip download` has no uv equivalent.",
    "wheel": "`pip wheel` has no uv equivalent; try `uv build` for the current project.",
    "hash": "`pip hash` has no uv equivalent.",
    "search": "PyPI XML-RPC search is deprecated; no uv equivalent.",
    "config": "no `uv pip config`; uv config lives in `uv.toml`/`pyproject.toml`.",
    "index": "no `uv pip index` equivalent.",
    "inspect": "no `uv pip inspect` equivalent.",
    "debug": "no `uv pip debug` equivalent.",
    "cache": "use `uv cache` (not under `uv pip`).",
    "completion": "use `uv generate-shell-completion`.",
}

STRIP_NO_VALUE = {
    "-y",
    "--yes",
    "--no-input",
    "--disable-pip-version-check",
    "--require-virtualenv",
    "--debug",
    "--isolated",
    "--compile",
    "--no-warn-script-location",
    "--no-warn-conflicts",
    "--check-build-dependencies",
    "--no-clean",
    "--include-editable",
    "--all",
}

STRIP_WITH_VALUE = {
    "--log",
    "--proxy",
    "--retries",
    "--timeout",
    "--exists-action",
    "--cert",
    "--client-cert",
    "--resume-retries",
    "--progress-bar",
    "--root-user-action",
    "--upgrade-strategy",
}

RENAME = {
    "--trusted-host": "--allow-insecure-host",
    "--no-cache-dir": "--no-cache",
    "--uploaded-prior-to": "--exclude-newer",
    "--platform": "--python-platform",
    "--no-compile": "--no-compile-bytecode",
}

RENAME_SPLIT = {
    "--no-color": ["--color", "never"],
}

ERROR_FLAGS = {
    "--use-feature": "pip `--use-feature` is not supported by uv.",
    "--use-deprecated": "pip `--use-deprecated` is not supported by uv.",
    "--user": "uv has no `--user`; use a venv or `--prefix`.",
    "--root": "pip `--root` is not supported by uv.",
    "--src": "pip `--src` is not supported by uv.",
    "--implementation": "pip `--implementation` is not supported by uv.",
    "--abi": "pip `--abi` is not supported by uv.",
    "--build-constraint": "pip `--build-constraint` is not supported by uv.",
    "--requirements-from-script": "use `uv run --script` instead.",
    "-I": "pip `-I/--ignore-installed` is not supported; try `--reinstall`.",
    "--ignore-installed": "pip `--ignore-installed` is not supported; try `--reinstall`.",
    "--ignore-requires-python": "pip `--ignore-requires-python` is not supported by uv.",
    "--global-option": "pip `--global-option` is deprecated and not supported.",
    "--report": "pip `--report` is not supported by uv.",
    "--group": "use `uv sync --group` instead.",
    "--all-releases": "pip `--all-releases` is not supported by uv.",
    "--only-final": "pip `--only-final` is not supported by uv.",
    "--prefer-binary": "pip `--prefer-binary` is not supported by uv.",
}

# pip `--no-binary`/`--only-binary` accept `:all:` / `:none:` / `pkg1,pkg2`.
PACKAGE_LIST_FLAGS = {
    "--no-binary": ("--no-binary", "--no-binary-package"),
    "--only-binary": ("--only-binary", "--only-binary-package"),
}

SHORT_NO_VALUE = set("UIvqyoulh")

_ALL_KNOWN_SUBCMDS = ENV_SUBCOMMANDS | SUBCMD_UNSUPPORTED.keys() | {"compile"}


def _die(msg: str, code: int = 2) -> None:
    sys.stderr.write(f"uv-pip: {msg}\n")
    sys.exit(code)


def _print_version() -> None:
    py = (
        f"{sys.version_info.major}."
        f"{sys.version_info.minor}."
        f"{sys.version_info.micro}"
    )
    here = os.path.dirname(os.path.abspath(__file__))
    print(
        f"uv-pip {__version__} from {here} "
        f"(python {py}) [wraps uv pip]"
    )
    sys.exit(0)


def _key(tok: str) -> str:
    if tok.startswith("--") and "=" in tok:
        return tok.split("=", 1)[0]
    return tok


def _expand_short_clusters(args: List[str]) -> List[str]:
    out: List[str] = []
    for tok in args:
        if (
            len(tok) > 2
            and tok.startswith("-")
            and not tok.startswith("--")
            and all(c in SHORT_NO_VALUE for c in tok[1:])
        ):
            out.extend(f"-{c}" for c in tok[1:])
        else:
            out.append(tok)
    return out


def _subcmd_index(args: List[str]) -> Optional[int]:
    for i, a in enumerate(args):
        if a in _ALL_KNOWN_SUBCMDS:
            return i
    return None


def _handle_package_list(
    args: List[str], i: int, raw: str, key: str, has_eq: bool
):
    flat, pkg_flag = PACKAGE_LIST_FLAGS[key]
    if has_eq:
        val = raw.split("=", 1)[1]
        i += 1
    else:
        if i + 1 >= len(args):
            _die(f"{key} requires a value")
        val = args[i + 1]
        i += 2
    tokens: List[str] = []
    if val == ":all:":
        tokens.append(flat)
    elif val == ":none:":
        pass
    else:
        for p in val.split(","):
            p = p.strip()
            if p:
                tokens.extend([pkg_flag, p])
    return tokens, i


def translate(args: List[str]) -> List[str]:
    args = _expand_short_clusters(args)
    out: List[str] = []
    i = 0
    while i < len(args):
        raw = args[i]
        key = _key(raw)
        has_eq = raw.startswith("--") and "=" in raw

        if key in ERROR_FLAGS:
            _die(ERROR_FLAGS[key])

        if key in PACKAGE_LIST_FLAGS:
            tokens, i = _handle_package_list(args, i, raw, key, has_eq)
            out.extend(tokens)
            continue

        if key in STRIP_NO_VALUE:
            i += 1
            continue

        if key in STRIP_WITH_VALUE:
            i += 1
            if not has_eq and i < len(args):
                i += 1
            continue

        if key in RENAME_SPLIT:
            out.extend(RENAME_SPLIT[key])
            i += 1
            continue

        if key in RENAME:
            if has_eq:
                out.append(raw.replace(key, RENAME[key], 1))
            else:
                out.append(RENAME[key])
            i += 1
            continue

        out.append(raw)
        i += 1
    return out


def main() -> None:
    uv = shutil.which("uv")
    if uv is None:
        _die(
            "`uv` not found on PATH. Install from https://github.com/astral-sh/uv",
            127,
        )

    args = sys.argv[1:]

    if any(a in ("-V", "--version") for a in args):
        _print_version()

    idx = _subcmd_index(args)
    subcmd = args[idx] if idx is not None else None

    if subcmd in SUBCMD_UNSUPPORTED:
        _die(SUBCMD_UNSUPPORTED[subcmd])

    translated = translate(args)

    idx = _subcmd_index(translated)
    user_set_python = any(
        a == "--python" or a.startswith("--python=") for a in translated
    )
    if subcmd in ENV_SUBCOMMANDS and idx is not None and not user_set_python:
        translated = [
            *translated[: idx + 1],
            "--python",
            sys.executable,
            *translated[idx + 1 :],
        ]

    os.execv(uv, [uv, "pip", *translated])


if __name__ == "__main__":
    main()
