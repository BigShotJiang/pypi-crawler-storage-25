"""Application entry point for the WebUI/OpenLineage backend."""

import logging
import os
import sys
from contextlib import asynccontextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

import logfire
import yaml
from agent.api import shutdown_event
from agent.api.profiles import (
    ApiCapability,
    ApiProfile,
    resolve_api_profile_config_from_env,
)
from agent.api.runtime_adapters import ApiRuntimeAdapters
from core.backends.blobs import BlobStorage, create_blob_storage
from core.backends.config import DataConfig, GitConfig, UnifiedConfig
from core.backends.data_query import DataQueryBackend
from core.backends.data_query.factory import create_data_backend_for_cli
from core.backends.lineage import LineageStorage
from core.backends.lineage.factory import create_storage_for_cli
from core.backends.memory import MemoryStorage
from core.backends.memory.factory import create_memory_backend
from core.backends.reports import ReportsBackend
from core.backends.reports.factory import create_reports_backend
from core.backends.threads import ThreadsBackend, create_threads_backend
from core.backends.tickets import TicketStorage
from core.backends.tickets.factory import create_ticket_backend_from_config
from core.backends.unified_graph.surreal.reader import SurrealUnifiedGraphReader
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from ingest.openlineage.loader import NamespaceResolver, OpenLineageLoader
from lineage.utils.env import load_env_file
from pydantic import ValidationError

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger(__name__)
_API_PROFILE = resolve_api_profile_config_from_env()
_HAS_DESKTOP_API = _API_PROFILE.has(ApiCapability.DESKTOP_ROUTES) and _API_PROFILE.has(
    ApiCapability.UNIFIED_GRAPH
)
_HAS_LEGACY_API = _API_PROFILE.has(
    ApiCapability.LEGACY_AGENT_ROUTES
) and _API_PROFILE.has(ApiCapability.OPENLINEAGE_INGEST)


def _legacy_state_from_request(request: Request) -> Any | None:
    return getattr(request.app.state, "app_state", None)


def _unified_reader_from_request(request: Request) -> Any | None:
    state = _legacy_state_from_request(request)
    if state is not None and getattr(state, "unified_reader", None) is not None:
        return state.unified_reader
    return getattr(request.app.state, "standalone_unified_reader", None)


_RUNTIME_ADAPTERS = ApiRuntimeAdapters(
    legacy_state_provider=_legacy_state_from_request,
    unified_reader_provider=_unified_reader_from_request,
)


# ============================================================================
# User Context Models
# ============================================================================


@dataclass
class UserContext:
    """User context extracted from request headers.

    This provides proper type safety for user identity across the application.
    """

    user_id: str
    org_id: str


def get_user_context(request: Request) -> UserContext:
    """FastAPI dependency to extract user context from request.

    This properly typed dependency replaces getattr() calls.

    Returns:
        UserContext with user_id and org_id

    Note:
        Values are set by the extract_user_context middleware.
    """
    return UserContext(
        user_id=request.state.user_id,
        org_id=request.state.org_id,
    )


# ============================================================================
# Application State
# ============================================================================


@dataclass
class AppState:
    """Application-wide state container.

    Encapsulates all application state including backends, orchestrators,
    and configuration. This provides type-safe access to state and eliminates
    global variables.

    Stored in app.state.app_state and accessed via dependency injection.
    """

    # Configuration
    config: UnifiedConfig
    data_config: DataConfig

    # Loaders
    openlineage_loader: OpenLineageLoader

    # Backends
    lineage: LineageStorage
    data_backend: DataQueryBackend
    memory_backend: Optional[MemoryStorage] = None
    ticket_storage: Optional[TicketStorage] = None  # Analyst role
    de_ticket_storage: Optional[TicketStorage] = (
        None  # Data Engineer role (for daemon/investigator/reconciler)
    )
    reports_backend: Optional[ReportsBackend] = None
    threads_backend: Optional[ThreadsBackend] = None
    git_config: Optional[GitConfig] = None  # Per-project git configuration
    blob_storage: Optional[BlobStorage] = None
    ontology_db: Any | None = None
    ontology_reader: Any | None = None
    unified_reader: Optional[SurrealUnifiedGraphReader] = None


# ============================================================================
# Middleware for Request Logging and User Context Extraction
# ============================================================================


@asynccontextmanager
async def lifespan(app: FastAPI):
    """FastAPI lifespan context manager for startup and shutdown.

    This replaces the deprecated @app.on_event("startup") and @app.on_event("shutdown")
    patterns with the modern lifespan approach.

    Yields control to the application after initialization, then performs cleanup
    on shutdown.
    """
    shutdown_event.clear()

    # Configure logfire once at startup (before importing orchestrator which uses it)
    # This ensures span context propagates correctly through asyncio.
    # Logfire is active on first launch (no prefs file = not opted out).
    # If user opts out via the consent modal or Settings, takes effect on next launch.
    from lineage.api.desktop_setup import _read_telemetry_prefs

    logfire_token = os.getenv("LOGFIRE_TOKEN")
    if logfire_token and not _read_telemetry_prefs().get("telemetry_opted_out"):
        logfire.configure(token=logfire_token, console=False)

    # Startup: initialize legacy state only when legacy capabilities are enabled.
    if _HAS_LEGACY_API:
        try:
            state = initialize_app_state()
        except Exception as exc:
            logger.error("Failed to initialize app state: %s", exc)
            # Create a minimal state so health endpoints can report failure.
            state = None
    elif _API_PROFILE.profile == ApiProfile.DESKTOP:
        logger.info("Starting in desktop API profile mode")
        state = None
    else:
        logger.warning(
            "No API capabilities enabled for profile=%s", _API_PROFILE.profile
        )
        state = None
    app.state.app_state = state

    # Initialize desktop capabilities (unified config + graph reader).
    if _HAS_DESKTOP_API:
        # Load UnifiedConfig so model tiers resolve even without full AppState.
        if state is None:
            app.state.unified_config = _load_unified_config()
        if state is not None and state.unified_reader is None:
            state.unified_reader = _initialize_unified_reader()
        elif state is None:
            # No AppState at all — stash the reader directly so the dependency
            # override can find it via getattr(app.state, ...).
            app.state.standalone_unified_reader = _initialize_unified_reader()

            # Initialize threads backend so desktop harness/session state can
            # persist plans and other cross-run metadata even without AppState.
            _ucfg_for_threads = getattr(app.state, "unified_config", None)
            if _ucfg_for_threads is not None:
                try:
                    app.state.standalone_threads_backend = create_threads_backend(
                        _ucfg_for_threads.threads
                    )
                    logger.info(
                        "Initialized standalone threads backend: %s",
                        _ucfg_for_threads.threads.db_path,
                    )
                except Exception as exc:
                    logger.warning(
                        "Could not initialize threads backend for desktop: %s", exc
                    )
                    app.state.standalone_threads_backend = None

            # Initialize data backend (DuckDB/Snowflake) for desktop agents
            # so the analyst can execute SQL queries and produce charts.
            _ucfg_for_data = getattr(app.state, "unified_config", None)
            if _ucfg_for_data is not None:
                try:
                    _data_cfg = _ucfg_for_data.get_project_data_config(
                        _ucfg_for_data.default_project
                    )
                    app.state.standalone_data_backend = create_data_backend_for_cli(
                        _data_cfg, read_only=True
                    )
                    logger.info(
                        "Initialized standalone data backend: %s", _data_cfg.backend
                    )
                except Exception as exc:
                    logger.warning(
                        "Could not initialize data backend for desktop: %s", exc
                    )
                    app.state.standalone_data_backend = None

            # Initialize filesystem reports backend so the presentation
            # toolset (create_report, add_chart_cell, etc.) is available.
            from core.backends.reports.filesystem import FilesystemReportsBackend
            from core.paths import typedef_home as _get_typedef_home

            _reports_dir = os.path.join(str(_get_typedef_home()), "reports")
            app.state.standalone_reports_backend = FilesystemReportsBackend(
                _reports_dir
            )
            logger.info("Initialized standalone reports backend: %s", _reports_dir)

        # Auto-switch to default project's graph database on startup
        reader = (state.unified_reader if state else None) or getattr(
            app.state, "standalone_unified_reader", None
        )
        if reader:
            try:
                # Prefer the already-parsed UnifiedConfig from app.state when available;
                # otherwise, use the config attached to the legacy AppState (if present).
                _ucfg = getattr(app.state, "unified_config", None)
                if _ucfg is None and state is not None:
                    _ucfg = getattr(state, "config", None)
                if _ucfg is not None:
                    _default = _ucfg.default_project
                    if _default and _ucfg.projects and _default in _ucfg.projects:
                        _graph = _ucfg.projects[_default].graph_name
                        reader.switch_project(_graph)
                        logger.info(
                            "Auto-switched to default project graph: %s", _graph
                        )
            except Exception as exc:
                logger.debug("Could not auto-switch project on startup: %s", exc)

    if state:
        logger.info("✅ Application ready to serve requests")
    else:
        if _HAS_DESKTOP_API:
            has_reader = (
                getattr(app.state, "standalone_unified_reader", None) is not None
            )
            if has_reader:
                logger.warning(
                    "⚠️  Legacy backends unavailable — desktop API active (SurrealDB only)"
                )
            else:
                logger.warning("⚠️  Application started with errors — check config")
        else:
            logger.warning("⚠️  Application started with errors — check config")

    # Start Claude Code hook socket listener and shared config (for relay.py → frontend events)
    if _HAS_DESKTOP_API:
        try:
            from agent.api.desktop_claude_hooks import start_listener_background

            await start_listener_background()
        except Exception as exc:
            logger.debug("Could not start Claude hook socket listener: %s", exc)
        try:
            from agent.api.desktop_delegation import ensure_delegation_hooks

            ensure_delegation_hooks()
        except Exception:
            logger.warning("Could not write delegation hooks", exc_info=True)
        try:
            from agent.api.desktop_pty import startup as pty_startup

            await pty_startup()
        except Exception:
            logger.debug("Could not start PTY session manager", exc_info=True)
        try:
            from lineage.api.desktop_worktree import _clone_cache

            _clone_cache.start_periodic_refresh()
        except Exception:
            logger.debug("Could not start clone cache refresh", exc_info=True)

    # Initialize the MCP sub-app's lifespan (required for streamable-http
    # session management). The lifespan must span the entire app runtime.
    _mcp_mounted = getattr(app.state, "_mcp_sub_app", None)
    if _mcp_mounted is not None:
        async with _mcp_mounted.router.lifespan_context(_mcp_mounted):
            yield  # Application runs here
    else:
        yield  # Application runs here

    # Shutdown: signal long-lived SSE generators to exit promptly.
    shutdown_event.set()

    # Shutdown: Cleanup resources
    logger.info("🔄 Shutting down gracefully...")

    # Close standalone data backend (e.g. DuckDB file handle)
    standalone_db = getattr(app.state, "standalone_data_backend", None)
    if standalone_db is not None:
        try:
            standalone_db.close()
            logger.debug("Closed standalone data backend")
        except Exception:
            logger.debug("Failed to close standalone data backend", exc_info=True)

    # TD-2562: checkpoint + close the threads backend so the WAL is
    # flushed back into the main .db file before Tauri SIGKILLs us.
    # Both the standalone (desktop) and app-state (server) paths can
    # hold a threads backend; close whichever is set.
    for attr in ("standalone_threads_backend", "threads_backend"):
        threads_be = getattr(app.state, attr, None)
        if threads_be is not None and hasattr(threads_be, "close"):
            try:
                threads_be.close()
                logger.debug("Closed threads backend (%s)", attr)
            except Exception:
                logger.debug(
                    "Failed to close threads backend (%s)", attr, exc_info=True
                )

    # Stop Claude hook socket listener and PTY sessions
    if _HAS_DESKTOP_API:
        try:
            from agent.api.desktop_claude_hooks import stop_listener

            await stop_listener()
        except Exception:
            logger.debug("Failed to stop Claude hook listener", exc_info=True)
        try:
            from agent.api.desktop_pty import shutdown as pty_shutdown

            await pty_shutdown()
        except Exception:
            logger.debug("Failed to clean up PTY sessions", exc_info=True)
        try:
            import asyncio

            from lineage.api.desktop_worktree import _clone_cache

            task = _clone_cache.stop_periodic_refresh()
            if task is not None:
                try:
                    await task
                except asyncio.CancelledError:
                    pass
        except Exception:
            logger.debug("Failed to stop clone cache refresh", exc_info=True)

    logger.info("✅ Shutdown complete")


def get_app_state(request: Request) -> AppState:
    """FastAPI dependency to get application state.

    Provides type-safe access to all application state including backends
    and orchestrators.

    Args:
        request: FastAPI request object

    Returns:
        AppState with all initialized backends and orchestrators

    Example:
        ```python
        @app.post("/agents/analyst")
        async def run_analyst(state: !State = Depends(get_app_state)):
            return await handle_request(state.analyst_orchestrator, ...)
        ```
    """
    state = _RUNTIME_ADAPTERS.legacy_state_provider(request)
    if state is None:
        profile = _API_PROFILE.profile
        raise HTTPException(
            status_code=503,
            detail=(
                "Legacy API backends are unavailable in current profile "
                f"(TYPEDEF_API_PROFILE={profile}). Use desktop endpoints or run with legacy profile."
            ),
        )
    return state


# ============================================================================
# State Initialization
# ============================================================================


def initialize_app_state() -> AppState:
    """Initialize all application state including backends and orchestrators.

    This function loads configuration, initializes all backends (lineage, data,
    memory, ticket), and creates all orchestrators with their dependencies.

    Returns:
        Fully initialized AppState

    Raises:
        SystemExit: If configuration is invalid or required backends fail to initialize
    """
    load_env_file()
    logger.info(
        "🚀 Starting PydanticAI Native Backend (Simplified 2-Level Architecture)"
    )
    logger.info("=" * 60)

    # Load unified config from environment
    config_path_str = os.getenv("UNIFIED_CONFIG")
    if not config_path_str:
        from core.paths import config_path as _core_config_path

        typedef_config = _core_config_path()
        if typedef_config.exists():
            config_path_str = str(typedef_config)
            logger.info("Using config at %s", typedef_config)
        else:
            logger.error("UNIFIED_CONFIG not set and no config found")
            raise RuntimeError(
                "UNIFIED_CONFIG environment variable not set. "
                "Set it to the path of your config.yml file."
            )

    config_path = Path(config_path_str)
    if not config_path.exists():
        raise RuntimeError(f"Config file not found: {config_path}")

    logger.info(f"📄 Loading config from: {config_path}")

    # Backfill missing top-level sections (desktop configs created before
    # the backend sections were added during create-project)
    try:
        import yaml as _yaml_migrate

        _raw = _yaml_migrate.safe_load(config_path.read_text()) or {}
        _dirty = False
        from core.paths import default_surreal_url

        surreal_url = os.getenv("SURREAL_URL", default_surreal_url())
        if "lineage" not in _raw:
            _raw["lineage"] = {
                "backend": "surrealdb",
                "url": surreal_url,
                "namespace": "lineage",
            }
            _dirty = True
        if _dirty:
            logger.info("Backfilling missing config section: lineage")
            tmp = config_path.with_suffix(".yaml.tmp")
            tmp.write_text(
                _yaml_migrate.dump(_raw, default_flow_style=False, sort_keys=False)
            )
            os.replace(str(tmp), str(config_path))
    except Exception as exc:
        logger.warning("Config backfill failed (non-fatal): %s", exc)

    try:
        cfg = UnifiedConfig.from_yaml(config_path)
    except (ValueError, FileNotFoundError) as e:
        raise RuntimeError(f"Failed to load config: {e}") from e

    logger.info(f"✅ Lineage backend: {cfg.lineage.backend}")
    logger.info(f"✅ Model tiers: {list(cfg.models.keys())}")

    # Check for active project/graph
    graph_name = os.getenv("TYPEDEF_GRAPH_NAME")
    if graph_name:
        logger.info(f"📁 Active project graph: {graph_name}")

    # Initialize lineage backend
    lineage = create_storage_for_cli(cfg.lineage, read_only=True)
    lineage_writeable = create_storage_for_cli(cfg.lineage, read_only=False)

    # Set active graph if specified
    if graph_name:
        lineage.set_active_graph(graph_name)
        lineage_writeable.set_active_graph(graph_name)

    # Initialize data backend from project config
    active_project = os.getenv("TYPEDEF_ACTIVE_PROJECT") or cfg.default_project
    try:
        data_config = cfg.get_project_data_config(active_project)
    except ValueError as exc:
        raise RuntimeError(
            "No data backend configuration found. "
            "Check your config.yml projects section."
        ) from exc
    logger.info(f"✅ Data backend: {data_config.backend}")
    data_backend = create_data_backend_for_cli(data_config, read_only=True)

    # Get per-project git config if active project specified
    git_config = None
    if active_project and cfg.projects and active_project in cfg.projects:
        git_config = cfg.get_project_git_config(active_project)
        if git_config and git_config.enabled:
            logger.info(f"📁 Git configuration loaded for project: {active_project}")

    # Initialize memory backend (optional)
    memory_backend: Optional[MemoryStorage] = None
    if cfg.memory and cfg.memory.enabled:
        logger.info(f"📝 Initializing memory backend: {cfg.memory.backend}")
        memory_backend = create_memory_backend(cfg.memory)
        if memory_backend:
            logger.info("✅ Memory backend initialized")
        else:
            logger.warning(
                "⚠️  Memory backend initialization failed (graceful degradation)"
            )
    else:
        logger.info("ℹ️  Memory backend disabled (add memory config section to enable)")

    # Initialize ticket storage (optional)
    # Create separate ticket storages for analyst and data engineer roles
    # This allows proper attribution when adding comments/updates to Linear tickets
    ticket_storage: Optional[TicketStorage] = None
    de_ticket_storage: Optional[TicketStorage] = None
    if cfg.ticket.enabled:
        logger.info(f"🎫 Initializing ticket storage: {cfg.ticket.backend}")
        # Analyst ticket storage (for analyst agent)
        ticket_storage = create_ticket_backend_from_config(
            config=cfg.ticket,
            role="analyst",
        )
        if ticket_storage:
            logger.info("✅ Analyst Ticket storage initialized")
        else:
            logger.warning(
                "⚠️  Analyst Ticket storage initialization failed (graceful degradation)"
            )

        # Data Engineer ticket storage (for investigator/reconciler/copilot/daemon agents)
        de_ticket_storage = create_ticket_backend_from_config(
            config=cfg.ticket,
            role="data_engineer",
        )
        if de_ticket_storage:
            logger.info("✅ Data Engineer Ticket storage initialized")
        else:
            logger.warning(
                "⚠️  Data Engineer Ticket storage initialization failed (graceful degradation)"
            )
    else:
        logger.info("ℹ️  Ticket storage disabled (set ticket.enabled=true to enable)")

    # Initialize reports backend (always enabled)
    logger.info("📊 Initializing reports backend")
    reports_backend = create_reports_backend(cfg.reports)
    if reports_backend:
        logger.info("✅ Reports backend initialized (path=./reports)")
    else:
        logger.warning(
            "⚠️  Reports backend initialization failed (graceful degradation)"
        )

    # Initialize threads backend for conversation memory
    logger.info("🧵 Initializing threads backend")
    threads_backend = None
    if cfg.threads.enabled:
        threads_backend = create_threads_backend(cfg.threads)
        if threads_backend:
            logger.info(f"✅ Threads backend initialized (cfg={cfg.threads})")
        else:
            logger.warning(
                "⚠️  Threads backend initialization failed (graceful degradation)"
            )
    else:
        logger.info("ℹ️  Threads backend disabled")

    # Initialize blob storage for query result persistence
    logger.info("📦 Initializing blob storage")
    blob_storage = None
    if cfg.blobs.enabled:
        blob_storage = create_blob_storage(cfg.blobs)
        if blob_storage:
            logger.info(f"✅ Blob storage initialized (db_path={cfg.blobs.db_path})")
        else:
            logger.warning(
                "⚠️  Blob storage initialization failed (graceful degradation)"
            )
    else:
        logger.info("ℹ️  Blob storage disabled")

    logger.info("")
    logger.info("=" * 60)
    logger.info("Endpoints:")
    logger.info("  - POST /api/v1/lineage     → OpenLineage Collector")
    logger.info("  - POST /agents/analyst     → Analyst (metadata, data, reports)")
    logger.info("  - POST /agents/quality     → Data Quality (troubleshooting)")
    logger.info("  - POST /agents/engineer    → Data Engineering (dbt, SQL)")
    logger.info("  - GET  /health             → Health check")
    logger.info("  - GET  /reports            → List saved reports")
    logger.info("  - GET  /reports/{report_id}         → View report by ID")
    logger.info("  - GET  /reports/{report_id}/export  → Download HTML export")
    logger.info("=" * 60)

    # Create and return app state
    return AppState(
        config=cfg,
        data_config=data_config,
        lineage=lineage,
        data_backend=data_backend,
        memory_backend=memory_backend,
        ticket_storage=ticket_storage,
        de_ticket_storage=de_ticket_storage,
        reports_backend=reports_backend,
        threads_backend=threads_backend,
        git_config=git_config,
        blob_storage=blob_storage,
        openlineage_loader=OpenLineageLoader(
            storage=lineage_writeable, resolver=NamespaceResolver()
        ),
        **_initialize_ontology_reader(),
        unified_reader=_initialize_unified_reader() if _HAS_DESKTOP_API else None,
    )


def _load_unified_config() -> UnifiedConfig:
    """Load UnifiedConfig for desktop profile mode.

    Tries the standard config paths (TYPEDEF_HOME/config.yaml via
    core.paths.config_path(), then UNIFIED_CONFIG env as fallback).
    Falls back to a minimal default config with SurrealDB lineage so that
    model tiers (haiku/sonnet/opus) resolve via the default_factory.
    """
    from core.paths import config_path as _core_config_path
    from core.paths import default_surreal_url

    # User's home config is the source of truth (has projects, default_project).
    # UNIFIED_CONFIG (set by --config flag) is a fallback for model tiers / defaults.
    # NOTE: This intentionally reverses the priority used by initialize_app_state(),
    # which checks UNIFIED_CONFIG first. In desktop mode, user config wins because
    # it contains project definitions and customized model tiers.
    candidate_paths = [_core_config_path()]
    config_path_str = os.getenv("UNIFIED_CONFIG")
    if config_path_str:
        candidate_paths.append(Path(config_path_str))

    for cfg_path in candidate_paths:
        try:
            cfg = UnifiedConfig.from_yaml(cfg_path)
            logger.info(
                "Loaded UnifiedConfig from %s (models: %s)",
                cfg_path,
                list(cfg.models.keys()),
            )
            return cfg
        except FileNotFoundError:
            continue
        except (yaml.YAMLError, ValidationError) as exc:
            logger.error("Config at %s is invalid: %s", cfg_path, exc)
        except Exception as exc:
            logger.warning("Failed to load config from %s: %s", cfg_path, exc)

    # No config file found — create minimal defaults so model tiers resolve.
    from core.backends.config import SurrealDBLineageConfig

    logger.info(
        "No config file found; using default UnifiedConfig with SurrealDB lineage"
    )
    return UnifiedConfig(
        lineage=SurrealDBLineageConfig(url=default_surreal_url()),
    )




def _initialize_unified_reader() -> SurrealUnifiedGraphReader | None:
    """Initialize the optional SurrealDB unified graph reader for the desktop API.

    Returns an initialized SurrealUnifiedGraphReader or None if SurrealDB
    is not configured.
    """
    try:
        reader = SurrealUnifiedGraphReader()
        logger.info("Unified graph reader initialized for desktop API")
        return reader
    except Exception as exc:
        logger.warning("Failed to initialize unified graph reader: %s", exc)
        return None


def _initialize_ontology_reader() -> dict[str, Any]:
    """Initialize the optional ontology reader backed by SurrealDB.

    Returns kwargs for AppState (ontology_db, ontology_reader).
    """
    ontology_path = os.getenv(
        "TYPEDEF_ONTOLOGY_DB_PATH", "surrealkv:///tmp/unified.surrealkv"
    )
    ontology_namespace = os.getenv("TYPEDEF_ONTOLOGY_NAMESPACE", "lineage")
    ontology_database = os.getenv("TYPEDEF_ONTOLOGY_DATABASE", "unified")

    if ontology_path.startswith("surrealkv://"):
        db_path = ontology_path.replace("surrealkv://", "", 1)
        if not Path(db_path).exists():
            logger.info(
                "Ontology store not found at %s; ontology API disabled", ontology_path
            )
            return {}

    try:
        from type_inference.adapters.ontology_store import OntologyGraphReader
    except Exception as exc:
        logger.warning("Failed to import ontology reader dependencies: %s", exc)
        return {}

    try:
        from core.backends.unified_graph.surreal.load import connect as _surreal_connect

        db = _surreal_connect(
            url=ontology_path,
            namespace=ontology_namespace,
            database=ontology_database,
        )
        reader = OntologyGraphReader(db)
        logger.info(
            "Ontology reader initialized (%s/%s)", ontology_namespace, ontology_database
        )
        return {"ontology_db": db, "ontology_reader": reader}
    except Exception as exc:
        logger.warning("Failed to initialize ontology reader: %s", exc)
        return {}


# ============================================================================
# FastAPI Application
# ============================================================================

app = FastAPI(title="Lineage WebUI - PydanticAI Native Backend", lifespan=lifespan)

# CORS for frontend (webui + Tauri desktop app)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://localhost:5173",
        "tauri://localhost",
        "https://tauri.localhost",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def log_requests(request: Request, call_next):
    """Log all incoming requests for debugging."""
    logger.info(f"→ {request.method} {request.url.path}")
    response = await call_next(request)
    logger.info(f"← {request.method} {request.url.path} - {response.status_code}")
    return response


@app.middleware("http")
async def extract_user_context(request: Request, call_next):
    """Extract user and organization context from HTTP headers.

    Looks for:
    - X-User-Id: Unique user identifier
    - X-Org-Id: Organization identifier

    For testing/development, defaults to:
    - user_id: "test_user@example.com"
    - org_id: "test_org"

    Override by setting headers from frontend or environment variables:
    - DEFAULT_USER_ID: Default user ID if header not present
    - DEFAULT_ORG_ID: Default org ID if header not present

    Stores context in request.state for use in agent endpoints.
    """
    # Use environment variables for defaults (useful for different test setups)
    default_user_id = os.getenv("DEFAULT_USER_ID", "test_user@example.com")
    default_org_id = os.getenv("DEFAULT_ORG_ID", "test_org")

    # Extract from headers, fall back to defaults
    user_id = request.headers.get("X-User-Id", default_user_id)
    org_id = request.headers.get("X-Org-Id", default_org_id)

    # Store in request state
    request.state.user_id = user_id
    request.state.org_id = org_id

    # Log user context for debugging
    logger.info(f"  User context: user_id={user_id}, org_id={org_id}")

    return await call_next(request)


# Late imports — placed after app + middleware setup.
if _HAS_DESKTOP_API:
    from agent.api.desktop import (
        get_graph_availability as _desktop_availability_dep,  # noqa: E402
    )
    from agent.api.desktop import router as desktop_router  # noqa: E402
    from agent.api.desktop_claude_hooks import (
        router as desktop_claude_hooks_router,  # noqa: E402
    )
    from agent.api.desktop_delegation import (
        router as desktop_delegation_router,  # noqa: E402
    )
    from agent.api.desktop_pty import router as desktop_pty_router  # noqa: E402
    from lineage.api.desktop_agents import router as desktop_agents_router  # noqa: E402
    from lineage.api.desktop_projects import (
        router as desktop_projects_router,  # noqa: E402
    )
    from lineage.api.desktop_quickstart import (
        router as desktop_quickstart_router,  # noqa: E402
    )
    from lineage.api.desktop_setup import (
        credentials_router as desktop_credentials_router,  # noqa: E402
    )
    from lineage.api.desktop_setup import router as desktop_setup_router  # noqa: E402
    from lineage.api.desktop_sync import (
        debug_router as desktop_debug_router,  # noqa: E402
    )
    from lineage.api.desktop_sync import router as desktop_sync_router  # noqa: E402
    from lineage.api.desktop_worktree import (
        router as desktop_worktree_router,  # noqa: E402
    )

    app.include_router(desktop_router)
    app.include_router(desktop_agents_router)
    app.include_router(desktop_claude_hooks_router)
    app.include_router(desktop_delegation_router)
    app.include_router(desktop_pty_router)
    app.include_router(desktop_worktree_router)
    app.include_router(desktop_setup_router)
    app.include_router(desktop_credentials_router)
    app.include_router(desktop_projects_router)
    app.include_router(desktop_quickstart_router)
    app.include_router(desktop_sync_router)
    app.include_router(desktop_debug_router)

    # Mount desktop-graph MCP server at /mcp/ via streamable-http transport.
    # When running inside the desktop app, the sidecar is always available —
    # set SURREAL_URL to skip the probe (Decision 2B).
    _mcp_sub_app = None
    try:
        sidecar_url = os.environ.get("SURREAL_SIDECAR_URL", "ws://127.0.0.1:3567")
        os.environ.setdefault("SURREAL_URL", sidecar_url)
        from lineage.devtools.unified_graph.surreal.desktop_mcp import (  # noqa: E402
            mcp as desktop_mcp,
        )

        _mcp_sub_app = desktop_mcp.http_app(path="/", transport="streamable-http")
        app.mount("/mcp", _mcp_sub_app)
        app.state._mcp_sub_app = _mcp_sub_app
        logger.info("Mounted desktop-graph MCP server at /mcp/")
    except Exception:
        logger.debug("Could not mount MCP server", exc_info=True)


# Legacy API modules register routes directly on `app` at import time.
if _HAS_LEGACY_API:
    from lineage.api import collector, ontology, pydantic  # noqa: E402, F401
else:

    @app.get("/health")
    async def desktop_only_health():
        """Lightweight health endpoint for desktop-only mode."""
        has_reader = getattr(
            app.state, "standalone_unified_reader", None
        ) is not None or (
            getattr(app.state, "app_state", None) is not None
            and getattr(app.state.app_state, "unified_reader", None) is not None
        )
        return {
            "status": "healthy" if has_reader else "degraded",
            "profile": _API_PROFILE.profile,
            "desktop_api": "ready" if has_reader else "unavailable",
        }

    @app.get("/health/readiness")
    async def desktop_only_readiness():
        """Readiness endpoint for desktop-only mode."""
        has_reader = getattr(
            app.state, "standalone_unified_reader", None
        ) is not None or (
            getattr(app.state, "app_state", None) is not None
            and getattr(app.state.app_state, "unified_reader", None) is not None
        )
        return {
            "status": "healthy" if has_reader else "degraded",
            "readiness": {
                "unified_graph": has_reader,
            },
            "profile": _API_PROFILE.profile,
        }


if _HAS_DESKTOP_API:

    def _provide_graph_availability(request: Request):
        """Provide a GraphAvailability instance for desktop endpoints.

        This is the sole dependency override — ``get_unified_reader`` is no
        longer overridden directly.  Instead it resolves availability via
        ``Depends(get_graph_availability)`` and the availability checker
        creates a request-scoped reader internally.
        """
        from lineage.api.desktop_context import (
            _get_active_project_name,
            _get_unified_config,
            create_request_scoped_unified_reader,
        )
        from lineage.api.desktop_sync import get_sync_ops
        from lineage.api.graph_availability import SurrealGraphAvailability

        config = _get_unified_config(request)
        project_name = _get_active_project_name(config)

        def reader_factory():
            return create_request_scoped_unified_reader(request)

        return SurrealGraphAvailability(
            reader_factory=reader_factory,
            sync_ops_ref=get_sync_ops,
            project_name=project_name,
        )

    app.dependency_overrides[_desktop_availability_dep] = _provide_graph_availability
