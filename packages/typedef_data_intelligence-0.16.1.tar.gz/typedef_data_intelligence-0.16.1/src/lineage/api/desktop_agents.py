"""Service-local composition for desktop AG-UI agent routes."""

from __future__ import annotations

import logging
from typing import Any

from agent.api.desktop_agents import (
    DesktopAgentRuntimeDeps,
    create_desktop_agents_router,
)
from fastapi import HTTPException, Request
from lineage.api.desktop_context import (
    _get_active_project_name,
    _get_unified_config,
    create_request_scoped_unified_reader,
)


def _resolve_unified_reader(request: Request):
    """Resolve unified reader from app state, supporting standalone mode."""
    try:
        return create_request_scoped_unified_reader(request)
    except HTTPException:
        raise
    except Exception as exc:  # pragma: no cover - environment specific
        raise HTTPException(
            status_code=503,
            detail="Desktop API unavailable — unified graph not configured.",
        ) from exc


def _runtime_provider(request: Request) -> DesktopAgentRuntimeDeps:
    """Build runtime deps for desktop agents from this service's app state."""
    state: Any = getattr(request.app.state, "app_state", None)
    cfg = getattr(state, "config", None) if state is not None else None

    # When running in desktop mode without full AppState, the
    # lifespan handler stashes a standalone UnifiedConfig so model tiers
    # (haiku/sonnet/opus) still resolve from prompt YAML.
    if cfg is None:
        cfg = getattr(request.app.state, "unified_config", None)

    ticket_storage = None
    if state is not None:
        ticket_storage = getattr(state, "de_ticket_storage", None) or getattr(
            state, "ticket_storage", None
        )

    logger = logging.getLogger(__name__)

    # Resolve data backend: prefer AppState, fall back to standalone (desktop profile)
    data_backend = None
    if state is not None:
        data_backend = getattr(state, "data_backend", None)
    if data_backend is None:
        data_backend = getattr(request.app.state, "standalone_data_backend", None)

    if data_backend is not None:
        logger.info("Desktop runtime: data_backend=%s", type(data_backend).__name__)
    else:
        logger.warning("Desktop runtime: no data_backend available — agent will lack SQL tools")

    unified_reader = _resolve_unified_reader(request)

    # Build graph availability checker for sync-aware error messages
    graph_availability = None
    try:
        from lineage.api.desktop_sync import get_sync_ops
        from lineage.api.graph_availability import SurrealGraphAvailability

        config = _get_unified_config(request)
        project_name = _get_active_project_name(config)

        def _reader_factory():
            return unified_reader

        graph_availability = SurrealGraphAvailability(
            reader_factory=_reader_factory,
            sync_ops_ref=get_sync_ops,
            project_name=project_name,
        )
    except Exception:
        logger.debug("Could not create GraphAvailability for agent runtime", exc_info=True)

    return DesktopAgentRuntimeDeps(
        unified_reader=unified_reader,
        graph_availability=graph_availability,
        models=getattr(cfg, "models", None) or {},
        data_backend=data_backend,
        memory_backend=getattr(state, "memory_backend", None)
        if state is not None
        else None,
        ticket_storage=ticket_storage,
        reports_backend=(
            getattr(state, "reports_backend", None)
            if state is not None
            else None
        )
        or getattr(request.app.state, "standalone_reports_backend", None),
        threads_backend=(
            getattr(state, "threads_backend", None)
            if state is not None
            else None
        )
        or getattr(request.app.state, "standalone_threads_backend", None),
        blob_storage=getattr(state, "blob_storage", None)
        if state is not None
        else None,
        user_id=getattr(request.state, "user_id", "desktop_user"),
        org_id=getattr(request.state, "org_id", "desktop_org"),
        harness_config=getattr(cfg, "harness", None) if cfg is not None else None,
    )


router = create_desktop_agents_router(_runtime_provider)
