"""Desktop project setup routes.

Wizard flow endpoints: validate project name, clone repository, discover
sub-projects, test data backend connection, and create project configuration.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import stat
import uuid
from pathlib import Path
from typing import Any, Literal

from agent.api import shutdown_event
from core.paths import (
    config_path,
    default_surreal_url,
    ensure_home,
    env_path,
    profiles_dir,
    projects_dir,
    typedef_home,
)
from fastapi import APIRouter, HTTPException, Request
from ingest.static_loaders.salesforce.factory import SfAuthMode
from pydantic import BaseModel, Field
from starlette.responses import StreamingResponse

logger = logging.getLogger(__name__)


def _sse_event(event_type: str, data: dict) -> str:
    """Format a single SSE event as a string."""
    return f"event: {event_type}\ndata: {json.dumps(data)}\n\n"


router = APIRouter(prefix="/desktop/setup", tags=["desktop-setup"])

# Credential reload router — mounted at /desktop (not /desktop/setup)
# so it matches the path the Rust side calls.
credentials_router = APIRouter(prefix="/desktop", tags=["desktop-credentials"])


# Must stay in sync with SECRET_FIELDS in services/desktop/src-tauri/src/keychain.rs
# and ENV_TO_API_FIELD in services/desktop/src/lib/keychain.ts.
_ALLOWED_CREDENTIAL_KEYS = frozenset(
    {
        "ANTHROPIC_API_KEY",
        "OPENAI_API_KEY",
        "LOGFIRE_TOKEN",
        "LINEAR_ANALYST_API_KEY",
        "LINEAR_DATA_ENGINEER_API_KEY",
        "FIVETRAN_API_KEY",
        "FIVETRAN_API_SECRET",
        "SF_PASSWORD",
        "SF_SECURITY_TOKEN",
        "SF_CLIENT_SECRET",
    }
)


def _require_session_token(req: Request) -> None:
    """Validate the session token on desktop-only endpoints."""
    expected = os.environ.get("TYPEDEF_SESSION_TOKEN")
    if not expected:
        return  # No token configured (e.g. browser-only dev mode)
    auth = req.headers.get("authorization", "")
    if auth != f"Bearer {expected}":
        raise HTTPException(status_code=401, detail="Unauthorized")


@credentials_router.post("/reload-credentials")
async def reload_credentials(req: Request):
    """Hot-reload credentials into os.environ. Called by Tauri after keychain writes."""
    _require_session_token(req)
    body = await req.json()
    if not isinstance(body, dict):
        raise HTTPException(
            status_code=400, detail="Request body must be a JSON object"
        )
    count = 0
    for key, value in body.items():
        if key not in _ALLOWED_CREDENTIAL_KEYS:
            continue
        if value:
            if not isinstance(value, str):
                continue
            os.environ[key] = value
        else:
            os.environ.pop(key, None)
        count += 1
    return {"message": "Credentials reloaded", "count": count}


# ── Telemetry preference helpers ─────────────────────────────────────


def _read_telemetry_prefs() -> dict:
    """Read telemetry preferences from TYPEDEF_HOME/preferences.json."""
    path = typedef_home() / "preferences.json"
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text())
    except (json.JSONDecodeError, OSError):
        return {}
    return data if isinstance(data, dict) else {}


def _write_telemetry_prefs(prefs: dict) -> None:
    """Write telemetry preferences to TYPEDEF_HOME/preferences.json atomically."""
    path = typedef_home() / "preferences.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = path.with_suffix(".json.tmp")
    tmp_path.write_text(json.dumps(prefs, indent=2))
    os.replace(str(tmp_path), str(path))


@credentials_router.get("/telemetry-status")
async def get_telemetry_status(req: Request):
    """Return current telemetry state: active (token present), opted_out, acknowledged."""
    _require_session_token(req)
    prefs = _read_telemetry_prefs()
    return {
        "active": bool(os.getenv("LOGFIRE_TOKEN")),
        "opted_out": prefs.get("telemetry_opted_out", False),
        "acknowledged": prefs.get("telemetry_acknowledged", False),
    }


@credentials_router.post("/telemetry-preference")
async def set_telemetry_preference(req: Request):
    """Update telemetry opt-out and/or acknowledgment preferences."""
    _require_session_token(req)
    body = await req.json()
    if not isinstance(body, dict):
        raise HTTPException(
            status_code=400, detail="Request body must be a JSON object"
        )
    prefs = _read_telemetry_prefs()
    if "opted_out" in body:
        prefs["telemetry_opted_out"] = bool(body["opted_out"])
    if "acknowledged" in body:
        prefs["telemetry_acknowledged"] = bool(body["acknowledged"])
    _write_telemetry_prefs(prefs)
    return {"ok": True}


# ── In-memory clone operation registry ────────────────────────────────
# Maps clone_id → {"status": ..., "dest": Path, "error": str | None}
_clone_ops: dict[str, dict[str, Any]] = {}

# ── In-memory Salesforce OAuth flow registry ─────────────────────────
# Maps flow_id → {"status": ..., "server": HTTPServer, ...}
_sf_oauth_flows: dict[str, dict[str, Any]] = {}


# ── Request/response models ───────────────────────────────────────────


class ValidateProjectRequest(BaseModel):
    """Request to validate and sanitize a project name."""

    name: str = Field(..., min_length=1, max_length=64)


class ValidateProjectResponse(BaseModel):
    """Result of project name validation."""

    valid: bool
    sanitized_name: str
    reason: str | None = None


class CloneRequest(BaseModel):
    """Request to clone a git repository for a project."""

    git_url: str
    project_name: str


class CloneResponse(BaseModel):
    """Response containing the clone operation identifier."""

    clone_id: str


class SubprojectsResponse(BaseModel):
    """Discovered dbt sub-projects within a cloned repository."""

    paths: list[str]
    auto_selected: str | None = None


class TestConnectionRequest(BaseModel):
    """Credentials to test a data backend connection."""

    backend_type: Literal["snowflake", "duckdb"]
    # Snowflake fields (private key auth)
    account: str | None = None
    user: str | None = None
    role: str | None = None
    warehouse: str | None = None
    private_key_path: str | None = None
    # DuckDB fields
    db_path: str | None = None


class TestConnectionResponse(BaseModel):
    """Result of a backend connection test, with optional metadata."""

    success: bool
    message: str
    # Metadata auto-fill (cherry-pick: connection returns warehouse metadata)
    databases: list[str] | None = None
    warehouses: list[str] | None = None
    schemas: list[str] | None = None


class CreateProjectRequest(BaseModel):
    """Wizard payload for creating a new project configuration."""

    name: str
    git_url: str
    sub_project: str | None = None
    backend: Literal["snowflake", "duckdb"]
    # Snowflake (private key auth)
    snowflake_account: str | None = None
    snowflake_user: str | None = None
    snowflake_role: str | None = None
    snowflake_warehouse: str | None = None
    snowflake_private_key_path: str | None = None
    snowflake_database: str | None = None
    snowflake_schema: str | None = "PUBLIC"
    allowed_databases: list[str] | None = None
    dbt_target: str | None = "prod"
    profile_name: str | None = None
    # DuckDB
    duckdb_path: str | None = None
    # Per-project env vars (comma-separated key=val for dbt env_var() references)
    env_vars: str | None = None
    # Integrations (optional)
    salesforce_enabled: bool = False
    salesforce_client_id: str | None = None
    salesforce_login_url: str | None = None
    salesforce_auth_type: SfAuthMode | None = None
    salesforce_instance_url: str | None = None
    salesforce_username: str | None = None
    cube_enabled: bool = False
    cube_project_dir: str | None = None
    lookml_enabled: bool = False
    lookml_project_dir: str | None = None
    fivetran_enabled: bool = False
    fivetran_connector_ids: list[str] | None = None
    linear_enabled: bool = False
    linear_team_id: str | None = None
    # Profiling
    profiling_enabled: bool = True
    # Secret fields — used by browser-only dev mode (.env fallback).
    # In Tauri mode, secrets go to OS keychain and never reach this endpoint.
    linear_analyst_api_key: str | None = None
    linear_data_engineer_api_key: str | None = None
    anthropic_api_key: str | None = None
    openai_api_key: str | None = None
    logfire_api_key: str | None = None


class CreateProjectResponse(BaseModel):
    """Response after successfully creating a project."""

    name: str
    config_path: str
    message: str


# ── Helpers ───────────────────────────────────────────────────────────


def _sanitize_project_name(name: str) -> str:
    """Sanitize a project name for filesystem and SurrealDB database use."""
    sanitized = re.sub(r"[^a-z0-9_]", "_", name.lower()).strip("_")
    # Collapse multiple underscores
    sanitized = re.sub(r"_+", "_", sanitized)
    return sanitized[:64]


def _write_env_file(path: Path, entries: dict[str, str]) -> None:
    """Write a .env file atomically with 0600 permissions."""
    content = "\n".join(f"{k}={v}" for k, v in entries.items() if v) + "\n"
    tmp_path = path.with_suffix(".env.tmp")
    # Write with restricted permissions from the start (no TOCTOU race)
    fd = os.open(
        str(tmp_path),
        os.O_WRONLY | os.O_CREAT | os.O_TRUNC,
        stat.S_IRUSR | stat.S_IWUSR,
    )
    with os.fdopen(fd, "w") as f:
        f.write(content)
    os.rename(str(tmp_path), str(path))


def _write_config_atomic(path: Path, content: str) -> None:
    """Write a config file atomically via temp-file-then-rename."""
    tmp_path = path.with_suffix(".yaml.tmp")
    tmp_path.write_text(content)
    os.rename(str(tmp_path), str(path))


# ── Endpoints ─────────────────────────────────────────────────────────


@router.get("/env-defaults")
async def env_defaults():
    """Return Snowflake/dbt env vars that are currently set. Used by 'Load from Environment'."""
    env_keys = [
        "SNOWFLAKE_ACCOUNT",
        "SNOWFLAKE_USER",
        "SNOWFLAKE_ROLE",
        "SNOWFLAKE_WAREHOUSE",
        "SNOWFLAKE_PRIVATE_KEY_PATH",
        "DBT_TARGET",
        "ANTHROPIC_API_KEY",
        "OPENAI_API_KEY",
        "LOGFIRE_TOKEN",
        # Integration secrets — reported as present/absent for placeholder UI
        "SF_PASSWORD",
        "SF_SECURITY_TOKEN",
        "SF_CLIENT_SECRET",
        "FIVETRAN_API_KEY",
        "FIVETRAN_API_SECRET",
        "LINEAR_ANALYST_API_KEY",
        "LINEAR_DATA_ENGINEER_API_KEY",
    ]
    return {k: v for k in env_keys if (v := os.environ.get(k))}


@router.post("/validate-project", response_model=ValidateProjectResponse)
async def validate_project(req: ValidateProjectRequest):
    """Validate and sanitize a project name. Check for uniqueness."""
    sanitized = _sanitize_project_name(req.name)
    if not sanitized:
        return ValidateProjectResponse(
            valid=False,
            sanitized_name="",
            reason="Name must contain alphanumeric characters",
        )

    # Check if project directory already exists
    project_dir = projects_dir() / sanitized
    if project_dir.exists():
        return ValidateProjectResponse(
            valid=False,
            sanitized_name=sanitized,
            reason=f"Project '{sanitized}' already exists",
        )

    return ValidateProjectResponse(valid=True, sanitized_name=sanitized)


@router.post("/clone", response_model=CloneResponse)
async def start_clone(req: CloneRequest):
    """Start a git clone operation. Returns a clone_id for progress tracking."""
    from lineage.utils.git import is_valid_git_url

    if not is_valid_git_url(req.git_url):
        raise HTTPException(status_code=400, detail="Invalid git URL")

    sanitized = _sanitize_project_name(req.project_name)
    dest = projects_dir() / sanitized
    if dest.exists() and any(dest.iterdir()):
        raise HTTPException(
            status_code=409, detail=f"Project directory already exists: {sanitized}"
        )

    clone_id = str(uuid.uuid4())
    _clone_ops[clone_id] = {
        "status": "pending",
        "dest": dest,
        "url": req.git_url,
        "error": None,
    }

    # Spawn clone in background
    asyncio.create_task(_run_clone(clone_id, req.git_url, dest))

    return CloneResponse(clone_id=clone_id)


async def _run_clone(clone_id: str, url: str, dest: Path) -> None:
    """Background task that runs the clone and updates the operation registry."""
    from lineage.utils.git import clone_repo_with_progress

    _clone_ops[clone_id]["status"] = "running"
    try:
        async for progress in clone_repo_with_progress(url, dest):
            _clone_ops[clone_id]["last_progress"] = progress
            if progress.phase == "error":
                _clone_ops[clone_id]["status"] = "error"
                _clone_ops[clone_id]["error"] = progress.message
                return
        _clone_ops[clone_id]["status"] = "complete"
    except Exception as exc:
        _clone_ops[clone_id]["status"] = "error"
        _clone_ops[clone_id]["error"] = str(exc)


@router.get("/clone/{clone_id}/progress")
async def clone_progress(clone_id: str):
    """SSE stream for clone progress. Polls the in-memory operation registry."""
    if clone_id not in _clone_ops:
        raise HTTPException(
            status_code=404, detail=f"Clone operation '{clone_id}' not found"
        )

    async def generate():
        last_emitted = None
        while not shutdown_event.is_set():
            op = _clone_ops.get(clone_id)
            if not op:
                break

            status = op["status"]
            progress = op.get("last_progress")

            if progress and progress != last_emitted:
                yield _sse_event(
                    "progress",
                    {
                        "phase": progress.phase,
                        "percent": progress.percent,
                        "message": progress.message,
                    },
                )
                last_emitted = progress

            if status == "complete":
                yield _sse_event("done", {"phase": "done", "percent": 100})
                # Don't pop here — fetchSubprojects needs the entry.
                # Cleaned up by get_subprojects or on error.
                break
            elif status == "error":
                yield _sse_event(
                    "error",
                    {
                        "phase": "error",
                        "message": op.get("error", "Unknown error"),
                    },
                )
                _clone_ops.pop(clone_id, None)
                break

            await asyncio.sleep(0.5)

    return StreamingResponse(generate(), media_type="text/event-stream")


@router.get("/subprojects/{clone_id}", response_model=SubprojectsResponse)
async def get_subprojects(clone_id: str):
    """Scan a cloned repo for dbt_project.yml files. Auto-selects if exactly one."""
    op = _clone_ops.get(clone_id)
    if not op:
        raise HTTPException(
            status_code=404, detail=f"Clone operation '{clone_id}' not found"
        )
    if op["status"] != "complete":
        raise HTTPException(status_code=409, detail="Clone not yet complete")

    dest = op["dest"]
    # Find all dbt_project.yml files
    dbt_files = list(dest.rglob("dbt_project.yml"))
    paths = [str(f.parent.relative_to(dest)) for f in dbt_files]

    # Cherry-pick: auto-select if exactly one
    auto_selected = paths[0] if len(paths) == 1 else None

    # Clean up the in-memory clone registry now that subprojects have been read
    _clone_ops.pop(clone_id, None)

    return SubprojectsResponse(paths=paths, auto_selected=auto_selected)


@router.post("/test-connection", response_model=TestConnectionResponse)
async def test_connection(req: TestConnectionRequest):
    """Test data backend credentials. Returns metadata on success (cherry-pick)."""
    if req.backend_type == "duckdb":
        if not req.db_path:
            return TestConnectionResponse(
                success=True, message="In-memory DuckDB (no file path)"
            )
        db_path = Path(req.db_path).expanduser()
        if db_path.suffix not in (".db", ".duckdb", ""):
            return TestConnectionResponse(
                success=False, message="Invalid DuckDB file extension"
            )
        return TestConnectionResponse(success=True, message="DuckDB path is valid")

    # Snowflake — private key auth
    if not all([req.account, req.user, req.private_key_path]):
        return TestConnectionResponse(
            success=False, message="Account, user, and private key path are required"
        )

    key_path = Path(req.private_key_path).expanduser()  # type: ignore[arg-type]
    if not key_path.exists():
        return TestConnectionResponse(
            success=False, message=f"Private key file not found: {key_path}"
        )

    try:
        from lineage.utils.snowflake import list_snowflake_databases

        databases = list_snowflake_databases(
            account=req.account,  # type: ignore[arg-type]
            user=req.user,  # type: ignore[arg-type]
            private_key_path=str(key_path),
            warehouse=req.warehouse,
            role=req.role,
        )

        return TestConnectionResponse(
            success=True,
            message="Connected successfully",
            databases=databases or None,
        )

    except ImportError:
        return TestConnectionResponse(
            success=False,
            message="snowflake-connector-python not installed",
        )
    except Exception as exc:
        return TestConnectionResponse(success=False, message=str(exc))


class TestLinearRequest(BaseModel):
    """Payload for testing Linear API credentials."""

    api_key: str
    team_id: str | None = None


class TestLinearResponse(BaseModel):
    """Result of a Linear API credential test."""

    success: bool
    message: str
    team_name: str | None = None


@router.post("/test-linear", response_model=TestLinearResponse)
async def test_linear(req: TestLinearRequest):
    """Test a Linear API key by fetching teams, optionally validating team_id."""
    if not req.api_key:
        return TestLinearResponse(success=False, message="API key is required")

    try:
        from linear_api import LinearClient

        client = LinearClient(api_key=req.api_key)
        teams = client.teams.get_all()

        if not teams:
            return TestLinearResponse(
                success=False,
                message="API key is valid but no teams found",
            )

        if req.team_id:
            team = teams.get(req.team_id)
            if not team:
                team_names = [f"{t.key} ({t.name})" for t in teams.values() if t.key]
                return TestLinearResponse(
                    success=False,
                    message=f"Team '{req.team_id}' not found. Available: {', '.join(team_names)}",
                )
            return TestLinearResponse(
                success=True,
                message=f"Connected to team {team.key} ({team.name})",
                team_name=team.name,
            )

        # No team_id specified — just confirm the key works
        first = next(iter(teams.values()))
        return TestLinearResponse(
            success=True,
            message=f"API key valid. Found {len(teams)} team(s)",
            team_name=first.name,
        )

    except ImportError:
        return TestLinearResponse(
            success=False,
            message="linear-api package not installed",
        )
    except Exception as exc:
        return TestLinearResponse(success=False, message=str(exc))


class TestFivetranRequest(BaseModel):
    """Payload for testing Fivetran API credentials."""

    api_key: str
    api_secret: str


class TestFivetranResponse(BaseModel):
    """Result of a Fivetran API credential test."""

    success: bool
    message: str


@router.post("/test-fivetran", response_model=TestFivetranResponse)
async def test_fivetran(req: TestFivetranRequest):
    """Test Fivetran API credentials by listing groups."""
    if not req.api_key or not req.api_secret:
        return TestFivetranResponse(
            success=False, message="API key and secret are required"
        )

    try:
        from ingest.static_loaders.fivetran.client import FivetranClient
    except ImportError:
        return TestFivetranResponse(
            success=False, message="Fivetran client package not available"
        )

    try:
        with FivetranClient(api_key=req.api_key, api_secret=req.api_secret) as client:
            if client.test_connection():
                return TestFivetranResponse(
                    success=True, message="Connected to Fivetran API"
                )
            return TestFivetranResponse(success=False, message="Invalid credentials")
    except Exception:
        return TestFivetranResponse(
            success=False, message="Failed to connect to Fivetran API"
        )


# ── Salesforce auth endpoints ─────────────────────────────────────────

_ALLOWED_SF_HOSTS = {"login.salesforce.com", "test.salesforce.com"}


def _is_salesforce_host(host: str) -> bool:
    """Return True if *host* is a known Salesforce domain."""
    if host in _ALLOWED_SF_HOSTS:
        return True
    return host.endswith((".salesforce.com", ".force.com"))


def _validate_salesforce_login_url(url: str) -> None:
    """Reject login URLs that aren't known Salesforce endpoints (SSRF prevention)."""
    from urllib.parse import urlparse

    parsed = urlparse(url)
    if parsed.scheme != "https":
        raise HTTPException(status_code=400, detail="Salesforce login URL must use HTTPS")
    host = (parsed.hostname or "").lower()
    if _is_salesforce_host(host):
        return
    raise HTTPException(
        status_code=400,
        detail=f"Unrecognized Salesforce login host: {host}. "
        "Expected login.salesforce.com, test.salesforce.com, *.salesforce.com, or *.force.com",
    )


def _validate_salesforce_instance_url(url: str) -> None:
    """Reject instance URLs that aren't Salesforce domains (SSRF prevention)."""
    from urllib.parse import urlparse

    parsed = urlparse(url)
    if parsed.scheme != "https":
        raise HTTPException(
            status_code=400, detail="Salesforce instance URL must use HTTPS"
        )
    host = (parsed.hostname or "").lower()
    if _is_salesforce_host(host):
        return
    raise HTTPException(
        status_code=400,
        detail=f"Unrecognized Salesforce instance host: {host}. "
        "Expected *.salesforce.com or *.force.com",
    )


class StartSalesforceOAuthRequest(BaseModel):
    """Payload to start a Salesforce OAuth PKCE flow."""

    client_id: str
    login_url: str = "https://login.salesforce.com"


class StartSalesforceOAuthResponse(BaseModel):
    """Response containing the authorize URL and flow identifier."""

    flow_id: str
    authorize_url: str


def _validate_salesforce_client_id(client_id: str) -> None:
    """Reject values that are clearly not a Salesforce Connected App Client ID."""
    trimmed = client_id.strip()
    if not trimmed:
        raise HTTPException(status_code=400, detail="Client ID is required.")
    if re.match(r"^https?://", trimmed, re.IGNORECASE):
        raise HTTPException(
            status_code=400,
            detail="This looks like a URL, not a Client ID. "
            "Paste the Consumer Key from your Salesforce Connected App.",
        )
    if re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", trimmed):
        raise HTTPException(
            status_code=400,
            detail="This looks like an email address, not a Client ID.",
        )
    if re.search(r"\s", trimmed):
        raise HTTPException(
            status_code=400, detail="Client ID should not contain spaces."
        )


@router.post("/salesforce/start-oauth", response_model=StartSalesforceOAuthResponse)
async def start_salesforce_oauth(req: StartSalesforceOAuthRequest):
    """Start a Salesforce OAuth PKCE flow.

    Generates PKCE code verifier/challenge, starts a local callback server
    on port 8443, and returns the authorize URL for the frontend to open
    in the user's browser.
    """
    client_id = req.client_id.strip()
    _validate_salesforce_client_id(client_id)
    _validate_salesforce_login_url(req.login_url)

    import secrets
    from urllib.parse import quote, urlencode

    from ingest.static_loaders.salesforce.auth.oauth_pkce import (
        generate_code_challenge,
        generate_code_verifier,
    )
    from ingest.static_loaders.salesforce.auth.server import start_callback_server

    # Only allow one OAuth flow at a time — also clean up any old flows
    for fid, flow in list(_sf_oauth_flows.items()):
        try:
            flow["server"].server_close()
        except Exception:  # noqa: BLE001
            logger.debug("Failed to close stale OAuth callback server for flow %s", fid)
        _sf_oauth_flows.pop(fid, None)

    flow_id = str(uuid.uuid4())

    code_verifier = generate_code_verifier()
    code_challenge = generate_code_challenge(code_verifier)

    state = secrets.token_urlsafe(32)
    callback_port = 8443
    redirect_uri = f"http://localhost:{callback_port}/callback"

    # Start callback server before returning the URL
    try:
        server, _ready = start_callback_server(port=callback_port)
    except OSError as exc:
        raise HTTPException(
            status_code=409,
            detail=f"Could not start OAuth callback server on port {callback_port}: {exc}",
        ) from exc

    # Build authorize URL
    params = {
        "response_type": "code",
        "client_id": client_id,
        "redirect_uri": redirect_uri,
        "code_challenge": code_challenge,
        "code_challenge_method": "S256",
        "state": state,
        "scope": "refresh_token api",
    }
    authorize_url = f"{req.login_url}/services/oauth2/authorize?{urlencode(params, quote_via=quote)}"

    _sf_oauth_flows[flow_id] = {
        "status": "pending",
        "server": server,
        "code_verifier": code_verifier,
        "expected_state": state,
        "client_id": client_id,
        "login_url": req.login_url,
        "redirect_uri": redirect_uri,
        "callback_port": callback_port,
    }

    return StartSalesforceOAuthResponse(flow_id=flow_id, authorize_url=authorize_url)


@router.get("/salesforce/oauth-status/{flow_id}")
async def salesforce_oauth_status(flow_id: str):
    """SSE stream that polls for the OAuth callback result.

    Emits ``waiting`` events while the user is in the browser, then a
    ``success`` or ``error`` event once the callback is received or the
    flow times out.
    """
    if flow_id not in _sf_oauth_flows:
        raise HTTPException(status_code=404, detail="OAuth flow not found")

    async def generate():
        import time

        import httpx
        from ingest.static_loaders.salesforce.auth.server import _CallbackHandler
        from ingest.static_loaders.salesforce.auth.token_store import (
            StoredTokens,
            TokenStore,
        )

        flow = _sf_oauth_flows[flow_id]
        deadline = time.monotonic() + 120.0  # 2 minute timeout

        try:
            while time.monotonic() < deadline and not shutdown_event.is_set():
                # Check if callback has been received
                if _CallbackHandler.auth_code is not None:
                    auth_code = _CallbackHandler.auth_code
                    callback_state = _CallbackHandler.callback_state

                    # Validate state (CSRF protection)
                    if callback_state != flow["expected_state"]:
                        yield _sse_event(
                            "error",
                            {"message": "OAuth state mismatch — possible CSRF attack"},
                        )
                        return

                    # Exchange code for tokens (run in executor to avoid blocking the event loop)
                    try:

                        def _exchange(code: str = auth_code) -> dict:
                            resp = httpx.post(
                                f"{flow['login_url']}/services/oauth2/token",
                                data={
                                    "grant_type": "authorization_code",
                                    "client_id": flow["client_id"],
                                    "code": code,
                                    "redirect_uri": flow["redirect_uri"],
                                    "code_verifier": flow["code_verifier"],
                                },
                                timeout=30.0,
                            )
                            resp.raise_for_status()
                            return resp.json()

                        token_data = await asyncio.get_running_loop().run_in_executor(
                            None, _exchange
                        )

                        # Store tokens
                        store = TokenStore(org_key="default")
                        store.save(
                            StoredTokens(
                                access_token=token_data["access_token"],
                                instance_url=token_data["instance_url"],
                                refresh_token=token_data.get("refresh_token"),
                                token_type=token_data.get("token_type", "Bearer"),
                                issued_at=token_data.get("issued_at"),
                                org_key="default",
                            )
                        )

                        yield _sse_event(
                            "success",
                            {
                                "instance_url": token_data["instance_url"],
                                "message": f"Connected to {token_data['instance_url']}",
                            },
                        )
                        return
                    except Exception as exc:
                        logger.error("Salesforce token exchange failed: %s", exc)
                        yield _sse_event(
                            "error", {"message": "Token exchange failed. Check backend logs for details."}
                        )
                        return

                if _CallbackHandler.error is not None:
                    yield _sse_event(
                        "error", {"message": f"OAuth error: {_CallbackHandler.error}"}
                    )
                    return

                yield _sse_event("waiting", {"message": "Waiting for browser login..."})
                await asyncio.sleep(1.0)

            yield _sse_event("error", {"message": "OAuth flow timed out (120s)"})
        finally:
            try:
                flow["server"].server_close()
            except Exception:  # noqa: BLE001
                logger.debug("Failed to close OAuth callback server for flow %s", flow_id)
            _sf_oauth_flows.pop(flow_id, None)

    return StreamingResponse(generate(), media_type="text/event-stream")


class TestSalesforceRequest(BaseModel):
    """Payload for testing Salesforce credentials."""

    auth_type: SfAuthMode
    client_id: str | None = None
    client_secret: str | None = None
    login_url: str = "https://login.salesforce.com"
    instance_url: str | None = None
    username: str | None = None
    password: str | None = None
    security_token: str | None = None


class TestSalesforceResponse(BaseModel):
    """Result of a Salesforce credential test."""

    success: bool
    message: str
    instance_url: str | None = None


@router.post("/test-salesforce", response_model=TestSalesforceResponse)
async def test_salesforce(req: TestSalesforceRequest):
    """Test Salesforce credentials based on auth type."""
    _validate_salesforce_login_url(req.login_url)

    if req.auth_type is SfAuthMode.OAUTH_PKCE:
        # Check for cached tokens from a previous OAuth flow
        try:
            from ingest.static_loaders.salesforce.auth.token_store import TokenStore

            store = TokenStore(org_key="default")
            stored = store.load()
            if stored and stored.access_token:
                return TestSalesforceResponse(
                    success=True,
                    message=f"OAuth tokens available for {stored.instance_url}",
                    instance_url=stored.instance_url,
                )
            return TestSalesforceResponse(
                success=False,
                message="No OAuth tokens found. Use 'Connect with Salesforce' to authenticate.",
            )
        except Exception as exc:
            logger.error("Salesforce OAuth token check failed: %s", exc)
            return TestSalesforceResponse(success=False, message="Failed to check OAuth tokens")

    elif req.auth_type is SfAuthMode.PASSWORD:
        if not all([req.instance_url, req.username, req.password, req.security_token]):
            return TestSalesforceResponse(
                success=False,
                message="Instance URL, username, password, and security token are required",
            )
        _validate_salesforce_instance_url(req.instance_url)  # type: ignore[arg-type]
        try:
            from simple_salesforce import Salesforce

            sf = await asyncio.get_running_loop().run_in_executor(
                None,
                lambda: Salesforce(
                    instance_url=req.instance_url,
                    username=req.username,
                    password=req.password,
                    security_token=req.security_token,
                ),
            )
            return TestSalesforceResponse(
                success=True,
                message=f"Connected to {sf.sf_instance}",
                instance_url=f"https://{sf.sf_instance}",
            )
        except ImportError:
            return TestSalesforceResponse(
                success=False,
                message="simple-salesforce package not installed",
            )
        except Exception as exc:
            logger.error("Salesforce password auth test failed: %s", exc)
            return TestSalesforceResponse(success=False, message="Authentication failed")

    elif req.auth_type is SfAuthMode.CLIENT_CREDENTIALS:
        if not req.client_id or not req.client_secret:
            return TestSalesforceResponse(
                success=False,
                message="Client ID and Client Secret are required",
            )
        try:
            from ingest.static_loaders.salesforce.auth.client_creds import (
                ClientCredentialsAuth,
            )

            auth = ClientCredentialsAuth(
                client_id=req.client_id,
                client_secret=req.client_secret,
                login_url=req.login_url,
            )
            creds = await asyncio.get_running_loop().run_in_executor(
                None, auth.authenticate
            )
            return TestSalesforceResponse(
                success=True,
                message=f"Connected to {creds.instance_url}",
                instance_url=creds.instance_url,
            )
        except Exception as exc:
            logger.error("Salesforce client credentials test failed: %s", exc)
            return TestSalesforceResponse(success=False, message="Authentication failed")

    return TestSalesforceResponse(
        success=False, message=f"Unknown auth type: {req.auth_type}"
    )


class ListSchemasRequest(BaseModel):
    """Snowflake connection details for listing schemas in a database."""

    account: str
    user: str
    role: str | None = None
    warehouse: str | None = None
    private_key_path: str
    database: str


@router.post("/list-schemas")
async def list_schemas(req: ListSchemasRequest):
    """List schemas for a given Snowflake database."""
    key_path = Path(req.private_key_path).expanduser()
    if not key_path.exists():
        raise HTTPException(
            status_code=400, detail=f"Private key not found: {key_path}"
        )

    try:
        from lineage.utils.snowflake import list_snowflake_schemas

        schemas = await asyncio.get_running_loop().run_in_executor(
            None,
            lambda: list_snowflake_schemas(
                account=req.account,
                user=req.user,
                private_key_path=str(key_path),
                database=req.database,
                warehouse=req.warehouse,
                role=req.role,
            ),
        )
        return {"schemas": schemas}
    except ImportError:
        raise HTTPException(
            status_code=500, detail="snowflake-connector-python not installed"
        ) from None
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from None


@router.post("/create-project", response_model=CreateProjectResponse)
async def create_project(req: CreateProjectRequest):
    """Create project configuration: config.yaml, profiles.yml, .env."""
    ensure_home()
    sanitized = _sanitize_project_name(req.name)

    # Build project config as Pydantic model (not Jinja2 template)
    project_dir = projects_dir() / sanitized
    if not project_dir.exists():
        raise HTTPException(
            status_code=400,
            detail=f"Project directory not found: {sanitized}. Clone first.",
        )

    dbt_path = str(project_dir)
    if req.sub_project:
        # Validate subproject path to prevent traversal
        sub = Path(req.sub_project)
        if sub.is_absolute() or ".." in sub.parts:
            raise HTTPException(status_code=400, detail="Invalid subproject path")
        resolved = (project_dir / sub).resolve()
        if not resolved.is_relative_to(project_dir.resolve()):
            raise HTTPException(status_code=400, detail="Invalid subproject path")
        dbt_path = str(resolved)

    # In Tauri mode, secrets go to OS keychain and never reach here.
    # In browser-only dev mode, secrets still arrive via this endpoint
    # and are written to .env as a fallback.
    env_entries: dict[str, str] = {}
    if req.snowflake_private_key_path:
        env_entries["SNOWFLAKE_PRIVATE_KEY_PATH"] = req.snowflake_private_key_path
    if req.snowflake_account:
        env_entries["SNOWFLAKE_ACCOUNT"] = req.snowflake_account
    if req.snowflake_user:
        env_entries["SNOWFLAKE_USER"] = req.snowflake_user
    if req.snowflake_role:
        env_entries["SNOWFLAKE_ROLE"] = req.snowflake_role
    if req.snowflake_warehouse:
        env_entries["SNOWFLAKE_WAREHOUSE"] = req.snowflake_warehouse
    if req.anthropic_api_key:
        env_entries["ANTHROPIC_API_KEY"] = req.anthropic_api_key
    if req.openai_api_key:
        env_entries["OPENAI_API_KEY"] = req.openai_api_key
    if req.logfire_api_key:
        env_entries["LOGFIRE_TOKEN"] = req.logfire_api_key
    if req.linear_analyst_api_key:
        env_entries["LINEAR_ANALYST_API_KEY"] = req.linear_analyst_api_key
    if req.linear_data_engineer_api_key:
        env_entries["LINEAR_DATA_ENGINEER_API_KEY"] = req.linear_data_engineer_api_key
    if req.linear_team_id:
        env_entries["LINEAR_TEAM_ID"] = req.linear_team_id

    if env_entries:
        ep = env_path()
        existing_env: dict[str, str] = {}
        if ep.exists():
            for line in ep.read_text().splitlines():
                if "=" in line and not line.startswith("#"):
                    k, v = line.split("=", 1)
                    existing_env[k.strip()] = v.strip()
        existing_env.update(env_entries)
        _write_env_file(ep, existing_env)

    # Resolve profile name: prefer the caller-supplied value, then fall back
    # to reading dbt_project.yml.  When the caller already provides a profile
    # name (e.g. quickstart) we skip the file read so the project directory
    # doesn't need to contain dbt_project.yml yet.
    profile_name = req.profile_name
    if not profile_name:
        dbt_project_yml = Path(dbt_path) / "dbt_project.yml"
        if not dbt_project_yml.exists():
            raise HTTPException(
                status_code=400,
                detail=f"dbt_project.yml not found at {dbt_path}",
            )
        import yaml

        with open(dbt_project_yml) as f:
            dbt_cfg = yaml.safe_load(f) or {}
        profile_name = dbt_cfg.get("profile")
        if not profile_name:
            raise HTTPException(
                status_code=400,
                detail="No 'profile' key found in dbt_project.yml",
            )

    # Write profiles.yml
    profiles_path = profiles_dir() / sanitized
    profiles_path.mkdir(parents=True, exist_ok=True)
    profiles_yml = _build_profiles_yml(req, profile_name)
    (profiles_path / "profiles.yml").write_text(profiles_yml)

    # Merge new project into existing config.yaml (don't overwrite other projects)
    import yaml

    cfg_file = config_path()
    existing: dict = {}
    if cfg_file.exists():
        existing = yaml.safe_load(cfg_file.read_text()) or {}

    new_project = _build_project_config(req, sanitized, dbt_path, profile_name)
    projects = existing.get("projects") or {}
    projects[sanitized] = new_project
    existing["projects"] = projects
    existing["default_project"] = sanitized  # new project becomes default

    # Ensure lineage section exists (only required top-level field for UnifiedConfig;
    # models and memory have defaults / are optional)
    surreal_url = os.environ.get("SURREAL_URL", default_surreal_url())
    if "lineage" not in existing:
        existing["lineage"] = {
            "backend": "surrealdb",
            "url": surreal_url,
            "namespace": "lineage",
        }

    _write_config_atomic(
        cfg_file, yaml.dump(existing, default_flow_style=False, sort_keys=False)
    )

    return CreateProjectResponse(
        name=sanitized,
        config_path=str(config_path()),
        message=f"Project '{sanitized}' created successfully",
    )


# ── Preflight (dbt venv + docs generate) ─────────────────────────────


class PreflightRequest(BaseModel):
    """Request payload for the dbt preflight (venv + docs generate) step."""

    project_name: str
    backend: Literal["snowflake", "duckdb"]


@router.post("/preflight/{project_name}/start")
async def start_preflight(project_name: str, req: PreflightRequest):
    """Run dbt venv setup + dbt docs generate. Returns SSE progress."""
    from core.paths import profiles_dir, projects_dir

    sanitized = _sanitize_project_name(project_name)
    project_dir = projects_dir() / sanitized
    if not project_dir.exists():
        raise HTTPException(
            status_code=404, detail=f"Project directory not found: {sanitized}"
        )

    # Determine dbt project root (may be a subproject)
    # Read config to find dbt_path
    config_file = config_path()
    dbt_project_root = project_dir
    cfg: dict = {}
    proj_cfg: dict = {}
    if config_file.exists():
        import yaml

        with open(config_file) as f:
            cfg = yaml.safe_load(f) or {}
        proj_cfg = (cfg.get("projects") or {}).get(sanitized, {})
        dbt_path = proj_cfg.get("dbt_path")
        if dbt_path:
            dbt_project_root = Path(dbt_path)

    adapter = "snowflake" if req.backend == "snowflake" else "duckdb"
    prof_dir = profiles_dir() / sanitized

    async def generate():
        yield _sse_event(
            "preflight.status",
            {
                "phase": "venv",
                "message": f"Ensuring dbt-{adapter} virtual environment...",
            },
        )

        # Ensure dbt venv
        try:
            from lineage.tui.wizards.init.helpers import ensure_dbt_venv

            venv_dir = await asyncio.to_thread(ensure_dbt_venv, adapter)
            yield _sse_event(
                "preflight.status", {"phase": "venv", "message": "dbt venv ready"}
            )
        except Exception as exc:
            yield _sse_event(
                "preflight.error",
                {"phase": "venv", "message": f"Failed to create dbt venv: {exc}"},
            )
            return

        # Check if a valid manifest already exists
        from lineage.utils.dbt import _validate_manifest

        manifest = dbt_project_root / "target" / "manifest.json"
        if _validate_manifest(manifest):
            yield _sse_event(
                "preflight.status",
                {
                    "phase": "docs",
                    "message": "manifest.json already exists, skipping dbt docs generate",
                },
            )
        else:
            yield _sse_event(
                "preflight.status",
                {"phase": "docs", "message": "Running dbt docs generate..."},
            )
            try:
                import subprocess as _sp  # nosec B404

                from lineage.utils.dbt import run_dbt_command

                # Read .env file to pass credentials to dbt subprocess
                extra_env: dict[str, str] = {}
                env_file = env_path()
                if env_file.exists():
                    for line in env_file.read_text().splitlines():
                        line = line.strip()
                        if line and not line.startswith("#") and "=" in line:
                            k, v = line.split("=", 1)
                            extra_env[k.strip()] = v.strip()

                # Also load per-project env vars from config.yaml
                if proj_cfg.get("env"):
                    for k, v in proj_cfg["env"].items():
                        extra_env[k] = str(v)

                # Install dbt packages first
                yield _sse_event(
                    "preflight.status",
                    {"phase": "deps", "message": "Running dbt deps..."},
                )
                try:
                    await asyncio.to_thread(
                        run_dbt_command,
                        ["deps"],
                        dbt_project_root,
                        profiles_dir=prof_dir,
                        venv_dir=venv_dir,
                        extra_env=extra_env or None,
                    )
                    yield _sse_event(
                        "preflight.status",
                        {"phase": "deps", "message": "dbt deps completed"},
                    )
                except _sp.CalledProcessError as exc:
                    err_detail = exc.stderr or exc.stdout or str(exc)
                    logger.error("[desktop:preflight] dbt deps failed:\n%s", err_detail)
                    display = (
                        err_detail
                        if len(err_detail) <= 2000
                        else err_detail[:2000] + "..."
                    )
                    yield _sse_event(
                        "preflight.error",
                        {"phase": "deps", "message": f"dbt deps failed:\n{display}"},
                    )
                    return

                # Determine dbt target from config
                dbt_target = (
                    (cfg.get("projects") or {}).get(sanitized, {}).get("dbt_target")
                    if config_file.exists()
                    else None
                )
                target_args = ["--target", dbt_target] if dbt_target else []

                # For DuckDB: run dbt seed first so seed tables exist for docs generate
                # (e.g. dbt_project_evaluator expects seed tables to be present)
                if adapter == "duckdb":
                    yield _sse_event(
                        "preflight.status",
                        {"phase": "seed", "message": "Running dbt seed..."},
                    )
                    try:
                        await asyncio.to_thread(
                            run_dbt_command,
                            ["seed", *target_args],
                            dbt_project_root,
                            profiles_dir=prof_dir,
                            venv_dir=venv_dir,
                            extra_env=extra_env or None,
                        )
                        yield _sse_event(
                            "preflight.status",
                            {"phase": "seed", "message": "dbt seed completed"},
                        )
                    except _sp.CalledProcessError as exc:
                        # Seed failures are non-fatal — some projects don't have seeds
                        logger.warning(
                            "[desktop:preflight] dbt seed failed (non-fatal):\n%s",
                            (exc.stderr or exc.stdout or str(exc))[:500],
                        )
                        yield _sse_event(
                            "preflight.status",
                            {
                                "phase": "seed",
                                "message": "dbt seed skipped (non-fatal failure)",
                            },
                        )

                from lineage.utils.dbt import run_dbt_docs_generate

                result = await asyncio.to_thread(
                    run_dbt_docs_generate,
                    dbt_project_root,
                    profiles_dir=prof_dir,
                    venv_dir=venv_dir,
                    extra_env=extra_env or None,
                    target_args=target_args or None,
                )

                if result.success:
                    yield _sse_event(
                        "preflight.status",
                        {"phase": "docs", "message": "dbt docs generate completed"},
                    )
                else:
                    summary = result.error_summary or "Unknown error"
                    # Build a concise error: filtered errors + log path.
                    parts = [summary[:500]]
                    if result.log_hint:
                        parts.append(f"Full log: {result.log_hint}")
                    yield _sse_event(
                        "preflight.error",
                        {"phase": "docs", "message": "\n".join(parts)},
                    )
                    return
            except Exception as exc:
                yield _sse_event(
                    "preflight.error",
                    {"phase": "docs", "message": f"dbt docs generate failed: {exc}"},
                )
                return

        # Return the artifacts directory for sync
        artifacts_dir = str(dbt_project_root / "target")
        yield _sse_event(
            "preflight.done", {"phase": "done", "artifacts_dir": artifacts_dir}
        )

    return StreamingResponse(generate(), media_type="text/event-stream")


def _build_profiles_yml(req: CreateProjectRequest, profile_name: str) -> str:
    """Build a dbt profiles.yml string from wizard inputs using yaml.dump.

    ``profile_name`` must match the ``profile:`` key in the project's
    ``dbt_project.yml`` so that dbt resolves it correctly.
    """
    import yaml

    target = req.dbt_target or "prod"
    if req.backend == "snowflake":
        output = {
            "type": "snowflake",
            "account": req.snowflake_account or "",
            "user": req.snowflake_user or "",
            "private_key_path": req.snowflake_private_key_path or "",
            "warehouse": req.snowflake_warehouse or "",
            "role": req.snowflake_role or "",
            "database": req.snowflake_database or "",
            "schema": req.snowflake_schema or "PUBLIC",
            "threads": 4,
        }
    else:
        # DuckDB: use the same target name as Snowflake (default "prod") so dbt
        # schema generation rules that key on target name behave correctly.
        target = req.dbt_target or "prod"
        output = {
            "type": "duckdb",
            "path": req.duckdb_path or ":memory:",
            "threads": 4,
        }

    profile = {profile_name: {"target": target, "outputs": {target: output}}}
    return yaml.dump(profile, default_flow_style=False, sort_keys=False)


def _build_project_config(
    req: CreateProjectRequest,
    sanitized: str,
    dbt_path: str,
    profile_name: str | None = None,
) -> dict[str, Any]:
    """Build a single project config dict for merging into config.yaml."""
    data: dict[str, Any] = {"backend": req.backend}

    if req.backend == "snowflake":
        data.update(
            {
                "account": req.snowflake_account or "",
                "user": req.snowflake_user or "",
                "private_key_path": req.snowflake_private_key_path or "",
                "warehouse": req.snowflake_warehouse or "",
                "role": req.snowflake_role or "",
                "database": req.snowflake_database or "",
                "schema_name": req.snowflake_schema or "PUBLIC",
            }
        )
        if req.allowed_databases:
            data["allowed_databases"] = list(req.allowed_databases)
    else:
        data["db_path"] = req.duckdb_path or ":memory:"

    # Use caller-resolved profile name (from dbt_project.yml or user-supplied)
    if not profile_name:
        raise ValueError("profile_name is required — must be read from dbt_project.yml")

    project: dict[str, Any] = {
        "name": sanitized,
        "dbt_path": dbt_path,
        "graph_name": sanitized,
        "profile_name": profile_name,
        "profiles_dir": str(profiles_dir() / sanitized),
        "dbt_target": req.dbt_target or "prod",
        "data": data,
    }

    # Per-project env vars so dbt can resolve env_var() references
    env_vars: dict[str, str] = {}
    if req.backend == "snowflake" and req.snowflake_private_key_path:
        env_vars["SNOWFLAKE_PRIVATE_KEY_PATH"] = req.snowflake_private_key_path
    if req.backend == "duckdb" and req.duckdb_path:
        env_vars["DUCKDB_PATH"] = req.duckdb_path
    # Parse user-supplied comma-separated key=val pairs (e.g. DuckDB env_var() refs)
    if req.env_vars:
        for pair in req.env_vars.split(","):
            pair = pair.strip()
            if "=" in pair:
                key, value = pair.split("=", 1)
                key, value = key.strip(), value.strip()
                if key:
                    env_vars[key] = value
    if env_vars:
        project["env"] = env_vars

    if req.salesforce_enabled:
        sf: dict[str, Any] = {"enabled": True}
        if req.salesforce_client_id:
            sf["client_id"] = req.salesforce_client_id
        sf["login_url"] = req.salesforce_login_url or "https://login.salesforce.com"
        if req.salesforce_auth_type:
            sf["auth_type"] = str(req.salesforce_auth_type)
        if req.salesforce_instance_url:
            sf["instance_url"] = req.salesforce_instance_url
        if req.salesforce_username:
            sf["username"] = req.salesforce_username
        project["salesforce"] = sf
    if req.cube_enabled:
        cube: dict[str, Any] = {"enabled": True}
        if req.cube_project_dir:
            cube["project_dir"] = req.cube_project_dir
        project["cube"] = cube
    if req.lookml_enabled:
        lookml: dict[str, Any] = {"enabled": True}
        if req.lookml_project_dir:
            lookml["project_dir"] = req.lookml_project_dir
        project["lookml"] = lookml
    if req.fivetran_enabled:
        ft: dict[str, Any] = {"enabled": True}
        if req.fivetran_connector_ids:
            ft["connector_ids"] = req.fivetran_connector_ids
        project["fivetran"] = ft
    if req.linear_enabled:
        ticket: dict[str, Any] = {"enabled": True, "backend": "linear"}
        if req.linear_team_id:
            ticket["team_id"] = req.linear_team_id
        project["ticket"] = ticket

    project["profiling"] = {"enabled": req.profiling_enabled}

    return project
