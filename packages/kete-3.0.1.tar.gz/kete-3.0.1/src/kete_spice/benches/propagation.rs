//! Benchmarks for SPK-dependent propagation algorithms.

#![allow(missing_docs, reason = "Unnecessary for benchmarks")]

use std::hint::black_box;
use std::time::Duration;

use criterion::{BenchmarkId, Criterion, criterion_group, criterion_main};
use kete_core::constants;
use kete_core::prelude::*;
use kete_spice::propagation::{propagate_n_body_spk, propagate_n_body_vec};
use kete_spice::spk::LOADED_SPK;
use pprof::criterion::{Output, PProfProfiler};
use rayon::iter::{IntoParallelIterator, ParallelIterator};

static CIRCULAR: std::sync::LazyLock<State<Ecliptic>> = std::sync::LazyLock::new(|| {
    State::new(
        Desig::Name("Circular".into()),
        2451545.0.into(),
        [0.0, 1., 0.0].into(),
        [-constants::GMS_SQRT, 0.0, 0.0].into(),
        0,
    )
});
static ELLIPTICAL: std::sync::LazyLock<State<Ecliptic>> = std::sync::LazyLock::new(|| {
    State::new(
        Desig::Name("Elliptical".into()),
        2451545.0.into(),
        [0.0, 1.5, 0.0].into(),
        [-constants::GMS_SQRT, 0.0, 0.0].into(),
        0,
    )
});
static PARABOLIC: std::sync::LazyLock<State<Ecliptic>> = std::sync::LazyLock::new(|| {
    State::new(
        Desig::Name("Parabolic".into()),
        2451545.0.into(),
        [0.0, 2., 0.0].into(),
        [-constants::GMS_SQRT, 0.0, 0.0].into(),
        0,
    )
});

static HYPERBOLIC: std::sync::LazyLock<State<Ecliptic>> = std::sync::LazyLock::new(|| {
    State::new(
        Desig::Name("Hyperbolic".into()),
        2451545.0.into(),
        [0.0, 3., 0.0].into(),
        [-constants::GMS_SQRT, 0.0, 0.0].into(),
        0,
    )
});

fn prop_n_body_radau(state: State<Ecliptic>, dt: f64) {
    let jd = state.epoch + dt;
    let _ = propagate_n_body_spk(state.into_frame(), jd, false, None).unwrap();
}

fn prop_n_body_vec_radau(mut state: State<Ecliptic>, dt: f64) {
    let spk = &LOADED_SPK.read().unwrap();
    spk.try_change_center(&mut state, 10).unwrap();
    let jd = state.epoch + dt;
    let states = vec![state.into_frame().clone(); 100];
    let non_gravs = vec![None; 100];
    let _ = propagate_n_body_vec(states, jd, None, non_gravs).unwrap();
}

fn prop_n_body_radau_par(state: &State<Ecliptic>, dt: f64) {
    let states: Vec<State<_>> = (0..100).map(|_| state.clone()).collect();
    let _tmp: Vec<State<_>> = states
        .into_par_iter()
        .map(|s| {
            let jd = s.epoch + dt;
            propagate_n_body_spk(s.into_frame(), jd, false, None).unwrap()
        })
        .collect();
}

/// Benchmark functions for the propagation algorithms
#[allow(clippy::missing_panics_doc, reason = "Benchmarking only")]
fn n_body_prop(c: &mut Criterion) {
    let mut nbody_group = c.benchmark_group("N-Body");

    for state in [
        CIRCULAR.clone(),
        ELLIPTICAL.clone(),
        PARABOLIC.clone(),
        HYPERBOLIC.clone(),
    ] {
        let Desig::Name(name) = &state.desig else {
            panic!()
        };
        let _ = nbody_group.bench_with_input(BenchmarkId::new("Single", name), &state, |b, s| {
            b.iter(|| prop_n_body_radau(black_box(s.clone()), black_box(1000.0)));
        });

        let _ = nbody_group.bench_with_input(BenchmarkId::new("Parallel", name), &state, |b, s| {
            b.iter(|| prop_n_body_radau_par(black_box(s), black_box(1000.0)));
        });
    }
}

/// Benchmark functions for the propagation algorithms
#[allow(clippy::missing_panics_doc, reason = "Benchmarking only")]
pub fn n_body_prop_vec(c: &mut Criterion) {
    let mut nbody_group = c.benchmark_group("N-Body-Vec");

    for state in [
        CIRCULAR.clone(),
        ELLIPTICAL.clone(),
        PARABOLIC.clone(),
        HYPERBOLIC.clone(),
    ] {
        let Desig::Name(name) = &state.desig else {
            panic!()
        };
        let _ = nbody_group.bench_with_input(BenchmarkId::new("Single", name), &state, |b, s| {
            b.iter(|| prop_n_body_vec_radau(black_box(s.clone()), black_box(1000.0)));
        });
    }
}

criterion_group!(name=benches;
                 config = Criterion::default().sample_size(30).measurement_time(Duration::from_secs(15)).with_profiler(PProfProfiler::new(100, Output::Flamegraph(None)));
                 targets=n_body_prop_vec, n_body_prop);

criterion_main!(benches);
