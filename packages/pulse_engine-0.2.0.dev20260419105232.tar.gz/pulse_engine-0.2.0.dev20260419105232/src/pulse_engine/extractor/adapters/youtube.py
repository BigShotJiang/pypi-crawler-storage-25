"""YouTube Data API v3 channel extractor with optional S3, Whisper, OpenSearch."""

from __future__ import annotations

import asyncio
import glob
import os
import subprocess
import tempfile
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from pulse_engine.services.opensearch import OpenSearchService

import httpx
import structlog

from pulse_engine.config import get_settings
from pulse_engine.core.exceptions import NotFoundError
from pulse_engine.extractor.base import (
    BaseExtractor,
    ExtractionResult,
    ExtractorConfig,
)

logger = structlog.get_logger(__name__)

_YOUTUBE_API_BASE = "https://www.googleapis.com/youtube/v3"
_MAX_PAGE_SIZE = 50
_WHISPER_MAX_BYTES = 24 * 1024 * 1024  # stay under Whisper's 25 MB hard limit
_WHISPER_CHUNK_SECS = 10 * 60          # split large files into 10-min chunks
_DEFAULT_WHISPER_LANGUAGE = "en"


def _resolve_yt_dlp_opts(parameters: dict[str, Any]) -> dict[str, Any]:
    """Merge caller-supplied yt-dlp options with environment-based defaults.

    Precedence (highest first):
      1. ``parameters["yt_dlp_opts"]`` — a dict merged verbatim.
      2. ``YT_DLP_COOKIEFILE`` env → ``cookiefile`` (used for anti-bot).
      3. ``YT_DLP_PLAYER_CLIENTS`` env, a comma-separated list like
         ``"web,mweb"`` → ``extractor_args.youtube.player_client``.
         Falls back to ``["android_vr"]`` when unset. ``android_vr`` does not
         require a GVS PO Token (unlike ``ios``/``mweb``) and does not need a
         JS challenge solver (unlike ``web``). Override via env if a better
         client becomes available.
    """
    opts: dict[str, Any] = {}

    cookiefile = os.environ.get("YT_DLP_COOKIEFILE", "").strip()
    if cookiefile:
        opts["cookiefile"] = cookiefile

    raw_clients = os.environ.get("YT_DLP_PLAYER_CLIENTS", "").strip()
    clients: list[str] = (
        [c.strip() for c in raw_clients.split(",") if c.strip()]
        if raw_clients
        else ["android_vr"]
    )
    opts["extractor_args"] = {"youtube": {"player_client": clients}}

    override = parameters.get("yt_dlp_opts") or {}
    if isinstance(override, dict):
        # Shallow-merge with one level of deep-merge for ``extractor_args``
        # so callers can add fields without clobbering the player_client
        # default unless they explicitly override it.
        ea_override = override.pop("extractor_args", None)
        opts.update(override)
        if isinstance(ea_override, dict):
            merged_ea = {**opts.get("extractor_args", {}), **ea_override}
            opts["extractor_args"] = merged_ea

    return opts


def _resolve_whisper_language(parameters: dict[str, Any]) -> tuple[str, str]:
    """Return ``(whisper_api_language, metadata_tag)``.

    Empty API language means omit the ``language`` argument to Whisper
    (auto-detect). Metadata tag is always a non-empty string for storage.
    """
    if "whisper_language" not in parameters:
        return _DEFAULT_WHISPER_LANGUAGE, _DEFAULT_WHISPER_LANGUAGE
    raw_wl = parameters["whisper_language"]
    if raw_wl is None or (isinstance(raw_wl, str) and not str(raw_wl).strip()):
        return "", "auto"
    s = str(raw_wl).strip()
    if s.lower() == "auto":
        return "", "auto"
    return s, s


def _is_live_or_upcoming_broadcast(video: dict[str, Any]) -> bool:
    """True if the video resource is a live or scheduled broadcast (not VOD)."""
    lbc = (video.get("snippet") or {}).get("liveBroadcastContent") or "none"
    return lbc in ("live", "upcoming")


def _parse_iso8601_duration(duration_str: str) -> int:
    """Parse an ISO 8601 duration (e.g. ``PT15M33S``) to seconds."""
    import re

    hours = int(m.group(1)) if (m := re.search(r"(\d+)H", duration_str)) else 0
    minutes = int(m.group(1)) if (m := re.search(r"(\d+)M", duration_str)) else 0
    seconds = int(m.group(1)) if (m := re.search(r"(\d+)S", duration_str)) else 0
    return hours * 3600 + minutes * 60 + seconds


class YouTubeExtractor(BaseExtractor):
    """Extracts video metadata, transcribes audio via Whisper (segment-level
    timestamps), and upserts enriched docs to OpenSearch in a single pass.

    Parameters (passed via ``extract()``'s ``parameters`` dict):
        channel_name (str): Channel handle (e.g. ``@mkbhd``) or display name.
        api_key (str): YouTube Data API v3 key.
        openai_api_key (str): OpenAI API key for Whisper. Required when
            ``include_transcript=True``.
        max_videos (int): Maximum number of videos to extract. Default: 50.
        published_after (str | None): ISO 8601 datetime — only fetch videos
            published after this date.
        min_duration_seconds (int): Skip videos shorter than this. Default: 0.
        skip_live_streams (bool): Skip live / upcoming broadcasts (uses
            ``snippet.liveBroadcastContent``: ``live`` / ``upcoming``). Default: True.
        include_transcript (bool): Transcribe via Whisper and attach segment
            timestamps. Default: True. When ``upload_audio_to_s3=True``, still
            defaults to True unless ``include_transcript`` is explicitly set
            false in ``parameters`` (audio is downloaded twice: once for S3,
            once for Whisper — acceptable for moderate batch sizes).
        whisper_language (str): BCP-47 code for Whisper (e.g. ``"hi"``).
            Omitted → ``"en"``. Pass ``""``, ``"auto"``, or ``None`` for Whisper
            auto-detect (stored as ``auto`` in metadata).

        # --- Upload-audio-to-S3 mode ---
        upload_audio_to_s3 (bool): Default False. When True, yt-dlp downloads
            audio and uploads mp3 to S3; ``audio_s3_bucket`` / ``audio_s3_key``
            are recorded in metadata (independent of transcription).
        audio_s3_bucket (str): Target S3 bucket.
        audio_s3_prefix (str): Key prefix (e.g. ``feed/youtube/audio``).

        # --- OpenSearch upsert mode ---
        upsert_to_opensearch (bool): Default False. When True, each result is
            upserted to ``opensearch_index`` using the pulse_raw_feed schema
            (doc_id, content, metadata with transcript_segments, metadata_chunk).
            No separate transcription script needed — the adapter writes the
            final enriched doc directly.
        opensearch_index (str): Target index (e.g. ``pulse_raw_feed``).
            Alias: ``opensearch_raw_index`` accepted for backward compatibility.
        doc_id_prefix (str): Prefix for ``doc_id`` field. Default: ``"yt"``.
            E.g. ``"yt_bahujan"`` → ``"yt_bahujan_{video_id}"``.
        opensearch_url (str): Endpoint. Falls back to ``OPENSEARCH_URL`` env.
        opensearch_username / opensearch_password (str): Basic-auth creds.
            Fall back to ``OPENSEARCH_USERNAME`` / ``OPENSEARCH_PASSWORD`` env.
    """

    def get_config(self) -> ExtractorConfig:
        return ExtractorConfig(
            name="youtube",
            job_type="youtube_channel",
            timeout_seconds=3600,
            max_retries=3,
        )

    async def extract(
        self, tenant_id: str, parameters: dict[str, Any]
    ) -> list[ExtractionResult]:
        channel_name: str = parameters["channel_name"]
        api_key: str = parameters["api_key"]
        openai_api_key: str = (
            parameters.get("openai_api_key") or get_settings().pulse_openai_api_key
        )
        max_videos: int = int(parameters.get("max_videos", 50))
        published_after: str | None = parameters.get("published_after")
        min_duration_seconds: int = int(parameters.get("min_duration_seconds", 0))
        skip_live_streams: bool = bool(parameters.get("skip_live_streams", True))
        whisper_api_lang, whisper_lang_tag = _resolve_whisper_language(parameters)

        upload_audio_to_s3: bool = bool(parameters.get("upload_audio_to_s3", False))
        audio_s3_bucket: str = parameters.get("audio_s3_bucket", "")
        audio_s3_prefix: str = parameters.get("audio_s3_prefix", "").rstrip("/")

        upsert_to_opensearch: bool = bool(
            parameters.get("upsert_to_opensearch", False)
        )
        # Accept both names; opensearch_index takes precedence.
        opensearch_index: str = (
            parameters.get("opensearch_index")
            or parameters.get("opensearch_raw_index", "")
        )
        doc_id_prefix: str = parameters.get("doc_id_prefix", "yt")
        opensearch_url: str = parameters.get(
            "opensearch_url", os.environ.get("OPENSEARCH_URL", "")
        )
        opensearch_username: str = parameters.get(
            "opensearch_username", os.environ.get("OPENSEARCH_USERNAME", "")
        )
        opensearch_password: str = parameters.get(
            "opensearch_password", os.environ.get("OPENSEARCH_PASSWORD", "")
        )

        # Caller-supplied yt-dlp options — merged on top of the hard-coded
        # defaults inside ``_download_audio`` so payloads can override
        # anything (e.g. ``cookiefile``, ``extractor_args`` for alternate
        # player clients to bypass YouTube bot checks, ``proxy``, etc.)
        # without a code change. Environment fallbacks:
        #   YT_DLP_COOKIEFILE       → cookies.txt path
        #   YT_DLP_PLAYER_CLIENTS   → comma-sep list, e.g.
        #                             "tv_embedded,ios,android"
        yt_dlp_opts: dict[str, Any] = _resolve_yt_dlp_opts(parameters)

        include_transcript: bool = bool(parameters.get("include_transcript", True))
        if upload_audio_to_s3:
            # Audio-upload mode: audio lands in S3 but Whisper runs here too
            # unless explicitly disabled, so segments are available for upsert.
            if (
                "include_transcript" in parameters
                and not parameters["include_transcript"]
            ):
                include_transcript = False

        if upload_audio_to_s3 and not audio_s3_bucket:
            raise ValueError(
                "upload_audio_to_s3=True requires 'audio_s3_bucket' parameter"
            )
        if upsert_to_opensearch and not (opensearch_index and opensearch_url):
            raise ValueError(
                "upsert_to_opensearch=True requires 'opensearch_index' (or "
                "'opensearch_raw_index') and an OpenSearch URL"
            )

        logger.info(
            "youtube_extraction_started",
            tenant_id=tenant_id,
            channel_name=channel_name,
            max_videos=max_videos,
            include_transcript=include_transcript,
            upload_audio_to_s3=upload_audio_to_s3,
            upsert_to_opensearch=upsert_to_opensearch,
            whisper_language=whisper_lang_tag,
        )

        if include_transcript and not openai_api_key:
            logger.warning(
                "youtube_transcript_skipped_no_key",
                tenant_id=tenant_id,
                channel_name=channel_name,
            )
            include_transcript = False

        async with httpx.AsyncClient(timeout=30.0) as client:
            channel_id = await self._resolve_channel_id(client, api_key, channel_name)
            uploads_playlist_id = await self._get_uploads_playlist_id(
                client, api_key, channel_id
            )
            video_ids = await self._list_playlist_video_ids(
                client,
                api_key,
                uploads_playlist_id,
                max_videos=max_videos,
                published_after=published_after,
            )
            video_details = await self._get_video_details(client, api_key, video_ids)

        # Duration / live-stream filters.
        filtered: list[dict[str, Any]] = []
        for v in video_details:
            if skip_live_streams and _is_live_or_upcoming_broadcast(v):
                continue
            dur_iso = v.get("contentDetails", {}).get("duration", "PT0S")
            if min_duration_seconds > 0:
                if _parse_iso8601_duration(dur_iso) < min_duration_seconds:
                    continue
            filtered.append(v)
        video_details = filtered

        os_service = None
        if upsert_to_opensearch:
            from pulse_engine.services.opensearch import OpenSearchService

            http_auth = (
                (opensearch_username, opensearch_password)
                if opensearch_username
                else None
            )
            use_ssl = opensearch_url.startswith("https://")
            os_service = OpenSearchService(
                url=opensearch_url,
                http_auth=http_auth,
                use_ssl=use_ssl,
                verify_certs=use_ssl,
                ssl_show_warn=False,
            )

        results: list[ExtractionResult] = []
        try:
            for video in video_details:
                transcript = ""
                segments: list[dict[str, Any]] = []
                audio_s3_key = ""

                if upload_audio_to_s3:
                    audio_s3_key = await self._upload_audio_to_s3(
                        video_id=video["id"],
                        bucket=audio_s3_bucket,
                        prefix=audio_s3_prefix,
                        yt_dlp_opts=yt_dlp_opts,
                    )
                    if not audio_s3_key:
                        continue

                if include_transcript:
                    transcript, segments = await self._transcribe_with_whisper(
                        video["id"],
                        openai_api_key,
                        language=whisper_api_lang,
                        yt_dlp_opts=yt_dlp_opts,
                    )

                video_url = f"https://www.youtube.com/watch?v={video['id']}"
                metadata: dict[str, Any] = {
                    "video_id": video["id"],
                    "title": video["snippet"]["title"],
                    "channel_id": video["snippet"]["channelId"],
                    "channel_name": video["snippet"]["channelTitle"],
                    "published_at": video["snippet"]["publishedAt"],
                    "description": video["snippet"]["description"],
                    "tags": video["snippet"].get("tags", []),
                    "duration": video.get("contentDetails", {}).get("duration"),
                    "duration_seconds": _parse_iso8601_duration(
                        video.get("contentDetails", {}).get("duration", "PT0S")
                    ),
                    "view_count": video.get("statistics", {}).get("viewCount"),
                    "like_count": video.get("statistics", {}).get("likeCount"),
                    "comment_count": video.get("statistics", {}).get("commentCount"),
                    "url": video_url,
                    "has_transcript": bool(transcript),
                }
                if include_transcript:
                    metadata["whisper_language"] = whisper_lang_tag
                if upload_audio_to_s3:
                    metadata["audio_s3_bucket"] = audio_s3_bucket
                    metadata["audio_s3_key"] = audio_s3_key
                if segments:
                    # Attach phrase-level timestamps so any segment can be
                    # cross-referenced to an exact point in the video.
                    metadata["transcript_segments"] = [
                        {
                            "start": seg["start"],
                            "end": seg["end"],
                            "text": seg["text"],
                            "url_at_time": f"{video_url}?t={int(seg['start'])}",
                        }
                        for seg in segments
                    ]

                result = ExtractionResult(
                    raw_content=self._build_content(video, transcript),
                    source_id=video["id"],
                    source_type="youtube",
                    metadata=metadata,
                )
                results.append(result)

                if os_service is not None:
                    await self._upsert_doc(
                        os_service=os_service,
                        index=opensearch_index,
                        tenant_id=tenant_id,
                        channel_name=channel_name,
                        doc_id_prefix=doc_id_prefix,
                        result=result,
                    )
        finally:
            if os_service is not None:
                await os_service.close()

        if upload_audio_to_s3 and include_transcript:
            mode = "upload_audio_with_transcript"
        elif upload_audio_to_s3:
            mode = "upload_audio"
        elif include_transcript:
            mode = "inline_transcript"
        else:
            mode = "metadata_only"
        logger.info(
            "youtube_extraction_completed",
            tenant_id=tenant_id,
            channel_name=channel_name,
            video_count=len(results),
            mode=mode,
            upserted=upsert_to_opensearch,
        )
        return results

    async def on_failure(self, tenant_id: str, error: Exception) -> None:
        logger.error(
            "youtube_extraction_failed",
            tenant_id=tenant_id,
            error=str(error),
        )

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    async def _resolve_channel_id(
        self, client: httpx.AsyncClient, api_key: str, channel_name: str
    ) -> str:
        """Resolve a channel handle or display name to a channel ID."""
        handle = channel_name.lstrip("@")

        resp = await client.get(
            f"{_YOUTUBE_API_BASE}/channels",
            params={"part": "id", "forHandle": handle, "key": api_key},
        )
        resp.raise_for_status()
        items = resp.json().get("items", [])
        if items:
            return str(items[0]["id"])

        # Fall back to search (display name)
        resp = await client.get(
            f"{_YOUTUBE_API_BASE}/search",
            params={
                "part": "snippet",
                "type": "channel",
                "q": channel_name,
                "maxResults": 1,
                "key": api_key,
            },
        )
        resp.raise_for_status()
        items = resp.json().get("items", [])
        if not items:
            raise NotFoundError(
                f"YouTube channel not found: '{channel_name}'",
                channel_name=channel_name,
            )
        return str(items[0]["snippet"]["channelId"])

    async def _get_uploads_playlist_id(
        self, client: httpx.AsyncClient, api_key: str, channel_id: str
    ) -> str:
        """Return the uploads playlist ID for a channel."""
        resp = await client.get(
            f"{_YOUTUBE_API_BASE}/channels",
            params={"part": "contentDetails", "id": channel_id, "key": api_key},
        )
        resp.raise_for_status()
        items = resp.json().get("items", [])
        if not items:
            raise NotFoundError(
                f"Channel not found: {channel_id}",
                channel_id=channel_id,
            )
        return str(items[0]["contentDetails"]["relatedPlaylists"]["uploads"])

    async def _list_playlist_video_ids(
        self,
        client: httpx.AsyncClient,
        api_key: str,
        playlist_id: str,
        max_videos: int,
        published_after: str | None,
    ) -> list[str]:
        """Page through a playlist and return up to ``max_videos`` video IDs."""
        video_ids: list[str] = []
        page_token: str | None = None

        while len(video_ids) < max_videos:
            page_size = min(_MAX_PAGE_SIZE, max_videos - len(video_ids))
            params: dict[str, Any] = {
                "part": "contentDetails,snippet",
                "playlistId": playlist_id,
                "maxResults": page_size,
                "key": api_key,
            }
            if page_token:
                params["pageToken"] = page_token

            resp = await client.get(f"{_YOUTUBE_API_BASE}/playlistItems", params=params)
            resp.raise_for_status()
            data = resp.json()

            for item in data.get("items", []):
                vid_id = item["contentDetails"]["videoId"]
                if published_after:
                    published = item["snippet"].get("publishedAt", "")
                    if published < published_after:
                        continue
                video_ids.append(vid_id)

            page_token = data.get("nextPageToken")
            if not page_token:
                break

        return video_ids

    async def _get_video_details(
        self, client: httpx.AsyncClient, api_key: str, video_ids: list[str]
    ) -> list[dict[str, Any]]:
        """Batch-fetch snippet, contentDetails, and statistics for video IDs."""
        if not video_ids:
            return []

        details: list[dict[str, Any]] = []
        for i in range(0, len(video_ids), _MAX_PAGE_SIZE):
            batch = video_ids[i : i + _MAX_PAGE_SIZE]
            resp = await client.get(
                f"{_YOUTUBE_API_BASE}/videos",
                params={
                    "part": "snippet,contentDetails,statistics",
                    "id": ",".join(batch),
                    "key": api_key,
                },
            )
            resp.raise_for_status()
            details.extend(resp.json().get("items", []))

        return details

    async def _transcribe_with_whisper(
        self,
        video_id: str,
        openai_api_key: str,
        language: str = "",
        yt_dlp_opts: dict[str, Any] | None = None,
    ) -> tuple[str, list[dict[str, Any]]]:
        """Download audio and transcribe with Whisper. Returns (full_text, segments).

        Each segment has ``{start, end, text}`` keys with phrase-level timestamps.
        Large files (>24 MB) are automatically split into 10-minute chunks before
        sending to the Whisper API to stay under its 25 MB per-request limit.
        """
        url = f"https://www.youtube.com/watch?v={video_id}"

        with tempfile.TemporaryDirectory() as tmp_dir:
            audio_path = await self._download_audio(
                url, tmp_dir, yt_dlp_opts=yt_dlp_opts
            )
            if audio_path is None:
                return "", []
            full_text, segments = await self._call_whisper_api(
                audio_path, openai_api_key, language=language
            )

        return full_text, segments

    async def _upload_audio_to_s3(
        self,
        video_id: str,
        bucket: str,
        prefix: str,
        yt_dlp_opts: dict[str, Any] | None = None,
    ) -> str:
        """Download audio via yt-dlp and upload mp3 to S3. Returns the s3 key."""
        url = f"https://www.youtube.com/watch?v={video_id}"
        s3_key = f"{prefix.rstrip('/')}/{video_id}.mp3" if prefix else f"{video_id}.mp3"

        with tempfile.TemporaryDirectory() as tmp_dir:
            audio_path = await self._download_audio(
                url, tmp_dir, yt_dlp_opts=yt_dlp_opts
            )
            if audio_path is None:
                return ""

            def _upload() -> None:
                import boto3

                s3 = boto3.client("s3")
                with open(audio_path, "rb") as fobj:
                    s3.upload_fileobj(fobj, bucket, s3_key)

            try:
                await asyncio.to_thread(_upload)
            except Exception:
                logger.warning(
                    "youtube_audio_upload_failed",
                    video_id=video_id,
                    bucket=bucket,
                    key=s3_key,
                    exc_info=True,
                )
                return ""

        logger.debug(
            "youtube_audio_uploaded",
            video_id=video_id,
            bucket=bucket,
            key=s3_key,
        )
        return s3_key

    async def _upsert_doc(
        self,
        os_service: OpenSearchService,
        index: str,
        tenant_id: str,
        channel_name: str,
        doc_id_prefix: str,
        result: ExtractionResult,
    ) -> None:
        """Upsert an enriched doc to OpenSearch using the pulse_raw_feed schema.

        The shape is consistent with the reference transcription script so
        downstream consumers see a uniform schema regardless of which extractor
        produced the content. Segments (with timestamps) are embedded in
        ``metadata.segments`` when a transcript is available.
        """
        video_id   = result.metadata["video_id"]
        video_url = result.metadata.get(
            "url", f"https://www.youtube.com/watch?v={video_id}"
        )
        segments = result.metadata.get("transcript_segments", [])
        full_text = result.raw_content

        body: dict[str, Any] = {
            "doc_id":              f"{doc_id_prefix}_{video_id}",
            "source":              "youtube",
            "chunk_id":            None,
            "original_content":    full_text,
            "content":             full_text,
            "content_translation": None,
            "content_summary":     "",
            "content_title":       result.metadata.get("title", ""),
            "metadata": {
                "source_type":      "youtube",
                "tenant_id":        tenant_id,
                "language":         result.metadata.get(
                    "whisper_language", _DEFAULT_WHISPER_LANGUAGE
                ),
                "timestamp":        result.metadata.get("published_at", ""),
                "video_id":         video_id,
                "video_url":        video_url,
                "channel":          channel_name,
                "channel_id":       result.metadata.get("channel_id", ""),
                "channel_name":     result.metadata.get("channel_name", ""),
                "duration_seconds": result.metadata.get("duration_seconds", 0),
                "view_count":       result.metadata.get("view_count"),
                "like_count":       result.metadata.get("like_count"),
                "comment_count":    result.metadata.get("comment_count"),
                "tags":             result.metadata.get("tags", []),
                "audio_s3_bucket":  result.metadata.get("audio_s3_bucket", ""),
                "audio_s3_key":     result.metadata.get("audio_s3_key", ""),
                "segments":         segments,
                "extracted_at":     datetime.now(UTC).isoformat(),
            },
            "metadata_chunk": {
                "topic": "General",
            },
        }
        try:
            await os_service.index_document(
                index=index,
                doc_id=f"{doc_id_prefix}_{video_id}",
                body=body,
            )
        except Exception:
            logger.warning(
                "youtube_opensearch_upsert_failed",
                video_id=video_id,
                index=index,
                exc_info=True,
            )

    async def _download_audio(
        self,
        url: str,
        output_dir: str,
        yt_dlp_opts: dict[str, Any] | None = None,
    ) -> Path | None:
        """Download audio from a YouTube URL to a temp directory via yt-dlp.

        ``yt_dlp_opts`` is merged on top of the defaults so callers can inject
        anti-bot workarounds (``cookiefile``, alternate player clients via
        ``extractor_args``, ``proxy``, etc.) without touching this code.
        """
        try:
            import yt_dlp  # type: ignore[import]
        except ImportError:
            logger.warning("yt_dlp_not_installed", url=url)
            return None

        output_template = str(Path(output_dir) / "%(id)s.%(ext)s")
        ydl_opts: dict[str, Any] = {
            "format": "bestaudio/best",
            "outtmpl": output_template,
            "postprocessors": [
                {
                    "key": "FFmpegExtractAudio",
                    "preferredcodec": "mp3",
                    "preferredquality": "64",
                }
            ],
            "quiet": True,
            "no_warnings": True,
        }
        # ``cookies_content`` lets callers ship a Netscape-format cookies.txt
        # inline in the trigger payload. We materialize it to a temp file
        # inside ``output_dir`` so it's cleaned up when the caller removes
        # the temp dir, and point ``cookiefile`` at it. Keeps secrets out
        # of env vars and avoids baking them into the image.
        cookies_content: str = ""
        if yt_dlp_opts:
            # Deep-merge ``extractor_args`` so callers can add fields without
            # clobbering any defaults set elsewhere.
            override = dict(yt_dlp_opts)
            cookies_content = str(override.pop("cookies_content", "") or "")
            ea = override.pop("extractor_args", None)
            ydl_opts.update(override)
            if isinstance(ea, dict):
                existing_ea = ydl_opts.get("extractor_args") or {}
                merged: dict[str, Any] = {**existing_ea}
                for k, v in ea.items():
                    if isinstance(v, dict) and isinstance(merged.get(k), dict):
                        merged[k] = {**merged[k], **v}
                    else:
                        merged[k] = v
                ydl_opts["extractor_args"] = merged

        # Fall back to env if the payload didn't ship cookies inline.
        if not cookies_content:
            cookies_content = os.environ.get("YT_DLP_COOKIES_CONTENT", "").strip()

        if cookies_content and "cookiefile" not in ydl_opts:
            cookies_path = Path(output_dir) / "cookies.txt"
            cookies_path.write_text(cookies_content, encoding="utf-8")
            try:
                os.chmod(cookies_path, 0o600)
            except OSError:
                pass
            ydl_opts["cookiefile"] = str(cookies_path)
            logger.info(
                "youtube_cookies_materialized",
                path=str(cookies_path),
                chars=len(cookies_content),
            )

        def _download() -> Path | None:
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=True)
                video_id = info.get("id", "")
                # yt-dlp names the file after the post-processor codec
                candidate = Path(output_dir) / f"{video_id}.mp3"
                return candidate if candidate.exists() else None

        try:
            return await asyncio.to_thread(_download)
        except Exception:
            logger.warning("youtube_audio_download_failed", url=url, exc_info=True)
            return None

    async def _call_whisper_api(
        self,
        audio_path: Path,
        openai_api_key: str,
        language: str = "",
    ) -> tuple[str, list[dict[str, Any]]]:
        """Send audio to Whisper and return (full_text, segments).

        Uses ``verbose_json`` + ``segment`` granularity so each segment carries
        ``start`` / ``end`` timestamps. Automatically splits files larger than
        24 MB into 10-minute chunks via ffmpeg to stay under the API limit.
        """
        try:
            from openai import AsyncOpenAI  # type: ignore[import]

            client = AsyncOpenAI(api_key=openai_api_key)

            def _transcribe_file(path: Path, offset: float) -> list[dict[str, Any]]:
                import asyncio as _asyncio
                loop = _asyncio.new_event_loop()
                try:
                    with open(path, "rb") as fobj:
                        kwargs: dict[str, Any] = {
                            "model": "whisper-1",
                            "file": fobj,
                            "response_format": "verbose_json",
                            "timestamp_granularities": ["segment"],
                        }
                        if language:
                            kwargs["language"] = language
                        resp = loop.run_until_complete(
                            client.audio.transcriptions.create(**kwargs)
                        )
                finally:
                    loop.close()
                raw_segs = getattr(resp, "segments", None) or []
                return [
                    {
                        "start": float(
                            s.get("start", 0) if isinstance(s, dict) else s.start
                        ) + offset,
                        "end": float(
                            s.get("end", 0) if isinstance(s, dict) else s.end
                        ) + offset,
                        "text": (
                            s.get("text", "") if isinstance(s, dict) else s.text
                        ).strip(),
                    }
                    for s in raw_segs
                ]

            file_size = audio_path.stat().st_size

            if file_size <= _WHISPER_MAX_BYTES:
                segments = await asyncio.to_thread(_transcribe_file, audio_path, 0.0)
            else:
                # Split with ffmpeg into CHUNK_SECS-second chunks, then stitch.
                logger.info(
                    "youtube_whisper_splitting_large_file",
                    audio_path=str(audio_path),
                    size_mb=round(file_size / (1024 * 1024), 1),
                )

                def _split_and_transcribe() -> list[dict[str, Any]]:
                    with tempfile.TemporaryDirectory(prefix="whisper_chunks_") as td:
                        chunk_pattern = os.path.join(td, "chunk_%04d.mp3")
                        subprocess.run(
                            [
                                "ffmpeg", "-i", str(audio_path),
                                "-f", "segment",
                                "-segment_time", str(_WHISPER_CHUNK_SECS),
                                "-c", "copy", "-reset_timestamps", "1",
                                chunk_pattern,
                            ],
                            check=True,
                            capture_output=True,
                        )
                        chunk_files = sorted(
                            glob.glob(os.path.join(td, "chunk_*.mp3"))
                        )
                        all_segs: list[dict[str, Any]] = []
                        offset = 0.0
                        for chunk_path in chunk_files:
                            segs = _transcribe_file(Path(chunk_path), offset)
                            if segs:
                                offset = segs[-1]["end"]
                            all_segs.extend(segs)
                    return all_segs

                segments = await asyncio.to_thread(_split_and_transcribe)

            full_text = " ".join(s["text"] for s in segments)
            logger.debug(
                "youtube_whisper_transcription_done",
                audio_path=str(audio_path),
                segments=len(segments),
                chars=len(full_text),
            )
            return full_text, segments

        except Exception:
            logger.warning(
                "youtube_whisper_transcription_failed",
                audio_path=str(audio_path),
                exc_info=True,
            )
            return "", []

    @staticmethod
    def _build_content(video: dict[str, Any], transcript: str) -> str:
        """Combine video metadata and transcript into a single text document."""
        snippet = video["snippet"]
        parts = [
            f"Title: {snippet['title']}",
            f"Channel: {snippet['channelTitle']}",
            f"Published: {snippet['publishedAt']}",
            "",
            snippet["description"],
        ]
        if transcript:
            parts += ["", "Transcript:", transcript]
        return "\n".join(parts)
