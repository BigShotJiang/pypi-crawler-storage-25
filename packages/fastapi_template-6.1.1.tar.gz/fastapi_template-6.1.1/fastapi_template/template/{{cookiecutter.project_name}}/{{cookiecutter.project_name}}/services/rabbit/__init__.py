"""RabbitMQ service."""
