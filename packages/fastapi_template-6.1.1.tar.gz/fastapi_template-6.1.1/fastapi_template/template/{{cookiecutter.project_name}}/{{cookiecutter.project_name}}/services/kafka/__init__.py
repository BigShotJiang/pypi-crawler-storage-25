"""Kafka service."""
