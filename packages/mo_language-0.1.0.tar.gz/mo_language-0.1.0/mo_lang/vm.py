"""
vm.py — stack-based virtual machine for Mo bytecode.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from .compiler import Op, CompiledFn
from .interpreter import (
    Environment, Function, Klass, Instance, BoundSuper,
    RuntimeError_, Interpreter,
)


class MoThrow(Exception):
    def __init__(self, value):
        self.value = value


class VMFunction:
    def __init__(self, name: str, params: list[str], code: list, closure: Environment):
        self.name    = name
        self.params  = params
        self.code    = code
        self.closure = closure

    def __repr__(self):
        return f"<fn {self.name}({', '.join(self.params)})>"


@dataclass
class Frame:
    code:      list
    ip:        int              = 0
    env:       Environment      = field(default_factory=Environment)
    stack:     list             = field(default_factory=list)
    try_stack: list             = field(default_factory=list)
    retval:    object           = None


class VM:
    def __init__(self):
        self._interp = Interpreter()
        self.globals = self._interp.globals
        self._base_dir = '.'

    def run(self, code: list, env: Environment = None) -> None:
        if env is None:
            env = Environment(parent=self.globals)
        frame = Frame(code=code, env=env)
        self._run_frame(frame)

    def _run_frame(self, frame: Frame) -> object:
        code  = frame.code
        stack = frame.stack
        env   = frame.env

        while frame.ip < len(code):
            instr = code[frame.ip]
            frame.ip += 1
            try:
                done = self._exec(instr, frame, stack, env)
                if done:
                    return frame.retval
            except (MoThrow, RuntimeError_) as exc:
                if frame.try_stack:
                    catch_ip, err_var, depth = frame.try_stack.pop()
                    while len(stack) > depth:
                        stack.pop()
                    err_val = exc.value if isinstance(exc, MoThrow) else str(exc)
                    env.define(err_var, err_val)
                    frame.ip = catch_ip
                else:
                    raise

        return frame.retval

    def _exec(self, instr, frame: Frame, stack: list, env: Environment) -> bool:
        op, arg = instr.op, instr.arg

        if op is Op.LOAD_CONST:
            stack.append(arg)

        elif op is Op.LOAD_NAME:
            stack.append(env.get(arg))

        elif op is Op.DEFINE_NAME:
            env.define(arg, stack.pop())

        elif op is Op.STORE_NAME:
            env.set(arg, stack.pop())

        elif op is Op.POP:
            stack.pop()

        elif op is Op.BINARY_OP:
            right = stack.pop()
            left  = stack.pop()
            stack.append(self._interp._binop(arg, left, right))

        elif op is Op.UNARY_OP:
            val = stack.pop()
            if arg == '-':
                stack.append(-val)
            else:
                stack.append(not self._interp._truthy(val))

        elif op is Op.JUMP:
            frame.ip = arg

        elif op is Op.JUMP_IF_FALSE:
            if not self._interp._truthy(stack.pop()):
                frame.ip = arg

        elif op is Op.CALL:
            argc = arg
            args = list(reversed([stack.pop() for _ in range(argc)]))
            fn   = stack.pop()
            stack.append(self._call(fn, args, env))

        elif op is Op.RETURN:
            frame.retval = stack.pop()
            return True

        elif op is Op.MAKE_LIST:
            items = list(reversed([stack.pop() for _ in range(arg)]))
            stack.append(items)

        elif op is Op.MAKE_DICT:
            pairs = []
            for _ in range(arg):
                v = stack.pop()
                k = stack.pop()
                pairs.append((k, v))
            pairs.reverse()
            stack.append(dict(pairs))

        elif op is Op.INDEX_GET:
            idx = stack.pop()
            obj = stack.pop()
            stack.append(self._interp._index_get(obj, idx))

        elif op is Op.INDEX_SET:
            val = stack.pop()
            idx = stack.pop()
            obj = stack.pop()
            self._interp._index_set(obj, idx, val)
            stack.append(val)

        elif op is Op.GET_ATTR:
            obj = stack.pop()
            stack.append(self._get_attr(obj, arg))

        elif op is Op.SET_ATTR:
            val = stack.pop()
            obj = stack.pop()
            if not isinstance(obj, Instance):
                raise RuntimeError_("Can only set attributes on class instances")
            obj.fields[arg] = val
            stack.append(val)

        elif op is Op.METHOD_CALL:
            method, argc = arg
            args = list(reversed([stack.pop() for _ in range(argc)]))
            obj  = stack.pop()
            stack.append(self._call_method(obj, method, args))

        elif op is Op.MAKE_FUNCTION:
            cfn: CompiledFn = arg
            stack.append(VMFunction(cfn.name, cfn.params, cfn.code, env))

        elif op is Op.MAKE_CLASS:
            name, parent_name, method_cfns = arg
            methods = {
                mname: VMFunction(cfn.name, cfn.params, cfn.code, env)
                for mname, cfn in method_cfns.items()
            }
            parent = None
            if parent_name:
                parent = env.get(parent_name)
                if not isinstance(parent, Klass):
                    raise RuntimeError_(f"'{parent_name}' is not a class")
            stack.append(Klass(name, methods, parent))

        elif op is Op.THROW:
            raise MoThrow(stack.pop())

        elif op is Op.SETUP_TRY:
            catch_ip, err_var = arg
            frame.try_stack.append((catch_ip, err_var, len(stack)))

        elif op is Op.END_TRY:
            frame.try_stack.pop()

        elif op is Op.IMPORT:
            self._import(arg, env)

        elif op is Op.MAKE_ITER:
            lst = stack.pop()
            if not isinstance(lst, list):
                raise RuntimeError_("'for' requires a list")
            stack.append(iter(lst))

        elif op is Op.FOR_ITER:
            it = stack[-1]
            try:
                stack.append(next(it))
            except StopIteration:
                stack.pop()
                frame.ip = arg

        return False

    def _call(self, fn, args: list, env: Environment):
        if isinstance(fn, VMFunction):
            return self._invoke_vm(fn, None, args)
        if isinstance(fn, Klass):
            return self._instantiate(fn, args)
        if isinstance(fn, Function):
            return self._interp._call(fn, args)
        if callable(fn):
            return fn(args)
        raise RuntimeError_(f"{fn!r} is not callable")

    def _instantiate(self, klass: Klass, args: list):
        instance = Instance(klass)
        init = self._interp._lookup_method(klass, "init")
        if init:
            self._invoke_callable(init, args, instance=instance)
        return instance

    def _call_method(self, obj, method: str, args: list):
        if isinstance(obj, (str, list)):
            return self._interp._call_method(obj, method, args)
        if isinstance(obj, Instance):
            fn = self._interp._lookup_method(obj.klass, method)
            if fn is None:
                raise RuntimeError_(f"'{obj.klass.name}' has no method '{method}'")
            return self._invoke_callable(fn, args, instance=obj)
        if isinstance(obj, BoundSuper):
            fn = self._interp._lookup_method(obj.klass, method)
            if fn is None:
                raise RuntimeError_(f"super has no method '{method}'")
            return self._invoke_callable(fn, args, instance=obj.instance,
                                         super_klass=obj.klass.parent)
        raise RuntimeError_(
            f"Cannot call method on {self._interp._builtin_type([obj])}"
        )

    def _get_attr(self, obj, attr: str):
        if isinstance(obj, Instance):
            if attr in obj.fields:
                return obj.fields[attr]
            fn = self._interp._lookup_method(obj.klass, attr)
            if fn is not None:
                return fn
            raise RuntimeError_(f"'{obj.klass.name}' has no attribute '{attr}'")
        if isinstance(obj, BoundSuper):
            fn = self._interp._lookup_method(obj.klass, attr)
            if fn is not None:
                return fn
            raise RuntimeError_(f"super has no attribute '{attr}'")
        if isinstance(obj, str):
            return self._interp._str_method(obj, attr)
        raise RuntimeError_(
            f"Cannot get attribute '{attr}' on {self._interp._builtin_type([obj])}"
        )

    def _invoke_callable(self, fn, args: list, instance=None, super_klass=None):
        if isinstance(fn, VMFunction):
            return self._invoke_vm(fn, instance, args, super_klass)
        if isinstance(fn, Function):
            if instance is not None:
                return self._interp._invoke_method(fn, instance, args, super_klass)
            return self._interp._call(fn, args)
        if callable(fn):
            return fn(args)
        raise RuntimeError_(f"{fn!r} is not callable")

    def _invoke_vm(self, fn: VMFunction, instance, args: list, super_klass=None):
        if len(args) != len(fn.params):
            raise RuntimeError_(
                f"{fn.name}() expects {len(fn.params)} args, got {len(args)}"
            )
        call_env = Environment(parent=fn.closure)
        if instance is not None:
            call_env.define("self", instance)
            if super_klass is not None:
                call_env.define("super", BoundSuper(super_klass, instance))
            elif isinstance(instance, Instance) and instance.klass.parent:
                call_env.define("super", BoundSuper(instance.klass.parent, instance))
        for param, val in zip(fn.params, args):
            call_env.define(param, val)
        frame = Frame(code=fn.code, env=call_env)
        return self._run_frame(frame)

    def _import(self, path: str, env: Environment):
        import os
        from .lexer import Lexer, LexError
        from .parser import Parser, ParseError
        from .compiler import Compiler
        full = os.path.join(
            self._base_dir, path if path.endswith('.mo') else path + '.mo'
        )
        if not os.path.exists(full):
            pkg_fallback = os.path.join(
                os.path.dirname(__file__), path if path.endswith('.mo') else path + '.mo'
            )
            if os.path.exists(pkg_fallback):
                full = pkg_fallback
            else:
                raise RuntimeError_(f"Cannot find module '{path}'")
        source = open(full).read()
        try:
            tokens = Lexer(source).tokenize()
            ast    = Parser(tokens).parse()
            code   = Compiler().compile(ast)
        except Exception as e:
            raise RuntimeError_(f"Error in module '{path}': {e}")
        mod_env = Environment(parent=self.globals)
        mod_frame = Frame(code=code, env=mod_env)
        self._run_frame(mod_frame)
        for name, val in mod_env.vars.items():
            env.define(name, val)
