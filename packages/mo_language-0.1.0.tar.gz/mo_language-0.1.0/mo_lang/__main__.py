"""
mo_lang.__main__ — entry point for the Mo language.
Invoked via `mo` console script or `python -m mo_lang`.

Usage:
    mo program.mo        # compile + run (bytecode VM)
    mo                   # interactive REPL
    mo --interp file.mo  # tree-walk interpreter (fallback)
    mo --dis file.mo     # disassemble bytecode
"""
import sys
from .lexer import Lexer, LexError
from .parser import Parser, ParseError
from .interpreter import RuntimeError_


def _parse(source: str):
    tokens = Lexer(source).tokenize()
    return Parser(tokens).parse()


# ── VM path ───────────────────────────────────────────────────────────────────

def vm_execute(source: str, vm, env=None):
    from .compiler import Compiler
    from .vm import MoThrow
    try:
        code = Compiler().compile(_parse(source))
        vm.run(code, env)
    except LexError as e:
        print(f"[Lex Error] {e}")
    except ParseError as e:
        print(f"[Parse Error] {e}")
    except MoThrow as e:
        print(f"[Uncaught throw] {e.value}")
    except RuntimeError_ as e:
        print(f"[Runtime Error] {e}")


def vm_repl():
    from .vm import VM
    from .interpreter import Environment
    machine = VM()
    env = Environment(parent=machine.globals)
    print("Mo REPL  (type 'exit' to quit)")
    while True:
        try:
            line = input(">>> ")
        except (EOFError, KeyboardInterrupt):
            print("\nBye!")
            break
        if line.strip() == "exit":
            break
        if line.strip():
            vm_execute(line, machine, env)


def vm_run_file(path: str):
    import os
    from .vm import VM
    try:
        source = open(path).read()
    except FileNotFoundError:
        print(f"File not found: {path}")
        sys.exit(1)
    machine = VM()
    machine._base_dir = os.path.dirname(os.path.abspath(path))
    vm_execute(source, machine)


# ── disassembler ──────────────────────────────────────────────────────────────

def disassemble(path: str):
    from .compiler import Compiler
    try:
        source = open(path).read()
    except FileNotFoundError:
        print(f"File not found: {path}")
        sys.exit(1)
    try:
        code = Compiler().compile(_parse(source))
    except (LexError, ParseError) as e:
        print(f"[Error] {e}")
        sys.exit(1)
    _dis_code(code, "<module>")


def _dis_code(code: list, name: str, indent: int = 0):
    from .compiler import Op
    pad = "  " * indent
    print(f"{pad}=== {name} ===")
    for i, instr in enumerate(code):
        if instr.op is Op.MAKE_FUNCTION:
            print(f"{pad}{i:4d}  {instr.op.name}  {instr.arg.name}")
            _dis_code(instr.arg.code, instr.arg.name, indent + 1)
        elif instr.op is Op.MAKE_CLASS:
            cname, parent, methods = instr.arg
            print(f"{pad}{i:4d}  {instr.op.name}  {cname}"
                  + (f" extends {parent}" if parent else ""))
            for mname, cfn in methods.items():
                _dis_code(cfn.code, f"{cname}.{mname}", indent + 1)
        else:
            arg_str = "" if instr.arg is None else f"  {instr.arg!r}"
            print(f"{pad}{i:4d}  {instr.op.name}{arg_str}")


# ── interpreter fallback ──────────────────────────────────────────────────────

def interp_run_file(path: str):
    import os
    from .interpreter import Interpreter
    try:
        source = open(path).read()
    except FileNotFoundError:
        print(f"File not found: {path}")
        sys.exit(1)
    interp = Interpreter()
    interp._base_dir = os.path.dirname(os.path.abspath(path))
    try:
        interp.run(_parse(source))
    except LexError as e:
        print(f"[Lex Error] {e}")
    except ParseError as e:
        print(f"[Parse Error] {e}")
    except RuntimeError_ as e:
        print(f"[Runtime Error] {e}")


# ── entry point ───────────────────────────────────────────────────────────────

def main():
    args = sys.argv[1:]
    if args and args[0] == "--interp":
        if len(args) < 2:
            print("Usage: mo --interp <file.mo>")
            sys.exit(1)
        interp_run_file(args[1])
    elif args and args[0] == "--dis":
        if len(args) < 2:
            print("Usage: mo --dis <file.mo>")
            sys.exit(1)
        disassemble(args[1])
    elif args:
        vm_run_file(args[0])
    else:
        vm_repl()


if __name__ == "__main__":
    main()
