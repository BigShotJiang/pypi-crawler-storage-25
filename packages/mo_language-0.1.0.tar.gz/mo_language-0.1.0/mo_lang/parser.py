"""
Parser — turns a list of tokens into an AST.

Uses recursive descent: each grammar rule is one method.

Grammar (simplified):
    program     = stmt*
    stmt        = let_stmt | assign_stmt | if_stmt | while_stmt | fn_def
                | return_stmt | expr_stmt
    expr        = or_expr
    or_expr     = and_expr  ( "||" and_expr )*
    and_expr    = equality  ( "&&" equality )*
    equality    = compare   ( ("==" | "!=") compare )*
    compare     = add_sub   ( ("<" | ">" | "<=" | ">=") add_sub )*
    add_sub     = mul_div   ( ("+" | "-") mul_div )*
    mul_div     = unary     ( ("*" | "/") unary )*
    unary       = ("-" | "!") unary | primary
    primary     = NUMBER | STRING | "true" | "false"
                | IDENT "(" args ")"     <- function call
                | IDENT                  <- variable
                | "(" expr ")"
"""
from __future__ import annotations
from .lexer import TT, Token
from .ast_nodes import *


class ParseError(Exception):
    pass


class Parser:
    def __init__(self, tokens: list[Token]):
        self.tokens = tokens
        self.pos    = 0

    # ── helpers ───────────────────────────────────────────────────────────────

    def _peek(self) -> Token:
        return self.tokens[self.pos]

    def _peek_type(self) -> TT:
        return self.tokens[self.pos].type

    def _advance(self) -> Token:
        tok = self.tokens[self.pos]
        self.pos += 1
        return tok

    def _check(self, *types: TT) -> bool:
        return self._peek_type() in types

    def _match(self, *types: TT) -> Token | None:
        if self._check(*types):
            return self._advance()
        return None

    def _expect(self, tt: TT) -> Token:
        if self._peek_type() == tt:
            return self._advance()
        tok = self._peek()
        raise ParseError(f"Expected {tt.name}, got {tok.type.name} {tok.value!r} at line {tok.line}")

    def _skip_newlines(self):
        while self._check(TT.NEWLINE):
            self._advance()

    # ── program ───────────────────────────────────────────────────────────────

    def parse(self) -> list:
        stmts = []
        self._skip_newlines()
        while not self._check(TT.EOF):
            stmts.append(self._stmt())
            self._skip_newlines()
        return stmts

    # ── statements ────────────────────────────────────────────────────────────

    def _stmt(self):
        tt = self._peek_type()
        if tt == TT.LET:    return self._let_stmt()
        if tt == TT.IF:     return self._if_stmt()
        if tt == TT.WHILE:  return self._while_stmt()
        if tt == TT.FOR:    return self._for_stmt()
        if tt == TT.TRY:    return self._try_stmt()
        if tt == TT.THROW:  return self._throw_stmt()
        if tt == TT.IMPORT: return self._import_stmt()
        if tt == TT.CLASS:  return self._class_def()
        if tt == TT.FN:     return self._fn_def()
        if tt == TT.RETURN: return self._return_stmt()
        if tt == TT.IDENT and self.pos + 1 < len(self.tokens):
            nxt = self.tokens[self.pos + 1].type
            if nxt == TT.ASSIGN:
                return self._assign_stmt()
            if nxt == TT.LBRACKET:
                return self._index_assign_or_expr()
            if nxt == TT.DOT and self._is_attr_assign():
                return self._attr_assign_stmt()
        return self._expr_stmt()

    def _let_stmt(self) -> LetStmt:
        self._expect(TT.LET)
        name = self._expect(TT.IDENT).value
        self._expect(TT.ASSIGN)
        value = self._expr()
        self._end_stmt()
        return LetStmt(name, value)

    def _assign_stmt(self) -> AssignStmt:
        name = self._advance().value   # IDENT
        self._advance()                # ASSIGN
        value = self._expr()
        self._end_stmt()
        return AssignStmt(name, value)

    def _if_stmt(self) -> IfStmt:
        self._expect(TT.IF)
        condition = self._expr()
        self._skip_newlines()
        self._expect(TT.LBRACE)
        then_body = self._block()
        else_body = []
        self._skip_newlines()
        if self._match(TT.ELSE):
            self._skip_newlines()
            if self._check(TT.IF):
                else_body = [self._if_stmt()]
            else:
                self._expect(TT.LBRACE)
                else_body = self._block()
        return IfStmt(condition, then_body, else_body)

    def _while_stmt(self) -> WhileStmt:
        self._expect(TT.WHILE)
        condition = self._expr()
        self._skip_newlines()
        self._expect(TT.LBRACE)
        body = self._block()
        return WhileStmt(condition, body)

    def _fn_def(self) -> FnDef:
        self._expect(TT.FN)
        name = self._expect(TT.IDENT).value
        self._expect(TT.LPAREN)
        params = []
        if not self._check(TT.RPAREN):
            params.append(self._expect(TT.IDENT).value)
            while self._match(TT.COMMA):
                params.append(self._expect(TT.IDENT).value)
        self._expect(TT.RPAREN)
        self._skip_newlines()
        self._expect(TT.LBRACE)
        body = self._block()
        return FnDef(name, params, body)

    def _for_stmt(self) -> ForStmt:
        self._expect(TT.FOR)
        var = self._expect(TT.IDENT).value
        self._expect(TT.IN)
        iter_expr = self._expr()
        self._skip_newlines()
        self._expect(TT.LBRACE)
        body = self._block()
        return ForStmt(var, iter_expr, body)

    def _try_stmt(self) -> TryCatch:
        self._expect(TT.TRY)
        self._skip_newlines()
        self._expect(TT.LBRACE)
        try_body = self._block()
        self._skip_newlines()
        self._expect(TT.CATCH)
        err_var = self._expect(TT.IDENT).value
        self._skip_newlines()
        self._expect(TT.LBRACE)
        catch_body = self._block()
        return TryCatch(try_body, err_var, catch_body)

    def _class_def(self) -> ClassDef:
        self._expect(TT.CLASS)
        name = self._expect(TT.IDENT).value
        parent = None
        if self._match(TT.EXTENDS):
            parent = self._expect(TT.IDENT).value
        self._skip_newlines()
        self._expect(TT.LBRACE)
        methods = []
        self._skip_newlines()
        while not self._check(TT.RBRACE, TT.EOF):
            if self._check(TT.FN):
                methods.append(self._fn_def())
            self._skip_newlines()
        self._expect(TT.RBRACE)
        return ClassDef(name, parent, methods)

    def _is_attr_assign(self) -> bool:
        """Peek: IDENT (DOT IDENT)+ ASSIGN ?"""
        i = self.pos
        if self.tokens[i].type != TT.IDENT:
            return False
        i += 1
        while i < len(self.tokens) and self.tokens[i].type == TT.DOT:
            i += 1
            if i >= len(self.tokens) or self.tokens[i].type != TT.IDENT:
                return False
            i += 1
        return i < len(self.tokens) and self.tokens[i].type == TT.ASSIGN

    def _attr_assign_stmt(self):
        obj = Ident(self._advance().value)   # base IDENT
        while self._check(TT.DOT):
            self._advance()                  # DOT
            attr = self._expect(TT.IDENT).value
            if self._check(TT.DOT):
                obj = GetAttr(obj, attr)
            else:
                self._expect(TT.ASSIGN)
                value = self._expr()
                self._end_stmt()
                return ExprStmt(SetAttr(obj, attr, value))
        raise ParseError("Invalid attribute assignment")

    def _import_stmt(self) -> ImportStmt:
        self._expect(TT.IMPORT)
        path = self._expect(TT.STRING).value
        self._end_stmt()
        return ImportStmt(path)

    def _throw_stmt(self) -> ThrowStmt:
        self._expect(TT.THROW)
        value = self._expr()
        self._end_stmt()
        return ThrowStmt(value)

    def _return_stmt(self) -> ReturnStmt:
        self._expect(TT.RETURN)
        value = None
        if not self._check(TT.NEWLINE, TT.EOF):
            value = self._expr()
        self._end_stmt()
        return ReturnStmt(value)

    def _index_assign_or_expr(self):
        """ident[expr] = expr   OR   just an expression statement."""
        saved = self.pos
        try:
            name  = self._advance().value        # IDENT
            self._advance()                       # [
            index = self._expr()
            self._expect(TT.RBRACKET)
            if self._check(TT.ASSIGN):
                self._advance()
                value = self._expr()
                self._end_stmt()
                return ExprStmt(IndexSet(Ident(name), index, value))
        except Exception:
            pass
        self.pos = saved
        return self._expr_stmt()

    def _expr_stmt(self) -> ExprStmt:
        expr = self._expr()
        self._end_stmt()
        return ExprStmt(expr)

    def _block(self) -> list:
        """Parse statements until } """
        stmts = []
        self._skip_newlines()
        while not self._check(TT.RBRACE, TT.EOF):
            stmts.append(self._stmt())
            self._skip_newlines()
        self._expect(TT.RBRACE)
        return stmts

    def _end_stmt(self):
        if not self._check(TT.NEWLINE, TT.EOF, TT.RBRACE):
            raise ParseError(f"Expected newline after statement, got {self._peek()}")
        self._match(TT.NEWLINE)

    # ── expressions (precedence climbing) ────────────────────────────────────

    def _expr(self):
        return self._or_expr()

    def _or_expr(self):
        left = self._and_expr()
        while self._check(TT.OR):
            self._advance()
            left = BinOp("||", left, self._and_expr())
        return left

    def _and_expr(self):
        left = self._equality()
        while self._check(TT.AND):
            self._advance()
            left = BinOp("&&", left, self._equality())
        return left

    def _equality(self):
        left = self._compare()
        while self._check(TT.EQ, TT.NEQ):
            op = self._advance().type
            left = BinOp("==" if op == TT.EQ else "!=", left, self._compare())
        return left

    def _compare(self):
        left = self._add_sub()
        OPS = {TT.LT: "<", TT.GT: ">", TT.LTE: "<=", TT.GTE: ">="}
        while self._check(*OPS):
            op = OPS[self._advance().type]
            left = BinOp(op, left, self._add_sub())
        return left

    def _add_sub(self):
        left = self._mul_div()
        while self._check(TT.PLUS, TT.MINUS):
            op = "+" if self._advance().type == TT.PLUS else "-"
            left = BinOp(op, left, self._mul_div())
        return left

    def _mul_div(self):
        left = self._unary()
        while self._check(TT.STAR, TT.SLASH):
            op = "*" if self._advance().type == TT.STAR else "/"
            left = BinOp(op, left, self._unary())
        return left

    def _unary(self):
        if self._check(TT.MINUS):
            self._advance()
            return UnaryOp("-", self._unary())
        if self._check(TT.BANG):
            self._advance()
            return UnaryOp("!", self._unary())
        return self._primary()

    def _primary(self):
        tok = self._peek()

        if tok.type == TT.NUMBER:
            self._advance()
            return self._chain(Number(tok.value))

        if tok.type == TT.STRING:
            self._advance()
            return self._chain(String(tok.value))

        if tok.type == TT.TRUE:
            self._advance()
            return Bool(True)

        if tok.type == TT.FALSE:
            self._advance()
            return Bool(False)

        if tok.type == TT.NULL:
            self._advance()
            return Null()

        if tok.type == TT.IDENT and tok.value == "super":
            self._advance()
            return self._chain(Ident("super"))

        if tok.type == TT.LBRACE:
            self._advance()
            pairs = []
            self._skip_newlines()
            while not self._check(TT.RBRACE, TT.EOF):
                key = self._expr()
                self._expect(TT.COLON)
                val = self._expr()
                pairs.append((key, val))
                self._skip_newlines()
                if not self._check(TT.RBRACE):
                    self._expect(TT.COMMA)
                    self._skip_newlines()
            self._expect(TT.RBRACE)
            return self._chain(DictLiteral(pairs))

        if tok.type == TT.LBRACKET:
            self._advance()
            elements = []
            if not self._check(TT.RBRACKET):
                elements.append(self._expr())
                while self._match(TT.COMMA):
                    self._skip_newlines()
                    if self._check(TT.RBRACKET):
                        break
                    elements.append(self._expr())
            self._expect(TT.RBRACKET)
            return self._chain(ListLiteral(elements))

        if tok.type == TT.IDENT:
            self._advance()
            if self._check(TT.LPAREN):
                self._advance()
                args = []
                if not self._check(TT.RPAREN):
                    args.append(self._expr())
                    while self._match(TT.COMMA):
                        args.append(self._expr())
                self._expect(TT.RPAREN)
                node = Call(tok.value, args)
            else:
                node = Ident(tok.value)
            return self._chain(node)

        if tok.type == TT.LPAREN:
            self._advance()
            expr = self._expr()
            self._expect(TT.RPAREN)
            return self._chain(expr)

        raise ParseError(f"Unexpected token {tok.type.name} {tok.value!r} at line {tok.line}")

    def _chain(self, node):
        """Chain .attr, .method(args), [index] after any expression."""
        while True:
            if self._check(TT.DOT):
                self._advance()
                attr = self._expect(TT.IDENT).value
                if self._check(TT.LPAREN):
                    self._advance()
                    args = []
                    if not self._check(TT.RPAREN):
                        args.append(self._expr())
                        while self._match(TT.COMMA):
                            args.append(self._expr())
                    self._expect(TT.RPAREN)
                    node = MethodCall(node, attr, args)
                else:
                    node = GetAttr(node, attr)
            elif self._check(TT.LBRACKET):
                self._advance()
                index = self._expr()
                self._expect(TT.RBRACKET)
                node = IndexGet(node, index)
            else:
                break
        return node
