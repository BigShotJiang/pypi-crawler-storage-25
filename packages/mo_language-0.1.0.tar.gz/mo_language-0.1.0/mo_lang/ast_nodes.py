"""
AST Nodes — the tree structure produced by the Parser.
Each node represents one piece of the program.
"""
from __future__ import annotations
from dataclasses import dataclass, field


# ── Expressions (produce a value) ────────────────────────────────────────────

@dataclass
class Number:
    value: float

@dataclass
class String:
    value: str

@dataclass
class Bool:
    value: bool

@dataclass
class Ident:
    name: str

@dataclass
class BinOp:
    op:    str   # + - * / == != < > <= >= && ||
    left:  object
    right: object

@dataclass
class UnaryOp:
    op:    str   # - !
    right: object

@dataclass
class Call:
    name: str
    args: list

@dataclass
class ListLiteral:
    elements: list

@dataclass
class IndexGet:
    obj:   object
    index: object

@dataclass
class IndexSet:
    obj:   object
    index: object
    value: object

# ── Statements (do something) ─────────────────────────────────────────────────

@dataclass
class LetStmt:
    name:  str
    value: object

@dataclass
class AssignStmt:
    name:  str
    value: object

@dataclass
class IfStmt:
    condition: object
    then_body: list
    else_body: list = field(default_factory=list)

@dataclass
class WhileStmt:
    condition: object
    body:      list

@dataclass
class FnDef:
    name:   str
    params: list[str]
    body:   list

@dataclass
class ReturnStmt:
    value: object

@dataclass
class ForStmt:
    var:  str
    iter: object   # expression that produces a list
    body: list

@dataclass
class TryCatch:
    try_body:   list
    err_var:    str
    catch_body: list

@dataclass
class ThrowStmt:
    value: object

@dataclass
class ExprStmt:
    expr: object

@dataclass
class Null:
    pass

@dataclass
class DictLiteral:
    pairs: list   # list of (key_expr, value_expr)

@dataclass
class ImportStmt:
    path: str

@dataclass
class ClassDef:
    name:    str
    parent:  object   # str parent name, or None
    methods: list     # list of FnDef

@dataclass
class GetAttr:
    obj:  object
    attr: str

@dataclass
class SetAttr:
    obj:   object
    attr:  str
    value: object

@dataclass
class MethodCall:
    obj:    object
    method: str
    args:   list
