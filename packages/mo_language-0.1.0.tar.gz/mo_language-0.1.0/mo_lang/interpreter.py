"""
Interpreter — walks the AST and executes it.

Uses an Environment (scope chain) to store variables.
Functions are first-class values stored in the same environment.
"""
from __future__ import annotations
from .ast_nodes import *


class ReturnSignal(Exception):
    def __init__(self, value):
        self.value = value

class ThrowSignal(Exception):
    def __init__(self, value):
        self.value = value


class RuntimeError_(Exception):
    pass


class Environment:
    def __init__(self, parent: Environment | None = None):
        self.vars   = {}
        self.parent = parent

    def get(self, name: str):
        if name in self.vars:
            return self.vars[name]
        if self.parent:
            return self.parent.get(name)
        raise RuntimeError_(f"Undefined variable '{name}'")

    def set(self, name: str, value):
        if name in self.vars:
            self.vars[name] = value
            return
        if self.parent:
            self.parent.set(name, value)
            return
        raise RuntimeError_(f"Undefined variable '{name}' (use 'let' to declare)")

    def define(self, name: str, value):
        self.vars[name] = value


class Function:
    def __init__(self, name: str, params: list[str], body: list, closure: Environment):
        self.name    = name
        self.params  = params
        self.body    = body
        self.closure = closure

    def __repr__(self):
        return f"<fn {self.name}({', '.join(self.params)})>"


class Klass:
    def __init__(self, name: str, methods: dict, parent=None):
        self.name    = name
        self.methods = methods
        self.parent  = parent

    def __repr__(self):
        return f"<class {self.name}>"


class BoundSuper:
    def __init__(self, klass: Klass, instance):
        self.klass    = klass
        self.instance = instance


class Instance:
    def __init__(self, klass: Klass):
        self.klass  = klass
        self.fields = {}

    def __repr__(self):
        return f"<{self.klass.name} instance>"


class Interpreter:
    def __init__(self):
        self.globals = Environment()
        self._register_builtins()

    def _register_builtins(self):
        self.globals.define("print",  self._builtin_print)
        self.globals.define("len",    self._builtin_len)
        self.globals.define("str",    self._builtin_str)
        self.globals.define("num",    self._builtin_num)
        self.globals.define("type",   self._builtin_type)
        self.globals.define("range",  self._builtin_range)
        self.globals.define("push",   self._builtin_push)
        self.globals.define("pop",    self._builtin_pop)
        self.globals.define("input",  self._builtin_input)
        self.globals.define("keys",   self._builtin_keys)
        self.globals.define("has",    self._builtin_has)
        self.globals.define("delete", self._builtin_delete)
        self.globals.define("floor",  self._builtin_floor)
        self.globals.define("ceil",   self._builtin_ceil)
        self.globals.define("round",  self._builtin_round)
        self.globals.define("abs",    self._builtin_abs)

    def run(self, stmts: list, env: Environment = None):
        if env is None:
            env = Environment(parent=self.globals)
        for stmt in stmts:
            self._exec(stmt, env)

    def _exec(self, node, env: Environment):
        t = type(node)
        if t is LetStmt:
            env.define(node.name, self._eval(node.value, env))
        elif t is AssignStmt:
            env.set(node.name, self._eval(node.value, env))
        elif t is IfStmt:
            if self._truthy(self._eval(node.condition, env)):
                self._exec_block(node.then_body, env)
            elif node.else_body:
                self._exec_block(node.else_body, env)
        elif t is WhileStmt:
            while self._truthy(self._eval(node.condition, env)):
                self._exec_block(node.body, env)
        elif t is FnDef:
            env.define(node.name, Function(node.name, node.params, node.body, env))
        elif t is ReturnStmt:
            raise ReturnSignal(self._eval(node.value, env) if node.value is not None else None)
        elif t is ForStmt:
            iterable = self._eval(node.iter, env)
            if not isinstance(iterable, list):
                raise RuntimeError_("'for' requires a list")
            for item in iterable:
                local = Environment(parent=env)
                local.define(node.var, item)
                try:
                    for stmt in node.body:
                        self._exec(stmt, local)
                except ReturnSignal:
                    raise
        elif t is TryCatch:
            try:
                self._exec_block(node.try_body, env)
            except ThrowSignal as e:
                local = Environment(parent=env)
                local.define(node.err_var, e.value)
                self._exec_block(node.catch_body, local)
            except RuntimeError_ as e:
                local = Environment(parent=env)
                local.define(node.err_var, str(e))
                self._exec_block(node.catch_body, local)
        elif t is ThrowStmt:
            raise ThrowSignal(self._eval(node.value, env))
        elif t is ImportStmt:
            self._import(node.path, env)
        elif t is ClassDef:
            methods = {fn.name: Function(fn.name, fn.params, fn.body, env)
                       for fn in node.methods}
            parent = env.get(node.parent) if node.parent else None
            if node.parent and not isinstance(parent, Klass):
                raise RuntimeError_(f"'{node.parent}' is not a class")
            env.define(node.name, Klass(node.name, methods, parent))
        elif t is ExprStmt:
            self._eval(node.expr, env)
        else:
            raise RuntimeError_(f"Unknown statement: {node}")

    def _exec_block(self, stmts: list, parent_env: Environment):
        local = Environment(parent=parent_env)
        for stmt in stmts:
            self._exec(stmt, local)

    def _eval(self, node, env: Environment):
        t = type(node)
        if t is Number:
            return node.value
        elif t is String:
            return node.value
        elif t is Bool:
            return node.value
        elif t is Ident:
            return env.get(node.name)
        elif t is BinOp:
            return self._binop(node.op, self._eval(node.left, env), self._eval(node.right, env))
        elif t is UnaryOp:
            val = self._eval(node.right, env)
            if node.op == "-": return -val
            if node.op == "!": return not self._truthy(val)
        elif t is Call:
            fn   = env.get(node.name)
            args = [self._eval(arg, env) for arg in node.args]
            return self._call(fn, args)
        elif t is Null:
            return None
        elif t is DictLiteral:
            return {self._eval(k, env): self._eval(v, env) for k, v in node.pairs}
        elif t is ListLiteral:
            return [self._eval(e, env) for e in node.elements]
        elif t is IndexGet:
            obj = self._eval(node.obj, env)
            idx = self._eval(node.index, env)
            return self._index_get(obj, idx)
        elif t is IndexSet:
            obj = self._eval(node.obj, env)
            idx = self._eval(node.index, env)
            val = self._eval(node.value, env)
            return self._index_set(obj, idx, val)
        elif t is GetAttr:
            obj = self._eval(node.obj, env)
            return self._get_attr(obj, node.attr)
        elif t is SetAttr:
            obj = self._eval(node.obj, env)
            val = self._eval(node.value, env)
            if not isinstance(obj, Instance):
                raise RuntimeError_("Can only set attributes on class instances")
            obj.fields[node.attr] = val
            return val
        elif t is MethodCall:
            obj  = self._eval(node.obj, env)
            args = [self._eval(a, env) for a in node.args]
            return self._call_method(obj, node.method, args)
        else:
            raise RuntimeError_(f"Unknown expression: {node}")

    def _binop(self, op: str, left, right):
        if op == "+":
            if isinstance(left, str) or isinstance(right, str):
                return str(left) + str(right)
            return left + right
        if op == "-":  return left - right
        if op == "*":  return left * right
        if op == "/":
            if right == 0:
                raise RuntimeError_("Division by zero")
            return left / right
        if op == "==": return left == right
        if op == "!=": return left != right
        if op == "<":  return left < right
        if op == ">":  return left > right
        if op == "<=": return left <= right
        if op == ">=": return left >= right
        if op == "&&": return self._truthy(left) and self._truthy(right)
        if op == "||": return self._truthy(left) or  self._truthy(right)
        raise RuntimeError_(f"Unknown operator: {op}")

    def _lookup_method(self, klass: Klass, name: str):
        k = klass
        while k is not None:
            if name in k.methods:
                return k.methods[name]
            k = k.parent
        return None

    def _get_attr(self, obj, attr: str):
        if isinstance(obj, Instance):
            if attr in obj.fields:
                return obj.fields[attr]
            fn = self._lookup_method(obj.klass, attr)
            if fn is not None:
                return fn
            raise RuntimeError_(f"'{obj.klass.name}' has no attribute '{attr}'")
        if isinstance(obj, BoundSuper):
            fn = self._lookup_method(obj.klass, attr)
            if fn is not None:
                return fn
            raise RuntimeError_(f"super has no attribute '{attr}'")
        if isinstance(obj, str):
            return self._str_method(obj, attr)
        raise RuntimeError_(f"Cannot get attribute '{attr}' on {self._builtin_type([obj])}")

    def _call_method(self, obj, method: str, args: list):
        if isinstance(obj, Instance):
            fn = self._lookup_method(obj.klass, method)
            if fn is None:
                raise RuntimeError_(f"'{obj.klass.name}' has no method '{method}'")
            return self._invoke_method(fn, obj, args)
        if isinstance(obj, BoundSuper):
            fn = self._lookup_method(obj.klass, method)
            if fn is None:
                raise RuntimeError_(f"super has no method '{method}'")
            return self._invoke_method(fn, obj.instance, args, super_klass=obj.klass.parent)
        if isinstance(obj, str):
            return self._call_str_method(obj, method, args)
        if isinstance(obj, list):
            return self._call_list_method(obj, method, args)
        raise RuntimeError_(f"Cannot call method on {self._builtin_type([obj])}")

    def _invoke_method(self, fn, instance, args: list, super_klass=None):
        if len(args) != len(fn.params):
            raise RuntimeError_(f"{fn.name}() expects {len(fn.params)} args, got {len(args)}")
        call_env = Environment(parent=fn.closure)
        call_env.define("self", instance)
        if super_klass is not None:
            call_env.define("super", BoundSuper(super_klass, instance))
        elif isinstance(instance, Instance) and instance.klass.parent:
            call_env.define("super", BoundSuper(instance.klass.parent, instance))
        for param, arg in zip(fn.params, args):
            call_env.define(param, arg)
        try:
            for stmt in fn.body:
                self._exec(stmt, call_env)
        except ReturnSignal as r:
            return r.value
        return None

    def _call(self, fn, args: list):
        if callable(fn):
            return fn(args)
        if isinstance(fn, Klass):
            instance = Instance(fn)
            init = self._lookup_method(fn, "init")
            if init:
                if len(args) != len(init.params):
                    raise RuntimeError_(f"{fn.name}.init() expects {len(init.params)} args, got {len(args)}")
                call_env = Environment(parent=init.closure)
                call_env.define("self", instance)
                if fn.parent:
                    call_env.define("super", BoundSuper(fn.parent, instance))
                for param, arg in zip(init.params, args):
                    call_env.define(param, arg)
                try:
                    for stmt in init.body:
                        self._exec(stmt, call_env)
                except ReturnSignal:
                    pass
            return instance
        if not isinstance(fn, Function):
            raise RuntimeError_(f"{fn!r} is not callable")
        if len(args) != len(fn.params):
            raise RuntimeError_(f"{fn.name}() expects {len(fn.params)} args, got {len(args)}")
        call_env = Environment(parent=fn.closure)
        for param, arg in zip(fn.params, args):
            call_env.define(param, arg)
        try:
            for stmt in fn.body:
                self._exec(stmt, call_env)
        except ReturnSignal as r:
            return r.value
        return None

    def _truthy(self, val) -> bool:
        if val is None or val is False:
            return False
        if isinstance(val, (int, float)) and val == 0:
            return False
        if isinstance(val, str) and val == "":
            return False
        return True

    def _builtin_print(self, args):
        print(*[self._display(a) for a in args])
        return None

    def _builtin_len(self, args):
        if len(args) != 1 or not isinstance(args[0], (str, list, dict)):
            raise RuntimeError_("len() takes a string, list, or dict")
        return float(len(args[0]))

    def _builtin_str(self, args):
        if len(args) != 1:
            raise RuntimeError_("str() takes 1 argument")
        return self._display(args[0])

    def _builtin_num(self, args):
        if len(args) != 1:
            raise RuntimeError_("num() takes 1 argument")
        try:
            return float(args[0])
        except (ValueError, TypeError):
            raise RuntimeError_(f"Cannot convert {args[0]!r} to number")

    def _builtin_type(self, args):
        if len(args) != 1:
            raise RuntimeError_("type() takes 1 argument")
        v = args[0]
        if isinstance(v, bool):     return "bool"
        if isinstance(v, float):    return "number"
        if isinstance(v, str):      return "string"
        if isinstance(v, list):     return "list"
        if isinstance(v, dict):     return "dict"
        if isinstance(v, Function): return "function"
        if isinstance(v, Klass):    return "class"
        if isinstance(v, Instance): return v.klass.name
        if v is None:               return "null"
        return "unknown"

    def _index_get(self, obj, idx):
        if isinstance(obj, dict):
            key = int(idx) if isinstance(idx, float) and idx == int(idx) else idx
            if key not in obj:
                raise RuntimeError_(f"Key {key!r} not found in dict")
            return obj[key]
        if not isinstance(obj, (list, str)):
            raise RuntimeError_(f"Cannot index into {self._builtin_type([obj])}")
        i = int(idx)
        if i < 0 or i >= len(obj):
            raise RuntimeError_(f"Index {i} out of range (length {len(obj)})")
        v = obj[i]
        return float(v) if isinstance(v, int) else v

    def _index_set(self, obj, idx, val):
        if isinstance(obj, dict):
            key = int(idx) if isinstance(idx, float) and idx == int(idx) else idx
            obj[key] = val
            return val
        if not isinstance(obj, list):
            raise RuntimeError_("Can only assign to list or dict index")
        i = int(idx)
        if i < 0 or i >= len(obj):
            raise RuntimeError_(f"Index {i} out of range (length {len(obj)})")
        obj[i] = val
        return val

    def _builtin_range(self, args):
        if len(args) == 1:
            start, stop, step = 0, int(args[0]), 1
        elif len(args) == 2:
            start, stop, step = int(args[0]), int(args[1]), 1
        elif len(args) == 3:
            start, stop, step = int(args[0]), int(args[1]), int(args[2])
        else:
            raise RuntimeError_("range() takes 1-3 arguments")
        return [float(i) for i in range(start, stop, step)]

    def _builtin_push(self, args):
        if len(args) != 2:
            raise RuntimeError_("push(list, value) takes 2 arguments")
        if not isinstance(args[0], list):
            raise RuntimeError_("push() first argument must be a list")
        args[0].append(args[1])
        return float(len(args[0]))

    def _builtin_pop(self, args):
        if len(args) != 1:
            raise RuntimeError_("pop(list) takes 1 argument")
        if not isinstance(args[0], list):
            raise RuntimeError_("pop() argument must be a list")
        if not args[0]:
            raise RuntimeError_("pop() on empty list")
        return args[0].pop()

    def _builtin_keys(self, args):
        if len(args) != 1 or not isinstance(args[0], dict):
            raise RuntimeError_("keys() takes a dict")
        return list(args[0].keys())

    def _builtin_has(self, args):
        if len(args) != 2 or not isinstance(args[0], dict):
            raise RuntimeError_("has(dict, key) takes a dict and a key")
        key = int(args[1]) if isinstance(args[1], float) and args[1] == int(args[1]) else args[1]
        return key in args[0]

    def _builtin_delete(self, args):
        if len(args) != 2 or not isinstance(args[0], dict):
            raise RuntimeError_("delete(dict, key) takes a dict and a key")
        key = int(args[1]) if isinstance(args[1], float) and args[1] == int(args[1]) else args[1]
        if key not in args[0]:
            raise RuntimeError_(f"Key {key!r} not found")
        del args[0][key]
        return None

    def _str_method(self, s: str, attr: str):
        methods = {
            "upper", "lower", "trim", "split",
            "contains", "starts_with", "ends_with", "replace", "index_of",
        }
        if attr not in methods:
            raise RuntimeError_(f"string has no attribute '{attr}'")
        def _bound(args, _s=s, _attr=attr):
            return self._call_str_method(_s, _attr, args)
        return _bound

    def _call_str_method(self, s: str, method: str, args: list):
        if method == "upper":     return s.upper()
        if method == "lower":     return s.lower()
        if method == "trim":      return s.strip()
        if method == "split":
            sep = args[0] if args else None
            return s.split(sep) if sep else s.split()
        if method == "contains":
            if len(args) != 1: raise RuntimeError_("contains() takes 1 argument")
            return args[0] in s
        if method == "starts_with":
            if len(args) != 1: raise RuntimeError_("starts_with() takes 1 argument")
            return s.startswith(args[0])
        if method == "ends_with":
            if len(args) != 1: raise RuntimeError_("ends_with() takes 1 argument")
            return s.endswith(args[0])
        if method == "replace":
            if len(args) != 2: raise RuntimeError_("replace() takes 2 arguments")
            return s.replace(args[0], args[1])
        if method == "index_of":
            if len(args) != 1: raise RuntimeError_("index_of() takes 1 argument")
            return float(s.find(args[0]))
        raise RuntimeError_(f"string has no method '{method}'")

    def _call_list_method(self, lst: list, method: str, args: list):
        if method == "contains":
            if len(args) != 1: raise RuntimeError_("contains() takes 1 argument")
            return args[0] in lst
        if method == "index_of":
            if len(args) != 1: raise RuntimeError_("index_of() takes 1 argument")
            try:
                return float(lst.index(args[0]))
            except ValueError:
                return -1.0
        if method == "join":
            sep = args[0] if args else ""
            return sep.join(self._display(v) for v in lst)
        if method == "reverse":
            lst.reverse()
            return None
        if method == "slice":
            start = int(args[0]) if len(args) > 0 else 0
            stop  = int(args[1]) if len(args) > 1 else len(lst)
            return lst[start:stop]
        raise RuntimeError_(f"list has no method '{method}'")

    def _builtin_floor(self, args):
        if len(args) != 1: raise RuntimeError_("floor() takes 1 argument")
        import math
        return float(math.floor(args[0]))

    def _builtin_ceil(self, args):
        if len(args) != 1: raise RuntimeError_("ceil() takes 1 argument")
        import math
        return float(math.ceil(args[0]))

    def _builtin_round(self, args):
        if len(args) not in (1, 2): raise RuntimeError_("round() takes 1-2 arguments")
        ndigits = int(args[1]) if len(args) == 2 else 0
        return float(round(args[0], ndigits))

    def _builtin_abs(self, args):
        if len(args) != 1: raise RuntimeError_("abs() takes 1 argument")
        return float(abs(args[0]))

    def _import(self, path: str, env: Environment):
        import os
        from .lexer import Lexer, LexError
        from .parser import Parser, ParseError
        base = getattr(self, '_base_dir', '.')
        full = os.path.join(base, path if path.endswith('.mo') else path + '.mo')
        if not os.path.exists(full):
            pkg_fallback = os.path.join(
                os.path.dirname(__file__), path if path.endswith('.mo') else path + '.mo'
            )
            if os.path.exists(pkg_fallback):
                full = pkg_fallback
            else:
                raise RuntimeError_(f"Cannot find module '{path}'")
        source = open(full).read()
        try:
            tokens = Lexer(source).tokenize()
            ast    = Parser(tokens).parse()
        except (LexError, ParseError) as e:
            raise RuntimeError_(f"Error in module '{path}': {e}")
        mod_env = Environment(parent=self.globals)
        self.run(ast, mod_env)
        for name, val in mod_env.vars.items():
            env.define(name, val)

    def _builtin_input(self, args):
        prompt = self._display(args[0]) if args else ""
        try:
            return input(prompt)
        except EOFError:
            return ""

    def _display(self, val) -> str:
        if val is True:  return "true"
        if val is False: return "false"
        if val is None:  return "null"
        if isinstance(val, list):
            return "[" + ", ".join(self._display(v) for v in val) + "]"
        if isinstance(val, dict):
            pairs = ", ".join(f"{self._display(k)}: {self._display(v)}" for k, v in val.items())
            return "{" + pairs + "}"
        if isinstance(val, Instance):
            fields = ", ".join(f"{k}: {self._display(v)}" for k, v in val.fields.items())
            return f"<{val.klass.name} {{{fields}}}>"
        if isinstance(val, Klass):
            return f"<class {val.name}>"
        if isinstance(val, float):
            return str(int(val)) if val == int(val) else str(val)
        return str(val)
