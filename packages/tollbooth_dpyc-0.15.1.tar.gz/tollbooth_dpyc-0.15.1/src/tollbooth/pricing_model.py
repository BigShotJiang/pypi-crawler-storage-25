"""Pricing model dataclasses for runtime-configurable tool pricing.

A PricingModel is a named bundle of per-tool prices and an optional
constraint pipeline that an operator can activate at runtime via the
Pricing Studio.

Tools are identified by a stable UUID (``tool_id``) derived from their
canonical capability name.  The pricing model references UUIDs, not
MCP-specific tool names, enabling portability across implementations.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any


@dataclass
class ToolPrice:
    """Per-tool price entry within a pricing model.

    ``tool_id`` is the canonical UUID for the capability.  ``tool_name``
    is kept for display/debugging but is NOT the primary key.
    """

    tool_id: str
    tool_name: str
    price_sats: int
    category: str = ""
    intent: str = ""
    priced: bool = False               # False = TBD, True = operator has set a price
    price_type: str = "flat"           # "flat" | "percent" | "formula"
    price_formula: str | None = None   # percent expression or formula string
    min_cost: int = 0                  # floor — minimum cost in sats
    max_cost: int | None = None        # ceiling — maximum cost in sats

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "tool_id": self.tool_id,
            "tool_name": self.tool_name,
            "price_sats": self.price_sats,
            "category": self.category,
            "intent": self.intent,
            "priced": self.priced,
        }
        if self.price_type != "flat":
            d["price_type"] = self.price_type
        if self.price_formula is not None:
            d["price_formula"] = self.price_formula
        if self.min_cost > 0:
            d["min_cost"] = self.min_cost
        if self.max_cost is not None:
            d["max_cost"] = self.max_cost
        return d

    def to_tool_pricing(self) -> "ToolPricing":
        """Convert this declarative price entry to a runtime ToolPricing."""
        from tollbooth.pricing import ToolPricing

        if self.price_type == "percent":
            return ToolPricing(
                rate_percent=float(self.price_sats),
                rate_param=self.price_formula or "",
                min_cost=self.min_cost,
                max_cost=self.max_cost,
            )
        return ToolPricing(
            fixed=self.price_sats,
            min_cost=self.min_cost,
            max_cost=self.max_cost,
        )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ToolPrice:
        tool_id = data.get("tool_id")
        if not tool_id:
            raise KeyError(
                f"tool_id is required for tool '{data.get('tool_name', '?')}'. "
                "Run reset_pricing_model to re-seed from the tool registry."
            )
        return cls(
            tool_id=tool_id,
            tool_name=data["tool_name"],
            price_sats=int(data["price_sats"]),
            category=data.get("category", ""),
            intent=data.get("intent", ""),
            priced=bool(data.get("priced", True)),  # legacy models without field are considered priced
            price_type=data.get("price_type", "flat"),
            price_formula=data.get("price_formula", None),
            min_cost=int(data.get("min_cost", 0)),
            max_cost=int(data["max_cost"]) if data.get("max_cost") is not None else None,
        )


@dataclass
class TrancheLifetime:
    """How long a tranche of api_sats endures before expiring.

    This is a property of the money, not a per-tool constraint.
    ``None`` for ttl_days means credits never expire.
    """

    ttl_days: int | None = None
    target_usage_pct: float = 0.75
    min_days: int = 3
    max_days: int = 90

    def __post_init__(self) -> None:
        if self.min_days > self.max_days:
            raise ValueError(
                f"min_days ({self.min_days}) must be <= max_days ({self.max_days})"
            )
        if self.ttl_days is not None:
            self.ttl_days = max(self.min_days, min(self.max_days, self.ttl_days))

    @property
    def ttl_seconds(self) -> int | None:
        """Lifetime in seconds, or None if credits never expire."""
        return self.ttl_days * 86400 if self.ttl_days is not None else None

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"target_usage_pct": self.target_usage_pct}
        if self.ttl_days is not None:
            d["ttl_days"] = self.ttl_days
        if self.min_days != 3:
            d["min_days"] = self.min_days
        if self.max_days != 90:
            d["max_days"] = self.max_days
        return d

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TrancheLifetime:
        ttl_raw = data.get("ttl_days")
        return cls(
            ttl_days=int(ttl_raw) if ttl_raw is not None else None,
            target_usage_pct=float(data.get("target_usage_pct", 0.75)),
            min_days=int(data.get("min_days", 3)),
            max_days=int(data.get("max_days", 90)),
        )


@dataclass
class PipelineStep:
    """A single step in the constraint pipeline.

    Scope fields control which tools and patrons this step applies to:
    - ``tool_ids``: empty = all tools (wildcard). Non-empty = only these tools.
    - ``patron_npubs``: empty = all patrons. Non-empty = only these patrons (max 10).
    """

    id: str
    type: str  # must match a key in CONSTRAINT_REGISTRY
    params: dict[str, Any] = field(default_factory=dict)
    tool_ids: list[str] = field(default_factory=list)
    patron_npubs: list[str] = field(default_factory=list)

    _MAX_PATRON_GROUP = 10

    def __post_init__(self) -> None:
        if len(self.patron_npubs) > self._MAX_PATRON_GROUP:
            raise ValueError(
                f"patron_npubs exceeds max group size of {self._MAX_PATRON_GROUP}. "
                "Clone the constraint for additional patron groups."
            )

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"id": self.id, "type": self.type}
        if self.params:
            d["params"] = self.params
        if self.tool_ids:
            d["tool_ids"] = self.tool_ids
        if self.patron_npubs:
            d["patron_npubs"] = self.patron_npubs
        return d

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PipelineStep:
        return cls(
            id=data["id"],
            type=data["type"],
            params=dict(data.get("params", {})),
            tool_ids=list(data.get("tool_ids", [])),
            patron_npubs=list(data.get("patron_npubs", [])),
        )


@dataclass
class PricingModel:
    """A named pricing model — tool costs + optional constraint pipeline."""

    model_id: str = ""
    operator: str = ""
    name: str = ""
    is_active: bool = False
    tools: list[ToolPrice] = field(default_factory=list)
    pipeline: list[PipelineStep] = field(default_factory=list)
    tranche_lifetime: TrancheLifetime | None = None

    def tool_cost_map(self) -> dict[str, int]:
        """Return a flat {tool_id: price_sats} lookup dict."""
        return {tp.tool_id: tp.price_sats for tp in self.tools}

    def tool_id_set(self) -> set[str]:
        """Return the set of tool_ids that have explicit entries."""
        return {tp.tool_id for tp in self.tools}

    def tool_priced_map(self) -> dict[str, bool]:
        """Return {tool_id: priced} — whether the operator has set a price."""
        return {tp.tool_id: tp.priced for tp in self.tools}

    def to_constraint_config(self) -> dict[str, Any] | None:
        """Convert pipeline to the format ``load_constraints()`` expects.

        Returns ``None`` if the pipeline is empty.

        Steps with ``tool_ids`` are grouped under each tool ID.
        Steps without are grouped under the wildcard ``"*"`` key.
        Patron scoping (``patron_npubs``) is embedded in the constraint
        entry as metadata for the gate to filter at evaluation time.
        """
        if not self.pipeline:
            return None

        by_scope: dict[str, list[dict[str, Any]]] = {}
        for step in self.pipeline:
            entry: dict[str, Any] = {"type": step.type}
            entry.update(step.params)
            if step.patron_npubs:
                entry["_patron_npubs"] = step.patron_npubs
            if step.tool_ids:
                for tid in step.tool_ids:
                    by_scope.setdefault(tid, []).append(entry)
            else:
                by_scope.setdefault("*", []).append(entry)

        return {
            "tool_constraints": {
                scope: {"constraints": steps}
                for scope, steps in by_scope.items()
            },
        }

    def to_json(self) -> str:
        """Serialize to a JSON string (for ``model_json`` column)."""
        return json.dumps(self._to_model_dict())

    def _to_model_dict(self) -> dict[str, Any]:
        """Internal dict for the ``model_json`` JSONB column."""
        d: dict[str, Any] = {
            "name": self.name,
            "tools": [tp.to_dict() for tp in self.tools],
            "pipeline": [ps.to_dict() for ps in self.pipeline],
        }
        if self.tranche_lifetime is not None:
            d["tranche_lifetime"] = self.tranche_lifetime.to_dict()
        return d

    @classmethod
    def from_json(cls, raw: str, *, model_id: str = "", operator: str = "", is_active: bool = False) -> PricingModel:
        """Deserialize from a JSON string (``model_json`` column)."""
        data = json.loads(raw)

        tl_data = data.get("tranche_lifetime")
        tranche_lifetime = TrancheLifetime.from_dict(tl_data) if isinstance(tl_data, dict) else None

        return cls(
            model_id=model_id,
            operator=operator,
            name=data.get("name", ""),
            is_active=is_active,
            tools=[ToolPrice.from_dict(t) for t in data.get("tools", [])],
            pipeline=[PipelineStep.from_dict(p) for p in data.get("pipeline", [])],
            tranche_lifetime=tranche_lifetime,
        )

    @classmethod
    def from_row(cls, row: dict[str, Any]) -> PricingModel:
        """Build from a Neon result row (``operator_pricing_models`` table)."""
        model_json = row["model_json"]
        raw = model_json if isinstance(model_json, str) else json.dumps(model_json)
        return cls.from_json(
            raw,
            model_id=str(row["id"]),
            operator=row["operator"],
            is_active=bool(row.get("is_active", False)),
        )
