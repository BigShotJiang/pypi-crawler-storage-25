"""Official ManyWe Chat-First placeholder package reserved on PyPI."""

__all__ = ["PACKAGE_NAME", "__version__", "placeholder_notice"]

PACKAGE_NAME = "manywe-chat-first"
__version__ = "0.0.1"

def placeholder_notice() -> str:
    return (
        "manywe-chat-first is an official ManyWe placeholder package on PyPI. "
        "The public Python implementation is not available yet."
    )
