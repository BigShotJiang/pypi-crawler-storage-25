"""Celery AOP aspects."""
