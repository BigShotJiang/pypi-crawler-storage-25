/**
 * django-live-translations — client-side widget
 * Vanilla JS, zero dependencies. Injected by middleware for superusers.
 *
 * State machine:
 *   inactive ──(shortcut)──► active ──(click span)──► editing
 *      ▲                       ▲│                        │
 *      └──────(shortcut)───────┘│                        │
 *                                └──(save/cancel/Esc)────┘
 *
 *   Save updates the DOM in-place using server-computed display data.
 *
 * Preview mode (shortcut → page reload):
 *   Server renders inactive translations. Elements with inactive overrides
 *   get amber borders. Shift+click selects them for bulk activation.
 */
(function () {
  "use strict";

  // ─── Data Attribute Constants ──────────────────────────
  // Shared with the Python middleware that injects these attributes.
  /** @type {string} */ var ATTR_CONFIG = "data-lt-config";
  /** @type {string} */ var ATTR_STRINGS = "data-lt-strings";
  /** @type {string} */ var SEL_ATTR_TRANSLATIONS = "[data-lt-attrs]";

  /**
   * @typedef {Object} LTConfig
   * @property {string}   [apiBase]          - URL prefix for the translation API endpoints.
   * @property {string[]} [languages]        - Language codes enabled for editing (e.g. ["en","cs","de"]).
   * @property {string}   [csrfToken]        - Django CSRF token injected by middleware.
   * @property {boolean}  [activeByDefault]  - Whether new overrides are active immediately.
   * @property {string}   [shortcutEdit]     - Keyboard shortcut for toggling edit mode.
   * @property {string}   [shortcutPreview]  - Keyboard shortcut for toggling preview mode.
   * @property {string[]} [draftLanguages]   - Language codes that are drafts (not in Django LANGUAGES).
   * @property {string}   [currentLanguage]  - Server-resolved current language code.
   * @property {boolean}  [preview]          - Whether preview mode is active.
   * @property {Array<{m:string, c:string}>} [previewEntries] - Inactive override entries for preview.
   * @property {string[]|null} [editableLanguages] - Subset of languages the current user may edit (null = all).
   * @property {Object<string, number>} [nplurals] - Map of language code to number of plural forms.
   * @property {Object<string, Array<[string, string]>>} [pluralHints] - CLDR category names + examples per form per language.
   */

  /**
   * @typedef {Object} LangMeta
   * @property {string} flag - Emoji flag for the language.
   * @property {string} name - English display name.
   */

  /**
   * Attribute translation descriptor embedded in `data-lt-attrs` JSON.
   * @typedef {Object} AttrInfo
   * @property {string} a - HTML attribute name (e.g. "title", "placeholder").
   * @property {string} m - The gettext msgid.
   * @property {string} c - The gettext context (empty string if none).
   */

  /**
   * Single language entry returned by the translations API.
   * @typedef {Object} TranslationEntry
   * @property {Object<string, string>} msgstr_forms - Plural form index to translated string.
   * @property {boolean} fuzzy        - Whether the .po entry is marked fuzzy.
   * @property {boolean} is_active    - Whether the DB override is active.
   * @property {boolean} has_override - Whether a DB override exists.
   */

  /**
   * Response payload from `GET /translations/`.
   * @typedef {Object} TranslationData
   * @property {Object<string, TranslationEntry>} translations - Keyed by language code.
   * @property {Object<string, Object<string, string>>|null} defaults - .po file defaults keyed by language code, each is form-index-to-string.
   * @property {string|null}                        hint         - Optional translator hint from the .po file.
   * @property {string}                             msgid_plural - The msgid_plural string (empty for singular).
   */

  /**
   * Single diff segment within a history entry.
   * @typedef {Object} DiffSegment
   * @property {"equal"|"insert"|"delete"} type - Diff operation type.
   * @property {string}                     text - Text content of this segment.
   */

  /**
   * Single entry from the edit history API.
   * @typedef {Object} HistoryEntry
   * @property {number}         id         - Database primary key.
   * @property {string}         language   - Language code this change applies to.
   * @property {"create"|"update"|"delete"|"activate"|"deactivate"} action - Type of change.
   * @property {string}         created_at - ISO 8601 timestamp.
   * @property {string|null}    user       - Username of the editor, or null.
   * @property {string|null}    old_value  - Previous msgstr (null for creates).
   * @property {string|null}    new_value  - New msgstr (null for deletes).
   * @property {DiffSegment[]}  [diff]      - Token-level diff between old and new values (absent for state changes).
   * @property {number}         form_index - Plural form index (0 for singular).
   */

  /**
   * Response payload from `POST /translations/save/`.
   * @typedef {Object} SaveResponse
   * @property {boolean} ok
   * @property {{text: string, is_preview_entry: boolean, reload_required: boolean}} [display] - Updated display info.
   */

  /**
   * Response payload from `POST /translations/delete/`.
   * @typedef {Object} DeleteResponse
   * @property {boolean} ok
   * @property {number}  deleted - Number of overrides deleted.
   * @property {{text: string, is_preview_entry: boolean, reload_required: boolean}} [display] - Updated display info.
   */

  /**
   * Response payload from `POST /translations/bulk-activate/`.
   * @typedef {Object} BulkActivateResponse
   * @property {boolean} ok
   * @property {number}  activated - Number of overrides activated.
   */

  /**
   * Error thrown by API methods when the server returns a non-OK response.
   * Extends the standard Error with optional structured per-language details.
   * @typedef {Error & {details?: Object<string, string[]>|null}} ApiError
   */

  /**
   * Drag state tracked during hint bar repositioning.
   * @typedef {Object} DragState
   * @property {number}  mouseX - Initial mouse X at drag start.
   * @property {number}  mouseY - Initial mouse Y at drag start.
   * @property {number}  barX   - Initial bar left offset at drag start.
   * @property {number}  barY   - Initial bar top offset at drag start.
   * @property {boolean} moved  - Whether the drag has passed the movement threshold.
   */

  /**
   * Persisted hint bar position in localStorage.
   * @typedef {Object} HintPosition
   * @property {number} x
   * @property {number} y
   */

  // ─── Config (read from <template data-lt-config>) ────
  /** @type {LTConfig} */
  var CONFIG = {};
  var _configTmpl = document.querySelector("template[" + ATTR_CONFIG + "]");
  if (_configTmpl) {
    try { CONFIG = JSON.parse(_configTmpl.getAttribute(ATTR_CONFIG) || "{}"); } catch (e) { /* ignore */ }
    _configTmpl.removeAttribute(ATTR_CONFIG);
  }
  /** @type {string} */
  const API_BASE = CONFIG.apiBase || "/__live-translations__";
  /** @type {string[]} */
  const LANGUAGES = CONFIG.languages || [];
  /** @type {string} */
  const CSRF_TOKEN = CONFIG.csrfToken || "";
  /** @type {boolean} */
  const ACTIVE_BY_DEFAULT = CONFIG.activeByDefault !== undefined ? CONFIG.activeByDefault : false;
  /** @type {string} */
  const SHORTCUT_EDIT = CONFIG.shortcutEdit || "ctrl+shift+e";
  /** @type {string} */
  const SHORTCUT_PREVIEW = CONFIG.shortcutPreview || "ctrl+shift+p";
  /** @type {boolean} */
  const PREVIEW = CONFIG.preview || false;
  /** @type {Array<{m:string, c:string}>} */
  let PREVIEW_ENTRIES = CONFIG.previewEntries || [];
  /** @type {string[]} */
  const DRAFT_LANGUAGES = CONFIG.draftLanguages || [];
  /** @type {string} */
  const CURRENT_LANGUAGE = CONFIG.currentLanguage || "";
  /** @type {string[]|null} */
  const EDITABLE_LANGUAGES = CONFIG.editableLanguages || null;
  /** @type {Object<string, number>} */
  const NPLURALS = CONFIG.nplurals || {};
  /** @type {Object<string, Array<[string, string]>>} */
  const PLURAL_HINTS = CONFIG.pluralHints || {};

  /**
   * Check whether a language is editable by the current user.
   * When EDITABLE_LANGUAGES is null, all languages are editable.
   * @param {string} lang - Language code.
   * @returns {boolean}
   */
  function _isEditable(lang) {
    return EDITABLE_LANGUAGES === null || EDITABLE_LANGUAGES.indexOf(lang) !== -1;
  }

  /**
   * Get the number of plural forms for a language. Defaults to 2.
   * @param {string} lang - Language code.
   * @returns {number}
   */
  function _getNplurals(lang) {
    return NPLURALS[lang] || 2;
  }

  /**
   * Build a descriptive label for a plural form index.
   * Returns e.g. "Form 0 \u2014 one (e.g. 1)" or plain "Form 0" when no hints.
   * @param {string} lang - Language code.
   * @param {number} formIdx - Plural form index.
   * @returns {string}
   */
  function _formLabel(lang, formIdx) {
    var base = "Form " + formIdx;
    var langHints = PLURAL_HINTS[lang] || PLURAL_HINTS[lang.split("-")[0]] || PLURAL_HINTS[lang.split("_")[0]];
    if (!langHints || !langHints[formIdx]) return base;
    var hint = langHints[formIdx];
    var category = hint[0];
    var examples = hint[1];
    if (!category && !examples) return base;
    var parts = base + " \u2014 ";
    if (category) parts += category;
    if (category && examples) parts += " ";
    if (examples) parts += "(e.g. " + examples + ")";
    return parts;
  }

  // ─── String Table & ZWC Marker Resolution ───────────

  /**
   * @typedef {{m: string, c: string, p?: string}} StringTableEntry
   * Mirrors Python's StringTableEntry TypedDict.
   */

  /**
   * @typedef {Object<number, StringTableEntry>} StringTable
   * Maps string ID to {msgid, context[, msgid_plural]}. Delivered via &lt;template data-lt-strings&gt;.
   */

  /**
   * @typedef {Object} RegisteredNode
   * @property {Text}              node    - The text node containing translated content.
   * @property {string}            msgid   - The gettext message ID.
   * @property {string}            context - The gettext context (empty string if none).
   * @property {HTMLElement|null}  span    - Wrapping <lt-t> element (null only for OPTION/TITLE/SCRIPT/STYLE parents).
   * @property {string}            [msgid_plural] - The msgid_plural if this is a plural entry.
   */

  /** @type {RegExp} */
  const ZWC_RE = /\uFEFF[\u200B\u200C]{16}\uFEFF/g;

  /**
   * Matches a start flag character that is NOT the leading boundary of a
   * full 18-char ZWC end marker.  Two flag characters are used:
   *   - \uFEFF (BOM) — position-0 flag for HTML-starting translations
   *   - \u2060 (WJ)  — position-1 flag for normal text translations
   * End markers have the pattern: FEFF + 16x(200B|200C) + FEFF.
   * The negative lookahead ensures standalone \uFEFF flags are matched
   * without consuming end-marker boundaries.  \u2060 never appears in
   * end markers so needs no lookahead.
   * @type {RegExp}
   */
  const START_FLAG_RE = /\uFEFF(?![\u200B\u200C]{16}\uFEFF)|\u2060/g;

  /** Word Joiner — position-1 start flag for normal text translations. */
  const WJ = "\u2060";

  /** @type {StringTable} */
  var STRING_TABLE = {};

  /** @type {RegisteredNode[]} */
  const registeredNodes = [];

  /**
   * Decode a ZWC marker string into a string-table ID.
   * @param {string} marker - 18-char ZWC sequence (FEFF + 16 bits + FEFF).
   * @returns {number} The decoded string ID (0-65535).
   */
  function decodeZWC(marker) {
    let n = 0;
    for (let i = 1; i <= 16; i++) {
      if (marker.charCodeAt(i) === 0x200C) n |= (1 << (16 - i));
    }
    return n;
  }

  /**
   * Walk the DOM, find ZWC markers in text nodes and attribute values,
   * strip them, and populate registeredNodes[].
   * @returns {void}
   */
  function resolveMarkers(root) {
    // Phase 1: Text nodes
    /** @type {Text[]} */
    const textNodes = [];
    const walker = document.createTreeWalker(root || document.body, NodeFilter.SHOW_TEXT);
    /** @type {Node|null} */
    let wNode;
    while ((wNode = walker.nextNode()) !== null) {
      textNodes.push(/** @type {Text} */ (wNode));
    }

    for (let ti = 0; ti < textNodes.length; ti++) {
      let tn = textNodes[ti];
      const text = tn.textContent || "";
      ZWC_RE.lastIndex = 0;

      // Collect all marker matches in this text node
      /** @type {RegExpExecArray[]} */
      const matches = [];
      /** @type {RegExpExecArray|null} */
      let execMatch;
      while ((execMatch = ZWC_RE.exec(text)) !== null) {
        matches.push(execMatch);
      }
      if (!matches.length) continue;

      // Process markers right-to-left to preserve indices when splitting.
      // After each iteration we update `tn` to the content node to the LEFT
      // of the processed marker so the next (leftward) marker can be found.
      for (let mi = matches.length - 1; mi >= 0; mi--) {
        const m = matches[mi];
        const mIdx = /** @type {number} */ (m.index);
        const mLen = m[0].length;
        const id = decodeZWC(m[0]);
        const meta = STRING_TABLE[id];
        if (!meta) continue;

        // Guard: after earlier iterations the text node may have been split
        // or removed, making the original offset stale.
        const tnLen = (tn.textContent || "").length;
        if (mIdx + mLen > tnLen) continue;

        // Text AFTER the marker becomes a separate text node (tail)
        const afterStart = mIdx + mLen;
        if (afterStart < tnLen) {
          tn.splitText(afterStart);
        }

        // Text of the marker itself: remove it.
        // Now tn contains everything up to and including the marker.
        // Split before the marker to isolate it.
        if (mIdx > 0) {
          tn = /** @type {Text} */ (tn.splitText(mIdx));
        }

        // tn now starts with the marker. Remove the marker text from tn.
        tn.textContent = (tn.textContent || "").substring(mLen);

        // The text node BEFORE the marker (content text) is tn's previous sibling.
        // Since we append markers, the content is BEFORE the marker in the text.
        const contentNode = /** @type {Text|null} */ (tn.previousSibling);

        // Determine which text node contains the translatable content
        /** @type {Text|null} */
        let nodeToWrap = null;
        if (contentNode && contentNode.nodeType === Node.TEXT_NODE && (contentNode.textContent || "").length > 0) {
          nodeToWrap = /** @type {Text} */ (contentNode);
        } else if (tn.nodeType === Node.TEXT_NODE && (tn.textContent || "").length > 0) {
          // Marker was at position 0 or no previous content; use tn (text after marker)
          nodeToWrap = /** @type {Text} */ (tn);
        }

        // Strip start flags from the content node (handles the plain-text case
        // where both start flag and end marker are in the same text node).
        if (nodeToWrap && nodeToWrap.nodeType === Node.TEXT_NODE) {
          START_FLAG_RE.lastIndex = 0;
          nodeToWrap.textContent = (nodeToWrap.textContent || "").replace(START_FLAG_RE, "");
        }

        let didMultiWrap = false;

        if (nodeToWrap) {
          const wrapParent = nodeToWrap.parentNode;
          const canWrap = wrapParent && wrapParent.nodeName !== "OPTION" && wrapParent.nodeName !== "TITLE" && wrapParent.nodeName !== "SCRIPT" && wrapParent.nodeName !== "STYLE";

          // ── Multi-node wrapping via start flag ──
          // Walk backwards from contentNode through previousSiblings looking
          // for the ZWC start flag.  When found, wrap all nodes from the
          // flag position through contentNode in a single <lt-t>.
          if (canWrap && contentNode) {
            let cursor = contentNode;
            while (cursor) {
              if (cursor.nodeType === Node.TEXT_NODE) {
                START_FLAG_RE.lastIndex = 0;
                const flagMatch = START_FLAG_RE.exec(cursor.textContent || "");
                if (flagMatch) {
                  const flagIdx = flagMatch.index;
                  const flagChar = flagMatch[0];
                  // Strip the flag character
                  cursor.textContent = (cursor.textContent || "").slice(0, flagIdx) + (cursor.textContent || "").slice(flagIdx + 1);
                  // Determine split position:
                  // - Position-0 flag (\uFEFF): split at flagIdx (text before is non-translation)
                  // - Position-1 flag (\u2060): split at flagIdx-1 (char before flag is the
                  //   first translation char and must be included in <lt-t>)
                  const splitAt = flagChar === WJ ? flagIdx - 1 : flagIdx;
                  let wrapStart = cursor;
                  if (splitAt > 0) {
                    wrapStart = /** @type {Text} */ (cursor.splitText(splitAt));
                  }
                  // Collect all nodes from wrapStart through contentNode (inclusive)
                  const nodesToWrap = [];
                  let n = wrapStart;
                  while (n) {
                    nodesToWrap.push(n);
                    if (n === contentNode) break;
                    n = n.nextSibling;
                  }
                  // Also include tn if it has content and follows contentNode
                  if (tn !== contentNode && tn.textContent && tn.textContent.length > 0 && tn.parentNode === wrapParent) {
                    // Check if tn is immediately after contentNode
                    if (contentNode.nextSibling === tn) {
                      nodesToWrap.push(tn);
                    }
                  }
                  if (nodesToWrap.length > 0) {
                    const ltEl = _createLtElement(meta);
                    wrapParent.insertBefore(ltEl, nodesToWrap[0]);
                    for (let ni = 0; ni < nodesToWrap.length; ni++) {
                      ltEl.appendChild(nodesToWrap[ni]);
                    }
                    // Find the first text node inside for registration
                    const firstText = _firstTextNode(ltEl);
                    registeredNodes.push({ node: firstText || nodeToWrap, msgid: meta.m, context: meta.c, span: ltEl, msgid_plural: meta.p || "" });
                    didMultiWrap = true;
                  }
                  break;
                }
              }
              // Stop walking at parent boundary or if we hit another <lt-t>
              const prev = cursor.previousSibling;
              if (!prev || (prev.nodeType === Node.ELEMENT_NODE && /** @type {Element} */ (prev).tagName === "LT-T")) break;
              cursor = prev;
            }
          }

          // ── Fallback: single-node wrapping ──
          if (!didMultiWrap) {
            if (canWrap) {
              const ltEl2 = _createLtElement(meta);
              wrapParent.insertBefore(ltEl2, nodeToWrap);
              ltEl2.appendChild(nodeToWrap);
              registeredNodes.push({ node: nodeToWrap, msgid: meta.m, context: meta.c, span: ltEl2, msgid_plural: meta.p || "" });
            } else {
              registeredNodes.push({ node: nodeToWrap, msgid: meta.m, context: meta.c, span: null, msgid_plural: meta.p || "" });
            }
          }
        }

        // Clean up empty text node left after marker removal
        if (!didMultiWrap && tn !== nodeToWrap && tn.textContent === "" && tn.parentNode) {
          tn.parentNode.removeChild(tn);
        }

        // Update tn for the next (leftward) iteration.  contentNode holds
        // all text to the left of the just-processed marker, including any
        // remaining markers.  It may have been reparented into <lt-t> but
        // its textContent is unchanged so the earlier match indices stay valid.
        if (contentNode && contentNode.nodeType === Node.TEXT_NODE) {
          tn = /** @type {Text} */ (contentNode);
        }
      }
    }

    // Phase 2: Attribute values
    const allElements = (root || document.body).querySelectorAll("*");
    for (let ei = 0; ei < allElements.length; ei++) {
      const el = /** @type {HTMLElement} */ (allElements[ei]);
      /** @type {AttrInfo[]} */
      const ltAttrs = [];
      const attrs = el.attributes;
      for (let ai = 0; ai < attrs.length; ai++) {
        const attr = attrs[ai];
        ZWC_RE.lastIndex = 0;
        const attrMatch = ZWC_RE.exec(attr.value);
        if (!attrMatch) continue;
        const attrId = decodeZWC(attrMatch[0]);
        const attrMeta = STRING_TABLE[attrId];
        if (!attrMeta) continue;
        // Strip ALL ZWC markers and start flags from the attribute value
        el.setAttribute(attr.name, attr.value.replace(ZWC_RE, "").replace(START_FLAG_RE, ""));
        ltAttrs.push({ a: attr.name, m: attrMeta.m, c: attrMeta.c });
      }
      if (ltAttrs.length) {
        el.dataset.ltAttrs = JSON.stringify(ltAttrs);
      }
    }
  }

  /**
   * Create an `<lt-t>` wrapper element with dataset attributes from a string-table entry.
   * @param {StringTableEntry} meta - String-table entry with msgid, context, and optional plural.
   * @returns {HTMLElement}
   */
  function _createLtElement(meta) {
    const el = document.createElement("lt-t");
    el.dataset.ltMsgid = meta.m;
    el.dataset.ltContext = meta.c;
    if (meta.p) el.dataset.ltPlural = meta.p;
    return el;
  }

  /**
   * Find the first text node inside a DOM subtree.
   * @param {Node} root - Root node to search within.
   * @returns {Text|null}
   */
  function _firstTextNode(root) {
    const tw = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    const n = tw.nextNode();
    return n ? /** @type {Text} */ (n) : null;
  }

  // ─── Dynamic Content Support ─────────────────────────

  /**
   * Find &lt;template data-lt-strings&gt; elements injected by the middleware,
   * merge their entries into STRING_TABLE, and remove them from the DOM.
   * Works for both the initial full-page template and partial-response templates
   * appended after dynamic content swaps (htmx, fetch, etc.).
   * @returns {void}
   */
  function _processPartialStrings() {
    var templates = document.body.querySelectorAll("template[" + ATTR_STRINGS + "]");
    for (var i = 0; i < templates.length; i++) {
      try {
        var data = JSON.parse(templates[i].getAttribute(ATTR_STRINGS) || "{}");
        for (var key in data) {
          if (data.hasOwnProperty(key)) STRING_TABLE[key] = data[key];
        }
      } catch (e) { /* ignore malformed JSON */ }
      templates[i].removeAttribute(ATTR_STRINGS);
      // Remove the template entirely if it has no remaining attributes
      if (!templates[i].attributes.length) {
        templates[i].parentNode.removeChild(templates[i]);
      }
    }
  }

  /**
   * Process any pending string-table templates and resolve ZWC markers.
   * Called on initial page load, after htmx content swaps, or manually
   * via {@link window.__LT_RESCAN__}.
   * @param {Element} [root] - DOM subtree to scan (defaults to document.body).
   * @returns {void}
   */
  function rescanMarkers(root) {
    _processPartialStrings();
    resolveMarkers(root || document.body);
  }

  // ─── HTML Validation ─────────────────────────────────

  /**
   * Set of HTML void elements that do not require a closing tag.
   * @type {Object<string, boolean>}
   */
  const VOID_ELEMENTS = {
    area:1, base:1, br:1, col:1, embed:1, hr:1, img:1, input:1,
    link:1, meta:1, param:1, source:1, track:1, wbr:1
  };

  /**
   * Matches HTML opening tags (including self-closing) and closing tags.
   * Groups: [1] = "/" for closing tags, [2] = tag name, [3] = "/" for self-closing.
   * @type {RegExp}
   */
  const HTML_TAG_RE = /<(\/?)([a-zA-Z][a-zA-Z0-9]*)\b[^>]*(\/?)>/g;

  /**
   * Validate the HTML structure of a translation string.
   * Returns an array of human-readable error descriptions.
   * Returns `[]` for plain text (no `<`) or well-formed HTML.
   *
   * Checks for:
   * - Unclosed tags (e.g. `<strong>text` without `</strong>`)
   * - Mismatched closing tags (e.g. `<strong>text</em>`)
   * - Stray closing tags (e.g. `</strong>` without a matching open)
   *
   * Void elements (`<br>`, `<img>`, etc.) and self-closing syntax (`<br/>`)
   * are handled correctly and never flagged.
   *
   * @param {string} text - The translation string to validate.
   * @returns {string[]} Array of error descriptions (empty = valid).
   */
  function _validateHtmlStructure(text) {
    if (text.indexOf("<") === -1) return [];

    const errors = [];
    const stack = [];
    let match;

    HTML_TAG_RE.lastIndex = 0;
    while ((match = HTML_TAG_RE.exec(text)) !== null) {
      const isClosing = match[1] === "/";
      const tagName = match[2].toLowerCase();
      const isSelfClosing = match[3] === "/";

      if (isSelfClosing || VOID_ELEMENTS[tagName]) {
        // Self-closing or void element — nothing to track
        if (isClosing && VOID_ELEMENTS[tagName]) {
          errors.push("Void element <" + tagName + "> should not have a closing tag");
        }
        continue;
      }

      if (isClosing) {
        if (stack.length === 0) {
          errors.push("Closing </" + tagName + "> without matching opening tag");
        } else if (stack[stack.length - 1] === tagName) {
          stack.pop();
        } else {
          // Check if the tag exists deeper in the stack (nesting error)
          let found = false;
          for (let si = stack.length - 1; si >= 0; si--) {
            if (stack[si] === tagName) { found = true; break; }
          }
          if (found) {
            errors.push("Expected </" + stack[stack.length - 1] + ">, found </" + tagName + ">");
          } else {
            errors.push("Closing </" + tagName + "> without matching opening tag");
          }
        }
      } else {
        stack.push(tagName);
      }
    }

    // Any tags left on the stack are unclosed
    for (let ui = stack.length - 1; ui >= 0; ui--) {
      errors.push("Unclosed <" + stack[ui] + "> tag");
    }

    return errors;
  }

  // ─── Shared Helpers ──────────────────────────────────

  /**
   * Return the page's language code (lowercase), e.g. "en" or "cs".
   * Uses server-injected currentLanguage when available, falls back to <html lang>.
   * @returns {string}
   */
  function _pageLang() {
    return CURRENT_LANGUAGE || (document.documentElement.lang || "").toLowerCase();
  }

  /**
   * Switch the page language. Draft languages use the lt_lang cookie + reload.
   * Published languages attempt URL prefix swap, falling back to django_language cookie.
   * @param {string} lang - Target language code.
   * @param {boolean} isDraft - Whether this is a draft language.
   * @returns {void}
   */
  function _switchPageLanguage(lang, isDraft) {
    if (isDraft) {
      document.cookie = "lt_lang=" + encodeURIComponent(lang) + "; path=/; max-age=86400; SameSite=Lax";
      window.location.reload();
      return;
    }
    // Published: clear draft cookie, then use URL prefix swap or django_language cookie
    document.cookie = "lt_lang=; path=/; max-age=0";
    const path = window.location.pathname;
    const prefixMatch = path.match(/^\/([a-z]{2}(?:-[a-z]{2})?)(\/|$)/i);
    if (prefixMatch && LANGUAGES.indexOf(prefixMatch[1].toLowerCase()) !== -1) {
      const newPath = "/" + lang + path.substring(prefixMatch[1].length + 1);
      window.location.href = newPath + window.location.search + window.location.hash;
      return;
    }
    document.cookie = "django_language=" + encodeURIComponent(lang) + "; path=/; max-age=86400; SameSite=Lax";
    window.location.reload();
  }

  /**
   * Safely parse the `data-lt-attrs` JSON on an element.
   * @param {HTMLElement} el - Element with a `data-lt-attrs` attribute.
   * @returns {AttrInfo[]}
   */
  function _parseLtAttrs(el) {
    try { return JSON.parse(el.dataset.ltAttrs || "[]"); } catch { return []; }
  }

  /**
   * Sync preview/selection CSS classes on an element after a save.
   * @param {Element} el              - The DOM element to update.
   * @param {boolean} isPreviewEntry  - Whether this entry is an inactive preview override.
   * @returns {void}
   */
  function _syncPreviewClass(el, isPreviewEntry) {
    if (isPreviewEntry) {
      el.classList.add("lt-preview");
    } else {
      el.classList.remove("lt-preview", "lt-selected");
      const idx = selectedElements.indexOf(el);
      if (idx !== -1) selectedElements.splice(idx, 1);
    }
  }

  /**
   * Build a dedup key from msgid + context (null-separated).
   * @param {string} msgid   - The gettext message identifier.
   * @param {string} context - The gettext context (empty string if none).
   * @returns {string}
   */
  function _entryKey(msgid, context) {
    return msgid + "\x00" + (context || "");
  }

  /**
   * Read an error JSON body from a failed API response and throw an Error.
   * @param {Response} resp - The fetch Response with a non-OK status.
   * @returns {Promise<never>}
   */
  async function _throwApiError(resp) {
    /** @type {Record<string, unknown>} */
    let errData;
    try { errData = await resp.json(); } catch { errData = {}; }
    throw new Error(/** @type {string} */ (errData.error) || "Request failed: " + resp.status);
  }

  /**
   * Check whether the current edit session is for a plural entry.
   * @returns {boolean}
   */
  function _isPlural() {
    return !!_editMsgidPlural;
  }

  // ─── Shortcut Parsing ────────────────────────────────

  /**
   * Parse a shortcut string like "ctrl+shift+e" into a descriptor object.
   * @param {string} combo - "+"-separated modifier+key string (case-insensitive).
   * @returns {{ctrl: boolean, shift: boolean, alt: boolean, meta: boolean, key: string}}
   */
  function _parseShortcut(combo) {
    const parts = combo.toLowerCase().split("+");
    const key = parts[parts.length - 1];
    return {
      ctrl: parts.indexOf("ctrl") !== -1,
      shift: parts.indexOf("shift") !== -1,
      alt: parts.indexOf("alt") !== -1,
      meta: parts.indexOf("meta") !== -1,
      key: key,
    };
  }

  /**
   * Test whether a KeyboardEvent matches a parsed shortcut descriptor.
   * @param {KeyboardEvent} e - The keyboard event.
   * @param {{ctrl: boolean, shift: boolean, alt: boolean, meta: boolean, key: string}} sc
   * @returns {boolean}
   */
  function _matchShortcut(e, sc) {
    return (
      e.key.toLowerCase() === sc.key &&
      e.ctrlKey === sc.ctrl &&
      e.shiftKey === sc.shift &&
      e.altKey === sc.alt &&
      e.metaKey === sc.meta
    );
  }

  /**
   * Format a shortcut descriptor as a human-readable label (e.g. "Ctrl + Shift + E").
   * Uses platform-aware symbols on macOS (⌘/⌃/⌥/⇧).
   * @param {{ctrl: boolean, shift: boolean, alt: boolean, meta: boolean, key: string}} sc
   * @returns {string}
   */
  function _formatShortcut(sc) {
    const isMac = navigator.platform ? navigator.platform.indexOf("Mac") !== -1 : false;
    const parts = [];
    if (sc.ctrl) parts.push(isMac ? "\u2303" : "Ctrl");
    if (sc.shift) parts.push(isMac ? "\u21E7" : "Shift");
    if (sc.alt) parts.push(isMac ? "\u2325" : "Alt");
    if (sc.meta) parts.push(isMac ? "\u2318" : "Meta");
    parts.push(sc.key.toUpperCase());
    return parts.join(isMac ? "" : " + ");
  }

  const SC_EDIT = _parseShortcut(SHORTCUT_EDIT);
  const SC_PREVIEW = _parseShortcut(SHORTCUT_PREVIEW);

  // ─── Language display names & flags ──────────────────
  /** @type {Object<string, LangMeta>} */
  const LANG_META = {
    af: { flag: "🇿🇦", name: "Afrikaans" },
    am: { flag: "🇪🇹", name: "Amharic" },
    ar: { flag: "🇸🇦", name: "Arabic" },
    "ar-dz": { flag: "🇩🇿", name: "Arabic (Algeria)" },
    ast: { flag: "🇪🇸", name: "Asturian" },
    az: { flag: "🇦🇿", name: "Azerbaijani" },
    be: { flag: "🇧🇾", name: "Belarusian" },
    bg: { flag: "🇧🇬", name: "Bulgarian" },
    bn: { flag: "🇧🇩", name: "Bengali" },
    br: { flag: "🇫🇷", name: "Breton" },
    bs: { flag: "🇧🇦", name: "Bosnian" },
    ca: { flag: "🇦🇩", name: "Catalan" },
    cs: { flag: "🇨🇿", name: "Czech" },
    cy: { flag: "🏴\uDB40\uDC67\uDB40\uDC62\uDB40\uDC77\uDB40\uDC6C\uDB40\uDC73\uDB40\uDC7F", name: "Welsh" },
    da: { flag: "🇩🇰", name: "Danish" },
    de: { flag: "🇩🇪", name: "German" },
    "de-at": { flag: "🇦🇹", name: "German (Austria)" },
    "de-ch": { flag: "🇨🇭", name: "German (Switzerland)" },
    dsb: { flag: "🇩🇪", name: "Lower Sorbian" },
    el: { flag: "🇬🇷", name: "Greek" },
    en: { flag: "🇬🇧", name: "English" },
    "en-au": { flag: "🇦🇺", name: "English (Australia)" },
    "en-ca": { flag: "🇨🇦", name: "English (Canada)" },
    "en-gb": { flag: "🇬🇧", name: "English (UK)" },
    "en-ie": { flag: "🇮🇪", name: "English (Ireland)" },
    "en-in": { flag: "🇮🇳", name: "English (India)" },
    "en-nz": { flag: "🇳🇿", name: "English (New Zealand)" },
    "en-us": { flag: "🇺🇸", name: "English (US)" },
    "en-za": { flag: "🇿🇦", name: "English (South Africa)" },
    eo: { flag: "🌍", name: "Esperanto" },
    es: { flag: "🇪🇸", name: "Spanish" },
    "es-ar": { flag: "🇦🇷", name: "Spanish (Argentina)" },
    "es-cl": { flag: "🇨🇱", name: "Spanish (Chile)" },
    "es-co": { flag: "🇨🇴", name: "Spanish (Colombia)" },
    "es-mx": { flag: "🇲🇽", name: "Spanish (Mexico)" },
    "es-ni": { flag: "🇳🇮", name: "Spanish (Nicaragua)" },
    "es-pe": { flag: "🇵🇪", name: "Spanish (Peru)" },
    "es-ve": { flag: "🇻🇪", name: "Spanish (Venezuela)" },
    et: { flag: "🇪🇪", name: "Estonian" },
    eu: { flag: "🇪🇸", name: "Basque" },
    fa: { flag: "🇮🇷", name: "Persian" },
    fi: { flag: "🇫🇮", name: "Finnish" },
    fr: { flag: "🇫🇷", name: "French" },
    "fr-be": { flag: "🇧🇪", name: "French (Belgium)" },
    "fr-ca": { flag: "🇨🇦", name: "French (Canada)" },
    "fr-ch": { flag: "🇨🇭", name: "French (Switzerland)" },
    fy: { flag: "🇳🇱", name: "Frisian" },
    ga: { flag: "🇮🇪", name: "Irish" },
    gd: { flag: "🏴\uDB40\uDC67\uDB40\uDC62\uDB40\uDC73\uDB40\uDC63\uDB40\uDC74\uDB40\uDC7F", name: "Scottish Gaelic" },
    gl: { flag: "🇪🇸", name: "Galician" },
    he: { flag: "🇮🇱", name: "Hebrew" },
    hi: { flag: "🇮🇳", name: "Hindi" },
    hr: { flag: "🇭🇷", name: "Croatian" },
    hsb: { flag: "🇩🇪", name: "Upper Sorbian" },
    hu: { flag: "🇭🇺", name: "Hungarian" },
    hy: { flag: "🇦🇲", name: "Armenian" },
    ia: { flag: "🌍", name: "Interlingua" },
    id: { flag: "🇮🇩", name: "Indonesian" },
    ig: { flag: "🇳🇬", name: "Igbo" },
    io: { flag: "🌍", name: "Ido" },
    is: { flag: "🇮🇸", name: "Icelandic" },
    it: { flag: "🇮🇹", name: "Italian" },
    ja: { flag: "🇯🇵", name: "Japanese" },
    ka: { flag: "🇬🇪", name: "Georgian" },
    kab: { flag: "🇩🇿", name: "Kabyle" },
    kk: { flag: "🇰🇿", name: "Kazakh" },
    km: { flag: "🇰🇭", name: "Khmer" },
    kn: { flag: "🇮🇳", name: "Kannada" },
    ko: { flag: "🇰🇷", name: "Korean" },
    ky: { flag: "🇰🇬", name: "Kyrgyz" },
    lb: { flag: "🇱🇺", name: "Luxembourgish" },
    lo: { flag: "🇱🇦", name: "Lao" },
    lt: { flag: "🇱🇹", name: "Lithuanian" },
    lv: { flag: "🇱🇻", name: "Latvian" },
    mk: { flag: "🇲🇰", name: "Macedonian" },
    ml: { flag: "🇮🇳", name: "Malayalam" },
    mn: { flag: "🇲🇳", name: "Mongolian" },
    mr: { flag: "🇮🇳", name: "Marathi" },
    ms: { flag: "🇲🇾", name: "Malay" },
    my: { flag: "🇲🇲", name: "Burmese" },
    nb: { flag: "🇳🇴", name: "Norwegian Bokm\u00E5l" },
    ne: { flag: "🇳🇵", name: "Nepali" },
    nl: { flag: "🇳🇱", name: "Dutch" },
    "nl-be": { flag: "🇧🇪", name: "Dutch (Belgium)" },
    nn: { flag: "🇳🇴", name: "Norwegian Nynorsk" },
    no: { flag: "🇳🇴", name: "Norwegian" },
    os: { flag: "🇬🇪", name: "Ossetic" },
    pa: { flag: "🇮🇳", name: "Punjabi" },
    pl: { flag: "🇵🇱", name: "Polish" },
    pt: { flag: "🇵🇹", name: "Portuguese" },
    "pt-br": { flag: "🇧🇷", name: "Portuguese (Brazil)" },
    ro: { flag: "🇷🇴", name: "Romanian" },
    ru: { flag: "🇷🇺", name: "Russian" },
    si: { flag: "🇱🇰", name: "Sinhala" },
    sk: { flag: "🇸🇰", name: "Slovak" },
    sl: { flag: "🇸🇮", name: "Slovenian" },
    sq: { flag: "🇦🇱", name: "Albanian" },
    sr: { flag: "🇷🇸", name: "Serbian" },
    "sr-latn": { flag: "🇷🇸", name: "Serbian (Latin)" },
    sv: { flag: "🇸🇪", name: "Swedish" },
    sw: { flag: "🇹🇿", name: "Swahili" },
    ta: { flag: "🇮🇳", name: "Tamil" },
    te: { flag: "🇮🇳", name: "Telugu" },
    tg: { flag: "🇹🇯", name: "Tajik" },
    th: { flag: "🇹🇭", name: "Thai" },
    tk: { flag: "🇹🇲", name: "Turkmen" },
    tl: { flag: "🇵🇭", name: "Filipino" },
    tr: { flag: "🇹🇷", name: "Turkish" },
    tt: { flag: "🇷🇺", name: "Tatar" },
    udm: { flag: "🇷🇺", name: "Udmurt" },
    uk: { flag: "🇺🇦", name: "Ukrainian" },
    ur: { flag: "🇵🇰", name: "Urdu" },
    uz: { flag: "🇺🇿", name: "Uzbek" },
    vi: { flag: "🇻🇳", name: "Vietnamese" },
    zh: { flag: "🇨🇳", name: "Chinese" },
    "zh-cn": { flag: "🇨🇳", name: "Chinese (China)" },
    "zh-hans": { flag: "🇨🇳", name: "Chinese (Simplified)" },
    "zh-hant": { flag: "🇹🇼", name: "Chinese (Traditional)" },
    "zh-tw": { flag: "🇹🇼", name: "Chinese (Taiwan)" },
  };

  /**
   * Look up LANG_META entry with case-insensitive matching and regional fallback.
   * @param {string} code - Language code (e.g. "en", "pt-BR", "sr-Latn").
   * @returns {{ flag: string, name: string } | undefined}
   */
  function langMeta(code) {
    const lower = code.toLowerCase();
    return LANG_META[lower] || LANG_META[lower.split("-")[0]];
  }

  /**
   * @param {string} code - ISO 639-1 language code.
   * @returns {string} Emoji flag + English name, or uppercased code if unknown.
   */
  function langLabel(code) {
    const meta = langMeta(code);
    if (meta) return meta.flag + "  " + meta.name;
    return code.toUpperCase();
  }

  // ─── Clipboard Copy Helper ───────────────────────────

  /** @type {string} */
  const ICON_COPY_SVG =
    '<svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" ' +
    'stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">' +
    '<rect x="5.5" y="5.5" width="8" height="8" rx="1.5"/>' +
    '<path d="M10.5 5.5V3.5a1.5 1.5 0 0 0-1.5-1.5H3.5A1.5 1.5 0 0 0 2 3.5V9a1.5 1.5 0 0 0 1.5 1.5h2"/></svg>';
  /** @type {string} */
  const ICON_CHECK_SVG =
    '<svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" ' +
    'stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
    '<path d="M3.5 8.5l3 3 6-7"/></svg>';
  /** @type {string} */
  const ICON_CHECKBOX_SVG =
    '<svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" ' +
    'stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">' +
    '<rect x="2" y="2" width="12" height="12" rx="2"/></svg>';
  /** @type {string} */
  const ICON_CHECKBOX_CHECKED_SVG =
    '<svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" ' +
    'stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">' +
    '<rect x="2" y="2" width="12" height="12" rx="2" fill="currentColor" fill-opacity="0.15"/>' +
    '<path d="M5 8l2.5 2.5L11 6"/></svg>';

  /**
   * Make a container element copyable: clicking anywhere on it copies text to
   * the clipboard, swaps the icon to a checkmark, and adds a `--copied` CSS
   * modifier class for visual feedback.
   *
   * @param {HTMLElement}        container   - The clickable wrapper element.
   * @param {HTMLElement}        iconEl      - Element whose innerHTML is swapped (copy ↔ check).
   * @param {function(): string} getText     - Returns the string to copy.
   * @param {string}             copiedClass - CSS class toggled during feedback (e.g. "foo--copied").
   * @param {number}             [duration]  - Feedback duration in ms (default 1500).
   * @returns {void}
   */
  function _makeCopyable(container, iconEl, getText, copiedClass, duration) {
    const ms = duration || 1500;
    iconEl.innerHTML = ICON_COPY_SVG;
    container.style.cursor = "pointer";
    container.addEventListener("click", async function () {
      const text = getText();
      if (!text || container.classList.contains(copiedClass)) return;
      try {
        await navigator.clipboard.writeText(text);
      } catch {
        return;
      }
      container.classList.add(copiedClass);
      iconEl.innerHTML = ICON_CHECK_SVG;
      setTimeout(function () {
        container.classList.remove(copiedClass);
        iconEl.innerHTML = ICON_COPY_SVG;
      }, ms);
    });
  }

  // ─── State ───────────────────────────────────────────
  /** @type {"inactive"|"active"|"editing"} */
  let state = "inactive";
  /** @type {string} */
  const _EDIT_MODE_KEY = "lt_edit_mode";

  /**
   * Persist edit-mode flag to sessionStorage and reload the page.
   * Edit mode is restored on the next page load via DOMContentLoaded.
   * @returns {void}
   */
  function _reloadPage() {
    if (state === "active" || state === "editing") {
      try { sessionStorage.setItem(_EDIT_MODE_KEY, "1"); } catch (e) { /* quota / private */ }
    }
    window.location.reload();
  }

  /**
   * Update all DOM elements matching a msgid/context with new display text.
   * Handles both inline text spans and attribute translations.
   * @param {string}  msgid          - The gettext msgid.
   * @param {string}  context        - The gettext context (empty string if none).
   * @param {string}  displayText    - The resolved text to display.
   * @param {boolean} isPreviewEntry - Whether this is an inactive preview entry.
   * @returns {void}
   */
  function _updateDomInPlace(msgid, context, displayText, isPreviewEntry) {
    // NOTE: We always use innerHTML so that HTML formatting tags in translations
    // (e.g. <strong>, <em>) render correctly after save without a page reload.
    // This code path only runs for the translator who just saved via the widget
    // (a trusted, permissioned user previewing their own input).  Other visitors
    // see the server-rendered version on next page load.  If _updateDomInPlace
    // is ever used for untrusted content, HTML sanitization must be added here.

    // Update registered text nodes (and their wrapping spans if in edit mode)
    for (let ri = 0; ri < registeredNodes.length; ri++) {
      const entry = registeredNodes[ri];
      if (entry.msgid === msgid && entry.context === context) {
        if (entry.span) {
          entry.span.innerHTML = displayText;
          const ft = _firstTextNode(entry.span);
          if (ft) entry.node = ft;
          _syncPreviewClass(entry.span, isPreviewEntry);
        } else {
          entry.node.textContent = displayText;
        }
      }
    }

    // Update attribute translations (always use textContent — attributes don't render HTML)
    const attrEls = document.querySelectorAll(SEL_ATTR_TRANSLATIONS);
    for (let j = 0; j < attrEls.length; j++) {
      const attrs = _parseLtAttrs(/** @type {HTMLElement} */ (attrEls[j]));
      for (let k = 0; k < attrs.length; k++) {
        if (attrs[k].m === msgid && (attrs[k].c || "") === context) {
          attrEls[j].setAttribute(attrs[k].a, displayText);
          _syncPreviewClass(attrEls[j], isPreviewEntry);
          break;
        }
      }
    }

    // Update PREVIEW_ENTRIES and action bar
    if (PREVIEW) {
      if (isPreviewEntry) {
        let found = false;
        for (let p = 0; p < PREVIEW_ENTRIES.length; p++) {
          if (PREVIEW_ENTRIES[p].m === msgid && (PREVIEW_ENTRIES[p].c || "") === context) {
            found = true;
            break;
          }
        }
        if (!found) PREVIEW_ENTRIES.push({m: msgid, c: context});
      } else {
        PREVIEW_ENTRIES = PREVIEW_ENTRIES.filter(function (e) {
          return !(e.m === msgid && (e.c || "") === context);
        });
      }
      _updateActionBar();
    }
  }

  /** @type {HTMLDialogElement|null} */
  let dialog = null;
  /** @type {HTMLElement|null} */
  let currentSpan = null;
  /** @type {string|null} - HTML attribute name when editing an attribute translation. */
  let currentAttrName = null;
  /** @type {boolean} */
  let historyOpen = false;
  /** @type {string} */
  let _iconHistory = "";
  /** @type {string} */
  let _iconBack = "";

  // ─── Editor State (tabbed editing) ───────────────────
  /** @type {TranslationData|null} - Cached API data for the current edit session. */
  let _editData = null;
  /** @type {string} - Currently selected language tab for editing. */
  let _editLang = "";
  /** @type {Object<string, Object<string, string>>} - Accumulated edited text values keyed by language, each is {formIndex: value}. */
  let _editedValues = {};
  /** @type {Object<string, boolean>} - Accumulated active flags keyed by language. */
  let _editedActiveFlags = {};
  /** @type {Object<string, Object<string, string>>} - Snapshot of initial text values from API (for dirty detection). */
  let _originalValues = {};
  /** @type {Object<string, boolean>} - Snapshot of initial active flags from API (for dirty detection). */
  let _originalActiveFlags = {};
  /** @type {Object<string, boolean>} - Languages marked for override deletion (submitted on Save). */
  let _deletionsMarked = {};
  /** @type {boolean} - When true, the next Save click bypasses HTML validation (user acknowledged warnings). */
  let _htmlWarningAcked = false;
  /** @type {string} - The msgid_plural for the current edit session (empty for singular). */
  let _editMsgidPlural = "";

  // ─── API Client ──────────────────────────────────────

  const api = {
    /**
     * Fetch all language translations for a single msgid.
     * @param {string} msgid  - The gettext message identifier.
     * @param {string} context - The gettext context (empty string if none).
     * @param {string} [msgidPlural] - The msgid_plural (empty for singular).
     * @returns {Promise<TranslationData>}
     */
    getTranslations: async function (msgid, context, msgidPlural) {
      const paramObj = { msgid: msgid, context: context };
      if (msgidPlural) paramObj.msgid_plural = msgidPlural;
      const params = new URLSearchParams(paramObj);
      const resp = await fetch(API_BASE + "/translations/?" + params, {
        credentials: "same-origin",
        cache: "no-store",
      });
      if (!resp.ok) throw new Error("GET failed: " + resp.status);
      return resp.json();
    },

    /**
     * Persist translation overrides to the database.
     * @param {string}                          msgid        - The gettext message identifier.
     * @param {string}                          context      - The gettext context.
     * @param {Object<string, Object<string, string>>} translations - Map of language code to {formIndex: value}.
     * @param {Object<string, boolean>}         activeFlags  - Map of language code to active/inactive flag.
     * @param {string}                          [msgidPlural] - The msgid_plural (empty for singular).
     * @returns {Promise<SaveResponse>}
     */
    saveTranslations: async function (msgid, context, translations, activeFlags, msgidPlural) {
      const payload = {
        msgid: msgid,
        context: context,
        translations: translations,
        active_flags: activeFlags || {},
        page_language: _pageLang(),
      };
      if (msgidPlural) payload.msgid_plural = msgidPlural;
      const resp = await fetch(API_BASE + "/translations/save/", {
        method: "POST",
        credentials: "same-origin",
        headers: {
          "Content-Type": "application/json",
          "X-CSRFToken": CSRF_TOKEN,
        },
        body: JSON.stringify(payload),
      });
      if (!resp.ok) {
        /** @type {Record<string, unknown>} */
        let errData;
        try { errData = await resp.json(); } catch { errData = {}; }
        /** @type {ApiError} */
        const apiErr = Object.assign(
          new Error(/** @type {string} */ (errData.error) || "POST failed: " + resp.status),
          { details: /** @type {Object<string, string[]>|null} */ (errData.details) || null }
        );
        throw apiErr;
      }
      return /** @type {Promise<SaveResponse>} */ (resp.json());
    },

    /**
     * Fetch the edit history for a msgid/context pair.
     * @param {string} msgid   - The gettext message identifier.
     * @param {string} context - The gettext context.
     * @param {string} [msgidPlural] - The msgid_plural (empty for singular).
     * @returns {Promise<{history: HistoryEntry[]}>}
     */
    getHistory: async function (msgid, context, msgidPlural) {
      const paramObj = { msgid: msgid, context: context };
      if (msgidPlural) paramObj.msgid_plural = msgidPlural;
      const params = new URLSearchParams(paramObj);
      const resp = await fetch(API_BASE + "/translations/history/?" + params, {
        credentials: "same-origin",
      });
      if (!resp.ok) throw new Error("GET failed: " + resp.status);
      return resp.json();
    },

    /**
     * Delete DB override(s) for a msgid/context.
     * @param {string}   msgid     - The gettext message identifier.
     * @param {string}   context   - The gettext context.
     * @param {string[]} languages - Language codes to delete.
     * @param {string}   [msgidPlural] - The msgid_plural (empty for singular).
     * @returns {Promise<DeleteResponse>}
     */
    deleteTranslation: async function (msgid, context, languages, msgidPlural) {
      const payload = {
        msgid: msgid,
        context: context,
        page_language: _pageLang(),
      };
      if (msgidPlural) payload.msgid_plural = msgidPlural;
      if (languages && languages.length) payload.languages = languages;
      const resp = await fetch(API_BASE + "/translations/delete/", {
        method: "POST",
        credentials: "same-origin",
        headers: {
          "Content-Type": "application/json",
          "X-CSRFToken": CSRF_TOKEN,
        },
        body: JSON.stringify(payload),
      });
      if (!resp.ok) await _throwApiError(resp);
      return /** @type {Promise<DeleteResponse>} */ (resp.json());
    },

    /**
     * Bulk-activate translations for the given msgid/context pairs for a single language.
     * @param {Array<{msgid:string, context:string}>} msgids - Entries to activate.
     * @param {string} language - Language code to activate for.
     * @returns {Promise<BulkActivateResponse>}
     */
    bulkActivate: async function (msgids, language) {
      const resp = await fetch(API_BASE + "/translations/bulk-activate/", {
        method: "POST",
        credentials: "same-origin",
        headers: {
          "Content-Type": "application/json",
          "X-CSRFToken": CSRF_TOKEN,
        },
        body: JSON.stringify({ msgids: msgids, language: language }),
      });
      if (!resp.ok) await _throwApiError(resp);
      return /** @type {Promise<BulkActivateResponse>} */ (resp.json());
    },
  };

  // ─── Toast ───────────────────────────────────────────

  /**
   * @param {string} message - Text to display.
   * @param {"success"|"error"|"info"} [type="success"] - Visual style of the toast.
   * @returns {void}
   */
  function showToast(message, type) {
    type = type || "success";
    const existing = document.querySelector(".lt-toast");
    if (existing) existing.remove();

    const toast = document.createElement("div");
    toast.className = "lt-toast lt-toast--" + type;
    toast.textContent = message;
    document.body.appendChild(toast);

    // Trigger reflow for animation
    void toast.offsetHeight;
    toast.classList.add("lt-toast--visible");

    setTimeout(function () {
      toast.classList.remove("lt-toast--visible");
      setTimeout(function () {
        toast.remove();
      }, 300);
    }, 3000);
  }

  // ─── Modal ───────────────────────────────────────────

  /**
   * Lazily create the shared `<dialog>` element and attach its event listeners.
   * Subsequent calls are no-ops; the dialog is reused across all edit sessions.
   * @returns {void}
   */
  function createDialog() {
    if (dialog) return;

    dialog = document.createElement("dialog");
    dialog.className = "lt-dialog";
    const ICON_HISTORY =
      '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">' +
      '<path d="M8 3.5V8L10.5 10.5M14 8A6 6 0 1 1 2 8a6 6 0 0 1 12 0Z" ' +
      'stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    const ICON_BACK =
      '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">' +
      '<path d="M10 12L6 8L10 4" stroke="currentColor" stroke-width="1.5" ' +
      'stroke-linecap="round" stroke-linejoin="round"/></svg>';
    const ICON_CLOSE =
      '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">' +
      '<path d="M4 4l8 8M12 4l-8 8" stroke="currentColor" stroke-width="1.5" ' +
      'stroke-linecap="round" stroke-linejoin="round"/></svg>';

    dialog.innerHTML =
      '<div class="lt-dialog__form">' +
      '<div class="lt-dialog__header">' +
      '<h2 class="lt-dialog__title">Edit Translation</h2>' +
      '<div class="lt-dialog__header-actions">' +
      '<button type="button" class="lt-btn lt-btn--history" aria-label="History" title="View edit history">' +
      ICON_HISTORY +
      "</button>" +
      '<button type="button" class="lt-dialog__close" aria-label="Close">' +
      ICON_CLOSE +
      "</button>" +
      "</div>" +
      "</div>" +
      '<div class="lt-dialog__msgid"></div>' +
      '<div class="lt-dialog__hint"></div>' +
      '<div class="lt-editor__tabs"></div>' +
      '<div class="lt-dialog__fields"></div>' +
      '<div class="lt-dialog__history"></div>' +
      '<div class="lt-dialog__error"></div>' +
      '<div class="lt-dialog__actions">' +
      '<button type="button" class="lt-btn lt-btn--delete-override" style="display:none">Delete Override</button>' +
      '<button type="button" class="lt-btn lt-btn--cancel">Cancel</button>' +
      '<button type="button" class="lt-btn lt-btn--save">Save</button>' +
      "</div>" +
      '<div class="lt-dialog__loading">Loading translations...</div>' +
      "</div>";

    // Store icon templates for toggling
    _iconHistory = ICON_HISTORY;
    _iconBack = ICON_BACK;

    document.body.appendChild(dialog);

    // Event listeners
    dialog
      .querySelector(".lt-dialog__close")
      .addEventListener("click", closeModal);
    dialog
      .querySelector(".lt-btn--cancel")
      .addEventListener("click", closeModal);
    dialog
      .querySelector(".lt-btn--save")
      .addEventListener("click", handleSave);
    dialog
      .querySelector(".lt-btn--delete-override")
      .addEventListener("click", handleDeleteOverride);
    dialog
      .querySelector(".lt-btn--history")
      .addEventListener("click", toggleHistory);

    // Native <dialog> close event (Escape key)
    dialog.addEventListener("close", function () {
      if (state === "editing") {
        state = "active";
      }
    });

    // Backdrop click closes
    dialog.addEventListener("click", function (e) {
      if (e.target === dialog) {
        closeModal();
      }
    });
  }

  /**
   * Open the translation editor for a translatable element.
   *
   * For inline text elements (`<lt-t>`), `attrInfo` is
   * omitted and the msgid/context are read from the element's `data-lt-msgid`
   * and `data-lt-context` attributes. For attribute translations (e.g. `title`),
   * the caller passes the {@link AttrInfo} descriptor from `data-lt-attrs`.
   *
   * @param {HTMLElement}   element   - The DOM element that was clicked.
   * @param {AttrInfo}      [attrInfo] - Attribute descriptor; omit for inline text.
   * @returns {Promise<void>}
   */
  async function openModal(element, attrInfo) {
    createDialog();
    currentSpan = element;
    currentAttrName = attrInfo ? attrInfo.a : null;
    state = "editing";
    historyOpen = false;
    _showEditView();

    const msgid = attrInfo ? attrInfo.m : element.dataset.ltMsgid;
    const context = attrInfo ? attrInfo.c : (element.dataset.ltContext || "");

    // Resolve msgid_plural from the element's data attribute (set during marker resolution)
    let msgidPlural = element.dataset.ltPlural || "";
    // Also look up in the string table for a matching entry
    if (!msgidPlural) {
      for (const stId in STRING_TABLE) {
        const stEntry = STRING_TABLE[stId];
        if (stEntry.m === msgid && stEntry.c === (context || "") && stEntry.p) {
          msgidPlural = stEntry.p;
          break;
        }
      }
    }

    // Show loading state
    dialog.querySelector(".lt-dialog__fields").innerHTML = "";
    dialog.querySelector(".lt-dialog__loading").style.display = "block";
    const msgidEl = dialog.querySelector(".lt-dialog__msgid");
    msgidEl.dataset.msgid = msgid;
    msgidEl.innerHTML = "";

    const msgidLabel = document.createElement("span");
    msgidLabel.className = "lt-dialog__msgid-label";
    msgidLabel.textContent = currentAttrName ? "msgid \u00b7 " + currentAttrName : "msgid";

    const msgidText = document.createElement("span");
    msgidText.className = "lt-dialog__msgid-text";
    msgidText.textContent = msgid;

    const copyIcon = document.createElement("span");
    copyIcon.className = "lt-dialog__msgid-icon";
    copyIcon.title = "Copy msgid";

    msgidEl.appendChild(msgidLabel);
    msgidEl.appendChild(msgidText);
    msgidEl.appendChild(copyIcon);
    _makeCopyable(
      msgidEl,
      copyIcon,
      function () { return msgidEl.dataset.msgid || ""; },
      "lt-dialog__msgid--copied"
    );
    const openSaveBtn = dialog.querySelector(".lt-btn--save");
    openSaveBtn.disabled = true;
    openSaveBtn.textContent = "Save";
    showDialogError(null);

    dialog.showModal();

    try {
      const data = await api.getTranslations(msgid, context, msgidPlural);
      renderFields(data);
    } catch (err) {
      showToast("Failed to load translations: " + err.message, "error");
      closeModal();
    }
  }

  /**
   * Populate the dialog with tabbed language editing.
   * Called after the translations API responds.
   * @param {TranslationData} data - Payload from `api.getTranslations`.
   * @returns {void}
   */
  function renderFields(data) {
    dialog.querySelector(".lt-dialog__loading").style.display = "none";
    dialog.querySelector(".lt-btn--save").disabled = false;

    // Show translator hint if available
    const hintEl = dialog.querySelector(".lt-dialog__hint");
    if (data.hint) {
      hintEl.textContent = data.hint;
      hintEl.style.display = "block";
    } else {
      hintEl.textContent = "";
      hintEl.style.display = "none";
    }

    // Store data for tab switching
    _editData = data;
    _editedValues = {};
    _editedActiveFlags = {};
    _originalValues = {};
    _originalActiveFlags = {};
    _editMsgidPlural = data.msgid_plural || "";

    const poDefaults = data.defaults || {};

    // Initialize values from API data
    for (let i = 0; i < LANGUAGES.length; i++) {
      const lang = LANGUAGES[i];
      const entry = data.translations[lang] || { msgstr_forms: {}, fuzzy: false };
      // msgstr_forms is {formIndex: value} — use it directly as our edit state
      const forms = entry.msgstr_forms || {};
      // Ensure we have entries for all expected forms
      const nForms = _isPlural() ? _getNplurals(lang) : 1;
      const editForms = {};
      for (let fi = 0; fi < nForms; fi++) {
        editForms[String(fi)] = forms[String(fi)] !== undefined ? forms[String(fi)] : "";
      }
      _editedValues[lang] = editForms;
      const hasOverride = !!entry.has_override;
      _editedActiveFlags[lang] = hasOverride ? entry.is_active !== false : ACTIVE_BY_DEFAULT;
      // Deep copy for original comparison
      _originalValues[lang] = JSON.parse(JSON.stringify(editForms));
      _originalActiveFlags[lang] = _editedActiveFlags[lang];
    }

    // Default edit language: current page language if configured, else first
    const lang = _pageLang();
    _editLang = LANGUAGES.indexOf(lang) !== -1 ? lang : LANGUAGES[0];

    _renderEditorTabs();
    _renderEditorPanels();
    _updateTabIndicators();
  }

  /**
   * Render the language tab bar above the editor panels.
   * Hidden when only one language is configured.
   * @returns {void}
   */
  function _renderEditorTabs() {
    const tabBar = dialog.querySelector(".lt-editor__tabs");
    tabBar.innerHTML = "";

    if (LANGUAGES.length <= 1) {
      tabBar.style.display = "none";
      return;
    }

    tabBar.style.display = "";

    for (let i = 0; i < LANGUAGES.length; i++) {
      (function (lang) {
        const entry = (_editData && _editData.translations[lang]) || {};
        const pill = document.createElement("button");
        pill.type = "button";
        pill.className = "lt-editor__tab" + (_editLang === lang ? " lt-editor__tab--active" : "") + (!_isEditable(lang) ? " lt-editor__tab--readonly" : "");

        const label = document.createTextNode(langLabel(lang));
        pill.appendChild(label);

        // Draft badge
        if (DRAFT_LANGUAGES.indexOf(lang) !== -1) {
          const draftBadge = document.createElement("span");
          draftBadge.className = "lt-editor__draft-badge";
          draftBadge.textContent = "Draft";
          pill.appendChild(draftBadge);
        }

        pill.dataset.lang = lang;
        pill.addEventListener("click", function () {
          if (_editLang === lang) return;
          _switchEditLang(lang);
        });
        tabBar.appendChild(pill);
      })(LANGUAGES[i]);
    }
  }

  /**
   * Switch the active edit language tab.
   * Persists current edits, swaps languages, and re-renders the editor.
   * @param {string} newLang - Language code to switch to.
   * @returns {void}
   */
  function _switchEditLang(newLang) {
    _persistCurrentEdit();
    _editLang = newLang;

    // Update tab active states without full re-render
    const tabs = dialog.querySelectorAll(".lt-editor__tab");
    for (let i = 0; i < tabs.length; i++) {
      if (tabs[i].dataset.lang === newLang) {
        tabs[i].classList.add("lt-editor__tab--active");
      } else {
        tabs[i].classList.remove("lt-editor__tab--active");
      }
    }

    _renderEditorPanels();
    _updateTabIndicators();
  }

  /**
   * Save current textarea value(s) and toggle state to the accumulated edit stores.
   * Called before tab switches and before save.
   * @returns {void}
   */
  function _persistCurrentEdit() {
    if (!_editLang || !dialog) return;

    // Persist all form textareas for this language
    const nForms = _isPlural() ? _getNplurals(_editLang) : 1;
    const forms = _editedValues[_editLang] || {};
    for (let fi = 0; fi < nForms; fi++) {
      const ta = dialog.querySelector("#lt-input-" + _editLang + "-" + fi);
      if (ta) {
        forms[String(fi)] = ta.value;
      }
    }
    _editedValues[_editLang] = forms;

    const toggle = dialog.querySelector("#lt-active-" + _editLang);
    if (toggle) {
      _editedActiveFlags[_editLang] = toggle.checked;
    }
  }

  /**
   * Check whether a language has unsaved changes relative to the API snapshot.
   * @param {string} lang - Language code.
   * @returns {boolean}
   */
  function _isLangDirty(lang) {
    if (_deletionsMarked[lang]) return true;
    // Compare per-form values
    const edited = _editedValues[lang] || {};
    const original = _originalValues[lang] || {};
    for (const key in edited) {
      if (edited[key] !== original[key]) return true;
    }
    for (const key2 in original) {
      if (original[key2] !== edited[key2]) return true;
    }
    if (_editedActiveFlags[lang] !== _originalActiveFlags[lang]) return true;
    return false;
  }

  /**
   * Update left-border status indicators and tooltips on each language tab.
   * Reads the current textarea/toggle for `_editLang` live (without persisting).
   * @returns {void}
   */
  function _updateTabIndicators() {
    if (!dialog || LANGUAGES.length <= 1) return;
    const tabs = dialog.querySelectorAll(".lt-editor__tab");
    for (let i = 0; i < tabs.length; i++) {
      const lang = tabs[i].dataset.lang;
      const markedForDelete = !!_deletionsMarked[lang];
      let dirty;
      let activeNow;
      if (lang === _editLang) {
        // Read live from DOM for the active tab
        const nForms = _isPlural() ? _getNplurals(lang) : 1;
        let formsDirty = false;
        for (let fi = 0; fi < nForms; fi++) {
          const ta = dialog.querySelector("#lt-input-" + lang + "-" + fi);
          const origVal = (_originalValues[lang] || {})[String(fi)] || "";
          if (ta && ta.value !== origVal) {
            formsDirty = true;
            break;
          }
        }
        const cb = dialog.querySelector("#lt-active-" + lang);
        dirty = markedForDelete || formsDirty || (cb && cb.checked !== _originalActiveFlags[lang]);
        activeNow = cb ? cb.checked : _editedActiveFlags[lang];
      } else {
        dirty = _isLangDirty(lang);
        activeNow = _editedActiveFlags[lang] !== undefined ? _editedActiveFlags[lang] : ACTIVE_BY_DEFAULT;
      }
      // Priority: delete > dirty > inactive
      tabs[i].classList.remove("lt-editor__tab--status-dirty", "lt-editor__tab--status-inactive", "lt-editor__tab--status-delete");
      delete tabs[i].dataset.tooltip;
      if (markedForDelete) {
        tabs[i].classList.add("lt-editor__tab--status-delete");
        tabs[i].dataset.tooltip = "Marked for deletion";
      } else if (dirty) {
        tabs[i].classList.add("lt-editor__tab--status-dirty");
        tabs[i].dataset.tooltip = "Unsaved changes";
      } else {
        const entry = (_editData && _editData.translations[lang]) || {};
        if (entry.has_override && !activeNow) {
          tabs[i].classList.add("lt-editor__tab--status-inactive");
          tabs[i].dataset.tooltip = "Inactive override";
        }
      }
    }
  }

  /**
   * Render the editor content area for the currently selected language.
   * @returns {void}
   */
  function _renderEditorPanels() {
    const container = dialog.querySelector(".lt-dialog__fields");
    container.innerHTML = "";

    const wrapper = document.createElement("div");
    wrapper.className = "lt-editor__single";
    _renderEditPanel(wrapper);
    container.appendChild(wrapper);

    // Focus and auto-resize first textarea
    const ta = container.querySelector("textarea");
    if (ta) {
      ta.focus();
      ta.style.height = "auto";
      ta.style.height = ta.scrollHeight + "px";
    }
    _syncDeleteOverride();
  }

  /**
   * Render the edit panel for the currently selected language.
   * Contains .po default hint, textarea(s), and active toggle.
   * For plural entries, renders N textareas (one per form).
   * @param {HTMLElement} container - Parent element to render into.
   * @returns {void}
   */
  function _renderEditPanel(container) {
    container.innerHTML = "";
    const lang = _editLang;
    const entry = (_editData.translations[lang]) || { msgstr_forms: {}, fuzzy: false };
    const poDefaults = _editData.defaults || {};
    const poDefault = poDefaults[lang] || {};
    const hasOverride = !!entry.has_override;
    const markedForDelete = !!_deletionsMarked[lang];
    const plural = _isPlural();
    const nForms = plural ? _getNplurals(lang) : 1;

    // Show language label in single-language mode (no tabs to indicate it)
    if (LANGUAGES.length <= 1) {
      const langLabelEl = document.createElement("label");
      langLabelEl.className = "lt-field__label";
      langLabelEl.textContent = langLabel(lang);
      langLabelEl.setAttribute("for", "lt-input-" + lang + "-0");
      container.appendChild(langLabelEl);
    }

    // .po default hint (click to copy) — singular only; plural defaults are interleaved below
    if (!plural) {
      const singleDefault = poDefault["0"] || "";
      if (singleDefault) {
        const poWrap = document.createElement("div");
        poWrap.className = "lt-field__po-wrap";

        const poHeader2 = document.createElement("div");
        poHeader2.className = "lt-field__po-header";

        const poLabel2 = document.createElement("span");
        poLabel2.className = "lt-field__po-label";
        poLabel2.textContent = "Default";

        const poCopyIcon2 = document.createElement("span");
        poCopyIcon2.className = "lt-field__po-copy";
        poCopyIcon2.title = "Copy default";

        poHeader2.appendChild(poLabel2);
        poHeader2.appendChild(poCopyIcon2);

        const poText2 = document.createElement("div");
        poText2.className = "lt-field__po-default";
        poText2.textContent = singleDefault;

        poWrap.appendChild(poHeader2);
        poWrap.appendChild(poText2);

        _makeCopyable(
          poWrap,
          poCopyIcon2,
          function () { return singleDefault; },
          "lt-field__po-wrap--copied"
        );

        container.appendChild(poWrap);
      }
    }

    // Get the primary default for toggle visibility logic
    const primaryDefault = poDefault["0"] || "";

    // Render textarea(s) — one per form for plural, single for singular
    // For plural entries, each form's .po default is rendered right above its textarea.
    const langEditable = _isEditable(lang);
    for (let formIdx = 0; formIdx < nForms; formIdx++) {
      // Form label for plural entries
      if (plural) {
        const formLabel = document.createElement("label");
        formLabel.className = "lt-field__form-label";
        formLabel.textContent = _formLabel(lang, formIdx);
        formLabel.setAttribute("for", "lt-input-" + lang + "-" + formIdx);
        container.appendChild(formLabel);

        // Per-form .po default (interleaved with textareas)
        var formDefault = poDefault[String(formIdx)] || "";
        if (formDefault) {
          var poFormWrap = document.createElement("div");
          poFormWrap.className = "lt-field__po-wrap lt-field__po-form";

          var poHeader = document.createElement("div");
          poHeader.className = "lt-field__po-header";

          var poLabel = document.createElement("span");
          poLabel.className = "lt-field__po-label";
          poLabel.textContent = "Default";

          var poCopyIcon = document.createElement("span");
          poCopyIcon.className = "lt-field__po-copy";
          poCopyIcon.title = "Copy default";

          poHeader.appendChild(poLabel);
          poHeader.appendChild(poCopyIcon);

          var poText = document.createElement("div");
          poText.className = "lt-field__po-default";
          poText.textContent = formDefault;

          poFormWrap.appendChild(poHeader);
          poFormWrap.appendChild(poText);
          container.appendChild(poFormWrap);

          _makeCopyable(
            poFormWrap,
            poCopyIcon,
            (function (val) { return function () { return val; }; })(formDefault),
            "lt-field__po-wrap--copied"
          );
        }
      }

      const textarea = document.createElement("textarea");
      textarea.className = "lt-field__input";
      textarea.id = "lt-input-" + lang + "-" + formIdx;
      textarea.name = lang + "-" + formIdx;
      const currentForms = _editedValues[lang] || {};
      textarea.value = currentForms[String(formIdx)] || "";
      textarea.rows = 3;
      if (entry.fuzzy) {
        textarea.classList.add("lt-field__input--fuzzy");
      }
      if (markedForDelete) {
        textarea.disabled = true;
        textarea.classList.add("lt-field__input--marked-delete");
      }
      if (!langEditable) {
        textarea.disabled = true;
        textarea.classList.add("lt-field__input--readonly");
      }

      // Auto-resize on input
      (function (ta) {
        ta.addEventListener("input", function () {
          this.style.height = "auto";
          this.style.height = this.scrollHeight + "px";
          _updateTabIndicators();
          // Reset HTML warning override so the next Save re-validates
          if (_htmlWarningAcked) {
            _htmlWarningAcked = false;
            showDialogError(null);
            const saveBtn = dialog.querySelector(".lt-btn--save");
            if (saveBtn) saveBtn.textContent = "Save";
          }
        });
      })(textarea);

      // Modified-from-default indicator
      (function (ta, defVal) {
        /** @returns {void} */
        function syncModified() {
          ta.classList.toggle("lt-field__input--modified", ta.value !== defVal);
        }
        syncModified();
        ta.addEventListener("input", syncModified);
      })(textarea, poDefault[String(formIdx)] || "");

      container.appendChild(textarea);
    }

    // Active toggle
    const isActive = _editedActiveFlags[lang];
    const currentVal = (_editedValues[lang] || {})["0"] || "";

    const isDraftLang = DRAFT_LANGUAGES.indexOf(lang) !== -1;

    const toggleWrap = document.createElement("label");
    toggleWrap.className = "lt-field__toggle";
    if (!langEditable) {
      // Non-editable languages — hide the toggle
      toggleWrap.style.display = "none";
    } else if (isDraftLang) {
      // Draft languages are always active — hide the toggle entirely
      toggleWrap.style.display = "none";
    } else if (markedForDelete) {
      toggleWrap.style.visibility = "hidden";
    } else if (!hasOverride && currentVal === primaryDefault) {
      toggleWrap.style.display = "none";
    }

    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.className = "lt-field__toggle-input";
    checkbox.id = "lt-active-" + lang;
    checkbox.checked = isActive;

    const slider = document.createElement("span");
    slider.className = "lt-field__toggle-slider";

    const toggleLabelEl = document.createElement("span");
    toggleLabelEl.className = "lt-field__toggle-label";
    toggleLabelEl.textContent = isActive ? "Active" : "Inactive";

    checkbox.addEventListener("change", function () {
      toggleLabelEl.textContent = checkbox.checked ? "Active" : "Inactive";
      _updateTabIndicators();
    });

    toggleWrap.title = "Inactive overrides are saved but won\u2019t take effect until activated.";
    toggleWrap.appendChild(checkbox);
    toggleWrap.appendChild(slider);
    toggleWrap.appendChild(toggleLabelEl);

    // Show/hide toggle based on whether any form differs from default
    (function (toggle, defaults, cb, defaultActive, hadOverride, draft, langCode, parent) {
      /** @returns {void} */
      function syncToggle() {
        if (draft) return; // Draft languages are always active — keep toggle hidden
        const nf = _isPlural() ? _getNplurals(langCode) : 1;
        let differs = false;
        for (let fi2 = 0; fi2 < nf; fi2++) {
          const ta2 = parent.querySelector("#lt-input-" + langCode + "-" + fi2);
          const defVal = (defaults || {})[String(fi2)] || "";
          if (ta2 && ta2.value !== defVal) { differs = true; break; }
        }
        toggle.style.display = (differs || hadOverride) ? "" : "none";
        if (!differs && !hadOverride) {
          cb.checked = defaultActive;
        }
      }
      // Attach input listeners to all textareas
      const nf = _isPlural() ? _getNplurals(langCode) : 1;
      for (let fi2 = 0; fi2 < nf; fi2++) {
        const ta2 = parent.querySelector("#lt-input-" + langCode + "-" + fi2);
        if (ta2) {
          ta2.addEventListener("input", syncToggle);
        }
      }
    })(toggleWrap, poDefault, checkbox, ACTIVE_BY_DEFAULT, hasOverride, isDraftLang, lang, container);

    container.appendChild(toggleWrap);
  }

  /**
   * Display or clear the inline error banner inside the dialog.
   *
   * When `details` is provided, the error is rendered as per-language lines
   * (e.g. missing `%(key)s` placeholders). Otherwise `message` is shown as plain text.
   *
   * @param {string|null}                     message - Error message, or null to clear.
   * @param {Object<string, string[]>|null}   [details] - Per-language error arrays from the server.
   * @returns {void}
   */
  function showDialogError(message, details) {
    const errorEl = dialog.querySelector(".lt-dialog__error");
    if (!message) {
      errorEl.innerHTML = "";
      errorEl.style.display = "none";
      return;
    }
    errorEl.innerHTML = "";
    if (details) {
      // Structured per-language errors: {lang: ["missing %(key)s", ...]}
      for (const lang in details) {
        const line = document.createElement("div");
        const meta = langMeta(lang);
        const label = meta ? meta.flag + " " + meta.name : lang.toUpperCase();
        line.textContent = label + ": " + details[lang].join(", ");
        errorEl.appendChild(line);
      }
    } else {
      errorEl.textContent = message;
    }
    errorEl.style.display = "block";
  }

  /**
   * Show or hide the "Delete Override" footer button and sync its checkbox state.
   * Visible whenever an override exists on the server for the current language.
   * The button acts as a toggle: clicking marks/unmarks the language for deletion.
   * @returns {void}
   */
  function _syncDeleteOverride() {
    if (!dialog) return;
    const btn = dialog.querySelector(".lt-btn--delete-override");
    if (!btn || !_editData) return;
    const lang = _editLang;
    const entry = (_editData.translations[lang]) || {};

    if (!entry.has_override || !_isEditable(lang)) {
      btn.style.display = "none";
      return;
    }

    btn.style.display = "";
    const marked = !!_deletionsMarked[lang];

    if (marked) {
      btn.innerHTML = ICON_CHECKBOX_CHECKED_SVG + " Delete Override";
      btn.classList.add("lt-btn--delete-override--checked");
    } else {
      btn.innerHTML = ICON_CHECKBOX_SVG + " Delete Override";
      btn.classList.remove("lt-btn--delete-override--checked");
    }
  }

  /**
   * Toggle the current language's "marked for deletion" flag.
   * Actual deletion happens on Save (all marked languages at once).
   * @returns {void}
   */
  function handleDeleteOverride() {
    _persistCurrentEdit();
    const lang = _editLang;
    if (_deletionsMarked[lang]) {
      delete _deletionsMarked[lang];
    } else {
      _deletionsMarked[lang] = true;
    }
    _renderEditorPanels();
    _updateTabIndicators();
  }

  /**
   * Collect all edited values, deletions, and active flags, then persist via API.
   * Handles both save and delete operations in parallel.
   * @returns {Promise<void>}
   */
  async function handleSave() {
    const saveBtn = dialog.querySelector(".lt-btn--save");
    saveBtn.disabled = true;
    saveBtn.textContent = "Saving...";
    showDialogError(null);

    // Capture whatever is in the current textarea/toggle before sending
    _persistCurrentEdit();

    const { msgid, context } = _getMsgidAndContext();

    // Separate languages into save vs delete groups (only include dirty languages)
    const translations = {};
    const activeFlags = {};
    const langsToDelete = [];
    for (let i = 0; i < LANGUAGES.length; i++) {
      const lang = LANGUAGES[i];
      if (!_isEditable(lang)) continue;
      if (_deletionsMarked[lang]) {
        langsToDelete.push(lang);
        continue;
      }
      if (!_isLangDirty(lang)) continue;
      // Always send as {formIndex: value} dict
      translations[lang] = _editedValues[lang] || {"0": ""};
      activeFlags[lang] = _editedActiveFlags[lang] !== undefined ? _editedActiveFlags[lang] : ACTIVE_BY_DEFAULT;
    }

    // Run save and delete sequentially — SQLite cannot handle concurrent
    // write transactions from parallel requests ("database is locked").
    const hasSave = Object.keys(translations).length > 0;
    const hasDelete = langsToDelete.length > 0;

    if (!hasSave && !hasDelete) {
      saveBtn.disabled = false;
      saveBtn.textContent = "Save";
      closeModal();
      return;
    }

    // ── HTML structure validation (client-side warning) ──
    if (!_htmlWarningAcked && hasSave) {
      const htmlErrors = {};
      for (const hlang in translations) {
        const langForms = translations[hlang];
        for (const hfi in langForms) {
          const errs = _validateHtmlStructure(langForms[hfi]);
          if (errs.length) {
            const errKey = _isPlural() ? hlang + " (form " + hfi + ")" : hlang;
            htmlErrors[errKey] = errs;
          }
        }
      }
      if (Object.keys(htmlErrors).length > 0) {
        showDialogError("Invalid HTML structure", htmlErrors);
        saveBtn.disabled = false;
        saveBtn.textContent = "Save anyway";
        _htmlWarningAcked = true;
        return;
      }
    }

    try {
      let display = null;
      if (hasSave) {
        const saveResult = await api.saveTranslations(msgid, context, translations, activeFlags, _editMsgidPlural);
        if (saveResult && saveResult.display) display = saveResult.display;
      }
      if (hasDelete) {
        const deleteResult = await api.deleteTranslation(msgid, context, langsToDelete, _editMsgidPlural);
        if (deleteResult && deleteResult.display) display = deleteResult.display;
      }
      if (display) {
        if (display.reload_required) {
          // Plural entries: can't update DOM in-place (we don't know which form is displayed)
          showToast("Saved. Reload to see changes.", "success");
        } else {
          _updateDomInPlace(msgid, context, display.text, display.is_preview_entry);
        }
      }
      saveBtn.disabled = false;
      saveBtn.textContent = "Save";
      closeModal();
    } catch (err) {
      showDialogError(err.message, err.details || null);
      saveBtn.disabled = false;
      saveBtn.textContent = "Save";
    }
  }

  /**
   * Look up a single attribute descriptor from the element's `data-lt-attrs` JSON array.
   * @param {HTMLElement} element  - Element carrying `data-lt-attrs`.
   * @param {string}      attrName - Attribute name to find (e.g. "title").
   * @returns {AttrInfo|null} The matching descriptor, or null if not found.
   */
  function _getAttrInfo(element, attrName) {
    const attrs = _parseLtAttrs(element);
    for (let i = 0; i < attrs.length; i++) {
      if (attrs[i].a === attrName) return attrs[i];
    }
    return null;
  }

  // ─── History Panel ──────────────────────────────────

  /** @type {HistoryEntry[]} - Cached entries from the last history fetch. */
  let _historyData = [];
  /** @type {string} - Active language filter ("" = show all languages). */
  let _historyLangFilter = "";

  /**
   * Read the msgid and context for the element currently being edited,
   * accounting for both inline text spans and attribute translations.
   * @returns {{msgid: string, context: string}}
   */
  function _getMsgidAndContext() {
    const attrData = currentAttrName ? _getAttrInfo(currentSpan, currentAttrName) : null;
    return {
      msgid: attrData ? attrData.m : currentSpan.dataset.ltMsgid,
      context: attrData ? attrData.c : (currentSpan.dataset.ltContext || ""),
    };
  }

  /**
   * Toggle the dialog between the edit form and the history timeline.
   * @returns {void}
   */
  function toggleHistory() {
    if (historyOpen) {
      _showEditView();
    } else {
      _showHistoryView();
    }
    historyOpen = !historyOpen;
  }

  /**
   * Switch the dialog chrome to show the translation editor (tabs + fields + save/cancel).
   * @returns {void}
   */
  function _showEditView() {
    if (!dialog) return;
    dialog.querySelector(".lt-dialog__title").textContent = "Edit Translation";
    const btn = dialog.querySelector(".lt-btn--history");
    btn.innerHTML = _iconHistory;
    btn.title = "View edit history";

    const tabBar = dialog.querySelector(".lt-editor__tabs");
    if (tabBar) tabBar.style.display = LANGUAGES.length > 1 ? "" : "none";

    dialog.querySelector(".lt-dialog__fields").style.display = "";
    dialog.querySelector(".lt-dialog__actions").style.display = "";
    dialog.querySelector(".lt-dialog__history").style.display = "none";

    // Restore hint visibility
    if (_editData && _editData.hint) {
      dialog.querySelector(".lt-dialog__hint").style.display = "block";
    }
  }

  /**
   * Switch the dialog chrome to show the history timeline, fetching data from the API.
   * @returns {Promise<void>}
   */
  async function _showHistoryView() {
    if (!dialog) return;
    dialog.querySelector(".lt-dialog__title").textContent = "Edit History";
    const btn = dialog.querySelector(".lt-btn--history");
    btn.innerHTML = _iconBack;
    btn.title = "Back to editing";

    // Persist current edits before switching views
    _persistCurrentEdit();

    const tabBar = dialog.querySelector(".lt-editor__tabs");
    if (tabBar) tabBar.style.display = "none";

    dialog.querySelector(".lt-dialog__fields").style.display = "none";
    dialog.querySelector(".lt-dialog__hint").style.display = "none";
    dialog.querySelector(".lt-dialog__actions").style.display = "none";
    dialog.querySelector(".lt-dialog__error").style.display = "none";

    const historyEl = dialog.querySelector(".lt-dialog__history");
    historyEl.style.display = "block";
    historyEl.innerHTML =
      '<div class="lt-history__loading">Loading history\u2026</div>';

    _historyLangFilter = "";
    _historyData = [];

    const info = _getMsgidAndContext();
    try {
      const data = await api.getHistory(info.msgid, info.context, _editMsgidPlural);
      _historyData = data.history || [];
      _renderHistoryPanel(historyEl);
    } catch {
      historyEl.innerHTML =
        '<div class="lt-history__empty">Failed to load history.</div>';
    }
  }

  /** @type {Object<string, string>} - Human-readable labels for history action types. */
  const _ACTION_LABELS = {
    create: "Created",
    update: "Updated",
    "delete": "Deleted",
    activate: "Activated",
    deactivate: "Deactivated",
  };

  /** @type {Object<string, string>} - Inline SVG markup for each history action type. */
  const _ACTION_ICONS = {
    create: '<svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M8 3v10M3 8h10"/></svg>',
    update: '<svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M2.5 11v2.5H5L13 5.5 10.5 3 2.5 11z"/><path d="M9 4.5l2.5 2.5"/></svg>',
    "delete": '<svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M3 4.5h10"/><path d="M6.5 4.5V3a.5.5 0 01.5-.5h2a.5.5 0 01.5.5v1.5"/><path d="M5 4.5V13a1 1 0 001 1h4a1 1 0 001-1V4.5"/></svg>',
    activate: '<svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="2" y="5" width="12" height="6" rx="3"/><circle cx="11" cy="8" r="2" fill="currentColor"/></svg>',
    deactivate: '<svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="2" y="5" width="12" height="6" rx="3"/><circle cx="5" cy="8" r="2"/></svg>',
  };

  /**
   * Append a middle-dot separator span to a parent element.
   * @param {HTMLElement} parent - Element to append the separator to.
   * @returns {void}
   */
  function _appendSep(parent) {
    const sep = document.createElement("span");
    sep.className = "lt-history__sep";
    sep.textContent = "\u00b7";
    parent.appendChild(sep);
  }

  /**
   * Render the history timeline into the given container.
   *
   * Builds language filter pills (when multiple languages have history),
   * applies the current `_historyLangFilter`, and renders a chronological
   * list of history entries with diff views and restore controls.
   * Re-called when the user changes the language filter.
   *
   * @param {HTMLElement} container - The `.lt-dialog__history` element to populate.
   * @returns {void}
   */
  function _renderHistoryPanel(container) {
    container.innerHTML = "";

    if (!_historyData || _historyData.length === 0) {
      container.innerHTML =
        '<div class="lt-history__empty">No edit history yet.</div>';
      return;
    }

    // ── Language filter pills ──
    const langs = [];
    /** @type {Object<string, boolean>} */
    const langSet = {};
    for (let k = 0; k < _historyData.length; k++) {
      const l = _historyData[k].language;
      if (!langSet[l]) {
        langSet[l] = true;
        langs.push(l);
      }
    }
    langs.sort();

    if (langs.length > 1) {
      const filterBar = document.createElement("div");
      filterBar.className = "lt-history__filters";

      const allPill = document.createElement("button");
      allPill.type = "button";
      allPill.className = "lt-history__filter-pill" + (!_historyLangFilter ? " lt-history__filter-pill--active" : "");
      allPill.textContent = "All";
      allPill.addEventListener("click", function () {
        _historyLangFilter = "";
        _renderHistoryPanel(container);
      });
      filterBar.appendChild(allPill);

      for (let p = 0; p < langs.length; p++) {
        (function (code) {
          const meta = langMeta(code);
          const pill = document.createElement("button");
          pill.type = "button";
          pill.className = "lt-history__filter-pill" + (_historyLangFilter === code ? " lt-history__filter-pill--active" : "");
          pill.textContent = meta ? meta.flag + " " + meta.name : code.toUpperCase();
          pill.addEventListener("click", function () {
            _historyLangFilter = code;
            _renderHistoryPanel(container);
          });
          filterBar.appendChild(pill);
        })(langs[p]);
      }
      container.appendChild(filterBar);
    }

    // ── Filter entries ──
    const filtered = _historyLangFilter
      ? _historyData.filter(function (e) { return e.language === _historyLangFilter; })
      : _historyData;

    if (filtered.length === 0) {
      const emptyMsg = document.createElement("div");
      emptyMsg.className = "lt-history__empty";
      emptyMsg.textContent = "No history for this language.";
      container.appendChild(emptyMsg);
      return;
    }

    // ── Timeline ──
    const timeline = document.createElement("div");
    timeline.className = "lt-history__timeline";

    // Track the newest (current) entry per language to hide its Restore button
    /** @type {Object<string, number>} */
    const newestPerLang = {};
    for (let n = 0; n < filtered.length; n++) {
      if (!newestPerLang[filtered[n].language]) {
        newestPerLang[filtered[n].language] = filtered[n].id;
      }
    }

    for (let i = 0; i < filtered.length; i++) {
      const entry = filtered[i];
      const item = document.createElement("div");
      item.className = "lt-history__entry lt-history__entry--" + entry.action;

      const header = document.createElement("div");
      header.className = "lt-history__entry-header";

      // Action icon (colored container — replaces text label)
      const iconEl = document.createElement("span");
      iconEl.className = "lt-history__icon lt-history__icon--" + entry.action;
      iconEl.innerHTML = _ACTION_ICONS[entry.action] || "";
      iconEl.title = _ACTION_LABELS[entry.action] || entry.action;
      header.appendChild(iconEl);

      // Flag (only when showing all languages)
      let hasFlag = false;
      if (!_historyLangFilter) {
        const entryMeta = langMeta(entry.language);
        if (entryMeta) {
          const flag = document.createElement("span");
          flag.className = "lt-history__flag";
           flag.textContent = entryMeta.flag;
          header.appendChild(flag);
          hasFlag = true;
        }
      }

      // Form index label for plural entries (show when form_index > 0)
      if (entry.form_index > 0) {
        if (hasFlag) _appendSep(header);
        const formTag = document.createElement("span");
        formTag.className = "lt-history__form-tag";
        formTag.textContent = _formLabel(entry.language, entry.form_index);
        header.appendChild(formTag);
        hasFlag = true;
      }

      if (hasFlag) _appendSep(header);

      const time = document.createElement("time");
      time.className = "lt-history__time";
      time.setAttribute("datetime", entry.created_at);
      time.textContent = _formatTime(entry.created_at);
      time.title = new Date(entry.created_at).toLocaleString();
      header.appendChild(time);

      if (entry.user && entry.user !== "System") {
        _appendSep(header);
        const user = document.createElement("span");
        user.className = "lt-history__user";
        user.textContent = entry.user;
        header.appendChild(user);
      }

      item.appendChild(header);

      // ── Content block ──
      const isStateChange = entry.action === "activate" || entry.action === "deactivate";

      if (isStateChange) {
        const statusEl = document.createElement("div");
        statusEl.className = "lt-history__status lt-history__status--" + entry.action;
        const dot = document.createElement("span");
        dot.className = "lt-history__status-dot";
        const statusText = document.createElement("span");
        statusText.textContent = entry.action === "activate"
          ? "Translation enabled"
          : "Translation disabled";
        statusEl.appendChild(dot);
        statusEl.appendChild(statusText);
        item.appendChild(statusEl);
      } else {
        // Build diff view
        let diffView = null;
        if (entry.diff && entry.diff.length > 0) {
          diffView = document.createElement("div");
          diffView.className = "lt-history__diff";
          for (let j = 0; j < entry.diff.length; j++) {
            const seg = entry.diff[j];
            const segSpan = document.createElement("span");
            segSpan.className = "lt-diff lt-diff--" + seg.type;
            segSpan.textContent = seg.text;
            diffView.appendChild(segSpan);
          }
        } else if (entry.action === "create" && entry.new_value) {
          diffView = document.createElement("div");
          diffView.className = "lt-history__diff";
          const cSpan = document.createElement("span");
          cSpan.className = "lt-diff lt-diff--insert";
          cSpan.textContent = entry.new_value;
          diffView.appendChild(cSpan);
        } else if (entry.action === "delete" && entry.old_value) {
          diffView = document.createElement("div");
          diffView.className = "lt-history__diff";
          const dSpan = document.createElement("span");
          dSpan.className = "lt-diff lt-diff--delete";
          dSpan.textContent = entry.old_value;
          diffView.appendChild(dSpan);
        }

        if (diffView) {
          const hasValues = entry.old_value || entry.new_value;
          if (hasValues) {
            // Toggle tabs: Diff / Value
            const tabs = document.createElement("div");
            tabs.className = "lt-history__content-tabs";

            const tDiff = document.createElement("button");
            tDiff.type = "button";
            tDiff.className = "lt-history__content-tab lt-history__content-tab--active";
            tDiff.textContent = "Diff";
            tabs.appendChild(tDiff);

            const tVal = document.createElement("button");
            tVal.type = "button";
            tVal.className = "lt-history__content-tab";
            tVal.textContent = "Value";
            tabs.appendChild(tVal);

            item.appendChild(tabs);
            item.appendChild(diffView);

            // Value view (hidden by default)
            const valView = document.createElement("div");
            valView.className = "lt-history__values";
            valView.style.display = "none";
            _buildValueSections(valView, entry);
            item.appendChild(valView);

            // Toggle handlers (IIFE for closure)
            (function (dt, vt, dv, vv) {
              dt.addEventListener("click", function () {
                dt.classList.add("lt-history__content-tab--active");
                vt.classList.remove("lt-history__content-tab--active");
                dv.style.display = "";
                vv.style.display = "none";
              });
              vt.addEventListener("click", function () {
                vt.classList.add("lt-history__content-tab--active");
                dt.classList.remove("lt-history__content-tab--active");
                vv.style.display = "";
                dv.style.display = "none";
              });
            })(tDiff, tVal, diffView, valView);
          } else {
            item.appendChild(diffView);
          }
        }
      }

      // ── Restore button (text changes only, skip current state per language) ──
      const isCurrent = newestPerLang[entry.language] === entry.id;
      if (!isStateChange && !isCurrent && _isEditable(entry.language)) {
        _appendRestoreControl(header, item, entry);
      }

      timeline.appendChild(item);
    }

    container.appendChild(timeline);
  }

  /**
   * Append a "Restore" button and confirmation panel to a history entry.
   *
   * Clicking "Restore" reveals two options: "Restore & activate" and
   * "Restore as inactive", each of which calls `_executeRestore`.
   * The restore value is `new_value` for create/update actions and
   * `old_value` for delete actions (i.e. the state after the event).
   *
   * @param {HTMLElement}  header - The entry's header row (button is appended here).
   * @param {HTMLElement}  item   - The entry's root element (confirmation panel appended here).
   * @param {HistoryEntry} entry  - The history entry data.
   * @returns {void}
   */
  function _appendRestoreControl(header, item, entry) {
    // Determine the value to restore:
    // CREATE/UPDATE → new_value (the state after this event)
    // DELETE → old_value (restore what was removed)
    const restoreValue = entry.action === "delete" ? entry.old_value : entry.new_value;

    // Restore button sits in the header row, right-aligned (like Revert in edit view).
    // When no lang tag precedes it, it needs margin-left:auto to push right.
    const restoreBtn = document.createElement("button");
    restoreBtn.type = "button";
    restoreBtn.className = "lt-history__restore-btn";
    restoreBtn.style.marginLeft = "auto";
    restoreBtn.textContent = "Restore";
    header.appendChild(restoreBtn);

    // Confirmation panel (hidden initially, appended to the item below header)
    const confirm = document.createElement("div");
    confirm.className = "lt-history__restore-confirm";
    confirm.style.display = "none";

    const confirmActions = document.createElement("div");
    confirmActions.className = "lt-history__restore-actions";

    const activateBtn = document.createElement("button");
    activateBtn.type = "button";
    activateBtn.className = "lt-history__restore-activate";
    activateBtn.textContent = "Restore & activate";

    const inactiveBtn = document.createElement("button");
    inactiveBtn.type = "button";
    inactiveBtn.className = "lt-history__restore-inactive";
    inactiveBtn.textContent = "Restore as inactive";

    const cancelBtn = document.createElement("button");
    cancelBtn.type = "button";
    cancelBtn.className = "lt-history__restore-cancel";
    cancelBtn.textContent = "Cancel";

    confirmActions.appendChild(activateBtn);
    confirmActions.appendChild(inactiveBtn);
    confirmActions.appendChild(cancelBtn);
    confirm.appendChild(confirmActions);

    item.appendChild(confirm);

    restoreBtn.addEventListener("click", function () {
      restoreBtn.style.display = "none";
      confirm.style.display = "block";
    });

    cancelBtn.addEventListener("click", function () {
      confirm.style.display = "none";
      restoreBtn.style.display = "";
    });

    activateBtn.addEventListener("click", function () {
      _executeRestore(entry.language, restoreValue, true, confirm, entry.form_index);
    });

    inactiveBtn.addEventListener("click", function () {
      _executeRestore(entry.language, restoreValue, false, confirm, entry.form_index);
    });
  }

  /**
   * Save a single-language translation restore and reload the page on success.
   * @param {string}      language  - Language code to restore.
   * @param {string}      value     - The msgstr value to restore.
   * @param {boolean}     activate  - Whether the restored value should be active.
   * @param {HTMLElement} confirmEl - The confirmation panel (buttons are disabled during request).
   * @param {number}      [formIndex] - The plural form index (default 0).
   * @returns {Promise<void>}
   */
  async function _executeRestore(language, value, activate, confirmEl, formIndex) {
    // Disable buttons during request
    const buttons = confirmEl.querySelectorAll("button");
    for (let b = 0; b < buttons.length; b++) buttons[b].disabled = true;

    const info = _getMsgidAndContext();
    const fi = formIndex || 0;
    const translations = {};
    const forms = {};
    forms[String(fi)] = value;
    translations[language] = forms;
    const activeFlags = {};
    activeFlags[language] = activate;

    try {
      const data = await api.saveTranslations(info.msgid, info.context, translations, activeFlags, _editMsgidPlural);
      if (data && data.display) {
        if (data.display.reload_required) {
          showToast("Saved. Reload to see changes.", "success");
        } else {
          _updateDomInPlace(info.msgid, info.context, data.display.text, data.display.is_preview_entry);
        }
      }
      closeModal();
    } catch (err) {
      for (let b = 0; b < buttons.length; b++) buttons[b].disabled = false;
      showToast("Restore failed: " + err.message, "error");
    }
  }

  /**
   * Render "Before" / "After" value sections for the history Value tab.
   * @param {HTMLElement}  container - Parent element to append sections into.
   * @param {HistoryEntry} entry     - The history entry with `old_value` and/or `new_value`.
   * @returns {void}
   */
  function _buildValueSections(container, entry) {
    /**
     * @param {string} label - Section heading ("Before" / "After").
     * @param {string} text  - Value to display.
     * @returns {void}
     */
    function addSection(label, text) {
      const sec = document.createElement("div");
      sec.className = "lt-history__value-section";
      const lbl = document.createElement("div");
      lbl.className = "lt-history__value-label";
      lbl.textContent = label;
      const txt = document.createElement("div");
      txt.className = "lt-history__value-text";
      txt.textContent = text;
      sec.appendChild(lbl);
      sec.appendChild(txt);
      container.appendChild(sec);
    }
    if (entry.old_value) addSection("Before", entry.old_value);
    if (entry.new_value) addSection("After", entry.new_value);
  }

  /**
   * Format an ISO 8601 timestamp as a human-friendly relative time string
   * (e.g. "just now", "5m ago", "3d ago") or a locale date for older entries.
   * @param {string} isoString - ISO 8601 date string from the API.
   * @returns {string}
   */
  function _formatTime(isoString) {
    const date = new Date(isoString);
    const now = new Date();
    const diffMs = now - date;
    const diffSec = Math.floor(diffMs / 1000);
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffSec < 10) return "just now";
    if (diffSec < 60) return diffSec + "s ago";
    if (diffMins < 60) return diffMins + "m ago";
    if (diffHours < 24) return diffHours + "h ago";
    if (diffDays < 7) return diffDays + "d ago";
    if (diffDays < 30) return Math.floor(diffDays / 7) + "w ago";
    return date.toLocaleDateString();
  }

  /**
   * Close the dialog and reset editing state back to "active" mode.
   * @returns {void}
   */
  function closeModal() {
    if (dialog && dialog.open) {
      dialog.close();
    }
    currentSpan = null;
    currentAttrName = null;
    historyOpen = false;
    _editData = null;
    _editLang = "";
    _editedValues = {};
    _editedActiveFlags = {};
    _originalValues = {};
    _originalActiveFlags = {};
    _deletionsMarked = {};
    _htmlWarningAcked = false;
    _editMsgidPlural = "";
    if (dialog) {
      const delBtn = dialog.querySelector(".lt-btn--delete-override");
      if (delBtn) {
        delBtn.style.display = "none";
        delBtn.classList.remove("lt-btn--delete-override--checked");
      }
    }
    if (state === "editing") {
      state = "active";
    }
  }

  // ─── Preview Mode: Multi-select & Action Bar ────────

  /** @type {HTMLElement[]} */
  let selectedElements = [];
  /** @type {HTMLElement|null} */
  let actionBar = null;
  /** @type {boolean} */
  let actionBarConfirming = false;

  /**
   * Toggle an element's selection state for bulk activation.
   * @param {HTMLElement} el - The element to toggle.
   * @returns {void}
   */
  function _toggleSelected(el) {
    const idx = selectedElements.indexOf(el);
    if (idx !== -1) {
      selectedElements.splice(idx, 1);
      el.classList.remove("lt-selected");
    } else {
      selectedElements.push(el);
      el.classList.add("lt-selected");
    }
    _updateActionBar();
  }

  /**
   * Clear all selected elements.
   * @returns {void}
   */
  function _clearSelection() {
    for (let i = 0; i < selectedElements.length; i++) {
      selectedElements[i].classList.remove("lt-selected");
    }
    selectedElements = [];
    _updateActionBar();
  }

  /**
   * Create the floating action bar element (called once on preview init).
   * @returns {void}
   */
  function _createActionBar() {
    if (actionBar) return;
    actionBar = document.createElement("div");
    actionBar.className = "lt-action-bar";
    document.body.appendChild(actionBar);
    _renderActionBarDefault();
  }

  /**
   * Render the action bar in its default state (count + activate + clear).
   * @returns {void}
   */
  function _renderActionBarDefault() {
    if (!actionBar) return;
    actionBarConfirming = false;
    const count = selectedElements.length;
    actionBar.innerHTML =
      '<span class="lt-action-bar__count">' + count + " selected</span>" +
      '<button type="button" class="lt-action-bar__activate">Activate</button>' +
      '<button type="button" class="lt-action-bar__clear">Clear</button>';
    actionBar.querySelector(".lt-action-bar__activate").addEventListener("click", _showActivateConfirm);
    actionBar.querySelector(".lt-action-bar__clear").addEventListener("click", _clearSelection);
  }

  /**
   * Show/hide the action bar based on selection count.
   * @returns {void}
   */
  function _updateActionBar() {
    if (!actionBar) return;
    const count = selectedElements.length;
    if (count === 0) {
      actionBar.classList.remove("lt-action-bar--visible");
      actionBarConfirming = false;
      _renderActionBarDefault();
      return;
    }
    actionBar.classList.add("lt-action-bar--visible");
    if (!actionBarConfirming) {
      _renderActionBarDefault();
    }
  }

  /**
   * Switch the action bar to confirmation state with a warning.
   * @returns {void}
   */
  function _showActivateConfirm() {
    actionBarConfirming = true;
    const count = selectedElements.length;
    const lang = _pageLang() || "unknown";
    actionBar.innerHTML =
      '<span class="lt-action-bar__warning">' +
      "This will activate " + count + " translation(s) for language \"" + lang + "\". Continue?" +
      "</span>" +
      '<button type="button" class="lt-action-bar__confirm">Confirm</button>' +
      '<button type="button" class="lt-action-bar__cancel">Cancel</button>';
    actionBar.querySelector(".lt-action-bar__confirm").addEventListener("click", _executeBulkActivate);
    actionBar.querySelector(".lt-action-bar__cancel").addEventListener("click", function () {
      _renderActionBarDefault();
    });
  }

  /**
   * Collect selected msgid/context pairs and POST to the bulk-activate endpoint.
   * @returns {Promise<void>}
   */
  async function _executeBulkActivate() {
    const confirmBtn = actionBar.querySelector(".lt-action-bar__confirm");
    if (confirmBtn) confirmBtn.disabled = true;

    const msgids = [];
    /** @type {Object<string, boolean>} */
    const seen = {};

    for (let i = 0; i < selectedElements.length; i++) {
      const el = selectedElements[i];

      if (el.dataset.ltMsgid) {
        // Inline text span
        const msgid = el.dataset.ltMsgid;
        const context = el.dataset.ltContext || "";
        const key = _entryKey(msgid, context);
        if (!seen[key]) {
          seen[key] = true;
          msgids.push({ msgid: msgid, context: context });
        }
      } else if (el.dataset.ltAttrs) {
        // Attribute element — collect all preview entries
        const attrs = _parseLtAttrs(el);
        for (let j = 0; j < attrs.length; j++) {
          const aKey = _entryKey(attrs[j].m, attrs[j].c);
          if (!seen[aKey]) {
            seen[aKey] = true;
            msgids.push({ msgid: attrs[j].m, context: attrs[j].c || "" });
          }
        }
      }
    }

    if (msgids.length === 0) {
      showToast("No translations to activate", "error");
      _renderActionBarDefault();
      return;
    }

    const lang = _pageLang();

    try {
      const data = await api.bulkActivate(msgids, lang);
      showToast(data.activated + " translation(s) activated", "success");
      // Delay reload so the user (and tests) can see the success toast.
      setTimeout(_reloadPage, 1500);
    } catch (err) {
      showToast("Bulk activate failed: " + err.message, "error");
      if (confirmBtn) confirmBtn.disabled = false;
    }
  }

  /**
   * Initialize preview mode: mark elements with inactive overrides and create the action bar.
   * Called once on DOMContentLoaded when PREVIEW is true.
   * @returns {void}
   */
  function _initPreviewMode() {
    // Build lookup from config
    /** @type {Object<string, boolean>} */
    const lookup = {};
    for (let i = 0; i < PREVIEW_ENTRIES.length; i++) {
      const pe = PREVIEW_ENTRIES[i];
      lookup[_entryKey(pe.m, pe.c)] = true;
    }

    // Mark inline text elements (lt-t elements created by resolveMarkers)
    const spans = document.querySelectorAll("lt-t");
    for (let s = 0; s < spans.length; s++) {
      const sp = spans[s];
      const spKey = _entryKey(sp.dataset.ltMsgid || "", sp.dataset.ltContext || "");
      if (lookup[spKey]) {
        sp.classList.add("lt-preview");
      }
    }

    // Mark attribute-translatable elements
    const attrEls = document.querySelectorAll(SEL_ATTR_TRANSLATIONS);
    for (let a = 0; a < attrEls.length; a++) {
      const attrs = _parseLtAttrs(/** @type {HTMLElement} */ (attrEls[a]));
      for (let j = 0; j < attrs.length; j++) {
        const aKey = _entryKey(attrs[j].m || "", attrs[j].c || "");
        if (lookup[aKey]) {
          attrEls[a].classList.add("lt-preview");
          break;
        }
      }
    }

    _createActionBar();
  }

  // ─── Edit Mode Toggle ───────────────────────────────

  /**
   * Enter translation edit mode: add the body class that highlights translatable
   * elements.
   * @returns {void}
   */
  function activateEditMode() {
    state = "active";
    document.body.classList.add("lt-edit-mode");
    _updateHintActiveState();
  }

  /**
   * Leave translation edit mode: close any open modal, remove the body class.
   * @returns {void}
   */
  function deactivateEditMode() {
    closeModal();
    _clearSelection();
    state = "inactive";
    document.body.classList.remove("lt-edit-mode");
    _updateHintActiveState();
  }

  /**
   * Toggle between active and inactive edit mode.
   * @returns {void}
   */
  function _toggleEditMode() {
    if (state === "inactive") {
      activateEditMode();
    } else {
      deactivateEditMode();
    }
  }

  /**
   * Toggle preview mode: flip the preview cookie and reload.
   * @returns {void}
   */
  function _togglePreview() {
    if (document.cookie.indexOf("lt_preview=1") !== -1) {
      document.cookie = "lt_preview=; path=/; max-age=0";
    } else {
      document.cookie = "lt_preview=1; path=/; max-age=86400; SameSite=Lax";
    }
    window.location.reload();
  }

  // ─── Keyboard Handler ───────────────────────────────

  document.addEventListener("keydown", function (e) {
    const tag = document.activeElement ? document.activeElement.tagName : "";
    const inInput = tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT";

    if (_matchShortcut(e, SC_EDIT)) {
      if (inInput) return;
      e.preventDefault();
      _toggleEditMode();
    }

    if (_matchShortcut(e, SC_PREVIEW)) {
      if (inInput) return;
      e.preventDefault();
      _togglePreview();
    }
  });

  // ─── Click Handler (delegated) ──────────────────────

  document.addEventListener(
    "click",
    function (e) {
      if (state !== "active") return;

      // Check for inline text element first
      const span = e.target.closest("lt-t");
      if (span) {
        e.preventDefault();
        e.stopPropagation();

        // Shift+click in preview mode: if the lt-t lives inside an
        // attribute-translatable element that has a preview marker, select
        // the *parent* attribute element (not the inner text span).
        if (e.shiftKey && PREVIEW) {
          const parentAttr = span.closest(SEL_ATTR_TRANSLATIONS);
          if (parentAttr && parentAttr.classList.contains("lt-preview")) {
            _toggleSelected(parentAttr);
            window.getSelection().removeAllRanges();
            return;
          }
          if (span.classList.contains("lt-preview")) {
            _toggleSelected(span);
            window.getSelection().removeAllRanges();
            return;
          }
        }

        openModal(span);
        return;
      }

      // Check for attribute-translatable element
      const attrEl = e.target.closest(SEL_ATTR_TRANSLATIONS);
      if (attrEl) {
        e.preventDefault();
        e.stopPropagation();

        // Shift+click on preview elements toggles selection
        if (e.shiftKey && PREVIEW && attrEl.classList.contains("lt-preview")) {
          _toggleSelected(attrEl);
          window.getSelection().removeAllRanges();
          return;
        }

        const attrs = _parseLtAttrs(attrEl);
        if (!attrs.length) return;

        openModal(attrEl, attrs[0]);
      }
    },
    true
  ); // Use capture phase to intercept before other handlers

  // ─── ZWC Marker Resolution + Edit Mode Restore ───────

  document.addEventListener("DOMContentLoaded", function () {
    // Process string table from <template> and resolve ZWC markers
    rescanMarkers();

    // Restore edit mode after reload (if persisted in sessionStorage)
    try {
      if (sessionStorage.getItem(_EDIT_MODE_KEY)) {
        sessionStorage.removeItem(_EDIT_MODE_KEY);
        if (state === "inactive") {
          activateEditMode();
        }
      }
    } catch (e) { /* private browsing / quota */ }

    // Preview mode auto-activation
    if (PREVIEW) {
      if (state === "inactive") {
        activateEditMode();
      }
      _initPreviewMode();
    }
  });

  // ─── Dynamic Content Event Listeners ─────────────────
  // Re-scan markers when htmx (or similar libraries) swap in new content.
  // We use htmx:load (not htmx:afterSettle) because outerHTML swaps detach the
  // trigger element from the DOM, preventing afterSettle from bubbling.
  // htmx:load fires on the NEW elements after insertion, so it always bubbles.
  // Note: htmx also fires htmx:load on initial init with document.body as elt,
  // causing a redundant rescanMarkers call (DOMContentLoaded already ran it).
  // This is harmless since rescanMarkers is idempotent — not worth guarding.
  // If htmx is not loaded, this event never fires — zero overhead.
  document.body.addEventListener("htmx:load", /** @param {CustomEvent<{elt: Element}>} e */ function (e) {
    rescanMarkers(e.detail && e.detail.elt);
  });

  // Public API: call window.__LT_RESCAN__() after inserting dynamic content
  // that contains translated strings (e.g. via fetch + innerHTML).
  window.__LT_RESCAN__ = rescanMarkers;

  // ─── Shortcut Hint (sticky bar) ──────────────────────

  /** @type {string} */
  const _HINT_POS_KEY = "lt_hint_pos";
  /** @type {HTMLElement|null} */
  let _hintBar = null;
  /** @type {boolean} - True while a drag gesture is in progress (past threshold). */
  let _hintDidDrag = false;

  /**
   * Show a persistent shortcut hint bar at the bottom of the viewport.
   * The entire bar is draggable. Edit/Preview are clickable toggle buttons.
   * Position is remembered in localStorage.
   * @returns {void}
   */
  function _showShortcutHint() {
    const bar = document.createElement("div");
    bar.className = "lt-hint";

    // Brand label
    const brand = document.createElement("span");
    brand.className = "lt-hint__brand";
    brand.textContent = "Live Translations";
    bar.appendChild(brand);

    // Separator after brand
    const sep0 = document.createElement("span");
    sep0.className = "lt-hint__sep";
    bar.appendChild(sep0);

    // Language switcher (only shown when multiple languages configured)
    if (LANGUAGES.length > 1) {
      const langSwitcher = document.createElement("div");
      langSwitcher.className = "lt-hint__lang";

      const langTrigger = document.createElement("button");
      langTrigger.type = "button";
      langTrigger.className = "lt-hint__lang-trigger";
      const currentMeta = langMeta(_pageLang());
      langTrigger.textContent = currentMeta
        ? currentMeta.flag + " " + _pageLang().toUpperCase()
        : _pageLang().toUpperCase();
      langTrigger.title = "Switch language";

      const langMenu = document.createElement("div");
      langMenu.className = "lt-hint__lang-menu";

      for (let li = 0; li < LANGUAGES.length; li++) {
        (function (lang) {
          const item = document.createElement("button");
          item.type = "button";
          item.className = "lt-hint__lang-item";
          if (lang === _pageLang()) {
            item.classList.add("lt-hint__lang-item--active");
          }

          const isDraft = DRAFT_LANGUAGES.indexOf(lang) !== -1;
          item.textContent = langLabel(lang);

          if (isDraft) {
            const badge = document.createElement("span");
            badge.className = "lt-hint__lang-badge";
            badge.textContent = "Draft";
            item.appendChild(badge);
          }

          item.addEventListener("click", function (e) {
            e.stopPropagation();
            if (_hintDidDrag) return;
            if (lang === _pageLang()) {
              langMenu.classList.remove("lt-hint__lang-menu--open");
              return;
            }
            _switchPageLanguage(lang, isDraft);
          });
          langMenu.appendChild(item);
        })(LANGUAGES[li]);
      }

      langTrigger.addEventListener("click", function (e) {
        if (_hintDidDrag) return;
        e.stopPropagation();
        langMenu.classList.toggle("lt-hint__lang-menu--open");
      });

      // Close menu when clicking outside
      document.addEventListener("click", function () {
        langMenu.classList.remove("lt-hint__lang-menu--open");
      });

      langSwitcher.appendChild(langTrigger);
      langSwitcher.appendChild(langMenu);
      bar.appendChild(langSwitcher);

      const sep1 = document.createElement("span");
      sep1.className = "lt-hint__sep";
      bar.appendChild(sep1);
    }

    // Edit mode button
    const editBtn = document.createElement("button");
    editBtn.type = "button";
    editBtn.className = "lt-hint__action";
    editBtn.dataset.mode = "edit";
    editBtn.title = "Toggle inline translation editor";
    editBtn.innerHTML =
      '<kbd class="lt-hint__kbd">' + _formatShortcut(SC_EDIT) + "</kbd>" +
      '<span class="lt-hint__label">Edit</span>';
    editBtn.addEventListener("click", function () {
      if (_hintDidDrag) return;
      _toggleEditMode();
    });
    bar.appendChild(editBtn);

    // Preview mode button
    const previewBtn = document.createElement("button");
    previewBtn.type = "button";
    previewBtn.className = "lt-hint__action";
    previewBtn.dataset.mode = "preview";
    previewBtn.title = "Preview translations from the database";
    previewBtn.innerHTML =
      '<kbd class="lt-hint__kbd">' + _formatShortcut(SC_PREVIEW) + "</kbd>" +
      '<span class="lt-hint__label">Preview</span>';
    previewBtn.addEventListener("click", function () {
      if (_hintDidDrag) return;
      _togglePreview();
    });
    bar.appendChild(previewBtn);

    // Preview tip (visible only in preview mode)
    const tip = document.createElement("span");
    tip.className = "lt-hint__tip";
    tip.title = "Hold Shift and click translated text to select multiple entries";
    tip.innerHTML = '<kbd class="lt-hint__kbd">Shift</kbd><span class="lt-hint__label">click to select</span>';
    bar.appendChild(tip);

    document.body.appendChild(bar);
    _hintBar = bar;

    // Restore saved position or use default centered bottom
    /** @type {HintPosition|null} */
    let savedPos = null;
    try {
      const raw = localStorage.getItem(_HINT_POS_KEY);
      if (raw) savedPos = JSON.parse(raw);
    } catch (e) { /* ignore */ }

    if (savedPos && typeof savedPos.x === "number" && typeof savedPos.y === "number") {
      const x = Math.max(0, Math.min(window.innerWidth - bar.offsetWidth, savedPos.x));
      const y = Math.max(0, Math.min(window.innerHeight - bar.offsetHeight, savedPos.y));
      bar.style.left = x + "px";
      bar.style.top = y + "px";
      bar.classList.add("lt-hint--positioned");
    }

    _updateHintActiveState();
    _initHintDrag(bar);

    void bar.offsetHeight;
    bar.classList.add("lt-hint--visible");
  }

  /** @type {number} - Pixel threshold to distinguish click from drag. */
  const _DRAG_THRESHOLD = 3;

  /**
   * Make the entire hint bar draggable.
   * Uses a movement threshold to distinguish clicks from drags — button
   * click handlers check `_hintDidDrag` and bail if a drag just occurred.
   * @param {HTMLElement} bar - The hint bar element.
   * @returns {void}
   */
  function _initHintDrag(bar) {
    /** @type {DragState|null} */
    let dragState = null;

    bar.addEventListener("mousedown", function (e) {
      if (e.button !== 0) return;
      // Don't prevent default — let clicks reach buttons if no drag happens

      const rect = bar.getBoundingClientRect();
      dragState = {
        mouseX: e.clientX,
        mouseY: e.clientY,
        barX: rect.left,
        barY: rect.top,
        moved: false,
      };
      _hintDidDrag = false;
    });

    document.addEventListener("mousemove", function (e) {
      if (!dragState) return;

      const dx = e.clientX - dragState.mouseX;
      const dy = e.clientY - dragState.mouseY;

      // Only start dragging after passing the threshold
      if (!dragState.moved) {
        if (Math.abs(dx) < _DRAG_THRESHOLD && Math.abs(dy) < _DRAG_THRESHOLD) return;
        dragState.moved = true;
        _hintDidDrag = true;

        // Switch from center-anchored to explicit positioning on first drag
        if (!bar.classList.contains("lt-hint--positioned")) {
          bar.style.left = dragState.barX + "px";
          bar.style.top = dragState.barY + "px";
          bar.classList.add("lt-hint--positioned");
        }

        bar.classList.add("lt-hint--dragging");
      }

      const newX = dragState.barX + dx;
      const newY = dragState.barY + dy;
      const maxX = window.innerWidth - bar.offsetWidth;
      const maxY = window.innerHeight - bar.offsetHeight;
      bar.style.left = Math.max(0, Math.min(maxX, newX)) + "px";
      bar.style.top = Math.max(0, Math.min(maxY, newY)) + "px";
    });

    document.addEventListener("mouseup", function () {
      if (!dragState) return;
      const wasDrag = dragState.moved;
      dragState = null;
      bar.classList.remove("lt-hint--dragging");

      if (wasDrag) {
        // Persist position
        try {
          localStorage.setItem(_HINT_POS_KEY, JSON.stringify({
            x: parseInt(bar.style.left, 10),
            y: parseInt(bar.style.top, 10),
          }));
        } catch (e) { /* ignore */ }

        // Reset drag flag after a tick so the click event (which fires after
        // mouseup) still sees _hintDidDrag=true and is suppressed
        setTimeout(function () { _hintDidDrag = false; }, 0);
      }
    });
  }

  /**
   * Update the hint bar to highlight the currently active mode.
   * @returns {void}
   */
  function _updateHintActiveState() {
    if (!_hintBar) return;
    const editEl = _hintBar.querySelector('[data-mode="edit"]');
    const previewEl = _hintBar.querySelector('[data-mode="preview"]');
    const tipEl = _hintBar.querySelector(".lt-hint__tip");
    if (editEl) editEl.classList.toggle("lt-hint__action--active", state === "active" || state === "editing");
    if (previewEl) previewEl.classList.toggle("lt-hint__action--active", PREVIEW);
    if (tipEl) tipEl.classList.toggle("lt-hint__tip--visible", PREVIEW);
  }

  _showShortcutHint();
})();
