---
title: Django Admin
description: Managing translation overrides from the Django admin panel
---

# Django Admin

django-live-translations registers two models in Django's admin: `TranslationEntry` for managing overrides and `TranslationHistory` as a read-only audit log.

!!! note
    The admin interface is most useful with the [database backend](backends.md#database-backend){ data-preview }. With the PO backend, overrides live in `.po` files and these tables remain empty.

## Translation entries

The list view shows all overrides with columns for message ID, language, translation, context, active status, and last updated timestamp.

**Filters**: language, context, active status, modified by (user)

**Search**: across msgid and context fields

### Detail view

The edit form has two fieldsets:

- **Translation**: PO file default (read-only, showing all plural forms for plural entries), the override forms (`msgstr_forms` JSON field), and active toggle
- **Identification**: language, message ID, context, and plural message ID (`msgid_plural`)

The PO default lets you compare your override against the baseline `.po` file value.

### Bulk actions

Four actions are available on selected entries:

- **Activate selected translations**: sets `is_active = True` and triggers cache invalidation
- **Deactivate selected translations**: sets `is_active = False` and triggers cache invalidation
- **Export selected as CSV**: downloads a CSV file with the selected entries
- **Export selected as PO (zip)**: downloads a zip archive of PO files for the selected entries

### Import & Export

The change list toolbar includes **Export** and **Import** buttons for bulk operations with CSV and PO files. See [Import & Export](import-export.md) for details.

## Translation history

A read-only audit log of all changes. Shows timestamp, action type, language, message ID, context, plural message ID, form index, and user. The `form_index` field indicates which plural form was changed (0 for singular or the first plural form).

No entries can be added, edited, or deleted through the admin. The history is append-only.

## django-unfold support

If [django-unfold](https://github.com/unfoldadmin/django-unfold) is installed, the admin automatically uses its `ModelAdmin` base class for a modern UI. No configuration needed.
