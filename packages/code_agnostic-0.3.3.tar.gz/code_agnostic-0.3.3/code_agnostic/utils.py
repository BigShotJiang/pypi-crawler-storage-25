import json
from pathlib import Path
from typing import Any


def read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def read_json_safe(path: Path) -> tuple[Any | None, str | None]:
    if not path.exists():
        return None, None
    if path.stat().st_size == 0:
        return None, None
    try:
        return read_json(path), None
    except Exception as exc:
        return None, str(exc)


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, sort_keys=False)
        handle.write("\n")


def is_under(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except Exception:
        return False


def compact_home_path(path: str | Path) -> str:
    text = str(path).replace("\\", "/")
    home = str(Path.home()).replace("\\", "/")
    if text == home:
        return "~"
    home_prefix = f"{home}/"
    if text.startswith(home_prefix):
        return f"~/{text[len(home_prefix) :]}"
    return text


def compact_home_paths_in_text(text: str) -> str:
    home = str(Path.home()).replace("\\", "/")
    normalized = text.replace("\\", "/")
    if normalized == home:
        return "~"
    return normalized.replace(f"{home}/", "~/")
