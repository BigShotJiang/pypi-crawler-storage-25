![PyPI Downloads](https://img.shields.io/badge/downloads-50k-blue)  
![PyPI](https://img.shields.io/pypi/v/cosmotalker.svg)  
[![Socket Badge](https://socket.dev/api/badge/pypi/package/cosmotalker/1.5.1?artifact_id=tar-gz)](https://socket.dev/pypi/package/cosmotalker/overview)  
[![License](https://img.shields.io/badge/license-MIT-blue.svg)](https://github.com/bhuvanesh-m-dev/cosmotalker/blob/main/document/LICENSE)  
[![Last Commit](https://img.shields.io/github/last-commit/bhuvanesh-m-dev/cosmotalker)](https://github.com/bhuvanesh-m-dev/cosmotalker)  
[![Issues](https://img.shields.io/github/issues/bhuvanesh-m-dev/cosmotalker)](https://github.com/bhuvanesh-m-dev/cosmotalker/issues)  
[![Stars](https://img.shields.io/github/stars/bhuvanesh-m-dev/cosmotalker)](https://github.com/bhuvanesh-m-dev/cosmotalker/stargazers)  
[![Made with Python](https://img.shields.io/badge/Made%20with-Python-blue?logo=python)](https://www.python.org/)  
[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Fira+Code&duration=6000&pause=1000&color=DCBDF7&multiline=true&width=460&height=150&lines=Offline+heart%2C+cosmic+art%E2%80%94;Planets+whisper%2C+searches+spark.;Images+bloom%2C+green+quests+ignite%2C;No+net%2C+just+stars+in+terminal+light.;For+coders%2C+dreamers%2C+minds+that+soar%E2%80%94;The+universe%2C+now+at+your+core.)](https://git.io/typing-svg)  

# ✨ Welcome to CosmoTalker v2.6 – Now Optimized for the Browser!

**CosmoTalker 2.6** is officially here!  
Explore the **Solar System** and beyond with this **offline-first Python library**, now with a **dedicated Browser Edition** optimized for **GalacticCode**.

> 🌐 **Try it instantly in your browser** — no installation required!  
> **[🚀 Launch GalacticCode](https://bhuvanesh-m-dev.github.io/galacticcode)**

---

## 🌟 CosmoTalker 2.6 — Browser Edition (Optimized for GalacticCode)

**Release Date**: April 2026  
**Version**: 2.6 (Special Browser Release)

**CosmoTalker 2.6** is a **dedicated edition** specially built and optimized for **GalacticCode** — the free, in-browser Python platform.

This version ensures the **best possible experience** when running CosmoTalker directly in the browser using Pyodide (WebAssembly). It focuses on reliability, fast loading, and educational use while maintaining the core spirit of making space exploration accessible to everyone.

### Major Changes in CosmoTalker 2.6 (Compared to Previous Full Versions ≤ 2.45)

| Feature                          | Previous Versions (≤ 2.45)                  | CosmoTalker 2.6 (for GalacticCode)                          | Status / Reason |
|----------------------------------|---------------------------------------------|--------------------------------------------------------------|-----------------|
| Core Astronomy Functions         | `planet_info`, `get_fun_fact`, `search`, `wiki`, `apod`, `celestrak`, `spacex`, etc. | Fully supported and unchanged                               | ✅ Stable |
| Oolit (Offline AI Chatbot)       | Supported                                   | Supported                                                   | ✅ Stable |
| **img()** – Beta Image Preview   | Available (uses CustomTkinter GUI)          | **Disabled** – Replaced with safe dummy function            | Browser limitation (no GUI support in Pyodide) |
| Image Preview & Saving           | Works on desktop                            | Shows clear warning message only                            | Not possible in browser |
| tkinter / customtkinter          | Used internally by img module               | Fully mocked with dummy modules                             | Required for compatibility |
| Package Installation             | Standard `pip install cosmotalker`          | Automatically pre-installed via micropip in GalacticCode    | Seamless browser experience |
| Performance                      | Native speed                                | Runs in WebAssembly (slightly slower for heavy tasks)       | Acceptable for learning & exploration |
| Offline Data                     | Strong                                      | Strong for core data                                        | Maintained |
| New in 2.6                       | —                                           | Better error handling for browser environment<br>Improved welcome messages<br>Optimized import path for web | Specific to GalacticCode |

> **Important for GalacticCode users**  
> CosmoTalker 2.6 is the **recommended version** for the GalacticCode platform.  
> All text-based and data functions work normally.  
> The **image preview feature** (`ct.img(...)` or `cosmotalker.img`) is **not supported** in this version because browsers do not support GUI libraries like CustomTkinter.  
> A friendly warning message will be shown if you try to use it.

---

## 🎥 See CosmoTalker in Motion
*(Your existing video section remains unchanged)*

---

## 🏆 Recognition & Awards
*(Your existing award section remains unchanged)*

---

## 🚀 What's New in v2.6?
- **Dedicated Browser Edition** for GalacticCode
- Optimized import and error handling for Pyodide/WebAssembly
- Safe dummy implementation for `img()` with clear browser warning
- Improved welcome messages and user guidance
- Pre-installed automatically in GalacticCode

*(All previous v2 features — improved Solar System module, enhanced search, beta image function (desktop only), wiki tool, etc. — are preserved.)*

---

## 🔧 Features
*(Your existing features section remains unchanged)*

---

## 🛆 Installation

### For Desktop / Local Use
```bash
pip install cosmotalker
✅ Compatible with Python 3.6+
🌐 Try in Browser (Recommended for Learning)
No installation needed!
🚀 Open GalacticCode → CosmoTalker 2.6 Ready
CosmoTalker 2.6 is automatically pre-loaded when you visit GalacticCode.

🧪 Usage Example
(Your existing example code block remains unchanged)

🌐 Project Links

Try in Browser: https://bhuvanesh-m-dev.github.io/galacticcode
Explore More: bhuvaneshm.in/cosmotalker
Star the Repo: github.com/bhuvanesh-m-dev/cosmotalker


👨‍💻 Developed By
Bhuvanesh M
🚀 CSE Student | 🎐 Astronomy Enthusiast | 🐧 Linux Dev | 🐍 Python Coder
(Your existing contact links remain unchanged)

The universe speaks — CosmoTalker listens. 💫
