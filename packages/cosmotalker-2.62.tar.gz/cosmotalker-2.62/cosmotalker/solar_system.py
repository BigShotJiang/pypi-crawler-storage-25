import os
import webbrowser
from pathlib import Path

def open_solar_system(celestial_body=None):
    """
    Open solar system HTML files in the default web browser.
    
    Args:
        celestial_body (str, optional): The celestial body to open. 
                                      If None, opens the main solar system page.
                                      Options: 'sun', 'mercury', 'venus', 'earth', 
                                      'mars', 'jupiter', 'saturn', 'uranus', 
                                      'neptune', 'asteroid-belt', 'kuiper-belt', 
                                      'oort-cloud'
    
    Returns:
        bool: True if file was found and opened, False otherwise
    """
    # Get the directory where this package is installed
    package_dir = Path(__file__).parent
    templates_dir = package_dir / 'templates'
    
    # Define valid celestial bodies
    valid_bodies = [
        None,  # Main index
        'sun', 'mercury', 'venus', 'earth', 'mars',
        'jupiter', 'saturn', 'uranus', 'neptune',
        'asteroid-belt', 'kuiper-belt', 'oort-cloud'
    ]
    
    if celestial_body not in valid_bodies:
        print(f"Error: '{celestial_body}' is not a valid celestial body.")
        print(f"Valid options: {[body for body in valid_bodies if body is not None]}")
        return False
    
    # Determine which HTML file to open
    if celestial_body is None:
        html_file = templates_dir / 'index.html'
    else:
        html_file = templates_dir / celestial_body / 'index.html'
    
    # Check if file exists
    if not html_file.exists():
        print(f"Error: HTML file not found: {html_file}")
        print(f"Please make sure the template files are installed correctly.")
        return False
    
    # Open in web browser
    try:
        webbrowser.open(f'file://{html_file.absolute()}')
        print(f"Opening: {celestial_body or 'Solar System Main Page'}")
        return True
    except Exception as e:
        print(f"Error opening file: {e}")
        return False

# Alternative function name for convenience
def solar_system(body=None):
    """Alias for open_solar_system function"""
    return open_solar_system(body)
