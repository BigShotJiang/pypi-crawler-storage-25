"""
Tests for gump.sentinel — Spectral security monitoring
"""
import sys, os, time, unittest
import numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from gump.sentinel import Sentinel


class TestBasics(unittest.TestCase):

    def test_create(self):
        s = Sentinel('test')
        self.assertEqual(s.name, 'test')
        self.assertFalse(s.is_baselined)

    def test_feed_metrics(self):
        s = Sentinel()
        s.feed_metrics({'cpu': 25.0, 'memory': 60.0})
        self.assertIn('cpu', s.sensors)
        self.assertIn('memory', s.sensors)

    def test_manual_baseline(self):
        s = Sentinel()
        s.set_baseline({
            'cpu': {'mean': 25, 'std': 5, 'min': 10, 'max': 50, 'samples': 60},
            'memory': {'mean': 60, 'std': 3, 'min': 55, 'max': 68, 'samples': 60},
        })
        self.assertTrue(s.is_baselined)


class TestAnomalyDetection(unittest.TestCase):

    def test_detects_cpu_spike(self):
        """Normal CPU ~25%, then spike to 95%. Must alert."""
        s = Sentinel()
        s.set_baseline({'cpu': {'mean': 25, 'std': 5, 'min': 10, 'max': 40, 'samples': 60}})
        # Feed normal data first
        for _ in range(10):
            s.feed_metrics({'cpu': 25 + np.random.randn() * 3})
        # Spike
        alerts = s.check({'cpu': 95.0})
        high_alerts = [a for a in alerts if a['severity'] in ('HIGH', 'CRITICAL')]
        self.assertGreater(len(high_alerts), 0,
            "Missed CPU spike from 25% to 95%")

    def test_detects_process_explosion(self):
        """Normal ~300 processes, suddenly 1500. Must alert."""
        s = Sentinel()
        s.set_baseline({'processes': {'mean': 300, 'std': 20, 'min': 270, 'max': 340, 'samples': 60}})
        for _ in range(10):
            s.feed_metrics({'processes': 300 + np.random.randn() * 10})
        alerts = s.check({'processes': 1500})
        self.assertGreater(len(alerts), 0,
            "Missed process explosion from 300 to 1500")

    def test_detects_connection_surge(self):
        """Normal ~20 connections, suddenly 500. Port scan or attack."""
        s = Sentinel()
        s.set_baseline({'connections': {'mean': 20, 'std': 5, 'min': 10, 'max': 35, 'samples': 60}})
        for _ in range(10):
            s.feed_metrics({'connections': 20 + np.random.randn() * 3})
        alerts = s.check({'connections': 500})
        self.assertGreater(len(alerts), 0,
            "Missed connection surge — potential port scan or DDoS")

    def test_no_false_alarm_normal(self):
        """Normal fluctuation should not trigger alerts."""
        s = Sentinel()
        s.set_baseline({'cpu': {'mean': 25, 'std': 5, 'min': 10, 'max': 40, 'samples': 60}})
        for _ in range(20):
            s.feed_metrics({'cpu': 25 + np.random.randn() * 3})
        alerts = s.check({'cpu': 28.0})  # within normal range
        high_alerts = [a for a in alerts if a['severity'] in ('HIGH', 'CRITICAL')]
        self.assertEqual(len(high_alerts), 0,
            "False alarm on normal CPU fluctuation")

    def test_detects_memory_leak(self):
        """Memory slowly climbing = leak. K should drop as pattern changes."""
        s = Sentinel()
        s.set_baseline({'memory': {'mean': 60, 'std': 2, 'min': 57, 'max': 64, 'samples': 60}})
        # Feed slowly climbing memory
        for i in range(20):
            s.feed_metrics({'memory': 60 + i * 2})
        # By now memory is at 98% — way above baseline
        alerts = s.check({'memory': 98})
        self.assertGreater(len(alerts), 0,
            "Missed memory leak — slow climb from 60% to 98%")


class TestFileIntegrity(unittest.TestCase):

    def test_detects_modified_file(self):
        """Create a file, watch it, modify it, detect change."""
        import tempfile
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
            f.write('original content')
            path = f.name

        s = Sentinel()
        s.watch_files([path])

        # Modify
        with open(path, 'w') as f:
            f.write('HACKED content')

        changes = s.check_integrity()
        os.unlink(path)

        modified = [c for c in changes if c['type'] == 'modified']
        self.assertGreater(len(modified), 0,
            "Failed to detect file modification")

    def test_detects_deleted_file(self):
        """Create, watch, delete, detect."""
        import tempfile
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
            f.write('will be deleted')
            path = f.name

        s = Sentinel()
        s.watch_files([path])
        os.unlink(path)

        changes = s.check_integrity()
        deleted = [c for c in changes if c['type'] == 'deleted']
        self.assertGreater(len(deleted), 0,
            "Failed to detect file deletion")

    def test_no_false_change(self):
        """Unchanged file should not flag."""
        import tempfile
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
            f.write('stable content')
            path = f.name

        s = Sentinel()
        s.watch_files([path])
        changes = s.check_integrity()
        os.unlink(path)

        self.assertEqual(len(changes), 0,
            "False file change alert on untouched file")


class TestStatus(unittest.TestCase):

    def test_status_fields(self):
        s = Sentinel()
        s.feed_metrics({'cpu': 25, 'memory': 60})
        s.feed_metrics({'cpu': 26, 'memory': 61})
        s.feed_metrics({'cpu': 24, 'memory': 59})
        s.feed_metrics({'cpu': 25, 'memory': 60})
        st = s.status()
        self.assertIn('overall', st)
        self.assertIn('metrics', st)
        self.assertIn('cpu', st['metrics'])

    def test_overall_normal(self):
        s = Sentinel()
        for _ in range(10):
            s.feed_metrics({'cpu': 25 + np.random.randn() * 2})
        st = s.status()
        self.assertEqual(st['overall'], 'NORMAL')

    def test_report_readable(self):
        s = Sentinel()
        for _ in range(10):
            s.feed_metrics({'cpu': 25, 'memory': 60, 'connections': 20})
        r = s.report()
        self.assertIn('SENTINEL', r)
        self.assertIn('cpu', r)


class TestSaveLoad(unittest.TestCase):

    def test_save_load_baseline(self):
        import tempfile
        s = Sentinel()
        s.set_baseline({'cpu': {'mean': 25, 'std': 5, 'min': 10, 'max': 40, 'samples': 60}})
        s.watch_files(['/tmp'])

        path = tempfile.mktemp(suffix='.json')
        s.save_baseline(path)

        s2 = Sentinel()
        s2.load_baseline(path)
        os.unlink(path)

        self.assertTrue(s2.is_baselined)
        self.assertIn('cpu', s2.baseline_stats)


class TestRealSystem(unittest.TestCase):

    def test_collect_metrics(self):
        """Actually collect from this machine."""
        s = Sentinel()
        metrics = s.collect()
        self.assertIn('cpu', metrics)
        self.assertIn('processes', metrics)
        self.assertGreater(metrics['processes'], 0,
            "No processes detected — collection broken")

    def test_live_check(self):
        """Collect + check without baseline = no alerts (no baseline to compare)."""
        s = Sentinel()
        for _ in range(5):
            s.collect()
            time.sleep(0.1)
        alerts = s.check()
        # Without baseline, should have no zscore-based alerts
        zscore_alerts = [a for a in alerts if 'zscore' in a]
        self.assertEqual(len(zscore_alerts), 0)


if __name__ == '__main__':
    unittest.main()
