"""
Tests for gump.coupling_license — Coupling-based software protection
Run: cd gump-package && python tests/test_coupling_license.py
"""
import sys, os, json, time, unittest, tempfile
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from gump.coupling_license import (
    CouplingLicense, _machine_fingerprint, _spectral_hash,
    K_PEAK, K_MIN, K_DECAY_RATE
)


class TestFingerprint(unittest.TestCase):

    def test_fingerprint_exists(self):
        fp = _machine_fingerprint()
        self.assertIsInstance(fp, str)
        self.assertEqual(len(fp), 64)  # sha256 hex

    def test_fingerprint_deterministic(self):
        fp1 = _machine_fingerprint()
        fp2 = _machine_fingerprint()
        self.assertEqual(fp1, fp2)

    def test_spectral_hash_deterministic(self):
        h1 = _spectral_hash('test', 'salt')
        h2 = _spectral_hash('test', 'salt')
        self.assertEqual(h1, h2)

    def test_spectral_hash_different_inputs(self):
        h1 = _spectral_hash('hello', 'salt')
        h2 = _spectral_hash('world', 'salt')
        self.assertNotEqual(h1, h2)

    def test_spectral_hash_different_salts(self):
        h1 = _spectral_hash('test', 'salt1')
        h2 = _spectral_hash('test', 'salt2')
        self.assertNotEqual(h1, h2)


class TestLicenseBasics(unittest.TestCase):

    def setUp(self):
        # Use temp state file so tests don't interfere with real state
        self.tmpdir = tempfile.mkdtemp()
        self.orig_state_file = CouplingLicense.STATE_FILE
        CouplingLicense.STATE_FILE = os.path.join(self.tmpdir, 'test_state.json')

    def tearDown(self):
        CouplingLicense.STATE_FILE = self.orig_state_file
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_initial_state(self):
        lic = CouplingLicense()
        self.assertFalse(lic.coupled)
        self.assertAlmostEqual(lic.K, K_MIN, places=3)
        self.assertEqual(lic.precision, lic.precision)  # doesn't crash

    def test_activate_valid_key(self):
        lic = CouplingLicense()
        result = lic.activate('GUMP-ABCD-EFGH-IJKL')
        self.assertEqual(result['status'], 'coupled')
        self.assertAlmostEqual(lic.K, K_PEAK, places=3)
        self.assertTrue(lic.coupled)

    def test_activate_invalid_key(self):
        lic = CouplingLicense()
        result = lic.activate('INVALID-KEY')
        self.assertEqual(result['status'], 'failed')
        self.assertAlmostEqual(lic.K, K_MIN, places=3)

    def test_activate_wrong_prefix(self):
        lic = CouplingLicense()
        result = lic.activate('XUMP-ABCD-EFGH-IJKL')
        self.assertEqual(result['status'], 'failed')

    def test_precision_at_peak(self):
        lic = CouplingLicense()
        lic.activate('GUMP-AAAA-BBBB-CCCC')
        self.assertEqual(lic.precision, 1.0)

    def test_precision_at_minimum(self):
        lic = CouplingLicense()
        # Not activated, K = K_MIN
        self.assertLess(lic.precision, 0.1)

    def test_calibrated_on_same_machine(self):
        lic = CouplingLicense()
        lic.activate('GUMP-AAAA-BBBB-CCCC')
        self.assertTrue(lic.calibrated)

    def test_gate_returns_modifier(self):
        lic = CouplingLicense()
        lic.activate('GUMP-AAAA-BBBB-CCCC')
        mod = lic.gate('tensions')
        self.assertIn('K', mod)
        self.assertIn('precision', mod)
        self.assertIn('noise', mod)
        self.assertIn('scale_limit', mod)
        self.assertTrue(mod['full_capability'])

    def test_gate_degraded(self):
        lic = CouplingLicense()
        # Not activated
        mod = lic.gate('tensions')
        self.assertFalse(mod['full_capability'])
        self.assertGreater(mod['noise'], 0)
        self.assertLess(mod['scale_limit'], 1_000_000)  # way below full capability

    def test_status_fields(self):
        lic = CouplingLicense()
        lic.activate('GUMP-AAAA-BBBB-CCCC')
        s = lic.status()
        self.assertTrue(s['activated'])
        self.assertEqual(s['phase'], 'peak')
        self.assertTrue(s['coupled'])
        self.assertTrue(s['calibrated'])
        self.assertIn('machine_id', s)


class TestDecay(unittest.TestCase):

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.orig_state_file = CouplingLicense.STATE_FILE
        CouplingLicense.STATE_FILE = os.path.join(self.tmpdir, 'test_state.json')

    def tearDown(self):
        CouplingLicense.STATE_FILE = self.orig_state_file
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_no_decay_within_grace(self):
        lic = CouplingLicense()
        lic.activate('GUMP-AAAA-BBBB-CCCC')
        # Simulate 3 days passing (within 7-day grace)
        lic._last_coupled = time.time() - 3 * 24 * 3600
        lic._apply_decay()
        self.assertAlmostEqual(lic.K, K_PEAK, places=3)

    def test_decay_after_grace(self):
        lic = CouplingLicense()
        lic.activate('GUMP-AAAA-BBBB-CCCC')
        # Simulate 10 days passing (3 days past grace)
        lic._last_coupled = time.time() - 10 * 24 * 3600
        lic._apply_decay()
        self.assertLess(lic.K, K_PEAK)
        self.assertGreater(lic.K, K_MIN)

    def test_decay_severe_after_months(self):
        lic = CouplingLicense()
        lic.activate('GUMP-AAAA-BBBB-CCCC')
        # Simulate 90 days
        lic._last_coupled = time.time() - 90 * 24 * 3600
        lic._apply_decay()
        self.assertLess(lic.K, 0.5)  # severely degraded

    def test_never_below_minimum(self):
        lic = CouplingLicense()
        lic.activate('GUMP-AAAA-BBBB-CCCC')
        # Simulate 365 days
        lic._last_coupled = time.time() - 365 * 24 * 3600
        lic._apply_decay()
        self.assertGreaterEqual(lic.K, K_MIN)  # the 0.002%

    def test_recouple_restores_peak(self):
        lic = CouplingLicense()
        lic.activate('GUMP-AAAA-BBBB-CCCC')
        # Decay
        lic._last_coupled = time.time() - 14 * 24 * 3600
        lic._apply_decay()
        self.assertLess(lic.K, K_PEAK)
        # Recouple
        result = lic.recouple()
        self.assertEqual(result['status'], 'recoupled')
        self.assertAlmostEqual(lic.K, K_PEAK, places=3)


class TestPersistence(unittest.TestCase):

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.orig_state_file = CouplingLicense.STATE_FILE
        CouplingLicense.STATE_FILE = os.path.join(self.tmpdir, 'test_state.json')

    def tearDown(self):
        CouplingLicense.STATE_FILE = self.orig_state_file
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_state_persists(self):
        lic1 = CouplingLicense()
        lic1.activate('GUMP-AAAA-BBBB-CCCC')
        # New instance should load saved state
        lic2 = CouplingLicense()
        self.assertTrue(lic2._activated)
        self.assertAlmostEqual(lic2.K, K_PEAK, places=2)

    def test_tampered_state_rejected(self):
        lic1 = CouplingLicense()
        lic1.activate('GUMP-AAAA-BBBB-CCCC')
        # Tamper with state file
        with open(CouplingLicense.STATE_FILE) as f:
            state = json.load(f)
        state['K'] = K_PEAK  # try to set K to peak manually
        state['integrity'] = 'fake'
        with open(CouplingLicense.STATE_FILE, 'w') as f:
            json.dump(state, f)
        # New instance should detect tampering
        lic2 = CouplingLicense()
        self.assertFalse(lic2._activated)  # rejected
        self.assertAlmostEqual(lic2.K, K_MIN, places=3)


class TestHardwareBinding(unittest.TestCase):

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.orig_state_file = CouplingLicense.STATE_FILE
        CouplingLicense.STATE_FILE = os.path.join(self.tmpdir, 'test_state.json')

    def tearDown(self):
        CouplingLicense.STATE_FILE = self.orig_state_file
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_wrong_machine_detected(self):
        lic = CouplingLicense()
        lic.activate('GUMP-AAAA-BBBB-CCCC')
        # Simulate different machine
        lic._activation_machine = 'different_machine_hash'
        self.assertFalse(lic.calibrated)
        # Drift increases after recouple attempt on wrong hardware
        lic.recouple()
        self.assertGreater(lic.drift, 0)

    def test_wrong_machine_recouple_fails(self):
        lic = CouplingLicense()
        lic.activate('GUMP-AAAA-BBBB-CCCC')
        lic._activation_machine = 'different_machine_hash'
        result = lic.recouple()
        self.assertEqual(result['status'], 'hardware_mismatch')


class TestThe0002(unittest.TestCase):
    """The 0.002% — never fully kill a pirated copy."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.orig_state_file = CouplingLicense.STATE_FILE
        CouplingLicense.STATE_FILE = os.path.join(self.tmpdir, 'test_state.json')

    def tearDown(self):
        CouplingLicense.STATE_FILE = self.orig_state_file
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_minimum_never_zero(self):
        lic = CouplingLicense()
        # Not activated at all
        self.assertGreater(lic.K, 0)
        self.assertEqual(lic.K, K_MIN)

    def test_gate_still_works_at_minimum(self):
        lic = CouplingLicense()
        mod = lic.gate()
        # Scale limit should allow SOMETHING
        self.assertGreater(mod['scale_limit'], 0)
        # Precision is near zero but not zero
        self.assertGreater(lic.precision, 0)

    def test_0002_is_preserved(self):
        """The wonder is preserved. Always."""
        self.assertAlmostEqual(K_MIN, 0.002, places=3)


if __name__ == '__main__':
    unittest.main()
