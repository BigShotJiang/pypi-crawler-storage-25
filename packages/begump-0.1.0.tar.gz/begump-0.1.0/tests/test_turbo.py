"""
Tests for gump.turbo — K→Native Compiler
"""
import sys, os, time, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from gump.turbo import analyze, compile_and_run, interpret, benchmark, python_to_k, report


class TestAnalyze(unittest.TestCase):

    def test_finds_parallel_waves(self):
        a = analyze(': x 5\n: y 10\n+ x y z\n* x y w')
        self.assertEqual(a['n_ops'], 4)
        self.assertLessEqual(a['n_waves'], 3)  # sets parallel, then ops
        self.assertGreater(a['speedup'], 1.0)

    def test_sequential_chain(self):
        """Each op depends on the previous — no parallelism."""
        a = analyze(': x 5\n* x x y\n* y y z\n* z z w')
        self.assertEqual(a['n_ops'], 4)
        self.assertEqual(a['n_waves'], 4)
        self.assertEqual(a['speedup'], 1.0)

    def test_wide_parallel(self):
        """10 independent operations — should be 1-2 waves."""
        k = '\n'.join(f': x{i} {i}' for i in range(10))
        a = analyze(k)
        self.assertEqual(a['n_ops'], 10)
        self.assertEqual(a['n_waves'], 1)
        self.assertEqual(a['max_wave'], 10)

    def test_wave_details(self):
        a = analyze(': a 3\n: b 4\n+ a b c')
        self.assertGreater(len(a['waves']), 0)
        self.assertIn('operations', a['waves'][0])


class TestInterpret(unittest.TestCase):

    def test_basic(self):
        r = interpret(': x 5\n: y 10\n+ x y z\n@ z')
        self.assertEqual(r['output'], [15.0])
        self.assertFalse(r['native'])

    def test_arithmetic(self):
        r = interpret(': a 12\n* a a b\n@ b')
        self.assertEqual(r['output'], [144.0])

    def test_trig(self):
        r = interpret(': x 0\nsin x y\n@ y')
        self.assertAlmostEqual(r['output'][0], 0.0, places=5)

    def test_multiple_outputs(self):
        r = interpret(': x 3\n: y 4\n+ x y s\n* x y p\n@ s\n@ p')
        self.assertEqual(r['output'], [7.0, 12.0])


class TestCompileAndRun(unittest.TestCase):

    def test_basic_native(self):
        r = compile_and_run(': x 5\n: y 10\n+ x y z\n@ z')
        self.assertIn(15.0, r['output'])
        self.assertGreater(r['waves'], 0)

    def test_correct_result(self):
        r = compile_and_run(': a 7\n: b 8\n* a b c\n@ c')
        self.assertIn(56.0, r['output'])

    def test_trig_native(self):
        import math
        r = compile_and_run(': x 3.14159\nsin x y\n@ y')
        self.assertAlmostEqual(r['output'][0], math.sin(3.14159), places=3)

    def test_complex_program(self):
        k = ''
        k += ': a 3\n: b 4\n'
        k += '* a a a2\n* b b b2\n'
        k += '+ a2 b2 sum\n'
        k += 'sqrt sum hyp\n'
        k += '@ hyp\n'
        r = compile_and_run(k)
        self.assertAlmostEqual(r['output'][0], 5.0, places=3)


class TestBenchmark(unittest.TestCase):

    def test_native_faster_than_interpreted(self):
        b = benchmark(': x 5\n: y 10\n+ x y z\n* x y w', n_iter=10000)
        if 'error' not in b:
            self.assertGreater(b['speedup'], 1,
                "Native should be faster than interpreted")

    def test_speedup_scales_with_ops(self):
        """More operations = higher speedup (more Python overhead to eliminate)."""
        k_small = ': a 5\n: b 10\n+ a b c'
        k_big = '\n'.join(f': x{i} {i}' for i in range(50))
        k_big += '\n' + '\n'.join(f'* x{i} x{i} sq{i}' for i in range(50))

        b_small = benchmark(k_small, n_iter=10000)
        b_big = benchmark(k_big, n_iter=10000)
        if 'error' not in b_small and 'error' not in b_big:
            # Bigger program should show equal or better speedup
            self.assertGreaterEqual(b_big['speedup'], b_small['speedup'] * 0.5,
                "Bigger program should benefit more from native compilation")


class TestPythonToK(unittest.TestCase):

    def test_simple_assignment(self):
        k = python_to_k('a = 5')
        self.assertIn(': a 5', k)

    def test_addition(self):
        k = python_to_k('a = 5\nb = 10\nc = a + b')
        self.assertIn('+ a b c', k)

    def test_multiplication(self):
        k = python_to_k('x = 3\ny = x * x')
        self.assertIn('* x x y', k)

    def test_sqrt(self):
        k = python_to_k('x = 25\ny = sqrt(x)')
        self.assertIn('sqrt x y', k)

    def test_full_pipeline(self):
        """Python → K → interpret → correct result."""
        k = python_to_k('a = 3\nb = 4\nc = a + b')
        r = interpret(k + '\n@ c')
        self.assertEqual(r['output'], [7.0])


class TestReport(unittest.TestCase):

    def test_report_readable(self):
        r = report(': x 5\n: y 10\n+ x y z\n* x y w')
        self.assertIn('TURBO', r)
        self.assertIn('Wave', r)
        self.assertIn('Operations', r)


class TestCorrectness(unittest.TestCase):
    """Native must produce EXACTLY the same results as interpreted."""

    def test_arithmetic_matches(self):
        k = ': a 7\n: b 3\n+ a b s\n- a b d\n* a b p\n/ a b q\n@ s\n@ d\n@ p\n@ q'
        interp = interpret(k)
        native = compile_and_run(k)
        for iv, nv in zip(interp['output'], native['output']):
            self.assertAlmostEqual(iv, nv, places=10,
                msg=f"Interpreted {iv} != native {nv}")

    def test_trig_matches(self):
        k = ': x 1.5\nsin x s\ncos x c\n* s s s2\n* c c c2\n+ s2 c2 one\n@ one'
        interp = interpret(k)
        native = compile_and_run(k)
        # sin²(x) + cos²(x) = 1
        self.assertAlmostEqual(interp['output'][0], 1.0, places=5)
        self.assertAlmostEqual(native['output'][0], 1.0, places=5)

    def test_pythagorean(self):
        """3² + 4² = 5²"""
        k = ': a 3\n: b 4\n* a a a2\n* b b b2\n+ a2 b2 sum\nsqrt sum hyp\n@ hyp'
        interp = interpret(k)
        native = compile_and_run(k)
        self.assertAlmostEqual(interp['output'][0], 5.0, places=5)
        self.assertAlmostEqual(native['output'][0], 5.0, places=5)


if __name__ == '__main__':
    unittest.main()
