"""
Tests for gump.accord — Compliance intelligence.
Scans regulations. Finds gaps. Traces origins. Generates counter-strategies.
"""
import sys, os, unittest
import numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from gump.accord import Accord


def build_begump():
    """Set up beGump LLC as the test company."""
    a = Accord('beGump LLC')
    a.set_profile({
        'industry': 'software',
        'state': 'NJ',
        'employees': 1,
        'handles_data': True,
        'accepts_payments': True,
        'international': False,
    })
    return a


def add_nj_privacy(a):
    a.ingest_regulation(
        title='NJ Data Privacy Act',
        text='All businesses handling personal data of NJ residents must implement reasonable security measures. '
             'Businesses must provide clear privacy notices. Consumers shall have the right to opt-out of data sales. '
             'Businesses with fewer than 50 employees may have extended compliance timelines. '
             'Companies must notify consumers within 72 hours of a data breach. '
             'Failure to comply shall result in fines up to $10,000 per violation. '
             'Exempt organizations include those processing data for fewer than 100 NJ residents annually.',
        jurisdiction='NJ',
        effective='2026-07-01',
        category='privacy',
        penalty='$10,000 per violation',
    )


def add_pci(a):
    a.ingest_regulation(
        title='PCI DSS 4.0',
        text='Merchants must encrypt all cardholder data at rest and in transit. '
             'Required annual penetration testing. '
             'Merchants shall maintain audit logs of all access to cardholder data. '
             'Multi-factor authentication is mandatory for administrative access. '
             'Merchants must file quarterly compliance reports.',
        jurisdiction='federal',
        effective='2025-03-31',
        category='payment',
        penalty='Fines up to $500,000 and loss of card processing privileges',
    )


def add_llc(a):
    a.ingest_regulation(
        title='NJ LLC Annual Report',
        text='All LLCs registered in NJ must file an annual report with the Division of Revenue. '
             'The annual report shall be filed by the anniversary of formation. '
             'Failure to file may result in administrative dissolution. Filing fee is $75.',
        jurisdiction='NJ',
        effective='immediate',
        category='corporate',
        penalty='Administrative dissolution',
    )


class TestBasics(unittest.TestCase):

    def test_create(self):
        a = Accord('TestCo')
        self.assertEqual(a.company, 'TestCo')

    def test_set_profile(self):
        a = Accord()
        a.set_profile({'industry': 'software', 'state': 'NJ'})
        self.assertEqual(a.profile['state'], 'NJ')

    def test_ingest_regulation(self):
        a = build_begump()
        result = add_nj_privacy(a)
        self.assertEqual(len(a.regulations), 1)

    def test_scan_requires_profile(self):
        a = Accord()
        a.ingest_regulation(title='Test', text='Must comply.', jurisdiction='NJ')
        result = a.scan()
        self.assertIn('error', result)

    def test_scan_requires_regulations(self):
        a = Accord()
        a.set_profile({'industry': 'software', 'state': 'NJ'})
        result = a.scan()
        self.assertIn('error', result)


class TestScanning(unittest.TestCase):

    def test_finds_gaps(self):
        a = build_begump()
        add_nj_privacy(a)
        scan = a.scan()
        self.assertGreater(scan['gaps_found'], 0, "Should find compliance gaps for NJ privacy")

    def test_multi_regulation_scan(self):
        a = build_begump()
        add_nj_privacy(a)
        add_pci(a)
        add_llc(a)
        scan = a.scan()
        self.assertGreater(scan['regulations_applicable'], 1, "Multiple regs should apply")
        self.assertGreater(scan['gaps_found'], 5, "Should find many gaps across 3 regulations")

    def test_jurisdiction_filter(self):
        """CA regulation shouldn't apply to NJ company."""
        a = build_begump()
        a.ingest_regulation(
            title='CCPA',
            text='California businesses must provide privacy notices. Consumers shall opt out.',
            jurisdiction='CA',
            category='privacy',
        )
        scan = a.scan()
        self.assertEqual(scan['gaps_found'], 0, "CA regulation shouldn't apply to NJ company")

    def test_federal_applies_everywhere(self):
        a = build_begump()
        add_pci(a)
        scan = a.scan()
        self.assertGreater(scan['gaps_found'], 0, "Federal regs apply to all states")

    def test_category_relevance(self):
        """Environmental reg shouldn't flag for software company."""
        a = build_begump()
        a.ingest_regulation(
            title='EPA Waste Disposal',
            text='Manufacturers must dispose of hazardous waste properly. Emissions shall not exceed limits.',
            jurisdiction='federal',
            category='environmental',
        )
        scan = a.scan()
        self.assertEqual(scan['gaps_found'], 0,
            "Environmental reg shouldn't apply to software company")

    def test_severity_sorting(self):
        a = build_begump()
        add_nj_privacy(a)
        add_pci(a)
        a.scan()
        tensions = [g.tension for g in a.gaps]
        self.assertEqual(tensions, sorted(tensions, reverse=True),
            "Gaps should be sorted by tension descending")


class TestImpact(unittest.TestCase):

    def test_impact_by_regulation(self):
        a = build_begump()
        add_nj_privacy(a)
        add_pci(a)
        impact = a.impact()
        self.assertIn('NJ Data Privacy Act', impact)
        self.assertIn('PCI DSS 4.0', impact)

    def test_impact_has_details(self):
        a = build_begump()
        add_nj_privacy(a)
        impact = a.impact()
        items = impact['NJ Data Privacy Act']
        self.assertGreater(len(items), 0)
        self.assertIn('tension', items[0])
        self.assertIn('action', items[0])


class TestActionPlan(unittest.TestCase):

    def test_action_plan_deduplicates(self):
        a = build_begump()
        add_nj_privacy(a)
        plan = a.action_plan()
        actions = [p['action'] for p in plan]
        self.assertEqual(len(actions), len(set(actions)), "Action plan should have no duplicates")

    def test_action_plan_has_priority(self):
        a = build_begump()
        add_nj_privacy(a)
        add_pci(a)
        plan = a.action_plan()
        self.assertGreater(len(plan), 0)
        self.assertIn(plan[0]['priority'], ('CRITICAL', 'HIGH', 'MEDIUM', 'LOW'))


class TestDeadlines(unittest.TestCase):

    def test_deadline_ordering(self):
        a = build_begump()
        add_nj_privacy(a)
        add_pci(a)
        add_llc(a)
        deadlines = a.deadlines()
        self.assertGreater(len(deadlines), 0)
        days = [d['days_left'] for d in deadlines]
        self.assertEqual(days, sorted(days), "Deadlines should be sorted by urgency")

    def test_overdue_detection(self):
        a = build_begump()
        add_pci(a)  # effective 2025-03-31 = overdue
        deadlines = a.deadlines()
        overdue = [d for d in deadlines if d['urgency'] == 'OVERDUE']
        self.assertGreater(len(overdue), 0, "PCI DSS should be overdue")

    def test_immediate_is_urgent(self):
        a = build_begump()
        add_llc(a)
        deadlines = a.deadlines()
        urgent = [d for d in deadlines if d['urgency'] == 'URGENT']
        self.assertGreater(len(urgent), 0, "Immediate deadline should be URGENT")


class TestComplianceStatus(unittest.TestCase):

    def test_initial_status_all_open(self):
        a = build_begump()
        add_nj_privacy(a)
        status = a.compliance_status()
        self.assertEqual(status['done'], 0)
        self.assertGreater(status['open'], 0)
        self.assertEqual(status['compliance_pct'], 0.0)

    def test_mark_compliant(self):
        a = build_begump()
        add_nj_privacy(a)
        plan = a.action_plan()
        a.mark_compliant('NJ Data Privacy Act', plan[0]['action'], status='done', notes='Implemented')
        status = a.compliance_status()
        self.assertGreater(status['done'], 0)
        self.assertGreater(status['compliance_pct'], 0)


class TestRiskAssessment(unittest.TestCase):

    def test_risk_scoring(self):
        a = build_begump()
        add_nj_privacy(a)
        add_pci(a)
        add_llc(a)
        risks = a.risk_assessment()
        self.assertEqual(len(risks), 3)
        # All should have risk scores
        self.assertGreater(risks[0]['risk_score'], 0,
            "Highest-risk regulation should have nonzero risk score")
        # Sorted descending
        scores = [r['risk_score'] for r in risks]
        self.assertEqual(scores, sorted(scores, reverse=True),
            "Risks should be sorted highest first")

    def test_dissolution_is_existential(self):
        a = build_begump()
        add_llc(a)
        risks = a.risk_assessment()
        llc_risk = [r for r in risks if r['regulation'] == 'NJ LLC Annual Report'][0]
        self.assertEqual(llc_risk['penalty_score'], 10,
            "Dissolution should score maximum penalty")

    def test_risk_decreases_after_compliance(self):
        a = build_begump()
        add_nj_privacy(a)
        add_pci(a)
        risks_before = a.risk_assessment()
        total_before = sum(r['risk_score'] for r in risks_before)
        # Mark everything done
        for gap in a.gaps:
            a.mark_compliant(gap.regulation.title, gap.action['action'], status='done')
        risks_after = a.risk_assessment()
        total_after = sum(r['risk_score'] for r in risks_after)
        self.assertLess(total_after, total_before,
            "Total risk should decrease after addressing gaps")


class TestRegulatoryIntelligence(unittest.TestCase):
    """Origin tracing, genealogy, who wrote it."""

    def test_ingest_origin(self):
        a = build_begump()
        add_nj_privacy(a)
        result = a.ingest_origin('NJ Data Privacy Act', {
            'sponsor': 'Senator Turner',
            'committee': 'Commerce Committee',
        })
        self.assertEqual(result['status'], 'added')

    def test_origin_not_found(self):
        a = build_begump()
        result = a.ingest_origin('Nonexistent Law', {'sponsor': 'Nobody'})
        self.assertIn('error', result)

    def test_trace_full(self):
        a = build_begump()
        add_nj_privacy(a)
        a.ingest_origin('NJ Data Privacy Act', {
            'sponsor': 'Senator Turner',
            'co_sponsors': ['Assemblyman Zwicker'],
            'committee': 'Commerce Committee',
            'lobbied_by': ['EFF', 'ACLU'],
            'vote': 'Passed 28-8',
            'public_comment': True,
            'comment_deadline': '2026-05-01',
            'exemptions': ['Small businesses'],
            'history': [
                {'date': '2025-09-15', 'event': 'Introduced', 'actor': 'Sen. Turner'},
                {'date': '2026-01-10', 'event': 'Passed Senate', 'actor': 'Full Senate'},
            ],
        })
        trace = a.trace_full('NJ Data Privacy Act')
        self.assertEqual(trace['sponsor'], 'Senator Turner')
        self.assertIn('Assemblyman Zwicker', trace['co_sponsors'])
        self.assertEqual(trace['committee'], 'Commerce Committee')
        self.assertEqual(len(trace['lobbied_by']), 2)
        self.assertTrue(trace['public_comment'])
        self.assertGreater(trace['chain_length'], 5,
            "Full chain should include sponsor + co-sponsors + committee + lobbyists + history")

    def test_trace_all(self):
        a = build_begump()
        add_nj_privacy(a)
        add_pci(a)
        traces = a.trace_full()
        self.assertEqual(len(traces), 2, "Should trace all regulations when no title specified")


class TestExemptions(unittest.TestCase):

    def test_find_text_exemptions(self):
        a = build_begump()
        add_nj_privacy(a)
        ex = a.find_exemptions('NJ Data Privacy Act')
        self.assertGreater(ex['total'], 0, "Should find exemptions in NJ Privacy text")
        # Should find 'fewer than' and 'exempt'
        types_found = [e['type'] for e in ex['detected_exemptions']]
        self.assertTrue(any('fewer' in t for t in types_found),
            "Should detect 'fewer than' exemption")
        self.assertTrue(any('exempt' in t for t in types_found),
            "Should detect 'exempt' clause")

    def test_explicit_exemptions(self):
        a = build_begump()
        add_nj_privacy(a)
        a.ingest_origin('NJ Data Privacy Act', {
            'exemptions': ['Businesses with fewer than 50 employees', 'Nonprofits'],
        })
        ex = a.find_exemptions('NJ Data Privacy Act')
        self.assertEqual(len(ex['explicit_exemptions']), 2)

    def test_safe_harbor(self):
        a = build_begump()
        a.ingest_regulation(
            title='Safe Harbor Test',
            text='Companies must implement encryption. A safe harbor provision applies to companies that demonstrate good faith compliance efforts.',
            jurisdiction='NJ',
            category='security',
        )
        ex = a.find_exemptions('Safe Harbor Test')
        types_found = [e['type'] for e in ex['detected_exemptions']]
        self.assertIn('safe harbor', types_found,
            "Should detect safe harbor provision")
        self.assertIn('good faith', types_found,
            "Should detect good faith provision")

    def test_no_exemptions(self):
        a = build_begump()
        a.ingest_regulation(
            title='Strict Law',
            text='All companies must comply. There are no exceptions. Violations result in penalties.',
            jurisdiction='NJ',
            category='corporate',
        )
        ex = a.find_exemptions('Strict Law')
        self.assertEqual(ex['total'], 0, "Strict law should have no exemptions")


class TestCounterStrategies(unittest.TestCase):

    def test_always_has_comply(self):
        a = build_begump()
        add_nj_privacy(a)
        a.scan()
        cs = a.counter_strategies('NJ Data Privacy Act')
        strategies = [s['strategy'] for s in cs['strategies']]
        self.assertIn('COMPLY', strategies, "COMPLY should always be an option")

    def test_public_comment_when_open(self):
        a = build_begump()
        add_nj_privacy(a)
        a.scan()
        a.ingest_origin('NJ Data Privacy Act', {
            'public_comment': True,
            'comment_deadline': '2026-05-01',
        })
        cs = a.counter_strategies('NJ Data Privacy Act')
        strategies = [s['strategy'] for s in cs['strategies']]
        self.assertIn('PUBLIC COMMENT', strategies,
            "Should suggest public comment when comment period is open")
        comment = [s for s in cs['strategies'] if s['strategy'] == 'PUBLIC COMMENT'][0]
        self.assertIn('2026-05-01', comment['description'])

    def test_exemption_strategy_when_exemptions_exist(self):
        a = build_begump()
        add_nj_privacy(a)
        a.scan()
        a.ingest_origin('NJ Data Privacy Act', {'exemptions': ['Small biz']})
        cs = a.counter_strategies('NJ Data Privacy Act')
        strategies = [s['strategy'] for s in cs['strategies']]
        self.assertIn('CLAIM EXEMPTION', strategies)

    def test_challenge_when_penalty(self):
        a = build_begump()
        add_nj_privacy(a)
        a.scan()
        cs = a.counter_strategies('NJ Data Privacy Act')
        strategies = [s['strategy'] for s in cs['strategies']]
        self.assertIn('CHALLENGE', strategies,
            "Should suggest challenge when regulation has penalty")

    def test_lobby_when_sponsor_known(self):
        a = build_begump()
        add_nj_privacy(a)
        a.scan()
        a.ingest_origin('NJ Data Privacy Act', {'sponsor': 'Senator Turner'})
        cs = a.counter_strategies('NJ Data Privacy Act')
        strategies = [s['strategy'] for s in cs['strategies']]
        self.assertIn('LOBBY FOR AMENDMENT', strategies)
        lobby = [s for s in cs['strategies'] if s['strategy'] == 'LOBBY FOR AMENDMENT'][0]
        self.assertIn('Senator Turner', lobby['description'])

    def test_automate_for_tech_regulations(self):
        a = build_begump()
        add_pci(a)
        a.scan()
        cs = a.counter_strategies('PCI DSS 4.0')
        strategies = [s['strategy'] for s in cs['strategies']]
        self.assertIn('AUTOMATE', strategies,
            "PCI with encryption/audit requirements should suggest automation")

    def test_recommended_first(self):
        a = build_begump()
        add_nj_privacy(a)
        a.scan()
        a.ingest_origin('NJ Data Privacy Act', {
            'public_comment': True,
            'comment_deadline': '2026-05-01',
            'sponsor': 'Senator Turner',
            'exemptions': ['Small biz'],
        })
        cs = a.counter_strategies('NJ Data Privacy Act')
        self.assertIn('COMPLY', cs['recommended_first'])
        self.assertIn('PUBLIC COMMENT', cs['recommended_first'])

    def test_all_regulations_strategies(self):
        a = build_begump()
        add_nj_privacy(a)
        add_pci(a)
        add_llc(a)
        a.scan()
        all_cs = a.counter_strategies()
        self.assertEqual(len(all_cs), 3, "Should return strategies for all 3 regulations")


class TestChangeDetection(unittest.TestCase):

    def test_detect_new_requirements(self):
        a = build_begump()
        add_nj_privacy(a)
        # New version adds biometric requirements
        new_text = (
            'All businesses handling personal data of NJ residents must implement reasonable security measures. '
            'Businesses must provide clear privacy notices. Consumers shall have the right to opt-out of data sales. '
            'Companies must notify consumers within 72 hours of a data breach. '
            'Businesses shall not collect biometric data without explicit written consent. '
            'All data processing activities must be logged and auditable.'
        )
        changes = a.detect_changes('NJ Data Privacy Act', new_text)
        self.assertGreater(changes['sentences_added'], 0)
        self.assertEqual(changes['impact'], 'SIGNIFICANT')
        self.assertTrue(changes['action_needed'])

    def test_no_changes(self):
        a = build_begump()
        a.ingest_regulation(title='Static Law', text='Companies must comply. This is the law.', jurisdiction='NJ')
        changes = a.detect_changes('Static Law', 'Companies must comply. This is the law.')
        self.assertEqual(changes['impact'], 'NONE')

    def test_unknown_regulation(self):
        a = build_begump()
        result = a.detect_changes('Nonexistent', 'New text.')
        self.assertIn('error', result)


class TestAuditTrail(unittest.TestCase):

    def test_log_action(self):
        a = build_begump()
        a.log_action('Reviewed NJ Privacy Act', 'Initial review complete')
        a.log_action('Implemented encryption', 'AES-256 at rest')
        trail = a.audit_trail()
        self.assertEqual(len(trail), 2)
        self.assertEqual(trail[0]['action'], 'Implemented encryption')  # most recent first

    def test_trail_has_timestamp(self):
        a = build_begump()
        a.log_action('Test action')
        trail = a.audit_trail()
        self.assertIn('timestamp', trail[0])
        self.assertIn('company', trail[0])


class TestChecklist(unittest.TestCase):

    def test_generate_checklist(self):
        a = build_begump()
        add_nj_privacy(a)
        add_pci(a)
        checklist = a.generate_checklist()
        self.assertGreater(checklist['total'], 0)
        self.assertEqual(checklist['done'], 0)
        self.assertEqual(checklist['remaining'], checklist['total'])

    def test_category_filter(self):
        a = build_begump()
        add_nj_privacy(a)
        add_pci(a)
        a.scan()
        categories = list(set(g.area for g in a.gaps))
        if categories:
            filtered = a.generate_checklist(category=categories[0])
            for item in filtered['items']:
                self.assertEqual(item['category'], categories[0])


class TestReport(unittest.TestCase):

    def test_report_string(self):
        a = build_begump()
        add_nj_privacy(a)
        add_pci(a)
        add_llc(a)
        report = a.report()
        self.assertIn('ACCORD', report)
        self.assertIn('beGump LLC', report)
        self.assertIn('ACTION PLAN', report)

    def test_report_no_profile(self):
        a = Accord()
        a.ingest_regulation(title='Test', text='Must comply.', jurisdiction='NJ')
        report = a.report()
        self.assertIn('profile', report.lower())


class TestRealWorldScenario(unittest.TestCase):
    """Full end-to-end: beGump LLC compliance workflow."""

    def test_full_workflow(self):
        a = build_begump()
        add_nj_privacy(a)
        add_pci(a)
        add_llc(a)

        # 1. Scan
        scan = a.scan()
        self.assertGreater(scan['gaps_found'], 0)

        # 2. Check deadlines
        deadlines = a.deadlines()
        self.assertGreater(len(deadlines), 0)

        # 3. Get action plan
        plan = a.action_plan()
        self.assertGreater(len(plan), 0)

        # 4. Assess risk
        risks = a.risk_assessment()
        self.assertGreater(len(risks), 0)

        # 5. Add origin intelligence
        a.ingest_origin('NJ Data Privacy Act', {
            'sponsor': 'Senator Turner',
            'public_comment': True,
            'comment_deadline': '2026-05-01',
            'exemptions': ['Small businesses'],
        })

        # 6. Get counter-strategies
        cs = a.counter_strategies('NJ Data Privacy Act')
        self.assertGreater(len(cs['strategies']), 3)

        # 7. Find exemptions
        ex = a.find_exemptions('NJ Data Privacy Act')
        self.assertGreater(ex['total'], 0)

        # 8. Trace origin
        trace = a.trace_full('NJ Data Privacy Act')
        self.assertEqual(trace['sponsor'], 'Senator Turner')

        # 9. Start addressing gaps
        a.mark_compliant('NJ Data Privacy Act', plan[0]['action'], status='done')
        a.log_action('Started compliance', 'Addressed first gap')

        # 10. Check progress
        status = a.compliance_status()
        self.assertGreater(status['compliance_pct'], 0)

        # 11. Generate checklist
        checklist = a.generate_checklist()
        self.assertGreater(checklist['done'], 0)

        # 12. Full report
        report = a.report()
        self.assertIn('ACCORD', report)


class TestCostEstimation(unittest.TestCase):

    def test_cost_estimate(self):
        a = build_begump()
        add_nj_privacy(a)
        add_pci(a)
        cost = a.estimate_cost(hourly_rate=200)
        self.assertGreater(cost['total_hours'], 0)
        self.assertGreater(cost['total_cost'], 0)
        self.assertEqual(cost['hourly_rate'], 200)
        self.assertGreater(len(cost['per_regulation']), 0)

    def test_cost_decreases_after_compliance(self):
        a = build_begump()
        add_nj_privacy(a)
        cost_before = a.estimate_cost()
        plan = a.action_plan()
        for action in plan:
            a.mark_compliant(action['regulation'], action['action'], status='done')
        cost_after = a.estimate_cost()
        self.assertLess(cost_after['total_cost'], cost_before['total_cost'],
            "Cost should decrease as gaps are addressed")

    def test_cost_with_no_gaps(self):
        a = build_begump()
        a.ingest_regulation(
            title='Irrelevant Law',
            text='Manufacturers of chemicals must dispose of waste.',
            jurisdiction='CA',
            category='environmental',
        )
        cost = a.estimate_cost()
        self.assertEqual(cost['total_cost'], 0)


class TestConflictDetection(unittest.TestCase):

    def test_retain_vs_delete_conflict(self):
        a = build_begump()
        a.ingest_regulation(title='Data Retention Act',
            text='Businesses must retain all customer records for 7 years.',
            jurisdiction='NJ', category='privacy')
        a.ingest_regulation(title='Right to Erasure Act',
            text='Consumers have the right to be forgotten. All personal data must be erased upon request.',
            jurisdiction='NJ', category='privacy')
        conflicts = a.find_conflicts()
        self.assertGreater(len(conflicts), 0,
            "Should detect conflict between retention and erasure requirements")

    def test_no_conflict_in_compatible_regs(self):
        a = build_begump()
        a.ingest_regulation(title='Encrypt Data',
            text='All businesses must encrypt personal data at rest.',
            jurisdiction='NJ', category='security')
        a.ingest_regulation(title='Audit Logs',
            text='All businesses must maintain audit logs of data access.',
            jurisdiction='NJ', category='security')
        conflicts = a.find_conflicts()
        self.assertEqual(len(conflicts), 0,
            "Compatible regulations should not conflict")

    def test_disclose_vs_confidential_conflict(self):
        a = build_begump()
        a.ingest_regulation(title='Transparency Act',
            text='Companies must disclose all data processing activities to the public.',
            jurisdiction='NJ', category='privacy')
        a.ingest_regulation(title='Trade Secret Protection',
            text='Business processes are confidential and shall remain secret.',
            jurisdiction='NJ', category='intellectual_property')
        conflicts = a.find_conflicts()
        self.assertGreater(len(conflicts), 0,
            "Should detect conflict between disclosure and confidentiality")


class TestDashboard(unittest.TestCase):

    def test_dashboard_all_keys(self):
        a = build_begump()
        add_nj_privacy(a)
        add_pci(a)
        add_llc(a)
        d = a.dashboard()
        for key in ['company', 'scan', 'deadlines', 'risk', 'status', 'cost', 'conflicts', 'action_plan']:
            self.assertIn(key, d, f"Dashboard missing key: {key}")

    def test_dashboard_no_profile(self):
        a = Accord()
        a.ingest_regulation(title='Test', text='Must comply.', jurisdiction='NJ')
        d = a.dashboard()
        self.assertIn('error', d)


if __name__ == '__main__':
    unittest.main(verbosity=2)
