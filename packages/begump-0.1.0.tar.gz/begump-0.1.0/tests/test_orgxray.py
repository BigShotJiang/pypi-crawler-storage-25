"""
Tests for gump.orgxray — Organizational X-Ray
Run: cd gump-package && python -m pytest tests/test_orgxray.py -v
  or: cd gump-package && python tests/test_orgxray.py
"""
import sys
import os
import json
import tempfile
import unittest

# Add parent to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from gump.orgxray import scan, scan_csv, scan_org, scan_json, scan_github, visualize


# ═══════════════════════════════════════════════════════════════
# Sample data
# ═══════════════════════════════════════════════════════════════

SMALL_NODES = ['Alice', 'Bob', 'Carol']
SMALL_EDGES = [('Alice', 'Bob'), ('Bob', 'Carol')]

TEAM_NODES = ['CEO', 'VP_Eng', 'VP_Sales', 'Dev1', 'Dev2', 'Dev3', 'Sales1', 'Sales2']
TEAM_EDGES = [
    ('CEO', 'VP_Eng'), ('CEO', 'VP_Sales'),
    ('VP_Eng', 'Dev1'), ('VP_Eng', 'Dev2'), ('VP_Eng', 'Dev3'),
    ('VP_Sales', 'Sales1'), ('VP_Sales', 'Sales2'),
    ('Dev1', 'Dev2'), ('Dev2', 'Dev3'),  # devs collaborate
]

DISCONNECTED_NODES = ['A', 'B', 'C', 'X', 'Y']
DISCONNECTED_EDGES = [('A', 'B'), ('B', 'C'), ('X', 'Y')]  # two components


class TestScan(unittest.TestCase):
    """Core scan function tests."""

    def test_basic_scan(self):
        result = scan(SMALL_NODES, SMALL_EDGES)
        self.assertNotIn('error', result)
        self.assertIn('health_score', result)
        self.assertIn('tensions', result)
        self.assertIn('positions', result)
        self.assertIn('node_scores', result)

    def test_all_keys_present(self):
        result = scan(TEAM_NODES, TEAM_EDGES)
        required = ['health_score', 'tensions', 'redundancies', 'clusters',
                     'hubs', 'isolates', 'bridges', 'action_plan', 'stats',
                     'positions', 'node_scores']
        for key in required:
            self.assertIn(key, result, f'Missing key: {key}')

    def test_positions_has_all_nodes(self):
        result = scan(TEAM_NODES, TEAM_EDGES)
        for node in TEAM_NODES:
            self.assertIn(node, result['positions'])
            pos = result['positions'][node]
            self.assertEqual(len(pos), 2)
            self.assertIsInstance(pos[0], float)
            self.assertIsInstance(pos[1], float)

    def test_node_scores_has_all_nodes(self):
        result = scan(TEAM_NODES, TEAM_EDGES)
        for node in TEAM_NODES:
            self.assertIn(node, result['node_scores'])
            s = result['node_scores'][node]
            self.assertIn('degree', s)
            self.assertIn('cluster', s)
            self.assertIn('is_hub', s)
            self.assertIn('is_isolate', s)

    def test_health_score_range(self):
        result = scan(TEAM_NODES, TEAM_EDGES)
        self.assertGreaterEqual(result['health_score'], 0)
        self.assertLessEqual(result['health_score'], 100)

    def test_disconnected_detects_components(self):
        result = scan(DISCONNECTED_NODES, DISCONNECTED_EDGES)
        self.assertNotIn('error', result)
        # Should detect multiple clusters
        self.assertGreaterEqual(result['stats']['n_clusters'], 2)

    def test_hub_detection(self):
        # CEO connects to VP_Eng and VP_Sales — VP_Eng connects to 4 nodes
        result = scan(TEAM_NODES, TEAM_EDGES)
        hub_names = [h['node'] for h in result['hubs']]
        # VP_Eng has highest degree (CEO + Dev1 + Dev2 + Dev3 = 4)
        # Whether detected as hub depends on threshold, but degree should be highest
        degrees = {n: result['node_scores'][n]['degree'] for n in TEAM_NODES}
        max_degree_node = max(degrees, key=degrees.get)
        self.assertEqual(max_degree_node, 'VP_Eng')

    def test_weighted_edges(self):
        weights = [5.0, 1.0]  # Alice-Bob strong, Bob-Carol weak
        result = scan(SMALL_NODES, SMALL_EDGES, weights)
        self.assertNotIn('error', result)

    def test_empty_nodes(self):
        result = scan([], [])
        self.assertIn('error', result)

    def test_no_edges(self):
        result = scan(['A', 'B'], [])
        self.assertIn('error', result)

    def test_self_loops_in_csv(self):
        csv = "A,B\nB,C\nC,C\n"  # C,C is self-loop
        result = scan_csv(csv)
        self.assertNotIn('error', result)
        # Self-loop should be filtered
        self.assertEqual(result['stats']['n_edges'], 2)

    def test_single_edge(self):
        result = scan(['A', 'B'], [('A', 'B')])
        self.assertNotIn('error', result)


class TestParsers(unittest.TestCase):
    """Input parser tests."""

    def test_csv_basic(self):
        csv = "Alice,Bob\nBob,Carol\nCarol,Alice\n"
        result = scan_csv(csv)
        self.assertNotIn('error', result)
        self.assertEqual(result['stats']['n_nodes'], 3)
        self.assertEqual(result['stats']['n_edges'], 3)

    def test_csv_with_weights(self):
        csv = "Alice,Bob,5\nBob,Carol,1\n"
        result = scan_csv(csv)
        self.assertNotIn('error', result)

    def test_csv_with_header(self):
        csv = "source,target,weight\nAlice,Bob,5\nBob,Carol,1\n"
        result = scan_csv(csv, has_header=True)
        self.assertNotIn('error', result)
        self.assertEqual(result['stats']['n_nodes'], 3)

    def test_csv_from_file(self):
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write("A,B\nB,C\nC,A\n")
            path = f.name
        try:
            result = scan_csv(path)
            self.assertNotIn('error', result)
        finally:
            os.unlink(path)

    def test_csv_empty(self):
        result = scan_csv("")
        self.assertIn('error', result)

    def test_org_dict(self):
        people = ['CEO', 'VP', 'Dev1', 'Dev2']
        reports_to = {'VP': 'CEO', 'Dev1': 'VP', 'Dev2': 'VP'}
        result = scan_org(people, reports_to)
        self.assertNotIn('error', result)
        self.assertEqual(result['stats']['n_nodes'], 4)

    def test_org_list(self):
        people = ['CEO', 'VP', 'Dev1']
        reports_to = [('VP', 'CEO'), ('Dev1', 'VP')]
        result = scan_org(people, reports_to)
        self.assertNotIn('error', result)

    def test_json_nodes_edges(self):
        data = {
            'nodes': ['A', 'B', 'C'],
            'edges': [['A', 'B'], ['B', 'C']]
        }
        result = scan_json(data)
        self.assertNotIn('error', result)

    def test_json_weighted(self):
        data = {
            'nodes': ['A', 'B', 'C'],
            'edges': [['A', 'B', 5], ['B', 'C', 1]]
        }
        result = scan_json(data)
        self.assertNotIn('error', result)

    def test_json_org_format(self):
        data = {
            'people': ['CEO', 'VP', 'Dev'],
            'reports_to': {'VP': 'CEO', 'Dev': 'VP'}
        }
        result = scan_json(data)
        self.assertNotIn('error', result)

    def test_json_string(self):
        data_str = '{"nodes":["A","B"],"edges":[["A","B"]]}'
        result = scan_json(data_str)
        self.assertNotIn('error', result)

    def test_json_infer_nodes(self):
        data = {'edges': [['A', 'B'], ['B', 'C']]}
        result = scan_json(data)
        self.assertNotIn('error', result)
        self.assertEqual(result['stats']['n_nodes'], 3)

    def test_github_basic(self):
        contributors = [
            {'author': 'alice', 'files': ['src/a.py', 'src/b.py']},
            {'author': 'bob', 'files': ['src/b.py', 'src/c.py']},
            {'author': 'carol', 'files': ['src/a.py']},
        ]
        result = scan_github(contributors)
        self.assertNotIn('error', result)
        # alice & bob share b.py, alice & carol share a.py
        self.assertGreaterEqual(result['stats']['n_edges'], 2)

    def test_github_no_overlap(self):
        contributors = [
            {'author': 'alice', 'files': ['a.py']},
            {'author': 'bob', 'files': ['b.py']},
        ]
        result = scan_github(contributors)
        self.assertIn('error', result)  # no co-edits


class TestVisualize(unittest.TestCase):
    """HTML visualization tests."""

    def test_html_valid(self):
        result = scan(TEAM_NODES, TEAM_EDGES)
        html = visualize(result)
        self.assertIn('<html', html)
        self.assertIn('<canvas', html)
        self.assertIn('Org X-Ray', html)

    def test_html_contains_data(self):
        result = scan(SMALL_NODES, SMALL_EDGES)
        html = visualize(result)
        self.assertIn('Alice', html)
        self.assertIn('Bob', html)
        self.assertIn('Carol', html)

    def test_html_error_case(self):
        html = visualize({'error': 'test error'})
        self.assertIn('test error', html)

    def test_html_has_all_sections(self):
        result = scan(TEAM_NODES, TEAM_EDGES)
        html = visualize(result)
        html_lower = html.lower()
        self.assertIn('actions', html_lower)
        self.assertIn('clusters', html_lower)
        self.assertIn('layers', html_lower)

    def test_html_write_to_file(self):
        result = scan(TEAM_NODES, TEAM_EDGES)
        html = visualize(result)
        with tempfile.NamedTemporaryFile(mode='w', suffix='.html', delete=False) as f:
            f.write(html)
            path = f.name
        try:
            self.assertTrue(os.path.exists(path))
            self.assertGreater(os.path.getsize(path), 1000)
        finally:
            os.unlink(path)


class TestEdgeCases(unittest.TestCase):
    """Edge case handling."""

    def test_large_network(self):
        """50 nodes, ~100 edges — should complete in reasonable time."""
        import random
        random.seed(42)
        nodes = [f'node_{i}' for i in range(50)]
        edges = []
        for i in range(100):
            a = random.choice(nodes)
            b = random.choice(nodes)
            if a != b:
                edges.append((a, b))
        result = scan(nodes, edges)
        self.assertNotIn('error', result)
        self.assertIn('positions', result)

    def test_duplicate_edges(self):
        edges = [('A', 'B'), ('A', 'B'), ('B', 'C')]
        result = scan(['A', 'B', 'C'], edges)
        self.assertNotIn('error', result)

    def test_nodes_not_in_edges(self):
        """Extra nodes with no connections."""
        nodes = ['A', 'B', 'C', 'Loner']
        edges = [('A', 'B'), ('B', 'C')]
        result = scan(nodes, edges)
        self.assertNotIn('error', result)
        self.assertIn('Loner', result['isolates'])

    def test_result_is_json_serializable(self):
        result = scan(TEAM_NODES, TEAM_EDGES)
        # Should not raise
        json_str = json.dumps(result, default=str)
        self.assertGreater(len(json_str), 100)


if __name__ == '__main__':
    unittest.main()
