"""Tests for gump.knowledge — Knowledge Engine"""
import sys, os, json, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from gump.knowledge import KnowledgeEngine

class TestAbsorb(unittest.TestCase):
    def test_basic_absorb(self):
        e = KnowledgeEngine()
        e.absorb("The cat sat on the mat.")
        self.assertGreater(len(e.concepts), 0)

    def test_multiple_absorb(self):
        e = KnowledgeEngine()
        e.absorb("Cells contain mitochondria.")
        e.absorb("Mitochondria produce ATP.")
        self.assertIn('mitochondria', e.concepts)
        self.assertGreater(e.concepts['mitochondria']['count'], 1)

    def test_empty_absorb(self):
        e = KnowledgeEngine()
        e.absorb("")
        self.assertEqual(len(e.concepts), 0)

    def test_connections_formed(self):
        e = KnowledgeEngine()
        e.absorb("Python is a programming language used for data science.")
        self.assertGreater(len(e.edges), 0)

class TestRecall(unittest.TestCase):
    def test_basic_recall(self):
        e = KnowledgeEngine()
        e.absorb("The brain processes information through neurons.")
        e.absorb("Neurons communicate through synapses.")
        result = e.recall('neurons')
        self.assertTrue(result['found'])
        self.assertGreater(len(result['results']), 0)

    def test_recall_not_found(self):
        e = KnowledgeEngine()
        e.absorb("Hello world.")
        result = e.recall('quantum')
        self.assertFalse(result['found'])

    def test_recall_relevance(self):
        e = KnowledgeEngine()
        e.absorb("Dogs are loyal pets. Cats are independent pets. Fish swim in water.")
        result = e.recall('pets')
        # 'dogs' and 'cats' should be more relevant than 'fish'
        words = [r['concept'] for r in result['results']]
        self.assertTrue('dogs' in words or 'cats' in words)

class TestTensions(unittest.TestCase):
    def test_tensions_with_data(self):
        e = KnowledgeEngine()
        e.absorb("Physics studies forces and energy. Biology studies cells and life.")
        e.absorb("Chemistry studies atoms and molecules. Physics uses mathematics.")
        e.absorb("Biology requires chemistry. Chemistry is applied physics.")
        tensions = e.tensions()
        self.assertIsInstance(tensions, list)

    def test_tensions_too_little_data(self):
        e = KnowledgeEngine()
        e.absorb("Hello.")
        tensions = e.tensions()
        self.assertEqual(len(tensions), 0)

class TestClusters(unittest.TestCase):
    def test_clusters_exist(self):
        e = KnowledgeEngine()
        for _ in range(3):
            e.absorb("Python programming code function class object method variable.")
            e.absorb("Guitar music rhythm melody harmony chord song beat.")
        clusters = e.clusters()
        self.assertGreater(len(clusters), 0)

class TestVisualize(unittest.TestCase):
    def test_html_valid(self):
        e = KnowledgeEngine()
        e.absorb("The quick brown fox jumps over the lazy dog near the river bank.")
        e.absorb("A river flows through mountains and valleys toward the ocean.")
        e.absorb("Mountains are formed by tectonic plates pushing against each other.")
        html = e.visualize()
        self.assertIn('<html', html)
        self.assertIn('Knowledge Engine', html)

    def test_html_too_little(self):
        e = KnowledgeEngine()
        e.absorb("Hi.")
        html = e.visualize()
        self.assertIn('Not enough', html)

class TestStatus(unittest.TestCase):
    def test_status_fields(self):
        e = KnowledgeEngine()
        e.absorb("Testing the knowledge engine with some sample text.")
        s = e.status()
        self.assertIn('n_concepts', s)
        self.assertIn('n_connections', s)
        self.assertIn('top_concepts', s)

    def test_json_serializable(self):
        e = KnowledgeEngine()
        e.absorb("Test data for serialization.")
        json.dumps(e.status(), default=str)

if __name__ == '__main__':
    unittest.main()
