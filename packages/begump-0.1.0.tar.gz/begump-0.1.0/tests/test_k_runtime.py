"""
Tests for gump.k_runtime — verify all products route through K core
"""
import sys, os, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from gump.k_runtime import (
    tensions, place, energy, grok_detect, measure, interval_cost, is_protected
)


class TestRouting(unittest.TestCase):

    def test_k_core_active(self):
        """K core should be the active computation path."""
        self.assertTrue(is_protected(), "K core not active — running unprotected fallback")

    def test_tensions_through_runtime(self):
        t = tensions(5, [(0,1),(1,2),(2,3),(3,4)], top_k=5)
        self.assertIsInstance(t, list)
        self.assertGreater(len(t), 0)

    def test_place_through_runtime(self):
        import numpy as np
        pos = place(5, [(0,1),(1,2),(2,3),(3,4)], 100, 100)
        self.assertEqual(pos.shape, (5, 2))

    def test_energy_through_runtime(self):
        cost = energy(100)
        self.assertGreater(cost, 0)
        self.assertEqual(energy(100, 'reverse'), 0.0)

    def test_grok_through_runtime(self):
        train = [0.95] * 60 + [0.97] * 40
        test = [0.12] * 60 + [0.12 + i*0.02 for i in range(40)]
        grokked, epoch, jump = grok_detect(train, test)
        self.assertIsInstance(grokked, bool)

    def test_measure_through_runtime(self):
        m = measure([1, 2, 3, 4, 5, 6, 7, 8])
        self.assertIn('K', m)
        self.assertIn('R', m)
        self.assertIn('T', m)

    def test_interval_through_runtime(self):
        fifth = interval_cost(3, 2)
        self.assertAlmostEqual(fifth, 1.7918, places=3)


class TestProductsUseKRuntime(unittest.TestCase):
    """Verify each product actually imports from k_runtime."""

    def test_orgxray_uses_k_place(self):
        import gump.orgxray
        # The module should have imported spectral_place from k_runtime
        import inspect
        src = inspect.getsource(gump.orgxray)
        self.assertIn('k_runtime', src, "orgxray not using k_runtime")

    def test_learnengine_uses_k_place(self):
        import gump.learnengine
        import inspect
        src = inspect.getsource(gump.learnengine)
        self.assertIn('k_runtime', src, "learnengine not using k_runtime")

    def test_knowledge_uses_k_place(self):
        import gump.knowledge
        import inspect
        src = inspect.getsource(gump.knowledge)
        self.assertIn('k_runtime', src, "knowledge not using k_runtime")

    def test_foldwatch_app_uses_k_place(self):
        import gump.foldwatch_app
        import inspect
        src = inspect.getsource(gump.foldwatch_app)
        self.assertIn('k_runtime', src, "foldwatch_app not using k_runtime")

    def test_chipfast_app_uses_k_runtime(self):
        import gump.chipfast_app
        import inspect
        src = inspect.getsource(gump.chipfast_app)
        self.assertIn('k_runtime', src, "chipfast_app not using k_runtime")

    def test_aitrainer_uses_k_runtime(self):
        import gump.aitrainer
        import inspect
        src = inspect.getsource(gump.aitrainer)
        self.assertIn('k_runtime', src, "aitrainer not using k_runtime")

    def test_sensor_uses_k_runtime(self):
        import gump.sensor
        import inspect
        src = inspect.getsource(gump.sensor)
        self.assertIn('k_runtime', src, "sensor not using k_runtime")


if __name__ == '__main__':
    unittest.main()
