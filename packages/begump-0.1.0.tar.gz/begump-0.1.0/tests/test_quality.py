"""
QUALITY BENCHMARKS — Would a paying customer be satisfied?
=============================================================
Each test simulates a real customer scenario at the price point they're paying.
Not "does it crash." "Is the output worth $25,000/mo."

Run: cd gump-package && python tests/test_quality.py -v
"""
import sys, os, time, unittest
import numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from gump.orgxray import scan as org_scan, visualize as org_viz
from gump.learnengine import LearnEngine
from gump.foldwatch import analyze as fold_analyze
from gump.chipfast import design as chip_design
from gump.aitrainer import AITrainer
from gump.knowledge import KnowledgeEngine
from gump.sensor import UniversalSensor


# ═══════════════════════════════════════════════════════════════
# ORG X-RAY — $15/user/mo — a 200-person company
# Customer: VP of People at a mid-size tech company
# Expectation: actionable insights, not just pretty graphs
# ═══════════════════════════════════════════════════════════════

class TestOrgXRayQuality(unittest.TestCase):

    def _build_company(self):
        """Realistic 50-person company with known problems."""
        depts = {
            'exec': ['CEO', 'CTO', 'VP_Sales', 'VP_Ops', 'CFO'],
            'eng': [f'Eng_{i}' for i in range(15)],
            'sales': [f'Sales_{i}' for i in range(10)],
            'ops': [f'Ops_{i}' for i in range(8)],
            'finance': [f'Fin_{i}' for i in range(5)],
            'lonely': ['NewHire_1', 'NewHire_2', 'Contractor_1', 'Contractor_2',
                       'Remote_1', 'Remote_2', 'Intern_1'],
        }
        nodes = []
        for d in depts.values():
            nodes.extend(d)

        edges = []
        # Exec connections
        edges += [('CEO', 'CTO'), ('CEO', 'VP_Sales'), ('CEO', 'VP_Ops'), ('CEO', 'CFO')]
        # Eng hierarchy + collaboration
        edges += [('CTO', f'Eng_{i}') for i in range(3)]  # CTO knows leads
        edges += [(f'Eng_{i}', f'Eng_{i+1}') for i in range(14)]  # chain
        edges += [(f'Eng_{0}', f'Eng_{5}'), (f'Eng_{3}', f'Eng_{10}')]  # cross-team
        # Sales
        edges += [('VP_Sales', f'Sales_{i}') for i in range(3)]
        edges += [(f'Sales_{i}', f'Sales_{i+1}') for i in range(9)]
        # Ops
        edges += [('VP_Ops', f'Ops_{i}') for i in range(2)]
        edges += [(f'Ops_{i}', f'Ops_{i+1}') for i in range(7)]
        # Finance
        edges += [('CFO', f'Fin_{i}') for i in range(3)]
        edges += [(f'Fin_{i}', f'Fin_{i+1}') for i in range(4)]
        # ONE cross-dept bridge: Sales_2 knows Eng_7
        edges += [('Sales_2', 'Eng_7')]
        # Lonely people: NewHire_1 knows one person only
        edges += [('NewHire_1', 'Eng_14')]
        # The rest of lonely have NO connections (intentional problem)

        return nodes, edges

    def test_detects_all_known_problems(self):
        """The company has known problems. Does the tool find them ALL?"""
        nodes, edges = self._build_company()
        result = org_scan(nodes, edges)

        # Problem 1: 6 people with 0-1 connections
        self.assertGreaterEqual(len(result['isolates']), 5,
            f"Only found {len(result['isolates'])} isolates — company has 6+ disconnected people")

        # Problem 2: Clusters should detect eng vs sales as separate
        # (Cross-dept tensions exist but compete with within-dept chain gaps in ranking.
        # The RIGHT signal is cluster detection — separate departments = separate clusters.)
        clusters = result['clusters']
        # Eng and Sales should be in different clusters
        eng_cluster = None
        sales_cluster = None
        for ci, c in enumerate(clusters):
            if any('Eng' in m for m in c['members']):
                eng_cluster = ci
            if any('Sales' in m for m in c['members']):
                sales_cluster = ci
        self.assertIsNotNone(eng_cluster, "Eng not found in any cluster")
        self.assertIsNotNone(sales_cluster, "Sales not found in any cluster")
        if eng_cluster is not None and sales_cluster is not None:
            self.assertNotEqual(eng_cluster, sales_cluster,
                "Eng and Sales in same cluster — silo not detected")

        # Problem 3: Action plan should prioritize isolates
        actions = result['action_plan']
        isolate_actions = [a for a in actions if a['type'] == 'integrate_isolate']
        self.assertGreater(len(isolate_actions), 0,
            "Action plan doesn't mention isolates — the most urgent problem")

    def test_health_score_makes_sense(self):
        """Health score should be LOW for this broken company."""
        nodes, edges = self._build_company()
        result = org_scan(nodes, edges)
        # With 6+ isolates and only 1 cross-dept bridge, health should be poor
        self.assertLess(result['health_score'], 70,
            f"Health score {result['health_score']} too high for a company with 6 isolates and 1 cross-dept bridge")

    def test_viz_is_shareable(self):
        """VP needs to share this with the CEO. HTML must be self-contained and useful."""
        nodes, edges = self._build_company()
        result = org_scan(nodes, edges)
        html = org_viz(result)
        # Must contain all key insights (case-insensitive — HTML may use Title Case)
        html_lower = html.lower()
        self.assertIn('actions', html_lower)
        self.assertIn('clusters', html_lower)
        # Must be large enough to be useful (not a blank page)
        self.assertGreater(len(html), 10000,
            f"HTML report only {len(html)} bytes — too small to be useful")

    def test_50_person_speed(self):
        """50-person company should analyze in under 1 second."""
        nodes, edges = self._build_company()
        start = time.time()
        result = org_scan(nodes, edges)
        elapsed = time.time() - start
        self.assertLess(elapsed, 1.0,
            f"50-person analysis took {elapsed:.2f}s — customer expects instant")


# ═══════════════════════════════════════════════════════════════
# LEARN ENGINE — $29/user/mo — a teacher with 1 student over 30 sessions
# Customer: college instructor tracking student progress
# Expectation: accurate grokking detection, useful recommendations
# ═══════════════════════════════════════════════════════════════

class TestLearnEngineQuality(unittest.TestCase):

    def _simulate_student(self):
        """Simulate a realistic student learning web development."""
        topics = ['html', 'css', 'javascript', 'dom', 'react', 'node',
                  'sql', 'api', 'auth', 'deploy']
        prereqs = [
            ('html', 'css'), ('html', 'dom'), ('css', 'react'),
            ('javascript', 'dom'), ('javascript', 'node'), ('javascript', 'react'),
            ('dom', 'react'), ('node', 'api'), ('sql', 'api'),
            ('api', 'auth'), ('react', 'deploy'), ('api', 'deploy'),
        ]
        e = LearnEngine(topics, prereqs)

        # Student is good at HTML/CSS, struggles with JS, hasn't touched advanced topics
        for _ in range(8): e.answer('html', correct=True)
        for _ in range(7): e.answer('css', correct=True)
        for _ in range(3): e.answer('javascript', correct=True)
        for _ in range(5): e.answer('javascript', correct=False)
        e.answer('dom', correct=False)
        e.answer('dom', correct=False)
        e.answer('sql', correct=True)
        e.answer('sql', correct=True)

        return e

    def test_mastery_detection_correct(self):
        """HTML and CSS should be mastered. JS should NOT be."""
        e = self._simulate_student()
        self.assertTrue(e.states['html'].grokked, "HTML should be mastered after 8/8")
        self.assertTrue(e.states['css'].grokked, "CSS should be mastered after 7/7")
        self.assertFalse(e.states['javascript'].grokked, "JS should NOT be mastered at 3/8")

    def test_recommendations_are_useful(self):
        """Should recommend JS (struggling prerequisite), not React (too advanced)."""
        e = self._simulate_student()
        recs = e.next(3)
        rec_topics = [r['topic'] for r in recs]
        # JS must be recommended (it's the bottleneck)
        self.assertIn('javascript', rec_topics,
            f"Recommended {rec_topics} but missed JS — the clear bottleneck")
        # React should NOT be recommended (prerequisites not met)
        self.assertNotIn('react', rec_topics,
            "Recommended React but student hasn't mastered JS or DOM — irresponsible")

    def test_gaps_identify_bottleneck(self):
        """JS gap should show it blocks node, react, dom."""
        e = self._simulate_student()
        gaps = e.gaps()
        js_gap = [g for g in gaps if g['topic'] == 'javascript']
        self.assertGreater(len(js_gap), 0, "JS not identified as a gap")
        # JS blocks multiple downstream topics
        self.assertGreater(len(js_gap[0]['blocking']), 0,
            "JS gap doesn't show what it blocks")

    def test_completion_accurate(self):
        """2 mastered out of 10 = 20%."""
        e = self._simulate_student()
        s = e.status()
        self.assertEqual(s['completion'], 20.0,
            f"Completion {s['completion']}% but only HTML+CSS mastered = 20%")


# ═══════════════════════════════════════════════════════════════
# FOLD WATCH — $8,500/mo — real proteins from UniProt
# Customer: biotech PI screening candidates
# Expectation: correct biology, no embarrassing errors
# ═══════════════════════════════════════════════════════════════

class TestFoldWatchQuality(unittest.TestCase):

    def test_insulin_makes_biological_sense(self):
        """Insulin B chain: known structure. Helix + disulfide bonds."""
        r = fold_analyze('FVNQHLCGSHLVEALYLVCGERGFFYTPKT')
        # Must have disulfide candidates (C7, C19)
        self.assertGreater(len(r['disulfide_candidates']), 0, "Missed insulin disulfide bonds")
        # Must have some secondary structure (not all coil)
        self.assertLess(r['coil_pct'], 80, "Insulin is not 80%+ coil — that's wrong")
        # Net charge should be slightly positive (has Arg, His, Glu)
        # Actually insulin B has: H(+0.1), R(+1), E(-1), net ≈ +0.1
        self.assertIsInstance(r['net_charge'], float)

    def test_collagen_is_not_helical(self):
        """Collagen-like sequence (GPP repeats) should NOT be alpha-helical.
        Collagen forms a TRIPLE helix, not alpha helix. Pro prevents alpha helix."""
        r = fold_analyze('GPPGPPGPPGPPGPPGPPGPP')
        self.assertLess(r['helix_pct'], 10,
            f"GPP repeat called {r['helix_pct']}% helix — collagen is NOT alpha-helical")

    def test_alanine_rich_is_helical(self):
        """Polyalanine is the canonical helix-forming sequence."""
        r = fold_analyze('AAAAAAAAAAAAAAAAAAAAAAAAA')
        self.assertGreater(r['helix_pct'], 50,
            f"Polyalanine only {r['helix_pct']}% helix — it's THE helix-forming residue")

    def test_alternating_hydrophobic_is_sheet(self):
        """Alternating Val-Gly-Val-Gly is beta-sheet territory."""
        r = fold_analyze('VGVGVGVGVGVGVGVGVGVGVG')
        self.assertGreater(r['sheet_pct'], 30,
            f"Alternating VG only {r['sheet_pct']}% sheet — this is classic beta pattern")

    def test_amyloid_risk_higher_than_insulin(self):
        """Amyloid-beta should be higher risk than insulin."""
        r_amyloid = fold_analyze('DAEFRHDSGYEVHHQKLVFFAEDVGSNKGAIIGLMVGGVVIA')
        r_insulin = fold_analyze('FVNQHLCGSHLVEALYLVCGERGFFYTPKT')
        risk_order = {'low': 0, 'medium': 1, 'high': 2}
        self.assertGreaterEqual(risk_order[r_amyloid['misfolding_risk']],
                                risk_order[r_insulin['misfolding_risk']],
            f"Amyloid ({r_amyloid['misfolding_risk']}) should be >= insulin ({r_insulin['misfolding_risk']}) risk")

    def test_charge_matches_biology(self):
        """Lysozyme-like: lots of K,R = positive. Pepsin-like: lots of D,E = negative."""
        pos_seq = 'KKRRKKKRRKKKRRRKKKKR'  # heavily positive
        neg_seq = 'DDEDDDDEDDDEDDDDEDDD'  # heavily negative
        r_pos = fold_analyze(pos_seq)
        r_neg = fold_analyze(neg_seq)
        self.assertGreater(r_pos['net_charge'], 10, f"KKRR... charge only {r_pos['net_charge']}")
        self.assertLess(r_neg['net_charge'], -10, f"DDED... charge only {r_neg['net_charge']}")

    def test_speed_at_scale(self):
        """500-residue protein (typical enzyme) should still be fast."""
        seq = 'MVLSPADKTNVKAAWGKVGAHAGEYGAEALERMFLSFPTTKTYFPHFDLSH' * 10  # 500 residues
        start = time.time()
        r = fold_analyze(seq)
        elapsed = time.time() - start
        self.assertLess(elapsed, 2.0,
            f"500-residue analysis took {elapsed:.1f}s — customer expects <2s")
        self.assertNotIn('error', r)


# ═══════════════════════════════════════════════════════════════
# CHIP FAST — $25,000/mo — benchmark circuits
# Customer: chip design engineer comparing to Cadence
# Expectation: real wire length reduction, correct legalization
# ═══════════════════════════════════════════════════════════════

class TestChipFastQuality(unittest.TestCase):

    def _random_circuit(self, n_gates, avg_fanout=3, seed=42):
        """Generate a realistic random circuit."""
        np.random.seed(seed)
        gates = [f'g{i}' for i in range(n_gates)]
        wires = set()
        for i in range(n_gates):
            for _ in range(avg_fanout):
                j = np.random.randint(0, n_gates)
                if i != j:
                    wires.add((min(i, j), max(i, j)))
        return gates, list(wires)

    def test_wirelength_vs_random_100(self):
        """100 gates: must beat random by >15%."""
        gates, wires = self._random_circuit(100)
        result = chip_design(gates, wires)
        np.random.seed(99)
        rand_pos = np.random.rand(100, 2) * float(result['positions'].max())
        rand_wl = sum(abs(rand_pos[a][0]-rand_pos[b][0])+abs(rand_pos[a][1]-rand_pos[b][1])
                      for a, b in wires)
        improvement = (rand_wl - result['wire_length']) / rand_wl * 100
        self.assertGreater(improvement, 15,
            f"Only {improvement:.1f}% improvement at 100 gates — not worth $25K/mo")

    def test_wirelength_vs_random_500(self):
        """500 gates: must beat random by >20%."""
        gates, wires = self._random_circuit(500)
        result = chip_design(gates, wires)
        np.random.seed(99)
        rand_pos = np.random.rand(500, 2) * float(result['positions'].max())
        rand_wl = sum(abs(rand_pos[a][0]-rand_pos[b][0])+abs(rand_pos[a][1]-rand_pos[b][1])
                      for a, b in wires)
        improvement = (rand_wl - result['wire_length']) / rand_wl * 100
        self.assertGreater(improvement, 20,
            f"Only {improvement:.1f}% improvement at 500 gates — not worth $25K/mo")

    def test_wirelength_vs_random_2000(self):
        """2000 gates: must beat random AND complete in <5s."""
        gates, wires = self._random_circuit(2000)
        start = time.time()
        result = chip_design(gates, wires)
        elapsed = time.time() - start
        self.assertLess(elapsed, 5.0, f"2000 gates took {elapsed:.1f}s")

        np.random.seed(99)
        rand_pos = np.random.rand(2000, 2) * float(result['positions'].max())
        rand_wl = sum(abs(rand_pos[a][0]-rand_pos[b][0])+abs(rand_pos[a][1]-rand_pos[b][1])
                      for a, b in wires)
        improvement = (rand_wl - result['wire_length']) / rand_wl * 100
        self.assertGreater(improvement, 20,
            f"Only {improvement:.1f}% improvement at 2000 gates")

    def test_no_gate_overlap(self):
        """At $25K/mo, overlapping gates would be lawsuit-worthy."""
        gates, wires = self._random_circuit(500)
        result = chip_design(gates, wires)
        pos = result['positions']
        # Round to gate-width precision
        seen = set()
        overlaps = 0
        for i in range(len(gates)):
            key = (round(pos[i][0], 1), round(pos[i][1], 1))
            if key in seen:
                overlaps += 1
            seen.add(key)
        self.assertEqual(overlaps, 0,
            f"{overlaps} gate overlaps in 500-gate design — unacceptable at $25K/mo")

    def test_improvement_scales_with_size(self):
        """Bigger circuits should show equal or better improvement (not degradation)."""
        improvements = []
        for n in [50, 200, 500]:
            gates, wires = self._random_circuit(n)
            result = chip_design(gates, wires)
            np.random.seed(99)
            rand_pos = np.random.rand(n, 2) * float(result['positions'].max())
            rand_wl = sum(abs(rand_pos[a][0]-rand_pos[b][0])+abs(rand_pos[a][1]-rand_pos[b][1])
                          for a, b in wires)
            imp = (rand_wl - result['wire_length']) / rand_wl * 100
            improvements.append((n, imp))

        # Should not dramatically degrade at scale
        _, imp_50 = improvements[0]
        _, imp_500 = improvements[2]
        self.assertGreater(imp_500, imp_50 * 0.5,
            f"Quality degrades at scale: {imp_50:.1f}% at 50 gates → {imp_500:.1f}% at 500")


# ═══════════════════════════════════════════════════════════════
# AI TRAINER — $2,500/mo — simulated training runs
# Customer: ML engineer watching a transformer train
# Expectation: correct stop signal, no false alarms
# ═══════════════════════════════════════════════════════════════

class TestAITrainerQuality(unittest.TestCase):

    def test_classic_grok_timing(self):
        """Must detect grokking within 30 epochs of it happening."""
        t = AITrainer('transformer')
        # Memorize for 200 epochs
        for _ in range(200):
            t.log(train_acc=0.96, test_acc=0.11, n_params=50000)
        # Grok starts at epoch 200
        grok_start = 200
        for i in range(50):
            test = 0.11 + (i / 50) * 0.82
            t.log(train_acc=0.97, test_acc=test, n_params=50000)

        self.assertTrue(t.grokked, "Missed grokking entirely")
        detection_delay = t.watcher.grok_epoch - grok_start
        self.assertLess(detection_delay, 30,
            f"Detected grokking {detection_delay} epochs late — customer loses money every late epoch")

    def test_no_false_alarm_slow_learner(self):
        """Slow but steady improvement should NOT trigger stop."""
        t = AITrainer('slow_model')
        for i in range(500):
            acc = 0.1 + (i / 500) * 0.7
            t.log(train_acc=acc + 0.03, test_acc=acc, n_params=10000)
        self.assertFalse(t.grokked,
            "False grokking alarm on slow learner — would kill a good training run")
        self.assertFalse(t.should_stop(),
            "Told customer to stop a successfully training model")

    def test_detects_overfitting(self):
        """Train acc high, test acc dropping = overfitting. Must flag it."""
        t = AITrainer('overfit_model')
        for i in range(300):
            train = min(0.99, 0.5 + i * 0.003)
            test = 0.5 + min(i, 100) * 0.003 - max(0, i - 100) * 0.002
            t.log(train_acc=train, test_acc=test, n_params=50000)
        # Test acc should be declining at the end
        rec = t.recommendation()
        # Should recommend something — plateau or change strategy
        self.assertIn(rec['action'], ['CONTINUE', 'PLATEAU DETECTED', 'CHANGE STRATEGY'],
            f"Got '{rec['action']}' — should flag the declining test acc")

    def test_savings_calculation_realistic(self):
        """If grokking at epoch 100 of planned 1000, savings should be ~67%."""
        t = AITrainer('test', planned_epochs=1000)
        for _ in range(60):
            t.log(train_acc=0.95, test_acc=0.12, n_params=10000)
        for i in range(40):
            t.log(train_acc=0.97, test_acc=0.12 + i * 0.02, n_params=10000)
        self.assertTrue(t.grokked)
        s = t.status()
        self.assertGreater(s['savings_pct'], 30,
            f"Savings only {s['savings_pct']}% — should be significant when grokking at epoch ~80 of 1000")


# ═══════════════════════════════════════════════════════════════
# KNOWLEDGE ENGINE — $59/user/mo — real text corpus
# Customer: research analyst extracting insights from papers
# Expectation: meaningful graph, useful recall, real gap detection
# ═══════════════════════════════════════════════════════════════

class TestKnowledgeQuality(unittest.TestCase):

    def _build_corpus(self):
        """5 paragraphs of neuroscience — realistic research input."""
        e = KnowledgeEngine()
        e.absorb("The hippocampus is essential for the formation of new declarative memories. "
                  "Damage to the hippocampus results in anterograde amnesia, the inability to "
                  "form new memories while old memories remain intact.")
        e.absorb("Long-term potentiation (LTP) is the persistent strengthening of synapses "
                  "based on recent patterns of activity. LTP is widely considered one of the "
                  "major cellular mechanisms that underlies learning and memory.")
        e.absorb("Dopamine neurons in the ventral tegmental area project to the prefrontal "
                  "cortex and nucleus accumbens. This mesolimbic pathway is critical for "
                  "reward processing and motivation.")
        e.absorb("The cerebellum coordinates voluntary movements, balance, and motor learning. "
                  "Recent research suggests the cerebellum also plays a role in cognitive "
                  "functions including attention and language processing.")
        e.absorb("Neuroplasticity refers to the brain's ability to reorganize itself by "
                  "forming new neural connections throughout life. This allows neurons to "
                  "compensate for injury and adjust to new situations.")
        return e

    def test_extracts_key_concepts(self):
        """Must find: hippocampus, memory, dopamine, cerebellum, neuroplasticity."""
        e = self._build_corpus()
        concepts = set(e.concepts.keys())
        expected = {'hippocampus', 'memory', 'dopamine', 'cerebellum'}
        found = expected & concepts
        self.assertEqual(found, expected,
            f"Missing concepts: {expected - found}")

    def test_recall_returns_relevant(self):
        """Query 'memory' should return hippocampus, LTP, learning — not cerebellum."""
        e = self._build_corpus()
        result = e.recall('memory')
        top_5 = [r['concept'] for r in result['results'][:5]]
        # Memory-related should be top
        memory_related = {'hippocampus', 'memory', 'learning', 'memories', 'amnesia', 'ltp'}
        found_relevant = len(set(top_5) & memory_related)
        self.assertGreater(found_relevant, 1,
            f"Query 'memory' returned {top_5} — only {found_relevant} are relevant")

    def test_clusters_make_sense(self):
        """Should separate memory/hippocampus from movement/cerebellum."""
        e = self._build_corpus()
        clusters = e.clusters()
        self.assertGreaterEqual(len(clusters), 2,
            f"Only {len(clusters)} cluster — should separate at least 2 distinct topics")

    def test_handles_50_documents(self):
        """50 paragraphs should process in <2 seconds."""
        e = KnowledgeEngine()
        para = ("The brain processes information through billions of interconnected neurons. "
                "Each neuron communicates through electrochemical signals across synapses. ")
        start = time.time()
        for i in range(50):
            e.absorb(para + f"Study {i} found additional evidence for neural coupling.")
        elapsed = time.time() - start
        self.assertLess(elapsed, 2.0,
            f"50 documents took {elapsed:.1f}s — customer expects near-instant")
        self.assertGreater(e.status()['n_concepts'], 10)


# ═══════════════════════════════════════════════════════════════
# UNIVERSAL SENSOR — $2,999/mo — real-world signals
# Customer: SRE monitoring production systems
# Expectation: meaningful regime detection, useful anomaly alerts
# ═══════════════════════════════════════════════════════════════

class TestSensorQuality(unittest.TestCase):

    def test_heartbeat_coherent(self):
        """Simulated healthy heartbeat should be coherent, not volatile."""
        s = UniversalSensor('ecg')
        t = np.linspace(0, 30, 1000)
        # Simplified ECG: periodic with slight HRV
        ecg = np.sin(2 * np.pi * 1.2 * t) * (1 + 0.05 * np.sin(2 * np.pi * 0.15 * t))
        s.feed(ecg.tolist())
        d = s.diagnose()
        self.assertIn(d['regime'], ['coherent', 'locked'],
            f"Healthy heartbeat classified as '{d['regime']}' — should be coherent")
        self.assertGreater(d['K'], 0.5,
            f"Healthy heartbeat K={d['K']} — should show strong coupling")

    def test_server_crash_detected(self):
        """Normal metrics → sudden spike → should detect anomaly."""
        s = UniversalSensor('cpu_load')
        np.random.seed(42)
        # Normal: ~30% CPU with small noise
        normal = np.random.randn(200) * 2 + 30
        # Crash: spike to 100%
        crash = np.array([98, 99, 100, 99, 97])
        # Recovery
        recovery = np.random.randn(100) * 2 + 30
        s.feed(np.concatenate([normal, crash, recovery]).tolist())
        d = s.diagnose()
        self.assertGreater(len(d['anomalies']), 0,
            "Missed a CPU spike from 30% to 100% — SRE would be furious")

    def test_stock_trend_detected(self):
        """Trending stock should show 'rising' trend."""
        s = UniversalSensor('stock')
        np.random.seed(42)
        # Uptrending stock: drift + noise
        prices = 100 + np.cumsum(np.random.randn(200) * 0.5 + 0.3)
        s.feed(prices.tolist())
        d = s.diagnose()
        self.assertEqual(d['trend'], 'rising',
            f"Uptrending stock detected as '{d['trend']}' — should be rising")

    def test_flat_signal_stable(self):
        """Constant signal should be stable, not flagged as anomalous."""
        s = UniversalSensor('temp')
        s.feed([72.0] * 200)
        d = s.diagnose()
        self.assertEqual(d['T'], 0.0, "Constant signal has tension — should be zero")
        self.assertEqual(len(d['anomalies']), 0,
            "Constant signal has anomalies — should have none")

    def test_distinguishes_sine_from_noise(self):
        """At $2,999/mo, must correctly distinguish signal from noise."""
        s1 = UniversalSensor('signal')
        s1.feed(np.sin(np.linspace(0, 20 * np.pi, 500)).tolist())
        d1 = s1.diagnose()

        np.random.seed(42)
        s2 = UniversalSensor('noise')
        s2.feed(np.random.randn(500).tolist())
        d2 = s2.diagnose()

        self.assertGreater(d1['K'], d2['K'],
            f"Signal K={d1['K']}, Noise K={d2['K']} — signal should have higher coupling")

    def test_diagnosis_has_actionable_text(self):
        """Diagnosis must include interpretation AND recommendation — not just numbers."""
        s = UniversalSensor('test')
        s.feed(np.sin(np.linspace(0, 10, 100)).tolist())
        d = s.diagnose()
        self.assertGreater(len(d['interpretation']), 2,
            "Diagnosis has fewer than 3 interpretation lines — not useful")
        self.assertGreater(len(d['recommendation']), 10,
            "Recommendation is empty or too short — customer needs guidance")


if __name__ == '__main__':
    unittest.main(verbosity=2)
