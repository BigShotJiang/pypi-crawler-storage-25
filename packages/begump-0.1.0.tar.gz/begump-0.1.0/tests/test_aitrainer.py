"""
Tests for gump.aitrainer — AI Trainer product
Run: cd gump-package && python tests/test_aitrainer.py
"""
import sys, os, json, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from gump.aitrainer import AITrainer


class TestBasics(unittest.TestCase):

    def test_create(self):
        t = AITrainer('test_model')
        self.assertEqual(t.model_name, 'test_model')
        self.assertEqual(t.epoch, 0)

    def test_log_epoch(self):
        t = AITrainer()
        t.log(train_acc=0.5, test_acc=0.3, loss=1.5)
        self.assertEqual(t.epoch, 1)

    def test_phase_learning(self):
        t = AITrainer()
        for _ in range(5):
            t.log(train_acc=0.5, test_acc=0.3)
        self.assertEqual(t.phase, 'learning')

    def test_phase_memorizing(self):
        t = AITrainer()
        for _ in range(30):
            t.log(train_acc=0.95, test_acc=0.15)
        self.assertEqual(t.phase, 'memorizing')

    def test_grokking_simulation(self):
        """Simulate a full grokking trajectory."""
        t = AITrainer()
        # Phase 1: memorize (train high, test low)
        for _ in range(50):
            t.log(train_acc=0.95, test_acc=0.12, n_params=1000)
        self.assertTrue(t.watcher.memorized)

        # Phase 2: grok (test suddenly jumps)
        for i in range(40):
            test = 0.12 + (i / 40) * 0.8
            t.log(train_acc=0.97, test_acc=test, n_params=1000)

        self.assertTrue(t.grokked)

    def test_should_stop_after_grok(self):
        t = AITrainer()
        for _ in range(50):
            t.log(train_acc=0.95, test_acc=0.12)
        for i in range(40):
            t.log(train_acc=0.97, test_acc=0.12 + i * 0.02)
        self.assertTrue(t.should_stop())

    def test_plateau_detection(self):
        t = AITrainer()
        for _ in range(200):
            t.log(train_acc=0.6, test_acc=0.55)
        self.assertGreater(t._plateau_count, 50)

    def test_best_tracking(self):
        t = AITrainer()
        t.log(train_acc=0.5, test_acc=0.3)
        t.log(train_acc=0.7, test_acc=0.5)
        t.log(train_acc=0.8, test_acc=0.4)
        self.assertAlmostEqual(t._best_test_acc, 0.5)
        self.assertEqual(t._best_epoch, 1)


class TestRecommendation(unittest.TestCase):

    def test_learning_recommendation(self):
        t = AITrainer()
        t.log(train_acc=0.5, test_acc=0.3)
        rec = t.recommendation()
        self.assertEqual(rec['action'], 'CONTINUE')

    def test_grokked_recommendation(self):
        t = AITrainer()
        for _ in range(50):
            t.log(train_acc=0.95, test_acc=0.12)
        for i in range(40):
            t.log(train_acc=0.97, test_acc=0.12 + i * 0.02)
        rec = t.recommendation()
        self.assertIn('STOP', rec['action'])
        self.assertIn('savings', rec)

    def test_plateau_recommendation(self):
        t = AITrainer()
        for _ in range(200):
            t.log(train_acc=0.6, test_acc=0.55)
        rec = t.recommendation()
        self.assertIn('PLATEAU', rec['action'])
        self.assertIn('suggestions', rec)


class TestStatus(unittest.TestCase):

    def test_status_complete(self):
        t = AITrainer('my_model')
        for _ in range(10):
            t.log(train_acc=0.5, test_acc=0.3, loss=1.0)
        s = t.status()
        self.assertEqual(s['model_name'], 'my_model')
        self.assertEqual(s['epoch'], 10)
        self.assertIn('recommendation', s)

    def test_status_json_serializable(self):
        t = AITrainer()
        for _ in range(10):
            t.log(train_acc=0.5, test_acc=0.3)
        s = t.status()
        json.dumps(s, default=str)  # should not raise


class TestVisualize(unittest.TestCase):

    def test_html_valid(self):
        t = AITrainer('test')
        for _ in range(30):
            t.log(train_acc=0.5 + _ * 0.01, test_acc=0.3 + _ * 0.005, loss=2.0 - _ * 0.05)
        html = t.visualize()
        self.assertIn('<html', html)
        self.assertIn('AI Trainer', html)
        self.assertIn('<canvas', html)

    def test_html_has_sections(self):
        t = AITrainer()
        for _ in range(10):
            t.log(train_acc=0.5, test_acc=0.3)
        html = t.visualize()
        self.assertIn('Recommendation', html)
        self.assertIn('Epoch', html)
        self.assertIn('Train acc', html)

    def test_html_shows_phase(self):
        t = AITrainer()
        for _ in range(10):
            t.log(train_acc=0.5, test_acc=0.3)
        html = t.visualize()
        self.assertIn('LEARNING', html)

    def test_html_grokked_shows_marker(self):
        t = AITrainer()
        for _ in range(50):
            t.log(train_acc=0.95, test_acc=0.12)
        for i in range(40):
            t.log(train_acc=0.97, test_acc=0.12 + i * 0.02)
        html = t.visualize()
        self.assertIn('GENERALIZED', html)
        self.assertIn('Savings', html)


class TestEdgeCases(unittest.TestCase):

    def test_single_epoch(self):
        t = AITrainer()
        t.log(train_acc=0.1, test_acc=0.1)
        self.assertIsNotNone(t.status())
        html = t.visualize()
        self.assertIn('<html', html)

    def test_zero_accuracy(self):
        t = AITrainer()
        t.log(train_acc=0.0, test_acc=0.0)
        self.assertIsNotNone(t.recommendation())

    def test_perfect_accuracy(self):
        t = AITrainer()
        for _ in range(10):
            t.log(train_acc=1.0, test_acc=1.0)
        self.assertIsNotNone(t.status())

    def test_with_lr_and_batch(self):
        t = AITrainer()
        t.log(train_acc=0.5, test_acc=0.3, lr=0.001, batch_size=32)
        self.assertEqual(len(t.learning_rates), 1)
        self.assertEqual(len(t.batch_sizes), 1)


if __name__ == '__main__':
    unittest.main()
