"""
Tests for gump.learnengine — Learn Engine
Run: cd gump-package && python -m pytest tests/test_learnengine.py -v
  or: cd gump-package && python tests/test_learnengine.py
"""
import sys
import os
import json
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from gump.learnengine import LearnEngine


MATH_TOPICS = ['algebra', 'trig', 'calculus', 'stats', 'linear_algebra', 'diff_eq']
MATH_PREREQS = [
    ('algebra', 'calculus'), ('trig', 'calculus'),
    ('algebra', 'stats'), ('algebra', 'linear_algebra'),
    ('calculus', 'diff_eq'), ('linear_algebra', 'diff_eq'),
]


class TestBasics(unittest.TestCase):

    def test_create_engine(self):
        e = LearnEngine(MATH_TOPICS, MATH_PREREQS)
        self.assertEqual(e.n, 6)

    def test_initial_status(self):
        e = LearnEngine(MATH_TOPICS, MATH_PREREQS)
        s = e.status()
        self.assertEqual(s['total_topics'], 6)
        self.assertEqual(s['mastered'], 0)
        self.assertEqual(s['attempted'], 0)
        self.assertEqual(s['completion'], 0)

    def test_answer_correct(self):
        e = LearnEngine(MATH_TOPICS, MATH_PREREQS)
        e.answer('algebra', correct=True)
        s = e.states['algebra']
        self.assertEqual(s.attempts, 1)
        self.assertEqual(s.correct, 1)
        self.assertEqual(s.streak, 1)

    def test_answer_incorrect(self):
        e = LearnEngine(MATH_TOPICS, MATH_PREREQS)
        e.answer('algebra', correct=True)
        e.answer('algebra', correct=False)
        s = e.states['algebra']
        self.assertEqual(s.streak, 0)
        self.assertEqual(s.best_streak, 1)

    def test_answer_invalid_topic(self):
        e = LearnEngine(MATH_TOPICS, MATH_PREREQS)
        e.answer('quantum_physics', correct=True)  # doesn't exist, should not crash

    def test_grokking_detection(self):
        e = LearnEngine(MATH_TOPICS, MATH_PREREQS)
        # Answer algebra correctly many times
        for _ in range(10):
            e.answer('algebra', correct=True)
        self.assertTrue(e.states['algebra'].grokked)
        self.assertEqual(e.states['algebra'].phase, 'mastered')

    def test_no_grok_without_enough_attempts(self):
        e = LearnEngine(MATH_TOPICS, MATH_PREREQS)
        for _ in range(2):
            e.answer('algebra', correct=True)
        self.assertFalse(e.states['algebra'].grokked)

    def test_no_grok_with_errors(self):
        e = LearnEngine(MATH_TOPICS, MATH_PREREQS)
        for _ in range(3):
            e.answer('algebra', correct=True)
        e.answer('algebra', correct=False)  # breaks streak
        for _ in range(3):
            e.answer('algebra', correct=True)
        # Streak is only 3, need 5
        self.assertFalse(e.states['algebra'].grokked)


class TestRecommendations(unittest.TestCase):

    def test_first_recommendation(self):
        e = LearnEngine(MATH_TOPICS, MATH_PREREQS)
        rec = e.next()
        self.assertIsNotNone(rec)
        self.assertIn('topic', rec)
        # Should recommend algebra first (root, no prereqs)
        self.assertEqual(rec['topic'], 'algebra')

    def test_recommend_after_mastering_prereq(self):
        e = LearnEngine(MATH_TOPICS, MATH_PREREQS)
        # Master algebra
        for _ in range(10):
            e.answer('algebra', correct=True)
        rec = e.next()
        # Should now recommend something that depends on algebra
        possible = ['trig', 'stats', 'linear_algebra', 'calculus']
        self.assertIn(rec['topic'], possible)

    def test_recommend_prereq_when_struggling(self):
        e = LearnEngine(MATH_TOPICS, MATH_PREREQS)
        # Struggle with calculus without mastering algebra
        for _ in range(5):
            e.answer('calculus', correct=False)
        rec = e.next()
        # Should recommend algebra (prerequisite for calculus)
        self.assertEqual(rec['topic'], 'algebra')

    def test_multiple_recommendations(self):
        e = LearnEngine(MATH_TOPICS, MATH_PREREQS)
        recs = e.next(3)
        self.assertIsInstance(recs, list)
        self.assertLessEqual(len(recs), 3)
        # All unique
        names = [r['topic'] for r in recs]
        self.assertEqual(len(names), len(set(names)))


class TestGaps(unittest.TestCase):

    def test_no_gaps_initially(self):
        e = LearnEngine(MATH_TOPICS, MATH_PREREQS)
        self.assertEqual(len(e.gaps()), 0)

    def test_gap_after_wrong_answers(self):
        e = LearnEngine(MATH_TOPICS, MATH_PREREQS)
        e.answer('calculus', correct=False)
        e.answer('calculus', correct=False)
        gaps = e.gaps()
        self.assertGreater(len(gaps), 0)
        self.assertEqual(gaps[0]['topic'], 'calculus')

    def test_gap_shows_blocking(self):
        e = LearnEngine(MATH_TOPICS, MATH_PREREQS)
        e.answer('algebra', correct=False)
        gaps = e.gaps()
        # algebra blocks: calculus, stats, linear_algebra
        algebra_gap = [g for g in gaps if g['topic'] == 'algebra'][0]
        self.assertGreater(len(algebra_gap['blocking']), 0)

    def test_no_gap_after_mastery(self):
        e = LearnEngine(MATH_TOPICS, MATH_PREREQS)
        for _ in range(10):
            e.answer('algebra', correct=True)
        gaps = e.gaps()
        algebra_gaps = [g for g in gaps if g['topic'] == 'algebra']
        self.assertEqual(len(algebra_gaps), 0)


class TestTensions(unittest.TestCase):

    def test_tensions_exist(self):
        e = LearnEngine(MATH_TOPICS, MATH_PREREQS)
        tensions = e.tensions()
        # Should find some spectral tensions
        self.assertIsInstance(tensions, list)

    def test_tension_has_fields(self):
        e = LearnEngine(MATH_TOPICS, MATH_PREREQS)
        tensions = e.tensions()
        if tensions:
            t = tensions[0]
            self.assertIn('topic_a', t)
            self.assertIn('topic_b', t)
            self.assertIn('spectral_tension', t)
            self.assertIn('insight', t)


class TestVisualize(unittest.TestCase):

    def test_html_valid(self):
        e = LearnEngine(MATH_TOPICS, MATH_PREREQS)
        for _ in range(6):
            e.answer('algebra', correct=True)
        e.answer('calculus', correct=False)
        html = e.visualize()
        self.assertIn('<html', html)
        self.assertIn('<canvas', html)
        self.assertIn('Learn Engine', html)

    def test_html_contains_topics(self):
        e = LearnEngine(MATH_TOPICS, MATH_PREREQS)
        html = e.visualize()
        for topic in MATH_TOPICS:
            self.assertIn(topic, html)

    def test_html_has_sections(self):
        e = LearnEngine(MATH_TOPICS, MATH_PREREQS)
        html = e.visualize()
        self.assertIn('STUDY NEXT', html)
        self.assertIn('KNOWLEDGE GAPS', html)
        self.assertIn('ALL TOPICS', html)


class TestStatus(unittest.TestCase):

    def test_status_json_serializable(self):
        e = LearnEngine(MATH_TOPICS, MATH_PREREQS)
        for _ in range(10):
            e.answer('algebra', correct=True)
        e.answer('trig', correct=False)
        s = e.status()
        json_str = json.dumps(s, default=str)
        self.assertGreater(len(json_str), 100)

    def test_completion_percentage(self):
        e = LearnEngine(MATH_TOPICS, MATH_PREREQS)
        # Master 3 of 6 topics
        for topic in ['algebra', 'trig', 'stats']:
            for _ in range(10):
                e.answer(topic, correct=True)
        s = e.status()
        self.assertEqual(s['completion'], 50.0)


class TestEdgeCases(unittest.TestCase):

    def test_single_topic(self):
        e = LearnEngine(['python'], [])
        e.answer('python', correct=True)
        self.assertIsNotNone(e.status())

    def test_no_prerequisites(self):
        e = LearnEngine(['a', 'b', 'c'], [])
        rec = e.next()
        self.assertIsNotNone(rec)

    def test_circular_prerequisites(self):
        # Shouldn't crash even with cycles
        e = LearnEngine(['a', 'b'], [('a', 'b'), ('b', 'a')])
        e.answer('a', correct=True)
        self.assertIsNotNone(e.status())

    def test_large_subject(self):
        topics = [f'topic_{i}' for i in range(50)]
        prereqs = [(f'topic_{i}', f'topic_{i+1}') for i in range(49)]
        e = LearnEngine(topics, prereqs)
        s = e.status()
        self.assertEqual(s['total_topics'], 50)


if __name__ == '__main__':
    unittest.main()
