"""Tests for gump.sensor — Universal Sensor"""
import sys, os, json, unittest
import numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from gump.sensor import UniversalSensor

class TestBasics(unittest.TestCase):
    def test_create(self):
        s = UniversalSensor('test')
        self.assertEqual(s.name, 'test')

    def test_feed_list(self):
        s = UniversalSensor()
        s.feed([1, 2, 3, 4, 5])
        self.assertEqual(len(s.data), 5)

    def test_feed_single(self):
        s = UniversalSensor()
        s.feed(3.14)
        self.assertEqual(len(s.data), 1)

    def test_feed_multiple(self):
        s = UniversalSensor()
        s.feed([1, 2, 3])
        s.feed([4, 5, 6])
        self.assertEqual(len(s.data), 6)

class TestMeasure(unittest.TestCase):
    def test_measure_basic(self):
        s = UniversalSensor()
        s.feed([1, 2, 3, 4, 5, 6, 7, 8])
        m = s.measure()
        self.assertNotIn('error', m)
        self.assertIn('K', m)
        self.assertIn('R', m)
        self.assertIn('E', m)
        self.assertIn('T', m)
        self.assertIn('regime', m)

    def test_measure_too_few(self):
        s = UniversalSensor()
        s.feed([1, 2])
        m = s.measure()
        self.assertIn('error', m)

    def test_sine_wave_coherent(self):
        s = UniversalSensor()
        t = np.linspace(0, 4*np.pi, 100)
        s.feed(np.sin(t).tolist())
        m = s.measure()
        # Sine wave should have high coupling
        self.assertGreater(m['K'], 0.3)

    def test_random_noise_low_coupling(self):
        np.random.seed(42)
        s = UniversalSensor()
        s.feed(np.random.randn(100).tolist())
        m = s.measure()
        # Random noise should have low coupling
        self.assertLess(m['K'], 1.0)

    def test_constant_signal(self):
        s = UniversalSensor()
        s.feed([5.0] * 20)
        m = s.measure()
        self.assertEqual(m['T'], 0.0)

    def test_regime_detection(self):
        s = UniversalSensor()
        s.feed(list(range(100)))  # rising trend
        m = s.measure()
        self.assertIn(m['regime'], ['locked', 'coherent', 'transitional', 'volatile', 'diffuse'])

    def test_trend_detection(self):
        s = UniversalSensor()
        s.feed(list(range(20)))  # clearly rising
        m = s.measure()
        self.assertEqual(m['trend'], 'rising')

    def test_anomaly_detection(self):
        s = UniversalSensor()
        data = [1.0] * 50 + [100.0] + [1.0] * 50  # spike at position 50
        s.feed(data)
        m = s.measure()
        self.assertGreater(len(m['anomalies']), 0)

class TestDiagnose(unittest.TestCase):
    def test_diagnose_has_interpretation(self):
        s = UniversalSensor()
        s.feed(np.sin(np.linspace(0, 10, 50)).tolist())
        d = s.diagnose()
        self.assertIn('interpretation', d)
        self.assertGreater(len(d['interpretation']), 0)
        self.assertIn('recommendation', d)

    def test_diagnose_volatile(self):
        np.random.seed(42)
        s = UniversalSensor()
        s.feed((np.random.randn(100) * 10).tolist())
        d = s.diagnose()
        self.assertIn('recommendation', d)

class TestVisualize(unittest.TestCase):
    def test_html_valid(self):
        s = UniversalSensor('heartbeat')
        s.feed(np.sin(np.linspace(0, 20, 200)).tolist())
        html = s.visualize()
        self.assertIn('<html', html)
        self.assertIn('Universal Sensor', html)
        self.assertIn('heartbeat', html)

    def test_html_has_kret(self):
        s = UniversalSensor()
        s.feed(list(range(20)))
        html = s.visualize()
        self.assertIn('K coupling', html)
        self.assertIn('R order', html)
        self.assertIn('E energy', html)
        self.assertIn('T tension', html)

    def test_html_error(self):
        s = UniversalSensor()
        s.feed([1])
        html = s.visualize()
        self.assertIn('Error', html)

class TestEdgeCases(unittest.TestCase):
    def test_large_data(self):
        s = UniversalSensor()
        s.feed(np.random.randn(10000).tolist())
        m = s.measure()
        self.assertNotIn('error', m)

    def test_negative_values(self):
        s = UniversalSensor()
        s.feed([-5, -3, -1, 0, 1, 3, 5])
        m = s.measure()
        self.assertNotIn('error', m)

    def test_json_serializable(self):
        s = UniversalSensor()
        s.feed([1, 2, 3, 4, 5, 6, 7, 8])
        d = s.diagnose()
        json.dumps(d, default=str)

if __name__ == '__main__':
    unittest.main()
