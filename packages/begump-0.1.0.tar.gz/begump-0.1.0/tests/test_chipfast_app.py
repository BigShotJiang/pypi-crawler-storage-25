"""
Tests for gump.chipfast_app — Chip Fast product
Run: cd gump-package && python tests/test_chipfast_app.py
"""
import sys, os, json, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from gump.chipfast_app import design_report, benchmark_report
from gump.chipfast import design, design_netlist


class TestDesign(unittest.TestCase):

    def test_basic_design(self):
        r = design(['and', 'or', 'xor'], [(0, 1), (1, 2)])
        self.assertNotIn('error', r)
        self.assertEqual(r['n_gates'], 3)
        self.assertEqual(r['n_wires'], 2)

    def test_wire_length_positive(self):
        r = design(['a', 'b', 'c', 'd'], [(0, 1), (1, 2), (2, 3), (0, 3)])
        self.assertGreater(r['wire_length'], 0)

    def test_positions_shape(self):
        r = design(['a', 'b', 'c'], [(0, 1), (1, 2)])
        self.assertEqual(r['positions'].shape, (3, 2))

    def test_empty_gates(self):
        r = design([], [])
        self.assertIn('error', r)

    def test_single_gate(self):
        r = design(['buf'], [])
        self.assertEqual(r['n_gates'], 1)

    def test_large_circuit(self):
        import random
        random.seed(42)
        n = 500
        gates = [f'g{i}' for i in range(n)]
        wires = [(random.randint(0, n-1), random.randint(0, n-1)) for _ in range(1500)]
        wires = [(a, b) for a, b in wires if a != b]
        r = design(gates, wires)
        self.assertNotIn('error', r)
        self.assertEqual(r['n_gates'], 500)

    def test_netlist_parse(self):
        netlist = 'and g0 (y, a, b); or g1 (z, y, c); buf g2 (w, z);'
        r = design_netlist(netlist)
        self.assertNotIn('error', r)
        self.assertEqual(r['n_gates'], 3)

    def test_netlist_chained(self):
        netlist = 'and g0 (n1, a, b); and g1 (n2, n1, c); or g2 (out, n2, d);'
        r = design_netlist(netlist)
        self.assertNotIn('error', r)
        self.assertGreater(r['n_wires'], 0)

    def test_tensions_detected(self):
        # Star topology: center connects to all, spokes don't connect to each other
        gates = ['hub'] + [f's{i}' for i in range(6)]
        wires = [(0, i) for i in range(1, 7)]
        r = design(gates, wires)
        # Spokes should have tensions between them
        self.assertGreater(len(r['missing_connections']), 0)


class TestReport(unittest.TestCase):

    def test_report_valid_html(self):
        html = design_report(['a', 'b', 'c', 'd'], [(0, 1), (1, 2), (2, 3)])
        self.assertIn('<html', html)
        self.assertIn('Chip Fast', html)
        self.assertIn('<canvas', html)

    def test_report_has_stats(self):
        html = design_report(['a', 'b', 'c'], [(0, 1), (1, 2)])
        html_lower = html.lower()
        self.assertIn('gates', html_lower)
        self.assertIn('wires', html_lower)
        self.assertIn('wire length', html_lower)
        self.assertIn('reduction', html_lower)

    def test_report_contains_gate_names(self):
        html = design_report(['inv0', 'nand1', 'nor2'], [(0, 1), (1, 2)])
        self.assertIn('inv0', html)
        self.assertIn('nand1', html)

    def test_report_error(self):
        html = design_report([], [])
        self.assertIn('Error', html)


class TestBenchmark(unittest.TestCase):

    def test_benchmark_100(self):
        html = benchmark_report(100)
        self.assertIn('<html', html)
        self.assertIn('100-Gate', html)

    def test_benchmark_1000(self):
        html = benchmark_report(1000)
        self.assertIn('1000-Gate', html)
        self.assertGreater(len(html), 5000)

    def test_benchmark_has_reduction(self):
        html = benchmark_report(200)
        self.assertIn('Reduction', html)


if __name__ == '__main__':
    unittest.main()
