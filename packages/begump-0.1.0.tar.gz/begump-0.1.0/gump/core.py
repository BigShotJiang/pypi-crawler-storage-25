"""
GUMP Core — K, R, E, T in one file.
Zero dependencies beyond numpy + scipy (optional).
"""
import numpy as np
from math import log, sqrt, gcd

# ═══ CONSTANTS ═══
K_CEILING = 1.868          # Universal coupling ceiling (= 256α)
PHI = (1 + sqrt(5)) / 2   # Golden ratio
kB = 1.380649e-23          # Boltzmann constant (J/K)
T_ROOM = 300               # Room temperature (K)
LANDAUER_PER_BIT = kB * T_ROOM * log(2)  # 2.87e-21 J


# ═══ TENSION — what wants to connect ═══

class _TensionDetector:
    """Spectral tension detection via Laplacian eigenvectors."""

    def __init__(self, n, edges, weights=None, n_vecs=8, seed=42):
        self.n = n
        self.edges = edges
        self.edge_set = set()
        for i, j in edges:
            self.edge_set.add((min(i, j), max(i, j)))

        ci = np.array([e[0] for e in edges], dtype=int)
        cj = np.array([e[1] for e in edges], dtype=int)
        w = np.array(weights, dtype=float) if weights is not None else np.ones(len(edges))

        if len(edges) == 0 or n < 3:
            self.coords = np.random.RandomState(seed).randn(n, max(1, n_vecs)) * 0.01
            return

        # Build sparse Laplacian and compute eigenvectors
        try:
            from scipy.sparse import csr_matrix
            from scipy.sparse.linalg import lobpcg
            import warnings
            warnings.filterwarnings('ignore')

            data = np.concatenate([w, w])
            row = np.concatenate([ci, cj])
            col = np.concatenate([cj, ci])
            A = csr_matrix((data, (row, col)), shape=(n, n))
            degree = np.array(A.sum(axis=1)).ravel()
            D = csr_matrix((degree, (np.arange(n), np.arange(n))), shape=(n, n))
            L = D - A

            k = min(n_vecs + 1, n - 1)
            rng = np.random.RandomState(seed)
            X0 = rng.randn(n, k)
            M_diag = 1.0 / np.maximum(degree, 1.0)
            M = csr_matrix((M_diag, (np.arange(n), np.arange(n))), shape=(n, n))

            eigenvalues, eigenvectors = lobpcg(L, X0, M=M, tol=1e-3,
                                                maxiter=60, largest=False,
                                                verbosityLevel=0)
            order = np.argsort(eigenvalues)
            self.coords = eigenvectors[:, order[1:]]
            self.eigenvalues = eigenvalues[order]
        except ImportError:
            # Fallback: power iteration (no scipy needed)
            degree = np.zeros(n)
            np.add.at(degree, ci, w)
            np.add.at(degree, cj, w)
            d_max = np.max(degree) + 1

            def shifted_mul(v):
                result = d_max * v - degree * v
                np.add.at(result, ci, w * v[cj])
                np.add.at(result, cj, w * v[ci])
                return result

            vecs = []
            rng = np.random.RandomState(seed)
            v0 = np.ones(n) / sqrt(n)
            vecs.append(v0)

            for _ in range(min(n_vecs, n - 1)):
                v = rng.randn(n)
                for prev in vecs:
                    v -= np.dot(v, prev) * prev
                v /= np.linalg.norm(v)
                for _ in range(60):
                    v = shifted_mul(v)
                    for prev in vecs:
                        v -= np.dot(v, prev) * prev
                    nm = np.linalg.norm(v)
                    if nm > 1e-10:
                        v /= nm
                vecs.append(v)

            self.coords = np.column_stack(vecs[1:]) if len(vecs) > 1 else np.zeros((n, 1))
            self.eigenvalues = None

    def _dist(self, i, j):
        return float(np.linalg.norm(self.coords[i] - self.coords[j]))

    def tensions(self, top_k=20):
        results = []
        for i in range(self.n):
            dists = np.linalg.norm(self.coords - self.coords[i], axis=1)
            nearest = np.argsort(dists)
            for j in nearest[1:min(50, self.n)]:
                if j <= i:
                    continue
                pair = (min(i, j), max(i, j))
                if pair not in self.edge_set:
                    d = float(dists[j])
                    if d > 0:
                        results.append((d, int(i), int(j), 1.0 / d))
        results.sort()
        return results[:top_k]

    def redundancies(self, top_k=20):
        results = []
        for i, j in self.edges:
            results.append((self._dist(i, j), int(i), int(j)))
        results.sort(reverse=True)
        return results[:top_k]

    def clusters(self, k=None):
        if self.eigenvalues is not None and k is None:
            gaps = np.diff(self.eigenvalues[1:])
            k = int(np.argmax(gaps)) + 2 if len(gaps) > 0 else 2
        if k is None:
            k = 2
        from scipy.cluster.vq import kmeans2
        coords = self.coords[:, :min(k, self.coords.shape[1])]
        _, labels = kmeans2(coords, k, minit='points')
        return labels, k

    def resolution_path(self, node_i, top_k=10):
        dists = np.linalg.norm(self.coords - self.coords[node_i], axis=1)
        order = np.argsort(dists)
        path = []
        for j in order[1:]:
            pair = (min(node_i, j), max(node_i, j))
            path.append({
                'node': int(j),
                'distance': float(dists[j]),
                'connected': pair in self.edge_set,
                'tension': pair not in self.edge_set,
            })
            if len(path) >= top_k:
                break
        return path


# ═══ PUBLIC API ═══

def tensions(n, edges, weights=None, top_k=20):
    """Find harmonic tensions in any graph.
    Returns list of (distance, node_i, node_j, tension_score)."""
    td = _TensionDetector(n, edges, weights)
    return td.tensions(top_k)


def redundancies(n, edges, weights=None, top_k=20):
    """Find redundant connections (connected but spectrally far)."""
    td = _TensionDetector(n, edges, weights)
    return td.redundancies(top_k)


def place(n, edges, width=100, height=100, weights=None, mode='auto'):
    """Spectral placement: position n nodes to minimize wire length.
    Returns (n, 2) array of positions."""
    ci = [e[0] for e in edges]
    cj = [e[1] for e in edges]
    w = weights

    # Build eigenvectors
    td = _TensionDetector(n, edges, w, n_vecs=2)

    coords = td.coords[:, :2] if td.coords.shape[1] >= 2 else \
             np.column_stack([td.coords[:, 0], np.random.randn(n)])

    # Quantile mapping for uniform density
    for d in range(2):
        mn, mx = coords[:, d].min(), coords[:, d].max()
        if mx > mn:
            coords[:, d] = (coords[:, d] - mn) / (mx - mn)
        order = np.argsort(coords[:, d])
        ranks = np.empty(n)
        ranks[order] = np.arange(n, dtype=float) / max(n - 1, 1)
        coords[:, d] = ranks

    positions = np.zeros((n, 2))
    positions[:, 0] = coords[:, 0] * width * 0.9 + width * 0.05
    positions[:, 1] = coords[:, 1] * height * 0.9 + height * 0.05
    return positions


def clusters(n, edges, weights=None, k=None):
    """Find natural clusters in a graph."""
    td = _TensionDetector(n, edges, weights)
    return td.clusters(k)


def resolution_path(n, edges, node, weights=None, top_k=10):
    """What does a node want to connect to?"""
    td = _TensionDetector(n, edges, weights)
    return td.resolution_path(node, top_k)


# ═══ ENERGY ═══

class EnergyTracker:
    """Track Landauer energy cost through computation."""

    def __init__(self, temperature=300):
        self.T = temperature
        self.landauer = kB * temperature * log(2)
        self.total_bits = 0
        self.total_joules = 0.0

    def erase(self, n_bits, label=''):
        cost = n_bits * self.landauer
        self.total_bits += n_bits
        self.total_joules += cost
        return cost

    def reverse(self, n_bits):
        return 0  # reversible = free

    @property
    def efficiency(self):
        return self.total_joules  # compare to actual watts × seconds

    def summary(self):
        return {
            'bits_erased': self.total_bits,
            'landauer_J': self.total_joules,
            'landauer_eV': self.total_joules / 1.602e-19,
        }


def interval_cost(p, q):
    """Landauer cost of processing interval p:q in nats.
    Simpler ratios = cheaper. Complex = expensive."""
    g = gcd(p, q)
    p, q = p // g, q // g
    return log(p) + log(q)


def coupling_energy(phases, K, adjacency=None):
    """Kuramoto coupling energy: E = -K Σ cos(θi - θj)."""
    n = len(phases)
    E = 0
    if adjacency is not None:
        for i, j in adjacency:
            E -= K * np.cos(phases[i] - phases[j])
    else:
        for i in range(n):
            for j in range(i + 1, n):
                E -= K * np.cos(phases[i] - phases[j])
    return float(E)


# ═══ CRASH DETECTION ═══

def detect_crash(time_series_list, window=30):
    """Detect phase transitions in correlated time series.
    Returns list of {day, R, regime} dicts."""
    n_assets = len(time_series_list)
    n_days = len(time_series_list[0])
    data = np.array(time_series_list)

    results = []
    for t in range(window, n_days):
        chunk = data[:, t - window:t]
        corr = np.corrcoef(chunk)
        corr = np.nan_to_num(corr, 0)

        # Order parameter from correlation eigenvalues
        eigvals = np.linalg.eigvalsh(corr)
        R = float(eigvals[-1] / np.sum(np.abs(eigvals) + 1e-10))
        regime = 'trending' if R > 1 / PHI else 'volatile'
        results.append({'day': t, 'R': R, 'regime': regime})

    return results


# ═══ GROK DETECTION ═══

def watch_training(test_accuracies, window=10):
    """Detect grokking: sudden jump in test accuracy.
    Returns (grokked: bool, epoch: int, jump_size: float)."""
    if len(test_accuracies) < window + 1:
        return False, -1, 0.0

    accs = np.array(test_accuracies)
    # Smoothed derivative
    smoothed = np.convolve(accs, np.ones(window) / window, mode='valid')
    if len(smoothed) < 2:
        return False, -1, 0.0

    jumps = np.diff(smoothed)
    max_jump_idx = int(np.argmax(jumps))
    max_jump = float(jumps[max_jump_idx])

    # Grokking = jump > 0.1 (10% accuracy improvement in one window)
    grokked = max_jump > 0.1
    epoch = max_jump_idx + window if grokked else -1

    return grokked, epoch, max_jump
