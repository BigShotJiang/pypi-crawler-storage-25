"""
ORG X-RAY — See the real structure of any network.
====================================================
Combines tension detection, spectral placement, and coupled oscillator
dynamics to reveal what an org chart won't show you.

    from gump.orgxray import scan, scan_csv, scan_org

    # From a list of connections
    result = scan(['Alice','Bob','Carol'], [('Alice','Bob'),('Bob','Carol')])

    # From CSV
    result = scan_csv('connections.csv')

    # From org chart
    result = scan_org(['CEO','VP','Dev1','Dev2'], {'VP':'CEO','Dev1':'VP','Dev2':'VP'})

    # Interactive HTML report
    html = visualize(result)
    with open('report.html','w') as f: f.write(html)

Built on: gump.tensionmap (analysis) + gump.core (placement) + network_k (dynamics)
"""

import json
import numpy as np
from gump.core import _TensionDetector, PHI
from gump.k_runtime import place as spectral_place
from gump.tensionmap import scan as tensionmap_scan

# Try to import NetworkK for dynamics enrichment (optional)
try:
    import sys, os
    _engine_path = os.path.join(os.path.dirname(__file__), '..', '..', 'tools', 'engines')
    if os.path.isdir(_engine_path):
        sys.path.insert(0, _engine_path)
    from network_k import NetworkK
    _HAS_NETWORK_K = True
except ImportError:
    _HAS_NETWORK_K = False


def scan(nodes, edges, weights=None, node_properties=None, top_k=20):
    """Full org X-ray: tensionmap analysis + spectral positions + dynamics.

    Args:
        nodes: list of node names
        edges: list of (name_a, name_b) tuples
        weights: optional edge weights
        node_properties: optional dict {name: {prop: value}}
        top_k: how many tensions/redundancies to return

    Returns:
        dict with everything tensionmap returns, plus:
        - positions: {name: [x, y]} spectral layout
        - node_scores: {name: {degree, cluster, ...}} per-node metrics
        - dynamics: {R, communities, ...} if NetworkK available
    """
    if not nodes or not edges:
        return {'error': 'Need both nodes and edges'}

    # Core analysis from tensionmap
    result = tensionmap_scan(nodes, edges, weights, top_k, node_properties)
    if 'error' in result:
        return result

    n = len(nodes)
    node_idx = {name: i for i, name in enumerate(nodes)}

    # Build index edges for spectral placement
    idx_edges = []
    idx_weights = []
    for k, (a, b) in enumerate(edges):
        if a in node_idx and b in node_idx:
            idx_edges.append((node_idx[a], node_idx[b]))
            idx_weights.append(weights[k] if weights and k < len(weights) else 1.0)

    # Spectral 2D positions
    try:
        positions_arr = spectral_place(n, idx_edges, 800, 600, idx_weights)
        # Add perpendicular jitter to prevent linear layouts
        # Chains produce 1D spectral placement — add 2nd dimension from cluster + noise
        import hashlib
        for i in range(n):
            seed = int(hashlib.md5(str(i).encode()).hexdigest()[:8], 16)
            jitter_x = ((seed % 1000) / 1000 - 0.5) * 120
            jitter_y = ((seed % 997) / 997 - 0.5) * 120
            positions_arr[i][0] += jitter_x
            positions_arr[i][1] += jitter_y
        result['positions'] = {nodes[i]: [round(float(positions_arr[i][0]), 1),
                                           round(float(positions_arr[i][1]), 1)]
                                for i in range(n)}
    except Exception:
        # Fallback: random positions
        result['positions'] = {nodes[i]: [round(float(np.random.rand() * 800), 1),
                                           round(float(np.random.rand() * 600), 1)]
                                for i in range(n)}

    # Per-node scores
    degree = np.zeros(n)
    for i, j in idx_edges:
        degree[i] += 1
        degree[j] += 1

    # Map each node to its cluster
    cluster_map = {}
    for ci, cl in enumerate(result.get('clusters', [])):
        for member in cl.get('members', []):
            cluster_map[member] = ci

    # Tension count per node
    tension_count = {}
    for t in result.get('tensions', []):
        tension_count[t['a']] = tension_count.get(t['a'], 0) + 1
        tension_count[t['b']] = tension_count.get(t['b'], 0) + 1

    result['node_scores'] = {}
    for i, name in enumerate(nodes):
        result['node_scores'][name] = {
            'degree': int(degree[i]),
            'cluster': cluster_map.get(name, -1),
            'tension_count': tension_count.get(name, 0),
            'is_hub': name in [h['node'] for h in result.get('hubs', [])],
            'is_isolate': name in result.get('isolates', []),
            'is_bridge': name in [b['node_a'] for b in result.get('bridges', [])] or
                         name in [b['node_b'] for b in result.get('bridges', [])],
        }

    # Include raw edges for visualization
    result['edges'] = [{'a': a, 'b': b, 'weight': weights[k] if weights and k < len(weights) else 1.0}
                       for k, (a, b) in enumerate(edges) if a in node_idx and b in node_idx]

    # Dynamics from NetworkK (optional enrichment)
    if _HAS_NETWORK_K and n > 2:
        try:
            adj = np.zeros((n, n))
            for k, (i, j) in enumerate(idx_edges):
                w = idx_weights[k] if k < len(idx_weights) else 1.0
                adj[i][j] = w
                adj[j][i] = w
            nk = NetworkK.from_adjacency(adj)
            nk.evolve(steps=200)
            R = float(nk.order_parameter())
            result['dynamics'] = {
                'R': round(R, 4),
                'above_critical': R > 1.0 / PHI,
                'regime': 'coherent' if R > 1.0 / PHI else 'fragmented',
            }
        except Exception:
            result['dynamics'] = None
    else:
        result['dynamics'] = None

    return result


def scan_csv(filepath_or_text, has_header=False):
    """Scan from CSV file or text. Format: node_a,node_b[,weight] per line."""
    import os
    if os.path.isfile(filepath_or_text):
        with open(filepath_or_text, encoding='utf-8', errors='ignore') as f:
            text = f.read()
    else:
        text = filepath_or_text

    lines = text.strip().split('\n')
    if has_header and len(lines) > 1:
        lines = lines[1:]

    nodes_set = set()
    edges = []
    wts = []
    for line in lines:
        parts = [p.strip() for p in line.strip().split(',')]
        if len(parts) >= 2 and parts[0] and parts[1]:
            a, b = parts[0], parts[1]
            if a == b:
                continue  # skip self-loops
            nodes_set.add(a)
            nodes_set.add(b)
            edges.append((a, b))
            try:
                wts.append(float(parts[2]) if len(parts) >= 3 else 1.0)
            except (ValueError, IndexError):
                wts.append(1.0)

    if not nodes_set:
        return {'error': 'No valid edges found in CSV'}

    return scan(sorted(nodes_set), edges, wts)


def scan_org(people, reports_to):
    """Scan an org chart.

    Args:
        people: list of names
        reports_to: dict {person: manager} or list of (person, manager) tuples
    """
    people_set = set(people)
    if isinstance(reports_to, dict):
        edges = [(person, manager) for person, manager in reports_to.items()
                 if person in people_set and manager in people_set]
    else:
        edges = [(a, b) for a, b in reports_to if a in people_set and b in people_set]

    if not edges:
        return {'error': 'No valid reporting relationships found'}

    return scan(people, edges)


def scan_json(data):
    """Scan from JSON. Accepts:
    - {"nodes": [...], "edges": [["a","b"], ...]}
    - {"nodes": [...], "edges": [["a","b",weight], ...]}
    - {"people": [...], "reports_to": {"person": "manager", ...}}
    """
    if isinstance(data, str):
        data = json.loads(data)

    if 'people' in data and 'reports_to' in data:
        return scan_org(data['people'], data['reports_to'])

    nodes = data.get('nodes', [])
    raw_edges = data.get('edges', [])

    edges = []
    weights = []
    for e in raw_edges:
        if len(e) >= 2:
            edges.append((e[0], e[1]))
            weights.append(float(e[2]) if len(e) >= 3 else 1.0)

    if not nodes:
        # Infer nodes from edges
        s = set()
        for a, b in edges:
            s.add(a)
            s.add(b)
        nodes = sorted(s)

    return scan(nodes, edges, weights)


def scan_slack(export_path):
    """Scan a Slack export directory. Reads channel JSON files,
    extracts who-messages-whom edges weighted by message count."""
    import os
    if not os.path.isdir(export_path):
        return {'error': f'Directory not found: {export_path}'}

    interactions = {}  # (user_a, user_b) → count
    users = set()

    for dirpath, dirnames, filenames in os.walk(export_path):
        for fname in filenames:
            if not fname.endswith('.json'):
                continue
            try:
                with open(os.path.join(dirpath, fname), encoding='utf-8') as f:
                    messages = json.load(f)
                if not isinstance(messages, list):
                    continue
                # Track who talks in the same channel within same hour
                by_hour = {}
                for msg in messages:
                    user = msg.get('user', msg.get('username', ''))
                    ts = msg.get('ts', '')
                    if not user or not ts:
                        continue
                    users.add(user)
                    hour = ts.split('.')[0][:7]  # rough hour bucket
                    if hour not in by_hour:
                        by_hour[hour] = set()
                    by_hour[hour].add(user)
                # Co-presence in same hour = interaction
                for hour_users in by_hour.values():
                    ul = sorted(hour_users)
                    for i in range(len(ul)):
                        for j in range(i + 1, len(ul)):
                            pair = (ul[i], ul[j])
                            interactions[pair] = interactions.get(pair, 0) + 1
            except (json.JSONDecodeError, KeyError, TypeError):
                continue

    if not interactions:
        return {'error': 'No interactions found in Slack export'}

    nodes = sorted(users)
    edges = list(interactions.keys())
    weights = [interactions[e] for e in edges]

    return scan(nodes, edges, weights)


def scan_github(contributors):
    """Scan GitHub contributor data.

    Args:
        contributors: list of dicts with 'author' and 'files' keys
            e.g. [{'author': 'alice', 'files': ['src/a.py', 'src/b.py']}, ...]
            Two authors editing the same file = connection.
    """
    file_authors = {}  # file → set of authors
    users = set()

    for contrib in contributors:
        author = contrib.get('author', '')
        files = contrib.get('files', [])
        if not author:
            continue
        users.add(author)
        for f in files:
            if f not in file_authors:
                file_authors[f] = set()
            file_authors[f].add(author)

    # Co-edit = connection
    interactions = {}
    for f, authors in file_authors.items():
        al = sorted(authors)
        for i in range(len(al)):
            for j in range(i + 1, len(al)):
                pair = (al[i], al[j])
                interactions[pair] = interactions.get(pair, 0) + 1

    if not interactions:
        return {'error': 'No co-edit relationships found'}

    nodes = sorted(users)
    edges = list(interactions.keys())
    weights = [interactions[e] for e in edges]

    return scan(nodes, edges, weights)


def visualize(result):
    """Generate a self-contained interactive HTML report from scan results.

    Returns a single HTML string with embedded CSS/JS. Dark theme, force-directed
    animation, metric overlays, cluster hulls, bezier edges, tension lines,
    tabbed interactive panel, SVG health gauge, hover/click detail, and search.
    Designed to match the polish of Polinode / Microsoft Viva Insights.
    """
    if 'error' in result:
        return f'<html><body style="background:#08080d;color:#e8e4dc;font-family:Georgia,serif;padding:40px"><h1 style="color:#c9a44a">Error</h1><p>{result["error"]}</p></body></html>'

    data_json = json.dumps(result, default=str)

    return f'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Org X-Ray</title>
<style>
*{{margin:0;padding:0;box-sizing:border-box}}
body{{background:#08080d;color:#e8e4dc;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Georgia,serif;display:flex;height:100vh;overflow:hidden}}
#canvas-wrap{{flex:1;position:relative}}
canvas{{display:block;width:100%;height:100%}}
#tooltip{{position:absolute;pointer-events:none;background:rgba(13,13,20,0.95);border:1px solid rgba(201,164,74,0.3);
  border-radius:8px;padding:8px 12px;font-size:12px;display:none;z-index:10;backdrop-filter:blur(8px);
  box-shadow:0 4px 20px rgba(0,0,0,0.5)}}
#tooltip .tt-name{{color:#c9a44a;font-weight:600;margin-bottom:2px}}
#tooltip .tt-row{{color:#888;font-size:11px}}
#panel{{width:360px;background:#0a0a12;border-left:1px solid rgba(255,255,255,0.04);display:flex;flex-direction:column;overflow:hidden}}
#panel-header{{padding:16px 20px 0;flex-shrink:0}}
#panel-header h1{{font-size:1.2em;font-weight:300;color:#c9a44a;letter-spacing:0.15em;text-transform:uppercase}}
#search-wrap{{margin:12px 20px 0;position:relative}}
#search{{width:100%;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.06);border-radius:8px;
  padding:8px 12px 8px 32px;color:#e8e4dc;font-size:13px;outline:none;transition:border-color 0.3s}}
#search:focus{{border-color:rgba(201,164,74,0.4)}}
#search-icon{{position:absolute;left:10px;top:50%;transform:translateY(-50%);color:#555;font-size:13px}}
#tabs{{display:flex;padding:12px 20px 0;gap:4px;flex-shrink:0}}
.tab{{flex:1;padding:8px 4px;text-align:center;font-size:11px;font-weight:500;letter-spacing:0.06em;
  text-transform:uppercase;color:#555;cursor:pointer;border-bottom:2px solid transparent;transition:all 0.3s}}
.tab:hover{{color:#888}}
.tab.active{{color:#c9a44a;border-bottom-color:#c9a44a}}
#tab-content{{flex:1;overflow-y:auto;padding:16px 20px 20px;scrollbar-width:thin;scrollbar-color:#ffffff10 transparent}}
#tab-content::-webkit-scrollbar{{width:4px}}
#tab-content::-webkit-scrollbar-track{{background:transparent}}
#tab-content::-webkit-scrollbar-thumb{{background:#ffffff10;border-radius:2px}}
.tab-pane{{display:none}}
.tab-pane.active{{display:block}}
.section-title{{font-size:11px;font-weight:600;color:#c9a44a;letter-spacing:0.1em;text-transform:uppercase;margin:16px 0 8px}}
.section-title:first-child{{margin-top:0}}
.stat-row{{display:flex;justify-content:space-between;font-size:12px;color:#777;padding:5px 0;border-bottom:1px solid rgba(255,255,255,0.02)}}
.stat-row span:last-child{{color:#c9a44a;font-weight:500}}
.action-card{{background:rgba(255,255,255,0.02);border-left:3px solid rgba(201,164,74,0.2);padding:10px 14px;
  margin:8px 0;border-radius:0 8px 8px 0;transition:background 0.2s}}
.action-card:hover{{background:rgba(255,255,255,0.04)}}
.action-card .act-text{{color:#e8e4dc;font-size:12px;line-height:1.4}}
.action-card .act-reason{{color:#555;font-size:11px;margin-top:3px}}
.action-card .act-badge{{display:inline-block;font-size:9px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase;
  padding:2px 6px;border-radius:4px;margin-bottom:4px}}
.action-card.high{{border-left-color:#e05555}}
.action-card.high .act-badge{{background:rgba(224,85,85,0.15);color:#e05555}}
.action-card.medium{{border-left-color:#d4a24a}}
.action-card.medium .act-badge{{background:rgba(212,162,74,0.15);color:#d4a24a}}
.action-card.low{{border-left-color:#4a9a6a}}
.action-card.low .act-badge{{background:rgba(74,154,106,0.15);color:#4a9a6a}}
.cluster-item{{display:flex;align-items:flex-start;gap:8px;padding:8px 0;border-bottom:1px solid rgba(255,255,255,0.02)}}
.cluster-badge{{width:10px;height:10px;border-radius:50%;margin-top:3px;flex-shrink:0}}
.cluster-members{{font-size:12px;color:#888;line-height:1.5}}
.cluster-members strong{{color:#e8e4dc;font-weight:500}}
.node-detail-card{{background:rgba(255,255,255,0.02);border-radius:10px;padding:16px}}
.node-detail-card .nd-name{{font-size:16px;font-weight:300;color:#c9a44a;margin-bottom:8px}}
.nd-roles{{display:flex;gap:6px;margin-bottom:10px;flex-wrap:wrap}}
.nd-role{{font-size:10px;font-weight:600;letter-spacing:0.06em;text-transform:uppercase;padding:3px 8px;border-radius:12px}}
.nd-role.hub{{background:rgba(201,164,74,0.15);color:#c9a44a}}
.nd-role.isolate{{background:rgba(224,85,85,0.15);color:#e05555}}
.nd-role.bridge{{background:rgba(74,154,201,0.15);color:#4a9ac9}}
.nd-tension-item{{font-size:12px;color:#888;padding:3px 0}}
.nd-tension-item span{{color:#c9a44a}}
.layer-toggles{{display:flex;flex-wrap:wrap;gap:4px;margin-top:8px}}
.ltoggle{{display:inline-flex;align-items:center;gap:4px;padding:4px 10px;font-size:11px;border:1px solid rgba(255,255,255,0.06);
  border-radius:16px;cursor:pointer;color:#555;transition:all 0.25s;user-select:none}}
.ltoggle:hover{{border-color:rgba(255,255,255,0.12)}}
.ltoggle.on{{color:#c9a44a;border-color:rgba(201,164,74,0.3);background:rgba(201,164,74,0.06)}}
.ltoggle .ldot{{width:6px;height:6px;border-radius:50%;background:currentColor}}
.empty-state{{text-align:center;padding:40px 20px;color:#444;font-size:13px}}
@media(max-width:900px){{
  body{{flex-direction:column}}
  #panel{{width:100%;height:45vh;border-left:none;border-top:1px solid rgba(255,255,255,0.04)}}
}}
</style>
</head>
<body>
<div id="canvas-wrap">
  <canvas id="graph"></canvas>
  <div id="tooltip"><div class="tt-name"></div><div class="tt-body"></div></div>
</div>
<div id="panel">
  <div id="panel-header">
    <h1>Org X-Ray</h1>
    <div id="search-wrap">
      <span id="search-icon">&#x1F50D;</span>
      <input id="search" type="text" placeholder="Search nodes..." autocomplete="off" spellcheck="false"/>
    </div>
  </div>
  <div id="tabs">
    <div class="tab active" data-tab="overview">Overview</div>
    <div class="tab" data-tab="actions">Actions</div>
    <div class="tab" data-tab="clusters">Clusters</div>
    <div class="tab" data-tab="detail">Detail</div>
  </div>
  <div id="tab-content">
    <div class="tab-pane active" id="pane-overview"></div>
    <div class="tab-pane" id="pane-actions"></div>
    <div class="tab-pane" id="pane-clusters"></div>
    <div class="tab-pane" id="pane-detail"><div class="empty-state">Click a node on the graph to see details</div></div>
  </div>
</div>

<script>
(function(){{
"use strict";

var DATA = {data_json};
var COLORS = ['#c9a44a','#4a9ac9','#6bc44a','#d44a7a','#8a5cf5','#e07a3a','#3ac9a0','#c9c44a','#5a8ef5','#d44ac9','#4ac9d4','#c97a4a'];
var PI2 = Math.PI * 2;

// --- Canvas setup ---
var cv = document.getElementById('graph');
var cx = cv.getContext('2d');
var wrap = document.getElementById('canvas-wrap');
var dpr = window.devicePixelRatio || 1;
var tooltip = document.getElementById('tooltip');

var layers = {{edges:true,tensions:true,redundancies:false,bridges:true,labels:true,hulls:true}};
var hovered = null, selected = null, searchTerm = '';
var time = 0;

var pos = DATA.positions || {{}};
var nodeNames = Object.keys(pos);
var scores = DATA.node_scores || {{}};
var edgeList = DATA.edges || [];
var maxWeight = 1;
edgeList.forEach(function(e){{ if(e.weight > maxWeight) maxWeight = e.weight; }});

// Bridge edge lookup
var bridgeSet = {{}};
(DATA.bridges||[]).forEach(function(b){{
  bridgeSet[b.node_a+'|'+b.node_b] = true;
  bridgeSet[b.node_b+'|'+b.node_a] = true;
}});

// Per-node animation seeds
var seeds = {{}};
nodeNames.forEach(function(n,i){{ seeds[n] = {{px:Math.random()*PI2, py:Math.random()*PI2, sx:0.3+Math.random()*0.4, sy:0.2+Math.random()*0.3, ax:1.5+Math.random()*2, ay:1+Math.random()*1.5}}; }});

// --- Resize ---
var W, H;
function resize(){{
  var r = wrap.getBoundingClientRect();
  W = r.width; H = r.height;
  cv.width = W * dpr; cv.height = H * dpr;
  cx.setTransform(dpr,0,0,dpr,0,0);
}}
resize();
window.addEventListener('resize', resize);

// --- Coord mapping with animation bob ---
var margin = 70;
function mapPos(name){{
  var p = pos[name];
  if(!p) return [0,0];
  var s = seeds[name];
  var bob_x = Math.sin(time * s.sx + s.px) * s.ax;
  var bob_y = Math.cos(time * s.sy + s.py) * s.ay;
  var x = margin + (p[0]/800) * (W - 2*margin) + bob_x;
  var y = margin + (p[1]/600) * (H - 2*margin) + bob_y;
  return [x,y];
}}
function mapPosStatic(name){{
  var p = pos[name];
  if(!p) return [0,0];
  return [margin + (p[0]/800)*(W-2*margin), margin + (p[1]/600)*(H-2*margin)];
}}

function nodeRadius(name){{
  var s = scores[name];
  return s ? Math.max(5, Math.sqrt(s.degree+1)*3.5) : 5;
}}
function nodeColor(name){{
  var s = scores[name];
  if(!s || s.cluster < 0) return '#555';
  return COLORS[s.cluster % COLORS.length];
}}
function hexToRGBA(hex, a){{
  var r=parseInt(hex.slice(1,3),16), g=parseInt(hex.slice(3,5),16), b=parseInt(hex.slice(5,7),16);
  return 'rgba('+r+','+g+','+b+','+a+')';
}}

// --- Cluster hull computation (convex hull) ---
function convexHull(points){{
  if(points.length < 3) return points;
  points.sort(function(a,b){{ return a[0]-b[0] || a[1]-b[1]; }});
  var lower = [];
  for(var i=0;i<points.length;i++){{
    while(lower.length>=2 && cross(lower[lower.length-2],lower[lower.length-1],points[i])<=0) lower.pop();
    lower.push(points[i]);
  }}
  var upper = [];
  for(var i=points.length-1;i>=0;i--){{
    while(upper.length>=2 && cross(upper[upper.length-2],upper[upper.length-1],points[i])<=0) upper.pop();
    upper.push(points[i]);
  }}
  upper.pop(); lower.pop();
  return lower.concat(upper);
}}
function cross(O,A,B){{ return (A[0]-O[0])*(B[1]-O[1])-(A[1]-O[1])*(B[0]-O[0]); }}

function getClusterHulls(){{
  var clusters = {{}};
  nodeNames.forEach(function(n){{
    var s = scores[n]; if(!s||s.cluster<0) return;
    if(!clusters[s.cluster]) clusters[s.cluster]=[];
    var p = mapPos(n), r = nodeRadius(n);
    // add expanded points around node for padding
    clusters[s.cluster].push([p[0]-r-12,p[1]-r-12]);
    clusters[s.cluster].push([p[0]+r+12,p[1]-r-12]);
    clusters[s.cluster].push([p[0]-r-12,p[1]+r+12]);
    clusters[s.cluster].push([p[0]+r+12,p[1]+r+12]);
  }});
  var result = {{}};
  for(var c in clusters){{
    if(clusters[c].length >= 6) result[c] = convexHull(clusters[c]);
  }}
  return result;
}}

// --- Bezier edge drawing ---
function drawBezierEdge(ax,ay,bx,by,color,width){{
  var mx = (ax+bx)/2, my = (ay+by)/2;
  var dx = bx-ax, dy = by-ay;
  var len = Math.sqrt(dx*dx+dy*dy);
  var off = Math.min(len*0.15, 30);
  var nx = -dy/len*off, ny = dx/len*off;
  cx.strokeStyle = color;
  cx.lineWidth = width;
  cx.beginPath();
  cx.moveTo(ax,ay);
  cx.quadraticCurveTo(mx+nx, my+ny, bx, by);
  cx.stroke();
}}

// --- Search matching ---
function matchesSearch(name){{
  if(!searchTerm) return true;
  return name.toLowerCase().indexOf(searchTerm) >= 0;
}}
function isSearchDimmed(name){{
  return searchTerm && !matchesSearch(name);
}}

// --- Main draw ---
function draw(){{
  cx.clearRect(0,0,W,H);

  // Cluster hulls
  if(layers.hulls){{
    var hulls = getClusterHulls();
    for(var ci in hulls){{
      var pts = hulls[ci];
      if(pts.length < 3) continue;
      var col = COLORS[parseInt(ci) % COLORS.length];
      cx.fillStyle = hexToRGBA(col, 0.04);
      cx.strokeStyle = hexToRGBA(col, 0.08);
      cx.lineWidth = 1;
      cx.beginPath();
      // Smooth hull with curves
      cx.moveTo(pts[0][0], pts[0][1]);
      for(var i=0;i<pts.length;i++){{
        var curr = pts[i], next = pts[(i+1)%pts.length];
        var mx = (curr[0]+next[0])/2, my = (curr[1]+next[1])/2;
        cx.quadraticCurveTo(curr[0], curr[1], mx, my);
      }}
      cx.closePath();
      cx.fill();
      cx.stroke();
    }}
  }}

  // Edges (bezier, thickness by weight)
  if(layers.edges){{
    edgeList.forEach(function(e){{
      var pa = mapPos(e.a), pb = mapPos(e.b);
      var isBridge = bridgeSet[e.a+'|'+e.b];
      var dimA = isSearchDimmed(e.a), dimB = isSearchDimmed(e.b);
      var dim = dimA && dimB;
      var thick = 0.5 + (e.weight/maxWeight)*2;
      if(isBridge && layers.bridges){{
        drawBezierEdge(pa[0],pa[1],pb[0],pb[1], dim?'rgba(74,154,201,0.05)':'rgba(74,154,201,0.35)', dim?thick:thick+1);
      }} else {{
        drawBezierEdge(pa[0],pa[1],pb[0],pb[1], dim?'rgba(255,255,255,0.015)':'rgba(255,255,255,0.07)', thick);
      }}
    }});
  }}

  // Tension lines (animated dashed gold)
  if(layers.tensions){{
    var dashOff = time * 12;
    (DATA.tensions||[]).forEach(function(t){{
      var pa = mapPos(t.a), pb = mapPos(t.b);
      var alpha = t.priority==='high'?0.45:t.priority==='medium'?0.25:0.12;
      if(selected && (t.a===selected||t.b===selected)) alpha = 0.7;
      var dim = isSearchDimmed(t.a) && isSearchDimmed(t.b);
      if(dim) alpha *= 0.15;
      cx.setLineDash([6,6]);
      cx.lineDashOffset = -dashOff;
      cx.strokeStyle = 'rgba(201,164,74,'+alpha+')';
      cx.lineWidth = t.priority==='high'?2:1;
      cx.beginPath(); cx.moveTo(pa[0],pa[1]); cx.lineTo(pb[0],pb[1]); cx.stroke();
    }});
    cx.setLineDash([]);
    cx.lineDashOffset = 0;
  }}

  // Redundancy lines
  if(layers.redundancies){{
    cx.setLineDash([2,6]);
    (DATA.redundancies||[]).forEach(function(r){{
      var pa = mapPos(r.a), pb = mapPos(r.b);
      var dim = isSearchDimmed(r.a) && isSearchDimmed(r.b);
      cx.strokeStyle = dim?'rgba(200,70,70,0.04)':'rgba(200,70,70,0.2)';
      cx.lineWidth = 1;
      cx.beginPath(); cx.moveTo(pa[0],pa[1]); cx.lineTo(pb[0],pb[1]); cx.stroke();
    }});
    cx.setLineDash([]);
  }}

  // Nodes
  nodeNames.forEach(function(name){{
    var p = mapPos(name);
    var r = nodeRadius(name);
    var col = nodeColor(name);
    var s = scores[name]||{{}};
    var dim = isSearchDimmed(name);
    var baseAlpha = dim ? 0.12 : 1;

    // Hub gold ring
    if(s.is_hub && !dim){{
      cx.strokeStyle = 'rgba(201,164,74,0.5)';
      cx.lineWidth = 2;
      cx.beginPath(); cx.arc(p[0],p[1],r+4,0,PI2); cx.stroke();
      // soft glow
      var grad = cx.createRadialGradient(p[0],p[1],r,p[0],p[1],r+12);
      grad.addColorStop(0,hexToRGBA(col,0.12));
      grad.addColorStop(1,'rgba(0,0,0,0)');
      cx.fillStyle = grad;
      cx.beginPath(); cx.arc(p[0],p[1],r+12,0,PI2); cx.fill();
    }}

    // Isolate red outline
    if(s.is_isolate && !dim){{
      cx.strokeStyle = 'rgba(224,85,85,0.6)';
      cx.lineWidth = 2;
      cx.setLineDash([3,3]);
      cx.beginPath(); cx.arc(p[0],p[1],r+3,0,PI2); cx.stroke();
      cx.setLineDash([]);
    }}

    // Bridge blue accent
    if(s.is_bridge && !s.is_hub && !dim){{
      cx.strokeStyle = 'rgba(74,154,201,0.5)';
      cx.lineWidth = 1.5;
      cx.beginPath(); cx.arc(p[0],p[1],r+3,0,PI2); cx.stroke();
    }}

    // Selection / hover highlight
    if((name===selected || name===hovered) && !dim){{
      var grad2 = cx.createRadialGradient(p[0],p[1],0,p[0],p[1],r+14);
      grad2.addColorStop(0,'rgba(201,164,74,0.2)');
      grad2.addColorStop(1,'rgba(0,0,0,0)');
      cx.fillStyle = grad2;
      cx.beginPath(); cx.arc(p[0],p[1],r+14,0,PI2); cx.fill();
    }}

    // Node fill
    cx.fillStyle = dim ? hexToRGBA(col,0.12) : col;
    cx.beginPath(); cx.arc(p[0],p[1],r,0,PI2); cx.fill();

    // Subtle inner highlight
    if(!dim){{
      var ig = cx.createRadialGradient(p[0]-r*0.3,p[1]-r*0.3,0,p[0],p[1],r);
      ig.addColorStop(0,'rgba(255,255,255,0.2)');
      ig.addColorStop(1,'rgba(255,255,255,0)');
      cx.fillStyle = ig;
      cx.beginPath(); cx.arc(p[0],p[1],r,0,PI2); cx.fill();
    }}

    // Labels
    if(layers.labels && !dim && (r>6 || name===hovered || name===selected)){{
      cx.fillStyle = name===selected?'#c9a44a':name===hovered?'#e8e4dc':'rgba(232,228,220,0.7)';
      cx.font = (name===selected||name===hovered)?'600 12px -apple-system,sans-serif':'11px -apple-system,sans-serif';
      cx.textAlign = 'center';
      cx.textBaseline = 'bottom';
      cx.fillText(name, p[0], p[1]-r-6);
    }}
  }});
}}

// --- Hit test ---
function hitTest(mx,my){{
  for(var i=nodeNames.length-1;i>=0;i--){{
    var p = mapPos(nodeNames[i]);
    var r = nodeRadius(nodeNames[i])+6;
    if((mx-p[0])*(mx-p[0])+(my-p[1])*(my-p[1]) < r*r) return nodeNames[i];
  }}
  return null;
}}

// --- Tooltip ---
function showTooltip(name,mx,my){{
  if(!name){{ tooltip.style.display='none'; return; }}
  var s = scores[name]||{{}};
  tooltip.querySelector('.tt-name').textContent = name;
  var lines = 'Degree: '+(s.degree||0);
  lines += ' | Cluster: '+(s.cluster>=0?s.cluster:'--');
  var roles = [];
  if(s.is_hub) roles.push('Hub');
  if(s.is_bridge) roles.push('Bridge');
  if(s.is_isolate) roles.push('Isolate');
  if(roles.length) lines += ' | '+roles.join(', ');
  tooltip.querySelector('.tt-body').textContent = lines;
  tooltip.style.display = 'block';
  var tw = tooltip.offsetWidth, th = tooltip.offsetHeight;
  var tx = mx+16, ty = my-10;
  if(tx+tw > W) tx = mx - tw - 10;
  if(ty+th > H) ty = my - th - 10;
  if(ty < 0) ty = 4;
  tooltip.style.left = tx+'px';
  tooltip.style.top = ty+'px';
}}

// --- Mouse events ---
cv.addEventListener('mousemove', function(e){{
  var r = cv.getBoundingClientRect();
  var mx = e.clientX-r.left, my = e.clientY-r.top;
  var hit = hitTest(mx,my);
  if(hit !== hovered){{ hovered = hit; }}
  showTooltip(hit, mx, my);
  cv.style.cursor = hit?'pointer':'default';
}});
cv.addEventListener('mouseleave', function(){{
  hovered = null;
  tooltip.style.display='none';
}});
cv.addEventListener('click', function(e){{
  var r = cv.getBoundingClientRect();
  var hit = hitTest(e.clientX-r.left, e.clientY-r.top);
  selected = (hit===selected)?null:hit;
  renderDetail(selected);
  // Switch to detail tab on click
  if(selected) activateTab('detail');
}});

// --- Animation loop ---
function animate(){{
  time += 0.016;
  draw();
  requestAnimationFrame(animate);
}}
requestAnimationFrame(animate);

// --- Tab system ---
var tabs = document.querySelectorAll('.tab');
var panes = document.querySelectorAll('.tab-pane');
function activateTab(name){{
  tabs.forEach(function(t){{ t.classList.toggle('active', t.dataset.tab===name); }});
  panes.forEach(function(p){{ p.classList.toggle('active', p.id==='pane-'+name); }});
}}
tabs.forEach(function(t){{
  t.addEventListener('click', function(){{ activateTab(this.dataset.tab); }});
}});

// --- Search ---
document.getElementById('search').addEventListener('input', function(){{
  searchTerm = this.value.toLowerCase().trim();
}});

// --- Build Overview pane ---
(function(){{
  var stats = DATA.stats||{{}};
  var health = DATA.health_score||0;
  var hCol = health>=70?'#4a9a6a':health>=40?'#d4a24a':'#e05555';
  var hColBg = health>=70?'rgba(74,154,106,0.1)':health>=40?'rgba(212,162,74,0.1)':'rgba(224,85,85,0.1)';
  var circumference = 2 * Math.PI * 54;
  var offset = circumference - (health/100)*circumference;
  var html = '';
  // SVG gauge
  html += '<div style="text-align:center;margin:8px 0 16px">';
  html += '<svg width="140" height="140" viewBox="0 0 140 140">';
  html += '<circle cx="70" cy="70" r="54" fill="none" stroke="rgba(255,255,255,0.04)" stroke-width="8"/>';
  html += '<circle cx="70" cy="70" r="54" fill="none" stroke="'+hCol+'" stroke-width="8" stroke-linecap="round" ';
  html += 'stroke-dasharray="'+circumference+'" stroke-dashoffset="'+offset+'" ';
  html += 'transform="rotate(-90 70 70)" style="transition:stroke-dashoffset 1.5s ease"/>';
  html += '<text x="70" y="66" text-anchor="middle" fill="'+hCol+'" font-size="28" font-weight="200" font-family="-apple-system,sans-serif">'+health+'</text>';
  html += '<text x="70" y="84" text-anchor="middle" fill="#555" font-size="10" font-family="-apple-system,sans-serif">HEALTH SCORE</text>';
  html += '</svg></div>';

  // Stats
  html += '<div class="section-title">Network Stats</div>';
  var statPairs = [['Nodes',stats.n_nodes||0],['Edges',stats.n_edges||0],['Clusters',stats.n_clusters||0],
    ['Avg Degree',stats.avg_degree||0],['Max Degree',stats.max_degree||0],['Hubs',stats.n_hubs||0],
    ['Isolates',stats.n_isolates||0],['Tensions',stats.n_tensions||0],['Bridges',stats.n_bridges||0]];
  statPairs.forEach(function(sp){{
    html += '<div class="stat-row"><span>'+sp[0]+'</span><span>'+sp[1]+'</span></div>';
  }});

  // Dynamics
  if(DATA.dynamics){{
    html += '<div class="section-title">Dynamics</div>';
    html += '<div class="stat-row"><span>Order (R)</span><span>'+DATA.dynamics.R+'</span></div>';
    html += '<div class="stat-row"><span>Regime</span><span style="color:'+(DATA.dynamics.regime==='coherent'?'#4a9a6a':'#e05555')+'">'+DATA.dynamics.regime+'</span></div>';
  }}

  // Layer toggles
  html += '<div class="section-title">Layers</div>';
  html += '<div class="layer-toggles">';
  var layerDefs = [['edges','Edges'],['tensions','Tensions'],['redundancies','Redundancies'],['bridges','Bridges'],['hulls','Clusters'],['labels','Labels']];
  layerDefs.forEach(function(ld){{
    html += '<div class="ltoggle'+(layers[ld[0]]?' on':'')+'" data-layer="'+ld[0]+'"><span class="ldot"></span>'+ld[1]+'</div>';
  }});
  html += '</div>';

  document.getElementById('pane-overview').innerHTML = html;

  // Toggle clicks
  document.querySelectorAll('.ltoggle').forEach(function(el){{
    el.addEventListener('click', function(){{
      var l = this.dataset.layer;
      layers[l] = !layers[l];
      this.classList.toggle('on');
    }});
  }});
}})();

// --- Build Actions pane ---
(function(){{
  var html = '<div class="section-title">Prioritized Recommendations</div>';
  var actions = DATA.action_plan||[];
  if(!actions.length) html += '<div class="empty-state">No actions needed</div>';
  actions.forEach(function(a,i){{
    html += '<div class="action-card '+a.priority+'">';
    html += '<div class="act-badge">'+a.priority+'</div>';
    html += '<div class="act-text">'+a.action+'</div>';
    html += '<div class="act-reason">'+a.reason+'</div>';
    html += '</div>';
  }});
  document.getElementById('pane-actions').innerHTML = html;
}})();

// --- Build Clusters pane ---
(function(){{
  var html = '<div class="section-title">Cluster Membership</div>';
  var clusters = DATA.clusters||[];
  if(!clusters.length) html += '<div class="empty-state">No clusters detected</div>';
  clusters.forEach(function(c,i){{
    var col = COLORS[i%COLORS.length];
    html += '<div class="cluster-item">';
    html += '<div class="cluster-badge" style="background:'+col+'"></div>';
    html += '<div class="cluster-members"><strong>Cluster '+i+'</strong> ('+c.size+' members)<br>';
    html += c.members.join(', ');
    html += '</div></div>';
  }});
  document.getElementById('pane-clusters').innerHTML = html;
}})();

// --- Detail pane (updates on click) ---
function renderDetail(name){{
  var pane = document.getElementById('pane-detail');
  if(!name){{
    pane.innerHTML = '<div class="empty-state">Click a node on the graph to see details</div>';
    return;
  }}
  var s = scores[name]||{{}};
  var col = nodeColor(name);
  var html = '<div class="node-detail-card">';
  html += '<div class="nd-name"><span style="display:inline-block;width:12px;height:12px;border-radius:50%;background:'+col+';margin-right:8px;vertical-align:middle"></span>'+name+'</div>';

  // Roles
  html += '<div class="nd-roles">';
  if(s.is_hub) html += '<span class="nd-role hub">Hub</span>';
  if(s.is_bridge) html += '<span class="nd-role bridge">Bridge</span>';
  if(s.is_isolate) html += '<span class="nd-role isolate">Isolate</span>';
  if(!s.is_hub&&!s.is_bridge&&!s.is_isolate) html += '<span class="nd-role" style="background:rgba(255,255,255,0.05);color:#777">Member</span>';
  html += '</div>';

  // Stats
  html += '<div class="stat-row"><span>Degree</span><span>'+( s.degree||0)+'</span></div>';
  html += '<div class="stat-row"><span>Cluster</span><span>'+( s.cluster>=0?s.cluster:'--')+'</span></div>';
  html += '<div class="stat-row"><span>Tension Count</span><span>'+(s.tension_count||0)+'</span></div>';

  // Connections
  var connections = [];
  edgeList.forEach(function(e){{
    if(e.a===name) connections.push(e.b);
    else if(e.b===name) connections.push(e.a);
  }});
  if(connections.length){{
    html += '<div class="section-title" style="margin-top:12px">Connections ('+connections.length+')</div>';
    connections.slice(0,15).forEach(function(c){{
      var cc = nodeColor(c);
      html += '<div style="font-size:12px;color:#888;padding:2px 0"><span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:'+cc+';margin-right:6px;vertical-align:middle"></span>'+c+'</div>';
    }});
    if(connections.length>15) html += '<div style="font-size:11px;color:#555;padding:2px 0">+'+(connections.length-15)+' more</div>';
  }}

  // Tensions
  var myTensions = (DATA.tensions||[]).filter(function(t){{ return t.a===name||t.b===name; }});
  if(myTensions.length){{
    html += '<div class="section-title" style="margin-top:12px">Missing Connections</div>';
    myTensions.slice(0,8).forEach(function(t){{
      var other = t.a===name?t.b:t.a;
      html += '<div class="nd-tension-item"><span>'+other+'</span> &mdash; tension: '+t.tension;
      if(t.priority) html += ' <span style="font-size:10px;color:'+(t.priority==='high'?'#e05555':t.priority==='medium'?'#d4a24a':'#4a9a6a')+'">'+t.priority+'</span>';
      html += '</div>';
    }});
  }}

  // Recommendations for this node
  var myActions = (DATA.action_plan||[]).filter(function(a){{
    return a.action && a.action.indexOf(name)>=0;
  }});
  if(myActions.length){{
    html += '<div class="section-title" style="margin-top:12px">Recommendations</div>';
    myActions.forEach(function(a){{
      html += '<div class="action-card '+a.priority+'" style="margin:4px 0">';
      html += '<div class="act-text">'+a.action+'</div>';
      html += '</div>';
    }});
  }}

  html += '</div>';
  pane.innerHTML = html;
}}

}})();
</script>
</body>
</html>'''
