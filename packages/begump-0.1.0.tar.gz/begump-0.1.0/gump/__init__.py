"""
GUMP — Grand Unified Music Project
=====================================
One framework. Four quantities. Everything computable.

    K = coupling strength     (how strongly things connect)
    R = order parameter       (how synchronized they are)
    E = energy cost           (what it costs in joules)
    T = tension               (what wants to connect but hasn't)

Works on: chips, music, proteins, markets, compilers, memory,
neural nets, primes, quantum circuits, organizations, and the body.

Quick start:
    import gump

    # Find what's missing in any graph
    tensions = gump.tensions(n_nodes, edges)

    # Place anything optimally
    positions = gump.place(n_nodes, edges, width, height)

    # Track energy cost of computation
    tracker = gump.EnergyTracker()

    # Detect phase transitions
    R, regime = gump.detect_crash(time_series)

    # Detect grokking in training
    grokked, epoch = gump.watch_training(losses, accuracies)

    # Analyze music thermodynamically
    cost = gump.interval_cost(3, 2)  # perfect fifth = 1.79 nats

pip install gump
https://github.com/LacobusGump/gump

Products:
    from gump.orgxray import scan, visualize    # org X-ray with interactive viz
    from gump.tensionmap import scan           # org analysis (core)
    from gump.grokwatch import GrokWatch       # AI training monitor
    from gump.crashwatch import CrashWatch     # financial early warning
    from gump.chipfast import design           # open-source chip layout
    from gump.energylens import profile        # computational thermodynamics
    from gump.learnpath import curriculum      # curriculum optimizer
    from gump.learnengine import LearnEngine   # adaptive learning with grokking detection
    from gump.foldwatch import analyze         # protein misfolding analysis
    from gump.foldwatch_app import report      # protein analysis with interactive viz
    from gump.music import analyze_melody      # thermodynamic music theory
    from gump.knowledge import KnowledgeEngine  # compress anything, recall instantly
    from gump.sensor import UniversalSensor    # K/R/E/T of any time series
    from gump.aitrainer import AITrainer       # train AI cheaper with grokking detection
    from gump.chipfast_app import design_report # chip layout with interactive viz
    from gump.mind import Mind                 # thinking architecture
"""

__version__ = '0.1.0'

from gump.core import (
    tensions,
    redundancies,
    place,
    clusters,
    resolution_path,
    EnergyTracker,
    interval_cost,
    coupling_energy,
    detect_crash,
    watch_training,
    K_CEILING,
    PHI,
    LANDAUER_PER_BIT,
)
