"""
FOLDWATCH — Protein structure analysis from sequence
=======================================================
Spectral tension on amino acid chains predicts:
  - Hydrophobic core location
  - Secondary structure tendency (helix vs sheet vs coil)
  - Disulfide bond candidates
  - Aggregation-prone regions
  - Misfolding risk

    from gump.foldwatch import analyze
    result = analyze('FVNQHLCGSHLVEALYLVCGERGFFYTPKT')
"""
import numpy as np
from gump.core import _TensionDetector

# ═══ AMINO ACID PROPERTY TABLES ═══

# Hydrophobicity (Kyte-Doolittle, normalized 0-1)
HYDRO = {
    'A': 0.70, 'R': 0.00, 'N': 0.11, 'D': 0.11, 'C': 0.78,
    'E': 0.11, 'Q': 0.11, 'G': 0.46, 'H': 0.14, 'I': 1.00,
    'L': 0.92, 'K': 0.07, 'M': 0.71, 'F': 0.81, 'P': 0.32,
    'S': 0.41, 'T': 0.45, 'W': 0.40, 'Y': 0.36, 'V': 0.97,
}

# Helix propensity (Chou-Fasman, normalized)
HELIX_PROP = {
    'A': 1.42, 'R': 0.98, 'N': 0.67, 'D': 1.01, 'C': 0.70,
    'E': 1.51, 'Q': 1.11, 'G': 0.57, 'H': 1.00, 'I': 1.08,
    'L': 1.21, 'K': 1.16, 'M': 1.45, 'F': 1.13, 'P': 0.57,
    'S': 0.77, 'T': 0.83, 'W': 1.08, 'Y': 0.69, 'V': 1.06,
}

# Sheet propensity (Chou-Fasman)
SHEET_PROP = {
    'A': 0.83, 'R': 0.93, 'N': 0.89, 'D': 0.54, 'C': 1.19,
    'E': 0.37, 'Q': 1.10, 'G': 0.75, 'H': 0.87, 'I': 1.60,
    'L': 1.30, 'K': 0.74, 'M': 1.05, 'F': 1.38, 'P': 0.55,
    'S': 0.75, 'T': 1.19, 'W': 1.37, 'Y': 1.47, 'V': 1.70,
}

# Charge at pH 7
CHARGE = {
    'R': +1, 'K': +1, 'H': +0.1,  # positive
    'D': -1, 'E': -1,              # negative
}

# Aggregation propensity (simplified TANGO-like)
AGG_PROP = {
    'I': 0.9, 'V': 0.85, 'L': 0.8, 'F': 0.75, 'Y': 0.6,
    'W': 0.5, 'A': 0.4, 'M': 0.4, 'C': 0.3, 'T': 0.2,
    'S': 0.1, 'G': 0.1, 'P': 0.0, 'N': 0.0, 'Q': 0.0,
    'D': -0.2, 'E': -0.2, 'K': -0.3, 'R': -0.3, 'H': -0.1,
}

VALID_AA = set('ACDEFGHIKLMNPQRSTVWY')


def analyze(sequence):
    """Full protein structure analysis from amino acid sequence.

    Args:
        sequence: string of single-letter amino acid codes

    Returns comprehensive analysis dict.
    """
    seq = sequence.upper().strip()

    # Validate
    invalid = [c for c in seq if c not in VALID_AA]
    if invalid:
        return {'error': f'Invalid amino acids: {set(invalid)}. Use single-letter codes.'}
    if len(seq) < 5:
        return {'error': 'Sequence too short (minimum 5 residues)'}

    n = len(seq)

    # ═══ Build interaction graph ═══
    edges = []
    weights = []

    # Backbone bonds
    for i in range(n - 1):
        edges.append((i, i + 1))
        weights.append(3.0)

    # Hydrophobic interactions (i+3 to i+50)
    for i in range(n):
        hi = HYDRO.get(seq[i], 0.5)
        for j in range(i + 3, min(i + 50, n)):
            hj = HYDRO.get(seq[j], 0.5)
            if hi > 0.55 and hj > 0.55:
                strength = hi * hj * 1.5
                edges.append((i, j))
                weights.append(strength)

    # Salt bridges (opposite charges attract)
    pos_res = [i for i in range(n) if seq[i] in 'RK']
    neg_res = [i for i in range(n) if seq[i] in 'DE']
    for i in pos_res:
        for j in neg_res:
            if abs(i - j) >= 3:
                edges.append((min(i, j), max(i, j)))
                weights.append(2.0)

    # Disulfide bond candidates (Cys-Cys)
    cys_positions = [i for i in range(n) if seq[i] == 'C']
    disulfide_candidates = []
    for ii in range(len(cys_positions)):
        for jj in range(ii + 1, len(cys_positions)):
            ci, cj = cys_positions[ii], cys_positions[jj]
            if abs(ci - cj) >= 4:  # minimum loop size
                disulfide_candidates.append((ci, cj))
                edges.append((ci, cj))
                weights.append(4.0)  # strong bond

    # Proline kinks (Pro breaks helices)
    pro_positions = [i for i in range(n) if seq[i] == 'P']

    # ═══ Spectral analysis ═══
    td = _TensionDetector(n, edges, weights, n_vecs=min(8, n - 2))

    # ═══ Core/surface from spectral center ═══
    center = np.mean(td.coords, axis=0)
    dists = np.array([float(np.linalg.norm(td.coords[i] - center)) for i in range(n)])
    median_dist = np.median(dists)

    core_mask = dists < median_dist
    surface_mask = ~core_mask

    hydro_arr = np.array([HYDRO.get(aa, 0.5) for aa in seq])
    core_hydro = float(np.mean(hydro_arr[core_mask])) if np.any(core_mask) else 0
    surface_hydro = float(np.mean(hydro_arr[surface_mask])) if np.any(surface_mask) else 0
    has_core = core_hydro > surface_hydro + 0.05

    # ═══ Secondary structure prediction (GOR-inspired with nucleation) ═══
    # Phase 1: raw propensity scores per residue
    window = 7
    helix_raw = np.zeros(n)
    sheet_raw = np.zeros(n)
    for i in range(n):
        start = max(0, i - window // 2)
        end = min(n, i + window // 2 + 1)
        segment = seq[start:end]
        helix_raw[i] = np.mean([HELIX_PROP.get(aa, 1.0) for aa in segment])
        sheet_raw[i] = np.mean([SHEET_PROP.get(aa, 1.0) for aa in segment])

        # Helix breakers: Pro and Gly strongly disfavor helix
        if seq[i] == 'P':
            helix_raw[i] *= 0.2
        elif seq[i] == 'G':
            helix_raw[i] *= 0.6
        # Pro at i+1 also breaks helix at i
        if i + 1 < n and seq[i + 1] == 'P':
            helix_raw[i] *= 0.5

        # Amphipathic helix signal: hydrophobic every 3-4 residues = helix
        if i >= 3:
            h_periodic = sum(1 for j in [i, i-3, i-4] if j >= 0 and HYDRO.get(seq[j], 0) > 0.6)
            if h_periodic >= 2:
                helix_raw[i] *= 1.15

        # Sheet signal: alternating hydrophobic/hydrophilic = beta strand
        if 1 <= i < n - 1:
            hi = HYDRO.get(seq[i], 0.5)
            h_prev = HYDRO.get(seq[i-1], 0.5)
            h_next = HYDRO.get(seq[i+1], 0.5) if i+1 < n else 0.5
            # Alternating pattern: high-low-high or low-high-low
            if (hi > 0.6 and h_prev < 0.4 and h_next < 0.4) or \
               (hi < 0.4 and h_prev > 0.6 and h_next > 0.6):
                sheet_raw[i] *= 1.1

    # Phase 2: nucleation — helices need 4+ consecutive high-propensity residues
    HELIX_NUCLEATION = 4
    HELIX_THRESHOLD = 1.05
    SHEET_NUCLEATION = 3
    SHEET_THRESHOLD = 1.05

    # Find helix nucleation sites
    # Key: helix must WIN over sheet by a margin to nucleate
    helix_nucleated = np.zeros(n, dtype=bool)
    run_start = -1
    for i in range(n):
        helix_wins = helix_raw[i] > HELIX_THRESHOLD and helix_raw[i] > sheet_raw[i]
        if helix_wins:
            if run_start < 0:
                run_start = i
            if i - run_start + 1 >= HELIX_NUCLEATION:
                helix_nucleated[run_start:i+1] = True
        else:
            run_start = -1

    # Extend helix regions: once nucleated, residues with modest propensity join
    for i in range(n):
        if not helix_nucleated[i] and helix_raw[i] > 0.9:
            # Check if adjacent to nucleated helix
            if (i > 0 and helix_nucleated[i-1]) or (i < n-1 and helix_nucleated[i+1]):
                helix_nucleated[i] = True

    # Find sheet nucleation sites
    sheet_nucleated = np.zeros(n, dtype=bool)
    run_start = -1
    for i in range(n):
        if sheet_raw[i] > SHEET_THRESHOLD and not helix_nucleated[i]:
            if run_start < 0:
                run_start = i
            if i - run_start + 1 >= SHEET_NUCLEATION:
                sheet_nucleated[run_start:i+1] = True
        else:
            run_start = -1

    # Phase 3: assign
    ss_prediction = []
    for i in range(n):
        if helix_nucleated[i]:
            ss = 'H'
        elif sheet_nucleated[i]:
            ss = 'E'
        else:
            ss = 'C'
        ss_prediction.append(ss)

    ss_string = ''.join(ss_prediction)
    helix_pct = ss_prediction.count('H') / n * 100
    sheet_pct = ss_prediction.count('E') / n * 100
    coil_pct = ss_prediction.count('C') / n * 100

    # ═══ Aggregation-prone regions ═══
    agg_window = 7
    agg_scores = []
    agg_regions = []
    for i in range(n):
        start = max(0, i - agg_window // 2)
        end = min(n, i + agg_window // 2 + 1)
        score = np.mean([AGG_PROP.get(aa, 0) for aa in seq[start:end]])
        agg_scores.append(score)
        if score > 0.35:
            if not agg_regions or agg_regions[-1]['end'] < i - 1:
                agg_regions.append({'start': i, 'end': i, 'max_score': score})
            else:
                agg_regions[-1]['end'] = i
                agg_regions[-1]['max_score'] = max(agg_regions[-1]['max_score'], score)

    # ═══ Fold tensions ═══
    tensions = td.tensions(top_k=15)
    fold_tensions = []
    for d, i, j, score in tensions:
        if i < n and j < n:
            fold_tensions.append({
                'residue_a': i,
                'residue_b': j,
                'aa_a': seq[i],
                'aa_b': seq[j],
                'seq_distance': abs(j - i),
                'tension': score,
                'type': 'hydrophobic' if HYDRO.get(seq[i], 0) > 0.6 and HYDRO.get(seq[j], 0) > 0.6
                        else 'electrostatic' if (seq[i] in 'RKDE' and seq[j] in 'RKDE')
                        else 'other',
            })

    # ═══ Structural domains ═══
    try:
        labels, k = td.clusters()
        domains = []
        for c in range(k):
            members = [i for i in range(n) if labels[i] == c]
            if len(members) > 2:
                dom_seq = ''.join(seq[i] for i in members)
                domains.append({
                    'start': min(members),
                    'end': max(members),
                    'size': len(members),
                    'avg_hydro': float(np.mean([HYDRO.get(seq[i], 0.5) for i in members])),
                    'dominant_ss': max(set(ss_prediction[i] for i in members),
                                      key=lambda x: sum(1 for i in members if ss_prediction[i] == x)),
                })
    except Exception:
        domains = [{'start': 0, 'end': n - 1, 'size': n}]

    # ═══ Misfolding risk assessment ═══
    risk_factors = 0
    risk_reasons = []

    # High long-range tension
    long_range_tensions = [t for t in fold_tensions if t['seq_distance'] > n / 3 and t['tension'] > 2]
    if len(long_range_tensions) > 3:
        risk_factors += 2
        risk_reasons.append(f'{len(long_range_tensions)} high long-range tensions')

    # Aggregation-prone regions
    if len(agg_regions) > 2:
        risk_factors += 1
        risk_reasons.append(f'{len(agg_regions)} aggregation-prone regions')
    if len(agg_regions) > 0:
        # Any aggregation region is a risk signal
        total_agg_len = sum(r.get('end', 0) - r.get('start', 0) + 1 for r in agg_regions)
        if total_agg_len > n * 0.3:
            risk_factors += 1
            risk_reasons.append(f'aggregation regions span {total_agg_len}/{n} residues ({total_agg_len/n*100:.0f}%)')
        # Large aggregation regions (>5 consecutive residues) are especially dangerous
        large_agg = [r for r in agg_regions if r.get('end', 0) - r.get('start', 0) >= 5]
        if large_agg:
            risk_factors += 1
            risk_reasons.append(f'{len(large_agg)} large aggregation stretch(es) (6+ residues)')

    # Repeat sequences (polyQ, polyA, etc.) — known aggregation drivers
    max_repeat = 1
    current_repeat = 1
    for i in range(1, n):
        if seq[i] == seq[i-1]:
            current_repeat += 1
            max_repeat = max(max_repeat, current_repeat)
        else:
            current_repeat = 1
    if max_repeat >= 8:
        risk_factors += 2
        risk_reasons.append(f'homopolymeric repeat of {max_repeat} residues (aggregation driver)')
    elif max_repeat >= 5:
        risk_factors += 1
        risk_reasons.append(f'homopolymeric repeat of {max_repeat} residues')

    # High overall hydrophobicity (aggregation-prone)
    avg_hydro = np.mean([HYDRO.get(aa, 0.5) for aa in seq])
    if avg_hydro > 0.7:
        risk_factors += 1
        risk_reasons.append(f'high average hydrophobicity ({avg_hydro:.2f})')

    # Low net charge relative to length (charge-poor = aggregation-prone)
    net_abs = abs(sum(CHARGE.get(aa, 0) for aa in seq))
    charge_density = net_abs / n
    if charge_density < 0.02 and n > 15:
        risk_factors += 1
        risk_reasons.append(f'very low charge density ({charge_density:.3f}) — charge-poor sequences aggregate')

    # Low helix/sheet content (mostly coil = unstable)
    if coil_pct > 70:
        risk_factors += 1
        risk_reasons.append(f'{coil_pct:.0f}% coil (low structured content)')

    # No hydrophobic core
    if not has_core:
        risk_factors += 1
        risk_reasons.append('no hydrophobic core detected')

    # Many prolines (breaks secondary structure)
    pro_pct = len(pro_positions) / n * 100
    if pro_pct > 10:
        risk_factors += 1
        risk_reasons.append(f'{pro_pct:.0f}% proline (helix breaker)')

    if risk_factors >= 4:
        risk = 'high'
    elif risk_factors >= 2:
        risk = 'medium'
    else:
        risk = 'low'

    # ═══ Charge distribution ═══
    net_charge = sum(CHARGE.get(aa, 0) for aa in seq)
    pos_count = sum(1 for aa in seq if aa in 'RK')
    neg_count = sum(1 for aa in seq if aa in 'DE')

    return {
        'sequence_length': n,
        'composition': {aa: seq.count(aa) for aa in sorted(set(seq))},

        # Core/surface
        'has_hydrophobic_core': has_core,
        'core_hydrophobicity': round(core_hydro, 3),
        'surface_hydrophobicity': round(surface_hydro, 3),

        # Secondary structure
        'secondary_structure': ss_string,
        'helix_pct': round(helix_pct, 1),
        'sheet_pct': round(sheet_pct, 1),
        'coil_pct': round(coil_pct, 1),

        # Domains
        'n_domains': len(domains),
        'domains': domains,

        # Special features
        'disulfide_candidates': disulfide_candidates,
        'proline_positions': pro_positions,
        'aggregation_regions': agg_regions,
        'net_charge': round(net_charge, 1),
        'positive_residues': pos_count,
        'negative_residues': neg_count,

        # Folding analysis
        'fold_tensions': fold_tensions[:10],
        'misfolding_risk': risk,
        'risk_factors': risk_reasons,

        # Raw spectral data
        'n_interactions': len(edges),
    }


def compare(seq_a, seq_b):
    """Compare two sequences structurally."""
    a = analyze(seq_a)
    b = analyze(seq_b)
    if 'error' in a or 'error' in b:
        return {'error': a.get('error') or b.get('error')}

    return {
        'length_a': a['sequence_length'],
        'length_b': b['sequence_length'],
        'helix_diff': abs(a['helix_pct'] - b['helix_pct']),
        'sheet_diff': abs(a['sheet_pct'] - b['sheet_pct']),
        'core_a': a['has_hydrophobic_core'],
        'core_b': b['has_hydrophobic_core'],
        'risk_a': a['misfolding_risk'],
        'risk_b': b['misfolding_risk'],
        'charge_a': a['net_charge'],
        'charge_b': b['net_charge'],
    }
