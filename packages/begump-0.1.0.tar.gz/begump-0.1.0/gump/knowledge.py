"""
KNOWLEDGE ENGINE — Compress anything. Recall instantly. Understand.
=====================================================================
Feed it text. It extracts structure in one pass. Ask it anything.

    from gump.knowledge import KnowledgeEngine

    engine = KnowledgeEngine()
    engine.absorb("The mitochondria is the powerhouse of the cell.")
    engine.absorb("Cells divide through mitosis. Each daughter cell gets a copy.")
    engine.absorb("ATP is produced in the mitochondria through oxidative phosphorylation.")

    # What does it know?
    print(engine.recall('mitochondria'))  # → connections to ATP, cell, powerhouse
    print(engine.tensions())              # → what WANTS to connect but hasn't
    print(engine.status())                # → how much it knows

    # Interactive report
    html = engine.visualize()

Built on: gump.core (tensions, placement, clusters) + trigram extraction
"""

import json
import re
import time
import numpy as np
from gump.core import _TensionDetector
from gump.k_runtime import place as spectral_place


class KnowledgeEngine:
    """Compress text into a knowledge graph. Recall by resonance."""

    def __init__(self):
        self.concepts = {}      # word → {count, connections, first_seen, contexts}
        self.edges = {}         # (word_a, word_b) → weight
        self.documents = []     # raw texts absorbed
        self._total_words = 0
        self._absorb_count = 0

    def absorb(self, text):
        """Extract knowledge from text. One pass. No training."""
        if not text or not text.strip():
            return

        self._absorb_count += 1
        self.documents.append(text[:500])  # store truncated

        # Tokenize
        words = re.findall(r'[a-z]+', text.lower())
        words = [w for w in words if len(w) > 2 and w not in _STOP_WORDS]
        self._total_words += len(words)

        # Update concept frequencies
        for w in words:
            if w not in self.concepts:
                self.concepts[w] = {
                    'count': 0, 'connections': set(),
                    'first_seen': self._absorb_count,
                    'contexts': [],
                }
            self.concepts[w]['count'] += 1

        # Co-occurrence within window = connection
        window = 5
        for i, w in enumerate(words):
            for j in range(max(0, i - window), min(len(words), i + window + 1)):
                if i != j:
                    other = words[j]
                    if w != other:
                        pair = tuple(sorted([w, other]))
                        self.edges[pair] = self.edges.get(pair, 0) + 1
                        self.concepts[w]['connections'].add(other)

        # Store context snippets for top concepts
        sentences = re.split(r'[.!?]+', text)
        for sent in sentences:
            sent = sent.strip()
            if len(sent) > 10:
                sent_words = set(re.findall(r'[a-z]+', sent.lower()))
                for w in sent_words:
                    if w in self.concepts and len(self.concepts[w]['contexts']) < 5:
                        self.concepts[w]['contexts'].append(sent[:200])

    def recall(self, query, top_k=10):
        """Recall knowledge related to a query. Returns connected concepts."""
        words = re.findall(r'[a-z]+', query.lower())
        words = [w for w in words if w in self.concepts]

        if not words:
            return {'query': query, 'found': False, 'results': []}

        # Spread activation from query words
        activation = {}
        for w in words:
            activation[w] = activation.get(w, 0) + 5.0  # seed
            for conn in self.concepts[w]['connections']:
                pair = tuple(sorted([w, conn]))
                weight = self.edges.get(pair, 0)
                activation[conn] = activation.get(conn, 0) + weight * 0.5

        # Rank by activation, exclude query words
        ranked = sorted(activation.items(), key=lambda x: -x[1])
        results = []
        for concept, score in ranked[:top_k]:
            c = self.concepts.get(concept, {})
            results.append({
                'concept': concept,
                'relevance': round(score, 2),
                'frequency': c.get('count', 0),
                'connections': len(c.get('connections', [])),
                'context': c.get('contexts', [''])[0] if c.get('contexts') else '',
            })

        return {'query': query, 'found': True, 'results': results}

    def tensions(self, top_k=10):
        """Find knowledge gaps — concepts that WANT to connect."""
        if len(self.concepts) < 3 or len(self.edges) < 2:
            return []

        # Build graph
        concept_list = sorted(self.concepts.keys(),
                              key=lambda w: -self.concepts[w]['count'])[:200]
        idx = {w: i for i, w in enumerate(concept_list)}
        n = len(concept_list)

        graph_edges = []
        graph_weights = []
        for (a, b), w in self.edges.items():
            if a in idx and b in idx:
                graph_edges.append((idx[a], idx[b]))
                graph_weights.append(w)

        if len(graph_edges) < 2:
            return []

        td = _TensionDetector(n, graph_edges, graph_weights)
        raw = td.tensions(top_k)

        return [{
            'concept_a': concept_list[i],
            'concept_b': concept_list[j],
            'tension': round(score, 3),
            'insight': f'"{concept_list[i]}" and "{concept_list[j]}" are structurally related '
                       f'but never appear together in your text',
        } for d, i, j, score in raw if i < n and j < n]

    def clusters(self):
        """Find natural topic clusters in the knowledge."""
        if len(self.concepts) < 5:
            return []

        concept_list = sorted(self.concepts.keys(),
                              key=lambda w: -self.concepts[w]['count'])[:200]
        idx = {w: i for i, w in enumerate(concept_list)}
        n = len(concept_list)

        graph_edges = []
        graph_weights = []
        for (a, b), w in self.edges.items():
            if a in idx and b in idx:
                graph_edges.append((idx[a], idx[b]))
                graph_weights.append(w)

        if len(graph_edges) < 2:
            return [concept_list]

        td = _TensionDetector(n, graph_edges, graph_weights)
        try:
            labels, k = td.clusters()
            groups = []
            for c in range(k):
                members = [concept_list[i] for i in range(n) if labels[i] == c]
                if members:
                    groups.append(sorted(members, key=lambda w: -self.concepts[w]['count']))
            return sorted(groups, key=len, reverse=True)
        except Exception:
            return [concept_list]

    def status(self):
        """Knowledge status."""
        return {
            'n_concepts': len(self.concepts),
            'n_connections': len(self.edges),
            'n_documents': len(self.documents),
            'total_words': self._total_words,
            'top_concepts': sorted(
                [(w, c['count'], len(c['connections']))
                 for w, c in self.concepts.items()],
                key=lambda x: -x[1]
            )[:20],
        }

    def visualize(self):
        """Generate interactive knowledge graph (Obsidian/Kumu style)."""
        if len(self.concepts) < 3:
            return '<html><body style="background:#08080d;color:#e8e4dc;font-family:Georgia;padding:40px;"><h1 style="color:#c9a44a;">Not enough knowledge yet</h1><p>Absorb more text.</p></body></html>'

        concept_list = sorted(self.concepts.keys(),
                              key=lambda w: -self.concepts[w]['count'])[:40]
        idx = {w: i for i, w in enumerate(concept_list)}
        n = len(concept_list)

        graph_edges = []
        graph_weights = []
        edges_for_viz = []
        max_edge_w = 1
        for (a, b), w in self.edges.items():
            if a in idx and b in idx:
                graph_edges.append((idx[a], idx[b]))
                graph_weights.append(w)
                edges_for_viz.append([idx[a], idx[b], w])
                if w > max_edge_w:
                    max_edge_w = w

        try:
            positions = spectral_place(n, graph_edges, 800, 600, graph_weights)
            pos_list = [[round(float(positions[i][0]), 1), round(float(positions[i][1]), 1)]
                         for i in range(n)]
        except Exception:
            pos_list = [[round(float(np.random.rand() * 800), 1),
                         round(float(np.random.rand() * 600), 1)] for _ in range(n)]

        tensions = self.tensions(15)
        clusters_data = self.clusters()
        cluster_map = {}
        for ci, group in enumerate(clusters_data):
            for w in group:
                if w in idx:
                    cluster_map[idx[w]] = ci

        # Build contexts for each concept (for detail panel)
        concept_contexts = {}
        for w in concept_list:
            ctxs = self.concepts[w].get('contexts', [])
            concept_contexts[w] = ctxs[:5]

        data = {
            'concepts': [{'word': w, 'count': self.concepts[w]['count'],
                          'connections': len(self.concepts[w]['connections']),
                          'cluster': cluster_map.get(idx[w], 0),
                          'contexts': concept_contexts.get(w, [])}
                         for w in concept_list],
            'edges': edges_for_viz,
            'positions': pos_list,
            'tensions': tensions,
            'clusters': [list(g[:15]) for g in clusters_data[:12]],
            'status': self.status(),
            'max_edge_weight': max_edge_w,
        }
        data_json = json.dumps(data, default=str)
        st = data['status']

        return f'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Knowledge Engine</title>
<style>
*{{margin:0;padding:0;box-sizing:border-box;}}
body{{background:#08080d;color:#e8e4dc;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Georgia,serif;display:flex;height:100vh;overflow:hidden;}}
#canvas-wrap{{flex:1;position:relative;overflow:hidden;}}
canvas{{display:block;width:100%;height:100%;cursor:default;}}
#search-overlay{{position:absolute;top:16px;left:16px;right:16px;z-index:10;}}
#search-overlay input{{width:100%;background:#0d0d14dd;border:1px solid #ffffff10;color:#e8e4dc;
  font-family:-apple-system,Georgia,serif;font-size:0.85em;padding:12px 18px;border-radius:24px;
  outline:none;backdrop-filter:blur(12px);transition:border-color 0.2s;}}
#search-overlay input:focus{{border-color:#c9a44a50;}}
#search-overlay input::placeholder{{color:#555;}}
#panel{{width:360px;background:#0d0d14;border-left:1px solid #ffffff08;overflow-y:auto;padding:0;display:flex;flex-direction:column;}}
.panel-header{{padding:24px 20px 0;}}
h1{{font-size:1.3em;font-weight:300;color:#c9a44a;letter-spacing:0.08em;margin-bottom:2px;}}
.sub{{font-size:0.6em;color:#444;letter-spacing:0.15em;margin-bottom:12px;}}
.tabs{{display:flex;border-bottom:1px solid #ffffff08;padding:0 20px;}}
.tab{{padding:10px 14px;font-size:0.72em;color:#666;letter-spacing:0.08em;text-transform:uppercase;cursor:pointer;border-bottom:2px solid transparent;transition:all 0.2s;}}
.tab:hover{{color:#999;}}
.tab.active{{color:#c9a44a;border-bottom-color:#c9a44a;}}
.tab-content{{display:none;padding:16px 20px;flex:1;overflow-y:auto;}}
.tab-content.active{{display:block;}}
h2{{font-size:0.72em;font-weight:600;color:#666;letter-spacing:0.12em;text-transform:uppercase;margin:16px 0 10px;}}
h2:first-child{{margin-top:0;}}
.stat{{display:flex;justify-content:space-between;font-size:0.78em;color:#888;padding:4px 0;border-bottom:1px solid #ffffff04;}}
.stat span:last-child{{color:#e8e4dc;font-weight:500;}}
.tension-item{{background:#111118;border-left:2px solid #c9a44a30;padding:8px 12px;margin:4px 0;border-radius:0 8px 8px 0;cursor:pointer;transition:background 0.15s;}}
.tension-item:hover{{background:#161620;}}
.tension-item .pair{{font-size:0.8em;color:#c9a44a;font-weight:500;}}
.tension-item .insight{{font-size:0.7em;color:#666;margin-top:3px;line-height:1.4;}}
.cluster-group{{margin:8px 0;}}
.cluster-label{{font-size:0.7em;color:#888;margin-bottom:4px;}}
.cluster-tags{{display:flex;flex-wrap:wrap;gap:4px;}}
.cluster-tag{{font-size:0.68em;padding:3px 8px;border-radius:10px;background:#ffffff06;color:#bbb;cursor:pointer;transition:all 0.15s;}}
.cluster-tag:hover{{background:#ffffff12;color:#e8e4dc;}}
.concept-detail{{background:#111118;border-radius:10px;padding:16px;margin:8px 0;display:none;}}
.concept-detail.visible{{display:block;}}
.concept-detail .cd-word{{font-size:1.1em;color:#c9a44a;font-weight:600;margin-bottom:8px;}}
.concept-detail .cd-stat{{font-size:0.72em;color:#888;margin:2px 0;}}
.concept-detail .cd-ctx{{font-size:0.7em;color:#777;padding:6px 10px;background:#0a0a12;border-radius:6px;margin:4px 0;line-height:1.5;font-style:italic;}}
.search-result{{padding:6px 10px;border-radius:6px;cursor:pointer;transition:background 0.15s;}}
.search-result:hover{{background:#ffffff08;}}
.search-result .sr-word{{color:#c9a44a;font-size:0.8em;font-weight:500;}}
.search-result .sr-meta{{color:#666;font-size:0.68em;}}
@media(max-width:768px){{body{{flex-direction:column;}}#panel{{width:100%;height:45vh;}}}}
</style>
</head>
<body>
<div id="canvas-wrap">
  <div id="search-overlay">
    <input id="search" placeholder="Search concepts..." autocomplete="off">
  </div>
  <canvas id="graph"></canvas>
</div>
<div id="panel">
  <div class="panel-header">
    <h1>Knowledge Engine</h1>
    <div class="sub">GUMP &middot; structure from text</div>
  </div>
  <div class="tabs">
    <div class="tab active" data-tab="search-tab">Search</div>
    <div class="tab" data-tab="tensions-tab">Tensions</div>
    <div class="tab" data-tab="clusters-tab">Clusters</div>
    <div class="tab" data-tab="stats-tab">Stats</div>
  </div>

  <div id="search-tab" class="tab-content active">
    <div id="concept-detail" class="concept-detail"></div>
    <div id="search-results"></div>
    <h2>Top Concepts</h2>
    <div id="top-concepts"></div>
  </div>

  <div id="tensions-tab" class="tab-content">
    <h2>Knowledge Gaps</h2>
    <p style="font-size:0.7em;color:#555;margin-bottom:10px;">Concepts that are structurally close but never co-occur.</p>
    <div id="tensions-list"></div>
  </div>

  <div id="clusters-tab" class="tab-content">
    <h2>Topic Groups</h2>
    <div id="clusters-list"></div>
  </div>

  <div id="stats-tab" class="tab-content">
    <h2>Overview</h2>
    <div class="stat"><span>Concepts</span><span>{st['n_concepts']}</span></div>
    <div class="stat"><span>Connections</span><span>{st['n_connections']}</span></div>
    <div class="stat"><span>Documents</span><span>{st['n_documents']}</span></div>
    <div class="stat"><span>Words processed</span><span>{st['total_words']}</span></div>
    <div class="stat"><span>Avg connections</span><span>{round(st['n_connections'] / max(st['n_concepts'], 1), 1)}</span></div>
    <div class="stat"><span>Clusters</span><span>{len(clusters_data)}</span></div>
    <div class="stat"><span>Tensions found</span><span>{len(tensions)}</span></div>
    <h2>Top Concepts</h2>
    <div id="stats-top"></div>
  </div>
</div>

<script>
var DATA = {data_json};
var COLORS = ['#c9a44a','#4a9ac9','#5b9a3a','#c44a7a','#7a4ac9','#c9744a','#4ac97a','#c9c44a','#9a4ac4','#4ac9c9'];
var cv = document.getElementById('graph');
var cx = cv.getContext('2d');
var wrap = document.getElementById('canvas-wrap');
var dpr = window.devicePixelRatio || 1;

/* ── State ── */
var concepts = DATA.concepts, pos = DATA.positions.map(function(p) {{ return [p[0], p[1]]; }}), edges = DATA.edges;
var selectedNode = -1;
var searchQuery = '';
var hoveredNode = -1;
var t0 = performance.now();

/* ── Canvas setup ── */
function resize() {{
  var r = wrap.getBoundingClientRect();
  cv.width = r.width * dpr; cv.height = r.height * dpr;
  cx.setTransform(dpr, 0, 0, dpr, 0, 0);
}}
resize();
var W = function() {{ return cv.width / dpr; }};
var H = function() {{ return cv.height / dpr; }};

/* ── Position mapping with gentle drift ── */
function mapP(i, time) {{
  var p = pos[i];
  var m = 60;
  /* Unique phase per node for organic drift */
  var phase1 = i * 2.399; /* golden angle */
  var phase2 = i * 3.717;
  var drift = 3.0; /* pixels of drift amplitude */
  var speed = 0.0008;
  var dx = Math.sin(time * speed + phase1) * drift + Math.cos(time * speed * 0.7 + phase2) * drift * 0.5;
  var dy = Math.cos(time * speed * 0.9 + phase1) * drift + Math.sin(time * speed * 0.6 + phase2) * drift * 0.5;
  return [m + (p[0] / 800) * (W() - 2 * m) + dx, m + (p[1] / 600) * (H() - 2 * m) + dy];
}}

/* ── Node size ── */
var maxCount = 1;
concepts.forEach(function(c) {{ if (c.count > maxCount) maxCount = c.count; }});
function nodeRadius(c) {{ return 3 + Math.sqrt(c.count / maxCount) * 12; }}

/* ── Search matching ── */
function matchesSearch(word) {{
  if (!searchQuery || searchQuery.length < 2) return true;
  return word.indexOf(searchQuery) >= 0;
}}

/* ── Tension dash animation offset ── */
var tensionDashOffset = 0;

/* ── Draw frame ── */
function draw() {{
  var time = performance.now() - t0;
  tensionDashOffset = (time * 0.02) % 20;
  cx.clearRect(0, 0, W(), H());
  var maxW = DATA.max_edge_weight || 1;

  /* Edges — curved bezier */
  edges.forEach(function(e) {{
    var a = mapP(e[0], time), b = mapP(e[1], time);
    var opacity = Math.min(0.2, (e[2] / maxW) * 0.25);
    if (e[2] < maxW * 0.3) opacity *= 0.3;  /* hide weak edges */
    var matchA = matchesSearch(concepts[e[0]].word);
    var matchB = matchesSearch(concepts[e[1]].word);
    if (searchQuery.length >= 2 && !matchA && !matchB) opacity *= 0.1;
    if (selectedNode >= 0 && e[0] !== selectedNode && e[1] !== selectedNode) opacity *= 0.15;
    if (selectedNode >= 0 && (e[0] === selectedNode || e[1] === selectedNode)) opacity = Math.max(opacity, 0.4);

    cx.strokeStyle = 'rgba(255,255,255,' + opacity + ')';
    cx.lineWidth = 0.5 + (e[2] / maxW) * 1.5;
    /* Bezier curve — perpendicular offset */
    var mx = (a[0] + b[0]) / 2, my = (a[1] + b[1]) / 2;
    var dx = b[0] - a[0], dy = b[1] - a[1];
    var dist = Math.sqrt(dx * dx + dy * dy);
    var off = Math.min(20, dist * 0.15);
    var cx1 = mx - dy / dist * off, cy1 = my + dx / dist * off;
    cx.beginPath();
    cx.moveTo(a[0], a[1]);
    cx.quadraticCurveTo(cx1, cy1, b[0], b[1]);
    cx.stroke();
  }});

  /* Tension lines — dashed gold, animated */
  (DATA.tensions || []).forEach(function(t) {{
    var ai = null, bi = null;
    concepts.forEach(function(c, i) {{ if (c.word === t.concept_a) ai = i; if (c.word === t.concept_b) bi = i; }});
    if (ai !== null && bi !== null) {{
      var a = mapP(ai, time), b = mapP(bi, time);
      cx.save();
      cx.strokeStyle = '#c9a44a40';
      cx.lineWidth = 1.2;
      cx.setLineDash([6, 6]);
      cx.lineDashOffset = -tensionDashOffset;
      cx.beginPath(); cx.moveTo(a[0], a[1]); cx.lineTo(b[0], b[1]); cx.stroke();
      cx.setLineDash([]);
      cx.restore();
    }}
  }});

  /* Nodes */
  concepts.forEach(function(c, i) {{
    var p = mapP(i, time);
    var r = nodeRadius(c);
    var color = COLORS[c.cluster % COLORS.length];
    var match = matchesSearch(c.word);
    var isSelected = (i === selectedNode);
    var isHovered = (i === hoveredNode);
    var alpha = 1;

    if (searchQuery.length >= 2 && !match) alpha = 0.1;
    if (selectedNode >= 0 && !isSelected) {{
      /* Check if connected to selected */
      var connected = false;
      edges.forEach(function(e) {{
        if ((e[0] === selectedNode && e[1] === i) || (e[1] === selectedNode && e[0] === i)) connected = true;
      }});
      alpha = connected ? 0.8 : 0.12;
    }}

    /* Glow for search matches or hover */
    if ((searchQuery.length >= 2 && match) || isSelected || isHovered) {{
      cx.save();
      cx.shadowBlur = isSelected ? 20 : 12;
      cx.shadowColor = color;
      cx.fillStyle = color;
      cx.globalAlpha = alpha * 0.3;
      cx.beginPath(); cx.arc(p[0], p[1], r + 4, 0, Math.PI * 2); cx.fill();
      cx.restore();
    }}

    /* Node circle */
    cx.globalAlpha = alpha;
    cx.fillStyle = color;
    cx.beginPath(); cx.arc(p[0], p[1], r, 0, Math.PI * 2); cx.fill();
    /* Bright ring */
    cx.strokeStyle = color;
    cx.lineWidth = isSelected ? 2 : 0.5;
    cx.globalAlpha = alpha * (isSelected ? 0.8 : 0.3);
    cx.beginPath(); cx.arc(p[0], p[1], r + 1.5, 0, Math.PI * 2); cx.stroke();
    cx.globalAlpha = 1;

    /* Label */
    if (alpha > 0.15 && (c.count > 3 || concepts.length < 50 || isSelected || isHovered || (searchQuery.length >= 2 && match))) {{
      cx.fillStyle = 'rgba(232,228,220,' + alpha + ')';
      cx.font = (isSelected || isHovered ? 'bold ' : '') + (r > 6 ? '11' : '9') + 'px -apple-system, Georgia, serif';
      cx.textAlign = 'center';
      cx.fillText(c.word, p[0], p[1] - r - 5);
    }}
  }});

  requestAnimationFrame(draw);
}}

/* ── Hit test ── */
function hitTest(mx, my) {{
  var time = performance.now() - t0;
  for (var i = concepts.length - 1; i >= 0; i--) {{
    var p = mapP(i, time);
    var r = nodeRadius(concepts[i]) + 4;
    var dx = mx - p[0], dy = my - p[1];
    if (dx * dx + dy * dy < r * r) return i;
  }}
  return -1;
}}

/* ── Mouse events ── */
cv.addEventListener('mousemove', function(e) {{
  var rect = cv.getBoundingClientRect();
  hoveredNode = hitTest(e.clientX - rect.left, e.clientY - rect.top);
  cv.style.cursor = hoveredNode >= 0 ? 'pointer' : 'default';
}});

cv.addEventListener('click', function(e) {{
  var rect = cv.getBoundingClientRect();
  var hit = hitTest(e.clientX - rect.left, e.clientY - rect.top);
  if (hit >= 0) {{
    selectedNode = hit;
    showConceptDetail(hit);
  }} else {{
    selectedNode = -1;
    document.getElementById('concept-detail').className = 'concept-detail';
  }}
}});

/* ── Concept detail panel ── */
function showConceptDetail(idx) {{
  var c = concepts[idx];
  var el = document.getElementById('concept-detail');
  var ctxHtml = '';
  (c.contexts || []).forEach(function(ctx) {{
    ctxHtml += '<div class="cd-ctx">"' + ctx + '"</div>';
  }});
  el.innerHTML = '<div class="cd-word">' + c.word + '</div>'
    + '<div class="cd-stat">Frequency: ' + c.count + '</div>'
    + '<div class="cd-stat">Connections: ' + c.connections + '</div>'
    + '<div class="cd-stat">Cluster: ' + c.cluster + '</div>'
    + (ctxHtml ? '<h2 style="margin-top:12px;">Contexts</h2>' + ctxHtml : '');
  el.className = 'concept-detail visible';
  /* Switch to search tab */
  switchTab('search-tab');
}}

/* ── Search ── */
var searchInput = document.getElementById('search');
searchInput.addEventListener('input', function() {{
  searchQuery = this.value.toLowerCase();
  var rDiv = document.getElementById('search-results');
  if (!searchQuery || searchQuery.length < 2) {{ rDiv.innerHTML = ''; return; }}
  var matches = concepts.filter(function(c) {{ return c.word.indexOf(searchQuery) >= 0; }}).slice(0, 12);
  rDiv.innerHTML = matches.map(function(c) {{
    return '<div class="search-result" onclick="selectConcept(\\'' + c.word + '\\')">'
      + '<div class="sr-word">' + c.word + '</div>'
      + '<div class="sr-meta">' + c.count + ' uses &middot; ' + c.connections + ' connections &middot; cluster ' + c.cluster + '</div>'
      + '</div>';
  }}).join('');
}});

function selectConcept(word) {{
  for (var i = 0; i < concepts.length; i++) {{
    if (concepts[i].word === word) {{ selectedNode = i; showConceptDetail(i); break; }}
  }}
}}

/* ── Tab switching ── */
document.querySelectorAll('.tab').forEach(function(tab) {{
  tab.addEventListener('click', function() {{ switchTab(this.getAttribute('data-tab')); }});
}});
function switchTab(tabId) {{
  document.querySelectorAll('.tab').forEach(function(t) {{ t.classList.remove('active'); }});
  document.querySelectorAll('.tab-content').forEach(function(t) {{ t.classList.remove('active'); }});
  document.querySelector('[data-tab="' + tabId + '"]').classList.add('active');
  document.getElementById(tabId).classList.add('active');
}}

/* ── Populate tensions ── */
var tDiv = document.getElementById('tensions-list');
(DATA.tensions || []).forEach(function(t) {{
  var el = document.createElement('div');
  el.className = 'tension-item';
  el.innerHTML = '<div class="pair">' + t.concept_a + ' \\u2194 ' + t.concept_b + '</div>'
    + '<div class="insight">' + t.insight + '</div>';
  el.onclick = function() {{
    /* Find and select first concept */
    for (var i = 0; i < concepts.length; i++) {{
      if (concepts[i].word === t.concept_a) {{ selectedNode = i; showConceptDetail(i); break; }}
    }}
  }};
  tDiv.appendChild(el);
}});

/* ── Populate clusters ── */
var clDiv = document.getElementById('clusters-list');
(DATA.clusters || []).forEach(function(group, ci) {{
  var html = '<div class="cluster-group">'
    + '<div class="cluster-label" style="color:' + COLORS[ci % COLORS.length] + ';">Cluster ' + ci + ' (' + group.length + ')</div>'
    + '<div class="cluster-tags">';
  group.forEach(function(w) {{
    html += '<span class="cluster-tag" onclick="selectConcept(\\'' + w + '\\')" style="border:1px solid ' + COLORS[ci % COLORS.length] + '20;">' + w + '</span>';
  }});
  html += '</div></div>';
  clDiv.innerHTML += html;
}});

/* ── Populate top concepts ── */
function populateTop(containerId) {{
  var cDiv = document.getElementById(containerId);
  DATA.status.top_concepts.slice(0, 15).forEach(function(c) {{
    var el = document.createElement('div');
    el.className = 'search-result';
    el.innerHTML = '<div class="sr-word">' + c[0] + '</div><div class="sr-meta">' + c[1] + ' uses &middot; ' + c[2] + ' connections</div>';
    el.onclick = function() {{ selectConcept(c[0]); }};
    cDiv.appendChild(el);
  }});
}}
populateTop('top-concepts');
populateTop('stats-top');

/* ── Start animation ── */
window.addEventListener('resize', resize);
draw();
</script>
</body></html>'''


# ═══ Stop words ═══
_STOP_WORDS = set('the a an is are was were be been being have has had do does did '
    'will would shall should may might can could this that these those it its '
    'and or but not no nor for with from into onto upon out off over under '
    'about above below between through during before after since until while '
    'than then also just only very too quite rather still already yet even '
    'more most much many some any all each every both few several own other '
    'another such what which who whom whose where when how why there here '
    'their they them his her him she her hers our ours your yours his'.split())
