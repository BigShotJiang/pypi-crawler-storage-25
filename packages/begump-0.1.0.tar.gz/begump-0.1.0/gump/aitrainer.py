"""
AI TRAINER — Train models 224,000× cheaper. Know when to stop.
================================================================
Wraps GrokWatch with energy tracking, meta-learning, and an interactive
dashboard that shows exactly when your model understands.

    from gump.aitrainer import AITrainer

    trainer = AITrainer(model_name='my_transformer')
    for epoch in range(10000):
        train(model)
        trainer.log(train_acc=0.99, test_acc=0.15, loss=2.3,
                    n_params=model.n_params)
        if trainer.should_stop():
            print(trainer.recommendation())
            break

    # Interactive report
    html = trainer.visualize()

Built on: gump.grokwatch (grokking detection) + gump.core (energy tracking)
"""

import json
import time
import numpy as np
from gump.grokwatch import GrokWatch
from gump.k_runtime import energy as k_energy_cost, grok_detect as k_grok
from gump.core import EnergyTracker, LANDAUER_PER_BIT


class AITrainer:
    """AI training monitor with grokking detection and energy optimization."""

    def __init__(self, model_name='model', planned_epochs=None):
        self.model_name = model_name
        self.planned_epochs = planned_epochs
        self.watcher = GrokWatch()
        self.start_time = time.time()

        # Extra tracking beyond GrokWatch
        self.learning_rates = []
        self.batch_sizes = []
        self.checkpoints = []
        self._best_test_acc = 0
        self._best_epoch = 0
        self._plateau_count = 0
        self._prev_test = 0

    def log(self, train_acc, test_acc, loss=None, weight_norm=None,
            grad_norm=None, n_params=0, lr=None, batch_size=None):
        """Log one epoch."""
        self.watcher.log(train_acc, test_acc, loss, weight_norm, grad_norm, n_params)

        if lr is not None:
            self.learning_rates.append(float(lr))
        if batch_size is not None:
            self.batch_sizes.append(int(batch_size))

        # Track best
        if test_acc > self._best_test_acc:
            self._best_test_acc = test_acc
            self._best_epoch = len(self.watcher.test_accs) - 1
            self.checkpoints.append({
                'epoch': self._best_epoch,
                'test_acc': round(test_acc, 4),
                'train_acc': round(train_acc, 4),
            })

        # Plateau detection — check trend over window, not single-epoch jitter
        if len(self.watcher.test_accs) >= 50:
            recent_mean = np.mean(self.watcher.test_accs[-25:])
            older_mean = np.mean(self.watcher.test_accs[-50:-25])
            if abs(recent_mean - older_mean) < 0.01:
                self._plateau_count += 1
            else:
                self._plateau_count = 0
        self._prev_test = test_acc

    @property
    def epoch(self):
        return len(self.watcher.test_accs)

    @property
    def phase(self):
        return self.watcher.phase

    @property
    def grokked(self):
        return self.watcher.grokked

    def should_stop(self):
        """Should training stop? More nuanced than GrokWatch alone."""
        if self.watcher.should_stop():
            return True
        # Long plateau with no improvement
        if self._plateau_count > 100 and self.epoch > 200:
            return True
        # If we've gone 3× past planned epochs
        if self.planned_epochs and self.epoch > self.planned_epochs * 3:
            return True
        return False

    def recommendation(self):
        """Get actionable recommendation based on current state."""
        phase = self.phase
        epoch = self.epoch

        if phase == 'generalized':
            savings = self.watcher.savings
            return {
                'action': 'STOP — model has grokked',
                'reason': f'Test accuracy jumped at epoch {self.watcher.grok_epoch}. Understanding achieved.',
                'savings': f'{savings}% compute saved',
                'next': 'Save checkpoint and deploy.',
            }
        elif phase == 'stuck':
            return {
                'action': 'CHANGE STRATEGY',
                'reason': f'Memorized at epoch {self.watcher.memorize_epoch} but never generalized.',
                'suggestions': [
                    'Increase weight decay (try 10× current value)',
                    'Reduce model size (may be overfitting)',
                    'Add more training data',
                    'Try a different optimizer (AdamW → SGD with warmup)',
                    'Increase batch size',
                ],
                'next': 'Pick ONE suggestion, run again.',
            }
        elif phase == 'memorizing':
            patience_left = self.watcher.patience - (epoch - self.watcher.memorize_epoch)
            return {
                'action': 'WAIT — memorizing, grokking may come',
                'reason': f'Train acc high but test acc low. This is normal before grokking.',
                'patience': f'{patience_left} epochs before declaring stuck',
                'next': 'Keep training. Grokking happens suddenly.',
            }
        elif self._plateau_count > 50:
            return {
                'action': 'PLATEAU DETECTED',
                'reason': f'Test accuracy flat for {self._plateau_count} epochs.',
                'suggestions': [
                    'Reduce learning rate (try 0.1× current)',
                    'Add learning rate warmup',
                    'Try cosine annealing schedule',
                ],
                'next': 'Adjust LR and continue.',
            }
        else:
            return {
                'action': 'CONTINUE',
                'reason': f'Learning in progress. Epoch {epoch}.',
                'next': 'Keep training.',
            }

    def status(self):
        """Full training status."""
        ws = self.watcher.status()
        elapsed = time.time() - self.start_time

        # Compute cost comparison
        if self.grokked and self.watcher.grok_epoch > 0:
            memo_cost = self.epoch  # if we'd kept memorizing
            grok_cost = self.watcher.grok_epoch
            ratio = memo_cost / max(grok_cost, 1)
        else:
            ratio = 1.0

        return {
            **ws,
            'model_name': self.model_name,
            'elapsed_seconds': round(elapsed, 1),
            'best_test_acc': round(self._best_test_acc, 4),
            'best_epoch': self._best_epoch,
            'n_checkpoints': len(self.checkpoints),
            'plateau_count': self._plateau_count,
            'cost_ratio': round(ratio, 1),
            'recommendation': self.recommendation(),
        }

    def visualize(self):
        """Generate interactive training dashboard (W&B style)."""
        s = self.status()
        phase = s['phase']
        phase_colors = {'generalized': '#4a9', 'stuck': '#c44', 'memorizing': '#c94', 'learning': '#7ac'}
        phase_color = phase_colors.get(phase, '#7ac')

        # Build chart data
        train_accs = [round(a, 4) for a in self.watcher.train_accs]
        test_accs = [round(a, 4) for a in self.watcher.test_accs]
        losses = [round(l, 4) for l in self.watcher.losses] if self.watcher.losses else []
        epc = [round(e, 6) for e in self.watcher.energy_per_correct] if self.watcher.energy_per_correct else []

        data = {
            'status': s,
            'train_accs': train_accs,
            'test_accs': test_accs,
            'losses': losses,
            'energy_per_correct': epc,
            'checkpoints': self.checkpoints,
        }
        data_json = json.dumps(data, default=str)
        rec = s['recommendation']

        # Savings callout
        savings_html = ''
        if s['grokked'] and s.get('savings_pct', 0) > 0:
            gpu_rate = 2.50  # $/GPU-hr typical
            pct = s['savings_pct']
            est_cost = round(pct * gpu_rate / 100, 2)
            savings_html = f'''
  <div class="savings-callout">
    <div class="savings-icon">&#x26A1;</div>
    <div class="savings-text">
      <div class="savings-title">Saved {pct}% compute</div>
      <div class="savings-detail">= ~${est_cost:.2f} at ${gpu_rate}/GPU-hr</div>
    </div>
  </div>'''

        suggestions_html = ''
        if rec.get('suggestions'):
            suggestions_html = '<div class="sug">' + ''.join(f'<div class="sug-item">{sg}</div>' for sg in rec['suggestions']) + '</div>'

        return f'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>AI Trainer — {self.model_name}</title>
<style>
*{{margin:0;padding:0;box-sizing:border-box;}}
body{{background:#08080d;color:#e8e4dc;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Georgia,serif;display:flex;height:100vh;overflow:hidden;}}
#charts{{flex:1;display:flex;flex-direction:column;padding:20px;gap:12px;overflow-y:auto;}}
.chart-container{{position:relative;border-radius:10px;background:#0a0a12;border:1px solid #ffffff06;overflow:hidden;}}
.chart-container canvas{{display:block;width:100%;}}
.chart-label{{position:absolute;top:12px;left:16px;font-size:0.7em;color:#666;letter-spacing:0.1em;text-transform:uppercase;}}
.chart-legend{{position:absolute;top:10px;right:16px;display:flex;gap:14px;}}
.legend-item{{display:flex;align-items:center;gap:5px;font-size:0.65em;color:#888;}}
.legend-dot{{width:8px;height:8px;border-radius:50%;}}
#tooltip{{position:fixed;pointer-events:none;background:#0d0d14ee;border:1px solid #c9a44a30;border-radius:8px;padding:10px 14px;font-size:0.72em;color:#e8e4dc;display:none;z-index:999;box-shadow:0 8px 32px rgba(0,0,0,0.5);backdrop-filter:blur(8px);min-width:140px;}}
#tooltip .tt-epoch{{color:#c9a44a;font-weight:600;margin-bottom:4px;}}
#tooltip .tt-row{{display:flex;justify-content:space-between;gap:16px;padding:1px 0;}}
#tooltip .tt-val{{font-weight:500;}}
#panel{{width:340px;background:#0d0d14;border-left:1px solid #ffffff08;overflow-y:auto;padding:24px 20px;}}
h1{{font-size:1.3em;font-weight:300;color:#c9a44a;letter-spacing:0.08em;margin-bottom:2px;}}
.sub{{font-size:0.6em;color:#444;letter-spacing:0.15em;margin-bottom:20px;}}
h2{{font-size:0.72em;font-weight:600;color:#666;letter-spacing:0.12em;text-transform:uppercase;margin:20px 0 10px;}}
.phase-badge{{display:inline-block;font-size:0.85em;font-weight:600;color:{phase_color};background:{phase_color}12;border:1px solid {phase_color}30;padding:6px 18px;border-radius:20px;letter-spacing:0.1em;margin:8px 0 12px;}}
.stat{{display:flex;justify-content:space-between;font-size:0.78em;color:#888;padding:5px 0;border-bottom:1px solid #ffffff04;}}
.stat span:last-child{{color:#e8e4dc;font-weight:500;}}
.rec-box{{background:#111118;border-left:3px solid {phase_color};padding:14px 16px;border-radius:0 10px 10px 0;margin:10px 0;}}
.rec-box .act{{color:{phase_color};font-size:0.85em;font-weight:700;letter-spacing:0.02em;}}
.rec-box .why{{color:#999;font-size:0.75em;margin-top:6px;line-height:1.5;}}
.rec-box .sug{{margin-top:8px;}}
.rec-box .sug-item{{color:#777;font-size:0.7em;padding:3px 0 3px 12px;border-left:2px solid #ffffff08;margin:4px 0;}}
.rec-box .next{{color:#c9a44a;font-size:0.72em;margin-top:8px;font-style:italic;}}
.savings-callout{{display:flex;align-items:center;gap:12px;background:linear-gradient(135deg,#4a9920 0%,#2a6610 100%);border-radius:10px;padding:14px 16px;margin:12px 0;}}
.savings-icon{{font-size:1.6em;}}
.savings-title{{color:#e8e4dc;font-size:0.85em;font-weight:700;}}
.savings-detail{{color:#ffffffaa;font-size:0.7em;margin-top:2px;}}
@media(max-width:768px){{
  body{{flex-direction:column;}}
  #panel{{width:100%;height:40vh;border-left:none;border-top:1px solid #ffffff08;}}
}}
</style>
</head>
<body>
<div id="charts">
  <div class="chart-container">
    <canvas id="acc-chart" height="280"></canvas>
    <div class="chart-label">Accuracy</div>
    <div class="chart-legend">
      <div class="legend-item"><div class="legend-dot" style="background:#c9a44a;"></div>Train</div>
      <div class="legend-item"><div class="legend-dot" style="background:#4a9ac9;"></div>Test</div>
      <div class="legend-item"><div class="legend-dot" style="background:#ffffff10;"></div>Gap</div>
    </div>
  </div>
  <div class="chart-container">
    <canvas id="energy-chart" height="200"></canvas>
    <div class="chart-label">Energy / Correct Answer</div>
    <div class="chart-legend">
      <div class="legend-item"><div class="legend-dot" style="background:#5b9a3a;"></div>Energy (J)</div>
    </div>
  </div>
</div>
<div id="panel">
  <h1>AI Trainer</h1>
  <div class="sub">GUMP &middot; {self.model_name}</div>

  <div style="text-align:center;"><span class="phase-badge">{phase.upper()}</span></div>

  <h2>Stats</h2>
  <div class="stat"><span>Epoch</span><span>{s['epoch']}</span></div>
  <div class="stat"><span>Train acc</span><span>{s['train_acc']:.1%}</span></div>
  <div class="stat"><span>Test acc</span><span>{s['test_acc']:.1%}</span></div>
  <div class="stat"><span>Best test</span><span>{s['best_test_acc']:.1%} (ep {s['best_epoch']})</span></div>
  <div class="stat"><span>Gap</span><span>{abs(s['train_acc'] - s['test_acc']):.1%}</span></div>
  <div class="stat"><span>Energy</span><span>{s['total_energy_J']:.2e} J</span></div>
  <div class="stat"><span>Cost ratio</span><span>{s['cost_ratio']}x</span></div>
  <div class="stat"><span>Checkpoints</span><span>{s['n_checkpoints']}</span></div>
  {'<div class="stat"><span>Grokked at</span><span>epoch ' + str(s['grok_epoch']) + '</span></div>' if s['grokked'] else ''}
  {'<div class="stat"><span>Savings</span><span>' + str(s['savings_pct']) + '%</span></div>' if s['grokked'] else ''}

  <h2>Recommendation</h2>
  <div class="rec-box">
    <div class="act">{rec['action']}</div>
    <div class="why">{rec['reason']}</div>
    {suggestions_html}
    <div class="next">{rec.get('next', '')}</div>
  </div>
  {savings_html}
</div>

<div id="tooltip"></div>

<script>
var DATA = {data_json};

/* ── Smooth (EMA) ── */
function smooth(arr, alpha) {{
  if (!arr.length) return [];
  var s = [arr[0]];
  for (var i = 1; i < arr.length; i++) s.push(alpha * arr[i] + (1 - alpha) * s[i-1]);
  return s;
}}

/* ── Chart drawing engine ── */
function initCanvas(canvasId) {{
  var cv = document.getElementById(canvasId);
  var cx = cv.getContext('2d');
  var dpr = window.devicePixelRatio || 1;
  cv.width = cv.offsetWidth * dpr;
  cv.height = cv.offsetHeight * dpr;
  cx.setTransform(dpr, 0, 0, dpr, 0, 0);
  return {{cv:cv, cx:cx, W:cv.offsetWidth, H:cv.offsetHeight}};
}}

function drawAccChart() {{
  var c = initCanvas('acc-chart');
  var cx = c.cx, W = c.W, H = c.H;
  var mg = {{left:52, right:24, top:36, bottom:32}};
  var pW = W - mg.left - mg.right, pH = H - mg.top - mg.bottom;
  var trainRaw = DATA.train_accs, testRaw = DATA.test_accs;
  var n = Math.max(trainRaw.length, testRaw.length);
  if (n === 0) return;
  var train = smooth(trainRaw, 0.15), test = smooth(testRaw, 0.15);

  var minY = 0, maxY = 1;

  function xOf(i) {{ return mg.left + (i / Math.max(n - 1, 1)) * pW; }}
  function yOf(v) {{ return mg.top + (1 - (v - minY) / (maxY - minY)) * pH; }}

  /* Grid lines */
  cx.strokeStyle = '#ffffff06';
  cx.lineWidth = 0.5;
  for (var i = 0; i <= 5; i++) {{
    var y = mg.top + pH * (1 - i / 5);
    cx.beginPath(); cx.moveTo(mg.left, y); cx.lineTo(W - mg.right, y); cx.stroke();
    cx.fillStyle = '#444';
    cx.font = '10px -apple-system, monospace';
    cx.textAlign = 'right';
    cx.fillText((minY + (maxY - minY) * i / 5).toFixed(1), mg.left - 6, y + 3);
  }}
  /* X axis labels */
  cx.fillStyle = '#444';
  cx.font = '10px -apple-system, monospace';
  cx.textAlign = 'center';
  var xTicks = Math.min(8, n);
  for (var i = 0; i < xTicks; i++) {{
    var ep = Math.round(i / (xTicks - 1) * (n - 1));
    cx.fillText(ep, xOf(ep), H - mg.bottom + 16);
  }}

  /* Gap fill between train & test */
  cx.fillStyle = 'rgba(255,255,255,0.02)';
  cx.beginPath();
  for (var i = 0; i < n; i++) {{
    var x = xOf(i);
    var yt = yOf(train[i] !== undefined ? train[i] : 0);
    if (i === 0) cx.moveTo(x, yt); else cx.lineTo(x, yt);
  }}
  for (var i = n - 1; i >= 0; i--) {{
    cx.lineTo(xOf(i), yOf(test[i] !== undefined ? test[i] : 0));
  }}
  cx.closePath();
  cx.fill();

  /* Train line — gold, anti-aliased */
  cx.strokeStyle = '#c9a44a';
  cx.lineWidth = 2;
  cx.lineJoin = 'round';
  cx.lineCap = 'round';
  cx.beginPath();
  train.forEach(function(v, i) {{
    var x = xOf(i), y = yOf(v);
    if (i === 0) cx.moveTo(x, y); else cx.lineTo(x, y);
  }});
  cx.stroke();

  /* Test line — blue */
  cx.strokeStyle = '#4a9ac9';
  cx.lineWidth = 2;
  cx.beginPath();
  test.forEach(function(v, i) {{
    var x = xOf(i), y = yOf(v);
    if (i === 0) cx.moveTo(x, y); else cx.lineTo(x, y);
  }});
  cx.stroke();

  /* Memorize marker — orange dashed */
  if (DATA.status.memorized && DATA.status.memorize_epoch > 0) {{
    var mx = xOf(DATA.status.memorize_epoch);
    cx.save();
    cx.strokeStyle = '#cc8833';
    cx.setLineDash([6, 4]);
    cx.lineWidth = 1.5;
    cx.beginPath(); cx.moveTo(mx, mg.top); cx.lineTo(mx, mg.top + pH); cx.stroke();
    cx.setLineDash([]);
    cx.fillStyle = '#cc8833';
    cx.font = 'bold 10px -apple-system, sans-serif';
    cx.textAlign = 'center';
    cx.fillText('MEMO', mx, mg.top - 6);
    cx.restore();
  }}

  /* Grok marker — green dashed */
  if (DATA.status.grokked && DATA.status.grok_epoch > 0) {{
    var gx = xOf(DATA.status.grok_epoch);
    cx.save();
    cx.strokeStyle = '#44aa66';
    cx.setLineDash([6, 4]);
    cx.lineWidth = 1.5;
    cx.beginPath(); cx.moveTo(gx, mg.top); cx.lineTo(gx, mg.top + pH); cx.stroke();
    cx.setLineDash([]);
    /* Grok label with background pill */
    cx.font = 'bold 10px -apple-system, sans-serif';
    var tw = cx.measureText('GROK').width + 10;
    cx.fillStyle = '#44aa6630';
    cx.beginPath();
    cx.roundRect(gx - tw/2, mg.top - 18, tw, 16, 4);
    cx.fill();
    cx.fillStyle = '#44aa66';
    cx.textAlign = 'center';
    cx.fillText('GROK', gx, mg.top - 6);
    cx.restore();
  }}

  /* Store chart geometry for tooltip */
  window._accChart = {{mg:mg, pW:pW, pH:pH, n:n, train:train, test:test, trainRaw:trainRaw, testRaw:testRaw, xOf:xOf, yOf:yOf}};
}}

function drawEnergyChart() {{
  var epc = DATA.energy_per_correct;
  if (!epc || epc.length === 0) return;
  var c = initCanvas('energy-chart');
  var cx = c.cx, W = c.W, H = c.H;
  var mg = {{left:52, right:24, top:36, bottom:32}};
  var pW = W - mg.left - mg.right, pH = H - mg.top - mg.bottom;
  var n = epc.length;
  var vals = smooth(epc, 0.2);
  var minY = Math.min.apply(null, vals), maxY = Math.max.apply(null, vals);
  if (minY === maxY) {{ minY *= 0.9; maxY *= 1.1; if (maxY === 0) maxY = 1; }}
  var pad = (maxY - minY) * 0.05; minY -= pad; maxY += pad;

  function xOf(i) {{ return mg.left + (i / Math.max(n - 1, 1)) * pW; }}
  function yOf(v) {{ return mg.top + (1 - (v - minY) / (maxY - minY)) * pH; }}

  /* Grid */
  cx.strokeStyle = '#ffffff06'; cx.lineWidth = 0.5;
  for (var i = 0; i <= 4; i++) {{
    var y = mg.top + pH * (1 - i / 4);
    cx.beginPath(); cx.moveTo(mg.left, y); cx.lineTo(W - mg.right, y); cx.stroke();
    cx.fillStyle = '#444'; cx.font = '10px monospace'; cx.textAlign = 'right';
    cx.fillText((minY + (maxY - minY) * i / 4).toExponential(1), mg.left - 6, y + 3);
  }}

  /* Gradient fill under line */
  var grad = cx.createLinearGradient(0, mg.top, 0, mg.top + pH);
  grad.addColorStop(0, 'rgba(90,154,58,0.15)');
  grad.addColorStop(1, 'rgba(90,154,58,0.0)');
  cx.fillStyle = grad;
  cx.beginPath();
  cx.moveTo(xOf(0), mg.top + pH);
  vals.forEach(function(v, i) {{ cx.lineTo(xOf(i), yOf(v)); }});
  cx.lineTo(xOf(n - 1), mg.top + pH);
  cx.closePath();
  cx.fill();

  /* Line */
  cx.strokeStyle = '#5b9a3a';
  cx.lineWidth = 2;
  cx.lineJoin = 'round';
  cx.lineCap = 'round';
  cx.beginPath();
  vals.forEach(function(v, i) {{
    if (i === 0) cx.moveTo(xOf(i), yOf(v)); else cx.lineTo(xOf(i), yOf(v));
  }});
  cx.stroke();

  /* Grok marker on energy chart too */
  if (DATA.status.grokked && DATA.status.grok_epoch > 0 && DATA.status.grok_epoch < n) {{
    var gx = xOf(DATA.status.grok_epoch);
    cx.save();
    cx.strokeStyle = '#44aa6640';
    cx.setLineDash([6, 4]);
    cx.lineWidth = 1;
    cx.beginPath(); cx.moveTo(gx, mg.top); cx.lineTo(gx, mg.top + pH); cx.stroke();
    cx.setLineDash([]);
    cx.restore();
  }}

  window._epcChart = {{mg:mg, pW:pW, pH:pH, n:n, vals:vals, epc:epc, xOf:xOf, yOf:yOf}};
}}

/* ── Tooltip ── */
var ttEl = document.getElementById('tooltip');
document.getElementById('acc-chart').addEventListener('mousemove', function(e) {{
  var rect = this.getBoundingClientRect();
  var ac = window._accChart;
  if (!ac) return;
  var mx = e.clientX - rect.left;
  var relX = (mx - ac.mg.left) / ac.pW;
  if (relX < 0 || relX > 1) {{ ttEl.style.display = 'none'; return; }}
  var ep = Math.round(relX * (ac.n - 1));
  ep = Math.max(0, Math.min(ep, ac.n - 1));
  var trainV = ac.trainRaw[ep], testV = ac.testRaw[ep];
  ttEl.innerHTML = '<div class="tt-epoch">Epoch ' + ep + '</div>'
    + '<div class="tt-row"><span style="color:#c9a44a;">Train</span><span class="tt-val">' + (trainV !== undefined ? (trainV * 100).toFixed(1) + '%' : '-') + '</span></div>'
    + '<div class="tt-row"><span style="color:#4a9ac9;">Test</span><span class="tt-val">' + (testV !== undefined ? (testV * 100).toFixed(1) + '%' : '-') + '</span></div>'
    + '<div class="tt-row"><span style="color:#666;">Gap</span><span class="tt-val">' + (trainV !== undefined && testV !== undefined ? ((trainV - testV) * 100).toFixed(1) + '%' : '-') + '</span></div>';
  ttEl.style.display = 'block';
  ttEl.style.left = (e.clientX + 14) + 'px';
  ttEl.style.top = (e.clientY - 10) + 'px';
}});
document.getElementById('energy-chart').addEventListener('mousemove', function(e) {{
  var rect = this.getBoundingClientRect();
  var ec = window._epcChart;
  if (!ec) return;
  var mx = e.clientX - rect.left;
  var relX = (mx - ec.mg.left) / ec.pW;
  if (relX < 0 || relX > 1) {{ ttEl.style.display = 'none'; return; }}
  var ep = Math.round(relX * (ec.n - 1));
  ep = Math.max(0, Math.min(ep, ec.n - 1));
  ttEl.innerHTML = '<div class="tt-epoch">Epoch ' + ep + '</div>'
    + '<div class="tt-row"><span style="color:#5b9a3a;">Energy/correct</span><span class="tt-val">' + ec.epc[ep].toExponential(2) + ' J</span></div>';
  ttEl.style.display = 'block';
  ttEl.style.left = (e.clientX + 14) + 'px';
  ttEl.style.top = (e.clientY - 10) + 'px';
}});
document.querySelectorAll('canvas').forEach(function(cv) {{
  cv.addEventListener('mouseleave', function() {{ ttEl.style.display = 'none'; }});
}});

/* ── Draw ── */
drawAccChart();
drawEnergyChart();
window.addEventListener('resize', function() {{ drawAccChart(); drawEnergyChart(); }});
</script>
</body>
</html>'''
