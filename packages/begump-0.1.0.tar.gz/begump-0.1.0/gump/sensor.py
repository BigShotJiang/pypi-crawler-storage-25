"""
UNIVERSAL SENSOR — K/R/E/T of anything. Diagnose any time series.
===================================================================
Feed it data. It measures coupling (K), order (R), energy cost (E),
and tension (T). Works on: EEG, ECG, stock prices, temperature,
seismic, audio, network traffic — anything with numbers over time.

    from gump.sensor import UniversalSensor

    sensor = UniversalSensor()
    sensor.feed([1.2, 1.5, 1.3, 1.8, 2.1, 1.9, 2.4, 2.2])  # any time series
    print(sensor.diagnose())   # → K, R, E, T + regime + recommendation
    print(sensor.visualize())  # → interactive HTML

Built on: gump.core (energy, tensions) + coupled oscillator dynamics
"""

import json
import numpy as np
from gump.k_runtime import energy as k_energy_cost, measure as k_measure
from gump.core import EnergyTracker, PHI, LANDAUER_PER_BIT


class UniversalSensor:
    """Measure the four quantities of any system: K, R, E, T."""

    def __init__(self, name='signal'):
        self.name = name
        self.data = []
        self.timestamps = []
        self._measurements = []

    def feed(self, values, timestamps=None):
        """Feed time series data. Can call multiple times."""
        if isinstance(values, (int, float)):
            values = [values]
        self.data.extend([float(v) for v in values])
        if timestamps:
            self.timestamps.extend(timestamps)
        else:
            start = len(self.timestamps)
            self.timestamps.extend(range(start, start + len(values)))

    def measure(self):
        """Compute K, R, E, T from current data."""
        if len(self.data) < 4:
            return {'error': 'Need at least 4 data points'}

        arr = np.array(self.data, dtype=float)
        n = len(arr)

        # ═══ R: Order parameter (phase coherence) ═══
        # Convert differences to phases (not raw values — differences capture dynamics)
        if n >= 6:
            diffs_for_phase = np.diff(arr)
            d_range = diffs_for_phase.max() - diffs_for_phase.min()
            if d_range > 1e-12:
                normed = (diffs_for_phase - diffs_for_phase.min()) / d_range * 2 * np.pi
            else:
                normed = np.zeros(len(diffs_for_phase))
            # Adaptive window: at least 3 windows worth
            window = max(4, min(20, len(normed) // 3))
            R_values = []
            step = max(1, window // 4)
            for i in range(0, len(normed) - window + 1, step):
                chunk = normed[i:i + window]
                R = abs(np.mean(np.exp(1j * chunk)))
                R_values.append(float(R))
            R_current = R_values[-1] if R_values else 0.5
            R_mean = float(np.mean(R_values)) if R_values else 0.5
        else:
            # Too few samples for windowed R — use global autocorrelation as proxy
            if n > 1 and np.std(arr) > 1e-12:
                ac = np.corrcoef(arr[:-1], arr[1:])[0, 1]
                R_current = float(max(0, ac))
                R_mean = R_current
            else:
                R_current = 0.0
                R_mean = 0.0
            R_values = [R_mean]

        # ═══ K: Coupling strength ═══
        # Autocorrelation lag-1 = proxy for coupling
        if n > 1:
            mean = np.mean(arr)
            var = np.var(arr)
            if var > 0:
                autocorr = np.sum((arr[:-1] - mean) * (arr[1:] - mean)) / ((n - 1) * var)
                K = float(np.clip(autocorr * 2.0, 0, 3))  # scale to K range
            else:
                K = 0.0
        else:
            K = 0.0

        # ═══ E: Energy cost (information content) ═══
        tracker = EnergyTracker()
        # Each sample is ~16 bits of information
        bits = n * 16
        tracker.erase(bits, 'signal')
        E = tracker.total_joules

        # Entropy as energy proxy
        hist, _ = np.histogram(arr, bins=min(50, n // 2), density=True)
        hist = hist[hist > 0]
        entropy = float(-np.sum(hist * np.log2(hist + 1e-12)))

        # ═══ T: Tension (rate of change, volatility) ═══
        if n > 1:
            diffs = np.diff(arr)
            T = float(np.std(diffs))
            T_max = float(np.max(np.abs(diffs)))
        else:
            T = 0.0
            T_max = 0.0

        # ═══ Regime detection ═══
        # Combined signal: K measures coupling (autocorrelation), R measures phase coherence.
        # For periodic signals, K is high even when phase-based R is moderate.
        # Use the stronger of the two signals for regime classification.
        R_regime = max(R_mean, K / 3.0)  # K>1.85 → R_regime > 0.618
        if R_regime > 1.0 / PHI:
            if K > 1.0:
                regime = 'locked'       # high coherence, high coupling
            else:
                regime = 'coherent'     # high coherence, moderate coupling
        elif R_regime > 0.3:
            regime = 'transitional'     # between order and chaos
        else:
            if T > np.std(arr) * 0.5:
                regime = 'volatile'     # low coherence, high tension
            else:
                regime = 'diffuse'      # low coherence, low tension

        # ═══ Trend ═══
        if n >= 4:
            half = n // 2
            first_half = np.mean(arr[:half])
            second_half = np.mean(arr[half:])
            diff = second_half - first_half
            rel_diff = diff / (np.std(arr) + 1e-12)
            if rel_diff > 0.5:
                trend = 'rising'
            elif rel_diff < -0.5:
                trend = 'falling'
            else:
                trend = 'stable'
        else:
            trend = 'unknown'

        # ═══ Anomaly detection ═══
        # Use rolling window for anomaly detection — catches local spikes
        # that get diluted by long global history
        anomalies = []
        if n > 20:
            # Rolling window: compare each point to its local neighborhood
            window = min(50, n // 4)
            for i in range(n):
                start = max(0, i - window)
                end = min(n, i + window)
                local = arr[start:end]
                local_mean = np.mean(local)
                local_std = np.std(local)
                if local_std > 0.01 * abs(local_mean + 1e-10):  # skip if variance is tiny relative to mean
                    zscore = (arr[i] - local_mean) / local_std
                    if abs(zscore) > 3.5:
                        anomalies.append({'index': int(i), 'value': float(arr[i]),
                                          'zscore': round(float(zscore), 2)})
            # Also check global anomalies for short sharp moves
            if n > 2:
                diffs = np.abs(np.diff(arr))
                diff_mean = np.mean(diffs)
                diff_std = np.std(diffs)
                if diff_std > 1e-10:
                    for i in range(len(diffs)):
                        if diffs[i] > diff_mean + 4 * diff_std:
                            idx = i + 1
                            if not any(a['index'] == idx for a in anomalies):
                                anomalies.append({'index': idx, 'value': float(arr[idx]),
                                                  'zscore': round(float((diffs[i] - diff_mean) / diff_std), 2)})
            anomalies = anomalies[:10]  # cap at 10

        measurement = {
            'K': round(K, 4),
            'R': round(R_current, 4),
            'R_mean': round(R_mean, 4),
            'E': E,
            'T': round(T, 4),
            'T_max': round(T_max, 4),
            'regime': regime,
            'trend': trend,
            'entropy': round(entropy, 3),
            'n_samples': n,
            'anomalies': anomalies[:10],
            'R_history': [round(r, 3) for r in R_values],
        }
        self._measurements.append(measurement)
        return measurement

    def diagnose(self):
        """Measure + interpret. Returns human-readable diagnosis."""
        m = self.measure()
        if 'error' in m:
            return m

        diagnosis = {
            **m,
            'interpretation': [],
            'recommendation': '',
        }

        # Interpret K
        if m['K'] > 1.5:
            diagnosis['interpretation'].append(f'Strong coupling (K={m["K"]:.2f}) — elements are tightly connected')
        elif m['K'] > 0.5:
            diagnosis['interpretation'].append(f'Moderate coupling (K={m["K"]:.2f}) — partial synchronization')
        else:
            diagnosis['interpretation'].append(f'Weak coupling (K={m["K"]:.2f}) — elements are relatively independent')

        # Interpret R
        if m['R'] > 1.0 / PHI:
            diagnosis['interpretation'].append(f'High coherence (R={m["R"]:.2f} > 1/φ) — system is phase-locked')
        elif m['R'] > 0.3:
            diagnosis['interpretation'].append(f'Partial coherence (R={m["R"]:.2f}) — system is transitioning')
        else:
            diagnosis['interpretation'].append(f'Low coherence (R={m["R"]:.2f}) — system is disordered')

        # Interpret T
        if m['T'] > np.std(self.data) * 0.5:
            diagnosis['interpretation'].append(f'High tension (T={m["T"]:.3f}) — rapid changes, instability')
        else:
            diagnosis['interpretation'].append(f'Low tension (T={m["T"]:.3f}) — gradual changes, stability')

        # Interpret regime
        regime_desc = {
            'locked': 'Fully synchronized. Very stable but potentially rigid.',
            'coherent': 'Well-organized. Healthy operating range.',
            'transitional': 'Between order and chaos. Critical point — could go either way.',
            'volatile': 'Chaotic with large swings. High energy expenditure.',
            'diffuse': 'Low activity, low structure. Dormant or degraded.',
        }
        diagnosis['interpretation'].append(f'Regime: {m["regime"]} — {regime_desc.get(m["regime"], "")}')

        # Recommendation
        if m['regime'] == 'volatile':
            diagnosis['recommendation'] = 'System is unstable. Look for the source of tension and address it.'
        elif m['regime'] == 'transitional':
            diagnosis['recommendation'] = 'System is at a critical point. Small interventions have outsized effect.'
        elif m['regime'] == 'diffuse':
            diagnosis['recommendation'] = 'System lacks structure. Increase coupling — add connections, communication, or energy.'
        elif m['regime'] == 'locked':
            diagnosis['recommendation'] = 'System is rigid. May need controlled disruption to adapt.'
        else:
            diagnosis['recommendation'] = 'System is healthy. Monitor for regime changes.'

        if m['anomalies']:
            diagnosis['interpretation'].append(f'{len(m["anomalies"])} anomalies detected (>3σ)')

        return diagnosis

    def visualize(self):
        """Interactive dashboard showing K, R, E, T (Datadog/Grafana style)."""
        m = self.diagnose()
        if 'error' in m:
            return f'<html><body><h1>Error</h1><p>{m["error"]}</p></body></html>'

        regime = m['regime']
        regime_colors = {'locked':'#4a9ac9','coherent':'#44aa66','transitional':'#ccaa33','volatile':'#cc4444','diffuse':'#666666'}
        regime_color = regime_colors.get(regime, '#888')

        data = {
            'values': [round(float(v), 4) for v in self.data],
            'measurement': {k: v for k, v in m.items() if k != 'interpretation'},
            'interpretation': m.get('interpretation', []),
            'recommendation': m.get('recommendation', ''),
        }
        data_json = json.dumps(data, default=str)

        interp_items = ''.join(f'<li>{i}</li>' for i in m.get('interpretation', []))
        anomaly_items = ''
        for a in m.get('anomalies', []):
            anomaly_items += f'<div class="anom-item" data-idx="{a["index"]}" onclick="highlightAnomaly({a["index"]})">' \
                             f'<span class="anom-idx">#{a["index"]}</span> ' \
                             f'<span class="anom-val">{a["value"]:.3f}</span> ' \
                             f'<span class="anom-z">z={a["zscore"]}</span></div>'

        # K/R/E/T gauge values — normalize to 0-1 for SVG arcs
        k_norm = min(1.0, m['K'] / 3.0)
        r_norm = min(1.0, m['R'])
        # E normalized by log scale
        e_val = m['E']
        e_norm = min(1.0, max(0, (np.log10(e_val + 1e-30) + 20) / 20)) if e_val > 0 else 0
        t_norm = min(1.0, m['T'] / (m['T_max'] + 1e-10)) if m['T_max'] > 0 else 0

        def gauge_svg(val, color, label, display_val):
            r = 36
            circ = 2 * 3.14159 * r
            offset = circ * (1 - val)
            return f'''<svg width="90" height="105" viewBox="0 0 90 105">
  <circle cx="45" cy="45" r="{r}" fill="none" stroke="#ffffff08" stroke-width="5"/>
  <circle cx="45" cy="45" r="{r}" fill="none" stroke="{color}" stroke-width="5"
    stroke-dasharray="{circ}" stroke-dashoffset="{offset:.1f}"
    stroke-linecap="round" transform="rotate(-90 45 45)" style="transition:stroke-dashoffset 0.6s;"/>
  <text x="45" y="50" text-anchor="middle" fill="{color}" font-size="14" font-weight="600" font-family="-apple-system,sans-serif">{display_val}</text>
  <text x="45" y="98" text-anchor="middle" fill="#666" font-size="10" letter-spacing="0.08em" font-family="-apple-system,sans-serif">{label}</text>
</svg>'''

        gauges_html = '<div class="gauges">'
        gauges_html += gauge_svg(k_norm, '#c9a44a', 'K coupling', f'{m["K"]:.2f}')
        gauges_html += gauge_svg(r_norm, '#4a9ac9', 'R order', f'{m["R"]:.2f}')
        gauges_html += gauge_svg(e_norm, '#44aa66', 'E energy', f'{m["E"]:.1e}')
        gauges_html += gauge_svg(t_norm, '#cc4444', 'T tension', f'{m["T"]:.3f}')
        gauges_html += '</div>'

        return f'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Universal Sensor — {self.name}</title>
<style>
*{{margin:0;padding:0;box-sizing:border-box;}}
body{{background:#08080d;color:#e8e4dc;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Georgia,serif;display:flex;height:100vh;overflow:hidden;}}
#charts{{flex:1;display:flex;flex-direction:column;padding:20px;gap:12px;overflow-y:auto;}}
.chart-container{{position:relative;border-radius:10px;background:#0a0a12;border:1px solid #ffffff06;overflow:hidden;}}
.chart-container canvas{{display:block;width:100%;}}
.chart-label{{position:absolute;top:12px;left:16px;font-size:0.7em;color:#666;letter-spacing:0.1em;text-transform:uppercase;}}
.chart-legend{{position:absolute;top:10px;right:16px;display:flex;gap:14px;}}
.legend-item{{display:flex;align-items:center;gap:5px;font-size:0.65em;color:#888;}}
.legend-dot{{width:8px;height:8px;border-radius:50%;}}
#tooltip{{position:fixed;pointer-events:none;background:#0d0d14ee;border:1px solid #c9a44a30;border-radius:8px;padding:10px 14px;font-size:0.72em;color:#e8e4dc;display:none;z-index:999;box-shadow:0 8px 32px rgba(0,0,0,0.5);backdrop-filter:blur(8px);min-width:140px;}}
#tooltip .tt-idx{{color:#c9a44a;font-weight:600;margin-bottom:4px;}}
#tooltip .tt-row{{display:flex;justify-content:space-between;gap:16px;padding:1px 0;}}
#panel{{width:360px;background:#0d0d14;border-left:1px solid #ffffff08;overflow-y:auto;padding:24px 20px;}}
h1{{font-size:1.3em;font-weight:300;color:#c9a44a;letter-spacing:0.08em;margin-bottom:2px;}}
.sub{{font-size:0.6em;color:#444;letter-spacing:0.15em;margin-bottom:16px;}}
h2{{font-size:0.72em;font-weight:600;color:#666;letter-spacing:0.12em;text-transform:uppercase;margin:20px 0 10px;}}
.regime-badge{{display:inline-block;font-size:0.9em;font-weight:700;color:{regime_color};background:{regime_color}15;border:1px solid {regime_color}40;padding:8px 24px;border-radius:24px;letter-spacing:0.12em;}}
.gauges{{display:flex;justify-content:space-between;margin:16px 0 8px;}}
.stat{{display:flex;justify-content:space-between;font-size:0.78em;color:#888;padding:4px 0;border-bottom:1px solid #ffffff04;}}
.stat span:last-child{{color:#e8e4dc;font-weight:500;}}
.interp{{margin:8px 0;}}
.interp ul{{list-style:none;padding:0;}}
.interp li{{font-size:0.75em;color:#999;padding:4px 0 4px 14px;border-left:2px solid #ffffff08;margin:3px 0;line-height:1.5;}}
.rec-box{{background:#111118;border-left:3px solid {regime_color};padding:14px 16px;border-radius:0 10px 10px 0;font-size:0.78em;color:#bbb;margin:8px 0;line-height:1.6;}}
.anom-list{{max-height:200px;overflow-y:auto;}}
.anom-item{{display:flex;align-items:center;gap:8px;font-size:0.72em;padding:5px 8px;border-radius:6px;cursor:pointer;transition:background 0.15s;}}
.anom-item:hover{{background:#ffffff08;}}
.anom-idx{{color:#cc4444;font-weight:600;min-width:30px;}}
.anom-val{{color:#e8e4dc;flex:1;}}
.anom-z{{color:#666;font-size:0.9em;}}
@media(max-width:768px){{body{{flex-direction:column;}}#panel{{width:100%;height:45vh;}}}}
</style>
</head>
<body>
<div id="charts">
  <div class="chart-container">
    <canvas id="signal-chart" height="280"></canvas>
    <div class="chart-label">Signal</div>
    <div class="chart-legend">
      <div class="legend-item"><div class="legend-dot" style="background:#c9a44a;"></div>Value</div>
      <div class="legend-item"><div class="legend-dot" style="background:#ffffff10;border:1px solid #ffffff20;"></div>2&sigma; band</div>
      <div class="legend-item"><div class="legend-dot" style="background:#cc4444;"></div>Anomaly</div>
    </div>
  </div>
  <div class="chart-container">
    <canvas id="r-chart" height="200"></canvas>
    <div class="chart-label">R &mdash; Order Parameter</div>
    <div class="chart-legend">
      <div class="legend-item"><div class="legend-dot" style="background:#4a9ac9;"></div>R</div>
      <div class="legend-item"><div class="legend-dot" style="background:#c9a44a40;border:1px dashed #c9a44a60;width:14px;height:1px;border-radius:0;"></div>1/&phi;</div>
    </div>
  </div>
</div>
<div id="panel">
  <h1>Universal Sensor</h1>
  <div class="sub">GUMP &middot; {self.name}</div>

  <div style="text-align:center;margin:10px 0 14px;"><span class="regime-badge">{regime.upper()}</span></div>

  {gauges_html}

  <h2>Stats</h2>
  <div class="stat"><span>Samples</span><span>{m['n_samples']}</span></div>
  <div class="stat"><span>Trend</span><span>{m['trend']}</span></div>
  <div class="stat"><span>Entropy</span><span>{m['entropy']}</span></div>
  <div class="stat"><span>R mean</span><span>{m['R_mean']:.3f}</span></div>
  <div class="stat"><span>T max</span><span>{m['T_max']:.4f}</span></div>
  <div class="stat"><span>Anomalies</span><span>{len(m['anomalies'])}</span></div>

  <h2>Interpretation</h2>
  <div class="interp"><ul>{interp_items}</ul></div>

  <h2>Recommendation</h2>
  <div class="rec-box">{m['recommendation']}</div>

  <h2>Anomalies</h2>
  <div class="anom-list">{anomaly_items if anomaly_items else '<div style="font-size:0.75em;color:#555;">None detected</div>'}</div>
</div>

<div id="tooltip"></div>

<script>
var DATA = {data_json};

/* ── Smooth (EMA) ── */
function smooth(arr, alpha) {{
  if (!arr.length) return [];
  var s = [arr[0]];
  for (var i = 1; i < arr.length; i++) s.push(alpha * arr[i] + (1 - alpha) * s[i-1]);
  return s;
}}

/* ── Rolling stats for anomaly band ── */
function rollingBand(arr, winSize) {{
  var means = [], uppers = [], lowers = [];
  for (var i = 0; i < arr.length; i++) {{
    var start = Math.max(0, i - winSize);
    var end = Math.min(arr.length, i + winSize + 1);
    var slice = arr.slice(start, end);
    var m = 0; for (var j = 0; j < slice.length; j++) m += slice[j]; m /= slice.length;
    var v = 0; for (var j = 0; j < slice.length; j++) v += (slice[j] - m) * (slice[j] - m); v = Math.sqrt(v / slice.length);
    means.push(m);
    uppers.push(m + 2 * v);
    lowers.push(m - 2 * v);
  }}
  return {{means: means, uppers: uppers, lowers: lowers}};
}}

/* ── Canvas init ── */
function initCanvas(canvasId) {{
  var cv = document.getElementById(canvasId);
  var cx = cv.getContext('2d');
  var dpr = window.devicePixelRatio || 1;
  cv.width = cv.offsetWidth * dpr; cv.height = cv.offsetHeight * dpr;
  cx.setTransform(dpr, 0, 0, dpr, 0, 0);
  return {{cv:cv, cx:cx, W:cv.offsetWidth, H:cv.offsetHeight}};
}}

/* ── Signal chart ── */
function drawSignalChart(highlightIdx) {{
  var c = initCanvas('signal-chart');
  var cx = c.cx, W = c.W, H = c.H;
  var mg = {{left:52, right:24, top:36, bottom:32}};
  var pW = W - mg.left - mg.right, pH = H - mg.top - mg.bottom;
  var vals = DATA.values;
  var n = vals.length; if (n === 0) return;
  var smoothed = smooth(vals, 0.15);

  /* Compute range including band */
  var band = rollingBand(vals, Math.max(5, Math.floor(n / 20)));
  var allVals = vals.concat(band.uppers).concat(band.lowers);
  var minY = Math.min.apply(null, allVals), maxY = Math.max.apply(null, allVals);
  var pad = (maxY - minY) * 0.05; minY -= pad; maxY += pad;
  if (minY === maxY) {{ minY -= 1; maxY += 1; }}

  function xOf(i) {{ return mg.left + (i / Math.max(n - 1, 1)) * pW; }}
  function yOf(v) {{ return mg.top + (1 - (v - minY) / (maxY - minY)) * pH; }}

  /* Grid */
  cx.strokeStyle = '#ffffff06'; cx.lineWidth = 0.5;
  for (var i = 0; i <= 5; i++) {{
    var y = mg.top + pH * (1 - i / 5);
    cx.beginPath(); cx.moveTo(mg.left, y); cx.lineTo(W - mg.right, y); cx.stroke();
    cx.fillStyle = '#444'; cx.font = '10px monospace'; cx.textAlign = 'right';
    cx.fillText((minY + (maxY - minY) * i / 5).toFixed(2), mg.left - 6, y + 3);
  }}

  /* Anomaly band (gray fill) */
  cx.fillStyle = 'rgba(255,255,255,0.025)';
  cx.beginPath();
  for (var i = 0; i < n; i++) {{
    var x = xOf(i), y = yOf(band.uppers[i]);
    if (i === 0) cx.moveTo(x, y); else cx.lineTo(x, y);
  }}
  for (var i = n - 1; i >= 0; i--) {{ cx.lineTo(xOf(i), yOf(band.lowers[i])); }}
  cx.closePath(); cx.fill();

  /* Band borders */
  cx.strokeStyle = 'rgba(255,255,255,0.06)'; cx.lineWidth = 0.5;
  cx.beginPath();
  for (var i = 0; i < n; i++) {{ var x = xOf(i); if (i === 0) cx.moveTo(x, yOf(band.uppers[i])); else cx.lineTo(x, yOf(band.uppers[i])); }}
  cx.stroke();
  cx.beginPath();
  for (var i = 0; i < n; i++) {{ var x = xOf(i); if (i === 0) cx.moveTo(x, yOf(band.lowers[i])); else cx.lineTo(x, yOf(band.lowers[i])); }}
  cx.stroke();

  /* Signal line — gold, smooth */
  cx.strokeStyle = '#c9a44a'; cx.lineWidth = 2; cx.lineJoin = 'round'; cx.lineCap = 'round';
  cx.beginPath();
  smoothed.forEach(function(v, i) {{
    var x = xOf(i), y = yOf(v);
    if (i === 0) cx.moveTo(x, y); else cx.lineTo(x, y);
  }});
  cx.stroke();

  /* Anomaly points — red circles with glow */
  var anomalies = DATA.measurement.anomalies || [];
  anomalies.forEach(function(a) {{
    var x = xOf(a.index), y = yOf(a.value);
    var isHighlighted = (highlightIdx !== undefined && a.index === highlightIdx);
    /* Outer glow */
    cx.fillStyle = isHighlighted ? 'rgba(200,70,70,0.25)' : 'rgba(200,70,70,0.12)';
    cx.beginPath(); cx.arc(x, y, isHighlighted ? 12 : 8, 0, Math.PI * 2); cx.fill();
    /* Inner dot */
    cx.fillStyle = isHighlighted ? '#ff4444' : '#cc4444';
    cx.beginPath(); cx.arc(x, y, isHighlighted ? 5 : 3.5, 0, Math.PI * 2); cx.fill();
    /* Ring */
    cx.strokeStyle = isHighlighted ? '#ff444480' : '#cc444440';
    cx.lineWidth = 1.5;
    cx.beginPath(); cx.arc(x, y, isHighlighted ? 8 : 5.5, 0, Math.PI * 2); cx.stroke();
  }});

  window._sigChart = {{mg:mg, pW:pW, pH:pH, n:n, vals:vals, minY:minY, maxY:maxY, xOf:xOf, yOf:yOf}};
}}

/* ── R chart ── */
function drawRChart() {{
  var rHist = DATA.measurement.R_history || [];
  if (rHist.length === 0) return;
  var c = initCanvas('r-chart');
  var cx = c.cx, W = c.W, H = c.H;
  var mg = {{left:52, right:34, top:36, bottom:32}};
  var pW = W - mg.left - mg.right, pH = H - mg.top - mg.bottom;
  var n = rHist.length;
  var minY = 0, maxY = Math.max(1, Math.max.apply(null, rHist) * 1.1);

  function xOf(i) {{ return mg.left + (i / Math.max(n - 1, 1)) * pW; }}
  function yOf(v) {{ return mg.top + (1 - (v - minY) / (maxY - minY)) * pH; }}

  /* Grid */
  cx.strokeStyle = '#ffffff06'; cx.lineWidth = 0.5;
  for (var i = 0; i <= 4; i++) {{
    var y = mg.top + pH * (1 - i / 4);
    cx.beginPath(); cx.moveTo(mg.left, y); cx.lineTo(W - mg.right, y); cx.stroke();
    cx.fillStyle = '#444'; cx.font = '10px monospace'; cx.textAlign = 'right';
    cx.fillText((minY + (maxY - minY) * i / 4).toFixed(2), mg.left - 6, y + 3);
  }}

  /* Gradient fill under R */
  var grad = cx.createLinearGradient(0, mg.top, 0, mg.top + pH);
  grad.addColorStop(0, 'rgba(74,154,201,0.12)');
  grad.addColorStop(1, 'rgba(74,154,201,0.0)');
  cx.fillStyle = grad;
  cx.beginPath();
  cx.moveTo(xOf(0), mg.top + pH);
  rHist.forEach(function(v, i) {{ cx.lineTo(xOf(i), yOf(v)); }});
  cx.lineTo(xOf(n - 1), mg.top + pH);
  cx.closePath(); cx.fill();

  /* R line */
  cx.strokeStyle = '#4a9ac9'; cx.lineWidth = 2; cx.lineJoin = 'round'; cx.lineCap = 'round';
  cx.beginPath();
  rHist.forEach(function(v, i) {{
    if (i === 0) cx.moveTo(xOf(i), yOf(v)); else cx.lineTo(xOf(i), yOf(v));
  }});
  cx.stroke();

  /* 1/phi threshold line */
  var phiVal = 0.618;
  var phiY = yOf(phiVal);
  if (phiY > mg.top && phiY < mg.top + pH) {{
    cx.save();
    cx.strokeStyle = '#c9a44a50'; cx.lineWidth = 1; cx.setLineDash([6, 4]);
    cx.beginPath(); cx.moveTo(mg.left, phiY); cx.lineTo(W - mg.right, phiY); cx.stroke();
    cx.setLineDash([]);
    /* Label pill */
    cx.font = '10px -apple-system, sans-serif';
    cx.fillStyle = '#c9a44a30';
    cx.beginPath(); cx.roundRect(W - mg.right + 2, phiY - 9, 28, 18, 4); cx.fill();
    cx.fillStyle = '#c9a44a';
    cx.textAlign = 'center';
    cx.fillText('1/\\u03c6', W - mg.right + 16, phiY + 4);
    cx.restore();
  }}
}}

/* ── Tooltip ── */
var ttEl = document.getElementById('tooltip');
document.getElementById('signal-chart').addEventListener('mousemove', function(e) {{
  var rect = this.getBoundingClientRect();
  var sc = window._sigChart; if (!sc) return;
  var mx = e.clientX - rect.left;
  var relX = (mx - sc.mg.left) / sc.pW;
  if (relX < 0 || relX > 1) {{ ttEl.style.display = 'none'; return; }}
  var idx = Math.round(relX * (sc.n - 1));
  idx = Math.max(0, Math.min(idx, sc.n - 1));
  ttEl.innerHTML = '<div class="tt-idx">Sample ' + idx + '</div>'
    + '<div class="tt-row"><span style="color:#c9a44a;">Value</span><span>' + sc.vals[idx].toFixed(4) + '</span></div>';
  ttEl.style.display = 'block';
  ttEl.style.left = (e.clientX + 14) + 'px';
  ttEl.style.top = (e.clientY - 10) + 'px';
}});
document.querySelectorAll('canvas').forEach(function(cv) {{
  cv.addEventListener('mouseleave', function() {{ ttEl.style.display = 'none'; }});
}});

/* ── Anomaly click highlight ── */
window.highlightAnomaly = function(idx) {{
  drawSignalChart(idx);
  /* Scroll chart into view */
  document.getElementById('signal-chart').scrollIntoView({{behavior:'smooth',block:'center'}});
}};

/* ── Draw ── */
drawSignalChart();
drawRChart();
window.addEventListener('resize', function() {{ drawSignalChart(); drawRChart(); }});
</script>
</body></html>'''
