"""
LEARN ENGINE — Know what you don't know. Know when you get it.
================================================================
Maps any subject as a knowledge graph. Tracks what's been learned,
what's missing, and detects the exact moment understanding arrives.

    from gump.learnengine import LearnEngine

    # Define a subject
    engine = LearnEngine(
        topics=['algebra','trig','calculus','stats','linear_algebra'],
        prerequisites=[('algebra','calculus'),('trig','calculus'),
                       ('algebra','stats'),('algebra','linear_algebra')]
    )

    # Student answers questions
    engine.answer('algebra', correct=True)
    engine.answer('algebra', correct=True)
    engine.answer('calculus', correct=False)

    # What should they study next?
    print(engine.next())        # → 'trig' (prerequisite for calculus, not yet attempted)
    print(engine.gaps())        # → ['calculus'] (attempted but not grokked)
    print(engine.status())      # → full learning state

    # Generate interactive report
    html = engine.visualize()

Built on: gump.learnpath (curriculum) + gump.grokwatch (grokking) +
          gump.core (tensions, placement, memory)
"""

import json
import time
import numpy as np
from gump.core import _TensionDetector
from gump.k_runtime import place as spectral_place
from gump.learnpath import curriculum


class TopicState:
    """Tracks learning state for one topic."""
    __slots__ = ('name', 'attempts', 'correct', 'streak', 'best_streak',
                 'first_seen', 'last_seen', 'grokked', 'grok_time',
                 'accuracy_history', 'confidence')

    def __init__(self, name):
        self.name = name
        self.attempts = 0
        self.correct = 0
        self.streak = 0
        self.best_streak = 0
        self.first_seen = None
        self.last_seen = None
        self.grokked = False
        self.grok_time = None
        self.accuracy_history = []
        self.confidence = 0.0

    @property
    def accuracy(self):
        return self.correct / self.attempts if self.attempts > 0 else 0.0

    @property
    def phase(self):
        if self.grokked:
            return 'mastered'
        if self.attempts == 0:
            return 'unseen'
        if self.accuracy < 0.3:
            return 'struggling'
        if self.accuracy < 0.7:
            return 'learning'
        if self.streak >= 3:
            return 'nearly'
        return 'learning'

    def to_dict(self):
        return {
            'name': self.name,
            'attempts': self.attempts,
            'correct': self.correct,
            'accuracy': round(self.accuracy, 3),
            'streak': self.streak,
            'best_streak': self.best_streak,
            'phase': self.phase,
            'grokked': self.grokked,
            'confidence': round(self.confidence, 3),
        }


class LearnEngine:
    """Adaptive learning engine that tracks knowledge and detects understanding."""

    # Grokking thresholds
    GROK_STREAK = 5         # correct in a row to grok
    GROK_ACCURACY = 0.85    # minimum accuracy to grok
    GROK_MIN_ATTEMPTS = 4   # minimum attempts before grokking possible

    def __init__(self, topics, prerequisites, weights=None):
        """
        Args:
            topics: list of topic names
            prerequisites: list of (prereq, dependent) pairs
            weights: optional importance weights for prerequisites
        """
        self.topics = list(topics)
        self.prerequisites = list(prerequisites)
        self.weights = weights
        self.topic_idx = {name: i for i, name in enumerate(self.topics)}
        self.n = len(self.topics)

        # Curriculum from learnpath
        self._curriculum = curriculum(self.topics, self.prerequisites, weights)

        # Per-topic state
        self.states = {name: TopicState(name) for name in self.topics}

        # Prerequisite graph
        self._prereqs_for = {}  # topic → [its prerequisites]
        self._dependents_of = {}  # topic → [what depends on it]
        for prereq, dep in self.prerequisites:
            if prereq in self.topic_idx and dep in self.topic_idx:
                self._prereqs_for.setdefault(dep, []).append(prereq)
                self._dependents_of.setdefault(prereq, []).append(dep)

        # Tension detector for knowledge gaps
        idx_edges = [(self.topic_idx[a], self.topic_idx[b])
                     for a, b in self.prerequisites
                     if a in self.topic_idx and b in self.topic_idx]
        self._td = _TensionDetector(self.n, idx_edges, weights) if idx_edges else None

        # Interaction counter
        self._total_answers = 0

    def answer(self, topic, correct=True):
        """Record a student's answer on a topic.

        Args:
            topic: topic name
            correct: whether they got it right
        """
        if topic not in self.states:
            return

        s = self.states[topic]
        now = time.time()
        if s.first_seen is None:
            s.first_seen = now
        s.last_seen = now
        s.attempts += 1
        self._total_answers += 1

        if correct:
            s.correct += 1
            s.streak += 1
            s.best_streak = max(s.best_streak, s.streak)
        else:
            s.streak = 0

        # Rolling accuracy (last 10)
        s.accuracy_history.append(1.0 if correct else 0.0)
        if len(s.accuracy_history) > 10:
            s.accuracy_history = s.accuracy_history[-10:]

        # Confidence: weighted recent accuracy
        if len(s.accuracy_history) >= 3:
            recent = s.accuracy_history[-3:]
            s.confidence = sum(recent) / len(recent)
        else:
            s.confidence = s.accuracy

        # Grokking detection — must have sustained performance with no recent failures
        recent_window = s.accuracy_history[-10:] if len(s.accuracy_history) >= 10 else s.accuracy_history
        recent_failures = recent_window.count(0.0) if recent_window else 0
        if (not s.grokked and
            s.attempts >= self.GROK_MIN_ATTEMPTS and
            s.streak >= self.GROK_STREAK and
            s.accuracy >= self.GROK_ACCURACY and
            recent_failures == 0):
            s.grokked = True
            s.grok_time = now
            # Check if prerequisites are grokked (validation)
            prereqs = self._prereqs_for.get(topic, [])
            prereqs_grokked = all(self.states[p].grokked for p in prereqs)
            if not prereqs_grokked:
                # Surprising — they understood the dependent before prerequisites
                pass  # still count it, but note in status

    def next(self, n=1):
        """Recommend what to study next.

        Returns the topic(s) that would have the highest impact right now.
        Priority: prerequisites of struggling topics > unseen in curriculum order > review.
        """
        recommendations = []

        # 1. Prerequisites of topics they're struggling with
        for name in self.topics:
            s = self.states[name]
            if s.phase == 'struggling':
                for prereq in self._prereqs_for.get(name, []):
                    ps = self.states[prereq]
                    if not ps.grokked:
                        recommendations.append((prereq, 'prerequisite for ' + name, 3))

        # 2. Unseen topics in curriculum order
        for name in self._curriculum['order']:
            s = self.states[name]
            if s.phase == 'unseen':
                # Check if prerequisites are met
                prereqs = self._prereqs_for.get(name, [])
                prereqs_met = all(self.states[p].grokked or self.states[p].accuracy > 0.6
                                  for p in prereqs)
                if prereqs_met or not prereqs:
                    recommendations.append((name, 'next in sequence', 2))

        # 3. Topics that are close to grokking (push them over)
        for name in self.topics:
            s = self.states[name]
            if s.phase == 'nearly':
                recommendations.append((name, 'almost mastered — push through', 1))

        # 4. Review topics with decaying confidence
        for name in self.topics:
            s = self.states[name]
            if s.grokked and s.last_seen and (time.time() - s.last_seen) > 86400:
                recommendations.append((name, 'review — been a while', 0))

        # Sort by priority (highest first), deduplicate
        recommendations.sort(key=lambda x: -x[2])
        seen = set()
        unique = []
        for name, reason, priority in recommendations:
            if name not in seen:
                seen.add(name)
                unique.append({'topic': name, 'reason': reason, 'priority': priority})

        return unique[:n] if n > 1 else (unique[0] if unique else None)

    def gaps(self):
        """Find knowledge gaps — topics attempted but not mastered,
        especially where prerequisites ARE mastered."""
        gaps = []
        for name in self.topics:
            s = self.states[name]
            if s.attempts > 0 and not s.grokked:
                prereqs = self._prereqs_for.get(name, [])
                prereqs_grokked = all(self.states[p].grokked for p in prereqs) if prereqs else True
                gaps.append({
                    'topic': name,
                    'accuracy': s.accuracy,
                    'attempts': s.attempts,
                    'phase': s.phase,
                    'prereqs_met': prereqs_grokked,
                    'blocking': [dep for dep in self._dependents_of.get(name, [])
                                 if self.states[dep].phase == 'unseen'],
                })
        gaps.sort(key=lambda g: (not g['prereqs_met'], -len(g['blocking']), g['accuracy']))
        return gaps

    def tensions(self, top_k=10):
        """Find conceptual tensions — topics that WANT to connect in the student's understanding."""
        if self._td is None:
            return []

        raw = self._td.tensions(top_k)
        result = []
        for d, i, j, score in raw:
            a, b = self.topics[i], self.topics[j]
            sa, sb = self.states[a], self.states[b]
            # Tension is more meaningful if one is mastered and the other isn't
            knowledge_gap = abs(sa.confidence - sb.confidence)
            result.append({
                'topic_a': a, 'topic_b': b,
                'spectral_tension': round(score, 3),
                'knowledge_gap': round(knowledge_gap, 3),
                'insight': f'{a} and {b} are structurally connected — '
                          f'understanding one helps the other',
            })
        return result

    def status(self):
        """Full learning status."""
        mastered = sum(1 for s in self.states.values() if s.grokked)
        attempted = sum(1 for s in self.states.values() if s.attempts > 0)
        struggling = sum(1 for s in self.states.values() if s.phase == 'struggling')

        return {
            'total_topics': self.n,
            'mastered': mastered,
            'attempted': attempted,
            'unseen': self.n - attempted,
            'struggling': struggling,
            'completion': round(mastered / self.n * 100, 1) if self.n > 0 else 0,
            'total_answers': self._total_answers,
            'topics': {name: s.to_dict() for name, s in self.states.items()},
            'curriculum_order': self._curriculum['order'],
            'clusters': self._curriculum['clusters'],
            'next': self.next(3),
            'gaps': self.gaps(),
        }

    def visualize(self):
        """Generate interactive HTML learning dashboard — Khan Academy mastery style."""
        # Spectral positions for knowledge graph
        idx_edges = [(self.topic_idx[a], self.topic_idx[b])
                     for a, b in self.prerequisites
                     if a in self.topic_idx and b in self.topic_idx]
        try:
            positions_arr = spectral_place(self.n, idx_edges, 800, 600, self.weights)
            positions = {self.topics[i]: [round(float(positions_arr[i][0]), 1),
                                           round(float(positions_arr[i][1]), 1)]
                          for i in range(self.n)}
        except Exception:
            positions = {self.topics[i]: [round(float(np.random.rand() * 800), 1),
                                           round(float(np.random.rand() * 600), 1)]
                          for i in range(self.n)}

        data = {
            'status': self.status(),
            'positions': positions,
            'prerequisites': [{'from': a, 'to': b} for a, b in self.prerequisites],
            'tensions': self.tensions(10),
        }
        data_json = json.dumps(data, default=str)
        status = data['status']
        pct = status['completion']

        return f'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Learn Engine — Mastery Dashboard</title>
<style>
*{{margin:0;padding:0;box-sizing:border-box;}}
body{{background:#08080d;color:#e8e4dc;font-family:'Inter',-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;display:flex;height:100vh;overflow:hidden;}}
@keyframes pulseGlow{{0%,100%{{filter:drop-shadow(0 0 4px rgba(74,170,154,0.3));}}50%{{filter:drop-shadow(0 0 12px rgba(74,170,154,0.6));}}}}
@keyframes fadeIn{{from{{opacity:0;transform:translateY(8px);}}to{{opacity:1;transform:translateY(0);}}}}
@keyframes ringFill{{from{{stroke-dashoffset:220;}}}}

/* ═══ Canvas area ═══ */
#canvas-wrap{{flex:1;position:relative;min-width:0;}}
canvas{{display:block;width:100%;height:100%;cursor:grab;}}
canvas:active{{cursor:grabbing;}}
#tooltip{{position:absolute;display:none;background:#0d0d14;border:1px solid #c9a44a40;border-radius:10px;padding:14px 18px;
  pointer-events:none;z-index:100;min-width:240px;box-shadow:0 8px 32px rgba(0,0,0,0.6);backdrop-filter:blur(8px);}}
#tooltip .tt-name{{font-size:1em;font-weight:600;color:#e8e4dc;margin-bottom:8px;}}
#tooltip .tt-phase{{display:inline-block;padding:2px 10px;border-radius:10px;font-size:0.7em;font-weight:600;letter-spacing:0.05em;text-transform:uppercase;}}
#tooltip .tt-row{{display:flex;justify-content:space-between;font-size:0.78em;color:#888;padding:3px 0;}}
#tooltip .tt-row span:last-child{{color:#c9a44a;font-weight:500;}}
#tooltip .tt-prereqs{{margin-top:8px;font-size:0.72em;}}
#tooltip .tt-prereqs .met{{color:#4a9;}} #tooltip .tt-prereqs .unmet{{color:#c44;}}
#tooltip .tt-history{{margin-top:8px;display:flex;gap:2px;align-items:flex-end;height:30px;}}
#tooltip .tt-history .bar{{width:6px;border-radius:2px 2px 0 0;min-height:2px;}}

/* ═══ Legend overlay ═══ */
#legend{{position:absolute;bottom:16px;left:16px;background:#0d0d14e0;border:1px solid #ffffff08;
  border-radius:8px;padding:10px 14px;font-size:0.68em;color:#888;backdrop-filter:blur(4px);}}
#legend .row{{display:flex;align-items:center;gap:8px;padding:2px 0;}}
#legend .dot{{width:10px;height:10px;border-radius:50%;flex-shrink:0;}}
#legend .line{{width:16px;height:0;border-top:1.5px solid;flex-shrink:0;}}

/* ═══ Right panel ═══ */
#panel{{width:380px;background:#0d0d14;border-left:1px solid #ffffff08;overflow-y:auto;padding:0;display:flex;flex-direction:column;}}
#panel::-webkit-scrollbar{{width:4px;}} #panel::-webkit-scrollbar-track{{background:transparent;}} #panel::-webkit-scrollbar-thumb{{background:#ffffff10;border-radius:2px;}}

.panel-inner{{padding:24px 20px;}}

h1{{font-size:1.3em;font-weight:300;color:#c9a44a;letter-spacing:0.08em;margin-bottom:2px;}}
.sub{{font-size:0.62em;color:#444;letter-spacing:0.15em;margin-bottom:20px;font-weight:400;}}
h2{{font-size:0.72em;font-weight:600;color:#c9a44a80;letter-spacing:0.12em;text-transform:uppercase;margin:24px 0 10px;}}

/* ═══ Completion bar ═══ */
.completion-wrap{{background:#111118;border-radius:12px;padding:16px 20px;margin-bottom:20px;}}
.completion-top{{display:flex;justify-content:space-between;align-items:baseline;margin-bottom:10px;}}
.completion-pct{{font-size:2.6em;font-weight:200;line-height:1;}}
.completion-label{{font-size:0.7em;color:#888;font-weight:400;}}
.completion-bar{{height:6px;background:#ffffff06;border-radius:3px;overflow:hidden;position:relative;}}
.completion-fill{{height:100%;border-radius:3px;transition:width 1s ease;position:relative;}}
.completion-fill::after{{content:'';position:absolute;right:0;top:-1px;width:8px;height:8px;border-radius:50%;background:inherit;box-shadow:0 0 8px currentColor;}}
.completion-stats{{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:14px;text-align:center;}}
.completion-stats .cs-val{{font-size:1.3em;font-weight:300;}}
.completion-stats .cs-label{{font-size:0.6em;color:#666;text-transform:uppercase;letter-spacing:0.08em;}}

/* ═══ Study next cards ═══ */
.rec-card{{background:linear-gradient(135deg,#0d1a0d,#111118);border:1px solid #4a9940;border-radius:10px;padding:14px 16px;margin:8px 0;
  animation:fadeIn 0.4s ease both;cursor:pointer;transition:all 0.2s;}}
.rec-card:hover{{border-color:#4a9;transform:translateX(4px);box-shadow:0 4px 16px rgba(74,170,154,0.15);}}
.rec-card .rc-num{{font-size:0.6em;font-weight:700;color:#4a9;letter-spacing:0.1em;margin-bottom:4px;}}
.rec-card .rc-topic{{font-size:0.95em;font-weight:500;color:#e8e4dc;margin-bottom:4px;}}
.rec-card .rc-reason{{font-size:0.72em;color:#888;line-height:1.4;}}

/* ═══ Gap cards ═══ */
.gap-card{{background:linear-gradient(135deg,#1a0d0d,#111118);border:1px solid #c4440030;border-radius:10px;padding:14px 16px;margin:8px 0;}}
.gap-card .gc-topic{{font-size:0.9em;font-weight:500;color:#e8e4dc;margin-bottom:4px;}}
.gap-card .gc-bar{{height:3px;background:#ffffff06;border-radius:2px;margin:6px 0;}}
.gap-card .gc-fill{{height:100%;background:#c44;border-radius:2px;}}
.gap-card .gc-info{{font-size:0.7em;color:#888;}}
.gap-card .gc-blocking{{font-size:0.68em;color:#c94;margin-top:4px;}}

/* ═══ Topic rows ═══ */
.topic-row{{display:flex;align-items:center;gap:12px;background:#111118;border-radius:8px;padding:10px 14px;margin:4px 0;
  cursor:pointer;transition:all 0.2s;border:1px solid transparent;}}
.topic-row:hover{{border-color:#c9a44a30;background:#16161e;}}
.topic-row.selected{{border-color:#c9a44a60;background:#1a1a24;}}

.tr-ring{{width:36px;height:36px;flex-shrink:0;position:relative;}}
.tr-ring svg{{width:100%;height:100%;transform:rotate(-90deg);}}
.tr-ring .ring-bg{{fill:none;stroke:#ffffff08;stroke-width:3;}}
.tr-ring .ring-fg{{fill:none;stroke-width:3;stroke-linecap:round;transition:stroke-dashoffset 0.8s ease;}}
.tr-ring .ring-label{{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);font-size:0.55em;font-weight:600;}}

.tr-info{{flex:1;min-width:0;}}
.tr-name{{font-size:0.82em;font-weight:500;color:#e8e4dc;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}}
.tr-meta{{display:flex;gap:8px;align-items:center;margin-top:2px;}}
.tr-badge{{display:inline-block;padding:1px 8px;border-radius:8px;font-size:0.58em;font-weight:600;letter-spacing:0.06em;text-transform:uppercase;}}
.tr-stat{{font-size:0.68em;color:#666;}}

.tr-bar{{width:60px;height:3px;background:#ffffff06;border-radius:2px;flex-shrink:0;}}
.tr-bar-fill{{height:100%;border-radius:2px;transition:width 0.6s ease;}}

.badge-mastered{{background:#4a9920;color:#4a9;}} .badge-learning{{background:#c9442020;color:#c94;}}
.badge-struggling{{background:#c4440020;color:#c44;}} .badge-nearly{{background:#7ac0e020;color:#7ac;}}
.badge-unseen{{background:#ffffff08;color:#555;}}

/* ═══ Phase filter tabs ═══ */
.phase-tabs{{display:flex;gap:4px;margin-bottom:10px;flex-wrap:wrap;}}
.phase-tab{{padding:4px 10px;border-radius:12px;font-size:0.65em;cursor:pointer;border:1px solid #ffffff10;
  color:#888;transition:all 0.2s;user-select:none;}}
.phase-tab:hover{{border-color:#ffffff20;color:#e8e4dc;}}
.phase-tab.active{{border-color:#c9a44a40;color:#c9a44a;background:#c9a44a10;}}

@media(max-width:768px){{
  body{{flex-direction:column;}}
  #panel{{width:100%;height:50vh;border-left:none;border-top:1px solid #ffffff08;}}
}}
</style>
</head>
<body>

<div id="canvas-wrap">
  <canvas id="graph"></canvas>
  <div id="tooltip"></div>
  <div id="legend">
    <div class="row"><div class="dot" style="background:#4a9;"></div> Mastered</div>
    <div class="row"><div class="dot" style="background:#7ac;"></div> Nearly there</div>
    <div class="row"><div class="dot" style="background:#c94;"></div> Learning</div>
    <div class="row"><div class="dot" style="background:#c44;"></div> Struggling</div>
    <div class="row"><div class="dot" style="background:#333;opacity:0.5;"></div> Unseen</div>
    <div class="row"><div class="line" style="border-color:#ffffff20;"></div> Prerequisite</div>
    <div class="row"><div class="line" style="border-color:#c9a44a40;border-style:dashed;"></div> Tension</div>
  </div>
</div>

<div id="panel">
  <div class="panel-inner">
    <h1>Learn Engine</h1>
    <div class="sub">GUMP &middot; knowledge through coupling</div>

    <div class="completion-wrap" id="completion"></div>

    <h2>STUDY NEXT</h2>
    <div id="recs"></div>

    <h2>KNOWLEDGE GAPS</h2>
    <div id="gaps"></div>

    <h2>ALL TOPICS</h2>
    <div class="phase-tabs" id="phase-tabs"></div>
    <div id="topics"></div>
  </div>
</div>

<script>
var DATA = {data_json};
var PHASE = {{mastered:'#4a9',struggling:'#c44',learning:'#c94',nearly:'#7ac',unseen:'#333'}};
var PHASE_LABELS = {{mastered:'Mastered',struggling:'Struggling',learning:'Learning',nearly:'Nearly',unseen:'Unseen'}};
var topics = DATA.status.topics || {{}};
var pos = DATA.positions || {{}};
var nodes = Object.keys(pos);

// ═══ COMPLETION BAR ═══
(function(){{
  var s = DATA.status, pct = s.completion;
  var pctC = pct>=70?'#4a9':pct>=30?'#c94':'#c44';
  var d = document.getElementById('completion');
  d.innerHTML = '<div class="completion-top"><div class="completion-pct" style="color:'+pctC+'">'+pct+'%</div>'+
    '<div class="completion-label">mastery across '+s.total_topics+' topics</div></div>'+
    '<div class="completion-bar"><div class="completion-fill" style="width:'+pct+'%;background:'+pctC+';color:'+pctC+';"></div></div>'+
    '<div class="completion-stats">'+
    '<div><div class="cs-val" style="color:#4a9;">'+s.mastered+'</div><div class="cs-label">mastered</div></div>'+
    '<div><div class="cs-val" style="color:#c94;">'+s.attempted+'</div><div class="cs-label">attempted</div></div>'+
    '<div><div class="cs-val" style="color:#666;">'+s.unseen+'</div><div class="cs-label">unseen</div></div>'+
    '</div>';
}})();

// ═══ STUDY NEXT ═══
(function(){{
  var d = document.getElementById('recs');
  var recs = DATA.status.next || [];
  if (recs.length === 0) {{ d.innerHTML='<div style="color:#444;font-size:0.75em;padding:8px 0;">Start answering questions to get recommendations.</div>'; return; }}
  recs.forEach(function(r,i){{
    d.innerHTML += '<div class="rec-card" style="animation-delay:'+i*0.1+'s" onclick="selectTopic(\''+r.topic+'\')">'+
      '<div class="rc-num">RECOMMENDATION '+(i+1)+'</div>'+
      '<div class="rc-topic">'+r.topic+'</div>'+
      '<div class="rc-reason">'+r.reason+'</div></div>';
  }});
}})();

// ═══ KNOWLEDGE GAPS ═══
(function(){{
  var d = document.getElementById('gaps');
  var gaps = DATA.status.gaps || [];
  if (gaps.length === 0) {{ d.innerHTML='<div style="color:#4a9;font-size:0.75em;padding:8px 0;">No knowledge gaps detected.</div>'; return; }}
  gaps.forEach(function(g){{
    var pct = Math.round(g.accuracy*100);
    d.innerHTML += '<div class="gap-card">'+
      '<div class="gc-topic">'+g.topic+'</div>'+
      '<div class="gc-bar"><div class="gc-fill" style="width:'+pct+'%;"></div></div>'+
      '<div class="gc-info">'+pct+'% accuracy &middot; '+g.attempts+' attempts &middot; '+g.phase+'</div>'+
      (g.blocking && g.blocking.length>0 ? '<div class="gc-blocking">Blocks: '+g.blocking.join(', ')+'</div>' : '')+
      '</div>';
  }});
}})();

// ═══ PHASE FILTER TABS ═══
var currentFilter = 'all';
(function(){{
  var d = document.getElementById('phase-tabs');
  var counts = {{all:0,mastered:0,learning:0,nearly:0,struggling:0,unseen:0}};
  Object.values(topics).forEach(function(t){{ counts[t.phase]=(counts[t.phase]||0)+1; counts.all++; }});
  ['all','mastered','nearly','learning','struggling','unseen'].forEach(function(p){{
    var label = p==='all'?'All':PHASE_LABELS[p]||p;
    d.innerHTML += '<div class="phase-tab'+(p==='all'?' active':'')+'" data-phase="'+p+'" onclick="filterPhase(\''+p+'\')">'+label+' ('+counts[p]+')</div>';
  }});
}})();

function filterPhase(phase){{
  currentFilter = phase;
  document.querySelectorAll('.phase-tab').forEach(function(t){{ t.classList.toggle('active', t.dataset.phase===phase); }});
  document.querySelectorAll('.topic-row').forEach(function(r){{
    r.style.display = (phase==='all'||r.dataset.phase===phase)?'flex':'none';
  }});
}}

// ═══ TOPIC ROWS WITH CONFIDENCE RINGS ═══
(function(){{
  var d = document.getElementById('topics');
  var html = '';
  DATA.status.curriculum_order.forEach(function(name, idx){{
    var t = topics[name] || {{}};
    var phase = t.phase || 'unseen';
    var color = PHASE[phase] || '#555';
    var conf = Math.round((t.confidence||0)*100);
    var acc = t.attempts>0 ? Math.round(t.accuracy*100) : 0;
    var circ = 2*Math.PI*35/2;
    var offset = circ - (circ * (conf/100));

    html += '<div class="topic-row" data-phase="'+phase+'" data-name="'+name+'" onclick="selectTopic(\''+name+'\')" style="animation:fadeIn 0.3s ease '+(idx*0.03)+'s both;">'+
      '<div class="tr-ring"><svg viewBox="0 0 40 40"><circle class="ring-bg" cx="20" cy="20" r="17.5"/><circle class="ring-fg" cx="20" cy="20" r="17.5" stroke="'+color+'" stroke-dasharray="'+circ.toFixed(1)+'" stroke-dashoffset="'+offset.toFixed(1)+'"/></svg>'+
      '<div class="ring-label" style="color:'+color+'">'+conf+'</div></div>'+
      '<div class="tr-info"><div class="tr-name">'+name+'</div><div class="tr-meta">'+
      '<span class="tr-badge badge-'+phase+'">'+phase+'</span>'+
      (t.attempts>0?'<span class="tr-stat">'+acc+'% &middot; '+t.attempts+' ans &middot; '+t.streak+' streak</span>':'')+
      '</div></div>'+
      '<div class="tr-bar"><div class="tr-bar-fill" style="width:'+acc+'%;background:'+color+';"></div></div>'+
      '</div>';
  }});
  d.innerHTML = html;
}})();

var selectedTopic = null;
function selectTopic(name){{
  selectedTopic = (selectedTopic===name)?null:name;
  document.querySelectorAll('.topic-row').forEach(function(r){{ r.classList.toggle('selected', r.dataset.name===name && selectedTopic===name); }});
  if (selectedTopic) {{
    // Scroll to it in the panel
    var el = document.querySelector('.topic-row[data-name="'+name+'"]');
    if (el) el.scrollIntoView({{behavior:'smooth',block:'nearest'}});
  }}
  draw();
}}

// ═══ CANVAS — KNOWLEDGE GRAPH ═══
var cv = document.getElementById('graph');
var cx = cv.getContext('2d');
var wrap = document.getElementById('canvas-wrap');
var dpr = window.devicePixelRatio || 1;
var tooltip = document.getElementById('tooltip');

var cam = {{x:0,y:0,zoom:1}};
var drag = {{active:false,sx:0,sy:0,cx:0,cy:0}};
var hoveredNode = null;
var animT = 0;

function resize(){{
  var r = wrap.getBoundingClientRect();
  cv.width = r.width * dpr; cv.height = r.height * dpr;
  cx.setTransform(dpr,0,0,dpr,0,0);
}}
resize();
window.addEventListener('resize',function(){{ resize(); draw(); }});

var W = function(){{ return cv.width/dpr; }};
var H = function(){{ return cv.height/dpr; }};

function mapPos(name){{
  var p = pos[name]; if(!p) return [0,0];
  var m=80;
  var x = m+(p[0]/800)*(W()-2*m);
  var y = m+(p[1]/600)*(H()-2*m);
  return [(x+cam.x)*cam.zoom + W()*(1-cam.zoom)/2,
          (y+cam.y)*cam.zoom + H()*(1-cam.zoom)/2];
}}

function draw(){{
  animT += 0.02;
  cx.clearRect(0,0,W(),H());

  // Subtle grid
  cx.strokeStyle='rgba(255,255,255,0.015)';
  cx.lineWidth=0.5;
  var step=40*cam.zoom;
  if(step>10){{
    for(var gx=0;gx<W();gx+=step){{ cx.beginPath();cx.moveTo(gx,0);cx.lineTo(gx,H());cx.stroke(); }}
    for(var gy=0;gy<H();gy+=step){{ cx.beginPath();cx.moveTo(0,gy);cx.lineTo(W(),gy);cx.stroke(); }}
  }}

  // Prerequisite edges with arrows
  (DATA.prerequisites||[]).forEach(function(e){{
    var a=mapPos(e.from), b=mapPos(e.to);
    var aPhase = (topics[e.from]||{{}}).phase||'unseen';
    var bPhase = (topics[e.to]||{{}}).phase||'unseen';
    var bothMastered = aPhase==='mastered'&&bPhase==='mastered';
    cx.strokeStyle = bothMastered?'rgba(74,170,154,0.2)':'rgba(255,255,255,0.08)';
    cx.lineWidth = bothMastered?1.5:1;
    cx.beginPath();cx.moveTo(a[0],a[1]);cx.lineTo(b[0],b[1]);cx.stroke();

    // Arrowhead
    var dx=b[0]-a[0],dy=b[1]-a[1],len=Math.sqrt(dx*dx+dy*dy);
    if(len>0){{
      var ux=dx/len,uy=dy/len;
      var nodeR = 14*cam.zoom;
      var tipX=b[0]-ux*nodeR, tipY=b[1]-uy*nodeR;
      var aSize=6*cam.zoom;
      cx.fillStyle=cx.strokeStyle;
      cx.beginPath();
      cx.moveTo(tipX, tipY);
      cx.lineTo(tipX-ux*aSize+uy*aSize*0.5, tipY-uy*aSize-ux*aSize*0.5);
      cx.lineTo(tipX-ux*aSize-uy*aSize*0.5, tipY-uy*aSize+ux*aSize*0.5);
      cx.closePath();cx.fill();
    }}
  }});

  // Tension lines
  cx.setLineDash([4*cam.zoom,4*cam.zoom]);
  (DATA.tensions||[]).forEach(function(t){{
    var a=mapPos(t.topic_a), b=mapPos(t.topic_b);
    cx.strokeStyle='rgba(201,164,74,0.15)';
    cx.lineWidth=1;
    cx.beginPath();cx.moveTo(a[0],a[1]);cx.lineTo(b[0],b[1]);cx.stroke();
  }});
  cx.setLineDash([]);

  // Nodes
  nodes.forEach(function(name){{
    var p=mapPos(name);
    var t=topics[name]||{{}};
    var phase=t.phase||'unseen';
    var color=PHASE[phase]||'#555';
    var isSelected = selectedTopic===name;
    var isHovered = hoveredNode===name;
    var baseR = phase==='mastered'?10:phase==='unseen'?5:7;
    var r = baseR*cam.zoom;

    // Selected/hovered glow
    if(isSelected||isHovered){{
      var gR = r + 12*cam.zoom;
      var grad = cx.createRadialGradient(p[0],p[1],r,p[0],p[1],gR);
      grad.addColorStop(0,color+'40');
      grad.addColorStop(1,color+'00');
      cx.fillStyle=grad;
      cx.beginPath();cx.arc(p[0],p[1],gR,0,Math.PI*2);cx.fill();
    }}

    // Mastered pulse
    if(phase==='mastered'){{
      var pulseR = r + (3+Math.sin(animT*2)*2)*cam.zoom;
      cx.strokeStyle = color+'30';
      cx.lineWidth = 1.5*cam.zoom;
      cx.beginPath();cx.arc(p[0],p[1],pulseR,0,Math.PI*2);cx.stroke();
    }}

    // Confidence ring (thick arc)
    var conf = t.confidence||0;
    if(conf>0){{
      cx.strokeStyle = color;
      cx.lineWidth = 3*cam.zoom;
      cx.lineCap='round';
      cx.beginPath();
      cx.arc(p[0],p[1],r+4*cam.zoom,-Math.PI/2,-Math.PI/2+Math.PI*2*conf);
      cx.stroke();
      cx.lineCap='butt';
      // Ring background track
      cx.strokeStyle='rgba(255,255,255,0.04)';
      cx.lineWidth=3*cam.zoom;
      cx.beginPath();
      cx.arc(p[0],p[1],r+4*cam.zoom,0,Math.PI*2);
      cx.stroke();
    }}

    // Node body
    cx.globalAlpha = phase==='unseen'?0.25:1;
    cx.fillStyle=color;
    cx.beginPath();cx.arc(p[0],p[1],r,0,Math.PI*2);cx.fill();

    // Inner detail
    if(phase!=='unseen' && r>4){{
      cx.fillStyle='rgba(0,0,0,0.2)';
      cx.beginPath();cx.arc(p[0]-r*0.2,p[1]-r*0.2,r*0.3,0,Math.PI*2);cx.fill();
    }}
    cx.globalAlpha=1;

    // Label
    var fontSize = Math.max(9, Math.min(12, 11*cam.zoom));
    cx.font = (isSelected||isHovered?'600 ':'400 ')+fontSize+'px -apple-system,sans-serif';
    cx.textAlign='center';
    cx.fillStyle = phase==='unseen'?'#555':(isSelected||isHovered?'#fff':'#ccc');
    cx.fillText(name, p[0], p[1]-r-6*cam.zoom);

    // Accuracy label under node
    if(t.attempts>0 && cam.zoom>0.7){{
      cx.font = Math.max(8,9*cam.zoom)+'px -apple-system,sans-serif';
      cx.fillStyle='#888';
      cx.fillText(Math.round(t.accuracy*100)+'%', p[0], p[1]+r+12*cam.zoom);
    }}
  }});
}}

// ═══ MOUSE INTERACTION ═══
cv.addEventListener('wheel',function(e){{
  e.preventDefault();
  var factor = e.deltaY<0?1.12:0.89;
  cam.zoom = Math.max(0.3, Math.min(5, cam.zoom*factor));
  draw();
}},{{passive:false}});

cv.addEventListener('mousedown',function(e){{
  drag.active=true; drag.sx=e.clientX; drag.sy=e.clientY; drag.cx=cam.x; drag.cy=cam.y;
}});
cv.addEventListener('mousemove',function(e){{
  if(drag.active){{
    cam.x = drag.cx + (e.clientX-drag.sx)/cam.zoom;
    cam.y = drag.cy + (e.clientY-drag.sy)/cam.zoom;
    draw();
    return;
  }}
  // Hit test
  var rect = cv.getBoundingClientRect();
  var mx = e.clientX-rect.left, my = e.clientY-rect.top;
  var hit = null;
  nodes.forEach(function(name){{
    var p=mapPos(name);
    var dx=p[0]-mx, dy=p[1]-my;
    if(Math.sqrt(dx*dx+dy*dy)<16*cam.zoom) hit=name;
  }});
  if(hit!==hoveredNode){{
    hoveredNode=hit;
    draw();
    if(hit){{
      var t=topics[hit]||{{}};
      var phase=t.phase||'unseen';
      var color=PHASE[phase];
      var prereqs = (DATA.prerequisites||[]).filter(function(e){{return e.to===hit;}}).map(function(e){{return e.from;}});
      var html='<div class="tt-name">'+hit+'</div>'+
        '<div class="tt-phase" style="background:'+color+'20;color:'+color+';">'+phase+'</div>'+
        '<div style="margin-top:10px;">'+
        '<div class="tt-row"><span>Confidence</span><span>'+Math.round((t.confidence||0)*100)+'%</span></div>'+
        '<div class="tt-row"><span>Accuracy</span><span>'+(t.attempts>0?Math.round(t.accuracy*100)+'%':'--')+'</span></div>'+
        '<div class="tt-row"><span>Attempts</span><span>'+(t.attempts||0)+'</span></div>'+
        '<div class="tt-row"><span>Streak</span><span>'+(t.streak||0)+'</span></div>'+
        '<div class="tt-row"><span>Best streak</span><span>'+(t.best_streak||0)+'</span></div>'+
        '</div>';
      if(prereqs.length>0){{
        html+='<div class="tt-prereqs"><strong style="color:#888;">Prerequisites:</strong><br>';
        prereqs.forEach(function(p){{
          var ps=topics[p]||{{}};
          var met=ps.grokked||ps.accuracy>0.6;
          html+='<span class="'+(met?'met':'unmet')+'">'+(met?'&#10003;':'&#10007;')+' '+p+'</span> ';
        }});
        html+='</div>';
      }}
      tooltip.innerHTML=html;
      tooltip.style.display='block';
      var tp=mapPos(hit);
      tooltip.style.left=Math.min(tp[0]+20, W()-260)+'px';
      tooltip.style.top=Math.max(10, tp[1]-40)+'px';
    }} else {{
      tooltip.style.display='none';
    }}
  }}
}});
window.addEventListener('mouseup',function(){{ drag.active=false; }});

cv.addEventListener('click',function(e){{
  if(hoveredNode) selectTopic(hoveredNode);
}});

// ═══ ANIMATION LOOP ═══
function animate(){{ draw(); requestAnimationFrame(animate); }}
animate();
</script>
</body>
</html>'''
