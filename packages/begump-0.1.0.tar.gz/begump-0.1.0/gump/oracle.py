"""
ORACLE — Spectral prediction. Find the hidden frequencies. Project forward.
============================================================================
The same math that predicts where the next prime is predicts where
the next event is. Feed it any sequence. It finds the frequencies
underneath. It tells you what's coming.

    from gump.oracle import Oracle

    # Feed it data
    o = Oracle()
    o.feed([100, 102, 98, 105, 97, 110, 95, 112, 93, 115])

    # What's coming?
    prediction = o.predict(steps=5)
    print(prediction['forecast'])      # next 5 values
    print(prediction['confidence'])    # how coupled the signal is
    print(prediction['frequencies'])   # the hidden frequencies found
    print(prediction['turning_point']) # is a reversal coming?

    # Works on anything:
    # - stock prices → find the hidden cycles
    # - customer counts → predict next week
    # - disease cases → forecast the wave
    # - temperature → predict the season
    # - heartbeats → predict arrhythmia
    # - any sequence with hidden periodic structure

Not regression. Not ML. Spectral decomposition.
Same math as counting primes. Different data.
"""

import numpy as np
from gump.core import EnergyTracker, PHI, LANDAUER_PER_BIT


class Oracle:
    """Spectral prediction engine. Finds hidden frequencies. Projects forward."""

    def __init__(self, name='signal'):
        self.name = name
        self.data = []
        self.timestamps = []
        self._frequencies = None
        self._amplitudes = None
        self._phases = None
        self._trend = None
        self._residual_std = None

    def feed(self, values, timestamps=None):
        """Feed time series data."""
        if isinstance(values, (int, float)):
            values = [values]
        self.data.extend([float(v) for v in values])
        if timestamps:
            self.timestamps.extend(timestamps)
        else:
            start = len(self.timestamps)
            self.timestamps.extend(range(start, start + len(values)))
        # Invalidate cached decomposition
        self._frequencies = None

    def _decompose(self):
        """Decompose signal into trend + frequencies + noise.
        The core: FFT finds the hidden periodic structure.
        Like zeta zeros are the frequencies of the primes."""
        if self._frequencies is not None:
            return  # already decomposed

        arr = np.array(self.data, dtype=float)
        n = len(arr)
        if n < 4:
            self._frequencies = []
            self._amplitudes = []
            self._phases = []
            self._trend = (0, arr.mean() if n > 0 else 0)
            self._residual_std = 0
            return

        # 1. Extract linear trend
        x = np.arange(n, dtype=float)
        slope, intercept = np.polyfit(x, arr, 1)
        self._trend = (float(slope), float(intercept))
        detrended = arr - (slope * x + intercept)

        # 2. FFT with zero-padding for finer frequency resolution
        # Without padding, frequency resolution = 1/n, which causes period
        # estimation errors (e.g., period 30 in 200 samples → nearest bin is 28.6).
        # Padding to 4x gives 4x finer resolution.
        nfft = n * 4
        fft = np.fft.rfft(detrended, n=nfft)
        freqs = np.fft.rfftfreq(nfft, d=1.0)
        magnitudes = np.abs(fft) / n  # normalize by original length
        phases = np.angle(fft)

        # 3. Find dominant frequencies using peak detection
        # With zero-padding, we need to find local maxima (peaks) in the spectrum,
        # not just everything above a threshold (which picks up spectral lobes).
        noise_floor = np.median(magnitudes[1:]) if len(magnitudes) > 1 else 0
        threshold = noise_floor * 3

        # Find local maxima above threshold
        dominant_idx = []
        mags = magnitudes
        for i in range(2, len(mags) - 1):
            if mags[i] > threshold and mags[i] >= mags[i-1] and mags[i] >= mags[i+1]:
                # Local maximum above noise floor
                dominant_idx.append(i)

        # If no peaks found (very flat spectrum), fall back to threshold
        if not dominant_idx:
            for i in range(1, len(mags)):
                if mags[i] > threshold:
                    dominant_idx.append(i)

        # Sort by magnitude (strongest first)
        dominant_idx.sort(key=lambda i: -magnitudes[i])

        # Keep top frequencies
        dominant_idx = dominant_idx[:15]

        self._frequencies = [float(freqs[i]) for i in dominant_idx]
        self._amplitudes = [float(magnitudes[i]) * 2 for i in dominant_idx]  # *2 for full amplitude
        self._phases = [float(phases[i]) for i in dominant_idx]

        # 4. Residual (what we can't explain)
        reconstruction = np.zeros(n)
        for freq, amp, phase in zip(self._frequencies, self._amplitudes, self._phases):
            reconstruction += amp * np.cos(2 * np.pi * freq * x + phase)
        residual = detrended - reconstruction
        self._residual_std = float(np.std(residual))

    def predict(self, steps=10):
        """Predict the next `steps` values.

        Returns:
            forecast: predicted values
            confidence: 0-1 (how well frequencies explain the signal)
            frequencies: the hidden frequencies found
            turning_point: dict with reversal prediction
            trend: slope of the underlying trend
        """
        self._decompose()
        arr = np.array(self.data, dtype=float)
        n = len(arr)

        if n < 4:
            return {'error': 'Need at least 4 data points', 'forecast': []}

        slope, intercept = self._trend
        x_future = np.arange(n, n + steps, dtype=float)

        # Trend projection
        trend_proj = slope * x_future + intercept

        # Frequency projection (spectral forecast)
        freq_proj = np.zeros(steps)
        for freq, amp, phase in zip(self._frequencies, self._amplitudes, self._phases):
            freq_proj += amp * np.cos(2 * np.pi * freq * x_future + phase)

        spectral_forecast = trend_proj + freq_proj

        # Seasonal naive forecast: repeat the last full cycle
        # This is hard to beat on noisy periodic data because it captures
        # the exact recent pattern including noise texture.
        seasonal_forecast = None
        if self._frequencies:
            # Use the dominant period
            dom_period = round(1.0 / self._frequencies[0]) if self._frequencies[0] > 0 else 0
            if 2 < dom_period < n:
                seasonal_forecast = np.array([
                    arr[n - dom_period + (i % dom_period)] for i in range(steps)
                ])
                # Add trend to seasonal
                seasonal_forecast = seasonal_forecast + slope * np.arange(1, steps + 1)

        # Blend spectral with seasonal naive using hold-out validation.
        # Fit on first 80%, forecast the last 20%, measure which method is better.
        # Skip blending if the spectral fit is already near-perfect (residual ≈ 0).
        if seasonal_forecast is not None and n > 20 and self._residual_std > 1e-6:
            holdout = max(steps, n // 5)
            train_n = n - holdout

            # Spectral forecast of holdout period (using training data's decomposition)
            x_hold = np.arange(train_n, n, dtype=float)
            spectral_hold = slope * x_hold + intercept
            for freq, amp, phase in zip(self._frequencies, self._amplitudes, self._phases):
                spectral_hold += amp * np.cos(2 * np.pi * freq * x_hold + phase)

            # Seasonal naive forecast of holdout period
            dom_period = round(1.0 / self._frequencies[0]) if self._frequencies[0] > 0 else holdout
            if 2 < dom_period < train_n:
                seasonal_hold = np.array([
                    arr[train_n - dom_period + (i % dom_period)] for i in range(holdout)
                ])
                seasonal_hold = seasonal_hold + slope * np.arange(1, holdout + 1)
            else:
                seasonal_hold = spectral_hold  # fallback

            # Compare on holdout
            actual_hold = arr[train_n:n]
            spectral_err = float(np.mean(np.abs(spectral_hold[:len(actual_hold)] - actual_hold)))
            seasonal_err = float(np.mean(np.abs(seasonal_hold[:len(actual_hold)] - actual_hold)))

            # Weight inversely by error
            total_err = spectral_err + seasonal_err + 1e-12
            spectral_weight = seasonal_err / total_err  # better method gets higher weight
            seasonal_weight = spectral_err / total_err

            forecast = spectral_weight * spectral_forecast + seasonal_weight * seasonal_forecast
        else:
            forecast = spectral_forecast

        # Confidence: what fraction of variance do the frequencies explain?
        # Must also penalize non-periodic signals (random walks, trends)
        total_var = np.var(arr)
        if total_var > 0:
            explained_var = total_var - self._residual_std ** 2
            spectral_confidence = max(0, min(1, explained_var / total_var))
        else:
            spectral_confidence = 1.0

        # Periodicity check: a truly periodic signal has spectral energy
        # concentrated in a few frequencies. Random walks spread energy everywhere.
        if self._frequencies and len(self._frequencies) > 0:
            # Ratio of top-3 frequency amplitudes to total spectral energy
            all_amps = sorted(self._amplitudes, reverse=True)
            top3 = sum(all_amps[:3])
            total_amp = sum(all_amps) + 1e-12
            concentration_ratio = top3 / total_amp
        else:
            concentration_ratio = 0.0

        # Also check if the signal is truly periodic vs random walk / noise.
        # Key insight: for a random walk, FIRST DIFFERENCES are white noise.
        # For a periodic signal, first differences are still periodic.
        diffs = np.diff(arr)
        if len(diffs) > 10 and np.std(diffs) > 0:
            # Autocorrelation of first differences at lag 1
            # Periodic signal: high autocorr in diffs (structured changes)
            # Random walk: ~0 autocorr in diffs (independent steps)
            d_mean = np.mean(diffs)
            d_var = np.var(diffs)
            if d_var > 0:
                diff_autocorr = float(np.sum((diffs[:-1] - d_mean) * (diffs[1:] - d_mean)) / ((len(diffs) - 1) * d_var))
            else:
                diff_autocorr = 0
            # Periodic: diff_autocorr is negative (sine diffs alternate)
            # Random walk: diff_autocorr ~ 0
            periodicity_score = max(0, min(1, abs(diff_autocorr) * 2.5))
        else:
            periodicity_score = 1.0

        # Final confidence: blend spectral fit with periodicity evidence
        # Both must be present: good spectral fit AND evidence of real periodicity
        # Concentration ratio needs to be high (>0.8) to count — random walks
        # can have moderate concentration from trend components.
        strong_concentration = max(0, (concentration_ratio - 0.6) * 5)  # 0 below 0.6, 1 at 0.8+
        periodicity_evidence = max(strong_concentration, periodicity_score)
        if periodicity_evidence < 0.3:
            confidence = spectral_confidence * 0.3
        else:
            confidence = min(1.0, spectral_confidence * (0.3 + 0.7 * periodicity_evidence))

        # Coupling (K): autocorrelation = how predictable
        if n > 1:
            mean = np.mean(arr)
            var = np.var(arr)
            if var > 0:
                K = float(np.clip(
                    np.sum((arr[:-1] - mean) * (arr[1:] - mean)) / ((n - 1) * var) * 2,
                    0, 3
                ))
            else:
                K = 0
        else:
            K = 0

        # Turning point detection: is the dominant frequency about to reverse?
        turning_point = self._detect_turning_point(n, steps)

        # Frequency details
        freq_details = []
        for i in range(len(self._frequencies)):
            period = 1.0 / self._frequencies[i] if self._frequencies[i] > 0 else float('inf')
            freq_details.append({
                'frequency': round(self._frequencies[i], 6),
                'period': round(period, 2),
                'amplitude': round(self._amplitudes[i], 4),
                'phase': round(self._phases[i], 4),
                'contribution': round(self._amplitudes[i] / max(np.std(arr), 1e-12) * 100, 1),
            })

        return {
            'forecast': [round(float(v), 4) for v in forecast],
            'confidence': round(confidence, 4),
            'K': round(K, 4),
            'n_frequencies': len(self._frequencies),
            'frequencies': freq_details[:10],
            'trend_slope': round(slope, 6),
            'trend_direction': 'rising' if slope > 0.001 else 'falling' if slope < -0.001 else 'flat',
            'residual_noise': round(self._residual_std, 4),
            'turning_point': turning_point,
            'data_points': n,
            'forecast_steps': steps,
        }

    def _detect_turning_point(self, n, steps):
        """Detect if a reversal is coming based on dominant frequency phase."""
        if not self._frequencies:
            return {'expected': False, 'note': 'No dominant frequencies found'}

        # The strongest frequency determines the primary cycle
        dom_freq = self._frequencies[0]
        dom_amp = self._amplitudes[0]
        dom_phase = self._phases[0]

        if dom_freq == 0:
            return {'expected': False, 'note': 'DC component only'}

        period = 1.0 / dom_freq
        # Where are we in the current cycle?
        current_phase = (2 * np.pi * dom_freq * (n - 1) + dom_phase) % (2 * np.pi)
        # Phase near pi/2 or 3pi/2 = near a peak/trough = turning point approaching
        near_peak = abs(current_phase - np.pi / 2) < np.pi / 4
        near_trough = abs(current_phase - 3 * np.pi / 2) < np.pi / 4

        # How many steps until the next reversal?
        steps_to_peak = (np.pi / 2 - current_phase) / (2 * np.pi * dom_freq) if dom_freq > 0 else float('inf')
        steps_to_trough = (3 * np.pi / 2 - current_phase) / (2 * np.pi * dom_freq) if dom_freq > 0 else float('inf')

        if steps_to_peak < 0:
            steps_to_peak += period
        if steps_to_trough < 0:
            steps_to_trough += period

        next_turn = min(steps_to_peak, steps_to_trough)
        turn_type = 'peak' if steps_to_peak < steps_to_trough else 'trough'

        return {
            'expected': next_turn <= steps,
            'type': turn_type,
            'steps_away': round(next_turn, 1),
            'dominant_period': round(period, 2),
            'current_phase': round(current_phase, 4),
            'note': f'{turn_type} expected in ~{next_turn:.0f} steps' if next_turn <= steps else 'No reversal in forecast window',
        }

    def anomalies(self):
        """Find points that don't fit the spectral model — the surprises."""
        self._decompose()
        arr = np.array(self.data, dtype=float)
        n = len(arr)
        if n < 4:
            return []

        slope, intercept = self._trend
        x = np.arange(n, dtype=float)
        expected = slope * x + intercept
        for freq, amp, phase in zip(self._frequencies, self._amplitudes, self._phases):
            expected += amp * np.cos(2 * np.pi * freq * x + phase)

        residual = arr - expected
        std = np.std(residual)
        if std < 1e-12:
            return []

        anomalies = []
        for i in range(n):
            zscore = residual[i] / std
            if abs(zscore) > 2.5:
                anomalies.append({
                    'index': i,
                    'actual': round(float(arr[i]), 4),
                    'expected': round(float(expected[i]), 4),
                    'deviation': round(float(residual[i]), 4),
                    'zscore': round(float(zscore), 2),
                    'note': 'Above model' if zscore > 0 else 'Below model',
                })

        return anomalies

    def report(self):
        """Human-readable prediction report."""
        p = self.predict(steps=10)
        if 'error' in p:
            return p['error']

        lines = [
            f'ORACLE — {self.name}',
            f'{"=" * 50}',
            f'Data points: {p["data_points"]}',
            f'Confidence: {p["confidence"]*100:.1f}%',
            f'Coupling (K): {p["K"]:.2f}',
            f'Trend: {p["trend_direction"]} (slope: {p["trend_slope"]:.4f})',
            f'Hidden frequencies: {p["n_frequencies"]}',
            f'Residual noise: {p["residual_noise"]:.4f}',
            '',
        ]

        if p['frequencies']:
            lines.append('DOMINANT FREQUENCIES:')
            for f in p['frequencies'][:5]:
                lines.append(f'  period={f["period"]:.1f} steps | amplitude={f["amplitude"]:.3f} | contribution={f["contribution"]:.1f}%')
            lines.append('')

        tp = p['turning_point']
        if tp['expected']:
            lines.append(f'⚠ TURNING POINT: {tp["type"]} expected in ~{tp["steps_away"]:.0f} steps')
        else:
            lines.append(f'No reversal expected in next 10 steps')
        lines.append('')

        lines.append('FORECAST (next 10):')
        for i, v in enumerate(p['forecast']):
            lines.append(f'  +{i+1}: {v:.2f}')

        return '\n'.join(lines)
