"""
ACCORD — Compliance intelligence. Law meets spectral brilliance.
==================================================================
Scans regulations. Scans your business. Finds the tensions between them.
Tells you what affects you, how to fix it, and where it came from.

    from gump.accord import Accord

    # Set up your business profile
    a = Accord('beGump LLC')
    a.set_profile({
        'industry': 'software',
        'state': 'NJ',
        'employees': 1,
        'handles_data': True,
        'accepts_payments': True,
        'international': False,
    })

    # Feed it regulations
    a.ingest_regulation(
        title='NJ Data Privacy Act',
        text='All businesses handling personal data of NJ residents must...',
        jurisdiction='NJ',
        effective='2026-07-01',
        category='privacy',
    )

    # Find what affects you
    print(a.scan())           # compliance gaps
    print(a.impact())         # how each regulation hits YOUR business
    print(a.action_plan())    # what to do, prioritized
    print(a.trace_origin())   # where each regulation came from

Not a PDF dump. Not a checklist.
Spectral tension between your operations and the law.
Same math that finds fraud finds non-compliance.
"""

import time
import json
import numpy as np
from collections import defaultdict
from gump.knowledge import KnowledgeEngine
from gump.core import _TensionDetector


class Regulation:
    """A single regulation or law."""
    def __init__(self, title, text, jurisdiction='federal', effective=None,
                 category='general', source=None, penalty=None):
        self.title = title
        self.text = text
        self.jurisdiction = jurisdiction
        self.effective = effective or 'immediate'
        self.category = category
        self.source = source
        self.penalty = penalty
        self.requirements = []  # extracted by knowledge engine
        self.keywords = set()
        self.ingested_at = time.time()


class ComplianceGap:
    """A tension between a regulation and your business."""
    def __init__(self, regulation, area, tension_score, impact, action):
        self.regulation = regulation
        self.area = area
        self.tension = tension_score
        self.impact = impact
        self.action = action


class Accord:
    """Compliance intelligence engine."""

    # Categories and what triggers them
    TRIGGERS = {
        'privacy': ['data', 'personal', 'consumer', 'privacy', 'gdpr', 'ccpa', 'collect',
                     'store', 'process', 'cookie', 'consent', 'opt-out', 'breach', 'notification'],
        'payment': ['payment', 'pci', 'card', 'transaction', 'stripe', 'merchant', 'refund',
                     'chargeback', 'billing', 'subscription', 'recurring'],
        'employment': ['employee', 'wage', 'overtime', 'discrimination', 'harassment', 'hire',
                       'fire', 'termination', 'benefits', 'contractor', 'w-2', '1099', 'minimum wage'],
        'tax': ['tax', 'sales tax', 'income', 'deduction', 'filing', 'quarterly', 'nexus',
                'withholding', 'exempt', 'irs', 'audit'],
        'corporate': ['llc', 'incorporation', 'annual report', 'registered agent', 'operating agreement',
                      'dissolution', 'foreign qualification', 'good standing'],
        'intellectual_property': ['patent', 'trademark', 'copyright', 'trade secret', 'license',
                                  'ip', 'infringement', 'dmca'],
        'security': ['encryption', 'cybersecurity', 'breach', 'incident response', 'firewall',
                     'access control', 'audit log', 'penetration test'],
        'international': ['export', 'import', 'sanctions', 'ofac', 'tariff', 'customs',
                          'foreign', 'cross-border', 'gdpr', 'eu'],
        'accessibility': ['ada', 'accessibility', 'wcag', 'disability', 'accommodation',
                          'screen reader', 'alt text'],
        'environmental': ['emissions', 'waste', 'recycling', 'carbon', 'epa', 'hazardous',
                          'sustainability', 'environmental'],
    }

    def __init__(self, company_name='Company'):
        self.company = company_name
        self.profile = {}
        self.regulations = []
        self.knowledge = KnowledgeEngine()
        self.gaps = []
        self._scanned = False

    def set_profile(self, profile):
        """Set your business profile. This determines what regulations affect you."""
        self.profile = profile
        self._scanned = False

    def ingest_regulation(self, title, text, jurisdiction='federal', effective=None,
                          category='general', source=None, penalty=None):
        """Feed a regulation into the engine."""
        reg = Regulation(title, text, jurisdiction, effective, category, source, penalty)

        # Extract keywords and requirements using Knowledge Engine
        self.knowledge.absorb(text)

        # Extract keywords from text
        lower = text.lower()
        for cat, keywords in self.TRIGGERS.items():
            for kw in keywords:
                if kw in lower:
                    reg.keywords.add(cat)

        # Extract requirement sentences (contains "must", "shall", "required")
        sentences = text.replace('\n', ' ').split('.')
        for sent in sentences:
            sent = sent.strip()
            if any(word in sent.lower() for word in ['must', 'shall', 'required', 'prohibited',
                                                       'mandatory', 'obligated', 'failure to']):
                reg.requirements.append(sent.strip() + '.')

        self.regulations.append(reg)
        self._scanned = False
        return {
            'title': title,
            'categories': list(reg.keywords),
            'requirements': len(reg.requirements),
            'jurisdiction': jurisdiction,
        }

    def scan(self):
        """Scan for compliance gaps between regulations and your business.
        Returns prioritized list of gaps."""
        if not self.profile:
            return {'error': 'Set your business profile first with set_profile()'}
        if not self.regulations:
            return {'error': 'Ingest at least one regulation first'}

        self.gaps = []

        for reg in self.regulations:
            # Does this regulation's jurisdiction match?
            if reg.jurisdiction != 'federal':
                if self.profile.get('state', '').upper() != reg.jurisdiction.upper():
                    continue  # different state, doesn't apply

            # Does this regulation's category match our business activities?
            relevant_cats = set()
            if self.profile.get('handles_data'):
                relevant_cats.update(['privacy', 'security'])
            if self.profile.get('accepts_payments'):
                relevant_cats.add('payment')
            if self.profile.get('employees', 0) > 0:
                relevant_cats.add('employment')
            if self.profile.get('international'):
                relevant_cats.add('international')
            # Tax and corporate always apply
            relevant_cats.update(['tax', 'corporate'])
            # Industry-specific
            if self.profile.get('industry') == 'software':
                relevant_cats.update(['intellectual_property', 'accessibility'])
            if self.profile.get('industry') == 'healthcare':
                relevant_cats.update(['privacy', 'security'])
            if self.profile.get('industry') == 'finance':
                relevant_cats.update(['payment', 'security', 'privacy'])

            # Check if regulation categories overlap with our relevant categories
            overlap = reg.keywords & relevant_cats
            if not overlap and reg.category not in relevant_cats:
                continue  # doesn't apply to us

            # Score the tension: how many requirements, how severe
            base_tension = len(reg.requirements) * 2
            if reg.penalty:
                base_tension += 5  # penalties increase urgency
            if reg.effective and reg.effective != 'immediate':
                # Future effective date = less urgent
                base_tension *= 0.7

            # For each requirement, assess impact
            for req in reg.requirements:
                impact = self._assess_impact(req, reg)
                action = self._suggest_action(req, reg, impact)

                self.gaps.append(ComplianceGap(
                    regulation=reg,
                    area=list(overlap)[0] if overlap else reg.category,
                    tension_score=base_tension + impact['severity'],
                    impact=impact,
                    action=action,
                ))

        # Sort by tension (highest = most urgent)
        self.gaps.sort(key=lambda g: -g.tension)
        self._scanned = True

        return {
            'company': self.company,
            'gaps_found': len(self.gaps),
            'critical': len([g for g in self.gaps if g.tension > 15]),
            'high': len([g for g in self.gaps if 10 < g.tension <= 15]),
            'medium': len([g for g in self.gaps if 5 < g.tension <= 10]),
            'low': len([g for g in self.gaps if g.tension <= 5]),
            'categories_affected': list(set(g.area for g in self.gaps)),
            'regulations_applicable': len(set(g.regulation.title for g in self.gaps)),
        }

    def _assess_impact(self, requirement, reg):
        """Assess the impact of a specific requirement on this business."""
        lower = requirement.lower()
        severity = 0
        areas = []

        if any(w in lower for w in ['fine', 'penalty', 'violation', 'criminal']):
            severity += 5
            areas.append('legal_risk')
        if any(w in lower for w in ['data', 'personal', 'consumer', 'user']):
            severity += 3
            areas.append('data_handling')
        if any(w in lower for w in ['notify', 'report', 'disclose', 'file']):
            severity += 2
            areas.append('reporting')
        if any(w in lower for w in ['encrypt', 'secure', 'protect', 'safeguard']):
            severity += 3
            areas.append('security')
        if any(w in lower for w in ['annual', 'quarterly', 'monthly', 'recurring']):
            severity += 1
            areas.append('ongoing_obligation')

        return {
            'severity': severity,
            'areas': areas,
            'requirement_text': requirement[:200],
            'regulation': reg.title,
        }

    def _suggest_action(self, requirement, reg, impact):
        """Suggest specific action to address a compliance gap."""
        lower = requirement.lower()

        if 'notify' in lower or 'report' in lower:
            return {
                'action': f'Set up {reg.category} notification/reporting procedure',
                'effort': 'medium',
                'urgency': 'before ' + reg.effective if reg.effective != 'immediate' else 'immediate',
                'type': 'process',
            }
        if 'encrypt' in lower or 'secure' in lower:
            return {
                'action': f'Verify encryption and security controls for {reg.category}',
                'effort': 'high',
                'urgency': 'immediate',
                'type': 'technical',
            }
        if 'consent' in lower or 'opt' in lower:
            return {
                'action': f'Implement consent mechanism for {reg.category}',
                'effort': 'medium',
                'urgency': 'before ' + reg.effective if reg.effective != 'immediate' else 'immediate',
                'type': 'product',
            }
        if 'file' in lower or 'submit' in lower or 'register' in lower:
            return {
                'action': f'Complete {reg.category} filing/registration',
                'effort': 'low',
                'urgency': 'before ' + reg.effective if reg.effective != 'immediate' else 'immediate',
                'type': 'administrative',
            }
        return {
            'action': f'Review and address: {requirement[:100]}',
            'effort': 'medium',
            'urgency': 'review needed',
            'type': 'review',
        }

    def impact(self):
        """Get detailed impact assessment for each regulation."""
        if not self._scanned:
            self.scan()

        impacts = defaultdict(list)
        for gap in self.gaps:
            impacts[gap.regulation.title].append({
                'area': gap.area,
                'tension': round(gap.tension, 1),
                'severity': gap.impact['severity'],
                'requirement': gap.impact['requirement_text'][:150],
                'action': gap.action['action'],
                'effort': gap.action['effort'],
                'urgency': gap.action['urgency'],
            })

        return dict(impacts)

    def action_plan(self):
        """Prioritized action plan — what to do first."""
        if not self._scanned:
            self.scan()

        actions = []
        seen = set()
        for gap in self.gaps:
            action_key = gap.action['action']
            if action_key in seen:
                continue
            seen.add(action_key)
            actions.append({
                'priority': 'CRITICAL' if gap.tension > 15 else 'HIGH' if gap.tension > 10 else 'MEDIUM' if gap.tension > 5 else 'LOW',
                'action': gap.action['action'],
                'regulation': gap.regulation.title,
                'area': gap.area,
                'effort': gap.action['effort'],
                'urgency': gap.action['urgency'],
                'type': gap.action['type'],
            })

        return actions

    def trace_origin(self):
        """Trace where each regulation came from."""
        origins = []
        for reg in self.regulations:
            origins.append({
                'title': reg.title,
                'jurisdiction': reg.jurisdiction,
                'source': reg.source or 'unknown',
                'category': reg.category,
                'effective': reg.effective,
                'penalty': reg.penalty,
                'requirements_count': len(reg.requirements),
                'affects_categories': list(reg.keywords),
            })
        return origins

    # ═══ DEADLINES + STATUS TRACKING ═══

    def deadlines(self):
        """Get all upcoming compliance deadlines, sorted by urgency."""
        import datetime
        today = datetime.date.today()
        items = []
        for reg in self.regulations:
            if reg.effective and reg.effective != 'immediate':
                try:
                    # Parse date formats: YYYY-MM-DD, MM/DD/YYYY, etc
                    for fmt in ['%Y-%m-%d', '%m/%d/%Y', '%B %d, %Y', '%b %d, %Y']:
                        try:
                            eff_date = datetime.datetime.strptime(reg.effective, fmt).date()
                            break
                        except ValueError:
                            continue
                    else:
                        continue
                    days_left = (eff_date - today).days
                    items.append({
                        'regulation': reg.title,
                        'effective': reg.effective,
                        'days_left': days_left,
                        'urgency': 'OVERDUE' if days_left < 0 else 'URGENT' if days_left < 30 else 'UPCOMING' if days_left < 90 else 'FUTURE',
                        'category': reg.category,
                        'requirements': len(reg.requirements),
                    })
                except Exception:
                    pass
            elif reg.effective == 'immediate':
                items.append({
                    'regulation': reg.title,
                    'effective': 'immediate',
                    'days_left': 0,
                    'urgency': 'URGENT',
                    'category': reg.category,
                    'requirements': len(reg.requirements),
                })
        items.sort(key=lambda x: x['days_left'])
        return items

    _compliance_status = {}  # gap_key → {status, updated, notes}

    def mark_compliant(self, regulation_title, action, status='done', notes=''):
        """Mark a compliance gap as addressed."""
        key = f'{regulation_title}::{action}'
        self._compliance_status[key] = {
            'status': status,  # 'done', 'in_progress', 'not_started', 'not_applicable'
            'updated': time.time(),
            'notes': notes,
        }

    def compliance_status(self):
        """Get full compliance status — what's done, in progress, and open."""
        if not self._scanned:
            self.scan()

        done = 0
        in_progress = 0
        open_items = 0
        items = []

        for gap in self.gaps:
            key = f'{gap.regulation.title}::{gap.action["action"]}'
            status = self._compliance_status.get(key, {'status': 'not_started'})
            s = status['status']
            if s == 'done':
                done += 1
            elif s == 'in_progress':
                in_progress += 1
            else:
                open_items += 1
            items.append({
                'regulation': gap.regulation.title,
                'action': gap.action['action'],
                'status': s,
                'priority': 'CRITICAL' if gap.tension > 15 else 'HIGH' if gap.tension > 10 else 'MEDIUM',
                'area': gap.area,
            })

        total = done + in_progress + open_items
        return {
            'total': total,
            'done': done,
            'in_progress': in_progress,
            'open': open_items,
            'compliance_pct': round(done / max(total, 1) * 100, 1),
            'items': items,
        }

    # ═══ RISK SCORING ═══

    def risk_assessment(self):
        """Calculate risk score per regulation: penalty × exposure × likelihood."""
        if not self._scanned:
            self.scan()

        risks = []
        for reg in self.regulations:
            # Extract penalty amount
            penalty_score = 0
            if reg.penalty:
                penalty_lower = reg.penalty.lower()
                if 'dissolution' in penalty_lower:
                    penalty_score = 10  # existential
                elif '$' in penalty_lower:
                    # Try to extract dollar amount
                    import re
                    amounts = re.findall(r'\$[\d,]+', penalty_lower)
                    if amounts:
                        amt = int(amounts[0].replace('$', '').replace(',', ''))
                        if amt >= 100000: penalty_score = 8
                        elif amt >= 10000: penalty_score = 6
                        elif amt >= 1000: penalty_score = 4
                        else: penalty_score = 2
                elif 'criminal' in penalty_lower:
                    penalty_score = 10
                elif 'fine' in penalty_lower:
                    penalty_score = 5

            # Exposure: how many requirements affect us
            reg_gaps = [g for g in self.gaps if g.regulation.title == reg.title]
            exposure = min(10, len(reg_gaps))

            # Compliance status
            addressed = sum(1 for g in reg_gaps
                          if self._compliance_status.get(
                              f'{g.regulation.title}::{g.action["action"]}',
                              {}
                          ).get('status') == 'done')
            unaddressed = len(reg_gaps) - addressed
            likelihood = min(10, unaddressed * 2) if reg_gaps else 0

            risk_score = round((penalty_score * exposure * likelihood) / 10, 1)

            risks.append({
                'regulation': reg.title,
                'penalty_score': penalty_score,
                'exposure': exposure,
                'likelihood': likelihood,
                'risk_score': risk_score,
                'rating': 'CRITICAL' if risk_score > 30 else 'HIGH' if risk_score > 15 else 'MEDIUM' if risk_score > 5 else 'LOW',
                'gaps': len(reg_gaps),
                'addressed': addressed,
            })

        risks.sort(key=lambda r: -r['risk_score'])
        return risks

    # ═══ REGULATORY CHANGE DETECTION ═══

    def detect_changes(self, title, new_text):
        """Compare new version of a regulation against the previously ingested version.
        Returns what changed and how it affects you."""
        old_reg = None
        for reg in self.regulations:
            if reg.title == title:
                old_reg = reg
                break

        if not old_reg:
            return {'error': f'No previous version of "{title}" found'}

        old_sentences = set(s.strip() for s in old_reg.text.replace('\n', ' ').split('.') if s.strip())
        new_sentences = set(s.strip() for s in new_text.replace('\n', ' ').split('.') if s.strip())

        added = new_sentences - old_sentences
        removed = old_sentences - new_sentences
        unchanged = old_sentences & new_sentences

        # Extract new requirements from added sentences
        new_requirements = []
        for sent in added:
            if any(w in sent.lower() for w in ['must', 'shall', 'required', 'prohibited', 'mandatory']):
                new_requirements.append(sent)

        removed_requirements = []
        for sent in removed:
            if any(w in sent.lower() for w in ['must', 'shall', 'required', 'prohibited', 'mandatory']):
                removed_requirements.append(sent)

        return {
            'regulation': title,
            'sentences_added': len(added),
            'sentences_removed': len(removed),
            'sentences_unchanged': len(unchanged),
            'new_requirements': new_requirements,
            'removed_requirements': removed_requirements,
            'impact': 'SIGNIFICANT' if new_requirements else 'MINOR' if added else 'NONE',
            'action_needed': len(new_requirements) > 0,
            'details': {
                'added': list(added)[:10],
                'removed': list(removed)[:10],
            },
        }

    # ═══ CHECKLIST GENERATION ═══

    def generate_checklist(self, category=None):
        """Generate a compliance checklist for a specific category or all."""
        if not self._scanned:
            self.scan()

        checklist = []
        seen = set()

        for gap in self.gaps:
            if category and gap.area != category:
                continue
            action_key = gap.action['action']
            if action_key in seen:
                continue
            seen.add(action_key)

            key = f'{gap.regulation.title}::{action_key}'
            status = self._compliance_status.get(key, {'status': 'not_started'})

            checklist.append({
                'item': action_key,
                'regulation': gap.regulation.title,
                'category': gap.area,
                'priority': 'CRITICAL' if gap.tension > 15 else 'HIGH' if gap.tension > 10 else 'MEDIUM',
                'effort': gap.action['effort'],
                'type': gap.action['type'],
                'status': status['status'],
                'done': status['status'] == 'done',
            })

        return {
            'category': category or 'all',
            'total': len(checklist),
            'done': sum(1 for c in checklist if c['done']),
            'remaining': sum(1 for c in checklist if not c['done']),
            'items': checklist,
        }

    # ═══ AUDIT TRAIL ═══

    # ═══ REGULATORY INTELLIGENCE — where it came from, how to counter ═══

    def ingest_origin(self, regulation_title, origin_data):
        """Add origin intelligence to a regulation.

        origin_data dict:
            sponsor: who introduced it
            co_sponsors: list of co-sponsors
            committee: which committee
            lobbied_by: who pushed for it
            vote: how it passed
            public_comment: is there a comment period?
            comment_deadline: when does comment close?
            related_bills: connected legislation
            exemptions: known exemptions
            history: list of {date, event} dicts
        """
        for reg in self.regulations:
            if reg.title == regulation_title:
                reg._origin = origin_data
                return {'status': 'added', 'regulation': regulation_title}
        return {'error': f'Regulation "{regulation_title}" not found'}

    def trace_full(self, regulation_title=None):
        """Full genealogy of a regulation — who, when, why, how."""
        results = []
        for reg in self.regulations:
            if regulation_title and reg.title != regulation_title:
                continue
            origin = getattr(reg, '_origin', {})

            # Build the chain: who → committee → vote → signed → effective
            chain = []
            if origin.get('sponsor'):
                chain.append({'actor': origin['sponsor'], 'role': 'sponsor', 'action': 'introduced'})
            for cs in origin.get('co_sponsors', []):
                chain.append({'actor': cs, 'role': 'co-sponsor', 'action': 'co-signed'})
            if origin.get('committee'):
                chain.append({'actor': origin['committee'], 'role': 'committee', 'action': 'approved'})
            for lb in origin.get('lobbied_by', []):
                chain.append({'actor': lb, 'role': 'lobbyist', 'action': 'advocated'})
            for event in origin.get('history', []):
                chain.append({'actor': event.get('actor', 'unknown'), 'role': 'process',
                             'action': event.get('event', ''), 'date': event.get('date', '')})

            results.append({
                'regulation': reg.title,
                'jurisdiction': reg.jurisdiction,
                'category': reg.category,
                'source': reg.source,
                'sponsor': origin.get('sponsor', 'unknown'),
                'co_sponsors': origin.get('co_sponsors', []),
                'committee': origin.get('committee', 'unknown'),
                'lobbied_by': origin.get('lobbied_by', []),
                'vote': origin.get('vote', 'unknown'),
                'public_comment': origin.get('public_comment', False),
                'comment_deadline': origin.get('comment_deadline'),
                'exemptions': origin.get('exemptions', []),
                'related_bills': origin.get('related_bills', []),
                'chain': chain,
                'chain_length': len(chain),
            })

        return results[0] if regulation_title and results else results

    def find_exemptions(self, regulation_title=None):
        """Find exemptions that might apply to your business."""
        exemptions = []
        for reg in self.regulations:
            if regulation_title and reg.title != regulation_title:
                continue

            origin = getattr(reg, '_origin', {})
            explicit = origin.get('exemptions', [])

            # Also scan the regulation text for exemption language
            lower = reg.text.lower()
            auto_exemptions = []

            exemption_phrases = [
                ('small business', 'Small business exemption may apply'),
                ('fewer than', 'Size-based exemption — check employee/revenue threshold'),
                ('less than', 'Size-based exemption — check threshold'),
                ('except for', 'Explicit exception clause found'),
                ('exempt', 'Exemption clause found in text'),
                ('not apply to', 'Non-applicability clause found'),
                ('grandfather', 'Grandfather clause — existing operations may be exempt'),
                ('phase-in', 'Phase-in period — compliance may be delayed'),
                ('safe harbor', 'Safe harbor provision — specific compliance path available'),
                ('good faith', 'Good faith effort provision — shows intent matters'),
            ]

            for phrase, note in exemption_phrases:
                if phrase in lower:
                    # Find the sentence containing the exemption
                    for sent in reg.text.split('.'):
                        if phrase in sent.lower():
                            auto_exemptions.append({
                                'type': phrase,
                                'note': note,
                                'text': sent.strip()[:200],
                            })
                            break

            exemptions.append({
                'regulation': reg.title,
                'explicit_exemptions': explicit,
                'detected_exemptions': auto_exemptions,
                'total': len(explicit) + len(auto_exemptions),
            })

        return exemptions[0] if regulation_title and exemptions else exemptions

    def counter_strategies(self, regulation_title=None):
        """Generate counter-strategies for each regulation.
        Not just comply — challenge, adapt, restructure, comment."""
        strategies = []

        for reg in self.regulations:
            if regulation_title and reg.title != regulation_title:
                continue

            origin = getattr(reg, '_origin', {})
            reg_strategies = []

            # Strategy 1: COMPLY (always an option)
            reg_gaps = [g for g in self.gaps if g.regulation.title == reg.title]
            reg_strategies.append({
                'strategy': 'COMPLY',
                'description': f'Address all {len(reg_gaps)} requirements',
                'effort': 'varies',
                'risk': 'none',
                'recommended': True,
            })

            # Strategy 2: PUBLIC COMMENT (if comment period is open)
            if origin.get('public_comment'):
                deadline = origin.get('comment_deadline', 'check deadline')
                reg_strategies.append({
                    'strategy': 'PUBLIC COMMENT',
                    'description': f'Submit public comment before {deadline}. Voice concerns, propose alternatives, request exemptions.',
                    'effort': 'low',
                    'risk': 'none',
                    'recommended': True,
                    'deadline': deadline,
                })

            # Strategy 3: EXEMPTION (if exemptions exist)
            exemptions = self.find_exemptions(reg.title)
            if isinstance(exemptions, dict) and exemptions.get('total', 0) > 0:
                reg_strategies.append({
                    'strategy': 'CLAIM EXEMPTION',
                    'description': f'{exemptions["total"]} potential exemption(s) found. Review applicability.',
                    'effort': 'low',
                    'risk': 'low — exemptions are legitimate',
                    'recommended': True,
                    'exemptions': exemptions.get('explicit_exemptions', []) +
                                 [e['note'] for e in exemptions.get('detected_exemptions', [])],
                })

            # Strategy 4: RESTRUCTURE (if the regulation targets a specific structure)
            lower = reg.text.lower()
            if any(w in lower for w in ['llc', 'corporation', 'partnership', 'sole proprietor']):
                reg_strategies.append({
                    'strategy': 'RESTRUCTURE',
                    'description': 'The regulation targets a specific business structure. Different structure = different obligations.',
                    'effort': 'high',
                    'risk': 'medium — legal advice required',
                    'recommended': False,
                    'note': 'Consult attorney before restructuring',
                })

            # Strategy 5: CHALLENGE (if penalty is disproportionate or law is new/untested)
            if reg.penalty:
                reg_strategies.append({
                    'strategy': 'CHALLENGE',
                    'description': f'Legal challenge to regulation scope or penalty ({reg.penalty}). Most effective during early enforcement.',
                    'effort': 'very high',
                    'risk': 'high — expensive, uncertain outcome',
                    'recommended': False,
                    'note': 'Only if compliance cost exceeds challenge cost',
                })

            # Strategy 6: LOBBY FOR AMENDMENT (if you have the connections)
            if origin.get('sponsor'):
                reg_strategies.append({
                    'strategy': 'LOBBY FOR AMENDMENT',
                    'description': f'Contact {origin["sponsor"]} or committee ({origin.get("committee", "unknown")}) to propose amendments that address your specific situation.',
                    'effort': 'high',
                    'risk': 'low — participating in the process is legitimate',
                    'recommended': len(reg_gaps) > 5,  # recommend if heavily affected
                })

            # Strategy 7: INDUSTRY COALITION (strength in numbers)
            reg_strategies.append({
                'strategy': 'INDUSTRY COALITION',
                'description': 'Join or form an industry group to collectively address the regulation. Shared resources, shared voice.',
                'effort': 'medium',
                'risk': 'none',
                'recommended': len(reg_gaps) > 3,
            })

            # Strategy 8: TECHNOLOGY SOLUTION (automate compliance)
            tech_applicable = any(w in lower for w in ['data', 'encrypt', 'security', 'monitor', 'report', 'audit'])
            if tech_applicable:
                reg_strategies.append({
                    'strategy': 'AUTOMATE',
                    'description': 'Technical controls can automate most requirements. Encrypt data, log access, automate reports.',
                    'effort': 'medium',
                    'risk': 'none',
                    'recommended': True,
                    'note': 'GUMP products may already cover some requirements',
                })

            strategies.append({
                'regulation': reg.title,
                'gaps': len(reg_gaps),
                'penalty': reg.penalty,
                'strategies': reg_strategies,
                'recommended_first': [s['strategy'] for s in reg_strategies if s['recommended']],
            })

        return strategies[0] if regulation_title and strategies else strategies

    _audit_log = []

    def log_action(self, action, details=''):
        """Log a compliance action for audit trail."""
        self._audit_log.append({
            'timestamp': time.time(),
            'action': action,
            'details': details,
            'company': self.company,
        })

    def audit_trail(self):
        """Get the full audit trail."""
        return sorted(self._audit_log, key=lambda x: -x['timestamp'])

    def tensions(self):
        """Find knowledge tensions — regulations that SHOULD be connected but aren't.
        These are potential regulatory gaps or conflicts."""
        return self.knowledge.tensions(top_k=10)

    def report(self):
        """Human-readable compliance report."""
        scan = self.scan()
        if 'error' in scan:
            return scan['error']

        lines = [
            f'ACCORD — {self.company}',
            f'{"=" * 50}',
            f'Regulations scanned: {len(self.regulations)}',
            f'Applicable: {scan["regulations_applicable"]}',
            f'Compliance gaps: {scan["gaps_found"]}',
            f'  Critical: {scan["critical"]}',
            f'  High: {scan["high"]}',
            f'  Medium: {scan["medium"]}',
            f'  Low: {scan["low"]}',
            f'Categories affected: {", ".join(scan["categories_affected"])}',
            '',
            'ACTION PLAN:',
        ]

        for action in self.action_plan()[:10]:
            lines.append(f'  [{action["priority"]}] {action["action"]}')
            lines.append(f'         {action["regulation"]} | {action["effort"]} effort | {action["urgency"]}')

        return '\n'.join(lines)

    # ═══ COMPLIANCE COST ESTIMATION ═══

    def estimate_cost(self, hourly_rate=150):
        """Estimate compliance cost based on gaps, effort, and hourly rate.

        Args:
            hourly_rate: $/hr for compliance work (default $150 — paralegal/junior attorney rate)

        Returns dict with per-regulation and total cost estimates.
        """
        if not self._scanned:
            self.scan()

        EFFORT_HOURS = {
            'low': 4,
            'medium': 16,
            'high': 40,
            'very high': 80,
        }

        estimates = []
        total_hours = 0
        total_cost = 0

        for reg in self.regulations:
            reg_gaps = [g for g in self.gaps if g.regulation.title == reg.title]
            if not reg_gaps:
                continue

            reg_hours = 0
            actions = []
            seen = set()
            for gap in reg_gaps:
                action_key = gap.action['action']
                if action_key in seen:
                    continue
                seen.add(action_key)
                # Check if already addressed
                key = f'{gap.regulation.title}::{action_key}'
                status = self._compliance_status.get(key, {'status': 'not_started'})
                if status['status'] == 'done':
                    continue

                hours = EFFORT_HOURS.get(gap.action['effort'], 16)
                reg_hours += hours
                actions.append({
                    'action': action_key,
                    'effort': gap.action['effort'],
                    'hours': hours,
                    'cost': hours * hourly_rate,
                    'type': gap.action['type'],
                })

            reg_cost = reg_hours * hourly_rate
            total_hours += reg_hours
            total_cost += reg_cost

            estimates.append({
                'regulation': reg.title,
                'hours': reg_hours,
                'cost': reg_cost,
                'actions': actions,
                'penalty': reg.penalty,
                'cost_vs_penalty': 'compliance cheaper' if reg.penalty else 'no penalty specified',
            })

        return {
            'hourly_rate': hourly_rate,
            'total_hours': total_hours,
            'total_cost': total_cost,
            'per_regulation': estimates,
            'note': 'Estimates based on effort classification. Actual costs vary by jurisdiction, complexity, and counsel rates.',
        }

    # ═══ REGULATION CONFLICT DETECTION ═══

    def find_conflicts(self):
        """Find regulations that conflict with each other.
        E.g., one requires data retention, another requires data deletion."""
        if not self._scanned:
            self.scan()

        OPPOSING_CONCEPTS = [
            (['retain', 'store', 'preserve', 'keep', 'maintain records'],
             ['delete', 'destroy', 'erase', 'purge', 'right to be forgotten']),
            (['disclose', 'transparent', 'publish', 'public'],
             ['confidential', 'secret', 'non-disclosure', 'classified']),
            (['collect', 'gather', 'obtain', 'require information'],
             ['minimize', 'limit collection', 'data minimization', 'only necessary']),
        ]

        conflicts = []
        for i, reg_a in enumerate(self.regulations):
            for reg_b in self.regulations[i+1:]:
                text_a = reg_a.text.lower()
                text_b = reg_b.text.lower()

                for side_a, side_b in OPPOSING_CONCEPTS:
                    a_has = any(phrase in text_a for phrase in side_a)
                    b_has = any(phrase in text_b for phrase in side_b)
                    a_has_reverse = any(phrase in text_a for phrase in side_b)
                    b_has_reverse = any(phrase in text_b for phrase in side_a)

                    if (a_has and b_has) or (a_has_reverse and b_has_reverse):
                        conflicts.append({
                            'regulation_a': reg_a.title,
                            'regulation_b': reg_b.title,
                            'concept_a': [p for p in side_a if p in text_a] or [p for p in side_b if p in text_a],
                            'concept_b': [p for p in side_b if p in text_b] or [p for p in side_a if p in text_b],
                            'type': 'opposing_requirements',
                            'note': 'These regulations may impose conflicting obligations. Consult counsel.',
                        })

        return conflicts

    # ═══ COMPLIANCE DASHBOARD DATA ═══

    def dashboard(self):
        """Return all data needed for a compliance dashboard in one call."""
        scan = self.scan()
        if 'error' in scan:
            return scan

        return {
            'company': self.company,
            'scan': scan,
            'deadlines': self.deadlines(),
            'risk': self.risk_assessment(),
            'status': self.compliance_status(),
            'cost': self.estimate_cost(),
            'conflicts': self.find_conflicts(),
            'action_plan': self.action_plan()[:20],
            'regulations': len(self.regulations),
        }
