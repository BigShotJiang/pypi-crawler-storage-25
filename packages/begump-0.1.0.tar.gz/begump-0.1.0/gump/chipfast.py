"""
CHIPFAST — Open-source chip layout
======================================
Write a circuit description → get optimal placement + routing.

    from gump.chipfast import design
    result = design(gates=['and','or','xor','buf'], wires=[(0,1),(1,2),(2,3)])
    print(result['wire_length'])
    print(result['positions'])

    # Or from netlist text
    result = design_netlist('and g0 (y, a, b); or g1 (z, y, c);')
"""
import numpy as np
from gump.core import _TensionDetector


def design(gates, wires, weights=None, chip_w=None, chip_h=None):
    """Place gates and estimate routing.

    Args:
        gates: list of gate names or types
        wires: list of (gate_i, gate_j) connections
        weights: optional timing weights (higher = more critical)
        chip_w, chip_h: chip dimensions (auto if None)
    """
    n = len(gates)
    if n == 0:
        return {'error': 'no gates'}

    if chip_w is None:
        side = max(10, int(np.sqrt(n)) * 3)
        chip_w = float(side)
    if chip_h is None:
        chip_h = chip_w

    ci = [w[0] for w in wires]
    cj = [w[1] for w in wires]
    w = weights

    # Spectral placement
    td = _TensionDetector(n, wires, w, n_vecs=2)
    coords = td.coords[:, :2] if td.coords.shape[1] >= 2 else \
             np.column_stack([td.coords[:, 0], np.random.randn(n)])

    # Quantile mapping
    for d in range(2):
        mn, mx = coords[:, d].min(), coords[:, d].max()
        if mx > mn:
            coords[:, d] = (coords[:, d] - mn) / (mx - mn)
        order = np.argsort(coords[:, d])
        ranks = np.empty(n)
        ranks[order] = np.arange(n, dtype=float) / max(n - 1, 1)
        coords[:, d] = ranks

    # Legalize: snap to rows
    gate_h = 1.5
    row_height = gate_h * 1.2
    n_rows = max(1, int(chip_h / row_height))
    row_y = np.linspace(row_height / 2, chip_h - row_height / 2, n_rows)
    row_assign = np.clip(np.round(coords[:, 1] * (n_rows - 1)).astype(int), 0, n_rows - 1)

    positions = np.zeros((n, 2))
    sort_key = row_assign.astype(float) * chip_w * 2 + coords[:, 0] * chip_w
    order = np.argsort(sort_key)
    row_of_sorted = row_assign[order]

    count = 0
    prev_row = -1
    gate_w = 2.0
    for idx in range(n):
        r = row_of_sorted[idx]
        if r != prev_row:
            count = 0
            prev_row = r
        positions[order[idx], 0] = count * gate_w + gate_w / 2
        positions[order[idx], 1] = row_y[r]
        count += 1

    # Wire length
    ci_arr = np.array(ci, dtype=int)
    cj_arr = np.array(cj, dtype=int)
    wl = float(np.sum(np.abs(positions[ci_arr, 0] - positions[cj_arr, 0]) +
                       np.abs(positions[ci_arr, 1] - positions[cj_arr, 1])))

    # Routing congestion (vectorized)
    grid_size = 20
    cell_w = chip_w / grid_size
    cell_h = chip_h / grid_size
    congestion = np.zeros((grid_size, grid_size))
    cx_i = np.clip((positions[ci_arr, 0] / cell_w).astype(int), 0, grid_size - 1)
    cy_i = np.clip((positions[ci_arr, 1] / cell_h).astype(int), 0, grid_size - 1)
    cx_j = np.clip((positions[cj_arr, 0] / cell_w).astype(int), 0, grid_size - 1)
    cy_j = np.clip((positions[cj_arr, 1] / cell_h).astype(int), 0, grid_size - 1)
    np.add.at(congestion, (cy_i, cx_i), 1)
    np.add.at(congestion, (cy_j, cx_j), 1)
    hot_spots = int(np.sum(congestion > congestion.mean() * 3))

    # Tensions
    tensions = td.tensions(top_k=5)
    missing = [{
        'gate_a': gates[i], 'gate_b': gates[j], 'tension': score
    } for d, i, j, score in tensions]

    return {
        'n_gates': n,
        'n_wires': len(wires),
        'wire_length': wl,
        'hot_spots': hot_spots,
        'positions': positions,
        'missing_connections': missing,
        'gate_names': gates,
    }


def design_netlist(netlist_text):
    """Parse simple netlist text and design.

    Format: 'gate_type instance_name (output, input1, input2);'
    Example: 'and g0 (y, a, b); or g1 (z, y, c);'
    """
    gates = []
    wires = []
    wire_drivers = {}
    wire_readers = {}
    gate_names = []

    for stmt in netlist_text.strip().split(';'):
        stmt = stmt.strip()
        if not stmt:
            continue
        parts = stmt.split()
        if len(parts) < 2:
            continue

        gate_type = parts[0]
        rest = ' '.join(parts[1:])
        if '(' in rest:
            inst = rest[:rest.index('(')].strip()
            ports = [p.strip() for p in rest[rest.index('(') + 1:rest.rindex(')')].split(',')]
            if len(ports) >= 2:
                gate_idx = len(gates)
                gates.append(gate_type)
                gate_names.append(inst)

                output_wire = ports[0]
                wire_drivers[output_wire] = gate_idx
                for inp in ports[1:]:
                    if inp not in wire_readers:
                        wire_readers[inp] = []
                    wire_readers[inp].append(gate_idx)

    # Build wires
    for wire, readers in wire_readers.items():
        if wire in wire_drivers:
            src = wire_drivers[wire]
            for dst in readers:
                if src != dst:
                    wires.append((src, dst))

    return design(gate_names if gate_names else gates, wires)
