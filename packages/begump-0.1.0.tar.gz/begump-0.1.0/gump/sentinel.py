"""
SENTINEL — Spectral security monitoring.
==========================================
Points K/R/E/T at your system. Detects anomalous behavior through
physics, not signatures. Knows what YOUR system looks like and
flags when that changes.

    from gump.sentinel import Sentinel

    # Create monitor and establish baseline
    s = Sentinel()
    s.baseline(duration=60)  # watch for 60 seconds to learn "normal"

    # Feed system metrics (or let it collect automatically)
    s.feed_metrics({
        'cpu': 23.5,
        'memory': 67.2,
        'network_in': 1240,
        'network_out': 890,
        'disk_io': 45,
        'processes': 312,
        'open_files': 1847,
        'connections': 23,
    })

    # Check status
    print(s.status())       # regime, alerts, K/R/E/T per metric
    print(s.alerts())       # what changed and why

    # Full report
    html = s.visualize()

    # File integrity monitoring
    s.watch_files(['/etc/hosts', '/usr/local/bin/'])
    print(s.integrity())    # what changed since baseline

Zero-day detection: doesn't need to know what the threat looks like.
Knows what YOUR system looks like. Flags when it doesn't.
"""

import os
import time
import json
import hashlib
import subprocess
import numpy as np
from collections import defaultdict
from gump.sensor import UniversalSensor
from gump.core import EnergyTracker, PHI


class Sentinel:
    """Spectral security monitor. K/R/E/T for your system."""

    def __init__(self, name='system'):
        self.name = name
        self.sensors = {}  # metric_name → UniversalSensor
        self.baseline_stats = {}  # metric_name → {mean, std, K, R}
        self.is_baselined = False
        self.alerts = []
        self.file_hashes = {}  # path → hash
        self.history = defaultdict(list)  # metric → [values]
        self._created = time.time()

    def _collect_metrics(self):
        """Collect current system metrics. macOS specific."""
        metrics = {}
        try:
            # CPU usage
            r = subprocess.run(['ps', '-A', '-o', '%cpu'], capture_output=True, text=True, timeout=5)
            cpus = [float(x) for x in r.stdout.strip().split('\n')[1:] if x.strip()]
            metrics['cpu'] = sum(cpus)
        except Exception:
            metrics['cpu'] = 0

        try:
            # Memory pressure
            r = subprocess.run(['vm_stat'], capture_output=True, text=True, timeout=5)
            lines = r.stdout.strip().split('\n')
            free = 0
            for line in lines:
                if 'free' in line.lower():
                    parts = line.split(':')
                    if len(parts) == 2:
                        free = int(parts[1].strip().rstrip('.')) * 4096
            total_mem = os.sysconf('SC_PAGE_SIZE') * os.sysconf('SC_PHYS_PAGES')
            metrics['memory_pct'] = round((1 - free / max(total_mem, 1)) * 100, 1)
        except Exception:
            metrics['memory_pct'] = 0

        try:
            # Process count
            r = subprocess.run(['ps', '-A'], capture_output=True, text=True, timeout=5)
            metrics['processes'] = len(r.stdout.strip().split('\n')) - 1
        except Exception:
            metrics['processes'] = 0

        try:
            # Network connections
            r = subprocess.run(['netstat', '-an'], capture_output=True, text=True, timeout=5)
            established = sum(1 for line in r.stdout.split('\n') if 'ESTABLISHED' in line)
            listening = sum(1 for line in r.stdout.split('\n') if 'LISTEN' in line)
            metrics['connections'] = established
            metrics['listeners'] = listening
        except Exception:
            metrics['connections'] = 0
            metrics['listeners'] = 0

        try:
            # Open files
            r = subprocess.run(['lsof', '-c', '', '+c', '0'], capture_output=True, text=True, timeout=10)
            metrics['open_files'] = len(r.stdout.strip().split('\n')) - 1
        except Exception:
            metrics['open_files'] = 0

        return metrics

    def feed_metrics(self, metrics):
        """Feed a dict of metric_name → value. Can be auto-collected or manual."""
        timestamp = time.time()
        for name, value in metrics.items():
            if name not in self.sensors:
                self.sensors[name] = UniversalSensor(name)
            self.sensors[name].feed([float(value)])
            self.history[name].append({'time': timestamp, 'value': float(value)})
            # Keep last 1000 readings
            if len(self.history[name]) > 1000:
                self.history[name] = self.history[name][-1000:]

    def collect(self):
        """Auto-collect system metrics and feed them."""
        metrics = self._collect_metrics()
        self.feed_metrics(metrics)
        return metrics

    def baseline(self, duration=60, interval=1):
        """Establish baseline by collecting metrics for duration seconds."""
        readings = defaultdict(list)
        end = time.time() + duration
        while time.time() < end:
            metrics = self.collect()
            for k, v in metrics.items():
                readings[k].append(v)
            time.sleep(interval)

        # Compute baseline statistics
        for name, values in readings.items():
            arr = np.array(values)
            self.baseline_stats[name] = {
                'mean': float(np.mean(arr)),
                'std': float(np.std(arr)),
                'min': float(np.min(arr)),
                'max': float(np.max(arr)),
                'samples': len(values),
            }

        self.is_baselined = True
        return self.baseline_stats

    def set_baseline(self, stats):
        """Set baseline from a saved dict (load from file)."""
        self.baseline_stats = stats
        self.is_baselined = True

    def check(self, metrics=None):
        """Check current metrics against baseline. Returns alerts."""
        if metrics is None:
            metrics = self.collect()
        else:
            self.feed_metrics(metrics)

        new_alerts = []
        for name, value in metrics.items():
            # K/R/E/T analysis
            if name in self.sensors and len(self.sensors[name].data) >= 4:
                diagnosis = self.sensors[name].diagnose()
            else:
                diagnosis = {'K': 0, 'R': 0, 'T': 0, 'regime': 'unknown'}

            # Baseline comparison
            if self.is_baselined and name in self.baseline_stats:
                bs = self.baseline_stats[name]
                if bs['std'] > 0:
                    zscore = (value - bs['mean']) / bs['std']
                else:
                    zscore = 0 if value == bs['mean'] else 10

                # Alert thresholds
                severity = None
                if abs(zscore) > 5:
                    severity = 'CRITICAL'
                elif abs(zscore) > 3.5:
                    severity = 'HIGH'
                elif abs(zscore) > 2.5:
                    severity = 'MEDIUM'

                if severity:
                    alert = {
                        'time': time.time(),
                        'metric': name,
                        'value': value,
                        'baseline_mean': round(bs['mean'], 2),
                        'baseline_std': round(bs['std'], 2),
                        'zscore': round(zscore, 2),
                        'severity': severity,
                        'regime': diagnosis.get('regime', 'unknown'),
                        'K': diagnosis.get('K', 0),
                    }
                    new_alerts.append(alert)

            # Regime change detection
            if diagnosis.get('regime') == 'volatile' and name in self.baseline_stats:
                alert = {
                    'time': time.time(),
                    'metric': name,
                    'value': value,
                    'severity': 'HIGH',
                    'type': 'regime_change',
                    'regime': 'volatile',
                    'note': f'{name} entered volatile regime — pattern disruption',
                }
                if not any(a.get('type') == 'regime_change' and a['metric'] == name
                          for a in self.alerts[-10:]):
                    new_alerts.append(alert)

        self.alerts.extend(new_alerts)
        # Keep last 500 alerts
        if len(self.alerts) > 500:
            self.alerts = self.alerts[-500:]

        return new_alerts

    # ═══ FILE INTEGRITY ═══

    def watch_files(self, paths):
        """Hash files/directories for integrity monitoring."""
        if not hasattr(self, '_watched_dirs'):
            self._watched_dirs = set()
        for path in paths:
            if os.path.isfile(path):
                self.file_hashes[path] = self._hash_file(path)
            elif os.path.isdir(path):
                self._watched_dirs.add(path)
                for root, dirs, files in os.walk(path):
                    # Skip hidden and system dirs
                    dirs[:] = [d for d in dirs if not d.startswith('.')]
                    for f in files:
                        fp = os.path.join(root, f)
                        try:
                            self.file_hashes[fp] = self._hash_file(fp)
                        except (PermissionError, OSError):
                            pass

    def check_integrity(self):
        """Check all watched files for changes."""
        changes = []
        for path, original_hash in self.file_hashes.items():
            if not os.path.exists(path):
                changes.append({'path': path, 'type': 'deleted', 'severity': 'CRITICAL'})
            else:
                current = self._hash_file(path)
                if current != original_hash:
                    changes.append({
                        'path': path,
                        'type': 'modified',
                        'severity': 'HIGH',
                        'original': original_hash[:16],
                        'current': current[:16],
                    })

        # Check for new files in explicitly watched DIRECTORIES only
        # (not parent dirs of individually watched files — that causes false positives)
        watched_dirs = getattr(self, '_watched_dirs', set())
        for d in watched_dirs:
            if os.path.isdir(d):
                for f in os.listdir(d):
                    fp = os.path.join(d, f)
                    if os.path.isfile(fp) and fp not in self.file_hashes:
                        changes.append({
                            'path': fp,
                            'type': 'new_file',
                            'severity': 'MEDIUM',
                        })

        return changes

    def _hash_file(self, path):
        try:
            with open(path, 'rb') as f:
                return hashlib.sha256(f.read()).hexdigest()
        except (PermissionError, OSError):
            return 'unreadable'

    # ═══ STATUS ═══

    def status(self):
        """Full security status."""
        metric_status = {}
        for name, sensor in self.sensors.items():
            if len(sensor.data) >= 4:
                d = sensor.diagnose()
                metric_status[name] = {
                    'current': sensor.data[-1] if sensor.data else 0,
                    'K': d.get('K', 0),
                    'R': d.get('R', 0),
                    'T': d.get('T', 0),
                    'regime': d.get('regime', 'unknown'),
                    'anomalies': len(d.get('anomalies', [])),
                }

        # Overall regime
        regimes = [m['regime'] for m in metric_status.values()]
        if 'volatile' in regimes or 'chaotic' in regimes:
            overall = 'ALERT'
        elif 'transitional' in regimes and self.is_baselined:
            # Only escalate to WATCH if we have a baseline to compare against.
            # Without a baseline, transitional is just "not enough data yet."
            overall = 'WATCH'
        else:
            overall = 'NORMAL'

        recent_alerts = [a for a in self.alerts if time.time() - a['time'] < 300]  # last 5 min

        return {
            'overall': overall,
            'baselined': self.is_baselined,
            'metrics': metric_status,
            'recent_alerts': len(recent_alerts),
            'total_alerts': len(self.alerts),
            'watched_files': len(self.file_hashes),
            'uptime': round(time.time() - self._created),
        }

    def get_alerts(self, severity=None, last_n=20):
        """Get recent alerts, optionally filtered by severity."""
        alerts = self.alerts
        if severity:
            alerts = [a for a in alerts if a.get('severity') == severity]
        return alerts[-last_n:]

    def save_baseline(self, path):
        """Save baseline to JSON file."""
        with open(path, 'w') as f:
            json.dump({
                'baseline': self.baseline_stats,
                'file_hashes': self.file_hashes,
                'saved_at': time.time(),
            }, f)

    def load_baseline(self, path):
        """Load baseline from JSON file."""
        with open(path) as f:
            data = json.load(f)
        self.baseline_stats = data.get('baseline', {})
        self.file_hashes = data.get('file_hashes', {})
        self.is_baselined = bool(self.baseline_stats)

    # ═══ ACTIVE DEFENSE ═══

    def profile_intruder(self, attack_metrics):
        """Analyze an intruder's behavior pattern using spectral tools.
        Feed the sequence of their actions — what they accessed, when, how much.
        Returns a behavioral fingerprint + predicted next targets."""
        from gump.trace import scan as trace_scan

        # Build transaction graph from access pattern
        txs = []
        for i, m in enumerate(attack_metrics):
            source = m.get('source', 'intruder')
            target = m.get('target', f'resource_{i}')
            weight = m.get('intensity', 1.0)
            txs.append({'from': source, 'to': target, 'amount': weight})

        if len(txs) < 2:
            return {'error': 'Need at least 2 access events to profile'}

        analysis = trace_scan(txs)

        # Predicted next targets = spectral tensions
        # (resources spectrally close to what they've touched but haven't reached yet)
        predicted_targets = []
        for t in analysis.get('tensions', []):
            predicted_targets.append({
                'target': t['entity_b'] if t['entity_a'] == 'intruder' else t['entity_a'],
                'tension': t['tension'],
                'note': 'Spectrally close to accessed resources — likely next target',
            })

        # Behavioral fingerprint — spectral hash of their access pattern
        access_sequence = '|'.join(m.get('target', '') for m in attack_metrics)
        from gump.khash import khash256
        fingerprint = khash256(access_sequence)

        return {
            'fingerprint': fingerprint,
            'risk_score': analysis.get('risk_score', 0),
            'pattern': analysis.get('circular_flows', []),
            'concentration': analysis.get('concentration', []),
            'predicted_targets': predicted_targets[:5],
            'clusters': analysis.get('clusters', []),
        }

    def deploy_honeypots(self, predicted_targets, honeypot_dir='/tmp/gump_honeypots'):
        """Auto-deploy decoy files in the direction the attacker is heading.
        Honeypots contain wrong data that looks real. Accessing them = confirmed intrusion."""
        import os
        os.makedirs(honeypot_dir, exist_ok=True)

        deployed = []
        for target in predicted_targets:
            name = target.get('target', 'unknown').replace('/', '_').replace(' ', '_')
            # Create decoy with plausible but wrong content
            decoy_path = os.path.join(honeypot_dir, f'{name}_config.json')
            decoy_content = json.dumps({
                'api_key': 'gump_canary_' + hashlib.md5(name.encode()).hexdigest()[:12],
                'database': f'{name}_production',
                'credentials': {'user': 'admin', 'pass': 'canary_' + name[:8]},
                '_honeypot': True,
                '_deployed': time.time(),
            }, indent=2)
            with open(decoy_path, 'w') as f:
                f.write(decoy_content)

            # Watch the honeypot for access
            self.watch_files([decoy_path])
            deployed.append({
                'path': decoy_path,
                'target': name,
                'tension': target.get('tension', 0),
            })

        return deployed

    def check_honeypots(self):
        """Check if any honeypots were accessed. Access = confirmed intrusion."""
        changes = self.check_integrity()
        triggered = []
        honeypot_paths = set()
        for path in self.file_hashes:
            try:
                with open(path, 'r') as f:
                    if '_honeypot' in f.read():
                        honeypot_paths.add(path)
            except (FileNotFoundError, PermissionError, UnicodeDecodeError):
                pass
        for c in changes:
            if c.get('path', '') in honeypot_paths:
                triggered.append({
                    'path': c['path'],
                    'type': c['type'],
                    'severity': 'CRITICAL',
                    'note': 'HONEYPOT TRIGGERED — confirmed unauthorized access',
                })
        return triggered

    def disrupt_coupling(self, target_paths, decay_rate=0.1):
        """Coupling disruption: degrade data visibility for the intruder.
        Creates decoy versions of sensitive files with progressively wrong data.
        The more they access, the more the data drifts — like K decaying."""
        disrupted = []
        for path in target_paths:
            if not os.path.exists(path):
                continue
            # Create a shadow copy with slightly wrong data
            shadow_dir = os.path.dirname(path) + '/.shadow'
            os.makedirs(shadow_dir, exist_ok=True)
            shadow_path = os.path.join(shadow_dir, os.path.basename(path))

            try:
                with open(path, 'r') as f:
                    content = f.read()
                # Inject noise proportional to decay_rate
                # For text: swap random characters
                chars = list(content)
                n_swap = max(1, int(len(chars) * decay_rate))
                import random
                for _ in range(n_swap):
                    idx = random.randint(0, len(chars) - 1)
                    chars[idx] = chr(ord(chars[idx]) ^ 1)  # flip one bit
                with open(shadow_path, 'w') as f:
                    f.write(''.join(chars))

                disrupted.append({
                    'original': path,
                    'shadow': shadow_path,
                    'noise_pct': round(decay_rate * 100, 1),
                })
            except (PermissionError, UnicodeDecodeError):
                pass

        return disrupted

    def spectral_fingerprint(self, behavior_sequence):
        """Create a spectral fingerprint of behavior that survives IP changes.
        Recognizes the BEHAVIOR pattern, not the network address."""
        from gump.khash import khash256

        # Convert behavior to a canonical string
        if isinstance(behavior_sequence, list):
            canonical = '|'.join(str(b) for b in behavior_sequence)
        else:
            canonical = str(behavior_sequence)

        return {
            'fingerprint': khash256(canonical),
            'length': len(behavior_sequence) if isinstance(behavior_sequence, list) else 1,
            'note': 'Spectral hash of behavior pattern — survives IP/UA changes',
        }

    def report(self):
        """Human-readable security report."""
        s = self.status()
        lines = [
            f'SENTINEL — {self.name}',
            f'{"=" * 50}',
            f'Status: {s["overall"]}',
            f'Baselined: {s["baselined"]}',
            f'Metrics tracked: {len(s["metrics"])}',
            f'Recent alerts: {s["recent_alerts"]}',
            f'Watched files: {s["watched_files"]}',
            f'Uptime: {s["uptime"]}s',
            '',
        ]

        for name, m in s['metrics'].items():
            regime_icon = '🟢' if m['regime'] in ('coherent', 'locked') else '🟡' if m['regime'] == 'transitional' else '🔴' if m['regime'] == 'volatile' else '⚪'
            lines.append(f'  {regime_icon} {name}: {m["current"]:.1f} | K={m["K"]:.2f} R={m["R"]:.2f} T={m["T"]:.3f} | {m["regime"]}')

        if self.alerts:
            lines.append('')
            lines.append('RECENT ALERTS:')
            for a in self.alerts[-5:]:
                note = a.get('note', 'value=' + str(a.get('value', '?')) + ' zscore=' + str(a.get('zscore', '?')))
                lines.append(f'  [{a["severity"]}] {a["metric"]}: {note}')

        return '\n'.join(lines)
