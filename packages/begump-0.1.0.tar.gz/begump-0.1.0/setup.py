from setuptools import setup, find_packages

setup(
    name='begump',
    version='0.1.0',
    description='K, R, E, T — Four quantities. One framework. Everything computable.',
    long_description=open('README.md').read() if __import__('os').path.exists('README.md') else '',
    long_description_content_type='text/markdown',
    author='Jim McCandless',
    author_email='gump@begump.com',
    url='https://github.com/LacobusGump/gump',
    packages=find_packages(),
    install_requires=['numpy'],
    extras_require={
        'full': ['scipy'],
    },
    python_requires='>=3.7',
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Science/Research',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Topic :: Scientific/Engineering',
        'Topic :: Scientific/Engineering :: Physics',
        'Topic :: Multimedia :: Sound/Audio',
    ],
)
