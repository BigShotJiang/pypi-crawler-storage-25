from .Email_DocumentUploader import Email_DocumentUploader
from .EmailReplyAssistant import EmailReplyAssistant
from http.cookies import SimpleCookie
from .Email_Draft import Email_Draft
import google.generativeai as genai
from email.utils import parseaddr
import loggerutility as logger
from datetime import datetime
from openai import OpenAI
from fpdf import FPDF
import mimetypes
import sqlite3
import openai
import json
import csv
import os
from email import message_from_string
import re
import weaviate
from weaviate.gql.get import HybridFusion
from openpyxl import Workbook

class Process_Category:

    def process_cat(self, category, dataValues):

        Model_Name = dataValues.get('Model_Name')
        file_JsonArray = dataValues.get('file_JsonArray')
        openai_api_key = dataValues.get('openai_api_key')
        openai_Process_Input = dataValues.get('openai_Process_Input')
        subject = dataValues.get('subject')
        sender_email_addr = dataValues.get('sender_email_addr')
        cc_email_addr = dataValues.get('cc_email_addr')
        email_body = dataValues.get('email_body')
        email_config = dataValues.get('email_config')
        msg = dataValues.get('msg')
        geminiAI_APIKey = dataValues.get('geminiAI_APIKey')
        localAIURL = dataValues.get('localAIURL')
        signature = dataValues.get('signature')
        LABEL = dataValues.get('LABEL')
        mail = dataValues.get('mail')
        email_id = dataValues.get('email_id')
        uid = dataValues.get('uid')
        to_email_addr =dataValues.get('to_email_addr')
        user_id =dataValues.get('user_id')
        date = msg.get('Date', '')
        is_html = dataValues.get('is_html')
        import_file = dataValues.get('import_file')

        customer_determination = None
        product_determination = None

        if category == "Product Enquiry":
            if Model_Name == "OpenAI":
                action_taken = "Reply email drafted using Open_AI Model"
                responseMethod, parameters = self.get_JsonArray_values(category, file_JsonArray)
                logger.log(f"the repsonse method is ::: {responseMethod}")
                if responseMethod == "Reply_Email_Ai_Assistant":
                    emailreplyassistant = EmailReplyAssistant()
                    openai_Response = emailreplyassistant.Reply_Email_Ai_Assistant(openai_api_key, parameters["Assistant_Id"], openai_Process_Input, subject)
                    logger.log(f"Process openai_Response ::: {openai_Response['message']}\n")
                    email_details = {"sender": sender_email_addr, "cc": cc_email_addr, "subject": subject, "body": email_body}
                    logger.log(f"response generated")
                    email_draft = Email_Draft()
                    status, response = email_draft.draft_email(email_config, email_details, openai_Response['message'])
                    logger.log(f"status ::: {status}")
                    logger.log(f"Email draft called")
                    csv_data_status = status
                    csv_data_response = response
                else:
                    message = f"Invalid response method received '{responseMethod}' for category : '{category}'"
                    raise ValueError(message)
            elif Model_Name == "LocalAI":
                action_taken = "Reply email drafted using Local_AI Model"
                logger.log("localAI")
                Detect_Email_category = False
                LocalAI_Response = category
                logger.log(f"Process LocalAI_Response ::: {LocalAI_Response}\n")
                email_details = {"sender": sender_email_addr, "cc": cc_email_addr, "subject": subject, "body": email_body}

                email_draft = Email_Draft()
                status, response = email_draft.draft_email(email_config, email_details, LocalAI_Response)
                logger.log(f"status ::: {status}")
                csv_data_status = status
                csv_data_response = response
            elif Model_Name == "GeminiAI":
                action_taken = "Reply email drafted using Gemini Model"
                logger.log("GeminiAI")
                Detect_Email_category = False
                GeminiAI_Response = category
                logger.log(f"Process GeminiAI_Response ::: {GeminiAI_Response}\n")
                email_details = {"sender": sender_email_addr, "cc": cc_email_addr, "subject": subject, "body": email_body}

                email_draft = Email_Draft()
                status, response = email_draft.draft_email(email_config, email_details, GeminiAI_Response)
                logger.log(f"status ::: {status}")
                csv_data_status = status
                csv_data_response = response
            else:
                raise ValueError(f"Invalid Model Name provided : '{Model_Name}'")

        elif category == "Purchase Order":
            action_taken = "Document uploaded"
            responseMethod, parameters = self.get_JsonArray_values(category, file_JsonArray)
            logger.log(f"responseMethod ::: {responseMethod}")
            logger.log(f"parameters ::: {parameters}")

            # Download the attachment
            fileName, document_type = self.download_attachment(msg)
            logger.log(f"fileName 107::: {fileName}")
            logger.log(f"document_type 108::: {document_type}")

            if responseMethod == "Upload_Document":

                email_upload_document = Email_DocumentUploader()
                if len(fileName) != 0 and document_type != '':
                    # Get today's date folder path
                    today_date = datetime.today().strftime('%Y-%m-%d')
                    order_folder = os.path.join(document_type, today_date)
                    
                    file_path = os.path.join(order_folder, fileName)  # Correct file path

                    with open(file_path, "rb") as file:
                        parameters["DOCUMENT_TYPE"] = document_type
                        
                        logger.log(f"Updated Parameters ::: {parameters}")
                        response_status, restAPI_Result = email_upload_document.email_document_upload(file, parameters)
                        logger.log(f"email_upload_document_response ::: {restAPI_Result}")
                else:
                    document_type = "Order Email"
                    # Get today's date folder path
                    today_date = datetime.today().strftime('%Y-%m-%d')
                    order_folder = os.path.join(document_type, today_date)

                    parameters["DOCUMENT_TYPE"] = document_type
                    logger.log(f"Updated Parameters ::: {parameters}")

                    email_parts = []
                    if sender_email_addr:
                        email_parts.append(f"From: {sender_email_addr}")
                    if to_email_addr:
                        email_parts.append(f"To: {to_email_addr}")
                    if cc_email_addr:
                        email_parts.append(f"CC: {cc_email_addr}")
                    if subject:
                        email_parts.append(f"Subject: {subject}")

                    email_parts.append(email_body)
                    email_body_with_details = "\n".join(email_parts)

                    logger.log(f"email_body ::: {email_body}")
                    new_fileName = self.create_file_from_emailBody(email_body_with_details, sender_email_addr, parameters)
                    new_file_path = os.path.join(order_folder, new_fileName)
                    
                    with open(new_file_path, "rb") as file:
                        response_status, restAPI_Result = email_upload_document.email_document_upload(file, parameters)
                        logger.log(f"email_upload_document_response ::: {restAPI_Result}")

                if response_status == "200":
                    logger.log(f"Attachment uploaded successfully against Document ID: '{restAPI_Result}'.")
                    csv_data_status="Success",
                    csv_data_response=f"Attachment uploaded successfully against Document ID: '{restAPI_Result}'"
                else:
                    logger.log(restAPI_Result)
                    csv_data_status="Fail",
                    csv_data_response=f"Attachment uploaded Failed against Document ID: '{restAPI_Result}'"
            else:
                message = f"Invalid response method received '{responseMethod}' for category : '{category}'"
                raise ValueError(message)

        elif category == "Quotation":
            action_taken = f"Mail drafted for products rate"
            responseMethod, parameters = self.get_JsonArray_values(category, file_JsonArray)
            logger.log(f"Parameters are ::: {parameters}")


            enterpriseName = parameters["Enterprise_Name"]
            schema_name = parameters["Schema_Name"].capitalize().replace("-","_")
            Product_Entity_Type = parameters["Product_Entity_Type"]
            Customer_Entity_Type = parameters["Customer_Entity_Type"]
            server_url = ""

            product_schemaName_Updated = enterpriseName + "_" + schema_name + "_" + Product_Entity_Type
            logger.log(f'\nschemaName_Updated of Product::: \t{product_schemaName_Updated}')

            customer_schemaName_Updated = enterpriseName + "_" + schema_name + "_" + Customer_Entity_Type
            logger.log(f'\nschemaName_Updated of Product::: \t{customer_schemaName_Updated}')

            environment_weaviate_server_url = os.getenv('weaviate_server_url')
            logger.log(f"environment_weaviate_server_url ::: [{environment_weaviate_server_url}]")

            if environment_weaviate_server_url != None and environment_weaviate_server_url != '':
                server_url = environment_weaviate_server_url
                logger.log(f"\nProcess_cat class Quotation server_url:::\t{server_url} \t{type(server_url)}","0")
            else:
                if 'server_url' in parameters.keys():
                    server_url = parameters['server_url']
            logger.log(f"\nProcess_cat class Quotation server_url:::\t{server_url} \t{type(server_url)}","0")
                
            # Step 4: Identify customer from email using AI
            
            # customer_data = self.identify_customer(email_body, subject, Model_Name, openai_api_key, geminiAI_APIKey, localAIURL, parameters["Customer_Assistant_Id"])           
            cust_data = self.identify_keywords(Model_Name, email_body, openai_api_key, geminiAI_APIKey, "customer")
            cust_name = cust_data["data"][0]["cust_name"]
            logger.log(f"Identified customer is ::: {cust_name}")

            if cust_name != None:
                # Identify customer code
                customer_data = self.customer_code_lookup(cust_name, openai_api_key, customer_schemaName_Updated, server_url)
                customer_determination=customer_data

            # Extract customer code once
            customer_code = customer_data.get("cust_code", "")

            # Step 5: Identify product from email using AI    
                    
            #If there is attachment then append the content in the body.
            extracted_content = dataValues.get('extracted_content')
            logger.log(f"extracted_content is ::: {extracted_content}")
            
            if extracted_content != "NA" and extracted_content != None:
                attachment_email_body =email_body + " \n\n" + extracted_content
                # products = self.identify_keywords(attachment_email_body, openai_api_key, "product")
                products = self.extract_product_catalog_details_gemini(attachment_email_body, geminiAI_APIKey)
            else:
                # products = self.identify_keywords(email_body, openai_api_key, "product")
                products = self.extract_product_catalog_details_gemini(email_body, geminiAI_APIKey)

            products = products.get("data", "")
            logger.log(f'Identified Products catalog details from gemini are ::: {products}')

            products = self.convert_product_code(products)
    
            logger.log(f'Products after converting the item_code are ::: {products}')

            products = self.get_valid_item_no(products)
            logger.log(f'Products after Verfying the item_code are ::: {products}')
            
            product=self.products_item_code_lookup(products, openai_api_key, product_schemaName_Updated, server_url)
            logger.log(f'Identified Products after Lookup are ::: {products}')

            product_determination=products

            db_connection = sqlite3.connect('database/fetchprice.db')
            for product in products:
                item_no = product.get("item_no", "").strip()
                make = "" if not product.get("make") or str(product["make"]).lower() == "none" else str(product["make"]).strip()
                rate = None
                discount = "NA"
                price_pickup_source = "NA"
                found_rate = False
                product["rate"] = rate

                logger.log(f"item no is ::: {item_no}")
                logger.log(f"make is ::: {make}")
                requested_make = make
                is_make = False
                
                # Extract rate from Special_rate_customer_wise
                query1 = '''
                    SELECT RATE 
                    FROM SPECIAL_RATE_CUSTOMER_WISE 
                    WHERE ITEM_CODE = ?
                    AND CUSTOMER_CODE = ?;
                '''
                cursor = db_connection.cursor()
                cursor.execute(query1, (item_no, customer_code))
                result = cursor.fetchone()
                cursor.close()

                if result:
                    rate = result[0]
                    found_rate = True
                    logger.log(f"Process_Category - [Initial Check] Quotation [1A] Special Rate for item '{item_no}' and customer '{customer_code}' is {rate}")
                    price_pickup_source="SPECIAL_RATE_CUSTOMER_WISE"
                    product["price"] = "NA"
                    product["discount"]= "NA"
                    product["rate"] = rate if found_rate else "NA"
                    product["price_pickup_source"]=price_pickup_source 

                else:
                    logger.log(f"RATE Not found in SPECIAL_RATE_CUSTOMER_WISE'")

                #Select preferred make based on customer's past purchases and current stock availability
                if product.get("rate") in (None, "", "NA"):
                    # Step 1: Get list of makes with count for given customer
                    query = '''
                            SELECT MAKE, COUNT(*) as make_count
                            FROM PAST_SALES
                            WHERE CUSTOMER_CODE = ?
                            GROUP BY MAKE
                            ORDER BY make_count DESC;
                        '''
                    cursor = db_connection.cursor()
                    cursor.execute(query, (customer_code,))
                    make_rows = cursor.fetchall()
                    cursor.close()

                    logger.log(f"The List of Make of the customer ::: {make_rows}")

                    if make_rows:
                        # Step 2: Iterate through makes in order of past sales count
                        for make, count in make_rows:
                            if product["cas_no"]:
                                query_stock = '''
                                        SELECT IN_STOCK
                                        FROM ITEM_MASTER_WITH_STOCK
                                        WHERE ITEM_CODE = ?
                                        AND MAKE = ?
                                        AND ADITIONAL_IDENTIFIER =?
                                        AND IN_STOCK > 0;
                                    '''
                                params = (item_no, make, product["cas_no"])
                            else:
                                query_stock = '''
                                        SELECT IN_STOCK
                                        FROM ITEM_MASTER_WITH_STOCK
                                        WHERE ITEM_CODE = ?
                                        AND MAKE = ?
                                        AND IN_STOCK > 0;
                                    '''
                                params = (item_no, make)
                            cursor = db_connection.cursor()
                            cursor.execute(query_stock, params)
                            stock_row = cursor.fetchone()
                            cursor.close()

                            if stock_row:  # stock available for this make
                                stock_available = stock_row[0]
                                product["make"] = make
                                is_make = True
                                logger.log(f"Selected make '{make}' with stock available (count={stock_available}).")
                                break

                        # Step 3: If no preferred make has stock, fallback to the originally requested/default make
                        if not is_make:
                            product["make"] = requested_make
                            make = requested_make
                            is_make = True
                            logger.log(f"No stock found for any make. Fallback to the default make: {requested_make}")

                    else:
                        logger.log(f"No past sales found for item {item_no}, keeping existing make: {product.get('make')}")

                    selected_make = product.get("make", "").strip()
    
                    # Extract Rate from Special_rate_customer_wise
                    query1 = '''
                        SELECT RATE 
                        FROM SPECIAL_RATE_CUSTOMER_WISE 
                        WHERE ITEM_CODE = ?
                        AND CUSTOMER_CODE = ?;
                    '''
                    cursor = db_connection.cursor()
                    cursor.execute(query1, (item_no, customer_code))
                    result = cursor.fetchone()
                    cursor.close()

                    if result:
                        rate = result[0]
                        found_rate = True
                        logger.log(f"Process_Category -[Recheck] Quotation [1B] Special Rate for item '{item_no}' and customer '{customer_code}' is {rate}")
                        price_pickup_source="SPECIAL_RATE_CUSTOMER_WISE"
                        product["price"] = "NA"
                        product["discount"]= "NA"
                        product["rate"] = rate if found_rate else "NA"
                        product["price_pickup_source"]=price_pickup_source 
                    else:
                        logger.log(f"RATE Not found in SPECIAL_RATE_CUSTOMER_WISE'")
    
                    #Extract rate from past_sales
                    if product.get("rate") in (None, "", "NA"):
                        query = '''
                            SELECT PRICE, DISCOUNT
                            FROM PAST_SALES
                            WHERE CUSTOMER_CODE = ?
                            AND ITEM_CODE = ?
                            AND MAKE = ?
                            LIMIT 1;
                        '''

                        cursor = db_connection.cursor()
                        cursor.execute(query, (customer_code, item_no, selected_make))
                        past_sales_result = cursor.fetchone()
                        cursor.close()

                        if past_sales_result:
                            price, discount = past_sales_result

                            if discount>0 :
                                # Compute rate using price & discount
                                rate = price * (1 - (discount / 100))
                                rate = round(rate, 2)

                                found_rate = True
                                price_pickup_source = "PAST_SALES"

                                logger.log(
                                    f"Process_Category - Quotation [2] Found in PAST_SALES Price={price}, Discount={discount}%. Rate={rate}"
                                )
                            else:
                                logger.log(f"Quotation Fallback: Invalid value Price={price}, Discount={discount}%. No discount applied in PAST_SALES'")
                                
                            product["price"] = price if price else "NA"
                            product["rate"] = rate if found_rate else "NA"
                            product["price_pickup_source"] = price_pickup_source
                            product["discount"] = discount if found_rate else "NA"
                        
                        else:
                            logger.log(f"Price Not found in PAST_SALES'")

                        if not product["price"] or product["price"] == "NA":
                            # Step 1: Get base price from PRICE_LIST
                            query_price = '''
                                SELECT PRICE 
                                FROM PRICE_LIST 
                                WHERE ITEM_NO = ?;
                            '''
                            cursor = db_connection.cursor()
                            cursor.execute(query_price, (item_no,))
                            price_result = cursor.fetchone()
                            cursor.close()

                            if price_result:
                                price_raw = price_result[0]
                                
                                if isinstance(price_raw, str):
                                    # Clean the string: remove INR and commas
                                    price_cleaned = price_raw.replace('INR', '').replace(',', '').strip()
                                else:
                                    price_cleaned = price_raw  # already numeric

                                try:
                                    raw_price = float(price_cleaned)
                                    logger.log(f"Process_Category - Quotation [3] Base price for item '{item_no}' is {raw_price}")
                                except (TypeError, ValueError):
                                    logger.log(f"Process_Category - Quotation [3] Invalid raw price for item '{item_no}': {price_result[0]}")
                                    product["rate"] = None
                                    continue
                            else:
                                logger.log(f"No base price found for item '{item_no}' .")
                                product["rate"] = "NA"
                                product["price_pickup_source"]="NA" 
                                product["discount"]="NA" 
                                continue

                            # Condition 1: Exact match in special_rate_customer_wise
                            # query1 = '''
                            #     SELECT RATE 
                            #     FROM SPECIAL_RATE_CUSTOMER_WISE 
                            #     WHERE ITEM_CODE = ?
                            #     AND CUSTOMER_CODE = ?;
                            # '''
                            # cursor = db_connection.cursor()
                            # cursor.execute(query1, (item_no, customer_code))
                            # result = cursor.fetchone()
                            # cursor.close()

                            # if result:
                            #     rate = result[0]
                            #     found_rate = True
                            #     logger.log(f"Process_Category - Quotation [1] Special Rate for item '{item_no}' and customer '{customer_code}' is {rate}")
                            #     price_pickup_source="SPECIAL_RATE_CUSTOMER_WISE"
                            #     Discount="NA"

                            # Condition 2: Customer + Manufacturer discount
                            if not found_rate:
                                query2 = '''
                                    SELECT DISCOUNT 
                                    FROM CUSTOMER_WISE_DISCOUNT 
                                    WHERE CUSTOMER_CODE = ? AND MAKE = ?;
                                '''
                                cursor = db_connection.cursor()
                                cursor.execute(query2, (customer_code, make))
                                discount_result = cursor.fetchone()
                                cursor.close()

                                if discount_result:
                                    discount_percent = discount_result[0]
                                    discount= discount_percent
                                    rate = raw_price * (1 - int(discount_percent) / 100)
                                    rate = round(rate, 2)
                                    found_rate = True
                                    logger.log(f"Process_Category - Quotation [4] Discounted rate for '{make}' ({discount_percent}%) on price {raw_price}: {rate} in  CUSTOMER_WISE_DISCOUNT ")
                                    price_pickup_source="CUSTOMER_WISE_DISCOUNT"

                            # Condition 3: Manufacturer General Discount
                            if not found_rate:
                                query4 = '''
                                    SELECT GENERAL_DISCOUNT 
                                    FROM MANUFACTURE_WISE_GENERAL_DISCOUNT 
                                    WHERE MAKE = ?;
                                '''
                                cursor = db_connection.cursor()
                                cursor.execute(query4, (make,))
                                general_discount_result = cursor.fetchone()
                                cursor.close()
                                 
                                if general_discount_result:
                                    general_discount_percent = general_discount_result[0]
                                    discount=general_discount_percent
                                    rate = raw_price * (1 - float(general_discount_percent) / 100)
                                    rate = round(rate, 2)
                                    found_rate = True
                                    logger.log(f"Process_Category - Quotation [5] General Discount for '{make}' ({general_discount_percent}%) on price {raw_price}: {rate}")
                                    price_pickup_source="MANUFACTURE_WISE_GENERAL_DISCOUNT"
                                            
                            #Condition 4: Fallback to raw_price if no discount applied
                            if not found_rate:
                                rate = raw_price
                                logger.log(f"Process_Category - Quotation [6] No discounts applied. Using base price for item '{item_no}': {rate}")
                                price_pickup_source="PRICE_LIST"
                                discount = "NA"

                            product["price"] = raw_price
                            product["rate"] = rate
                            product["price_pickup_source"]=price_pickup_source 
                            product["discount"]=discount 

            db_connection.close()

            logger.log(f"Identified products: {products}")
            logger.log(f"Identified products length: {len(products)}")
            # quotation_draft = self.generate_quotation_attachment_draft(products, signature)
            quotation_draft,is_attachment = self.generate_quotation_draft(
                customer_data, 
                products,
                Model_Name, 
                openai_api_key, 
                geminiAI_APIKey, 
                localAIURL,
                email_body, 
                subject,
                signature
            )
            logger.log(f"quotation_draft ::: {quotation_draft}")
            logger.log(f"is_attachment ::: {is_attachment}")

            # Step 8: Send draft quotation email
            email_details = {"sender": sender_email_addr, "cc": cc_email_addr, "subject": subject, "body": email_body}
            email_draft = Email_Draft()
            if is_attachment:
                status, response = email_draft.quotation_draft_attachment_email(email_config, email_details, quotation_draft)
            else:
                status, response = email_draft.quotation_draft_email(email_config, email_details, quotation_draft)
            logger.log(f"status ::: {status}")

            csv_data_status = status
            csv_data_response = response
            logger.log(f"Quotation email sent to {sender_email_addr}")

        elif category == "Others" and import_file == True:
            action_taken = "-"
            csv_data_status = "Fail"
            csv_data_response = f"-"
        else:
            val_mail_id = email_config.get('email')
            val_mail_pass = email_config.get('password')
            
            if val_mail_id != None and val_mail_pass != None:
                action_taken = f"Saved the mail to the label: {LABEL}"
                csv_data_status = "Success"
                csv_data_response = f""

                logger.log(f"Marking email as UNREAD. ")
                mail.store(email_id, '-FLAGS', '\\Seen')
                mail.create(LABEL)
                mail.copy(email_id, LABEL)
                logger.log(f"Mail labeled as '{LABEL}' and kept in inbox (unread).")

        current_timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        filename = f'{uid}{current_timestamp}'
        logger.log(f"The file name for csv and eml is ::: {filename}")
        self.store_email_details_to_csv(
            email_id=f'{uid}{current_timestamp}',
            to_email=parseaddr(to_email_addr)[1],
            from_email=parseaddr(sender_email_addr)[1],
            cc_email=parseaddr(cc_email_addr)[1] if cc_email_addr else '',
            subject=subject,
            body=email_body,
            email_type=category,
            action_performed=action_taken,
            filename=filename,
            user_id=user_id,
            status=csv_data_status,
            response=csv_data_response,
            current_timestamp=current_timestamp,
            customer_determination=customer_determination,
            product_determination=product_determination,
        )
        self.store_email_as_eml(
            uid=f'{uid}{current_timestamp}',
            from_email=sender_email_addr,
            to_email=to_email_addr,
            cc_email=cc_email_addr,
            subject=subject,
            date=date,
            body_content=email_body,
            is_html=is_html,
            filename=filename,
            user_id=user_id
        )    

    def get_JsonArray_values(self, category, jsonArray):
        responseMethod  = ""
        parameters      = ""
        
        for eachJson in jsonArray :
            for key, value in eachJson.items():
                if value == category:
                    responseMethod  = eachJson["Response_Method"]  
                    parameters      = eachJson["Parameters"]
        
        return responseMethod, parameters
    
    def download_attachment(self, msg):

        filename = ""
        mime_type = ""
        document_type = ""

        for part in msg.walk():
            if part.get_content_maintype() == 'multipart':
                continue
            if part.get('Content-Disposition') is None:
                continue

            filename = part.get_filename()
            mime_type = part.get_content_type().lower()

            if "pdf" in mime_type or filename.lower().endswith(".pdf"):
                document_type = "Orders"
            elif "msword" in mime_type or "wordprocessingml" in mime_type or filename.lower().endswith(".docx"):
                document_type = "Order Excel"
            elif "excel" in mime_type or "spreadsheetml" in mime_type or filename.lower().endswith((".xls", ".xlsx")):
                document_type = "Order Excel"
            elif "csv" in mime_type or filename.lower().endswith(".csv"):
                document_type = "Order Excel"
            elif "plain" in mime_type or filename.lower().endswith(".txt"):
                document_type = "Order Email"
            elif "rtf" in mime_type or filename.lower().endswith(".rtf"):
                document_type = "Order Excel"

            if filename:
                today_date = datetime.today().strftime('%Y-%m-%d')  # Format: YYYY-MM-DD
                date_folder = os.path.join(document_type, today_date)  # Path: ORDERS/YYYY-MM-DD
                os.makedirs(date_folder, exist_ok=True)

                filepath = os.path.join(date_folder, filename)  # Save inside date-wise folder

                with open(filepath, 'wb') as f:
                    f.write(part.get_payload(decode=True))
                logger.log(f"\nAttachment saved: '{filepath}'")
            else:
                logger.log("\nNo Attachment found.")
        return filename, document_type
    
    def create_file_from_emailBody(self, text, sender_email_addr, parameters):
        base_folder = parameters.get('DOCUMENT_TYPE', '')
        today_date = datetime.today().strftime('%Y-%m-%d')  # Format: YYYY-MM-DD
        order_folder = os.path.join(base_folder, today_date)

        # Ensure the date-wise folder exists
        os.makedirs(order_folder, exist_ok=True)

        # Generate filename from sender's email
        fileName = sender_email_addr[sender_email_addr.find("<")+1:sender_email_addr.find("@")].strip().replace(".","_")
        
        if parameters["FILE_TYPE"] == "pdf":
            fileName = fileName + ".pdf"
            filePath = os.path.join(order_folder, fileName)

            pdf = FPDF()
            pdf.add_page()
            pdf.set_font("Arial", size=12)
            pdf.multi_cell(0, 10, text)
            pdf.output(filePath)
            logger.log(f"New PDF file created from email body and stored in '{filePath}'")

        elif parameters["FILE_TYPE"] == "txt":
            fileName = fileName + ".txt"
            filePath = os.path.join(order_folder, fileName)

            with open(filePath, "w", encoding="utf-8") as file:
                file.write(text)
                logger.log(f"New TXT file created from email body and stored in '{filePath}'")
        else:
            message = f"Invalid File Type received."
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            self.wfile.write(message.encode('utf-8'))

        return fileName
    
    def identify_keywords(self, Model_Name, email_body, openai_api_key, geminiAI_APIKey, target_keyword):
        prompt=""
        if target_keyword == "customer":
            prompt = """ Extract the client/Customer Name from the text and return ONLY a JSON list with fields: cust_name, where the cust_name is the customer name/company name. If customer name is not explicitly mentioned in the mail check the email id or website mentioned for the customer name."""
        elif target_keyword == "product":
            prompt = """
                Extract all the products requested from the text and return ONLY a JSON list with fields: requested_description, item_no and quantity, Where the requested_description is the name of the item, quantity is the quantity of the respective item and item_no is the product/item code. If any of these is not present in the text return NA.
            """
        if Model_Name == "OpenAI":
            client = OpenAI(api_key=openai_api_key)
            response = client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": "You are an assistant that extracts structured data."},
                    {"role": "user", "content": f"{prompt}\n\nText:\n{email_body}"}
                ],
                temperature=0
            )
            json_text = response.choices[0].message.content.strip()
            cleaned_text = (
                json_text.replace("\n```", "")
                .replace("```", "")
                .replace("json", "")
                .replace("JSON", "")
                .strip()
            )

            try:
                parsed = json.loads(cleaned_text)  # Convert to Python object
                ai_result = {"status": "Success", "data": parsed}
                logger.log(f"The response generated by OpenAI keyword extraction ::: {ai_result}")
            except Exception as e:
                ai_result = {"status": "Error", "message": cleaned_text, "error": str(e)}

        elif Model_Name == "GeminiAI":
            try:
                genai.configure(api_key=geminiAI_APIKey)
                model = genai.GenerativeModel("gemini-2.5-flash-lite")

                full_prompt = f"""
                {prompt}
                Text:
                {email_body}
                Return ONLY valid JSON. No explanation, no markdown.
                """
                response = model.generate_content(
                    full_prompt,
                    generation_config={
                        "temperature": 0,
                        "response_mime_type": "application/json"
                    }
                )

                json_text = response.text.strip()

                # Clean response 
                cleaned_text = (
                    json_text.replace("\n```", "")
                    .replace("```", "")
                    .replace("json", "")
                    .replace("JSON", "")
                    .strip()
                )

                try:
                    parsed = json.loads(cleaned_text)
                    ai_result = {"status": "Success", "data": parsed}
                    logger.log(f"The response generated by Gemini keyword extraction ::: {ai_result}")
                except Exception as e:
                    ai_result = {"status": "Error","message": cleaned_text, "error": str(e)}

            except Exception as e:
                ai_result = {"status": "Error","message": "Gemini API failed","error": str(e)}

        else:
            logger.log(f"Invalid Model Type ::: {Model_Name}")

        return ai_result
    
    def generate_quotation_draft(self, customer_data, products, model_type, openai_api_key, gemini_api_key, local_ai_url, email_body, subject, signature):
        
        customer = customer_data
        
        product_table = "Products:\n"
        for product in products:
            rate = product.get("rate", "NA")
            quantity = product.get("quantity", "NA")
            try:
                total = float(rate) * float(quantity)
            except:
                total = rate if rate != "NA" and rate not in ("", None) else "-"
            product_table += (
                f'- Requested Description: {product.get("requested_description", "-")}, '
                f'Item Code: {product.get("item_no", "-")}, '
                f'Item Description: {product.get("description", "-")}, '
                f'Make: {product.get("make", "-")}, '
                f'Inventory Unit: {product.get("inventory_unit", "-")}, '
                f'Price: {product.get("price", "-")}, '
                f'Discount: {product.get("discount", "-")}, '
                f'Rate: {rate}, '
                f'Quantity: {quantity}, '
                f'Pack Size: {product.get("pack_size", "-")}, '
                f'Material Type: {product.get("material_type", "-")}, '
                f'Total: {total}, '
                f'Availability: ""\n'
            )
                # f'Price Pickup Source: {product.get("price_pickup_source", "-")}, '
        
        if model_type == "OpenAI":
            prompt = f"""
                Generate product information in HTML tabular format with line separators for rows and columns in a draft reply based on the following information:

                Customer: {customer.get('cust_name', '')}  
                Customer Code: {customer.get('cust_code', '')}  

                {product_table}  
                Ensure the table has the following columns in this exact order:
                Sr. No., Requested Description, Item Code, Item Description, Make, Inventory Unit, Price, Discount, Rate, Quantity, Pack Size, Material Type, Total, Availability

                - If any value is missing, use a dash ("-") instead.
                - "Availability" should be a blank column.
                Original Email Subject: {subject}

                Return only the following JSON String format:
                {{
                    "email_body": {{
                        "body": "Draft email body proper response, It should not be same like mail content and does not having any signature part like Best regards.",
                        "table_html": "Table Details with Sr. No. in HTML",
                        "signature": "{signature}"
                    }}
                }}

                Do not include signature in body and any instructions, explanations, or additional text—only the JSON object.
            """
            logger.log(f"Quotation draft ::: {prompt}")
            emailreplyassistant = EmailReplyAssistant()
            ai_result = emailreplyassistant.create_quotation_draft(openai_api_key, email_body, subject, prompt)   

        elif model_type == "GeminiAI":
            prompt = f"""
                Generate product information in HTML tabular format with line separators for rows and columns in a draft reply based on the following information:

                Customer: {customer.get('cust_name', '')}  
                Customer Code: {customer.get('cust_code', '')}  

                {product_table}  
                Ensure the table has the following columns in this exact order:
                Sr. No., Requested Description, Item Code, Item Description, Make, Inventory Unit, Price, Discount, Rate, Quantity, Pack Size, Material Type, Total, Availability

                - If any value is missing, use a dash ("-") instead.
                - "Availability" should be a blank column.
                Original Email Subject: {subject}

                Return only the following JSON String format:
                {{
                    "email_body": {{
                        "body": "Write a simple,short and formal email reply addressed directly to the customer (e.g., 'Dear [Customer Name],').After the greeting, insert a newline (line break) before starting the message body. The response must sound natural and conversational, clearly replying to the customer's inquiry. It should not be same like mail content and should not having any signature part like Best regards.",
                        "table_html": "Table Details with Sr. No. in HTML, ensure the table always has visible borders using inline CSS for table",
                        "signature": "{signature}"
                    }}
                }}

                Do not include signature in body and any instructions, explanations, or additional text—only the JSON object.
            """
            logger.log(f"Quotation draft ::: {prompt}")
            ai_result = self.create_quotation_draft_GeminiAI(gemini_api_key, email_body, prompt)

        elif model_type == "LocalAI":
            prompt = f"""
                Generate product information in HTML tabular format with line separators for rows and columns in a draft reply based on the following information:

                Customer: {customer.get('customer_name', '')}  
                Customer Code: {customer.get('customer_code', '')}  

                {product_table}  
                - The table must contain the **Price** column, even if it is empty (set it as `-` if None).  
                - The table should include **Sr. No.** as the first column.  
                - Format the table with `<table>`, `<tr>`, `<th>`, and `<td>` tags with some border to table.

                Original Email Subject: {subject}  

                Return **strictly** in the following JSON String format:
                - All keys must be: `body`, `table_`, and `signature` inside the `email_body` JSON.  
                - **Do not include** `\n`, `\`, `\\`, or any unnecessary escape characters.  
                - Do not include instructions, explanations, or additional text—only the JSON object.  

                Format:
                {{
                    "email_body": {{
                        "body": "Draft email body proper response, It should not contain the table or signature.",
                        "table_": "Table Details with Sr. No. in HTML only",
                        "signature": "{signature}"
                    }}
                }}
            """
            logger.log(f"Quotation draft ::: {prompt}")
            ai_result = self.create_quotation_draft_LocalAI(openai_api_key, email_body, local_ai_url, prompt)

        else:
            ai_result = "Error: Unable to generate quotation draft. Please check the configuration."
        
        logger.log(f"Quotation draft ai_result::: {ai_result}")
        quotation_draft_data = None
        is_attachment = False
        if ai_result != None:
            try:
                quotation_draft_data = json.loads(ai_result)["email_body"]
            except:
                logger.log("AI JSON parsing failed, generating attachment draft")
                quotation_draft_data = self.generate_quotation_attachment_draft(products, signature)
                is_attachment = True
        return quotation_draft_data,is_attachment

    def generate_quotation_attachment_draft(self, products, signature):
        base_dir = "quotation_attachments"
        os.makedirs(base_dir, exist_ok=True)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        file_path = os.path.join(base_dir, f"Quotation_{timestamp}.xlsx")

        wb = Workbook()
        ws = wb.active
        ws.title = "Quotation"

        # EXACT HEADER SEQUENCE
        headers = [
            "Sr. No.",
            "Requested Description",
            "Item Code",
            "Item Description",
            "Make",
            "Inventory Unit",
            "Price",
            "Discount",
            "Rate",
            "Quantity",
            "Pack Size",
            "Material Type",
            "Total",
            "Availability"
        ]

        ws.append(headers)

        # DATA ROWS
        for index, product in enumerate(products, start=1):
            rate = product.get("rate")
            quantity = product.get("quantity")

            try:
                total = float(rate) * float(quantity)
            except (TypeError, ValueError):
                total = ""

            ws.append([
                index,  # Sr. No.
                product.get("requested_description", ""),
                product.get("item_no", ""),
                product.get("description", ""),
                product.get("make", ""),
                product.get("inventory_unit", ""),
                product.get("price", ""),
                product.get("discount", ""),
                rate,
                quantity,
                product.get("pack_size", ""),
                product.get("material_type", ""),
                total,
                ""  # Availability (blank)
            ])

        wb.save(file_path)

        return {
            "body": "Dear Sir,<br>Please find the quotation of the product details attached as per your request.",
            "file_path": file_path,
            "signature": signature
        }

    def identify_customer_product_LocalAI(self, openai_api_key, email_body, local_ai_url, prompt):
        logger.log("Inside identify_customer_product_LocalAI")   
        try:
            message = [{
                "role": "user",
                "content": f"{prompt}"
            }]

            logger.log(f"Final Local AI message for detecting category::: {message}")
            openai.api_key = openai_api_key
            client = OpenAI(base_url=local_ai_url, api_key="lm-studio")
            completion = client.chat.completions.create(
                model="mistral",
                messages=message,
                temperature=0,
                stream=False,
                max_tokens=4096
            )

            final_result = str(completion.choices[0].message.content)
            final_result = final_result.replace("\n```", "").replace("```", "").replace("json","").replace("JSON","").replace("csv","").replace("CSV","").replace("html","")
            logger.log(f"finalResult:520  {final_result}")
            return {"status": "Success", "message": final_result}

        except Exception as e:
            logger.log(f"Error with LocalAI detection/generation: {str(e)}")
            return {"success": "Failed", "message": f"Error with LocalAI detection/generation: {str(e)}"}
        
    def create_quotation_draft_LocalAI(self, openai_api_key, email_body, local_ai_url, prompt):
        logger.log("Inside create_quotation_draft_LocalAI")   
        try:
            message = [{
                "role": "user",
                "content": f"{prompt}"
            }]

            logger.log(f"Final Local AI message for detecting category::: {message}")
            openai.api_key = openai_api_key
            client = OpenAI(base_url=local_ai_url, api_key="lm-studio")
            completion = client.chat.completions.create(
                model="mistral",
                messages=message,
                temperature=0,
                stream=False,
                max_tokens=4096
            )

            final_result = str(completion.choices[0].message.content)
            final_result = final_result.replace("\n```", "").replace("```", "").replace("json","").replace("JSON","").replace("csv","").replace("CSV","").replace("html","")
            logger.log(f"finalResult:520  {final_result}")
            return final_result

        except Exception as e:
            logger.log(f"Error with LocalAI detection/generation: {str(e)}")
            return str(e)
        
    def identify_customer_product_GeminiAI(self, gemini_api_key, email_body, prompt):
        logger.log("Inside identify_customer_product_GeminiAI")   
        try:
            message = [{
                "role": "user",
                "content": f"{prompt}"
            }]

            logger.log(f"Final Gemini AI message for detecting category::: {message}")
            message_list = str(message)

            genai.configure(api_key=gemini_api_key)
            # model = genai.GenerativeModel('gemini-1.0-pro')
            model = genai.GenerativeModel('gemini-2.5-flash-lite')
            response = model.generate_content(message_list)
            
            final_result = ""
            for part in response:
                final_result = part.text
                logger.log(f"response:::  {final_result}")
                if final_result:
                    try:
                        final_result = final_result.replace("\\", "").replace('```', '').replace('json', '')
                        if final_result.startswith("{{") and final_result.endswith("}}"):
                            final_result = final_result[1:-1]
                    except json.JSONDecodeError:
                        logger.log(f"Exception : Invalid JSON Response GEMINI 1.5: {final_result} {type(final_result)}")

            logger.log(f"finalResult:::  {final_result}")
            return {"status": "Success", "message": final_result}

        except Exception as e:
            logger.log(f"Error with Gemini AI detection/generation: {str(e)}")
            return {"success": "Failed", "message": f"Error with Gemini AI detection/generation: {str(e)}"}
        
    def create_quotation_draft_GeminiAI(self, gemini_api_key, email_body, prompt):
        logger.log("Inside identify_customer_product_GeminiAI")   
        try:
            message = [{
                "role": "user",
                "content": f"{prompt}"
            }]

            logger.log(f"Final Gemini AI message for detecting category::: {message}")
            message_list = str(message)

            genai.configure(api_key=gemini_api_key)
            # model = genai.GenerativeModel('gemini-1.0-pro')
            model = genai.GenerativeModel('gemini-2.5-flash-lite')
            response = model.generate_content(message_list)
            
            final_result = ""
            for part in response:
                final_result = part.text
                logger.log(f"response:::  {final_result}")
                if final_result:
                    try:
                        final_result = final_result.replace('```', '').replace('json', '')
                        if final_result.startswith("{{") and final_result.endswith("}}"):
                            final_result = final_result[1:-1]
                    except json.JSONDecodeError:
                        logger.log(f"Exception : Invalid JSON Response GEMINI 1.5: {final_result} {type(final_result)}")

            logger.log(f"Response Draft Generated by GeminiAI:::  {final_result}")
            return final_result

        except Exception as e:
            logger.log(f"Error with Gemini AI detection/generation: {str(e)}")
            return {"success": "Failed", "message": f"Error with Gemini AI detection/generation: {str(e)}"}
        
    def store_email_details_to_csv(self, email_id, to_email, from_email, cc_email, subject, body, email_type, action_performed, filename, user_id,status,response,current_timestamp,customer_determination,product_determination):
        """
        Stores the extracted email details to a CSV file inside 'Mail_log/mail_log_user_id' folder
        with the name user_id.csv.
        """

        match = re.search(
            r'Content-Transfer-Encoding:\s*base64\s+([\s\S]+?)\n--',
            response,
            re.IGNORECASE
        )
        if match:
            response = self.extract_html_from_mime(response)
                
        # Ensure the Mail_log folder exists
        log_folder = "Mail_log"
        os.makedirs(log_folder, exist_ok=True)

        # Create the mail_log_user_id folder inside 'Mail_log' if it doesn't exist
        user_folder = os.path.join(log_folder, f"{user_id}")
        os.makedirs(user_folder, exist_ok=True)

        filename = filename.lstrip()
        full_csv_path = os.path.join(user_folder, f"{filename}.csv")

        if email_type=="Quotation":
            csv_data = [{
            'to': to_email,
            'from': from_email,
            'cc': cc_email,
            'subject': subject,
            'body': body.replace('\n', ' ').replace('\r', ''),
            'Category': email_type,
            'Action Performed': action_performed,
            'unique_id': email_id,
            'timestamp': current_timestamp,
            'status of mail draft': status,
            'Response Generated':response,
            'Customer Determination':customer_determination,
            'Product Determination':product_determination,
        }]
        else:
            csv_data = [{
                'to': to_email,
                'from': from_email,
                'cc': cc_email,
                'subject': subject,
                'body': body.replace('\n', ' ').replace('\r', ''),
                'Category': email_type,
                'Action Performed': action_performed,
                'unique_id': email_id,
                'timestamp': current_timestamp,
                'status of mail draft': status,
            }]
        
        # Write to CSV file (user_id.csv)
        with open(full_csv_path, 'a', newline='', encoding='utf-8') as csvfile:
            if email_type == "Quotation":
                fieldnames = [
                    'to', 'from', 'cc', 'timestamp', 'subject', 'body',
                    'Category', 'Action Performed', 'unique_id',
                    'status of mail draft', 'Response Generated',
                    'Customer Determination', 'Product Determination'
                ]
            else:
                fieldnames = [
                    'to', 'from', 'cc', 'timestamp', 'subject', 'body',
                    'Category', 'Action Performed', 'unique_id',
                    'status of mail draft'
                ]
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            
            # If the file is empty, write the header
            if os.stat(full_csv_path).st_size == 0:
                writer.writeheader()
            
            # Write the email data
            writer.writerows(csv_data)

        # Log the action
        logger.log(f"Email with ID '{email_id}' details appended to {full_csv_path}")

    def store_email_as_eml(self, uid, from_email, to_email, cc_email, subject, date, body_content,filename,user_id,is_html=False,):
        """
        Stores a simplified EML-style email as a .eml file inside 'Mail_Formats' folder.

        Args:
            uid (str): Unique ID of the email.
            from_email (str): Sender email.
            to_email (str): Recipient email.
            cc_email (str): CC email.
            subject (str): Subject of the email.
            date (str): Date of the email.
            body_content (str): Email body content.
            is_html (bool): Whether the body_content is in HTML format.
        """
        archive_folder = "Mail_Formats"
        user_folder = os.path.join(archive_folder, f"{user_id}")
        os.makedirs(user_folder, exist_ok=True)

        filename = filename.lstrip()
        # Define the full path for the CSV file (csv_filename.csv inside the mail_log_user_id folder)
        eml_file_path = os.path.join(user_folder, f"{filename}.eml")

        try:
            with open(eml_file_path, 'w', encoding='utf-8') as eml_file:
                eml_file.write(f"From: {from_email}\n")
                eml_file.write(f"To: {to_email}\n")
                if cc_email:
                    eml_file.write(f"Cc: {cc_email}\n")
                eml_file.write(f"Subject: {subject}\n")
                eml_file.write(f"Date: {date}\n")
                eml_file.write(f"MIME-Version: 1.0\n")
                
                if is_html:
                    eml_file.write(f"Content-Type: text/html; charset=utf-8\n\n")
                    eml_file.write(body_content)
                else:
                    eml_file.write(f"Content-Type: text/plain; charset=utf-8\n\n")
                    eml_file.write(body_content)

            logger.log(f"Stored simplified EML file for UID '{uid}' at {eml_file_path}")

        except Exception as e:
            logger.log(f"Failed to save EML for UID '{uid}': {str(e)}")


            """Retrieves the user ID from the session or cookies."""
            # For simplicity, let's assume we get the user_id from cookies
            if "Cookie" in self.headers:
                cookie = SimpleCookie(self.headers["Cookie"])
                user_id = cookie.get("user_id")  # Assuming user_id is stored in a cookie
                if user_id:
                    return user_id.value
            return None

    def extract_html_from_mime(self, raw_data):
        msg = message_from_string(raw_data)

        if msg.is_multipart():
            for part in msg.walk():
                content_type = part.get_content_type()
                content_disposition = part.get("Content-Disposition", "").lower()

                # Skip attachments
                if "attachment" in content_disposition:
                    continue

                if content_type == "text/html":
                    payload = part.get_payload(decode=True)

                    if payload:
                        charset = part.get_content_charset() or "utf-8"
                        try:
                            return payload.decode(charset, errors="replace")
                        except Exception as e:
                            logger.log(f"HTML decode error: {e}")
                            return payload.decode("utf-8", errors="replace")

        return "No HTML content found."
   
    def products_item_code_lookup(self, products, openai_api_key, schemaName_Updated, server_url):
        try:
            logger.log(f'\nproduct_Json : {products}')
            logger.log(f'\nopenai_api_key : {openai_api_key}')
            logger.log(f'\nschemaName_Updated : {schemaName_Updated}')
            logger.log(f'\nserver_url : {server_url}')
            alphaValue = 0.54

            client = weaviate.Client(server_url,additional_headers={"X-OpenAI-Api-Key": openai_api_key}, timeout_config=(180, 180))
            logger.log(f'Connection is establish : {client.is_ready()}')

            schemaClasslist = [i['class'] for i in client.schema.get()["classes"]]  
            logger.log(f'schemaClasslist : {schemaClasslist}')

            for product in products:
                item_name = product.get("requested_description", "NA")
                item_no = product.get("item_no", "NA")
                # inputQuery  = item_name.upper().replace("N/A","").replace("."," ").replace(","," ").replace("-"," ").replace("_"," ")
                # if item_no != "NA":
                    # inputQuery  = item_no
                    # logger.log(f'inputQuery : {inputQuery}')
                    # product = self.product_lookup_by_item_no(item_no, client,schemaName_Updated,alphaValue,inputQuery,product)
                    # logger.log(f'product : {product}')
                if item_no == "NA":
                    inputQuery  = item_name
                    logger.log(f'inputQuery : {inputQuery}')
                    
                    if schemaName_Updated in schemaClasslist:
                        logger.log(f'Inside schemaClasslist')
                        response    = (
                            client.query
                            .get(schemaName_Updated, ["description", "answer", "phy_attrib_1", "phy_attrib_2", "phy_attrib_3", "phy_attrib_4","phy_attrib_5"])
                            .with_hybrid(
                                            alpha = alphaValue,
                                            query       =  inputQuery.strip() ,
                                            fusion_type =  HybridFusion.RELATIVE_SCORE
                                        )
                            .with_additional('score')
                            .with_limit(10)
                            .do()
                            )

                        if response != {}:
                            response_List = response['data']['Get'][schemaName_Updated] 
                            logger.log(f"The response_List is ::: {response_List}")
                            best_item = min(response_List, key=lambda x: self.get_priority_index(x.get("phy_attrib_2", "").lower()))
                            logger.log(f"The best item is ::: {best_item}")

                            # Assign selected values to product
                            product['description']     = best_item.get('description')
                            product['item_no']         = best_item.get('answer')
                            product['cas_no']          = best_item.get('phy_attrib_1')
                            product['make']            = best_item.get('phy_attrib_2')
                            product["price"]           = best_item.get('phy_attrib_3')
                            product["inventory_unit"]  = best_item.get('phy_attrib_4')
                            product["stock"]           = best_item.get('phy_attrib_5')

                            for index in range(len(response_List)):
                                description           = response_List[index]['description']
                                description           = description.upper().replace("N/A","").replace("."," ").replace(","," ").replace("-"," ").replace("_"," ")

                                descr_replaced        = description.replace(" ", "") 
                                inputQuery_replaced   = inputQuery.replace(" ", "")

                                if descr_replaced == inputQuery_replaced:
                                    logger.log(f"\n Input::: '{inputQuery_replaced}' MATCHEDD with description ::: '{descr_replaced}' \n")
                                    product['description'] = response_List[index]['description']
                                    product['item_no'] = response_List[index]['answer']
                                    product['cas_no']  =  response_List[index]['phy_attrib_1']
                                    product['make'] =  response_List[index]['phy_attrib_2']
                                    product["price"] =  response_List[index]['phy_attrib_3']
                                    product["inventory_unit"] =  response_List[index]['phy_attrib_4']
                                    product["stock"] =  response_List[0]['phy_attrib_5']

                                    break
                                else:
                                    logger.log(f"\n Input '{inputQuery_replaced}' not matched with returned response description '{descr_replaced}'\n ")    

            return product       

        except Exception as error:
            raise 
    
    def customer_code_lookup(self, cust_name, openai_api_key, schemaName_Updated, server_url):
        try:
            logger.log(f'\ncust_name : {cust_name}')
            logger.log(f'\nopenai_api_key : {openai_api_key}')
            logger.log(f'\nschemaName_Updated : {schemaName_Updated}')
            logger.log(f'\nserver_url : {server_url}')
            alphaValue = 0.54

            finalResultJson = {}
            client = weaviate.Client(server_url,additional_headers={"X-OpenAI-Api-Key": openai_api_key}, timeout_config=(180, 180))
            logger.log(f'Connection is establish : {client.is_ready()}')

            schemaClasslist = [i['class'] for i in client.schema.get()["classes"]]  
            logger.log(f'schemaClasslist : {schemaClasslist}')

            inputQuery  = cust_name.upper().replace("N/A","").replace("."," ").replace(","," ").replace("-"," ").replace("_"," ")
            logger.log(f'inputQuery : {inputQuery}')
            
            if schemaName_Updated in schemaClasslist:
                logger.log(f'Inside schemaClasslist')
                response    = (
                    client.query
                    .get(schemaName_Updated, ["description", "answer"]) 
                    .with_hybrid(
                                    alpha       =  alphaValue ,
                                    query       =  inputQuery.strip() ,
                                    fusion_type =  HybridFusion.RELATIVE_SCORE
                                )
                    .with_additional('score')
                    .with_limit(10)
                    .do()
                    )
                logger.log(f"Input ::: {cust_name}")
                if response != {}:
                    response_List = response['data']['Get'][schemaName_Updated] 
                    finalResultJson = {"cust_code": response_List[0]['answer'] , "cust_name": response_List[0]['description'] } if len(response_List) > 0 else {}

                    for index in range(len(response_List)):
                        cust_name           = response_List[index]['description']
                        cust_name           = cust_name.upper().replace("N/A","").replace("."," ").replace(","," ").replace("-"," ").replace("_"," ")
                        cust_code           = response_List[index]['answer']

                        descr_replaced      = cust_name.replace(" ", "") 
                        inputQuery_replaced = inputQuery.replace(" ", "")

                        if descr_replaced == inputQuery_replaced:
                            logger.log(f"\n Input::: '{inputQuery_replaced}' MATCHEDD with description ::: '{descr_replaced}' \n")
                            finalResultJson    =  {"cust_code": cust_code, "cust_name": cust_name } 
                            break
                        else:
                            logger.log(f"\n Input '{inputQuery_replaced}' not matched with returned response description '{descr_replaced}'\n ")    
                return finalResultJson        
        except Exception as error:
            raise str(error)     
    
    # def product_lookup_by_item_no(self,item_no, client,schemaName_Updated,alphaValue,inputQuery,product):
    #     logger.log(f'Inside schemaClasslist')
    #     where_filter = {
    #         "path": ["answer"],
    #         "operator": "Equal",
    #         "valueText": item_no
    #     }
    #     response    = (
    #         client.query
    #         .get(schemaName_Updated, ["description", "answer", "phy_attrib_1", "phy_attrib_2", "phy_attrib_3", "phy_attrib_4","phy_attrib_5"])
    #         .with_where(where_filter)
    #         .with_hybrid(
    #                         alpha = alphaValue,
    #                         query       =  inputQuery.strip() ,
    #                         fusion_type =  HybridFusion.RELATIVE_SCORE
    #                     )
    #         .with_additional('score')
    #         .with_limit(10)
    #         .do()
    #         )
    #     response_List = response['data']['Get'][schemaName_Updated]
    #     if response_List:
    #         product['description'] = response_List[0]['description']
    #         product['item_no'] = response_List[0]['answer']
    #         product['cas_no']  =  response_List[0]['phy_attrib_1']
    #         product['make'] =  response_List[0]['phy_attrib_2']
    #         product["price"] =  response_List[0]['phy_attrib_3']
    #         product["inventory_unit"] =  response_List[0]['phy_attrib_4']
    #         product["stock"] =  response_List[0]['phy_attrib_5']
    #     return product
    
    def get_priority_index(self, make):
        priority_list = ["loba", "merck", "e-merck", "rankem", "borosil", "tarsons", "rcc", "sigma-aldrich"]
        make = make.lower().strip()

        for i, priority in enumerate(priority_list):
            if priority in make:
                return i

        return len(priority_list)

    def extract_product_catalog_details_gemini(self,attachment_email_body, geminiAI_APIKey):
        genai.configure(api_key=geminiAI_APIKey)

        model = genai.GenerativeModel("gemini-flash-latest")

        prompt = f"""
            Extract all products mentioned in the given text and enrich them using manufacturer/catalog information. For each product, return the following fields in the specified order:
            requested_description – Product name exactly as mentioned in the text.
            make – Find manufacturers who supply this product based on grade mapping and allowed list. If multiple manufacturers supply it, create a separate entry for each make.
            description – Product name as listed in the manufacturer/catalog for that make.
            item_no – Search for an exact match in that manufacturer’s catalog using product name or CAS number. Return the item code only if an exact match is found. Do not generate or assume item codes. If not found, return NA.
            quantity – Quantity mentioned in the text. If not mentioned, return 1.
            pack_size – Pack size of the product e.g., 100 gm, 500 ml, 1 Ltr, 25 Kg, etc. extracted from the text or catalog, if not found, return NA.
            material_type – Material type such as chemical,instrument, plasticware, or glassware. Infer from the product name or catalog information if possible, otherwise return NA.
            cas_no – Extract the CAS number using the product name from standard chemical references. Do not guess or infer CAS numbers, if not available, return NA.
            inventory_unit – Inventory unit e.g., KGS, LTR, NOS, PKT etc. if it can be inferred from the catalog or product description, otherwise return NA.
            price – Return blank.
            stock – Return blank.
            Note: The make of the products must be strictly limited to the ones mentioned below no other makes will be accepted.
            "Loba Chemie, E-Merck, Merck, Merck Biomonitoring, Merck KGaA, Merck PCS, Rankem, Borosil, TARSONS, RCC, SIGMA-ALDRICH, ADVANCED, AGILENT, AVANTOR, BIO-SPAN, BioShlied, DURAN,  EUTECH, EXPRESOLV, FILTRUM, FINAR, GACL, HEMILTON, Hi - Media, HONEYWELL, HPLC, INORGENIC VENTURES, J T Baker, KEMPHASOL, LABINDIA ANALYTICAL INSTRUMENT, Macherey-Nagel,  MICROLIT, Microxpress, Millipore, MP Biomedicals, NANO MICRO TECH, NATIONAL, ORYN, OTTO, PALL, PHENOMENEX, POLYLAB, PRIME CHEM, PSI, Qualigens, Qualikems, RASAYAN, RELCO, REMI, Sartorius, SD FINE, SGE, SPECTROCHEM, TCI, Thermo Fisher, VWR, WESLEY TECHNOLOGIES, WHATMAN, ZENITH"
            Rules:
            1. Perform extraction first, then enrichment in this sequence: extract product name, identify makes, find CAS number, use product name or CAS number to search within that manufacturer’s catalog and return the correct item code then infer remaining fields.
            2. If any field cannot be found, return NA for that field. Extract all products mentioned and return ONLY a JSON array containing these fields, with no explanations, comments, or additional text outside the JSON output.
            3. Grade-based make mapping rule:
            If a product mentions a grade, map it to the corresponding manufacturer (make) using the following:
            - LR (Laboratory Reagent)- Merck (Emplura), Loba Chemie (Extra Pure), Rankem/ J.T. Baker(LR/Purified), Sigma Aldrich(ReagentGrade)
            - AR (Analytical Reagent)- Merck (Emparta), Loba Chemie (GR / ACS), Rankem/ J.T. Baker(AR / ACS), Sigma Aldrich(ReagentPlus)
            - HPLC - Merck (LiChrosolv), Loba Chemie (HPLC Grade), Rankem/ J.T. Baker(HPLC), Sigma Aldrich(Gradient Grade)
            - GC - Merck (SupraSolv), Loba Chemie (GC Grade), Rankem/ J.T. Baker(GC), Sigma Aldrich(PESTANAL)
            4. While returning products, select and return makes based on the following priority order according to material_type:
            - For chemicals: prioritize 1. Loba Chemie 2. Merck 3. Rankem
            - For plasticware: prioritize TARSONS
            - For glassware: prioritize 1. Borosil 2. RCC
            - For Instrument: Sartorius
            If multiple valid makes exist, return results in this priority order.
            5. When both "Merck" and "E-Merck" are applicable, always prioritize "Merck" over "E-Merck" and return only "Merck" unless explicitly specified otherwise in the input text.
            Text :
            {attachment_email_body}
        """
        response = model.generate_content(
            prompt,
            generation_config={
                "response_mime_type": "application/json",
                "temperature": 0,
                "top_p": 1,
                "top_k": 1
            }
        )
        json_text = response.text.strip()

        try:
            parsed = json.loads(json_text)
            ai_result = {"status": "Success", "data": parsed}
        except Exception as e:
            ai_result = {"status": "Error", "message": json_text, "error": str(e)}

        logger.log(f"The response generated by Gemini for Product Catalog Details extraction ::: {ai_result}")
        return ai_result
    
    def convert_product_code(self, products):
        for product in products:
            make = (product.get("make") or "").strip().upper()
            item_no = (product.get("item_no") or "").strip()
            pack_size = (product.get("pack_size") or "").strip().lower()
            pack_size = pack_size.replace(" g", " gm")

            if not item_no or item_no.upper() in {"NA", "N/A"}:
                continue

            # ---------------- LOBA ----------------
            if make == "LOBA CHEMIE":
                # convert "x l" → "x ltr" ONLY at end
                pack_size = re.sub(r"\b(\d+(\.\d+)?)\s*l$", r"\1 ltr", pack_size)
                lobo_pack_map = {
                    "100 gm": "00100", "100 ml": "00100",
                    "250 gm": "00250", "250 ml": "00250",
                    "500 gm": "00500", "500 ml": "00500",
                    "1000 gm": "01000", "1 kg": "01000", "1 ltr": "01000", "1000 ml": "01000",
                    "2.5 kg": "02500", "2500 gm": "02500", "2.5 ltr": "02500",
                    "5 kg": "05000", "5000 gm": "05000", "5 ltr": "05000",
                    "10 kg": "0010K", "10 ltr": "0010K",
                    "25 kg": "0025K", "25 ltr": "0025K",
                    "50 kg": "0050K", "50 ltr": "0050K",
                }

                suffix = lobo_pack_map.get(pack_size)

                if suffix and len(item_no) == 5:
                    product["item_no"] = item_no + suffix

            # ---------------- MERCK / E-MERCK ----------------
            elif make in {
                "MERCK", "MERCK KGAA", "MERCK PCS",
                "MERCK BIOMONITORING", "E-MERCK"
            }:
                merck_pack_map = {
                    "100 gm": ("0100", "0121"),
                    "250 gm": ("0250", "0251"),
                    "500 gm": ("0500", "0521"),
                    "500 ml": ("0500", "0521"),
                    "1 kg": ("1000", "1021"),
                    "1 ltr": ("1000", "1021"),
                    "2.5 kg": ("2500", "2521"),
                    "2.5 ltr": ("2500", "2521"),
                    "5 kg": ("5000", "5021"),
                    "5 ltr": ("5000", "5021"),
                    "25 kg": ("9025", "9027"),
                    "25 ltr": ("9025", "9027"),
                }

                if item_no.isdigit() and len(item_no) >= 6:
                    prefix = item_no[0]
                    base_code = item_no[1:6]

                    # Case 1: suffix already present in item_no
                    if len(item_no) > 6:
                        suffix = item_no[6:]
                        product["item_no"] = f"{prefix}.{base_code}.{suffix}"

                    # Case 2: suffix needs to be derived from pack_size
                    else:
                        e_merck_suffix, merck_suffix = merck_pack_map.get(pack_size, (None, None))
                        suffix = merck_suffix if make != "E-MERCK" else e_merck_suffix

                        if suffix:
                            product["item_no"] = f"{prefix}.{base_code}.{suffix}"
                        else:
                            product["item_no"] = f"{prefix}.{base_code}"


            # ---------------- RANKEM ----------------
            elif make == "RANKEM":
                if item_no.startswith("RANK") and "-" not in item_no:
                    product["item_no"] = item_no.replace("RANK", "", 1)
                else:
                    product["item_no"] = item_no

            # ---------------- BOROSIL ----------------
            elif make == "BOROSIL":
                borosil_pack_map = {
                    "50 ml": "012",
                    "100 ml": "016",
                    "250 ml": "021",
                    "500 ml": "024",
                    "1 ltr": "029",
                    "1000 ml": "029",
                    "2 ltr": "030",
                    "2000 ml": "030",
                    "5 ltr": "033",
                    "5000 ml": "033",
                }

                suffix = borosil_pack_map.get(pack_size)
                if suffix and item_no.isdigit():
                    product["item_no"] = f"{item_no}.{suffix}"

            # ---------------- HONEYWELL ----------------
            elif make == "HONEYWELL":
                if pack_size:
                    product["item_no"] = f"{item_no}-{pack_size.replace(' ', '')}"

            # ---------------- SIGMA-ALDRICH ----------------
            elif make == "SIGMA-ALDRICH":
                if pack_size and "-" not in item_no:
                    product["item_no"] = f"{item_no}-{pack_size.replace(' ', '')}"

            # ---------------- DEFAULT ----------------
            else:
                product["item_no"] = item_no

        return products

    def get_valid_item_no(self, products):
        db_connection = sqlite3.connect('database/fetchprice.db')
        cursor = db_connection.cursor()

        for product in products:
            item_no = product.get("item_no", "").strip()
            cas_no = product.get("cas_no", "").strip()
            make = product.get("make", "").strip()
            current_desc = product.get("description", "").strip()

            # Normalize invalid item_no
            if item_no.upper() in {"NA", "N/A", ""}:
                item_no = ""

            
            # Step 1: Validate item_no
            possible_item_codes = []

            if item_no:
                if make in {"J.T. BAKER", "JT BAKER", "J T BAKER"}:
                    # Try both with and without BAKR
                    if item_no.startswith("BAKR"):
                        possible_item_codes.append(item_no)
                        possible_item_codes.append(item_no.replace("BAKR", "", 1))
                    else:
                        possible_item_codes.append(item_no)
                        possible_item_codes.append("BAKR" + item_no)
                else:
                    possible_item_codes.append(item_no)

            found = False

            for code in possible_item_codes:
                validate_query = '''
                    SELECT ITEM_CODE, ITEM_DESCRIPTION
                    FROM ITEM_MASTER_WITH_STOCK
                    WHERE ITEM_CODE = ?
                    LIMIT 1;
                '''
                cursor.execute(validate_query, (code,))
                result = cursor.fetchone()

                if result:
                    db_item_no, db_desc = result[0], result[1].strip()

                    # Update correct values
                    product["item_no"] = db_item_no

                    if not current_desc or current_desc.lower() != db_desc.lower():
                        product["description"] = db_desc

                    found = True
                    break

            if found:
                continue  # valid item found, skip to next product

            # Step 2:If item_no invalid or missing → try make + cas_no
            if cas_no:
                fetch_query = '''
                    SELECT ITEM_CODE, ITEM_DESCRIPTION
                    FROM ITEM_MASTER_WITH_STOCK
                    WHERE MAKE = ?
                    AND ADITIONAL_IDENTIFIER = ?
                    LIMIT 1;
                '''
                cursor.execute(fetch_query, (make, cas_no))
                result = cursor.fetchone()

                if result:
                    product["item_no"] = result[0]
                    product["description"] = result[1]

        cursor.close()
        db_connection.close()

        return products