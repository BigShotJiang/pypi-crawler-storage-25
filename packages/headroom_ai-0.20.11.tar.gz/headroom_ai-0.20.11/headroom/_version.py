"""Package version metadata."""

__version__ = "0.20.11"
