"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.LambdaFunctionStack = void 0;
const path = __importStar(require("path"));
const cdk = __importStar(require("aws-cdk-lib/core"));
const s3 = __importStar(require("aws-cdk-lib/aws-s3"));
const lambda = __importStar(require("aws-cdk-lib/aws-lambda"));
const s3n = __importStar(require("aws-cdk-lib/aws-s3-notifications"));
class LambdaFunctionStack extends cdk.Stack {
    constructor(scope, id, props) {
        super(scope, id, props);
        const inputBucket = new s3.Bucket(this, 'input-bucket');
        const outputBucket = new s3.Bucket(this, 'output-bucket');
        const lambdaFunction = new lambda.Function(this, 'example-lambda-function', {
            runtime: lambda.Runtime.PYTHON_3_13,
            handler: 'lambda_function_example.sum_values_in_file',
            code: lambda.Code.fromAsset(path.join(__dirname, '..', 'src')),
            environment: { OUTPUT_BUCKET: outputBucket.bucketName },
        });
        inputBucket.grantRead(lambdaFunction);
        outputBucket.grantWrite(lambdaFunction);
        inputBucket.addEventNotification(s3.EventType.OBJECT_CREATED, new s3n.LambdaDestination(lambdaFunction));
    }
}
exports.LambdaFunctionStack = LambdaFunctionStack;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGFtYmRhLWZ1bmN0aW9uLXN0YWNrLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsibGFtYmRhLWZ1bmN0aW9uLXN0YWNrLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLDJDQUE2QjtBQUM3QixzREFBd0M7QUFDeEMsdURBQXlDO0FBRXpDLCtEQUFpRDtBQUNqRCxzRUFBd0Q7QUFFeEQsTUFBYSxtQkFBb0IsU0FBUSxHQUFHLENBQUMsS0FBSztJQUM5QyxZQUFZLEtBQWdCLEVBQUUsRUFBVSxFQUFFLEtBQXNCO1FBQzVELEtBQUssQ0FBQyxLQUFLLEVBQUUsRUFBRSxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQ3hCLE1BQU0sV0FBVyxHQUFHLElBQUksRUFBRSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsY0FBYyxDQUFDLENBQUE7UUFDdkQsTUFBTSxZQUFZLEdBQUcsSUFBSSxFQUFFLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSxlQUFlLENBQUMsQ0FBQTtRQUV6RCxNQUFNLGNBQWMsR0FBRyxJQUFJLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLHlCQUF5QixFQUFFO1lBQ3hFLE9BQU8sRUFBRSxNQUFNLENBQUMsT0FBTyxDQUFDLFdBQVc7WUFDbkMsT0FBTyxFQUFFLDRDQUE0QztZQUNyRCxJQUFJLEVBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQzlELFdBQVcsRUFBRSxFQUFDLGFBQWEsRUFBRSxZQUFZLENBQUMsVUFBVSxFQUFDO1NBQ3hELENBQUMsQ0FBQztRQUNILFdBQVcsQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLENBQUM7UUFDdEMsWUFBWSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsQ0FBQztRQUV4QyxXQUFXLENBQUMsb0JBQW9CLENBQzVCLEVBQUUsQ0FBQyxTQUFTLENBQUMsY0FBYyxFQUMzQixJQUFJLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxjQUFjLENBQUMsQ0FDNUMsQ0FBQztJQUNOLENBQUM7Q0FDSjtBQXBCRCxrREFvQkMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgKiBhcyBwYXRoIGZyb20gJ3BhdGgnO1xuaW1wb3J0ICogYXMgY2RrIGZyb20gJ2F3cy1jZGstbGliL2NvcmUnO1xuaW1wb3J0ICogYXMgczMgZnJvbSAnYXdzLWNkay1saWIvYXdzLXMzJztcbmltcG9ydCB7Q29uc3RydWN0fSBmcm9tICdjb25zdHJ1Y3RzJztcbmltcG9ydCAqIGFzIGxhbWJkYSBmcm9tICdhd3MtY2RrLWxpYi9hd3MtbGFtYmRhJztcbmltcG9ydCAqIGFzIHMzbiBmcm9tICdhd3MtY2RrLWxpYi9hd3MtczMtbm90aWZpY2F0aW9ucyc7XG5cbmV4cG9ydCBjbGFzcyBMYW1iZGFGdW5jdGlvblN0YWNrIGV4dGVuZHMgY2RrLlN0YWNrIHtcbiAgICBjb25zdHJ1Y3RvcihzY29wZTogQ29uc3RydWN0LCBpZDogc3RyaW5nLCBwcm9wcz86IGNkay5TdGFja1Byb3BzKSB7XG4gICAgICAgIHN1cGVyKHNjb3BlLCBpZCwgcHJvcHMpO1xuICAgICAgICBjb25zdCBpbnB1dEJ1Y2tldCA9IG5ldyBzMy5CdWNrZXQodGhpcywgJ2lucHV0LWJ1Y2tldCcpXG4gICAgICAgIGNvbnN0IG91dHB1dEJ1Y2tldCA9IG5ldyBzMy5CdWNrZXQodGhpcywgJ291dHB1dC1idWNrZXQnKVxuXG4gICAgICAgIGNvbnN0IGxhbWJkYUZ1bmN0aW9uID0gbmV3IGxhbWJkYS5GdW5jdGlvbih0aGlzLCAnZXhhbXBsZS1sYW1iZGEtZnVuY3Rpb24nLCB7XG4gICAgICAgICAgICBydW50aW1lOiBsYW1iZGEuUnVudGltZS5QWVRIT05fM18xMyxcbiAgICAgICAgICAgIGhhbmRsZXI6ICdsYW1iZGFfZnVuY3Rpb25fZXhhbXBsZS5zdW1fdmFsdWVzX2luX2ZpbGUnLFxuICAgICAgICAgICAgY29kZTogbGFtYmRhLkNvZGUuZnJvbUFzc2V0KHBhdGguam9pbihfX2Rpcm5hbWUsICcuLicsICdzcmMnKSksXG4gICAgICAgICAgICBlbnZpcm9ubWVudDoge09VVFBVVF9CVUNLRVQ6IG91dHB1dEJ1Y2tldC5idWNrZXROYW1lfSxcbiAgICAgICAgfSk7XG4gICAgICAgIGlucHV0QnVja2V0LmdyYW50UmVhZChsYW1iZGFGdW5jdGlvbik7XG4gICAgICAgIG91dHB1dEJ1Y2tldC5ncmFudFdyaXRlKGxhbWJkYUZ1bmN0aW9uKTtcblxuICAgICAgICBpbnB1dEJ1Y2tldC5hZGRFdmVudE5vdGlmaWNhdGlvbihcbiAgICAgICAgICAgIHMzLkV2ZW50VHlwZS5PQkpFQ1RfQ1JFQVRFRCxcbiAgICAgICAgICAgIG5ldyBzM24uTGFtYmRhRGVzdGluYXRpb24obGFtYmRhRnVuY3Rpb24pLFxuICAgICAgICApO1xuICAgIH1cbn1cbiJdfQ==