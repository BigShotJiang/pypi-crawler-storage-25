r"""SWF (Standard Workload Format) parser.

This module implements step 3 of the empirical-validation plan
(`examples/07-structural-fingerprint/README.md`): a parser from the
Standard Workload Format used by the Parallel Workloads Archive
(https://www.cs.huji.ac.il/labs/parallel/workload/) to the v0.1.6
`SchedulingInstance` data model. Once instances exist as Python objects,
`instance_coordinates` (v0.1.6) measures their four-coordinate
structural fingerprint.

## SWF format reference

Each non-comment line in an SWF file is a job record with 18 whitespace-
separated fields (Feitelson, Tsafrir, Krakov, "Experience with using
the Parallel Workloads Archive", 2014):

    1. Job Number              (sequential identifier)
    2. Submit Time             (seconds since UnixStartTime)
    3. Wait Time               (seconds queued)
    4. Run Time                (seconds running)
    5. Number of Allocated Processors
    6. Average CPU Time Used   (per processor)
    7. Used Memory             (per processor, KB)
    8. Requested Number of Processors
    9. Requested Time          (wallclock limit, seconds)
   10. Requested Memory
   11. Status                  (1 completed, 0 failed, 5 cancelled, ...)
   12. User ID
   13. Group ID
   14. Executable Number
   15. Queue Number
   16. Partition Number
   17. Preceding Job Number    (dependency; -1 if none)
   18. Think Time from Preceding Job  (seconds)

Comment lines start with ';' and carry archive metadata (UnixStartTime,
MaxNodes, MaxProcs, MaxJobs, MaxRuntime, MaxQueues, etc.).

## What this module produces

- **`SWFJob`** -- dataclass for one job record.
- **`SWFHeader`** -- dataclass for the archive-level metadata.
- **`SWFWorkload`** -- jobs + header.
- **`parse_swf(path)`** -- file -> SWFWorkload.
- **`parse_swf_string(text)`** -- in-memory text -> SWFWorkload.
- **`instance_from_window(workload, t_start, t_end, machine_partitions)`** --
  extract a SchedulingInstance from jobs submitted in [t_start, t_end].
- **`instance_from_snapshot(workload, t, machine_partitions)`** -- extract
  jobs active (queued or running) at time t.

## Honest scope

- **The encoding is `bipartite-assignment-with-capacity`** -- consistent
  with v0.1.6's `compile_to_holant`. Each extracted job becomes a `Job`;
  the machine pool is either a single Machine with total capacity, or
  partitioned into multiple machines (configurable). Precedence
  constraints from field 17 are recorded in the SchedulingInstance.precedence
  list but not yet compiled to Holant (v0.1.6 documented gap).

- **Job-level fidelity, not full system fidelity.** A real cluster's
  state at time t depends on backfill policies, reservations, priority
  queues -- none of which are present in the SWF trace. The extracted
  instances are a *job-set-plus-machine-pool* abstraction sufficient
  for testing the four-coordinate hypothesis, not a full reconstruction
  of the cluster's exact state.

- **The Parallel Workloads Archive is not bundled** with this package.
  Each archive has its own attribution / use policy. Users download
  the SWF files separately and feed them to this parser.

## Example

    >>> from holant_tools.swf import parse_swf, instance_from_window
    >>> from holant_tools import instance_coordinates
    >>> wl = parse_swf("SDSC-SP2.swf")
    >>> inst = instance_from_window(wl, t_start=0, t_end=3600, machine_partitions=4)
    >>> coords = instance_coordinates(inst)
    >>> coords.max_rank
    2
    >>> coords.product_rank_bound
    16  # = 2^4 for 4 cap-2+ machines
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from .scheduling import Job, Machine, SchedulingInstance


# ---------------------------------------------------------------------------
# SWF data model
# ---------------------------------------------------------------------------


@dataclass
class SWFJob:
    """One SWF job record (18 fields)."""

    job_number: int
    submit_time: int
    wait_time: int
    run_time: int
    allocated_processors: int
    avg_cpu_time: float
    used_memory: int
    requested_processors: int
    requested_time: int
    requested_memory: int
    status: int
    user_id: int
    group_id: int
    executable_number: int
    queue_number: int
    partition_number: int
    preceding_job_number: int
    think_time: int

    @property
    def completion_time(self) -> int:
        """When the job finishes: submit_time + wait_time + run_time."""
        return self.submit_time + self.wait_time + self.run_time

    @property
    def start_time(self) -> int:
        """When the job starts running: submit_time + wait_time."""
        return self.submit_time + self.wait_time

    @property
    def has_dependency(self) -> bool:
        """True iff this job has a recorded preceding dependency."""
        return self.preceding_job_number > 0  # -1 means none

    def is_active_at(self, t: int) -> bool:
        """Is the job submitted but not yet completed at time t?"""
        return self.submit_time <= t < self.completion_time


@dataclass
class SWFHeader:
    """Archive-level metadata from SWF comment lines (`; key: value`)."""

    unix_start_time: Optional[int] = None
    max_nodes: Optional[int] = None
    max_procs: Optional[int] = None
    max_jobs: Optional[int] = None
    max_runtime: Optional[int] = None
    max_queues: Optional[int] = None
    max_partitions: Optional[int] = None
    raw: Dict[str, str] = field(default_factory=dict)
    """All other ; key: value pairs from the header (unparsed)."""


@dataclass
class SWFWorkload:
    """A parsed SWF workload: jobs + header metadata."""

    jobs: List[SWFJob]
    header: SWFHeader = field(default_factory=SWFHeader)
    source: str = ""

    @property
    def num_jobs(self) -> int:
        return len(self.jobs)

    def jobs_submitted_in(self, t_start: int, t_end: int) -> List[SWFJob]:
        """Jobs with t_start <= submit_time < t_end."""
        return [j for j in self.jobs if t_start <= j.submit_time < t_end]

    def jobs_active_at(self, t: int) -> List[SWFJob]:
        """Jobs that have been submitted but not yet completed at time t."""
        return [j for j in self.jobs if j.is_active_at(t)]


# ---------------------------------------------------------------------------
# Parsing
# ---------------------------------------------------------------------------


_HEADER_FIELDS = {
    "UnixStartTime": "unix_start_time",
    "MaxNodes": "max_nodes",
    "MaxProcs": "max_procs",
    "MaxJobs": "max_jobs",
    "MaxRuntime": "max_runtime",
    "MaxQueues": "max_queues",
    "MaxPartitions": "max_partitions",
}


def _parse_header_line(line: str, header: SWFHeader) -> None:
    """Parse a single ; comment line and update the header in place."""
    if not line.startswith(";"):
        return
    line = line.lstrip(";").strip()
    if ":" not in line:
        return
    key, _, value = line.partition(":")
    key = key.strip()
    value = value.strip()
    if key in _HEADER_FIELDS:
        attr = _HEADER_FIELDS[key]
        try:
            setattr(header, attr, int(value))
        except ValueError:
            header.raw[key] = value
    else:
        header.raw[key] = value


def _parse_job_line(line: str) -> Optional[SWFJob]:
    """Parse a single SWF job line. Returns None for empty/comment lines."""
    line = line.strip()
    if not line or line.startswith(";"):
        return None
    fields = line.split()
    if len(fields) < 18:
        raise ValueError(
            f"SWF line has {len(fields)} fields, expected 18: {line!r}"
        )
    return SWFJob(
        job_number=int(fields[0]),
        submit_time=int(fields[1]),
        wait_time=int(fields[2]),
        run_time=int(fields[3]),
        allocated_processors=int(fields[4]),
        avg_cpu_time=float(fields[5]),
        used_memory=int(fields[6]),
        requested_processors=int(fields[7]),
        requested_time=int(fields[8]),
        requested_memory=int(fields[9]),
        status=int(fields[10]),
        user_id=int(fields[11]),
        group_id=int(fields[12]),
        executable_number=int(fields[13]),
        queue_number=int(fields[14]),
        partition_number=int(fields[15]),
        preceding_job_number=int(fields[16]),
        think_time=int(fields[17]),
    )


def parse_swf_string(text: str, source: str = "") -> SWFWorkload:
    """Parse an SWF file from an in-memory string."""
    header = SWFHeader()
    jobs: List[SWFJob] = []
    for line in text.splitlines():
        if line.startswith(";"):
            _parse_header_line(line, header)
            continue
        job = _parse_job_line(line)
        if job is not None:
            jobs.append(job)
    return SWFWorkload(jobs=jobs, header=header, source=source)


def parse_swf(path: str) -> SWFWorkload:
    """Parse an SWF file from disk."""
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        text = f.read()
    return parse_swf_string(text, source=path)


# ---------------------------------------------------------------------------
# Extraction: SWF workload -> SchedulingInstance
# ---------------------------------------------------------------------------
#
# Design. SWF traces show what HAPPENED, not scheduling INSTANCES per se.
# To get an instance suitable for Holant compilation, we pick a job set
# (typically jobs submitted in a time window or active at a specific
# instant) and pair them with a machine pool derived from the archive's
# total capacity (header.max_procs) partitioned into `machine_partitions`
# logical machines.
#
# This gives a bipartite-assignment-with-capacity scheduling instance
# (v0.1.6's compile_to_holant target). It is a job-set + machine-pool
# abstraction, not a full reconstruction of the cluster's exact state.


def _derive_machines(
    workload: SWFWorkload,
    machine_partitions: int,
    total_capacity_override: Optional[int] = None,
) -> List[Machine]:
    """Build a machine pool by partitioning the archive's total capacity.

    Total capacity comes from workload.header.max_procs by default;
    override with `total_capacity_override`. Capacity is split as evenly
    as possible across `machine_partitions` machines; remainder distributed
    to the lowest-indexed machines.
    """
    if total_capacity_override is not None:
        total = total_capacity_override
    elif workload.header.max_procs is not None:
        total = workload.header.max_procs
    else:
        # Fallback: derive from observed max allocation in the trace
        total = max((j.allocated_processors for j in workload.jobs), default=1)
    if machine_partitions < 1:
        raise ValueError(f"machine_partitions must be >= 1, got {machine_partitions}")
    base, extra = divmod(total, machine_partitions)
    capacities = [base + (1 if i < extra else 0) for i in range(machine_partitions)]
    # Filter out cap-0 machines (which would have base=0 and no extra).
    capacities = [c for c in capacities if c > 0]
    return [Machine(name=f"M{i + 1}", capacity=c) for i, c in enumerate(capacities)]


def instance_from_window(
    workload: SWFWorkload,
    t_start: int,
    t_end: int,
    machine_partitions: int = 1,
    total_capacity_override: Optional[int] = None,
    name: Optional[str] = None,
) -> SchedulingInstance:
    """Extract a SchedulingInstance from jobs submitted in [t_start, t_end).

    Each SWF job in the window becomes a `Job` (with processor count =
    requested_processors). The machine pool is derived from
    `workload.header.max_procs` (or the override) partitioned into
    `machine_partitions` machines of approximately equal capacity.
    Preceding-job dependencies (SWF field 17) within the job set are
    recorded in the instance's `precedence` list.

    Args:
        workload: a parsed SWFWorkload.
        t_start: window lower bound (inclusive), seconds since UnixStartTime.
        t_end: window upper bound (exclusive).
        machine_partitions: how many logical Machine objects to create.
        total_capacity_override: ignore the header; use this total.
        name: optional display name for the SchedulingInstance.

    Returns:
        SchedulingInstance.
    """
    swf_jobs = workload.jobs_submitted_in(t_start, t_end)
    job_numbers = {j.job_number for j in swf_jobs}
    jobs = [
        Job(
            name=f"J{j.job_number}",
            processors=max(1, j.requested_processors),
            walltime=j.requested_time if j.requested_time >= 0 else None,
            deadline=None,
        )
        for j in swf_jobs
    ]
    machines = _derive_machines(workload, machine_partitions, total_capacity_override)
    precedence = [
        (f"J{j.preceding_job_number}", f"J{j.job_number}")
        for j in swf_jobs
        if j.has_dependency and j.preceding_job_number in job_numbers
    ]
    inst_name = (
        name
        or f"SWF[{workload.source}] window=[{t_start}, {t_end}) jobs={len(jobs)}"
    )
    return SchedulingInstance(
        jobs=jobs, machines=machines, precedence=precedence, name=inst_name
    )


def instance_from_snapshot(
    workload: SWFWorkload,
    t: int,
    machine_partitions: int = 1,
    total_capacity_override: Optional[int] = None,
    name: Optional[str] = None,
) -> SchedulingInstance:
    """Extract a SchedulingInstance of jobs ACTIVE at time t.

    Active = submitted by t but not yet completed by t. Machine pool
    derivation matches `instance_from_window`.

    Args:
        workload: a parsed SWFWorkload.
        t: snapshot time (seconds since UnixStartTime).
        machine_partitions: number of logical machines in the pool.
        total_capacity_override: ignore the header; use this total.
        name: optional display name.

    Returns:
        SchedulingInstance.
    """
    swf_jobs = workload.jobs_active_at(t)
    job_numbers = {j.job_number for j in swf_jobs}
    jobs = [
        Job(
            name=f"J{j.job_number}",
            processors=max(1, j.requested_processors),
            walltime=j.requested_time if j.requested_time >= 0 else None,
        )
        for j in swf_jobs
    ]
    machines = _derive_machines(workload, machine_partitions, total_capacity_override)
    precedence = [
        (f"J{j.preceding_job_number}", f"J{j.job_number}")
        for j in swf_jobs
        if j.has_dependency and j.preceding_job_number in job_numbers
    ]
    inst_name = (
        name
        or f"SWF[{workload.source}] snapshot=t{t} jobs={len(jobs)}"
    )
    return SchedulingInstance(
        jobs=jobs, machines=machines, precedence=precedence, name=inst_name
    )
