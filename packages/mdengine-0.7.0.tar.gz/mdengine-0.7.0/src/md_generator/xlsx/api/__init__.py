# FastAPI application (optional dependency).
