"""Tests for the FastMCP server — one-per-tool dispatch assertions.

Mirrors the mocking style in ``test_client.py``, but one level higher:
here we mock the ``ForgeClient`` instance directly (not the underlying
``requests.request``) and assert each ``@mcp.tool()`` function delegates
to the right client method with the right args.

If the ``mcp`` Python SDK is not installed (only ``.[dev]`` was used),
this module is skipped cleanly — it is gated behind
``pytest.importorskip("mcp")``.
"""

import asyncio

import pytest
from unittest.mock import MagicMock, patch

pytest.importorskip("mcp")

from dke_forge import mcp as forge_mcp  # noqa: E402


def _run(coro):
    return asyncio.run(coro)


@pytest.fixture
def mock_client():
    client = MagicMock()
    with patch.object(forge_mcp, "_client", client):
        yield client


# -- Foundation ----------------------------------------------------------

class TestFoundation:
    def test_forge_graph_stats(self, mock_client):
        mock_client.graph_stats.return_value = {"nodes": 1, "edges": 0}
        result = _run(forge_mcp.forge_graph_stats())
        mock_client.graph_stats.assert_called_once_with()
        assert result == {"nodes": 1, "edges": 0}


# -- Navigation ----------------------------------------------------------

class TestNavigation:
    def test_forge_query_function(self, mock_client):
        mock_client.graph_function.return_value = {}
        _run(forge_mcp.forge_query_function("foo"))
        mock_client.graph_function.assert_called_once_with("foo", None, None)

    def test_forge_callers_of_default_depth(self, mock_client):
        mock_client.graph_callers.return_value = {}
        _run(forge_mcp.forge_callers_of("foo"))
        mock_client.graph_callers.assert_called_once_with("foo", 2, None, None)

    def test_forge_callers_of_explicit_depth(self, mock_client):
        mock_client.graph_callers.return_value = {}
        _run(forge_mcp.forge_callers_of("foo", depth=5))
        mock_client.graph_callers.assert_called_once_with("foo", 5, None, None)

    def test_forge_callees_of(self, mock_client):
        mock_client.graph_callees.return_value = {}
        _run(forge_mcp.forge_callees_of("foo", depth=3))
        mock_client.graph_callees.assert_called_once_with("foo", 3, None, None)

    def test_forge_depends_on(self, mock_client):
        mock_client.graph_depends.return_value = {}
        _run(forge_mcp.forge_depends_on("src/a.cpp"))
        mock_client.graph_depends.assert_called_once_with("src/a.cpp")

    def test_forge_impact_analysis_default(self, mock_client):
        mock_client.graph_impact.return_value = {}
        _run(forge_mcp.forge_impact_analysis("foo"))
        mock_client.graph_impact.assert_called_once_with("foo", "modify", None, None)

    def test_forge_impact_analysis_rename(self, mock_client):
        mock_client.graph_impact.return_value = {}
        _run(forge_mcp.forge_impact_analysis("foo", change_type="rename"))
        mock_client.graph_impact.assert_called_once_with("foo", "rename", None, None)

    # -- FG-SUBSTRATE-MULTI-DEF-POLICY Slice 4: branch + file qualifiers --

    def test_forge_query_function_with_branch(self, mock_client):
        mock_client.graph_function.return_value = {}
        _run(forge_mcp.forge_query_function("foo", branch="4c373c25a9e2b1f8"))
        mock_client.graph_function.assert_called_once_with(
            "foo", "4c373c25a9e2b1f8", None)

    def test_forge_query_function_with_file_qualifier(self, mock_client):
        mock_client.graph_function.return_value = {}
        _run(forge_mcp.forge_query_function("foo", file="src/foo.c"))
        mock_client.graph_function.assert_called_once_with(
            "foo", None, "src/foo.c")

    def test_forge_callers_of_with_branch(self, mock_client):
        mock_client.graph_callers.return_value = {}
        _run(forge_mcp.forge_callers_of("foo", depth=3, branch="aabbccdd00112233"))
        mock_client.graph_callers.assert_called_once_with(
            "foo", 3, "aabbccdd00112233", None)

    def test_forge_callees_of_with_branch(self, mock_client):
        mock_client.graph_callees.return_value = {}
        _run(forge_mcp.forge_callees_of("foo", branch="aabbccdd00112233"))
        mock_client.graph_callees.assert_called_once_with(
            "foo", 2, "aabbccdd00112233", None)

    def test_forge_impact_analysis_with_branch(self, mock_client):
        mock_client.graph_impact.return_value = {}
        _run(forge_mcp.forge_impact_analysis(
            "foo", change_type="rename", branch="deadbeefcafef00d"))
        mock_client.graph_impact.assert_called_once_with(
            "foo", "rename", "deadbeefcafef00d", None)

    def test_forge_callgraph_reachable_no_via(self, mock_client):
        mock_client.graph_reachable.return_value = []
        _run(forge_mcp.forge_callgraph_reachable("entry"))
        mock_client.graph_reachable.assert_called_once_with("entry", None)

    def test_forge_callgraph_reachable_with_via(self, mock_client):
        mock_client.graph_reachable.return_value = []
        _run(forge_mcp.forge_callgraph_reachable("entry", via="Implements"))
        mock_client.graph_reachable.assert_called_once_with("entry", "Implements")

    def test_forge_find_implementers(self, mock_client):
        mock_client.graph_implementers.return_value = []
        _run(forge_mcp.forge_find_implementers("Base"))
        mock_client.graph_implementers.assert_called_once_with("Base")


# -- Architecture --------------------------------------------------------

class TestArchitecture:
    def test_forge_dead_code_default(self, mock_client):
        mock_client.graph_dead_code.return_value = []
        _run(forge_mcp.forge_dead_code())
        mock_client.graph_dead_code.assert_called_once_with(True)

    def test_forge_dead_code_include_tests(self, mock_client):
        mock_client.graph_dead_code.return_value = []
        _run(forge_mcp.forge_dead_code(exclude_tests=False))
        mock_client.graph_dead_code.assert_called_once_with(False)

    def test_forge_subgraph_module(self, mock_client):
        mock_client.graph_subgraph.return_value = {}
        _run(forge_mcp.forge_subgraph(module="render"))
        mock_client.graph_subgraph.assert_called_once_with(module="render")

    def test_forge_subgraph_functions_list(self, mock_client):
        mock_client.graph_subgraph.return_value = {}
        _run(forge_mcp.forge_subgraph(functions=["a", "b"], max_depth=0))
        mock_client.graph_subgraph.assert_called_once_with(
            functions=["a", "b"], max_depth=0
        )

    def test_forge_subgraph_no_args(self, mock_client):
        mock_client.graph_subgraph.return_value = {}
        _run(forge_mcp.forge_subgraph())
        mock_client.graph_subgraph.assert_called_once_with()


# -- Rules ---------------------------------------------------------------

class TestRules:
    def test_forge_rules(self, mock_client):
        mock_client.graph_rules.return_value = []
        _run(forge_mcp.forge_rules())
        mock_client.graph_rules.assert_called_once_with()

    def test_forge_check_rules(self, mock_client):
        mock_client.graph_check.return_value = []
        _run(forge_mcp.forge_check_rules("foo"))
        mock_client.graph_check.assert_called_once_with("foo")


# -- Provenance ----------------------------------------------------------

class TestProvenance:
    def test_forge_contradictions(self, mock_client):
        mock_client.graph_contradictions.return_value = []
        _run(forge_mcp.forge_contradictions())
        mock_client.graph_contradictions.assert_called_once_with()

    def test_forge_last_modified(self, mock_client):
        mock_client.graph_last_modified.return_value = {}
        _run(forge_mcp.forge_last_modified("foo"))
        mock_client.graph_last_modified.assert_called_once_with("foo")

    def test_forge_provenance_edge(self, mock_client):
        mock_client.graph_provenance.return_value = {}
        _run(forge_mcp.forge_provenance(edge_id=42))
        mock_client.graph_provenance.assert_called_once_with(
            edge_id=42, node_id=None, property=None
        )

    def test_forge_provenance_node_property(self, mock_client):
        mock_client.graph_provenance.return_value = {}
        _run(forge_mcp.forge_provenance(node_id=7, property="signature"))
        mock_client.graph_provenance.assert_called_once_with(
            edge_id=None, node_id=7, property="signature"
        )

    def test_forge_reasoning_trace_cascade(self, mock_client):
        mock_client.graph_reasoning_trace.return_value = {}
        _run(forge_mcp.forge_reasoning_trace(
            "cascade", name="foo", change_type="rename"
        ))
        mock_client.graph_reasoning_trace.assert_called_once_with(
            "cascade", "foo", "rename"
        )

    def test_forge_reasoning_trace_check_all(self, mock_client):
        mock_client.graph_reasoning_trace.return_value = {}
        _run(forge_mcp.forge_reasoning_trace("check_all"))
        mock_client.graph_reasoning_trace.assert_called_once_with(
            "check_all", None, None
        )


# -- Patterns ------------------------------------------------------------

class TestPatterns:
    def test_forge_patterns(self, mock_client):
        mock_client.graph_patterns_similar.return_value = []
        _run(forge_mcp.forge_patterns("foo"))
        mock_client.graph_patterns_similar.assert_called_once_with("foo")

    def test_forge_pattern_catalog(self, mock_client):
        mock_client.graph_patterns.return_value = []
        _run(forge_mcp.forge_pattern_catalog())
        mock_client.graph_patterns.assert_called_once_with()

    def test_forge_pattern_detail_by_id(self, mock_client):
        mock_client.graph_pattern.return_value = {}
        _run(forge_mcp.forge_pattern_detail(pattern_id=3))
        mock_client.graph_pattern.assert_called_once_with(3)
        mock_client.graph_pattern_by_name.assert_not_called()

    def test_forge_pattern_detail_by_name(self, mock_client):
        mock_client.graph_pattern_by_name.return_value = {}
        _run(forge_mcp.forge_pattern_detail(name="visitor"))
        mock_client.graph_pattern_by_name.assert_called_once_with("visitor")
        mock_client.graph_pattern.assert_not_called()

    def test_forge_pattern_detail_neither_raises(self, mock_client):
        with pytest.raises(ValueError):
            _run(forge_mcp.forge_pattern_detail())

    def test_forge_learn_patterns(self, mock_client):
        mock_client.admin_learn_patterns.return_value = {}
        _run(forge_mcp.forge_learn_patterns(
            similarity_threshold=0.8, min_exemplars=3
        ))
        mock_client.admin_learn_patterns.assert_called_once_with(0.8, 3)


# -- Generation-prep -----------------------------------------------------

class TestGenerationPrep:
    def test_forge_envelope(self, mock_client):
        mock_client.envelope.return_value = {}
        _run(forge_mcp.forge_envelope("foo", "add timeout", max_context=50))
        mock_client.envelope.assert_called_once_with("foo", "add timeout", 50)

    def test_forge_envelope_default_max_context(self, mock_client):
        mock_client.envelope.return_value = {}
        _run(forge_mcp.forge_envelope("foo", "task"))
        mock_client.envelope.assert_called_once_with("foo", "task", None)


# -- Ingestion -----------------------------------------------------------

class TestIngestion:
    """FG-DARQ-PHASE-13 sub-D collapsed ``forge_scan`` + ``forge_scan_status``
    + ``forge_ingest`` (3 tools) into ``forge_declare`` (1 tool). The
    new tool POSTs an archive to ``/v1/declare/`` with the unified DARQ
    surface; status polling moves to ``forge_query`` against
    ``/.forge/ops/<op_id>``.
    """

    def test_forge_declare_zip(self, mock_client):
        mock_client.declare_archive.return_value = {
            "status_code": 200, "body": "...rich envelope..."}
        archive = b"PK\x03\x04..."
        _run(forge_mcp.forge_declare(archive, "application/zip", commit="abc"))
        mock_client.declare_archive.assert_called_once_with(
            archive, "application/zip", "abc")

    def test_forge_declare_no_commit(self, mock_client):
        mock_client.declare_archive.return_value = {
            "status_code": 200, "body": "..."}
        archive = b"PK\x03\x04..."
        _run(forge_mcp.forge_declare(archive, "application/zip"))
        mock_client.declare_archive.assert_called_once_with(
            archive, "application/zip", None)

    def test_forge_declare_tar(self, mock_client):
        mock_client.declare_archive.return_value = {
            "status_code": 202, "body": "op_id=42 status_path=..."}
        archive = b"\x00" * 64
        _run(forge_mcp.forge_declare(archive, "application/x-tar"))
        mock_client.declare_archive.assert_called_once_with(
            archive, "application/x-tar", None)


# -- Reasoning (FG-CODE-REASONING-LIBRARY Phase 1 step 7) ----------------

class TestReasoning:
    """``forge_reason_chain`` is the L0.5 chain DSL surface — the
    R7 multi-hop coordinator's MCP entry point. Wraps
    ``ForgeClient.reason_chain``; future siblings under [Reasoning]
    will surface the per-operator phases (Phases 2-8 of the umbrella).
    """

    def test_forge_reason_chain_dispatch(self, mock_client):
        mock_client.reason_chain.return_value = {
            "status_code": 200,
            "body": "200 OK\n\nCHAIN SUMMARY\nlet bindings  : 1\n",
        }
        chain = "let x = reach.from origin\nreturn x\n"
        _run(forge_mcp.forge_reason_chain("src/foo.c/main", chain))
        mock_client.reason_chain.assert_called_once_with(
            "src/foo.c/main", chain)

    def test_forge_reason_chain_passes_through_400(self, mock_client):
        # The 400-with-prose surface is the diagnostic shape the chain
        # endpoint exists for. The MCP wrapper forwards the structured
        # return verbatim — consumers (LLMs reading via stdio) get the
        # formatError prose without an exception unwrap.
        mock_client.reason_chain.return_value = {
            "status_code": 400,
            "body": "400 Bad Request — chain parse error\n\n"
                    "2:8 unknown operator `bogus.op` (not in L0.5 catalog)\n",
        }
        result = _run(forge_mcp.forge_reason_chain(
            "src/foo.c/main", "let x = bogus.op f\nreturn x\n"))
        assert result["status_code"] == 400
        assert "chain parse error" in result["body"]

    def test_forge_reason_chain_multi_let_tuple_return(self, mock_client):
        # Multi-binding tuple return is the canonical Phase-1 example
        # from finding §11.5; pinning the tuple shape flows through
        # the wrapper so a regression in the args plumbing is caught.
        mock_client.reason_chain.return_value = {
            "status_code": 200,
            "body": "CHAIN SUMMARY\nlet bindings  : 2\nreturn        : (a, b)\n",
        }
        chain = ("let a = reach.from start\n"
                 "let b = reach.cone a\n"
                 "return (a, b)\n")
        _run(forge_mcp.forge_reason_chain("src/lib.rs/init", chain))
        mock_client.reason_chain.assert_called_once_with(
            "src/lib.rs/init", chain)

    # -- Phase 1.5 step 6 — change DSL endpoints ---------------------

    def test_forge_audit_changes_dispatch(self, mock_client):
        mock_client.audit_changes.return_value = {
            "status_code": 200,
            "body": ("=== FORGE AUDIT CHANGES ===\n"
                     "1 changes proposed, 1 resolved\n"
                     "CHANGE h1:\n  resolution: pre-add\n  violations: 0\n"),
        }
        body = ('add Function name="HttpHandler" file="app/h.cpp" '
                'as h1\n')
        _run(forge_mcp.forge_audit_changes(body))
        mock_client.audit_changes.assert_called_once_with(body)

    def test_forge_audit_changes_passes_through_400(self, mock_client):
        # Mirror the chain DSL diagnostic surface — 400 with parse-
        # error prose forwards verbatim so the calling LLM reads the
        # `<line>:<col>` formatError text without an exception.
        mock_client.audit_changes.return_value = {
            "status_code": 400,
            "body": ("400 Bad Request — change DSL parse error\n\n"
                     "1:8 unknown kind `Frobozz` (see §12 grammar)\n"),
        }
        result = _run(forge_mcp.forge_audit_changes(
            'add Frobozz name="bogus" file="f.cpp"\n'))
        assert result["status_code"] == 400
        assert "change DSL parse error" in result["body"]

    def test_forge_contradictions_hypothetical_dispatch(self, mock_client):
        mock_client.contradictions_hypothetical.return_value = {
            "status_code": 200,
            "body": ("=== FORGE HYPOTHETICAL CONTRADICTIONS ===\n"
                     "1 changes proposed, 1 resolved\n"
                     "CHANGE c1:\n  resolution: pre-add\n  contradictions: 0\n"),
        }
        body = 'add Function name="X" file="f.cpp" as c1\n'
        _run(forge_mcp.forge_contradictions_hypothetical(body))
        mock_client.contradictions_hypothetical.assert_called_once_with(body)

    def test_forge_contradictions_hypothetical_passes_through_400(
            self, mock_client):
        mock_client.contradictions_hypothetical.return_value = {
            "status_code": 400,
            "body": ("400 Bad Request — change DSL parse error\n\n"
                     "1:1 statement must start with `add`, `remove`, "
                     "or `modify`\n"),
        }
        result = _run(forge_mcp.forge_contradictions_hypothetical(
            "nope nothing useful here\n"))
        assert result["status_code"] == 400
        assert "change DSL parse error" in result["body"]

    # -- Phase 2 — L0.5 reachability + cone operators ----------------

    def test_forge_reach_from_dispatch(self, mock_client):
        mock_client.code_reachability.return_value = {
            "status_code": 200,
            "body": ("/.forge/code/reachability/  seed=Function:main@src/foo.c\n\n"
                     "Function:main@src/foo.c\nFunction:helper@src/foo.c\n"
                     "\nreached_count=2\n"),
        }
        _run(forge_mcp.forge_reach_from("src/foo.c/main"))
        # `via=None` plumbs through to the client method — the client
        # decides whether to forward it as a query-string param. This
        # pin catches a regression where the wrapper accidentally
        # passes a default-string instead of None.
        mock_client.code_reachability.assert_called_once_with(
            "src/foo.c/main", None)

    def test_forge_reach_from_404_passthrough(self, mock_client):
        # The 404-with-did-you-mean prose is the diagnostic surface
        # when the seed isn't found. MCP wrapper forwards verbatim.
        mock_client.code_reachability.return_value = {
            "status_code": 404,
            "body": ("404 Not Found\n\nseed unresolved: src/foo.c/typo\n"
                     "did you mean:\n  src/foo.c/main\n"),
        }
        result = _run(forge_mcp.forge_reach_from("src/foo.c/typo"))
        assert result["status_code"] == 404
        assert "did you mean" in result["body"]

    def test_forge_reach_cone_dispatch_with_change_type(self, mock_client):
        # `change_type` plumbing — pinned because it's the cone-
        # specific knob that mirrors the legacy /v1/graph/impact
        # endpoint; consumers migrating need it routable.
        mock_client.code_cone.return_value = {
            "status_code": 200,
            "body": "directly_affected (count=0):\n",
        }
        _run(forge_mcp.forge_reach_cone(
            "src/foo.c/main", change_type="delete"))
        mock_client.code_cone.assert_called_once_with(
            "src/foo.c/main", "delete")

    def test_forge_reach_cone_default_change_type_modify(self, mock_client):
        mock_client.code_cone.return_value = {
            "status_code": 200,
            "body": "directly_affected (count=0):\n",
        }
        _run(forge_mcp.forge_reach_cone("src/foo.c/main"))
        # Default change_type is `modify` — the wrapper must pass
        # through the default explicitly so the client sees it
        # rather than relying on the client's default chain.
        mock_client.code_cone.assert_called_once_with(
            "src/foo.c/main", "modify")

    def test_forge_use_def_dispatch(self, mock_client):
        # Phase 3 step 6 — flow.use_def dispatch through code_use_def.
        mock_client.code_use_def.return_value = {
            "status_code": 200,
            "body": "/.forge/code/use-def/  ...\n\nreached_count=0\n",
        }
        _run(forge_mcp.forge_use_def("src/foo.c/main"))
        mock_client.code_use_def.assert_called_once_with("src/foo.c/main")

    def test_forge_reaching_defs_dispatch(self, mock_client):
        mock_client.code_reaching_defs.return_value = {
            "status_code": 200,
            "body": "/.forge/code/reaching-defs/  ...\n\nreached_count=0\n",
        }
        _run(forge_mcp.forge_reaching_defs("src/foo.c/main"))
        mock_client.code_reaching_defs.assert_called_once_with(
            "src/foo.c/main")

    def test_forge_live_vars_dispatch(self, mock_client):
        mock_client.code_live_vars.return_value = {
            "status_code": 200,
            "body": "/.forge/code/live-vars/  ...\n\nreached_count=0\n",
        }
        _run(forge_mcp.forge_live_vars("src/foo.c/main"))
        mock_client.code_live_vars.assert_called_once_with("src/foo.c/main")

    def test_forge_effects_dispatch(self, mock_client):
        # Phase 5a — effects dispatch through code_effects (no label arg).
        mock_client.code_effects.return_value = {
            "status_code": 200,
            "body": "/.forge/code/effects/  ...\neffect_set: (empty)\n"
                    "\nreached_count=0\neffect_set_count=0\n",
        }
        _run(forge_mcp.forge_effects("src/handler.c/parse"))
        mock_client.code_effects.assert_called_once_with(
            "src/handler.c/parse")

    def test_forge_taint_dispatch(self, mock_client):
        # Phase 4 — flow.taint dispatch through code_taint with the
        # required label argument.
        mock_client.code_taint.return_value = {
            "status_code": 200,
            "body": "/.forge/code/taint/  seed=c_function:parse  "
                    "label=user_input  ...\n\nreached_count=0\n",
        }
        _run(forge_mcp.forge_taint("src/handler.c/parse", "user_input"))
        mock_client.code_taint.assert_called_once_with(
            "src/handler.c/parse", "user_input")

    def test_forge_classify_effects_dispatch(self, mock_client):
        # Phase 5b — explicit operator-trigger; no args, returns JSON
        # writes_total summary.
        mock_client.classify_effects.return_value = {"writes_total": 7}
        result = _run(forge_mcp.forge_classify_effects())
        mock_client.classify_effects.assert_called_once_with()
        assert result == {"writes_total": 7}

    def test_forge_effects_classification_dispatch(self, mock_client):
        # Phase 5b — per-Function introspection; takes source_name,
        # returns {node_id, name, effects, source}.
        mock_client.effects_classification.return_value = {
            "node_id": 11, "name": "printf", "effects": "io",
            "source": "tenant_declare_or_convention",
        }
        result = _run(forge_mcp.forge_effects_classification("printf"))
        mock_client.effects_classification.assert_called_once_with("printf")
        assert result["effects"] == "io"

    def test_forge_declare_rule_dispatch(self, mock_client):
        # Phase 5c — DECLARE rule + auto-fire classify. Verifies the
        # MCP wrapper passes all 9 rule-body params through to the
        # client method positionally (declare_rule signature order).
        mock_client.declare_rule.return_value = {
            "rule_name": "io_for_mylog", "rule_node_id": 1,
            "op_id": 5, "classify_writes": 1, "status": "declared",
        }
        result = _run(forge_mcp.forge_declare_rule(
            "io_for_mylog", "Function", "mylog", None, ["io"],
            "Derive", "info", "", True))
        mock_client.declare_rule.assert_called_once_with(
            "io_for_mylog", "Function", "mylog", None, ["io"],
            "Derive", "info", "", True)
        assert result["status"] == "declared"

    def test_forge_amend_rule_dispatch(self, mock_client):
        # Phase 5c — AMEND rule + auto-fire classify. Same body shape
        # as declare; updateNode replaces props; classify rebuilds.
        mock_client.amend_rule.return_value = {
            "rule_name": "r1", "rule_node_id": 1, "op_id": 6,
            "classify_writes": 2, "status": "amended",
        }
        result = _run(forge_mcp.forge_amend_rule(
            "r1", "Function", "mylog", None, ["throwing"],
            "Derive", "info", "", True))
        mock_client.amend_rule.assert_called_once_with(
            "r1", "Function", "mylog", None, ["throwing"],
            "Derive", "info", "", True)
        assert result["status"] == "amended"

    def test_forge_retire_rule_dispatch(self, mock_client):
        # Phase 5c — RETIRE rule + auto-fire classify. Empty body; the
        # rule name in the URL is sufficient to identify the target.
        mock_client.retire_rule.return_value = {
            "rule_name": "r1", "op_id": 7,
            "classify_writes": 0, "status": "retired",
        }
        result = _run(forge_mcp.forge_retire_rule("r1"))
        mock_client.retire_rule.assert_called_once_with("r1")
        assert result["status"] == "retired"


class TestMeta:
    def test_forge_health(self, mock_client):
        mock_client.health.return_value = {}
        _run(forge_mcp.forge_health())
        mock_client.health.assert_called_once_with()

    def test_forge_auth_verify(self, mock_client):
        mock_client.auth_verify.return_value = {}
        _run(forge_mcp.forge_auth_verify())
        mock_client.auth_verify.assert_called_once_with()


# -- Config resolution ---------------------------------------------------

class TestConfigResolution:
    def test_env_wins_over_config(self, monkeypatch):
        monkeypatch.setenv("FORGE_URL", "https://env.example")
        monkeypatch.setenv("FORGE_API_KEY", "env-key")
        with patch.object(forge_mcp._config, "load", return_value={
            "url": "https://cfg.example", "api_key": "cfg-key"
        }):
            url, api_key, _graph = forge_mcp._resolve_config()
        assert url == "https://env.example"
        assert api_key == "env-key"

    def test_config_fallback(self, monkeypatch):
        monkeypatch.delenv("FORGE_URL", raising=False)
        monkeypatch.delenv("FORGE_API_KEY", raising=False)
        with patch.object(forge_mcp._config, "load", return_value={
            "url": "https://cfg.example", "api_key": "cfg-key"
        }):
            url, api_key, _graph = forge_mcp._resolve_config()
        assert url == "https://cfg.example"
        assert api_key == "cfg-key"

    def test_default_url_when_all_unset(self, monkeypatch):
        monkeypatch.delenv("FORGE_URL", raising=False)
        monkeypatch.delenv("FORGE_API_KEY", raising=False)
        monkeypatch.delenv("FORGE_GRAPH", raising=False)
        with patch.object(forge_mcp._config, "load", return_value={}):
            url, api_key, graph = forge_mcp._resolve_config()
        from dke_forge.config import DEFAULT_URL
        assert url == DEFAULT_URL
        assert api_key == ""
        assert graph is None

    def test_forge_graph_env_picked_up(self, monkeypatch):
        monkeypatch.setenv("FORGE_GRAPH", "featurex")
        monkeypatch.delenv("FORGE_URL", raising=False)
        monkeypatch.delenv("FORGE_API_KEY", raising=False)
        with patch.object(forge_mcp._config, "load", return_value={}):
            _url, _key, graph = forge_mcp._resolve_config()
        assert graph == "featurex"


# -- Tool registration ---------------------------------------------------

class TestToolRegistration:
    """All tools are present as module-level coroutine functions.

    FG-SUBSTRATE-MULTI-DEF-POLICY L1 finish-cycle + dead-MCP retirement
    (2026-04-24): 9 tools retired alongside the forge-api endpoints they
    called — `forge_semantic_search`, `forge_semantic_neighbors`,
    `forge_embed`, `forge_embed_status`, `forge_generate`,
    `forge_generate_docs`, `forge_write_test`, `forge_extract_method`,
    `forge_naming_suggest`. Per `project_dkeforge_tool_not_tool_user.md`
    forge doesn't call external LLMs; these tools targeted external
    inference (Voyage embed, Anthropic scribe) and are gone. Tool
    surface 54 → 45, categories 13 → 11 (Semantic Search + Generation
    retired).
    """

    EXPECTED_TOOLS = [
        # Foundation
        "forge_graph_stats",
        # Graphs (FG-96 A2 multi-graph)
        "forge_list_graphs", "forge_create_graph", "forge_get_graph",
        "forge_rename_graph", "forge_delete_graph",
        "forge_promote_default_graph",
        # Navigation
        "forge_query_function", "forge_callers_of", "forge_callees_of",
        "forge_depends_on", "forge_impact_analysis",
        "forge_callgraph_reachable", "forge_find_implementers",
        # Architecture (Wave 0 + Wave 1 / FG-30)
        "forge_dead_code", "forge_subgraph",
        "forge_circular_deps", "forge_god_classes", "forge_architecture_map",
        "forge_api_surface", "forge_abstractions",
        "forge_module_topology",
        # Change (Wave 2 / FG-32)
        "forge_refactor_preview", "forge_breaking_change",
        "forge_deprecation_path", "forge_risky_change",
        "forge_commit_impact", "forge_review",
        # Rules
        "forge_rules", "forge_check_rules",
        # Provenance
        "forge_contradictions", "forge_last_modified",
        "forge_provenance", "forge_reasoning_trace",
        # Patterns
        "forge_patterns", "forge_pattern_catalog",
        "forge_pattern_detail", "forge_learn_patterns",
        # Generation-prep
        "forge_envelope",
        # Ingestion (FG-DARQ-PHASE-13 sub-D: forge_scan + forge_scan_status
        # + forge_ingest collapsed to forge_declare, 3 → 1 net -2)
        "forge_declare",
        # Reasoning (FG-CODE-REASONING-LIBRARY)
        # — step 7 (Phase 1): forge_reason_chain
        # — step 6 (Phase 1.5): forge_audit_changes,
        #   forge_contradictions_hypothetical
        # — Phase 2: forge_reach_from, forge_reach_cone
        # — Phase 3 step 6: forge_use_def, forge_reaching_defs,
        #   forge_live_vars (flow.* family)
        # — Phase 4 step 4: forge_taint (label-propagation operator)
        # — Phase 5a step 4: forge_effects (effect-set propagation)
        "forge_reason_chain",
        "forge_audit_changes", "forge_contradictions_hypothetical",
        "forge_reach_from", "forge_reach_cone",
        "forge_use_def", "forge_reaching_defs", "forge_live_vars",
        "forge_taint",
        "forge_effects",
        "forge_classify_effects", "forge_effects_classification",
        # Meta
        "forge_health", "forge_auth_verify",
        # Invitations (FG-API-INVITATION-RESEND + FG-API-INVITATION-PREVIEW)
        "forge_invitation_resend", "forge_invitation_preview",
    ]

    def test_count(self):
        # 54 → 45 after retiring the 9 tools that called deleted
        # forge-api endpoints (Voyage + Anthropic + Scribe stack).
        # 45 → 47 with the FG-API-INVITATION-{RESEND,PREVIEW} L2
        # follow-on (new Invitations category).
        # 47 → 45 with the FG-DARQ-PHASE-13 sub-D Ingestion collapse.
        # 45 → 46 with FG-CODE-REASONING-LIBRARY Phase 1 step 7
        # (forge_reason_chain under new Reasoning category).
        # 46 → 48 with FG-CODE-REASONING-LIBRARY Phase 1.5 step 6
        # (forge_audit_changes + forge_contradictions_hypothetical
        # under existing Reasoning category — categories held).
        # 48 → 50 with FG-CODE-REASONING-LIBRARY Phase 2 (forge_reach_from
        # + forge_reach_cone under existing Reasoning category — drift
        # repaired at step 4 close: the prior assertion stayed at 48
        # despite the catalog reaching 50 in 0.17.0).
        # 50 → 49 at FG-CODE-REASONING-LIBRARY Phase 3 step 4 — legacy
        # forge_data_flow Architecture-Suite tool retired in favor of
        # multi-edge `?via=` reachability + the `flow.*` family.
        # 49 → 52 at FG-CODE-REASONING-LIBRARY Phase 3 step 6 — flow.*
        # L2 wrap: forge_use_def + forge_reaching_defs + forge_live_vars
        # added under existing Reasoning category (Reasoning 5 → 8).
        # 52 → 53 at FG-CODE-REASONING-LIBRARY Phase 4 step 4 — taint
        # L2 wrap: forge_taint added under existing Reasoning category
        # (Reasoning 8 → 9).
        # 53 → 54 at FG-CODE-REASONING-LIBRARY Phase 5a step 4 — effects
        # L2 wrap: forge_effects added under existing Reasoning category
        # (Reasoning 9 → 10).
        # 54 → 56 at FG-CODE-REASONING-LIBRARY Phase 5b step 4 —
        # classify-effects + effects-classification L2 wrap: explicit
        # operator-trigger + per-Function introspection added under
        # existing Reasoning category (Reasoning 10 → 12).
        # Phase 1.5 step 7 close: banner-audit reconciled long-standing
        # -2 miscount (Meta orphaned since 822c059a, Invitations
        # malformed since beba2664). Source-truth-canonical category
        # count is 14, see finding §12.12.
        assert len(self.EXPECTED_TOOLS) == 56

    def test_all_present_as_coroutines(self):
        for name in self.EXPECTED_TOOLS:
            fn = getattr(forge_mcp, name, None)
            assert fn is not None, f"tool missing: {name}"
            assert asyncio.iscoroutinefunction(fn), (
                f"tool not async: {name}"
            )


# -- Architecture Suite (FG-30 Phase 1.2.D) -----------------------------


class TestArchitectureSuite:
    def test_forge_circular_deps_defaults(self, mock_client):
        mock_client.analysis_circular_deps.return_value = {"cycles": []}
        _run(forge_mcp.forge_circular_deps())
        mock_client.analysis_circular_deps.assert_called_once_with(
            None, None, None,
        )

    def test_forge_circular_deps_all_params(self, mock_client):
        mock_client.analysis_circular_deps.return_value = {"cycles": []}
        _run(forge_mcp.forge_circular_deps(
            scope="module", max_cycles=10, max_length=50,
        ))
        mock_client.analysis_circular_deps.assert_called_once_with(
            "module", 10, 50,
        )

    def test_forge_god_classes_default(self, mock_client):
        mock_client.analysis_god_classes.return_value = {"entries": []}
        _run(forge_mcp.forge_god_classes())
        mock_client.analysis_god_classes.assert_called_once_with(None)

    def test_forge_god_classes_threshold(self, mock_client):
        mock_client.analysis_god_classes.return_value = {"entries": []}
        _run(forge_mcp.forge_god_classes(threshold=30))
        mock_client.analysis_god_classes.assert_called_once_with(30)

    def test_forge_architecture_map_all_params(self, mock_client):
        mock_client.analysis_architecture_map.return_value = {"top_nodes": []}
        _run(forge_mcp.forge_architecture_map(
            top_n=100, damping=0.85, max_iterations=50, tolerance=1e-6,
        ))
        mock_client.analysis_architecture_map.assert_called_once_with(
            100, 0.85, 50, 1e-6,
        )

    def test_forge_api_surface_by_id(self, mock_client):
        mock_client.analysis_api_surface.return_value = {"public_symbols": []}
        _run(forge_mcp.forge_api_surface(module_id=42))
        mock_client.analysis_api_surface.assert_called_once_with(42, None)

    def test_forge_api_surface_by_name(self, mock_client):
        mock_client.analysis_api_surface.return_value = {"public_symbols": []}
        _run(forge_mcp.forge_api_surface(module_name="render"))
        mock_client.analysis_api_surface.assert_called_once_with(None, "render")

    def test_forge_abstractions_min_group_size(self, mock_client):
        mock_client.analysis_abstractions.return_value = {"groups": []}
        _run(forge_mcp.forge_abstractions(min_group_size=4))
        mock_client.analysis_abstractions.assert_called_once_with(4)

    def test_forge_module_topology(self, mock_client):
        mock_client.analysis_module_topology.return_value = {
            "modules": [], "deps": [],
        }
        _run(forge_mcp.forge_module_topology())
        mock_client.analysis_module_topology.assert_called_once_with()


# -- Change Suite (FG-32 Phase 2.1.C) -----------------------------------


class TestChangeSuite:
    def test_forge_refactor_preview_required_only(self, mock_client):
        mock_client.change_refactor_preview.return_value = {"found": True}
        _run(forge_mcp.forge_refactor_preview("old", "new"))
        mock_client.change_refactor_preview.assert_called_once_with(
            "old", "new", None,
        )

    def test_forge_refactor_preview_with_kind(self, mock_client):
        mock_client.change_refactor_preview.return_value = {}
        _run(forge_mcp.forge_refactor_preview("Foo", "Bar", kind="Type"))
        mock_client.change_refactor_preview.assert_called_once_with(
            "Foo", "Bar", "Type",
        )

    def test_forge_breaking_change(self, mock_client):
        mock_client.change_breaking_change.return_value = {"found": True}
        _run(forge_mcp.forge_breaking_change(
            "f", "int", ["const std::string&", "std::size_t"],
        ))
        mock_client.change_breaking_change.assert_called_once_with(
            "f", "int", ["const std::string&", "std::size_t"],
        )

    def test_forge_deprecation_path_defaults(self, mock_client):
        mock_client.change_deprecation_path.return_value = {}
        _run(forge_mcp.forge_deprecation_path("OldApi"))
        mock_client.change_deprecation_path.assert_called_once_with(
            "OldApi", None, None,
        )

    def test_forge_deprecation_path_all_params(self, mock_client):
        mock_client.change_deprecation_path.return_value = {}
        _run(forge_mcp.forge_deprecation_path(
            "OldApi", kind="Function", max_depth=50,
        ))
        mock_client.change_deprecation_path.assert_called_once_with(
            "OldApi", "Function", 50,
        )

    def test_forge_risky_change(self, mock_client):
        mock_client.change_risky.return_value = {"score": 0.0}
        _run(forge_mcp.forge_risky_change("abc123"))
        mock_client.change_risky.assert_called_once_with("abc123")

    def test_forge_commit_impact(self, mock_client):
        mock_client.change_commit_impact.return_value = {"touched_count": 0}
        _run(forge_mcp.forge_commit_impact("abc123"))
        mock_client.change_commit_impact.assert_called_once_with("abc123")

    def test_forge_review_commit_only(self, mock_client):
        mock_client.change_review.return_value = {"risk_score": 0.0}
        _run(forge_mcp.forge_review("abc123"))
        mock_client.change_review.assert_called_once_with("abc123", None)

    def test_forge_review_with_focus_area_top_n(self, mock_client):
        mock_client.change_review.return_value = {}
        _run(forge_mcp.forge_review("abc123", focus_area_top_n=10))
        mock_client.change_review.assert_called_once_with("abc123", 10)


# -- Semantic Search (FG-29 Phase 1.1.C) --------------------------------


class TestGraphs:
    def test_forge_list_graphs(self, mock_client):
        mock_client.list_graphs.return_value = {"graphs": [],
                                                 "default_graph_id": ""}
        _run(forge_mcp.forge_list_graphs())
        mock_client.list_graphs.assert_called_once_with()

    def test_forge_create_graph(self, mock_client):
        mock_client.create_graph.return_value = {"id": "g1",
                                                   "slug": "a", "name": "A"}
        _run(forge_mcp.forge_create_graph("a", "A"))
        mock_client.create_graph.assert_called_once_with("a", "A")

    def test_forge_get_graph(self, mock_client):
        mock_client.get_graph.return_value = {"id": "g1"}
        _run(forge_mcp.forge_get_graph("g1"))
        mock_client.get_graph.assert_called_once_with("g1")

    def test_forge_rename_graph_slug_only(self, mock_client):
        mock_client.rename_graph.return_value = {"id": "g1"}
        _run(forge_mcp.forge_rename_graph("g1", slug="new"))
        mock_client.rename_graph.assert_called_once_with("g1", "new", None)

    def test_forge_delete_graph_with_reassign(self, mock_client):
        mock_client.delete_graph.return_value = {"deleted": True}
        _run(forge_mcp.forge_delete_graph("g1",
                                            reassign_default_to="g2"))
        mock_client.delete_graph.assert_called_once_with("g1", "g2")

    def test_forge_promote_default_graph(self, mock_client):
        mock_client.promote_default_graph.return_value = {
            "default_graph_id": "g1"}
        _run(forge_mcp.forge_promote_default_graph("g1"))
        mock_client.promote_default_graph.assert_called_once_with("g1")


# FG-API-INVITATION-{RESEND,PREVIEW} L2 follow-on — workspace
# invitation lifecycle. Mocked-client pattern same as TestGraphs;
# verifies the MCP wrapper dispatches to the right ForgeClient
# method with the right args.
class TestInvitations:
    def test_forge_invitation_resend(self, mock_client):
        mock_client.invitation_resend.return_value = {
            "token": "abc", "email_sent": True,
            "accept_url": "https://dke-forge.com/accept-invitation.html?token=abc",
        }
        _run(forge_mcp.forge_invitation_resend("abc"))
        mock_client.invitation_resend.assert_called_once_with("abc")

    def test_forge_invitation_preview(self, mock_client):
        mock_client.invitation_preview.return_value = {
            "workspace_name": "Acme",
            "invitee_email": "alice@example.com",
            "role": "contributor",
            "state": "pending",
            "expires_at": 1234567890,
        }
        result = _run(forge_mcp.forge_invitation_preview("abc"))
        mock_client.invitation_preview.assert_called_once_with("abc")
        # MCP layer is a pure adapter — passes the dict through unchanged.
        assert result["state"] == "pending"
        assert result["workspace_name"] == "Acme"
