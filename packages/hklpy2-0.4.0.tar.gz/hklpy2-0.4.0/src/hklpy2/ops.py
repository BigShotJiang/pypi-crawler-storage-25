"""
Operate the diffractometer using a |solver| library and geometry.

Intermediate layer between DiffractometerBase Device and backend |solver|
library.

.. autosummary::

    ~Core
"""

import datetime
import logging
from collections.abc import Iterable
from typing import TYPE_CHECKING
from typing import Mapping
from typing import Optional
from typing import Union

from .backends.base import SolverBase
from .typing import ConfigHeaderDict
from .blocks.configure import Configuration
from .blocks.constraints import RealAxisConstraints
from .blocks.lattice import Lattice
from .blocks.reflection import Reflection
from .blocks.sample import Sample
from .misc import CoreError
from .misc import NoForwardSolutions
from .misc import axes_to_dict
from .misc import convert_units
from .misc import solver_factory
from .misc import unique_name
from .typing import AnyAxesType
from .typing import AxesDict
from .typing import KeyValueMap
from .typing import Matrix3x3
from .typing import NamedFloatDict

__all__ = ["Core"]

if TYPE_CHECKING:
    from .diffract import DiffractometerBase

logger = logging.getLogger(__name__)
DEFAULT_EXTRA_VALUE: float = 0
DEFAULT_SAMPLE_NAME: str = "sample"


class Core:
    """
    Core operations of a diffractometer, coordinating with sample & |solver|.

    PARAMETERS

    diffractometer (DiffractometerBase):
        The diffractometer parent.
    default_sample (bool):
        If 'True' (default), create a 'sample' with 1 angstrom cubic lattice.

    .. rubric:: Python Methods

    .. autosummary::

        ~_asdict
        ~_fromdict
        ~_validate_pseudos
        ~add_reflection
        ~add_sample
        ~assign_axes
        ~calc_UB
        ~forward
        ~geometries
        ~inverse
        ~local_pseudo_axes
        ~local_real_axes
        ~refine_lattice
        ~remove_sample
        ~request_solver_update
        ~reset_constraints
        ~reset_samples
        ~set_solver
        ~standardize_pseudos
        ~standardize_reals
        ~update_solver

    .. rubric:: Python Properties

    .. autosummary::

        ~all_extras
        ~constant_axis_names
        ~extras
        ~geometry
        ~mode
        ~modes
        ~presets
        ~sample
        ~solver
        ~solver_extra_axis_names
        ~solver_name
        ~solver_pseudo_axis_names
        ~solver_real_axis_names
        ~solver_signature
        ~solver_summary
    """

    from .blocks.sample import Sample

    def __init__(
        self,
        diffractometer: "DiffractometerBase",
        default_sample: bool = True,
    ) -> None:
        self.axes_xref = {}  # cross-reference:  diffractometer name : solver name
        self.diffractometer = diffractometer
        self._extras = {}  # Dictionary of any extra solver axis (across all modes).
        self._mode = None
        self._mode_presets = {}  # Dictionary of presets per mode: {mode_name: {axis: value}}
        self._sample_name = None
        self._samples = {}
        self._solver = None
        self.constraints = None
        self.configuration = None
        self.request_solver_update()

        if default_sample:
            # first sample is cubic, no reflections
            self.add_sample(DEFAULT_SAMPLE_NAME, 1)

    def _asdict(self) -> KeyValueMap:
        """Describe the diffractometer as a dictionary."""
        from .__init__ import __version__

        header: ConfigHeaderDict = {
            "datetime": str(datetime.datetime.now()),
            "hklpy2_version": __version__,
            "python_class": self.diffractometer.__class__.__name__,
        }
        config = {
            "_header": header,
            "name": self.diffractometer.name,
            "axes": {
                "pseudo_axes": self.diffractometer.pseudo_axis_names,
                "real_axes": self.diffractometer.real_axis_names,
                "axes_xref": self.axes_xref,
                "extra_axes": self.all_extras,
            },
            "digits": self.diffractometer.digits,
            "sample_name": self.sample.name,
            "samples": {k: v._asdict() for k, v in self._samples.items()},
            "constraints": self.constraints._asdict(),
            "solver": self.solver._metadata,
            "beam": self.diffractometer.beam._asdict(),
            "presets": self._mode_presets,
        }

        return config

    def _axes_names_s2d(self, axis_dict: NamedFloatDict) -> NamedFloatDict:
        """Convert keys of axis dictionary from solver to diffractometer."""
        reverse = self.axes_xref_reversed
        return {reverse[k]: v for k, v in axis_dict.items()}

    def _axes_names_d2s(self, axis_dict: NamedFloatDict) -> NamedFloatDict:
        """Convert keys of axis dictionary from diffractometer to solver."""
        return {self.axes_xref[k]: v for k, v in axis_dict.items()}

    def _fromdict(self, config: KeyValueMap) -> None:
        """Redefine diffractometer from a (configuration) dictionary."""
        # Since this code might raise, validate first.
        extras = self._validate_extras(config["axes"]["extra_axes"], self.all_extras)
        if len(extras) > 0:
            self._extras.update(extras)

        digits = config.get("digits")
        if isinstance(digits, int) and 0 <= digits:
            self.diffractometer.digits = digits

        # Fix #243: YAML serialises reals dict keys alphabetically.  Reorder
        # each reflection's reals by key using the saved config's real_axes
        # (physical order, saved local names) and axes_xref (local→solver),
        # so values reach the correct axes regardless of YAML key ordering.
        saved_real_axes = config.get("axes", {}).get("real_axes") or []
        saved_axes_xref = config.get("axes", {}).get("axes_xref") or {}
        if saved_real_axes and saved_axes_xref:
            for sample in config["samples"].values():
                for refl in sample.get("reflections", {}).values():
                    saved = refl["reals"]
                    refl["reals"] = {
                        saved_axes_xref[local]: saved[local]
                        for local in saved_real_axes
                        if local in saved_axes_xref and local in saved
                    }

        for key, sample in config["samples"].items():
            sample_object = self.add_sample(key, 1, replace=True)
            sample_object._fromdict(sample, core=self)
        sname = config.get("sample_name")
        if sname is not None:
            self.sample = sname

        for key, constraint in config["constraints"].items():
            if (
                constraint["class"] == "LimitsConstraint"
                # .
                and constraint["label"] in config["axes"]["real_axes"]
            ):
                # By convention, the 'key' here is the axis name when config was written.
                axis_canonical = config["axes"]["axes_xref"][key]
                axis_local = self.axes_xref_reversed[axis_canonical]
                constraint["label"] = axis_local
        self.constraints._fromdict(config["constraints"], core=self)

        presets = config.get("presets", {})
        for mode, mode_presets in presets.items():
            if mode in self.modes:
                self._mode_presets[mode] = {
                    str(k): float(v) for k, v in mode_presets.items()
                }

    def _validate_extras(
        self,
        values: NamedFloatDict,
        expected: NamedFloatDict,
    ) -> NamedFloatDict:
        """Validate that the supplied extras are acceptable."""
        extras, unexpected = {}, []
        for key, value in values.items():
            if key in expected:
                extras[key] = value
            else:
                unexpected.append(key)
        if len(unexpected) > 0:
            raise KeyError(
                f"Unexpected extra axis name(s) {unexpected!r}."
                # ..
                f"  Expected names: {expected}."
            )
        return extras

    def _validate_pseudos(self, pseudos: Union[Iterable, NamedFloatDict]) -> bool:
        """Validate that the supplied pseudos are acceptable."""
        if not isinstance(pseudos, Iterable):
            raise TypeError(
                "Pseudos must be tuple, list, or dict."
                # Always show the input.
                f"  Received {pseudos!r}"
            )
        if not isinstance(pseudos, (dict, list, set, tuple)):
            raise TypeError(f"Unexpected data type: {pseudos}")

        expected_names = self.local_pseudo_axes
        if len(pseudos) != len(expected_names):
            raise ValueError(
                f"Expected {len(expected_names)} pseudos,"
                # Always show the input.
                f" received {pseudos}"
            )

        original = pseudos  # Keep the original for reporting.
        if hasattr(pseudos, "_asdict"):
            pseudos = pseudos._asdict()
        if isinstance(pseudos, (list, set, tuple)):
            # Expect values are provided in canonical order.
            pseudos = {
                axis: value
                # rewrite as dictionary
                for axis, value in zip(expected_names, pseudos)
            }
        for axis in expected_names:
            if axis not in pseudos:
                raise ValueError(f"Wrong axis names: received {original}")
            if not isinstance(pseudos[axis], (float, int)):
                raise TypeError(f"Must be number, received {original}")

        return True

    def add_reflection(
        self,
        pseudos: AnyAxesType,
        reals: Union[AnyAxesType, None] = None,
        wavelength: Optional[float] = None,
        wavelength_units: Optional[str] = None,
        name: Optional[str] = None,
        replace: bool = False,
    ) -> Reflection:
        """
        Add a new reflection.

        PARAMETERS

        pseudos various:
            Pseudo-space axes and values.
        reals various:
            Dictionary of real-space axes and values.
        wavelength float:
            Wavelength of incident radiation. The created Reflection will
            use ``wavelength_units`` from the optional parameter below; if
            that is ``None``, the diffractometer's current
            ``beam.wavelength_units`` is used. When preparing data for the
            solver, Core converts each reflection's wavelength into the
            solver's internal units (``INTERNAL_LENGTH_UNITS``).
        wavelength_units str or None:
            Units for the ``wavelength`` value (e.g. "angstrom"). If
            provided, this overrides the diffractometer beam units for the
            new Reflection; otherwise the beam units are used. The
            Reflection stores this string and Core will convert values for
            solver consumption.
        name str:
            Reference name for this reflection.  If ``None``, a random name will
            be assigned.
        replace bool:
            When ``True``, replace existing reflection of this name.
            (default: ``False``)
        """
        from .blocks.reflection import Reflection

        self._validate_pseudos(pseudos)
        wavelength = wavelength or self.diffractometer.beam.wavelength.get()

        logger.debug(
            "name=%r, geometry=%r, wavelength=%r",
            name,
            self.geometry,
            wavelength,
        )

        pnames = self.local_pseudo_axes
        rnames = self.local_real_axes
        pdict = self.standardize_pseudos(pseudos)
        rdict = self.standardize_reals(reals)
        logger.debug(
            "pdict=%r, rdict=%r, pnames=%r, rnames=%r",
            pdict,
            rdict,
            pnames,
            rnames,
        )
        # Thread the current beam wavelength units into the new Reflection
        # prefer an explicit wavelength_units argument; otherwise use beam units
        wl_units = (
            wavelength_units
            if wavelength_units is not None
            else self.diffractometer.beam.wavelength_units.get()
        )
        refl = Reflection(
            name or unique_name(),
            pdict,
            rdict,
            wavelength,
            self.geometry,
            pnames,
            rnames,
            wavelength_units=wl_units,
        )
        self.sample.reflections.add(refl, replace=replace)
        return refl

    def add_sample(
        self,
        name: str,
        a: float,
        b: Optional[float] = None,
        c: Optional[float] = None,
        alpha: float = 90.0,  # degrees
        beta: Optional[float] = None,  # degrees
        gamma: Optional[float] = None,  # degrees
        digits: int = 4,
        replace: bool = False,
    ) -> Sample:
        """Add a new sample."""
        if name in self.samples:
            if not replace:
                raise CoreError(f"Sample {name=!r} already defined.")
        lattice = Lattice(a, b, c, alpha, beta, gamma, digits=digits)
        self._samples[name] = Sample(self, name, lattice)
        self.sample = name
        self.request_solver_update(True)  # 58  test_diffract line 410: 2 pi a
        if self.solver is not None:
            self.solver.sample = self.to_solver_units()["sample"]
        return self.sample

    @property
    def all_extras(self) -> list[str]:
        """Sorted dictionary of |solver| extra parameters in any mode."""
        return self._extras

    def assign_axes(self, pseudos: list[str], reals: list[str]) -> None:
        """
        Designate attributes for use by the PseudoPositioner class.

        Result is re-definition of 'self.axes_xref'.
        """
        pseudos = pseudos or []
        reals = reals or []

        def itemize(label, select, full):
            keys = [name for name, _obj in full]
            for attr in select:
                if attr not in keys:
                    raise KeyError(f"Unknown {label}={attr!r}.  Known: {keys!r}")
            return keys

        def rebuild_axes_xref(dnames, snames):
            for dname, sname in zip(dnames, snames):
                self.axes_xref[dname] = sname
                both_p_r.remove(dname)

        # check for duplicates
        if len(set(pseudos + reals)) != len(pseudos + reals):
            raise ValueError("Axis name cannot be in more than list.")

        if self.solver is None:
            return  # such as initialization

        dfrct = self.diffractometer
        all_pseudos = itemize("pseudo", pseudos, dfrct._get_pseudo_positioners())
        all_reals = itemize("real", reals, dfrct._get_real_positioners())
        both_p_r = all_pseudos + all_reals

        self.axes_xref = {}
        rebuild_axes_xref(pseudos, self.solver.pseudo_axis_names)
        rebuild_axes_xref(reals, self.solver.real_axis_names)
        self.reset_constraints()
        logger.debug("axes_xref=%r", self.axes_xref)
        self.configuration = Configuration(self.diffractometer)

    @property
    def axes_xref_reversed(self) -> Mapping[str, str]:
        """Map axis names from solver to diffractometer."""
        if len(self.axes_xref) == 0:
            if self.solver is not None:
                names = self.solver.pseudo_axis_names + self.solver.real_axis_names
                if len(names) == 0:
                    return {}
            raise CoreError("Did you forget to call `assign_axes()`?")
        return {v: k for k, v in self.axes_xref.items()}

    def calc_UB(
        self, r1: Union[Reflection, str], r2: Union[Reflection, str]
    ) -> Matrix3x3:
        """
        Calculate and return the UB (orientation) matrix with two reflections.

        The method of Busing & Levy, Acta Cryst 22 (1967) 457.
        """

        def _get(r: Union[Reflection, str]) -> Reflection:
            """Given a reference, get the Reflection object."""
            if isinstance(r, Reflection):
                return r
            reflection = self.sample.reflections.get(r)
            if reflection is None:
                raise KeyError(
                    f"{reflection!r} unknown."
                    # .
                    f"  Knowns: {list(self.sample.reflections)!r}"
                )
            return reflection

        two_reflections = [_get(r1), _get(r2)]
        self.sample.reflections.set_orientation_reflections(two_reflections)

        # Ensure the solver has the current lattice before computing UB (#240).
        self.update_solver()

        solver_reflections = self._reflections_to_solver(two_reflections)
        ub = self.solver.calculate_UB(*solver_reflections)
        self.sample.U = self.solver.U
        self.sample.UB = ub
        self.request_solver_update(False)
        return ub

    @property
    def extras(self) -> list[str]:
        """Ordered dictionary of |solver| extra parameters in current mode."""
        every = self.all_extras
        current = {axis: every[axis] for axis in self.solver_extra_axis_names}
        return current

    @extras.setter
    def extras(self, values: NamedFloatDict) -> None:
        """Set |solver| extra parameters for the current mode."""
        incoming = self._validate_extras(values, self.extras)
        if len(incoming) > 0:
            self._extras.update(incoming)
            self.request_solver_update(True)

    def forward(self, pseudos: AnyAxesType, wavelength: Optional[float] = None) -> list:
        """Compute [{names:reals}] from {names: pseudos} (hkl -> angles)."""
        logger.debug(
            "(%s) forward(): pseudos=%r",
            self.__class__.__name__,
            pseudos,
        )

        pdict = self.standardize_pseudos(pseudos)
        base_reals = self.diffractometer.real_position._asdict()  # Original values.

        self.update_solver(wavelength=wavelength)

        # Filter just the solutions that fit the constraints.
        solutions = []
        try:
            # Unit conversions for presets and new values.
            angle_units_solver = self.solver.ANGLE_UNITS
            angle_units_core = self.diffractometer.reals_units

            # Get the constant (read-only) axis names for this mode.
            constant_axes = self.solver_constant_axis_names

            # Get presets for current mode.
            mode_presets = self.presets

            # Build the presets dict:
            # - For constant axes: use preset value if set, otherwise use current motor position
            # - For written axes: always use current motor position
            solver_reals = {}
            for axis in self.solver.real_axis_names:
                local_axis = self.axes_xref_reversed[axis]
                if axis in constant_axes:
                    if local_axis in mode_presets:
                        solver_reals[axis] = convert_units(
                            mode_presets[local_axis],
                            angle_units_core,
                            angle_units_solver,
                        )
                    else:
                        solver_reals[axis] = convert_units(
                            base_reals[local_axis],
                            angle_units_core,
                            angle_units_solver,
                        )
                else:
                    solver_reals[axis] = convert_units(
                        base_reals[local_axis],
                        angle_units_core,
                        angle_units_solver,
                    )

            self.solver.set_reals(solver_reals)
            for solution in self.solver.forward(self._axes_names_d2s(pdict)):
                reals = base_reals.copy()  # Fresh copy per solution.
                new_reals = self._axes_names_s2d(solution)
                for axis, value in new_reals.items():
                    # Update with converted new value.
                    reals[axis] = convert_units(
                        value,
                        angle_units_solver,
                        angle_units_core,
                    )
                if self.constraints.valid(**reals):
                    solutions.append(self.diffractometer.RealPosition(**reals))
                else:
                    # Log which constraint(s) rejected this solution.
                    for name, constraint in self.constraints.items():
                        if not constraint.valid(**reals):
                            logger.info(
                                "Solution discarded: %s=%.4f"
                                " outside limits [%.4f, %.4f]."
                                "  pseudos=%r",
                                name,
                                reals[name],
                                constraint.low_limit,
                                constraint.high_limit,
                                pdict,
                            )
        except NoForwardSolutions as exc:
            logger.info(
                "No forward solutions from solver for pseudos=%r: %s",
                pdict,
                exc,
            )

        return solutions

    def geometries(self) -> list[str]:
        """Return all available |solver| geometries."""
        # Not a @property since it's a classmethod of a Solver.
        return self.solver.geometries()

    @property
    def geometry(self) -> str:
        """Return the |solver| geometry."""
        return self.solver.geometry

    def inverse(
        self,
        reals: Union[AnyAxesType, None],
        wavelength: Optional[float] = None,
    ) -> AxesDict:
        """Compute (pseudos) from {names: reals} (angles -> hkl)."""
        logger.debug(
            "(%s) inverse(): reals=%r",
            self.__class__.__name__,
            reals,
        )
        pseudos: AxesDict = {
            axis[0]: 0
            # Original values.
            for axis in self.diffractometer._get_pseudo_positioners()
        }
        if self.solver is None or len(self.axes_xref) == 0:
            # Called from the constructor before solver is defined.
            return pseudos  # current values of pseudos

        # Just the reals expected by the solver.
        # Dictionary in order expected by the solver.
        reals: AxesDict = self.standardize_reals(reals)
        for axis, value in reals.items():
            angle_units_uc = self.diffractometer.reals_units
            angle_units_solver = self.solver.ANGLE_UNITS
            reals[axis] = convert_units(value, angle_units_uc, angle_units_solver)

        self.update_solver(wavelength=wavelength)

        # transform: reals -> pseudos
        spdict: AxesDict = self.solver.inverse(self._axes_names_d2s(reals))

        pseudos.update(self._axes_names_s2d(spdict))  # Update with new values.
        return pseudos

    @property
    def local_pseudo_axes(self) -> list[str]:
        """
        List of the diffractometer pseudo axes expected by the solver.

        This becomes useful when additional pseudo axes are named
        as ophyd Components in the diffractometer.
        """
        if self.solver is None:
            return []
        return [
            self.axes_xref_reversed[k]
            #
            for k in self.solver.pseudo_axis_names
        ]

    @property
    def local_real_axes(self) -> list[str]:
        """
        List of the diffractometer real axes expected by the solver.

        This becomes useful when additional real axes are named
        as ophyd Components in the diffractometer.
        """
        if self.solver is None:
            return []
        return [
            self.axes_xref_reversed[k]
            #
            for k in self.solver.real_axis_names
        ]

    @property
    def mode(self) -> str:
        """Return the current computation mode."""
        if self._mode is None:
            self._mode = self.solver.mode
            self.request_solver_update(True)
        return self._mode

    @mode.setter
    def mode(self, value: str) -> None:
        """Set the computation mode to be used."""
        if value in self.modes:
            self._mode = value
            self.request_solver_update(True)

    @property
    def modes(self) -> list[str]:
        """Return the list of available |solver| modes."""
        return self.solver.modes

    @property
    def presets(self) -> NamedFloatDict:
        """
        Preset values for constant-axis modes.

        When using a mode that holds one or more axes at constant values (such
        as ``constant_phi``), these preset values override the current
        diffractometer motor positions when computing ``forward()`` solutions.

        NOTE: Presets affect **computed solutions** from ``forward()``. They
        do **not** move any motor.

        The presets are stored per-mode: changing the mode switches to that
        mode's saved presets. Presets default to an empty dictionary ``{}``
        for each mode. Presets only contain axes that are read-only (constant)
        in the current mode.

        The getter returns the **live mutable dictionary** for the current
        mode. To remove a single preset key, call
        ``diffractometer.core.presets.pop("phi")``.

        Returns a dictionary of axis name:value pairs for the current mode.

        EXAMPLE::

            >>> diffractometer.core.mode = "constant_phi"
            >>> diffractometer.core.presets = {"phi": 45.0}  # Set phi preset
            >>> diffractometer.core.presets
            {'phi': 45.0}

            >>> # Remove a single preset entry
            >>> diffractometer.core.presets.pop("phi")
            45.0
            >>> diffractometer.core.presets
            {}

            >>> # Each mode stores its own preset dict
            >>> diffractometer.core.presets = {"phi": 45.0}
            >>> diffractometer.core.mode = "constant_omega"
            >>> diffractometer.core.presets = {"omega": 30.0}

            >>> # Switch back — phi preset is restored
            >>> diffractometer.core.mode = "constant_phi"
            >>> diffractometer.core.presets
            {'phi': 45.0}
        """
        mode = self.mode
        if mode not in self._mode_presets:
            self._mode_presets[mode] = {}
        return self._mode_presets[mode]

    @presets.setter
    def presets(self, values: AnyAxesType) -> None:
        """
        Set (replace) preset values for the current mode.

        The preset dictionary for the current mode is **replaced** by the
        supplied values. Only axes that are read-only (constant) in the
        current mode will be stored; values for computed axes are silently
        ignored.

        .. note::

            Setting a preset does **not** move any motor. The preset only
            specifies the value the solver will assume for that axis when
            computing ``forward()`` solutions. Use this to compute hkl
            positions without moving motors to the constant-axis position.

        PARAMETERS

        values various:
            Dictionary of axis name:value pairs to use as presets when
            computing ``forward()`` solutions in the current mode.
            Only axes that are read-only (constant) in the current mode
            should be provided; other values will be ignored.
            Can also be a list, tuple, or namedtuple in the order of
            ``local_real_axes``.

        EXAMPLE::

            >>> diffractometer.core.mode = "constant_phi"

            >>> # Motor is at phi=10, but we want to compute for phi=45
            >>> diffractometer.core.presets = {"phi": 45.0}
            >>> # forward() now uses phi=45, not the motor position phi=10

            >>> # Assignment replaces — not merges — the preset dict
            >>> diffractometer.core.presets = {"phi": 90.0}
            >>> diffractometer.core.presets
            {'phi': 90.0}

            >>> # To remove one preset key:
            >>> diffractometer.core.presets.pop("phi")
            90.0
            >>> diffractometer.core.presets
            {}

            >>> # To clear all presets for the current mode:
            >>> diffractometer.core.presets = {}
        """
        mode = self.mode
        constant_axes = self.constant_axis_names
        new_presets: dict = {}

        if isinstance(values, dict):
            for axis, value in values.items():
                if axis in constant_axes:
                    new_presets[axis] = float(value)
        else:
            standardized = self.standardize_reals(values)
            for axis, value in standardized.items():
                if axis in constant_axes:
                    new_presets[axis] = float(value)

        self._mode_presets[mode] = new_presets

    @property
    def constant_axis_names(self) -> list[str]:
        """
        List of axis names (diffractometer names) that are held constant
        in the current mode.

        These are the axes that will use preset values (or current motor
        positions if no presets are set) when computing ``forward()``
        solutions.

        EXAMPLE::

            >>> diffractometer.core.mode = "constant_phi"
            >>> diffractometer.core.constant_axis_names
            ['phi']
            >>> diffractometer.core.mode = "bissector"
            >>> diffractometer.core.constant_axis_names
            []
        """
        constant_solver_names = self.solver_constant_axis_names
        return [self.axes_xref_reversed[k] for k in constant_solver_names]

    def refine_lattice(self, *reflections: list[Reflection]) -> Lattice:
        """
        Return the sample lattice computed from 3 or more reflections.

        Do not change the sample lattice.  Let the user decide that.
        """
        if len(reflections) == 0:
            reflections = list(self.sample.reflections.values())
        rnames = [r.name for r in reflections]
        if len(reflections) < 3:
            raise CoreError(
                # fmt: off
                "Must have at least 3 reflections to refine lattice."
                f" Known reflections: {rnames}"
                # fmt: on
            )

        logger.debug("Refining lattice using reflections %r", rnames)
        lattice = self.solver.refineLattice(self._reflections_to_solver(reflections))

        # apply unit conversions solver to lattice after refineLattice
        angle_units_solver = self.solver.ANGLE_UNITS
        angle_units_uc = self.sample.lattice.angle_units
        length_units_solver = self.solver.LENGTH_UNITS
        length_units_uc = self.sample.lattice.length_units
        for parm, value in lattice.items():
            if parm in "a b c".split():
                lattice[parm] = convert_units(
                    value, length_units_solver, length_units_uc
                )
            elif parm in "alpha beta gamma".split():
                lattice[parm] = convert_units(
                    value,
                    angle_units_solver,
                    angle_units_uc,
                )

        return Lattice(**lattice)

    def _reflections_to_solver(self, refl_list: list) -> dict:
        """(internal) Convert list of reflections to dict for solver.

        Each :class:`~hklpy2.blocks.reflection.Reflection` carries its
        own units for real axis angles and wavelength.  Convert these to
        the solver's internal units.
        """
        k = "wavelength"
        wl_units_solver = self.solver.LENGTH_UNITS
        reflections = []
        for refl in refl_list:
            if isinstance(refl, str):
                refl = self.sample.reflections[refl]
            refl = refl._asdict()

            angle_units_uc = self.diffractometer.reals_units
            angle_units_solver = self.solver.ANGLE_UNITS
            reals = {
                axis: convert_units(
                    refl["reals"][self.axes_xref_reversed[axis]],
                    angle_units_uc,
                    angle_units_solver,
                )
                for axis in self.solver.real_axis_names
            }
            refl["reals"] = reals

            # determine the original wavelength_units from reflection or incident beam
            refl_wl_units = (
                refl.get("wavelength_units")
                or self.diffractometer.beam.wavelength_units.get()
            )
            refl[k] = convert_units(refl[k], refl_wl_units, wl_units_solver)

            reflections.append(refl)
        return reflections

    def remove_sample(self, name: str):
        """Remove the named sample.  No error if name is not known."""
        if name not in self.samples:
            raise KeyError(f"{name!r} not in sample list:{list(self.samples)}.")
        if len(self.samples) == 1:
            raise CoreError("Cannot remove last sample.")

        self._samples.pop(name)
        self._sample_name = list(self.samples)[0]

    def request_solver_update(self, flag: bool = True) -> None:
        """
        Set (or clear) signal to trigger a solver update.

        Needs to be a method (not a property) so it can be called from a
        wavelength method.
        """
        self._solver_needs_update = flag

    def reset_constraints(self) -> None:
        """Restore diffractometer constraints to default settings."""
        self.constraints = RealAxisConstraints(self.diffractometer.real_axis_names)

    def reset_samples(self) -> None:
        """Restore diffractometer samples to default settings."""
        self._samples = {}  # Remove all the samples.
        # Create the default sample.
        self.add_sample(DEFAULT_SAMPLE_NAME, 1)

    @property
    def sample(self) -> Sample:
        """Current Sample (Python object)."""
        return self.samples[self._sample_name]

    @sample.setter
    def sample(self, value: str) -> None:
        self._sample_name = value
        if self.solver is not None:
            try:
                self.solver.U = self.sample.U
                self.solver.UB = self.sample.UB
            except AttributeError:
                pass  # property is not settable

    @property
    def samples(self) -> Mapping[str, Sample]:
        """Sample dictionary."""
        return self._samples

    @property
    def solver(self) -> SolverBase:
        """Backend |solver| object."""
        return self._solver

    @property
    def solver_extra_axis_names(self) -> list[str]:
        """Ordered list of any |solver| extra axis names in current mode."""
        self.update_solver()
        return self.solver.extra_axis_names

    @property
    def solver_name(self) -> str:
        """Name of |solver|."""
        return self.solver.name

    @property
    def solver_pseudo_axis_names(self) -> list[str]:
        """Ordered list of |solver| pseudo axis names."""
        self.update_solver()
        return self.solver.pseudo_axis_names

    @property
    def solver_real_axis_names(self) -> list[str]:
        """Ordered list of |solver| real axis names."""
        self.update_solver()
        return self.solver.real_axis_names

    @property
    def solver_constant_axis_names(self) -> list[str]:
        """
        Ordered list of |solver| real axis names that are constant in the current mode.

        These are axes that are read (not written) by the solver in the current
        mode. They will use preset values (or current motor positions if no
        presets are set) when computing ``forward()`` solutions.

        Constant axes are computed as: all real axis names - written axis names.
        """
        self.update_solver()
        all_axes = set(self.solver.real_axis_names)
        written_axes = set(self.solver_written_axis_names)
        constant_axes = list(all_axes - written_axes)
        constant_axes.sort(key=self.solver.real_axis_names.index)
        return constant_axes

    @property
    def solver_written_axis_names(self) -> list[str]:
        """
        Ordered list of |solver| real axis names that are solved in the current mode.

        These are axes that are written (computed) by the solver in the current
        mode.
        """
        self.update_solver()
        if hasattr(self.solver, "axes_w"):
            return self.solver.axes_w
        return self.solver.real_axis_names

    @property
    def solver_signature(self) -> str:
        """Return 'repr(self.solver)' for use as ophyd.AttributeSignal."""
        return repr(self.solver)

    @property
    def solver_summary(self) -> str:
        """Return table of solver's geometry (modes, axes).."""
        return self.solver.summary

    def set_solver(
        self,
        name: str,
        geometry: str,
        **kwargs: dict,
    ) -> SolverBase:
        """
        Create an instance of the backend |solver| library and geometry.

        PARAMETERS

        solver str:
            Name of the |solver| library.
        geometry str:
            Name of the |solver| geometry.
        kwargs dict:
            Any keyword arguments needed by the |solver|.
        """
        logger.debug(
            "(%s) solver=%r, geometry=%r, kwargs=%r",
            self.__class__.__name__,
            name,
            geometry,
            kwargs,
        )
        self._solver = solver_factory(name, geometry, **kwargs)
        self._extras = {
            k: DEFAULT_EXTRA_VALUE
            #
            for k in self.solver.all_extra_axis_names
        }
        self.update_solver()
        return self._solver

    def standardize_pseudos(self, pseudos: AnyAxesType) -> AxesDict:
        """
        Convert user-supplied pseudos into dictionary in solver's order.

        User could provide pseudos in several forms:

        * dict: {"h": 0, "k": 1, "l": -1}
        * namedtuple: (h=0.0, k=1.0, l=-1.0)
        * numpy array: numpy.array([0, 1, -1])
        * ordered list: [0, 1, -1]  (for h, k, l)
        * ordered tuple: (0, 1, -1)  (for h, k, l)

        .. note::

            This method operates at the **solver / Core layer** and returns an
            ordered :obj:`~hklpy2.typing.AxesDict` keyed by solver axis names.
            It is complementary to — not a replacement for — the ophyd
            ``@pseudo_position_argument`` decorator used on
            :meth:`~hklpy2.diffract.Diffractometer.forward`.  That decorator
            normalises flexible user input into an ophyd ``PseudoPosition``
            namedtuple at the *diffractometer* layer; this method converts any
            of those forms (plus numpy arrays) into the ``AxesDict`` that the
            solver expects.
        """
        return axes_to_dict(pseudos, self.local_pseudo_axes)

    def standardize_reals(self, reals: Union[AnyAxesType, None]) -> AxesDict:
        """
        Convert user-supplied reals into dictionary in solver's order.

        User could provide reals in several forms:

        * None: current positions (read from the diffractometer)
        * dict: {"omega": 120, "chi": 35.3, "phi": 45, "tth": -120}
        * namedtuple: (omega=120, chi=35.3, phi=45, tth=-120)
        * numpy array: numpy.array([120, 35.3, 45, -120])
        * ordered list: [120, 35.3, 45, -120]  (for omega, chi, phi, tth)
        * ordered tuple: (120, 35.3, 45, -120)  (for omega, chi, phi, tth)

        .. note::

            This method operates at the **solver / Core layer** and returns an
            ordered :obj:`~hklpy2.typing.AxesDict` keyed by solver axis names.
            It is complementary to — not a replacement for — the ophyd
            ``@real_position_argument`` decorator used on
            :meth:`~hklpy2.diffract.Diffractometer.inverse` and
            :meth:`~hklpy2.diffract.Diffractometer.move_reals`.  That decorator
            normalises flexible user input into an ophyd ``RealPosition``
            namedtuple at the *diffractometer* layer; this method converts any
            of those forms (plus ``None`` and numpy arrays) into the
            ``AxesDict`` that the solver expects.
        """

        if reals is None:  # write ordered dict
            reals = {
                k: getattr(self.diffractometer, k).position
                # Get from current diffractometer axis positions
                for k in self.local_real_axes
            }

        return axes_to_dict(reals, self.local_real_axes)

    def to_solver_units(self, wavelength: Optional[float] = None) -> dict:
        """Convert quantities from diffractometer units to solver units."""
        lattice = self.sample.lattice._asdict()

        angle_units_uc = lattice["angle_units"]
        angle_units_solver = self.solver.ANGLE_UNITS
        length_units_uc = lattice["length_units"]
        length_units_solver = self.solver.LENGTH_UNITS
        for k in "a b c  alpha beta gamma".split():
            if k in "a b c".split():
                lattice[k] = convert_units(
                    lattice[k], length_units_uc, length_units_solver
                )
            else:
                lattice[k] = convert_units(
                    lattice[k], angle_units_uc, angle_units_solver
                )

        reflections = self._reflections_to_solver(self.sample.reflections)
        wavelength = wavelength or self.diffractometer.beam.wavelength.get()

        wl_units = self.diffractometer.beam.wavelength_units.get()
        wl_units_solver = self.solver.LENGTH_UNITS
        return dict(
            sample=dict(
                name=self.sample.name,
                lattice=lattice,
                order=self.sample.reflections.order,
                reflections=reflections,
            ),
            wavelength=convert_units(wavelength, wl_units, wl_units_solver),
        )

    def update_solver(self, wavelength: Optional[float] = None) -> None:
        """Update solver data if needed."""
        if self.solver.mode != self.mode or wavelength is not None:
            self.request_solver_update(True)  # force the update

        if self._solver_needs_update:
            std = self.to_solver_units(wavelength)

            self.solver.wavelength = std["wavelength"]
            self.solver.sample = std["sample"]
            self.solver.mode = self.mode

            try:
                self.solver.extras = {
                    axis: self._extras[axis]
                    # multiline
                    for axis in self.solver.extra_axis_names
                }
            except AttributeError:
                pass  # Some solvers have no setter for extras

            try:
                self.solver.U = self.sample.U
                self.solver.UB = self.sample.UB
            except AttributeError:
                pass  # Some solvers have no setter for U & UB

            self.request_solver_update(False)
