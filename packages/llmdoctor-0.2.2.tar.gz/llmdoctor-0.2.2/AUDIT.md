# llmdoctor — Self-Audit (v0.1.0)

**Goal:** before shipping a measurement tool to the public, confirm that the
tool itself does not lie, crash, or get exploited by hostile input. A
measurement tool with a known bug is worse than no tool — once trust is gone,
it does not come back.

**Audit scope:** the [`llmdoctor`](src/llmdoctor/) package — specifically
[`scanner.py`](src/llmdoctor/scanner.py),
[`report.py`](src/llmdoctor/report.py), and the three checkers in
[`checkers/`](src/llmdoctor/checkers/).

**Audit method:** four passes — checker correctness, input safety, reporter
safety, and security. For each issue found we added a regression test in
[`tests/test_edge_cases.py`](tests/test_edge_cases.py) **before** fixing,
so silent regressions are not possible.

**Audit result:** 23/23 tests passing. Five concrete issues fixed, eight
limitations documented but unfixed (with rationale). Three more risk areas
flagged as future work.

---

## 1. Checker correctness audit

### Method
Built [`tests/fixtures/edge_cases.py`](tests/fixtures/edge_cases.py)
that exercises every weird AST shape we could think of, then asserted **zero
issues** must fire. Any check that flags here has a false positive on a
pattern we explicitly said is fine.

### Cases covered
- `await client.messages.create(...)` — async calls. ✅ caught (the inner Call node is visited).
- `client.messages.create(**config)` — `**kwargs` unpacking. ✅ no false positive (we cannot see inside `config`, so we silently do nothing).
- `model = "opus" if x else "haiku"` — dynamic model selection. ✅ no TS020 (we bail out when `model` is not a Constant string).
- `(msg := "hi")` — walrus inside a call. ✅ no crash.
- `A = B = "x"` — multi-target assignment. ✅ skipped (with intentional false negative — see §5).
- `LONG: str = "x" * 100` — annotated assignment with BinOp. ✅ resolves correctly to a length of 100.
- `LONG = "x" * N; LONG += "more"` — augmented assignment. ✅ skipped (with intentional false negative — see §5).
- Empty `system=[]`. ✅ no crash.
- Bound-method assignment `m = client.messages.create; m(...)`. ✅ no crash, but **not detected** (documented limitation).
- Mock client `fake_client.messages.create(...)`. ✅ scanned (we cannot tell it is a mock — false positives possible but currently none).
- Nested calls inside a Call's args (`int("256")`). ✅ no infinite recursion, no spurious detection.

### Issues found
- **TS002 was a false-positive trap.** Earlier draft fired on the *correct*
  canonical pattern (single static system block with `cache_control`,
  dynamic content in messages). **Fix:** rule dropped from 0.1.0. The
  genuine "wasted cache write" case requires execution-trace data; that
  belongs in a runtime SDK, not static analysis. Documented in the
  checker module-level docstring.
- **Module-level `Name` resolution missed `"x" * N` patterns.** Previous
  version of `_string_literal_length` only handled `Constant` and pure
  `JoinedStr`. **Fix:** added `BinOp(Mult)` handler in
  [`anthropic_cache.py`](src/llmdoctor/checkers/anthropic_cache.py)
  and a one-pass module-scope assignment collector that maps `Name` → length.

---

## 2. Input safety audit

### Method
Wrote five fixture-style tmp_path tests in
[`test_edge_cases.py`](tests/test_edge_cases.py) covering the
file types we will hit on the first day someone runs the doctor against a
non-trivial repo.

### Cases covered
| Input | Before | After |
|---|---|---|
| Empty file | OK (0 issues) | OK |
| Syntax-error file | OK (0 issues) | OK |
| Non-UTF-8 bytes (latin-1) | OK (UnicodeDecodeError caught) | OK |
| **UTF-8 BOM-prefixed file** (Notepad on Windows) | **Crashed** with parse error | **Fixed** — switched `read_text` to `encoding="utf-8-sig"`. Tested by writing a BOM-prefixed file with a real TS010-eligible call; the issue now fires correctly. |
| **6 MB generated `.py` file** | OOM-risk; very slow `ast.parse` | **Fixed** — files larger than 5 MB are silently skipped. Threshold configurable via `LLMDOCTOR_MAX_FILE_BYTES`. |
| Binary content with `.py` extension | Decoded as garbage, parser errored, but NOT caught | **Fixed** — `_parse_safely` now catches `ValueError` too (some binary content makes `ast.parse` raise ValueError, not SyntaxError). |
| **200-deep BinOp chain** | Could hit `RecursionError` on the visitor walk | **Fixed** — bumped `sys.setrecursionlimit(5000)` if currently lower; checker walks wrap individual checkers in try/except so one bad file doesn't take down the run. |
| Symlink loops | Already safe — `os.walk(followlinks=False)` is the default. Made it explicit. | OK |
| Files inside `.venv/`, `__pycache__/`, `node_modules/` | Already skipped by name. | OK |

### Issues found and fixed
1. **BOM crash** — see above. Real bug, would have shipped to anyone using Windows Notepad.
2. **5 MB cap** — see above. A 100k-LOC repo with one big generated file would have stalled the doctor for tens of seconds.
3. **`ValueError` from `ast.parse`** on certain binary content was not caught alongside `SyntaxError`. Fixed.
4. **Visitor `RecursionError`** on minified Python (one-line files with deep BinOps) was unhandled. Fixed two ways: bump limit + per-checker try/except so partial results still come through.

---

## 3. Reporter safety audit

### Method
Wrote a test that creates a directory whose name contains rich-markup
characters (`[red]name[reset]`), drops a Python file inside, and runs the
full pretty-render pipeline. The test asserts the renderer must not raise.

### Issues found
- **Rich-markup injection via file paths and code snippets.** `Table.add_row`
  with a plain `str` would, depending on rich's version and config, run the
  string through `Text.from_markup`. A filename containing `[red]` could in
  principle change downstream styling. **Fix:** every user-controlled string
  (`issue.file`, `issue.snippet`) is now wrapped in `Text(...)` explicitly,
  which never interprets markup. Author-controlled strings (titles,
  explanations, fix hints) are still passed as plain strings since we control
  their contents.
- **Long snippets blowing up the panel.** A multi-line snippet from a
  particularly deep AST node could produce a 5KB string and break the panel
  layout. **Fix:** truncated to 400 chars with an ellipsis.
- **JSON output validity.** `Severity` is a `str`-Enum, `Path` is converted
  via `str()` upstream. Verified by `json.loads` round-trip in
  [`test_cli.py`](tests/test_cli.py).

### What is still at risk in the reporter
- **Windows console encoding.** When the user pipes pretty output through
  `Select-Object` in PowerShell, rich's UTF-8 box-drawing characters get
  mangled by the legacy CP1252 codepage. This is a Windows console
  limitation, not a tool bug — but we should detect a non-UTF-8 stdout and
  either emit ASCII fallbacks or hint the user to set `PYTHONIOENCODING=utf-8`.
  Filed as future work.

---

## 4. Security audit

| Threat | Mitigation status |
|---|---|
| **Code execution from input** | None possible. We use `ast.parse`, never `eval`/`exec`/`compile(... 'exec')`. |
| **Path traversal from CLI argument** | Not relevant — the doctor reads files the user explicitly points it at; it does not serve untrusted clients. |
| **Symlink loops** | `os.walk(..., followlinks=False)`. Cycle-safe. |
| **Resource exhaustion (zip-bomb-style)** | File-size cap at 5 MB. Recursion limit bumped but bounded. Per-checker try/except prevents one runaway file from killing the whole scan. |
| **Markup injection in TTY output** | All user-controlled strings wrapped in `Text(...)`. |
| **Network exfiltration** | None — the tool makes zero network calls. Verified manually. No `requests`, `httpx`, `urllib`, `socket` imports. |
| **Telemetry / phone-home** | None. The tool never reports usage anywhere. This is a hard requirement for OSS releases — adding telemetry would break the trust contract. |
| **Reading files outside the scan root** | We only open files that `iter_python_files` yields, all under the user-provided root. |

---

## 5. Documented limitations (intentional false negatives)

These are bugs we *could* catch but chose not to in 0.1.0. Each has a clear
upgrade path; none silently lies to the user.

| # | Limitation | Why we did not fix |
|---|---|---|
| L1 | Bound-method assignment: `m = client.messages.create; m(...)` not detected. | Requires intra-procedural data-flow analysis. Unusual in practice. Cost > benefit for v0.1. |
| L2 | Multi-target assignment `A = B = "long"` not resolved by name collector. | Would resolve, but corner case. Documented; PR-welcome. |
| L3 | Augmented assignment `LONG += "more"` not tracked. | Same. Edge case. |
| L4 | Conditional model: `model = "opus" if x else "haiku"` — TS020 not flagged. | Could partially evaluate IfExp branches, but would create false-positive pressure. Conservative default: bail. |
| L5 | `client.messages.create` shadowed by a mock in tests does get scanned. | We cannot tell it is a mock. False positives possible if mocks have realistic-looking models — none observed yet, will reconsider after community feedback. |
| L6 | Indirect calls through wrappers (`my_chat(...)`-helpers around the SDK) not detected. | Requires full call-graph analysis. Future work. |
| L7 | LangChain / LlamaIndex / LiteLLM / direct-HTTP usage not detected. | Different patterns — `ChatAnthropic(...).invoke(...)`. Adapter checkers planned for 0.2. |
| L8 | TypeScript / JavaScript codebases not supported. | Out of scope for 0.1.0. Most LLM agents in 2026 are JS. Top of the v0.2 list. |

---

## 6. Future-work risks not yet addressed

**Risk A — Pricing table goes stale.**
[`pricing.py`](src/llmdoctor/pricing.py) is hand-maintained.
Provider prices change. We need a CI job that fetches the latest pages
quarterly and opens a PR if numbers drift. Until that exists, every cost
estimate has an implicit "as of 2026-04-30" caveat — mentioned in the
pricing.py header but not surfaced in the report.

**Risk B — Cost estimate calibration.**
Our heuristics assume "100 calls/day, 30-day month, 3000-token system
prompt" as defaults. These come from observation of typical SaaS LLM
workloads but they could be wrong for any individual user by 10×. The
report prints assumptions inline, but a `--traffic-profile path/to.yaml`
override would let users plug in their actual numbers and get real
estimates. Planned for 0.2.

**Risk C — No provenance for the rules.**
Rule explanations describe real-world bug classes anonymously. If we
later add citations to specific upstream issues, we should version them
in a docs-source-of-truth JSON keyed by rule ID and add a CI link-check
job so explanation prose can't silently rot.

---

## 7. Test inventory (23 tests, all passing as of v0.1.0)

```
tests/
├── test_anthropic_cache.py    3 tests   TS001/TS003 correctness
├── test_cli.py                4 tests   CLI surface (pretty, json, --fail-on, clean path)
├── test_edge_cases.py        13 tests   ALL hardening above
├── test_max_tokens.py         2 tests   TS010/TS011 correctness
└── test_model_choice.py       1 test    TS020 correctness
```

Run locally:
```bash
pip install -e ".[dev]"
pytest -v
```

---

## 8. What this audit deliberately did NOT cover

- **Performance benchmarks.** No formal scan-throughput target. On the
  fixture files the scanner runs in ~50 ms; on small reference repos
  in <1 s. Sufficient for 0.1.0; we will revisit when someone reports
  slowness.
- **Multi-language scanning.** Python only. JS/TS scanning is its own audit
  when we ship the TS adapter.
- **Real-world false-positive rate.** That is the *next* audit — running
  the doctor against popular public Python LLM repos and triaging every
  finding. Will be published as findings emerge.
