"""llmdoctor CLI entry point.

Subcommands:
    doctor <path>    Scan a path for cost-leak patterns. Default subcommand.
"""

from __future__ import annotations

import sys
from pathlib import Path

import click

from llmdoctor import __version__
from llmdoctor.report import render_json, render_pretty
from llmdoctor.scanner import iter_python_files, scan_path
from llmdoctor.issues import Severity


@click.group(invoke_without_command=True)
@click.version_option(__version__, prog_name="llmdoctor")
@click.pass_context
def main(ctx: click.Context) -> None:
    """llmdoctor — find LLM cost leaks before your bill does."""
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@main.command()
@click.argument("path", type=click.Path(exists=True, path_type=Path), default=".")
@click.option("--json", "as_json", is_flag=True, help="Emit JSON instead of pretty output.")
@click.option(
    "--fail-on",
    type=click.Choice([s.value for s in Severity], case_sensitive=False),
    default=None,
    help="Exit with non-zero code if any issue >= this severity is found. Useful in CI.",
)
def doctor(path: Path, as_json: bool, fail_on: str | None) -> None:
    """Scan PATH (file or directory) for LLM cost-leak patterns."""
    files = list(iter_python_files(path))
    issues = scan_path(path)

    if as_json:
        click.echo(render_json(issues))
    else:
        render_pretty(issues, scanned_files=len(files), scan_root=str(path))

    if fail_on:
        threshold = Severity(fail_on.upper())
        order = [Severity.HIGH, Severity.MEDIUM, Severity.LOW, Severity.INFO]
        threshold_idx = order.index(threshold)
        for i in issues:
            if order.index(i.severity) <= threshold_idx:
                sys.exit(1)
    sys.exit(0)


if __name__ == "__main__":
    main()
