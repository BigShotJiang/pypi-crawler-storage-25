"""llmdoctor — find LLM cost leaks before your bill does."""

__version__ = "0.2.0"
