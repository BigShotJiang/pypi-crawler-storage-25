"""Issue model — what every checker emits."""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Optional


class Severity(str, Enum):
    HIGH = "HIGH"      # measurable cost leak, fix now
    MEDIUM = "MEDIUM"  # likely cost leak, depends on traffic
    LOW = "LOW"        # advisory, future risk
    INFO = "INFO"      # observation, no action required


@dataclass
class Issue:
    """A single finding from a checker.

    `cost_estimate_usd_monthly` is intentionally a rough number. We tell the
    user it is an estimate everywhere it appears — that is the trust contract.
    """

    code: str                    # stable ID, e.g. "TS001"
    title: str                   # one-line summary
    severity: Severity
    file: str                    # absolute path
    line: int                    # 1-indexed
    col: int = 0
    snippet: str = ""            # the offending line(s), trimmed
    explanation: str = ""        # why this is a problem
    fix_hint: str = ""           # concrete suggested fix
    docs_url: str = ""           # link for deeper reading
    cost_estimate_usd_monthly: Optional[float] = None  # None = unknown
    assumptions: list[str] = field(default_factory=list)  # what we assumed in the cost estimate

    def to_dict(self) -> dict:
        d = asdict(self)
        d["severity"] = self.severity.value
        return d
