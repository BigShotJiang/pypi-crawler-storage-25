"""Terminal report renderer using rich.

Two output modes:
- pretty (default) — colorized, grouped by severity, with cost totals
- json — for CI / programmatic consumption
"""

from __future__ import annotations

import json
from collections import Counter
from typing import Iterable

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from llmdoctor.issues import Issue, Severity


SEVERITY_ORDER = [Severity.HIGH, Severity.MEDIUM, Severity.LOW, Severity.INFO]
SEVERITY_STYLE = {
    Severity.HIGH: "bold red",
    Severity.MEDIUM: "yellow",
    Severity.LOW: "blue",
    Severity.INFO: "dim",
}


def render_json(issues: Iterable[Issue]) -> str:
    return json.dumps([i.to_dict() for i in issues], indent=2)


def render_pretty(issues: list[Issue], scanned_files: int, scan_root: str) -> None:
    console = Console()

    if not issues:
        console.print(
            Panel.fit(
                Text(
                    f"Clean. Scanned {scanned_files} Python file(s) under {scan_root}.\n"
                    "No cost-leak patterns detected.",
                    style="green",
                ),
                title="llmdoctor doctor",
                border_style="green",
            )
        )
        return

    # Header summary
    severity_counts = Counter(i.severity for i in issues)
    total_est = sum(i.cost_estimate_usd_monthly or 0.0 for i in issues)
    summary = Text()
    summary.append("Scanned ", style="dim")
    summary.append(f"{scanned_files} file(s)", style="bold")
    summary.append(" under ", style="dim")
    summary.append(f"{scan_root}\n", style="bold")
    summary.append("Found ", style="dim")
    summary.append(f"{len(issues)} issue(s): ", style="bold")
    parts = []
    for sev in SEVERITY_ORDER:
        n = severity_counts.get(sev, 0)
        if n:
            parts.append(f"[{SEVERITY_STYLE[sev]}]{n} {sev.value}[/]")
    summary.append(" · ".join(p for p in parts if p) if parts else "", style="")
    summary = Text.from_markup(str(summary) if False else "")  # placeholder below

    header = Text()
    header.append(f"Scanned {scanned_files} file(s) under {scan_root}\n", style="dim")
    header.append(f"Found {len(issues)} issue(s)", style="bold")
    if parts:
        header.append("  ·  ")
        header.append_text(Text.from_markup(" · ".join(parts)))
    if total_est > 0:
        header.append("\n")
        header.append(
            f"Estimated potential savings: ~${total_est:,.0f}/month",
            style="bold green",
        )
        header.append(
            "  (rough estimate, see assumptions)", style="dim italic"
        )

    console.print(Panel(header, title="llmdoctor doctor", border_style="cyan"))

    # Sort: HIGH first, then by file, then by line
    sorted_issues = sorted(
        issues,
        key=lambda i: (SEVERITY_ORDER.index(i.severity), i.file, i.line),
    )

    for issue in sorted_issues:
        _render_issue(console, issue)

    # Footer disclaimer
    console.print()
    console.print(
        Text.from_markup(
            "[dim italic]"
            "Cost estimates are heuristic — they assume traffic levels printed in each issue. "
            "Treat them as 'order of magnitude', not invoice predictions. "
            "Run `llmdoctor doctor --json` for programmatic output."
            "[/]"
        )
    )


def _render_issue(console: Console, issue: Issue) -> None:
    """Render a single issue panel.

    Security note: every user-controlled string (file path, code snippet,
    title) is wrapped in `Text(...)` which does NOT interpret rich markup.
    A filename containing `[red]` or square brackets cannot break the
    layout or inject styling. Strings we author (explanation, fix_hint,
    docs_url, severity name, code id) are safe to pass directly.
    """
    style = SEVERITY_STYLE[issue.severity]
    title = Text()
    title.append(f"[{issue.severity.value}] ", style=style)
    title.append(f"{issue.code} ", style="bold")
    title.append_text(Text(issue.title))

    body = Table.grid(padding=(0, 1))
    body.add_column(style="dim", justify="right", no_wrap=True)
    body.add_column(overflow="fold")

    body.add_row("file:", Text(f"{issue.file}:{issue.line}"))
    if issue.snippet:
        # Truncate very long snippets to keep the panel readable.
        snip = issue.snippet if len(issue.snippet) <= 400 else issue.snippet[:397] + "..."
        body.add_row("code:", Text(snip, style="white on grey15"))
    body.add_row("why:", Text(issue.explanation))
    if issue.fix_hint:
        body.add_row("fix:", Text(issue.fix_hint))
    if issue.cost_estimate_usd_monthly is not None and issue.cost_estimate_usd_monthly > 0:
        est_line = Text()
        est_line.append(
            f"~${issue.cost_estimate_usd_monthly:,.2f}/month",
            style="bold green",
        )
        if issue.assumptions:
            est_line.append(
                f"  (assuming: {', '.join(issue.assumptions)})", style="dim italic"
            )
        body.add_row("estimate:", est_line)
    if issue.docs_url:
        body.add_row("docs:", Text(issue.docs_url, style="blue underline"))

    console.print(Panel(body, title=title, border_style=style, padding=(0, 1)))
