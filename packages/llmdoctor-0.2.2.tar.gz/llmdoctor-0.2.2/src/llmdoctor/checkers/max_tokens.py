"""TS010 — missing max_tokens / output cap on LLM calls.

Output tokens cost 3-10x input tokens (Anthropic Opus: 5x; OpenAI GPT-5: 3x).
A call with no max_tokens cap can run away. We flag any messages.create() or
chat.completions.create() that doesn't specify it.
"""

from __future__ import annotations

import ast
from typing import Optional

from llmdoctor.checkers.base import Checker
from llmdoctor.issues import Issue, Severity
from llmdoctor.pricing import lookup


# Anthropic SDK requires max_tokens (it's a required arg) — so this checker
# fires only on OpenAI-style chat.completions.create where it's optional.
# Anthropic-side, we instead flag VERY HIGH max_tokens on cheap models.
HIGH_OUTPUT_THRESHOLD = 8000  # tokens — likely a copy-paste default


class MissingMaxTokensChecker(Checker):
    code_prefix = "TS010"

    def visit_Call(self, node: ast.Call) -> None:
        name = self.get_call_name(node)
        if name.endswith("chat.completions.create"):
            self._check_openai(node)
        elif name.endswith("messages.create"):
            self._check_anthropic(node)
        self.generic_visit(node)

    def _check_openai(self, call: ast.Call) -> None:
        max_tokens = self.get_kwarg(call, "max_tokens") or self.get_kwarg(
            call, "max_completion_tokens"
        )
        if max_tokens is None:
            self.emit(self._no_cap_issue(call, provider="openai"))
            return
        if isinstance(max_tokens, ast.Constant) and isinstance(max_tokens.value, int):
            if max_tokens.value > HIGH_OUTPUT_THRESHOLD:
                model = self._extract_model(call)
                self.emit(self._high_cap_issue(call, max_tokens.value, model))

    def _check_anthropic(self, call: ast.Call) -> None:
        max_tokens = self.get_kwarg(call, "max_tokens")
        if isinstance(max_tokens, ast.Constant) and isinstance(max_tokens.value, int):
            if max_tokens.value > HIGH_OUTPUT_THRESHOLD:
                model = self._extract_model(call)
                self.emit(self._high_cap_issue(call, max_tokens.value, model))

    def _extract_model(self, call: ast.Call) -> Optional[str]:
        m = self.get_kwarg(call, "model")
        if isinstance(m, ast.Constant) and isinstance(m.value, str):
            return m.value
        return None

    def _no_cap_issue(self, call: ast.Call, provider: str) -> Issue:
        return Issue(
            code="TS010",
            title="No max_tokens / max_completion_tokens set — output cost is unbounded",
            severity=Severity.HIGH,
            file=self.file_path,
            line=call.lineno,
            col=call.col_offset,
            snippet=self.snippet_at(call.lineno),
            explanation=(
                "Output tokens cost 3-10x input tokens. Without a cap, a single misbehaving "
                "request (or a model that happens to start a long ramble) can produce thousands "
                "of unwanted output tokens — often the single biggest cost spike in production."
            ),
            fix_hint=(
                "Set `max_tokens=...` explicitly. Pick a value matched to the route's worst "
                "legitimate response length, not the model's max. e.g. 256 for short Q&A, "
                "2048 for summaries, 4096 for code generation."
            ),
            docs_url="https://platform.openai.com/docs/api-reference/chat/create#chat-create-max_completion_tokens",
        )

    def _high_cap_issue(
        self, call: ast.Call, value: int, model: Optional[str]
    ) -> Issue:
        price = lookup(model)
        est = None
        assumptions: list[str] = []
        if price is not None:
            # Assume 30% of calls hit half the cap (a common observed pattern)
            calls_per_day = 100
            avg_output = value * 0.3
            cost_at_high = (avg_output * calls_per_day * 30 / 1_000_000) * price.output_per_mtok
            cost_at_2k = (min(avg_output, 2000) * calls_per_day * 30 / 1_000_000) * price.output_per_mtok
            est = round(cost_at_high - cost_at_2k, 2)
            assumptions = [
                f"max_tokens={value}",
                "30% of calls produce ~30% of cap",
                "100 calls/day, 30-day month",
                "vs a 2048-token cap",
            ]
        return Issue(
            code="TS011",
            title=f"max_tokens={value} is suspiciously high — likely a copy-paste default",
            severity=Severity.MEDIUM,
            file=self.file_path,
            line=call.lineno,
            col=call.col_offset,
            snippet=self.snippet_at(call.lineno),
            explanation=(
                f"Setting max_tokens to {value} means a single response can cost up to "
                f"{value} output tokens. Most production routes need <2k. Long ceilings rarely "
                "improve quality but reliably enable expensive ramble-on completions."
            ),
            fix_hint=(
                "Audit your traffic: what's the p95 output length you actually need? Set "
                "max_tokens to ~1.5x that. If you genuinely need long output, suppress this "
                "warning with `# llmdoctor: ignore TS011`."
            ),
            docs_url="",
            cost_estimate_usd_monthly=est,
            assumptions=assumptions,
        )
