"""TS001/TS003 — Anthropic prompt cache placement bugs.

TS001: dynamic content placed *before* a `cache_control` marker, which
silently invalidates the cached prefix on every call. This pattern has
been observed in shipped production LLM tooling — easy to write, hard
to detect at runtime (the cost only shows up on the next month's bill).

TS003: large literal system prompt without cache_control (likely-cacheable,
missed savings).

Note: an earlier version included a TS002 ("cache_control on the last block
with nothing after") but it false-positived on the canonical correct pattern
(single static system block with cache_control, dynamic in messages). We
dropped it rather than ship a noisy check. The real "wasted cache write"
case requires execution-trace data; that lives in the runtime SDK, not
static analysis.
"""

from __future__ import annotations

import ast
from typing import Optional

from llmdoctor.checkers.base import Checker
from llmdoctor.issues import Issue, Severity
from llmdoctor.pricing import lookup

# Heuristic: any system prompt string longer than this is likely-cacheable.
# Anthropic recommends >= 1024 tokens; 1 token ~= 4 chars, so ~4000 chars.
# We use a conservative 2000 chars to catch lots of real cases.
LIKELY_CACHEABLE_CHARS = 2000


def _is_dynamic(node: ast.expr) -> bool:
    """Does this expression produce content that varies per call?

    f-strings, .format(), %, +, name references — yes.
    Plain string constants and Bytes — no.
    """
    if isinstance(node, ast.Constant):
        return False
    if isinstance(node, ast.JoinedStr):
        # f-string: check it has any FormattedValue
        return any(isinstance(v, ast.FormattedValue) for v in node.values)
    if isinstance(node, ast.BinOp):
        return True
    if isinstance(node, ast.Call):
        # .format(), str(), etc. — assume dynamic.
        return True
    if isinstance(node, (ast.Name, ast.Attribute, ast.Subscript)):
        return True
    return True  # err on the side of "dynamic"


def _block_has_cache_control(block: ast.expr) -> bool:
    """A 'block' is a dict literal. Does it set cache_control=...?"""
    if not isinstance(block, ast.Dict):
        return False
    for k in block.keys:
        if isinstance(k, ast.Constant) and k.value == "cache_control":
            return True
    return False


def _block_text_is_dynamic(block: ast.expr) -> bool:
    """Does this content block hold dynamic text?"""
    if not isinstance(block, ast.Dict):
        # If it's a Name/Call, we can't see inside — assume dynamic.
        return True
    for k, v in zip(block.keys, block.values):
        if isinstance(k, ast.Constant) and k.value == "text":
            return _is_dynamic(v)
    # No text key found (could be image, tool_result) — treat as dynamic.
    return True


def _system_blocks(system_arg: ast.expr) -> Optional[list[ast.expr]]:
    """If `system=` is a list of blocks, return the list. Otherwise None."""
    if isinstance(system_arg, ast.List):
        return list(system_arg.elts)
    return None


def _string_literal_length(node: ast.expr, name_lengths: Optional[dict[str, int]] = None) -> Optional[int]:
    """If node is a static string literal, return its char length. Else None.

    Handles:
        "literal"
        "abc" * 100         (constant * int)
        f"plain f-string with only constants"
        IDENTIFIER          (resolved via name_lengths if provided)
    """
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return len(node.value)
    if isinstance(node, ast.JoinedStr):
        if all(isinstance(v, ast.Constant) for v in node.values):
            return sum(len(v.value) for v in node.values if isinstance(v.value, str))
        return None
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Mult):
        # "x" * N or N * "x"
        left, right = node.left, node.right
        if (
            isinstance(left, ast.Constant)
            and isinstance(left.value, str)
            and isinstance(right, ast.Constant)
            and isinstance(right.value, int)
        ):
            return len(left.value) * right.value
        if (
            isinstance(right, ast.Constant)
            and isinstance(right.value, str)
            and isinstance(left, ast.Constant)
            and isinstance(left.value, int)
        ):
            return len(right.value) * left.value
    if isinstance(node, ast.Name) and name_lengths is not None:
        return name_lengths.get(node.id)
    return None


def _collect_module_string_lengths(tree: ast.AST) -> dict[str, int]:
    """One-pass scan: top-level NAME = <static string expr> assignments.

    Lets us flag a long system prompt even when stored in a module constant.
    Only resolves SIMPLE assigns at module scope — no walrus, no destructuring,
    no class/function-scoped names. False negatives over false positives.
    """
    lengths: dict[str, int] = {}
    if not isinstance(tree, ast.Module):
        return lengths
    for stmt in tree.body:
        if isinstance(stmt, ast.Assign) and len(stmt.targets) == 1:
            target = stmt.targets[0]
            if isinstance(target, ast.Name):
                length = _string_literal_length(stmt.value)
                if length is not None:
                    lengths[target.id] = length
        elif isinstance(stmt, ast.AnnAssign) and isinstance(stmt.target, ast.Name) and stmt.value is not None:
            length = _string_literal_length(stmt.value)
            if length is not None:
                lengths[stmt.target.id] = length
    return lengths


class AnthropicCacheChecker(Checker):
    code_prefix = "TS001"

    def __init__(self, file_path: str, source: str) -> None:
        super().__init__(file_path, source)
        self._name_lengths: dict[str, int] = {}

    def visit_Module(self, node: ast.Module) -> None:
        self._name_lengths = _collect_module_string_lengths(node)
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call) -> None:
        name = self.get_call_name(node)
        # Match anthropic-style: <anything>.messages.create(...)
        if name.endswith("messages.create"):
            self._check_messages_create(node)
        self.generic_visit(node)

    def _check_messages_create(self, call: ast.Call) -> None:
        model = self._extract_model(call)
        system_arg = self.get_kwarg(call, "system")

        if system_arg is not None:
            self._check_system(call, system_arg, model)

    def _extract_model(self, call: ast.Call) -> Optional[str]:
        m = self.get_kwarg(call, "model")
        if isinstance(m, ast.Constant) and isinstance(m.value, str):
            return m.value
        return None

    # ---- TS001 / TS003 logic -------------------------------------------------
    def _check_system(self, call: ast.Call, system_arg: ast.expr, model: Optional[str]) -> None:
        blocks = _system_blocks(system_arg)
        if blocks is None:
            # system is a plain string or a Name — check TS003.
            length = _string_literal_length(system_arg, self._name_lengths)
            if length is not None and length >= LIKELY_CACHEABLE_CHARS:
                self.emit(self._missed_cache_issue(call, model, length))
            return

        # Find the first block with cache_control. Dynamic content before it
        # invalidates the cache on every call (TS001).
        first_cached_idx: Optional[int] = None
        for i, b in enumerate(blocks):
            if _block_has_cache_control(b):
                first_cached_idx = i
                break

        if first_cached_idx is None:
            # No caching. If any block is large+static, flag TS003.
            for b in blocks:
                if isinstance(b, ast.Dict):
                    for k, v in zip(b.keys, b.values):
                        if isinstance(k, ast.Constant) and k.value == "text":
                            length = _string_literal_length(v, self._name_lengths)
                            if length is not None and length >= LIKELY_CACHEABLE_CHARS:
                                self.emit(self._missed_cache_issue(call, model, length))
                                return
            return

        # Walk blocks BEFORE the first cached marker; flag any dynamic content.
        for i in range(first_cached_idx):
            b = blocks[i]
            if _block_text_is_dynamic(b):
                self.emit(self._dynamic_before_cache_issue(call, b, i, model))
                return  # one issue per call site is enough

    # ---- Issue constructors --------------------------------------------------
    def _dynamic_before_cache_issue(
        self, call: ast.Call, block: ast.expr, idx: int, model: Optional[str]
    ) -> Issue:
        price = lookup(model)
        # Conservative cost estimate: assume 3000 input tokens of system prompt,
        # 100 calls/day, savings missed = 90% of input cost (cache read is 0.1x).
        est = None
        assumptions: list[str] = []
        if price is not None:
            tokens_per_call = 3000
            calls_per_day = 100
            full_cost = (tokens_per_call * calls_per_day * 30 / 1_000_000) * price.input_per_mtok
            cached_cost = (tokens_per_call * calls_per_day * 30 / 1_000_000) * (
                price.cache_read_per_mtok or price.input_per_mtok * 0.1
            )
            est = round(full_cost - cached_cost, 2)
            assumptions = [
                "3000-token system prompt",
                "100 calls/day",
                "30-day month",
                "0.1× cache-read pricing",
            ]
        return Issue(
            code="TS001",
            title="Dynamic content before cache_control invalidates the prompt cache on every call",
            severity=Severity.HIGH,
            file=self.file_path,
            line=getattr(block, "lineno", call.lineno),
            col=getattr(block, "col_offset", 0),
            snippet=self.snippet_at(getattr(block, "lineno", call.lineno)),
            explanation=(
                f"System block at index {idx} contains dynamic content (variable, f-string, "
                "or call) but appears BEFORE the first block with cache_control. Anthropic "
                "matches the cache by exact prefix bytes — anything dynamic before the marker "
                "means the cache is rewritten, not read, on every call. This bug has been "
                "observed in shipped production LLM code; runtime detection takes weeks of "
                "billing-data analysis to spot."
            ),
            fix_hint=(
                "Move all static content (long instructions, retrieved docs that are stable for "
                "the route) to BEFORE the cache_control marker. Move dynamic content (the user's "
                "current question, per-request context) AFTER it, or into the messages array."
            ),
            docs_url="https://docs.anthropic.com/en/docs/build-with-claude/prompt-caching",
            cost_estimate_usd_monthly=est,
            assumptions=assumptions,
        )

    def _missed_cache_issue(
        self, call: ast.Call, model: Optional[str], char_length: int
    ) -> Issue:
        approx_tokens = char_length // 4
        price = lookup(model)
        est = None
        assumptions: list[str] = []
        if price is not None:
            calls_per_day = 100
            full_cost = (approx_tokens * calls_per_day * 30 / 1_000_000) * price.input_per_mtok
            cached_cost = (approx_tokens * calls_per_day * 30 / 1_000_000) * (
                price.cache_read_per_mtok or price.input_per_mtok * 0.1
            )
            est = round(full_cost - cached_cost, 2)
            assumptions = [
                f"~{approx_tokens}-token system prompt (chars/4)",
                "100 calls/day",
                "30-day month",
                "0.1× cache-read pricing",
            ]
        return Issue(
            code="TS003",
            title=f"Large static system prompt (~{approx_tokens} tokens) without cache_control",
            severity=Severity.MEDIUM,
            file=self.file_path,
            line=call.lineno,
            col=0,
            snippet=self.snippet_at(call.lineno),
            explanation=(
                "System prompt is long enough to benefit from prompt caching but no "
                "cache_control marker is set. Cache reads cost 0.1× input — leaving this "
                "uncached is paying 10× what you have to."
            ),
            fix_hint=(
                "Pass `system` as a list of blocks and add "
                "`{'type': 'text', 'text': '...', 'cache_control': {'type': 'ephemeral'}}` "
                "on the last static block. Keep dynamic content out of the cached prefix."
            ),
            docs_url="https://docs.anthropic.com/en/docs/build-with-claude/prompt-caching",
            cost_estimate_usd_monthly=est,
            assumptions=assumptions,
        )
