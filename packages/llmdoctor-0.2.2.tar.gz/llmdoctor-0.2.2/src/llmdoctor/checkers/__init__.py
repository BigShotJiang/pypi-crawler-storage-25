"""Built-in checkers."""

from llmdoctor.checkers.base import Checker
from llmdoctor.checkers.anthropic_cache import AnthropicCacheChecker
from llmdoctor.checkers.langchain import LangChainChecker
from llmdoctor.checkers.max_tokens import MissingMaxTokensChecker
from llmdoctor.checkers.model_choice import ExpensiveModelChecker

ALL_CHECKERS: list[type[Checker]] = [
    AnthropicCacheChecker,
    MissingMaxTokensChecker,
    ExpensiveModelChecker,
    LangChainChecker,
]
