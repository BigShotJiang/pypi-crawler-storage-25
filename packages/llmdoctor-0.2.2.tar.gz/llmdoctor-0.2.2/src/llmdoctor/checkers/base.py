"""Base class for AST-walking checkers.

Each checker subclasses ast.NodeVisitor, accumulates Issues into self.issues,
and exposes a stable `code` prefix (e.g. TS001) for filtering.
"""

from __future__ import annotations

import ast
from typing import Optional

from llmdoctor.issues import Issue


class Checker(ast.NodeVisitor):
    """Subclass and override visit_* methods. Append findings to self.issues."""

    code_prefix: str = "TS000"

    def __init__(self, file_path: str, source: str) -> None:
        self.file_path = file_path
        self.source = source
        self.source_lines = source.splitlines()
        self.issues: list[Issue] = []

    def snippet_at(self, lineno: int, context: int = 0) -> str:
        """Return the source line at lineno (1-indexed), trimmed."""
        if lineno <= 0 or lineno > len(self.source_lines):
            return ""
        start = max(0, lineno - 1 - context)
        end = min(len(self.source_lines), lineno + context)
        return "\n".join(self.source_lines[start:end]).strip()

    def emit(self, issue: Issue) -> None:
        self.issues.append(issue)

    @staticmethod
    def get_kwarg(call: ast.Call, name: str) -> Optional[ast.expr]:
        """Find a keyword argument by name in a Call node."""
        for kw in call.keywords:
            if kw.arg == name:
                return kw.value
        return None

    @staticmethod
    def get_call_name(call: ast.Call) -> str:
        """Best-effort dotted name of the called function. e.g. 'client.messages.create'."""
        parts: list[str] = []
        node: Optional[ast.expr] = call.func
        while isinstance(node, ast.Attribute):
            parts.append(node.attr)
            node = node.value
        if isinstance(node, ast.Name):
            parts.append(node.id)
        return ".".join(reversed(parts))
