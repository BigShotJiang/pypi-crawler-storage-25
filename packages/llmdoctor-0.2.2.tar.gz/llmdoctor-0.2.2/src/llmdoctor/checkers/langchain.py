"""TS101 / TS102 — same cost-leak shapes via langchain_anthropic / langchain_openai.

Most LLM apps in 2026 don't write `client.messages.create(...)` directly.
They construct a model object once via `ChatAnthropic(...)` or `ChatOpenAI(...)`
and let LangChain handle the call mechanics. The `max_tokens` mistakes that
TS010 / TS011 catch on direct SDK calls happen at the **constructor** here:
miss it once, every downstream `.invoke()` / `.stream()` / `.batch()` inherits
the same uncapped behaviour.

We only check the constructor — analysing every `.invoke()` site to see
whether it adds `max_tokens` later via `.bind()` would require data-flow
analysis we don't do in 0.1. False negatives over false positives: if you
set `max_tokens=` on the constructor we trust you.

We do NOT add a TS020-equivalent (premium-on-tiny-prompt) for LangChain
because the prompt isn't visible at construction time — we'd false-positive
on every Opus instantiation regardless of the actual workload.
"""

from __future__ import annotations

import ast
from typing import Optional

from llmdoctor.checkers.base import Checker
from llmdoctor.checkers.max_tokens import HIGH_OUTPUT_THRESHOLD
from llmdoctor.issues import Issue, Severity
from llmdoctor.pricing import lookup


class LangChainChecker(Checker):
    code_prefix = "TS101"

    def visit_Call(self, node: ast.Call) -> None:
        name = self.get_call_name(node)
        # Match constructor calls. `endswith` lets us catch both
        # `from langchain_openai import ChatOpenAI; ChatOpenAI(...)` and
        # `langchain_openai.ChatOpenAI(...)` and `lc.ChatOpenAI(...)`.
        if name.endswith("ChatOpenAI"):
            self._check(node, has_default_max_tokens=False, provider_label="ChatOpenAI")
        elif name.endswith("ChatAnthropic"):
            # ChatAnthropic ships with a default max_tokens, so missing it is
            # not unbounded. We only flag the high-cap case here.
            self._check(node, has_default_max_tokens=True, provider_label="ChatAnthropic")
        elif name.endswith("AgentExecutor"):
            self._check_agent_executor(node)
        self.generic_visit(node)

    # ---- main logic ---------------------------------------------------------
    def _check(
        self,
        call: ast.Call,
        *,
        has_default_max_tokens: bool,
        provider_label: str,
    ) -> None:
        max_tokens = self.get_kwarg(call, "max_tokens") or self.get_kwarg(
            call, "max_completion_tokens"
        )
        model = self._extract_model(call)

        if max_tokens is None:
            if not has_default_max_tokens:
                self.emit(self._no_cap_issue(call, provider_label, model))
            return

        if isinstance(max_tokens, ast.Constant) and isinstance(max_tokens.value, int):
            if max_tokens.value > HIGH_OUTPUT_THRESHOLD:
                self.emit(self._high_cap_issue(call, max_tokens.value, model, provider_label))

    def _extract_model(self, call: ast.Call) -> Optional[str]:
        """LangChain accepts the model name as `model=`, `model_name=`, or first positional."""
        m = self.get_kwarg(call, "model") or self.get_kwarg(call, "model_name")
        if isinstance(m, ast.Constant) and isinstance(m.value, str):
            return m.value
        if call.args and isinstance(call.args[0], ast.Constant) and isinstance(call.args[0].value, str):
            return call.args[0].value
        return None

    # ---- issue constructors -------------------------------------------------
    def _no_cap_issue(self, call: ast.Call, provider_label: str, model: Optional[str]) -> Issue:
        return Issue(
            code="TS101",
            title=f"{provider_label}() instantiated without max_tokens — output cost is unbounded",
            severity=Severity.HIGH,
            file=self.file_path,
            line=call.lineno,
            col=call.col_offset,
            snippet=self.snippet_at(call.lineno),
            explanation=(
                f"When {provider_label} is constructed without `max_tokens`, every downstream "
                "`.invoke()` / `.stream()` / `.batch()` call inherits no output cap. A single "
                "misbehaving completion can produce thousands of unwanted output tokens — and "
                "output is 3-10x the cost of input. This is the LangChain-side equivalent of "
                "TS010 (the same bug at the SDK layer)."
            ),
            fix_hint=(
                f"Set `max_tokens=...` on the {provider_label}(...) call. Match the value to "
                "your route's worst legitimate response length: 256 for short Q&A, 2048 for "
                "summaries, 4096 for code. If you set it later via `.bind(max_tokens=...)`, "
                "add `# llmdoctor: ignore TS101` on this line — we can't see the bind."
            ),
            docs_url="",
        )

    # ---- TS103 / TS104: agent loop runaway ---------------------------------
    # Agent loops are the #1 cost pain point in 2026: a single autonomous agent
    # without an iteration cap can rack up $1,000–$5,000 in tokens per session
    # (per dev.to, Apr 2026). The default `max_iterations=15` on AgentExecutor
    # is sensible — we only flag when developers EXPLICITLY override it to
    # `None` (unbounded) or to a suspicious large value.
    AGENT_HIGH_ITER_THRESHOLD = 50  # iterations — past this, costs are real

    def _check_agent_executor(self, call: ast.Call) -> None:
        max_iter = self.get_kwarg(call, "max_iterations")
        if max_iter is None:
            # Kwarg absent → uses sensible default. Don't false-positive.
            return
        if isinstance(max_iter, ast.Constant):
            if max_iter.value is None:
                self.emit(self._unbounded_agent_issue(call))
            elif (
                isinstance(max_iter.value, int)
                and max_iter.value > self.AGENT_HIGH_ITER_THRESHOLD
            ):
                self.emit(self._high_iter_agent_issue(call, max_iter.value))

    def _unbounded_agent_issue(self, call: ast.Call) -> Issue:
        return Issue(
            code="TS103",
            title="AgentExecutor instantiated with max_iterations=None — single session can cost $1k+ in tokens",
            severity=Severity.HIGH,
            file=self.file_path,
            line=call.lineno,
            col=call.col_offset,
            snippet=self.snippet_at(call.lineno),
            explanation=(
                "Setting `max_iterations=None` removes the loop cap. If the agent's stop "
                "condition fails to trigger (a bad tool response, an LLM that refuses to "
                "call the final-answer action, a circular tool-call pattern), the agent runs "
                "forever — racking up $1,000–$5,000 in tokens per session in documented 2026 "
                "incidents. Output tokens cost 3-10x input, every iteration adds prior "
                "context to the prompt, and intermediate tool results compound."
            ),
            fix_hint=(
                "Set `max_iterations=15` (the LangChain default) or higher if your agent "
                "genuinely needs more depth. Always pair with `max_execution_time=...` "
                "(seconds) for a wall-clock cap. If you really must run unbounded, add "
                "`# llmdoctor: ignore TS103` and document why in a comment above."
            ),
            docs_url="https://api.python.langchain.com/en/latest/agents/langchain.agents.agent.AgentExecutor.html",
        )

    def _high_iter_agent_issue(self, call: ast.Call, value: int) -> Issue:
        # Rough estimate: at ~$0.10/turn (Sonnet-class) and 30% chance of running
        # to the cap on a stuck session, value=200 means up to ~$6 per stuck session.
        per_turn_cost = 0.10
        stuck_session_cost = round(value * per_turn_cost, 2)
        return Issue(
            code="TS104",
            title=f"AgentExecutor max_iterations={value} is suspiciously high",
            severity=Severity.MEDIUM,
            file=self.file_path,
            line=call.lineno,
            col=call.col_offset,
            snippet=self.snippet_at(call.lineno),
            explanation=(
                f"At a typical ~$0.10/turn (Sonnet-class), {value} iterations means a single "
                f"stuck session can burn up to ~${stuck_session_cost} of tokens before the "
                "cap kicks in. Most agents converge in <15 turns; values above 50 usually "
                "mean someone hit a tool-loop bug and bumped the cap as a workaround instead "
                "of fixing the underlying logic."
            ),
            fix_hint=(
                "Lower `max_iterations` to ~20–30 unless you have measurement showing your "
                "p95 legitimate session needs more. If your agent legitimately runs longer, "
                "suppress with `# llmdoctor: ignore TS104` and add `max_execution_time=...` "
                "as a wall-clock backstop."
            ),
            docs_url="https://api.python.langchain.com/en/latest/agents/langchain.agents.agent.AgentExecutor.html",
            cost_estimate_usd_monthly=None,  # depends on stuck-session frequency, hard to estimate
            assumptions=[],
        )

    def _high_cap_issue(
        self,
        call: ast.Call,
        value: int,
        model: Optional[str],
        provider_label: str,
    ) -> Issue:
        price = lookup(model)
        est = None
        assumptions: list[str] = []
        if price is not None:
            calls_per_day = 100
            avg_output = value * 0.3
            cost_at_high = (avg_output * calls_per_day * 30 / 1_000_000) * price.output_per_mtok
            cost_at_2k = (
                min(avg_output, 2000) * calls_per_day * 30 / 1_000_000
            ) * price.output_per_mtok
            est = round(cost_at_high - cost_at_2k, 2)
            assumptions = [
                f"max_tokens={value}",
                "30% of calls produce ~30% of cap",
                "100 calls/day, 30-day month",
                "vs a 2048-token cap",
            ]
        return Issue(
            code="TS102",
            title=f"max_tokens={value} on {provider_label} is suspiciously high",
            severity=Severity.MEDIUM,
            file=self.file_path,
            line=call.lineno,
            col=call.col_offset,
            snippet=self.snippet_at(call.lineno),
            explanation=(
                f"Setting max_tokens to {value} on the {provider_label} constructor means a "
                f"single response can cost up to {value} output tokens, and every subsequent "
                ".invoke()/.stream() call inherits the cap. Most production routes need <2k. "
                "Long ceilings rarely improve quality but reliably enable expensive "
                "ramble-on completions."
            ),
            fix_hint=(
                "Lower max_tokens to ~1.5x your p95 legitimate response length. If you "
                "genuinely need this much output, suppress with `# llmdoctor: ignore TS102`."
            ),
            docs_url="",
            cost_estimate_usd_monthly=est,
            assumptions=assumptions,
        )
