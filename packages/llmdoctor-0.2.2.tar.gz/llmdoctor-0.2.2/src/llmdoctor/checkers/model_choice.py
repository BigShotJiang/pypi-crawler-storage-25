"""TS020 — expensive model on tiny prompts.

Opus on a 50-token prompt is the canonical "I copy-pasted from the docs" leak.
We flag when a premium-tier model is used for a call whose total static
content is small enough that a cheaper model would almost certainly suffice.
"""

from __future__ import annotations

import ast
from typing import Optional

from llmdoctor.checkers.base import Checker
from llmdoctor.issues import Issue, Severity
from llmdoctor.pricing import lookup


# Models we consider "premium" — using them for trivial work is a known leak.
PREMIUM = {
    "claude-opus-4",
    "claude-opus-4-7",
    "gpt-5",
    "gpt-4-turbo",
    "gpt-4o",
}

# Total static char count under which premium feels likely overkill.
TINY_PROMPT_CHARS = 400


def _model_is_premium(name: str) -> bool:
    if name in PREMIUM:
        return True
    # match prefix-stripped form too
    parts = name.rsplit("-", 1)
    if len(parts) == 2 and (parts[1].isdigit() or parts[1] == "latest"):
        return parts[0] in PREMIUM
    return False


def _approx_static_size(call: ast.Call) -> int:
    """Sum char lengths of all string-literal text we can see in this call."""
    total = 0

    class StrCounter(ast.NodeVisitor):
        def visit_Constant(self, n: ast.Constant) -> None:
            nonlocal total
            if isinstance(n.value, str):
                total += len(n.value)

    StrCounter().visit(call)
    return total


class ExpensiveModelChecker(Checker):
    code_prefix = "TS020"

    def visit_Call(self, node: ast.Call) -> None:
        name = self.get_call_name(node)
        if name.endswith("messages.create") or name.endswith("chat.completions.create"):
            self._check(node)
        self.generic_visit(node)

    def _check(self, call: ast.Call) -> None:
        model_arg = self.get_kwarg(call, "model")
        if not isinstance(model_arg, ast.Constant) or not isinstance(model_arg.value, str):
            return  # dynamic model selection — assume the dev knows what they're doing
        model_name = model_arg.value
        if not _model_is_premium(model_name):
            return
        size = _approx_static_size(call)
        if size > TINY_PROMPT_CHARS:
            return  # might genuinely need premium — don't nag

        cheaper = self._cheaper_alternative(model_name)
        self.emit(self._issue(call, model_name, cheaper, size))

    def _cheaper_alternative(self, model: str) -> Optional[str]:
        if model.startswith("claude-opus"):
            return "claude-haiku-4-5"
        if model in ("gpt-5", "gpt-4-turbo", "gpt-4o"):
            return "gpt-4o-mini"
        return None

    def _issue(
        self, call: ast.Call, model: str, cheaper: Optional[str], static_chars: int
    ) -> Issue:
        price = lookup(model)
        cheap_price = lookup(cheaper) if cheaper else None
        est = None
        assumptions: list[str] = []
        if price and cheap_price:
            # Assume 200 input + 200 output tokens per call, 1000 calls/day.
            in_tok, out_tok, cpd = 200, 200, 1000
            curr = (in_tok * cpd * 30 / 1_000_000) * price.input_per_mtok + (
                out_tok * cpd * 30 / 1_000_000
            ) * price.output_per_mtok
            new = (in_tok * cpd * 30 / 1_000_000) * cheap_price.input_per_mtok + (
                out_tok * cpd * 30 / 1_000_000
            ) * cheap_price.output_per_mtok
            est = round(curr - new, 2)
            assumptions = [
                "200 in / 200 out tokens per call",
                "1000 calls/day, 30-day month",
                f"vs {cheaper}",
            ]
        return Issue(
            code="TS020",
            title=f"Premium model `{model}` used on a tiny prompt (~{static_chars} static chars)",
            severity=Severity.MEDIUM,
            file=self.file_path,
            line=call.lineno,
            col=call.col_offset,
            snippet=self.snippet_at(call.lineno),
            explanation=(
                f"This call uses {model} but the total static prompt content is small. "
                "Premium models often produce indistinguishable output from mid/small-tier "
                "models on short tasks. The 95% cost-cut anecdote (GPT-4 → GPT-4o-mini, $3k/mo "
                "→ $150/mo, identical quality) starts here."
            ),
            fix_hint=(
                f"Try `{cheaper or 'a cheaper model'}` for this route. Run a small A/B with an "
                "LLM-as-judge eval on 50 real prompts before fully switching."
            ),
            docs_url="",
            cost_estimate_usd_monthly=est,
            assumptions=assumptions,
        )
