"""File walker — finds Python files, parses them, runs every checker.

Hardening notes:
- BOM-aware decoding (utf-8-sig).
- File-size cap to keep `read_text` + `ast.parse` from blowing memory on
  generated/minified files. Configurable via env var.
- Wide except around ast.parse and visitor walks: a measurement tool that
  crashes on a single weird file in a 10k-file monorepo is worse than one
  that silently skips it.
- Suppression comments: `# llmdoctor: ignore TSxxx` on the same line as the
  reported source location filters that issue out post-hoc.
- os.walk does not follow symlinks by default — keep that.
"""

from __future__ import annotations

import ast
import os
import re
import sys
from pathlib import Path
from typing import Iterable

from llmdoctor.checkers import ALL_CHECKERS
from llmdoctor.issues import Issue


SKIP_DIR_NAMES = {
    ".git", ".hg", ".svn",
    "__pycache__",
    ".venv", "venv", "env", ".env",
    "node_modules",
    "dist", "build", ".eggs", ".tox", ".mypy_cache", ".pytest_cache", ".ruff_cache",
    ".idea", ".vscode",
    "site-packages",
}

# 5 MB. A normal Python file is < 100 KB. Anything bigger is almost certainly
# generated, vendored, or hostile. Override with LLMDOCTOR_MAX_FILE_BYTES.
DEFAULT_MAX_FILE_BYTES = 5 * 1024 * 1024


def _max_file_bytes() -> int:
    raw = os.environ.get("LLMDOCTOR_MAX_FILE_BYTES")
    if raw is None:
        return DEFAULT_MAX_FILE_BYTES
    try:
        return max(0, int(raw))
    except ValueError:
        return DEFAULT_MAX_FILE_BYTES


# `# llmdoctor: ignore TS001` or `# llmdoctor: ignore TS001, TS010`
SUPPRESS_RE = re.compile(r"#\s*llmdoctor:\s*ignore\s+([A-Z0-9, ]+)", re.IGNORECASE)


def iter_python_files(root: Path) -> Iterable[Path]:
    if root.is_file():
        if root.suffix == ".py":
            yield root
        return
    for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
        dirnames[:] = [
            d for d in dirnames if d not in SKIP_DIR_NAMES and not d.startswith(".")
        ]
        for fn in filenames:
            if fn.endswith(".py"):
                yield Path(dirpath) / fn


def _read_source(path: Path) -> str | None:
    """Read source defensively. Returns None to mean 'skip this file'."""
    try:
        size = path.stat().st_size
    except OSError:
        return None
    if size > _max_file_bytes():
        return None
    try:
        # utf-8-sig transparently strips a UTF-8 BOM if present, otherwise
        # behaves like utf-8.
        return path.read_text(encoding="utf-8-sig")
    except (UnicodeDecodeError, OSError):
        return None


def _parse_safely(source: str, filename: str) -> ast.AST | None:
    try:
        return ast.parse(source, filename=filename)
    except (SyntaxError, ValueError):
        return None
    except RecursionError:
        # Pathologically nested expressions (often minified). Skip.
        return None


def _suppressions_for_file(source: str) -> dict[int, set[str]]:
    """Map line-number → set of issue codes suppressed on that line."""
    out: dict[int, set[str]] = {}
    for lineno, line in enumerate(source.splitlines(), start=1):
        m = SUPPRESS_RE.search(line)
        if not m:
            continue
        codes = {c.strip().upper() for c in m.group(1).split(",") if c.strip()}
        if codes:
            out[lineno] = codes
    return out


def _filter_suppressed(issues: list[Issue], suppressions: dict[int, set[str]]) -> list[Issue]:
    if not suppressions:
        return issues
    kept: list[Issue] = []
    for i in issues:
        codes_at_line = suppressions.get(i.line, set())
        if i.code in codes_at_line or "ALL" in codes_at_line:
            continue
        kept.append(i)
    return kept


def scan_file(path: Path) -> list[Issue]:
    """Parse one file, run every checker, drop suppressed issues. Never raises."""
    source = _read_source(path)
    if source is None:
        return []
    tree = _parse_safely(source, str(path))
    if tree is None:
        return []

    issues: list[Issue] = []
    for cls in ALL_CHECKERS:
        try:
            checker = cls(file_path=str(path), source=source)
            checker.visit(tree)
            issues.extend(checker.issues)
        except RecursionError:
            # Pathological AST shape. Skip just this checker, not the file.
            continue
        except Exception:
            # Any other checker bug should not take down the run. We swallow
            # silently in 0.1.0; once we have a logger in 0.2 we'll surface it.
            continue

    suppressions = _suppressions_for_file(source)
    return _filter_suppressed(issues, suppressions)


def scan_path(root: Path) -> list[Issue]:
    """Scan a file or directory tree; return aggregated issues."""
    # Bump recursion limit modestly for deeply nested ASTs (CPython's
    # ast.NodeVisitor recurses; very deep files can hit the default 1000).
    if sys.getrecursionlimit() < 5000:
        sys.setrecursionlimit(5000)

    all_issues: list[Issue] = []
    for f in iter_python_files(root):
        all_issues.extend(scan_file(f))
    return all_issues
