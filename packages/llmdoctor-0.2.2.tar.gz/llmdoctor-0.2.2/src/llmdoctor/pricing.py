"""Per-model pricing table for cost-impact estimates.

Numbers are per **million** tokens, USD. Verified 2026-04-30 from each provider's
public pricing page. We deliberately keep this short — only models we actually
recognise from import patterns. Out-of-table models get `None` and the report
shows "unknown model, no estimate" rather than guessing.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ModelPrice:
    input_per_mtok: float
    output_per_mtok: float
    cache_read_per_mtok: float | None = None   # Anthropic-style
    cache_write_5m_per_mtok: float | None = None
    provider: str = ""


# Anthropic pricing as of Apr 2026 (Opus 4.x family)
# Cache reads are 0.1x base input, 5-min writes are 1.25x base.
ANTHROPIC: dict[str, ModelPrice] = {
    "claude-opus-4": ModelPrice(15.0, 75.0, 1.50, 18.75, "anthropic"),
    "claude-opus-4-7": ModelPrice(15.0, 75.0, 1.50, 18.75, "anthropic"),
    "claude-sonnet-4": ModelPrice(3.0, 15.0, 0.30, 3.75, "anthropic"),
    "claude-sonnet-4-6": ModelPrice(3.0, 15.0, 0.30, 3.75, "anthropic"),
    "claude-haiku-4-5": ModelPrice(0.80, 4.0, 0.08, 1.0, "anthropic"),
}

# OpenAI pricing — automatic prompt cache since late 2024, no manual markers needed.
OPENAI: dict[str, ModelPrice] = {
    "gpt-5": ModelPrice(10.0, 30.0, provider="openai"),
    "gpt-4o": ModelPrice(2.50, 10.0, 1.25, provider="openai"),
    "gpt-4o-mini": ModelPrice(0.15, 0.60, 0.075, provider="openai"),
    "gpt-4-turbo": ModelPrice(10.0, 30.0, provider="openai"),
}

ALL: dict[str, ModelPrice] = {**ANTHROPIC, **OPENAI}


def lookup(model: str | None) -> ModelPrice | None:
    """Best-effort lookup. Strips date suffixes (e.g. -20251001) and matches prefix."""
    if not model:
        return None
    if model in ALL:
        return ALL[model]
    # Strip -YYYYMMDD or -latest suffixes and retry.
    parts = model.rsplit("-", 1)
    if len(parts) == 2 and (parts[1].isdigit() or parts[1] == "latest"):
        return ALL.get(parts[0])
    # Try progressively shorter prefixes.
    pieces = model.split("-")
    for i in range(len(pieces) - 1, 0, -1):
        candidate = "-".join(pieces[:i])
        if candidate in ALL:
            return ALL[candidate]
    return None
