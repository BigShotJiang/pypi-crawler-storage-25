"""Smoke tests for the CLI entry point."""

import json
from pathlib import Path

from click.testing import CliRunner

from llmdoctor.cli import main

FIXTURES = Path(__file__).parent / "fixtures"


def test_cli_doctor_runs_pretty() -> None:
    runner = CliRunner()
    result = runner.invoke(main, ["doctor", str(FIXTURES)])
    assert result.exit_code == 0, result.output
    assert "llmdoctor doctor" in result.output
    assert "TS001" in result.output  # at least one finding from fixtures
    assert "TS010" in result.output


def test_cli_doctor_json_is_valid() -> None:
    runner = CliRunner()
    result = runner.invoke(main, ["doctor", str(FIXTURES), "--json"])
    assert result.exit_code == 0, result.output
    data = json.loads(result.output)
    assert isinstance(data, list)
    assert any(i["code"] == "TS001" for i in data)


def test_cli_doctor_fail_on_high_exits_nonzero() -> None:
    runner = CliRunner()
    result = runner.invoke(main, ["doctor", str(FIXTURES), "--fail-on", "HIGH"])
    # Fixtures contain at least one HIGH issue, so the command should fail.
    assert result.exit_code == 1


def test_cli_doctor_clean_path_exits_zero(tmp_path: Path) -> None:
    # Empty dir → no issues → exit 0 even with --fail-on HIGH
    runner = CliRunner()
    result = runner.invoke(main, ["doctor", str(tmp_path), "--fail-on", "HIGH"])
    assert result.exit_code == 0
    assert "Clean" in result.output
