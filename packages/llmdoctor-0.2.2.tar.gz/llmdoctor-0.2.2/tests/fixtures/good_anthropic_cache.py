"""Fixture: correct cache placement. Should produce ZERO TS001/TS002/TS003 issues."""

import anthropic

client = anthropic.Anthropic()
user_query = "What is the meaning of life?"

# Static, long content first WITH cache_control on the last static block.
# Dynamic content goes into messages, not into the cached system prefix.
response = client.messages.create(
    model="claude-opus-4-7",
    max_tokens=1024,
    system=[
        {
            "type": "text",
            "text": "You are a helpful assistant. Always answer concisely. " * 100,
            "cache_control": {"type": "ephemeral"},
        },
    ],
    messages=[{"role": "user", "content": user_query}],
)
