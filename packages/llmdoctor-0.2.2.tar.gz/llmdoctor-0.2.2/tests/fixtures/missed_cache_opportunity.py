"""Fixture: large static system prompt without cache_control. Should trigger TS003."""

import anthropic

client = anthropic.Anthropic()

# 2000+ char static system prompt with no cache_control anywhere.
LONG_SYSTEM = "You are an expert in distributed systems. " * 100  # ~4400 chars

response = client.messages.create(
    model="claude-sonnet-4-6",
    max_tokens=1024,
    system=LONG_SYSTEM,
    messages=[{"role": "user", "content": "Explain Raft."}],
)
