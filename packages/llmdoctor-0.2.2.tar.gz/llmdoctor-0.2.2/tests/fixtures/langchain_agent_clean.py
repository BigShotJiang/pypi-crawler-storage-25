"""Fixture: AgentExecutor with default + sensible explicit caps. Should fire NOTHING."""

from langchain.agents import AgentExecutor

# Default max_iterations=15 — the kwarg is missing, that's fine.
default_agent = AgentExecutor(agent=None, tools=[])

# Explicit and sensible.
explicit_agent = AgentExecutor(
    agent=None,
    tools=[],
    max_iterations=20,
    max_execution_time=120,
)
