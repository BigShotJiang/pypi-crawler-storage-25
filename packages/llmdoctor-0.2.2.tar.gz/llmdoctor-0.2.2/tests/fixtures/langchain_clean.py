"""Fixture: properly-configured LangChain models. Should fire NOTHING."""

from langchain_anthropic import ChatAnthropic
from langchain_openai import ChatOpenAI

# Both have a sensible max_tokens cap. Neither premium model.
oai = ChatOpenAI(model="gpt-4o-mini", max_tokens=512)
ant = ChatAnthropic(model="claude-haiku-4-5", max_tokens=2048)
