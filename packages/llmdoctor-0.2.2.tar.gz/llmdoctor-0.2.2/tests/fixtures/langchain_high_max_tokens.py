"""Fixture: ChatAnthropic with absurdly high max_tokens. Should fire TS102."""

from langchain_anthropic import ChatAnthropic

llm = ChatAnthropic(model="claude-opus-4-7", max_tokens=20000)
