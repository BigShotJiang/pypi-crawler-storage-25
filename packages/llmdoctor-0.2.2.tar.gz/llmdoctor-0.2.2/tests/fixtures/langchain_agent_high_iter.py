"""Fixture: AgentExecutor with max_iterations=200. Should fire TS104 (MEDIUM)."""

from langchain.agents import AgentExecutor

# The "I bumped the cap as a workaround" anti-pattern.
agent = AgentExecutor(
    agent=None,
    tools=[],
    max_iterations=200,
)
