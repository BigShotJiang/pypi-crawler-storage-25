"""Fixture: edge cases that should NOT crash and should NOT produce false positives.

If any check in here flags an issue, fix the checker, not this file.
"""

import anthropic
from anthropic import AsyncAnthropic

client = anthropic.Anthropic()
async_client = AsyncAnthropic()

# Multi-target assignment (we currently skip these — that's fine, just don't crash).
A = B = "shared string"

# Annotated assignment with literal.
LONG_PROMPT_ANNOTATED: str = "You are a careful expert. " * 200

# Augmented assignment to a known string. We don't resolve these.
PROMPT = "start "
PROMPT += "more text"  # AugAssign — should not crash the collector

# Tuple unpacking — we skip; should not crash.
X, Y = "a", "b"

# Walrus inside a call — should not break model extraction.
def use_walrus():
    if (msg := "hi") and len(msg) > 0:
        return client.messages.create(
            model="claude-haiku-4-5",
            max_tokens=10,
            messages=[{"role": "user", "content": msg}],
        )


# Async call — same checks should apply via the inner Call node.
async def use_async():
    response = await async_client.messages.create(
        model="claude-haiku-4-5",
        max_tokens=10,
        system=[
            {"type": "text", "text": "You are helpful. " * 200, "cache_control": {"type": "ephemeral"}}
        ],
        messages=[{"role": "user", "content": "hi"}],
    )
    return response


# **kwargs unpacking — we cannot see inside, so we should not flag anything.
def use_kwargs(**config):
    return client.messages.create(**config)


# Dynamic model name (computed) — we should NOT flag TS020 because we can't see the model.
def use_dynamic_model(use_premium: bool):
    model = "claude-opus-4-7" if use_premium else "claude-haiku-4-5"
    return client.messages.create(
        model=model,
        max_tokens=256,
        system="hi",
        messages=[{"role": "user", "content": "x"}],
    )


# Bound-method assignment — known limitation, do not crash.
def use_bound_method():
    create = client.messages.create
    return create(
        model="claude-haiku-4-5",
        max_tokens=10,
        messages=[{"role": "user", "content": "hi"}],
    )


# Nested call — checker runs on every Call node, must not infinite-loop.
def nested_calls():
    return client.messages.create(
        model="claude-haiku-4-5",
        max_tokens=int("256"),
        messages=[{"role": "user", "content": str("hi")}],
    )


# Empty system list — must not IndexError.
def empty_system():
    return client.messages.create(
        model="claude-haiku-4-5",
        max_tokens=10,
        system=[],
        messages=[{"role": "user", "content": "x"}],
    )


# Shadowed `client.messages.create` (mock object). We can't tell — should not crash.
class MockMessages:
    def create(self, **_):
        return None


fake_client = type("X", (), {"messages": MockMessages()})()
fake_client.messages.create(model="something")  # should not be flagged or crash
