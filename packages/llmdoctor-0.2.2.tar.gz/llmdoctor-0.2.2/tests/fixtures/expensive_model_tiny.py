"""Fixture: Opus on a tiny prompt. Should trigger TS020."""

import anthropic

client = anthropic.Anthropic()

response = client.messages.create(
    model="claude-opus-4-7",
    max_tokens=256,
    system="You are helpful.",
    messages=[{"role": "user", "content": "What is 2+2?"}],
)
