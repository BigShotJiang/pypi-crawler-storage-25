"""Fixture: AgentExecutor with max_iterations=None. Should fire TS103 (HIGH)."""

from langchain.agents import AgentExecutor

# THE BUG — explicit None means unbounded loop. A single stuck session
# can cost $1k+ in tokens.
agent = AgentExecutor(
    agent=None,  # placeholder
    tools=[],
    max_iterations=None,
)
