"""Fixture: dynamic-before-cache-marker bug. Should trigger TS001."""

import anthropic

client = anthropic.Anthropic()
user_query = "What is the meaning of life?"

# BUG: the dynamic user_query block sits BEFORE the cache_control marker,
# so the cache prefix changes on every call and is never read.
response = client.messages.create(
    model="claude-opus-4-7",
    max_tokens=1024,
    system=[
        {"type": "text", "text": f"User said: {user_query}"},
        {
            "type": "text",
            "text": "You are a helpful assistant. Always answer concisely. " * 100,
            "cache_control": {"type": "ephemeral"},
        },
    ],
    messages=[{"role": "user", "content": "Hi"}],
)
