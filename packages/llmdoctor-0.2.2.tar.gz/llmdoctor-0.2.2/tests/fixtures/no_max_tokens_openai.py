"""Fixture: OpenAI call with no max_tokens. Should trigger TS010."""

from openai import OpenAI

client = OpenAI()

# BUG: no max_tokens — output cost is unbounded.
response = client.chat.completions.create(
    model="gpt-4o-mini",
    messages=[
        {"role": "system", "content": "You are helpful."},
        {"role": "user", "content": "Tell me a story."},
    ],
)
