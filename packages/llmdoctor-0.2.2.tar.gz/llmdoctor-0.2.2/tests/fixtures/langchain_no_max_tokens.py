"""Fixture: ChatOpenAI without max_tokens. Should fire TS101."""

from langchain_openai import ChatOpenAI

# BUG: no max_tokens — every downstream invoke() has unbounded output cost.
llm = ChatOpenAI(model="gpt-4o-mini")
response = llm.invoke("Tell me a story.")
