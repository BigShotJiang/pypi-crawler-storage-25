"""Edge cases — these are what kill measurement tools in production.

Every test here exercises a corner case the doctor must survive without
crashing or false-positiving.
"""

from __future__ import annotations

from pathlib import Path

from llmdoctor.scanner import scan_file, scan_path

FIXTURES = Path(__file__).parent / "fixtures"


# ---------- Edge-case fixture file: kwargs/walrus/async/etc ------------------

def test_edge_cases_fixture_has_no_findings() -> None:
    """The handcrafted edge-cases fixture must produce zero issues.

    If any check fires here, the check has a false positive on patterns
    we deliberately said should be allowed.
    """
    issues = scan_file(FIXTURES / "edge_cases.py")
    codes = [i.code for i in issues]
    assert codes == [], f"unexpected issues on edge_cases.py: {codes}"


# ---------- Input-safety edge cases ------------------------------------------

def test_empty_file_is_safe(tmp_path: Path) -> None:
    f = tmp_path / "empty.py"
    f.write_text("")
    assert scan_file(f) == []


def test_syntax_error_file_is_safe(tmp_path: Path) -> None:
    f = tmp_path / "syntax.py"
    f.write_text("def broken(:\n    pass\n")
    assert scan_file(f) == []


def test_non_utf8_file_is_safe(tmp_path: Path) -> None:
    f = tmp_path / "latin1.py"
    f.write_bytes(b"x = '\xe9clair'\n")  # latin-1 encoded
    assert scan_file(f) == []


def test_utf8_bom_file_is_parsed_correctly(tmp_path: Path) -> None:
    """A file written by Notepad on Windows has a UTF-8 BOM.
    The scanner must not choke on this and must still detect issues.
    """
    f = tmp_path / "bom.py"
    f.write_bytes(
        b"\xef\xbb\xbf"  # UTF-8 BOM
        + b"from openai import OpenAI\n"
        + b"client = OpenAI()\n"
        + b"client.chat.completions.create(model='gpt-4o-mini', messages=[])\n"
    )
    issues = scan_file(f)
    codes = [i.code for i in issues]
    assert "TS010" in codes, codes


def test_oversized_file_is_skipped(tmp_path: Path) -> None:
    """A 10 MB python file is almost certainly generated. Skip it."""
    f = tmp_path / "huge.py"
    # Write 6 MB of valid-but-pointless python that includes a real LLM call.
    # We expect the scanner to skip the whole file based on size, NOT report.
    body = "x = " + ("'a' + " * 1_000_000) + "''\n"
    body += (
        "from openai import OpenAI\n"
        "client = OpenAI()\n"
        "client.chat.completions.create(model='gpt-4o-mini', messages=[])\n"
    )
    f.write_text(body)
    issues = scan_file(f)
    # Even though the file ends with a real TS010-eligible call, we skip
    # because the file is too big.
    assert issues == []


def test_binary_file_with_py_extension_is_safe(tmp_path: Path) -> None:
    f = tmp_path / "binary.py"
    f.write_bytes(b"\x00\x01\x02\x03\xff\xfe")
    assert scan_file(f) == []


def test_pathological_string_concat_does_not_crash(tmp_path: Path) -> None:
    """Deeply nested BinOps used to hit RecursionError on the visitor walk."""
    # 200 string concats — well below the bumped recursion limit.
    body = "x = " + " + ".join(["'a'"] * 200) + "\n"
    f = tmp_path / "nested.py"
    f.write_text(body)
    # Just must not raise.
    scan_file(f)


# ---------- Suppression comments ---------------------------------------------

def test_suppression_filters_specific_code(tmp_path: Path) -> None:
    f = tmp_path / "suppressed.py"
    f.write_text(
        "from openai import OpenAI\n"
        "client = OpenAI()\n"
        "client.chat.completions.create(model='gpt-4o-mini', messages=[])  # llmdoctor: ignore TS010\n"
    )
    issues = scan_file(f)
    assert "TS010" not in [i.code for i in issues]


def test_suppression_all_filters_everything(tmp_path: Path) -> None:
    f = tmp_path / "suppress_all.py"
    f.write_text(
        "from openai import OpenAI\n"
        "client = OpenAI()\n"
        "client.chat.completions.create(model='gpt-5', messages=[])  # llmdoctor: ignore ALL\n"
    )
    issues = scan_file(f)
    assert issues == []


def test_unrelated_comment_does_not_suppress(tmp_path: Path) -> None:
    f = tmp_path / "no_suppress.py"
    f.write_text(
        "from openai import OpenAI\n"
        "client = OpenAI()\n"
        "client.chat.completions.create(model='gpt-4o-mini', messages=[])  # noqa\n"
    )
    issues = scan_file(f)
    assert "TS010" in [i.code for i in issues]


# ---------- Symlinks & directory traversal ------------------------------------

def test_skipped_dirs_are_not_scanned(tmp_path: Path) -> None:
    """Files inside venv / __pycache__ / node_modules must not be scanned."""
    bad = tmp_path / ".venv" / "lib" / "evil.py"
    bad.parent.mkdir(parents=True)
    bad.write_text(
        "from openai import OpenAI\n"
        "OpenAI().chat.completions.create(model='gpt-4o-mini', messages=[])\n"
    )
    issues = scan_path(tmp_path)
    assert issues == []


def test_path_with_special_characters_does_not_break_render(tmp_path: Path) -> None:
    """A filename containing rich-markup syntax must not break the report.

    This is an injection-style edge case: if the renderer interpreted the
    filename as markup, a file named '[red]hi[/].py' could change how every
    subsequent issue is styled.
    """
    # Windows forbids `/` in dir names, so use chars rich treats as markup
    # but the FS allows: square brackets and at-signs are sufficient.
    weird_dir = tmp_path / "[red]name[reset]"
    weird_dir.mkdir()
    f = weird_dir / "evil.py"
    f.write_text(
        "from openai import OpenAI\n"
        "OpenAI().chat.completions.create(model='gpt-4o-mini', messages=[])\n"
    )
    from llmdoctor.report import render_pretty
    issues = scan_file(f)
    # Just must not raise.
    render_pretty(issues, scanned_files=1, scan_root=str(tmp_path))
