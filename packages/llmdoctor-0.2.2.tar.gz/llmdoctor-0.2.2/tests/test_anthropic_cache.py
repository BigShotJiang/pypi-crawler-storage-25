"""Tests for the AnthropicCacheChecker (TS001/TS002/TS003)."""

from pathlib import Path

from llmdoctor.scanner import scan_file

FIXTURES = Path(__file__).parent / "fixtures"


def test_dynamic_before_cache_emits_ts001() -> None:
    issues = scan_file(FIXTURES / "bad_anthropic_cache.py")
    codes = [i.code for i in issues]
    assert "TS001" in codes, f"expected TS001, got {codes}"
    ts001 = next(i for i in issues if i.code == "TS001")
    assert ts001.severity.value == "HIGH"
    assert ts001.cost_estimate_usd_monthly is not None
    assert ts001.cost_estimate_usd_monthly > 0


def test_correct_cache_placement_no_ts001() -> None:
    issues = scan_file(FIXTURES / "good_anthropic_cache.py")
    codes = [i.code for i in issues]
    assert "TS001" not in codes, f"got false positive TS001: {codes}"
    assert "TS003" not in codes, f"got false positive TS003: {codes}"


def test_long_static_system_emits_ts003() -> None:
    issues = scan_file(FIXTURES / "missed_cache_opportunity.py")
    codes = [i.code for i in issues]
    assert "TS003" in codes, f"expected TS003, got {codes}"
