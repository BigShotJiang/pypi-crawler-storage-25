"""Tests for ExpensiveModelChecker (TS020)."""

from pathlib import Path

from llmdoctor.scanner import scan_file

FIXTURES = Path(__file__).parent / "fixtures"


def test_opus_on_tiny_prompt_emits_ts020() -> None:
    issues = scan_file(FIXTURES / "expensive_model_tiny.py")
    codes = [i.code for i in issues]
    assert "TS020" in codes, f"expected TS020, got {codes}"
    ts020 = next(i for i in issues if i.code == "TS020")
    assert "claude-opus" in ts020.title or "Opus" in ts020.title or "claude-opus-4-7" in ts020.title
    assert ts020.cost_estimate_usd_monthly is not None
