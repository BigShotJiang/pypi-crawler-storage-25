"""Tests for MissingMaxTokensChecker (TS010/TS011)."""

from pathlib import Path

from llmdoctor.scanner import scan_file

FIXTURES = Path(__file__).parent / "fixtures"


def test_openai_no_max_tokens_emits_ts010() -> None:
    issues = scan_file(FIXTURES / "no_max_tokens_openai.py")
    codes = [i.code for i in issues]
    assert "TS010" in codes, f"expected TS010, got {codes}"


def test_anthropic_with_max_tokens_no_ts010() -> None:
    # The anthropic fixtures all set max_tokens, so TS010 should not fire.
    issues = scan_file(FIXTURES / "good_anthropic_cache.py")
    codes = [i.code for i in issues]
    assert "TS010" not in codes
