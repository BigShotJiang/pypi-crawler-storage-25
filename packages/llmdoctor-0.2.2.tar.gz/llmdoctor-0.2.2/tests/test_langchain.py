"""Tests for LangChainChecker (TS101 / TS102)."""

from pathlib import Path

from llmdoctor.scanner import scan_file

FIXTURES = Path(__file__).parent / "fixtures"


def test_chatopenai_without_max_tokens_emits_ts101() -> None:
    issues = scan_file(FIXTURES / "langchain_no_max_tokens.py")
    codes = [i.code for i in issues]
    assert "TS101" in codes, f"expected TS101, got {codes}"
    ts101 = next(i for i in issues if i.code == "TS101")
    assert ts101.severity.value == "HIGH"
    assert "ChatOpenAI" in ts101.title


def test_chatanthropic_without_max_tokens_does_not_emit_ts101() -> None:
    """ChatAnthropic has a default max_tokens, so missing it is not unbounded.

    Use the high-max fixture (which sets max_tokens=20000) and assert TS101 is
    absent — only TS102 (excessive cap) should fire.
    """
    issues = scan_file(FIXTURES / "langchain_high_max_tokens.py")
    codes = [i.code for i in issues]
    assert "TS101" not in codes, f"unexpected TS101 on ChatAnthropic: {codes}"


def test_high_max_tokens_emits_ts102() -> None:
    issues = scan_file(FIXTURES / "langchain_high_max_tokens.py")
    codes = [i.code for i in issues]
    assert "TS102" in codes, f"expected TS102, got {codes}"
    ts102 = next(i for i in issues if i.code == "TS102")
    assert ts102.severity.value == "MEDIUM"
    # Cost estimate should be present because we know the model.
    assert ts102.cost_estimate_usd_monthly is not None
    assert ts102.cost_estimate_usd_monthly > 0


def test_clean_langchain_no_findings() -> None:
    issues = scan_file(FIXTURES / "langchain_clean.py")
    codes = [i.code for i in issues]
    assert codes == [], f"unexpected findings on clean fixture: {codes}"


# ---- TS103 / TS104: agent loop runaway --------------------------------------

def test_agent_max_iterations_none_emits_ts103() -> None:
    issues = scan_file(FIXTURES / "langchain_agent_unbounded.py")
    codes = [i.code for i in issues]
    assert "TS103" in codes, f"expected TS103, got {codes}"
    ts103 = next(i for i in issues if i.code == "TS103")
    assert ts103.severity.value == "HIGH"
    assert "1k" in ts103.title or "unbounded" in ts103.explanation.lower()


def test_agent_high_max_iterations_emits_ts104() -> None:
    issues = scan_file(FIXTURES / "langchain_agent_high_iter.py")
    codes = [i.code for i in issues]
    assert "TS104" in codes, f"expected TS104, got {codes}"
    ts104 = next(i for i in issues if i.code == "TS104")
    assert ts104.severity.value == "MEDIUM"
    assert "200" in ts104.title


def test_default_agent_no_findings() -> None:
    """Missing max_iterations kwarg = LangChain default (15) — must not fire."""
    issues = scan_file(FIXTURES / "langchain_agent_clean.py")
    codes = [i.code for i in issues]
    assert codes == [], f"unexpected findings on default agent: {codes}"
