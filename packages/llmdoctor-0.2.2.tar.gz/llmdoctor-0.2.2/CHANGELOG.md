# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.2.2] - 2026-04-30

Docs-only release. Tightens two README sections so the package page on
PyPI carries the same level of detail as the source.

### Changed
- **Check reference table.** Dropped the stale `(v0.2.0)` heading
  suffix; added a one-line lead-in that groups the nine checks into
  four failure-mode clusters (prompt-cache placement, output caps,
  model overspecification, agent loop runaway); rewrote five row
  descriptions so each one carries shape + cost mechanism in one
  sentence. The TS103 row in particular now surfaces the
  $1,000–$5,000 per-stuck-session figure that the rest of the README
  and CHANGELOG already cite.
- **Cost estimate methodology.** Replaced the file-path pointer
  (`llmdoctor/pricing.py`) with the actual logic: the cost formula,
  the default traffic profile, per-check assumption overrides, the
  list of bugs that deliberately produce no monthly figure (TS010 /
  TS101 / TS103 / TS104 — unbounded per-incident, surfaced inline
  instead), and which model families and cache treatments the
  bundled pricing data covers. Readers no longer need to open a file
  to understand how an estimate was derived.

No functional changes. Same nine checks, same 30/30 test suite, same
pricing table.

## [0.2.1] - 2026-04-30

Docs-only release. The wheel uploaded as 0.2.0 still contained the
earlier marketing-tone README with emoji status indicators (✅ / ❌ /
📧). The on-disk README had since been rewritten to a reference-document
style with plain-text status words; this release republishes so the
PyPI page reflects the cleaned content.

### Changed
- README description block bundled into the wheel switched from the
  emoji-heavy "What we don't do (yet)" / Roadmap layout to the plain
  `Supported` / `Not supported` / `Planned` / `Released` text columns
  used in the source repository.
- Example CLI output block in the README switched from ASCII
  (`+--`, `|`) to Unicode rounded box drawing (`╭─╮`, `│`, `╰─╯`) so it
  matches what `rich.Panel` actually renders in a terminal.

No functional changes. Same 30/30 test suite, same five direct-SDK
checks (TS001/003/010/011/020), same four LangChain checks
(TS101/102/103/104). Pricing table unchanged.

## [0.2.0] - 2026-04-30

First feature release after 0.1.0. Extends the addressable surface from
"direct anthropic/openai SDK calls" to also cover the LangChain
wrappers most production Python LLM code uses today.

(0.1.1 was prepared for a docs-only republish but never uploaded; its
changes are folded into 0.2.0 below.)

### Added
- **TS101 (HIGH)** — `langchain_openai.ChatOpenAI(...)` instantiated
  without `max_tokens`. Every downstream `.invoke()` / `.stream()` /
  `.batch()` inherits unbounded output cost.
- **TS102 (MEDIUM)** — `ChatOpenAI` or `ChatAnthropic` constructed with
  `max_tokens > 8000`. Same copy-paste-default risk as TS011, but at
  the LangChain construction site.
- **TS103 (HIGH)** — `AgentExecutor(...)` instantiated with
  `max_iterations=None`. The single highest-impact cost bug we know
  how to detect statically: a stuck session with no loop cap can cost
  $1,000–$5,000 in tokens (documented in 2026 production incidents).
- **TS104 (MEDIUM)** — `AgentExecutor(...)` with `max_iterations > 50`,
  the "bumped the cap as a workaround" anti-pattern. At ~$0.10/turn,
  200 iterations means $20+ per stuck session.
- 7 new tests + 6 new fixtures covering all four LangChain checks.
  Total suite: **30/30 passing**.

### Changed
- README expanded to describe the LangChain surface; checks table
  shows which surface each rule applies to.
- "What this tool deliberately does NOT do" updated — the doctor now
  recognises ChatAnthropic / ChatOpenAI constructors. Other wrappers
  (LiteLLM, OpenRouter, raw HTTP) still invisible.
- Public-prose generalised to remove specific OSS-project naming.
  Previous wording ("an OSS Claude Code memory plugin shipped this bug
  to prod") replaced with neutral "observed in shipped production LLM
  code" framing.
- Self-audit content inlined into the README so it's visible on PyPI
  without needing to click through to a private repository.
- Project URLs in `pyproject.toml` removed while the source repository
  is private (was previously linking to URLs that 404 for the public).

### Fixed
- BOM-prefixed files no longer crash the scanner (already shipped in
  0.1.0; previously documented incorrectly).
- Removed dangling `../docs/summry.md` reference that shipped in 0.1.0.

## [0.1.0] - 2026-04-30

Initial release. The "doctor" CLI: static analysis for Python codebases that
call Anthropic or OpenAI directly, surfacing the cost-leak patterns most
likely to be quietly burning money in production.

### Added
- `llmdoctor doctor <path>` CLI with pretty terminal output, `--json`
  mode for CI, and `--fail-on {HIGH,MEDIUM,LOW}` for build gates.
- Five built-in checks:
  - **TS001** (HIGH) — dynamic content placed before a `cache_control`
    marker, silently invalidating Anthropic's prompt cache on every call.
  - **TS003** (MEDIUM) — large static system prompt with no
    `cache_control` (missed cache opportunity).
  - **TS010** (HIGH) — OpenAI call with no `max_tokens` /
    `max_completion_tokens` cap.
  - **TS011** (MEDIUM) — `max_tokens` set above 8000 (likely a
    copy-paste default).
  - **TS020** (MEDIUM) — premium model on a tiny prompt.
- Per-issue cost-impact estimates with explicit assumptions printed
  inline. Pricing table in [`src/llmdoctor/pricing.py`](src/llmdoctor/pricing.py)
  verified against provider pages on 2026-04-30.
- Suppression comments: `# llmdoctor: ignore TS001` (or `ignore ALL`)
  on the offending line.
- Hardening for real-world repos: UTF-8 BOM handling, 5 MB file-size
  cap (configurable via `LLMDOCTOR_MAX_FILE_BYTES`), `RecursionError`
  guard, per-checker exception isolation, rich-markup escaping for
  user-controlled strings.
- 23-test pytest suite covering correctness fixtures, input safety,
  reporter safety, and CLI surface.

### Known limitations
- Python only; TypeScript / JS not yet supported.
- Only direct `anthropic` / `openai` SDK calls; LangChain / LiteLLM /
  raw HTTP not yet recognised.
- Cost estimates are heuristic with assumptions printed inline — never
  invoice predictions.
- See [`AUDIT.md`](AUDIT.md) (added in 0.1.1) for the full self-audit
  including documented false negatives and future-work risks.

<!-- Comparison links removed while the source repository is private. -->
<!-- Re-add when the repository is made public:                       -->
<!-- [Unreleased]: https://github.com/Shahriyar-Khan27/llm-doctor/compare/v0.1.1...HEAD -->
<!-- [0.1.1]: https://github.com/Shahriyar-Khan27/llm-doctor/compare/v0.1.0...v0.1.1   -->
<!-- [0.1.0]: https://github.com/Shahriyar-Khan27/llm-doctor/releases/tag/v0.1.0       -->
