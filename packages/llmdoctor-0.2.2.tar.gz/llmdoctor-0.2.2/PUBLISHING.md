# Publishing llmdoctor

This is a contributor / maintainer guide. End users do not need to read it.

## One-time setup

### 1. Pick a PyPI account / org

PyPI does not let two projects share a name, and `llmdoctor` is currently
unclaimed (verify on https://pypi.org/project/llmdoctor before the first
push). Once we publish 0.1.0 the name is ours.

### 2. Configure trusted publishing (preferred — no API tokens stored)

This is the modern way. PyPI verifies the upload by checking that it came
from a specific GitHub repository + workflow file, not by checking a stored
API token. It is the safer default.

1. Go to https://pypi.org/manage/account/publishing/
2. Add a new "pending publisher":
   - **PyPI project name:** `llmdoctor`
   - **Owner / repository:** `Shahriyar-Khan27/llm-doctor`
   - **Workflow filename:** `publish.yml`
   - **Environment name:** `pypi`
3. In your GitHub repository settings, create an Environment named `pypi`.
   Optionally add required reviewers or a deployment branch rule.

After the first successful publish, the "pending" publisher becomes a
regular publisher.

### 3. (Fallback) API token, if you cannot use trusted publishing

1. Generate a project-scoped token at
   https://pypi.org/manage/account/token/
2. Store it as a GitHub Actions secret named `PYPI_API_TOKEN`.
3. Replace the trusted-publishing step in `.github/workflows/publish.yml`
   with:
   ```yaml
       - name: Publish via API token
         uses: pypa/gh-action-pypi-publish@release/v1
         with:
           password: ${{ secrets.PYPI_API_TOKEN }}
   ```

## Cutting a release

The full flow, end to end:

```bash
# 1. Make sure the working tree is clean and tests pass
git status
pytest

# 2. Bump the version in two places:
#    - pyproject.toml                  -> [project] version
#    - src/llmdoctor/__init__.py      -> __version__
# (Both must match. The CI will not catch a mismatch automatically yet —
#  see "Future hardening" below.)

# 3. Update CHANGELOG.md: move items from [Unreleased] to a new dated section.

# 4. Commit
git add pyproject.toml src/llmdoctor/__init__.py CHANGELOG.md
git commit -m "release: 0.1.1"

# 5. Tag the release
git tag -a v0.1.1 -m "llmdoctor 0.1.1"
git push origin main --tags

# 6. Create a GitHub Release from the tag.
#    The publish.yml workflow fires on `release: published`,
#    builds the sdist + wheel, runs twine check, and publishes to PyPI.

# 7. Verify
pip install --upgrade llmdoctor
llmdoctor --version    # should print 0.1.1
```

## Building locally (dry run before tagging)

```bash
# Clean
rm -rf dist build *.egg-info

# Build
python -m pip install --upgrade build twine
python -m build

# Verify metadata
python -m twine check dist/*

# Inspect contents
python -m zipfile -l dist/llmdoctor-*.whl
```

The wheel must contain only `src/llmdoctor/...` and the dist-info dir.
If you see `tests/`, `fixtures/`, or `__pycache__/` inside the wheel,
something is wrong with the build configuration.

## Test-PyPI dry run

For a paranoid first release, push to TestPyPI first:

```bash
python -m twine upload --repository testpypi dist/*
pip install --index-url https://test.pypi.org/simple/ llmdoctor
```

If that works, do the real upload via the GitHub Release flow above.

## Future hardening (not blocking 0.1.0)

- **Version-mismatch CI check.** Add a job that fails if
  `pyproject.toml` `version` ≠ `llmdoctor.__version__` ≠ git tag.
- **Pricing-table freshness check.** Quarterly Action that fetches the
  Anthropic / OpenAI pricing pages and opens a PR if the numbers in
  `pricing.py` look stale.
- **Wheel content lockdown.** Add a CI step that asserts the wheel's
  RECORD file contents match an expected list (no surprise files).
