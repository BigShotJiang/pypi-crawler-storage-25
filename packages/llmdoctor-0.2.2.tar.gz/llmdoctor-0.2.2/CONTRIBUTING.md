# Contributing

Thanks for considering a contribution. The bar for this project is
**measurement honesty over feature breadth**: a check that false-positives
or shows wrong cost numbers does more harm than good. Read this before
opening a PR.

## Setup

```bash
git clone https://github.com/Shahriyar-Khan27/llm-doctor
cd llmdoctor
pip install -e ".[dev]"
pytest
```

All 23 tests should pass.

## What kind of changes we welcome

Highest priority:
1. **New checks** that catch a concrete, verifiable cost-leak pattern. A new
   check needs:
   - A unique stable code (`TSxxx`)
   - A good fixture (`tests/fixtures/<descriptive>.py`) AND a
     deliberately-correct counter-fixture
   - Tests in `tests/test_<check>.py` proving both fire/no-fire cases
   - Cost estimate logic that returns `None` when the model is unknown
     rather than guessing
2. **Fixes for false positives** — open an issue first with the offending
   code snippet so we can lock in a regression test before we change the
   check.
3. **Adapters** for LangChain / LlamaIndex / LiteLLM call patterns. These
   should live in their own module (`src/llmdoctor/checkers/langchain.py`
   etc) and be opt-in via a CLI flag for the first release.

Lower priority:
- New CLI flags that complicate the surface
- Refactors that don't fix a bug or unlock a check

## What we won't merge without strong justification

- Network access of any kind (the tool stays fully offline).
- Telemetry or "anonymous usage stats" (breaks the trust contract).
- Speculative features without a test or a real-world example.
- Changes that ship without updating `pricing.py` when adding a model.

## Style

- Type hints on new code. We're not strict but we follow them.
- One issue per checker rule; subordinate rules can share a checker class
  (see `anthropic_cache.py` for the precedent — TS001 and TS003 in one
  module).
- Public functions get a docstring. Private helpers get a one-liner
  if non-obvious, nothing if obvious.
- No emoji in code or commits.

## Pricing-table changes

The table in `src/llmdoctor/pricing.py` is the single source of truth for
cost estimates. If you add or update a model:

1. Verify the price on the provider's official pricing page.
2. Update the comment at the top of the file with the verification date.
3. Add an entry to the table.
4. If the model has a cache-read price, set `cache_read_per_mtok` —
   otherwise leave it `None` and the estimate code falls back gracefully.

## Reporting an issue

A good bug report:
- The offending code (smallest reproduction)
- The output the doctor gave you
- The output you expected
- `python --version` and `llmdoctor --version`

A great bug report includes a failing test in PR form.
