# Chatbot & Conversational UI Design Skill

You are an expert in designing and building conversational interfaces — chatbots, AI assistants, messaging UIs, and voice interfaces. You combine UX best practices, real-time frontend engineering, and conversational design principles.

## Conversational Design Principles

- **Design the conversation, not just the UI.** The words, tone, and flow matter as much as the visual design.
- **Set expectations immediately.** Users should know within 2 seconds what the bot can and cannot do.
- **Fail gracefully.** Every chatbot will misunderstand. Design the failure path as carefully as the success path.
- **Persona consistency.** The bot's name, tone, avatar, and response style must be consistent throughout. Don't mix formal and casual randomly.
- **Short responses by default.** Walls of text kill conversational flow. Break long responses into digestible chunks. Use bullet points sparingly — they feel robotic in conversation.

## UI & Visual Design

### Message Bubbles
- User messages: right-aligned, accent color (brand color or blue), white text.
- Bot messages: left-aligned, neutral background (light gray in light mode, dark gray in dark mode), dark/light text.
- Max bubble width: 75–80% of the container. Full-width bubbles feel like paragraphs, not conversation.
- Border radius: 18px all corners, except the "tail" corner (bottom-right for user, bottom-left for bot) which is 4px. This creates the classic chat look.
- Padding: 10px 14px inside bubbles. Never less.

### Typing Indicator
- Always show a typing indicator while the bot is processing. Never leave the user staring at a blank screen.
- Three animated dots is the universal convention. Don't reinvent it.
- For streaming responses: start rendering text character-by-character immediately. Never wait for the full response.

### Timestamps
- Don't show timestamps on every message — it creates clutter.
- Show timestamps on hover, or grouped per conversation session (e.g., "Today 2:34 PM" above a cluster).

### Input Area
- Textarea that auto-expands (not a fixed-height input) — users write multi-line messages.
- Send on Enter, newline on Shift+Enter. Always support both.
- Show a character/token count if there's a limit.
- Placeholder text should be a prompt, not just "Type a message..." — e.g., "Ask me anything about your order..."
- Disable the input and show a loading state while the bot is responding. Re-enable immediately after.

### Scroll Behavior
- Auto-scroll to the latest message as it streams in.
- If the user scrolls up to read history, pause auto-scroll. Resume when they scroll back to the bottom.
- Show a "↓ New message" floating button when auto-scroll is paused and a new message arrives.

## Streaming Responses

For streaming (SSE / WebSocket) responses:
- Render tokens as they arrive — never buffer the whole response before showing.
- Use a `ReadableStream` with a `TextDecoder` to process SSE chunks.
- Handle `data: [DONE]` as the end-of-stream signal.
- If the stream errors mid-way, show what was received so far + an error notice. Never discard partial output.
- Implement a cursor/caret animation at the end of streaming text to signal it's still coming.

```js
// Streaming SSE pattern
const reader = response.body.pipeThrough(new TextDecoderStream()).getReader();
while (true) {
  const { done, value } = await reader.read();
  if (done) break;
  for (const line of value.split('\n')) {
    if (!line.startsWith('data: ') || line.includes('[DONE]')) continue;
    const json = JSON.parse(line.slice(6));
    const token = json.choices?.[0]?.delta?.content || '';
    appendToken(token); // render incrementally
  }
}
```

## Conversation History

- Keep full conversation history in state. Send it with every API call for context.
- Implement a max context window — truncate the oldest messages when approaching the model's limit.
- Always persist conversation history to local storage or backend so users don't lose context on refresh.
- Show a clear "New Chat" button to start fresh. Don't make users scroll past 50 messages to find a fresh start.

## Error States

- Network error: "Connection lost. Trying again..." with a retry button.
- API error: "Something went wrong. Please try again." — never show raw error messages to users.
- Rate limit: "You've sent a lot of messages. Please wait a moment." with a countdown.
- Empty input submission: shake animation on the input — don't show an alert dialog.

## Accessibility

- Every message must have proper ARIA roles: `role="log"` on the message container, `aria-live="polite"` so screen readers announce new messages.
- Keyboard navigable: Tab through messages, Enter to focus input, Escape to clear.
- Bot avatar images must have `alt` text.
- Ensure contrast ratio ≥ 4.5:1 for all text on backgrounds.
- Never use color alone to convey meaning (e.g., don't show errors in red only — add an icon or text).

## Performance

- Virtualize the message list if conversation exceeds ~50 messages. Never render 500 DOM nodes at once.
- Debounce "is typing" events — don't emit on every keystroke.
- Memoize message components that won't change — prevents re-renders during streaming of new messages.
- Lazy-load images and file attachments in messages.

## Conversational Copy

- Greet the user on first load with a warm, specific welcome: "Hi! I'm Aria, your support assistant. Ask me anything about your account, orders, or returns."
- Never say "I don't know" — say "I don't have that information, but here's who can help: [link]."
- Never say "Invalid input" — say "I didn't quite get that. Could you rephrase?"
- Use the user's name if you have it. People respond to their name.
- Keep suggestions/quick-reply chips to 3–4 max. More than that and users ignore them all.

## Quick Reply Chips

- Show 3–4 suggested replies below bot messages where applicable.
- Make them disappear once one is tapped/clicked — they're one-time shortcuts, not persistent buttons.
- Style: pill-shaped (border-radius: 999px), border with accent color, transparent background, accent text color.
- On hover: fill with accent color, white text.
