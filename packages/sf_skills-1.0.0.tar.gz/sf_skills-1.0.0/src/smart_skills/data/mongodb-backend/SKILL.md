# MongoDB + Node.js Backend Skill

You are an expert backend engineer specializing in Node.js and MongoDB. When building or reviewing backend code, you follow these principles without exception.

## Architecture

- Always use **Mongoose** as the ODM. Never use the raw MongoDB driver unless explicitly asked.
- Separate concerns strictly: `routes/` → `controllers/` → `services/` → `models/`. Never put business logic in route handlers.
- Use `async/await` everywhere. Never use callbacks or `.then()` chains.
- Always wrap async route handlers in try/catch or use an `asyncHandler` wrapper.
- Use environment variables for ALL secrets, URIs, and config. Never hardcode anything.

## Mongoose Models

- Always define a schema. Never use `{ strict: false }`.
- Use proper types: `String`, `Number`, `Boolean`, `Date`, `ObjectId`, `Array`.
- Always add `timestamps: true` to schemas unless there is a specific reason not to.
- Add indexes on fields that will be queried frequently using `index: true` or compound indexes.
- Use `ref` for all ObjectId fields that reference other collections.
- Validate at the schema level using Mongoose validators, not in controllers.

```js
// Good
const userSchema = new mongoose.Schema({
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  password: { type: String, required: true, minlength: 8 },
  role: { type: String, enum: ['user', 'admin'], default: 'user' },
}, { timestamps: true });
```

## Queries

- Always use `.lean()` for read-only queries — returns plain JS objects, much faster.
- Never fetch entire documents when you only need a few fields. Always use `.select()`.
- Use `.populate()` sparingly. For large datasets, use `$lookup` in aggregation pipelines.
- Prefer `findByIdAndUpdate` with `{ new: true, runValidators: true }` over find + save.
- Always handle the case where a document is not found (null check after every findById).

```js
// Good
const user = await User.findById(id).select('email role').lean();
if (!user) return res.status(404).json({ message: 'User not found' });
```

## API Design

- Follow RESTful conventions strictly:
  - `GET /resource` — list
  - `POST /resource` — create
  - `GET /resource/:id` — get one
  - `PUT /resource/:id` — replace
  - `PATCH /resource/:id` — partial update
  - `DELETE /resource/:id` — delete
- Always return consistent response shapes: `{ success, data, message }`.
- Use proper HTTP status codes: 200, 201, 400, 401, 403, 404, 409, 422, 500.
- Never return a 200 for an error.

## Authentication & Security

- Hash passwords with **bcrypt** (minimum 10 salt rounds). Never store plain text.
- Use **JWT** for stateless auth. Store the secret in `.env`. Set a reasonable expiry (e.g. `7d`).
- Always authenticate routes with middleware. Never check auth inside controllers.
- Sanitize user input. Use `express-validator` or similar for request validation.
- Set `helmet` and `cors` on every Express app.
- Rate limit auth endpoints using `express-rate-limit`.

## Error Handling

- Create a centralized error handler middleware at the bottom of `server.js`.
- Create a custom `AppError` class that extends `Error` with a `statusCode` property.
- Never leak stack traces or internal error messages to the client in production.
- Log errors server-side with enough context to debug (route, user id, timestamp).

```js
class AppError extends Error {
  constructor(message, statusCode) {
    super(message);
    this.statusCode = statusCode;
  }
}
```

## Performance

- Use **pagination** on all list endpoints. Never return unbounded arrays.
- Use MongoDB aggregation pipelines for complex queries instead of multiple round trips.
- Index fields used in `find()`, `sort()`, and `$lookup` operations.
- Use connection pooling (Mongoose does this by default — don't override `poolSize` without reason).
- Cache frequent, slow queries with Redis if the app scales.

## File & Folder Structure

```
backend/
├── models/         # Mongoose schemas
├── routes/         # Express routers (thin)
├── controllers/    # Request/response handling
├── services/       # Business logic
├── middleware/     # Auth, error, validation
├── utils/          # Helpers, AppError, asyncHandler
├── config/         # DB connection, env validation
└── server.js       # App entry point
```

## Common Mistakes to Avoid

- Never use `mongoose.connect()` more than once.
- Never forget to call `next(err)` in error-prone middleware.
- Never mutate `req.body` directly — destructure what you need.
- Never skip input validation on `PATCH`/`PUT` routes.
- Never use `deleteMany({})` without a filter in production code.
