import os
import re
import json
import urllib.request
from collections import Counter
from pathlib import Path

# Automatically locate the internal "data" folder packaged with the library
PACKAGE_DIR = Path(__file__).parent
DATA_DIR = PACKAGE_DIR / "data"

class Skill:
    def __init__(self, filepath, name, description, content):
        self.filepath = filepath
        self.name = name
        self.description = description
        self.content = content
        self.keywords = set(re.findall(r'\b\w+\b', (name + " " + description).lower()))

class SkillManager:
    def __init__(self):
        self.skills = []
        if not DATA_DIR.exists():
            print(f"Warning: Internal skills data directory not found at {DATA_DIR}")
        else:
            self.load_all_skills()

    def load_all_skills(self):
        """Recursively loads all markdown skills packaged inside the library."""
        for root, _, files in os.walk(DATA_DIR):
            for file in files:
                if file.endswith((".md", ".txt")):
                    filepath = os.path.join(root, file)
                    self._parse_skill_file(filepath)

    def _parse_skill_file(self, filepath):
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()

            name = os.path.basename(filepath).replace('.md', '')
            description = ""

            # Try to parse YAML frontmatter
            frontmatter_match = re.match(r'^---\s*(.*?)\s*---', content, re.DOTALL)
            if frontmatter_match:
                fm_text = frontmatter_match.group(1)
                name_match = re.search(r'name:\s*(.+)', fm_text)
                if name_match: name = name_match.group(1).strip().strip('"\'')
                
                desc_match = re.search(r'description:\s*(.+)', fm_text)
                if desc_match: description = desc_match.group(1).strip().strip('"\'')

            self.skills.append(Skill(filepath, name, description, content))
        except Exception as e:
            pass # Silently skip unreadable files

    def useSkills(self, user_prompt, min_k=1, max_k=4):
        """Selects min 1 and max 4 skills, returning the formatted system prompt payload."""
        if not self.skills:
            return ""

        prompt_words = re.findall(r'\b\w+\b', user_prompt.lower())
        prompt_counter = Counter(prompt_words)

        scored_skills = []
        for skill in self.skills:
            score = sum(prompt_counter[word] for word in skill.keywords if word in prompt_counter)
            if skill.name.lower() in user_prompt.lower():
                score += 5 
            
            scored_skills.append((score, skill))

        # Sort by highest score first
        scored_skills.sort(key=lambda x: x[0], reverse=True)
        
        # Filter to ones that actually triggered a match
        valid_skills = [skill for score, skill in scored_skills if score > 0][:max_k]
        
        # Ensure we meet the minimum requirement (at least 1)
        if len(valid_skills) < min_k:
            needed = min_k - len(valid_skills)
            remaining = [skill for score, skill in scored_skills if skill not in valid_skills]
            valid_skills.extend(remaining[:needed])

        # Safety clamp to max_k
        selected_skills = valid_skills[:max_k]

        if not selected_skills:
            return "" 

        payload = "\n\n### RELEVANT AI SKILLS ###\n"
        payload += "The user's query triggered the following specific skills/guidelines. Follow them strictly:\n\n"
        
        for skill in selected_skills:
            payload += f"==== SKILL: {skill.name} ====\n"
            payload += skill.content + "\n\n"
            
        return payload

# Global helper functions
_default_manager = None

def useSkills(prompt, min_skills=1, max_skills=4):
    global _default_manager
    if _default_manager is None:
        _default_manager = SkillManager()
    return _default_manager.useSkills(prompt, min_k=min_skills, max_k=max_skills)

def send_opr(prompt, api_key=None, model="google/gemma-4-31b-it:free", min_skills=1, max_skills=4):
    """
    Automatically fetches the right skills and sends a request to OpenRouter.
    """
    api_key = api_key or os.environ.get("OPENROUTER_API_KEY")
    if not api_key:
        raise ValueError("OpenRouter API key is required.")
        
    # Ensure key doesn't have accidental whitespace
    api_key = api_key.strip()
        
    skills_context = useSkills(prompt, min_skills=min_skills, max_skills=max_skills)
    system_prompt = "You are an expert AI assistant. Follow these skills strictly:\n" + skills_context
    
    url = "https://openrouter.ai/api/v1/chat/completions"
    
    # Improved headers to avoid 403 Forbidden
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "HTTP-Referer": "http://localhost:3000", # Generic referer often works better
        "X-Title": "Smart Skills Library",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }
    
    data = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": prompt}
        ]
    }
    
    req = urllib.request.Request(
        url, 
        data=json.dumps(data).encode('utf-8'), 
        headers=headers, 
        method='POST'
    )
    
    try:
        with urllib.request.urlopen(req) as response:
            result = json.loads(response.read().decode('utf-8'))
            if 'choices' in result:
                return result['choices'][0]['message']['content']
            else:
                return f"API Error: {json.dumps(result)}"
    except urllib.error.HTTPError as e:
        error_body = e.read().decode('utf-8')
        return f"HTTP Error {e.code}: {error_body}"
    except Exception as e:
        return f"Connection Error: {str(e)}"