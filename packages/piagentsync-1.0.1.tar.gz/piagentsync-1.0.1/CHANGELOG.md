# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.1] - 2026-03-29
### Fixed
- fix(cli): add git push command after commit in vault
### Documentation
- docs(readme): document PIA-015 fixes, auto-commit behavior, watch status, and test names
## [1.0.0] - 2026-03-29
### Added
- feat(pia-013): add status --diff flag for line-by-line file comparison
- feat(pia-012): add watch command for commit-triggered vault polling
- feat(pia-011): add new-project command to scaffold projects
### Fixed
- fix(pia-015): workspace-wins writes to vault and diff shows full paths
- fix(pia-014): sync --all now includes global agents and improves conflict messaging
### Chores
- chore(release): bump version to 0.5.1-rc.4
- chore(release): bump version to 0.5.1-rc.3
- chore(release): bump version to 0.5.1-rc.2
- chore(release): bump version to 0.5.1-rc.1
## [0.5.1-rc.4] - 2026-03-29
### Fixed
- fix(pia-015): workspace-wins writes to vault and diff shows full paths
## [0.5.1-rc.3] - 2026-03-29
### Fixed
- fix(pia-014): sync --all now includes global agents and improves conflict messaging
## [0.5.1-rc.2] - 2026-03-29
### Added
- feat(pia-013): add status --diff flag for line-by-line file comparison
## [0.5.1-rc.1] - 2026-03-29
### Added
- feat(pia-012): add watch command for commit-triggered vault polling
- feat(pia-011): add new-project command to scaffold projects
## [0.5.0] - 2026-03-29
### Added
- feat(pia-010): add new-agent command to scaffold agent files
- feat(pia-008): add doctor command to validate full system setup
- feat(pia-009): auto git pull vault before pull/push/sync operations
### Fixed
- fix: separate critical and optional checks in doctor command
## [0.4.0] - 2026-03-29
### Added
- feat(pia-007): auto-commit vault with conventional commit message
- feat(sync): expose --strategy flag for conflict resolution
- feat(status): add --global flag to show global agent sync state
- feat(sync): implement bidirectional sync with conflict detection
### Chores
- chore(release): bump version to 0.3.1-rc.4
- chore(status): default to showing global agents
- chore(release): bump version to 0.3.1-rc.3
- chore: update uv.lock after version bump
- chore(release): bump version to 0.3.1-rc.2
- chore(release): bump version to 0.3.1-rc.1
## [0.3.1-rc.4] - 2026-03-29
### Added
- feat(sync): expose --strategy flag for conflict resolution
### Chores
- chore(status): default to showing global agents
## [0.3.1-rc.3] - 2026-03-29
### Added
- feat(status): add --global flag to show global agent sync state
### Chores
- chore: update uv.lock after version bump
## [0.3.1-rc.2] - 2026-03-28
## [0.3.1-rc.1] - 2026-03-27
### Added
- feat(sync): implement bidirectional sync with conflict detection
## [0.3.0] - 2026-03-27
### Added
- feat(push): implement push command to sync workspace back to vault
### Documentation
- docs(readme): document push command and mypy setup
### Chores
- chore(release): bump version to 0.2.2-rc.1
- chore: add mypy strict type checking to entire codebase
- chore(ci): remove pull_request trigger from CI configuration
## [0.2.2-rc.1] - 2026-03-27
### Added
- feat(push): implement push command to sync workspace back to vault
### Chores
- chore: add mypy strict type checking to entire codebase
- chore(ci): remove pull_request trigger from CI configuration
## [0.2.1] - 2026-03-27
### Added
- feat(bootstrap): merge MCP config into existing opencode.json
## [0.2.0] - 2026-03-27
### Added
- feat(bootstrap): add machine bootstrap command
### Chores
- chore: add pre-commit hooks and fix formatting
## [0.1.0] - 2026-03-27
### Added
- feat(ci): combine tag and publish into single release workflow with GitHub Release
### Fixed
- fix(ci): uv publish does not support --no-build flag (remove it)
### Documentation
- docs: update publishing workflow to use release.yml
### Chores
- chore(release): bump version to 0.0.3-rc.2
- chore(release): bump version to 0.0.3-rc.1
## [0.0.3-rc.2] - 2026-03-27
### Fixed
- fix(ci): uv publish does not support --no-build flag (remove it)
## [0.0.3-rc.1] - 2026-03-27
### Added
- feat(ci): combine tag and publish into single release workflow with GitHub Release
### Documentation
- docs: update publishing workflow to use release.yml
## [0.0.2] - 2026-03-27
## [0.0.1] - 2026-03-27
### Added
- feat(ci): support numbered RC tags and fix commit ranges
- feat(ci): automate changelog generation and remove test gate from publish
- feat(piagentsync): initial implementation with full test suite
### Fixed
- fix(ci): prevent duplicate tags by checking existing tags
### Tests
- test(cli): make version check dynamic using package __version__
### Chores
- chore(release): bump version to 0.0.1-rc
- chore(release): bump version to 0.0.1-rc
- chore(release): bump version to 0.0.1-rc
### CI/CD
- ci: add GitHub Actions workflows for CI, tagging, and publishing
### Other
- Initial commit
## [0.0.1-rc] - 2026-03-27
### Added
- feat(ci): automate changelog generation and remove test gate from publish
- feat(piagentsync): initial implementation with full test suite
### Fixed
- fix(ci): prevent duplicate tags by checking existing tags
### Tests
- test(cli): make version check dynamic using package __version__
### Chores
- chore(release): bump version to 0.0.1-rc
- chore(release): bump version to 0.0.1-rc
### CI/CD
- ci: add GitHub Actions workflows for CI, tagging, and publishing
### Other
- Initial commit
## [0.0.1-rc] - 2026-03-27
### Added
- feat(ci): automate changelog generation and remove test gate from publish
- feat(piagentsync): initial implementation with full test suite
### Tests
- test(cli): make version check dynamic using package __version__
### Chores
- chore(release): bump version to 0.0.1-rc
### CI/CD
- ci: add GitHub Actions workflows for CI, tagging, and publishing
### Other
- Initial commit
## [0.1.0] - 2026-03-27

### Added
- Initial release of piagentsync
- Sync OpenCode agents and skills from Obsidian vault to workspace
- CLI commands: `pull`, `status`, `init`
- Support for global agents
- Dry-run mode
- Full TDD implementation with pytest
