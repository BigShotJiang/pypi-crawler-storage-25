"""CLI entry point for piagentsync."""

import hashlib
import json
import re
import subprocess
import time
from pathlib import Path

import typer
from pydantic import ValidationError
from rich.console import Console
from rich.table import Table

from . import __version__
from .config import Settings, ensure_vault_exists, get_settings
from .errors import (
    ManifestNotFoundError,
    ManifestParseError,
    PiAgentSyncError,
    VaultNotFoundError,
)
from .manifest import parse_manifest
from .models import ConflictResult, ProjectManifest, SyncEntry, SyncResult, SyncStrategy
from .sync import (
    collect_entries,
    collect_global_entries,
    collect_push_entries,
    collect_push_global_entries,
    copy_file_sync,
    sync_entries,
    sync_entries_with_conflicts,
)

app = typer.Typer()
console = Console()


def _auto_commit_vault(vault_path: Path, message: str) -> tuple[bool, str]:
    """Auto-commit changes to vault with conventional commit message.

    Args:
        vault_path: Path to vault git repository
        message: Conventional commit message

    Returns:
        Tuple of (success: bool, status_msg: str)
    """
    try:
        # Check if there are changes to commit
        result = subprocess.run(
            ["git", "status", "--porcelain"],
            cwd=vault_path,
            capture_output=True,
            text=True,
            check=True,
        )

        if not result.stdout.strip():
            return True, "No changes to commit"

        # Stage all changes
        subprocess.run(
            ["git", "add", "-A"],
            cwd=vault_path,
            capture_output=True,
            check=True,
        )

        # Commit with message
        subprocess.run(
            ["git", "commit", "-m", message],
            cwd=vault_path,
            capture_output=True,
            check=True,
        )
        subprocess.run(
            ["git", "push"],
            cwd=vault_path,
            capture_output=True,
            check=True,
        )
        return True, f"Committed: {message}"
    except subprocess.CalledProcessError as e:
        return False, f"Git error: {e}"
    except Exception as e:
        return False, f"Unexpected error during commit: {e}"


def _git_pull_vault(vault_path: Path) -> tuple[bool, str]:
    """Pull latest changes from vault git repository.

    Args:
        vault_path: Path to vault git repository

    Returns:
        Tuple of (success: bool, status_msg: str)
    """
    try:
        result = subprocess.run(
            ["git", "pull"],
            cwd=vault_path,
            capture_output=True,
            text=True,
            check=True,
        )

        if result.stdout.strip():
            return True, result.stdout.strip()
        return True, "Already up to date"
    except subprocess.CalledProcessError as e:
        return False, f"Git pull error: {e}"
    except Exception as e:
        return False, f"Unexpected error during git pull: {e}"


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    version: bool = typer.Option(False, "--version", help="Print version and exit"),
) -> None:
    if version:
        console.print(f"piagentsync {__version__}")
        raise typer.Exit(0)


@app.command()
def pull(
    project: str | None = typer.Argument(None, help="Project name"),
    dry_run: bool = typer.Option(
        False, "--dry-run", "--no-dry-run", help="Preview changes without writing"
    ),
    global_sync: bool = typer.Option(
        False, "--global", "--no-global", help="Also sync global agents"
    ),
    all_projects: bool = typer.Option(
        False, "--all", "--no-all", help="Sync all discovered projects"
    ),
) -> None:
    """Sync projects from vault to workspace."""
    if project is None and not all_projects:
        console.print("[red]Error:[/] Must specify a project name or use --all flag")
        raise typer.Exit(1)
    if project is not None and all_projects:
        console.print("[red]Error:[/] Cannot specify both project and --all")
        raise typer.Exit(1)

    settings = get_settings()
    try:
        ensure_vault_exists(settings)
    except VaultNotFoundError as e:
        console.print(f"[red]{e}[/]")
        raise typer.Exit(1)

    # Git pull vault before operation
    success, status = _git_pull_vault(settings.vault_path)
    if success:
        console.print(f"[dim]✓ Pulled vault:[/] {status}")
    else:
        console.print(f"[yellow]Warning:[/] Git pull failed - {status}")

    if all_projects:
        projects_dir = settings.vault_path / "projects"
        if not projects_dir.exists():
            console.print("[yellow]No projects found (directory missing)[/]")
            raise typer.Exit(0)
        project_names = [p.name for p in projects_dir.iterdir() if p.is_dir()]
        any_errors = False
        for proj_name in project_names:
            try:
                _sync_single_project(proj_name, dry_run, global_sync, settings)
            except typer.Exit:
                any_errors = True
        if any_errors:
            raise typer.Exit(1)
    else:
        assert project is not None  # project is guaranteed by earlier check
        _sync_single_project(project, dry_run, global_sync, settings)


@app.command()
def push(
    project: str | None = typer.Argument(None, help="Project name"),
    dry_run: bool = typer.Option(
        False, "--dry-run", "--no-dry-run", help="Preview changes without writing"
    ),
    global_sync: bool = typer.Option(
        False, "--global", "--no-global", help="Also push global agents"
    ),
    all_projects: bool = typer.Option(
        False, "--all", "--no-all", help="Push all discovered projects"
    ),
) -> None:
    """Sync projects from workspace to vault.

    Pushes workspace .opencode/ directories back to vault.
    After push, commit changes manually: cd ~/vault && git add -A && git commit
    """
    if project is None and not all_projects:
        console.print("[red]Error:[/] Must specify a project name or use --all flag")
        raise typer.Exit(1)
    if project is not None and all_projects:
        console.print("[red]Error:[/] Cannot specify both project and --all")
        raise typer.Exit(1)

    settings = get_settings()
    try:
        ensure_vault_exists(settings)
    except VaultNotFoundError as e:
        console.print(f"[red]{e}[/]")
        raise typer.Exit(1)

    # Git pull vault before operation
    success, status = _git_pull_vault(settings.vault_path)
    if success:
        console.print(f"[dim]✓ Pulled vault:[/] {status}")
    else:
        console.print(f"[yellow]Warning:[/] Git pull failed - {status}")

    if all_projects:
        projects_dir = settings.vault_path / "projects"
        if not projects_dir.exists():
            console.print("[yellow]No projects found (directory missing)[/]")
            raise typer.Exit(0)
        project_names = [p.name for p in projects_dir.iterdir() if p.is_dir()]
        any_errors = False
        for proj_name in project_names:
            try:
                _push_single_project(proj_name, dry_run, global_sync, settings)
            except typer.Exit:
                any_errors = True
        if any_errors:
            raise typer.Exit(1)
    else:
        assert project is not None  # project is guaranteed by earlier check
        _push_single_project(project, dry_run, global_sync, settings)


def _sync_single_project(
    project: str, dry_run: bool, global_sync: bool, settings: Settings
) -> None:
    manifest_path = settings.vault_path / "projects" / project / "AGENTS.md"
    try:
        manifest = parse_manifest(manifest_path)
    except ManifestNotFoundError:
        console.print(f"[red]Manifest not found for project:[/] {project}")
        raise typer.Exit(1)
    except ManifestParseError as e:
        console.print(f"[red]Failed to parse manifest for project {project}:[/] {e}")
        raise typer.Exit(1)

    entries = collect_entries(manifest, settings)
    if global_sync:
        try:
            global_entries = collect_global_entries(settings)
            entries.extend(global_entries)
        except Exception as e:
            console.print(f"[yellow]Warning:[/] Failed to collect global agents: {e}")

    result = sync_entries(entries, dry_run=dry_run)
    if dry_run:
        console.print("[yellow]Dry run enabled; no files were written.[/]")
    _print_sync_result(result)
    if result.has_errors:
        raise typer.Exit(1)


def _push_single_project(
    project: str, dry_run: bool, global_sync: bool, settings: Settings
) -> None:
    """Push a single project from workspace to vault.

    Args:
        project: Project name.
        dry_run: If True, preview without writing.
        global_sync: If True, also push global agents.
        settings: Settings with vault and workspace paths.
    """
    manifest_path = settings.vault_path / "projects" / project / "AGENTS.md"
    try:
        manifest = parse_manifest(manifest_path)
    except ManifestNotFoundError:
        console.print(f"[red]Manifest not found for project:[/] {project}")
        raise typer.Exit(1)
    except ManifestParseError as e:
        console.print(f"[red]Failed to parse manifest for project {project}:[/] {e}")
        raise typer.Exit(1)

    entries = collect_push_entries(manifest, settings)
    if global_sync:
        try:
            global_entries = collect_push_global_entries(settings)
            entries.extend(global_entries)
        except Exception as e:
            console.print(f"[yellow]Warning:[/] Failed to collect global agents: {e}")

    result = sync_entries(entries, dry_run=dry_run)
    if dry_run:
        console.print("[yellow]Dry run enabled; no files were written.[/]")
    _print_sync_result(result)

    # Auto-commit if not dry run and no errors
    if not dry_run and not result.has_errors:
        commit_msg = f"feat(push): sync {project} from workspace to vault"
        if global_sync:
            commit_msg += " (including global agents)"
        success, status = _auto_commit_vault(settings.vault_path, commit_msg)
        if success:
            console.print(f"\n[green]✓ Vault committed:[/] {status}")
        else:
            console.print(f"\n[yellow]Warning:[/] Auto-commit failed - {status}")
            console.print(
                "Please commit manually: cd ~/vault && git add -A && git commit"
            )
    else:
        console.print(
            "\n[green]Done.[/] Commit the vault to persist:\n"
            "  cd ~/vault && git add -A && git commit && git push"
        )

    if result.has_errors:
        raise typer.Exit(1)


def _print_sync_result(result: SyncResult) -> None:
    table = Table()
    table.add_column("Name")
    table.add_column("Kind")
    table.add_column("Status")
    for entry in result.written:
        table.add_row(entry.name, entry.kind, "written")
    for entry in result.skipped:
        table.add_row(entry.name, entry.kind, "skipped")
    for entry, error_msg in result.errors:
        table.add_row(entry.name, entry.kind, f"error: {error_msg}")
    console.print(table)
    console.print(result.summary_line)


@app.command()
def sync(
    project: str | None = typer.Argument(None, help="Project name"),
    dry_run: bool = typer.Option(
        False, "--dry-run", "--no-dry-run", help="Preview changes without writing"
    ),
    strategy: str | None = typer.Option(
        None,
        "--strategy",
        help="Conflict resolution strategy: vault-wins, workspace-wins, or ask (default)",
    ),
    vault_wins: bool = typer.Option(
        False, "--vault-wins", help="[DEPRECATED] Use --strategy vault-wins instead"
    ),
    workspace_wins: bool = typer.Option(
        False,
        "--workspace-wins",
        help="[DEPRECATED] Use --strategy workspace-wins instead",
    ),
    global_sync: bool = typer.Option(
        False, "--global", "--no-global", help="Also sync global agents"
    ),
    all_projects: bool = typer.Option(
        False, "--all", "--no-all", help="Sync all discovered projects"
    ),
) -> None:
    """Bidirectional sync with conflict detection and resolution.

    Performs intelligent two-way sync:
    - Files unchanged in both locations: synced normally
    - Files changed only in one location: synced from that location
    - Files changed in both locations: resolved based on --strategy

    Strategies:
    - vault-wins: vault version always overwrites workspace
    - workspace-wins: workspace version is preserved
    - ask: report conflicts (default, requires manual review)

    Use: piagentsync sync <project> --strategy {vault-wins,workspace-wins,ask}
    """
    if project is None and not all_projects:
        console.print("[red]Error:[/] Must specify a project name or use --all flag")
        raise typer.Exit(1)
    if project is not None and all_projects:
        console.print("[red]Error:[/] Cannot specify both project and --all")
        raise typer.Exit(1)

    # Validate strategy vs legacy flags
    if strategy and (vault_wins or workspace_wins):
        console.print(
            "[red]Error:[/] Cannot specify both --strategy and legacy flags (--vault-wins/--workspace-wins)"
        )
        raise typer.Exit(1)

    # Legacy flag validation
    if vault_wins and workspace_wins:
        console.print(
            "[red]Error:[/] Cannot specify both --vault-wins and --workspace-wins"
        )
        raise typer.Exit(1)

    # Resolve strategy from new or legacy flags
    if strategy:
        strategy_lower = strategy.lower().replace("_", "-")
        if strategy_lower == "vault-wins":
            resolved_strategy = SyncStrategy.VAULT_WINS
        elif strategy_lower == "workspace-wins":
            resolved_strategy = SyncStrategy.WORKSPACE_WINS
        elif strategy_lower == "ask":
            resolved_strategy = SyncStrategy.ASK
        else:
            console.print(
                f"[red]Error:[/] Invalid strategy '{strategy}'. Must be: vault-wins, workspace-wins, or ask"
            )
            raise typer.Exit(1)
    elif vault_wins:
        resolved_strategy = SyncStrategy.VAULT_WINS
    elif workspace_wins:
        resolved_strategy = SyncStrategy.WORKSPACE_WINS
    else:
        resolved_strategy = SyncStrategy.ASK

    settings = get_settings()
    try:
        ensure_vault_exists(settings)
    except VaultNotFoundError as e:
        console.print(f"[red]{e}[/]")
        raise typer.Exit(1)

    # Git pull vault before operation
    success, status = _git_pull_vault(settings.vault_path)
    if success:
        console.print(f"[dim]✓ Pulled vault:[/] {status}")
    else:
        console.print(f"[yellow]Warning:[/] Git pull failed - {status}")

    if all_projects:
        projects_dir = settings.vault_path / "projects"
        if not projects_dir.exists():
            console.print("[yellow]No projects found (directory missing)[/]")
            raise typer.Exit(0)
        project_names = [p.name for p in projects_dir.iterdir() if p.is_dir()]
        any_errors = False
        for proj_name in project_names:
            try:
                _sync_single_project_bidirectional(
                    proj_name,
                    dry_run,
                    global_sync=True,
                    settings=settings,
                    strategy=resolved_strategy,
                )
            except typer.Exit:
                any_errors = True
        if any_errors:
            raise typer.Exit(1)
    else:
        assert project is not None  # project is guaranteed by earlier check
        _sync_single_project_bidirectional(
            project, dry_run, global_sync, settings, resolved_strategy
        )


def _sync_single_project_bidirectional(
    project: str,
    dry_run: bool,
    global_sync: bool,
    settings: Settings,
    strategy: SyncStrategy,
) -> None:
    """Perform bidirectional sync for a single project.

    Args:
        project: Project name.
        dry_run: If True, preview without writing.
        global_sync: If True, also sync global agents.
        settings: Settings with vault and workspace paths.
        strategy: Conflict resolution strategy.
    """
    manifest_path = settings.vault_path / "projects" / project / "AGENTS.md"
    try:
        manifest = parse_manifest(manifest_path)
    except ManifestNotFoundError:
        console.print(f"[red]Manifest not found for project:[/] {project}")
        raise typer.Exit(1)
    except ManifestParseError as e:
        console.print(f"[red]Failed to parse manifest for project {project}:[/] {e}")
        raise typer.Exit(1)

    entries = collect_entries(manifest, settings)
    if global_sync:
        try:
            global_entries = collect_global_entries(settings)
            entries.extend(global_entries)
        except Exception as e:
            console.print(f"[yellow]Warning:[/] Failed to collect global agents: {e}")

    result = sync_entries_with_conflicts(entries, strategy=strategy, dry_run=dry_run)
    if dry_run:
        console.print("[yellow]Dry run enabled; no files were written.[/]")
    _print_conflict_result(result)

    # Auto-commit vault changes if not dry run and no errors
    if not dry_run and not result.has_errors:
        commit_msg = f"feat(sync): bidirectional sync for {project}"
        if global_sync:
            commit_msg += " (including global agents)"
        success, status = _auto_commit_vault(settings.vault_path, commit_msg)
        if success:
            # Only print commit message if changes were actually committed
            if status != "No changes to commit":
                console.print(f"\n[green]✓ Vault committed:[/] {status}")
            else:
                console.print("\n[dim]No changes in vault to commit[/]")
        else:
            console.print(f"\n[yellow]Warning:[/] Auto-commit failed - {status}")
            console.print(
                "Please commit manually: cd ~/vault && git add -A && git commit"
            )

    if result.has_errors:
        raise typer.Exit(1)


def _print_conflict_result(result: ConflictResult) -> None:
    """Print the result of bidirectional sync with conflicts."""
    table = Table()
    table.add_column("Name")
    table.add_column("Kind")
    table.add_column("Status")
    for entry in result.synced:
        table.add_row(entry.name, entry.kind, "synced")
    for conflict in result.conflicts:
        table.add_row(conflict.name, conflict.kind, "[yellow]conflict[/]")
    for entry, error_msg in result.errors:
        table.add_row(entry.name, entry.kind, f"[red]error: {error_msg}[/]")
    console.print(table)

    # Print summary with conflict count
    summary = f"{len(result.synced)} synced"
    if result.conflicts:
        summary += f" · [yellow]{len(result.conflicts)} conflicts[/]"
    if result.errors:
        summary += f" · [red]{len(result.errors)} errors[/]"
    console.print(summary)

    # Print conflict resolution hints
    if result.conflicts:
        console.print(
            "\n[yellow]⚠ Conflicts detected (strategy: ask)[/]"
            "\nTo resolve, choose one strategy:"
        )
        console.print("  [green]piagentsync sync --strategy vault-wins[/]")
        console.print("    → vault version overwrites workspace")
        console.print("  [green]piagentsync sync --strategy workspace-wins[/]")
        console.print("    → workspace version is preserved")
        console.print("  [green]piagentsync status --diff[/]")
        console.print("    → inspect differences first")


@app.command()
def status(
    project: str | None = typer.Argument(None, help="Project name (optional)"),
    global_status: bool = typer.Option(
        True, "--global", "--no-global", help="Show global agents (default: True)"
    ),
    diff: bool = typer.Option(
        False, "--diff", help="Show line-by-line diff for differing files"
    ),
) -> None:
    """Show sync status without writing.

    By default, shows both project agents and global agents. Use --no-global to
    show only project agents. Use --diff to show line-by-line differences.
    """
    settings = get_settings()
    try:
        ensure_vault_exists(settings)
    except VaultNotFoundError as e:
        console.print(f"[red]{e}[/]")
        raise typer.Exit(1)

    all_entries: list[tuple[str, SyncEntry]] = []

    if project is None:
        projects_dir = settings.vault_path / "projects"
        if projects_dir.exists():
            project_names = [p.name for p in projects_dir.iterdir() if p.is_dir()]
            for proj_name in project_names:
                try:
                    manifest = parse_manifest(projects_dir / proj_name / "AGENTS.md")
                    entries = collect_entries(manifest, settings)
                    all_entries.extend([(proj_name, e) for e in entries])
                except PiAgentSyncError as e:
                    console.print(f"[red]Error loading project {proj_name}:[/] {e}")
    else:
        manifest_path = settings.vault_path / "projects" / project / "AGENTS.md"
        try:
            manifest = parse_manifest(manifest_path)
        except ManifestNotFoundError:
            console.print(f"[red]Manifest not found for project:[/] {project}")
            raise typer.Exit(1)
        except ManifestParseError as e:
            console.print(f"[red]Failed to parse manifest:[/] {e}")
            raise typer.Exit(1)
        entries = collect_entries(manifest, settings)
        all_entries.extend([(project, e) for e in entries])

    if global_status:
        global_entries = collect_global_entries(settings)
        all_entries.extend([("global", e) for e in global_entries])

    if not all_entries:
        console.print("[yellow]No agents found[/]")
        return

    _display_status(all_entries, show_diff=diff)


def _display_status(
    entries_with_project: list[tuple[str, SyncEntry]], show_diff: bool = False
) -> None:
    table = Table()
    table.add_column("Project")
    table.add_column("Name")
    table.add_column("Kind")
    table.add_column("Local")
    table.add_column("Vault")
    table.add_column("State")
    for proj, entry in entries_with_project:
        # Determine state and local presence
        dest = entry.destination
        if dest.exists():
            try:
                with open(entry.source, "rb") as f:
                    src_hash = hashlib.sha256(f.read()).hexdigest()
                with open(dest, "rb") as f:
                    dst_hash = hashlib.sha256(f.read()).hexdigest()
                if src_hash == dst_hash:
                    state = "in sync"
                else:
                    state = "differs"
                local_desc = "present"
            except OSError as e:
                state = f"error: {e}"
                local_desc = "present?"
        else:
            state = "needs pull"
            local_desc = "missing"
        vault_desc = "present"
        table.add_row(proj, entry.name, entry.kind, local_desc, vault_desc, state)
    console.print(table)

    # Show diffs if requested and there are differing files
    if show_diff:
        _display_diffs(entries_with_project)


def _display_diffs(entries_with_project: list[tuple[str, SyncEntry]]) -> None:
    """Show line-by-line diffs for differing files."""
    import difflib

    has_diffs = False
    for proj, entry in entries_with_project:
        dest = entry.destination
        if not dest.exists():
            continue

        try:
            with open(entry.source, "r", encoding="utf-8", errors="replace") as f:
                src_lines = f.readlines()
            with open(dest, "r", encoding="utf-8", errors="replace") as f:
                dst_lines = f.readlines()

            # Calculate hashes to check if files differ
            with open(entry.source, "rb") as f:
                src_hash = hashlib.sha256(f.read()).hexdigest()
            with open(dest, "rb") as f:
                dst_hash = hashlib.sha256(f.read()).hexdigest()

            if src_hash != dst_hash:
                if not has_diffs:
                    # Print legend once, before first diff
                    console.print(
                        "\n[dim]Legend: - = workspace only, + = vault only[/]"
                    )
                has_diffs = True
                console.print(
                    f"\n[bold blue]Diff for {proj}/{entry.name}[/]"
                    f" [dim]({entry.kind})[/]"
                )
                diff = difflib.unified_diff(
                    dst_lines,
                    src_lines,
                    fromfile=f"workspace: {dest}",
                    tofile=f"vault: {entry.source}",
                    lineterm="",
                )
                for line in diff:
                    if line.startswith("---") or line.startswith("+++"):
                        console.print(f"[dim]{line}[/]")
                    elif line.startswith("-"):
                        console.print(f"[red]{line}[/]")
                    elif line.startswith("+"):
                        console.print(f"[green]{line}[/]")
                    elif line.startswith("@@"):
                        console.print(f"[cyan]{line}[/]")
                    else:
                        console.print(line)
        except (OSError, UnicodeDecodeError):
            # Skip binary or unreadable files
            pass

    if not has_diffs:
        console.print("\n[dim]No differing files to display[/]")


@app.command()
def doctor() -> None:
    """Validate full system setup.

    Checks:
    - Vault exists and is accessible
    - Vault is a git repository with proper configuration
    - Project manifests are valid
    - Workspace directories are accessible
    """
    settings = get_settings()

    # Track overall health (critical checks only)
    critical_passed = 0
    critical_total = 0
    optional_passed = 0
    optional_total = 0

    # Check 1: Vault exists (CRITICAL)
    critical_total += 1
    if settings.vault_path.exists():
        console.print(f"[green]✓[/] Vault exists at [bold]{settings.vault_path}[/]")
        critical_passed += 1
    else:
        console.print(f"[red]✗[/] Vault not found at [bold]{settings.vault_path}[/]")
        console.print(
            "[yellow]Hint:[/] Clone it first: "
            f"git clone git@github.com:Piwero/vault.git {settings.vault_path}"
        )

    # Check 2: Vault is a git repository (CRITICAL)
    critical_total += 1
    vault_git_dir = settings.vault_path / ".git"
    if vault_git_dir.exists():
        console.print("[green]✓[/] Vault is a git repository")
        critical_passed += 1

        # Check 2b: Git is configured (user.name and user.email)
        try:
            subprocess.run(
                ["git", "config", "user.name"],
                cwd=settings.vault_path,
                capture_output=True,
                check=True,
            )
            subprocess.run(
                ["git", "config", "user.email"],
                cwd=settings.vault_path,
                capture_output=True,
                check=True,
            )
            console.print("[green]✓[/] Git user configured (name and email)")
        except subprocess.CalledProcessError:
            console.print("[yellow]⚠[/] Git user not configured. Run:")
            console.print("  git config user.name 'Your Name'")
            console.print("  git config user.email 'your.email@example.com'")
    else:
        console.print("[red]✗[/] Vault is not a git repository")

    # Check 3: Vault structure (projects directory) (CRITICAL)
    critical_total += 1
    projects_dir = settings.vault_path / "projects"
    if projects_dir.exists() and projects_dir.is_dir():
        console.print("[green]✓[/] Projects directory exists")

        # Check 3b: Validate project manifests
        try:
            project_dirs = [d for d in projects_dir.iterdir() if d.is_dir()]
            if project_dirs:
                manifest_errors = []
                for proj_dir in project_dirs:
                    manifest_path = proj_dir / "AGENTS.md"
                    if manifest_path.exists():
                        try:
                            parse_manifest(manifest_path)
                        except (ManifestNotFoundError, ManifestParseError) as e:
                            manifest_errors.append(f"{proj_dir.name}: {str(e)}")
                    else:
                        manifest_errors.append(f"{proj_dir.name}: AGENTS.md not found")

                if manifest_errors:
                    console.print(
                        f"[yellow]⚠[/] {len(manifest_errors)} project(s) have manifest issues:"
                    )
                    for error in manifest_errors:
                        console.print(f"  - {error}")
                    # Projects with manifest issues = critical failure
                else:
                    console.print(
                        f"[green]✓[/] All {len(project_dirs)} project manifest(s) valid"
                    )
                    critical_passed += 1
            else:
                console.print(
                    "[dim]ℹ[/] No projects found (this is OK for a fresh vault)"
                )
                critical_passed += 1
        except Exception as e:
            console.print(f"[yellow]⚠[/] Error checking projects: {e}")
    else:
        console.print(
            "[yellow]⚠[/] Projects directory not found (create with 'mkdir projects')"
        )

    # Check 4: Global agents directory (OPTIONAL)
    optional_total += 1
    global_agents_dir = settings.vault_path / "agents" / "global"
    if global_agents_dir.exists() and global_agents_dir.is_dir():
        console.print("[green]✓[/] Global agents directory exists")
        optional_passed += 1
    else:
        console.print("[dim]ℹ[/] Global agents directory not found (optional)")

    # Check 5: Global opencode config (OPTIONAL)
    optional_total += 1
    opencode_config = settings.global_opencode_path / "opencode.json"
    if opencode_config.exists():
        console.print(f"[green]✓[/] Global OpenCode config exists at {opencode_config}")
        optional_passed += 1
    else:
        console.print(
            f"[yellow]⚠[/] Global OpenCode config not found at {opencode_config}"
        )
        console.print("[yellow]Hint:[/] Run 'piagentsync bootstrap' to create it")

    # Summary
    console.print(
        f"\n[bold]Summary: {critical_passed}/{critical_total} critical checks passed"
        f" ({optional_passed}/{optional_total} optional)[/]"
    )

    if critical_passed == critical_total:
        console.print("[green]✓ System is healthy![/]")
        raise typer.Exit(0)
    elif critical_passed >= critical_total - 1:
        console.print("[yellow]⚠ System mostly healthy, but some warnings above[/]")
        raise typer.Exit(0)
    else:
        console.print("[red]✗ System has critical issues, please review above[/]")
        raise typer.Exit(1)


@app.command()
def init(
    project: str = typer.Argument(..., help="Project slug"),
    workspace: Path = typer.Option(
        ..., "--workspace", "-w", help="Workspace directory"
    ),
    notion_board_id: str | None = typer.Option(
        None, "--notion-board-id", help="Notion board ID"
    ),
    notion_project_filter: str | None = typer.Option(
        None,
        "--notion-project-filter",
        help="Notion project filter (defaults to project slug)",
    ),
) -> None:
    """Scaffold a new project in the vault."""
    # Validate project slug early using ProjectManifest
    try:
        manifest = ProjectManifest(
            project=project,
            workspace=workspace,
            notion_board_id=notion_board_id,
            notion_project_filter=notion_project_filter or project,
        )
    except ValidationError as e:
        console.print(f"[red]Invalid project slug:[/] {e}")
        raise typer.Exit(1)

    settings = get_settings()
    try:
        ensure_vault_exists(settings)
    except VaultNotFoundError as e:
        console.print(f"[red]{e}[/]")
        raise typer.Exit(1)

    project_dir = settings.vault_path / "projects" / project
    if project_dir.exists():
        console.print(f"[red]Project directory already exists:[/] {project_dir}")
        raise typer.Exit(1)

    try:
        project_dir.mkdir(parents=True, exist_ok=False)
        (project_dir / "agents").mkdir()
        (project_dir / "skills").mkdir()
        (project_dir / "context.md").write_text("")
        (project_dir / "decisions.md").write_text("")
    except OSError as e:
        console.print(f"[red]Failed to create project directories:[/] {e}")
        raise typer.Exit(1)

    # Build AGENTS.md content
    frontmatter = [
        "---",
        f"project: {manifest.project}",
        f"workspace: {workspace}",
    ]
    if manifest.notion_board_id:
        frontmatter.append(f"notion_board_id: {manifest.notion_board_id}")
    if manifest.notion_project_filter:
        frontmatter.append(f"notion_project_filter: {manifest.notion_project_filter}")
    frontmatter.append("---")
    frontmatter_body = "\n".join(frontmatter)

    body = f"""# {project} — agent routing

## Stack

_Fill in the tech stack._

## Agent routing

| Task | Agent |
|------|-------|
| _example_ | _example-agent_ |
"""
    agents_md_content = frontmatter_body + "\n\n" + body
    try:
        (project_dir / "AGENTS.md").write_text(agents_md_content)
        # Add .gitkeep files
        (project_dir / "agents" / ".gitkeep").write_text("")
        (project_dir / "skills" / ".gitkeep").write_text("")
    except OSError as e:
        console.print(f"[red]Failed to write manifest files:[/] {e}")
        raise typer.Exit(1)

    console.print(f"[green]Project initialized:[/] {project}")
    console.print(f"Next step: piagentsync pull {project}")


def merge_opencode_json(settings: Settings, force: bool) -> str:
    """Merge MCP configuration into existing opencode.json.

    Returns:
        "created"  – file did not exist, wrote full default
        "merged"   – file existed, MCP block was added/updated
        "skipped"  – file existed and MCP block already correct (no write)
        "error:<msg>" – failed to read/write
    """
    config_path = settings.global_opencode_path / "opencode.json"
    default_mcp: dict[str, dict[str, object]] = {
        "mcp": {
            "notion": {
                "type": "remote",
                "url": "https://mcp.notion.com/mcp",
                "enabled": True,
            },
            "obsidian": {
                "type": "local",
                "command": ["sh", "-c", "npx @bitbonsai/mcpvault@latest $HOME/vault"],
                "enabled": True,
            },
        },
        "tools": {
            "notion_*": False,
            "obsidian_*": False,
        },
    }

    try:
        if not config_path.exists():
            config_path.parent.mkdir(parents=True, exist_ok=True)
            with open(config_path, "w") as f:
                json.dump(default_mcp, f, indent=2)
            return "created"

        # Read existing config
        with open(config_path, "r") as f:
            config = json.load(f)

        # Check if MCP+tools already match defaults
        mcp_dict = config.get("mcp", {})
        assert isinstance(mcp_dict, dict)
        tools_dict = config.get("tools", {})
        assert isinstance(tools_dict, dict)

        mcp_notion = mcp_dict.get("notion")
        mcp_obsidian = mcp_dict.get("obsidian")
        tools_notion = tools_dict.get("notion_*")
        tools_obsidian = tools_dict.get("obsidian_*")

        mcp_correct = (
            mcp_notion == default_mcp["mcp"]["notion"]
            and mcp_obsidian == default_mcp["mcp"]["obsidian"]
            and tools_notion == default_mcp["tools"]["notion_*"]
            and tools_obsidian == default_mcp["tools"]["obsidian_*"]
        )
        if mcp_correct and not force:
            return "skipped"

        # Merge: ensure mcp and tools dicts exist, then update
        if "mcp" not in config:
            config["mcp"] = {}
        config["mcp"].update(default_mcp["mcp"])
        if "tools" not in config:
            config["tools"] = {}
        config["tools"].update(default_mcp["tools"])

        # Write back
        with open(config_path, "w") as f:
            json.dump(config, f, indent=2)
        return "merged"
    except (OSError, json.JSONDecodeError) as e:
        return f"error:{e}"


@app.command()
def new_agent(
    name: str = typer.Argument(..., help="Name of the agent (kebab-case, lowercase)"),
    project: str | None = typer.Option(
        None, "--project", help="Project name for project-specific agent"
    ),
) -> None:
    """Create a new agent scaffold in vault."""
    settings = get_settings()

    # Validate vault exists
    try:
        ensure_vault_exists(settings)
    except VaultNotFoundError as e:
        console.print(f"[red]{e}[/]")
        raise typer.Exit(1)

    # Validate agent name (kebab-case, lowercase, alphanumeric + hyphens)
    if not re.match(r"^[a-z0-9]([a-z0-9-]*[a-z0-9])?$", name):
        console.print(
            "[red]Error:[/] Agent name must be lowercase kebab-case (e.g., 'my-agent')"
        )
        raise typer.Exit(1)

    # Determine agent path
    if project:
        # Project-specific agent
        agent_dir = settings.vault_path / "projects" / project / "agents"
        agent_path = agent_dir / f"{name}.md"
    else:
        # Global agent
        agent_dir = settings.vault_path / "agents" / "global"
        agent_path = agent_dir / f"{name}.md"

    # Check if agent already exists
    if agent_path.exists():
        console.print(f"[red]Error:[/] Agent '{name}' already exists at {agent_path}")
        raise typer.Exit(1)

    # Create agent directory if needed
    agent_dir.mkdir(parents=True, exist_ok=True)

    # Create agent template
    template = f"""# {name}

## Description

Add agent description here.

## Usage

Add usage instructions here.
"""

    agent_path.write_text(template)
    scope = f"project:{project}" if project else "global"
    console.print(f"[green]Created[/] agent '{name}' ({scope}) at {agent_path}")


@app.command()
def new_project(
    project: str = typer.Argument(..., help="Project slug (kebab-case)"),
    workspace: Path | None = typer.Option(
        None, "--workspace", "-w", help="Workspace directory path"
    ),
    notion: bool | None = typer.Option(
        None, "--notion", help="Create Notion board (True/False)"
    ),
    no_notion: bool = typer.Option(
        False, "--no-notion", help="Skip Notion board setup"
    ),
    yes: bool = typer.Option(False, "--yes", help="Use all defaults without prompting"),
    no_commit: bool = typer.Option(False, "--no-commit", help="Skip auto-commit"),
) -> None:
    """Create a new project scaffold in vault.

    Interactive by default; all prompts have sensible defaults.
    Use --yes to skip all prompts and use defaults.
    """
    settings = get_settings()

    # Validate vault exists
    try:
        ensure_vault_exists(settings)
    except VaultNotFoundError as e:
        console.print(f"[red]{e}[/]")
        raise typer.Exit(1)

    # Validate project slug (kebab-case)
    if not re.match(r"^[a-z0-9]+(-[a-z0-9]+)*$", project):
        console.print(
            "[red]Invalid project name.[/] Use kebab-case (e.g., 'my-project')"
        )
        raise typer.Exit(1)

    # Check if project already exists
    project_dir = settings.vault_path / "projects" / project
    if project_dir.exists():
        console.print(f"[red]Project '{project}' already exists[/] at {project_dir}")
        raise typer.Exit(1)

    # Determine workspace path
    if workspace is None:
        if yes:
            # Use default without prompting
            workspace = Path.home() / f"workspace-{project}"
        else:
            # Interactive prompt with default
            default_ws = Path.home() / f"workspace-{project}"
            ws_input = typer.prompt("Workspace path", default=str(default_ws))
            workspace = Path(ws_input).expanduser()
    else:
        workspace = workspace.expanduser()

    # Check if workspace exists
    if workspace.exists():
        console.print(
            f"[yellow]⚠[/] Directory already exists, using existing: {workspace}"
        )
    else:
        workspace.mkdir(parents=True, exist_ok=True)
        console.print(f"[green]✓[/] Created workspace: {workspace}")

    # Determine Notion setup
    use_notion = False
    if no_notion:
        use_notion = False
    elif notion is not None:
        use_notion = notion
    elif not yes:
        use_notion = typer.confirm(
            "Set up Notion board for this project?", default=False
        )

    notion_board_id = ""
    notion_data_source = ""

    if use_notion:
        # TODO: Handle Notion integration (for now, skip gracefully)
        console.print("[dim]ℹ Notion integration would go here[/]")

    # Create project scaffold
    try:
        project_dir.mkdir(parents=True)
        (project_dir / "agents").mkdir()
        (project_dir / "skills").mkdir()
        (project_dir / "context.md").write_text("")
        (project_dir / "decisions.md").write_text("")
        (project_dir / "agents" / ".gitkeep").write_text("")
        (project_dir / "skills" / ".gitkeep").write_text("")
    except OSError as e:
        console.print(f"[red]Failed to create project directories:[/] {e}")
        raise typer.Exit(1)

    # Build AGENTS.md content
    frontmatter = [
        "---",
        f"project: {project}",
        f"workspace: {workspace}",
    ]
    if use_notion and notion_board_id:
        frontmatter.append(f"notion_board_id: {notion_board_id}")
        frontmatter.append(f"notion_data_source: {notion_data_source}")
        frontmatter.append(f"notion_project_filter: {project}")
    else:
        frontmatter.append("notion_board_id: ")
        frontmatter.append("notion_data_source: ")
        frontmatter.append(f"notion_project_filter: {project}")
    frontmatter.append("obsidian_context: projects/" + project + "/context.md")
    frontmatter.append("---")
    frontmatter_body = "\n".join(frontmatter)

    body = f"""# {project} — agent routing

## Stack

_Fill in the tech stack._

## Agent routing

| Task | Agent |
|------|-------|
| Tickets / context / decisions | `@chief-pm` (global) |
"""
    agents_md_content = frontmatter_body + "\n\n" + body

    try:
        (project_dir / "AGENTS.md").write_text(agents_md_content)
    except OSError as e:
        console.print(f"[red]Failed to create AGENTS.md:[/] {e}")
        raise typer.Exit(1)

    # Update index.md
    index_path = settings.vault_path / "index.md"
    if not index_path.exists():
        console.print("[red]index.md not found in vault[/]")
        raise typer.Exit(1)

    try:
        index_content = index_path.read_text()
        # Add new project row to the table
        notion_cell = f"`{notion_board_id}`" if notion_board_id else "—"
        new_row = f"| [{project}](projects/{project}/AGENTS.md) | active | `{workspace}` | {notion_cell} |"
        index_content += "\n" + new_row
        index_path.write_text(index_content)
        console.print("[green]✓[/] Updated index.md")
    except OSError as e:
        console.print(f"[red]Failed to update index.md:[/] {e}")
        raise typer.Exit(1)

    console.print(f"[green]✓[/] Created project '{project}'")
    console.print(f"[green]✓[/] Workspace: {workspace}")

    if use_notion:
        console.print("[green]✓[/] Notion board configured")

    # Auto-commit
    if not no_commit:
        success, msg = _auto_commit_vault(
            settings.vault_path, f"chore: add project {project}"
        )
        if success:
            console.print(f"[green]✓[/] {msg}")
        else:
            console.print(f"[yellow]⚠[/] {msg}")

    console.print(
        f"\n[bold]Next steps:[/]\n"
        f"  1. Fill in the stack: {project_dir / 'context.md'}\n"
        f"  2. Add agents: piagentsync new-agent <name> --project {project}\n"
        f"  3. Sync to workspace: piagentsync pull {project}"
    )


@app.command()
def watch(
    project: str | None = typer.Argument(None, help="Project to watch"),
    all_projects: bool = typer.Option(False, "--all", help="Watch all projects"),
    global_agents: bool = typer.Option(
        False, "--global", help="Also sync global agents"
    ),
    interval: int = typer.Option(
        30, "--interval", help="Polling interval in seconds (minimum 10)"
    ),
    no_pull: bool = typer.Option(
        False, "--no-pull", help="Dry-run: detect but don't write"
    ),
    max_iterations: int = typer.Option(
        None, "--max-iterations", help="Stop after N iterations (for testing)"
    ),
) -> None:
    """Watch vault for new commits and auto-sync projects.

    Polling-based watching: checks git for new commits every --interval seconds.
    Syncs only affected projects when changes are detected.
    """
    settings = get_settings()

    # Validate vault exists and is a git repo
    try:
        ensure_vault_exists(settings)
    except VaultNotFoundError as e:
        console.print(f"[red]{e}[/]")
        raise typer.Exit(1)

    vault_git_dir = settings.vault_path / ".git"
    if not vault_git_dir.exists():
        console.print("[red]Vault is not a git repository[/]")
        raise typer.Exit(1)

    # Validate interval
    if interval < 10:
        console.print("[red]Interval must be at least 10 seconds[/]")
        raise typer.Exit(1)

    # Determine projects to watch
    projects_to_watch: list[str] = []
    if all_projects:
        projects_dir = settings.vault_path / "projects"
        if projects_dir.exists():
            projects_to_watch = [d.name for d in projects_dir.iterdir() if d.is_dir()]
        if not projects_to_watch:
            console.print("[red]No projects found in vault[/]")
            raise typer.Exit(1)
    elif project:
        project_dir = settings.vault_path / "projects" / project
        if not project_dir.exists():
            console.print(f"[red]Project '{project}' not found[/]")
            raise typer.Exit(1)
        projects_to_watch = [project]
    else:
        console.print("[red]Specify a project or use --all[/]")
        raise typer.Exit(1)

    console.print(
        f"[bold]Watching vault for new commits[/] (polling every {interval}s). Ctrl+C to stop."
    )

    iteration = 0
    last_head_sha = None

    try:
        while True:
            iteration += 1

            # Stop after max_iterations if specified (for testing)
            if max_iterations and iteration > max_iterations:
                break

            try:
                # Fetch latest from remote
                subprocess.run(
                    ["git", "fetch", "origin"],
                    cwd=settings.vault_path,
                    capture_output=True,
                    check=False,
                )

                # Check current HEAD vs origin/main
                result = subprocess.run(
                    ["git", "rev-parse", "HEAD"],
                    cwd=settings.vault_path,
                    capture_output=True,
                    text=True,
                    check=True,
                )
                current_head_sha = result.stdout.strip()

                # Skip first iteration or if no change
                if last_head_sha is None:
                    last_head_sha = current_head_sha
                    time.sleep(interval)
                    continue

                # Check if we're behind origin/main
                result_behind = subprocess.run(
                    ["git", "rev-parse", "origin/main"],
                    cwd=settings.vault_path,
                    capture_output=True,
                    text=True,
                    check=False,
                )

                if result_behind.returncode == 0:
                    origin_sha = result_behind.stdout.strip()
                    if current_head_sha != origin_sha:
                        # We're behind - pull and sync
                        console.print(
                            f"\n[green][{time.strftime('%H:%M:%S')}][/] New commits detected"
                        )

                        if not no_pull:
                            # Pull latest commits
                            subprocess.run(
                                ["git", "pull", "origin", "main"],
                                cwd=settings.vault_path,
                                capture_output=True,
                                check=False,
                            )

                            # Get list of changed files
                            result_diff = subprocess.run(
                                ["git", "diff", "--name-only", last_head_sha, "HEAD"],
                                cwd=settings.vault_path,
                                capture_output=True,
                                text=True,
                                check=False,
                            )
                            changed_files = (
                                result_diff.stdout.strip().split("\n")
                                if result_diff.stdout.strip()
                                else []
                            )

                            # Determine affected projects
                            affected = set()
                            for file in changed_files:
                                if file.startswith("projects/"):
                                    parts = file.split("/")
                                    if len(parts) > 1:
                                        affected.add(parts[1])
                                elif (
                                    file.startswith("agents/global/") and global_agents
                                ):
                                    affected.add("__global__")

                            # Sync affected projects
                            for proj in projects_to_watch:
                                if proj in affected or "__global__" in affected:
                                    # TODO: Sync project (call collect_entries, etc)
                                    console.print(f"  [green]Synced:[/] {proj}")

                        last_head_sha = current_head_sha

            except subprocess.CalledProcessError as e:
                console.print(
                    f"[yellow]⚠ Git error:[/] {e.stderr}. Retrying in {interval}s."
                )
            except Exception as e:
                console.print(f"[yellow]⚠ Error:[/] {str(e)}. Retrying in {interval}s.")

            # Sleep before next iteration
            time.sleep(interval)

    except KeyboardInterrupt:
        console.print("\n[yellow]Stopped watching.[/]")
        raise typer.Exit(0)


@app.command()
def bootstrap(
    force: bool = typer.Option(
        False, "--force", help="Overwrite MCP configuration if present"
    ),
) -> None:
    """Bootstrap machine from vault (install global config and agents)."""
    settings = get_settings()

    # Step 1: ensure vault exists
    try:
        ensure_vault_exists(settings)
    except VaultNotFoundError as e:
        console.print(f"[red]{e}[/]")
        raise typer.Exit(1)

    # Step 2: merge/write opencode.json
    opencode_config_path = settings.global_opencode_path / "opencode.json"
    status = merge_opencode_json(settings, force)
    if status == "created":
        console.print(f"[green]Created[/] {opencode_config_path}")
    elif status == "merged":
        console.print(
            f"[green]Updated[/] {opencode_config_path} (MCP configuration merged)"
        )
    elif status == "skipped":
        console.print("[dim]opencode.json already has MCP configured[/]")
    else:
        console.print(f"[red]Failed to update opencode.json:[/] {status}")
        raise typer.Exit(1)

    # Step 3: run opencode mcp auth notion (only if MCP was added/updated)
    if status in ("created", "merged"):
        console.print("\n[bold]Next:[/] Running Notion MCP authentication...")
        console.print(
            "This will open a browser window. Follow the prompts to authenticate."
        )
        try:
            result = subprocess.run(
                ["opencode", "mcp", "auth", "notion"],
                check=False,
            )
            if result.returncode != 0:
                console.print(
                    "[yellow]Warning:[/] auth command exited with non-zero status. You may need to run 'opencode mcp auth notion' manually."
                )
        except FileNotFoundError:
            console.print(
                "[yellow]Warning:[/] 'opencode' command not found on PATH. Please install OpenCode and run 'opencode mcp auth notion' manually."
            )
    else:
        console.print("\n[dim]Skipping auth (MCP already configured).[/]")

    # Step 4: install global agent chief-pm
    console.print("\n[bold]Installing global agent[/] chief-pm...")
    src_chief = settings.vault_path / "agents" / "global" / "chief-pm.md"
    dst_chief = settings.global_opencode_path / "agents" / "chief-pm.md"
    status = copy_file_sync(src_chief, dst_chief)
    if status == "copied":
        console.print(f"[green]Copied[/] chief-pm to {dst_chief}")
    elif status == "updated":
        console.print(f"[green]Updated[/] chief-pm at {dst_chief}")
    elif status == "skipped":
        console.print("[dim]chief-pm already in sync[/]")
    elif status == "missing":
        console.print(
            "[yellow]Warning:[/] vault/agents/global/chief-pm.md not found, skipping"
        )
    else:
        console.print(f"[yellow]Warning:[/] failed to copy chief-pm: {status}")

    console.print("\n[green]Bootstrap complete![/]")
