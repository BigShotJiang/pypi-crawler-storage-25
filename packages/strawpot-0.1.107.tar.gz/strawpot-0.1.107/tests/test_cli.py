"""Tests for strawpot.cli — start command wiring."""

import os
from unittest.mock import MagicMock, patch

from click.testing import CliRunner

from strawpot.agents.registry import AgentSpec, ValidationResult
from strawpot.cli import _check_system_prerequisites, cli


def _make_spec(**overrides):
    defaults = {
        "name": "strawpot-claude-code",
        "version": "1.0.0",
        "wrapper_cmd": ["/usr/bin/test-wrapper"],
        "config": {},
        "env_schema": {},
        "tools": {},
    }
    defaults.update(overrides)
    return AgentSpec(**defaults)


# ---------------------------------------------------------------------------
# No-args invocation (issue #446)
# ---------------------------------------------------------------------------


@patch("strawpot.cli._show_first_run_banner")
def test_no_args_shows_help_and_exits_zero(_mock_banner):
    """Running ``strawpot`` with no arguments should show help and exit 0."""
    runner = CliRunner()
    result = runner.invoke(cli, [])
    assert result.exit_code == 0
    assert "StrawPot" in result.output


# ---------------------------------------------------------------------------
# Agent resolution
# ---------------------------------------------------------------------------


@patch("strawpot.cli.needs_onboarding", return_value=False)
@patch("strawpot.cli._ensure_memory_installed")
@patch("strawpot.cli._ensure_role_installed")
@patch("strawpot.cli._ensure_skill_installed")
@patch("strawpot.cli._ensure_agent_installed")
@patch("strawpot.cli.Session")
@patch("strawpot.cli.WrapperRuntime")
@patch("strawpot.cli.validate_agent", return_value=ValidationResult())
@patch("strawpot.cli.resolve_agent")
@patch("strawpot.cli.load_config")
def test_start_resolves_agent(
    mock_load, mock_resolve, mock_validate, mock_wrapper,
    mock_session, mock_ensure_agent, mock_ensure_skill, mock_ensure_role, mock_ensure_memory,
    _mock_onboarding,
):
    """start() calls resolve_agent with config.runtime."""
    from strawpot.config import StrawPotConfig

    mock_load.return_value = StrawPotConfig()
    mock_resolve.return_value = _make_spec()

    runner = CliRunner()
    result = runner.invoke(cli, ["start"])

    mock_resolve.assert_called_once()
    call_args = mock_resolve.call_args
    assert call_args[0][0] == "strawpot-claude-code"  # runtime name
    assert call_args[0][2] is None  # no agent-specific config


@patch("strawpot.cli._ensure_memory_installed")
@patch("strawpot.cli._ensure_role_installed")
@patch("strawpot.cli._ensure_skill_installed")
@patch("strawpot.cli._ensure_agent_installed")
@patch("strawpot.cli.Session")
@patch("strawpot.cli.WrapperRuntime")
@patch("strawpot.cli.validate_agent", return_value=ValidationResult())
@patch("strawpot.cli.resolve_agent")
@patch("strawpot.cli.load_config")
def test_start_resolves_agent_with_runtime_override(
    mock_load, mock_resolve, mock_validate, mock_wrapper,
    mock_session, mock_ensure_agent, mock_ensure_skill, mock_ensure_role, mock_ensure_memory
):
    """start --runtime overrides the agent name passed to resolve_agent."""
    from strawpot.config import StrawPotConfig

    mock_load.return_value = StrawPotConfig()
    mock_resolve.return_value = _make_spec()

    runner = CliRunner()
    runner.invoke(cli, ["start", "--runtime", "custom_agent"])

    # resolve_agent should be called with the overridden runtime name
    call_args = mock_resolve.call_args
    assert call_args[0][0] == "custom_agent"


@patch("strawpot.cli.needs_onboarding", return_value=False)
@patch("strawpot.cli._ensure_memory_installed")
@patch("strawpot.cli._ensure_role_installed")
@patch("strawpot.cli._ensure_skill_installed")
@patch("strawpot.cli._ensure_agent_installed")
@patch("strawpot.cli.resolve_agent")
@patch("strawpot.cli.load_config")
def test_start_agent_not_found(mock_load, mock_resolve, mock_ensure_agent, mock_ensure_skill, mock_ensure_role, mock_ensure_memory, _mock_onboarding):
    """FileNotFoundError from resolve_agent prints error and exits 1."""
    from strawpot.config import StrawPotConfig

    mock_load.return_value = StrawPotConfig()
    mock_resolve.side_effect = FileNotFoundError("Agent not found: 'bad_agent'")

    runner = CliRunner()
    result = runner.invoke(cli, ["start"])

    assert result.exit_code != 0
    assert "Agent not found" in result.output


@patch("strawpot.cli.needs_onboarding", return_value=False)
@patch("strawpot.cli._ensure_memory_installed")
@patch("strawpot.cli._ensure_role_installed")
@patch("strawpot.cli._ensure_skill_installed")
@patch("strawpot.cli._ensure_agent_installed")
@patch("strawpot.cli.resolve_agent")
@patch("strawpot.cli.load_config")
def test_start_agent_binary_not_found(
    mock_load, mock_resolve, mock_ensure_agent, mock_ensure_skill,
    mock_ensure_role, mock_ensure_memory, _mock_onboarding
):
    """ValueError from resolve_agent prints actionable error and exits 1."""
    from strawpot.config import StrawPotConfig

    mock_load.return_value = StrawPotConfig()
    mock_resolve.side_effect = ValueError("Agent binary not found: /path/to/binary")

    runner = CliRunner()
    result = runner.invoke(cli, ["start"])

    assert result.exit_code != 0
    assert "Agent runtime binary not found" in result.output
    assert "strawpot doctor" in result.output


@patch("strawpot.cli.needs_onboarding", return_value=False)
@patch("strawpot.cli._check_system_prerequisites")
@patch("strawpot.cli.load_config")
def test_start_missing_system_prerequisites(mock_load, mock_prereqs, _mock_onboarding):
    """Missing system tools (node, npm) exits 1 with actionable guidance."""
    from strawpot.config import StrawPotConfig

    mock_load.return_value = StrawPotConfig()
    mock_prereqs.return_value = [
        ("node", "Install from https://nodejs.org/"),
        ("npm", "Install from https://nodejs.org/ (npm is bundled with Node.js)"),
    ]

    runner = CliRunner()
    result = runner.invoke(cli, ["start"])

    assert result.exit_code != 0
    assert "Missing system prerequisites" in result.output
    assert "node" in result.output
    assert "npm" in result.output
    assert "nodejs.org" in result.output


# ---------------------------------------------------------------------------
# _check_system_prerequisites
# ---------------------------------------------------------------------------


def test_check_system_prerequisites_all_present(monkeypatch):
    """Returns empty list when node and npm are on PATH."""
    pass  # moved to test_doctor.py


def test_check_system_prerequisites_missing_node(monkeypatch):
    """Returns node as missing when not on PATH."""
    monkeypatch.setattr(
        "strawpot.cli.shutil.which",
        lambda c: None if c == "node" else f"/usr/bin/{c}",
    )
    result = _check_system_prerequisites()
    tool_names = [name for name, _ in result]
    assert "node" in tool_names
    assert "npm" not in tool_names


# ---------------------------------------------------------------------------
# _authenticate_agent ValueError handling
# ---------------------------------------------------------------------------


@patch("strawpot.cli.resolve_agent")
def test_authenticate_agent_catches_value_error(mock_resolve, capsys):
    """_authenticate_agent catches ValueError and prints guidance."""
    from strawpot.cli import _authenticate_agent

    mock_resolve.side_effect = ValueError("Agent binary not found")

    _authenticate_agent("test-agent", "/tmp/project")

    captured = capsys.readouterr()
    assert "Agent binary not available" in captured.err
    assert "strawpot doctor" in captured.err


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------


@patch("strawpot.cli._ensure_memory_installed")
@patch("strawpot.cli._ensure_role_installed")
@patch("strawpot.cli._ensure_skill_installed")
@patch("strawpot.cli._ensure_agent_installed")
@patch("strawpot.cli.resolve_agent")
@patch("strawpot.cli.validate_agent")
@patch("strawpot.cli.load_config")
def test_start_missing_tools_exits(
    mock_load, mock_validate, mock_resolve, mock_ensure_agent, mock_ensure_skill, mock_ensure_role, mock_ensure_memory
):
    """Missing tools prints error with hints and exits 1."""
    from strawpot.config import StrawPotConfig

    mock_load.return_value = StrawPotConfig()
    mock_resolve.return_value = _make_spec()
    mock_validate.return_value = ValidationResult(
        missing_tools=[("node", "brew install node"), ("git", None)]
    )

    runner = CliRunner()
    result = runner.invoke(cli, ["start"], input="n\n")

    assert result.exit_code != 0
    assert "Missing required tools" in result.output
    assert "node" in result.output
    assert "brew install node" in result.output
    assert "git" in result.output


@patch("strawpot.cli._ensure_memory_installed")
@patch("strawpot.cli._ensure_role_installed")
@patch("strawpot.cli._ensure_skill_installed")
@patch("strawpot.cli._ensure_agent_installed")
@patch("strawpot.cli.Session")
@patch("strawpot.cli.WrapperRuntime")
@patch("strawpot.cli.resolve_agent")
@patch("strawpot.cli.validate_agent")
@patch("strawpot.cli.load_config")
def test_start_missing_env_prompts(
    mock_load, mock_validate, mock_resolve, mock_wrapper,
    mock_session, mock_ensure_agent, mock_ensure_skill, mock_ensure_role, mock_ensure_memory
):
    """Missing env vars are prompted and set in os.environ."""
    from strawpot.config import StrawPotConfig

    mock_load.return_value = StrawPotConfig()
    mock_resolve.return_value = _make_spec()
    mock_validate.return_value = ValidationResult(missing_env=["ANTHROPIC_API_KEY"])

    runner = CliRunner()
    result = runner.invoke(cli, ["start"], input="sk-test-key-123\n")

    assert result.exit_code == 0
    assert os.environ.get("ANTHROPIC_API_KEY") == "sk-test-key-123"

    # Clean up
    os.environ.pop("ANTHROPIC_API_KEY", None)


@patch("strawpot.cli._ensure_memory_installed")
@patch("strawpot.cli._ensure_role_installed")
@patch("strawpot.cli._ensure_skill_installed")
@patch("strawpot.cli._ensure_agent_installed")
@patch("strawpot.cli.Session")
@patch("strawpot.cli.WrapperRuntime")
@patch("strawpot.cli.resolve_agent")
@patch("strawpot.cli.validate_agent")
@patch("strawpot.cli.load_config")
@patch("strawpot.config.save_resource_config")
def test_start_missing_env_persists_to_config(
    mock_save, mock_load, mock_validate, mock_resolve, mock_wrapper,
    mock_session, mock_ensure_agent, mock_ensure_skill, mock_ensure_role, mock_ensure_memory
):
    """Prompted agent env vars are persisted to global config."""
    from strawpot.config import StrawPotConfig

    mock_load.return_value = StrawPotConfig()
    mock_resolve.return_value = _make_spec()
    mock_validate.return_value = ValidationResult(missing_env=["ANTHROPIC_API_KEY"])

    runner = CliRunner()
    result = runner.invoke(cli, ["start"], input="sk-test-key-123\n")

    assert result.exit_code == 0
    mock_save.assert_called_once_with(
        None, "agents", "strawpot-claude-code",
        env_values={"ANTHROPIC_API_KEY": "sk-test-key-123"},
    )
    assert "Saved env vars" in result.output

    # Clean up
    os.environ.pop("ANTHROPIC_API_KEY", None)


# ---------------------------------------------------------------------------
# Runtime selection
# ---------------------------------------------------------------------------


@patch("strawpot.cli._ensure_memory_installed")
@patch("strawpot.cli._ensure_role_installed")
@patch("strawpot.cli._ensure_skill_installed")
@patch("strawpot.cli._ensure_agent_installed")
@patch("strawpot.cli.Session")
@patch("strawpot.cli.WrapperRuntime")
@patch("strawpot.cli.validate_agent", return_value=ValidationResult())
@patch("strawpot.cli.resolve_agent")
@patch("strawpot.cli.load_config")
@patch("strawpot.cli.shutil.which")
def test_start_uses_tmux_when_available(
    mock_which, mock_load, mock_resolve, mock_validate,
    mock_wrapper, mock_session, mock_ensure_agent, mock_ensure_skill, mock_ensure_role, mock_ensure_memory
):
    """InteractiveWrapperRuntime is used when tmux is on PATH."""
    from strawpot.config import StrawPotConfig

    mock_load.return_value = StrawPotConfig()
    mock_resolve.return_value = _make_spec()
    # shutil.which("tmux") returns a path
    mock_which.return_value = "/usr/bin/tmux"

    with patch("strawpot.cli.InteractiveWrapperRuntime") as mock_interactive:
        runner = CliRunner()
        runner.invoke(cli, ["start"])

        mock_interactive.assert_called_once()


@patch("strawpot.cli._ensure_memory_installed")
@patch("strawpot.cli._ensure_role_installed")
@patch("strawpot.cli._ensure_skill_installed")
@patch("strawpot.cli._ensure_agent_installed")
@patch("strawpot.cli.Session")
@patch("strawpot.cli.WrapperRuntime")
@patch("strawpot.cli.validate_agent", return_value=ValidationResult())
@patch("strawpot.cli.resolve_agent")
@patch("strawpot.cli.load_config")
@patch("strawpot.cli.shutil.which")
def test_start_falls_back_to_direct(
    mock_which, mock_load, mock_resolve, mock_validate,
    mock_wrapper, mock_session, mock_ensure_agent, mock_ensure_skill, mock_ensure_role, mock_ensure_memory
):
    """DirectWrapperRuntime is used when tmux is not on PATH."""
    from strawpot.config import StrawPotConfig

    mock_load.return_value = StrawPotConfig()
    mock_resolve.return_value = _make_spec()
    mock_which.return_value = None

    with patch("strawpot.cli.DirectWrapperRuntime") as mock_direct:
        runner = CliRunner()
        runner.invoke(cli, ["start"])

        mock_direct.assert_called_once()


# ---------------------------------------------------------------------------
# Session creation
# ---------------------------------------------------------------------------


@patch("strawpot.cli._ensure_memory_installed")
@patch("strawpot.cli._ensure_role_installed")
@patch("strawpot.cli._ensure_skill_installed")
@patch("strawpot.cli._ensure_agent_installed")
@patch("strawpot.cli.Session")
@patch("strawpot.cli.WrapperRuntime")
@patch("strawpot.cli.validate_agent", return_value=ValidationResult())
@patch("strawpot.cli.resolve_agent")
@patch("strawpot.cli.load_config")
def test_start_creates_session(
    mock_load, mock_resolve, mock_validate, mock_wrapper,
    mock_session, mock_ensure_agent, mock_ensure_skill, mock_ensure_role, mock_ensure_memory
):
    """Session is constructed with correct args and start() is called."""
    from strawpot.config import StrawPotConfig

    config = StrawPotConfig()
    mock_load.return_value = config
    mock_resolve.return_value = _make_spec()

    runner = CliRunner()
    result = runner.invoke(cli, ["start"])

    assert result.exit_code == 0
    mock_session.assert_called_once()
    call_kwargs = mock_session.call_args.kwargs
    assert call_kwargs["config"] is config
    assert "resolve_role" in call_kwargs
    assert "resolve_role_dirs" in call_kwargs

    # session.start() was called
    mock_session.return_value.start.assert_called_once()


# ---------------------------------------------------------------------------
# CLI overrides
# ---------------------------------------------------------------------------


@patch("strawpot.cli._ensure_memory_installed")
@patch("strawpot.cli._ensure_role_installed")
@patch("strawpot.cli._ensure_skill_installed")
@patch("strawpot.cli._ensure_agent_installed")
@patch("strawpot.cli.Session")
@patch("strawpot.cli.WrapperRuntime")
@patch("strawpot.cli.validate_agent", return_value=ValidationResult())
@patch("strawpot.cli.resolve_agent")
@patch("strawpot.cli.load_config")
def test_start_role_override(
    mock_load, mock_resolve, mock_validate, mock_wrapper,
    mock_session, mock_ensure_agent, mock_ensure_skill, mock_ensure_role, mock_ensure_memory
):
    """--role overrides config.orchestrator_role."""
    from strawpot.config import StrawPotConfig

    config = StrawPotConfig()
    mock_load.return_value = config
    mock_resolve.return_value = _make_spec()

    runner = CliRunner()
    runner.invoke(cli, ["start", "--role", "custom-orchestrator"])

    assert config.orchestrator_role == "custom-orchestrator"


@patch("strawpot.cli._ensure_memory_installed")
@patch("strawpot.cli._ensure_role_installed")
@patch("strawpot.cli._ensure_skill_installed")
@patch("strawpot.cli._ensure_agent_installed")
@patch("strawpot.cli.Session")
@patch("strawpot.cli.WrapperRuntime")
@patch("strawpot.cli.validate_agent", return_value=ValidationResult())
@patch("strawpot.cli.resolve_agent")
@patch("strawpot.cli.load_config")
def test_start_host_port_override(
    mock_load, mock_resolve, mock_validate, mock_wrapper,
    mock_session, mock_ensure_agent, mock_ensure_skill, mock_ensure_role, mock_ensure_memory
):
    """--host and --port override config.denden_addr."""
    from strawpot.config import StrawPotConfig

    config = StrawPotConfig()
    mock_load.return_value = config
    mock_resolve.return_value = _make_spec()

    runner = CliRunner()
    runner.invoke(cli, ["start", "--host", "0.0.0.0", "--port", "8080"])

    assert config.denden_addr == "0.0.0.0:8080"


# ---------------------------------------------------------------------------
# Run ID
# ---------------------------------------------------------------------------


@patch("strawpot.cli._ensure_memory_installed")
@patch("strawpot.cli._ensure_role_installed")
@patch("strawpot.cli._ensure_skill_installed")
@patch("strawpot.cli._ensure_agent_installed")
@patch("strawpot.cli.Session")
@patch("strawpot.cli.WrapperRuntime")
@patch("strawpot.cli.validate_agent", return_value=ValidationResult())
@patch("strawpot.cli.resolve_agent")
@patch("strawpot.cli.load_config")
def test_start_run_id_override(
    mock_load, mock_resolve, mock_validate, mock_wrapper,
    mock_session, mock_ensure_agent, mock_ensure_skill, mock_ensure_role, mock_ensure_memory
):
    """--run-id passes the pre-assigned run ID to Session constructor."""
    from strawpot.config import StrawPotConfig

    mock_load.return_value = StrawPotConfig()
    mock_resolve.return_value = _make_spec()

    runner = CliRunner()
    runner.invoke(cli, [
        "start", "--headless", "--task", "do stuff", "--run-id", "run_gui123"
    ])

    call_kwargs = mock_session.call_args.kwargs
    assert call_kwargs["run_id"] == "run_gui123"


@patch("strawpot.cli._ensure_memory_installed")
@patch("strawpot.cli._ensure_role_installed")
@patch("strawpot.cli._ensure_skill_installed")
@patch("strawpot.cli._ensure_agent_installed")
@patch("strawpot.cli.resolve_agent")
@patch("strawpot.cli.load_config")
def test_start_invalid_run_id_rejected(
    mock_load, mock_resolve, mock_ensure_agent, mock_ensure_skill, mock_ensure_role, mock_ensure_memory
):
    """--run-id without 'run_' prefix fails with error."""
    from strawpot.config import StrawPotConfig

    mock_load.return_value = StrawPotConfig()
    mock_resolve.return_value = _make_spec()

    runner = CliRunner()
    result = runner.invoke(cli, [
        "start", "--headless", "--task", "do stuff", "--run-id", "bad_id"
    ])

    assert result.exit_code != 0
    assert "run_" in result.output


# ---------------------------------------------------------------------------
# Fail-fast when not configured (--task / --headless)
# ---------------------------------------------------------------------------


@patch("strawpot.cli.needs_onboarding", return_value=True)
@patch("strawpot.cli.load_config")
def test_start_headless_fails_when_not_configured(mock_load, _mock_onboarding):
    """--headless exits 1 with clear error when onboarding is needed."""
    from strawpot.config import StrawPotConfig

    mock_load.return_value = StrawPotConfig()

    runner = CliRunner()
    result = runner.invoke(cli, ["start", "--headless", "--task", "do stuff"])

    assert result.exit_code != 0
    assert "No agent configured" in result.output


@patch("strawpot.cli.needs_onboarding", return_value=True)
@patch("strawpot.cli.load_config")
def test_start_task_fails_when_not_configured(mock_load, _mock_onboarding):
    """--task without --headless exits 1 instead of launching the wizard (#442)."""
    from strawpot.config import StrawPotConfig

    mock_load.return_value = StrawPotConfig()

    runner = CliRunner()
    result = runner.invoke(cli, ["start", "--task", "Review my latest PR"])

    assert result.exit_code != 0
    assert "No agent configured" in result.output
    assert "strawpot start" in result.output


@patch("strawpot.cli.needs_onboarding", return_value=True)
@patch("strawpot.cli.load_config")
def test_start_headless_alone_fails_when_not_configured(mock_load, _mock_onboarding):
    """--headless without --task also exits 1 when not configured."""
    from strawpot.config import StrawPotConfig

    mock_load.return_value = StrawPotConfig()

    runner = CliRunner()
    result = runner.invoke(cli, ["start", "--headless"])

    assert result.exit_code != 0
    assert "No agent configured" in result.output


# ---------------------------------------------------------------------------
# Doctor command
# ---------------------------------------------------------------------------


@patch("strawpot.cli.validate_agent", return_value=ValidationResult())
@patch("strawpot.cli.resolve_agent")
@patch("strawpot.cli.load_config")
@patch("strawpot.doctor.subprocess.run")
@patch("strawpot.doctor.shutil.which")
def test_doctor_healthy(mock_which, mock_run, mock_load, mock_resolve, mock_validate):
    """Doctor reports all-OK with checklist markers."""
    from strawpot.config import StrawPotConfig

    mock_load.return_value = StrawPotConfig()
    mock_resolve.return_value = _make_spec()
    mock_which.return_value = "/usr/bin/fake"
    proc = MagicMock(); proc.stdout = "v20.11.0"; proc.stderr = ""
    mock_run.return_value = proc

    runner = CliRunner()
    result = runner.invoke(cli, ["doctor"])

    assert result.exit_code == 0
    assert "All checks passed" in result.output
    assert "[✓]" in result.output


@patch("strawpot.cli.resolve_agent")
@patch("strawpot.cli.load_config")
@patch("strawpot.doctor.subprocess.run")
@patch("strawpot.doctor.shutil.which")
def test_doctor_missing_system_tools(mock_which, mock_run, mock_load, mock_resolve):
    """Doctor reports missing tools with checklist markers."""
    from strawpot.config import StrawPotConfig

    mock_load.return_value = StrawPotConfig()
    mock_resolve.return_value = _make_spec()
    # All tools missing
    mock_which.return_value = None

    runner = CliRunner()
    result = runner.invoke(cli, ["doctor"])

    assert result.exit_code != 0
    assert "[✗]" in result.output
    assert "Some checks failed" in result.output


@patch("strawpot.cli.resolve_agent")
@patch("strawpot.cli.load_config")
@patch("strawpot.doctor.subprocess.run")
@patch("strawpot.doctor.shutil.which")
def test_doctor_agent_not_found(mock_which, mock_run, mock_load, mock_resolve):
    """Doctor handles agent resolution failure gracefully."""
    from strawpot.config import StrawPotConfig

    mock_load.return_value = StrawPotConfig()
    mock_resolve.side_effect = FileNotFoundError("Agent not found")
    mock_which.return_value = "/usr/bin/fake"
    proc = MagicMock(); proc.stdout = "v20.0.0"; proc.stderr = ""
    mock_run.return_value = proc

    runner = CliRunner()
    result = runner.invoke(cli, ["doctor"])

    assert result.exit_code != 0
    assert "[✗]" in result.output
    assert "not installed" in result.output.lower()


@patch("strawpot.cli.resolve_agent")
@patch("strawpot.cli.load_config")
@patch("strawpot.doctor.subprocess.run")
@patch("strawpot.doctor.shutil.which")
def test_doctor_agent_value_error(mock_which, mock_run, mock_load, mock_resolve):
    """Doctor handles ValueError from resolve_agent gracefully."""
    from strawpot.config import StrawPotConfig

    mock_load.return_value = StrawPotConfig()
    mock_resolve.side_effect = ValueError("AGENT.md missing frontmatter")
    mock_which.return_value = "/usr/bin/fake"
    proc = MagicMock(); proc.stdout = "v20.0.0"; proc.stderr = ""
    mock_run.return_value = proc

    runner = CliRunner()
    result = runner.invoke(cli, ["doctor"])

    assert result.exit_code != 0
    assert "[✗]" in result.output
    assert "missing frontmatter" in result.output
