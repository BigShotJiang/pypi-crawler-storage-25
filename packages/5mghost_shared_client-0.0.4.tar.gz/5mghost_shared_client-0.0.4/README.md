# 5mghost-shared-client

Shared client utilities for MCP local clients (auth, registration, skills).

This package provides common functionality used by first-party MCP clients like reddit-mcp and yt-mcp:

- **Token Management**: OAuth2 PKCE flow and JWT/PAT token refresh
- **MCP Registration**: Orchestrates registration across multiple AI clients (Claude Code, Codex, Gemini, etc.)
- **Skills Installation**: Copies skill bundles to CLI skill directories

## Installation

```bash
pip install 5mghost-shared-client
```

## Usage

See the documentation in individual modules for API details.

```python
from fivemghost_shared_client import TokenManager, run_oauth_flow
from fivemghost_shared_client.registration import register_all, install_skills
```
