"""Shared client utilities for MCP local clients (auth, registration, skills)."""

from __future__ import annotations

__version__ = "0.1.0"

from .oauth_flow import run_oauth_flow
from .token_manager import TokenManager

__all__ = [
    "__version__",
    "TokenManager",
    "run_oauth_flow",
]
