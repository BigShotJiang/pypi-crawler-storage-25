"""Test that all public imports work correctly."""

import sys
from pathlib import Path


def test_top_level_imports():
    """Test top-level package imports."""
    from fivemghost_shared_client import __version__, TokenManager, run_oauth_flow
    
    assert isinstance(__version__, str)
    assert callable(TokenManager)
    assert callable(run_oauth_flow)


def test_shared_auth_imports():
    """Test shared auth module imports."""
    from fivemghost_shared_client.shared_auth import (
        read_shared_auth,
        write_shared_auth,
        SharedAuthData,
    )
    
    assert callable(read_shared_auth)
    assert callable(write_shared_auth)


def test_registration_imports():
    """Test registration subpackage imports."""
    from fivemghost_shared_client.registration import (
        register_all,
        unregister_all,
        install_skills,
    )
    
    assert callable(register_all)
    assert callable(unregister_all)
    assert callable(install_skills)


def test_registration_submodule_imports():
    """Test registration submodule imports."""
    from fivemghost_shared_client.registration.cli_registry import register_all, unregister_all
    from fivemghost_shared_client.registration.codex_internal import (
        get_codex_internal_config_path,
        write_codex_internal_config,
        remove_codex_internal_config,
    )
    from fivemghost_shared_client.registration.openclaw import (
        get_openclaw_config_path,
        write_openclaw_config,
        remove_openclaw_config,
    )
    from fivemghost_shared_client.registration.skills import (
        get_skill_install_targets,
        install_skill_target,
        install_skills,
    )
    
    assert callable(register_all)
    assert callable(unregister_all)
    assert callable(get_codex_internal_config_path)
    assert callable(write_codex_internal_config)
    assert callable(remove_codex_internal_config)
    assert callable(get_openclaw_config_path)
    assert callable(write_openclaw_config)
    assert callable(remove_openclaw_config)
    assert callable(get_skill_install_targets)
    assert callable(install_skill_target)
    assert callable(install_skills)


def test_classify_failure_imports():
    """Test failure classification imports."""
    from fivemghost_shared_client._classify_failure import (
        classify_registration_failure,
        RegistrationFailure,
    )
    
    assert callable(classify_registration_failure)
    assert callable(RegistrationFailure)


if __name__ == "__main__":
    test_top_level_imports()
    test_shared_auth_imports()
    test_registration_imports()
    test_registration_submodule_imports()
    test_classify_failure_imports()
    print("✅ All import tests passed!")
