"""Build setup for Cython-compiled core modules.

Compiles 5 IP-sensitive modules to native extensions (.so / .pyd) so the
published wheel ships binary blobs instead of readable Python source.

Modules compiled (and their .py source REMOVED from the wheel):
    - context.py         (run orchestration, policy enforcement, span dedup)
    - cost.py            (cost estimation algorithm)
    - tracing/span_processor.py        (OTel bridge)
    - instrumentors/_auto_decision.py  (tool-call decision extraction)
    - instrumentors/_guard.py          (prompt guard)

All other modules remain as plain .py files.

How the .py exclusion works:
    Cython produces .so / .pyd files but setuptools' default ``build_py``
    still ships the original .py source alongside them — defeating the
    obfuscation. Note: pyproject.toml's ``[tool.setuptools.exclude-package-data]``
    only filters NON-Python data files; it does NOT drop .py modules.
    The ``BuildPyExcludeCompiled`` cmdclass below is what actually removes the
    source from the wheel.

    See ``agentforge/areas/packages/IP_PROTECTION.md`` for the full rationale.

Editable installs (``pip install -e .``) skip cythonization and the cmdclass
override entirely (``_COMPILING`` is False), so dev workflow with breakpoints
and source navigation continues to work.
"""

import os
import sys

from setuptools import setup
from setuptools.command.build_py import build_py

# ---------------------------------------------------------------------------
# Only cythonize when building wheels — not during editable installs or when
# Cython is unavailable. Editable installs must keep .py readable so devs can
# set breakpoints and inspect source.
# ---------------------------------------------------------------------------
_COMPILING = any(
    arg in sys.argv for arg in ("build_ext", "bdist_wheel", "build", "install")
) and not os.environ.get("WAXELL_SKIP_CYTHON")

# (package, module) tuples — what to compile + what to exclude from .py shipping.
# Keep this list IN SYNC with scripts/verify_release.sh's `protected_for_package`
# block for the observe package; the verifier checks both ends.
_PROTECTED_MODULES = {
    ("waxell_observe", "context"),
    ("waxell_observe", "cost"),
    ("waxell_observe.tracing", "span_processor"),
    ("waxell_observe.instrumentors", "_auto_decision"),
    ("waxell_observe.instrumentors", "_guard"),
}


class BuildPyExcludeCompiled(build_py):
    """Drop protected .py modules from the wheel; only the .so / .pyd ships."""

    def find_package_modules(self, package, package_dir):
        return [
            (p, m, path)
            for (p, m, path) in super().find_package_modules(package, package_dir)
            if (p, m) not in _PROTECTED_MODULES
        ]


ext_modules = []
cmdclass = {}

if _COMPILING:
    try:
        from Cython.Build import cythonize
    except ImportError:
        print(
            "WARNING: Cython not found — skipping compilation of core modules. "
            "Install Cython>=3.0 to build compiled wheels.",
            file=sys.stderr,
        )
    else:
        _SRC = os.path.join("src", "waxell_observe")
        ext_modules = cythonize(
            [
                os.path.join(_SRC, "context.py"),
                os.path.join(_SRC, "cost.py"),
                os.path.join(_SRC, "tracing", "span_processor.py"),
                os.path.join(_SRC, "instrumentors", "_auto_decision.py"),
                os.path.join(_SRC, "instrumentors", "_guard.py"),
            ],
            compiler_directives={"language_level": "3"},
        )
        # Only swap in the filtering build_py when we actually compiled —
        # editable installs (no cythonize call) keep the default build_py
        # so .py source ships into the package directory normally.
        cmdclass["build_py"] = BuildPyExcludeCompiled

setup(ext_modules=ext_modules, cmdclass=cmdclass)
