"""Parity tests for `guard_schema.py` against the live SDK constants.

Until phase 2 of GUARD_CONFIG_UNIFICATION collapses the duplication,
the new canonical schema and the legacy `_DEFAULT_*` constants in
`guard.py` MUST match exactly. Drift here means the cloud editor
(which reads the schema) and the runtime enforcer (which reads the
constants) disagree on what a builtin default is.
"""

from __future__ import annotations


def test_schema_defaults_match_legacy_constants():
    from waxell_observe.integrations.claude_code import guard as legacy
    from waxell_observe.integrations.claude_code.guard_schema import (
        GUARD_CONFIG_DEFAULTS,
    )

    pairs = [
        ("blocked_command_patterns", legacy._DEFAULT_BLOCKED_COMMANDS),
        ("warn_command_patterns", legacy._DEFAULT_WARN_COMMANDS),
        ("protected_file_patterns", legacy._DEFAULT_PROTECTED_FILES),
        ("warn_file_patterns", legacy._DEFAULT_WARN_FILES),
        ("git_protected_branches", legacy._DEFAULT_PROTECTED_BRANCHES),
        ("infra_file_patterns", legacy._DEFAULT_INFRA_FILES),
    ]
    for field_name, legacy_value in pairs:
        assert GUARD_CONFIG_DEFAULTS[field_name] == legacy_value, (
            f"Drift: {field_name} differs between guard_schema.py and "
            f"guard.py. Update both or collapse the duplication "
            f"(phase 2 of GUARD_CONFIG_UNIFICATION)."
        )


def test_schema_scalar_defaults_match_dataclass():
    from waxell_observe.integrations.claude_code.guard import GuardConfig
    from waxell_observe.integrations.claude_code.guard_schema import (
        GUARD_CONFIG_DEFAULTS,
    )

    # The legacy GuardConfig dataclass uses field(default=...) for
    # scalars; instantiating with no args picks them up.
    legacy = GuardConfig()
    scalar_fields = (
        "path_boundary_enabled",
        "git_block_force_push",
        "git_block_hard_reset",
        "git_block_config_edit",
        "block_internal_urls",
        "max_file_changes",
        "warn_file_changes",
        "detect_file_conflicts",
    )
    for f in scalar_fields:
        assert GUARD_CONFIG_DEFAULTS[f] == getattr(legacy, f), (
            f"Drift: {f} differs between guard_schema and the legacy "
            f"GuardConfig dataclass."
        )


def test_to_json_schema_shape():
    """The cloud editor depends on this JSON Schema shape."""
    from waxell_observe.integrations.claude_code.guard_schema import (
        to_json_schema,
    )

    schema = to_json_schema()
    assert schema["type"] == "object"
    assert schema["additionalProperties"] is False
    props = schema["properties"]
    assert len(props) >= 15

    # Every property has a description, x-category, and default.
    for name, prop in props.items():
        assert "description" in prop, f"{name}: missing description"
        assert "x-category" in prop, f"{name}: missing x-category"
        assert "default" in prop, f"{name}: missing default"

    # Spot-check known types.
    assert props["block_internal_urls"]["type"] == "boolean"
    assert props["max_file_changes"]["type"] == "integer"
    assert props["blocked_command_patterns"]["type"] == "array"
    assert props["blocked_command_patterns"]["items"]["type"] == "string"


def test_field_categories_grouping():
    from waxell_observe.integrations.claude_code.guard_schema import (
        field_categories,
    )

    cats = field_categories()
    # Must have at least the categories the cloud editor expects.
    expected_categories = {
        "Commands",
        "Files",
        "Git",
        "Network",
        "Session",
        "Cowork",
        "Infrastructure",
    }
    assert set(cats.keys()) >= expected_categories, (
        f"Missing categories: {expected_categories - set(cats.keys())}"
    )
    # Spot-check assignments.
    assert "blocked_command_patterns" in cats["Commands"]
    assert "block_internal_urls" in cats["Network"]
    assert "infra_file_patterns" in cats["Infrastructure"]
