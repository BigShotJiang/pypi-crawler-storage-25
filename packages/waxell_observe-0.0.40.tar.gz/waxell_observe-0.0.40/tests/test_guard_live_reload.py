"""Live-reload tests for the per-hook config loader.

Phase 5 of GUARD_CONFIG_UNIFICATION — locks in the behaviour that
`load_config()` re-reads `~/.waxell/guard-effective.json` on every
call, so a cloud edit propagates to running Claude Code sessions
on the next PreToolUse hook fire (no session restart needed).
"""

from __future__ import annotations

import json
import os
import time
from unittest import mock


def test_load_from_effective_file_returns_effective_dict(tmp_path):
    """File present + fresh + agent_slug match → returns `effective`."""
    from waxell_observe.integrations.claude_code import guard

    f = tmp_path / "guard-effective.json"
    f.write_text(
        json.dumps(
            {
                "agent_slug": "my-agent",
                "effective": {"block_internal_urls": False, "max_file_changes": 99},
                "origins": {"block_internal_urls": "tenant"},
                "etag": "abc",
            }
        )
    )

    with mock.patch.object(guard, "_EFFECTIVE_PATH", f):
        out = guard._load_from_effective_file(agent_slug="my-agent")

    assert out == {"block_internal_urls": False, "max_file_changes": 99}


def test_load_from_effective_file_skips_stale(tmp_path):
    """File present but mtime older than freshness budget → None."""
    from waxell_observe.integrations.claude_code import guard

    f = tmp_path / "guard-effective.json"
    f.write_text(
        json.dumps({"agent_slug": "x", "effective": {"block_internal_urls": False}})
    )

    # Backdate mtime past the freshness budget.
    old = time.time() - guard._POLICY_POLLER_FRESHNESS_SECONDS - 60
    os.utime(f, (old, old))

    with mock.patch.object(guard, "_EFFECTIVE_PATH", f):
        out = guard._load_from_effective_file(agent_slug="x")

    assert out is None


def test_load_from_effective_file_skips_wrong_agent(tmp_path):
    """File pinned to a different agent → don't substitute."""
    from waxell_observe.integrations.claude_code import guard

    f = tmp_path / "guard-effective.json"
    f.write_text(
        json.dumps(
            {"agent_slug": "agent-A", "effective": {"block_internal_urls": False}}
        )
    )

    with mock.patch.object(guard, "_EFFECTIVE_PATH", f):
        out = guard._load_from_effective_file(agent_slug="agent-B")

    assert out is None


def test_load_from_effective_file_skips_corrupt(tmp_path):
    """Garbage JSON → None, no exception."""
    from waxell_observe.integrations.claude_code import guard

    f = tmp_path / "guard-effective.json"
    f.write_text("{not valid json")

    with mock.patch.object(guard, "_EFFECTIVE_PATH", f):
        out = guard._load_from_effective_file(agent_slug="x")

    assert out is None


def test_load_from_effective_file_skips_empty_effective(tmp_path):
    """Empty `effective` dict → fall through to next layer."""
    from waxell_observe.integrations.claude_code import guard

    f = tmp_path / "guard-effective.json"
    f.write_text(json.dumps({"agent_slug": "x", "effective": {}}))

    with mock.patch.object(guard, "_EFFECTIVE_PATH", f):
        out = guard._load_from_effective_file(agent_slug="x")

    assert out is None


def test_live_reload_picks_up_file_change(tmp_path):
    """Two reads with different file contents return different configs.

    This is the core P5 contract: a cloud-driven edit (which
    rewrites the file via the poller) is visible to the next hook
    invocation without the SDK keeping a stale cached copy.
    """
    from waxell_observe.integrations.claude_code import guard

    f = tmp_path / "guard-effective.json"

    with mock.patch.object(guard, "_EFFECTIVE_PATH", f):
        # First read.
        f.write_text(
            json.dumps({"agent_slug": "x", "effective": {"block_internal_urls": True}})
        )
        out1 = guard._load_from_effective_file(agent_slug="x")
        assert out1 == {"block_internal_urls": True}

        # Simulate a cloud edit propagated by the poller — file is
        # rewritten with new content. mtime advances naturally on
        # `write_text`. The loader must NOT have a stale in-process
        # cache.
        f.write_text(
            json.dumps({"agent_slug": "x", "effective": {"block_internal_urls": False}})
        )
        out2 = guard._load_from_effective_file(agent_slug="x")
        assert out2 == {"block_internal_urls": False}

    # Drives home the property: same function, two calls, two
    # different answers — no in-process caching is hiding state.
    assert out1 != out2


def test_load_config_has_no_in_process_cache():
    """`load_config` itself must not use lru_cache or any process-
    level cache. If someone wraps it, the live-reload contract
    breaks silently — fail loud."""
    from waxell_observe.integrations.claude_code import guard

    # functools.lru_cache attaches `cache_info` and `cache_clear`
    # attributes to the wrapped function.
    assert not hasattr(guard.load_config, "cache_info"), (
        "load_config should not be lru_cache'd — would break live reload"
    )
    assert not hasattr(guard.load_config, "cache_clear"), (
        "load_config should not be lru_cache'd — would break live reload"
    )
