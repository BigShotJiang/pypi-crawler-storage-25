"""Tests for the Cowork MCP server (E7 — Cowork MCP shim).

Covers:
- Tool registration shape (3 tools, schemas advertised correctly)
- Each tool's happy + error paths with the underlying HTTP client mocked
- Auth-failure (unconfigured client) fail-open behavior
- The stdio JSON-RPC loop end-to-end via StringIO
- The `.mcp.json` register/unregister helpers
"""

from __future__ import annotations

import io
import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from waxell_observe.integrations.cowork import (
    DEFAULT_COWORK_PROFILE,
    register_mcp_config,
    unregister_mcp_config,
)
from waxell_observe.integrations.cowork import mcp_server as cowork_mcp


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def configured_client():
    """A WaxellObserveClient mock that reports as fully configured."""
    client = MagicMock()
    client.config.is_configured = True
    client.config.agent_slug = "petrichor-cowork"
    return client


@pytest.fixture
def unconfigured_client():
    client = MagicMock()
    client.config.is_configured = False
    client.config.agent_slug = ""
    return client


# ---------------------------------------------------------------------------
# Tool registration shape
# ---------------------------------------------------------------------------


class TestToolRegistration:
    def test_three_tools_are_advertised(self):
        names = {t["name"] for t in cowork_mcp.TOOLS}
        assert names == {
            "waxell_check_policy",
            "waxell_budget_status",
            "waxell_record_decision",
        }

    def test_handlers_match_tools(self):
        # Every advertised tool must have a handler — a missing one would
        # 404 every call from Cowork.
        tool_names = {t["name"] for t in cowork_mcp.TOOLS}
        assert tool_names == set(cowork_mcp.HANDLERS.keys())

    def test_check_policy_schema(self):
        tool = next(t for t in cowork_mcp.TOOLS if t["name"] == "waxell_check_policy")
        schema = tool["inputSchema"]
        assert schema["type"] == "object"
        assert "action_kind" in schema["properties"]
        assert schema["required"] == ["action_kind"]

    def test_budget_status_schema_takes_no_args(self):
        tool = next(t for t in cowork_mcp.TOOLS if t["name"] == "waxell_budget_status")
        assert tool["inputSchema"]["properties"] == {}
        assert "required" not in tool["inputSchema"]

    def test_record_decision_schema(self):
        tool = next(
            t for t in cowork_mcp.TOOLS if t["name"] == "waxell_record_decision"
        )
        schema = tool["inputSchema"]
        assert set(schema["properties"]) >= {"reasoning", "decision", "confidence"}
        assert schema["required"] == ["reasoning", "decision"]

    def test_constants(self):
        # The whole point of the shim is to identify itself as Cowork so
        # server-side scopes match. Regression-guard the agent_name.
        assert cowork_mcp.COWORK_AGENT_NAME == "claude-cowork"
        assert cowork_mcp.COWORK_AGENT_TYPE == "claude-cowork"


# ---------------------------------------------------------------------------
# waxell_check_policy
# ---------------------------------------------------------------------------


class TestCheckPolicyTool:
    def test_allows_when_unconfigured(self, unconfigured_client):
        with patch.object(
            cowork_mcp, "WaxellObserveClient", return_value=unconfigured_client
        ):
            result = cowork_mcp._tool_check_policy(
                {"action_kind": "shell", "action_summary": "rm -rf /"}
            )
        assert result["allowed"] is True
        assert "not configured" in result["reason"].lower()
        assert result["suggested_alternative"] == ""

    def test_passes_cowork_agent_name(self, configured_client):
        policy_result = MagicMock(
            action="allow", reason="No policy matched", metadata={}
        )
        configured_client.check_policy_sync.return_value = policy_result

        with patch.object(
            cowork_mcp, "WaxellObserveClient", return_value=configured_client
        ):
            cowork_mcp._tool_check_policy(
                {"action_kind": "shell", "action_summary": "ls -la"}
            )

        configured_client.check_policy_sync.assert_called_once()
        kwargs = configured_client.check_policy_sync.call_args.kwargs
        assert kwargs["agent_name"] == "claude-cowork"
        assert kwargs["workflow_name"].startswith("mcp:")
        assert kwargs["inputs"]["action_kind"] == "shell"
        assert kwargs["inputs"]["source"] == "cowork-mcp-shim"

    def test_block_action_returns_allowed_false(self, configured_client):
        policy_result = MagicMock(
            action="block",
            reason="Network egress restricted",
            metadata={
                "suggested_alternative": "Use the Connect domain endpoint instead"
            },
        )
        configured_client.check_policy_sync.return_value = policy_result

        with patch.object(
            cowork_mcp, "WaxellObserveClient", return_value=configured_client
        ):
            result = cowork_mcp._tool_check_policy(
                {"action_kind": "network", "action_summary": "POST internal-api.corp"}
            )

        assert result["allowed"] is False
        assert result["action"] == "block"
        assert result["reason"] == "Network egress restricted"
        assert (
            result["suggested_alternative"] == "Use the Connect domain endpoint instead"
        )

    def test_warn_action_still_allowed(self, configured_client):
        policy_result = MagicMock(action="warn", reason="Risky", metadata={})
        configured_client.check_policy_sync.return_value = policy_result

        with patch.object(
            cowork_mcp, "WaxellObserveClient", return_value=configured_client
        ):
            result = cowork_mcp._tool_check_policy({"action_kind": "shell"})

        assert result["allowed"] is True
        assert result["action"] == "warn"

    def test_empty_action_kind_returns_allow(self, configured_client):
        with patch.object(
            cowork_mcp, "WaxellObserveClient", return_value=configured_client
        ):
            result = cowork_mcp._tool_check_policy({"action_kind": "  "})
        assert result["allowed"] is True
        assert "no action_kind" in result["reason"].lower()
        configured_client.check_policy_sync.assert_not_called()

    def test_http_failure_fails_open(self, configured_client):
        configured_client.check_policy_sync.side_effect = RuntimeError("network down")
        with patch.object(
            cowork_mcp, "WaxellObserveClient", return_value=configured_client
        ):
            result = cowork_mcp._tool_check_policy({"action_kind": "shell"})
        assert result["allowed"] is True
        assert "policy check failed" in result["reason"].lower()

    def test_remediation_fallback_keys(self, configured_client):
        # "remediation" is the older metadata key — make sure we still
        # surface it as suggested_alternative.
        policy_result = MagicMock(
            action="block",
            reason="boom",
            metadata={"remediation": "ask a human"},
        )
        configured_client.check_policy_sync.return_value = policy_result

        with patch.object(
            cowork_mcp, "WaxellObserveClient", return_value=configured_client
        ):
            result = cowork_mcp._tool_check_policy({"action_kind": "shell"})

        assert result["suggested_alternative"] == "ask a human"


# ---------------------------------------------------------------------------
# waxell_budget_status
# ---------------------------------------------------------------------------


class TestBudgetStatusTool:
    def test_unconfigured_returns_empty_snapshot(self, unconfigured_client):
        with patch.object(
            cowork_mcp, "WaxellObserveClient", return_value=unconfigured_client
        ):
            result = cowork_mcp._tool_budget_status({})
        assert result["status"] == "unconfigured"
        assert result["tokens_used_today"] == 0
        assert result["cost_used_today"] == 0.0
        assert result["percent_used"] == 0.0

    def test_no_agent_slug(self, configured_client):
        configured_client.config.agent_slug = ""
        with patch.object(
            cowork_mcp, "WaxellObserveClient", return_value=configured_client
        ):
            result = cowork_mcp._tool_budget_status({})
        assert result["status"] == "no_agent"
        # Should NOT have called start_daily_run_sync — we short-circuit
        # before attempting it.
        configured_client.start_daily_run_sync.assert_not_called()

    def test_happy_path_returns_run_id(self, configured_client):
        daily = MagicMock(run_id="run_abc", date="2026-05-02")
        configured_client.start_daily_run_sync.return_value = daily

        with patch.object(
            cowork_mcp, "WaxellObserveClient", return_value=configured_client
        ):
            result = cowork_mcp._tool_budget_status({})

        configured_client.start_daily_run_sync.assert_called_once_with(
            agent_slug="petrichor-cowork", agent_type="claude-cowork"
        )
        assert result["status"] == "ok"
        assert result["run_id"] == "run_abc"
        assert result["date"] == "2026-05-02"
        # All five spec fields must be present (model conditions on them).
        for key in (
            "tokens_used_today",
            "tokens_limit",
            "cost_used_today",
            "cost_limit",
            "percent_used",
        ):
            assert key in result

    def test_daily_run_failure_returns_no_agent(self, configured_client):
        configured_client.start_daily_run_sync.side_effect = RuntimeError("unreachable")
        with patch.object(
            cowork_mcp, "WaxellObserveClient", return_value=configured_client
        ):
            result = cowork_mcp._tool_budget_status({})
        # Failure to fetch the daily run degrades to no_agent without crashing.
        assert result["status"] == "no_agent"


# ---------------------------------------------------------------------------
# waxell_record_decision
# ---------------------------------------------------------------------------


class TestRecordDecisionTool:
    def test_requires_reasoning_and_decision(self, configured_client):
        with patch.object(
            cowork_mcp, "WaxellObserveClient", return_value=configured_client
        ):
            result = cowork_mcp._tool_record_decision({"reasoning": "", "decision": ""})
        assert result["recorded"] is False
        configured_client.record_spans_sync.assert_not_called()

    def test_unconfigured_does_not_record(self, unconfigured_client):
        with patch.object(
            cowork_mcp, "WaxellObserveClient", return_value=unconfigured_client
        ):
            result = cowork_mcp._tool_record_decision(
                {"reasoning": "because", "decision": "ship it"}
            )
        assert result["recorded"] is False
        unconfigured_client.record_spans_sync.assert_not_called()

    def test_happy_path_records_span_with_cowork_attribution(self, configured_client):
        daily = MagicMock(run_id="run_xyz", date="2026-05-02")
        configured_client.start_daily_run_sync.return_value = daily

        with patch.object(
            cowork_mcp, "WaxellObserveClient", return_value=configured_client
        ):
            result = cowork_mcp._tool_record_decision(
                {
                    "reasoning": "API was rate-limited so we cached",
                    "decision": "use cached result",
                    "confidence": 0.85,
                }
            )

        assert result["recorded"] is True
        assert result["run_id"] == "run_xyz"
        configured_client.record_spans_sync.assert_called_once()
        kwargs = configured_client.record_spans_sync.call_args.kwargs
        assert kwargs["run_id"] == "run_xyz"
        spans = kwargs["spans"]
        assert len(spans) == 1
        span = spans[0]
        assert span["name"] == "cowork:decision"
        assert span["kind"] == "decision"
        # agent_type stamp lets the controlplane scope by claude-cowork
        assert span["attributes"]["agent_type"] == "claude-cowork"
        assert span["attributes"]["decision.confidence"] == 0.85
        assert span["attributes"]["decision.source"] == "cowork-mcp-shim"

    def test_invalid_confidence_falls_back_to_zero(self, configured_client):
        configured_client.start_daily_run_sync.return_value = MagicMock(
            run_id="run_xyz", date="2026-05-02"
        )
        with patch.object(
            cowork_mcp, "WaxellObserveClient", return_value=configured_client
        ):
            result = cowork_mcp._tool_record_decision(
                {"reasoning": "r", "decision": "d", "confidence": "not-a-number"}
            )
        assert result["recorded"] is True
        span = configured_client.record_spans_sync.call_args.kwargs["spans"][0]
        assert span["attributes"]["decision.confidence"] == 0.0

    def test_record_failure_returns_recorded_false(self, configured_client):
        configured_client.start_daily_run_sync.return_value = MagicMock(
            run_id="run_xyz", date="2026-05-02"
        )
        configured_client.record_spans_sync.side_effect = RuntimeError("500")
        with patch.object(
            cowork_mcp, "WaxellObserveClient", return_value=configured_client
        ):
            result = cowork_mcp._tool_record_decision(
                {"reasoning": "r", "decision": "d"}
            )
        assert result["recorded"] is False
        assert "500" in result["reason"]


# ---------------------------------------------------------------------------
# stdio JSON-RPC loop (end-to-end protocol test)
# ---------------------------------------------------------------------------


class TestStdioLoop:
    @staticmethod
    def _drive(messages: list[dict]) -> list[dict]:
        """Feed JSON-RPC frames into the server, return parsed responses."""
        stdin = io.StringIO("\n".join(json.dumps(m) for m in messages) + "\n")
        stdout = io.StringIO()
        cowork_mcp.run_mcp_server(stdin=stdin, stdout=stdout)
        out_lines = [l for l in stdout.getvalue().splitlines() if l.strip()]
        return [json.loads(l) for l in out_lines]

    def test_initialize_returns_server_info(self):
        responses = self._drive(
            [{"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {}}]
        )
        assert len(responses) == 1
        result = responses[0]["result"]
        assert result["serverInfo"]["name"] == "waxell-observe-cowork"
        assert "tools" in result["capabilities"]
        assert result["protocolVersion"] == "2024-11-05"

    def test_tools_list_returns_three_tools(self):
        responses = self._drive([{"jsonrpc": "2.0", "id": 2, "method": "tools/list"}])
        tools = responses[0]["result"]["tools"]
        assert len(tools) == 3
        assert {t["name"] for t in tools} == {
            "waxell_check_policy",
            "waxell_budget_status",
            "waxell_record_decision",
        }

    def test_unknown_method_returns_method_not_found(self):
        responses = self._drive([{"jsonrpc": "2.0", "id": 3, "method": "nonsense"}])
        assert responses[0]["error"]["code"] == -32601

    def test_unknown_tool_returns_invalid_params(self):
        responses = self._drive(
            [
                {
                    "jsonrpc": "2.0",
                    "id": 4,
                    "method": "tools/call",
                    "params": {"name": "no_such_tool", "arguments": {}},
                }
            ]
        )
        assert responses[0]["error"]["code"] == -32602

    def test_notifications_initialized_emits_no_response(self):
        responses = self._drive(
            [{"jsonrpc": "2.0", "method": "notifications/initialized"}]
        )
        assert responses == []

    def test_ping_returns_empty_result(self):
        responses = self._drive([{"jsonrpc": "2.0", "id": 5, "method": "ping"}])
        assert responses[0]["result"] == {}

    def test_tool_call_dispatches_to_handler(self, unconfigured_client):
        # Drive a real tools/call through the loop; with an unconfigured
        # client check_policy fails open and we should see the JSON
        # decoded out of the content text part.
        with patch.object(
            cowork_mcp, "WaxellObserveClient", return_value=unconfigured_client
        ):
            responses = self._drive(
                [
                    {
                        "jsonrpc": "2.0",
                        "id": 6,
                        "method": "tools/call",
                        "params": {
                            "name": "waxell_check_policy",
                            "arguments": {"action_kind": "shell"},
                        },
                    }
                ]
            )
        assert len(responses) == 1
        content = responses[0]["result"]["content"]
        assert content[0]["type"] == "text"
        payload = json.loads(content[0]["text"])
        assert payload["allowed"] is True
        assert "not configured" in payload["reason"].lower()


# ---------------------------------------------------------------------------
# .mcp.json registration helper
# ---------------------------------------------------------------------------


class TestMcpRegistration:
    def test_register_creates_file(self, tmp_path: Path):
        target = tmp_path / ".mcp.json"
        written = register_mcp_config(path=target)
        assert written == target
        cfg = json.loads(target.read_text())
        assert "mcpServers" in cfg
        entry = cfg["mcpServers"]["waxell-observe-claude-cowork"]
        assert entry["type"] == "stdio"
        assert entry["command"] == "wax"
        assert entry["args"] == ["--profile", "claude-cowork", "cowork", "mcp-server"]

    def test_register_preserves_other_servers(self, tmp_path: Path):
        target = tmp_path / ".mcp.json"
        target.write_text(
            json.dumps(
                {
                    "mcpServers": {
                        "some-other-server": {"type": "stdio", "command": "other"}
                    },
                    "unrelatedKey": {"keep": "me"},
                }
            )
        )
        register_mcp_config(path=target)
        cfg = json.loads(target.read_text())
        # Both old + new servers must be present
        assert set(cfg["mcpServers"]) == {
            "some-other-server",
            "waxell-observe-claude-cowork",
        }
        # Unrelated top-level keys must survive
        assert cfg["unrelatedKey"] == {"keep": "me"}

    def test_register_is_idempotent(self, tmp_path: Path):
        target = tmp_path / ".mcp.json"
        register_mcp_config(path=target)
        first = target.read_text()
        register_mcp_config(path=target)
        # Two writes should be byte-identical (no duplicate entry, no key
        # reorder).
        assert target.read_text() == first

    def test_register_custom_profile(self, tmp_path: Path):
        target = tmp_path / ".mcp.json"
        register_mcp_config(path=target, profile="bethpc")
        cfg = json.loads(target.read_text())
        assert "waxell-observe-bethpc" in cfg["mcpServers"]
        entry = cfg["mcpServers"]["waxell-observe-bethpc"]
        assert entry["args"][1] == "bethpc"

    def test_unregister_removes_entry(self, tmp_path: Path):
        target = tmp_path / ".mcp.json"
        register_mcp_config(path=target)
        assert unregister_mcp_config(path=target) is True
        cfg = json.loads(target.read_text())
        assert "waxell-observe-claude-cowork" not in cfg.get("mcpServers", {})

    def test_unregister_returns_false_when_missing(self, tmp_path: Path):
        target = tmp_path / ".mcp.json"
        target.write_text(json.dumps({"mcpServers": {}}))
        assert unregister_mcp_config(path=target) is False

    def test_unregister_no_file(self, tmp_path: Path):
        # No file exists at all — should be a no-op return False.
        assert unregister_mcp_config(path=tmp_path / "never.json") is False

    def test_default_profile_constant(self):
        assert DEFAULT_COWORK_PROFILE == "claude-cowork"
