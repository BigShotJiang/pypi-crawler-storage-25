"""Tests for the C6 MCP keep-alive layer (`_mcp_shared`).

Covers:
- `_safe_write` returns False on stdout that times out / errors
- The keep-alive ping thread sends a `{"method": "ping"}` notification
  every interval and tracks failures
- Two consecutive ping failures flip `should_stop` so the dispatch loop
  exits cleanly even if stdin is still open
- The dispatch loop never raises when stdout is unwritable

The tests fake stdout writability with a `select.select` patch so they
run in milliseconds — no real socket / pipe is involved.
"""

from __future__ import annotations

import io
import json
import threading
import time
from typing import Any
from unittest.mock import patch


from waxell_observe.integrations import _mcp_shared


# ---------------------------------------------------------------------------
# Fakes
# ---------------------------------------------------------------------------


class _DeadStdout:
    """A stdout-like object whose fileno() reports an fd that select
    will treat as unwritable.

    We expose a real-looking fileno (0 — stdin in this process) but every
    test patches `select.select` to return an empty writable list, which
    is what an unwritable pipe looks like.
    """

    def __init__(self) -> None:
        self.writes: list[str] = []
        self._closed = False

    def fileno(self) -> int:
        return 0

    def write(self, data: str) -> int:
        if self._closed:
            raise BrokenPipeError("dead reader")
        self.writes.append(data)
        return len(data)

    def flush(self) -> None:
        if self._closed:
            raise BrokenPipeError("dead reader")

    def close(self) -> None:
        self._closed = True


class _BlockingStdin:
    """Stdin that blocks `__iter__` until `release()` is called.

    Used to simulate "Claude Code stops reading but keeps the pipe
    open" — the dispatch loop would otherwise block on stdin and never
    notice the dead reader. The keep-alive thread is what saves us.
    """

    def __init__(self) -> None:
        self._gate = threading.Event()
        self._lines: list[str] = []

    def feed(self, line: str) -> None:
        self._lines.append(line)
        self._gate.set()

    def release(self) -> None:
        self._gate.set()

    def __iter__(self):
        # Yield any pre-fed lines first.
        while self._lines:
            yield self._lines.pop(0)
        # Then block until release(); after release the iterator ends.
        self._gate.wait(timeout=10)
        return


# ---------------------------------------------------------------------------
# _safe_write
# ---------------------------------------------------------------------------


class TestSafeWrite:
    def test_returns_true_on_writable_stream(self):
        # StringIO has no real fileno — _safe_write should fall through
        # the select probe and just write.
        buf = io.StringIO()
        ok = _mcp_shared._safe_write(buf, "hi\n", write_timeout=5.0)
        assert ok is True
        assert buf.getvalue() == "hi\n"

    def test_returns_false_when_stdout_not_writable(self):
        out = _DeadStdout()
        with patch.object(_mcp_shared.select, "select", return_value=([], [], [])):
            ok = _mcp_shared._safe_write(out, "x\n", write_timeout=0.01)
        assert ok is False
        # Nothing was written — the timeout short-circuited before write().
        assert out.writes == []

    def test_returns_false_on_broken_pipe(self):
        out = _DeadStdout()
        out.close()  # make subsequent writes raise BrokenPipeError
        # select reports writable, but the actual write() raises.
        with patch.object(_mcp_shared.select, "select", return_value=([], [0], [])):
            ok = _mcp_shared._safe_write(out, "x\n", write_timeout=5.0)
        assert ok is False

    def test_no_fileno_falls_back_to_synchronous_write(self):
        # Plain object without fileno — _stdout_writable should return True
        # without calling select at all.
        class NoFileno:
            def __init__(self):
                self.buf = ""

            def write(self, data):
                self.buf += data

            def flush(self):
                pass

        out = NoFileno()
        with patch.object(_mcp_shared.select, "select") as mock_select:
            ok = _mcp_shared._safe_write(out, "x\n", write_timeout=5.0)
        assert ok is True
        assert out.buf == "x\n"
        mock_select.assert_not_called()


# ---------------------------------------------------------------------------
# _KeepAlive thread
# ---------------------------------------------------------------------------


class TestKeepAliveThread:
    def test_sends_ping_when_writable(self):
        buf = io.StringIO()
        ka = _mcp_shared._KeepAlive(
            buf,
            threading.Lock(),
            interval=0.05,
            write_timeout=5.0,
            failure_threshold=2,
        )
        ka.start()
        try:
            # Wait for at least one ping.
            time.sleep(0.2)
        finally:
            ka.stop()
        text = buf.getvalue()
        assert '"method": "ping"' in text
        # At least one full ping line; should NOT have flipped should_stop
        # because writes succeeded.
        assert ka.should_stop is False

    def test_two_consecutive_failures_set_stop(self):
        out = _DeadStdout()
        ka = _mcp_shared._KeepAlive(
            out,
            threading.Lock(),
            interval=0.05,
            write_timeout=0.01,
            failure_threshold=2,
        )
        with patch.object(_mcp_shared.select, "select", return_value=([], [], [])):
            ka.start()
            # Wait long enough for >=2 ping attempts at 0.05s spacing.
            deadline = time.time() + 5.0
            while time.time() < deadline and not ka.should_stop:
                time.sleep(0.02)
            ka.stop()
        assert ka.should_stop is True
        assert out.writes == []  # nothing made it through

    def test_disabled_when_interval_zero(self):
        buf = io.StringIO()
        ka = _mcp_shared._KeepAlive(
            buf,
            threading.Lock(),
            interval=0,
            write_timeout=5.0,
            failure_threshold=2,
        )
        ka.start()
        time.sleep(0.05)
        ka.stop()
        # No thread, no pings.
        assert buf.getvalue() == ""
        assert ka.should_stop is False


# ---------------------------------------------------------------------------
# run_stdio_loop end-to-end with dead reader
# ---------------------------------------------------------------------------


class TestStdioLoopKeepAlive:
    def test_loop_exits_within_60s_when_pings_fail_twice(self):
        """The whole point of C6: an unwritable stdout must not hang the
        server. With ping_interval=0.05 and threshold=2, we expect the
        keep-alive to mark the loop dead in well under 60s; the test
        asserts the full bound from the spec."""
        out = _DeadStdout()
        stdin = _BlockingStdin()

        thread_done = threading.Event()
        exc: dict[str, Any] = {}

        def runner():
            try:
                with patch.object(
                    _mcp_shared.select, "select", return_value=([], [], [])
                ):
                    _mcp_shared.run_stdio_loop(
                        server_name="test",
                        server_version="0.0.0",
                        tools=[],
                        handlers={},
                        stdin=stdin,
                        stdout=out,
                        write_timeout=0.01,
                        ping_interval=0.05,
                        ping_failure_threshold=2,
                    )
            except BaseException as e:  # pragma: no cover - defensive
                exc["err"] = e
            finally:
                thread_done.set()

        t = threading.Thread(target=runner, daemon=True)
        t.start()

        # Give the keep-alive a moment to flip should_stop.
        time.sleep(0.5)
        # Send a line so the for-line loop wakes up, sees should_stop, and
        # exits the dispatch.
        stdin.feed('{"jsonrpc": "2.0", "id": 1, "method": "ping"}\n')
        # And release the iterator end so even if should_stop hadn't
        # propagated, stdin EOF still ends the loop.
        stdin.release()

        # The 60s bound is the spec's outer deadline. In practice this
        # finishes in <1s on every machine we care about; we use a
        # tighter assertion here so a hang fails the test fast.
        assert thread_done.wait(timeout=10.0), (
            "run_stdio_loop did not exit after dead-reader detection"
        )
        assert exc == {}, f"loop raised: {exc.get('err')!r}"

    def test_loop_handles_normal_traffic_with_keepalive_enabled(self):
        """Sanity: a working stdout still gets responses with the new
        write path. Regression-guard against breaking the happy path
        while wiring in the keep-alive."""
        stdin = io.StringIO(
            json.dumps({"jsonrpc": "2.0", "id": 1, "method": "tools/list"}) + "\n"
        )
        stdout = io.StringIO()
        # Disable the ping thread so we don't race with the test reading
        # stdout — `tools/list` is the only frame we want to see here.
        _mcp_shared.run_stdio_loop(
            server_name="test",
            server_version="0.0.0",
            tools=[{"name": "x", "description": "", "inputSchema": {"type": "object"}}],
            handlers={},
            stdin=stdin,
            stdout=stdout,
            ping_interval=0,
        )
        out_lines = [l for l in stdout.getvalue().splitlines() if l.strip()]
        assert len(out_lines) == 1
        resp = json.loads(out_lines[0])
        assert resp["result"]["tools"][0]["name"] == "x"

    def test_dropped_response_does_not_raise(self):
        """If a tool response can't be written (timed-out stdout), the
        loop must keep running rather than throwing the JSON encode +
        write error up to the caller."""
        out = _DeadStdout()
        stdin = io.StringIO(
            json.dumps({"jsonrpc": "2.0", "id": 1, "method": "tools/list"}) + "\n"
        )
        with patch.object(_mcp_shared.select, "select", return_value=([], [], [])):
            # No exception expected — the dropped write is logged at debug.
            _mcp_shared.run_stdio_loop(
                server_name="test",
                server_version="0.0.0",
                tools=[],
                handlers={},
                stdin=stdin,
                stdout=out,
                write_timeout=0.01,
                ping_interval=0,
            )
        assert out.writes == []


# ---------------------------------------------------------------------------
# Cowork + Claude Code servers both inherit C6 via the shared loop
# ---------------------------------------------------------------------------


class TestSharedDispatchAcrossServers:
    def test_cowork_uses_shared_loop(self):
        from waxell_observe.integrations.cowork import mcp_server as cowork_mcp

        # Sanity: the function delegates to the shared module.
        assert cowork_mcp.run_stdio_loop is _mcp_shared.run_stdio_loop

    def test_claude_code_uses_shared_loop(self):
        from waxell_observe.integrations.claude_code import mcp_server as cc_mcp

        # The CC server was rewritten in C6 to delegate to the shared
        # loop — so the C6 keep-alive applies to both servers without
        # needing per-server wiring.
        assert cc_mcp.run_stdio_loop is _mcp_shared.run_stdio_loop
