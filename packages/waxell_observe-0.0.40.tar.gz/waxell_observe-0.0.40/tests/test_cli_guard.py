"""Tests for `wax guard config` CLI subcommands.

Covers B8 of EXTERNAL_AGENT_GOVERNANCE: show / set / validate / push.
HOME is redirected to a tmp_path so tests never touch the real
~/.waxell/.
"""

from __future__ import annotations

import json

import pytest
from click.testing import CliRunner

from waxell_observe.cli.commands.guard import guard


@pytest.fixture
def fake_home(tmp_path, monkeypatch):
    """Redirect HOME so guard.json writes land in tmp_path."""
    home = tmp_path / "home"
    home.mkdir()
    monkeypatch.setenv("HOME", str(home))
    # Some Path.home() impls cache via expanduser — ensure both work.
    monkeypatch.setenv("USERPROFILE", str(home))
    return home


@pytest.fixture
def fake_project(tmp_path):
    """Empty project directory for --project-dir tests."""
    proj = tmp_path / "proj"
    proj.mkdir()
    return proj


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture(autouse=True)
def _no_remote_client(monkeypatch):
    """Force `_get_client()` to return None so `show` doesn't try to
    hit a real controlplane during tests."""
    from waxell_observe.cli.commands import guard as guard_mod

    monkeypatch.setattr(guard_mod, "_get_client", lambda: None)


# ---------------------------------------------------------------------------
# show
# ---------------------------------------------------------------------------


class TestShow:
    def test_show_with_no_files_prints_builtin_defaults(
        self, runner, fake_home, fake_project
    ):
        result = runner.invoke(
            guard, ["config", "show", "--project-dir", str(fake_project)]
        )
        assert result.exit_code == 0, result.output
        # Headers
        assert "# Sources" in result.output
        assert "builtin" in result.output
        # No user / project file should be listed since neither exists.
        assert "user (" not in result.output
        assert "project (" not in result.output
        # The JSON payload should parse and contain default fields.
        payload = result.output.split("\n\n", 1)[1]
        cfg = json.loads(payload)
        assert cfg["max_file_changes"] == 50
        assert cfg["block_internal_urls"] is True
        assert isinstance(cfg["blocked_command_patterns"], list)

    def test_show_after_user_edit_reflects_change(
        self, runner, fake_home, fake_project
    ):
        # Seed a user file.
        user_path = fake_home / ".waxell" / "guard.json"
        user_path.parent.mkdir(parents=True)
        user_path.write_text(json.dumps({"max_file_changes": 999}))

        result = runner.invoke(
            guard, ["config", "show", "--project-dir", str(fake_project)]
        )
        assert result.exit_code == 0, result.output
        assert "user (" in result.output
        payload = result.output.split("\n\n", 1)[1]
        cfg = json.loads(payload)
        assert cfg["max_file_changes"] == 999


# ---------------------------------------------------------------------------
# set
# ---------------------------------------------------------------------------


class TestSet:
    def test_set_int_user_scope_writes_and_show_reads_back(
        self, runner, fake_home, fake_project
    ):
        result = runner.invoke(
            guard,
            ["config", "set", "max_file_changes", "100", "--type", "int", "--user"],
        )
        assert result.exit_code == 0, result.output

        user_path = fake_home / ".waxell" / "guard.json"
        assert user_path.exists()
        on_disk = json.loads(user_path.read_text())
        assert on_disk == {"max_file_changes": 100}

        # show round-trip
        show_result = runner.invoke(
            guard, ["config", "show", "--project-dir", str(fake_project)]
        )
        assert show_result.exit_code == 0
        payload = show_result.output.split("\n\n", 1)[1]
        cfg = json.loads(payload)
        assert cfg["max_file_changes"] == 100

    def test_set_bool_coercion(self, runner, fake_home):
        result = runner.invoke(
            guard,
            [
                "config",
                "set",
                "git_block_force_push",
                "false",
                "--type",
                "bool",
                "--user",
            ],
        )
        assert result.exit_code == 0, result.output
        on_disk = json.loads((fake_home / ".waxell" / "guard.json").read_text())
        assert on_disk == {"git_block_force_push": False}

    def test_set_list_coercion(self, runner, fake_home):
        result = runner.invoke(
            guard,
            [
                "config",
                "set",
                "blocked_domains",
                "evil.com, bad.io ,scam.net",
                "--type",
                "list",
                "--user",
            ],
        )
        assert result.exit_code == 0, result.output
        on_disk = json.loads((fake_home / ".waxell" / "guard.json").read_text())
        assert on_disk == {"blocked_domains": ["evil.com", "bad.io", "scam.net"]}

    def test_set_project_scope_writes_to_project_dir(
        self, runner, fake_home, fake_project
    ):
        result = runner.invoke(
            guard,
            [
                "config",
                "set",
                "max_file_changes",
                "42",
                "--type",
                "int",
                "--project",
                "--project-dir",
                str(fake_project),
            ],
        )
        assert result.exit_code == 0, result.output
        proj_path = fake_project / ".waxell" / "guard.json"
        assert proj_path.exists()
        assert json.loads(proj_path.read_text()) == {"max_file_changes": 42}
        # User file should NOT have been touched.
        assert not (fake_home / ".waxell" / "guard.json").exists()

    def test_set_unknown_field_fails(self, runner, fake_home):
        result = runner.invoke(
            guard, ["config", "set", "unknown_field", "foo", "--user"]
        )
        assert result.exit_code != 0
        # Error must list the valid fields so users can fix typos.
        assert "unknown field" in result.output.lower()
        assert "max_file_changes" in result.output
        assert "blocked_command_patterns" in result.output

    def test_set_bad_int_fails(self, runner, fake_home):
        result = runner.invoke(
            guard,
            [
                "config",
                "set",
                "max_file_changes",
                "not-a-number",
                "--type",
                "int",
                "--user",
            ],
        )
        assert result.exit_code != 0
        assert "int" in result.output.lower()

    def test_set_bad_bool_fails(self, runner, fake_home):
        result = runner.invoke(
            guard,
            [
                "config",
                "set",
                "git_block_force_push",
                "maybe",
                "--type",
                "bool",
                "--user",
            ],
        )
        assert result.exit_code != 0
        assert "bool" in result.output.lower()

    def test_set_preserves_existing_keys(self, runner, fake_home):
        # Pre-seed user file with another key.
        user_path = fake_home / ".waxell" / "guard.json"
        user_path.parent.mkdir(parents=True)
        user_path.write_text(json.dumps({"warn_file_changes": 5}))

        result = runner.invoke(
            guard,
            ["config", "set", "max_file_changes", "200", "--type", "int", "--user"],
        )
        assert result.exit_code == 0, result.output
        on_disk = json.loads(user_path.read_text())
        assert on_disk == {"warn_file_changes": 5, "max_file_changes": 200}

    def test_set_refuses_to_overwrite_malformed_json(self, runner, fake_home):
        user_path = fake_home / ".waxell" / "guard.json"
        user_path.parent.mkdir(parents=True)
        user_path.write_text("{not valid json")

        result = runner.invoke(
            guard,
            ["config", "set", "max_file_changes", "1", "--type", "int", "--user"],
        )
        assert result.exit_code != 0
        # File untouched.
        assert user_path.read_text() == "{not valid json"

    def test_set_project_and_user_mutually_exclusive(self, runner, fake_home):
        result = runner.invoke(
            guard,
            [
                "config",
                "set",
                "max_file_changes",
                "1",
                "--type",
                "int",
                "--project",
                "--user",
            ],
        )
        assert result.exit_code != 0
        assert "mutually exclusive" in result.output.lower()


# ---------------------------------------------------------------------------
# validate
# ---------------------------------------------------------------------------


class TestValidate:
    def test_validate_clean_config_exits_zero(self, runner, fake_home, fake_project):
        # Both files clean.
        user_path = fake_home / ".waxell" / "guard.json"
        user_path.parent.mkdir(parents=True)
        user_path.write_text(json.dumps({"max_file_changes": 30}))

        proj_path = fake_project / ".waxell" / "guard.json"
        proj_path.parent.mkdir(parents=True)
        proj_path.write_text(json.dumps({"git_block_force_push": True}))

        result = runner.invoke(
            guard, ["config", "validate", "--project-dir", str(fake_project)]
        )
        assert result.exit_code == 0, result.output
        assert "OK" in result.output

    def test_validate_missing_files_exits_zero(self, runner, fake_home, fake_project):
        result = runner.invoke(
            guard, ["config", "validate", "--project-dir", str(fake_project)]
        )
        assert result.exit_code == 0, result.output
        assert "missing" in result.output

    def test_validate_malformed_json_exits_one(self, runner, fake_home, fake_project):
        user_path = fake_home / ".waxell" / "guard.json"
        user_path.parent.mkdir(parents=True)
        user_path.write_text("{not valid json")

        result = runner.invoke(
            guard, ["config", "validate", "--project-dir", str(fake_project)]
        )
        assert result.exit_code == 1, result.output
        assert "INVALID" in result.output
        assert "invalid JSON" in result.output

    def test_validate_unknown_field_exits_one(self, runner, fake_home, fake_project):
        user_path = fake_home / ".waxell" / "guard.json"
        user_path.parent.mkdir(parents=True)
        user_path.write_text(json.dumps({"completely_made_up_field": 1}))

        result = runner.invoke(
            guard, ["config", "validate", "--project-dir", str(fake_project)]
        )
        assert result.exit_code == 1, result.output
        assert "unknown field" in result.output


# ---------------------------------------------------------------------------
# push (stub)
# ---------------------------------------------------------------------------


class TestPush:
    def test_push_is_stubbed_with_helpful_error(self, runner):
        result = runner.invoke(guard, ["config", "push"])
        assert result.exit_code != 0
        assert "not yet supported" in result.output.lower()
        assert "B7" in result.output


# ---------------------------------------------------------------------------
# help / discoverability
# ---------------------------------------------------------------------------


class TestHelp:
    def test_guard_config_help_lists_subcommands(self, runner):
        result = runner.invoke(guard, ["config", "--help"])
        assert result.exit_code == 0
        for sub in ("show", "set", "validate", "push"):
            assert sub in result.output
