"""Shared data types for waxell-observe."""

from dataclasses import dataclass, field


@dataclass
class RunInfo:
    """Information about a started execution run."""

    run_id: str
    workflow_id: str
    started_at: str


@dataclass
class DailyRunInfo:
    """Get-or-create result for a Connect agent's daily session run."""

    run_id: str
    workflow_id: str
    started_at: str
    date: str
    created: bool


@dataclass
class PolicyCheckResult:
    """Result of a policy check against the controlplane."""

    action: str  # "allow", "block", "warn", "throttle", "retry", "redact"
    reason: str = ""
    metadata: dict = field(default_factory=dict)
    evaluations: list = field(default_factory=list)
    redacted_inputs: dict | None = None

    @property
    def allowed(self) -> bool:
        return self.action in ("allow", "warn", "redact")

    @property
    def blocked(self) -> bool:
        return self.action in ("block", "throttle")

    @property
    def should_redact(self) -> bool:
        return self.action == "redact"

    @property
    def should_retry(self) -> bool:
        return self.action == "retry"


@dataclass
class RunCompleteResult:
    """Result from completing a run, including governance info."""

    run_id: str
    duration: float | None = None
    governance_action: str = "allow"
    governance_reason: str = ""
    retry_feedback: str = ""
    max_retries: int = 0

    @property
    def should_retry(self) -> bool:
        return self.governance_action == "retry"


@dataclass
class LlmCallInfo:
    """Information about an LLM API call."""

    model: str
    tokens_in: int
    tokens_out: int
    cost: float = 0.0
    task: str = ""
    prompt_preview: str = ""
    response_preview: str = ""


class CompiledPromptList(list):
    """Chat messages with a reference back to the source prompt version.

    A drop-in replacement for a plain ``list[dict]`` that carries the
    template's ``content_hash`` so instrumentors can auto-link LLM calls
    back to the prompt version in the registry.
    """

    _waxell_template_hash: str = ""


class CompiledPromptText(str):
    """Text prompt with a reference back to the source prompt version.

    Drop-in replacement for a plain ``str``. Instrumentors cannot
    introspect this through a messages list (OpenAI chat strips subclass
    info on dict values), so auto-linkage is best-effort for chat usage.
    """

    def __new__(cls, value: str, template_hash: str = ""):
        obj = super().__new__(cls, value)
        obj._waxell_template_hash = template_hash
        return obj


@dataclass
class PromptInfo:
    """A prompt version retrieved from the controlplane."""

    name: str
    version: int
    prompt_type: str  # "text" or "chat"
    content: object  # str for text, list[dict] for chat
    config: dict = field(default_factory=dict)
    labels: list = field(default_factory=list)
    content_hash: str = ""  # SHA-256 of content; links LLM calls to this version

    def compile(self, **variables: str) -> object:
        """Render the prompt with template variables.

        Replaces ``{{variable}}`` placeholders in the content.
        For text prompts, returns a ``CompiledPromptText`` (str subclass).
        For chat prompts, returns a ``CompiledPromptList`` (list subclass).
        Both carry the template's ``content_hash`` so instrumentors can
        auto-link the resulting LLM call back to this prompt version.
        """
        if isinstance(self.content, str):
            result = self.content
            for key, value in variables.items():
                result = result.replace("{{" + key + "}}", value)
            return CompiledPromptText(result, template_hash=self.content_hash)
        elif isinstance(self.content, list):
            messages = CompiledPromptList()
            messages._waxell_template_hash = self.content_hash
            for msg in self.content:
                rendered = dict(msg)
                if "content" in rendered and isinstance(rendered["content"], str):
                    for key, value in variables.items():
                        rendered["content"] = rendered["content"].replace(
                            "{{" + key + "}}", value
                        )
                messages.append(rendered)
            return messages
        return self.content


@dataclass
class ApprovalDecision:
    """Result from an ``on_policy_block`` handler.

    Tells the decorator whether to retry the function (``approved=True``)
    or propagate the :class:`PolicyViolationError` (``approved=False``).
    """

    approved: bool
    approver: str = ""
    timed_out: bool = False
    elapsed_seconds: float | None = None


@dataclass
class PromptGuardResult:
    """Result of a prompt guard check before an LLM call."""

    passed: bool
    action: str = "allow"  # "allow", "warn", "block", "redact"
    violations: list[str] = field(default_factory=list)
    source: str = "local"  # "local", "server", "both"
    redacted_messages: list | None = None  # Only set when action="redact"
