"""Shared JSON-RPC stdio plumbing for the integration MCP servers.

Used by:
- `waxell_observe.integrations.claude_code.mcp_server`
- `waxell_observe.integrations.cowork.mcp_server`

Both servers expose a small set of governance tools (policy-check, budget,
record-decision) over the MCP stdio protocol. The transport / dispatch loop
is identical; only the tool list and the per-tool handlers differ. This
module centralises the wire-format bits so the two integrations don't drift.

It is intentionally tiny — it does NOT try to be a general MCP framework.
It speaks just enough of the protocol (initialize, tools/list, tools/call,
notifications/initialized, ping) to satisfy Claude Code / Cowork.

C6 — keep-alive & bounded write timeout
---------------------------------------
Stdio MCP servers can hang on `stdout.write()` if the reader (Claude Code /
Cowork) stops draining its pipe — for example, after a crash or a
suspended-but-not-killed subprocess. To bound that risk we:

1. Wrap every write in a short `select`-based writability probe (default
   5s). On timeout, the message is dropped (logged at debug) — never
   raised. A dropped response is recoverable; a hung stdio thread is not.
2. Run a periodic `ping` notification (every 30s by default) on a
   background thread to detect a dead reader. Two consecutive write
   failures stop the server cleanly: stdin is closed, the dispatch loop
   exits, the warning is logged.
"""

from __future__ import annotations

import json
import logging
import select
import sys
import threading
from typing import Any, Callable

logger = logging.getLogger(__name__)

JSONRPC_VERSION = "2.0"

# A handler takes the raw `arguments` dict and returns a JSON-serializable
# result. It must NOT raise — if it does, the dispatcher catches and reports.
ToolHandler = Callable[[dict], dict]

# Default protocol revision we advertise. Matches Claude Code / Cowork today.
DEFAULT_PROTOCOL_VERSION = "2024-11-05"

# C6 — defaults for the keep-alive subsystem. Tunable via run_stdio_loop kwargs.
DEFAULT_WRITE_TIMEOUT_SECONDS = 5.0
DEFAULT_PING_INTERVAL_SECONDS = 30.0
DEFAULT_PING_FAILURE_THRESHOLD = 2  # consecutive failures before we give up


def make_initialize_response(
    req_id: Any,
    *,
    server_name: str,
    server_version: str,
    protocol_version: str = DEFAULT_PROTOCOL_VERSION,
) -> dict:
    """Build the JSON-RPC response for an MCP `initialize` request."""
    return {
        "jsonrpc": JSONRPC_VERSION,
        "id": req_id,
        "result": {
            "protocolVersion": protocol_version,
            "capabilities": {"tools": {}},
            "serverInfo": {"name": server_name, "version": server_version},
        },
    }


def make_tools_list_response(req_id: Any, tools: list[dict]) -> dict:
    """Wrap a list of tool descriptors in a `tools/list` JSON-RPC response."""
    return {
        "jsonrpc": JSONRPC_VERSION,
        "id": req_id,
        "result": {"tools": tools},
    }


def make_tool_call_response(req_id: Any, result: dict) -> dict:
    """Wrap a tool result in a `tools/call` JSON-RPC response.

    MCP wants tool results as a list of content parts. We always serialize
    the handler's dict to a single text part — both CC and Cowork callers
    re-parse it as JSON, so we keep it round-trippable.
    """
    return {
        "jsonrpc": JSONRPC_VERSION,
        "id": req_id,
        "result": {
            "content": [
                {"type": "text", "text": json.dumps(result, indent=2)},
            ],
        },
    }


def make_method_not_found_response(req_id: Any, method: str) -> dict:
    """JSON-RPC -32601 envelope for unknown methods."""
    return {
        "jsonrpc": JSONRPC_VERSION,
        "id": req_id,
        "error": {"code": -32601, "message": f"Method not found: {method}"},
    }


def make_unknown_tool_response(req_id: Any, tool_name: str) -> dict:
    """JSON-RPC -32602 envelope for unknown tool names inside `tools/call`."""
    return {
        "jsonrpc": JSONRPC_VERSION,
        "id": req_id,
        "error": {"code": -32602, "message": f"Unknown tool: {tool_name}"},
    }


def dispatch_tool_call(
    req_id: Any,
    params: dict,
    handlers: dict[str, ToolHandler],
) -> dict:
    """Look up `params['name']`, run its handler, wrap the result.

    Catches handler exceptions so a single buggy tool never kills the
    server — the model sees `{"error": "..."}` and decides what to do.
    """
    tool_name = params.get("name", "")
    arguments = params.get("arguments", {})

    handler = handlers.get(tool_name)
    if handler is None:
        return make_unknown_tool_response(req_id, tool_name)

    try:
        result = handler(arguments)
    except Exception as e:  # pragma: no cover - defensive
        result = {"error": str(e)}

    return make_tool_call_response(req_id, result)


# ---------------------------------------------------------------------------
# C6 — bounded-write + ping keep-alive
# ---------------------------------------------------------------------------


def _stdout_writable(stdout: Any, timeout: float) -> bool:
    """Return True if `stdout` accepts a write within `timeout` seconds.

    Falls back to True for stream objects without a real fileno (StringIO,
    pipes wrapped by tests) — those are always synchronous in-memory and
    do not need the select probe.
    """
    try:
        fileno = stdout.fileno()
    except (AttributeError, OSError, ValueError):
        return True
    try:
        _, ready, _ = select.select([], [fileno], [], timeout)
    except (OSError, ValueError) as e:
        logger.debug("select() on stdout failed: %s", e)
        return False
    return bool(ready)


def _safe_write(
    stdout: Any,
    payload: str,
    *,
    write_timeout: float,
) -> bool:
    """Write `payload` to `stdout` if it's writable within `write_timeout`.

    Returns True on success, False on timeout or write failure. Never
    raises — a dead reader is a fact, not an exception.
    """
    if not _stdout_writable(stdout, write_timeout):
        logger.debug(
            "stdout not writable within %.1fs — dropping message", write_timeout
        )
        return False
    try:
        stdout.write(payload)
        stdout.flush()
    except (BrokenPipeError, OSError, ValueError) as e:
        logger.debug("stdout write failed: %s", e)
        return False
    return True


class _KeepAlive:
    """Background ping thread that detects a dead reader.

    Sends `{"jsonrpc": "2.0", "method": "ping"}` every `interval` seconds.
    After `failure_threshold` consecutive failures (write timeout OR write
    error), `should_stop` flips True so the dispatch loop can exit.

    The thread is daemonic — if the loop exits first, the process tears
    down without waiting on us.
    """

    def __init__(
        self,
        stdout: Any,
        write_lock: threading.Lock,
        *,
        interval: float,
        write_timeout: float,
        failure_threshold: int,
    ) -> None:
        self._stdout = stdout
        self._write_lock = write_lock
        self._interval = interval
        self._write_timeout = write_timeout
        self._failure_threshold = failure_threshold
        self._stop_event = threading.Event()
        self._dead_event = threading.Event()
        self._thread: threading.Thread | None = None

    @property
    def should_stop(self) -> bool:
        """True when consecutive ping failures crossed the threshold."""
        return self._dead_event.is_set()

    def start(self) -> None:
        if self._interval <= 0:
            return  # disabled
        self._thread = threading.Thread(
            target=self._run, name="waxell-mcp-keepalive", daemon=True
        )
        self._thread.start()

    def stop(self) -> None:
        self._stop_event.set()

    def _run(self) -> None:
        consecutive_failures = 0
        ping_payload = json.dumps({"jsonrpc": JSONRPC_VERSION, "method": "ping"}) + "\n"

        while not self._stop_event.wait(self._interval):
            with self._write_lock:
                ok = _safe_write(
                    self._stdout, ping_payload, write_timeout=self._write_timeout
                )

            if ok:
                consecutive_failures = 0
                continue

            consecutive_failures += 1
            if consecutive_failures >= self._failure_threshold:
                logger.warning(
                    "MCP keep-alive: %d consecutive ping failures — reader appears dead, stopping server",
                    consecutive_failures,
                )
                self._dead_event.set()
                return


def run_stdio_loop(
    *,
    server_name: str,
    server_version: str,
    tools: list[dict],
    handlers: dict[str, ToolHandler],
    stdin=None,
    stdout=None,
    write_timeout: float = DEFAULT_WRITE_TIMEOUT_SECONDS,
    ping_interval: float = DEFAULT_PING_INTERVAL_SECONDS,
    ping_failure_threshold: int = DEFAULT_PING_FAILURE_THRESHOLD,
) -> None:
    """Run the JSON-RPC stdio loop until stdin closes or the reader dies.

    Reads one line of JSON per request, writes one line of JSON per
    response. Notifications (no `id`) get no response. `stdin`/`stdout`
    are injectable so tests can drive the loop with StringIO.

    Keep-alive (C6):
    - Every write goes through `_safe_write`, which uses `select` to
      bound the time spent waiting for stdout. Dropped writes are logged
      at debug, never raised.
    - A background thread pings the reader every `ping_interval` seconds.
      `ping_failure_threshold` consecutive failures stop the server
      cleanly (the next stdin read will see the close, or the reader-dead
      flag short-circuits the dispatch loop).

    Pass `ping_interval=0` to disable the keep-alive thread (useful in
    short-lived tests). The default 30s matches the spec.
    """
    stdin = stdin if stdin is not None else sys.stdin
    stdout = stdout if stdout is not None else sys.stdout

    write_lock = threading.Lock()
    keepalive = _KeepAlive(
        stdout,
        write_lock,
        interval=ping_interval,
        write_timeout=write_timeout,
        failure_threshold=ping_failure_threshold,
    )
    keepalive.start()

    try:
        for line in stdin:
            if keepalive.should_stop:
                # Reader is gone — don't bother dispatching any further.
                break

            line = line.strip()
            if not line:
                continue

            try:
                request = json.loads(line)
            except json.JSONDecodeError:
                continue

            method = request.get("method", "")
            req_id = request.get("id")

            response: dict | None
            if method == "initialize":
                response = make_initialize_response(
                    req_id,
                    server_name=server_name,
                    server_version=server_version,
                )
            elif method == "tools/list":
                response = make_tools_list_response(req_id, tools)
            elif method == "tools/call":
                response = dispatch_tool_call(
                    req_id, request.get("params", {}), handlers
                )
            elif method == "notifications/initialized":
                # Pure notification — no response.
                continue
            elif method == "ping":
                response = {"jsonrpc": JSONRPC_VERSION, "id": req_id, "result": {}}
            else:
                response = make_method_not_found_response(req_id, method)

            if response is not None:
                with write_lock:
                    _safe_write(
                        stdout,
                        json.dumps(response) + "\n",
                        write_timeout=write_timeout,
                    )
    finally:
        keepalive.stop()
