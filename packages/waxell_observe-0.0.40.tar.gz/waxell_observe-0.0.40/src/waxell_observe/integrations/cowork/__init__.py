"""Claude Cowork observability — tails Anthropic's audit.jsonl files and ships
events to Waxell observe as runs attributed to a Connect agent.

Cowork runs Claude Code inside a sandboxed VM; local hooks aren't reachable.
Anthropic writes a signed audit log (`audit.jsonl`) to the host filesystem for
every Cowork session — that's our observability hook.

Also exposes the Cowork MCP shim (E7 in `EXTERNAL_AGENT_GOVERNANCE.md`) — a
stdio MCP server the Cowork model can call proactively to self-check before
non-read actions.
"""

import json
from pathlib import Path
from typing import Optional

from .audit_parser import parse_audit_event
from .audit_watcher import watch_audit_logs


# Profile this integration writes its MCP config under. Cowork runs inside
# Claude (Desktop), which honors the same `~/.claude/.mcp.json` file Claude
# Code does — so the registration target is the same path Claude Code uses,
# but with a Cowork-specific server entry name so the two don't collide.
DEFAULT_COWORK_PROFILE = "claude-cowork"


def _mcp_server_name(profile: str) -> str:
    """Server entry name in `.mcp.json` (unique per profile)."""
    return f"waxell-observe-{profile}"


def register_mcp_config(
    path: Optional[Path] = None,
    *,
    profile: str = DEFAULT_COWORK_PROFILE,
) -> Path:
    """Write a Waxell-Cowork MCP server entry into `.mcp.json`.

    Idempotent and merge-safe — preserves existing `mcpServers` entries and
    every other top-level key in the config. Mirrors the Claude Code helper
    at `claude_code.setup._merge_mcp_config`, but registers the Cowork
    `mcp-server` subcommand instead.

    Args:
        path: Override config file location. Defaults to
            `~/.claude/.mcp.json` (Cowork shares Claude Desktop's MCP file).
        profile: The `~/.waxell/config` profile to read auth from. The
            registered command becomes
            `wax --profile {profile} cowork mcp-server`.

    Returns:
        The path that was written.
    """
    target = Path(path).expanduser() if path else Path.home() / ".claude" / ".mcp.json"
    target.parent.mkdir(parents=True, exist_ok=True)

    existing: dict = {}
    if target.exists():
        try:
            existing = json.loads(target.read_text())
        except (json.JSONDecodeError, OSError):
            existing = {}

    servers = existing.get("mcpServers", {}) or {}
    servers[_mcp_server_name(profile)] = {
        "type": "stdio",
        "command": "wax",
        "args": ["--profile", profile, "cowork", "mcp-server"],
    }
    existing["mcpServers"] = servers

    target.write_text(json.dumps(existing, indent=2) + "\n")
    return target


def unregister_mcp_config(
    path: Optional[Path] = None,
    *,
    profile: str = DEFAULT_COWORK_PROFILE,
) -> bool:
    """Remove the Waxell-Cowork MCP server entry from `.mcp.json`.

    Returns True if an entry was removed, False if nothing matched.
    """
    target = Path(path).expanduser() if path else Path.home() / ".claude" / ".mcp.json"
    if not target.exists():
        return False
    try:
        cfg = json.loads(target.read_text())
    except (json.JSONDecodeError, OSError):
        return False

    servers = cfg.get("mcpServers", {}) or {}
    name = _mcp_server_name(profile)
    if name not in servers:
        return False

    del servers[name]
    cfg["mcpServers"] = servers
    target.write_text(json.dumps(cfg, indent=2) + "\n")
    return True


__all__ = [
    "DEFAULT_COWORK_PROFILE",
    "parse_audit_event",
    "register_mcp_config",
    "unregister_mcp_config",
    "watch_audit_logs",
]
