"""MCP server for Claude Cowork governance integration.

Cowork runs Claude Code inside a sandboxed VM with no PreToolUse hooks
(see `agentforge/areas/connect/plans/EXTERNAL_AGENT_GOVERNANCE.md` E7).
The only realistic way to bring preventive-style enforcement to Cowork
is to register an MCP server that exposes governance tools the Cowork
model can call proactively ("self-check before action"). It is detective
by nature — the model can ignore it — but it raises the ceiling on
shaping/playbook-driven governance.

Mirrors the Claude Code shim at
`waxell_observe.integrations.claude_code.mcp_server`. Three tools:

1. `waxell_check_policy(action_kind, action_summary)` — pre-action gate
2. `waxell_budget_status()` — daily token/cost snapshot for the agent
3. `waxell_record_decision(reasoning, decision, confidence)` — audit span

All API calls stamp `agent_name="claude-cowork"` so server-side policies
scoped via `Policy.scope_agent_types: ["claude-cowork"]` match. Auth uses
the same `WaxellObserveClient` config + `X-Wax-Key` flow as the rest of
the SDK; pass `--profile claude-cowork` to wax to pick up the right key.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Any, Optional

from ...client import WaxellObserveClient
from .._mcp_shared import run_stdio_loop

logger = logging.getLogger(__name__)

# The agent_name we stamp on every API call. This is what the controlplane
# matches against `Policy.scope_agent_types` (E6 in the External Agent
# Governance plan). The Cowork MCP shim ALWAYS speaks as claude-cowork
# regardless of which agent_slug the user has configured locally — the
# slug is per-agent attribution; agent_type is per-tool-class governance.
COWORK_AGENT_NAME = "claude-cowork"
COWORK_AGENT_TYPE = "claude-cowork"

# Server identity returned in MCP `initialize` responses.
SERVER_NAME = "waxell-observe-cowork"

try:
    from ...__about__ import __version__ as SERVER_VERSION  # noqa: F401
except ImportError:
    SERVER_VERSION = "0.0.0"


# ---------------------------------------------------------------------------
# Tool descriptors (MCP `tools/list` payload)
# ---------------------------------------------------------------------------

TOOLS: list[dict] = [
    {
        "name": "waxell_check_policy",
        "description": (
            "Check if an action is allowed by Waxell governance policies BEFORE "
            "performing it. Cowork cannot be blocked by hooks (sandboxed VM), so "
            "this self-check is the strongest preventive surface available. Call "
            "before any non-read action: shell commands, file edits, network calls, "
            "delegation, or sending messages on behalf of the user."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "action_kind": {
                    "type": "string",
                    "description": (
                        "Short action category (e.g. 'shell', 'file_edit', "
                        "'network', 'connect_send_message', 'delegate')"
                    ),
                },
                "action_summary": {
                    "type": "string",
                    "description": "One-line human-readable description of what you're about to do",
                },
            },
            "required": ["action_kind"],
        },
    },
    {
        "name": "waxell_budget_status",
        "description": (
            "Snapshot of today's token + cost usage for this Cowork agent's tenant. "
            "Use to self-throttle expensive plans. Returns tokens_used_today, "
            "tokens_limit, cost_used_today, cost_limit, percent_used."
        ),
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "waxell_record_decision",
        "description": (
            "Record an important decision or reasoning step on the Cowork audit "
            "trail. Use when picking between approaches, justifying a risky action, "
            "or noting an architectural choice. Becomes a behavior span on the "
            "current daily run."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "reasoning": {
                    "type": "string",
                    "description": "Why you decided this way",
                },
                "decision": {
                    "type": "string",
                    "description": "The decision itself (the chosen path / answer)",
                },
                "confidence": {
                    "type": "number",
                    "description": "Optional 0.0-1.0 self-rated confidence",
                    "default": 0.0,
                },
            },
            "required": ["reasoning", "decision"],
        },
    },
]


# ---------------------------------------------------------------------------
# Daily-run lookup (used by budget + decision tools)
# ---------------------------------------------------------------------------


def _resolve_agent_slug(client: WaxellObserveClient) -> str:
    """The agent_slug from the active profile, if any.

    Cowork installs always populate this via `wax cowork init`, but we
    never assume — `record_decision` and `budget_status` degrade
    gracefully if it's missing.
    """
    return getattr(client.config, "agent_slug", "") or ""


def _ensure_daily_run(
    client: WaxellObserveClient,
) -> tuple[Optional[str], Optional[str]]:
    """Get-or-create today's Cowork daily session run.

    Returns (run_id, date) or (None, None) if no agent_slug is configured
    (which means we can't attribute a run). Failures are swallowed and
    logged — the model should still get a usable response.
    """
    slug = _resolve_agent_slug(client)
    if not slug:
        return None, None
    try:
        info = client.start_daily_run_sync(
            agent_slug=slug,
            agent_type=COWORK_AGENT_TYPE,
        )
    except Exception:
        logger.exception("Failed to fetch daily run for cowork mcp tools")
        return None, None
    return (info.run_id or None), (info.date or None)


# ---------------------------------------------------------------------------
# Tool handlers
# ---------------------------------------------------------------------------


def _tool_check_policy(args: dict) -> dict:
    """Ask the controlplane whether an action is allowed.

    Always stamps `agent_name="claude-cowork"` so policies scoped to
    Cowork (via `scope_agent_types: ["claude-cowork"]`) match. The
    response shape mirrors the spec:
        {allowed: bool, reason: str, suggested_alternative: str}
    """
    action_kind = (args.get("action_kind") or "").strip()
    action_summary = (args.get("action_summary") or "").strip()

    if not action_kind:
        return {
            "allowed": True,
            "reason": "No action_kind provided — nothing to check",
            "suggested_alternative": "",
        }

    client = WaxellObserveClient()
    if not client.config.is_configured:
        # Fail-open with an obvious reason so users know to configure.
        return {
            "allowed": True,
            "reason": "Waxell not configured — allowing by default",
            "suggested_alternative": "",
        }

    workflow_name = f"mcp:{action_kind}"
    if action_summary:
        # Keep workflow_name short — it's matched against scope rules,
        # not displayed verbatim. Summary travels in inputs for context.
        workflow_name = f"mcp:{action_kind}"[:255]

    try:
        result = client.check_policy_sync(
            agent_name=COWORK_AGENT_NAME,
            workflow_name=workflow_name,
            inputs={
                "action_kind": action_kind,
                "action_summary": action_summary,
                "source": "cowork-mcp-shim",
            },
        )
    except Exception as e:
        logger.exception("policy-check failed")
        return {
            "allowed": True,
            "reason": f"Policy check failed: {e} — allowing by default",
            "suggested_alternative": "",
        }

    metadata = result.metadata or {}
    suggested = ""
    # The controlplane policy handlers may stash a remediation hint in
    # metadata under a few different keys depending on category. Try the
    # most common ones; fall through to empty string.
    for key in ("suggested_alternative", "remediation", "suggestion"):
        if metadata.get(key):
            suggested = str(metadata[key])
            break

    return {
        "allowed": result.action != "block",
        "action": result.action,
        "reason": result.reason or "No policy matched",
        "suggested_alternative": suggested,
    }


def _tool_budget_status(args: dict) -> dict:  # noqa: ARG001 — schema has no args
    """Today's token + cost usage for the calling tenant.

    The Cowork shim has no access to a server-side budget aggregation
    endpoint that accepts X-Wax-Key (the existing BudgetOverviewView
    requires session auth). So we surface what we DO know via the
    daily-run record: counters maintained per-tenant in the daily run.
    Limits come from the agent's `metadata.budget` if configured;
    otherwise we report 0 for limit and let the model interpret.
    """
    client = WaxellObserveClient()
    if not client.config.is_configured:
        return {
            "status": "unconfigured",
            "reason": "Waxell not configured",
            "tokens_used_today": 0,
            "tokens_limit": 0,
            "cost_used_today": 0.0,
            "cost_limit": 0.0,
            "percent_used": 0.0,
        }

    run_id, date = _ensure_daily_run(client)
    if not run_id:
        return {
            "status": "no_agent",
            "reason": "No agent_slug configured — set one via `wax cowork init`",
            "tokens_used_today": 0,
            "tokens_limit": 0,
            "cost_used_today": 0.0,
            "cost_limit": 0.0,
            "percent_used": 0.0,
        }

    return {
        "status": "ok",
        "run_id": run_id,
        "date": date or "",
        # The controlplane is the source of truth for per-tenant budgets.
        # Until the X-Wax-Key budget endpoint lands, the shim reports
        # zeros so the model knows "I have a daily run, but I don't have
        # quantitative budget data yet." This is honest behavior — we
        # don't fabricate limits the model would condition on.
        "tokens_used_today": 0,
        "tokens_limit": 0,
        "cost_used_today": 0.0,
        "cost_limit": 0.0,
        "percent_used": 0.0,
        "note": (
            "Quantitative budget surfacing is pending an X-Wax-Key budget "
            "endpoint. Use the controlplane UI for live numbers."
        ),
    }


def _tool_record_decision(args: dict) -> dict:
    """Persist the decision on the current Cowork daily run as a behavior span."""
    reasoning = (args.get("reasoning") or "").strip()
    decision = (args.get("decision") or "").strip()
    try:
        confidence = float(args.get("confidence", 0.0) or 0.0)
    except (TypeError, ValueError):
        confidence = 0.0

    if not reasoning or not decision:
        return {
            "recorded": False,
            "reason": "Both 'reasoning' and 'decision' are required",
        }

    client = WaxellObserveClient()
    if not client.config.is_configured:
        return {
            "recorded": False,
            "reason": "Waxell not configured",
        }

    run_id, _ = _ensure_daily_run(client)
    if not run_id:
        return {
            "recorded": False,
            "reason": "No active Cowork daily run (agent_slug missing or controlplane unreachable)",
        }

    now = datetime.now(timezone.utc).isoformat()
    try:
        client.record_spans_sync(
            run_id=run_id,
            spans=[
                {
                    "name": "cowork:decision",
                    "kind": "decision",
                    "status": "ok",
                    "start_time": now,
                    "end_time": now,
                    "attributes": {
                        "decision.reasoning": reasoning,
                        "decision.chosen": decision,
                        "decision.confidence": confidence,
                        "decision.source": "cowork-mcp-shim",
                        "agent_type": COWORK_AGENT_TYPE,
                    },
                    "input_data": json.dumps({"reasoning": reasoning}),
                    "output_data": json.dumps(
                        {"decision": decision, "confidence": confidence}
                    ),
                }
            ],
        )
    except Exception as e:
        logger.exception("Failed to record cowork decision span")
        return {"recorded": False, "reason": str(e)}

    return {
        "recorded": True,
        "run_id": run_id,
        "decision": decision,
        "confidence": confidence,
    }


# ---------------------------------------------------------------------------
# Public entrypoint
# ---------------------------------------------------------------------------


HANDLERS = {
    "waxell_check_policy": _tool_check_policy,
    "waxell_budget_status": _tool_budget_status,
    "waxell_record_decision": _tool_record_decision,
}


def run_mcp_server(stdin: Any = None, stdout: Any = None) -> None:
    """Run the Cowork MCP server (stdio transport).

    Blocks reading JSON-RPC frames from stdin until EOF. `stdin`/`stdout`
    are injectable so tests can drive the loop without spawning a
    subprocess.
    """
    run_stdio_loop(
        server_name=SERVER_NAME,
        server_version=SERVER_VERSION,
        tools=TOOLS,
        handlers=HANDLERS,
        stdin=stdin,
        stdout=stdout,
    )
