"""Cowork audit log watcher.

Polls `~/Library/Application Support/Claude/local-agent-mode-sessions/` for
new/modified `audit.jsonl` files. For each session it discovers, creates a
Waxell observe run attributed to the configured Connect agent, then streams
every audit event into that run as a step (plus LLM token usage).

Keeps a cursor at `~/.waxell/cowork-cursor.json` mapping `{session_path: offset}`
so restarts resume at the next unread byte. Each file also has an associated
`run_id` mapping so events on that file append to the correct existing run.

Design notes:
- Polling not inotify — zero external deps, works everywhere, cheap at scale
  (one stat per audit.jsonl every few seconds)
- Lines are parsed ONE AT A TIME; partial lines stay buffered until newline
- If a Waxell API call fails, the cursor does NOT advance — events retry on
  next poll. Duplicate posts are acceptable during transient errors.
- No HMAC verification yet — that's Phase 5. For now, trust local filesystem.
"""

from __future__ import annotations

import json
import logging
import os
import sys
import time
from pathlib import Path
from typing import Optional

from .audit_parser import CoworkEvent, parse_audit_event

logger = logging.getLogger(__name__)


def _default_cowork_root() -> Path:
    """Where Claude Desktop writes Cowork session audit logs, per-platform.

    macOS:   ~/Library/Application Support/Claude/local-agent-mode-sessions
    Windows: %APPDATA%/Claude/local-agent-mode-sessions
             (falls back to ~/AppData/Roaming/Claude/... if APPDATA unset)
    Linux:   ~/.config/Claude/local-agent-mode-sessions
             (Cowork is macOS/Windows-first today but this is the XDG location
             in case it lands on Linux)
    """
    sessions_dir = "local-agent-mode-sessions"
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "Claude" / sessions_dir
    if sys.platform == "win32":
        appdata = os.environ.get("APPDATA")
        if appdata:
            return Path(appdata) / "Claude" / sessions_dir
        return Path.home() / "AppData" / "Roaming" / "Claude" / sessions_dir
    # Linux and other Unix
    return Path.home() / ".config" / "Claude" / sessions_dir


# Cursor persistence (platform-agnostic — lives under ~/.waxell)
_CURSOR_PATH = Path.home() / ".waxell" / "cowork-cursor.json"


def watch_audit_logs(
    *,
    root: Optional[Path] = None,
    client=None,
    agent_slug: str = "",
    agent_type: str = "claude-cowork",
    poll_interval: float = 2.0,
    verbose: bool = False,
    cursor_path: Optional[Path] = None,
    from_start: bool = False,
) -> None:
    """Run the watcher loop. Blocks forever until interrupted.

    Args:
        root: Cowork session directory (defaults to ~/Library/Application Support/Claude/...)
        client: An already-configured WaxellObserveClient. If None, a new one is
            constructed from environment / profile config.
        agent_slug: Override the agent_slug attached to runs. If empty, uses
            whatever the client's config provides (typically from the profile).
        agent_type: Value for AgentExecutionRun.agent_name (default: claude-cowork)
        poll_interval: seconds between filesystem polls
        verbose: if True, log every processed event
        cursor_path: override cursor file location (default ~/.waxell/cowork-cursor.json)
    """
    from ...client import WaxellObserveClient

    if client is None:
        client = WaxellObserveClient()
    if not client.config.is_configured:
        raise RuntimeError(
            "Waxell observe client not configured. Set WAXELL_API_KEY/WAXELL_API_URL "
            "or ~/.waxell/config, and ensure the profile has agent_slug set."
        )

    effective_slug = agent_slug or getattr(client.config, "agent_slug", "") or ""
    if not effective_slug:
        logger.warning(
            "No agent_slug configured — runs will be created without Connect agent "
            "attribution. Set agent_slug in your profile."
        )

    root = root or _default_cowork_root()
    if not root.exists():
        logger.warning(
            "Cowork session root does not exist: %s (is Claude Cowork installed?)", root
        )

    cursor_path = cursor_path or _CURSOR_PATH
    state = _load_state(cursor_path)

    if verbose:
        logger.info("Watching Cowork audit logs under %s", root)
        logger.info("Cursor file: %s", cursor_path)
        logger.info("Agent slug: %s", effective_slug or "(none)")
        logger.info("Poll interval: %.1fs", poll_interval)

    # Seed cursor for existing files: skip to EOF unless --from-start is set.
    # Prevents flooding with events from already-closed historical sessions.
    if not from_start:
        _seed_cursor_to_eof(
            root=root, state=state, cursor_path=cursor_path, verbose=verbose
        )

    # Heartbeat: ping every 5 min so dead-watcher alerting works.
    _HEARTBEAT_INTERVAL = 300
    _last_heartbeat = 0.0

    try:
        while True:
            try:
                _poll_once(
                    root=root,
                    client=client,
                    agent_slug=effective_slug,
                    agent_type=agent_type,
                    state=state,
                    cursor_path=cursor_path,
                    verbose=verbose,
                )
            except Exception:
                logger.exception("Error during poll iteration")

            # Heartbeat ping — non-blocking, failures silently ignored.
            # Uses httpx directly (not the observe client) so it's self-contained.
            now = time.time()
            if effective_slug and now - _last_heartbeat >= _HEARTBEAT_INTERVAL:
                try:
                    import httpx as _httpx

                    _httpx.post(
                        f"{client.config.api_url}/api/v1/observe/agents/{effective_slug}/heartbeat/",
                        json={"source": "watcher", "machine_id": platform.node()},
                        headers={"X-Wax-Key": client.config.api_key},
                        timeout=10,
                    )
                    _last_heartbeat = now
                except Exception:
                    pass  # heartbeat failures must never crash the watcher

            time.sleep(poll_interval)
    except KeyboardInterrupt:
        logger.info("Watcher stopped")


def _seed_cursor_to_eof(
    *, root: Path, state: dict, cursor_path: Path, verbose: bool
) -> None:
    """For any audit file we haven't seen before, set cursor = EOF so we only
    process events that happen FROM NOW ON. Preserves existing cursors so
    restarts resume correctly."""
    audit_files = _find_audit_files(root)
    seeded = 0
    for f in audit_files:
        key = str(f)
        if key in state:
            continue
        try:
            size = f.stat().st_size
        except FileNotFoundError:
            continue
        state[key] = {
            "offset": size,
            "run_id": None,
            "workflow_id": None,
            "step_position": 0,
        }
        seeded += 1
    if seeded:
        logger.info(
            "Seeded cursor to EOF for %d existing audit files (tail-only mode)", seeded
        )
        _save_state(cursor_path, state)


# -----------------------------------------------------------------
# Internals
# -----------------------------------------------------------------


def _poll_once(
    *,
    root: Path,
    client,
    agent_slug: str,
    agent_type: str,
    state: dict,
    cursor_path: Path,
    verbose: bool,
) -> None:
    audit_files = _find_audit_files(root)
    if verbose:
        logger.debug("Found %d audit.jsonl files", len(audit_files))

    for audit_file in audit_files:
        key = str(audit_file)
        file_state = state.setdefault(
            key, {"offset": 0, "run_id": None, "workflow_id": None}
        )

        try:
            size = audit_file.stat().st_size
        except FileNotFoundError:
            continue

        offset = int(file_state.get("offset", 0) or 0)
        if size <= offset:
            continue  # nothing new

        try:
            with open(audit_file, "rb") as f:
                f.seek(offset)
                raw = f.read(size - offset)
        except Exception:
            logger.exception("Failed to read %s", audit_file)
            continue

        # Split on newlines but keep partial trailing line for next poll
        buffer = raw.decode("utf-8", errors="replace")
        lines, tail = _split_lines_keep_partial(buffer)
        new_offset = size - len(tail.encode("utf-8"))

        advanced_offset = offset
        for line in lines:
            if not line.strip():
                advanced_offset += len(line.encode("utf-8")) + 1
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                logger.warning("Skipping malformed line in %s", audit_file)
                advanced_offset += len(line.encode("utf-8")) + 1
                continue

            try:
                _process_line(
                    audit_file=audit_file,
                    file_state=file_state,
                    line_obj=obj,
                    client=client,
                    agent_slug=agent_slug,
                    agent_type=agent_type,
                    verbose=verbose,
                )
            except Exception:
                logger.exception(
                    "Failed to process event in %s; will retry next poll", audit_file
                )
                # Don't advance offset — retry this line on next poll
                break

            advanced_offset += len(line.encode("utf-8")) + 1

        file_state["offset"] = min(advanced_offset, new_offset)
        _save_state(cursor_path, state)


def _event_dedup_key(line_obj: dict, event: CoworkEvent) -> str:
    """Stable identifier for an audit event (for dedup on retry)."""
    # Prefer the explicit uuid/id fields Anthropic sets on most events
    uid = (
        line_obj.get("uuid")
        or line_obj.get("id")
        or event.payload.get("message_id")
        or event.payload.get("tool_use_id")
        or ""
    )
    # Include kind so multi-event lines (assistant text + tool_use) dedup separately
    return f"{uid}:{event.kind}:{event.payload.get('tool_use_id', '')}"


def _process_line(
    *,
    audit_file: Path,
    file_state: dict,
    line_obj: dict,
    client,
    agent_slug: str,
    agent_type: str,
    verbose: bool,
) -> None:
    events = parse_audit_event(line_obj)

    # Dedup window (keeps last N event keys per file; bounded memory)
    seen = file_state.setdefault("seen_keys", [])
    seen_set = set(seen)

    for event in events:
        dedup_key = _event_dedup_key(line_obj, event)
        if dedup_key and dedup_key in seen_set:
            if verbose:
                logger.debug("skip duplicate event key=%s", dedup_key[:40])
            continue

        if verbose:
            logger.info(
                "event kind=%s session=%s%s",
                event.kind,
                event.session_id[:8] if event.session_id else "(none)",
                f" payload_keys={list(event.payload.keys())}" if event.payload else "",
            )

        # Detect a stale daily run (cursor cached a run_id from a previous day).
        # Without this, events after midnight keep posting to yesterday's run
        # and never show up in today's dashboard.
        cached_date = file_state.get("daily_session_date")
        if cached_date and agent_slug:
            from datetime import datetime, timezone

            today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
            if cached_date != today:
                logger.info(
                    "daily run stale (cached=%s today=%s) — rolling over for %s",
                    cached_date,
                    today,
                    audit_file,
                )
                file_state["run_id"] = None
                file_state["workflow_id"] = None
                file_state["daily_session_date"] = None

        # First session_init for a file → start the run
        if event.kind == "session_init" and not file_state.get("run_id"):
            _ensure_run_started(
                event=event,
                file_state=file_state,
                client=client,
                agent_slug=agent_slug,
                agent_type=agent_type,
            )
            continue

        # If we haven't seen session_init yet (audit log from before we started),
        # lazily start the run on first event
        if not file_state.get("run_id"):
            _ensure_run_started(
                event=event,
                file_state=file_state,
                client=client,
                agent_slug=agent_slug,
                agent_type=agent_type,
                fallback=True,
            )

        run_id = file_state.get("run_id")
        if not run_id:
            logger.warning(
                "Could not establish run for %s — skipping event", audit_file
            )
            continue

        _append_event_to_run(
            event=event,
            run_id=run_id,
            client=client,
            file_state=file_state,
        )

        # Mark as processed only AFTER successful append (so retry still works
        # if the call failed partway through)
        if dedup_key:
            seen.append(dedup_key)
            seen_set.add(dedup_key)

    # Trim dedup window to last 10000 keys per file (keeps cursor file bounded)
    if len(seen) > 10000:
        file_state["seen_keys"] = seen[-5000:]


def _next_position(file_state: dict) -> int:
    """Monotonic step position counter per file."""
    pos = int(file_state.get("step_position", 0) or 0)
    file_state["step_position"] = pos + 1
    return pos


def _step_name_for_event(event: CoworkEvent) -> str:
    """Build a human-readable step_name from the event kind + payload."""
    p = event.payload
    if event.kind == "user_message":
        return "cowork:user_message"
    if event.kind == "assistant_text":
        return "cowork:assistant"
    if event.kind == "tool_use":
        name = p.get("tool_name") or "tool"
        return f"cowork:tool_use:{name}"
    if event.kind == "tool_result":
        return "cowork:tool_result"
    if event.kind == "tool_use_summary":
        name = p.get("tool_name") or "tool"
        return f"cowork:tool_summary:{name}"
    if event.kind == "session_init":
        return "cowork:session_init"
    if event.kind.startswith("permission:"):
        decision = p.get("decision") or "unknown"
        tool = p.get("tool_name") or "tool"
        return f"cowork:{event.kind}:{tool}:{decision}"
    if event.kind.startswith("result:"):
        return f"cowork:{event.kind}"
    if event.kind == "system_status":
        return "cowork:system_status"
    if event.kind == "compact_boundary":
        return "cowork:compact_boundary"
    if event.kind == "rate_limit":
        return "cowork:rate_limit"
    return f"cowork:{event.kind}"


def _ensure_run_started(
    *,
    event: CoworkEvent,
    file_state: dict,
    client,
    agent_slug: str,
    agent_type: str,
    fallback: bool = False,
) -> None:
    """Attach this audit file to the agent's daily session run.

    If the watcher's agent_slug is configured, we use the daily-run endpoint
    (events roll up across multiple Cowork sessions in the same day).
    Otherwise we fall back to a per-session run via start_run_sync.
    """
    if not agent_slug:
        # Legacy path: per-session run, no Connect attribution
        workflow_name = f"cowork:{event.session_id or 'unknown'}"
        metadata = {
            "source": "cowork-audit",
            "cowork_session_id": event.session_id,
        }
        if event.kind == "session_init":
            metadata["model"] = event.payload.get("model", "")
        try:
            run_info = client.start_run_sync(
                agent_name=agent_type,
                workflow_name=workflow_name,
                inputs={"source": "claude_cowork", "session_id": event.session_id},
                metadata=metadata,
                session_id=event.session_id,
            )
            file_state["run_id"] = run_info.run_id
            file_state["workflow_id"] = run_info.workflow_id
            logger.info(
                "started per-session cowork run run_id=%s session=%s",
                run_info.run_id,
                event.session_id,
            )
        except Exception:
            logger.exception("Failed to start run for session %s", event.session_id)
        return

    # Daily session path — preferred
    try:
        daily = client.start_daily_run_sync(
            agent_slug=agent_slug,
            agent_type=agent_type,
        )
        file_state["run_id"] = daily.run_id
        file_state["workflow_id"] = daily.workflow_id
        file_state["daily_session_date"] = daily.date
        logger.info(
            "attached cowork session=%s to daily run run_id=%s date=%s (%s)",
            event.session_id,
            daily.run_id,
            daily.date,
            "created" if daily.created else "existing",
        )
    except Exception:
        logger.exception(
            "Failed to get daily run for agent=%s; falling back to per-session",
            agent_slug,
        )
        # Fallback: per-session run
        try:
            run_info = client.start_run_sync(
                agent_name=agent_type,
                workflow_name=f"cowork:{event.session_id or 'unknown'}",
                inputs={"source": "claude_cowork", "session_id": event.session_id},
                metadata={
                    "source": "cowork-audit",
                    "cowork_session_id": event.session_id,
                },
                session_id=event.session_id,
                agent_slug=agent_slug or None,
            )
            file_state["run_id"] = run_info.run_id
            file_state["workflow_id"] = run_info.workflow_id
        except Exception:
            logger.exception(
                "Failed fallback start_run for session %s", event.session_id
            )


def _append_event_to_run(
    *,
    event: CoworkEvent,
    run_id: str,
    client,
    file_state: dict,
) -> None:
    """Append an audit event to the run as a step (+ llm_call if assistant)."""
    # Track latest user message for LLM prompt_preview correlation
    if event.kind == "user_message":
        file_state["_last_user_message"] = (event.payload.get("text") or "")[:2000]

    # Phase 1.5 / Task #8 — hardware_uuid stamps every emission so the
    # controlplane Device model can join cowork events to the same machine
    # as Claude Code hooks + observe SDK records. Cached per-process.
    from waxell_observe.platform import get_hardware_uuid

    step = {
        "step_name": _step_name_for_event(event),
        "position": _next_position(file_state),
        "output": {
            "kind": event.kind,
            "timestamp": event.timestamp,
            "source": "cowork-audit",
            "session_id": event.session_id,
            "hardware_uuid": get_hardware_uuid(),
            **event.payload,
        },
    }
    try:
        client.record_steps_sync(run_id=run_id, steps=[step])
    except Exception:
        logger.exception("Failed to record step for run %s", run_id)
        raise

    # Assistant events also emit an llm_call (with tokens + prompt/response text)
    if event.kind == "assistant":
        usage = event.payload.get("usage") or {}
        if usage.get("input_tokens") or usage.get("output_tokens"):
            call = {
                "model": event.payload.get("model") or "claude-cowork-unknown",
                "tokens_in": int(usage.get("input_tokens", 0) or 0),
                "tokens_out": int(usage.get("output_tokens", 0) or 0),
                "cost": 0.0,  # server-side cost resolution
                "task": "cowork",
                "prompt_preview": (file_state.get("_last_user_message") or "")[:2000],
                "response_preview": (event.payload.get("text") or "")[:2000],
            }
            try:
                client.record_llm_calls_sync(run_id=run_id, calls=[call])
            except Exception:
                logger.exception("Failed to record llm_call for run %s", run_id)
                raise

    # Session-ending result: only auto-complete per-session runs.
    # Daily runs stay open all day — they're closed by a daily roll-up job
    # (or simply by retention / explicit admin action), not per Cowork session.
    if event.kind.startswith("result:") and not file_state.get("run_completed"):
        is_daily = bool(file_state.get("daily_session_date"))
        if is_daily:
            logger.debug(
                "daily run — not auto-completing on result event (run_id=%s)", run_id
            )
        else:
            subtype = event.payload.get("subtype", "")
            result_status = "success" if subtype == "success" else "error"
            try:
                client.complete_run_sync(
                    run_id=run_id,
                    status=result_status,
                    result={
                        "cowork_result_subtype": subtype,
                        "duration_ms": event.payload.get("duration_ms"),
                        "num_turns": event.payload.get("num_turns"),
                        "total_cost_usd": event.payload.get("total_cost_usd"),
                    },
                )
                file_state["run_completed"] = True
                logger.info(
                    "completed per-session cowork run run_id=%s status=%s",
                    run_id,
                    result_status,
                )
            except Exception:
                logger.exception("Failed to complete run %s", run_id)


def _record_usage(*, event: CoworkEvent, run_id: str, client) -> None:
    p = event.payload
    call = {
        "model": p.get("model", "") or "claude-cowork-unknown",
        "tokens_in": int(p.get("input_tokens", 0) or 0),
        "tokens_out": int(p.get("output_tokens", 0) or 0),
        "cost": 0.0,  # Cost resolved server-side via SystemModelCost
        "task": "cowork",
    }
    try:
        client.record_llm_calls_sync(run_id=run_id, calls=[call])
    except Exception:
        logger.exception("Failed to record llm_call for run %s", run_id)
        raise


def _find_audit_files(root: Path) -> list[Path]:
    """Locate every audit.jsonl under the cowork session tree.

    Windows-safe: uses os.walk with explicit pruning of subtrees that don't
    contain audit logs (cowork_plugins/marketplaces has deeply-nested
    node_modules that hit Windows LongPath limits, and .claude.json.lock is
    a directory not a file on Windows). On macOS this is a tiny perf
    optimization; on Windows it prevents the watcher from crashing.
    """
    if not root.exists():
        return []

    # Subtree names anywhere in the tree that we never want to descend into.
    skip_dirs = {
        "cowork_plugins",  # marketplace clones with node_modules — LongPath risk
        ".claude.json.lock",  # Windows: directory used as POSIX-flock substitute
        "node_modules",
        ".git",
        "shim-lib",  # Cowork shim source — no audit files
        "shim-perm",  # Windows-only — no audit files
        "outputs",  # Cowork output staging — no audit files
        "uploads",  # Cowork upload staging — no audit files
        "skills-plugin",  # Global Claude skills cache — no audit files
        "debug",  # Cowork debug dumps — no audit files
    }

    results: list[Path] = []
    try:
        for dirpath, dirnames, filenames in os.walk(root):
            # Prune in-place so os.walk doesn't descend into them
            dirnames[:] = [d for d in dirnames if d not in skip_dirs]
            if "audit.jsonl" in filenames:
                p = Path(dirpath) / "audit.jsonl"
                # Defensive: only include actual files (handles odd FS state)
                try:
                    if p.is_file():
                        results.append(p)
                except OSError:
                    pass
    except (PermissionError, OSError):
        # Best-effort: don't crash the watcher on transient FS errors
        pass
    return results


def _split_lines_keep_partial(buf: str) -> tuple[list[str], str]:
    """Split buffer into complete lines (sans newline) + trailing partial.

    If buf ends with '\\n' the partial is empty.
    """
    if "\n" not in buf:
        return [], buf
    parts = buf.split("\n")
    return parts[:-1], parts[-1]


def _load_state(cursor_path: Path) -> dict:
    if not cursor_path.exists():
        return {}
    try:
        return json.loads(cursor_path.read_text())
    except Exception:
        logger.warning("Failed to load cursor %s — starting fresh", cursor_path)
        return {}


def _save_state(cursor_path: Path, state: dict) -> None:
    try:
        cursor_path.parent.mkdir(parents=True, exist_ok=True)
        tmp = cursor_path.with_suffix(cursor_path.suffix + ".tmp")
        tmp.write_text(json.dumps(state, indent=2))
        os.replace(tmp, cursor_path)
    except Exception:
        logger.exception("Failed to persist cursor to %s", cursor_path)
