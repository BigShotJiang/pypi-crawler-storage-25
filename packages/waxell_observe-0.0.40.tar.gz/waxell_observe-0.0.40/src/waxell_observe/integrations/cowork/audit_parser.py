"""Pure parser: maps Anthropic Cowork audit.jsonl lines to Waxell observe events.

Kept side-effect-free so it's testable in isolation. The watcher consumes the
structured events this produces and invokes the observe client.

Audit line shapes (from observed Cowork sessions):

  Session bootstrap:
    {"type":"system","subtype":"init","cwd":"/sessions/...","session_id":"...",
     "tools":[...],"model":"...","_audit_timestamp":"...","_audit_hmac":"..."}

  User prompt:
    {"type":"user","uuid":"...","session_id":"...","parent_tool_use_id":null,
     "message":{"role":"user","content":"<text>"},"_audit_timestamp":"..."}

  Assistant message (text or tool_use blocks):
    {"type":"assistant","message":{"model":"claude-opus-4-6","id":"msg_...",
     "type":"message","role":"assistant",
     "content":[{"type":"text","text":"..."} | {"type":"tool_use","name":"...","input":{...}}],
     "usage":{"input_tokens":N,"output_tokens":N,...}},"_audit_timestamp":"..."}

  Tool result:
    {"type":"user","message":{"role":"user","content":[{"type":"tool_result",...}]}}
    (yes — tool results come back as 'user' type with tool_result content blocks)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional


@dataclass
class CoworkEvent:
    """Normalized event derived from one audit.jsonl line."""

    kind: str
    """'session_init' | 'user_message' | 'assistant_text' | 'tool_use' |
    'tool_result' | 'usage' | 'unknown'"""

    session_id: str
    timestamp: str
    raw: dict
    payload: dict = field(default_factory=dict)


def parse_audit_event(line_obj: dict) -> list[CoworkEvent]:
    """Parse one audit.jsonl record. Returns zero or more normalized events.

    Some audit lines carry multiple logical events (e.g. an assistant message
    with text + tool_use blocks + usage). Each becomes a separate CoworkEvent.
    """
    events: list[CoworkEvent] = []
    ts = line_obj.get("_audit_timestamp") or _iso_now()
    session_id = line_obj.get("session_id") or _inner_session_id(line_obj) or ""

    t = line_obj.get("type")
    subtype = line_obj.get("subtype")

    # ---------- system events ----------
    if t == "system":
        if subtype == "init":
            events.append(
                CoworkEvent(
                    kind="session_init",
                    session_id=session_id,
                    timestamp=ts,
                    raw=line_obj,
                    payload={
                        "cwd": line_obj.get("cwd", ""),
                        "model": line_obj.get("model", ""),
                        "tools": line_obj.get("tools", []),
                        "inner_session_id": line_obj.get("session_id", ""),
                    },
                )
            )
            return events

        # Governance-relevant: user granting/denying tool permissions
        if subtype in (
            "permission_request",
            "permission_response",
            "permission_auto_approved",
        ):
            events.append(
                CoworkEvent(
                    kind=f"permission:{subtype.replace('permission_', '')}",
                    session_id=session_id,
                    timestamp=ts,
                    raw=line_obj,
                    payload={
                        "tool_name": line_obj.get("tool_name", ""),
                        "tool_input": line_obj.get("tool_input", {}),
                        "decision": line_obj.get("decision", ""),
                        "reason": line_obj.get("reason", ""),
                        "auto_approved": subtype == "permission_auto_approved",
                    },
                )
            )
            return events

        if subtype == "status":
            events.append(
                CoworkEvent(
                    kind="system_status",
                    session_id=session_id,
                    timestamp=ts,
                    raw=line_obj,
                    payload={
                        "status": line_obj.get("status", ""),
                        "message": line_obj.get("message", ""),
                    },
                )
            )
            return events

        if subtype == "compact_boundary":
            events.append(
                CoworkEvent(
                    kind="compact_boundary",
                    session_id=session_id,
                    timestamp=ts,
                    raw=line_obj,
                    payload={
                        "compact_type": line_obj.get("compact_type", ""),
                        "pre_tokens": line_obj.get("pre_tokens"),
                        "post_tokens": line_obj.get("post_tokens"),
                    },
                )
            )
            return events

    # ---------- session result (end-of-session summary) ----------
    if t == "result":
        events.append(
            CoworkEvent(
                kind=f"result:{subtype or 'unknown'}",
                session_id=session_id,
                timestamp=ts,
                raw=line_obj,
                payload={
                    "subtype": subtype,
                    "duration_ms": line_obj.get("duration_ms"),
                    "num_turns": line_obj.get("num_turns"),
                    "total_cost_usd": line_obj.get("total_cost_usd"),
                    "summary": line_obj.get("summary", ""),
                },
            )
        )
        return events

    # ---------- tool_use_summary (aggregated tool call view) ----------
    if t == "tool_use_summary":
        events.append(
            CoworkEvent(
                kind="tool_use_summary",
                session_id=session_id,
                timestamp=ts,
                raw=line_obj,
                payload={
                    "tool_name": line_obj.get("tool_name", ""),
                    "tool_use_id": line_obj.get("tool_use_id", ""),
                    "is_error": bool(line_obj.get("is_error")),
                    "summary": line_obj.get("summary", ""),
                },
            )
        )
        return events

    # ---------- rate limit event ----------
    if t == "rate_limit_event":
        events.append(
            CoworkEvent(
                kind="rate_limit",
                session_id=session_id,
                timestamp=ts,
                raw=line_obj,
                payload={
                    "resets_at": line_obj.get("resets_at"),
                    "tokens_remaining": line_obj.get("tokens_remaining"),
                    "tokens_used": line_obj.get("tokens_used"),
                    "status": line_obj.get("status", ""),
                },
            )
        )
        return events

    if t == "user":
        msg = line_obj.get("message", {}) or {}
        content = msg.get("content")
        # User text prompt
        if isinstance(content, str) and content:
            events.append(
                CoworkEvent(
                    kind="user_message",
                    session_id=session_id,
                    timestamp=ts,
                    raw=line_obj,
                    payload={"text": content},
                )
            )
        # Tool results come back as user messages with tool_result blocks
        elif isinstance(content, list):
            for block in content:
                if isinstance(block, dict) and block.get("type") == "tool_result":
                    events.append(
                        CoworkEvent(
                            kind="tool_result",
                            session_id=session_id,
                            timestamp=ts,
                            raw=line_obj,
                            payload={
                                "tool_use_id": block.get("tool_use_id", ""),
                                "is_error": bool(block.get("is_error")),
                                "content": _summarize_content(block.get("content")),
                            },
                        )
                    )
        return events

    if t == "assistant":
        msg = line_obj.get("message", {}) or {}
        model = msg.get("model", "")
        content_blocks = msg.get("content", []) or []
        usage = msg.get("usage") or {}
        msg_id = msg.get("id", "")  # unique per assistant message — dedup key

        # Collect text + tool_uses in one pass so we keep them associated
        text_parts = []
        tool_uses = []
        for block in content_blocks:
            if not isinstance(block, dict):
                continue
            btype = block.get("type")
            if btype == "text":
                text_parts.append(block.get("text", ""))
            elif btype == "tool_use":
                tool_uses.append(
                    {
                        "tool_use_id": block.get("id", ""),
                        "tool_name": block.get("name", ""),
                        "tool_input": block.get("input", {}),
                    }
                )

        response_text = "\n".join([t for t in text_parts if t])

        # Emit a single assistant event carrying text + tool_uses + usage
        events.append(
            CoworkEvent(
                kind="assistant",
                session_id=session_id,
                timestamp=ts,
                raw=line_obj,
                payload={
                    "message_id": msg_id,
                    "model": model,
                    "text": response_text,
                    "tool_uses": tool_uses,
                    "usage": {
                        "input_tokens": int(usage.get("input_tokens", 0) or 0),
                        "output_tokens": int(usage.get("output_tokens", 0) or 0),
                        "cache_creation_input_tokens": int(
                            usage.get("cache_creation_input_tokens", 0) or 0
                        ),
                        "cache_read_input_tokens": int(
                            usage.get("cache_read_input_tokens", 0) or 0
                        ),
                    }
                    if usage
                    else {},
                },
            )
        )

        # Emit a span for each tool_use so they show up as individual spans
        for tu in tool_uses:
            events.append(
                CoworkEvent(
                    kind="tool_use",
                    session_id=session_id,
                    timestamp=ts,
                    raw=line_obj,
                    payload={**tu, "model": model, "message_id": msg_id},
                )
            )

        return events

    # Unknown shape — surface as-is for visibility but don't fail
    events.append(
        CoworkEvent(
            kind="unknown",
            session_id=session_id,
            timestamp=ts,
            raw=line_obj,
            payload={"type": t, "subtype": subtype},
        )
    )
    return events


def _inner_session_id(obj: dict) -> Optional[str]:
    """Some events embed session_id deep in nested structures."""
    msg = obj.get("message") or {}
    if isinstance(msg, dict):
        sid = msg.get("session_id") or msg.get("id")
        if isinstance(sid, str):
            return sid
    return None


def _summarize_content(content: Any, max_len: int = 500) -> str:
    if content is None:
        return ""
    if isinstance(content, str):
        return content[:max_len]
    if isinstance(content, list):
        parts = []
        for b in content:
            if isinstance(b, dict):
                txt = b.get("text") or b.get("content") or ""
                if isinstance(txt, str):
                    parts.append(txt)
        joined = "\n".join(parts)
        return joined[:max_len]
    return str(content)[:max_len]


def _iso_now() -> str:
    return datetime.now(timezone.utc).isoformat()
