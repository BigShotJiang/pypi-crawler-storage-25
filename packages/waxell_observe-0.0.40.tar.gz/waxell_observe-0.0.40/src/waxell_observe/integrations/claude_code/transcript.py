"""JSONL transcript parser for Claude Code sessions.

Extracts LLM call records and session summaries from Claude Code's
transcript files (path provided in hook payloads as `transcript_path`).
"""

import json
import logging
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)

# Model costs (USD per 1M tokens) — kept in sync with observe_views.py SYSTEM_MODEL_COSTS
MODEL_COSTS = {
    "claude-opus-4-6": {"input": 15.0, "output": 75.0},
    "claude-sonnet-4-5-20250929": {"input": 3.0, "output": 15.0},
    "claude-haiku-4-5-20251001": {"input": 0.80, "output": 4.0},
    # Fallback aliases
    "claude-opus-4-6-20250924": {"input": 15.0, "output": 75.0},
    "opus": {"input": 15.0, "output": 75.0},
    "sonnet": {"input": 3.0, "output": 15.0},
    "haiku": {"input": 0.80, "output": 4.0},
}

DEFAULT_COST = {"input": 3.0, "output": 15.0}  # Default to Sonnet pricing


@dataclass
class LlmCallData:
    """A single LLM call extracted from the transcript."""

    model: str = ""
    tokens_in: int = 0
    tokens_out: int = 0
    cache_read_tokens: int = 0
    cache_creation_tokens: int = 0
    cost: float = 0.0
    task: str = "claude_code_turn"
    # Stable identifier from the transcript entry (uuid + message.id) so
    # Stop/SessionEnd handlers can dedupe across repeat fires in one session.
    message_id: str = ""
    prompt_preview: str = ""
    response_preview: str = ""
    timestamp: str = ""


@dataclass
class TranscriptSummary:
    """Summary of a Claude Code session transcript."""

    llm_calls: list[LlmCallData] = field(default_factory=list)
    total_tokens_in: int = 0
    total_tokens_out: int = 0
    total_cost: float = 0.0
    total_turns: int = 0
    models_used: list[str] = field(default_factory=list)
    tool_uses: int = 0


def _estimate_cost(model: str, tokens_in: int, tokens_out: int) -> float:
    """Estimate cost for a single LLM call."""
    costs = MODEL_COSTS.get(model, DEFAULT_COST)
    return (tokens_in * costs["input"] + tokens_out * costs["output"]) / 1_000_000


def _truncate(text: str, limit: int) -> str:
    if not text:
        return ""
    if len(text) <= limit:
        return text
    return text[: limit - 1] + "…"


def _extract_message_text(msg: dict) -> str:
    """Pull a human-readable text preview from a Claude Code transcript message.

    Handles three shapes: plain string content, list-of-blocks
    (text/tool_use/tool_result), or missing content.
    """
    if not isinstance(msg, dict):
        return ""
    content = msg.get("content")
    if isinstance(content, str):
        return content.strip()
    if not isinstance(content, list):
        return ""
    parts: list[str] = []
    for block in content:
        if not isinstance(block, dict):
            continue
        btype = block.get("type")
        if btype == "text":
            t = block.get("text", "")
            if isinstance(t, str) and t.strip():
                parts.append(t.strip())
        elif btype == "tool_use":
            name = block.get("name", "tool")
            parts.append(f"[tool_use:{name}]")
        elif btype == "tool_result":
            inner = block.get("content", "")
            if isinstance(inner, str):
                snippet = inner.strip()[:400]
                if snippet:
                    parts.append(f"[tool_result] {snippet}")
            elif isinstance(inner, list):
                for sub in inner:
                    if isinstance(sub, dict) and sub.get("type") == "text":
                        s = sub.get("text", "")
                        if isinstance(s, str) and s.strip():
                            parts.append(f"[tool_result] {s.strip()[:400]}")
                            break
    return "\n".join(parts).strip()


def parse_transcript(path: str, start_offset: int = 0) -> TranscriptSummary:
    """Parse a Claude Code JSONL transcript into structured telemetry data.

    Args:
        path: Absolute path to the JSONL transcript file.
        start_offset: Byte offset to start reading from. Pass the value from
            a previous call's file size to only parse NEW lines (incremental).
            Default 0 reads the full file.

    Returns:
        TranscriptSummary with LLM calls, token totals, and cost.
    """
    transcript_path = Path(path)
    if not transcript_path.exists():
        logger.warning("Transcript file not found: %s", path)
        return TranscriptSummary()

    llm_calls: list[LlmCallData] = []
    models_seen: set[str] = set()
    tool_uses = 0
    last_user_text: str = ""

    try:
        with open(transcript_path, "r", encoding="utf-8", errors="replace") as fh:
            if start_offset > 0:
                fh.seek(start_offset)
                partial = fh.readline()
                if partial and not partial.endswith("\n"):
                    pass
            content = fh.read()
        for line in content.splitlines():
            if not line.strip():
                continue
            try:
                entry = json.loads(line)
            except json.JSONDecodeError:
                continue

            entry_type = entry.get("type", "")

            if entry_type == "user":
                last_user_text = (
                    _extract_message_text(entry.get("message", {}) or {})
                    or last_user_text
                )

            # Extract LLM calls from assistant turns with model metadata
            if entry_type == "assistant":
                meta = entry.get("modelMetadata") or entry.get("usage") or {}
                if not meta:
                    # Try nested in message
                    msg = entry.get("message", {})
                    meta = msg.get("usage", {})

                model = (
                    meta.get("model", "")
                    or entry.get("model", "")
                    or entry.get("message", {}).get("model", "")
                )
                tokens_in = int(
                    meta.get("inputTokens", 0) or meta.get("input_tokens", 0) or 0
                )
                tokens_out = int(
                    meta.get("outputTokens", 0) or meta.get("output_tokens", 0) or 0
                )
                cache_read = int(
                    meta.get("cacheReadInputTokens", 0)
                    or meta.get("cache_read_input_tokens", 0)
                    or 0
                )
                cache_create = int(
                    meta.get("cacheCreationInputTokens", 0)
                    or meta.get("cache_creation_input_tokens", 0)
                    or 0
                )

                if model or tokens_in or tokens_out:
                    cost = _estimate_cost(model, tokens_in, tokens_out)
                    # Prefer the assistant message.id (stable across reparses)
                    # over the outer entry uuid; fall back to the outer uuid.
                    msg_obj = entry.get("message", {}) or {}
                    msg_id = msg_obj.get("id") or entry.get("uuid") or ""
                    response_text = _extract_message_text(msg_obj)
                    llm_calls.append(
                        LlmCallData(
                            model=model,
                            tokens_in=tokens_in,
                            tokens_out=tokens_out,
                            cache_read_tokens=cache_read,
                            cache_creation_tokens=cache_create,
                            cost=cost,
                            message_id=str(msg_id),
                            prompt_preview=_truncate(last_user_text, 2000),
                            response_preview=_truncate(response_text, 2000),
                            timestamp=str(entry.get("timestamp", "") or ""),
                        )
                    )
                    if model:
                        models_seen.add(model)

            # Count tool uses
            elif entry_type == "tool_use" or entry_type == "tool":
                tool_uses += 1

    except Exception as e:
        logger.warning("Error parsing transcript %s: %s", path, e)
        return TranscriptSummary()

    total_in = sum(c.tokens_in for c in llm_calls)
    total_out = sum(c.tokens_out for c in llm_calls)
    total_cost = sum(c.cost for c in llm_calls)

    return TranscriptSummary(
        llm_calls=llm_calls,
        total_tokens_in=total_in,
        total_tokens_out=total_out,
        total_cost=total_cost,
        total_turns=len(llm_calls),
        models_used=sorted(models_seen),
        tool_uses=tool_uses,
    )
