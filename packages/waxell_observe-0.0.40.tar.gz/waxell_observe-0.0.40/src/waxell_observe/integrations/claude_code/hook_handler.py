"""Claude Code hook handler — reads JSON from stdin, dispatches to observe API.

This is the entry point called by Claude Code for all hook events.
It routes to the appropriate handler based on hook_event_name.

Usage (called by Claude Code hooks):
    echo '{"hook_event_name": "SessionStart", ...}' | wax observe claude-code hook
"""

import json
import logging
import os
import sys
from datetime import datetime, timezone

from ...client import WaxellObserveClient
from .state import (
    SessionState,
    cleanup_stale_states,
    delete_state,
    find_cowork_peer,
    load_state,
    save_state,
)
from .transcript import parse_transcript

logger = logging.getLogger(__name__)


def handle_hook() -> None:
    """Main entry point — read hook JSON from stdin, dispatch by event."""
    try:
        raw = sys.stdin.read()
        if not raw.strip():
            return
        data = json.loads(raw)
    except (json.JSONDecodeError, IOError):
        return

    event = data.get("hook_event_name", "")

    try:
        if event == "SessionStart":
            result = _handle_session_start(data)
        elif event == "PreToolUse":
            result = _handle_pre_tool_use(data)
        elif event == "PostToolUse":
            result = _handle_post_tool_use(data)
        elif event == "PostToolUseFailure":
            result = _handle_post_tool_use_failure(data)
        elif event == "SubagentStart":
            result = _handle_subagent_start(data)
        elif event == "SubagentStop":
            result = _handle_subagent_stop(data)
        elif event == "TeammateIdle":
            result = _handle_teammate_idle(data)
        elif event == "Stop":
            result = _handle_stop(data)
        elif event == "StopFailure":
            result = _handle_generic(data, "stop_failure", include_keys=("error",))
        elif event == "SessionEnd":
            result = _handle_session_end(data)
        elif event == "UserPromptSubmit":
            result = _handle_generic(data, "user_prompt", include_keys=("prompt",))
        elif event == "Notification":
            result = _handle_generic(
                data, "notification", include_keys=("message", "notification_type")
            )
        elif event == "TaskCreated":
            result = _handle_generic(
                data, "task_created", include_keys=("task_id", "content", "status")
            )
        elif event == "TaskCompleted":
            result = _handle_generic(
                data, "task_completed", include_keys=("task_id", "content", "status")
            )
        elif event == "PermissionRequest":
            result = _handle_generic(
                data,
                "permission_request",
                include_keys=("tool_name", "tool_input", "reason"),
            )
        elif event == "PermissionDenied":
            result = _handle_generic(
                data,
                "permission_denied",
                include_keys=("tool_name", "tool_input", "reason"),
            )
        elif event == "InstructionsLoaded":
            result = _handle_generic(
                data, "instructions_loaded", include_keys=("file_path", "source")
            )
        elif event == "CwdChanged":
            result = _handle_generic(
                data, "cwd_changed", include_keys=("old_cwd", "new_cwd", "cwd")
            )
        elif event == "ConfigChange":
            result = _handle_generic(
                data, "config_change", include_keys=("file_path", "config_type")
            )
        elif event == "FileChanged":
            result = _handle_generic(
                data, "file_changed", include_keys=("file_path", "event_type")
            )
        elif event == "PreCompact":
            result = _handle_pre_compact(data)
        elif event == "PostCompact":
            result = _handle_generic(
                data, "post_compact", include_keys=("pre_tokens", "post_tokens")
            )
        elif event == "WorktreeCreate":
            result = _handle_generic(
                data, "worktree_create", include_keys=("worktree_path",)
            )
        elif event == "WorktreeRemove":
            result = _handle_generic(
                data, "worktree_remove", include_keys=("worktree_path",)
            )
        elif event == "Elicitation":
            result = _handle_generic(
                data, "elicitation", include_keys=("server_name", "prompt")
            )
        elif event == "ElicitationResult":
            result = _handle_generic(
                data, "elicitation_result", include_keys=("server_name", "response")
            )
        else:
            # Still record unknown events so we can discover new ones the
            # Claude Code team adds later
            result = _handle_generic(data, f"unknown:{event}")

        if result:
            print(json.dumps(result))
    except Exception as e:
        # Never let hook errors break Claude Code
        logger.debug("Hook handler error for %s: %s", event, e)


def _get_client() -> WaxellObserveClient:
    """Get an observe client using standard config resolution."""
    return WaxellObserveClient()


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


_VALID_FAIL_DEFAULTS = {"allow", "ask", "deny"}


def _resolve_agent_slug(client) -> str:
    """B10 — resolve agent_slug for this CC instance.

    Priority:
        1. CLAUDE_CODE_AGENT_SLUG env var (per-instance override)
        2. WAXELL_AGENT_SLUG env var (generic alias)
        3. ~/.waxell/config [<profile>] agent_slug = ...

    Lets a single profile (and its API key) be reused by two CC instances
    that each want a distinct daily run + dedupe namespace — set the env
    var in the shell that launches each instance.

    C7 — when ``WAXELL_PROJECT_KEY`` is set (--isolation project) and the
    resolved slug doesn't already include it, append ``-proj-<key>`` so
    two repos sharing one profile materialize as distinct daily-run
    accumulators on the controlplane.
    """
    env = (
        os.environ.get("CLAUDE_CODE_AGENT_SLUG")
        or os.environ.get("WAXELL_AGENT_SLUG")
        or ""
    ).strip()
    base = (
        env
        or (getattr(getattr(client, "config", None), "agent_slug", "") or "").strip()
    )
    if not base:
        return ""
    project_key = (os.environ.get("WAXELL_PROJECT_KEY") or "").strip()
    if project_key and f"proj-{project_key}" not in base:
        return f"{base}-proj-{project_key}"
    return base


def _emit_guard_decision(
    *,
    state,
    tool_name: str,
    action: str,
    violations: list,
    rule: str = "",
) -> None:
    """B9 — emit a guard_decision step so deny/ask decisions show up on
    the trace timeline. Best-effort; swallows all errors so a network
    blip never affects the local guard's actual decision."""
    if not state or not getattr(state, "run_id", ""):
        return
    try:
        client = _get_client()
        if not client.config.is_configured:
            return
        client.record_steps_sync(
            run_id=state.run_id,
            steps=[
                {
                    "step_name": f"hook:guard_decision:{action}",
                    "position": state.span_count,
                    "output": {
                        "kind": "guard_decision",
                        "source": "hook",
                        "session_id": getattr(state, "session_id", ""),
                        "tool_name": tool_name,
                        "action": action,
                        "violations": list(violations or []),
                        "rule": rule or "",
                        "timestamp": _now_iso(),
                    },
                }
            ],
        )
        state.span_count += 1
        save_state(state)
    except Exception as e:
        logger.debug("Failed to emit guard_decision step: %s", e)


def _resolve_fail_default(client) -> str:
    """C1 — resolve PreToolUse fail-default policy when controlplane is
    unreachable.

    Priority:
        1. WAXELL_POLICY_CHECK_FAIL_DEFAULT env var
        2. ~/.waxell/config [<profile>] policy_check_fail_default = ...
        3. "allow" (preserves historical fail-open behavior)
    """
    env = os.environ.get("WAXELL_POLICY_CHECK_FAIL_DEFAULT", "").strip().lower()
    if env in _VALID_FAIL_DEFAULTS:
        return env
    cfg = getattr(client, "config", None)
    if cfg is not None:
        # Config implementations expose extras differently; try common shapes.
        for attr in ("policy_check_fail_default", "extras"):
            value = getattr(cfg, attr, None)
            if isinstance(value, str) and value.strip().lower() in _VALID_FAIL_DEFAULTS:
                return value.strip().lower()
            if isinstance(value, dict):
                v = value.get("policy_check_fail_default")
                if isinstance(v, str) and v.strip().lower() in _VALID_FAIL_DEFAULTS:
                    return v.strip().lower()
    return "allow"


def _dedupe_path(run_id: str):
    """Per-run dedupe file for LLM call message_ids — persists across sessions.

    When ``WAXELL_PROJECT_KEY`` is set (--isolation project), the dedupe
    file lives under a project-scoped subdirectory so two repos sharing
    one Waxell profile keep independent dedupe namespaces. Without
    isolation the legacy flat layout is preserved.
    """
    from pathlib import Path

    base = Path.home() / ".waxell" / "cc-dedupe"
    project_key = (os.environ.get("WAXELL_PROJECT_KEY") or "").strip()
    if project_key:
        return base / project_key / f"{run_id}.json"
    return base / f"{run_id}.json"


def _handle_generic(data: dict, kind: str, include_keys: tuple = ()) -> dict | None:
    """Catch-all handler for hook events that don't need custom logic.

    Emits a single step with the selected payload keys (or the whole data dict
    if include_keys is empty). Used for: UserPromptSubmit, Notification,
    TaskCreated/Completed, PermissionRequest/Denied, InstructionsLoaded,
    CwdChanged, FileChanged, PreCompact/PostCompact, etc.

    Claude Code 2.1.92+ often fires InstructionsLoaded or UserPromptSubmit
    before (or instead of) SessionStart when plugins register competing
    SessionStart hooks — so if no session state exists, we lazy-create it
    here via _handle_session_start (idempotent).
    """
    session_id = data.get("session_id", "")
    state = _load_state_fresh(session_id, data)
    if not state or not state.run_id:
        _handle_session_start(data)
        state = _load_state_fresh(session_id, data)
        if not state or not state.run_id:
            return None
    if include_keys:
        payload = {k: data.get(k) for k in include_keys if k in data}
    else:
        # Exclude noisy boilerplate fields, keep everything else
        payload = {
            k: v
            for k, v in data.items()
            if k not in ("session_id", "hook_event_name", "transcript_path")
        }
    _emit_step(state, kind, payload)
    return None


def _load_state_fresh(session_id: str, data: dict | None = None):
    """Like load_state but also auto-rolls the run_id forward if the date
    has changed since the session started. Use this instead of load_state
    in all hook handlers so midnight-rollover is transparent.

    If `data` is provided AND no state exists for this session, lazily
    creates state by running SessionStart logic. This handles Claude Code
    2.1.92+ where plugins can preempt the SessionStart hook and we only
    see later events (InstructionsLoaded, UserPromptSubmit, PreToolUse).
    """
    state = load_state(session_id) if session_id else None
    if state and state.run_id:
        _refresh_daily_run_if_stale(state)
        return state
    if data and session_id and (not state or not state.run_id):
        _handle_session_start(data)
        state = load_state(session_id)
        if state and state.run_id:
            _refresh_daily_run_if_stale(state)
    return state


def _refresh_daily_run_if_stale(state) -> None:
    """If this session's state.run_id is from a previous day, refresh it to
    today's daily run. Handles the midnight-rollover case for long-lived
    Claude Code sessions that span multiple days.

    Silently no-ops on failure; worst case events keep writing to yesterday's
    run until the session restarts.
    """
    if not state or not state.run_id:
        return
    try:
        today_iso = datetime.now(timezone.utc).date().isoformat()
        # state.started_at is ISO8601 UTC. Extract the date portion (chars 0-10).
        started_date = (state.started_at or "")[:10]
        if started_date and started_date == today_iso:
            return  # Still same day — state is fresh
        client = _get_client()
        if not client.config.is_configured:
            return
        agent_slug = _resolve_agent_slug(client)
        if not agent_slug:
            return
        daily = client.start_daily_run_sync(
            agent_slug=agent_slug,
            agent_type="claude-code",
        )
        if daily.run_id and daily.run_id != state.run_id:
            logger.info(
                "rolled session %s from run %s → %s (daily session date changed)",
                state.session_id[:8] if state.session_id else "(none)",
                state.run_id,
                daily.run_id,
            )
            # C4 — emit a rollover step on the OLD run so the trace tail
            # shows why the session pivoted. Best-effort; never raises.
            old_run_id = state.run_id
            try:
                client.record_steps_sync(
                    run_id=old_run_id,
                    steps=[
                        {
                            "step_name": "hook:daily_run_rollover",
                            "position": state.span_count,
                            "output": {
                                "kind": "daily_run_rollover",
                                "source": "hook",
                                "session_id": state.session_id,
                                "old_run_id": old_run_id,
                                "new_run_id": daily.run_id,
                                "old_started_at": state.started_at,
                                "rolled_at": _now_iso(),
                            },
                        }
                    ],
                )
            except Exception as roll_err:
                logger.debug("rollover span emit failed: %s", roll_err)

            state.run_id = daily.run_id
            state.workflow_id = daily.workflow_id
            state.started_at = daily.started_at or _now_iso()
            save_state(state)
    except Exception as e:
        logger.debug("daily run refresh failed: %s", e)


def _load_recorded_llm_ids(run_id: str) -> set:
    if not run_id:
        return set()
    p = _dedupe_path(run_id)
    if not p.exists():
        return set()
    try:
        import json as _j

        return set(_j.loads(p.read_text()))
    except Exception:
        return set()


def _save_recorded_llm_ids(run_id: str, ids: set) -> None:
    if not run_id:
        return
    import json as _j
    import os as _os

    p = _dedupe_path(run_id)
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = str(p) + ".tmp"
        with open(tmp, "w") as f:
            _j.dump(sorted(ids), f)
        _os.replace(tmp, p)
    except Exception as e:
        logger.debug("dedupe save failed run=%s: %s", run_id, e)


def _emit_step(state, kind: str, payload: dict | None = None) -> None:
    """Emit a step on the agent's daily run for the activity timeline.

    Best-effort — failures logged at debug, never raised. State's span_count
    is reused as the monotonic position so events stay ordered within a run.
    `kind` becomes the suffix of step_name (e.g. 'session_start' →
    'hook:session_start'); payload contents go into step.output for the
    timeline expander.
    """
    if not state or not state.run_id:
        return
    # Auto-rollover to today's daily run if the date changed since SessionStart
    _refresh_daily_run_if_stale(state)
    client = _get_client()
    if not client.config.is_configured:
        return
    # Phase 1.5 / Task #8 — hardware_uuid stamps every hook emission so
    # the controlplane Device model can join Claude Code hook events to
    # the same machine as cowork audit + observe SDK records. Cached.
    from waxell_observe.platform import get_hardware_uuid

    output = {
        "kind": kind,
        "source": "hook",
        "session_id": state.session_id,
        "timestamp": _now_iso(),
        "hardware_uuid": get_hardware_uuid(),
    }
    if payload:
        output.update(payload)
    try:
        client.record_steps_sync(
            run_id=state.run_id,
            steps=[
                {
                    "step_name": f"hook:{kind}",
                    "position": state.span_count,
                    "output": output,
                }
            ],
        )
        state.span_count += 1
        save_state(state)
    except Exception as e:
        logger.debug("Failed to emit hook:%s step: %s", kind, e)


# -----------------------------------------------------------------
# Event handlers
# -----------------------------------------------------------------


def _handle_session_start(data: dict) -> dict | None:
    """Create a new run for this Claude Code session."""
    session_id = data.get("session_id", "")
    if not session_id:
        return None

    # Clean up stale state files from old sessions
    cleanup_stale_states()

    # Check if this session already has state (resume)
    existing = load_state(session_id)
    if existing and existing.run_id:
        return None

    source = data.get("source", "startup")
    cwd = data.get("cwd", "")
    model = data.get("model", "")

    # Detect Cowork: another active session in the same directory
    peer = find_cowork_peer(cwd, session_id) if cwd else None
    is_cowork = peer is not None
    cowork_session_id = ""
    if peer:
        # Use the peer's cowork_session_id if it has one, otherwise use the peer's session_id
        cowork_session_id = peer.cowork_session_id or peer.session_id
        # Mark the peer as cowork too if not already
        if not peer.is_cowork:
            peer.is_cowork = True
            peer.cowork_session_id = cowork_session_id
            save_state(peer)

    client = _get_client()
    if not client.config.is_configured:
        return None

    metadata = {
        "source": "claude_code",
        "model": model,
        "permission_mode": data.get("permission_mode", ""),
    }
    if is_cowork:
        metadata["is_cowork"] = True
        metadata["cowork_session_id"] = cowork_session_id
        if peer:
            metadata["cowork_parent_run_id"] = peer.run_id

    # Prefer the daily session run if we have an agent_slug configured —
    # multiple Claude Code CLI sessions on the same day accumulate into one
    # run attributed to the Connect agent. Fall back to per-session run.
    configured_slug = _resolve_agent_slug(client)
    run_info = None
    is_daily_session = False
    if configured_slug:
        try:
            daily = client.start_daily_run_sync(
                agent_slug=configured_slug,
                agent_type="claude-code",
            )

            # DailyRunInfo → shim into RunInfo-ish for downstream state
            class _Run:
                def __init__(self, r, w, s):
                    self.run_id = r
                    self.workflow_id = w
                    self.started_at = s

            run_info = _Run(daily.run_id, daily.workflow_id, daily.started_at)
            is_daily_session = True
            logger.debug(
                "attached CLI session %s to daily run %s (agent=%s, %s)",
                session_id,
                daily.run_id,
                configured_slug,
                "created" if daily.created else "existing",
            )
        except Exception as e:
            logger.debug("daily run failed (%s) — falling back to per-session", e)

    if run_info is None:
        try:
            run_info = client.start_run_sync(
                agent_name="claude-code",
                workflow_name=f"session:{source}",
                inputs={
                    "cwd": cwd,
                    "source": source,
                },
                metadata=metadata,
                session_id=session_id,
            )
        except Exception as e:
            logger.debug("Failed to start run: %s", e)
            return None

    state = SessionState(
        session_id=session_id,
        run_id=run_info.run_id,
        workflow_id=run_info.workflow_id,
        started_at=run_info.started_at or _now_iso(),
        cwd=cwd,
        model=model,
        is_cowork=is_cowork,
        cowork_session_id=cowork_session_id,
        is_daily_session=is_daily_session,
    )
    save_state(state)
    _emit_step(
        state,
        "session_start",
        {
            "source": source,
            "cwd": cwd,
            "model": model,
            "is_cowork": is_cowork,
        },
    )
    return None


def _handle_pre_tool_use(data: dict) -> dict | None:
    """Governance gate — local guard + server policy check before tool execution.

    Flow:
    1. Run local guard (instant, no network) — checks tool inputs
    2. If local guard denies → block immediately
    3. Run server-side policy check (budget, scheduling, kill switch)
    4. Combine warnings from both layers
    """
    session_id = data.get("session_id", "")
    state = _load_state_fresh(session_id, data)
    if not state or not state.run_id:
        return None

    tool_name = data.get("tool_name", "")
    tool_input = data.get("tool_input", {})
    warnings: list[str] = []

    # Skip the recording step — PostToolUse already captures tool events.
    # Removing this network call saves 200-500ms per tool use that was
    # blocking Claude synchronously.

    # --- Layer 1: Local guard (instant, no network) ---
    try:
        from .guard import check_tool_use, load_config

        # Pass the client so load_config can pull the controlplane-managed
        # remote layer (B5/B6). Falls back gracefully to file + builtin
        # if the client isn't configured or controlplane is unreachable.
        config = load_config(state.cwd, client=_get_client())

        # Gather peer modified files for cowork conflict detection
        peer_modified: list[str] | None = None
        if state.is_cowork and config.detect_file_conflicts:
            peer = find_cowork_peer(state.cwd, state.session_id)
            if peer:
                peer_modified = peer.modified_files

        guard_result = check_tool_use(
            tool_name=tool_name,
            tool_input=tool_input,
            config=config,
            cwd=state.cwd,
            modified_files=state.modified_files,
            peer_modified_files=peer_modified,
        )

        if guard_result.action == "deny":
            # B9 — emit a guard_decision step so the deny shows up on the
            # trace timeline next to other hook events. Best-effort; never
            # raises (the deny return below is the hard guarantee).
            _emit_guard_decision(
                state=state,
                tool_name=tool_name,
                action="deny",
                violations=guard_result.violations,
                rule=getattr(guard_result, "rule", ""),
            )
            return {
                "hookSpecificOutput": {
                    "hookEventName": "PreToolUse",
                    "permissionDecision": "deny",
                    "permissionDecisionReason": (
                        f"Waxell guard: {'; '.join(guard_result.violations)}"
                    ),
                }
            }

        if guard_result.action == "ask":
            warnings.extend(guard_result.violations)
            _emit_guard_decision(
                state=state,
                tool_name=tool_name,
                action="ask",
                violations=guard_result.violations,
                rule=getattr(guard_result, "rule", ""),
            )

    except Exception as e:
        logger.debug("Local guard error: %s", e)

    # --- Layer 2: Server-side policy check (budget, scheduling, kill switch) ---
    # Skip if no agent_slug configured — means no Connect agent, so no
    # server-side policies to check. Saves 200-500ms network round-trip.
    client = _get_client()
    has_agent = bool(_resolve_agent_slug(client))
    if client.config.is_configured and has_agent:
        try:
            policy_result = client.check_policy_sync(
                agent_name="claude-code",
                workflow_name=f"tool:{tool_name}",
                agent_id=state.run_id,
            )

            if policy_result.action == "block":
                _emit_guard_decision(
                    state=state,
                    tool_name=tool_name,
                    action="policy_block",
                    violations=[policy_result.reason or "Policy violation"],
                    rule="server-side",
                )
                return {
                    "hookSpecificOutput": {
                        "hookEventName": "PreToolUse",
                        "permissionDecision": "deny",
                        "permissionDecisionReason": (
                            f"Waxell policy blocked: {policy_result.reason or 'Policy violation'}"
                        ),
                    }
                }

            if policy_result.action == "warn":
                warnings.append(f"Policy warning: {policy_result.reason}")
                _emit_guard_decision(
                    state=state,
                    tool_name=tool_name,
                    action="policy_warn",
                    violations=[policy_result.reason or "Policy warning"],
                    rule="server-side",
                )

        except Exception as e:
            # C1 — server-side policy check failed (network, timeout, etc).
            # Today's behavior: silently fail-open (this branch). New
            # behavior: honor the tenant's configured fail-default. The
            # default remains `allow` to match historical behavior, but
            # operators can opt into stricter (`ask`/`deny`) via
            # ~/.waxell/config: [claude-code] policy_check_fail_default = ask
            fail_default = _resolve_fail_default(client)
            logger.warning(
                "[hook] PreToolUse policy check failed (%s); applying fail-default=%s",
                e,
                fail_default,
            )
            if fail_default == "deny":
                return {
                    "hookSpecificOutput": {
                        "hookEventName": "PreToolUse",
                        "permissionDecision": "deny",
                        "permissionDecisionReason": (
                            "Waxell policy check failed and tenant default is deny — "
                            "controlplane is unreachable. Configure "
                            "[claude-code] policy_check_fail_default=allow to override."
                        ),
                    }
                }
            if fail_default == "ask":
                warnings.append(
                    "Policy check failed (controlplane unreachable); proceeding requires confirmation."
                )

    # --- Combine warnings ---
    if warnings:
        return {
            "hookSpecificOutput": {
                "hookEventName": "PreToolUse",
                "permissionDecision": "ask",
                "additionalContext": (f"Waxell: {'; '.join(warnings)}"),
            }
        }

    return None


def _handle_post_tool_use(data: dict) -> dict | None:
    """Record a tool call span (async, non-blocking)."""
    session_id = data.get("session_id", "")
    state = _load_state_fresh(session_id, data)
    if not state or not state.run_id:
        return None

    tool_name = data.get("tool_name", "")
    tool_input = data.get("tool_input", {})
    tool_response = data.get("tool_response", {})

    # Build input summary (truncated for safety)
    input_summary = _summarize_tool_input(tool_name, tool_input)
    output_summary = _summarize_tool_output(tool_name, tool_response)

    client = _get_client()
    if not client.config.is_configured:
        return None

    now = _now_iso()
    try:
        client.record_spans_sync(
            run_id=state.run_id,
            spans=[
                {
                    "name": tool_name,
                    "kind": "tool",
                    "status": "ok",
                    "start_time": now,
                    "end_time": now,
                    "attributes": {
                        "tool.name": tool_name,
                        "tool.input_summary": input_summary,
                        "tool.output_summary": output_summary,
                    },
                    "input_data": input_summary,
                    "output_data": output_summary,
                }
            ],
        )
    except Exception as e:
        logger.debug("Failed to record span: %s", e)
        return None

    # Also record as a step so it shows up in the per-agent activity timeline
    # (steps + llm_calls is what /observe/agents/<slug>/activity/ aggregates).
    # Spans go to the Tempo/OTEL-style trace tree which is a different surface.
    try:
        client.record_steps_sync(
            run_id=state.run_id,
            steps=[
                {
                    "step_name": f"hook:tool_use:{tool_name}",
                    "position": state.span_count,
                    "output": {
                        "kind": "tool_use",
                        "tool_name": tool_name,
                        "tool_input": _truncate_json(tool_input),
                        "tool_response_summary": output_summary,
                        "source": "hook",
                        "session_id": session_id,
                        "timestamp": now,
                    },
                }
            ],
        )
    except Exception as e:
        logger.debug("Failed to record step: %s", e)

    # Track modified files for session scope + cowork conflict detection
    if tool_name in ("Write", "Edit"):
        file_path = tool_input.get("file_path", "")
        if file_path and file_path not in state.modified_files:
            state.modified_files.append(file_path)

    # Update span count
    state.span_count += 1
    save_state(state)
    return None


def _truncate_json(obj, max_chars=2000):
    """Make a JSON-serializable copy with each string field bounded."""
    if isinstance(obj, str):
        return obj[:max_chars]
    if isinstance(obj, dict):
        return {k: _truncate_json(v, max_chars) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_truncate_json(v, max_chars) for v in obj[:50]]
    return obj


def _handle_post_tool_use_failure(data: dict) -> dict | None:
    """Record a failed tool call span."""
    session_id = data.get("session_id", "")
    state = _load_state_fresh(session_id, data)
    if not state or not state.run_id:
        return None

    tool_name = data.get("tool_name", "")
    error = data.get("error", "")

    client = _get_client()
    if not client.config.is_configured:
        return None

    now = _now_iso()
    try:
        client.record_spans_sync(
            run_id=state.run_id,
            spans=[
                {
                    "name": tool_name,
                    "kind": "tool",
                    "status": "error",
                    "start_time": now,
                    "end_time": now,
                    "attributes": {
                        "tool.name": tool_name,
                        "error.message": error[:500],
                    },
                    "events": [{"name": "error", "message": error[:500]}]
                    if error
                    else [],
                }
            ],
        )
    except Exception as e:
        logger.debug("Failed to record error span: %s", e)

    _emit_step(
        state,
        "tool_failure",
        {
            "tool_name": tool_name,
            "error": (error or "")[:500],
        },
    )

    state.span_count += 1
    save_state(state)
    return None


def _handle_subagent_start(data: dict) -> dict | None:
    """Record the start of a subagent/Task tool invocation."""
    session_id = data.get("session_id", "")
    state = _load_state_fresh(session_id, data)
    if not state or not state.run_id:
        return None

    agent_id = data.get("agent_id", "")
    agent_type = data.get("agent_type", "")

    # Store start time for this subagent
    state.pending_subagent_spans[agent_id] = {
        "agent_type": agent_type,
        "start_time": _now_iso(),
    }
    save_state(state)
    _emit_step(
        state,
        "subagent_start",
        {
            "agent_id": agent_id,
            "agent_type": agent_type,
        },
    )
    return None


def _handle_subagent_stop(data: dict) -> dict | None:
    """Record the end of a subagent and its token usage."""
    session_id = data.get("session_id", "")
    state = _load_state_fresh(session_id, data)
    if not state or not state.run_id:
        return None

    agent_id = data.get("agent_id", "")
    agent_type = data.get("agent_type", "")
    transcript_path = data.get("agent_transcript_path", "")

    # Get start time from pending spans
    pending = state.pending_subagent_spans.pop(agent_id, {})
    start_time = pending.get("start_time", _now_iso())

    # Parse subagent transcript for token usage
    sub_summary = None
    if transcript_path:
        sub_summary = parse_transcript(transcript_path)

    client = _get_client()
    if not client.config.is_configured:
        save_state(state)
        return None

    now = _now_iso()
    attributes = {
        "agent.type": agent_type or pending.get("agent_type", ""),
        "agent.id": agent_id,
    }
    if sub_summary:
        attributes["agent.total_tokens"] = (
            sub_summary.total_tokens_in + sub_summary.total_tokens_out
        )
        attributes["agent.cost"] = round(sub_summary.total_cost, 6)
        attributes["agent.turns"] = sub_summary.total_turns

    try:
        client.record_spans_sync(
            run_id=state.run_id,
            spans=[
                {
                    "name": f"subagent:{agent_type or 'unknown'}",
                    "kind": "agent",
                    "status": "ok",
                    "start_time": start_time,
                    "end_time": now,
                    "attributes": attributes,
                }
            ],
        )
    except Exception as e:
        logger.debug("Failed to record subagent span: %s", e)

    # Also record subagent LLM calls on the parent run
    if sub_summary and sub_summary.llm_calls:
        try:
            client.record_llm_calls_sync(
                run_id=state.run_id,
                calls=[
                    {
                        "model": call.model,
                        "tokens_in": call.tokens_in,
                        "tokens_out": call.tokens_out,
                        "cost": call.cost,
                        "task": f"subagent:{agent_type}",
                    }
                    for call in sub_summary.llm_calls
                ],
            )
        except Exception:
            pass

    sub_payload = {
        "agent_id": agent_id,
        "agent_type": agent_type,
    }
    if sub_summary:
        sub_payload["total_tokens_in"] = sub_summary.total_tokens_in
        sub_payload["total_tokens_out"] = sub_summary.total_tokens_out
        sub_payload["total_cost"] = round(sub_summary.total_cost, 6)
        sub_payload["total_turns"] = sub_summary.total_turns
    _emit_step(state, "subagent_stop", sub_payload)

    state.span_count += 1
    save_state(state)
    return None


def _handle_teammate_idle(data: dict) -> dict | None:
    """Record a Cowork teammate idle event (coordination span)."""
    session_id = data.get("session_id", "")
    state = _load_state_fresh(session_id, data)
    if not state or not state.run_id:
        return None

    # Mark this session as a Cowork session
    if not state.is_cowork:
        state.is_cowork = True
        if not state.cowork_session_id:
            state.cowork_session_id = session_id
        save_state(state)

    client = _get_client()
    if not client.config.is_configured:
        return None

    now = _now_iso()
    try:
        client.record_spans_sync(
            run_id=state.run_id,
            spans=[
                {
                    "name": "teammate_idle",
                    "kind": "custom",
                    "status": "ok",
                    "start_time": now,
                    "end_time": now,
                    "attributes": {
                        "cowork.event": "teammate_idle",
                        "cowork.session_id": state.cowork_session_id,
                    },
                }
            ],
        )
    except Exception:
        pass
    _emit_step(
        state,
        "teammate_idle",
        {
            "cowork_session_id": state.cowork_session_id,
        },
    )
    return None


def _handle_stop(data: dict) -> dict | None:
    """Session ending — parse transcript and complete the run."""
    session_id = data.get("session_id", "")
    state = _load_state_fresh(session_id, data)
    if not state or not state.run_id:
        return None

    transcript_path = data.get("transcript_path", "")

    client = _get_client()
    if not client.config.is_configured:
        delete_state(session_id)
        return None

    # Incrementally parse ONLY new lines since last Stop. The transcript file
    # grows throughout the session; re-parsing from the start every turn is
    # what made Stop take 5-30s on long sessions.
    summary = None
    if transcript_path:
        last_offset = getattr(state, "transcript_offset", 0) or 0
        summary = parse_transcript(transcript_path, start_offset=last_offset)
        # Update the offset so the NEXT Stop only parses new content.
        try:
            import os

            new_offset = os.path.getsize(transcript_path)
            state.transcript_offset = new_offset
        except OSError:
            pass

    # Batch-record only LLM calls we haven't already seen on this RUN.
    # Dedupe scoped to run_id (persists across multiple CLI sessions that
    # all share the same daily run) — NOT just this session. Claude Code's
    # transcript is per-project and accumulates across sessions, so without
    # this every new session's Stop re-records every historical call.
    seen_ids = _load_recorded_llm_ids(state.run_id)
    new_calls = [
        c
        for c in (summary.llm_calls if summary else [])
        if c.message_id and c.message_id not in seen_ids
    ]
    if summary and new_calls:
        try:
            client.record_llm_calls_sync(
                run_id=state.run_id,
                calls=[
                    {
                        "model": call.model,
                        "tokens_in": call.tokens_in,
                        "tokens_out": call.tokens_out,
                        "cost": call.cost,
                        "task": call.task,
                        "prompt_preview": call.prompt_preview,
                        "response_preview": call.response_preview,
                        "timestamp": call.timestamp,
                    }
                    for call in new_calls
                ],
            )
            _save_recorded_llm_ids(
                state.run_id, seen_ids | {c.message_id for c in new_calls}
            )
        except Exception as e:
            logger.debug("Failed to record LLM calls: %s", e)

    # Complete the run
    result_data = {}
    if summary:
        result_data = {
            "total_tokens_in": summary.total_tokens_in,
            "total_tokens_out": summary.total_tokens_out,
            "total_cost": round(summary.total_cost, 6),
            "total_turns": summary.total_turns,
            "models_used": summary.models_used,
            "tool_uses": summary.tool_uses + state.span_count,
        }

    if state.is_cowork:
        result_data["is_cowork"] = True
        result_data["cowork_session_id"] = state.cowork_session_id

    # C9 — Stop cost reconciliation. Re-resolve total cost from the
    # transcript's ingested LLM calls (authoritative) and compare against
    # the agent's expected cap (server-side policy). On overage, emit a
    # one-time guard_decision step so the alert lands on the run timeline
    # next to the regular stop step. Best-effort; failure here must never
    # block the rest of the Stop pipeline.
    try:
        _reconcile_stop_cost(state, summary, client)
    except Exception as e:
        logger.debug("Stop cost reconciliation failed: %s", e)

    # Emit a final visibility step BEFORE completing the run so it appears
    # in the activity timeline. (For daily session runs we don't actually
    # complete — the run accumulates across many CLI sessions in the day.)
    _emit_step(state, "stop", result_data)

    # Only complete the run + delete state if this is NOT a daily session
    # accumulator. Daily runs stay open across the day and across many CLI
    # sessions; deleting state here would cause subsequent PostToolUse hooks
    # to bail silently (no state, no attribution).
    is_daily = bool(getattr(state, "is_daily_session", False))
    if not is_daily:
        try:
            client.complete_run_sync(
                run_id=state.run_id,
                result=result_data,
                status="success",
            )
        except Exception as e:
            logger.debug("Failed to complete run: %s", e)
        delete_state(session_id)
    else:
        # Persist state so next Stop fire picks up where we left off (dedupe
        # set, span_count, etc.)
        save_state(state)
    return None


def _handle_session_end(data: dict) -> dict | None:
    """Session fully terminated — ensure cleanup."""
    session_id = data.get("session_id", "")
    if session_id:
        # Stop handler may not have fired (e.g., force quit)
        state = load_state(session_id)
        if state and state.run_id:
            _handle_stop(data)
    return None


# -----------------------------------------------------------------
# C9 — Governance routing for previously-unwired hook events.
# -----------------------------------------------------------------


def _handle_pre_compact(data: dict) -> dict | None:
    """C9 — PreCompact governance gate.

    Run a server-side policy check (typically a budget policy) before the
    model compacts its context. Compaction is a model-driven decision
    that hides cost behind a single big LLM call; if the agent is already
    near or over a budget threshold the operator may want to refuse the
    compaction and force the model to stop or summarize differently.

    Hook response shape:
      - ``block`` policy → return ``permissionDecision: "deny"`` so Claude
        Code refuses the compaction and surfaces the reason to the model.
      - ``warn`` policy → return ``additionalContext`` so the model sees
        the budget pressure but compaction proceeds.
      - otherwise → no-op (still emits the pre_compact timeline step).

    Always emits a ``hook:pre_compact`` step for the timeline regardless
    of policy outcome; that's the same surface as the previous generic
    handler so we don't lose visibility for tenants without policies.
    """
    session_id = data.get("session_id", "")
    state = _load_state_fresh(session_id, data)
    if not state or not state.run_id:
        return None

    pre_tokens = data.get("pre_tokens")
    payload: dict = {}
    if pre_tokens is not None:
        payload["pre_tokens"] = pre_tokens

    # Always record the lifecycle event for timeline parity with the
    # previous generic handler. The governance branch below adds a
    # guard_decision step on top when the policy fires.
    _emit_step(state, "pre_compact", payload)

    client = _get_client()
    if not client.config.is_configured:
        return None
    if not _resolve_agent_slug(client):
        # No Connect agent → no server-side policies to check (matches
        # _handle_pre_tool_use's gating).
        return None

    try:
        policy_result = client.check_policy_sync(
            agent_name="claude-code",
            workflow_name="claude-code:precompact",
            agent_id=state.run_id,
        )
    except Exception as e:
        # Policy check failed — never escalate to a refusal here. C1's
        # fail-default is for tool-call enforcement; refusing compaction
        # on a network blip would strand the model in a too-large context.
        logger.debug("PreCompact policy check failed: %s", e)
        return None

    action = (getattr(policy_result, "action", "") or "").lower()
    reason = (getattr(policy_result, "reason", "") or "").strip()

    if action == "block":
        _emit_guard_decision(
            state=state,
            tool_name="PreCompact",
            action="precompact_block",
            violations=[reason or "Budget policy blocked compaction"],
            rule="server-side",
        )
        return {
            "hookSpecificOutput": {
                "hookEventName": "PreCompact",
                "permissionDecision": "deny",
                "permissionDecisionReason": (
                    f"Waxell policy blocked compaction: "
                    f"{reason or 'budget threshold exceeded'}"
                ),
            }
        }

    if action == "warn":
        _emit_guard_decision(
            state=state,
            tool_name="PreCompact",
            action="precompact_warn",
            violations=[reason or "Budget policy warning"],
            rule="server-side",
        )
        return {
            "hookSpecificOutput": {
                "hookEventName": "PreCompact",
                "additionalContext": (
                    f"Waxell budget warning before compaction: "
                    f"{reason or 'approaching budget threshold'}"
                ),
            }
        }

    return None


def _reconcile_stop_cost(state, summary, client) -> None:
    """C9 — re-resolve total cost from ingested LLM calls and flag overage.

    Pulls the expected cap from a server-side policy check so the same
    budget config drives both PreToolUse blocking and post-run alerting.
    On overage, emits a one-time ``post_run_overage`` guard_decision step
    so the alert lands on the run timeline. ``state.cost_overage_emitted``
    guards against duplicate alerts when Stop fires repeatedly within a
    daily session.
    """
    if not state or not state.run_id or not summary:
        return
    if not client or not getattr(client.config, "is_configured", False):
        return
    if not _resolve_agent_slug(client):
        return

    # Already alerted on this run — Stop may fire many times within a daily
    # session and we don't want to spam the timeline.
    if getattr(state, "cost_overage_emitted", False):
        return

    actual_cost = float(getattr(summary, "total_cost", 0.0) or 0.0)
    if actual_cost <= 0:
        return

    # Pull the expected cap from a stop-time policy check. Server reports
    # `metadata.cost_cap` when a budget policy is in scope; falling back
    # to None means "no cap configured", which is a no-op below.
    expected_cap: float | None = None
    try:
        policy_result = client.check_policy_sync(
            agent_name="claude-code",
            workflow_name="claude-code:stop",
            agent_id=state.run_id,
        )
        meta = getattr(policy_result, "metadata", {}) or {}
        cap_val = meta.get("cost_cap")
        if cap_val is not None:
            expected_cap = float(cap_val)
    except Exception as e:
        logger.debug("Stop policy lookup for cost cap failed: %s", e)

    if expected_cap is None or expected_cap <= 0:
        return
    if actual_cost <= expected_cap:
        return

    overage = round(actual_cost - expected_cap, 6)
    _emit_guard_decision(
        state=state,
        tool_name="Stop",
        action="post_run_overage",
        violations=[
            f"Reconciled cost ${actual_cost:.4f} exceeds cap ${expected_cap:.4f} "
            f"(overage ${overage:.4f})"
        ],
        rule="server-side",
    )
    # Mark so we don't re-emit on subsequent Stops in the same daily session.
    try:
        state.cost_overage_emitted = True
        save_state(state)
    except Exception as e:
        logger.debug("Failed to persist cost_overage_emitted flag: %s", e)


# -----------------------------------------------------------------
# Tool input/output summarization
# -----------------------------------------------------------------


def _summarize_tool_input(tool_name: str, tool_input: dict) -> str:
    """Create a brief summary of tool input for the span."""
    if not tool_input:
        return ""

    if tool_name == "Bash":
        cmd = tool_input.get("command", "")
        return cmd[:200] if cmd else ""
    elif tool_name in ("Read", "Write", "Edit"):
        return tool_input.get("file_path", "")
    elif tool_name == "Grep":
        pattern = tool_input.get("pattern", "")
        path = tool_input.get("path", "")
        return f"{pattern} in {path}" if path else pattern
    elif tool_name == "Glob":
        return tool_input.get("pattern", "")
    elif tool_name == "WebSearch":
        return tool_input.get("query", "")
    elif tool_name == "WebFetch":
        return tool_input.get("url", "")
    elif tool_name == "Task":
        desc = tool_input.get("description", "")
        agent_type = tool_input.get("subagent_type", "")
        return f"[{agent_type}] {desc}" if agent_type else desc
    else:
        # MCP tools or unknown — just show first key-value
        for k, v in tool_input.items():
            return f"{k}={str(v)[:100]}"
    return ""


def _summarize_tool_output(tool_name: str, tool_response: dict) -> str:
    """Create a brief summary of tool output for the span."""
    if not tool_response:
        return ""

    if isinstance(tool_response, str):
        return tool_response[:200]

    # Common patterns
    content = tool_response.get("content", "")
    if content and isinstance(content, str):
        return content[:200]

    file_path = tool_response.get("filePath", "")
    if file_path:
        return f"file:{file_path}"

    return str(tool_response)[:200]
