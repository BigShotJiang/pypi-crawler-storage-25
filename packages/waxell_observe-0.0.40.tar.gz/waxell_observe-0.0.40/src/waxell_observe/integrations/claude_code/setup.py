"""Setup, removal, and status detection for Claude Code integration.

Profile-aware: each tool (claude-code, claude-cowork, etc.) gets its own
profile in ~/.waxell/config and its own hook/MCP entries in Claude Code's
settings. Setup is idempotent and composable — re-running just refreshes
the target profile without touching others.
"""

import hashlib
import json
import logging
import os
import shutil
import subprocess
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

# Default profile name for the Claude Code integration.
# Each downstream tool (claude-code, claude-cowork, cursor, ...) uses its own.
DEFAULT_PROFILE = "claude-code"

# Isolation modes for hook installation.
# - "profile": (default) hooks are scoped per Waxell profile and shared across
#   any project that uses that profile. One daily run + one dedupe namespace.
# - "project": hooks live only in ./.claude/settings.json AND get
#   WAXELL_PROJECT_KEY=<sha256(cwd)[:8]> injected into the hook command, so
#   the handler scopes state and the dedupe path to a project namespace.
ISOLATION_PROFILE = "profile"
ISOLATION_PROJECT = "project"
VALID_ISOLATIONS = (ISOLATION_PROFILE, ISOLATION_PROJECT)


def project_key_for(path: Path | str) -> str:
    """Stable 8-char project key derived from absolute cwd.

    Used by --isolation project so two repos sharing the same profile don't
    collide on the daily run accumulator or LLM-call dedupe file. Hash is
    intentionally short — readable in hook commands and dedupe paths — and
    we only need uniqueness across the small set of project dirs a single
    user has, not collision-resistance.
    """
    s = str(Path(path).expanduser().resolve())
    return hashlib.sha256(s.encode("utf-8")).hexdigest()[:8]


# Legacy command (no profile) — detected during setup/remove for migration.
_LEGACY_HOOK_CMD = "wax claude-code hook"
_LEGACY_OBSERVE_HOOK_CMD = "wax observe claude-code hook"  # even older, broken
_LEGACY_FINGERPRINTS = [_LEGACY_HOOK_CMD, _LEGACY_OBSERVE_HOOK_CMD]


def _hook_cmd(profile: str, project_key: Optional[str] = None) -> str:
    """Build the hook command string for a given profile.

    When ``project_key`` is set (--isolation project), prepend a
    ``WAXELL_PROJECT_KEY=<key>`` env-var assignment so the hook handler
    scopes session state and the dedupe file to that project namespace.
    Two repos sharing the same profile won't collide.
    """
    base = f"wax --profile {profile} claude-code hook"
    if project_key:
        return f"WAXELL_PROJECT_KEY={project_key} {base}"
    return base


def _mcp_server_name(profile: str) -> str:
    """MCP server name in .mcp.json (unique per profile)."""
    return f"waxell-observe-{profile}"


def _profile_detect_cmd(project_key: Optional[str] = None) -> str:
    """Build the SessionStart profile auto-detection command (C8).

    Runs ``wax claude-code profile-detect`` which reads ``<cwd>/.waxell-profile``
    and (if present and valid) emits a Claude Code hook JSON response that
    injects ``WAXELL_PROFILE=<value>`` for subsequent hooks in the session.
    No-op when the file is missing — the configured-at-setup-time profile
    applies in that case.

    The project_key prefix is propagated so the detect step is
    indistinguishable from the rest of the project's hook entries when
    cleaning up via ``--isolation project``.
    """
    base = "wax claude-code profile-detect"
    if project_key:
        return f"WAXELL_PROJECT_KEY={project_key} {base}"
    return base


def _hook_fingerprint(profile: str) -> str:
    """Substring that identifies hooks belonging to a specific profile.

    The fingerprint matches whether the hook command was built with or
    without a ``WAXELL_PROJECT_KEY=...`` prefix (--isolation project) since
    the ``--profile <name>`` substring is always present after the prefix.
    """
    return f"--profile {profile} claude-code"


def _any_waxell_fingerprint(command: str) -> bool:
    """True if the command looks like any waxell hook (new or legacy)."""
    if "waxell" in command:
        return True
    if "wax claude-code" in command or "wax observe claude-code" in command:
        return True
    if "--profile" in command and "claude-code" in command and "wax" in command:
        return True
    # C8 profile-detect SessionStart shim (no --profile, but unmistakably ours)
    if "wax claude-code profile-detect" in command:
        return True
    return False


def _command_for_profile(command: str, profile: str) -> bool:
    """True if command is a waxell hook for the given profile specifically."""
    return _hook_fingerprint(profile) in command


# =============================================================================
# SETUP
# =============================================================================


DEFAULT_GOVERNANCE_MATCHER = "Bash|Edit|Write|Task|mcp__.*"


def setup_hooks(
    project_dir: Optional[str] = None,
    global_config: bool = False,
    governance: bool = False,
    mcp: bool = False,
    profile: str = DEFAULT_PROFILE,
    governance_matcher: Optional[str] = None,
    isolation: str = ISOLATION_PROFILE,
) -> dict:
    """Configure Claude Code hooks for Waxell observability.

    Args:
        project_dir: Project directory (defaults to cwd).
        global_config: Write to ~/.claude/settings.json instead of project.
        governance: Enable PreToolUse blocking hooks for policy enforcement.
        mcp: Register MCP server in .mcp.json.
        profile: Which Waxell config profile these hooks should use.
            Defaults to "claude-code". Each tool (claude-cowork, cursor, etc.)
            should use its own profile so they can have independent API keys.
        governance_matcher: Regex for which tools the PreToolUse hook fires on.
            Defaults to ``Bash|Edit|Write|Task|mcp__.*`` — covers shell, file
            mutations, sub-agent spawns, and MCP tool calls. Pass a tighter
            value (e.g. just "Bash") if the tenant only wants shell governance,
            or a wider value to add WebFetch/etc. Ignored when ``governance``
            is False.
        isolation: ``"profile"`` (default) or ``"project"``. When
            ``"project"``, hooks are forced to land in ./.claude/settings.json
            (regardless of ``global_config``) and the hook command is
            prefixed with ``WAXELL_PROJECT_KEY=<sha256(cwd)[:8]>`` so the
            handler partitions session state + LLM-call dedupe by project.
            Use this when two repos share the same profile but want
            independent daily runs / dedupe namespaces.

    Returns:
        dict with 'hooks_path', 'mcp_path' (if applicable), 'profile', 'summary'.
    """
    if isolation not in VALID_ISOLATIONS:
        raise ValueError(
            f"isolation must be one of {VALID_ISOLATIONS}, got {isolation!r}"
        )

    result: dict = {"summary": [], "profile": profile, "isolation": isolation}
    matcher = governance_matcher or DEFAULT_GOVERNANCE_MATCHER

    project_root = Path(project_dir) if project_dir else Path.cwd()
    project_key: Optional[str] = None
    if isolation == ISOLATION_PROJECT:
        project_key = project_key_for(project_root)
        # --isolation project forces project-local settings — global hooks
        # would defeat the entire point (two repos colliding on one profile).
        if global_config:
            logger.info(
                "isolation=project forces project-local settings; ignoring --global"
            )
        global_config = False
        result["project_key"] = project_key
        result["project_root"] = str(project_root)

    # C2 — fail fast on bad guard.json. Silently swallowing bad config at
    # hook time meant the user only discovered misconfigurations when a
    # blocked command unexpectedly ran. Validate at setup so install errors
    # immediately and the user can fix the config.
    from .guard import validate_config_file

    guard_errors: list[str] = []
    user_guard = Path.home() / ".waxell" / "guard.json"
    guard_errors.extend(validate_config_file(user_guard))

    project_guard = project_root / ".waxell" / "guard.json"
    guard_errors.extend(validate_config_file(project_guard))

    if guard_errors:
        raise ValueError(
            "guard.json validation failed:\n  - " + "\n  - ".join(guard_errors)
        )

    # Determine settings path
    if global_config:
        settings_path = Path.home() / ".claude" / "settings.json"
    else:
        settings_path = project_root / ".claude" / "settings.json"

    # Build hook configuration for this profile
    hooks_config = _build_hooks_config(
        profile, governance, matcher=matcher, project_key=project_key
    )

    # Merge with existing settings (idempotent)
    _merge_settings(settings_path, hooks_config, profile)
    result["hooks_path"] = str(settings_path)
    summary_suffix = f" (profile: {profile}"
    if project_key:
        summary_suffix += f", project_key: {project_key}"
    summary_suffix += ")"
    result["summary"].append(f"Hooks written to {settings_path}{summary_suffix}")

    if governance:
        result["summary"].append(
            f"Governance enabled: PreToolUse hooks will enforce policies on tools matching /{matcher}/"
        )

    if project_key:
        result["summary"].append(
            f"Isolation: project — hook handler will scope state under WAXELL_PROJECT_KEY={project_key}"
        )

    # MCP server registration
    if mcp:
        if global_config:
            mcp_path = Path.home() / ".claude" / ".mcp.json"
        else:
            mcp_path = project_root / ".mcp.json"

        _merge_mcp_config(mcp_path, profile)
        result["mcp_path"] = str(mcp_path)
        result["summary"].append(
            f"MCP server registered in {mcp_path} (as {_mcp_server_name(profile)})"
        )

    return result


def _build_hooks_config(
    profile: str,
    governance: bool,
    *,
    matcher: str = DEFAULT_GOVERNANCE_MATCHER,
    project_key: Optional[str] = None,
) -> dict:
    """Build the hooks configuration dict for a given profile.

    `matcher` is the regex applied to tool names for the PreToolUse
    governance hook (only used when ``governance`` is True).

    When ``project_key`` is provided (--isolation project), every hook
    command is prefixed with ``WAXELL_PROJECT_KEY=<key>`` so the hook
    handler partitions session state and the LLM-call dedupe file by
    project. Allows two repos sharing one Waxell profile to have
    independent daily run accumulators and dedupe namespaces.

    Hook-timeout SLO (C11 audit, 2026-05-02):

      Sync hooks (block CC until they return):
        - SessionStart:    10s — needs an acceptable cold-start budget; CC
                           can't show the prompt until this returns.
        - Stop:            10s — must finalize the run before CC exits.
        - SessionEnd:      30s — last-call flush; CC has already accepted
                           termination, so larger budget is fine.
        - StopFailure:     30s — same rationale as SessionEnd.
        - WorktreeCreate:  10s — blocks the worktree spawn UX.
        - WorktreeRemove:  10s — blocks worktree teardown UX.
        - PreToolUse:       5s — every tool call adds this to user-perceived
                           latency. Tight by design. C1 (PreToolUse fail-
                           open w/ tenant default) covers what happens when
                           the network is slower than this.

      Async hooks (CC continues immediately, hook runs in background):
        - PostToolUse / PostToolUseFailure: 10s
        - Subagent{Start,Stop} / TeammateIdle:                  10s
        - UserPromptSubmit / Notification:                       5s
        - TaskCreated / TaskCompleted / PermissionRequest /
          PermissionDenied / InstructionsLoaded / CwdChanged /
          ConfigChange / Pre/PostCompact / FileChanged /
          Elicitation / ElicitationResult:                       5s

      Anything <5s is too tight for cold-start network calls; anything
      >10s on a sync path costs interactive feel. 30s is reserved for
      hooks that fire on terminal lifecycle events (Session/Stop end).
    """
    hook_cmd = _hook_cmd(profile, project_key=project_key)
    # C8 — profile auto-detect runs FIRST on SessionStart. Reads
    # `<cwd>/.waxell-profile` and emits a JSON env-injection so the rest
    # of the hooks in this session pick up the right WAXELL_PROFILE.
    # Project-key prefix carried through so detect logs land in the right
    # project namespace too.
    profile_detect_cmd = _profile_detect_cmd(project_key=project_key)

    hooks: dict = {
        "SessionStart": [
            {
                "matcher": "startup",
                "hooks": [
                    {"type": "command", "command": profile_detect_cmd, "timeout": 5},
                    {"type": "command", "command": hook_cmd, "timeout": 10},
                ],
            },
            {
                "matcher": "resume",
                "hooks": [
                    {"type": "command", "command": profile_detect_cmd, "timeout": 5},
                    {"type": "command", "command": hook_cmd, "timeout": 10},
                ],
            },
        ],
        "PostToolUse": [
            {
                "matcher": ".*",
                "hooks": [
                    {
                        "type": "command",
                        "command": hook_cmd,
                        "timeout": 10,
                        "async": True,
                    }
                ],
            },
        ],
        "PostToolUseFailure": [
            {
                "matcher": ".*",
                "hooks": [
                    {
                        "type": "command",
                        "command": hook_cmd,
                        "timeout": 10,
                        "async": True,
                    }
                ],
            },
        ],
        "SubagentStart": [
            {
                "matcher": ".*",
                "hooks": [
                    {
                        "type": "command",
                        "command": hook_cmd,
                        "timeout": 10,
                        "async": True,
                    }
                ],
            },
        ],
        "SubagentStop": [
            {
                "matcher": ".*",
                "hooks": [{"type": "command", "command": hook_cmd, "timeout": 10}],
            },
        ],
        "TeammateIdle": [
            {
                "hooks": [
                    {
                        "type": "command",
                        "command": hook_cmd,
                        "timeout": 10,
                        "async": True,
                    }
                ],
            },
        ],
        "Stop": [
            {
                "hooks": [{"type": "command", "command": hook_cmd, "timeout": 30}],
            },
        ],
        "StopFailure": [
            {
                "hooks": [
                    {
                        "type": "command",
                        "command": hook_cmd,
                        "timeout": 10,
                        "async": True,
                    }
                ],
            },
        ],
        "SessionEnd": [
            {
                "hooks": [{"type": "command", "command": hook_cmd, "timeout": 30}],
            },
        ],
        # Prompt + narrative visibility
        "UserPromptSubmit": [
            {
                "hooks": [
                    {
                        "type": "command",
                        "command": hook_cmd,
                        "timeout": 5,
                        "async": True,
                    }
                ],
            },
        ],
        "Notification": [
            {
                "hooks": [
                    {
                        "type": "command",
                        "command": hook_cmd,
                        "timeout": 5,
                        "async": True,
                    }
                ],
            },
        ],
        # Task lifecycle (complements Subagent* for TaskCreate-spawned agents)
        "TaskCreated": [
            {
                "hooks": [
                    {
                        "type": "command",
                        "command": hook_cmd,
                        "timeout": 5,
                        "async": True,
                    }
                ],
            },
        ],
        "TaskCompleted": [
            {
                "hooks": [
                    {
                        "type": "command",
                        "command": hook_cmd,
                        "timeout": 5,
                        "async": True,
                    }
                ],
            },
        ],
        # Permission / governance signals (PreToolUse is governance-configured below)
        "PermissionRequest": [
            {
                "hooks": [
                    {
                        "type": "command",
                        "command": hook_cmd,
                        "timeout": 5,
                        "async": True,
                    }
                ],
            },
        ],
        "PermissionDenied": [
            {
                "hooks": [
                    {
                        "type": "command",
                        "command": hook_cmd,
                        "timeout": 5,
                        "async": True,
                    }
                ],
            },
        ],
        # Context + environment
        "InstructionsLoaded": [
            {
                "hooks": [
                    {
                        "type": "command",
                        "command": hook_cmd,
                        "timeout": 5,
                        "async": True,
                    }
                ],
            },
        ],
        "CwdChanged": [
            {
                "hooks": [
                    {
                        "type": "command",
                        "command": hook_cmd,
                        "timeout": 5,
                        "async": True,
                    }
                ],
            },
        ],
        "ConfigChange": [
            {
                "hooks": [
                    {
                        "type": "command",
                        "command": hook_cmd,
                        "timeout": 5,
                        "async": True,
                    }
                ],
            },
        ],
        "PreCompact": [
            {
                "hooks": [
                    {
                        "type": "command",
                        "command": hook_cmd,
                        "timeout": 5,
                        "async": True,
                    }
                ],
            },
        ],
        "PostCompact": [
            {
                "hooks": [
                    {
                        "type": "command",
                        "command": hook_cmd,
                        "timeout": 5,
                        "async": True,
                    }
                ],
            },
        ],
        # Worktree lifecycle (for --worktree and isolation: "worktree")
        "WorktreeCreate": [
            {
                "hooks": [{"type": "command", "command": hook_cmd, "timeout": 10}],
            },
        ],
        "WorktreeRemove": [
            {
                "hooks": [{"type": "command", "command": hook_cmd, "timeout": 10}],
            },
        ],
        # MCP elicitation
        "Elicitation": [
            {
                "hooks": [
                    {
                        "type": "command",
                        "command": hook_cmd,
                        "timeout": 5,
                        "async": True,
                    }
                ],
            },
        ],
        "ElicitationResult": [
            {
                "hooks": [
                    {
                        "type": "command",
                        "command": hook_cmd,
                        "timeout": 5,
                        "async": True,
                    }
                ],
            },
        ],
    }

    if governance:
        hooks["PreToolUse"] = [
            {
                "matcher": matcher,
                "hooks": [{"type": "command", "command": hook_cmd, "timeout": 5}],
            },
        ]

    return hooks


def _merge_settings(path: Path, hooks_config: dict, profile: str) -> None:
    """Merge hook config into existing settings.json.

    Strategy:
      1. Parse existing settings.
      2. Remove all entries belonging to THIS profile + any legacy entries.
      3. Add fresh entries for THIS profile.
      4. Leave entries from OTHER profiles (claude-cowork, cursor, etc.) untouched.
      5. Leave non-waxell hooks (GSD, user-defined) untouched.

    This makes setup idempotent and composable.
    """
    path.parent.mkdir(parents=True, exist_ok=True)

    existing: dict = {}
    if path.exists():
        try:
            existing = json.loads(path.read_text())
        except (json.JSONDecodeError, IOError):
            existing = {}

    existing_hooks = existing.get("hooks", {})
    fp = _hook_fingerprint(profile)

    def _is_stale_for_this_profile(entry: dict) -> bool:
        """Remove only this-profile entries and legacy waxell entries.

        Also strips any standalone profile-detect SessionStart shims —
        the new config re-emits them paired with the profile's hook, so
        leaving an old detect entry would create a duplicate.
        """
        for h in entry.get("hooks", []):
            cmd = h.get("command", "")
            if fp in cmd:
                return True
            # C8 profile-detect shim (carries no --profile, gets re-emitted)
            if "wax claude-code profile-detect" in cmd:
                return True
            # Drop legacy (profile-less) commands
            for legacy in _LEGACY_FINGERPRINTS:
                if legacy in cmd and "--profile" not in cmd:
                    return True
        return False

    for event_name, event_hooks in hooks_config.items():
        if event_name not in existing_hooks:
            existing_hooks[event_name] = event_hooks
            continue

        existing_list = existing_hooks[event_name]
        kept = [e for e in existing_list if not _is_stale_for_this_profile(e)]
        existing_hooks[event_name] = kept + event_hooks

    existing["hooks"] = existing_hooks
    path.write_text(json.dumps(existing, indent=2) + "\n")


def _merge_mcp_config(path: Path, profile: str) -> None:
    """Register the Waxell MCP server in .mcp.json for this profile."""
    path.parent.mkdir(parents=True, exist_ok=True)

    existing: dict = {}
    if path.exists():
        try:
            existing = json.loads(path.read_text())
        except (json.JSONDecodeError, IOError):
            existing = {}

    servers = existing.get("mcpServers", {})

    # Drop the generic legacy name if present (from old installs)
    if "waxell-observe" in servers:
        # Only drop if it looks like a legacy waxell entry (has no --profile)
        legacy = servers["waxell-observe"]
        args = legacy.get("args", [])
        if "--profile" not in args:
            del servers["waxell-observe"]

    servers[_mcp_server_name(profile)] = {
        "type": "stdio",
        "command": "wax",
        "args": ["--profile", profile, "claude-code", "mcp-server"],
    }
    existing["mcpServers"] = servers
    path.write_text(json.dumps(existing, indent=2) + "\n")


# =============================================================================
# REMOVE
# =============================================================================


def remove_hooks(
    project_dir: Optional[str] = None,
    global_config: bool = False,
    profile: str = DEFAULT_PROFILE,
    remove_mcp: bool = True,
    remove_profile_from_config: bool = False,
) -> dict:
    """Remove Waxell hooks + MCP registration for a specific profile.

    Leaves other profiles and non-waxell hooks untouched. Does NOT remove
    the profile from ~/.waxell/config unless explicitly asked
    (remove_profile_from_config=True).
    """
    result: dict = {"summary": [], "profile": profile}

    if global_config:
        settings_path = Path.home() / ".claude" / "settings.json"
        mcp_path = Path.home() / ".claude" / ".mcp.json"
    else:
        base = Path(project_dir) if project_dir else Path.cwd()
        settings_path = base / ".claude" / "settings.json"
        mcp_path = base / ".mcp.json"

    # 1. Strip hooks for this profile from settings.json
    if settings_path.exists():
        try:
            settings = json.loads(settings_path.read_text())
        except (json.JSONDecodeError, IOError):
            settings = {}

        hooks = settings.get("hooks", {})
        fp = _hook_fingerprint(profile)
        stripped_count = 0

        def _is_this_profile(entry: dict) -> bool:
            """Match profile-specific hooks plus the shared profile-detect
            shim — if we're removing the only Waxell profile, the detect
            shim has nothing to dispatch to and should go too. (If other
            profiles remain, the next setup re-emits it.)"""
            for h in entry.get("hooks", []):
                cmd = h.get("command", "")
                if fp in cmd:
                    return True
                if "wax claude-code profile-detect" in cmd:
                    return True
            return False

        for event, entries in list(hooks.items()):
            kept = [e for e in entries if not _is_this_profile(e)]
            stripped = len(entries) - len(kept)
            stripped_count += stripped
            if kept:
                hooks[event] = kept
            else:
                del hooks[event]

        settings["hooks"] = hooks
        settings_path.write_text(json.dumps(settings, indent=2) + "\n")
        result["summary"].append(
            f"Removed {stripped_count} hook entrie(s) for profile '{profile}' from {settings_path}"
        )

    # 2. Remove MCP server entry for this profile
    if remove_mcp and mcp_path.exists():
        try:
            mcp_cfg = json.loads(mcp_path.read_text())
        except (json.JSONDecodeError, IOError):
            mcp_cfg = {}

        servers = mcp_cfg.get("mcpServers", {})
        server_name = _mcp_server_name(profile)
        removed = False
        if server_name in servers:
            del servers[server_name]
            removed = True

        mcp_cfg["mcpServers"] = servers
        mcp_path.write_text(json.dumps(mcp_cfg, indent=2) + "\n")
        if removed:
            result["summary"].append(
                f"Removed MCP server '{server_name}' from {mcp_path}"
            )

    # 3. Optionally remove the profile section from ~/.waxell/config
    if remove_profile_from_config:
        config_path = Path.home() / ".waxell" / "config"
        if config_path.exists():
            _remove_config_profile(config_path, profile)
            result["summary"].append(f"Removed [{profile}] profile from {config_path}")

    return result


def _remove_config_profile(path: Path, profile: str) -> None:
    """Remove a single profile section from a Waxell INI config."""
    text = path.read_text()
    lines = text.splitlines()
    output = []
    skipping = False
    found = False
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("[") and stripped.endswith("]"):
            section = stripped[1:-1]
            if section == profile:
                skipping = True
                found = True
                continue
            else:
                skipping = False
                output.append(line)
        elif not skipping:
            output.append(line)

    if found:
        # Trim trailing blanks
        while output and not output[-1].strip():
            output.pop()
        path.write_text("\n".join(output) + "\n")


# =============================================================================
# STATUS / DETECTION
# =============================================================================


def detect_status(
    project_dir: Optional[str] = None,
    global_config: bool = True,
) -> dict:
    """Detect current installation state: binary, config profiles, hooks, MCP.

    Used by the installer GUI to render current state and decide what to
    configure / reconfigure / leave alone.

    C12 — top-level keys the installer's "current state" detector needs:
        governance_enabled         — PreToolUse hook is wired in
        governance_matcher         — the regex applied to tool names
        profile                    — Waxell config profile in use
        guard_config_source        — "remote" | "file" | "builtin"
        last_successful_policy_fetch  — ISO timestamp from the policy
                                       poller / remote-config cache
        dedupe_state_path          — where Claude Code session state lives
        hardware_uuid              — stable per-device identifier (Phase 1.5)
    """
    cc = _detect_claude_code(project_dir, global_config)
    status: dict = {
        "binary": _detect_binary(),
        "config": _detect_config(),
        "claude_code": cc,
        # C12 top-level summary fields. The installer GUI / external
        # tooling reads these by exact key — keep the names stable.
        "governance_enabled": cc.get("governance_enabled", False),
        "governance_matcher": cc.get("governance_matcher", ""),
        "profile": _resolve_active_profile(cc),
        "guard_config_source": _detect_guard_config_source(),
        "last_successful_policy_fetch": _detect_last_policy_fetch(),
        "dedupe_state_path": _detect_dedupe_state_path(),
        "hardware_uuid": _detect_hardware_uuid(),
    }
    return status


# ---------------------------------------------------------------------------
# C12 helpers — derive top-level summary fields from the existing detection
# building blocks. Kept defensive (return empty strings on any failure) so
# `wax claude-code install-status --json` always emits a parseable shape.
# ---------------------------------------------------------------------------


def _resolve_active_profile(cc: dict) -> str:
    """Pick the most likely profile in use.

    Preference order:
      1. The first profile that has hooks installed (governance is wired)
      2. The first profile that has an MCP server configured
      3. DEFAULT_PROFILE as a last resort
    """
    hooks_profiles = cc.get("hooks_profiles") or []
    if hooks_profiles:
        return hooks_profiles[0]
    mcp_profiles = list((cc.get("mcp_profiles") or {}).keys())
    if mcp_profiles:
        return mcp_profiles[0]
    return DEFAULT_PROFILE


def _detect_guard_config_source() -> str:
    """Where the active GuardConfig is coming from right now.

    Mirrors the precedence chain in `guard.load_config()`:
        builtin defaults
        < remote (controlplane-managed config; B5/B6)
        < file (~/.waxell/guard.json or ./.waxell/guard.json)

    We report the highest layer with on-disk evidence. File overlays win
    because the loader applies them last.
    """
    cwd_guard = Path.cwd() / ".waxell" / "guard.json"
    home_guard = Path.home() / ".waxell" / "guard.json"
    if cwd_guard.exists() or home_guard.exists():
        return "file"
    # Remote layer's evidence is the network-monitor poller's policy.json
    # OR the direct-fetch cache; either means the remote config is active.
    policy_file = Path.home() / ".waxell" / "policy.json"
    cache_file = Path.home() / ".waxell" / "guard-config-cache.json"
    if policy_file.exists() or cache_file.exists():
        return "remote"
    return "builtin"


def _detect_last_policy_fetch() -> str:
    """ISO timestamp of the most recent successful policy fetch.

    The poller writes `~/.waxell/policy.json` and the direct-fetch path
    writes `~/.waxell/guard-config-cache.json` (with a `fetched_at`
    field). Either is fine — we surface the freshest one.
    """
    candidates: list[str] = []

    cache_file = Path.home() / ".waxell" / "guard-config-cache.json"
    if cache_file.exists():
        try:
            payload = json.loads(cache_file.read_text())
            ts = payload.get("fetched_at")
            if isinstance(ts, str) and ts:
                candidates.append(ts)
        except (json.JSONDecodeError, IOError, OSError):
            pass

    policy_file = Path.home() / ".waxell" / "policy.json"
    if policy_file.exists():
        try:
            payload = json.loads(policy_file.read_text())
            ts = payload.get("fetched_at")
            if isinstance(ts, str) and ts:
                candidates.append(ts)
            else:
                from datetime import datetime, timezone

                mtime = policy_file.stat().st_mtime
                candidates.append(
                    datetime.fromtimestamp(mtime, tz=timezone.utc).isoformat()
                )
        except (json.JSONDecodeError, IOError, OSError):
            pass

    if not candidates:
        return ""
    # Return the lexicographically largest ISO-8601 string — for UTC ISO
    # timestamps that's also the chronologically most recent.
    return max(candidates)


def _detect_dedupe_state_path() -> str:
    """Where Claude Code session state (incl. dedupe markers) is stored."""
    from .state import STATE_DIR

    return str(STATE_DIR)


def _detect_hardware_uuid() -> str:
    """Stable per-device identifier (Phase 1.5 / Task #8).

    Failure-mode is empty string — installer detection must never crash
    because hardware probing failed.
    """
    try:
        from waxell_observe.platform import get_hardware_uuid

        return get_hardware_uuid() or ""
    except Exception:  # pragma: no cover - defensive
        logger.debug("hardware_uuid lookup failed", exc_info=True)
        return ""


def _detect_binary() -> dict:
    """Find the `wax` binary and its version."""
    # Prefer /usr/local/bin/wax (typical install location)
    candidates = [
        "/usr/local/bin/wax",
        "/opt/homebrew/bin/wax",
        shutil.which("wax"),
    ]
    seen = set()
    path = None
    for c in candidates:
        if c and c not in seen and os.path.exists(c):
            path = c
            break
        if c:
            seen.add(c)

    if not path:
        return {"installed": False, "path": None, "version": None}

    # Get version. Skip the subprocess (which triggers a second PyInstaller
    # cold-start, ~3-5s) when the caller sets WAX_SKIP_VERSION_CHECK=1.
    # In that case, return our OWN version — we're the one running, and for
    # the installer-GUI use case, our version is what matters (installer's
    # bundled binary will either match or replace what's installed).
    version = None
    if os.environ.get("WAX_SKIP_VERSION_CHECK"):
        try:
            from waxell_observe.__about__ import __version__

            version = __version__
        except ImportError:
            pass
    else:
        try:
            result = subprocess.run(
                [path, "--version"], capture_output=True, text=True, timeout=15
            )
            out = (result.stdout or "").strip()
            if "version" in out.lower():
                version = out.split()[-1]
        except (subprocess.SubprocessError, FileNotFoundError):
            pass

    return {"installed": True, "path": path, "version": version}


def _detect_config() -> dict:
    """Parse ~/.waxell/config and return known profiles."""
    config_path = Path.home() / ".waxell" / "config"
    if not config_path.exists():
        return {"path": str(config_path), "exists": False, "profiles": {}}

    profiles: dict = {}
    current_section = None
    try:
        text = config_path.read_text()
    except IOError:
        return {
            "path": str(config_path),
            "exists": True,
            "profiles": {},
            "error": "read_failed",
        }

    for line in text.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or stripped.startswith(";"):
            continue
        if stripped.startswith("[") and stripped.endswith("]"):
            current_section = stripped[1:-1]
            profiles[current_section] = {"has_api_key": False, "api_url": None}
            continue
        if current_section is None:
            continue
        if "=" in stripped:
            key, _, value = stripped.partition("=")
            key = key.strip()
            value = value.strip()
            if key == "api_key" and value:
                profiles[current_section]["has_api_key"] = True
            elif key == "api_url":
                profiles[current_section]["api_url"] = value

    return {"path": str(config_path), "exists": True, "profiles": profiles}


def _detect_claude_code(
    project_dir: Optional[str],
    global_config: bool,
) -> dict:
    """Scan Claude Code settings + MCP config for configured waxell profiles."""
    if global_config:
        settings_path = Path.home() / ".claude" / "settings.json"
        mcp_path = Path.home() / ".claude" / ".mcp.json"
    else:
        base = Path(project_dir) if project_dir else Path.cwd()
        settings_path = base / ".claude" / "settings.json"
        mcp_path = base / ".mcp.json"

    # Parse hooks to find configured profiles
    profiles_with_hooks: set[str] = set()
    legacy_hooks_present = False
    # C12 — governance_enabled tracks whether ANY waxell PreToolUse hook
    # is registered. governance_matcher captures the regex (the C3
    # matcher) so the installer can show "policies fire on /Bash|Edit/" etc.
    governance_enabled = False
    governance_matcher = ""

    settings_exists = settings_path.exists()
    if settings_exists:
        try:
            settings = json.loads(settings_path.read_text())
        except (json.JSONDecodeError, IOError):
            settings = {}
        for event, event_hooks in settings.get("hooks", {}).items():
            for entry in event_hooks:
                for h in entry.get("hooks", []):
                    cmd = h.get("command", "")
                    is_waxell = False
                    if "--profile" in cmd and "claude-code" in cmd:
                        # Extract the profile name
                        parts = cmd.split()
                        if "--profile" in parts:
                            idx = parts.index("--profile")
                            if idx + 1 < len(parts):
                                profiles_with_hooks.add(parts[idx + 1])
                        is_waxell = True
                    elif any(legacy in cmd for legacy in _LEGACY_FINGERPRINTS):
                        legacy_hooks_present = True
                        is_waxell = True

                    # PreToolUse hook on a waxell command = governance is on.
                    # Capture the matcher regex from the entry so the
                    # installer can display it. Multiple PreToolUse entries
                    # are unusual but we keep the first one we see.
                    if is_waxell and event == "PreToolUse" and not governance_matcher:
                        governance_enabled = True
                        governance_matcher = entry.get("matcher", "") or ""

    # Parse MCP servers
    mcp_servers_by_profile: dict = {}
    mcp_legacy = False
    mcp_exists = mcp_path.exists()
    if mcp_exists:
        try:
            mcp_cfg = json.loads(mcp_path.read_text())
        except (json.JSONDecodeError, IOError):
            mcp_cfg = {}
        for server_name, server in mcp_cfg.get("mcpServers", {}).items():
            args = server.get("args") or []
            if "--profile" in args:
                idx = args.index("--profile")
                if idx + 1 < len(args):
                    mcp_servers_by_profile[args[idx + 1]] = server_name
            elif server_name == "waxell-observe":
                mcp_legacy = True

    return {
        "settings_path": str(settings_path),
        "settings_exists": settings_exists,
        "mcp_path": str(mcp_path),
        "mcp_exists": mcp_exists,
        "hooks_profiles": sorted(profiles_with_hooks),
        "mcp_profiles": mcp_servers_by_profile,
        "legacy_hooks_present": legacy_hooks_present,
        "legacy_mcp_present": mcp_legacy,
    }
