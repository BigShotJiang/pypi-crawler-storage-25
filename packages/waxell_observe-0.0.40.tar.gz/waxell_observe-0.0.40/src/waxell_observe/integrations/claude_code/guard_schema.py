"""Canonical schema + defaults for the Claude Code local guard.

Phase 1 of GUARD_CONFIG_UNIFICATION (see
`agentforge/areas/connect/plans/GUARD_CONFIG_UNIFICATION.md`).

Why this module exists
----------------------
Today the SDK's `GuardConfig` dataclass, the cloud editor's
hardcoded field list, and the Mac extension's policy.json schema
are three drifting copies of "what is a guard config." This
module declares one canonical contract:

- Every field the SDK supports
- Their builtin defaults (factual: what the guard enforces if no
  override exists at any layer)
- Type, description, and category metadata so the cloud editor
  can introspect and render every field automatically
- A `to_json_schema()` export so the cloud can fetch it once and
  generate the editor UI

Implementation note: this is plain `dataclasses` + a hand-rolled
JSON Schema builder. waxell-observe is intentionally a lean SDK
without pydantic in its runtime dep set. The output of
`to_json_schema()` is a normal JSON Schema dict — interoperable
with any JSON-Schema-aware tool.

The legacy `GuardConfig` dataclass and the `_DEFAULT_*` constants
in `guard.py` continue to exist — they're the runtime contract for
the hot-path enforcer. This module mirrors those values; phase 2
of the plan swaps the dataclass for this schema and deletes the
duplication.

Public API
----------
- `GuardConfigSchema` — the canonical dataclass
- `GUARD_CONFIG_DEFAULTS` — `dict` snapshot of every field's default
- `to_json_schema()` — JSON-Schema dict for the cloud editor
- `field_categories()` — `{category: [field_names...]}` for grouping
"""

from __future__ import annotations

from dataclasses import MISSING, dataclass, field, fields
from typing import Any

# ---------------------------------------------------------------------------
# Default values — copy of the lists in `guard.py`. Until phase 2
# collapses the duplication, the test in `tests/test_guard_schema.py`
# (added with this commit) asserts these match what `guard.py` exports.
# ---------------------------------------------------------------------------

_DEFAULT_BLOCKED_COMMANDS: list[str] = [
    r"rm\s+(-[a-zA-Z]*f[a-zA-Z]*\s+(-[a-zA-Z]*r|--recursive)|(-[a-zA-Z]*r[a-zA-Z]*\s+(-[a-zA-Z]*f|--force))|--force\s+--recursive|--recursive\s+--force)\s+(/\s|/\s*$|~/|~\s|/\s*\*|\$HOME)",
    r"rm\s+-rf\s+/\s*$",
    r"rm\s+-rf\s+~/",
    r"rm\s+-rf\s+\$HOME",
    r"rm\s+-rf\s+\.\s*$",
    r"\bmkfs\b",
    r"\bdd\s+if=",
    r">\s*/dev/sd",
    r":\(\)\{\s*:\|:\s*&\s*\}\s*;",
    r"\bshutdown\b",
    r"\breboot\b",
    r"\bhalt\b",
    r"\binit\s+0\b",
    r"chmod\s+(-R\s+)?777\s+/",
    r"curl\s+[^|]*\|\s*(ba)?sh",
    r"wget\s+[^|]*\|\s*(ba)?sh",
    r"curl\s+[^|]*\|\s*sudo\s+(ba)?sh",
]

_DEFAULT_WARN_COMMANDS: list[str] = [
    r"rm\s+-rf\b",
    r"rm\s+-r\s+-f\b",
    r"rm\s+-fr\b",
    r"kill\s+-9\b",
    r"pkill\s+-9\b",
    r"killall\b",
    r"docker\s+system\s+prune",
    r"docker\s+rm\s+-f",
    r"docker\s+rmi\s+-f",
    r"DROP\s+(TABLE|DATABASE|SCHEMA)\b",
    r"TRUNCATE\s+TABLE\b",
    r"DELETE\s+FROM\s+\w+\s*;?\s*$",
]

_DEFAULT_PROTECTED_FILES: list[str] = [
    ".env",
    ".env.*",
    ".env.local",
    ".env.production",
    ".env.staging",
    "**/credentials*",
    "**/secrets.yml",
    "**/secrets.yaml",
    "**/secrets.json",
    "**/*.pem",
    "**/*.key",
    "**/id_rsa",
    "**/id_rsa.pub",
    "**/id_ed25519",
    "**/id_ed25519.pub",
    "**/.ssh/authorized_keys",
    "**/.ssh/known_hosts",
    "**/.aws/credentials",
    "**/.aws/config",
    "**/.config/gcloud/*",
    ".git/config",
    "**/.netrc",
    "**/.npmrc",
    "**/.pypirc",
]

_DEFAULT_WARN_FILES: list[str] = [
    "*.lock",
    "*lock.json",
    "*lock.yaml",
    ".gitignore",
    ".dockerignore",
]

_DEFAULT_PROTECTED_BRANCHES: list[str] = [
    "main",
    "master",
    "develop",
    "release/*",
    "production",
]

_DEFAULT_INFRA_FILES: list[str] = [
    "Dockerfile",
    "Dockerfile.*",
    "docker-compose*.yml",
    "docker-compose*.yaml",
    ".github/**",
    ".gitlab-ci.yml",
    ".gitlab-ci/**",
    "Jenkinsfile",
    ".circleci/**",
    "**/*.tf",
    "**/terraform/**",
    "**/k8s/**",
    "**/kubernetes/**",
    "**/helm/**",
    "Makefile",
    "justfile",
    "Procfile",
    ".buildpacks",
    "fly.toml",
    "render.yaml",
    "vercel.json",
    "netlify.toml",
]

# ---------------------------------------------------------------------------
# Schema dataclass — declarative metadata via `field(metadata=...)`.
#
# `metadata={"category": ..., "description": ...}` is surfaced verbatim
# by `to_json_schema()`. The cloud editor reads `category` for section
# headers and `description` for input helper text.
# ---------------------------------------------------------------------------


@dataclass
class GuardConfigSchema:
    """Canonical schema for the Claude Code local guard."""

    # --- Destructive command blocking ---
    blocked_command_patterns: list[str] = field(
        default_factory=lambda: list(_DEFAULT_BLOCKED_COMMANDS),
        metadata={
            "category": "Commands",
            "description": (
                "Regex patterns for shell commands that are blocked outright. "
                "Each pattern is `re.search`-matched against the candidate "
                "command. Replacing this list (e.g. with `[]`) disables all "
                "command-level blocking."
            ),
        },
    )
    warn_command_patterns: list[str] = field(
        default_factory=lambda: list(_DEFAULT_WARN_COMMANDS),
        metadata={
            "category": "Commands",
            "description": (
                "Regex patterns that produce a warning rather than a block. "
                "Hooks surface this as `ask` so the user can confirm."
            ),
        },
    )

    # --- File protection ---
    protected_file_patterns: list[str] = field(
        default_factory=lambda: list(_DEFAULT_PROTECTED_FILES),
        metadata={
            "category": "Files",
            "description": (
                "Glob patterns for files the guard refuses to write. "
                "Matched against the relative path from the project root."
            ),
        },
    )
    warn_file_patterns: list[str] = field(
        default_factory=lambda: list(_DEFAULT_WARN_FILES),
        metadata={
            "category": "Files",
            "description": "Glob patterns that produce a warning on write.",
        },
    )
    path_boundary_enabled: bool = field(
        default=False,
        metadata={
            "category": "Files",
            "description": (
                "Refuse writes to files outside the current project "
                "directory. Default off — legitimate cross-project edits "
                "happen all the time and the strict boundary blocks them "
                "with no opt-out."
            ),
        },
    )

    # --- Git safety ---
    git_protected_branches: list[str] = field(
        default_factory=lambda: list(_DEFAULT_PROTECTED_BRANCHES),
        metadata={
            "category": "Git",
            "description": (
                "Branch globs that get extra protection (force-push, "
                "hard-reset, config-edit)."
            ),
        },
    )
    git_block_force_push: bool = field(
        default=True,
        metadata={
            "category": "Git",
            "description": "Block `git push --force` on protected branches.",
        },
    )
    git_block_hard_reset: bool = field(
        default=True,
        metadata={
            "category": "Git",
            "description": "Block `git reset --hard` on protected branches.",
        },
    )
    git_block_config_edit: bool = field(
        default=True,
        metadata={
            "category": "Git",
            "description": "Block writes to `.git/config`.",
        },
    )

    # --- Network access ---
    blocked_domains: list[str] = field(
        default_factory=list,
        metadata={
            "category": "Network",
            "description": (
                "Domains/URL substrings to refuse outbound network access to."
            ),
        },
    )
    block_internal_urls: bool = field(
        default=True,
        metadata={
            "category": "Network",
            "description": (
                "Block requests to localhost / RFC1918 / link-local / "
                "cloud metadata endpoints. Defaults on; turn off only "
                "with strong reason (e.g. a tenant whose agents "
                "legitimately hit private internal services)."
            ),
        },
    )

    # --- Session scope ---
    max_file_changes: int = field(
        default=50,
        metadata={
            "category": "Session",
            "description": (
                "Hard cap on file changes per session. Above this, "
                "the guard refuses further writes."
            ),
        },
    )
    warn_file_changes: int = field(
        default=20,
        metadata={
            "category": "Session",
            "description": "Soft threshold — surface a warning once exceeded.",
        },
    )

    # --- Cowork ---
    detect_file_conflicts: bool = field(
        default=True,
        metadata={
            "category": "Cowork",
            "description": (
                "Surface conflicts when the agent edits files another "
                "tool changed since the last read."
            ),
        },
    )

    # --- CI/CD protection ---
    infra_file_patterns: list[str] = field(
        default_factory=lambda: list(_DEFAULT_INFRA_FILES),
        metadata={
            "category": "Infrastructure",
            "description": (
                "Glob patterns for CI/CD and infrastructure files. "
                "Writes are guarded with extra confirmation. NOTE: "
                "`**/*.tf` is in this list, which is why every "
                "Terraform-or-similar edit triggers an "
                "`infrastructure file` confirmation."
            ),
        },
    )


# ---------------------------------------------------------------------------
# Convenience exports
# ---------------------------------------------------------------------------


def _to_json_type(py_type: Any) -> dict[str, Any]:
    """Best-effort Python annotation → JSON Schema type fragment.

    Limited to the small set of types `GuardConfigSchema` actually
    uses (bool, int, list[str]). Under `from __future__ import
    annotations`, dataclass `f.type` comes back as a string ("bool",
    "list[str]") rather than the resolved class — so we match on
    string form too.

    Order matters: check `bool` before `int` because Python's
    `isinstance(True, int)` is True; the string forms also distinct.
    """
    s = py_type if isinstance(py_type, str) else str(py_type)
    if py_type is bool or s == "bool":
        return {"type": "boolean"}
    if py_type is int or s == "int":
        return {"type": "integer"}
    if py_type is str or s == "str":
        return {"type": "string"}
    if "list[str]" in s or s == "list":
        return {"type": "array", "items": {"type": "string"}}
    return {"type": "string"}  # safe-ish fallback


def to_json_schema() -> dict[str, Any]:
    """Return a JSON-Schema-shaped dict the cloud editor can consume.

    Each property has `type`, `description`, and `default`.
    Non-standard `x-category` tags the section the field belongs in
    (the cloud editor's grouping affordance reads this).
    """
    properties: dict[str, Any] = {}
    for f in fields(GuardConfigSchema):
        prop: dict[str, Any] = _to_json_type(f.type)
        meta = f.metadata or {}
        if "description" in meta:
            prop["description"] = meta["description"]
        if "category" in meta:
            prop["x-category"] = meta["category"]
        # Default surfaces as JSON Schema `default`. For dataclasses,
        # `f.default` is `MISSING` when default_factory is used; call
        # the factory to materialize the default value.
        if f.default_factory is not MISSING:
            try:
                prop["default"] = f.default_factory()
            except Exception:
                pass
        elif f.default is not MISSING:
            prop["default"] = f.default
        properties[f.name] = prop

    return {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "title": "GuardConfig",
        "description": (
            "Canonical schema for the Claude Code local guard. "
            "Generated by waxell_observe.integrations.claude_code.guard_schema."
        ),
        "type": "object",
        "additionalProperties": False,
        "properties": properties,
    }


def field_categories() -> dict[str, list[str]]:
    """Return `{category: [field_names...]}` so the editor can group
    fields under section headers without re-deriving from the schema.
    """
    by_cat: dict[str, list[str]] = {}
    for f in fields(GuardConfigSchema):
        cat = (f.metadata or {}).get("category", "Other")
        by_cat.setdefault(cat, []).append(f.name)
    return by_cat


# Snapshot of every field's builtin default. Stable, comparable —
# useful for the cloud editor's "default if no override" hint and
# for unit tests that want to assert the defaults haven't drifted.
def _default_value(f) -> Any:
    if f.default_factory is not MISSING:
        return f.default_factory()  # type: ignore[misc]
    return f.default


GUARD_CONFIG_DEFAULTS: dict[str, Any] = {
    f.name: _default_value(f) for f in fields(GuardConfigSchema)
}
