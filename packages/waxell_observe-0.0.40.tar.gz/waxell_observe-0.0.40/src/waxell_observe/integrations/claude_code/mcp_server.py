"""MCP server for Claude Code governance integration.

Provides 3 tools that Claude Code can call proactively:
1. waxell_check_policy — Check if an action is allowed by policies
2. waxell_budget_status — Query remaining session budget
3. waxell_record_decision — Record a decision/reasoning span

Runs as a stdio MCP server registered in .mcp.json.

Wire format + dispatch loop comes from `_mcp_shared.run_stdio_loop` —
the same plumbing the Cowork MCP shim uses, including C6's bounded write
timeout and ping keep-alive.
"""

import json
import logging
from datetime import datetime, timezone
from typing import Any

from ...client import WaxellObserveClient
from .._mcp_shared import run_stdio_loop
from .state import load_state

logger = logging.getLogger(__name__)

# Server identity returned in MCP `initialize` responses.
SERVER_NAME = "waxell-observe"

try:
    from ...__about__ import __version__ as SERVER_VERSION
except ImportError:
    SERVER_VERSION = "0.1.0"


# ---------------------------------------------------------------------------
# Tool descriptors (MCP `tools/list` payload)
# ---------------------------------------------------------------------------

TOOLS: list[dict] = [
    {
        "name": "waxell_check_policy",
        "description": (
            "Check if an action is allowed by Waxell governance policies. "
            "Call this before attempting potentially restricted operations "
            "like deleting files, running destructive commands, or accessing sensitive data."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "description": "The action to check (e.g., 'bash:rm -rf', 'edit:config.py', 'write:secrets.env')",
                },
                "resource": {
                    "type": "string",
                    "description": "The resource being acted on (e.g., file path, command)",
                },
            },
            "required": ["action"],
        },
    },
    {
        "name": "waxell_budget_status",
        "description": (
            "Check the remaining token/cost budget for this Claude Code session. "
            "Returns how much has been spent and the limit if one is configured."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "waxell_record_decision",
        "description": (
            "Record an important decision or reasoning step for the audit trail. "
            "Use this when making architectural choices, selecting between approaches, "
            "or explaining why a particular implementation was chosen."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "name": {
                    "type": "string",
                    "description": "Decision name (e.g., 'architecture_choice', 'library_selection')",
                },
                "options": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Options that were considered",
                },
                "chosen": {
                    "type": "string",
                    "description": "The option that was selected",
                },
                "reasoning": {
                    "type": "string",
                    "description": "Why this option was chosen",
                },
            },
            "required": ["name", "chosen"],
        },
    },
]


# ---------------------------------------------------------------------------
# Tool handlers
# ---------------------------------------------------------------------------


def _find_active_session() -> tuple[Any, Any]:
    """Find the active session state. Returns (state, client) or (None, None)."""
    from .state import STATE_DIR

    client = WaxellObserveClient()
    if not client.config.is_configured:
        return None, None

    # Find the most recently modified state file
    if not STATE_DIR.exists():
        return None, None

    state_files = sorted(
        STATE_DIR.glob("*.json"), key=lambda f: f.stat().st_mtime, reverse=True
    )
    for sf in state_files:
        session_id = sf.stem
        state = load_state(session_id)
        if state and state.run_id:
            return state, client

    return None, None


def _tool_check_policy(args: dict) -> dict:
    """Check if an action is allowed by policies."""
    action = args.get("action", "")
    # `resource` is part of the schema for the LLM's benefit but the
    # current controlplane policy-check endpoint scopes by workflow_name
    # alone — drop it on the floor for now and revisit when scope rules
    # accept resource hints.

    client = WaxellObserveClient()
    if not client.config.is_configured:
        return {
            "allowed": True,
            "reason": "Waxell not configured — allowing by default",
        }

    try:
        result = client.check_policy_sync(
            agent_name="claude-code",
            workflow_name=f"mcp:{action}",
        )
        return {
            "allowed": result.action != "block",
            "action": result.action,
            "reason": result.reason or "No policy matched",
        }
    except Exception as e:
        return {
            "allowed": True,
            "reason": f"Policy check failed: {e} — allowing by default",
        }


def _tool_budget_status(args: dict) -> dict:
    """Query remaining budget for this session."""
    state, _client = _find_active_session()
    if not state:
        return {"status": "unknown", "reason": "No active session found"}

    return {
        "session_id": state.session_id,
        "run_id": state.run_id,
        "spans_recorded": state.span_count,
        "started_at": state.started_at,
        "is_cowork": state.is_cowork,
    }


def _tool_record_decision(args: dict) -> dict:
    """Record a decision span on the active session."""
    state, client = _find_active_session()
    if not state or not client:
        return {"recorded": False, "reason": "No active session found"}

    name = args.get("name", "decision")
    options = args.get("options", [])
    chosen = args.get("chosen", "")
    reasoning = args.get("reasoning", "")

    now = datetime.now(timezone.utc).isoformat()

    try:
        client.record_spans_sync(
            run_id=state.run_id,
            spans=[
                {
                    "name": name,
                    "kind": "decision",
                    "status": "ok",
                    "start_time": now,
                    "end_time": now,
                    "attributes": {
                        "decision.options": json.dumps(options),
                        "decision.chosen": chosen,
                        "decision.reasoning": reasoning,
                    },
                    "input_data": json.dumps({"options": options}),
                    "output_data": json.dumps(
                        {"chosen": chosen, "reasoning": reasoning}
                    ),
                }
            ],
        )
        return {"recorded": True, "decision": name, "chosen": chosen}
    except Exception as e:
        return {"recorded": False, "reason": str(e)}


# ---------------------------------------------------------------------------
# Public entrypoint
# ---------------------------------------------------------------------------


HANDLERS = {
    "waxell_check_policy": _tool_check_policy,
    "waxell_budget_status": _tool_budget_status,
    "waxell_record_decision": _tool_record_decision,
}


def run_mcp_server(stdin: Any = None, stdout: Any = None) -> None:
    """Run the MCP server (stdio transport).

    Reads JSON-RPC messages from stdin, writes responses to stdout. The
    transport (incl. C6's bounded write timeout + ping keep-alive) lives
    in `_mcp_shared.run_stdio_loop`. `stdin`/`stdout` are injectable so
    tests can drive the loop without spawning a subprocess.
    """
    run_stdio_loop(
        server_name=SERVER_NAME,
        server_version=SERVER_VERSION,
        tools=TOOLS,
        handlers=HANDLERS,
        stdin=stdin,
        stdout=stdout,
    )
