"""Local guard for Claude Code tool use — runs before server-side policy check.

Inspects tool inputs (bash commands, file paths, git operations, URLs) against
configurable patterns. Zero network overhead — all checks are local regex/glob
matching.

Configuration priority:
1. .waxell/guard.json in project root
2. ~/.waxell/guard.json (user global)
3. Built-in defaults

Actions:
- deny: block the tool call immediately
- ask: prompt the user for confirmation
- allow: let it through
"""

from __future__ import annotations

import fnmatch
import json
import logging
import os
import re
from dataclasses import dataclass, field, fields
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Result type
# ---------------------------------------------------------------------------


@dataclass
class GuardResult:
    """Result of a local guard check."""

    allowed: bool
    action: str  # "allow", "deny", "ask"
    violations: list[str] = field(default_factory=list)
    rule: str = ""  # which guard rule triggered


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------


@dataclass
class GuardConfig:
    """Configuration for local guard checks."""

    # --- Destructive command blocking ---
    blocked_command_patterns: list[str] = field(default_factory=list)
    warn_command_patterns: list[str] = field(default_factory=list)

    # --- File protection ---
    protected_file_patterns: list[str] = field(default_factory=list)
    warn_file_patterns: list[str] = field(default_factory=list)
    # Default OFF. Legitimate cross-project edits happen all the time (working
    # in one repo, editing a config in a sibling repo, etc.) and the strict
    # boundary check blocks them with no opt-out UX. Users who want this can
    # enable it explicitly via ~/.waxell/guard.json or similar.
    path_boundary_enabled: bool = False

    # --- Git safety ---
    git_protected_branches: list[str] = field(default_factory=list)
    git_block_force_push: bool = True
    git_block_hard_reset: bool = True
    git_block_config_edit: bool = True

    # --- Network access ---
    blocked_domains: list[str] = field(default_factory=list)
    block_internal_urls: bool = True

    # --- Session scope ---
    max_file_changes: int = 50
    warn_file_changes: int = 20

    # --- Cowork ---
    detect_file_conflicts: bool = True

    # --- CI/CD protection ---
    infra_file_patterns: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Built-in defaults
# ---------------------------------------------------------------------------

# Bash commands that should be BLOCKED (deny)
_DEFAULT_BLOCKED_COMMANDS = [
    # Recursive force delete of critical paths
    r"rm\s+(-[a-zA-Z]*f[a-zA-Z]*\s+(-[a-zA-Z]*r|--recursive)|(-[a-zA-Z]*r[a-zA-Z]*\s+(-[a-zA-Z]*f|--force))|--force\s+--recursive|--recursive\s+--force)\s+(/\s|/\s*$|~/|~\s|/\s*\*|\$HOME)",
    r"rm\s+-rf\s+/\s*$",
    r"rm\s+-rf\s+~/",
    r"rm\s+-rf\s+\$HOME",
    r"rm\s+-rf\s+\.\s*$",  # rm -rf . (wipe cwd)
    # Disk/filesystem destruction
    r"\bmkfs\b",
    r"\bdd\s+if=",
    r">\s*/dev/sd",
    # Fork bomb
    r":\(\)\{\s*:\|:\s*&\s*\}\s*;",
    # System control
    r"\bshutdown\b",
    r"\breboot\b",
    r"\bhalt\b",
    r"\binit\s+0\b",
    # Dangerous permissions
    r"chmod\s+(-R\s+)?777\s+/",
    # Pipe to shell (remote code execution)
    r"curl\s+[^|]*\|\s*(ba)?sh",
    r"wget\s+[^|]*\|\s*(ba)?sh",
    r"curl\s+[^|]*\|\s*sudo\s+(ba)?sh",
]

# Bash commands that should trigger a WARNING (ask)
_DEFAULT_WARN_COMMANDS = [
    # Any recursive force delete (not just root)
    r"rm\s+-rf\b",
    r"rm\s+-r\s+-f\b",
    r"rm\s+-fr\b",
    # Process killing
    r"kill\s+-9\b",
    r"pkill\s+-9\b",
    r"killall\b",
    # Docker cleanup
    r"docker\s+system\s+prune",
    r"docker\s+rm\s+-f",
    r"docker\s+rmi\s+-f",
    # Database destruction
    r"DROP\s+(TABLE|DATABASE|SCHEMA)\b",
    r"TRUNCATE\s+TABLE\b",
    r"DELETE\s+FROM\s+\w+\s*;?\s*$",  # DELETE without WHERE
]

# File patterns that should be BLOCKED for writes
_DEFAULT_PROTECTED_FILES = [
    ".env",
    ".env.*",
    ".env.local",
    ".env.production",
    ".env.staging",
    "**/credentials*",
    "**/secrets.yml",
    "**/secrets.yaml",
    "**/secrets.json",
    "**/*.pem",
    "**/*.key",
    "**/id_rsa",
    "**/id_rsa.pub",
    "**/id_ed25519",
    "**/id_ed25519.pub",
    "**/.ssh/authorized_keys",
    "**/.ssh/known_hosts",
    "**/.aws/credentials",
    "**/.aws/config",
    "**/.config/gcloud/*",
    ".git/config",
    "**/.netrc",
    "**/.npmrc",  # can contain auth tokens
    "**/.pypirc",  # can contain auth tokens
]

# File patterns that should trigger a WARNING for writes
_DEFAULT_WARN_FILES = [
    "*.lock",
    "*lock.json",
    "*lock.yaml",
    ".gitignore",
    ".dockerignore",
]

# Default protected branches
_DEFAULT_PROTECTED_BRANCHES = [
    "main",
    "master",
    "develop",
    "release/*",
    "production",
]

# CI/CD and infrastructure file patterns (warn on writes)
_DEFAULT_INFRA_FILES = [
    "Dockerfile",
    "Dockerfile.*",
    "docker-compose*.yml",
    "docker-compose*.yaml",
    ".github/**",
    ".gitlab-ci.yml",
    ".gitlab-ci/**",
    "Jenkinsfile",
    ".circleci/**",
    "**/*.tf",
    "**/terraform/**",
    "**/k8s/**",
    "**/kubernetes/**",
    "**/helm/**",
    "Makefile",
    "justfile",
    "Procfile",
    ".buildpacks",
    "fly.toml",
    "render.yaml",
    "vercel.json",
    "netlify.toml",
]

# Internal/private network patterns
_INTERNAL_URL_PATTERNS = [
    re.compile(r"^https?://localhost\b"),
    re.compile(r"^https?://127\.0\.0\.1\b"),
    re.compile(r"^https?://0\.0\.0\.0\b"),
    re.compile(r"^https?://10\.\d+\.\d+\.\d+"),
    re.compile(r"^https?://172\.(1[6-9]|2\d|3[01])\.\d+\.\d+"),
    re.compile(r"^https?://192\.168\.\d+\.\d+"),
    re.compile(r"^https?://169\.254\.\d+\.\d+"),  # link-local / cloud metadata
    re.compile(r"^https?://metadata\.google\.internal"),
    re.compile(r"^https?://\[::1\]"),  # IPv6 loopback
]


def _default_config() -> GuardConfig:
    """Return a GuardConfig with sensible enterprise defaults."""
    return GuardConfig(
        blocked_command_patterns=list(_DEFAULT_BLOCKED_COMMANDS),
        warn_command_patterns=list(_DEFAULT_WARN_COMMANDS),
        protected_file_patterns=list(_DEFAULT_PROTECTED_FILES),
        warn_file_patterns=list(_DEFAULT_WARN_FILES),
        path_boundary_enabled=False,
        git_protected_branches=list(_DEFAULT_PROTECTED_BRANCHES),
        git_block_force_push=True,
        git_block_hard_reset=True,
        git_block_config_edit=True,
        blocked_domains=[],
        block_internal_urls=True,
        max_file_changes=50,
        warn_file_changes=20,
        detect_file_conflicts=True,
        infra_file_patterns=list(_DEFAULT_INFRA_FILES),
    )


def load_config(cwd: str = "", *, client=None) -> GuardConfig:
    """Load guard configuration with override chain.

    Priority (lowest to highest — later layers override earlier):
        builtin defaults
        < remote (controlplane-managed `ConnectGuardConfig`, B5/B6)
        < ~/.waxell/guard.json (user global)
        < ./.waxell/guard.json (project-local)

    Override layers are partial — only specified keys replace earlier values.

    The remote layer is **best-effort and cached**: a fresh response is
    pulled from `/api/waxell/v1/connect/guard-config/` once per
    REMOTE_FETCH_FRESHNESS_SECONDS and persisted to disk. On network
    failure the last cached response is reused; if no cache exists,
    builtin defaults flow through. The local file overlays always apply
    on top — developers keep their per-repo escape hatch.

    Pass ``client`` (a configured ``WaxellObserveClient``) to enable the
    remote layer. Without it, behavior reduces to the legacy file +
    builtin chain.
    """
    config = _default_config()

    # Remote layer (B5/B6) — managed config from controlplane. Skipped
    # silently if the client isn't configured or agent_slug is unknown.
    if client is not None:
        remote = _load_remote_overrides(client)
        if remote:
            _apply_overrides_dict(config, remote)

    # Try user-global config
    user_path = Path.home() / ".waxell" / "guard.json"
    _apply_overrides(config, user_path)

    # Try project config (higher priority)
    if cwd:
        project_path = Path(cwd) / ".waxell" / "guard.json"
        _apply_overrides(config, project_path)

    return config


def _apply_overrides(config: GuardConfig, path: Path) -> None:
    """Apply JSON overrides from a config file onto an existing config."""
    if not path.exists():
        return
    try:
        overrides = json.loads(path.read_text())
        if not isinstance(overrides, dict):
            return
        _apply_overrides_dict(config, overrides)
    except (json.JSONDecodeError, IOError) as e:
        logger.debug("Failed to load guard config from %s: %s", path, e)


def _apply_overrides_dict(config: GuardConfig, overrides: dict) -> None:
    """Apply a dict of overrides onto an existing GuardConfig.

    Only keys that correspond to dataclass fields are applied — unknown
    keys are silently ignored at this layer (the validator at install
    time, `validate_config_file`, catches typos).
    """
    if not isinstance(overrides, dict):
        return
    for key, value in overrides.items():
        if hasattr(config, key):
            setattr(config, key, value)


# ---------------------------------------------------------------------------
# Remote config loader (B5/B6) — pulls merged ConnectGuardConfig
# ---------------------------------------------------------------------------

REMOTE_FETCH_FRESHNESS_SECONDS = 60
REMOTE_FETCH_TIMEOUT_SECONDS = 5
_REMOTE_CACHE_PATH = Path.home() / ".waxell" / "guard-config-cache.json"


def _load_remote_overrides(client) -> dict | None:
    """Fetch the merged remote guard config from controlplane. Returns
    the config dict (the `config` field of the response) on success, or
    None when nothing usable is available.

    Behavior:
    - If `now - cache.fetched_at < REMOTE_FETCH_FRESHNESS_SECONDS`, the
      cached config is returned without a network call.
    - Otherwise an HTTP GET is issued with `If-None-Match: <cached-etag>`.
      304 → refresh `fetched_at` on disk, return cached config.
      200 → write new config + etag to disk, return new config.
      anything else → return cached config if any, else None.
    - Never raises. All failure paths log at debug.

    The local guard's overlay precedence is preserved: this function
    returns the *server's merged remote layer*. The caller in
    `load_config()` then applies user/project files on top.
    """
    if not _client_configured_for_remote(client):
        return None

    agent_slug = _client_agent_slug(client)
    if not agent_slug:
        # No agent identity → can't request the per-agent merged config.
        # Fall back to file + builtin chain.
        return None

    # Phase 3b — origin-aware effective config from the poller's
    # side-write (Phase 3a). Preferred over policy.json because:
    # 1. It's the merged result (defaults + tenant + groups + agent)
    #    so we can return it as-is without the caller doing extra
    #    layering.
    # 2. Failures are gracefully detected (empty dict → fall through),
    #    no schema-shape ambiguity vs the legacy `config` vs
    #    `guard_config` keys.
    effective_layer = _load_from_effective_file(agent_slug=agent_slug)
    if effective_layer is not None:
        return effective_layer

    # B6 — if the network-monitor policy poller is running, it already
    # keeps `~/.waxell/policy.json` fresh against the same endpoint.
    # Reading that file lets us skip the network fetch entirely on every
    # session start. Falls through to the legacy direct-fetch path when
    # the poller isn't installed or the file's stale.
    policy_layer = _load_from_policy_file(agent_slug=agent_slug)
    if policy_layer is not None:
        return policy_layer

    cached = _load_remote_cache()

    # Fresh cache short-circuit — avoids spamming the endpoint per hook.
    if cached and cached.get("agent_slug") == agent_slug:
        if _cache_is_fresh(cached):
            return cached.get("config") or None

    headers = {"X-Wax-Key": client.config.api_key}
    if cached and cached.get("agent_slug") == agent_slug and cached.get("etag"):
        headers["If-None-Match"] = f'"{cached["etag"]}"'

    response = _fetch_remote_config(
        api_url=client.config.api_url,
        agent_slug=agent_slug,
        headers=headers,
    )

    if response is None:
        # Network failure — fall back to cached config if it matches the
        # current agent_slug. Last-known-good is the right behavior here:
        # losing controlplane connectivity must not silently strip the
        # tenant's policy.
        if cached and cached.get("agent_slug") == agent_slug:
            return cached.get("config") or None
        return None

    if response == "not_modified":
        # 304 — refresh the freshness window without rewriting payload.
        if cached:
            cached["fetched_at"] = _utc_iso_now()
            _save_remote_cache(cached)
            return cached.get("config") or None
        # Got a 304 with no cache — odd but recoverable: skip remote layer.
        return None

    # Fresh payload — write to disk + return.
    new_cache = {
        "agent_slug": agent_slug,
        "etag": response.get("etag") or "",
        "fetched_at": _utc_iso_now(),
        "config": response.get("config") or {},
    }
    _save_remote_cache(new_cache)
    return new_cache["config"] or None


def _client_configured_for_remote(client) -> bool:
    cfg = getattr(client, "config", None)
    if cfg is None:
        return False
    return bool(getattr(cfg, "api_url", "") and getattr(cfg, "api_key", ""))


def _client_agent_slug(client) -> str:
    """Agent slug for the remote fetch. Honors B10's env override
    (`CLAUDE_CODE_AGENT_SLUG` / `WAXELL_AGENT_SLUG`) so two CC instances
    sharing a profile can pull distinct merged configs."""
    env = (
        os.environ.get("CLAUDE_CODE_AGENT_SLUG")
        or os.environ.get("WAXELL_AGENT_SLUG")
        or ""
    ).strip()
    if env:
        return env
    cfg = getattr(client, "config", None)
    return (getattr(cfg, "agent_slug", "") if cfg else "") or ""


def _utc_iso_now() -> str:
    from datetime import datetime, timezone

    return datetime.now(timezone.utc).isoformat()


def _cache_is_fresh(cached: dict) -> bool:
    fetched_at = cached.get("fetched_at") or ""
    if not fetched_at:
        return False
    try:
        from datetime import datetime, timezone

        ts = datetime.fromisoformat(fetched_at.replace("Z", "+00:00"))
        if ts.tzinfo is None:
            ts = ts.replace(tzinfo=timezone.utc)
        age = (datetime.now(timezone.utc) - ts).total_seconds()
        return 0 <= age < REMOTE_FETCH_FRESHNESS_SECONDS
    except (ValueError, TypeError):
        return False


def _load_remote_cache() -> dict | None:
    try:
        if not _REMOTE_CACHE_PATH.exists():
            return None
        return json.loads(_REMOTE_CACHE_PATH.read_text())
    except (json.JSONDecodeError, IOError, OSError) as e:
        logger.debug("Remote guard-config cache unreadable: %s", e)
        return None


# Path written by the network-monitor policy poller — same shape as the
# /api/waxell/v1/connect/guard-config/ response body. Reading it skips
# a network call on every session start when the poller is installed.
_POLICY_POLLER_PATH = Path.home() / ".waxell" / "policy.json"
_POLICY_POLLER_FRESHNESS_SECONDS = 300

# Phase 3b of GUARD_CONFIG_UNIFICATION — origin-aware effective
# config. Written by the poller (Phase 3a). Same freshness budget
# as policy.json. When present, this is the preferred source: it
# already merges defaults + tenant + groups + agent server-side
# and includes per-field origins.
_EFFECTIVE_PATH = Path.home() / ".waxell" / "guard-effective.json"


def _load_from_effective_file(*, agent_slug: str) -> dict | None:
    """Pull the merged guard config from `~/.waxell/guard-effective.json`
    if usable.

    Returns the `effective` dict (already includes defaults + all
    layers merged server-side). Same freshness window as
    `_load_from_policy_file`.

    The legacy `_apply_overrides_dict` only applies keys that match
    GuardConfig fields — anything in the effective doc that the
    runtime dataclass doesn't know about is silently dropped, which
    matches the behavior we want: schema-only fields can be added
    without breaking older SDKs.
    """
    try:
        if not _EFFECTIVE_PATH.exists():
            return None
        import time

        age = time.time() - _EFFECTIVE_PATH.stat().st_mtime
        if age > _POLICY_POLLER_FRESHNESS_SECONDS:
            logger.debug(
                "guard-effective.json stale (%.0fs old) — falling through", age
            )
            return None
        body = json.loads(_EFFECTIVE_PATH.read_text())
    except (json.JSONDecodeError, IOError, OSError) as e:
        logger.debug("guard-effective.json unreadable: %s", e)
        return None

    file_slug = (body.get("agent_slug") or "").strip()
    if file_slug and file_slug != agent_slug:
        # Different agent pinned — don't substitute.
        return None

    effective = body.get("effective")
    if not isinstance(effective, dict) or not effective:
        return None
    return effective


def _load_from_policy_file(*, agent_slug: str) -> dict | None:
    """Pull the merged guard config from the policy poller's output if usable.

    Returns the merged config dict (matching `_load_remote_overrides`'s
    return contract) when:
    - `~/.waxell/policy.json` exists and parses as JSON
    - the file's mtime is within `_POLICY_POLLER_FRESHNESS_SECONDS`
    - either the file's `agent_slug` matches the caller's, or the file
      is the tenant-default (empty `agent_slug`) and the caller didn't
      pin a specific agent

    Returns None otherwise — caller falls through to the legacy direct
    fetch + cache path.

    The freshness window matches the poller's default `--interval`
    (60s) plus a 4× margin so a backed-up poller doesn't cause the
    guard to silently miss policy updates.
    """
    try:
        if not _POLICY_POLLER_PATH.exists():
            return None
        # mtime cheap-freshness check before parsing.
        import time

        age = time.time() - _POLICY_POLLER_PATH.stat().st_mtime
        if age > _POLICY_POLLER_FRESHNESS_SECONDS:
            logger.debug(
                "policy.json stale (%.0fs old) — falling through to fetch", age
            )
            return None

        body = json.loads(_POLICY_POLLER_PATH.read_text())
    except (json.JSONDecodeError, IOError, OSError) as e:
        logger.debug("policy.json unreadable: %s", e)
        return None

    file_slug = (body.get("agent_slug") or "").strip()
    if file_slug and file_slug != agent_slug:
        # The poller is pinned to a different agent — don't substitute.
        return None

    # Prefer guard_config (canonical key from G1) but accept the legacy
    # `config` alias the connect endpoint also returns.
    cfg = body.get("guard_config") or body.get("config")
    if not isinstance(cfg, dict):
        return None
    return cfg or None


def _save_remote_cache(payload: dict) -> None:
    try:
        _REMOTE_CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
        tmp = _REMOTE_CACHE_PATH.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(payload, sort_keys=True))
        os.replace(str(tmp), str(_REMOTE_CACHE_PATH))
    except (IOError, OSError) as e:
        logger.debug("Failed to write remote guard-config cache: %s", e)


def _fetch_remote_config(
    *,
    api_url: str,
    agent_slug: str,
    headers: dict,
) -> dict | str | None:
    """HTTP GET against /api/waxell/v1/connect/guard-config/. Best-effort.

    Returns:
        dict — fresh response body on 200
        "not_modified" — on 304
        None — on any failure (network, timeout, non-200/304 status)
    """
    import urllib.error
    import urllib.parse
    import urllib.request

    qs = urllib.parse.urlencode({"agent_slug": agent_slug})
    url = f"{api_url.rstrip('/')}/api/waxell/v1/connect/guard-config/?{qs}"
    req = urllib.request.Request(url, headers=headers, method="GET")

    try:
        with urllib.request.urlopen(req, timeout=REMOTE_FETCH_TIMEOUT_SECONDS) as resp:
            status = resp.status
            if status == 304:
                return "not_modified"
            if status != 200:
                logger.debug("guard-config fetch returned unexpected status %s", status)
                return None
            raw = resp.read()
            return json.loads(raw)
    except urllib.error.HTTPError as e:
        if e.code == 304:
            return "not_modified"
        logger.debug("guard-config fetch HTTP error: %s", e)
        return None
    except (urllib.error.URLError, OSError, json.JSONDecodeError, TimeoutError) as e:
        logger.debug("guard-config fetch failed: %s", e)
        return None


def validate_config_file(path: Path) -> list[str]:
    """Validate a guard.json file. Returns a list of error strings; empty
    list means the file is valid (or missing — missing is allowed).

    Used by ``wax claude-code setup`` to fail fast on broken configs
    instead of silently fail-opening at runtime. C2 of the External Agent
    Governance plan.

    Validation rules:
    - File must parse as JSON.
    - Top-level value must be an object/dict.
    - Every top-level key must correspond to a real GuardConfig field
      (typo guard — silently dropped fields hide misconfiguration).
    - List-valued fields must be lists of strings.
    - Bool / int fields must have the right type.
    """
    errors: list[str] = []
    if not path.exists():
        return errors  # missing files are fine — defaults apply

    try:
        raw = path.read_text()
    except IOError as exc:
        errors.append(f"{path}: cannot read ({exc})")
        return errors

    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        errors.append(f"{path}: invalid JSON — {exc}")
        return errors

    if not isinstance(data, dict):
        errors.append(
            f"{path}: top-level value must be an object, got {type(data).__name__}"
        )
        return errors

    # Build a type map from the GuardConfig dataclass.
    template = _default_config()
    known_fields = {f.name: f for f in fields(template)}

    for key, value in data.items():
        if key not in known_fields:
            errors.append(
                f"{path}: unknown field '{key}' (typo? valid fields: "
                f"{', '.join(sorted(known_fields.keys()))})"
            )
            continue

        # Inspect the dataclass field's annotation to enforce shape.
        default = getattr(template, key)
        if isinstance(default, bool) and not isinstance(value, bool):
            errors.append(f"{path}: '{key}' must be a bool, got {type(value).__name__}")
        elif (
            isinstance(default, int)
            and not isinstance(default, bool)
            and not isinstance(value, int)
        ):
            errors.append(
                f"{path}: '{key}' must be an integer, got {type(value).__name__}"
            )
        elif isinstance(default, list):
            if not isinstance(value, list):
                errors.append(
                    f"{path}: '{key}' must be a list, got {type(value).__name__}"
                )
            else:
                bad = [v for v in value if not isinstance(v, str)]
                if bad:
                    errors.append(
                        f"{path}: '{key}' must contain only strings, got {bad!r}"
                    )

    return errors


# ---------------------------------------------------------------------------
# Check functions — each returns None (pass) or GuardResult (violation)
# ---------------------------------------------------------------------------


def check_tool_use(
    tool_name: str,
    tool_input: dict,
    config: GuardConfig,
    cwd: str = "",
    modified_files: Optional[list[str]] = None,
    peer_modified_files: Optional[list[str]] = None,
) -> GuardResult:
    """Run all applicable guard checks for a tool call.

    Returns GuardResult. If allowed=True, no violations found.
    """
    result = None

    if tool_name == "Bash":
        command = tool_input.get("command", "")
        result = _check_bash_command(command, config)
        if not result:
            result = _check_git_operation(command, config)

    elif tool_name in ("Write", "Edit"):
        file_path = tool_input.get("file_path", "")
        result = _check_file_write(file_path, config, cwd)
        if not result:
            result = _check_infra_file(file_path, config, cwd)
        if not result and modified_files is not None:
            result = _check_session_scope(file_path, modified_files, config)
        if (
            not result
            and peer_modified_files is not None
            and config.detect_file_conflicts
        ):
            result = _check_cowork_conflict(file_path, peer_modified_files)

    elif tool_name == "Read":
        file_path = tool_input.get("file_path", "")
        if config.path_boundary_enabled and cwd:
            result = _check_path_boundary(file_path, cwd, read_only=True)

    elif tool_name == "WebFetch":
        url = tool_input.get("url", "")
        result = _check_network_access(url, config)

    if result:
        return result

    return GuardResult(allowed=True, action="allow")


# ---------------------------------------------------------------------------
# Bash command checks
# ---------------------------------------------------------------------------


def _check_bash_command(command: str, config: GuardConfig) -> Optional[GuardResult]:
    """Check a bash command against blocked/warn patterns."""
    if not command:
        return None

    # Check blocked patterns first
    for pattern in config.blocked_command_patterns:
        try:
            if re.search(pattern, command, re.IGNORECASE):
                return GuardResult(
                    allowed=False,
                    action="deny",
                    violations=[f"Blocked command pattern: {command[:100]}"],
                    rule="destructive_command",
                )
        except re.error:
            continue

    # Check warn patterns
    for pattern in config.warn_command_patterns:
        try:
            if re.search(pattern, command, re.IGNORECASE):
                return GuardResult(
                    allowed=False,
                    action="ask",
                    violations=[f"Potentially dangerous command: {command[:100]}"],
                    rule="destructive_command",
                )
        except re.error:
            continue

    return None


# ---------------------------------------------------------------------------
# Git operation checks
# ---------------------------------------------------------------------------

# Pre-compiled git patterns for performance
_GIT_FORCE_PUSH = re.compile(r"git\s+push\s+.*?(--force|-f)\b", re.IGNORECASE)
_GIT_FORCE_PUSH_LEASE = re.compile(
    r"git\s+push\s+.*?--force-with-lease\b", re.IGNORECASE
)
_GIT_HARD_RESET = re.compile(r"git\s+reset\s+--hard\b", re.IGNORECASE)
_GIT_CLEAN = re.compile(r"git\s+clean\s+.*?-[a-zA-Z]*f", re.IGNORECASE)
_GIT_CHECKOUT_DOT = re.compile(r"git\s+checkout\s+\.\s*$", re.IGNORECASE)
_GIT_RESTORE_DOT = re.compile(r"git\s+restore\s+\.\s*$", re.IGNORECASE)
_GIT_CONFIG = re.compile(r"git\s+config\b", re.IGNORECASE)
_GIT_PUSH = re.compile(r"git\s+push\b", re.IGNORECASE)
_GIT_BRANCH_DELETE = re.compile(r"git\s+branch\s+.*?-D\b", re.IGNORECASE)
_GIT_REBASE = re.compile(r"git\s+rebase\b", re.IGNORECASE)


def _branch_matches_protected(branch: str, protected: list[str]) -> bool:
    """Check if a branch name matches any protected branch pattern."""
    for pattern in protected:
        if fnmatch.fnmatch(branch, pattern):
            return True
    return False


def _command_mentions_protected_branch(command: str, protected: list[str]) -> bool:
    """Check if a command mentions any protected branch name."""
    # Extract non-flag arguments from the command
    parts = command.split()
    for part in parts:
        if part.startswith("-"):
            continue
        if _branch_matches_protected(part, protected):
            return True
    return False


def _check_git_operation(command: str, config: GuardConfig) -> Optional[GuardResult]:
    """Check git commands for dangerous operations."""
    if not command.strip().startswith("git "):
        return None

    protected = config.git_protected_branches

    # Force push — block if targeting a protected branch or no branch specified
    if config.git_block_force_push and (
        _GIT_FORCE_PUSH.search(command) or _GIT_FORCE_PUSH_LEASE.search(command)
    ):
        if _command_mentions_protected_branch(command, protected):
            return GuardResult(
                allowed=False,
                action="deny",
                violations=[f"Force push to protected branch blocked: {command[:100]}"],
                rule="git_safety",
            )

    # Hard reset
    if config.git_block_hard_reset and _GIT_HARD_RESET.search(command):
        return GuardResult(
            allowed=False,
            action="deny",
            violations=[f"git reset --hard blocked: {command[:100]}"],
            rule="git_safety",
        )

    # git clean -f, git checkout ., git restore .
    if (
        _GIT_CLEAN.search(command)
        or _GIT_CHECKOUT_DOT.search(command)
        or _GIT_RESTORE_DOT.search(command)
    ):
        return GuardResult(
            allowed=False,
            action="deny",
            violations=[f"Destructive git operation blocked: {command[:100]}"],
            rule="git_safety",
        )

    # git config
    if config.git_block_config_edit and _GIT_CONFIG.search(command):
        return GuardResult(
            allowed=False,
            action="deny",
            violations=[f"git config modification blocked: {command[:100]}"],
            rule="git_safety",
        )

    # Warn: push to protected branch (non-force)
    if _GIT_PUSH.search(command) and not _GIT_FORCE_PUSH.search(command):
        if _command_mentions_protected_branch(command, protected):
            # Find which branch matched for the message
            matched_branch = (
                next(
                    (p for p in parts if _branch_matches_protected(p, protected)),
                    "protected",
                )
                if (parts := command.split())
                else "protected"
            )
            return GuardResult(
                allowed=False,
                action="ask",
                violations=[f"Push to protected branch '{matched_branch}' — confirm?"],
                rule="git_safety",
            )

    # Warn: branch -D
    if _GIT_BRANCH_DELETE.search(command):
        return GuardResult(
            allowed=False,
            action="ask",
            violations=[f"Force-deleting a branch: {command[:100]}"],
            rule="git_safety",
        )

    # Warn: rebase on protected branch
    if _GIT_REBASE.search(command):
        # Check if rebasing onto a protected branch
        for branch in protected:
            if branch in command:
                return GuardResult(
                    allowed=False,
                    action="ask",
                    violations=[f"Rebasing on protected branch '{branch}' — confirm?"],
                    rule="git_safety",
                )

    return None


# ---------------------------------------------------------------------------
# File access checks
# ---------------------------------------------------------------------------


def _normalize_path(file_path: str, cwd: str = "") -> str:
    """Normalize a file path for matching."""
    p = file_path
    # Expand ~ and $HOME
    p = os.path.expanduser(p)
    p = os.path.expandvars(p)
    # Make relative paths absolute using cwd
    if not os.path.isabs(p) and cwd:
        p = os.path.join(cwd, p)
    return os.path.normpath(p)


def _matches_file_pattern(
    file_path: str, patterns: list[str], cwd: str = ""
) -> Optional[str]:
    """Check if a file path matches any pattern. Returns the matched pattern or None."""
    basename = os.path.basename(file_path)
    norm_path = _normalize_path(file_path, cwd)
    rel_path = file_path  # also match against the raw path

    for pattern in patterns:
        # Direct basename match (e.g., ".env", "Dockerfile")
        if fnmatch.fnmatch(basename, pattern):
            return pattern
        # Full path glob match (e.g., "**/.ssh/*")
        if fnmatch.fnmatch(norm_path, pattern):
            return pattern
        if fnmatch.fnmatch(rel_path, pattern):
            return pattern
        # Glob-style with ** for any directory
        if "**" in pattern:
            # Convert ** glob to regex for deep matching
            regex_pattern = (
                pattern.replace("**", "DOUBLESTAR")
                .replace("*", "[^/]*")
                .replace("DOUBLESTAR", ".*")
            )
            try:
                if re.search(regex_pattern, norm_path) or re.search(
                    regex_pattern, rel_path
                ):
                    return pattern
            except re.error:
                continue

    return None


def _check_file_write(
    file_path: str, config: GuardConfig, cwd: str = ""
) -> Optional[GuardResult]:
    """Check if a file write should be blocked or warned."""
    if not file_path:
        return None

    # Check protected files (deny)
    matched = _matches_file_pattern(file_path, config.protected_file_patterns, cwd)
    if matched:
        return GuardResult(
            allowed=False,
            action="deny",
            violations=[
                f"Write to protected file blocked: {file_path} (matched: {matched})"
            ],
            rule="file_protection",
        )

    # Check warn files (ask)
    matched = _matches_file_pattern(file_path, config.warn_file_patterns, cwd)
    if matched:
        return GuardResult(
            allowed=False,
            action="ask",
            violations=[f"Write to sensitive file: {file_path} (matched: {matched})"],
            rule="file_protection",
        )

    # Path boundary check
    if config.path_boundary_enabled and cwd:
        boundary_result = _check_path_boundary(file_path, cwd, read_only=False)
        if boundary_result:
            return boundary_result

    return None


def _check_path_boundary(
    file_path: str, cwd: str, read_only: bool = False
) -> Optional[GuardResult]:
    """Check if a file path is within the project boundary."""
    if not file_path or not cwd:
        return None

    norm_path = _normalize_path(file_path, cwd)
    norm_cwd = os.path.normpath(cwd)

    # Exceptions: /tmp, /var/folders (macOS temp)
    exempt_prefixes = ("/tmp", "/var/folders", "/private/tmp")
    for prefix in exempt_prefixes:
        if norm_path.startswith(prefix):
            return None

    # Allow home directory reads (e.g., reading ~/.waxell/config)
    if read_only:
        return None

    # Check if path is within cwd
    if not norm_path.startswith(norm_cwd + os.sep) and norm_path != norm_cwd:
        return GuardResult(
            allowed=False,
            action="deny",
            violations=[
                f"Write outside project directory blocked: {file_path} (cwd: {cwd})"
            ],
            rule="path_boundary",
        )

    return None


def _check_infra_file(
    file_path: str, config: GuardConfig, cwd: str = ""
) -> Optional[GuardResult]:
    """Check if a file write targets infrastructure/CI files."""
    if not file_path or not config.infra_file_patterns:
        return None

    matched = _matches_file_pattern(file_path, config.infra_file_patterns, cwd)
    if matched:
        return GuardResult(
            allowed=False,
            action="ask",
            violations=[
                f"Write to infrastructure file: {file_path} (matched: {matched})"
            ],
            rule="infra_protection",
        )

    return None


# ---------------------------------------------------------------------------
# Network access checks
# ---------------------------------------------------------------------------


def _check_network_access(url: str, config: GuardConfig) -> Optional[GuardResult]:
    """Check if a URL should be blocked or warned."""
    if not url:
        return None

    # Block internal URLs
    if config.block_internal_urls:
        for pattern in _INTERNAL_URL_PATTERNS:
            if pattern.search(url):
                return GuardResult(
                    allowed=False,
                    action="deny",
                    violations=[f"Access to internal/private URL blocked: {url}"],
                    rule="network_access",
                )

    # Block specific domains
    if config.blocked_domains:
        for domain in config.blocked_domains:
            if domain.lower() in url.lower():
                return GuardResult(
                    allowed=False,
                    action="deny",
                    violations=[f"Access to blocked domain: {domain}"],
                    rule="network_access",
                )

    return None


# ---------------------------------------------------------------------------
# Session scope checks
# ---------------------------------------------------------------------------


def _check_session_scope(
    file_path: str,
    modified_files: list[str],
    config: GuardConfig,
) -> Optional[GuardResult]:
    """Check if the session is modifying too many files."""
    if file_path in modified_files:
        return None  # Already counted

    count = len(modified_files) + 1  # Including this file

    if config.max_file_changes and count > config.max_file_changes:
        return GuardResult(
            allowed=False,
            action="ask",
            violations=[
                f"Session has modified {count} files (limit: {config.max_file_changes})"
            ],
            rule="session_scope",
        )

    if config.warn_file_changes and count == config.warn_file_changes:
        return GuardResult(
            allowed=False,
            action="ask",
            violations=[f"Session has modified {count} files — approaching limit"],
            rule="session_scope",
        )

    return None


# ---------------------------------------------------------------------------
# Cowork conflict detection
# ---------------------------------------------------------------------------


def _check_cowork_conflict(
    file_path: str,
    peer_modified_files: list[str],
) -> Optional[GuardResult]:
    """Check if a teammate has already modified this file."""
    if not peer_modified_files:
        return None

    # Normalize for comparison
    norm_path = os.path.normpath(file_path)
    for peer_file in peer_modified_files:
        if os.path.normpath(peer_file) == norm_path:
            return GuardResult(
                allowed=False,
                action="ask",
                violations=[f"Cowork conflict: teammate already modified {file_path}"],
                rule="cowork_conflict",
            )

    return None
