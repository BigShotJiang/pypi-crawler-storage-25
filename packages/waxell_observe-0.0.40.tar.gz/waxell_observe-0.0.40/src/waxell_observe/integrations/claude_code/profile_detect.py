"""C8 — SessionStart profile auto-detection shim for Claude Code.

If ``<cwd>/.waxell-profile`` is present, read its contents and emit a
Claude Code hook JSON response that injects ``WAXELL_PROFILE=<value>``
into the session environment so all subsequent waxell hooks pick up
the right profile without the user touching their shell.

If ``.waxell-profile`` is missing, no env injection happens; the
configured-at-setup-time profile applies. The hook is intentionally
fail-soft: any read or validation error silently no-ops so a malformed
file can't kill Claude Code's startup.

Validation rules:
  - 1..64 chars
  - alphanumeric, underscore, hyphen only (matches profile-section name
    rules in ~/.waxell/config)
  - no leading/trailing whitespace, no newlines, no path separators

Output shape (when a valid profile is found):

    {
      "hookSpecificOutput": {
        "hookEventName": "SessionStart",
        "additionalContext": "Waxell profile auto-detected: <name>"
      },
      "env_extra": {"WAXELL_PROFILE": "<name>"}
    }

The ``env_extra`` key is the Claude Code convention for injecting env
vars into the session for downstream hooks. ``additionalContext`` puts
a one-line note in the model's view so it knows which profile applies.
"""

from __future__ import annotations

import json
import logging
import os
import re
import sys
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

PROFILE_FILENAME = ".waxell-profile"
_PROFILE_NAME_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$")


def _read_profile_file(cwd: Path) -> Optional[str]:
    """Read and validate ``<cwd>/.waxell-profile``. Returns None if absent
    or invalid (including empty). Never raises."""
    try:
        path = cwd / PROFILE_FILENAME
        if not path.exists() or not path.is_file():
            return None
        raw = path.read_text(encoding="utf-8", errors="replace")
    except (OSError, UnicodeError) as e:
        logger.debug("profile-detect: read failed for %s: %s", cwd, e)
        return None
    # Strip whitespace + comments. Take first non-comment, non-empty line.
    name: Optional[str] = None
    for line in raw.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        name = line
        break
    if not name:
        return None
    if not _PROFILE_NAME_RE.match(name):
        logger.debug(
            "profile-detect: invalid profile name in %s (must match [A-Za-z0-9_-]{1,64})",
            path,
        )
        return None
    return name


def handle_profile_detect(stdin_data: Optional[dict] = None) -> Optional[dict]:
    """Main entry point for the profile-detect SessionStart hook.

    Reads the SessionStart hook payload from stdin (when not given), looks
    up the cwd, and (if a valid ``.waxell-profile`` exists) returns a
    response dict that Claude Code parses to inject ``WAXELL_PROFILE``
    for the rest of the session.

    Returns ``None`` (no output) when nothing should change. Callers print
    the dict as JSON; this function never prints itself so it's testable.
    """
    if stdin_data is None:
        try:
            raw = sys.stdin.read()
            if not raw.strip():
                return None
            stdin_data = json.loads(raw)
        except (json.JSONDecodeError, IOError):
            return None

    # Claude Code hook payloads include 'cwd' on SessionStart. Fall back to
    # process cwd just in case some forks of CC don't include it.
    cwd_raw = (stdin_data or {}).get("cwd") or os.getcwd()
    try:
        cwd = Path(cwd_raw).expanduser().resolve()
    except (OSError, RuntimeError):
        return None

    name = _read_profile_file(cwd)
    if not name:
        return None

    return {
        "hookSpecificOutput": {
            "hookEventName": "SessionStart",
            "additionalContext": f"Waxell profile auto-detected: {name}",
        },
        # Claude Code's env-injection convention. Subsequent hooks in this
        # SessionStart batch + every later hook in the session see this var.
        "env_extra": {"WAXELL_PROFILE": name},
    }


def main() -> None:
    """CLI entry: read stdin → emit JSON or be silent. Never raises."""
    try:
        result = handle_profile_detect()
    except Exception as e:  # pragma: no cover - defensive
        logger.debug("profile-detect: unexpected error: %s", e)
        return
    if result is not None:
        try:
            sys.stdout.write(json.dumps(result))
        except Exception:
            pass


if __name__ == "__main__":  # pragma: no cover
    main()
