"""Session state management for Claude Code hooks.

Each hook invocation is a separate process — shared state is stored
in temp files under /tmp/waxell-cc/{session_id}.json.

Writes are atomic (write to .tmp then rename) to avoid corruption
from concurrent async hooks.
"""

import json
import os
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Optional

STATE_DIR = Path(os.environ.get("WAXELL_CC_STATE_DIR", "/tmp/waxell-cc"))
STATE_TTL_SECONDS = 24 * 60 * 60  # 24 hours


def _project_key() -> str:
    """Read the project-isolation key from the environment.

    Set by hook commands when ``wax claude-code setup --isolation project``
    was used. Empty string means default (profile-only) scoping.
    """
    return (os.environ.get("WAXELL_PROJECT_KEY") or "").strip()


def _scoped_state_dir() -> Path:
    """STATE_DIR, namespaced under the project key when present.

    Without isolation: /tmp/waxell-cc/{session_id}.json (legacy layout).
    With isolation:    /tmp/waxell-cc/proj-{key}/{session_id}.json.

    Two repos sharing one Waxell profile end up with disjoint state files
    so cowork-peer detection, modified_files, transcript offsets, etc.
    don't bleed across projects.
    """
    key = _project_key()
    if key:
        return STATE_DIR / f"proj-{key}"
    return STATE_DIR


@dataclass
class SessionState:
    """State for an active Claude Code session."""

    session_id: str = ""
    run_id: str = ""
    workflow_id: str = ""
    cowork_session_id: str = ""
    started_at: str = ""
    cwd: str = ""
    model: str = ""
    span_count: int = 0
    is_cowork: bool = False
    pending_subagent_spans: dict = field(default_factory=dict)
    modified_files: list = field(default_factory=list)
    # Set of LLM message_ids already recorded on this run — prevents
    # Stop/SessionEnd from duplicating calls when they fire mid-session
    # (Stop fires between every turn, not just at session end).
    recorded_llm_ids: list = field(default_factory=list)
    # True when run_id points at a daily session accumulator. Daily runs
    # stay open all day and are shared across many CLI sessions, so Stop
    # must NOT complete/delete state the way per-session runs do.
    is_daily_session: bool = False
    transcript_offset: int = 0
    # C9 — set by _reconcile_stop_cost the first time Stop detects an
    # overage so we don't re-emit the alert on subsequent Stops within
    # the same daily session.
    cost_overage_emitted: bool = False


def _state_path(session_id: str) -> Path:
    return _scoped_state_dir() / f"{session_id}.json"


def save_state(state: SessionState) -> None:
    """Atomically save session state to disk."""
    scope = _scoped_state_dir()
    scope.mkdir(parents=True, exist_ok=True)
    path = _state_path(state.session_id)
    tmp_path = path.with_suffix(".tmp")
    tmp_path.write_text(json.dumps(asdict(state)))
    tmp_path.rename(path)


def load_state(session_id: str) -> Optional[SessionState]:
    """Load session state from disk. Returns None if not found."""
    path = _state_path(session_id)
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text())
        return SessionState(
            **{k: v for k, v in data.items() if k in SessionState.__dataclass_fields__}
        )
    except (json.JSONDecodeError, TypeError):
        return None


def delete_state(session_id: str) -> None:
    """Remove session state file."""
    path = _state_path(session_id)
    path.unlink(missing_ok=True)


def find_cowork_peer(cwd: str, exclude_session_id: str) -> Optional[SessionState]:
    """Find an active session in the same working directory (Cowork detection).

    If another session exists with the same cwd, this is likely a Cowork session.
    Returns the peer's state, or None.

    Scope: scans only the current isolation scope's directory. Under
    --isolation project, two repos with the same WAXELL_PROJECT_KEY are
    by definition the same project so peers across project keys would
    not be cowork peers anyway.
    """
    scope = _scoped_state_dir()
    if not scope.exists():
        return None
    for f in scope.glob("*.json"):
        peer_id = f.stem
        if peer_id == exclude_session_id:
            continue
        peer = load_state(peer_id)
        if peer and peer.run_id and peer.cwd == cwd:
            return peer
    return None


def cleanup_stale_states() -> int:
    """Remove state files older than STATE_TTL_SECONDS in the active scope.

    Returns count removed. Other scopes (other project keys, or the
    default scope) are untouched — each Claude Code instance only sweeps
    its own bucket so a long-running default-scope session doesn't expire
    a project-isolated session's state and vice versa.
    """
    scope = _scoped_state_dir()
    if not scope.exists():
        return 0
    cutoff = time.time() - STATE_TTL_SECONDS
    removed = 0
    for f in scope.glob("*.json"):
        try:
            if f.stat().st_mtime < cutoff:
                f.unlink()
                removed += 1
        except OSError:
            pass
    return removed
