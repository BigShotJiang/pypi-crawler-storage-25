"""Claude Code & Cowork observability integration.

Instruments Claude Code sessions as observable agent runs in Waxell.
Uses Claude Code's hooks system and JSONL transcripts.
"""

from .guard import GuardConfig, GuardResult, check_tool_use, load_config
from .hook_handler import handle_hook
from .profile_detect import handle_profile_detect
from .setup import (
    DEFAULT_PROFILE,
    ISOLATION_PROFILE,
    ISOLATION_PROJECT,
    VALID_ISOLATIONS,
    detect_status,
    project_key_for,
    remove_hooks,
    setup_hooks,
)
from .transcript import parse_transcript

__all__ = [
    "DEFAULT_PROFILE",
    "GuardConfig",
    "GuardResult",
    "ISOLATION_PROFILE",
    "ISOLATION_PROJECT",
    "VALID_ISOLATIONS",
    "check_tool_use",
    "detect_status",
    "handle_hook",
    "handle_profile_detect",
    "load_config",
    "parse_transcript",
    "project_key_for",
    "remove_hooks",
    "setup_hooks",
]
