"""Policy poller — fetches managed guard config + network-filter rules.

Periodically calls ``GET /api/waxell/v1/connect/guard-config/`` and
materializes the response to ``~/.waxell/policy.json``. The system
extension's network filter reads that file on each new flow to decide
allow/block. The local guard (waxell-observe in claude-code / cowork)
also reads the same file so all enforcement surfaces see the same
truth.

Design choices:
- ETag-driven: store last-seen etag in ``~/.waxell/policy-etag.json``,
  send ``If-None-Match`` on every request. Quiet 304s mean transfer is
  just headers; updates only happen when policy actually changed.
- Atomic writes: write to ``policy.json.tmp`` then ``os.replace`` so
  the network filter never sees a half-written file.
- Crash-safe: nothing on disk is required for startup; missing files
  just mean "first poll." Corrupt etag/policy files self-heal.
- Profile-aware: pulls api_key + api_url from the same ``[<profile>]``
  block in ``~/.waxell/config`` that the uploader uses, so a single
  install gives both poller and uploader the right credentials.

Mirrors the patterns in ``uploader.py`` so a future ``service install``
can install both daemons under the same launchd plist.
"""

from __future__ import annotations

import json
import logging
import os
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


# === Constants ===

POLICY_PATH = Path.home() / ".waxell" / "policy.json"
ETAG_PATH = Path.home() / ".waxell" / "policy-etag.json"
GUARD_CONFIG_PATH = "/api/waxell/v1/connect/guard-config/"

# Phase 3a of GUARD_CONFIG_UNIFICATION — origin-aware effective
# config. Written alongside POLICY_PATH; SDK readers and the cloud
# editor can now see "this came from default vs tenant vs agent."
EFFECTIVE_PATH = Path.home() / ".waxell" / "guard-effective.json"
GUARD_EFFECTIVE_PATH = "/api/waxell/v1/guard/effective/"

DEFAULT_POLL_INTERVAL = 60.0  # seconds — matches the Cache-Control hint
DEFAULT_REQUEST_TIMEOUT = 30.0


# === Etag persistence ===


def _load_etag() -> Optional[str]:
    """Returns the last seen ETag, or ``None`` if no/corrupt cache."""
    if not ETAG_PATH.exists():
        return None
    try:
        return json.loads(ETAG_PATH.read_text()).get("etag")
    except (OSError, json.JSONDecodeError):
        return None


def _save_etag(etag: str) -> None:
    ETAG_PATH.parent.mkdir(parents=True, exist_ok=True)
    ETAG_PATH.write_text(json.dumps({"etag": etag}))


# === Atomic policy write ===


def _atomic_write_policy(policy: dict) -> None:
    """Write ``policy`` to POLICY_PATH atomically.

    The network filter mmaps / reads this file on every new flow, so a
    half-written file would briefly drop enforcement. ``os.replace`` is
    atomic on every platform we ship on.
    """
    POLICY_PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = POLICY_PATH.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(policy, indent=2, sort_keys=True))
    os.replace(tmp, POLICY_PATH)


def _atomic_write_effective(payload: dict) -> None:
    """Write origin-aware effective config to EFFECTIVE_PATH atomically.

    Phase 3a — additive. The legacy `policy.json` write keeps
    happening; this is a sibling file the schema-driven UIs read.
    Same atomic-rename pattern.
    """
    EFFECTIVE_PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = EFFECTIVE_PATH.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(payload, indent=2, sort_keys=True))
    os.replace(tmp, EFFECTIVE_PATH)


def _fetch_and_write_effective(
    *,
    api_url: str,
    api_key: str,
    agent_slug: Optional[str] = None,
    timeout: float = DEFAULT_REQUEST_TIMEOUT,
) -> None:
    """Best-effort side-fetch of the origin-aware effective config.

    Failures here are silent — the legacy `policy.json` is the
    authoritative cache for runtime enforcement; this file exists
    purely so admin UIs (Mac app's Guard tab, controlplane editor)
    can show per-field origin badges. If the controlplane is older
    than the SDK and doesn't have `/v1/guard/effective`, we just
    skip without disrupting anything.
    """
    try:
        url = api_url.rstrip("/") + GUARD_EFFECTIVE_PATH
        if agent_slug:
            url = f"{url}?agent_slug={agent_slug}"
        req = urllib.request.Request(
            url,
            method="GET",
            headers={"X-Wax-Key": api_key, "Accept": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            if 200 <= resp.status < 300:
                body = resp.read()
                payload = json.loads(body)
                _atomic_write_effective(payload)
            else:
                logger.debug(
                    "guard/effective fetch returned %d (skipping side-write)",
                    resp.status,
                )
    except urllib.error.HTTPError as e:
        # 404 = controlplane doesn't have the new endpoint yet.
        # Anything else logs at debug; we don't disrupt the legacy path.
        logger.debug("guard/effective HTTPError %d: %s", e.code, e.reason)
    except (urllib.error.URLError, OSError, ValueError) as e:
        logger.debug("guard/effective fetch skipped: %s", e)


def _load_policy() -> Optional[dict]:
    """Return the on-disk policy, or ``None`` if missing/corrupt."""
    if not POLICY_PATH.exists():
        return None
    try:
        return json.loads(POLICY_PATH.read_text())
    except (OSError, json.JSONDecodeError):
        return None


# === HTTP fetch ===


class FetchResult:
    """Outcome of a single guard-config fetch.

    Distinct states:
    - ``not_modified``: server returned 304; on-disk policy is current.
    - ``updated``: server returned 200 with new body; etag advanced.
    - ``error``: HTTP / network / parse failure; on-disk policy untouched.
    """

    __slots__ = ("status", "etag", "policy", "error")

    def __init__(
        self,
        *,
        status: str,
        etag: Optional[str] = None,
        policy: Optional[dict] = None,
        error: Optional[str] = None,
    ):
        self.status = status
        self.etag = etag
        self.policy = policy
        self.error = error


def _fetch_guard_config(
    *,
    api_url: str,
    api_key: str,
    if_none_match: Optional[str] = None,
    agent_slug: Optional[str] = None,
    device_uuid: Optional[str] = None,
    wait_seconds: int = 0,
    timeout: float = DEFAULT_REQUEST_TIMEOUT,
) -> FetchResult:
    """One GET against the guard-config endpoint.

    Returns ``FetchResult`` rather than raising — the daemon loop must
    keep running through transient failures.

    G2: when ``wait_seconds > 0`` the server holds the connection until
    the etag changes or the wait expires (long-poll). Bump ``timeout``
    above ``wait_seconds`` so the urllib client doesn't disconnect first.
    G4: ``device_uuid`` causes the server to embed any pending
    EndpointCommand rows for that device in the response body.
    """
    url = api_url.rstrip("/") + GUARD_CONFIG_PATH
    qs: list[str] = []
    if agent_slug:
        qs.append(f"agent_slug={agent_slug}")
    if device_uuid:
        qs.append(f"device={device_uuid}")
    if wait_seconds > 0:
        qs.append(f"wait={int(wait_seconds)}")
    if qs:
        url += "?" + "&".join(qs)

    if wait_seconds > 0:
        # urllib timeout must outlive the server-side wait, otherwise
        # we tear down the socket before the server sends 200/304.
        timeout = max(timeout, float(wait_seconds) + 10.0)

    headers = {
        "X-Wax-Key": api_key,
        "Accept": "application/json",
    }
    if if_none_match:
        # Wrap in quotes per RFC 7232 §2.3.
        headers["If-None-Match"] = f'"{if_none_match}"'

    req = urllib.request.Request(url, method="GET", headers=headers)

    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            status_code = resp.status
            body = resp.read()
            etag_header = resp.headers.get("ETag", "").strip().strip('"') or None
    except urllib.error.HTTPError as e:
        if e.code == 304:
            return FetchResult(status="not_modified")
        return FetchResult(status="error", error=f"HTTP {e.code}: {e.reason}")
    except urllib.error.URLError as e:
        return FetchResult(status="error", error=f"URLError: {e.reason}")
    except OSError as e:
        return FetchResult(status="error", error=f"OSError: {e}")

    if status_code == 304:
        return FetchResult(status="not_modified")
    if status_code != 200:
        return FetchResult(status="error", error=f"unexpected status {status_code}")

    try:
        policy = json.loads(body.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as e:
        return FetchResult(status="error", error=f"bad JSON: {e}")

    # Body's `etag` field is authoritative; fall back to ETag header if absent.
    etag = policy.get("etag") or etag_header
    return FetchResult(status="updated", etag=etag, policy=policy)


# === Tick — one iteration of the loop ===


def poll_once(
    *,
    api_url: str,
    api_key: str,
    agent_slug: Optional[str] = None,
    device_uuid: Optional[str] = None,
    wait_seconds: int = 0,
) -> FetchResult:
    """Run one fetch + persist cycle. Side-effect: may write to disk.

    Public for the ``--once`` CLI mode and for tests. The daemon loop
    just repeats this on a timer.

    G2: ``wait_seconds > 0`` enables long-poll — server holds the
    connection until the etag changes or the wait expires.
    G4: ``device_uuid`` causes the server to embed pending
    ``EndpointCommand`` rows for that device in the response body.
    """
    if_none_match = _load_etag()

    result = _fetch_guard_config(
        api_url=api_url,
        api_key=api_key,
        if_none_match=if_none_match,
        agent_slug=agent_slug,
        device_uuid=device_uuid,
        wait_seconds=wait_seconds,
    )

    if result.status == "updated" and result.policy is not None:
        _atomic_write_policy(result.policy)
        if result.etag:
            _save_etag(result.etag)
        logger.info(
            "policy updated (etag=%s, %d bytes)",
            result.etag,
            len(json.dumps(result.policy)),
        )
        # Side-fetch the origin-aware effective config (Phase 3a).
        # Best-effort; failures don't affect the legacy enforcement
        # path. Same etag boundary as the legacy fetch — if the
        # legacy etag advanced, the effective response advanced too.
        _fetch_and_write_effective(
            api_url=api_url,
            api_key=api_key,
            agent_slug=agent_slug,
        )
    elif result.status == "not_modified":
        logger.debug("policy unchanged (etag=%s)", if_none_match)
    elif result.status == "error":
        logger.warning("policy fetch failed: %s", result.error)

    return result


# === Main loop ===


def watch_policy(
    *,
    profile: str = "connect",
    poll_interval: float = DEFAULT_POLL_INTERVAL,
    agent_slug: Optional[str] = None,
    long_poll_seconds: int = 0,
) -> None:
    """Run the poller forever. Designed for launchd / Windows Service.

    Pulls api_key + api_url from env or ``~/.waxell/config`` ``[<profile>]``.
    Writes to ``~/.waxell/policy.json`` whenever the server returns a new
    etag; otherwise just sleeps.

    G2: ``long_poll_seconds > 0`` switches to long-poll mode — each
    request waits up to that many seconds for an etag change before
    returning. Cuts wakeup latency from ``poll_interval`` to "as soon
    as the policy changes." Defaults off; admin opts in via
    ``--long-poll``.

    G4: the daemon's hardware_uuid is sent as ``device=...`` so the
    response carries any pending EndpointCommand rows for this machine.
    """
    # Reuse the uploader's config resolution so a single ``[connect]``
    # section feeds both daemons.
    from .uploader import _hardware_uuid, _resolve_api_key_and_url

    api_key, api_url = _resolve_api_key_and_url(profile)
    if not api_key:
        raise RuntimeError(
            f"No API key found. Set WAXELL_API_KEY env var or [{profile}] "
            f"section in ~/.waxell/config."
        )

    device_uuid = _hardware_uuid() or None
    mode = "long-poll" if long_poll_seconds > 0 else "short-poll"

    logger.info(
        "policy poller starting; profile=%s api=%s mode=%s wait=%ds interval=%.0fs path=%s device=%s",
        profile,
        api_url,
        mode,
        long_poll_seconds,
        poll_interval,
        POLICY_PATH,
        device_uuid,
    )

    while True:
        try:
            result = poll_once(
                api_url=api_url,
                api_key=api_key,
                agent_slug=agent_slug,
                device_uuid=device_uuid,
                wait_seconds=long_poll_seconds,
            )
            # G4 — execute pending commands the server embedded in
            # the response. Each handler is best-effort and PATCHes
            # back done/failed so the queue drains on its own.
            if (
                result.status == "updated"
                and result.policy is not None
                and isinstance(result.policy.get("commands"), list)
            ):
                cmds = result.policy["commands"]
                if cmds:
                    from .command_runner import execute_all

                    summary = execute_all(
                        api_url=api_url, api_key=api_key, commands=cmds
                    )
                    logger.info("executed %d command(s): %s", len(cmds), summary)
        except Exception:
            # Belt-and-suspenders: poll_once swallows everything but a
            # logic bug shouldn't kill the daemon.
            logger.exception("poll cycle crashed; retrying after %.0fs", poll_interval)

        # In long-poll mode the server already held the connection up
        # to wait_seconds, so a short between-request gap is fine. In
        # short-poll mode we sleep the full interval.
        if long_poll_seconds > 0:
            time.sleep(min(poll_interval, 2.0))
        else:
            time.sleep(poll_interval)
