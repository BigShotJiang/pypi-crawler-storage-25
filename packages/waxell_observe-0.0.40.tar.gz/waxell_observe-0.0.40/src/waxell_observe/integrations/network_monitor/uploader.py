"""Network-monitor flow uploader.

Reads `os_log` (subsystem `dev.waxell.setup.flowmonitor`) for `ai-flow`
and `flow` log lines emitted by the system extension's `FilterDataProvider`,
batches them, and POSTs to `/api/waxell/v1/endpoint/flows`.

Design mirrors `cowork.audit_watcher`:
- Polls (not inotify / log stream) for simplicity and crash-resume semantics
- Cursor at `~/.waxell/network-monitor-cursor.json` storing last successfully
  uploaded timestamp. On crash/restart, resume from there. macOS persists
  os_log entries for hours, so the OS provides the durable buffer.
- Cursor only advances on successful POST. Duplicate posts during transient
  errors are acceptable (server is idempotent on (device, occurred_at,
  process_name, sni_hostname) at the dashboard level).
- Uses the existing tenant API key from `~/.waxell/config` `[connect]`
  section — same credential the cowork-watcher and claude-code hooks
  already use.

Linux/Windows note: this module is macOS-only (uses `log show`). Windows
gets its own ETW-based uploader in a future module.
"""

from __future__ import annotations

import json
import logging
import os
import platform
import re
import shutil
import subprocess
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import urllib.error
import urllib.request

logger = logging.getLogger(__name__)

# === Constants ===

SUBSYSTEM = "dev.waxell.setup.flowmonitor"
CURSOR_PATH = Path.home() / ".waxell" / "network-monitor-cursor.json"
CONFIG_PATH = Path.home() / ".waxell" / "config"
DEFAULT_BATCH_SIZE = 200
DEFAULT_FLUSH_INTERVAL = 30.0  # seconds
DEFAULT_POLL_INTERVAL = 5.0
INGEST_PATH = "/api/waxell/v1/endpoint/flows/"

# === Log line parsing ===

# `log show --style ndjson` emits per-line JSON like:
#   {"timestamp": "2026-05-02 15:11:55.263287-0400", ...,
#    "eventMessage": "ai-flow process=claude/2.1.126 sni=api.anthropic.com ...",
#    ...}
# The `eventMessage` is the format string our os_log emits. We parse the
# space-separated key=value pairs from there.
_KV_RE = re.compile(r"(\w+)=([^\s]+(?: [^\s=]+)*?)(?=\s+\w+=|\s*$)")
_AI_FLOW_PREFIX = "ai-flow"
_FLOW_PREFIX = "flow"


def _parse_log_message(message: str) -> Optional[dict]:
    """Extract our key=value fields from an os_log eventMessage string.

    Returns ``None`` if the line isn't one of our flow lines (so callers can
    skip it without raising).
    """
    if not isinstance(message, str):
        return None

    msg = message.strip()
    # Strip any leading "[subsystem:filter]" prefix that os_log inserts when
    # we're being verbose; the first word should be `ai-flow` or `flow`.
    if "ai-flow" in msg:
        kind = "ai-flow"
        msg = msg[msg.index("ai-flow") :]
    elif " flow " in msg or msg.startswith("flow "):
        kind = "flow"
        idx = msg.find("flow ")
        msg = msg[idx:]
    else:
        return None

    fields: dict = {"_kind": kind}
    for match in _KV_RE.finditer(msg):
        key, value = match.group(1), match.group(2).strip()
        fields[key] = value
    return fields


def _to_event(fields: dict, occurred_at: str, user_email: str) -> dict:
    """Map parsed os_log fields → ingest API event shape."""
    port_str = fields.get("port", "")
    try:
        port = int(port_str) if port_str else None
    except ValueError:
        port = None

    return {
        "user_email": user_email,
        "occurred_at": occurred_at,
        "process_name": fields.get("process", ""),
        # process_path isn't in our log emission yet — omit
        "process_path": "",
        "sni_hostname": fields.get("sni", ""),
        "destination_host": "",
        "destination_port": port,
        "protocol": fields.get("proto", ""),
        "ai_service": fields.get("service", ""),
        "matched_domain": "",
    }


# === os_log driver ===


def _log_show(start_iso: str) -> list[dict]:
    """Run `log show --style ndjson` for our subsystem, starting from
    ``start_iso``. Returns a list of parsed JSON entries.

    The Sequoia-era flag set is used (no `--subsystem` flag — that was
    removed; predicate-based filtering only).
    """
    if shutil.which("log") is None:
        raise RuntimeError("`log` command not found — macOS-only uploader")

    cmd = [
        "log",
        "show",
        "--style",
        "ndjson",
        "--info",
        "--predicate",
        f'subsystem == "{SUBSYSTEM}"',
        "--start",
        start_iso,
    ]
    proc = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        timeout=60,
        check=False,
    )
    if proc.returncode != 0:
        logger.warning(
            "log show exited %d: %s", proc.returncode, proc.stderr.strip()[:500]
        )
        return []

    out: list[dict] = []
    for line in proc.stdout.splitlines():
        line = line.strip()
        if not line or not line.startswith("{"):
            continue
        try:
            out.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return out


# === Cursor persistence ===


def _load_cursor() -> Optional[str]:
    """Returns ISO-8601 string of last-successfully-uploaded timestamp,
    or ``None`` if no cursor exists yet.
    """
    if not CURSOR_PATH.exists():
        return None
    try:
        return json.loads(CURSOR_PATH.read_text()).get("last_timestamp")
    except (OSError, json.JSONDecodeError):
        return None


def _normalize_log_timestamp(ts: str) -> str:
    """Reduce an os_log entry timestamp to the format `log show --start`
    accepts.

    Input examples:  "2026-05-03 18:08:54.872203-0400"
                     "2026-05-03 22:08:27.000000+0000"
                     "2026-05-03T22:08:27.872203Z"
    Output:          "2026-05-03 18:08:54-0400"

    Strips the microsecond fraction; preserves the date, time-to-second,
    and timezone offset. Tolerant of either `T` or space separator.
    """
    s = ts.strip()
    # Drop microsecond fraction if present.
    if "." in s:
        # Find the dot that introduces fractional seconds (between the
        # time and the timezone offset).
        dot_idx = s.rfind(".")
        # Locate the trailing tz marker (+, -, or Z).
        tz_idx = -1
        for i in range(len(s) - 1, dot_idx, -1):
            if s[i] in "+-Z":
                tz_idx = i
                break
        if tz_idx > 0:
            s = s[:dot_idx] + s[tz_idx:]
        else:
            s = s[:dot_idx]
    # log show wants a space, not a T.
    if "T" in s:
        s = s.replace("T", " ", 1)
    # Trailing Z → +0000 for log show's parser.
    if s.endswith("Z"):
        s = s[:-1] + "+0000"
    return s


def _save_cursor(timestamp_iso: str) -> None:
    CURSOR_PATH.parent.mkdir(parents=True, exist_ok=True)
    CURSOR_PATH.write_text(json.dumps({"last_timestamp": timestamp_iso}))


# === Config / device identity ===


def _read_config_section(section: str) -> dict:
    """Pull the [<section>] block out of ~/.waxell/config (INI-style)."""
    if not CONFIG_PATH.exists():
        return {}
    import configparser

    parser = configparser.ConfigParser()
    try:
        parser.read(CONFIG_PATH)
    except configparser.Error:
        return {}
    if section not in parser:
        return {}
    return dict(parser[section])


def _resolve_api_key_and_url(profile: str) -> tuple[str, str]:
    """Get api_key + api_url from env or config profile."""
    key = os.environ.get("WAXELL_API_KEY") or os.environ.get("WAX_API_KEY") or ""
    url = (
        os.environ.get("WAXELL_API_URL")
        or os.environ.get("WAX_API_URL")
        or "https://api.waxell.dev"
    )
    if key:
        return key, url

    cfg = _read_config_section(profile)
    return cfg.get("api_key", ""), cfg.get("api_url", url)


def _hardware_uuid() -> str:
    """Stable per-machine UUID. macOS: IOPlatformUUID.

    Use the **absolute path** to ioreg (`/usr/sbin/ioreg`). When the
    daemon runs from launchd / LaunchAgent / a context with a stripped
    PATH, just `["ioreg", ...]` raises FileNotFoundError → silent
    fallback to `str(uuid.getnode())` → orphan Device row in the
    cloud DB. Devastatingly subtle bug; force the absolute path.
    """
    if sys.platform != "darwin":
        # Windows/Linux fallback — not the canonical id but workable for
        # non-Mac dev. Windows uploader will replace this.
        return str(uuid.getnode())

    try:
        out = subprocess.check_output(
            ["/usr/sbin/ioreg", "-rd1", "-c", "IOPlatformExpertDevice"],
            text=True,
            timeout=5,
        )
        match = re.search(r'"IOPlatformUUID"\s*=\s*"([^"]+)"', out)
        if match:
            return match.group(1)
    except (subprocess.SubprocessError, OSError):
        pass
    # Last-resort fallback — should be unreachable on a healthy macOS
    # install. Logged at WARN by callers if this path is ever taken.
    return str(uuid.getnode())


def _device_payload() -> dict:
    return {
        "hardware_uuid": _hardware_uuid(),
        "hostname": platform.node() or "",
        "os": "macOS" if sys.platform == "darwin" else platform.system(),
        "os_version": platform.mac_ver()[0] or platform.release() or "",
    }


def _user_email_hint() -> str:
    """Best-effort user identity for events. Pulled from config; empty if
    not set. The OS audit-token-derived per-process email is more accurate
    but we don't have it from os_log today — treat the config user as a
    soft default."""
    return _read_config_section("connect").get("user_email", "")


# === Upload ===


def _post_batch(
    *, api_url: str, api_key: str, device: dict, events: list[dict]
) -> bool:
    """POST events to controlplane. Returns True on 2xx, False otherwise."""
    if not events:
        return True

    body = json.dumps({"device": device, "events": events}).encode("utf-8")
    req = urllib.request.Request(
        api_url.rstrip("/") + INGEST_PATH,
        data=body,
        method="POST",
        headers={
            "Content-Type": "application/json",
            "X-Wax-Key": api_key,
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            ok = 200 <= resp.status < 300
            if not ok:
                logger.warning("ingest returned %d", resp.status)
            return ok
    except urllib.error.HTTPError as e:
        logger.warning("ingest HTTPError %d: %s", e.code, e.reason)
        return False
    except urllib.error.URLError as e:
        logger.warning("ingest URLError: %s", e.reason)
        return False
    except OSError as e:
        logger.warning("ingest OSError: %s", e)
        return False


# === Main loop ===


def watch_flows(
    *,
    profile: str = "connect",
    poll_interval: float = DEFAULT_POLL_INTERVAL,
    flush_interval: float = DEFAULT_FLUSH_INTERVAL,
    batch_size: int = DEFAULT_BATCH_SIZE,
    verbose: bool = False,
) -> None:
    """Run the uploader loop. Blocks forever. Designed to be run as a
    launchd agent or under `wax network-monitor watch`.

    Reads tenant API key + URL from env or `~/.waxell/config` `[<profile>]`
    section. Polls os_log, batches, POSTs to `/api/waxell/v1/endpoint/flows`.
    Cursor file at `~/.waxell/network-monitor-cursor.json` survives restarts.
    """
    if sys.platform != "darwin":
        raise RuntimeError(
            "Network-monitor uploader is macOS-only. Windows uploader is a "
            "separate module (ETW-based)."
        )

    api_key, api_url = _resolve_api_key_and_url(profile)
    if not api_key:
        raise RuntimeError(
            f"No API key found. Set WAXELL_API_KEY env var or [{profile}] "
            f"section in ~/.waxell/config."
        )

    device = _device_payload()
    user_email_hint = _user_email_hint()

    # Resume from the last successful upload, or start "now" if first run.
    cursor = _load_cursor()
    if cursor is None:
        # `log show` won't tail forward without a start, so seed with "now".
        cursor = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S%z")
        _save_cursor(cursor)
        logger.info("first run — starting from %s", cursor)

    logger.info(
        "watching subsystem %s; cursor=%s; api=%s",
        SUBSYSTEM,
        cursor,
        api_url,
    )

    pending: list[dict] = []
    last_flush = time.monotonic()

    while True:
        try:
            entries = _log_show(cursor)
        except Exception:
            logger.exception("log show failed; retrying after %ss", poll_interval)
            time.sleep(poll_interval)
            continue

        new_events_this_round: list[tuple[str, dict]] = []
        for entry in entries:
            ts = entry.get("timestamp")
            msg = entry.get("eventMessage") or entry.get("composedMessage") or ""
            if not ts or not msg:
                continue
            fields = _parse_log_message(msg)
            if fields is None:
                continue
            # Only ship AI-catalog hits. Older extension builds also emit
            # plain `flow` lines for non-AI traffic; drop those here so
            # we never upload non-governed traffic, even on cached logs.
            if fields.get("_kind") != "ai-flow":
                continue
            event = _to_event(fields, occurred_at=ts, user_email=user_email_hint)
            new_events_this_round.append((ts, event))
            if verbose:
                logger.info(
                    "%s %s → %s [%s]",
                    ts,
                    event.get("process_name"),
                    event.get("sni_hostname"),
                    event.get("ai_service") or "-",
                )

        for ts, event in new_events_this_round:
            pending.append(event)

        # Flush by size or time.
        now = time.monotonic()
        should_flush = len(pending) >= batch_size or (
            pending and (now - last_flush) >= flush_interval
        )
        if should_flush:
            ok = _post_batch(
                api_url=api_url,
                api_key=api_key,
                device=device,
                events=pending,
            )
            if ok:
                # Advance cursor to the latest event timestamp we successfully
                # uploaded. Use either the last processed event ts, or "now"
                # if pending was already drained when we got here.
                #
                # `log show --start` accepts only `YYYY-MM-DD HH:MM:SS<tz>`
                # (no microseconds). os_log entries come back with the
                # microsecond fraction included, so we have to strip it
                # before re-feeding as the cursor — otherwise log show
                # rejects every subsequent run with "Failed conversion".
                if new_events_this_round:
                    cursor = _normalize_log_timestamp(new_events_this_round[-1][0])
                else:
                    cursor = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S%z")
                _save_cursor(cursor)
                pending.clear()
                last_flush = now
            else:
                # Don't advance cursor; retry on next loop iteration.
                logger.warning(
                    "ingest failed — keeping %d events in buffer; cursor unchanged",
                    len(pending),
                )

        time.sleep(poll_interval)
