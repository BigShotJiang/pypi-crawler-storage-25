"""G4 — daemon-side runner for `EndpointCommand` rows.

The policy poller surfaces pending commands in its response body; this
module dispatches them to handlers and PATCHes the controlplane back
with `done` / `failed`. Handlers are kept small + side-effect-free
where possible so each one is testable in isolation.

Built-in commands (extensible via `register_handler(name, fn)`):

- ``refresh_policy`` — invalidate the local etag cache and force the
  next poll to fetch a fresh policy. Cheap and safe.
- ``kill_process`` — graceful SIGTERM (escalate to SIGKILL after
  ``args.grace_seconds``) for processes whose name matches
  ``args.process_name``. Best-effort, never raises.
- ``uninstall_hook`` — remove the claude-code or cowork
  `~/.claude/settings.json` hook the install added. Stub for v1 —
  logs the request and returns ``{"would_remove": [...]}`` without
  touching the file.
- ``self_uninstall`` — stub for v1 — logs and returns the path the
  uninstall would target, without doing it. Production needs an
  audit-trailed elevator step before this can flip live.

Unknown commands return `failed` with `error_message` set so the
controlplane can render the rejection in the audit trail.
"""

from __future__ import annotations

import json
import logging
import os
import signal
import time
import urllib.error
import urllib.request
from typing import Callable

logger = logging.getLogger(__name__)

PATCH_PATH = "/api/waxell/v1/endpoint/commands/"
DEFAULT_PATCH_TIMEOUT = 15.0


# === Handler registry ===

CommandHandler = Callable[[dict], dict]
_REGISTRY: dict[str, CommandHandler] = {}


def register_handler(name: str, fn: CommandHandler) -> None:
    """Register a callable for a command name. Last registration wins
    so tests can swap in mocks via the same surface."""
    _REGISTRY[name] = fn


def get_handler(name: str) -> CommandHandler | None:
    return _REGISTRY.get(name)


# === Built-in handlers ===


def _handle_refresh_policy(args: dict) -> dict:
    """Invalidate the local etag cache. Next poll fetches fresh."""
    from .policy_poller import ETAG_PATH

    try:
        if ETAG_PATH.exists():
            ETAG_PATH.unlink()
        return {"refreshed": True}
    except OSError as e:
        return {"refreshed": False, "error": str(e)}


def _handle_kill_process(args: dict) -> dict:
    """Graceful SIGTERM → escalate to SIGKILL if the process is still
    running after `grace_seconds`. Matches by exact `comm` name (no
    glob) — keeps blast radius tight; admin specifies precisely.

    Caveats: skipped on Windows (uses /F taskkill via subprocess —
    not yet implemented). On Mac/Linux uses os.kill.
    """
    import platform
    import subprocess

    name = (args.get("process_name") or "").strip()
    if not name:
        return {"killed": [], "error": "process_name required"}

    grace = max(1, min(int(args.get("grace_seconds", 5)), 60))
    killed: list[int] = []

    if platform.system() == "Windows":
        # Best-effort taskkill — won't enumerate PIDs but covers v1.
        try:
            subprocess.run(["taskkill", "/IM", name, "/T"], timeout=10, check=False)
            time.sleep(grace)
            subprocess.run(
                ["taskkill", "/IM", name, "/T", "/F"], timeout=10, check=False
            )
            return {"killed": [name], "platform": "windows"}
        except Exception as e:
            return {"killed": [], "error": str(e)}

    # Unix path: pgrep + os.kill SIGTERM, wait, SIGKILL stragglers.
    try:
        out = subprocess.check_output(["pgrep", "-x", name], text=True, timeout=5)
    except (subprocess.SubprocessError, FileNotFoundError):
        out = ""
    pids = [int(p) for p in out.split() if p.isdigit()]
    for pid in pids:
        try:
            os.kill(pid, signal.SIGTERM)
        except (ProcessLookupError, PermissionError):
            continue
    time.sleep(grace)
    for pid in pids:
        try:
            os.kill(pid, signal.SIGKILL)
        except ProcessLookupError:
            killed.append(pid)  # already exited cleanly
        except PermissionError:
            continue
        else:
            killed.append(pid)
    return {"killed": killed, "matched": pids}


def _handle_uninstall_hook(args: dict) -> dict:
    """Stub — logs the would-be-removed paths without touching them.
    Real uninstall lives behind a separate elevator flag in v2."""
    paths = args.get("paths") or [
        str(os.path.expanduser("~/.claude/settings.json")),
    ]
    logger.warning("uninstall_hook (stub): would remove %s", paths)
    return {"would_remove": paths, "stub": True}


def _handle_self_uninstall(args: dict) -> dict:
    """Stub — logs the daemon path. Real uninstall ships in v2 with
    an audit-trailed elevator step."""
    logger.warning("self_uninstall (stub): would remove launchd plists + binary")
    return {"stub": True}


# Register defaults on import.
register_handler("refresh_policy", _handle_refresh_policy)
register_handler("kill_process", _handle_kill_process)
register_handler("uninstall_hook", _handle_uninstall_hook)
register_handler("self_uninstall", _handle_self_uninstall)


# === PATCH back to controlplane ===


def _patch_command(
    *,
    api_url: str,
    api_key: str,
    command_id: str,
    new_status: str,
    result: dict | None = None,
    error_message: str = "",
    timeout: float = DEFAULT_PATCH_TIMEOUT,
) -> bool:
    """Mark a command as done/failed on the server. Returns True on 2xx."""
    body = json.dumps(
        {
            "id": command_id,
            "status": new_status,
            "result": result or {},
            "error_message": error_message,
        }
    ).encode("utf-8")
    req = urllib.request.Request(
        api_url.rstrip("/") + PATCH_PATH,
        data=body,
        method="PATCH",
        headers={
            "Content-Type": "application/json",
            "X-Wax-Key": api_key,
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return 200 <= resp.status < 300
    except urllib.error.HTTPError as e:
        logger.warning("PATCH command %s: HTTP %d %s", command_id, e.code, e.reason)
        return False
    except (urllib.error.URLError, OSError) as e:
        logger.warning("PATCH command %s: %s", command_id, e)
        return False


# === Top-level dispatch ===


def execute_one(
    *,
    api_url: str,
    api_key: str,
    command: dict,
) -> str:
    """Run one command from the policy response. Returns the new status
    (`done` or `failed`); the caller doesn't need to interpret further.

    `command` is the dict the server embedded in the guard-config
    response or the dedicated commands endpoint, e.g.::

        {
          "id": "<uuid>",
          "command": "kill_process",
          "args": {"process_name": "cursor"},
          "reason": "policy violation: rate-limit exceeded"
        }
    """
    cmd_id = (command.get("id") or "").strip()
    cmd_name = (command.get("command") or "").strip()
    args = command.get("args") or {}
    if not cmd_id or not cmd_name:
        return "failed"

    handler = get_handler(cmd_name)
    if handler is None:
        _patch_command(
            api_url=api_url,
            api_key=api_key,
            command_id=cmd_id,
            new_status="failed",
            error_message=f"unknown command: {cmd_name}",
        )
        return "failed"

    try:
        result = handler(args) or {}
        new_status = "done"
        error_message = ""
    except Exception as e:
        # Don't crash the daemon over one command. Surface the error.
        logger.exception("command %s (%s) raised", cmd_id, cmd_name)
        result = {}
        new_status = "failed"
        error_message = f"{type(e).__name__}: {e}"[:1500]

    _patch_command(
        api_url=api_url,
        api_key=api_key,
        command_id=cmd_id,
        new_status=new_status,
        result=result,
        error_message=error_message,
    )
    return new_status


def execute_all(*, api_url: str, api_key: str, commands: list[dict]) -> dict[str, int]:
    """Run a batch of commands. Returns a `{status: count}` summary."""
    summary = {"done": 0, "failed": 0}
    for cmd in commands:
        try:
            outcome = execute_one(api_url=api_url, api_key=api_key, command=cmd)
        except Exception:
            logger.exception("execute_one crashed for command %s", cmd.get("id"))
            outcome = "failed"
        summary[outcome] = summary.get(outcome, 0) + 1
    return summary
