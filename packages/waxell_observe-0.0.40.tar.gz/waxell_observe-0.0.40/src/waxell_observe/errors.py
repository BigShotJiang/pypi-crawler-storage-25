"""Errors raised by waxell-observe."""


class ObserveError(Exception):
    """Base error for waxell-observe."""

    pass


class PolicyViolationError(ObserveError):
    """Raised when a policy check blocks execution."""

    def __init__(self, message: str, policy_result=None):
        super().__init__(message)
        self.policy_result = policy_result


class ConfigurationError(ObserveError):
    """Raised when the client is not properly configured."""

    pass


class PromptNotFoundError(ObserveError):
    """Raised by ``get_prompt()`` when the prompt, label, or version doesn't exist.

    Attributes:
        name: The prompt name that was requested.
        label: The label requested (empty if none was given).
        version: The version requested (0 if none was given).
        status_code: The HTTP status returned by the controlplane, when known.
    """

    def __init__(
        self,
        name: str,
        label: str = "",
        version: int = 0,
        status_code: int | None = None,
        detail: str = "",
    ):
        self.name = name
        self.label = label
        self.version = version
        self.status_code = status_code
        self.detail = detail

        if version:
            what = f"version {version}"
        elif label:
            what = f"label '{label}'"
        else:
            what = "any version"
        message = f"Prompt '{name}' / {what} not found"
        if detail:
            message = f"{message}: {detail}"
        super().__init__(message)
