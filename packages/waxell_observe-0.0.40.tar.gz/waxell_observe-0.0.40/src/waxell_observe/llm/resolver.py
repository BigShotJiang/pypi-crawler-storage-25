"""Model → instance resolution for the observe-side dispatcher.

Mirrors the runtime resolver's contract (qualified syntax, group
expansion, default-for-kind heuristic) but operates on a snapshot
``Manifest`` pulled over HTTP rather than the Django ORM.
"""

from __future__ import annotations

from dataclasses import dataclass

from .types import Manifest, ProviderInstance


@dataclass(frozen=True)
class Candidate:
    """One step in the dispatch fallback chain — a specific instance to
    dispatch against, with the provider-side model id to use."""

    instance: ProviderInstance
    provider_model_id: str

    @property
    def kind(self) -> str:
        return self.instance.kind

    @property
    def instance_id(self) -> str:
        return self.instance.instance_id


class ModelNotResolvable(Exception):
    """Raised when a model spec can't be mapped to any instance.

    Common causes: the model name doesn't match any TenantModel and no
    default instance exists for its kind, the qualified instance_id
    doesn't exist, or the named group is empty.
    """


# Heuristic: prefix → kind. Used as a last-ditch fallback when a model
# name is unqualified and not registered as a TenantModel. Keys matched
# longest-first via sort.
_PREFIX_TO_KIND: tuple[tuple[str, str], ...] = (
    ("claude-", "anthropic"),
    ("anthropic.", "anthropic"),
    ("gemini-", "gemini"),
    ("models/gemini-", "gemini"),
    ("command-", "cohere"),
    ("mistral-", "mistral"),
    ("open-mistral-", "mistral"),
    ("jamba-", "ai21"),
    ("nvidia/", "nvidia"),
    ("grok-", "xai"),
    ("o1-", "openai"),
    ("o3-", "openai"),
    ("o4-", "openai"),
    ("gpt-", "openai"),
    ("text-embedding-", "openai"),
)


def _kind_for_unqualified_model(model_id: str) -> str:
    """Best-effort kind inference from the model name. Used only when
    the manifest has no TenantModel registered for ``model_id``."""
    for prefix, kind in sorted(_PREFIX_TO_KIND, key=lambda p: -len(p[0])):
        if model_id.startswith(prefix):
            return kind
    return "openai"  # the historic default


def resolve_chain(manifest: Manifest, model: str) -> list[Candidate]:
    """Resolve ``model`` to an ordered chain of dispatch candidates.

    Resolution rules (first match wins):

    1. ``"group:<group_id>"`` — expand to the group's entries in
       declared order. Each entry maps to an instance via ``instance_id``.
    2. ``"<instance_id>/<model_id>"`` — qualified syntax; resolve
       the instance directly, use the provided ``model_id``.
    3. Plain ``model_id`` matching a ``TenantModel`` — use its bound
       instance and ``provider_model_id``.
    4. Plain ``model_id`` with no TenantModel — find a default
       instance for the kind inferred from the name (single-step chain).

    Disabled instances are filtered at the manifest source (Phase A),
    so any candidate that comes back here is dispatchable on capability
    grounds alone.

    Raises:
        ModelNotResolvable: nothing in the manifest matches.
    """
    if not model:
        raise ModelNotResolvable("model is empty")

    if model.startswith("group:"):
        return _resolve_group(manifest, model[len("group:") :])

    if "/" in model:
        return _resolve_qualified(manifest, model)

    return _resolve_unqualified(manifest, model)


# ---------------------------------------------------------------------------
# Strategies
# ---------------------------------------------------------------------------


def _resolve_group(manifest: Manifest, group_id: str) -> list[Candidate]:
    group = manifest.find_group(group_id)
    if group is None:
        raise ModelNotResolvable(
            f"group '{group_id}' not found in manifest. Configure it in "
            f"the controlplane at /settings/llm-routing or check that the "
            f"group is enabled."
        )

    chain: list[Candidate] = []
    for entry in group.entries:
        inst = manifest.find_instance(entry.instance_id)
        if inst is None:
            # Disabled / removed since the group was last edited. Skip
            # silently — the group can still satisfy from later entries.
            continue
        chain.append(Candidate(instance=inst, provider_model_id=entry.model_id))

    if not chain:
        raise ModelNotResolvable(
            f"group '{group_id}' has no usable entries. All instances may "
            f"have been disabled."
        )
    return chain


def _resolve_qualified(manifest: Manifest, model: str) -> list[Candidate]:
    instance_id, model_id = model.split("/", 1)
    inst = manifest.find_instance(instance_id)
    if inst is None:
        raise ModelNotResolvable(
            f"instance '{instance_id}' not found in manifest. Either it "
            f"doesn't exist or it's disabled. List your instances with "
            f"`wax provider instance list`."
        )
    return [Candidate(instance=inst, provider_model_id=model_id)]


def _resolve_unqualified(manifest: Manifest, model_id: str) -> list[Candidate]:
    tm = manifest.find_tenant_model(model_id)
    if tm is not None:
        inst = manifest.find_instance(tm.instance_id)
        if inst is None:
            raise ModelNotResolvable(
                f"tenant model '{model_id}' references instance "
                f"'{tm.instance_id}' which is not in the manifest "
                f"(disabled or removed?)."
            )
        return [Candidate(instance=inst, provider_model_id=tm.provider_model_id)]

    # No TenantModel registered. Fall back to default-for-kind by
    # heuristic. This is what makes naked "gpt-4o" / "claude-3-5-sonnet"
    # work without explicit registration.
    kind = _kind_for_unqualified_model(model_id)
    inst = manifest.find_default_for_kind(kind)
    if inst is None:
        raise ModelNotResolvable(
            f"model '{model_id}' is not a registered TenantModel and no "
            f"default instance exists for kind '{kind}'. Either register "
            f"the model in /settings/llm-routing or set a default "
            f"instance for kind '{kind}'."
        )
    return [Candidate(instance=inst, provider_model_id=model_id)]
