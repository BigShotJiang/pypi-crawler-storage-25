"""Per-kind client builders + secret resolution.

Lazy SDK imports — a missing optional dep only fails when the user
actually invokes that kind. The ``waxell-observe[<kind>]`` extras in
``pyproject.toml`` give users a one-liner install for each provider.

OpenAI-compatible kinds (Fireworks, Together, Groq, xAI, Mistral, AI21,
NVIDIA, Replicate, Ollama, vLLM, HF TGI) all use the ``openai`` SDK
with ``base_url=instance.base_url``. They live alongside ``openai`` and
``openai_compat`` in :data:`_OPENAI_COMPATIBLE_KINDS`.

Phase C ships chat-completion dispatch for the OpenAI-compat family
plus Anthropic. Bedrock, Vertex, Cohere, Gemini, Azure are stubs that
raise ``UnsupportedKind`` until Phase G or a follow-up.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any

from .resolver import Candidate

# Kinds that talk OpenAI's HTTP wire format. We use the ``openai`` SDK
# with ``base_url=instance.base_url`` for all of them — no separate
# pip install per provider.
_OPENAI_COMPATIBLE_KINDS: frozenset[str] = frozenset(
    {
        "openai",
        "openai_compat",
        "fireworks",
        "together",
        "groq",
        "xai",
        "mistral",
        "ai21",
        "nvidia",
        "replicate",
        "ollama",
        "vllm",
        "huggingface_tgi",
    }
)

# Kinds with their own SDKs that we DON'T support yet in the Phase C
# chat path. Each will get a builder in Phase G.
_DEFERRED_KINDS: frozenset[str] = frozenset(
    {"bedrock", "vertex", "azure_openai", "cohere", "gemini"}
)


class SecretNotInEnvironment(Exception):
    """Raised when a provider instance references an env var that
    isn't set in the calling process. Verbatim message per
    OBSERVE_DISPATCH_PLAN locked decision Q4."""


class UnsupportedKind(Exception):
    """The instance's ``kind`` doesn't have a Phase C client builder
    yet. Follow-up phases add Bedrock, Vertex, Cohere, Gemini, Azure."""


class MissingProviderSDK(ImportError):
    """The user invoked a provider whose SDK isn't installed. Surfaces
    the right ``pip install`` command."""


@dataclass
class _BuiltClient:
    kind: str
    instance_id: str
    sdk_client: Any  # openai.OpenAI or anthropic.Anthropic etc.
    api_key: str  # used in error reports — not for logging


def _resolve_secret(candidate: Candidate) -> str:
    """Read the API key from ``os.environ[secret_ref]``. Verbatim
    error message from the plan."""
    secret_ref = candidate.instance.secret_ref
    if not secret_ref:
        raise SecretNotInEnvironment(
            f"Provider instance '{candidate.instance_id}' has no "
            f"secret_ref configured. Set one in the controlplane at "
            f"/settings/llm-routing."
        )
    val = os.environ.get(secret_ref, "")
    if not val:
        raise SecretNotInEnvironment(
            f"Provider instance '{candidate.instance_id}' references "
            f"env var {secret_ref} which is not set in this process. "
            f"Either set the env var, or change the instance's "
            f"secret_ref in the controlplane at /settings/llm-routing."
        )
    return val


def build_client(candidate: Candidate) -> _BuiltClient:
    """Return an SDK client wired up to dispatch against ``candidate``.

    Lazily imports the right SDK; raises ``MissingProviderSDK`` with
    a clear pip install hint if the user hasn't installed it.
    """
    kind = candidate.kind
    api_key = _resolve_secret(candidate)

    if kind in _OPENAI_COMPATIBLE_KINDS:
        return _build_openai_compatible(candidate, api_key)

    if kind == "anthropic":
        return _build_anthropic(candidate, api_key)

    if kind in _DEFERRED_KINDS:
        raise UnsupportedKind(
            f"Provider kind '{kind}' is not yet supported by the "
            f"observe SDK dispatcher. Phase C ships OpenAI + Anthropic + "
            f"OpenAI-compatible providers; Bedrock, Vertex, Cohere, "
            f"Gemini, and Azure are coming in Phase G. Track progress "
            f"at agentforge/areas/llm-providers/plans/OBSERVE_DISPATCH_PLAN.md"
        )

    raise UnsupportedKind(
        f"Unknown provider kind '{kind}' on instance "
        f"'{candidate.instance_id}'. Either typo'd in /settings/"
        f"llm-routing or this kind isn't implemented yet."
    )


# ---------------------------------------------------------------------------
# Per-kind builders
# ---------------------------------------------------------------------------


def _build_openai_compatible(candidate: Candidate, api_key: str) -> _BuiltClient:
    try:
        import openai
    except ImportError as e:  # pragma: no cover — install-time error
        raise MissingProviderSDK(
            f"The OpenAI SDK is required to dispatch to "
            f"'{candidate.instance_id}' (kind={candidate.kind}). "
            f"Install: pip install 'waxell-observe[openai]'"
        ) from e

    base_url = candidate.instance.base_url or None  # SDK default if blank
    client = openai.OpenAI(api_key=api_key, base_url=base_url)
    return _BuiltClient(
        kind=candidate.kind,
        instance_id=candidate.instance_id,
        sdk_client=client,
        api_key=api_key,
    )


def _build_anthropic(candidate: Candidate, api_key: str) -> _BuiltClient:
    try:
        import anthropic
    except ImportError as e:  # pragma: no cover
        raise MissingProviderSDK(
            f"The Anthropic SDK is required to dispatch to "
            f"'{candidate.instance_id}'. "
            f"Install: pip install 'waxell-observe[anthropic]'"
        ) from e

    base_url = candidate.instance.base_url or None
    if base_url:
        client = anthropic.Anthropic(api_key=api_key, base_url=base_url)
    else:
        client = anthropic.Anthropic(api_key=api_key)
    return _BuiltClient(
        kind=candidate.kind,
        instance_id=candidate.instance_id,
        sdk_client=client,
        api_key=api_key,
    )


# ---------------------------------------------------------------------------
# Retryable error classification
# ---------------------------------------------------------------------------


def is_retryable(exc: BaseException) -> bool:
    """Should we walk the chain past this error?

    True for transient/retryable: rate limits, server errors, timeouts,
    connection errors. False for caller bugs (auth, bad request,
    missing model on this provider).

    The SDK's own retry logic handles tight retries (3x with backoff);
    we only "retry" by moving to a different instance entirely.
    """
    # OpenAI / OpenAI-compatible
    try:
        import openai

        if isinstance(
            exc,
            (
                openai.APIConnectionError,
                openai.APITimeoutError,
                openai.RateLimitError,
                openai.InternalServerError,
            ),
        ):
            return True
        # Auth / bad-request / not-found — non-retryable
        if isinstance(
            exc,
            (
                openai.AuthenticationError,
                openai.PermissionDeniedError,
                openai.BadRequestError,
            ),
        ):
            return False
        # NotFoundError — model isn't on THIS provider — try next in chain
        if isinstance(exc, openai.NotFoundError):
            return True
    except ImportError:
        pass

    # Anthropic
    try:
        import anthropic

        if isinstance(
            exc,
            (
                anthropic.APIConnectionError,
                anthropic.APITimeoutError,
                anthropic.RateLimitError,
                anthropic.InternalServerError,
            ),
        ):
            return True
        if isinstance(
            exc,
            (
                anthropic.AuthenticationError,
                anthropic.PermissionDeniedError,
                anthropic.BadRequestError,
            ),
        ):
            return False
        if isinstance(exc, anthropic.NotFoundError):
            return True
    except ImportError:
        pass

    # Network-level (httpx) — definitely retryable
    try:
        import httpx

        if isinstance(exc, (httpx.ConnectError, httpx.TimeoutException)):
            return True
    except ImportError:  # pragma: no cover
        pass

    # Unknown — be conservative and don't fall through. If users see
    # legitimate errors that should fall through, we add them above.
    return False
