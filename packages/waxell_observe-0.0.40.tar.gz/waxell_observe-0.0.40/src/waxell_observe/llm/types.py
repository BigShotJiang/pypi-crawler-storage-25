"""Typed dataclasses for the LLM-config manifest.

Mirrors the JSON shape returned by
``GET /api/v1/observe/llm-config/manifest/`` (controlplane Phase A).

Frozen so callers can pass them around safely.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


@dataclass(frozen=True)
class ProviderInstance:
    """A configured LLM provider account on this tenant.

    The dispatcher resolves a model call to one of these instances and
    uses ``base_url`` + the env var named in ``secret_ref`` to talk to
    the provider.
    """

    instance_id: str
    kind: str
    base_url: str
    secret_ref: str
    capabilities: dict
    extra_config: dict
    is_default_for_kind: bool
    catalog_id: str
    catalog_version: int

    @classmethod
    def from_dict(cls, d: dict) -> "ProviderInstance":
        return cls(
            instance_id=d.get("instance_id", ""),
            kind=d.get("kind", ""),
            base_url=d.get("base_url", "") or "",
            secret_ref=d.get("secret_ref", "") or "",
            capabilities=d.get("capabilities") or {},
            extra_config=d.get("extra_config") or {},
            is_default_for_kind=bool(d.get("is_default_for_kind", False)),
            catalog_id=d.get("catalog_id", "") or "",
            catalog_version=int(d.get("catalog_version", 0) or 0),
        )


@dataclass(frozen=True)
class TenantModel:
    """Maps a user-facing ``model_id`` to the instance that backs it
    plus the provider-side model name (``provider_model_id``)."""

    model_id: str
    instance_id: str
    provider_model_id: str
    supports_tools: bool
    supports_json: bool
    supports_streaming: bool
    context_window: Optional[int]

    @classmethod
    def from_dict(cls, d: dict) -> "TenantModel":
        return cls(
            model_id=d.get("model_id", ""),
            instance_id=d.get("instance_id", "") or "",
            provider_model_id=(d.get("provider_model_id") or d.get("model_id") or ""),
            supports_tools=bool(d.get("supports_tools", False)),
            supports_json=bool(d.get("supports_json", False)),
            supports_streaming=bool(d.get("supports_streaming", True)),
            context_window=d.get("context_window"),
        )


@dataclass(frozen=True)
class ModelGroupEntry:
    position: int
    instance_id: str
    model_id: str

    @classmethod
    def from_dict(cls, d: dict) -> "ModelGroupEntry":
        return cls(
            position=int(d.get("position", 0)),
            instance_id=d.get("instance_id", ""),
            model_id=d.get("model_id", ""),
        )


@dataclass(frozen=True)
class ModelGroup:
    """An ordered cross-provider fallback chain. Reference in dispatch
    as ``model="group:<group_id>"``."""

    group_id: str
    display_name: str
    entries: tuple[ModelGroupEntry, ...]

    @classmethod
    def from_dict(cls, d: dict) -> "ModelGroup":
        return cls(
            group_id=d.get("group_id", ""),
            display_name=d.get("display_name", "") or "",
            entries=tuple(
                ModelGroupEntry.from_dict(e) for e in (d.get("entries") or [])
            ),
        )


@dataclass(frozen=True)
class ModelCapabilityOverride:
    """Per-(instance, model_id) tri-state pin for capability flags.

    ``None`` for any boolean field means "no override; use instance
    default." ``True``/``False`` means override.
    """

    instance_id: str
    model_id: str
    native_tools: Optional[bool]
    json_mode: Optional[bool]
    streaming: Optional[bool]
    supports_system_prompt: Optional[bool]
    max_context_tokens: Optional[int]

    @classmethod
    def from_dict(cls, d: dict) -> "ModelCapabilityOverride":
        return cls(
            instance_id=d.get("instance_id", ""),
            model_id=d.get("model_id", ""),
            native_tools=d.get("native_tools"),
            json_mode=d.get("json_mode"),
            streaming=d.get("streaming"),
            supports_system_prompt=d.get("supports_system_prompt"),
            max_context_tokens=d.get("max_context_tokens"),
        )


@dataclass(frozen=True)
class Manifest:
    """Bundled snapshot of LLM dispatch config for a tenant."""

    schema_version: int
    tenant_id: str
    tenant_slug: str
    generated_at: str
    instances: tuple[ProviderInstance, ...] = field(default_factory=tuple)
    tenant_models: tuple[TenantModel, ...] = field(default_factory=tuple)
    groups: tuple[ModelGroup, ...] = field(default_factory=tuple)
    capability_overrides: tuple[ModelCapabilityOverride, ...] = field(
        default_factory=tuple
    )

    @classmethod
    def from_dict(cls, d: dict) -> "Manifest":
        return cls(
            schema_version=int(d.get("schema_version", 0)),
            tenant_id=d.get("tenant_id", ""),
            tenant_slug=d.get("tenant_slug", ""),
            generated_at=d.get("generated_at", ""),
            instances=tuple(
                ProviderInstance.from_dict(i) for i in (d.get("instances") or [])
            ),
            tenant_models=tuple(
                TenantModel.from_dict(m) for m in (d.get("tenant_models") or [])
            ),
            groups=tuple(ModelGroup.from_dict(g) for g in (d.get("groups") or [])),
            capability_overrides=tuple(
                ModelCapabilityOverride.from_dict(o)
                for o in (d.get("capability_overrides") or [])
            ),
        )

    def find_instance(self, instance_id: str) -> Optional[ProviderInstance]:
        return next((i for i in self.instances if i.instance_id == instance_id), None)

    def find_default_for_kind(self, kind: str) -> Optional[ProviderInstance]:
        return next(
            (i for i in self.instances if i.kind == kind and i.is_default_for_kind),
            None,
        )

    def find_tenant_model(self, model_id: str) -> Optional[TenantModel]:
        return next((m for m in self.tenant_models if m.model_id == model_id), None)

    def find_group(self, group_id: str) -> Optional[ModelGroup]:
        return next((g for g in self.groups if g.group_id == group_id), None)

    def find_capability_override(
        self, instance_id: str, model_id: str
    ) -> Optional[ModelCapabilityOverride]:
        return next(
            (
                o
                for o in self.capability_overrides
                if o.instance_id == instance_id and o.model_id == model_id
            ),
            None,
        )
