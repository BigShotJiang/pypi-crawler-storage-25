"""Phase C dispatcher — chat-completion mode against OpenAI + Anthropic
+ OpenAI-compatible providers.

Walks the resolved chain, builds a client per candidate, calls the
underlying SDK. Returns the SDK's native response object so callers
can use ``.choices[0].message.content`` (OpenAI) or ``.content[0].text``
(Anthropic) exactly as before.

Phase D adds JSON + tool modes (``waxell.llm.json`` / ``waxell.llm.tool``).
Phase E adds the ``_dispatch_in_flight`` context-var so instrumentors
don't double-record.
"""

from __future__ import annotations

import logging
from typing import Any, Optional

from waxell_observe.instrumentors._dispatch_flag import dispatch_in_flight_token

from .capability import Mode, filter_chain_for_mode
from .clients import (
    MissingProviderSDK,
    SecretNotInEnvironment,
    UnsupportedKind,
    build_client,
    is_retryable,
)
from .manifest import get_default_client as _get_manifest_client
from .resolver import Candidate, resolve_chain
from .types import Manifest

logger = logging.getLogger(__name__)


__all__ = [
    "DispatchError",
    "NoCandidateForMode",
    "NoProviderAvailable",
    "DispatchAttempt",
    "DispatchNotImplemented",
    "call",
    "text",
    "json",
    "tool",
]


class DispatchError(Exception):
    """Base class for dispatch-side errors."""


class NoCandidateForMode(DispatchError):
    """The resolved chain exists but no entry supports the requested
    mode (e.g. asked for ``mode='tool'`` but every candidate's
    capability flag says no native tools)."""


class NoProviderAvailable(DispatchError):
    """Walked every candidate; every one failed with a retryable error.
    Last error is chained as ``__cause__``."""

    def __init__(self, model: str, attempted: list["DispatchAttempt"]):
        self.model = model
        self.attempted = attempted
        names = [
            f"{a.instance_id}/{a.provider_model_id} ({type(a.error).__name__})"
            for a in attempted
        ]
        super().__init__(
            f"all dispatch candidates failed for model={model!r}: " + ", ".join(names)
        )


class DispatchAttempt:
    """Record of one attempt against one candidate. Returned in
    ``NoProviderAvailable.attempted`` and exposed for telemetry."""

    __slots__ = ("instance_id", "provider_model_id", "kind", "error")

    def __init__(
        self,
        candidate: Candidate,
        error: BaseException,
    ) -> None:
        self.instance_id = candidate.instance_id
        self.provider_model_id = candidate.provider_model_id
        self.kind = candidate.kind
        self.error = error

    def __repr__(self) -> str:  # pragma: no cover
        return (
            f"DispatchAttempt(instance={self.instance_id}, "
            f"model={self.provider_model_id}, kind={self.kind}, "
            f"error={type(self.error).__name__}: {self.error})"
        )


# Kept as a typed alias so existing Phase B callers that catch
# ``DispatchNotImplemented`` continue working — we don't raise it now,
# but the symbol still exists.
class DispatchNotImplemented(NotImplementedError):
    """Legacy Phase B sentinel. Phase C+ paths don't raise this."""


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def call(
    *,
    model: str,
    messages: list[dict[str, Any]],
    tools: Optional[list[dict[str, Any]]] = None,
    mode: Mode = "chat",
    manifest: Optional[Manifest] = None,
    **kwargs: Any,
) -> Any:
    """Dispatch a chat-completion call. Returns the underlying SDK's
    response object (no wrapper).

    Args:
        model: Either an unqualified model id (``"gpt-4o"``), a
            qualified ``"<instance_id>/<model_id>"``, or a group
            reference (``"group:<group_id>"``).
        messages: OpenAI-style list of ``{"role", "content"}`` dicts.
            Translated to Anthropic shape on Anthropic instances.
        tools: Optional OpenAI-style tool schemas. Capability filter
            uses presence of ``tools`` to bias toward instances that
            advertise ``native_tools``.
        mode: ``"chat"`` (default), ``"json"``, or ``"tool"``. Drives
            the capability filter.
        manifest: Override the cached manifest (mostly for tests).
        **kwargs: Forwarded to the underlying SDK call (temperature,
            max_tokens, response_format, top_p, etc.).

    Raises:
        ModelNotResolvable: model spec doesn't map to anything in the manifest.
        NoCandidateForMode: chain exists but no entry supports the mode.
        NoProviderAvailable: every candidate failed with a retryable error.
        SecretNotInEnvironment: an instance's ``secret_ref`` env var is unset.
        UnsupportedKind: an instance's ``kind`` doesn't have a Phase C builder.
        MissingProviderSDK: the right provider SDK isn't installed.
    """
    if mode == "tool" and not tools:
        # Treat tool mode without tools as chat — the user just wants
        # to use a tools-capable provider but not actually pass tools.
        # Keep capability filter strict.
        pass

    chain = _resolve_for_call(model, manifest=manifest)
    chain = filter_chain_for_mode(_active_manifest(manifest), chain, mode)
    if not chain:
        raise NoCandidateForMode(
            f"no candidate in the chain for model={model!r} supports "
            f"mode={mode!r}. Check capability flags on the instances "
            f"or add a ModelCapabilityOverride."
        )

    attempts: list[DispatchAttempt] = []
    for candidate in chain:
        try:
            client = build_client(candidate)
        except (SecretNotInEnvironment, UnsupportedKind, MissingProviderSDK):
            # These are user-config errors — surface immediately. Don't
            # walk past them; the next instance may have the same issue.
            raise

        try:
            with dispatch_in_flight_token():
                return _invoke_chat(
                    client.sdk_client,
                    client.kind,
                    candidate.provider_model_id,
                    messages=messages,
                    tools=tools,
                    mode=mode,
                    **kwargs,
                )
        except BaseException as exc:
            attempts.append(DispatchAttempt(candidate, exc))
            if is_retryable(exc):
                logger.info(
                    "Dispatch fallback: %s/%s failed with %s; trying next candidate",
                    candidate.instance_id,
                    candidate.provider_model_id,
                    type(exc).__name__,
                )
                continue
            # Hard error — don't fall through. Surface immediately.
            raise

    # Exhausted chain
    raise NoProviderAvailable(model=model, attempted=attempts) from attempts[-1].error


def text(
    *,
    model: str,
    messages: list[dict[str, Any]],
    **kwargs: Any,
) -> Any:
    """Convenience: chat-completion text mode."""
    return call(model=model, messages=messages, mode="chat", **kwargs)


async def acall(
    *,
    model: str,
    messages: list[dict[str, Any]],
    tools: Optional[list[dict[str, Any]]] = None,
    mode: Mode = "chat",
    manifest: Optional[Manifest] = None,
    **kwargs: Any,
) -> Any:
    """Async wrapper around :func:`call`. Runs the sync dispatch in a
    thread so async callers don't block the event loop on the sync
    SDK invocation. Phase H will replace this with native async
    dispatch when streaming lands."""
    import asyncio

    return await asyncio.to_thread(
        call,
        model=model,
        messages=messages,
        tools=tools,
        mode=mode,
        manifest=manifest,
        **kwargs,
    )


async def atext(
    *,
    model: str,
    messages: list[dict[str, Any]],
    **kwargs: Any,
) -> Any:
    """Async chat-completion text mode."""
    return await acall(model=model, messages=messages, mode="chat", **kwargs)


def json(
    *,
    model: str,
    messages: list[dict[str, Any]],
    schema: Optional[dict[str, Any]] = None,
    **kwargs: Any,
) -> Any:
    """JSON-mode dispatch.

    For OpenAI-compatible kinds, sets ``response_format={"type":
    "json_object"}`` (or ``"json_schema"`` if ``schema`` provided).
    For Anthropic, JSON mode is achieved via prompt + parsing — we
    pass through and the instance must be tagged json-capable in
    its capabilities or override.
    """
    if schema is not None:
        kwargs.setdefault(
            "response_format",
            {
                "type": "json_schema",
                "json_schema": {"name": "output", "schema": schema},
            },
        )
    else:
        kwargs.setdefault("response_format", {"type": "json_object"})
    return call(model=model, messages=messages, mode="json", **kwargs)


def tool(
    *,
    model: str,
    messages: list[dict[str, Any]],
    tools: list[dict[str, Any]],
    **kwargs: Any,
) -> Any:
    """Tool-call dispatch. Capability filter drops chain entries whose
    instances/overrides don't advertise ``native_tools``."""
    return call(model=model, messages=messages, tools=tools, mode="tool", **kwargs)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _resolve_for_call(model: str, *, manifest: Optional[Manifest]) -> list[Candidate]:
    return resolve_chain(_active_manifest(manifest), model)


def _active_manifest(override: Optional[Manifest]) -> Manifest:
    if override is not None:
        return override
    return _get_manifest_client().get()


def _invoke_chat(
    sdk_client: Any,
    kind: str,
    model_id: str,
    *,
    messages: list[dict[str, Any]],
    tools: Optional[list[dict[str, Any]]],
    mode: Mode,
    **kwargs: Any,
) -> Any:
    """Per-kind dispatch. Returns the SDK's native response shape."""
    # OpenAI-compatible (and ``openai`` itself) — single code path
    if kind in {
        "openai",
        "openai_compat",
        "fireworks",
        "together",
        "groq",
        "xai",
        "mistral",
        "ai21",
        "nvidia",
        "replicate",
        "ollama",
        "vllm",
        "huggingface_tgi",
    }:
        params: dict[str, Any] = {
            "model": model_id,
            "messages": messages,
        }
        if tools:
            params["tools"] = tools
        params.update(kwargs)
        return sdk_client.chat.completions.create(**params)

    if kind == "anthropic":
        return _invoke_anthropic(sdk_client, model_id, messages, tools, **kwargs)

    raise UnsupportedKind(
        f"_invoke_chat reached an unsupported kind={kind!r}. "
        f"This is a bug — clients.build_client should have caught it."
    )


def _invoke_anthropic(
    sdk_client: Any,
    model_id: str,
    messages: list[dict[str, Any]],
    tools: Optional[list[dict[str, Any]]],
    **kwargs: Any,
) -> Any:
    """Translate OpenAI-style messages → Anthropic shape and dispatch.

    Anthropic separates the system prompt from the messages array.
    All other ``role: "system"`` messages get folded into the system
    prompt; ``"user"``/``"assistant"`` messages pass through.
    """
    system_parts: list[str] = []
    out_messages: list[dict[str, Any]] = []
    for m in messages:
        role = m.get("role", "")
        content = m.get("content", "")
        if role == "system":
            if isinstance(content, str):
                system_parts.append(content)
            continue
        out_messages.append({"role": role, "content": content})

    params: dict[str, Any] = {
        "model": model_id,
        "messages": out_messages,
        "max_tokens": kwargs.pop("max_tokens", 4096),
    }
    if system_parts:
        params["system"] = "\n\n".join(system_parts)
    if tools:
        params["tools"] = tools

    # Pass through anything else the caller wanted (temperature,
    # top_p, top_k, stop_sequences, metadata, etc.). Drop OpenAI-only
    # kwargs that anthropic.messages.create rejects.
    _OPENAI_ONLY = {
        "response_format",
        "logprobs",
        "n",
        "presence_penalty",
        "frequency_penalty",
        "logit_bias",
        "user",
        "seed",
    }
    for k, v in kwargs.items():
        if k in _OPENAI_ONLY:
            continue
        params[k] = v

    return sdk_client.messages.create(**params)
