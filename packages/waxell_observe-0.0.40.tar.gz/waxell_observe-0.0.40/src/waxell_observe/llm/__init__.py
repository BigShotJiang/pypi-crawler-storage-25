"""``waxell.llm`` — opt-in dispatch surface for observe-only customers.

Phase B ships the manifest pull + cache. Phase C lands real dispatch.

Usage::

    import waxell_observe as waxell

    # Phase B — fetch the manifest
    manifest = waxell.llm._get_config()
    for inst in manifest.instances:
        print(inst.instance_id, inst.kind, inst.base_url)

    # Phase C (not yet) — dispatch a call
    resp = waxell.llm.call(model="gpt-4o", messages=[...])

See ``agentforge/areas/llm-providers/plans/OBSERVE_DISPATCH_PLAN.md``.
"""

from __future__ import annotations

from .capability import filter_chain_for_mode
from .clients import (
    MissingProviderSDK,
    SecretNotInEnvironment,
    UnsupportedKind,
    build_client,
)
from .dispatch import (
    DispatchAttempt,
    DispatchError,
    DispatchNotImplemented,
    NoCandidateForMode,
    NoProviderAvailable,
    acall,
    atext,
    call,
    json,
    text,
    tool,
)
from .manifest import (
    DEFAULT_MANIFEST_TTL_SECONDS,
    ManifestClient,
    ManifestUnavailable,
    get_default_client,
    reset_default_client,
)
from .resolver import Candidate, ModelNotResolvable, resolve_chain
from .types import (
    Manifest,
    ModelCapabilityOverride,
    ModelGroup,
    ModelGroupEntry,
    ProviderInstance,
    TenantModel,
)


def _get_config(*, force_refresh: bool = False) -> Manifest:
    """Return the cached LLM-config Manifest, fetching it lazily.

    Phase B done-criterion: this returns a populated ``Manifest`` in a
    user shell against the controlplane. Underscore prefix because the
    typical caller is internal dispatch logic — direct user access is
    fine but not the headline API.
    """
    return get_default_client().get(force_refresh=force_refresh)


__all__ = [
    "DEFAULT_MANIFEST_TTL_SECONDS",
    "Candidate",
    "DispatchAttempt",
    "DispatchError",
    "DispatchNotImplemented",
    "Manifest",
    "ManifestClient",
    "ManifestUnavailable",
    "MissingProviderSDK",
    "ModelCapabilityOverride",
    "ModelGroup",
    "ModelGroupEntry",
    "ModelNotResolvable",
    "NoCandidateForMode",
    "NoProviderAvailable",
    "ProviderInstance",
    "SecretNotInEnvironment",
    "TenantModel",
    "UnsupportedKind",
    "_get_config",
    "acall",
    "atext",
    "build_client",
    "call",
    "filter_chain_for_mode",
    "get_default_client",
    "json",
    "reset_default_client",
    "resolve_chain",
    "text",
    "tool",
]
