"""Manifest pull + cache for the SDK-side LLM dispatcher.

Pulls ``GET /api/v1/observe/llm-config/manifest/`` from the
controlplane (Phase A), caches the parsed ``Manifest`` in process,
refreshes on TTL expiry using ``If-None-Match`` for cheap 304s.

Sync HTTP via ``httpx.Client``. The manifest is rare-traffic (5-min
TTL) so a brief sync block is acceptable in async contexts. Future
work: optional async path to avoid event-loop blocks on first call.
"""

from __future__ import annotations

import logging
import threading
import time
from typing import Optional

from waxell_observe.config import ObserveConfig

from .types import Manifest

logger = logging.getLogger(__name__)


# Default TTL for the in-memory manifest cache. Matches the
# Cache-Control: max-age=300 hint the controlplane returns.
DEFAULT_MANIFEST_TTL_SECONDS = 300.0

# Cap on consecutive failed refresh attempts before we surface the
# error rather than re-using a stale manifest forever.
_MAX_STALE_REUSE_ATTEMPTS = 3


class ManifestUnavailable(Exception):
    """Raised when the manifest cannot be fetched and there is no
    cached copy to fall back to. Distinct from a transient refresh
    failure (which silently re-uses the cached copy)."""


class ManifestClient:
    """Thread-safe singleton-style cache for the LLM-config manifest.

    Resolution order for config:
      1. Explicit ``api_url`` / ``api_key`` constructor args
      2. ``WaxellObserveClient`` global config (set via ``configure()``)
      3. ``WAXELL_API_URL``/``WAXELL_API_KEY`` env vars

    Attempts cache-validation via ETag (``If-None-Match``) on refresh
    so a 304 response avoids re-parsing the body.
    """

    def __init__(
        self,
        api_url: Optional[str] = None,
        api_key: Optional[str] = None,
        ttl_seconds: float = DEFAULT_MANIFEST_TTL_SECONDS,
    ) -> None:
        self._explicit_url = api_url
        self._explicit_key = api_key
        self._ttl = float(ttl_seconds)
        self._lock = threading.Lock()
        self._cached_manifest: Optional[Manifest] = None
        self._cached_etag: str = ""
        self._cached_at: float = 0.0
        self._consecutive_refresh_failures: int = 0

    # -----------------------------------------------------------------
    # Public API
    # -----------------------------------------------------------------

    def get(self, *, force_refresh: bool = False) -> Manifest:
        """Return the current Manifest, fetching or refreshing as needed.

        Raises ``ManifestUnavailable`` if no cached copy is available
        AND the network fetch fails.
        """
        with self._lock:
            now = time.monotonic()
            if (
                not force_refresh
                and self._cached_manifest is not None
                and (now - self._cached_at) < self._ttl
            ):
                return self._cached_manifest

            try:
                self._refresh_locked()
            except _RefreshFailed as e:
                self._consecutive_refresh_failures += 1
                if self._cached_manifest is not None:
                    if self._consecutive_refresh_failures <= _MAX_STALE_REUSE_ATTEMPTS:
                        logger.warning(
                            "Manifest refresh failed (%s); using cached copy "
                            "(failure #%d, will keep retrying)",
                            e,
                            self._consecutive_refresh_failures,
                        )
                        return self._cached_manifest
                    logger.error(
                        "Manifest refresh failed %d times; surfacing error",
                        self._consecutive_refresh_failures,
                    )
                raise ManifestUnavailable(str(e)) from e

            if self._cached_manifest is None:  # pragma: no cover — defensive
                raise ManifestUnavailable("manifest fetch returned no payload")
            return self._cached_manifest

    def invalidate(self) -> None:
        """Drop the cached manifest. Next ``get()`` re-fetches."""
        with self._lock:
            self._cached_manifest = None
            self._cached_etag = ""
            self._cached_at = 0.0
            self._consecutive_refresh_failures = 0

    @property
    def cached_etag(self) -> str:
        return self._cached_etag

    # -----------------------------------------------------------------
    # Internals
    # -----------------------------------------------------------------

    def _resolve_config(self) -> ObserveConfig:
        if self._explicit_url and self._explicit_key:
            return ObserveConfig(api_url=self._explicit_url, api_key=self._explicit_key)

        # Try the global WaxellObserveClient config (set via .configure())
        try:
            from waxell_observe.client import WaxellObserveClient

            existing = WaxellObserveClient.get_config()
            if existing and existing.is_configured:
                return existing
        except Exception:
            pass

        cfg = ObserveConfig.from_env()
        if cfg.is_configured:
            return cfg

        try:
            cli_cfg = ObserveConfig.from_cli_config()
            if cli_cfg.is_configured:
                return cli_cfg
        except Exception:
            pass

        return cfg  # not configured — caller will get a clear error

    def _refresh_locked(self) -> None:
        """Fetch the manifest. Caller holds ``self._lock``."""
        import httpx

        cfg = self._resolve_config()
        if not cfg.is_configured:
            raise _RefreshFailed(
                "waxell-observe not configured: set WAXELL_API_URL and "
                "WAXELL_API_KEY environment variables, or call "
                "WaxellObserveClient.configure(...) at startup."
            )

        url = f"{cfg.api_url.rstrip('/')}/api/v1/observe/llm-config/manifest/"
        headers = {"X-Wax-Key": cfg.api_key}
        if self._cached_etag:
            headers["If-None-Match"] = self._cached_etag

        try:
            with httpx.Client(timeout=30.0) as client:
                response = client.get(url, headers=headers)
        except (httpx.ConnectError, httpx.TimeoutException) as e:
            raise _RefreshFailed(
                f"controlplane unreachable: {type(e).__name__}: {e}"
            ) from e

        if response.status_code == 304 and self._cached_manifest is not None:
            self._cached_at = time.monotonic()
            self._consecutive_refresh_failures = 0
            return

        if response.status_code == 401:
            raise _RefreshFailed(
                "unauthorized: API key invalid or expired. Check WAXELL_API_KEY."
            )

        if response.status_code >= 400:
            detail = response.text[:200] if response.text else ""
            raise _RefreshFailed(
                f"manifest fetch failed: HTTP {response.status_code} {detail}"
            )

        try:
            body = response.json()
        except Exception as e:
            raise _RefreshFailed(f"manifest response was not valid JSON: {e}") from e

        manifest = Manifest.from_dict(body)
        self._cached_manifest = manifest
        self._cached_etag = response.headers.get("ETag", "")
        self._cached_at = time.monotonic()
        self._consecutive_refresh_failures = 0


class _RefreshFailed(Exception):
    """Internal — distinguishes a transient refresh failure from a
    user-facing ``ManifestUnavailable``."""


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------

_default_client: Optional[ManifestClient] = None
_default_lock = threading.Lock()


def get_default_client() -> ManifestClient:
    """Return the process-wide ManifestClient, creating it if needed."""
    global _default_client
    if _default_client is None:
        with _default_lock:
            if _default_client is None:
                _default_client = ManifestClient()
    return _default_client


def reset_default_client() -> None:
    """Mostly for tests — drop the module-level cache."""
    global _default_client
    with _default_lock:
        _default_client = None
