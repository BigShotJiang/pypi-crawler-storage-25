"""Capability filter — drop chain entries that can't satisfy the
requested call mode.

OR-semantics across three sources, in priority order:

1. ``ModelCapabilityOverride`` (per-(instance, model_id) tri-state)
2. ``TenantModel.supports_*`` (per-model_id, set when the model was
   registered)
3. ``ProviderInstance.capabilities`` (per-instance baseline)

Only ``False`` values from override OR True values anywhere else
matter. ``None`` from override means "no opinion, defer to lower
priority sources." This mirrors the runtime resolver's semantics.
"""

from __future__ import annotations

from typing import Literal

from .resolver import Candidate
from .types import Manifest

Mode = Literal["chat", "json", "tool"]


def filter_chain_for_mode(
    manifest: Manifest,
    chain: list[Candidate],
    mode: Mode,
) -> list[Candidate]:
    """Return only the chain entries that support the requested mode.

    For ``mode="chat"``: every entry passes (chat is always supported).

    For ``mode="json"``: requires ``json_mode`` capability on at least
    one of (override, tenant_model, instance).

    For ``mode="tool"``: requires ``native_tools`` capability on at
    least one of (override, tenant_model, instance).
    """
    if mode == "chat":
        return list(chain)

    return [c for c in chain if _candidate_supports(manifest, c, mode)]


def _candidate_supports(manifest: Manifest, candidate: Candidate, mode: Mode) -> bool:
    """OR-semantics across (override, tenant_model, instance.capabilities)."""

    # 1. Capability override (tri-state)
    override = manifest.find_capability_override(
        candidate.instance_id, candidate.provider_model_id
    )
    override_value: bool | None = None
    if override is not None:
        if mode == "json":
            override_value = override.json_mode
        elif mode == "tool":
            override_value = override.native_tools
    if override_value is True:
        return True
    if override_value is False:
        # Explicit False from override is final — even if instance says yes.
        return False

    # 2. TenantModel flag (only if a TenantModel exists for this model_id)
    tm = manifest.find_tenant_model(candidate.provider_model_id)
    if tm is not None:
        if mode == "json" and tm.supports_json:
            return True
        if mode == "tool" and tm.supports_tools:
            return True

    # 3. ProviderInstance capabilities baseline
    caps = candidate.instance.capabilities or {}
    if mode == "json" and bool(caps.get("json_mode", False)):
        return True
    if mode == "tool" and bool(caps.get("native_tools", False)):
        return True

    return False
