"""Platform-specific helpers shared across observe-SDK integrations.

Today: just `hardware_id`. Future home for any other cross-platform
machine introspection helpers (OS version, hostname normalization,
network interfaces, etc).
"""

from .hardware_id import get_hardware_uuid

__all__ = ["get_hardware_uuid"]
