"""Guard config CLI — inspect, edit, and validate the local-guard config.

The local guard (`waxell_observe.integrations.claude_code.guard`) reads its
configuration from a layered chain:

    builtin defaults
    < remote (controlplane-managed `ConnectGuardConfig`, B5/B6)
    < ~/.waxell/guard.json (user global)
    < ./.waxell/guard.json (project-local)

This command group lets operators interact with that config without
hand-editing JSON files. Subcommands:

    wax guard config show       Print the merged effective config + sources.
    wax guard config set        Edit either the user or project guard.json.
    wax guard config validate   Validate guard.json files (typo / shape check).
    wax guard config push       Stub — controlplane write API not yet shipped.

See `agentforge/areas/connect/plans/EXTERNAL_AGENT_GOVERNANCE.md` (B8).
"""

from __future__ import annotations

import dataclasses
import json
import os
from dataclasses import fields
from pathlib import Path
from typing import Optional

import click


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_client():
    """Best-effort: build a configured WaxellObserveClient for the remote
    layer. Returns None if the SDK can't resolve credentials — `show`
    should still work locally without a server connection."""
    try:
        from ...client import WaxellObserveClient

        client = WaxellObserveClient()
        # If there's no api_key/api_url we skip the remote layer rather
        # than 4xx-spamming the controlplane.
        cfg = getattr(client, "config", None)
        if cfg is None:
            return None
        if not (getattr(cfg, "api_key", "") and getattr(cfg, "api_url", "")):
            return None
        return client
    except Exception:
        return None


def _coerce_value(raw: str, type_hint: str, key: str) -> object:
    """Coerce a CLI-supplied string into the appropriate Python value
    for a GuardConfig field. Raises ClickException on bad input."""
    t = (type_hint or "").lower()
    if t == "bool":
        low = raw.strip().lower()
        if low in ("1", "true", "yes", "y", "on"):
            return True
        if low in ("0", "false", "no", "n", "off"):
            return False
        raise click.ClickException(
            f"--type bool: '{raw}' is not a recognized boolean (try true/false)"
        )
    if t == "int":
        try:
            return int(raw)
        except ValueError as exc:
            raise click.ClickException(
                f"--type int: '{raw}' is not an integer ({exc})"
            ) from exc
    if t == "list":
        # Comma-separated, trim empties so "a,b,c" and "a, b, c" both work.
        # Use split + strip rather than CSV parsing — guard config values
        # are simple identifiers / globs, not anything quote-aware.
        parts = [p.strip() for p in raw.split(",")]
        return [p for p in parts if p]
    if t in ("str", "string", ""):
        return raw
    raise click.ClickException(
        f"unknown --type '{type_hint}' (expected: bool, int, list, str)"
    )


def _validate_value_for_field(key: str, value: object, default: object) -> None:
    """Sanity-check the coerced value against the GuardConfig field's
    declared default. Mirrors `guard.validate_config_file`'s rules."""
    if isinstance(default, bool):
        if not isinstance(value, bool):
            raise click.ClickException(
                f"'{key}' must be a bool, got {type(value).__name__}"
            )
    elif isinstance(default, int) and not isinstance(default, bool):
        if isinstance(value, bool) or not isinstance(value, int):
            raise click.ClickException(
                f"'{key}' must be an integer, got {type(value).__name__}"
            )
    elif isinstance(default, list):
        if not isinstance(value, list):
            raise click.ClickException(
                f"'{key}' must be a list, got {type(value).__name__}"
            )
        bad = [v for v in value if not isinstance(v, str)]
        if bad:
            raise click.ClickException(
                f"'{key}' must contain only strings, got {bad!r}"
            )


def _atomic_write_json(path: Path, payload: dict) -> None:
    """Write JSON atomically: temp file + os.replace. Mirrors
    `guard._save_remote_cache` so user files survive a crash mid-write."""
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, indent=2, sort_keys=True))
    os.replace(str(tmp), str(path))


def _load_json_file(path: Path) -> dict:
    """Read a guard.json file. Returns {} if missing. Raises
    ClickException on parse errors so 'set' fails loudly rather than
    overwriting a malformed file."""
    if not path.exists():
        return {}
    try:
        raw = path.read_text()
    except IOError as exc:
        raise click.ClickException(f"cannot read {path}: {exc}") from exc
    if not raw.strip():
        return {}
    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise click.ClickException(
            f"{path} is not valid JSON ({exc}); refusing to overwrite. "
            f"Fix the file or delete it before re-running 'set'."
        ) from exc
    if not isinstance(data, dict):
        raise click.ClickException(
            f"{path} must be a JSON object at the top level, got {type(data).__name__}"
        )
    return data


# ---------------------------------------------------------------------------
# Click group
# ---------------------------------------------------------------------------


@click.group("guard")
def guard():
    """Inspect and edit the local-guard config.

    The guard runs inside Claude Code / Cowork hooks and gates tool
    calls (Bash, Write, WebFetch, etc.) against blocked-command lists,
    protected-file globs, git-safety rules, and network policies.
    """


@guard.group("config")
def config():
    """Manage guard.json — show, set, validate, push."""


# ---- show -------------------------------------------------------------------


@config.command("show")
@click.option(
    "--project-dir",
    default=None,
    help="Project directory (defaults to current cwd). Used to look up "
    "./.waxell/guard.json.",
)
@click.option(
    "--profile",
    default=None,
    help="Waxell config profile to use when fetching the remote layer "
    "(propagated via WAX_PROFILE).",
)
def show(project_dir: Optional[str], profile: Optional[str]):
    """Print the effective guard config (all layers merged) as JSON.

    Sources are listed first, in priority order, so you can see which
    layer contributed what. Layers checked:

      1. builtin defaults
      2. remote (controlplane) — only if a client is configured
      3. ~/.waxell/guard.json (user)
      4. ./.waxell/guard.json (project)
    """
    from ...integrations.claude_code import guard as guard_mod

    if profile:
        os.environ["WAX_PROFILE"] = profile

    cwd = project_dir or os.getcwd()

    # Bookkeeping — figure out which layers contributed before we hand
    # off to load_config(). load_config() doesn't expose this, so we
    # introspect by checking which paths exist + whether a client is
    # available.
    sources: list[str] = ["builtin"]
    client = _get_client()
    if client is not None:
        sources.append(f"remote (api_url={client.config.api_url})")
    user_path = Path.home() / ".waxell" / "guard.json"
    if user_path.exists():
        sources.append(f"user ({user_path})")
    project_path = Path(cwd) / ".waxell" / "guard.json"
    if project_path.exists():
        sources.append(f"project ({project_path})")

    cfg = guard_mod.load_config(cwd, client=client)
    cfg_dict = dataclasses.asdict(cfg)

    click.echo("# Sources (in priority order, later layers override earlier):")
    for src in sources:
        click.echo(f"#   - {src}")
    click.echo("")
    click.echo(json.dumps(cfg_dict, indent=2, sort_keys=True))


# ---- set --------------------------------------------------------------------


@config.command("set")
@click.argument("key")
@click.argument("value")
@click.option(
    "--project",
    "scope_project",
    is_flag=True,
    help="Write to ./.waxell/guard.json (project-local). Default scope is --user.",
)
@click.option(
    "--user",
    "scope_user",
    is_flag=True,
    help="Write to ~/.waxell/guard.json (default).",
)
@click.option(
    "--type",
    "type_hint",
    default="str",
    type=click.Choice(["bool", "int", "list", "str"], case_sensitive=False),
    help="Value type for coercion. Use 'list' for comma-separated input.",
)
@click.option(
    "--project-dir",
    default=None,
    help="Project directory for --project scope (defaults to cwd).",
)
def set_cmd(
    key: str,
    value: str,
    scope_project: bool,
    scope_user: bool,
    type_hint: str,
    project_dir: Optional[str],
):
    """Set KEY=VALUE in the appropriate guard.json file.

    Examples:

      wax guard config set max_file_changes 100 --type int
      wax guard config set git_block_force_push false --type bool
      wax guard config set blocked_domains "evil.com,bad.io" --type list --project
    """
    from ...integrations.claude_code import guard as guard_mod

    if scope_project and scope_user:
        raise click.ClickException("--project and --user are mutually exclusive")

    # Validate the field name up front against the dataclass — typos
    # silently disappear at runtime otherwise.
    template = guard_mod._default_config()
    known = {f.name: f for f in fields(template)}
    if key not in known:
        valid = ", ".join(sorted(known.keys()))
        raise click.ClickException(f"unknown field '{key}'. Valid fields: {valid}")

    coerced = _coerce_value(value, type_hint, key)
    _validate_value_for_field(key, coerced, getattr(template, key))

    if scope_project:
        cwd = project_dir or os.getcwd()
        target = Path(cwd) / ".waxell" / "guard.json"
        scope_label = "project"
    else:
        target = Path.home() / ".waxell" / "guard.json"
        scope_label = "user"

    existing = _load_json_file(target)
    existing[key] = coerced
    _atomic_write_json(target, existing)

    click.echo(
        f"wrote {scope_label} guard.json: {target}\n  {key} = {json.dumps(coerced)}"
    )


# ---- validate ---------------------------------------------------------------


@config.command("validate")
@click.option(
    "--project-dir",
    default=None,
    help="Project directory (defaults to cwd). Both ~/.waxell/guard.json "
    "and ./.waxell/guard.json are validated.",
)
def validate(project_dir: Optional[str]):
    """Validate guard.json files. Exits 1 if any errors are found.

    Missing files are treated as valid (defaults apply).
    """
    from ...integrations.claude_code import guard as guard_mod

    paths = [Path.home() / ".waxell" / "guard.json"]
    cwd = project_dir or os.getcwd()
    paths.append(Path(cwd) / ".waxell" / "guard.json")

    any_errors = False
    for path in paths:
        errors = guard_mod.validate_config_file(path)
        if errors:
            any_errors = True
            click.echo(f"{path}: INVALID")
            for err in errors:
                click.echo(f"  - {err}")
        else:
            status = "OK" if path.exists() else "missing (defaults apply)"
            click.echo(f"{path}: {status}")

    if any_errors:
        raise click.exceptions.Exit(1)


# ---- push (stub) ------------------------------------------------------------


@config.command("push")
def push():
    """Push local guard.json to the controlplane.

    \b
    NOT YET SUPPORTED. The controlplane does not currently expose a
    write endpoint for ConnectGuardConfig (B7 of EXTERNAL_AGENT_GOVERNANCE
    is deferred). Until B7 ships, edit configs via the controlplane API
    directly, or commit ./.waxell/guard.json to your repo and let the
    project layer override the remote layer locally.
    """
    raise click.ClickException(
        "wax guard config push is not yet supported. "
        "The controlplane write API for ConnectGuardConfig (B7) hasn't "
        "shipped yet. Use the controlplane API directly when it lands, "
        "or commit ./.waxell/guard.json to your repo for project-scoped "
        "overrides in the meantime."
    )
