"""`wax doctor` — comprehensive health check + auto-fix.

Catches every post-install gotcha we've hit in the wild:
  - PATH issues (absolute vs bare `wax` in settings.json)
  - SSL cert bundle missing from bundled Python
  - Invalid / stale config profiles
  - Missing hook key attribution
  - VS Code extension vs CLI quirks
  - Claude Code settings.json hook registration
  - End-to-end synthetic hook test

Run with `--fix` to auto-repair what we can.
"""

import configparser
import json
import os
import shutil
import ssl
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

import click

from .._display import print_error, print_info, print_success, print_warning


@click.command("doctor")
@click.option("--fix", is_flag=True, help="Auto-fix issues where possible")
@click.option("--json", "as_json", is_flag=True, help="Output machine-readable JSON")
@click.option("--profile", default=None, help="Only check a specific profile")
def doctor(fix, as_json, profile):
    """Run every health check we have; repair common breakage.

    Exits 0 if everything is green, 1 if any hard failures remain after fixes.
    """
    results = []

    def add(name: str, ok: bool, detail: str, fixed: bool = False, hint: str = ""):
        results.append(
            {
                "name": name,
                "ok": ok,
                "detail": detail,
                "fixed": fixed,
                "hint": hint,
            }
        )

    # ---- 1. Binary sanity ----
    add(*_check_binary_path())

    # ---- 2. SSL cert bundle ----
    ok, detail, fixed, hint = _check_ssl(fix=fix)
    add("ssl_cert_bundle", ok, detail, fixed, hint)

    # ---- 3. Config file ----
    config_path = Path.home() / ".waxell" / "config"
    add(
        "config_file_exists",
        config_path.exists(),
        f"{config_path}" + ("" if config_path.exists() else " — run installer first"),
        hint="Run the Waxell Setup app to create profiles"
        if not config_path.exists()
        else "",
    )

    profiles = _read_profiles(config_path) if config_path.exists() else {}
    if profile:
        profiles = {k: v for k, v in profiles.items() if k == profile}

    # ---- 4. Per-profile auth check ----
    for pname, pdata in profiles.items():
        if pname == "default":
            continue
        ok, detail, hint = _check_profile_auth(pname, pdata)
        add(f"auth:{pname}", ok, detail, hint=hint)

    # ---- 5. State dir writable ----
    state_dir = Path(os.environ.get("WAXELL_CC_STATE_DIR", "/tmp/waxell-cc"))
    try:
        state_dir.mkdir(parents=True, exist_ok=True)
        test_file = state_dir / f".probe-{int(time.time())}"
        test_file.write_text("x")
        test_file.unlink()
        add("state_dir_writable", True, f"{state_dir}")
    except Exception as e:
        add(
            "state_dir_writable",
            False,
            f"{state_dir}: {e}",
            hint="Check filesystem permissions on /tmp",
        )

    # ---- 6. Claude Code settings.json — hooks with absolute paths ----
    if profile != "claude-cowork":  # only relevant when claude-code profile is in play
        ok, detail, fixed, hint = _check_claude_settings_paths(fix=fix)
        add("claude_settings_absolute_paths", ok, detail, fixed, hint)

    # ---- 7. Project-level .claude/settings.json overrides ----
    cwd = Path.cwd()
    local_override = cwd / ".claude" / "settings.local.json"
    if local_override.exists():
        has_hooks = _json_has_hooks(local_override)
        add(
            "no_project_hooks_override",
            not has_hooks,
            f"{local_override}"
            + (
                " contains hooks (may override user-level)"
                if has_hooks
                else " — no hooks override"
            ),
            hint="Remove the hooks block from local settings, or merge with user settings"
            if has_hooks
            else "",
        )

    # ---- 8. Claude Code CLI version ----
    ok, detail, hint = _check_claude_cli()
    add("claude_cli_installed", ok, detail, hint=hint)

    # ---- 9. Synthetic hook test ----
    if "claude-code" in profiles:
        ok, detail, hint = _synthetic_hook_test()
        add("synthetic_hook_end_to_end", ok, detail, hint=hint)

    # -------- Output --------
    if as_json:
        click.echo(
            json.dumps({"results": results, "ok": all(r["ok"] for r in results)})
        )
        sys.exit(0 if all(r["ok"] for r in results) else 1)

    _render_human(results)
    sys.exit(0 if all(r["ok"] for r in results) else 1)


# ---------------------------------------------------------------------------
# Individual checks
# ---------------------------------------------------------------------------


def _check_binary_path():
    """Verify wax binary is findable and executable."""
    path = shutil.which("wax")
    if not path:
        return (
            "binary_in_path",
            False,
            "wax not found in PATH",
            False,
            "Run the Waxell Setup app to install at /usr/local/bin/wax",
        )
    try:
        result = subprocess.run(
            [path, "--version"], capture_output=True, text=True, timeout=5
        )
        if result.returncode != 0:
            return (
                "binary_in_path",
                False,
                f"{path} exists but --version failed",
                False,
                "Binary may be corrupted; reinstall from Waxell Setup app",
            )
        return ("binary_in_path", True, f"{path} — {result.stdout.strip()}", False, "")
    except Exception as e:
        return ("binary_in_path", False, f"{path}: {e}", False, "Reinstall wax")


def _check_ssl(fix=False):
    """PyInstaller-bundled Python often lacks CA certs. Verify HTTPS to
    api.waxell.dev works, and if not, set SSL_CERT_FILE for future runs."""
    try:
        # Try system cert first
        ctx = ssl.create_default_context()
        req = urllib.request.Request("https://api.waxell.dev/health")
        try:
            urllib.request.urlopen(req, timeout=8, context=ctx)
            return True, "TLS verified against api.waxell.dev", False, ""
        except urllib.error.HTTPError:
            # Even a 404 means the TLS handshake completed
            return True, "TLS verified against api.waxell.dev", False, ""
        except urllib.error.URLError as e:
            if "CERTIFICATE_VERIFY_FAILED" not in str(e):
                # Network issue, not SSL
                return False, f"Can't reach api.waxell.dev: {e}", False, "Check network"
    except Exception as e:
        return False, f"SSL check errored: {e}", False, "Run `wax doctor` again"

    # TLS failed — try setting SSL_CERT_FILE
    candidates = [
        "/etc/ssl/cert.pem",
        "/opt/homebrew/etc/openssl@3/cert.pem",
        "/usr/local/etc/openssl@3/cert.pem",
    ]
    working_bundle = None
    for c in candidates:
        if not Path(c).exists():
            continue
        try:
            ctx = ssl.create_default_context(cafile=c)
            urllib.request.urlopen(
                "https://api.waxell.dev/health", timeout=8, context=ctx
            )
            working_bundle = c
            break
        except urllib.error.HTTPError:
            working_bundle = c
            break
        except Exception:
            continue

    if not working_bundle:
        return (
            False,
            "TLS fails with every known cert bundle",
            False,
            "Install certifi or check system SSL: python3 -c 'import ssl; print(ssl.get_default_verify_paths())'",
        )

    if not fix:
        return (
            False,
            f"TLS fails without {working_bundle}",
            False,
            f"Run: export SSL_CERT_FILE={working_bundle}  (or `wax doctor --fix` to persist)",
        )

    # Persist it in shell rc + launchd plist
    _persist_env_var("SSL_CERT_FILE", working_bundle)
    return True, f"SSL_CERT_FILE={working_bundle} persisted to shell rc files", True, ""


def _check_profile_auth(name: str, pdata: dict):
    """Hit /api/v1/connect/agents/me/ with the profile's api_key."""
    api_key = pdata.get("api_key", "")
    api_url = pdata.get("api_url", "").rstrip("/")
    if not api_key or not api_url:
        return False, "missing api_key or api_url", "Re-run installer for this profile"
    try:
        req = urllib.request.Request(
            f"{api_url}/api/v1/connect/agents/me/",
            headers={"X-Wax-Key": api_key},
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read())
        agent_name = data.get("name", "?")
        agent_slug = data.get("slug", "?")
        configured_slug = pdata.get("agent_slug", "")
        warning = ""
        if configured_slug and configured_slug != agent_slug:
            warning = f" ⚠ config agent_slug={configured_slug} but key resolves to {agent_slug}"
        return True, f"→ {agent_name} ({agent_slug}){warning}", ""
    except urllib.error.HTTPError as e:
        try:
            body = json.loads(e.read())
            err = body.get("error", str(e))
        except Exception:
            err = f"HTTP {e.code}"
        return False, err, f"Check the api_key in [{name}] section"
    except Exception as e:
        return False, str(e), ""


def _check_claude_settings_paths(fix=False):
    """~/.claude/settings.json should use absolute path for wax commands.
    Otherwise GUI apps (VS Code extension, etc.) can't find it."""
    settings = Path.home() / ".claude" / "settings.json"
    if not settings.exists():
        return True, f"{settings} not present (no claude integration)", False, ""
    try:
        data = json.loads(settings.read_text())
    except Exception as e:
        return (
            False,
            f"invalid JSON: {e}",
            False,
            "Run Waxell Setup → Claude Code to regenerate",
        )

    hooks = data.get("hooks", {})
    bad_refs = []
    all_hook_cmds = []

    def scan(obj):
        if isinstance(obj, dict):
            for k, v in obj.items():
                if k == "command" and isinstance(v, str):
                    all_hook_cmds.append(v)
                    if v.strip().startswith("wax "):
                        bad_refs.append(v)
                else:
                    scan(v)
        elif isinstance(obj, list):
            for item in obj:
                scan(item)

    scan(hooks)
    if not all_hook_cmds:
        return (
            True,
            "No waxell hooks registered (run `wax claude-code setup`)",
            False,
            "",
        )
    if not bad_refs:
        return True, f"{len(all_hook_cmds)} hooks all use absolute paths", False, ""

    if not fix:
        return (
            False,
            f"{len(bad_refs)} hook(s) use bare `wax` — GUI apps won't find them",
            False,
            "Run `wax doctor --fix`",
        )

    # Fix: replace `wax ` with `/usr/local/bin/wax ` in all hook commands
    wax_path = shutil.which("wax") or "/usr/local/bin/wax"

    def patch(obj):
        if isinstance(obj, dict):
            for k, v in list(obj.items()):
                if (
                    k == "command"
                    and isinstance(v, str)
                    and v.strip().startswith("wax ")
                ):
                    obj[k] = v.replace("wax ", f"{wax_path} ", 1)
                else:
                    patch(v)
        elif isinstance(obj, list):
            for item in obj:
                patch(item)

    patch(data.get("hooks", {}))
    settings.write_text(json.dumps(data, indent=2))
    return True, f"Patched {len(bad_refs)} hook command(s) to {wax_path}", True, ""


def _check_claude_cli():
    """Claude Code CLI must be >= 2.0 for hooks."""
    path = shutil.which("claude")
    if not path:
        return (
            False,
            "claude CLI not installed",
            "Install via: npm install -g @anthropic-ai/claude-code",
        )
    try:
        result = subprocess.run(
            [path, "--version"], capture_output=True, text=True, timeout=5
        )
        ver_line = result.stdout.strip()
        # Extract e.g. "2.1.92" from "2.1.92 (Claude Code)"
        first_token = ver_line.split()[0] if ver_line else ""
        try:
            major = int(first_token.split(".")[0])
            if major < 2:
                return (
                    False,
                    f"claude v{first_token} is too old for hooks",
                    "Upgrade via: npm install -g @anthropic-ai/claude-code@latest",
                )
        except ValueError:
            pass
        return True, f"claude {ver_line} at {path}", ""
    except Exception as e:
        return False, str(e), "Reinstall claude CLI"


def _synthetic_hook_test():
    """Fire a synthetic SessionStart event at ourselves, verify state is
    written and (best-effort) that the remote run was created."""
    wax = shutil.which("wax")
    if not wax:
        return False, "wax not in PATH", "Install wax first"
    sid = f"doctor-probe-{int(time.time())}"
    event = json.dumps(
        {
            "hook_event_name": "SessionStart",
            "session_id": sid,
            "transcript_path": "/tmp/nonexistent.jsonl",
            "cwd": str(Path.cwd()),
            "source": "doctor",
        }
    )
    try:
        result = subprocess.run(
            [wax, "--profile", "claude-code", "claude-code", "hook"],
            input=event,
            capture_output=True,
            text=True,
            timeout=30,
        )
    except subprocess.TimeoutExpired:
        return (
            False,
            "hook invocation timed out (>30s)",
            "Check network to api.waxell.dev",
        )
    state_file = (
        Path(os.environ.get("WAXELL_CC_STATE_DIR", "/tmp/waxell-cc")) / f"{sid}.json"
    )
    if not state_file.exists():
        return (
            False,
            f"hook ran (exit={result.returncode}) but no state file created",
            f"Output was: {(result.stdout + result.stderr).strip()[:200]}",
        )
    try:
        st = json.loads(state_file.read_text())
        state_file.unlink()
    except Exception:
        return True, "state file created (unparseable)", ""
    run_id = st.get("run_id")
    if not run_id:
        return (
            False,
            "state file written but no run_id attached",
            "api_key may lack attribution; check `wax doctor --profile claude-code`",
        )
    return True, f"end-to-end OK; run_id={run_id}", ""


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _read_profiles(path: Path) -> dict:
    """INI-style config → dict keyed by profile name."""
    parser = configparser.RawConfigParser()
    try:
        parser.read(path)
    except Exception:
        return {}
    out = {}
    for section in parser.sections():
        out[section] = {k: parser[section].get(k, "") for k in parser[section]}
    return out


def _json_has_hooks(path: Path) -> bool:
    try:
        d = json.loads(path.read_text())
        return isinstance(d.get("hooks"), dict) and len(d.get("hooks", {})) > 0
    except Exception:
        return False


def _persist_env_var(name: str, value: str):
    """Append export to ~/.zshenv so all shells (including GUI launchd)
    inherit it. Idempotent."""
    rc = Path.home() / ".zshenv"
    line = f"export {name}={value}"
    existing = rc.read_text() if rc.exists() else ""
    if line not in existing:
        with open(rc, "a") as f:
            f.write(f"\n# Added by wax doctor — ensures TLS works\n{line}\n")
    # Also update the launchd plist if we've installed the cowork watcher
    plist = Path.home() / "Library" / "LaunchAgents" / "dev.waxell.cowork.watcher.plist"
    if plist.exists():
        try:
            txt = plist.read_text()
            if (
                f"<key>{name}</key>" not in txt
                and "<key>EnvironmentVariables</key>" in txt
            ):
                insertion = f"    <key>{name}</key>\n    <string>{value}</string>\n"
                txt = txt.replace(
                    "<key>EnvironmentVariables</key>\n  <dict>\n",
                    f"<key>EnvironmentVariables</key>\n  <dict>\n{insertion}",
                    1,
                )
                plist.write_text(txt)
                # Restart via launchctl
                subprocess.run(["launchctl", "unload", str(plist)], capture_output=True)
                subprocess.run(["launchctl", "load", str(plist)], capture_output=True)
        except Exception:
            pass


def _render_human(results):
    n_ok = sum(1 for r in results if r["ok"])
    n_total = len(results)
    n_fixed = sum(1 for r in results if r.get("fixed"))
    print_info(f"Ran {n_total} checks")
    if n_fixed:
        print_success(f"Auto-fixed {n_fixed}")
    print_info("")

    for r in results:
        status = "✓" if r["ok"] else "✗"
        fn = print_success if r["ok"] else print_error
        tag = r["name"]
        detail = r["detail"]
        fn(f"{status} {tag}: {detail}")
        if r.get("fixed"):
            print_info("    (fixed)")
        if r.get("hint") and not r["ok"]:
            print_info(f"    → {r['hint']}")

    print_info("")
    if n_ok == n_total:
        print_success(f"All {n_total} checks passed 🎉")
    else:
        print_warning(
            f"{n_total - n_ok}/{n_total} checks failed. Run `wax doctor --fix` to auto-repair."
        )
