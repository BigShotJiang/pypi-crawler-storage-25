"""Sub-user v2 token signing keys (Ed25519 + JWKS).

These commands surface the per-tenant Ed25519 public key Waxell uses to
sign ``wax_su_v2_`` tokens. Your domain endpoints verify those tokens by
fetching the JWKS URL — no shared secret is ever exchanged.

Typical onboarding flow::

    wax sub-user-auth show              # show JWKS URL + active kid
    wax sub-user-auth show --format json
    wax sub-user-auth rotate            # rotate keypair (overlap window)
"""

from __future__ import annotations

import json

import click

from .._display import console, print_header, print_warning
from .._http import api_get, api_post


def _render_v2_keys(data: dict, *, show_json: bool) -> None:
    if show_json:
        console.print_json(json.dumps(data, indent=2))
        return

    print_header(
        "Sub-user v2 signing keys (Ed25519)",
        f"tenant={data.get('tenant_slug', '-')}",
    )
    console.print(f"[dim]Tenant ID:[/dim]      {data.get('tenant_id', '-')}")
    console.print(
        f"[dim]Active kid:[/dim]     [bold cyan]{data.get('active_kid', '-')}[/bold cyan]"
    )
    if data.get("prev_kid"):
        console.print(
            f"[dim]Previous kid:[/dim]   {data['prev_kid']}  "
            f"[dim](retires: {data.get('prev_retires_at') or 'n/a'})[/dim]"
        )
    console.print()
    console.print("[bold]JWKS URL:[/bold]")
    console.print(f"  {data.get('jwks_url', '-')}")
    console.print()
    console.print(
        "[dim]Configure your verifier to fetch this URL. Cache for "
        "up to 10 min. Accept any key in the returned 'keys' array.[/dim]"
    )
    console.print()
    keys = data.get("keys") or []
    if keys:
        console.print("[dim]Current JWKS keys:[/dim]")
        for k in keys:
            console.print(
                f"  [bold]{k.get('kid', '?')}[/bold]  "
                f"crv={k.get('crv', '?')}  alg={k.get('alg', '?')}  "
                f"x={k.get('x', '')[:20]}…"
            )
    console.print()


@click.group("sub-user-auth")
def sub_user_auth():
    """Manage the per-tenant Ed25519 keypair Waxell uses to sign sub-user
    tokens. Verification on your side is done via the published JWKS URL.
    """


@sub_user_auth.command("show")
@click.option(
    "--format",
    "fmt",
    type=click.Choice(["human", "json"]),
    default="human",
)
@click.pass_context
def show(ctx, fmt: str):
    """Show the tenant's active Ed25519 public key info + JWKS URL.

    Private key material is never revealed — verification uses the
    published JWKS endpoint."""
    data = api_get(ctx, "/v1/sub-user-signing-secret/v2/")
    _render_v2_keys(data, show_json=(fmt == "json"))


@sub_user_auth.command("rotate")
@click.option("--yes", "-y", "skip_confirm", is_flag=True)
@click.option(
    "--overlap-seconds",
    type=int,
    default=None,
    help="How long the previous public key stays in JWKS. "
    "Default 3600 (1h). Pass 0 for hard rotation (no overlap).",
)
@click.option("--format", "fmt", type=click.Choice(["human", "json"]), default="human")
@click.pass_context
def rotate(ctx, skip_confirm: bool, overlap_seconds, fmt: str):
    """Rotate the keypair. Previous key stays in JWKS for the overlap
    window so in-flight tokens keep verifying."""
    if not skip_confirm and fmt == "human":
        print_warning(
            "Rotating the keypair invalidates in-flight tokens after the "
            "overlap window expires. Verifiers fetching JWKS within "
            "~10 minutes pick up both keys automatically."
        )
        click.confirm("Rotate now?", abort=True)

    body = {}
    if overlap_seconds is not None:
        body["overlap_seconds"] = overlap_seconds
    data = api_post(ctx, "/v1/sub-user-signing-secret/v2/rotate/", json=body)
    _render_v2_keys(data, show_json=(fmt == "json"))
    if fmt == "human":
        warning = data.get("warning")
        if warning:
            console.print(f"[yellow]{warning}[/yellow]")
