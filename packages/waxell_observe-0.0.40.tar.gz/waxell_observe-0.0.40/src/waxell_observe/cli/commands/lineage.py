"""Lineage commands — walk the agent causality graph.

Reads from the HTTP endpoints at ``/api/v1/lineage/*``. Gated server-side
by ``WAXELL_LINEAGE_UI_V1`` — command returns 404 when off.
"""

import json

import click
from rich.table import Table
from rich.tree import Tree

from .._http import api_get
from .._display import (
    console,
    print_header,
    print_warning,
    status_dot,
    fmt_duration,
)


@click.group()
def lineage():
    """Walk the agent causality graph (runs + edges)."""
    pass


def _kind_style(kind: str) -> str:
    return {
        "spawn": "cyan",
        "resume": "green",
        "signal_fire": "magenta",
        "domain_callback": "blue",
        "user_start": "yellow",
        "timer_fire": "dim yellow",
        "retry": "red",
        "ctx_ask_user": "yellow",
        "cross_session_bridge": "magenta",
        "span_tree_fallback": "dim",
    }.get(kind, "white")


@lineage.command("upstream")
@click.argument("run_id")
@click.option("--max-hops", type=int, default=10, help="Max walk depth (≤50).")
@click.option("--kinds", default=None, help="Comma-separated edge kinds to filter.")
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["table", "json"]),
    default="table",
)
@click.pass_context
def upstream(ctx, run_id: str, max_hops: int, kinds: str, output_format: str):
    """Walk upstream (backward causality) from a run."""
    params: dict = {"max_hops": max_hops}
    if kinds:
        params["kinds"] = kinds

    data = api_get(ctx, f"/v1/lineage/runs/{run_id}/upstream", params=params)

    if output_format == "json":
        console.print_json(json.dumps(data, indent=2))
        return

    hops = data.get("hops", [])
    print_header(
        f"Upstream lineage: {run_id[:12]}...",
        f"{len(hops)} hop(s){' (truncated)' if data.get('truncated') else ''}",
    )

    if not hops:
        print_warning("No inbound edges — this run was the origin.")
        return

    table = Table(show_header=True, header_style="bold cyan", border_style="dim")
    table.add_column("Hop", justify="right")
    table.add_column("Kind")
    table.add_column("Label")
    table.add_column("Parent Agent")
    table.add_column("Status")
    table.add_column("Cost", justify="right")

    for hop in hops:
        edge = hop.get("edge", {})
        parent = hop.get("parent_run") or {}
        kind = edge.get("kind", "?")
        cost = edge.get("cost_attributed")
        cost_str = f"${cost:.4f}" if cost else "-"
        table.add_row(
            str(hop.get("hop", "")),
            f"[{_kind_style(kind)}]{kind}[/{_kind_style(kind)}]",
            edge.get("edge_label") or "-",
            f"{parent.get('agent_name', '?')}.{parent.get('workflow_name', '?')}",
            f"{status_dot(parent.get('status', 'unknown'))} {parent.get('status', '?')}",
            cost_str,
        )
    console.print(table)


@lineage.command("downstream")
@click.argument("run_id")
@click.option("--max-hops", type=int, default=10, help="Max walk depth (≤50).")
@click.option("--kinds", default=None, help="Comma-separated edge kinds to filter.")
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["table", "json", "tree"]),
    default="tree",
)
@click.pass_context
def downstream(ctx, run_id: str, max_hops: int, kinds: str, output_format: str):
    """Walk downstream (forward cascade) from a run."""
    params: dict = {"max_hops": max_hops}
    if kinds:
        params["kinds"] = kinds

    data = api_get(ctx, f"/v1/lineage/runs/{run_id}/downstream", params=params)

    if output_format == "json":
        console.print_json(json.dumps(data, indent=2))
        return

    nodes = data.get("nodes", [])
    edges = data.get("edges", [])
    counts = data.get("counts", {})
    by_kind = counts.get("by_kind", {})

    subtitle = (
        f"{counts.get('total_runs', 0)} runs | "
        f"{counts.get('total_edges', 0)} edges | "
        f"${data.get('cost_total', 0):.4f} | "
        f"{data.get('tokens_total', 0)} tokens"
        f"{' | truncated' if data.get('truncated') else ''}"
    )
    print_header(f"Downstream lineage: {run_id[:12]}...", subtitle)

    if by_kind:
        console.print(
            "  [dim]"
            + "  ".join(f"{k}={v}" for k, v in sorted(by_kind.items()))
            + "[/dim]"
        )
        console.print()

    if not nodes and not edges:
        print_warning("This run caused nothing (no outbound edges).")
        return

    if output_format == "table":
        table = Table(show_header=True, header_style="bold cyan", border_style="dim")
        table.add_column("Kind")
        table.add_column("Parent")
        table.add_column("Child")
        table.add_column("Cost", justify="right")
        for e in edges:
            cost = e.get("cost_attributed")
            cost_str = f"${cost:.4f}" if cost else "-"
            table.add_row(
                f"[{_kind_style(e.get('kind', ''))}]{e.get('kind', '?')}[/{_kind_style(e.get('kind', ''))}]",
                (e.get("parent_run_id") or "-")[:12],
                (e.get("child_run_id") or "-")[:12],
                cost_str,
            )
        console.print(table)
        return

    # Tree view: group edges by parent; render starting from root_run_id.
    nodes_by_id = {n.get("workflow_id"): n for n in nodes}
    edges_by_parent: dict = {}
    for e in edges:
        edges_by_parent.setdefault(e.get("parent_run_id") or "", []).append(e)

    def _label(run_id: str) -> str:
        n = nodes_by_id.get(run_id) or {}
        return (
            f"[bold]{n.get('agent_name', '?')}.{n.get('workflow_name', '?')}[/bold] "
            f"{status_dot(n.get('status', 'unknown'))} {fmt_duration(n.get('duration', 0) or 0)}"
            f" [dim]{run_id[:8]}[/dim]"
        )

    root_id = data.get("root_run_id") or run_id
    tree = Tree(_label(root_id))
    visited = {root_id}

    def _walk(parent_id: str, parent_node: Tree):
        for e in edges_by_parent.get(parent_id, []):
            cid = e.get("child_run_id")
            if cid in visited:
                continue
            visited.add(cid)
            kind = e.get("kind", "?")
            cost = e.get("cost_attributed")
            cost_str = f" [dim]${cost:.4f}[/dim]" if cost else ""
            child = parent_node.add(
                f"[{_kind_style(kind)}]{kind}[/{_kind_style(kind)}]"
                f" → {_label(cid)}{cost_str}"
            )
            _walk(cid, child)

    _walk(root_id, tree)
    console.print(tree)


@lineage.command("session")
@click.argument("session_id")
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["table", "json"]),
    default="table",
)
@click.pass_context
def session(ctx, session_id: str, output_format: str):
    """Show the full lineage graph for a session."""
    data = api_get(ctx, f"/v1/lineage/sessions/{session_id}/graph")

    if output_format == "json":
        console.print_json(json.dumps(data, indent=2))
        return

    stats = data.get("stats", {})
    subtitle = (
        f"{stats.get('run_count', 0)} runs | "
        f"{stats.get('edge_count', 0)} edges | "
        f"${stats.get('total_cost', 0):.4f}"
    )
    print_header(f"Session DAG: {session_id[:12]}...", subtitle)

    roots = stats.get("root_run_ids", [])
    if roots:
        console.print(
            f"  [dim]roots: {', '.join(r[:8] for r in roots[:5])}"
            f"{' …' if len(roots) > 5 else ''}[/dim]"
        )
        console.print()

    runs = data.get("runs", [])
    if not runs:
        print_warning("No runs found for this session.")
        return

    runs_table = Table(
        title="Runs", show_header=True, header_style="bold cyan", border_style="dim"
    )
    runs_table.add_column("Source")
    runs_table.add_column("Agent.Workflow")
    runs_table.add_column("Status")
    runs_table.add_column("Run ID")
    for r in runs:
        src = r.get("source", "runtime")
        runs_table.add_row(
            f"[dim]{src}[/dim]",
            f"{r.get('agent_name', '?')}.{r.get('workflow_name', '?')}",
            f"{status_dot(r.get('status', 'unknown'))} {r.get('status', '?')}",
            (r.get("workflow_id") or "-")[:12],
        )
    console.print(runs_table)
    console.print()

    edges = data.get("edges", [])
    if not edges:
        return
    edges_table = Table(
        title="Edges", show_header=True, header_style="bold cyan", border_style="dim"
    )
    edges_table.add_column("Kind")
    edges_table.add_column("Label")
    edges_table.add_column("Parent")
    edges_table.add_column("Child")
    edges_table.add_column("Cost", justify="right")
    for e in edges:
        cost = e.get("cost_attributed")
        cost_str = f"${cost:.4f}" if cost else "-"
        kind = e.get("kind", "?")
        edges_table.add_row(
            f"[{_kind_style(kind)}]{kind}[/{_kind_style(kind)}]",
            e.get("edge_label") or "-",
            (e.get("parent_run_id") or "-")[:12],
            (e.get("child_run_id") or "-")[:12],
            cost_str,
        )
    console.print(edges_table)
