"""Network-monitor uploader CLI — tails os_log + POSTs to controlplane.

Mirrors the `cowork` command shape: `init` (later), `watch` (the foreground
loop), `cursor` (reset/inspect), and `service install/uninstall/status`
(launchd / Windows Service registration — later).
"""

import logging

import click

from .._display import print_error, print_info, print_warning


@click.group("network-monitor")
def network_monitor():
    """Network-monitor flow uploader (Mac system extension → controlplane)."""
    pass


@network_monitor.command("watch")
@click.option(
    "--profile",
    default="connect",
    help=(
        "~/.waxell/config section to read api_key/api_url from "
        "(default: connect — same section the installer signs in to)."
    ),
)
@click.option(
    "--poll",
    default=5.0,
    type=float,
    help="Polling interval in seconds (default: 5.0)",
)
@click.option(
    "--flush",
    default=30.0,
    type=float,
    help="Max seconds to buffer before forcing a flush (default: 30.0)",
)
@click.option(
    "--batch",
    default=200,
    type=int,
    help="Max events per batch before forcing a flush (default: 200)",
)
@click.option(
    "--verbose",
    is_flag=True,
    help="Log every processed flow",
)
def watch(profile, poll, flush, batch, verbose):
    """Tail the system extension's os_log entries and ship batches to
    `/api/waxell/v1/endpoint/flows`.

    Runs in the foreground — keep a terminal tab open. Ctrl-C to stop.
    Best run as a launchd agent in production (see `service install`).

    Cursor at `~/.waxell/network-monitor-cursor.json` lets restarts resume
    at the last successfully uploaded timestamp; macOS persists `os_log`
    for hours so the OS provides the durable buffer.

    Typical usage:

        wax network-monitor watch --verbose

    Reads the API key from `~/.waxell/config` `[connect]` section by
    default — same credential the installer signed in with. Override with
    `WAXELL_API_KEY` env var or `--profile <other>`.
    """
    from ...integrations.network_monitor.uploader import watch_flows

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    print_info(f"Starting network-monitor uploader (profile={profile}, poll={poll}s)")

    try:
        watch_flows(
            profile=profile,
            poll_interval=poll,
            flush_interval=flush,
            batch_size=batch,
            verbose=verbose,
        )
    except KeyboardInterrupt:
        print_info("\nStopped.")
    except RuntimeError as e:
        print_error(str(e))
        raise SystemExit(1)


@network_monitor.command("cursor")
@click.option(
    "--reset", is_flag=True, help="Delete the cursor file (next run starts at 'now')"
)
def cursor(reset):
    """Show or reset the upload cursor."""
    from ...integrations.network_monitor.uploader import CURSOR_PATH, _load_cursor

    if reset:
        if CURSOR_PATH.exists():
            CURSOR_PATH.unlink()
            print_info(f"Removed {CURSOR_PATH}")
        else:
            print_warning("No cursor file existed.")
        return

    last = _load_cursor()
    if last is None:
        print_info(f"No cursor at {CURSOR_PATH} — next run starts at 'now'.")
    else:
        print_info(f"{CURSOR_PATH}: last_timestamp={last}")


@network_monitor.command("poll")
@click.option(
    "--profile",
    default="connect",
    help="~/.waxell/config section to read api_key/api_url from.",
)
@click.option(
    "--interval",
    default=60.0,
    type=float,
    help="Poll interval in seconds (default: 60.0 — matches Cache-Control hint).",
)
@click.option(
    "--agent-slug",
    default=None,
    help=(
        "Agent slug to scope the config to (e.g. 'claude-code-prod'). "
        "Omit for the tenant-default merged config."
    ),
)
@click.option(
    "--once",
    is_flag=True,
    help="Run a single fetch + persist cycle and exit (for testing / launchd one-shot).",
)
@click.option(
    "--long-poll",
    "long_poll_seconds",
    default=0,
    type=int,
    help=(
        "G2 — server-side long-poll wait (seconds, max 300). 0 = short-poll "
        "with ETag (default). Non-zero = server holds the connection until "
        "the etag changes or the wait expires."
    ),
)
def poll(profile, interval, agent_slug, once, long_poll_seconds):
    """Long-poll the controlplane for guard-config updates and write
    `~/.waxell/policy.json` on every change.

    The system extension's network filter reads `policy.json` to decide
    allow/block on each new flow, and the local guard (claude-code,
    cowork) reads the same file so all enforcement surfaces share one
    truth.

    Uses ETag / If-None-Match — quiet 304s mean the only network cost
    is request headers when policy hasn't changed. New body → atomic
    write to `~/.waxell/policy.json`.

    Typical usage:

        wax network-monitor poll                    # daemon mode
        wax network-monitor poll --once             # single fetch
        wax network-monitor poll --agent-slug cc-1  # per-agent merge

    Reads `[connect]` API key by default — same credential the
    installer signed in with. Override with `WAXELL_API_KEY` or
    `--profile <other>`.
    """
    from ...integrations.network_monitor.policy_poller import (
        POLICY_PATH,
        poll_once,
        watch_policy,
    )
    from ...integrations.network_monitor.uploader import _resolve_api_key_and_url

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    if once:
        api_key, api_url = _resolve_api_key_and_url(profile)
        if not api_key:
            print_error(
                f"No API key found. Set WAXELL_API_KEY or [{profile}] in ~/.waxell/config."
            )
            raise SystemExit(1)
        result = poll_once(
            api_url=api_url,
            api_key=api_key,
            agent_slug=agent_slug,
            wait_seconds=long_poll_seconds,
        )
        if result.status == "updated":
            print_info(f"policy.json updated (etag={result.etag}) → {POLICY_PATH}")
        elif result.status == "not_modified":
            print_info("policy unchanged (304 from server)")
        else:
            print_error(f"poll failed: {result.error}")
            raise SystemExit(1)
        return

    print_info(f"Starting policy poller (profile={profile}, interval={interval}s)")
    try:
        watch_policy(
            profile=profile,
            poll_interval=interval,
            agent_slug=agent_slug,
            long_poll_seconds=long_poll_seconds,
        )
    except KeyboardInterrupt:
        print_info("\nStopped.")
    except RuntimeError as e:
        print_error(str(e))
        raise SystemExit(1)


@network_monitor.command("policy")
@click.option(
    "--reset",
    is_flag=True,
    help="Delete `~/.waxell/policy.json` and the etag cache.",
)
def policy(reset):
    """Show or reset the locally-cached policy.json."""
    from ...integrations.network_monitor.policy_poller import (
        ETAG_PATH,
        POLICY_PATH,
        _load_etag,
        _load_policy,
    )

    if reset:
        for p in (POLICY_PATH, ETAG_PATH):
            if p.exists():
                p.unlink()
                print_info(f"Removed {p}")
        return

    etag = _load_etag()
    pol = _load_policy()
    if pol is None:
        print_warning(
            f"No policy at {POLICY_PATH} — run `wax network-monitor poll --once`."
        )
        return
    print_info(f"{POLICY_PATH}: etag={etag or '(none)'}")
    print_info(f"  policy_version={pol.get('policy_version')}")
    print_info(f"  block_domains={len(pol.get('block_domains') or [])}")
    print_info(f"  block_processes={len(pol.get('block_processes') or [])}")
    print_info(f"  blocked_users={len(pol.get('blocked_users') or [])}")
    print_info(f"  redirect_rules={len(pol.get('redirect_rules') or [])}")
    print_info(f"  commands={len(pol.get('commands') or [])}")


# ---------------------------------------------------------------------------
# Persistent service management — keep uploader + poller alive across reboot
# ---------------------------------------------------------------------------

UPLOADER_SERVICE_LABEL = "dev.waxell.network-monitor.uploader"
POLLER_SERVICE_LABEL = "dev.waxell.network-monitor.poller"


@network_monitor.group("service")
def service():
    """Manage uploader + poller as persistent OS services.

    On macOS this installs two LaunchAgent plists (one for `watch`,
    one for `poll`) so the daemons survive reboot and restart on
    crash. Windows / Linux uploaders are separate modules — service
    install is macOS-only today.
    """


@service.command("install")
@click.option(
    "--profile",
    default="connect",
    help="~/.waxell/config section the daemons read (default: connect).",
)
@click.option(
    "--watch-poll",
    default=5.0,
    type=float,
    help="Uploader poll interval in seconds (default: 5.0).",
)
@click.option(
    "--policy-interval",
    default=60.0,
    type=float,
    help="Policy poller interval in seconds (default: 60.0).",
)
@click.option(
    "--no-poller",
    is_flag=True,
    help="Skip installing the policy poller (uploader only).",
)
@click.option(
    "--no-uploader",
    is_flag=True,
    help="Skip installing the flow uploader (poller only).",
)
def service_install(profile, watch_poll, policy_interval, no_poller, no_uploader):
    """Install uploader + poller as launchd LaunchAgents."""
    import platform

    if platform.system() != "Darwin":
        print_error(
            "service install is macOS-only today. Windows uses ETW + Scheduled Tasks "
            "(separate module — not yet shipped)."
        )
        raise SystemExit(1)

    if no_poller and no_uploader:
        print_error("--no-poller and --no-uploader together installs nothing.")
        raise SystemExit(1)

    wax_path = _wax_binary_path()

    if not no_uploader:
        _install_launchd_uploader(wax_path, profile=profile, poll=watch_poll)
    if not no_poller:
        _install_launchd_poller(wax_path, profile=profile, interval=policy_interval)


@service.command("uninstall")
def service_uninstall():
    """Remove both LaunchAgents."""
    import platform

    if platform.system() != "Darwin":
        print_error("service uninstall is macOS-only.")
        raise SystemExit(1)
    _uninstall_launchd(UPLOADER_SERVICE_LABEL)
    _uninstall_launchd(POLLER_SERVICE_LABEL)


@service.command("status")
def service_status():
    """Show whether either daemon is registered + running."""
    import platform

    if platform.system() != "Darwin":
        print_error("service status is macOS-only.")
        raise SystemExit(1)
    _status_launchd(UPLOADER_SERVICE_LABEL, "uploader")
    _status_launchd(POLLER_SERVICE_LABEL, "poller")


# ---- launchd helpers ----


def _wax_binary_path() -> str:
    import shutil
    import sys
    from pathlib import Path

    wax_path = shutil.which("wax") or sys.argv[0]
    if not Path(wax_path).exists():
        print_error(f"Can't find `wax` binary at {wax_path}")
        raise SystemExit(1)
    return wax_path


def _launchd_plist_path(label: str):
    from pathlib import Path

    return Path.home() / "Library" / "LaunchAgents" / f"{label}.plist"


def _launchd_log_paths(label: str):
    from pathlib import Path

    log_dir = Path.home() / ".waxell" / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    short = label.split(".")[-1]  # "uploader" / "poller"
    return (
        log_dir / f"network-monitor-{short}.out.log",
        log_dir / f"network-monitor-{short}.err.log",
    )


def _build_plist(*, label: str, args: list[str], stdout: str, stderr: str) -> str:
    """Produce the LaunchAgent plist XML.

    KeepAlive only on crash (don't relaunch successful exits — the
    daemons run forever). ThrottleInterval=10 prevents tight crashloops.
    """
    args_xml = "\n".join(f"    <string>{a}</string>" for a in args)
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>{label}</string>
  <key>ProgramArguments</key>
  <array>
{args_xml}
  </array>
  <key>RunAtLoad</key>
  <true/>
  <key>KeepAlive</key>
  <dict>
    <key>SuccessfulExit</key>
    <false/>
    <key>Crashed</key>
    <true/>
  </dict>
  <key>ThrottleInterval</key>
  <integer>10</integer>
  <key>StandardOutPath</key>
  <string>{stdout}</string>
  <key>StandardErrorPath</key>
  <string>{stderr}</string>
  <key>EnvironmentVariables</key>
  <dict>
    <key>PATH</key>
    <string>/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin</string>
  </dict>
</dict>
</plist>
"""


def _load_plist(plist_path) -> None:
    """Replace any prior load and load the current plist."""
    import subprocess

    subprocess.run(["launchctl", "unload", str(plist_path)], capture_output=True)
    result = subprocess.run(
        ["launchctl", "load", str(plist_path)], capture_output=True, text=True
    )
    if result.returncode != 0:
        print_error(f"launchctl load failed: {result.stderr.strip()}")
        raise SystemExit(1)


def _install_launchd_uploader(wax_path: str, *, profile: str, poll: float):
    plist_path = _launchd_plist_path(UPLOADER_SERVICE_LABEL)
    plist_path.parent.mkdir(parents=True, exist_ok=True)
    stdout, stderr = _launchd_log_paths(UPLOADER_SERVICE_LABEL)
    plist = _build_plist(
        label=UPLOADER_SERVICE_LABEL,
        args=[
            wax_path,
            "network-monitor",
            "watch",
            "--profile",
            profile,
            "--poll",
            str(poll),
        ],
        stdout=str(stdout),
        stderr=str(stderr),
    )
    plist_path.write_text(plist)
    _load_plist(plist_path)
    from .._display import print_success

    print_success(f"Installed uploader LaunchAgent: {plist_path}")
    print_info(f"  Logs: {stdout}")


def _install_launchd_poller(wax_path: str, *, profile: str, interval: float):
    plist_path = _launchd_plist_path(POLLER_SERVICE_LABEL)
    plist_path.parent.mkdir(parents=True, exist_ok=True)
    stdout, stderr = _launchd_log_paths(POLLER_SERVICE_LABEL)
    plist = _build_plist(
        label=POLLER_SERVICE_LABEL,
        args=[
            wax_path,
            "network-monitor",
            "poll",
            "--profile",
            profile,
            "--interval",
            str(interval),
        ],
        stdout=str(stdout),
        stderr=str(stderr),
    )
    plist_path.write_text(plist)
    _load_plist(plist_path)
    from .._display import print_success

    print_success(f"Installed poller LaunchAgent: {plist_path}")
    print_info(f"  Logs: {stdout}")


def _uninstall_launchd(label: str):
    import subprocess

    plist_path = _launchd_plist_path(label)
    if not plist_path.exists():
        print_info(f"No LaunchAgent for {label}.")
        return
    subprocess.run(["launchctl", "unload", str(plist_path)], capture_output=True)
    plist_path.unlink()
    from .._display import print_success

    print_success(f"Removed {plist_path}")


def _status_launchd(label: str, friendly: str):
    import subprocess

    plist_path = _launchd_plist_path(label)
    if not plist_path.exists():
        print_warning(f"{friendly}: not installed.")
        return
    print_info(f"{friendly}: plist={plist_path}")
    result = subprocess.run(
        ["launchctl", "list", label],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        print_warning(
            f"  launchctl list failed: {result.stderr.strip() or '(no stderr)'}"
        )
        return
    pid = None
    last_exit = None
    for line in result.stdout.splitlines():
        s = line.strip().rstrip(";")
        if s.startswith('"PID"'):
            pid = s.split("=")[-1].strip()
        elif s.startswith('"LastExitStatus"'):
            last_exit = s.split("=")[-1].strip()
    if pid and pid != "-":
        from .._display import print_success

        print_success(f"  running (PID {pid})")
    else:
        print_warning(f"  registered but not running (LastExitStatus={last_exit})")
