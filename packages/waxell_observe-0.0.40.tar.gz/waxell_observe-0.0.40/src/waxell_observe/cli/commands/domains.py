"""Tenant domain config self-serve CLI.

    wax domains list
    wax domains show <domain_name>
    wax domains enable-per-user-auth <domain_name>
    wax domains disable-per-user-auth <domain_name>
    wax domains activate <domain_name> / deactivate <domain_name>

Lets tenants flip per-domain toggles (`per_user_auth_enabled`) without
needing a Waxell engineer. Sub-user tokens are always v2 (Ed25519 +
JWKS) — there is no version selector.
"""

from __future__ import annotations

import json
from typing import Any

import click
from rich.table import Table

from .._display import console, print_header, print_warning, status_dot
from .._http import api_get, api_patch


def _fmt_bool(v: Any) -> str:
    return "✓" if v else "—"


@click.group("domains")
def domains():
    """Manage tenant domain configurations (per-user-auth, token version)."""


@domains.command("list")
@click.option(
    "--format",
    "fmt",
    type=click.Choice(["table", "json"]),
    default="table",
)
@click.pass_context
def list_(ctx, fmt):
    """List this tenant's domain configs."""
    data = api_get(ctx, "/v1/domains/")
    rows = data.get("results", [])
    if fmt == "json":
        console.print_json(json.dumps(data, indent=2))
        return
    if not rows:
        print_warning("No domain configs registered for this tenant.")
        return

    print_header("Tenant Domain Configs", f"{len(rows)} rows")
    t = Table(show_header=True, header_style="bold cyan", border_style="dim")
    t.add_column("Domain", style="bold")
    t.add_column("Base URL")
    t.add_column("Auth")
    t.add_column("Per-user auth", justify="center")
    t.add_column("Active", justify="center")
    for r in rows:
        t.add_row(
            r.get("domain_name", "-"),
            r.get("base_url", "-"),
            r.get("auth_type", "-"),
            _fmt_bool(r.get("per_user_auth_enabled")),
            status_dot("active" if r.get("is_active") else "inactive"),
        )
    console.print(t)


@domains.command("show")
@click.argument("domain_name")
@click.option(
    "--format",
    "fmt",
    type=click.Choice(["human", "json"]),
    default="human",
)
@click.pass_context
def show(ctx, domain_name, fmt):
    """Show full detail for one domain."""
    data = api_get(ctx, f"/v1/domains/{domain_name}/")
    if fmt == "json":
        console.print_json(json.dumps(data, indent=2))
        return
    print_header(
        f"Domain: {data.get('domain_name', '-')}",
        data.get("base_url", "-"),
    )
    for field in (
        "id",
        "domain_name",
        "base_url",
        "path_template",
        "auth_type",
        "timeout_seconds",
        "retry_attempts",
        "is_active",
        "per_user_auth_enabled",
        "sub_user_token_endpoint",
        "last_verified_at",
        "verification_status",
    ):
        console.print(
            f"[dim]{field}:[/dim]  {data.get(field) if data.get(field) is not None else '—'}"
        )
    if data.get("actions"):
        console.print(f"[dim]actions:[/dim]  {', '.join(data['actions'])}")
    if data.get("headers"):
        console.print("[dim]headers:[/dim]")
        console.print_json(json.dumps(data["headers"], indent=2))


def _patch(ctx, domain_name, body):
    return api_patch(ctx, f"/v1/domains/{domain_name}/", json=body)


@domains.command("enable-per-user-auth")
@click.argument("domain_name")
@click.pass_context
def enable_per_user_auth(ctx, domain_name):
    """Turn on sub-user header emission for this domain."""
    data = _patch(ctx, domain_name, {"per_user_auth_enabled": True})
    console.print(
        f"[green]Enabled[/green]  {data['domain_name']}: "
        f"per_user_auth_enabled={data.get('per_user_auth_enabled')}"
    )


@domains.command("disable-per-user-auth")
@click.argument("domain_name")
@click.pass_context
def disable_per_user_auth(ctx, domain_name):
    """Turn off sub-user header emission for this domain."""
    data = _patch(ctx, domain_name, {"per_user_auth_enabled": False})
    console.print(
        f"[yellow]Disabled[/yellow]  {data['domain_name']}: "
        f"per_user_auth_enabled={data.get('per_user_auth_enabled')}"
    )


@domains.command("set-version")
@click.argument("domain_name")
@click.argument("version", type=click.Choice(["v1", "v2"]))
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation.")
@click.pass_context
def set_version(ctx, domain_name, version, yes):
    """Flip sub_user_token_version for this domain (v1 HMAC ↔ v2 Ed25519).

    Your verifier must already handle the target version. v1 tokens fail
    on v2-only verifiers and vice versa. Plan in advance.
    """
    if not yes:
        print_warning(
            f"About to flip {domain_name} → {version}. Your verifier must "
            f"already accept this prefix. If in doubt, verify with a "
            f"single test call before committing more traffic."
        )
        click.confirm(f"Set {domain_name} to {version}?", abort=True)

    data = _patch(ctx, domain_name, {"sub_user_token_version": version})
    console.print(
        f"[green]Set[/green]  {data['domain_name']}: "
        f"sub_user_token_version={data.get('sub_user_token_version')}"
    )


@domains.command("activate")
@click.argument("domain_name")
@click.pass_context
def activate(ctx, domain_name):
    """Mark this domain config active (is_active=True)."""
    data = _patch(ctx, domain_name, {"is_active": True})
    console.print(f"[green]Active[/green]  {data['domain_name']}")


@domains.command("deactivate")
@click.argument("domain_name")
@click.pass_context
def deactivate(ctx, domain_name):
    """Pause this domain (is_active=False). Existing runs will error on
    next call to this domain until you re-activate."""
    data = _patch(ctx, domain_name, {"is_active": False})
    console.print(f"[yellow]Inactive[/yellow]  {data['domain_name']}")
