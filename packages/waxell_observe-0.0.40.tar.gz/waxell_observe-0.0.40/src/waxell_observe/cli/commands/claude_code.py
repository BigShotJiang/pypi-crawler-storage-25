"""Claude Code & Cowork integration commands."""

import json as _json

import click

from .._display import (
    console,
    print_header,
    print_success,
    print_error,
    print_info,
    print_warning,
    status_dot,
    fmt_number,
)
from rich.table import Table


@click.group("claude-code")
def claude_code():
    """Claude Code & Cowork observability integration."""
    pass


@claude_code.command()
@click.option(
    "--global", "global_config", is_flag=True, help="Write to ~/.claude/ (all projects)"
)
@click.option(
    "--governance",
    is_flag=True,
    help="Enable PreToolUse policy enforcement (blocking hooks)",
)
@click.option("--mcp", is_flag=True, help="Register MCP server in .mcp.json")
@click.option("--project-dir", default=None, help="Project directory (defaults to cwd)")
@click.option(
    "--profile",
    "install_profile",
    default="claude-code",
    help="Waxell config profile to use (default: claude-code). Each tool should have its own profile.",
)
@click.option(
    "--governance-tools",
    "governance_matcher",
    default=None,
    help=(
        "Regex of tools the governance hook fires on (default: "
        "Bash|Edit|Write|Task|mcp__.*). Pass a tighter or wider value "
        "to scope policy enforcement. Ignored without --governance."
    ),
)
@click.option(
    "--isolation",
    type=click.Choice(["profile", "project"]),
    default="profile",
    show_default=True,
    help=(
        "Hook scoping. 'profile' (default): one daily run + dedupe per "
        "Waxell profile, shared across projects. 'project': forces "
        "project-local settings + injects WAXELL_PROJECT_KEY so two "
        "repos sharing a profile get independent state."
    ),
)
def setup(
    global_config: bool,
    governance: bool,
    mcp: bool,
    project_dir: str,
    install_profile: str,
    governance_matcher: str,
    isolation: str,
):
    """Configure Claude Code hooks for Waxell observability.

    Sets up hooks in .claude/settings.json so Claude Code sessions
    are automatically tracked as agent runs in Waxell.

    \b
    Examples:
      wax claude-code setup                           # Basic observability (profile: claude-code)
      wax claude-code setup --governance              # + policy enforcement
      wax claude-code setup --governance --mcp        # + MCP tools for Claude
      wax claude-code setup --global                  # Apply to all projects
      wax claude-code setup --profile claude-cowork   # Configure Cowork with separate profile
      wax claude-code setup --governance --governance-tools "Bash"   # Shell-only governance
      wax claude-code setup --isolation project       # Per-repo daily run + dedupe namespace
    """
    from ...integrations.claude_code import setup_hooks

    try:
        result = setup_hooks(
            project_dir=project_dir,
            global_config=global_config,
            governance=governance,
            mcp=mcp,
            profile=install_profile,
            governance_matcher=governance_matcher,
            isolation=isolation,
        )
    except Exception as e:
        print_error(f"Setup failed: {e}")
        raise SystemExit(1)

    print_header(
        "Claude Code Integration", f"Setup complete (profile: {install_profile})"
    )

    for line in result.get("summary", []):
        print_success(line)

    console.print()

    if not governance:
        print_info(
            "Tip: Use --governance to enable policy enforcement (PreToolUse blocking)"
        )
    if not mcp:
        print_info(
            "Tip: Use --mcp to register the MCP server (gives Claude policy-check & budget tools)"
        )

    console.print()
    print_info("Restart Claude Code to activate hooks.")


@claude_code.command()
@click.option(
    "--global",
    "global_config",
    is_flag=True,
    help="Remove from ~/.claude/ (all projects)",
)
@click.option("--project-dir", default=None, help="Project directory (defaults to cwd)")
@click.option(
    "--profile",
    "remove_profile",
    default="claude-code",
    help="Waxell profile whose hooks to remove (default: claude-code)",
)
@click.option(
    "--keep-mcp",
    is_flag=True,
    help="Leave the MCP server entry in .mcp.json (default: remove it)",
)
@click.option(
    "--remove-profile-from-config",
    is_flag=True,
    help="Also delete the [profile] section from ~/.waxell/config (default: leave intact)",
)
def remove(
    global_config: bool,
    project_dir: str,
    remove_profile: str,
    keep_mcp: bool,
    remove_profile_from_config: bool,
):
    """Remove Waxell hooks and MCP registration for a profile.

    Leaves other profiles, user-defined hooks, and non-waxell settings untouched.

    \b
    Examples:
      wax claude-code remove --global                         # Remove default claude-code profile
      wax claude-code remove --global --profile claude-cowork # Remove Cowork specifically
      wax claude-code remove --remove-profile-from-config     # Also delete config section
    """
    from ...integrations.claude_code import remove_hooks

    try:
        result = remove_hooks(
            project_dir=project_dir,
            global_config=global_config,
            profile=remove_profile,
            remove_mcp=not keep_mcp,
            remove_profile_from_config=remove_profile_from_config,
        )
    except Exception as e:
        print_error(f"Remove failed: {e}")
        raise SystemExit(1)

    print_header("Claude Code Integration", f"Removed profile: {remove_profile}")

    for line in result.get("summary", []):
        print_success(line)


@claude_code.command("install-status")
@click.option("--json", "as_json", is_flag=True, help="Emit machine-readable JSON")
@click.option(
    "--global",
    "global_config",
    is_flag=True,
    default=True,
    help="Check ~/.claude/ (default: true)",
)
@click.option(
    "--project-dir", default=None, help="Project directory (when --global is not used)"
)
def install_status(as_json: bool, global_config: bool, project_dir: str):
    """Report install state: binary, config profiles, hooks, MCP servers.

    Used by the installer GUI to decide what to configure.
    """
    from ...integrations.claude_code import detect_status

    status = detect_status(project_dir=project_dir, global_config=global_config)

    if as_json:
        click.echo(_json.dumps(status, indent=2))
        return

    # Human-readable output
    bin_info = status["binary"]
    if bin_info["installed"]:
        print_success(
            f"Binary: {bin_info['path']} (v{bin_info.get('version') or 'unknown'})"
        )
    else:
        print_warning("Binary: not installed")

    cfg = status["config"]
    if cfg["exists"]:
        profiles = cfg["profiles"]
        if profiles:
            print_info(f"Config: {cfg['path']} — {len(profiles)} profile(s)")
            for name, info in profiles.items():
                key_state = "has api_key" if info["has_api_key"] else "no api_key"
                console.print(
                    f"    [{name}] — {key_state}, api_url={info.get('api_url') or '(unset)'}"
                )
        else:
            print_warning(f"Config: {cfg['path']} exists but has no profiles")
    else:
        print_warning(f"Config: {cfg['path']} does not exist")

    cc = status["claude_code"]
    if cc["settings_exists"]:
        configured = cc["hooks_profiles"]
        if configured:
            print_success(
                f"Hooks: {cc['settings_path']} — profiles configured: {', '.join(configured)}"
            )
        else:
            print_info(
                f"Hooks: {cc['settings_path']} exists but no waxell profiles configured"
            )
        if cc.get("legacy_hooks_present"):
            print_warning(
                "  Legacy (profile-less) waxell hooks detected — re-run setup to migrate"
            )
    else:
        print_info(f"Hooks: {cc['settings_path']} does not exist")

    mcp_profiles = cc.get("mcp_profiles") or {}
    if mcp_profiles:
        print_success(
            f"MCP: {cc['mcp_path']} — {len(mcp_profiles)} server(s): {', '.join(mcp_profiles.values())}"
        )
    elif cc.get("mcp_exists"):
        print_info(f"MCP: {cc['mcp_path']} exists but no waxell servers configured")
    if cc.get("legacy_mcp_present"):
        print_warning(
            "  Legacy (profile-less) waxell MCP server detected — re-run setup to migrate"
        )


@claude_code.command()
def hook():
    """Handle a Claude Code hook event (called by hooks, not directly).

    Reads hook JSON from stdin and dispatches to the appropriate handler.
    This command is invoked automatically by Claude Code's hook system.
    """
    from ...integrations.claude_code import handle_hook

    handle_hook()


@claude_code.command("profile-detect")
def profile_detect():
    """SessionStart shim — auto-inject WAXELL_PROFILE from <cwd>/.waxell-profile.

    Reads SessionStart JSON from stdin, looks for a `.waxell-profile` file
    in the session's cwd, and (if found and valid) emits a Claude Code
    hook response that injects WAXELL_PROFILE for the rest of the session.

    Eliminates manual `WAXELL_PROFILE=...` exports when switching between
    projects that need different profiles. Silently no-ops when the file
    is missing or invalid — your configured-at-setup-time profile applies.
    """
    from ...integrations.claude_code.profile_detect import main as _profile_detect_main

    _profile_detect_main()


@claude_code.command("mcp-server")
def mcp_server():
    """Run the MCP server for Claude Code governance tools.

    Provides tools that Claude Code can call proactively:
    - waxell_check_policy: Check if an action is allowed
    - waxell_budget_status: Query session budget
    - waxell_record_decision: Record a decision for audit trail

    This is registered in .mcp.json and launched by Claude Code.
    """
    from ...integrations.claude_code.mcp_server import run_mcp_server

    run_mcp_server()


@claude_code.command()
def status():
    """Show current Claude Code session state and recent activity.

    (For install state, use `wax claude-code install-status`.)
    """
    from ...integrations.claude_code.state import STATE_DIR, load_state

    if not STATE_DIR.exists():
        print_warning("No active Claude Code sessions found.")
        print_info(f"State directory: {STATE_DIR}")
        return

    state_files = sorted(
        STATE_DIR.glob("*.json"),
        key=lambda f: f.stat().st_mtime,
        reverse=True,
    )

    if not state_files:
        print_warning("No active Claude Code sessions found.")
        return

    print_header("Claude Code Sessions", f"{len(state_files)} active")

    table = Table(show_header=True, header_style="bold cyan", border_style="dim")
    table.add_column("Session ID", style="bold", max_width=20)
    table.add_column("Run ID", max_width=20)
    table.add_column("Model")
    table.add_column("Spans", justify="right")
    table.add_column("Cowork")
    table.add_column("Started")
    table.add_column("CWD", style="dim", max_width=30)

    for sf in state_files[:10]:
        session_id = sf.stem
        state = load_state(session_id)
        if not state:
            continue

        cowork_status = (
            f"{status_dot('active')} Yes" if state.is_cowork else "[dim]No[/dim]"
        )

        table.add_row(
            state.session_id[:18] + "..."
            if len(state.session_id) > 18
            else state.session_id,
            state.run_id[:18] + "..." if len(state.run_id) > 18 else state.run_id,
            state.model or "[dim]-[/dim]",
            fmt_number(state.span_count),
            cowork_status,
            state.started_at[:19] if state.started_at else "[dim]-[/dim]",
            state.cwd or "[dim]-[/dim]",
        )

    console.print(table)
    console.print()


@claude_code.command()
def clean():
    """Remove stale session state files."""
    from ...integrations.claude_code.state import cleanup_stale_states, STATE_DIR

    if not STATE_DIR.exists():
        print_info("No state directory to clean.")
        return

    removed = cleanup_stale_states()
    if removed:
        print_success(f"Removed {removed} stale session state file(s).")
    else:
        print_info("No stale state files found.")
