"""Cowork observability — watches Anthropic's audit.jsonl files and ships
events to Waxell as runs attributed to a Connect agent."""

import configparser
import json
import logging
import os
import platform
import urllib.error
import urllib.request
from pathlib import Path

import click

from .._display import print_error, print_info, print_success, print_warning


@click.group("cowork")
def cowork():
    """Claude Cowork observability integration."""
    pass


@cowork.command("init")
@click.argument("api_key", required=False)
@click.option(
    "--api-url",
    default="https://api.waxell.dev",
    help="Waxell API base URL (default: https://api.waxell.dev)",
)
@click.option(
    "--profile",
    default="claude-cowork",
    help="Config profile to write (default: claude-cowork)",
)
@click.option(
    "--label",
    default=None,
    help="Label for the linked hook key (default: this machine's hostname)",
)
@click.option(
    "--config-path",
    default=None,
    help="Override config file location (default: ~/.waxell/config)",
)
def init(api_key, api_url, profile, label, config_path):
    """One-shot setup for the Cowork watcher.

    Takes any tenant API key, asks the controlplane to:
      1. Resolve which Connect agent owns it
      2. Mint a fresh hook key dedicated to THIS machine (so rotating the
         original key doesn't break your watcher)

    Then writes the hook key + agent_slug into ~/.waxell/config under the
    given profile so `wax cowork watch` Just Works.

    \b
    Examples:
      wax cowork init wax_sk_<your_key>
      wax cowork init wax_sk_<key> --label "Beth's PC"
      wax cowork init wax_sk_<key> --profile claude-code
    """
    if not api_key:
        api_key = click.prompt(
            "Paste your Waxell tenant API key (any agent's key works)",
            hide_input=True,
        ).strip()
    if not api_key.startswith(("wax_sk_", "wax_pk_")):
        print_error(
            "Doesn't look like a Waxell API key (should start with wax_sk_ or wax_pk_)"
        )
        raise SystemExit(1)

    api_url = api_url.rstrip("/")
    label = label or platform.node() or "Unknown machine"

    # 1. Resolve the key → agent
    print_info("Resolving agent for this key...")
    try:
        resp = _post_json(
            f"{api_url}/api/v1/connect/agents/resolve-key/",
            {
                "api_key": api_key,
                "agent_type": profile if profile.startswith("claude-") else "mcp",
            },
        )
    except Exception as e:
        print_error(f"resolve-key failed: {e}")
        raise SystemExit(1)
    agent_slug = resp.get("agent_slug")
    agent_name = resp.get("agent_name") or "Unnamed agent"
    tenant_slug = resp.get("tenant_slug") or "(unknown tenant)"
    if not agent_slug:
        print_error(
            "Server didn't return an agent_slug — your key has no Connect agent."
        )
        raise SystemExit(1)
    print_success(
        f"  Resolved: {agent_name} (slug: {agent_slug}) in tenant: {tenant_slug}"
    )

    # 2. Mint a hook key dedicated to this machine
    print_info(f"Minting dedicated hook key for '{label}'...")
    try:
        mint = _post_json(
            f"{api_url}/api/v1/connect/agents/{agent_slug}/create-hook-key/",
            {"label": label, "tool_profile": profile},
            headers={"X-Wax-Key": api_key},
        )
    except Exception as e:
        print_error(f"create-hook-key failed: {e}")
        raise SystemExit(1)
    hook_key = mint.get("api_key")
    if not hook_key:
        print_error("Server didn't return a hook key.")
        raise SystemExit(1)
    print_success(
        f"  Created: {mint.get('api_key_prefix', '')}... (id: {mint.get('link_id', '')[:8]})"
    )

    # 3. Write the profile to ~/.waxell/config (atomic, preserving other profiles)
    cfg_path = (
        Path(config_path).expanduser()
        if config_path
        else Path.home() / ".waxell" / "config"
    )
    cfg_path.parent.mkdir(parents=True, exist_ok=True)

    cfg = configparser.ConfigParser()
    if cfg_path.exists():
        cfg.read(cfg_path)
    if not cfg.has_section(profile):
        cfg.add_section(profile)
    cfg.set(profile, "api_key", hook_key)
    cfg.set(profile, "api_url", api_url)
    cfg.set(profile, "agent_slug", agent_slug)

    tmp = str(cfg_path) + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        cfg.write(f)
    os.replace(tmp, cfg_path)
    try:
        os.chmod(cfg_path, 0o600)
    except OSError:
        pass  # Windows ACLs differ; chmod is a no-op there

    print_success(f"  Config written to {cfg_path}")
    print_info("")
    print_info("You're set up. Start the watcher with:")
    print_info(f"    wax --profile {profile} cowork watch --verbose")
    print_info("")
    print_info(
        f"Activity will appear at https://app.waxell.dev/observability/connect-agents/{agent_slug}"
    )


def _post_json(url: str, body: dict, headers: dict | None = None) -> dict:
    """Minimal stdlib POST helper (no httpx dep needed for setup commands)."""
    data = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(url, data=data, method="POST")
    req.add_header("Content-Type", "application/json")
    if headers:
        for k, v in headers.items():
            req.add_header(k, v)
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body_text = e.read().decode("utf-8", errors="replace")[:500]
        raise RuntimeError(f"HTTP {e.code}: {body_text}")


@cowork.command("watch")
@click.option(
    "--root",
    default=None,
    help=(
        "Override the Cowork session directory "
        "(defaults to ~/Library/Application Support/Claude/local-agent-mode-sessions)"
    ),
)
@click.option(
    "--agent-slug",
    default=None,
    help="Override the agent_slug used for run attribution. Defaults to the profile's agent_slug.",
)
@click.option(
    "--agent-type",
    default="claude-cowork",
    help="agent_name value for runs created by the watcher (default: claude-cowork)",
)
@click.option(
    "--poll",
    default=2.0,
    type=float,
    help="Polling interval in seconds (default: 2.0)",
)
@click.option(
    "--verbose",
    is_flag=True,
    help="Log every processed event",
)
@click.option(
    "--cursor",
    default=None,
    help="Override cursor file location (default: ~/.waxell/cowork-cursor.json)",
)
@click.option(
    "--from-start",
    is_flag=True,
    help=(
        "Process the ENTIRE audit history of every existing session file. "
        "Default: skip to EOF on first sight so only new events after watcher "
        "starts are captured."
    ),
)
def watch(root, agent_slug, agent_type, poll, verbose, cursor, from_start):
    """Watch Cowork audit logs and stream events to Waxell.

    Runs in the foreground — keep a terminal tab open. Ctrl-C to stop.

    Behavior:
      - Discovers every audit.jsonl under the Cowork session root
      - Creates one observe run per Cowork session, attributed to your profile's
        agent_slug (or --agent-slug override)
      - Streams every user / assistant / tool_use / tool_result event as a step
      - Records LLM token usage from assistant messages
      - Persists a cursor so restarts resume at the next unread byte

    Typical usage:
      wax --profile claude-cowork cowork watch --verbose
    """
    from ...integrations.cowork import watch_audit_logs

    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )

    root_path = Path(root).expanduser() if root else None
    cursor_path = Path(cursor).expanduser() if cursor else None

    print_info("Starting Cowork audit watcher (Ctrl-C to stop)")
    if root_path:
        print_info(f"  root: {root_path}")
    print_info(f"  agent_type: {agent_type}")
    if agent_slug:
        print_info(f"  agent_slug (override): {agent_slug}")
    print_info(f"  poll: {poll}s")

    try:
        watch_audit_logs(
            root=root_path,
            agent_slug=agent_slug or "",
            agent_type=agent_type,
            poll_interval=poll,
            verbose=verbose,
            cursor_path=cursor_path,
            from_start=from_start,
        )
    except RuntimeError as e:
        print_error(str(e))
        raise SystemExit(1)
    except KeyboardInterrupt:
        print_success("Watcher stopped")


@cowork.command("mcp-server")
def mcp_server():
    """Run the Cowork governance MCP server (stdio transport).

    Exposes 3 tools the Cowork model can call proactively:
      - waxell_check_policy  — pre-action policy gate (self-check)
      - waxell_budget_status — daily token/cost snapshot
      - waxell_record_decision — log reasoning to the audit trail

    Cowork runs in a sandboxed VM with no PreToolUse hooks (E7 in
    EXTERNAL_AGENT_GOVERNANCE.md). This server is detective by nature —
    the model can ignore it — but it's the strongest preventive surface
    available to Cowork. Registered in `~/.claude/.mcp.json` and launched
    as a child process by Claude.
    """
    from ...integrations.cowork.mcp_server import run_mcp_server

    run_mcp_server()


@cowork.command("mcp-register")
@click.option(
    "--profile",
    default="claude-cowork",
    help="Waxell profile the MCP server should run under (default: claude-cowork)",
)
@click.option(
    "--path",
    default=None,
    help="Override `.mcp.json` path (default: ~/.claude/.mcp.json)",
)
def mcp_register(profile: str, path: str):
    """Register the Cowork MCP shim in `.mcp.json`.

    Idempotent — writing twice is a no-op. Preserves every other entry in
    `mcpServers` and any unrelated top-level keys.
    """
    from ...integrations.cowork import register_mcp_config

    target = Path(path).expanduser() if path else None
    written = register_mcp_config(path=target, profile=profile)
    print_success(f"MCP server registered in {written} (profile: {profile})")
    print_info("Restart Claude / Cowork to pick up the new MCP server.")


@cowork.command("mcp-unregister")
@click.option(
    "--profile",
    default="claude-cowork",
    help="Waxell profile whose MCP entry to remove (default: claude-cowork)",
)
@click.option(
    "--path",
    default=None,
    help="Override `.mcp.json` path (default: ~/.claude/.mcp.json)",
)
def mcp_unregister(profile: str, path: str):
    """Remove the Cowork MCP shim entry from `.mcp.json`."""
    from ...integrations.cowork import unregister_mcp_config

    target = Path(path).expanduser() if path else None
    if unregister_mcp_config(path=target, profile=profile):
        print_success(f"Removed MCP entry for profile '{profile}'")
    else:
        print_info(f"No MCP entry found for profile '{profile}' (already absent)")


@cowork.command("cursor")
@click.option(
    "--reset",
    is_flag=True,
    help="Delete the cursor file (next watch will reprocess all current data)",
)
@click.option(
    "--cursor",
    default=None,
    help="Override cursor file location (default: ~/.waxell/cowork-cursor.json)",
)
def cursor(reset, cursor):
    """Inspect or reset the watcher cursor."""
    import json as _json

    cursor_path = (
        Path(cursor).expanduser()
        if cursor
        else Path.home() / ".waxell" / "cowork-cursor.json"
    )

    if reset:
        if cursor_path.exists():
            cursor_path.unlink()
            print_success(f"Reset {cursor_path}")
        else:
            print_info(f"No cursor at {cursor_path} (already fresh)")
        return

    if not cursor_path.exists():
        print_info(f"No cursor yet at {cursor_path}")
        return

    try:
        state = _json.loads(cursor_path.read_text())
    except Exception as e:
        print_error(f"Failed to read cursor: {e}")
        raise SystemExit(1)

    print_info(f"Cursor: {cursor_path}")
    print_info(f"Tracked files: {len(state)}")
    for path, info in state.items():
        run_id = info.get("run_id") or "(not started)"
        offset = info.get("offset", 0)
        print_info(f"  {path}")
        print_info(f"    offset={offset} run_id={run_id}")


# ---------------------------------------------------------------------------
# Persistent service management — keep watcher alive across reboot/sleep
# ---------------------------------------------------------------------------

SERVICE_LABEL = "dev.waxell.cowork.watcher"
WIN_TASK_NAME = "WaxellCoworkWatcher"


@cowork.group("service")
def service():
    """Manage the Cowork watcher as a persistent background service.

    On macOS this installs a launchd LaunchAgent that survives reboot,
    sleep/wake, and auto-restarts on crash. On Windows this registers
    a Scheduled Task that runs at user logon and restarts on failure.
    """


@service.command("install")
@click.option(
    "--profile",
    default="claude-cowork",
    help="Config profile to read (default: claude-cowork)",
)
@click.option("--poll", default=2, type=int, help="Poll interval seconds (default: 2)")
def service_install(profile, poll):
    """Install the Cowork watcher as a persistent OS-managed service."""
    import shutil
    import sys

    wax_path = shutil.which("wax") or sys.argv[0]
    if not Path(wax_path).exists():
        print_error(f"Can't find wax binary at {wax_path}")
        raise SystemExit(1)

    system = platform.system()
    if system == "Darwin":
        _install_launchd(wax_path, profile, poll)
    elif system == "Windows":
        _install_schtasks(wax_path, profile, poll)
    else:
        _install_systemd(wax_path, profile, poll)


@service.command("uninstall")
def service_uninstall():
    """Remove the persistent Cowork watcher service."""
    system = platform.system()
    if system == "Darwin":
        _uninstall_launchd()
    elif system == "Windows":
        _uninstall_schtasks()
    else:
        _uninstall_systemd()


@service.command("status")
def service_status():
    """Show whether the persistent Cowork watcher service is installed/running."""
    system = platform.system()
    if system == "Darwin":
        _status_launchd()
    elif system == "Windows":
        _status_schtasks()
    else:
        _status_systemd()


# ---- macOS launchd ----


def _launchd_plist_path() -> Path:
    return Path.home() / "Library" / "LaunchAgents" / f"{SERVICE_LABEL}.plist"


def _install_launchd(wax_path: str, profile: str, poll: int):
    import subprocess

    plist_path = _launchd_plist_path()
    plist_path.parent.mkdir(parents=True, exist_ok=True)
    log_dir = Path.home() / ".waxell" / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    stdout_log = log_dir / "cowork-watcher.out.log"
    stderr_log = log_dir / "cowork-watcher.err.log"

    plist = f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>{SERVICE_LABEL}</string>
  <key>ProgramArguments</key>
  <array>
    <string>{wax_path}</string>
    <string>--profile</string>
    <string>{profile}</string>
    <string>cowork</string>
    <string>watch</string>
    <string>--poll</string>
    <string>{poll}</string>
  </array>
  <key>RunAtLoad</key>
  <true/>
  <key>KeepAlive</key>
  <dict>
    <key>SuccessfulExit</key>
    <false/>
    <key>Crashed</key>
    <true/>
  </dict>
  <key>ThrottleInterval</key>
  <integer>10</integer>
  <key>StandardOutPath</key>
  <string>{stdout_log}</string>
  <key>StandardErrorPath</key>
  <string>{stderr_log}</string>
  <key>EnvironmentVariables</key>
  <dict>
    <key>PATH</key>
    <string>/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin</string>
  </dict>
</dict>
</plist>
"""
    plist_path.write_text(plist)
    # Load it (unload first to replace any previous version)
    subprocess.run(["launchctl", "unload", str(plist_path)], capture_output=True)
    result = subprocess.run(
        ["launchctl", "load", str(plist_path)], capture_output=True, text=True
    )
    if result.returncode != 0:
        print_error(f"launchctl load failed: {result.stderr.strip()}")
        raise SystemExit(1)

    print_success(f"Installed LaunchAgent: {plist_path}")
    print_info(f"  Label: {SERVICE_LABEL}")
    print_info(f"  Watching profile: {profile}")
    print_info(f"  Logs: {stdout_log}")
    print_info("The watcher now auto-starts at login and restarts on crash.")
    print_info("Check: wax cowork service status")


def _uninstall_launchd():
    import subprocess

    plist_path = _launchd_plist_path()
    if not plist_path.exists():
        print_info("No LaunchAgent installed.")
        return
    subprocess.run(["launchctl", "unload", str(plist_path)], capture_output=True)
    plist_path.unlink()
    print_success(f"Removed {plist_path}")


def _status_launchd():
    import subprocess

    plist_path = _launchd_plist_path()
    if not plist_path.exists():
        print_warning("Not installed. Run: wax cowork service install")
        return
    print_info(f"Plist: {plist_path}")
    result = subprocess.run(
        ["launchctl", "list", SERVICE_LABEL],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        print_warning(
            f"Loaded plist but launchctl list failed: {result.stderr.strip()}"
        )
        return
    # Output is a plist-like kv dump — parse PID and last-exit
    pid = None
    last_exit = None
    for line in result.stdout.splitlines():
        s = line.strip().rstrip(";")
        if s.startswith('"PID"'):
            pid = s.split("=")[-1].strip()
        elif s.startswith('"LastExitStatus"'):
            last_exit = s.split("=")[-1].strip()
    if pid and pid != "-":
        print_success(f"Running (PID {pid})")
    else:
        print_warning(f"Registered but not running (LastExitStatus={last_exit})")
    log_dir = Path.home() / ".waxell" / "logs"
    print_info(f"Logs: {log_dir}/cowork-watcher.out.log")


# ---- Windows schtasks ----


def _vbs_launcher_path() -> Path:
    """Location of the hidden-window VBScript wrapper for wax cowork watch."""
    return Path.home() / ".waxell" / "cowork-watcher.vbs"


def _startup_folder_shortcut() -> Path:
    """Non-admin fallback — user's Startup folder."""
    appdata = os.environ.get("APPDATA") or (Path.home() / "AppData" / "Roaming")
    return (
        Path(appdata)
        / "Microsoft"
        / "Windows"
        / "Start Menu"
        / "Programs"
        / "Startup"
        / "WaxellCoworkWatcher.vbs"
    )


def _write_vbs_launcher(wax_path: str, profile: str, poll: int) -> Path:
    """Write a self-healing VBScript that spawns wax.exe with a hidden window
    and relaunches it on crash with a 30s backoff.

    Without this, schtasks ONLOGON only fires wax once per login — any crash
    leaves the watcher dead until next login. With it, the VBS stays resident
    and keeps wax alive across crashes, network hiccups, etc.
    """
    launcher = _vbs_launcher_path()
    launcher.parent.mkdir(parents=True, exist_ok=True)
    wax_escaped = wax_path.replace("\\", "\\\\")
    # WshShell.Run 3rd arg True = WAIT for process to exit; 2nd arg 0 = hidden.
    # Loop forever: run wax hidden, wait for exit, sleep 30s, repeat.
    vbs = (
        "Option Explicit\r\n"
        "Dim WshShell, cmd, exitCode\r\n"
        'Set WshShell = CreateObject("WScript.Shell")\r\n'
        f'cmd = Chr(34) & "{wax_escaped}" & Chr(34) & " --profile {profile} cowork watch --poll {poll}"\r\n'
        "Do\r\n"
        "  exitCode = WshShell.Run(cmd, 0, True)\r\n"
        "  WScript.Sleep 30000\r\n"
        "Loop\r\n"
    )
    launcher.write_text(vbs)
    return launcher


def _install_schtasks(wax_path: str, profile: str, poll: int):
    import subprocess

    # Write hidden-window launcher VBS
    launcher = _write_vbs_launcher(wax_path, profile, poll)
    cmd = f'wscript.exe "{launcher}"'

    # /it = run only if user is logged on (invisible no-GUI mode is fine too
    # since VBS hides wax). /ru <user> = explicit user binding (helps avoid
    # "access denied" on some group policies). /rl LIMITED = no admin needed.
    args = [
        "schtasks",
        "/create",
        "/tn",
        WIN_TASK_NAME,
        "/tr",
        cmd,
        "/sc",
        "ONLOGON",
        "/rl",
        "LIMITED",
        "/it",
        "/ru",
        os.environ.get("USERNAME", ""),
        "/f",
    ]

    # Try to add wax.exe to Windows Defender exclusions (silent-fails if no
    # admin — optional optimization to avoid Defender scanning the binary on
    # every invocation).
    try:
        ps = (
            f'Add-MpPreference -ExclusionPath "{wax_path}" -ErrorAction SilentlyContinue; '
            f'Add-MpPreference -ExclusionProcess "wax.exe" -ErrorAction SilentlyContinue'
        )
        subprocess.run(
            ["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command", ps],
            capture_output=True,
            timeout=10,
        )
    except Exception:
        pass  # User isn't admin; Defender still works, just slower first-run
    result = subprocess.run(args, capture_output=True, text=True)
    if result.returncode != 0:
        err = result.stderr.strip() or result.stdout.strip()
        # Fallback — schtasks often fails with "Access denied" without admin.
        # Drop the VBS launcher into the user's Startup folder instead. No
        # admin required, runs on next logon, fires wax.exe hidden.
        shortcut = _startup_folder_shortcut()
        try:
            shortcut.parent.mkdir(parents=True, exist_ok=True)
            shortcut.write_text(launcher.read_text())
            print_warning(f"schtasks unavailable ({err}); used Startup folder fallback")
            print_success(f"Installed: {shortcut}")
            # Start it right now in the current session (still hidden)
            subprocess.run(
                ["wscript.exe", str(launcher)], creationflags=0x08000000
            )  # CREATE_NO_WINDOW
            print_info("Watcher launched silently — no visible console.")
            return
        except Exception as fallback_err:
            print_error(
                f"schtasks failed AND Startup-folder fallback failed: {fallback_err}"
            )
            raise SystemExit(1)

    print_success(f"Registered scheduled task: {WIN_TASK_NAME}")
    # Start it now too — invoked via wscript so no visible console window
    subprocess.run(
        ["wscript.exe", str(launcher)],
        capture_output=True,
        creationflags=0x08000000,  # CREATE_NO_WINDOW
    )
    print_info(
        "Runs at every logon, launched hidden. Verify: wax cowork service status"
    )


def _uninstall_schtasks():
    import subprocess

    # 1. Kill ALL descendants of the watcher FIRST so file handles release
    # before we try to delete the VBS / binary.
    for target in ("wax.exe",):
        subprocess.run(
            ["taskkill", "/f", "/t", "/im", target],
            capture_output=True,
        )
    # wscript hosts the VBS — need to find and kill just ours (not all wscript)
    try:
        launcher = _vbs_launcher_path()
        ps = (
            "Get-CimInstance Win32_Process -Filter \"Name='wscript.exe'\" | "
            f'Where-Object {{ $_.CommandLine -like "*{launcher.name}*" }} | '
            "ForEach-Object {{ Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }}"
        )
        subprocess.run(
            ["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command", ps],
            capture_output=True,
            timeout=10,
        )
    except Exception:
        pass

    # 2. Remove the scheduled task
    result = subprocess.run(
        ["schtasks", "/delete", "/tn", WIN_TASK_NAME, "/f"],
        capture_output=True,
        text=True,
    )
    removed_task = result.returncode == 0

    # 3. Remove Startup folder fallback shortcut
    shortcut = _startup_folder_shortcut()
    removed_shortcut = False
    if shortcut.exists():
        try:
            shortcut.unlink()
            removed_shortcut = True
        except OSError:
            pass

    # 4. Remove the VBS launcher itself (it's no longer needed)
    launcher = _vbs_launcher_path()
    if launcher.exists():
        try:
            launcher.unlink()
        except OSError:
            pass

    if removed_task or removed_shortcut:
        if removed_task:
            print_success(f"Removed scheduled task {WIN_TASK_NAME}")
        if removed_shortcut:
            print_success(f"Removed {shortcut}")
    else:
        print_info("Nothing installed.")


def _status_schtasks():
    import subprocess

    printed = False
    result = subprocess.run(
        ["schtasks", "/query", "/tn", WIN_TASK_NAME, "/fo", "LIST", "/v"],
        capture_output=True,
        text=True,
    )
    if result.returncode == 0:
        for line in result.stdout.splitlines():
            line = line.strip()
            if line.startswith(
                ("TaskName", "Status", "Last Run", "Last Result", "Next Run")
            ):
                print_info(f"  {line}")
                printed = True

    shortcut = _startup_folder_shortcut()
    if shortcut.exists():
        print_info(f"  Startup folder fallback: {shortcut}")
        printed = True

    # Check if watcher is actively running
    proc = subprocess.run(
        ["tasklist", "/fi", "imagename eq wax.exe", "/fo", "csv"],
        capture_output=True,
        text=True,
    )
    lines = [l for l in proc.stdout.splitlines() if "wax.exe" in l]
    if lines:
        print_success(f"  Running ({len(lines)} wax.exe process(es))")
    elif printed:
        print_warning("  Installed but not currently running")
    else:
        print_warning("Not installed. Run: wax cowork service install")


# ---- Linux systemd (user service) ----


def _systemd_unit_path() -> Path:
    return (
        Path.home() / ".config" / "systemd" / "user" / "waxell-cowork-watcher.service"
    )


def _install_systemd(wax_path: str, profile: str, poll: int):
    import subprocess

    unit_path = _systemd_unit_path()
    unit_path.parent.mkdir(parents=True, exist_ok=True)
    unit = f"""[Unit]
Description=Waxell Cowork audit watcher
After=network.target

[Service]
Type=simple
ExecStart={wax_path} --profile {profile} cowork watch --poll {poll}
Restart=always
RestartSec=5

[Install]
WantedBy=default.target
"""
    unit_path.write_text(unit)
    subprocess.run(["systemctl", "--user", "daemon-reload"], capture_output=True)
    subprocess.run(
        ["systemctl", "--user", "enable", "--now", "waxell-cowork-watcher.service"],
        capture_output=True,
    )
    print_success(f"Installed systemd unit: {unit_path}")


def _uninstall_systemd():
    import subprocess

    unit_path = _systemd_unit_path()
    subprocess.run(
        ["systemctl", "--user", "disable", "--now", "waxell-cowork-watcher.service"],
        capture_output=True,
    )
    if unit_path.exists():
        unit_path.unlink()
        print_success(f"Removed {unit_path}")
    else:
        print_info("No systemd unit installed.")


def _status_systemd():
    import subprocess

    result = subprocess.run(
        ["systemctl", "--user", "is-active", "waxell-cowork-watcher.service"],
        capture_output=True,
        text=True,
    )
    state = result.stdout.strip()
    if state == "active":
        print_success("Running")
    else:
        print_warning(f"State: {state}")
