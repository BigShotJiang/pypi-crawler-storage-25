"""End-user identity commands.

Full reference: docs/integrations/callsine-end-user-identity.md §8.

Commands:
    wax end-users list [--status] [--tier] [--search]
    wax end-users show <waxell_user_id> [--format json]
    wax end-users create --tenant-sub-user-id ID [--email] [--display-name] ...
    wax end-users update <id> [--subscription-tier] [--budget] ...
    wax end-users suspend <id> [--reason]
    wax end-users unsuspend <id>
    wax end-users archive <id>
    wax end-users hard-delete <id> --yes
    wax end-users sync --file users.json
    wax end-users lookup <tenant_sub_user_id> [--tenant_sub_user_id ...]
    wax end-users activity <id> [--window 30d] [--kind]
    wax end-users runs <id>
    wax end-users cost <id> [--window 30d]
"""

from __future__ import annotations

import json
from typing import Optional

import click
from rich.table import Table

from .._display import console, print_header, print_warning, status_dot
from .._http import api_delete, api_get, api_patch, api_post


_STATUS_DOT = {
    "active": "active",
    "suspended": "inactive",
    "archived": "disabled",
}


def _print_user_table(users, title="End-Users"):
    if not users:
        print_warning("No end-users found.")
        return
    print_header(title, f"{len(users)} shown")
    table = Table(show_header=True, header_style="bold cyan", border_style="dim")
    table.add_column("Waxell ID", style="dim", no_wrap=True, max_width=36)
    table.add_column("Tenant Sub-User ID", style="bold")
    table.add_column("Email")
    table.add_column("Display Name")
    table.add_column("Tier")
    table.add_column("Budget (¢)", justify="right")
    table.add_column("Status", justify="center")
    table.add_column("Last Seen", no_wrap=True)
    for u in users:
        table.add_row(
            u.get("waxell_user_id", "-"),
            u.get("tenant_sub_user_id", "-"),
            u.get("email") or "—",
            u.get("display_name") or "—",
            u.get("subscription_tier") or "—",
            str(u.get("monthly_budget_cap_cents") or "—"),
            status_dot(_STATUS_DOT.get(u.get("status", ""), "pending")),
            (u.get("last_seen") or "")[:16],
        )
    console.print(table)
    console.print()


@click.group("end-users")
def end_users():
    """Manage Waxell end-user identity records."""


# ---------------------------------------------------------------------------
# Read
# ---------------------------------------------------------------------------


@end_users.command("list")
@click.option(
    "--status",
    "status_filter",
    default=None,
    type=click.Choice(["active", "suspended", "archived"]),
)
@click.option(
    "--tier", "tier_filter", default=None, help="Filter by subscription_tier."
)
@click.option(
    "--search",
    default=None,
    help="Substring match on display_name / tenant_sub_user_id.",
)
@click.option("--limit", default=50, type=int, show_default=True)
@click.option("--offset", default=0, type=int)
@click.option("--format", "fmt", type=click.Choice(["table", "json"]), default="table")
@click.pass_context
def list_(ctx, status_filter, tier_filter, search, limit, offset, fmt):
    """List end-users."""
    params = {"limit": limit, "offset": offset}
    if status_filter:
        params["status"] = status_filter
    if tier_filter:
        params["subscription_tier"] = tier_filter
    if search:
        params["search"] = search
    data = api_get(ctx, "/v1/end-users/", params=params)
    if fmt == "json":
        console.print_json(json.dumps(data, indent=2))
        return
    _print_user_table(data.get("results", []), title="End-Users")
    console.print(
        f"[dim]Total: {data.get('total', 0)}  |  "
        f"Showing {len(data.get('results', []))} (limit={limit}, offset={offset})[/dim]"
    )


@end_users.command("show")
@click.argument("waxell_user_id")
@click.option("--format", "fmt", type=click.Choice(["human", "json"]), default="human")
@click.pass_context
def show(ctx, waxell_user_id, fmt):
    """Show a single end-user's full detail."""
    data = api_get(ctx, f"/v1/end-users/{waxell_user_id}/")
    if fmt == "json":
        console.print_json(json.dumps(data, indent=2))
        return
    print_header("End-User", data.get("tenant_sub_user_id", "-"))
    for field in (
        "waxell_user_id",
        "tenant_sub_user_id",
        "email",
        "display_name",
        "status",
        "subscription_tier",
        "monthly_budget_cap_cents",
        "rate_limit_override_rpm",
        "first_seen",
        "last_seen",
        "archived_at",
    ):
        console.print(
            f"[dim]{field}:[/dim]  {data.get(field) if data.get(field) is not None else '—'}"
        )
    if data.get("attrs"):
        console.print("[dim]attrs:[/dim]")
        console.print_json(json.dumps(data["attrs"], indent=2))


@end_users.command("lookup")
@click.argument("tenant_sub_user_ids", nargs=-1, required=True)
@click.option("--format", "fmt", type=click.Choice(["human", "json"]), default="human")
@click.pass_context
def lookup(ctx, tenant_sub_user_ids, fmt):
    """Resolve tenant_sub_user_id(s) → waxell_user_id(s)."""
    data = api_post(
        ctx,
        "/v1/end-users/lookup/",
        json={"tenant_sub_user_ids": list(tenant_sub_user_ids)},
    )
    if fmt == "json":
        console.print_json(json.dumps(data, indent=2))
        return
    table = Table(show_header=True, header_style="bold cyan", border_style="dim")
    table.add_column("Tenant Sub-User ID", style="bold")
    table.add_column("Waxell User ID")
    for k, v in (data.get("results") or {}).items():
        table.add_row(k, v or "[red]not-registered[/red]")
    console.print(table)


# ---------------------------------------------------------------------------
# Mutations
# ---------------------------------------------------------------------------


@end_users.command("create")
@click.option("--tenant-sub-user-id", required=True)
@click.option("--email", default=None)
@click.option("--display-name", default="")
@click.option("--subscription-tier", default="")
@click.option("--budget", "monthly_budget_cap_cents", type=int, default=None)
@click.option(
    "--attrs", "attrs_json", default=None, help="JSON dict of free-form attrs."
)
@click.option("--format", "fmt", type=click.Choice(["human", "json"]), default="human")
@click.pass_context
def create(
    ctx,
    tenant_sub_user_id: str,
    email: Optional[str],
    display_name: str,
    subscription_tier: str,
    monthly_budget_cap_cents: Optional[int],
    attrs_json: Optional[str],
    fmt: str,
):
    """Create a new end-user (returns waxell_user_id)."""
    body = {
        "tenant_sub_user_id": tenant_sub_user_id,
        "display_name": display_name,
        "subscription_tier": subscription_tier,
    }
    if email:
        body["email"] = email
    if monthly_budget_cap_cents is not None:
        body["monthly_budget_cap_cents"] = monthly_budget_cap_cents
    if attrs_json:
        try:
            body["attrs"] = json.loads(attrs_json)
        except json.JSONDecodeError as exc:
            raise click.ClickException(f"--attrs must be valid JSON: {exc}")

    data = api_post(ctx, "/v1/end-users/", json=body)
    if fmt == "json":
        console.print_json(json.dumps(data, indent=2))
        return
    console.print(f"[green]Created[/green]  waxell_user_id={data['waxell_user_id']}")


@end_users.command("update")
@click.argument("waxell_user_id")
@click.option("--email", default=None)
@click.option("--display-name", default=None)
@click.option("--subscription-tier", default=None)
@click.option("--budget", "monthly_budget_cap_cents", type=int, default=None)
@click.option("--rate-limit", "rate_limit_override_rpm", type=int, default=None)
@click.option("--attrs", "attrs_json", default=None)
@click.pass_context
def update(
    ctx,
    waxell_user_id,
    email,
    display_name,
    subscription_tier,
    monthly_budget_cap_cents,
    rate_limit_override_rpm,
    attrs_json,
):
    """Update fields on an end-user."""
    body = {}
    if email is not None:
        body["email"] = email
    if display_name is not None:
        body["display_name"] = display_name
    if subscription_tier is not None:
        body["subscription_tier"] = subscription_tier
    if monthly_budget_cap_cents is not None:
        body["monthly_budget_cap_cents"] = monthly_budget_cap_cents
    if rate_limit_override_rpm is not None:
        body["rate_limit_override_rpm"] = rate_limit_override_rpm
    if attrs_json:
        body["attrs"] = json.loads(attrs_json)

    if not body:
        raise click.ClickException("Nothing to update — pass at least one field.")

    data = api_patch(ctx, f"/v1/end-users/{waxell_user_id}/", json=body)
    console.print(
        f"[green]Updated[/green]  tier={data.get('subscription_tier')!r} status={data.get('status')!r}"
    )


@end_users.command("suspend")
@click.argument("waxell_user_id")
@click.option("--reason", default="")
@click.pass_context
def suspend(ctx, waxell_user_id, reason):
    """Suspend an end-user (next run turn halts)."""
    data = api_post(
        ctx, f"/v1/end-users/{waxell_user_id}/suspend/", json={"reason": reason}
    )
    console.print(f"[yellow]Suspended[/yellow]  status={data.get('status')!r}")


@end_users.command("unsuspend")
@click.argument("waxell_user_id")
@click.pass_context
def unsuspend(ctx, waxell_user_id):
    """Unsuspend an end-user."""
    data = api_post(ctx, f"/v1/end-users/{waxell_user_id}/unsuspend/", json={})
    console.print(f"[green]Unsuspended[/green]  status={data.get('status')!r}")


@end_users.command("archive")
@click.argument("waxell_user_id")
@click.pass_context
def archive(ctx, waxell_user_id):
    """Archive (soft-delete) an end-user."""
    data = api_delete(ctx, f"/v1/end-users/{waxell_user_id}/")
    console.print(f"[yellow]Archived[/yellow]  status={data.get('status')!r}")


@end_users.command("hard-delete")
@click.argument("waxell_user_id")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation.")
@click.pass_context
def hard_delete(ctx, waxell_user_id, yes):
    """GDPR hard-delete — zeros PII, retains activity. IRREVERSIBLE."""
    if not yes:
        print_warning(
            "Hard-delete zeros PII and is irreversible. Activity rows are "
            "retained with waxell_user_id only for compliance audit."
        )
        click.confirm(f"Hard-delete {waxell_user_id}?", abort=True)
    data = api_post(ctx, f"/v1/end-users/{waxell_user_id}/hard-delete/", json={})
    console.print(
        f"[red]Hard-deleted[/red]  waxell_user_id={data.get('waxell_user_id')}"
    )


@end_users.command("sync")
@click.option(
    "--file", "file_path", required=True, type=click.Path(exists=True, dir_okay=False)
)
@click.option("--format", "fmt", type=click.Choice(["human", "json"]), default="human")
@click.pass_context
def sync(ctx, file_path, fmt):
    """Bulk upsert from a JSON file (array of users or {"users": [...]})."""
    with open(file_path) as f:
        content = json.load(f)
    users = content if isinstance(content, list) else content.get("users", [])
    if not users:
        raise click.ClickException("No users in file.")

    data = api_post(ctx, "/v1/end-users/bulk-sync/", json={"users": users})
    if fmt == "json":
        console.print_json(json.dumps(data, indent=2))
        return
    console.print(
        f"[green]Bulk-sync[/green]  "
        f"processed={data.get('processed')} "
        f"created={data.get('created')} "
        f"updated={data.get('updated')} "
        f"errors={len(data.get('errors') or [])}"
    )
    for err in data.get("errors") or []:
        console.print(
            f"  [red]✗[/red] index={err['index']} id={err.get('tenant_sub_user_id')!r}: {err['error']}"
        )


# ---------------------------------------------------------------------------
# Drill-downs
# ---------------------------------------------------------------------------


@end_users.command("activity")
@click.argument("waxell_user_id")
@click.option(
    "--window", default="30d", type=click.Choice(["7d", "30d", "90d", "mtd", "ytd"])
)
@click.option(
    "--kind", default=None, help="Filter to one event kind (e.g. domain_call)."
)
@click.option("--limit", default=100, type=int)
@click.option("--format", "fmt", type=click.Choice(["table", "json"]), default="table")
@click.pass_context
def activity(ctx, waxell_user_id, window, kind, limit, fmt):
    """Recent activity for an end-user."""
    params = {"window": window, "limit": limit}
    if kind:
        params["kind"] = kind
    data = api_get(ctx, f"/v1/end-users/{waxell_user_id}/activity/", params=params)
    if fmt == "json":
        console.print_json(json.dumps(data, indent=2))
        return
    rows = data.get("results", [])
    if not rows:
        print_warning("No activity in window.")
        return
    table = Table(show_header=True, header_style="bold cyan", border_style="dim")
    table.add_column("When", no_wrap=True)
    table.add_column("Kind")
    table.add_column("Agent")
    table.add_column("Domain.Action")
    table.add_column("Run ID", no_wrap=True)
    table.add_column("Cost (¢)", justify="right")
    for r in rows:
        da = ""
        if r.get("domain_name") or r.get("action_name"):
            da = f"{r.get('domain_name') or '-'}.{r.get('action_name') or '-'}"
        table.add_row(
            (r.get("occurred_at") or "")[:19],
            r.get("kind", "-"),
            r.get("agent_name") or "—",
            da or "—",
            (r.get("run_id") or "—")[:36],
            str(r.get("cost_cents") or 0),
        )
    console.print(table)
    console.print(f"[dim]Total in window: {data.get('total')}[/dim]")


@end_users.command("runs")
@click.argument("waxell_user_id")
@click.option("--agent", "agent_name", default=None)
@click.option("--limit", default=50, type=int)
@click.option("--format", "fmt", type=click.Choice(["table", "json"]), default="table")
@click.pass_context
def runs(ctx, waxell_user_id, agent_name, limit, fmt):
    """Agent runs triggered by an end-user."""
    params = {"limit": limit}
    if agent_name:
        params["agent_name"] = agent_name
    data = api_get(ctx, f"/v1/end-users/{waxell_user_id}/runs/", params=params)
    if fmt == "json":
        console.print_json(json.dumps(data, indent=2))
        return
    rows = data.get("results", [])
    if not rows:
        print_warning("No runs.")
        return
    table = Table(show_header=True, header_style="bold cyan", border_style="dim")
    table.add_column("Run ID", style="dim", no_wrap=True)
    table.add_column("Agent")
    table.add_column("Workflow")
    table.add_column("Status")
    table.add_column("Started", no_wrap=True)
    for r in rows:
        table.add_row(
            (r.get("run_id") or "")[:36],
            r.get("agent_name") or "—",
            r.get("workflow_name") or "—",
            r.get("status") or "—",
            (r.get("started_at") or "")[:19],
        )
    console.print(table)
    console.print(f"[dim]Total: {data.get('total')}[/dim]")


@end_users.command("cost")
@click.argument("waxell_user_id")
@click.option(
    "--window", default="30d", type=click.Choice(["7d", "30d", "90d", "mtd", "ytd"])
)
@click.option("--format", "fmt", type=click.Choice(["human", "json"]), default="human")
@click.pass_context
def cost(ctx, waxell_user_id, window, fmt):
    """Cost rollup for an end-user."""
    data = api_get(
        ctx, f"/v1/end-users/{waxell_user_id}/cost/", params={"window": window}
    )
    if fmt == "json":
        console.print_json(json.dumps(data, indent=2))
        return
    print_header("Cost rollup", f"{window}")
    console.print(f"[bold]Total:[/bold] {data.get('total_cents', 0) / 100:.2f} USD")
    console.print(f"[bold]Runs:[/bold]  {data.get('run_count', 0)}")
    by_agent = data.get("by_agent") or {}
    if by_agent:
        console.print("\n[dim]By agent:[/dim]")
        for agent, cents in sorted(by_agent.items(), key=lambda kv: -kv[1]):
            console.print(f"  {agent}:  {cents / 100:.2f} USD")
    console.print(f"\n[dim]Calculated: {data.get('last_calculated_at')}[/dim]")
