"""LLM configuration commands."""

import json
import os

import click
from rich.table import Table

from .._http import api_get
from .._display import (
    console,
    print_header,
    print_warning,
    status_dot,
)


def _normalize_items(data, key: str = "routes"):
    """Extract items from paginated or raw list responses."""
    if isinstance(data, dict):
        items = data.get(key, data.get("results", data.get("items", data)))
    else:
        items = data
    if not isinstance(items, list):
        items = [items] if items else []
    return items


@click.group(name="llm")
def llm_config():
    """View LLM configuration and dispatch test calls."""


@llm_config.command("call")
@click.option(
    "--model",
    required=True,
    help="Model id (unqualified, qualified instance/model, or group:<id>)",
)
@click.option(
    "--message",
    "-m",
    "messages",
    multiple=True,
    help="User message(s); repeat for multi-turn",
)
@click.option("--system", default="", help="Optional system prompt")
@click.option("--mode", type=click.Choice(["chat", "json", "tool"]), default="chat")
@click.option("--max-tokens", default=1024, type=int)
@click.option("--temperature", default=None, type=float)
@click.option(
    "--show-config",
    is_flag=True,
    help="Print resolved chain + capability filter, do not dispatch",
)
@click.pass_context
def llm_call(ctx, model, messages, system, mode, max_tokens, temperature, show_config):
    """Dispatch an LLM call via waxell.llm.call(...).

    Lets you sanity-check `secret_ref → env var` resolution and
    fallback chains from a shell without writing Python.

    Examples::

        wax llm call --model gpt-4o -m "hello"
        wax llm call --model 'group:cheap-llama-70b' -m "hi"
        wax llm call --model fireworks-prod/llama-3.1-70b-instruct \\
                     --system "You are concise." -m "summarize attention"
        wax llm call --model gpt-4o --show-config
    """
    try:
        from waxell_observe import llm as waxell_llm
    except ImportError as e:
        raise click.ClickException(
            f"waxell.llm dispatch is unavailable: {e}. "
            f"Install: pip install 'waxell-observe[all-providers]'"
        )

    # Pull manifest first so we can show what would happen even
    # without actually dispatching
    try:
        manifest = waxell_llm._get_config()
    except waxell_llm.ManifestUnavailable as e:
        raise click.ClickException(f"Manifest unavailable: {e}")

    # Show-config path: resolve + filter, print, return.
    if show_config:
        try:
            chain = waxell_llm.resolve_chain(manifest, model)
        except waxell_llm.ModelNotResolvable as e:
            raise click.ClickException(str(e))
        filtered = waxell_llm.filter_chain_for_mode(manifest, chain, mode)
        print_header(f"Resolved chain for {model!r} (mode={mode})")
        table = Table(show_header=True)
        table.add_column("#")
        table.add_column("instance_id")
        table.add_column("kind")
        table.add_column("provider_model_id")
        table.add_column("base_url")
        table.add_column("secret_ref")
        table.add_column("env set?")
        table.add_column("passes filter")
        passing_ids = {(c.instance_id, c.provider_model_id) for c in filtered}
        for i, c in enumerate(chain):
            env_set = (
                "✓"
                if (c.instance.secret_ref and os.environ.get(c.instance.secret_ref))
                else "✗"
            )
            passes = "✓" if (c.instance_id, c.provider_model_id) in passing_ids else "✗"
            table.add_row(
                str(i + 1),
                c.instance_id,
                c.kind,
                c.provider_model_id,
                c.instance.base_url or "(SDK default)",
                c.instance.secret_ref or "—",
                env_set,
                passes,
            )
        console.print(table)
        if not filtered:
            print_warning(
                f"No candidates pass mode={mode!r}. Dispatch would raise NoCandidateForMode."
            )
        return

    # Actual dispatch
    msg_list = []
    if system:
        msg_list.append({"role": "system", "content": system})
    for m in messages:
        msg_list.append({"role": "user", "content": m})
    if not msg_list:
        raise click.UsageError("Pass at least one --message / -m, or use --show-config")

    kwargs = {"max_tokens": max_tokens}
    if temperature is not None:
        kwargs["temperature"] = temperature

    try:
        if mode == "chat":
            resp = waxell_llm.text(model=model, messages=msg_list, **kwargs)
        elif mode == "json":
            resp = waxell_llm.json(model=model, messages=msg_list, **kwargs)
        else:
            raise click.UsageError(
                "--mode tool requires --tools (not yet supported in CLI)"
            )
    except waxell_llm.SecretNotInEnvironment as e:
        raise click.ClickException(str(e))
    except waxell_llm.ModelNotResolvable as e:
        raise click.ClickException(f"Resolve failed: {e}")
    except waxell_llm.NoCandidateForMode as e:
        raise click.ClickException(f"No candidate: {e}")
    except waxell_llm.NoProviderAvailable as e:
        raise click.ClickException(f"All providers failed: {e}")
    except waxell_llm.UnsupportedKind as e:
        raise click.ClickException(str(e))
    except waxell_llm.MissingProviderSDK as e:
        raise click.ClickException(str(e))

    # Best-effort response extraction across provider shapes
    text_out = _extract_response_text(resp)
    print_header(f"Response (model={model})")
    console.print(text_out)


def _extract_response_text(resp) -> str:
    """Pluck the assistant message out of an OpenAI- or Anthropic-shaped response."""
    # OpenAI-style
    if hasattr(resp, "choices") and resp.choices:
        choice = resp.choices[0]
        msg = getattr(choice, "message", None)
        if msg is not None and getattr(msg, "content", None):
            return msg.content
    # Anthropic-style
    if hasattr(resp, "content") and isinstance(resp.content, list):
        parts = []
        for block in resp.content:
            text = getattr(block, "text", None)
            if text:
                parts.append(text)
        if parts:
            return "\n".join(parts)
    # Fallback — give up gracefully
    return repr(resp)


@llm_config.command("routing")
@click.option(
    "--format",
    "fmt",
    type=click.Choice(["table", "json"]),
    default="table",
    help="Output format",
)
@click.pass_context
def llm_routing(ctx, fmt: str):
    """Show LLM routing configuration."""
    data = api_get(ctx, "/v1/observe/query/llm-config/")

    if fmt == "json":
        console.print_json(json.dumps(data, indent=2))
        return

    items = _normalize_items(data, "routes")

    if not items:
        print_warning("No LLM routing configuration found.")
        return

    print_header("LLM Routing", f"{len(items)} routes configured")

    table = Table(show_header=True, header_style="bold cyan", border_style="dim")
    table.add_column("Route Name", style="bold")
    table.add_column("Models")
    table.add_column("Priority", justify="right")
    table.add_column("Status", justify="center")

    for route in items:
        models = route.get("models", route.get("model_list", []))
        if isinstance(models, list):
            models_str = ", ".join(str(m) for m in models[:3])
            if len(models) > 3:
                models_str += f" +{len(models) - 3}"
        else:
            models_str = str(models) if models else "-"

        is_active = route.get(
            "is_active", route.get("enabled", route.get("status", "") == "active")
        )
        status = "active" if is_active else "inactive"

        table.add_row(
            route.get("name", route.get("route_name", "-")),
            models_str,
            str(route.get("priority", "-")),
            status_dot(status),
        )

    console.print(table)
    console.print()


@llm_config.command("models")
@click.option(
    "--format",
    "fmt",
    type=click.Choice(["table", "json"]),
    default="table",
    help="Output format",
)
@click.pass_context
def llm_models(ctx, fmt: str):
    """Show available LLM models and pricing."""
    data = api_get(ctx, "/v1/observe/query/llm-config/")

    if fmt == "json":
        console.print_json(json.dumps(data, indent=2))
        return

    items = _normalize_items(data, "models")

    if not items:
        print_warning("No LLM model configuration found.")
        return

    print_header("LLM Models", f"{len(items)} models available")

    table = Table(show_header=True, header_style="bold cyan", border_style="dim")
    table.add_column("Model", style="bold")
    table.add_column("Provider")
    table.add_column("Status", justify="center")
    table.add_column("Input $/1K", justify="right")
    table.add_column("Output $/1K", justify="right")

    for model in items:
        is_active = model.get(
            "is_active", model.get("enabled", model.get("status", "") == "active")
        )
        status = "active" if is_active else "inactive"

        # Cost per 1K tokens
        input_cost = model.get("input_cost_per_1k", model.get("input_cost", 0)) or 0
        output_cost = model.get("output_cost_per_1k", model.get("output_cost", 0)) or 0

        # If costs are per-token, convert to per-1K
        if input_cost > 0 and input_cost < 0.001:
            input_cost *= 1000
        if output_cost > 0 and output_cost < 0.001:
            output_cost *= 1000

        table.add_row(
            model.get("model", model.get("model_name", model.get("name", "-"))),
            model.get("provider", "-"),
            status_dot(status),
            f"${input_cost:.4f}" if input_cost else "-",
            f"${output_cost:.4f}" if output_cost else "-",
        )

    console.print(table)
    console.print()
