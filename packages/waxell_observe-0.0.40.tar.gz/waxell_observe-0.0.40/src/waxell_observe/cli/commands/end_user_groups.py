"""End-user group management commands.

wax end-user-groups list
wax end-user-groups show <group_id>
wax end-user-groups create --name <name> [--description] [--rate-limit]
wax end-user-groups update <group_id> [...]
wax end-user-groups delete <group_id> --yes
wax end-user-groups members <group_id>
wax end-user-groups add-members <group_id> <user_id> [...]
wax end-user-groups remove-member <group_id> <user_id>
"""

from __future__ import annotations

import json
from typing import Optional

import click
from rich.table import Table

from .._display import console, print_header, print_warning
from .._http import api_delete, api_get, api_patch, api_post


@click.group("end-user-groups")
def end_user_groups():
    """Manage Waxell end-user groups (tenant-scoped)."""


@end_user_groups.command("list")
@click.option("--search", default=None)
@click.option("--limit", default=50, type=int)
@click.option("--format", "fmt", type=click.Choice(["table", "json"]), default="table")
@click.pass_context
def list_(ctx, search, limit, fmt):
    """List groups."""
    params = {"limit": limit}
    if search:
        params["search"] = search
    data = api_get(ctx, "/v1/end-user-groups/", params=params)
    rows = data.get("results", [])
    if fmt == "json":
        console.print_json(json.dumps(data, indent=2))
        return
    if not rows:
        print_warning("No groups.")
        return
    print_header("Groups", f"{len(rows)} of {data.get('total', 0)}")
    t = Table(show_header=True, header_style="bold cyan", border_style="dim")
    t.add_column("ID", style="dim", no_wrap=True)
    t.add_column("Name", style="bold")
    t.add_column("Description")
    t.add_column("RL (rpm)", justify="right")
    t.add_column("Members", justify="right")
    for r in rows:
        t.add_row(
            r.get("id", "")[:36],
            r.get("name", "-"),
            r.get("description") or "—",
            str(r.get("rate_limit_override_rpm") or "—"),
            str(r.get("member_count") if r.get("member_count") is not None else "—"),
        )
    console.print(t)


@end_user_groups.command("show")
@click.argument("group_id")
@click.pass_context
def show(ctx, group_id):
    data = api_get(ctx, f"/v1/end-user-groups/{group_id}/")
    console.print_json(json.dumps(data, indent=2))


@end_user_groups.command("create")
@click.option("--name", required=True)
@click.option("--description", default="")
@click.option("--rate-limit", "rate_limit_override_rpm", type=int, default=None)
@click.option(
    "--attrs", "attrs_json", default=None, help="JSON dict of free-form attrs."
)
@click.pass_context
def create(
    ctx,
    name: str,
    description: str,
    rate_limit_override_rpm: Optional[int],
    attrs_json: Optional[str],
):
    body: dict = {"name": name, "description": description}
    if rate_limit_override_rpm is not None:
        body["rate_limit_override_rpm"] = rate_limit_override_rpm
    if attrs_json:
        body["attrs"] = json.loads(attrs_json)
    data = api_post(ctx, "/v1/end-user-groups/", json=body)
    console.print(
        f"[green]Created[/green]  group_id={data['id']} name={data['name']!r}"
    )


@end_user_groups.command("update")
@click.argument("group_id")
@click.option("--name", default=None)
@click.option("--description", default=None)
@click.option("--rate-limit", "rate_limit_override_rpm", type=int, default=None)
@click.option("--attrs", "attrs_json", default=None)
@click.pass_context
def update(ctx, group_id, name, description, rate_limit_override_rpm, attrs_json):
    body: dict = {}
    if name is not None:
        body["name"] = name
    if description is not None:
        body["description"] = description
    if rate_limit_override_rpm is not None:
        body["rate_limit_override_rpm"] = rate_limit_override_rpm
    if attrs_json:
        body["attrs"] = json.loads(attrs_json)
    if not body:
        raise click.ClickException("Nothing to update.")
    data = api_patch(ctx, f"/v1/end-user-groups/{group_id}/", json=body)
    console.print(f"[green]Updated[/green]  name={data['name']!r}")


@end_user_groups.command("delete")
@click.argument("group_id")
@click.option("--yes", "-y", is_flag=True)
@click.pass_context
def delete(ctx, group_id, yes):
    if not yes:
        click.confirm(f"Delete group {group_id}?", abort=True)
    api_delete(ctx, f"/v1/end-user-groups/{group_id}/")
    console.print(f"[red]Deleted[/red]  group_id={group_id}")


@end_user_groups.command("members")
@click.argument("group_id")
@click.option("--limit", default=50, type=int)
@click.option("--format", "fmt", type=click.Choice(["table", "json"]), default="table")
@click.pass_context
def members(ctx, group_id, limit, fmt):
    data = api_get(
        ctx, f"/v1/end-user-groups/{group_id}/members/", params={"limit": limit}
    )
    rows = data.get("results", [])
    if fmt == "json":
        console.print_json(json.dumps(data, indent=2))
        return
    if not rows:
        print_warning("No members.")
        return
    print_header("Members", f"{len(rows)} of {data.get('total', 0)}")
    t = Table(show_header=True, header_style="bold cyan", border_style="dim")
    t.add_column("Waxell User ID", style="dim", no_wrap=True)
    t.add_column("Tenant Sub-User ID", style="bold")
    t.add_column("Email")
    t.add_column("Added", no_wrap=True)
    for r in rows:
        t.add_row(
            r.get("waxell_user_id", "")[:36],
            r.get("tenant_sub_user_id", "-"),
            r.get("email") or "—",
            (r.get("added_at") or "")[:19],
        )
    console.print(t)


@end_user_groups.command("add-members")
@click.argument("group_id")
@click.argument("user_ids", nargs=-1, required=True)
@click.pass_context
def add_members(ctx, group_id, user_ids):
    data = api_post(
        ctx,
        f"/v1/end-user-groups/{group_id}/members/",
        json={"user_ids": list(user_ids)},
    )
    console.print(
        f"[green]Added[/green]  added={data.get('added', 0)} "
        f"skipped={len(data.get('skipped_invalid', []))}"
    )
    for skipped in data.get("skipped_invalid") or []:
        console.print(f"  [yellow]skipped[/yellow] {skipped}")


@end_user_groups.command("remove-member")
@click.argument("group_id")
@click.argument("user_id")
@click.pass_context
def remove_member(ctx, group_id, user_id):
    data = api_delete(ctx, f"/v1/end-user-groups/{group_id}/members/{user_id}/")
    console.print(f"[green]Removed[/green]  success={data.get('removed')}")
