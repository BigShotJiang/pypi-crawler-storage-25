"""`wax provider` — manage LLM provider instances and browse the catalog.

Mirrors the Phase 3 REST endpoints at /waxell/v1/llm-config/provider-catalog/
and /waxell/v1/llm-config/provider-instances/.

Examples:
    wax provider catalog list                                      # browse the 30 day-1 presets
    wax provider catalog show fireworks                            # detail for one preset
    wax provider list                                              # this tenant's instances
    wax provider add fireworks_main --from-catalog fireworks       # quick: pick a preset, supply slug
    wax provider add my_vllm --kind openai_compat \\
        --base-url http://10.0.0.5:8000/v1 --secret-ref VLLM_KEY    # custom (non-catalog) provider
    wax provider show fireworks_main
    wax provider disable fireworks_main
    wax provider enable fireworks_main
    wax provider set-default fireworks_main                        # mark as default for its kind
    wax provider delete fireworks_main                             # only when no models reference it
"""

import json

import click
from rich.table import Table

from .._display import (
    console,
    print_error,
    print_header,
    print_success,
    print_warning,
    status_dot,
)
from .._http import api_delete, api_get, api_post, api_put


def _fmt_caps(caps: dict) -> str:
    flags = []
    if caps.get("native_tools"):
        flags.append("tools")
    if caps.get("json_mode"):
        flags.append("json")
    if caps.get("streaming"):
        flags.append("stream")
    return ",".join(flags) if flags else "-"


@click.group(name="provider")
def provider():
    """Manage LLM provider instances and browse the catalog."""


# =============================================================================
# Catalog subgroup
# =============================================================================


@provider.group()
def catalog():
    """Browse the curated catalog of provider presets (Fireworks, Bedrock, …)."""


@catalog.command("list")
@click.option(
    "--kind",
    type=str,
    default=None,
    help="Filter by kind (openai_compat, anthropic, bedrock, …).",
)
@click.option(
    "--status",
    type=str,
    default="stable,beta",
    help="Comma-separated statuses to include (default: stable,beta).",
)
@click.option(
    "--format",
    "fmt",
    type=click.Choice(["table", "json"]),
    default="table",
)
@click.pass_context
def catalog_list(ctx, kind: str | None, status: str, fmt: str):
    """List provider catalog entries."""
    params = {"status": status}
    if kind:
        params["kind"] = kind
    data = api_get(ctx, "/waxell/v1/llm-config/provider-catalog/", params=params)
    entries = data.get("entries", [])

    if fmt == "json":
        console.print_json(json.dumps(entries, indent=2))
        return

    if not entries:
        print_warning("No catalog entries match those filters.")
        return

    print_header("Provider Catalog", f"{len(entries)} preset(s)")

    table = Table(show_header=True, header_style="bold cyan", border_style="dim")
    table.add_column("Catalog ID", style="bold")
    table.add_column("Kind")
    table.add_column("Display Name")
    table.add_column("Default Endpoint", overflow="fold")
    table.add_column("Caps")
    table.add_column("Status", justify="center")

    for e in entries:
        table.add_row(
            e.get("catalog_id", "-"),
            e.get("kind", "-"),
            e.get("display_name", "-"),
            e.get("base_url") or "(SDK default)",
            _fmt_caps(e.get("capabilities", {}) or {}),
            status_dot(e.get("status", "")),
        )
    console.print(table)
    console.print()


@catalog.command("show")
@click.argument("catalog_id")
@click.pass_context
def catalog_show(ctx, catalog_id: str):
    """Show full detail for one catalog preset."""
    entry = api_get(ctx, f"/waxell/v1/llm-config/provider-catalog/{catalog_id}/")
    console.print_json(json.dumps(entry, indent=2))


# =============================================================================
# Instance management
# =============================================================================


@provider.command("list")
@click.option(
    "--format",
    "fmt",
    type=click.Choice(["table", "json"]),
    default="table",
)
@click.pass_context
def list_instances(ctx, fmt: str):
    """List this tenant's configured provider instances."""
    data = api_get(ctx, "/waxell/v1/llm-config/provider-instances/")
    instances = data.get("instances", [])

    if fmt == "json":
        console.print_json(json.dumps(instances, indent=2))
        return

    if not instances:
        print_warning(
            "No provider instances configured. Add one with "
            "'wax provider add <slug> --from-catalog <preset>'."
        )
        return

    print_header("Provider Instances", f"{len(instances)} configured")

    table = Table(show_header=True, header_style="bold cyan", border_style="dim")
    table.add_column("Instance ID", style="bold")
    table.add_column("Kind")
    table.add_column("Catalog")
    table.add_column("Base URL", overflow="fold")
    table.add_column("Secret Ref")
    table.add_column("Models", justify="right")
    table.add_column("Default", justify="center")
    table.add_column("Status", justify="center")

    for i in instances:
        table.add_row(
            i.get("instance_id", "-"),
            i.get("kind", "-"),
            i.get("catalog_id") or "-",
            i.get("base_url") or "(SDK default)",
            i.get("secret_ref", "-"),
            str(i.get("model_count", 0)),
            "✓" if i.get("is_default_for_kind") else "",
            status_dot("active" if i.get("enabled") else "inactive"),
        )
    console.print(table)
    console.print()


@provider.command("show")
@click.argument("instance_id")
@click.pass_context
def show_instance(ctx, instance_id: str):
    """Show full detail for one provider instance."""
    instance = api_get(ctx, f"/waxell/v1/llm-config/provider-instances/{instance_id}/")
    console.print_json(json.dumps(instance, indent=2))


@provider.command("add")
@click.argument("instance_id")
@click.option(
    "--from-catalog",
    "from_catalog",
    type=str,
    default=None,
    help="Catalog preset to autofill from (e.g. 'fireworks', 'bedrock', 'ollama').",
)
@click.option(
    "--kind",
    type=str,
    default=None,
    help="Required when --from-catalog is omitted (e.g. openai_compat, anthropic).",
)
@click.option(
    "--base-url",
    "base_url",
    type=str,
    default=None,
    help="Provider HTTP endpoint. Required for self-hosted/per-deployment kinds.",
)
@click.option(
    "--secret-ref",
    "secret_ref",
    type=str,
    default=None,
    help="Name of the secret holding the API key (set the value separately via 'wax secrets set').",
)
@click.option(
    "--display-name",
    "display_name",
    type=str,
    default=None,
)
@click.option(
    "--default/--no-default",
    "is_default",
    default=False,
    help="Mark this instance as the default for its kind (unqualified model IDs route here).",
)
@click.pass_context
def add_instance(
    ctx,
    instance_id: str,
    from_catalog: str | None,
    kind: str | None,
    base_url: str | None,
    secret_ref: str | None,
    display_name: str | None,
    is_default: bool,
):
    """Create a new provider instance.

    Two paths:

      Catalog (recommended): wax provider add fireworks_main --from-catalog fireworks

      Custom: wax provider add my_vllm --kind openai_compat \\
              --base-url http://10.0.0.5:8000/v1 --secret-ref VLLM_KEY
    """
    body: dict = {"instance_id": instance_id}
    if from_catalog:
        body["catalog_id"] = from_catalog
    if kind:
        body["kind"] = kind
    if base_url is not None:
        body["base_url"] = base_url
    if secret_ref is not None:
        body["secret_ref"] = secret_ref
    if display_name:
        body["display_name"] = display_name
    if is_default:
        body["is_default_for_kind"] = True

    if not from_catalog and not kind:
        raise click.ClickException(
            "Either --from-catalog <preset> or --kind <kind> is required."
        )

    try:
        instance = api_post(ctx, "/waxell/v1/llm-config/provider-instances/", json=body)
    except click.ClickException:
        raise
    except Exception as e:
        print_error(f"Failed to create instance: {e}")
        raise click.exceptions.Exit(1)

    print_success(
        f"Created provider instance '{instance.get('instance_id')}' "
        f"(kind={instance.get('kind')}, base_url={instance.get('base_url') or '(SDK default)'})."
    )
    if instance.get("secret_ref"):
        console.print(
            f"  Set the secret: [cyan]wax secrets set {instance['secret_ref']} <your-api-key>[/cyan]"
        )


def _patch_instance(ctx, instance_id: str, body: dict, success_msg: str) -> None:
    try:
        api_put(
            ctx, f"/waxell/v1/llm-config/provider-instances/{instance_id}/", json=body
        )
    except Exception as e:
        print_error(f"Failed to update instance '{instance_id}': {e}")
        raise click.exceptions.Exit(1)
    print_success(success_msg)


@provider.command("disable")
@click.argument("instance_id")
@click.pass_context
def disable_instance(ctx, instance_id: str):
    """Disable an instance — router skips it, existing data is preserved."""
    _patch_instance(
        ctx,
        instance_id,
        {"enabled": False},
        f"Instance '{instance_id}' disabled.",
    )


@provider.command("enable")
@click.argument("instance_id")
@click.pass_context
def enable_instance(ctx, instance_id: str):
    """Re-enable a previously disabled instance."""
    _patch_instance(
        ctx,
        instance_id,
        {"enabled": True},
        f"Instance '{instance_id}' enabled.",
    )


@provider.command("set-default")
@click.argument("instance_id")
@click.pass_context
def set_default_instance(ctx, instance_id: str):
    """Mark this instance as the default for its kind.

    Unqualified model IDs of this kind (e.g. 'gpt-4o' for kind=openai)
    will route here when no other TenantModel match exists.
    """
    _patch_instance(
        ctx,
        instance_id,
        {"is_default_for_kind": True},
        f"Instance '{instance_id}' marked as default for its kind.",
    )


@provider.command("test")
@click.argument("instance_id")
@click.pass_context
def test_instance(ctx, instance_id: str):
    """Sanity-check a provider instance's configuration.

    Verifies that the instance's secret_ref resolves in the tenant secret
    store. Doesn't make a live API call yet — that's a follow-up. Catches
    the most common misconfiguration ('forgot wax secrets set FIREWORKS_API_KEY
    before adding the instance').
    """
    result = api_post(
        ctx, f"/waxell/v1/llm-config/provider-instances/{instance_id}/test/"
    )
    status_str = result.get("status", "unknown")
    msg = result.get("message", "")
    if status_str == "ok":
        print_success(msg)
    elif status_str == "warn":
        print_warning(msg)
    else:
        print_error(msg)
        raise click.exceptions.Exit(1)


@provider.command("delete")
@click.argument("instance_id")
@click.confirmation_option(
    prompt="Delete this provider instance? (Refused when models still reference it.)"
)
@click.pass_context
def delete_instance(ctx, instance_id: str):
    """Delete a provider instance.

    Refused (409) when one or more TenantModel rows still reference it —
    reassign or delete those models first.
    """
    try:
        api_delete(ctx, f"/waxell/v1/llm-config/provider-instances/{instance_id}/")
    except Exception as e:
        print_error(f"Failed to delete instance '{instance_id}': {e}")
        raise click.exceptions.Exit(1)
    print_success(f"Instance '{instance_id}' deleted.")


# =============================================================================
# Model Groups (Phase 6 #36)
# =============================================================================


@provider.group()
def group():
    """Manage cross-provider fallback chains (ModelGroups).

    A ModelGroup is an ordered list of (instance, model) pairs. Reference
    one in agent task_routes as `models: ["group:my-chain"]` and the
    router expands it into the chain at dispatch time, skipping disabled
    or unhealthy instances.

    Examples:
      wax provider group list
      wax provider group add cheap-llama-70b \\
          --entry fireworks_main/llama-3.1-70b-instruct \\
          --entry groq_main/llama-3.1-70b-versatile \\
          --entry bedrock_main/anthropic.claude-3-haiku
      wax provider group show cheap-llama-70b
      wax provider group delete cheap-llama-70b
    """


@group.command("list")
@click.option(
    "--format",
    "fmt",
    type=click.Choice(["table", "json"]),
    default="table",
)
@click.pass_context
def group_list(ctx, fmt: str):
    """List all model groups for this tenant."""
    data = api_get(ctx, "/waxell/v1/llm-config/model-groups/")
    groups = data.get("groups", [])
    if fmt == "json":
        console.print_json(json.dumps(groups, indent=2))
        return
    if not groups:
        print_warning("No model groups configured.")
        return
    print_header("Model Groups", f"{len(groups)} group(s)")
    table = Table(show_header=True, header_style="bold cyan", border_style="dim")
    table.add_column("Group ID", style="bold")
    table.add_column("Display")
    table.add_column("Entries", justify="right")
    table.add_column("Status", justify="center")
    for g in groups:
        table.add_row(
            g.get("group_id", "-"),
            g.get("display_name") or "-",
            str(len(g.get("entries", []))),
            status_dot("active" if g.get("enabled") else "inactive"),
        )
    console.print(table)
    console.print()


@group.command("show")
@click.argument("group_id")
@click.pass_context
def group_show(ctx, group_id: str):
    """Show full detail for one group, including ordered entries."""
    g = api_get(ctx, f"/waxell/v1/llm-config/model-groups/{group_id}/")
    console.print_json(json.dumps(g, indent=2))


@group.command("add")
@click.argument("group_id")
@click.option(
    "--entry",
    "entries",
    multiple=True,
    help=(
        "Repeatable. Each entry: 'instance_id/model_id' "
        "(e.g. fireworks_main/llama-3.1-70b-instruct). Order matters — "
        "first listed is primary, rest are fallbacks."
    ),
)
@click.option("--display-name", "display_name", default=None)
@click.option("--description", default=None)
@click.pass_context
def group_add(
    ctx,
    group_id: str,
    entries: tuple[str, ...],
    display_name: str | None,
    description: str | None,
):
    """Create a new model group.

    Each --entry is 'instance_id/model_id'. Position in the chain
    matches the order they're listed on the command line.
    """
    if not entries:
        raise click.ClickException(
            "At least one --entry is required (e.g. --entry fireworks_main/llama-3.1-70b)."
        )
    parsed: list[dict] = []
    for idx, raw in enumerate(entries):
        if "/" not in raw:
            raise click.ClickException(
                f"--entry {raw!r} must be 'instance_id/model_id'"
            )
        slug, _, model = raw.partition("/")
        parsed.append(
            {
                "instance_id": slug,
                "model_id": model,
                "position": idx,
                "is_active": True,
            }
        )
    body: dict = {"group_id": group_id, "entries": parsed}
    if display_name:
        body["display_name"] = display_name
    if description:
        body["description"] = description
    try:
        result = api_post(ctx, "/waxell/v1/llm-config/model-groups/", json=body)
    except Exception as e:
        print_error(f"Failed to create group: {e}")
        raise click.exceptions.Exit(1)
    print_success(
        f"Created group '{result.get('group_id')}' with "
        f"{len(result.get('entries', []))} entries. Reference it in task_routes "
        f'as: models: ["group:{group_id}"]'
    )


@group.command("delete")
@click.argument("group_id")
@click.confirmation_option(prompt="Delete this group?")
@click.pass_context
def group_delete(ctx, group_id: str):
    """Delete a model group."""
    try:
        api_delete(ctx, f"/waxell/v1/llm-config/model-groups/{group_id}/")
    except Exception as e:
        print_error(f"Failed to delete group: {e}")
        raise click.exceptions.Exit(1)
    print_success(f"Group '{group_id}' deleted.")


# =============================================================================
# Capability Overrides (Phase 6 #38)
# =============================================================================


@provider.group()
def capability():
    """Pin per-(instance, model) capability flags.

    Use when a provider instance advertises a capability at the instance
    level but a specific model on it doesn't support it (e.g. a Fireworks-
    hosted Llama variant lacking tool support).

    Examples:
      wax provider capability list
      wax provider capability set fireworks_main llama-3.1-70b --no-tools
      wax provider capability clear fireworks_main llama-3.1-70b
    """


@capability.command("list")
@click.option(
    "--format",
    "fmt",
    type=click.Choice(["table", "json"]),
    default="table",
)
@click.pass_context
def capability_list(ctx, fmt: str):
    """List all capability overrides for this tenant."""
    data = api_get(ctx, "/waxell/v1/llm-config/capability-overrides/")
    rows = data.get("overrides", [])
    if fmt == "json":
        console.print_json(json.dumps(rows, indent=2))
        return
    if not rows:
        print_warning("No capability overrides configured.")
        return
    print_header("Capability Overrides", f"{len(rows)} override(s)")
    table = Table(show_header=True, header_style="bold cyan", border_style="dim")
    table.add_column("Instance", style="bold")
    table.add_column("Model")
    table.add_column("Tools")
    table.add_column("JSON")
    table.add_column("Stream")
    table.add_column("Notes")
    for r in rows:
        table.add_row(
            r.get("instance_id", "-"),
            r.get("model_id", "-"),
            str(r.get("native_tools")) if r.get("native_tools") is not None else "-",
            str(r.get("json_mode")) if r.get("json_mode") is not None else "-",
            str(r.get("streaming")) if r.get("streaming") is not None else "-",
            (r.get("notes") or "")[:40],
        )
    console.print(table)
    console.print()


@capability.command("set")
@click.argument("instance_id")
@click.argument("model_id")
@click.option(
    "--tools/--no-tools",
    "native_tools",
    default=None,
    help="Pin tool-calling capability (--tools / --no-tools / omit for default).",
)
@click.option(
    "--json/--no-json",
    "json_mode",
    default=None,
    help="Pin JSON-mode capability.",
)
@click.option(
    "--streaming/--no-streaming",
    "streaming",
    default=None,
    help="Pin streaming capability.",
)
@click.option(
    "--max-context",
    "max_context_tokens",
    type=int,
    default=None,
    help="Pin max context window (tokens).",
)
@click.option("--notes", default=None)
@click.pass_context
def capability_set(
    ctx,
    instance_id: str,
    model_id: str,
    native_tools: bool | None,
    json_mode: bool | None,
    streaming: bool | None,
    max_context_tokens: int | None,
    notes: str | None,
):
    """Set or update a capability override for (instance, model)."""
    body: dict = {
        "instance_id": instance_id,
        "model_id": model_id,
    }
    if native_tools is not None:
        body["native_tools"] = native_tools
    if json_mode is not None:
        body["json_mode"] = json_mode
    if streaming is not None:
        body["streaming"] = streaming
    if max_context_tokens is not None:
        body["max_context_tokens"] = max_context_tokens
    if notes is not None:
        body["notes"] = notes
    try:
        result = api_post(ctx, "/waxell/v1/llm-config/capability-overrides/", json=body)
    except Exception as e:
        print_error(f"Failed to set capability override: {e}")
        raise click.exceptions.Exit(1)
    print_success(
        f"Override set for {instance_id}/{model_id}. "
        f"native_tools={result.get('native_tools')}, "
        f"json_mode={result.get('json_mode')}, "
        f"streaming={result.get('streaming')}."
    )


@capability.command("clear")
@click.argument("instance_id")
@click.argument("model_id")
@click.pass_context
def capability_clear(ctx, instance_id: str, model_id: str):
    """Remove a capability override (model falls back to instance defaults)."""
    overrides = api_get(ctx, "/waxell/v1/llm-config/capability-overrides/").get(
        "overrides", []
    )
    target = next(
        (
            o
            for o in overrides
            if o.get("instance_id") == instance_id and o.get("model_id") == model_id
        ),
        None,
    )
    if target is None:
        print_warning(f"No override found for {instance_id}/{model_id}.")
        return
    try:
        api_delete(
            ctx,
            f"/waxell/v1/llm-config/capability-overrides/{target['id']}/",
        )
    except Exception as e:
        print_error(f"Failed to clear override: {e}")
        raise click.exceptions.Exit(1)
    print_success(f"Override cleared for {instance_id}/{model_id}.")
