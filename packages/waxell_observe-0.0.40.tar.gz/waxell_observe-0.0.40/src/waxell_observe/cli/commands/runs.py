"""Execution run commands."""

import json
import time

import click

from .._http import api_get
from .._display import (
    console,
    print_header,
    print_warning,
    status_dot,
    fmt_number,
    fmt_cost,
    fmt_tokens,
    fmt_duration,
    pct_color,
)
from rich.table import Table
from rich.panel import Panel


_RUNS_GROUP_EPILOG = """\
\b
Commands:
  list    Browse recent runs (default if no subcommand given)
  show    Drill into a single run: spans, LLM calls, scores
  watch   Tail new runs as they arrive
  stats   Aggregate totals and top agents for a window

\b
Examples:
  wax -p <profile> runs                          # last 10 runs in the last 24h
  wax -p <profile> runs list --hours 168         # last week
  wax -p <profile> runs list --status error      # only failures
  wax -p <profile> runs show 230 --spans         # span tree for run 230
  wax -p <profile> runs watch --agent my-agent   # tail new runs for one agent

\b
Tip: 'list' returns a Run ID column; pass that to 'show'. 'show' also
accepts an OTel trace_id or a workflow_id — whichever is easiest to paste.
"""


@click.group(invoke_without_command=True, epilog=_RUNS_GROUP_EPILOG)
@click.pass_context
def runs(ctx):
    """Browse, inspect, and tail agent execution runs.

    A "run" is one end-to-end execution of an agent workflow. Each run has
    a numeric Run ID, an OTel trace_id, and a tree of spans (agent → LLM
    calls → tool calls). Runs are listed newest-first and filtered by the
    tenant plan's retention window (typically 14 days on free, longer on paid).

    With no subcommand, this runs 'list' with defaults (last 10 runs in 24h).
    """
    if ctx.invoked_subcommand is None:
        ctx.invoke(runs_list)


_LIST_EPILOG = """\
\b
Examples:
  wax -p <profile> runs list
  wax -p <profile> runs list --hours 168 --limit 25
  wax -p <profile> runs list --agent outreach --status error
  wax -p <profile> runs list --format json | jq '.traces[] | .id'

\b
Notes:
  - Results are clamped to your tenant's retention window server-side;
    asking for 720h on a 336h plan returns 336h.
  - --agent does substring matching (case-insensitive).
  - The Run ID shown in the table is what you pass to 'runs show'.
"""


@runs.command("list", epilog=_LIST_EPILOG)
@click.option(
    "--agent",
    default=None,
    metavar="NAME",
    help="Filter to runs whose agent name contains NAME (case-insensitive).",
)
@click.option(
    "--status",
    type=click.Choice(["success", "error", "running"]),
    default=None,
    help="Only show runs in this state. 'running' = not yet completed.",
)
@click.option(
    "--hours",
    type=int,
    default=24,
    metavar="N",
    show_default=True,
    help="Look back N hours. Try 168 for a week, 720 for 30 days.",
)
@click.option(
    "--limit",
    type=int,
    default=10,
    metavar="N",
    show_default=True,
    help="Max rows to show. Server caps at 100.",
)
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["table", "json"]),
    default="table",
    show_default=True,
    help="Pretty table or raw JSON (pipe-friendly).",
)
@click.pass_context
def runs_list(ctx, agent: str, status: str, hours: int, limit: int, output_format: str):
    """List recent execution runs, newest first.

    Columns: Run ID | Agent | Workflow | Status | Duration | Cost | Tokens | User.
    Use the Run ID with 'wax runs show <id>' to drill in.
    """
    params: dict = {"hours": hours, "limit": limit}
    if agent:
        params["agent_name"] = agent
    if status:
        params["status"] = status

    data = api_get(ctx, "/v1/observe/query/traces/", params=params)

    if output_format == "json":
        console.print_json(json.dumps(data, indent=2))
        return

    runs_data = data.get("traces", [])
    total = data.get("total", len(runs_data))
    period = data.get("hours", hours)

    if not runs_data:
        print_warning(
            f"No runs found in the last {period}h. "
            f"Try --hours 168 (7d) or --hours 720 (30d)."
        )
        return

    print_header(
        "Execution Runs", f"Last {period}h | {total} total, showing {len(runs_data)}"
    )

    table = Table(show_header=True, header_style="bold cyan", border_style="dim")
    table.add_column("Run ID", style="bold", max_width=14)
    table.add_column("Agent")
    table.add_column("Workflow")
    table.add_column("Status")
    table.add_column("Duration", justify="right")
    table.add_column("Cost", justify="right")
    table.add_column("Tokens", justify="right")
    table.add_column("User", style="dim")

    for run in runs_data:
        run_id = str(run.get("id", ""))[:12]
        run_status = run.get("status", "unknown")

        table.add_row(
            run_id,
            run.get("agent_name", "-"),
            run.get("workflow_name", "-"),
            f"{status_dot(run_status)} {run_status}",
            fmt_duration(run.get("duration", 0)),
            fmt_cost(run.get("total_cost", 0)),
            fmt_tokens(run.get("total_tokens", 0)),
            str(run.get("user_id") or "-"),
        )

    console.print(table)
    console.print()
    console.print("[dim]Drill into a run: [bold]wax runs show <run-id>[/bold][/dim]")


_SHOW_EPILOG = """\
\b
Examples:
  wax -p <profile> runs show 230
  wax -p <profile> runs show 230 --spans
  wax -p <profile> runs show 0a931a81409fc62f970e0c27be287d9f    # by trace_id
  wax -p <profile> runs show 230 --format json > run.json

\b
What you get:
  - Run summary panel (agent, workflow, duration, cost, tokens, session)
  - LLM Calls table (model, task, tokens in/out, cost per call)
  - Scores panel (governance + user-emitted scores)
  - Inputs + Result panels (raw JSON)
  - With --spans: full span tree (agent → LLM/tool children) with timings
"""


@runs.command("show", epilog=_SHOW_EPILOG)
@click.argument("run_id", metavar="RUN_ID")
@click.option(
    "--spans",
    is_flag=True,
    help="Also print the full span tree with indentation and durations.",
)
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["text", "json"]),
    default="text",
    show_default=True,
    help="Human-readable panels or the raw API JSON response.",
)
@click.pass_context
def runs_show(ctx, run_id: str, spans: bool, output_format: str):
    """Show one run's details: summary, LLM calls, scores, inputs, result.

    \b
    RUN_ID can be any of:
      - The numeric Run ID from 'runs list' (e.g. 230)
      - An OTel trace_id hex string
      - A workflow_id

    The server resolves whichever form you pass.
    """
    data = api_get(ctx, "/v1/observe/query/traces/detail/", params={"trace_id": run_id})

    if output_format == "json":
        console.print_json(json.dumps(data, indent=2))
        return

    run = data.get("run")
    if not run:
        print_warning(f"Run '{run_id}' not found.")
        return

    run_status = run.get("status", "unknown")
    llm_calls = data.get("llm_calls", []) or []
    scores = data.get("scores", []) or []
    span_tree = data.get("span_tree", []) or []
    span_count = data.get("span_count", 0)

    total_cost = sum(float(c.get("cost") or 0) for c in llm_calls)
    total_tokens = sum(int(c.get("total_tokens") or 0) for c in llm_calls)

    print_header(f"Run: {run.get('id')}", f"Status: {run_status}")

    detail_lines = [
        f"[bold]Agent:[/bold]    {run.get('agent_name', '-')}",
        f"[bold]Workflow:[/bold] {run.get('workflow_name', '-')}",
        f"[bold]Status:[/bold]   {status_dot(run_status)} {run_status}",
        f"[bold]Duration:[/bold] {fmt_duration(run.get('duration', 0))}",
        f"[bold]Cost:[/bold]     {fmt_cost(total_cost)}",
        f"[bold]Tokens:[/bold]   {fmt_tokens(total_tokens)}",
        f"[bold]User:[/bold]     {run.get('user_id') or '-'}",
        f"[bold]Started:[/bold]  {run.get('started_at', '-')}",
    ]
    if run.get("completed_at"):
        detail_lines.append(f"[bold]Completed:[/bold] {run['completed_at']}")
    if run.get("session_id"):
        detail_lines.append(f"[bold]Session:[/bold]  {run['session_id']}")
    if run.get("trace_id"):
        detail_lines.append(f"[bold]Trace ID:[/bold] {run['trace_id']}")

    console.print(
        Panel("\n".join(detail_lines), title="Run Details", border_style="cyan")
    )
    console.print()

    if llm_calls:
        llm_table = Table(
            show_header=True, header_style="bold cyan", border_style="dim"
        )
        llm_table.add_column("Model")
        llm_table.add_column("Task", style="dim")
        llm_table.add_column("Tokens In", justify="right")
        llm_table.add_column("Tokens Out", justify="right")
        llm_table.add_column("Cost", justify="right")

        for call in llm_calls:
            llm_table.add_row(
                call.get("model", "-"),
                call.get("task", "") or "-",
                fmt_tokens(call.get("tokens_in", 0)),
                fmt_tokens(call.get("tokens_out", 0)),
                fmt_cost(call.get("cost", 0)),
            )

        console.print(f"[bold cyan]LLM Calls[/bold cyan] ({len(llm_calls)})")
        console.print(llm_table)
        console.print()

    if scores:
        score_lines = []
        for s in scores:
            val = s.get("numeric_value")
            if val is None:
                val = s.get("string_value", "-")
            score_lines.append(
                f"[bold]{s.get('name', '-')}[/bold]: {val}  [dim]({s.get('source', '-')})[/dim]"
            )
        console.print(
            Panel("\n".join(score_lines), title="Scores", border_style="yellow")
        )
        console.print()

    if spans and span_tree:
        console.print(f"[bold cyan]Span Tree[/bold cyan] ({span_count} spans)")
        for root in span_tree:
            _print_span(root, 0)
        console.print()
    elif span_count:
        console.print(
            f"[dim]{span_count} spans in trace — pass --spans to print the tree.[/dim]"
        )

    if run.get("inputs"):
        console.print(
            Panel(
                json.dumps(run["inputs"], indent=2, default=str),
                title="Inputs",
                border_style="dim",
            )
        )
        console.print()
    if run.get("result"):
        console.print(
            Panel(
                json.dumps(run["result"], indent=2, default=str),
                title="Result",
                border_style="dim",
            )
        )
        console.print()


def _print_span(span: dict, depth: int) -> None:
    """Recursively render a span tree node."""
    indent = "  " * depth
    name = span.get("name", "-")
    kind = span.get("kind", "")
    status = span.get("status", "")
    dur = span.get("duration_ms")
    dur_s = f"{dur}ms" if dur is not None else ""
    console.print(
        f"{indent}{status_dot(status)} [bold]{name}[/bold] "
        f"[dim]({kind}{', ' + dur_s if dur_s else ''})[/dim]"
    )
    for child in span.get("children", []) or []:
        _print_span(child, depth + 1)


_WATCH_EPILOG = """\
\b
Examples:
  wax -p <profile> runs watch
  wax -p <profile> runs watch --agent outreach
  wax -p <profile> runs watch --interval 2

\b
Behavior:
  - Polls the last 1 hour every --interval seconds.
  - Prints only runs it hasn't seen before in this session.
  - Ctrl+C to stop.
"""


@runs.command("watch", epilog=_WATCH_EPILOG)
@click.option(
    "--agent",
    default=None,
    metavar="NAME",
    help="Only show new runs whose agent name contains NAME.",
)
@click.option(
    "--interval",
    type=int,
    default=5,
    metavar="SEC",
    show_default=True,
    help="Poll the API every SEC seconds.",
)
@click.pass_context
def runs_watch(ctx, agent: str, interval: int):
    """Tail new runs as they arrive (polls on an interval).

    A lightweight alternative to streaming — good for spotting fresh activity
    while running a local agent or watching a deploy.
    """
    console.print("[bold cyan]Watching runs...[/bold cyan] (Ctrl+C to stop)")
    console.print()

    seen_ids: set = set()
    try:
        while True:
            params: dict = {"hours": 1, "limit": 50}
            if agent:
                params["agent_name"] = agent

            data = api_get(ctx, "/v1/observe/query/traces/", params=params)
            runs_data = data.get("traces", [])

            new_runs = []
            for run in runs_data:
                rid = run.get("id", "")
                if rid and rid not in seen_ids:
                    seen_ids.add(rid)
                    new_runs.append(run)

            if new_runs:
                table = Table(
                    show_header=True, header_style="bold cyan", border_style="dim"
                )
                table.add_column("Run ID", style="bold", max_width=14)
                table.add_column("Agent")
                table.add_column("Status")
                table.add_column("Duration", justify="right")
                table.add_column("Cost", justify="right")

                for run in new_runs:
                    run_status = run.get("status", "unknown")
                    table.add_row(
                        str(run.get("id", ""))[:12],
                        run.get("agent_name", "-"),
                        f"{status_dot(run_status)} {run_status}",
                        fmt_duration(run.get("duration", 0)),
                        fmt_cost(run.get("total_cost", 0)),
                    )

                console.print(table)

            time.sleep(interval)

    except KeyboardInterrupt:
        console.print()
        console.print("[dim]Stopped watching.[/dim]")


_STATS_EPILOG = """\
\b
Examples:
  wax -p <profile> runs stats                  # last 24h
  wax -p <profile> runs stats --hours 168      # last week
  wax -p <profile> runs stats --format json    # pipe into jq

\b
What you get:
  - Totals: run count, error rate, total cost, avg cost/run
  - Top agents table (runs, error rate, cost per agent)
"""


@runs.command("stats", epilog=_STATS_EPILOG)
@click.option(
    "--hours",
    type=int,
    default=24,
    metavar="N",
    show_default=True,
    help="Aggregation window in hours (server clamps to retention).",
)
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["table", "json"]),
    default="table",
    show_default=True,
    help="Pretty tables or raw JSON.",
)
@click.pass_context
def runs_stats(ctx, hours: int, output_format: str):
    """Aggregate totals and top agents across a time window.

    Uses the dashboard endpoint — faster than 'list' for just counts + costs,
    and returns a top-agents breakdown you can skim for anomalies.
    """
    data = api_get(ctx, "/v1/observe/query/dashboard/", params={"hours": hours})

    if output_format == "json":
        console.print_json(json.dumps(data, indent=2))
        return

    print_header("Run Statistics", f"Last {hours}h")

    total = data.get("total_runs", data.get("total_executions", 0))
    error_rate = data.get("error_rate", 0)
    error_pct = error_rate * 100 if error_rate < 1 else error_rate
    avg_cost = data.get("avg_cost_per_run", data.get("avg_cost", 0))
    total_cost = data.get("total_cost", 0)

    stats_text = (
        f"[bold]Total Runs:[/bold]   {fmt_number(total)}\n"
        f"[bold]Error Rate:[/bold]   {error_pct:.1f}%\n"
        f"[bold]Total Cost:[/bold]   {fmt_cost(total_cost)}\n"
        f"[bold]Avg Cost/Run:[/bold] {fmt_cost(avg_cost)}"
    )
    console.print(Panel(stats_text, title="Summary", border_style="cyan"))
    console.print()

    # Top agents
    top_agents = data.get("top_agents", [])
    if top_agents:
        agent_table = Table(
            show_header=True, header_style="bold cyan", border_style="dim"
        )
        agent_table.add_column("Agent", style="bold")
        agent_table.add_column("Runs", justify="right")
        agent_table.add_column("Error Rate", justify="right")
        agent_table.add_column("Cost", justify="right")

        for agent in top_agents:
            a_err = agent.get("error_rate", 0)
            a_err_pct = a_err * 100 if a_err < 1 else a_err
            err_color = pct_color(a_err_pct)

            agent_table.add_row(
                agent.get("name", agent.get("agent_name", "unknown")),
                fmt_number(agent.get("runs", agent.get("executions", 0))),
                f"[{err_color}]{a_err_pct:.1f}%[/{err_color}]",
                fmt_cost(agent.get("cost", 0)),
            )

        console.print(agent_table)
        console.print()
