"""Rich display utilities for wax CLI."""

import sys
from typing import Any, Optional

from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.text import Text
from rich.tree import Tree

console = Console()

# On legacy Windows consoles (cp1252), rich's Win32 renderer hardcodes
# `text.encode("cp1252")` which crashes on glyphs like ℹ ✓ ✗ ⚠ ●. Detect that
# environment and substitute ASCII fallbacks so the CLI works everywhere
# (including cross-compiled .exe distributions).
_ENC = (sys.stdout.encoding or "").lower() if hasattr(sys.stdout, "encoding") else ""
_USE_ASCII_GLYPHS = sys.platform == "win32" and "utf" not in _ENC

_GLYPHS = {
    "check": "[OK]" if _USE_ASCII_GLYPHS else "\u2713",  # ✓
    "cross": "[ERR]" if _USE_ASCII_GLYPHS else "\u2717",  # ✗
    "warn": "[WARN]" if _USE_ASCII_GLYPHS else "!",
    "info": "[INFO]" if _USE_ASCII_GLYPHS else "\u2139",  # ℹ
    "dot": "*" if _USE_ASCII_GLYPHS else "\u25cf",  # ●
}

STATUS_COLORS = {
    "active": "green",
    "enabled": "green",
    "running": "green",
    "completed": "green",
    "success": "green",
    "inactive": "dim",
    "disabled": "dim",
    "paused": "yellow",
    "pending": "yellow",
    "warning": "yellow",
    "failed": "red",
    "error": "red",
    "killed": "red",
    "triggered": "red",
}


def status_badge(status: str) -> Text:
    """Create a colored status badge."""
    color = STATUS_COLORS.get(status.lower(), "white")
    return Text(f" {status.upper()} ", style=f"bold {color} on {color}")


def status_dot(status: str) -> str:
    """Create a colored status dot."""
    color = STATUS_COLORS.get(status.lower(), "white")
    return f"[{color}]{_GLYPHS['dot']}[/{color}]"


def print_header(title: str, subtitle: Optional[str] = None):
    """Print a styled header."""
    console.print()
    console.print(f"[bold cyan]{title}[/bold cyan]")
    if subtitle:
        console.print(f"[dim]{subtitle}[/dim]")
    console.print()


def print_success(message: str):
    console.print(f"[green]{_GLYPHS['check']}[/green] {message}")


def print_error(message: str):
    console.print(f"[red]{_GLYPHS['cross']}[/red] {message}")


def print_warning(message: str):
    console.print(f"[yellow]{_GLYPHS['warn']}[/yellow] {message}")


def print_info(message: str):
    console.print(f"[blue]{_GLYPHS['info']}[/blue] {message}")


def loading_spinner(message: str = "Loading..."):
    """Create a loading spinner context manager."""
    return Progress(
        SpinnerColumn(),
        TextColumn("[bold cyan]{task.description}"),
        console=console,
        transient=True,
    )


def fmt_number(n: Any) -> str:
    """Format a number with commas."""
    if isinstance(n, (int, float)):
        if isinstance(n, float) and n == int(n):
            return f"{int(n):,}"
        return f"{n:,}"
    return str(n)


def fmt_cost(n: Any) -> str:
    """Format a dollar amount with enough precision to show small values.

    Embedding calls and short single-turn chats often cost a fraction of
    a cent — formatting at 2dp rounds them to "$0.00" and makes it look
    like the call was free. Bumps precision up to 4dp when the value
    is below $0.01 but greater than 0, and 6dp when below $0.0001, so
    small but real costs are still visible. Larger amounts stay at the
    familiar 2dp money shape.
    """
    if isinstance(n, (int, float)):
        if n <= 0:
            return "$0.00"
        if n < 0.0001:
            return f"${n:,.6f}"
        if n < 0.01:
            return f"${n:,.4f}"
        return f"${n:,.2f}"
    return str(n)


def fmt_tokens(n: Any) -> str:
    """Format token counts with K/M suffixes."""
    if isinstance(n, (int, float)):
        if n >= 1_000_000:
            return f"{n / 1_000_000:.1f}M"
        if n >= 1_000:
            return f"{n / 1_000:.1f}K"
        return fmt_number(n)
    return str(n)


def fmt_duration(seconds: Any) -> str:
    """Format a duration in seconds to human-readable."""
    if not isinstance(seconds, (int, float)):
        return str(seconds)
    if seconds < 1:
        return f"{seconds * 1000:.0f}ms"
    if seconds < 60:
        return f"{seconds:.1f}s"
    if seconds < 3600:
        mins = int(seconds // 60)
        secs = seconds % 60
        return f"{mins}m {secs:.0f}s"
    hours = int(seconds // 3600)
    mins = int((seconds % 3600) // 60)
    return f"{hours}h {mins}m"


def pct_color(value: float, warn: float = 70, danger: float = 90) -> str:
    """Return Rich color name based on percentage thresholds."""
    if value < warn:
        return "green"
    if value < danger:
        return "yellow"
    return "red"


def trend_arrow(trend: Any) -> str:
    """Format a trend value with arrow."""
    if trend is None:
        return ""
    try:
        val = float(trend)
    except (TypeError, ValueError):
        return ""
    if val > 0:
        return f"[green]\u2191{val:+.1f}%[/green]"
    if val < 0:
        return f"[red]\u2193{val:+.1f}%[/red]"
    return "[dim]--[/dim]"


def usage_gauge(label: str, current: float, limit: float, width: int = 40):
    """Display a usage gauge."""
    pct = (current / limit * 100) if limit > 0 else 0
    filled = int((pct / 100) * width)
    empty = width - filled
    color = pct_color(pct)

    bar = f"[{color}]{'█' * filled}[/{color}][dim]{'░' * empty}[/dim]"
    console.print(f"{label}")
    console.print(f"  {bar} {pct:.1f}%")
    console.print(f"  [dim]{current:,.0f} / {limit:,.0f}[/dim]")
    console.print()


def print_tree(name: str, items: dict[str, Any], style: str = "cyan"):
    """Print a tree structure."""
    tree = Tree(f"[bold {style}]{name}[/bold {style}]")
    _add_tree_items(tree, items)
    console.print(tree)


def _add_tree_items(tree: Tree, items: dict[str, Any]):
    for key, value in items.items():
        if isinstance(value, dict):
            branch = tree.add(f"[bold]{key}[/bold]")
            _add_tree_items(branch, value)
        elif isinstance(value, list):
            branch = tree.add(f"[bold]{key}[/bold]")
            for item in value:
                if isinstance(item, dict):
                    _add_tree_items(branch, item)
                else:
                    branch.add(str(item))
        else:
            tree.add(f"[bold]{key}:[/bold] {value}")
