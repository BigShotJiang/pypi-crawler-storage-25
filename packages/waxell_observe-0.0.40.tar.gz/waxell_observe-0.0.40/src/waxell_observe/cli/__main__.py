"""Entry point for PyInstaller binary and `python -m waxell_observe.cli`."""

import sys

# Force UTF-8 stdout/stderr on Windows so rich can print non-ASCII glyphs
# without crashing on legacy cp1252 console encoding. Also makes any future
# unicode in our output safe (file paths, agent names, etc.).
# `errors="replace"` means we never crash on encoding errors — worst case
# we substitute "?" for unmappable chars.
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[union-attr]
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[union-attr]
    except Exception:
        pass

from waxell_observe.cli import cli  # noqa: E402

if __name__ == "__main__":
    cli()
