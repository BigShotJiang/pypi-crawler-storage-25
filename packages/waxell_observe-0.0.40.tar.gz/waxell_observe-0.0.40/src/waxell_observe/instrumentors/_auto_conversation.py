"""Shared auto-conversation recording for LLM instrumentors.

When an LLM call is made, this module extracts conversation state from the
messages array and response: user messages, agent responses, context window
metrics. All 13+ provider instrumentors call ``record_conversation_io`` after
recording the LLM call itself.

Usage from an instrumentor::

    from ._auto_conversation import record_conversation_io

    record_conversation_io(
        messages=messages,
        response_preview=response_preview,
        is_final_response=True,  # finish_reason == "stop"
        tokens_in_context=prompt_tokens,
        model=response_model,
        ctx=ctx,
    )
"""

from __future__ import annotations

import hashlib
import logging
from typing import TYPE_CHECKING, Any

from ._context_var import _current_context

if TYPE_CHECKING:
    from ..context import WaxellContext

logger = logging.getLogger(__name__)


def _hash_content(content: str) -> str:
    """Return a short hash of content for dedup comparison."""
    return hashlib.md5(content.encode("utf-8", errors="replace")).hexdigest()[:12]


def _extract_text_content(message: dict[str, Any] | Any) -> str:
    """Extract text content from a message dict.

    Handles both OpenAI-style string content and structured content arrays.
    """
    if not isinstance(message, dict):
        # Pydantic model object
        content = getattr(message, "content", None)
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            parts = []
            for part in content:
                if isinstance(part, dict) and part.get("type") == "text":
                    parts.append(part.get("text", ""))
                elif hasattr(part, "text"):
                    parts.append(getattr(part, "text", ""))
            return " ".join(parts)
        return str(content) if content else ""

    content = message.get("content", "")
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        # Structured content array (OpenAI, Anthropic)
        parts = []
        for part in content:
            if isinstance(part, dict) and part.get("type") == "text":
                parts.append(part.get("text", ""))
            elif isinstance(part, str):
                parts.append(part)
        return " ".join(parts)
    return str(content) if content else ""


def _get_role(message: dict[str, Any] | Any) -> str:
    """Extract role from a message (dict or Pydantic model)."""
    if isinstance(message, dict):
        return message.get("role", "")
    return getattr(message, "role", "")


def record_conversation_io(
    messages: list,
    response_preview: str,
    is_final_response: bool,
    tokens_in_context: int,
    model: str,
    ctx: WaxellContext | None = None,
    system_content: str = "",
) -> None:
    """Auto-capture user messages, agent responses, and context metrics.

    Called by every instrumentor's ``_record_http_*`` function AFTER the
    LLM call is recorded. Each instrumentor extracts provider-specific
    fields and passes normalized data here.

    Args:
        messages: The messages array sent to the LLM.
        response_preview: Text content of the LLM response (already extracted).
        is_final_response: True if finish_reason is "stop"/"end_turn" (not tool_calls).
        tokens_in_context: prompt_tokens / input_tokens from response.usage.
        model: Model name (for context window limit lookup).
        ctx: Active WaxellContext. If None, looks up from ContextVar.
        system_content: System prompt content (for Anthropic which passes it separately).
    """
    if ctx is None:
        ctx = _current_context.get()
    if ctx is None:
        return

    try:
        _do_record(
            messages,
            response_preview,
            is_final_response,
            tokens_in_context,
            model,
            ctx,
            system_content,
        )
    except Exception:
        pass  # Never break user code


def _do_record(
    messages: list,
    response_preview: str,
    is_final_response: bool,
    tokens_in_context: int,
    model: str,
    ctx: "WaxellContext",
    system_content: str,
) -> None:
    """Internal implementation — separated for cleaner exception handling."""
    if not messages:
        return

    # 1. Extract + deduplicate user message
    last_user_content = ""
    for msg in reversed(messages):
        if _get_role(msg) == "user":
            last_user_content = _extract_text_content(msg)
            break

    if last_user_content:
        content_hash = _hash_content(last_user_content)
        if content_hash != getattr(ctx, "_last_user_msg_hash", ""):
            ctx._last_user_msg_hash = content_hash
            ctx.record_user_message(last_user_content)

    # 2. Record agent response (only on final text response)
    if is_final_response and response_preview:
        response_hash = _hash_content(response_preview)
        if response_hash != getattr(ctx, "_last_agent_resp_hash", ""):
            ctx._last_agent_resp_hash = response_hash
            ctx.record_agent_response(response_preview)

    # 3. Compute conversation metrics from messages array
    user_turns = 0
    assistant_turns = 0
    tool_results = 0
    for msg in messages:
        role = _get_role(msg)
        if role == "user":
            user_turns += 1
        elif role == "assistant":
            assistant_turns += 1
        elif role in ("tool", "function"):
            tool_results += 1

    message_count = len(messages)

    # 4. System prompt hash
    system_hash = ""
    if system_content:
        system_hash = _hash_content(system_content)
    else:
        for msg in messages:
            if _get_role(msg) == "system":
                sys_text = _extract_text_content(msg)
                if sys_text:
                    system_hash = _hash_content(sys_text)
                break

    # 5. Compute context utilization
    utilization_pct = 0.0
    if tokens_in_context > 0:
        from ..model_limits import get_context_limit

        limit = get_context_limit(model)
        if limit:
            utilization_pct = tokens_in_context / limit * 100

    # 6. Update context state
    ctx.update_conversation_state(
        user_turns=user_turns,
        message_count=message_count,
        assistant_turns=assistant_turns,
        tool_results=tool_results,
        tokens_in_context=tokens_in_context,
        context_utilization_pct=utilization_pct,
        system_prompt_hash=system_hash,
    )
