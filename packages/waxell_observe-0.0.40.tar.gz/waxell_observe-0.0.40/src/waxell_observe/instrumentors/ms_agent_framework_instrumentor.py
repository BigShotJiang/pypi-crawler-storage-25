"""Microsoft Agent Framework auto-instrumentor for waxell-observe.

Instruments the Microsoft Agent Framework (``agent-framework`` package,
import ``agent_framework``) — the successor to AutoGen and Semantic Kernel.

The Microsoft Agent Framework provides:
- ``Agent`` class with model clients for single-agent execution
- Graph-based workflows for multi-agent orchestration
- Session-based state management with middleware

Primary entry points:
- ``Agent.invoke()`` / ``Agent.invoke_stream()`` — single agent execution
- ``AgentGroupChat.invoke()`` — multi-agent orchestration
- ``GraphFlow.invoke()`` — graph-based workflow execution

All wrapper code is wrapped in try/except — never breaks the user's calls.
"""

from __future__ import annotations

import logging
import time

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class MSAgentFrameworkInstrumentor(BaseInstrumentor):
    """Instrumentor for Microsoft Agent Framework.

    Patches Agent, AgentGroupChat, and GraphFlow execution entry points.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import agent_framework  # noqa: F401
        except ImportError:
            logger.debug("agent_framework not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug(
                "wrapt not installed -- skipping MS Agent Framework instrumentation"
            )
            return False

        patched = False

        # ── Agent.invoke (async) ──────────────────────────────────────
        try:
            wrapt.wrap_function_wrapper(
                "agent_framework",
                "Agent.invoke",
                _agent_invoke_async_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch Agent.invoke: %s", exc)

        # ── Agent.invoke_stream (async) ───────────────────────────────
        try:
            wrapt.wrap_function_wrapper(
                "agent_framework",
                "Agent.invoke_stream",
                _agent_invoke_stream_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch Agent.invoke_stream: %s", exc)

        # ── Try submodule paths for Agent if top-level didn't work ────
        if not patched:
            for submod in ("agent_framework.agents", "agent_framework.core"):
                try:
                    wrapt.wrap_function_wrapper(
                        submod,
                        "Agent.invoke",
                        _agent_invoke_async_wrapper,
                    )
                    patched = True
                except Exception:
                    pass

        # ── AgentGroupChat.invoke (multi-agent) ──────────────────────
        for mod_path in ("agent_framework", "agent_framework.agents"):
            try:
                wrapt.wrap_function_wrapper(
                    mod_path,
                    "AgentGroupChat.invoke",
                    _group_chat_invoke_wrapper,
                )
                patched = True
                break
            except Exception:
                pass

        # ── GraphFlow.invoke (graph-based workflow) ───────────────────
        for mod_path in ("agent_framework", "agent_framework.graph"):
            try:
                wrapt.wrap_function_wrapper(
                    mod_path,
                    "GraphFlow.invoke",
                    _graph_flow_invoke_wrapper,
                )
                patched = True
                break
            except Exception:
                pass

        if not patched:
            logger.debug("Could not find MS Agent Framework methods to patch")
            return False

        self._instrumented = True
        logger.debug("Microsoft Agent Framework instrumented")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        for mod_path in (
            "agent_framework",
            "agent_framework.agents",
            "agent_framework.core",
            "agent_framework.graph",
        ):
            try:
                import importlib

                mod = importlib.import_module(mod_path)
                for cls_name in ("Agent", "AgentGroupChat", "GraphFlow"):
                    cls = getattr(mod, cls_name, None)
                    if cls is None:
                        continue
                    for method_name in ("invoke", "invoke_stream"):
                        method = getattr(cls, method_name, None)
                        if method and hasattr(method, "__wrapped__"):
                            setattr(cls, method_name, method.__wrapped__)
            except (ImportError, AttributeError):
                pass

        self._instrumented = False
        logger.debug("Microsoft Agent Framework uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Metadata extraction
# ---------------------------------------------------------------------------


def _extract_agent_info(instance) -> dict:
    """Extract agent metadata from an Agent instance."""
    info: dict = {}

    info["agent_name"] = (
        getattr(instance, "name", None)
        or getattr(instance, "id", None)
        or "ms_agent_framework.agent"
    )

    # Model client info
    model_client = getattr(instance, "model_client", None) or getattr(
        instance, "client", None
    )
    if model_client:
        model_name = (
            getattr(model_client, "model", None)
            or getattr(model_client, "model_id", None)
            or type(model_client).__name__
        )
        info["model"] = str(model_name)

    # Instructions
    instructions = getattr(instance, "instructions", None) or getattr(
        instance, "system_prompt", None
    )
    if instructions:
        info["instructions_preview"] = str(instructions)[:200]

    # Plugins / tools
    plugins = (
        getattr(instance, "plugins", None) or getattr(instance, "tools", None) or []
    )
    if plugins:
        tool_names = []
        for p in plugins:
            name = getattr(p, "name", None) or type(p).__name__
            tool_names.append(str(name))
        info["tools"] = tool_names

    return info


def _extract_group_chat_info(instance) -> dict:
    """Extract metadata from an AgentGroupChat instance."""
    info: dict = {"agent_name": "ms_agent_framework.group_chat"}

    # Participating agents
    agents = getattr(instance, "agents", None) or []
    if agents:
        agent_names = []
        for a in agents:
            name = (
                getattr(a, "name", None) or getattr(a, "id", None) or type(a).__name__
            )
            agent_names.append(str(name))
        info["participant_agents"] = agent_names
        info["agent_count"] = len(agent_names)

    # Selection strategy
    strategy = getattr(instance, "selection_strategy", None)
    if strategy:
        info["selection_strategy"] = type(strategy).__name__

    # Termination strategy
    termination = getattr(instance, "termination_strategy", None)
    if termination:
        info["termination_strategy"] = type(termination).__name__

    return info


def _extract_graph_flow_info(instance) -> dict:
    """Extract metadata from a GraphFlow instance."""
    info: dict = {"agent_name": "ms_agent_framework.graph_flow"}

    name = getattr(instance, "name", None)
    if name:
        info["agent_name"] = str(name)

    # Nodes / agents in the graph
    nodes = getattr(instance, "nodes", None) or getattr(instance, "agents", None) or []
    if nodes:
        node_names = []
        for n in nodes:
            name = (
                getattr(n, "name", None) or getattr(n, "id", None) or type(n).__name__
            )
            node_names.append(str(name))
        info["graph_nodes"] = node_names
        info["node_count"] = len(node_names)

    # Edges
    edges = getattr(instance, "edges", None) or []
    if edges:
        info["edge_count"] = len(edges)

    return info


def _extract_result_info(result) -> dict:
    """Extract metadata from execution results."""
    info: dict = {}

    # Messages / chat history
    messages = getattr(result, "messages", None) or getattr(
        result, "chat_history", None
    )
    if messages and hasattr(messages, "__len__"):
        info["message_count"] = len(messages)

    # Final output
    output = (
        getattr(result, "value", None)
        or getattr(result, "content", None)
        or getattr(result, "text", None)
    )
    if output:
        info["output_preview"] = str(output)[:500]

    # Token usage
    usage = getattr(result, "usage", None)
    if usage is None:
        metadata = getattr(result, "metadata", None)
        if isinstance(metadata, dict) and (
            "prompt_tokens" in metadata or "completion_tokens" in metadata
        ):
            usage = metadata
    if isinstance(usage, dict):
        if "prompt_tokens" in usage or "completion_tokens" in usage:
            info["tokens_in"] = usage.get("prompt_tokens", 0)
            info["tokens_out"] = usage.get("completion_tokens", 0)
    elif usage is not None and hasattr(usage, "prompt_tokens"):
        info["tokens_in"] = getattr(usage, "prompt_tokens", 0)
        info["tokens_out"] = getattr(usage, "completion_tokens", 0)

    return info


# ---------------------------------------------------------------------------
# Agent.invoke wrapper
# ---------------------------------------------------------------------------


async def _agent_invoke_async_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``Agent.invoke``."""
    try:
        from ..tracing.spans import start_agent_span
    except Exception:
        return await wrapped(*args, **kwargs)

    info = _extract_agent_info(instance)
    agent_name = info.get("agent_name", "ms_agent_framework.agent")

    try:
        span = start_agent_span(
            agent_name=agent_name,
            workflow_name="ms_agent_framework_invoke",
        )
        _set_span_attributes(span, info)
    except Exception:
        return await wrapped(*args, **kwargs)

    start_time = time.monotonic()
    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        duration_ms = (time.monotonic() - start_time) * 1000
        try:
            result_info = _extract_result_info(result)
            _set_result_attributes(span, result_info, duration_ms)
            _record_to_context(agent_name, info, result_info)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Agent.invoke_stream wrapper
# ---------------------------------------------------------------------------


async def _agent_invoke_stream_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``Agent.invoke_stream``."""
    try:
        from ..tracing.spans import start_agent_span
    except Exception:
        async for chunk in wrapped(*args, **kwargs):
            yield chunk
        return

    info = _extract_agent_info(instance)
    agent_name = info.get("agent_name", "ms_agent_framework.agent")

    try:
        span = start_agent_span(
            agent_name=agent_name,
            workflow_name="ms_agent_framework_invoke_stream",
        )
        _set_span_attributes(span, info)
    except Exception:
        async for chunk in wrapped(*args, **kwargs):
            yield chunk
        return

    start_time = time.monotonic()
    chunk_count = 0
    try:
        async for chunk in wrapped(*args, **kwargs):
            chunk_count += 1
            yield chunk
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        duration_ms = (time.monotonic() - start_time) * 1000
        try:
            span.set_attribute("waxell.ms_agent_framework.stream_chunks", chunk_count)
            span.set_attribute(
                "waxell.ms_agent_framework.duration_ms", round(duration_ms, 2)
            )
            _record_to_context(agent_name, info, {"chunk_count": chunk_count})
        except Exception:
            pass
    finally:
        span.end()


# ---------------------------------------------------------------------------
# AgentGroupChat.invoke wrapper
# ---------------------------------------------------------------------------


async def _group_chat_invoke_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``AgentGroupChat.invoke``."""
    try:
        from ..tracing.spans import start_agent_span
    except Exception:
        return await wrapped(*args, **kwargs)

    info = _extract_group_chat_info(instance)
    agent_name = info.get("agent_name", "ms_agent_framework.group_chat")

    try:
        span = start_agent_span(
            agent_name=agent_name,
            workflow_name="ms_agent_framework_group_chat",
        )
        span.set_attribute("waxell.ms_agent_framework.agent_name", agent_name)
        span.set_attribute("waxell.ms_agent_framework.execution_type", "group_chat")

        if "participant_agents" in info:
            span.set_attribute(
                "waxell.ms_agent_framework.participant_agents",
                info["participant_agents"],
            )
            span.set_attribute(
                "waxell.ms_agent_framework.agent_count", info["agent_count"]
            )
        if "selection_strategy" in info:
            span.set_attribute(
                "waxell.ms_agent_framework.selection_strategy",
                info["selection_strategy"],
            )
        if "termination_strategy" in info:
            span.set_attribute(
                "waxell.ms_agent_framework.termination_strategy",
                info["termination_strategy"],
            )
    except Exception:
        return await wrapped(*args, **kwargs)

    start_time = time.monotonic()
    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        duration_ms = (time.monotonic() - start_time) * 1000
        try:
            result_info = _extract_result_info(result)
            _set_result_attributes(span, result_info, duration_ms)
            _record_to_context(agent_name, info, result_info)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# GraphFlow.invoke wrapper
# ---------------------------------------------------------------------------


async def _graph_flow_invoke_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``GraphFlow.invoke``."""
    try:
        from ..tracing.spans import start_agent_span
    except Exception:
        return await wrapped(*args, **kwargs)

    info = _extract_graph_flow_info(instance)
    agent_name = info.get("agent_name", "ms_agent_framework.graph_flow")

    try:
        span = start_agent_span(
            agent_name=agent_name,
            workflow_name="ms_agent_framework_graph_flow",
        )
        span.set_attribute("waxell.ms_agent_framework.agent_name", agent_name)
        span.set_attribute("waxell.ms_agent_framework.execution_type", "graph_flow")

        if "graph_nodes" in info:
            span.set_attribute(
                "waxell.ms_agent_framework.graph_nodes", info["graph_nodes"]
            )
            span.set_attribute(
                "waxell.ms_agent_framework.node_count", info["node_count"]
            )
        if "edge_count" in info:
            span.set_attribute(
                "waxell.ms_agent_framework.edge_count", info["edge_count"]
            )
    except Exception:
        return await wrapped(*args, **kwargs)

    start_time = time.monotonic()
    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        duration_ms = (time.monotonic() - start_time) * 1000
        try:
            result_info = _extract_result_info(result)
            _set_result_attributes(span, result_info, duration_ms)
            _record_to_context(agent_name, info, result_info)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Span attribute helpers
# ---------------------------------------------------------------------------


def _set_span_attributes(span, info: dict) -> None:
    """Set agent configuration attributes on the span."""
    span.set_attribute(
        "waxell.ms_agent_framework.agent_name", info.get("agent_name", "")
    )
    span.set_attribute("waxell.ms_agent_framework.execution_type", "single_agent")

    if "model" in info:
        span.set_attribute("waxell.ms_agent_framework.model", info["model"])
    if "tools" in info:
        span.set_attribute("waxell.ms_agent_framework.tools", info["tools"])
        span.set_attribute("waxell.ms_agent_framework.tool_count", len(info["tools"]))
    if "instructions_preview" in info:
        span.set_attribute(
            "waxell.ms_agent_framework.instructions_preview",
            info["instructions_preview"],
        )


def _set_result_attributes(span, result_info: dict, duration_ms: float) -> None:
    """Set execution result attributes on the span."""
    span.set_attribute("waxell.ms_agent_framework.duration_ms", round(duration_ms, 2))

    if "tokens_in" in result_info:
        span.set_attribute(
            "waxell.ms_agent_framework.tokens_in", result_info["tokens_in"]
        )
    if "tokens_out" in result_info:
        span.set_attribute(
            "waxell.ms_agent_framework.tokens_out", result_info["tokens_out"]
        )
    if "message_count" in result_info:
        span.set_attribute(
            "waxell.ms_agent_framework.message_count", result_info["message_count"]
        )
    if "output_preview" in result_info:
        span.set_attribute(
            "waxell.ms_agent_framework.output_preview", result_info["output_preview"]
        )


# ---------------------------------------------------------------------------
# Context recording
# ---------------------------------------------------------------------------


def _record_to_context(agent_name: str, info: dict, result_info: dict) -> None:
    """Record execution to the Waxell context."""
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            ctx.record_step(
                f"ms_agent_framework:{agent_name}",
                output={
                    "model": info.get("model", ""),
                    "tools": info.get("tools", []),
                    "tokens_in": result_info.get("tokens_in", 0),
                    "tokens_out": result_info.get("tokens_out", 0),
                    "output_preview": result_info.get("output_preview", ""),
                },
            )
    except Exception:
        pass


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
