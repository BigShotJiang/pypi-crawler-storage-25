"""Thread-local coordination so a single logical LLM call doesn't get
recorded twice when two instrumentors observe it.

Concrete case: ChatWatsonx (langchain-ibm) routes through
``ModelInference.chat()``. Both the watsonx instrumentor's chat wrapper
AND LangChain's ``on_llm_end`` callback fire for the SAME call. Without
coordination, the call gets two HTTP records (``task="chat"`` and
``task="langchain.llm"``), token counts get doubled in the run total,
and any mid-execution budget policy trips at half the configured limit.

The flow:

  1. Watsonx chat wrapper runs ``_record_http_chat`` (rich prompt/response).
  2. Wrapper calls ``mark_recorded()`` → flag set on this thread.
  3. LangChain ``on_llm_end`` fires later in the same call stack.
  4. on_llm_end calls ``consume()`` — sees flag, skips its own record,
     clears the flag.
  5. Next unrelated call starts with a clean slate.

Thread-local is the right scope: wrapt-wrapped calls and LangChain
callbacks fire synchronously on the same thread for a given LLM call.
Async/streaming agents that fan out across threads will each get their
own flag, so cross-thread bleed isn't a concern.
"""

from __future__ import annotations

import threading

_local = threading.local()


def mark_recorded() -> None:
    """Mark that the HTTP record for the current LLM call was already
    emitted by an upstream instrumentor — the next consumer should skip."""
    _local.recorded = True


def consume() -> bool:
    """Check + clear the flag. Returns True if the upstream instrumentor
    already recorded this call (caller should skip)."""
    recorded = getattr(_local, "recorded", False)
    _local.recorded = False
    return bool(recorded)
