"""Context-var that signals "we're inside waxell.llm dispatch — do
NOT record the underlying SDK call as its own LlmCallRecord."

Phase E of OBSERVE_DISPATCH_PLAN. Without this, every dispatch call
would emit two records: one from the dispatch wrapper (with provider
attribution + fallback metadata) and one from the underlying
instrumentor patching the same SDK method.

Usage in dispatch (set the flag around the SDK invocation)::

    with dispatch_in_flight_token():
        return sdk_client.chat.completions.create(...)

Usage in each LLM instrumentor (suppress recording when flag is set)::

    def _sync_chat_wrapper(wrapped, instance, args, kwargs):
        if is_dispatch_in_flight():
            return wrapped(*args, **kwargs)
        # ... existing instrumentation ...
"""

from __future__ import annotations

from contextlib import contextmanager
from contextvars import ContextVar
from typing import Iterator

_dispatch_in_flight: ContextVar[bool] = ContextVar(
    "_waxell_dispatch_in_flight", default=False
)


def is_dispatch_in_flight() -> bool:
    """Return True if the current task/thread is inside a
    ``waxell.llm.call(...)`` invocation."""
    return _dispatch_in_flight.get()


@contextmanager
def dispatch_in_flight_token() -> Iterator[None]:
    """Context manager that flips the flag for the duration of the
    enclosed block and restores the prior value on exit."""
    token = _dispatch_in_flight.set(True)
    try:
        yield
    finally:
        _dispatch_in_flight.reset(token)
