"""Subprocess & os.system auto-instrumentor for waxell-observe.

Monkey-patches ``subprocess.run``, ``subprocess.Popen.__init__``, and
``os.system`` to emit OTel tool spans and enforce code-execution governance
for local command execution:
  - ``subprocess.run``       -- sync command execution (captures output)
  - ``subprocess.Popen``     -- long-lived process creation
  - ``os.system``            -- simple command execution (return code only)

Pre-execution governance validates commands against code-execution policies
BEFORE the command runs.  If governance blocks, ``PolicyViolationError``
propagates and the command never executes.

OPT-IN only — subprocess is always importable, so this instrumentor is
registered in ``_REGISTRY`` but NOT auto-detected.  Activate via:

    instrument_all(libraries=["subprocess"])

All wrapper code is wrapped in try/except — never breaks the user's calls
(except for governance blocks, which MUST propagate).
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class SubprocessInstrumentor(BaseInstrumentor):
    """Instrumentor for subprocess.run, subprocess.Popen, and os.system.

    Patches these functions via wrapt to add OTel spans and code-execution
    governance.  Only active inside a WaxellContext.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import wrapt
        except ImportError:
            logger.debug(
                "wrapt package not installed -- skipping subprocess instrumentation"
            )
            return False

        patched = False

        # Patch subprocess.run
        try:
            wrapt.wrap_function_wrapper(
                "subprocess",
                "run",
                _subprocess_run_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch subprocess.run: %s", exc)

        # Patch subprocess.Popen.__init__
        try:
            wrapt.wrap_function_wrapper(
                "subprocess",
                "Popen.__init__",
                _popen_init_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch subprocess.Popen.__init__: %s", exc)

        # Patch os.system
        try:
            wrapt.wrap_function_wrapper(
                "os",
                "system",
                _os_system_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch os.system: %s", exc)

        if not patched:
            logger.debug("Could not find any subprocess/os methods to patch")
            return False

        self._instrumented = True
        logger.debug(
            "Subprocess instrumented (subprocess.run + Popen.__init__ + os.system)"
        )
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import subprocess
            import os

            for target, attr in [
                (subprocess, "run"),
                (os, "system"),
            ]:
                method = getattr(target, attr, None)
                if method is not None and hasattr(method, "__wrapped__"):
                    setattr(target, attr, method.__wrapped__)

            popen_init = getattr(subprocess.Popen, "__init__", None)
            if popen_init is not None and hasattr(popen_init, "__wrapped__"):
                subprocess.Popen.__init__ = popen_init.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Subprocess uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Command extraction helpers
# ---------------------------------------------------------------------------


def _extract_command(args, kwargs) -> str:
    """Extract the command string from subprocess/os arguments.

    Handles both list-form (["ls", "-la"]) and string-form ("ls -la").
    """
    cmd = None
    if args:
        cmd = args[0]
    cmd = kwargs.get("args", cmd)

    if cmd is None:
        return ""
    if isinstance(cmd, (list, tuple)):
        return " ".join(str(c) for c in cmd)
    return str(cmd)


def _extract_command_for_os_system(args, kwargs) -> str:
    """Extract command from os.system(command) arguments."""
    if args:
        return str(args[0])
    return kwargs.get("command", "")


def _extract_paths_from_command(command: str) -> list[str]:
    """Extract filesystem paths from a shell command."""
    import re

    paths = sorted(
        {m.group(1) for m in re.finditer(r"""(?:^|\s)(\/[^\s'"]+)""", command)}
    )
    # Also check for ~ paths
    paths.extend(
        sorted({m.group(1) for m in re.finditer(r"""(?:^|\s)(~[^\s'"]+)""", command)})
    )
    return paths


# ---------------------------------------------------------------------------
# Pre-execution governance
# ---------------------------------------------------------------------------


def _pre_execution_governance(command: str) -> None:
    """Record code execution BEFORE command runs for governance pre-validation.

    If a code-execution policy blocks the command (e.g. blocked commands,
    blocked paths), PolicyViolationError propagates and the command never
    executes.
    """
    try:
        from ._context_var import _current_context
        from ..errors import PolicyViolationError

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            paths = _extract_paths_from_command(command)

            ctx.record_code_execution(
                language="shell",
                code=command,
                packages=[],
                paths=paths,
                _skip_otel=True,  # Caller already created the OTel span
            )
    except PolicyViolationError:
        raise  # Governance blocks must propagate — command must NOT run
    except Exception:
        pass  # Never break user's command for non-governance errors


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _subprocess_run_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``subprocess.run``.

    Records command execution BEFORE it runs (governance pre-validation),
    then executes, then records output/timing.  If governance blocks,
    the command never executes.
    """
    command = _extract_command(args, kwargs)

    # Only instrument inside a WaxellContext
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if not ctx or not ctx.run_id:
            return wrapped(*args, **kwargs)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        span = start_tool_span(tool_name="subprocess.run", tool_type="code_execution")
        span.set_attribute("waxell.subprocess.method", "run")
        span.set_attribute("waxell.subprocess.command_preview", command[:200])
    except Exception:
        return wrapped(*args, **kwargs)

    # Pre-execution governance — PolicyViolationError propagates
    _pre_execution_governance(command)

    import time as _time

    start = _time.monotonic()

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        elapsed = _time.monotonic() - start

        stdout = ""
        stderr = ""
        returncode = getattr(result, "returncode", None)

        try:
            if hasattr(result, "stdout") and result.stdout:
                if isinstance(result.stdout, bytes):
                    stdout = result.stdout.decode("utf-8", errors="replace")[:500]
                else:
                    stdout = str(result.stdout)[:500]
            if hasattr(result, "stderr") and result.stderr:
                if isinstance(result.stderr, bytes):
                    stderr = result.stderr.decode("utf-8", errors="replace")[:500]
                else:
                    stderr = str(result.stderr)[:500]
        except Exception:
            pass

        try:
            if stdout:
                span.set_attribute("waxell.subprocess.stdout_preview", stdout)
            if stderr:
                span.set_attribute("waxell.subprocess.stderr_preview", stderr)
            if returncode is not None:
                span.set_attribute("waxell.subprocess.returncode", returncode)
        except Exception:
            pass

        try:
            _record_execution_result(
                command=command,
                stdout=stdout,
                stderr=stderr,
                returncode=returncode,
                elapsed=elapsed,
            )
        except Exception:
            pass

        return result
    finally:
        span.end()


def _popen_init_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``subprocess.Popen.__init__``.

    Records pre-execution governance. No output capture — Popen is
    long-lived and output is streamed.
    """
    command = _extract_command(args, kwargs)

    # Only instrument inside a WaxellContext
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if not ctx or not ctx.run_id:
            return wrapped(*args, **kwargs)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        span = start_tool_span(tool_name="subprocess.Popen", tool_type="code_execution")
        span.set_attribute("waxell.subprocess.method", "Popen")
        span.set_attribute("waxell.subprocess.command_preview", command[:200])
    except Exception:
        return wrapped(*args, **kwargs)

    # Pre-execution governance — PolicyViolationError propagates
    _pre_execution_governance(command)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    finally:
        span.end()

    return result


def _os_system_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``os.system``.

    Records pre-execution governance + return code.
    """
    command = _extract_command_for_os_system(args, kwargs)

    # Only instrument inside a WaxellContext
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if not ctx or not ctx.run_id:
            return wrapped(*args, **kwargs)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        span = start_tool_span(tool_name="os.system", tool_type="code_execution")
        span.set_attribute("waxell.subprocess.method", "os.system")
        span.set_attribute("waxell.subprocess.command_preview", command[:200])
    except Exception:
        return wrapped(*args, **kwargs)

    # Pre-execution governance — PolicyViolationError propagates
    _pre_execution_governance(command)

    import time as _time

    start = _time.monotonic()

    try:
        returncode = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        elapsed = _time.monotonic() - start

        try:
            span.set_attribute("waxell.subprocess.returncode", returncode)
        except Exception:
            pass

        try:
            _record_execution_result(
                command=command,
                stdout="",
                stderr="",
                returncode=returncode,
                elapsed=elapsed,
            )
        except Exception:
            pass

        return returncode
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Post-execution recording
# ---------------------------------------------------------------------------


def _record_execution_result(
    command: str,
    stdout: str,
    stderr: str,
    returncode: int | None,
    elapsed: float,
) -> None:
    """Record execution results to the HTTP path (context).

    Called AFTER command executes.  Records as a tool call for the trace tree.
    """
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        output_dict: dict = {}
        if stdout:
            output_dict["stdout_preview"] = stdout[:500]
        if stderr:
            output_dict["stderr_preview"] = stderr[:500]
        if returncode is not None:
            output_dict["returncode"] = returncode

        ctx.record_tool_call(
            name="subprocess.run",
            input={"command_preview": command[:200]},
            output=output_dict,
            tool_type="code_execution",
            status="error" if (returncode and returncode != 0) else "ok",
            duration_ms=int(elapsed * 1000),
            _skip_otel=True,  # Caller already has the OTel span
        )


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
