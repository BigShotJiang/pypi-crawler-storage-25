"""Base class and shared helpers for waxell-observe auto-instrumentors.

Defines the interface that all library-specific instrumentors must implement.
This module has NO OpenTelemetry imports at module level, so it can be
imported safely regardless of whether OTel is installed.
"""

from abc import ABC, abstractmethod


def extract_prompt_preview(messages: list, max_len: int = 500) -> str:
    """Return a prompt preview from an LLM messages array.

    Finds the **last user-role message** so the preview shows what the
    user actually asked — not the system prompt.  Falls back to the first
    message if no user message exists.
    """
    if not messages:
        return ""

    # Walk backwards to find the last user message
    for msg in reversed(messages):
        if isinstance(msg, dict):
            role = msg.get("role", "")
            content = msg.get("content", "")
        elif hasattr(msg, "role"):
            role = getattr(msg, "role", "")
            content = getattr(msg, "content", "")
        else:
            continue

        if role == "user":
            # Content may be a string or a list of content blocks
            if isinstance(content, list):
                # e.g. [{"type": "text", "text": "..."}, ...]
                parts = []
                for block in content:
                    if isinstance(block, dict):
                        parts.append(block.get("text", ""))
                    elif isinstance(block, str):
                        parts.append(block)
                content = " ".join(p for p in parts if p)
            return str(content)[:max_len]

    # No user message found — fall back to first message content
    first = messages[0]
    if isinstance(first, dict):
        content = first.get("content", "")
    elif hasattr(first, "content"):
        content = getattr(first, "content", "")
    else:
        content = str(first)

    if isinstance(content, list):
        parts = []
        for block in content:
            if isinstance(block, dict):
                parts.append(block.get("text", ""))
            elif isinstance(block, str):
                parts.append(block)
        content = " ".join(p for p in parts if p)

    return str(content)[:max_len]


def extract_prompt_hash(*candidates) -> str:
    """Recover the template ``content_hash`` from any call-site input.

    ``PromptInfo.compile()`` returns a ``CompiledPromptList`` (for chat)
    or ``CompiledPromptText`` (for text) that carries the source prompt
    version's hash on ``_waxell_template_hash``.  When these objects
    survive unmodified through the LLM SDK call, instrumentors can
    recover the hash and attach it to the recorded call, linking the
    LLM call back to the registered prompt version without requiring
    any manual code from the user.

    Pass any candidates the LLM SDK might have received — typically the
    ``messages=`` list (chat), the ``prompt=`` string (text), or the
    ``input=`` value (responses API).  Returns the first hash found,
    or an empty string.

    Detection order:
      1. The candidate itself has ``_waxell_template_hash`` (user passed
         ``messages=prompt.compile(...)`` directly).
      2. The candidate is a messages list, and one of the message
         ``content`` values is a ``CompiledPromptText`` (user embedded
         a compiled text prompt inside a hand-built chat messages list).
         The *last* hash found wins — usually the user-role message
         with the main prompt, after any system prompts.
    """
    for candidate in candidates:
        if candidate is None:
            continue
        direct = getattr(candidate, "_waxell_template_hash", "")
        if direct:
            return direct

        # Only walk iterables of messages — not arbitrary strings, which
        # would iterate characters.
        if isinstance(candidate, (list, tuple)):
            found = ""
            for msg in candidate:
                if isinstance(msg, dict):
                    content = msg.get("content", "")
                elif hasattr(msg, "content"):
                    content = getattr(msg, "content", "")
                else:
                    continue
                # String content — check for subclass with hash
                direct = getattr(content, "_waxell_template_hash", "")
                if direct:
                    found = direct
                    continue
                # List of content blocks — walk them too
                if isinstance(content, list):
                    for block in content:
                        if isinstance(block, dict):
                            text = block.get("text", "")
                        else:
                            text = block
                        block_hash = getattr(text, "_waxell_template_hash", "")
                        if block_hash:
                            found = block_hash
            if found:
                return found
    return ""


class BaseInstrumentor(ABC):
    """Abstract base class for library-specific instrumentors.

    Subclasses implement monkey-patching logic to intercept LLM SDK
    calls and emit spans/metrics.

    Each subclass maintains its own ``_instrumented`` guard to prevent
    double-patching.
    """

    _instrumented: bool = False

    @abstractmethod
    def instrument(self) -> bool:
        """Apply monkey-patches to the target library.

        Returns True if instrumentation was applied successfully,
        False if skipped (e.g. library not importable, already
        instrumented).
        """
        ...

    @abstractmethod
    def uninstrument(self) -> None:
        """Restore original (unpatched) methods on the target library."""
        ...

    @abstractmethod
    def is_instrumented(self) -> bool:
        """Return True if this instrumentor is currently active."""
        ...
