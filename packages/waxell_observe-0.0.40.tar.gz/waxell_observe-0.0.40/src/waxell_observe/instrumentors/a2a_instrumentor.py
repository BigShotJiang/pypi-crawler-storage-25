"""Google A2A (Agent-to-Agent) protocol auto-instrumentor for waxell-observe.

Monkey-patches the A2A SDK client to emit agent communication and tool
dispatch spans when agents exchange messages and tasks via the A2A protocol.

Supports both A2A SDK v0.3 and v1.0:
  - v0.3: A2AClient with send_message / send_task / get_task
  - v1.0: BaseClient via ClientFactory.connect() with send_message /
           send_message_streaming / get_task / cancel_task

A2A protocol patterns:
  - Agent sends messages to other agents
  - Tasks are created and dispatched between agents
  - Task status is polled until completion
  - Artifacts are produced as task outputs

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import json
import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class A2AInstrumentor(BaseInstrumentor):
    """Instrumentor for Google A2A (Agent-to-Agent) protocol.

    Attempts to import from ``a2a`` or ``a2a_sdk`` and patches
    message sending, task creation, and task status polling.

    Supports both v0.3 (A2AClient) and v1.0 (BaseClient / ClientFactory).
    """

    _instrumented: bool = False
    _module_name: str = ""  # Tracks which module was found

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        # Try to find the A2A module
        a2a_mod = None
        for mod_name in ("a2a", "a2a_sdk"):
            try:
                a2a_mod = __import__(mod_name)
                self._module_name = mod_name
                break
            except ImportError:
                continue

        if a2a_mod is None:
            logger.debug(
                "Neither a2a nor a2a_sdk package installed -- skipping instrumentation"
            )
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping A2A instrumentation")
            return False

        patched = False

        # ── v0.3 API: A2AClient ──────────────────────────────────────
        # Patch client send_message
        try:
            wrapt.wrap_function_wrapper(
                self._module_name,
                "A2AClient.send_message",
                _send_message_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug(
                "Could not patch %s.A2AClient.send_message: %s", self._module_name, exc
            )

        # Patch async send_message
        try:
            wrapt.wrap_function_wrapper(
                self._module_name,
                "A2AClient.send_message_async",
                _async_send_message_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug(
                "Could not patch %s.A2AClient.send_message_async: %s",
                self._module_name,
                exc,
            )

        # Patch send_task / create_task
        for method_name in ("send_task", "create_task"):
            try:
                wrapt.wrap_function_wrapper(
                    self._module_name,
                    f"A2AClient.{method_name}",
                    _send_task_wrapper,
                )
                patched = True
            except Exception as exc:
                logger.debug(
                    "Could not patch %s.A2AClient.%s: %s",
                    self._module_name,
                    method_name,
                    exc,
                )

        # Patch async send_task / create_task
        for method_name in ("send_task_async", "create_task_async"):
            try:
                wrapt.wrap_function_wrapper(
                    self._module_name,
                    f"A2AClient.{method_name}",
                    _async_send_task_wrapper,
                )
                patched = True
            except Exception as exc:
                logger.debug(
                    "Could not patch %s.A2AClient.%s: %s",
                    self._module_name,
                    method_name,
                    exc,
                )

        # Patch get_task / get_task_status
        for method_name in ("get_task", "get_task_status"):
            try:
                wrapt.wrap_function_wrapper(
                    self._module_name,
                    f"A2AClient.{method_name}",
                    _get_task_wrapper,
                )
                patched = True
            except Exception as exc:
                logger.debug(
                    "Could not patch %s.A2AClient.%s: %s",
                    self._module_name,
                    method_name,
                    exc,
                )

        # Patch async get_task / get_task_status
        for method_name in ("get_task_async", "get_task_status_async"):
            try:
                wrapt.wrap_function_wrapper(
                    self._module_name,
                    f"A2AClient.{method_name}",
                    _async_get_task_wrapper,
                )
                patched = True
            except Exception as exc:
                logger.debug(
                    "Could not patch %s.A2AClient.%s: %s",
                    self._module_name,
                    method_name,
                    exc,
                )

        # ── v1.0 API: BaseClient (via ClientFactory.connect) ─────────
        # The v1.0 SDK restructured the client classes. BaseClient is in
        # a2a.client.base_client and exposes send_message,
        # send_message_streaming, get_task, cancel_task.
        for client_mod_path in (
            f"{self._module_name}.client.base_client",
            f"{self._module_name}.client",
        ):
            # send_message (v1.0)
            try:
                wrapt.wrap_function_wrapper(
                    client_mod_path,
                    "BaseClient.send_message",
                    _async_send_message_wrapper,
                )
                patched = True
                logger.debug(
                    "A2A v1.0: patched %s.BaseClient.send_message", client_mod_path
                )
            except Exception:
                pass

            # send_message_streaming (v1.0)
            try:
                wrapt.wrap_function_wrapper(
                    client_mod_path,
                    "BaseClient.send_message_streaming",
                    _async_send_message_wrapper,
                )
                patched = True
                logger.debug(
                    "A2A v1.0: patched %s.BaseClient.send_message_streaming",
                    client_mod_path,
                )
            except Exception:
                pass

            # get_task (v1.0)
            try:
                wrapt.wrap_function_wrapper(
                    client_mod_path,
                    "BaseClient.get_task",
                    _async_get_task_wrapper,
                )
                patched = True
                logger.debug(
                    "A2A v1.0: patched %s.BaseClient.get_task", client_mod_path
                )
            except Exception:
                pass

            # cancel_task (v1.0)
            try:
                wrapt.wrap_function_wrapper(
                    client_mod_path,
                    "BaseClient.cancel_task",
                    _async_cancel_task_wrapper,
                )
                patched = True
                logger.debug(
                    "A2A v1.0: patched %s.BaseClient.cancel_task", client_mod_path
                )
            except Exception:
                pass

            # list_tasks (v1.0)
            try:
                wrapt.wrap_function_wrapper(
                    client_mod_path,
                    "BaseClient.list_tasks",
                    _async_get_task_wrapper,
                )
                patched = True
            except Exception:
                pass

        # ── v1.0: ClientFactory.connect ──────────────────────────────
        # Wrapping connect() lets us capture the agent card URL.
        try:
            wrapt.wrap_function_wrapper(
                f"{self._module_name}.client.client_factory",
                "ClientFactory.connect",
                _client_factory_connect_wrapper,
            )
            logger.debug("A2A v1.0: patched ClientFactory.connect")
        except Exception:
            pass

        if not patched:
            logger.debug("Could not find any A2A client methods to patch")
            return False

        self._instrumented = True
        logger.debug("A2A protocol instrumented (%s)", self._module_name)
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        if not self._module_name:
            self._instrumented = False
            return

        # Restore v0.3 A2AClient
        try:
            mod = __import__(self._module_name)
            client_cls = getattr(mod, "A2AClient", None)
            if client_cls:
                for attr in (
                    "send_message",
                    "send_message_async",
                    "send_task",
                    "send_task_async",
                    "create_task",
                    "create_task_async",
                    "get_task",
                    "get_task_async",
                    "get_task_status",
                    "get_task_status_async",
                ):
                    method = getattr(client_cls, attr, None)
                    if method is not None and hasattr(method, "__wrapped__"):
                        setattr(client_cls, attr, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        # Restore v1.0 BaseClient
        for client_mod_path in (
            f"{self._module_name}.client.base_client",
            f"{self._module_name}.client",
        ):
            try:
                import importlib

                cmod = importlib.import_module(client_mod_path)
                base_cls = getattr(cmod, "BaseClient", None)
                if base_cls:
                    for attr in (
                        "send_message",
                        "send_message_streaming",
                        "get_task",
                        "cancel_task",
                        "list_tasks",
                    ):
                        method = getattr(base_cls, attr, None)
                        if method and hasattr(method, "__wrapped__"):
                            setattr(base_cls, attr, method.__wrapped__)
            except (ImportError, AttributeError):
                pass

        # Restore ClientFactory
        try:
            import importlib

            cfmod = importlib.import_module(
                f"{self._module_name}.client.client_factory"
            )
            cf_cls = getattr(cfmod, "ClientFactory", None)
            if cf_cls:
                connect = getattr(cf_cls, "connect", None)
                if connect and hasattr(connect, "__wrapped__"):
                    setattr(cf_cls, "connect", connect.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("A2A protocol uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers for extracting A2A metadata
# ---------------------------------------------------------------------------


def _extract_agent_info(instance) -> tuple[str, str]:
    """Extract sender and receiver agent identifiers.

    Returns (sender_agent, receiver_agent).
    Works with both v0.3 (A2AClient) and v1.0 (BaseClient) instances.
    """
    sender = ""
    receiver = ""

    try:
        sender = (
            str(getattr(instance, "agent_name", ""))
            or str(getattr(instance, "name", ""))
            # v1.0: BaseClient may have agent_card with name
            or str(getattr(getattr(instance, "agent_card", None), "name", ""))
        )
    except Exception:
        pass

    try:
        receiver = (
            str(getattr(instance, "target_agent", ""))
            or str(getattr(instance, "url", ""))
            # v1.0: BaseClient stores the base_url
            or str(getattr(instance, "base_url", ""))
            or str(getattr(instance, "_base_url", ""))
        )
    except Exception:
        pass

    return sender or "unknown-sender", receiver or "unknown-receiver"


def _extract_message_info(args, kwargs) -> dict:
    """Extract message metadata from send_message arguments."""
    info = {}

    # Try to get message from kwargs or first arg
    message = kwargs.get("message") or kwargs.get("request")
    if message is None and args:
        message = args[0]

    if message is not None:
        try:
            info["message_type"] = type(message).__name__

            # Extract task_id if present
            task_id = getattr(message, "task_id", None) or getattr(message, "id", None)
            if task_id:
                info["task_id"] = str(task_id)

            # Extract message content preview
            content = getattr(message, "content", None) or getattr(
                message, "text", None
            )
            if content:
                info["content_preview"] = str(content)[:500]

            # Extract message type/role
            msg_type = getattr(message, "type", None) or getattr(message, "role", None)
            if msg_type:
                info["message_type"] = str(msg_type)
        except Exception:
            pass

    return info


def _extract_task_info(args, kwargs) -> dict:
    """Extract task metadata from task-related arguments.

    Handles both v0.3 and v1.0 status enum formats:
      v0.3: "completed", "working", "failed"
      v1.0: "TASK_STATE_COMPLETED", "TASK_STATE_WORKING", "TASK_STATE_FAILED"
    """
    info = {}

    task = kwargs.get("task") or kwargs.get("request")
    if task is None and args:
        task = args[0]

    if task is not None:
        try:
            task_id = (
                getattr(task, "task_id", None)
                or getattr(task, "id", None)
                # v1.0: context_id replaces task_id in some flows
                or getattr(task, "context_id", None)
            )
            if task_id:
                info["task_id"] = str(task_id)

            status = getattr(task, "status", None)
            if status:
                # Normalize v1.0 SCREAMING_SNAKE_CASE to readable form
                status_str = _normalize_status(status)
                info["status"] = status_str

            artifacts = getattr(task, "artifacts", None)
            if artifacts:
                info["artifact_count"] = len(artifacts)

            # v1.0: history (list of messages in the task)
            history = getattr(task, "history", None)
            if history and hasattr(history, "__len__"):
                info["history_length"] = len(history)
        except Exception:
            pass

    # Also check for task_id directly in kwargs
    if "task_id" in kwargs:
        info["task_id"] = str(kwargs["task_id"])

    return info


def _normalize_status(status) -> str:
    """Normalize A2A task status to a consistent format.

    v0.3 used lowercase ("completed"), v1.0 uses SCREAMING_SNAKE_CASE
    with type prefix ("TASK_STATE_COMPLETED"). We normalize to lowercase
    without the prefix for consistent span attributes.
    """
    status_str = str(status)

    # Handle enum objects (both v0.3 and v1.0)
    if hasattr(status, "value"):
        status_str = str(status.value)
    elif hasattr(status, "name"):
        status_str = str(status.name)

    # Strip v1.0 prefix (TASK_STATE_COMPLETED -> COMPLETED -> completed)
    if status_str.startswith("TASK_STATE_"):
        status_str = status_str[len("TASK_STATE_") :]

    return status_str.lower()


# ---------------------------------------------------------------------------
# Message wrapper functions
# ---------------------------------------------------------------------------


def _send_message_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``A2AClient.send_message``."""
    try:
        from ..tracing.spans import start_agent_span
    except Exception:
        return wrapped(*args, **kwargs)

    sender, receiver = _extract_agent_info(instance)
    msg_info = _extract_message_info(args, kwargs)

    try:
        span = start_agent_span(
            agent_name=f"a2a:{sender}",
            workflow_name="a2a.send_message",
        )
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.a2a.sender_agent", sender)
            span.set_attribute("waxell.a2a.receiver_agent", receiver)
            span.set_attribute("waxell.a2a.operation", "send_message")

            if "message_type" in msg_info:
                span.set_attribute("waxell.a2a.message_type", msg_info["message_type"])
            if "task_id" in msg_info:
                span.set_attribute("waxell.a2a.task_id", msg_info["task_id"])
            if "content_preview" in msg_info:
                span.set_attribute(
                    "waxell.a2a.content_preview", msg_info["content_preview"]
                )
        except Exception:
            pass

        try:
            _record_http_a2a(sender, receiver, "send_message", msg_info)
        except Exception:
            pass

        return result
    finally:
        span.end()


async def _async_send_message_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``A2AClient.send_message_async``."""
    try:
        from ..tracing.spans import start_agent_span
    except Exception:
        return await wrapped(*args, **kwargs)

    sender, receiver = _extract_agent_info(instance)
    msg_info = _extract_message_info(args, kwargs)

    try:
        span = start_agent_span(
            agent_name=f"a2a:{sender}",
            workflow_name="a2a.send_message",
        )
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.a2a.sender_agent", sender)
            span.set_attribute("waxell.a2a.receiver_agent", receiver)
            span.set_attribute("waxell.a2a.operation", "send_message")

            if "message_type" in msg_info:
                span.set_attribute("waxell.a2a.message_type", msg_info["message_type"])
            if "task_id" in msg_info:
                span.set_attribute("waxell.a2a.task_id", msg_info["task_id"])
            if "content_preview" in msg_info:
                span.set_attribute(
                    "waxell.a2a.content_preview", msg_info["content_preview"]
                )
        except Exception:
            pass

        try:
            _record_http_a2a(sender, receiver, "send_message", msg_info)
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Task dispatch wrapper functions
# ---------------------------------------------------------------------------


def _send_task_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``A2AClient.send_task`` / ``create_task``."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    sender, receiver = _extract_agent_info(instance)
    task_info = _extract_task_info(args, kwargs)
    task_id = task_info.get("task_id", "unknown")

    try:
        span = start_tool_span(tool_name=f"a2a.task:{task_id}", tool_type="a2a")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            # Update task_id from result if available
            result_task_id = getattr(result, "task_id", None) or getattr(
                result, "id", None
            )
            if result_task_id:
                task_info["task_id"] = str(result_task_id)

            result_status = getattr(result, "status", None)
            if result_status:
                task_info["status"] = str(result_status)

            span.set_attribute("waxell.a2a.sender_agent", sender)
            span.set_attribute("waxell.a2a.receiver_agent", receiver)
            span.set_attribute("waxell.a2a.operation", "send_task")
            span.set_attribute("waxell.a2a.task_id", task_info.get("task_id", ""))

            if "status" in task_info:
                span.set_attribute("waxell.a2a.task_status", task_info["status"])
            if "artifact_count" in task_info:
                span.set_attribute(
                    "waxell.a2a.artifact_count", task_info["artifact_count"]
                )
        except Exception:
            pass

        try:
            _record_http_a2a(sender, receiver, "send_task", task_info)
        except Exception:
            pass

        return result
    finally:
        span.end()


async def _async_send_task_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``A2AClient.send_task_async`` / ``create_task_async``."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return await wrapped(*args, **kwargs)

    sender, receiver = _extract_agent_info(instance)
    task_info = _extract_task_info(args, kwargs)
    task_id = task_info.get("task_id", "unknown")

    try:
        span = start_tool_span(tool_name=f"a2a.task:{task_id}", tool_type="a2a")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            result_task_id = getattr(result, "task_id", None) or getattr(
                result, "id", None
            )
            if result_task_id:
                task_info["task_id"] = str(result_task_id)

            result_status = getattr(result, "status", None)
            if result_status:
                task_info["status"] = str(result_status)

            span.set_attribute("waxell.a2a.sender_agent", sender)
            span.set_attribute("waxell.a2a.receiver_agent", receiver)
            span.set_attribute("waxell.a2a.operation", "send_task")
            span.set_attribute("waxell.a2a.task_id", task_info.get("task_id", ""))

            if "status" in task_info:
                span.set_attribute("waxell.a2a.task_status", task_info["status"])
            if "artifact_count" in task_info:
                span.set_attribute(
                    "waxell.a2a.artifact_count", task_info["artifact_count"]
                )
        except Exception:
            pass

        try:
            _record_http_a2a(sender, receiver, "send_task", task_info)
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Task status wrapper functions
# ---------------------------------------------------------------------------


def _get_task_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``A2AClient.get_task`` / ``get_task_status``."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    task_info = _extract_task_info(args, kwargs)
    task_id = task_info.get("task_id", kwargs.get("task_id", "unknown"))

    try:
        span = start_tool_span(tool_name=f"a2a.poll:{task_id}", tool_type="a2a")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            status = getattr(result, "status", None)
            artifacts = getattr(result, "artifacts", None)

            span.set_attribute("waxell.a2a.operation", "get_task")
            span.set_attribute("waxell.a2a.task_id", str(task_id))

            if status:
                span.set_attribute("waxell.a2a.task_status", str(status))
            if artifacts:
                span.set_attribute("waxell.a2a.artifact_count", len(artifacts))
        except Exception:
            pass

        return result
    finally:
        span.end()


async def _async_get_task_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``A2AClient.get_task_async`` / ``get_task_status_async``."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return await wrapped(*args, **kwargs)

    task_info = _extract_task_info(args, kwargs)
    task_id = task_info.get("task_id", kwargs.get("task_id", "unknown"))

    try:
        span = start_tool_span(tool_name=f"a2a.poll:{task_id}", tool_type="a2a")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            status = getattr(result, "status", None)
            artifacts = getattr(result, "artifacts", None)

            span.set_attribute("waxell.a2a.operation", "get_task")
            span.set_attribute("waxell.a2a.task_id", str(task_id))

            if status:
                span.set_attribute("waxell.a2a.task_status", str(status))
            if artifacts:
                span.set_attribute("waxell.a2a.artifact_count", len(artifacts))
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_http_a2a(sender: str, receiver: str, operation: str, info: dict) -> None:
    """Record an A2A call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector

    call_data = {
        "model": f"a2a:{receiver}",
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": f"a2a.{operation}",
        "prompt_preview": f"sender={sender}, receiver={receiver}",
        "response_preview": json.dumps(info)[:500] if info else "",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# v1.0 cancel_task wrapper
# ---------------------------------------------------------------------------


async def _async_cancel_task_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``BaseClient.cancel_task`` (v1.0)."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return await wrapped(*args, **kwargs)

    task_info = _extract_task_info(args, kwargs)
    task_id = task_info.get("task_id", kwargs.get("task_id", "unknown"))

    try:
        span = start_tool_span(tool_name=f"a2a.cancel:{task_id}", tool_type="a2a")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.a2a.operation", "cancel_task")
            span.set_attribute("waxell.a2a.task_id", str(task_id))

            status = getattr(result, "status", None)
            if status:
                span.set_attribute("waxell.a2a.task_status", _normalize_status(status))
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# v1.0 ClientFactory.connect wrapper
# ---------------------------------------------------------------------------


async def _client_factory_connect_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``ClientFactory.connect`` (v1.0).

    Captures agent card resolution as an agent discovery span.
    """
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return await wrapped(*args, **kwargs)

    # Extract agent card URL from args
    agent_url = ""
    if args:
        agent_url = str(args[0])
    elif "url" in kwargs:
        agent_url = str(kwargs["url"])

    try:
        span = start_tool_span(
            tool_name=f"a2a.discover:{agent_url[:80]}", tool_type="a2a"
        )
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.a2a.operation", "discover")
            span.set_attribute("waxell.a2a.agent_url", agent_url)

            # Try to extract agent card info from the result
            agent_card = getattr(result, "agent_card", None)
            if agent_card:
                card_name = getattr(agent_card, "name", None)
                if card_name:
                    span.set_attribute("waxell.a2a.discovered_agent", str(card_name))

                skills = getattr(agent_card, "skills", None)
                if skills and hasattr(skills, "__len__"):
                    span.set_attribute("waxell.a2a.skill_count", len(skills))
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
