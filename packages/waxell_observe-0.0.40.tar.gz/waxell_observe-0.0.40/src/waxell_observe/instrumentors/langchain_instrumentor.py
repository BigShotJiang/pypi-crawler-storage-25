"""LangChain auto-instrumentor for waxell-observe.

Registers a WaxellCallbackHandler with LangChain's callback system to
instrument ALL sub-components: chains, agents, tools, retrievers, LLMs,
embeddings, LangGraph nodes, document loaders, and more.

Covers:
  - ChatModel / LLM calls (on_llm_start / on_llm_end / on_chat_model_start)
  - Chain execution (on_chain_start / on_chain_end) -- all chain types
  - Tool execution (on_tool_start / on_tool_end)
  - Retriever operations (on_retriever_start / on_retriever_end)
  - Agent actions (on_agent_action / on_agent_finish)
  - Errors (on_llm_error, on_chain_error, on_tool_error, on_retriever_error)

All callback code is wrapped in try/except -- never breaks the user's
LangChain calls.
"""

from __future__ import annotations

import logging
import threading
from typing import Any, Dict, List, Optional
from uuid import UUID

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


def _swallow(exc: BaseException, where: str) -> None:
    """Re-raise governance violations, log everything else.

    Every callback in this file uses ``except Exception as exc:`` so a
    bug in the instrumentor doesn't break the user's LangChain run. The
    historical bare-except, though, also silently ate ``PolicyViolationError``
    raised mid-execution from ``record_llm_call`` / ``record_tool_call`` —
    which meant a 'block' decision from the controlplane never killed the
    agent. Mid-run token-limit blocks would fire, the agent would keep
    burning tokens, and the brief would still come back.

    This helper restores the contract: governance violations propagate up
    so the surrounding ``with WaxellContext(...) as ctx:`` catches them
    and stops the run. Other exceptions stay buried as before so the
    instrumentor can't crash the user's app.
    """
    from ..errors import PolicyViolationError

    if isinstance(exc, PolicyViolationError):
        raise exc
    logger.debug("%s callback failed: %s", where, exc)


# ---------------------------------------------------------------------------
# WaxellCallbackHandler -- installed into LangChain's callback system
# ---------------------------------------------------------------------------


class WaxellCallbackHandler:
    """LangChain callback handler that emits OTel spans and HTTP records.

    Implements the same interface as ``langchain_core.callbacks.BaseCallbackHandler``
    but does NOT inherit from it at class-definition time. The inheritance is
    set up dynamically inside ``LangChainInstrumentor.instrument()`` so that
    ``langchain_core`` is only imported when the user actually has it installed.

    This handler is designed to be injected into every ``CallbackManager`` via
    a monkey-patch on ``CallbackManager.__init__``.

    Thread safety
    -------------
    LangChain may fire callbacks from multiple threads (e.g. parallel chains,
    async-to-thread bridges). We store open spans in a ``threading.local()``
    dict keyed by ``run_id`` so concurrent runs never collide.

    Error resilience
    ----------------
    Every callback method body is wrapped in ``try / except Exception``.
    ``raise_error`` is ``False`` so LangChain will never propagate our errors
    to the user's application.
    """

    # Tell LangChain not to propagate errors from this handler.
    raise_error: bool = False
    # Tell LangChain not to ignore this handler on retries.
    run_inline: bool = False
    # LangChain checks these attributes on callback handlers.
    ignore_llm: bool = False
    ignore_retry: bool = False
    ignore_chain: bool = False
    ignore_agent: bool = False
    ignore_retriever: bool = False
    ignore_chat_model: bool = False
    ignore_custom_event: bool = False

    def __init__(self) -> None:
        self._local = threading.local()

    # -- Span storage helpers -----------------------------------------------

    def _spans(self) -> dict:
        """Return the per-thread span dict, creating it lazily."""
        if not hasattr(self._local, "spans"):
            self._local.spans = {}
        return self._local.spans

    def _put_span(self, run_id: UUID, span: Any) -> None:
        # Tag every span this instrumentor creates with the LangChain
        # framework attribute. The controlplane integrations panel reads
        # `waxell.framework` to count framework usage; without this, the
        # panel never sees Langchain because individual LLM/tool spans
        # use the underlying provider name (openai, watsonx, etc.) and
        # the framework row drops out as a 0-span entry.
        try:
            span.set_attribute("waxell.framework", "langchain")
        except Exception:
            pass
        self._spans()[run_id] = span

    def _pop_span(self, run_id: UUID) -> Any:
        return self._spans().pop(run_id, None)

    # -- Model name extraction helpers --------------------------------------

    @staticmethod
    def _extract_model(serialized: Dict[str, Any]) -> str:
        """Best-effort extraction of the model name from the serialized dict.

        LangChain provides different shapes depending on the component:
        - ``serialized["kwargs"]["model_name"]`` (ChatOpenAI, etc.)
        - ``serialized["kwargs"]["model"]`` (ChatAnthropic, etc.)
        - ``serialized["id"][-1]`` (class name fallback)
        - ``serialized.get("name")``
        """
        kwargs = serialized.get("kwargs", {})
        model = (
            kwargs.get("model_name")
            or kwargs.get("model")
            or kwargs.get("model_id")
            or ""
        )
        if model:
            return str(model)

        # Fall back to the class name from the serialized id path
        id_path = serialized.get("id", [])
        if id_path:
            return str(id_path[-1])

        return serialized.get("name", "unknown")

    @staticmethod
    def _extract_chain_name(serialized: Dict[str, Any]) -> str:
        """Extract a human-readable chain/component name."""
        name = serialized.get("name", "")
        if name:
            return str(name)
        id_path = serialized.get("id", [])
        if id_path:
            return str(id_path[-1])
        return "unknown"

    # ======================================================================
    # LLM callbacks
    # ======================================================================

    def on_llm_start(
        self,
        serialized: Dict[str, Any],
        prompts: List[str],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        """Called when an LLM (non-chat) starts generating."""
        try:
            from ..tracing.spans import start_llm_span

            model = self._extract_model(serialized)
            span = start_llm_span(model=model, provider_name="langchain")

            # Attach metadata as span attributes
            if tags:
                span.set_attribute("waxell.langchain.tags", tags)
            if parent_run_id:
                span.set_attribute("waxell.langchain.parent_run_id", str(parent_run_id))

            self._put_span(run_id, span)

            # Stash model name so on_llm_end can retrieve it
            if not hasattr(self._local, "models"):
                self._local.models = {}
            self._local.models[run_id] = model
        except Exception as exc:
            _swallow(exc, "on_llm_start")

    def on_chat_model_start(
        self,
        serialized: Dict[str, Any],
        messages: List[Any],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        """Called when a chat model starts (ChatOpenAI, ChatAnthropic, etc.)."""
        try:
            from ..tracing.spans import start_llm_span

            model = self._extract_model(serialized)
            span = start_llm_span(model=model, provider_name="langchain")

            if tags:
                span.set_attribute("waxell.langchain.tags", tags)
            if parent_run_id:
                span.set_attribute("waxell.langchain.parent_run_id", str(parent_run_id))

            # Store the model name alongside the span so on_llm_end can use it
            self._put_span(run_id, span)
            # Stash model name in a parallel dict for on_llm_end
            if not hasattr(self._local, "models"):
                self._local.models = {}
            self._local.models[run_id] = model
        except Exception as exc:
            _swallow(exc, "on_chat_model_start")

    def on_llm_end(
        self,
        response: Any,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        """Called when an LLM/ChatModel finishes successfully."""
        try:
            from ..tracing.attributes import GenAIAttributes, WaxellAttributes
            from ..cost import estimate_cost

            span = self._pop_span(run_id)
            if span is None:
                return

            # Retrieve stashed model name
            models = getattr(self._local, "models", {})
            model = models.pop(run_id, "unknown")

            # Extract token usage from response.llm_output
            tokens_in = 0
            tokens_out = 0
            response_model = model

            llm_output = getattr(response, "llm_output", None) or {}
            if isinstance(llm_output, dict):
                token_usage = llm_output.get("token_usage", {})
                if isinstance(token_usage, dict):
                    tokens_in = int(token_usage.get("prompt_tokens", 0))
                    tokens_out = int(token_usage.get("completion_tokens", 0))

                # Some providers put model_name in llm_output
                response_model = llm_output.get("model_name", model) or model

            cost = estimate_cost(response_model, tokens_in, tokens_out)

            # Set span attributes
            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, response_model)
            span.set_attribute(WaxellAttributes.LLM_MODEL, response_model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(
                WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out
            )
            span.set_attribute(WaxellAttributes.LLM_COST, cost)

            span.end()

            # HTTP dual-path recording. Skip if an upstream provider
            # instrumentor (e.g. the watsonx chat wrapper) already recorded
            # this exact call — otherwise we get duplicate rows in the
            # llm-calls table and inflated token totals that trip budget
            # policies at half the real usage.
            from ._http_dedup import consume

            if not consume():
                _record_http_llm(response, response_model, tokens_in, tokens_out, cost)
        except Exception as exc:
            _swallow(exc, "on_llm_end")

    def on_llm_new_token(
        self,
        token: str,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        """Called for each new token in streaming mode. No-op for telemetry."""
        pass

    def on_llm_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        """Called when an LLM call raises an error."""
        try:
            span = self._pop_span(run_id)
            # Also clean up stashed model
            models = getattr(self._local, "models", {})
            models.pop(run_id, None)

            if span is not None:
                _record_error(span, error)
                span.end()
        except Exception as exc:
            _swallow(exc, "on_llm_error")

    # ======================================================================
    # Chain callbacks
    # ======================================================================

    def on_chain_start(
        self,
        serialized: Dict[str, Any],
        inputs: Dict[str, Any],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        """Called when a chain starts running (any chain type, LangGraph node, etc.)."""
        try:
            from ..tracing.spans import start_step_span

            chain_name = self._extract_chain_name(serialized)
            span = start_step_span(step_name=f"langchain.chain.{chain_name}")

            if tags:
                span.set_attribute("waxell.langchain.tags", tags)
            if parent_run_id:
                span.set_attribute("waxell.langchain.parent_run_id", str(parent_run_id))

            self._put_span(run_id, span)
        except Exception as exc:
            _swallow(exc, "on_chain_start")

    def on_chain_end(
        self,
        outputs: Dict[str, Any],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        """Called when a chain finishes successfully."""
        try:
            span = self._pop_span(run_id)
            if span is not None:
                span.end()
        except Exception as exc:
            _swallow(exc, "on_chain_end")

    def on_chain_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        """Called when a chain raises an error."""
        try:
            span = self._pop_span(run_id)
            if span is not None:
                _record_error(span, error)
                span.end()
        except Exception as exc:
            _swallow(exc, "on_chain_error")

    # ======================================================================
    # Tool callbacks
    # ======================================================================

    def on_tool_start(
        self,
        serialized: Dict[str, Any],
        input_str: str,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        """Called when a tool starts executing.

        Performs a pre-execution governance check — if the tool is blocked by
        policy, raises ``PolicyViolationError`` so the tool never runs.

        Does NOT create an OTel span here — ``on_tool_end`` records the tool
        via ``ctx.record_tool_call()`` which creates a single span covering
        both OTel and HTTP paths. This avoids duplicate tool spans in the
        trace UI.
        """
        try:
            import time

            tool_name = serialized.get("name", "unknown")

            # Stash metadata for on_tool_end — no OTel span created here
            if not hasattr(self._local, "tool_meta"):
                self._local.tool_meta = {}
            self._local.tool_meta[run_id] = {
                "name": tool_name,
                "input": input_str,
                "start_time": time.perf_counter(),
                "tags": tags,
            }

            # Pre-execution governance check — blocks BEFORE the tool runs
            from ._context_var import _current_context

            ctx = _current_context.get()
            if ctx is not None:
                ctx.check_tool_before_execution(tool_name)

        except Exception as exc:
            _swallow(exc, "on_tool_start")

    def on_tool_end(
        self,
        output: Any,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        """Called when a tool finishes successfully."""
        try:
            import time

            tool_meta = getattr(self._local, "tool_meta", {})
            meta = tool_meta.pop(run_id, None)
            if meta is None:
                return

            duration_ms = int((time.perf_counter() - meta["start_time"]) * 1000)

            # Single recording path: ctx.record_tool_call() handles both
            # the HTTP step buffer AND creates the OTel span.
            _record_http_tool(
                tool_name=meta["name"],
                tool_input=meta.get("input", ""),
                tool_output=output,
                status="ok",
                duration_ms=duration_ms,
            )
        except Exception as exc:
            _swallow(exc, "on_tool_end")

    def on_tool_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        """Called when a tool raises an error."""
        try:
            import time

            tool_meta = getattr(self._local, "tool_meta", {})
            meta = tool_meta.pop(run_id, None)
            if meta is None:
                return

            duration_ms = int((time.perf_counter() - meta["start_time"]) * 1000)

            _record_http_tool(
                tool_name=meta["name"],
                tool_input=meta.get("input", ""),
                tool_output=None,
                status="error",
                error=str(error),
                duration_ms=duration_ms,
            )
        except Exception as exc:
            _swallow(exc, "on_tool_error")

    # ======================================================================
    # Retriever callbacks
    # ======================================================================

    def on_retriever_start(
        self,
        serialized: Dict[str, Any],
        query: str,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        """Called when a retriever starts fetching documents."""
        try:
            from ..tracing.spans import start_retrieval_span

            retriever_name = self._extract_chain_name(serialized)
            span = start_retrieval_span(
                query=query[:500] if query else "",
                source=f"langchain.{retriever_name}",
            )

            if tags:
                span.set_attribute("waxell.langchain.tags", tags)

            self._put_span(run_id, span)
        except Exception as exc:
            _swallow(exc, "on_retriever_start")

    def on_retriever_end(
        self,
        documents: Any,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        """Called when a retriever finishes fetching documents."""
        try:
            span = self._pop_span(run_id)
            if span is not None:
                doc_count = len(documents) if documents else 0
                span.set_attribute("waxell.retrieval.results_count", doc_count)
                span.end()
        except Exception as exc:
            _swallow(exc, "on_retriever_end")

    def on_retriever_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        """Called when a retriever raises an error."""
        try:
            span = self._pop_span(run_id)
            if span is not None:
                _record_error(span, error)
                span.end()
        except Exception as exc:
            _swallow(exc, "on_retriever_error")

    # ======================================================================
    # Agent callbacks
    # ======================================================================

    def on_agent_action(
        self,
        action: Any,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> None:
        """Called when an agent selects an action (tool invocation).

        ``action`` is a ``langchain_core.agents.AgentAction`` with ``.tool``
        and ``.tool_input`` attributes.
        """
        try:
            from ..tracing.spans import start_step_span

            tool_name = getattr(action, "tool", "unknown")
            span = start_step_span(step_name=f"langchain.agent_action.{tool_name}")

            tool_input = getattr(action, "tool_input", None)
            if tool_input is not None:
                span.set_attribute(
                    "waxell.langchain.agent_action.input",
                    str(tool_input)[:500],
                )
            log_text = getattr(action, "log", None)
            if log_text:
                span.set_attribute(
                    "waxell.langchain.agent_action.log",
                    str(log_text)[:500],
                )

            self._put_span(run_id, span)
        except Exception as exc:
            _swallow(exc, "on_agent_action")

    def on_agent_finish(
        self,
        finish: Any,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        """Called when an agent finishes its execution loop.

        ``finish`` is a ``langchain_core.agents.AgentFinish`` with
        ``.return_values`` and ``.log`` attributes.
        """
        try:
            span = self._pop_span(run_id)
            if span is not None:
                # Capture agent finish info
                return_values = getattr(finish, "return_values", None)
                if return_values is not None:
                    span.set_attribute(
                        "waxell.langchain.agent_finish.output",
                        str(return_values)[:500],
                    )
                span.end()
        except Exception as exc:
            _swallow(exc, "on_agent_finish")

    # ======================================================================
    # Text / misc callbacks (no-ops -- listed for completeness)
    # ======================================================================

    def on_text(
        self,
        text: str,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        """Called with arbitrary text output. No-op for telemetry."""
        pass

    def on_retry(
        self,
        retry_state: Any,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        """Called on LLM retry. No-op for telemetry."""
        pass


# ---------------------------------------------------------------------------
# LangChainInstrumentor -- the BaseInstrumentor subclass
# ---------------------------------------------------------------------------


class LangChainInstrumentor(BaseInstrumentor):
    """Instrumentor for the LangChain framework (``langchain_core`` package).

    Injects a :class:`WaxellCallbackHandler` into every
    ``CallbackManager`` instance by monkey-patching its ``__init__``.
    This covers all LangChain components that go through the standard
    callback machinery: LLMs, chat models, chains, agents, tools,
    retrievers, LangGraph nodes, etc.
    """

    _instrumented: bool = False
    _original_init: Any = None
    _original_async_init: Any = None
    _original_tool_invoke: Any = None
    _original_tool_ainvoke: Any = None
    _handler: Optional[WaxellCallbackHandler] = None

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import langchain_core.callbacks  # noqa: F401
            from langchain_core.callbacks.manager import (
                CallbackManager,
                AsyncCallbackManager,
            )
        except ImportError:
            logger.debug(
                "langchain_core not installed -- skipping LangChain instrumentation"
            )
            return False

        # Dynamically make WaxellCallbackHandler inherit from
        # BaseCallbackHandler so LangChain recognises it.
        try:
            from langchain_core.callbacks import BaseCallbackHandler

            if BaseCallbackHandler not in WaxellCallbackHandler.__bases__:
                try:
                    WaxellCallbackHandler.__bases__ = (
                        BaseCallbackHandler,
                    ) + WaxellCallbackHandler.__bases__
                except TypeError:
                    # Python 3.14+ restricts __bases__ reassignment when
                    # deallocators differ. The handler still works via direct
                    # injection into CallbackManager.handlers.
                    pass
        except Exception as exc:
            logger.debug(
                "Could not set BaseCallbackHandler as parent: %s -- "
                "continuing without inheritance",
                exc,
            )

        # Create our handler singleton
        self._handler = WaxellCallbackHandler()

        # Idempotency: don't double-patch
        if getattr(CallbackManager.__init__, "_waxell_patched", False):
            self._instrumented = True
            # Ensure instance has a ref to the original for uninstrument()
            if self._original_init is None:
                self._original_init = LangChainInstrumentor._original_init
            logger.debug("LangChain CallbackManager already patched -- skipping")
            return True

        handler_ref = self._handler

        # --- Patch sync CallbackManager ---
        LangChainInstrumentor._original_init = CallbackManager.__init__
        self._original_init = LangChainInstrumentor._original_init
        original_init = self._original_init

        def _patched_init(self_cm: Any, *args: Any, **kwargs: Any) -> None:
            """Patched CallbackManager.__init__ that injects our handler."""
            original_init(self_cm, *args, **kwargs)
            try:
                handlers = getattr(self_cm, "handlers", [])
                if not any(h is handler_ref for h in handlers):
                    handlers.append(handler_ref)
            except Exception:
                pass

        _patched_init._waxell_patched = True  # type: ignore[attr-defined]
        _patched_init._original = original_init  # type: ignore[attr-defined]
        CallbackManager.__init__ = _patched_init  # type: ignore[assignment]

        # --- Patch async CallbackManager ---
        # AsyncCallbackManager does NOT inherit from CallbackManager, so it
        # needs its own __init__ patch.  LangGraph and other async frameworks
        # use AsyncCallbackManager exclusively — without this patch, the
        # WaxellCallbackHandler is never injected into async execution paths.
        if not getattr(AsyncCallbackManager.__init__, "_waxell_patched", False):
            LangChainInstrumentor._original_async_init = AsyncCallbackManager.__init__
            self._original_async_init = LangChainInstrumentor._original_async_init
            original_async_init = self._original_async_init

            def _patched_async_init(self_cm: Any, *args: Any, **kwargs: Any) -> None:
                """Patched AsyncCallbackManager.__init__ that injects our handler."""
                original_async_init(self_cm, *args, **kwargs)
                try:
                    handlers = getattr(self_cm, "handlers", [])
                    if not any(h is handler_ref for h in handlers):
                        handlers.append(handler_ref)
                except Exception:
                    pass

            _patched_async_init._waxell_patched = True  # type: ignore[attr-defined]
            _patched_async_init._original = original_async_init  # type: ignore[attr-defined]
            AsyncCallbackManager.__init__ = _patched_async_init  # type: ignore[assignment]

        # --- Patch BaseTool.invoke / ainvoke for pre-execution governance ---
        # Callbacks can't block tool execution (LangChain swallows callback
        # exceptions). We patch invoke/ainvoke on BaseTool so a governance
        # check runs BEFORE the tool function, and PolicyViolationError
        # propagates up to the agent loop.
        try:
            from langchain_core.tools import BaseTool as _BaseTool

            if not getattr(_BaseTool.invoke, "_waxell_patched", False):
                _orig_invoke = _BaseTool.invoke

                def _patched_invoke(self_tool, input, config=None, **kwargs):
                    from ._context_var import _current_context

                    ctx = _current_context.get()
                    if ctx is not None:
                        ctx.check_tool_before_execution(self_tool.name)
                    return _orig_invoke(self_tool, input, config=config, **kwargs)

                _patched_invoke._waxell_patched = True
                _patched_invoke._original = _orig_invoke
                _BaseTool.invoke = _patched_invoke
                LangChainInstrumentor._original_tool_invoke = _orig_invoke

            if not getattr(_BaseTool.ainvoke, "_waxell_patched", False):
                _orig_ainvoke = _BaseTool.ainvoke

                async def _patched_ainvoke(self_tool, input, config=None, **kwargs):
                    from ._context_var import _current_context

                    ctx = _current_context.get()
                    if ctx is not None:
                        ctx.check_tool_before_execution(self_tool.name)
                    return await _orig_ainvoke(
                        self_tool, input, config=config, **kwargs
                    )

                _patched_ainvoke._waxell_patched = True
                _patched_ainvoke._original = _orig_ainvoke
                _BaseTool.ainvoke = _patched_ainvoke
                LangChainInstrumentor._original_tool_ainvoke = _orig_ainvoke

        except ImportError:
            pass
        except Exception as exc:
            logger.debug("Could not patch BaseTool.invoke/ainvoke: %s", exc)

        self._instrumented = True
        logger.debug(
            "LangChain instrumented (CallbackManager + AsyncCallbackManager "
            "patched with WaxellCallbackHandler)"
        )
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            from langchain_core.callbacks.manager import (
                CallbackManager,
                AsyncCallbackManager,
            )

            if self._original_init is not None:
                CallbackManager.__init__ = self._original_init  # type: ignore[assignment]
                self._original_init = None
            if self._original_async_init is not None:
                AsyncCallbackManager.__init__ = self._original_async_init  # type: ignore[assignment]
                self._original_async_init = None
        except (ImportError, AttributeError):
            pass

        # Restore BaseTool.invoke / ainvoke
        try:
            from langchain_core.tools import BaseTool as _BaseTool

            orig_invoke = getattr(LangChainInstrumentor, "_original_tool_invoke", None)
            if orig_invoke is not None:
                _BaseTool.invoke = orig_invoke
                LangChainInstrumentor._original_tool_invoke = None
            orig_ainvoke = getattr(
                LangChainInstrumentor, "_original_tool_ainvoke", None
            )
            if orig_ainvoke is not None:
                _BaseTool.ainvoke = orig_ainvoke
                LangChainInstrumentor._original_tool_ainvoke = None
        except (ImportError, AttributeError):
            pass

        self._handler = None
        self._instrumented = False
        logger.debug("LangChain uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_http_llm(
    response: Any,
    model: str,
    tokens_in: int,
    tokens_out: int,
    cost: float,
) -> None:
    """Record an LLM call to the HTTP path (context or background collector).

    If a ``WaxellContext`` is active (i.e. the user wrapped their code in a
    context manager), the call is recorded there.  Otherwise it goes to the
    background collector which batches and flushes periodically.
    """
    try:
        from ._context_var import _current_context
        from ._collector import _collector

        # Build a preview of the response text
        response_preview = ""
        generations = getattr(response, "generations", None)
        if generations:
            # response.generations is a list of lists
            for gen_list in generations:
                if gen_list:
                    first_gen = gen_list[0]
                    text = getattr(first_gen, "text", "")
                    if text:
                        response_preview = str(text)[:500]
                        break

        call_data = {
            "model": model,
            "tokens_in": tokens_in,
            "tokens_out": tokens_out,
            "cost": cost,
            "task": "langchain.llm",
            "response_preview": response_preview,
            "framework": "langchain",
        }

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            ctx.record_llm_call(**call_data)
            # The openai instrumentor may have already recorded this call
            # (it fires during the API call, before on_llm_end).  In that
            # case record_llm_call() deduplicates and returns early, so the
            # framework attribute is never set.  Annotate the existing span.
            ctx._annotate_framework("langchain", model)
        else:
            _collector.record_call(call_data)
    except Exception as exc:
        logger.debug("HTTP dual-path recording failed: %s", exc)


# ---------------------------------------------------------------------------
# HTTP dual-path recording -- tools
# ---------------------------------------------------------------------------


def _record_http_tool(
    tool_name: str,
    tool_input: Any,
    tool_output: Any,
    status: str = "ok",
    error: str = "",
    duration_ms: int | None = None,
) -> None:
    """Record a tool call via ``ctx.record_tool_call()``.

    This is the SINGLE recording path for LangChain tool invocations. It
    creates both the HTTP-path step (for the trace UI) and the OTel span.
    The LangChain ``on_tool_start`` callback deliberately does NOT create
    an OTel span to avoid duplicates.
    """
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx is None or not ctx.run_id:
            return

        # Build serialisable input/output dicts
        if isinstance(tool_input, dict):
            input_data = tool_input
        elif tool_input:
            input_data = {"raw": str(tool_input)[:4096]}
        else:
            input_data = {}

        if isinstance(tool_output, dict):
            output_data = tool_output
        elif tool_output is not None:
            output_data = {"raw": str(tool_output)[:4096]}
        else:
            output_data = {}

        ctx.record_tool_call(
            name=tool_name,
            input=input_data,
            output=output_data,
            duration_ms=duration_ms,
            status=status,
            tool_type="langchain",
            error=error,
            _skip_step=True,
        )
    except Exception as exc:
        logger.debug("HTTP tool recording failed: %s", exc)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span: Any, exc: BaseException) -> None:
    """Record an exception on a span and set error status."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
