"""IBM WatsonX AI auto-instrumentor for waxell-observe.

Monkey-patches WatsonX AI SDK methods to emit OTel spans and record
to the Waxell HTTP API.

Patched methods:
  - ``ibm_watsonx_ai.foundation_models.ModelInference.generate()``
  - ``ibm_watsonx_ai.foundation_models.ModelInference.generate_text()``
  - ``ibm_watsonx_ai.foundation_models.ModelInference.chat()``
  - ``ibm_watsonx_ai.foundation_models.ModelInference.chat_stream()``
  - ``ibm_watsonx_ai.foundation_models.Embeddings.embed_documents()``

WatsonX generate() returns a dict:
  - ``result["results"][0]["generated_text"]``
  - ``result["results"][0]["generated_token_count"]`` (output tokens)
  - ``result["results"][0]["input_token_count"]`` (input tokens)
  - ``result["results"][0]["stop_reason"]`` (finish reason)
  - ``result["model_id"]`` (model name)

Models: ibm/granite-13b-chat-v2, meta-llama/llama-3-70b-instruct,
        ibm/granite-3-8b-instruct, etc.

All wrapper code is wrapped in try/except -- never breaks the user's LLM calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Cost estimates for WatsonX models (USD per token)
#
# Prices are the per-million-token rates from IBM's published watsonx
# pricing (sourced via LiteLLM's `model_prices_and_context_window.json`
# under the `watsonx/<id>` keys). Keep this table sparse-but-current:
# the longest matching key wins, so an entry like "ibm/granite-4" covers
# the whole Granite 4 family unless a more specific row overrides it.
#
# The runtime fallback is conservative — calls that hit `_DEFAULT_COST`
# are reported at the cheapest current Granite rate so we never *under*-
# report by orders of magnitude when a new model lands without a row,
# but we don't artificially inflate either. The previous defaults of
# $0.30 in / $0.90 out were 5× the real Granite-4 prices and produced
# inflated cost rollups in the controlplane.
# ---------------------------------------------------------------------------

_WATSONX_COSTS: dict[str, dict[str, float]] = {
    # Granite 4 family — published Aug 2025
    "ibm/granite-4-h-small": {
        "input": 0.06 / 1_000_000,
        "output": 0.25 / 1_000_000,
    },
    "ibm/granite-4": {
        "input": 0.06 / 1_000_000,
        "output": 0.25 / 1_000_000,
    },
    # Granite 3.x
    "ibm/granite-3-3-8b-instruct": {
        "input": 0.20 / 1_000_000,
        "output": 0.20 / 1_000_000,
    },
    "ibm/granite-3-8b-instruct": {
        "input": 0.20 / 1_000_000,
        "output": 0.20 / 1_000_000,
    },
    "ibm/granite-3-8b": {
        "input": 0.20 / 1_000_000,
        "output": 0.20 / 1_000_000,
    },
    "ibm/granite-3-2b": {
        "input": 0.10 / 1_000_000,
        "output": 0.10 / 1_000_000,
    },
    # Granite Guardian (safety/guard models)
    "ibm/granite-guardian-3-3-8b": {
        "input": 0.20 / 1_000_000,
        "output": 0.20 / 1_000_000,
    },
    "ibm/granite-guardian-3-2-2b": {
        "input": 0.10 / 1_000_000,
        "output": 0.10 / 1_000_000,
    },
    # Granite legacy
    "ibm/granite-13b-chat-v2": {
        "input": 0.60 / 1_000_000,
        "output": 0.60 / 1_000_000,
    },
    "ibm/granite-13b-instruct-v2": {
        "input": 0.60 / 1_000_000,
        "output": 0.60 / 1_000_000,
    },
    "ibm/granite-13b": {
        "input": 0.60 / 1_000_000,
        "output": 0.60 / 1_000_000,
    },
    # Granite vision
    "ibm/granite-vision-3-2-2b": {
        "input": 0.10 / 1_000_000,
        "output": 0.10 / 1_000_000,
    },
    # Llama on watsonx
    "meta-llama/llama-3-3-70b-instruct": {
        "input": 0.71 / 1_000_000,
        "output": 0.71 / 1_000_000,
    },
    "meta-llama/llama-4-maverick-17b": {
        "input": 0.35 / 1_000_000,
        "output": 1.40 / 1_000_000,
    },
    "meta-llama/llama-3-70b": {
        "input": 0.90 / 1_000_000,
        "output": 1.20 / 1_000_000,
    },
    "meta-llama/llama-3-2-3b-instruct": {
        "input": 0.15 / 1_000_000,
        "output": 0.15 / 1_000_000,
    },
    "meta-llama/llama-3-2-1b-instruct": {
        "input": 0.10 / 1_000_000,
        "output": 0.10 / 1_000_000,
    },
    "meta-llama/llama-3-8b": {
        "input": 0.15 / 1_000_000,
        "output": 0.20 / 1_000_000,
    },
    # Mistral on watsonx
    "mistralai/mistral-large": {
        "input": 3.00 / 1_000_000,
        "output": 10.00 / 1_000_000,
    },
    "mistralai/mistral-small-3-1-24b-instruct-2503": {
        "input": 0.10 / 1_000_000,
        "output": 0.30 / 1_000_000,
    },
    "mistralai/mistral-medium-2505": {
        "input": 3.00 / 1_000_000,
        "output": 10.00 / 1_000_000,
    },
    "mistralai/mixtral-8x7b": {
        "input": 0.45 / 1_000_000,
        "output": 0.70 / 1_000_000,
    },
    # OpenAI gpt-oss hosted on watsonx
    "openai/gpt-oss-120b": {
        "input": 0.15 / 1_000_000,
        "output": 0.60 / 1_000_000,
    },
}

# Fallback for unknown watsonx model ids. Set to the cheapest current
# Granite rate so we under-report at worst by 4-5x rather than over-
# report. Better than the old $0.30/$0.90 defaults that inflated bills.
_DEFAULT_COST = {"input": 0.10 / 1_000_000, "output": 0.20 / 1_000_000}


def _estimate_watsonx_cost(model: str, tokens_in: int, tokens_out: int) -> float:
    """Estimate cost for a WatsonX model call."""
    model_lower = model.lower()
    costs = _DEFAULT_COST
    for prefix, cost_info in _WATSONX_COSTS.items():
        if model_lower.startswith(prefix):
            costs = cost_info
            break
    return (tokens_in * costs["input"]) + (tokens_out * costs["output"])


class WatsonXInstrumentor(BaseInstrumentor):
    """Instrumentor for the IBM WatsonX AI SDK (``ibm_watsonx_ai`` package).

    Patches ``ModelInference.generate()``, ``ModelInference.generate_text()``,
    and ``Embeddings.embed_documents()``.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import ibm_watsonx_ai  # noqa: F401
        except ImportError:
            logger.debug(
                "ibm_watsonx_ai package not installed -- skipping instrumentation"
            )
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug(
                "wrapt package not installed -- skipping WatsonX instrumentation"
            )
            return False

        patched = False

        # Patch ModelInference.generate()
        try:
            wrapt.wrap_function_wrapper(
                "ibm_watsonx_ai.foundation_models",
                "ModelInference.generate",
                _sync_generate_wrapper,
            )
            patched = True
            logger.debug("WatsonX ModelInference.generate instrumented")
        except Exception as exc:
            logger.debug("Could not patch ModelInference.generate: %s", exc)

        # Patch ModelInference.generate_text()
        try:
            wrapt.wrap_function_wrapper(
                "ibm_watsonx_ai.foundation_models",
                "ModelInference.generate_text",
                _sync_generate_text_wrapper,
            )
            logger.debug("WatsonX ModelInference.generate_text instrumented")
        except Exception as exc:
            logger.debug("Could not patch ModelInference.generate_text: %s", exc)

        # Patch ModelInference.chat() — OpenAI-shaped chat API. ChatWatsonx
        # (langchain-ibm) routes through this for chat-mode calls, so without
        # this wrapper LangChain-wrapped Granite calls lose prompt/response
        # capture (only token counts come through the LC CallbackManager).
        try:
            wrapt.wrap_function_wrapper(
                "ibm_watsonx_ai.foundation_models",
                "ModelInference.chat",
                _sync_chat_wrapper,
            )
            logger.debug("WatsonX ModelInference.chat instrumented")
        except Exception as exc:
            logger.debug("Could not patch ModelInference.chat: %s", exc)

        # Patch ModelInference.chat_stream() — generator of incremental chunks.
        # We wrap it so we can accumulate content + final usage across the
        # stream and emit one span at completion.
        try:
            wrapt.wrap_function_wrapper(
                "ibm_watsonx_ai.foundation_models",
                "ModelInference.chat_stream",
                _sync_chat_stream_wrapper,
            )
            logger.debug("WatsonX ModelInference.chat_stream instrumented")
        except Exception as exc:
            logger.debug("Could not patch ModelInference.chat_stream: %s", exc)

        # Patch Embeddings.embed_documents()
        try:
            wrapt.wrap_function_wrapper(
                "ibm_watsonx_ai.foundation_models",
                "Embeddings.embed_documents",
                _sync_embed_wrapper,
            )
            logger.debug("WatsonX Embeddings.embed_documents instrumented")
        except Exception as exc:
            logger.debug("Could not patch Embeddings.embed_documents: %s", exc)

        if not patched:
            logger.debug("Could not find WatsonX generation methods to patch")
            return False

        self._instrumented = True
        logger.debug("WatsonX ModelInference/Embeddings instrumented")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import importlib

            mod = importlib.import_module("ibm_watsonx_ai.foundation_models")

            if hasattr(mod, "ModelInference"):
                if hasattr(mod.ModelInference.generate, "__wrapped__"):
                    mod.ModelInference.generate = (
                        mod.ModelInference.generate.__wrapped__
                    )  # type: ignore[attr-defined]
                if hasattr(mod.ModelInference.generate_text, "__wrapped__"):
                    mod.ModelInference.generate_text = (
                        mod.ModelInference.generate_text.__wrapped__
                    )  # type: ignore[attr-defined]
                if hasattr(mod.ModelInference.chat, "__wrapped__"):
                    mod.ModelInference.chat = mod.ModelInference.chat.__wrapped__  # type: ignore[attr-defined]
                if hasattr(mod.ModelInference.chat_stream, "__wrapped__"):
                    mod.ModelInference.chat_stream = (
                        mod.ModelInference.chat_stream.__wrapped__
                    )  # type: ignore[attr-defined]

            if hasattr(mod, "Embeddings"):
                if hasattr(mod.Embeddings.embed_documents, "__wrapped__"):
                    mod.Embeddings.embed_documents = (
                        mod.Embeddings.embed_documents.__wrapped__
                    )  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("WatsonX ModelInference/Embeddings uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------


def _extract_generate_result(result: dict) -> tuple[str, int, int, str, str]:
    """Extract data from WatsonX generate() dict response.

    Returns (generated_text, input_tokens, output_tokens, stop_reason, model_id).
    """
    generated_text = ""
    tokens_in = 0
    tokens_out = 0
    stop_reason = ""
    model_id = ""

    try:
        model_id = result.get("model_id", "") or ""
        results = result.get("results", [])
        if results and len(results) > 0:
            first = results[0]
            generated_text = first.get("generated_text", "") or ""
            tokens_in = first.get("input_token_count", 0) or 0
            tokens_out = first.get("generated_token_count", 0) or 0
            stop_reason = first.get("stop_reason", "") or ""
    except Exception:
        pass

    return generated_text, tokens_in, tokens_out, stop_reason, model_id


def _get_model_from_instance(instance) -> str:
    """Try to extract the model ID from a ModelInference instance."""
    try:
        # ModelInference typically stores model_id
        model = getattr(instance, "model_id", None)
        if model:
            return str(model)
        model = getattr(instance, "model", None)
        if model:
            return str(model)
    except Exception:
        pass
    return "unknown"


# ---------------------------------------------------------------------------
# Wrapper functions (module-level for wrapt compatibility)
# ---------------------------------------------------------------------------


def _sync_generate_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for WatsonX ``ModelInference.generate``."""
    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    model = _get_model_from_instance(instance)

    try:
        span = start_llm_span(model=model, provider_name="watsonx")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            if isinstance(result, dict):
                generated_text, tokens_in, tokens_out, stop_reason, model_id = (
                    _extract_generate_result(result)
                )
                response_model = model_id or model
                cost = _estimate_watsonx_cost(response_model, tokens_in, tokens_out)

                finish_reasons = [stop_reason] if stop_reason else []

                span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
                span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
                span.set_attribute(GenAIAttributes.RESPONSE_MODEL, response_model)
                span.set_attribute(
                    GenAIAttributes.RESPONSE_FINISH_REASONS, finish_reasons
                )
                span.set_attribute(WaxellAttributes.LLM_MODEL, response_model)
                span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
                span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
                span.set_attribute(
                    WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out
                )
                span.set_attribute(WaxellAttributes.LLM_COST, cost)
            else:
                # Non-dict response (e.g. streaming) -- just set model
                span.set_attribute(WaxellAttributes.LLM_MODEL, model)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        # Dual-path: record to HTTP API
        try:
            _record_http_generate(result, model, kwargs, instance)
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# chat() — OpenAI-shaped chat API on watsonx
# ---------------------------------------------------------------------------


def _extract_chat_result(result: dict) -> tuple[str, int, int, str, str, list]:
    """Pull data from a chat() response dict.

    Returns (assistant_text, input_tokens, output_tokens, finish_reason,
    model_id, tool_calls). All fields safe-default to "" / 0 / [].
    """
    text = ""
    tokens_in = 0
    tokens_out = 0
    finish_reason = ""
    model_id = ""
    tool_calls: list = []

    try:
        model_id = result.get("model_id", "") or result.get("model", "") or ""
        choices = result.get("choices") or []
        if choices:
            first = choices[0] or {}
            finish_reason = first.get("finish_reason", "") or ""
            msg = first.get("message") or {}
            text = msg.get("content", "") or ""
            tool_calls = msg.get("tool_calls") or []
        usage = result.get("usage") or {}
        tokens_in = usage.get("prompt_tokens") or usage.get("input_tokens") or 0
        tokens_out = usage.get("completion_tokens") or usage.get("output_tokens") or 0
    except Exception:
        pass

    return text, tokens_in, tokens_out, finish_reason, model_id, tool_calls


def _summarize_messages(messages, max_chars: int = 800) -> str:
    """Render the request messages into a single preview string.

    Each role gets a brief tag so the prompt_preview retains the
    structure of a multi-turn conversation without ballooning the
    record size. Tool messages also include the tool name when present.
    """
    if not messages:
        return ""
    out: list[str] = []
    try:
        for m in messages:
            if not isinstance(m, dict):
                continue
            role = m.get("role", "user")
            content = m.get("content", "")
            if isinstance(content, list):
                # OpenAI content-parts shape; concatenate text segments
                parts = []
                for c in content:
                    if isinstance(c, dict):
                        parts.append(c.get("text", "") or "")
                content = " ".join(p for p in parts if p)
            content = str(content)
            tag = role
            if role == "tool":
                name = m.get("name", "")
                if name:
                    tag = f"tool:{name}"
            out.append(f"[{tag}] {content}")
    except Exception:
        pass
    joined = "\n".join(out)
    if len(joined) > max_chars:
        joined = joined[:max_chars].rstrip() + "..."
    return joined


def _sync_chat_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for WatsonX ``ModelInference.chat``."""
    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    model = _get_model_from_instance(instance)
    messages = args[0] if args else kwargs.get("messages", [])

    try:
        span = start_llm_span(model=model, provider_name="watsonx")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            if isinstance(result, dict):
                text, tokens_in, tokens_out, finish, model_id, tool_calls = (
                    _extract_chat_result(result)
                )
                response_model = model_id or model
                cost = _estimate_watsonx_cost(response_model, tokens_in, tokens_out)
                finish_reasons = [finish] if finish else []

                span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
                span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
                span.set_attribute(GenAIAttributes.RESPONSE_MODEL, response_model)
                span.set_attribute(
                    GenAIAttributes.RESPONSE_FINISH_REASONS, finish_reasons
                )
                span.set_attribute(WaxellAttributes.LLM_MODEL, response_model)
                span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
                span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
                span.set_attribute(
                    WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out
                )
                span.set_attribute(WaxellAttributes.LLM_COST, cost)
                if tool_calls:
                    span.set_attribute("waxell.llm.tool_call_count", len(tool_calls))
            else:
                span.set_attribute(WaxellAttributes.LLM_MODEL, model)
        except Exception as attr_exc:
            logger.debug("Failed to set chat span attributes: %s", attr_exc)

        # Dual-path: record to HTTP API with prompt/response preview so the
        # llm-calls table actually has content (this is the gap that drove
        # adding this wrapper in the first place).
        try:
            _record_http_chat(result, model, messages)
        except Exception:
            pass

        return result
    finally:
        span.end()


def _sync_chat_stream_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for WatsonX ``ModelInference.chat_stream``.

    chat_stream returns an iterable of incremental chunk dicts. We
    accumulate the content + grab the final usage block (if present)
    so the single emitted span captures the same fields the non-streaming
    wrapper does.
    """
    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    model = _get_model_from_instance(instance)
    messages = args[0] if args else kwargs.get("messages", [])

    try:
        span = start_llm_span(model=model, provider_name="watsonx")
    except Exception:
        return wrapped(*args, **kwargs)

    upstream = None
    try:
        upstream = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        span.end()
        raise

    def _iter_and_capture():
        accumulated_text = ""
        tokens_in = 0
        tokens_out = 0
        finish_reason = ""
        model_id = ""
        tool_call_count = 0
        try:
            for chunk in upstream:
                # Inspect the chunk for incremental content + usage. The
                # caller still sees every chunk unchanged.
                try:
                    if isinstance(chunk, dict):
                        if not model_id:
                            model_id = chunk.get("model_id") or chunk.get("model", "")
                        choices = chunk.get("choices") or []
                        if choices:
                            delta = (choices[0] or {}).get("delta") or {}
                            piece = delta.get("content") or ""
                            if piece:
                                accumulated_text += piece
                            tc = delta.get("tool_calls") or []
                            if tc:
                                tool_call_count += len(tc)
                            fr = (choices[0] or {}).get("finish_reason") or ""
                            if fr:
                                finish_reason = fr
                        usage = chunk.get("usage") or {}
                        if usage:
                            tokens_in = (
                                usage.get("prompt_tokens")
                                or usage.get("input_tokens")
                                or tokens_in
                            )
                            tokens_out = (
                                usage.get("completion_tokens")
                                or usage.get("output_tokens")
                                or tokens_out
                            )
                except Exception:
                    pass
                yield chunk
        except Exception as exc:
            _record_error(span, exc)
            raise
        finally:
            try:
                response_model = model_id or model
                cost = _estimate_watsonx_cost(response_model, tokens_in, tokens_out)
                finish_reasons = [finish_reason] if finish_reason else []

                span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
                span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
                span.set_attribute(GenAIAttributes.RESPONSE_MODEL, response_model)
                span.set_attribute(
                    GenAIAttributes.RESPONSE_FINISH_REASONS, finish_reasons
                )
                span.set_attribute(WaxellAttributes.LLM_MODEL, response_model)
                span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
                span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
                span.set_attribute(
                    WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out
                )
                span.set_attribute(WaxellAttributes.LLM_COST, cost)
                if tool_call_count:
                    span.set_attribute("waxell.llm.tool_call_count", tool_call_count)
            except Exception as attr_exc:
                logger.debug("Failed to set chat_stream span attributes: %s", attr_exc)

            # Build a synthetic "result" for the HTTP dual-path so the
            # llm-calls table gets the same shape as non-streaming.
            try:
                synthetic = {
                    "model_id": model_id or model,
                    "choices": [
                        {
                            "message": {
                                "role": "assistant",
                                "content": accumulated_text,
                            },
                            "finish_reason": finish_reason,
                        }
                    ],
                    "usage": {
                        "prompt_tokens": tokens_in,
                        "completion_tokens": tokens_out,
                    },
                }
                _record_http_chat(synthetic, model, messages)
            except Exception:
                pass

            span.end()

    return _iter_and_capture()


def _sync_generate_text_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for WatsonX ``ModelInference.generate_text``.

    generate_text() is a convenience method that returns just the text string.
    We still create a span but with limited usage info.
    """
    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    model = _get_model_from_instance(instance)

    try:
        span = start_llm_span(model=model, provider_name="watsonx")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute(WaxellAttributes.LLM_MODEL, model)
            if isinstance(result, str):
                # generate_text returns just the text, limited info available
                pass
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        return result
    finally:
        span.end()


def _sync_embed_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for WatsonX ``Embeddings.embed_documents``."""
    try:
        from ..tracing.spans import start_embedding_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    model = _get_model_from_instance(instance)

    # Count input documents
    docs = args[0] if args else kwargs.get("documents", [])
    if isinstance(docs, list):
        input_count = len(docs)
    elif isinstance(docs, str):
        input_count = 1
    else:
        input_count = 1

    try:
        span = start_embedding_span(
            model=model, provider_name="watsonx", input_count=input_count
        )
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            dimensions = 0
            if isinstance(result, list) and len(result) > 0:
                first = result[0]
                if isinstance(first, list):
                    dimensions = len(first)

            span.set_attribute(WaxellAttributes.EMBEDDING_MODEL, model)
            span.set_attribute(WaxellAttributes.EMBEDDING_DIMENSIONS, dimensions)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_COUNT, input_count)
        except Exception as attr_exc:
            logger.debug("Failed to set embedding span attributes: %s", attr_exc)

        # Dual-path: record to HTTP API
        try:
            _record_http_embedding(result, model, kwargs, input_count)
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_http_generate(
    result, request_model: str, kwargs: dict, instance=None
) -> None:
    """Record a WatsonX generate call to the HTTP path."""
    from ._context_var import _current_context
    from ._collector import _collector

    generated_text = ""
    tokens_in = 0
    tokens_out = 0
    model_id = request_model

    if isinstance(result, dict):
        generated_text, tokens_in, tokens_out, _, model_id = _extract_generate_result(
            result
        )
        if not model_id:
            model_id = request_model

    cost = _estimate_watsonx_cost(model_id, tokens_in, tokens_out)

    # Extract prompt preview
    prompt_preview = ""
    prompt = kwargs.get("prompt", None)
    if prompt:
        prompt_preview = str(prompt)[:500]

    response_preview = str(generated_text)[:500] if generated_text else ""

    call_data = {
        "model": model_id,
        "tokens_in": tokens_in,
        "tokens_out": tokens_out,
        "cost": cost,
        "task": "generate",
        "prompt_preview": prompt_preview,
        "response_preview": response_preview,
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


def _record_http_chat(result, request_model: str, messages) -> None:
    """Record a WatsonX chat() / chat_stream() call to the HTTP path.

    Mirrors _record_http_generate but for chat-shaped requests, so the
    prompt_preview retains the multi-turn structure and the response
    preview includes the assistant's reply.

    Marks ``_http_dedup`` after recording so the LangChain instrumentor
    skips its own ``on_llm_end`` HTTP record for this same call —
    otherwise ChatWatsonx-routed calls land in the llm-calls table twice
    (once as ``task='chat'``, once as ``task='langchain.llm'``) and the
    doubled token counts trip mid-run budget policies at half the real
    usage.
    """
    from ._context_var import _current_context
    from ._collector import _collector
    from ._http_dedup import mark_recorded

    text = ""
    tokens_in = 0
    tokens_out = 0
    model_id = request_model

    if isinstance(result, dict):
        text, tokens_in, tokens_out, _finish, model_id, _tc = _extract_chat_result(
            result
        )
        if not model_id:
            model_id = request_model

    cost = _estimate_watsonx_cost(model_id, tokens_in, tokens_out)

    prompt_preview = _summarize_messages(messages)
    response_preview = str(text)[:500] if text else ""

    call_data = {
        "model": model_id,
        "tokens_in": tokens_in,
        "tokens_out": tokens_out,
        "cost": cost,
        "task": "chat",
        "prompt_preview": prompt_preview,
        "response_preview": response_preview,
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)

    # Tell the LangChain instrumentor's on_llm_end to skip its dual-path
    # record for this call — see _http_dedup module-docstring.
    mark_recorded()


def _record_http_embedding(
    result, model: str, kwargs: dict, input_count: int = 0
) -> None:
    """Record a WatsonX embedding call to the HTTP path."""
    from ._context_var import _current_context
    from ._collector import _collector

    call_data = {
        "model": model,
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": "embedding",
        "prompt_preview": f"[{model} embedding, {input_count} docs]",
        "response_preview": "",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
