"""Claude Agent SDK auto-instrumentor for waxell-observe.

Instruments the Anthropic Claude Agent SDK (``claude-agent-sdk`` package,
import ``claude_agent_sdk``) to emit OTel spans and record to the Waxell
HTTP API.

The Claude Agent SDK provides an async iteration-based agent loop that yields
``AssistantMessage`` and ``ResultMessage`` objects.  The primary entry point
is the ``Claude`` client class which exposes ``agent()`` to create an agent
and an async iteration protocol for the agent loop.

Since the SDK spawns a Rust-based CLI subprocess under the hood the best
instrumentation strategy is to wrap the high-level Python entry points:
- ``Claude.agent()`` — creates an agent run
- ``AgentSession.run()`` / ``AgentSession.__aiter__`` — iterates the loop

All wrapper code is wrapped in try/except — never breaks the user's calls.
"""

from __future__ import annotations

import logging
import time

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)

# Module candidates in order of likelihood
_MODULE_CANDIDATES = (
    "claude_agent_sdk",
    "claude_agent",
    "anthropic.agents",
    "anthropic.agent",
    "anthropic_agents",
)


class ClaudeAgentsInstrumentor(BaseInstrumentor):
    """Instrumentor for the Claude Agent SDK.

    Patches agent execution entry points across multiple possible
    module paths since the SDK has gone through naming changes.
    """

    _instrumented: bool = False
    _patched_module: str | None = None

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        # Find the SDK module
        agent_module = None
        for candidate in _MODULE_CANDIDATES:
            try:
                __import__(candidate)
                agent_module = candidate
                break
            except ImportError:
                continue

        if agent_module is None:
            logger.debug("Claude Agent SDK not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug(
                "wrapt not installed -- skipping Claude Agents instrumentation"
            )
            return False

        import importlib

        mod = importlib.import_module(agent_module)
        patched = False

        # ── Strategy 1: Patch Claude client class ─────────────────────
        # The SDK exposes Claude() as the main client; Claude.agent() or
        # Claude.create_agent() starts an agent session.
        for cls_name in ("Claude", "Client", "ClaudeClient"):
            cls = getattr(mod, cls_name, None)
            if cls is None:
                continue

            for method_name in ("agent", "create_agent", "run"):
                method = getattr(cls, method_name, None)
                if method is None:
                    continue
                try:
                    import asyncio

                    is_async = asyncio.iscoroutinefunction(method)
                    wrapper = (
                        _async_client_wrapper if is_async else _sync_client_wrapper
                    )
                    wrapt.wrap_function_wrapper(
                        agent_module,
                        f"{cls_name}.{method_name}",
                        wrapper,
                    )
                    patched = True
                    self._patched_module = agent_module
                    logger.debug(
                        "Claude Agents: patched %s.%s.%s",
                        agent_module,
                        cls_name,
                        method_name,
                    )
                except Exception as exc:
                    logger.debug(
                        "Failed to patch %s.%s.%s: %s",
                        agent_module,
                        cls_name,
                        method_name,
                        exc,
                    )

        # ── Strategy 2: Patch Agent / Runner classes ──────────────────
        # Fallback for older SDK layouts or direct Agent usage.
        for cls_name in ("Agent", "Runner", "AgentRunner", "AgentSession"):
            cls = getattr(mod, cls_name, None)
            if cls is None:
                continue

            for method_name in ("run", "run_async", "run_sync", "execute", "__call__"):
                method = getattr(cls, method_name, None)
                if method is None:
                    continue
                try:
                    import asyncio

                    is_async = asyncio.iscoroutinefunction(method)
                    wrapper = _async_agent_wrapper if is_async else _sync_agent_wrapper
                    wrapt.wrap_function_wrapper(
                        agent_module,
                        f"{cls_name}.{method_name}",
                        wrapper,
                    )
                    patched = True
                    self._patched_module = agent_module
                    logger.debug(
                        "Claude Agents: patched %s.%s.%s",
                        agent_module,
                        cls_name,
                        method_name,
                    )
                except Exception as exc:
                    logger.debug(
                        "Failed to patch %s.%s.%s: %s",
                        agent_module,
                        cls_name,
                        method_name,
                        exc,
                    )

        # ── Strategy 3: Patch submodule entry points ──────────────────
        # Some SDK layouts expose entry points in submodules.
        for submod_suffix in (".client", ".session", ".agent", ".runner"):
            submod_path = agent_module + submod_suffix
            try:
                submod = importlib.import_module(submod_path)
            except ImportError:
                continue

            for cls_name in ("Claude", "Client", "Agent", "Runner", "AgentSession"):
                cls = getattr(submod, cls_name, None)
                if cls is None:
                    continue
                for method_name in (
                    "agent",
                    "create_agent",
                    "run",
                    "run_async",
                    "run_sync",
                ):
                    method = getattr(cls, method_name, None)
                    if method is None:
                        continue
                    try:
                        import asyncio

                        is_async = asyncio.iscoroutinefunction(method)
                        wrapper = (
                            _async_agent_wrapper if is_async else _sync_agent_wrapper
                        )
                        wrapt.wrap_function_wrapper(
                            submod_path,
                            f"{cls_name}.{method_name}",
                            wrapper,
                        )
                        patched = True
                        self._patched_module = agent_module
                        logger.debug(
                            "Claude Agents: patched %s.%s.%s",
                            submod_path,
                            cls_name,
                            method_name,
                        )
                    except Exception as exc:
                        logger.debug(
                            "Failed to patch %s.%s.%s: %s",
                            submod_path,
                            cls_name,
                            method_name,
                            exc,
                        )

        if not patched:
            logger.debug("Could not find Claude Agent SDK methods to patch")
            return False

        self._instrumented = True
        logger.debug("Claude Agent SDK instrumented via %s", agent_module)
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        if self._patched_module:
            try:
                import importlib

                mod = importlib.import_module(self._patched_module)
                _restore_methods(mod)

                # Also check submodules
                for suffix in (".client", ".session", ".agent", ".runner"):
                    try:
                        submod = importlib.import_module(self._patched_module + suffix)
                        _restore_methods(submod)
                    except ImportError:
                        pass
            except (ImportError, AttributeError):
                pass

        self._instrumented = False
        self._patched_module = None
        logger.debug("Claude Agent SDK uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


def _restore_methods(mod) -> None:
    """Restore wrapped methods on all known class names in a module."""
    for cls_name in (
        "Claude",
        "Client",
        "ClaudeClient",
        "Agent",
        "Runner",
        "AgentRunner",
        "AgentSession",
    ):
        cls = getattr(mod, cls_name, None)
        if cls is None:
            continue
        for method_name in (
            "agent",
            "create_agent",
            "run",
            "run_async",
            "run_sync",
            "execute",
            "__call__",
        ):
            method = getattr(cls, method_name, None)
            if method and hasattr(method, "__wrapped__"):
                setattr(cls, method_name, method.__wrapped__)


# ---------------------------------------------------------------------------
# Metadata extraction
# ---------------------------------------------------------------------------


def _extract_agent_info(instance, args, kwargs) -> dict:
    """Extract agent metadata from the instance and arguments."""
    info: dict = {}

    # Agent name
    info["agent_name"] = (
        getattr(instance, "name", None)
        or getattr(instance, "agent_name", None)
        or kwargs.get("agent_name")
        or kwargs.get("name")
        or "claude.agent"
    )

    # Model
    model = (
        getattr(instance, "model", None)
        or getattr(instance, "model_name", None)
        or kwargs.get("model")
    )
    if model:
        info["model"] = str(model)

    # Tools
    tools = getattr(instance, "tools", None) or kwargs.get("tools") or []
    if tools:
        tool_names = []
        for t in tools:
            name = (
                getattr(t, "name", None)
                or getattr(t, "__name__", None)
                or type(t).__name__
            )
            tool_names.append(str(name))
        info["tools"] = tool_names

    # Instructions / system prompt (preview)
    instructions = (
        getattr(instance, "instructions", None)
        or getattr(instance, "system_prompt", None)
        or kwargs.get("instructions")
    )
    if instructions:
        info["instructions_preview"] = str(instructions)[:200]

    # Max turns / max tokens
    for field in ("max_turns", "max_tokens"):
        val = getattr(instance, field, None) or kwargs.get(field)
        if val is not None:
            info[field] = val

    return info


def _extract_result_info(result) -> dict:
    """Extract metadata from an agent execution result."""
    info: dict = {}

    # Cost info (ResultMessage has cost)
    cost = getattr(result, "cost", None)
    if cost is not None:
        info["cost"] = float(cost) if not isinstance(cost, dict) else cost

    # Token usage
    usage = getattr(result, "usage", None) or getattr(result, "token_usage", None)
    if usage:
        if hasattr(usage, "input_tokens"):
            info["tokens_in"] = getattr(usage, "input_tokens", 0)
            info["tokens_out"] = getattr(usage, "output_tokens", 0)
        elif isinstance(usage, dict):
            info["tokens_in"] = usage.get("input_tokens", 0)
            info["tokens_out"] = usage.get("output_tokens", 0)

    # Success status
    success = getattr(result, "success", None)
    if success is not None:
        info["success"] = bool(success)

    # Final output / text
    output = (
        getattr(result, "final_output", None)
        or getattr(result, "output", None)
        or getattr(result, "text", None)
        or getattr(result, "content", None)
    )
    if output:
        info["output_preview"] = str(output)[:500]

    # Tool calls made
    tool_calls = getattr(result, "tool_calls", None) or getattr(
        result, "tools_used", None
    )
    if tool_calls:
        names = []
        for tc in tool_calls:
            name = (
                getattr(tc, "name", None) or getattr(tc, "tool_name", None) or str(tc)
            )
            names.append(str(name))
        info["tool_calls_made"] = names

    # Messages count
    messages = getattr(result, "messages", None)
    if messages and hasattr(messages, "__len__"):
        info["message_count"] = len(messages)

    return info


# ---------------------------------------------------------------------------
# Client-level wrappers (Claude.agent / Claude.create_agent)
# ---------------------------------------------------------------------------


def _sync_client_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``Claude.agent()`` or ``Claude.create_agent()``."""
    try:
        from ..tracing.spans import start_agent_span
    except Exception:
        return wrapped(*args, **kwargs)

    info = _extract_agent_info(instance, args, kwargs)
    agent_name = info.get("agent_name", "claude.agent")

    try:
        span = start_agent_span(
            agent_name=agent_name,
            workflow_name="claude_agent_sdk",
        )
        _set_span_attributes(span, info)
    except Exception:
        return wrapped(*args, **kwargs)

    start_time = time.monotonic()
    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        duration_ms = (time.monotonic() - start_time) * 1000
        try:
            result_info = _extract_result_info(result)
            _set_result_attributes(span, result_info, duration_ms)
            _record_to_context(agent_name, info, result_info)
        except Exception:
            pass
        return result
    finally:
        span.end()


async def _async_client_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``Claude.agent()`` or ``Claude.create_agent()``."""
    try:
        from ..tracing.spans import start_agent_span
    except Exception:
        return await wrapped(*args, **kwargs)

    info = _extract_agent_info(instance, args, kwargs)
    agent_name = info.get("agent_name", "claude.agent")

    try:
        span = start_agent_span(
            agent_name=agent_name,
            workflow_name="claude_agent_sdk",
        )
        _set_span_attributes(span, info)
    except Exception:
        return await wrapped(*args, **kwargs)

    start_time = time.monotonic()
    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        duration_ms = (time.monotonic() - start_time) * 1000
        try:
            result_info = _extract_result_info(result)
            _set_result_attributes(span, result_info, duration_ms)
            _record_to_context(agent_name, info, result_info)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Agent-level wrappers (Agent.run / Runner.run etc.)
# ---------------------------------------------------------------------------


def _sync_agent_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``Agent.run`` / ``Runner.run_sync`` etc."""
    try:
        from ..tracing.spans import start_agent_span
    except Exception:
        return wrapped(*args, **kwargs)

    info = _extract_agent_info(instance, args, kwargs)
    agent_name = info.get("agent_name", "claude.agent")

    try:
        span = start_agent_span(
            agent_name=agent_name,
            workflow_name="claude_agent_run",
        )
        _set_span_attributes(span, info)
    except Exception:
        return wrapped(*args, **kwargs)

    start_time = time.monotonic()
    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        duration_ms = (time.monotonic() - start_time) * 1000
        try:
            result_info = _extract_result_info(result)
            _set_result_attributes(span, result_info, duration_ms)
            _record_to_context(agent_name, info, result_info)
        except Exception:
            pass
        return result
    finally:
        span.end()


async def _async_agent_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``Agent.run_async`` / ``Runner.run`` etc."""
    try:
        from ..tracing.spans import start_agent_span
    except Exception:
        return await wrapped(*args, **kwargs)

    info = _extract_agent_info(instance, args, kwargs)
    agent_name = info.get("agent_name", "claude.agent")

    try:
        span = start_agent_span(
            agent_name=agent_name,
            workflow_name="claude_agent_run",
        )
        _set_span_attributes(span, info)
    except Exception:
        return await wrapped(*args, **kwargs)

    start_time = time.monotonic()
    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        duration_ms = (time.monotonic() - start_time) * 1000
        try:
            result_info = _extract_result_info(result)
            _set_result_attributes(span, result_info, duration_ms)
            _record_to_context(agent_name, info, result_info)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Span attribute helpers
# ---------------------------------------------------------------------------


def _set_span_attributes(span, info: dict) -> None:
    """Set agent configuration attributes on the span."""
    span.set_attribute("waxell.claude_agents.agent_name", info.get("agent_name", ""))

    if "model" in info:
        span.set_attribute("waxell.claude_agents.model", info["model"])
    if "tools" in info:
        span.set_attribute("waxell.claude_agents.tools", info["tools"])
        span.set_attribute("waxell.claude_agents.tool_count", len(info["tools"]))
    if "instructions_preview" in info:
        span.set_attribute(
            "waxell.claude_agents.instructions_preview", info["instructions_preview"]
        )
    if "max_turns" in info:
        span.set_attribute("waxell.claude_agents.max_turns", info["max_turns"])
    if "max_tokens" in info:
        span.set_attribute("waxell.claude_agents.max_tokens", info["max_tokens"])


def _set_result_attributes(span, result_info: dict, duration_ms: float) -> None:
    """Set execution result attributes on the span."""
    span.set_attribute("waxell.claude_agents.duration_ms", round(duration_ms, 2))

    if "success" in result_info:
        span.set_attribute("waxell.claude_agents.success", result_info["success"])
    if "tokens_in" in result_info:
        span.set_attribute("waxell.claude_agents.tokens_in", result_info["tokens_in"])
    if "tokens_out" in result_info:
        span.set_attribute("waxell.claude_agents.tokens_out", result_info["tokens_out"])
    if "cost" in result_info and isinstance(result_info["cost"], (int, float)):
        span.set_attribute("waxell.claude_agents.cost", result_info["cost"])
    if "tool_calls_made" in result_info:
        span.set_attribute(
            "waxell.claude_agents.tool_calls_made", result_info["tool_calls_made"]
        )
    if "message_count" in result_info:
        span.set_attribute(
            "waxell.claude_agents.message_count", result_info["message_count"]
        )
    if "output_preview" in result_info:
        span.set_attribute(
            "waxell.claude_agents.output_preview", result_info["output_preview"]
        )


# ---------------------------------------------------------------------------
# Context recording
# ---------------------------------------------------------------------------


def _record_to_context(agent_name: str, info: dict, result_info: dict) -> None:
    """Record execution to the Waxell context."""
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            ctx.record_step(
                f"claude_agent:{agent_name}",
                output={
                    "model": info.get("model", ""),
                    "tools": info.get("tools", []),
                    "success": result_info.get("success"),
                    "tokens_in": result_info.get("tokens_in", 0),
                    "tokens_out": result_info.get("tokens_out", 0),
                    "tool_calls_made": result_info.get("tool_calls_made", []),
                    "output_preview": result_info.get("output_preview", ""),
                },
            )
    except Exception:
        pass


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
