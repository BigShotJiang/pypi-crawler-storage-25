"""D2 — unified decision API behind a feature flag.

Aggregates the three legacy decision points (local guard / cloud
policy check / MCP self-check tool) behind a single function so callers
get one canonical answer. Default OFF — caller opt-in via
`WAXELL_UNIFIED_DECISIONS=1` env var while we run parity in production.

Aggregation rule (matches the existing hook-handler chain semantics):
    1. Local guard runs first (fast, in-process).
    2. If local returns `deny` → final = `deny` (short-circuit).
    3. Otherwise call the cloud policy check (network).
    4. If cloud returns `block` → final = `deny`.
    5. If either returned `ask`/`warn` → final = `ask` (UX surface).
    6. Otherwise → `allow`.

The unified result preserves both sources' data so dashboards can
distinguish "denied by local rule" vs "denied by server policy."
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from typing import Any, Optional

logger = logging.getLogger("waxell.decisions.unified")


# ---------------------------------------------------------------------------
# Result type
# ---------------------------------------------------------------------------


@dataclass
class UnifiedDecisionResult:
    """Single canonical answer aggregating all decision points.

    `action` is the user-facing verdict. `sources` lists which decision
    points contributed (so dashboards can show "denied by local rule"
    vs "denied by server policy"). `policy_provenance` is the D1
    metadata from the server side when applicable.
    """

    action: str  # "allow" | "ask" | "deny"
    reason: str = ""
    violations: list[str] = field(default_factory=list)
    sources: list[str] = field(default_factory=list)
    local_rule: str = ""
    policy_provenance: dict | None = None
    hop_latencies_ms: dict[str, float] = field(default_factory=dict)

    @property
    def should_block(self) -> bool:
        return self.action == "deny"

    @property
    def should_ask(self) -> bool:
        return self.action == "ask"


# ---------------------------------------------------------------------------
# Feature flag
# ---------------------------------------------------------------------------


def is_unified_decisions_enabled() -> bool:
    """Read `WAXELL_UNIFIED_DECISIONS` env. `1` / `true` / `yes` → enabled.

    Default off so existing callers keep using the legacy two-layer
    chain. Operators flip this once parity has been verified in their
    environment.
    """
    raw = os.environ.get("WAXELL_UNIFIED_DECISIONS", "").strip().lower()
    return raw in ("1", "true", "yes", "on")


# ---------------------------------------------------------------------------
# The unified entry point
# ---------------------------------------------------------------------------


def evaluate_decision(
    *,
    tool_name: str,
    tool_input: dict | None = None,
    agent_slug: str = "",
    agent_id: str = "",
    cwd: str = "",
    modified_files: Optional[list[str]] = None,
    peer_modified_files: Optional[list[str]] = None,
    config=None,  # GuardConfig instance, or None to load via guard.load_config
    client=None,  # WaxellObserveClient instance, or None for local-guard-only
) -> UnifiedDecisionResult:
    """Run all applicable decision points and aggregate into a single
    UnifiedDecisionResult. Best-effort: an error in any single source
    degrades to "no contribution from that source"; the function never
    raises.

    Local guard is always run (it's pure regex, in-process, fast).
    Cloud policy check runs only if `client` is configured. The MCP
    `waxell_check_policy` self-check tool is intentionally NOT called
    here — it's the consumer (the model) that calls into this same
    function via the MCP server, so a recursive call would be
    nonsensical. The MCP path stays separate.

    Aggregation:
        - Local `deny` → return immediately (short-circuit, no network).
        - Else cloud `block` → return as `deny`.
        - Else any `ask`/`warn` → `ask`.
        - Else → `allow`.
    """
    import time

    tool_input = tool_input or {}
    sources: list[str] = []
    violations: list[str] = []
    local_rule = ""
    hop_latencies: dict[str, float] = {}

    # ---- Layer 1: local guard ------------------------------------------------
    t0 = time.monotonic()
    try:
        # Lazy import — guard.py is the canonical local-guard module today.
        from ..integrations.claude_code import guard as _guard_mod

        if config is None:
            config = _guard_mod.load_config(cwd=cwd, client=client)

        guard_result = _guard_mod.check_tool_use(
            tool_name=tool_name,
            tool_input=tool_input,
            config=config,
            cwd=cwd,
            modified_files=modified_files,
            peer_modified_files=peer_modified_files,
        )
        sources.append("local-guard")
        hop_latencies["local-guard"] = (time.monotonic() - t0) * 1000.0

        if guard_result.action == "deny":
            return UnifiedDecisionResult(
                action="deny",
                reason=f"Waxell guard: {'; '.join(guard_result.violations)}",
                violations=list(guard_result.violations or []),
                sources=sources,
                local_rule=getattr(guard_result, "rule", "") or "",
                hop_latencies_ms=hop_latencies,
            )
        if guard_result.action == "ask":
            violations.extend(guard_result.violations or [])
            local_rule = getattr(guard_result, "rule", "") or ""
    except Exception as exc:
        # Local-guard error is not fatal; fall through to cloud path.
        # Don't pollute `sources` because we got nothing useful.
        logger.debug("[unified] local-guard error: %s", exc)
        hop_latencies["local-guard"] = (time.monotonic() - t0) * 1000.0

    # ---- Layer 2: cloud policy check ----------------------------------------
    cloud_action = "allow"
    cloud_reason = ""
    cloud_provenance: dict | None = None

    if (
        client is not None
        and getattr(client, "config", None)
        and getattr(client.config, "is_configured", False)
    ):
        agent_slug = agent_slug or _safe_attr(client.config, "agent_slug", "")
        if agent_slug:
            t0 = time.monotonic()
            try:
                policy_result = client.check_policy_sync(
                    agent_name=agent_slug,
                    workflow_name=f"tool:{tool_name}",
                    agent_id=agent_id,
                )
                sources.append("server-policy")
                hop_latencies["server-policy"] = (time.monotonic() - t0) * 1000.0
                cloud_action = (getattr(policy_result, "action", "") or "").lower()
                cloud_reason = getattr(policy_result, "reason", "") or ""
                # PolicyCheckResult exposes metadata in different ways across
                # versions; try a couple of paths.
                metadata = getattr(policy_result, "metadata", None) or {}
                if isinstance(metadata, dict):
                    cloud_provenance = metadata.get("provenance") or None
            except Exception as exc:
                logger.debug("[unified] server-policy error: %s", exc)
                hop_latencies["server-policy"] = (time.monotonic() - t0) * 1000.0

    # ---- Aggregate ----------------------------------------------------------
    if cloud_action == "block":
        return UnifiedDecisionResult(
            action="deny",
            reason=f"Waxell policy blocked: {cloud_reason or 'Policy violation'}",
            violations=violations,
            sources=sources,
            local_rule=local_rule,
            policy_provenance=cloud_provenance,
            hop_latencies_ms=hop_latencies,
        )

    if cloud_action == "warn":
        violations.append(f"Policy warning: {cloud_reason}".rstrip(": "))

    if violations:
        return UnifiedDecisionResult(
            action="ask",
            reason="Waxell: " + "; ".join(violations),
            violations=violations,
            sources=sources,
            local_rule=local_rule,
            policy_provenance=cloud_provenance,
            hop_latencies_ms=hop_latencies,
        )

    return UnifiedDecisionResult(
        action="allow",
        reason="",
        violations=[],
        sources=sources,
        local_rule="",
        policy_provenance=cloud_provenance,
        hop_latencies_ms=hop_latencies,
    )


def _safe_attr(obj: Any, name: str, default: str) -> str:
    try:
        return str(getattr(obj, name, default) or default)
    except Exception:
        return default
