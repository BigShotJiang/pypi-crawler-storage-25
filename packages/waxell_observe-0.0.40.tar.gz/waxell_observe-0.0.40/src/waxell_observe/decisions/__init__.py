"""Unified decision API (D2 — feature-flagged).

Today three independent decision points run in the Claude Code path:

1. **Local guard** (`integrations/claude_code/guard.py:check_tool_use`) —
   pure regex/glob over Bash/Edit/Write inputs. Synchronous, no network.
2. **Cloud policy check** (`client.check_policy_sync`) — server-side
   `DynamicPolicyManager` evaluation against the tenant's seeded
   policies. Network call, returns `PolicyCheckResult`.
3. **MCP `waxell_check_policy`** (`integrations/claude_code/mcp_server.py`)
   — exposed to the model itself for proactive self-check. Same
   server-side policy machinery as #2.

The three speak different languages (`GuardResult` vs
`PolicyCheckResult` vs MCP tool dict) and apply different fail modes.
The hook handler currently chains 1 → 2 manually.

This module is the **unified decision authority** that consolidates
those three behind a single function `evaluate_decision()` returning a
single `UnifiedDecisionResult`. The aggregation rule is "first deny
wins; else collect asks/warnings; else allow."

**Feature flag:** `WAXELL_UNIFIED_DECISIONS=1` opts callers into the
unified path. Default off — every existing caller continues to use the
legacy two-layer chain. The intent is to roll out as additive,
parity-tested in production for several weeks, then cut over callers
one at a time.

The cutover plan (NOT yet shipped — explicit follow-up):
1. Hook handler's PreToolUse path calls `evaluate_decision()` when the
   flag is set; falls back to the legacy chain otherwise.
2. The MCP `waxell_check_policy` tool calls `evaluate_decision()` so
   self-checks see the same answer as the hook would.
3. Once both paths are unified and parity holds, the legacy direct
   calls in hook handler get deleted.
"""

from .unified import (
    UnifiedDecisionResult,
    evaluate_decision,
    is_unified_decisions_enabled,
)

__all__ = [
    "UnifiedDecisionResult",
    "evaluate_decision",
    "is_unified_decisions_enabled",
]
