"""Report generation for AI cost tracking."""

from pathlib import Path
from typing import Dict, Any, List
from datetime import datetime, timedelta
import json


# Advanced estimation constants
SESSION_GAP_THRESHOLD = timedelta(hours=2)    # Gaps > 2h define a new session
CONTEXT_SWITCH_PENALTY = timedelta(minutes=15) # Penalty for gaps between 30m and 2h
MIN_SESSION_DURATION = timedelta(hours=1.0)   # Minimum work block (1h)
DAILY_PREP_BUFFER = timedelta(hours=1.5)      # Setup/Research overhead per author/day


def calculate_human_time(commits: List[Dict[str, Any]]) -> float:
    """Calculate human development time with realistic overhead.
    
    1. Groups commits by Author and Date.
    2. Adds a 1.5h Daily Prep Buffer (Research/Setup) per author-day.
    3. Identifies Work Sessions (gaps > 2h).
    4. Applies Context Switching Penalty (15m) for gaps between 30m and 2h.
    5. Ensures minimum session duration (1h).
    """
    if not commits:
        return 0.0
    
    # Group commits by author
    authors_data = {}
    for commit in commits:
        author = commit.get("author", "unknown")
        if author not in authors_data:
            authors_data[author] = []
        
        try:
            date_str = commit.get("date", "")
            if date_str:
                dt = datetime.fromisoformat(date_str.replace("Z", "+00:00"))
                authors_data[author].append(dt)
        except:
            continue
    
    total_seconds = 0.0
    
    for author, dates in authors_data.items():
        if not dates:
            continue
        
        dates.sort()
        
        # Track unique days worked for daily buffers
        days_worked = set(d.date() for d in dates)
        total_seconds += len(days_worked) * DAILY_PREP_BUFFER.total_seconds()
        
        session_start = dates[0]
        session_last = dates[0]
        author_session_seconds = 0.0
        
        for i in range(1, len(dates)):
            gap = dates[i] - session_last
            
            if gap > SESSION_GAP_THRESHOLD:
                # End session: duration + buffer (enforce minimum)
                session_duration = max((session_last - session_start).total_seconds(), 
                                      MIN_SESSION_DURATION.total_seconds())
                author_session_seconds += session_duration
                # Start new session
                session_start = dates[i]
            elif gap > timedelta(minutes=30):
                # Context switch penalty
                author_session_seconds += CONTEXT_SWITCH_PENALTY.total_seconds()
            
            session_last = dates[i]
        
        # Add final session for this author
        session_duration = max((session_last - session_start).total_seconds(), 
                              MIN_SESSION_DURATION.total_seconds())
        author_session_seconds += session_duration
        total_seconds += author_session_seconds
    
    return total_seconds / 3600.0


def generate_markdown_report(results: Dict[str, Any], output_path: Path) -> str:
    """Generate markdown report with cost visualizations."""
    summary = results["summary"]
    commits = results["commits"]
    
    # Calculate additional metrics
    model = summary["model"]
    total_cost = summary["total_cost"]
    total_commits = summary["total_commits"]
    avg_cost_per_commit = total_cost / total_commits if total_commits > 0 else 0
    
    # Generate cost chart data
    daily_costs = {}
    for commit in commits:
        date = commit["date"][:10]  # YYYY-MM-DD
        cost = commit["cost"]
        daily_costs[date] = daily_costs.get(date, 0) + cost
    
    # Sort dates
    sorted_dates = sorted(daily_costs.keys())
    
    md_content = f"""# AI Cost Analysis Report

> Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
> Model: `{model}`
> Analysis Mode: {summary.get("mode", "unknown")}

## Summary

| Metric | Value |
|--------|-------|
| **Total Cost** | {summary["total_cost_formatted"]} |
| **Total Commits** | {total_commits} |
| **Average per Commit** | ${avg_cost_per_commit:.4f} |
| **Hours Saved** | {summary["total_hours_saved"]:.1f}h |
| **Value Generated** | ${summary["total_value_generated"]:.2f} |
| **ROI** | {summary["average_roi"]} |

## Cost Visualizations

### Daily Cost Breakdown

```
"""
    
    # Generate ASCII bar chart for daily costs
    if sorted_dates:
        max_cost = max(daily_costs.values())
        chart_width = 40
        
        for date in sorted_dates[-14:]:  # Last 14 days
            cost = daily_costs[date]
            bar_length = int((cost / max_cost) * chart_width) if max_cost > 0 else 0
            bar = "█" * bar_length
            md_content += f"{date} | {bar} ${cost:.4f}\n"
    
    md_content += f"""```

### Cumulative Cost Over Time

```
"""
    
    # Generate cumulative chart
    cumulative = 0
    for date in sorted_dates:
        cumulative += daily_costs[date]
        bar_length = int((cumulative / total_cost) * 30) if total_cost > 0 else 0
        bar = "█" * bar_length
        md_content += f"{date} | {bar} ${cumulative:.4f}\n"
    
    md_content += f"""```

## Recent AI Commits

| Commit | Date | Cost | Message |
|--------|------|------|---------|
"""
    
    # Add last 10 commits
    for c in commits[:10]:
        msg = c["commit_message"][:40].replace("\n", " ").replace("|", "\\|")
        md_content += f"| {c['commit_hash']} | {c['date'][:10]} | {c['cost_formatted']} | {msg} |\n"
    
    md_content += f"""
## Badge

![AI Cost](https://img.shields.io/badge/AI%20Cost-{summary["total_cost_formatted"].replace("$", "%24")}-{get_cost_color(total_cost)})
![Commits](https://img.shields.io/badge/AI%20Commits-{total_commits}-blue)
![Model](https://img.shields.io/badge/Model-{model.replace("/", "%2F")}-lightgrey)

## Configuration

```bash
# To reproduce this analysis
aicost analyze --repo . --model {model} --full-history
```

---
*Report generated by [ai-cost-tracker](https://github.com/your-org/ai-cost-tracker)*
"""
    
    # Write to file
    output_path.write_text(md_content)
    return md_content


def generate_html_report(results: Dict[str, Any], output_path: Path) -> str:
    """Generate interactive HTML report with visualizations."""
    summary = results["summary"]
    commits = results["commits"]
    
    # Prepare chart data
    daily_costs = {}
    daily_commits = {}
    for commit in commits:
        date = commit["date"][:10]
        daily_costs[date] = daily_costs.get(date, 0) + commit["cost"]
        daily_commits[date] = daily_commits.get(date, 0) + 1
    
    sorted_dates = sorted(daily_costs.keys())
    
    # Calculate cumulative
    cumulative = []
    running_total = 0
    for date in sorted_dates:
        running_total += daily_costs[date]
        cumulative.append({"date": date, "cost": daily_costs[date], "total": running_total})
    
    html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Cost Analysis Report</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background: #f5f5f5;
        }}
        .header {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 20px;
        }}
        .header h1 {{
            margin: 0 0 10px 0;
        }}
        .header .meta {{
            opacity: 0.9;
        }}
        .metrics {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }}
        .metric-card {{
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            text-align: center;
        }}
        .metric-card .value {{
            font-size: 2em;
            font-weight: bold;
            color: #667eea;
        }}
        .metric-card .label {{
            color: #666;
            margin-top: 5px;
        }}
        .chart-container {{
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }}
        .chart-container h2 {{
            margin-top: 0;
        }}
        .badges {{
            background: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
        }}
        .commits-table {{
            background: white;
            padding: 20px;
            border-radius: 8px;
            overflow-x: auto;
        }}
        table {{
            width: 100%;
            border-collapse: collapse;
        }}
        th, td {{
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }}
        th {{
            font-weight: 600;
            color: #333;
        }}
        tr:hover {{
            background: #f5f5f5;
        }}
        .badge {{
            display: inline-block;
            padding: 5px 10px;
            margin: 5px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: bold;
        }}
        .badge-cost {{ background: #e74c3c; color: white; }}
        .badge-commits {{ background: #3498db; color: white; }}
        .badge-model {{ background: #95a5a6; color: white; }}
    </style>
</head>
<body>
    <div class="header">
        <h1>🤖 AI Cost Analysis Report</h1>
        <div class="meta">
            Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")} | 
            Model: {summary["model"]} | 
            Mode: {summary.get("mode", "unknown")}
        </div>
    </div>

    <div class="metrics">
        <div class="metric-card">
            <div class="value">{summary["total_cost_formatted"]}</div>
            <div class="label">Total Cost</div>
        </div>
        <div class="metric-card">
            <div class="value">{summary["total_commits"]}</div>
            <div class="label">AI Commits</div>
        </div>
        <div class="metric-card">
            <div class="value">{summary["total_hours_saved"]:.1f}h</div>
            <div class="label">Hours Saved</div>
        </div>
        <div class="metric-card">
            <div class="value">{summary["average_roi"]}</div>
            <div class="label">ROI</div>
        </div>
    </div>

    <div class="badges">
        <span class="badge badge-cost">💰 Total: {summary["total_cost_formatted"]}</span>
        <span class="badge badge-commits">📝 Commits: {summary["total_commits"]}</span>
        <span class="badge badge-model">🤖 {summary["model"]}</span>
    </div>

    <div class="chart-container">
        <h2>📊 Daily Cost Trend</h2>
        <canvas id="dailyChart"></canvas>
    </div>

    <div class="chart-container">
        <h2>📈 Cumulative Cost</h2>
        <canvas id="cumulativeChart"></canvas>
    </div>

    <div class="commits-table">
        <h2>📝 Recent AI Commits</h2>
        <table>
            <thead>
                <tr>
                    <th>Commit</th>
                    <th>Date</th>
                    <th>Cost</th>
                    <th>Author</th>
                    <th>Message</th>
                </tr>
            </thead>
            <tbody>
"""
    
    # Add commit rows
    for c in commits[:50]:
        msg = c["commit_message"][:60].replace("<", "&lt;").replace(">", "&gt;")
        html_content += f"""                <tr>
                    <td><code>{c['commit_hash']}</code></td>
                    <td>{c['date'][:10]}</td>
                    <td>{c['cost_formatted']}</td>
                    <td>{c['author']}</td>
                    <td>{msg}</td>
                </tr>
"""
    
    # Chart data as JSON
    chart_data = json.dumps(cumulative)
    
    html_content += f"""            </tbody>
        </table>
    </div>

    <script>
        // Daily cost chart
        const dailyCtx = document.getElementById('dailyChart').getContext('2d');
        const dailyChart = new Chart(dailyCtx, {{
            type: 'bar',
            data: {{
                labels: {json.dumps(sorted_dates[-30:])},
                datasets: [{{
                    label: 'Daily Cost ($)',
                    data: {[daily_costs.get(d, 0) for d in sorted_dates[-30:]]},
                    backgroundColor: 'rgba(102, 126, 234, 0.6)',
                    borderColor: 'rgba(102, 126, 234, 1)',
                    borderWidth: 1
                }}]
            }},
            options: {{
                responsive: true,
                plugins: {{
                    legend: {{ display: false }}
                }},
                scales: {{
                    y: {{
                        beginAtZero: true,
                        ticks: {{
                            callback: function(value) {{
                                return '$' + value.toFixed(2);
                            }}
                        }}
                    }}
                }}
            }}
        }});

        // Cumulative chart
        const cumCtx = document.getElementById('cumulativeChart').getContext('2d');
        const cumData = {chart_data};
        const cumChart = new Chart(cumCtx, {{
            type: 'line',
            data: {{
                labels: cumData.map(d => d.date),
                datasets: [{{
                    label: 'Cumulative Cost ($)',
                    data: cumData.map(d => d.total),
                    fill: true,
                    backgroundColor: 'rgba(118, 75, 162, 0.2)',
                    borderColor: 'rgba(118, 75, 162, 1)',
                    tension: 0.4
                }}]
            }},
            options: {{
                responsive: true,
                plugins: {{
                    legend: {{ display: false }}
                }},
                scales: {{
                    y: {{
                        beginAtZero: true,
                        ticks: {{
                            callback: function(value) {{
                                return '$' + value.toFixed(2);
                            }}
                        }}
                    }}
                }}
            }}
        }});
    </script>
</body>
</html>
"""
    
    output_path.write_text(html_content)
    return html_content


def get_cost_color(cost: float) -> str:
    """Get badge color based on cost level."""
    if cost < 1:
        return "brightgreen"
    elif cost < 5:
        return "green"
    elif cost < 10:
        return "yellow"
    elif cost < 50:
        return "orange"
    else:
        return "red"


def update_readme_badge(repo_path: Path, results: Dict[str, Any]) -> bool:
    """Update README.md with cost badge including human time calculation."""
    readme_path = repo_path / "README.md"
    if not readme_path.exists():
        return False
    
    summary = results["summary"]
    model = summary["model"]
    total_cost = summary["total_cost"]
    commits = results.get("commits", [])
    
    # Get all commits (not just AI) for accurate human time calculation
    from .git_parser import parse_commits
    all_commits_data = parse_commits(
        str(repo_path),
        max_count=1000,
        ai_only=False,
        full_history=True
    )
    # Convert to dict format expected by calculate_human_time
    all_commits = [
        {"date": c[0].committed_datetime.isoformat(), "author": c[0].author.name} 
        for c in all_commits_data
    ]
    
    # Calculate human time with 30-min deduplication using ALL commits
    human_hours = calculate_human_time(all_commits)
    human_cost = human_hours * 100  # $100/hour rate
    
    # Calculate ROI
    roi = (human_cost / total_cost) if total_cost > 0 else 0
    
    # Create badge lines with standout colors
    cost_badge = f"![AI Cost](https://img.shields.io/badge/AI%20Cost-${total_cost:.2f}-orange)"
    human_time_badge = f"![Human Time](https://img.shields.io/badge/Human%20Time-{human_hours:.1f}h-blue)"
    model_badge = f"![Model](https://img.shields.io/badge/Model-{model.replace('/', '%2F').replace('-', '--')}-lightgrey)"
    
    badge_section = f"""## AI Cost Tracking

{cost_badge} {human_time_badge} {model_badge}

This project uses AI-generated code.

**Costs:**
- 🤖 **LLM usage:** {summary['total_cost_formatted']} ({summary['total_commits']} commits)
- 👤 **Human dev:** ~${human_cost:.0f} ({human_hours:.1f}h @ $100/h, 30min dedup)
- 📊 **ROI:** {roi:.0f}x savings vs full manual

Generated on {datetime.now().strftime("%Y-%m-%d")} using [{model}](https://openrouter.ai/models/{model})

---

"""
    
    content = readme_path.read_text()
    
    # Check if badge section already exists
    if "## AI Cost Tracking" in content:
        # Replace existing section
        import re
        pattern = r"## AI Cost Tracking\n.*?\n---\n\n"
        content = re.sub(pattern, badge_section, content, flags=re.DOTALL)
    else:
        # Add after first heading
        lines = content.split("\n")
        # Find first # or ## heading
        insert_idx = 0
        for i, line in enumerate(lines):
            if line.startswith("# "):
                insert_idx = i + 1
                break
        lines.insert(insert_idx, "\n" + badge_section)
        content = "\n".join(lines)
    
    readme_path.write_text(content)
    return True
