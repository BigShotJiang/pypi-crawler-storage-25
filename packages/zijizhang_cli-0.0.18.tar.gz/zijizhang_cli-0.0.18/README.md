# zijizhang-cli

Cli tool for zijizhang

## Requirements

- Python 3 or higher – [Download Python](https://www.python.org/downloads/)

## Installation

It is **strongly recommended** to install this tool inside a Python virtual environment to avoid dependency conflicts with other Python projects on your system.

You can choose **one** of the following installation methods:

- Use Python's built-in `venv`
- Use `uv`

You only need to follow one method, not both.

### Option 1: Install with `venv`

#### Step 1: Create a virtual environment

Open your terminal and choose a location for the environment. A common practice is to place it in your home directory as a hidden folder (e.g., `~/.my-cli-tool-env`). Run:

```shell
python3 -m venv ~/.my-cli-tool-env
```

#### Step 2: Activate the virtual environment

- Linux / macOS:

```shell
source ~/.my-cli-tool-env/bin/activate
```

- Windows (Command Prompt):

```bash
.my-cli-tool-env\Scripts\activate.bat
```

- Windows (PowerShell):

```bash
.my-cli-tool-env\Scripts\Activate.ps1
```

You will see (`.my-cli-tool-env`) appear at the beginning of your command prompt, indicating the virtual environment is active.

#### Step 3: Install the tool

With the virtual environment activated, install the package from PyPI:

```shell
pip install --upgrade zijizhang-cli
```

That's it! The CLI command `zijizhang-cli` is now available inside this virtual environment.

### Option 2: Install with `uv`

If you prefer using `uv`, you can create and manage the virtual environment with it instead.

#### Step 1: Install `uv`

Follow the official guide to install `uv`:

[Install uv](https://docs.astral.sh/uv/getting-started/installation/)

#### Step 2: Create a virtual environment

```shell
uv venv ~/.my-cli-tool-env
```

#### Step 3: Activate the virtual environment

- Linux / macOS:

```shell
source ~/.my-cli-tool-env/bin/activate
```

- Windows (Command Prompt):

```bash
.my-cli-tool-env\Scripts\activate.bat
```

- Windows (PowerShell):

```bash
.my-cli-tool-env\Scripts\Activate.ps1
```

#### Step 4: Install the tool

With the virtual environment activated, install the package with `uv`:

```shell
uv pip install --upgrade zijizhang-cli
```

That's it! The CLI command `zijizhang-cli` is now available inside this virtual environment.

### Usage

Once the virtual environment is activated, you can run the tool:

```shell
zijizhang-cli --help
```

## Why a virtual environment?

Using a virtual environment prevents version clashes between Python packages required by this tool and other Python applications on your system. It also keeps your global Python installation clean. For more background, see [Python Virtual Environments: A Primer](https://realpython.com/python-virtual-environments-a-primer/).
