import re
from datetime import datetime
from pathlib import Path

from app.api import zjz_api
from app.service.config_manager import cfg_mgr

class InvoiceService:
    def _validate_page_and_date_range(self, current: int, invoice_date_begin: str, invoice_date_end: str) -> tuple:
        if not current or current < 1:
            current = 1
        if (invoice_date_begin and not invoice_date_end) or (invoice_date_end and not invoice_date_begin):
            return False, {
                'code': 400,
                'msg': 'invoice_date_begin 和 invoice_date_end 需要同时填写',
            }
        if invoice_date_begin and not re.match(r'^\d{4}-\d{2}-\d{2}$', invoice_date_begin):
            return False, {
                'code': 400,
                'msg': 'invoice_date_begin 格式不正确，期望 YYYY-MM-DD',
            }
        if invoice_date_end and not re.match(r'^\d{4}-\d{2}-\d{2}$', invoice_date_end):
            return False, {
                'code': 400,
                'msg': 'invoice_date_end 格式不正确，期望 YYYY-MM-DD',
            }
        if invoice_date_begin and invoice_date_end:
            try:
                begin_dt = datetime.strptime(invoice_date_begin, '%Y-%m-%d')
                end_dt = datetime.strptime(invoice_date_end, '%Y-%m-%d')
                if begin_dt > end_dt:
                    return False, {
                        'code': 400,
                        'msg': 'invoice_date_begin 不能晚于 invoice_date_end',
                    }
            except ValueError:
                return False, {
                    'code': 400,
                    'msg': 'invoice_date_begin / invoice_date_end 解析失败，期望 YYYY-MM-DD',
                }
        return True, {
            'current': current,
            'invoice_date_begin': invoice_date_begin,
            'invoice_date_end': invoice_date_end,
        }

    # 获取销项/开出的发票列表
    def get_sales_invoice_data_list(self, uid: str, current: int = 1, invoice_number: str = '', invoice_date_begin: str = '', invoice_date_end: str = ''):
        uid = cfg_mgr.get_abs_uid(uid)

        ok, validated = self._validate_page_and_date_range(current, invoice_date_begin, invoice_date_end)
        if not ok:
            return validated
        current = validated['current']

        res = zjz_api.get_sales_invoice_data_list(uid, current, invoice_number, invoice_date_begin, invoice_date_end)
        if res.get('code') != 200:
            return {
                'code': res['code'],
                'msg': res['msg'],
            }
        
        data = res.get('data') or {}
        items = data.get('items') or []
        total_cnt = data.get('total_count') or 0
        return {
            'code': 200,
            'msg': "查询成功",
            'data': {
                'uid': uid,
                'cnt': total_cnt,
                'invoice_list': items,
            },
        }

    def set_month_no_sales_invoice(self, uid: str, year: int, month: int) -> dict:
        uid = cfg_mgr.get_abs_uid(uid)

        if not year or year < 1970:
            return {
                'code': 400,
                'msg': 'year 不合法',
            }
        if not month or month < 1 or month > 12:
            return {
                'code': 400,
                'msg': 'month 不合法（1-12）',
            }
        
        res = zjz_api.set_month_no_sales_invoice(uid, year, month)
        if res.get('code') != 200:
            return res
        return {
            'code': 200,
            'msg': '设置成功',
            'data': {
                'uid': uid,
            }
        }

    # 获取进项/收到的发票列表
    def get_income_invoice_data_list(self, uid: str, current: int = 1, invoice_number: str = '', invoice_date_begin: str = '', invoice_date_end: str = '', status: str = ''):
        uid = cfg_mgr.get_abs_uid(uid)

        ok, validated = self._validate_page_and_date_range(current, invoice_date_begin, invoice_date_end)
        if not ok:
            return validated
        current = validated['current']

        res = zjz_api.get_income_invoice_data_list(uid, current, invoice_number, invoice_date_begin, invoice_date_end, status)
        if res.get('code') != 200:
            return {
                'code': res['code'],
                'msg': res['msg'],
            }
        
        data = res.get('data') or {}
        items = data.get('items') or []
        total_cnt = data.get('total_count') or 0
        return {
            'code': 200,
            'msg': "查询成功",
            'data': {
                'uid': uid,
                'cnt': total_cnt,
                'invoice_list': items,
            },
        }

    def set_month_no_invoice(self, uid: str, year: int, month: int) -> dict:
        uid = cfg_mgr.get_abs_uid(uid)

        if not year or year < 1970:
            return {
                'code': 400,
                'msg': 'year 不合法',
            }
        if not month or month < 1 or month > 12:
            return {
                'code': 400,
                'msg': 'month 不合法（1-12）',
            }
        
        res = zjz_api.set_month_no_invoice(uid, year, month)
        if res.get('code') != 200:
            return res
        return {
            'code': 200,
            'msg': '设置成功',
            'data': {
                'uid': uid,
            }
        }

    # 收到的发票入账要选择的用途
    def invoice_can_choose_use_list(self, uid: str, goods_name: str, total_tax_price: str, total_money: str) -> dict:
        uid = cfg_mgr.get_abs_uid(uid)

        if not goods_name:
            return {
                'code': 400,
                'msg': 'goods_name 不能为空',
            }
        if total_tax_price is None or total_tax_price == '':
            return {
                'code': 400,
                'msg': 'total_tax_price 不能为空',
            }
        if total_money is None or total_money == '':
            return {
                'code': 400,
                'msg': 'total_money 不能为空',
            }
        res = zjz_api.invoice_can_choose_use_list(uid, goods_name, total_tax_price, total_money)
        if res.get('code') != 200:
            return {
                'code': res['code'],
                'msg': res['msg'],
            }
        
        data = res.get('data') or {}
        items = data.get('items') or []
        is_pay = data.get('is_pay') or []
        boss_name = data.get('boss_name') or ''
        return {
            'code': 200,
            'msg': "查询成功",
            'data': {
                'uid': uid,
                'items': items,
                'is_pay': is_pay,
                'boss_name': boss_name,
            },
        }
        
    # 收到的发票选择用途并入账
    def invoice_choose_use(self, uid: str, invoice_id: int, category: str, is_pay: str, payee: str) -> dict:
        uid = cfg_mgr.get_abs_uid(uid)

        if not invoice_id or invoice_id <= 0:
            return {
                'code': 400,
                'msg': 'invoice_id 不合法',
            }
        if not category:
            return {
                'code': 400,
                'msg': 'category 不能为空',
            }
        if not is_pay:
            return {
                'code': 400,
                'msg': 'is_pay 不能为空',
            }
        if is_pay in ['员工垫付', '老板垫付'] and not payee:
            return {
                'code': 400,
                'msg': 'payee 不能为空',
            }
        res = zjz_api.invoice_choose_use(uid, invoice_id, category, is_pay, payee)
        if res.get('code') != 200:
            return {
                'code': res['code'],
                'msg': res['msg'],
            }
        return {
            'code': 200,
            'msg': '入账成功',
            'data': {
                'uid': uid,
            }
        }

    def upload_invoice_file(self, uid: str, file: str) -> dict:
        uid = cfg_mgr.get_abs_uid(uid)
        if not file:
            return {
                'code': 400,
                'msg': 'file 不能为空',
            }

        p = Path(file).expanduser()
        if not p.exists() or not p.is_file():
            return {
                'code': 400,
                'msg': f'file 不存在或不是文件：{p}',
            }

        suffix = p.suffix.lower()
        if suffix not in ['.pdf', '.ofd']:
            return {
                'code': 400,
                'msg': '仅支持上传 pdf 或 ofd 文件',
            }

        res = zjz_api.upload_invoice_file(uid, str(p))
        if res.get('code') != 200:
            return {
                'code': res.get('code', 500),
                'msg': res.get('msg', '上传失败'),
                'data': res.get('data') or {},
            }

        return {
            'code': 200,
            'msg': '上传成功',
            'data': {
                'uid': uid,
                'filename': p.name,
                'file_path': str(p),
                'raw': res.get('data') or {},
            }
        }

    def invoice_file_list(self, uid: str, current: int = 1) -> dict:
        uid = cfg_mgr.get_abs_uid(uid)
        if not current or current < 1:
            current = 1

        res = zjz_api.invoice_file_list(uid, current)
        if res.get('code') != 200:
            return {
                'code': res.get('code', 500),
                'msg': res.get('msg', '查询失败'),
                'data': res.get('data') or {},
            }

        data = res.get('data') or {}
        items = data.get('items') or []
        total = data.get('total')
        if total is None:
            total = data.get('total_count') or 0

        return {
            'code': 200,
            'msg': '查询成功',
            'data': {
                'uid': uid,
                'current': current,
                'total': total,
                'items': items,
            }
        }
