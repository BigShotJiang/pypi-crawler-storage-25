from app.api import zjz_api
from app.service.config_manager import cfg_mgr


class AccountService:
    def create_auth_url(self):
        res = zjz_api.create_auth_url()
        if res.get('code') == 200:
            data = res.get('data')
            cfg_mgr.update_configs({
                'curr_uid': '',
                'token': data.get('auth_key'),
            })
        return res

    # def sms_verify_code(self, phone: str) -> dict:
    #     res = zjz_api.sms_verify_code(phone)
    #     if res.get('code') != 200:
    #         return res
    #     data = res.get('data', {})
    #     expire_in = data.get('expire_in')
    #     return {
    #         'code': 200,
    #         'msg': f'获取成功，请在 {expire_in} 秒内完成验证'
    #     }

    def _get_default_select_user(self, users: list) -> tuple:
        if not users:
            return 0, None
        user_cnt = len(users)
        if user_cnt == 0:
            return 0, None
        if user_cnt == 1:
            return user_cnt, users[0]
        for user in users:
            if user['cpy_id'] and user['cpy_name']:
                return user_cnt, user
        return user_cnt, users[0]

    # def sms_code_login(self, phone: str, code: str) -> dict:
    #     res = zjz_api.verify_sms_code(phone, code)
    #     if res.get('code') != 200:
    #         return res
    #     data = res.get('data')
    #     users = data.get('users', [])
    #     curr_uid = ''
    #     cpy_description_info = ''
    #     user_cnt, curr_user = self._get_default_select_user(users)
    #     if curr_user:
    #         curr_uid = curr_user['uid']
    #         cpy_name = curr_user['cpy_name']
    #         if user_cnt > 1:
    #             cpy_description_info = f'账号下一共有{user_cnt}个公司。'
    #             if cpy_name:
    #                 cpy_description_info += f'当前已经切换至 {cpy_name}'
    #         elif cpy_name:
    #             cpy_description_info = cpy_name
    #     cfg_mgr.update_configs({
    #         'curr_uid': curr_uid,
    #         'token': data.get('token', ''),
    #     })
    #     return {
    #         'code': 200,
    #         'msg': f'账号绑定成功！{cpy_description_info}'
    #     }

    def logout(self) -> dict:
        cfg_mgr.update_configs({
            'curr_uid': '',
            'token': '',
        })
        return {
            'code': 200,
            'msg': f'账号已退出'
        }

    def get_cpy_list(self):
        res = zjz_api.get_account_info()
        if res.get('code') != 200:
            return res
        data = res.get('data')
        cpy_list = data.get('cpy_list', [])
        if not cpy_list or len(cpy_list) == 0:
            return {
                'code': 400,
                'msg': '没有可用的公司列表'
            }
        curr_uid = cfg_mgr.get_config('curr_uid', '')
        if not curr_uid:
            curr_uid = cpy_list[0]['cpy']['uid']
            cfg_mgr.update_config('curr_uid', curr_uid)
        total_cpy = len(cpy_list)
        return {
            'code': 200,
            'msg': f'一共{total_cpy}个公司，当前正使用uid={curr_uid}',
            'data': [
                {
                    'uid': cpy['cpy']['uid'],
                    'cpy_name': cpy['cpy']['cpy_name'],
                    'tax_no': cpy['cpy']['tax_no'],
                    'active': True if cpy['cpy']['uid'] == curr_uid else False,
                }
                for cpy in cpy_list
            ]
        }

    def switch_to(self, uid: str):
        data = self.get_cpy_list()
        users = data.get('data', [])
        if len(users) == 0:
            return {
                'code': 400,
                'msg': '当前没有可切换的公司'
            }
        condition = lambda item: item['uid'] == uid
        user = next((item for item in users if condition(item)), None)
        if not user:
            return {
                'code': 404,
                'msg': f'没有找到符合uid={uid}条件的公司信息'
            }
        cfg_mgr.update_config('curr_uid', uid)
        cpy_name = f" {user['cpy_name']}"
        return {
            'code': 200,
            'msg': f'切换成功{cpy_name}'
        }
