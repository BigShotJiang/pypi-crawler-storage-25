from app.api import zjz_api
from app.service.config_manager import cfg_mgr


class SbService:
    def _validate_year_month(self, year: int, month: int) -> tuple:
        if not year or year < 1970:
            return False, {
                'code': 400,
                'msg': 'year 不合法',
            }
        if not month or month < 1 or month > 12:
            return False, {
                'code': 400,
                'msg': 'month 不合法（1-12）',
            }
        return True, {}

    def _validate_sb_type(self, sb_type: str) -> tuple:
        if not sb_type:
            sb_type = 'normal'
        allowed = {'normal', 'last_month'}
        if sb_type not in allowed:
            return False, {
                'code': 400,
                'msg': "sb_type 不合法（可选：normal、last_month）",
            }
        return True, {
            'sb_type': sb_type,
        }

    def sb_history_list(self, uid: str, current: int = 1) -> dict:
        uid = cfg_mgr.get_abs_uid(uid)
        if not current or current < 1:
            current = 1

        res = zjz_api.sb_history_list(uid, current)
        if res.get('code') != 200:
            return {
                'code': res.get('code', 500),
                'msg': res.get('msg', '查询失败'),
                'data': res.get('data') or {},
            }
        data = res.get('data')
        if data is None:
            data = []
        return {
            'code': 200,
            'msg': res.get('msg', '') or '查询成功',
            'data': {
                'uid': uid,
                'current': current,
                'cnt': len(data),
                'history_list': data,
            }
        }

    def now_month_sb_report_info(self, uid: str = '') -> dict:
        uid = cfg_mgr.get_abs_uid(uid)
        res = zjz_api.now_month_sb_report_info(uid)
        if res.get('code') != 200:
            return {
                'code': res.get('code', 500),
                'msg': res.get('msg', '查询失败'),
                'data': res.get('data') or {},
            }
        data = res.get('data') or {}
        return {
            'code': 200,
            'msg': res.get('msg', '') or '查询成功',
            'data': {
                'uid': uid,
                'reporting_period': data.get('reporting_period', ''),
                'state': data.get('state', ''),
            }
        }

    def get_sb_mx_data(self, uid: str, year: int, month: int, sb_type: str = 'normal') -> dict:
        uid = cfg_mgr.get_abs_uid(uid)

        ok, err = self._validate_year_month(year, month)
        if not ok:
            return err
        ok, validated = self._validate_sb_type(sb_type)
        if not ok:
            return validated
        sb_type = validated['sb_type']

        res = zjz_api.get_sb_mx_data(uid, year, month, sb_type)
        if res.get('code') != 200:
            return {
                'code': res.get('code', 500),
                'msg': res.get('msg', '查询失败'),
                'data': res.get('data') or {},
            }
        data = res.get('data') or {}
        return {
            'code': 200,
            'msg': res.get('msg', '') or '查询成功',
            'data': {
                'uid': uid,
                'reporting_period': data.get('reporting_period', ''),
                'state': data.get('state', ''),
                'members': data.get('data') or [],
            }
        }

    def build_sb_sb_task(self, uid: str, year: int, month: int, sb_type: str = 'normal') -> dict:
        uid = cfg_mgr.get_abs_uid(uid)

        ok, err = self._validate_year_month(year, month)
        if not ok:
            return err
        ok, validated = self._validate_sb_type(sb_type)
        if not ok:
            return validated
        sb_type = validated['sb_type']

        res = zjz_api.build_sb_sb_task(uid, year, month, sb_type)
        if res.get('code') != 200:
            return {
                'code': res.get('code', 500),
                'msg': res.get('msg', '创建失败'),
                'data': res.get('data') or {},
            }
        return {
            'code': 200,
            'msg': res.get('msg', '') or '创建成功',
            'data': {
                'uid': uid,
                'year': year,
                'month': month,
                'sb_type': sb_type,
            }
        }

    def agree_sb_tax(self, uid: str, year: int, month: int) -> dict:
        uid = cfg_mgr.get_abs_uid(uid)
        ok, err = self._validate_year_month(year, month)
        if not ok:
            return err

        res = zjz_api.agree_sb_tax(uid, year, month)
        if res.get('code') != 200:
            return {
                'code': res.get('code', 500),
                'msg': res.get('msg', '操作失败'),
                'data': res.get('data') or {},
            }
        return {
            'code': 200,
            'msg': res.get('msg', '') or '操作成功',
            'data': {
                'uid': uid,
                'year': year,
                'month': month,
            }
        }

    def disagree_sb_tax(self, uid: str, year: int, month: int) -> dict:
        uid = cfg_mgr.get_abs_uid(uid)
        ok, err = self._validate_year_month(year, month)
        if not ok:
            return err

        res = zjz_api.disagree_sb_tax(uid, year, month)
        if res.get('code') != 200:
            return {
                'code': res.get('code', 500),
                'msg': res.get('msg', '操作失败'),
                'data': res.get('data') or {},
            }
        return {
            'code': 200,
            'msg': res.get('msg', '') or '操作成功',
            'data': {
                'uid': uid,
                'year': year,
                'month': month,
            }
        }
