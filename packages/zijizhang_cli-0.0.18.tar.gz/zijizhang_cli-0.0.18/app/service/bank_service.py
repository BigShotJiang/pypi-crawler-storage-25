import re
from datetime import datetime
from pathlib import Path

from app.api import zjz_api
from app.service.config_manager import cfg_mgr


class BankService:
    def _validate_page_and_date_range(self, current: int, date_begin: str, date_end: str) -> tuple:
        if not current or current < 1:
            current = 1
        if (date_begin and not date_end) or (date_end and not date_begin):
            return False, {
                'code': 400,
                'msg': 'date_begin 和 date_end 需要同时填写',
            }
        if date_begin and not re.match(r'^\d{4}-\d{2}-\d{2}$', date_begin):
            return False, {
                'code': 400,
                'msg': 'date_begin 格式不正确，期望 YYYY-MM-DD',
            }
        if date_end and not re.match(r'^\d{4}-\d{2}-\d{2}$', date_end):
            return False, {
                'code': 400,
                'msg': 'date_end 格式不正确，期望 YYYY-MM-DD',
            }
        if date_begin and date_end:
            try:
                begin_dt = datetime.strptime(date_begin, '%Y-%m-%d')
                end_dt = datetime.strptime(date_end, '%Y-%m-%d')
                if begin_dt > end_dt:
                    return False, {
                        'code': 400,
                        'msg': 'date_begin 不能晚于 date_end',
                    }
            except ValueError:
                return False, {
                    'code': 400,
                    'msg': 'date_begin / date_end 解析失败，期望 YYYY-MM-DD',
                }
        return True, {
            'current': current,
            'date_begin': date_begin,
            'date_end': date_end,
        }

    def get_bank_bill_data_list(self, uid: str, current: int = 1, date_begin: str = '', date_end: str = '') -> dict:
        uid = cfg_mgr.get_abs_uid(uid)
        ok, validated = self._validate_page_and_date_range(current, date_begin, date_end)
        if not ok:
            return validated
        current = validated['current']

        res = zjz_api.get_bank_bill_data_list(uid, current, date_begin, date_end)
        if res.get('code') != 200:
            return {
                'code': res.get('code'),
                'msg': res.get('msg'),
            }
        data = res.get('data') or {}
        items = data.get('items') or []
        total_cnt = data.get('total_count')
        return {
            'code': 200,
            'msg': '查询成功',
            'data': {
                'uid': uid,
                'cnt': total_cnt if total_cnt is not None else len(items),
                'bill_list': items,
            }
        }

    def choose_bank_use(self, uid: str, bill_id: int, rule_text: str) -> dict:
        uid = cfg_mgr.get_abs_uid(uid)
        if not bill_id or bill_id <= 0:
            return {
                'code': 400,
                'msg': 'id 不合法',
            }
        if not rule_text:
            return {
                'code': 400,
                'msg': 'rule_text 不能为空',
            }
        res = zjz_api.choose_bank_use(uid, bill_id, rule_text)
        if res.get('code') != 200:
            return res
        return {
            'code': 200,
            'msg': '录入成功',
            'data': {
                'uid': uid,
                'id': bill_id,
                'rule_text': rule_text,
            }
        }

    def set_month_bank_no_water(self, uid: str, year: int, month: int) -> dict:
        uid = cfg_mgr.get_abs_uid(uid)
        if not year or year < 1970:
            return {
                'code': 400,
                'msg': 'year 不合法',
            }
        if not month or month < 1 or month > 12:
            return {
                'code': 400,
                'msg': 'month 不合法（1-12）',
            }
        res = zjz_api.set_month_bank_no_water(uid, year, month)
        if res.get('code') != 200:
            return res
        return {
            'code': 200,
            'msg': '设置成功',
            'data': {
                'uid': uid,
                'year': year,
                'month': month,
            }
        }

    def support_bank_list(self) -> dict:
        res = zjz_api.support_bank_list()
        if res.get('code') != 200:
            return {
                'code': res.get('code', 500),
                'msg': res.get('msg', '查询失败'),
                'data': res.get('data') or {},
            }
        data = res.get('data')
        if data is None:
            data = []
        return {
            'code': 200,
            'msg': res.get('msg', '') or '查询成功',
            'data': data,
        }

    def bank_account_number_list(self, uid: str = '') -> dict:
        uid = cfg_mgr.get_abs_uid(uid)
        res = zjz_api.bank_account_number_list(uid)
        if res.get('code') != 200:
            return {
                'code': res.get('code', 500),
                'msg': res.get('msg', '查询失败'),
                'data': res.get('data') or {},
            }
        data = res.get('data')
        if data is None:
            data = []
        return {
            'code': 200,
            'msg': res.get('msg', '') or '查询成功',
            'data': data,
        }

    def add_bank_account_number(self, uid: str, bank_id: int, bank_number: str) -> dict:
        uid = cfg_mgr.get_abs_uid(uid)
        if not bank_id or bank_id <= 0:
            return {
                'code': 400,
                'msg': 'bank_id 不合法',
                'data': {},
            }
        if not bank_number:
            return {
                'code': 400,
                'msg': 'bank_number 不能为空',
                'data': {},
            }
        res = zjz_api.add_bank_account_number(uid, bank_id, bank_number)
        if res.get('code') != 200:
            return {
                'code': res.get('code', 500),
                'msg': res.get('msg', '操作失败'),
                'data': res.get('data') or {},
            }
        return {
            'code': 200,
            'msg': res.get('msg', '') or '操作成功',
            'data': res.get('data') or {},
        }

    def del_bank_account_number(self, uid: str, bank_id: int, bank_number: str) -> dict:
        uid = cfg_mgr.get_abs_uid(uid)
        if not bank_id or bank_id <= 0:
            return {
                'code': 400,
                'msg': 'bank_id 不合法',
                'data': {},
            }
        if not bank_number:
            return {
                'code': 400,
                'msg': 'bank_number 不能为空',
                'data': {},
            }
        res = zjz_api.del_bank_account_number(uid, bank_id, bank_number)
        if res.get('code') != 200:
            return {
                'code': res.get('code', 500),
                'msg': res.get('msg', '操作失败'),
                'data': res.get('data') or {},
            }
        return {
            'code': 200,
            'msg': res.get('msg', '') or '操作成功',
            'data': res.get('data') or {},
        }

    def bank_file_list(self, uid: str = '', current: int = 1) -> dict:
        uid = cfg_mgr.get_abs_uid(uid)
        if not current or current < 1:
            current = 1

        res = zjz_api.bank_file_list(uid, current)
        if res.get('code') != 200:
            return {
                'code': res.get('code', 500),
                'msg': res.get('msg', '查询失败'),
                'data': res.get('data') or {},
            }

        data = res.get('data') or {}
        items = data.get('items') or []
        total = data.get('total')
        if total is None:
            total = data.get('total_count') or 0

        return {
            'code': 200,
            'msg': res.get('msg', '') or '查询成功',
            'data': {
                'uid': uid,
                'current': current,
                'total': total,
                'items': items,
            }
        }

    def upload_bank_file(self, uid: str, file: str, file_type: str, bank_account_number_id: int, billing_cycle: str) -> dict:
        uid = cfg_mgr.get_abs_uid(uid)
        if not file:
            return {
                'code': 400,
                'msg': 'file 不能为空',
            }
        p = Path(file).expanduser()
        if not p.exists() or not p.is_file():
            return {
                'code': 400,
                'msg': f'file 不存在或不是文件：{p}',
            }
        if file_type not in ['明细', '回单']:
            return {
                'code': 400,
                'msg': "file_type 必须为：明细 或 回单",
            }

        suffix = p.suffix.lower()
        if file_type == '回单' and suffix != '.pdf':
            return {
                'code': 400,
                'msg': '回单文件仅支持上传 pdf',
            }
        if file_type == '明细' and suffix not in ['.xls', '.xlsx']:
            return {
                'code': 400,
                'msg': '明细文件仅支持上传 Excel（.xls/.xlsx）',
            }

        if not bank_account_number_id or bank_account_number_id <= 0:
            return {
                'code': 400,
                'msg': 'bank_account_number_id 不合法',
            }

        if not billing_cycle:
            return {
                'code': 400,
                'msg': 'billing_cycle 不能为空',
            }
        if not re.match(r'^\d{4}-\d{2}-\d{2}$', billing_cycle):
            return {
                'code': 400,
                'msg': 'billing_cycle 格式不正确，期望 YYYY-MM-DD（如 2026-03-01）',
            }
        try:
            datetime.strptime(billing_cycle, '%Y-%m-%d')
        except ValueError:
            return {
                'code': 400,
                'msg': 'billing_cycle 解析失败，期望 YYYY-MM-DD（如 2026-03-01）',
            }

        res = zjz_api.upload_bank_file(uid, str(p), file_type, bank_account_number_id, billing_cycle)
        if res.get('code') != 200:
            return {
                'code': res.get('code', 500),
                'msg': res.get('msg', '上传失败'),
                'data': res.get('data') or {},
            }

        return {
            'code': 200,
            'msg': res.get('msg', '') or '上传成功',
            'data': {
                'uid': uid,
                'filename': p.name,
                'file_path': str(p),
                'file_type': file_type,
                'bank_account_number_id': bank_account_number_id,
                'billing_cycle': billing_cycle,
                'raw': res.get('data') or {},
            }
        }
