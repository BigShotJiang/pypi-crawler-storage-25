import textwrap


def format_epilog(text: str) -> str:
    text = textwrap.dedent(text).strip("\n")
    return text.replace("\n", "\n\n")
