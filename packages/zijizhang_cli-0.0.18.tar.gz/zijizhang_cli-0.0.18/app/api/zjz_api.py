from app.api.zjz_req import zjz_req
from pathlib import Path


def create_auth_url():
    return zjz_req.get_client().post_json('login/auth-login', {})


def get_account_info():
    return zjz_req.get_client().get('account-info')


# def sms_verify_code(phone: str) -> dict:
#     return zjz_req.get_client().post_json('login/sms', {
#         'phone': phone,
#     })


# def verify_sms_code(phone: str, code: str) -> dict:
#     return zjz_req.get_client().post_json('login/sms-2-token', {
#         'phone': phone,
#         'sms': code,
#     })


def get_employee_list(uid: str = None, keyword: str = '', page: int = 1) -> dict:
    if not page or page < 1:
        page = 1
    return zjz_req.get_client().get('ryxx', params={
        'uid': uid,
        'keyword': keyword,
        'page': page
    })


def add_employee(uid: str, data: dict) -> dict:
    data['uid'] = uid
    return zjz_req.get_client().post_json('ryxx', data)


def update_employee(employee_id: str, data: dict) -> dict:
    return zjz_req.get_client().put('ryxx', {
        'id': employee_id,
        'data': data,
    })


def get_payroll(uid: str, year: int, month: int) -> dict:
    month_str = f"{year}-{month:02d}"
    return zjz_req.get_client().get('payroll', params={
        'uid': uid,
        'month': month_str
    })


def get_payroll_creation_status(uid: str, year: int, month: int) -> dict:
    month_str = f"{year}-{month:02d}"
    return zjz_req.get_client().get('payroll/creation-status', params={
        'uid': uid,
        'month': month_str
    })


def get_preview_payroll(uid: str, year: int, month: int) -> dict:
    month_str = f"{year}-{month:02d}"
    return zjz_req.get_client().get('payroll/preview', params={
        'uid': uid,
        'month': month_str
    })


def create_payroll(uid: str, year: int, month: int, data: list) -> dict:
    month_str = f"{year}-{month:02d}"
    return zjz_req.get_client().post_json('payroll', {
        'uid': uid,
        'month': month_str,
        'data': data
    })

def remove_payroll(uid: str, year: int, month: int) -> dict:
    month_str = f"{year}-{month:02d}"
    return zjz_req.get_client().post_json('payroll/remove', {
        'uid': uid,
        'month': month_str
    })

def get_sales_invoice_data_list(uid: str, current: int = 1, invoice_number: str = '', invoice_date_begin: str = '',
                                invoice_date_end: str = '', status: str = '') -> dict:
    return zjz_req.get_client().get('invoice/sales_invoice_data_list', params={
        'uid': uid,
        'current': current,
        'invoice_number': invoice_number,
        'invoice_date_begin': invoice_date_begin,
        'invoice_date_end': invoice_date_end,
        'status': status,
    })


def set_month_no_sales_invoice(uid: str, year: int, month: int) -> dict:
    return zjz_req.get_client().post_json('invoice/set_month_no_sales_invoice', {
        'uid': uid,
        'year': year,
        'month': month,
    })


def get_income_invoice_data_list(uid: str, current: int = 1, invoice_number: str = '', invoice_date_begin: str = '',
                                 invoice_date_end: str = '', status: str = '') -> dict:
    return zjz_req.get_client().get('invoice/income_invoice_data_list', params={
        'uid': uid,
        'current': current,
        'invoice_number': invoice_number,
        'invoice_date_begin': invoice_date_begin,
        'invoice_date_end': invoice_date_end,
        'status': status,
    })


def set_month_no_invoice(uid: str, year: int, month: int) -> dict:
    return zjz_req.get_client().post_json('invoice/set_month_no_invoice', {
        'uid': uid,
        'year': year,
        'month': month,
    })


def invoice_can_choose_use_list(uid: str, goods_name: str, total_tax_price: str, total_money: str) -> dict:
    return zjz_req.get_client().get('invoice/invoice_can_choose_use_list', params={
        'uid': uid,
        'goods_name': goods_name,
        'total_tax_price': total_tax_price,
        'total_money': total_money,
    })


def invoice_choose_use(uid: str, invoice_id: int, category: str, is_pay: str, payee: str) -> dict:
    return zjz_req.get_client().post_json('invoice/invoice_choose_use', {
        'uid': uid,
        'invoice_id': invoice_id,
        'category': category,
        'is_pay': is_pay,
        'payee': payee,
    })


def upload_invoice_file(uid: str, file_path: str) -> dict:
    p = Path(file_path)
    suffix = p.suffix.lower()
    content_type = 'application/octet-stream'
    if suffix == '.pdf':
        content_type = 'application/pdf'
    elif suffix == '.ofd':
        content_type = 'application/ofd'

    with p.open('rb') as f:
        return zjz_req.get_client().post_file('invoice/upload_invoice_file', files={
            'file': (p.name, f, content_type),
        }, data={
            'uid': uid,
        })


def invoice_file_list(uid: str, current: int = 1) -> dict:
    if not current or current < 1:
        current = 1
    params = {
        'current': current,
        'uid': uid,
    }
    return zjz_req.get_client().get('invoice/invoice_file_list', params=params)


def get_todo_list(uid: str) -> dict:
    params = {
        'uid': uid,
    }
    return zjz_req.get_client().get('todo-list', params=params)


def before_set_month_audited(year: int, month: int, uid: str) -> dict:
    params = {
        'year': year,
        'month': month,
        'uid': uid,
    }
    return zjz_req.get_client().get('audit/before_set_month_audited', params=params)


def set_month_audited(year: int, month: int, uid: str) -> dict:
    payload = {
        'year': year,
        'month': month,
        'uid': uid,
    }
    return zjz_req.get_client().post_json('audit/set_month_audited', payload)


def get_bank_bill_data_list(uid: str, current: int = 1, date_begin: str = '', date_end: str = '') -> dict:
    params = {
        'current': current,
        'date_begin': date_begin,
        'date_end': date_end,
        'uid': uid,
    }
    return zjz_req.get_client().get('bank/bill_data_list', params=params)


def choose_bank_use(uid: str, bill_id: int, rule_text: str) -> dict:
    payload = {
        'id': bill_id,
        'rule_text': rule_text,
        'uid': uid,
    }
    return zjz_req.get_client().post_json('bank/bank_bill_choose_use', payload)


def sb_history_list(uid: str, current: int = 1) -> dict:
    if not current or current < 1:
        current = 1
    return zjz_req.get_client().get('sb/sb_history_list', params={
        'uid': uid,
        'current': current,
    })


def now_month_sb_report_info(uid: str) -> dict:
    return zjz_req.get_client().get('sb/now_month_sb_report_info', params={
        'uid': uid,
    })


def get_sb_mx_data(uid: str, year: int, month: int, sb_type: str = 'normal') -> dict:
    return zjz_req.get_client().get('sb/get_sb_mx_data', params={
        'uid': uid,
        'year': year,
        'month': month,
        'sb_type': sb_type,
    })


def build_sb_sb_task(uid: str, year: int, month: int, sb_type: str = 'normal') -> dict:
    return zjz_req.get_client().post_json('sb/build_sb_sb_task', {
        'uid': uid,
        'year': year,
        'month': month,
        'sb_type': sb_type,
    })


def agree_sb_tax(uid: str, year: int, month: int) -> dict:
    return zjz_req.get_client().post_json('sb/agree_sb_tax', {
        'uid': uid,
        'year': year,
        'month': month,
    })


def disagree_sb_tax(uid: str, year: int, month: int) -> dict:
    return zjz_req.get_client().post_json('sb/disagree_sb_tax', {
        'uid': uid,
        'year': year,
        'month': month,
    })


def set_month_bank_no_water(uid: str, year: int, month: int) -> dict:
    payload = {
        'year': year,
        'month': month,
        'uid': uid,
    }
    return zjz_req.get_client().post_json('bank/set_month_no_water', payload)


def support_bank_list() -> dict:
    return zjz_req.get_client().get('bank/support_bank_list')


def bank_account_number_list(uid: str) -> dict:
    params = {
        'uid': uid,
    }
    return zjz_req.get_client().get('bank/bank_account_number_list', params=params)


def add_bank_account_number(uid: str, bank_id: int, bank_number: str) -> dict:
    payload = {
        'bank_id': bank_id,
        'bank_number': bank_number,
        'uid': uid,
    }
    return zjz_req.get_client().post_json('bank/add_bank_account_number', payload)


def del_bank_account_number(uid: str, bank_id: int, bank_number: str) -> dict:
    payload = {
        'bank_id': bank_id,
        'bank_number': bank_number,
        'uid': uid,
    }
    return zjz_req.get_client().post_json('bank/del_bank_account_number', payload)


def bank_file_list(uid: str, current: int = 1) -> dict:
    if not current or current < 1:
        current = 1
    params = {
        'current': current,
        'uid': uid,
    }
    return zjz_req.get_client().get('bank/bank_file_list', params=params)


def upload_bank_file(uid: str, file_path: str, file_type: str, bank_account_number_id: int, billing_cycle: str) -> dict:
    p = Path(file_path)
    suffix = p.suffix.lower()
    content_type = 'application/octet-stream'
    if suffix == '.pdf':
        content_type = 'application/pdf'
    elif suffix == '.xls':
        content_type = 'application/vnd.ms-excel'
    elif suffix == '.xlsx':
        content_type = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    with p.open('rb') as f:
        return zjz_req.get_client().post_file('bank/upload_bank_file', files={
            'file': (p.name, f, content_type),
        }, data={
            'uid': uid,
            'file_type': file_type,
            'bank_account_number_id': str(bank_account_number_id),
            'billing_cycle': billing_cycle,
        })
