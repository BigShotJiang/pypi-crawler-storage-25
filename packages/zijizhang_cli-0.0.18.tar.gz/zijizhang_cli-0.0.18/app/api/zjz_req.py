from app.service.config_manager import cfg_mgr
from app.util.http_client import HttpClient

DEFAULT_BASE_URL = 'https://www.zijizhang.com/ai/skill'

class ZjzReq:
    def __init__(self):
        self.headers = {}
        self.client = None

    def get_client(self):
        auth_token = self.headers.get('Authorization')
        if not auth_token:
            token = cfg_mgr.get_config('token')
            if token:
                self.headers['Authorization'] = f'Bearer {token}'
                self.client = None
        base_url = DEFAULT_BASE_URL
        cfg_base_url = cfg_mgr.get_config('base_url')
        if cfg_base_url:
            base_url = cfg_base_url
        if not self.client:
            self.client = HttpClient(base_url=base_url, headers=self.headers)
        return self.client

zjz_req = ZjzReq()