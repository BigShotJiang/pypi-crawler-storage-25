import typer

from app.service.todo_service import TodoService
from app.util import cli_help, echo_util

todo_app = typer.Typer()


@todo_app.command(
    name='get_todo_list',
    help="获取代办列表",
    epilog=cli_help.format_epilog("""
返回参数说明

- code: int，200 代表成功，其他代表失败
- msg: string，提示信息
- data: dict，代办与当前记账期信息
- data.uid: string，当前所属 uid
- data.year: string，当前记账期年份
- data.month: string，当前记账期月份
- data.todo_list: list，代办项列表
- data.todo_list[].code: string，代办编码
- data.todo_list[].name: string，代办名称
- data.todo_list[].state: int，完成状态，1 已完成 / 0 未完成
- data.todo_list[].blocking: int，是否阻塞，1 阻塞 / 0 不阻塞

使用示例

zijizhang-cli todo get_todo_list"""))
def get_todo_list(
    uid: str = typer.Option('', '--uid', help='公司唯一标识uid；不传则使用当前已切换在用的 uid'),
):
    service = TodoService()
    res = service.get_todo_list(uid)
    echo_util.echo_http_res(res)


@todo_app.command(
    name='before_set_month_audited',
    help="提交审账前确认",
    no_args_is_help=True,
    epilog=cli_help.format_epilog("""
返回参数说明

- code: int，200 代表成功，其他代表失败
- msg: string，提示信息
- data: dict，确认结果
- data.uid: string，当前所属 uid
- data.year: int，年份
- data.month: int，月份
- data.state: bool，是否允许提交审账
- data.reason: string，不允许时的原因

使用示例

zijizhang-cli todo before_set_month_audited 2026 3"""))
def before_set_month_audited(
    year: int = typer.Argument(..., help='年份，如 2026'),
    month: int = typer.Argument(..., help='月份(1-12)，如 3'),
    uid: str = typer.Option('', '--uid', help='公司唯一标识uid；不传则使用当前已切换在用的 uid'),
):
    service = TodoService()
    res = service.before_set_month_audited(year, month, uid)
    echo_util.echo_http_res(res)


@todo_app.command(
    name='set_month_audited',
    help="提交审账",
    no_args_is_help=True,
    epilog=cli_help.format_epilog("""
返回参数说明

- code: int，200 代表成功，其他代表失败
- msg: string，提示信息
- data: dict，结果数据，常见字段为 uid

使用示例

zijizhang-cli todo set_month_audited 2026 3"""))
def set_month_audited(
    year: int = typer.Argument(..., help='年份，如 2026'),
    month: int = typer.Argument(..., help='月份(1-12)，如 3'),
    uid: str = typer.Option('', '--uid', help='公司唯一标识uid；不传则使用当前已切换在用的 uid'),
):
    service = TodoService()
    res = service.set_month_audited(year, month, uid)
    echo_util.echo_http_res(res)
