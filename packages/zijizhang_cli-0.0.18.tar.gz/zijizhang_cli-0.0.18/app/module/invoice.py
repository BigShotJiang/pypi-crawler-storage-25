import typer
from pathlib import Path

from app.service.invoice_service import InvoiceService
from app.util import cli_help, echo_util

invoice_app = typer.Typer()


@invoice_app.command(
    name='get_sales_invoice_data_list',
    help="获取销项发票列表",
    epilog=cli_help.format_epilog("""
返回参数说明

- code: int，200 代表成功，其他代表失败
- msg: string，提示信息
- data: dict，发票列表结果
- data.uid: string，当前查询所属 uid
- data.cnt: int，符合条件的总数
- data.invoice_list: list，发票列表
- data.invoice_list[].id: string/int，发票 id
- data.invoice_list[].invoice_number: string，发票号码
- data.invoice_list[].create_invoice_time: string，开票日期
- data.invoice_list[].status: string/int，状态

使用示例

zijizhang-cli invoice get_sales_invoice_data_list --current=1

zijizhang-cli invoice get_sales_invoice_data_list --current=2

zijizhang-cli invoice get_sales_invoice_data_list --uid='xxxx'

zijizhang-cli invoice get_sales_invoice_data_list --invoice_number='11111111111111111111'

zijizhang-cli invoice get_sales_invoice_data_list --uid='xxxx' --invoice_date_begin='2024-01-01' --invoice_date_end='2024-01-31'"""))
def get_sales_invoice_data_list(
        uid: str = typer.Option('', '--uid', help='公司唯一标识uid；不传则使用当前激活公司'),
        current: int = typer.Option(1, '--current', help='页码，默认 1'),
        invoice_number: str = typer.Option('', '--invoice_number', help='发票号码；用于精确查询，不传则查询全部'),
        invoice_date_begin: str = typer.Option('', '--invoice_date_begin', help='发票日期开始，格式 YYYY-MM-DD；如需使用需与 invoice_date_end 同时传'),
        invoice_date_end: str = typer.Option('', '--invoice_date_end', help='发票日期结束，格式 YYYY-MM-DD；如需使用需与 invoice_date_begin 同时传'),
):
    service = InvoiceService()
    res = service.get_sales_invoice_data_list(uid, current, invoice_number, invoice_date_begin, invoice_date_end)
    echo_util.echo_http_res(res)


@invoice_app.command(
    name='get_income_invoice_data_list',
    help="获取进项/收到的发票列表",
    epilog=cli_help.format_epilog("""
返回参数说明

- code: int，200 代表成功，其他代表失败
- msg: string，提示信息
- data: dict，发票列表结果
- data.uid: string，当前查询所属 uid
- data.cnt: int，符合条件的总数
- data.invoice_list: list，发票列表
- data.invoice_list[].id: string/int，发票 id
- data.invoice_list[].invoice_number: string，发票号码
- data.invoice_list[].goods_name: string，货物/服务名称
- data.invoice_list[].status: string/int，状态

使用示例

zijizhang-cli invoice get_income_invoice_data_list --current=1

zijizhang-cli invoice get_income_invoice_data_list --uid='xxxx'

zijizhang-cli invoice get_income_invoice_data_list --invoice_date_begin='2026-03-01' --invoice_date_end='2026-03-31'

zijizhang-cli invoice get_income_invoice_data_list --status='待确认'"""))
def get_income_invoice_data_list(
        uid: str = typer.Option('', '--uid', help='公司唯一标识uid；不传则使用当前激活公司'),
        current: int = typer.Option(1, '--current', help='页码'),
        invoice_number: str = typer.Option('', '--invoice_number', help='发票号码；精确匹配，不传则查询全部'),
        invoice_date_begin: str = typer.Option('', '--invoice_date_begin', help='开票日期开始，格式 YYYY-MM-DD；如需使用需与 invoice_date_end 同时传'),
        invoice_date_end: str = typer.Option('', '--invoice_date_end', help='开票日期结束，格式 YYYY-MM-DD；如需使用需与 invoice_date_begin 同时传'),
        status: str = typer.Option('', '--status', help='发票状态；可选 审核中 / 待确认 / 已拒绝 / 已入账'),
):
    service = InvoiceService()
    res = service.get_income_invoice_data_list(uid, current, invoice_number, invoice_date_begin, invoice_date_end, status)
    echo_util.echo_http_res(res)


@invoice_app.command(
    name='set_month_no_sales_invoice',
    help="标记某个月份无销项/开出的发票",
    no_args_is_help=True,
    epilog=cli_help.format_epilog("""
返回参数说明

- code: int，200 代表成功，其他代表失败
- msg: string，提示信息；失败时通常说明该月份已录入发票或当前时间不允许设置
- data: dict，结果数据
- data.uid: string，当前查询所属 uid

使用示例

zijizhang-cli invoice set_month_no_sales_invoice 2026 3

zijizhang-cli invoice set_month_no_sales_invoice 2026 3 --uid='xxxx'"""))
def set_month_no_sales_invoice(
    uid: str = typer.Option('', '--uid', help='公司唯一标识uid；不传则使用当前激活公司'),
    year: int = typer.Argument(..., help='年份，如 2026'),
    month: int = typer.Argument(..., help='月份(1-12)，如 3'),
):
    service = InvoiceService()
    res = service.set_month_no_sales_invoice(uid, year, month)
    echo_util.echo_http_res(res)


@invoice_app.command(
    name='set_month_no_invoice',
    help="标记某个月份无进项/收到的发票",
    no_args_is_help=True,
    epilog=cli_help.format_epilog("""
返回参数说明

- code: int，200 代表成功，其他代表失败
- msg: string，提示信息；失败时通常说明该月份已录入发票或当前时间不允许设置
- data: dict，结果数据
- data.uid: string，当前查询所属 uid

使用示例

zijizhang-cli invoice set_month_no_invoice 2026 3

zijizhang-cli invoice set_month_no_invoice --uid='xxxx' 2026 3"""))
def set_month_no_invoice(
    uid: str = typer.Option('', '--uid', help='公司唯一标识uid；不传则使用当前激活公司'),
    year: int = typer.Argument(..., help='年份，如 2026'),
    month: int = typer.Argument(..., help='月份(1-12)，如 3'),
):
    service = InvoiceService()
    res = service.set_month_no_invoice(uid, year, month)
    echo_util.echo_http_res(res)


@invoice_app.command(
    name='invoice_can_choose_use_list',
    help="进项发票：查询可选用途列表",
    no_args_is_help=True,
    epilog=cli_help.format_epilog("""
返回参数说明

- code: int，200 代表成功，其他代表失败
- msg: string，提示信息
- data: dict，可选用途结果
- data.uid: string，当前查询所属 uid
- data.items: list，可选用途/类目列表
- data.items[].id: int，用途 id，可用于 `invoice_choose_use --category`
- data.items[].category_name: string，用途名称
- data.is_pay: list，支付方式候选，可用于 `invoice_choose_use --is_pay`
- data.boss_name: string，老板名称

使用示例

zijizhang-cli invoice invoice_can_choose_use_list --goods_name='*建筑服务*安装服务费' --total_tax_price='113.00' --total_money='100.00'"""))
def invoice_can_choose_use_list(
    uid: str = typer.Option('', '--uid', help='公司唯一标识uid；不传则使用当前已切换在用的 uid'),
    goods_name: str = typer.Option(..., '--goods_name', help='货物/服务名称；用于推荐用途'),
    total_tax_price: str = typer.Option(..., '--total_tax_price', help='价税合计；建议传元，如 113.00'),
    total_money: str = typer.Option(..., '--total_money', help='不含税金额；建议传元，如 100.00'),
):
    service = InvoiceService()
    res = service.invoice_can_choose_use_list(uid, goods_name, total_tax_price, total_money)
    echo_util.echo_http_res(res)


@invoice_app.command(
    name='invoice_choose_use',
    help="进项发票：选择用途并入账",
    no_args_is_help=True,
    epilog=cli_help.format_epilog("""
返回参数说明

- code: int，200 代表成功，其他代表失败
- msg: string，提示信息；失败时通常为不能入账的原因
- data: dict，结果数据
- data.uid: string，当前查询所属 uid

使用示例

zijizhang-cli invoice invoice_choose_use --invoice_id='123456' --category='1216' --is_pay='员工垫付' --payee='张三'"""))
def invoice_choose_use(
    uid: str = typer.Option('', '--uid', help='公司唯一标识uid；不传则使用当前已切换在用的 uid'),
    invoice_id: int = typer.Option(..., '--invoice_id', help='发票 id'),
    category: str = typer.Option(..., '--category', help='用途/类目；建议从 invoice_can_choose_use_list.data.items[].id 中选择'),
    is_pay: str = typer.Option(..., '--is_pay', help='支付方式；可选 对公银行支付 / 员工垫付 / 老板垫付 / 现金支付'),
    payee: str = typer.Option('', '--payee', help='垫付人/收款人；员工垫付或老板垫付时必填'),
):
    service = InvoiceService()
    res = service.invoice_choose_use(uid, invoice_id, category, is_pay, payee)
    echo_util.echo_http_res(res)


@invoice_app.command(
    name='upload_invoice_file',
    help="上传发票文件（仅支持 pdf/ofd）",
    no_args_is_help=True,
    epilog=cli_help.format_epilog("""
返回参数说明

- code: int，200 代表成功，其他代表失败
- msg: string，提示信息
- data: dict，结果数据，以服务端返回为准

使用示例

zijizhang-cli invoice upload_invoice_file --file='/path/to/invoice.pdf'"""))
def upload_invoice_file(
    uid: str = typer.Option('', '--uid', help='公司唯一标识uid；不传则使用当前已切换在用的 uid'),
    file: Path = typer.Option(..., '--file', '-f', help='发票文件路径；仅支持 .pdf 或 .ofd'),
):
    service = InvoiceService()
    res = service.upload_invoice_file(uid, str(file))
    echo_util.echo_http_res(res)


@invoice_app.command(
    name='invoice_file_list',
    help="查询发票文件列表",
    no_args_is_help=True,
    epilog=cli_help.format_epilog("""
返回参数说明

- code: int，200 代表成功，其他代表失败
- msg: string，提示信息
- data: dict，文件列表结果
- data.uid: string，当前查询所属 uid
- data.current: int，当前页码
- data.total: int，总数
- data.items: list，文件列表
- data.items[].file_name: string，文件名
- data.items[].type: string，文件类型
- data.items[].status: string，状态
- data.items[].url: string，下载/访问地址

使用示例

zijizhang-cli invoice invoice_file_list --current=1"""))
def invoice_file_list(
    uid: str = typer.Option('', '--uid', help='公司唯一标识uid；不传则使用当前已切换在用的 uid'),
    current: int = typer.Option(1, '--current', help='页码，默认 1'),
):
    service = InvoiceService()
    res = service.invoice_file_list(uid, current)
    echo_util.echo_http_res(res)
