import json
import typer

from app.service.payroll_service import PayrollService
from app.util import cli_help, echo_util

payroll_app = typer.Typer()


def parse_month(month_str: str) -> tuple:
    try:
        parts = month_str.split('-')
        if len(parts) != 2:
            raise typer.BadParameter("格式必须为 yyyy-mm，例如 2026-04")
        year = int(parts[0])
        month_val = int(parts[1])
        if not (1 <= month_val <= 12):
            raise typer.BadParameter("月份必须在 1 到 12 之间")
        return year, month_val
    except ValueError:
        raise typer.BadParameter("年份和月份必须是数字，例如 2026-04")


@payroll_app.command(
    name='get_payroll',
    help="获取工资单",
    epilog=cli_help.format_epilog("""
## 返回参数说明

- code: int，200 代表成功，其他代表失败
- msg: string，提示信息
- data: dict，工资单数据
- data.uid: string，当前查询所属 uid
- data.year: int，年份
- data.month: int，月份
- data.payroll: list，工资单列表
- data.payroll[].xm: string，员工姓名
- data.payroll[].zjhm: string，证件号码
- data.payroll[].bqsr: float，本期收入
- data.payroll[].gs: float，个税

## 使用示例

zijizhang-cli payroll get_payroll 2026-04

zijizhang-cli payroll get_payroll 2026-04 --uid='xxxx'

## 推荐展示方式

展示例子：

- 如果结果中，只有一条记录

| 项目 | 内容 |
| :--- | :--- |
| **基本信息** | |
| 员工姓名 | {xm} |
| 证件号码 | {zjhm} |
| **收入与奖金** | |
| 本期收入 | {bqsr} 元 |
| 全年一次性奖金 | {qnycxjj} 元 |
| 离职补偿金 | {lzbcj} 元 |
| **个人扣款明细** | |
| ├─ 住房公积金 | {gr_zfgjj} 元 |
| ├─ 养老保险 | {gr_jbpbxf} 元 |
| ├─ 医疗保险 | {gr_jbmbxf} 元 |
| ├─ 失业保险 | {gr_sybxf} 元 |
| └─ 其他保险费 | {gr_qt} 元 |
| └─ 个人备注 | {gr_bz} |
| **企业缴纳明细** | |
| ├─ 住房公积金 | {qy_zfgjj} 元 |
| ├─ 养老保险 | {qy_jbpbxf} 元 |
| ├─ 医疗保险 | {qy_jbmbxf} 元 |
| ├─ 失业保险 | {qy_sybxf} 元 |
| ├─ 工伤保险 | {qy_gsbxf} 元 |
| └─ 其他保险费 | {qy_qt} 元 |
| └─ 企业备注 | {qy_bz} |
| **税务信息** | |
| **个税** | **{gs} 元** |

- 如果结果中，超过一条记录

| 姓名 | 证件号码 | 本期收入 | 全年一次性奖金 | 离职补偿金 | 个人-养老保险 | 个人-医疗保险 | 个人-失业保险 | 个人-其他保险 | 个人-公积金 | 个人-备注 | 企业-养老保险 | 企业-医疗保险 | 企业-失业保险 | 企业-工伤保险 | 企业-其他保险 | 企业-公积金 | 企业-备注 | 个税 |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| {xm} | {zjhm} | {bqsr} | {qnycxjj} | {lzbcj} | {gr_jbpbxf} | {gr_jbmbxf} | {gr_sybxf} | {gr_qt} | {gr_zfgjj} | {gr_bz} | {qy_jbpbxf} | {qy_jbmbxf} | {qy_sybxf} | {qy_gsbxf} | {qy_qt} | {qy_zfgjj} | {qy_bz} | {gs} |
"""))
def get_payroll(
        month: str = typer.Argument(..., help='工资单月份，格式 YYYY-MM，如 2026-04'),
        uid: str = typer.Option('', '--uid', help='公司唯一标识uid；不传则使用当前激活公司')
):
    req_year, req_month = parse_month(month)
    service = PayrollService()
    res = service.get_payroll(uid, req_year, req_month)
    echo_util.echo_http_res(res)


@payroll_app.command(
    name='get_payroll_creation_status',
    help="获取工资单创建状态",
    no_args_is_help=True,
    epilog=cli_help.format_epilog("""
返回参数说明

- code: int，200 表示可以创建工资单，其他代表失败
- msg: string，提示信息；失败时通常为不能创建的原因
- data: dict，创建状态
- data.uid: string，当前查询所属 uid
- data.year: int，年份
- data.month: int，月份
- data.already_exist: bool，所查月份工资单是否已存在
- data.is_time_allowed: bool，当前时间是否允许创建
- data.has_ryxx: bool，是否已存在员工记录

使用示例

zijizhang-cli payroll get_payroll_creation_status 2026-04"""))
def get_payroll_creation_status(
        month: str = typer.Argument(..., help='按月时间，格式 YYYY-MM，如 2026-04'),
        uid: str = typer.Option('', '--uid', help='公司唯一标识uid；不传则使用当前激活公司')
):
    req_year, req_month = parse_month(month)
    service = PayrollService()
    res = service.get_payroll_creation_status(uid, req_year, req_month)
    echo_util.echo_http_res(res)


@payroll_app.command(
    name='get_preview_payroll',
    help="获取预览工资单",
    no_args_is_help=True,
    epilog=cli_help.format_epilog("""
## 返回参数说明

- code: int，200 代表成功，其他代表失败
- msg: string，提示信息
- data: dict，预览工资单数据
- data.uid: string，当前查询所属 uid
- data.year: int，年份
- data.month: int，月份
- data.payroll: list，预览工资单列表

## 补充说明

- 此操作仅结合历史工资单和相关社保数据生成概览
- 该结果不代表最终创建结果
- 最终工资单请通过 `get_payroll` 获取

## 使用示例

zijizhang-cli payroll get_preview_payroll 2026-04

## 推荐展示方式

- 如果结果中，只有一条记录

| 项目 | 内容 |
| :--- | :--- |
| **员工姓名** | {xm} |
| **证件号码** | {zjhm} |
| **本期收入** | {bqsr} 元 |
| **个人社保公积金** | |
| ├─ 住房公积金 | {gr_zfgjj} 元 |
| ├─ 养老保险 | {gr_jbpbxf} 元 |
| ├─ 医疗保险 | {gr_jbmbxf} 元 |
| └─ 失业保险 | {gr_sybxf} 元 |
| **企业社保公积金** | |
| ├─ 住房公积金 | {qy_zfgjj} 元 |
| ├─ 养老保险 | {qy_jbpbxf} 元 |
| ├─ 医疗保险 | {qy_jbmbxf} 元 |
| ├─ 失业保险 | {qy_sybxf} 元 |
| └─ 工伤保险 | {qy_gsbxf} 元 |

- 如果结果中，超过一条记录

| 姓名 | 证件号码 | 本期收入 | 个人公积金 | 个人-养老保险 | 个人-医疗保险 | 个人-失业保险 | 企业-公积金 | 企业-养老保险 | 企业-医疗保险 | 企业-失业保险 | 企业-工伤保险 |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| {xm} | {zjhm} | {bqsr} | {gr_zfgjj} | {gr_jbpbxf} | {gr_jbmbxf} | {gr_sybxf} | {qy_zfgjj} | {qy_jbpbxf} | {qy_jbmbxf} | {qy_sybxf} | {qy_gsbxf} |"""))
def get_preview_payroll(
        month: str = typer.Argument(..., help='工资单月份，格式 YYYY-MM，如 2026-04'),
        uid: str = typer.Option('', '--uid', help='公司唯一标识uid；不传则使用当前激活公司')
):
    req_year, req_month = parse_month(month)
    service = PayrollService()
    res = service.get_preview_payroll(uid, req_year, req_month)
    echo_util.echo_http_res(res)


@payroll_app.command(
    name='create_payroll',
    help='创建工资单',
    no_args_is_help=True,
    epilog=cli_help.format_epilog("""
返回参数说明

- code: int，200 代表成功，其他代表失败
- msg: string，提示信息；失败时为原因
- data: dict，结果数据
- data.uid: string，所属 uid
- data.year: int，年份
- data.month: int，月份

补充说明

创建工资单前，请确认已经使用 `zijizhang-cli payroll get_payroll_creation_status '<month>'`，根据返回状态，确保符合创建工资单的条件

使用示例

zijizhang-cli payroll create_payroll 2026-04 '[{"xm":"夏","zjhm":"310...","bqsr":5000.00,"gr_zfgjj":500.00,"gr_jbpbxf":554.68,"gr_jbmbxf":129.68,"gr_sybxf":25.00,"gr_tq":0.00,"gr_bz":"","qy_zfgjj":500.00,"qy_jbpbxf":800.00,"qy_jbmbxf":421.46,"qy_sybxf":25.00,"qy_qt":0.00,"qy_gsbxf":8.00,"lzbcj":0.00,"qnycxjj":0.00}]'"""))
def create_payroll(
        month: str = typer.Argument(..., help='工资单月份，格式 YYYY-MM，如 2026-04'),
        data: str = typer.Argument(..., help='工资单列表 JSON 字符串；每项常见字段为 xm、zjhm、bqsr，也可传 gr_zfgjj、gr_jbpbxf、qy_zfgjj、qy_gsbxf、lzbcj、qnycxjj 等'),
        uid: str = typer.Option('', '--uid', help='公司唯一标识uid；不传则使用当前激活公司')
):
    req_year, req_month = parse_month(month)
    data_obj = json.loads(data)
    service = PayrollService()
    res = service.create_payroll(uid, req_year, req_month, data_obj)
    echo_util.echo_http_res(res)


@payroll_app.command(
    name='remove_payroll',
    help='删除工资单',
    no_args_is_help=True,
    epilog=cli_help.format_epilog("""
返回参数说明

- code: int，200 代表成功，其他代表失败
- msg: string，提示信息；成功时通常为“操作成功”

使用示例

zijizhang-cli payroll remove_payroll 2026-04"""))
def remove_payroll(month: str = typer.Argument(..., help='工资单月份，格式 YYYY-MM，如 2026-04'),
                   uid: str = typer.Option('', '--uid', help='公司唯一标识uid；不传则使用当前激活公司')):
    req_year, req_month = parse_month(month)
    service = PayrollService()
    service.remove_payroll(uid, req_year, req_month)
