import typer
from pathlib import Path

from app.service.bank_service import BankService
from app.util import cli_help, echo_util

bank_app = typer.Typer()


@bank_app.command(
    name='get_bank_bill_data_list',
    help="获取银行回单/流水列表",
    epilog=cli_help.format_epilog("""
返回参数说明

- code: int，200 代表成功，其他代表失败
- msg: string，提示信息
- data: dict，回单查询结果
- data.uid: string，当前查询所属 uid
- data.cnt: int，返回条数或总数
- data.bill_list: list，回单列表
- data.bill_list[].id: int，回单 id
- data.bill_list[].status: string，状态，如待审核/待确认/已入账
- data.bill_list[].use_list: list，可选用途列表，可用于 `choose_bank_use`

使用示例

zijizhang-cli bank get_bank_bill_data_list --current=1

zijizhang-cli bank get_bank_bill_data_list --date_begin='2026-03-01' --date_end='2026-03-31'"""))
def get_bank_bill_data_list(
    uid: str = typer.Option('', '--uid', help='公司唯一标识uid；不传则使用当前已切换在用的 uid'),
    current: int = typer.Option(1, '--current', help='页码，默认 1'),
    date_begin: str = typer.Option('', '--date_begin', help='交易日期开始，格式 YYYY-MM-DD；如需使用需与 date_end 同时传'),
    date_end: str = typer.Option('', '--date_end', help='交易日期结束，格式 YYYY-MM-DD；如需使用需与 date_begin 同时传'),
):
    service = BankService()
    res = service.get_bank_bill_data_list(uid, current, date_begin, date_end)
    echo_util.echo_http_res(res)


@bank_app.command(
    name='choose_bank_use',
    help="回单选择用途/入账",
    no_args_is_help=True,
    epilog=cli_help.format_epilog("""
返回参数说明

- code: int，200 代表成功，其他代表失败
- msg: string，提示信息
- data: dict，结果数据，可能为空对象

使用示例

zijizhang-cli bank choose_bank_use '123456' '货款'"""))
def choose_bank_use(
    bill_id: int = typer.Argument(...,help='回单单据 id；来自 get_bank_bill_data_list 返回的 bill_list[].id'),
    rule_text: str = typer.Argument(..., help='用途文本；建议从 bill_list[].use_list 中选择'),
    uid: str = typer.Option('', '--uid', help='公司唯一标识uid；不传则使用当前已切换在用的 uid'),
):
    service = BankService()
    res = service.choose_bank_use(uid, bill_id, rule_text)
    echo_util.echo_http_res(res)


@bank_app.command(
    name='set_month_bank_no_water',
    help="标记某个月份无银行回单/流水",
    no_args_is_help=True,
    epilog=cli_help.format_epilog("""
返回参数说明

- code: int，200 代表成功，其他代表失败
- msg: string，提示信息；失败时通常说明该月份已录入回单或当前时间不允许设置
- data: dict，结果数据
- data.uid: string，当前查询所属 uid

使用示例

zijizhang-cli bank set_month_bank_no_water 2026 3"""))
def set_month_bank_no_water(
    year: int = typer.Argument(..., help='年份，如 2026'),
    month: int = typer.Argument(..., help='月份(1-12)，如 3'),
    uid: str = typer.Option('', '--uid', help='公司唯一标识uid；不传则使用当前已切换在用的 uid'),
):
    service = BankService()
    res = service.set_month_bank_no_water(uid, year, month)
    echo_util.echo_http_res(res)


@bank_app.command(
    name='support_bank_list',
    help="获取支持的银行列表",
    epilog=cli_help.format_epilog("""
返回参数说明

- code: int，200 代表成功，其他代表失败
- msg: string，提示信息
- data: list，银行列表
- data[].id: int，银行 id
- data[].bank_name: string，银行名称
- 常用于 `add_bank_account_number` / `del_bank_account_number`

使用示例

zijizhang-cli bank support_bank_list"""))
def support_bank_list():
    service = BankService()
    res = service.support_bank_list()
    echo_util.echo_http_res(res)


@bank_app.command(
    name='bank_account_number_list',
    help="获取银行账号列表",
    epilog=cli_help.format_epilog("""
返回参数说明

- code: int，200 代表成功，其他代表失败
- msg: string，提示信息
- data: list，银行账号列表
- data[].bank_id: int，银行 id
- data[].bank_name: string，银行名称
- data[].bank_number: string，银行账号

使用示例

zijizhang-cli bank bank_account_number_list --uid='<uid>'"""))
def bank_account_number_list(
    uid: str = typer.Option('', '--uid', help='公司唯一标识uid；不传则使用当前已切换在用的 uid'),
):
    service = BankService()
    res = service.bank_account_number_list(uid)
    echo_util.echo_http_res(res)


@bank_app.command(
    name='add_bank_account_number',
    help="添加银行账号",
    no_args_is_help=True,
    epilog=cli_help.format_epilog("""
返回参数说明

- code: int，200 代表成功，其他代表失败
- msg: string，提示信息
- data: dict，结果数据，以服务端返回为准

使用示例

zijizhang-cli bank add_bank_account_number --bank_id=1 --bank_number='6222000000000000'

zijizhang-cli bank add_bank_account_number --uid='<uid>' --bank_id=1 --bank_number='6222000000000000'"""))
def add_bank_account_number(
    bank_id: int = typer.Option(..., '--bank_id', help='银行 id；来自 support_bank_list 返回的银行 id'),
    bank_number: str = typer.Option(..., '--bank_number', help='需要添加的银行账号'),
    uid: str = typer.Option('', '--uid', help='公司唯一标识uid；不传则使用当前已切换在用的 uid'),
):
    service = BankService()
    res = service.add_bank_account_number(uid, bank_id, bank_number)
    echo_util.echo_http_res(res)


@bank_app.command(
    name='del_bank_account_number',
    help="删除银行账号",
    no_args_is_help=True,
    epilog=cli_help.format_epilog("""
返回参数说明

- code: int，200 代表成功，其他代表失败
- msg: string，提示信息
- data: dict，结果数据，以服务端返回为准

使用示例

zijizhang-cli bank del_bank_account_number --bank_id=1 --bank_number='6222000000000000'

zijizhang-cli bank del_bank_account_number --uid='<uid>' --bank_id=1 --bank_number='6222000000000000'"""))
def del_bank_account_number(
    bank_id: int = typer.Option(..., '--bank_id', help='银行 id；来自 support_bank_list 返回的银行 id'),
    bank_number: str = typer.Option(..., '--bank_number', help='需要删除的银行账号'),
    uid: str = typer.Option('', '--uid', help='公司唯一标识uid；不传则使用当前已切换在用的 uid'),
):
    service = BankService()
    res = service.del_bank_account_number(uid, bank_id, bank_number)
    echo_util.echo_http_res(res)


@bank_app.command(
    name='bank_file_list',
    help="获取银行文件列表",
    epilog=cli_help.format_epilog("""
返回参数说明

- code: int，200 代表成功，其他代表失败
- msg: string，提示信息
- data: dict，文件列表结果
- data.uid: string，当前查询所属 uid
- data.current: int，当前页码
- data.total: int，总数
- data.items: list，文件列表
- data.items[].bank_name: string，银行名称
- data.items[].file_type: string，文件类型
- data.items[].file_name: string，文件名
- data.items[].status: string，状态
- data.items[].book_time: string，所属月份

使用示例

zijizhang-cli bank bank_file_list --current=1"""))
def bank_file_list(
    uid: str = typer.Option('', '--uid', help='公司唯一标识uid；不传则使用当前已切换在用的 uid'),
    current: int = typer.Option(1, '--current', help='页码，默认 1'),
):
    service = BankService()
    res = service.bank_file_list(uid, current)
    echo_util.echo_http_res(res)


@bank_app.command(
    name='upload_bank_file',
    help="上传银行文件（明细：Excel；回单：PDF）",
    no_args_is_help=True,
    epilog=cli_help.format_epilog("""
返回参数说明

- code: int，200 代表成功，其他代表失败
- msg: string，提示信息
- data: dict，结果数据，以服务端返回为准

使用示例

zijizhang-cli bank upload_bank_file --file='/path/to/bank.pdf' --file_type='回单' --bank_account_number_id=123 --billing_cycle='2026-03-01'

zijizhang-cli bank upload_bank_file --file='/path/to/detail.xlsx' --file_type='明细' --bank_account_number_id=123 --billing_cycle='2026-03-01'"""))
def upload_bank_file(
    uid: str = typer.Option('', '--uid', help='公司唯一标识uid；不传则使用当前已切换在用的 uid'),
    file: Path = typer.Option(..., '--file', '-f', help='银行文件路径；file_type=明细 仅支持 .xls/.xlsx，file_type=回单 仅支持 .pdf'),
    file_type: str = typer.Option(..., '--file_type', help='文件类型；必填，可选 明细 / 回单'),
    bank_account_number_id: int = typer.Option(..., '--bank_account_number_id', help='银行账户 id；来自 bank_account_number_list 返回的账号 id'),
    billing_cycle: str = typer.Option(..., '--billing_cycle', help='回单文件所属月份，格式 YYYY-MM-DD，如 2026-03-01'),
):
    service = BankService()
    res = service.upload_bank_file(uid, str(file), file_type, bank_account_number_id, billing_cycle)
    echo_util.echo_http_res(res)
