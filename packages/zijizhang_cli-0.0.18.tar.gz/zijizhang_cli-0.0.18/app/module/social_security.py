import typer

from app.service.sb_service import SbService
from app.util import cli_help, echo_util

social_security_app = typer.Typer()


@social_security_app.command(
    name='social_security_history_list',
    help="获取社保申报历史记录列表",
    epilog=cli_help.format_epilog("""
返回参数说明

- code: int，200 代表成功，其他代表失败
- msg: string，提示信息
- data: dict，结果数据，以服务端返回为准

使用示例

zijizhang-cli social_security social_security_history_list --current=1

zijizhang-cli social_security social_security_history_list --uid='<uid>' --current=2"""))
def social_security_history_list(
    uid: str = typer.Option('', '--uid', help='公司唯一标识uid；不传则使用当前已切换在用的 uid'),
    current: int = typer.Option(1, '--current', help='页码，默认 1'),
):
    service = SbService()
    res = service.sb_history_list(uid, current)
    echo_util.echo_http_res(res)


@social_security_app.command(
    name='social_security_now_month_report_info',
    help="获取当月社保申报概览信息",
    epilog=cli_help.format_epilog("""
返回参数说明

- code: int，200 代表成功，其他代表失败
- msg: string，提示信息
- data: dict，当月社保申报概览信息，以服务端返回为准

使用示例

zijizhang-cli social_security social_security_now_month_report_info

zijizhang-cli social_security social_security_now_month_report_info --uid='<uid>'"""))
def social_security_now_month_report_info(
    uid: str = typer.Option('', '--uid', help='公司唯一标识uid；不传则使用当前已切换在用的 uid'),
):
    service = SbService()
    res = service.now_month_sb_report_info(uid)
    echo_util.echo_http_res(res)


@social_security_app.command(
    name='social_security_get_mx_data',
    help="获取某个月份社保明细数据",
    no_args_is_help=True,
    epilog=cli_help.format_epilog("""
返回参数说明

- code: int，200 代表成功，其他代表失败
- msg: string，提示信息
- data: dict，社保明细数据，以服务端返回为准

使用示例

zijizhang-cli social_security social_security_get_mx_data 2026 3

zijizhang-cli social_security social_security_get_mx_data 2026 3 --sb_type=last_month"""))
def social_security_get_mx_data(
    year: int = typer.Argument(..., help='年份，如 2026'),
    month: int = typer.Argument(..., help='月份(1-12)，如 3'),
    sb_type: str = typer.Option('normal', '--sb_type', help='社保类型；可选 normal / last_month，默认 normal'),
    uid: str = typer.Option('', '--uid', help='公司唯一标识uid；不传则使用当前已切换在用的 uid'),
):
    service = SbService()
    res = service.get_sb_mx_data(uid, year, month, sb_type)
    echo_util.echo_http_res(res)


@social_security_app.command(
    name='social_security_build_task',
    help="创建社保申报任务",
    no_args_is_help=True,
    epilog=cli_help.format_epilog("""
返回参数说明

- code: int，200 代表成功，其他代表失败
- msg: string，提示信息
- data: dict，任务创建结果，以服务端返回为准

使用示例

zijizhang-cli social_security social_security_build_task 2026 3

zijizhang-cli social_security social_security_build_task 2026 3 --sb_type=normal"""))
def social_security_build_task(
    year: int = typer.Argument(..., help='年份，如 2026'),
    month: int = typer.Argument(..., help='月份(1-12)，如 3'),
    sb_type: str = typer.Option('normal', '--sb_type', help='社保类型；可选 normal / last_month，默认 normal'),
    uid: str = typer.Option('', '--uid', help='公司唯一标识uid；不传则使用当前已切换在用的 uid'),
):
    service = SbService()
    res = service.build_sb_sb_task(uid, year, month, sb_type)
    echo_util.echo_http_res(res)


@social_security_app.command(
    name='social_security_agree_tax',
    help="同意社保税额/费率（确认金额）",
    no_args_is_help=True,
    epilog=cli_help.format_epilog("""
返回参数说明

- code: int，200 代表成功，其他代表失败
- msg: string，提示信息
- data: dict，确认结果，以服务端返回为准

使用示例

zijizhang-cli social_security social_security_agree_tax 2026 3"""))
def social_security_agree_tax(
    year: int = typer.Argument(..., help='年份，如 2026'),
    month: int = typer.Argument(..., help='月份(1-12)，如 3'),
    uid: str = typer.Option('', '--uid', help='公司唯一标识uid；不传则使用当前已切换在用的 uid'),
):
    service = SbService()
    res = service.agree_sb_tax(uid, year, month)
    echo_util.echo_http_res(res)

@social_security_app.command(
    name='social_security_disagree_tax',
    help="不同意社保税额/费率（驳回金额）",
    no_args_is_help=True,
    epilog=cli_help.format_epilog("""
返回参数说明

- code: int，200 代表成功，其他代表失败
- msg: string，提示信息
- data: dict，驳回结果，以服务端返回为准

使用示例

zijizhang-cli social_security social_security_disagree_tax 2026 3"""))
def social_security_disagree_tax(
    year: int = typer.Argument(..., help='年份，如 2026'),
    month: int = typer.Argument(..., help='月份(1-12)，如 3'),
    uid: str = typer.Option('', '--uid', help='公司唯一标识uid；不传则使用当前已切换在用的 uid'),
):
    service = SbService()
    res = service.disagree_sb_tax(uid, year, month)
    echo_util.echo_http_res(res)
