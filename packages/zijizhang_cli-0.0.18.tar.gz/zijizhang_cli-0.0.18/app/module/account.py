import typer

from app.service.account_service import AccountService
from app.util import cli_help, echo_util

account_app = typer.Typer()


# @account_app.command(
#     name='get_sms_verify_code',
#     help='获取登录的短信验证码',
#     no_args_is_help=True,
#     epilog="""使用示例
#
# zijizhang-cli account get_sms_verify_code 17199999999""")
# def get_sms_verify_code(phone: str = typer.Argument(..., help='自记账的登录手机号')):
#     service = AccountService()
#     res = service.sms_verify_code(phone)
#     echo_util.echo_http_res(res)


# @account_app.command(
#     name='verify_sms_code',
#     help='通过短信验证码登录',
#     no_args_is_help=True,
#     epilog="""使用示例
#
# zijizhang-cli account verify_sms_code 17199999999 5799""")
# def verify_sms_code(
#         phone: str = typer.Argument(..., help='手机号'),
#         code: str = typer.Argument(..., help='短信验证码')):
#     service = AccountService()
#     res = service.sms_code_login(phone, code)
#     echo_util.echo_http_res(res)

@account_app.command(
    name='create_auth_url',
    help='创建登录授权链接',
    epilog=cli_help.format_epilog("""
返回参数说明

- code: int，200 代表成功，其他代表失败
- msg: string，提示信息，失败时为异常信息
- data: object，授权链接相关信息
- data.url: string，快速登录的授权链接
- data.expire_in: int，链接有效时间，单位秒
- data.auth_key: string，授权关联的凭证令牌

使用示例

zijizhang-cli account create_auth_url"""))
def create_auth_url():
    service = AccountService()
    res = service.create_auth_url()
    echo_util.echo_http_res(res)


@account_app.command(
    name='get_cpy_list',
    help='获取可切换的公司列表',
    epilog=cli_help.format_epilog("""
返回参数说明

- code: int，200 代表成功，其他代表失败
- msg: string，提示信息，失败时为异常信息
- data: list，当前账号下的公司列表
- data[].uid: string，公司唯一标识
- data[].cpy_name: string，公司名称
- data[].tax_no: string，公司税号
- data[].active: bool，true 代表当前终端激活在用的公司

使用示例

zijizhang-cli account get_cpy_list"""))
def get_cpy_list():
    service = AccountService()
    res = service.get_cpy_list()
    echo_util.echo_http_res(res)


@account_app.command(
    name='logout',
    help='退出登录',
    epilog=cli_help.format_epilog("""
返回参数说明

- code: int，200 代表成功，其他代表失败
- msg: string，提示信息；成功时通常为“成功退出”

使用示例

zijizhang-cli account logout"""))
def logout():
    service = AccountService()
    res = service.logout()
    echo_util.echo_http_res(res)


@account_app.command(
    name='switch_to',
    help='切换公司',
    no_args_is_help=True,
    epilog=cli_help.format_epilog("""
返回参数说明

- code: int，200 代表成功，其他代表失败
- msg: string，提示信息；成功时会包含切换后的公司名称

使用示例

zijizhang-cli account switch_to 123451c07f47435e12a34111"""))
def switch_to(uid: str = typer.Argument(..., help='公司唯一标识uid；可先通过 `zijizhang-cli account get_cpy_list` 查询')):
    service = AccountService()
    res = service.switch_to(uid)
    echo_util.echo_http_res(res)
