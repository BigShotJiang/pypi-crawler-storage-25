import json
import typer

from app.service.employee_service import EmployeeService
from app.util import cli_help, echo_util

employee_app = typer.Typer()


@employee_app.command(
    name='get_employee_list',
    help="获取员工列表",
    epilog=cli_help.format_epilog("""
返回参数说明

- code: int，200 代表成功，其他代表失败
- msg: string，提示信息
- data: dict，查询结果
- data.uid: string，当前查询所属 uid
- data.ryxx: list，员工列表
- data.ryxx[].id: string，员工唯一标识
- data.ryxx[].xm: string，姓名
- data.ryxx[].zjhm: string，证件号码
- data.ryxx[].sjhm: string，手机号
- data.ryxx[].rzrq: string，入职日期，格式 YYYY-MM-DD
- data.ryxx[].jbgz: float，基本工资

使用示例

zijizhang-cli employee get_employee_list

zijizhang-cli employee get_employee_list --uid='xxxx'

zijizhang-cli employee get_employee_list --keyword='夏天'

zijizhang-cli employee get_employee_list --uid='xxxx' --keyword='夏天'"""))
def get_employee_list(
        uid: str = typer.Option('', '--uid', help='公司唯一标识uid；不传则使用当前激活公司'),
        keyword: str = typer.Option('', '--keyword', help='搜索关键字，支持姓名或证件号码模糊搜索；为空则查询全部')
):
    service = EmployeeService()
    res = service.get_employee_list(uid, keyword)
    echo_util.echo_http_res(res)


@employee_app.command(
    name='add_employee',
    help="添加员工",
    no_args_is_help=True,
    epilog=cli_help.format_epilog("""
返回参数说明

- code: int，200 代表成功，其他代表失败
- msg: string，提示信息；失败时为异常信息

使用示例

zijizhang-cli employee add_employee '{"xm": "夏天", "zjhm":"888888888888888888","sjhm":"18888888888", "rzrq": "2026-01-01", "jbgz": 0}'"""))
def add_employee(
        data: str = typer.Argument(..., help='员工信息 JSON 字符串；必填字段常见为 xm、zjhm、sjhm、rzrq、jbgz，其中 rzrq 格式为 YYYY-MM-DD'),
        uid: str = typer.Option('', '--uid', help='公司唯一标识uid；不传则使用当前激活公司')
):
    data_obj = json.loads(data)
    service = EmployeeService()
    res = service.add_employee(uid, data_obj)
    echo_util.echo_http_res(res)


@employee_app.command(
    name='update_employee',
    help='更新员工信息',
    no_args_is_help=True,
    epilog=cli_help.format_epilog("""
返回参数说明

- code: int，200 代表成功，其他代表失败
- msg: string，提示信息；失败时为异常信息

使用示例

zijizhang-cli employee update_employee 'xxxxxxx' '{"xm": "夏天", "zjhm":"888888888888888888","sjhm":"18888888888", "rzrq": "2026-01-01", "jbgz": 0}'

zijizhang-cli employee update_employee 'xxxxxxx' '{"zjhm":"888888888888888888"}'"""))
def update_employee(
        employee_id: str = typer.Argument(..., help='员工id'),
        data: str = typer.Argument(..., help='待更新字段 JSON 字符串；支持部分字段更新，如 xm、zjhm、sjhm、rzrq、jbgz 等')
):
    data_obj = json.loads(data)
    service = EmployeeService()
    res = service.update_employee(employee_id, data_obj)
    echo_util.echo_http_res(res)
