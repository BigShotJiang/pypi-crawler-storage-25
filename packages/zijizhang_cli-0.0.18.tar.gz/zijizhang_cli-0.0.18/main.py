import typer
from importlib.metadata import version

from app.module.account import account_app
from app.module.employee import employee_app
from app.module.bank import bank_app
from app.module.payroll import payroll_app
from app.module.invoice import invoice_app
from app.module.todo import todo_app
from app.module.social_security import social_security_app

try:
    __version__ = version("zijizhang-cli")
except Exception as ignore:
    __version__ = "dev"

app = typer.Typer(
    name="zijizhang-cli",
    help="自记账的cli工具箱",
    add_completion=True
)


@app.callback(invoke_without_command=True)
def main_callback(
        ctx: typer.Context,
        show_version: bool = typer.Option(
            None,
            "--version", "-v",
            help="Show the version to the output stream and exit"
        )
):
    if show_version:
        typer.echo(__version__)
        raise typer.Exit()


app.add_typer(account_app, name="account", help='账号模块')
app.add_typer(employee_app, name="employee", help='员工模块')
app.add_typer(bank_app, name="bank", help='银行回单模块')
app.add_typer(invoice_app, name="invoice", help='发票模块')
app.add_typer(payroll_app, name="payroll", help='工资单模块')
app.add_typer(todo_app, name="todo", help='待办模块')
app.add_typer(social_security_app, name="social_security", help='社保模块')

if __name__ == '__main__':
    app()
