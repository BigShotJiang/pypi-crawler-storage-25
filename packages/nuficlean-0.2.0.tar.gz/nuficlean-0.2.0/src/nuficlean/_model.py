# -*- coding: utf-8 -*-
"""
Minimal text normalization utilities extracted from nufi_model.py.
Only the functions required by the cleaning pipeline are included here.
"""

import unicodedata


def repair_mojibake(text: str) -> str:
    """Attempt to fix common Latin-1 → UTF-8 mojibake."""
    if not text:
        return text
    suspicious = ("\u00c3", "\u00c2", "\u00e2", "\u00cc", "\u00c9", "\u00f0")
    if not any(ch in text for ch in suspicious):
        return text
    try:
        return text.encode("latin1").decode("utf-8")
    except (UnicodeEncodeError, UnicodeDecodeError):
        return text


def normalize_text(text: str) -> str:
    """
    Repair mojibake, strip BOM, unify apostrophe/quote variants, then NFC-normalize.
    """
    if text is None:
        return ""
    text = repair_mojibake(text)
    text = text.replace("\ufeff", "")
    # Unify apostrophe-like characters so Bana maps (keys use ASCII ') match corpus tokens.
    text = (
        text.replace("\u2018", "'")
        .replace("\u2019", "'")
        .replace("\u0060", "'")
        .replace("\u00b4", "'")
        .replace("\u02bc", "'")  # modifier letter apostrophe
        .replace("\u201c", '"')
        .replace("\u201d", '"')
        .replace("\u00ab", '"')
        .replace("\u00bb", '"')
    )
    return unicodedata.normalize("NFC", text)


__all__ = ["normalize_text", "repair_mojibake"]
