# -*- coding: utf-8 -*-
"""
nuficlean — Nufi text normalisation library.

Quick start::

    from nuficlean import clean, apply_clafrica, finalize_clafrica

    clean("kòlə̀'")              # → "kwele'"
    apply_clafrica("af1 e2 n*")  # → "ɑ̀ é ŋ"
    finalize_clafrica("eu3")     # → "ə̄"

Pipeline (clean)
----------------
1. Repair mojibake & unify apostrophe/quote variants
2. Rewrite Bana substrings to Komako standard (longest-match first)
3. Strip low-tone (grave) diacritics to base letters
4. Final Unicode NFC recomposition

Clafrica
--------
Converts Clafrica keyboard shortcut sequences (ASCII) into the corresponding
Nufi Unicode characters using the canonical mapping table (clafrica.json).
For advanced use, instantiate :class:`ClafricaEngine` directly.
"""

import sys
import unicodedata

from ._bana_classification import normalize_bana_to_standard, normalize_ton_bas
from ._clafrica_engine import ClafricaEngine
from ._model import normalize_text

__version__ = "0.2.0"
__all__ = [
    "clean",
    "clean_lines",
    "apply_clafrica",
    "finalize_clafrica",
    "ClafricaEngine",
]

# Shared default engine instance (lazy-initialised on first use).
_default_engine: ClafricaEngine | None = None


def _engine() -> ClafricaEngine:
    global _default_engine
    if _default_engine is None:
        _default_engine = ClafricaEngine()
    return _default_engine


# ---------------------------------------------------------------------------
# Bana → Komako normalisation
# ---------------------------------------------------------------------------

def clean(text: str) -> str:
    """Apply the full Nufi normalisation pipeline to *text* and return the result."""
    text = normalize_text(text or "")
    text = normalize_bana_to_standard(text)
    text = normalize_ton_bas(text)
    return unicodedata.normalize("NFC", text)


def clean_lines(lines: list[str]) -> list[str]:
    """Clean each line in *lines* and return the cleaned list."""
    return [clean(line) for line in lines]


# ---------------------------------------------------------------------------
# Clafrica keyboard mapping
# ---------------------------------------------------------------------------

def apply_clafrica(text: str, preserve_ambiguous_trailing: bool = False) -> str:
    """Convert Clafrica shortcut sequences in *text* to Nufi Unicode.

    Example::

        apply_clafrica("af1 e2 n*")   # → "ɑ̀ é ŋ"

    With ``preserve_ambiguous_trailing=True`` the last token is left as typed
    when it could still grow into a longer shortcut (live-typing mode).
    """
    return _engine().apply_mapping(text, preserve_ambiguous_trailing)


def finalize_clafrica(text: str) -> str:
    """Finalize *text*: resolve any remaining shortcut suffix and return.

    Example::

        finalize_clafrica("eu3")   # → "ə̄"
    """
    return _engine().finalize_input(text)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _cli() -> None:
    if len(sys.argv) > 1:
        for arg in sys.argv[1:]:
            print(clean(arg))
    else:
        for line in sys.stdin:
            print(clean(line.rstrip("\n")))
