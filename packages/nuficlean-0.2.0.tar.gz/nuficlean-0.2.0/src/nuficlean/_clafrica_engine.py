# -*- coding: utf-8 -*-
"""
Clafrica keyboard mapping engine — converts ASCII shortcut sequences to Nufi Unicode.

Wraps the transformation logic shared with the Android/Windows keyboard, reading the
bundled clafrica.json as the single source of truth for the mapping table.

Quick start::

    from nuficlean import apply_clafrica, finalize_clafrica

    apply_clafrica("af1 e2 n*")     # → "ɑ̀ é ŋ"
    finalize_clafrica("af1 eu3")    # → "ɑ̀ ə̄"
"""

from __future__ import annotations

import importlib.resources
import json
import re


def _load_bundled_map() -> dict[str, str]:
    pkg = importlib.resources.files("nuficlean").joinpath("data/clafrica.json")
    with pkg.open("r", encoding="utf-8") as fh:
        data: dict[str, str] = json.load(fh)
    # Mirror the manual addition in the Android/Windows engine.
    data.setdefault("uu", "ʉ")
    return data


class ClafricaEngine:
    """
    Transforms Clafrica shortcut text (e.g. ``af1``, ``eu3``, ``n*``) into
    the corresponding Nufi Unicode characters.

    Parameters
    ----------
    mapping:
        Custom ``{shortcut: unicode}`` dict.  Defaults to the bundled
        ``clafrica.json`` (the canonical mapping used by Android / Windows
        keyboards).
    extra:
        Optional extra entries merged on top of the base mapping.
    """

    def __init__(
        self,
        mapping: dict[str, str] | None = None,
        extra: dict[str, str] | None = None,
    ) -> None:
        base = mapping if mapping is not None else _load_bundled_map()
        if extra:
            base = {**base, **extra}
        # Separate space-containing entries (phrase patterns) from token entries.
        self._token_map: dict[str, str] = {k: v for k, v in base.items() if " " not in k}
        self._phrase_map: dict[str, str] = {k: v for k, v in base.items() if " " in k}
        self._keys_sorted = sorted(self._token_map, key=lambda k: (-len(k), k))
        self._ambiguous: set[str] = {
            k for k in self._keys_sorted
            if any(len(o) > len(k) and o.startswith(k) for o in self._keys_sorted)
        }
        self._phrase_patterns = [
            (re.compile(re.escape(k)), v)
            for k, v in sorted(self._phrase_map.items(), key=lambda kv: -len(kv[0]))
        ]

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def apply_mapping(self, text: str, preserve_ambiguous_trailing: bool = False) -> str:
        """Transform all shortcut tokens in *text*, whitespace preserved.

        With ``preserve_ambiguous_trailing=True`` the last token is left as-is
        when it could still grow into a longer shortcut (live-typing mode).
        """
        if not text:
            return text
        text = self._apply_phrase_mappings(text)
        segments = self._split(text)
        trailing = len(segments) - 1 if text and not text[-1].isspace() else -1
        out: list[str] = []
        for i, seg in enumerate(segments):
            if seg.isspace():
                out.append(seg)
            elif preserve_ambiguous_trailing and i == trailing:
                out.append(self._apply_live(seg))
            else:
                out.append(self._apply_token(seg))
        return "".join(out)

    def finalize_input(self, text: str) -> str:
        """Finalize *text*: resolve any remaining shortcut suffix and return."""
        if not text:
            return text
        text = self._apply_phrase_mappings(text)
        return "".join(
            seg if seg.isspace() else self._finalize_token(seg)
            for seg in self._split(text)
        )

    def lookup(self, shortcut: str) -> str | None:
        """Return the Unicode value for an exact shortcut, or ``None``."""
        key = self._resolve(shortcut)
        return self._token_map.get(key) if key else None

    # ------------------------------------------------------------------
    # Internal helpers (mirror engine.py logic, clafrica-only)
    # ------------------------------------------------------------------

    @staticmethod
    def _is_ascii(s: str) -> bool:
        return all(ord(c) <= 0x7F for c in s)

    @staticmethod
    def _split(text: str) -> list[str]:
        out: list[str] = []
        i = 0
        for m in re.finditer(r"\s+", text):
            if m.start() > i:
                out.append(text[i:m.start()])
            out.append(m.group())
            i = m.end()
        if i < len(text):
            out.append(text[i:])
        return out or [""]

    def _resolve(self, token: str) -> str | None:
        if token in self._token_map:
            return token
        if self._is_ascii(token):
            lower = token.lower()
            if lower != token and lower in self._token_map:
                return lower
        return None

    def _apply_phrase_mappings(self, text: str) -> str:
        result = text
        changed = True
        while changed:
            changed = False
            for pat, repl in self._phrase_patterns:
                nxt = pat.sub(repl, result)
                if nxt != result:
                    result = nxt
                    changed = True
                    break
        return result

    def _apply_compositional(self, token: str) -> str:
        if not token or any(ord(c) > 0x7F for c in token):
            return token
        result = token
        changed = True
        while changed:
            changed = False
            for key in self._keys_sorted:
                if len(key) > len(result) or key not in result:
                    continue
                nxt = result.replace(key, self._token_map[key])
                if nxt != result:
                    result = nxt
                    changed = True
                    break
        return result

    def _apply_token(self, token: str) -> str:
        if not token:
            return token
        direct = self._resolve(token)
        if direct:
            return self._token_map[direct]
        for pattern in (r"^([a-zA-Z]+\*?)([1-9])([1-9])$", r"^([a-zA-Z]+\*?)([1-9])$"):
            m = re.fullmatch(pattern, token)
            if m:
                combined = "".join(m.groups())
                resolved = self._resolve(combined)
                if resolved:
                    return self._token_map[resolved]
        return self._apply_compositional(token)

    def _longest_trailing_exact_key(self, token: str) -> str | None:
        best: str | None = None
        for i in range(len(token)):
            suffix = token[i:]
            if self._resolve(suffix) and (best is None or len(suffix) > len(best)):
                best = suffix
        return best

    def _longest_trailing_prefix(self, token: str) -> str | None:
        best: str | None = None
        lo = token.lower()
        for i in range(len(token)):
            suffix = token[i:]
            suffix_lo = lo[i:]
            ascii_s = self._is_ascii(suffix)
            if any(
                k.startswith(suffix)
                or (ascii_s and self._is_ascii(k) and k.lower().startswith(suffix_lo))
                for k in self._keys_sorted
            ):
                if best is None or len(suffix) > len(best):
                    best = suffix
        return best

    def _ambiguous_trailing_suffix(self, token: str) -> str | None:
        best: str | None = None
        for i in range(len(token)):
            suffix = token[i:]
            canonical = self._resolve(suffix)
            if canonical and canonical in self._ambiguous:
                if best is None or len(suffix) > len(best):
                    best = suffix
        return best

    def _apply_live(self, token: str) -> str:
        if not token:
            return token
        canonical = self._resolve(token)
        if canonical:
            return token if canonical in self._ambiguous else self._token_map[canonical]
        exact_key = self._longest_trailing_exact_key(token)
        exact_canonical = self._resolve(exact_key) if exact_key else None
        if exact_key and exact_canonical and exact_canonical not in self._ambiguous:
            return self._apply_compositional(token[:-len(exact_key)]) + self._token_map[exact_canonical]
        amb = self._ambiguous_trailing_suffix(token)
        if amb:
            return self._apply_compositional(token[:-len(amb)]) + amb
        prefix = self._longest_trailing_prefix(token)
        if prefix:
            return self._apply_compositional(token[:-len(prefix)]) + prefix
        return self._apply_token(token)

    def _finalize_token(self, token: str) -> str:
        if not token:
            return token
        current = token
        changed = True
        while changed:
            changed = False
            exact_key = self._longest_trailing_exact_key(current)
            exact_canonical = self._resolve(exact_key) if exact_key else None
            if exact_key and exact_canonical:
                nxt = self._apply_compositional(current[:-len(exact_key)]) + self._token_map[exact_canonical]
                if nxt != current:
                    current = nxt
                    changed = True
                    continue
            mapped = self._apply_token(current)
            if mapped != current:
                current = mapped
                changed = True
        return current


__all__ = ["ClafricaEngine"]
