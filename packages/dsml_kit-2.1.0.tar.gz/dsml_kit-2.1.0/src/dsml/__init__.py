"""dsml-kit CLI package."""

from importlib.metadata import PackageNotFoundError, version


try:
    __version__ = version("dsml-kit")
except PackageNotFoundError:
    __version__ = "0+unknown"
