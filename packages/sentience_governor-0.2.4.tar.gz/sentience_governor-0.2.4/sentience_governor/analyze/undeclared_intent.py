"""Undeclared-intent token spend analyzer (v0.2.4).

For a given session, computes how much of the agent's compute was
attributed to reasoning turns that touched execution outside the
session's declared operational intent.

This is the first derived metric over v0.2.3's token-attribution
substrate. It is fully grounded in v0.2.3 trace fields. No schema
changes. No new event types. No probabilistic inference.

Module guarantees (load-bearing — see plan v3 §"Module shape"):

* No I/O. No file reads, no network, no logging side effects.
* No environment state read. No ``os.environ``, no time-based
  branches, no random sources.
* No input mutation. Read-only access patterns; defensive copies
  where needed.
* Byte-stable output for identical inputs. ``repr(result_a) ==
  repr(result_b)`` holds across runs.

These guarantees enable golden-trace tests, replay, and snapshot
comparison without re-validating the analyzer each time.

Algorithm — turn-window bracketing model (plan v3 §"Aggregation
algorithm"):

The wrapper schema does not allow simple "pair SCOPE_ASSERTED with
CONTEXT_SNAPSHOT by ``tool_id``" — ``ContextSnapshotPayload`` does
not carry ``tool_id``. The model implemented here avoids pairing
entirely:

1. Walk events in emit order, scoped to one session.
2. ``CONTEXT_SNAPSHOT`` events carrying populated ``llm_turn_id``
   establish (or advance) the active reasoning turn.
3. ``SCOPE_ASSERTED`` events carrying ``INTENT_MISSING`` (advisory
   flag) or ``POL-001`` (policy violation) at the **event-envelope**
   level buffer their reasons until the next turn-establishing
   ``CONTEXT_SNAPSHOT``, then attribute to that turn.
4. Per-turn token totals come from the first ``CONTEXT_SNAPSHOT``
   per ``(session_id, llm_turn_id)`` with populated token fields
   (dedupe precedence — first populated wins; conflicts increment
   ``dedupe_conflict_count``).
5. ``undeclared_tokens`` = sum of per-turn totals where the turn
   has any buffered reasons.

This model is surface-agnostic: it handles the MCP wrapper's emit
shape (``SCOPE_ASSERTED → CONTEXT_SNAPSHOT``) and the Claude Code
hook's dual-snapshot shape (``CONTEXT_SNAPSHOT pre → SCOPE_ASSERTED
→ CONTEXT_SNAPSHOT post``) uniformly.

Output schema and full edge-case behavior table: see
``docs/plans/v0.2.4-undeclared-intent-token-spend.md`` (revision v3).
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

# ---------------------------------------------------------------------------
# Constants — copy of v0.2.3 enum string values rather than importing the
# enums, so the analyzer is decoupled from the schema module's import path
# and remains a pure-function module with no side-effecting imports.
# These string values are the authoritative wire-format values from
# `sentience_governor/schema/events.py`.
# ---------------------------------------------------------------------------

EVENT_TYPE_SCOPE_ASSERTED = "SCOPE_ASSERTED"
EVENT_TYPE_CONTEXT_SNAPSHOT = "CONTEXT_SNAPSHOT"
EVENT_TYPE_INTENT_DECLARED = "INTENT_DECLARED"

ADVISORY_FLAG_INTENT_MISSING = "INTENT_MISSING"
POLICY_VIOLATION_POL_001 = "POL-001"

# Status values returned in the result dict.
STATUS_OK = "ok"
STATUS_PARTIAL = "partial"
STATUS_NO_TOKEN_DATA = "no_token_data"
STATUS_NO_TURNS = "no_turns"

# Threshold for malformed-event ratio that flips status from ok → partial.
_PARTIAL_MALFORMED_THRESHOLD = 0.25

# Token field names — used in dedupe precedence and per-turn aggregation.
_TOKEN_FIELDS = (
    "llm_prompt_tokens",
    "llm_completion_tokens",
    "llm_cached_read_tokens",
    "llm_cached_write_tokens",
)


# ---------------------------------------------------------------------------
# Internal types — small dataclass-like dicts kept as plain dicts so the
# byte-stable output guarantee is trivially satisfied (dicts of primitives
# serialize deterministically under repr() in Python 3.7+).
# ---------------------------------------------------------------------------


def _new_turn_data() -> Dict[str, Any]:
    """Initialize a fresh turn-data dict.

    Each entry tracks: token totals (filled when the first populated
    CONTEXT_SNAPSHOT for the turn arrives), the list of reasons (any
    INTENT_MISSING or POL-001 from buffered SCOPE_ASSERTED events),
    and the list of tool_ids that touched the turn (for the
    undeclared_turns output).
    """
    return {
        "tokens": {field: 0 for field in _TOKEN_FIELDS},
        "tokens_populated": False,
        "reasons": [],  # list of strings: "INTENT_MISSING" / "POL-001"
        "tool_ids": [],  # list of tool_ids contributing reasons
        "first_seen_index": -1,  # event index where this turn first appeared (for stable ordering)
    }


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def compute_undeclared_intent_spend(events: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Compute undeclared-intent token spend from a session event list.

    Args:
        events: List of governance events for a single session, in
            emit order. Typically loaded from an NDJSON trace.
            Pure function — events are not mutated.

    Returns:
        A structured dict matching the JSON output schema in plan v3.
        Status field indicates ``ok`` / ``partial`` / ``no_token_data`` /
        ``no_turns``.

    Raises:
        Nothing. Malformed events are skipped (per plan v3
        §"Malformed-trace handling"), individual extraction failures
        increment warning counters, and the analyzer always returns
        a structured result.
    """
    # Defensive: accept any iterable, materialize to list once for stable
    # iteration. Do not modify the caller's list.
    events_list = list(events) if events is not None else []
    total_event_count = len(events_list)

    # Walk state.
    current_turn_id: Optional[str] = None
    pending_scope_reasons: List[Dict[str, str]] = []  # [{reason, tool_id}, ...]
    turn_data: Dict[str, Dict[str, Any]] = {}
    session_id: Optional[str] = None
    session_has_declared_intent = False

    # Warning counters.
    unpaired_event_count = 0
    untokened_pair_count = 0
    dedupe_conflict_count = 0
    malformed_event_count = 0
    warnings: List[Dict[str, Any]] = []

    for event_index, event in enumerate(events_list):
        # Malformed-event guard. Skip + count + warn; never raise.
        if not isinstance(event, dict):
            malformed_event_count += 1
            warnings.append(
                {"code": "malformed_event", "event_index": event_index,
                 "detail": "event is not a dict"}
            )
            continue

        event_type = event.get("event_type")
        if not isinstance(event_type, str):
            malformed_event_count += 1
            warnings.append(
                {"code": "malformed_event", "event_index": event_index,
                 "detail": "event_type missing or non-string"}
            )
            continue

        # Capture session_id from the first event that has one.
        if session_id is None:
            sid = event.get("session_id")
            if isinstance(sid, str):
                session_id = sid

        # ------------------------------------------------------------------
        # INTENT_DECLARED — flips session_has_declared_intent to True
        # iff the payload carries a non-empty stated_objective.
        # ------------------------------------------------------------------
        if event_type == EVENT_TYPE_INTENT_DECLARED:
            payload = event.get("payload")
            if isinstance(payload, dict):
                stated = payload.get("stated_objective")
                if isinstance(stated, str) and stated.strip():
                    session_has_declared_intent = True
            continue

        # ------------------------------------------------------------------
        # SCOPE_ASSERTED — collect undeclared-touching reasons into the
        # pending buffer. Reasons attach to the next turn-establishing
        # CONTEXT_SNAPSHOT (or count as unpaired at session end).
        #
        # CRITICAL: advisory_flags and policy_violations are at the
        # event-envelope level (NOT inside payload). Plan v3 §Findings.
        # ------------------------------------------------------------------
        if event_type == EVENT_TYPE_SCOPE_ASSERTED:
            advisory_flags = event.get("advisory_flags") or []
            policy_violations = event.get("policy_violations") or []

            # Defensive — these should be lists of strings per schema.
            if not isinstance(advisory_flags, list):
                advisory_flags = []
            if not isinstance(policy_violations, list):
                policy_violations = []

            payload = event.get("payload")
            tool_id = ""
            if isinstance(payload, dict):
                t = payload.get("tool_id")
                if isinstance(t, str):
                    tool_id = t

            if ADVISORY_FLAG_INTENT_MISSING in advisory_flags:
                pending_scope_reasons.append(
                    {"reason": ADVISORY_FLAG_INTENT_MISSING, "tool_id": tool_id}
                )
            if POLICY_VIOLATION_POL_001 in policy_violations:
                pending_scope_reasons.append(
                    {"reason": POLICY_VIOLATION_POL_001, "tool_id": tool_id}
                )
            continue

        # ------------------------------------------------------------------
        # CONTEXT_SNAPSHOT — may or may not carry llm_turn_id and tokens.
        # If llm_turn_id is populated, this snapshot establishes (or
        # advances) the active turn AND consumes any pending reasons.
        # If llm_turn_id is NOT populated, the snapshot is transparent
        # to the bracketing model (does not establish a turn, does not
        # clear the pending buffer).
        # ------------------------------------------------------------------
        if event_type == EVENT_TYPE_CONTEXT_SNAPSHOT:
            payload = event.get("payload")
            if not isinstance(payload, dict):
                # Malformed — skip. Don't count as malformed_event because
                # the event_type was valid; just no useful payload to read.
                continue

            turn_id = payload.get("llm_turn_id")
            if not isinstance(turn_id, str) or not turn_id:
                # Non-Track-2 CONTEXT_SNAPSHOT (no turn id). Transparent
                # to the bracketing model. But: if it carries populated
                # tokens WITHOUT a turn id, that's an integrator
                # misconfiguration; flag it.
                if _has_populated_tokens(payload):
                    untokened_pair_count += 1
                    warnings.append(
                        {"code": "untokened_pair", "event_index": event_index,
                         "detail": "CONTEXT_SNAPSHOT carried populated tokens "
                                   "without llm_turn_id"}
                    )
                continue

            # Establish or re-encounter this turn.
            if turn_id not in turn_data:
                turn_data[turn_id] = _new_turn_data()
                turn_data[turn_id]["first_seen_index"] = event_index

            # Consume any pending scope reasons into this turn.
            if pending_scope_reasons:
                td = turn_data[turn_id]
                for entry in pending_scope_reasons:
                    if entry["reason"] not in td["reasons"]:
                        td["reasons"].append(entry["reason"])
                    if entry["tool_id"] and entry["tool_id"] not in td["tool_ids"]:
                        td["tool_ids"].append(entry["tool_id"])
                pending_scope_reasons = []

            # Apply token dedupe precedence.
            if _has_populated_tokens(payload):
                td = turn_data[turn_id]
                if not td["tokens_populated"]:
                    # First populated CONTEXT_SNAPSHOT for this turn.
                    for field in _TOKEN_FIELDS:
                        v = payload.get(field)
                        if isinstance(v, int) and v >= 0:
                            td["tokens"][field] = v
                    td["tokens_populated"] = True
                else:
                    # Already have tokens for this turn; check for conflict.
                    incoming = {}
                    for field in _TOKEN_FIELDS:
                        v = payload.get(field)
                        if isinstance(v, int) and v >= 0:
                            incoming[field] = v
                    # Conflict iff any field disagrees with what we already have.
                    conflict = any(
                        incoming.get(field) is not None
                        and incoming[field] != td["tokens"][field]
                        for field in _TOKEN_FIELDS
                    )
                    if conflict:
                        dedupe_conflict_count += 1
                        warnings.append(
                            {"code": "dedupe_conflict", "event_index": event_index,
                             "detail": f"conflicting tokens for turn {turn_id[:12]}"}
                        )

            current_turn_id = turn_id
            continue

        # ------------------------------------------------------------------
        # All other event types (AGENT_REGISTERED, MEMORY_WRITE_ATTEMPT,
        # GOVERNANCE_ERROR) — skip for turn tracking.
        # ------------------------------------------------------------------
        continue

    # ---------------------------------------------------------------------
    # Post-walk: any remaining pending_scope_reasons are unpaired.
    # ---------------------------------------------------------------------
    if pending_scope_reasons:
        unpaired_event_count += len(pending_scope_reasons)
        for entry in pending_scope_reasons:
            warnings.append(
                {"code": "unpaired_scope_asserted", "event_index": -1,
                 "detail": f"reason {entry['reason']} from tool "
                           f"{entry['tool_id']!r} had no following "
                           f"turn-establishing CONTEXT_SNAPSHOT"}
            )

    # ---------------------------------------------------------------------
    # Status determination + aggregation.
    # ---------------------------------------------------------------------

    # No CONTEXT_SNAPSHOTs with llm_turn_id at all → no_token_data.
    if not turn_data:
        return _build_result(
            session_id=session_id,
            status=STATUS_NO_TOKEN_DATA,
            session_has_declared_intent=session_has_declared_intent,
            turn_data={},
            unpaired_event_count=unpaired_event_count,
            untokened_pair_count=untokened_pair_count,
            dedupe_conflict_count=dedupe_conflict_count,
            malformed_event_count=malformed_event_count,
            warnings=warnings,
            total_event_count=total_event_count,
        )

    # Turns established but no populated tokens anywhere → no_turns.
    any_populated = any(td["tokens_populated"] for td in turn_data.values())
    if not any_populated:
        return _build_result(
            session_id=session_id,
            status=STATUS_NO_TURNS,
            session_has_declared_intent=session_has_declared_intent,
            turn_data=turn_data,
            unpaired_event_count=unpaired_event_count,
            untokened_pair_count=untokened_pair_count,
            dedupe_conflict_count=dedupe_conflict_count,
            malformed_event_count=malformed_event_count,
            warnings=warnings,
            total_event_count=total_event_count,
        )

    # Status partial fires for any of the four counter conditions (per
    # plan v3 status definitions — "partial: analysis completed but
    # warnings accumulated (unpaired events, untokened pairs, dedupe
    # conflicts, or malformed events)"). The malformed >25% threshold is
    # still surfaced as the bigger structural concern; below that, any
    # single counter still flips to partial.
    status = STATUS_OK
    if total_event_count > 0:
        ratio = malformed_event_count / total_event_count
        if ratio > _PARTIAL_MALFORMED_THRESHOLD:
            status = STATUS_PARTIAL

    if status == STATUS_OK and (
        unpaired_event_count > 0
        or untokened_pair_count > 0
        or dedupe_conflict_count > 0
        or malformed_event_count > 0
    ):
        status = STATUS_PARTIAL

    return _build_result(
        session_id=session_id,
        status=status,
        session_has_declared_intent=session_has_declared_intent,
        turn_data=turn_data,
        unpaired_event_count=unpaired_event_count,
        untokened_pair_count=untokened_pair_count,
        dedupe_conflict_count=dedupe_conflict_count,
        malformed_event_count=malformed_event_count,
        warnings=warnings,
        total_event_count=total_event_count,
    )


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _has_populated_tokens(payload: Dict[str, Any]) -> bool:
    """True iff at least one of the four token fields is populated with
    a non-negative int.

    Treats negative values, non-int types, and missing fields as
    unpopulated.
    """
    for field in _TOKEN_FIELDS:
        v = payload.get(field)
        if isinstance(v, int) and not isinstance(v, bool) and v >= 0:
            return True
    return False


def _build_result(
    *,
    session_id: Optional[str],
    status: str,
    session_has_declared_intent: bool,
    turn_data: Dict[str, Dict[str, Any]],
    unpaired_event_count: int,
    untokened_pair_count: int,
    dedupe_conflict_count: int,
    malformed_event_count: int,
    warnings: List[Dict[str, Any]],
    total_event_count: int,
) -> Dict[str, Any]:
    """Assemble the final structured result dict.

    Order of keys is fixed for byte-stable output (Python 3.7+ dicts
    preserve insertion order, so building keys in a fixed order
    guarantees identical repr() across runs).
    """
    # Aggregate per-turn totals.
    total_tokens = 0
    undeclared_tokens = 0
    declared_tokens = 0
    undeclared_turn_count = 0
    total_turn_count = len(turn_data)

    # Per-turn entries for the output, sorted by first_seen_index for
    # stable ordering.
    sorted_turns = sorted(
        turn_data.items(),
        key=lambda kv: (kv[1]["first_seen_index"], kv[0]),
    )

    undeclared_turns: List[Dict[str, Any]] = []
    for turn_id, td in sorted_turns:
        turn_total = sum(td["tokens"][field] for field in _TOKEN_FIELDS)
        total_tokens += turn_total
        if td["reasons"]:
            undeclared_tokens += turn_total
            undeclared_turn_count += 1
            undeclared_turns.append({
                "turn_id": turn_id,
                "tokens": turn_total,
                "reasons": list(td["reasons"]),
                "tool_ids": list(td["tool_ids"]),
            })
        else:
            declared_tokens += turn_total

    # Ratio + percent calculations. Avoid division by zero.
    if total_tokens > 0:
        undeclared_ratio = undeclared_tokens / total_tokens
        undeclared_percent = round(undeclared_ratio * 100, 1)
    else:
        undeclared_ratio = 0.0
        undeclared_percent = 0.0

    return {
        "session_id": session_id or "",
        "status": status,
        "session_has_declared_intent": session_has_declared_intent,
        "total_tokens": total_tokens,
        "undeclared_tokens": undeclared_tokens,
        "declared_tokens": declared_tokens,
        "undeclared_ratio": undeclared_ratio,
        "undeclared_percent": undeclared_percent,
        "undeclared_turn_count": undeclared_turn_count,
        "total_turn_count": total_turn_count,
        "undeclared_turns": undeclared_turns,
        "warnings": warnings,
        "unpaired_event_count": unpaired_event_count,
        "untokened_pair_count": untokened_pair_count,
        "dedupe_conflict_count": dedupe_conflict_count,
        "malformed_event_count": malformed_event_count,
    }
