"""`sentience` — signal-first trace viewer for agent-hook sessions.

Purpose
-------
Opinionated CLI for the high-noise, high-volume agent-hook workflow
(Claude Code today; Cursor / Codex / OpenCode in the future). Three
subcommands:

* ``sentience status`` — self-check. Is the hook capturing sessions?
* ``sentience list`` — what sessions exist? One line per session.
* ``sentience open [--latest | <session_id>]`` — curated view of one
  session with Summary, Focus block, Notes, Key Events, Full Trace,
  Footer.

Relationship to ``sentience-cli``
---------------------------------
Two CLIs, two audiences.

* ``sentience-cli <file>`` (``sentience_governor.cli.viewer``) is the
  raw, full-fidelity viewer. Every event renders with detail. Used by
  library integrators (MCP wrapper, LangChain) and by the
  golden-trace snapshot tests. Stays unchanged.

* ``sentience`` (this module) is the curated, narrative viewer. Uses
  signal-hierarchy rendering with a baseline-noise classifier so
  hundreds of near-identical events in a Claude Code session compress
  into a scannable story.

Spec
----
The full design lives at ``docs/plans/sentience-cli-v1-ux.md``. That
doc is the source of truth; this module must not drift from it.

Implementation notes
--------------------
* Single-file v1. Classifier, formatter, render blocks, and CLI
  dispatch all live here. Can split into submodules later if any one
  piece grows.
* Reuses ``parse_events`` from :mod:`sentience_governor.cli.viewer`
  for the trace parsing primitive — no duplicate JSONL handling.
* Reuses the default sink path from
  :mod:`sentience_governor.wrapper.claude_code_hook` so a user who
  has not set ``SENTIENCE_CLAUDE_CODE_SINK_PATH`` gets the same path
  the hook writes to.
* Fail-safe: unknown tools, missing fields, corrupt JSON lines all
  render as ``???`` rather than crashing. Forward-compatible with
  future adapters.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

from sentience_governor.analyze import (
    compute_undeclared_intent_spend,
    render_cli as render_undeclared_cli,
    render_markdown_report as render_undeclared_markdown,
)
from sentience_governor.cli.first_run import maybe_run_first_run_flow
from sentience_governor.cli.viewer import parse_events

# ---------------------------------------------------------------------------
# Defaults — mirror what the Claude Code hook writes to.
# Imported lazily so test suites that patch env vars still see them.
# ---------------------------------------------------------------------------

_DEFAULT_SINK_DIR = Path.home() / ".sentience" / "traces" / "claude-code"


def _resolve_trace_dir() -> Path:
    """Return the trace directory the hook is writing to.

    Honours the same env var the Claude Code hook honours
    (``SENTIENCE_CLAUDE_CODE_SINK_PATH``) with the same disambiguation
    rule: ``.jsonl`` suffix = shared-file mode (return parent
    directory); anything else = per-session directory mode.
    """
    raw = os.environ.get("SENTIENCE_CLAUDE_CODE_SINK_PATH", "").strip()
    if not raw:
        return _DEFAULT_SINK_DIR
    base = Path(raw).expanduser()
    if base.suffix == ".jsonl":
        return base.parent
    return base


# ---------------------------------------------------------------------------
# Gloss table — LOCKED per docs/plans/sentience-cli-v1-ux.md §5.5.
# Every advisory / policy code here must match the plan doc exactly.
# ---------------------------------------------------------------------------

_GLOSS: Dict[str, str] = {
    "POL-001": "write operation without declared intent",
    "POL-002": "agent not registered",
    "POL-003": "unclassified context",
    "POL-004": "memory write without classification or retention policy",
    "POL-005": "sensitivity escalation without authorization",
    "INTENT_MISSING": "no intent declared",
    "SCOPE_INTENT_MISMATCH": "tool call does not match declared intent",
    "SCOPE_OPERATION_UNEXPECTED": "unexpected operation type for declared scope",
    "CONTEXT_UNCLASSIFIED": "context data not classified",
    "SENSITIVITY_ESCALATION": "context sensitivity escalated",
    "MEMORY_WRITE_CANDIDATE": "write outside declared scope",
    "MEMORY_WRITE_UNCLASSIFIED": "memory write lacks classification",
    "AGENT_UNREGISTERED": "agent not registered before session start",
}


def _gloss(code: str) -> str:
    """Return the plain-English gloss for a code; empty string if unknown.

    Per §5.5: if a new code appears that is not in the table, render
    the code alone (no invented wording).
    """
    return _GLOSS.get(code, "")


# ---------------------------------------------------------------------------
# Baseline-noise classifier — §6.1 of the plan.
# ---------------------------------------------------------------------------

# Known baseline patterns: (event_type, code) where code may be an
# advisory flag OR a policy violation. Both forms appear on the wire.
_BASELINE_PATTERNS: set = {
    ("INTENT_DECLARED", "INTENT_MISSING"),
    ("CONTEXT_SNAPSHOT", "POL-003"),
    ("CONTEXT_SNAPSHOT", "CONTEXT_UNCLASSIFIED"),
}

_BASELINE_FREQUENCY_THRESHOLD = 0.80


@dataclass
class _ClassifiedSession:
    """Result of classifying one session's events.

    ``anomalies`` holds one entry per event that carries at least one
    anomaly code. ``baseline_codes_present`` records which known
    baseline patterns crossed the 80% threshold in this session.

    Focus is derived from ``anomalies`` (§5.2 coupling rule). Summary
    is derived from ``anomaly_code_counts``. Both come from the same
    source; they cannot drift.
    """

    events: List[dict]
    anomalies: List["_EventAnomaly"] = field(default_factory=list)
    anomaly_code_counts: Counter = field(default_factory=Counter)
    baseline_codes_present: set = field(default_factory=set)
    tool_counts: Counter = field(default_factory=Counter)


@dataclass
class _EventAnomaly:
    """One event's worth of anomaly data, carried through to render."""

    sequence: int
    event_type: str
    tool_name: str
    tool_input: dict
    code: str  # the primary (highest-priority) anomaly code
    all_codes: List[str]
    user_impact_rank: int  # lower is more severe per §5.3 ordering
    raw_event: dict = field(default_factory=dict)
    # raw_event is carried so Key Events / Focus refs can render
    # non-SCOPE events (MEMORY_WRITE_ATTEMPT, INTENT_DECLARED, etc.)
    # via _format_event_oneline rather than the tool-action path.


def _user_impact_rank(event_type: str, code: str, tool_name: str) -> int:
    """Rank an anomaly by user impact (§5.3 ordering).

    Lower is more severe. Ordering:
      1. Destructive operations (writes, deletes, memory writes)
      2. Unexpected command execution (Bash-class)
      3. Scope mismatches
      4. Context exposure issues
    Policy-code severity is a tiebreaker only.
    """
    if code in ("MEMORY_WRITE_CANDIDATE", "MEMORY_WRITE_UNCLASSIFIED", "POL-004"):
        return 1
    if event_type == "MEMORY_WRITE_ATTEMPT":
        return 1
    if tool_name == "Bash" and code in (
        "POL-001",
        "SCOPE_OPERATION_UNEXPECTED",
    ):
        return 2
    if code in ("SCOPE_INTENT_MISMATCH", "SCOPE_OPERATION_UNEXPECTED", "POL-001"):
        return 3
    if code in ("SENSITIVITY_ESCALATION", "POL-005"):
        return 4
    # Anything else (unknown codes, context flags not filtered as baseline)
    return 5


def classify_session(events: List[dict]) -> _ClassifiedSession:
    """Classify events into anomalies vs baseline noise.

    Pattern + frequency rule per §6.1:

    * A ``(event_type, code)`` tuple is baseline iff it matches a
      known-baseline pattern AND appears in >80% of eligible events
      of that event_type.
    * Everything else is anomaly.

    ``events`` must already be ordered by event_sequence_number. The
    caller (``parse_events``) guarantees this.
    """
    result = _ClassifiedSession(events=events)

    # Step 1 — compute per-event-type frequencies for each known pattern.
    events_by_type: Dict[str, List[dict]] = defaultdict(list)
    for ev in events:
        events_by_type[ev.get("event_type", "")].append(ev)

    baseline_eligible: set = set()  # (event_type, code) tuples that meet the rule
    for pattern in _BASELINE_PATTERNS:
        event_type, code = pattern
        eligible = events_by_type.get(event_type, [])
        if not eligible:
            continue
        matching = 0
        for ev in eligible:
            if _event_has_code(ev, code):
                matching += 1
        frequency = matching / len(eligible)
        if frequency > _BASELINE_FREQUENCY_THRESHOLD:
            baseline_eligible.add(pattern)
            result.baseline_codes_present.add(code)

    # Step 2 — walk events, classify each code as baseline or anomaly.
    for ev in events:
        event_type = ev.get("event_type", "")
        tool_name = _extract_tool_name(ev)
        if tool_name:
            result.tool_counts[tool_name] += 1

        event_codes = _all_event_codes(ev)
        anomaly_codes: List[str] = []
        for code in event_codes:
            if (event_type, code) in baseline_eligible:
                continue  # baseline noise
            anomaly_codes.append(code)

        if not anomaly_codes:
            continue

        # Pick the highest-priority anomaly code (lowest rank value).
        ranked = sorted(
            anomaly_codes,
            key=lambda c: _user_impact_rank(event_type, c, tool_name),
        )
        primary = ranked[0]
        for c in anomaly_codes:
            result.anomaly_code_counts[c] += 1

        result.anomalies.append(
            _EventAnomaly(
                sequence=ev.get("event_sequence_number", 0),
                event_type=event_type,
                tool_name=tool_name,
                tool_input=_extract_tool_input(ev),
                code=primary,
                all_codes=anomaly_codes,
                user_impact_rank=_user_impact_rank(event_type, primary, tool_name),
                raw_event=ev,
            )
        )

    return result


def _all_event_codes(event: dict) -> List[str]:
    """Flatten advisory_flags + policy_violations into a single list."""
    flags = event.get("advisory_flags") or []
    vios = event.get("policy_violations") or []
    out: List[str] = []
    if isinstance(flags, list):
        out.extend(str(x) for x in flags if x)
    if isinstance(vios, list):
        out.extend(str(x) for x in vios if x)
    return out


def _event_has_code(event: dict, code: str) -> bool:
    return code in _all_event_codes(event)


# ---------------------------------------------------------------------------
# Locked event formatting table — §5.6 of the plan.
# Unknown tools fall back to `<tool_name> → ???`, NEVER crash.
# Tool identity is always preserved even when payload is unknown.
# ---------------------------------------------------------------------------


def _extract_tool_name(event: dict) -> str:
    """Return the tool_id from a SCOPE_ASSERTED payload, or empty string."""
    payload = event.get("payload")
    if not isinstance(payload, dict):
        return ""
    return str(payload.get("tool_id") or "")


def _extract_tool_input(event: dict) -> dict:
    """Best-effort extraction of tool_input shape from either a native
    wrapper trace or a Claude Code hook trace.

    The library wrappers emit SCOPE_ASSERTED events without tool_input
    in the payload. The Claude Code hook also does not encode tool_input
    on SCOPE_ASSERTED (it appears on the PreToolUse payload at dispatch,
    not on the emitted event). We return an empty dict in that case;
    the formatter falls back to ``???`` which is the documented behaviour.
    """
    payload = event.get("payload")
    if not isinstance(payload, dict):
        return {}
    ti = payload.get("tool_input")
    return ti if isinstance(ti, dict) else {}


def _format_tool_action(tool_name: str, tool_input: dict) -> str:
    """Render a tool invocation per the LOCKED §5.6 table.

    Preserves tool identity even when the payload shape is unknown:
    returns ``<tool_name> → ???`` rather than collapsing to ``???``.
    """
    if not tool_name:
        # Truly unknown event shape — preserve a minimal identity
        return "??? → ???"

    ti = tool_input if isinstance(tool_input, dict) else {}

    if tool_name == "Bash":
        cmd = str(ti.get("command") or "")
        if not cmd:
            return f'{tool_name} → ???'
        shown = cmd[:60] + ("…" if len(cmd) > 60 else "")
        return f'{tool_name} → run("{shown}")'

    if tool_name in ("Edit", "Write", "NotebookEdit", "Read"):
        path = ti.get("file_path") or ti.get("notebook_path") or ""
        if not path:
            return f'{tool_name} → ???'
        return f'{tool_name} → "{path}"'

    if tool_name == "Grep":
        pattern = ti.get("pattern") or ""
        path = ti.get("path") or ""
        if pattern and path:
            return f'{tool_name} → "{pattern}" in "{path}"'
        if pattern:
            return f'{tool_name} → "{pattern}"'
        return f'{tool_name} → ???'

    if tool_name == "Glob":
        pattern = ti.get("pattern") or ""
        return f'{tool_name} → "{pattern}"' if pattern else f'{tool_name} → ???'

    if tool_name == "WebFetch":
        url = ti.get("url") or ""
        return f'{tool_name} → {url}' if url else f'{tool_name} → ???'

    if tool_name == "WebSearch":
        query = ti.get("query") or ""
        return f'{tool_name} → "{query}"' if query else f'{tool_name} → ???'

    if tool_name in ("Agent", "Task"):
        desc = ti.get("description") or ti.get("prompt") or ""
        if desc:
            shown = str(desc)[:60] + ("…" if len(str(desc)) > 60 else "")
            return f'{tool_name} → {shown}'
        return f'{tool_name} → ???'

    if tool_name.startswith("mcp__"):
        parts = tool_name.split("__", 2)
        if len(parts) >= 3:
            _, server, op = parts
            return f"MCP[{server}] → {op}(...)"
        return f'{tool_name} → ???'

    # Unknown tool — preserve identity, degrade payload to ???.
    return f'{tool_name} → ???'


def _format_anomaly_action(anomaly: "_EventAnomaly") -> str:
    """Render one anomaly's action line for Key Events / Focus refs.

    SCOPE_ASSERTED events render via the tool-action path (preserves
    tool identity via :func:`_format_tool_action`). Non-SCOPE events
    (MEMORY_WRITE_ATTEMPT, INTENT_DECLARED, CONTEXT_SNAPSHOT) render
    via :func:`_format_event_oneline` so operators see a meaningful
    narrative instead of ``??? → ???``.
    """
    if anomaly.event_type == "SCOPE_ASSERTED":
        return _format_tool_action(anomaly.tool_name, anomaly.tool_input or {})
    if anomaly.raw_event:
        return _format_event_oneline(anomaly.raw_event)
    return "??? → ???"


def _format_nontool_event(event: dict) -> str:
    """Render a non-tool event as narrative per §5.6, not schema.

    Examples:
        INTENT_DECLARED → none provided
        CONTEXT_SNAPSHOT → unclassified context (44 tokens)
        AGENT_REGISTERED → agent claude-code-abc123
        MEMORY_WRITE_ATTEMPT → write to filesystem
    """
    event_type = event.get("event_type", "???")
    payload = event.get("payload") if isinstance(event.get("payload"), dict) else {}

    if event_type == "AGENT_REGISTERED":
        agent_id = payload.get("agent_id") or event.get("agent_id") or "unknown"
        return f"{event_type} → agent {agent_id}"

    if event_type == "INTENT_DECLARED":
        source = payload.get("intent_source") or "none"
        if source in (None, "none", "", "unknown"):
            return f"{event_type} → none provided"
        objective = payload.get("stated_objective")
        if objective:
            shown = str(objective)[:50] + ("…" if len(str(objective)) > 50 else "")
            return f'{event_type} → "{shown}" (source={source})'
        return f"{event_type} → source={source}"

    if event_type == "CONTEXT_SNAPSHOT":
        tokens = payload.get("context_size_tokens")
        classification = payload.get("classification_source") or "unclassified"
        if tokens is not None:
            return f"{event_type} → {classification} context ({tokens} tokens)"
        return f"{event_type} → {classification} context"

    if event_type == "MEMORY_WRITE_ATTEMPT":
        target = payload.get("target_store") or "unknown target"
        return f"{event_type} → write to {target}"

    if event_type == "GOVERNANCE_ERROR":
        err = payload.get("error_type") or "unknown"
        return f"{event_type} → {err}"

    return f"{event_type} → ???"


def _format_event_oneline(event: dict) -> str:
    """Render any event as a single indented narrative line.

    For SCOPE_ASSERTED: ``<primitive> → <tool> → <action>``.
    For everything else: delegated to :func:`_format_nontool_event`.
    """
    event_type = event.get("event_type", "???")
    if event_type == "SCOPE_ASSERTED":
        tool_name = _extract_tool_name(event)
        tool_input = _extract_tool_input(event)
        action = _format_tool_action(tool_name, tool_input)
        # action already contains `<tool> → <payload>`; prefix with primitive.
        return f"{event_type} → {action}"
    return _format_nontool_event(event)


# ---------------------------------------------------------------------------
# Focus derivation — §5.3, MUST derive from Summary's anomaly list
# (§5.2 coupling rule). Never compute anomalies twice.
# ---------------------------------------------------------------------------


@dataclass
class _FocusBullet:
    marker: str  # always "⚠" per §5.3
    description: str  # plain-English ("write operations outside declared scope")
    refs: List[str]  # event-formatted references


def _build_focus_bullets(cls: _ClassifiedSession) -> List[_FocusBullet]:
    """Group anomalies into up to 4 user-impact-ordered bullets.

    Grouping strategy:
      1. Destructive ops (rank 1) -> "N write operations outside declared scope"
      2. Unexpected commands (rank 2) -> "N unexpected command executions"
      3. Scope mismatches (rank 3) -> "N scope mismatches"
      4. Context/escalation (rank 4) -> "N context escalations"
      Everything else (rank 5) -> "N other anomalies"

    Each bullet's ``refs`` holds up to 3 concrete event-formatted
    references for inline display (§5.3 example shape).
    """
    if not cls.anomalies:
        return []

    groups: Dict[int, List[_EventAnomaly]] = defaultdict(list)
    for a in cls.anomalies:
        groups[a.user_impact_rank].append(a)

    rank_to_label = {
        1: "write operations outside declared scope",
        2: "unexpected command executions",
        3: "scope mismatches",
        4: "context escalations",
        5: "other anomalies",
    }

    bullets: List[_FocusBullet] = []
    for rank in sorted(groups.keys()):
        group = groups[rank]
        label = rank_to_label[rank]
        refs = []
        for a in group[:3]:
            refs.append(_format_anomaly_action(a))
        bullets.append(
            _FocusBullet(
                marker="⚠",
                description=f"{len(group)} {label}",
                refs=refs,
            )
        )

    return bullets[:4]


# ---------------------------------------------------------------------------
# Render — the six-block output of `sentience open`.
# ---------------------------------------------------------------------------


def _render_header(session_id: str, events: List[dict]) -> str:
    first_ts = ""
    for ev in events:
        ts = ev.get("timestamp_utc") or ev.get("timestamp") or ""
        if ts:
            first_ts = ts.split(".")[0].replace("T", " ")
            break
    return (
        f"Session: {session_id}\n"
        f"Time:    {first_ts or 'unknown'}\n"
        f"Events:  {len(events)}\n"
    )


def _render_summary(cls: _ClassifiedSession) -> str:
    if cls.anomalies:
        status_line = "Status: ⚠ anomalies detected\n"
        lines = [status_line, ""]
        total = sum(cls.anomaly_code_counts.values())
        lines.append(f"⚠ Violations: {total}")
        for code, n in cls.anomaly_code_counts.most_common():
            g = _gloss(code)
            suffix = f" — {g}" if g else ""
            lines.append(f"  - {n} {code}{suffix}")
    else:
        lines = [
            "Status: ✓ baseline behavior",
            "",
            "No violations beyond expected Claude Code baseline.",
        ]

    lines.append("")
    lines.append("Top tools:")
    top = cls.tool_counts.most_common(5)
    if top:
        for tool, n in top:
            lines.append(f"  {tool} ({n})")
    else:
        lines.append("  (none)")
    lines.append("")
    return "Summary\n\n" + "\n".join(lines)


def _render_focus(cls: _ClassifiedSession) -> str:
    header = "Focus (what to pay attention to)\n\n"
    if not cls.anomalies:
        return header + "No anomalies detected. Observed flags match expected Claude Code baseline behavior.\n"
    bullets = _build_focus_bullets(cls)
    body_lines: List[str] = []
    for b in bullets:
        refs_text = ""
        if b.refs:
            refs_text = " (" + "; ".join(b.refs) + ")"
        body_lines.append(f"• {b.marker} {b.description}{refs_text}")
    return header + "\n".join(body_lines) + "\n"


def _render_notes(cls: _ClassifiedSession) -> str:
    """Shown only when at least one baseline code crossed the threshold."""
    if not cls.baseline_codes_present:
        return ""
    lines = ["Notes", ""]
    if "INTENT_MISSING" in cls.baseline_codes_present:
        lines.append("- INTENT_MISSING is expected (Claude Code does not expose intent yet)")
    if ("POL-003" in cls.baseline_codes_present
            or "CONTEXT_UNCLASSIFIED" in cls.baseline_codes_present):
        lines.append("- POL-003 appears on most context reads (current classification limitation)")
    lines.append("- Focus on:")
    lines.append("    • scope mismatches")
    lines.append("    • write operations")
    lines.append("    • unexpected tool usage")
    lines.append("")
    return "\n".join(lines)


def _render_key_events(cls: _ClassifiedSession) -> str:
    header = "Key Events\n\n"
    if not cls.anomalies:
        return header + "No violations detected in this session.\n"

    ordered = sorted(
        cls.anomalies,
        key=lambda a: (a.user_impact_rank, a.sequence),
    )
    shown = ordered[:10]
    more = len(ordered) - len(shown)

    blocks: List[str] = []
    for a in shown:
        action = _format_anomaly_action(a)
        gloss = _gloss(a.code)
        issue = f"{a.code} ({gloss})" if gloss else a.code
        blocks.append(f"⚠ [{a.sequence}] {action}\n    Issue: {issue}")
    out = "\n\n".join(blocks) + "\n"
    if more > 0:
        out += f"\n... and {more} more (see Full Trace)\n"
    return header + out


def _render_full_trace(events: List[dict]) -> str:
    header = "Full Trace\n\n"
    lines: List[str] = []
    for ev in events:
        seq = ev.get("event_sequence_number", "?")
        line = _format_event_oneline(ev)
        lines.append(f"[{seq}] {line}")
    return header + "\n".join(lines) + "\n"


def _render_footer(trace_dir: Path, session_file: Optional[Path]) -> str:
    raw_path = str(session_file) if session_file else str(trace_dir)
    return (
        "Next steps\n\n"
        "View all sessions → sentience list\n"
        "Open another      → sentience open <session_id>\n"
        f"Raw JSONL         → cat {raw_path}\n"
        "\n"
        "Tip: after running Claude Code, use `sentience open --latest` to review the session.\n"
    )


def render_open(
    session_id: str,
    events: List[dict],
    session_file: Path,
    summary: bool = False,
) -> str:
    """Compose the output for one session.

    ``summary=False`` (default): six-block output — Header, Summary,
    Focus, Notes, Key Events, Full Trace, Footer.

    ``summary=True``: skips the Full Trace block. Fits on one terminal
    screen for the typical session. Every anomaly still surfaces in
    Key Events; the JSONL file on disk is unchanged. The footer
    already tells operators where to read the raw events if they
    need them.

    Note: this is not a filter on event content. The Full Trace
    invariant ("every event rendered in order") holds on the default
    output; ``--summary`` only controls whether that block is
    printed to the terminal.
    """
    cls = classify_session(events)
    blocks = [
        _render_header(session_id, events),
        _render_summary(cls),
        _render_focus(cls),
        _render_notes(cls),
        _render_key_events(cls),
    ]
    if not summary:
        blocks.append(_render_full_trace(events))
    blocks.append(_render_footer(session_file.parent, session_file))
    # Notes block is empty for clean sessions — elide it cleanly.
    return "\n".join(b for b in blocks if b)


# ---------------------------------------------------------------------------
# Session discovery — shared by `list`, `open --latest`, `open <id>`.
# ---------------------------------------------------------------------------


def _list_session_files(trace_dir: Path) -> List[Path]:
    """Return .jsonl session files in the directory, newest first.

    Excludes the ``.jsonl.index`` sidecar glob automatically (Path.glob
    suffix match is strict).
    """
    if not trace_dir.exists() or not trace_dir.is_dir():
        return []
    files = [p for p in trace_dir.glob("*.jsonl") if p.is_file()]
    files.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    return files


def _load_session(path: Path) -> Tuple[str, List[dict]]:
    """Load one session file, return (session_id, events).

    Uses the shared ``parse_events`` so NDJSON / JSON-array parsing
    stays consistent with ``sentience-cli``. If the file contains
    multiple session_ids (shared-file mode), returns only the
    session_id matching the filename stem, falling back to the first
    session_id encountered.
    """
    with open(path, encoding="utf-8") as fh:
        sessions = parse_events(fh)
    if not sessions:
        return (path.stem, [])
    if path.stem in sessions:
        return (path.stem, sessions[path.stem])
    # Shared-file or stem mismatch — pick the first session encountered.
    first = next(iter(sessions))
    return (first, sessions[first])


def _relative_time(mtime: float, now: Optional[float] = None) -> str:
    now = now or time.time()
    delta = max(0, now - mtime)
    if delta < 60:
        return "just now"
    if delta < 3600:
        return f"{int(delta / 60)}m ago"
    if delta < 86400:
        return f"{int(delta / 3600)}h ago"
    if delta < 7 * 86400:
        return f"{int(delta / 86400)}d ago"
    # Over a week — show absolute date.
    return time.strftime("%Y-%m-%d", time.localtime(mtime))


# ---------------------------------------------------------------------------
# Subcommand handlers
# ---------------------------------------------------------------------------


def run_status(args: argparse.Namespace) -> int:
    """`sentience status` — is the hook capturing sessions?"""
    trace_dir = _resolve_trace_dir()

    if not trace_dir.exists():
        print("Sentience Status\n")
        print(f"Hook:           not detected")
        print(f"Trace path:     {trace_dir}")
        print()
        print("No sessions found yet.")
        print()
        print("Run Claude Code with the hook enabled, then run:")
        print("    sentience status")
        return 1

    files = _list_session_files(trace_dir)
    if not files:
        print("Sentience Status\n")
        print(f"Hook:           trace path available")
        print(f"Trace path:     {trace_dir}")
        print()
        print("No sessions captured yet.")
        print()
        print("Run Claude Code with the hook enabled, then run:")
        print("    sentience status")
        return 1

    # At least one session exists.
    latest = files[0]
    session_id, events = _load_session(latest)

    # Count violations (anomalies only, matching Summary semantics).
    cls = classify_session(events)
    violation_total = sum(cls.anomaly_code_counts.values())

    # Pick a sample event for the status — prefer a SCOPE_ASSERTED so
    # the reader sees a tool invocation; fall back to any event.
    sample_line = ""
    for ev in events:
        if ev.get("event_type") == "SCOPE_ASSERTED":
            tool_name = _extract_tool_name(ev)
            sample_line = _format_tool_action(tool_name, _extract_tool_input(ev))
            break
    if not sample_line and events:
        sample_line = _format_event_oneline(events[0])

    ts = latest.stat().st_mtime
    ts_str = time.strftime("%Y-%m-%d %H:%M", time.localtime(ts))

    print("Sentience Status\n")
    print(f"Hook:           sessions detected")
    print(f"Trace path:     {trace_dir}")
    print()
    print("Last session:")
    print(f"  ID:           {session_id}")
    print(f"  Time:         {ts_str}")
    print(f"  Events:       {len(events)}")
    print(f"  Violations:   {violation_total}")
    if sample_line:
        print()
        print("Sample event:")
        print(f"  {sample_line}")
    print()
    print("Sentience is governing your Claude Code sessions locally.")
    return 0


def run_list(args: argparse.Namespace) -> int:
    """`sentience list` — what sessions exist?"""
    trace_dir = _resolve_trace_dir()
    files = _list_session_files(trace_dir)
    if not files:
        print("No sessions found yet.")
        print()
        print("Run Claude Code with the hook enabled, then run:")
        print("    sentience status")
        return 0

    print("Sentience Sessions\n")

    shown = files[:20]
    for i, f in enumerate(shown, start=1):
        session_id, events = _load_session(f)
        cls = classify_session(events)
        violation_total = sum(cls.anomaly_code_counts.values())
        symbol = "⚠" if violation_total > 0 else "✓"
        rel = _relative_time(f.stat().st_mtime)
        # Short session id for display (first 12 chars).
        sid_short = session_id[:12] if session_id else f.stem[:12]
        print(
            f"{i:>2}. {sid_short:<16} {rel:<8} "
            f"{len(events):>3} events   {symbol} {violation_total}"
        )

    if len(files) > 20:
        print()
        print(f"Showing latest 20 sessions (of {len(files)} total)")

    print()
    print("Tip:")
    print("Open latest session → sentience open --latest")
    print("Open specific      → sentience open <session_id>")
    return 0


def run_open(args: argparse.Namespace) -> int:
    """`sentience open [--latest | <session_id>]` — render one session."""
    trace_dir = _resolve_trace_dir()
    files = _list_session_files(trace_dir)

    if not files:
        print("No sessions found yet.")
        print()
        print("Run Claude Code with the hook enabled, then run:")
        print("    sentience status")
        return 1

    target: Optional[Path] = None
    if args.latest:
        target = files[0]
    elif args.session_id:
        # Match by filename stem (session_id). Accept prefix match too
        # — operators copy-paste short IDs from `sentience list`.
        exact = [f for f in files if f.stem == args.session_id]
        if exact:
            target = exact[0]
        else:
            prefix = [f for f in files if f.stem.startswith(args.session_id)]
            if len(prefix) == 1:
                target = prefix[0]
            elif len(prefix) > 1:
                print(
                    f"Ambiguous session prefix {args.session_id!r} — {len(prefix)} matches:",
                    file=sys.stderr,
                )
                for f in prefix[:10]:
                    print(f"  {f.stem}", file=sys.stderr)
                return 1
    else:
        # Neither --latest nor a session_id — treat as --latest.
        target = files[0]

    if target is None:
        print(f"No session matching {args.session_id!r}", file=sys.stderr)
        print(file=sys.stderr)
        print("Available sessions (sentience list):", file=sys.stderr)
        for f in files[:5]:
            print(f"  {f.stem}", file=sys.stderr)
        return 1

    session_id, events = _load_session(target)
    if not events:
        print(f"Session file {target} has no parseable events.", file=sys.stderr)
        return 1

    summary_mode = getattr(args, "summary", False)
    out = render_open(session_id, events, target, summary=summary_mode)
    print(out)
    return 0


# ---------------------------------------------------------------------------
# Analyze subcommand — undeclared-intent
# ---------------------------------------------------------------------------


_REPORTS_DIR = Path.home() / ".sentience" / "reports"


def _resolve_analyze_target(
    args: argparse.Namespace,
) -> Tuple[Optional[Path], Optional[str]]:
    """Resolve the trace target for an analyze subcommand.

    Returns ``(path, error_message)``. On success ``error_message`` is
    None; on failure ``path`` is None.

    Resolution order:
      1. ``--latest`` flag → newest .jsonl in the trace dir.
      2. Positional ``target`` looks like an existing file path
         (contains '/' or has .jsonl suffix or exists on disk) →
         use that file directly.
      3. Otherwise treat ``target`` as a session-id prefix and match
         against trace dir filenames.
      4. No target and no --latest → default to --latest.
    """
    target: Optional[str] = getattr(args, "target", None)

    # File-path mode (does not depend on the trace dir).
    if target:
        candidate = Path(target).expanduser()
        if candidate.is_file():
            return candidate, None
        # If it looks like a path (contains separator or .jsonl suffix)
        # but doesn't exist, return a clear file-not-found error rather
        # than treating it as a session prefix.
        if "/" in target or candidate.suffix == ".jsonl":
            return None, f"Trace file not found: {target}"

    trace_dir = _resolve_trace_dir()
    files = _list_session_files(trace_dir)
    if not files:
        return None, (
            f"No sessions found under {trace_dir}.\n"
            "Run a Claude Code session with the hook enabled, "
            "or pass an explicit trace file path."
        )

    if getattr(args, "latest", False) or not target:
        return files[0], None

    # Session-id prefix match.
    exact = [f for f in files if f.stem == target]
    if exact:
        return exact[0], None
    prefix = [f for f in files if f.stem.startswith(target)]
    if len(prefix) == 1:
        return prefix[0], None
    if len(prefix) > 1:
        names = "\n".join(f"  {f.stem}" for f in prefix[:10])
        return None, (
            f"Ambiguous session prefix {target!r} — {len(prefix)} matches:\n"
            f"{names}"
        )
    return None, f"No session matching {target!r}"


def _write_undeclared_report(result: Dict, target_path: Path) -> Path:
    """Write the saved Markdown report and return its path.

    Path shape:
      ~/.sentience/reports/undeclared-intent-<sid-prefix>-<timestamp>.md

    Side-effecting: creates the reports directory if needed.
    """
    _REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    sid = (result.get("session_id") or target_path.stem) or "unknown"
    sid_short = sid[:12].replace("/", "_")
    ts = time.strftime("%Y%m%dT%H%M%S", time.localtime())
    out = _REPORTS_DIR / f"undeclared-intent-{sid_short}-{ts}.md"
    body = render_undeclared_markdown(result)
    out.write_text(body, encoding="utf-8")
    return out


def run_analyze_undeclared_intent(args: argparse.Namespace) -> int:
    """`sentience analyze undeclared-intent [target] [flags]` handler.

    Per plan v3 §"Save prompt — behavior contract":
      - Save prompt fires only after successful render AND status==ok.
      - --json / --no-prompt suppress prompting unconditionally.
      - --save skips the prompt and writes directly.
      - On non-ok status (no_token_data / no_turns / partial), the
        save prompt is suppressed.
      - After a successful save, echo the written file path.
    """
    target_path, err = _resolve_analyze_target(args)
    if target_path is None:
        print(err, file=sys.stderr)
        return 1

    try:
        _, events = _load_session(target_path)
    except (OSError, ValueError) as exc:
        print(f"Failed to read trace {target_path}: {exc}", file=sys.stderr)
        return 1

    result = compute_undeclared_intent_spend(events)

    # --json mode: emit structured result and exit, no prompts.
    if getattr(args, "json", False):
        print(json.dumps(result, indent=2, sort_keys=False))
        return 0

    # Human-readable render.
    print(render_undeclared_cli(result))

    # Save flow — strict P7 ordering.
    status = result.get("status")
    save_eligible = status == "ok"  # partial / no_token_data / no_turns are NOT eligible

    if getattr(args, "save", False):
        if not save_eligible:
            print(
                f"Skipping save: status={status} (only status=ok results are saved).",
                file=sys.stderr,
            )
            return 0
        out_path = _write_undeclared_report(result, target_path)
        print(f"Saved to {out_path}")
        return 0

    if getattr(args, "no_prompt", False):
        return 0

    if not save_eligible:
        return 0

    # Interactive prompt — only fires for status=ok and only after the
    # metric has already been printed above (P7 ordering).
    try:
        answer = input("Save this report? [Y/n]: ").strip().lower()
    except EOFError:
        # Non-interactive stdin — treat as decline; do not save.
        return 0
    if answer in ("", "y", "yes"):
        out_path = _write_undeclared_report(result, target_path)
        print(f"Saved to {out_path}")
    return 0


# ---------------------------------------------------------------------------
# CLI entry
# ---------------------------------------------------------------------------


def main() -> int:
    parser = argparse.ArgumentParser(
        prog="sentience",
        description=(
            "Sentience Governor — curated viewer for agent-hook session traces "
            "(Claude Code today; more coming). Pairs with the raw "
            "`sentience-cli` tool for library-trace inspection."
        ),
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    p_status = subparsers.add_parser(
        "status", help="Check that the hook is capturing sessions."
    )
    p_status.set_defaults(func=run_status)

    p_list = subparsers.add_parser(
        "list", help="List captured sessions, newest first (max 20)."
    )
    p_list.set_defaults(func=run_list)

    p_open = subparsers.add_parser(
        "open",
        help="Render one session with Summary / Focus / Notes / Key Events / Full Trace.",
    )
    p_open.add_argument(
        "session_id",
        nargs="?",
        default=None,
        help="Session id (or prefix). If omitted, uses --latest.",
    )
    p_open.add_argument(
        "--latest",
        action="store_true",
        help="Open the most recently modified session (default when no session_id given).",
    )
    p_open.add_argument(
        "--summary",
        action="store_true",
        help=(
            "Skip the Full Trace block so the rendered output fits on "
            "one terminal screen. Header, Summary, Focus, Notes, Key "
            "Events, and Footer all print as usual. Every event is "
            "still on disk in the JSONL; the footer shows the path."
        ),
    )
    p_open.set_defaults(func=run_open)

    # ------------------------------------------------------------------
    # `sentience analyze ...` — derived metrics over v0.2.3+ traces.
    # First sub-subcommand: `undeclared-intent` (v0.2.4).
    # ------------------------------------------------------------------
    p_analyze = subparsers.add_parser(
        "analyze",
        help=(
            "Run a derived-metric analyzer over a captured session trace."
        ),
    )
    analyze_subparsers = p_analyze.add_subparsers(
        dest="analyzer", required=True
    )

    p_undeclared = analyze_subparsers.add_parser(
        "undeclared-intent",
        help=(
            "Compute how much compute was attributed to turns that "
            "touched execution outside the session's declared intent."
        ),
    )
    p_undeclared.add_argument(
        "target",
        nargs="?",
        default=None,
        help=(
            "Session id (or prefix) under the default trace dir, OR a "
            "path to an .jsonl trace file. If omitted, uses --latest."
        ),
    )
    p_undeclared.add_argument(
        "--latest",
        action="store_true",
        help="Analyze the most recently captured session.",
    )
    p_undeclared.add_argument(
        "--json",
        action="store_true",
        help="Emit structured JSON instead of human-readable output.",
    )
    p_undeclared.add_argument(
        "--save",
        action="store_true",
        help=(
            "Skip the interactive prompt and write the Markdown report "
            "directly to ~/.sentience/reports/."
        ),
    )
    p_undeclared.add_argument(
        "--no-prompt",
        action="store_true",
        dest="no_prompt",
        help="Disable the post-render save prompt entirely.",
    )
    p_undeclared.set_defaults(func=run_analyze_undeclared_intent)

    args = parser.parse_args()

    # First-run flow runs AFTER argparse succeeds (so --help / shell
    # completion paths exit before reaching here) and BEFORE the
    # requested subcommand executes. The flow itself short-circuits
    # if state already exists, if SENTIENCE_NO_FIRST_RUN_PROMPT is
    # set, or if any error occurs (defensive — never blocks a real
    # command). See sentience_governor/cli/first_run.py.
    maybe_run_first_run_flow(package_version=_resolve_package_version())

    return args.func(args)


def _resolve_package_version() -> Optional[str]:
    """Best-effort sentience-governor version, or None if unavailable.

    Used to populate the optional ``package_version`` field on the
    launch-list subscribe payload. If the package metadata isn't
    importable for any reason, return None — the field is optional
    and the server treats absence as no-op.
    """
    try:
        from importlib.metadata import PackageNotFoundError, version

        return version("sentience-governor")
    except (ImportError, Exception):  # PackageNotFoundError + safety
        return None


if __name__ == "__main__":
    sys.exit(main())
