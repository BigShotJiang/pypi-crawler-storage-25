# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [0.2.4] — 2026-05-08

First **derived metric** over the v0.2.3 token-attribution substrate:
**undeclared-intent token spend**. For a given session, computes how
much of the agent's compute was attributed to reasoning turns that
touched execution outside the session's declared operational intent.
No schema changes. No new event types. No probabilistic inference.
Deterministic analyzer with replay-stable output, additive only.
Existing v0.2.3 integrations continue to work unchanged.

### Added

- **`sentience_governor.analyze` package.** New top-level subpackage
  for derived-metric analyzers.
- **`compute_undeclared_intent_spend(events)`.** Pure-function
  analyzer in `sentience_governor.analyze.undeclared_intent`. No I/O,
  no environment reads, no input mutation, byte-stable output.
  Single-pass O(n) algorithm with bounded memory. Verified safe for
  10k-event traces under 1s.
- **Turn-window bracketing model.** Surface-agnostic attribution
  algorithm that handles both the MCP wrapper's emit shape
  (`SCOPE_ASSERTED` → `CONTEXT_SNAPSHOT`) and the Claude Code hook's
  dual-snapshot shape (`CONTEXT_SNAPSHOT pre` → `SCOPE_ASSERTED` →
  `CONTEXT_SNAPSHOT post`) uniformly. Replaces the earlier
  pair-by-`tool_id` approach (the wrapper schema doesn't carry
  `tool_id` on `ContextSnapshotPayload`, making true pairing
  unimplementable).
- **`render_cli` and `render_markdown_report` renderers.**
  Pure-function renderers in `sentience_governor.analyze.renderers`.
  CLI output is one-screen-friendly, screenshot-worthy. Markdown
  report carries the canonical two-vector footer (direct reply path
  + launch-list link).
- **`sentience analyze undeclared-intent` CLI subcommand.** New
  subcommand group in `sentience` with positional target
  (session-id prefix OR file path OR omitted = `--latest`),
  `--latest`, `--json`, `--save`, `--no-prompt` flags.
- **Saved report flow.** Writes to
  `~/.sentience/reports/undeclared-intent-<sid-prefix>-<timestamp>.md`
  on operator confirmation or `--save`. P7-strict ordering: prompt
  fires only after the metric has rendered; suppressed for non-`ok`
  status; `--json` and `--no-prompt` suppress prompting
  unconditionally; saved path is echoed back to the operator.
- **Differentiated footer copy.** Both CLI and Markdown branch on
  `session_has_declared_intent`. The agent-bound copy is used when
  intent was declared; the surface-bound copy is used when no
  `INTENT_DECLARED` event fires anywhere in the session — framing
  the result as a surface-level limitation rather than agent drift.
- **Showcase examples.** Three pre-rendered scenarios under
  `examples/showcase/` (low / high / surface-bound). The fixtures
  are inlined in `examples/showcase/regenerate.py` so the script is
  the single source of truth and re-rendering is byte-stable
  (MD5-verified across consecutive runs).
- **Runnable demo.** `examples/v024_undeclared_intent_demo.py`
  builds a synthesized 4-turn session, runs the analyzer, and
  prints the CLI render, a Markdown excerpt, and the JSON output.
- **Userdocs §10 "Analyzers — derived metrics over captured
  traces".** Covers the CLI, the saved Markdown report, the JSON
  output schema, status branches, and the differentiated footer.

### Changed

- Userdocs sections 11-14 are renumbered (was 10-13) to make room
  for the new §10 "Analyzers". Section content unchanged.
- README "What's new" section refreshed for v0.2.4 with the v0.2.3
  block retained as historical context.
- `sentience` CLI help output now includes the `analyze` subcommand
  group.
- Test-suite count: 519 (was 488 in v0.2.3.post1).

### What this release is NOT

- **Not a schema bump.** No new event types, no new payload fields,
  no breaking changes.
- **Not enforcement.** v0.2.4 ships *visibility* — the metric
  exposes the gap. Intervention modes (review, constraint,
  confirmation, block) follow downstream.
- **Not a dashboard.** Single-session reports today. Consolidated
  views across runs are downstream.
- **Not a PDF report integration.** The PDF generator at
  `examples/sentience_business_report.py` (v0.2.3 cycle) is
  unchanged; the v0.2.4 metric is not surfaced through it.
  Consolidated visualization is a control-plane concern.

See `userdocs/sentience_governor.md` §10 for the full guide and
`docs/plans/v0.2.4-undeclared-intent-token-spend.md` for the design
rationale.

## [0.2.3.post1] — 2026-05-07

Metadata-only post-release. **No code changes** — same wheel
contents as 0.2.3. The PyPI landing page README is refreshed to
surface v0.2.3 features clearly:

- Opening paragraph now mentions execution-cost attribution as a
  first-class capability.
- New "What's new in 0.2.3" section near the top of the README
  with three short paragraphs covering execution-cost attribution,
  the first-run UX, and the LangChain + LangGraph additions.

Per PEP 440 conventions, post-releases are for metadata fixes
that don't justify a real version bump. `pip install
sentience-governor` and `pip install --upgrade sentience-governor`
both pick this up as the latest version.

## [0.2.3] — 2026-05-07

Set out to add token tracking. Ended up adding execution-cost
attribution: token spend attached directly to execution-boundary
traces, with per-turn identity so multi-tool-call attribution stays
mathematically correct. No breaking changes; existing v0.2.2 wrappers,
traces, and downstream tooling continue to work unchanged.

Unexpected token spend in agent systems is often an operational signal:
retries after failed tool calls, excessive reasoning before low-value
actions, undeclared execution, execution loops, or intent drifting from
action. v0.2.3 records the raw token facts needed to correlate those
behaviors with execution-boundary traces.

What we deliberately did NOT do:
- no schema bump
- no new event types
- no provider "normalization"
- no derived cost math
- no dashboards pretending Anthropic and OpenAI count tokens the same way

### Added

- **Launch-list email capture.** The `sentience` CLI prompts once on
  first invocation for an email so we can let you know when the hosted
  dashboard ships. Easy to skip; never re-asks. Also at
  `getsentience.ai/launch-list`. Architecturally separate from
  `sentience-sync` — the launch list never receives trace data,
  telemetry counts, or tool calls.

- **Optional LLM-token tracking on `CONTEXT_SNAPSHOT` events.** Eight
  new optional fields on `ClassificationHint` and
  `ContextSnapshotPayload`: `llm_prompt_tokens`, `llm_completion_tokens`,
  `llm_cached_read_tokens`, `llm_cached_write_tokens`,
  `llm_reasoning_tokens`, `model_identifier`, `provider`, `llm_turn_id`.
  All optional; non-adopters see zero schema change. Provider-accurate
  raw values pass through unchanged (Anthropic excludes cache from
  input; OpenAI includes; we don't reconcile).

- **Per-turn attribution identity (`llm_turn_id`).** When one LLM turn
  produces multiple tool calls, the same token usage attaches to every
  emitted event in that turn, all sharing one `llm_turn_id`. Without
  this identity, aggregation across multi-tool-call turns becomes
  mathematically wrong. Consumers MUST dedupe by
  `(session_id, llm_turn_id)` before summing canonical token fields.
  See `userdocs/sentience_governor.md` "Token tracking (optional)" →
  "Aggregation warning" for the full rule and per-provider cache-token
  semantics.

- **`SentienceCallbackHandler.on_llm_start` and `on_llm_end`.** New
  callback methods that capture per-turn token usage from LangChain
  responses and attach it (with the turn's `llm_turn_id`) to subsequent
  tool-call events. Trace immutability preserved: events emitted before
  `on_llm_end` arrives carry the turn id but no token fields, and are
  never mutated retroactively when usage data lands.

- **`SentienceMiddleware.awrap_step`.** New optional LangGraph hook that
  aggregates token usage across messages within a step. Existing
  `awrap_tool_call` is unchanged and remains backward-compatible for
  users who don't opt in.

- **Defensive token-extraction helper module**
  (`sentience_governor.wrapper.token_extraction`). Handles Anthropic
  native, OpenAI dict, LangChain `usage_metadata`, and legacy
  `llm_output["token_usage"]` shapes. Merges across shapes so
  Anthropic-via-LangChain cache fields are preserved (they would be
  silently dropped by an early-returning helper).

- Claude Code hook adapter probes the hook payload for `usage` /
  `token_usage` defensively. Anthropic does not currently expose this
  in the hook payload; fields stay `None` until they do, and no further
  changes are needed when they do.

### Changed

- `sentience status` reassurance line now reads *"Sentience is governing
  your Claude Code sessions locally."* (was "capturing your Claude Code
  sessions"). Better matches the product brand and makes the local-first
  privacy stance explicit.

### What this release is NOT

- Not a schema-bump release. Existing event types are unchanged; no
  new event types added.
- Not a cost-calculation feature. We record raw provider-reported
  tokens; cost math lives in dashboards / downstream tools.
- Not a token-budget enforcement feature. Governance based on token
  counts is separate work.
- Not a dashboard. The hosted dashboard and downstream analytics ship
  separately — see `getsentience.ai/launch-list` to be notified.

## [0.2.2] — 2026-04-28

Patch release. No API changes. No command changes.

### Fixed

- **Default network timeout for `sentience-sync` raised from 15 seconds
  to 30 seconds.** First-call latency on the cloud sync endpoint can
  exceed 15 seconds on slower client networks, causing
  `sentience-sync run` to fail with a network-error message even when
  the request would have eventually succeeded. The new default
  comfortably covers typical first-call latency while still failing
  fast on a genuinely unreachable network. Operators can override
  via the `SENTIENCE_SYNC_TIMEOUT_SECONDS` environment variable or
  the `timeout_seconds` config key.
- **Removed misleading `(placeholder)` suffix from `sentience-sync
  status` output.** The status command previously appended
  "(placeholder)" next to the production endpoint URL, suggesting
  configuration was incomplete when it wasn't. Output now shows the
  endpoint URL plainly.

### Changed

- **README and userdocs now recommend `pipx install sentience-governor`
  as the canonical install method.** Modern macOS and Linux Pythons
  enforce PEP 668 and refuse `pip install` outside a virtualenv;
  `pipx` is the standard fix. Library integration via
  `pip install sentience-governor` inside an active venv is still
  documented and supported. Updated install guide and troubleshooting
  cover both paths.

## [0.2.1] — 2026-04-26

Patch release. No API changes. No command changes.

### Fixed

- **Default network timeout for `sentience-sync` raised from 5 seconds
  to 15 seconds.** The previous default was too tight for first-call
  latency on the cloud sync endpoint and could cause `sentience-sync
  register` to fail with a network-error message on first use. The new
  default covers normal first-call latency comfortably while still
  failing fast on a genuinely unreachable network. Operators on slow
  links can raise the timeout further via the
  `SENTIENCE_SYNC_TIMEOUT_SECONDS` environment variable or the
  `timeout_seconds` config key.

### Notes

- macOS users running Python from python.org may see `SSL:
  CERTIFICATE_VERIFY_FAILED` on first network call. This is a known
  Python packaging quirk, not a Sentience issue. One-time fix:
  `/Applications/Python\ 3.13/Install\ Certificates.command` (adjust
  the version number to match your Python install). The troubleshooting
  guide covers this in detail.

## [0.2.0] — 2026-04-23

First release talking to a live production endpoint. The
governance runtime itself is unchanged from 0.1.9; the minor
bump is driven by a breaking change in the
`sentience-sync register` CLI surface.

### Breaking

- **`sentience-sync register` now requires `--email` and
  `--name`.** Scripts that invoke `register` without these
  flags will fail before any network call. This aligns the
  CLI with the server's contract — contact info is required
  because Sentience Sync is an opt-in communication channel.
- **The Sentience Sync local state file format is bumped from
  v1 to v2.** New fields: `installation_secret`,
  `contact_email`, `contact_name`. No manual migration needed
  — v1 state files are loaded cleanly, new fields default to
  empty, and the file is re-written as v2 on the next
  successful save. Upgrading from 0.1.9 is transparent.

### Added

- **Live production endpoint at `https://sync.getsentience.ai/v1`.**
  All three routes — `/register`, `/sync`, `/update-check` —
  are now served by a real backend. Previous versions shipped
  with a placeholder URL.
- **Bearer-token authentication on `/v1/sync`.** The
  `installation_secret` returned at register time is stored
  locally and presented on every subsequent sync call.
- **`user_agent` field in registration payloads.** Identifies
  CLI version + Python version + OS for server-side
  observability.
- **Duplicate-sync contract.** Re-running `sentience-sync run`
  for a window that was already uploaded is now a successful
  no-op. The server returns `duplicate=true`, the CLI prints
  `Already uploaded for this window (sync_run_id=<id>)`, and
  exits 0. Expected behaviour for cron retries.
- **Targeted error messages.** Every expected failure path
  surfaces a specific, actionable message:
  - "Not registered. Run `register` first." — for a clean
    first run
  - "Registration incomplete or outdated. Run `register` again."
    — for an upgrade-from-0.1.9 or corrupted state
  - "Authorization failed. Your installation_secret may be out
    of sync. Run `register` again (your installation ID will
    be preserved)." — for a 401 response
- **State-file permission hardening on POSIX.** The state file
  is written with owner-only permissions (`0600`). On Windows,
  best-effort equivalent with a warning if unavailable.
- **Optional `--organization` and `--role` flags on register.**
  For teams that want to tag their installation with more than
  just the operator name.

### Changed

- **Default endpoint is live, not a placeholder.** The
  "placeholder endpoint" caveat is gone from every surface —
  documentation, CLI help output, code comments.
- **`/v1/update-check` is now a GET with query string** (was a
  POST with a body). No auth required. Matches the server's
  public API.
- **Payload shapes match the server contract exactly.**
  Internal fields (`language_binding`, `deployment_label`)
  that were never adopted server-side are dropped from the
  wire format.

### Security

- **`installation_secret` stored in owner-readable JSON.** This
  is best-effort local hardening — meaningful protection
  against accidental exposure (other local users, backup
  tarballs) but not a defense against local root. A
  compromised secret can be rotated without creating a
  duplicate installation.
- **Bearer token never appears in the request body.** Only in
  the `Authorization` header.
- **Source IPs hashed server-side.** The raw source IP of a
  sync request is SHA-256 hashed with a server-side pepper on
  arrival and never stored.

### Correctness invariant

- **`register` never regenerates your `installation_id`** once
  one exists locally. `--force` refreshes the secret but
  preserves the ID. This keeps your history intact across
  re-registrations and makes the server's recovery flow work
  cleanly without creating duplicate rows.

### Upgrade notes from 0.1.9

1. `pip install --upgrade sentience-governor`
2. Run `sentience-sync register --email you@example.com --name "Your Name"`
3. Your existing `installation_id` is preserved; a fresh
   `installation_secret` is issued and stored locally
4. Any scripts that invoked `sentience-sync register` without
   flags will need to be updated — the flags are now required

Everything else continues to work. Per-session traces,
`sentience` / `sentience-cli`, the Claude Code hook, and all
library-integration paths are unchanged.

## [0.1.9] — 2026-04-17

Public release of the Sentience Governor open-tier runtime,
including execution-boundary instrumentation, policy evaluation, local
trace generation, and CLI tooling.

### Added
- Core governance runtime with 5 control points:
  AGENT_REGISTERED, INTENT_DECLARED, SCOPE_ASSERTED,
  CONTEXT_SNAPSHOT, MEMORY_WRITE_ATTEMPT
- GOVERNANCE_ERROR event for runtime faults (sink failure, schema
  violation, intercept failure, timeout)
- MCP wrapper path (`wrap_mcp_client`) with `SentienceMCPAdapter`
- LangChain adapter: `SentienceCallbackHandler` and
  `SentienceMiddleware`
- Honest intent classification: inferred inputs are marked
  `intent_source=inferred` with `intent_confidence=inferred_low`,
  never `explicit`
- EventBuilder with 5 default policy rules (POL-001 through
  POL-005) and 8 advisory flags
- Session manager with IDLE → ACTIVE → CLOSING → CLOSED lifecycle
- In-process per-session cache for intent baseline and sensitivity
  tier tracking
- Three sinks: StdoutSink, FileSink, HttpLocalSink with fail-open
  semantics
- CLI trace viewer (`sentience-cli`) supporting NDJSON and JSON
  array input formats
- Sentience Sync CLI (`sentience-sync`) for optional, explicit,
  opt-in telemetry
- Wrapper-based integration model requiring no modification to
  agent logic
- Open-tier design: observe-only, fail-open runtime with no
  network calls or execution blocking
- Claude Code hook adapter
  (`sentience_governor.wrapper.claude_code_hook`) with
  `sentience-claude-code-hook` CLI entry point. Zero-code
  integration via `.claude/settings.json` produces governance
  traces for every Claude Code tool invocation (`Bash`, `Edit`,
  `Write`, `Read`, `Grep`, `Glob`, `WebFetch`, `WebSearch`,
  `Agent`, and every `mcp__<server>__<tool>`). Observe-only,
  fail-open, no credentials required.
- **Per-session trace files by default** for the Claude Code
  hook. Default sink is now a directory
  (`~/.sentience/traces/claude-code/`) with one `<session_id>.jsonl`
  file per Claude Code session, bounding growth naturally. Setting
  `SENTIENCE_CLAUDE_CODE_SINK_PATH` to a path ending in `.jsonl`
  keeps the legacy shared-file mode for operators who want every
  session in one interleaved trace.
- `sentience-cli` now accepts a directory argument: it globs
  `*.jsonl` inside, merges the sessions, and renders them in one
  pass. Single-file usage unchanged.
- Sink-backed session resumption primitive
  (`sentience_governor.session_manager.resumption`): atomic
  sidecar index, forward-validation, linear-scan fallback,
  file-locked read-plus-append critical section. Enables chain
  continuity across fresh Python processes (used today by the
  Claude Code hook; reusable by future adapters that need
  process-restart survival).
- `SessionManager.session_start` gains optional
  `initial_sequence` and `initial_last_event_id` parameters for
  pre-seeding chain state when resuming from disk. Defaults
  preserve the original fresh-session behaviour for every
  existing caller.
- **New `sentience` top-level CLI** (subcommands: `status`, `list`,
  `open`). Purpose-built for the agent-hook workflow where a single
  Claude Code session can produce hundreds of tool calls. Uses a
  baseline-noise classifier (pattern match + >80% frequency
  threshold) to separate real anomalies from expected noise, then
  renders a six-block output: Header, Summary (with `Status: ⚠` or
  `Status: ✓` anchor), Focus (plain-English "what to pay attention
  to"), Notes (baseline framing, shown only when relevant), Key
  Events (anomalies only, max 10 with plain-English glosses), Full
  Trace (one-liner per event), and Footer (tips + raw JSONL path).
  The existing `sentience-cli` stays unchanged for library/MCP/
  LangChain/golden-trace use — two-CLI architecture by design.
- `sentience open --latest --summary` — skips the Full Trace block
  so the rendered output fits on one terminal screen for busy
  sessions. Every other block prints as usual; the JSONL file on
  disk is unchanged.
- Locked gloss table and event formatting table documented in the
  plan (`docs/plans/sentience-cli-v1-ux.md`) and implemented in
  `sentience_governor/cli/ux.py`. Unknown tools render with tool
  identity preserved (`<tool_name> → ???`), enabling forward-
  compatibility with future coding-agent adapters without code
  changes.
