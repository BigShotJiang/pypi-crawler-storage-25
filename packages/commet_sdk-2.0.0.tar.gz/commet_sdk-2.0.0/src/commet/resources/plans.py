from __future__ import annotations

from .._http import ApiResponse, CommetHTTPClient
from .._resource_mixins import parse_plan, parse_plan_list
from .._shared import build_body
from ..types import Plan


class PlansResource:
    def __init__(self, http: CommetHTTPClient) -> None:
        self._http = http

    def list(
        self,
        *,
        include_private: bool | None = None,
        limit: int | None = None,
        cursor: str | None = None,
    ) -> ApiResponse[list[Plan]]:
        return parse_plan_list(self._http.get("/plans", build_body(
            include_private=include_private, limit=limit, cursor=cursor
        )))

    def get(self, plan_code: str) -> ApiResponse[Plan]:
        return parse_plan(self._http.get(f"/plans/{plan_code}"))
