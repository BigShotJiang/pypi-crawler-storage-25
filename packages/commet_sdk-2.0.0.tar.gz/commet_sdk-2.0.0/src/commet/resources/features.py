from __future__ import annotations

from .._http import ApiResponse, CommetHTTPClient
from .._resource_mixins import parse_feature_access, parse_feature_access_list, parse_feature_check
from ..types import FeatureAccess


class FeaturesResource:
    def __init__(self, http: CommetHTTPClient) -> None:
        self._http = http

    def get(
        self,
        *,
        code: str,
        customer_id: str,
    ) -> ApiResponse[FeatureAccess]:
        return parse_feature_access(
            self._http.get(f"/features/{code}", {"customer_id": customer_id})
        )

    def check(
        self,
        *,
        code: str,
        customer_id: str,
    ) -> ApiResponse[dict[str, bool]]:
        return parse_feature_check(
            self._http.get(f"/features/{code}", {"customer_id": customer_id})
        )

    def can_use(
        self,
        *,
        code: str,
        customer_id: str,
    ) -> ApiResponse[dict[str, bool | str | None]]:
        return self._http.get(
            f"/features/{code}", {"customer_id": customer_id, "action": "canUse"}
        )

    def list(self, customer_id: str) -> ApiResponse[list[FeatureAccess]]:
        return parse_feature_access_list(
            self._http.get("/features", {"customer_id": customer_id})
        )
