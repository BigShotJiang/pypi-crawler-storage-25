# Argus — AI-Powered Exploratory QA Agent

## What is this

Argus is an open-source tool that tests web applications like a real user. Give it a URL, it explores your app — clicking buttons, filling forms, trying edge cases — and generates an HTML report of every bug it finds.

**The key insight:** Existing testing tools (Playwright, Cypress) only test what you script. Argus discovers bugs you didn't think to test for.

## Two usage modes

1. **CLI mode** (`argus <url>`) — Standalone with built-in LLM planner via LiteLLM. Needs an API key (OpenAI, Anthropic, DeepSeek, Gemini, Ollama, etc.).
2. **MCP mode** (`argus-mcp`) — Claude Code becomes the AI brain. Argus provides browser tools. No API key needed. Configured via `claude mcp add argus -- argus-mcp`.

## Project goals

- **Primary:** Get GitHub stars. This means: solve a real pain point, one-command setup, great README with GIFs/screenshots, polished UX.
- **Secondary:** Portfolio piece for Big Tech AI/ML Engineer interviews. Demonstrate AI system engineering (not prompt wrappers) — async workers, state management, cost control, scaling.
- **Tertiary:** Eventually commercializable as a SaaS.

## Architecture

```
argus/
├── cli.py           # CLI entry point (click)
├── config.py        # YAML config + focus areas
├── browser.py       # Playwright driver + DOM extraction + page content extraction + error capture
├── planner.py       # LLM exploration strategy (LiteLLM) — CLI mode brain
├── detector.py      # Bug detection: 12 detection methods (console, network, text anomaly,
│                    #   count consistency, CSS state, toast cross-check, state verification,
│                    #   dead links, broken images, SEO, accessibility, performance, mixed content)
├── explorer.py      # Main loop: observe → plan → act → detect → verify → screenshot
├── reporter.py      # Self-contained HTML report with embedded base64 screenshots
├── mcp_server.py    # MCP server (14 tools incl. verify_action, check_links, check_performance)
└── models.py        # Data models (Bug, Action, PageState, Screenshot, etc.)
```

## Tech stack

Python 3.10+ | Playwright | LiteLLM | MCP SDK | Click | Rich | PyYAML

## Development

```bash
cd /Users/yichen/projects/argus
source .venv/bin/activate
pip install -e .
playwright install chromium
```

## Test site

`test-site/app.py` is BuggyTasks — a realistic task management app (Starlette) with **22 intentional bugs** across 4 difficulty tiers:

- **Tier 1 (surface):** console errors, dead links, API 500s
- **Tier 2 (form):** auth bypass, password mismatch, XSS, form data loss
- **Tier 3 (logic):** fake delete/save, off-by-one count, pagination dupes, race conditions
- **Tier 4 (UX):** case-sensitive search, broken dates, eternal "Loading...", misleading success toasts

The full bug catalog is documented at the top of `test-site/app.py`. Run with:

```bash
cd test-site && python app.py  # runs on http://127.0.0.1:5555
```

## GitHub

Repo: https://github.com/chriswu727/argus (owner: chriswu727)

## Key files for context

- `docs/STATUS.md` — Current completion status and what's done
- `docs/ROADMAP.md` — Future features and priorities
- `docs/TODO.md` — Immediate next tasks
