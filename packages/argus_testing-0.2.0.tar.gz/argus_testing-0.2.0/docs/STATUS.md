# Current Status

Last updated: 2026-04-11

## What's done

### Core pipeline
- [x] Playwright browser driver with DOM extraction
- [x] Interactive element detection (links, buttons, inputs, selects, textareas, ARIA roles)
- [x] Console error + network error capture
- [x] Bug deduplication
- [x] Action execution: click, type, select, navigate, scroll, go back

### Smart detection
- [x] Page content extraction (full visible text, toasts, counts, CSS indicators, item lists)
- [x] Text anomaly detection (broken dates, NaN, eternal "Loading...", raw "undefined")
- [x] Count consistency (displayed count vs actual rendered items)
- [x] CSS state detection (alarming styling on success states)
- [x] Toast + network cross-check (success toast + HTTP 500 = misleading)
- [x] State verification (verify_action: delete/edit persistence after refresh)

### Comprehensive detection (NEW)
- [x] **Dead link crawling** — `check_links()` MCP tool, HEAD requests all internal links
- [x] **Broken image detection** — images that failed to load (naturalWidth === 0)
- [x] **SEO audit** — missing title/description/viewport, OG tags, heading hierarchy (no H1, multiple H1s)
- [x] **Accessibility** — missing alt text, unlabeled form inputs, buttons with no accessible name, missing html lang
- [x] **Performance metrics** — `check_performance()` MCP tool, slow loads (>3s), large resources (>500KB), too many requests (>50)
- [x] **Mixed content** — HTTP resources on HTTPS pages

### MCP mode
- [x] 14 MCP tools: start_session, get_page_state, click, type_text, select_option, navigate, go_back, scroll_down, screenshot, get_errors, verify_action, check_links, check_performance, end_session
- [x] get_page_state() returns page text, toasts, counts, CSS indicators, links, images, meta tags, headings, a11y issues
- [x] get_errors() runs all passive detectors automatically (console, network, text, counts, CSS, toast, images, a11y, SEO, mixed content)
- [x] MCP instructions guide Claude Code through verification, link checking, performance testing

### CLI mode
- [x] LLM planner via LiteLLM (100+ models)
- [x] All detectors wired into exploration loop
- [ ] Planner loops on weak models (DeepSeek/GLM) — needs code-driven exploration (v2)

### Reporting
- [x] Self-contained HTML report (dark theme, base64-embedded screenshots)
- [x] 16 bug type labels: Console Error, Network Error, Text Anomaly, Count Mismatch, State Verification, Misleading Success, Broken Link, Broken Image, SEO Issue, Accessibility, Performance, Mixed Content, etc.

### Publishing
- [x] PyPI: `pip install argus-testing` (v0.1.0)
- [x] GitHub: https://github.com/chriswu727/argus
- [x] MIT LICENSE

### Real website testing
- [x] vanlifeyvr.com: found missing og:image (was 0 bugs before comprehensive detection)
- [x] nalifex.com: found unlabeled search input, 1.5MB uncompressed image, missing og:image (was 0 bugs before)
- [x] test-site (BuggyTasks): ~15/22 bugs detected with smart + comprehensive detection

## What's NOT done yet

- [ ] CLI planner needs code-driven exploration (doesn't work well with cheap models)
- [ ] No README demo GIF
- [ ] Not submitted to awesome-mcp-servers yet
- [ ] Edit verification needs improvement for some edge cases
- [ ] Steps to reproduce include all session steps (should be scoped per bug)
- [ ] No responsive/viewport testing
- [ ] No JS coverage analysis
