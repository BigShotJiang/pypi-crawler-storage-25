# Current TODO

Last updated: 2026-04-11

## Launch checklist

- [ ] **Record demo GIF** — most important for GitHub stars. Show MCP session finding real bugs.
- [ ] **Submit to awesome-mcp-servers** — 84k+ star list, free traffic
- [ ] **Add GitHub topics** — mcp, testing, qa, playwright, ai-agent, claude-code
- [ ] **Bump PyPI to v0.2.0** — with comprehensive detection features

## Next features

- [ ] **Code-driven CLI exploration** — don't rely on LLM for navigation. Auto-crawl all nav links → find forms → systematic edge cases → LLM only generates test data.
- [ ] **Responsive testing** — test at multiple viewport widths (mobile, tablet, desktop), detect overflow/layout breaks
- [ ] **Scoped reproduction steps** — each bug should only show steps relevant to it, not the entire session
- [ ] **Test against more real websites** — find edge cases in JS extraction, selector building
- [ ] **PyPI v0.2.0 release** after fixes

## Known issues

- CLI planner loops with cheap models (DeepSeek, GLM) — needs code-driven exploration
- Toast detection depends on timing (toast may hide before extraction)
- Some images use CSS background-image not <img> — not detected
- `check_links()` only checks internal links by default
