# Roadmap

Features ordered by priority (impact on GitHub stars + technical depth).

## Phase 1 — Polish for Launch (next)

**Goal:** Make it good enough to post on Reddit/HN/Twitter and get initial traction.

- [ ] **Record a GIF demo** — 30-second terminal recording showing Argus finding bugs. This is the #1 factor for GitHub stars.
- [ ] **Improve HTML report** — Add action log timeline (not just screenshots), collapsible sections, bug filtering by severity
- [ ] **Publish to PyPI** — `pip install argus-qa` should just work
- [ ] **Add to awesome-mcp-servers** — The list has 84k+ stars, being listed = free traffic
- [ ] **Error report improvements** — Better bug titles, smarter severity classification, group related bugs

## Phase 2 — Deeper Testing Intelligence

**Goal:** Make the AI actually smarter, not just more verbose prompts.

- [ ] **State graph tracking** — Build a map of app states and transitions, detect unexplored branches
- [ ] **Coverage-aware exploration** — Track which pages/forms/buttons have been tested and prioritize untested ones
- [ ] **Smart input generation** — Context-aware inputs (e.g., generate realistic names for name fields, valid-looking credit card numbers for payment forms)
- [ ] **Multi-step flow awareness** — Understand and test multi-page flows (register → verify email → login → use feature)
- [ ] **Visual anomaly detection** — Detect layout breaks, overlapping elements, invisible text (no VLM needed — use DOM analysis)

## Phase 3 — Production Features

**Goal:** Make it usable in real CI/CD pipelines.

- [ ] **JUnit/JSON output** — Machine-readable reports for CI integration
- [ ] **GitHub Actions integration** — Run Argus as a PR check, comment results on the PR
- [ ] **Baseline comparison** — Compare current run vs previous, highlight new bugs only
- [ ] **Config profiles** — Pre-built configs for common app types (e-commerce, SaaS, blog)
- [ ] **Auth support** — Cookie/token injection for testing behind login walls
- [ ] **Sitemap crawling** — Auto-discover all pages from sitemap.xml

## Phase 4 — Scale & SaaS

**Goal:** Handle real production workloads, potential commercialization.

- [ ] **Parallel browser sessions** — Celery + Redis worker pool for concurrent testing
- [ ] **React dashboard** — Real-time WebSocket view of agent exploring
- [ ] **Test history & trends** — PostgreSQL backend, track bugs over time
- [ ] **Multi-tenant API** — REST API for running tests programmatically
- [ ] **Hosted version** — Deploy as a service, users submit URLs via web UI

## Ideas (not prioritized)

- Browser extension that records user sessions and replays them with Argus variations
- Slack/Discord bot integration for test results
- Accessibility (a11y) audit mode
- Performance testing mode (measure load times, detect slow pages)
- API testing mode (discover and test REST/GraphQL endpoints)
