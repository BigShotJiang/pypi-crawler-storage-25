"""AI Launcher - Fast context switching for AI coding assistant projects."""

__version__ = "0.4.0"
