Wan 3 AI video generator metadata for PyPI indexing.
