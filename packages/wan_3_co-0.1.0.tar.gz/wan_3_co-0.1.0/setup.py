from setuptools import setup, find_packages
setup(
    name="wan-3-co",
    version="0.1.0",
    packages=["wan_3_co"],
    package_dir={"": "."},
    include_package_data=True,
)
