# Log File Cleaner
A simple Python script to clean log files by deleting old log files.

## Features
- Removes empty lines from log files.

## Installation
You can install the Log File Cleaner using pip:

```bash
pip install log-file-cleaner-bijena
log-file-cleaner-bijena --input <input_file> --output <output_file>
```
## Usage
from log_file_cleaner import LogFileCleaner

cleaner = LogFileCleaner()
cleaner.clean_log_file("your_log_file.log", "cleaned_log_file.log")

## License
```text
MIT License
Copyright (c) 2026 Bijena Dhewaju.
Permission is hereby granted...
```