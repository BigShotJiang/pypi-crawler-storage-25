# log file cleaner
import os
import re # Regular expression module

class LogFileCleaner:
