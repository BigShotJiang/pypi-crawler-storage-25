# SPDX-License-Identifier: GPL-3.0-only
#
# Copyright (C) 2026 ss0832
#
# This file is part of ASE_Biaspot.
#
# ASE_Biaspot is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, version 3 only.
#
# ASE_Biaspot is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with ASE_Biaspot. If not, see <https://www.gnu.org/licenses/>.
"""
BiasTerm abstract base class and concrete implementations.

Class hierarchy
---------------
BiasTerm  (metaclass: _BiasTermMeta → ABCMeta)
├── AFIRTerm          — AFIR bias with torch autograd support
├── CallableTerm      — user-defined NumPy callable (FD gradient)
└── TorchBiasTerm     — nn.Module-based terms with learnable parameters
    ├── TorchCallableTerm
    └── TorchAFIRTerm
"""

from __future__ import annotations

import warnings
from abc import ABCMeta, abstractmethod
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, TypeAlias

import numpy as np

from ._compat import _TORCH_AVAILABLE, require_torch
from .afir import _validate_afir_groups, afir_energy, afir_energy_tensor
from .context import GeometryContext, TorchGeometryContext, VariableFunction

if TYPE_CHECKING:
    import torch
    import torch.nn as nn

BiasCallable: TypeAlias = Callable[[dict[str, Any], dict[str, Any]], float]


# ── Abstract base ────────────────────────────────────────────────────────────


class _BiasTermMeta(ABCMeta):
    """Metaclass for :class:`BiasTerm` that enforces ``self.name`` at instantiation.

    Extends :class:`~abc.ABCMeta` so that abstract-method tracking is preserved.
    The :meth:`__call__` hook fires *after* ``__new__`` + ``__init__`` complete,
    making it a single uniform enforcement point regardless of how the subclass
    defines its ``__init__`` (manual, ``@dataclass``-generated, or inherited).

    This replaces the previous ``_wrap_init_for_name_check`` approach of
    wrapping individual ``__init__`` methods in ``__init_subclass__`` and
    adding an MRO-fallback check in ``BiasTerm.__init__``.  Neither
    ``@dataclass`` timing nor MRO edge cases require special handling here.
    """

    def __call__(cls, *args: object, **kwargs: object) -> object:
        instance = super().__call__(*args, **kwargs)
        if not hasattr(instance, "name"):
            raise TypeError(
                f"{cls.__name__}.__init__() did not set self.name. "
                "Every concrete BiasTerm subclass must assign a string to "
                "self.name inside its __init__()."
            )
        return instance


class BiasTerm(metaclass=_BiasTermMeta):
    """
    Abstract base class for all bias potential terms.

    Subclass this to add new term types without modifying existing code
    (Open/Closed Principle).

    Class attributes
    ----------------
    name : str
        Human-readable identifier used in log output and CSV columns.
        Every concrete subclass **must** assign ``self.name`` in its
        ``__init__``.  Forgetting to do so raises :exc:`TypeError` at
        instantiation time (enforced via :class:`_BiasTermMeta`).
    energy_unit : str
        Declares the unit of the value returned by ``evaluate()`` and
        ``evaluate_tensor()``. Must be ``"eV"`` for correct force computation.
        If a different unit is declared, ``BiasCalculator`` emits a
        ``UserWarning`` at construction time. No automatic conversion is applied.

    Subclassing contract
    --------------------
    * **Required**: assign ``self.name`` in ``__init__`` and implement
      ``evaluate()``.
    * **Optional**: override ``supports_autograd`` to return ``True`` and
      implement ``evaluate_tensor()`` to enable torch autograd gradient
      computation.  ``BiasCalculator`` will call ``evaluate_tensor()`` for
      all terms where ``supports_autograd`` is ``True``.

    Example — torch-native harmonic distance term::

        class HarmonicTorchTerm(BiasTerm):
            def __init__(self, name, i, j, k, r0):
                self.name, self.i, self.j, self.k, self.r0 = name, i, j, k, r0

            def evaluate(self, positions, atomic_numbers=None):
                r = np.linalg.norm(positions[self.i] - positions[self.j])
                return float(self.k * (r - self.r0) ** 2)

            @property
            def supports_autograd(self): return True

            def evaluate_tensor(self, positions, atomic_numbers=None):
                r = torch.linalg.norm(positions[self.i] - positions[self.j])
                return self.k * (r - self.r0) ** 2
    """

    name: str
    energy_unit: str = "eV"

    def __init_subclass__(cls, **kwargs: object) -> None:
        super().__init_subclass__(**kwargs)

    @abstractmethod
    def evaluate(
        self,
        positions: np.ndarray,
        atomic_numbers: list[int] | None = None,
    ) -> float:
        """Return bias energy (eV) for the given positions (Angstrom).

        Parameters
        ----------
        positions : np.ndarray
            Atomic positions, shape ``(N, 3)``, in Angstrom.
        atomic_numbers : list[int] | None, optional
            Atomic numbers for each atom.  Required by some subclasses; see
            *Notes* below.

        Returns
        -------
        float
            Bias energy in eV.

        Notes
        -----
        **Precondition strengthened by certain subclasses:**

        Some subclasses require ``atomic_numbers`` to be provided and will
        raise :exc:`ValueError` when it is ``None``.

        - :class:`AFIRTerm` — covalent radii (element-dependent) are needed
          for AFIR weight computation.  Passing ``None`` raises
          :exc:`ValueError`.
        - :class:`CallableTerm` — does not require ``atomic_numbers`` itself;
          ``None`` is valid unless the user-supplied callable uses it.
        - :class:`TorchBiasTerm` subclasses — follow the requirements of
          their :meth:`evaluate_tensor` implementation.

        :class:`BiasCalculator` always passes
        ``atoms.get_atomic_numbers()`` so this precondition is
        transparently satisfied in normal usage.  When calling
        :meth:`evaluate` directly (e.g. in tests or custom training loops),
        consult each subclass's documentation.
        """

    @property
    def supports_autograd(self) -> bool:
        """True when this term implements ``evaluate_tensor()`` for autograd."""
        return False

    def evaluate_tensor(
        self,
        positions: torch.Tensor,
        atomic_numbers: list[int] | None = None,
    ) -> torch.Tensor:
        """
        Return bias energy (eV) as a torch scalar for autograd.

        The return value MUST be a rank-0 tensor (shape=()).
        ``BiasCalculator`` raises ``TypeError`` if a non-scalar tensor is returned.
        If your fn naturally produces a vector (e.g. per-pair contributions),
        reduce it explicitly: ``return contributions.sum()``.

        .. note::
           *positions* **must** be created with ``requires_grad=True``
           for ``torch.autograd.backward()`` to compute positional gradients.
           :class:`BiasCalculator` always sets ``requires_grad=True`` internally,
           so this requirement only matters when calling ``evaluate_tensor()``
           directly (e.g. during testing or custom training loops).
           Passing a ``requires_grad=False`` tensor and then calling
           ``backward()`` will raise ``RuntimeError: element 0 of tensors does
           not require grad and does not have a grad_fn``.

        Override this together with ``supports_autograd = True``.
        """
        raise NotImplementedError(
            f"{type(self).__name__} does not implement evaluate_tensor(). "
            "Set supports_autograd=True and provide a torch-native implementation."
        )

    # ── Backward-compatible factory helpers ──────────────────────────────────

    @classmethod
    def from_callable(
        cls,
        name: str,
        fn: BiasCallable,
        variables: dict[str, VariableFunction] | None = None,
        params: dict[str, Any] | None = None,
    ) -> CallableTerm:
        """Create a :class:`CallableTerm` from a user-defined callable.

        This is the **recommended** way to build a callable bias term.
        It is equivalent to constructing :class:`CallableTerm` directly but
        provides a more concise call signature.

        Parameters
        ----------
        name : str
            Identifier used in log output and CSV columns.
        fn : callable
            ``(vars_: dict, params: dict) -> float``

            The two arguments passed to *fn* at each evaluation step are:

            * ``vars_`` — values produced by running each extractor in
              *variables* against the current :class:`GeometryContext`.
              Keys match those in the *variables* dict.  If *variables* is
              empty, ``vars_`` will be an empty dict.
            * ``params`` — the *params* dict, forwarded unchanged.

        variables : dict[str, callable] or None
            Geometry extractors, each a callable
            ``(ctx: GeometryContext) -> scalar``.  Built-in helpers such as
            ``ctx.distance(i, j)``, ``ctx.angle(i, j, k)``, and
            ``ctx.dihedral(i, j, k, l)`` can be used directly as extractors.
            Defaults to ``{}`` (empty — ``vars_`` will always be ``{}``).
        params : dict[str, Any] or None
            Arbitrary keyword parameters forwarded verbatim to *fn*.
            Defaults to ``{}`` (empty).

        Returns
        -------
        CallableTerm

        Examples
        --------
        .. code-block:: python

            term = BiasTerm.from_callable(
                name="harmonic_distance",
                fn=lambda v, p: p["k"] * (v["r"] - p["r0"]) ** 2,
                variables={"r": lambda ctx: ctx.distance(0, 1)},
                params={"k": 5.0, "r0": 0.5},
            )
        """
        return CallableTerm(name=name, fn=fn, variables=variables or {}, params=params or {})

    @classmethod
    def from_afir(
        cls,
        name: str,
        group_a: list[int],
        group_b: list[int],
        gamma: float,
        power: float = 6.0,
    ) -> AFIRTerm:
        """Create an :class:`AFIRTerm`."""
        return AFIRTerm(name=name, group_a=group_a, group_b=group_b, gamma=gamma, power=power)


# ── Concrete implementations ─────────────────────────────────────────────────


@dataclass
class AFIRTerm(BiasTerm):
    """
    AFIR bias term (Maeda-Morokuma single-component AFIR).

    Gradients are computed via ``torch.autograd`` when PyTorch is available;
    otherwise ``BiasCalculator`` falls back to finite differences.

    Parameters
    ----------
    name : str
        Identifier used in log output.
    group_a, group_b : list[int]
        0-based atom indices for fragments A and B (non-overlapping).
    gamma : float
        AFIR parameter in kJ/mol.
        Positive → push together; negative → pull apart.
    power : float
        Exponent *p* in the ω weight function (default: 6).
    fd_step : float or None, optional
        Step size (Å) for central-difference differentiation when this term
        uses the FD gradient path. ``None`` (default) uses the step size
        set on ``BiasCalculator``. Tune this if the potential energy scale
        is very large (kJ/mol order) and FD accuracy is insufficient.
    """

    name: str
    group_a: list[int]
    group_b: list[int]
    gamma: float
    power: float = 6.0
    fd_step: float | None = None  # None → use BiasCalculator.fd_step

    def __post_init__(self) -> None:
        # Catch empty groups and overlapping indices at construction time so
        # users get a clear error rather than a silent zero energy at runtime.
        _validate_afir_groups(self.group_a, self.group_b, f"AFIRTerm '{self.name}'")
        if self.fd_step is not None and self.fd_step <= 0.0:
            raise ValueError(
                f"AFIRTerm '{self.name}': fd_step must be a positive float or None, "
                f"got {self.fd_step}."
            )

    @property
    def supports_autograd(self) -> bool:
        # Always True: AFIRTerm implements evaluate_tensor().
        # Whether PyTorch is actually installed is checked by BiasCalculator.
        return True

    def evaluate(
        self,
        positions: np.ndarray,
        atomic_numbers: list[int] | None = None,
    ) -> float:
        if atomic_numbers is None:
            raise ValueError(
                "AFIRTerm.evaluate() requires atomic_numbers (got None). "
                "Pass atomic_numbers=list(atoms.get_atomic_numbers()) when "
                "calling evaluate() directly. BiasCalculator handles this automatically."
            )
        return afir_energy(
            positions, atomic_numbers, self.group_a, self.group_b, self.gamma, self.power
        )

    def evaluate_tensor(
        self,
        positions: torch.Tensor,
        atomic_numbers: list[int] | None = None,
    ) -> torch.Tensor:
        if atomic_numbers is None:
            raise ValueError("AFIRTerm.evaluate_tensor() requires atomic_numbers.")
        return afir_energy_tensor(
            positions, atomic_numbers, self.group_a, self.group_b, self.gamma, self.power
        )


def _coerce_to_float(value: Any, term_name: str) -> float:
    """
    Convert a bias energy return value to ``float`` with informative errors.

    Accepted types
    --------------
    - Python ``float`` / ``int``
    - ``numpy.floating`` / ``numpy.integer``
    - ``numpy.ndarray`` with shape ``()`` or size 1
    - Any object with ``.item()`` and ``.shape`` (e.g. ``torch.Tensor``, shape=())

    Raises
    ------
    TypeError
        If the value cannot be unambiguously reduced to a scalar.
        This happens when ``fn`` returns a multi-element array or tensor.
    """
    if isinstance(value, (float, int, np.floating, np.integer)):
        return float(value)
    if isinstance(value, np.ndarray):
        if value.shape == () or value.size == 1:
            return float(value.flat[0])
        raise TypeError(
            f"Term '{term_name}': fn returned ndarray with shape {value.shape}. "
            "Bias energy must be a scalar (shape=() or size=1). "
            "Use .sum() or index the array inside fn to reduce it."
        )
    # Duck-type check for torch.Tensor without importing torch unconditionally.
    if hasattr(value, "item") and hasattr(value, "shape"):
        shape = tuple(value.shape)
        if shape == ():
            return float(value.item())
        raise TypeError(
            f"Term '{term_name}': fn returned a tensor with shape {shape}. "
            "In CallableTerm (FD path), autograd graphs are not preserved. "
            "Either return a Python float, or use TorchCallableTerm for autograd."
        )
    return float(value)  # last resort — let Python raise naturally


@dataclass
class CallableTerm(BiasTerm):
    """
    Bias term defined by a user-provided NumPy callable.

    Gradients are always computed via finite differences because arbitrary
    Python/NumPy callables are not differentiable by ``torch.autograd``.

    To enable autograd for a custom term, subclass :class:`BiasTerm` directly,
    implement ``evaluate_tensor()``, and set ``supports_autograd = True``.

    .. tip::
        The recommended way to create a ``CallableTerm`` is via the class method
        :meth:`BiasTerm.from_callable`, which provides the same interface with a
        more concise call signature::

            term = BiasTerm.from_callable(
                name="harmonic",
                fn=lambda v, p: p["k"] * (v["r"] - p["r0"]) ** 2,
                variables={"r": lambda ctx: ctx.distance(0, 1)},
                params={"k": 5.0, "r0": 0.5},
            )

    Parameters
    ----------
    name : str
        Identifier used in log output.
    fn : callable
        ``(vars_: dict, params: dict) -> float``

        Called once per energy evaluation.  The two arguments are:

        * ``vars_`` — a ``dict`` whose keys and values are determined by the
          ``variables`` mapping.  Before ``fn`` is called, each extractor
          function in ``variables`` is invoked with a :class:`GeometryContext`
          object, and the result is stored under the corresponding key.
          For example, if ``variables={"r": lambda ctx: ctx.distance(0, 1)}``,
          then ``vars_["r"]`` will be the interatomic distance between atoms 0
          and 1 (in Å).  If ``variables`` is empty (the default), ``vars_``
          will be an empty dict and ``fn`` must not reference it.
        * ``params`` — the ``params`` dict passed at construction time,
          forwarded unchanged.

        ``fn`` must return a scalar (Python float, scalar numpy array, or scalar
        torch.Tensor via ``.item()``). Multi-element arrays or tensors raise
        ``TypeError``. For torch autograd, use :class:`TorchCallableTerm` instead.
    variables : dict[str, VariableFunction]
        Geometry extractor functions, keyed by the variable name that will
        appear in ``vars_`` when ``fn`` is called.  Each value must be a
        callable ``(ctx: GeometryContext) -> scalar``.  Built-in helpers
        (``ctx.distance``, ``ctx.angle``, ``ctx.dihedral``, etc.) can be used
        directly as extractors.  Defaults to an empty dict.
    params : dict[str, Any]
        Arbitrary parameters forwarded verbatim to *fn* as its second argument.
        Defaults to an empty dict.
    fd_step : float or None, optional
        Step size (Å) for central-difference differentiation.
        ``None`` (default) uses the step size set on ``BiasCalculator``.
        Tune this if the potential energy scale is very large (kJ/mol order)
        and FD accuracy is insufficient.

    Examples
    --------
    Harmonic distance restraint pulling atoms 0 and 1 toward 0.5 Å:

    .. code-block:: python

        from ase_biaspot import BiasTerm, BiasCalculator

        term = BiasTerm.from_callable(          # preferred constructor
            name="harmonic",
            fn=lambda v, p: p["k"] * (v["r"] - p["r0"]) ** 2,
            variables={"r": lambda ctx: ctx.distance(0, 1)},
            params={"k": 5.0, "r0": 0.5},
        )

    Equivalent construction using ``CallableTerm`` directly:

    .. code-block:: python

        from ase_biaspot.core import CallableTerm

        term = CallableTerm(
            name="harmonic",
            fn=lambda v, p: p["k"] * (v["r"] - p["r0"]) ** 2,
            variables={"r": lambda ctx: ctx.distance(0, 1)},
            params={"k": 5.0, "r0": 0.5},
        )
    """

    name: str
    fn: BiasCallable
    variables: dict[str, VariableFunction] = field(default_factory=dict)
    params: dict[str, Any] = field(default_factory=dict)
    fd_step: float | None = None  # None → use BiasCalculator.fd_step

    # supports_autograd stays False (inherited default)

    def __post_init__(self) -> None:
        if self.fd_step is not None and self.fd_step <= 0.0:
            raise ValueError(
                f"CallableTerm '{self.name}': fd_step must be a positive float or None, "
                f"got {self.fd_step}."
            )

    def evaluate(
        self,
        positions: np.ndarray,
        atomic_numbers: list[int] | None = None,
    ) -> float:
        ctx = GeometryContext(positions=positions, atomic_numbers=atomic_numbers)
        vars_: dict[str, Any] = {key: extractor(ctx) for key, extractor in self.variables.items()}
        try:
            raw = self.fn(vars_, self.params)
        except KeyError as exc:
            missing = exc.args[0] if exc.args else exc
            raise KeyError(
                f"Term '{self.name}': fn raised KeyError for missing key {missing!r}. "
                f"Available vars keys: {list(vars_.keys())}. "
                f"Available params keys: {list(self.params.keys())}."
            ) from exc
        except Exception as exc:
            raise RuntimeError(
                f"Term '{self.name}': error in fn — {type(exc).__name__}: {exc}"
            ) from exc
        return _coerce_to_float(raw, self.name)


# ── nn.Module-based terms (require PyTorch) ──────────────────────────────────
#
# Design note (Problem 1 fix):
# Previously, TorchBiasTerm / TorchCallableTerm / TorchAFIRTerm were defined
# inside `if _TORCH_AVAILABLE:` with stub aliases in the `else` branch.  That
# caused:
#   • Three `# type: ignore` suppressions (no-redef, misc, assignment).
#   • mypy / IDEs unable to determine which branch is active statically.
#   • `TorchCallableTerm` and `TorchAFIRTerm` silently becoming the same class
#     as `TorchBiasTerm` at runtime when torch is absent.
#
# The fix: introduce `_NNModuleBase` as the single conditional, then define all
# three classes at module level with a single unconditional class hierarchy.
# `require_torch()` in `TorchBiasTerm.__init__` raises ImportError before any
# torch-specific code runs, so the `_NNModuleBase = object` fallback is never
# observable from user code.  All three `# type: ignore` suppressions have
# been removed (Problem 1 + Problem 5 fixes combined).

if _TORCH_AVAILABLE:
    import torch
    import torch.nn as nn

    _NNModuleBase: type = nn.Module
else:
    _NNModuleBase = object


def _to_parameter(v: Any) -> Any:
    """Convert a scalar / Tensor to an nn.Parameter (float64).

    Requires PyTorch.  Only ever called from ``TorchCallableTerm.__init__``,
    which is guarded by ``require_torch()`` via ``TorchBiasTerm.__init__``.
    """
    # Local import so this helper can live at module level without triggering
    # an ImportError on environments without torch.  When torch is available
    # the import is a no-op (already cached in sys.modules).
    import torch as _torch
    import torch.nn as _nn

    if isinstance(v, _nn.Parameter):
        return v
    if isinstance(v, _torch.Tensor):
        return _nn.Parameter(v.clone().detach().to(_torch.float64))
    return _nn.Parameter(_torch.tensor(float(v), dtype=_torch.float64))


class TorchBiasTerm(BiasTerm, _NNModuleBase):
    """
    Abstract base class for bias terms with learnable (nn.Parameter) weights.

    Extends both :class:`BiasTerm` and ``torch.nn.Module`` so that
    learnable parameters are managed by the standard PyTorch ecosystem
    (``Adam``, ``LBFGS``, ``term.parameters()``, ``term.zero_grad()``, …).

    Subclassing contract
    --------------------
    * Implement ``evaluate_tensor(positions, atomic_numbers)``.
    * ``evaluate()`` is available for finite-difference gradient computation
      (``gradient_mode="fd"``); it runs ``evaluate_tensor()`` in a
      ``torch.no_grad()`` context.  ``nn.Parameter`` gradients are **not**
      populated through this path.

    Usage example — learnable harmonic distance term::

        class HarmonicTorchTerm(TorchBiasTerm):
            def __init__(self, name, i, j, k_init, r0):
                super().__init__(name)
                self.i, self.j, self.r0 = i, j, r0
                self.k = nn.Parameter(torch.tensor(k_init, dtype=torch.float64))

            def evaluate_tensor(self, positions, atomic_numbers=None):
                r = torch.linalg.norm(positions[self.i] - positions[self.j])
                return self.k * (r - self.r0) ** 2

    Notes
    -----
    * :class:`BiasCalculator` always uses ``evaluate_tensor`` (torch autograd)
      for energy **and** forces when the term is a :class:`TorchBiasTerm`
      under ``gradient_mode="auto"`` (the default).
    * Parameter gradients (``nn.Parameter.grad``) are populated by
      ``BiasCalculator`` after each force call.  Call ``term.zero_grad()``
      before accumulating gradients for an external optimizer step.
    * Instantiating this class (or any subclass) when PyTorch is not installed
      raises :exc:`ImportError` via :func:`require_torch`.
    """

    def __init__(self, name: str) -> None:
        require_torch("TorchBiasTerm")
        # MRO: TorchBiasTerm → BiasTerm → nn.Module → object.
        # BiasTerm defines no __init__, so super().__init__() resolves directly
        # to nn.Module.__init__(), setting up the Module parameter registry.
        super().__init__()
        self.name = name

    @property
    def supports_autograd(self) -> bool:
        return True

    def evaluate(
        self,
        positions: np.ndarray,
        atomic_numbers: list[int] | None = None,
    ) -> float:
        """Return bias energy (eV) using evaluate_tensor() in no-grad mode.

        This provides a NumPy-compatible path that makes finite-difference
        gradient computation possible (``gradient_mode="fd"``).

        .. note::
           ``nn.Parameter`` gradients are **not** populated through this
           path (``torch.no_grad()`` suppresses the autograd graph).
           Use ``evaluate_tensor()`` directly, or let
           :class:`BiasCalculator` handle it with autograd, when you
           need parameter gradients for an external optimiser step.
        """
        import torch as _torch

        with _torch.no_grad():
            p_t = _torch.tensor(positions, dtype=_torch.float64)
            e = self.evaluate_tensor(p_t, atomic_numbers)
        return float(e.item())

    def evaluate_tensor(
        self,
        positions: torch.Tensor,
        atomic_numbers: list[int] | None = None,
    ) -> torch.Tensor:
        raise NotImplementedError(f"{type(self).__name__} must implement evaluate_tensor().")


class TorchCallableTerm(TorchBiasTerm):
    """
    Bias term with a torch-native callable and learnable weights.

    Three kinds of parameters can be passed to *fn* via the ``params`` dict:

    * **fixed_params** — plain Python constants (floats, ints, ...).
    * **trainable_params** — scalar/tensor values stored as ``nn.Parameter``
      (float64).  Gradients w.r.t. these are populated by
      :class:`BiasCalculator` after each step.
    * **submodules** — arbitrary ``nn.Module`` objects (MLP, SchNet layer, ...).
      Their full parameter trees are registered under ``self.submodules``
      (``nn.ModuleDict``) so that ``term.parameters()`` yields every weight
      and ``term.zero_grad()`` resets every gradient.

    All three are merged into a single ``params`` dict before *fn* is called,
    so *fn* always has the signature
    ``(vars_: dict[str, Tensor], params: dict[str, Any]) -> Tensor``.
    This keeps the interface backward-compatible: existing two-argument
    callables continue to work unchanged.

    Parameters
    ----------
    name : str
        Identifier used in log output.
    fn : callable
        ``(vars_: dict[str, Tensor], params: dict[str, Any]) -> Tensor``
        Must use torch operations so that autograd can propagate through it.
    variables : dict[str, VariableFunction]
        Geometry extractors.  The same lambdas used with :class:`CallableTerm`
        work here -- they receive a :class:`TorchGeometryContext` and return
        ``torch.Tensor`` scalars automatically.
    fixed_params : dict[str, Any]
        Non-learnable constants forwarded to *fn*.
    trainable_params : dict[str, float | Tensor | nn.Parameter]
        Learnable scalar/tensor weights.  Values are converted to
        ``nn.Parameter`` (float64) automatically.
    submodules : dict[str, nn.Module]
        Arbitrary ``nn.Module`` objects (e.g. MLP, embedding).  Registered
        via ``nn.ModuleDict`` so their parameters are tracked by PyTorch.
        Accessed in *fn* as ``params["module_key"]``.

    Examples
    --------
    Scalar learnable parameter::

        import torch.nn as nn
        from ase_biaspot import TorchCallableTerm

        k = nn.Parameter(torch.tensor(1.0, dtype=torch.float64))
        term = TorchCallableTerm(
            name="harmonic_r",
            fn=lambda v, p: p["k"] * (v["r"] - p["r0"]) ** 2,
            variables={"r": lambda ctx: ctx.distance(0, 1)},
            fixed_params={"r0": 0.9},
            trainable_params={"k": k},
        )

    MLP bias via ``submodules``::

        import torch
        import torch.nn as nn
        from ase_biaspot import TorchCallableTerm

        mlp = nn.Sequential(
            nn.Linear(1, 16, dtype=torch.float64),
            nn.Tanh(),
            nn.Linear(16, 1, dtype=torch.float64),
        )
        term = TorchCallableTerm(
            name="mlp_distance_bias",
            fn=lambda v, p: p["mlp"](v["r"].unsqueeze(0)).squeeze(),
            variables={"r": lambda ctx: ctx.distance(0, 1)},
            submodules={"mlp": mlp},
        )
        # All MLP weights are visible to an external optimizer:
        opt = torch.optim.Adam(term.parameters(), lr=1e-3)
    """

    def __init__(
        self,
        name: str,
        fn: Any,
        variables: dict[str, Any] | None = None,
        fixed_params: dict[str, Any] | None = None,
        trainable_params: dict[str, Any] | None = None,
        submodules: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(name)
        self.fn = fn
        self.variables: dict[str, Any] = variables or {}
        self.fixed_params: dict[str, Any] = fixed_params or {}
        import torch.nn as _nn

        self.trainable_params = _nn.ParameterDict(
            {k: _to_parameter(v) for k, v in (trainable_params or {}).items()}
        )
        # nn.ModuleDict registers sub-modules so their parameters are
        # tracked by PyTorch (term.parameters(), term.zero_grad(), etc.)
        self.submodules = _nn.ModuleDict(submodules or {})

    def evaluate_tensor(
        self,
        positions: torch.Tensor,
        atomic_numbers: list[int] | None = None,
    ) -> torch.Tensor:
        ctx = TorchGeometryContext(positions=positions, atomic_numbers=atomic_numbers)
        vars_: dict[str, Any] = {key: extractor(ctx) for key, extractor in self.variables.items()}
        # Merge all param sources; submodules are passed as nn.Module objects
        # so fn can call them directly (e.g. p["mlp"](x)).
        #
        # Collision detection: warn when a key defined in an earlier source
        # is silently overwritten by a later one.  Precedence order is
        # fixed_params → trainable_params → submodules, mirroring the update
        # sequence below.  We surface every collision so the user can rename
        # conflicting keys before a trainable parameter gets hidden by a
        # constant (the most dangerous silent failure mode).
        params: dict[str, Any] = dict(self.fixed_params)
        for source_name, source in (
            ("trainable_params", dict(self.trainable_params)),
            ("submodules", dict(self.submodules)),
        ):
            collisions = set(params.keys()) & set(source.keys())
            if collisions:
                warnings.warn(
                    f"TorchCallableTerm '{self.name}': parameter key(s) "
                    f"{sorted(collisions)} defined in an earlier source are "
                    f"overwritten by '{source_name}'. Rename the conflicting "
                    "keys to avoid silent parameter shadowing.",
                    UserWarning,
                    stacklevel=2,
                )
            params.update(source)
        return self.fn(vars_, params)


class TorchAFIRTerm(TorchBiasTerm):
    """
    AFIR bias term with a learnable ``gamma`` parameter (``nn.Parameter``).

    ``power`` remains a fixed float because it appears only as an integer-like
    exponent and its gradient is rarely meaningful in practice.

    Parameters
    ----------
    name : str
        Identifier used in log output.
    group_a, group_b : list[int]
        0-based atom indices for fragments A and B (non-overlapping).
    gamma_init : float or nn.Parameter
        Initial value of the AFIR gamma parameter (kJ/mol).
        Stored as ``self.gamma_param`` (``nn.Parameter``, float64).

        Accepts either a plain ``float`` (a fresh ``nn.Parameter`` is
        created internally) **or** an existing ``nn.Parameter`` (used
        directly without copying, so ``term.parameters()`` yields the
        same object the caller holds).  Passing an ``nn.Parameter`` is
        the recommended pattern when you need to monitor or update
        ``gamma`` from outside ``BiasCalculator``::

            gamma = nn.Parameter(torch.tensor(3.0, dtype=torch.float64))
            term  = TorchAFIRTerm(..., gamma_init=gamma)
            # term.gamma_param is gamma — same object, not a copy.
            opt = torch.optim.Adam(term.parameters(), lr=0.1)
            # opt now updates the same tensor the caller holds.

        .. warning::
           Initializing with ``gamma_init=0`` (or very close to zero) is
           discouraged. The gradient ``∂alpha/∂gamma`` diverges near zero
           due to the smooth approximation used in ``_alpha_tensor``, which
           can cause optimizer instability at the first step.
           A ``UserWarning`` is emitted when ``|gamma_init| < 0.1`` kJ/mol.

    power : float
        Exponent in the ω weight function (default: 6, fixed).
    gamma_min_abs : float, optional
        Threshold below which a ``UserWarning`` is emitted (default: 0.1 kJ/mol).
        Set to 0.0 to suppress the warning.

    Examples
    --------
    .. rubric:: Float initialisation (most common)

    ::

        import torch
        from ase_biaspot import TorchAFIRTerm

        term = TorchAFIRTerm(
            name="afir_learnable",
            group_a=[0, 1],
            group_b=[2, 3],
            gamma_init=2.5,
        )
        # After a BiasCalculator step:
        print(term.gamma_param.grad)   # ∂E_AFIR / ∂gamma

        opt = torch.optim.Adam(term.parameters(), lr=0.1)
        opt.step(); opt.zero_grad()

    .. rubric:: ``nn.Parameter`` passthrough (external monitoring)

    ::

        import torch, torch.nn as nn
        from ase_biaspot import TorchAFIRTerm

        gamma = nn.Parameter(torch.tensor(3.0, dtype=torch.float64))
        term  = TorchAFIRTerm(name="afir", group_a=[0], group_b=[1],
                              gamma_init=gamma)
        assert term.gamma_param is gamma   # same object — no copy made

        opt = torch.optim.Adam(term.parameters(), lr=0.1)
        # opt.step() updates `gamma` in-place; the caller can inspect it.
    """

    def __init__(
        self,
        name: str,
        group_a: list[int],
        group_b: list[int],
        gamma_init: float | nn.Parameter | None = None,
        power: float = 6.0,
        gamma_min_abs: float = 0.1,
        *,
        gamma: float | nn.Parameter | None = None,
    ) -> None:
        # ``gamma`` is a convenience alias for ``gamma_init`` so that
        # ``TorchAFIRTerm(gamma=5.0)`` works the same way as
        # ``AFIRTerm(gamma=5.0)``.  Passing both raises ``ValueError``.
        if gamma is not None and gamma_init is not None:
            raise ValueError(
                "TorchAFIRTerm: specify either 'gamma_init' or the alias 'gamma', not both."
            )
        if gamma is not None:
            gamma_init = gamma
        if gamma_init is None:
            raise TypeError(
                "TorchAFIRTerm.__init__() missing required argument: "
                "'gamma_init' (or its alias 'gamma')."
            )
        super().__init__(name)
        self.group_a = list(group_a)
        self.group_b = list(group_b)
        # Validate non-empty and disjoint groups at construction time.
        _validate_afir_groups(self.group_a, self.group_b, f"TorchAFIRTerm '{name}'")

        # ── Resolve gamma value and build self.gamma_param ────────────────
        import torch as _torch
        import torch.nn as _nn

        if isinstance(gamma_init, _nn.Parameter):
            _gamma_scalar = float(gamma_init.detach())
            self.gamma_param = gamma_init
        else:
            _gamma_scalar = float(gamma_init)
            self.gamma_param = _nn.Parameter(_torch.tensor(_gamma_scalar, dtype=_torch.float64))

        if gamma_min_abs > 0.0 and abs(_gamma_scalar) < gamma_min_abs:
            warnings.warn(
                f"TorchAFIRTerm '{name}': gamma_init={_gamma_scalar:.3g} kJ/mol is very "
                f"close to zero (|gamma| < {gamma_min_abs} kJ/mol). "
                "The gradient ∂alpha/∂gamma diverges near gamma=0, which may cause "
                "optimizer instability. Consider initializing with a non-zero value "
                "such as gamma_init=1.0.",
                UserWarning,
                stacklevel=2,
            )
        self.power = float(power)

    def evaluate_tensor(
        self,
        positions: torch.Tensor,
        atomic_numbers: list[int] | None = None,
    ) -> torch.Tensor:
        if atomic_numbers is None:
            raise ValueError("TorchAFIRTerm.evaluate_tensor() requires atomic_numbers.")
        # gamma_param is an nn.Parameter — _alpha_tensor propagates grad through it.
        return afir_energy_tensor(
            positions,
            atomic_numbers,
            self.group_a,
            self.group_b,
            self.gamma_param,
            self.power,
        )
