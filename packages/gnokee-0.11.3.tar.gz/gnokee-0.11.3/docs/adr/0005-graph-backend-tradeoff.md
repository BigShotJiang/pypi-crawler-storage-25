# ADR-0005: Graph backend trade-off space — Neo4j v0.1 and v0.2

**Status:** Accepted
**Date:** 2026-05-08
**Refs:** ADR-0001 (build on Graphiti), ADR-0004 (gnokee owns retrieval),
AGENTS.md "Currently-open decisions" (Q5)

## Context

ADR-0001 accepted Graphiti as the bi-temporal storage primitive.
ADR-0004 reassigned retrieval to gnokee. AGENTS.md still listed Q5
(Neo4j vs FalkorDB) as an open decision, with FalkorDB tentatively
positioned for a v0.2 swap.

Two pieces of research on 2026-05-08 changed the picture and forced a
re-decision:

1. **FalkorDB is SSPL v1**, not Apache 2.0. Verified directly from
   the upstream `LICENSE` file. SSPL §13 forces source disclosure for
   anyone offering FalkorDB-backed services to third parties. This
   maps directly onto Omur's planned multi-tenant SaaS deployment of
   gnokee. The v0.2 FalkorDB plan is not a license-compatible plan.

2. **Kùzu is archived** as of 2025-10-10 (verified via the GitHub
   API: `archived: true`). Even though graphiti-core 0.29 ships a
   `kuzu_driver.py`, the upstream project is dead and the driver is
   on a dead-end backend.

The question therefore widened: is there *any* graph backend worth
swapping to in v0.2 — and if so, what is the actual engineering cost?

## Research summary

Of the four backends with an in-tree Graphiti driver:

| Backend | License | Status |
|---|---|---|
| Neo4j Community | GPLv3 server / Apache 2.0 driver | Active, canonical, regression bar for every Graphiti release |
| FalkorDB | **SSPL v1** | Active, but license-incompatible with gnokee/Omur SaaS plans |
| Kùzu | MIT, **archived 2025-10-10** | Dead-end |
| AWS Neptune | Proprietary SaaS | Locked to AWS |

Of the candidates without a Graphiti driver, Apache AGE is the only
strong fit (Apache 2.0, Postgres extension — would collapse Postgres
+ pgvector + graph into one container). Other candidates rejected:

- **Memgraph** — BSL 1.1; SaaS-hostile clauses
- **TerminusDB** — Apache 2.0 but WOQL-only, leaves Graphiti
- **XTDB v2** — MPL-2.0 with native bi-temporal storage, but
  "burn the bridges" scope (rebuild Graphiti's entity-extraction
  pipeline from scratch); JVM runtime
- **CozoDB** — MPL-2.0, embedded, time-travel via validity param,
  but bus-factor of one and slowing 2025
- **SurrealDB** — BSL 1.1 core; bespoke query language; AI-memory
  marketing-heavy without code substance
- **AgensGraph** — Apache 2.0 but dormant fork of Postgres
- **JanusGraph** — Gremlin not Cypher; declining activity
- **DuckPGQ** — read-only graph matching, can't be primary store
- **NebulaGraph** — Apache 2.0 distributed, overkill for personal scale

## Effort: AGE driver vs staying on Neo4j

A focused engineering audit (Apache AGE Cypher coverage vs the
features Graphiti emits) lands the AGE driver at **5–7 person-weeks
realistic**, with two structural complications:

1. **Vector cosine.** AGE has no native cosine. The driver must
   intercept vector-search queries and rewrite them as a Cypher-then-SQL
   CTE that joins back to pgvector. AGE issue #1121 (first-class
   pgvector integration) is still a proposal, no PR. Until that lands,
   the workaround is a shadow-table sync between AGE writes and a
   pgvector mirror — moving parts.

2. **Fulltext.** AGE has no fulltext extension. The driver must
   intercept `CALL db.index.fulltext.queryNodes(...)` and rewrite
   against Postgres `tsvector` + `GIN` indexes. Doable but every
   Graphiti upstream change to the fulltext path becomes a merge
   conflict.

Plus the in-tree-driver expectation. graphiti-core ships its
alternative drivers in-tree (`graphiti_core/driver/`); there is no
plug-in entry point. An out-of-tree AGE driver lives in a fork until
upstream accepts a PR — graphiti issue #1095 (Dec 2025) is the
existing tracking issue and has no PR yet.

**Cost of staying on Neo4j:** near zero. Reference driver, every
Graphiti release regression-tested against it, mature ops surface,
pgvector already in the v0.1 stack so adding Neo4j is just one more
stateful service (~512MB–2GB RAM, separate backup, separate auth)
that gnokee already accepts.

**Break-even for the AGE swap:** the 5–7-week build plus the
ongoing translation tax on every Graphiti upstream release pays back
only if at least two of these hold:

1. gnokee is forced to ship single-binary on-prem under terms
   incompatible with Neo4j Community's GPLv3 server license
2. operational headcount cannot run two stateful services and
   consolidation eliminates a real role-shaped cost
3. gnokee plans to use Postgres-native features (RLS, logical
   replication, pg_partman) directly on graph data, not just on
   facts/embeddings tables

None of these are on the v0.1 or v0.2 roadmap.

## Decision

**Neo4j Community for v0.1 and v0.2.** Drop FalkorDB from the v0.2
plan (SSPL kills it). Defer AGE evaluation until at least one
break-even condition becomes concretely scheduled.

The "Apache 2.0 stack" goal is partially compromised regardless of
backend choice — Neo4j Community is GPLv3 at the server, Postgres is
PostgreSQL License (permissive but its own thing), pgvector is
PostgreSQL License. **gnokee code is Apache 2.0; storage backends
are external dependencies that consumers bring themselves**, same
model as pgvector users for Postgres. `docs/architecture.md`
captures this boundary explicitly.

## Re-evaluation triggers

Re-open this decision when any of the following becomes true:

- gnokee commits to a single-binary on-prem distribution requiring
  non-GPL terms — AGE moves up the priority list immediately
- AGE issue #1121 (first-class pgvector integration) lands and
  ships in an Apache AGE release — the realistic effort drops
  meaningfully (probably 3–4 person-weeks)
- A community Graphiti AGE driver appears upstream — gnokee adopts
  rather than authors
- Omur SaaS hits scaling cliffs that Neo4j Community can't address
  and a license-compatible swap is worth the migration cost
- Cozo recovers active development OR XTDB v3 ships an HTTP-only
  binary that doesn't require JVM ops — re-examines the
  "burn the bridges" path

## Footnote: the upstream contributions opportunity

If gnokee does eventually invest in an AGE driver, it would be
genuinely useful upstream — graphiti-core has had an open issue
(#1095) since December 2025 with no PR. Authoring the driver makes
gnokee a notable upstream contributor and keeps the v0.2 swap
coupled to graphiti-core's release cadence rather than a fork.
But this is opportunity, not obligation; ADR-0005 does not commit
to it.

## Amendment 2026-05-11: AGE release maturity correction + revised cost

**Status:** Amendment — does not change the Decision.
**Date:** 2026-05-11
**Trigger:** Re-audit of Apache AGE release state and concrete
inventory of gnokee's Neo4j surface against a swap plan.

### What was wrong in the original ADR

The original ADR (2026-05-08) implicitly treated AGE as immature
("AGE issue #1121 lands and ships in an Apache AGE release" listed
as a re-evaluation trigger). A focused re-check on 2026-05-11
confirmed AGE is in fact mature and shipping on Postgres-17 — the
same major gnokee already runs:

| Tag | PG | Published |
|---|---|---|
| PG17/v1.7.0-rc0 | 17 | 2026-02-11 |
| PG18/v1.7.0-rc0 | 18 | 2026-01-21 |
| PG15/v1.6.0-rc0 | 15 | 2025-11-20 |
| PG14/v1.6.0-rc0 | 14 | 2025-11-20 |
| PG17/v1.6.0-rc0 | 17 | 2025-09-22 |
| PG16/v1.6.0-rc0 | 16 | 2025-09-04 |

- AGE ships per-PG-major release branches. The `-rc0` suffix is the
  publication convention; `prerelease: false` on every release.
- Compatibility: PG 11–18. gnokee runs PG17 → covered by v1.7.0.
- Activity: 41 commits to master in the 90 days before 2026-05-11,
  latest 2026-05-05. Project is active, not stagnant.
- Issue #1121 (first-class pgvector) is still open, last updated
  2026-01-12, 36 comments, zero PR. Vector cosine still needs the
  shadow-table or CTE bridge.

**Implication:** AGE is technically usable on PG17 today. The
"wait for 1.1 stable" framing implicit in the original triggers is
stale.

### Revised cost estimate (concrete inventory, not hand-wave)

The original ADR estimated 5–7 person-weeks. A 2026-05-11 inventory
of gnokee's actual Neo4j surface lands closer to **7–8 person-weeks
of focused engineering**, plus permanent maintenance tax. Itemised:

| Workstream | Effort |
|---|---|
| Author Graphiti AGE driver against current 0.29 `GraphDriver` contract (no viable upstream — see uahic audit) | 2 wk |
| Port the 11 direct `execute_query` Cypher sites gnokee owns in `src/gnokee/storage/graph.py` | 1 wk |
| pgvector ↔ AGE bridge: shadow embedding table + join logic for hybrid search; intercept and rewrite `cypher()` + vector queries | 1 wk |
| Vector index DDL rewrite: Neo4j HNSW on `name_embedding` + `fact_embedding` → pgvector HNSW; size + EF tuning | 3 d |
| Compose stack: drop neo4j service, build custom postgres+age image (or apache/age base) and re-validate health checks | 2 d |
| Neo4j → AGE migration tool for existing deployments (Omur dump/reload path) | 1 wk |
| Integration suite rewrite: `test_supersession_e2e`, `test_lite_mode_recall`, `test_smoke`, `test_encrypted_body_e2e` + Neo4j fixtures + APOC-dependent ops | 1 wk |
| Eval re-baseline: Q1 / Q7 / Q8 / Q10 / Q11 to catch silent recall regressions before ship | 1 wk |
| Docs + this-ADR amendment + ops runbook | 2 d |
| **Total** | **≈7–8 person-weeks** |

Plus an ongoing tax that does not appear in the one-time estimate:

- Every graphiti-core release re-validates the AGE driver against
  newly emitted Cypher; gnokee carries the only-known Graphiti
  AGE driver until upstream accepts a PR.
- AGE upstream cadence is decoupled from Postgres cadence; gnokee
  takes on a custom image build/push pipeline.
- Bus factor on this driver = 1.

### Audit: uahic/graphiti-postgres is not a shortcut

A community Graphiti AGE driver appearing upstream was listed as a
trigger. The closest candidate today is
`uahic/graphiti-postgres` (standalone repo, not a fork). Audit
verdict: **NOT_VIABLE** for a gnokee swap-in.

- 14 commits, all within a 5-day burst 2026-01-12 to 2026-01-17,
  idle since
- 1 contributor; 0 outside PRs; 0 issues; 1 star; README leads
  with "EXPERIMENTAL ALPHA, BACKUP DATA"
- Pinned `graphiti-core >= 0.8`; gnokee is on 0.29 — roughly 20
  minor versions of `GraphDriver` evolution unaccounted for
- No `SearchFilters` (`valid_at` / `invalid_at` / `created_at`)
  plumbing; Q7 / Q8 temporal queries would silently degrade
- `AgeDriver` and pgvector are not bridged — pure-graph or
  pure-vector, never one query
- IVFFlat indexes, not HNSW — recall regression vs current Neo4j
- Hand-rolled lark Cypher→SQL parser with a `_simple_translate`
  startswith fallback; will not survive graphiti-core's emitted
  Cypher

Useful as reference reading. Not as a dependency.

### Revised re-evaluation triggers

The original five triggers conflated quality-of-life (AGE #1121)
with the actual gating factor (no Graphiti AGE driver upstream).
Re-read:

- gnokee commits to a single-binary on-prem distribution requiring
  non-GPL terms — AGE moves up the priority list immediately
- ~~AGE issue #1121 (first-class pgvector integration) lands and~~
  ~~ships in an Apache AGE release — the realistic effort drops~~
  ~~meaningfully (probably 3–4 person-weeks)~~
  **Superseded:** AGE is shipping on PG17 today regardless of
  #1121; the bridge is hand-rollable. #1121 landing now saves
  ≈1 week of bridge work, not 3–4 weeks. Tracked as a watch item,
  not a trigger.
- An **upstream-merged** Graphiti AGE driver appears — gnokee adopts
  rather than authors. (Strengthened from the original wording: an
  out-of-tree fork like `uahic/graphiti-postgres` does not satisfy
  this trigger.)
- Omur SaaS hits operational pain from running two stateful stores
  that exceeds 7–8 weeks of engineering invest plus permanent
  driver-maintenance tax — pull the trigger
- Cozo recovers active development OR XTDB v3 ships an HTTP-only
  binary that doesn't require JVM ops — re-examines the
  "burn the bridges" path

### What this amendment does NOT change

- Decision: Neo4j Community for v0.1 and v0.2 still holds.
- "gnokee code is Apache 2.0; storage backends are external
  dependencies consumers bring themselves" still holds.
- Footnote on the upstream contribution opportunity still holds —
  and now carries a concrete 7–8-week price tag.

## Amendment — 2026-05-16 (issue #152): per-label group_id indexes — verified, not duplicated

Issue #152 (`neo4j-ops-specialist` review) flagged a suspected missing
`group_id` index that would let every per-tenant Cypher fall back to
`NodeByLabelScan` + `Filter`. Investigation against Neo4j Community 5 +
graphiti-core 0.29 found that Graphiti's
`build_indices_and_constraints()` **already creates** the necessary
range indexes:

```
episode_group_id    on  Episodic.group_id    (RANGE, ONLINE)
entity_group_id     on  Entity.group_id      (RANGE, ONLINE)
relation_group_id   on  RELATES_TO.group_id  (RANGE, ONLINE)
mention_group_id    on  MENTIONS.group_id    (RANGE, ONLINE)
has_episode_group_id  on HAS_EPISODE.group_id
next_episode_group_id on NEXT_EPISODE.group_id
community_group_id  on  Community.group_id   (RANGE, ONLINE)
saga_group_id       on  Saga.group_id        (RANGE, ONLINE)
```

`EXPLAIN MATCH (n:Episodic {group_id: $g}) RETURN count(n)` already
plans to `NodeIndexSeek RANGE INDEX n:Episodic(group_id)` on a
graphiti-managed v0.8 instance. Same for `Entity`.

**Outcome:** gnokee does NOT add its own `group_id` indexes —
duplicating graphiti's would add pointless write amplification on every
Episodic/Entity insert with zero query-plan benefit. The
`bootstrap_indices` docstring notes the dependency.
`tests/integration/test_neo4j_group_id_indexes.py` is a regression
guard: if a future graphiti upgrade renames or drops these indexes the
test catches it before per-tenant Cypher silently degrades to O(n)
scans.
