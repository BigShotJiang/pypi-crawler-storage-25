# gnokee backlog

Living index of post-v0.2.x work. Each item links to its tracking GitHub issue. Items get promoted from this doc to a release scope (v0.3, v0.4, etc.) as they pick up momentum.

Source of truth is the GitHub issue. This doc is the table of contents.

## v0.11.3 — patch scope (DRAFT 2026-05-19 — "forget_episode top-level re-export")

Source: [omur#598](https://github.com/omurlabs/omur/pull/598) — Phase C
("GnokeeMemoryProvider via Marrow HTTP bridge") merged 2026-05-19T20:45Z
using existing v0.11 APIs only. Marrow's `/memory/forget` route uses
`from gnokee.forget import forget_episode` (module path). The top-level
re-export is a DX cleanup so downstream consumers can `from gnokee import
forget_episode` to match `ingest_episode` / `recall` / `history_of` etc.

This replaces the previously-drafted v0.12.0 scope (see
[docs/plans/2026-05-19-v0.12-marrow-bridge.md](plans/2026-05-19-v0.12-marrow-bridge.md)
header for the supersession trail). The two larger items that were
draft-scoped to v0.12 are gone:

- `gnokee.get_episodes` / `EpisodeRecord` — Phase C used `history_of`
  with sibling-row join instead; [ADR-0029](adr/0029-episode-record-provenance-api.md)
  flipped to **Rejected**.
- `MemoryProvider.forget` Protocol contract reconcile — Phase C inlined
  the gnokee call in the Marrow route rather than evolving the Protocol
  shape; no cross-repo coordination needed.

| # | Title | Driver |
|---|---|---|
| (new) | Lift `forget_episode` to `gnokee/__init__.py` top-level + `__all__` (re-export from `gnokee.forget`); add `tests/unit/test_public_surface.py` to pin identity | omur#598 — public-surface parity with other forget-adjacent symbols |

Pre-impl gates: none. Patch is independent of upstream; Marrow's existing
module-path import continues to work after the re-export lands.

Out of scope for v0.11.3 (no concrete consumer demand):
- `gnokee.get_episodes(... episode_ids)` / `EpisodeRecord` — see
  [ADR-0029 rejection note 2026-05-19](adr/0029-episode-record-provenance-api.md#rejection-note-2026-05-19).
- `recorded_at` on `HistoryNode` — Marrow currently sources from sibling
  row; if a non-Marrow consumer asks, candidate for v0.11.x or v0.12.
- Predicate-level / subject-level forget primitives — covered by
  [ADR-0026 amendment 2026-05-19](adr/0026-forget-pipeline.md#amendment-2026-05-19--public-forget-surface-is-episode-level-and-tenant-level-only)
  rejection; Marrow now enforces this via its HTTP surface, not the
  Protocol shape.

Parked for v0.13+ minor (no Omur driver until Option C MCP transport
revives):
- [#233](https://github.com/omurlabs/gnokee/issues/233) — `gnokee_forget_episode.episode_uuid` → `episode_id` MCP param rename.
- [#244](https://github.com/omurlabs/gnokee/issues/244) — MCP auth surface (FastMCP `AuthBackend`).
- [#245](https://github.com/omurlabs/gnokee/issues/245) — productionize streamable-http transport.
- [#246](https://github.com/omurlabs/gnokee/issues/246) — `tenant_id` boundary audit (single-process server).

## v0.11 — release scope (LANDED 2026-05-18, both a0 and final)

Source: specialist sweep 2026-05-17. v0.11.0a0 (2026-05-18) absorbed the
overnight-autonomous batch; v0.11.0 final (same day) closed the four
human-driver tail issues (#210/#211/#218/#220) plus #232 and four P2
cleanups (#236/#237/#239/#243). See `## Closed in the v0.11 series`
below for the rotation.

## v0.11.2 — patch scope (LANDED + CUT 2026-05-19 — "Stage 4 retrieval correctness")

Tagged `v0.11.2` on 2026-05-19. Two retrieval fixes that landed
post-v0.11.1 tag: #95 (Stage 4 attribution-filter) and #290
(fact-cosine floor that closes the grader-artifact regression the
first fix surfaced). See `## Closed in the v0.11 series` for the
rotation.

Source: #95 unblocked by the post-v0.11.1 specialist-sweep root-cause
finding (Graphiti `MENTIONS` chain attributes every fact about a
shared `Entity` hub to every episode mentioning it). #290 surfaced
during #95 verification on Q41 — Q-X.3 went 10/10 → 9/10 on the
grounded-but-topically-unrelated £-quote fact, addressed via
fact-cosine floor knob rather than grader change.

| # | Title | Driver |
|---|---|---|
| _(empty — both items landed)_ | | |

## v0.11.1 — patch scope (LANDED + CUT 2026-05-18 — "FORCE-RLS readiness + dead-code mop-up")

Tagged `v0.11.1` on 2026-05-18. All six P1+P2 items closed
(PRs #283/#284/#285/#286/#287 plus #231 closed no-action). See
`## Closed in the v0.11 series` for the rotation. `#95` (Q41
rank-order tune) carried into v0.11.2 — single eval miss, no
FORCE-RLS dependency.

Source: post-v0.11.0 specialist-sweep residue + the natural continuation
of #220 (RLS GUC sweep). Driver = close the FORCE-RLS readiness gap
before any `FORCE ROW LEVEL SECURITY` migration ships.

Out of scope for v0.11.1 (saved for v0.12.0 minor):
- #233 — `gnokee_forget_episode.episode_uuid` → `episode_id` rename (breaking MCP param).
- #244 — MCP auth surface (new feature).
- #245 — productionize streamable-http transport (new feature).
- #246 — tenant_id boundary audit (new audit surface, may surface ADR).
- #235 — Graphiti LLMConfig cross-lingual prompt override (new integration surface).
- #238 — embedder startup probe (new bootstrap behavior).
- #207 — Q3 harness rewrite for `gnokee_query` envelope (eval scaffolding new).
- omkit `set_tenant_guc` upstream — new abstraction.
- #79 / #78 / #75 / #102 / #108 — ADR-grade work (next-quarter candidates).

## v0.10.x — release scope (carryovers from 2026-05-17)

`#207` deferred to v0.12.0 (eval scaffolding is new-public-surface,
patch-class doesn't fit). `#95` + `#290` landed in v0.11.2.

| # | Title | Driver |
|---|---|---|
| _(empty — rolled forward)_ | | |

## Closed in the v0.11 series

| # | Title | Where |
|---|---|---|
| [#210](https://github.com/omurlabs/gnokee/issues/210) | `EdgeInWindow.asserted_at` axis-3 pollution in backfill | v0.11.0 (PR #274) |
| [#211](https://github.com/omurlabs/gnokee/issues/211) | `list_episodes_for_tenant` missing `valid_until` upper bound + `corrects_reason` | v0.11.0 (PR #276) |
| [#212](https://github.com/omurlabs/gnokee/issues/212) | `gnokee_history_of` anchor missing `asserted_until` predicate | v0.11.0a0 |
| [#213](https://github.com/omurlabs/gnokee/issues/213) | `_recency_proxy` axis-2/axis-1 swap | v0.11.0a0 |
| [#215](https://github.com/omurlabs/gnokee/issues/215) | Neo4j HNSW DDL hardcoded dim | v0.11.0a0 |
| [#217](https://github.com/omurlabs/gnokee/issues/217) | `_OurIdRaceLost` bare `AssertionError` | pre-a0 (PR #263) |
| [#218](https://github.com/omurlabs/gnokee/issues/218) | `fact_contradiction` DELETE on wrong UUID column | v0.11.0 (PR #277) |
| [#220](https://github.com/omurlabs/gnokee/issues/220) | RLS GUC missing on `fact_history.py` + `vector.py` reads | v0.11.0 (PR #278) |
| [#221](https://github.com/omurlabs/gnokee/issues/221) | ADR-0028 amend vs insert-new-row | works-as-designed (PR #270) |
| [#222](https://github.com/omurlabs/gnokee/issues/222) | `gnokee_query` lazy provenance pointer | v0.11.0a0 |
| [#223](https://github.com/omurlabs/gnokee/issues/223) | `docs/api/mcp.md` tools-at-glance drift | v0.11.0a0 |
| [#224](https://github.com/omurlabs/gnokee/issues/224) | recall/query disambiguation in descriptions | v0.11.0a0 |
| [#225](https://github.com/omurlabs/gnokee/issues/225) | telemetry behind `include_telemetry` opt-in | v0.11.0a0 |
| [#226](https://github.com/omurlabs/gnokee/issues/226) | `gnokee_forget_episode` description trim | v0.11.0a0 |
| [#227](https://github.com/omurlabs/gnokee/issues/227) | `prior_revision_id` short-ID symmetry | v0.11.0a0 |
| [#228](https://github.com/omurlabs/gnokee/issues/228) | `OpenAIClient` empty-key guard | pre-a0 (PR #260) |
| [#232](https://github.com/omurlabs/gnokee/issues/232) | `gnokee_wiki_export` `valid_at` axis | v0.11.0 (PR #275) |
| [#236](https://github.com/omurlabs/gnokee/issues/236) | `DEFAULT_MAX_TOKENS` documentation | v0.11.0 (PR #280) |
| [#237](https://github.com/omurlabs/gnokee/issues/237) | caller-parsed Lab/Med fallback dead code | v0.11.0 (PR #280) |
| [#239](https://github.com/omurlabs/gnokee/issues/239) | `write_lite_episode` content-zero on encrypted resume | v0.11.0 (PR #279) |
| [#243](https://github.com/omurlabs/gnokee/issues/243) | `list_edges_in_window` static Cypher | v0.11.0 (PR #279) |
| _(no issue — #220 follow-up)_ | RLS GUC sweep + `set_config(..., true)` transaction wrap on `metadata.py` / `contradictions.py` / `lab.py` / `wiki_export.py` / `vector.py` / `fact_history.py` | v0.11.1 (PR #283) |
| [#240](https://github.com/omurlabs/gnokee/issues/240) | `OpenAIRerankerClient` wired but never exercised | v0.11.1 (PR #284) |
| [#234](https://github.com/omurlabs/gnokee/issues/234) | `ForgetNeo4jPartial` hint references Python `resume_forget` | v0.11.1 (PR #285) |
| [#242](https://github.com/omurlabs/gnokee/issues/242) | No duplicate-vector-index guard if graphiti-core upgrade adds vector DDL | v0.11.1 (PR #286) |
| [#230](https://github.com/omurlabs/gnokee/issues/230) | Autovacuum tuning missing on `content_embedding` + `ingest_audit` | v0.11.1 (PR #287) |
| [#231](https://github.com/omurlabs/gnokee/issues/231) | ADR-0004 reconciliation — `content_embedding` schema names diverge from spec | v0.11.1 (closed no-action — ADR-0004 already had the 2026-05-17 reconcile amendment) |
| [#95](https://github.com/omurlabs/gnokee/issues/95) | Graphiti fact-ranking: allergy episode outranked by medication (Q41 p_x1_03) | v0.11.2 (PR #291; fact-attribution `ep.uuid IN r.episodes` fix; ADR-0019 § Issue #95 verdict) |
| [#290](https://github.com/omurlabs/gnokee/issues/290) | Fact-cosine reranking + Q-X.3 grader refinement (follow-up to #95) | v0.11.2 (PR #292; `fact_cosine_floor` retrieval knob + `gnokee_recall` MCP param; ADR-0019 § Issue #290 verdict) |

## v0.4.x — release scope

| # | Title | Driver |
|---|---|---|
| _(empty — #84 landed in v0.4.0 follow-up, see Closed in the v0.4.x series below)_ | | |

## v0.5.x — release scope (post-v0.5 follow-ups)

| # | Title | Driver |
|---|---|---|
| [#95](https://github.com/omurlabs/gnokee/issues/95) | Graphiti fact-ranking: allergy episode outranked by medication episode (Q41 p_x1_03) | Q41 follow-up; single eval miss, rank-order tune. Low priority. |

## v0.5 — release scope (LANDED 2026-05-12)

Source: [#71](https://github.com/omurlabs/gnokee/issues/71) competitive-landscape 2026-Q2 review.
Scope landed 2026-05-12 (commits b990f3f / e7e81b3 / d8fe1d5 / a013a49).
See "Closed in the v0.5 series" below for the rotation.

### Next-quarter candidates (post-v0.5)

| # | Title | Driver |
|---|---|---|
| ~~[#73](https://github.com/omurlabs/gnokee/issues/73)~~ | ~~ADR-0014 append-only `fact_revision` log + `gnokee_fact_history` MCP tool~~ — **SHIPPED v0.9.0a0** | GCP Memory Bank `MemoryRevision` + A-MEM bidirectional evolution. |
| [#79](https://github.com/omurlabs/gnokee/issues/79) | ADR-0018 typed supersession verb grammar + `branch_id` for what-if reasoning | Mem0 ADD/UPDATE/DELETE/NOOP grammar (DELETE-free variant) + Letta / TerminusDB branch axis. Depends on #73. |
| [#78](https://github.com/omurlabs/gnokee/issues/78) | ADR-0017 declarative `gnokee.types.yaml` surface | A-MEM tag-evolution + Fabric IQ ontology vocabulary alignment. |
| [#75](https://github.com/omurlabs/gnokee/issues/75) | Spike: scheduled dreaming lint pass for cross-session supersession | Anthropic Dreaming + A-MEM bidirectional evolution; cron infra (`scheduled_tasks.lock`) already present. |
| [#102](https://github.com/omurlabs/gnokee/issues/102) | Spike Q15: semantic bridges across `group_id` partitions (cross-source-type fact discovery) | NOUZ-MCP "semantic bridge" idea on `EntityEdge.fact_embedding`; lab↔med↔wearable see-also signal. |
| [#103](https://github.com/omurlabs/gnokee/issues/103) | Vault-adapter onboarding: mean-centered cosine separation health check on source-type prompts | NOUZ-MCP calibration ergonomic; one-shot probe, no infra, catches weak source-type prompts before retrieval. |
| [#104](https://github.com/omurlabs/gnokee/issues/104) | Obsidian vault adapter: opportunistic NOUZ frontmatter interop (read sign/level/parents/tags if present) | Co-marketing + zero-risk interop with NOUZ-managed vaults; follow-up to ADR-0020. |
| [#108](https://github.com/omurlabs/gnokee/issues/108) | Q16 — Notion export ingest quality through Obsidian adapter | ADR-0020 § Q14.2 follow-up; measures markdown→plaintext recall on heavy-formatted (Notion-noise) source. |

Items can move to `wontfix` after ADR debate per #71 § "What this issue is for".

## v0.6 — release scope (LANDED 2026-05-16)

Source: [#111](https://github.com/omurlabs/gnokee/issues/111) (Q18 silent-drop verdict).
Scope landed 2026-05-16 via PR #121 (squash commit 9b4cd54). Q18 release-cut gate PASS: recall@5 measurable = 100% (vs v0.5 baseline 17.6%); 0 silent-drops. See "Closed in the v0.6 series" below for the rotation.

## v0.7 — release scope (LANDED 2026-05-16)

"Durability + lineage" ramp. Scope locked 2026-05-15; full batch landed 2026-05-16 (#124 STRICT removal → #122 journal + ADR-0024 → #123 history_of DAG). See "Closed in the v0.7 series" below for the rotation.

## v0.7.x — release scope (post-v0.7 follow-ups)

| # | Title | Driver |
|---|---|---|
| ~~[#130](https://github.com/omurlabs/gnokee/issues/130)~~ | ~~Forget-cascade: include `ingest_journal` in tenant-deletion sweep~~ — **CLOSED 2026-05-16** | ADR-0024 follow-up; tenant-forget must wipe journal rows. |
| [#102](https://github.com/omurlabs/gnokee/issues/102) | Q15 cross-`group_id` semantic bridges spike | Adjacent retrieval primitive; carried over from v0.6.x. |

### Next-quarter candidates (post-v0.7)

| # | Title | Driver |
|---|---|---|
| ~~[#73](https://github.com/omurlabs/gnokee/issues/73)~~ | ~~ADR-0014 append-only `fact_revision` log + `gnokee_fact_history` MCP tool~~ — **SHIPPED v0.9.0a0** | GCP Memory Bank `MemoryRevision` + A-MEM bidirectional evolution. Natural successor to `gnokee_history_of` (episode-level → fact-level lineage). |
| [#79](https://github.com/omurlabs/gnokee/issues/79) | ADR-0018 typed supersession verb grammar + `branch_id` for what-if reasoning | Mem0 ADD/UPDATE/DELETE/NOOP grammar (DELETE-free variant) + Letta / TerminusDB branch axis. Depends on #73. |
| [#78](https://github.com/omurlabs/gnokee/issues/78) | ADR-0017 declarative `gnokee.types.yaml` surface | A-MEM tag-evolution + Fabric IQ ontology vocabulary alignment. |
| [#75](https://github.com/omurlabs/gnokee/issues/75) | Spike: scheduled dreaming lint pass for cross-session supersession | Anthropic Dreaming + A-MEM bidirectional evolution. |
| [#108](https://github.com/omurlabs/gnokee/issues/108) | Q16 Notion export ingest quality through Obsidian adapter | ADR-0020 § Q14.2 follow-up; markdown→plaintext recall on Notion-noise source. |
| Z2 (untracked) | `EpisodeIn.source_type` field + lite-mode default for prose | Deferred from v0.6 per ADR-0023 § Out-of-scope. Public API contract — own ADR. |
| LongMemEval-S publish | ADR-0019 stance `PUBLISH_POST_Z1`; publish recall@5 / recall@10 numbers | Q18 gate pass unlocks this. Separate PR. |

## How to add an item

1. Open a GitHub issue with a 1-line title and a short body covering: problem / decision / acceptance.
2. Label with the target release (`v0.3`, `v0.4`, etc.) and a category (`enhancement`, `documentation`, etc.).
3. Add a row to the appropriate table above. Keep the description column to one driver-sentence — the issue carries the detail.

## Closed in the v0.10.x series

v0.10.1 (2026-05-17) — specialist-sweep P1 mop-up:
- Issue #214 — Cypher deprecated `count()` after `DETACH DELETE` × 4 sites — landed (PR #248). Side-effect: kills the `UserWarning: Expected a result with a single record, but found multiple` from `graph.py`.
- Issue #216 — `EpisodeIn.asserted_at` doc claimed `now(UTC)` default; actual is `valid_at` — landed (PR #247).
- Issue #219 — `write_embedding` called without `model=` so column ignored `GNOKEE_EMBED_MODEL` — landed (PR #249).
- Issue #229 — `classify_contradiction` outer try/except swallowed `LLMUnavailable` past per-pair handler — landed (PR #250).
- Issue #241 — `add_episode(our_id=None)` silently disables dedup; emit ingest-time WARN — landed (PR #251).

Deferred to v0.10.x / unscoped:
- Issue #207 — Q3 harness rewrite driving `gnokee_query` envelope at `output_shape:fact` (median-token capture + ADR-0013 v0.10 footer amendment).
- Issue #95 — Graphiti fact-ranking allergy/med rank delta on Q41 `p_x1_03` (investigation; no acceptance contract yet).

## Closed in the v0.7 series

v0.7.0 (2026-05-16):
- Issue #122 — Ingest crash-recovery journal + `gnokee.resume_ingest` Python API — landed (PR #129, squash aa559da). Append-only `ingest_journal` Postgres table; `begin`/`commit`/`fail` rows; `IngestPipeline` surfaces orphans on first ingest per tenant per process. Operator-driven resume only — gnokee NEVER auto-replays. ADR-0024 Accepted. Q19 spike: 2.17% median latency regression (under ADR-0024 10% threshold).
- Issue #123 — `gnokee_history_of` supersession-DAG MCP tool + `gnokee.history_of` Python API — landed (#128). Cytoscape-flat envelope; `mode=compact` / `mode=verbatim`; `as_of` time-travel; `cycle_detected` instead of raising; encrypted episodes keep ciphertext. `EpisodeIn.corrects_reason` field added (Python API only; MCP exposure deferred).
- Issue #124 — Hard-removal of `GNOKEE_INGEST_STRICT` env var — landed (#126). v0.6 deprecation cycle closed; env var now a no-op. Replacement signals on `IngestReceipt.ingest_telemetry`.
- ADR-0024 — Ingest crash-recovery journal — Status `Accepted` (#127).

## Closed in the v0.6 series

v0.6.0 (2026-05-16):
- Issue #111 — Graphiti `add_episode` silent-drop ingest hardening — landed (#121). Z1 storage-first stage reorder + Z4 adaptive retry + concurrency cap. Q18 release-cut gate PASS: recall@5 measurable 17.6% → 100%; zero silent-drops. ADR-0023 Accepted. ADR-0012 + ADR-0019 amended.
- ADR-0023 — gnokee owns episode storage; Graphiti is enhancement-only — Status `Accepted`.
- `GNOKEE_INGEST_STRICT` env var — deprecated (DeprecationWarning); hard-removal v0.7.

## Closed in the v0.5 series

v0.5.0 (2026-05-12):
- Issue #72 — ADR-0013 `gnokee_query` declarative envelope MCP tool — landed (#100).
- Issue #74 — ADR-0015 `gnokee_wiki_export` + `llms.txt` manifest — landed (#99).
- Issue #76 — ADR-0016 per-claim bi-temporal citation envelope — landed (#92).
- Issue #77 — Source-grounded refusal Q-suite — consolidated into #109 / ADR-0022.
- Issue #80 — confidence-decay function open question — resolved by ADR-0019 (`SHIP_RECENCY_AS_PROXY`, PR #87).
- Issue #81 — LongMemEval-S v0.5 publish target — resolved as `DECLINE_TO_PUBLISH` (ADR-0019 amendment 2026-05-12); defer to v0.6 after #111.
- Issue #88 — Q13.1 confidence-model stage-2 spike at N≥30 — landed (#118). Verdict `KEEP_RECENCY_PROXY`: 0/48 composite variants cleared both Spearman + calibration gates at N=31. ADR-0019 § Follow-up closed.
- Issue #89 — per-fact `cosine_top1` telemetry on `gnokee_recall` — landed (#117); ADR-0019 § Follow-up amended (recency-proxy proxy reading retired).
- Issue #90 — Graphiti literal-numeric extraction gap — accepted (option 1 of 4); triple-coverage via `lab_record` / `med_record` / `excerpts[]` + `episode_fallback[]` suffices.
- Issue #94 — Refusal posture UX gap — ADR-0022 Option A landed (#119): `refused: bool` + `cosine_floor` knob on `RecallResponse` / `gnokee_recall`. Pulled forward from v0.5.x.
- Issue #97 / #96 — Obsidian vault adapter — landed (#101); ADR-0020 Q14 spike verdict `SHIP_ADAPTER`.
- Issue #103 — Vault-adapter mean-centered cosine separation probe — landed (#105).
- Issue #106 — ADR-0021 consumer surface strategy — accepted (#113).
- Issue #107 — Q14.1 sweep of past spike harnesses for threshold-semantics bug class — landed (#114).
- Issue #109 — Q17 refusal-posture spike + ADR-0022 draft — landed (#115); verdict `ADOPT_OPTION_D_CURRENT_POSTURE_CONTROLS_PARTIAL`.
- Issue #110 — v0.5 LongMemEval narrative note — landed (8743c25).
- Issue #111 (Z3 partial) — graphiti orphan-edge warnings on `IngestReceipt` — landed (#112). Z1/Z2 remain for v0.6.
- ADR-0022 — refusal posture — Status `Accepted` (verdict `ADOPT_OPTION_D`, Q17 spike; amended same-day for Option A landing) — landed (#116, #119).

## Closed in the v0.2.x maintenance series

v0.2.2 (2026-05-09):
- Issue #17 — partial open-subset indexes on `lab_record` / `med_record` for supersession perf — landed.
- Issue #18 — `gnokee_lab_query op=abnormal`; Q7 `q_electrolyte_abnormal_q2` PARTIAL → PASS — landed.
- Issue #19 — `gnokee_recall.supersession_hints[]` (Option A+, clinical-safe) — landed.

v0.2.3 (2026-05-09):
- Issue #20 — first PyPI publish; `pip install gnokee==0.2.3` works — landed.
- Issue #21 — `GNOKEE_SPIKE_SKIP_INGEST=1` env-var alignment for Q7 + Q8 harnesses — landed.

## Closed in the v0.3.x release scope

v0.3.0 (2026-05-09):
- Issue #16 — Lite ingest mode + integration patterns doc + eval-delta gate — landed.
- Issue #38 — `gnokee.recall` episode-cosine fallback when `fact_count == 0` (Path A) — landed.
- Issue #39 — Q10.1 Zep-OSS + basic-memory adapters + Stage C confirmation — landed; ADR-0012 Accepted-with-caveat.
- Issue #54 — per-lane budget + emitted telemetry on `RecallResponse` — landed.
- Issue #56 — lite-mode ingest writes minimal `Episodic` node so recall sees it — landed.

v0.4.0 (2026-05-10):
- Issue #22 — `encrypted_body` branch wires DEK pathway end-to-end (Stage 1 boundary, migration `0012_episode_body_encrypted`, recall surfacing) — landed.
- Issue #37 — ADR-0004 + ADR-0012 amendments for encrypted_body boundary + Q10 Stage C-pilot magnitude — landed.
- Issue #51 — consolidate `episode_metadata.content` + `content_text` (migration `0011_drop_content_column`) — landed.
- Issue #52 — `top_k_bodies` + `per_body_char_cap` knobs on `recall()` (Python API; MCP deferred) — landed.
- Issue #62 — Q12 abstain split + synth-v2 falsifies "retrieval is the bottleneck" hypothesis — landed.
- Issue #63 — `evals/q10/run.py` parallelize per-question + Mem0 adapter robustness — landed.
- Issue #64 — Q10 / Zep CE compose env keys + smoke step — landed.

## Closed in the v0.4.x series

(no v0.4.x point release cut yet; closures listed against the next tag)

- Issue #80 — confidence-decay function open question — resolved by ADR-0019 (Accepted-with-caveat, SHIP_RECENCY_AS_PROXY); merged in #87.
- Issue #84 — MCP `top_k_bodies` + `per_body_char_cap` exposure on `gnokee_recall` — merged in #85.
- Issue #90 — Graphiti literal-numeric extraction gap — **Accept** (option 1 of 4); triple-coverage via `lab_record` / `med_record` / `excerpts[]` + `episode_fallback[]` suffices; ADR-0019 § Follow-up amended + spike-author guidance added to `docs/evals/methodology.md`.

## Closed before v0.2.x

- Issue #15 — `chore(release): v0.2.0 typed clinical reads` — landed.
- Issues #2 / #3 / #4 / #5 / #6 / #7 / #8 — v0.1.1 extraction-quality work, all closed before v0.2.0.

ADRs that surface implicit backlog items but are not yet tracked as issues:
- ADR-0011 (wearables off-ramp) — depends on consumer TimescaleDB integration; not gnokee work.
- ADR-0008 (contradiction storage) — Q4 closed; orthogonal to supersession.
