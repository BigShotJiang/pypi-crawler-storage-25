"""src/gnokee/mcp/__init__.py — FastMCP server. Tools:

  - gnokee_ingest_episode
  - gnokee_recall
  - gnokee_fact_provenance
  - gnokee_lab_query       (v0.2 / ADR-0009 — typed clinical-lab reads)
  - gnokee_med_query       (v0.2 / ADR-0010 — typed medication-history reads)
  - gnokee_query           (v0.5 / ADR-0013 — declarative envelope)
  - gnokee_wiki_export     (v0.5 / ADR-0015 — markdown wiki view per tenant)
  - gnokee_history_of      (v0.7 / issue #123 — supersession DAG)
  - gnokee_fact_history    (v0.9 / issue #73 — fact-grain revision log)
  - gnokee_forget_episode  (v0.8 / ADR-0026 — hard-delete episode + descendants)
  - gnokee_forget_tenant   (v0.8 / ADR-0026 — hard-delete entire tenant)

Tool descriptions per spec §6 (token-budgeted, fit MCP listing). All
datetime parameters accept ISO-8601 strings (Z or +HH:MM); MCP layer
resolves null → datetime.now(UTC) BEFORE calling the Python API.

exports: build_server | _cli_main
used_by: external MCP clients
rules:   never let `None` flow into storage; tenant_id mandatory; v0.1 unauthenticated
agent:   claude-opus-4-7 | 2026-05-09 | v0.2 ADR-0009
         claude-opus-4-7 | 2026-05-11 | issue #84 expose top_k_bodies + per_body_char_cap on gnokee_recall
         claude-opus-4-7 | 2026-05-11 | issue #76 / ADR-0016 per-claim citation envelope
         claude-opus-4-7 | 2026-05-11 | issue #72 / ADR-0013 gnokee_query declarative envelope
         claude-opus-4-7 | 2026-05-11 | issue #74 / ADR-0015 gnokee_wiki_export + llms.txt manifest
         claude-sonnet-4-6 | 2026-05-12 | issue #89 include_cosine_top1 opt-in telemetry on gnokee_recall
         claude-sonnet-4-6 | 2026-05-12 | issue #94 / ADR-0022 Option A cosine_floor + refused signal
         claude-sonnet-4-6 | 2026-05-16 | issue #130 / ADR-0026 gnokee_forget_episode + gnokee_forget_tenant
         claude-opus-4-7   | 2026-05-18 | issue #290 fact_cosine_floor knob + fact_cosine telemetry on gnokee_recall
"""

from __future__ import annotations

import asyncio
import logging
import os
from datetime import datetime
from typing import Annotated, Any, Literal
from uuid import UUID

import asyncpg
from mcp.server.fastmcp import FastMCP
from pydantic import Field

from gnokee.bootstrap import App, build_app, shutdown_app
from gnokee.config import Settings, utc_now
from gnokee.errors import CannotForgetChainNode, ForgetNeo4jPartial, GnokeeError
from gnokee.fact_history import DEFAULT_MAX_REVISIONS as FACT_HISTORY_MAX_REVISIONS
from gnokee.forget import forget_episode, forget_tenant
from gnokee.history import (
    DEFAULT_MAX_NODES as HISTORY_DEFAULT_MAX_NODES,
)
from gnokee.history import (
    DEFAULT_MAX_TOKENS as HISTORY_DEFAULT_MAX_TOKENS,
)
from gnokee.history import (
    DEFAULT_PER_BODY_CHAR_CAP as HISTORY_DEFAULT_PER_BODY_CHAR_CAP,
)
from gnokee.history import (
    DEFAULT_TOP_K_BODIES as HISTORY_DEFAULT_TOP_K_BODIES,
)
from gnokee.ingest import ingest_episode
from gnokee.lab_query import DEFAULT_HISTORY_LIMIT, lab_query
from gnokee.med_query import DEFAULT_HISTORY_LIMIT as MED_HISTORY_LIMIT
from gnokee.med_query import med_query
from gnokee.models import Citation, ForgetEpisodeIn, ForgetReceipt, ForgetTenantIn
from gnokee.query import (
    DEFAULT_MAX_EPISODES,
    DEFAULT_MAX_TOKENS,
    DateRange,
    QueryEnvelope,
    QueryEnvelopeBudget,
    QueryEnvelopeFilter,
    QueryResponse,
)
from gnokee.query import (
    gnokee_query as run_gnokee_query,
)
from gnokee.retrieval import (
    DEFAULT_PER_BODY_CHAR_CAP,
    DEFAULT_TOP_K_BODIES,
    fact_provenance,
    recall,
)
from gnokee.wiki_export import wiki_export

from . import short_id as _sid

log = logging.getLogger(__name__)

# Issue #183 — Q3 validated ceiling for `max_tokens` on the recall path.
# Above 500 the body lane crowds out the fact list without improving recall
# in the Q3 harness; LLMs that pass `10_000` etc. waste the budget and
# inflate token cost without changing the answer. Applied at the MCP
# boundary so the underlying recall/query pipelines stay unbounded for
# direct library callers.
MAX_TOKENS_CEILING = 500


# ADR-0027 / issue #197 — short-ID translation at the MCP boundary.
# Every UUID emit site in the gnokee_* tools routes through these
# helpers. They are thin wrappers over `_sid.encode` that pin the kind
# vocabulary to the caller's expectation. ``_encode_ep_optional`` and
# friends keep the nullable-UUID branches readable.


async def _encode_ep(pool: asyncpg.Pool, tenant_id: str, uuid: UUID) -> str:
    return await _sid.encode(pool, tenant_id=tenant_id, kind="ep", target_uuid=uuid)


async def _encode_fact(pool: asyncpg.Pool, tenant_id: str, uuid: UUID) -> str:
    return await _sid.encode(pool, tenant_id=tenant_id, kind="fact", target_uuid=uuid)


async def _encode_ent(pool: asyncpg.Pool, tenant_id: str, uuid: UUID) -> str:
    return await _sid.encode(pool, tenant_id=tenant_id, kind="ent", target_uuid=uuid)


async def _encode_ep_optional(pool: asyncpg.Pool, tenant_id: str, uuid: UUID | None) -> str | None:
    if uuid is None:
        return None
    return await _encode_ep(pool, tenant_id, uuid)


async def _encode_fact_optional(pool: asyncpg.Pool, tenant_id: str, uuid: UUID | None) -> str | None:
    if uuid is None:
        return None
    return await _encode_fact(pool, tenant_id, uuid)


def _parse_datetime(value: str | None) -> datetime | None:
    if value is None:
        return None
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def _require_datetime(value: str | None) -> datetime:
    parsed = _parse_datetime(value)
    return parsed if parsed is not None else utc_now()


async def _serialize_fact_revision(
    pool: asyncpg.Pool,
    tenant_id: str,
    r: Any,
    include_graph_fields: bool,
) -> dict[str, Any]:
    """Wire-shape one ``FactRevision``. Compact by default (issue #177).

    Compact mode (7 fields) is the LLM-facing default: the audit story
    travels in `fact_text` + the time axes + the lineage pointer. Graph
    UUIDs and ingest-clock noise are gated behind ``include_graph_fields``
    for audit / debug callers who actually need them.

    ADR-0027: `fact_id` and `prior_revision_id` are fact-grain logical
    identifiers; both translate to `fact_<seq>`. `revision_id` is a
    revision-scope UUID — ADR-0027 deliberately keeps revision IDs as
    raw UUIDs (revisions are scoped under a fact). `episode_uuid` →
    `ep_<seq>`; entity / node uuids → `ent_<seq>`.

    Issue #227: `prior_revision_id` was previously emitted as a raw UUID
    in the compact path, breaking the short-ID symmetry promised by the
    docstring. It now routes through the fact-grain namespace so the
    LLM sees `fact_<seq>` for every chain pointer in compact mode. The
    short-ID is wire-shape-only — resolving it back through
    `gnokee_fact_provenance` will not find a fact; use
    `gnokee_fact_history` + `include_graph_fields=True` to walk
    revisions by raw UUID when audit-grade lineage is needed.
    """
    out: dict[str, Any] = {
        "revision_id": str(r.revision_id),
        "fact_id": await _encode_fact(pool, tenant_id, r.fact_id),
        "valid_at": r.valid_at.isoformat(),
        "asserted_at": r.asserted_at.isoformat(),
        "superseded_at": r.superseded_at.isoformat() if r.superseded_at is not None else None,
        "fact_text": r.fact_text,
        "prior_revision_id": await _encode_fact_optional(pool, tenant_id, r.prior_revision_id),
    }
    if include_graph_fields:
        out.update(
            {
                "fact_uuid": await _encode_fact(pool, tenant_id, r.fact_uuid),
                "episode_uuid": await _encode_ep(pool, tenant_id, r.episode_uuid),
                "created_at": r.created_at.isoformat(),
                "source_node_uuid": await _encode_ent(pool, tenant_id, r.source_node_uuid),
                "predicate": r.predicate,
                "target_node_uuid": await _encode_ent(pool, tenant_id, r.target_node_uuid),
            }
        )
    return out


async def _serialize_citations(
    pool: asyncpg.Pool,
    tenant_id: str,
    citations: dict[str, Citation],
) -> dict[str, dict[str, Any]]:
    """Serialise the per-claim bi-temporal citation envelope (ADR-0016).

    Map keys (``c1``, ``c2``, …) are preserved verbatim so the host LLM
    can back-reference entries via inline `[cN]` markers. UUIDs are
    translated to ADR-0027 short IDs (`ep_<seq>` / `fact_<seq>`);
    datetimes serialise to ISO-8601; `extracted_quote` and `source_uri`
    stay nullable in the wire envelope (v0.5 emits them as `None`
    everywhere — see ADR-0016 § "Migration strategy").
    """
    out: dict[str, dict[str, Any]] = {}
    for key, cite in citations.items():
        out[key] = {
            "episode_uuid": await _encode_ep(pool, tenant_id, cite.episode_uuid),
            "fact_uuid": await _encode_fact_optional(pool, tenant_id, cite.fact_uuid),
            "valid_at": cite.valid_at.isoformat(),
            "asserted_at": cite.asserted_at.isoformat(),
            "extracted_quote": cite.extracted_quote,
            "source_uri": cite.source_uri,
        }
    return out


def build_server(app: App) -> FastMCP:
    server = FastMCP(name="gnokee", instructions="bi-temporal memory infrastructure for personal AI")

    @server.tool(
        name="gnokee_ingest_episode",
        description=(
            "Store a new fact, event, or observation in bi-temporal memory. Call this whenever "
            "the user states something worth remembering, or when an external source delivers a "
            "new fact-bearing payload. `valid_at` = when the fact was true in the world (not the "
            "ingestion time); `asserted_at` = when you learned of it (defaults to now). Pass "
            "`our_id` (a stable consumer-supplied key, e.g. `email:msg-id`) to make ingest "
            "idempotent — re-ingest with the same key returns the existing episode with "
            "`replayed=true` instead of creating a duplicate. Returns the episode UUID, the UUIDs "
            "of any facts created, and any contradictions detected against existing facts; "
            "gnokee never auto-resolves — surface contradictions to the user."
        ),
    )
    async def gnokee_ingest_episode(
        tenant_id: Annotated[str, Field(description="Memory partition. Mandatory.")],
        content: Annotated[str, Field(description="Episode body (cleartext).")],
        valid_at: Annotated[
            str,
            Field(description="ISO-8601 UTC. When the fact was true in the world (NOT ingestion time)."),
        ],
        valid_until: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC. Optional world-time upper bound."),
        ] = None,
        asserted_at: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC. When the consumer learned of it. Defaults to now."),
        ] = None,
        our_id: Annotated[
            str | None,
            Field(
                default=None,
                description=(
                    "Stable consumer-supplied id (e.g. `email:<message-id>`). Same key + tenant = "
                    "idempotent replay; response sets `replayed=true`."
                ),
            ),
        ] = None,
        sensitive: Annotated[
            Literal["public", "private", "clinical"],
            Field(default="private", description="Sensitivity tag. Drives retrieval gating."),
        ] = "private",
        language: Annotated[
            str | None,
            Field(default=None, description="ISO 639-1; auto-detect when null."),
        ] = None,
    ) -> dict[str, Any]:  # tool body
        receipt = await ingest_episode(
            pipeline=app.ingest,
            tenant_id=tenant_id,
            content=content,
            valid_at=_require_datetime(valid_at),
            valid_until=_parse_datetime(valid_until),
            asserted_at=_require_datetime(asserted_at),
            our_id=our_id,
            sensitive=sensitive,
            language=language,
        )
        return {
            "episode_uuid": await _encode_ep(app.pool, tenant_id, receipt.episode_uuid),
            "asserted_at": receipt.asserted_at.isoformat(),
            "created_fact_uuids": [await _encode_fact(app.pool, tenant_id, u) for u in receipt.created_fact_uuids],
            "contradicts": [
                {
                    "fact_uuid": await _encode_fact(app.pool, tenant_id, c.fact_uuid),
                    "verdict": c.verdict,
                    "summary": c.summary,
                    "valid_at": c.valid_at.isoformat(),
                }
                for c in receipt.contradicts
            ],
            "replayed": receipt.replayed,
        }

    @server.tool(
        name="gnokee_recall",
        description=(
            "Bi-temporal recall. For single-question natural-language "
            "lookup; prefer `gnokee_query` for date-range filters, topic "
            "routing, or `output_shape` control. Returns fact statements + "
            "provenance handles + ADR-0016 `citations{}` keyed `c1`, "
            "`c2`, … — emit inline `[cN]` markers. `valid_at` pins "
            "world-time, `as_of` pins source-time (both default to now). "
            "Contradictions surface as refs with `verdict` (refinement/"
            "update/contradiction) and the conflicting fact's `valid_at`; "
            "gnokee NEVER picks a winner. Numeric queries also get "
            "`excerpts[]`; conversation queries get `episode_fallback[]`. "
            "Use `gnokee_fact_provenance(fact_uuid)` for the original body "
            "when a fact is contested. Episodes superseded at `as_of` "
            "move to `supersession_hints[]`. `refused: true` when zero "
            "facts + zero fallback."
        ),
    )
    async def gnokee_recall(
        tenant_id: Annotated[str, Field(description="Memory partition. Mandatory.")],
        text: Annotated[str, Field(description="Natural-language query.")],
        as_of: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC source-time pin. Defaults to now."),
        ] = None,
        valid_at: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC world-time pin. Defaults to now."),
        ] = None,
        surface_contradictions: Annotated[
            bool,
            Field(default=True, description="If true, attach contradicts[] to each FactStatement."),
        ] = True,
        max_tokens: Annotated[
            int,
            Field(
                default=200,
                description=(
                    "Response token budget. Truncates fact list when reached. "
                    f"Capped at {MAX_TOKENS_CEILING} per Q3-validated ceiling — higher "
                    "values are silently clamped (issue #183)."
                ),
            ),
        ] = 200,
        top_k: Annotated[
            int,
            Field(default=10, description="Cosine top-K candidates to consider."),
        ] = 10,
        top_k_bodies: Annotated[
            int,
            Field(
                default=DEFAULT_TOP_K_BODIES,
                description=(
                    "Max episode_fallback body rows the body lane is allowed to emit when it "
                    "fires. Stacks against body_budget; the always-emit-first guard still applies."
                ),
            ),
        ] = DEFAULT_TOP_K_BODIES,
        per_body_char_cap: Annotated[
            int,
            Field(
                default=DEFAULT_PER_BODY_CHAR_CAP,
                description=(
                    "Per-body character cap before token accounting + emission. Bounds the "
                    "body lane's token cost so the first-row guard does not consume the budget."
                ),
            ),
        ] = DEFAULT_PER_BODY_CHAR_CAP,
        include_cosine_top1: Annotated[
            bool,
            Field(
                default=False,
                description=(
                    "When true, each facts[] entry gains cosine_top1: pgvector cosine similarity "
                    "in [0,1] of the source episode vs the query. Null for Path-A fallback facts. "
                    "Telemetry only — do NOT use to reorder or suppress. Default false."
                ),
            ),
        ] = False,
        cosine_floor: Annotated[
            float | None,
            Field(
                default=None,
                ge=0.0,
                le=1.0,
                description=(
                    "ADR-0022 Option A (issue #94). When set (0.0-1.0), episodes whose cosine "
                    "similarity falls below this floor are pruned before fact fetch. Makes "
                    "refused=true observable on out-of-domain queries. Default null = no floor "
                    "(preserves current behaviour). Start around 0.3-0.4 for narrow corpora."
                ),
            ),
        ] = None,
        fact_cosine_floor: Annotated[
            float | None,
            Field(
                default=None,
                ge=0.0,
                le=1.0,
                description=(
                    "Issue #290. When set (0.0-1.0), facts whose `fact_embedding` cosine "
                    "similarity vs the query falls below this floor are pruned before the "
                    "token-budget loop. Episode-rank order is preserved for survivors. Closes "
                    "Q-X.3 grounded-but-unrelated-fact regression (e.g. renovation £-quote "
                    "surfacing on an investment query). Default null = no floor (preserves "
                    "current behaviour). Empirical value on Q41 corpus is 0.76 (ADR-0019 "
                    "§ Issue #290 verdict). Tune per corpus — bge-m3 cosines are subject-shape "
                    "sensitive."
                ),
            ),
        ] = None,
        include_telemetry: Annotated[
            bool,
            Field(
                default=False,
                description=(
                    "Issue #225 — when true, response carries the full "
                    "`recall_telemetry` dict (per-lane counters, budget "
                    "split, orphan-edge warnings). Off by default; the "
                    "8-12 field nested dict is LLM-invisible noise (~80 "
                    "tokens/turn). Enable for harness / observability "
                    "callers only."
                ),
            ),
        ] = False,
    ) -> dict[str, Any]:  # tool body
        response = await recall(
            pipeline=app.recall,
            tenant_id=tenant_id,
            text=text,
            as_of=_require_datetime(as_of),
            valid_at=_require_datetime(valid_at),
            surface_contradictions=surface_contradictions,
            max_tokens=min(max_tokens, MAX_TOKENS_CEILING),
            top_k=top_k,
            top_k_bodies=top_k_bodies,
            per_body_char_cap=per_body_char_cap,
            include_cosine_top1=include_cosine_top1,
            cosine_floor=cosine_floor,
            fact_cosine_floor=fact_cosine_floor,
        )
        facts_out: list[dict[str, Any]] = []
        for f in response.facts:
            facts_out.append(
                {
                    "text": f.text,
                    "fact_uuid": await _encode_fact(app.pool, tenant_id, f.fact_uuid),
                    "episode_uuid": await _encode_ep(app.pool, tenant_id, f.episode_uuid),
                    "valid_at": f.valid_at.isoformat(),
                    "asserted_at": f.asserted_at.isoformat(),
                    "confidence": f.confidence,
                    "cosine_top1": f.cosine_top1,
                    "fact_cosine": f.fact_cosine,
                    "contradicts": [
                        {
                            "fact_uuid": await _encode_fact(app.pool, tenant_id, c.fact_uuid),
                            "verdict": c.verdict,
                            "summary": c.summary,
                            "valid_at": c.valid_at.isoformat(),
                        }
                        for c in f.contradicts
                    ],
                }
            )
        excerpts_out: list[dict[str, Any]] = [
            {
                "episode_uuid": await _encode_ep(app.pool, tenant_id, e.episode_uuid),
                "text": e.text,
            }
            for e in response.excerpts
        ]
        supersession_hints_out: list[dict[str, Any]] = [
            {
                "superseded_uuid": await _encode_ep(app.pool, tenant_id, h.superseded_uuid),
                "current_head_uuid": await _encode_ep(app.pool, tenant_id, h.current_head_uuid),
                "superseded_at": h.superseded_at.isoformat(),
            }
            for h in response.supersession_hints
        ]
        episode_fallback_out: list[dict[str, Any]] = [
            {
                "episode_uuid": await _encode_ep(app.pool, tenant_id, r.episode_uuid),
                "text": r.text,
                "valid_at": r.valid_at.isoformat(),
                "asserted_at": r.asserted_at.isoformat(),
            }
            for r in response.episode_fallback
        ]
        encrypted_bodies_out: list[dict[str, Any]] = [
            {
                "episode_uuid": await _encode_ep(app.pool, tenant_id, eb.episode_uuid),
                "ciphertext_hex": eb.ciphertext.hex(),
                "nonce_hex": eb.nonce.hex(),
                "key_id": eb.key_id,
            }
            for eb in response.encrypted_bodies
        ]
        return {
            "facts": facts_out,
            "truncated": response.truncated,
            "candidate_count": response.candidate_count,
            "excerpts": excerpts_out,
            "supersession_hints": supersession_hints_out,
            "episode_fallback": episode_fallback_out,
            "body_used": response.body_used,
            "retrieved_episode_external_ids": list(response.retrieved_episode_external_ids),
            # Issue #225 — gated behind include_telemetry opt-in. Default-off
            # because the 8-12 field nested dict is LLM-invisible noise.
            **({"recall_telemetry": response.recall_telemetry.model_dump()} if include_telemetry else {}),
            # Issue #22 — encrypted-body episodes ride here. ciphertext +
            # nonce are bytes; emit hex strings so the JSON-RPC envelope
            # stays UTF-8 clean. Consumer decrypts via their KMS using
            # `key_id`. gnokee NEVER carries plaintext for these.
            "encrypted_bodies": encrypted_bodies_out,
            # ADR-0022 Option A (issue #94) — structural refusal signal.
            # True when the corpus returned zero facts and zero episode_fallback.
            # Consumer LLMs should render "I cannot answer from these sources"
            # when refused=True rather than synthesising an off-topic answer.
            "refused": response.refused,
            # ADR-0016 (issue #76) — per-claim bi-temporal citation envelope.
            # Additive to the existing `facts[].fact_uuid` / `episode_uuid`
            # provenance handles; both ship in v0.5. Host LLM emits inline
            # `[cN]` markers to back-reference entries.
            "citations": await _serialize_citations(app.pool, tenant_id, response.citations),
        }

    @server.tool(
        name="gnokee_fact_provenance",
        description=(
            "Fetch the full episode body and metadata behind a `fact_uuid` returned by "
            "`gnokee_recall` or `gnokee_ingest_episode`. Call when a fact is contested, carries an "
            "`update`/`contradiction` verdict, or its source text is needed for the user-facing answer."
        ),
    )
    async def gnokee_fact_provenance(
        tenant_id: Annotated[str, Field(description="Memory partition. Mandatory.")],
        fact_uuid: Annotated[
            str,
            Field(
                description=(
                    "Identifier returned in a FactStatement or IngestReceipt. Accepts either "
                    "the ADR-0027 short-ID form (`fact_<n>`) or a full UUID string."
                )
            ),
        ],
    ) -> dict[str, Any] | None:
        parsed_uuid = await _sid.parse_short_or_uuid(app.pool, tenant_id=tenant_id, value=fact_uuid)
        prov = await fact_provenance(
            pipeline=app.recall,
            tenant_id=tenant_id,
            fact_uuid=parsed_uuid,
        )
        if prov is None:
            return None
        encrypted_body_out: dict[str, Any] | None = None
        if prov.encrypted_body is not None:
            encrypted_body_out = {
                "episode_uuid": await _encode_ep(app.pool, tenant_id, prov.encrypted_body.episode_uuid),
                "ciphertext_hex": prov.encrypted_body.ciphertext.hex(),
                "nonce_hex": prov.encrypted_body.nonce.hex(),
                "key_id": prov.encrypted_body.key_id,
            }
        return {
            "fact_uuid": await _encode_fact(app.pool, tenant_id, prov.fact_uuid),
            "fact_text": prov.fact_text,
            "episode_uuid": await _encode_ep(app.pool, tenant_id, prov.episode_uuid),
            "episode_content": prov.episode_content,
            "valid_at": prov.valid_at.isoformat(),
            "valid_until": prov.valid_until.isoformat() if prov.valid_until else None,
            "asserted_at": prov.asserted_at.isoformat(),
            "asserted_until": prov.asserted_until.isoformat() if prov.asserted_until else None,
            "language": prov.language,
            "sensitive": prov.sensitive,
            # Issue #22 — populated when the episode was ingested via
            # the encrypted_body branch. ``episode_content`` is "" then;
            # consumer decrypts via their KMS using ``key_id``.
            "encrypted_body": encrypted_body_out,
        }

    @server.tool(
        name="gnokee_history_of",
        description=(
            "Return the supersession DAG for a single episode — chain of "
            "corrections from oldest predecessor to current active head, in "
            "bi-temporal order. Use when auditing how a fact changed over "
            "time, NOT to answer a current-state question (use "
            "`gnokee_recall` or `gnokee_fact_provenance` for that). "
            "`mode=compact` (default) returns one line per node with no "
            "body; `mode=verbatim` attaches body text to the newest "
            "`top_k_bodies` nodes and respects `per_body_char_cap`. "
            "`as_of` pins transaction time (chain as believed at T); "
            "`valid_at` pins world time. Encrypted episodes return "
            "`body_encrypted=true` + ciphertext envelope — gnokee NEVER "
            "returns plaintext for those. Contradictions surface inline; "
            "gnokee never auto-resolves."
        ),
    )
    async def gnokee_history_of(
        tenant_id: Annotated[str, Field(description="Memory partition. Mandatory.")],
        episode_id: Annotated[
            str,
            Field(
                description=(
                    "Anchor episode identifier — returned by `gnokee_recall.facts[].episode_uuid`, "
                    "`gnokee_ingest_episode`, or `gnokee_fact_provenance`. Accepts either the "
                    "ADR-0027 short-ID form (`ep_<n>`) or a full UUID string. Walks the "
                    "supersession DAG in both directions from this node."
                )
            ),
        ],
        mode: Annotated[
            Literal["compact", "verbatim"],
            Field(
                description=(
                    "`compact` (default) — DAG nodes carry id + bi-temporal axes + status + "
                    "rationale only; no episode body. `verbatim` — additionally attaches body "
                    "text to the newest `top_k_bodies` nodes, capped at `per_body_char_cap` "
                    "chars each."
                )
            ),
        ] = "compact",
        as_of: Annotated[
            str | None,
            Field(
                description=(
                    "Transaction-time pin (ISO-8601). 'Show the DAG as believed at T' — filters "
                    "nodes by `asserted_at <= as_of AND (asserted_until IS NULL OR asserted_until "
                    "> as_of)`. Defaults to now(UTC)."
                )
            ),
        ] = None,
        valid_at: Annotated[
            str | None,
            Field(
                description=(
                    "World-time pin (ISO-8601). Filters nodes by `valid_until IS NULL OR "
                    "valid_until > valid_at`. Rarely narrows the DAG — most useful when "
                    "episodes carry long validity ranges. Defaults to now(UTC)."
                )
            ),
        ] = None,
        max_nodes: Annotated[
            int,
            Field(
                description=(
                    "Bound on DAG node count. Matches the storage chain-depth limit. "
                    "Truncated DAGs surface `truncated=true` with `truncation_note`."
                )
            ),
        ] = HISTORY_DEFAULT_MAX_NODES,
        max_tokens: Annotated[
            int,
            Field(
                description=(
                    "Token budget for the assembled response. Oldest nodes dropped first "
                    "when over budget; head + recent predecessors preserved."
                )
            ),
        ] = HISTORY_DEFAULT_MAX_TOKENS,
        top_k_bodies: Annotated[
            int,
            Field(
                description=(
                    "Verbatim-only — number of newest nodes to attach body text to. "
                    "Older nodes stay compact. Ignored in `compact` mode."
                )
            ),
        ] = HISTORY_DEFAULT_TOP_K_BODIES,
        per_body_char_cap: Annotated[
            int,
            Field(
                description=(
                    "Verbatim-only — max characters of `content_text` per attached body. "
                    "Mirrors `gnokee_recall.per_body_char_cap`. Ignored in `compact` mode."
                )
            ),
        ] = HISTORY_DEFAULT_PER_BODY_CHAR_CAP,
    ) -> dict[str, Any]:
        parsed_uuid = await _sid.parse_short_or_uuid(app.pool, tenant_id=tenant_id, value=episode_id)
        result = await app.history.history_of(
            tenant_id=tenant_id,
            episode_id=parsed_uuid,
            mode=mode,
            as_of=_parse_datetime(as_of),
            valid_at=_parse_datetime(valid_at),
            max_nodes=max_nodes,
            max_tokens=max_tokens,
            top_k_bodies=top_k_bodies,
            per_body_char_cap=per_body_char_cap,
        )
        nodes_out: list[dict[str, Any]] = []
        for node in result.nodes:
            encrypted_body_out: dict[str, Any] | None = None
            if node.encrypted_body is not None:
                encrypted_body_out = {
                    "episode_uuid": await _encode_ep(app.pool, tenant_id, node.encrypted_body.episode_uuid),
                    "ciphertext_hex": node.encrypted_body.ciphertext.hex(),
                    "nonce_hex": node.encrypted_body.nonce.hex(),
                    "key_id": node.encrypted_body.key_id,
                }
            nodes_out.append(
                {
                    "episode_id": await _encode_ep(app.pool, tenant_id, node.episode_id),
                    "valid_at": node.valid_at.isoformat(),
                    "asserted_at": node.asserted_at.isoformat(),
                    "superseded_by": await _encode_ep_optional(app.pool, tenant_id, node.superseded_by),
                    "status": node.status,
                    "rationale": node.rationale,
                    "episode_body": node.episode_body,
                    "body_encrypted": node.body_encrypted,
                    "encrypted_body": encrypted_body_out,
                }
            )
        edges_out: list[dict[str, Any]] = [
            {
                "from_id": await _encode_ep(app.pool, tenant_id, edge.from_id),
                "to_id": await _encode_ep(app.pool, tenant_id, edge.to_id),
            }
            for edge in result.edges
        ]
        return {
            "nodes": nodes_out,
            "edges": edges_out,
            "root": await _encode_ep(app.pool, tenant_id, result.root),
            "head": await _encode_ep(app.pool, tenant_id, result.head),
            "truncated": result.truncated,
            "truncation_note": result.truncation_note,
            "cycle_detected": result.cycle_detected,
        }

    @server.tool(
        name="gnokee_fact_history",
        description=(
            "Bi-temporal revision history of a single FACT — append-only "
            "audit log per ADR-0014. Distinct from `gnokee_history_of` "
            "(episode-grain DAG); this is fact-grain. Accepts either "
            "`fact_id` (logical) or `fact_uuid` (Graphiti edge) — "
            "auto-resolves. `as_of` pins transaction time. Returns a flat "
            "array sorted DESC by `asserted_at` (newest first); each "
            "revision carries `superseded_at` (null = still open) joined "
            "from the Graphiti edge. Default response is compact (7 "
            "fields); set `include_graph_fields=true` to add the Graphiti "
            "edge UUIDs + ingest timestamp. Tombstones DISALLOWED."
        ),
    )
    async def gnokee_fact_history(
        tenant_id: Annotated[str, Field(description="Memory partition. Mandatory.")],
        fact_id: Annotated[
            str,
            Field(
                description=(
                    "Fact identifier. Accepts either the ADR-0027 short-ID form (`fact_<n>`) "
                    "or a full UUID string. Resolves logical `fact_id` (stable across "
                    "supersession chains) or Graphiti `fact_uuid` (per-edge); the pipeline "
                    "resolves fact_uuid → fact_id automatically."
                )
            ),
        ],
        as_of: Annotated[
            str | None,
            Field(
                description=(
                    "Transaction-time pin (ISO-8601). 'Revisions as believed at T' — "
                    "filters by `asserted_at <= as_of`. Defaults to now(UTC)."
                )
            ),
        ] = None,
        include_graph_fields: Annotated[
            bool,
            Field(
                description=(
                    "Default False — compact mode emits `revision_id`, `fact_id`, "
                    "`valid_at`, `asserted_at`, `superseded_at`, `fact_text`, "
                    "`prior_revision_id`. Set True to additionally emit "
                    "`fact_uuid`, `episode_uuid`, `created_at`, `source_node_uuid`, "
                    "`predicate`, `target_node_uuid` for audit / graph-debug use."
                )
            ),
        ] = False,
        max_revisions: Annotated[
            int,
            Field(
                description=(
                    f"Cap on returned revisions. Newest kept; older truncated. Default {FACT_HISTORY_MAX_REVISIONS}."
                )
            ),
        ] = FACT_HISTORY_MAX_REVISIONS,
    ) -> dict[str, Any]:
        parsed_uuid = await _sid.parse_short_or_uuid(app.pool, tenant_id=tenant_id, value=fact_id)
        result = await app.fact_history.fact_history(
            tenant_id=tenant_id,
            fact_id=parsed_uuid,
            as_of=_parse_datetime(as_of),
            max_revisions=max_revisions,
        )
        revisions_out: list[dict[str, Any]] = [
            await _serialize_fact_revision(app.pool, tenant_id, r, include_graph_fields) for r in result.revisions
        ]
        return {
            "fact_id": await _encode_fact(app.pool, tenant_id, result.fact_id),
            "revisions": revisions_out,
            "truncated": result.truncated,
            "truncation_note": result.truncation_note,
        }

    @server.tool(
        name="gnokee_lab_query",
        description=(
            "Typed clinical-lab read against `lab_record` (ADR-0009). Use "
            "for numeric analyte values, trends, or aggregates that "
            "`gnokee_recall`'s narrative facts strip away. Op semantics: "
            "`latest` / `history` return rows; `min` / `max` / `avg` / "
            "`count` return a numeric `scalar`; `abnormal` returns rows "
            "whose `abnormal_flag` is set. Bi-temporal half-pairs apply "
            "(`as_of` source-time, `valid_at` world-time); `since`/`until` "
            "bound the world-time sample window. `analyte` required except "
            "for `abnormal`. Each row carries `episode_uuid` provenance "
            "plus an ADR-0016 `citations{}` entry keyed `c1`, `c2`, … in "
            "`rows` order — emit inline `[cN]` markers."
        ),
    )
    async def gnokee_lab_query(
        tenant_id: Annotated[str, Field(description="Memory partition. Mandatory.")],
        op: Annotated[
            Literal["latest", "history", "min", "max", "avg", "count", "abnormal"],
            Field(description="latest|history|min|max|avg|count|abnormal."),
        ],
        analyte: Annotated[
            str | None,
            Field(
                default=None,
                description=(
                    'Analyte name, e.g. "Potassium", "Hemoglobin". Required for '
                    "every op except `abnormal` (where it acts as an optional "
                    "narrowing filter)."
                ),
            ),
        ] = None,
        since: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC. Lower-bound on sample valid_at (inclusive)."),
        ] = None,
        until: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC. Upper-bound on sample valid_at (exclusive)."),
        ] = None,
        as_of: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC source-time pin. Defaults to now."),
        ] = None,
        valid_at: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC world-time pin. Defaults to now."),
        ] = None,
        limit: Annotated[
            int,
            Field(default=DEFAULT_HISTORY_LIMIT, description="Row cap for op=history. Ignored for scalar ops."),
        ] = DEFAULT_HISTORY_LIMIT,
    ) -> dict[str, Any]:  # tool body
        response = await lab_query(
            pipeline=app.lab_query,
            tenant_id=tenant_id,
            analyte=analyte,
            op=op,
            since=_parse_datetime(since),
            until=_parse_datetime(until),
            as_of=_require_datetime(as_of),
            valid_at=_require_datetime(valid_at),
            limit=limit,
        )
        rows_out: list[dict[str, Any]] = []
        for r in response.rows:
            rows_out.append(
                {
                    "episode_uuid": await _encode_ep(app.pool, tenant_id, r.episode_uuid),
                    "analyte": r.analyte,
                    "value_numeric": str(r.value_numeric) if r.value_numeric is not None else None,
                    "value_text": r.value_text,
                    "unit": r.unit,
                    "ref_range_low": str(r.ref_range_low) if r.ref_range_low is not None else None,
                    "ref_range_high": str(r.ref_range_high) if r.ref_range_high is not None else None,
                    "abnormal_flag": r.abnormal_flag,
                    "valid_at": r.valid_at.isoformat(),
                    "asserted_at": r.asserted_at.isoformat(),
                }
            )
        return {
            "op": response.op,
            "rows": rows_out,
            "scalar": str(response.scalar) if response.scalar is not None else None,
            "count": response.count,
            # ADR-0016 (issue #76) — per-claim bi-temporal citation envelope.
            # Map keyed `c1`, `c2`, … in `rows` order. Empty for scalar ops.
            "citations": await _serialize_citations(app.pool, tenant_id, response.citations),
        }

    @server.tool(
        name="gnokee_med_query",
        description=(
            "Typed medication-history read against `med_record` (ADR-0010). "
            "Use for current meds, dose history, allergies, or drug switches "
            "that `gnokee_recall` may preserve names for but strip dates and "
            "dosages from. Op semantics: `active` returns one row per drug "
            "whose latest visible event is not a stop/allergy (pass "
            "`valid_at` to pin a world-time); `history` returns all events "
            "for `drug_name` bounded by `since`/`until`; `allergies` returns "
            "allergy rows; `switches` returns drug-switch events. "
            "Bi-temporal half-pairs apply (`as_of` source-time, `valid_at` "
            "world-time). Each row carries `episode_uuid` provenance plus an "
            "ADR-0016 `citations{}` entry keyed `c1`, `c2`, … in `rows` "
            "order — emit inline `[cN]` markers."
        ),
    )
    async def gnokee_med_query(
        tenant_id: Annotated[str, Field(description="Memory partition. Mandatory.")],
        op: Annotated[
            Literal["active", "history", "allergies", "switches"],
            Field(description="active|history|allergies|switches."),
        ],
        drug_name: Annotated[
            str | None,
            Field(default=None, description="Drug name. Required for op=history; optional filter for op=active."),
        ] = None,
        since: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC. Lower-bound on event valid_at (inclusive)."),
        ] = None,
        until: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC. Upper-bound on event valid_at (exclusive)."),
        ] = None,
        as_of: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC source-time pin. Defaults to now."),
        ] = None,
        valid_at: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC world-time pin. Defaults to now."),
        ] = None,
        limit: Annotated[
            int,
            Field(default=MED_HISTORY_LIMIT, description="Row cap. Ignored for op=active (one per drug)."),
        ] = MED_HISTORY_LIMIT,
    ) -> dict[str, Any]:  # tool body
        response = await med_query(
            pipeline=app.med_query,
            tenant_id=tenant_id,
            op=op,
            drug_name=drug_name,
            since=_parse_datetime(since),
            until=_parse_datetime(until),
            as_of=_require_datetime(as_of),
            valid_at=_require_datetime(valid_at),
            limit=limit,
        )
        med_rows_out: list[dict[str, Any]] = []
        for r in response.rows:
            med_rows_out.append(
                {
                    "episode_uuid": await _encode_ep(app.pool, tenant_id, r.episode_uuid),
                    "drug_name": r.drug_name,
                    "drug_class": r.drug_class,
                    "dose_value": str(r.dose_value) if r.dose_value is not None else None,
                    "dose_unit": r.dose_unit,
                    "frequency": r.frequency,
                    "route": r.route,
                    "event_kind": r.event_kind,
                    "reason": r.reason,
                    "valid_at": r.valid_at.isoformat(),
                    "asserted_at": r.asserted_at.isoformat(),
                }
            )
        return {
            "op": response.op,
            "rows": med_rows_out,
            "count": response.count,
            # ADR-0016 (issue #76) — per-claim bi-temporal citation envelope.
            # Map keyed `c1`, `c2`, … in `rows` order.
            "citations": await _serialize_citations(app.pool, tenant_id, response.citations),
        }

    # ── ADR-0013 / issue #72 — gnokee_query declarative envelope ────────────
    # Isolated registration block. See `src/gnokee/query.py` for the
    # orchestrator; this block only carries the FastMCP tool wrapper +
    # envelope -> dict serialiser.

    @server.tool(
        name="gnokee_query",
        description=(
            "Declarative envelope read (ADR-0013). Prefer over "
            "`gnokee_recall` for date-range filters, topic routing, or "
            "`output_shape=fact`. Single call: `ask` + range "
            "(`valid_at`, `asserted_at`) + topics + budget "
            "(`max_episodes`, `max_tokens`, `confidence_floor`). "
            "`tenant_id` REQUIRED. Returns `provenance`, ADR-0016 "
            "`citations{}` keyed `c1`, `c2`, …, ADR-0019 recency-proxy "
            "`confidence` (NOT calibrated), and flat `contradictions[]` "
            "(ADR-0008, never auto-resolved). `topics` (`general`, "
            "`clinical.lab`, `clinical.med`) routes pipelines. "
            "`output_shape` reshapes lanes (fact | episode | mixed). "
            "`created_at` is NEVER a filter axis. `value` is "
            "RESERVED-but-`null` — gnokee never hosts an LLM. Call "
            "`gnokee_fact_provenance(fact_uuid)` on any "
            "`provenance[].fact_uuid` for the source episode body. Emit "
            "inline `[c1]`, `[c2]`, … markers when stating claims."
        ),
    )
    async def gnokee_query(
        tenant_id: Annotated[str, Field(description="Memory partition. Mandatory.")],
        ask: Annotated[str, Field(description="Natural-language question.")],
        valid_at_gte: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC. Lower bound on fact `valid_at`."),
        ] = None,
        valid_at_lte: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC. Upper bound on fact `valid_at`."),
        ] = None,
        asserted_at_gte: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC. Lower bound on fact `asserted_at`."),
        ] = None,
        asserted_at_lte: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC. Upper bound on fact `asserted_at`."),
        ] = None,
        topics: Annotated[
            list[str] | None,
            Field(
                default=None,
                description=(
                    "Routing hint. v0.5 vocabulary: general, clinical.lab, "
                    "clinical.med. Unknown entries surface in telemetry."
                ),
            ),
        ] = None,
        # Issue #183 — `tenant_scope` removed from the MCP surface. The
        # underlying `QueryEnvelopeFilter.tenant_scope` still validates and
        # rejects `cross` for direct library callers, but exposing a
        # single-value `Literal["self"]` enum at the MCP boundary added
        # noise to every tool description and burned a parameter slot in
        # LLM tool-call prompts for zero behavioural variation.
        output_shape: Annotated[
            Literal["fact", "episode", "mixed"],
            Field(default="mixed", description="fact | episode | mixed."),
        ] = "mixed",
        max_episodes: Annotated[
            int,
            Field(
                default=DEFAULT_MAX_EPISODES,
                description="Provenance list cap. Applied after all filters.",
            ),
        ] = DEFAULT_MAX_EPISODES,
        max_tokens: Annotated[
            int,
            Field(
                default=DEFAULT_MAX_TOKENS,
                description=(
                    f"Response token budget. Maps to recall(max_tokens). Capped at "
                    f"{MAX_TOKENS_CEILING} per Q3-validated ceiling (issue #183)."
                ),
            ),
        ] = DEFAULT_MAX_TOKENS,
        confidence_floor: Annotated[
            float,
            Field(
                default=0.0,
                ge=0.0,
                le=1.0,
                description=(
                    "Minimum age-credibility cutoff. ADR-0019 recency proxy "
                    "(NOT a calibrated probability). Default 0.0."
                ),
            ),
        ] = 0.0,
        as_of: Annotated[
            str | None,
            Field(
                default=None,
                description=(
                    "ISO-8601 UTC source-tx-time pin. Defaults to now. "
                    "When `output_shape=fact`, each fact's `fact_text` + "
                    "`valid_at` come from the latest fact_revision row "
                    "asserted on or before `as_of` (ADR-0014). Facts with "
                    "no revision at `as_of` drop out."
                ),
            ),
        ] = None,
        include_telemetry: Annotated[
            bool,
            Field(
                default=False,
                description=(
                    "Issue #225 — when true, response carries the full "
                    "`query_telemetry` (per-envelope-axis counters + the "
                    "nested `recall_telemetry`). Off by default; the dict "
                    "is LLM-invisible noise. Enable for harness / "
                    "observability callers only."
                ),
            ),
        ] = False,
    ) -> dict[str, Any]:
        # Build the Pydantic envelope from the flat-keyword MCP shape so
        # the JSON-Schema validation runs at the boundary. Bad envelopes
        # raise ValidationError → MCP layer surfaces a structured error.
        valid_range = (
            DateRange(gte=_parse_datetime(valid_at_gte), lte=_parse_datetime(valid_at_lte))
            if (valid_at_gte is not None or valid_at_lte is not None)
            else None
        )
        asserted_range = (
            DateRange(
                gte=_parse_datetime(asserted_at_gte),
                lte=_parse_datetime(asserted_at_lte),
            )
            if (asserted_at_gte is not None or asserted_at_lte is not None)
            else None
        )
        envelope = QueryEnvelope(
            ask=ask,
            filter=QueryEnvelopeFilter(
                tenant_id=tenant_id,
                valid_at_range=valid_range,
                asserted_at_range=asserted_range,
                topics=topics or [],
                # tenant_scope defaults to "self" at the model layer (issue #183).
            ),
            output_shape=output_shape,
            budget=QueryEnvelopeBudget(
                max_episodes=max_episodes,
                max_tokens=min(max_tokens, MAX_TOKENS_CEILING),
            ),
            confidence_floor=confidence_floor,
        )
        response: QueryResponse = await run_gnokee_query(
            recall_pipeline=app.recall,
            lab_pipeline=app.lab_query,
            med_pipeline=app.med_query,
            envelope=envelope,
            pool=app.pool,
            fact_revisions=app.fact_revision_store,
            as_of=_parse_datetime(as_of),
        )
        return await _serialize_query_response(
            app.pool,
            tenant_id,
            response,
            include_telemetry=include_telemetry,
        )

    # ──────────────────────────────────────────────────────────────────────
    # gnokee_wiki_export — ADR-0015 / issue #74. Isolated registration
    # block; no shared mutable state with the tools above. The only
    # construction-site coupling is `app.wiki_export` from bootstrap.py.
    # ──────────────────────────────────────────────────────────────────────

    @server.tool(
        name="gnokee_wiki_export",
        description=(
            "Export a tenant's memory as a markdown wiki (ADR-0015). "
            "Returns synthetic files (`index.md`, `log.md`, "
            "`entities/<slug>.md`) templated from the bi-temporal store — "
            "no LLM synthesis, no new storage. `scope='self'` returns "
            "active facts; `scope='full'` adds a History section per "
            "entity for superseded facts. `as_of` pins source-tx-time "
            "(default: now). `valid_at` pins world-time (default: same "
            "as `as_of`) — episodes/facts whose `valid_at` is later than "
            "the pin are excluded. Output is markdown bytes in the MCP "
            "response — gnokee NEVER writes to a consumer filesystem on "
            "its own. Slugs are human-readable with stable UUID "
            "disambiguation. Cached per-tenant write-clock. First 200 "
            "episodes per `log.md`."
        ),
    )
    async def gnokee_wiki_export(
        tenant_id: Annotated[str, Field(description="Memory partition. Mandatory.")],
        scope: Annotated[
            Literal["self", "full"],
            Field(
                default="self",
                description=(
                    "`self` = active facts only (Current section per entity). "
                    "`full` = include superseded facts (History section per entity)."
                ),
            ),
        ] = "self",
        as_of: Annotated[
            str | None,
            Field(
                default=None,
                description=(
                    "ISO-8601 UTC source-tx-time pin. Defaults to now. When "
                    "older than the latest write, v0.5 falls back to the "
                    "latest snapshot + emits a header note in `index.md`."
                ),
            ),
        ] = None,
        valid_at: Annotated[
            str | None,
            Field(
                default=None,
                description=(
                    "ISO-8601 UTC world-time pin (ADR-0004 axis-1). Filters "
                    "to episodes whose `valid_at` is at or before this "
                    "instant — episodes that happen in the world later than "
                    "the pin are excluded from the export. Defaults to the "
                    "effective `as_of` so callers that pass only `as_of` keep "
                    "the historical 'anchored on as_of for both axes' behaviour."
                ),
            ),
        ] = None,
    ) -> dict[str, Any]:  # tool body
        response = await wiki_export(
            pipeline=app.wiki_export,
            tenant_id=tenant_id,
            scope=scope,
            as_of=_parse_datetime(as_of),
            valid_at=_parse_datetime(valid_at),
        )
        return {
            "files": [{"path": f.path, "content": f.content} for f in response.files],
            "generated_at": response.generated_at.isoformat(),
            "tenant_id": response.tenant_id,
        }

    # ── ADR-0026 / issue #130 — forget pipeline (destructive; registered last) ──

    @server.tool(
        name="gnokee_forget_episode",
        description=(
            "Hard-delete a single episode from gnokee storage. Refuses with "
            "'cannot_forget_chain_node' if the episode is in a supersession "
            "chain unless cascade=True. Writes a forget_audit row in the "
            "gnokee_maintenance schema that survives tenant deletion. When "
            "the receipt's affected_key_ids is non-empty, the consumer MUST "
            "destroy those DEKs in their KMS to complete cryptographic "
            "erasure (gnokee never holds keys)."
        ),
    )
    async def gnokee_forget_episode(
        tenant_id: Annotated[str, Field(description="Memory partition. Mandatory.")],
        episode_uuid: Annotated[
            str,
            Field(
                description=(
                    "Episode identifier to hard-delete. Accepts either the ADR-0027 short-ID "
                    "form (`ep_<n>`) or a full UUID string."
                )
            ),
        ],
        reason: Annotated[
            str,
            Field(
                description=(
                    "Required. Category label only — DO NOT include personal data "
                    "(names, identifiers, diagnoses). Persisted in forget_audit which survives "
                    "tenant deletion."
                ),
            ),
        ],
        cascade: Annotated[
            bool,
            Field(
                default=False,
                description=(
                    "If True, recursively deletes this episode AND all supersession descendants. "
                    "Default False. DO NOT set True without explicit operator approval — permanent "
                    "and irreversible."
                ),
            ),
        ] = False,
        actor: Annotated[
            str | None,
            Field(default=None, description="Optional actor identifier for the audit trail."),
        ] = None,
    ) -> dict[str, Any]:
        parsed_uuid = await _sid.parse_short_or_uuid(app.pool, tenant_id=tenant_id, value=episode_uuid)
        spec = ForgetEpisodeIn(
            tenant_id=tenant_id,
            episode_uuid=parsed_uuid,
            cascade=cascade,
            reason=reason,
            actor=actor,
        )
        try:
            detail = await forget_episode(
                app,
                tenant_id=spec.tenant_id,
                episode_uuid=spec.episode_uuid,
                cascade=spec.cascade,
                reason=spec.reason,
                actor=spec.actor,
            )
        except CannotForgetChainNode as exc:
            return {
                "error": "cannot_forget_chain_node",
                "descendant_count": exc.descendant_count,
                "deepest_descendant_uuid": exc.deepest_descendant_uuid,
                "hint": (
                    "Use gnokee_history_of(uuid=<target>) to inspect the chain. "
                    "Resubmit with cascade=True only after explicit operator approval — "
                    "this is permanent."
                ),
            }
        except ForgetNeo4jPartial as exc:
            return {
                "error": "forget_neo4j_partial",
                "audit_id": exc.audit_id,
                # Issue #234 — operator-side recovery only. No MCP tool exposes
                # `resume_forget` (matches v0.8.0 design: forget retry is
                # CLI/Python, not consumer-LLM). Point the consumer at both
                # actionable surfaces so they can escalate to an operator.
                "hint": (
                    "Operator recovery required. Run `gnokee forget resume "
                    f"--audit-id {exc.audit_id}` (CLI) or call "
                    "`gnokee.maintenance.resume_forget(tenant_id, audit_id)` "
                    "(Python). No MCP tool re-runs the Neo4j sweep."
                ),
            }
        return ForgetReceipt.model_validate(detail.model_dump(include=set(ForgetReceipt.model_fields))).model_dump(
            mode="json"
        )

    @server.tool(
        name="gnokee_forget_tenant",
        description=(
            "Hard-delete an entire tenant. Two-call ceremony: dry_run defaults to True and returns "
            "a planned receipt with no writes. Caller MUST issue a SECOND call with dry_run=False to "
            "actually destroy. Affected key_ids surface on the receipt — the consumer destroys those "
            "DEKs in their KMS."
        ),
    )
    async def gnokee_forget_tenant(
        tenant_id: Annotated[str, Field(description="Memory partition to hard-delete. Mandatory.")],
        reason: Annotated[
            str,
            Field(
                description=(
                    "Required. Category label only — DO NOT include personal data. "
                    "Persisted in forget_audit which survives tenant deletion."
                ),
            ),
        ],
        dry_run: Annotated[
            bool,
            Field(
                default=True,
                description=(
                    "DEFAULT TRUE. dry_run=True returns a planned receipt with no writes. "
                    "Issue a SECOND call with dry_run=False to actually destroy the tenant."
                ),
            ),
        ] = True,
        actor: Annotated[
            str | None,
            Field(default=None, description="Optional actor identifier for the audit trail."),
        ] = None,
    ) -> dict[str, Any]:
        spec = ForgetTenantIn(
            tenant_id=tenant_id,
            dry_run=dry_run,
            reason=reason,
            actor=actor,
        )
        try:
            detail = await forget_tenant(
                app,
                tenant_id=spec.tenant_id,
                dry_run=spec.dry_run,
                reason=spec.reason,
                actor=spec.actor,
            )
        except ForgetNeo4jPartial as exc:
            return {
                "error": "forget_neo4j_partial",
                "audit_id": exc.audit_id,
                # Issue #234 — operator-side recovery only. No MCP tool exposes
                # `resume_forget` (matches v0.8.0 design: forget retry is
                # CLI/Python, not consumer-LLM). Point the consumer at both
                # actionable surfaces so they can escalate to an operator.
                "hint": (
                    "Operator recovery required. Run `gnokee forget resume "
                    f"--audit-id {exc.audit_id}` (CLI) or call "
                    "`gnokee.maintenance.resume_forget(tenant_id, audit_id)` "
                    "(Python). No MCP tool re-runs the Neo4j sweep."
                ),
            }
        return ForgetReceipt.model_validate(detail.model_dump(include=set(ForgetReceipt.model_fields))).model_dump(
            mode="json"
        )

    return server


async def _serialize_query_response(
    pool: asyncpg.Pool,
    tenant_id: str,
    response: QueryResponse,
    *,
    include_telemetry: bool = False,
) -> dict[str, Any]:
    """Serialise `QueryResponse` to the MCP wire envelope.

    Kept as a free helper so the wire shape is co-located with the
    citation serialiser. UUIDs are translated to ADR-0027 short IDs
    (`ep_<seq>` / `fact_<seq>`); datetimes → ISO-8601; the citation
    map is delegated to `_serialize_citations` to keep the `[cN]`
    ordering invariant in a single place.

    Issue #225 — `query_telemetry` is gated behind ``include_telemetry``;
    the 11-field nested dict is LLM-invisible noise on the default
    path. Harness / observability callers opt in.
    """
    telemetry = response.query_telemetry
    provenance_out: list[dict[str, Any]] = []
    for p in response.provenance:
        provenance_out.append(
            {
                "episode_uuid": await _encode_ep(pool, tenant_id, p.episode_uuid),
                "fact_uuid": await _encode_fact_optional(pool, tenant_id, p.fact_uuid),
                "valid_at": p.valid_at.isoformat(),
                "asserted_at": p.asserted_at.isoformat(),
                "source_uri": p.source_uri,
                "score": p.score,
            }
        )
    contradictions_out: list[dict[str, Any]] = []
    for c in response.contradictions:
        contradictions_out.append(
            {
                "episode_a": await _encode_ep(pool, tenant_id, c.episode_a),
                "episode_b": await _encode_ep(pool, tenant_id, c.episode_b),
                "fact_a": await _encode_fact(pool, tenant_id, c.fact_a),
                "fact_b": await _encode_fact(pool, tenant_id, c.fact_b),
                "verdict": c.verdict,
                "axis": c.axis,
                "summary": c.summary,
            }
        )
    envelope: dict[str, Any] = {
        # ADR-0013 § value field — `null` in v0.5 (no LLM hosting). Kept
        # on the wire so future hosts can populate it without a schema bump.
        "value": response.value,
        "provenance": provenance_out,
        "confidence": response.confidence,
        "contradictions": contradictions_out,
        "citations": await _serialize_citations(pool, tenant_id, response.citations),
    }
    if include_telemetry:
        envelope["query_telemetry"] = {
            "topic": telemetry.topic,
            "max_episodes": telemetry.max_episodes,
            "max_tokens": telemetry.max_tokens,
            "facts_considered": telemetry.facts_considered,
            "facts_after_floor": telemetry.facts_after_floor,
            "facts_after_range": telemetry.facts_after_range,
            "confidence_floor": telemetry.confidence_floor,
            "recall_telemetry": telemetry.recall_telemetry.model_dump(),
            "post_recall_filter": telemetry.post_recall_filter,
            "unknown_topics": list(telemetry.unknown_topics),
            "clinical_lab_rows": telemetry.clinical_lab_rows,
            "clinical_med_rows": telemetry.clinical_med_rows,
        }
    return envelope


async def _async_main() -> None:
    settings = Settings()
    app = await build_app(settings)
    server = build_server(app)
    transport: Literal["stdio", "streamable-http"] = "streamable-http" if settings.mcp_http else "stdio"
    try:
        if transport == "streamable-http":
            await server.run_streamable_http_async()
        else:
            await server.run_stdio_async()
    finally:
        await shutdown_app(app)


def _cli_main() -> None:
    from gnokee.logging import configure as configure_logging

    configure_logging(os.environ.get("GNOKEE_LOG_LEVEL", "info"))
    try:
        asyncio.run(_async_main())
    except (GnokeeError, KeyboardInterrupt) as exc:
        log.error("gnokee mcp exit: %s", exc)


__all__ = ["_cli_main", "build_server"]


if __name__ == "__main__":
    _cli_main()
