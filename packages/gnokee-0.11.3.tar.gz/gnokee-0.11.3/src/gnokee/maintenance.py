"""src/gnokee/maintenance.py — Periodic maintenance helpers for gnokee operators.

Provides `run_deferred_extraction` — a backfill helper that lifts narrative
facts for episodes ingested with `extract=False` (lite mode, issue #16 item 1).

Design: single-threaded batched loop. Concurrency is out of scope for v0.3
(see issue #47). The operator drives scheduling via cron / pg_cron / any
external task runner; gnokee does NOT host a scheduler.

Two-store coordination: Graphiti write first (Stage 4), then Postgres update
(mark_extraction_complete). If the Postgres update fails after a successful
Graphiti write the episode will be re-processed on the next run — idempotency
comes from Graphiti's dedup (same `name` + `group_id`) and from the WHERE
clause in `mark_extraction_complete` (extraction_deferred=TRUE guard).

RLS: the helper sets `app.current_tenant` GUC on every acquired connection
before any SELECT or UPDATE so Postgres row-level security policies (when
enabled) enforce tenant isolation. The GUC is set inside the connection
scope and does not persist beyond the connection's lifetime.

exports: run_deferred_extraction | resume_ingest | resume_forget | prune_forget_audit | backfill_fact_revisions | DeferredExtractionReport | ExtractionFailure | PruneForgetAuditReport | PruneRefused | BackfillFactRevisionsReport
used_by: operator scripts / cron / noggin maintenance task
rules:   tenant_id mandatory; reference_time = valid_at (NOT now()); never
         re-run Stages 1-3 (embed, lang detect, clinical parsers already done);
         leave extraction_deferred=TRUE on failure (next run retries)
agent:   claude-sonnet-4-6 | 2026-05-09 | issue #47 v0.3
         claude-opus-4-7 | 2026-05-09 | issue #51 read content_text (content column dropped)
         claude-opus-4-7 | 2026-05-16 | issue #122 ADR-0024 resume_ingest
         claude-sonnet-4-6 | 2026-05-16 | ADR-0026 §7 resume_forget
         claude-opus-4-7 | 2026-05-17 | issue #169 backfill_fact_revisions (Stage 6c crash skew)
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field, replace
from datetime import datetime
from typing import TYPE_CHECKING, Any
from uuid import UUID

import asyncpg

if TYPE_CHECKING:
    from gnokee.bootstrap import App
    from gnokee.ingest import IngestPipeline
    from gnokee.models import ForgetReceiptDetail

from gnokee.config import utc_now
from gnokee.contradiction import detect_for_facts
from gnokee.errors import GraphStoreError, ValidationError, VectorStoreError
from gnokee.extract import augment_for_extraction
from gnokee.llm import OpenAIClient
from gnokee.models import EpisodeIn, IngestReceipt
from gnokee.storage.contradictions import ContradictionStore
from gnokee.storage.fact_revision import FactRevisionRow, FactRevisionStore
from gnokee.storage.fact_revision_stage import write_fact_revisions_for_edges
from gnokee.storage.graph import EdgeInWindow, GraphitiStore
from gnokee.storage.journal import IngestJournalError
from gnokee.storage.metadata import EpisodeMetadataRow, MetadataStore

log = logging.getLogger(__name__)

_MAX_NAME_LEN = 80


def _episode_name(content: str) -> str:
    head = content.strip().splitlines()[0] if content.strip() else "episode"
    if len(head) <= _MAX_NAME_LEN:
        return head
    return head[: _MAX_NAME_LEN - 1].rstrip() + "…"


@dataclass(frozen=True)
class ExtractionFailure:
    """Record of one failed episode in a deferred-extraction run."""

    episode_uuid: UUID
    tenant_id: str
    error: str


@dataclass
class DeferredExtractionReport:
    """Summary returned by `run_deferred_extraction`.

    ``fact_revision_skew_count`` mirrors the ingest-path
    ``IngestTelemetry.fact_revision_skew_count`` (issue #179): counts
    edges whose Stage 6c append-only ``fact_revision`` row failed to
    write. Non-zero values indicate ``gnokee_fact_history`` will return
    incomplete history for those facts until the skew is reconciled.
    """

    processed: int = 0
    succeeded: int = 0
    failed: list[ExtractionFailure] = field(default_factory=list)
    elapsed_ms: int = 0
    fact_revision_skew_count: int = 0


async def run_deferred_extraction(
    tenant_id: str,
    *,
    pool: asyncpg.Pool,
    graph: GraphitiStore,
    metadata: MetadataStore,
    contradictions: ContradictionStore,
    llm: OpenAIClient | None = None,
    contradiction_enabled: bool = True,
    since: datetime | None = None,
    batch_size: int = 50,
    max_episodes: int | None = None,
    fact_revisions: FactRevisionStore | None = None,
) -> DeferredExtractionReport:
    """Back-fill Graphiti narrative extraction for lite-ingest episodes.

    Args:
        tenant_id: Mandatory. Raises ValidationError when empty/missing.
        pool: asyncpg connection pool.
        graph: GraphitiStore wrapping the Graphiti client.
        metadata: MetadataStore for episode_metadata reads + updates.
        contradictions: ContradictionStore for writing contradiction rows.
        llm: OpenAIClient for contradiction detection. When None or
            contradiction_enabled=False, Stage 5 contradiction detection
            is skipped (consistent with full-mode ingest with llm=None).
        contradiction_enabled: Toggle contradiction detection independently
            of llm presence. Mirrors IngestPipeline.contradiction_enabled.
        since: When set, restricts to episodes with valid_at >= since.
            Useful for operators running a targeted backfill over a
            specific time window (e.g. "last 7 days of Pulse telemetry").
        batch_size: Episodes per batch. Default 50.
        max_episodes: Hard cap on total episodes processed this run.
            None = no cap (process all deferred). Useful for rate-limited
            operators who want to spread cost over multiple scheduler ticks.
        fact_revisions: FactRevisionStore for Stage 6c append-only
            history-shadow writes (issue #179 / ADR-0014). When None,
            Stage 6c is skipped (preserves pre-#179 behaviour for
            callers that don't yet thread the store — though that path
            silently breaks ``gnokee_fact_history`` on back-filled
            episodes and emits a one-time WARNING per call). The
            standard caller threads ``app.fact_revision_store``.

    Returns:
        DeferredExtractionReport with counts and per-failure records.

    Raises:
        ValidationError: tenant_id is empty.

    RLS note: `app.current_tenant` GUC is SET on every acquired connection
    before any query. This is defence-in-depth for Postgres RLS policies.
    The WHERE clause always includes `tenant_id = $1` as primary isolation.
    """
    if not tenant_id or not tenant_id.strip():
        raise ValidationError("run_deferred_extraction: tenant_id is required and must be non-empty")

    if fact_revisions is None:
        log.warning(
            "run_deferred_extraction: fact_revisions=None — Stage 6c append-only "
            "history-shadow writes will be SKIPPED for tenant=%s. "
            "gnokee_fact_history will return empty for back-filled facts on this "
            "tenant. Pass app.fact_revision_store to enable (issue #179).",
            tenant_id,
        )

    report = DeferredExtractionReport()
    t0 = time.monotonic()

    remaining = max_episodes  # None = unlimited

    while True:
        fetch_limit = batch_size
        if remaining is not None:
            fetch_limit = min(batch_size, remaining)

        async with pool.acquire() as conn:
            # RLS GUC: defence-in-depth tenant isolation. Issue #157:
            # `set_config(..., is_local=true)` scopes to the current
            # transaction so the GUC drops cleanly on commit and does NOT
            # leak to the next coroutine that reuses this pool connection.
            # The pre-#157 `is_local=false` form persisted past pool
            # checkin and leaked tenant context cross-tenant.
            async with conn.transaction():
                await conn.execute(
                    "SELECT set_config('app.current_tenant', $1, true)",
                    tenant_id,
                )
                batch = await metadata.fetch_deferred(
                    conn=conn,
                    tenant_id=tenant_id,
                    since=since,
                    limit=fetch_limit,
                )

        if not batch:
            break

        report.processed += len(batch)

        for row in batch:
            success = await _extract_one(
                row=row,
                graph=graph,
                pool=pool,
                metadata=metadata,
                contradictions=contradictions,
                llm=llm,
                contradiction_enabled=contradiction_enabled,
                fact_revisions=fact_revisions,
                report=report,
            )
            if success:
                report.succeeded += 1

        if remaining is not None:
            remaining -= len(batch)
            if remaining <= 0:
                break

        # If the batch was smaller than requested, we've exhausted the
        # deferred set (or the since-filter drained it). Stop.
        if len(batch) < fetch_limit:
            break

    report.elapsed_ms = int((time.monotonic() - t0) * 1000)
    return report


async def _extract_one(
    *,
    row: EpisodeMetadataRow,
    graph: GraphitiStore,
    pool: asyncpg.Pool,
    metadata: MetadataStore,
    contradictions: ContradictionStore,
    llm: OpenAIClient | None,
    contradiction_enabled: bool,
    fact_revisions: FactRevisionStore | None,
    report: DeferredExtractionReport,
) -> bool:
    """Run Stage 4 + Stage 5 + Stage 6c for a single deferred episode.

    Stage 6c (append-only ``fact_revision`` rows for fact-grain
    lineage) runs only when ``fact_revisions`` is supplied. Issue
    #179 — without Stage 6c here, lite-mode episodes that get
    back-filled produce EntityEdges in Neo4j with NO matching
    ``fact_revision`` rows in Postgres, so ``gnokee_fact_history``
    silently returns empty.

    Returns True on full success (Graphiti write + Postgres stamp both OK).
    Returns False and appends to report.failed on any error.
    Stage 6c failure does NOT flip the return to False (consistent with
    ingest.py — Graphiti edges are already durable; failing here would
    re-process the episode and double-write Neo4j); the skew count is
    surfaced via ``DeferredExtractionReport.fact_revision_skew_count``.
    Never raises — failure isolation is the contract.
    """
    tenant_id = row.tenant_id
    episode_uuid = row.episode_uuid

    if row.content_text is None:
        # Should not happen (lite ingest writes content_text via
        # PgVectorStore.write_content_text in Stage 6); guard anyway.
        failure_msg = (
            f"episode {episode_uuid} has extraction_deferred=True but content_text is NULL; "
            "cannot rehydrate for Graphiti extraction"
        )
        log.error("deferred_extraction: %s", failure_msg)
        report.failed.append(
            ExtractionFailure(
                episode_uuid=episode_uuid,
                tenant_id=tenant_id,
                error=failure_msg,
            )
        )
        return False

    content = row.content_text

    # Stage 4: Graphiti add_episode.
    # reference_time MUST be valid_at — NOT utc_now(). This is the
    # load-bearing invariant: deferred extraction must assign the same
    # world-time as the original lite ingest would have. Using now() here
    # would corrupt the valid-time axis for every backfilled episode.
    augmented = augment_for_extraction(content)
    try:
        # v0.6 Z1 / #111 M4 — pass ``uuid=episode_uuid`` so graphiti attaches
        # entities + edges to the EXISTING lite Episodic (gnokee-owned uuid)
        # instead of creating a fresh node. Per Z1.6 spike, graphiti's
        # add_episode(uuid=X) loads-by-uuid and uses the LOADED Episodic's
        # content for extraction (kwarg silently dropped). The lite write
        # already lands the raw content (no augmentation in lite mode), so
        # we overwrite it to the augmented form just before this call so
        # the extractor sees augmented body, then restore at Stage 4b.
        await graph.overwrite_episode_content(
            tenant_id=tenant_id,
            episode_uuid=episode_uuid,
            content=augmented,
        )
        result = await graph.add_episode(
            tenant_id=tenant_id,
            name=_episode_name(content),
            content=augmented,
            reference_time=row.valid_at,  # NOT utc_now()
            uuid=episode_uuid,
            source_description="gnokee.maintenance.deferred_extraction",
        )
    except GraphStoreError as exc:
        log.warning(
            "deferred_extraction: graphiti.add_episode failed tenant=%s uuid=%s: %s",
            tenant_id,
            episode_uuid,
            exc,
        )
        report.failed.append(
            ExtractionFailure(
                episode_uuid=episode_uuid,
                tenant_id=tenant_id,
                error=str(exc),
            )
        )
        return False

    # Stage 4b: restore original content on the Episodic node if the
    # preprocessor augmented the body (consistent with v0.6 Z1-B ingest).
    # Z1-B intentional behaviour: provenance-restore failure is logged
    # loud but non-fatal — the Episodic + facts already exist; rolling
    # back here would delete real entity work.
    if augmented != content:
        try:
            await graph.overwrite_episode_content(
                tenant_id=tenant_id,
                episode_uuid=episode_uuid,
                content=content,
            )
        except GraphStoreError as exc:
            log.warning(
                "deferred_extraction: overwrite_episode_content failed (non-fatal in v0.6 Z1-B); tenant=%s uuid=%s: %s",
                tenant_id,
                episode_uuid,
                exc,
            )

    # Stage 6c: append-only fact_revision rows (ADR-0014, issue #179).
    # Mirrors ingest.py Stage 6c via the shared
    # storage/fact_revision_stage.py helper. Best-effort: failure
    # increments DeferredExtractionReport.fact_revision_skew_count but
    # does NOT poison the episode (Graphiti edges + episode_metadata
    # are already durable; flipping to failure would re-process and
    # double-write Neo4j on the next maintenance tick).
    #
    # Derive `corrects` for this back-filled episode by looking up the
    # row whose `superseded_by == row.episode_uuid` — that row is the
    # episode this one corrects (the chain runs corrected -[superseded_by]-> corrector).
    if fact_revisions is not None and result.edges:
        corrects_target: UUID | None = None
        try:
            async with pool.acquire() as conn:
                async with conn.transaction():
                    await conn.execute(
                        "SELECT set_config('app.current_tenant', $1, true)",
                        tenant_id,
                    )
                    rec = await conn.fetchrow(
                        "SELECT episode_uuid FROM episode_metadata WHERE tenant_id = $1 AND superseded_by = $2 LIMIT 1",
                        tenant_id,
                        episode_uuid,
                    )
            if rec is not None:
                corrects_target = rec["episode_uuid"]
        except Exception as exc:
            # Failure to resolve corrects: → fall through with None.
            # New edges then get fresh fact_ids (no inheritance) — same
            # degraded posture as ingest.py prior-triple lookup failure.
            log.warning(
                "deferred_extraction: corrects-target lookup failed tenant=%s uuid=%s: %s",
                tenant_id,
                episode_uuid,
                exc,
            )

        skew = await write_fact_revisions_for_edges(
            tenant_id=tenant_id,
            episode_uuid=episode_uuid,
            episode_valid_at=row.valid_at,
            asserted_at=row.asserted_at,
            edges=result.edges,
            corrects=corrects_target,
            pool=pool,
            graph=graph,
            fact_revisions=fact_revisions,
            caller="maintenance",
        )
        report.fact_revision_skew_count += skew

    # Stage 5: contradiction detection (degraded-tolerant; mirrors ingest.py).
    if contradiction_enabled and llm is not None and result.edges:
        new_facts: list[tuple[UUID, str, datetime, list[float]]] = []
        for edge in result.edges:
            if edge.fact_embedding is None:
                continue
            edge_valid = edge.valid_at or row.valid_at
            new_facts.append(
                (
                    UUID(edge.uuid),
                    edge.fact,
                    edge_valid,
                    list(edge.fact_embedding),
                )
            )
        if new_facts:
            try:
                await detect_for_facts(
                    tenant_id=tenant_id,
                    new_facts=new_facts,
                    store=graph,
                    contradictions=contradictions,
                    llm=llm,
                    detected_at=utc_now(),
                )
            except Exception as exc:
                # Contradiction detection is degraded-tolerant: log + continue.
                # The Graphiti episode is already written; don't roll back for
                # contradiction detection failures.
                log.warning(
                    "deferred_extraction: contradiction detection failed (degraded); tenant=%s uuid=%s: %s",
                    tenant_id,
                    episode_uuid,
                    exc,
                )

    # Stamp extraction_completed_at + clear extraction_deferred flag.
    completed_at = utc_now()
    try:
        async with pool.acquire() as conn:
            # Issue #157: tx-local GUC. See run_deferred_extraction for the
            # full rationale; in short, `is_local=false` on a pooled conn
            # leaks tenant context to the next checkout.
            async with conn.transaction():
                await conn.execute(
                    "SELECT set_config('app.current_tenant', $1, true)",
                    tenant_id,
                )
                await metadata.mark_extraction_complete(
                    conn=conn,
                    tenant_id=tenant_id,
                    episode_uuid=episode_uuid,
                    completed_at=completed_at,
                )
    except VectorStoreError as exc:
        log.error(
            "deferred_extraction: mark_extraction_complete failed; "
            "Graphiti write succeeded but Postgres stamp failed — "
            "episode will be re-processed on next run. "
            "tenant=%s uuid=%s: %s",
            tenant_id,
            episode_uuid,
            exc,
        )
        report.failed.append(
            ExtractionFailure(
                episode_uuid=episode_uuid,
                tenant_id=tenant_id,
                error=f"mark_extraction_complete: {exc}",
            )
        )
        return False

    log.info(
        "deferred_extraction: completed tenant=%s uuid=%s",
        tenant_id,
        episode_uuid,
    )
    return True


async def resume_ingest(
    tenant_id: str,
    episode_uuid: UUID,
    episode: EpisodeIn,
    *,
    pipeline: IngestPipeline,
) -> IngestReceipt:
    """Opt-in resume for a journaled ``begin`` row with no matching ``commit``.

    ADR-0024 / issue #122. gnokee NEVER auto-replays: the consumer
    must explicitly call this entry with the original ``EpisodeIn``
    payload (option (b) — consumer-resupply, locked on #122). The
    journaled ``payload_hash`` is checked against the supplied
    payload; mismatch raises :class:`IngestJournalError` without
    touching either store.

    The resume re-executes Stage 4 (Neo4j ``MERGE`` is idempotent on
    ``uuid``) and Stage 5 (all inserts use ``ON CONFLICT DO NOTHING``
    or ``DO UPDATE``). Stage 6 (Graphiti enhancement) is force-
    disabled — call :func:`run_deferred_extraction` separately if
    narrative extraction is wanted on the resumed episode.

    Args:
        tenant_id: Tenant scope. Must match ``episode.tenant_id``.
        episode_uuid: The journaled ``episode_uuid`` from the
            ``begin`` row to resume.
        episode: Consumer-resupplied ``EpisodeIn``. Must produce the
            same ``payload_hash`` as the journaled ``begin`` row
            (i.e. same ``tenant_id``, ``our_id``, ``valid_at``).
        pipeline: The :class:`IngestPipeline` whose pool + journal
            are addressed.

    Raises:
        ValidationError: empty ``tenant_id`` (input validation; the
            journal is not consulted in this case).
        IngestJournalError: ``tenant_id``/``episode.tenant_id``
            mismatch; no resumable ``begin`` row for the given
            ``(tenant_id, episode_uuid)``; the episode is already
            committed (no resume needed); or payload-hash drift.

    Returns:
        :class:`IngestReceipt` describing the resumed episode.

    Note on ``asserted_at`` semantics: if the consumer's re-supplied
    ``EpisodeIn.asserted_at`` is ``None``, Stage 5 will write a fresh
    ``asserted_at = utc_now()`` — the source-tx time of the resume,
    NOT the original ingest wall-clock time (axis-2 ADR-0004). Pass
    the original ``asserted_at`` explicitly if reproducibility matters.

    Note on content drift: ``payload_hash`` covers ``(tenant_id,
    our_id, valid_at)`` only — content bytes are NOT hashed. If the
    consumer re-supplies a different ``content`` on resume, Stage 5's
    ``content_embedding`` and ``content_text`` writes use
    ``ON CONFLICT ... DO UPDATE`` and will overwrite any previously
    landed embedding/text with the resume's value. Resume MUST supply
    the original ``EpisodeIn`` content for axis-2 consistency.
    """
    if not tenant_id:
        raise ValidationError("resume_ingest: tenant_id required")
    if episode.tenant_id != tenant_id:
        raise IngestJournalError(
            f"resume_ingest: tenant_id mismatch — argument={tenant_id!r} vs episode.tenant_id={episode.tenant_id!r}"
        )

    # Point-lookup avoids the race window where another caller commits
    # this episode between scan_resumable and the predicate match.
    target = await pipeline.journal.get_resumable(tenant_id, episode_uuid)
    if target is None:
        state = await pipeline.journal.episode_state(tenant_id, episode_uuid)
        if state == "commit":
            raise IngestJournalError(
                f"resume_ingest: episode {episode_uuid} already committed for tenant={tenant_id}; no resume needed"
            )
        raise IngestJournalError(
            f"resume_ingest: no resumable 'begin' row for tenant={tenant_id} episode_uuid={episode_uuid}"
        )

    log.info(
        "resume_ingest: tenant=%s episode_uuid=%s replaying Stage 4 + Stage 5",
        tenant_id,
        episode_uuid,
    )
    return await pipeline.ingest(episode, _resume=target)


@dataclass
class BackfillFactRevisionsReport:
    """Summary returned by `backfill_fact_revisions` (issue #169).

    `scanned_count`         — total RELATES_TO edges Neo4j returned for
                              the tenant + window.
    `backfilled_count`      — rows inserted into `fact_revision`.
    `skipped_count`         — edges that already had a row in
                              `fact_revision` (idempotency proof —
                              re-running produces `backfilled_count=0`,
                              `skipped_count + dropped_orphan_count
                              == scanned_count`).
    `dropped_orphan_count`  — edges dropped because their
                              ``episode_uuid`` has no
                              ``episode_metadata`` row in Postgres for
                              this tenant (issue #210). Backfill cannot
                              populate axis-2 ``asserted_at`` without
                              the source-tx-time anchor, so the edge
                              is skipped rather than written with an
                              axis-3 fallback (would re-introduce
                              ADR-0004 axis confusion).
    `error_count`           — edges that could NOT be back-filled
                              (malformed uuids, empty predicate/fact,
                              or the batch insert raised). NEVER raises
                              out of the function; callers surface
                              this as the operator-visible skew
                              counter.
    """

    scanned_count: int = 0
    backfilled_count: int = 0
    skipped_count: int = 0
    dropped_orphan_count: int = 0
    error_count: int = 0
    elapsed_ms: int = 0


async def backfill_fact_revisions(
    *,
    tenant_id: str,
    pool: asyncpg.Pool,
    graph: GraphitiStore,
    fact_revisions: FactRevisionStore,
    window_start: datetime | None = None,
    window_end: datetime | None = None,
) -> BackfillFactRevisionsReport:
    """Backfill ``fact_revision`` rows for Stage 6c crash-recovery skew.

    Issue #169 / ADR-0024 follow-up. ``resume_ingest`` covers the Stage
    4→5 crash window but Stage 6c (``fact_revision`` write) lives
    OUTSIDE the Stage 5 transaction. A crash between Stage 5 commit and
    Stage 6c commit leaves Neo4j with ``EntityEdges`` but Postgres with
    no matching ``fact_revision`` rows — ``gnokee_fact_history`` then
    silently returns empty for those facts until the skew is reconciled.

    This helper is the reconciliation path. Distinct from
    :func:`run_deferred_extraction` (issue #179) which back-fills the
    lite→full lift path; this helper targets edges that already exist
    in Neo4j (Stage 5 succeeded) but failed Stage 6c.

    The helper is **opt-in**: gnokee NEVER auto-replays (ADR-0024
    posture). Operators invoke this explicitly — typically scheduled
    behind a window like ``window_start = last_known_clean_tick``
    after a known crash, or run unbounded as a periodic reconciler.

    Algorithm:
      1. Scan Neo4j for ``RELATES_TO`` edges keyed by ``group_id =
         tenant_id`` within the optional ``r.created_at`` window.
      2. SELECT the subset of ``fact_uuid`` values that already have a
         row in ``fact_revision`` (idempotency filter).
      3. Batch-fetch ``episode_metadata.asserted_at`` for the distinct
         ``episode_uuid`` set on the surviving edges. Drop edges whose
         episode has no metadata row — they cannot supply axis-2
         (issue #210). Increment ``dropped_orphan_count``.
      4. INSERT one ``fact_revision`` row per remaining edge with
         ``fact_id = fact_uuid``, ``prior_revision_id = None``, and
         ``asserted_at`` sourced from ``episode_metadata`` (axis-2).
      5. Return :class:`BackfillFactRevisionsReport` with counts.

    Args:
        tenant_id: Tenant scope. Mandatory; empty raises ValidationError.
        pool: asyncpg connection pool. The helper opens its own
            connections and sets the ``app.current_tenant`` GUC
            (tx-local) on each.
        graph: GraphitiStore — used for the Neo4j scan only.
        fact_revisions: FactRevisionStore for the idempotency filter
            + batch insert.
        window_start: Lower bound on edge ``created_at`` (tz-aware UTC).
            None = unbounded earlier.
        window_end: Upper bound on edge ``created_at`` (tz-aware UTC).
            None = unbounded later.

    Returns:
        :class:`BackfillFactRevisionsReport`.

    Raises:
        ValidationError: empty ``tenant_id``.

    RLS note: ``app.current_tenant`` GUC is SET on every acquired
    connection before any query, with ``is_local=true`` so the GUC
    drops on commit and never leaks across pool checkouts (issue
    #157). Every SQL statement also carries ``tenant_id = $1`` as
    primary isolation.

    Failure posture (mirrors Stage 6c in
    ``storage/fact_revision_stage.py``): batch insert failure
    increments ``error_count`` instead of raising — same degraded-
    tolerant contract callers already wire on the ingest path.
    """
    if not tenant_id or not tenant_id.strip():
        raise ValidationError("backfill_fact_revisions: tenant_id is required and must be non-empty")

    report = BackfillFactRevisionsReport()
    t0 = time.monotonic()

    # Step 1: scan Neo4j edges in window.
    try:
        edges = await graph.list_edges_in_window(
            tenant_id=tenant_id,
            created_at_start=window_start,
            created_at_end=window_end,
        )
    except GraphStoreError as exc:
        log.warning(
            "backfill_fact_revisions: edge scan failed tenant=%s: %s",
            tenant_id,
            exc,
        )
        report.elapsed_ms = int((time.monotonic() - t0) * 1000)
        return report

    report.scanned_count = len(edges)
    if not edges:
        report.elapsed_ms = int((time.monotonic() - t0) * 1000)
        return report

    # Step 2: idempotency filter — drop edges whose fact_uuid is already
    # in fact_revision for this tenant. One round-trip.
    fact_uuids = [e.fact_uuid for e in edges]
    try:
        async with pool.acquire() as conn:
            async with conn.transaction():
                await conn.execute(
                    "SELECT set_config('app.current_tenant', $1, true)",
                    tenant_id,
                )
                existing = await fact_revisions.existing_fact_uuids(
                    conn=conn,
                    tenant_id=tenant_id,
                    fact_uuids=fact_uuids,
                )
    except Exception as exc:
        log.warning(
            "backfill_fact_revisions: idempotency lookup failed tenant=%s: %s",
            tenant_id,
            exc,
        )
        report.error_count = report.scanned_count
        report.elapsed_ms = int((time.monotonic() - t0) * 1000)
        return report

    missing_edges = [e for e in edges if e.fact_uuid not in existing]
    report.skipped_count = report.scanned_count - len(missing_edges)

    if not missing_edges:
        report.elapsed_ms = int((time.monotonic() - t0) * 1000)
        return report

    # Step 3: batch-fetch axis-2 asserted_at from episode_metadata for
    # the distinct episode_uuid set on the surviving edges (issue
    # #210). The Neo4j EdgeInWindow.edge_created_at is axis-3
    # (graphiti ingest-system time) and MUST NOT be written into
    # fact_revision.asserted_at — that would re-introduce the
    # bi-temporal corruption per ADR-0004 that this fix removes.
    #
    # Pattern mirrors `MetadataStore.filter_visible` — `tenant_id = $1
    # AND episode_uuid = ANY($2::uuid[])` is the canonical batch
    # episode-metadata lookup shape.
    distinct_episode_uuids = list({e.episode_uuid for e in missing_edges})
    asserted_at_by_episode: dict[UUID, datetime] = {}
    try:
        async with pool.acquire() as conn:
            async with conn.transaction():
                await conn.execute(
                    "SELECT set_config('app.current_tenant', $1, true)",
                    tenant_id,
                )
                rows = await conn.fetch(
                    """
                    SELECT episode_uuid, asserted_at
                      FROM episode_metadata
                     WHERE tenant_id = $1
                       AND episode_uuid = ANY($2::uuid[])
                    """,
                    tenant_id,
                    distinct_episode_uuids,
                )
        for r in rows:
            asserted_at_by_episode[r["episode_uuid"]] = r["asserted_at"]
    except Exception as exc:
        log.warning(
            "backfill_fact_revisions: episode_metadata fetch failed tenant=%s: %s",
            tenant_id,
            exc,
        )
        report.error_count += len(missing_edges)
        report.elapsed_ms = int((time.monotonic() - t0) * 1000)
        return report

    # Drop orphan edges (no episode_metadata row). Expected for
    # pre-ADR-0023 episodes, so DEBUG not WARNING — WARNING would be
    # operator noise on every run against legacy data. The counter is
    # the operator-visible signal.
    enriched_edges: list[EdgeInWindow] = []
    for edge in missing_edges:
        ep_asserted = asserted_at_by_episode.get(edge.episode_uuid)
        if ep_asserted is None:
            report.dropped_orphan_count += 1
            log.debug(
                "backfill_fact_revisions: dropped orphan edge tenant=%s fact_uuid=%s episode_uuid=%s",
                tenant_id,
                edge.fact_uuid,
                edge.episode_uuid,
            )
            continue
        enriched_edges.append(replace(edge, asserted_at=ep_asserted))

    if not enriched_edges:
        report.elapsed_ms = int((time.monotonic() - t0) * 1000)
        return report

    # Step 4: build rows + batch insert. fact_id = fact_uuid and
    # prior_revision_id = None per spec ("no inheritance attempted on
    # backfill"). Same shape as a freshly-extracted edge whose
    # corrects: target was None on the original ingest. asserted_at
    # is axis-2 (episode_metadata.asserted_at) per issue #210.
    rows_to_write: list[FactRevisionRow] = []
    for edge in enriched_edges:
        assert edge.asserted_at is not None  # narrowed: orphans dropped above
        try:
            rows_to_write.append(
                FactRevisionRow(
                    fact_id=edge.fact_uuid,
                    fact_uuid=edge.fact_uuid,
                    tenant_id=tenant_id,
                    episode_uuid=edge.episode_uuid,
                    valid_at=edge.valid_at,
                    asserted_at=edge.asserted_at,
                    fact_text=edge.fact_text,
                    source_node_uuid=edge.source_node_uuid,
                    predicate=edge.predicate,
                    target_node_uuid=edge.target_node_uuid,
                    prior_revision_id=None,
                )
            )
        except ValueError as exc:
            # FactRevisionRow.__post_init__ rejects empty fact_text /
            # naive datetimes. list_edges_in_window already filters
            # empty fact_text + None valid_at; this is belt-and-braces.
            log.warning(
                "backfill_fact_revisions: row build failed tenant=%s fact_uuid=%s: %s",
                tenant_id,
                edge.fact_uuid,
                exc,
            )
            report.error_count += 1

    if not rows_to_write:
        report.elapsed_ms = int((time.monotonic() - t0) * 1000)
        return report

    try:
        async with pool.acquire() as conn:
            async with conn.transaction():
                await conn.execute(
                    "SELECT set_config('app.current_tenant', $1, true)",
                    tenant_id,
                )
                await fact_revisions.insert_batch(conn=conn, rows=rows_to_write)
    except Exception as exc:
        log.warning(
            "backfill_fact_revisions: batch insert FAILED tenant=%s n=%d: %s",
            tenant_id,
            len(rows_to_write),
            exc,
        )
        report.error_count += len(rows_to_write)
        report.elapsed_ms = int((time.monotonic() - t0) * 1000)
        return report

    report.backfilled_count = len(rows_to_write)
    report.elapsed_ms = int((time.monotonic() - t0) * 1000)
    log.info(
        "backfill_fact_revisions: tenant=%s scanned=%d backfilled=%d skipped=%d dropped_orphan=%d errors=%d",
        tenant_id,
        report.scanned_count,
        report.backfilled_count,
        report.skipped_count,
        report.dropped_orphan_count,
        report.error_count,
    )
    return report


async def resume_forget(
    app: App,
    *,
    tenant_id: str,
    audit_id: UUID | None = None,
) -> list[ForgetReceiptDetail]:
    """Replay 'fail' rows (Neo4j retry); skip orphaned 'begin' rows.

    Opt-in mirror of resume_ingest. gnokee never auto-replays.

    ADR-0026 §7. Finds all ``state='fail'`` rows for ``tenant_id`` (or a
    single row when ``audit_id`` is supplied), re-drives the Neo4j sweep,
    then flips the audit row to ``state='commit'``.

    ``state='begin'`` rows (process kill before Postgres commit) are
    surfaced as a WARNING and skipped — the caller must re-issue the
    original forget call (data is intact; Postgres was never swept).

    Args:
        app: Bootstrapped :class:`gnokee.bootstrap.App`.
        tenant_id: Tenant scope.
        audit_id: Optional narrow filter — retry only this audit row.

    Returns:
        List of :class:`~gnokee.models.ForgetReceiptDetail` for each
        row that was successfully retried and committed.
    """
    from gnokee.models import ForgetReceiptDetail
    from gnokee.storage import forget_audit

    failed = await forget_audit.find_failed_neo4j_rows(app.pool, tenant_id=tenant_id)
    pending = await forget_audit.find_resumable(app.pool, tenant_id=tenant_id)

    if pending:
        log.warning(
            "resume_forget: %d 'begin' rows for tenant=%s skipped — these indicate "
            "a process kill before Postgres commit; data is intact, caller must "
            "re-issue the forget call",
            len(pending),
            tenant_id,
        )

    if audit_id is not None:
        failed = [r for r in failed if r.audit_id == audit_id]

    receipts: list[ForgetReceiptDetail] = []
    for row in failed:
        if row.scope == "tenant":
            counts = await app.graph_store.remove_tenant_group(
                tenant_id=tenant_id,
                chunk_threshold=app.settings.neo4j_detach_chunk_threshold,
                chunk_size=app.settings.neo4j_detach_chunk_size,
            )
        else:
            uuids = [UUID(s) for s in (row.cascade_uuids or [])]
            counts = await app.graph_store.remove_episodes_by_uuid(
                tenant_id=tenant_id,
                episode_uuids=uuids,
            )
        # receipt may be None if the fail happened before the commit phase
        # stored a receipt — reconstruct from the audit row columns.
        existing: dict[str, Any]
        if row.receipt:
            existing = dict(row.receipt)
        else:
            now_iso = utc_now().isoformat()
            existing = {
                "audit_id": str(row.audit_id),
                "tenant_id": row.tenant_id,
                "scope": row.scope,
                "episode_uuid": str(row.episode_uuid) if row.episode_uuid else None,
                "cascade": row.cascade,
                "dry_run": row.dry_run,
                "summary": "",
                "affected_episode_count": 0,
                "deepest_episode_uuid": None,
                "affected_key_ids": [],
                "replayed": False,
                "started_at": row.started_at.isoformat() if row.started_at else now_iso,
                "finished_at": row.finished_at.isoformat() if row.finished_at else now_iso,
                "actor": row.actor,
                "reason": row.reason,
                "postgres_rows_deleted": {},
                "neo4j_nodes_deleted": {},
                "neo4j_edges_deleted": {},
                "cascaded_episode_uuids": row.cascade_uuids or [],
                "partial": True,
                "bitemporal_snap": row.bitemporal_snap or [],
            }
        merged = {
            **existing,
            "neo4j_nodes_deleted": {k: v for k, v in counts.items() if k != "edges_total"},
            "neo4j_edges_deleted": {"total": counts.get("edges_total", 0)},
            "partial": False,
            "replayed": False,
        }
        await forget_audit.mark_commit(app.pool, audit_id=row.audit_id, receipt=merged)
        receipts.append(ForgetReceiptDetail.model_validate(merged))
        log.info(
            "resume_forget: tenant=%s audit_id=%s committed",
            tenant_id,
            row.audit_id,
        )

    return receipts


@dataclass(frozen=True)
class PruneForgetAuditReport:
    """Outcome of `prune_forget_audit`.

    `rows_eligible` counts rows older than `before` regardless of `state`.
    `fail_rows` is the count of `state='fail'` rows in the same window —
    the pruner refuses to delete when this is > 0 (those rows must be
    resolved via `resume_forget` first).

    `rows_deleted` is 0 in dry-run mode or when the pruner refuses; otherwise
    it equals `rows_eligible`. `archive_path` is populated when the caller
    requested archiving and the dump succeeded.
    """

    tenant_id: str | None
    before: datetime
    rows_eligible: int
    fail_rows: int
    rows_deleted: int
    dry_run: bool
    archive_path: str | None
    refused: bool
    refusal_reason: str | None


class PruneRefused(Exception):
    """Raised when `prune_forget_audit(dry_run=False)` cannot proceed.

    Today the only refusal cause is the presence of `state='fail'` rows in
    the prune window — those represent an unfinished Neo4j sweep that the
    operator must resolve via `resume_forget` before the audit row may be
    deleted.
    """

    def __init__(self, *, reason: str, fail_rows: int) -> None:
        super().__init__(reason)
        self.reason = reason
        self.fail_rows = fail_rows


async def prune_forget_audit(
    app: App,
    *,
    tenant_id: str | None = None,
    before: datetime,
    dry_run: bool = True,
    archive_path: str | None = None,
    chunk_size: int = 1000,
) -> PruneForgetAuditReport:
    """Operator-driven retention pruner for `gnokee_maintenance.forget_audit`.

    Issue #139 / ADR-0026 § Audit storage. The audit table is append-only
    by design (proof-of-forget), so retention is managed out-of-band by
    operators per their compliance window.

    Hardened under #155 — the archive cursor and the delete loop both
    page in chunks of `chunk_size` rows, so memory stays bounded and
    each DELETE statement holds only chunk-sized page locks. A pre-#155
    prune over a long-retention deploy would materialize the entire
    eligible set in memory and issue a single unbounded DELETE.

    Args:
        app: Bootstrapped :class:`gnokee.bootstrap.App`.
        tenant_id: Narrow the prune to one tenant. `None` (default) means
            "all tenants" — operators with a global retention policy.
        before: Hard cutoff. Rows with `started_at < before` are eligible.
        dry_run: When True (default) returns a planning report only. When
            False, archives (if `archive_path` set) then deletes.
        archive_path: Optional filesystem path. If set, eligible rows are
            streamed as newline-delimited JSON before deletion. Compliance
            posture — keeps a copy outside the live table.
        chunk_size: Number of rows fetched per archive page and deleted
            per DELETE statement. Default 1000. Operators on very wide
            JSONB payloads (`bitemporal_snap` for large cascades) may
            lower this further.

    Raises:
        PruneRefused: `dry_run=False` and `state='fail'` rows exist in the
            window. Operator must `resume_forget` these first.
    """
    from gnokee.storage import forget_audit

    if chunk_size <= 0:
        raise ValueError("chunk_size must be positive")

    rows_eligible = await forget_audit.count_for_prune(app.pool, tenant_id=tenant_id, before=before)
    fail_rows = await forget_audit.count_for_prune(app.pool, tenant_id=tenant_id, before=before, state="fail")

    if dry_run:
        return PruneForgetAuditReport(
            tenant_id=tenant_id,
            before=before,
            rows_eligible=rows_eligible,
            fail_rows=fail_rows,
            rows_deleted=0,
            dry_run=True,
            archive_path=None,
            refused=False,
            refusal_reason=None,
        )

    if fail_rows > 0:
        reason = (
            f"prune_forget_audit refused: {fail_rows} 'fail' row(s) in window. "
            "Resolve via resume_forget before pruning."
        )
        raise PruneRefused(reason=reason, fail_rows=fail_rows)

    written_archive: str | None = None
    if archive_path is not None and rows_eligible > 0:
        import json as _json
        from pathlib import Path as _Path

        path = _Path(archive_path)
        with path.open("w", encoding="utf-8") as fh:
            async for r in forget_audit.iter_for_prune(
                app.pool, tenant_id=tenant_id, before=before, chunk_size=chunk_size
            ):
                fh.write(
                    _json.dumps(
                        {
                            "audit_id": str(r.audit_id),
                            "tenant_id": r.tenant_id,
                            "scope": r.scope,
                            "episode_uuid": str(r.episode_uuid) if r.episode_uuid is not None else None,
                            "cascade": r.cascade,
                            "dry_run": r.dry_run,
                            "state": r.state,
                            "reason": r.reason,
                            "actor": r.actor,
                            "receipt": r.receipt,
                            "error": r.error,
                            "cascade_uuids": r.cascade_uuids,
                            "bitemporal_snap": r.bitemporal_snap,
                            "started_at": r.started_at.isoformat(),
                            "finished_at": r.finished_at.isoformat() if r.finished_at is not None else None,
                        },
                        ensure_ascii=False,
                    )
                    + "\n"
                )
        written_archive = str(path)

    rows_deleted = await forget_audit.delete_for_prune(
        app.pool, tenant_id=tenant_id, before=before, chunk_size=chunk_size
    )
    log.info(
        "prune_forget_audit: tenant=%s before=%s deleted=%d archive=%s chunk=%d",
        tenant_id,
        before.isoformat(),
        rows_deleted,
        written_archive,
        chunk_size,
    )

    return PruneForgetAuditReport(
        tenant_id=tenant_id,
        before=before,
        rows_eligible=rows_eligible,
        fail_rows=0,
        rows_deleted=rows_deleted,
        dry_run=False,
        archive_path=written_archive,
        refused=False,
        refusal_reason=None,
    )


__all__ = [
    "BackfillFactRevisionsReport",
    "DeferredExtractionReport",
    "ExtractionFailure",
    "PruneForgetAuditReport",
    "PruneRefused",
    "backfill_fact_revisions",
    "prune_forget_audit",
    "resume_forget",
    "resume_ingest",
    "run_deferred_extraction",
]
