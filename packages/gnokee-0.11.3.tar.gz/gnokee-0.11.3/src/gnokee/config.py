"""src/gnokee/config.py — Environment-driven settings for gnokee.

Reads `GNOKEE_*` env vars per spec § Settings. Settings is frozen and
read once at startup; all downstream modules accept it as a parameter.

exports: class Settings | utc_now
used_by: src/gnokee/storage/migrate.py | src/gnokee/storage/* | src/gnokee/embeddings.py | src/gnokee/llm.py | src/gnokee/mcp.py | src/gnokee/demo.py
rules:   GNOKEE_* env vars only; no hard-coded defaults for connection strings
agent:   claude-opus-4-7 | 2026-05-08 | v0.1 spec
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone

from pydantic import AliasChoices, Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

log = logging.getLogger(__name__)

# Issue #183 — legacy defaults shipped since v0.1 to keep the compose stack
# zero-config. They are SAFE for `localhost`/127.0.0.1/`*-postgres` and
# `*-neo4j` compose-network hosts but DANGEROUS in any other deployment;
# Settings logs a loud warning when the default is still active and the
# resolved host is none of the above. Kept as defaults (not flipped to
# None) to avoid breaking docker-compose smoke + every existing CI job.
_LEGACY_PG_PASSWORD_DEFAULT = "gnokee"  # noqa: S105 — public compose-stack default, not a secret
_LEGACY_NEO4J_PASSWORD_DEFAULT = "gnokee-dev-password"  # noqa: S105 — public compose-stack default
_LOCAL_HOST_TOKENS = ("localhost", "127.0.0.1", "::1", "gnokee-postgres", "gnokee-neo4j")


def _looks_local(host: str) -> bool:
    host_lower = host.lower()
    return any(tok in host_lower for tok in _LOCAL_HOST_TOKENS)


class Settings(BaseSettings):
    """All gnokee-side env config. Frozen; read once at startup.

    `openai_base_url` / `openai_api_key` accept the spec-canonical
    `GNOKEE_OPENAI_*` and the spike-era `GNOKEE_LLM_*` env names.

    `pg_dsn` may be assembled from `GNOKEE_PG_USER` / `_PASSWORD` / `_DB`
    / `_PORT` (compose-stack convention) when not given directly.
    Same for `tei_url` from `GNOKEE_TEI_PORT` (defaults to 8080).
    """

    model_config = SettingsConfigDict(
        env_prefix="GNOKEE_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        frozen=True,
        populate_by_name=True,
    )

    pg_dsn: str | None = Field(default=None, description="Postgres DSN, e.g. postgresql://u:p@h:5432/d")
    pg_user: str = Field(default="gnokee")
    pg_password: str = Field(default="gnokee")
    pg_db: str = Field(default="gnokee")
    pg_port: int = Field(default=5432)
    pg_host: str = Field(default="localhost")
    neo4j_uri: str = Field(default="bolt://localhost:7687", description="Bolt URI")
    neo4j_user: str = Field(default="neo4j")
    neo4j_password: str = Field(default="gnokee-dev-password", description="Neo4j auth password")
    neo4j_detach_chunk_threshold: int = Field(
        default=100_000,
        description=(
            "Issue #138 — `forget_tenant` Neo4j sweep stays monolithic while "
            "the tenant's node count is at or below this value; above it, the "
            "sweep chunks via repeated `LIMIT $chunk_size DETACH DELETE` "
            "passes. Default 100k keeps single-tx behaviour for typical "
            "deployments and avoids Neo4j heap pressure on >1M-node tenants."
        ),
    )
    neo4j_detach_chunk_size: int = Field(
        default=10_000,
        description=(
            "Nodes per chunk when the chunked path engages (see "
            "`neo4j_detach_chunk_threshold`). 10k keeps each chunk in the "
            "single-second-range on typical Neo4j 5 Community deployments."
        ),
    )
    forget_lock_timeout_ms: int = Field(
        default=30_000,
        ge=0,
        description=(
            "Issue #153 — `lock_timeout` (Postgres `SET LOCAL`) the forget "
            "pipeline applies before `pg_advisory_xact_lock(...)` for the "
            "exclusive forget lock. A long-running or stalled ingest holds "
            "the shared lock for its transaction's duration; without a "
            "lock_timeout a contending forget would block until "
            "`idle_in_transaction_session_timeout` fires (often >5 min). "
            "On timeout the forget raises `ForgetContention(tenant_id=..., "
            "waited_ms=...)` rather than hanging. 0 disables the timeout."
        ),
    )
    tei_url: str | None = Field(default=None, description="TEI base URL (legacy)")
    tei_port: int = Field(default=8080)
    embed_base_url: str | None = Field(
        default=None,
        validation_alias=AliasChoices("GNOKEE_EMBED_BASE_URL"),
        description=(
            "Embedder endpoint. URLs ending in `/v1` use the OpenAI-compatible "
            "shape (Ollama, OpenAI cloud); otherwise the native HuggingFace TEI "
            "`/embed` shape. Falls back to `tei_url` when unset."
        ),
    )
    embed_api_key: str = Field(
        default="",
        validation_alias=AliasChoices("GNOKEE_EMBED_API_KEY"),
        description="Bearer for OpenAI-compatible embedders. Empty for TEI native.",
    )
    embed_model: str = Field(default="bge-m3")
    openai_base_url: str = Field(
        default="https://api.openai.com/v1",
        validation_alias=AliasChoices("GNOKEE_OPENAI_BASE_URL", "GNOKEE_LLM_BASE_URL"),
    )
    openai_api_key: str = Field(
        default="",
        validation_alias=AliasChoices("GNOKEE_OPENAI_API_KEY", "GNOKEE_LLM_API_KEY"),
    )
    llm_model: str = Field(default="gpt-4o-mini")
    tenant_default: str = Field(default="default")
    mcp_http: bool = Field(default=False)
    log_level: str = Field(default="info")

    # ── omkit integration (all opt-in) ───────────────────────────────────
    # Tracing is OFF by default; setting `otel_endpoint` (or
    # `OTEL_EXPORTER_OTLP_ENDPOINT` per OTel convention) turns it on.
    otel_enabled: bool = Field(
        default=False,
        validation_alias=AliasChoices("GNOKEE_OTEL_ENABLED"),
        description="Initialise omkit OTel tracing in build_app. No-op without omkit installed.",
    )
    otel_endpoint: str = Field(
        default="",
        validation_alias=AliasChoices("GNOKEE_OTEL_ENDPOINT", "OTEL_EXPORTER_OTLP_ENDPOINT"),
        description="OTLP/HTTP collector base URL (e.g. http://otel-collector:4318).",
    )
    otel_service_name: str = Field(default="gnokee")

    # KMS for the encrypted_body branch. `kms_backend=disabled` (default)
    # keeps gnokee's classic stance — caller supplies DEK at recall time.
    # `localdev` and `openbao` wire the omkit adapters; the recall path
    # uses them to unwrap automatically. `key_master` is only consulted
    # by the localdev backend.
    kms_backend: str = Field(
        default="disabled",
        description="One of: disabled | localdev | openbao. Requires omkit when not disabled.",
    )
    kms_master_secret: str = Field(
        default="",
        validation_alias=AliasChoices("GNOKEE_KMS_MASTER_SECRET"),
        description="HMAC master secret for the localdev backend. Hex-encoded; 32 bytes recommended.",
    )
    openbao_addr: str = Field(default="", validation_alias=AliasChoices("GNOKEE_OPENBAO_ADDR"))
    openbao_role_id: str = Field(default="", validation_alias=AliasChoices("GNOKEE_OPENBAO_ROLE_ID"))
    openbao_secret_id: str = Field(default="", validation_alias=AliasChoices("GNOKEE_OPENBAO_SECRET_ID"))
    # Maps to omkit OpenBaoKMS `key_name` — the Transit key gnokee unwraps against.
    openbao_mount: str = Field(
        default="gnokee-encrypted-body",
        validation_alias=AliasChoices("GNOKEE_OPENBAO_KEY_NAME", "GNOKEE_OPENBAO_MOUNT"),
    )

    @model_validator(mode="after")
    def _resolve_optional(self) -> Settings:
        if self.pg_dsn is None:
            object.__setattr__(
                self,
                "pg_dsn",
                f"postgresql://{self.pg_user}:{self.pg_password}@{self.pg_host}:{self.pg_port}/{self.pg_db}",
            )
        if self.tei_url is None:
            object.__setattr__(self, "tei_url", f"http://localhost:{self.tei_port}")
        if self.embed_base_url is None:
            # Fall back to the legacy TEI URL so existing configs keep working.
            object.__setattr__(self, "embed_base_url", self.tei_url)

        # Issue #183 — warn loudly when the legacy compose-stack default
        # passwords are still in effect AND the resolved host is not a
        # recognised localhost / compose-network token. Catches accidental
        # production deploys that forgot to rotate the seed credentials.
        if self.pg_password == _LEGACY_PG_PASSWORD_DEFAULT and not _looks_local(self.pg_host):
            log.warning(
                "gnokee.config: GNOKEE_PG_PASSWORD is still the default "
                "%r and GNOKEE_PG_HOST=%r is not localhost — set a real "
                "password or remove the default before deploying.",
                _LEGACY_PG_PASSWORD_DEFAULT,
                self.pg_host,
            )
        neo4j_host = self.neo4j_uri.split("://", 1)[-1].split(":", 1)[0]
        if self.neo4j_password == _LEGACY_NEO4J_PASSWORD_DEFAULT and not _looks_local(neo4j_host):
            log.warning(
                "gnokee.config: GNOKEE_NEO4J_PASSWORD is still the default "
                "%r and GNOKEE_NEO4J_URI host %r is not localhost — set a "
                "real password or remove the default before deploying.",
                _LEGACY_NEO4J_PASSWORD_DEFAULT,
                neo4j_host,
            )
        # Setting OTEL_EXPORTER_OTLP_ENDPOINT (industry-standard env name)
        # is sufficient intent — flip the gnokee bool so build_app wires it.
        if self.otel_endpoint and not self.otel_enabled:
            object.__setattr__(self, "otel_enabled", True)
        return self


def utc_now() -> datetime:
    """Tz-aware UTC datetime. Single source for `now()` across the codebase."""
    return datetime.now(timezone.utc)
