import logging
from datetime import UTC, datetime

from mongoengine import EmbeddedDocument
from mongoengine.errors import ValidationError
from mongoengine.fields import DateTimeField, EmbeddedDocumentListField, ReferenceField, StringField
from mongoengine.signals import post_save

from udata.api_fields import field, generate_fields
from udata.auth import current_user

from .signals import on_badge_added, on_badge_removed

log = logging.getLogger(__name__)


__all__ = ["Badge", "BadgeMixin", "BadgesList"]


@generate_fields(default_filterable_field="kind")
class Badge(EmbeddedDocument):
    meta = {"allow_inheritance": True}
    kind = field(StringField(required=True))
    created = DateTimeField(default=lambda: datetime.now(UTC), required=True)
    created_by = ReferenceField("User")

    def __str__(self):
        return self.kind


class BadgesList(EmbeddedDocumentListField):
    def __init__(self, badge_model, *args, **kwargs):
        return super(BadgesList, self).__init__(badge_model, *args, **kwargs)


DEFAULT_BADGES_LIST_PARAMS = {
    "readonly": True,
}


class BadgeMixin:
    default_badges_list_params = DEFAULT_BADGES_LIST_PARAMS
    badges = field(BadgesList(Badge), **DEFAULT_BADGES_LIST_PARAMS)

    @classmethod
    def available_badges(cls):
        from flask import current_app

        hidden = current_app.config.get(f"{cls.__name__.upper()}_HIDDEN_BADGES", [])
        return {k: v for k, v in cls.__badges__.items() if k not in hidden}

    def get_badge(self, kind):
        """Get a badge given its kind if present"""
        candidates = [b for b in self.badges if b.kind == kind]
        return candidates[0] if candidates else None

    def add_badge(self, kind):
        """Perform an atomic prepend for a new badge"""
        badge = self.get_badge(kind)
        if badge:
            return badge
        if kind not in self.available_badges():
            msg = "Unknown badge type for {model}: {kind}"
            raise ValidationError(msg.format(model=self.__class__.__name__, kind=kind))
        badge = self._fields["badges"].field.document_type(kind=kind)
        if current_user and current_user.is_authenticated:
            badge.created_by = current_user.id

        self.update(__raw__={"$push": {"badges": {"$each": [badge.to_mongo()], "$position": 0}}})
        self.reload()
        post_save.send(self.__class__, document=self)
        on_badge_added.send(self, kind=kind)
        return self.get_badge(kind)

    def remove_badge(self, kind):
        """Perform an atomic removal for a given badge"""
        self.update(__raw__={"$pull": {"badges": {"kind": kind}}})
        self.reload()
        on_badge_removed.send(self, kind=kind)
        post_save.send(self.__class__, document=self)

    def toggle_badge(self, kind):
        """Toggle a bdage given its kind"""
        badge = self.get_badge(kind)
        if badge:
            return self.remove_badge(kind)
        else:
            return self.add_badge(kind)

    def badge_label(self, badge):
        """Display the badge label for a given kind"""
        # Uses __badges__ (not available_badges) so that existing badges
        # still have a displayable label even if hidden via settings.
        badge_model = self._fields["badges"].field.document_type
        kind = badge.kind if isinstance(badge, badge_model) else badge
        return self.__badges__[kind]
