from udata.core.dataservices.tasks import purge_dataservices
from udata.core.dataset.tasks import purge_datasets
from udata.core.reuse.tasks import purge_reuses
from udata.core.topic.factories import TopicWithElementsFactory
from udata.core.topic.tasks import purge_topics_elements
from udata.tests.api import PytestOnlyDBTestCase


class TopicTasksTest(PytestOnlyDBTestCase):
    def test_purge_topics_elements(self):
        topic = TopicWithElementsFactory()
        assert len(topic.elements) > 0
        for element in topic.elements:
            element.title = None
            element.save()
            # Handle different deletion field names across models
            if hasattr(element.element, "deleted_at"):
                element.element.deleted_at = "2023-01-01"
            else:
                element.element.deleted = "2023-01-01"
            element.element.save()
        topic.save()
        # remove the dataset elements marked as deleted
        purge_datasets()
        # remove the reuse elements marked as deleted
        purge_reuses()
        # remove the dataservices elements marked as deleted
        purge_dataservices()
        # remove the topic elements that have neither title nor element
        purge_topics_elements()
        topic.reload()
        assert len(topic.elements) == 0
