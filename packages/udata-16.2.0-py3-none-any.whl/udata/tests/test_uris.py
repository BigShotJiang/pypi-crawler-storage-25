import pytest

from udata import uris
from udata.settings import Defaults
from udata.tests import PytestOnlyTestCase

PUBLIC_HOSTS = [
    "http://foo.com/blah_blah",
    "http://foo.com/blah_blah/",
    "http://foo.com/blah_blah_(wikipedia)",
    "http://foo.com/blah_blah_(wikipedia)_(again)",
    "http://www.example.com/wpstyle/?p=364",
    "https://www.example.com/foo/?bar=baz&inga=42&quux",
    "http://✪df.ws/123",
    "http://➡.ws/䨹",
    "http://⌘.ws",
    "http://⌘.ws/",
    "http://foo.com/blah_(wikipedia)#cite-1",
    "http://foo.com/blah_(wikipedia)_blah#cite-1",
    "http://foo.com/unicode_(✪)_in_parens",
    "http://foo.com/(something)?after=parens",
    "http://☺.damowmow.com/",
    "http://code.google.com/events/#&product=browser",
    "http://j.mp",
    "ftp://foo.bar/baz",
    "http://foo.bar/?q=Test%20URL-encoded%20stuff",
    "http://مثال.إختبار.com",
    "http://例子.测试.com",
    "http://उदाहरण.परीक्षा.com",
    "http://-.~_!$&'()*+,;=:%40:80%2f::::::@example.com",
    "http://1337.net",
    "http://a.b-c.de",
    "https://foo_bar.example.com/",
    "ftps://foo.bar/",
    "//foo.bar/",
]

PUBLIC_HOSTS_IDN = [
    "http://例子.中国",
    "http://somewhere.укр",
]

WITH_CREDENTIALS = [
    "http://userid:password@example.com:8080",
    "http://userid:password@example.com:8080/",
    "http://userid@example.com",
    "http://userid@example.com/",
    "http://userid@example.com:8080",
    "http://userid@example.com:8080/",
    "http://userid:password@example.com",
    "http://userid:password@example.com/",
]

PUBLIC_IPS = [
    "http://142.42.1.1/",
    "http://142.42.1.1:8080",
    "http://142.42.1.1:8080/",
    "http://223.255.255.254",
    "http://[2a00:1450:4007:80e::2004]",
    "http://[2a00:1450:4007:80e::2004]:8080",
    "http://[2a00:1450:4007:80e::2004]:8080/",
]

PUBLIC = PUBLIC_HOSTS + PUBLIC_HOSTS_IDN + PUBLIC_IPS + WITH_CREDENTIALS

PRIVATE_IPS = [
    "http://10.1.1.1",
    "http://10.1.1.1:8080",
    "http://10.1.1.1:8080/index.html",
    "http://10.1.1.254",
    "http://10.1.1.254:8080",
    "http://10.1.1.254:8080/index.html",
    "http://[fc00::1]",
    "http://[fc00::1]:8080",
    "http://[fc00::1]:8080/index.html",
]

PRIVATE = PRIVATE_IPS

LOCAL_HOSTS = [
    "http://localhost",
    "http://localhost:8080",
    "http://localhost:8080/index.html",
    "http://localhost.localdomain",
    "http://localhost.localdomain:8080",
    "http://localhost.localdomain:8080/index.html",
]

LOCAL_IPS = [
    "http://127.0.0.1",
    "http://127.0.0.1:8080",
    "http://127.0.0.1:8080/index.html",
    "http://127.0.1.1",
    "http://127.0.1.1:8080",
    "http://127.0.1.1:8080/index.html",
    "http://[::1]",
    "http://[::1]:8080",
    "http://[::1]:8080/index.html",
]

LOCAL = LOCAL_HOSTS + LOCAL_IPS

HOSTS_RESOLVING_TO_LOOPBACK = [
    "http://localtest.me",
    "http://localtest.me/index.html",
    "http://localtest.me:8080/index.html",
]

MULTICAST = [
    "http://224.1.1.1",
    "http://224.1.1.1:8080",
    "http://224.1.1.1:8080/index.html",
    "http://[ff00::1]",
    "http://[ff00::1]:8080",
    "http://[ff00::1]:8080/index.html",
]

INVALID = [
    "http://",
    "h/://.",
    "http://..",
    "http://../",
    "http://?",
    "http://??",
    "http://??/",
    "http://#",
    "http://##",
    "http://##/",
    "http://foo.bar?q=Spaces should be encoded",
    "http://foo.bar?q=Spaces should be encoded with unicode é",
    "//",
    "//a",
    "///a",
    "///",
    "http:///a",
    "foo.com",
    "rdar://1234",
    "h://test",
    "http:// shouldfail.com",
    ":// should fail",
    "http://foo.bar/foo(bar)baz quux",
    "http://-error-.invalid/",
    "http://_error_.invalid/",
    "http://a.b--c.de/",
    "http://-a.b.co",
    "http://a.b-.co",
    "http://0.0.0.0",
    "http://10.1.1.0",
    "http://10.1.1.255",
    "http://1.1.1.1.1",
    "http://123.123.123",
    "http://3628126748",
    "http://.www.foo.bar/",
    "http://www.foo.bar./",
    "http://.www.foo.bar./",
    "http://[fffff:1450:4007:80e::2004]",
    "http://[fffff:1450:4007:80e::2004]:8080",
    "http://[fffff:1450:4007:80e::2004]:8080/index.html",
    "http://[::]",
    "http://[::]:8080",
    "http://[::]:8080/index.html",
]

DEFAULT_SCHEMES = Defaults.URLS_ALLOWED_SCHEMES
# Custom schemes not in uris.SCHEMES
CUSTOM_SCHEMES = ["irc", "unknown"]

# Extract some default TLDs
DEFAULT_TLDS = sorted(Defaults.URLS_ALLOWED_TLDS)[:2]
# Custom TLDs not in IANA official list
CUSTOM_TLDS = ["i2", "unknown"]


@pytest.mark.options(URLS_ALLOW_LOCAL=False)
@pytest.mark.options(DEFAULT_LANGUAGE="en")
class UriValidationTest(PytestOnlyTestCase):
    def test_validate_strip_url(self):
        assert uris.validate("  http://somewhere.com  ") == "http://somewhere.com"

    @pytest.mark.parametrize("url", PUBLIC_HOSTS)
    def test_default_should_validate_public_urls(self, url):
        assert uris.validate(url) == url

    @pytest.mark.parametrize("url", PUBLIC_HOSTS_IDN)
    def test_default_should_validate_public_urls_with_utf8_tld(self, url):
        assert uris.validate(url) == url

    @pytest.mark.parametrize("url", PUBLIC_IPS)
    def test_default_should_validate_public_ips(self, url):
        assert uris.validate(url) == url

    @pytest.mark.parametrize("scheme", DEFAULT_SCHEMES)
    def test_default_should_validate_default_schemes(self, scheme):
        url = "{0}://somewhere.com".format(scheme)
        assert uris.validate(url) == url

    @pytest.mark.parametrize("scheme", CUSTOM_SCHEMES)
    def test_default_should_not_validate_non_default_schemes(self, scheme):
        url = "{0}://somewhere.com".format(scheme)
        with pytest.raises(uris.ValidationError, match="Invalid scheme"):
            uris.validate(url)

    @pytest.mark.parametrize("tld", CUSTOM_TLDS)
    def test_default_should_not_validate_unknown_tlds(self, tld):
        url = "http://somewhere.{0}".format(tld)
        with pytest.raises(uris.ValidationError, match="Invalid TLD"):
            uris.validate(url)

    @pytest.mark.parametrize("url", PRIVATE)
    def test_default_should_not_validate_private_urls(self, url):
        with pytest.raises(uris.ValidationError, match="private URL"):
            uris.validate(url)

    @pytest.mark.parametrize("url", LOCAL_HOSTS)
    def test_default_should_not_validate_local_hosts(self, url):
        with pytest.raises(uris.ValidationError, match="local URL"):
            uris.validate(url)

    @pytest.mark.parametrize("url", INVALID)
    def test_should_not_validate_bad_urls(self, url):
        with pytest.raises(uris.ValidationError, match="Invalid URL"):
            uris.validate(url)

    @pytest.mark.parametrize("url", MULTICAST)
    def test_should_not_validate_multicast_urls(self, url):
        with pytest.raises(uris.ValidationError, match="multicast IP"):
            uris.validate(url)

    @pytest.mark.parametrize("url", PUBLIC + PRIVATE)
    def test_private_should_validate_public_and_private_urls(self, url):
        assert uris.validate(url, private=True) == url

    @pytest.mark.parametrize("url", LOCAL)
    def test_private_should_not_validate_local_urls(self, url):
        with pytest.raises(uris.ValidationError, match="local URL"):
            uris.validate(url, private=True)

    @pytest.mark.parametrize("url", PUBLIC + LOCAL)
    def test_local_should_validate_public_and_local_urls(self, url):
        assert uris.validate(url, local=True) == url

    @pytest.mark.parametrize("url", PRIVATE)
    def test_local_should_not_validate_private_urls(self, url):
        with pytest.raises(uris.ValidationError, match="private URL"):
            uris.validate(url, local=True)

    @pytest.mark.parametrize("url", PUBLIC + LOCAL + PRIVATE)
    def test_private_local_should_validate_any_valid_urls(self, url):
        assert uris.validate(url, local=True, private=True) == url

    @pytest.mark.parametrize("url", HOSTS_RESOLVING_TO_LOOPBACK)
    @pytest.mark.options(URLS_RESOLVE_HOSTNAME=True)
    def test_default_should_not_validate_hostnames_resolving_to_loopback(self, url):
        with pytest.raises(uris.ValidationError, match="local URL"):
            uris.validate(url)

    @pytest.mark.parametrize("url", HOSTS_RESOLVING_TO_LOOPBACK)
    @pytest.mark.options(URLS_RESOLVE_HOSTNAME=True)
    def test_should_validate_hostnames_if_no_resolve(self, url):
        assert uris.validate(url, resolve=False) == url

    @pytest.mark.parametrize("url", HOSTS_RESOLVING_TO_LOOPBACK)
    @pytest.mark.options(URLS_RESOLVE_HOSTNAME=True)
    def test_local_should_validate_hostnames_resolving_to_loopback(self, url):
        assert uris.validate(url, local=True) == url

    @pytest.mark.parametrize("scheme", CUSTOM_SCHEMES)
    def test_custom_schemes(self, scheme):
        url = "{0}://somewhere.com".format(scheme)
        assert uris.validate(url, schemes=CUSTOM_SCHEMES) == url

    @pytest.mark.parametrize("scheme", DEFAULT_SCHEMES)
    def test_custom_schemes_should_not_validate_defaults(self, scheme):
        url = "{0}://somewhere.com".format(scheme)
        with pytest.raises(uris.ValidationError, match="Invalid scheme"):
            uris.validate(url, schemes=CUSTOM_SCHEMES)

    @pytest.mark.parametrize("tld", CUSTOM_TLDS)
    def test_custom_tlds(self, tld):
        url = "http://somewhere.{0}".format(tld)
        assert uris.validate(url, tlds=CUSTOM_TLDS) == url

    @pytest.mark.parametrize("tld", DEFAULT_TLDS)
    def test_custom_tlds_should_not_validate_defaults(self, tld):
        url = "http://somewhere.{0}".format(tld)
        with pytest.raises(uris.ValidationError, match="Invalid "):
            uris.validate(url, tlds=CUSTOM_TLDS)

    @pytest.mark.parametrize("url", WITH_CREDENTIALS)
    def test_with_credentials(self, url):
        assert uris.validate(url) == url

    @pytest.mark.parametrize("url", WITH_CREDENTIALS)
    def test_with_credentials_disabled(self, url):
        with pytest.raises(uris.ValidationError, match="Credentials in URL are not allowed"):
            uris.validate(url, credentials=False)


@pytest.mark.options(CDATA_BASE_URL="http://localhost:3000/")
class CdataUrlTest(PytestOnlyTestCase):
    def test_cdata_url_without_base_url(self, app):
        app.config["CDATA_BASE_URL"] = None
        assert uris.cdata_url("test") is None

    def test_cdata_url_with_simple_uri(self):
        assert uris.cdata_url("test") == "http://localhost:3000/test"

    @pytest.mark.options(MAIL_CAMPAIGN="mail")
    def test_cdata_url_with_mail_campaign(self):
        assert (
            uris.cdata_url("test", _mailCampaign=True)
            == "http://localhost:3000/test?mtm_campaign=mail"
        )

    def test_cdata_url_with_trailing_slash(self):
        assert uris.cdata_url("test/") == "http://localhost:3000/test"

    def test_cdata_url_with_append(self):
        assert (
            uris.cdata_url("test/", append="/discussions")
            == "http://localhost:3000/test/discussions"
        )

    def test_cdata_url_with_append_and_kwargs(self):
        assert (
            uris.cdata_url("test/", append="/discussions", discussion_id="disc_id")
            == "http://localhost:3000/test/discussions?discussion_id=disc_id"
        )
