from datetime import UTC, datetime, timedelta, timezone

from flask import url_for

from udata.core.dataset.activities import UserCreatedDataset
from udata.core.dataset.factories import CommunityResourceFactory, DatasetFactory
from udata.core.discussions.factories import DiscussionFactory
from udata.core.discussions.models import Message as DiscMsg
from udata.core.organization.factories import OrganizationFactory
from udata.core.reuse.factories import ReuseFactory
from udata.core.user.factories import UserFactory
from udata.i18n import _
from udata.models import Discussion, Follow, Member, User
from udata.tests.helpers import capture_mails
from udata.utils import faker

from . import APITestCase


class MeAPITest(APITestCase):
    def test_get_profile(self):
        """It should fetch my user data on GET"""
        self.login()
        response = self.get(url_for("api.me"))
        self.assert200(response)
        self.assertEqual(response.json["email"], self.user.email)
        self.assertEqual(response.json["first_name"], self.user.first_name)
        self.assertEqual(response.json["roles"], [])

    def test_get_profile_with_deleted_org(self):
        """It should not display my membership to deleted organizations"""
        user = self.login()
        member = Member(user=user, role="editor")
        org = OrganizationFactory(members=[member])
        deleted_org = OrganizationFactory(members=[member], deleted=datetime.now(UTC))
        response = self.get(url_for("api.me"))
        self.assert200(response)
        orgs = [o["id"] for o in response.json["organizations"]]
        self.assertIn(str(org.id), orgs)
        self.assertNotIn(str(deleted_org.id), orgs)

    def test_get_profile_401(self):
        """It should raise a 401 on GET /me if no user is authenticated"""
        response = self.get(url_for("api.me"))
        self.assert401(response)

    def test_update_profile(self):
        """It should update my profile from the API"""
        self.login()
        data = self.user.to_dict()
        self.assertTrue(self.user.active)
        data["about"] = "new about"
        data["active"] = False
        response = self.put(url_for("api.me"), data)
        self.assert200(response)
        self.assertEqual(User.objects.count(), 1)
        self.user.reload()
        self.assertEqual(self.user.about, "new about")
        self.assertTrue(self.user.active)

    def test_my_metrics(self):
        self.login()
        response = self.get(url_for("api.my_metrics"))
        self.assert200(response)
        self.assertEqual(response.json["resources_availability"], 100.0)
        self.assertEqual(response.json["datasets_org_count"], 0)
        self.assertEqual(response.json["followers_org_count"], 0)
        self.assertEqual(response.json["datasets_count"], 0)
        self.assertEqual(response.json["followers_count"], 0)

    def test_my_reuses(self):
        user = self.login()
        reuses = [ReuseFactory(owner=user) for _ in range(2)]

        response = self.get(url_for("api.my_reuses"))
        self.assert200(response)

        self.assertEqual(len(response.json), len(reuses))

    def test_my_org_datasets(self):
        user = self.login()
        member = Member(user=user, role="editor")
        organization = OrganizationFactory(members=[member])
        community_resources = [DatasetFactory(owner=user) for _ in range(2)]
        org_datasets = [DatasetFactory(organization=organization) for _ in range(2)]

        response = self.get(url_for("api.my_org_datasets"))
        self.assert200(response)
        self.assertEqual(len(response.json), len(community_resources) + len(org_datasets))

    def test_my_org_datasets_with_search(self):
        user = self.login()
        member = Member(user=user, role="editor")
        organization = OrganizationFactory(members=[member])
        datasets = [
            DatasetFactory(owner=user, title="foô"),
        ]
        org_datasets = [
            DatasetFactory(organization=organization, title="foô"),
        ]

        # Should not be listed.
        DatasetFactory(owner=user)
        DatasetFactory(organization=organization)

        response = self.get(url_for("api.my_org_datasets", q="foô"))
        self.assert200(response)
        self.assertEqual(len(response.json), len(datasets) + len(org_datasets))

    def test_my_org_community_resources(self):
        user = self.login()
        member = Member(user=user, role="editor")
        organization = OrganizationFactory(members=[member])
        community_resources = [CommunityResourceFactory(owner=user) for _ in range(2)]
        org_community_resources = [
            CommunityResourceFactory(organization=organization) for _ in range(2)
        ]

        response = self.get(url_for("api.my_org_community_resources"))
        self.assert200(response)
        self.assertEqual(
            len(response.json), len(community_resources) + len(org_community_resources)
        )

    def test_my_org_community_resources_with_search(self):
        user = self.login()
        member = Member(user=user, role="editor")
        organization = OrganizationFactory(members=[member])
        community_resources = [
            CommunityResourceFactory(owner=user, title="foô"),
        ]
        org_community_resources = [
            CommunityResourceFactory(organization=organization, title="foô"),
        ]

        # Should not be listed.
        CommunityResourceFactory(owner=user)
        CommunityResourceFactory(organization=organization)

        response = self.get(url_for("api.my_org_community_resources", q="foô"))
        self.assert200(response)
        self.assertEqual(
            len(response.json), len(community_resources) + len(org_community_resources)
        )

    def test_my_org_reuses(self):
        user = self.login()
        member = Member(user=user, role="editor")
        organization = OrganizationFactory(members=[member])
        reuses = [ReuseFactory(owner=user) for _ in range(2)]
        org_reuses = [ReuseFactory(organization=organization) for _ in range(2)]

        response = self.get(url_for("api.my_org_reuses"))
        self.assert200(response)
        self.assertEqual(len(response.json), len(reuses) + len(org_reuses))

    def test_my_org_reuses_with_search(self):
        user = self.login()
        member = Member(user=user, role="editor")
        organization = OrganizationFactory(members=[member])
        reuses = [
            ReuseFactory(owner=user, title="foô"),
        ]
        org_reuses = [
            ReuseFactory(organization=organization, title="foô"),
        ]

        # Should not be listed.
        ReuseFactory(owner=user)
        ReuseFactory(organization=organization)

        response = self.get(url_for("api.my_org_reuses", q="foô"))
        self.assert200(response)
        self.assertEqual(len(response.json), len(reuses) + len(org_reuses))

    def test_my_org_discussions(self):
        user = self.login()
        member = Member(user=user, role="editor")
        organization = OrganizationFactory(members=[member])
        reuse = ReuseFactory(owner=user)
        org_reuse = ReuseFactory(organization=organization)
        dataset = DatasetFactory(owner=user)
        org_dataset = DatasetFactory(organization=organization)

        discussions = [
            Discussion.objects.create(subject=dataset, title="", user=user),
            Discussion.objects.create(subject=org_dataset, title="", user=user),
            Discussion.objects.create(subject=reuse, title="", user=user),
            Discussion.objects.create(subject=org_reuse, title="", user=user),
        ]

        # Should not be listed
        Discussion.objects.create(subject=DatasetFactory(), title="", user=user)
        Discussion.objects.create(subject=ReuseFactory(), title="", user=user)

        response = self.get(url_for("api.my_org_discussions"))
        self.assert200(response)
        self.assertEqual(len(response.json), len(discussions))

    def test_my_org_discussions_with_search(self):
        user = self.login()
        member = Member(user=user, role="editor")
        organization = OrganizationFactory(members=[member])
        reuse = ReuseFactory(owner=user)
        org_reuse = ReuseFactory(organization=organization)
        dataset = DatasetFactory(owner=user)
        org_dataset = DatasetFactory(organization=organization)

        discussions = [
            Discussion.objects.create(subject=dataset, title="foô", user=user),
            Discussion.objects.create(subject=org_reuse, title="foô", user=user),
        ]

        # Should not be listed.
        (Discussion.objects.create(subject=reuse, title="", user=user),)
        (Discussion.objects.create(subject=org_dataset, title="", user=user),)

        # Should really not be listed.
        Discussion.objects.create(subject=DatasetFactory(), title="foô", user=user)
        Discussion.objects.create(subject=ReuseFactory(), title="foô", user=user)

        response = self.get(url_for("api.my_org_discussions", q="foô"))
        self.assert200(response)
        self.assertEqual(len(response.json), len(discussions))

    def test_my_reuses_401(self):
        response = self.get(url_for("api.my_reuses"))
        self.assert401(response)

    def test_create_token(self):
        """It should create a new API token on POST"""
        self.login()
        response = self.post(url_for("api.my_api_tokens"))
        self.assert201(response)
        self.assertIn("token", response.json)
        self.assertIn("token_prefix", response.json)
        self.assertTrue(response.json["token"].startswith("udata_"))

    def test_create_token_with_name(self):
        """It should create a named API token on POST"""
        self.login()
        response = self.post(url_for("api.my_api_tokens"), {"name": "My CI token"})
        self.assert201(response)
        self.assertEqual(response.json["name"], "My CI token")

    def test_create_token_with_expiration(self):
        """It should create a token with an expiration date"""
        self.login()
        response = self.post(
            url_for("api.my_api_tokens"),
            {"expires_at": "2030-01-01T00:00:00"},
        )
        self.assert201(response)
        self.assertIsNotNone(response.json["expires_at"])

    def test_create_token_with_invalid_expiration(self):
        """It should return 400 for an invalid expires_at format"""
        self.login()
        response = self.post(
            url_for("api.my_api_tokens"),
            {"expires_at": "not-a-date"},
        )
        self.assert400(response)

    def test_create_token_with_past_expiration(self):
        """It should return 400 for an expires_at in the past"""
        self.login()
        response = self.post(
            url_for("api.my_api_tokens"),
            {"expires_at": "2020-01-01T00:00:00"},
        )
        self.assert400(response)

    def test_list_tokens(self):
        """It should list active tokens without the plaintext"""
        self.login()
        self.post(url_for("api.my_api_tokens"), {"name": "Token 1"})
        self.post(url_for("api.my_api_tokens"), {"name": "Token 2"})
        response = self.get(url_for("api.my_api_tokens"))
        self.assert200(response)
        self.assertEqual(len(response.json), 2)
        for token_data in response.json:
            self.assertNotIn("token", token_data)
            self.assertIn("token_prefix", token_data)

    def test_revoke_token(self):
        """It should revoke a token on DELETE"""
        self.login()
        create_response = self.post(url_for("api.my_api_tokens"))
        self.assert201(create_response)
        token_id = create_response.json["id"]
        plaintext = create_response.json["token"]

        response = self.delete(url_for("api.my_api_token", api_token=token_id))
        self.assert204(response)

        # Verify the token is no longer in the active list
        response = self.get(url_for("api.my_api_tokens"))
        self.assert200(response)
        active_ids = [t["id"] for t in response.json]
        self.assertNotIn(token_id, active_ids)

        # Verify the revoked token no longer authenticates
        from udata.core.api_token.models import ApiToken

        token, error = ApiToken.authenticate(plaintext)
        self.assertIsNone(token)
        self.assertEqual(error, "revoked")

    def test_revoke_nonexistent_token(self):
        """It should return 404 for a non-existent token"""
        self.login()
        response = self.delete(url_for("api.my_api_token", api_token="000000000000000000000000"))
        self.assert404(response)

    def test_multiple_tokens(self):
        """It should support multiple active tokens"""
        self.login()
        resp1 = self.post(url_for("api.my_api_tokens"), {"name": "Token 1"})
        resp2 = self.post(url_for("api.my_api_tokens"), {"name": "Token 2"})
        self.assert201(resp1)
        self.assert201(resp2)
        token1 = resp1.json["token"]
        token2 = resp2.json["token"]
        token1_id = resp1.json["id"]

        # Both tokens should work
        from udata.core.api_token.models import ApiToken

        self.assertIsNotNone(ApiToken.authenticate(token1)[0])
        self.assertIsNotNone(ApiToken.authenticate(token2)[0])

        # Revoke token1
        self.delete(url_for("api.my_api_token", api_token=token1_id))

        # token1 no longer works, token2 still works
        self.assertIsNone(ApiToken.authenticate(token1)[0])
        self.assertIsNotNone(ApiToken.authenticate(token2)[0])

    def test_get_me_no_apikey_field(self):
        """GET /me should no longer contain the apikey field"""
        self.login()
        response = self.get(url_for("api.me"))
        self.assert200(response)
        self.assertNotIn("apikey", response.json)

    def test_delete(self):
        """It should delete the connected user"""
        user = self.login()
        user_email = user.email
        self.assertIsNone(user.deleted)
        other_user = UserFactory()
        members = [Member(user=user), Member(user=other_user)]
        organization = OrganizationFactory(members=members)
        disc_msg_content = faker.sentence()
        disc_msg = DiscMsg(content=disc_msg_content, posted_by=user)
        other_disc_msg_content = faker.sentence()
        other_disc_msg = DiscMsg(content=other_disc_msg_content, posted_by=other_user)
        discussion = DiscussionFactory(user=user, discussion=[disc_msg, other_disc_msg])
        dataset = DatasetFactory(owner=user)
        reuse = ReuseFactory(owner=user)
        resource = CommunityResourceFactory(owner=user)
        activity = UserCreatedDataset.objects().create(actor=user, related_to=dataset)

        following = Follow.objects().create(follower=user, following=other_user)
        followed = Follow.objects().create(follower=other_user, following=user)

        with capture_mails() as mails:
            response = self.delete(url_for("api.me"))
        self.assertEqual(len(mails), 1)
        self.assertEqual(mails[0].send_to, set([user_email]))
        self.assertEqual(mails[0].subject, _("Account deletion"))
        self.assert204(response)

        user.reload()
        organization.reload()
        discussion.reload()
        dataset.reload()
        reuse.reload()
        resource.reload()
        activity.reload()

        # The following are deleted
        with self.assertRaises(Follow.DoesNotExist):
            following.reload()
        # The followers are deleted
        with self.assertRaises(Follow.DoesNotExist):
            followed.reload()

        # The personal data of the user are anonymized
        self.assertEqual(user.email, "{}@deleted".format(user.id))
        self.assertEqual(user.password, None)
        self.assertEqual(user.active, False)
        self.assertEqual(user.first_name, "DELETED")
        self.assertEqual(user.last_name, "DELETED")
        self.assertFalse(bool(user.avatar))
        self.assertEqual(user.avatar_url, None)
        self.assertEqual(user.website, None)
        self.assertEqual(user.about, None)

        # The user is marked as deleted
        self.assertIsNotNone(user.deleted)

        # The user is removed from his organizations
        self.assertEqual(len(organization.members), 1)
        self.assertEqual(organization.members[0].user.id, other_user.id)

        # The discussions are kept but the messages are anonymized
        self.assertEqual(len(discussion.discussion), 2)
        self.assertEqual(discussion.discussion[0].posted_by.fullname, "DELETED DELETED")
        self.assertEqual(discussion.discussion[1].content, other_disc_msg_content)

        # The datasets are unchanged
        self.assertEqual(dataset.owner, user)

        # The reuses are unchanged
        self.assertEqual(reuse.owner, user)

        # The community resources are unchanged
        self.assertEqual(resource.owner, user)

        # The activities are unchanged
        self.assertEqual(activity.actor, user)

    def test_expired_token_auth_returns_401(self):
        """Should return 401 with 'Expired API token' for an expired token"""
        from udata.core.api_token.models import ApiToken

        user = UserFactory()
        expired = datetime.now(timezone.utc) - timedelta(hours=1)
        token, plaintext = ApiToken.generate(user, expires_at=expired)

        response = self.get(url_for("api.me"), headers={"X-API-KEY": plaintext})
        self.assert401(response)
        self.assertIn("Expired", response.json["message"])

    def test_expired_token_with_naive_datetime(self):
        """authenticate() should not crash comparing naive vs aware datetimes"""
        from udata.core.api_token.models import ApiToken

        user = UserFactory()
        # Simulate a naive datetime as MongoDB might return.
        # Without the timezone fix, this would raise:
        # TypeError: can't compare offset-naive and offset-aware datetimes
        future_naive = datetime.utcnow() + timedelta(days=30)
        token, plaintext = ApiToken.generate(user, expires_at=future_naive)

        result, error = ApiToken.authenticate(plaintext)
        self.assertIsNotNone(result)
        self.assertIsNone(error)

        # Also verify the expired naive case
        past_naive = datetime.utcnow() - timedelta(hours=1)
        token2, plaintext2 = ApiToken.generate(user, expires_at=past_naive)

        result2, error2 = ApiToken.authenticate(plaintext2)
        self.assertIsNone(result2)
        self.assertEqual(error2, "expired")

    def test_revoked_token_auth_returns_401(self):
        """Should return 401 with 'Revoked API token' for a revoked token"""
        from udata.core.api_token.models import ApiToken

        user = UserFactory()
        token, plaintext = ApiToken.generate(user)
        token.revoke()

        response = self.get(url_for("api.me"), headers={"X-API-KEY": plaintext})
        self.assert401(response)
        self.assertIn("Revoked", response.json["message"])

    def test_revoke_already_revoked_token_returns_410(self):
        """Should return 410 when trying to revoke an already revoked token"""
        self.login()
        create_response = self.post(url_for("api.my_api_tokens"))
        self.assert201(create_response)
        token_id = create_response.json["id"]

        # First revocation succeeds
        response = self.delete(url_for("api.my_api_token", api_token=token_id))
        self.assert204(response)

        # Second revocation returns 410
        response = self.delete(url_for("api.my_api_token", api_token=token_id))
        self.assert410(response)
