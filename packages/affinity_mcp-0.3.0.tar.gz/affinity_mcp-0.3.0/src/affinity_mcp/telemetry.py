"""Telemetry for the Affinity MCP server.

HTTP mode  → OTel SDK + OTLP exporter: traces and metrics are exported via the
             OpenTelemetry Protocol (OTLP) to whatever backend is configured.
             In hosted environments this is the Datadog agent, which accepts
             OTLP natively on port 4318 (HTTP).
STDIO mode → loguru only: everything stays local on the user's machine.

Vendor neutrality
-----------------
Traces and metrics use the OpenTelemetry API; in HTTP mode the SDK sends OTLP.
Logging stays on loguru (JSON in HTTP mode) with trace/span IDs taken from the
OTel context — not the OpenTelemetry Logs API. There are no vendor-specific
imports in this file.

  Tracing  → opentelemetry.trace   + OTLPSpanExporter
  Metrics  → opentelemetry.metrics + OTLPMetricExporter
  Logging  → loguru + OTel context (trace_id / span_id on records)

To switch backends (e.g. from Datadog to Grafana), change the environment
variable OTEL_EXPORTER_OTLP_ENDPOINT — no code changes required.

  Datadog agent : http://<agent-host>:4318   (set via DD_AGENT_HOST or KUBERNETES_HOST_IP)
  Grafana Tempo : http://<tempo-host>:4318
  Jaeger        : http://<jaeger-host>:4318

In STDIO mode no providers are set, so OTel returns built-in no-op
implementations for both tracers and meters — zero overhead, zero config.

Sampling
--------
Trace sampling rate defaults to 100 % and is configurable via
OTEL_TRACES_SAMPLER_ARG (a float in the range 0.0–1.0).  Invalid or
out-of-range values fall back to the default with a warning.
"""

from __future__ import annotations

import atexit
import functools
import inspect
import os
import sys
import threading
import time
from typing import TYPE_CHECKING, Any, Callable, Awaitable, Final

from loguru import logger
from opentelemetry import metrics as otel_metrics
from opentelemetry import trace as otel_trace
from opentelemetry.trace import StatusCode


from .context import TransportMode

if TYPE_CHECKING:
    from loguru import Record

AFFINITY_MCP: Final = "affinity-mcp"

# Lazily created on first tool call so HTTP mode can install MeterProvider first.
_tool_instruments: tuple[Any, Any, Any] | None = None
_tool_instruments_lock = threading.Lock()

# Set when HTTP telemetry initialises; used for graceful shutdown.
_tracer_provider: Any = None
_meter_provider: Any = None
_otel_atexit_registered = False


def _get_tool_instruments() -> tuple[Any, Any, Any]:
    """Return shared counters and histogram bound to the current global MeterProvider."""
    global _tool_instruments
    if _tool_instruments is not None:
        return _tool_instruments
    with _tool_instruments_lock:
        if _tool_instruments is not None:
            return _tool_instruments
        meter = otel_metrics.get_meter(AFFINITY_MCP)
        _tool_instruments = (
            meter.create_counter(
                "affinity.mcp.tool.calls",
                description="Number of MCP tool invocations",
                unit="1",
            ),
            meter.create_counter(
                "affinity.mcp.tool.errors",
                description="Number of MCP tool invocations that raised an exception",
                unit="1",
            ),
            meter.create_histogram(
                "affinity.mcp.tool.duration_ms",
                description="Duration of MCP tool invocations in milliseconds",
                unit="ms",
            ),
        )
        return _tool_instruments


def _build_otel_resource():
    from importlib import metadata

    from opentelemetry.sdk.resources import Resource

    try:
        version = metadata.version(AFFINITY_MCP)
    except metadata.PackageNotFoundError:
        version = "0.0.0"
    return Resource.create({"service.name": AFFINITY_MCP, "service.version": version})


def _shutdown_otel_providers() -> None:
    global _tracer_provider, _meter_provider
    if _meter_provider is not None:
        mp = _meter_provider
        _meter_provider = None
        try:
            mp.shutdown()
        except Exception:
            pass
    if _tracer_provider is not None:
        tp = _tracer_provider
        _tracer_provider = None
        try:
            tp.shutdown()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def configure_telemetry(mode: TransportMode) -> None:
    """Configure telemetry based on transport mode. Call once at startup.

    HTTP mode always activates full OTel instrumentation. STDIO mode activates
    it only when OTEL_EXPORTER_OTLP_ENDPOINT is explicitly set, allowing local
    MCP server users to opt in to observability with their own OTel collector.
    """
    if mode == TransportMode.HTTP or os.getenv("OTEL_EXPORTER_OTLP_ENDPOINT"):
        _configure_otel()
    # STDIO without OTEL_EXPORTER_OTLP_ENDPOINT: loguru defaults are correct
    # and OTel no-ops require no setup


def instrument_tool(
    func: Callable[..., Awaitable[Any]],
) -> Callable[..., Awaitable[Any]]:
    """Decorator that adds an OTel trace span and OTel metrics to every MCP tool call.

    Entirely vendor-neutral — no backend-specific code here. The backend is
    determined solely by which providers and exporters were configured at
    startup in configure_telemetry().

    Works in both transport modes with zero branching:
    - HTTP mode: real spans and metrics are exported via OTLP.
    - STDIO mode: OTel returns built-in no-op tracer and meter — zero overhead.

    Metric instruments are created once on first tool invocation and reused.
    """

    @functools.wraps(func)
    async def wrapper(*args: Any, **kwargs: Any) -> Any:
        tool_name = func.__name__
        attributes = {"tool": tool_name}

        tracer = otel_trace.get_tracer(AFFINITY_MCP)
        calls_counter, errors_counter, duration_histogram = _get_tool_instruments()

        with tracer.start_as_current_span(f"{tool_name}") as span:
            span.set_attribute("affinity.tool.name", tool_name)
            start = time.monotonic()
            status = "success"
            try:
                result = await func(*args, **kwargs)
                span.set_status(StatusCode.OK)
                span.set_attribute("http.status_code", 200)
                return result
            except Exception as exc:
                status = "error"
                span.record_exception(exc)
                span.set_status(StatusCode.ERROR, str(exc))
                span.set_attribute("http.status_code", 500)
                errors_counter.add(
                    1, attributes={**attributes, "error": type(exc).__name__}
                )
                raise
            finally:
                calls_counter.add(1, attributes={**attributes, "status": status})
                duration_ms = (time.monotonic() - start) * 1000
                duration_histogram.record(duration_ms, attributes=attributes)

    return wrapper


# ---------------------------------------------------------------------------
# Internal — HTTP mode setup
# ---------------------------------------------------------------------------


def _configure_otel() -> None:
    global _otel_atexit_registered
    for step in (_configure_tracing, _configure_json_logging, _configure_metrics):
        try:
            step()
        except Exception as exc:
            logger.warning(
                "Telemetry setup step skipped",
                step=getattr(step, "__name__", repr(step)),
                error=str(exc),
            )
    if not _otel_atexit_registered:
        atexit.register(_shutdown_otel_providers)
        _otel_atexit_registered = True


def _configure_tracing() -> None:
    """Set up the OTel TracerProvider with an OTLP span exporter.

    Traces are exported via OTLP to the endpoint resolved by _otlp_endpoint().
    No vendor-specific code here — any OTLP-compatible backend will receive the traces.

    Loguru records are patched to include the current OTel trace_id and span_id
    so log lines can be correlated with their trace in any backend.
    """
    global _tracer_provider
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import BatchSpanProcessor
    from opentelemetry.exporter.otlp.proto.http.trace_exporter import (  # type: ignore[import-not-found]
        OTLPSpanExporter,
    )
    from opentelemetry.trace import set_tracer_provider
    from opentelemetry.propagate import set_global_textmap
    from opentelemetry.trace.propagation.tracecontext import (
        TraceContextTextMapPropagator,
    )

    from opentelemetry.sdk.trace.sampling import TraceIdRatioBased, ParentBased

    endpoint = _otlp_endpoint()
    _DEFAULT_SAMPLE_RATE = 1.0
    raw = os.getenv("OTEL_TRACES_SAMPLER_ARG", str(_DEFAULT_SAMPLE_RATE))
    try:
        sample_rate = float(raw)
        if not (0.0 <= sample_rate <= 1.0) or sample_rate != sample_rate:  # NaN check
            raise ValueError(f"out of range: {raw}")
    except ValueError:
        logger.bind(value=raw, default=_DEFAULT_SAMPLE_RATE).warning(
            "Invalid OTEL_TRACES_SAMPLER_ARG value, falling back to default"
        )
        sample_rate = _DEFAULT_SAMPLE_RATE
    sampler = ParentBased(TraceIdRatioBased(sample_rate))
    exporter = OTLPSpanExporter(endpoint=f"{endpoint}/v1/traces")
    provider = TracerProvider(resource=_build_otel_resource(), sampler=sampler)
    provider.add_span_processor(BatchSpanProcessor(exporter))
    set_tracer_provider(provider)
    _tracer_provider = provider
    # Tracecontext-only: replaces the default tracecontext+baggage composite.
    # Baggage propagation is intentionally omitted
    # To re-enable baggage: CompositePropagator([TraceContextTextMapPropagator(), W3CBaggagePropagator()])
    set_global_textmap(TraceContextTextMapPropagator())

    def _patcher(record: Record) -> None:
        """Inject OTel trace/span IDs into each loguru record.

        This is what lets you correlate a log line with its trace in
        Datadog, Grafana, or any other backend — they share the same IDs.
        """
        span = otel_trace.get_current_span()
        ctx = span.get_span_context()
        if ctx.is_valid:
            record["extra"]["trace_id"] = format(ctx.trace_id, "032x")
            record["extra"]["span_id"] = format(ctx.span_id, "016x")

    logger.configure(patcher=_patcher)
    logger.bind(endpoint=endpoint).info("OTel tracing enabled")


def _configure_json_logging() -> None:
    """Switch loguru to newline-delimited JSON so any log aggregator can parse it.

    The Datadog agent (or any log collector) running on the K8s node watches
    stderr of each pod and expects JSON so it can extract structured fields
    like level, message, and the trace/span IDs injected by _configure_tracing().

    FastMCP (and the underlying MCP SDK) emit plain-text logs via the stdlib
    ``logging`` module under the ``mcp`` hierarchy.  We intercept ERROR and
    CRITICAL records and forward them to loguru so they appear as structured
    JSON alongside our own logs.  Everything below ERROR is silenced.
    """
    import logging

    class _InterceptHandler(logging.Handler):
        """Forward stdlib log records to loguru as structured JSON."""

        def emit(self, record: logging.LogRecord) -> None:
            # Map the stdlib level name (e.g. "ERROR") to loguru's name.
            # Fall back to the numeric value if loguru doesn't know the name.
            try:
                level = logger.level(record.levelname).name
            except ValueError:
                level = record.levelno  # type: ignore[assignment]
            # Walk up the call stack until we leave the stdlib logging module
            # so that loguru reports the original call site, not a frame inside
            # the logging machinery. This follows the pattern from the loguru docs:
            # https://loguru.readthedocs.io/en/stable/overview.html#entirely-compatible-with-standard-logging
            frame, depth = inspect.currentframe(), 0
            while frame and (
                depth == 0 or frame.f_code.co_filename == logging.__file__
            ):
                frame = frame.f_back  # type: ignore[assignment]
                depth += 1
            # depth tells loguru how many frames to skip when reporting the
            # source location; exception passes along the original traceback.
            logger.opt(depth=depth, exception=record.exc_info).log(
                level, record.getMessage()
            )

    # Set the level on both the logger and the handler. The logger-level check
    # is bypassed when child loggers (e.g. mcp.server.fastmcp) propagate records
    # up to this handler, so the handler-level acts as a second gate to ensure
    # nothing below ERROR reaches loguru regardless of where it originated.
    handler = _InterceptHandler()
    handler.setLevel(logging.ERROR)

    mcp_logger = logging.getLogger("mcp")
    mcp_logger.setLevel(logging.ERROR)
    mcp_logger.handlers = [handler]
    mcp_logger.propagate = False

    logger.remove()
    logger.add(
        sys.stderr,
        level=os.getenv("LOG_LEVEL", "INFO").upper(),
        serialize=True,  # emit JSON
        diagnose=False,  # never include local variable values in tracebacks (PII risk)
        backtrace=True,
        colorize=False,
    )


def _configure_metrics() -> None:
    """Set up the OTel MeterProvider with an OTLP metric exporter.

    Metrics are exported via OTLP to the endpoint resolved by _otlp_endpoint().
    No vendor-specific code here — any OTLP-compatible backend will receive the metrics.
    """
    global _meter_provider
    from opentelemetry.sdk.metrics import MeterProvider
    from opentelemetry.sdk.metrics.export import PeriodicExportingMetricReader
    from opentelemetry.exporter.otlp.proto.http.metric_exporter import (  # type: ignore[import-not-found]
        OTLPMetricExporter,
    )
    from opentelemetry.metrics import set_meter_provider

    endpoint = _otlp_endpoint()
    exporter = OTLPMetricExporter(endpoint=f"{endpoint}/v1/metrics")
    reader = PeriodicExportingMetricReader(exporter)
    provider = MeterProvider(
        resource=_build_otel_resource(),
        metric_readers=[reader],
    )
    set_meter_provider(provider)
    _meter_provider = provider
    logger.info("OTel metrics enabled", endpoint=endpoint)


def _otlp_endpoint() -> str:
    """Resolve the OTLP collector endpoint.

    Checks environment variables in order:
    1. OTEL_EXPORTER_OTLP_ENDPOINT — standard OTel env var, takes priority
    2. DD_AGENT_HOST / KUBERNETES_HOST_IP — Datadog agent host, used when
       the standard OTel var is not set (common in Affinity's K8s setup)

    The Datadog agent accepts OTLP on port 4318 (HTTP) by default.
    """
    if endpoint := os.getenv("OTEL_EXPORTER_OTLP_ENDPOINT"):
        return endpoint.rstrip("/")

    host = os.getenv("DD_AGENT_HOST") or os.getenv("KUBERNETES_HOST_IP", "localhost")
    return f"http://{host}:4318"
