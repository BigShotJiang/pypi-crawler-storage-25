from enum import StrEnum, IntEnum
from pydantic import BaseModel, Field


class EntityType(StrEnum):
    """Entity types for company, person, and opportunity."""

    COMPANY = "company"
    PERSON = "person"
    OPPORTUNITY = "opportunity"

    def to_plural(self) -> str:
        return {
            EntityType.COMPANY: "companies",
            EntityType.PERSON: "persons",
            EntityType.OPPORTUNITY: "opportunities",
        }[self]

    def to_entity_id_v1(self) -> str:
        return {
            EntityType.COMPANY: "organization_id",
            EntityType.PERSON: "person_id",
            EntityType.OPPORTUNITY: "opportunity_id",
        }[self]


class FieldType(StrEnum):
    """Available field types for entity queries."""

    ENRICHED = "enriched"
    GLOBAL = "global"
    RELATIONSHIP_INTELLIGENCE = "relationship-intelligence"
    LIST = "list"

    @classmethod
    def all(cls) -> list[str]:
        return [ft.value for ft in cls]

    @classmethod
    def entity_field_types(cls) -> list[str]:
        """Get field types applicable to entities (person/company).

        Excludes 'list' as it's only applicable to list entries.
        """
        return [ft.value for ft in cls if ft != cls.LIST]


class LoggingType(IntEnum):
    """Logging type classification for interactions."""

    ALL = 0
    MANUAL = 1


class InteractionType(IntEnum):
    """Types of interactions"""

    MEETING = 0


class FieldValueType(StrEnum):
    """Types of field values"""

    DATETIME = "datetime"
    COMPANY = "company"
    COMPANY_MULTI = "company-multi"
    PERSON = "person"
    PERSON_MULTI = "person-multi"
    NUMBER = "number"
    NUMBER_MULTI = "number-multi"
    LOCATION = "location"
    LOCATION_MULTI = "location-multi"
    DROPDOWN = "dropdown"
    DROPDOWN_MULTI = "dropdown-multi"
    RANKED_DROPDOWN = "ranked-dropdown"
    TEXT = "text"
    FILTERABLE_TEXT = "filterable-text"
    FILTERABLE_TEXT_MULTI = "filterable-text-multi"


class ReminderType(IntEnum):
    """Reminder recurrence type."""

    ONE_TIME = 0
    RECURRING = 1


class ReminderResetType(IntEnum):
    """Reset trigger for recurring reminders. Only valid when type is RECURRING."""

    INTERACTION = 0
    EMAIL = 1
    EVENT = 2


class ReminderStatus(IntEnum):
    """Reminder status."""

    COMPLETED = 0
    ACTIVE = 1
    OVERDUE = 2


class Location(BaseModel):
    """Location object for field values."""

    model_config = {"populate_by_name": True}

    street_address: str | None = Field(default=None, alias="streetAddress")
    city: str | None = None
    state: str | None = None
    country: str | None = None
    continent: str | None = None
