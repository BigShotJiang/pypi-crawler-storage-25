from typing import Any

from ..utils.affinity_api import AffinityAPI
from ..utils.url import construct_tenant_url
from ..types import FieldType


async def get_lists(cursor: str | None = None, limit: int = 100) -> dict[str, Any]:
    """Get all lists in the user's organization that they have access to

    Args:
        cursor: Cursor for the next or previous page.
        limit: The number of items to include in the page. Default is 100.

    Returns:
        List of JSON objects containing list metadata such as
        list name, entity type, creator ID, and owner ID.

    """
    params = {
        k: v
        for k, v in {
            "cursor": cursor,
            "limit": limit,
        }.items()
        if v is not None
    }
    async with AffinityAPI() as client:
        return await client.get("/v2/lists", params=params)


async def get_list_info(list_id: int) -> dict[str, Any]:
    """Get metadata on a single list

    Args:
        list_id (required): ID of list

    Returns:
        JSON object containing list metadata such as
        list name, entity type, creator ID, and owner ID.
    """
    async with AffinityAPI() as client:
        response = await client.get(f"/v2/lists/{list_id}")

    tenant_url = await construct_tenant_url()
    response["list_url"] = f"{tenant_url}/lists/{response['id']}"
    return response


async def get_list_entries(
    list_id: int,
    cursor: str | None = None,
    limit: int = 10,
    field_ids: list[str] | None = None,
    field_types: list[FieldType] | None = None,
) -> dict[str, Any]:
    """Paginate through list entries on a given list. Each list entry contains basic
    information about the related person/company/opportunity and list-specific field data.
    By default, returns only list-specific fields.

    IMPORTANT: field_ids and field_types are mutually exclusive. They cannot be used together.

    WARNING: Lists can contain many entries with large field data.
    Best practices to minimize response size:
      - MUST start with limit=10 (default), increase only if needed
      - Select specific fields using field_ids or field_types (use get_list_fields tool to identify fields)
      - Request additional field types (enriched, global, relationship-intelligence) only when needed
      - Use pagination (cursor) to iterate through results

    Args:
        list_id (required): ID of list
        cursor: Cursor for the next or previous page.
        limit: The number of items to include in the page. Default is 10, maximum is 100.
        field_ids: List of field IDs to return.
        field_types: List of field types to return. Defaults to ['list']. Available types: 'enriched', 'global', 'relationship-intelligence', 'list'

    Returns:
        List of JSON objects containing list entry metadata such as entity info and
        list-specific field data.
    """
    field_types_str = (
        [ft.value for ft in field_types]
        if field_types
        else ([FieldType.LIST.value] if field_ids is None else None)
    )

    params = {
        k: v
        for k, v in {
            "cursor": cursor,
            "limit": limit,
            "fieldIds": field_ids,
            "fieldTypes": field_types_str,
        }.items()
        if v is not None
    }
    async with AffinityAPI() as client:
        return await client.get(f"/v2/lists/{list_id}/list-entries", params=params)


async def get_single_list_entry(
    list_id: int,
    list_entry_id: int,
    field_ids: list[str] | None = None,
    field_types: list[FieldType] | None = None,
) -> dict[str, Any]:
    """Retrieve a single list entry from the given list. The list entry contains basic
    information about the related person/company/opportunity and list-specific field data.
    By default, returns only list-specific fields.

    IMPORTANT: field_ids and field_types are mutually exclusive. They cannot be used together.

    WARNING: List entry may contain large field data.
    Best practices to minimize response size:
    - Select specific fields using field_ids or field_types (use get_list_fields tool to identify fields)
    - Request additional field types (enriched, global, relationship-intelligence) only when needed

    Args:
        list_id (required): ID of list
        list_entry_id (required): ID of list entry
        field_ids: List of field IDs to return.
        field_types: List of field types to return. Defaults to ['list']. Available types: 'enriched', 'global', 'relationship-intelligence', 'list'
    """
    field_types_str = (
        [ft.value for ft in field_types]
        if field_types
        else ([FieldType.LIST.value] if field_ids is None else None)
    )

    params = {
        k: v
        for k, v in {
            "fieldIds": field_ids,
            "fieldTypes": field_types_str,
        }.items()
        if v is not None
    }
    async with AffinityAPI() as client:
        return await client.get(
            f"/v2/lists/{list_id}/list-entries/{list_entry_id}", params=params
        )


async def create_list_entry(list_id: int, entity_id: int) -> dict[str, Any]:
    """Adds an existing company or person as a list entry on the specified list. Opportunities
    CANNOT be added using this tool.

    Args:
        list_id: ID of the list where the entry is being added.
        entity_id: ID of the existing person or company to add to this list.

    Returns:
        JSON object containing information about the newly created list entry.
    """
    async with AffinityAPI() as client:
        return await client.post(
            f"/lists/{list_id}/list-entries", body={"entity_id": entity_id}
        )
