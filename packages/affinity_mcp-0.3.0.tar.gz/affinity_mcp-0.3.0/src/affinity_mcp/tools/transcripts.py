from typing import Any

from ..utils.affinity_api import AffinityAPI


async def get_transcript_fragments(
    transcript_id: int,
    cursor: str | None = None,
    limit: int = 20,
) -> dict[str, Any]:
    """Get dialogue fragments (individual speaker turns) from a transcript.
    Use pagination to retrieve all fragments from long transcripts.

    To get transcripts for a specific entity (company, person, opportunity):
    1. Use get_notes_for_entity to get notes for that entity
    2. Look for notes where type is "ai-notetaker" or "ai-notetaker-reply"
    3. Those notes have a transcriptId field - use it with this tool

    Args:
        transcript_id: The transcript ID from the transcriptId field in AI Notetaker
            notes (returned by get_notes_for_entity).
        cursor: Cursor for the next or previous page.
        limit: Number of items per page. Default is 20, max is 100.

    Returns:
        Paginated list of dialogue fragments with total count. Each fragment contains
        speaker, content, and timestamps.
    """
    params = {
        k: v
        for k, v in {
            "cursor": cursor,
            "limit": limit,
            "totalCount": True,
        }.items()
        if v is not None
    }

    async with AffinityAPI() as client:
        return await client.get(
            f"/v2/transcripts/{transcript_id}/fragments", params=params
        )
