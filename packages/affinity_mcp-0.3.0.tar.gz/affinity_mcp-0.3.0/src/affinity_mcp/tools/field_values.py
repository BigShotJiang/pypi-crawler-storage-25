from typing import Any

from pydantic import BaseModel, Field

from ..types import EntityType, Location, FieldValueType
from ..utils.affinity_api import AffinityAPI


class ValueToUpsert(BaseModel):
    """Field value to upsert. Structure of data depends on the type of field.

    Supported field types:
    - text: str (ex. "Some new text")
    - filterable-text: str (ex. "Some new text")
    - filterable-text-multi: list[str] (ex. ["Some new text", "Another new text"])
    - datetime: str in ISO 8601 format (ex. "2023-01-01T00:00:00Z")
    - company: dict[str, int] (ex. {"id": 1})
    - company-multi: list[dict[str, int]] (ex. [{"id": 1}, {"id": 2}])
    - person: dict[str, int] (ex. {"id": 2})
    - person-multi: list[dict[str, int]] (ex. [{"id": 1}, {"id": 2}])
    - location: Location object (ex. Location(street_address="123 Main St", city="SF", state="CA", country="US"))
    - location-multi: list[Location] (ex. [Location(city="SF", state="CA"), Location(city="NYC", state="NY")])
    - number: int (ex. 1000000)
    - number-multi: list[int] (ex. [100, 200, 300])
    - dropdown: dict[str, int] (ex. {"dropdownOptionId": 2})
    - dropdown-multi: list[dict[str, int]] (ex. [{"dropdownOptionId": 1}, {"dropdownOptionId": 2}])
    - ranked-dropdown: dict[str, int] (ex. {"dropdownOptionId": 2})
    """

    type: FieldValueType
    data: str | int | dict | list | Location | None


class FieldValueUpsert(BaseModel):
    """A single field value upsert request."""

    id: str = Field(
        description="A human readable field ID (ex. affinity-data-description)"
    )
    value: ValueToUpsert


async def get_entity_field_values(
    entity_type: EntityType,
    entity_id: int,
) -> dict[str, Any]:
    """Get field values for an entity. Use this tool if the entity is NOT on a list. If
    the entity is on a list, and you have the list context, prefer get_single_list_entry tool.

    Args:
        entity_type: Type of entity ("company", "person", or "opportunity").
        entity_id: ID of the entity

    Returns:
        List of JSON objects containing field value data
    """
    params = {
        entity_type.to_entity_id_v1(): entity_id,
    }

    async with AffinityAPI() as client:
        field_values = await client.get("/field-values", params=params)
        return {"data": field_values}


async def upsert_entity_field_value(
    value: str | int | Location | None,
    field_value_id: int | None = None,
    field_id: int | None = None,
    entity_id: int | None = None,
) -> dict[str, Any]:
    """Upsert a field value for an entity. Use this tool if the entity is NOT on a list.
    If the entity is on a list, and you have list context, prefer upsert_list_entry_field_values tool.

    This tool has two modes of operation:
      1. UPDATE MODE (provide field_value_id):
         - Updates an existing field value with the new value
         - Clears the field if value=None. Note that after clearing, the field_value_id no longer exists.
         You must use CREATE mode to set the value again.
         - For multi-value fields: updates only the specific field_value_id in place
         - Example: upsert_entity_field_value(value=200, field_value_id=12345)
      2. CREATE MODE (provide field_id + entity_id):
         - Creates a new field value, cannot be empty
         - For multi-value fields: adds a new value without affecting existing ones
         - For single-value fields: sets the initial value (errors if already exists)
         - Example: upsert_entity_field_value(value=200, field_id=456, entity_id=789)

    Args:
        value: New value. Structure depends on field type:
        - dropdown: str representing dropdown value, NOT option ID (ex. "In Progress")
        - ranked-dropdown: int representing dropdown option ID (ex. 123). Use get_list_field_dropdown_options to obtain the ID
        - number: int (ex. 1000000)
        - person: int representing person ID (ex. 1)
        - company: int representing company ID (ex. 2)
        - location: Location (ex. Location(city="San Francisco", state="CA"))
        - datetime: str in ISO 8601 format (ex. "2023-01-01T00:00:00Z")
        - text: str (ex. "Some new text")
        - None: clears/empties the field (only valid in UPDATE mode)
        field_value_id: ID of the field value
        field_id: ID of the field
        entity_id: ID of the person, company, or opportunity

    Returns:
        JSON object containing the upserted field value

    Raises:
        ValueError: if field_id, entity_id, and field_value_id are all provided
    """
    is_create = field_id is not None and entity_id is not None
    is_update = field_value_id is not None
    if is_create and is_update:
        raise ValueError(
            "Cannot provide both field_value_id (UPDATE mode) and field_id/entity_id (CREATE mode)"
        )
    if not is_create and not is_update:
        raise ValueError(
            "Must provide either field_value_id (UPDATE MODE) or field_id/entity_id (CREATE MODE)"
        )

    formatted_value = (
        value.model_dump(exclude_none=True) if isinstance(value, Location) else value
    )

    if is_create:
        if formatted_value is None:
            raise ValueError("Cannot create empty field value")
        assert field_id is not None and entity_id is not None
        return await _create_entity_field_value(formatted_value, field_id, entity_id)
    else:
        assert field_value_id is not None
        if formatted_value is None:
            return await _delete_entity_field_value(field_value_id)
        else:
            return await _update_entity_field_value(formatted_value, field_value_id)


async def _create_entity_field_value(
    value: str | int | dict,
    field_id: int,
    entity_id: int | None = None,
) -> dict[str, Any]:
    """Create a new field value for an entity (company, person, opportunity)."""
    body = {"field_id": field_id, "value": value, "entity_id": entity_id}
    async with AffinityAPI() as client:
        return await client.post("/field-values", body=body)


async def _update_entity_field_value(
    value: str | int | dict,
    field_value_id: int,
) -> dict[str, Any]:
    """Update an existing field value"""
    async with AffinityAPI() as client:
        return await client.put(
            f"/field-values/{field_value_id}", body={"value": value}
        )


async def _delete_entity_field_value(field_value_id: int) -> dict[str, Any]:
    """Delete an existing field value"""
    async with AffinityAPI() as client:
        return await client.delete(f"/field-values/{field_value_id}")


async def upsert_list_entry_field_values(
    list_id: int, list_entry_id: int, upserts: list[FieldValueUpsert]
) -> dict[str, Any]:
    """Upsert up to 100 field values for a list entry.

    Args:
        list_id: ID of list
        list_entry_id: ID of list entry
        upserts: List of field value upserts. Each item has:
            - id (str): The field ID. Use get_list_fields or get_single_list_entry
              tools to discover field IDs.
            - value (ValueToUpsert): An object with `type` and `data` keys.
              Use get_list_field_dropdown_options to look up dropdown option IDs.

    Examples:
        - Text field
        {"id": "affinity-data-description", "value": {"type": "text", "data": "Top prospect"}}

        - Number field
        {"id": "my-revenue-field", "value": {"type": "number", "data": 5000000}}

        - Ranked-dropdown field (get option IDs from get_list_field_dropdown_options)
        {"id": "my-stage-field", "value": {"type": "ranked-dropdown", "data": {"dropdownOptionId": 42}}}

        - Person-multi field
        {"id": "my-owners-field", "value": {"type": "person-multi", "data": [{"id": 101}, {"id": 202}]}}

    Returns:
        Dict containing the name of the successful operation
    """
    formatted_updates = [
        {
            "id": upsert.id,
            "value": {
                "type": upsert.value.type.value,
                "data": _maybe_format_value(upsert.value.type, upsert.value.data),
            },
        }
        for upsert in upserts
    ]

    body = {"operation": "update-fields", "updates": formatted_updates}

    async with AffinityAPI() as client:
        result = await client.patch(
            f"/v2/lists/{list_id}/list-entries/{list_entry_id}/fields", body=body
        )
        return result


def _maybe_format_value(value_type: FieldValueType, data: Any) -> Any:
    """Format value if type is location or location-multi, else return the value as is.
    If the LLM used a plain dict instead of a Location object, we need to convert it
    to a Location object to ensure it has all fields and camel casing.
    """
    if value_type == FieldValueType.LOCATION:
        if isinstance(data, dict):
            data = Location(**data)
        if isinstance(data, Location):
            return data.model_dump(by_alias=True)
    elif value_type == FieldValueType.LOCATION_MULTI and isinstance(data, list):
        locations = [
            Location(**item) if isinstance(item, dict) else item for item in data
        ]
        return [loc.model_dump(by_alias=True) for loc in locations]
    return data
