from typing import Any
from ..utils.affinity_api import AffinityAPI
from ..types import EntityType, ReminderResetType, ReminderStatus, ReminderType


async def get_reminders(
    entity_id: int | None = None,
    entity_type: EntityType | None = None,
    creator_id: int | None = None,
    owner_id: int | None = None,
    completer_id: int | None = None,
    reminder_type: ReminderType | None = None,
    reset_type: ReminderResetType | None = None,
    status: ReminderStatus | None = None,
    due_before: str | None = None,
    due_after: str | None = None,
    page_size: int = 10,
    page_token: str | None = None,
) -> dict[str, Any]:
    """Returns reminders that meet the query parameters if provided.
    By default, returns reminders for all entities.

    IMPORTANT: entity_id and entity_type are only applied when both are provided; if only one is set,
               the entity filter is ignored and reminders for all entities are returned.

    Args:
        entity_id: The ID of the company, external person, or opportunity to filter reminders by.
        entity_type: The type of entity that entity_id refers to. Options: "company", "person", "opportunity".
        creator_id: Filters to reminders created by this internal person (identified by their person ID).
        owner_id: Filters to reminders assigned to this internal person (identified by their person ID).
        completer_id: Filters to reminders completed by this internal person (identified by their person ID).
        reminder_type: Filters by recurrence type:
            - ReminderType.ONE_TIME (0): One-time reminders only
            - ReminderType.RECURRING (1): Recurring reminders only
        reset_type: Filters recurring reminders by their reset trigger. Only valid when reminder_type=RECURRING.
            - ReminderResetType.INTERACTION (0): Resets on any interaction
            - ReminderResetType.EMAIL (1): Resets on email only
            - ReminderResetType.EVENT (2): Resets on event only
        status: Filters by reminder status:
            - ReminderStatus.COMPLETED (0): Completed reminders
            - ReminderStatus.ACTIVE (1): Active reminders
            - ReminderStatus.OVERDUE (2): Overdue reminders
        due_before: ISO 8601 formatted date to retrieve reminders due before this date.
            Example: "2025-01-31T00:00:00Z"
        due_after: ISO 8601 formatted date to retrieve reminders due after this date.
            Example: "2025-01-01T00:00:00Z"
        page_size: Number of results per page. Default is 10.
        page_token: The next_page_token from the previous response required to retrieve the next page of results.

    Returns:
        Structured data containing the list of reminders and pagination information.
    """

    params = {
        k: v
        for k, v in {
            **(
                {entity_type.to_entity_id_v1(): entity_id}
                if entity_type is not None and entity_id is not None
                else {}
            ),
            "creator_id": creator_id,
            "owner_id": owner_id,
            "completer_id": completer_id,
            "type": reminder_type,
            "reset_type": reset_type,
            "status": status,
            "due_before": due_before,
            "due_after": due_after,
            "page_size": page_size,
            "page_token": page_token,
        }.items()
        if v is not None
    }

    async with AffinityAPI() as client:
        return await client.get("/reminders", params=params)


async def create_reminder(
    owner_id: int,
    reminder_type: ReminderType,
    entity_id: int,
    entity_type: EntityType,
    content: str | None = None,
    due_date: str | None = None,
    reset_type: ReminderResetType | None = None,
    reminder_days: int | None = None,
    is_completed: bool | None = None,
) -> dict[str, Any]:
    """Creates a new reminder.

    SCHEDULING BY DAY NAME:
    If the user specifies a recurring reminder by day name (e.g. "every Friday", "every Sunday"),
    calculate the next occurrence of that day from today's date and use it as the due_date for
    the first reminder. Set reminder_days to match the recurrence interval
    (e.g. 7 for weekly, 14 for bi-weekly). You must still supply reset_type and the other recurring
    fields documented under reset_type and reminder_days below; this section only helps derive
    due_date and reminder_days.

    Args:
        owner_id: Required. Internal person ID who owns the reminder (team member only; not an
            external contact).
        reminder_type: Required. ReminderType.ONE_TIME (0) or ReminderType.RECURRING (1). If unclear,
            ask before calling.
        entity_id: Required with entity_type. ID of the company, external/collaborator person, or
            opportunity to attach the reminder to. If the user has not chosen a target yet, ask before calling.
        entity_type: Required with entity_id. EntityType: company, person, or opportunity.
        content: Optional description or note text for the reminder.
        due_date: Required when reminder_type is ONE_TIME; omit for recurring unless you are supplying
            a first due date (e.g. day-name scheduling). ISO 8601. If the user has not given a due date
            for a one-time reminder, ask before calling. Example: "2025-01-31T00:00:00Z"
        reset_type: Required when reminder_type is RECURRING. What triggers the reset:
            ReminderResetType.INTERACTION (0), EMAIL (1), or EVENT (2). If missing, ask before calling.
        reminder_days: Required when reminder_type is RECURRING; minimum 1. If missing, ask before calling.
        is_completed: Optional; only for ONE_TIME. Whether the reminder is completed on creation.
            Do not pass for RECURRING (the API rejects it).

    Returns:
        dict[str, Any]: API response containing the created reminder.
    """
    if reminder_type == ReminderType.ONE_TIME and due_date is None:
        raise ValueError("due_date is required for ONE_TIME reminders")

    if reminder_type == ReminderType.RECURRING:
        if reset_type is None:
            raise ValueError("reset_type is required for RECURRING reminders")
        if reminder_days is None:
            raise ValueError("reminder_days is required for RECURRING reminders")
        if reminder_days < 1:
            raise ValueError("reminder_days must be >= 1 for RECURRING reminders")
        if is_completed is not None:
            raise ValueError("is_completed cannot be used with RECURRING reminders")

    body = {
        k: v
        for k, v in {
            "owner_id": owner_id,
            "type": reminder_type,
            "content": content,
            **{entity_type.to_entity_id_v1(): entity_id},
            "due_date": due_date,
            "reset_type": reset_type,
            "reminder_days": reminder_days,
            "is_completed": is_completed,
        }.items()
        if v is not None
    }

    async with AffinityAPI() as client:
        return await client.post("/reminders", body)


async def update_reminder(
    reminder_id: int,
    owner_id: int | None = None,
    reminder_type: ReminderType | None = None,
    content: str | None = None,
    due_date: str | None = None,
    reset_type: ReminderResetType | None = None,
    reminder_days: int | None = None,
    is_completed: bool | None = None,
) -> dict[str, Any]:
    """Updates an existing reminder.

    IMPORTANT:
    - Only the fields provided will be updated; omitted fields remain unchanged.
    - Updates require the current user to be either the creator OR owner of the reminder, otherwise the API returns a permissions error.

    Args:
        reminder_id: The ID of the reminder to update.
        owner_id: Internal person ID to reassign the reminder to.
        reminder_type: ReminderType.ONE_TIME (0) or ReminderType.RECURRING (1).
        content: Description or note text for the reminder.
        due_date: ISO 8601 due date. Required when reminder_type is ONE_TIME.
            Example: "2025-01-31T00:00:00Z"
        reset_type: What triggers reset for recurring reminders. Required when reminder_type is RECURRING.
            ReminderResetType.INTERACTION (0), EMAIL (1), or EVENT (2).
        reminder_days: Recurrence interval in days. Required when reminder_type is RECURRING. Minimum 1.
        is_completed: Whether the reminder is completed. Only for ONE_TIME, Do not pass for RECURRING (the API rejects it).

    Returns:
        dict[str, Any]: API response containing the updated reminder.
    """
    if reminder_days is not None and reminder_days < 1:
        raise ValueError("reminder_days must be >= 1")
    if reminder_type == ReminderType.RECURRING and is_completed is not None:
        raise ValueError("is_completed cannot be used with RECURRING reminders")

    body = {
        k: v
        for k, v in {
            "owner_id": owner_id,
            "type": reminder_type,
            "content": content,
            "due_date": due_date,
            "reset_type": reset_type,
            "reminder_days": reminder_days,
            "is_completed": is_completed,
        }.items()
        if v is not None
    }

    async with AffinityAPI() as client:
        return await client.put(f"/reminders/{reminder_id}", body)


async def delete_reminder(
    reminder_id: int,
) -> dict[str, Any]:
    """Deletes a reminder by ID. Requires the current user to be either the creator OR owner of the reminder,
    otherwise the API returns a permissions error.

    Args:
        reminder_id: The ID of the reminder to delete.

    Returns:
        JSON object containing confirmation of successful deletion.
    """
    async with AffinityAPI() as client:
        return await client.delete(f"/reminders/{reminder_id}")
