from json import JSONDecodeError
from typing import Any

import httpx
import importlib.metadata
from loguru import logger
from opentelemetry import propagate

from ..context import TransportMode, api_key_var, transport_mode
from ..settings import settings

APP_NAME = "affinity-mcp"
AFFINITY_API_VERSION = "2024-01-01"


class AffinityAPIError(Exception):
    """Error from Affinity API request."""

    def __init__(self, message: str, status_code: int):
        super().__init__(message)
        self.status_code = status_code


class AffinityAPI:
    """Async client for Affinity API v1 and v2 endpoints.

    Uses Bearer token authentication.

    Usage:
        async with AffinityAPI() as client:
            return await client.get("/v2/persons")
    """

    def __init__(self):
        """Initialize the Affinity API client."""
        self._client = httpx.AsyncClient(
            base_url=str(settings.api_url),
            headers=self._base_headers,
            timeout=30.0,
        )

    def _get_api_key(self) -> str:
        """Resolve the API key from contextvar (HTTP mode) or settings (stdio mode)."""
        mode = transport_mode.get()
        if mode == TransportMode.HTTP:
            api_key = api_key_var.get()
            if not api_key:
                raise AffinityAPIError(
                    "Missing Authorization: Bearer <api_key> header in HTTP request",
                    401,
                )
            return api_key
        elif mode == TransportMode.STDIO:
            api_key = (
                settings.api_key.get_secret_value().strip() if settings.api_key else ""
            )
            if not api_key:
                raise ValueError(
                    "AFFINITY_API_KEY is missing. Please set it as an environment variable."
                )
            return api_key
        else:
            raise ValueError("Unsupported transport mode")

    @property
    def _base_headers(self) -> dict[str, str]:
        """Get static headers without Bearer token."""
        version = importlib.metadata.version(APP_NAME)
        return {
            "Accept": "application/json",
            "User-Agent": f"{APP_NAME}/{version}",
            "X-Client-Id": APP_NAME,
            "X-Client-Version": version,
        }

    async def __aenter__(self):
        """Enter async context manager."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Exit async context manager."""
        await self.aclose()

    async def aclose(self) -> None:
        """Close the underlying HTTP client."""
        await self._client.aclose()

    async def _request(
        self, method: str, endpoint: str, **kwargs: Any
    ) -> dict[str, Any] | None:
        """Make an authenticated request to the Affinity API.

        Adds the Authorization and X-Affinity-Api-Version headers, then
        delegates to the underlying httpx client.

        Args:
            method: HTTP method (e.g. 'GET', 'POST')
            endpoint: The API endpoint path (e.g. '/v2/persons')
            **kwargs: Additional arguments passed to httpx (params, json, etc.)

        Returns:
            Dictionary containing the API response, or None for empty responses.

        Raises:
            AffinityAPIError: For Affinity API errors
            httpx.RequestError: For connection/timeout errors
            json.JSONDecodeError: For invalid JSON in response body
        """
        logger.debug(f"{method} request to {endpoint}")

        headers = {
            "Authorization": f"Bearer {self._get_api_key()}",
            "X-Affinity-Api-Version": AFFINITY_API_VERSION,
        }

        # Inject W3C trace context headers for trace propagation
        propagate.inject(headers)

        response = await self._client.request(
            method, endpoint, headers=headers, **kwargs
        )
        return self._handle_response(method, endpoint, response)

    async def get(
        self, endpoint: str, params: dict[str, Any] | None = None
    ) -> dict[str, Any] | None:
        """Make a GET request to the Affinity API."""
        return await self._request("GET", endpoint, params=params)

    async def post(
        self, endpoint: str, body: dict[str, Any] | None = None
    ) -> dict[str, Any] | None:
        """Make a POST request to the Affinity API."""
        return await self._request("POST", endpoint, json=body)

    async def put(
        self, endpoint: str, body: dict[str, Any] | None = None
    ) -> dict[str, Any] | None:
        """Make a PUT request to the Affinity API."""
        return await self._request("PUT", endpoint, json=body)

    async def patch(
        self, endpoint: str, body: dict[str, Any] | None = None
    ) -> dict[str, Any] | None:
        """Make a PATCH request to the Affinity API."""
        return await self._request("PATCH", endpoint, json=body)

    async def delete(
        self, endpoint: str, params: dict[str, Any] | None = None
    ) -> dict[str, Any] | None:
        """Make a DELETE request to the Affinity API."""
        return await self._request("DELETE", endpoint, params=params)

    def _handle_response(
        self, method: str, endpoint: str, response: httpx.Response
    ) -> dict[str, Any] | None:
        """Handle HTTP response by raising error if present, otherwise return JSON.

        Args:
            method: HTTP method used (e.g. 'GET')
            endpoint: API endpoint that was called
            response: The HTTP response from httpx

        Returns:
            Dictionary containing the API response, or None for empty responses.

        Raises:
            AffinityAPIError: For Affinity API errors
            httpx.RequestError: For connection/timeout errors
            json.JSONDecodeError: For invalid JSON in response body
        """
        if response.is_error:
            error_message = self._parse_error_message(response)

            logger.error(
                f"HTTP error {response.status_code} on {method} {endpoint}: {error_message}"
            )

            if response.status_code == 403:
                error_message = f"{error_message}. Please contact your Affinity Admin for help gaining access."

            raise AffinityAPIError(error_message, response.status_code)

        logger.info(f"Success: {method} {endpoint} -> {response.status_code}")
        if response.status_code == 204:
            return None

        return response.json()

    def _parse_error_message(self, response: httpx.Response) -> str:
        """Parse error message from HTTP response.

        Handles both v1 and v2 API error formats:
        - v1 - list of error messages: ["error string 1", "error string 2", ...]
        - v2 - list of error objects: {"errors": [{"message": "...", "code": "..."}, ...]}

        Args:
            response: The HTTP response

        Returns:
            String containing all error messages joined with "; "
        """
        try:
            error_data = response.json()

            # Handles API v2 format: {"errors": [{"message": "...", "code": "..."}, ...]}
            if isinstance(error_data, dict) and "errors" in error_data:
                error_messages = [
                    err.get("message", str(err)) for err in error_data["errors"]
                ]
                return "; ".join(error_messages)

            # Handles API v1 format: ["error string 1", "error string 2", ...]
            elif isinstance(error_data, list):
                return "; ".join(str(err) for err in error_data)
            else:
                return response.text

        except JSONDecodeError:
            return response.text
