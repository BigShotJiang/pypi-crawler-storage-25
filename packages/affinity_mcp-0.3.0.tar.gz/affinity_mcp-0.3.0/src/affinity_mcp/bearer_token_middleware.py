from loguru import logger
from starlette.requests import Request
from starlette.types import ASGIApp, Receive, Scope, Send

from .context import api_key_var

_UNAUTHENTICATED_PATHS = frozenset(
    {"/healthz", "/.well-known/oauth-protected-resource/mcp"}
)


class BearerTokenMiddleware:
    """Extracts an Affinity API key from the ``Authorization: Bearer <key>``
    header and stores it in ``api_key_var`` for the duration of the request."""

    def __init__(self, app: ASGIApp):
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] == "http":
            request = Request(scope)
            key = ""
            # Skip auth entirely for paths that don't require a token (e.g. health
            # check, OAuth discovery). This avoids false-positive warnings from
            # Kubernetes liveness probes and unauthenticated metadata endpoints.
            if request.url.path not in _UNAUTHENTICATED_PATHS:
                auth = request.headers.get("authorization", "")
                # Split on any whitespace (space or tab) per RFC 7235 OWS rules,
                # rather than checking for a literal "Bearer " prefix.
                auth_parts = auth.split(None, 1)
                if len(auth_parts) == 2 and auth_parts[0].lower() == "bearer":
                    key = auth_parts[1].strip()
                if not key:
                    logger.bind(
                        path=request.url.path,
                        method=request.method,
                        client=request.client.host if request.client else None,
                    ).warning("Missing API key")

            key_token = api_key_var.set(key) if key else None
            try:
                await self.app(scope, receive, send)
            finally:
                if key_token:
                    api_key_var.reset(key_token)
            return

        await self.app(scope, receive, send)
