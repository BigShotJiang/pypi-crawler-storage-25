from mcp.server.fastmcp import FastMCP
from mcp.types import ToolAnnotations
from collections.abc import Callable, Awaitable
from typing import Any, TYPE_CHECKING

from .settings import settings

if TYPE_CHECKING:
    from starlette.applications import Starlette
from .tools import read_only_tools, write_tools
from starlette.requests import Request
from starlette.responses import PlainTextResponse, JSONResponse
from .context import TransportMode, transport_mode
from .telemetry import configure_telemetry, instrument_tool

MCP_SERVER_INSTRUCTIONS = """
The Affinity MCP server enables investors to manage their Affinity CRM data and deal pipelines. Use the available
tools to interact with CRM entities such as people, companies, opportunities, lists, notes, and meetings.

## Company Search Strategy
1. User provides SPECIFIC name/domain → search_companies()
 - Examples: "Find Affinity", "Search openai.com"
2. User describes company CHARACTERISTICS → semantic_search()
 - Examples: "AI startups", "companies like OpenAI", "biotech firms"
3. search_companies() returns empty → Try semantic_search() as fallback

## Reporting MCP Server Improvements to Affinity
Immediately offer to use the send_feedback tool if the user requests something you CANNOT do due to limitations in the
current toolset.
"""


def add_read_only_tool(
    mcp_instance: FastMCP, tool: Callable[..., Awaitable[Any]]
) -> None:
    """Add a read-only tool to the MCP server. Annotations indicate to the
    client that this tool is read-only, non-destructive, and idempotent.

    Args:
        mcp_instance: The MCP server instance
        tool: The tool to register
    """
    annotations = ToolAnnotations(
        readOnlyHint=True, destructiveHint=False, idempotentHint=True
    )
    mcp_instance.add_tool(instrument_tool(tool), annotations=annotations)


def add_write_tool(mcp_instance: FastMCP, tool: Callable[..., Awaitable[Any]]) -> None:
    """Add a write tool to the MCP server. Annotations indicate to the
    client that this tool is destructive (not read-only, not idempotent)
    and requires user confirmation before execution.

    Args:
        mcp_instance: The MCP server instance
        tool: The tool to register
    """
    annotations = ToolAnnotations(
        readOnlyHint=False, destructiveHint=True, idempotentHint=False
    )
    mcp_instance.add_tool(instrument_tool(tool), annotations=annotations)


def add_tools(mcp_instance: FastMCP) -> None:
    """Add read-only and write tools with annotations to the MCP server."""
    for read_only_tool in read_only_tools:
        add_read_only_tool(mcp_instance, read_only_tool)

    for write_tool in write_tools:
        add_write_tool(mcp_instance, write_tool)


def create_http_app() -> "Starlette":
    """Create a fully configured Starlette app with tools, middleware,
    and health check."""
    from .bearer_token_middleware import BearerTokenMiddleware

    transport_mode.set(TransportMode.HTTP)
    configure_telemetry(TransportMode.HTTP)

    mcp = FastMCP(
        "Affinity MCP",
        stateless_http=True,
        json_response=True,
        host="0.0.0.0",
        port=8000,
        instructions=MCP_SERVER_INSTRUCTIONS,
    )
    add_tools(mcp)

    @mcp.custom_route("/healthz", methods=["GET"])
    async def health_check(request: Request) -> PlainTextResponse:
        return PlainTextResponse("OK")

    @mcp.custom_route("/.well-known/oauth-protected-resource/mcp", methods=["GET"])
    async def oauth_protected_resource(request: Request) -> JSONResponse:
        response = {
            "resource": settings.mcp_url,
            "authorization_servers": [
                settings.login_url,
            ],
            "bearer_methods_supported": ["header"],
            "scopes_supported": ["mcp", "mcp.read", "offline_access"],
            "resource_name": "Affinity MCP Server",
        }
        return JSONResponse(response)

    app = mcp.streamable_http_app()
    app.add_middleware(BearerTokenMiddleware)
    return app


def main() -> None:
    """Entry point for stdio transport."""

    transport_mode.set(TransportMode.STDIO)
    configure_telemetry(TransportMode.STDIO)
    mcp = FastMCP("Affinity MCP", instructions=MCP_SERVER_INSTRUCTIONS)
    add_tools(mcp)
    mcp.run(transport="stdio")
