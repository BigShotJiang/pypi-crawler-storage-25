"""Application settings and configuration management."""

import os

from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field, SecretStr, HttpUrl, field_validator


class EnvSettings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="affinity_",
        env_file=os.getenv("ENV_FILE", ".env"),
        env_file_encoding="utf-8",
        extra="ignore",
    )
    api_key: SecretStr | None = Field(default=None)
    base_url: HttpUrl = Field(default=HttpUrl("https://affinity.co"))

    @field_validator("base_url", mode="after")
    @classmethod
    def validate_base_url_field(cls, url: HttpUrl) -> HttpUrl:
        """Validates the provided Affinity Base URL."""

        if str(url.scheme) != "https":
            raise ValueError("AFFINITY_BASE_URL scheme must be https")

        if url.path and url.path != "/":
            raise ValueError("AFFINITY_BASE_URL must not contain a path")

        return url


class Settings:
    """Application settings from environment variables and env file.

    Settings are loaded from the env file specified by ENV_FILE (default: .env).
    Environment variables override env file values.

    Attributes:
        api_key: The Affinity API key, stored securely as a SecretStr.
            Optional — required for stdio transport, not needed for HTTP transport.
        api_url: The Affinity API URL (eg https://api.affinity.co)
        base_url: The Affinity Base URL (defaults to https://affinity.co)
        login_url: The Affinity Login URL (eg https://login.affinity.co)
        mcp_url: The URL of this MCP server (eg https://mcp.affinity.co/mcp)
    """

    def url_for_subdomain(self, base, subdomain, path="") -> str:
        """Computes the HttpUrl for an Affinity subdomain."""

        url = HttpUrl.build(
            scheme=base.scheme,
            host=f"{subdomain}.{base.host}",
            port=base.port,
            path=path,
        )
        if path != "":
            return str(url)
        else:
            # HttpUrl adds a trailing '/' even when we explicitly tell it not to.
            return str(url).rstrip("/")

    def __init__(self):
        env_settings = EnvSettings()

        base = env_settings.base_url
        self.api_key = env_settings.api_key
        self.base_url = str(base).rstrip("/")
        self.api_url = self.url_for_subdomain(base, "api")
        self.login_url = self.url_for_subdomain(base, "login")
        self.mcp_url = self.url_for_subdomain(base, "mcp", "mcp")


settings = Settings()
