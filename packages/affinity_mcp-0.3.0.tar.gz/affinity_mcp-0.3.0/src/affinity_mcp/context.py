"""Context variables shared across the application.

These contextvars control how the API key is resolved at request time:
- ``transport_mode`` stores the current transport mode (HTTP or stdio).
- ``api_key_var`` carries the per-request API key set by the HTTP middleware.
"""

import contextvars
from enum import StrEnum


class TransportMode(StrEnum):
    STDIO = "stdio"
    HTTP = "http"


api_key_var: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "api_key", default=None
)

transport_mode: contextvars.ContextVar[TransportMode] = contextvars.ContextVar(
    "transport_mode", default=TransportMode.HTTP
)
