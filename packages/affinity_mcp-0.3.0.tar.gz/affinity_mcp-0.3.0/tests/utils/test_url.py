import pytest
from pydantic import HttpUrl
from affinity_mcp.utils.url import construct_tenant_url


@pytest.fixture
def mock_fetch_current_user(mocker):
    mock = mocker.patch("affinity_mcp.utils.url.fetch_current_user")
    mock.return_value = {
        "grant": {
            "createdAt": "2023-01-01T00:00:00Z",
            "scopes": ["api"],
            "type": "api-key",
        },
        "user": {
            "id": 1,
            "firstName": "John",
            "lastName": "Smith",
            "emailAddress": "john.smith@contoso.com",
        },
        "tenant": {
            "id": 1,
            "name": "Contoso Ltd.",
            "subdomain": "contoso",
        },
    }
    return mock


@pytest.mark.asyncio
async def test_construct_tenant_url_calls_fetch_current_user(mock_fetch_current_user):
    await construct_tenant_url()

    mock_fetch_current_user.assert_called_once()


@pytest.mark.asyncio
async def test_construct_tenant_url_returns_tenant_url(mocker, mock_fetch_current_user):
    mock_settings = mocker.patch("affinity_mcp.utils.url.settings")
    mock_settings.api_url = HttpUrl("https://api.affinity.co")

    result = await construct_tenant_url()

    assert result == "https://contoso.affinity.co"


@pytest.mark.asyncio
async def test_construct_tenant_url_strips_trailing_slash(
    mocker, mock_fetch_current_user
):
    mock_settings = mocker.patch("affinity_mcp.utils.url.settings")
    mock_settings.api_url = HttpUrl("https://api.affinity.co/")

    result = await construct_tenant_url()

    assert result == "https://contoso.affinity.co"
