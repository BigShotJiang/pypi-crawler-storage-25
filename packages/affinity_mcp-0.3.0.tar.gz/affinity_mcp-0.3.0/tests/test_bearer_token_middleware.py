"""Tests for BearerTokenMiddleware."""

import pytest

from starlette.applications import Starlette
from starlette.responses import JSONResponse
from starlette.routing import Route
from starlette.testclient import TestClient

from affinity_mcp.bearer_token_middleware import (
    BearerTokenMiddleware,
    _UNAUTHENTICATED_PATHS,
)
from affinity_mcp.context import api_key_var


def _make_app() -> Starlette:
    """Create a minimal Starlette app that echoes the current api_key_var."""

    async def echo_key(request):
        return JSONResponse({"api_key": api_key_var.get("")})

    async def healthz(request):
        return JSONResponse({"api_key": api_key_var.get("")})

    async def oauth_discovery(request):
        return JSONResponse({})

    app = Starlette(
        routes=[
            Route("/echo", echo_key),
            Route("/healthz", healthz),
            Route("/.well-known/oauth-protected-resource/mcp", oauth_discovery),
        ]
    )
    app.add_middleware(BearerTokenMiddleware)
    return app


@pytest.fixture
def client() -> TestClient:
    return TestClient(_make_app())


def test_sets_api_key_from_bearer_header(client: TestClient):
    resp = client.get("/echo", headers={"Authorization": "Bearer test-key-123"})
    assert resp.status_code == 200
    assert resp.json() == {"api_key": "test-key-123"}


def test_sets_api_key_from_bearer_header_with_tab_separator(client: TestClient):
    resp = client.get("/echo", headers={"Authorization": "Bearer\ttest-key-123"})
    assert resp.status_code == 200
    assert resp.json() == {"api_key": "test-key-123"}


def test_missing_header_leaves_key_empty(client: TestClient):
    resp = client.get("/echo")
    assert resp.status_code == 200
    assert resp.json() == {"api_key": ""}


def test_empty_bearer_leaves_key_empty(client: TestClient):
    resp = client.get("/echo", headers={"Authorization": "Bearer "})
    assert resp.status_code == 200
    assert resp.json() == {"api_key": ""}


def test_bearer_without_separator_leaves_key_empty(client: TestClient):
    resp = client.get("/echo", headers={"Authorization": "Bearertoken"})
    assert resp.status_code == 200
    assert resp.json() == {"api_key": ""}


def test_non_bearer_auth_leaves_key_empty(client: TestClient):
    resp = client.get("/echo", headers={"Authorization": "Basic abc123"})
    assert resp.status_code == 200
    assert resp.json() == {"api_key": ""}


def test_bearer_token_not_extracted_for_unauthenticated_paths(client: TestClient):
    # Even with a valid Bearer token, api_key_var is not set for exempt paths
    resp = client.get("/healthz", headers={"Authorization": "Bearer some-key"})
    assert resp.json() == {"api_key": ""}


def test_api_key_does_not_leak_between_requests(client: TestClient):
    resp1 = client.get("/echo", headers={"Authorization": "Bearer key-one"})
    assert resp1.json() == {"api_key": "key-one"}

    resp2 = client.get("/echo")
    assert resp2.json() == {"api_key": ""}


@pytest.mark.asyncio
async def test_non_http_scope_passes_through():
    observed_keys = []

    async def inner_app(scope, receive, send):
        observed_keys.append(api_key_var.get(""))

    middleware = BearerTokenMiddleware(inner_app)
    await middleware({"type": "websocket"}, None, None)
    assert observed_keys == [""]


# ---------------------------------------------------------------------------
# Missing API key logging
# ---------------------------------------------------------------------------


class TestMissingApiKeyLogging:
    # ── Warning fired ────────────────────────────────────────────────────────

    def _assert_bind_warning(self, mock_logger, mocker, path, method):
        """Assert logger.bind(...).warning("Missing API key") was called correctly."""
        mock_logger.bind.assert_called_once_with(
            path=path,
            method=method,
            client=mocker.ANY,
        )
        mock_logger.bind.return_value.warning.assert_called_once_with("Missing API key")

    def test_warns_when_no_auth_header(self, client, mocker):
        mock_logger = mocker.patch("affinity_mcp.bearer_token_middleware.logger")
        client.get("/echo")
        self._assert_bind_warning(mock_logger, mocker, "/echo", "GET")

    def test_warns_when_empty_bearer_token(self, client, mocker):
        mock_logger = mocker.patch("affinity_mcp.bearer_token_middleware.logger")
        client.get("/echo", headers={"Authorization": "Bearer "})
        self._assert_bind_warning(mock_logger, mocker, "/echo", "GET")

    def test_warns_when_non_bearer_auth_scheme(self, client, mocker):
        mock_logger = mocker.patch("affinity_mcp.bearer_token_middleware.logger")
        client.get("/echo", headers={"Authorization": "Basic abc123"})
        self._assert_bind_warning(mock_logger, mocker, "/echo", "GET")

    # ── Warning suppressed ───────────────────────────────────────────────────

    def test_no_warning_when_valid_bearer_token_present(self, client, mocker):
        mock_logger = mocker.patch("affinity_mcp.bearer_token_middleware.logger")
        client.get("/echo", headers={"Authorization": "Bearer valid-key"})
        mock_logger.bind.assert_not_called()

    def test_no_warning_for_healthz(self, client, mocker):
        mock_logger = mocker.patch("affinity_mcp.bearer_token_middleware.logger")
        client.get("/healthz")
        mock_logger.bind.assert_not_called()

    def test_no_warning_for_oauth_discovery_path(self, client, mocker):
        mock_logger = mocker.patch("affinity_mcp.bearer_token_middleware.logger")
        client.get("/.well-known/oauth-protected-resource/mcp")
        mock_logger.bind.assert_not_called()

    # ── Non-HTTP scope (STDIO-side code path) ────────────────────────────────

    @pytest.mark.asyncio
    async def test_no_warning_for_non_http_scope(self, mocker):
        """Websocket/lifespan scopes bypass all auth logic — no warning emitted."""
        mock_logger = mocker.patch("affinity_mcp.bearer_token_middleware.logger")

        async def inner_app(scope, receive, send):
            pass

        middleware = BearerTokenMiddleware(inner_app)
        await middleware({"type": "websocket"}, None, None)
        mock_logger.bind.assert_not_called()

    # ── Exempt paths set ─────────────────────────────────────────────────────

    def test_unauthenticated_paths_contains_expected_entries(self):
        assert "/healthz" in _UNAUTHENTICATED_PATHS
        assert "/.well-known/oauth-protected-resource/mcp" in _UNAUTHENTICATED_PATHS
