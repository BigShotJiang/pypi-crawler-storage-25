import json

import pytest
from affinity_mcp.server import add_tools, create_http_app, main
from affinity_mcp.tools import read_only_tools, write_tools
from mcp.types import ToolAnnotations
from unittest.mock import MagicMock
from affinity_mcp.context import TransportMode, transport_mode

from mcp.server.fastmcp import FastMCP
from starlette.testclient import TestClient


def test_no_duplicate_tools_between_read_and_write():
    read_names = {t.__name__ for t in read_only_tools}
    write_names = {t.__name__ for t in write_tools}

    duplicates = read_names & write_names
    assert len(duplicates) == 0


@pytest.mark.asyncio
async def test_add_tools_registers_all_tools():
    mcp = FastMCP("test")
    add_tools(mcp)
    registered_tools = await mcp.list_tools()

    registered_tool_names = {tool.name for tool in registered_tools}
    expected_tool_names = {tool.__name__ for tool in read_only_tools + write_tools}
    assert expected_tool_names == registered_tool_names


@pytest.mark.asyncio
async def test_add_tools_registers_tools_with_correct_annotations():
    mcp = FastMCP("test")
    add_tools(mcp)
    registered_tools = await mcp.list_tools()

    tools_by_name = {tool.name: tool for tool in registered_tools}
    for tool_func in read_only_tools:
        tool_name = tool_func.__name__
        tool = tools_by_name[tool_name]
        annotations = tool.annotations
        assert_read_only_annotations(annotations)

    for tool_func in write_tools:
        tool_name = tool_func.__name__
        tool = tools_by_name[tool_name]
        annotations = tool.annotations
        assert_write_annotations(annotations)


def assert_read_only_annotations(annotations):
    assert isinstance(annotations, ToolAnnotations)
    assert annotations.readOnlyHint is True
    assert annotations.destructiveHint is False
    assert annotations.idempotentHint is True


def assert_write_annotations(annotations):
    assert isinstance(annotations, ToolAnnotations)
    assert annotations.readOnlyHint is False
    assert annotations.destructiveHint is True
    assert annotations.idempotentHint is False


def test_main_runs_stdio(mocker):
    mock_mcp = MagicMock()
    mocker.patch("affinity_mcp.server.FastMCP", return_value=mock_mcp)
    mocker.patch("affinity_mcp.server.add_tools")

    main()

    mock_mcp.run.assert_called_once_with(transport=TransportMode.STDIO)


def test_create_http_app_sets_http_transport_mode(mocker):
    """HTTP transport is set without initialising real OTLP (avoids export threads)."""
    mocker.patch("affinity_mcp.server.configure_telemetry")
    create_http_app()

    assert transport_mode.get() == TransportMode.HTTP


def test_healthz_returns_ok(mocker):
    mocker.patch("affinity_mcp.server.configure_telemetry")
    app = create_http_app()
    client = TestClient(app)

    response = client.get("/healthz")
    assert response.status_code == 200
    assert response.text == "OK"


def test_oauth_protected_resource_returns_ok(mocker):
    mocker.patch("affinity_mcp.server.configure_telemetry")
    app = create_http_app()
    client = TestClient(app)

    response = client.get("/.well-known/oauth-protected-resource/mcp")

    parsed = json.loads(response.text)
    expected = {
        "resource": "https://mcp.affinity.co/mcp",
        "authorization_servers": [
            "https://login.affinity.co",
        ],
        "bearer_methods_supported": ["header"],
        "scopes_supported": ["mcp", "mcp.read", "offline_access"],
        "resource_name": "Affinity MCP Server",
    }
    assert response.status_code == 200
    assert expected == parsed
