import pytest
from unittest.mock import AsyncMock
from affinity_mcp.tools.reminders import (
    get_reminders,
    create_reminder,
    update_reminder,
    delete_reminder,
)
from affinity_mcp.types import (
    EntityType,
    ReminderResetType,
    ReminderStatus,
    ReminderType,
)


# ──────────────────────────────────────────────────────────────
# Shared fixtures
# ──────────────────────────────────────────────────────────────


@pytest.fixture
def mock_reminder_response():
    return {
        "id": 1,
        "type": 0,
        "created_at": "2025-01-01T00:00:00Z",
        "completed_at": None,
        "content": None,
        "due_date": "2025-06-01T00:00:00Z",
        "reset_type": None,
        "reminder_days": None,
        "status": 1,
        "creator": {
            "id": 10,
            "type": 1,
            "first_name": "Jane",
            "last_name": "Smith",
            "primary_email": "jane@affinity.co",
            "emails": ["jane@affinity.co"],
        },
        "owner": {
            "id": 10,
            "type": 1,
            "first_name": "Jane",
            "last_name": "Smith",
            "primary_email": "jane@affinity.co",
            "emails": ["jane@affinity.co"],
        },
        "completer": None,
        "person": None,
        "organization": None,
        "opportunity": None,
    }


@pytest.fixture
def mock_affinity_api(mocker):
    mock_api_instance = AsyncMock()
    mock_api_class = mocker.patch("affinity_mcp.tools.reminders.AffinityAPI")
    mock_api_class.return_value.__aenter__.return_value = mock_api_instance
    return mock_api_instance


@pytest.fixture
def mock_reminders_response():
    return {
        "reminders": [
            {
                "id": 15562,
                "type": 1,
                "created_at": "2021-11-22T09:31:52.415-08:00",
                "completed_at": None,
                "content": "Recurring reminder",
                "due_date": "2021-12-22T09:31:52.415-08:00",
                "reset_type": 0,
                "reminder_days": 30,
                "status": 2,
                "creator": {
                    "id": 443,
                    "type": 1,
                    "first_name": "John",
                    "last_name": "Doe",
                    "primary_email": "john@affinity.co",
                    "emails": ["john@affinity.co"],
                },
                "owner": {
                    "id": 443,
                    "type": 1,
                    "first_name": "John",
                    "last_name": "Doe",
                    "primary_email": "john@affinity.co",
                    "emails": ["john@affinity.co"],
                },
                "completer": None,
                "person": None,
                "organization": {
                    "id": 4904,
                    "name": "organization",
                    "domain": None,
                    "domains": [],
                    "crunchbase_uuid": None,
                    "global": False,
                },
                "opportunity": None,
            },
        ],
        "next_page_token": "test_page_token_123",
    }


@pytest.mark.asyncio
async def test_get_reminders_use_defaults(mock_affinity_api, mock_reminders_response):
    mock_affinity_api.get.return_value = mock_reminders_response
    result = await get_reminders()
    assert mock_reminders_response == result
    mock_affinity_api.get.assert_called_once_with(
        "/reminders", params={"page_size": 10}
    )


@pytest.mark.asyncio
async def test_get_reminders_for_entity_company(
    mock_affinity_api, mock_reminders_response
):
    mock_affinity_api.get.return_value = mock_reminders_response

    result = await get_reminders(
        entity_id=123,
        entity_type=EntityType.COMPANY,
    )

    assert result == mock_reminders_response
    mock_affinity_api.get.assert_called_once_with(
        "/reminders",
        params={
            "organization_id": 123,
            "page_size": 10,
        },
    )


@pytest.mark.asyncio
async def test_get_reminders_for_entity_person(
    mock_affinity_api, mock_reminders_response
):
    mock_affinity_api.get.return_value = mock_reminders_response

    await get_reminders(
        entity_id=456,
        entity_type=EntityType.PERSON,
    )

    mock_affinity_api.get.assert_called_once_with(
        "/reminders",
        params={
            "person_id": 456,
            "page_size": 10,
        },
    )


@pytest.mark.asyncio
async def test_get_reminders_for_entity_opportunity(
    mock_affinity_api, mock_reminders_response
):
    mock_affinity_api.get.return_value = mock_reminders_response

    await get_reminders(
        entity_id=789,
        entity_type=EntityType.OPPORTUNITY,
    )

    mock_affinity_api.get.assert_called_once_with(
        "/reminders",
        params={
            "opportunity_id": 789,
            "page_size": 10,
        },
    )


@pytest.mark.asyncio
async def test_get_reminders_entity_id_without_type_omits_entity_params(
    mock_affinity_api, mock_reminders_response
):
    mock_affinity_api.get.return_value = mock_reminders_response

    await get_reminders(entity_id=123)

    mock_affinity_api.get.assert_called_once_with(
        "/reminders",
        params={"page_size": 10},
    )


@pytest.mark.asyncio
async def test_get_reminders_entity_type_without_id_omits_entity_params(
    mock_affinity_api, mock_reminders_response
):
    mock_affinity_api.get.return_value = mock_reminders_response

    await get_reminders(entity_type=EntityType.COMPANY)

    mock_affinity_api.get.assert_called_once_with(
        "/reminders",
        params={"page_size": 10},
    )


@pytest.mark.asyncio
async def test_get_reminders_with_creator_owner_completer(
    mock_affinity_api, mock_reminders_response
):
    mock_affinity_api.get.return_value = mock_reminders_response

    await get_reminders(
        creator_id=1,
        owner_id=2,
        completer_id=3,
    )

    mock_affinity_api.get.assert_called_once_with(
        "/reminders",
        params={
            "creator_id": 1,
            "owner_id": 2,
            "completer_id": 3,
            "page_size": 10,
        },
    )


@pytest.mark.asyncio
async def test_get_reminders_with_type_reset_status(
    mock_affinity_api, mock_reminders_response
):
    mock_affinity_api.get.return_value = mock_reminders_response

    await get_reminders(
        reminder_type=ReminderType.RECURRING,
        reset_type=ReminderResetType.INTERACTION,
        status=ReminderStatus.OVERDUE,
    )

    mock_affinity_api.get.assert_called_once_with(
        "/reminders",
        params={
            "type": ReminderType.RECURRING,
            "reset_type": ReminderResetType.INTERACTION,
            "status": ReminderStatus.OVERDUE,
            "page_size": 10,
        },
    )


@pytest.mark.asyncio
async def test_get_reminders_with_due_before_and_after(
    mock_affinity_api, mock_reminders_response
):
    mock_affinity_api.get.return_value = mock_reminders_response
    due_before = "2025-12-31T23:59:59Z"
    due_after = "2025-01-01T00:00:00Z"

    await get_reminders(due_before=due_before, due_after=due_after)

    mock_affinity_api.get.assert_called_once_with(
        "/reminders",
        params={
            "due_before": due_before,
            "due_after": due_after,
            "page_size": 10,
        },
    )


@pytest.mark.asyncio
async def test_get_reminders_with_page_size_and_page_token(
    mock_affinity_api, mock_reminders_response
):
    mock_affinity_api.get.return_value = mock_reminders_response

    await get_reminders(page_size=50, page_token="next_token_abc")

    mock_affinity_api.get.assert_called_once_with(
        "/reminders",
        params={
            "page_size": 50,
            "page_token": "next_token_abc",
        },
    )


@pytest.mark.asyncio
async def test_get_reminders_with_all_parameters(
    mock_affinity_api, mock_reminders_response
):
    mock_affinity_api.get.return_value = mock_reminders_response
    due_before = "2025-12-31T23:59:59Z"
    due_after = "2025-01-01T00:00:00Z"

    await get_reminders(
        entity_id=100,
        entity_type=EntityType.COMPANY,
        creator_id=1,
        owner_id=2,
        completer_id=3,
        reminder_type=ReminderType.RECURRING,
        reset_type=ReminderResetType.INTERACTION,
        status=ReminderStatus.OVERDUE,
        due_before=due_before,
        due_after=due_after,
        page_size=25,
        page_token="tok",
    )

    mock_affinity_api.get.assert_called_once_with(
        "/reminders",
        params={
            "organization_id": 100,
            "creator_id": 1,
            "owner_id": 2,
            "completer_id": 3,
            "type": ReminderType.RECURRING,
            "reset_type": ReminderResetType.INTERACTION,
            "status": ReminderStatus.OVERDUE,
            "due_before": due_before,
            "due_after": due_after,
            "page_size": 25,
            "page_token": "tok",
        },
    )


# ──────────────────────────────────────────────────────────────
# create_reminder tests
# ──────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_create_one_time_reminder_required_fields_only(
    mock_affinity_api, mock_reminder_response
):
    mock_affinity_api.post.return_value = mock_reminder_response

    result = await create_reminder(
        owner_id=10,
        reminder_type=ReminderType.ONE_TIME,
        entity_id=42,
        entity_type=EntityType.PERSON,
        due_date="2025-06-01T00:00:00Z",
    )

    assert result == mock_reminder_response
    mock_affinity_api.post.assert_called_once_with(
        "/reminders",
        {
            "owner_id": 10,
            "type": ReminderType.ONE_TIME,
            "due_date": "2025-06-01T00:00:00Z",
            "person_id": 42,
        },
    )


@pytest.mark.asyncio
async def test_create_one_time_reminder_with_content_and_person(
    mock_affinity_api, mock_reminder_response
):
    mock_affinity_api.post.return_value = mock_reminder_response

    result = await create_reminder(
        owner_id=10,
        reminder_type=ReminderType.ONE_TIME,
        entity_id=42,
        entity_type=EntityType.PERSON,
        due_date="2025-06-01T00:00:00Z",
        content="Follow up",
    )

    assert result == mock_reminder_response
    mock_affinity_api.post.assert_called_once_with(
        "/reminders",
        {
            "owner_id": 10,
            "type": ReminderType.ONE_TIME,
            "content": "Follow up",
            "person_id": 42,
            "due_date": "2025-06-01T00:00:00Z",
        },
    )


@pytest.mark.asyncio
async def test_create_one_time_reminder_with_company(
    mock_affinity_api, mock_reminder_response
):
    mock_affinity_api.post.return_value = mock_reminder_response

    await create_reminder(
        owner_id=10,
        reminder_type=ReminderType.ONE_TIME,
        entity_id=99,
        entity_type=EntityType.COMPANY,
        due_date="2025-06-01T00:00:00Z",
    )

    mock_affinity_api.post.assert_called_once_with(
        "/reminders",
        {
            "owner_id": 10,
            "type": ReminderType.ONE_TIME,
            "organization_id": 99,
            "due_date": "2025-06-01T00:00:00Z",
        },
    )


@pytest.mark.asyncio
async def test_create_one_time_reminder_with_opportunity(
    mock_affinity_api, mock_reminder_response
):
    mock_affinity_api.post.return_value = mock_reminder_response

    await create_reminder(
        owner_id=10,
        reminder_type=ReminderType.ONE_TIME,
        entity_id=77,
        entity_type=EntityType.OPPORTUNITY,
        due_date="2025-06-01T00:00:00Z",
    )

    mock_affinity_api.post.assert_called_once_with(
        "/reminders",
        {
            "owner_id": 10,
            "type": ReminderType.ONE_TIME,
            "opportunity_id": 77,
            "due_date": "2025-06-01T00:00:00Z",
        },
    )


@pytest.mark.asyncio
async def test_create_one_time_reminder_already_completed(
    mock_affinity_api, mock_reminder_response
):
    mock_affinity_api.post.return_value = mock_reminder_response

    await create_reminder(
        owner_id=10,
        reminder_type=ReminderType.ONE_TIME,
        entity_id=42,
        entity_type=EntityType.PERSON,
        due_date="2025-06-01T00:00:00Z",
        is_completed=True,
    )

    mock_affinity_api.post.assert_called_once_with(
        "/reminders",
        {
            "owner_id": 10,
            "type": ReminderType.ONE_TIME,
            "due_date": "2025-06-01T00:00:00Z",
            "person_id": 42,
            "is_completed": True,
        },
    )


@pytest.mark.asyncio
async def test_create_reminder_missing_entity_type_raises_type_error(
    mock_affinity_api,
):
    with pytest.raises(TypeError, match="entity_type"):
        await create_reminder(
            owner_id=10,
            reminder_type=ReminderType.ONE_TIME,
            entity_id=42,
            due_date="2025-06-01T00:00:00Z",
        )

    mock_affinity_api.post.assert_not_called()


@pytest.mark.asyncio
async def test_create_reminder_missing_entity_id_raises_type_error(
    mock_affinity_api,
):
    with pytest.raises(TypeError, match="entity_id"):
        await create_reminder(
            owner_id=10,
            reminder_type=ReminderType.ONE_TIME,
            entity_type=EntityType.COMPANY,
            due_date="2025-06-01T00:00:00Z",
        )

    mock_affinity_api.post.assert_not_called()


@pytest.mark.asyncio
async def test_create_recurring_reminder_required_fields(
    mock_affinity_api, mock_reminder_response
):
    mock_affinity_api.post.return_value = mock_reminder_response

    result = await create_reminder(
        owner_id=10,
        reminder_type=ReminderType.RECURRING,
        entity_id=42,
        entity_type=EntityType.PERSON,
        reset_type=ReminderResetType.INTERACTION,
        reminder_days=30,
    )

    assert result == mock_reminder_response
    mock_affinity_api.post.assert_called_once_with(
        "/reminders",
        {
            "owner_id": 10,
            "type": ReminderType.RECURRING,
            "reset_type": ReminderResetType.INTERACTION,
            "reminder_days": 30,
            "person_id": 42,
        },
    )


@pytest.mark.asyncio
async def test_create_recurring_reminder_all_reset_types(
    mock_affinity_api, mock_reminder_response
):
    mock_affinity_api.post.return_value = mock_reminder_response

    for reset_type in ReminderResetType:
        mock_affinity_api.reset_mock()
        await create_reminder(
            owner_id=10,
            reminder_type=ReminderType.RECURRING,
            entity_id=42,
            entity_type=EntityType.PERSON,
            reset_type=reset_type,
            reminder_days=7,
        )
        mock_affinity_api.post.assert_called_once_with(
            "/reminders",
            {
                "owner_id": 10,
                "type": ReminderType.RECURRING,
                "reset_type": reset_type,
                "reminder_days": 7,
                "person_id": 42,
            },
        )


@pytest.mark.asyncio
async def test_create_recurring_reminder_with_all_fields(
    mock_affinity_api, mock_reminder_response
):
    mock_affinity_api.post.return_value = mock_reminder_response

    await create_reminder(
        owner_id=10,
        reminder_type=ReminderType.RECURRING,
        entity_id=55,
        entity_type=EntityType.COMPANY,
        content="Check in",
        reset_type=ReminderResetType.EMAIL,
        reminder_days=14,
    )

    mock_affinity_api.post.assert_called_once_with(
        "/reminders",
        {
            "owner_id": 10,
            "type": ReminderType.RECURRING,
            "content": "Check in",
            "organization_id": 55,
            "reset_type": ReminderResetType.EMAIL,
            "reminder_days": 14,
        },
    )


@pytest.mark.asyncio
async def test_create_one_time_reminder_without_due_date_raises(mock_affinity_api):
    with pytest.raises(ValueError, match="due_date is required for ONE_TIME reminders"):
        await create_reminder(
            owner_id=10,
            reminder_type=ReminderType.ONE_TIME,
            entity_id=42,
            entity_type=EntityType.PERSON,
        )

    mock_affinity_api.post.assert_not_called()


@pytest.mark.asyncio
async def test_create_recurring_reminder_without_reset_type_raises(
    mock_affinity_api,
):
    with pytest.raises(
        ValueError, match="reset_type is required for RECURRING reminders"
    ):
        await create_reminder(
            owner_id=10,
            reminder_type=ReminderType.RECURRING,
            entity_id=42,
            entity_type=EntityType.PERSON,
            reminder_days=7,
        )

    mock_affinity_api.post.assert_not_called()


@pytest.mark.asyncio
async def test_create_recurring_reminder_without_reminder_days_raises(
    mock_affinity_api,
):
    with pytest.raises(
        ValueError, match="reminder_days is required for RECURRING reminders"
    ):
        await create_reminder(
            owner_id=10,
            reminder_type=ReminderType.RECURRING,
            entity_id=42,
            entity_type=EntityType.PERSON,
            reset_type=ReminderResetType.INTERACTION,
        )

    mock_affinity_api.post.assert_not_called()


@pytest.mark.asyncio
async def test_create_recurring_reminder_with_non_positive_days_raises(
    mock_affinity_api,
):
    with pytest.raises(
        ValueError, match="reminder_days must be >= 1 for RECURRING reminders"
    ):
        await create_reminder(
            owner_id=10,
            reminder_type=ReminderType.RECURRING,
            entity_id=42,
            entity_type=EntityType.PERSON,
            reset_type=ReminderResetType.INTERACTION,
            reminder_days=0,
        )

    mock_affinity_api.post.assert_not_called()


@pytest.mark.asyncio
async def test_create_recurring_reminder_with_entity_succeeds(
    mock_affinity_api, mock_reminder_response
):
    mock_affinity_api.post.return_value = mock_reminder_response

    result = await create_reminder(
        owner_id=10,
        reminder_type=ReminderType.RECURRING,
        entity_id=42,
        entity_type=EntityType.PERSON,
        reset_type=ReminderResetType.INTERACTION,
        reminder_days=7,
    )

    assert result == mock_reminder_response
    mock_affinity_api.post.assert_called_once_with(
        "/reminders",
        {
            "owner_id": 10,
            "type": ReminderType.RECURRING,
            "reset_type": ReminderResetType.INTERACTION,
            "reminder_days": 7,
            "person_id": 42,
        },
    )


@pytest.mark.asyncio
async def test_create_recurring_reminder_with_is_completed_raises(
    mock_affinity_api,
):
    with pytest.raises(
        ValueError, match="is_completed cannot be used with RECURRING reminders"
    ):
        await create_reminder(
            owner_id=10,
            reminder_type=ReminderType.RECURRING,
            entity_id=42,
            entity_type=EntityType.PERSON,
            reset_type=ReminderResetType.INTERACTION,
            reminder_days=7,
            is_completed=True,
        )

    mock_affinity_api.post.assert_not_called()


# ──────────────────────────────────────────────────────────────
# update_reminder tests
# ──────────────────────────────────────────────────────────────


@pytest.fixture
def base_reminder():
    return {
        "id": 1,
        "type": 0,
        "created_at": "2025-01-01T00:00:00Z",
        "completed_at": None,
        "content": None,
        "due_date": "2025-06-01T00:00:00Z",
        "reset_type": None,
        "reminder_days": None,
        "status": 1,
        "creator": {"id": 10, "first_name": "Jane", "last_name": "Smith"},
        "owner": {"id": 10, "first_name": "Jane", "last_name": "Smith"},
        "completer": None,
        "person": None,
        "organization": None,
        "opportunity": None,
    }


@pytest.mark.asyncio
async def test_update_reminder_owner_id(mock_affinity_api, base_reminder):
    updated = {
        **base_reminder,
        "owner": {"id": 99, "first_name": "Bob", "last_name": "Jones"},
    }
    mock_affinity_api.put.return_value = updated

    result = await update_reminder(reminder_id=1, owner_id=99)

    assert result == updated
    mock_affinity_api.put.assert_called_once_with("/reminders/1", {"owner_id": 99})


@pytest.mark.asyncio
async def test_update_reminder_content(mock_affinity_api, base_reminder):
    updated = {**base_reminder, "content": "Updated note"}
    mock_affinity_api.put.return_value = updated

    result = await update_reminder(reminder_id=1, content="Updated note")

    assert result == updated
    mock_affinity_api.put.assert_called_once_with(
        "/reminders/1", {"content": "Updated note"}
    )


@pytest.mark.asyncio
async def test_update_reminder_due_date(mock_affinity_api, base_reminder):
    updated = {**base_reminder, "due_date": "2026-03-01T00:00:00Z"}
    mock_affinity_api.put.return_value = updated

    result = await update_reminder(reminder_id=1, due_date="2026-03-01T00:00:00Z")

    assert result == updated
    mock_affinity_api.put.assert_called_once_with(
        "/reminders/1", {"due_date": "2026-03-01T00:00:00Z"}
    )


@pytest.mark.asyncio
async def test_update_reminder_is_completed(mock_affinity_api, base_reminder):
    updated = {**base_reminder, "status": 0, "completed_at": "2026-04-21T12:00:00Z"}
    mock_affinity_api.put.return_value = updated

    result = await update_reminder(reminder_id=5, is_completed=True)

    assert result == updated
    mock_affinity_api.put.assert_called_once_with(
        "/reminders/5", {"is_completed": True}
    )


@pytest.mark.asyncio
async def test_update_reminder_recurring_fields(mock_affinity_api, base_reminder):
    updated = {
        **base_reminder,
        "type": 1,
        "reset_type": 1,
        "reminder_days": 14,
        "due_date": None,
    }
    mock_affinity_api.put.return_value = updated

    result = await update_reminder(
        reminder_id=2,
        reminder_type=ReminderType.RECURRING,
        reset_type=ReminderResetType.EMAIL,
        reminder_days=14,
    )

    assert result == updated
    mock_affinity_api.put.assert_called_once_with(
        "/reminders/2",
        {
            "type": ReminderType.RECURRING,
            "reset_type": ReminderResetType.EMAIL,
            "reminder_days": 14,
        },
    )


@pytest.mark.asyncio
async def test_update_reminder_non_positive_reminder_days_raises(
    mock_affinity_api,
):
    with pytest.raises(ValueError, match="reminder_days must be >= 1"):
        await update_reminder(reminder_id=1, reminder_days=0)

    mock_affinity_api.put.assert_not_called()


@pytest.mark.asyncio
async def test_update_reminder_recurring_with_is_completed_raises(
    mock_affinity_api,
):
    with pytest.raises(
        ValueError, match="is_completed cannot be used with RECURRING reminders"
    ):
        await update_reminder(
            reminder_id=1,
            reminder_type=ReminderType.RECURRING,
            is_completed=True,
        )

    mock_affinity_api.put.assert_not_called()


@pytest.mark.asyncio
async def test_update_reminder_all_parameters(mock_affinity_api, base_reminder):
    updated = {
        **base_reminder,
        "id": 10,
        "type": 0,
        "content": "Full update",
        "due_date": "2026-06-01T00:00:00Z",
        "reset_type": 0,
        "reminder_days": 7,
        "owner": {"id": 20, "first_name": "Alice", "last_name": "Wu"},
    }
    mock_affinity_api.put.return_value = updated

    result = await update_reminder(
        reminder_id=10,
        owner_id=20,
        reminder_type=ReminderType.ONE_TIME,
        content="Full update",
        due_date="2026-06-01T00:00:00Z",
        reset_type=ReminderResetType.INTERACTION,
        reminder_days=7,
        is_completed=False,
    )

    assert result == updated
    mock_affinity_api.put.assert_called_once_with(
        "/reminders/10",
        {
            "owner_id": 20,
            "type": ReminderType.ONE_TIME,
            "content": "Full update",
            "due_date": "2026-06-01T00:00:00Z",
            "reset_type": ReminderResetType.INTERACTION,
            "reminder_days": 7,
            "is_completed": False,
        },
    )


# ──────────────────────────────────────────────────────────────
# delete_reminder tests
# ──────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_delete_reminder_success(mock_affinity_api):
    mock_affinity_api.delete.return_value = {"success": True}

    result = await delete_reminder(reminder_id=123)

    assert result == {"success": True}
    mock_affinity_api.delete.assert_called_once_with("/reminders/123")
