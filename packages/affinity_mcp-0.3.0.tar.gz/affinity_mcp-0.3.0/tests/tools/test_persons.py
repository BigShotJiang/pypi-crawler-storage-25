import pytest
from unittest.mock import AsyncMock
from affinity_mcp.tools.persons import (
    search_persons,
    get_person_list_entries,
    get_person_info,
)
from affinity_mcp.types import FieldType


@pytest.fixture
def mock_affinity_api(mocker):
    mock_api_instance = AsyncMock()

    mock_persons_api = mocker.patch("affinity_mcp.tools.persons.AffinityAPI")
    mock_persons_api.return_value.__aenter__.return_value = mock_api_instance

    return mock_api_instance


@pytest.mark.asyncio
async def test_search_persons_with_default_filters(mock_affinity_api):
    mock_response = {
        "persons": [
            {
                "id": 38706,
                "type": 0,
                "first_name": "John",
                "last_name": "Doe",
                "primary_email": "john@affinity.co",
                "emails": [
                    "jdoe@alumni.stanford.edu",
                    "johnjdoe@gmail.com",
                ],
            },
        ],
        "next_page_token": "some_token",
    }

    mock_affinity_api.get.return_value = mock_response

    result = await search_persons()

    assert len(result["persons"]) == 1

    person = result["persons"][0]
    assert person["id"] == 38706
    assert person["type"] == 0
    assert person["first_name"] == "John"
    assert person["last_name"] == "Doe"
    assert person["primary_email"] == "john@affinity.co"
    assert person["emails"] == ["jdoe@alumni.stanford.edu", "johnjdoe@gmail.com"]
    assert result["next_page_token"] == "some_token"

    mock_affinity_api.get.assert_called_once_with("/persons", params={"page_size": 100})


@pytest.mark.asyncio
async def test_search_persons_with_term_no_page_size_reduce_page_size(
    mock_affinity_api,
):
    mock_response = {
        "persons": [
            {
                "id": 38706,
                "type": 0,
                "first_name": "John",
                "last_name": "Doe",
                "primary_email": "john@affinity.co",
                "emails": [
                    "jdoe@alumni.stanford.edu",
                    "johnjdoe@gmail.com",
                ],
            },
        ],
        "next_page_token": "some_token",
    }

    mock_affinity_api.get.return_value = mock_response

    result = await search_persons(term="John")

    assert len(result["persons"]) == 1

    person = result["persons"][0]
    assert person["id"] == 38706
    assert person["type"] == 0
    assert person["first_name"] == "John"
    assert person["last_name"] == "Doe"
    assert person["primary_email"] == "john@affinity.co"
    assert person["emails"] == ["jdoe@alumni.stanford.edu", "johnjdoe@gmail.com"]
    assert result["next_page_token"] == "some_token"

    mock_affinity_api.get.assert_called_once_with(
        "/persons", params={"term": "John", "page_size": 10}
    )


@pytest.mark.asyncio
async def test_search_persons_with_term_and_provided_page_size(mock_affinity_api):
    mock_response = {
        "persons": [
            {
                "id": 38706,
                "type": 0,
                "first_name": "John",
                "last_name": "Doe",
                "primary_email": "john@affinity.co",
                "emails": [
                    "jdoe@alumni.stanford.edu",
                    "johnjdoe@gmail.com",
                ],
            },
        ],
        "next_page_token": "some_token",
    }

    mock_affinity_api.get.return_value = mock_response

    result = await search_persons(term="John", page_size=50)

    assert len(result["persons"]) == 1

    person = result["persons"][0]
    assert person["id"] == 38706
    assert person["type"] == 0
    assert person["first_name"] == "John"
    assert person["last_name"] == "Doe"
    assert person["primary_email"] == "john@affinity.co"
    assert person["emails"] == ["jdoe@alumni.stanford.edu", "johnjdoe@gmail.com"]
    assert result["next_page_token"] == "some_token"

    mock_affinity_api.get.assert_called_once_with(
        "/persons", params={"term": "John", "page_size": 50}
    )


@pytest.mark.asyncio
async def test_search_persons_with_filters(mock_affinity_api):
    mock_response = {"persons": []}
    mock_affinity_api.get.return_value = mock_response

    await search_persons(
        term="Jane",
        with_interaction_dates=True,
        with_interaction_persons=True,
        with_opportunities=True,
        date_filters={"min_first_email_date": "2024-01-01T00:00:00Z"},
        page_size=50,
        page_token="next_page",
    )

    mock_affinity_api.get.assert_called_once_with(
        "/persons",
        params={
            "term": "Jane",
            "with_interaction_dates": True,
            "with_interaction_persons": True,
            "with_opportunities": True,
            "min_first_email_date": "2024-01-01T00:00:00Z",
            "page_size": 50,
            "page_token": "next_page",
        },
    )


@pytest.mark.asyncio
async def test_get_person_list_entries(mock_affinity_api):
    mock_response = {
        "pagination": {
            "prevUrl": "https://api.affinity.co/v2/foo?cursor=IFAgI7bdYmVmb3JlOqm6Nw",
            "nextUrl": "https://api.affinity.co/v2/foo?cursor=ICAgICAgIGFmdGVyOjo6NA",
        },
        "data": [
            {
                "listId": 1,
                "createdAt": "2023-01-01T00:00:00Z",
                "creatorId": 1,
                "id": 1,
                "fields": [
                    {
                        "enrichmentSource": "affinity-data",
                        "name": "Location",
                        "id": "affinity-data-location",
                        "type": "enriched",
                        "value": {},
                    },
                ],
            },
            {
                "listId": 1,
                "createdAt": "2023-01-01T00:00:00Z",
                "creatorId": 1,
                "id": 1,
                "fields": [{}, {}],
            },
        ],
    }

    mock_affinity_api.get.return_value = mock_response

    result = await get_person_list_entries(1)

    expected_response = {
        "pagination": {
            "prevUrl": "https://api.affinity.co/v2/foo?cursor=IFAgI7bdYmVmb3JlOqm6Nw",
            "nextUrl": "https://api.affinity.co/v2/foo?cursor=ICAgICAgIGFmdGVyOjo6NA",
        },
        "data": [
            {
                "listId": 1,
                "createdAt": "2023-01-01T00:00:00Z",
                "creatorId": 1,
                "id": 1,
            },
            {
                "listId": 1,
                "createdAt": "2023-01-01T00:00:00Z",
                "creatorId": 1,
                "id": 1,
            },
        ],
    }
    assert expected_response == result

    mock_affinity_api.get.assert_called_once_with(
        "/v2/persons/1/list-entries", params={"limit": 100}
    )


@pytest.mark.asyncio
async def test_get_person_list_entries_with_pagination(mock_affinity_api):
    mock_response = {
        "pagination": {
            "prevUrl": "https://api.affinity.co/v2/foo?cursor=ICAgICAgYmVmb3JlOjo6Nw",
            "nextUrl": None,
        },
        "data": [],
    }
    mock_affinity_api.get.return_value = mock_response

    result = await get_person_list_entries(1, "ICAgICAgIGFmdGVyOjo6NA", 1)

    assert mock_response == result
    mock_affinity_api.get.assert_called_once_with(
        "/v2/persons/1/list-entries",
        params={"cursor": "ICAgICAgIGFmdGVyOjo6NA", "limit": 1},
    )


@pytest.mark.asyncio
async def test_get_person_info_use_default_field_types(mock_affinity_api):
    mock_response = {
        "id": 38706,
        "firstName": "John",
        "lastName": "Doe",
        "primaryEmail": "john@affinity.co",
        "emails": ["john@affinity.co", "jdoe@alumni.stanford.edu"],
        "types": "external",
        "fields": [
            {
                "id": "affinity-data-job-title",
                "name": "Job Title",
                "type": "enriched",
                "value": {
                    "type": "text",
                    "data": "Software Engineer",
                },
            },
            {
                "id": "global-field-1",
                "name": "Notes",
                "type": "global",
                "enrichmentSource": "affinity-data",
                "value": {"type": "text", "data": "Great contact"},
            },
        ],
    }

    mock_affinity_api.get.return_value = mock_response

    result = await get_person_info(38706)

    assert mock_response == result

    mock_affinity_api.get.assert_called_once_with(
        "/v2/persons/38706",
        params={"fieldTypes": ["enriched", "global", "relationship-intelligence"]},
    )


@pytest.mark.asyncio
async def test_get_person_info_with_field_ids(mock_affinity_api):
    mock_response = {
        "id": 38706,
        "firstName": "John",
        "lastName": "Doe",
        "primaryEmail": "john@affinity.co",
        "emails": ["john@affinity.co"],
        "types": "external",
        "fields": [
            {
                "id": "field-1",
                "name": "Custom Field",
                "type": "global",
                "enrichmentSource": "affinity-data",
                "value": {"type": "text", "data": "Custom value"},
            }
        ],
    }

    mock_affinity_api.get.return_value = mock_response

    result = await get_person_info(38706, field_ids=["field-1", "field-2"])

    assert mock_response == result

    mock_affinity_api.get.assert_called_once_with(
        "/v2/persons/38706", params={"fieldIds": ["field-1", "field-2"]}
    )


@pytest.mark.asyncio
async def test_get_person_info_with_field_types(mock_affinity_api):
    mock_response = {
        "id": 38706,
        "firstName": "John",
        "lastName": "Doe",
        "primaryEmail": "john@affinity.co",
        "emails": ["john@affinity.co"],
        "types": "external",
        "fields": [
            {
                "id": "enriched-field-1",
                "name": "Enriched Field",
                "type": "enriched",
                "enrichmentSource": "affinity-data",
                "value": {"type": "text", "data": "Enriched data"},
            }
        ],
    }

    mock_affinity_api.get.return_value = mock_response

    result = await get_person_info(38706, field_types=[FieldType.ENRICHED])

    assert mock_response == result

    mock_affinity_api.get.assert_called_once_with(
        "/v2/persons/38706", params={"fieldTypes": ["enriched"]}
    )


@pytest.mark.asyncio
async def test_get_person_info_with_field_ids_and_field_types(mock_affinity_api):
    mock_response = {
        "id": 38706,
        "firstName": "John",
        "lastName": "Doe",
        "primaryEmail": "john@affinity.co",
        "emails": ["john@affinity.co"],
        "types": "external",
        "fields": [
            {
                "id": "enriched-field-1",
                "name": "Enriched Field",
                "type": "enriched",
                "enrichmentSource": "affinity-data",
                "value": {"type": "text", "data": "Enriched data"},
            }
        ],
    }

    mock_affinity_api.get.return_value = mock_response

    result = await get_person_info(
        38706, field_ids=["field-1"], field_types=[FieldType.GLOBAL]
    )

    assert result["id"] == 38706

    mock_affinity_api.get.assert_called_once_with(
        "/v2/persons/38706",
        params={"fieldIds": ["field-1"], "fieldTypes": ["global"]},
    )


@pytest.mark.asyncio
async def test_get_person_info_filters_out_list_field_type(mock_affinity_api):
    mock_response = {
        "id": 38706,
        "firstName": "John",
        "lastName": "Doe",
        "primaryEmail": "john@affinity.co",
        "emails": ["john@affinity.co"],
        "types": "external",
        "fields": [
            {
                "id": "enriched-field-1",
                "name": "Enriched Field",
                "type": "enriched",
                "enrichmentSource": "affinity-data",
                "value": {"type": "text", "data": "Enriched data"},
            }
        ],
    }

    mock_affinity_api.get.return_value = mock_response

    result = await get_person_info(
        38706, field_ids=["field-1"], field_types=[FieldType.GLOBAL, FieldType.LIST]
    )

    assert result["id"] == 38706

    mock_affinity_api.get.assert_called_once_with(
        "/v2/persons/38706",
        params={"fieldIds": ["field-1"], "fieldTypes": ["global"]},
    )
