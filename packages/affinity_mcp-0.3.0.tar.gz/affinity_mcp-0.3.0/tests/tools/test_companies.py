import pytest
import httpx
from unittest.mock import AsyncMock
from affinity_mcp.tools.companies import (
    search_companies,
    get_company_list_entries,
    get_company_info,
)
from affinity_mcp.types import FieldType


@pytest.fixture
def mock_affinity_api(mocker):
    mock_api_instance = AsyncMock()

    mock_companies_api = mocker.patch("affinity_mcp.tools.companies.AffinityAPI")
    mock_companies_api.return_value.__aenter__.return_value = mock_api_instance

    return mock_api_instance


@pytest.mark.asyncio
async def test_search_companies_with_default_filters(mock_affinity_api):
    mock_response = {
        "organizations": [
            {
                "id": 64779194,
                "name": "Affinity",
                "domain": "affinity.co",
                "domains": ["affinity.co"],
                "global": False,
            },
        ],
        "next_page_token": "some_token",
    }

    mock_affinity_api.get.return_value = mock_response

    result = await search_companies()

    assert len(result["organizations"]) == 1

    organization = result["organizations"][0]
    assert organization["id"] == 64779194
    assert organization["name"] == "Affinity"
    assert organization["domain"] == "affinity.co"
    assert organization["domains"] == ["affinity.co"]
    assert organization["global"] is False
    assert result["next_page_token"] == "some_token"

    mock_affinity_api.get.assert_called_once_with(
        "/organizations", params={"page_size": 100}
    )


@pytest.mark.asyncio
async def test_search_companies_with_term_no_page_size_reduce_page_size(
    mock_affinity_api,
):
    mock_response = {
        "organizations": [
            {
                "id": 64779194,
                "name": "Affinity",
                "domain": "affinity.co",
                "domains": ["affinity.co"],
                "global": False,
            },
        ],
        "next_page_token": "some_token",
    }

    mock_affinity_api.get.return_value = mock_response

    result = await search_companies(term="Affinity")

    assert len(result["organizations"]) == 1

    organization = result["organizations"][0]
    assert organization["id"] == 64779194
    assert organization["name"] == "Affinity"
    assert organization["domain"] == "affinity.co"
    assert organization["domains"] == ["affinity.co"]
    assert organization["global"] is False
    assert result["next_page_token"] == "some_token"

    mock_affinity_api.get.assert_called_once_with(
        "/organizations", params={"term": "Affinity", "page_size": 10}
    )


@pytest.mark.asyncio
async def test_search_companies_with_term_and_provided_page_size(mock_affinity_api):
    mock_response = {
        "organizations": [
            {
                "id": 64779194,
                "name": "Affinity",
                "domain": "affinity.co",
                "domains": ["affinity.co"],
                "global": False,
            },
        ],
        "next_page_token": "some_token",
    }

    mock_affinity_api.get.return_value = mock_response

    result = await search_companies(term="Affinity", page_size=50)

    assert len(result["organizations"]) == 1

    organization = result["organizations"][0]
    assert organization["id"] == 64779194
    assert organization["name"] == "Affinity"
    assert organization["domain"] == "affinity.co"
    assert organization["domains"] == ["affinity.co"]
    assert organization["global"] is False
    assert result["next_page_token"] == "some_token"

    mock_affinity_api.get.assert_called_once_with(
        "/organizations", params={"term": "Affinity", "page_size": 50}
    )


@pytest.mark.asyncio
async def test_search_companies_with_filters(mock_affinity_api):
    mock_response = {"organizations": []}
    mock_affinity_api.get.return_value = mock_response

    await search_companies(
        term="Acme",
        with_interaction_dates=True,
        with_interaction_persons=True,
        with_opportunities=True,
        page_size=20,
        page_token="next_page",
    )

    mock_affinity_api.get.assert_called_once_with(
        "/organizations",
        params={
            "term": "Acme",
            "with_interaction_dates": True,
            "with_interaction_persons": True,
            "with_opportunities": True,
            "page_size": 20,
            "page_token": "next_page",
        },
    )


@pytest.mark.asyncio
async def test_search_companies_with_invalid_date_passed_to_api(mock_affinity_api):
    request = httpx.Request("GET", "https://api.affinity.co/organizations")
    response = httpx.Response(
        422, request=request, json={"error": "Invalid date format"}
    )
    error = httpx.HTTPStatusError(
        "Unprocessable Entity", request=request, response=response
    )

    mock_affinity_api.get.side_effect = error

    with pytest.raises(httpx.HTTPStatusError) as exc_info:
        await search_companies(
            term="Acme", date_filters={"min_first_email_date": "yesterday"}
        )

    assert exc_info.value.response.status_code == 422

    mock_affinity_api.get.assert_called_once_with(
        "/organizations",
        params={
            "term": "Acme",
            "min_first_email_date": "yesterday",
            "page_size": 10,
        },
    )


@pytest.mark.asyncio
async def test_get_company_list_entries(mock_affinity_api):
    mock_response = {
        "pagination": {
            "prevUrl": "https://api.affinity.co/v2/foo?cursor=ICAgICAgYmVmb3JlOjo6Nw",
            "nextUrl": "https://api.affinity.co/v2/foo?cursor=ICAgICAgIGFmdGVyOjo6NA",
        },
        "data": [
            {
                "listId": 1,
                "createdAt": "2023-01-01T00:00:00Z",
                "creatorId": 1,
                "id": 1,
                "fields": [
                    {
                        "enrichmentSource": "affinity-data",
                        "name": "Location",
                        "id": "affinity-data-location",
                        "type": "enriched",
                        "value": {
                            "data": {
                                "continent": "North America",
                                "country": "United States",
                                "streetAddress": "1 Main Street",
                                "city": "San Francisco",
                                "state": "California",
                            },
                            "type": "location",
                        },
                    }
                ],
            }
        ],
    }

    mock_affinity_api.get.return_value = mock_response

    result = await get_company_list_entries(1)

    expected_response = {
        "pagination": {
            "prevUrl": "https://api.affinity.co/v2/foo?cursor=ICAgICAgYmVmb3JlOjo6Nw",
            "nextUrl": "https://api.affinity.co/v2/foo?cursor=ICAgICAgIGFmdGVyOjo6NA",
        },
        "data": [
            {
                "listId": 1,
                "createdAt": "2023-01-01T00:00:00Z",
                "creatorId": 1,
                "id": 1,
            }
        ],
    }
    assert expected_response == result

    mock_affinity_api.get.assert_called_once_with(
        "/v2/companies/1/list-entries", params={"limit": 100}
    )


@pytest.mark.asyncio
async def test_get_company_list_entries_with_pagination(mock_affinity_api):
    mock_response = {
        "pagination": {
            "prevUrl": "https://api.affinity.co/v2/foo?cursor=ICAgICAgYmVmb3JlOjo6Nw",
            "nextUrl": None,
        },
        "data": [],
    }
    mock_affinity_api.get.return_value = mock_response

    result = await get_company_list_entries(1, "ICAgICAgIGFmdGVyOjo6NA", 1)

    assert mock_response == result
    mock_affinity_api.get.assert_called_once_with(
        "/v2/companies/1/list-entries",
        params={"cursor": "ICAgICAgIGFmdGVyOjo6NA", "limit": 1},
    )


@pytest.mark.asyncio
async def test_get_company_info_use_default_field_types(mock_affinity_api):
    mock_response = {
        "id": 12345,
        "name": "Acme Corp",
        "domain": "acme.com",
        "domains": ["acme.com"],
        "isGlobal": True,
        "fields": [
            {
                "id": "affinity-data-location",
                "name": "Location",
                "type": "enriched",
                "value": {
                    "type": "location",
                    "data": {
                        "city": "San Francisco",
                        "state": "California",
                        "country": "United States",
                    },
                },
            },
            {
                "id": "global-field-1",
                "name": "Description",
                "type": "global",
                "enrichmentSource": "affinity-data",
                "value": {"type": "text", "data": "A great company"},
            },
        ],
    }

    mock_affinity_api.get.return_value = mock_response

    result = await get_company_info(12345)

    assert mock_response == result

    mock_affinity_api.get.assert_called_once_with(
        "/v2/companies/12345",
        params={"fieldTypes": ["enriched", "global", "relationship-intelligence"]},
    )


@pytest.mark.asyncio
async def test_get_company_info_with_field_ids(mock_affinity_api):
    mock_response = {
        "id": 12345,
        "name": "Acme Corp",
        "domain": "acme.com",
        "domains": ["acme.com"],
        "isGlobal": True,
        "fields": [
            {
                "id": "field-1",
                "name": "Custom Field",
                "type": "global",
                "enrichmentSource": "affinity-data",
                "value": {"type": "text", "data": "Custom value"},
            }
        ],
    }

    mock_affinity_api.get.return_value = mock_response

    result = await get_company_info(12345, field_ids=["field-1", "field-2"])

    assert result["id"] == 12345
    assert result["name"] == "Acme Corp"
    assert len(result["fields"]) == 1

    mock_affinity_api.get.assert_called_once_with(
        "/v2/companies/12345", params={"fieldIds": ["field-1", "field-2"]}
    )


@pytest.mark.asyncio
async def test_get_company_info_with_field_types(mock_affinity_api):
    mock_response = {
        "id": 12345,
        "name": "Acme Corp",
        "domain": "acme.com",
        "domains": ["acme.com"],
        "isGlobal": True,
        "fields": [
            {
                "id": "enriched-field-1",
                "name": "Enriched Field",
                "type": "enriched",
                "enrichmentSource": "affinity-data",
                "value": {"type": "text", "data": "Enriched data"},
            }
        ],
    }

    mock_affinity_api.get.return_value = mock_response

    result = await get_company_info(12345, field_types=[FieldType.ENRICHED])

    assert mock_response == result

    mock_affinity_api.get.assert_called_once_with(
        "/v2/companies/12345", params={"fieldTypes": ["enriched"]}
    )


@pytest.mark.asyncio
async def test_get_company_info_with_field_ids_and_field_types(mock_affinity_api):
    mock_response = {
        "id": 12345,
        "name": "Acme Corp",
        "domain": "acme.com",
        "domains": ["acme.com"],
        "isGlobal": True,
        "fields": [
            {
                "id": "field-1",
                "name": "Custom Field",
                "type": "global",
                "enrichmentSource": "affinity-data",
                "value": {"type": "text", "data": "Custom value"},
            }
        ],
    }

    mock_affinity_api.get.return_value = mock_response

    result = await get_company_info(
        12345, field_ids=["field-1"], field_types=[FieldType.GLOBAL]
    )

    assert mock_response == result

    mock_affinity_api.get.assert_called_once_with(
        "/v2/companies/12345",
        params={"fieldIds": ["field-1"], "fieldTypes": ["global"]},
    )


@pytest.mark.asyncio
async def test_get_company_info_filters_out_list_field_type(mock_affinity_api):
    mock_response = {
        "id": 12345,
        "name": "Acme Corp",
        "domain": "acme.com",
        "domains": ["acme.com"],
        "isGlobal": True,
        "fields": [
            {
                "id": "field-1",
                "name": "Custom Field",
                "type": "global",
                "enrichmentSource": "affinity-data",
                "value": {"type": "text", "data": "Custom value"},
            }
        ],
    }

    mock_affinity_api.get.return_value = mock_response

    result = await get_company_info(
        12345, field_ids=["field-1"], field_types=[FieldType.GLOBAL, FieldType.LIST]
    )

    assert mock_response == result

    mock_affinity_api.get.assert_called_once_with(
        "/v2/companies/12345",
        params={"fieldIds": ["field-1"], "fieldTypes": ["global"]},
    )
