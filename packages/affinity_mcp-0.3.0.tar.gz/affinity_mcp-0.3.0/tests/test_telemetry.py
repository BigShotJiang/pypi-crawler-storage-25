"""Tests for the telemetry module."""

import pytest
import affinity_mcp.telemetry as telemetry_module
from affinity_mcp.context import TransportMode
from affinity_mcp.telemetry import configure_telemetry, instrument_tool
from opentelemetry.sdk.trace import TracerProvider as SDKTracerProvider
from opentelemetry.sdk.trace.export import SimpleSpanProcessor
from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter
from opentelemetry.sdk.metrics import MeterProvider as SDKMeterProvider
from opentelemetry.sdk.metrics.export import InMemoryMetricReader
from opentelemetry.trace import StatusCode


# ---------------------------------------------------------------------------
# Shared fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def in_memory_tracer(mocker):
    exporter = InMemorySpanExporter()
    provider = SDKTracerProvider()
    provider.add_span_processor(SimpleSpanProcessor(exporter))
    tracer = provider.get_tracer("affinity-mcp")
    mocker.patch("affinity_mcp.telemetry.otel_trace.get_tracer", return_value=tracer)
    yield exporter
    exporter.clear()


@pytest.fixture
def in_memory_meter(mocker):
    reader = InMemoryMetricReader()
    provider = SDKMeterProvider(metric_readers=[reader])
    meter = provider.get_meter("affinity-mcp")
    mocker.patch("affinity_mcp.telemetry.otel_metrics.get_meter", return_value=meter)
    yield reader


@pytest.fixture(autouse=True)
def _telemetry_isolation():
    import logging

    mcp_logger = logging.getLogger("mcp")
    original_level = mcp_logger.level
    original_handlers = mcp_logger.handlers[:]
    original_propagate = mcp_logger.propagate

    telemetry_module._tool_instruments = None
    yield
    telemetry_module._tool_instruments = None
    for attr in ("_meter_provider", "_tracer_provider"):
        provider = getattr(telemetry_module, attr, None)
        if provider is not None:
            try:
                provider.shutdown()
            except Exception:
                pass
            setattr(telemetry_module, attr, None)

    mcp_logger.level = original_level
    mcp_logger.handlers = original_handlers
    mcp_logger.propagate = original_propagate


# ---------------------------------------------------------------------------
# TestConfigureTracing
# ---------------------------------------------------------------------------


class TestConfigureTracing:
    def _common_patches(self, mocker):
        mock_ratio = mocker.patch("opentelemetry.sdk.trace.sampling.TraceIdRatioBased")
        mock_parent = mocker.patch("opentelemetry.sdk.trace.sampling.ParentBased")
        mock_provider_cls = mocker.patch("opentelemetry.sdk.trace.TracerProvider")
        mocker.patch("opentelemetry.sdk.trace.export.BatchSpanProcessor")
        mocker.patch(
            "opentelemetry.exporter.otlp.proto.http.trace_exporter.OTLPSpanExporter"
        )
        mocker.patch("opentelemetry.trace.set_tracer_provider")
        mocker.patch("opentelemetry.propagate.set_global_textmap")
        mocker.patch("affinity_mcp.telemetry._build_otel_resource")
        return mock_ratio, mock_parent, mock_provider_cls

    def test_default_sample_rate_is_10_percent(self, mocker):
        from affinity_mcp.telemetry import _configure_tracing

        mocker.patch.dict("os.environ", {}, clear=True)
        mocker.patch("affinity_mcp.telemetry.logger")
        mock_ratio, mock_parent, mock_provider_cls = self._common_patches(mocker)

        _configure_tracing()

        mock_ratio.assert_called_once_with(1.0)
        mock_parent.assert_called_once_with(mock_ratio.return_value)
        _, kwargs = mock_provider_cls.call_args
        assert kwargs["sampler"] is mock_parent.return_value

    def test_sample_rate_is_configurable_via_env_var(self, mocker):
        from affinity_mcp.telemetry import _configure_tracing

        mocker.patch.dict("os.environ", {"OTEL_TRACES_SAMPLER_ARG": "0.5"}, clear=True)
        mocker.patch("affinity_mcp.telemetry.logger")
        mock_ratio, mock_parent, mock_provider_cls = self._common_patches(mocker)

        _configure_tracing()

        mock_ratio.assert_called_once_with(0.5)
        mock_parent.assert_called_once_with(mock_ratio.return_value)
        _, kwargs = mock_provider_cls.call_args
        assert kwargs["sampler"] is mock_parent.return_value

    def test_invalid_sample_rate_falls_back_to_default(self, mocker):
        from affinity_mcp.telemetry import _configure_tracing

        mocker.patch.dict(
            "os.environ", {"OTEL_TRACES_SAMPLER_ARG": "not-a-number"}, clear=True
        )
        mock_logger = mocker.patch("affinity_mcp.telemetry.logger")
        mock_ratio, _, _ = self._common_patches(mocker)

        _configure_tracing()

        mock_ratio.assert_called_once_with(1.0)
        mock_logger.bind.assert_any_call(value="not-a-number", default=1.0)
        mock_logger.bind.return_value.warning.assert_called_once_with(
            "Invalid OTEL_TRACES_SAMPLER_ARG value, falling back to default"
        )

    def test_out_of_range_sample_rate_falls_back_to_default(self, mocker):
        from affinity_mcp.telemetry import _configure_tracing

        mocker.patch.dict("os.environ", {"OTEL_TRACES_SAMPLER_ARG": "1.5"}, clear=True)
        mock_logger = mocker.patch("affinity_mcp.telemetry.logger")
        mock_ratio, _, _ = self._common_patches(mocker)

        _configure_tracing()

        mock_ratio.assert_called_once_with(1.0)
        mock_logger.bind.assert_any_call(value="1.5", default=1.0)
        mock_logger.bind.return_value.warning.assert_called_once_with(
            "Invalid OTEL_TRACES_SAMPLER_ARG value, falling back to default"
        )


# ---------------------------------------------------------------------------
# TestConfigureTelemetry
# ---------------------------------------------------------------------------


class TestConfigureTelemetry:
    def test_stdio_mode_does_not_call_otel_setup(self, mocker):
        mocker.patch.dict("os.environ", {}, clear=False)
        mocker.patch("os.getenv", return_value=None)
        mock_otel = mocker.patch("affinity_mcp.telemetry._configure_otel")

        configure_telemetry(TransportMode.STDIO)

        mock_otel.assert_not_called()

    def test_stdio_mode_activates_telemetry_when_otlp_endpoint_is_set(self, mocker):
        mocker.patch.dict(
            "os.environ", {"OTEL_EXPORTER_OTLP_ENDPOINT": "http://localhost:4318"}
        )
        mock_otel = mocker.patch("affinity_mcp.telemetry._configure_otel")

        configure_telemetry(TransportMode.STDIO)

        mock_otel.assert_called_once()

    def test_http_mode_calls_all_setup_helpers(self, mocker):
        mock_tracing = mocker.patch("affinity_mcp.telemetry._configure_tracing")
        mock_logging = mocker.patch("affinity_mcp.telemetry._configure_json_logging")
        mock_metrics = mocker.patch("affinity_mcp.telemetry._configure_metrics")

        configure_telemetry(TransportMode.HTTP)

        mock_tracing.assert_called_once()
        mock_logging.assert_called_once()
        mock_metrics.assert_called_once()

    def test_configure_metrics_calls_set_meter_provider(self, mocker):
        from affinity_mcp.telemetry import _configure_metrics

        mocker.patch("affinity_mcp.telemetry.logger")
        mock_set = mocker.patch("opentelemetry.metrics.set_meter_provider")
        # Prevent real OTLP connections and background export threads
        mocker.patch("opentelemetry.sdk.metrics.export.PeriodicExportingMetricReader")
        mocker.patch(
            "opentelemetry.exporter.otlp.proto.http.metric_exporter.OTLPMetricExporter"
        )

        _configure_metrics()

        mock_set.assert_called_once()

    def test_http_mode_falls_back_gracefully_when_setup_helpers_raise(self, mocker):
        mocker.patch(
            "affinity_mcp.telemetry._configure_tracing",
            side_effect=ImportError("opentelemetry-sdk not installed"),
        )
        mock_logging = mocker.patch("affinity_mcp.telemetry._configure_json_logging")
        mocker.patch(
            "affinity_mcp.telemetry._configure_metrics",
            side_effect=ImportError("opentelemetry-sdk not installed"),
        )
        mock_logger = mocker.patch("affinity_mcp.telemetry.logger")

        configure_telemetry(TransportMode.HTTP)

        # JSON logging must still be configured even though tracing and metrics failed
        mock_logging.assert_called_once()
        assert mock_logger.warning.call_count == 2

    def test_configure_json_logging_intercepts_mcp_logger(self, mocker):
        from affinity_mcp.telemetry import _configure_json_logging
        import logging

        mocker.patch("affinity_mcp.telemetry.logger")
        _configure_json_logging()

        mcp_logger = logging.getLogger("mcp")
        assert mcp_logger.level == logging.ERROR
        assert len(mcp_logger.handlers) == 1
        assert not mcp_logger.propagate

    def test_configure_json_logging_silences_mcp_logs_below_error(self, mocker):
        from affinity_mcp.telemetry import _configure_json_logging
        import logging

        mock_logger = mocker.patch("affinity_mcp.telemetry.logger")
        _configure_json_logging()

        logging.getLogger("mcp").info("should be dropped")
        logging.getLogger("mcp").warning("also dropped")

        mock_logger.opt.assert_not_called()

    def test_configure_json_logging_forwards_mcp_errors_to_loguru(self, mocker):
        from affinity_mcp.telemetry import _configure_json_logging
        import logging

        mock_logger = mocker.patch("affinity_mcp.telemetry.logger")
        mock_logger.level.return_value.name = "ERROR"
        mock_logger.opt.return_value.log = mocker.Mock()
        _configure_json_logging()

        logging.getLogger("mcp").error("something went wrong")

        mock_logger.opt.assert_called_once()
        mock_logger.opt.return_value.log.assert_called_once_with(
            "ERROR", "something went wrong"
        )

    def test_http_mode_starts_server_even_when_all_setup_helpers_raise(self, mocker):
        mocker.patch(
            "affinity_mcp.telemetry._configure_tracing",
            side_effect=Exception("tracing unavailable"),
        )
        mocker.patch(
            "affinity_mcp.telemetry._configure_json_logging",
            side_effect=Exception("logging unavailable"),
        )
        mocker.patch(
            "affinity_mcp.telemetry._configure_metrics",
            side_effect=Exception("metrics unavailable"),
        )
        mock_logger = mocker.patch("affinity_mcp.telemetry.logger")

        configure_telemetry(TransportMode.HTTP)

        assert mock_logger.warning.call_count == 3


# ---------------------------------------------------------------------------
# TestInstrumentTool
# ---------------------------------------------------------------------------


class TestInstrumentTool:
    # ── Decorator basics ────────────────────────────────────────────────────

    def test_preserves_function_name(self):
        async def my_tool() -> str:
            return "result"

        assert instrument_tool(my_tool).__name__ == "my_tool"

    def test_preserves_docstring(self):
        async def my_tool() -> str:
            """Fetches important data."""
            return "result"

        assert instrument_tool(my_tool).__doc__ == "Fetches important data."

    # ── Return value and exception behaviour ────────────────────────────────

    @pytest.mark.asyncio
    async def test_returns_result_on_success(self, in_memory_tracer, in_memory_meter):
        async def my_tool() -> dict:
            return {"id": 1}

        result = await instrument_tool(my_tool)()

        assert result == {"id": 1}

    @pytest.mark.asyncio
    async def test_reraises_exception(self, in_memory_tracer, in_memory_meter):
        async def failing_tool() -> None:
            raise ValueError("something went wrong")

        with pytest.raises(ValueError, match="something went wrong"):
            await instrument_tool(failing_tool)()

    # ── Tracing ─────────────────────────────────────────────────────────────

    @pytest.mark.asyncio
    async def test_creates_span_with_correct_name(
        self, in_memory_tracer, in_memory_meter
    ):
        async def search_companies() -> dict:
            return {}

        await instrument_tool(search_companies)()

        spans = in_memory_tracer.get_finished_spans()
        assert len(spans) == 1
        assert spans[0].name == "search_companies"

    @pytest.mark.asyncio
    async def test_sets_tool_name_attribute_on_span(
        self, in_memory_tracer, in_memory_meter
    ):
        async def get_company_info() -> dict:
            return {}

        await instrument_tool(get_company_info)()

        spans = in_memory_tracer.get_finished_spans()
        assert spans[0].attributes["affinity.tool.name"] == "get_company_info"

    @pytest.mark.asyncio
    async def test_sets_span_status_ok_on_success(
        self, in_memory_tracer, in_memory_meter
    ):
        async def my_tool() -> str:
            return "ok"

        await instrument_tool(my_tool)()

        spans = in_memory_tracer.get_finished_spans()
        assert spans[0].status.status_code == StatusCode.OK
        assert spans[0].attributes["http.status_code"] == 200

    @pytest.mark.asyncio
    async def test_sets_span_status_error_on_exception(
        self, in_memory_tracer, in_memory_meter
    ):
        async def broken_tool() -> None:
            raise RuntimeError("API timeout")

        with pytest.raises(RuntimeError):
            await instrument_tool(broken_tool)()

        spans = in_memory_tracer.get_finished_spans()
        assert spans[0].status.status_code == StatusCode.ERROR
        assert spans[0].attributes["http.status_code"] == 500

    @pytest.mark.asyncio
    async def test_records_exception_on_span(self, in_memory_tracer, in_memory_meter):
        async def broken_tool() -> None:
            raise ValueError("bad input")

        with pytest.raises(ValueError):
            await instrument_tool(broken_tool)()

        spans = in_memory_tracer.get_finished_spans()
        assert any(e.name == "exception" for e in spans[0].events)

    # ── Metrics ─────────────────────────────────────────────────────────────

    @pytest.mark.asyncio
    async def test_increments_call_counter_on_success(
        self, in_memory_tracer, in_memory_meter
    ):
        async def my_tool() -> str:
            return "ok"

        await instrument_tool(my_tool)()

        metrics = _collect_metrics(in_memory_meter, "affinity.mcp.tool.calls")
        assert metrics is not None
        _assert_data_point(
            metrics, attributes={"tool": "my_tool", "status": "success"}, value=1
        )

    @pytest.mark.asyncio
    async def test_increments_call_counter_on_exception(
        self, in_memory_tracer, in_memory_meter
    ):
        async def broken_tool() -> None:
            raise TypeError("wrong type")

        with pytest.raises(TypeError):
            await instrument_tool(broken_tool)()

        metrics = _collect_metrics(in_memory_meter, "affinity.mcp.tool.calls")
        assert metrics is not None
        _assert_data_point(
            metrics, attributes={"tool": "broken_tool", "status": "error"}, value=1
        )

    @pytest.mark.asyncio
    async def test_increments_error_counter_on_exception(
        self, in_memory_tracer, in_memory_meter
    ):
        async def broken_tool() -> None:
            raise TypeError("wrong type")

        with pytest.raises(TypeError):
            await instrument_tool(broken_tool)()

        metrics = _collect_metrics(in_memory_meter, "affinity.mcp.tool.errors")
        assert metrics is not None
        _assert_data_point(
            metrics, attributes={"tool": "broken_tool", "error": "TypeError"}, value=1
        )

    @pytest.mark.asyncio
    async def test_records_duration_histogram_on_success(
        self, in_memory_tracer, in_memory_meter
    ):
        async def my_tool() -> str:
            return "ok"

        await instrument_tool(my_tool)()

        metrics = _collect_metrics(in_memory_meter, "affinity.mcp.tool.duration_ms")
        assert metrics is not None
        # Histogram data points have a sum; verify it's a non-negative number
        point = metrics.data.data_points[0]
        assert point.sum >= 0

    @pytest.mark.asyncio
    async def test_records_duration_histogram_even_on_exception(
        self, in_memory_tracer, in_memory_meter
    ):
        async def broken_tool() -> None:
            raise RuntimeError("oops")

        with pytest.raises(RuntimeError):
            await instrument_tool(broken_tool)()

        metrics = _collect_metrics(in_memory_meter, "affinity.mcp.tool.duration_ms")
        assert metrics is not None
        assert len(metrics.data.data_points) == 1


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _collect_metrics(reader: InMemoryMetricReader, metric_name: str):
    """Return the first metric with the given name from the reader, or None."""
    data = reader.get_metrics_data()
    if data is None:
        return None
    for resource_metric in data.resource_metrics:
        for scope_metric in resource_metric.scope_metrics:
            for metric in scope_metric.metrics:
                if metric.name == metric_name:
                    return metric
    return None


def _assert_data_point(metric, attributes: dict, value: int) -> None:
    """Assert that a metric has a data point matching the given attributes and value."""
    for point in metric.data.data_points:
        if dict(point.attributes) == attributes and point.value == value:
            return
    raise AssertionError(
        f"No data point with attributes={attributes} and value={value} found in {metric.name}. "
        f"Points: {[(dict(p.attributes), p.value) for p in metric.data.data_points]}"
    )
