"""ServiceCallNode — call a @step method on a Service as a DAG node.

This node provides direct YAML-to-Service wiring: YAML pipelines reference
a service name and method, and at execution time the bound ``@step`` method
is called with the node's input.  No intermediate bridge layer.

The raw return value of the ``@step`` method is passed directly to
downstream nodes — no envelope wrapping.

YAML usage::

    - kind: service_call_node          # or system:service_call
      metadata:
        name: save_order
      spec:
        service: orders                # references spec.services.orders
        method: save_order             # @step method name
"""

from __future__ import annotations

import inspect
from typing import TYPE_CHECKING, Any, ClassVar

from hexdag.kernel.context import get_services
from hexdag.kernel.logging import get_logger
from hexdag.kernel.utils.node_timer import node_timer

from .base_node_factory import BaseNodeFactory

if TYPE_CHECKING:
    from hexdag.kernel.domain.dag import NodeSpec

logger = get_logger(__name__)


def _auto_infer_params(
    filtered: dict[str, Any],
    missing: set[str],
    input_data: dict[str, Any],
    method_name: str,
    service_name: str,
) -> dict[str, Any]:
    """Search upstream node outputs for missing @step parameters.

    When a ``service_call_node`` has no explicit ``input_mapping``, the
    additive input dict contains ``{node_name: result_dict, ...}``.
    This function searches those result dicts (and ``input`` for pipeline
    input) for keys matching the missing param names.

    If a param name is found in exactly one upstream source, it is
    auto-mapped.  Ambiguous matches (same key in multiple sources)
    are skipped with a debug log.
    """
    result = dict(filtered)

    for param in missing:
        sources: list[tuple[str, Any]] = []

        for key, value in input_data.items():
            if isinstance(value, dict) and param in value:
                sources.append((key, value[param]))

        if len(sources) == 1:
            result[param] = sources[0][1]
        elif len(sources) > 1:
            source_names = [s[0] for s in sources]
            logger.debug(
                "Auto-infer: param '{}' for {}.{} found in multiple "
                "upstream sources: {}. Skipping (use explicit input_mapping).",
                param,
                service_name,
                method_name,
                source_names,
            )

    return result


class ServiceCallNode(BaseNodeFactory, yaml_alias="service_call_node"):
    """Call a ``@step`` method on a Service as a deterministic DAG node.

    At execution time, the node:

    1. Retrieves services from the execution context.
    2. Looks up the named service.
    3. Looks up the method via ``service.get_steps()`` (validates ``@step``).
    4. Calls the bound method with the node's input data.
    5. Returns the raw result from the ``@step`` method.

    Errors raise as exceptions (handled by the orchestrator's retry/error
    system) rather than being wrapped in an output envelope.

    Examples
    --------
    Direct (programmatic) usage::

        factory = ServiceCallNode()
        node = factory(
            name="save_order",
            service="orders",
            method="save_order",
        )

    YAML usage::

        - kind: service_call_node
          metadata:
            name: save_order
          spec:
            service: orders
            method: save_order
    """

    # Studio UI metadata
    _hexdag_icon: ClassVar[str] = "Cog"
    _hexdag_color: ClassVar[str] = "#10b981"  # emerald-500

    # System kind marker — enables ``system:`` namespace aliases in discovery.
    _hexdag_system_kind: ClassVar[bool] = True

    def __call__(
        self,
        name: str,
        service: str,
        method: str,
        deps: list[str] | None = None,
        **kwargs: Any,
    ) -> NodeSpec:
        """Create a NodeSpec that calls a ``@step`` method on a Service.

        Parameters
        ----------
        name:
            Node name (must be unique within the pipeline).
        service:
            Name of the service declared in ``spec.services``.
        method:
            Name of the ``@step`` method to call.
        deps:
            Explicit dependencies.
        **kwargs:
            Framework params (``timeout``, ``max_retries``, ``when``, etc.)
            and any extra params forwarded to ``create_node_with_mapping``.
        """
        service_name = service
        method_name = method

        async def execute_service_call(input_data: dict[str, Any]) -> Any:
            """Resolve service + method at runtime and call with *input_data*."""
            # 1. Get services from execution context
            services = get_services()
            if not services:
                msg = "No services available in execution context"
                raise RuntimeError(msg)

            # 2. Look up service instance
            svc = services.get(service_name)
            if svc is None:
                available = list(services.keys())
                msg = f"Service '{service_name}' not found. Available: {available}"
                raise KeyError(msg)

            # 3. Look up method via get_steps() — validates @step
            steps = svc.get_steps()
            step_fn = steps.get(method_name)
            if step_fn is None:
                available_steps = list(steps.keys())
                msg = (
                    f"Method '{method_name}' is not a @step on "
                    f"service '{service_name}'. "
                    f"Available steps: {available_steps}"
                )
                raise AttributeError(msg)

            # 4. Filter input to match method signature + auto-infer from
            #    upstream node outputs when no explicit input_mapping is used.
            sig = inspect.signature(step_fn)
            params = sig.parameters
            if any(p.kind == p.VAR_KEYWORD for p in params.values()):
                filtered = input_data
            else:
                accepted = {
                    n
                    for n, p in params.items()
                    if p.kind in (p.POSITIONAL_OR_KEYWORD, p.KEYWORD_ONLY)
                }
                filtered = {k: v for k, v in input_data.items() if k in accepted}

                # Auto-infer: for accepted params not found at top level,
                # search inside upstream node result dicts and $input.
                missing = accepted - filtered.keys()
                if missing:
                    filtered = _auto_infer_params(
                        filtered,
                        missing,
                        input_data,
                        method_name,
                        service_name,
                    )

            # 5. Call the bound method
            with node_timer() as t:
                if inspect.iscoroutinefunction(step_fn):
                    result = await step_fn(**filtered)
                else:
                    result = step_fn(**filtered)

                logger.debug(
                    "Service step {}.{} completed in {}ms",
                    service_name,
                    method_name,
                    t.duration_str,
                )

                return result

        return self.create_node_with_mapping(
            name=name,
            wrapped_fn=execute_service_call,
            input_schema=None,
            output_schema=None,
            deps=deps,
            **kwargs,
        )
