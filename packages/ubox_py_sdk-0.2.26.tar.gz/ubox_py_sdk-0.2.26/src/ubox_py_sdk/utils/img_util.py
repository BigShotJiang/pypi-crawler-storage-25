import base64
import io
import os.path
from typing import Optional

import numpy as np
import cv2 as cv
from PIL import Image, UnidentifiedImageError


def load_image(data):
    try:
        if isinstance(data, str) and os.path.exists(data):
            im = Image.open(data)
        elif isinstance(data, bytes):
            buffer = io.BytesIO(base64.b64decode(data))
            im = Image.open(buffer)
        elif isinstance(data, io.BytesIO):
            im = Image.open(data)
        elif isinstance(data, Image.Image):
            im = data
        elif isinstance(data, np.ndarray):
            im = Image.fromarray(data)
        else:
            im = None
        return im
    except UnidentifiedImageError:
        return None


def crop_img(img, crop_box):
    """
    裁剪屏蔽
    @param img : 原始尺寸的图片数据 (NumPy array)
    @param crop_box: 屏蔽范围或者保留范围 均为百分比
                     保留范围: 保留矩形范围的<左上角顶点>坐标和<右下角>坐标, 示例 [[0.3, 0.3], [0.7, 0.7]]
                     屏蔽范围: [0, 1, 0, 0.3] 屏蔽x轴 0-1, y轴0-0.3的部分
    """
    if img is None or not isinstance(img, np.ndarray):
        raise ValueError("Invalid image data")

    height, width = img.shape[:2]

    try:
        if len(crop_box) == 2 and all(len(box) == 2 for box in crop_box):
            # 保留范围模式
            left_top = (int(crop_box[0][0] * width), int(crop_box[0][1] * height))
            right_bottom = (int(crop_box[1][0] * width), int(crop_box[1][1] * height))

            mask = np.zeros_like(img)
            mask[left_top[1]:right_bottom[1], left_top[0]:right_bottom[0]] = img[left_top[1]:right_bottom[1],
                                                                             left_top[0]:right_bottom[0]]
            img[:, :] = mask

        elif len(crop_box) == 4:
            # 屏蔽范围模式
            x_start, x_end, y_start, y_end = map(int, [
                crop_box[0] * width,
                crop_box[1] * width,
                crop_box[2] * height,
                crop_box[3] * height
            ])

            img[y_start:y_end, x_start:x_end] = 0

        else:
            raise ValueError("Invalid crop_box format")

    except Exception as e:
        raise RuntimeError(f"Failed to process image: {e}")
    return img


def base64_to_bgr_ndarray(b64_str: str) -> Optional[np.ndarray]:
    """将 base64 图片字符串（可带 data:image/... 前缀）解码为 OpenCV 使用的 BGR ndarray。"""
    if not b64_str:
        return None
    try:
        if b64_str.startswith("data:image"):
            _, b64_str = b64_str.split(",", 1)
        raw = base64.b64decode(b64_str)
        arr = np.frombuffer(raw, dtype=np.uint8)
        img = cv.imdecode(arr, cv.IMREAD_COLOR)
        return img
    except Exception:
        return None
