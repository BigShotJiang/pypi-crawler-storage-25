"""
设备操作接口定义。

本模块通过 Protocol 定义了 phone-agent 运行期所依赖的设备能力抽象，
便于在不直接依赖具体 Device 实现的前提下完成类型检查。
"""
from typing import Protocol, Optional, Union, TYPE_CHECKING

if TYPE_CHECKING:
    # 仅用于类型检查，避免循环依赖
    from ..models import OSType, PinchDirection

from ..models import DeviceButton


class IDeviceOperations(Protocol):
    """
    设备操作接口协议。
    
    Agent 需要的设备操作方法接口定义。
    Device 类需要实现此协议的所有方法，保证在执行模型下发动作时能力完备。
    """
    
    def screenshot_base64(
        self,
        crop: Optional[tuple] = None,
        trace_id: Optional[str] = None
    ) -> str:
        """
        对设备当前画面进行截图，返回 base64 编码的图片数据。
        
        Args:
            crop: 裁剪参数（可选），可以是 Tuple[Union[int, float], ...] 格式
            trace_id: 追踪 ID（可选）
        
        Returns:
            str: 图片 base64 编码字符串
        """
        ...
    
    def current_app(self, trace_id: Optional[str] = None) -> str:
        """
        获取当前前台应用标识。
        
        Args:
            trace_id: 追踪 ID（可选）
        
        Returns:
            str: 当前应用的包名或 bundle ID
        """
        ...
    
    def start_app(self, pkg: str, clear_data: bool = False, trace_id: Optional[str] = None, **kwargs) -> bool:
        """
        启动指定应用。
        
        Args:
            pkg: 应用包名或 bundle ID
            clear_data: 是否清除应用数据（可选，仅部分平台支持）
            trace_id: 追踪 ID（可选）
            **kwargs: 其他扩展参数
        
        Returns:
            bool: 启动是否成功
        """
        ...
    
    def click_pos(self, pos: Union[list, tuple], duration: float = 0.05, times: int = 1, trace_id: Optional[str] = None) -> bool:
        """
        基于屏幕坐标执行点击操作。
        
        Args:
            pos: 坐标 [x, y]，支持绝对像素或 0-1 相对坐标
            duration: 点击按压持续时间（秒）
            times: 点击次数（大于 1 可实现双击）
            trace_id: 追踪 ID（可选）
        
        Returns:
            bool: 点击是否成功
        """
        ...
    
    def input_text(self, text: str, timeout: int = 30, depth: int = 10, trace_id: Optional[str] = None) -> bool:
        """
        向设备当前聚焦的输入框注入文本。
        
        Args:
            text: 待输入的文本
            timeout: 查找输入目标的超时时间
            depth: source tree 的最大深度值
            trace_id: 追踪 ID（可选）
        
        Returns:
            bool: 输入是否成功
        """
        ...
    
    def slide_pos(
        self,
        pos_from: Union[list, tuple],
        pos_to: Optional[Union[list, tuple]] = None,
        down_duration: float = 0,
        slide_duration: float = 0.3,
        trace_id: Optional[str] = None
    ) -> bool:
        """
        基于坐标执行滑动/拖拽操作。
        
        Args:
            pos_from: 滑动起始坐标 [x, y]
            pos_to: 滑动结束坐标 [x, y]
            down_duration: 起始位置按下时长（秒），大于 0 可实现拖拽效果
            slide_duration: 滑动时间（秒）
            trace_id: 追踪 ID（可选）
        
        Returns:
            bool: 滑动是否成功
        """
        ...
    
    def press(self, name: DeviceButton, trace_id: Optional[str] = None) -> bool:
        """
        执行设备物理/系统按键操作。
        
        Args:
            name: 设备按键类型
            trace_id: 追踪 ID（可选）
        
        Returns:
            bool: 操作是否成功
        """
        ...

    def pinch(
        self,
        rect: Union[list, tuple],
        scale: float,
        direction: Union[str, "PinchDirection"],
        trace_id: Optional[str] = None,
    ) -> bool:
        """
        执行双指缩放操作。
        
        Agent 通过该接口将模型下发的 Pinch 动作映射到具体设备实现。
        
        Args:
            rect: 使用相对坐标系表示的缩放区域 [x, y, w, h]，
                  取值范围为 [0, 1.0)，分别为左上角坐标和区域宽高
            scale: 缩放倍数，小于 1 为缩小，大于 1 为放大
            direction: 缩放方向字符串或 PinchDirection 枚举值
            trace_id: 追踪 ID（可选）
        
        Returns:
            bool: 缩放是否成功
        """
        ...
    
    @property
    def os_type(self) -> "OSType":
        """
        获取设备操作系统类型。
        
        Returns:
            OSType: 设备操作系统类型（ANDROID、IOS 或 HM）
        """
        ...