"""Phone Agent的动作处理模块。

本模块提供：
- ActionHandler: 动作执行处理器
- ActionResult: 动作执行结果
- 强类型动作定义和构建器

类型体系:
    - ActionType: 动作类型枚举
    - ParamType: 参数类型枚举
    - ActionDefinition: 动作定义的强类型结构
    - ActionParam: 动作参数定义
    - HandlerAction: handler 接收的动作格式
    - Coordinate: 坐标类型

使用示例:
    ```python
    from ubox_py_sdk.phone_agent.actions import (
        ActionType,
        ActionBuilder,
        action_builder,
        get_action_definition,
    )
    
    # 使用构建器创建动作（类型安全）
    tap = action_builder.tap(500, 300)
    swipe = action_builder.swipe((500, 800), (500, 200))
    finish = action_builder.finish("任务完成")
    
    # 获取动作定义
    tap_def = get_action_definition(ActionType.TAP)
    print(f"描述: {tap_def.description}")
    print(f"必需参数: {tap_def.required_params}")
    ```

新增模型适配器时，可以参考 definitions.py 中的动作定义来映射模型输出。
"""

from .handler import ActionHandler, ActionResult, do, finish
from .definitions import (
    # 基础类型
    Coordinate,
    MetadataType,
    HandlerAction,
    # 枚举类型
    ActionType,
    ParamType,
    # 定义类
    ActionParam,
    ActionDefinition,
    # 定义注册表
    ACTION_DEFINITIONS,
    SUPPORTED_ACTION_NAMES,
    COMMON_ACTION_MAPPING,
    # 查询函数
    get_action_type,
    get_action_definition,
    get_action_definition_by_name,
    is_action_supported,
    map_action_name,
    # 动作构建器
    ActionBuilder,
    action_builder,
)

__all__ = [
    # 处理器
    "ActionHandler",
    "ActionResult",
    "do",
    "finish",
    # 基础类型
    "Coordinate",
    "MetadataType",
    "HandlerAction",
    # 枚举类型
    "ActionType",
    "ParamType",
    # 定义类
    "ActionParam",
    "ActionDefinition",
    # 定义注册表
    "ACTION_DEFINITIONS",
    "SUPPORTED_ACTION_NAMES",
    "COMMON_ACTION_MAPPING",
    # 查询函数
    "get_action_type",
    "get_action_definition",
    "get_action_definition_by_name",
    "is_action_supported",
    "map_action_name",
    # 动作构建器
    "ActionBuilder",
    "action_builder",
]
