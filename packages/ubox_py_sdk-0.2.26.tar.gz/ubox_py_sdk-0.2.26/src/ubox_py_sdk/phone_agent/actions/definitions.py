"""ActionHandler 支持的动作定义。

本模块定义了 ActionHandler 支持的所有动作类型及其参数规范。
新增模型适配器时，应参考此定义来映射模型输出到对应的 handler 动作。

类型体系:
    - Coordinate: 坐标类型 [x, y]，范围 0-1000
    - ActionType: 动作类型枚举
    - ParamType: 参数类型枚举
    - ActionDefinition: 动作定义的强类型结构
    - HandlerAction: handler 接收的动作格式
使用示例:
        ```python
        builder = ActionBuilder()

        # 创建点击动作（点击屏幕 50%, 30% 的位置）
        tap = builder.tap(500, 300)
        # {"_metadata": "do", "action": "Tap", "element": [500, 300]}

        # 创建滑动动作（从 50%, 80% 滑动到 50%, 20%）
        swipe = builder.swipe((500, 800), (500, 200))
        # {"_metadata": "do", "action": "Swipe", "start": [500, 800], "end": [500, 200]}

        # 创建结束动作
        finish = builder.finish("任务完成")
        # {"_metadata": "finish", "message": "任务完成"}
        ```
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Literal, Optional, Tuple, Union

# ============================================
# 基础类型定义
# ============================================

# 坐标类型: (x, y)，使用千分比表示
# 范围 0-1000，例如 (888, 500) 表示 x=88.8%、y=50.0% 的屏幕位置
Coordinate = Tuple[int, int]

# 元数据类型
MetadataType = Literal["do", "finish"]


class ActionType(Enum):
    """ActionHandler 支持的动作类型枚举。
    
    新增模型适配器时，应将模型输出的动作映射到这些类型。
    
    动作分类:
        - 点击类: TAP, DOUBLE_TAP, LONG_PRESS
        - 滑动类: SWIPE
        - 输入类: TYPE, TYPE_NAME
        - 系统按键类: BACK, HOME
        - 应用管理类: LAUNCH
        - 其他: WAIT, NOTE, CALL_API, TAKE_OVER, INTERACT
    """

    # 点击类动作
    TAP = "Tap"
    """点击操作。参数: element: Coordinate"""

    DOUBLE_TAP = "Double Tap"
    """双击操作。参数: element: Coordinate"""

    LONG_PRESS = "Long Press"
    """长按操作。参数: element: Coordinate"""

    # 滑动类 / 缩放类动作
    SWIPE = "Swipe"
    """滑动操作。参数: start: Coordinate, end: Coordinate"""

    # 拖动类动作
    DRAG = "Drap"
    """拖动操作。参数: start: Coordinate, end: Coordinate"""

    PINCH = "Pinch"
    """双指缩放操作。参数: center: Coordinate（中心点）, scale: float, direction: str；代码内由中心点自动生成安全矩形"""

    # 输入类动作
    TYPE = "Type"
    """文本输入。参数: text: str"""

    TYPE_NAME = "Type_Name"
    """人名输入（特殊处理）。参数: text: str"""

    # 系统按键类动作
    BACK = "Back"
    """返回键。无参数"""

    HOME = "Home"
    """主页键。无参数"""

    # 应用管理类动作
    LAUNCH = "Launch"
    """启动应用。参数: app: str (包名或应用名)"""

    # 其他动作
    WAIT = "Wait"
    """等待操作。参数: duration: str (如 "1 seconds")"""

    NOTE = "Note"
    """记录笔记（占位）。无参数"""

    CALL_API = "Call_API"
    """调用API（占位）。参数: instruction: str"""

    TAKE_OVER = "Take_over"
    """请求用户接管。参数: message: str"""

    INTERACT = "Interact"
    """交互请求。无参数"""


class ParamType(Enum):
    """动作参数的类型枚举。"""

    COORDINATE = "coordinate"
    """坐标类型: (x, y)，千分比表示，范围 0-1000，如 888 表示 88.8%"""

    TEXT = "text"
    """文本类型: 字符串"""

    DURATION = "duration"
    """时长类型: 如 "1 seconds" """

    APP = "app"
    """应用标识: 包名或应用名"""


# ============================================
# 强类型动作定义
# ============================================

@dataclass(frozen=True)
class ActionParam:
    """动作参数定义（不可变）。"""

    name: str
    """参数名称"""

    param_type: ParamType
    """参数类型"""

    required: bool = True
    """是否必需"""

    description: str = ""
    """参数描述"""


@dataclass(frozen=True)
class ActionDefinition:
    """动作定义（不可变）。
    
    定义了一个动作的完整规范，包括名称、描述、参数和示例。
    """

    action_type: ActionType
    """动作类型"""

    description: str
    """动作描述"""

    params: Tuple[ActionParam, ...] = field(default_factory=tuple)
    """参数列表（不可变元组）"""

    @property
    def name(self) -> str:
        """获取动作名称。"""
        return self.action_type.value

    @property
    def required_params(self) -> List[ActionParam]:
        """获取必需参数列表。"""
        return [p for p in self.params if p.required]

    @property
    def optional_params(self) -> List[ActionParam]:
        """获取可选参数列表。"""
        return [p for p in self.params if not p.required]

    def get_param(self, name: str) -> Optional[ActionParam]:
        """根据名称获取参数定义。"""
        for p in self.params:
            if p.name == name:
                return p
        return None


# ============================================
# Handler 动作格式类型定义
# ============================================

# 执行动作的基础字段
class _DoActionBase:
    """执行动作的基础结构（仅用于类型提示说明）。"""
    _metadata: Literal["do"]
    action: str  # ActionType.value


# 结束动作的基础字段
class _FinishActionBase:
    """结束动作的基础结构（仅用于类型提示说明）。"""
    _metadata: Literal["finish"]
    message: str


# 由于 Python 的 TypedDict 对于动态字段支持有限，
# 这里使用 Union 类型来表示所有可能的动作格式
HandlerAction = Dict[str, Union[str, int, float, List[int], Coordinate, None]]
"""Handler 接收的动作字典类型。

执行动作格式:
    {
        "_metadata": "do",
        "action": str,  # ActionType.value
        # 根据动作类型，可能包含以下字段:
        "element": [x, y],      # 点击类动作的坐标
        "start": [x, y],        # 滑动的起始坐标
        "end": [x, y],          # 滑动的结束坐标
        "text": str,            # 输入的文本
        "app": str,             # 启动的应用
        "duration": str,        # 等待时长
        "message": str,         # 敏感操作确认消息
        "instruction": str,     # API 指令
        "center": [cx, cy],     # 双指缩放的中心点（千分比），代码内自动生成安全矩形
        "scale": float,         # 双指缩放的缩放倍数
        "direction": str,       # 双指缩放的方向
        "size": int/float,      # 可选，缩放区域边长（千分比），不传则默认 400
    }

结束动作格式:
    {
        "_metadata": "finish",
        "message": str,  # 结束消息
    }
"""

# ============================================
# 动作定义注册表
# ============================================

# 使用强类型定义所有支持的动作
ACTION_DEFINITIONS: Dict[ActionType, ActionDefinition] = {
    # ========== 点击类动作 ==========
    ActionType.TAP: ActionDefinition(
        action_type=ActionType.TAP,
        description="点击屏幕指定位置",
        params=(
            ActionParam(
                name="element",
                param_type=ParamType.COORDINATE,
                required=True,
                description="点击坐标 (x, y)，千分比表示，如 (888, 500) 表示 88.8%, 50%"
            ),
            ActionParam(
                name="message",
                param_type=ParamType.TEXT,
                required=False,
                description="敏感操作确认消息"
            ),
        ),
    ),

    ActionType.DOUBLE_TAP: ActionDefinition(
        action_type=ActionType.DOUBLE_TAP,
        description="双击屏幕指定位置",
        params=(
            ActionParam(
                name="element",
                param_type=ParamType.COORDINATE,
                required=True,
                description="双击坐标 (x, y)，千分比表示，如 (888, 500) 表示 88.8%, 50%"
            ),
        ),
    ),

    ActionType.LONG_PRESS: ActionDefinition(
        action_type=ActionType.LONG_PRESS,
        description="长按屏幕指定位置",
        params=(
            ActionParam(
                name="element",
                param_type=ParamType.COORDINATE,
                required=True,
                description="长按坐标 (x, y)，千分比表示，如 (888, 500) 表示 88.8%, 50%"
            ),
        ),
    ),

    # ========== 滑动类 / 缩放类动作 ==========
    ActionType.SWIPE: ActionDefinition(
        action_type=ActionType.SWIPE,
        description="从起始点滑动到结束点",
        params=(
            ActionParam(
                name="start",
                param_type=ParamType.COORDINATE,
                required=True,
                description="滑动起始坐标 (x, y)，千分比表示"
            ),
            ActionParam(
                name="end",
                param_type=ParamType.COORDINATE,
                required=True,
                description="滑动结束坐标 (x, y)，千分比表示"
            ),
        ),
    ),

    # ========== 拖动类动作 ==========
    ActionType.DRAG: ActionDefinition(
        action_type=ActionType.DRAG,
        description="从起始点拖动到结束点",
        params=(
            ActionParam(
                name="start",
                param_type=ParamType.COORDINATE,
                required=True,
                description="拖动起始坐标 (x, y)，千分比表示"
            ),
            ActionParam(
                name="end",
                param_type=ParamType.COORDINATE,
                required=True,
                description="拖动结束坐标 (x, y)，千分比表示"
            ),
        ),
    ),

    ActionType.PINCH: ActionDefinition(
        action_type=ActionType.PINCH,
        description="在指定中心点周围执行双指缩放（代码内自动生成安全矩形）",
        params=(
            ActionParam(
                name="center",
                param_type=ParamType.COORDINATE,
                required=True,
                description="缩放中心点坐标 (cx, cy)，千分比表示 0-1000"
            ),
            ActionParam(
                name="scale",
                param_type=ParamType.TEXT,
                required=True,
                description="缩放倍数，小于1为缩小，大于1为放大"
            ),
            ActionParam(
                name="direction",
                param_type=ParamType.TEXT,
                required=False,
                description="缩放方向，horizontal/vertical/diagonal"
            ),
            ActionParam(
                name="size",
                param_type=ParamType.TEXT,
                required=False,
                description="可选。缩放区域正方形的边长（千分比 0-1000），不传则默认 400（约 40% 屏）。建议范围 200~600，代码会做安全裁剪"
            ),
        ),
    ),

    # ========== 输入类动作 ==========
    ActionType.TYPE: ActionDefinition(
        action_type=ActionType.TYPE,
        description="在当前聚焦的输入框中输入文本",
        params=(
            ActionParam(
                name="text",
                param_type=ParamType.TEXT,
                required=True,
                description="要输入的文本内容"
            ),
        ),
    ),

    ActionType.TYPE_NAME: ActionDefinition(
        action_type=ActionType.TYPE_NAME,
        description="输入人名（特殊处理）",
        params=(
            ActionParam(
                name="text",
                param_type=ParamType.TEXT,
                required=True,
                description="要输入的人名"
            ),
        ),
    ),

    # ========== 系统按键类动作 ==========
    ActionType.BACK: ActionDefinition(
        action_type=ActionType.BACK,
        description="按下返回键",
        params=(),
    ),

    ActionType.HOME: ActionDefinition(
        action_type=ActionType.HOME,
        description="按下主页键，返回桌面",
        params=(),
    ),

    # ========== 应用管理类动作 ==========
    ActionType.LAUNCH: ActionDefinition(
        action_type=ActionType.LAUNCH,
        description="启动指定应用",
        params=(
            ActionParam(
                name="app",
                param_type=ParamType.APP,
                required=True,
                description="应用包名或应用名称"
            ),
        ),
    ),

    # ========== 其他动作 ==========
    ActionType.WAIT: ActionDefinition(
        action_type=ActionType.WAIT,
        description="等待指定时间",
        params=(
            ActionParam(
                name="duration",
                param_type=ParamType.DURATION,
                required=False,
                description="等待时长，格式: '1 seconds'"
            ),
        ),
    ),

    ActionType.NOTE: ActionDefinition(
        action_type=ActionType.NOTE,
        description="记录当前页面内容（占位）",
        params=(),
    ),

    ActionType.CALL_API: ActionDefinition(
        action_type=ActionType.CALL_API,
        description="调用API进行总结或评论（占位）",
        params=(
            ActionParam(
                name="instruction",
                param_type=ParamType.TEXT,
                required=False,
                description="API调用指令"
            ),
        ),
    ),

    ActionType.TAKE_OVER: ActionDefinition(
        action_type=ActionType.TAKE_OVER,
        description="请求用户接管（登录、验证码等场景）",
        params=(
            ActionParam(
                name="message",
                param_type=ParamType.TEXT,
                required=False,
                description="提示用户的消息"
            ),
        ),
    ),

    ActionType.INTERACT: ActionDefinition(
        action_type=ActionType.INTERACT,
        description="交互请求，询问用户选择",
        params=(),
    ),
}

# ============================================
# 便捷查询接口
# ============================================

# 动作名称到动作类型的映射（用于字符串查找）
_ACTION_NAME_TO_TYPE: Dict[str, ActionType] = {
    action_type.value: action_type for action_type in ActionType
}

# 支持的动作名称列表
SUPPORTED_ACTION_NAMES: List[str] = [action_type.value for action_type in ActionType]


def get_action_type(action_name: str) -> Optional[ActionType]:
    """根据动作名称获取动作类型枚举。
    
    Args:
        action_name: 动作名称（如 "Tap", "Swipe"）
        
    Returns:
        ActionType 枚举，如果不存在返回 None
    """
    return _ACTION_NAME_TO_TYPE.get(action_name)


def get_action_definition(action_type: ActionType) -> ActionDefinition:
    """获取动作的完整定义。
    
    Args:
        action_type: 动作类型枚举
        
    Returns:
        ActionDefinition 对象
        
    Raises:
        KeyError: 如果动作类型未定义
    """
    return ACTION_DEFINITIONS[action_type]


def get_action_definition_by_name(action_name: str) -> Optional[ActionDefinition]:
    """根据动作名称获取动作定义。
    
    Args:
        action_name: 动作名称
        
    Returns:
        ActionDefinition 对象，如果不存在返回 None
    """
    action_type = get_action_type(action_name)
    if action_type is None:
        return None
    return ACTION_DEFINITIONS.get(action_type)


def is_action_supported(action_name: str) -> bool:
    """检查动作是否被支持。
    
    Args:
        action_name: 动作名称
        
    Returns:
        是否支持
    """
    return action_name in _ACTION_NAME_TO_TYPE


# ============================================
# 动作构建器（类型安全）
# ============================================

class ActionBuilder:
    """动作构建器，提供类型安全的动作创建方法。
    
    坐标使用千分比表示，范围 0-1000，例如 888 表示 88.8% 的位置。
    
    使用示例:
        ```python
        builder = ActionBuilder()
        
        # 创建点击动作（点击屏幕 50%, 30% 的位置）
        tap = builder.tap(500, 300)
        # {"_metadata": "do", "action": "Tap", "element": [500, 300]}
        
        # 创建滑动动作（从 50%, 80% 滑动到 50%, 20%）
        swipe = builder.swipe((500, 800), (500, 200))
        # {"_metadata": "do", "action": "Swipe", "start": [500, 800], "end": [500, 200]}
        
        # 创建结束动作
        finish = builder.finish("任务完成")
        # {"_metadata": "finish", "message": "任务完成"}
        ```
    """

    @staticmethod
    def tap(x: int, y: int, message: Optional[str] = None) -> HandlerAction:
        """创建点击动作。
        
        Args:
            x: X 坐标，千分比表示 (0-1000)，如 888 表示 88.8%
            y: Y 坐标，千分比表示 (0-1000)，如 500 表示 50%
            message: 可选的确认消息
        """
        action: HandlerAction = {
            "_metadata": "do",
            "action": ActionType.TAP.value,
            "element": [x, y],
        }
        if message:
            action["message"] = message
        return action

    @staticmethod
    def double_tap(x: int, y: int) -> HandlerAction:
        """创建双击动作。
        
        Args:
            x: X 坐标，千分比表示 (0-1000)，如 888 表示 88.8%
            y: Y 坐标，千分比表示 (0-1000)，如 500 表示 50%
        """
        return {
            "_metadata": "do",
            "action": ActionType.DOUBLE_TAP.value,
            "element": [x, y],
        }

    @staticmethod
    def long_press(x: int, y: int) -> HandlerAction:
        """创建长按动作。
        
        Args:
            x: X 坐标，千分比表示 (0-1000)，如 888 表示 88.8%
            y: Y 坐标，千分比表示 (0-1000)，如 500 表示 50%
        """
        return {
            "_metadata": "do",
            "action": ActionType.LONG_PRESS.value,
            "element": [x, y],
        }

    @staticmethod
    def swipe(
            start: Union[Coordinate, Tuple[int, int]],
            end: Union[Coordinate, Tuple[int, int]],
    ) -> HandlerAction:
        """创建滑动动作。
        
        Args:
            start: 起始坐标 (x, y)，千分比表示 (0-1000)
            end: 结束坐标 (x, y)，千分比表示 (0-1000)
        """
        return {
            "_metadata": "do",
            "action": ActionType.SWIPE.value,
            "start": list(start),
            "end": list(end),
        }

    @staticmethod
    def drag(
            start: Union[Coordinate, Tuple[int, int]],
            end: Union[Coordinate, Tuple[int, int]],
    ) -> HandlerAction:
        """创建拖动动作。

        Args:
            start: 起始坐标 (x, y)，千分比表示 (0-1000)
            end: 结束坐标 (x, y)，千分比表示 (0-1000)
        """
        return {
            "_metadata": "do",
            "action": ActionType.DRAG.value,
            "start": list(start),
            "end": list(end),
        }

    @staticmethod
    def pinch(
            center: Union[Coordinate, Tuple[int, int], List[int]],
            scale: float,
    ) -> HandlerAction:
        """创建双指缩放动作。
        
        只需提供缩放中心点，执行时由 ActionHandler 在中心点周围自动生成安全矩形并调用设备 pinch。
        
        Args:
            center: 缩放中心点 [cx, cy]，千分比表示 (0-1000)
            scale: 缩放倍数，小于 1 为缩小，大于 1 为放大
        """
        return {
            "_metadata": "do",
            "action": ActionType.PINCH.value,
            "center": list(center),
            "scale": scale,
        }

    @staticmethod
    def type_text(text: str) -> HandlerAction:
        """创建文本输入动作。
        
        Args:
            text: 要输入的文本
        """
        return {
            "_metadata": "do",
            "action": ActionType.TYPE.value,
            "text": text,
        }

    @staticmethod
    def type_name(name: str) -> HandlerAction:
        """创建人名输入动作。
        
        Args:
            name: 要输入的人名
        """
        return {
            "_metadata": "do",
            "action": ActionType.TYPE_NAME.value,
            "text": name,
        }

    @staticmethod
    def back() -> HandlerAction:
        """创建返回键动作。"""
        return {
            "_metadata": "do",
            "action": ActionType.BACK.value,
        }

    @staticmethod
    def home() -> HandlerAction:
        """创建主页键动作。"""
        return {
            "_metadata": "do",
            "action": ActionType.HOME.value,
        }

    @staticmethod
    def launch(app: str) -> HandlerAction:
        """创建启动应用动作。
        
        Args:
            app: 应用包名或名称
        """
        return {
            "_metadata": "do",
            "action": ActionType.LAUNCH.value,
            "app": app,
        }

    @staticmethod
    def wait(duration: str = "1 seconds") -> HandlerAction:
        """创建等待动作。
        
        Args:
            duration: 等待时长，如 "1 seconds", "2 seconds"
        """
        return {
            "_metadata": "do",
            "action": ActionType.WAIT.value,
            "duration": duration,
        }

    @staticmethod
    def take_over(message: str) -> HandlerAction:
        """创建用户接管请求动作。
        
        Args:
            message: 提示用户的消息
        """
        return {
            "_metadata": "do",
            "action": ActionType.TAKE_OVER.value,
            "message": message,
        }

    @staticmethod
    def finish(message: str) -> HandlerAction:
        """创建结束动作。
        
        Args:
            message: 结束消息
        """
        return {
            "_metadata": "finish",
            "message": message,
        }


# 提供一个全局实例方便使用
action_builder = ActionBuilder()

# ============================================
# 模型动作映射辅助
# ============================================

# 常见的模型动作名称到 ActionHandler 动作类型的映射
# 新增模型适配器时可以参考或扩展此映射
COMMON_ACTION_MAPPING: Dict[str, ActionType] = {
    # 点击类
    "click": ActionType.TAP,
    "tap": ActionType.TAP,
    "press": ActionType.TAP,
    "double_click": ActionType.DOUBLE_TAP,
    "double_tap": ActionType.DOUBLE_TAP,
    "long_press": ActionType.LONG_PRESS,
    "long_click": ActionType.LONG_PRESS,

    # 滑动类
    "swipe": ActionType.SWIPE,
    "slide": ActionType.SWIPE,
    "drag": ActionType.DRAG,
    "scroll": ActionType.SWIPE,

    # 缩放类
    "pinch": ActionType.PINCH,
    "zoom": ActionType.PINCH,
    "zoom_in": ActionType.PINCH,
    "zoom_out": ActionType.PINCH,

    # 输入类
    "type": ActionType.TYPE,
    "input": ActionType.TYPE,
    "text": ActionType.TYPE,
    "enter_text": ActionType.TYPE,

    # 系统按键
    "back": ActionType.BACK,
    "go_back": ActionType.BACK,
    "home": ActionType.HOME,
    "go_home": ActionType.HOME,

    # 应用管理
    "launch": ActionType.LAUNCH,
    "open": ActionType.LAUNCH,
    "start_app": ActionType.LAUNCH,
    "open_app": ActionType.LAUNCH,

    # 等待
    "wait": ActionType.WAIT,
    "sleep": ActionType.WAIT,
    "pause": ActionType.WAIT,
}


def map_action_name(model_action: str) -> Optional[ActionType]:
    """将模型动作名称映射到 ActionHandler 动作类型。
    
    Args:
        model_action: 模型输出的动作名称
        
    Returns:
        对应的 ActionType，如果无法映射返回 None
    """
    # 先尝试直接匹配（区分大小写）
    action_type = get_action_type(model_action)
    if action_type is not None:
        return action_type

    # 尝试通过映射表匹配（不区分大小写）
    return COMMON_ACTION_MAPPING.get(model_action.lower())
