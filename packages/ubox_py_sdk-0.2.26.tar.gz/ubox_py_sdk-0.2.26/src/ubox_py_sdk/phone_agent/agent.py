"""ExplorationAgent主类，用于编排手机自动化探索测试操作。

本模块提供了探索测试 Agent 的核心实现，支持：
- 使用视觉语言模型理解屏幕内容
- 自动执行操作完成测试任务
- 实时流式返回执行状态
- 可插拔的模型适配器架构

使用示例:
    ```python
    from ubox_py_sdk.phone_agent import (
        ExplorationAgent, AgentConfig,
        ModelType, ModelConfig, AgentModelConfig
    )
    
    # 配置模型
    model_config = AgentModelConfig(
        model=ModelType.AUTOGLM_PHONE_9B,
        models={
            ModelType.AUTOGLM_PHONE_9B: ModelConfig(
                base_url="http://localhost:8000/v1"
            ),
        }
    )
    
    # 创建 Agent
    agent = ExplorationAgent(model_config=model_config, device=device)
    
    # 执行探索任务
    for update in agent.run_stream("打开微信并发送消息"):
        if update.update_type == "thinking":
            print(f"思考: {update.content}")
        elif update.update_type == "finished":
            print(f"完成: {update.content}")
    ```
"""

import base64
import json
from dataclasses import dataclass
from io import BytesIO
from typing import Any, Callable, Generator, Literal, Optional, TYPE_CHECKING

from PIL import Image

from ubox_py_sdk.logger import get_logger

from .actions import ActionHandler
from .actions.definitions import HandlerAction
from .models import (
    AgentModelConfig,
    ModelConfig,
    BaseModelAdapter,
    MessageDict,
    ModelType,
    create_adapter,
)
from .device_interface import IDeviceOperations

if TYPE_CHECKING:
    from ubox_py_sdk.device import Device

logger = get_logger("ubox_py_sdk.phone_agent")

# 流方式输出的消息类型
UpdateType = Literal["thinking", "model_complete", "action", "result", "finished"]


@dataclass
class AgentConfig:
    """ExplorationAgent的配置类。
    
    Attributes:
        max_steps: 最大执行步数，超过后停止执行
        verbose: 是否输出详细日志
        keep_recent_images: 保留最近几步的截图，用于让模型记住近期界面信息
        max_context_tokens: 模型最大上下文 token 数
        context_warning_threshold: 上下文警告阈值（0-1），达到此比例时触发清理
    """

    max_steps: int = 100
    """最大执行步数。Agent在执行任务时最多执行多少步，超过此步数将停止执行。"""
    
    verbose: bool = True
    """是否输出详细日志。"""
    
    keep_recent_images: int = 1
    """保留最近几步的截图数量。
    
    为了节省 token，每步执行后会清理历史消息中的图片。
    此参数控制保留最近几步的截图，让模型能记住近期的界面信息。
    
    - 默认值 1：只保留当前步的截图（每步执行后清理上一步的图片）
    - 设置为 3：保留最近 3 步的截图，模型可以参考之前的界面状态
    
    注意：最小值为 1，确保模型至少能看到当前界面。
    """
    
    max_context_tokens: int = 128000
    """模型最大上下文 token 数。
    
    用于判断何时需要裁剪上下文，防止超出模型限制。
    
    注意：此值应略小于模型实际限制，为输出预留空间。
    """
    
    context_warning_threshold: float = 0.8
    """上下文警告阈值（0-1）。
    
    当实际 token 使用量达到 max_context_tokens 的此比例时，
    触发上下文裁剪，移除最早的对话轮次。
    
    - 默认值 0.8：使用量达到 80% 时开始清理
    - 设置为 0.9：更激进，到 90% 才清理（风险略高）
    - 设置为 0.7：更保守，70% 就开始清理
    """


@dataclass
class StepUpdate:
    """Agent步骤的实时更新信息。
    
    用于在流式执行过程中返回每个步骤的状态更新。
    
    Attributes:
        step: 步骤编号
        update_type: 更新类型
        content: 更新内容
    """

    step: int
    """步骤编号。"""

    update_type: UpdateType
    """更新类型：'thinking'（思考过程）、'action'（动作）、'result'（执行结果）、'finished'（完成）。"""

    content: Any
    """更新内容。根据update_type不同而不同：
    - thinking: str - 思考过程的文本片段
    - model_complete: dict - 模型处理完成信息，包含 {
        "tokens": dict - Token统计，包含 {
          "prompt_tokens": int - 输入token数,
          "completion_tokens": int - 输出token数,
          "total_tokens": int - 总token数
        },
        "timing": dict - 推理时长统计，包含 {
          "time_to_first_token": float - 首Token延迟（秒）,
          "time_to_thinking_end": float - 思考完成延迟（秒）,
          "total_time": float - 总推理时间（秒）
        }
      }
    - action: dict - 动作信息，包含 {
        "action": HandlerAction - 要执行的动作字典,
        "description": str - 操作描述（简要说明本次操作）,
        "screenshot_before": str - 操作前的截图（base64，已标注操作位置）
      }
    - result: dict - 执行结果，包含 {
        "success": bool - 执行是否成功,
        "message": str - 执行结果消息,
        "screenshot_after": str - 操作后的截图（base64）
      }
    - finished: dict - 完成信息，包含 {"success": bool, "message": str}
    """


@dataclass
class Screenshot:
    """表示一个截图的类。
    
    Attributes:
        base64_data: base64 编码的图片数据
        width: 图片宽度
        height: 图片高度
        is_sensitive: 是否为敏感内容
        mime_type: 图片的 MIME 类型（image/jpeg 或 image/png）
    """

    base64_data: str
    width: int
    height: int
    is_sensitive: bool = False
    mime_type: str = "image/png"


class ExplorationAgent:
    """
    使用视觉语言模型来理解屏幕内容，并决定执行哪些操作来完成探索测试任务。
    直接使用SDK的Device对象进行操作，支持Android、iOS和HM三端。
    
    初始化方式：
        ```python
        from ubox_py_sdk.phone_agent import (
            ModelType, ModelConfig, AgentModelConfig
        )
        
        # 配置模型
        model_config = AgentModelConfig(
            model=ModelType.AUTOGLM_PHONE_9B,
            models={
                ModelType.AUTOGLM_PHONE_9B: ModelConfig(
                    base_url="http://localhost:8000/v1"
                ),
                ModelType.AUTOGLM_PHONE_14B: ModelConfig(
                    base_url="https://api.example.com/v1",
                    api_key="your-key"
                ),
            }
        )
        
        # 创建 Agent
        agent = ExplorationAgent(model_config=model_config, device=device)
        ```

    Args:
        model_config: 模型配置（AgentModelConfig 实例）
        agent_config: Agent行为的配置
        confirmation_callback: 敏感操作确认的回调函数（可选）
        takeover_callback: 接管请求的回调函数（可选）
        device: SDK的Device实例（必需）

    Note:
        使用时不需要直接创建ExplorationAgent实例，直接通过device.explore()方法使用。
    """

    def __init__(
            self,
            model_config: AgentModelConfig,
            agent_config: Optional[AgentConfig] = None,
            confirmation_callback: Optional[Callable[[str], bool]] = None,
            takeover_callback: Optional[Callable[[str], None]] = None,
            device: Optional[IDeviceOperations] = None,
    ):
        """
        初始化ExplorationAgent。

        Args:
            model_config: 模型配置（AgentModelConfig 实例）
            agent_config: Agent行为配置
            confirmation_callback: 敏感操作确认回调
            takeover_callback: 接管请求回调
            device: 实现IDeviceOperations接口的设备对象（必需）
            
        Raises:
            ValueError: 如果 device 为 None 或 model_config 类型不正确
            ValueError: 如果指定的模型没有对应的配置
        """
        self._current_system_prompt = None
        self.agent_config = agent_config or AgentConfig()

        # 必须提供 device 对象
        if device is None:
            raise ValueError("device 参数是必需的，请传入实现 IDeviceOperations 接口的设备对象")

        self.device = device
        
        # 验证并创建适配器
        if not isinstance(model_config, AgentModelConfig):
            raise TypeError(
                f"model_config 必须是 AgentModelConfig 类型，"
                f"当前类型: {type(model_config).__name__}"
            )
        
        self.model_config = model_config
        self.adapter = create_adapter(model_config)
        self._current_model = model_config.model
        logger.info(f"使用模型: {model_config.model.value} (适配器: {self.adapter.name})")
        
        self.action_handler = ActionHandler(
            device=device,
            confirmation_callback=confirmation_callback,
            takeover_callback=takeover_callback,
            original_user_prompt_getter=lambda: self._original_user_prompt,
        )

        self._context: list[MessageDict] = []
        self._step_count: int = 0
        self._original_user_prompt: Optional[str] = None
        self._stop_flag: bool = False
        self._is_running: bool = False
        self._last_prompt_tokens: Optional[int] = None  # 记录最近一次请求的 prompt tokens

    def __call__(self, task: str, rules: Optional[str] = None, model: Optional[ModelType] = None) -> str:
        """
        使 ExplorationAgent 对象可以直接被调用，内部调用 run() 方法。

        Args:
            task: 任务的自然语言描述。
            rules: 自定义规则内容，会拼接到系统提示词末尾。
            model: 指定使用的模型类型，如果为 None 则使用当前模型。

        Returns:
            Agent的最终消息。
        """
        return self.run(task, rules=rules, model=model)

    def run(self, task: str, rules: Optional[str] = None, model: Optional[ModelType] = None) -> str:
        """
        运行agent完成任务（简单接口，不返回实时更新）。

        如果需要实时监控思考和动作，请使用 run_stream() 方法。

        Args:
            task: 任务的自然语言描述。
            rules: 自定义规则内容，会拼接到系统提示词末尾。
            model: 指定使用的模型类型，如果为 None 则使用当前模型。

        Returns:
            Agent的最终消息。
        """
        final_message = None
        for update in self.run_stream(task, rules=rules, model=model):
            if update.update_type == "finished":
                final_message = update.content.get("message") if isinstance(update.content, dict) else update.content
                break
        return final_message or "任务完成"

    def stop(self) -> None:
        """主动停止agent的执行。"""
        self._stop_flag = True
        logger.info("Agent收到停止信号，将在下一个检查点停止执行")

    @property
    def is_running(self) -> bool:
        """检查agent是否正在执行。"""
        return self._is_running
    
    @property
    def current_model(self) -> ModelType:
        """获取当前使用的模型类型。"""
        return self._current_model
    
    def switch_model(self, model: ModelType) -> None:
        """切换使用的模型。
        
        切换会创建新的适配器实例。
        如果配置了多模型（models 字典），会使用对应模型的配置；
        否则会复用当前模型的服务配置。
        
        如果当前有任务正在执行，切换会在下次执行时生效。
        
        Args:
            model: 要切换到的模型类型
            
        Raises:
            ValueError: 如果指定的模型未配置且与当前模型不同
        """
        if model == self._current_model:
            logger.debug(f"模型已经是 {model.value}，无需切换")
            return
        
        # 使用配置的 with_model 方法创建新配置
        new_config = self.model_config.with_model(model)
        self.adapter = create_adapter(new_config)
        self.model_config = new_config
        self._current_model = model
        
        logger.info(f"已切换至模型: {model.value} (适配器: {self.adapter.name})")
    
    def _build_system_prompt(
        self, 
        rules: Optional[str] = None, 
        system_prompt: Optional[str] = None
    ) -> str:
        """构建最终的系统提示词。
        
        Args:
            rules: 自定义规则内容，会拼接到系统提示词末尾
            system_prompt: 自定义系统提示词，完全覆盖默认提示词
            
        Returns:
            最终的系统提示词
            
        Warning:
            自定义 system_prompt 会完全覆盖适配器默认的系统提示词。
            默认提示词是模型实现的核心部分，包含了操作格式定义、输出解析规则等关键内容。
            错误的系统提示词可能导致：
            - 模型输出格式无法解析
            - 操作执行失败
            - Agent 功能异常
            
            建议：优先使用 rules 参数补充规则，而非完全替换系统提示词。
        """
        # 如果指定了自定义系统提示词，完全使用自定义的
        if system_prompt is not None:
            logger.warning(
                "使用自定义系统提示词，已覆盖适配器默认提示词。"
                "这可能影响 Agent 的正常功能，请确保提示词格式正确。"
            )
            prompt = system_prompt
        else:
            # 获取适配器定义的系统提示词
            prompt = self.adapter.get_system_prompt()
        
        # 如果有规则，拼接到末尾
        if rules:
            prompt = f"{prompt}\n\n---\n【规则】\n{rules}"
        
        return prompt

    def run_stream(
        self, 
        task: str, 
        rules: Optional[str] = None,
        model: Optional[ModelType] = None,
        system_prompt: Optional[str] = None
    ) -> Generator[StepUpdate, None, None]:
        """
        运行agent完成任务，返回生成器以实时获取执行状态。

        类似 Go 的 channel，可以实时获取 AI 的思考和动作。
        可以通过调用 stop() 方法来主动中断执行。
        如果上一次执行还未完成，会自动停止上一次执行后再开始新的执行。

        Args:
            task: 任务的自然语言描述。
            rules: 自定义规则内容，会拼接到系统提示词末尾。
            model: 指定使用的模型类型，如果为 None 则使用当前模型。
                切换模型时会复用当前配置的服务端点。
                
            system_prompt: 自定义系统提示词，完全覆盖默认提示词。
                
                ⚠️ **警告**：自定义系统提示词是高级功能，使用不当可能导致 Agent 功能异常。
                
                默认系统提示词由模型适配器提供，包含：
                - 操作指令格式定义（如 Tap、Swipe、Type 等）
                - 输出格式规范（thinking/action 结构）
                - 坐标系统说明
                - 任务完成判断逻辑
                
                如果自定义提示词缺少这些关键内容，可能导致：
                - 模型输出无法正确解析
                - 操作执行失败或行为异常
                - Agent 无法正常完成任务
                
                **建议**：优先使用 rules 参数补充规则，仅在充分理解默认提示词的情况下使用此参数。

        Yields:
            StepUpdate: 每个步骤的实时更新信息。
        """
        # 如果上一次执行还在进行，先停止它
        if self._is_running:
            logger.warning("检测到上一次执行还未完成，正在停止上一次执行...")
            self._stop_flag = True
            import time
            time.sleep(0.1)

        # 检查是否需要切换模型
        if model is not None and model != self._current_model:
            self.switch_model(model)

        # 重置状态，开始新的执行
        self._context = []
        self._step_count = 0
        self._stop_flag = False
        self._is_running = True
        self._last_prompt_tokens = None
        
        # 构建本次执行使用的系统提示词
        self._current_system_prompt = self._build_system_prompt(rules, system_prompt)
        if system_prompt:
            logger.info("已应用自定义系统提示词")
        elif rules:
            logger.info("已应用自定义规则到系统提示词")

        try:
            for update in self._execute_step_stream(task, is_first=True):
                yield update
                if update.update_type == "finished":
                    return
                if self._stop_flag:
                    yield StepUpdate(
                        step=self._step_count,
                        update_type="finished",
                        content={"success": False, "message": "用户主动中断执行"},
                    )
                    return

            # 继续执行直到完成或达到最大步数
            while self._step_count < self.agent_config.max_steps and not self._stop_flag:
                for update in self._execute_step_stream(is_first=False):
                    yield update
                    if update.update_type == "finished":
                        return
                    if self._stop_flag:
                        yield StepUpdate(
                            step=self._step_count,
                            update_type="finished",
                            content={"success": False, "message": "用户主动中断执行"},
                        )
                        return

            # 达到最大步数或被中断
            if self._stop_flag:
                yield StepUpdate(
                    step=self._step_count,
                    update_type="finished",
                    content={"success": False, "message": "用户主动中断执行"},
                )
            else:
                yield StepUpdate(
                    step=self._step_count,
                    update_type="finished",
                    content={"success": False, "message": "达到最大步数"},
                )
        finally:
            self._is_running = False

    def step(self, task: Optional[str] = None) -> StepUpdate:
        """
        执行agent的单个步骤。

        用于手动控制或调试。返回包含完整步骤信息的StepUpdate。

        Args:
            task: 任务描述（仅在第一步时需要）。

        Returns:
            包含步骤详情的StepUpdate。
        """
        is_first = len(self._context) == 0

        if is_first and not task:
            raise ValueError("第一步需要提供任务描述")

        last_update = None
        for update in self._execute_step_stream(task, is_first):
            last_update = update
            if update.update_type == "finished":
                break

        if last_update is None:
            return StepUpdate(
                step=self._step_count,
                update_type="finished",
                content={"success": False, "message": "步骤执行失败"},
            )

        return last_update

    def reset(self) -> None:
        """重置agent状态以开始新任务。"""
        self._context = []
        self._step_count = 0
        self._stop_flag = False
        self._is_running = False
        self._last_prompt_tokens = None

    def _execute_step_stream(
            self, user_prompt: Optional[str] = None, is_first: bool = False
    ) -> Generator[StepUpdate, None, None]:
        """
        执行agent循环的单个步骤，返回生成器以实时输出状态。

        Args:
            user_prompt: 用户提示（仅在第一步时需要）。
            is_first: 是否为第一步。

        Yields:
            StepUpdate: 每个步骤的实时更新信息。
        """
        self._step_count += 1

        # 获取截图和应用信息
        logger.debug("查看当前屏幕...")
        screenshot = self._get_screenshot()
        current_app = self._get_current_app()

        # 构建消息（使用适配器）
        if is_first:
            self._original_user_prompt = user_prompt

            self._context.append(
                self.adapter.build_system_message(self._current_system_prompt)
            )

            screen_info = self.adapter.build_screen_info(current_app)
            text_content = f"{user_prompt}\n\n{screen_info}"

            self._context.append(
                self.adapter.build_user_message(
                    text=text_content, 
                    image_base64=screenshot.base64_data,
                    mime_type=screenshot.mime_type
                )
            )
        else:
            screen_info = self.adapter.build_screen_info(current_app)
            text_content = f"** Screen Info **\n\n{screen_info}"

            self._context.append(
                self.adapter.build_user_message(
                    text=text_content, 
                    image_base64=screenshot.base64_data,
                    mime_type=screenshot.mime_type
                )
            )

        # 检查是否被中断
        if self._stop_flag:
            yield StepUpdate(
                step=self._step_count,
                update_type="finished",
                content={"success": False, "message": "用户主动中断执行"},
            )
            return

        # 获取模型响应（使用适配器的流式请求）
        try:
            logger.debug("💭 开始思考...")
            thinking_chunks = []
            for chunk in self.adapter.request_stream(self._context):
                if self._stop_flag:
                    yield StepUpdate(
                        step=self._step_count,
                        update_type="finished",
                        content={"success": False, "message": "用户主动中断执行"},
                    )
                    return
                thinking_chunks.append(chunk)
                yield StepUpdate(
                    step=self._step_count,
                    update_type="thinking",
                    content=chunk,
                )
            if self._stop_flag:
                yield StepUpdate(
                    step=self._step_count,
                    update_type="finished",
                    content={"success": False, "message": "用户主动中断执行"},
                )
                return

            # 获取完整响应
            response = self.adapter.get_last_response()
            
            # 记录 prompt_tokens 用于上下文管理
            if response and response.prompt_tokens is not None:
                self._last_prompt_tokens = response.prompt_tokens
                # 检查是否需要裁剪上下文
                self._trim_context_if_needed(response.prompt_tokens)

        except Exception as e:
            if self.agent_config.verbose:
                logger.exception("模型请求失败")
            yield StepUpdate(
                step=self._step_count,
                update_type="finished",
                content={"success": False, "message": f"模型错误: {e}"},
            )
            return

        # 解析动作（使用适配器）
        try:
            action = self.adapter.parse_action(response.action)
        except ValueError:
            if self.agent_config.verbose:
                logger.exception("解析动作失败")
            action = self.adapter.create_finish_action(message=response.action)

        # 如果是完成动作，直接走完成逻辑
        if action.get("_metadata") == "finish":
            if response:
                tokens_info = None
                if hasattr(response, 'total_tokens') and response.total_tokens is not None:
                    tokens_info = {
                        "prompt_tokens": response.prompt_tokens,
                        "completion_tokens": response.completion_tokens,
                        "total_tokens": response.total_tokens,
                    }

                timing_info = None
                if hasattr(response, 'total_time') and response.total_time is not None:
                    timing_info = {}
                    if hasattr(response, 'time_to_first_token') and response.time_to_first_token is not None:
                        timing_info["time_to_first_token"] = response.time_to_first_token
                    if hasattr(response, 'time_to_thinking_end') and response.time_to_thinking_end is not None:
                        timing_info["time_to_thinking_end"] = response.time_to_thinking_end
                    if response.total_time is not None:
                        timing_info["total_time"] = response.total_time

                content = {}
                if tokens_info:
                    content["tokens"] = tokens_info
                if timing_info:
                    content["timing"] = timing_info
                content["message"] = '执行结束'
                yield StepUpdate(
                    step=self._step_count,
                    update_type="model_complete",
                    content=content,
                )

            self._context.append(
                self.adapter.build_assistant_message(response.thinking, response.action)
            )
            finish_message = action.get("message", "任务完成")
            if self.agent_config.verbose:
                logger.info("\n" + "🎉 " + "=" * 48)
                logger.info(f"✅ 任务完成: {finish_message}")
                logger.info("=" * 50 + "\n")
            yield StepUpdate(
                step=self._step_count,
                update_type="finished",
                content={"success": True, "message": finish_message},
            )
            return

        if self.agent_config.verbose:
            logger.debug("🎯 执行动作:")
            logger.debug(json.dumps(action, ensure_ascii=False, indent=2))

        model_description = None
        model_desc_token_info = None
        if response.thinking:
            try:
                model_description, model_desc_token_info = self.adapter.extract_description_from_thinking(
                    response.thinking
                )
            except Exception:
                model_description, model_desc_token_info = None, None

        if response:
            if model_desc_token_info:
                if response.prompt_tokens is not None:
                    response.prompt_tokens = (response.prompt_tokens or 0) + (
                            model_desc_token_info.get("prompt_tokens") or 0)
                elif model_desc_token_info.get("prompt_tokens") is not None:
                    response.prompt_tokens = model_desc_token_info.get("prompt_tokens")

                if response.completion_tokens is not None:
                    response.completion_tokens = (response.completion_tokens or 0) + (
                            model_desc_token_info.get("completion_tokens") or 0)
                elif model_desc_token_info.get("completion_tokens") is not None:
                    response.completion_tokens = model_desc_token_info.get("completion_tokens")

                if response.total_tokens is not None:
                    response.total_tokens = (response.total_tokens or 0) + (
                            model_desc_token_info.get("total_tokens") or 0)
                elif model_desc_token_info.get("total_tokens") is not None:
                    response.total_tokens = model_desc_token_info.get("total_tokens")

            tokens_info = None
            if hasattr(response, 'total_tokens') and response.total_tokens is not None:
                tokens_info = {
                    "prompt_tokens": response.prompt_tokens,
                    "completion_tokens": response.completion_tokens,
                    "total_tokens": response.total_tokens,
                }

            timing_info = None
            if hasattr(response, 'total_time') and response.total_time is not None:
                timing_info = {}
                if hasattr(response, 'time_to_first_token') and response.time_to_first_token is not None:
                    timing_info["time_to_first_token"] = response.time_to_first_token
                if hasattr(response, 'time_to_thinking_end') and response.time_to_thinking_end is not None:
                    timing_info["time_to_thinking_end"] = response.time_to_thinking_end
                if response.total_time is not None:
                    timing_info["total_time"] = response.total_time

            content = {}
            if tokens_info:
                content["tokens"] = tokens_info
            if timing_info:
                content["timing"] = timing_info
            if model_description:
                content["message"] = model_description

            yield StepUpdate(
                step=self._step_count,
                update_type="model_complete",
                content=content,
            )

        # 准备操作前截图并标注
        screenshot_before, action_description = self.action_handler.prepare_action_screenshot(
            action, screenshot.width, screenshot.height
        )
        yield StepUpdate(
            step=self._step_count,
            update_type="action",
            content={
                "action": action,
                "message": action_description,
                "screenshot_before": screenshot_before,
            },
        )

        # 清理历史图片，保留最近 keep_recent_images 步的截图
        self._cleanup_old_images()

        # 执行动作
        try:
            result = self.action_handler.execute(
                action, screenshot.width, screenshot.height
            )
        except Exception as e:
            if self.agent_config.verbose:
                logger.exception("动作执行失败")
            result = self.action_handler.execute(
                self.adapter.create_finish_action(message=str(e)), 
                screenshot.width, 
                screenshot.height
            )

        yield StepUpdate(
            step=self._step_count,
            update_type="result",
            content={
                "success": result.success,
                "message": result.message,
                "screenshot_after": result.screenshot_after,
            },
        )

        self._context.append(
            self.adapter.build_assistant_message(response.thinking, response.action)
        )

        # 记录执行结果
        result_text = f"action执行结果: {'成功' if result.success else '失败'}"
        if result.message:
            result_text += f" - {result.message}"
        if not result.success:
            result_text += "\n请根据执行结果调整策略，重新尝试或选择其他操作。"
        self._context.append(
            self.adapter.build_user_message(text=result_text)
        )

    def _cleanup_old_images(self) -> None:
        """清理历史消息中的图片，保留最近 keep_recent_images 步的截图。
        
        遍历上下文消息，从旧到新清理包含图片的用户消息，
        保留最近 N 条带图片的消息不被清理。
        
        这样模型可以参考最近几步的界面截图，更好地理解上下文。
        """
        # 确保至少保留 1 张图片
        keep_count = max(1, self.agent_config.keep_recent_images)
        
        # 找出所有包含图片的用户消息的索引（从旧到新）
        messages_with_images = []
        for i, msg in enumerate(self._context):
            if msg.get("role") == "user" and self._message_has_image(msg):
                messages_with_images.append(i)
        
        # 保留最近 keep_count 条，清理其余的
        if len(messages_with_images) > keep_count:
            messages_to_clean = messages_with_images[:-keep_count]
            for idx in messages_to_clean:
                self._context[idx] = self.adapter.remove_images_from_message(self._context[idx])
    
    def _message_has_image(self, message: MessageDict) -> bool:
        """检查消息是否包含图片内容。"""
        content = message.get("content")
        if isinstance(content, list):
            return any(
                item.get("type") in ("image_url", "image") 
                for item in content
            )
        return False

    @property
    def context(self) -> list[MessageDict]:
        """获取当前对话上下文。"""
        return self._context.copy()

    @property
    def step_count(self) -> int:
        """获取当前步数。"""
        return self._step_count

    def _get_screenshot(self) -> Screenshot:
        """从设备获取截图并进行压缩优化。
        
        压缩策略：
        1. 可选将图片转换为 JPEG 格式（比 PNG 体积更小）
        2. 等比例缩放，使最长边不超过 image_max_size
        3. 使用 image_quality 控制压缩质量
        
        Returns:
            Screenshot 对象，包含压缩后的图片数据和原始尺寸信息
        """
        try:
            base64_data = self.device.screenshot_base64()
            if not base64_data:
                return self._create_fallback_screenshot()

            if base64_data.startswith("data:image"):
                base64_data = base64_data.split(",", 1)[1]

            img_data = base64.b64decode(base64_data)
            img = Image.open(BytesIO(img_data))
            
            # 记录原始尺寸（用于坐标计算）
            original_width, original_height = img.size
            
            # 压缩图片
            compressed_base64, mime_type = self._compress_image(img)

            return Screenshot(
                base64_data=compressed_base64, 
                width=original_width,  # 返回原始尺寸，用于坐标映射
                height=original_height, 
                is_sensitive=False,
                mime_type=mime_type,
            )
        except Exception as e:
            if self.agent_config.verbose:
                logger.error(f"截图错误: {e}")
            return self._create_fallback_screenshot()
    
    def _compress_image(self, img: Image.Image) -> tuple[str, str]:
        """压缩图片：可选转 JPEG + 限制最长边 + 质量压缩。
        
        压缩参数从当前模型配置中获取，不同模型有不同的默认值：
        - MAI 系列：默认压缩到 960px，转 JPEG
        - AutoGLM 系列：默认不压缩，保持 PNG（对分辨率敏感）
        
        Args:
            img: PIL Image 对象
            
        Returns:
            (base64 编码字符串, MIME 类型) 元组
        """
        # 从模型配置中获取图片压缩参数
        adapter_config = self.model_config.get_adapter_config()
        max_size = adapter_config.image_max_size
        quality = adapter_config.image_quality
        convert_to_jpeg = adapter_config.convert_to_jpeg
        
        # 等比例缩放：限制最长边
        if max_size is not None and max_size > 0:
            width, height = img.size
            max_dim = max(width, height)
            
            if max_dim > max_size:
                scale = max_size / max_dim
                new_width = int(width * scale)
                new_height = int(height * scale)
                img = img.resize((new_width, new_height), Image.Resampling.LANCZOS)
                
                if self.agent_config.verbose:
                    logger.debug(
                        f"📷 图片缩放: {width}x{height} -> {new_width}x{new_height} "
                        f"(最长边限制 {max_size})"
                    )
        
        buffered = BytesIO()
        
        if convert_to_jpeg:
            # 转 JPEG：确保图片是 RGB 模式（JPEG 不支持 RGBA）
            if img.mode in ('RGBA', 'P'):
                img = img.convert('RGB')
            img.save(buffered, format="JPEG", quality=quality or 85, optimize=True)
            mime_type = "image/jpeg"
            
            if self.agent_config.verbose:
                logger.debug(f"📷 图片格式: JPEG (quality={quality or 85})")
        else:
            # 保持 PNG 格式
            img.save(buffered, format="PNG", optimize=True)
            mime_type = "image/png"
            
            if self.agent_config.verbose:
                logger.debug("📷 图片格式: PNG (无损)")
        
        compressed_data = base64.b64encode(buffered.getvalue()).decode("utf-8")
        
        return compressed_data, mime_type

    def _get_current_app(self) -> str:
        """获取当前应用名称。"""
        try:
            package_name = self.device.current_app()
            return package_name if package_name else "System Home"
        except Exception as e:
            if self.agent_config.verbose:
                logger.error(f"获取当前应用失败: {e}")
            return "System Home"

    def _create_fallback_screenshot(self) -> Screenshot:
        """创建占位截图。"""
        default_width, default_height = 1080, 2400
        black_img = Image.new("RGB", (default_width, default_height), color="black")
        buffered = BytesIO()
        black_img.save(buffered, format="PNG")
        base64_data = base64.b64encode(buffered.getvalue()).decode("utf-8")

        return Screenshot(
            base64_data=base64_data,
            width=default_width,
            height=default_height,
            is_sensitive=False,
        )

    def _trim_context_if_needed(self, current_prompt_tokens: int) -> None:
        """根据实际 token 使用量裁剪上下文。
        
        裁剪策略：
        - 始终保留：系统提示词 + 用户初始任务 + 第一步回复（包含任务规划）
        - 始终保留：最近几轮对话（确保模型有足够的近期上下文）
        - 移除：中间的历史对话轮次
        
        上下文结构示例：
        [0] system: 系统提示词（必须保留）
        [1] user: 用户初始任务 + 第一张截图（必须保留）
        [2] assistant: 第一步的思考和动作（必须保留，包含任务规划）
        [3] user: 第一步的执行结果（必须保留）
        ─────────────────────────────
        [4] user: 第二步的截图和屏幕信息（可清理）
        [5] assistant: 第二步的思考和动作（可清理）
        [6] user: 第二步的执行结果（可清理）
        ...
        ─────────────────────────────
        [-6] user: 最近第2步的截图（保留）
        [-5] assistant: 最近第2步的回复（保留）
        [-4] user: 最近第2步的结果（保留）
        [-3] user: 最近一步的截图（保留）
        [-2] assistant: 最近一步的回复（保留）
        [-1] user: 最近的执行结果（保留）
        
        Args:
            current_prompt_tokens: 当前请求的 prompt token 数（由模型返回）
        """
        threshold = int(self.agent_config.max_context_tokens * self.agent_config.context_warning_threshold)
        
        if current_prompt_tokens < threshold:
            return
        
        logger.warning(
            f"⚠️ 上下文接近限制: {current_prompt_tokens}/{self.agent_config.max_context_tokens} tokens "
            f"({current_prompt_tokens / self.agent_config.max_context_tokens * 100:.1f}%)"
        )
        
        # 必须保留的消息：
        # - 前4条：系统消息 + 用户初始任务 + 第一步回复（任务规划）+ 第一步结果
        # - 后6条：保留最近2轮对话的上下文（每轮约3条：截图+回复+结果）
        protected_head = 4  # 系统提示词 + 用户初始任务 + 第一步回复 + 第一步结果
        protected_tail = 6  # 最近2轮对话
        min_context_len = protected_head + protected_tail
        
        if len(self._context) <= min_context_len:
            logger.debug(f"上下文消息数({len(self._context)})已是最小值，无法继续裁剪")
            return
        
        # 计算可以移除的范围
        removable_start = protected_head  # 从索引4开始可以移除
        removable_end = len(self._context) - protected_tail  # 保护最后6条
        
        if removable_start >= removable_end:
            logger.debug("没有可移除的消息")
            return
        
        # 每次裁剪移除一轮完整的对话（通常3条消息）
        # 一轮对话结构：user(截图) -> assistant(回复) -> user(结果)
        removed_count = 0
        messages_to_remove = min(3, removable_end - removable_start)  # 最多移除一轮（3条）
        
        for _ in range(messages_to_remove):
            if removable_start < len(self._context) - protected_tail:
                removed_msg = self._context.pop(removable_start)
                removed_count += 1
                
                # 记录移除的消息类型（调试用）
                role = removed_msg.get("role", "unknown")
                logger.debug(f"移除历史消息: role={role}")
        
        if removed_count > 0:
            logger.info(
                f"🗑️ 已裁剪 {removed_count} 条历史消息以控制上下文长度 "
                f"(保留系统提示词+初始任务+第一步规划+最近{protected_tail}条消息)"
            )

    def get_context_stats(self) -> dict:
        """获取当前上下文统计信息。
        
        Returns:
            包含以下字段的字典：
            - message_count: 上下文消息数
            - last_prompt_tokens: 最近一次请求的 prompt token 数
            - max_context_tokens: 配置的最大上下文 token 数
            - usage_ratio: 使用率（如果有 token 信息）
            - images_count: 当前上下文中的图片数量
        """
        images_count = sum(1 for msg in self._context if self._message_has_image(msg))
        
        stats = {
            "message_count": len(self._context),
            "last_prompt_tokens": self._last_prompt_tokens,
            "max_context_tokens": self.agent_config.max_context_tokens,
            "images_count": images_count,
        }
        
        if self._last_prompt_tokens is not None:
            stats["usage_ratio"] = self._last_prompt_tokens / self.agent_config.max_context_tokens
        
        return stats
