"""
Exploration Agent - 基于AI的手机自动化探索测试框架。

支持UBOX SDK设备的探索测试Agent能力，SDK已统一支持Android、iOS和HarmonyOS三端。

配置设计理念：
- 每个模型单独配置服务地址、密钥和参数，清晰明确
- Agent 的行为逻辑由模型类型（ModelType）决定
- 支持多模型配置，可在运行时切换

目录结构：
- agent.py: Agent 核心实现
- device_interface.py: 设备接口定义
- apps.py: 应用包名映射（通用资源）
- actions/: 动作处理模块
- models/: 模型实现目录
  - base.py: 基础类定义
  - registry.py: 模型注册表
  - autoglm/: AutoGLM 模型实现
- config/: 通用配置（timing）

使用示例：
    ```python
    from ubox_py_sdk.phone_agent import (
        ExplorationAgent, AgentConfig,
        ModelType, ModelConfig, AgentModelConfig
    )
    
    # 配置模型
    model_config = AgentModelConfig(
        model=ModelType.AUTOGLM_PHONE_9B,
        models={
            ModelType.AUTOGLM_PHONE_9B: ModelConfig(
                base_url="http://localhost:8000/v1"
            ),
            ModelType.AUTOGLM_PHONE_14B: ModelConfig(
                base_url="https://api.example.com/v1",
                api_key="your-key"
            ),
        }
    )
    
    # 创建 Agent
    agent = ExplorationAgent(model_config=model_config, device=device)
    
    # 执行任务
    for update in agent.run_stream("打开微信"):
        print(update)
    
    # 切换模型
    for update in agent.run_stream("打开微信", model=ModelType.AUTOGLM_PHONE_14B):
        print(update)
    ```
"""

# 导出用户需要的配置类和结构体
from .agent import (
    AgentConfig,
    ExplorationAgent,
    StepUpdate,
    UpdateType,
    
    Screenshot,
)
from .device_interface import IDeviceOperations
from .actions.handler import ActionResult

# 导出动作定义类型（推荐使用）
from .actions.definitions import (
    HandlerAction,   # 推荐使用，提供更好的类型提示
    ActionType,
    ActionBuilder,
    action_builder,
    Coordinate,
)

# 导出模型相关类
from .models import (
    # 模型类型枚举
    ModelType,
    # 配置类
    ModelConfig,
    AgentModelConfig,
    # 工厂函数
    create_adapter,
    register_adapter,
    register_model,
    get_supported_models,
    # 基础类
    BaseModelAdapter,
    ModelResponse,
    # 具体适配器
    AutoGLMAdapter,
    MAIAdapter,
)

# 导出应用映射（通用资源）
from .apps import (
    APP_PACKAGES,
    APP_PACKAGES_ANDROID,
    APP_PACKAGES_IOS,
    APP_PACKAGES_HARMONYOS,
    get_package_name,
    get_app_name,
    list_supported_apps,
)

__version__ = "0.3.0"
__all__ = [
    # Agent 核心类
    "ExplorationAgent",
    "AgentConfig",
    "StepUpdate",
    "UpdateType",
    
    "HandlerAction",   # 推荐使用
    "Screenshot",
    "ActionResult",
    "IDeviceOperations",
    # 动作定义
    "ActionType",
    "ActionBuilder",
    "action_builder",
    "Coordinate",
    # 模型类型枚举
    "ModelType",
    # 配置类
    "ModelConfig",
    "AgentModelConfig",
    # 工厂函数
    "create_adapter",
    "register_adapter",
    "register_model",
    "get_supported_models",
    # 适配器基类
    "BaseModelAdapter",
    "ModelResponse",
    # 具体适配器
    "AutoGLMAdapter",
    "MAIAdapter",
    # 应用映射（通用资源）
    "APP_PACKAGES",
    "APP_PACKAGES_ANDROID",
    "APP_PACKAGES_IOS",
    "APP_PACKAGES_HARMONYOS",
    "get_package_name",
    "get_app_name",
    "list_supported_apps",
]
