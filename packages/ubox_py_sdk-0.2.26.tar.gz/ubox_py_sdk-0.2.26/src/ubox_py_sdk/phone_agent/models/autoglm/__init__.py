"""AutoGLM 模型实现模块。

此模块包含 AutoGLM-Phone 模型的完整实现，包括：
- 适配器 (AutoGLMAdapter)
- 系统提示词 (SYSTEM_PROMPT)

配置说明：
    AutoGLM 适配器使用通用的 ModelConfig 配置类。
    配置通过 AgentModelConfig 统一管理：
    - base_url: 服务地址
    - api_key: API 密钥
    - model_name: 实际请求时的模型名称（可选）
    - model: 模型类型（ModelType.AUTOGLM_PHONE_9B 或 AUTOGLM_PHONE_14B）

注意：应用映射表 (APP_PACKAGES) 是所有模型通用的资源，
已移至 phone_agent/apps.py，请从那里导入。

使用示例:
    ```python
    from ubox_py_sdk.phone_agent.models import AgentModelConfig, ModelType, ModelConfig, create_adapter
    
    # 配置模型
    config = AgentModelConfig(
        model=ModelType.AUTOGLM_PHONE_9B,
        models={
            ModelType.AUTOGLM_PHONE_9B: ModelConfig(
                base_url="http://localhost:8000/v1"
            ),
        }
    )
    
    # 创建适配器
    adapter = create_adapter(config)
    ```
"""

from .adapter import AutoGLMAdapter
from .prompts import SYSTEM_PROMPT

__all__ = [
    # 适配器
    "AutoGLMAdapter",
    # 提示词
    "SYSTEM_PROMPT",
]
