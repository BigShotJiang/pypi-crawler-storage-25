"""模型适配器模块。

本模块提供了探索测试 Agent 的模型适配器接口和实现。

设计理念：
- 每个模型单独配置服务地址、密钥和参数，清晰明确
- Agent 的行为逻辑由模型类型（ModelType）决定
- 支持多模型配置，可在运行时切换

目录结构：
- base.py: 基础类定义（BaseModelAdapter, ModelResponse）
- registry.py: 模型注册表、配置类和工厂函数
- autoglm/: AutoGLM 模型实现
  - adapter.py: AutoGLM 适配器
  - prompts.py: AutoGLM 系统提示词
- mai/: MAI-UI 模型实现
  - adapter.py: MAI 适配器
  - prompts.py: MAI 系统提示词

使用示例:
    ```python
    from ubox_py_sdk.phone_agent.models import (
        ModelType, ModelConfig, AgentModelConfig, create_adapter
    )
    
    # 使用 AutoGLM 模型
    config = AgentModelConfig(
        model=ModelType.AUTOGLM_PHONE_9B,
        models={
            ModelType.AUTOGLM_PHONE_9B: ModelConfig(
                base_url="http://localhost:8000/v1"
            ),
        }
    )
    
    # 使用 MAI-UI 模型
    config = AgentModelConfig(
        model=ModelType.MAI_UI_8B,
        models={
            ModelType.MAI_UI_8B: ModelConfig(
                base_url="http://localhost:8000/v1",
                model_name="MAI-UI-8B"
            ),
        }
    )
    
    # 创建适配器
    adapter = create_adapter(config)
    ```

扩展新模型:
    要添加新的模型支持，需要：
    1. 在 ModelType 枚举中添加新的模型类型
    2. 在 _MODEL_ADAPTER_TYPE 中注册该模型使用的适配器类型
"""

# 基础类
from .base import (
    
    BaseModelAdapter,
    HandlerAction,   # 推荐使用，提供更好的类型提示
    MessageDict,
    ModelResponse,
)

# 注册表和工厂
from .registry import (
    ModelType,
    ModelConfig,
    AgentModelConfig,
    create_adapter,
    register_adapter,
    register_model,
    get_supported_models,
)

# AutoGLM 模型（具体实现）
from .autoglm import (
    AutoGLMAdapter,
)

# MAI-UI 模型（具体实现）
from .mai import (
    MAIAdapter,
)

__all__ = [
    # 模型类型枚举
    "ModelType",
    # 配置类
    "ModelConfig",
    "AgentModelConfig",
    # 工厂函数
    "create_adapter",
    "register_adapter",
    "register_model",
    "get_supported_models",
    # 基础类
    "BaseModelAdapter",
    "ModelResponse",
    "MessageDict",
    
    "HandlerAction",   # 推荐使用
    # 具体适配器实现
    "AutoGLMAdapter",
    "MAIAdapter",
]
