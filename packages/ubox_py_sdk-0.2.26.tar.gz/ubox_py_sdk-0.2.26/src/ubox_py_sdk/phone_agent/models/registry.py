"""模型适配器注册表和工厂。

本模块提供模型枚举、配置管理和适配器工厂功能。

设计理念：
- 每个模型单独配置服务地址、密钥和参数，清晰明确
- Agent 的行为逻辑由模型类型（ModelType）决定
- 支持多模型配置，可在运行时切换

使用示例:
    ```python
    from ubox_py_sdk.phone_agent.models import (
        ModelType, ModelConfig, AgentModelConfig, create_adapter
    )
    
    # 配置模型
    config = AgentModelConfig(
        model=ModelType.AUTOGLM_PHONE_9B,
        models={
            ModelType.AUTOGLM_PHONE_9B: ModelConfig(
                base_url="http://localhost:8000/v1"
            ),
            ModelType.AUTOGLM_PHONE_14B: ModelConfig(
                base_url="https://api.example.com/v1",
                api_key="your-key",
                model_name="autoglm-14b-v2"  # 可选，指定实际请求的模型名称
            ),
        }
    )
    
    # 创建适配器
    adapter = create_adapter(config)
    ```
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Type, Any

from .base import BaseModelAdapter


class ModelType(Enum):
    """支持的模型类型枚举。
    
    每个模型类型决定了 Agent 的行为逻辑（系统提示词、输出解析等）。
    同一个模型可以由不同的服务提供商提供。
    
    新增模型时，需要：
    1. 在此枚举中添加新的模型类型
    2. 在 _MODEL_ADAPTER_TYPE 中注册对应的适配器类型
    """
    
    AUTOGLM_PHONE_9B = "AutoGLM-Phone-9B-Multilingual"
    """AutoGLM-Phone-9B-Multilingual 模型，专为手机操作设计的视觉语言模型。"""

    AUTOGLM_PHONE_9B_ZHIPU = "AutoGLM-Phone"
    """智谱平台的 AutoGLM-Phone 模型。"""
    
    MAI_UI_2B = "MAI-UI-2B"
    """MAI-UI-2B 模型，阿里云的轻量级 GUI 智能体模型。"""

    MAI_UI_8B = "MAI-UI-8B"
    """MAI-UI-8B 模型，阿里云的 GUI 智能体模型，适用于 UI 理解和操作。"""


# 模型类型到适配器类型的映射
# 决定了每种模型使用哪个适配器实现（系统提示词、输出解析逻辑等）
_MODEL_ADAPTER_TYPE: Dict[ModelType, str] = {
    ModelType.AUTOGLM_PHONE_9B: "autoglm",
    ModelType.AUTOGLM_PHONE_9B_ZHIPU: "autoglm",
    ModelType.MAI_UI_2B: "mai",
    ModelType.MAI_UI_8B: "mai",
}


@dataclass
class ModelConfig:
    """单个模型的服务配置。
    
    每个模型单独配置服务地址、密钥和参数。
    
    Attributes:
        base_url: 模型服务的 API 地址
        api_key: API 密钥
        model_name: 实际请求时使用的模型名称（可选，默认使用 ModelType 的 value）
        max_tokens: 最大生成 token 数
        temperature: 温度参数
        top_p: Top-p 采样参数
        frequency_penalty: 频率惩罚参数
        extra_body: 额外的请求体参数
        image_max_size: 图片最长边的最大像素值（0 表示不压缩）
        image_quality: 图片压缩质量（1-100）
        
    Example:
        ```python
        # 本地部署，使用默认模型名称
        config = ModelConfig(
            base_url="http://localhost:8000/v1"
        )
        
        # 云端服务，指定实际的模型名称
        config = ModelConfig(
            base_url="https://api.example.com/v1",
            api_key="your-api-key",
            model_name="autoglm-9b-v1"  # 服务商要求的实际模型名称
        )
        ```
    """
    
    base_url: str = "http://localhost:8000/v1"
    """模型服务的 API 地址。"""
    
    api_key: str = "EMPTY"
    """API 密钥。本地部署通常为 "EMPTY"。"""
    
    model_name: Optional[str] = None
    """实际请求时使用的模型名称。如果为 None，则使用 ModelType 的 value。"""
    
    max_tokens: int = 3000
    """最大生成 token 数。"""
    
    temperature: float = 0.0
    """温度参数，控制输出随机性。范围 0-2，0 表示最确定性的输出。"""
    
    top_p: float = 0.85
    """Top-p 采样参数。"""
    
    frequency_penalty: float = 0.2
    """频率惩罚参数，减少重复内容。"""
    
    extra_body: Dict[str, Any] = field(default_factory=dict)
    """额外的请求体参数，会传递给模型 API。"""
    
    image_max_size: Optional[int] = None
    """图片最长边的最大像素值。
    
    截图会被等比例缩放，使最长边不超过此值。
    - None：使用模型默认值（MAI 系列: 960, AutoGLM 系列: 不压缩）
    - 0 或负数：不压缩，保持原始尺寸
    - 正数：限制最长边到指定像素值
    """
    
    image_quality: Optional[int] = None
    """图片压缩质量（1-100）。
    
    - None：使用默认值 85
    - 1-100：指定压缩质量（数值越低压缩率越高，图片质量越低）
    """
    
    convert_to_jpeg: Optional[bool] = None
    """是否将图片转换为 JPEG 格式。
    
    - None：使用模型默认值（MAI 系列: True, AutoGLM 系列: False）
    - True：转换为 JPEG（体积更小，传输更快，但为有损压缩）
    - False：保持 PNG 格式（无损压缩，保留所有细节）
    """


# 不同模型类型的默认图片配置
_MODEL_IMAGE_DEFAULTS: Dict[ModelType, Dict[str, Any]] = {
    # MAI 系列：支持压缩，默认 960px，转 JPEG
    ModelType.MAI_UI_2B: {"image_max_size": 960, "image_quality": 85, "convert_to_jpeg": True},
    ModelType.MAI_UI_8B: {"image_max_size": 960, "image_quality": 85, "convert_to_jpeg": True},
    # AutoGLM 系列：对分辨率敏感，默认不压缩，转 JPEG
    ModelType.AUTOGLM_PHONE_9B: {"image_max_size": 0, "image_quality": 85, "convert_to_jpeg": True},
    ModelType.AUTOGLM_PHONE_9B_ZHIPU: {"image_max_size": 0, "image_quality": 85, "convert_to_jpeg": True},
}


@dataclass
class AgentModelConfig:
    """Agent 模型配置。
    
    通过 models 字典为每个模型单独配置服务地址、密钥和参数。
    
    使用示例:
        ```python
        # 配置单个模型
        config = AgentModelConfig(
            model=ModelType.AUTOGLM_PHONE_9B,
            models={
                ModelType.AUTOGLM_PHONE_9B: ModelConfig(
                    base_url="http://localhost:8000/v1"
                ),
            }
        )
        
        # 配置多个模型，可运行时切换
        config = AgentModelConfig(
            model=ModelType.AUTOGLM_PHONE_9B,  # 当前使用的模型
            models={
                ModelType.AUTOGLM_PHONE_9B: ModelConfig(
                    base_url="http://localhost:8000/v1"
                ),
                ModelType.AUTOGLM_PHONE_14B: ModelConfig(
                    base_url="https://api.example.com/v1",
                    api_key="your-key",
                    model_name="autoglm-14b-v2"  # 服务商要求的实际名称
                ),
            }
        )
        ```
    
    Attributes:
        model: 当前使用的模型类型
        models: 模型配置字典，每个模型单独配置
    """
    
    model: ModelType = ModelType.AUTOGLM_PHONE_9B
    """当前使用的模型类型。"""
    
    models: Dict[ModelType, ModelConfig] = field(default_factory=dict)
    """模型配置字典，每个模型单独配置服务地址、密钥等参数。"""
    
    def __post_init__(self):
        """初始化后检查配置有效性。"""
        if not self.models:
            # 如果没有配置任何模型，为当前模型创建默认配置
            self.models = {self.model: ModelConfig()}
        elif self.model not in self.models:
            raise ValueError(
                f"当前模型 {self.model.value} 未在 models 中配置。"
                f"已配置的模型: {[m.value for m in self.models.keys()]}"
            )
    
    def get_model_config(self, model: Optional[ModelType] = None) -> ModelConfig:
        """获取指定模型的配置。
        
        Args:
            model: 模型类型，默认为当前模型
            
        Returns:
            模型配置
            
        Raises:
            ValueError: 如果指定的模型未配置
        """
        target_model = model or self.model
        
        if target_model not in self.models:
            configured = [m.value for m in self.models.keys()]
            raise ValueError(
                f"模型 {target_model.value} 未配置。"
                f"已配置的模型: {configured}"
            )
        
        return self.models[target_model]
    
    def get_adapter_config(self, model: Optional[ModelType] = None) -> "ModelConfig":
        """获取适配器使用的模型配置。
        
        此方法返回填充了实际 model_name 和默认图片配置的配置副本，供适配器使用。
        
        Args:
            model: 模型类型，默认为当前模型
            
        Returns:
            带有实际 model_name 和图片配置的 ModelConfig 对象
        """
        target_model = model or self.model
        model_config = self.get_model_config(target_model)
        
        # 获取该模型的默认图片配置
        image_defaults = _MODEL_IMAGE_DEFAULTS.get(target_model, {"image_max_size": 0, "image_quality": 85, "convert_to_jpeg": False})
        
        # 创建配置副本，填充默认值
        return ModelConfig(
            base_url=model_config.base_url,
            api_key=model_config.api_key,
            model_name=model_config.model_name or target_model.value,
            max_tokens=model_config.max_tokens,
            temperature=model_config.temperature,
            top_p=model_config.top_p,
            frequency_penalty=model_config.frequency_penalty,
            extra_body=model_config.extra_body,
            # 图片配置：优先使用用户配置，否则使用模型默认值
            image_max_size=model_config.image_max_size if model_config.image_max_size is not None else image_defaults["image_max_size"],
            image_quality=model_config.image_quality if model_config.image_quality is not None else image_defaults["image_quality"],
            convert_to_jpeg=model_config.convert_to_jpeg if model_config.convert_to_jpeg is not None else image_defaults["convert_to_jpeg"],
        )
    
    def with_model(self, model: ModelType) -> "AgentModelConfig":
        """创建使用指定模型的新配置。
        
        Args:
            model: 要切换到的模型类型
            
        Returns:
            新的配置对象
            
        Raises:
            ValueError: 如果指定的模型未配置
        """
        # 验证模型已配置
        self.get_model_config(model)
        
        return AgentModelConfig(
            model=model,
            models=self.models,
        )


# ============================================================
# 适配器注册表
# ============================================================

# 适配器类型 -> 适配器类的映射（延迟加载）
_ADAPTER_REGISTRY: Dict[str, Type[BaseModelAdapter]] = {}


def _ensure_registry_initialized():
    """确保注册表已初始化。"""
    global _ADAPTER_REGISTRY
    if not _ADAPTER_REGISTRY:
        # 延迟导入适配器类
        from .autoglm import AutoGLMAdapter
        from .mai import MAIAdapter
        
        _ADAPTER_REGISTRY = {
            "autoglm": AutoGLMAdapter,
            "mai": MAIAdapter,
        }


def register_adapter(adapter_type: str, adapter_class: Type[BaseModelAdapter]) -> None:
    """注册新的模型适配器类型。
    
    Args:
        adapter_type: 适配器类型标识（如 "autoglm", "qwen"）
        adapter_class: 适配器类（必须继承 BaseModelAdapter）
    """
    _ensure_registry_initialized()
    _ADAPTER_REGISTRY[adapter_type] = adapter_class


def register_model(model_type: ModelType, adapter_type: str) -> None:
    """注册模型类型到适配器类型的映射。
    
    Args:
        model_type: 模型类型枚举
        adapter_type: 适配器类型标识
    """
    _MODEL_ADAPTER_TYPE[model_type] = adapter_type


def get_supported_models() -> List[ModelType]:
    """获取所有系统支持的模型类型列表。
    
    Returns:
        支持的模型类型列表
    """
    return list(_MODEL_ADAPTER_TYPE.keys())


def create_adapter(config: AgentModelConfig) -> BaseModelAdapter:
    """根据配置创建模型适配器。
    
    Args:
        config: Agent 模型配置
        
    Returns:
        对应模型的适配器实例
        
    Raises:
        ValueError: 如果模型类型不支持
        
    Example:
        ```python
        config = AgentModelConfig(
            model=ModelType.AUTOGLM_PHONE_9B,
            models={
                ModelType.AUTOGLM_PHONE_9B: ModelConfig(
                    base_url="http://localhost:8000/v1"
                ),
            }
        )
        adapter = create_adapter(config)
        ```
    """
    _ensure_registry_initialized()
    
    # 获取该模型对应的适配器类型
    adapter_type = _MODEL_ADAPTER_TYPE.get(config.model)
    if adapter_type is None:
        supported = [m.value for m in get_supported_models()]
        raise ValueError(
            f"不支持的模型类型: {config.model.value}，"
            f"当前支持的模型: {supported}"
        )
    
    # 获取适配器类
    adapter_class = _ADAPTER_REGISTRY.get(adapter_type)
    if adapter_class is None:
        raise ValueError(
            f"适配器类型 '{adapter_type}' 未注册，"
            f"请先调用 register_adapter() 注册"
        )
    
    # 创建适配器
    adapter_config = config.get_adapter_config()
    return adapter_class(adapter_config)
