"""模型适配器抽象基类定义。

本模块定义了探索测试 Agent 的模型适配器接口，使得不同的 AI 模型可以通过实现统一接口来接入系统。

要实现一个新的模型适配器，需要继承 BaseModelAdapter 类并实现以下方法：
1. get_system_prompt() - 返回模型使用的系统提示词
2. request_stream() - 流式请求模型，返回思考过程
3. get_last_response() - 获取最后一次请求的完整响应
4. parse_action() - 解析模型输出的动作
5. build_user_message() - 构建用户消息（包含截图和屏幕信息）
6. build_assistant_message() - 构建助手消息（记录历史）

示例用法:
    ```python
    from ubox_py_sdk.phone_agent.models import AutoGLMAdapter, ModelConfig
    
    # 创建模型配置
    config = ModelConfig(
        base_url="http://localhost:8000/v1",
        api_key="your-api-key",
        model_name="autoglm-phone-9b"
    )
    
    # 创建适配器实例
    adapter = AutoGLMAdapter(config)
    
    # 在 Agent 中使用
    agent = ExplorationAgent(adapter=adapter, device=device)
    ```
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict, Generator, List, Optional, TYPE_CHECKING

# 导入强类型的动作定义
from ..actions.definitions import HandlerAction

if TYPE_CHECKING:
    from .registry import ModelConfig


# 类型定义
MessageDict = Dict[str, Any]




@dataclass
class ModelResponse:
    """模型响应的标准格式。
    
    所有模型适配器返回的响应都应该转换为此格式，以便 Agent 统一处理。
    
    Attributes:
        thinking: 模型的思考过程文本
        action: 解析后的动作字符串（原始格式）
        raw_content: 模型的原始响应内容
        time_to_first_token: 首 Token 延迟（秒）
        time_to_thinking_end: 思考完成延迟（秒）
        total_time: 总推理时间（秒）
        prompt_tokens: 输入 token 数
        completion_tokens: 输出 token 数
        total_tokens: 总 token 数
    """
    
    thinking: str
    """模型的思考过程文本。"""
    
    action: str
    """解析后的动作字符串（原始格式）。"""
    
    raw_content: str
    """模型的原始响应内容。"""
    
    # 性能指标
    time_to_first_token: Optional[float] = None
    """首 Token 延迟（秒）。"""
    
    time_to_thinking_end: Optional[float] = None
    """思考完成延迟（秒）。"""
    
    total_time: Optional[float] = None
    """总推理时间（秒）。"""
    
    # Token 统计
    prompt_tokens: Optional[int] = None
    """输入 token 数。"""
    
    completion_tokens: Optional[int] = None
    """输出 token 数。"""
    
    total_tokens: Optional[int] = None
    """总 token 数。"""


class BaseModelAdapter(ABC):
    """模型适配器抽象基类。
    
    所有模型适配器都需要继承此类并实现抽象方法。
    适配器负责：
    1. 提供模型使用的系统提示词
    2. 处理与模型服务的通信
    3. 解析模型输出的动作
    4. 构建对话消息
    
    Attributes:
        config: 模型配置
        _last_response: 最后一次请求的响应
    """
    
    def __init__(self, config: Optional["ModelConfig"] = None):
        """初始化模型适配器。
        
        Args:
            config: 模型配置，如果为 None 则使用默认配置
        """
        if config is None:
            from .registry import ModelConfig
            config = ModelConfig()
        self.config = config
        self._last_response: Optional[ModelResponse] = None
    
    @property
    def name(self) -> str:
        """返回适配器名称，用于日志和调试。
        
        Returns:
            适配器的可读名称
        """
        return self.__class__.__name__
    
    @abstractmethod
    def get_system_prompt(self) -> str:
        """获取该模型使用的系统提示词。
        
        系统提示词是模型实现的核心部分，它影响模型输出的格式和内容解析。
        每个模型适配器都应该提供自己专属的系统提示词，不建议外部修改。
        
        Returns:
            系统提示词字符串
        """
        pass
    
    @abstractmethod
    def request_stream(
        self, 
        messages: List[MessageDict]
    ) -> Generator[str, None, None]:
        """向模型发送流式请求，实时返回思考过程。
        
        此方法应该：
        1. 向模型服务发送请求
        2. 以流式方式返回模型的思考过程
        3. 完成后更新 _last_response
        
        Args:
            messages: OpenAI 格式的消息列表
            
        Yields:
            思考过程的文本块
        """
        pass
    
    @abstractmethod
    def get_last_response(self) -> Optional[ModelResponse]:
        """获取最后一次请求的完整响应。
        
        在调用 request_stream() 后可以调用此方法获取完整的响应信息，
        包括 token 统计和推理时长。
        
        Returns:
            ModelResponse 对象，如果没有请求过则返回 None
        """
        pass
    
    @abstractmethod
    def parse_action(self, response: str) -> HandlerAction:
        """解析模型输出的动作。
        
        不同的模型可能使用不同的动作格式，此方法负责将模型输出解析为统一的动作字典。
        推荐使用 ActionBuilder 来构建返回值以获得类型安全。
        
        执行动作格式 (HandlerAction):
            {
                "_metadata": "do",
                "action": str,      # 动作名称，使用 ActionType 枚举值
                "element": [x, y],  # 坐标，千分比表示 (0-1000)
                ...                 # 其他动作特定参数
            }
        
        结束动作格式:
            {
                "_metadata": "finish",
                "message": str,     # 结束消息
            }
        
        Args:
            response: 模型响应中的动作部分字符串
            
        Returns:
            解析后的 HandlerAction 字典
            
        Raises:
            ValueError: 如果动作无法解析
            
        See Also:
            - ActionType: 支持的动作类型枚举
            - ActionBuilder: 类型安全的动作构建器
            - ACTION_DEFINITIONS: 动作定义详情
        """
        pass
    
    @abstractmethod
    def build_user_message(
        self, 
        text: str, 
        image_base64: Optional[str] = None,
        mime_type: str = "image/png"
    ) -> MessageDict:
        """构建用户消息。
        
        Args:
            text: 文本内容
            image_base64: 可选的 base64 编码图片
            mime_type: 图片的 MIME 类型，默认为 "image/png"
            
        Returns:
            用户消息字典
        """
        pass
    
    @abstractmethod
    def build_assistant_message(
        self, 
        thinking: str, 
        action: str
    ) -> MessageDict:
        """构建助手消息，用于记录历史上下文。
        
        Args:
            thinking: 思考过程
            action: 执行的动作
            
        Returns:
            助手消息字典
        """
        pass
    
    def build_system_message(self, content: Optional[str] = None) -> MessageDict:
        """构建系统消息。
        
        Args:
            content: 系统消息内容，如果为 None 则使用 get_system_prompt()
            
        Returns:
            系统消息字典
        """
        return {
            "role": "system", 
            "content": content or self.get_system_prompt()
        }
    
    def build_screen_info(self, current_app: str, **extra_info) -> str:
        """构建屏幕信息字符串。
        
        Args:
            current_app: 当前应用名称
            **extra_info: 额外的信息
            
        Returns:
            包含屏幕信息的 JSON 字符串
        """
        import json
        info = {"current_app": current_app, **extra_info}
        return json.dumps(info, ensure_ascii=False)
    
    def remove_images_from_message(self, message: MessageDict) -> MessageDict:
        """从消息中移除图片内容以节省上下文空间。
        
        Args:
            message: 消息字典
            
        Returns:
            移除图片后的消息
        """
        if isinstance(message.get("content"), list):
            message["content"] = [
                item for item in message["content"] 
                if item.get("type") == "text"
            ]
        return message
    
    def create_finish_action(self, message: str) -> HandlerAction:
        """创建结束动作。
        
        Args:
            message: 结束消息
            
        Returns:
            结束动作字典
        """
        from ..actions.definitions import ActionBuilder
        return ActionBuilder.finish(message)
    
    def extract_description_from_thinking(
        self, 
        thinking: str
    ) -> tuple[Optional[str], Optional[Dict[str, int]]]:
        """从思考内容中提取操作描述。
        
        默认实现返回 None，子类可以重写此方法以提供自定义的描述提取逻辑。
        
        Args:
            thinking: 模型的思考内容
            
        Returns:
            (操作描述, token 消耗信息) 元组
        """
        return None, None
    
    @property
    def supports_vision(self) -> bool:
        """返回该适配器是否支持视觉输入。
        
        Returns:
            是否支持图片输入
        """
        return True
