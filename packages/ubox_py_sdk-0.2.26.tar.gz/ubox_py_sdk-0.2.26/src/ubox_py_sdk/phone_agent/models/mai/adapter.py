"""MAI-UI 模型适配器实现。

本模块实现了 MAI-UI 系列模型的适配器，集成基础导航能力。
MAI-UI 是阿里云的 GUI 智能体模型，专为移动端 UI 理解和操作设计。

动作映射说明：
    MAI 模型输出的动作会被转换为 ActionHandler 支持的格式。
    支持的动作定义参见 ubox_py_sdk.phone_agent.actions.definitions

使用示例:
    ```python
    from ubox_py_sdk.phone_agent import ModelConfig, ModelType, create_adapter
    
    config = AgentModelConfig(
        model=ModelType.MAI_UI_8B,
        models={
            ModelType.MAI_UI_8B: ModelConfig(
                base_url="http://localhost:8000/v1",
                model_name="MAI-UI-8B"
            ),
        }
    )
    adapter = create_adapter(config)
    ```
"""

import json
import re
import time
from typing import Any, Dict, Generator, List, Optional, Tuple

from openai import OpenAI

from ubox_py_sdk.logger import get_logger

from ..base import (
    HandlerAction,
    BaseModelAdapter,
    MessageDict,
    ModelResponse,
)
from ..registry import ModelConfig
from .prompts import SYSTEM_PROMPT, EXTRACT_DESC_PROMPT

# 导入动作定义，用于映射 MAI 动作到 ActionHandler 动作
from ...actions.definitions import (
    ActionType,
    HandlerAction,
    ActionBuilder,
    SUPPORTED_ACTION_NAMES,
    is_action_supported,
    map_action_name,
)

logger = get_logger("ubox_py_sdk.phone_agent.models.mai")

# MAI 使用 0-999 坐标系统
SCALE_FACTOR = 999

# MAI 动作到 ActionHandler 动作类型的映射表
# 使用 ActionType 枚举保证类型安全
MAI_ACTION_MAPPING: Dict[str, ActionType | str] = {
    # 点击类
    "click": ActionType.TAP,
    "double_click": ActionType.DOUBLE_TAP,
    "long_press": ActionType.LONG_PRESS,

    # 滑动类
    "swipe": ActionType.SWIPE,
    "drag": ActionType.DRAG,
    "pinch": ActionType.PINCH,

    # 输入类
    "type": ActionType.TYPE,

    # 系统按键（特殊处理）
    "system_button": "_system_button",

    # 应用管理
    "open": ActionType.LAUNCH,

    # 等待
    "wait": ActionType.WAIT,

    # 结束类（特殊处理）
    "terminate": "_finish",
    "answer": "_finish",
}


class MAIAdapter(BaseModelAdapter):
    """MAI-UI 模型适配器。
    
    专门针对 MAI-UI 系列模型优化的适配器，集成基础导航能力，支持：
    - 视觉输入（截图）
    - 流式输出
    - 思考过程和动作分离
    - 0-999 相对坐标系统（转换到 0-1000 供 ActionHandler 使用）
    
    支持的动作类型（适配 ActionHandler）：
    - Tap: 点击
    - Double Tap: 双击
    - Long Press: 长按
    - Swipe: 滑动
    - Type: 输入文本
    - Back: 返回键
    - Home: 主页键
    - Launch: 启动应用
    - Wait: 等待
    - finish: 结束任务
    
    Attributes:
        client: OpenAI 客户端实例
    """

    def __init__(self, config: Optional[ModelConfig] = None):
        """初始化 MAI 适配器。
        
        Args:
            config: 模型配置，如果为 None 则使用默认配置
        """
        if config is None:
            config = ModelConfig(model_name="MAI-UI-8B")
        super().__init__(config)
        self.client = OpenAI(
            base_url=self.config.base_url,
            api_key=self.config.api_key
        )

    @property
    def name(self) -> str:
        """返回适配器名称。"""
        return "MAI-UI"

    def get_system_prompt(self) -> str:
        """获取 MAI 模型的系统提示词。"""
        return SYSTEM_PROMPT

    def request_stream(
            self,
            messages: List[MessageDict]
    ) -> Generator[str, None, None]:
        """向 MAI 模型发送流式请求。
        
        Args:
            messages: 消息列表
            
        Yields:
            思考过程的文本块
        """
        start_time = time.time()
        time_to_first_token = None
        time_to_thinking_end = None
        first_token_received = False

        # MAI 特有的请求参数
        extra_body = {
            "repetition_penalty": 1.0,
            "top_k": self.config.extra_body.get("top_k", 0),
            **self.config.extra_body
        }

        stream = self.client.chat.completions.create(
            messages=messages,
            model=self.config.model_name,
            max_tokens=self.config.max_tokens,
            temperature=self.config.temperature,
            top_p=self.config.top_p,
            frequency_penalty=self.config.frequency_penalty,
            extra_body=extra_body,
            stream=True,
        )

        raw_content = ""
        pattern_buffer = ""  # 缓存可能是标签或特殊前缀的部分
        in_action_phase = False
        usage_info = None
        
        # 需要过滤的标签列表（完全丢弃）
        tags_to_filter = [
            "<thinking>", "</thinking>",
            "<think>", "</think>",
            "<tool_call>", "</tool_call>",
            "<answer>", "</answer>",
        ]
        
        # 需要替换的前缀 {匹配内容: 替换为}
        prefixes_to_replace = {
            "Thought: ": "💭",
            "Thought:": "💭",
        }
        
        # 合并所有需要检测的模式
        all_patterns = tags_to_filter + list(prefixes_to_replace.keys())

        for chunk in stream:
            if hasattr(chunk, 'usage') and chunk.usage is not None:
                usage_info = chunk.usage

            if len(chunk.choices) == 0:
                continue
            if chunk.choices[0].delta.content is not None:
                content = chunk.choices[0].delta.content
                raw_content += content

                if not first_token_received:
                    time_to_first_token = time.time() - start_time
                    first_token_received = True

                if in_action_phase:
                    continue

                # 逐字符处理，实现流式模式过滤/替换
                for char in content:
                    if pattern_buffer:
                        # 正在缓存可能的模式
                        pattern_buffer += char
                        
                        # 检查是否完整匹配某个标签（需要丢弃）
                        if pattern_buffer in tags_to_filter:
                            if pattern_buffer == "<tool_call>":
                                # 进入 action 阶段，停止输出
                                in_action_phase = True
                                if time_to_thinking_end is None:
                                    time_to_thinking_end = time.time() - start_time
                            pattern_buffer = ""
                            continue
                        
                        # 检查是否完整匹配某个需要替换的前缀
                        if pattern_buffer in prefixes_to_replace:
                            yield prefixes_to_replace[pattern_buffer]
                            pattern_buffer = ""
                            continue
                        
                        # 检查是否仍是某个模式的前缀
                        is_prefix = False
                        for pattern in all_patterns:
                            if pattern.startswith(pattern_buffer):
                                is_prefix = True
                                break
                        
                        if not is_prefix:
                            # 不是任何模式的前缀，输出缓冲内容
                            yield pattern_buffer
                            pattern_buffer = ""
                    else:
                        # 没有在缓存模式，检查是否是某个模式的开始字符
                        is_pattern_start = False
                        for pattern in all_patterns:
                            if pattern.startswith(char):
                                is_pattern_start = True
                                break
                        
                        if is_pattern_start:
                            # 开始缓存可能的模式
                            pattern_buffer = char
                        else:
                            # 普通字符，直接输出
                            yield char

        total_time = time.time() - start_time

        thinking, action = self._parse_response(raw_content)

        # 提取 token 使用信息
        prompt_tokens = None
        completion_tokens = None
        total_tokens = None
        if usage_info:
            prompt_tokens = getattr(usage_info, 'prompt_tokens', None)
            completion_tokens = getattr(usage_info, 'completion_tokens', None)
            total_tokens = getattr(usage_info, 'total_tokens', None)

        self._last_response = ModelResponse(
            thinking=thinking,
            action=action,
            raw_content=raw_content,
            time_to_first_token=time_to_first_token,
            time_to_thinking_end=time_to_thinking_end,
            total_time=total_time,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            total_tokens=total_tokens,
        )

        logger.debug("")
        logger.debug("=" * 50)
        logger.debug("⏱️  性能指标:")
        logger.debug("-" * 50)
        if time_to_first_token is not None:
            logger.debug(f"首 Token 延迟 (TTFT): {time_to_first_token:.3f}s")
        if time_to_thinking_end is not None:
            logger.debug(f"思考完成延迟:        {time_to_thinking_end:.3f}s")
        logger.debug(f"总推理时间:          {total_time:.3f}s")
        if total_tokens is not None:
            logger.debug("")
            logger.debug("📊 Token统计:")
            logger.debug("-" * 50)
            if prompt_tokens is not None:
                logger.debug(f"输入 Token:          {prompt_tokens}")
            if completion_tokens is not None:
                logger.debug(f"输出 Token:          {completion_tokens}")
            if total_tokens is not None:
                logger.debug(f"总 Token:            {total_tokens}")
        logger.debug("=" * 50)

    def get_last_response(self) -> Optional[ModelResponse]:
        """获取最后一次请求的完整响应。"""
        return self._last_response

    def parse_action(self, response: str) -> HandlerAction:
        """解析 MAI 模型输出的动作。
        
        MAI 使用 JSON 格式的 tool_call：
        {"name": "mobile_use", "arguments": {"action": "click", "coordinate": [x, y]}}
        
        返回格式适配 ActionHandler，坐标使用 0-1000 范围。
        
        Args:
            response: 模型响应中的动作部分
            
        Returns:
            解析后的动作字典，格式符合 ActionHandler 要求
            
        Raises:
            ValueError: 如果动作无法解析
        """
        try:
            response = response.strip()

            # 尝试提取 tool_call 标签内容
            tool_call_match = re.search(r'<tool_call>(.*?)</tool_call>', response, re.DOTALL)
            if tool_call_match:
                response = tool_call_match.group(1).strip()

            # 解析 JSON
            try:
                tool_call = json.loads(response)
            except json.JSONDecodeError:
                # 如果直接解析失败，尝试查找 JSON 对象
                json_match = re.search(r'\{.*\}', response, re.DOTALL)
                if json_match:
                    tool_call = json.loads(json_match.group())
                else:
                    raise ValueError(f"无法解析 JSON: {response}")

            # 提取 arguments
            if "arguments" in tool_call:
                action = tool_call["arguments"]
            else:
                action = tool_call

            # 转换为 ActionHandler 格式
            return self._convert_to_handler_action(action)

        except Exception as e:
            raise ValueError(f"解析动作失败: {e}")

    def _convert_to_handler_action(self, mai_action: Dict[str, Any]) -> HandlerAction:
        """将 MAI 动作格式转换为 ActionHandler 格式。
        
        使用 MAI_ACTION_MAPPING 映射表和 ActionBuilder 将 MAI 动作转换为 ActionHandler 支持的动作。
        
        Args:
            mai_action: MAI 格式的动作字典
            
        Returns:
            HandlerAction 格式的动作字典
        """
        mai_action_type = mai_action.get("action", "")

        # 通过映射表获取 ActionHandler 动作类型
        handler_action = MAI_ACTION_MAPPING.get(mai_action_type)

        # ============================================
        # 1. 结束任务类动作（_finish）
        # ============================================
        if handler_action == "_finish":
            if mai_action_type == "terminate":
                status = mai_action.get("status", "success")
                return ActionBuilder.finish(f"任务{'完成' if status == 'success' else '失败'}")
            elif mai_action_type == "answer":
                return ActionBuilder.finish(mai_action.get("text", ""))

        # ============================================
        # 2. 系统按键类动作（_system_button）
        # ============================================
        if handler_action == "_system_button":
            button = mai_action.get("button", "back")
            if button == "home":
                return ActionBuilder.home()
            else:
                # back, menu 等都映射到 back
                return ActionBuilder.back()

        # ============================================
        # 3. 已知动作类型，使用 ActionBuilder 构建
        # ============================================
        if isinstance(handler_action, ActionType):
            action_type = handler_action

            # 点击类动作
            if action_type == ActionType.TAP:
                if "coordinate" in mai_action:
                    x, y = mai_action["coordinate"]
                    return ActionBuilder.tap(x, y)
                raise ValueError("点击动作缺少坐标")

            if action_type == ActionType.DOUBLE_TAP:
                if "coordinate" in mai_action:
                    x, y = mai_action["coordinate"]
                    return ActionBuilder.double_tap(x, y)
                raise ValueError("双击动作缺少坐标")

            if action_type == ActionType.LONG_PRESS:
                if "coordinate" in mai_action:
                    x, y = mai_action["coordinate"]
                    return ActionBuilder.long_press(x, y)
                raise ValueError("长按动作缺少坐标")

            # 滑动动作
            if action_type == ActionType.SWIPE:
                if "start_coordinate" in mai_action and "end_coordinate" in mai_action:
                    start = mai_action["start_coordinate"]
                    end = mai_action["end_coordinate"]
                    return ActionBuilder.swipe(tuple(start), tuple(end))
                raise ValueError("滑动动作缺少起止坐标")
            
            # 缩放动作：入参为中心点 center（或 coordinate），代码内自动生成安全矩形和默认方向
            if action_type == ActionType.PINCH:
                center = mai_action.get("center") or mai_action.get("coordinate")
                if not center:
                    raise ValueError("缩放动作缺少 center 或 coordinate 参数")
                scale = mai_action.get("scale", 1.5)
                # 方向和矩形大小一律走 ActionHandler 默认策略
                return ActionBuilder.pinch(center=center, scale=scale)
            
            # 拖动动作
            if action_type == ActionType.DRAG:
                if "start_coordinate" in mai_action and "end_coordinate" in mai_action:
                    start = mai_action["start_coordinate"]
                    end = mai_action["end_coordinate"]
                    return ActionBuilder.drag(tuple(start), tuple(end))
                raise ValueError("滑动动作缺少起止坐标")

            # 输入动作
            if action_type == ActionType.TYPE:
                text = mai_action.get("text", "")
                return ActionBuilder.type_text(text)

            # 启动应用动作
            if action_type == ActionType.LAUNCH:
                app = mai_action.get("text", "")
                return ActionBuilder.launch(app)

            # 等待动作
            if action_type == ActionType.WAIT:
                duration = mai_action.get("duration", 1)
                return ActionBuilder.wait(f"{duration} seconds")

            # 其他动作（无参数）
            if action_type == ActionType.BACK:
                return ActionBuilder.back()
            if action_type == ActionType.HOME:
                return ActionBuilder.home()

        # ============================================
        # 4. 未知动作类型，尝试通用映射
        # ============================================
        mapped = map_action_name(mai_action_type)
        if mapped is not None and is_action_supported(mapped.value):
            logger.info(f"MAI 动作 '{mai_action_type}' 通过通用映射转换为 '{mapped.value}'")
            # 更新动作类型后重新转换
            mai_action_copy = mai_action.copy()
            # 找到对应的 MAI 动作名称
            for mai_name, action_type in MAI_ACTION_MAPPING.items():
                if action_type == mapped:
                    mai_action_copy["action"] = mai_name
                    return self._convert_to_handler_action(mai_action_copy)

        # 无法映射，记录警告
        logger.warning(
            f"未知的 MAI 动作类型: '{mai_action_type}'，"
            f"支持的动作: {SUPPORTED_ACTION_NAMES}"
        )
        return {
            "_metadata": "do",
            "action": mai_action_type,
            **{k: v for k, v in mai_action.items() if k != "action"},
        }

    def build_user_message(
            self,
            text: str,
            image_base64: Optional[str] = None,
            mime_type: str = "image/png"
    ) -> MessageDict:
        """构建用户消息。
        
        Args:
            text: 文本内容
            image_base64: 可选的 base64 编码图片
            mime_type: 图片的 MIME 类型，默认为 "image/png"
            
        Returns:
            用户消息字典
        """
        content = []

        if image_base64:
            content.append({
                "type": "image_url",
                "image_url": {"url": f"data:{mime_type};base64,{image_base64}"},
            })

        content.append({"type": "text", "text": text})

        return {"role": "user", "content": content}

    def build_assistant_message(
            self,
            thinking: str,
            action: str
    ) -> MessageDict:
        """构建助手消息。
        
        MAI 使用 <thinking>...</thinking><tool_call>...</tool_call> 格式。
        
        Args:
            thinking: 思考过程
            action: 执行的动作（JSON 字符串）
            
        Returns:
            助手消息字典
        """
        content = f"<thinking>\n{thinking}\n</thinking>\n<tool_call>\n{action}\n</tool_call>"
        return {"role": "assistant", "content": content}

    def _parse_response(self, content: str) -> Tuple[str, str]:
        """将模型响应解析为思考和动作部分。
        
        Args:
            content: 原始响应内容
            
        Returns:
            (思考, 动作) 元组
        """
        thinking = ""
        action = ""

        # 处理思考模型输出格式（使用 <think> 而不是 <thinking>）
        if "<think>" in content and "<thinking>" not in content:
            content = content.replace("<think>", "<thinking>")
            content = content.replace("</think>", "</thinking>")

        # 提取 thinking
        thinking_match = re.search(r'<thinking>(.*?)</thinking>', content, re.DOTALL)
        if thinking_match:
            thinking = thinking_match.group(1).strip()

        # 提取 tool_call
        tool_call_match = re.search(r'<tool_call>(.*?)</tool_call>', content, re.DOTALL)
        if tool_call_match:
            action = tool_call_match.group(1).strip()

        return thinking, action

    def extract_description_from_thinking(
            self,
            thinking: str
    ) -> Tuple[Optional[str], Optional[Dict[str, int]]]:
        """从思考内容中提取操作描述。
        
        使用模型进行简短描述提取，比规则提取更灵活准确。
        
        Args:
            thinking: 模型的思考内容
            
        Returns:
            (操作描述, token 消耗信息) 元组
        """
        if not thinking or not thinking.strip():
            return None, None

        try:
            prompt = EXTRACT_DESC_PROMPT.format(thinking=thinking.strip())

            response = self.client.chat.completions.create(
                messages=[{"role": "user", "content": prompt}],
                model=self.config.model_name,
                max_tokens=50,
                temperature=0.0,
                stream=False,
            )

            # 提取 token 统计
            token_info = self._extract_token_info(response)

            # 解析并清理描述
            desc = self._parse_description(response)

            return desc, token_info

        except Exception as e:
            logger.warning(f"使用模型提取描述失败: {e}")
            return None, None

    def _extract_token_info(self, response) -> Optional[Dict[str, int]]:
        """从响应中提取 token 统计信息。"""
        if not hasattr(response, 'usage') or not response.usage:
            return None

        return {
            "prompt_tokens": getattr(response.usage, 'prompt_tokens', None),
            "completion_tokens": getattr(response.usage, 'completion_tokens', None),
            "total_tokens": getattr(response.usage, 'total_tokens', None),
        }

    def _parse_description(self, response) -> Optional[str]:
        """解析并清理模型返回的描述。"""
        if not response.choices or len(response.choices) == 0:
            return None

        desc = response.choices[0].message.content
        if not desc:
            return None

        desc = desc.strip()

        # 清理常见前缀
        prefixes_to_remove = ["操作描述：", "操作描述:", "描述：", "描述:"]
        for prefix in prefixes_to_remove:
            if desc.startswith(prefix):
                desc = desc[len(prefix):].strip()

        # 取第一行（避免多行输出）
        desc = desc.split('\n')[0].strip()

        # 清理末尾标点
        desc = desc.rstrip('。.，,')

        # 校验长度
        if desc and 3 <= len(desc) <= 50:
            return desc

        return None
