#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
设备列表示例 - 展示如何使用新的模型类

此示例展示了如何使用PhonePlatform枚举和DeviceListRequest/DeviceListResponse模型
来获取设备列表。
"""

import sys
import os
from venv import create

from ubox_py_sdk import create_device

# 添加项目根目录到Python路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from src.ubox_py_sdk.client import UBox, connect_device
from src.ubox_py_sdk.models import PhonePlatform, ConnectionInfo, OSType
from src.ubox_py_sdk.exceptions import UBoxError
from config import get_ubox_config


def main():
    try:
        # 从配置文件获取UBox配置
        ubox_config = get_ubox_config()

        with UBox(
                secret_id=ubox_config.get('secret_id'),
                secret_key=ubox_config.get('secret_key'),
                env=ubox_config.get('env'),
        ) as ubox:
            try:
                android_devices = ubox.device_list(
                    page_num=1,
                    page_size=1000,
                )
                print(f"   找到 {android_devices.total} 台Android设备")
                for device in android_devices.list[:3]:  # 只显示前3台
                    print(f"   - {device.manufacturer} {device.modelKind} (udid: {device.udid})")
            except UBoxError as e:
                print(f"   获取Android设备失败: {e}")
    except Exception as e:
        print(f"演示过程中发生错误: {e}")


def main_cli():
    try:
        # device_1 = connect_device(udid="xxx", os_type=OSType.ANDROID, auth_token='xxx')
        # connection_info = device_1.connection_info
        # print(connection_info)

        connection_info = ConnectionInfo(
            udid="f91e8b66",
            os_type=OSType.ANDROID,
            target_url="http://127.0.0.1:26000",
            use_proxy=False,
            auth_code="xxx"
        )
        device_2 = create_device(connection_info=connection_info, auth_token="xxx")
        device_2.slide_pos(pos_from=(0.2,0.5),pos_to=(0.8,0.5),slide_duration=0.05)
        device_2.release()
    except Exception as e:
        print(f"演示过程中发生错误: {e}")


if __name__ == "__main__":
    exit(main_cli())
    # exit(main())
