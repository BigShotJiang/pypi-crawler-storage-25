#!/usr/bin/env python3
"""
LLM 模型性能评测脚本
支持：响应速度、并发性能、资源监控、测试报告生成
"""

import argparse
import asyncio
import json
import os
import statistics
import time
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional
import aiohttp


@dataclass
class RequestResult:
    """单个请求结果"""
    success: bool
    ttft: Optional[float] = None  # Time To First Token (ms)
    total_time: Optional[float] = None  # 端到端时间 (ms)
    input_tokens: int = 0
    output_tokens: int = 0
    tps: Optional[float] = None  # Tokens Per Second
    error: Optional[str] = None
    response_length: int = 0


@dataclass
class BenchmarkConfig:
    """测试配置"""
    api_url: str
    api_key: str = ""
    model: str = "default"
    max_concurrent: int = 16
    num_requests: int = 100
    timeout: float = 120.0
    test_prompt: str = "请用200字左右介绍一下人工智能的发展历程。"
    warmup_requests: int = 3
    output_dir: str = "./reports"


@dataclass
class BenchmarkResult:
    """测试结果汇总"""
    test_name: str
    start_time: str
    end_time: str
    total_requests: int = 0
    successful_requests: int = 0
    failed_requests: int = 0

    # 响应时间统计 (ms)
    ttft_p50: Optional[float] = None
    ttft_p90: Optional[float] = None
    ttft_p99: Optional[float] = None
    ttft_avg: Optional[float] = None

    total_time_p50: Optional[float] = None
    total_time_p90: Optional[float] = None
    total_time_p99: Optional[float] = None
    total_time_avg: Optional[float] = None

    # Token 统计
    tps_avg: Optional[float] = None
    tps_p50: Optional[float] = None
    input_tokens_avg: Optional[float] = None
    output_tokens_avg: Optional[float] = None

    # 并发统计
    concurrent_level: int = 1
    qps: Optional[float] = None

    # 错误统计
    error_rate: float = 0.0
    errors: list = field(default_factory=list)

    # 单次请求明细（可选，仅对基准测试和最后一档并发测试进行填充）
    per_request_ttft: list[Optional[float]] = field(default_factory=list)
    per_request_total_time: list[Optional[float]] = field(default_factory=list)

    def to_dict(self):
        return {
            "test_name": self.test_name,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "total_requests": self.total_requests,
            "successful_requests": self.successful_requests,
            "failed_requests": self.failed_requests,
            "ttft_ms": {
                "avg": round(self.ttft_avg, 2) if self.ttft_avg else None,
                "p50": round(self.ttft_p50, 2) if self.ttft_p50 else None,
                "p90": round(self.ttft_p90, 2) if self.ttft_p90 else None,
                "p99": round(self.ttft_p99, 2) if self.ttft_p99 else None,
            },
            "total_time_ms": {
                "avg": round(self.total_time_avg, 2) if self.total_time_avg else None,
                "p50": round(self.total_time_p50, 2) if self.total_time_p50 else None,
                "p90": round(self.total_time_p90, 2) if self.total_time_p90 else None,
                "p99": round(self.total_time_p99, 2) if self.total_time_p99 else None,
            },
            "tokens": {
                "tps_avg": round(self.tps_avg, 2) if self.tps_avg else None,
                "tps_p50": round(self.tps_p50, 2) if self.tps_p50 else None,
                "input_avg": round(self.input_tokens_avg, 2) if self.input_tokens_avg else None,
                "output_avg": round(self.output_tokens_avg, 2) if self.output_tokens_avg else None,
            },
            "concurrent": {
                "level": self.concurrent_level,
                "qps": round(self.qps, 2) if self.qps else None,
            },
            "error_rate": round(self.error_rate, 4),
            "errors": self.errors[:10],  # 只保留前10个错误
            # 如果需要在 JSON 中分析单次请求表现，这里会携带每次请求的首 Token 延迟和总时间
            "per_request": {
                "ttft_ms": self.per_request_ttft,
                "total_time_ms": self.per_request_total_time,
            } if self.per_request_ttft or self.per_request_total_time else None,
        }


class LLMBenchmark:
    """LLM 性能测试器"""

    def __init__(self, config: BenchmarkConfig):
        self.config = config
        self.results: list[RequestResult] = []

    async def send_request(self, session: aiohttp.ClientSession, prompt: str) -> RequestResult:
        """发送单个请求并记录结果"""
        headers = {"Content-Type": "application/json"}
        if self.config.api_key:
            headers["Authorization"] = f"Bearer {self.config.api_key}"

        payload = {
            "model": self.config.model,
            "messages": [{"role": "user", "content": prompt}],
            "stream": True,  # 使用流式响应获取 TTFT
            "max_tokens": 512,
        }

        result = RequestResult(success=False)
        start_time = time.time()
        first_token_time = None
        output_tokens = 0
        response_text = ""

        try:
            async with session.post(
                    self.config.api_url,
                    headers=headers,
                    json=payload,
                    timeout=aiohttp.ClientTimeout(total=self.config.timeout)
            ) as response:
                if response.status != 200:
                    result.error = f"HTTP {response.status}: {await response.text()}"
                    return result

                async for line in response.content:
                    if not line:
                        continue

                    line_text = line.decode('utf-8').strip()
                    if line_text.startswith("data: "):
                        data_str = line_text[6:]
                        if data_str == "[DONE]":
                            break
                        try:
                            data = json.loads(data_str)
                            if "choices" in data and data["choices"]:
                                delta = data["choices"][0].get("delta", {})
                                content = delta.get("content", "")
                                if content:
                                    if first_token_time is None:
                                        first_token_time = time.time()
                                        result.ttft = (first_token_time - start_time) * 1000
                                    response_text += content
                                    output_tokens += 1
                        except json.JSONDecodeError:
                            pass

                end_time = time.time()
                result.success = True
                result.total_time = (end_time - start_time) * 1000
                result.output_tokens = output_tokens
                result.response_length = len(response_text)

                if result.total_time and output_tokens > 0:
                    result.tps = output_tokens / (result.total_time / 1000)

        except asyncio.TimeoutError:
            result.error = "Request timeout"
        except Exception as e:
            result.error = str(e)

        return result

    def calculate_percentile(self, values: list[float], percentile: float) -> Optional[float]:
        """计算百分位数"""
        if not values:
            return None
        sorted_values = sorted(values)
        index = int(len(sorted_values) * percentile / 100)
        return sorted_values[min(index, len(sorted_values) - 1)]

    def aggregate_results(self, test_name: str, concurrent_level: int = 1, include_details: bool = False) -> BenchmarkResult:
        """汇总测试结果

        :param test_name: 测试场景名称，如 baseline_test、concurrent_8 等
        :param concurrent_level: 并发级别
        :param include_details: 是否在结果中附带单次请求明细（首 Token 延迟和总时间）
        """
        result = BenchmarkResult(
            test_name=test_name,
            start_time=datetime.now().isoformat(),
            end_time=datetime.now().isoformat(),
            total_requests=len(self.results),
            concurrent_level=concurrent_level,
        )

        successful = [r for r in self.results if r.success]
        failed = [r for r in self.results if not r.success]

        result.successful_requests = len(successful)
        result.failed_requests = len(failed)
        result.error_rate = len(failed) / len(self.results) if self.results else 0
        result.errors = [r.error for r in failed if r.error][:10]

        if not successful:
            return result

        # TTFT 统计
        ttfts = [r.ttft for r in successful if r.ttft is not None]
        if ttfts:
            result.ttft_avg = statistics.mean(ttfts)
            result.ttft_p50 = self.calculate_percentile(ttfts, 50)
            result.ttft_p90 = self.calculate_percentile(ttfts, 90)
            result.ttft_p99 = self.calculate_percentile(ttfts, 99)

        # 总时间统计
        total_times = [r.total_time for r in successful if r.total_time is not None]
        if total_times:
            result.total_time_avg = statistics.mean(total_times)
            result.total_time_p50 = self.calculate_percentile(total_times, 50)
            result.total_time_p90 = self.calculate_percentile(total_times, 90)
            result.total_time_p99 = self.calculate_percentile(total_times, 99)

        # TPS 统计
        tps_values = [r.tps for r in successful if r.tps is not None]
        if tps_values:
            result.tps_avg = statistics.mean(tps_values)
            result.tps_p50 = self.calculate_percentile(tps_values, 50)

        # Token 统计
        input_tokens = [r.input_tokens for r in successful if r.input_tokens > 0]
        output_tokens = [r.output_tokens for r in successful if r.output_tokens > 0]
        if input_tokens:
            result.input_tokens_avg = statistics.mean(input_tokens)
        if output_tokens:
            result.output_tokens_avg = statistics.mean(output_tokens)

        # 如果需要在报告或 JSON 中展示单次请求表现，则保留本轮所有请求的原始 TTFT / 总时间
        if include_details:
            result.per_request_ttft = [r.ttft for r in self.results]
            result.per_request_total_time = [r.total_time for r in self.results]

        # QPS 不再统计，这里保留占位注释方便以后需要时恢复
        # if total_times and concurrent_level > 1:
        #     total_test_time = sum(total_times) / concurrent_level / 1000  # 转换为秒
        #     if total_test_time > 0:
        #         result.qps = len(successful) / total_test_time

        return result

    async def warmup(self, session: aiohttp.ClientSession):
        """预热请求"""
        print(f"🔥 预热中... ({self.config.warmup_requests} requests)")
        for _ in range(self.config.warmup_requests):
            await self.send_request(session, "你好")
            await asyncio.sleep(0.5)
        print("✅ 预热完成")

    async def run_baseline_test(self) -> BenchmarkResult:
        """基准测试 - 串行请求"""
        print("\n📊 开始基准测试...")
        self.results = []

        async with aiohttp.ClientSession() as session:
            await self.warmup(session)

            for i in range(self.config.num_requests):
                print(f"\r  进度: {i + 1}/{self.config.num_requests}", end="", flush=True)
                result = await self.send_request(session, self.config.test_prompt)
                self.results.append(result)
                await asyncio.sleep(0.1)  # 短暂间隔

        # 输出基准测试阶段每一次请求的首 Token 延迟和总耗时，便于细粒度分析单次表现
        print("\n🔎 基准测试单次请求明细:")
        for idx, r in enumerate(self.results, start=1):
            ttft = f"{r.ttft:.1f}ms" if r.ttft is not None else "N/A"
            total = f"{r.total_time:.1f}ms" if r.total_time is not None else "N/A"
            print(f"  请求#{idx}: 首Token延迟={ttft}, 总时间={total}")

        print("\n✅ 基准测试完成")
        # 基准测试总是附带单次请求明细，方便在报告和 JSON 中进一步分析
        return self.aggregate_results("baseline_test", concurrent_level=1, include_details=True)

    async def run_concurrent_test(self, concurrent_levels: list[int] = None) -> list[BenchmarkResult]:
        """并发测试"""
        if concurrent_levels is None:
            concurrent_levels = [2, 4, 8, 16, 24, 32]

        results = []
        # 记录列表中的最后一个并发级别，用于事后输出该轮的单次请求明细
        last_level = concurrent_levels[-1] if concurrent_levels else None

        async with aiohttp.ClientSession() as session:
            await self.warmup(session)

            for level in concurrent_levels:
                if level > self.config.max_concurrent:
                    print(f"⚠️  跳过并发级别 {level}（超过最大限制 {self.config.max_concurrent}）")
                    continue

                print(f"\n📊 并发测试 (concurrency={level})...")
                self.results = []

                semaphore = asyncio.Semaphore(level)

                async def limited_request():
                    async with semaphore:
                        return await self.send_request(session, self.config.test_prompt)

                start_time = time.time()
                tasks = [limited_request() for _ in range(max(self.config.num_requests, level))]
                self.results = await asyncio.gather(*tasks)
                end_time = time.time()

                # 对最后一档并发测试附带单次请求明细，其余并发级别只做聚合统计
                include_details = last_level is not None and level == last_level
                result = self.aggregate_results(
                    f"concurrent_{level}",
                    concurrent_level=level,
                    include_details=include_details,
                )

                ttft_avg_str = f"{result.ttft_avg:.1f}ms" if result.ttft_avg else "N/A"
                tps_avg_str = f"{result.tps_avg:.1f}" if result.tps_avg else "N/A"

                results.append(result)
                print(f"  ✅ 完成: TTFT_avg={ttft_avg_str}, TPS_avg={tps_avg_str}")

                # 如果是本轮并发测试中的最后一个并发级别，则输出这一档下每一次请求的首 Token 延迟和总耗时
                if last_level is not None and level == last_level:
                    print("\n🔎 最后一档并发测试的单次请求明细:\n\n")
                    for idx, r in enumerate(self.results, start=1):
                        ttft = f"{r.ttft:.1f}ms" if r.ttft is not None else "N/A"
                        total = f"{r.total_time:.1f}ms" if r.total_time is not None else "N/A"
                        print(f"  请求#{idx}: 首Token延迟={ttft}, 总时间={total}")

        return results

    async def run_full_test(self, concurrent_levels: list[int] = None) -> list[BenchmarkResult]:
        """完整测试套件"""
        results = []

        # 1. 基准测试
        baseline = await self.run_baseline_test()
        results.append(baseline)

        # 2. 并发测试
        concurrent_results = await self.run_concurrent_test(concurrent_levels)
        results.extend(concurrent_results)

        return results


def generate_report(results: list[BenchmarkResult], output_dir: str) -> str:
    """生成 Markdown 测试报告"""
    os.makedirs(output_dir, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_path = os.path.join(output_dir, f"benchmark_report_{timestamp}.md")

    with open(report_path, "w", encoding="utf-8") as f:
        f.write("# LLM 模型性能评测报告\n\n")
        f.write(f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        f.write("---\n\n")

        # 汇总表格：这里展示首 Token 延迟（含平均值/P90/P99）、总时间分布以及每秒输出 Token 数等关键指标
        f.write("## 📊 测试汇总\n\n")
        f.write(
            "| 测试场景 | 并发数 | 成功率 | 首Token延迟avg(ms) | 首Token延迟P90(ms) | 首Token延迟P99(ms) | 总时间avg(ms) | 总时间P90(ms) | 每秒输出Token数avg(token/s) |\n")
        f.write(
            "|----------|--------|--------|--------------------|--------------------|--------------------|---------------|---------------|---------------------------|\n")

        for r in results:
            success_rate = f"{(1 - r.error_rate) * 100:.1f}%"
            ttft_avg = f"{r.ttft_avg:.1f}" if r.ttft_avg else "N/A"
            ttft_p90 = f"{r.ttft_p90:.1f}" if r.ttft_p90 else "N/A"
            ttft_p99 = f"{r.ttft_p99:.1f}" if r.ttft_p99 else "N/A"
            total_time_avg = f"{r.total_time_avg:.1f}" if r.total_time_avg else "N/A"
            total_time_p90 = f"{r.total_time_p90:.1f}" if r.total_time_p90 else "N/A"
            token_speed_avg = f"{r.tps_avg:.1f}" if r.tps_avg else "N/A"  # 每秒输出 Token 数（token/s）
            f.write(
                f"| {r.test_name} | {r.concurrent_level} | {success_rate} | "
                f"{ttft_avg} | {ttft_p90} | {ttft_p99} | "
                f"{total_time_avg} | {total_time_p90} | {token_speed_avg} |\n"
            )

        f.write("\n---\n\n")

        # 详细结果
        f.write("## 📋 详细结果\n\n")

        for r in results:
            f.write(f"### {r.test_name}\n\n")
            f.write(f"- **并发级别**: {r.concurrent_level}\n")
            f.write(f"- **总请求数**: {r.total_requests}\n")
            f.write(f"- **成功请求**: {r.successful_requests}\n")
            f.write(f"- **失败请求**: {r.failed_requests}\n")
            f.write(f"- **错误率**: {r.error_rate * 100:.2f}%\n\n")

            f.write("**响应时间**:\n")
            f.write(
                f"- TTFT: avg={r.ttft_avg:.1f}ms, P50={r.ttft_p50:.1f}ms, P90={r.ttft_p90:.1f}ms, P99={r.ttft_p99:.1f}ms\n") if r.ttft_avg else f"- TTFT: N/A\n"
            f.write(
                f"- 总时间: avg={r.total_time_avg:.1f}ms, P50={r.total_time_p50:.1f}ms, P90={r.total_time_p90:.1f}ms, P99={r.total_time_p99:.1f}ms\n\n") if r.total_time_avg else f"- 总时间: N/A\n\n"

            # Token 统计中的「每秒输出 Token 数」指的是 token/s，而不是传统压测里的 QPS
            f.write("**Token 统计**:\n")
            if r.tps_avg:
                f.write(f"- 每秒输出 Token 数(avg): {r.tps_avg:.1f}")
                if r.tps_p50:
                    f.write(f", P50: {r.tps_p50:.1f}\n")
                else:
                    f.write("\n")
            else:
                f.write("- 每秒输出 Token 数: N/A\n")
            f.write(
                f"- 平均输出 Token: {r.output_tokens_avg:.1f}\n\n" if r.output_tokens_avg else "- 平均输出 Token: N/A\n\n")

            # 如果当前测试场景附带了单次请求明细（例如基准测试或最后一档并发测试），则在报告中输出每一次请求的首 Token 延迟和总时间
            if r.per_request_ttft or r.per_request_total_time:
                f.write("**单次请求明细（首Token延迟 / 总时间）**:\n\n")
                f.write("| 序号 | 首Token延迟(ms) | 总时间(ms) |\n")
                f.write("|------|-----------------|------------|\n")
                length = max(len(r.per_request_ttft), len(r.per_request_total_time))
                for idx in range(length):
                    ttft_val = r.per_request_ttft[idx] if idx < len(r.per_request_ttft) else None
                    total_val = r.per_request_total_time[idx] if idx < len(r.per_request_total_time) else None
                    ttft_str = f"{ttft_val:.1f}" if ttft_val is not None else "N/A"
                    total_str = f"{total_val:.1f}" if total_val is not None else "N/A"
                    f.write(f"| {idx + 1} | {ttft_str} | {total_str} |\n")
                f.write("\n")

            if r.errors:
                f.write("**错误示例**:\n")
                for err in r.errors[:3]:
                    f.write(f"- {err}\n")
                f.write("\n")

            f.write("---\n\n")

        # 结论与建议
        f.write("## 💡 基于基线单并发分析结论与建议\n\n")

        baseline = results[0] if results else None
        if baseline and baseline.ttft_avg:
            if baseline.ttft_avg < 500:
                f.write("- ✅ **TTFT 表现优秀** (<500ms)，用户体验良好\n")
            elif baseline.ttft_avg < 1000:
                f.write("- ⚠️ **TTFT 表现一般** (500-1000ms)，可考虑优化\n")
            else:
                f.write("- ❌ **TTFT 较慢** (>1000ms)，建议优化模型或硬件\n")

        if baseline and baseline.tps_avg:
            # 这里的「生成速度」使用的是每秒输出 Token 数（token/s），而非请求级别的 QPS
            if baseline.tps_avg > 50:
                f.write("- ✅ **生成速度快** (>50 token/s)，吞吐量表现优秀\n")
            elif baseline.tps_avg > 20:
                f.write("- ⚠️ **生成速度中等** (20-50 token/s)，可接受\n")
            else:
                f.write("- ❌ **生成速度较慢** (<20 token/s)，建议优化\n")

        # 不再基于 QPS 自动推默认「最佳并发数」，避免误导，改由使用者结合延迟/TPS 等维度自行判断
        f.write("\n---\n\n")

    return report_path


async def main():
    parser = argparse.ArgumentParser(description="LLM 模型性能评测工具")
    parser.add_argument("--url", required=True, help="API 地址，如 http://localhost:8000/v1/chat/completions")
    parser.add_argument("--api-key", default="", help="API Key（可选）")
    parser.add_argument("--model", default="default", help="模型名称")
    parser.add_argument("--mode", choices=["baseline", "concurrent", "full"], default="baseline",
                        help="测试模式: baseline(基准), concurrent(并发), full(完整)")
    parser.add_argument("--num-requests", type=int, default=10, help="每种测试的请求数量")
    parser.add_argument("--max-concurrent", type=int, default=32, help="最大并发数")
    parser.add_argument("--concurrent-levels", type=str, default="2,4,8,16,24,32",
                        help="并发级别列表，逗号分隔")
    parser.add_argument("--output", default="./reports", help="报告输出目录")
    parser.add_argument("--prompt", default="请用200字左右介绍一下人工智能的发展历程。",
                        help="测试提示词")

    args = parser.parse_args()

    config = BenchmarkConfig(
        api_url=args.url,
        api_key=args.api_key,
        model=args.model,
        max_concurrent=args.max_concurrent,
        num_requests=args.num_requests,
        test_prompt=args.prompt,
        output_dir=args.output,
    )

    benchmark = LLMBenchmark(config)

    print("=" * 60)
    print("🚀 LLM 模型性能评测")
    print("=" * 60)
    print(f"API 地址: {config.api_url}")
    print(f"模型: {config.model}")
    print(f"测试模式: {args.mode}")
    print(f"请求数量: {config.num_requests}")
    print("=" * 60)

    results = []

    if args.mode == "baseline":
        result = await benchmark.run_baseline_test()
        results.append(result)
    elif args.mode == "concurrent":
        levels = [int(x.strip()) for x in args.concurrent_levels.split(",")]
        results = await benchmark.run_concurrent_test(levels)
    elif args.mode == "full":
        levels = [int(x.strip()) for x in args.concurrent_levels.split(",")]
        results = await benchmark.run_full_test(levels)

    # 生成报告
    report_path = generate_report(results, config.output_dir)
    print(f"\n📄 测试报告已生成: {report_path}")

    # 同时输出 JSON 结果
    json_path = report_path.replace(".md", ".json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump([r.to_dict() for r in results], f, ensure_ascii=False, indent=2)
    print(f"📄 JSON 结果: {json_path}")


if __name__ == "__main__":
    asyncio.run(main())
