# 优测 UBox SDK - 完整 API 参考

本文档详细介绍 UBox SDK 暴露的所有公开 API，包括 **UBox 客户端** 和 **Device 设备操作** 两大部分。

---

## 目录

- [一、UBox 客户端 API](#一ubox-客户端-api)
  - [UBox 构造函数](#ubox-构造函数)
  - [init_device - 初始化/占用设备](#init_device---初始化占用设备)
  - [probe_device - 探测设备连通性](#probe_device---探测设备连通性)
  - [device_list - 获取设备列表](#device_list---获取设备列表)
  - [release_all_devices - 释放所有设备](#release_all_devices---释放所有设备)
  - [get_auth_token - 获取认证Token](#get_auth_token---获取认证token)
  - [connect_device - CLI快捷连接](#connect_device---cli快捷连接)
  - [create_device - CLI快捷创建](#create_device---cli快捷创建)
- [二、Device 设备操作 API](#二device-设备操作-api)
  - [设备信息](#设备信息)
  - [基础操作](#基础操作)
  - [智能定位与查找](#智能定位与查找)
  - [截图与录制](#截图与录制)
  - [应用管理](#应用管理)
  - [性能监控](#性能监控)
  - [日志采集](#日志采集logcat)
  - [ANR/Crash监控](#anrcrash监控)
  - [控件树与元素操作](#控件树与元素操作)
  - [剪贴板操作](#剪贴板操作)
  - [网络代理](#网络代理)
  - [文件操作](#文件操作)
  - [事件自动处理（服务端）](#事件自动处理服务端)
  - [事件处理（客户端Watcher）](#事件处理客户端watcher)
  - [AI Agent 探索测试](#ai-agent-探索测试)
  - [设备释放与关闭](#设备释放与关闭)

---

## 一、UBox 客户端 API

### UBox 构造函数

```python
UBox(
    mode: RunMode = RunMode.NORMAL,
    secret_id: str = None,
    secret_key: str = None,
    auth_token: str = None,
    timeout: int = 30,
    verify_ssl: bool = True,
    env: str = "formal",
    log_level: str = "INFO",
    log_format: str = None,
    log_to_file: bool = False,
    log_file_path: str = "ubox/ubox_sdk.log",
    agent_model_config: AgentModelConfig = None,
    agent_config: AgentConfig = None,
)
```

**参数说明：**

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `mode` | `RunMode` | `NORMAL` | 运行模式：`NORMAL`/`LOCAL`/`CLI` |
| `secret_id` | `str` | `None` | Secret ID，正常模式必填（与 `auth_token` 二选一） |
| `secret_key` | `str` | `None` | Secret Key，正常模式必填（与 `auth_token` 二选一） |
| `auth_token` | `str` | `None` | 认证Token，CLI模式必填 |
| `timeout` | `int` | `30` | 请求超时时间（秒） |
| `verify_ssl` | `bool` | `True` | 是否验证SSL证书 |
| `env` | `str` | `"formal"` | 环境：`"formal"` 正式 / `"test"` 测试 |
| `log_level` | `str` | `"INFO"` | 日志级别：`DEBUG`/`INFO`/`WARNING`/`ERROR`/`CRITICAL` |
| `log_to_file` | `bool` | `False` | 是否输出日志到文件 |
| `log_file_path` | `str` | `"ubox/ubox_sdk.log"` | 日志文件路径 |
| `agent_model_config` | `AgentModelConfig` | `None` | AI Agent模型配置 |
| `agent_config` | `AgentConfig` | `None` | AI Agent行为配置 |

**支持上下文管理器：**

```python
with UBox(secret_id="sid", secret_key="skey") as ubox:
    # 退出时自动释放所有设备并关闭连接
    pass
```

---

### init_device - 初始化/占用设备

```python
ubox.init_device(
    udid: str,
    os_type: OSType,
    auth_code: str = None,
    force_proxy: bool = False,
    trace_id: str = None
) -> Device
```

初始化并占用设备，使后续操作针对该设备。

| 参数 | 类型 | 说明 |
|------|------|------|
| `udid` | `str` | 设备唯一标识（序列号） |
| `os_type` | `OSType` | 设备系统类型：`OSType.ANDROID` / `OSType.IOS` / `OSType.HM` |
| `auth_code` | `str` | 可选认证码，提供后跳过设备占用流程 |
| `force_proxy` | `bool` | 是否强制公网代理连接，默认 `False`（自动选择最优路径） |
| `trace_id` | `str` | 可选追踪ID |

**返回值：** `Device` 设备对象

```python
device = ubox.init_device(udid="ABC123", os_type=OSType.ANDROID)
```

---

### probe_device - 探测设备连通性

```python
ubox.probe_device(
    udid: str,
    os_type: OSType,
    force_proxy: bool = False,
    trace_id: str = None
) -> bool
```

探测设备是否可连接，**不会占用设备**，探测完成后自动释放。

**返回值：** `bool` - 设备是否可连接

```python
if ubox.probe_device(udid="ABC123", os_type=OSType.ANDROID):
    print("设备可用")
```

---

### device_list - 获取设备列表

```python
ubox.device_list(
    page_num: int = 1,
    page_size: int = 20,
    phone_platform: List[PhonePlatform] = None,
    manufacturers: List[str] = None,
    online_status: int = 1,
    resolution_ratios: List[str] = None,
    extra_filters: Dict[str, Any] = None,
    **more_filters
) -> DeviceListData
```

获取设备列表，支持多种过滤条件。

| 参数 | 类型 | 说明 |
|------|------|------|
| `page_num` | `int` | 页码，从1开始 |
| `page_size` | `int` | 每页大小 |
| `phone_platform` | `List[PhonePlatform]` | 平台过滤，如 `[PhonePlatform.ANDROID]` |
| `manufacturers` | `List[str]` | 制造商过滤，如 `["Xiaomi", "Huawei"]` |
| `online_status` | `int` | 在线状态：`1` 在线 / `0` 离线 / `None` 不过滤 |
| `resolution_ratios` | `List[str]` | 分辨率过滤，如 `["1080*2376"]` |
| `extra_filters` | `Dict` | 额外过滤条件（透传到请求体） |

**返回值：** `DeviceListData` 对象，包含 `list`（设备列表）、`total`（总数）、`pageNum`、`pageSize`

```python
result = ubox.device_list(
    phone_platform=[PhonePlatform.ANDROID, PhonePlatform.IOS],
    manufacturers=["Xiaomi"],
    online_status=1
)
for dev in result.list:
    print(f"{dev.udid} - {dev.modelKind} - {dev.osVersion}")
```

---

### release_all_devices - 释放所有设备

```python
ubox.release_all_devices()
```

并发释放所有已初始化的设备。通常不需要手动调用，使用 `with` 语句时会自动释放。

---

### get_auth_token - 获取认证Token

```python
ubox.get_auth_token() -> Optional[str]
```

获取当前有效的认证Token。

---

### connect_device - CLI快捷连接

```python
connect_device(
    udid: str,
    os_type: OSType,
    auth_token: str,
    env: str = "formal",
    force_proxy: bool = False,
    timeout: int = 30,
    log_level: str = "INFO"
) -> Device
```

CLI模式快捷函数，一步连接设备并返回可操作的设备实例。内部自动创建 UBox 客户端。

```python
from ubox_py_sdk import connect_device, OSType

device = connect_device(
    udid="DEVICE_SERIAL",
    os_type=OSType.ANDROID,
    auth_token="your_token"
)
device.click_pos([0.5, 0.5])
```

---

### create_device - CLI快捷创建

```python
create_device(
    connection_info: ConnectionInfo,
    auth_token: str,
    env: str = "formal",
    timeout: int = 30,
    log_level: str = "INFO"
) -> Device
```

用已有的连接信息直接创建设备实例，跳过连接流程。适用于已通过 `connect_device()` 获取过连接信息的场景。

```python
from ubox_py_sdk import connect_device, create_device, OSType

# 首次连接
device = connect_device(udid="xxx", os_type=OSType.ANDROID, auth_token="token")
conn_info = device.connection_info  # 保存连接信息

# 后续复用
device2 = create_device(conn_info, auth_token="token")
```

---

## 二、Device 设备操作 API

通过 `ubox.init_device()` 获取 `Device` 实例后，可调用以下方法操作设备。

---

### 设备信息

#### device_info - 获取设备详细信息

```python
device.device_info(trace_id=None) -> dict
```

返回设备的完整硬件信息，包括屏幕分辨率、CPU、内存、存储等。

```python
info = device.device_info()
print(f"分辨率: {info['display']['width']}x{info['display']['height']}")
print(f"系统版本: {info.get('os_version')}")
print(f"制造商: {info.get('manufacturer')}")
```

**Android 返回示例：**
```json
{
    "display": {"width": 1440, "height": 3200, "rotation": 0},
    "density": {"density": 480},
    "os_version": "13",
    "manufacturer": "meizu",
    "model": "MEIZU 18",
    "cpu": {"cores": 7},
    "memory": {"total": 7377784, "around": "7 GB"},
    "storage": {"total": 114392375296, "available": 21983236096}
}
```

#### screen_size - 获取屏幕分辨率

```python
device.screen_size(trace_id=None) -> List[int]
```

返回设备屏幕的物理分辨率 `[height, width]`。

```python
size = device.screen_size()
print(f"屏幕尺寸: {size[0]}x{size[1]}")
```

#### get_orientation - 获取屏幕方向

```python
device.get_orientation(trace_id=None) -> int
```

返回屏幕旋转角度：`0` / `90` / `180` / `270`。

```python
rotation = device.get_orientation()
print(f"屏幕方向: {rotation}度")
```

#### current_app - 获取当前应用

```python
device.current_app(trace_id=None) -> str
```

返回当前前台应用的包名（Android/鸿蒙）或 Bundle ID（iOS）。

```python
pkg = device.current_app()
print(f"当前应用: {pkg}")
```

#### current_activity - 获取当前Activity

```python
device.current_activity(trace_id=None) -> str
```

> ⚠️ 仅 Android 和鸿蒙设备支持

返回当前 Activity 名称。

```python
activity = device.current_activity()
print(f"当前Activity: {activity}")
```

#### app_list_running - 获取运行中的应用列表

```python
device.app_list_running(trace_id=None) -> list[str]
```

返回正在运行的应用包名列表。

```python
apps = device.app_list_running()
for app in apps:
    print(app)
```

#### app_list_info - 获取所有三方应用信息

```python
device.app_list_info(trace_id=None) -> list
```

返回设备内所有第三方应用的详细信息列表，每个应用包含 `label`（名称）、`packageName`（包名）、`versionName`（版本）等字段。

```python
apps = device.app_list_info()
for app in apps:
    print(f"{app['label']} - {app['packageName']} v{app['versionName']}")
```

---

### 基础操作

#### click_pos - 坐标点击

```python
device.click_pos(
    pos: list,           # 坐标 [x, y]
    duration: float = 0.05,  # 按压时长（秒）
    times: int = 1,      # 点击次数
    trace_id: str = None
) -> bool
```

基于坐标点击，自动识别绝对坐标（像素）和相对坐标（0~1.0）。

```python
# 相对坐标（推荐）
device.click_pos([0.5, 0.5])           # 点击屏幕中心
device.click_pos([0.5, 0.5], times=2)  # 双击
device.click_pos([0.5, 0.5], duration=2)  # 长按2秒

# 绝对坐标
device.click_pos([540, 960])
```

#### slide_pos - 坐标滑动

```python
device.slide_pos(
    pos_from: list,          # 起始坐标 [x, y]
    pos_to: list = None,     # 结束坐标 [x, y]
    down_duration: float = 0,    # 按下时长（实现拖拽）
    slide_duration: float = 0.05,  # 滑动时长
    trace_id: str = None
) -> bool
```

基于坐标滑动，支持绝对坐标和相对坐标混合使用。

```python
# 上滑
device.slide_pos([0.5, 0.8], [0.5, 0.2])

# 左滑
device.slide_pos([0.8, 0.5], [0.2, 0.5])

# 拖拽效果（先按住0.5秒再滑动）
device.slide_pos([0.5, 0.5], [0.5, 0.2], down_duration=0.5)
```

#### click - 智能点击

```python
device.click(
    loc,                     # 定位目标（文字/图片路径/xpath/坐标）
    by=DriverType.UI,        # 定位方式
    offset: list = None,     # 偏移量
    crop_box: list = None,   # 裁剪区域
    timeout: int = 30,       # 超时时间
    duration: float = 0.05,  # 按压时长
    times: int = 1,          # 点击次数
    use_ai: bool = False,    # 是否使用AI定位
    threshold: float = 0.7,  # 匹配阈值
    trace_id: str = None,
    **kwargs
) -> bool
```

支持多种定位方式的智能点击：

| `by` 值 | 说明 | `loc` 格式 |
|----------|------|-----------|
| `DriverType.UI` (1) | UI控件定位 | XPath 表达式 |
| `DriverType.OCR` (2) | OCR文字识别 | 目标文字 |
| `DriverType.CV` (3) | 图像匹配 | 模板图片路径 |
| `DriverType.POS` (0) | 坐标定位 | `[x, y]` 坐标 |
| `DriverType.GA_UNITY` (5) | GA Unity | 控件标识 |
| `DriverType.GA_UE` (6) | GA UE | 控件标识 |

```python
# UI控件点击
device.click("//*[@text='登录']", by=DriverType.UI)

# OCR文字点击
device.click("确定", by=DriverType.OCR)

# 图像匹配点击
device.click("./templates/icon.png", by=DriverType.CV)

# 使用AI增强的OCR点击
device.click("确定", by=DriverType.OCR, use_ai=True, threshold=0.8)

# 坐标点击
device.click([0.5, 0.5], by=DriverType.POS)
```

#### long_click - 长按

```python
device.long_click(
    loc,
    by=DriverType.UI,
    offset: list = None,
    timeout: int = 30,
    trace_id: str = None,
    **kwargs
) -> bool
```

长按操作，参数与 `click` 类似。

```python
device.long_click("//*[@text='文件']", by=DriverType.UI)
```

#### slide - 智能滑动

```python
device.slide(
    loc_from,
    loc_to=None,
    by=DriverType.UI,
    trace_id: str = None,
    **kwargs
) -> bool
```

基于多种定位方式的滑动操作。

```python
device.slide("//*[@text='起点']", "//*[@text='终点']", by=DriverType.UI)
```

#### input_text - 文本输入

```python
device.input_text(
    text: str,
    timeout: int = 30,
    depth: int = 10,
    trace_id: str = None
) -> bool
```

向当前焦点输入框输入文本。

```python
device.input_text("Hello World")
```

#### press - 按键操作

```python
device.press(name: DeviceButton, trace_id: str = None) -> bool
```

模拟物理按键操作。

**DeviceButton 常用按键：**

| 按键 | 值 | 说明 |
|------|-----|------|
| `DeviceButton.HOME` | 3 | Home键 |
| `DeviceButton.BACK` | 4 | 返回键（Android） |
| `DeviceButton.VOLUME_UP` | 24 | 音量+ |
| `DeviceButton.VOLUME_DOWN` | 25 | 音量- |
| `DeviceButton.POWER` | 26 | 电源键（Android） |
| `DeviceButton.ENTER` | 13 | 回车键 |
| `DeviceButton.SPACE` | 32 | 空格键 |
| `DeviceButton.DELETE` | 46 | 删除键 |
| `DeviceButton.DEL` | 67 | 退格键（Android） |
| `DeviceButton.MENU` | 82 | 菜单键（Android） |
| `DeviceButton.RECENT_APP` | 187 | 最近任务（Android） |
| `DeviceButton.LOCK` | 1000 | 锁屏（iOS） |
| `DeviceButton.UNLOCK` | 1001 | 解锁（iOS） |

```python
device.press(DeviceButton.HOME)
device.press(DeviceButton.BACK)
device.press(DeviceButton.VOLUME_UP)
```

#### pinch - 双指缩放

```python
device.pinch(
    rect: list,              # 缩放区域 [x, y, w, h]（相对坐标 0~1.0）
    scale: float,            # 缩放倍数（<1.0 缩小，>1.0 放大，最大2.0）
    direction: PinchDirection,  # 缩放方向
    trace_id: str = None
) -> bool
```

**PinchDirection 枚举：**
- `PinchDirection.HORIZONTAL` - 水平方向
- `PinchDirection.VERTICAL` - 垂直方向
- `PinchDirection.DIAGONAL` - 对角线方向

```python
from ubox_py_sdk import PinchDirection

# 水平放大
device.pinch(rect=[0.3, 0.3, 0.4, 0.4], scale=1.5, direction=PinchDirection.HORIZONTAL)

# 垂直缩小
device.pinch(rect=[0.3, 0.3, 0.4, 0.4], scale=0.8, direction="vertical")

# 对角线放大到最大
device.pinch(rect=[0.25, 0.25, 0.5, 0.5], scale=2.0, direction="diagonal")
```

#### cmd_adb - 执行ADB命令

```python
device.cmd_adb(
    cmd: Union[str, list],
    timeout: int = 10,
    trace_id: str = None
) -> Union[tuple[str, int], str]
```

执行 ADB/HDC 命令。

- Android 返回 `(output, exit_code)` 元组
- 鸿蒙返回 `output` 字符串

```python
# 获取设备属性
output, code = device.cmd_adb("getprop ro.product.model")
print(f"设备型号: {output}")

# 列出文件
output, code = device.cmd_adb("ls /sdcard/")
```

---

### 智能定位与查找

#### find_cv - 图像匹配查找

```python
device.find_cv(
    tpl,                     # 模板图像（路径或ndarray）
    img=None,                # 搜索图像（None则使用当前屏幕）
    timeout: int = 30,       # 超时时间
    threshold: float = 0.7,  # 匹配阈值
    pos=None,                # 辅助定位坐标
    pos_weight: float = 0.05,
    ratio_lv: int = 21,      # 缩放范围
    is_translucent: bool = False,  # 是否半透明
    to_gray: bool = False,   # 是否灰度匹配
    tpl_l=None,              # 备选大尺寸模板
    deviation=None,          # 偏差
    time_interval: float = 0.5,  # 循环间隔
    use_ai: bool = False,    # 是否使用AI服务
    trace_id: str = None
) -> Any
```

基于多尺寸模板匹配的图像查找，返回匹配位置的中心坐标，未找到返回 `None`。

```python
# 基础用法
center = device.find_cv("./templates/button.png")
if center:
    print(f"找到目标: {center}")

# 使用AI增强
center = device.find_cv("./templates/icon.png", use_ai=True, threshold=0.8)

# 指定搜索区域和灰度匹配
center = device.find_cv("./tpl.png", to_gray=True, timeout=10)
```

#### find_ocr - OCR文字查找

```python
device.find_ocr(
    word: str,               # 目标文字
    left_word: str = None,   # 左侧辅助文字
    right_word: str = None,  # 右侧辅助文字
    timeout: int = 30,
    time_interval: float = 0.5,
    use_ai: bool = False,    # 是否使用AI服务
    threshold: float = 0.7,
    trace_id: str = None
) -> Any
```

基于 OCR 文字识别查找，返回文字中心坐标。

```python
# 查找文字
center = device.find_ocr("确定")

# 使用AI增强OCR
center = device.find_ocr("登录", use_ai=True, threshold=0.8)

# 使用左右文字辅助定位
center = device.find_ocr("价格", left_word="商品", right_word="元")
```

#### find_ui - UI控件查找

```python
device.find_ui(
    xpath: str,
    timeout: int = 30,
    trace_id: str = None,
    **kwargs
) -> Any
```

基于 XPath 的 UI 控件查找，返回控件中心坐标。

```python
center = device.find_ui("//*[@text='确定']")
center = device.find_ui("//*[@resource-id='com.example:id/btn']", timeout=10)
```

#### find - 通用查找

```python
device.find(
    loc,
    by=DriverType.UI,
    timeout: int = 30,
    trace_id: str = None,
    **kwargs
) -> Any
```

通用查找接口，根据 `by` 参数自动选择查找方式。

```python
center = device.find("确定", by=DriverType.OCR)
center = device.find("//*[@text='登录']", by=DriverType.UI)
center = device.find("./icon.png", by=DriverType.CV)
```

#### multi_find - 综合查找

```python
device.multi_find(
    ctrl: str = "",
    img=None,
    pos=None,
    by=DriverType.UI,
    ctrl_timeout: int = 30,
    img_timeout: int = 10,
    trace_id: str = None,
    **kwargs
) -> Any
```

综合查找：优先控件定位 → 图像匹配 → 坐标定位。

```python
result = device.multi_find(
    ctrl="//*[@text='确定']",
    img="./button.png",
    pos=[0.5, 0.5]
)
```

#### get_element_cv - 图像匹配获取元素

```python
device.get_element_cv(
    tpl: str,
    img: str = None,
    timeout: int = 30,
    threshold: float = 0.7,
    use_ai: bool = False,
    trace_id: str = None,
    **kwargs
) -> Dict[str, Any]
```

基于图像匹配获取元素的边界信息。

**返回值：** `{"bounds": [x, y, dx, dy]}`

```python
element = device.get_element_cv("./icon.png")
if element and element.get("bounds"):
    print(f"元素位置: {element['bounds']}")
```

#### get_element_ocr - OCR获取元素

```python
device.get_element_ocr(
    word: str,
    timeout: int = 30,
    use_ai: bool = False,
    threshold: float = 0.7,
    trace_id: str = None,
    **kwargs
) -> Dict[str, Any]
```

基于 OCR 文字识别获取元素的边界信息。

**返回值：** `{"bounds": [x, y, dx, dy]}`

```python
element = device.get_element_ocr("确定")
if element and element.get("bounds"):
    print(f"文字位置: {element['bounds']}")
```

---

### 截图与录制

#### screenshot - 截图保存

```python
device.screenshot(
    label: str,              # 截图文件名
    img_path: str,           # 保存目录
    crop: tuple = None,      # 裁剪区域 (left, upper, right, lower)
    trace_id: str = None
) -> str
```

截图并保存到本地，返回图片文件路径。

`crop` 参数支持两种格式：
- 比例裁剪：`(0.1, 0.1, 0.9, 0.9)` — 所有值在 0~1 之间
- 像素裁剪：`(100, 50, 400, 300)` — 像素坐标

```python
# 全屏截图
path = device.screenshot("home_page", "./screenshots")

# 裁剪截图（比例）
path = device.screenshot("center", "./screenshots", crop=(0.2, 0.2, 0.8, 0.8))

# 裁剪截图（像素）
path = device.screenshot("area", "./screenshots", crop=(100, 200, 500, 600))
```

#### screenshot_base64 - Base64截图

```python
device.screenshot_base64(
    crop: tuple = None,
    trace_id: str = None
) -> str
```

截图并返回 Base64 编码字符串，适用于需要在内存中处理图片的场景。

```python
img_b64 = device.screenshot_base64()

# 带裁剪
img_b64 = device.screenshot_base64(crop=(0.2, 0.2, 0.8, 0.8))
```

#### record_start - 开始录制

```python
device.record_start(video_path: str = '', trace_id: str = None) -> bool
```

开始屏幕录制。

```python
device.record_start("./videos")
```

#### record_stop - 停止录制

```python
device.record_stop(trace_id: str = None) -> bool
```

停止屏幕录制并保存视频。

```python
device.record_stop()
```

---

### 应用管理

#### install_app - 安装应用（URL方式）

```python
device.install_app(
    app_url: str = None,         # 安装包URL（可下载的COS链接）
    app_path: str = None,        # 安装包本地路径（client本地，调试用）
    need_resign: bool = False,   # 是否需要重签名（仅iOS）
    resign_bundle: str = "",     # 重签名BundleId（仅iOS）
    trace_id: str = None
) -> bool
```

```python
device.install_app(app_url="https://example.com/app.apk")

# iOS重签名安装
device.install_app(
    app_url="https://example.com/app.ipa",
    need_resign=True,
    resign_bundle="com.example.resigned"
)
```

#### local_install_app - 安装应用（本地文件）

```python
device.local_install_app(
    local_app_path: str,
    need_resign: bool = False,
    resign_bundle: str = "",
    trace_id: str = None
) -> bool
```

从本地文件安装应用到设备。

```python
device.local_install_app("./app-release.apk")
```

#### uninstall_app - 卸载应用

```python
device.uninstall_app(pkg: str, trace_id: str = None) -> bool
```

```python
device.uninstall_app("com.example.app")
```

#### start_app - 启动应用

```python
device.start_app(
    pkg: str,
    clear_data: bool = False,  # 启动前清除数据（仅Android/鸿蒙）
    trace_id: str = None
) -> bool
```

```python
device.start_app("com.example.app")
device.start_app("com.example.app", clear_data=True)  # 清除数据后启动
```

#### stop_app - 停止应用

```python
device.stop_app(pkg: str, trace_id: str = None) -> bool
```

```python
device.stop_app("com.example.app")
```

#### clear_app - 清理应用数据

```python
device.clear_app(pkg: str, trace_id: str = None) -> bool
```

结束应用并清理应用数据（仅 Android/鸿蒙）。

```python
device.clear_app("com.example.app")
```

#### open_url - 打开URL

```python
device.open_url(url: str, trace_id: str = None) -> bool
```

通过 URL 跳转到特定界面。

```python
device.open_url("https://example.com")
```

#### ios_open_url - iOS智能打开URL

```python
device.ios_open_url(
    url: str,
    permission_config: dict = None,
    trace_id: str = None
) -> bool
```

iOS 设备智能打开 URL，自动处理导航、输入和权限弹窗。

```python
# 默认配置
device.ios_open_url("https://example.com")

# 自定义权限处理
device.ios_open_url("https://example.com", permission_config={
    "allow_conditions": ["允许", "打开", "同意"],
    "wait_time": 30,
    "enabled": True
})

# 禁用权限处理
device.ios_open_url("https://example.com", permission_config={"enabled": False})
```

#### clear_safari - 清除Safari缓存

```python
device.clear_safari(close_pages: bool = False, trace_id: str = None) -> bool
```

> ⚠️ 仅 iOS 设备支持

清除 Safari 的历史记录、缓存和 Cookie。

```python
device.clear_safari()
device.clear_safari(close_pages=True)  # 同时关闭所有页面
```

---

### 性能监控

#### perf_start - 开始性能采集

```python
device.perf_start(
    container_bundle_identifier: str,  # 应用包名
    sub_process_name: str = '',
    sub_window: str = '',
    case_name: str = '',
    log_output_file: str = 'perf.log',
    trace_id: str = None
) -> bool
```

开始采集指定应用的性能数据。

```python
device.perf_start(container_bundle_identifier="com.example.app")
```

#### perf_stop - 停止性能采集

```python
device.perf_stop(output_directory: str = None, trace_id: str = None) -> bool
```

停止性能采集，可选保存数据到本地目录。

```python
device.perf_stop("./perf_output")
```

**完整示例：**

```python
# 开始采集
device.perf_start(container_bundle_identifier="com.example.app")

# 执行测试操作...
device.start_app("com.example.app")
time.sleep(10)

# 停止采集并保存
device.perf_stop("./perf_output")
```

---

### 日志采集（Logcat）

> ⚠️ 仅 Android 和鸿蒙设备支持

#### logcat_start - 启动日志采集

```python
device.logcat_start(
    file: str,               # 日志保存路径
    clear: bool = False,     # 开始前是否清除logcat
    re_filter: str = None,   # 正则过滤表达式
    trace_id: str = None
) -> LogcatTask
```

返回 `LogcatTask` 对象，可通过 `task.stop()` 停止采集。

```python
# 启动采集
task = device.logcat_start(
    file="./logs/app.txt",
    clear=True,
    re_filter=".*MyApp.*"
)

# 执行测试操作...
time.sleep(10)

# 停止采集
success = task.stop()
print(f"日志已保存到: {task.file_path}")
```

#### logcat_stop_all - 停止所有日志采集

```python
device.logcat_stop_all(trace_id: str = None) -> bool
```

停止设备上所有正在运行的 logcat 任务。

#### logcat_list_tasks - 获取运行中的任务列表

```python
device.logcat_list_tasks() -> List[LogcatTask]
```

```python
tasks = device.logcat_list_tasks()
for task in tasks:
    print(f"任务: {task.task_id}, 文件: {task.file_path}")
```

#### logcat_get_task - 获取指定任务

```python
device.logcat_get_task(task_id: str) -> Optional[LogcatTask]
```

---

### ANR/Crash监控

> ⚠️ 仅 Android 和鸿蒙设备支持

#### anr_start - 启动ANR/Crash监控

```python
device.anr_start(
    package_name: str,
    collect_am_monitor: bool = False,  # 是否采集AM监控日志
    trace_id: str = None
) -> bool
```

```python
# 基础监控
device.anr_start(package_name="com.example.app")

# 包含AM监控日志
device.anr_start(package_name="com.example.app", collect_am_monitor=True)
```

#### anr_stop - 停止ANR/Crash监控

```python
device.anr_stop(
    output_directory: str = None,
    trace_id: str = None
) -> Dict[str, Any]
```

**返回值字段：**

| 字段 | 类型 | 说明 |
|------|------|------|
| `success` | `bool` | 是否成功 |
| `run_time` | `int` | 运行时间（秒） |
| `crash_count` | `int` | Crash次数 |
| `anr_count` | `int` | ANR次数 |
| `logcat_file` | `str` | logcat文件路径 |
| `screenshots` | `list` | 截图文件路径列表 |
| `context_files` | `list` | 上下文文件路径列表 |
| `am_monitor_file` | `str` | AM监控文件路径 |

```python
device.anr_start(package_name="com.example.app")

# 执行测试操作...
time.sleep(30)

result = device.anr_stop(output_directory="./anr_output")
print(f"ANR: {result['anr_count']}, Crash: {result['crash_count']}")
print(f"截图: {result['screenshots']}")
print(f"日志: {result['logcat_file']}")
```

---

### 控件树与元素操作

#### get_uitree - 获取控件树

```python
device.get_uitree(xml: bool = False, trace_id: str = None) -> Union[Dict, str]
```

获取当前页面的控件树。

```python
# JSON格式
tree = device.get_uitree()

# XML格式
xml_tree = device.get_uitree(xml=True)
```

#### get_element - 获取单个元素

```python
device.get_element(xpath: str, timeout: int = 30, trace_id: str = None) -> Any
```

根据 XPath 获取元素，支持超时等待。

```python
element = device.get_element("//*[@text='确定']", timeout=10)
if element:
    print(f"找到元素: {element}")
```

#### get_elements - 获取元素列表

```python
device.get_elements(xpath: str, trace_id: str = None) -> Any
```

根据 XPath 获取所有匹配的元素列表。

```python
elements = device.get_elements("//*[@class='android.widget.Button']")
print(f"找到 {len(elements)} 个按钮")
```

---

### 剪贴板操作

#### set_clipboard - 设置剪贴板

```python
device.set_clipboard(text: str, trace_id: str = None) -> Any
```

```python
device.set_clipboard("要复制的文本")
```

#### get_clipboard - 获取剪贴板

```python
device.get_clipboard(trace_id: str = None) -> Any
```

```python
text = device.get_clipboard()
print(f"剪贴板内容: {text}")
```

---

### 网络代理

#### set_http_global_proxy - 设置全局代理

```python
device.set_http_global_proxy(
    host: str,
    port: int,
    username: str = None,
    password: str = None,
    trace_id: str = None
) -> Any
```

```python
device.set_http_global_proxy(host="192.168.1.100", port=8080)

# 带认证
device.set_http_global_proxy(
    host="proxy.example.com",
    port=8080,
    username="user",
    password="pass"
)
```

#### get_http_global_proxy - 获取全局代理

```python
device.get_http_global_proxy(trace_id: str = None) -> Any
```

```python
proxy = device.get_http_global_proxy()
print(f"当前代理: {proxy}")
```

#### clear_http_global_proxy - 清除全局代理

```python
device.clear_http_global_proxy(trace_id: str = None) -> Any
```

```python
device.clear_http_global_proxy()
```

---

### 文件操作

#### get_file_path_info - 获取文件属性

```python
device.get_file_path_info(path: str, trace_id: str = None) -> Any
```

获取设备上文件或目录的属性信息。

**返回值字段：** `isDirectory`、`mode`、`modifyTime`、`name`、`path`、`size`、`files`（目录下文件列表）

```python
info = device.get_file_path_info("/sdcard/Download/")
print(f"是否目录: {info['isDirectory']}")
print(f"文件列表: {info.get('files', [])}")
```

#### create_remote_dir - 创建远程目录

```python
device.create_remote_dir(trace_id: str = None) -> Optional[str]
```

在设备 client 上创建临时目录。

#### clean_remote_device_dir - 清理远程目录

```python
device.clean_remote_device_dir(trace_id: str = None) -> bool
```

清理设备 client 上的临时文件目录。

---

### 事件自动处理（服务端）

这组 API 通过服务端实现事件自动处理，适用于需要在设备端持续运行的弹窗处理场景。

#### load_default_handler - 批量加载处理规则

```python
device.load_default_handler(rule: list, trace_id: str = None)
```

批量加载事件自动处理规则。规则支持字符串（正则匹配后点击）和元组（匹配+指定点击目标）。

```python
rule = [
    '^(允许|确定|同意|关闭|知道了)$',                    # 正则匹配后点击
    ('(更新|升级)', '取消'),                              # 匹配"更新"时点击"取消"
    ('(隐私)', '同意并继续'),                             # 匹配"隐私"时点击"同意并继续"
    ('(申请获取以下权限)', '(允许|同意)'),                # 匹配权限弹窗
]
device.load_default_handler(rule)
```

#### start_event_handler - 启动预设处理

```python
device.start_event_handler(trace_id: str = None)
```

启动预设的事件自动处理。

#### add_event_handler - 添加处理规则

```python
device.add_event_handler(
    match_element: str,
    action_element: str = None,
    trace_id: str = None
)
```

添加单条事件处理规则并运行。

```python
device.add_event_handler(match_element="允许", action_element="允许")
```

#### sync_event_handler - 同步处理规则

```python
device.sync_event_handler(trace_id: str = None)
```

#### clear_event_handler - 清除处理规则

```python
device.clear_event_handler(trace_id: str = None)
```

---

### 事件处理（客户端Watcher）

客户端 Watcher 模式，通过后台线程定期检查 UI 树并自动处理匹配的事件。

通过 `device.handler` 访问 `EventHandler` 实例。

#### 创建 Watcher

```python
# 匹配文字并点击
device.handler.watcher("name").when("匹配条件").click()

# 匹配文字并调用自定义函数
device.handler.watcher("name").when("匹配条件").call(handler_func)

# 多条件匹配
device.handler.watcher("name").when("条件1").when("条件2").click()

# 设置匹配模式
device.handler.watcher("name").when("条件").with_match_mode("strict").click()
```

**匹配模式：**
- `auto`（默认）：依次尝试 强匹配 → 模糊匹配 → 正则匹配
- `strict`：仅精确匹配
- `fuzzy`：仅包含匹配
- `regex`：仅正则匹配

#### 启动/停止监控

```python
# 启动监控（默认2秒间隔）
device.handler.start(interval=2.0)

# 停止监控
device.handler.stop()

# 重置所有watcher
device.handler.reset()

# 获取watcher状态
status = device.handler.get_watcher_status()
```

#### 完整示例

```python
# 自动关闭权限弹窗
device.handler.watcher("permission").when("允许").click()

# 自动关闭更新弹窗
device.handler.watcher("update").when("稍后更新").click()

# 自定义处理逻辑
def handle_ad(device, xml_element, smart_click):
    """自定义处理函数
    Args:
        device: 设备对象
        xml_element: 匹配到的XML元素
        smart_click: 智能点击方法，可模糊匹配文字并点击
    """
    smart_click("关闭")

device.handler.watcher("ad_popup").when("广告").call(handle_ad)

# 启动监控
device.handler.start(interval=1.5)

# 执行测试操作...
device.start_app("com.example.app")
time.sleep(30)

# 停止监控
device.handler.stop()
```

---

### AI Agent 探索测试

#### explore - 执行AI探索任务

```python
device.explore(
    task: str,                       # 任务描述（自然语言）
    rules: str = None,               # 自定义规则
    model: ModelType = None,         # 指定模型
    system_prompt: str = None        # 自定义系统提示词（高级）
) -> Generator[StepUpdate, None, None]
```

使用 AI Agent 执行探索性测试，返回生成器实时获取执行状态。

> ⚠️ 需要在创建 UBox 时提供 `agent_model_config` 参数

**StepUpdate 字段：**
- `update_type`: 更新类型（如 `"thinking"`、`"action"`、`"finished"` 等）
- `content`: 更新内容

```python
# 基本用法
for update in device.explore("打开微信并搜索'优测'"):
    if update.update_type == "thinking":
        print(f"思考: {update.content}")
    elif update.update_type == "action":
        print(f"操作: {update.content}")
    elif update.update_type == "finished":
        print(f"完成: {update.content}")

# 使用自定义规则
for update in device.explore(
    "测试登录功能",
    rules="1. 遇到弹窗优先关闭\n2. 不要点击广告"
):
    pass

# 切换模型
for update in device.explore("探索应用功能", model=ModelType.MAI_UI_8B):
    pass
```

#### stop_agent - 停止Agent任务

```python
device.stop_agent() -> None
```

主动停止当前正在执行的 Agent 任务。

```python
device.stop_agent()
```

---

### 设备释放与关闭

#### release - 释放设备

```python
device.release(timeout: int = 30)
```

释放当前设备，停止续期任务。通常不需要手动调用，使用 `with` 语句时会自动释放。

#### close - 关闭设备

```python
device.close()
```

关闭设备连接。

#### init_driver - 初始化驱动

```python
device.init_driver(trace_id: str = None) -> bool
```

初始化设备驱动，通常在设备初始化时自动调用。

#### get_auth_info - 获取认证信息

```python
device.get_auth_info() -> Dict[str, Any]
```

获取设备的认证信息，包含 `authCode`、`debugId`、`udid` 等。

```python
auth_info = device.get_auth_info()
print(f"authCode: {auth_info['authCode']}")
```

---

## 附录：DriverType 定位方式速查

| 常量 | 值 | 说明 | `loc` 参数格式 |
|------|-----|------|---------------|
| `DriverType.POS` | 0 | 坐标定位 | `[x, y]` 坐标 |
| `DriverType.UI` | 1 | UI控件定位 | XPath 表达式 |
| `DriverType.OCR` | 2 | OCR文字识别 | 目标文字字符串 |
| `DriverType.CV` | 3 | 图像匹配 | 模板图片路径 |
| `DriverType.GA` | 4 | GA定位 | 控件标识 |
| `DriverType.GA_UNITY` | 5 | GA Unity | 控件标识 |
| `DriverType.GA_UE` | 6 | GA UE | 控件标识 |
