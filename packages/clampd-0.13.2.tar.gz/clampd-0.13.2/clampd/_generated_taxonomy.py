# AUTO-GENERATED FROM services/crates/ag-common/src/categories.toml
# DO NOT EDIT BY HAND — run `cargo build -p ag-common` to regenerate.
"""Generated taxonomy data for the Python SDK.

Shape: category -> subcategory -> [operations].
Enums and helpers live in `clampd/taxonomy.py` (hand-written).
"""

from __future__ import annotations

TAXONOMY: dict[str, dict[str, list[str]]] = {
    'agent': {
        'a2a': ['read', 'write'],
        'config': ['read', 'write'],
        'delegate': ['write'],
        'spawn': ['write'],
    },
    'auth': {
        'credential': ['read', 'write', 'delete'],
        'oauth': ['read', 'write'],
        'secret': ['read', 'write', 'delete'],
        'token': ['read', 'write', 'delete', 'refresh'],
    },
    'browser': {
        'page': ['read', 'write'],
        'screenshot': ['read'],
    },
    'cloud': {
        'deploy': ['read', 'write', 'destructive'],
        'iam': ['read', 'write', 'delete'],
        'infra': ['read', 'write', 'destructive'],
    },
    'comms': {
        'email': ['read', 'send', 'delete'],
        'messaging': ['read', 'send', 'delete'],
        'notification': ['send'],
        'slack': ['read', 'send', 'delete'],
        'sms': ['read', 'send'],
    },
    'db': {
        'mutate': ['write', 'delete', 'destructive'],
        'query': ['read'],
        'schema': ['read', 'destructive'],
    },
    'exec': {
        'code': ['run'],
        'function': ['run'],
        'shell': ['run', 'destructive'],
    },
    'fs': {
        'blob': ['read', 'write', 'delete'],
        'file': ['read', 'write', 'delete'],
    },
    'llm': {
        'embedding': ['read', 'write'],
        'input': ['write'],
        'output': ['read'],
    },
    'net': {
        'dns': ['read'],
        'http': ['read', 'write'],
        'socket': ['read', 'write'],
    },
    'payment': {
        'billing': ['read', 'write'],
        'invoice': ['read', 'write'],
        'transaction': ['read', 'write', 'destructive'],
    },
    'scm': {
        'git': ['read', 'write', 'delete'],
    },
}

__all__ = ["TAXONOMY"]
