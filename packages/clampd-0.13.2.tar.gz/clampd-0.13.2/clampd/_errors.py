"""Internal SDK exception types.

Kept separate from ``client.py`` (where ``ClampdBlockedError`` lives for
historical reasons) so new error types don't force a circular import.
"""

from __future__ import annotations


class ClampdClassificationError(ValueError):
    """Raised when a tool classification triple is invalid.

    Thrown by :func:`clampd.register_tool` when the provided
    ``(category, subcategory, operation)`` combination does not appear in
    the canonical taxonomy (``ag-common/src/categories.toml``).

    The message always lists valid alternatives so the caller can correct
    the call site without leaving the editor.
    """

    def __init__(
        self,
        message: str,
        *,
        category: str | None = None,
        subcategory: str | None = None,
        operation: str | None = None,
        valid: list[str] | None = None,
    ) -> None:
        self.category = category
        self.subcategory = subcategory
        self.operation = operation
        self.valid = list(valid or [])
        super().__init__(message)


__all__ = ["ClampdClassificationError"]
