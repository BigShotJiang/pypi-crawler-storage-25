"""LangChain CallbackHandler — guards ALL tools in any chain/agent.

Used internally by ``clampd.langchain()``. You don't need to import this directly.
"""

from __future__ import annotations

import json
import logging
from typing import Any

from clampd.client import ClampdBlockedError, ClampdClient
from clampd._guardrails import guard_tool_callback, inspect_response_callback
from clampd.contract_hash import contract_hash

logger = logging.getLogger("clampd.langchain")


def _schema_to_dict(args_schema: Any) -> dict[str, Any]:
    """Convert a pydantic args_schema (v1 or v2) to a JSON Schema dict.

    Returns ``{}`` when no schema is available, when the schema call
    raises, or when it returns a non-dict — ``contract_hash`` treats
    that as the explicit "empty contract" case so the gateway can still
    detect rug-pulls rather than silently skipping.
    """
    if args_schema is None:
        return {}
    if hasattr(args_schema, "model_json_schema"):  # pydantic v2
        try:
            result = args_schema.model_json_schema()
        except Exception:
            return {}
        return result if isinstance(result, dict) else {}
    if hasattr(args_schema, "schema"):  # pydantic v1
        try:
            result = args_schema.schema()
        except Exception:
            return {}
        return result if isinstance(result, dict) else {}
    return {}

try:
    from langchain_core.callbacks import BaseCallbackHandler
except ImportError:
    raise ImportError(
        "langchain-core required. Install: pip install langchain-core"
    )


class ClampdCallbackHandler(BaseCallbackHandler):
    """LangChain callback that intercepts tool calls via Clampd."""

    raise_error = True
    run_inline = True

    def __init__(self, client: ClampdClient, target_url: str = "", fail_open: bool = False, check_response: bool = False) -> None:
        super().__init__()
        self.client = client
        self.target_url = target_url
        self.fail_open = fail_open
        self.check_response = check_response
        self._last_tool_name = ""
        self._last_scope_token = ""

    def on_tool_start(self, serialized: dict[str, Any], input_str: str, **kwargs: Any) -> None:
        tool_name = serialized.get("name", "unknown_tool")
        self._last_tool_name = tool_name

        inputs = kwargs.get("inputs")
        if inputs and isinstance(inputs, dict):
            params = inputs
        else:
            try:
                params = json.loads(input_str) if input_str else {}
            except (json.JSONDecodeError, TypeError):
                params = {"input": input_str}

        # LangChain's on_tool_start only surfaces ``name`` and
        # ``description`` via ``serialized``; the pydantic ``args_schema``
        # is not passed through. Emit a hash anyway (empty-parameters
        # case) so the gateway can still key rug-pull detection on the
        # (name, description) pair. If the schema ever becomes available
        # through a future LangChain callback extension, feed it through
        # ``_schema_to_dict`` here.
        descriptor_hash = contract_hash(
            tool_name,
            serialized.get("description", "") or "",
            _schema_to_dict(serialized.get("args_schema")),
        )

        error, scope_token = guard_tool_callback(
            self.client, tool_name, params,
            target_url=self.target_url, fail_open=self.fail_open,
            tool_descriptor_hash=descriptor_hash,
        )
        self._last_scope_token = scope_token

        if error:
            raise ClampdBlockedError(
                error.get("error", "denied"),
                risk_score=error.get("risk_score", 1.0),
            )

    def on_tool_end(self, output: str, **kwargs: Any) -> None:
        if not self.check_response:
            return
        error = inspect_response_callback(
            self.client, self._last_tool_name, output,
            fail_open=self.fail_open, scope_token=self._last_scope_token,
        )
        if error:
            raise ClampdBlockedError(
                error.get("error", "Response blocked"),
                risk_score=error.get("risk_score", 1.0),
            )
