"""真实 API 集成测试 - 验证返回基金数据"""
import pytest
import os

from caichacha_sdk import FundFilterClient
from caichacha_sdk.models import (
    FundFilterRequest,
    FundFilterRangeV2DTO,
    FundOrderRankValueV2DTO,
    TimeRangeCode,
    RiskLevel,
)


# 标记需要真实 API 环境的测试
pytestmark = pytest.mark.integration


@pytest.fixture
def client():
    """创建客户端"""
    base_url = os.getenv("CCCSDK_BASE_URL", "http://192.168.90.209:6098")
    return FundFilterClient(base_url=base_url)


class TestBasicQuery:
    """测试基础查询 - 验证返回基金数据"""

    def test_basic_query_returns_funds(self, client):
        """测试基础查询返回基金列表"""
        request = FundFilterRequest(
            page_num=1,
            page_size=10
        )

        response = client.fund_filter_v2(request)

        # 验证响应成功
        assert response.is_success, f"API 调用失败: {response.msg}"
        assert response.code == 0
        assert response.data is not None

        # 验证返回基金数据
        assert isinstance(response.fund_list, list)
        assert len(response.fund_list) > 0, "应该返回至少一只基金"

        # 验证基金数据完整性
        fund = response.fund_list[0]
        assert fund.fund_code is not None, "基金代码不能为空"
        assert fund.fund_sname is not None, "基金简称不能为空"
        assert fund.fund_type is not None, "基金类型不能为空"

        print(f"\n[OK] 基础查询成功，返回 {len(response.fund_list)} 只基金")
        print(f"   第一只基金: {fund.fund_sname} ({fund.fund_code})")

    def test_pagination_works(self, client):
        """测试分页功能"""
        # 第一页
        request1 = FundFilterRequest(page_num=1, page_size=5)
        response1 = client.fund_filter_v2(request1)

        assert response1.is_success
        assert len(response1.fund_list) <= 5

        # 第二页
        request2 = FundFilterRequest(page_num=2, page_size=5)
        response2 = client.fund_filter_v2(request2)

        assert response2.is_success
        assert len(response2.fund_list) <= 5

        # 验证两页数据不同
        if len(response1.fund_list) > 0 and len(response2.fund_list) > 0:
            codes1 = [f.fund_code for f in response1.fund_list]
            codes2 = [f.fund_code for f in response2.fund_list]
            assert codes1 != codes2, "分页应该返回不同的基金"

        print(f"\n[OK] 分页测试通过，第1页 {len(response1.fund_list)} 只，第2页 {len(response2.fund_list)} 只")


class TestFilterByCompany:
    """测试按基金公司筛选"""

    def test_filter_by_company_code(self, client):
        """测试按基金公司代码筛选"""
        # 先查询获取一个存在的基金公司代码
        all_request = FundFilterRequest(page_num=1, page_size=1)
        all_response = client.fund_filter_v2(all_request)

        if not all_response.is_success or len(all_response.fund_list) == 0:
            pytest.skip("无法获取测试数据")

        # 使用查询到的基金公司代码进行筛选
        company_code = "80000248"  # 易方达基金

        request = FundFilterRequest(
            page_num=1,
            page_size=20,
            company_code_list=[company_code]
        )

        response = client.fund_filter_v2(request)

        assert response.is_success, f"筛选失败: {response.msg}"

        if len(response.fund_list) > 0:
            for fund in response.fund_list:
                # 验证返回的基金都属于指定基金公司
                assert fund.company_name is not None
                print(f"   - {fund.fund_sname} | 公司: {fund.company_name}")

            print(f"\n[OK] 基金公司筛选成功，返回 {len(response.fund_list)} 只基金")
        else:
            print(f"\n[WARN] 基金公司 {company_code} 没有返回基金")


class TestFilterByRiskLevel:
    """测试按风险等级筛选"""

    def test_filter_by_risk_level(self, client):
        """测试按风险等级筛选"""
        request = FundFilterRequest(
            page_num=1,
            page_size=20,
            risk_level_list=[RiskLevel.R3]  # 中风险
        )

        response = client.fund_filter_v2(request)

        assert response.is_success

        if len(response.fund_list) > 0:
            for fund in response.fund_list[:5]:  # 只打印前5只
                print(f"   - {fund.fund_sname} | 风险: {fund.risk_level}")

            print(f"\n[OK] 风险等级筛选成功，返回 {len(response.fund_list)} 只基金")
        else:
            print("\n[WARN] 该风险等级没有返回基金")


class TestFilterByPerformance:
    """测试按业绩筛选"""

    def test_filter_by_return_rate(self, client):
        """测试按收益率筛选"""
        request = FundFilterRequest(
            page_num=1,
            page_size=20,
            ret_list=[
                FundOrderRankValueV2DTO(
                    code=TimeRangeCode.ONE_YEAR,
                    min_value=10,  # 近一年收益 > 10%
                    max_value=100
                )
            ]
        )

        response = client.fund_filter_v2(request)

        assert response.is_success

        if len(response.fund_list) > 0:
            for fund in response.fund_list[:5]:
                print(f"   - {fund.fund_sname}")
                print(f"     近一年收益: {fund.per_1y}%")

            print(f"\n[OK] 收益率筛选成功，返回 {len(response.fund_list)} 只基金")
        else:
            print("\n[WARN] 没有符合条件的基金")


class TestFilterByFundSize:
    """测试按基金规模筛选"""

    def test_filter_by_fund_size(self, client):
        """测试按基金规模筛选"""
        request = FundFilterRequest(
            page_num=1,
            page_size=20,
            fund_specification_list=[
                FundFilterRangeV2DTO(min_value=10, max_value=100)  # 10-100亿
            ]
        )

        response = client.fund_filter_v2(request)

        assert response.is_success

        if len(response.fund_list) > 0:
            for fund in response.fund_list[:5]:
                size = fund.fund_specification
                print(f"   - {fund.fund_sname}")
                print(f"     规模: {size}亿元" if size else "     规模: 未知")

            print(f"\n[OK] 基金规模筛选成功，返回 {len(response.fund_list)} 只基金")
        else:
            print("\n[WARN] 没有符合条件的基金")


class TestComplexFilter:
    """测试复杂组合筛选"""

    def test_complex_filter(self, client):
        """测试多条件组合筛选"""
        request = FundFilterRequest(
            page_num=1,
            page_size=20,
            company_code_list=["80000248"],  # 易方达
            risk_level_list=[RiskLevel.R3, RiskLevel.R4],
            fund_specification_list=[
                FundFilterRangeV2DTO(min_value=5, max_value=200)
            ],
            sort_by="per1y",
            sort_type="DESC"
        )

        response = client.fund_filter_v2(request)

        assert response.is_success

        if len(response.fund_list) > 0:
            print(f"\n[OK] 复杂筛选成功，返回 {len(response.fund_list)} 只基金")
            print("\n筛选条件:")
            print("  - 基金公司: 80000248 (易方达)")
            print("  - 风险等级: R3, R4")
            print("  - 基金规模: 5-200亿元")
            print("  - 排序: 近一年收益降序")
            print("\n结果:")

            for fund in response.fund_list[:5]:
                print(f"   {fund.fund_sname}")
                print(f"   类型: {fund.fund_type_txt} | 风险: {fund.risk_level}")
                print(f"   近一年收益: {fund.per_1y}% | 日涨跌: {fund.daily_change}%")
                print()
        else:
            print("\n[WARN] 没有符合条件的基金")


class TestResponseDataIntegrity:
    """测试响应数据完整性"""

    def test_fund_data_fields(self, client):
        """测试基金数据字段完整性"""
        request = FundFilterRequest(page_num=1, page_size=1)
        response = client.fund_filter_v2(request)

        assert response.is_success

        if len(response.fund_list) == 0:
            pytest.skip("没有返回基金数据")

        fund = response.fund_list[0]

        # 验证基本信息
        assert fund.fund_code is not None
        assert fund.fund_sname is not None

        print(f"\n[OK] 基金数据完整性检查")
        print(f"   基金代码: {fund.fund_code}")
        print(f"   基金简称: {fund.fund_sname}")
        print(f"   基金类型: {fund.fund_type_txt} ({fund.fund_type})")
        print(f"   基金公司: {fund.company_name}")
        print(f"   基金经理: {fund.fund_managers}")
        print(f"   单位净值: {fund.unit_net_worth}")
        print(f"   日涨跌幅: {fund.daily_change}%")
        print(f"   风险等级: {fund.risk_level}")
        print(f"   基金规模: {fund.fund_specification}亿元")

    def test_pagination_info(self, client):
        """测试分页信息"""
        request = FundFilterRequest(page_num=1, page_size=10)
        response = client.fund_filter_v2(request)

        assert response.is_success
        assert response.data is not None

        # 验证分页信息
        assert response.data.page_num == 1
        assert response.data.page_size == 10
        assert response.data.total >= 0
        assert response.data.pages >= 0

        print(f"\n[OK] 分页信息")
        print(f"   当前页: {response.data.page_num}")
        print(f"   每页数量: {response.data.page_size}")
        print(f"   总记录数: {response.data.total}")
        print(f"   总页数: {response.data.pages}")
        print(f"   当前页基金数: {len(response.fund_list)}")


if __name__ == "__main__":
    # 允许直接运行测试
    pytest.main([__file__, "-v", "-s"])
