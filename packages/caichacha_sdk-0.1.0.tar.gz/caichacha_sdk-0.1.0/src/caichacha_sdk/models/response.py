"""响应数据模型"""
from datetime import date
from decimal import Decimal
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field


class FundOrderRangeRetYearVO(BaseModel):
    """年度收益对象"""
    model_config = ConfigDict(populate_by_name=True)

    year: Optional[str] = Field(None, description="年份")
    ret: Optional[Decimal] = Field(None, description="收益率")


class FndSelection(BaseModel):
    """条件筛选指标"""
    model_config = ConfigDict(populate_by_name=True)

    code: Optional[str] = Field(None, description="指标代码")
    name: Optional[str] = Field(None, description="指标名称")
    value: Optional[str] = Field(None, description="指标值")


class FundOrderListV2VO(BaseModel):
    """
    基金信息对象

    包含基金的基本信息、净值信息、规模与风险、收益表现、持仓信息等。
    """
    model_config = ConfigDict(populate_by_name=True)

    # 基本信息
    fund_code: Optional[str] = Field(None, alias="fundCode", description="基金编码")
    fund_backcode: Optional[str] = Field(None, alias="fundBackcode", description="基金后端代码")
    master_code: Optional[str] = Field(None, alias="masterCode", description="主基金编码")
    fund_sname: Optional[str] = Field(None, alias="fundSname", description="基金简称")
    fund_type: Optional[str] = Field(None, alias="fundType", description="基金类型代码")
    fund_type_txt: Optional[str] = Field(None, alias="fundTypeTxt", description="基金类型简称")
    company_name: Optional[str] = Field(None, alias="companyName", description="基金公司名称")
    fund_managers: Optional[str] = Field(None, alias="fundManagers", description="基金经理")

    # 净值信息
    nav_date: Optional[str] = Field(None, alias="navDate", description="净值更新日期")
    unit_net_worth: Optional[Decimal] = Field(None, alias="unitNetWorth", description="单位净值")
    cumulative_net_worth: Optional[Decimal] = Field(
        None,
        alias="cumulativeNetWorth",
        description="累计净值"
    )
    daily_change: Optional[Decimal] = Field(None, alias="dailyChange", description="日涨跌幅（%）")
    annu_yield: Optional[Decimal] = Field(None, alias="annuYield", description="七日年化收益率（%）")
    w_income: Optional[Decimal] = Field(None, alias="wIncome", description="万份收益")

    # 规模与风险
    fund_specification: Optional[Decimal] = Field(
        None,
        alias="fundSpecification",
        description="基金规模（亿元）"
    )
    establish_date: Optional[date] = Field(None, alias="establishDate", description="基金成立日期")
    risk_level: Optional[str] = Field(None, alias="riskLevel", description="风险等级")
    min_amount: Optional[Decimal] = Field(None, alias="minAmount", description="起购金额（元）")

    # 收益表现
    per_1y: Optional[Decimal] = Field(None, alias="per1y", description="近一年收益率（%）")
    per_3y: Optional[Decimal] = Field(None, alias="per3y", description="近三年收益率（%）")
    per_all: Optional[Decimal] = Field(None, alias="perAll", description="成立以来收益率（%）")

    # 持仓信息
    heavy_position: Optional[Decimal] = Field(
        None,
        alias="heavyPosition",
        description="重仓集中度占比"
    )
    turnover: Optional[Decimal] = Field(None, alias="turnover", description="换手率")
    sw_holding_list: Optional[List[str]] = Field(
        None,
        alias="swHoldingList",
        description="申万持有行业列表"
    )
    inst_tsppt: Optional[Decimal] = Field(
        None,
        alias="instTsppt",
        description="机构投资者持有份额占总份额比例"
    )
    holding_style_map: Optional[Dict[str, Decimal]] = Field(
        None,
        alias="holdingStyleMap",
        description="持仓风格偏好"
    )
    holding_industry_map: Optional[Dict[str, Decimal]] = Field(
        None,
        alias="holdingIndustryMap",
        description="持仓行业偏好"
    )

    # 状态信息
    subscribe_status: Optional[int] = Field(
        None,
        alias="subscribeStatus",
        description="新发认购状态：1-是，0-否"
    )
    fixed_investment_status: Optional[int] = Field(
        None,
        alias="fixedInvestmentStatus",
        description="定投状态：1-可以，0-不可以"
    )
    buy_status: Optional[int] = Field(None, alias="buyStatus", description="申购状态：1-是，0-否")
    limit_large_buy_status: Optional[int] = Field(
        None,
        alias="limitLargeBuyStatus",
        description="限大额申购状态：1-是，0-否"
    )
    opera_type_name: Optional[str] = Field(None, alias="operaTypeName", description="开放类型名称")
    other_name: Optional[str] = Field(None, alias="otherName", description="其他属性")
    currency: Optional[str] = Field(None, alias="currency", description="发行币种")

    # 其他信息
    visit_count_week: Optional[int] = Field(
        None,
        alias="visitCountWeek",
        description="近一周浏览次数"
    )
    cast_count_year: Optional[int] = Field(
        None,
        alias="castCountYear",
        description="近一年定投数量"
    )
    cast_create_count_three_month: Optional[int] = Field(
        None,
        alias="castCreateCountThreeMonth",
        description="近三月定投计划数"
    )
    number_of_taurus_awards: Optional[int] = Field(
        None,
        alias="numberOfTaurusAwards",
        description="金牛奖获奖次数"
    )
    range_ret_year_map: Optional[Dict[str, "FundOrderRangeRetYearVO"]] = Field(
        None,
        alias="rangeRetYearMap",
        description="最近10年年度收益"
    )
    selection_map: Optional[Dict[str, "FndSelection"]] = Field(
        None,
        alias="selectionMap",
        description="条件筛选指标列表"
    )


class PageVO(BaseModel):
    """
    分页对象

    Attributes:
        list: 数据列表
        page_num: 当前页码
        page_size: 每页数量
        pages: 总页数
        total: 总记录数
    """
    model_config = ConfigDict(populate_by_name=True)

    list: List[FundOrderListV2VO] = Field(..., description="数据列表")
    page_num: int = Field(..., alias="pageNum", description="当前页码")
    page_size: int = Field(..., alias="pageSize", description="每页数量")
    pages: int = Field(..., description="总页数")
    total: int = Field(..., description="总记录数")


class FundFilterResponse(BaseModel):
    """
    基金筛选响应

    Attributes:
        code: 响应码：0-成功，其他-失败
        msg: 响应消息
        data: 分页数据
    """
    model_config = ConfigDict(populate_by_name=True)

    code: int = Field(..., description="响应码：0-成功，其他-失败")
    msg: str = Field(..., description="响应消息")
    data: Optional[PageVO] = Field(None, description="分页数据")

    @property
    def is_success(self) -> bool:
        """是否成功"""
        return self.code == 0

    @property
    def fund_list(self) -> List[FundOrderListV2VO]:
        """获取基金列表"""
        return self.data.list if self.data else []
