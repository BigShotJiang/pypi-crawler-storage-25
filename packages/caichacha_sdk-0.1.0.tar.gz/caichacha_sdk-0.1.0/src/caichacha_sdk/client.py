"""SDK 客户端实现"""
import json
from decimal import Decimal
from typing import Any, Optional

import requests
from pydantic import ValidationError as PydanticValidationError

from caichacha_sdk.exceptions import APIError, NetworkError, ValidationError
from caichacha_sdk.models.request import FundFilterRequest
from caichacha_sdk.models.response import FundFilterResponse


def decimal_encoder(obj: Any) -> Any:
    """Decimal 编码器，用于 JSON 序列化"""
    if isinstance(obj, Decimal):
        return float(obj)
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")


class FundFilterClient:
    """
    基金筛选客户端

    提供 fundFilterV2 接口的调用方法，支持多种筛选条件组合查询基金列表。

    Attributes:
        base_url: API 基础地址
        timeout: 请求超时时间（秒）

    Example:
        >>> client = FundFilterClient(base_url="http://192.168.90.209:6098")
        >>> request = FundFilterRequest(page_num=1, page_size=20)
        >>> response = client.fund_filter_v2(request)
        >>> if response.is_success:
        ...     for fund in response.fund_list:
        ...         print(f"{fund.fund_sname}: {fund.daily_change}%")
    """

    DEFAULT_BASE_URL = "http://192.168.90.209:6098"
    DEFAULT_TIMEOUT = 30
    API_PATH = "/fund-tools-server/AIAssistant/fundFilterV2"

    def __init__(
        self,
        base_url: str = DEFAULT_BASE_URL,
        timeout: int = DEFAULT_TIMEOUT,
        headers: Optional[dict] = None
    ):
        """
        初始化客户端

        Args:
            base_url: API 基础地址，默认为 http://192.168.90.209:6098
            timeout: 请求超时时间（秒），默认为 30
            headers: 自定义请求头
        """
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({
            "Content-Type": "application/json",
            "Accept": "application/json",
            **(headers or {})
        })

    def _build_url(self, path: str) -> str:
        """构建完整 URL"""
        return f"{self.base_url}{path}"

    def _handle_response(self, response: requests.Response) -> FundFilterResponse:
        """处理响应"""
        try:
            response.raise_for_status()
            data = response.json()
            return FundFilterResponse(**data)
        except requests.HTTPError as e:
            raise APIError(
                message=f"HTTP 错误: {e.response.status_code}",
                code=e.response.status_code
            )
        except json.JSONDecodeError as e:
            raise APIError(
                message=f"JSON 解析错误: {str(e)}",
                response_data={"raw_response": response.text}
            )
        except PydanticValidationError as e:
            raise APIError(
                message=f"响应数据验证错误: {str(e)}",
                response_data={"raw_response": response.text}
            )

    def fund_filter_v2(self, request: FundFilterRequest) -> FundFilterResponse:
        """
        基金筛选v2接口

        支持多种筛选条件组合查询基金列表。

        Args:
            request: 基金筛选请求参数

        Returns:
            FundFilterResponse: 基金筛选响应

        Raises:
            ValidationError: 请求参数验证失败
            NetworkError: 网络请求失败
            APIError: API 调用失败

        Example:
            >>> from caichacha_sdk.models import (
            ...     FundFilterRequest,
            ...     FundFilterRangeV2DTO,
            ...     FundOrderRankValueV2DTO
            ... )
            >>>
            >>> request = FundFilterRequest(
            ...     page_num=1,
            ...     page_size=20,
            ...     company_code_list=["80000248"],
            ...     risk_level_list=["R3", "R4"],
            ...     fund_specification_list=[
            ...         FundFilterRangeV2DTO(min_value=10, max_value=100)
            ...     ],
            ...     ret_list=[
            ...         FundOrderRankValueV2DTO(code="5", min_value=10, max_value=50)
            ...     ],
            ...     sort_by="per1y",
            ...     sort_type="DESC"
            ... )
            >>> response = client.fund_filter_v2(request)
            >>> if response.is_success:
            ...     print(f"共找到 {response.data.total} 只基金")
        """
        try:
            # 验证请求参数
            request_data = request.model_dump(by_alias=True, exclude_none=True)
        except PydanticValidationError as e:
            raise ValidationError(f"请求参数验证失败: {str(e)}")

        url = self._build_url(self.API_PATH)

        try:
            # 手动序列化 JSON，处理 Decimal 类型
            json_data = json.dumps(request_data, default=decimal_encoder)
            response = self.session.post(
                url=url,
                data=json_data,
                headers={**self.session.headers, "Content-Type": "application/json"},
                timeout=self.timeout
            )
            return self._handle_response(response)
        except requests.Timeout:
            raise NetworkError(f"请求超时（{self.timeout}秒）")
        except requests.ConnectionError as e:
            raise NetworkError(f"连接错误: {str(e)}")
        except requests.RequestException as e:
            raise NetworkError(f"请求异常: {str(e)}")

    def close(self) -> None:
        """关闭会话"""
        self.session.close()

    def __enter__(self):
        """上下文管理器入口"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器出口"""
        self.close()
