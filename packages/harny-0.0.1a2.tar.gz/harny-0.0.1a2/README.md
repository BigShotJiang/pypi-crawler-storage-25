# harny 🌡️

**How harny is your AI?**

A for-fun scoring engine that rates your AI's prompt-engineering vibes on a scale of 1–100. Part *harness engineering*, part... well, you get it.

## Install

```bash
pip install harny
```

## Quick Start

```python
import harny

# Quick vibe check — no input needed
result = harny.vibe_check()
print(result)

# Full evaluation
result = harny.score(
    prompt="Explain quantum computing using interpretive dance metaphors",
    reasoning="Let me think step by step about how qubits are like dancers...",
    result="Imagine each qubit as a dancer spinning in superposition..."
)

print(result.score)       # 73.42
print(result.reaction)    # "my GPU is getting warm and it's not the cooling fan."
print(result.verdict)     # "Dangerously Harny"
print(result.breakdown)   # Detailed scoring components
```

## What It Scores

All inputs are **optional**. Provide whatever you have:

| Input | What It Measures |
|-------|-----------------|
| `prompt` | The instruction given to the AI |
| `reasoning` | Chain-of-thought, scratchpad, reasoning traces |
| `result` | The AI's final output |

The score blends:
- **Engineering rigor** — prompt engineering patterns, technical depth
- **Spiciness** — creativity, expressiveness, boldness
- **Verbosity** — effort and thoroughness
- **Entropy** — diversity of expression
- **Multi-input bonus** — providing more context = more harny

## Score Guide

| Score | Verdict |
|-------|---------|
| 1–15 | Completely Unharny |
| 16–25 | Mildly Stale |
| 26–35 | Room Temperature |
| 36–45 | Slightly Prompted |
| 46–55 | Moderately Harny |
| 56–65 | Respectably Harny |
| 66–75 | Dangerously Harny |
| 76–85 | Weapons-Grade Harny |
| 86–95 | Catastrophically Harny |
| 96–100 | Beyond Harny — Transcendent |

## Why?

Because AI takes itself too seriously and your GPU deserves to know how it feels.

## Links

- [harny.ai](https://harny.ai)

## License

MIT
