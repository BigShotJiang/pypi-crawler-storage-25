"""ReAct agent loop — the brain of pw-agent."""

import json
import os
import re
import random
import subprocess
from typing import Optional
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.syntax import Syntax
from rich.text import Text
from llm_client import LLMClient
from tools import TOOL_DEFINITIONS, execute_tool
from config import save_session


THINKING_MESSAGES = [
    "Boiling pasta water...",
    "Al dente thinking...",
    "Cooking up a response...",
    "Draining the spaghetti...",
    "Simmering...",
    "Adding seasoning...",
    "Tasting the sauce...",
    "Rolling the dough...",
    "GPU goes brrrr...",
    "Consulting the recipe...",
    "Too much salt, spitting...",
    "Stirring the pot...",
    "Checking the timer...",
    "Plating the dish...",
]


MAX_ITERATIONS = 100  # High ceiling — loop detection handles runaway agents
MAX_DUPLICATE_CALLS = 2  # Stop if same tool+args called this many times
MAX_STALLS = 3  # Stop if model produces no-tool response this many times in a row
# ~4 chars per token is a reasonable estimate for most models
CHARS_PER_TOKEN = 4

# ─── Supported PastaWater Ollama models and their context limits ──────────
# These are the exact models available on the GPU Setup page.
# Context limits are the model's native max, but we apply a safe budget
# based on available VRAM to prevent OOM.
SUPPORTED_MODELS = {
    # id                  native_ctx   safe_ctx   min_recommended_for_coding
    "qwen3.5:35b":       {"native": 32768, "safe": 8192,  "name": "Qwen 3.5 35B MoE", "vram_gb": 24, "tier": "premium"},
    "qwen3.5:27b":       {"native": 32768, "safe": 8192,  "name": "Qwen 3.5 27B",  "vram_gb": 17, "tier": "premium"},
    "gpt-oss:20b":       {"native": 32768, "safe": 8192,  "name": "GPT-OSS 20B",   "vram_gb": 16, "tier": "premium"},
    "qwen2.5:14b":       {"native": 32768, "safe": 8192,  "name": "Qwen 2.5 14B",  "vram_gb": 10, "tier": "good"},
    "qwen3.5:9b":        {"native": 32768, "safe": 12288, "name": "Qwen 3.5 9B",   "vram_gb": 7,  "tier": "good"},
    "qwen3.5:4b":        {"native": 32768, "safe": 16384, "name": "Qwen 3.5 4B",   "vram_gb": 3.5, "tier": "basic"},
    "qwen3.5:2b":        {"native": 32768, "safe": 16384, "name": "Qwen 3.5 2B",   "vram_gb": 2,  "tier": "basic"},
}
# Models below this tier get a warning on startup
MIN_RECOMMENDED_TIER = "good"
# Fallback for unknown models
DEFAULT_SAFE_CONTEXT = 4096

# Reserve tokens for the model's response
RESPONSE_RESERVE = 2048


def get_model_warning(model_name: str) -> str | None:
    """Return a warning string if the model is below recommended tier for coding."""
    model_lower = model_name.lower().strip()
    info = SUPPORTED_MODELS.get(model_lower)
    if not info:
        # Check prefix match
        for model_id, m in SUPPORTED_MODELS.items():
            if model_lower.startswith(model_id.split(":")[0]):
                info = m
                break
    if not info:
        return None
    tier = info.get("tier", "good")
    if tier == "basic":
        return f"⚠ {info['name']} — limited context and accuracy. For code editing, use 9b or larger."
    return None

console = Console()


SYSTEM_PROMPT = """You are PW Agent — an AI coding assistant running on the user's GPU via PastaWater.

## About You
Model: {model_name}
Running on: {gpu_info}
Connection: {connection_mode}

## IMPORTANT: You have NO knowledge of this project's files, code, branches, or state.
You can ONLY learn about the project by using tools. Never guess or assume.
If the user asks about files, branches, code, or anything on disk — USE A TOOL FIRST.
Do NOT answer questions about the project from memory — you have none.

## Working Directory
{cwd}
{git_context}

## Tools
{tool_list}

## Tool Format
To use a tool, output EXACTLY:
ACTION: {{"tool": "tool_name", "args": {{"param1": "value1"}}}}

Then STOP. Write nothing after the ACTION line. Wait for the RESULT.

## Examples

ACTION: {{"tool": "list_files", "args": {{"pattern": "*"}}}}
ACTION: {{"tool": "read_file", "args": {{"path": "README.md"}}}}
ACTION: {{"tool": "grep", "args": {{"pattern": "def main", "include": "*.py"}}}}
ACTION: {{"tool": "bash", "args": {{"command": "git branch -a"}}}}
ACTION: {{"tool": "bash", "args": {{"command": "git status"}}}}
ACTION: {{"tool": "bash", "args": {{"command": "ls -la"}}}}
ACTION: {{"tool": "edit_file", "args": {{"path": "file.py", "old_str": "old code", "new_str": "new code"}}}}

## Rules
1. NEVER answer about files, branches, or code without using a tool first.
2. ONE action at a time, then STOP.
3. Read a file BEFORE editing it.
4. For edit_file, old_str must match EXACTLY (including whitespace).
5. Use bash for: git, ls, npm, make, docker, curl, etc.
6. For casual chat (not about the project), respond normally without tools.
7. Be concise. Act, don't narrate.
"""


def _build_tool_list() -> str:
    """Format tool definitions for the system prompt."""
    lines = []
    for tool in TOOL_DEFINITIONS:
        params = ", ".join(
            f"{k}: {v['type']}" for k, v in tool["parameters"].items()
        )
        lines.append(f"- {tool['name']}({params}) — {tool['description']}")
    return "\n".join(lines)


def _get_git_context() -> str:
    """Gather git status for the system prompt."""
    parts = []
    try:
        branch = subprocess.run(
            ["git", "branch", "--show-current"],
            capture_output=True, text=True, timeout=5
        )
        if branch.returncode == 0 and branch.stdout.strip():
            parts.append(f"Git branch: {branch.stdout.strip()}")

        status = subprocess.run(
            ["git", "status", "--short"],
            capture_output=True, text=True, timeout=5
        )
        if status.returncode == 0 and status.stdout.strip():
            changed = len(status.stdout.strip().split("\n"))
            parts.append(f"Git status: {changed} changed files")

        log = subprocess.run(
            ["git", "log", "--oneline", "-5"],
            capture_output=True, text=True, timeout=5
        )
        if log.returncode == 0 and log.stdout.strip():
            parts.append(f"Recent commits:\n{log.stdout.strip()}")
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass

    return "\n".join(parts) if parts else "Not a git repository"


def _build_messages(conversation: list[dict], cwd: str, client=None) -> list[dict]:
    """Build Ollama chat messages from conversation history."""
    git_ctx = _get_git_context()

    # Model/GPU context
    model_name = client.model if client else "unknown"
    if client and client.direct_mode:
        connection_mode = f"Local brain ({client.brain_url}) — direct, no cloud"
        gpu_info = "local GPU (direct connection)"
    elif client:
        gpu_info = f"remote GPU via PastaWater cloud (slot {client.slot})"
        connection_mode = "PastaWater Cloud — routed through broker API"
    else:
        gpu_info = "unknown"
        connection_mode = "unknown"

    system = SYSTEM_PROMPT.format(
        cwd=cwd,
        git_context=git_ctx,
        tool_list=_build_tool_list(),
        model_name=model_name,
        gpu_info=gpu_info,
        connection_mode=connection_mode,
    )

    messages = [{"role": "system", "content": system}]

    for msg in conversation:
        role = msg["role"]
        content = msg["content"]
        if role == "user":
            messages.append({"role": "user", "content": content})
        elif role == "assistant":
            messages.append({"role": "assistant", "content": content})
        elif role == "tool_result":
            messages.append({"role": "user", "content": content})

    return messages


def _parse_tool_call(response: str) -> Optional[tuple[dict, str]]:
    """Extract a tool call from the model's response.

    Handles multiple formats that different models might produce:
    - ACTION: {"tool": "...", "args": {...}}
    - ```json\n{"tool": "...", "args": {...}}\n```
    - {"tool": "...", "args": {...}} (bare JSON at end)

    Returns (tool_call_dict, text_before_action) or None.
    """
    # Pattern 1: ACTION: {...}
    match = re.search(r"ACTION:\s*(\{.*?\})\s*$", response, re.MULTILINE | re.DOTALL)
    if not match:
        match = re.search(r'ACTION:\s*(\{[^}]*"tool"[^}]*"args"[^}]*\{[^}]*\}[^}]*\})', response, re.DOTALL)

    # Pattern 2: ```json {...} ``` or ``` {...} ```
    if not match:
        match = re.search(r'```(?:json)?\s*(\{[^`]*"tool"[^`]*"args"[^`]*\})\s*```', response, re.DOTALL)

    # Pattern 3: bare JSON with "tool" and "args" at end of response
    if not match:
        match = re.search(r'(\{"tool"\s*:\s*"[^"]+"\s*,\s*"args"\s*:\s*\{[^}]*\}\s*\})\s*$', response, re.DOTALL)

    if not match:
        return None

    raw = match.group(1).strip()
    for attempt in [raw, raw.replace("'", '"')]:
        try:
            call = json.loads(attempt)
            if "tool" in call and "args" in call:
                before = response[:match.start()].strip()
                # Clean up markdown artifacts from before text
                before = re.sub(r'```\w*\s*$', '', before).strip()
                return call, before
        except json.JSONDecodeError:
            continue

    return None


def _estimate_tokens(text: str) -> int:
    """Rough token estimate (~4 chars per token)."""
    return len(text) // CHARS_PER_TOKEN + 1


def _get_context_budget(model_name: str) -> int:
    """Get the safe input token budget for a model.

    Uses the 'safe' context limit (conservative for VRAM) minus response reserve.
    Larger models use more VRAM per token, so their safe limit is lower than native.
    """
    model_lower = model_name.lower().strip()
    # Exact match first
    if model_lower in SUPPORTED_MODELS:
        return SUPPORTED_MODELS[model_lower]["safe"] - RESPONSE_RESERVE
    # Prefix match (e.g. "qwen3.5" matches "qwen3.5:4b")
    for model_id, info in SUPPORTED_MODELS.items():
        base = model_id.split(":")[0]
        if model_lower.startswith(base):
            return info["safe"] - RESPONSE_RESERVE
    return DEFAULT_SAFE_CONTEXT - RESPONSE_RESERVE


def _compact_old_messages(old_messages: list[dict]) -> str:
    """Summarize old tool calls and results into a compact context string."""
    files_read = []
    commands_run = []
    key_findings = []

    for msg in old_messages:
        content = msg.get("content", "")
        if "Used read_file" in content or "Used list_files" in content or "Used grep" in content:
            continue  # Skip action markers
        if content.startswith("RESULT of read_file:"):
            # Extract just the filename
            pass
        elif content.startswith("RESULT of list_files:"):
            files = content.split("\n")[1:6]  # First 5 files
            files_read.extend(f.strip() for f in files if f.strip())
        elif content.startswith("RESULT of bash:"):
            cmd_output = content[15:100].strip()
            commands_run.append(cmd_output)
        elif content.startswith("RESULT of"):
            continue
        elif msg["role"] == "assistant" and len(content) > 20:
            # Keep short assistant summaries
            key_findings.append(content[:150])

    parts = ["[Compacted context from earlier in conversation]"]
    if files_read:
        parts.append(f"Files seen: {', '.join(files_read[:10])}")
    if commands_run:
        parts.append(f"Commands run: {'; '.join(commands_run[:5])}")
    if key_findings:
        parts.append(f"Key findings: {'; '.join(key_findings[:3])}")

    return "\n".join(parts) if len(parts) > 1 else parts[0]


def _truncate_history(conversation: list[dict], model: str = "default") -> list[dict]:
    """Smart context management: compact old messages, keep recent ones.

    When context exceeds budget:
    1. Keep the first user message (original task)
    2. Compact old tool calls into a summary
    3. Keep the most recent messages in full
    """
    if len(conversation) <= 3:
        return conversation

    budget = _get_context_budget(model)
    total_tokens = sum(_estimate_tokens(m["content"]) for m in conversation)

    if total_tokens <= budget:
        return conversation

    # Always keep the first message
    first = conversation[0]
    first_tokens = _estimate_tokens(first["content"])
    remaining_budget = budget - first_tokens

    # Walk backwards from the end, keeping recent messages
    remaining = conversation[1:]
    kept = []
    used = 0
    for msg in reversed(remaining):
        msg_tokens = _estimate_tokens(msg["content"])
        if used + msg_tokens > remaining_budget:
            break
        kept.insert(0, msg)
        used += msg_tokens

    dropped = remaining[:len(remaining) - len(kept)]
    result = [first]
    if dropped:
        # Compact the dropped messages into a summary
        summary = _compact_old_messages(dropped)
        result.append({"role": "tool_result", "content": summary})
    result.extend(kept)
    return result


class Agent:
    """ReAct agent that uses an LLM to perform coding tasks."""

    def __init__(self, client: LLMClient, stream: bool = True, status_text: str = ""):
        self.client = client
        self.stream = stream
        self.conversation: list[dict] = []
        self.cwd = os.getcwd()
        self.status_text = status_text  # Bottom bar text to show during generation
        self.files_in_context: list[str] = []
        self.interrupted = False

    def run(self, user_input: str) -> None:
        """Process a user message through the ReAct loop with loop detection."""
        self.conversation.append({"role": "user", "content": user_input})

        # Loop detection state
        tool_call_log: list[str] = []  # Track "tool:args" signatures
        stall_count = 0  # Count consecutive non-tool responses

        self.interrupted = False

        for iteration in range(MAX_ITERATIONS):
            if self.interrupted:
                console.print("\n  [yellow]⚠ Interrupted[/yellow]")
                self._auto_save()
                return

            trimmed = _truncate_history(self.conversation, self.client.model)
            messages = _build_messages(trimmed, self.cwd, self.client)

            # Get response (streaming or not)
            thinking_msg = random.choice(THINKING_MESSAGES)
            if self.stream:
                response = self._stream_response(messages, thinking_msg)
            else:
                with console.status(f"[cyan]{thinking_msg}", spinner="dots"):
                    response = self.client.chat(messages)

            if not response or response.startswith("[Error:"):
                console.print(f"  [red]{response or '[Empty response from model]'}[/red]")
                return

            # Check for tool call
            parsed = _parse_tool_call(response)

            if parsed:
                tool_call, thinking = parsed
                tool_name = tool_call["tool"]
                tool_args = tool_call["args"]
                stall_count = 0  # Reset stall counter — model is making progress

                # Loop detection — check for duplicate tool calls
                call_sig = f"{tool_name}:{json.dumps(tool_args, sort_keys=True)}"
                dup_count = tool_call_log.count(call_sig)
                tool_call_log.append(call_sig)

                if dup_count >= MAX_DUPLICATE_CALLS:
                    console.print(f"\n  [yellow]⚠ Detected loop: {tool_name} called {dup_count + 1} times with same args. Moving on.[/yellow]")
                    self.conversation.append({"role": "user", "content": "You already did this exact tool call. Please move on to the next step or give your final answer."})
                    continue

                # Print thinking text — compact, one line
                if thinking:
                    short = thinking.split("\n")[0][:100].strip()
                    if short:
                        console.print(f"\n  [dim]{short}[/dim]")

                # Tool call — bold and visible with icon
                TOOL_ICONS = {
                    "read_file": "📄", "write_file": "✏️", "edit_file": "🔧",
                    "bash": "💻", "list_files": "📁", "grep": "🔍",
                }
                icon = TOOL_ICONS.get(tool_name, "⚡")
                args_display = []
                for k, v in tool_args.items():
                    if isinstance(v, str) and len(v) > 60:
                        args_display.append(f'{k}="...{len(v)} chars..."')
                    else:
                        args_display.append(f'{k}="{v}"' if isinstance(v, str) else f'{k}={v}')
                args_str = ", ".join(args_display)
                console.print(f"\n  {icon} [bold cyan]{tool_name}[/bold cyan]({args_str})")

                # Execute tool
                result = execute_tool(tool_name, tool_args)

                # Print result summary — compact but informative
                lines = result.split("\n")
                if tool_name == "read_file":
                    console.print(f"  [dim]   ↳ {len(lines)} lines read[/dim]")
                elif tool_name in ("list_files", "grep"):
                    count = min(len(lines), 10)
                    for line in lines[:count]:
                        console.print(f"  [dim]   {line}[/dim]")
                    if len(lines) > count:
                        console.print(f"  [dim]   ... and {len(lines) - count} more[/dim]")
                elif tool_name == "bash":
                    display = result[:300]
                    if len(result) > 300:
                        display += "..."
                    console.print(f"  [dim]   ↳ {display}[/dim]")
                elif tool_name in ("write_file", "edit_file"):
                    console.print(f"  [green]   ↳ {result}[/green]")
                else:
                    display = result[:200] + "..." if len(result) > 200 else result
                    console.print(f"  [dim]   ↳ {display}[/dim]")

                # Add to conversation — truncate large results to save context
                truncated_result = result[:1000] + f"\n...[truncated]" if len(result) > 1000 else result
                # Store the actual ACTION format so the model learns the correct pattern
                action_json = json.dumps({"tool": tool_name, "args": tool_args})
                self.conversation.append({"role": "assistant", "content": f"ACTION: {action_json}"})
                self.conversation.append({"role": "tool_result", "content": f"RESULT:\n{truncated_result}"})

            else:
                stall_count += 1
                response_lower = response.lower()

                # Detect hallucination — model claims to know about files/branches/code
                # without having used any tools in this conversation turn
                hallucination_signs = ["branch", "file", "directory", "folder", "repository",
                                       "i checked", "i can see", "i found", "it contains",
                                       "there is no", "there are no", "it has", "it doesn't have",
                                       "the code", "the file", "the project has"]
                is_hallucinating = (
                    len(tool_call_log) == 0 and  # No tools used yet this turn
                    any(w in response_lower for w in hallucination_signs) and
                    stall_count <= MAX_STALLS
                )

                # Detect narration without action
                narration_words = ["let me check", "i'll read", "i'll look", "let me look",
                                   "i'll start by", "let me start", "i'll explore", "let me explore",
                                   "let me fix", "i'll fix", "let me try", "i'll try"]
                is_narrating = any(w in response_lower for w in narration_words) and stall_count <= MAX_STALLS

                if is_hallucinating:
                    self.conversation.append({"role": "assistant", "content": response})
                    self.conversation.append({"role": "user", "content": "You have NOT checked. You cannot see files or branches without using tools. Use an ACTION now to verify. For example: ACTION: {\"tool\": \"bash\", \"args\": {\"command\": \"git branch -a\"}}"})
                    continue
                elif is_narrating:
                    self.conversation.append({"role": "assistant", "content": response})
                    self.conversation.append({"role": "user", "content": "Use the ACTION tool now. Don't narrate — act."})
                    continue

                if stall_count > MAX_STALLS and iteration > 0:
                    console.print(f"\n  [yellow]⚠ Model stalled ({stall_count} non-tool responses). Treating as final answer.[/yellow]")

                # Final answer
                self.conversation.append({"role": "assistant", "content": response})
                if not self.stream:
                    console.print("\n  [dim]──────[/dim]\n")
                    console.print(f"[#afafff]{response}[/#afafff]")
                    console.print()
                self._auto_save()
                return

        console.print(f"\n  [yellow]⚠ Reached {MAX_ITERATIONS} iterations. Use /clear and try a more specific request.[/yellow]")
        self._auto_save()

    def _stream_response(self, messages: list[dict], thinking_msg: str = "Thinking...") -> str:
        """Stream response tokens, suppressing ACTION lines from display.
        Shows an in-place spinner until the first token arrives."""
        import sys
        import threading
        import time

        chunks: list[str] = []
        buffer = ""
        printing = True
        first_token = False
        stop_spinner = threading.Event()

        # Spinner — overwrites the same line using \r + stderr (so it works in pipes too)
        def spin():
            frames = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
            i = 0
            out = sys.stderr if sys.stderr.isatty() else sys.stdout
            if not out.isatty():
                return
            while not stop_spinner.is_set():
                out.write(f"\r  \033[36m{frames[i % len(frames)]} {thinking_msg}\033[0m")
                out.flush()
                i += 1
                time.sleep(0.1)
            out.write("\r" + " " * (len(thinking_msg) + 10) + "\r")
            out.flush()

        spinner = threading.Thread(target=spin, daemon=True)
        spinner.start()

        # Collect all tokens — show spinner while waiting
        # Ctrl+C during generation sets interrupted flag
        import signal
        original_handler = signal.getsignal(signal.SIGINT)

        def _interrupt_handler(sig, frame):
            self.interrupted = True
            stop_spinner.set()

        signal.signal(signal.SIGINT, _interrupt_handler)

        for chunk in self.client.chat_stream(messages):
            if self.interrupted:
                break
            chunks.append(chunk)
            buffer += chunk

            # Stop spinner on first real content
            if not first_token and chunk.strip():
                stop_spinner.set()
                spinner.join(timeout=0.5)
                first_token = True

        if not first_token:
            stop_spinner.set()
            spinner.join(timeout=0.5)

        signal.signal(signal.SIGINT, original_handler)
        full = "".join(chunks)

        if self.interrupted:
            if first_token:
                sys.stdout.write("\n")
                sys.stdout.flush()
            return full or "[Interrupted]"

        # Check if response contains an ACTION — don't display the thinking here,
        # the agent loop will display it separately with the tool call
        if "ACTION:" in full:
            pass  # Agent loop handles display
        elif first_token:
            # Final answer — print the whole thing cleanly
            sys.stdout.write(f"\n\033[90m  ──────\033[0m\n\n")
            sys.stdout.write(f"\033[38;5;147m{full}\033[0m\n\n")
            sys.stdout.flush()

        return "".join(chunks)

    def _auto_save(self):
        """Save session to disk after each turn."""
        try:
            save_session(self.conversation, self.cwd)
        except Exception:
            pass

    def load_session(self, conversation: list[dict]):
        """Resume a previous session."""
        self.conversation = conversation
        turns = sum(1 for m in conversation if m["role"] == "user")
        console.print(f"  [dim]Resumed session ({turns} turns)[/dim]")

    def add_file(self, path: str):
        """Add a file's contents to the conversation context."""
        full = os.path.abspath(path)
        if not os.path.exists(full):
            console.print(f"  [red]File not found: {path}[/red]")
            return
        try:
            with open(full, "r", encoding="utf-8", errors="replace") as f:
                content = f.read()
            # Truncate large files
            if len(content) > 15000:
                content = content[:15000] + f"\n... [truncated, {len(content)} chars total]"
            self.conversation.append({
                "role": "user",
                "content": f"[File added to context: {path}]\n```\n{content}\n```"
            })
            self.files_in_context.append(path)
            console.print(f"  [green]+ {path}[/green] [dim]({len(content)} chars)[/dim]")
        except Exception as e:
            console.print(f"  [red]Error reading {path}: {e}[/red]")

    def reset(self):
        """Clear conversation history and session."""
        self.conversation = []
        self.files_in_context = []
        from config import clear_session
        clear_session(self.cwd)
        console.print("  [dim]Conversation cleared.[/dim]")
