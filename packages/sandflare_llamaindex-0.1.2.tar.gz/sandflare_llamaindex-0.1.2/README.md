# sandflare-llamaindex

[LlamaIndex](https://docs.llamaindex.ai/) code interpreter tool for [Sandflare](https://sandflare.io) — execute agent-generated code in isolated Firecracker microVM sandboxes.

## Installation

```bash
pip install sandflare-llamaindex
```

## Usage

```python
from llama_index.core.agent import ReActAgent
from llama_index.llms.openai import OpenAI
from sandflare_llamaindex import SandflareCodeInterpreterTool

tool = SandflareCodeInterpreterTool(api_key="sf-...")

agent = ReActAgent.from_tools(
    [tool],
    llm=OpenAI(model="gpt-4o"),
    verbose=True,
)

response = agent.chat("Compute the first 20 Fibonacci numbers and plot them")
print(response)
```

## How it works

Each tool call creates a fresh Sandflare microVM sandbox, runs the code, and returns stdout/stderr to the LlamaIndex agent as a tool response.

## Links

- [Sandflare docs](https://docs.sandflare.io)
- [sandflare Python SDK](https://pypi.org/project/sandflare/)
