"""
sandflare-llamaindex
~~~~~~~~~~~~~~~~~~~~
LlamaIndex tool for Sandflare Firecracker microVM sandboxes.

Usage:
    from sandflare_llamaindex import SandflareCodeInterpreterTool
    from llama_index.core.agent import ReActAgent
    from llama_index.llms.openai import OpenAI

    tool = SandflareCodeInterpreterTool.from_defaults(api_key="pa_live_...")
    agent = ReActAgent.from_tools([tool], llm=OpenAI(model="gpt-4o"), verbose=True)
    response = agent.chat("What is 2**100?")
"""
from __future__ import annotations

from typing import Optional

from llama_index.core.tools import FunctionTool

try:
    from sandflare import Sandbox
except ImportError as e:
    raise ImportError(
        "sandflare package is required. Install with: pip install sandflare"
    ) from e


def _make_run_python(api_key: Optional[str], template_id: str):
    def run_python(code: str) -> str:
        """Execute Python code in an isolated Sandflare Firecracker microVM sandbox.
        Returns the stdout and stderr output. Use for calculations, data analysis,
        file operations, or any code that needs a safe execution environment."""
        sb = Sandbox.create(
            api_key=api_key,
            template_id=template_id,
        )
        try:
            sb.write_file("/tmp/_sf_code.py", code)
            result = sb.exec("python3 /tmp/_sf_code.py")
            parts = []
            if result.stdout:
                parts.append(result.stdout)
            if result.stderr:
                parts.append(f"[stderr] {result.stderr}")
            if result.exit_code != 0:
                parts.append(f"[exit {result.exit_code}]")
            return "\n".join(parts) or "(no output)"
        finally:
            sb.delete()

    return run_python


class SandflareCodeInterpreterTool:
    """Factory for a LlamaIndex FunctionTool that runs Python in a Sandflare sandbox."""

    @classmethod
    def from_defaults(
        cls,
        api_key: Optional[str] = None,
        template_id: str = "",
    ) -> FunctionTool:
        """Create a LlamaIndex FunctionTool backed by a Sandflare sandbox.

        Args:
            api_key: Sandflare API key (or set SANDFLARE_API_KEY env var).
            template_id: Sandbox template — e.g. "ai-agent", "code-interpreter".

        Returns:
            A LlamaIndex FunctionTool ready to add to an agent.
        """
        fn = _make_run_python(api_key, template_id)
        return FunctionTool.from_defaults(fn=fn, name="sandflare_code_interpreter")


__all__ = ["SandflareCodeInterpreterTool"]
