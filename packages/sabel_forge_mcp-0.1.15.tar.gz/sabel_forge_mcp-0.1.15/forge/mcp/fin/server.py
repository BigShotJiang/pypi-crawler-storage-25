"""
forge-fin MCP server
====================
Exposes Intercom Fin AI and automation tools to an AI agent.

Multi-tenant: every tool requires a `workspace` argument that names a folder
under `workspace/<name>/` containing a `forge.json` config. The server reads
each workspace's Intercom access token from an environment variable named
in that config, so a single server process can serve any number of
workspaces without restart.

Run with:
  forge-fin

Workspace tokens must be exported in the shell environment (e.g. via
`~/.secrets`). See CLAUDE.md for the setup flow.
"""

from mcp.server.fastmcp import FastMCP

from forge.mcp.shared_bug_report import report_tool_bug
from forge.mcp.workspaces_tool import list_workspaces
from forge.mcp.fin.tools import (
    ai_content,
    calls,
    data_connectors,
    fin,
    fin_snapshot,
    fin_voice,
    procedures,
    ui_data_connectors,
    ui_fin_attributes,
    ui_workflows,
    workflows,
)

INSTRUCTIONS = """\
This server exposes Intercom Fin AI tools across multiple client workspaces.
Tools fall into three groups with very different audiences:

  CONFIG (audit + implementation): list_*, get_*, create_*, update_*, delete_*
    on data_connectors, content_import_sources, external_pages. Use these to
    audit and provision Fin's knowledge sources and external integrations
    against playbook standards.

  RUNTIME / AUDIT (read-only): list_calls, search_calls, get_call,
    get_call_transcript, get_fin_voice_*. Use these to inspect Fin behaviour
    on real conversations — useful for auditing flow effectiveness.

  STANDALONE API integration: fin_standalone_start, fin_standalone_reply,
    register_fin_voice. Use these ONLY when integrating Fin into an EXTERNAL
    customer channel (3rd-party messenger, custom app, non-Intercom telephony
    provider). Do NOT use these to control Fin behaviour inside
    Intercom-native Inbox conversations — Fin handles those automatically
    when enabled on the inbox.

Plus snapshot_fin_resources, which captures every Fin SDK resource (procedures,
workflows, guidance, audiences, simulations) via the intercom CLI and is the
audit-side companion to snapshot_workspace on forge-workspace. Workflows can
only be exported (not created/updated) via API; export_workflow needs a
workflow_id which you discover by running snapshot_fin_resources first.

Procedures (Fin SDK YAMLs) have their own dedicated tools: list_procedures,
get_procedure, upload_procedure. These shell out to the `intercom fin
procedures` CLI and provide cleaner CRUD than going via snapshot_fin_resources.
Use them for both auditing existing procedures and implementing new ones.

PROCEDURE AUTHORING — composability over prose

When authoring a NEW procedure (not just editing an existing one),
read upload_procedure's docstring fully BEFORE writing any YAML.
Summary: compose from the Fin SDK's structured primitives (conditional
branches, temporary/scratch attributes, data connector calls,
escalations, reusable components) rather than encoding logic in prose
blocks Fin paraphrases at runtime. Workflow:

  1. list_procedures + get_procedure on 2-3 existing procedures in this
     workspace to see the exact YAML schema and primitive names. The
     CLI output is authoritative; the SDK evolves faster than docs.
  2. Sketch the flow as a list of distinct steps; identify which
     primitive each step uses.
  3. Replace any step shaped like "Fin will figure out X" with a
     primitive (a condition on a typed attribute, a data-connector
     lookup, a named escalation, etc.).
  4. Upload, verify with get_procedure, run sample conversations
     through Fin Studio's simulator before going live.

A well-structured procedure is reviewable, deterministic, and minimises
the surface where Fin can hallucinate values or drift from the playbook.
A prose-heavy procedure is none of those things.

UI-AUTOMATION fallbacks for things REST + Fin SDK CLI both refuse:

  - create_fin_attributes            — PREFERRED. Inline list of attributes;
    each {name, description, values=[{value, description}, ...]}. Tool
    materialises the CSV/manifest format internally before driving the UI.
  - create_fin_attributes_from_csv   — only if the partner already has
    CSV files on disk (legacy / batch). Same UI driver underneath.
  - update_data_connector_via_ui    — REST has no PUT/PATCH for data
    connectors; this drives the connector edit page.
  - create_workflow_via_ui          — REST is export-only for workflows;
    this drives the visual builder (creates draft shells only).
  - probe_fin_attributes_ui         — debug helper; dumps DOM structure
    when selectors break (e.g. after Intercom UI redesigns).

These open a visible Chromium window on the user's machine, take minutes
per resource, and need a one-time interactive login. Use them only when
the user explicitly wants the UI path; the REST/CLI tools above remain
the right default for everything they can do.

Every tool except `list_workspaces` requires a `workspace` argument
identifying which workspace to act on. When the user requests an action
that needs Intercom access but does not specify a workspace, call
`list_workspaces` first and ask the user which one to use. Never invent a
workspace name — only use names returned by `list_workspaces`.

BUG REPORTING — when a forge tool fails, do NOT propose to patch it.

If a forge MCP tool fails in a way that looks like a forge bug (UI
selector timing out, REST returning 500/422 with a missing-field
message, tool signature mismatched, etc.), call `report_tool_bug(
tool_name=..., error_summary=..., error_detail=..., args_summary=...)`
to send it to the maintainer's backend (lands at /admin/bugs). Then
tell the partner the bug is reported and a fix will ship in a future
release. Offer a manual workaround in the Intercom UI if applicable.

DO NOT propose to edit forge's source, monkey-patch the tool, or ship
a local fix — partner installs must stay in lockstep with the published
PyPI release. See forge-workspace's INSTRUCTIONS for the full rule.

If the user asks for an action on a workspace that does NOT appear in
`list_workspaces`, the workspace must be created via the `forge` CLI
on their machine first. See the forge-workspace server's INSTRUCTIONS
for the full add procedure (forge workspace add → set token env var →
restart Claude Code). Don't try to call Fin tools against an
unregistered workspace; they'll fail.
"""

mcp = FastMCP("forge-fin", instructions=INSTRUCTIONS)

# ── Workspace discovery ───────────────────────────────────────────────────────
mcp.tool()(list_workspaces)

# ── Bug reporting (every tool surface gets it) ───────────────────────────────
mcp.tool()(report_tool_bug)

# ── Data Connectors (no UPDATE — delete + recreate or use UI) ────────────────
mcp.tool()(data_connectors.list_data_connectors)
mcp.tool()(data_connectors.get_data_connector)
mcp.tool()(data_connectors.create_data_connector)
mcp.tool()(data_connectors.delete_data_connector)
mcp.tool()(data_connectors.list_execution_results)
mcp.tool()(data_connectors.get_execution_result)

# ── AI Content Import Sources ─────────────────────────────────────────────────
mcp.tool()(ai_content.list_content_import_sources)
mcp.tool()(ai_content.get_content_import_source)
mcp.tool()(ai_content.create_content_import_source)
mcp.tool()(ai_content.update_content_import_source)
mcp.tool()(ai_content.delete_content_import_source)

# ── AI External Pages ─────────────────────────────────────────────────────────
mcp.tool()(ai_content.list_external_pages)
mcp.tool()(ai_content.get_external_page)
mcp.tool()(ai_content.create_external_page)
mcp.tool()(ai_content.update_external_page)
mcp.tool()(ai_content.delete_external_page)

# ── Procedures (Fin SDK YAMLs — via intercom CLI shell-out) ──────────────────
mcp.tool()(procedures.list_procedures)
mcp.tool()(procedures.get_procedure)
mcp.tool()(procedures.upload_procedure)

# ── Workflows (read/export only — no create/update/delete via API) ────────────
mcp.tool()(workflows.export_workflow)

# ── Calls (read-only — useful for auditing Fin Voice usage) ──────────────────
mcp.tool()(calls.list_calls)
mcp.tool()(calls.search_calls)
mcp.tool()(calls.get_call)
mcp.tool()(calls.get_call_transcript)

# ── Fin Standalone API (external channel integration ONLY) ───────────────────
mcp.tool()(fin.fin_standalone_reply)
mcp.tool()(fin.fin_standalone_start)

# ── Fin Voice (register = external integration; get_* = read-only audit) ─────
mcp.tool()(fin_voice.register_fin_voice)
mcp.tool()(fin_voice.get_fin_voice_conversation)
mcp.tool()(fin_voice.get_fin_voice_by_external_id)
mcp.tool()(fin_voice.get_fin_voice_by_phone)
mcp.tool()(fin_voice.get_fin_voice_collect)

# ── Fin SDK snapshot (audit foundation — partner to snapshot_workspace) ──────
mcp.tool()(fin_snapshot.snapshot_fin_resources)

# ── Fin attributes UI automation (REST + Fin SDK CLI both refuse) ────────────
mcp.tool()(ui_fin_attributes.create_fin_attributes)
mcp.tool()(ui_fin_attributes.create_fin_attributes_from_csv)
mcp.tool()(ui_fin_attributes.probe_fin_attributes_ui)

# ── Data connectors UI update (REST has no PUT/PATCH) ────────────────────────
mcp.tool()(ui_data_connectors.update_data_connector_via_ui)

# ── Workflows UI create (REST is export-only) ────────────────────────────────
mcp.tool()(ui_workflows.create_workflow_via_ui)


def main():
    import sys
    from forge import license as lic

    try:
        lic.gate_startup()
    except lic.LicenseError as e:
        print(f"[forge-fin] {e}", file=sys.stderr)
        sys.exit(1)

    mcp.run()


if __name__ == "__main__":
    main()
