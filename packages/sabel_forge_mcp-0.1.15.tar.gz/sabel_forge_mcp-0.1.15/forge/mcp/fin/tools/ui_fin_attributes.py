"""MCP tools for the Fin attributes UI script.

Fin attributes (conversation-scoped enums Fin reasons over) are NOT
creatable via REST or the intercom CLI's Fin SDK — they live behind
the Fin Studio UI at /automation/fin-ai-agent/attributes. These
wrappers shell out to the Playwright script that drives that UI.
"""
from __future__ import annotations

import csv
import shutil
import tempfile
import uuid
from pathlib import Path

from forge import paths
from forge.mcp.shared_ui import run_ui_script


_MODULE = "forge.ui_automation.fin_attributes"


def create_fin_attributes_from_csv(
    workspace: str,
    csv_dir: str,
    dry_run: bool = False,
) -> dict:
    """Create Fin attributes by driving the Intercom Fin Studio UI.

    SIDE EFFECT — opens a visible Chromium window on the user's machine.
    First run requires the user to log in to Intercom interactively;
    cookies persist per-workspace under
    `forge/ui_automation/.profiles/<workspace>/`.

    USE THIS WHEN — the user wants to bulk-create Fin attributes from
    CSV files. There is no REST or CLI alternative; POST /data_attributes
    refuses model="conversation", and `intercom fin attributes` only
    supports `list`.

    csv_dir: directory containing `fin_attribute_<Name>.csv` files (one
        per attribute; rows of `value,description`). Plus an optional
        `_manifest.yaml` providing per-attribute metadata:
            attributes:
              <NameStem>:
                description: "Required attribute-level description (the
                              UI requires this; runs without it fail
                              with 'Attribute not saved')."
                name_override: "Optional display-name override"
        Absolute paths used as-is; relative paths resolve against the
        workspace directory (workspace/<Industry>/<Name>/).

    dry_run: if True, parse CSVs and print what would be created;
        no UI writes.

    Returns: subprocess result dict with `command`, `exit_code`,
    `stdout`, `stderr`. Stdout contains the per-attribute CREATE /
    SKIP / created / failed lines plus a SUMMARY block. Non-zero
    exit_code means the script crashed (not just per-attribute
    failures, which are reported in stdout).

    Timing: ~30-60s per attribute end-to-end on a populated workspace.
    A bulk run of ~25 attributes typically takes 15-25 minutes.
    """
    return run_ui_script(
        workspace,
        _MODULE,
        mode="--dry-run" if dry_run else "--create",
        csv_dir=csv_dir,
    )


def create_fin_attributes(
    workspace: str,
    attributes: list[dict],
    dry_run: bool = False,
) -> dict:
    """Create Fin attributes from inline definitions — no CSV files needed.

    PREFERRED tool for creating Fin attributes from an agent. Internally
    writes the CSVs + manifest the underlying Playwright script expects,
    then drives the Fin Studio UI. The CSV file format is an
    implementation detail you don't need to think about.

    SIDE EFFECT — opens a visible Chromium window. First run requires
    interactive Intercom login; cookies persist per-workspace.

    USE THIS WHEN — the user wants to bulk-create Fin attributes. The
    only alternative is `create_fin_attributes_from_csv`, which is for
    partners who already have CSV files on disk.

    Each element of `attributes` is a dict with:
        name (required, str)         — display name shown in Fin Studio
        description (required, str)  — attribute-level description Fin
                                       reasons over. Required by the UI;
                                       runs without it fail.
        values (required, list)      — at least 2 entries. Each entry is
                                       either {"value": "...", "description": "..."}
                                       (preferred — Fin uses the per-option
                                       description to pick a value) or a
                                       bare string (description defaults
                                       to the value).
        name_override (optional, str) — if the display name should differ
                                       from the dict key. Rarely needed.

    Example:
        attributes=[
            {
                "name": "Sentiment",
                "description": "Conversation sentiment classification.",
                "values": [
                    {"value": "positive", "description": "User expresses satisfaction."},
                    {"value": "neutral",  "description": "Matter-of-fact tone."},
                    {"value": "negative", "description": "User frustrated or upset."},
                ],
            },
            {
                "name": "Urgency",
                "description": "How urgent the conversation is.",
                "values": [
                    {"value": "low",    "description": "Routine question, no time pressure."},
                    {"value": "medium", "description": "Regular issue."},
                    {"value": "high",   "description": "Locked out / payment failing / urgent business impact."},
                ],
            },
        ]

    dry_run: if True, write the CSVs + manifest, validate, print what
        would be created, but don't open the browser.

    Returns the same subprocess result dict as
    create_fin_attributes_from_csv: {command, exit_code, stdout, stderr}.
    On non-zero exit, the temp directory containing the generated CSVs
    is preserved at the path printed in stdout for debugging.
    """
    if not attributes:
        raise ValueError("create_fin_attributes: `attributes` is empty.")

    # Write CSVs + manifest into ~/.forge/cache/fin_attrs/<run-id>/
    # so they outlive a tmp-cleanup on macOS reboot but stay outside
    # any client workspace directory.
    runs_root = paths.ensure_dir(paths.cache_dir() / "fin_attrs")
    run_dir = runs_root / f"run-{uuid.uuid4().hex[:8]}"
    run_dir.mkdir(parents=True, exist_ok=False)

    manifest_lines = ["attributes:"]

    for attr in attributes:
        name = attr.get("name")
        description = attr.get("description")
        values = attr.get("values") or []

        if not name or not isinstance(name, str):
            raise ValueError(
                f"create_fin_attributes: each attribute needs a string `name`. Got: {attr!r}"
            )
        if not description:
            raise ValueError(
                f"create_fin_attributes: attribute '{name}' is missing required `description`. "
                f"The Fin Studio UI rejects attributes without one."
            )
        if len(values) < 2:
            raise ValueError(
                f"create_fin_attributes: attribute '{name}' needs at least 2 `values` "
                f"(Fin requires it). Got {len(values)}."
            )

        csv_path = run_dir / f"fin_attribute_{name}.csv"
        with csv_path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            # No header row — load_csv_dir treats every row as a data
            # option, so a "value,description" header would create a
            # junk option literally named "value" with description
            # "description". Format is implicit two columns.
            for v in values:
                if isinstance(v, str):
                    writer.writerow([v, v])
                elif isinstance(v, dict):
                    val = v.get("value")
                    desc = v.get("description") or val
                    if not val:
                        raise ValueError(
                            f"create_fin_attributes: attribute '{name}' has a value entry "
                            f"missing `value`: {v!r}"
                        )
                    writer.writerow([val, desc])
                else:
                    raise ValueError(
                        f"create_fin_attributes: attribute '{name}' value must be str or dict, "
                        f"got {type(v).__name__}: {v!r}"
                    )

        # Manifest entry — escape any quotes/newlines in the description.
        safe_desc = description.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n")
        manifest_lines.append(f"  {name}:")
        manifest_lines.append(f'    description: "{safe_desc}"')
        if attr.get("name_override"):
            safe_override = attr["name_override"].replace('"', '\\"')
            manifest_lines.append(f'    name_override: "{safe_override}"')

    (run_dir / "_manifest.yaml").write_text("\n".join(manifest_lines) + "\n", encoding="utf-8")

    print(f"[create_fin_attributes] generated CSVs at: {run_dir}")
    result = run_ui_script(
        workspace,
        _MODULE,
        mode="--dry-run" if dry_run else "--create",
        csv_dir=str(run_dir),
    )
    result["run_dir"] = str(run_dir)
    if result.get("exit_code") == 0 and not dry_run:
        # Successful create — remove the generated CSVs to avoid clutter.
        try:
            shutil.rmtree(run_dir)
            result["run_dir_cleaned_up"] = True
        except OSError:
            pass
    return result


def probe_fin_attributes_ui(
    workspace: str,
    probe_create_form: bool = False,
) -> dict:
    """Probe the Fin attributes UI to dump headings, buttons, inputs,
    and a screenshot. Read-only — no writes. Use this when the create
    flow is failing and selectors need verification (e.g. after an
    Intercom UI redesign).

    probe_create_form: if True, click "New" and probe the create form
        (General tab → Values tab → New value sub-form). If False, just
        probe the index page.
    """
    return run_ui_script(
        workspace,
        _MODULE,
        mode="--probe-create-form" if probe_create_form else "--probe",
    )
