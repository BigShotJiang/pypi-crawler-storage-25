"""Fin SDK procedures via the intercom CLI.

Procedures are YAML-defined Fin agent capabilities — they describe
multi-step conversations Fin can run (data collection, branching, data
connector calls, response composition). Intercom's REST API does NOT
expose procedures; the only programmatic path is the `intercom fin
procedures` CLI.

These tools shell out to that CLI with `INTERCOM_TOKEN` scoped per
workspace (same pattern as `snapshot_fin_resources`) so the CLI's
persisted auth state is never mutated.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path

from forge.workspace_config import get_intercom_token, workspace_dir


def _resolve_cli() -> str:
    cli = shutil.which("intercom")
    if not cli:
        raise RuntimeError(
            "intercom CLI not found on PATH. Install @intercom/cli and retry."
        )
    return cli


def _run_capture(args: list[str], token: str, timeout: int = 60) -> str:
    """Run an `intercom` CLI subcommand with INTERCOM_TOKEN scoped, capture
    stdout, raise on non-zero exit. Returns stdout as a string."""
    cli = _resolve_cli()
    env = {**os.environ, "INTERCOM_TOKEN": token}
    result = subprocess.run(
        [cli, *args],
        capture_output=True,
        text=True,
        timeout=timeout,
        env=env,
    )
    if result.returncode != 0:
        raise RuntimeError(
            f"`intercom {' '.join(args)}` failed (exit {result.returncode}): "
            f"{result.stderr.strip() or result.stdout.strip()}"
        )
    return result.stdout


def list_procedures(workspace: str) -> list[dict]:
    """List every Fin procedure in the workspace.

    Useful for AUDITING — comparing the workspace's procedures against
    playbook recommendations for the industry, or finding procedures by
    name to fetch their full YAML for review.

    Returns a list of {id, name} dicts (CLI summary view). Use
    get_procedure(workspace, id) to fetch the full YAML for any procedure.

    LIMITATION: procedures are not exposed via REST. This shells out to
    `intercom fin procedures list --json` with INTERCOM_TOKEN scoped to
    the requested workspace.
    """
    token = get_intercom_token(workspace)
    out = _run_capture(["fin", "procedures", "list", "--json"], token)
    if not out.strip():
        return []
    return json.loads(out)


def get_procedure(workspace: str, procedure_id: str) -> dict:
    """Retrieve a single procedure's full YAML definition by ID.

    Useful for AUDITING (review what a procedure does), for COPYING a
    procedure between workspaces (get from source, upload_procedure to
    target), or — most importantly — as a SCHEMA REFERENCE before
    authoring a new procedure. The Fin SDK YAML keys evolve; rather than
    relying on a static schema doc, fetch 2-3 working procedures from
    the same workspace and mirror their use of conditionals, scratch
    attributes, data connector calls, and escalations. See
    upload_procedure's docstring for the authoring guidance.

    procedure_id: the procedure's ID (use list_procedures to discover).

    Returns a dict with:
      - id: the procedure id
      - yaml: the full YAML definition as a single string (suitable to
        write to disk and feed into upload_procedure unchanged)

    Shells out to `intercom fin procedures get <id>`.
    """
    token = get_intercom_token(workspace)
    out = _run_capture(["fin", "procedures", "get", procedure_id], token)
    return {"id": procedure_id, "yaml": out}


def upload_procedure(workspace: str, file_path: str) -> dict:
    """Upload a procedure YAML file to the workspace, creating or updating
    a procedure (the file's metadata determines the target).

    Used during IMPLEMENTATION — once you've authored a procedure YAML
    (manually or via agent), this pushes it to the workspace. Pair with
    list_procedures + get_procedure to verify after upload.

    AUTHORING GUIDANCE — read before writing a new procedure
    --------------------------------------------------------
    Compose procedures from the Fin SDK's structured primitives. Don't
    encode logic, state, or branching in prose — Fin will paraphrase
    prose differently across runs and miss edge cases. Use the explicit
    primitives the SDK exposes:

      • Conditional branches → for any "if X then Y else Z" decision.
        Branch on a typed attribute, not on Fin re-reading the
        conversation. Examples: branch on `loyalty_tier`, on whether a
        data-connector call succeeded, on the user's collected answer.

      • Temporary / scratch attributes → capture state as soon as you
        have it (collected from the user, returned by a data connector,
        derived from a lookup). Subsequent steps reference the attribute,
        not the conversation history. Minimises hallucination of values
        Fin "thought it heard" earlier. Mark them temporary so they
        don't bloat the contact's permanent record.

      • Data connector calls → look up authoritative state (order id,
        subscription tier, KYC status, account balance) instead of
        asking the user to repeat themselves or asking Fin to guess.
        Surface the response into a scratch attribute and branch on it.

      • Escalations → hand off to a named team with explicit reason +
        captured context (the scratch attributes you've collected).
        Don't write "if this is complex, escalate" — encode the exact
        triggers (sentiment threshold, missing data, regulatory keyword
        match) as conditions that fire an escalation step.

      • Reusable components → if the same collection pattern appears in
        multiple procedures (e.g. "verify identity before refund"),
        extract it as a shared component and reference it. Don't
        re-author the same prose three times.

    Anti-patterns to avoid
    ----------------------
    × One-step procedures with the entire flow in a single prose block
      ("if the customer wants a refund, check their order, if it's
      under 30 days then issue, otherwise tell them no"). Always split
      into discrete steps.
    × Asking the user for information Fin can look up via a data
      connector. Lookup beats interrogation.
    × Free-text decision points ("decide if this is urgent"). Replace
      with explicit conditions on collected attributes.
    × Pushing values into permanent contact attributes when they were
      only relevant to this conversation — use scratch/temporary
      attributes instead.
    × Mixing escalation logic into the response message ("I'll get a
      human" inside an `say` block). Use the escalation primitive so
      Intercom routes properly.

    Recommended workflow
    --------------------
    1. Run list_procedures + get_procedure on 2-3 existing procedures
       in this workspace (or a similar one) to see the exact YAML
       schema and primitive names — these CLI outputs are
       authoritative; the SDK evolves.
    2. Sketch the flow as a list of distinct steps before writing YAML.
       For each step, identify which primitive it uses.
    3. Author. Re-read; if any step is "Fin will figure out X",
       you're encoding control flow as prose. Replace with a primitive.
    4. upload_procedure → verify with get_procedure → run a few sample
       conversations against it (Fin Studio has a simulator) before
       making it live.

    Parameters
    ----------
    file_path: path to the YAML file. Absolute paths used as-is; relative
        paths are resolved against the workspace directory
        (workspace/<Name>/) so e.g. "procedures/my_proc.yaml" resolves to
        "workspace/<Name>/procedures/my_proc.yaml".

    Returns the parsed CLI output (id, status fields if any). Raises on
    non-zero exit.

    Shells out to `intercom fin procedures upload <file> --json`.
    """
    token = get_intercom_token(workspace)
    p = Path(file_path).expanduser()
    if not p.is_absolute():
        p = workspace_dir(workspace) / p
    p = p.resolve()
    if not p.exists():
        raise RuntimeError(f"Procedure file not found: {p}")
    out = _run_capture(["fin", "procedures", "upload", str(p), "--json"], token, timeout=120)
    parsed: dict = {"file": str(p)}
    if out.strip():
        try:
            data = json.loads(out)
            if isinstance(data, dict):
                parsed.update(data)
            else:
                parsed["raw"] = data
        except json.JSONDecodeError:
            parsed["raw_output"] = out.strip()
    return parsed
