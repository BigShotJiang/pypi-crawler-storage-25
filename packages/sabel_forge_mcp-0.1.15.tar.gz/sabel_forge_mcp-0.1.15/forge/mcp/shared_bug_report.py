"""report_tool_bug — agent-side bug reporting.

Shared by both forge-workspace and forge-fin (bugs in either tool surface
flow back to one /admin/bugs queue on forge-mcp-api).

The agent calls this when a forge tool fails in a way that looks like a
forge bug — UI selector drift, payload rejected, signature mismatch,
missing required field, undocumented Intercom behavior. The maintainer
sees it on /admin/bugs and patches a new release.

This is NOT for partner mistakes (e.g. they passed a non-existent
workspace, their token expired) — those don't deserve a bug ticket.
"""
from __future__ import annotations

import os

import httpx

from forge import license as lic


def _backend_url() -> str:
    return os.environ.get("FORGE_API_URL", lic.DEFAULT_BACKEND_URL).rstrip("/")


def report_tool_bug(
    tool_name: str,
    error_summary: str,
    error_detail: str | None = None,
    args_summary: dict | list | str | None = None,
) -> dict:
    """Report a forge bug to the maintainer.

    Call this when a forge MCP tool fails in a way that suggests a forge
    bug — NOT when a partner passed bad input or Intercom is having an
    outage. Examples of bugs to report:

      • A Playwright selector times out, indicating the Intercom UI shape
        has changed (CSV upload no longer exposes <input type="file">,
        a tab was renamed, etc.).
      • A REST POST returns 500/422 because the tool is sending a payload
        that's missing a now-required field (e.g. missing data_type).
      • An MCP tool's signature doesn't match what its docstring promises.
      • A claimed-supported feature plain doesn't work end-to-end.

    NOT bugs to report (don't bother the maintainer):

      • Workspace not found (partner needs to forge workspace add).
      • Intercom 401 (partner's token is wrong/expired).
      • Intercom 429 (rate limit — retry with backoff).
      • Tool refusing to run because license is inactive.

    What to send:

      tool_name: exact MCP tool name that failed (e.g. "create_data_attribute").
      error_summary: one-line description of what went wrong, < 500 chars.
                     Be specific: "POST /data_attributes returned 500
                     because data_type was not in the payload" beats
                     "the create attribute tool failed".
      error_detail: optional longer text — full error message, traceback
                    excerpt, screenshot path, anything that helps diagnose.
                    < 20 KB.
      args_summary: optional dict/list/str of the arguments at the call
                    site, with anything sensitive (tokens, customer PII)
                    REDACTED. Don't blindly forward partner data.

    What the agent should ALSO do (the rule, repeated for emphasis):

      • Tell the partner the bug has been reported and the maintainer
        will fix it in a future release.
      • Offer a manual workaround in the Intercom UI if there is one.
      • DO NOT propose to edit forge's source code, monkey-patch the
        tool, or ship a "fix" yourself. Forge is a maintained
        distribution; out-of-band patches diverge partner installs and
        bypass the watermarking + license enforcement.

    Returns: {received: bool, id: int} on success, or {received: False,
    error: str} if the report endpoint is unreachable. The function
    NEVER raises — failing to report a bug should never compound the
    original failure.
    """
    payload = {
        "tool_name": tool_name[:128],
        "error_summary": error_summary[:500],
        "error_detail": (error_detail[:20000] if error_detail else None),
        "args_summary": args_summary,
        "machine_id_hash": lic.machine_id_hash(),
        "client_version": lic._client_version(),
    }

    cached = lic.load_cache()
    if cached is None:
        return {"received": False, "error": "no license cache; cannot authenticate"}

    try:
        resp = httpx.post(
            f"{_backend_url()}/v1/bugs/report",
            headers={"Authorization": f"Bearer {cached.api_key}"},
            json=payload,
            timeout=10.0,
        )
    except httpx.HTTPError as e:
        return {"received": False, "error": f"network: {e}"}

    if resp.status_code != 200:
        return {"received": False, "error": f"backend returned HTTP {resp.status_code}"}
    try:
        data = resp.json()
    except ValueError:
        return {"received": False, "error": "malformed backend response"}
    return {"received": True, "id": data.get("id")}
