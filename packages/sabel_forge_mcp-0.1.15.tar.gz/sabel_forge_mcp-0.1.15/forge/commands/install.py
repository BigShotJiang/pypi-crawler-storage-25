"""One-shot installer subcommands.

The forge core install (`uv tool install sabel-forge-mcp` or `pipx install
sabel-forge-mcp`) is REST-only by default — it doesn't pull Playwright or
Chromium since both are heavy and not all partners use the UI tools.

Run `forge install ui-deps` to add what's needed for the Playwright-driven
UI automation tools (create_*_via_ui on forge-workspace, the Fin
attributes/data connector/workflow UI tools on forge-fin).
"""
from __future__ import annotations

import importlib
import shutil
import subprocess
import sys

import click


@click.group("install")
def install_group():
    """Setup helpers for forge."""


def _detect_install_method() -> str:
    """Best-effort detection based on sys.prefix path. Returns one of
    'uv', 'pipx', or 'pip' — drives the suggested reinstall command.

    Heuristic, not perfect; if we're wrong the printed alternatives
    cover the other paths."""
    p = sys.prefix
    if "uv/tools" in p:
        return "uv"
    if "pipx/venvs" in p or "pipx" in p:
        return "pipx"
    return "pip"


def _reinstall_instructions() -> str:
    """Multi-method instructions for adding the ui-automation extra.
    Lists the detected method first and the others as alternatives."""
    method = _detect_install_method()
    cmds = {
        "uv":   "  uv tool install 'sabel-forge-mcp[ui-automation]' --reinstall",
        "pipx": "  pipx inject sabel-forge-mcp playwright pyyaml",
        "pip":  "  pip install --upgrade 'sabel-forge-mcp[ui-automation]'",
    }
    primary = cmds.pop(method)
    alternatives = "\n".join(cmds.values())
    return (
        f"Looks like a {method.upper()} install, so try:\n"
        f"{primary}\n"
        f"\n"
        f"If that's not how you installed forge, use whichever matches:\n"
        f"{alternatives}\n"
        f"\n"
        f"Then re-run `forge install ui-deps`."
    )


def _try_pip_install_extras() -> bool:
    """Attempt `<sys.executable> -m pip install` for the ui-automation
    deps. Works in pip-managed envs; usually fails in uv tool / pipx
    venvs because they don't include pip itself.

    Returns True if playwright is importable afterwards, else False.

    pyyaml is a required dep as of 0.1.10, so it should already be
    importable — included here as a safety net for legacy installs
    upgrading from <=0.1.9 where pyyaml lived in the ui-automation
    extra and might be missing.
    """
    cmd = [sys.executable, "-m", "pip", "install", "playwright>=1.45", "pyyaml>=6.0"]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False
    if result.returncode != 0:
        return False
    importlib.invalidate_caches()
    try:
        importlib.import_module("playwright")
        return True
    except ImportError:
        return False


@install_group.command("ui-deps")
@click.option(
    "--browser",
    default="chromium",
    show_default=True,
    help="Which Playwright browser to install. Forge only drives Chromium.",
)
@click.option(
    "--with-system-deps",
    is_flag=True,
    help=(
        "Also run `playwright install-deps` (Linux only — installs system "
        "libraries Chromium needs). Requires sudo."
    ),
)
def install_ui_deps(browser: str, with_system_deps: bool) -> None:
    """Install Playwright + Chromium so the UI-automation tools work.

    Two phases:
      1. Add the playwright + pyyaml Python deps to forge's venv (if
         missing). For pip-installed forge this just works via
         `python -m pip install`. For uv tool / pipx installs, pip
         isn't in the venv — we print the right reinstall command.
      2. `playwright install <browser>` to download the actual browser
         binary (~150 MB).

    Idempotent — safe to re-run.
    """
    try:
        import playwright  # noqa: F401
    except ImportError:
        click.echo("Playwright Python package not found in forge's venv. Trying pip install ...")
        if not _try_pip_install_extras():
            click.echo("\n" + _reinstall_instructions(), err=True)
            sys.exit(1)
        click.echo("Playwright installed.")

    cli = shutil.which("playwright")
    if not cli:
        click.echo(
            "Playwright Python package is installed but the `playwright` CLI "
            "isn't on PATH. The CLI ships in the same venv as the package — "
            "make sure forge's bin/ directory is on PATH.",
            err=True,
        )
        sys.exit(1)

    click.echo(f"Installing Playwright browser: {browser} ...")
    rc = subprocess.call([cli, "install", browser])
    if rc != 0:
        sys.exit(rc)

    if with_system_deps:
        click.echo("Installing system dependencies (may prompt for sudo) ...")
        rc = subprocess.call([cli, "install-deps", browser])
        if rc != 0:
            sys.exit(rc)

    click.echo("UI dependencies installed.")
