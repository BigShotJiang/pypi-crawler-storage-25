"""
Create Intercom Fin attributes via the admin UI.

Fin attributes are conversation-scoped enums Fin reasons over (e.g.
Sentiment with options positive/negative/neutral). They live in the UI
under /automation/fin-ai-agent/attributes. There is NO REST API path:
- POST /data_attributes refuses model="conversation"
- POST with options=[{value, description}] silently drops description
- intercom CLI's `fin attributes` only supports list, not upload
So Playwright is the only path.

Form structure (probed against Migr8now):
  - Click "New" on the index → side panel with tabs General / Values / Conditions
  - General tab:
      input[name="name"]              attribute name
      textarea[name="description"]    attribute-level description Fin reasons over
  - Values tab:
      "+ New value" button + per-value form (label + description)
      "Upload CSV" button + hidden file input — the path this script uses,
      since the user's CSVs already have the right two-column shape
  - "Save" button at top right commits.
  - Attribute is created in Disabled state; "Enable" turns it live.

Input format: a directory of CSV files matching the format the user
already has on disk:

    <csv_dir>/fin_attribute_<Name>.csv
        value1,description1
        value2,description2
        ...

The attribute name is derived from the filename (suffix after
`fin_attribute_`, with underscores → spaces unless --keep-underscores).

Optionally, a `_manifest.yaml` in the same directory provides per-
attribute metadata that isn't in the CSV:

    attributes:
      Sentiment:
        description: "Categorise the customer's tone."
      Source_Channel:
        name_override: "Source Channel"
        description: "Where the conversation originated."

Usage:
    # Probe the index page to find New / Add button selectors
    uv run python -m forge.ui_automation.fin_attributes \\
        --workspace Migr8now_Workspace --probe

    # Probe the create form (clicks New, dumps form structure)
    uv run python -m forge.ui_automation.fin_attributes \\
        --workspace Migr8now_Workspace --probe-create-form

    # Dry run — parse CSV dir, print what would be created
    uv run python -m forge.ui_automation.fin_attributes \\
        --workspace Migr8now_Workspace --dry-run \\
        --csv-dir /Users/gregyd/Downloads/fin_attributes_migration_3

    # Create
    uv run python -m forge.ui_automation.fin_attributes \\
        --workspace Migr8now_Workspace --create \\
        --csv-dir /Users/gregyd/Downloads/fin_attributes_migration_3
"""
from __future__ import annotations

import argparse
import asyncio
import csv
import time
from dataclasses import dataclass, field
from pathlib import Path

import yaml

from forge.ui_automation.session import (
    ensure_logged_in,
    intercom_session,
    resolve_app_id,
    screenshot,
)

INDEX_PATH = "/automation/fin-ai-agent/attributes"

# Selector candidates — the first probe run will tell us which to lock in.
NEW_BUTTON_LABELS = [
    "New attribute",
    "Add attribute",
    "Create attribute",
    "New",
    "Add",
    "Create",
]
# ────────────────────────────────────────────────────────────────────
# Payload model
# ────────────────────────────────────────────────────────────────────


@dataclass
class FinAttributeOption:
    value: str
    description: str = ""


@dataclass
class FinAttribute:
    name: str
    options: list[FinAttributeOption] = field(default_factory=list)
    description: str = ""
    source_file: str = ""


def _filename_to_attr_name(stem: str, *, keep_underscores: bool) -> str:
    """`fin_attribute_Source_Channel` → `Source Channel` (or `Source_Channel`)."""
    prefix = "fin_attribute_"
    if not stem.startswith(prefix):
        return stem
    name = stem[len(prefix):]
    if keep_underscores:
        return name
    return name.replace("_", " ")


def load_csv_dir(csv_dir: Path, *, keep_underscores: bool = False) -> list[FinAttribute]:
    """Read every fin_attribute_*.csv in csv_dir into FinAttribute objects.

    A `_manifest.yaml` (if present) provides attribute-level descriptions
    and name overrides keyed by filename stem.
    """
    if not csv_dir.is_dir():
        raise SystemExit(f"--csv-dir {csv_dir} is not a directory")

    manifest_path = csv_dir / "_manifest.yaml"
    manifest: dict = {}
    if manifest_path.exists():
        loaded = yaml.safe_load(manifest_path.read_text()) or {}
        manifest = (loaded.get("attributes") or {}) if isinstance(loaded, dict) else {}

    attrs: list[FinAttribute] = []
    files = sorted(csv_dir.glob("fin_attribute_*.csv"))
    if not files:
        raise SystemExit(f"No fin_attribute_*.csv files found in {csv_dir}")

    for path in files:
        stem = path.stem  # e.g. "fin_attribute_Sentiment"
        suffix = stem[len("fin_attribute_"):] if stem.startswith("fin_attribute_") else stem
        meta = manifest.get(suffix, {}) if isinstance(manifest, dict) else {}

        name = meta.get("name_override") or _filename_to_attr_name(stem, keep_underscores=keep_underscores)
        description = meta.get("description", "") or ""

        opts: list[FinAttributeOption] = []
        with path.open(newline="", encoding="utf-8") as fh:
            reader = csv.reader(fh)
            for row in reader:
                if not row:
                    continue
                value = (row[0] or "").strip()
                if not value:
                    continue
                desc = (row[1].strip() if len(row) > 1 else "")
                opts.append(FinAttributeOption(value=value, description=desc))

        attrs.append(FinAttribute(
            name=name,
            options=opts,
            description=description,
            source_file=str(path),
        ))

    return attrs


# ────────────────────────────────────────────────────────────────────
# Probe modes
# ────────────────────────────────────────────────────────────────────


async def go_to_index(page, workspace: str):
    app_id = resolve_app_id(workspace)
    url = f"https://app.intercom.com/a/apps/{app_id}{INDEX_PATH}"
    print(f"[fin-attr] navigating to {url}")
    await page.goto(url, wait_until="domcontentloaded")
    try:
        await page.wait_for_load_state("networkidle", timeout=12_000)
    except Exception:
        pass
    await page.wait_for_timeout(800)


async def click_new_button(page) -> str:
    """Try each candidate label; return the one that worked."""
    for label in NEW_BUTTON_LABELS:
        loc = page.get_by_role("button", name=label).first
        try:
            if await loc.count() and await loc.is_visible():
                print(f"[fin-attr] clicking '{label}'")
                await loc.click()
                await page.wait_for_timeout(1500)
                try:
                    await page.wait_for_load_state("networkidle", timeout=6_000)
                except Exception:
                    pass
                return label
        except Exception:
            continue
    raise RuntimeError(
        f"Could not find a New/Add/Create button on {page.url}. "
        f"Tried: {NEW_BUTTON_LABELS}. Run --probe to dump visible buttons."
    )


async def probe_page(page) -> dict:
    info: dict = {"url": page.url, "page_title": await page.title()}
    try:
        all_buttons = await page.get_by_role("button").all_inner_texts()
        info["visible_buttons"] = [b.strip() for b in all_buttons if b.strip()][:80]
    except Exception as e:
        info["visible_buttons_error"] = str(e)
    try:
        headings = await page.locator("h1, h2, h3, h4, [role='heading']").all_inner_texts()
        info["headings"] = [h.strip() for h in headings if h.strip()][:40]
    except Exception as e:
        info["headings_error"] = str(e)
    try:
        inputs = page.locator("input, textarea")
        descriptors = []
        for i in range(min(await inputs.count(), 30)):
            el = inputs.nth(i)
            descriptors.append({
                "tag": await el.evaluate("el => el.tagName"),
                "type": await el.get_attribute("type"),
                "placeholder": await el.get_attribute("placeholder"),
                "aria-label": await el.get_attribute("aria-label"),
                "name": await el.get_attribute("name"),
            })
        info["inputs"] = descriptors
    except Exception as e:
        info["inputs_error"] = str(e)
    return info


async def run_probe(workspace: str):
    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)
        await go_to_index(page, workspace)
        info = await probe_page(page)
        shot = await screenshot(page, f"fin-attr-index-{workspace}")
        _print_probe("FIN ATTRIBUTES INDEX PROBE", info, shot)


async def run_probe_create_form(workspace: str):
    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)
        await go_to_index(page, workspace)
        label = await click_new_button(page)

        # Tab 1: General (default)
        info = await probe_page(page)
        info["new_button_clicked"] = label
        shot = await screenshot(page, f"fin-attr-create-general-{workspace}")
        _print_probe("FIN ATTRIBUTES — GENERAL TAB", info, shot)

        # Tab 2: Values — click and probe.
        values_tab_clicked = False
        for tab_label in ("Values", "Options", "Choices"):
            tab = page.get_by_role("tab", name=tab_label).first
            try:
                if await tab.count() and await tab.is_visible():
                    print(f"\n[fin-attr] clicking tab {tab_label!r}")
                    await tab.click()
                    await page.wait_for_timeout(1200)
                    info_v = await probe_page(page)
                    info_v["tab_clicked"] = tab_label
                    shot_v = await screenshot(page, f"fin-attr-create-values-{workspace}")
                    _print_probe(f"FIN ATTRIBUTES — {tab_label.upper()} TAB", info_v, shot_v)
                    values_tab_clicked = True
                    break
            except Exception as e:
                print(f"[fin-attr] tab {tab_label!r} click failed: {e}")
        if not values_tab_clicked:
            print("\n[fin-attr] could not locate a Values/Options/Choices tab")
            return

        # Click "+ New value" to expose the per-value field structure.
        for label in ("New value", "Add value", "+ New value"):
            btn = page.get_by_role("button", name=label).first
            try:
                if await btn.count() and await btn.is_visible():
                    print(f"\n[fin-attr] clicking {label!r}")
                    await btn.click()
                    await page.wait_for_timeout(1000)
                    info_n = await probe_page(page)
                    info_n["new_value_button"] = label
                    shot_n = await screenshot(page, f"fin-attr-create-newvalue-{workspace}")
                    _print_probe("FIN ATTRIBUTES — NEW VALUE FORM", info_n, shot_n)
                    break
            except Exception:
                continue


def _print_probe(title: str, info: dict, shot: Path):
    print(f"\n=== {title} ===")
    print(f"URL:        {info['url']}")
    print(f"Screenshot: {shot}")
    print("\nHeadings:")
    for h in info.get("headings", []):
        print(f"  - {h!r}")
    print("\nVisible buttons (first 80):")
    for b in info.get("visible_buttons", []):
        print(f"  - {b!r}")
    if info.get("inputs"):
        print("\nInputs (tag, type, placeholder, aria-label, name):")
        for inp in info["inputs"]:
            print(f"  - {inp}")
    if info.get("new_button_clicked"):
        print(f"\nNew-button label that worked: {info['new_button_clicked']!r}")


# ────────────────────────────────────────────────────────────────────
# Existence check + Create flow
# ────────────────────────────────────────────────────────────────────


async def attr_exists(page, name: str) -> bool:
    """Check whether an attribute with this exact name already exists on
    the index page. The page mixes two layouts:

      - Card view (no custom attributes yet): each template appears as a
        button containing a heading with the name.
      - Table view (after at least one custom attribute exists): each
        row's first cell shows the name; the row is itself an expandable
        button.

    A naive `get_by_text(name, exact=True)` is unsafe — strings like
    "Status" also appear as table column headers (`<th>`). Strategy:
    match any exact-text element EXCEPT column headers.
    """
    try:
        elements = page.get_by_text(name, exact=True)
        count = await elements.count()
        for i in range(count):
            try:
                tag = await elements.nth(i).evaluate("el => el.tagName")
                if tag and tag.upper() != "TH":
                    return True
            except Exception:
                continue
        return False
    except Exception:
        return False


async def create_one_attribute(page, attr: FinAttribute, workspace: str) -> dict:
    """Create a single Fin attribute via the New → CSV-upload flow.

    Index page must already be loaded. Selectors below were derived from
    --probe-create-form against Migr8now."""
    result: dict = {"name": attr.name, "status": "unknown"}

    if await attr_exists(page, attr.name):
        result["status"] = "skipped"
        return result

    # Description is required by the form — empty descriptions cause
    # Save validation to fail with "Attribute not saved. Fix issues
    # and try again". Catch this upfront with a clear message rather
    # than after a wasted form-fill.
    if not attr.description.strip():
        return {**result, "status": "error",
                "error": ("missing description — add one for this attribute in "
                          "_manifest.yaml under attributes.<name>.description")}
    if not attr.options:
        return {**result, "status": "error", "error": "CSV has no rows"}

    # 1. Click New → opens the side panel at /attributes/new
    try:
        await click_new_button(page)
    except Exception as e:
        shot = await screenshot(page, f"fin-attr-new-fail-{int(time.time())}")
        return {**result, "status": "error", "error": f"new-button: {e}", "screenshot": str(shot)}

    # 2. Fill name (input[name="name"]).
    try:
        name_input = page.locator('input[name="name"]').first
        await name_input.wait_for(state="visible", timeout=10_000)
        await name_input.fill(attr.name)
    except Exception as e:
        shot = await screenshot(page, f"fin-attr-name-fail-{int(time.time())}")
        return {**result, "status": "error", "error": f"name fill: {e}", "screenshot": str(shot)}

    # 3. Fill attribute-level description (textarea[name="description"]).
    try:
        desc = page.locator('textarea[name="description"]').first
        await desc.fill(attr.description)
    except Exception as e:
        shot = await screenshot(page, f"fin-attr-desc-fail-{int(time.time())}")
        return {**result, "status": "error", "error": f"description fill: {e}", "screenshot": str(shot)}

    # 4. Click Values tab.
    try:
        tab = page.get_by_role("tab", name="Values").first
        await tab.wait_for(state="visible", timeout=8_000)
        await tab.click()
        await page.wait_for_timeout(800)
    except Exception as e:
        shot = await screenshot(page, f"fin-attr-values-tab-fail-{int(time.time())}")
        return {**result, "status": "error", "error": f"values tab: {e}", "screenshot": str(shot)}

    # 5. Add each value inline.
    #
    # Intercom changed the Fin Studio create-attribute UI: the hidden
    # <input type="file"> for CSV upload no longer exists. The "Upload
    # CSV" button is now a click-only native picker that Playwright
    # cannot drive without granting OS-level file dialog access.
    #
    # The reliable path is the "New value" button: it opens an inline
    # value sub-form with input[name="label"] + textarea[name="description"]
    # + an inner Save button. Repeat per option.
    try:
        for i, opt in enumerate(attr.options, 1):
            # Click "New value" — exposes the per-value sub-form.
            new_value_btn = page.get_by_role("button", name="New value").first
            await new_value_btn.wait_for(state="visible", timeout=8_000)
            await new_value_btn.click()
            await page.wait_for_timeout(400)

            # Fill value label.
            label_input = page.locator('input[name="label"]').first
            await label_input.wait_for(state="visible", timeout=8_000)
            await label_input.fill(opt.value)

            # Fill per-value description (Fin reasons over this).
            # The Values-tab sub-form's textarea[name="description"] is
            # the only visible one at this point — the attribute-level
            # description (General tab) is hidden.
            desc_input = page.locator('textarea[name="description"]').first
            await desc_input.wait_for(state="visible", timeout=5_000)
            await desc_input.fill(opt.description)

            # Click inner Save (last Save in DOM order — the outer attr
            # Save is in the side-panel header above; inner Save lives
            # below in the value sub-form).
            inner_save = page.get_by_role("button", name="Save").last
            await inner_save.wait_for(state="visible", timeout=5_000)
            await inner_save.click()
            await page.wait_for_timeout(700)
    except Exception as e:
        shot = await screenshot(page, f"fin-attr-value-fail-{int(time.time())}")
        return {**result, "status": "error",
                "error": f"adding value #{i} ({opt.value!r}): {e}",
                "screenshot": str(shot)}

    # 6. Click outer Save to commit the attribute.
    # By this point there are no more inline value sub-forms open so
    # only the outer Save is visible — .first is fine.
    try:
        save_btn = page.get_by_role("button", name="Save").first
        await save_btn.wait_for(state="visible", timeout=8_000)
        if not await save_btn.is_enabled():
            shot = await screenshot(page, f"fin-attr-save-disabled-{int(time.time())}")
            return {**result, "status": "error",
                    "error": "Save button is disabled — a required field is missing",
                    "screenshot": str(shot)}
        await save_btn.click()
        await page.wait_for_timeout(1500)
    except Exception as e:
        shot = await screenshot(page, f"fin-attr-save-fail-{int(time.time())}")
        return {**result, "status": "error", "error": f"save click: {e}", "screenshot": str(shot)}

    # Wait for the save round-trip; the URL should leave /new.
    try:
        await page.wait_for_url(lambda u: "/new" not in u, timeout=15_000)
    except Exception:
        pass
    await page.wait_for_timeout(1000)

    # 7. Verify by going back to the index and looking for the name.
    if not page.url.rstrip("/").endswith(INDEX_PATH):
        await go_to_index(page, workspace)
    if await attr_exists(page, attr.name):
        result["status"] = "created"
    else:
        shot = await screenshot(page, f"fin-attr-verify-fail-{int(time.time())}")
        result["status"] = "failed"
        result["screenshot"] = str(shot)
        result["error"] = "saved but did not appear on index"
    return result


def _emit_temp_csv(attr: FinAttribute) -> Path:
    """Write attr.options to a tempfile in the format Intercom's UI
    accepts: two columns, value,description, no header, UTF-8."""
    import tempfile
    fd, path_str = tempfile.mkstemp(prefix="fin_attr_", suffix=".csv")
    path = Path(path_str)
    with open(fd, "w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh)
        for o in attr.options:
            writer.writerow([o.value, o.description])
    return path


# ────────────────────────────────────────────────────────────────────
# Driver modes
# ────────────────────────────────────────────────────────────────────


async def run_dry_run(workspace: str, csv_dir: Path, keep_underscores: bool):
    attrs = load_csv_dir(csv_dir, keep_underscores=keep_underscores)
    print(f"\n[dry-run] {len(attrs)} attributes parsed from {csv_dir}")
    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)
        await go_to_index(page, workspace)
        for a in attrs:
            exists = await attr_exists(page, a.name)
            verb = "SKIP (exists)" if exists else "CREATE"
            print(f"  [{verb}] {a.name!r}  ({len(a.options)} options, source={Path(a.source_file).name})")
            if a.description:
                print(f"           description: {a.description[:80]!r}")
            for o in a.options[:3]:
                print(f"           - {o.value!r}: {o.description[:60]!r}")
            if len(a.options) > 3:
                print(f"           ... +{len(a.options) - 3} more")


async def run_create(workspace: str, csv_dir: Path, keep_underscores: bool):
    attrs = load_csv_dir(csv_dir, keep_underscores=keep_underscores)
    print(f"[create] {len(attrs)} attributes parsed from {csv_dir}")
    summary = {"created": 0, "skipped": 0, "failed": 0, "error": 0, "details": []}

    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)
        await go_to_index(page, workspace)

        for i, a in enumerate(attrs, 1):
            print(f"\n[create] [{i}/{len(attrs)}] {a.name!r}  ({len(a.options)} options)")
            try:
                result = await create_one_attribute(page, a, workspace)
            except Exception as e:
                shot = await screenshot(page, f"fin-attr-uncaught-{int(time.time())}")
                result = {"name": a.name, "status": "error",
                          "error": f"uncaught: {e}", "screenshot": str(shot)}
            print(f"           → {result['status']}")
            if result.get("error"):
                print(f"           error: {result['error']}")
            if result.get("screenshot"):
                print(f"           screenshot: {result['screenshot']}")
            summary[result["status"]] = summary.get(result["status"], 0) + 1
            summary["details"].append(result)
            await page.wait_for_timeout(800)
            # Make sure we're back on the index for the next iteration.
            if not page.url.endswith(INDEX_PATH):
                await go_to_index(page, workspace)

    print("\n=== SUMMARY ===")
    print(f"  created: {summary['created']}")
    print(f"  skipped: {summary['skipped']}")
    print(f"  failed:  {summary['failed']}")
    print(f"  error:   {summary['error']}")
    if summary["failed"] or summary["error"]:
        print("\n  Problem details:")
        for d in summary["details"]:
            if d["status"] in ("failed", "error"):
                print(f"    - {d['name']}: {d.get('error', '')}")


def main():
    ap = argparse.ArgumentParser(description="Manage Intercom Fin attributes via the admin UI.")
    ap.add_argument("--workspace", required=True, help="Workspace folder name under workspace/")
    mode = ap.add_mutually_exclusive_group(required=True)
    mode.add_argument("--probe", action="store_true", help="Open the index page and dump structure.")
    mode.add_argument("--probe-create-form", action="store_true",
                      help="Click New on the index, dump the create form structure.")
    mode.add_argument("--dry-run", action="store_true", help="Parse CSV dir, list what would be created.")
    mode.add_argument("--create", action="store_true", help="Create attributes from CSV dir.")
    ap.add_argument("--csv-dir", type=Path,
                    help="Directory of fin_attribute_*.csv files. Required for --dry-run and --create.")
    ap.add_argument("--keep-underscores", action="store_true",
                    help="Keep underscores in derived names (default: replace with spaces).")
    args = ap.parse_args()

    if args.probe:
        asyncio.run(run_probe(args.workspace))
    elif args.probe_create_form:
        asyncio.run(run_probe_create_form(args.workspace))
    elif args.dry_run:
        if not args.csv_dir:
            ap.error("--dry-run requires --csv-dir")
        asyncio.run(run_dry_run(args.workspace, args.csv_dir, args.keep_underscores))
    elif args.create:
        if not args.csv_dir:
            ap.error("--create requires --csv-dir")
        asyncio.run(run_create(args.workspace, args.csv_dir, args.keep_underscores))


if __name__ == "__main__":
    main()
