# docent-python

This package has been renamed to [`docent`](https://pypi.org/project/docent/).

`docent-python` is now a thin redirect that depends on `docent`. Installing it
will install `docent` automatically, and `import docent` continues to work
without any code changes.

## Migrating

Replace `docent-python` with `docent` in your project's dependencies:

```diff
- docent-python
+ docent
```

The import path is unchanged:

```python
import docent
```

## Source

Source code, issues, and documentation live in the canonical project:

- Repository: <https://github.com/TransluceAI/docent>
- Docs: <https://transluce.mintlify.app>
