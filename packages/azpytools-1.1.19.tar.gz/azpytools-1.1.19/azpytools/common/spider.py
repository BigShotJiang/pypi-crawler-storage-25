import requests
from lxml import etree
import json
import re
import datetime
from datetime import datetime
import hashlib
import pandas as pd
import time
import logging
from typing import List, Dict, Optional

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class spider:
    '''cls_scrapy = spider(url_str,headers)
    htmls = cls_scrapy.html_xpath()
    newlists = htmls.xpath("//span[@class='c-34304b']/div")
    for newlist in newlists:
            data = {}
            str = etree.tostring(newlist,encoding ='utf-8').decode('utf-8')
            data['title'] = re.findall(r"<strong>(.*?)</strong>",str)[0] if re.findall(r"<strong>(.*?)</strong>",str) else None 
    ''' 
    def __init__(self,url,headers) -> None:
        self.session = requests.Session()
        self.__url = url
        self.__headers = headers
        self.response = self.__url_parse()
        self.__html_str = ""
        if self.response.status_code == 200:
            self.__html_str = self.response.content.decode(encoding= 'utf8')
        else:
            self.__html_str = None 
        self.html_list = []
        
    def __url_parse(self) :
        response =  self.session.get(self.__url, headers=self.__headers)
        # response =  requests.get(self.__url, headers=self.__headers)
        return response

    @property 
    def html_str(self):
        return self.__html_str

    def html_xpath(self):
        return etree.HTML(self.__html_str)

    def get_html_json(self):
        data_list = self.html_list
        jsons = json.dumps(data_list,ensure_ascii=False)
        return jsons



class clsSpider():
    """财联社数据爬取类"""

    BASE_URL = "https://x-quote.cls.cn"
    TELEGRAPH_URL = "https://www.cls.cn/nodeapi/telegraphList"
    DEFAULT_HEADERS = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.67 Safari/537.36",
        "Referer": "https://www.cls.cn/",
    }

    def __init__(self, maxpage: int = 5):
        self.session = requests.Session()
        self.session.headers.update(self.DEFAULT_HEADERS)
        self.maxpages = maxpage
        self.html_list: List[Dict] = []

    def _request(self, url: str, params: dict = None, timeout: int = 10) -> dict:
        """统一请求方法，自动处理异常与状态码"""
        try:
            resp = self.session.get(url, params=params, timeout=timeout)
            resp.raise_for_status()
            return resp.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"请求失败: {url} - {e}")
            return {}
        except json.JSONDecodeError:
            logger.error(f"响应JSON解析失败: {url}")
            return {}

    # ================== 电报相关 ==================
    def get_telegraph(self):
        """获取财联社电报快讯，最多翻页到 self.maxpages 页

        分页拉取财联社7x24小时电报快讯，每条记录包含标题、正文、时间戳等信息。
        通过 lastTime 参数实现翻页，每次取最后一电报的时间戳作为下一页起点。

        Returns:
            List[Dict]: 电报记录列表，每条记录字段包括：
                from(来源，固定为"CLS.CN"),
                timestamp(原始时间戳),
                date(格式化时间，如 "2025-01-01 10:30:00"),
                title(标题),
                text(正文，换行符替换为<br>),
                brief(摘要)
        """
        logger.info(f"开始获取电报，最大页数: {self.maxpages}")
        current_ts = int(datetime.now().timestamp())  # API要求整型时间戳
        page = 0

        while page < self.maxpages or self.maxpages == 0:
            params = {
                "app": "CailianpressWeb",
                "category": "",
                "lastTime": current_ts,
            }
            data = self._request(self.TELEGRAPH_URL, params=params)
            # print(data)
            if not data or data.get("error") != 0:
                logger.warning("电报接口返回错误或无数据")
                break

            roll_data = data.get("data", {}).get("roll_data", [])
            if not roll_data:
                logger.info("已无更多电报数据")
                break

            for item in roll_data:
                record = {
                    "from": "CLS.CN",
                    "timestamp": item.get("ctime"),
                    "date": datetime.fromtimestamp(item["ctime"]).strftime("%Y-%m-%d %H:%M:%S") if item.get("ctime") else "",
                    "title": item.get("title") or item.get("brief", ""),
                    "text": item.get("content", "").replace("\n", "<br>"),
                    "brief": item.get("brief", ""),
                }
                self.html_list.append(record)

            # 使用最后一条的时间戳作为下一次请求的起点
            current_ts = int(roll_data[-1]["ctime"])
            page += 1
            logger.info(f"已获取第 {page} 页，累计 {len(self.html_list)} 条")
            time.sleep(0.5)  # 礼貌爬取

        logger.info(f"电报获取完成，共 {len(self.html_list)} 条")
        return self.html_list

    # ================== 签名算法 ==================
    def get_sign(self, params: dict) -> str:
        """财联社接口签名：字典序拼接 -> SHA1 -> MD5"""
        sorted_keys = sorted(params.keys())
        raw_str = "&".join(f"{k}={params[k]}" for k in sorted_keys)
        sha1_hash = hashlib.sha1(raw_str.encode()).hexdigest()
        md5_hash = hashlib.md5(sha1_hash.encode()).hexdigest()
        return md5_hash

    # ================== 涨跌分析 ==================
    def fetch_up_down_analysis(self, analysis_type: str = "up_pool",
                               way: str = "last_px", rever: int = 1) -> Dict:
        """获取涨跌分析数据（连续涨停池/炸板池/涨停池/跌停池）"""
        valid_types = ("continuous_up_pool", "up_open_pool", "up_pool", "down_pool")
        if analysis_type not in valid_types:
            raise ValueError(f"analysis_type 必须为: {valid_types}")

        url = f"{self.BASE_URL}/quote/index/up_down_analysis"
        params = {
            "app": "CailianpressWeb",
            "os": "web",
            "rever": rever,
            "sv": "8.4.6",
            "type": analysis_type,
            "way": way,
        }
        params["sign"] = self.get_sign(params)
        return self._request(url, params=params)

    def parse_analysis_data(self, data: Dict) -> Dict[str, pd.DataFrame]:
        """解析涨跌分析数据，拆分为股票DataFrame和板块DataFrame"""
        stock_list = data.get("data", [])
        if not stock_list:
            return {"stocks": pd.DataFrame(), "plates": pd.DataFrame()}

        stock_records = [
            {
                "secu_code": item.get("secu_code"),
                "secu_name": item.get("secu_name"),
                "change": item.get("change"),
                "last_px": item.get("last_px"),
                "time": item.get("time"),
                "up_reason": item.get("up_reason"),
                "num_stocks": item.get("num_stocks"),
                "is_st": item.get("is_st"),
                "limit_up_days": item.get("limit_up_days"),
            }
            for item in stock_list
        ]

        plate_records = []
        for item in stock_list:
            secu_code = item.get("secu_code")
            for p in item.get("plate", []):
                plate_records.append({
                    "stock_code": secu_code,
                    "plate_code": p.get("secu_code"),
                    "plate_name": p.get("secu_name"),
                    "plate_change": p.get("change"),
                })

        stock_list = pd.DataFrame(stock_records)
        stock_list["code"] = self.transform_stock_code(stock_list["secu_code"])
        plate_list = pd.DataFrame(plate_records)
        plate_list["code"] = self.transform_stock_code(plate_list["stock_code"])
        return {
            
            "stocks": stock_list,
            "plates": plate_list,
        }

    # 便捷方法
    def get_up_pool(self) -> Dict[str, pd.DataFrame]:
        return self.parse_analysis_data(self.fetch_up_down_analysis("up_pool"))

    def get_up_open_pool(self) -> Dict[str, pd.DataFrame]:
        """获取炸板池（曾涨停但未封住）数据

        查询当日曾经触及涨停但最终未能封住的股票，即"炸板"股票。
        返回股票明细和所属板块信息。

        Returns:
            Dict[str, pd.DataFrame]: 包含两个DataFrame的字典：
                - "stocks": 炸板股票明细，字段包括
                    secu_code, secu_name, change, last_px,
                    up_reason(涨停原因), num_stocks, is_st,
                    code(标准格式股票代码) 等
                - "plates": 股票所属板块映射，字段包括
                    stock_code, plate_code, plate_name, plate_change, code
        """
        return self.parse_analysis_data(self.fetch_up_down_analysis("up_open_pool"))

    def get_continuous_up_pool(self) -> Dict[str, pd.DataFrame]:
        """获取连续涨停池数据

        查询当日连续涨停（2板及以上）的股票，返回股票明细和所属板块信息。
        连续涨停天数通过 limit_up_days 字段标识。

        Returns:
            Dict[str, pd.DataFrame]: 包含两个DataFrame的字典：
                - "stocks": 连续涨停股票明细，字段包括
                    secu_code, secu_name, change, last_px,
                    limit_up_days(连板天数), up_reason(涨停原因),
                    num_stocks, is_st, code(标准格式股票代码) 等
                - "plates": 股票所属板块映射，字段包括
                    stock_code, plate_code, plate_name, plate_change, code
        """
        return self.parse_analysis_data(self.fetch_up_down_analysis("continuous_up_pool"))

    def get_down_pool(self) -> Dict[str, pd.DataFrame]:
        """获取跌停池数据

        查询当日跌停的股票，返回股票明细和所属板块信息。

        Returns:
            Dict[str, pd.DataFrame]: 包含两个DataFrame的字典：
                - "stocks": 跌停股票明细，字段包括
                    secu_code, secu_name, change, last_px,
                    up_reason, num_stocks, is_st,
                    code(标准格式股票代码) 等
                - "plates": 股票所属板块映射，字段包括
                    stock_code, plate_code, plate_name, plate_change, code
        """
        return self.parse_analysis_data(self.fetch_up_down_analysis("down_pool"))

    # ================== 板块相关 ==================
    def fetch_plate_list(self, page: int, plate_type: str,
                         way: str = "change", rever: int = 1) -> dict:
        """获取板块列表单页数据"""
        url = f"{self.BASE_URL}/web_quote/plate/plate_list"
        params = {
            "app": "CailianpressWeb",
            "os": "web",
            "page": page,
            "rever": rever,
            "sv": "8.4.6",
            "type": plate_type,
            "way": way,
        }
        params["sign"] = self.get_sign(params)
        return self._request(url, params=params)

    def fetch_plate_info(self, secu_code: str) -> dict:
        """获取单个板块详细信息"""
        url = f"{self.BASE_URL}/web_quote/plate/info"
        params = {
            "app": "CailianpressWeb",
            "os": "web",
            "secu_code": secu_code,
            "sv": "8.4.6",
        }
        params["sign"] = self.get_sign(params)
        return self._request(url, params=params)

    def fetch_plate_stocks(self, secu_code: str,
                           way: str = "last_px", rever: int = 1) -> dict:
        """获取板块成分股列表"""
        url = f"{self.BASE_URL}/web_quote/plate/stocks"
        params = {
            "app": "CailianpressWeb",
            "os": "web",
            "rever": rever,
            "secu_code": secu_code,
            "sv": "8.4.6",
            "way": way,
        }
        params["sign"] = self.get_sign(params)
        return self._request(url, params=params)

    def get_bk_list(self, plate_type: str = "industry",up:bool = True) -> pd.DataFrame:
        """获取板块清单，返回扁平化后的DataFrame

        调用财联社板块列表接口，获取行业板块或概念板块的汇总数据，
        包括板块涨跌幅、涨跌停数量、主力资金净流入、领涨股等信息。
        返回的DataFrame中嵌套的first_stock字段会被扁平化展开，
        并额外添加 first_stock.code 列（标准股票代码格式）。

        Args:
            plate_type: 板块类型，可选值：
                - "industry": 行业板块（默认）
                - "concept": 概念板块
            up: 是否获取涨幅榜块（默认True），False表示获取跌幅榜

        Returns:
            pd.DataFrame: 扁平化的板块数据，主要字段包括：
                secu_name(板块名称), secu_code(板块代码),
                limit_up(涨家数), limit_down(跌家数),
                change(涨跌幅), main_fund_diff(主力资金净流入),
                first_stock_last_px(领涨股最新价),
                limit_up_num(涨停数),
                limit_down_num(跌停数),
                first_stock.secu_name(领涨股名称),
                first_stock.change(领涨股涨跌幅),
                first_stock.code(标准格式股票代码) 等

        """
        if up:
            plates = self.fetch_plate_list(1, plate_type,rever=1)
        else:
            plates = self.fetch_plate_list(1, plate_type,rever=0)
        plates_list = plates["data"]["plate_data"]
        # print(plates)
        # 扁平化并转为 DataFrame
        df = pd.json_normalize(plates_list)
        df["first_stock.code"] = self.transform_stock_code(df["first_stock.secu_code"])
        return df

    def get_bk_stock_list(self, secu_code: str) -> pd.DataFrame:
        """获取指定板块的成分股清单，返回扁平化后的DataFrame

        根据板块代码查询该板块下所有成分股的行情数据，
        包括股价、涨跌幅、成交量等，并额外添加 code 列（标准股票代码格式）。

        Args:
            secu_code: 板块代码，如 "cls82198"（行业板块）、"cls82245"（概念板块），
                可通过 get_bk_list() 获取

        Returns:
            pd.DataFrame: 板块成分股数据，主要字段包括：
                secu_code(股票代码), secu_name(股票名称),
                change(涨跌幅), last_px(最新价),
                volume(成交量), amount(成交额),
                code(标准格式股票代码，如 000001.SZ) 等
        """
        stocks_data = self.fetch_plate_stocks(secu_code)["data"]["stocks"]
        df = pd.json_normalize(stocks_data)
        df["code"] = self.transform_stock_code(df["secu_code"])
        return df
    
    @staticmethod
    def transform_stock_code(series: pd.Series) -> pd.Series:
        """
        批量转换股票代码格式：
        sz000001 -> 000001.SZ
        sh600000 -> 600000.SH
        其他格式保持不变
        """
        s = series.astype(str)
        
        # 1. 判断是否以 sz 或 sh 开头（忽略大小写）
        # 使用切片比对，速度极快
        prefix = s.str[:2].str.lower()
        mask = prefix.isin(['sz', 'sh','bj','hk'])
        
        # 2. 构建结果容器（先复制原数据，处理不匹配的情况）
        result = s.copy()
        
        # 3. 仅对符合条件的数据进行拼接
        # 代码部分 = [2:]，后缀部分 = [:2] 转 大写
        result[mask] = s[mask].str[2:] + '.' + prefix[mask].str.upper()
        
        return result
                
class JinseSpider(spider):
        # maxpages = 1
        url_str = 'https://api.jinse.cn/noah/v2/lives?limit=20'
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.67 Safari/537.36",
               }
               
        def __init__(self,maxpage):
            self.curpage = 0
            self.html_list = []
            self.maxpages = maxpage
            self.get_html_list(0)


            
        def get_html_list(self,id=0):
            url_next = "https://api.jinse.cn/noah/v2/lives?reading=false&sort=&flag=down&id={}&limit=20&_source=m".format(id)
            if id >0 :
                jinse = spider(url_next,self.headers)
            else:
                jinse = spider(self.url_str,self.headers)
            data_list =[]
            self.curpage += 1 
            htmls = jinse.html_str
            newlists = json.loads(htmls)["list"][0]["lives"]
            data_list = [{"from":"JINSE.CN",
                          "title": news["content_prefix"], 
                          "text":news["content"].replace('\n','<br>'),
                          "date":datetime.datetime.strftime(datetime.datetime.fromtimestamp(news["created_at"]),'%Y-%m-%d %H:%M:%S') ,
                          'id':news['id']} for news in newlists]
            self.html_list.extend(data_list) 
            newid = data_list[-1]['id']
            
            if self.curpage <= self.maxpages and newid:
                self.get_html_list(newid)  


class weiboSpider():
        
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.67 Safari/537.36",
                }          
        def __init__(self,uuid,cookie):
            self.html_list = []
            self.headers["cookie"] = cookie
            for i in range(2):
                url_str = 'https://weibo.com/ajax/statuses/mymblog?uid={}&page={}&feature=0'.format(uuid,i+1)
                self.html_list.extend(self.get_html_list(url_str))
            
        def get_html_list(self,url_str):
            weibo_scrapy = spider(url_str,self.headers)
            htmls = weibo_scrapy.html_str
            newlists = json.loads(htmls)["data"]["list"]
            data_list = []
            data_list =[{'name':lst['user']['screen_name'], 
                          'title':lst['created_at'],
                          'mblogid':lst['mblogid'], 
                          'date':datetime.datetime.strftime(datetime.datetime.strptime(lst['created_at'],"%a %b %d %H:%M:%S %z %Y"),'%Y-%m-%d %H:%M:%S')  ,
                          'longtext':self.get_longtext(lst['mblogid']) if bool(lst['isLongText'])  else  lst['text'],
                          'text': lst['text_raw']} for lst in newlists ]
            del data_list[0]
            return data_list
            
        
        def get_longtext(self,mblogid):
            longtext = ''
            url_string = "https://weibo.com/ajax/statuses/longtext?id={}".format(mblogid)
            weibo_longtext_scrapy = spider(url_string,self.headers)
        
            htmls = weibo_longtext_scrapy.html_str
            if htmls != None:
                ljson_data = json.loads(htmls).get("data",None)
                if ljson_data != None:
                    longtext = ljson_data.get("longTextContent")
            # longtext = json.loads(htmls)["data"]["longTextContent"]
            return longtext
        
 
class weiboHotSpider():
        url_str = 'https://weibo.com/ajax/statuses/hot_band'
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.67 Safari/537.36",
                  "x-requested-with":"XMLHttpRequest",
               }          
        def __init__(self,cookie):
            self.headers["cookie"] = cookie
            self.html_list = []
            self.html_list.extend(self.get_html_list())
            
        def get_html_list(self):
            weibo_scrapy = spider(self.url_str,self.headers)
            htmls = weibo_scrapy.html_str
            # print(htmls)
            newlists = json.loads(htmls)["data"]["band_list"]
            # print(newlists)
            data_list = []
            for lst in newlists:
                dats = {}
                # Not AD
                if lst.get("is_ad",None) == None:
                    dats['name'] = 'HOT'
                    dats['title'] = lst['note']
                    dats['hotnum'] = lst['num']  
                    dats['date'] = datetime.datetime.strftime(datetime.datetime.fromtimestamp(lst.get('onboard_time'),None),'%Y-%m-%d %H:%M:%S') 
                    lmblog = lst.get('mblog',None)
                    if lmblog != None:
                        dats['text'] = lmblog.get('text','')  # lst['mblog']['text'] 
                    data_list.append(dats)                          
            return data_list
                



 
