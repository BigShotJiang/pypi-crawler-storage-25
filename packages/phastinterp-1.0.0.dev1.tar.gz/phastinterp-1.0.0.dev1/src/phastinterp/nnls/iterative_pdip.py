from phastinterp._sparsejax import LSMRResult
from jax._src.basearray import Array
from jax import Array
from typing import Any, Callable

from .._sparsejax import LSMR
import jax
import jax.numpy as jnp
from jax.tree_util import Partial
from jax.numpy import ndarray


def lsmr(A: Callable, b: Array, x0: Array) -> Array:
    out = LSMR(A, b, x0, a_tol=1e-9, b_tol=1e-9)
    return out.x


def preconditioned_augmented_A(A, d1, d2, x):
    Ad1x = A(d1 * x)
    return jnp.hstack([Ad1x, d2 * x])


def scaling_matrix(s: Array, z: Array) -> Array:
    return jnp.diag(jnp.sqrt(s) / jnp.sqrt(z))


def solve_newton_system(
    A: Callable,
    b: Array,
    x: Array,
    s: Array,
    z: Array,
    dz: Array,
    ds: Array,
    lam: Array,
    w: Array,
    a_col_norms_sq: Array,
    delta_x0: Array,
) -> tuple[Array, Array, Array]:
    qz = dz - w * ds / lam
    u = b - A(x)
    v = w * z + -qz / w
    d1 = jnp.sqrt(s / (s * a_col_norms_sq + z))
    d2 = jnp.sqrt(z / (s * a_col_norms_sq + z))
    H = Partial(preconditioned_augmented_A, A, d1, d2)
    delta_p0 = delta_x0 / d1
    rhs = jnp.hstack([u, v])
    delta_p = lsmr(H, rhs, delta_p0)
    delta_x = d1 * delta_p
    delta_z = jnp.square(jnp.reciprocal(w)) * (-delta_x - qz)
    delta_s = w * (ds / lam - w * delta_z)
    return delta_x, delta_z, delta_s


def max_step(z: Array, dz: Array, s: Array, ds: Array) -> Array:
    rho = ds / s
    sigma = dz / z
    return jnp.minimum(1 / jnp.maximum(-jnp.min(rho), -jnp.min(sigma)), 1)


def residuals(A: Callable, A_T: Callable, b: Array, x: Array, z: Array, s: Array):
    rx = A_T(A(x) - b) - z
    rz = s - x
    return rx, rz


def mehrotra_predictor(w: Array, delta_s: Array, delta_z: Array):
    return (delta_s / w) * (delta_z * w)


def matfreePDIP_body(
    A: Callable,
    A_T: Callable,
    a_col_norms_sq: Array,
    b: Array,
    m: int,
    value: tuple[Array, Array, Array, int],
):
    x, z, s, iteration = value
    w = jnp.sqrt(s) / jnp.sqrt(z)
    lam = jnp.sqrt(z * s)
    mu = jnp.linalg.vecdot(lam, lam) / m
    rx, rz = residuals(A, A_T, b, x, z, s)
    delta_xa, delta_za, delta_sa = solve_newton_system(
        A, b, x, s, z, -rz, -jnp.square(lam), lam, w, a_col_norms_sq, jnp.zeros_like(x)
    )
    alpha_aff = max_step(z, delta_za, s, delta_sa)
    rho = jnp.linalg.vecdot(
        z + alpha_aff * delta_za, s + alpha_aff * delta_sa
    ) / jnp.linalg.vecdot(z, s)
    sigma = jnp.power(jnp.maximum(0, jnp.minimum(1, rho)), 3)
    ds_2 = -jnp.square(lam) + sigma * mu - mehrotra_predictor(w, delta_sa, delta_za)
    delta_x, delta_z, delta_s = solve_newton_system(
        A, b, x, s, z, -rz, ds_2, lam, w, a_col_norms_sq, delta_xa
    )
    delta_scaled_s = delta_s / (w * 0.99)
    delta_scaled_z = w * delta_z / (0.99)
    alpha = max_step(lam, delta_scaled_z, lam, delta_scaled_s)
    x = x + alpha * delta_x
    z = z + alpha * delta_z
    s = s + alpha * delta_s
    return (x, z, s, iteration + 1)


def matfreePDIP_cond(
    A: Callable, A_T: Callable, b, m, tolerance, max_iterations, value
):
    x, z, s, iteration = value
    rx, rz = residuals(A, A_T, b, x, z, s)
    rx_norm = jnp.linalg.vector_norm(rx, ord=2)
    rz_norm = jnp.linalg.vector_norm(rz, ord=2)
    c1 = jnp.greater(rx_norm / jnp.linalg.vector_norm(b, ord=2), tolerance)
    c2 = jnp.greater(
        rz_norm / (jnp.linalg.vector_norm(x, ord=2) + jnp.linalg.vector_norm(s, ord=2)),
        tolerance,
    )
    c3 = jnp.greater(jnp.abs(jnp.vdot(z, s)), m * tolerance)
    c4 = jnp.less(iteration, max_iterations)
    return (c1 | c2 | c3) & c4


def initialize(A, b, n, epsilon) -> tuple[Array, Array, Array]:
    out: LSMRResult = LSMR(A, b, jnp.zeros(n, dtype=b.dtype), damping_parameter=1.0)
    x0: Array = out.x
    x_min = jnp.min(x0)
    s = jnp.copy(x0)
    if x_min <= epsilon:
        alpha_p = epsilon - x_min
        s0 = s + alpha_p
    else:
        s0 = s
    z = -x0
    z_min = jnp.min(z)
    if z_min <= epsilon:
        alpha_d = epsilon - z_min
        z0 = z + alpha_d
    else:
        z0 = z
    return x0, z0, s0


def matfreePDIP(
    A: Callable, b, n, a_col_norms_sq, epsilon=1.0, tolerance=1e-5, max_iterations=100
):
    x, z, s = initialize(A, b, n, epsilon)
    iteration = 0
    m = jnp.size(b)
    A_T = jax.linear_transpose(A, x)

    def A_T_op(x):
        return A_T(x)[0]

    body_func = Partial(matfreePDIP_body, A, A_T_op, a_col_norms_sq, b, m)
    cond_func = Partial(matfreePDIP_cond, A, A_T_op, b, m, tolerance, max_iterations)
    x, z, s, iteration = jax.lax.while_loop(cond_func, body_func, (x, z, s, iteration))
    return x, z, s, iteration
