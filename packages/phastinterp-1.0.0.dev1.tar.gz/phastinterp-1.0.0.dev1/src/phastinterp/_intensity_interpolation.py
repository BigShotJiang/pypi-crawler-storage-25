import jax
import jax.numpy as jnp
from jax.typing import ArrayLike
import numpy as np
import scipy
import scipy.linalg
import scipy.optimize
import lineax as lx
from ._sparsejax import LSMR, _LSMR_irfftn
from ._nnls import _nnls_autocorr
from .nnls import matfreePDIP


# @partial(jnp.vectorize, excluded={0}, signature='()->(n)')
def ifft_vec(support, index):
    unit_vector = jnp.zeros_like(support)
    unit_vector = unit_vector.at[index].set(1)
    return jnp.ravel(jnp.fft.ifft2(unit_vector))


def interpolation_operator(support_mask, missing_intensity_indices, autocorr_indices):
    P = jnp.zeros(
        (jnp.size(autocorr_indices), len(missing_intensity_indices[0])),
        dtype=jnp.complex128,
    )
    missing_index_list = [
        (missing_intensity_indices[0][i], missing_intensity_indices[1][i])
        for i in range(len(missing_intensity_indices[0]))
    ]
    for col_index, intensity_index in enumerate(missing_index_list):
        P = P.at[:, col_index].set(
            ifft_vec(support_mask, intensity_index)[autocorr_indices]
        )
    return P


def calculate_residual(intensities, autocorr_indices):
    autocorr = jnp.fft.ifft2(intensities)
    return autocorr[autocorr_indices]


def autocorr_mask(near_field_mask):
    intensity = jnp.square(jnp.abs(jnp.fft.fft2(near_field_mask)))
    autocorr = jnp.fft.ifft2(intensity)
    mask = jnp.zeros_like(autocorr)
    mask = mask.at[jnp.abs(autocorr) > 0.5].set(1)
    return mask


def calc_flat_autocorr_indices(support_mask):
    intensity = jnp.square(jnp.abs(jnp.fft.fft2(support_mask)))
    autocorr = jnp.fft.ifft2(intensity)
    mask = jnp.ones_like(autocorr)
    mask = mask.at[autocorr > 0].set(0)
    return jnp.flatnonzero(mask)


def calc_autocorr_indices_choice(support_mask, num_points):
    intensity = jnp.square(jnp.abs(jnp.fft.fft2(support_mask)))
    autocorr = jnp.fft.ifft2(intensity)
    mask = jnp.ones_like(autocorr)
    mask = mask.at[autocorr > 0.5].set(0)
    flat_indices = jnp.flatnonzero(mask)
    key = jax.random.key(42)
    chosen_flat_indices = jax.random.choice(key, flat_indices, (num_points,), False)
    chosen_non_flat_indices = jnp.unravel_index(chosen_flat_indices, mask.shape)
    return (chosen_non_flat_indices, chosen_flat_indices)


def calc_autocorr_indices(support_mask):
    intensity = jnp.square(jnp.abs(jnp.fft.fft2(support_mask)))
    autocorr = jnp.fft.ifft2(intensity)
    mask = jnp.ones_like(autocorr)
    mask = mask.at[autocorr > 0.5].set(0)
    flat_indices = jnp.flatnonzero(mask)
    non_flat_indices = jnp.unravel_index(flat_indices, mask.shape)
    return (non_flat_indices, flat_indices)


def interpolate_intensities(
    far_field_intensities,  # Total far-field pattern, with missing elements set to 0
    near_field_support_mask,  # Support mask, the total size should be the size of the far-field
    missing_intensity_indices,  # indices of the missing intensity measurements. Should of the form you get from jax.numpy.nonzero
    num_matrix_rows,
    non_neg_leat_squares: bool = True,
):
    autocorr_indices, flat_autocorr_indices = calc_autocorr_indices_choice(
        near_field_support_mask, num_matrix_rows
    )
    b_complex = -calculate_residual(far_field_intensities, autocorr_indices)
    interpolation_matrix_complex = interpolation_operator(
        near_field_support_mask, missing_intensity_indices, flat_autocorr_indices
    )
    b_real_imag = jnp.concat([jnp.real(b_complex), jnp.imag(b_complex)])
    A_matrix = jnp.concat(
        [jnp.real(interpolation_matrix_complex), jnp.imag(interpolation_matrix_complex)]
    )
    b_numpy = np.asarray(b_real_imag)
    A_numpy = np.asarray(A_matrix)
    if non_neg_leat_squares:
        x = non_negative_least_squares(A_numpy, b_numpy)
    else:
        x = standard_least_squares(A_numpy, b_numpy)
    return jnp.asarray(x)


def replace_negative_intensities(
    far_field_intensities,
    near_field_support_mask,
    num_matrix_rows,
    non_neg_least_squares: bool = True,
):
    index_mask = jnp.zeros_like(far_field_intensities)
    index_mask = index_mask.at[jnp.less(far_field_intensities, 0)].set(1)
    missing_indices = jnp.nonzero(index_mask)
    far_field_intensities = far_field_intensities.at[missing_indices].set(0)
    missing_intensities = interpolate_intensities(
        far_field_intensities,
        near_field_support_mask,
        missing_indices,
        num_matrix_rows,
        non_neg_least_squares,
    )

    far_field_intensities = far_field_intensities.at[missing_indices].set(
        missing_intensities
    )
    return far_field_intensities


def interpolation_linear_operator(
    missing_intensities, full_intensities, missing_intensity_indices, autocorr_indices
):
    full_intensities = full_intensities.at[missing_intensity_indices].set(
        missing_intensities, unique_indices=True
    )
    autocorr = jnp.fft.ifft2(full_intensities)
    autocorr = autocorr[autocorr_indices]
    real_autocorr = jnp.real(autocorr)
    imag_autocorr = jnp.imag(autocorr)

    return jnp.concat([real_autocorr, imag_autocorr])


def matrix_free_intensity_interpolation(
    far_field_intensities,  # Total far-field pattern, with missing elements set to 0
    near_field_support_mask,  # Support mask, the total size should be the size of the far-field
    missing_intensity_indices,  # indices of the missing intensity measurements. Should of the form you get from jax.numpy.nonzero)
    a_tol: float = 1e-6,
    b_tol: float = 1e-6,
    max_steps: int = 100,
    damping=1e-3,
    use_ac_support: bool = False,
):
    if use_ac_support:
        mask = jnp.ones_like(near_field_support_mask)
        mask = mask.at[near_field_support_mask > 0.0].set(0)
        autocorr_indices = jnp.nonzero(mask)
    else:
        autocorr_indices, flat_autocorr_indices = calc_autocorr_indices(
            near_field_support_mask
        )
    b_complex = -calculate_residual(far_field_intensities, autocorr_indices)
    b_real_imag = jnp.concat([jnp.real(b_complex), jnp.imag(b_complex)])
    full_intensities = jnp.zeros_like(far_field_intensities)
    non_flat_indices = jnp.unravel_index(
        missing_intensity_indices, jnp.shape(full_intensities)
    )

    def interp_operator(x):
        return interpolation_linear_operator(
            x, full_intensities, non_flat_indices, autocorr_indices
        )

    init_x = jnp.zeros(jnp.size(missing_intensity_indices))
    out = LSMR(
        interp_operator,
        rhs=b_real_imag,
        x0=init_x,
        a_tol=a_tol,
        b_tol=b_tol,
        max_steps=max_steps,
        damping_parameter=damping,
    )
    return out.x


def mat_free_replace_negative_intensities(
    far_field_intensities,
    near_field_support_mask,
    a_tol: float = 1e-9,
    b_tol: float = 1e-9,
    max_steps: int = 1000,
    damping=0.0,
    use_ac_support: bool = False,
):
    """
    Replace negative intensities in the far-field pattern with interpolated values.
    Args:
        far_field_intensities (jnp.ndarray): Total far-field pattern, with missing elements set to negative values.
        near_field_support_mask (jnp.ndarray): Support mask, the total size should be the size of the far-field.
        a_tol (float, optional): Tolerance representing uncertainty in transform (from unknown aberrations, for example). Defaults to 1e-12.
        b_tol (float, optional): Tolerance representing uncertainty in the right-hand side (from measurement noise, for example). Defaults to 1e-12.
        max_steps (int, optional): Maximum number of steps for the solver. Defaults to 100.
        damping (float, optional): Damping parameter for the solver. Defaults to 1e-3.
    Returns:
        jnp.ndarray: Far-field pattern with negative intensities replaced by interpolated values.
    """
    index_mask = jnp.zeros_like(far_field_intensities)
    index_mask = index_mask.at[jnp.less(far_field_intensities, 0)].set(1)
    missing_indices = jnp.flatnonzero(index_mask)
    non_flat_indices = jnp.nonzero(index_mask)
    far_field_intensities = far_field_intensities.at[non_flat_indices].set(0)
    missing_intensities = matrix_free_intensity_interpolation(
        far_field_intensities,
        near_field_support_mask,
        missing_indices,
        a_tol,
        b_tol,
        max_steps,
        damping,
        use_ac_support=use_ac_support,
    )
    far_field_intensities = far_field_intensities.at[non_flat_indices].set(
        missing_intensities
    )
    return far_field_intensities


def nnls_replace_negative_intensities(
    far_field_intensities,
    near_field_support_mask,
    tol=1e-5,
    damping=0.0,
    use_ac_support: bool = False,
):
    if use_ac_support:
        mask = jnp.ones_like(near_field_support_mask)
        ac_mask = mask.at[near_field_support_mask > 0.0].set(0)
    else:
        ac = jnp.fft.ifft2(jnp.square(jnp.abs(jnp.fft.fft2(near_field_support_mask))))
        ac_mask = jnp.ones_like(jnp.abs(ac))
        ac_mask = ac_mask.at[jnp.abs(ac) > 0.5].set(0)
    index_mask = jnp.zeros_like(far_field_intensities)
    index_mask = index_mask.at[jnp.less(far_field_intensities, 0)].set(1)
    missing_indices = jnp.flatnonzero(index_mask)
    non_flat_indices = jnp.nonzero(index_mask)
    far_field_intensities = far_field_intensities.at[non_flat_indices].set(0)
    rhs = -jnp.fft.ifft2(far_field_intensities)
    nnls_out = _nnls_autocorr(ac_mask, rhs, missing_indices, damping, tol=tol)
    far_field_intensities = far_field_intensities.at[non_flat_indices].set(nnls_out)
    return far_field_intensities


def matrix_free_nnls_replace_negative_intensities(
    far_field_intensities,
    near_field_support_mask,
    damping=0.0,
    use_ac_support: bool = False,
):
    if use_ac_support:
        mask = jnp.ones_like(near_field_support_mask)
        ac_mask = mask.at[near_field_support_mask > 0.0].set(0)
    else:
        ac = jnp.fft.ifft2(jnp.square(jnp.abs(jnp.fft.fft2(near_field_support_mask))))
        ac_mask = jnp.ones_like(jnp.abs(ac))
        ac_mask = ac_mask.at[jnp.abs(ac) > 0.5].set(0)
    autocorr_indices = jnp.nonzero(ac_mask)
    index_mask = jnp.zeros_like(far_field_intensities)
    index_mask = index_mask.at[jnp.less(far_field_intensities, 0)].set(1)
    missing_indices = jnp.flatnonzero(index_mask)
    non_flat_indices = jnp.nonzero(index_mask)
    far_field_intensities = far_field_intensities.at[non_flat_indices].set(0)
    full_intensities = jnp.zeros_like(far_field_intensities)

    def interp_operator(x):
        return interpolation_linear_operator(
            x, full_intensities, non_flat_indices, autocorr_indices
        )

    b_complex = -calculate_residual(far_field_intensities, autocorr_indices)
    b_real_imag = jnp.concat([jnp.real(b_complex), jnp.imag(b_complex)])
    out = matfreePDIP(
        interp_operator,
        b_real_imag,
        jnp.size(missing_indices),
        a_col_norms_sq=jnp.ones(jnp.size(missing_indices)),
    )
    far_field_intensities = far_field_intensities.at[non_flat_indices].set(out[0])
    return far_field_intensities


def standard_least_squares(A, b):
    x, res, rank, svds = scipy.linalg.lstsq(A, b)
    return x


def non_negative_least_squares(A, b):
    x, rnorm = scipy.optimize.nnls(A, b)
    return x


def view_as_flat_real(complex_array):
    real_part = jnp.real(complex_array)
    imag_part = jnp.imag(complex_array)
    return jnp.concatenate([real_part, imag_part])


def view_as_complex(flat_array, original_shape):
    half_length = flat_array.shape[0] // 2
    real_part = flat_array[:half_length]
    imag_part = flat_array[half_length:]
    complex_array = real_part + 1j * imag_part
    return complex_array.reshape(original_shape)


def view_as_flat_complex(flat_array):
    half_length = flat_array.shape[0] // 2
    real_part = flat_array[:half_length]
    imag_part = flat_array[half_length:]
    complex_array = real_part + 1j * imag_part
    return complex_array


def weighted_autocorr_intensities(
    flat_real_autocorr,
    original_shape,
    autocorr_indices,
    intensity_shape,
    intensity_indices,
    weights,
):
    complex_autocorr = view_as_flat_complex(flat_real_autocorr)
    autocorr_full = jnp.zeros(original_shape, dtype=jnp.complex128)
    autocorr_full = autocorr_full.at[autocorr_indices].set(
        complex_autocorr, unique_indices=True
    )
    intensities_out = jnp.fft.irfftn(autocorr_full, s=intensity_shape)
    return weights * intensities_out[intensity_indices]


@jax.jit
def setup_solve_gaussian_system(
    rhs,
    x0,
    autocorr_mask,
    weights,
    a_tol: float = 1e-9,
    b_tol: float = 1e-9,
    max_steps: int = 1000,
    damping=0.0,
):
    """Needed to separate out the Jittable portion of the function. We due the operator definition here so its included in the jit."""

    lsmr_result = _LSMR_irfftn(
        rhs,
        x0,
        autocorr_mask,
        weights,
        a_tol=a_tol,
        b_tol=b_tol,
        max_steps=max_steps,
        damping_parameter=damping,
    )
    return lsmr_result


def approx_gaussian_noise_intensity_interpolation(
    far_field_intensities,
    near_field_support_mask,
    variance_scale=1.0,
    variance_damping=1e-5,
    a_tol: float = 1e-9,
    b_tol: float = 1e-9,
    max_steps: int = 1000,
    damping=0.0,
):
    index_mask = jnp.ones_like(far_field_intensities)
    index_mask = index_mask.at[jnp.less(far_field_intensities, 0)].set(0)
    dummy_intensities = jnp.square(jnp.abs(jnp.fft.fft2(near_field_support_mask)))
    autocorr_mask = jnp.fft.rfftn(dummy_intensities)
    autocorr_mask = jnp.where(autocorr_mask > 0, 1, 0)
    masked_intensities = index_mask * far_field_intensities

    variances = variance_scale * masked_intensities
    weights = 1.0 / jnp.sqrt(variances + variance_damping)
    weights = weights.at[jnp.equal(index_mask, 0)].set(0)
    non_neg_intensities = far_field_intensities.at[far_field_intensities < 0].set(0)
    init_autocorr = jnp.fft.rfftn(non_neg_intensities)
    x_0 = init_autocorr * autocorr_mask

    rhs = weights * non_neg_intensities

    # Separate out the jittable portions of the function.
    lsmr_result = setup_solve_gaussian_system(
        rhs, x_0, autocorr_mask, weights, a_tol, b_tol, max_steps, damping
    )
    x_out = lsmr_result.x * autocorr_mask
    intensities_out = jnp.fft.irfftn(x_out, s=far_field_intensities.shape)
    return intensities_out
