from OpenGL.GL import *
import ctypes

class Mesh:
    def __init__(self, vertices):
        self.vbo = glGenBuffers(1)
        self.vao = glGenVertexArrays(1)
        glBindVertexArray(self.vao)
        glBindBuffer(GL_ARRAY_BUFFER, self.vbo)
        glBufferData(GL_ARRAY_BUFFER, vertices.nbytes, vertices, GL_STATIC_DRAW)
        self.vertex_count = len(vertices) // 6 
        # ... (configuração de atributos que já fizemos)

class InstancedMesh(Mesh):
    def __init__(self, vertices, instance_offsets):
        super().__init__(vertices)
        self.instance_count = len(instance_offsets)
        self.instance_vbo = glGenBuffers(1)
        glBindBuffer(GL_ARRAY_BUFFER, self.instance_vbo)
        glBufferData(GL_ARRAY_BUFFER, instance_offsets.nbytes, instance_offsets, GL_STATIC_DRAW)

    def draw_instanced(self):
        glBindVertexArray(self.vao)
        glBindBuffer(GL_ARRAY_BUFFER, self.instance_vbo)
        glEnableVertexAttribArray(2)
        glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 0, None)
        glVertexAttribDivisor(2, 1)
        glDrawArraysInstanced(GL_TRIANGLES, 0, self.vertex_count, self.instance_count)
