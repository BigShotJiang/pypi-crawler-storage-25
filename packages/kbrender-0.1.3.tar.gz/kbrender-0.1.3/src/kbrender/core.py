import pygame
from OpenGL.GL import *

class Engine:
    def __init__(self, width=800, height=600):
        pygame.init()
        self.screen = pygame.display.set_mode((width, height), pygame.OPENGL | pygame.DOUBLEBUF)
        pygame.display.set_caption("kbrender Engine v0.1.0")
        
        # Configurações básicas de quem "encosta" na luz (Z-Buffer)
        glEnable(GL_DEPTH_TEST) # Ativa o teste de profundidade
        glEnable(GL_CULL_FACE)  # Não desenha o que está atrás (performance!)
        
    def clear(self, r=0.1, g=0.1, b=0.1):
        """Limpa a tela e o buffer de profundidade para o próximo frame"""
        glClearColor(r, g, b, 1.0)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

    def update(self):
        pygame.display.flip()
