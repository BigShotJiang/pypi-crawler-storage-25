from OpenGL.GL import *
from OpenGL.GL import shaders
import numpy as np

class Shader:
    def __init__(self, vertex_code, fragment_code):
        # Compila os códigos que rodam na GPU
        self.program = shaders.compileProgram(
            shaders.compileShader(vertex_code, GL_VERTEX_SHADER),
            shaders.compileShader(fragment_code, GL_FRAGMENT_SHADER)
        )

    def use(self):
        glUseProgram(self.program)

    def set_uniform(self, name, value):
        # Envia dados da RAM para a VRAM (ex: posição da luz)
        location = glGetUniformLocation(self.program, name)
        if isinstance(value, (list, tuple, np.ndarray)):
            glUniform3fv(location, 1, value)
        else:
            glUniform1f(location, value)
