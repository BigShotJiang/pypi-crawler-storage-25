import numpy as np
import math

class MathEngine:
    @staticmethod
    def perspective(fovy, aspect, near, far):
        """Cria a matriz de perspectiva (Visão 3D)"""
        f = 1.0 / math.tan(math.radians(fovy) / 2.0)
        return np.array([
            [f/aspect, 0, 0, 0],
            [0, f, 0, 0],
            [0, 0, (far+near)/(near-far), (2*far*near)/(near-far)],
            [0, 0, -1, 0]
        ], dtype=np.float32)

    @staticmethod
    def translate(x, y, z):
        """Matriz de movimento"""
        return np.array([
            [1, 0, 0, x],
            [0, 1, 0, y],
            [0, 0, 1, z],
            [0, 0, 0, 1]
        ], dtype=np.float32)

    @staticmethod
    def rotate_y(theta):
        """Matriz de rotação no eixo Y (para a grama balançar)"""
        c, s = math.cos(theta), math.sin(theta)
        return np.array([
            [c, 0, s, 0],
            [0, 1, 0, 0],
            [-s, 0, c, 0],
            [0, 0, 0, 1]
        ], dtype=np.float32)
