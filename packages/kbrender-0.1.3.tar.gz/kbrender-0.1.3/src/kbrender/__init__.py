import os

# Força o modo EGL (Mobile) logo de cara
os.environ['PYOPENGL_PLATFORM'] = 'egl'

# Importa as classes dos sub-arquivos para o "topo" da biblioteca
from .core import Engine
from .renderer import Shader
from .mesh import Mesh, InstancedMesh
from .math_engine import MathEngine  # <-- FALTAVA ESSA LINHA!

__version__ = "0.1.3"

def init():
    print(f"kbrender v{__version__} inicializada (EGL Mode)")
