# kbrender 🚀
A high-performance rendering library for mobile.

- **Fast:** Geometry Instancing for grass and fur.
- **Physics-based:** Silk and wool materials.
- **Optimized:** Heavy math stays in the GPU.

## Install
pip install kbrender
