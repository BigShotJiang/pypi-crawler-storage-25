"""Private SQLite persistence implementation for BenchCaddy."""
