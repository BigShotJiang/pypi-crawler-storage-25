# ⚡ NEON-BURP PRO
### *Advanced Web Security Framework & Penetration Testing Suite*

[![Python](https://img.shields.io/badge/Python-3.10%2B-00f3ff?style=for-the-badge&logo=python)](https://www.python.org/)
[![Framework](https://img.shields.io/badge/Framework-Flask-39ff14?style=for-the-badge&logo=flask)](https://flask.palletsprojects.com/)
[![License](https://img.shields.io/badge/License-MIT-ff00ff?style=for-the-badge)](https://opensource.org/licenses/MIT)
[![Maintainer](https://img.shields.io/badge/Developer-Amjad--Purple-white?style=for-the-badge)](https://github.com/Amjad-Purple)

---

## 📖 Overview
**Neon-Burp Pro** is a lightweight, asynchronous security auditing framework designed for rapid web application assessment. It combines the power of traditional intercepting proxies with a modernized, API-driven Neon interface. Built for speed, efficiency, and deep-dive analysis.

## 🛠️ Core Modules

### 1. 🛡️ Vulnerability Research Engine
Equipped with a proprietary scanning logic to detect:
- **Injection Flaws:** SQLi (Error-based & Blind), RCE, and LFI.
- **Cross-Site Scripting:** Reflected XSS detection via parameter analysis.
- **Security Misconfigurations:** Missing HSTS, CSP, and X-Frame-Options.

### 2. 💣 Advanced Intruder (Fuzzer)
A high-speed fuzzing engine for directory discovery and parameter brute-forcing. 
- Supports custom payloads and wordlists.
- Real-time status code and response size monitoring.

### 3. 🔄 Request Repeater & Forge
A dedicated environment for manual request manipulation.
- Full control over HTTP headers, cookies, and body data.
- Instant response rendering for rapid debugging.

### 4. 🔐 Crypto-Toolkit (Decoder)
On-the-fly encoding and decoding support:
- Base64, URL Encoding, Hex, and MD5/SHA hash identification.

---

## 🚀 Quick Start

### Installation
Ensure you have Python 3.10+ installed.

$ git clone https://github.com/Amjad-Purple/Nburp.git
$ cd Nburp
$ pip install -r requirements.txt

### Deployment
$ python3 Nburp.py

The dashboard will be initialized at: http://127.0.0.1:5000

---

## 🏗️ Technical Architecture
Nburp Pro operates on a decoupled architecture:
- **Backend:** Python/Flask RESTful API handling the security logic.
- **Frontend:** Responsive Neon-CSS UI using Vanilla JS for real-time data fetching.
- **Engine:** Requests-based HTTP client with SSL/TLS verification bypass for internal auditing.

---

## ⚖️ Legal Disclaimer
**For Educational and Ethical Testing Only.** Usage of Nburp for attacking targets without prior mutual consent is illegal. The developer (Amjad-Purple) assumes no liability and is not responsible for any misuse or damage caused by this program.

---

## 🤝 Contributing
We welcome contributions to the Nburp core! 
1. Fork the Project
2. Create your Feature Branch
3. Commit your Changes
4. Push to the Branch
5. Open a Pull Request

## 👤 Contact & Support
**Lead Developer:** Amjad (@Amjad-Purple)  
**GitHub:** https://github.com/Amjad-Purple  
**Project Link:** https://github.com/Amjad-Purple/Nburp.git
