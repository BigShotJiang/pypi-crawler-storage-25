"""Sprout specific checks."""
