# Enoch MCP Server — Autopilot Prompt

## Goal

Build `enoch-mcp`: a Python MCP (Model Context Protocol) server that wraps the existing Enoch FastAPI control-plane API and exposes its operations as tools for AI assistants (Claude Desktop, Cursor, Copilot, Windsurf, etc.).

This is a **thin bridge**, not a rewrite. The MCP server calls Enoch's existing HTTP endpoints. No business logic lives in the MCP server itself.

## What Enoch Is

Enoch is an open-source control plane for long-running local AI agent jobs. It:

- Queues research ideas separately from execution
- Gates dispatch (requires worker health checks before sending work)
- Prevents overlapping GPU-heavy runs (single-lane safety)
- Tracks process/telemetry state during execution
- Detects completion via wake-gate quiet windows
- Syncs evidence back from the worker to the control plane
- Packages artifacts with claim/provenance metadata
- Runs quality gates before artifacts are finalized

**Repo:** https://github.com/alias8818/enoch-agentic-research-system
**Package name:** `omx-wake-gate` (pyproject.toml)
**Python:** >=3.11
**Framework:** FastAPI + Pydantic v2

## Existing Enoch API Endpoints (what the MCP server wraps)

The Enoch FastAPI service runs on `http://localhost:8000` by default. Two router prefixes exist:

### Control Plane Router (`/control/` prefix)

**Read-only status:**
- `GET /control/api/status?refresh_worker=true` — Full system status (dispatch_safe, flags, counts, active items, source freshness, warnings, conflicts)
- `GET /control/api/queue-health?refresh_worker=true` — Queue health with alert findings
- `GET /control/api/queues/{queue_name}?page_size=100&search=` — Queue items by status (active, queued, blocked, paused)
- `GET /control/api/papers?page=1&page_size=50&search=&status=&sort=-updated_at` — Paper listing
- `GET /control/api/papers/{paper_id}` — Paper detail with project, run, events, warnings
- `GET /control/api/papers/{paper_id}/artifact/{field}` — Paper artifact content (field: draft_markdown_path, draft_latex_path, evidence_bundle_path, claim_ledger_path, manifest_path)
- `GET /control/api/paper-reviews?page=1&page_size=100&search=&review_status=&paper_status=&include_rank_reasons=true` — Publication review queue
- `GET /control/api/paper-reviews/{paper_id}` — Single paper review detail with checklist
- `GET /control/api/paper-reviews/next?paper_status=publication_draft` — Next review candidate
- `GET /control/api/projects/{project_id}` — Project detail
- `GET /control/api/runs/{run_id}` — Run detail
- `GET /control/api/events?page=1&page_size=100&entity_type=&entity_id=&event_type=&search=` — Event log
- `GET /control/api/intake/notion` — Notion intake status
- `GET /control/export/snapshot` — Full state export
- `GET /control/projections/notion/queue` — Notion queue projection
- `GET /control/projections/notion/papers` — Notion papers projection

**Mutating (require explicit human approval in MCP):**
- `POST /control/dispatch-next` — Dispatch next queued item to worker (body: `{requested_by, dry_run, force_preflight}`)
- `POST /control/pause` — Pause queue (body: `{reason, paused_by, maintenance_mode}`)
- `POST /control/resume` — Resume queue (body: `{resumed_by, maintenance_mode}`)
- `POST /control/queue/mark-paused` — Pause specific queue item (body: `{project_id, reason, updated_by}`)
- `POST /control/worker/preflight` — Run worker health preflight check (body: `{...}`)
- `POST /control/api/preflight` — Dashboard preflight
- `POST /control/intake/notion-ideas` — Ingest Notion ideas (body: `{idempotency_key, source, ideas[], dry_run}`)
- `POST /control/import/legacy-snapshot` — Import snapshot
- `POST /control/papers/draft-next` — Draft next paper (body: `{requested_by, force}`)
- `POST /control/api/paper-reviews/{paper_id}/claim` — Claim a review
- `POST /control/api/paper-reviews/{paper_id}/checklist/{item_id}` — Update checklist item
- `POST /control/api/paper-reviews/{paper_id}/status` — Update review status
- `POST /control/api/paper-reviews/{paper_id}/approve-finalization` — Approve finalization
- `POST /control/api/paper-reviews/{paper_id}/rewrite-draft` — Rewrite draft with LLM
- `POST /control/api/paper-reviews/rewrite-batch` — Batch rewrite
- `POST /control/api/paper-reviews/{paper_id}/prepare-finalization-package` — Prepare finalization package

### Enoch Core Router (`/enoch-core/` prefix)

- `GET /enoch-core/health` — Core health check (returns mode: off/shadow/compare/enforce)
- `POST /enoch-core/snapshots/n8n-queue` — Ingest n8n queue snapshot
- `GET /enoch-core/projections/queue?mode=` — Queue projection
- `GET /enoch-core/candidates/paper-draft?mode=` — Next paper draft candidate
- `GET /enoch-core/candidates/paper-polish?mode=` — Next paper polish candidate

**Auth:** All endpoints require `Authorization: Bearer <token>` header.

## MCP Tools to Implement

### Read-Only Tools (safe, no approval needed)

1. **`enoch_status`** — Full system status. Calls `GET /control/api/status?refresh_worker=true`. Returns: dispatch_safe, flags, counts, active items, source freshness, warnings, conflicts. The assistant can say "dispatch is safe, 3 items queued, 1 active."

2. **`enoch_queue_health`** — Queue health with worker freshness. Calls `GET /control/api/queue-health?refresh_worker=true`. Returns: active runs, alert findings, worker freshness, recent events.

3. **`enoch_queue_list`** — List queue items by status. Calls `GET /control/api/queues/{status}`. Parameters: `status` (active|queued|blocked|paused), `search` (optional). Returns: paginated queue items with project_id, status, priority, last run state.

4. **`enoch_papers_list`** — List papers. Calls `GET /control/api/papers`. Parameters: `search`, `status`, `page`, `page_size`. Returns: paginated paper rows with links.

5. **`enoch_paper_detail`** — Get paper detail with artifacts. Calls `GET /control/api/papers/{paper_id}`. Returns: paper record, project, run, events, warnings, missing artifacts.

6. **`enoch_paper_artifact`** — Read a paper's artifact content. Calls `GET /control/api/papers/{paper_id}/artifact/{field}`. Parameters: `paper_id`, `field` (draft_markdown_path|draft_latex_path|evidence_bundle_path|claim_ledger_path|manifest_path). Returns: artifact content, path, size. Note: content is truncated at 1MB by Enoch.

7. **`enoch_reviews_list`** — List publication reviews. Calls `GET /control/api/paper-reviews`. Parameters: `review_status`, `paper_status`, `search`, `page`. Returns: review rows with checklist progress, rank scores.

8. **`enoch_review_next`** — Get next review candidate. Calls `GET /control/api/paper-reviews/next?paper_status=publication_draft`. Returns: next unreviewed paper.

9. **`enoch_events`** — Query the event log. Calls `GET /control/api/events`. Parameters: `entity_type`, `entity_id`, `event_type`, `search`, `page`. Returns: paginated event rows.

10. **`enoch_core_health`** — Enoch core health/mode. Calls `GET /enoch-core/health`. Returns: mode, db_path, timestamp.

11. **`enoch_core_queue_projection`** — Queue projection from core. Calls `GET /enoch-core/projections/queue`. Parameters: `mode`. Returns: status counts, active rows, candidate counts.

12. **`enoch_core_paper_candidates`** — Next paper draft/polish candidate. Calls `GET /enoch-core/candidates/paper-draft` or `paper-polish`. Parameters: `kind` (draft|polish), `mode`. Returns: candidate info, action, reason.

### Mutating Tools (require human approval via MCP)

13. **`enoch_dispatch`** — Dispatch next queued item. Calls `POST /control/dispatch-next`. Parameters: `requested_by`, `dry_run` (default true), `force_preflight`. **Default dry_run=true** — the assistant must explicitly set dry_run=false to actually dispatch. This is a safety gate.

14. **`enoch_pause`** — Pause the queue. Calls `POST /control/pause`. Parameters: `reason`, `maintenance_mode`.

15. **`enoch_resume`** — Resume the queue. Calls `POST /control/resume`. Parameters: `maintenance_mode`.

16. **`enoch_preflight`** — Run worker health preflight. Calls `POST /control/worker/preflight`. Returns: worker health, GPU status, can_dispatch.

17. **`enoch_intake_notion`** — Ingest Notion ideas. Calls `POST /control/intake/notion-ideas`. Parameters: `ideas`, `dry_run` (default true). **Default dry_run=true.**

18. **`enoch_review_claim`** — Claim a paper review. Calls `POST /control/api/paper-reviews/{paper_id}/claim`. Parameters: `paper_id`, `claimed_by`.

19. **`enoch_review_checklist`** — Update a review checklist item. Calls `POST /control/api/paper-reviews/{paper_id}/checklist/{item_id}`. Parameters: `paper_id`, `item_id`, `status` (pass|fail|accepted_risk), `note`.

20. **`enoch_review_status`** — Update review status. Calls `POST /control/api/paper-reviews/{paper_id}/status`. Parameters: `paper_id`, `review_status`, `updated_by`.

21. **`enoch_draft_paper`** — Draft next paper. Calls `POST /control/papers/draft-next`. Parameters: `requested_by`, `force`. **Requires approval.**

22. **`enoch_rewrite_draft`** — Rewrite a paper draft with LLM. Calls `POST /control/api/paper-reviews/{paper_id}/rewrite-draft`. Parameters: `paper_id`, `requested_by`, `force`. **Requires approval.**

## Security Model

- **Read-only by default.** The 12 read-only tools need no approval.
- **Mutating tools require explicit human approval.** MCP protocol supports this natively — mark these tools with `userApproval` in the tool metadata.
- **dry_run defaults to true** for dispatch and intake. The assistant must explicitly override to false.
- **No shell execution through MCP.** The MCP server only makes HTTP calls to the Enoch API.
- **No hidden model calls.** The MCP server does not call any LLM itself.
- **Local-only binding by default.** The Enoch API URL defaults to `http://localhost:8000`.
- **Bearer token required.** Configured via environment variable `ENOCH_API_TOKEN` or `--api-token` flag.
- **No write access to filesystem.** The MCP server reads artifact content from the API, it never writes files.

## Technical Requirements

- **Python package:** `enoch-mcp`
- **Run via:** `uvx enoch-mcp --api-url http://localhost:8000 --api-token <token>`
- **MCP transport:** stdio (standard for local tools)
- **Dependencies:** `mcp` (official Python MCP SDK from modelcontextprotocol/python-sdk), `httpx` (async HTTP client), `pydantic>=2`
- **Python:** >=3.11
- **Async:** Use async throughout (MCP SDK is async-native, httpx is async)
- **Error handling:** Translate Enoch HTTP errors (4xx, 5xx) into MCP tool errors with clear messages
- **Type hints:** Full type annotations on all tool parameters and return values
- **No business logic duplication:** The MCP server is a pure HTTP proxy. If Enoch adds an endpoint, the MCP server should only need a new tool definition to expose it.

## Project Structure

```
enoch-mcp/
├── pyproject.toml
├── README.md
├── src/
│   └── enoch_mcp/
│       ├── __init__.py
│       ├── server.py          # MCP server setup, tool registration
│       ├── client.py          # Async HTTP client for Enoch API
│       ├── tools_readonly.py  # Read-only tool implementations
│       ├── tools_mutating.py  # Mutating tool implementations (marked userApproval)
│       └── config.py          # CLI args, env vars, API URL/token defaults
├── tests/
│   ├── test_client.py
│   ├── test_tools_readonly.py
│   └── test_tools_mutating.py
└── .github/
    └── workflows/
        └── test.yml
```

## Implementation Commands (suggestions, not requirements)

These are the commands I think the project should expose. Codex may add, change, or remove any of these as it sees fit. The goal is a working, well-tested MCP server — the specific tool names and parameter shapes are starting points, not constraints.

**Run/debug:**
- `uvx enoch-mcp` — Start the MCP server on stdio
- `uvx enoch-mcp --api-url http://localhost:8000 --api-token TOKEN` — With explicit config
- `python -m enoch_mcp` — Development run

**Test:**
- `pytest` — Run all tests
- `pytest tests/test_tools_readonly.py` — Read-only tools only
- `pytest tests/test_tools_mutating.py` — Mutating tools only

**Publish:**
- `uv build` — Build sdist + wheel
- `uv publish` — Publish to PyPI (when ready)

## What NOT to Do

- Do **not** implement Enoch business logic in the MCP server. It is a proxy.
- Do **not** add authentication logic beyond passing the Bearer token. Enoch handles auth.
- Do **not** add caching, retry logic, or circuit breakers. Keep it thin.
- Do **not** expose file paths or shell commands through MCP tools.
- Do **not** create framework-specific integrations (LangChain, CrewAI). MCP is the narrow waist.
- Do **not** include the generated corpus or any paper content as MCP assets.
- Do **not** add telemetry, analytics, or tracking to the MCP server.

## Acceptance Criteria

1. `uvx enoch-mcp --api-url http://localhost:8000 --api-token test` starts without error
2. Claude Desktop can connect to it as an MCP server and discover all 22 tools
3. All 12 read-only tools return data when pointed at a running Enoch instance
4. All 10 mutating tools default to safe behavior (dry_run=true or require approval)
5. `pytest` passes with mocked Enoch API responses
6. README includes: what this is, how to install, how to configure, how to use with Claude Desktop/Cursor
7. README does NOT include marketing language, superlatives, or pitch framing
8. Package is structured for PyPI publishing (pyproject.toml with correct metadata)

## Context for the Implementer

- The Enoch repo is at https://github.com/alias8818/enoch-agentic-research-system
- The MCP Python SDK is at https://github.com/modelcontextprotocol/python-sdk
- The MCP specification is at https://spec.modelcontextprotocol.io
- Enoch uses FastAPI + Pydantic v2, so response shapes are well-defined
- The MCP server does NOT need the Enoch source code — it only needs the API endpoint documentation above
- The `userApproval` annotation on mutating tools is part of the MCP spec for tools that require human confirmation before execution

## One More Thing

The goal is not "ship an MCP server." The goal is: someone running Enoch locally can point Claude Desktop or Cursor at it and have their AI assistant act as a dispatch operator — checking queue health, reading evidence bundles, approving dispatch, reviewing paper artifacts. The MCP server is the bridge that makes that possible. Build accordingly.
