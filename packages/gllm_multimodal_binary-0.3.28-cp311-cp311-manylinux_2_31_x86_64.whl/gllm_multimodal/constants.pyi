from enum import StrEnum

DEFAULT_ROUTER_EMBEDDING_MODEL: str

class ImageToTextConstants:
    """Constants for image-to-text operations in Gen AI applications."""
    NOT_GIVEN: str
    FILENAME: str
    NO_IMAGE_FILENAME: str

class CaptionConstants:
    """Constants for caption operations in Gen AI applications."""
    CAPTION_DEFAULT_JSON_KEY: str
    DOMAIN_KNOWLEDGE: str
    IMAGE_DESCRIPTION: str
    IMAGE_METADATA: str
    IMAGE_ONE_LINER: str
    NUMBER_OF_CAPTIONS: str
    ATTACHMENTS_CONTEXT: str
    IS_STRUCTURED_CAPTION: str
    DEFAULT_NUMBER_OF_CAPTIONS: int

class ExifConstants:
    """Constants for EXIF tag operations in image metadata extraction."""
    GPS_LATITUDE: str
    GPS_LATITUDE_REF: str
    GPS_LONGITUDE: str
    GPS_LONGITUDE_REF: str
    GPS_SOUTH: str
    GPS_WEST: str
    LATITUDE: str
    LONGITUDE: str

class Modality(StrEnum):
    """Defines supported modalities."""
    IMAGE: str
    TEXT: str
    AUDIO: str
    VIDEO: str

class ModalityConverterApproach(StrEnum):
    """Defines supported modality converter approach types."""
    LM_BASED: str
    WHISPER: str
    GEMINI: str
    GOOGLE_CLOUD: str
    PROSA: str
    YOUTUBE: str

class ModalityConverterTask(StrEnum):
    """Defines supported modality converter tasks."""
    CAPTIONING: str
    MERMAID: str
    TRANSCRIPT: str
    AUTO: str

class WhisperResponseKeys:
    """String keys used when parsing OpenAI Whisper API responses."""
    SEGMENTS: str
    WORDS: str
    LANGUAGE: str
    TEXT: str
    AUDIO_TRANSCRIPTS: str

class CaptionOutputFormattingStrategy(StrEnum):
    """Defines how output should be formatted."""
    TEXT: str
    STRUCTURED: str

class ModalityConverterBuildStrategy(StrEnum):
    """Defines how a modality converter should be constructed from its configuration."""
    PRESET: str
    LMRP: str
    KWARGS: str

class ModalityTransformerType(StrEnum):
    """Defines supported modality transformer types."""
    STANDARD: str
    GENERIC: str

class ModalityTransformerRouterPreset(StrEnum):
    """Defines supported modality transformer router presets."""
    MULTIMODAL: str
    DOMAIN_SPECIFIC: str

class ConverterResultTag(StrEnum):
    """Defines converter result tags."""
    CAPTION: str
    MERMAID: str
    STRUCTURED_CAPTION: str

class AudioFormatConstants:
    """Constants for audio format related keys and MIME types."""
    MIME_MPEG: str
    MIME_WAV: str
    MIME_OGG: str
    MIME_MP4: str
    MIME_FLAC: str
    FORMAT_MP3: str
    FORMAT_MPEG: str
    FORMAT_MPGA: str
    FORMAT_M4A: str
    FORMAT_WAV: str
    FORMAT_WAVE: str
    FORMAT_FLAC: str
    FORMAT_OGG: str
    FORMAT_OGA: str
    FORMAT_TO_MIME_TYPE: dict[str, str]
