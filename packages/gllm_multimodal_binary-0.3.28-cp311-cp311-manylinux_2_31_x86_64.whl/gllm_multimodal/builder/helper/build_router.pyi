from _typeshed import Incomplete
from gllm_multimodal.constants import ModalityTransformerRouterPreset as ModalityTransformerRouterPreset
from gllm_multimodal.modality_transformer.schema.router_config import RouterConfig as RouterConfig
from gllm_pipeline.router.aurelio_semantic_router import AurelioSemanticRouter
from gllm_pipeline.router.lm_based_router import LMBasedRouter
from gllm_pipeline.router.router import BaseRouter

logger: Incomplete

def build_router(router_config: RouterConfig) -> BaseRouter:
    """Build a router from a RouterConfig instance.

    Args:
        router_config (RouterConfig): Router configuration.

    Returns:
        BaseRouter: The constructed router instance.
    """
def build_multimodal_router(router_config: RouterConfig) -> AurelioSemanticRouter:
    """Build a multimodal router from a RouterConfig instance.

    If both es_url and es_index_name are provided, an
    Elasticsearch vector data store is attached to the router.

    Args:
        router_config (RouterConfig): Router configuration.

    Returns:
        AurelioSemanticRouter: The constructed router instance.
    """
def build_domain_specific_router(router_config: RouterConfig) -> LMBasedRouter:
    """Build a domain-specific router from a RouterConfig instance.

    Args:
        router_config (RouterConfig): Router configuration.

    Returns:
        LMBasedRouter: The constructed router instance.
    """

ROUTER_REGISTRY: Incomplete
