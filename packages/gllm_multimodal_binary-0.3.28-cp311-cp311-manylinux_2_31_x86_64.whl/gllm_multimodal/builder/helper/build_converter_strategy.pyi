from _typeshed import Incomplete
from dataclasses import dataclass, field
from gllm_multimodal.constants import ModalityConverterBuildStrategy as ModalityConverterBuildStrategy
from gllm_multimodal.modality_converter.modality_converter import BaseModalityConverter as BaseModalityConverter
from typing import Any

logger: Incomplete
LMRP_CONFIG_KEY: str

@dataclass
class PresetBuildConfig:
    """Config for building a converter using a named preset."""
    preset: str
    extra_kwargs: dict[str, Any] = field(default_factory=dict)
    def build(self, cls: type[BaseModalityConverter]) -> BaseModalityConverter:
        """Build a converter using a named preset.

        Args:
            cls (type[BaseModalityConverter]): The converter class to build.

        Returns:
            BaseModalityConverter: The built converter.
        """

@dataclass
class LMRPBuildConfig:
    """Config for building a converter using an LMRP configuration."""
    lmrp_config: dict[str, Any]
    extra_kwargs: dict[str, Any] = field(default_factory=dict)
    def build(self, cls: type[BaseModalityConverter]) -> BaseModalityConverter:
        """Build a converter using an LMRP configuration.

        Args:
            cls (type[BaseModalityConverter]): The converter class to build.

        Returns:
            BaseModalityConverter: The built converter.
        """

@dataclass
class KwargsBuildConfig:
    """Config for building a converter using raw keyword arguments."""
    kwargs: dict[str, Any] = field(default_factory=dict)
    def build(self, cls: type[BaseModalityConverter]) -> BaseModalityConverter:
        """Build a converter using raw keyword arguments.

        Args:
            cls (type[BaseModalityConverter]): The converter class to build.

        Returns:
            BaseModalityConverter: The built converter.
        """
ConverterBuildConfig = PresetBuildConfig | LMRPBuildConfig | KwargsBuildConfig

def determine_build_strategy(preset: str | None, kwargs: dict[str, Any]) -> ModalityConverterBuildStrategy:
    """Determine the build strategy from the provided configuration.

    Priority by order:
    1. LMRP config -> LMRP strategy
    2. Preset -> PRESET strategy
    3. Fallback -> KWARGS strategy

    Args:
        preset (str | None): The preset to use.
        kwargs (dict[str, Any]): Additional keyword arguments.

    Returns:
        ModalityConverterBuildStrategy: The determined build strategy.
    """
def build_config_from_params(strategy: ModalityConverterBuildStrategy, preset: str | None, kwargs: dict[str, Any]) -> ConverterBuildConfig:
    """Construct the typed build config for the given strategy.

    Args:
        strategy (ModalityConverterBuildStrategy): The build strategy.
        preset (str | None): The preset name, required for PRESET strategy.
        kwargs (dict[str, Any]): Remaining keyword arguments from the caller.

    Returns:
        ConverterBuildConfig: Config instance carrying the build logic for the strategy.

    Raises:
        ValueError: If the strategy is unsupported or required params are missing.
    """
