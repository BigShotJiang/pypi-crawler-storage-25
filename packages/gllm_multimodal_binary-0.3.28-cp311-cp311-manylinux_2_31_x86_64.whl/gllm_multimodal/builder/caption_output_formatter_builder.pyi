from gllm_multimodal.constants import CaptionOutputFormattingStrategy as CaptionOutputFormattingStrategy
from gllm_multimodal.modality_converter.image_to_text.image_to_caption.output_formatter import BaseCaptionOutputFormatter as BaseCaptionOutputFormatter, FreeTextCaptionOutputFormatter as FreeTextCaptionOutputFormatter, StructuredCaptionOutputFormatter as StructuredCaptionOutputFormatter

CAPTION_OUTPUT_FORMATTER_REGISTRY: dict

def build_caption_output_formatter(formatting_strategy: CaptionOutputFormattingStrategy) -> BaseCaptionOutputFormatter:
    """Build a caption output formatter based on the provided formatting strategy.

    Args:
        formatting_strategy (CaptionOutputFormattingStrategy): The formatting strategy to use.

    Returns:
        BaseCaptionOutputFormatter: The caption output formatter.
    """
