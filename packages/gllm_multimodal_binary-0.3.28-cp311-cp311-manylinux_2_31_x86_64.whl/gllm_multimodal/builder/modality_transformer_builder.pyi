from _typeshed import Incomplete
from gllm_multimodal.constants import Modality as Modality, ModalityTransformerType as ModalityTransformerType
from gllm_multimodal.modality_transformer.image_modality_transformer.generic_image_modality_transformer import GenericImageModalityTransformer as GenericImageModalityTransformer
from gllm_multimodal.modality_transformer.image_modality_transformer.standard_image_modality_transformer import StandardImageModalityTransformer as StandardImageModalityTransformer
from gllm_multimodal.modality_transformer.modality_transformer import BaseModalityTransformer as BaseModalityTransformer
from gllm_multimodal.modality_transformer.schema.converter_config import ConverterConfig as ConverterConfig
from gllm_multimodal.modality_transformer.schema.router_config import RouterConfig as RouterConfig

MODALITY_TRANSFORMER_REGISTRY: Incomplete
logger: Incomplete

def build_modality_transformer(source_modality: Modality = ..., target_modality: Modality = ..., transformer_type: ModalityTransformerType = ..., router_config: RouterConfig | None = None, converter_config: dict[str, ConverterConfig] | None = None, **kwargs) -> BaseModalityTransformer:
    '''Build and initialize a modality transformer instance for a given configuration.

    The factory looks up the converter class based on the combination of:
        - source_modality: input modality (e.g., Modality.IMAGE, Modality.AUDIO)
        - target_modality: output modality (e.g., Modality.TEXT)
        - transformer_type: transformer type (e.g., ModalityTransformerType.STANDARD)

    The factory then delegates construction to each class\'s from_config() classmethod.

    Args:
        source_modality (Modality, optional): The source modality.
            Defaults to Modality.IMAGE.
        target_modality (Modality, optional): The output modality.
            Defaults to Modality.TEXT.
        transformer_type (ModalityTransformerType, optional): The transformer type.
            Defaults to ModalityTransformerType.STANDARD.
        router_config (RouterConfig | None): Additional router configuration.
            Defaults to None.
        converter_config (dict[str, ConverterConfig] | None): Additional converter configuration.
            Defaults to None.
        **kwargs: Additional keyword arguments passed to transformer.

    Returns:
        BaseModalityTransformer: An instance of the matching transformer class.

    Raises:
        ValueError: If the configuration is invalid or not registered, including:
            - (source_modality, target_modality, transformer_type) not registered.

    Examples:
        1. Default routers and default converters.
            >>> build_modality_transformer(
            ...     source_modality=Modality.IMAGE,
            ...     target_modality=Modality.TEXT,
            ...     transformer_type=ModalityTransformerType.STANDARD,
            ... )

        2. Custom router and default converters.
            Note: route_mapping values must match the keys used in converter_config
            (e.g., "captioning", "mermaid" when using default converters).
            >>> build_modality_transformer(
            ...     source_modality=Modality.IMAGE,
            ...     target_modality=Modality.TEXT,
            ...     transformer_type=ModalityTransformerType.STANDARD,
            ...     router_config=RouterConfig(
            ...         modality=Modality.IMAGE,
            ...         preset="multimodal",
            ...         model_id="openai/text-embedding-3-small",
            ...         es_url="http://localhost:9200",
            ...         es_index_name="gllm_multimodal",
            ...         route_mapping={
            ...             "chart": "captioning",
            ...             "diagram": "mermaid",
            ...         }
            ...     )
            ... )

        3. Default router and custom converters with preset.
            # Additional imports needed for examples 3-5:
            # from gllm_multimodal.constants import ModalityConverterTask, ModalityConverterApproach
            >>> build_modality_transformer(
            ...     source_modality=Modality.IMAGE,
            ...     target_modality=Modality.TEXT,
            ...     transformer_type=ModalityTransformerType.STANDARD,
            ...     converter_config={
            ...         "captioning": ConverterConfig(
            ...             source_modality=Modality.IMAGE,
            ...             target_modality=Modality.TEXT,
            ...             task_type=ModalityConverterTask.CAPTIONING,
            ...             approach_type=ModalityConverterApproach.LM_BASED,
            ...             preset="default",
            ...         ),
            ...         "mermaid": ConverterConfig(
            ...             source_modality=Modality.IMAGE,
            ...             target_modality=Modality.TEXT,
            ...             task_type=ModalityConverterTask.MERMAID,
            ...             approach_type=ModalityConverterApproach.LM_BASED,
            ...             preset="default",
            ...         ),
            ...     }
            ... )

        4. Default router and custom converters with custom LMRP.
            >>> build_modality_transformer(
            ...     source_modality=Modality.IMAGE,
            ...     target_modality=Modality.TEXT,
            ...     transformer_type=ModalityTransformerType.STANDARD,
            ...     converter_config={
            ...         "captioning": ConverterConfig(
            ...             source_modality=Modality.IMAGE,
            ...             target_modality=Modality.TEXT,
            ...             task_type=ModalityConverterTask.CAPTIONING,
            ...             approach_type=ModalityConverterApproach.LM_BASED,
            ...             lmrp_config={
            ...                 "model_id": "google/gemini-3-flash-preview",
            ...                 "system_template": DEFAULT_CAPTION_SYSTEM_PROMPT,
            ...                 "user_template": DEFAULT_CAPTION_USER_PROMPT,
            ...                 "output_parser_type": "json",
            ...             },
            ...         ),
            ...         "mermaid": ConverterConfig(
            ...             source_modality=Modality.IMAGE,
            ...             target_modality=Modality.TEXT,
            ...             task_type=ModalityConverterTask.MERMAID,
            ...             approach_type=ModalityConverterApproach.LM_BASED,
            ...             lmrp_config={
            ...                 "model_id": "openai/gpt-5.2-latest",
            ...                 "system_template": DEFAULT_MERMAID_SYSTEM_PROMPT,
            ...                 "user_template": DEFAULT_MERMAID_USER_PROMPT,
            ...             },
            ...         ),
            ...     }
            ... )

        5. Custom router and custom converters.
            >>> build_modality_transformer(
            ...     source_modality=Modality.IMAGE,
            ...     target_modality=Modality.TEXT,
            ...     transformer_type=ModalityTransformerType.STANDARD,
            ...     router_config=RouterConfig(
            ...         modality=Modality.IMAGE,
            ...         preset="multimodal",
            ...         model_id="openai/text-embedding-3-small",
            ...         route_mapping={
            ...             "chart": "captioning",
            ...             "diagram": "mermaid",
            ...         },
            ...     ),
            ...     converter_config={
            ...         "captioning": ConverterConfig(
            ...             source_modality=Modality.IMAGE,
            ...             target_modality=Modality.TEXT,
            ...             task_type=ModalityConverterTask.CAPTIONING,
            ...             approach_type=ModalityConverterApproach.LM_BASED,
            ...             lmrp_config={
            ...                 "model_id": "google/gemini-3-flash-preview",
            ...                 "system_template": DEFAULT_CAPTION_SYSTEM_PROMPT,
            ...                 "user_template": DEFAULT_CAPTION_USER_PROMPT,
            ...                 "output_parser_type": "json",
            ...             },
            ...         ),
            ...         "mermaid": ConverterConfig(
            ...             source_modality=Modality.IMAGE,
            ...             target_modality=Modality.TEXT,
            ...             task_type=ModalityConverterTask.MERMAID,
            ...             approach_type=ModalityConverterApproach.LM_BASED,
            ...             lmrp_config={
            ...                 "model_id": "openai/gpt-5.2-latest",
            ...                 "system_template": DEFAULT_MERMAID_SYSTEM_PROMPT,
            ...                 "user_template": DEFAULT_MERMAID_USER_PROMPT,
            ...             },
            ...         ),
            ...     }
            ... )
    '''
