from _typeshed import Incomplete
from gllm_inference.schema import Attachment
from gllm_multimodal.constants import ImageToTextConstants as ImageToTextConstants
from gllm_multimodal.utils.gdrive_utils import get_file_from_gdrive as get_file_from_gdrive
from gllm_multimodal.utils.s3_utils import get_file_from_s3 as get_file_from_s3
from gllm_multimodal.utils.source_utils import get_file_from_file_path as get_file_from_file_path, get_file_from_url as get_file_from_url
from typing import Any

logger: Incomplete

def is_valid_binary_data(image_binary_data: bytes, allowed_mime_types: list[str] | None = None) -> bool:
    '''Validate if the provided binary data represents a valid file based on MIME type.

    This function uses the python-magic library to detect the MIME type of binary data
    and validates it against allowed types.

    Args:
        image_binary_data (bytes): The binary data to validate.
        allowed_mime_types (list[str] | None): Optional list of allowed MIME types or prefixes.
            If provided, the function validates if the binary data\'s MIME type matches exactly
            or starts with any of the allowed type strings (prefix matching).
            If not provided, it defaults to checking if the MIME type starts with "image/" or "video/".

    Examples:
                - ["image/png", "image/jpeg"] - exact match for PNG or JPEG
                - ["image/", "video/"] - any image or video type
                - ["image"] - any MIME type starting with "image"

    Returns:
        bool: True if the binary data represents a valid file based on criteria,
            False otherwise.
    '''
def get_image_from_base64(image_source: str) -> bytes | None:
    """Decode and validate a base64 encoded image string.

    This function attempts to:
    1. Decode the provided base64 string
    2. Validate that the decoded data represents a valid image
    3. Return the binary data if both steps succeed

    Args:
        image_source (str): The base64 encoded image string to decode.
            Should be a valid base64 string without the data URI prefix
            (e.g., without 'data:image/jpeg;base64,').

    Returns:
        bytes | None: The decoded image binary data if successful and valid,
            None if either the decoding fails or the data is not a valid image.

    Note:
        1. The function performs validation using is_valid_binary_data()
        2. Invalid base64 strings or non-image data will return None
        3. Logs debug messages on failure for troubleshooting
    """
async def get_image_binary(image_source: Any) -> tuple[bytes | None, str | None]:
    """Retrieve image binary data from various sources.

    This function acts as a unified interface for retrieving image data from different sources:
    1. Local file paths
    2. URLs (HTTP/HTTPS)
    3. Base64 encoded strings
    4. S3 URLs (s3:// or https://)

    The function automatically detects the source type and uses the appropriate method
    to retrieve the image data.

    Args:
        image_source (Any): The source of the image, which can be:
            1. bytes: Direct binary data
            2. str: Base64 string, file path, URL, or S3 URL

    Returns:
        tuple[bytes | None, str | None]: A tuple containing:
            1. The image binary data if successful, None if failed
            2. The filename if available, None for direct binary or base64
    """
def get_unique_non_empty_strings(texts: list[str]) -> list[str]:
    """Get unique non-empty strings from a list of strings and remove whitespace.

    This function takes a list of strings and returns a list of strings where each
    string from the list is not empty or whitespace-only. It also removes duplicates.

    Args:
        texts (list[str]): A list of strings to combine.

    Returns:
        list[str]: A list of strings where each string is not empty or whitespace-only.
    """
def combine_strings(texts: list[str]) -> str:
    """Combine multiple strings into a single string with newline separators.

    This function takes a list of strings and returns a single string where each
    string from the list is on a new line. It filters out any empty or whitespace-only
    strings from the list before joining them.

    Args:
        texts (list[str]): A list of strings to combine.

    Returns:
        str: A single string containing all valid strings, where each string is on a new line.
    """
def resize_image(image_bytes: bytes, target_width: int, target_height: int, preserve_aspect_ratio: bool = True) -> bytes:
    """Resize image to meet target dimension requirements.

    Args:
        image_bytes (bytes): The input image binary data.
        target_width (int): The target width.
        target_height (int): The target height.
        preserve_aspect_ratio (bool): Whether to preserve the aspect ratio while resizing.
            If True, the image is scaled to cover the target dimensions while maintaining aspect ratio.
            If False, the image is resized exactly to the target dimensions.
            Defaults to True.

    Returns:
        bytes: The resized image binary data.

    Examples:
        # Resize with aspect ratio preservation (default)
        # If input is 64x128 and target is 128x128, output will be 128x256
        resized_bytes = resize_image(original_bytes, target_width=128, target_height=128)

        # Resize to exact dimensions without preserving aspect ratio
        # Output will be exactly 128x128 regardless of input aspect ratio
        exact_bytes = resize_image(
            original_bytes,
            target_width=128,
            target_height=128,
            preserve_aspect_ratio=False
        )
    """
def convert_into_structured_caption(text: str) -> dict[str, Any]:
    """Convert a structured caption string (YAML or JSON) into a dictionary.

    Args:
        text (str): The structured caption string to parse.

    Returns:
        dict[str, Any]: The parsed dictionary, or an empty dictionary if parsing fails.
    """
def resize_attachment(attachment: Attachment, target_width: int, target_height: int, preserve_aspect_ratio: bool = True) -> Attachment:
    """Resize an attachment's image if it is smaller than the target dimensions.

    Args:
        attachment (Attachment): The input attachment containing image binary data.
        target_width (int): The minimum target width.
        target_height (int): The minimum target height.
        preserve_aspect_ratio (bool): Whether to preserve the aspect ratio while resizing.
            Defaults to True.

    Returns:
        Attachment: The original attachment if already at or above target dimensions,
            otherwise a new attachment with the resized image.
    """
