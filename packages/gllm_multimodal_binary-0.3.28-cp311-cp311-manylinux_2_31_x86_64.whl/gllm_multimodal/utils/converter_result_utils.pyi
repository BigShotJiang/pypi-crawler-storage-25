from _typeshed import Incomplete
from gllm_multimodal.constants import ConverterResultTag as ConverterResultTag, ModalityConverterTask as ModalityConverterTask
from gllm_multimodal.schema import TextResult as TextResult
from typing import Any

CAPTION_TAGS: Incomplete

def extract_captions_from_result(result: TextResult, selected_route: str | None = None) -> list[str]:
    """Extracts captions from the result based on the result tag and selected route.

    Args:
        result (TextResult): The result of the converter.
        selected_route (str | None): The selected route for the conversion. Defaults to None.

    Returns:
        list[str]: The captions output.
    """
def extract_text_repr_from_result(result: TextResult) -> str | list[str] | dict[str, Any]:
    """Extracts text representation from the result.

    Args:
        result (TextResult): The result of the converter.

    Returns:
        str | list[str] | dict[str, Any]: The text representation.
    """
