from _typeshed import Incomplete

logger: Incomplete

def configure_gst_plugin_path() -> None:
    """Configures GST_PLUGIN_PATH if running in a Conda environment or virtual environment.

    This function checks if GST_PLUGIN_PATH is not already set. If it is not set,
    it attempts to locate the GStreamer plugins directory within the current environment
    (checking CONDA_PREFIX and sys.prefix) and sets the GST_PLUGIN_PATH environment
    variable accordingly.

    This ensures that GStreamer plugins installed in the environment are correctly found.
    """
