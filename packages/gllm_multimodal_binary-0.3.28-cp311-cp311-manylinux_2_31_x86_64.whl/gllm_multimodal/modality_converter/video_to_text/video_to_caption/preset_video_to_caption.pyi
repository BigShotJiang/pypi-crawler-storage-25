from gllm_multimodal.media_toolkit.processor.frame_sampling_processor import GST_AVAILABLE as GST_AVAILABLE, GstFrameSamplingProcessor as GstFrameSamplingProcessor
from typing import Any

DEFAULT_SYSTEM_PROMPT: str
DEFAULT_USER_PROMPT: str

def get_preset_video_to_caption(preset_name: str, lm_invoker_kwargs: dict | None = None, prompt_builder_kwargs: dict | None = None) -> dict[str, Any]:
    """Get the preset configuration for generating video captions.

    Args:
        preset_name (str): The name of the preset to get.
        lm_invoker_kwargs: dict | None: Additional arguments for lm invoker.
        prompt_builder_kwargs: dict | None: Additional arguments for prompt builder.

    Returns:
        dict[str, Any]: A dict containing the preset configuration for video captioning.
          The dict contains the following keys:
          - lm_invoker: The lm invoker instance.
          - prompt_builder: The prompt builder instance.
          - output_parser: The output parser instance.
          - transform: The processors to process input attachment
    """
