from _typeshed import Incomplete
from abc import ABC
from gllm_multimodal.media_toolkit.processor.base_processor import BaseProcessor as BaseProcessor
from gllm_multimodal.modality_converter.video_to_text.video_to_text import BaseVideoToText as BaseVideoToText
from gllm_multimodal.schema.caption import Caption as Caption
from gllm_multimodal.schema.text_result import TextResult as TextResult
from gllm_multimodal.schema.video_caption_result import Segment as Segment, VideoCaptionMetadata as VideoCaptionMetadata
from gllm_multimodal.utils.image_utils import get_image_binary as get_image_binary
from typing import Any

class BaseVideoToCaption(BaseVideoToText, ABC):
    """Abstract base class for video captioning operations in Gen AI applications.

    This class extends BaseVideoToText to provide specialized functionality for generating
    captions from videos. It supports video segmentation, keyframe extraction, transcript
    integration, and can incorporate additional context like video title, description,
    domain knowledge, and metadata.

    Attributes:
        denormalize_time (bool): Whether to denormalize time to second. Defaults to True.
    """
    denormalize_time: Incomplete
    def __init__(self, transform: list[BaseProcessor] | None = None, **kwargs: Any) -> None:
        """Initialize the video captioning converter.

        Args:
            transform (list[BaseProcessor] | None): Processor(s) to transform the video attachment.
            **kwargs (Any): Additional keyword arguments.
                denormalize_time (bool): Whether to denormalize time to second. Defaults to True.
        """
