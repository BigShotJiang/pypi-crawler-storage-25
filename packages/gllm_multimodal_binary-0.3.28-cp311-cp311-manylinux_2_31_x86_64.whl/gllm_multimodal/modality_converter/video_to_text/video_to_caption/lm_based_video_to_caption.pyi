from _typeshed import Incomplete
from gllm_inference.request_processor.lm_request_processor import LMRequestProcessor
from gllm_inference.request_processor.uses_lm_mixin import UsesLM
from gllm_multimodal.constants import ImageToTextConstants as ImageToTextConstants
from gllm_multimodal.media_toolkit.processor.base_processor import BaseProcessor as BaseProcessor
from gllm_multimodal.modality_converter.video_to_text.video_to_caption.preset_video_to_caption import get_preset_video_to_caption as get_preset_video_to_caption
from gllm_multimodal.modality_converter.video_to_text.video_to_caption.video_to_caption import BaseVideoToCaption as BaseVideoToCaption
from gllm_multimodal.schema.caption import Caption as Caption
from gllm_multimodal.schema.video_caption_result import Segment as Segment, VideoCaptionMetadata as VideoCaptionMetadata
from typing import Any

class LMBasedVideoToCaption(BaseVideoToCaption, UsesLM):
    """Video captioning implementation using Language Models.

    This class implements the VideoToCaption interface using LMs for generating
    natural language captions.
    """
    lm_request_processor: Incomplete
    max_retries: Incomplete
    def __init__(self, lm_request_processor: LMRequestProcessor, transform: list[BaseProcessor] | None = None, max_retries: int = 2, **kwargs: Any) -> None:
        """Initialize the LM based video captioning component.

        Args:
            lm_request_processor (LMRequestProcessor): Language model request processor instance that
                supports multimodal inputs.
            transform (list[BaseProcessor] | None): Processor(s) to transform the video attachment.
            max_retries (int, optional): Maximum number of retries for LM invocations. Defaults to 2.
            **kwargs (Any): Additional keyword arguments to pass to the parent constructor.
        """
    @classmethod
    def from_preset(cls, preset_name: str | None = 'default', lm_invoker_kwargs: dict | None = None, prompt_builder_kwargs: dict | None = None, **kwargs: Any) -> LMBasedVideoToCaption:
        """Initialize the LM based video captioning component using preset model configurations.

        Args:
            preset_name (str): Name of the preset to use.
            lm_invoker_kwargs (dict | None): Keyword arguments to pass to the LM invoker.
            prompt_builder_kwargs (dict | None): Keyword arguments to pass to the prompt builder.
            **kwargs (Any): Additional keyword arguments to pass to from_lm_components().

        Returns:
            LMBasedVideoToCaption: Initialized video captioning component using preset model.
        """
