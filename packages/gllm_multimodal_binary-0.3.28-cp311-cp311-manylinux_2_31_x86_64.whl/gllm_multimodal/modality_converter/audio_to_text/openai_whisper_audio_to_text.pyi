from _typeshed import Incomplete
from gllm_multimodal.constants import AudioFormatConstants as AudioFormatConstants, WhisperResponseKeys as WhisperResponseKeys
from gllm_multimodal.modality_converter.audio_to_text.audio_to_text import BaseAudioToText as BaseAudioToText
from gllm_multimodal.schema.audio_transcript import AudioTranscript as AudioTranscript
from gllm_multimodal.utils.audio_to_text_utils import convert_audio_to_mono_flac as convert_audio_to_mono_flac, detect_audio_format as detect_audio_format, get_audio_from_base64 as get_audio_from_base64, get_audio_from_downloadable_url as get_audio_from_downloadable_url, get_audio_from_file_path as get_audio_from_file_path, get_audio_from_youtube_url as get_audio_from_youtube_url
from openai.types.audio import TranscriptionVerbose as TranscriptionVerbose

MAX_AUDIO_SIZE: Incomplete
AUDIO_FORMAT_TO_MIME_TYPE: Incomplete

class OpenAIWhisperAudioToText(BaseAudioToText):
    """An audio to text converter using OpenAI Whisper.

    The OpenAIWhisperAudioToText class is responsible for converting audio to text using OpenAI Whisper.
    It supports various audio sources such as file paths, base64 encoded strings, downloadable audio URLs,
    and YouTube URLs.

    When ``base_url`` is omitted, the class operates using the official OpenAI API.
    When ``base_url`` points to a custom OpenAI-compatible endpoint, the API response is checked
    for an ``error`` field and a fallback ``AudioTranscript`` is produced when no segments or words are returned.

    In both cases:

    * Audio is converted to mono FLAC before upload (unless the format appears in
      ``skip_conversion_for_formats``).
    * Files exceeding 25 MB are progressively downsampled.

    Both modes use the same synchronous :class:`openai.OpenAI` client.

    Attributes:
        client (OpenAI): The OpenAI client instance used for API requests.
        model (str): The identifier of the OpenAI Whisper model to use for transcription.
        language (str | None): The language of the input audio content.
        prompt (str | None): The text prompt to guide the model's style or continue a previous audio segment.
        temperature (float): The sampling temperature to control output randomness.
        timestamp_granularity (str): The timestamp detail levels to include in the output.
        proxy (str | None): The proxy URL to use for the YouTube request.
        skip_conversion_for_formats (list[str]): List of audio formats that should skip mono FLAC conversion.
        merge_consecutive_duplicates (bool): Whether to merge consecutive duplicated transcripts.
    """
    client: Incomplete
    model: Incomplete
    language: Incomplete
    prompt: Incomplete
    temperature: Incomplete
    timestamp_granularity: Incomplete
    proxy: Incomplete
    skip_conversion_for_formats: Incomplete
    merge_consecutive_duplicates: Incomplete
    logger: Incomplete
    def __init__(self, api_key: str, model: str = 'whisper-1', language: str | None = None, prompt: str | None = None, temperature: float = 0, timestamp_granularity: str = 'segment', proxy: str | None = None, skip_conversion_for_formats: list[str] | None = None, base_url: str | None = None, merge_consecutive_duplicates: bool = False) -> None:
        '''Initialize the OpenAIWhisperAudioToText instance.

        Args:
            api_key (str): The API key for authentication with OpenAI (or the custom endpoint).
            model (str, optional): The model identifier to use for transcription. Defaults to "whisper-1".
            language (str | None, optional): The language of the input audio content. Defaults to None.
            prompt (str | None, optional): The text prompt to guide the model\'s style or continue a previous audio
                segment. The prompt should match the audio language. Defaults to None.
            temperature (float, optional): The sampling temperature to control output randomness. Defaults to 0.
            timestamp_granularity (str, optional): The timestamp detail levels to include in the output.
                The granularity can be "segment" or "word". When set to "segment", OpenAI will return
                transcripts divided into segments of speech. When set to "word", it will include word-level
                timestamps. Defaults to "segment".
            proxy (str | None, optional): The proxy URL to use for the YouTube request. Defaults to None.
            skip_conversion_for_formats (list[str] | None, optional): List of audio formats (e.g., [\'mp3\', \'wav\'])
                that should skip the mono FLAC conversion process. Formats are case-insensitive and can be
                specified with or without a leading dot. If None or empty, all audio will be converted to
                mono FLAC. Defaults to None.
            base_url (str | None, optional): Base URL of a custom OpenAI-compatible Whisper endpoint
                (e.g. ``"https://my-whisper-server/v1"``). When provided, the class checks for API-level errors,
                and produces a fallback transcript when the response contains no segments or words.
                Defaults to ``None`` (standard OpenAI API).
            merge_consecutive_duplicates (bool, optional): Whether to merge consecutive transcripts that have
                the exact same text, combining their time ranges. Defaults to False.
        '''
    async def convert(self, audio_source: str | bytes) -> list[AudioTranscript]:
        """Convert audio to text using OpenAI Whisper.

        This method process the given audio source and return a list of AudioTranscript.
        The audio source can be a file path, a base64 encoded string, a URL, or directly as bytes.

        Args:
            audio_source (str | bytes): The source of the audio to convert. Can be:
                - A file path to an audio file.
                - A base64 encoded string of the audio.
                - A downloadable audio URL (e.g. Google Drive, OneDrive).
                - A YouTube URL.
                - Bytes containing the audio data.

        Returns:
            list[AudioTranscript]: A list of AudioTranscript.

        Raises:
            ValueError: If the provided audio source is not supported or cannot be processed.
        """
