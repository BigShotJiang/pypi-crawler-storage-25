from _typeshed import Incomplete
from gllm_multimodal.constants import AudioFormatConstants as AudioFormatConstants
from gllm_multimodal.modality_converter.audio_to_text.audio_to_text import BaseAudioToText as BaseAudioToText
from gllm_multimodal.schema.audio_transcript import AudioTranscript as AudioTranscript
from gllm_multimodal.utils.audio_to_text_utils import detect_audio_format as detect_audio_format, resolve_audio_source as resolve_audio_source

AUDIO_FORMAT_TO_MIME_TYPE: Incomplete
DEFAULT_MIME_TYPE: Incomplete
DEFAULT_REQUEST_TIMEOUT: Incomplete
TAG_LANGUAGE: str
TAG_TEXT: str
TAG_TIMESTAMPS: str
WORD_TIMESTAMP_PATTERN: Incomplete
DEFAULT_SEGMENT_GAP_THRESHOLD: float

class QwenAsrAudioToText(BaseAudioToText):
    '''An audio to text converter using Qwen3-ASR served via a vLLM-compatible endpoint.

    This class sends audio to a vLLM OpenAI-compatible chat completions endpoint as a
    base64-encoded ``audio_url`` data URI. The model returns a structured response containing
    a ``<|language|>`` tag, a ``<|text|>`` tag with the full transcription, and a
    ``<|timestamps|>`` tag with word-level timing information.

    The ``timestamp_granularity`` parameter controls the output format:

    1. ``"word"`` — each word is returned as a separate ``AudioTranscript`` with its own
       start and end times.
    2. ``"segment"`` — consecutive words are merged into segments based on the time gap
       between them. A new segment is started whenever the gap between one word\'s end time
       and the next word\'s start time exceeds ``segment_gap_threshold`` seconds.

    Attributes:
        client (AsyncOpenAI): The OpenAI-compatible async client used for API requests.
        model (str): The model identifier (e.g. ``"Qwen/Qwen3-ASR-1.7B"``).
        prompt (str | None): Optional text prompt to inject domain knowledge or context.
        align_text (str | None): The ground truth transcription to use for forced alignment.
        temperature (float): The sampling temperature for generation.
        max_tokens (int): The maximum number of tokens to generate.
        timestamp_granularity (str): The timestamp detail level — ``"word"`` or ``"segment"``.
        segment_gap_threshold (float): The maximum gap in seconds between consecutive words
            before starting a new segment (only used when ``timestamp_granularity`` is
            ``"segment"``).
        proxy (str | None): The proxy URL to use for YouTube requests.
    '''
    client: Incomplete
    model: Incomplete
    prompt: Incomplete
    align_text: Incomplete
    temperature: Incomplete
    max_tokens: Incomplete
    timestamp_granularity: Incomplete
    segment_gap_threshold: Incomplete
    proxy: Incomplete
    logger: Incomplete
    def __init__(self, api_key: str, model: str = 'Qwen/Qwen3-ASR-1.7B', base_url: str = 'http://localhost:8000/v1', prompt: str | None = None, align_text: str | None = None, temperature: float = 0.01, max_tokens: int = 1024, timestamp_granularity: str = 'segment', segment_gap_threshold: float = ..., proxy: str | None = None, timeout: float = ...) -> None:
        '''Initialize the QwenAsrAudioToText instance.

        Args:
            api_key (str): The API key for authentication with the endpoint.
            model (str, optional): The model identifier. Defaults to "Qwen/Qwen3-ASR-1.7B".
            base_url (str, optional): The base URL of the vLLM-compatible endpoint.
                Defaults to "http://localhost:8000/v1".
            prompt (str | None, optional): Optional text prompt to inject domain knowledge or provide context.
                Defaults to None.
            align_text (str | None, optional): The ground truth transcription to use for forced alignment.
                If provided, the server will bypass generation and instead return accurate timestamps for the text.
                Defaults to None.
            temperature (float, optional): The sampling temperature. Defaults to 0.01.
            max_tokens (int, optional): The maximum number of tokens to generate. Defaults to 1024.
            timestamp_granularity (str, optional): The timestamp detail level. Use ``"word"`` for
                word-level transcripts or ``"segment"`` to merge words into segments split by
                time gaps. Must be one of ``"word"`` or ``"segment"``.
                Defaults to "segment".
            segment_gap_threshold (float, optional): The maximum gap in seconds between consecutive
                words before a new segment is started. Only applies when ``timestamp_granularity``
                is ``"segment"``. Defaults to 2.0.
            proxy (str | None, optional): The proxy URL for YouTube requests. Defaults to None.
            timeout (float, optional): The timeout in seconds for API requests.
                Defaults to 120.0.

        Raises:
            ValueError: If ``timestamp_granularity`` is not ``"word"`` or ``"segment"``.
        '''
    async def convert(self, audio_source: str | bytes) -> list[AudioTranscript]:
        """Convert audio to text using Qwen3-ASR.

        The audio source can be a file path, a base64 encoded string, a downloadable URL,
        a YouTube URL, or raw bytes. The audio is base64-encoded and sent to the model via
        the chat completions API as an ``audio_url`` data URI.

        Source resolution (file reads and URL downloads) runs synchronously and may briefly
        block the event loop. The subsequent model API call is non-blocking, made via the
        async :class:`~openai.AsyncOpenAI` client which natively supports ``await``.

        Args:
            audio_source (str | bytes): The source of the audio to convert.

        Returns:
            list[AudioTranscript]: A list of AudioTranscript objects. The granularity depends
                on ``timestamp_granularity``.

        Raises:
            ValueError: If the provided audio source is not supported or cannot be processed.
        """
