from gllm_multimodal.schema.audio_transcript import AudioTranscript as AudioTranscript

__all__ = ['AudioTranscript']
