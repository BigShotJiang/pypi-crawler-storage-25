from gllm_multimodal.schema.video_caption_result import Keyframe as Keyframe, Segment as Segment, VideoCaptionMetadata as VideoCaptionMetadata

__all__ = ['Keyframe', 'Segment', 'VideoCaptionMetadata']
