from gllm_multimodal.schema.text_result import TextResult as TextResult

__all__ = ['TextResult']
