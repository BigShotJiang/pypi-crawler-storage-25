from gllm_multimodal.schema.caption_result import CaptionResult as CaptionResult

__all__ = ['CaptionResult']
