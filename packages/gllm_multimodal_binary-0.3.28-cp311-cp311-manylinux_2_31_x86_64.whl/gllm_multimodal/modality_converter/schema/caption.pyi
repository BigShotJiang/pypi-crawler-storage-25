from gllm_multimodal.schema.caption import Caption as Caption

__all__ = ['Caption']
