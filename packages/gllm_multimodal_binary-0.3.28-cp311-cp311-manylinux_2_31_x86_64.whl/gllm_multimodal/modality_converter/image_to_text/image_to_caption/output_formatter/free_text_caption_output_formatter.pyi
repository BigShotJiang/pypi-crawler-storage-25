from gllm_multimodal.constants import CaptionConstants as CaptionConstants, ConverterResultTag as ConverterResultTag
from gllm_multimodal.modality_converter.image_to_text.image_to_caption.output_formatter.base_caption_output_formatter import BaseCaptionOutputFormatter as BaseCaptionOutputFormatter
from gllm_multimodal.schema.caption_result import CaptionResult as CaptionResult
from gllm_multimodal.schema.text_result import TextResult as TextResult
from gllm_multimodal.utils.image_utils import combine_strings as combine_strings, get_unique_non_empty_strings as get_unique_non_empty_strings
from typing import Any

class FreeTextCaptionOutputFormatter(BaseCaptionOutputFormatter):
    '''Formatter for plain text LLM output.

    This formatter expects a JSON string with this structure:
    {
        "<key>": [
            "<text_1>",
            "<text_2>",
            "<text_3>",
            ...
        ]
    }
    then converts the list of texts into a single string.
    '''
    def format(self, result: str, **kwargs: Any) -> TextResult:
        """Format the raw result into a text-based TextResult.

        Args:
            result (str): The raw JSON string containing LLM results.
            **kwargs (Any): Additional keyword arguments including:
                1. caption_key (str, optional): Key in the JSON response containing LLM results.
                    Defaults to 'result'.

        Returns:
            TextResult: A structured result containing the combined LLM results.
        """
