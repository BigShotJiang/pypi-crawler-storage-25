from abc import ABC, abstractmethod
from gllm_multimodal.schema.text_result import TextResult as TextResult
from typing import Any

class BaseCaptionOutputFormatter(ABC):
    """Abstract base class for LLM output formatters."""
    def __init__(self) -> None:
        """Initialize the LLM output formatter with logging capabilities."""
    @abstractmethod
    def format(self, result: str, **kwargs: Any) -> TextResult:
        """Format the raw LLM result into a structured TextResult.

        Args:
            result (str): The raw LLM string from the model.
            **kwargs (Any): Additional formatting options.

        Returns:
            TextResult: The formatted result containing the LLM result and metadata.
        """
