from gllm_multimodal.constants import ConverterResultTag as ConverterResultTag
from gllm_multimodal.modality_converter.image_to_text.image_to_caption.output_formatter.base_caption_output_formatter import BaseCaptionOutputFormatter as BaseCaptionOutputFormatter
from gllm_multimodal.schema.caption_result import CaptionResult as CaptionResult
from gllm_multimodal.schema.text_result import TextResult as TextResult
from gllm_multimodal.utils.image_utils import convert_into_structured_caption as convert_into_structured_caption
from typing import Any

class StructuredCaptionOutputFormatter(BaseCaptionOutputFormatter):
    """Formatter for structured caption output.

    This formatter converts the raw model output into a structured dictionary
    format within the metadata.
    """
    def format(self, result: str, **kwargs: Any) -> TextResult:
        """Format the raw result into a structured TextResult.

        Args:
            result (str): The raw string output from the model.
            **kwargs (Any): Additional keyword arguments.

        Returns:
            TextResult: A structured result containing the raw text and structured metadata.
        """
