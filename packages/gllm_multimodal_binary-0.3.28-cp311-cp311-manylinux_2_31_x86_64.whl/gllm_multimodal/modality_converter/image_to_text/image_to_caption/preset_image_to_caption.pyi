from _typeshed import Incomplete
from gllm_inference.lm_invoker.lm_invoker import BaseLMInvoker as BaseLMInvoker
from gllm_inference.prompt_builder import PromptBuilder
from gllm_multimodal.modality_converter.image_to_text.image_to_caption.output_formatter import BaseCaptionOutputFormatter as BaseCaptionOutputFormatter, FreeTextCaptionOutputFormatter as FreeTextCaptionOutputFormatter, StructuredCaptionOutputFormatter as StructuredCaptionOutputFormatter

DEFAULT_SYSTEM_PROMPT: str
DEFAULT_USER_PROMPT: str
STRUCTURED_CAPTION_SYSTEM_PROMPT: str
DJARUM_ENG_SVLM_SYSTEM_PROMPT: str
DJARUM_ENG_SVLM_USER_PROMPT: str
PRESET_CONFIG: Incomplete

def create_preset_prompt_builder(preset_name: str | None) -> PromptBuilder:
    """Create a prompt builder for the given preset name.

    Args:
        preset_name (str): The name of the preset to create.

    Returns:
        PromptBuilder: A prompt builder instance configured with the given
            preset.
    """
def get_preset_image_to_caption(preset_name: str | None) -> tuple[BaseLMInvoker, PromptBuilder, BaseCaptionOutputFormatter]:
    """Get the preset configuration for generating image captions.

    Args:
        preset_name (str): The name of the preset to get.

    Returns:
        tuple[BaseLMInvoker, PromptBuilder, BaseCaptionOutputFormatter]:
            A tuple containing the preset configuration for image captioning.
    """
