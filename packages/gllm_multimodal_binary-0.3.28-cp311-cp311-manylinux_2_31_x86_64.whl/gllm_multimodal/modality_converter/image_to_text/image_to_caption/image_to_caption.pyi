from _typeshed import Incomplete
from abc import ABC
from gllm_multimodal.modality_converter.image_to_text.image_to_caption.output_formatter import BaseCaptionOutputFormatter as BaseCaptionOutputFormatter, FreeTextCaptionOutputFormatter as FreeTextCaptionOutputFormatter
from gllm_multimodal.modality_converter.image_to_text.image_to_text import BaseImageToText as BaseImageToText
from gllm_multimodal.schema.caption import Caption as Caption
from gllm_multimodal.schema.text_result import TextResult as TextResult
from gllm_multimodal.utils.image_metadata_utils import get_image_metadata as get_image_metadata

DEFAULT_FORMATTER: Incomplete

class BaseImageToCaption(BaseImageToText, ABC):
    """Abstract base class for image captioning operations in Gen AI applications.

    This class extends ImageToText to provide specialized functionality for generating
    captions from images. It supports multiple captioning styles and can incorporate additional context
    like oneliner of image, description of image, domain knowledge and metadata.
    """
    formatter: Incomplete
    def __init__(self, formatter: BaseCaptionOutputFormatter = ...) -> None:
        """Initialize the image to caption converter.

        Args:
            formatter (BaseCaptionOutputFormatter): The formatter to use for formatting the output.
        """
