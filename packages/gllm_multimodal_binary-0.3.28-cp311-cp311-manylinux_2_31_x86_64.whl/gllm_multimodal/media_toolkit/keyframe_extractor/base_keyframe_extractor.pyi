from abc import ABC
from gllm_inference.schema import Attachment
from gllm_multimodal.media_toolkit.processor.base_processor import BaseProcessor as BaseProcessor
from gllm_multimodal.schema.video_caption_metadata import Keyframe as Keyframe

class BaseKeyframeExtractor(BaseProcessor, ABC):
    """Abstract base class for keyframe extraction from video attachments.

    Keyframe extractors are responsible for identifying and extracting
    representative frames (keyframes) from a given video attachment.
    The resulting attachments should contain `Keyframe` metadata.
    """
    async def process(self, attachment: Attachment | list[Attachment]) -> Attachment | list[Attachment]:
        """Process the attachment and return the result with Keyframe metadata.

        This is the public entry point for processing. It delegates to `_process`
        and then validates the output.

        Args:
            attachment (Attachment | list[Attachment]): The video attachment(s) to process.

        Returns:
            Attachment | list[Attachment]: The extracted keyframe attachment(s).
        """
    def output_validator(self, attachment: Attachment | list[Attachment]) -> Attachment | list[Attachment]:
        """Validate that each output attachment has Keyframe-compatible metadata dict.

        Args:
            attachment (Attachment | list[Attachment]): The attachment(s) to validate.

        Returns:
            Attachment | list[Attachment]: The validated attachment(s).

        Raises:
            TypeError: If any attachment metadata is not a dictionary.
            ValueError: If any metadata dictionary cannot be parsed as `Keyframe`.
        """
