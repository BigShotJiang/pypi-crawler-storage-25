from gllm_multimodal.media_toolkit.keyframe_extractor.base_keyframe_extractor import BaseKeyframeExtractor as BaseKeyframeExtractor

__all__ = ['BaseKeyframeExtractor']
