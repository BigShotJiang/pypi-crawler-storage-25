import aiofiles as aiofiles
import tempfile as tempfile
import uuid as uuid
from gi.repository import Gst as Gst
from gllm_multimodal.media_toolkit.processor.gstreamer_based_processor.base_gstreamer_processor import GST_AVAILABLE as GST_AVAILABLE
from gllm_multimodal.media_toolkit.processor.gstreamer_based_processor.frame_sampling_processor import GstFrameSamplingConfig as _GstFrameSamplingConfig, GstFrameSamplingProcessor as _GstFrameSamplingProcessor
from gllm_multimodal.utils.gst_utils import configure_gst_plugin_path as configure_gst_plugin_path

__all__ = ['GST_AVAILABLE', 'GstFrameSamplingConfig', 'GstFrameSamplingProcessor', 'Gst', 'configure_gst_plugin_path', 'aiofiles', 'tempfile', 'uuid']

class GstFrameSamplingConfig(_GstFrameSamplingConfig):
    """Deprecated re-export of GstFrameSamplingConfig. Use the canonical path."""
class GstFrameSamplingProcessor(_GstFrameSamplingProcessor):
    """Deprecated re-export of GstFrameSamplingProcessor. Use the canonical path."""
