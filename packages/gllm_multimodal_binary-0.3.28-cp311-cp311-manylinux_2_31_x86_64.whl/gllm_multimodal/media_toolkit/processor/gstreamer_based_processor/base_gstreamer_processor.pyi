from _typeshed import Incomplete
from gllm_core.utils.concurrency import asyncify as asyncify
from gllm_inference.schema import Attachment
from gllm_multimodal.media_toolkit.processor.base_processor import BaseProcessor as BaseProcessor
from gllm_multimodal.utils.gst_utils import configure_gst_plugin_path as configure_gst_plugin_path
from pydantic import BaseModel
from typing import Any

GST_AVAILABLE: bool
DEFAULT_TIMEOUT_SECONDS: int

class GstBaseConfig(BaseModel):
    '''Minimal shared configuration for all GStreamer-based processors.

    Attributes:
        timeout (int): Maximum seconds a GStreamer pipeline may run before
            being forcibly terminated. Defaults to 300 seconds.
        audio_passthrough (bool): When ``True`` (the default), encoded audio
            streams are passed directly to the muxer without being decoded and
            re-encoded. Set to ``False`` to force re-encoding via the best
            available audio encoder.
        video_encoder (str | None): Pin a specific GStreamer video encoder
            element name (e.g. ``"x264enc"``). When set, the candidate-list
            scan is skipped entirely and this element is used directly.
            The element must exist in the GStreamer registry. Defaults to
            ``None`` (auto-select from :attr:`_VIDEO_ENCODER_CANDIDATES`).
        audio_encoder (str | None): Pin a specific GStreamer audio encoder
            element name (e.g. ``"voaacenc"``). When set, the candidate-list
            scan is skipped entirely and this element is used directly.
            The element must exist in the GStreamer registry. Defaults to
            ``None`` (auto-select from :attr:`_AUDIO_ENCODER_CANDIDATES`).
    '''
    timeout: int
    audio_passthrough: bool
    video_encoder: str | None
    audio_encoder: str | None

class BaseGstreamerProcessor(BaseProcessor):
    """Abstract base class for GStreamer-powered processors.

    Subclasses must implement only :meth:`_execute_pipeline`.  All common
    concerns — availability checks, Conda environment configuration, GStreamer
    initialisation, encoder/element selection, the standard EOS/error bus loop,
    and temporary-file cleanup — are handled here.

    Typical subclass skeleton::

        class MyGstProcessor(BaseGstreamerProcessor):
            def __init__(self, my_param, config=None):
                super().__init__(config=config)
                self.my_param = my_param

            async def process(self, attachment):
                if isinstance(attachment, list):
                    return [await self._process_single(a) for a in attachment]
                return await self._process_single(attachment)

            async def _execute_pipeline(self, input_path, output_path):
                # build & run YOUR GStreamer pipeline here
                ...

    Attributes:
        logger: Logger bound to the concrete subclass name.
        config (GstBaseConfig): Runtime configuration.
        video_encoder (str): Name of the selected GStreamer video encoder element.
        audio_encoder (str): Name of the selected GStreamer audio encoder element.
    """
    logger: Incomplete
    config: GstBaseConfig
    video_encoder: str
    audio_encoder: str
    def __init__(self, config: dict[str, Any] | GstBaseConfig | None = None) -> None:
        """Verify GStreamer availability, configure the environment, and select encoders.

        Args:
            config (dict[str, Any] | GstBaseConfig | None): Optional configuration.
                A plain ``dict`` is coerced into a :class:`GstBaseConfig`.
                ``None`` uses all :class:`GstBaseConfig` defaults.

        Raises:
            RuntimeError: If GStreamer is not installed or cannot be initialised.
            RuntimeError: If no suitable video encoder is found in the registry.
        """
    async def process(self, attachment: Attachment | list[Attachment]) -> Attachment | list[Attachment]:
        """Process one or more video attachments.

        Args:
            attachment (Attachment | list[Attachment]): Input video attachment(s).

        Returns:
            Attachment | list[Attachment]: Processed attachment(s). If an attachment
                is skipped or fails, the original is returned unchanged.
        """
