from _typeshed import Incomplete
from gllm_multimodal.media_toolkit.processor.gstreamer_based_processor.base_gstreamer_processor import BaseGstreamerProcessor as BaseGstreamerProcessor, GST_AVAILABLE as GST_AVAILABLE, GstBaseConfig as GstBaseConfig
from pydantic import BaseModel as BaseModel
from typing import Any

class GstFrameSamplingConfig(GstBaseConfig):
    """Configuration for GstFrameSamplingProcessor.

    Attributes:
        min_size_mb (int): Minimum video size in MB to process.
            Videos smaller than this are returned unchanged. ``0`` disables
            the check. Defaults to ``0``.
        timeout (int): Inherited from :class:`GstBaseConfig`. Defaults to 300 s.
        audio_passthrough (bool): Inherited from :class:`GstBaseConfig`. Defaults to ``True``.
    """
    min_size_mb: int

class GstFrameSamplingProcessor(BaseGstreamerProcessor):
    """Resamples a video attachment to a target frame-rate using GStreamer.

    The processor is format-agnostic: it handles MP4, MKV, MOV, and similar
    containers and preserves any audio track (passthrough by default).

    Attributes:
        target_fps (int): The target frames-per-second for the output video.
        config (GstFrameSamplingConfig): Runtime configuration.

    Raises:
        RuntimeError: If GStreamer is not available or no suitable encoder is found.
    """
    target_fps: Incomplete
    def __init__(self, target_fps: int = 1, config: dict[str, Any] | GstFrameSamplingConfig | None = None) -> None:
        """Initialise and select encoders.

        Args:
            target_fps (int): Target FPS for the output video. Defaults to 1.
            config (dict[str, Any] | GstFrameSamplingConfig | None): Optional
                configuration. A plain ``dict`` is coerced into
                :class:`GstFrameSamplingConfig`. ``None`` uses defaults.
        """
