from gllm_multimodal.media_toolkit.processor.gstreamer_based_processor.base_gstreamer_processor import BaseGstreamerProcessor as BaseGstreamerProcessor, GST_AVAILABLE as GST_AVAILABLE, GstBaseConfig as GstBaseConfig
from gllm_multimodal.utils import gst_utils as gst_utils
from typing import Any

class GstAudioExtractionConfig(GstBaseConfig):
    """Configuration for GstAudioExtractionProcessor.

    Attributes:
        sample_rate (int | None): Force output sample rate in Hz (e.g. ``16000``).
            ``None`` preserves the source rate. Defaults to ``None``.
        channels (int | None): Force output channel count (e.g. ``1`` for mono).
            ``None`` preserves the source count. Defaults to ``None``.
    """
    sample_rate: int | None
    channels: int | None

class GstAudioExtractionProcessor(BaseGstreamerProcessor):
    '''Extracts the audio track from a video Attachment using GStreamer.

    The processor demuxes the input video, re-encodes (or passes through) the
    audio into the best available format, and returns the result as an
    ``Attachment`` whose ``mime_type`` reflects the audio container.

    If the video has no audio track the original ``Attachment`` is returned
    unchanged, so callers do not need to handle ``None``.

    Attributes:
        audio_encoder (str): Selected audio encoder element name.
        muxer (str): Selected muxer element name.
        output_extension (str): File extension of the output audio file.
        output_mime_type (str): MIME type of the output audio file.
        config (GstAudioExtractionConfig): Runtime configuration.

    Raises:
        RuntimeError: If GStreamer is unavailable or no suitable audio encoder
            is found.

    Example::

        processor = GstAudioExtractionProcessor()
        audio_attachment = await processor.process(video_attachment)
        # audio_attachment.mime_type == "audio/x-wav"
        # audio_attachment.filename  == "audio_my_video.wav"
    '''
    audio_encoder: str
    muxer: str
    output_extension: str
    output_mime_type: str
    def __init__(self, config: dict[str, Any] | GstAudioExtractionConfig | None = None) -> None:
        """Initialise GStreamer and select the best available audio encoder.

        Args:
            config (dict[str, Any] | GstAudioExtractionConfig | None): Optional
                configuration. A plain ``dict`` is coerced into
                :class:`GstAudioExtractionConfig`. ``None`` uses defaults.

        Raises:
            RuntimeError: If GStreamer is unavailable or no audio encoder is found.
        """
