from _typeshed import Incomplete
from gllm_multimodal.media_toolkit.processor.gstreamer_based_processor.base_gstreamer_processor import BaseGstreamerProcessor as BaseGstreamerProcessor, DEFAULT_TIMEOUT_SECONDS as DEFAULT_TIMEOUT_SECONDS, GST_AVAILABLE as GST_AVAILABLE, GstBaseConfig as GstBaseConfig
from typing import Any

class GstVideoClipConfig(GstBaseConfig):
    """Configuration for GstVideoClipProcessor.

    Inherits :attr:`timeout` and :attr:`audio_passthrough` from
    :class:`GstBaseConfig` unchanged.
    """

class GstVideoClipProcessor(BaseGstreamerProcessor):
    """Clips a video attachment to a specific ``[start_time, end_time]`` window.

    Uses GStreamer's ``GST_SEEK_FLAG_ACCURATE`` to extract a time-bounded
    sub-clip from a video, re-encoding it into a clean, self-contained file
    that downstream processors (e.g. keyframe extractors, captioners) can
    consume in isolation.

    Attributes:
        start_time (float): Clip start in seconds (inclusive).
        end_time (float): Clip end in seconds (exclusive).
        config (GstVideoClipConfig): Runtime configuration.

    Raises:
        RuntimeError: If GStreamer is unavailable, no encoder is found, or
            ``end_time <= start_time``.
    """
    start_time: Incomplete
    end_time: Incomplete
    def __init__(self, start_time: float, end_time: float, config: dict[str, Any] | GstVideoClipConfig | None = None) -> None:
        """Initialise the clip processor with the desired time window.

        Args:
            start_time (float): Clip start position in seconds.
            end_time (float): Clip end position in seconds.
            config (dict[str, Any] | GstVideoClipConfig | None): Optional
                configuration. ``None`` uses :class:`GstVideoClipConfig` defaults.

        Raises:
            ValueError: If ``end_time <= start_time``.
            RuntimeError: If GStreamer is unavailable or no encoder is found.
        """
    def set_window(self, start_time: float, end_time: float) -> None:
        """Update the clip window without re-initialising the processor.

        The expensive parts of initialisation (GStreamer setup, encoder
        selection) are performed only once in :meth:`__init__`.  Call this
        method between :meth:`process` calls to reuse the same instance for
        different time segments.

        Args:
            start_time (float): New clip start position in seconds.
            end_time (float): New clip end position in seconds.

        Raises:
            ValueError: If ``end_time <= start_time``.

        Example::

            clipper = GstVideoClipProcessor(start_time=0.0, end_time=10.0)
            clip_a = await clipper.process(video)

            clipper.set_window(20.0, 30.0)
            clip_b = await clipper.process(video)
        """
