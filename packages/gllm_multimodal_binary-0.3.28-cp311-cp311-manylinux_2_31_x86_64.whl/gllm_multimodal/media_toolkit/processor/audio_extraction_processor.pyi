import aiofiles as aiofiles
import tempfile as tempfile
import uuid as uuid
from gi.repository import Gst as Gst
from gllm_multimodal.media_toolkit.processor.gstreamer_based_processor.audio_extraction_processor import GstAudioExtractionConfig as _GstAudioExtractionConfig, GstAudioExtractionProcessor as _GstAudioExtractionProcessor
from gllm_multimodal.media_toolkit.processor.gstreamer_based_processor.base_gstreamer_processor import GST_AVAILABLE as GST_AVAILABLE
from gllm_multimodal.utils.gst_utils import configure_gst_plugin_path as configure_gst_plugin_path

__all__ = ['GST_AVAILABLE', 'GstAudioExtractionConfig', 'GstAudioExtractionProcessor', 'Gst', 'configure_gst_plugin_path', 'aiofiles', 'tempfile', 'uuid']

class GstAudioExtractionConfig(_GstAudioExtractionConfig):
    """Deprecated re-export of GstAudioExtractionConfig. Use the canonical path."""
class GstAudioExtractionProcessor(_GstAudioExtractionProcessor):
    """Deprecated re-export of GstAudioExtractionProcessor. Use the canonical path."""
