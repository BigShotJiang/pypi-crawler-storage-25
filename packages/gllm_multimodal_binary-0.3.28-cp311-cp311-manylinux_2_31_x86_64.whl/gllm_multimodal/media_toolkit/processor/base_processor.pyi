from abc import ABC, abstractmethod
from gllm_inference.schema import Attachment

class BaseProcessor(ABC):
    """Abstract base class for processing attachments."""
    @abstractmethod
    async def process(self, attachment: Attachment | list[Attachment]) -> Attachment | list[Attachment]:
        """Process the attachment and return the result.

        Args:
            attachment (Attachment | list[Attachment]): The attachment(s) to process.

        Returns:
            Attachment | list[Attachment]: The result of the processing.
        """
