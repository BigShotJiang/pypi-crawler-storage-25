from _typeshed import Incomplete
from gllm_multimodal.media_toolkit.processor.gstreamer_based_processor.video_clip_processor import GstVideoClipProcessor as GstVideoClipProcessor
from gllm_multimodal.media_toolkit.segmenter.base_segmenter import BaseSegmenter as BaseSegmenter
from gllm_multimodal.schema.video_caption_metadata import Segment as Segment

class FixedDurationSegmenter(BaseSegmenter):
    """Segment attachments using explicit per-segment durations.

    Each output segment keeps the original attachment binary, while segment timing
    is represented in metadata as cumulative windows based on ``segment_durations``.
    """
    segment_durations: Incomplete
    start_time: Incomplete
    def __init__(self, segment_durations: list[float], start_time: float = 0.0) -> None:
        """Initialize the segmenter with manually provided segment durations.

        Args:
            segment_durations (list[float]): Ordered segment durations in seconds.
            start_time (float, optional): Base start time for the first segment. Defaults to 0.0.

        Raises:
            ValueError: If no segment duration is provided, or any duration is non-positive.
        """
