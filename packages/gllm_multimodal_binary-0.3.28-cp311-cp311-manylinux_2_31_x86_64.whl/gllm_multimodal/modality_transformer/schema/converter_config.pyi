from gllm_multimodal.constants import Modality as Modality, ModalityConverterApproach as ModalityConverterApproach, ModalityConverterBuildStrategy as ModalityConverterBuildStrategy, ModalityConverterTask as ModalityConverterTask
from pydantic import BaseModel
from typing import Any

class ConverterConfig(BaseModel):
    """Configuration for building a single modality converter instance.

    Attributes:
        source_modality (Modality): Source modality for conversion.
            Defaults to Modality.IMAGE.
        target_modality (Modality): Target modality for conversion.
            Defaults to Modality.TEXT.
        task_type (ModalityConverterTask): Converter task type.
            Defaults to ModalityConverterTask.AUTO.
        approach_type (ModalityConverterApproach | None): Converter approach type.
            Defaults to None.
        preset (str | None): Preset name for the converter.
            Required for ModalityConverterBuildStrategy.PRESET.
            Defaults to None.
        strategy (ModalityConverterBuildStrategy | None): Build strategy for the converter.
            When None, the strategy is auto-determined from the provided fields
            (preset → PRESET, lmrp_config → LMRP, otherwise → KWARGS).
            Defaults to None.
        lmrp_config (dict[str, Any] | None): Configuration for custom LMRP.
            Required for ModalityConverterBuildStrategy.LMRP.
            Follows build_lm_request_processor signature.
            Defaults to None.
    """
    source_modality: Modality
    target_modality: Modality
    task_type: ModalityConverterTask
    approach_type: ModalityConverterApproach | None
    preset: str | None
    strategy: ModalityConverterBuildStrategy | None
    lmrp_config: dict[str, Any] | None
    class Config:
        """Pydantic model configuration.

        This class defines the Pydantic model configuration for the ConverterConfig model.

        Attributes:
            extra (str): Allow extra fields.
        """
        extra: str
