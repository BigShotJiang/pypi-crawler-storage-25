from gllm_multimodal.constants import DEFAULT_ROUTER_EMBEDDING_MODEL as DEFAULT_ROUTER_EMBEDDING_MODEL, Modality as Modality, ModalityTransformerRouterPreset as ModalityTransformerRouterPreset
from pydantic import BaseModel
from typing import Any

DEFAULT_BATCH_SIZE: int

class RouterConfig(BaseModel):
    """Configuration for building a router instance.

    Attributes:
        modality (Modality): Modality type. Defaults to Modality.IMAGE.
        preset (ModalityTransformerRouterPreset): Router preset type. Defaults to MULTIMODAL.
        model_id (str): Embedding model ID for multimodal preset. Defaults to DEFAULT_ROUTER_EMBEDDING_MODEL.
        model_params (dict[str, Any]): Additional parameters for the embedding model.
        es_url (str | None): Elasticsearch URL for vector store. Defaults to None.
        es_index_name (str | None): Elasticsearch index name. Defaults to None.
        route_mapping (dict[str, str]): Mapping from route labels (as returned by the router)
            to converter names (keys in converter_config). Defaults to an empty dict.
        batch_size (int): Batch size for indexing utterances. Defaults to DEFAULT_BATCH_SIZE.
    """
    modality: Modality
    preset: ModalityTransformerRouterPreset
    model_id: str
    model_params: dict[str, Any]
    es_url: str | None
    es_index_name: str | None
    route_mapping: dict[str, str]
    batch_size: int
