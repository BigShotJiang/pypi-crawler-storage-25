from pydantic import BaseModel
from typing import Any

class TransformResult(BaseModel):
    """Base class for all transformation operation results.

    This class provides the foundation for structured results from any
    transformation operation, including:
        - Image-to-Caption
        - Image-to-Mermaid

    Attributes:
        result (str | bytes): The transformed result.
        tag (str): The tag of the conversion result.
        route (str): The selected route from the router.
        captions (str | list[str]): The captions generated during conversion.
        text_repr (str | list[str] | dict[str, Any]): The text representation of the result.
        metadata (dict[str, Any] | BaseModel): Additional metadata generated from the transformation.
    """
    result: str | bytes
    tag: str
    route: str
    captions: str | list[str]
    text_repr: str | list[str] | dict[str, Any]
    metadata: dict[str, Any] | BaseModel | None
