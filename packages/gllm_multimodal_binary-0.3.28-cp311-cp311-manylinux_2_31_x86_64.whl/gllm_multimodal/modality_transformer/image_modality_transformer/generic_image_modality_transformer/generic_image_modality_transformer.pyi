from _typeshed import Incomplete
from gllm_multimodal.builder.modality_converter_builder import build_modality_converter as build_modality_converter
from gllm_multimodal.modality_converter.modality_converter import BaseModalityConverter as BaseModalityConverter
from gllm_multimodal.modality_transformer.image_modality_transformer.generic_image_modality_transformer.defaults import get_default_converter_config as get_default_converter_config
from gllm_multimodal.modality_transformer.image_modality_transformer.image_modality_transformer import ImageModalityTransformer as ImageModalityTransformer
from gllm_multimodal.modality_transformer.schema import ConverterConfig as ConverterConfig, TransformResult as TransformResult
from gllm_multimodal.schema import TextResult as TextResult
from gllm_multimodal.utils.converter_result_utils import extract_captions_from_result as extract_captions_from_result, extract_text_repr_from_result as extract_text_repr_from_result

logger: Incomplete

class GenericImageModalityTransformer(ImageModalityTransformer):
    """A generic transformer which uses a single converter to convert images to text.

    Attributes:
        converter (BaseModalityConverter): The converter used to transform images into text.
    """
    converter: Incomplete
    def __init__(self, converter: BaseModalityConverter) -> None:
        """Initializes the transformer with a modality converter.

        Args:
            converter (BaseModalityConverter): An instance of a modality converter responsible
                for performing the image-to-text or image-to-bytes transformation.
        """
    @classmethod
    def from_config(cls, converter_config: dict[str, ConverterConfig] | None = None) -> GenericImageModalityTransformer:
        """Create an instance from a converter configuration dict.

        This function:
            1. Build the converter from the converter_config.
            2. Create the GenericImageModalityTransformer instance.

        Args:
            converter_config (dict[str, ConverterConfig] | None, optional): Per-converter configurations
                keyed by converter name. Defaults to None.

        Returns:
            GenericImageModalityTransformer: An instance configured from the given dict.
        """
