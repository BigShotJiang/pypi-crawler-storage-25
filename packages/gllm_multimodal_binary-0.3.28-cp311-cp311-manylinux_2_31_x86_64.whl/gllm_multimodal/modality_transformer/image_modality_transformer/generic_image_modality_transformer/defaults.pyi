from gllm_multimodal.constants import Modality as Modality, ModalityConverterApproach as ModalityConverterApproach, ModalityConverterTask as ModalityConverterTask
from gllm_multimodal.modality_transformer.schema.converter_config import ConverterConfig as ConverterConfig

def get_default_converter_config() -> dict[str, ConverterConfig]:
    """Get default converter configuration for GenericImageModalityTransformer.

    Returns:
        dict[str, ConverterConfig]: Dictionary mapping converter names to their configurations.
    """
