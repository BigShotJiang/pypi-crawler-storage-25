from gllm_multimodal.constants import DEFAULT_ROUTER_EMBEDDING_MODEL as DEFAULT_ROUTER_EMBEDDING_MODEL, Modality as Modality, ModalityConverterApproach as ModalityConverterApproach, ModalityConverterTask as ModalityConverterTask, ModalityTransformerRouterPreset as ModalityTransformerRouterPreset
from gllm_multimodal.modality_transformer.schema.converter_config import ConverterConfig as ConverterConfig
from gllm_multimodal.modality_transformer.schema.router_config import RouterConfig as RouterConfig

def get_default_route_mapping() -> dict[str, str]:
    """Get default route mapping for StandardImageModalityTransformer.

    Returns:
        dict[str, str]: Dictionary mapping route names to their converter names.
    """
def get_default_converter_config() -> dict[str, ConverterConfig]:
    """Get default converter configuration for StandardImageModalityTransformer.

    Returns:
        dict[str, ConverterConfig]: Dictionary mapping converter names to their configurations.
    """
def get_default_router_config() -> RouterConfig:
    """Get default router configuration for StandardImageModalityTransformer.

    Returns:
        RouterConfig: Default router configuration instance.
    """
