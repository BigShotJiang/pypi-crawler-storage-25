from _typeshed import Incomplete
from gllm_multimodal.builder import build_modality_converter as build_modality_converter
from gllm_multimodal.builder.helper.build_router import build_router as build_router
from gllm_multimodal.modality_converter.modality_converter import BaseModalityConverter as BaseModalityConverter
from gllm_multimodal.modality_transformer.image_modality_transformer.image_modality_transformer import ImageModalityTransformer as ImageModalityTransformer
from gllm_multimodal.modality_transformer.image_modality_transformer.standard_image_modality_transformer.defaults import get_default_converter_config as get_default_converter_config, get_default_route_mapping as get_default_route_mapping, get_default_router_config as get_default_router_config
from gllm_multimodal.modality_transformer.image_modality_transformer.standard_image_modality_transformer.preset import get_preset as get_preset
from gllm_multimodal.modality_transformer.schema import ConverterConfig as ConverterConfig, RouterConfig as RouterConfig, TransformResult as TransformResult
from gllm_multimodal.utils.converter_result_utils import extract_captions_from_result as extract_captions_from_result, extract_text_repr_from_result as extract_text_repr_from_result
from gllm_multimodal.utils.image_utils import resize_attachment as resize_attachment
from gllm_pipeline.router.router import BaseRouter
from typing import Any

logger: Incomplete
DEFAULT_MIN_IMAGE_SIZE: Incomplete

class StandardImageModalityTransformer(ImageModalityTransformer):
    """A standardized image modality transformer that routes and applies converter.

    This class integrates a routing mechanism to dynamically select a converter
    according to the characteristics of the image input (e.g., format, content, etc.).

    Attributes:
        router (BaseRouter): A routing component that determines the route based on the input image.
        route_mapping (dict[str, BaseModalityConverter]): A mapping of route names to their corresponding
            modality converters.
    """
    router: Incomplete
    route_mapping: Incomplete
    def __init__(self, router: BaseRouter, route_mapping: dict[str, BaseModalityConverter]) -> None:
        """Initialize the StandardImageModalityTransformer.

        Args:
            router (BaseRouter): The router responsible for selecting the route.
            route_mapping (dict[str, BaseModalityConverter]): Mapping from route names to modality converters.

        Raises:
            ValueError: If any expected route from the router is missing in the route_mapping.
        """
    @classmethod
    def from_preset(cls, preset_name: str, **kwargs: Any) -> StandardImageModalityTransformer:
        """Create an instance using a predefined preset configuration.

        Args:
            preset_name (str): Name of the preset to use.
            **kwargs (Any): Additional arguments passed to create the class.

        Returns:
            StandardImageModalityTransformer: An instance configured with the preset.
        """
    @classmethod
    def from_config(cls, converter_config: dict[str, ConverterConfig] | None = None, router_config: RouterConfig | None = None, **kwargs: Any) -> StandardImageModalityTransformer:
        """Create an instance from converter and router configuration dicts.

        This function:
            1. Build converters from converter_config.
            2. Build the router from router_config.
            3. Create the StandardImageModalityTransformer instance.

        Args:
            converter_config (dict[str, ConverterConfig] | None, optional): Per-converter configurations
                keyed by converter name. Defaults to None.
            router_config (RouterConfig | None, optional): Router configuration. Defaults to None.
            **kwargs (Any): Accepted for interface consistency with other transformers; not used.

        Returns:
            StandardImageModalityTransformer: An instance configured from the given dicts.
        """
