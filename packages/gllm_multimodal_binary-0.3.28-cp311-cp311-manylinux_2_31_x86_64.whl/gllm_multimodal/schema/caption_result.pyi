from gllm_multimodal.schema.caption import Caption as Caption
from typing import Any

class CaptionResult(Caption):
    """Result of a caption operation.

    Attributes:
        captions (str | list[str] | dict[str, Any]): The caption result.
    """
    captions: str | list[str] | dict[str, Any]
