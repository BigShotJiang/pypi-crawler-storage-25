from _typeshed import Incomplete
from gllm_multimodal.schema.audio_transcript import AudioTranscript
from pydantic import BaseModel

__all__ = ['Keyframe', 'Segment', 'VideoCaptionMetadata', 'VideoCaptionResult']

class Keyframe(BaseModel):
    """Represents a keyframe extracted from a video segment.

    Attributes:
        time_offset (float): Time within the segment where the keyframe occurs.
        caption (str | None): Text description of this specific keyframe.
    """
    model_config: Incomplete
    time_offset: float
    caption: str | None

class Segment(BaseModel):
    """Represents a video segment with its captions, transcripts, and keyframes.

    Attributes:
        start_time (float | None): The segment's starting time in seconds.
        end_time (float | None): The segment's ending time in seconds.
        transcripts (list[AudioTranscript]): Optional list of transcripts for the segment.
        segment_caption (list[str]): The single, rich description of the segment's action/plot.
        keyframes (list[Keyframe]): Optional list of keyframes extracted from the segment.
    """
    model_config: Incomplete
    start_time: float | None
    end_time: float | None
    transcripts: list[AudioTranscript]
    segment_caption: list[str]
    keyframes: list[Keyframe]
    def ensure_caption(self) -> Segment:
        """Ensure segment has caption, fallback to keyframes/transcripts if needed."""
    def ensure_keyframes(self) -> Segment:
        """Ensure all keyframes time offset is non-negative."""
    def ensure_transcripts(self) -> Segment:
        """Ensure all transcripts time offset is non-negative."""

class VideoCaptionMetadata(BaseModel):
    """Metadata for video captioning results.

    Attributes:
        video_summary (str): A high-level summary of the entire video's plot, topic, or main events.
        segments (list[Segment]): List of video segments with their captions and metadata.
    """
    video_summary: str
    segments: list[Segment]
    def ensure_segment_end_time_greater_than_start_time(self) -> VideoCaptionMetadata:
        """Ensure segment end time is greater than start time.

        If end time equal or lower than start time, then use next segment start time-1 as end time.
        """

class VideoCaptionResult(VideoCaptionMetadata):
    """Backward-compatible model alias for video caption result payload."""
