from .video_caption_metadata import Keyframe as Keyframe, Segment as Segment

__all__ = ['Segment', 'Keyframe']
