"""Minimap rendering mixin for GrafliView."""

from __future__ import annotations

import re

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QBrush, QColor, QFont, QPainter, QPen

from grafli.constants import (
    BOX_BORDER,
    FONT_FAMILY,
    MINIMAP_BG,
    MINIMAP_BORDER_COLOR,
    MINIMAP_CONNECTOR_COLOR,
    MINIMAP_INFO_COLOR,
    MINIMAP_MARGIN,
    MINIMAP_MAX_H,
    MINIMAP_MAX_W,
    MINIMAP_STATS_COLOR,
    MINIMAP_STATS_FONT_SIZE,
    MINIMAP_TIER_COLORS,
    MINIMAP_VIEWPORT_COLOR,
    NOTE_DISCUSSION_COLOR,
    NOTE_PEN_COLOR,
    NOTE_QUESTION_COLOR,
    NOTE_TASK_COLOR,
    _resolve_color,
)

_RE_SPEAKER = re.compile(r"^([A-Z][A-Za-z0-9_-]{0,15}): ", re.MULTILINE)

_TIER_LABELS = ("Simple", "Moderate", "Intricate", "Dense")


class MinimapMixin:
    """Mixin providing minimap rendering and click-to-navigate.

    Expects the host class to have: _minimap_visible, _minimap_rect,
    _minimap_panel_rect, _minimap_scene_rect, _board, _note_items,
    viewport(), mapToScene().
    """

    def _compute_graph_stats(self) -> dict:
        """Compute node/edge/cyclomatic stats for the current board."""
        boxes = self._board.boxes
        arrows = self._board.arrows
        n = len(boxes)
        e = len(arrows)

        # Connected components via BFS (undirected)
        ids = {b.id for b in boxes}
        adj: dict[str, set[str]] = {bid: set() for bid in ids}
        for a in arrows:
            if a.from_id in adj and a.to_id in adj:
                adj[a.from_id].add(a.to_id)
                adj[a.to_id].add(a.from_id)
        visited: set[str] = set()
        components = 0
        for bid in ids:
            if bid not in visited:
                components += 1
                stack = [bid]
                while stack:
                    cur = stack.pop()
                    if cur in visited:
                        continue
                    visited.add(cur)
                    stack.extend(adj[cur] - visited)

        cyclomatic = e - n + 2 * components if n > 0 else 0

        # Fuzzy label: tier = max(node_tier, cyclomatic_tier)
        n_tier = 0 if n <= 8 else (1 if n <= 20 else (2 if n <= 40 else 3))
        c_tier = 0 if cyclomatic <= 3 else (1 if cyclomatic <= 8 else (2 if cyclomatic <= 15 else 3))
        tier = max(n_tier, c_tier)
        label = _TIER_LABELS[tier]

        return {"n": n, "e": e, "c": cyclomatic, "label": label, "tier": tier}

    def _draw_minimap(self, painter: QPainter):
        """Draw the minimap overlay. Call from drawForeground."""
        if not self._minimap_visible or not self._board:
            return
        if not self._board.boxes and not self._board.notes:
            return

        painter.resetTransform()
        vp = self.viewport().rect()

        # Compute scene bounding rect of all boxes + notes with padding
        rects = []
        for box in self._board.boxes:
            rects.append(QRectF(box.x, box.y, box.w, box.h))
        for note in self._board.notes:
            ni = self._note_items.get(note.id)
            if ni:
                br = ni.boundingRect()
                rects.append(QRectF(note.x, note.y, br.width(), br.height()))
        if not rects:
            return
        scene_rect = rects[0]
        for r in rects[1:]:
            scene_rect = scene_rect.united(r)
        scene_rect = scene_rect.adjusted(-40, -40, 40, 40)
        self._minimap_scene_rect = scene_rect

        # Fit into minimap dimensions preserving aspect ratio
        aspect = scene_rect.width() / max(scene_rect.height(), 1)
        if aspect > MINIMAP_MAX_W / MINIMAP_MAX_H:
            mw = MINIMAP_MAX_W
            mh = mw / max(aspect, 0.01)
        else:
            mh = MINIMAP_MAX_H
            mw = mh * aspect

        # Compute stats text height for unified panel
        if not self._graph_stats:
            self._graph_stats = self._compute_graph_stats()
        stats = self._graph_stats

        stats_font = QFont(FONT_FAMILY, MINIMAP_STATS_FONT_SIZE)
        painter.setFont(stats_font)
        fm = painter.fontMetrics()
        stats_line_h = fm.height()
        stats_gap = 6
        panel_pad = 8

        hint_font = QFont(FONT_FAMILY, 9)
        painter.setFont(hint_font)
        hint_line_h = painter.fontMetrics().height()
        hint_gap = 4
        painter.setFont(stats_font)

        # Panel dimensions: stats header + gap + minimap + gap + hint footer
        panel_h = panel_pad + stats_line_h + stats_gap + mh + hint_gap + hint_line_h + panel_pad
        panel_w = mw + panel_pad * 2
        panel_x = vp.width() - panel_w - MINIMAP_MARGIN
        panel_y = vp.height() - panel_h - MINIMAP_MARGIN
        panel_rect = QRectF(panel_x, panel_y, panel_w, panel_h)
        self._minimap_panel_rect = panel_rect

        # Minimap content area inside the panel
        mx = panel_x + panel_pad
        my = panel_y + panel_pad + stats_line_h + stats_gap
        self._minimap_rect = QRectF(mx, my, mw, mh)

        # Draw unified panel background
        painter.setPen(QPen(MINIMAP_BORDER_COLOR, 1))
        painter.setBrush(QBrush(MINIMAP_BG))
        painter.drawRoundedRect(panel_rect, 6, 6)

        # ── Stats line inside panel header ──
        stats_text = f"N:{stats['n']}  E:{stats['e']}  C:{stats['c']}"
        label_text = stats["label"]
        separator = " \u00b7 "

        stats_baseline = panel_y + panel_pad + fm.ascent()

        painter.setFont(stats_font)
        painter.setPen(QPen(MINIMAP_STATS_COLOR))
        stats_w = fm.horizontalAdvance(stats_text)
        painter.drawText(QPointF(mx, stats_baseline), stats_text)

        sep_x = mx + stats_w
        sep_w = fm.horizontalAdvance(separator)
        painter.drawText(QPointF(sep_x, stats_baseline), separator)

        label_x = sep_x + sep_w
        tier_color = MINIMAP_TIER_COLORS[stats["tier"]]
        painter.setPen(QPen(tier_color))
        painter.drawText(QPointF(label_x, stats_baseline), label_text)

        # Info circle (right-aligned in panel header)
        info_r = 7
        info_cx = mx + mw - info_r - 1
        info_cy = stats_baseline - fm.ascent() / 2
        info_rect = QRectF(info_cx - info_r, info_cy - info_r,
                           info_r * 2, info_r * 2)
        self._minimap_info_rect = info_rect

        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QBrush(MINIMAP_INFO_COLOR))
        painter.drawEllipse(info_rect)

        info_font = QFont(FONT_FAMILY, 9)
        info_font.setBold(True)
        painter.setFont(info_font)
        painter.setPen(QPen(QColor(255, 255, 255)))
        painter.drawText(info_rect, Qt.AlignmentFlag.AlignCenter, "i")

        # ── Minimap content ──
        sx = mw / scene_rect.width()
        sy = mh / scene_rect.height()

        # Draw connectors first (under boxes/notes) — single neutral colour
        # gives a density read of the graph without competing with the
        # element markers drawn on top.
        elem_centers: dict[str, tuple[float, float]] = {}
        for box in self._board.boxes:
            cx = mx + (box.x - scene_rect.x() + box.w / 2) * sx
            cy = my + (box.y - scene_rect.y() + box.h / 2) * sy
            elem_centers[box.id] = (cx, cy)
        for note in self._board.notes:
            cx = mx + (note.x - scene_rect.x() + 10) * sx
            cy = my + (note.y - scene_rect.y() + 10) * sy
            elem_centers[note.id] = (cx, cy)

        painter.setPen(QPen(MINIMAP_CONNECTOR_COLOR, 1))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        for arrow in self._board.arrows:
            src = elem_centers.get(arrow.from_id)
            dst = elem_centers.get(arrow.to_id)
            if src is None or dst is None or src == dst:
                continue
            painter.drawLine(QPointF(src[0], src[1]), QPointF(dst[0], dst[1]))

        # Draw boxes
        painter.setPen(Qt.PenStyle.NoPen)
        for box in self._board.boxes:
            color_hex = _resolve_color(box.color) if box.color else ""
            if color_hex:
                c = QColor(color_hex)
            else:
                c = QColor(BOX_BORDER)
            painter.setBrush(QBrush(c))
            bx = mx + (box.x - scene_rect.x()) * sx
            by = my + (box.y - scene_rect.y()) * sy
            bw = max(box.w * sx, 2)
            bh = max(box.h * sy, 2)
            painter.drawRect(QRectF(bx, by, bw, bh))

        # Draw notes as small markers
        from grafli.items import note_prefix as _note_prefix
        for note in self._board.notes:
            p = _note_prefix(note.text)
            if p is not None:
                color = NOTE_TASK_COLOR if p[0] == "T:" else NOTE_QUESTION_COLOR
            elif len(set(_RE_SPEAKER.findall(note.text))) >= 2:
                color = NOTE_DISCUSSION_COLOR
            else:
                color = NOTE_PEN_COLOR
            painter.setBrush(QBrush(color))
            nx = mx + (note.x - scene_rect.x()) * sx
            ny = my + (note.y - scene_rect.y()) * sy
            painter.drawRect(QRectF(nx, ny, max(3, 20 * sx), max(3, 20 * sy)))

        # Viewport indicator
        vp_scene = self.mapToScene(vp).boundingRect()
        vx = mx + (vp_scene.x() - scene_rect.x()) * sx
        vy = my + (vp_scene.y() - scene_rect.y()) * sy
        vw = vp_scene.width() * sx
        vh = vp_scene.height() * sy
        vp_rect = QRectF(vx, vy, vw, vh).intersected(self._minimap_rect)
        painter.setBrush(QBrush(MINIMAP_VIEWPORT_COLOR))
        painter.setPen(QPen(QColor(255, 255, 255, 120), 1))
        painter.drawRect(vp_rect)

        # ── F1 Help hint in bottom-left of panel ──
        hint_font = QFont(FONT_FAMILY, 9)
        painter.setFont(hint_font)
        painter.setPen(QPen(MINIMAP_STATS_COLOR))
        hint_y = panel_y + panel_h - panel_pad
        painter.drawText(QPointF(mx, hint_y), "F1 Help")

    def _minimap_viewport_rect(self) -> QRectF:
        """Compute the viewport indicator rect in minimap (widget) coords."""
        mr = self._minimap_rect
        sr = self._minimap_scene_rect
        if mr.isNull() or sr.isNull():
            return QRectF()
        sx = mr.width() / sr.width()
        sy = mr.height() / sr.height()
        vp_scene = self.mapToScene(self.viewport().rect()).boundingRect()
        vx = mr.x() + (vp_scene.x() - sr.x()) * sx
        vy = mr.y() + (vp_scene.y() - sr.y()) * sy
        vw = vp_scene.width() * sx
        vh = vp_scene.height() * sy
        return QRectF(vx, vy, vw, vh).intersected(mr)

    def _minimap_to_scene(self, minimap_pos: QPointF) -> QPointF:
        """Map a minimap widget position to scene coordinates."""
        mr = self._minimap_rect
        sr = self._minimap_scene_rect
        rx = (minimap_pos.x() - mr.x()) / mr.width()
        ry = (minimap_pos.y() - mr.y()) / mr.height()
        return QPointF(sr.x() + rx * sr.width(),
                       sr.y() + ry * sr.height())

    def _minimap_press(self, event_position) -> bool:
        """Handle press on minimap: info button, drag viewport, or click-to-jump."""
        if not self._minimap_visible:
            return False

        # Info button hit-test (inside panel header)
        info_rect = getattr(self, "_minimap_info_rect", None)
        if info_rect and info_rect.contains(event_position):
            self._show_graph_stats_dialog()
            return True

        # Click inside minimap content area → navigate
        if not self._minimap_rect.isNull() and self._minimap_rect.contains(event_position):
            pass  # fall through to viewport drag / click-to-jump below
        elif not self._minimap_panel_rect.isNull() and self._minimap_panel_rect.contains(event_position):
            return True  # consume click on panel header / padding
        else:
            return False

        vp_ind = self._minimap_viewport_rect()
        if not vp_ind.isNull() and vp_ind.contains(event_position):
            self._minimap_dragging = True
            center = vp_ind.center()
            self._minimap_drag_offset = QPointF(
                event_position.x() - center.x(),
                event_position.y() - center.y(),
            )
        else:
            self.centerOn(self._minimap_to_scene(event_position))
        return True

    def _minimap_move(self, event_position) -> bool:
        """Handle drag on minimap viewport indicator."""
        if not self._minimap_dragging:
            return False
        adjusted = QPointF(
            event_position.x() - self._minimap_drag_offset.x(),
            event_position.y() - self._minimap_drag_offset.y(),
        )
        self.centerOn(self._minimap_to_scene(adjusted))
        return True

    def _minimap_release(self) -> bool:
        """End minimap viewport drag."""
        if not self._minimap_dragging:
            return False
        self._minimap_dragging = False
        return True
