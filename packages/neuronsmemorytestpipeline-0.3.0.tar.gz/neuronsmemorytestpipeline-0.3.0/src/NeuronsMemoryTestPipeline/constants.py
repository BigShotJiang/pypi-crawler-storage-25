 # ── GCP / Model ──────────────────────────────────────────────
PROJECT = "neurons-ml"
LOCATION = "us-central1"
MODEL_ID = "gemini-2.5-flash-lite"

GENERATION_CONFIG = {
    "candidate_count": 1,
    "max_output_tokens": 64,
    "temperature": 0.0,
}

# ── MRT MODULE ───────────────────────────────────────────────
MRT_COLUMNS = [
    "reason_to_end_the_behavioral_task_code",
    "participant_id",
    "group_id",
    "provider_id",
    "module_name",
    "project_identifier",
    "reaction_time",
    "task_name",
    "trial_name",
    "given_response_label_presented",
    "procedure_name",
    "trial_stimulus_category",
    "expected_response",
    "given_response_accuracy",
    "given_response_label_english",
    "Gender",
    "Age",
]

# ── FRT MODULE ───────────────────────────────────────────────
FRT_COLUMNS_RENAME = {
    "procedure_stimulus": "frt_stimulus",
    "trial_association_english": "frt_association",
    "given_response_label_english": "frt_response",
}

# ── Spell-check prompt ──────────────────────────────────────
SPELLCHECK_PROMPT_TEMPLATE = """\
You are a **Brand Name Matcher**.

## Context
A respondent was shown advertisements for specific brands and later asked to
freely recall them.  Their typed answer may contain:
- Minor or major misspellings  (e.g. "Addidas" → "Adidas")
- Partial names               (e.g. "Outfitters" → "Urban Outfitters")
- Singular / plural variants   (e.g. "Petal Grace" → "Petals and Grace")
- Well-known abbreviations or full expansions
  (e.g. "Kentucky Fried Chicken" → "KFC",  "ESPN" → "ESPN Bet")
- Word reordering              (e.g. "Urban Outfitters" → "Outfitters Urban")
- A single distinctive word    (e.g. "Colgate" → "Colgate-Palmolive")

## Valid brand names
{potential_responses}

## Input to match
"{brand_to_check}"

## Rules
1. If the input is a plausible reference to **exactly one** brand in the list,
   set `corrected` to that brand name **exactly as it appears in the list**.
2. Consider famous abbreviations / full names of brands even if only the
   abbreviation or only the full name is in the list.
3. Accept singular/plural differences, missing or extra words like
   "the", "and", "of", minor word-order changes.
4. **Prefer direct word matches over loose associations.**
5. If the input is gibberish, a random word unrelated to any brand,
   "I don't know", or could match **more than one** brand equally,
   set `corrected` to exactly: Not Found
6. Be generous but not reckless — the respondent DID see the brands,
   so lean towards matching when reasonable.
"""

# ═══════════════════════════════════════════════════════════════
#  Text helpers
# ═══════════════════════════════════════════════════════════════

GENERIC_NOT_FOUND = {
    "idk",
    "i don't know",
    "i dont know",
    "dont know",
    "don't know",
    "can't remember",
    "cant remember",
    "no idea",
    "nothing",
    "na",
    "n/a",
    "none",
    "other",
    "others",
    "not sure",
    "no",
    "nope",
    "forgot",
    "forget",
    "?",
    "...",
    "-",
    "x",
}

STOP_WORDS = {
    "the",
    "and",
    "of",
    "for",
    "in",
    "a",
    "an",
    "by",
    "to",
    "or",
    "is",
    "it",
    "its",
    "plc",
    "ltd",
    "inc",
    "co",
    "corp",
    "group",
    "services",
    "trust",
    "hotels",
    "hotel",
}
