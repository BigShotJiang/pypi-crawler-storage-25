from __future__ import annotations

import functools
import re
import unicodedata
from collections import defaultdict
from typing import Optional

import pandas as pd
from pydantic import BaseModel
from rapidfuzz import fuzz, process
from rapidfuzz.distance import Levenshtein
from tqdm.auto import tqdm

from NeuronsMemoryTestPipeline.constants import (
    GENERATION_CONFIG,
    LOCATION,
    MODEL_ID,
    PROJECT,
    SPELLCHECK_PROMPT_TEMPLATE,
    GENERIC_NOT_FOUND,
    STOP_WORDS,
)

class BrandMatch(BaseModel):
    corrected: str  # exact brand name from the list, or "Not Found"



@functools.lru_cache(maxsize=1)
def _get_genai_client():
    from google import genai

    client = genai.Client(
        project=PROJECT,
        location=LOCATION,
        vertexai=True,
    )
    return client


def _llm_generate(prompt: str) -> str:
    """Call Gemini and return the structured `corrected` field."""
    from google.genai import types

    client = _get_genai_client()
    response = client.models.generate_content(
        model=MODEL_ID,
        contents=prompt,
        config=types.GenerateContentConfig(
            candidate_count=GENERATION_CONFIG["candidate_count"],
            max_output_tokens=GENERATION_CONFIG["max_output_tokens"],
            temperature=GENERATION_CONFIG["temperature"],
            response_mime_type="application/json",
            response_schema=BrandMatch,
        ),
    )
    try:
        import json

        payload = json.loads(response.text)
        return payload.get("corrected", "Not Found").strip()
    except Exception:
        return "Not Found"


def normalize(s: str) -> str:
    if not isinstance(s, str):
        return ""
    s = unicodedata.normalize("NFKC", s)
    s = s.strip()
    s = re.sub(r"\s+", " ", s)
    s = s.lower()
    s = re.sub(r"[^\w\s&+]", "", s)
    return s


def nospace(s: str) -> str:
    return re.sub(r"\s+", "", s)


def and_equiv(s: str) -> str:
    return re.sub(r"\band\b", "&", s)


def compress_runs(s: str) -> str:
    return re.sub(r"(.)\1+", r"\1", s)


def tokens(s: str) -> list[str]:
    return [t for t in re.split(r"\s+", s.strip()) if t]


def distinctive_tokens(s: str) -> list[str]:
    return [t for t in tokens(normalize(s)) if t not in STOP_WORDS and len(t) >= 2]


def bigrams(s: str) -> set[str]:
    return {s[i : i + 2] for i in range(len(s) - 1)} if len(s) > 1 else set()


def abbr_of(phrase: str) -> str:
    return "".join(w[0].upper() for w in re.split(r"\s+", (phrase or "").strip()) if w)


VOWELS = set("aeiou")


def is_numeric_like(s: str) -> bool:
    s = (s or "").strip()
    if not s:
        return True
    d = sum(c.isdigit() for c in s)
    return s.isdigit() or (len(s) >= 4 and d / len(s) >= 0.5)


def looks_like_gibberish(s: str) -> bool:
    t = re.sub(r"[^a-z]", "", normalize(s))
    if len(t) == 0:
        return True
    if len(t) >= 6 and not (set(t) & VOWELS):
        return True
    if len(t) >= 7 and (sum(ch in VOWELS for ch in t) / len(t) <= 0.1):
        return True
    if re.search(r"(.)\1{3,}", t):
        return True
    raw = normalize(s)
    non_alnum = sum(not c.isalnum() and not c.isspace() for c in raw)
    return len(raw) >= 6 and non_alnum / len(raw) > 0.3


def is_candidate_for_ai(s: str) -> bool:
    s = (s or "").strip()
    return (
        bool(s)
        and s.lower() not in GENERIC_NOT_FOUND
        and not is_numeric_like(s)
        and not looks_like_gibberish(s)
    )



def _build_indices(brands_presented: list[str]):
    brands_presented = list(dict.fromkeys(brands_presented))
    norm_to_orig: dict[str, str] = {normalize(b): b for b in brands_presented}
    norm_names: list[str] = list(norm_to_orig.keys())

    # abbreviation map: "KFC" -> ["KFC"], initials of multi-word brands
    abbr_map: dict[str, list[str]] = defaultdict(list)
    for b in brands_presented:
        ab = abbr_of(b)
        if len(ab) >= 2:
            abbr_map[ab].append(b)

    # exact-equivalence maps
    ns_map = {nospace(k): v for k, v in norm_to_orig.items()}
    and_map = {nospace(and_equiv(k)): v for k, v in norm_to_orig.items()}
    cr_map = {compress_runs(k): v for k, v in norm_to_orig.items()}
    cr_ns_map = {nospace(compress_runs(k)): v for k, v in norm_to_orig.items()}
    ns_cr_map = {compress_runs(nospace(k)): v for k, v in norm_to_orig.items()}

    # distinctive-token → brand(s) map
    dt_map: dict[str, list[str]] = defaultdict(list)
    for b in brands_presented:
        for tok in distinctive_tokens(b):
            dt_map[tok].append(b)

    return (
        brands_presented,
        norm_to_orig,
        norm_names,
        abbr_map,
        ns_map,
        and_map,
        cr_map,
        cr_ns_map,
        ns_cr_map,
        dt_map,
    )

def _grounded_match(
    user_text: str,
    norm_to_orig: dict,
    norm_names: list,
    abbr_map: dict,
    ns_map: dict,
    and_map: dict,
    cr_map: dict,
    cr_ns_map: dict,
    ns_cr_map: dict,
    dt_map: dict,
) -> tuple[str, str]:
    raw = user_text or ""
    raw_norm = normalize(raw)

    # ── obvious not-found ──
    if raw_norm in GENERIC_NOT_FOUND or raw_norm == "":
        return "", "not_match"

    # ── 1. exact normalized ──
    if raw_norm in norm_to_orig:
        return norm_to_orig[raw_norm], "exact"

    # ── 2. exact-equivalence transforms ──
    k = nospace(raw_norm)
    if k in ns_map:
        return ns_map[k], "exact_nospace"

    k2 = nospace(and_equiv(raw_norm))
    if k2 in and_map:
        return and_map[k2], "exact_and_equiv"

    k3 = compress_runs(raw_norm)
    if k3 in cr_map:
        return cr_map[k3], "exact_compress"

    k4 = nospace(compress_runs(raw_norm))
    if k4 in cr_ns_map:
        return cr_ns_map[k4], "exact_compress_nospace"

    k5 = compress_runs(nospace(raw_norm))
    if k5 in ns_cr_map:
        return ns_cr_map[k5], "exact_nospace_compress"

    # ── 3. containment: all user tokens exist in brand tokens (exact) ──
    raw_toks = set(tokens(raw_norm))
    for bn, orig in norm_to_orig.items():
        bn_toks = set(tokens(bn))
        if raw_toks and raw_toks <= bn_toks:
            return orig, "containment"
        if bn_toks and bn_toks <= raw_toks:
            return orig, "containment"

    # ── 4. abbreviation ──
    raw_upper = raw.strip().upper().replace(".", "")
    if len(raw_upper) >= 2 and raw_upper in abbr_map:
        if len(abbr_map[raw_upper]) == 1:
            return abbr_map[raw_upper][0], "abbreviation"

    user_abbr = abbr_of(raw)
    if len(user_abbr) >= 2:
        user_abbr_norm = normalize(user_abbr)
        if user_abbr_norm in norm_to_orig:
            return norm_to_orig[user_abbr_norm], "abbreviation_reverse"

    # ── 5. high-confidence fuzzy only (score >= 90 AND low edit distance) ──
    hit = process.extractOne(raw_norm, norm_names, scorer=fuzz.token_sort_ratio)
    if hit:
        cand_norm, score, _ = hit
        cand_orig = norm_to_orig[cand_norm]
        edit_dist = Levenshtein.distance(raw_norm, cand_norm)
        if score >= 90 and edit_dist <= 2:
            return cand_orig, "fuzzy"

    return "", "maybe"



def _ai_spellcheck_batch(
    candidates_unique: list[str],
    brands_presented: list[str],
) -> pd.DataFrame:
    """Send unresolved entries to Gemini and return corrections."""

    clean = [c for c in candidates_unique if is_candidate_for_ai(c)]
    print(
        f"[AI] candidates after junk filter: {len(clean)} / {len(candidates_unique)}"
    )

    if len(clean) == 0:
        return pd.DataFrame(
            columns=["given_response_label_presented", "corrected", "method"]
        )

    brands_str = "\n".join(f"  - {b}" for b in brands_presented)
    rows = []

    for item in tqdm(clean, desc="AI spellcheck", leave=False):
        prompt = SPELLCHECK_PROMPT_TEMPLATE.format(
            potential_responses=brands_str,
            brand_to_check=item,
        )
        try:
            txt = _llm_generate(prompt)
        except Exception as e:
            print(f"[AI] Error for '{item}': {e}")
            txt = "Not Found"

        if txt and txt != "Not Found" and txt in brands_presented:
            rows.append(
                {
                    "given_response_label_presented": item,
                    "corrected": txt,
                    "method": "ai",
                }
            )

    return pd.DataFrame(rows)


def clean_free_recall_fast(
    df: pd.DataFrame,
    brands_presented: list[str],
    *,
    use_ai: bool = True,
) -> pd.DataFrame:
    """
    Clean free-recall responses by matching to the given brand list.

    Parameters
    ----------
    df : DataFrame
        Must contain column ``given_response_label_presented``.
    brands_presented : list[str]
        The canonical brand names for this group.
    use_ai : bool
        Whether to call Gemini for entries that cannot be resolved
        deterministically.  Default ``True``.

    Returns
    -------
    DataFrame
        Copy of *df* with added columns ``corrected`` and ``method``.
    """
    (
        brands_presented,
        norm_to_orig,
        norm_names,
        abbr_map,
        ns_map,
        and_map,
        cr_map,
        cr_ns_map,
        ns_cr_map,
        dt_map,
    ) = _build_indices(brands_presented)

    out = df.copy()
    if "given_response_label_presented" not in out.columns:
        raise ValueError("Input df must have 'given_response_label_presented'")

    out["given_response_label_presented"] = (
        out["given_response_label_presented"].astype(str).str.strip()
    )
    out.loc[
        out["given_response_label_presented"].eq(""), "given_response_label_presented"
    ] = pd.NA

    out["method"] = ""
    out["corrected"] = ""

    results = out["given_response_label_presented"].apply(
        lambda x: _grounded_match(
            x,
            norm_to_orig,
            norm_names,
            abbr_map,
            ns_map,
            and_map,
            cr_map,
            cr_ns_map,
            ns_cr_map,
            dt_map,
        )
        if pd.notna(x)
        else ("", "not_match")
    )
    out[["corrected", "method"]] = pd.DataFrame(results.tolist(), index=out.index)

    # force "other"/"others" to not_match
    mask_others = (
        out["given_response_label_presented"].astype(str).str.lower().isin({"other", "others"})
    )
    out.loc[mask_others, "method"] = "not_match"
    out.loc[mask_others, "corrected"] = ""

    # ── AI fallback for "maybe" entries ──
    if use_ai:
        maybes = (
            out.loc[out["method"] == "maybe", "given_response_label_presented"]
            .dropna()
            .astype(str)
            .str.strip()
        )
        maybes_unique = [m for m in maybes.unique() if m]

        ai_df = _ai_spellcheck_batch(maybes_unique, brands_presented)

        if not ai_df.empty:
            ai_lookup = dict(
                zip(ai_df["given_response_label_presented"], ai_df["corrected"])
            )
            mask_maybe = out["method"] == "maybe"
            out.loc[mask_maybe, "corrected"] = out.loc[
                mask_maybe, "given_response_label_presented"
            ].map(ai_lookup)
            out.loc[mask_maybe & out["corrected"].notna(), "method"] = "ai"

        # anything still "maybe" is not_match
        still_maybe = out["method"] == "maybe"
        out.loc[still_maybe, "method"] = "not_match"
        out.loc[still_maybe, "corrected"] = ""

    return out


def calculate_corrected_brands_fast(
    df: pd.DataFrame, brands_presented: list[str]
) -> pd.DataFrame:
    valid = set(brands_presented)
    count_df = df[df["corrected"].isin(valid)].drop_duplicates(
        ["participant_id", "corrected", "method"]
    )
    return (
        count_df.groupby(["group_id", "method"])["corrected"]
        .value_counts()
        .rename("count")
        .reset_index()
    )
