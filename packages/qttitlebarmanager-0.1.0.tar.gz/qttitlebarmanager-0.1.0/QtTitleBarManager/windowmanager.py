from PyQt5 import QtCore, QtGui, QtWidgets
import sys

class title_bar_handler():
    def __init__(self,form:QtWidgets.QWidget,titlebar:QtWidgets.QFrame, close_button:QtWidgets.QPushButton, minimise_button:QtWidgets.QPushButton) -> None:
        self.og_mousepress_event = form.mousePressEvent

        titlebar.mouseMoveEvent = self.MoveWindow # type: ignore
        form.mousePressEvent = self.mp # type: ignore

        minimise_button.clicked.connect(lambda : form.showMinimized())
        close_button.clicked.connect(lambda : form.close())

        form.setWindowFlags(QtCore.Qt.Window | QtCore.Qt.CustomizeWindowHint | QtCore.Qt.FramelessWindowHint | QtCore.Qt.WindowTitleHint) # type: ignore
        form.setAttribute(QtCore.Qt.WA_TranslucentBackground) # type: ignore
        self.Form = form

    def MoveWindow(self, event):
        if self.Form.isMaximized() == False:
            self.Form.move(self.Form.pos() + event.globalPos() - self.clickPosition)
            self.clickPosition = event.globalPos()
        event.accept()
        pass

    def mp(self,event):
        print('mousePressEvent')
        self.clickPosition = event.globalPos()
        self.og_mousepress_event(event)
        event.accept()
        pass