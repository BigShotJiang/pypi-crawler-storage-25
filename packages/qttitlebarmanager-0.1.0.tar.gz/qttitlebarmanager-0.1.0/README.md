
# Custom Title Bar Handler

  

This tool simplifies the process of managing custom title bars, including functionality for window movement, minimizing, and closing. It is especially useful for applications that use custom-designed UI elements instead of the default OS-provided title bars and buttons.

## Features

  

Custom Title Bar Movement: Easily implement custom title bar dragging.

Minimize Button: Add functionality for minimizing your application window.

Close Button: Add functionality for closing your application window.

  

## Installation

  

To use this tool, simply include it in your project. There is no need for additional dependencies beyond your current setup.

## Usage

  

Here’s a simple example of how to use the tool:

  

```python

  

title_bar_handler(

form=Form, # The main window or form of the application

titlebar=self.titlebar, # The custom title bar element

close_button=self.exit_button, # The custom close button

minimise_button=self.mini_button # The custom minimize button

)
```
  

## Parameters

  

form: The main window or form object you want to control.

titlebar: The custom UI element acting as your title bar. This allows dragging and moving the window.

close_button: The button that will handle the window's close action.

minimise_button: The button that will handle minimizing the window.

  

Example

```python
from your_module import title_bar_handler

  

# Assuming Form is your main application window class

# and you have created custom widgets for titlebar, exit_button, and mini_button

  

title_bar_handler(

form=Form,

titlebar=self.titlebar,

close_button=self.exit_button,

minimise_button=self.mini_button

)
```
  

This will ensure that your custom title bar and buttons work just like a standard window's controls, but with your own design.
