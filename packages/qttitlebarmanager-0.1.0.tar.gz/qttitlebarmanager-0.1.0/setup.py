import pathlib
import setuptools

setuptools.setup(
    name="QtTitleBarManager",
    version="0.1.0",
    description="A Custom Titlebar Handler for pyqt5",
    long_description=pathlib.Path("README.md").read_text(),
    long_description_content_type="text/markdown",
    install_requires=["PyQt5==5.15.11",
            "PyQt5-Qt5==5.15.2",
            "PyQt5_sip==12.15.0"],
    packages=setuptools.find_packages(),
    include_package_data=True,
)