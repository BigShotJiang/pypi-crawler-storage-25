"""Contains definitions of standard (sync) client as well as async client."""

# pylint: disable=too-many-arguments
import dataclasses
import warnings
from abc import ABC, abstractmethod
from collections.abc import AsyncGenerator, AsyncIterable, Awaitable, Callable, Generator, Iterable
from datetime import date, timedelta
from json import JSONDecodeError
from types import TracebackType
from typing import Any

import httpx

from . import __version__ as sdk_version
from . import schema
from .exceptions import (
    ApiException,
    ApiRateLimitException,
    ApiRequestException,
    ApiVersionMismatchException,
    ErrorDetails,
)

API_BASE_URL = "https://api.panel.rtbhouse.com"
API_VERSION = "v5"

DEFAULT_TIMEOUT = timedelta(seconds=60.0)
MAX_CURSOR_ROWS = 10000


@dataclasses.dataclass
class ApiTokenAuth:
    token: str


class DynamicApiTokenAuth(ABC):  # pylint: disable=too-few-public-methods
    @abstractmethod
    def get_token(self) -> str:
        pass


@dataclasses.dataclass
class BasicAuth:
    username: str
    password: str


@dataclasses.dataclass
class BasicTokenAuth:
    token: str


class Client:
    """
    A standard synchronous API client.

    The simplest way is to use it like:
    ```
    cli = Client(...)
    info = cli.get_user_info()
    adv = cli.get_advertiser(hash)
    cli.close()
    ```

    It's also possible to use it as context manager:
    ```
    with Client(...) as cli:
        info = cli.get_user_info()
        adv = cli.get_advertiser(hash)
    ```
    """

    _httpx_client: httpx.Client

    def __init__(
        self,
        auth: ApiTokenAuth | DynamicApiTokenAuth | BasicAuth | BasicTokenAuth,
        timeout: timedelta = DEFAULT_TIMEOUT,
    ) -> None:
        super().__init__()

        self._httpx_client = httpx.Client(
            base_url=build_base_url(),
            auth=_choose_auth_backend(auth),
            headers=_build_headers(),
            timeout=timeout.total_seconds(),
        )

    def close(self) -> None:
        self._httpx_client.close()

    def __enter__(self) -> "Client":
        self._httpx_client.__enter__()
        return self

    def __exit__(
        self,
        exc_type: type[BaseException],
        exc_value: BaseException,
        traceback: TracebackType,
    ) -> None:
        self._httpx_client.__exit__(exc_type, exc_value, traceback)

    def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        data: dict[str, Any] | None = None,
    ) -> Any:
        response = self._httpx_client.request(
            method,
            path,
            json=data,
            params=params,
        )
        return _validate_response(response)

    def _get_dict(
        self,
        path: str,
        *,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        response_data = self._request(
            "GET",
            path,
            params=params,
        )
        if not isinstance(response_data, dict):
            raise ValueError("Result is not a dict")
        return response_data

    def _post_dict(
        self,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        data: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        response_data = self._request(
            "POST",
            path,
            params=params,
            data=data,
        )
        if not isinstance(response_data, dict):
            raise ValueError("Result is not a dict")
        return response_data

    def _get_list_of_dicts(
        self,
        path: str,
        *,
        params: dict[str, Any] | None = None,
    ) -> list[dict[str, Any]]:
        response_data = self._request(
            "GET",
            path,
            params=params,
        )
        if not isinstance(response_data, list) or not all(isinstance(item, dict) for item in response_data):
            raise ValueError("Result is not a list of dicts")
        return response_data

    def _get_list_of_dicts_from_cursor(
        self,
        path: str,
        *,
        params: dict[str, Any] | None = None,
    ) -> Iterable[dict[str, Any]]:
        request_params = {
            "limit": MAX_CURSOR_ROWS,
        }
        request_params.update(params or {})

        while True:
            resp_data = self._get_dict(
                path,
                params=request_params,
            )
            yield from resp_data["rows"]
            next_cursor = resp_data["nextCursor"]
            if next_cursor is None:
                break
            request_params["nextCursor"] = next_cursor

    def get_user_info(self) -> schema.UserInfo:
        data = self._get_dict("/user/info")
        return schema.UserInfo(**data)

    def get_advertisers(self) -> list[schema.Advertiser]:
        data = self._get_list_of_dicts("/advertisers")
        return [schema.Advertiser(**adv) for adv in data]

    def get_advertiser(self, adv_hash: str) -> schema.Advertiser:
        data = self._get_dict(f"/advertisers/{adv_hash}")
        return schema.Advertiser(**data)

    def get_invoicing_data(self, adv_hash: str) -> schema.InvoiceData:
        data = self._get_dict(f"/advertisers/{adv_hash}/client")
        return schema.InvoiceData(**data["invoicing"])

    def get_offer_categories(self, adv_hash: str) -> list[schema.Category]:
        data = self._get_list_of_dicts(f"/advertisers/{adv_hash}/offer-categories")
        return [schema.Category(**cat) for cat in data]

    def get_offers(self, adv_hash: str) -> list[schema.Offer]:
        data = self._get_list_of_dicts(f"/advertisers/{adv_hash}/offers")
        return [schema.Offer(**offer) for offer in data]

    def get_advertiser_campaigns(self, adv_hash: str, exclude_archived: bool = False) -> list[schema.Campaign]:
        data = self._get_list_of_dicts(
            f"/advertisers/{adv_hash}/campaigns",
            params={
                "excludeArchived": exclude_archived,
            },
        )
        return [schema.Campaign(**camp) for camp in data]

    def get_billing(
        self,
        adv_hash: str,
        day_from: date,
        day_to: date,
    ) -> schema.Billing:
        data = self._get_dict(
            f"/advertisers/{adv_hash}/billing",
            params={
                "dayFrom": day_from,
                "dayTo": day_to,
            },
        )
        return schema.Billing(**data)

    def get_rtb_creatives(
        self,
        adv_hash: str,
        subcampaigns: list[str] | schema.SubcampaignsFilter | None = None,
        active_only: bool | None = None,
    ) -> list[schema.Creative]:
        params = _build_rtb_creatives_params(subcampaigns, active_only)
        data = self._get_list_of_dicts(
            f"/advertisers/{adv_hash}/rtb-creatives",
            params=params,
        )
        return [schema.Creative(**cr) for cr in data]

    def get_rtb_conversions(
        self,
        adv_hash: str,
        day_from: date,
        day_to: date,
        convention_type: schema.CountConvention = schema.CountConvention.ATTRIBUTED_POST_CLICK,
    ) -> Iterable[schema.Conversion]:
        rows = self._get_list_of_dicts_from_cursor(
            f"/advertisers/{adv_hash}/conversions",
            params={
                "dayFrom": day_from,
                "dayTo": day_to,
                "countConvention": convention_type.value,
            },
        )
        for conv in rows:
            yield schema.Conversion(**conv)

    def get_rtb_stats(
        self,
        adv_hash: str,
        day_from: date,
        day_to: date,
        group_by: list[schema.StatsGroupBy],
        metrics: list[schema.StatsMetric],
        count_convention: schema.CountConvention | None = None,
        utc_offset_hours: int = 0,
        subcampaigns: list[str] | None = None,
        user_segments: list[schema.UserSegment] | None = None,
        device_types: list[schema.DeviceType] | None = None,
    ) -> list[schema.Stats]:
        params = _build_rtb_stats_params(
            day_from,
            day_to,
            group_by,
            metrics,
            count_convention,
            utc_offset_hours,
            subcampaigns,
            user_segments,
            device_types,
        )

        data = self._get_list_of_dicts(
            f"/advertisers/{adv_hash}/rtb-stats",
            params=params,
        )
        return [schema.Stats(**st) for st in data]

    def get_summary_stats(
        self,
        adv_hash: str,
        day_from: date,
        day_to: date,
        group_by: list[schema.StatsGroupBy],
        metrics: list[schema.StatsMetric],
        count_convention: schema.CountConvention | None = None,
        utc_offset_hours: int = 0,
        subcampaigns: list[str] | None = None,
    ) -> list[schema.Stats]:
        params = _build_summary_stats_params(
            day_from, day_to, group_by, metrics, count_convention, utc_offset_hours, subcampaigns
        )

        data = self._get_list_of_dicts(
            f"/advertisers/{adv_hash}/summary-stats",
            params=params,
        )
        return [schema.Stats(**st) for st in data]

    def get_current_api_token(self) -> schema.ApiTokenDetails:
        data = self._get_dict("/tokens/current")
        return schema.ApiTokenDetails(**data)

    def rotate_current_api_token(self) -> schema.ApiTokenRotateResult:
        data = self._post_dict("/tokens/current/rotate")
        return schema.ApiTokenRotateResult(**data)


class AsyncDynamicApiTokenAuth(ABC):  # pylint: disable=too-few-public-methods
    @abstractmethod
    async def get_token(self) -> str:
        pass


class AsyncClient:
    """
    An asynchronous API client.

    Usage is the same as with synchronous client with the only difference of `await` keyword.
    ```
    cli = AsyncClient(...)
    info = await cli.get_user_info()
    await cli.close()
    ```
    """

    _httpx_client: httpx.AsyncClient

    def __init__(
        self,
        auth: ApiTokenAuth | AsyncDynamicApiTokenAuth | BasicAuth | BasicTokenAuth,
        timeout: timedelta = DEFAULT_TIMEOUT,
    ) -> None:
        super().__init__()

        self._httpx_client = httpx.AsyncClient(
            base_url=build_base_url(),
            auth=_choose_auth_backend(auth),
            headers=_build_headers(),
            timeout=timeout.total_seconds(),
        )

    async def close(self) -> None:
        await self._httpx_client.aclose()

    async def __aenter__(self) -> "AsyncClient":
        await self._httpx_client.__aenter__()
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException],
        exc_value: BaseException,
        traceback: TracebackType,
    ) -> None:
        await self._httpx_client.__aexit__(exc_type, exc_value, traceback)

    async def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        data: dict[str, Any] | None = None,
    ) -> Any:
        response = await self._httpx_client.request(
            method,
            path,
            json=data,
            params=params,
        )
        return _validate_response(response)

    async def _get_dict(
        self,
        path: str,
        *,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        response_data = await self._request(
            "GET",
            path,
            params=params,
        )
        if not isinstance(response_data, dict):
            raise ValueError("Result is not a dict")
        return response_data

    async def _post_dict(
        self,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        data: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        response_data = await self._request(
            "POST",
            path,
            params=params,
            data=data,
        )
        if not isinstance(response_data, dict):
            raise ValueError("Result is not a dict")
        return response_data

    async def _get_list_of_dicts(
        self,
        path: str,
        *,
        params: dict[str, Any] | None = None,
    ) -> list[dict[str, Any]]:
        response_data = await self._request(
            "GET",
            path,
            params=params,
        )
        if not isinstance(response_data, list) or not all(isinstance(item, dict) for item in response_data):
            raise ValueError("Result is not a list of dicts")
        return response_data

    async def _get_list_of_dicts_from_cursor(
        self,
        path: str,
        *,
        params: dict[str, Any] | None = None,
    ) -> AsyncIterable[dict[str, Any]]:
        request_params = {
            "limit": MAX_CURSOR_ROWS,
        }
        request_params.update(params or {})

        while True:
            resp_data = await self._get_dict(
                path,
                params=request_params,
            )
            for row in resp_data["rows"]:
                yield row
            next_cursor = resp_data["nextCursor"]
            if next_cursor is None:
                break
            request_params["nextCursor"] = next_cursor

    async def get_user_info(self) -> schema.UserInfo:
        data = await self._get_dict("/user/info")
        return schema.UserInfo(**data)

    async def get_advertisers(self) -> list[schema.Advertiser]:
        data = await self._get_list_of_dicts("/advertisers")
        return [schema.Advertiser(**adv) for adv in data]

    async def get_advertiser(self, adv_hash: str) -> schema.Advertiser:
        data = await self._get_dict(f"/advertisers/{adv_hash}")
        return schema.Advertiser(**data)

    async def get_invoicing_data(self, adv_hash: str) -> schema.InvoiceData:
        data = await self._get_dict(f"/advertisers/{adv_hash}/client")
        return schema.InvoiceData(**data["invoicing"])

    async def get_offer_categories(self, adv_hash: str) -> list[schema.Category]:
        data = await self._get_list_of_dicts(f"/advertisers/{adv_hash}/offer-categories")
        return [schema.Category(**cat) for cat in data]

    async def get_offers(self, adv_hash: str) -> list[schema.Offer]:
        data = await self._get_list_of_dicts(f"/advertisers/{adv_hash}/offers")
        return [schema.Offer(**offer) for offer in data]

    async def get_advertiser_campaigns(self, adv_hash: str, exclude_archived: bool = False) -> list[schema.Campaign]:
        data = await self._get_list_of_dicts(
            f"/advertisers/{adv_hash}/campaigns",
            params={
                "excludeArchived": exclude_archived,
            },
        )
        return [schema.Campaign(**camp) for camp in data]

    async def get_billing(
        self,
        adv_hash: str,
        day_from: date,
        day_to: date,
    ) -> schema.Billing:
        data = await self._get_dict(
            f"/advertisers/{adv_hash}/billing",
            params={
                "dayFrom": day_from,
                "dayTo": day_to,
            },
        )
        return schema.Billing(**data)

    async def get_rtb_creatives(
        self,
        adv_hash: str,
        subcampaigns: list[str] | schema.SubcampaignsFilter | None = None,
        active_only: bool | None = None,
    ) -> list[schema.Creative]:
        params = _build_rtb_creatives_params(subcampaigns, active_only)
        data = await self._get_list_of_dicts(
            f"/advertisers/{adv_hash}/rtb-creatives",
            params=params,
        )
        return [schema.Creative(**cr) for cr in data]

    async def get_rtb_conversions(
        self,
        adv_hash: str,
        day_from: date,
        day_to: date,
        convention_type: schema.CountConvention = schema.CountConvention.ATTRIBUTED_POST_CLICK,
    ) -> AsyncIterable[schema.Conversion]:
        rows = self._get_list_of_dicts_from_cursor(
            f"/advertisers/{adv_hash}/conversions",
            params={
                "dayFrom": day_from,
                "dayTo": day_to,
                "countConvention": convention_type.value,
            },
        )
        async for conv in rows:
            yield schema.Conversion(**conv)

    async def get_rtb_stats(
        self,
        adv_hash: str,
        day_from: date,
        day_to: date,
        group_by: list[schema.StatsGroupBy],
        metrics: list[schema.StatsMetric],
        count_convention: schema.CountConvention | None = None,
        utc_offset_hours: int = 0,
        subcampaigns: list[str] | None = None,
        user_segments: list[schema.UserSegment] | None = None,
        device_types: list[schema.DeviceType] | None = None,
    ) -> list[schema.Stats]:
        params = _build_rtb_stats_params(
            day_from,
            day_to,
            group_by,
            metrics,
            count_convention,
            utc_offset_hours,
            subcampaigns,
            user_segments,
            device_types,
        )

        data = await self._get_list_of_dicts(
            f"/advertisers/{adv_hash}/rtb-stats",
            params=params,
        )
        return [schema.Stats(**st) for st in data]

    async def get_summary_stats(
        self,
        adv_hash: str,
        day_from: date,
        day_to: date,
        group_by: list[schema.StatsGroupBy],
        metrics: list[schema.StatsMetric],
        count_convention: schema.CountConvention | None = None,
        utc_offset_hours: int = 0,
        subcampaigns: list[str] | None = None,
    ) -> list[schema.Stats]:
        params = _build_summary_stats_params(
            day_from, day_to, group_by, metrics, count_convention, utc_offset_hours, subcampaigns
        )

        data = await self._get_list_of_dicts(
            f"/advertisers/{adv_hash}/summary-stats",
            params=params,
        )
        return [schema.Stats(**st) for st in data]

    async def get_current_api_token(self) -> schema.ApiTokenDetails:
        data = await self._get_dict("/tokens/current")
        return schema.ApiTokenDetails(**data)

    async def rotate_current_api_token(self) -> schema.ApiTokenRotateResult:
        data = await self._post_dict("/tokens/current/rotate")
        return schema.ApiTokenRotateResult(**data)


class _HttpxApiTokenAuth(httpx.Auth):
    """API token auth backend."""

    _token: str

    def __init__(self, token: str) -> None:
        super().__init__()

        self._token = token

    def auth_flow(self, request: httpx.Request) -> Generator[httpx.Request, httpx.Response, None]:
        request.headers["Authorization"] = f"Bearer {self._token}"
        yield request


class _HttpxDynamicApiTokenAuth(httpx.Auth):
    """API token auth backend which resolves the token based on provider method."""

    _token_provider: Callable[[], str]

    def __init__(self, token_provider: Callable[[], str]) -> None:
        super().__init__()

        self._token_provider = token_provider

    def sync_auth_flow(self, request: httpx.Request) -> Generator[httpx.Request, httpx.Response, None]:
        token = self._token_provider()
        request.headers["Authorization"] = f"Bearer {token}"
        yield request

    async def async_auth_flow(self, _: httpx.Request) -> AsyncGenerator[  # type: ignore[override]
        httpx.Request,
        httpx.Response,
    ]:
        raise RuntimeError("This auth backend does not support async mode")


class _AsyncHttpxDynamicApiTokenAuth(httpx.Auth):
    """Async API token auth backend which resolves the token based on async provider method."""

    _token_provider: Callable[[], Awaitable[str]]

    def __init__(self, token_provider: Callable[[], Awaitable[str]]) -> None:
        super().__init__()

        self._token_provider = token_provider

    async def async_auth_flow(self, request: httpx.Request) -> AsyncGenerator[httpx.Request, httpx.Response]:
        token = await self._token_provider()
        request.headers["Authorization"] = f"Bearer {token}"
        yield request

    def sync_auth_flow(self, _: httpx.Request) -> Generator[httpx.Request, httpx.Response, None]:
        raise RuntimeError("This auth backend does not support sync mode")


class _HttpxBasicTokenAuth(httpx.Auth):
    """Basic token auth backend."""

    _token: str

    def __init__(self, token: str) -> None:
        super().__init__()

        self._token = token

    def auth_flow(self, request: httpx.Request) -> Generator[httpx.Request, httpx.Response, None]:
        request.headers["Authorization"] = f"Token {self._token}"
        yield request


def build_base_url() -> str:
    return f"{API_BASE_URL}/{API_VERSION}"


def _build_headers() -> dict[str, str]:
    return {
        "user-agent": f"rtbhouse-python-sdk/{sdk_version}",
    }


def _choose_auth_backend(
    auth: ApiTokenAuth | DynamicApiTokenAuth | AsyncDynamicApiTokenAuth | BasicAuth | BasicTokenAuth,
) -> httpx.Auth:
    match auth:
        case ApiTokenAuth(token=token):
            return _HttpxApiTokenAuth(token)
        case DynamicApiTokenAuth():
            return _HttpxDynamicApiTokenAuth(auth.get_token)
        case AsyncDynamicApiTokenAuth():
            return _AsyncHttpxDynamicApiTokenAuth(auth.get_token)
        case BasicAuth(username=username, password=password):
            return httpx.BasicAuth(username, password)
        case BasicTokenAuth(token=token):
            return _HttpxBasicTokenAuth(token)
        case _:
            raise ValueError("Unknown auth method")


def _validate_response(response: httpx.Response) -> Any:
    try:
        response_data = response.json()
    except JSONDecodeError:
        response_data = {}

    if not isinstance(response_data, dict):
        raise ApiException("Invalid response format")

    if response.is_error:
        if response.status_code == 410:
            newest_version = response.headers.get("X-Current-Api-Version")
            raise ApiVersionMismatchException(
                f"Unsupported api version ({API_VERSION}), use newest version ({newest_version}) "
                f"by updating rtbhouse_sdk package."
            )

        error_details = ErrorDetails(
            app_code=response_data.get("appCode", ""),
            message=response_data.get("message", ""),
            errors=response_data.get("errors"),
        )

        if response.status_code == 429:
            raise ApiRateLimitException(
                message="Resource usage limits reached",
                details=error_details,
                usage_header=response.headers.get("X-Resource-Usage"),
            )

        raise ApiRequestException(
            message=error_details.message,
            details=error_details,
        )

    current_version = response.headers.get("X-Current-Api-Version")
    if current_version is not None and current_version != API_VERSION:
        warnings.warn(
            f"Used api version ({API_VERSION}) is outdated, use newest version ({current_version}) "
            f"by updating rtbhouse_sdk package."
        )

    try:
        data = response_data["data"]
    except KeyError as exc:
        raise ApiException("Invalid response format") from exc

    return data


def _build_rtb_creatives_params(
    subcampaigns: list[str] | schema.SubcampaignsFilter | None = None,
    active_only: bool | None = None,
) -> dict[str, Any]:
    params: dict[str, Any] = {}
    if subcampaigns:
        if isinstance(subcampaigns, schema.SubcampaignsFilter):
            params["subcampaigns"] = subcampaigns.value
        elif isinstance(subcampaigns, (list, tuple, set)):
            params["subcampaigns"] = "-".join(str(sub) for sub in subcampaigns)
    if active_only is not None:
        params["activeOnly"] = active_only

    return params


def _build_rtb_stats_params(
    day_from: date,
    day_to: date,
    group_by: list[schema.StatsGroupBy],
    metrics: list[schema.StatsMetric],
    count_convention: schema.CountConvention | None = None,
    utc_offset_hours: int = 0,
    subcampaigns: list[str] | None = None,
    user_segments: list[schema.UserSegment] | None = None,
    device_types: list[schema.DeviceType] | None = None,
) -> dict[str, Any]:
    params: dict[str, Any] = {
        "dayFrom": day_from,
        "dayTo": day_to,
        "groupBy": "-".join(gb.value for gb in group_by),
        "metrics": "-".join(m.value for m in metrics),
    }
    if count_convention is not None:
        params["countConvention"] = count_convention.value
    if utc_offset_hours != 0:
        params["utcOffsetHours"] = utc_offset_hours
    if subcampaigns is not None:
        params["subcampaigns"] = "-".join(str(sub) for sub in subcampaigns)
    if user_segments is not None:
        params["userSegments"] = "-".join(us.value for us in user_segments)
    if device_types is not None:
        params["deviceTypes"] = "-".join(dt.value for dt in device_types)

    return params


def _build_summary_stats_params(
    day_from: date,
    day_to: date,
    group_by: list[schema.StatsGroupBy],
    metrics: list[schema.StatsMetric],
    count_convention: schema.CountConvention | None = None,
    utc_offset_hours: int = 0,
    subcampaigns: list[str] | None = None,
) -> dict[str, Any]:
    params: dict[str, Any] = {
        "dayFrom": day_from,
        "dayTo": day_to,
        "groupBy": "-".join(gb.value for gb in group_by),
        "metrics": "-".join(m.value for m in metrics),
    }
    if count_convention is not None:
        params["countConvention"] = count_convention.value
    if utc_offset_hours != 0:
        params["utcOffsetHours"] = utc_offset_hours
    if subcampaigns is not None:
        params["subcampaigns"] = "-".join(str(sub) for sub in subcampaigns)

    return params
