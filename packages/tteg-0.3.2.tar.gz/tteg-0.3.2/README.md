# tteg

Free stock image search for AI coding agents. No API keys, no rate limits. Just search and get URLs.

## Install

```bash
uv tool install tteg
```

Or with pip:

```bash
pip install tteg
```

## Usage

```bash
tteg "mountain sunset"
tteg "hero banner" -n 8 --orientation landscape
tteg "office workspace" --width 1920 --height 1080
tteg --version
```

## Output

```json
{
  "query": "mountain sunset",
  "results": [
    {
      "id": 1,
      "title": "A colorful sunrise from a small hill in the village of Jamnik",
      "image_url": "https://images.unsplash.com/photo-1519414442781-...",
      "thumb_url": "https://images.unsplash.com/photo-1519414442781-...&w=200"
    },
    {
      "id": 2,
      "title": "brown and black mountains under orange sky",
      "image_url": "https://images.unsplash.com/photo-1603657523988-...",
      "thumb_url": "https://images.unsplash.com/photo-1603657523988-...&w=200"
    }
  ]
}
```

## Options

| Flag | Description | Default |
|------|-------------|---------|
| `-n`, `--count` | Number of results (1-10) | 5 |
| `--orientation` | `any`, `landscape`, `portrait`, `square` | `any` |
| `--width` | Request specific width in image URL | - |
| `--height` | Request specific height in image URL | - |
| `--version` | Show version | - |

## How it works

The CLI calls a hosted API backend — no API keys needed on your machine. Images are served via Unsplash CDN URLs.

## Links

- [Website](https://kushalsm.com/tteg)
- [PyPI](https://pypi.org/project/tteg/)
