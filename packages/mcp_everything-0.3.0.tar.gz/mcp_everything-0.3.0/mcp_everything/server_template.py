"""
Template used by `mcp-everything create` to scaffold new custom servers.
The string SERVER_NAME is replaced with the actual server name at generation time.
"""

TEMPLATE = '''"""
SERVER_NAME MCP server — custom server.

Add a description of what this server does and which API it connects to.
"""

import httpx
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("SERVER_NAME")

# ── Uncomment below if your server needs an API key ───────────────────────────
# import os
#
# def _api_key() -> str:
#     key = os.environ.get("MYSERVICE_API_KEY", "")
#     if not key:
#         raise ValueError(
#             "MYSERVICE_API_KEY is not set.\\n"
#             "Get a key at https://example.com/api and run:\\n"
#             "  export MYSERVICE_API_KEY=your_key_here"
#         )
#     return key
# ──────────────────────────────────────────────────────────────────────────────


@mcp.tool()
async def SERVER_NAME_search(query: str) -> str:
    """Search MYSERVICE for results matching a query.
    Claude reads this docstring to decide when to call this tool — make it descriptive.

    Args:
        query: What to search for (e.g. \'python tutorials\', \'machine learning\')
    """
    # TODO: Replace this with your real API call
    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get(
            "https://api.example.com/search",
            params={"q": query},
            # headers={"Authorization": f"Bearer {_api_key()}"},  # uncomment if needed
        )
        r.raise_for_status()
        data = r.json()

    # TODO: Format and return your results
    results = data.get("items", [])
    if not results:
        return f"No results found for \\"{query}\\"."
    return "\\n".join(str(r) for r in results[:5])


@mcp.tool()
async def SERVER_NAME_get(item_id: str) -> str:
    """Get details for a specific item by its ID.

    Args:
        item_id: The unique identifier of the item to retrieve
    """
    # TODO: Replace with your real API call
    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get(f"https://api.example.com/items/{item_id}")
        if r.status_code == 404:
            return f"Item \\"{item_id}\\" not found."
        r.raise_for_status()
        data = r.json()

    return str(data)


if __name__ == "__main__":
    mcp.run()
'''
