"""
Live test cases for each built-in MCP server.
Used by `mcp-everything test` to verify servers are working end-to-end.
"""

import asyncio
import time
import httpx

# Each entry: (server_key, description, async_test_fn)
# test_fn returns a non-empty string on success, raises on failure.

async def _test_hackernews() -> str:
    async with httpx.AsyncClient(timeout=10) as c:
        r = await c.get("https://hacker-news.firebaseio.com/v0/topstories.json")
        r.raise_for_status()
        ids = r.json()
        assert ids and len(ids) > 0
        return f"Got {len(ids)} story IDs; top ID: {ids[0]}"


async def _test_wikipedia() -> str:
    async with httpx.AsyncClient(timeout=10, follow_redirects=True) as c:
        r = await c.get(
            "https://en.wikipedia.org/api/rest_v1/page/random/summary",
            headers={"User-Agent": "mcp-everything/0.3.0"},
        )
        r.raise_for_status()
        d = r.json()
        title = d.get("title", "?")
        assert title
        return f'Random article: "{title}"'


async def _test_arxiv() -> str:
    async with httpx.AsyncClient(timeout=15) as c:
        r = await c.get(
            "https://export.arxiv.org/api/query",
            params={"search_query": "all:AI", "max_results": 1},
        )
        r.raise_for_status()
        assert "<entry>" in r.text
        return "Fetched 1 ArXiv result"


async def _test_weather() -> str:
    async with httpx.AsyncClient(timeout=10) as c:
        r = await c.get(
            "https://geocoding-api.open-meteo.com/v1/search",
            params={"name": "London", "count": 1},
        )
        r.raise_for_status()
        d = r.json()
        loc = d["results"][0]
        return f"Geocoded: {loc['name']}, {loc['country']} ({loc['latitude']}, {loc['longitude']})"


async def _test_pokedex() -> str:
    async with httpx.AsyncClient(timeout=10) as c:
        r = await c.get("https://pokeapi.co/api/v2/pokemon/pikachu")
        r.raise_for_status()
        d = r.json()
        return f"{d['name'].title()} #{d['id']} — {len(d['moves'])} moves"


async def _test_reddit() -> str:
    async with httpx.AsyncClient(timeout=12, follow_redirects=True,
                                  headers={"User-Agent": "mcp-everything/0.3.0"}) as c:
        r = await c.get("https://www.reddit.com/r/programming/hot.json", params={"limit": 1})
        r.raise_for_status()
        posts = r.json()["data"]["children"]
        assert posts
        return f'Top post: "{posts[0]["data"]["title"][:60]}..."'


async def _test_crypto() -> str:
    async with httpx.AsyncClient(timeout=10) as c:
        r = await c.get(
            "https://api.coingecko.com/api/v3/simple/price",
            params={"ids": "bitcoin", "vs_currencies": "usd"},
            headers={"accept": "application/json"},
        )
        r.raise_for_status()
        d = r.json()
        price = d["bitcoin"]["usd"]
        return f"Bitcoin: ${price:,}"


async def _test_countries() -> str:
    async with httpx.AsyncClient(timeout=10) as c:
        r = await c.get("https://restcountries.com/v3.1/name/japan")
        r.raise_for_status()
        d = r.json()[0]
        return f"{d['flag']} {d['name']['common']} — Pop: {d['population']:,}"


async def _test_books() -> str:
    async with httpx.AsyncClient(timeout=12) as c:
        r = await c.get(
            "https://openlibrary.org/search.json",
            params={"q": "dune", "limit": 1, "fields": "title,author_name"},
        )
        r.raise_for_status()
        d = r.json()
        book = d["docs"][0]
        return f'"{book["title"]}" by {", ".join(book.get("author_name", ["?"])[:1])}'


async def _test_recipes() -> str:
    async with httpx.AsyncClient(timeout=10) as c:
        r = await c.get("https://www.themealdb.com/api/json/v1/1/random.php")
        r.raise_for_status()
        meal = r.json()["meals"][0]
        return f'Random meal: "{meal["strMeal"]}" ({meal["strCategory"]})'


async def _test_dictionary() -> str:
    async with httpx.AsyncClient(timeout=10) as c:
        r = await c.get("https://api.dictionaryapi.dev/api/v2/entries/en/serendipity")
        r.raise_for_status()
        d = r.json()[0]
        defn = d["meanings"][0]["definitions"][0]["definition"]
        return f'serendipity: "{defn[:80]}..."'


async def _test_translate() -> str:
    async with httpx.AsyncClient(timeout=12) as c:
        r = await c.get(
            "https://api.mymemory.translated.net/get",
            params={"q": "Hello, world!", "langpair": "en|fr"},
        )
        r.raise_for_status()
        translated = r.json()["responseData"]["translatedText"]
        return f'"Hello, world!" → "{translated}"'


async def _test_holidays() -> str:
    from datetime import date
    year = date.today().year
    async with httpx.AsyncClient(timeout=10) as c:
        r = await c.get(f"https://date.nager.at/api/v3/NextPublicHolidays/US")
        r.raise_for_status()
        holidays = r.json()
        assert holidays
        next_h = holidays[0]
        return f'Next US holiday: {next_h["localName"]} on {next_h["date"]}'


async def _test_github() -> str:
    import os
    headers = {"Accept": "application/vnd.github+json"}
    token = os.environ.get("GITHUB_TOKEN", "")
    if token:
        headers["Authorization"] = f"Bearer {token}"
    async with httpx.AsyncClient(timeout=10) as c:
        r = await c.get(
            "https://api.github.com/search/repositories",
            params={"q": "mcp server", "sort": "stars", "per_page": 1},
            headers=headers,
        )
        r.raise_for_status()
        items = r.json()["items"]
        return f'Top result: "{items[0]["full_name"]}" ⭐ {items[0]["stargazers_count"]:,}'


async def _test_news() -> str:
    import os
    key = os.environ.get("NEWS_API_KEY", "")
    if not key:
        raise ValueError("NEWS_API_KEY not set — skipping")
    async with httpx.AsyncClient(timeout=10) as c:
        r = await c.get(
            "https://newsapi.org/v2/top-headlines",
            params={"country": "us", "pageSize": 1, "apiKey": key},
        )
        r.raise_for_status()
        articles = r.json()["articles"]
        return f'Headline: "{articles[0]["title"][:60]}..."'


async def _test_nasa() -> str:
    import os
    key = os.environ.get("NASA_API_KEY", "DEMO_KEY")
    async with httpx.AsyncClient(timeout=12) as c:
        r = await c.get(
            "https://api.nasa.gov/planetary/apod",
            params={"api_key": key},
        )
        r.raise_for_status()
        d = r.json()
        return f'APOD: "{d["title"]}" ({d["date"]})'


async def _test_movies() -> str:
    import os
    key = os.environ.get("TMDB_API_KEY", "")
    if not key:
        raise ValueError("TMDB_API_KEY not set — skipping")
    async with httpx.AsyncClient(timeout=10) as c:
        r = await c.get(
            "https://api.themoviedb.org/3/trending/movie/week",
            params={"api_key": key},
        )
        r.raise_for_status()
        items = r.json()["results"]
        return f'Trending: "{items[0]["title"]}" ⭐ {items[0]["vote_average"]}'


async def _test_youtube() -> str:
    import os
    key = os.environ.get("YOUTUBE_API_KEY", "")
    if not key:
        raise ValueError("YOUTUBE_API_KEY not set — skipping")
    async with httpx.AsyncClient(timeout=10) as c:
        r = await c.get(
            "https://www.googleapis.com/youtube/v3/search",
            params={"key": key, "q": "claude ai", "part": "snippet", "type": "video", "maxResults": 1},
        )
        r.raise_for_status()
        items = r.json()["items"]
        return f'Video: "{items[0]["snippet"]["title"][:60]}"'


# Registry — maps server key → (description, async test function)
SERVER_TESTS: dict[str, tuple[str, object]] = {
    "hackernews":  ("HN top stories API",       _test_hackernews),
    "wikipedia":   ("Wikipedia random article",  _test_wikipedia),
    "arxiv":       ("ArXiv paper search",        _test_arxiv),
    "weather":     ("Open-Meteo geocoding",      _test_weather),
    "pokedex":     ("PokéAPI — Pikachu lookup",  _test_pokedex),
    "reddit":      ("Reddit hot posts",          _test_reddit),
    "crypto":      ("CoinGecko BTC price",       _test_crypto),
    "countries":   ("REST Countries — Japan",    _test_countries),
    "books":       ("Open Library search",       _test_books),
    "recipes":     ("TheMealDB random meal",     _test_recipes),
    "dictionary":  ("Free Dictionary API",       _test_dictionary),
    "translate":   ("MyMemory translation",      _test_translate),
    "holidays":    ("Nager.Date US holidays",    _test_holidays),
    "github":      ("GitHub repo search",        _test_github),
    "news":        ("NewsAPI headlines",         _test_news),
    "nasa":        ("NASA APOD",                 _test_nasa),
    "movies":      ("TMDB trending movies",      _test_movies),
    "youtube":     ("YouTube video search",      _test_youtube),
}


async def run_test(server_key: str) -> tuple[bool, str, float]:
    """Run the test for a single server. Returns (passed, message, elapsed_seconds)."""
    if server_key not in SERVER_TESTS:
        return False, f"No test defined for '{server_key}'", 0.0

    _, test_fn = SERVER_TESTS[server_key]
    start = time.monotonic()
    try:
        result = await test_fn()
        elapsed = time.monotonic() - start
        return True, result, elapsed
    except Exception as e:
        elapsed = time.monotonic() - start
        return False, str(e), elapsed
