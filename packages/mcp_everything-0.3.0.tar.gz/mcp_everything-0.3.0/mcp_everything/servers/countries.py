"""
Countries MCP server.
No API key required — uses the REST Countries API.
"""

import httpx
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("countries")

COUNTRIES_API = "https://restcountries.com/v3.1"


def _fmt_country(c: dict) -> str:
    name = c.get("name", {}).get("common", "Unknown")
    official = c.get("name", {}).get("official", "")
    capital = ", ".join(c.get("capital", []) or ["N/A"])
    region = c.get("region", "")
    subregion = c.get("subregion", "")
    population = c.get("population", 0)
    area = c.get("area", 0)
    currencies = ", ".join(
        f"{v.get('name', k)} ({v.get('symbol', '')})"
        for k, v in (c.get("currencies") or {}).items()
    )
    languages = ", ".join((c.get("languages") or {}).values())
    flag = c.get("flag", "")
    tld = ", ".join(c.get("tld") or [])
    timezones = ", ".join((c.get("timezones") or [])[:3])

    return (
        f"# {flag} {name}\n"
        f"**Official name:** {official}\n"
        f"**Capital:** {capital}\n"
        f"**Region:** {region} / {subregion}\n"
        f"**Population:** {population:,}\n"
        f"**Area:** {area:,.0f} km²\n"
        f"**Currency:** {currencies or 'N/A'}\n"
        f"**Languages:** {languages or 'N/A'}\n"
        f"**Top-level domain:** {tld or 'N/A'}\n"
        f"**Timezones:** {timezones}"
    )


@mcp.tool()
async def country_info(name: str) -> str:
    """Get detailed information about a country.

    Args:
        name: Country name (e.g. 'Germany', 'Japan', 'Brazil') or 2-letter code (e.g. 'DE')
    """
    async with httpx.AsyncClient(timeout=10) as client:
        # Try by name first
        r = await client.get(f"{COUNTRIES_API}/name/{name}", params={"fullText": "false"})
        if r.status_code == 404:
            # Try by code
            r = await client.get(f"{COUNTRIES_API}/alpha/{name}")
        if r.status_code == 404:
            return f"Country '{name}' not found. Try the full name or ISO 2-letter code."
        r.raise_for_status()
        data = r.json()

    return _fmt_country(data[0] if isinstance(data, list) else data)


@mcp.tool()
async def countries_by_region(region: str) -> str:
    """List all countries in a region.

    Args:
        region: Region name — 'Africa', 'Americas', 'Asia', 'Europe', 'Oceania'
    """
    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get(f"{COUNTRIES_API}/region/{region}")
        if r.status_code == 404:
            return f"Region '{region}' not found. Valid options: Africa, Americas, Asia, Europe, Oceania."
        r.raise_for_status()
        data = r.json()

    data.sort(key=lambda c: c.get("name", {}).get("common", ""))
    results = [f"**Countries in {region}** ({len(data)} total)\n"]
    for c in data:
        flag = c.get("flag", "")
        name = c.get("name", {}).get("common", "?")
        pop = c.get("population", 0)
        capital = ", ".join(c.get("capital", []) or ["N/A"])
        results.append(f"{flag} **{name}** — Capital: {capital} | Pop: {pop:,}")
    return "\n".join(results)


@mcp.tool()
async def countries_compare(country1: str, country2: str) -> str:
    """Compare two countries side by side.

    Args:
        country1: First country name or code
        country2: Second country name or code
    """
    async def fetch(name: str) -> dict | None:
        async with httpx.AsyncClient(timeout=10) as client:
            r = await client.get(f"{COUNTRIES_API}/name/{name}")
            if r.status_code != 200:
                r = await client.get(f"{COUNTRIES_API}/alpha/{name}")
            if r.status_code != 200:
                return None
            data = r.json()
            return data[0] if isinstance(data, list) else data

    c1, c2 = await fetch(country1), await fetch(country2)
    if not c1:
        return f"Country '{country1}' not found."
    if not c2:
        return f"Country '{country2}' not found."

    def val(c, key, default="N/A"):
        return c.get(key, default)

    n1 = c1["name"]["common"]
    n2 = c2["name"]["common"]

    rows = [
        ("Population", f"{val(c1,'population',0):,}", f"{val(c2,'population',0):,}"),
        ("Area (km²)", f"{val(c1,'area',0):,.0f}", f"{val(c2,'area',0):,.0f}"),
        ("Capital", ", ".join(c1.get("capital") or ["N/A"]), ", ".join(c2.get("capital") or ["N/A"])),
        ("Region", val(c1, "region"), val(c2, "region")),
        ("Languages", ", ".join((c1.get("languages") or {}).values())[:30], ", ".join((c2.get("languages") or {}).values())[:30]),
    ]

    lines = [f"**{c1.get('flag','')} {n1}** vs **{c2.get('flag','')} {n2}**\n"]
    lines.append(f"{'Metric':<15} | {n1:<20} | {n2}")
    lines.append("-" * 60)
    for label, v1, v2 in rows:
        lines.append(f"{label:<15} | {v1:<20} | {v2}")
    return "\n".join(lines)


if __name__ == "__main__":
    mcp.run()
