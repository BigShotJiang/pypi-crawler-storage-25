"""
Crypto MCP server.
No API key required — uses CoinGecko's free public API.
"""

import httpx
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("crypto")

CG_API = "https://api.coingecko.com/api/v3"
HEADERS = {"accept": "application/json"}


@mcp.tool()
async def crypto_price(coins: str, currencies: str = "usd") -> str:
    """Get current prices for one or more cryptocurrencies.

    Args:
        coins: Coin IDs separated by commas (e.g. 'bitcoin,ethereum,solana')
        currencies: Currency codes separated by commas (e.g. 'usd,eur', default 'usd')
    """
    async with httpx.AsyncClient(timeout=10, headers=HEADERS) as client:
        r = await client.get(
            f"{CG_API}/simple/price",
            params={
                "ids": coins,
                "vs_currencies": currencies,
                "include_24hr_change": "true",
                "include_market_cap": "true",
            },
        )
        r.raise_for_status()
        data = r.json()

    if not data:
        return f"No data found for '{coins}'. Try IDs like 'bitcoin', 'ethereum', 'solana'."

    results = []
    for coin_id, values in data.items():
        lines = [f"**{coin_id.title()}**"]
        for currency in currencies.split(","):
            currency = currency.strip().lower()
            price = values.get(currency)
            change = values.get(f"{currency}_24h_change")
            mcap = values.get(f"{currency}_market_cap")
            if price is not None:
                change_str = f"({'▲' if change and change > 0 else '▼'} {abs(change):.2f}%)" if change else ""
                lines.append(f"  {currency.upper()}: ${price:,.2f} {change_str}")
                if mcap:
                    lines.append(f"  Market cap: ${mcap:,.0f}")
        results.append("\n".join(lines))
    return "\n\n".join(results)


@mcp.tool()
async def crypto_trending() -> str:
    """Get the top 7 trending cryptocurrencies on CoinGecko in the last 24 hours."""
    async with httpx.AsyncClient(timeout=10, headers=HEADERS) as client:
        r = await client.get(f"{CG_API}/search/trending")
        r.raise_for_status()
        data = r.json()

    results = ["**Trending Cryptocurrencies (last 24h)**\n"]
    for item in data.get("coins", []):
        coin = item.get("item", {})
        results.append(
            f"• **{coin.get('name')}** ({coin.get('symbol')})\n"
            f"  Market cap rank: #{coin.get('market_cap_rank', '?')}\n"
            f"  CoinGecko score: {coin.get('score', '?')}"
        )
    return "\n\n".join(results)


@mcp.tool()
async def crypto_top(limit: int = 10, currency: str = "usd") -> str:
    """Get the top cryptocurrencies by market cap.

    Args:
        limit: Number of coins to return (1-50, default 10)
        currency: Price currency (e.g. 'usd', 'eur', 'gbp', default 'usd')
    """
    limit = min(max(1, limit), 50)
    async with httpx.AsyncClient(timeout=10, headers=HEADERS) as client:
        r = await client.get(
            f"{CG_API}/coins/markets",
            params={
                "vs_currency": currency,
                "order": "market_cap_desc",
                "per_page": limit,
                "page": 1,
                "price_change_percentage": "24h",
            },
        )
        r.raise_for_status()
        data = r.json()

    results = [f"**Top {limit} Cryptocurrencies by Market Cap ({currency.upper()})**\n"]
    for i, coin in enumerate(data, 1):
        change = coin.get("price_change_percentage_24h") or 0
        arrow = "▲" if change > 0 else "▼"
        results.append(
            f"{i}. **{coin['name']}** ({coin['symbol'].upper()})\n"
            f"   ${coin['current_price']:,.4f}  {arrow} {abs(change):.2f}% (24h)\n"
            f"   Market cap: ${coin['market_cap']:,.0f}"
        )
    return "\n\n".join(results)


@mcp.tool()
async def crypto_search(query: str) -> str:
    """Search for a cryptocurrency by name or ticker symbol.

    Args:
        query: Coin name or symbol to search for (e.g. 'eth', 'pepe', 'chainlink')
    """
    async with httpx.AsyncClient(timeout=10, headers=HEADERS) as client:
        r = await client.get(f"{CG_API}/search", params={"query": query})
        r.raise_for_status()
        data = r.json()

    coins = data.get("coins", [])[:8]
    if not coins:
        return f"No cryptocurrencies found for '{query}'."

    results = [f"**Search results for '{query}'**\n"]
    for coin in coins:
        rank = coin.get("market_cap_rank")
        rank_str = f"  Rank #{rank}" if rank else ""
        results.append(
            f"• **{coin['name']}** ({coin['symbol'].upper()}) — ID: `{coin['id']}`{rank_str}"
        )
    results.append(f"\n_Use the ID (e.g. `{coins[0]['id']}`) with crypto_price_")
    return "\n".join(results)


if __name__ == "__main__":
    mcp.run()
