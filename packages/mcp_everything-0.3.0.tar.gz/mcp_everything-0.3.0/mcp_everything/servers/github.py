"""
GitHub MCP server.
Requires a GitHub Personal Access Token (free at github.com/settings/tokens).
Set GITHUB_TOKEN in your environment or .env file.
"""

import os
import httpx
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("github")

GH_API = "https://api.github.com"


def _headers() -> dict:
    token = os.environ.get("GITHUB_TOKEN", "")
    headers = {"Accept": "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    return headers


async def _get(path: str, params: dict | None = None) -> dict | list:
    async with httpx.AsyncClient(timeout=15) as client:
        r = await client.get(f"{GH_API}{path}", headers=_headers(), params=params or {})
        if r.status_code == 401:
            raise ValueError("Invalid GitHub token. Check your GITHUB_TOKEN environment variable.")
        if r.status_code == 403:
            raise ValueError("Rate limit hit. Add a GITHUB_TOKEN to get 5000 requests/hour.")
        r.raise_for_status()
        return r.json()


@mcp.tool()
async def github_search_repos(query: str, limit: int = 5, sort: str = "stars") -> str:
    """Search GitHub repositories.

    Args:
        query: Search terms (e.g. 'machine learning python', 'react dashboard')
        limit: Number of results (1-20, default 5)
        sort: Sort by 'stars', 'forks', or 'updated' (default 'stars')
    """
    limit = min(max(1, limit), 20)
    sort = sort if sort in ("stars", "forks", "updated") else "stars"
    data = await _get("/search/repositories", {"q": query, "sort": sort, "per_page": limit})
    repos = data.get("items", [])
    if not repos:
        return f"No repositories found for '{query}'."

    results = []
    for r in repos:
        results.append(
            f"**[{r['full_name']}]({r['html_url']})**\n"
            f"{r.get('description') or 'No description'}\n"
            f"⭐ {r['stargazers_count']:,}  🍴 {r['forks_count']:,}  "
            f"📝 {r.get('language') or 'N/A'}  🔄 {r['updated_at'][:10]}"
        )
    return "\n\n---\n\n".join(results)


@mcp.tool()
async def github_get_repo(owner: str, repo: str) -> str:
    """Get details about a specific GitHub repository.

    Args:
        owner: Repository owner (username or org, e.g. 'microsoft')
        repo: Repository name (e.g. 'vscode')
    """
    data = await _get(f"/repos/{owner}/{repo}")
    topics = ", ".join(data.get("topics", [])[:8]) or "none"
    return (
        f"# {data['full_name']}\n\n"
        f"{data.get('description') or 'No description'}\n\n"
        f"⭐ Stars: {data['stargazers_count']:,}\n"
        f"🍴 Forks: {data['forks_count']:,}\n"
        f"👁️ Watchers: {data['watchers_count']:,}\n"
        f"📝 Language: {data.get('language') or 'N/A'}\n"
        f"🏷️ Topics: {topics}\n"
        f"📅 Created: {data['created_at'][:10]}\n"
        f"🔄 Updated: {data['updated_at'][:10]}\n"
        f"🔗 {data['html_url']}"
    )


@mcp.tool()
async def github_list_issues(owner: str, repo: str, state: str = "open", limit: int = 10) -> str:
    """List issues for a GitHub repository.

    Args:
        owner: Repository owner (e.g. 'anthropics')
        repo: Repository name (e.g. 'anthropic-sdk-python')
        state: 'open', 'closed', or 'all' (default 'open')
        limit: Number of issues (1-30, default 10)
    """
    limit = min(max(1, limit), 30)
    state = state if state in ("open", "closed", "all") else "open"
    data = await _get(f"/repos/{owner}/{repo}/issues", {"state": state, "per_page": limit})
    issues = [i for i in data if "pull_request" not in i][:limit]
    if not issues:
        return f"No {state} issues found for {owner}/{repo}."

    results = [f"**{state.title()} Issues in {owner}/{repo}**\n"]
    for issue in issues:
        labels = ", ".join(l["name"] for l in issue.get("labels", [])[:3])
        label_str = f"  🏷️ {labels}" if labels else ""
        results.append(
            f"• #{issue['number']}: **{issue['title']}**{label_str}\n"
            f"  Opened by @{issue['user']['login']} on {issue['created_at'][:10]}"
        )
    return "\n\n".join(results)


@mcp.tool()
async def github_search_code(query: str, limit: int = 5) -> str:
    """Search code across GitHub — great for finding usage examples.
    Note: Requires GITHUB_TOKEN for this endpoint.

    Args:
        query: Code search query (e.g. 'FastMCP tool language:python', 'useState react')
        limit: Number of results (1-10, default 5)
    """
    limit = min(max(1, limit), 10)
    data = await _get("/search/code", {"q": query, "per_page": limit})
    items = data.get("items", [])
    if not items:
        return f"No code results for '{query}'."

    results = []
    for item in items:
        results.append(
            f"**{item['repository']['full_name']}** → `{item['path']}`\n"
            f"{item['html_url']}"
        )
    return "\n\n".join(results)


@mcp.tool()
async def github_trending(language: str = "", since: str = "daily") -> str:
    """Get trending GitHub repositories (scraped from github.com/trending).
    Fallback: searches for recently-starred repos in the given language.

    Args:
        language: Programming language filter (e.g. 'python', 'typescript', '' for all)
        since: 'daily', 'weekly', or 'monthly' (default 'daily')
    """
    # GitHub doesn't have an official trending API; use search as proxy
    q = "stars:>100"
    if language:
        q += f" language:{language}"
    data = await _get("/search/repositories", {
        "q": q,
        "sort": "stars",
        "order": "desc",
        "per_page": 10,
    })
    repos = data.get("items", [])
    lang_label = f" ({language})" if language else ""
    results = [f"**Trending Repos on GitHub{lang_label}**\n"]
    for r in repos:
        results.append(
            f"• **[{r['full_name']}]({r['html_url']})** ⭐ {r['stargazers_count']:,}\n"
            f"  {r.get('description') or 'No description'}"
        )
    return "\n\n".join(results)


if __name__ == "__main__":
    mcp.run()
