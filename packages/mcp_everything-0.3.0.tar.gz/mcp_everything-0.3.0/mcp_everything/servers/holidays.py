"""
Public Holidays MCP server.
No API key required — uses Nager.Date free API.
"""

import httpx
from datetime import date
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("holidays")

NAGER_API = "https://date.nager.at/api/v3"


@mcp.tool()
async def holidays_upcoming(country_code: str = "US", year: int | None = None) -> str:
    """Get public holidays for a country in a given year.

    Args:
        country_code: ISO 2-letter country code (e.g. 'US', 'GB', 'DE', 'JP', 'AU', 'FR')
        year: Year to get holidays for (default: current year)
    """
    year = year or date.today().year
    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get(f"{NAGER_API}/PublicHolidays/{year}/{country_code.upper()}")
        if r.status_code == 404:
            return f"No holiday data for country code '{country_code}'. Try codes like US, GB, DE, JP, AU, FR, CA."
        r.raise_for_status()
        data = r.json()

    if not data:
        return f"No public holidays found for {country_code} in {year}."

    today = date.today()
    results = [f"**Public Holidays in {country_code.upper()} ({year})**\n"]
    for h in data:
        holiday_date = date.fromisoformat(h["date"])
        is_past = holiday_date < today
        marker = "✓" if is_past else "→" if holiday_date >= today else ""
        name = h.get("localName") or h.get("name", "")
        global_name = h.get("name", "")
        name_str = f"{name}" + (f" ({global_name})" if global_name != name else "")
        types = ", ".join(h.get("types", []))
        results.append(f"{marker} **{h['date']}** — {name_str} _{types}_")
    return "\n".join(results)


@mcp.tool()
async def holidays_next(country_code: str = "US") -> str:
    """Find the next upcoming public holiday for a country.

    Args:
        country_code: ISO 2-letter country code (e.g. 'US', 'GB', 'DE', default 'US')
    """
    today = date.today()
    year = today.year

    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get(f"{NAGER_API}/NextPublicHolidays/{country_code.upper()}")
        if r.status_code == 404:
            return f"No holiday data found for '{country_code}'."
        r.raise_for_status()
        data = r.json()

    if not data:
        return f"No upcoming holidays found for {country_code}."

    results = [f"**Upcoming Public Holidays in {country_code.upper()}**\n"]
    for h in data[:5]:
        holiday_date = date.fromisoformat(h["date"])
        days_away = (holiday_date - today).days
        name = h.get("localName") or h.get("name", "")
        results.append(f"• **{h['date']}** — {name} _(in {days_away} days)_")
    return "\n".join(results)


@mcp.tool()
async def holidays_countries() -> str:
    """List all countries with available public holiday data."""
    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get(f"{NAGER_API}/AvailableCountries")
        r.raise_for_status()
        data = r.json()

    results = [f"**Countries with Holiday Data** ({len(data)} countries)\n"]
    for country in sorted(data, key=lambda c: c.get("name", "")):
        results.append(f"  `{country.get('countryCode')}` — {country.get('name')}")
    return "\n".join(results)


if __name__ == "__main__":
    mcp.run()
