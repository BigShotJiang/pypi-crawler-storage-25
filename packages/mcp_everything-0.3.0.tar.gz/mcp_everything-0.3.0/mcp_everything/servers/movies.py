"""
Movies & TV MCP server.
Free API key at: https://www.themoviedb.org/settings/api
Set TMDB_API_KEY in your environment.
"""

import os
import httpx
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("movies")

TMDB_API = "https://api.themoviedb.org/3"
IMG_BASE = "https://image.tmdb.org/t/p/w500"


def _key() -> str:
    key = os.environ.get("TMDB_API_KEY", "")
    if not key:
        raise ValueError(
            "TMDB_API_KEY not set. Get a free key at https://www.themoviedb.org/settings/api\n"
            "Then: export TMDB_API_KEY=your_key_here"
        )
    return key


async def _get(path: str, params: dict | None = None) -> dict:
    async with httpx.AsyncClient(timeout=12) as client:
        r = await client.get(
            f"{TMDB_API}{path}",
            params={"api_key": _key(), **(params or {})},
        )
        r.raise_for_status()
        return r.json()


def _fmt_movie(m: dict) -> str:
    title = m.get("title") or m.get("name", "Unknown")
    date = m.get("release_date") or m.get("first_air_date", "?")
    year = date[:4] if date else "?"
    rating = m.get("vote_average", 0)
    votes = m.get("vote_count", 0)
    overview = m.get("overview", "No overview available.")
    poster = IMG_BASE + m["poster_path"] if m.get("poster_path") else ""
    genres = ", ".join(g["name"] for g in m.get("genres", []))
    runtime = m.get("runtime", "")
    runtime_str = f"{runtime} min" if runtime else ""
    tagline = m.get("tagline", "")

    lines = [
        f"# {title} ({year})",
        f"*{tagline}*" if tagline else "",
        f"⭐ {rating:.1f}/10 ({votes:,} votes){' | ' + runtime_str if runtime_str else ''}",
        f"**Genres:** {genres}" if genres else "",
        "",
        overview,
        f"\n🖼️ {poster}" if poster else "",
    ]
    return "\n".join(l for l in lines if l is not None)


@mcp.tool()
async def movies_search(query: str, limit: int = 5, media_type: str = "movie") -> str:
    """Search for movies or TV shows.

    Args:
        query: Title or keywords to search for (e.g. 'inception', 'breaking bad', 'dune')
        limit: Number of results (1-20, default 5)
        media_type: 'movie' or 'tv' (default 'movie')
    """
    limit = min(max(1, limit), 20)
    media_type = "tv" if media_type.lower() in ("tv", "show", "series") else "movie"
    data = await _get(f"/search/{media_type}", {"query": query, "page": 1})

    results_list = data.get("results", [])[:limit]
    if not results_list:
        return f"No {media_type} results for '{query}'."

    total = data.get("total_results", 0)
    label = "Movies" if media_type == "movie" else "TV Shows"
    results = [f"**{label} matching '{query}'** ({total:,} total)\n"]
    for m in results_list:
        title = m.get("title") or m.get("name", "Unknown")
        date = m.get("release_date") or m.get("first_air_date", "")
        year = date[:4] if date else "?"
        rating = m.get("vote_average", 0)
        overview = (m.get("overview") or "")[:120]
        results.append(
            f"**{title}** ({year}) ⭐ {rating:.1f}\n"
            f"  {overview}{'...' if len(m.get('overview','')) > 120 else ''}"
        )
    return "\n\n".join(results)


@mcp.tool()
async def movies_trending(media_type: str = "movie", time_window: str = "week") -> str:
    """Get trending movies or TV shows.

    Args:
        media_type: 'movie', 'tv', or 'all' (default 'movie')
        time_window: 'day' or 'week' (default 'week')
    """
    media_type = media_type if media_type in ("movie", "tv", "all") else "movie"
    time_window = "week" if time_window not in ("day", "week") else time_window
    data = await _get(f"/trending/{media_type}/{time_window}")

    results_list = data.get("results", [])[:10]
    label = {"movie": "Movies", "tv": "TV Shows", "all": "Movies & TV"}[media_type]
    results = [f"**Trending {label} this {time_window.title()}**\n"]
    for i, m in enumerate(results_list, 1):
        title = m.get("title") or m.get("name", "Unknown")
        date = m.get("release_date") or m.get("first_air_date", "")
        year = date[:4] if date else "?"
        rating = m.get("vote_average", 0)
        media = m.get("media_type", media_type)
        results.append(f"{i}. **{title}** ({year}) ⭐ {rating:.1f} [{media}]")
    return "\n".join(results)


@mcp.tool()
async def movies_details(movie_id: int, media_type: str = "movie") -> str:
    """Get full details for a specific movie or TV show by TMDB ID.

    Args:
        movie_id: The TMDB ID of the movie/show (found in search results)
        media_type: 'movie' or 'tv' (default 'movie')
    """
    media_type = "tv" if media_type.lower() in ("tv", "show", "series") else "movie"
    data = await _get(f"/{media_type}/{movie_id}")
    return _fmt_movie(data)


@mcp.tool()
async def movies_top_rated(media_type: str = "movie", limit: int = 10) -> str:
    """Get all-time top rated movies or TV shows on TMDB.

    Args:
        media_type: 'movie' or 'tv' (default 'movie')
        limit: Number of results (1-20, default 10)
    """
    limit = min(max(1, limit), 20)
    media_type = "tv" if media_type.lower() in ("tv", "show", "series") else "movie"
    data = await _get(f"/{media_type}/top_rated")

    results_list = data.get("results", [])[:limit]
    label = "Movies" if media_type == "movie" else "TV Shows"
    results = [f"**Top Rated {label} (TMDB)**\n"]
    for i, m in enumerate(results_list, 1):
        title = m.get("title") or m.get("name", "Unknown")
        date = m.get("release_date") or m.get("first_air_date", "")
        year = date[:4] if date else "?"
        rating = m.get("vote_average", 0)
        votes = m.get("vote_count", 0)
        results.append(f"{i}. **{title}** ({year}) ⭐ {rating:.1f}/10 ({votes:,} votes)")
    return "\n".join(results)


if __name__ == "__main__":
    mcp.run()
