"""
Pokédex MCP server.
No API key required — uses the free PokéAPI.
A fun server that also demonstrates how clean MCP tools look.
"""

import httpx
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("pokedex")

POKE_API = "https://pokeapi.co/api/v2"


@mcp.tool()
async def pokedex_get(name_or_id: str) -> str:
    """Look up a Pokémon by name or Pokédex number.

    Args:
        name_or_id: Pokémon name (e.g. 'pikachu') or number (e.g. '25')
    """
    query = str(name_or_id).lower().strip()
    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get(f"{POKE_API}/pokemon/{query}")
        if r.status_code == 404:
            return f"Pokémon '{name_or_id}' not found. Try a name like 'pikachu' or a number like '25'."
        r.raise_for_status()
        data = r.json()

    name = data["name"].capitalize()
    number = data["id"]
    types = " / ".join(t["type"]["name"].capitalize() for t in data["types"])
    height = data["height"] / 10
    weight = data["weight"] / 10
    stats = {s["stat"]["name"]: s["base_stat"] for s in data["stats"]}
    abilities = ", ".join(a["ability"]["name"].replace("-", " ").title() for a in data["abilities"])
    sprite = data.get("sprites", {}).get("front_default", "")

    stat_lines = "\n".join(
        f"  {k.replace('-', ' ').title()}: {v}" for k, v in stats.items()
    )

    return (
        f"# {name} (#{number:03d})\n\n"
        f"**Type:** {types}\n"
        f"**Height:** {height} m  |  **Weight:** {weight} kg\n"
        f"**Abilities:** {abilities}\n\n"
        f"**Base Stats:**\n{stat_lines}\n\n"
        f"{'🖼️ ' + sprite if sprite else ''}"
    )


@mcp.tool()
async def pokedex_move(move_name: str) -> str:
    """Get details about a Pokémon move.

    Args:
        move_name: Move name (e.g. 'thunderbolt', 'flamethrower', 'surf')
    """
    query = move_name.lower().strip().replace(" ", "-")
    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get(f"{POKE_API}/move/{query}")
        if r.status_code == 404:
            return f"Move '{move_name}' not found."
        r.raise_for_status()
        data = r.json()

    name = data["name"].replace("-", " ").title()
    move_type = data["type"]["name"].capitalize()
    power = data.get("power") or "—"
    accuracy = data.get("accuracy") or "—"
    pp = data.get("pp") or "—"
    damage_class = data.get("damage_class", {}).get("name", "unknown").capitalize()
    flavor = ""
    for entry in data.get("flavor_text_entries", []):
        if entry.get("language", {}).get("name") == "en":
            flavor = entry.get("flavor_text", "").replace("\n", " ").replace("\x0c", " ")
            break

    return (
        f"# {name}\n\n"
        f"**Type:** {move_type}  |  **Category:** {damage_class}\n"
        f"**Power:** {power}  |  **Accuracy:** {accuracy}%  |  **PP:** {pp}\n\n"
        f"_{flavor}_"
    )


@mcp.tool()
async def pokedex_type_matchup(type_name: str) -> str:
    """Get type effectiveness for a given Pokémon type — useful for battle strategy.

    Args:
        type_name: Pokémon type (e.g. 'fire', 'water', 'dragon', 'ghost')
    """
    query = type_name.lower().strip()
    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get(f"{POKE_API}/type/{query}")
        if r.status_code == 404:
            return f"Type '{type_name}' not found. Valid types: fire, water, grass, electric, etc."
        r.raise_for_status()
        data = r.json()

    dmg = data.get("damage_relations", {})
    double_to = [t["name"] for t in dmg.get("double_damage_to", [])]
    half_to = [t["name"] for t in dmg.get("half_damage_to", [])]
    no_to = [t["name"] for t in dmg.get("no_damage_to", [])]
    double_from = [t["name"] for t in dmg.get("double_damage_from", [])]
    half_from = [t["name"] for t in dmg.get("half_damage_from", [])]
    no_from = [t["name"] for t in dmg.get("no_damage_from", [])]

    def fmt(lst):
        return ", ".join(t.capitalize() for t in lst) if lst else "none"

    return (
        f"# {type_name.capitalize()} Type Matchups\n\n"
        f"**Attacking:**\n"
        f"  2× damage to: {fmt(double_to)}\n"
        f"  ½× damage to: {fmt(half_to)}\n"
        f"  0× damage to: {fmt(no_to)}\n\n"
        f"**Defending:**\n"
        f"  2× damage from: {fmt(double_from)}\n"
        f"  ½× damage from: {fmt(half_from)}\n"
        f"  0× damage from: {fmt(no_from)}"
    )


if __name__ == "__main__":
    mcp.run()
