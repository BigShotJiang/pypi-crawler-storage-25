"""
Weather MCP server.
No API key required — uses Open-Meteo (free, no registration).
Geocoding via Open-Meteo's free geocoding API.
"""

import httpx
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("weather")

GEO_API = "https://geocoding-api.open-meteo.com/v1/search"
WEATHER_API = "https://api.open-meteo.com/v1/forecast"

WMO_CODES = {
    0: "Clear sky", 1: "Mainly clear", 2: "Partly cloudy", 3: "Overcast",
    45: "Foggy", 48: "Icy fog", 51: "Light drizzle", 53: "Moderate drizzle",
    55: "Dense drizzle", 61: "Slight rain", 63: "Moderate rain", 65: "Heavy rain",
    71: "Slight snow", 73: "Moderate snow", 75: "Heavy snow", 77: "Snow grains",
    80: "Slight showers", 81: "Moderate showers", 82: "Violent showers",
    85: "Slight snow showers", 86: "Heavy snow showers",
    95: "Thunderstorm", 96: "Thunderstorm with hail", 99: "Heavy thunderstorm with hail",
}


async def _geocode(location: str) -> tuple[float, float, str]:
    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get(GEO_API, params={"name": location, "count": 1, "language": "en", "format": "json"})
        r.raise_for_status()
        data = r.json()
    results = data.get("results")
    if not results:
        raise ValueError(f"Location '{location}' not found. Try a city name like 'London' or 'New York'.")
    first = results[0]
    name = f"{first.get('name')}, {first.get('country', '')}"
    return first["latitude"], first["longitude"], name


@mcp.tool()
async def weather_current(location: str) -> str:
    """Get the current weather for any city or location.

    Args:
        location: City name (e.g. 'London', 'Tokyo', 'New York')
    """
    lat, lon, name = await _geocode(location)
    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get(
            WEATHER_API,
            params={
                "latitude": lat,
                "longitude": lon,
                "current": "temperature_2m,relative_humidity_2m,wind_speed_10m,weathercode,apparent_temperature",
                "temperature_unit": "celsius",
                "wind_speed_unit": "kmh",
                "timezone": "auto",
            },
        )
        r.raise_for_status()
        data = r.json()

    curr = data.get("current", {})
    code = curr.get("weathercode", 0)
    condition = WMO_CODES.get(code, "Unknown")
    temp = curr.get("temperature_2m")
    feels_like = curr.get("apparent_temperature")
    humidity = curr.get("relative_humidity_2m")
    wind = curr.get("wind_speed_10m")

    return (
        f"**Weather in {name}**\n\n"
        f"🌡️ Temperature: {temp}°C (feels like {feels_like}°C)\n"
        f"☁️ Condition: {condition}\n"
        f"💧 Humidity: {humidity}%\n"
        f"💨 Wind: {wind} km/h"
    )


@mcp.tool()
async def weather_forecast(location: str, days: int = 7) -> str:
    """Get a multi-day weather forecast for any city or location.

    Args:
        location: City name (e.g. 'Paris', 'Sydney', 'Chicago')
        days: Number of days to forecast (1-14, default 7)
    """
    days = min(max(1, days), 14)
    lat, lon, name = await _geocode(location)
    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get(
            WEATHER_API,
            params={
                "latitude": lat,
                "longitude": lon,
                "daily": "temperature_2m_max,temperature_2m_min,weathercode,precipitation_probability_max",
                "temperature_unit": "celsius",
                "timezone": "auto",
                "forecast_days": days,
            },
        )
        r.raise_for_status()
        data = r.json()

    daily = data.get("daily", {})
    dates = daily.get("time", [])
    highs = daily.get("temperature_2m_max", [])
    lows = daily.get("temperature_2m_min", [])
    codes = daily.get("weathercode", [])
    precip = daily.get("precipitation_probability_max", [])

    lines = [f"**{days}-Day Forecast for {name}**\n"]
    for i in range(len(dates)):
        condition = WMO_CODES.get(codes[i] if i < len(codes) else 0, "Unknown")
        rain = precip[i] if i < len(precip) else "?"
        lines.append(
            f"**{dates[i]}** — {condition}\n"
            f"  ↑ {highs[i]}°C  ↓ {lows[i]}°C  🌧 {rain}% rain chance"
        )
    return "\n\n".join(lines)


if __name__ == "__main__":
    mcp.run()
