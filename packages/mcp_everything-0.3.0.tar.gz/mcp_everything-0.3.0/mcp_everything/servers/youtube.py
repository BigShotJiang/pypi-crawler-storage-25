"""
YouTube MCP server.
Free API key at: https://console.cloud.google.com → Enable YouTube Data API v3
Set YOUTUBE_API_KEY in your environment.
Free tier: 10,000 quota units/day (search = 100 units, so ~100 searches/day free).
"""

import os
import httpx
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("youtube")

YT_API = "https://www.googleapis.com/youtube/v3"


def _key() -> str:
    key = os.environ.get("YOUTUBE_API_KEY", "")
    if not key:
        raise ValueError(
            "YOUTUBE_API_KEY not set.\n"
            "1. Go to https://console.cloud.google.com\n"
            "2. Create a project → Enable 'YouTube Data API v3'\n"
            "3. Create credentials → API key\n"
            "Then: export YOUTUBE_API_KEY=your_key_here"
        )
    return key


@mcp.tool()
async def youtube_search(query: str, limit: int = 5, video_type: str = "video") -> str:
    """Search YouTube for videos, channels, or playlists.

    Args:
        query: Search terms (e.g. 'python tutorial', 'lofi hip hop', 'how to make pasta')
        limit: Number of results (1-25, default 5)
        video_type: 'video', 'channel', or 'playlist' (default 'video')
    """
    limit = min(max(1, limit), 25)
    video_type = video_type if video_type in ("video", "channel", "playlist") else "video"

    async with httpx.AsyncClient(timeout=12) as client:
        r = await client.get(
            f"{YT_API}/search",
            params={
                "key": _key(),
                "q": query,
                "part": "snippet",
                "type": video_type,
                "maxResults": limit,
            },
        )
        r.raise_for_status()
        data = r.json()

    items = data.get("items", [])
    if not items:
        return f"No YouTube results for '{query}'."

    results = [f"**YouTube search: '{query}'**\n"]
    for item in items:
        snippet = item.get("snippet", {})
        title = snippet.get("title", "Untitled")
        channel = snippet.get("channelTitle", "")
        description = snippet.get("description", "")[:100]
        published = snippet.get("publishedAt", "")[:10]
        kind = item.get("id", {})

        if video_type == "video":
            vid_id = kind.get("videoId", "")
            url = f"https://www.youtube.com/watch?v={vid_id}"
        elif video_type == "channel":
            channel_id = kind.get("channelId", "")
            url = f"https://www.youtube.com/channel/{channel_id}"
        else:
            playlist_id = kind.get("playlistId", "")
            url = f"https://www.youtube.com/playlist?list={playlist_id}"

        results.append(
            f"**{title}**\n"
            f"  📺 {channel} · {published}\n"
            f"  {description}{'...' if description else ''}\n"
            f"  {url}"
        )
    return "\n\n".join(results)


@mcp.tool()
async def youtube_video_details(video_id_or_url: str) -> str:
    """Get detailed stats and metadata for a specific YouTube video.

    Args:
        video_id_or_url: YouTube video ID (e.g. 'dQw4w9WgXcQ') or full URL
    """
    # Extract ID from URL if needed
    vid = video_id_or_url.strip()
    if "youtube.com/watch?v=" in vid:
        vid = vid.split("v=")[1].split("&")[0]
    elif "youtu.be/" in vid:
        vid = vid.split("youtu.be/")[1].split("?")[0]

    async with httpx.AsyncClient(timeout=12) as client:
        r = await client.get(
            f"{YT_API}/videos",
            params={
                "key": _key(),
                "id": vid,
                "part": "snippet,statistics,contentDetails",
            },
        )
        r.raise_for_status()
        data = r.json()

    items = data.get("items", [])
    if not items:
        return f"Video '{video_id_or_url}' not found."

    item = items[0]
    snippet = item.get("snippet", {})
    stats = item.get("statistics", {})
    content = item.get("contentDetails", {})

    title = snippet.get("title", "Untitled")
    channel = snippet.get("channelTitle", "")
    published = snippet.get("publishedAt", "")[:10]
    description = snippet.get("description", "")[:300]
    views = int(stats.get("viewCount", 0))
    likes = int(stats.get("likeCount", 0))
    comments = int(stats.get("commentCount", 0))
    duration = content.get("duration", "").replace("PT", "").replace("H", "h ").replace("M", "m ").replace("S", "s")

    return (
        f"# {title}\n\n"
        f"**Channel:** {channel}\n"
        f"**Published:** {published}  |  **Duration:** {duration}\n"
        f"👁️ {views:,} views  |  👍 {likes:,} likes  |  💬 {comments:,} comments\n\n"
        f"{description}{'...' if len(snippet.get('description','')) > 300 else ''}\n\n"
        f"https://www.youtube.com/watch?v={vid}"
    )


@mcp.tool()
async def youtube_trending(region_code: str = "US", category: str = "") -> str:
    """Get trending videos on YouTube in a region.

    Args:
        region_code: 2-letter country code (e.g. 'US', 'GB', 'JP', 'DE', default 'US')
        category: Optional video category ID — '' for all, '10' for Music, '20' for Gaming, '25' for News, '28' for Tech
    """
    params: dict = {
        "key": _key(),
        "part": "snippet,statistics",
        "chart": "mostPopular",
        "regionCode": region_code.upper(),
        "maxResults": 10,
    }
    if category:
        params["videoCategoryId"] = category

    async with httpx.AsyncClient(timeout=12) as client:
        r = await client.get(f"{YT_API}/videos", params=params)
        r.raise_for_status()
        data = r.json()

    items = data.get("items", [])
    if not items:
        return f"No trending videos found for region '{region_code}'."

    results = [f"**Trending on YouTube ({region_code.upper()})**\n"]
    for i, item in enumerate(items, 1):
        snippet = item.get("snippet", {})
        stats = item.get("statistics", {})
        title = snippet.get("title", "Untitled")
        channel = snippet.get("channelTitle", "")
        views = int(stats.get("viewCount", 0))
        vid_id = item.get("id", "")
        results.append(
            f"{i}. **{title}**\n"
            f"   📺 {channel}  |  👁️ {views:,} views\n"
            f"   https://www.youtube.com/watch?v={vid_id}"
        )
    return "\n\n".join(results)


if __name__ == "__main__":
    mcp.run()
