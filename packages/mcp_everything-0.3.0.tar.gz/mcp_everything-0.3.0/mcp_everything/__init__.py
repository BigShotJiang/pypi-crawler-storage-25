"""
mcp-everything — plug-and-play MCP servers for Claude.
"""

__version__ = "0.3.0"
