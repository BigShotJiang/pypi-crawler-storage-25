"""Allow `python -m mcp_everything` to run the CLI."""
from mcp_everything.cli import main

if __name__ == "__main__":
    main()
