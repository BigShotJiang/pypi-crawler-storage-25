"""
Utilities for locating and updating the Claude Desktop MCP config file.
"""

import json
import os
import platform
import sys
from pathlib import Path


def get_claude_config_path() -> Path | None:
    """Locate the Claude Desktop config file for the current OS."""
    system = platform.system()
    if system == "Darwin":  # macOS
        return Path.home() / "Library" / "Application Support" / "Claude" / "claude_desktop_config.json"
    elif system == "Windows":
        appdata = os.environ.get("APPDATA", "")
        if appdata:
            return Path(appdata) / "Claude" / "claude_desktop_config.json"
    elif system == "Linux":
        return Path.home() / ".config" / "Claude" / "claude_desktop_config.json"
    return None


def load_config(path: Path) -> dict:
    """Load existing Claude Desktop config, or return empty config."""
    if path.exists():
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            return {}
    return {}


def save_config(path: Path, config: dict) -> None:
    """Write config to disk, creating parent directories if needed."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(config, indent=2), encoding="utf-8")


def python_executable() -> str:
    """Return the absolute path to the current Python interpreter."""
    return sys.executable


def build_server_entry(server_module: str, env_vars: dict[str, str] | None = None) -> dict:
    """Build a claude_desktop_config.json server entry for an mcp_everything server."""
    entry: dict = {
        "command": python_executable(),
        "args": ["-m", f"mcp_everything.servers.{server_module}"],
    }
    if env_vars:
        entry["env"] = env_vars
    return entry


SERVERS: list[dict] = [
    {
        "key": "hackernews",
        "module": "hackernews",
        "label": "Hacker News",
        "description": "Search stories, get hot posts, read comments",
        "needs_key": False,
        "env_vars": [],
    },
    {
        "key": "wikipedia",
        "module": "wikipedia",
        "label": "Wikipedia",
        "description": "Search & summarise articles, On This Day",
        "needs_key": False,
        "env_vars": [],
    },
    {
        "key": "arxiv",
        "module": "arxiv",
        "label": "ArXiv",
        "description": "Search academic papers, recent publications",
        "needs_key": False,
        "env_vars": [],
    },
    {
        "key": "weather",
        "module": "weather",
        "label": "Weather",
        "description": "Current weather & forecasts for any city (Open-Meteo)",
        "needs_key": False,
        "env_vars": [],
    },
    {
        "key": "pokedex",
        "module": "pokedex",
        "label": "Pokédex",
        "description": "Pokémon stats, moves, and type matchups (via PokéAPI)",
        "needs_key": False,
        "env_vars": [],
    },
    {
        "key": "reddit",
        "module": "reddit",
        "label": "Reddit",
        "description": "Browse hot/top posts, search Reddit",
        "needs_key": False,
        "env_vars": [],
    },
    {
        "key": "github",
        "module": "github",
        "label": "GitHub",
        "description": "Search repos, list issues, search code",
        "needs_key": True,
        "env_vars": [
            {
                "name": "GITHUB_TOKEN",
                "prompt": "GitHub Personal Access Token",
                "hint": "Create one at github.com/settings/tokens (read-only public access is enough)",
                "required": False,
            }
        ],
    },
    {
        "key": "news",
        "module": "news",
        "label": "News (NewsAPI)",
        "description": "Top headlines & article search (newsapi.org)",
        "needs_key": True,
        "env_vars": [
            {
                "name": "NEWS_API_KEY",
                "prompt": "NewsAPI Key",
                "hint": "Free key at newsapi.org/register (100 req/day on free tier)",
                "required": True,
            }
        ],
    },
    # ── New in v0.2.0 ─────────────────────────────────────────────────────────
    {
        "key": "crypto",
        "module": "crypto",
        "label": "Crypto (CoinGecko)",
        "description": "Live prices, trending coins, top market caps",
        "needs_key": False,
        "env_vars": [],
    },
    {
        "key": "countries",
        "module": "countries",
        "label": "Countries",
        "description": "Country info, region lists, side-by-side comparisons",
        "needs_key": False,
        "env_vars": [],
    },
    {
        "key": "books",
        "module": "books",
        "label": "Books (Open Library)",
        "description": "Search books, look up authors, ISBN lookup, trending",
        "needs_key": False,
        "env_vars": [],
    },
    {
        "key": "recipes",
        "module": "recipes",
        "label": "Recipes (TheMealDB)",
        "description": "Search recipes, random meals, browse by category",
        "needs_key": False,
        "env_vars": [],
    },
    {
        "key": "dictionary",
        "module": "dictionary",
        "label": "Dictionary",
        "description": "Word definitions, phonetics, synonyms, antonyms",
        "needs_key": False,
        "env_vars": [],
    },
    {
        "key": "translate",
        "module": "translate",
        "label": "Translate",
        "description": "Translate text between 60+ languages (MyMemory)",
        "needs_key": False,
        "env_vars": [],
    },
    {
        "key": "holidays",
        "module": "holidays",
        "label": "Public Holidays",
        "description": "Public holidays by country, next upcoming holiday",
        "needs_key": False,
        "env_vars": [],
    },
    {
        "key": "nasa",
        "module": "nasa",
        "label": "NASA",
        "description": "Astronomy Picture of the Day, Near-Earth Objects, Mars rover photos",
        "needs_key": True,
        "env_vars": [
            {
                "name": "NASA_API_KEY",
                "prompt": "NASA API Key",
                "hint": "Free instant key at api.nasa.gov — no credit card needed. Without a key, DEMO_KEY is used (30 req/hr).",
                "required": False,
            }
        ],
    },
    {
        "key": "movies",
        "module": "movies",
        "label": "Movies & TV (TMDB)",
        "description": "Search movies/TV, trending, top rated, full details",
        "needs_key": True,
        "env_vars": [
            {
                "name": "TMDB_API_KEY",
                "prompt": "TMDB API Key",
                "hint": "Free key at themoviedb.org/settings/api",
                "required": True,
            }
        ],
    },
    {
        "key": "youtube",
        "module": "youtube",
        "label": "YouTube",
        "description": "Search videos, get video stats, view trending",
        "needs_key": True,
        "env_vars": [
            {
                "name": "YOUTUBE_API_KEY",
                "prompt": "YouTube Data API v3 Key",
                "hint": "Free at console.cloud.google.com — enable 'YouTube Data API v3', create an API key",
                "required": True,
            }
        ],
    },
]
