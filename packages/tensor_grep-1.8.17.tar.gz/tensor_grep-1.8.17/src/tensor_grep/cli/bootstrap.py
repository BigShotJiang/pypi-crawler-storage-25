from __future__ import annotations

import os
import re
import subprocess
import sys
from pathlib import Path

from tensor_grep.cli.commands import KNOWN_COMMANDS as _KNOWN_COMMANDS
from tensor_grep.cli.commands import PYTHON_FULL_HELP_COMMANDS as _PYTHON_FULL_HELP_COMMANDS
from tensor_grep.cli.runtime_paths import (
    env_flag_enabled,
    resolve_native_tg_binary,
    resolve_ripgrep_binary,
)

_TG_ONLY_SEARCH_FLAGS = {
    "--ast",
    "--cpu",
    "--debug",
    "--files",
    "--files-with-matches",
    "--files-without-match",
    "--force-cpu",
    "--format",
    "--generate",
    "--glob",
    "--gpu-device-ids",
    "--json",
    "--ndjson",
    "--pcre2-version",
    "--lang",
    "--ltl",
    "--replace",
    "--stats",
    "--type-list",
    "-l",
    "-g",
    "-r",
}

_TG_ONLY_SEARCH_FLAG_PREFIXES = (
    "--format=",
    "--gpu-device-ids=",
    "--lang=",
    "--replace=",
)

_SCAN_FULL_CLI_FLAGS = {
    "--help",
    "-h",
    "--baseline",
    "--include-evidence-snippets",
    "--inline-rules",
    "--json",
    "--justification",
    "--language",
    "--max-evidence-snippet-chars",
    "--max-evidence-snippets-per-file",
    "--path",
    "--ruleset",
    "--suppressions",
    "--write-baseline",
    "--write-suppressions",
}

_SCAN_FULL_CLI_FLAG_PREFIXES = (
    "--baseline=",
    "--justification=",
    "--language=",
    "--max-evidence-snippet-chars=",
    "--max-evidence-snippets-per-file=",
    "--path=",
    "--ruleset=",
    "--suppressions=",
    "--write-baseline=",
    "--write-suppressions=",
)
_GUARDED_BROAD_SEARCH_ROOTS = {".claude", ".claude/context"}
_SEARCH_PATTERN_FLAGS = {"-e", "--regexp"}
_SEARCH_LITERAL_FLAGS = {"-F", "--fixed-strings"}
_SEARCH_PCRE2_FLAGS = {"-P", "--pcre2"}
_SEARCH_FLAGS_WITH_VALUES = {
    "-A",
    "-B",
    "-C",
    "-E",
    "-M",
    "-g",
    "-j",
    "-m",
    "--after-context",
    "--before-context",
    "--color",
    "--colors",
    "--context",
    "--context-separator",
    "--dfa-size-limit",
    "--encoding",
    "--engine",
    "--field-context-separator",
    "--field-match-separator",
    "--glob",
    "--gpu-device-ids",
    "--hostname-bin",
    "--hyperlink-format",
    "--iglob",
    "--ignore-file",
    "--max-columns",
    "--max-count",
    "--max-depth",
    "--max-filesize",
    "--path-separator",
    "--pre",
    "--pre-glob",
    "--regex-size-limit",
    "--replace",
    "--sort",
    "--sortr",
    "--threads",
    "--type",
    "--type-add",
    "--type-clear",
    "--type-not",
    "-r",
    "-t",
    "-T",
}


def _prefer_rust_first_search() -> bool:
    value = os.environ.get("TG_RUST_FIRST_SEARCH", "").strip().lower()
    return value in {"1", "true", "yes", "on"}


def _read_project_version_fallback() -> str:
    try:
        pyproject_path = Path(__file__).resolve().parents[3] / "pyproject.toml"
        for line in pyproject_path.read_text(encoding="utf-8").splitlines():
            stripped = line.strip()
            if stripped.startswith("version = "):
                return stripped.split('"', 2)[1]
    except Exception:
        pass
    return "0.0.0"


def _print_version() -> None:
    try:
        from importlib.metadata import version

        pkg_version = version("tensor-grep")
    except Exception:
        pkg_version = _read_project_version_fallback()

    print(f"tensor-grep {pkg_version}")
    print()
    print("features:+gpu-cudf,+gpu-torch,+rust-core")
    print("simd(compile):+SSE2,-SSSE3,-AVX2")
    print("simd(runtime):+SSE2,+SSSE3,+AVX2")
    print()
    print("Arrow Zero-Copy IPC is available")


def _normalize_search_invocation(argv: list[str]) -> list[str] | None:
    if not argv:
        return None

    first_arg = argv[0]
    if first_arg == "search":
        return argv[1:]
    if first_arg in _KNOWN_COMMANDS or first_arg.startswith("--typer-"):
        return None
    return argv


def _is_public_help_invocation(argv: list[str]) -> bool:
    if len(argv) == 1 and argv[0] in {"--help", "-h"}:
        return True
    if len(argv) == 2 and argv[0] in _PYTHON_FULL_HELP_COMMANDS and argv[1] in {"--help", "-h"}:
        return True
    return False


def _requires_full_cli(search_args: list[str]) -> bool:
    if not search_args:
        return True
    for arg in search_args:
        if arg in {"--help", "-h"}:
            return True
        if arg in {"--show-completion", "--install-completion"}:
            return True
        if arg in _TG_ONLY_SEARCH_FLAGS:
            return True
        if arg.startswith(_TG_ONLY_SEARCH_FLAG_PREFIXES):
            return True
    return False


def _can_delegate_to_native_tg_search(search_args: list[str]) -> bool:
    if not search_args:
        return False

    supported_trigger = any(
        arg in {"--cpu", "--force-cpu", "--json", "--ndjson", "--gpu-device-ids"}
        or arg.startswith("--gpu-device-ids=")
        for arg in search_args
    )
    if not supported_trigger:
        return False

    unsupported_flags = {
        "--ast",
        "--files",
        "--files-with-matches",
        "--files-without-match",
        "--format",
        "--lang",
        "--ltl",
        "--replace",
        "--stats",
        "-l",
        "-r",
    }
    unsupported_prefixes = ("--format=", "--lang=", "--replace=")
    return not any(
        arg in unsupported_flags or arg.startswith(unsupported_prefixes) for arg in search_args
    )


def _search_args_include_guarded_broad_root(search_args: list[str]) -> bool:
    for arg in search_args:
        if not arg or arg == "-" or arg.startswith("-"):
            continue
        normalized = arg.replace("\\", "/").rstrip("/").lower()
        if normalized in _GUARDED_BROAD_SEARCH_ROOTS:
            return True
        if any(normalized.endswith(f"/{root}") for root in _GUARDED_BROAD_SEARCH_ROOTS):
            return True
    return False


def _regex_patterns_from_search_args(search_args: list[str]) -> list[str]:
    skip_next = False
    bare_pattern: str | None = None
    regexp_patterns: list[str] = []
    for index, arg in enumerate(search_args):
        if skip_next:
            skip_next = False
            continue
        if arg in _SEARCH_PATTERN_FLAGS:
            if index + 1 < len(search_args):
                regexp_patterns.append(search_args[index + 1])
                skip_next = True
            continue
        if any(arg.startswith(f"{flag}=") for flag in _SEARCH_PATTERN_FLAGS):
            regexp_patterns.append(arg.split("=", 1)[1])
            continue
        if arg in _SEARCH_FLAGS_WITH_VALUES:
            skip_next = True
            continue
        if any(arg.startswith(f"{flag}=") for flag in _SEARCH_FLAGS_WITH_VALUES):
            continue
        if arg.startswith("-"):
            continue
        if bare_pattern is None:
            bare_pattern = arg
    if regexp_patterns:
        return regexp_patterns
    return [bare_pattern] if bare_pattern is not None else []


def _search_args_include_obviously_invalid_regex(search_args: list[str]) -> bool:
    if any(arg in _SEARCH_LITERAL_FLAGS for arg in search_args):
        return False
    if any(arg in _SEARCH_PCRE2_FLAGS for arg in search_args):
        return False
    for pattern in _regex_patterns_from_search_args(search_args):
        if not pattern:
            continue
        try:
            re.compile(pattern)
        except re.error:
            return True
    return False


def _effective_native_tg_search_args(search_args: list[str]) -> list[str]:
    if (
        not env_flag_enabled("TG_FORCE_CPU")
        or "--cpu" in search_args
        or "--force-cpu" in search_args
    ):
        return list(search_args)
    return [*search_args, "--cpu"]


def _run_native_tg_search(binary_name: str, search_args: list[str]) -> int:
    result = subprocess.run([binary_name, "search", *search_args], check=False)
    return int(result.returncode)


def _run_rg_passthrough(binary_name: str, search_args: list[str]) -> int:
    result = subprocess.run([binary_name, *search_args], check=False)
    return int(result.returncode)


def _run_full_cli() -> None:
    from tensor_grep.cli.main import main_entry as full_main_entry

    full_main_entry()


def _run_ast_workflow_cli(argv: list[str]) -> None:
    from tensor_grep.cli.ast_workflows import main_entry as ast_main_entry

    ast_main_entry(argv)


def _scan_requires_full_cli(scan_args: list[str]) -> bool:
    return any(
        arg in _SCAN_FULL_CLI_FLAGS or arg.startswith(_SCAN_FULL_CLI_FLAG_PREFIXES)
        for arg in scan_args
    )


def main_entry() -> None:
    argv = sys.argv[1:]
    if argv and argv[0] in {"--version", "-V"}:
        _print_version()
        raise SystemExit(0)
    if _is_public_help_invocation(argv):
        _run_full_cli()
        return

    if argv and argv[0] in {"run", "scan", "test", "ast-info"}:
        if (argv[0] in {"run", "test", "ast-info"}) or (
            argv[0] == "scan" and _scan_requires_full_cli(argv[1:])
        ):
            _run_full_cli()
            return
        _run_ast_workflow_cli(argv)
        return

    search_args = _normalize_search_invocation(argv)
    if search_args is not None:
        effective_search_args = _effective_native_tg_search_args(search_args)
        native_binary_path = resolve_native_tg_binary()
        native_binary = str(native_binary_path) if native_binary_path else None
        guarded_broad_root = _search_args_include_guarded_broad_root(search_args)
        invalid_regex = _search_args_include_obviously_invalid_regex(search_args)

        if (
            native_binary is not None
            and not guarded_broad_root
            and not invalid_regex
            and (
                _can_delegate_to_native_tg_search(effective_search_args)
                or (_prefer_rust_first_search() and not _requires_full_cli(search_args))
            )
        ):
            command_args = (
                effective_search_args
                if _can_delegate_to_native_tg_search(effective_search_args)
                else search_args
            )
            raise SystemExit(_run_native_tg_search(native_binary, command_args))

        if not guarded_broad_root and not invalid_regex and not _requires_full_cli(search_args):
            rg_binary_path = resolve_ripgrep_binary()
            binary_name = str(rg_binary_path) if rg_binary_path else None
            if binary_name is not None:
                raise SystemExit(_run_rg_passthrough(binary_name, search_args))

    _run_full_cli()


if __name__ == "__main__":
    main_entry()
