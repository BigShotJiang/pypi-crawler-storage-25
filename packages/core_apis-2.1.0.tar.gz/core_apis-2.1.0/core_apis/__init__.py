# -*- coding: utf-8 -*-

"""
Reusable building blocks API services.
"""

from importlib.metadata import PackageNotFoundError
from importlib.metadata import version


try:
    __version__ = version("core-apis")

except PackageNotFoundError:
    __version__ = "unknown"


__all__ = [
    "__version__",
]
