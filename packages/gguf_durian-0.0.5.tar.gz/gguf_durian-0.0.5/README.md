## durian

```
python -m gguf_durian
```

![screenshot](https://raw.githubusercontent.com/calcuis/goldfish/master/durian.jpg)