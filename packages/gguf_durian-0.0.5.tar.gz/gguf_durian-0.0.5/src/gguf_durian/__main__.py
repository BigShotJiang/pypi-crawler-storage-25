# import platform
# import subprocess
# import sys

# def run_command(command, shell_type=None):
#     try:
#         if shell_type == "powershell":
#             subprocess.run(
#                 ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", command],
#                 check=True
#             )
#         else:
#             subprocess.run(command, shell=True, check=True)
#     except subprocess.CalledProcessError as e:
#         print(f"Error executing command: {e}")
#         sys.exit(1)

# # def main():
# def run_installer():
#     os_name = platform.system().lower()

#     if "windows" in os_name:
#         print("Detected OS: Windows")
#         cmd = "irm https://raw.githubusercontent.com/gguf-org/durian/main/scripts/install.ps1 | iex"
#         run_command(cmd, shell_type="powershell")

#     elif "darwin" in os_name or "linux" in os_name:
#         print("Detected OS: macOS/Linux")
#         cmd = "curl -fsSL https://raw.githubusercontent.com/gguf-org/durian/main/scripts/install.sh | bash"
#         run_command(cmd)

#     else:
#         print(f"Unsupported OS: {os_name}")
#         sys.exit(1)

# # if __name__ == "__main__":
# #     main()
# run_installer()

import os
os.system("durian")