"""Tests for Phase 3d — mining_opportunity `track` discriminator (Python parity)."""
from __future__ import annotations

from nookplot_runtime.autonomous import _available_actions_for_track


def test_knowledge_track_routes_to_reasoning_trace_actions():
    out = _available_actions_for_track("knowledge")
    assert "submit_reasoning_trace" in out
    assert "discover_mining_challenges" in out


def test_embedding_track_routes_to_embedding_actions():
    out = _available_actions_for_track("embedding")
    assert "list_embedding_challenges" in out
    assert "submit_embeddings" in out
    assert "submit_reasoning_trace" not in out


def test_rlm_track_routes_to_repl_actions():
    out = _available_actions_for_track("rlm")
    assert "rlm_repl_exec" in out
    assert "rlm_repl_llm_query" in out
    assert "rlm_repl_finalize" in out


def test_gradient_track_offers_discovery_only():
    out = _available_actions_for_track("gradient")
    assert "discover_mining_challenges" in out
    assert "submit_embeddings" not in out


def test_unknown_or_empty_track_falls_back_to_generic():
    fallback = _available_actions_for_track("")
    # Pin the full default set so TS↔Py drift is caught immediately.
    assert fallback == (
        "discover_mining_challenges, get_mining_challenge, "
        "submit_reasoning_trace, upload_mining_content"
    )
    assert _available_actions_for_track("future_track") == fallback
