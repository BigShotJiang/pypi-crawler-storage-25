"""Tests for swarm signal handling — parity with runtime/src/autonomous.ts.

Covers dedup keys, dispatch routing, and handler bodies for the three
``swarm_*`` proactive signals emitted by the gateway:

* ``swarm_subtask_available`` → ``_handle_swarm_subtask_available``
* ``swarm_subtask_claimed``  → log-only (broadcast ``action_skipped``)
* ``swarm_result_submitted`` → ``_handle_swarm_result_submitted``
"""
from __future__ import annotations

import logging
import pytest
from unittest.mock import AsyncMock, MagicMock

from nookplot_runtime.autonomous import AutonomousAgent
from tests.helpers.mock_runtime import create_mock_runtime


# ================================================================
#  Dedup key tests
# ================================================================

class TestSwarmDedupKey:
    """Verify _signal_dedup_key produces stable, type-correct keys."""

    def setup_method(self):
        self.runtime, self.captured = create_mock_runtime()
        self.agent = AutonomousAgent(self.runtime, verbose=False)

    def test_swarm_subtask_available_key(self):
        key = self.agent._signal_dedup_key({
            "signalType": "swarm_subtask_available",
            "swarmId": "sw_42",
        })
        assert key == "swarm_avail:sw_42"

    def test_swarm_subtask_claimed_key(self):
        key = self.agent._signal_dedup_key({
            "signalType": "swarm_subtask_claimed",
            "subtaskId": "st_7",
        })
        assert key == "swarm_claimed:st_7"

    def test_swarm_result_submitted_key(self):
        key = self.agent._signal_dedup_key({
            "signalType": "swarm_result_submitted",
            "subtaskId": "st_9",
        })
        assert key == "swarm_result:st_9"


class TestSwarmDedupSuppression:
    """Verify duplicate swarm signals are dropped within the TTL window."""

    def setup_method(self):
        self.runtime, self.captured = create_mock_runtime()
        # Handler is invoked once per unique signal; we count its calls.
        self.handler = AsyncMock()
        self.agent = AutonomousAgent(self.runtime, on_signal=self.handler, verbose=False)
        self.agent.start()

    @pytest.mark.asyncio
    async def test_swarm_subtask_available_dedup(self):
        signal = {"data": {"signalType": "swarm_subtask_available", "swarmId": "sw_42"}}
        await self.captured["signal_cb"](signal)
        await self.captured["signal_cb"](signal)
        assert self.handler.call_count == 1

    @pytest.mark.asyncio
    async def test_swarm_subtask_claimed_dedup(self):
        signal = {"data": {"signalType": "swarm_subtask_claimed", "subtaskId": "st_7"}}
        await self.captured["signal_cb"](signal)
        await self.captured["signal_cb"](signal)
        assert self.handler.call_count == 1

    @pytest.mark.asyncio
    async def test_swarm_result_submitted_dedup(self):
        signal = {"data": {"signalType": "swarm_result_submitted", "subtaskId": "st_9"}}
        await self.captured["signal_cb"](signal)
        await self.captured["signal_cb"](signal)
        assert self.handler.call_count == 1


# ================================================================
#  Dispatch routing tests
# ================================================================

class TestSwarmDispatch:
    """Verify _handle_signal routes swarm_* to the right handler."""

    def setup_method(self):
        self.runtime, self.captured = create_mock_runtime()
        # generate_response present so the dispatch path actually runs
        self.gen = AsyncMock(return_value="")
        self.agent = AutonomousAgent(self.runtime, generate_response=self.gen, verbose=False)
        self.agent.start()
        # Spy broadcast directly — mock_runtime doesn't collect broadcasts
        self.agent._broadcast = MagicMock()

    @pytest.mark.asyncio
    async def test_swarm_subtask_available_dispatches_to_handler(self):
        self.agent._handle_swarm_subtask_available = AsyncMock()
        await self.captured["signal_cb"]({"data": {
            "signalType": "swarm_subtask_available",
            "swarmId": "sw_1",
            "swarmTitle": "Test swarm",
            "skillTags": ["python"],
        }})
        self.agent._handle_swarm_subtask_available.assert_called_once()
        call_data = self.agent._handle_swarm_subtask_available.call_args[0][0]
        assert call_data["swarmId"] == "sw_1"

    @pytest.mark.asyncio
    async def test_swarm_subtask_claimed_logs_only(self):
        await self.captured["signal_cb"]({"data": {
            "signalType": "swarm_subtask_claimed",
            "swarmId": "sw_1",
            "subtaskId": "st_1",
        }})
        assert any(
            call.args[0] == "action_skipped" and "sw_1" in call.args[1]
            for call in self.agent._broadcast.call_args_list
        )

    @pytest.mark.asyncio
    async def test_swarm_result_submitted_dispatches_to_handler(self):
        self.agent._handle_swarm_result_submitted = AsyncMock()
        await self.captured["signal_cb"]({"data": {
            "signalType": "swarm_result_submitted",
            "swarmId": "sw_1",
            "subtaskTitle": "Result review",
            "submittedBy": "0xAGENT",
        }})
        self.agent._handle_swarm_result_submitted.assert_called_once()
        call_data = self.agent._handle_swarm_result_submitted.call_args[0][0]
        assert call_data["swarmId"] == "sw_1"


# ================================================================
#  Handler body — _handle_swarm_subtask_available
# ================================================================

class TestHandleSwarmSubtaskAvailable:
    def setup_method(self):
        self.runtime, self.captured = create_mock_runtime()
        self.agent = AutonomousAgent(self.runtime, verbose=False)
        self.agent._broadcast = MagicMock()
        self.agent._parse_and_execute_action = AsyncMock()

    @pytest.mark.asyncio
    async def test_no_generate_response_returns_silently(self):
        # generate_response is None — no LLM call, no exception
        self.agent._generate_response = None
        await self.agent._handle_swarm_subtask_available({
            "swarmId": "sw_1", "swarmTitle": "T", "skillTags": [],
        })
        self.agent._parse_and_execute_action.assert_not_called()
        # No action_executed broadcast either
        assert not any(
            call.args[0] == "action_executed"
            for call in self.agent._broadcast.call_args_list
        )

    @pytest.mark.asyncio
    async def test_empty_response_skips_dispatch(self):
        self.agent._generate_response = AsyncMock(return_value="")
        await self.agent._handle_swarm_subtask_available({
            "swarmId": "sw_1", "swarmTitle": "T", "skillTags": [],
        })
        self.agent._parse_and_execute_action.assert_not_called()

    @pytest.mark.asyncio
    async def test_action_response_triggers_dispatch_and_broadcast(self):
        self.agent._generate_response = AsyncMock(
            return_value='ACTION: claim_subtask\nPARAMS: {"subtaskId":"st_1"}'
        )
        await self.agent._handle_swarm_subtask_available({
            "swarmId": "sw_12345678abcd",
            "swarmTitle": "Build dashboard",
            "skillTags": ["react"],
        })
        self.agent._parse_and_execute_action.assert_called_once()
        # action_executed broadcast with swarm context
        executed = [
            c for c in self.agent._broadcast.call_args_list
            if c.args[0] == "action_executed"
        ]
        assert len(executed) == 1
        assert executed[0].args[2]["action"] == "swarm_subtask_available"
        assert executed[0].args[2]["swarmId"] == "sw_12345678abcd"

    @pytest.mark.asyncio
    async def test_prompt_contains_expected_fields(self):
        self.agent._generate_response = AsyncMock(return_value="")
        skills = [f"skill_{i}" for i in range(15)]
        await self.agent._handle_swarm_subtask_available({
            "swarmId": "sw_abc",
            "swarmTitle": "Untitled <swarm>",
            "skillTags": skills,
        })
        prompt = self.agent._generate_response.call_args[0][0]
        # Sanitized title
        assert "Untitled" in prompt
        # Swarm ID present
        assert "sw_abc" in prompt
        # Skills sliced to ≤10
        assert "skill_0" in prompt
        assert "skill_9" in prompt
        assert "skill_10" not in prompt
        # 4 expected actions present
        for action in ("available_subtasks", "claim_subtask", "get_swarm", "heartbeat_subtask"):
            assert action in prompt
        # Format hint
        assert "ACTION:" in prompt
        assert "PARAMS:" in prompt

    @pytest.mark.asyncio
    async def test_generate_response_raises_emits_error_no_propagation(self):
        self.agent._generate_response = AsyncMock(side_effect=RuntimeError("LLM down"))
        try:
            await self.agent._handle_swarm_subtask_available({
                "swarmId": "sw_1", "swarmTitle": "T", "skillTags": [],
            })
        except Exception:
            pytest.fail("Exception should not propagate from handler")
        error_calls = [
            c for c in self.agent._broadcast.call_args_list
            if c.args[0] == "error"
        ]
        assert len(error_calls) == 1
        assert error_calls[0].args[2]["action"] == "swarm_subtask_available"


# ================================================================
#  Handler body — _handle_swarm_result_submitted
# ================================================================

class TestHandleSwarmResultSubmitted:
    def setup_method(self):
        self.runtime, self.captured = create_mock_runtime()
        self.agent = AutonomousAgent(self.runtime, verbose=False)
        self.agent._broadcast = MagicMock()
        self.agent._parse_and_execute_action = AsyncMock()

    @pytest.mark.asyncio
    async def test_no_generate_response_returns_silently(self):
        self.agent._generate_response = None
        await self.agent._handle_swarm_result_submitted({
            "swarmId": "sw_1", "subtaskTitle": "T", "submittedBy": "0xA",
        })
        self.agent._parse_and_execute_action.assert_not_called()
        assert not any(
            c.args[0] == "action_executed"
            for c in self.agent._broadcast.call_args_list
        )

    @pytest.mark.asyncio
    async def test_empty_response_skips_dispatch(self):
        self.agent._generate_response = AsyncMock(return_value="")
        await self.agent._handle_swarm_result_submitted({
            "swarmId": "sw_1", "subtaskTitle": "T", "submittedBy": "0xA",
        })
        self.agent._parse_and_execute_action.assert_not_called()

    @pytest.mark.asyncio
    async def test_action_response_triggers_dispatch_and_broadcast(self):
        self.agent._generate_response = AsyncMock(
            return_value='ACTION: aggregate_swarm\nPARAMS: {"swarmId":"sw_1"}'
        )
        await self.agent._handle_swarm_result_submitted({
            "swarmId": "sw_12345678abcd",
            "subtaskTitle": "Result A",
            "submittedBy": "0xWORKER01",
        })
        self.agent._parse_and_execute_action.assert_called_once()
        executed = [
            c for c in self.agent._broadcast.call_args_list
            if c.args[0] == "action_executed"
        ]
        assert len(executed) == 1
        assert executed[0].args[2]["action"] == "swarm_result_submitted"
        assert executed[0].args[2]["swarmId"] == "sw_12345678abcd"

    @pytest.mark.asyncio
    async def test_prompt_contains_expected_fields(self):
        self.agent._generate_response = AsyncMock(return_value="")
        await self.agent._handle_swarm_result_submitted({
            "swarmId": "sw_abc",
            "subtaskTitle": "Subtask <result>",
            "submittedBy": "0xWORKER_ADDR_12345",
        })
        prompt = self.agent._generate_response.call_args[0][0]
        # Sanitized title
        assert "Subtask" in prompt
        # Swarm ID
        assert "sw_abc" in prompt
        # Submitted by sliced to first 12 chars
        assert "0xWORKER_ADD" in prompt
        # Expected actions present (aggregate_swarm is the distinctive one)
        for action in ("get_swarm", "aggregate_swarm",
                       "accept_subtask_result", "reject_subtask_result"):
            assert action in prompt
        # Format hint
        assert "ACTION:" in prompt
        assert "PARAMS:" in prompt

    @pytest.mark.asyncio
    async def test_generate_response_raises_emits_error_no_propagation(self):
        self.agent._generate_response = AsyncMock(side_effect=RuntimeError("LLM down"))
        try:
            await self.agent._handle_swarm_result_submitted({
                "swarmId": "sw_1", "subtaskTitle": "T", "submittedBy": "0xA",
            })
        except Exception:
            pytest.fail("Exception should not propagate from handler")
        error_calls = [
            c for c in self.agent._broadcast.call_args_list
            if c.args[0] == "error"
        ]
        assert len(error_calls) == 1
        assert error_calls[0].args[2]["action"] == "swarm_result_submitted"


# ================================================================
#  Verbose-log assertions (handlers use logger.debug, not print)
# ================================================================

class TestSwarmVerboseLogs:
    @pytest.mark.asyncio
    async def test_subtask_available_verbose_debug_log(self, caplog):
        runtime, _ = create_mock_runtime()
        agent = AutonomousAgent(runtime, verbose=True, generate_response=None)
        with caplog.at_level(logging.DEBUG, logger="nookplot.autonomous"):
            await agent._handle_swarm_subtask_available({
                "swarmId": "sw_x",
                "swarmTitle": "Verbose-swarm",
                "skillTags": ["python"],
            })
        assert any(
            "Swarm subtask available" in r.message and "Verbose-swarm" in r.message
            for r in caplog.records
        )

    @pytest.mark.asyncio
    async def test_result_submitted_verbose_debug_log(self, caplog):
        runtime, _ = create_mock_runtime()
        agent = AutonomousAgent(runtime, verbose=True, generate_response=None)
        with caplog.at_level(logging.DEBUG, logger="nookplot.autonomous"):
            await agent._handle_swarm_result_submitted({
                "swarmId": "sw_x",
                "subtaskTitle": "Verbose-subtask",
                "submittedBy": "0xV",
            })
        assert any(
            "Swarm result submitted" in r.message and "Verbose-subtask" in r.message
            for r in caplog.records
        )
