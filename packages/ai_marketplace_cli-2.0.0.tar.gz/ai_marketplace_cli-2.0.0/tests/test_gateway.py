"""Tests for Gateway client behavior."""

from __future__ import annotations

import json

import httpx
import pytest

from aimp_cli.core.config import build_command_context
from aimp_cli.core.errors import CliError
from aimp_cli.clients.gateway import GatewayClient
from aimp_cli.domain.models import (
    AuthContext,
    ModeReadinessPayload,
    PublishBuildJobCreateRequest,
)


def _build_publish_request_payload() -> dict[str, object]:
    """Return a publish payload that matches the current CLI contract."""
    return {
        "slug": "demo",
        "version": "0.1.0",
        "publish_build_job_id": "build-1",
        "resources": {"vector_db": True},
        "modes": {
            "generate": {
                "inputs": [{"name": "text", "kind": "text", "required": True}],
                "outputs": ["text"],
            },
            "search": {
                "inputs": [{"name": "text", "kind": "text", "required": True}],
            },
            "index": {
                "inputs": [{"name": "text", "kind": "text", "required": True}],
            },
        },
        "mode_readiness": ModeReadinessPayload.model_validate(
            {
                "generate": {
                    "declared": True,
                    "implemented": True,
                    "reason": None,
                },
                "search": {
                    "declared": True,
                    "implemented": True,
                    "reason": None,
                },
                "index": {
                    "declared": True,
                    "implemented": True,
                    "reason": None,
                },
            }
        ).model_dump(),
        "pricing": {"developer_margin": 0},
        "supported_hardware_tiers": ["cpu-basic"],
        "studio": {
            "name": "Demo",
            "tags": ["example"],
            "visibility": "private",
            "article": {
                "format": "tiptap-json",
                "schema_version": 1,
                "content": {"type": "doc"},
            },
        },
    }


def _build_execution_publish_job_payload(**overrides: object) -> dict[str, object]:
    """Return a V2 execution payload for a publish-build job."""
    payload: dict[str, object] = {
        "id": "build-1",
        "type": "publish-build",
        "model_slug": "vision-pro",
        "operation": "publish-build",
        "status": "running",
        "timeline": [],
        "error_code": None,
        "error_message": None,
        "created_at": "2026-03-19T00:00:00+00:00",
        "started_at": None,
        "finished_at": None,
        "details": {
            "version": "1.0.0",
        },
    }
    payload.update(overrides)
    return payload


def _build_execution_fine_tune_payload(**overrides: object) -> dict[str, object]:
    """Return a V2 execution payload for a fine-tune job."""
    payload: dict[str, object] = {
        "id": "ft-1",
        "type": "fine-tune",
        "model_slug": "vision-pro",
        "operation": "fine-tune",
        "status": "running",
        "timeline": [],
        "error_code": None,
        "error_message": None,
        "created_at": "2026-03-19T00:00:00+00:00",
        "started_at": None,
        "finished_at": None,
        "details": {
            "dataset_ref": "s3://bucket/data.jsonl",
            "adapter_format": "lora",
            "output_asset_id": "asset-1",
        },
    }
    payload.update(overrides)
    return payload


def test_publish_surfaces_gateway_detail() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            409,
            json={
                "detail": {
                    "code": "slug_conflict",
                    "message": "slug conflict",
                    "retryable": False,
                }
            },
            request=request,
        )

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        try:
            client.publish(_build_publish_request_payload())
        except CliError as error:
            assert error.code == "slug_conflict"
            assert error.http_status == 409
            assert error.message == "slug conflict"
        else:
            raise AssertionError("Expected CliError")
    finally:
        client.close()


def test_publish_parses_gateway_publish_response() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={
                "id": "8ac15d57-4705-4a1f-86c1-ff81eb477c60",
                "slug": "demo",
                "visibility": "private",
                "readiness": {
                    "is_ready": False,
                    "blocking_reasons": ["publish_pricing_not_configured"],
                },
                "url": "http://localhost:3000/studio/models/demo",
            },
            request=request,
        )

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        response = client.publish(_build_publish_request_payload())
    finally:
        client.close()

    assert response.id == "8ac15d57-4705-4a1f-86c1-ff81eb477c60"
    assert response.visibility == "private"
    assert response.readiness["is_ready"] is False
    assert response.url == "http://localhost:3000/studio/models/demo"


def test_publish_serializes_canonical_mode_inputs_in_request_body() -> None:
    captured_body: dict[str, object] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal captured_body
        captured_body = json.loads(request.content.decode("utf-8"))
        return httpx.Response(
            200,
            json={
                "id": "8ac15d57-4705-4a1f-86c1-ff81eb477c60",
                "slug": "demo",
                "visibility": "private",
                "readiness": {
                    "is_ready": True,
                    "blocking_reasons": [],
                },
                "url": "http://localhost:3000/studio/models/demo",
            },
            request=request,
        )

    payload = _build_publish_request_payload()
    payload["modes"] = {
        "generate": {
            "inputs": [
                {
                    "name": "text",
                    "kind": "text",
                    "required": True,
                }
            ],
            "outputs": ["text"],
            "description": "",
        }
    }
    payload["mode_readiness"] = {
        "generate": {
            "declared": True,
            "implemented": True,
        },
    }

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        client.publish(payload)
    finally:
        client.close()

    assert captured_body["modes"] == {
        "generate": {
            "inputs": [
                {
                    "name": "text",
                    "kind": "text",
                    "required": True,
                    "description": "",
                    "multiple": False,
                }
            ],
            "outputs": ["text"],
            "description": "",
        }
    }
    assert captured_body["mode_readiness"] == {
        "generate": {
            "declared": True,
            "implemented": True,
        }
    }


def test_publish_preserves_multi_input_metadata_in_request_body() -> None:
    captured_body: dict[str, object] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal captured_body
        captured_body = json.loads(request.content.decode("utf-8"))
        return httpx.Response(
            200,
            json={
                "id": "8ac15d57-4705-4a1f-86c1-ff81eb477c60",
                "slug": "demo",
                "visibility": "private",
                "readiness": {
                    "is_ready": True,
                    "blocking_reasons": [],
                },
                "url": "http://localhost:3000/studio/models/demo",
            },
            request=request,
        )

    payload = _build_publish_request_payload()
    payload["modes"] = {
        "generate": {
            "inputs": [
                {
                    "name": "query",
                    "kind": "text",
                    "required": True,
                    "description": "Search query",
                    "label": "Query",
                },
                {
                    "name": "gallery",
                    "kind": "image",
                    "required": False,
                    "multiple": True,
                },
            ],
            "outputs": ["json"],
            "description": "Rank images",
        }
    }
    payload["mode_readiness"] = {
        "generate": {
            "declared": True,
            "implemented": True,
        },
    }

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        client.publish(payload)
    finally:
        client.close()

    assert captured_body["modes"] == {
        "generate": {
            "inputs": [
                {
                    "name": "query",
                    "kind": "text",
                    "required": True,
                    "description": "Search query",
                    "multiple": False,
                    "label": "Query",
                },
                {
                    "name": "gallery",
                    "kind": "image",
                    "required": False,
                    "description": "",
                    "multiple": True,
                },
            ],
            "outputs": ["json"],
            "description": "Rank images",
        }
    }


def test_publish_model_by_slug_parses_gateway_publish_response() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/v1/cli/models/vision-pro-tuned/publish/"
        return httpx.Response(
            200,
            json={
                "id": "derived-1",
                "slug": "vision-pro-tuned",
                "visibility": "public",
                "readiness": {
                    "is_ready": True,
                    "blocking_reasons": [],
                },
                "url": "http://localhost:3000/studio/models/vision-pro-tuned",
            },
            request=request,
        )

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        response = client.publish_model_by_slug("vision-pro-tuned")
    finally:
        client.close()

    assert response.id == "derived-1"
    assert response.slug == "vision-pro-tuned"
    assert response.visibility == "public"
    assert response.url == "http://localhost:3000/studio/models/vision-pro-tuned"


def test_get_publish_metadata_parses_gateway_response() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={
                "hardware_tiers": [
                    {
                        "id": "cpu-basic",
                        "label": "CPU Basic",
                        "description": (
                            "General-purpose CPU runtime for standard inference workloads."
                        ),
                        "base_cost_hourly": 0.05,
                    }
                ],
                "platform_fee_pct": 0.3,
            },
            request=request,
        )

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        response = client.get_publish_metadata()
    finally:
        client.close()

    assert response.platform_fee_pct == 0.3
    assert response.hardware_tiers[0].id == "cpu-basic"


def test_get_publish_metadata_surfaces_outdated_gateway_route() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(404, json={"detail": "Not Found"}, request=request)

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        try:
            client.get_publish_metadata()
        except CliError as error:
            assert error.code == "gateway_publish_metadata_unsupported"
            assert "up -d gateway" in str(error.hint)
            assert error.extra == {"route": "/v1/cli/publish/metadata"}
        else:
            raise AssertionError("Expected CliError")
    finally:
        client.close()


def test_get_model_parses_gateway_model_lookup_response() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={
                "id": "asset-123",
                "slug": "demo-model",
                "name": "Demo Model",
                "version": "0.1.0",
                "visibility": "private",
                "asset_type": "model",
            },
            request=request,
        )

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        response = client.get_model("demo-model")
    finally:
        client.close()

    assert response is not None
    assert response.slug == "demo-model"
    assert response.visibility == "private"
    assert response.asset_type == "model"


def test_create_publish_build_job_posts_jobs_command() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.method == "POST"
        assert request.url.path == "/api/jobs/publish-build/"
        payload = json.loads(request.read().decode())
        assert payload == {
            "model": "vision-pro",
            "mode": "publish-build",
            "input": {
                "version": "1.0.0",
                "source_artifact_uri": "s3://uploads/vision-pro.tar.gz",
                "dockerfile_path": "Dockerfile",
                "build_context_path": ".",
                "requested_hardware_tiers": ["cpu-basic"],
                "python_package_index": {
                    "extra_index_url": "https://test.pypi.org/simple/",
                    "username": "ci-user",
                    "password": "ci-pass",
                },
            },
        }
        return httpx.Response(
            200,
            json={
                "job": {
                    "job_id": "build-1",
                    "job_type": "build",
                    "slug": "vision-pro",
                    "version": "1.0.0",
                    "status": "queued",
                    "timeline": [],
                    "error_code": None,
                    "error_message": None,
                    "logs": [],
                    "created_at": "2026-03-19T00:00:00+00:00",
                    "started_at": None,
                    "finished_at": None,
                }
            },
            request=request,
        )

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        job = client.create_publish_build_job(
            PublishBuildJobCreateRequest(
                slug="vision-pro",
                version="1.0.0",
                source_artifact_uri="s3://uploads/vision-pro.tar.gz",
                dockerfile_path="Dockerfile",
                build_context_path=".",
                requested_hardware_tiers=["cpu-basic"],
                python_package_index={
                    "extra_index_url": "https://test.pypi.org/simple/",
                    "username": "ci-user",
                    "password": "ci-pass",
                },
            )
        )
    finally:
        client.close()

    assert job.job_id == "build-1"
    assert job.job_type == "build"
    assert job.slug == "vision-pro"
    assert job.version == "1.0.0"
    assert job.status == "queued"


def test_list_publish_build_jobs_parses_gateway_response() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/jobs/"
        assert request.url.params["type"] == "build"
        assert request.url.params["model_slug"] == "vision-pro"
        assert request.url.params["status"] == "running"
        return httpx.Response(
            200,
            json={
                "results": [
                    {
                        "job_id": "build-1",
                        "job_type": "build",
                        "model_slug": "vision-pro",
                        "version": "1.0.0",
                        "status": "running",
                        "created_at": "2026-03-19T00:00:00+00:00",
                        "started_at": None,
                        "finished_at": None,
                    }
                ],
                "pagination": {
                    "page": 1,
                    "page_size": 20,
                    "total_items": 1,
                    "total_pages": 1,
                    "has_next": False,
                    "has_previous": False,
                },
            },
            request=request,
        )

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        response = client.list_publish_build_jobs(model_slug="vision-pro", status="running")
    finally:
        client.close()

    assert response.results[0].job_id == "build-1"
    assert response.results[0].slug == "vision-pro"
    assert response.results[0].version == "1.0.0"
    assert response.pagination["total_items"] == 1


def test_get_publish_build_job_normalizes_job_response() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/jobs/build-1/"
        return httpx.Response(200, json=_build_execution_publish_job_payload(), request=request)

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        job = client.get_publish_build_job("build-1")
    finally:
        client.close()

    assert job.job_id == "build-1"
    assert job.slug == "vision-pro"
    assert job.version == "1.0.0"


def test_cancel_publish_build_job_normalizes_job_response() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/jobs/build-1/cancel/"
        return httpx.Response(
            200,
            json={
                "id": "build-1",
                "type": "publish-build",
                "status": "canceled",
                "cancel_state": "canceled",
            },
            request=request,
        )

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        payload = client.cancel_publish_build_job("build-1")
    finally:
        client.close()

    assert payload.job_type == "build"
    assert payload.cancel_state == "canceled"
    assert payload.job["job_id"] == "build-1"
    assert payload.job["status"] == "canceled"


def test_list_fine_tune_jobs_normalizes_job_response() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/jobs/"
        assert request.url.params["type"] == "fine-tune"
        assert request.url.params["model_slug"] == "vision-pro"
        assert request.url.params["status"] == "running"
        return httpx.Response(
            200,
            json={
                "results": [_build_execution_fine_tune_payload()],
                "pagination": {
                    "page": 1,
                    "page_size": 20,
                    "total_items": 1,
                    "total_pages": 1,
                    "has_next": False,
                    "has_previous": False,
                },
            },
            request=request,
        )

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        response = client.list_fine_tune_jobs(model_slug="vision-pro", status="running")
    finally:
        client.close()

    assert response.results[0].job_id == "ft-1"
    assert response.results[0].model_slug == "vision-pro"
    assert response.results[0].adapter_format == "lora"
    assert response.results[0].output_asset_id == "asset-1"


def test_get_fine_tune_job_normalizes_job_response() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/jobs/ft-1/"
        return httpx.Response(200, json=_build_execution_fine_tune_payload(), request=request)

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        job = client.get_fine_tune_job(job_id="ft-1")
    finally:
        client.close()

    assert job.job_id == "ft-1"
    assert job.model_slug == "vision-pro"
    assert job.adapter_format == "lora"
    assert job.output_asset_id == "asset-1"


def test_cancel_fine_tune_job_normalizes_job_response() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/jobs/ft-1/cancel/"
        return httpx.Response(
            200,
            json={
                "id": "ft-1",
                "type": "fine-tune",
                "status": "canceled",
                "cancel_state": "canceled",
            },
            request=request,
        )

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        payload = client.cancel_fine_tune_job(job_id="ft-1")
    finally:
        client.close()

    assert payload.job_type == "fine-tune"
    assert payload.cancel_state == "canceled"
    assert payload.job["job_id"] == "ft-1"
    assert payload.job["status"] == "canceled"


def test_list_publish_build_jobs_surfaces_gateway_error_payload() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            500,
            json={
                "error": {
                    "code": "UPSTREAM_INVALID_ERROR_RESPONSE",
                    "message": "Backend service returned a non-JSON error response",
                    "details": {"content_type": "text/html; charset=utf-8"},
                }
            },
            request=request,
        )

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        try:
            client.list_publish_build_jobs()
        except CliError as error:
            assert error.code == "UPSTREAM_INVALID_ERROR_RESPONSE"
            assert error.http_status == 500
            assert error.message == "Backend service returned a non-JSON error response"
            assert error.extra == {"content_type": "text/html; charset=utf-8"}
        else:
            raise AssertionError("Expected CliError")
    finally:
        client.close()


def test_list_publish_build_jobs_hides_raw_html_gateway_errors() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            500,
            text=(
                "<!DOCTYPE html><html><head><title>ProgrammingError</title></head>"
                "<body>broken</body></html>"
            ),
            headers={"content-type": "text/html; charset=utf-8"},
            request=request,
        )

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        try:
            client.list_publish_build_jobs()
        except CliError as error:
            assert error.code == "invalid_gateway_error_response"
            assert error.http_status == 500
            assert error.message == "Gateway returned a non-JSON error response"
            assert "<!DOCTYPE html>" not in error.message
            assert error.extra == {"content_type": "text/html; charset=utf-8"}
        else:
            raise AssertionError("Expected CliError")
    finally:
        client.close()


def test_get_current_user_returns_none_for_invalid_api_key() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            401,
            json={
                "detail": {
                    "code": "invalid_api_key",
                    "message": "Invalid API key",
                    "retryable": False,
                }
            },
            request=request,
        )

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_invalid"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        assert client.get_current_user() is None
    finally:
        client.close()


def test_get_current_user_raises_for_connectivity_failure() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("down", request=request)

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        try:
            client.get_current_user()
        except CliError as error:
            assert error.code == "gateway_unreachable"
            assert error.exit_code == 5
        else:
            raise AssertionError("Expected CliError")
    finally:
        client.close()


def test_extract_gateway_detail_reads_streaming_error_body() -> None:
    """Streaming httpx responses must buffer before json/text (e.g. execution SSE errors)."""
    body = json.dumps(
        {
            "detail": {
                "code": "execution_not_found",
                "message": "Execution not found",
                "retryable": False,
            }
        }
    ).encode()
    request = httpx.Request("GET", "http://localhost:8080/api/jobs/job-id/stream/")
    response = httpx.Response(
        404,
        stream=httpx.ByteStream(body),
        headers={"content-type": "application/json"},
        request=request,
    )

    def handler(req: httpx.Request) -> httpx.Response:
        return httpx.Response(500, request=req)

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        detail = client._extract_gateway_detail(response)
    finally:
        client.close()

    assert detail["code"] == "execution_not_found"
    assert detail["message"] == "Execution not found"


def test_extract_gateway_detail_merges_gateway_request_id_from_error_envelope() -> None:
    """Gateway JSON errors may carry error.request_id for log correlation."""
    response = httpx.Response(
        404,
        json={
            "error": {
                "code": "UPSTREAM_INVALID_ERROR_RESPONSE",
                "message": "Backend service returned a non-JSON error response",
                "request_id": "gw-trace-9f2a",
                "details": {
                    "content_type": "text/html; charset=utf-8",
                    "method": "POST",
                    "upstream_path": "/api/v1/missing/",
                },
            }
        },
        request=httpx.Request("GET", "http://localhost:8080/api/jobs/"),
    )
    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(lambda req: httpx.Response(500, request=req)),
    )
    try:
        detail = client._extract_gateway_detail(response)
    finally:
        client.close()

    assert detail["extra"]["gateway_request_id"] == "gw-trace-9f2a"
    assert detail["extra"]["upstream_path"] == "/api/v1/missing/"


def test_stream_job_surfaces_gateway_detail_before_stream_close() -> None:
    """HTTP errors on SSE open must parse JSON while httpx stream context is still open."""
    job_id = "8ac15d57-4705-4a1f-86c1-ff81eb477c60"
    stream_path = f"/api/jobs/{job_id}/stream/"

    def handler(request: httpx.Request) -> httpx.Response:
        if request.method == "GET" and request.url.path == stream_path:
            return httpx.Response(
                403,
                json={
                    "detail": {
                        "code": "forbidden_job",
                        "message": "Not allowed to stream this job",
                        "retryable": False,
                    }
                },
                request=request,
            )
        return httpx.Response(500, request=request)

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        with pytest.raises(CliError) as exc_info:
            with client.stream_job(job_id) as lines:
                next(iter(lines), "")
        error = exc_info.value
        assert error.code == "forbidden_job"
        assert error.http_status == 403
        assert "Not allowed" in error.message
        assert "closed" not in error.message.lower()
    finally:
        client.close()
