"""CLI command tests."""

from __future__ import annotations

import json
import sys
import tempfile
from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import pytest
import typer
from pytest import MonkeyPatch
from typer.testing import CliRunner

import aimp_cli.core.app as app_module
import aimp_cli.core.config as config_module
import aimp_cli.operations.publish.config as publish_config_module
from aimp_cli.core.config import config_store
from aimp_cli.core.errors import CliError, network_error
from aimp_cli.utils.interactive import LauncherJobItem
from aimp_cli.core.launcher import LauncherActionResult
from aimp_cli.domain.models import (
    AuthResponse,
    FineTuneJobListResponse,
    FineTuneJobResponse,
    InputDefinition,
    JobCancelResponse,
    ModeContract,
    ModesConfig,
    PublishBuildJob,
    PublishBuildJobListResponse,
    PublishResponse,
    ResourceConfig,
)
from aimp_cli.domain.project import (
    AGENT_CONTRACT_RELATIVE_PATH,
    FINE_TUNE_MODULE_RELATIVE_PATH,
    FINE_TUNE_SCHEMA_MODULE_RELATIVE_PATH,
    ProjectConfig,
    PROJECT_CONFIG_RELATIVE_PATH,
    PublishHardwareConfig,
    PublishMetadataConfig,
    PublishStudioConfig,
)
from aimp_cli.operations.scaffold.sync import create_legacy_project_files

runner = CliRunner()


def _scaffold_legacy_project(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
    *,
    name: str = "demo-model",
    include_skills: bool = True,
    contract_config: ProjectConfig | None = None,
) -> Path:
    monkeypatch.chdir(tmp_path)
    return create_legacy_project_files(
        name,
        include_skills=include_skills,
        contract_config=contract_config,
    )


class FakeTTYStream:
    """Simple stream stub with configurable TTY behavior."""

    def __init__(self, *, is_tty: bool) -> None:
        self._is_tty = is_tty

    def isatty(self) -> bool:
        return self._is_tty

    def write(self, text: str) -> int:
        return len(text)

    def flush(self) -> None:
        pass


class FakeCommand:
    """Simple command stub for top-level help dispatch."""

    def __init__(self) -> None:
        self.calls: list[dict[str, Any]] = []

    def main(self, **kwargs: Any) -> None:
        self.calls.append(kwargs)


class FakeGatewayClient:
    """Fake gateway used by app tests."""

    def __init__(self, *args: object, **kwargs: object) -> None:
        self.closed = False

    def close(self) -> None:
        self.closed = True

    def authenticate(self, api_key: str) -> AuthResponse:
        assert api_key == "pk_test"
        return AuthResponse(valid=True, user_id=1, username="alice", workspace="acme", scopes=[])

    def get_current_user(self) -> AuthResponse | None:
        return AuthResponse(valid=True, user_id=1, username="alice", workspace="acme", scopes=[])


class UnusedPublishConfigGateway:
    """Gateway stub used when publish config loading should fail early."""

    def get_publish_metadata(self) -> Any:
        raise AssertionError("get_publish_metadata should not be called in this test")


class FakeFineTuneGateway:
    """Gateway stub for fine-tune CLI commands."""

    def __init__(self, *args: object, **kwargs: object) -> None:
        self.closed = False

    def close(self) -> None:
        self.closed = True

    def get_marketplace_model_detail(self, slug: str) -> dict[str, Any]:
        return {
            "slug": slug,
            "tuning_supported": True,
            "tuning_output_kind": "lora",
            "tuning_schema": {
                "fields": [
                    {
                        "key": "query_image",
                        "type": "image",
                        "required": True,
                        "description": "Query image",
                        "multiple": False,
                    },
                    {
                        "key": "candidate_image",
                        "type": "image",
                        "required": True,
                        "description": "Candidate image",
                        "multiple": False,
                    },
                ],
            },
        }

    def create_fine_tune_job(
        self,
        *,
        model_slug: str,
        dataset_ref: str,
        budget: dict[str, Any] | None = None,
        labels: dict[str, Any] | None = None,
    ) -> FineTuneJobResponse:
        _ = labels
        return FineTuneJobResponse(
            job_id="job-1",
            model_slug=model_slug,
            status="queued",
            adapter_format="lora",
            output_kind="derived_model_recipe",
            output_asset_slug="vision-pro-tuned",
            timeline=[{"status": "queued"}],
        )

    @contextmanager
    def stream_job(self, job_id: str) -> Any:
        yield iter(
            [
                "event: snapshot",
                (
                    "data: "
                    + json.dumps(
                        {
                            "job": {
                                "job_id": job_id,
                                "job_type": "fine-tune",
                                "model_slug": "vision-pro",
                                "status": "queued",
                                "timeline": [{"status": "queued"}],
                                "details": {
                                    "dataset_ref": "s3://datasets/vision-pro/bundle.zip",
                                    "adapter_format": "lora",
                                    "output_asset_id": None,
                                },
                            },
                            "timeline_count": 1,
                            "log_count": None,
                        }
                    )
                ),
                "",
                "event: terminal",
                (
                    "data: "
                    + json.dumps(
                        {
                            "job": {
                                "job_id": job_id,
                                "job_type": "fine-tune",
                                "model_slug": "vision-pro",
                                "status": "succeeded",
                                "timeline": [
                                    {"status": "queued"},
                                    {"status": "succeeded"},
                                ],
                                "details": {
                                    "dataset_ref": "s3://datasets/vision-pro/bundle.zip",
                                    "adapter_format": "lora",
                                    "output_asset_id": None,
                                },
                            },
                            "timeline_count": 2,
                            "log_count": None,
                        }
                    )
                ),
                "",
            ]
        )

    def list_fine_tune_jobs(
        self,
        *,
        model_slug: str | None = None,
        status: str | None = None,
        page: int = 1,
        page_size: int = 20,
    ) -> FineTuneJobListResponse:
        _ = model_slug, status, page, page_size
        return FineTuneJobListResponse(
            results=[
                FineTuneJobResponse(
                    job_id="job-1",
                    model_slug="vision-pro",
                    status="queued",
                    adapter_format="lora",
                )
            ],
            pagination={"total_items": 1},
        )

    def get_fine_tune_job(self, *, job_id: str) -> FineTuneJobResponse:
        return FineTuneJobResponse(
            job_id=job_id,
            model_slug="vision-pro",
            status="succeeded",
            adapter_format="lora",
            output_asset_slug="vision-pro-tuned",
            output_kind="derived_model_recipe",
        )


class FakeJobsGateway(FakeFineTuneGateway):
    """Gateway stub for unified jobs CLI commands."""

    last_build_list_params: dict[str, Any] | None = None
    last_canceled_build_job: str | None = None
    last_deleted_build_job: str | None = None
    last_canceled_fine_tune_job: str | None = None
    last_deleted_fine_tune_job: str | None = None

    def list_publish_build_jobs(
        self,
        *,
        model_slug: str | None = None,
        status: str | None = None,
        page: int = 1,
        page_size: int = 20,
    ) -> PublishBuildJobListResponse:
        type(self).last_build_list_params = {
            "model_slug": model_slug,
            "status": status,
            "page": page,
            "page_size": page_size,
        }
        return PublishBuildJobListResponse(
            results=[
                PublishBuildJob(
                    job_id="build-1",
                    slug="vision-pro",
                    version="1.0.0",
                    status=status or "running",
                    created_at="2026-03-18T10:00:00Z",
                    timeline=[],
                )
            ],
            pagination={
                "page": page,
                "page_size": page_size,
                "total_items": 1,
                "total_pages": 1,
                "has_next": False,
                "has_previous": False,
            },
            model_slug=model_slug,
        )

    def get_publish_build_job(self, job_id: str) -> PublishBuildJob:
        return PublishBuildJob(
            job_id=job_id,
            slug="vision-pro",
            version="1.0.0",
            status="succeeded",
            created_at="2026-03-18T10:00:00Z",
            timeline=[],
        )

    def cancel_publish_build_job(self, job_id: str) -> JobCancelResponse:
        type(self).last_canceled_build_job = job_id
        return JobCancelResponse(
            job_type="build",
            cancel_state="canceled",
            job={"job_id": job_id, "status": "canceled"},
        )

    def delete_publish_build_job(self, job_id: str) -> None:
        type(self).last_deleted_build_job = job_id

    def cancel_fine_tune_job(self, *, job_id: str) -> JobCancelResponse:
        type(self).last_canceled_fine_tune_job = job_id
        return JobCancelResponse(
            job_type="fine-tune",
            cancel_state="canceled",
            job={"job_id": job_id, "status": "canceled"},
        )

    def delete_fine_tune_job(self, *, job_id: str) -> None:
        type(self).last_deleted_fine_tune_job = job_id


def test_login_stdin_persists_config(tmp_path: Path, monkeypatch: MonkeyPatch) -> None:
    monkeypatch.setattr(app_module, "GatewayClient", FakeGatewayClient)
    config_store._path = tmp_path / "config.json"
    result = runner.invoke(
        app_module.app,
        ["login", "--gateway", "http://localhost:8080", "--stdin", "--json"],
        input="pk_test",
    )
    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["ok"] is True
    assert payload["data"]["username"] == "alice"
    persisted = json.loads((tmp_path / "config.json").read_text(encoding="utf-8"))
    assert persisted["apiKey"] == "pk_test"


def test_auth_reports_not_authenticated_when_no_credentials(tmp_path: Path) -> None:
    config_store._path = tmp_path / "config.json"
    config_store._config = None
    result = runner.invoke(app_module.app, ["auth", "--json"])
    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["ok"] is True
    assert payload["data"]["authenticated"] is False
    assert payload["data"]["reason"] == "no_credentials"


def test_init_creates_unified_deployable_project(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)

    result = runner.invoke(
        app_module.app,
        ["init", "demo-model", "--yes", "--json"],
    )

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["data"]["entrypoint"] == "agent.py"
    assert payload["data"]["next_steps"] == [
        "cd demo-model",
        "uv sync",
        "ai publish --configure",
        "ai push",
    ]
    project_dir = tmp_path / "demo-model"
    assert (project_dir / "model" / "__init__.py").exists()
    assert (project_dir / "model" / "model.py").exists()
    assert (project_dir / "model" / "modes.py").exists()
    assert (project_dir / "model" / "schemas.py").exists()
    assert (project_dir / "model" / "trainer.py").exists()
    assert (project_dir / "model" / "vector.py").exists()
    assert (project_dir / "model" / "engine.py").exists()
    assert (project_dir / "agent.py").exists()
    assert (project_dir / "contract.toml").exists()
    assert (project_dir / ".aimp" / "project.toml").exists()
    assert (project_dir / ".aimp" / "publish.toml").exists()
    assert (project_dir / "Dockerfile").exists()
    assert (project_dir / "pyproject.toml").exists()
    assert (project_dir / ".dockerignore").exists()
    assert (project_dir / "AGENTS.md").exists()
    assert (project_dir / "studio" / "article.mdx").exists()
    assert (project_dir / "studio" / "cover.jpg").exists()
    assert not (project_dir / ".aimp" / "sdk" / "python").exists()
    assert not any(path.name == "__pycache__" for path in project_dir.rglob("__pycache__"))
    model_text = (project_dir / "model" / "model.py").read_text(encoding="utf-8")
    app_text = (project_dir / "agent.py").read_text(encoding="utf-8")
    docker_text = (project_dir / "Dockerfile").read_text(encoding="utf-8")
    assert "class Example(Model):" in model_text
    assert "train = [ExampleTrainer]" in model_text
    assert "class DemoModelAgent(Agent):" in app_text
    assert "models = [Example]" in app_text
    assert "class GenerateMode(Mode):" not in app_text
    assert "inputs_schema" not in app_text
    assert "outputs_schema" not in app_text
    assert "parameters_schema" not in app_text
    assert "from aimp_framework.base import Agent" in app_text
    assert "from model.model import Example" in app_text
    assert not (project_dir / "scripts" / "build.py").exists()
    assert "# syntax=docker/dockerfile:1.7" in docker_text
    assert "RUN --mount=type=secret,id=python_package_extra_index_pip_conf," in docker_text
    assert "pip install --no-cache-dir ." in docker_text
    assert 'RUN python -m aimp_sdk.build_runner --module /app/agent.py' in docker_text


def test_init_rejects_removed_template_option(tmp_path: Path, monkeypatch: MonkeyPatch) -> None:
    monkeypatch.chdir(tmp_path)

    result = runner.invoke(app_module.app, ["init", "demo-model", "--template", "anything"])

    assert result.exit_code != 0
    assert "No such option: --template" in result.stdout


def test_init_rejects_removed_vector_options(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)

    result = runner.invoke(app_module.app, ["init", "demo-model", "--with-vector"])

    assert result.exit_code != 0
    assert "No such option: --with-vector" in result.stdout


def test_init_rejects_removed_no_skills_option(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)

    result = runner.invoke(app_module.app, ["init", "demo-model", "--no-skills"])

    assert result.exit_code != 0
    assert "No such option: --no-skills" in result.stdout


def test_help_no_longer_exposes_add_commands() -> None:
    result = runner.invoke(app_module.app, ["--help"])

    assert result.exit_code == 0
    assert "add" not in result.stdout
    assert "agent" not in result.stdout


def test_init_fails_when_directory_exists(tmp_path: Path, monkeypatch: MonkeyPatch) -> None:
    monkeypatch.chdir(tmp_path)
    (tmp_path / "demo-model").mkdir()

    result = runner.invoke(app_module.app, ["init", "demo-model", "--json"])

    assert result.exit_code != 0
    payload = json.loads(result.stdout)
    assert payload["error"]["code"] == "validation_error"
    assert 'Directory "demo-model" already exists' in payload["error"]["message"]


def test_skills_list_returns_project_local_skills(tmp_path: Path, monkeypatch: MonkeyPatch) -> None:
    project_dir = _scaffold_legacy_project(tmp_path, monkeypatch)
    monkeypatch.chdir(project_dir)

    result = runner.invoke(app_module.app, ["skills", "list", "--json"])

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["data"]["skill_index_file"] == ".agents/skills/SKILL_INDEX.md"
    skill_names = [item["name"] for item in payload["data"]["skills"]]
    assert "skill-index" in skill_names
    assert "model-development" in skill_names
    assert "tuning-development" in skill_names
    assert "publish-readiness" in skill_names
    assert "studio-article-media" in skill_names
    assert "ci-quality-gates" in skill_names


def test_skills_list_fails_cleanly_outside_project(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)

    result = runner.invoke(app_module.app, ["skills", "list", "--json"])

    assert result.exit_code != 0
    payload = json.loads(result.stdout)
    assert payload["error"]["code"] == "project_not_found"


def test_skills_list_fails_when_project_has_no_skills(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    project_dir = _scaffold_legacy_project(tmp_path, monkeypatch, include_skills=False)
    monkeypatch.chdir(project_dir)

    result = runner.invoke(app_module.app, ["skills", "list", "--json"])

    assert result.exit_code != 0
    payload = json.loads(result.stdout)
    assert payload["error"]["code"] == "project_skills_not_found"


def test_fine_tune_create_rejects_missing_bundle(monkeypatch: MonkeyPatch) -> None:
    monkeypatch.setattr(
        app_module,
        "resolve_auth_context",
        lambda **_kwargs: SimpleNamespace(api_key="pk_test", gateway_url="http://localhost:8080"),
    )
    monkeypatch.setattr(app_module, "GatewayClient", FakeFineTuneGateway)

    result = runner.invoke(
        app_module.app,
        [
            "fine-tune",
            "create",
            "--model",
            "vision-pro",
            "--bundle",
            "/tmp/does-not-exist.json",
            "--json",
        ],
    )

    assert result.exit_code != 0
    payload = json.loads(result.stdout)
    assert payload["ok"] is False
    assert payload["error"]["code"] == "dataset_not_found"


def test_fine_tune_create_uploads_workspace_bundle_and_submits_job(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    class NoActiveFineTuneGateway(FakeFineTuneGateway):
        def list_fine_tune_jobs(
            self,
            *,
            model_slug: str | None = None,
            status: str | None = None,
            page: int = 1,
            page_size: int = 20,
        ) -> FineTuneJobListResponse:
            _ = model_slug, status, page, page_size
            return FineTuneJobListResponse(results=[], pagination={"total_items": 0})

    query_image = tmp_path / "query.jpg"
    candidate_image = tmp_path / "candidate.jpg"
    query_image.write_bytes(b"query-image")
    candidate_image.write_bytes(b"candidate-image")
    bundle_path = tmp_path / "bundle.json"
    bundle_path.write_text(
        json.dumps(
            {
                "records": [
                    {
                        "query_image": query_image.name,
                        "candidate_image": candidate_image.name,
                    }
                ]
            }
        ),
        encoding="utf-8",
    )
    upload_calls: list[dict[str, Any]] = []

    class FakeUploadClient:
        def __init__(self, gateway: Any) -> None:
            self.gateway = gateway

        def upload_file(
            self,
            *,
            file_path: Path,
            slug: str,
            version: str,
            artifact_type: str,
            content_type: str,
            metadata: dict[str, Any],
            concurrency: int,
            on_progress: Any,
        ) -> Any:
            upload_calls.append(
                {
                    "file_path": file_path,
                    "slug": slug,
                    "version": version,
                    "artifact_type": artifact_type,
                    "content_type": content_type,
                    "metadata": metadata,
                    "concurrency": concurrency,
                    "on_progress": on_progress,
                }
            )
            return SimpleNamespace(storage_uri="s3://datasets/vision-pro/bundle.zip")

    monkeypatch.setattr(
        app_module,
        "resolve_auth_context",
        lambda **_kwargs: SimpleNamespace(api_key="pk_test", gateway_url="http://localhost:8080"),
    )
    monkeypatch.setattr(app_module, "GatewayClient", NoActiveFineTuneGateway)
    monkeypatch.setattr(app_module, "UploadClient", FakeUploadClient)

    result = runner.invoke(
        app_module.app,
        [
            "fine-tune",
            "create",
            "--model",
            "vision-pro",
            "--workspace",
            str(tmp_path),
            "--max-trials",
            "3",
            "--json",
        ],
    )

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["ok"] is True
    assert payload["data"]["job_id"] == "job-1"
    assert payload["data"]["job_created"] is True
    assert payload["data"]["output_dir"] == str(tmp_path)
    assert payload["data"]["output_kind"] == "derived_model_recipe"
    assert payload["data"]["output_asset_slug"] == "vision-pro-tuned"
    assert upload_calls[0]["artifact_type"] == "fine_tune_dataset"
    assert upload_calls[0]["slug"] == "vision-pro"
    assert upload_calls[0]["content_type"] == "application/zip"


def test_fine_tune_create_scaffolds_output_dir_when_bundle_missing(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        app_module,
        "resolve_auth_context",
        lambda **_kwargs: SimpleNamespace(api_key="pk_test", gateway_url="http://localhost:8080"),
    )
    monkeypatch.setattr(app_module, "GatewayClient", FakeFineTuneGateway)

    output_dir = tmp_path / "customer-data"
    result = runner.invoke(
        app_module.app,
        [
            "fine-tune",
            "create",
            "--model",
            "vision-pro",
            "--output-dir",
            str(output_dir),
            "--json",
        ],
    )

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["data"]["job_created"] is False
    assert payload["data"]["output_dir"] == str(output_dir)
    assert (output_dir / ".tuning" / "schema.json").exists()
    assert (output_dir / "prepare_bundle.py").exists()
    assert (output_dir / "README.md").exists()
    assert "python prepare_bundle.py" in payload["data"]["next_step"]


def test_fine_tune_create_preserves_existing_workspace_when_bundle_missing(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        app_module,
        "resolve_auth_context",
        lambda **_kwargs: SimpleNamespace(api_key="pk_test", gateway_url="http://localhost:8080"),
    )
    monkeypatch.setattr(app_module, "GatewayClient", FakeFineTuneGateway)

    output_dir = tmp_path / "customer-data"
    output_dir.mkdir(parents=True)
    prepare_bundle = output_dir / "prepare_bundle.py"
    prepare_bundle.write_text("# custom prepare bundle\n", encoding="utf-8")

    result = runner.invoke(
        app_module.app,
        [
            "fine-tune",
            "create",
            "--model",
            "vision-pro",
            "--output-dir",
            str(output_dir),
            "--json",
        ],
    )

    assert result.exit_code != 0
    payload = json.loads(result.stdout)
    assert payload["error"]["code"] == "dataset_not_found"
    assert "python prepare_bundle.py" in payload["error"]["message"]
    assert prepare_bundle.read_text(encoding="utf-8") == "# custom prepare bundle\n"


def test_fine_tune_create_rejects_existing_active_job_before_upload(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    class ActiveFineTuneGateway(FakeFineTuneGateway):
        def list_fine_tune_jobs(
            self,
            *,
            model_slug: str | None = None,
            status: str | None = None,
            page: int = 1,
            page_size: int = 20,
        ) -> FineTuneJobListResponse:
            _ = status, page, page_size
            return FineTuneJobListResponse(
                results=[
                    FineTuneJobResponse(
                        job_id="job-active",
                        model_slug=model_slug or "vision-pro",
                        status="running",
                        adapter_format="lora",
                    )
                ],
                pagination={"total_items": 1},
            )

        def create_fine_tune_job(
            self,
            *,
            model_slug: str,
            dataset_ref: str,
            budget: dict[str, Any] | None = None,
            labels: dict[str, Any] | None = None,
        ) -> FineTuneJobResponse:
            _ = model_slug, dataset_ref, budget, labels
            raise AssertionError("create_fine_tune_job should not be called")

    class NoUploadClient:
        def __init__(self, *args: object, **kwargs: object) -> None:
            _ = args, kwargs

        def upload_file(self, **kwargs: Any) -> Any:
            _ = kwargs
            raise AssertionError("upload_file should not be called")

    bundle_path = tmp_path / "bundle.json"
    bundle_path.write_text("{}", encoding="utf-8")

    def fake_create_bundle(**_kwargs: Any) -> tuple[SimpleNamespace, str]:
        temp_path = Path(tempfile.mkstemp(suffix=".zip")[1])
        temp_path.write_text("archive", encoding="utf-8")
        return SimpleNamespace(name=str(temp_path)), "application/zip"

    monkeypatch.setattr(
        app_module,
        "resolve_auth_context",
        lambda **_kwargs: SimpleNamespace(api_key="pk_test", gateway_url="http://localhost:8080"),
    )
    monkeypatch.setattr(app_module, "GatewayClient", ActiveFineTuneGateway)
    monkeypatch.setattr(app_module, "UploadClient", NoUploadClient)
    monkeypatch.setattr(app_module, "_create_tuning_bundle_archive", fake_create_bundle)

    result = runner.invoke(
        app_module.app,
        [
            "fine-tune",
            "create",
            "--model",
            "vision-pro",
            "--bundle",
            str(bundle_path),
            "--json",
        ],
    )

    assert result.exit_code == 6
    payload = json.loads(result.stdout)
    assert payload["ok"] is False
    assert payload["error"]["code"] == "active_job_exists"


def test_fine_tune_create_streams_live_logs_in_non_json_mode(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    class StreamingFineTuneGateway(FakeFineTuneGateway):
        def list_fine_tune_jobs(
            self,
            *,
            model_slug: str | None = None,
            status: str | None = None,
            page: int = 1,
            page_size: int = 20,
        ) -> FineTuneJobListResponse:
            _ = model_slug, status, page, page_size
            return FineTuneJobListResponse(results=[], pagination={"total_items": 0})

        @contextmanager
        def stream_job(self, job_id: str) -> Any:
            yield iter(
                [
                    "event: snapshot",
                    (
                        "data: "
                        + json.dumps(
                            {
                                "job": {
                                    "job_id": job_id,
                                    "job_type": "fine-tune",
                                    "model_slug": "vision-pro",
                                    "status": "running",
                                    "timeline": [{"status": "queued"}],
                                    "logs": [
                                        {
                                            "level": "info",
                                            "message": "Creating tuning study",
                                        }
                                    ],
                                    "details": {
                                        "dataset_ref": "s3://datasets/vision-pro/bundle.zip",
                                        "adapter_format": "lora",
                                        "output_asset_id": None,
                                    },
                                },
                                "timeline_count": 1,
                                "log_count": 1,
                            }
                        )
                    ),
                    "",
                    "event: logs",
                    (
                        "data: "
                        + json.dumps(
                            {
                                "job_id": job_id,
                                "job_type": "fine-tune",
                                "offset": 1,
                                "count": 1,
                                "items": [
                                    {
                                        "level": "warning",
                                        "message": "Executing tuning trial 1/3",
                                    }
                                ],
                            }
                        )
                    ),
                    "",
                    "event: terminal",
                    (
                        "data: "
                        + json.dumps(
                            {
                                "job": {
                                    "job_id": job_id,
                                    "job_type": "fine-tune",
                                    "model_slug": "vision-pro",
                                    "status": "succeeded",
                                    "timeline": [
                                        {"status": "queued"},
                                        {"status": "succeeded"},
                                    ],
                                    "logs": [
                                        {
                                            "level": "info",
                                            "message": "Creating tuning study",
                                        },
                                        {
                                            "level": "warning",
                                            "message": "Executing tuning trial 1/3",
                                        },
                                        {
                                            "level": "info",
                                            "message": "Fine-tune job succeeded",
                                        },
                                    ],
                                    "details": {
                                        "dataset_ref": "s3://datasets/vision-pro/bundle.zip",
                                        "adapter_format": "lora",
                                        "output_asset_id": None,
                                    },
                                },
                                "timeline_count": 2,
                                "log_count": 3,
                            }
                        )
                    ),
                    "",
                ]
            )

    class FakeUploadClient:
        def __init__(self, gateway: Any) -> None:
            self.gateway = gateway

        def upload_file(
            self,
            *,
            file_path: Path,
            slug: str,
            version: str,
            artifact_type: str,
            content_type: str,
            metadata: dict[str, Any],
            concurrency: int,
            on_progress: Any,
        ) -> Any:
            _ = (
                file_path,
                slug,
                version,
                artifact_type,
                content_type,
                metadata,
                concurrency,
                on_progress,
            )
            return SimpleNamespace(storage_uri="s3://datasets/vision-pro/bundle.zip")

    class _StatusStub:
        def __enter__(self) -> _StatusStub:
            return self

        def __exit__(self, exc_type, exc, tb) -> None:
            _ = exc_type, exc, tb

        def update(self, message: str) -> None:
            _ = message

    printed: list[str] = []

    class _ConsoleStub:
        @staticmethod
        def status(*args: Any, **kwargs: Any) -> _StatusStub:
            _ = args, kwargs
            return _StatusStub()

        @staticmethod
        def print(message: Any, **kwargs: Any) -> None:
            _ = kwargs
            printed.append(str(message))

        @staticmethod
        def print_json(*args: Any, **kwargs: Any) -> None:
            _ = args, kwargs

    query_image = tmp_path / "query.jpg"
    candidate_image = tmp_path / "candidate.jpg"
    query_image.write_bytes(b"query-image")
    candidate_image.write_bytes(b"candidate-image")
    bundle_path = tmp_path / "bundle.json"
    bundle_path.write_text(
        json.dumps(
            {
                "records": [
                    {
                        "query_image": query_image.name,
                        "candidate_image": candidate_image.name,
                    }
                ]
            }
        ),
        encoding="utf-8",
    )

    monkeypatch.setattr(
        app_module,
        "resolve_auth_context",
        lambda **_kwargs: SimpleNamespace(api_key="pk_test", gateway_url="http://localhost:8080"),
    )
    monkeypatch.setattr(app_module, "GatewayClient", StreamingFineTuneGateway)
    monkeypatch.setattr(app_module, "UploadClient", FakeUploadClient)
    monkeypatch.setattr(app_module, "console", _ConsoleStub())

    result = runner.invoke(
        app_module.app,
        [
            "fine-tune",
            "create",
            "--model",
            "vision-pro",
            "--workspace",
            str(tmp_path),
        ],
    )

    assert result.exit_code == 0
    assert "[dim]  Creating tuning study[/dim]" in printed
    assert "[yellow]⚠ Executing tuning trial 1/3[/yellow]" in printed
    assert "[dim]  Fine-tune job succeeded[/dim]" in printed


def test_project_configure_enables_fine_tune_module(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    project_dir = _scaffold_legacy_project(tmp_path, monkeypatch)
    monkeypatch.chdir(project_dir)

    result = runner.invoke(
        app_module.app,
        ["project", "configure", "--fine-tune", "--json"],
    )

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["data"]["tuning"]["supported"] is True
    model_text = (tmp_path / "demo-model" / "app" / "generator" / "model.py").read_text(
        encoding="utf-8"
    )
    assert "def tune(self, session) -> TuneResult:" in model_text
    assert (tmp_path / "demo-model" / "tuning.py").exists()


def test_contract_edit_keeps_project_fine_tune_wiring(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    project_dir = _scaffold_legacy_project(tmp_path, monkeypatch)
    monkeypatch.chdir(project_dir)
    runner.invoke(app_module.app, ["project", "configure", "--fine-tune", "--json"])

    result = runner.invoke(
        app_module.app,
        [
            "contract",
            "edit",
            "--modes",
            "generate,search",
            "--mode-inputs",
            "search=image",
            "--json",
        ],
    )

    assert result.exit_code == 0
    model_text = (tmp_path / "demo-model" / "app" / "generator" / "model.py").read_text(
        encoding="utf-8"
    )
    assert "def tune(self, session) -> TuneResult:" in model_text
    assert (tmp_path / "demo-model" / "tuning.py").exists()


def test_fine_tune_schema_reads_local_project_contract(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    project_dir = _scaffold_legacy_project(tmp_path, monkeypatch)
    monkeypatch.chdir(project_dir)
    runner.invoke(
        app_module.app,
        [
            "contract",
            "edit",
            "--modes",
            "search,index",
            "--vector-db",
            "--mode-inputs",
            "search=image",
            "--mode-inputs",
            "index=image",
            "--fine-tune",
            "--json",
        ],
    )

    schema_path = tmp_path / "demo-model" / "tuning.py"
    schema_path.write_text(
        "from aimp_sdk import FineTuneSchema, TuningTextField\n\n\n"
        "class TuningInputs(FineTuneSchema):\n"
        "    dataset_url = TuningTextField()\n",
        encoding="utf-8",
    )

    result = runner.invoke(app_module.app, ["fine-tune", "schema", "--json"])

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    field_keys = [field["key"] for field in payload["data"]["schema"]["fields"]]
    assert field_keys == ["dataset_url"]


def test_fine_tune_scaffold_generates_consumer_workspace(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    class RichSchemaGateway(FakeFineTuneGateway):
        def get_marketplace_model_detail(self, slug: str) -> dict[str, Any]:
            return {
                "slug": slug,
                "tuning_supported": True,
                "tuning_output_kind": "lora",
                "tuning_schema": {
                    "fields": [
                        {
                            "key": "prompt",
                            "type": "text",
                            "required": True,
                            "description": "Prompt text",
                            "multiple": False,
                        },
                        {
                            "key": "metadata",
                            "type": "json",
                            "required": True,
                            "description": "Structured metadata",
                            "multiple": False,
                        },
                        {
                            "key": "attachments",
                            "type": "file",
                            "required": False,
                            "description": "Supporting files",
                            "multiple": True,
                        },
                        {
                            "key": "query_image",
                            "type": "image",
                            "required": True,
                            "description": "Reference image",
                            "multiple": False,
                        },
                        {
                            "key": "reference_audio",
                            "type": "audio",
                            "required": False,
                            "description": "Reference audio",
                            "multiple": False,
                        },
                        {
                            "key": "preview_video",
                            "type": "video",
                            "required": False,
                            "description": "Preview video",
                            "multiple": False,
                        },
                    ],
                },
            }

    monkeypatch.setattr(
        app_module,
        "resolve_auth_context",
        lambda **_kwargs: SimpleNamespace(api_key="pk_test", gateway_url="http://localhost:8080"),
    )
    monkeypatch.setattr(app_module, "GatewayClient", RichSchemaGateway)

    output_dir = tmp_path / "consumer-workspace"
    result = runner.invoke(
        app_module.app,
        [
            "fine-tune",
            "scaffold",
            "--model",
            "vision-pro",
            "--output",
            str(output_dir),
            "--json",
        ],
    )

    assert result.exit_code == 0
    assert (output_dir / ".tuning" / "schema.json").exists()
    assert (output_dir / "prepare_bundle.py").exists()
    assert (output_dir / "README.md").exists()
    assert (output_dir / "assets" / "README.md").exists()
    prepare_script = (output_dir / "prepare_bundle.py").read_text(encoding="utf-8")
    assert "bundle.json" in prepare_script
    assert "prompt" in prepare_script
    assert "metadata" in prepare_script
    assert "attachments" in prepare_script
    assert "query_image" in prepare_script
    assert "reference_audio" in prepare_script
    assert "preview_video" in prepare_script


def test_fine_tune_list_and_get_commands(monkeypatch: MonkeyPatch) -> None:
    monkeypatch.setattr(
        app_module,
        "resolve_auth_context",
        lambda **_kwargs: SimpleNamespace(api_key="pk_test", gateway_url="http://localhost:8080"),
    )
    monkeypatch.setattr(app_module, "GatewayClient", FakeFineTuneGateway)

    list_result = runner.invoke(app_module.app, ["fine-tune", "list", "--json"])
    get_result = runner.invoke(app_module.app, ["fine-tune", "get", "--job", "job-1", "--json"])

    assert list_result.exit_code == 0
    assert get_result.exit_code == 0
    assert json.loads(list_result.stdout)["data"]["results"][0]["job_id"] == "job-1"
    assert json.loads(get_result.stdout)["data"]["status"] == "succeeded"


def test_jobs_list_defaults_to_all_and_merges_job_types(monkeypatch: MonkeyPatch) -> None:
    monkeypatch.setattr(
        app_module,
        "resolve_auth_context",
        lambda **_kwargs: SimpleNamespace(api_key="pk_test", gateway_url="http://localhost:8080"),
    )
    monkeypatch.setattr(app_module, "GatewayClient", FakeJobsGateway)
    FakeJobsGateway.last_build_list_params = None

    result = runner.invoke(app_module.app, ["jobs", "list", "--json"])

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["data"]["type"] == "all"
    assert [item["job_type"] for item in payload["data"]["results"]] == ["build", "fine-tune"]
    assert payload["data"]["results"][0]["job_id"] == "build-1"
    assert payload["data"]["results"][1]["job_id"] == "job-1"
    assert payload["data"]["sources"]["build"]["total_items"] == 1
    assert payload["data"]["sources"]["fine_tune"]["total_items"] == 1


def test_jobs_list_build_filter_and_get_build_job(monkeypatch: MonkeyPatch) -> None:
    monkeypatch.setattr(
        app_module,
        "resolve_auth_context",
        lambda **_kwargs: SimpleNamespace(api_key="pk_test", gateway_url="http://localhost:8080"),
    )
    monkeypatch.setattr(app_module, "GatewayClient", FakeJobsGateway)
    FakeJobsGateway.last_build_list_params = None

    list_result = runner.invoke(
        app_module.app,
        [
            "jobs",
            "list",
            "--type",
            "build",
            "--status",
            "running",
            "--model",
            "vision-pro",
            "--json",
        ],
    )
    get_result = runner.invoke(
        app_module.app,
        ["jobs", "get", "--type", "build", "--job", "build-1", "--json"],
    )

    assert list_result.exit_code == 0
    assert get_result.exit_code == 0
    assert FakeJobsGateway.last_build_list_params == {
        "model_slug": "vision-pro",
        "status": "running",
        "page": 1,
        "page_size": 20,
    }
    assert json.loads(list_result.stdout)["data"]["results"][0]["job_type"] == "build"
    assert json.loads(get_result.stdout)["data"]["job"]["job_id"] == "build-1"


def test_jobs_cancel_and_delete_commands(monkeypatch: MonkeyPatch) -> None:
    monkeypatch.setattr(
        app_module,
        "resolve_auth_context",
        lambda **_kwargs: SimpleNamespace(api_key="pk_test", gateway_url="http://localhost:8080"),
    )
    monkeypatch.setattr(app_module, "GatewayClient", FakeJobsGateway)
    FakeJobsGateway.last_canceled_build_job = None
    FakeJobsGateway.last_deleted_build_job = None
    FakeJobsGateway.last_deleted_fine_tune_job = None

    cancel_result = runner.invoke(
        app_module.app,
        ["jobs", "cancel", "--type", "build", "--job", "build-1", "--json"],
    )
    delete_result = runner.invoke(
        app_module.app,
        ["jobs", "delete", "--type", "fine-tune", "--job", "job-1", "--json"],
    )

    assert cancel_result.exit_code == 0
    assert delete_result.exit_code == 0
    assert json.loads(cancel_result.stdout)["data"]["action"] == "canceled_and_deleted"
    assert json.loads(delete_result.stdout)["data"]["action"] == "deleted"
    assert FakeJobsGateway.last_canceled_build_job == "build-1"
    assert FakeJobsGateway.last_deleted_build_job == "build-1"
    assert FakeJobsGateway.last_deleted_fine_tune_job == "job-1"


def test_auth_surfaces_gateway_connectivity_failure(monkeypatch: MonkeyPatch) -> None:
    class UnreachableGateway(FakeGatewayClient):
        def get_current_user(self) -> AuthResponse | None:
            raise network_error(
                "Authentication failed: gateway unreachable",
                code="gateway_unreachable",
                request_id="req-auth-down",
            )

    monkeypatch.setattr(app_module, "GatewayClient", UnreachableGateway)
    result = runner.invoke(
        app_module.app,
        ["auth", "--json", "--gateway", "http://127.0.0.1:9", "--api-key", "pk_test"],
    )
    assert result.exit_code == 5
    payload = json.loads(result.stdout)
    assert payload["ok"] is False
    assert payload["error"]["code"] == "gateway_unreachable"


def test_build_publish_success_message_includes_readiness_blockers() -> None:
    message = app_module._build_publish_success_message(
        {
            "slug": "demo-model",
            "visibility": "private",
            "readiness": {
                "is_ready": False,
                "blocking_reasons": ["publish_pricing_not_configured"],
            },
            "url": "http://localhost:3000/studio/models/demo-model",
        }
    )

    assert "Deployment successful." in message
    assert "Visibility: private" in message
    assert "Ready: no" in message
    assert "- publish_pricing_not_configured" in message


def test_ensure_publish_config_rejects_legacy_root_file(tmp_path: Path) -> None:
    (tmp_path / "aimp.publish.toml").write_text("schema_version = 2\n", encoding="utf-8")

    with pytest.raises(CliError) as exc_info:
        publish_config_module.ensure_publish_config(
            project_dir=tmp_path,
            gateway=UnusedPublishConfigGateway(),
            configure_only=False,
            console=app_module.console,
            interactive_terminal=False,
        )

    assert exc_info.value.code == "legacy_publish_config_unsupported"


def test_ensure_publish_config_non_tty_missing_config_deduplicates_guidance(
    tmp_path: Path,
) -> None:
    with pytest.raises(CliError) as exc_info:
        publish_config_module.ensure_publish_config(
            project_dir=tmp_path,
            gateway=UnusedPublishConfigGateway(),
            configure_only=False,
            console=app_module.console,
            interactive_terminal=False,
        )

    assert exc_info.value.code == "publish_config_required"
    assert "Publish config not found: .aimp/publish.toml." in str(exc_info.value)
    assert (
        "Use an interactive terminal to create .aimp/publish.toml, or commit a valid file."
        in str(exc_info.value)
    )


def test_write_publish_config_writes_hidden_state_and_default_article(tmp_path: Path) -> None:
    config = PublishMetadataConfig(
        schema_version=4,
        studio=PublishStudioConfig(
            name="Demo",
            tags=["example"],
            visibility="private",
            cover_file="studio/cover.jpg",
            article_mdx_file="studio/article.mdx",
        ),
        hardware=PublishHardwareConfig(supported_tiers=["cpu-basic"]),
        pricing={"developer_margin": 0},
    )

    config_path = publish_config_module.write_publish_config(tmp_path, config)

    assert config_path == tmp_path / ".aimp" / "publish.toml"
    assert config_path.exists()
    assert (tmp_path / "studio" / "article.mdx").exists()
    assert (tmp_path / "studio" / "cover.jpg").exists()


def test_select_visibility_only_offers_private_and_public(monkeypatch: MonkeyPatch) -> None:
    captured_keys: list[str] = []
    captured_show_header: list[bool] = []

    def fake_select_menu(
        sections: list[Any],
        *,
        show_header: bool = True,
        title: str | None = None,
        subtitle: str | None = None,
    ) -> Any:
        captured_keys.extend(option.key for option in sections[0].options)
        captured_show_header.append(show_header)
        _ = title, subtitle
        return sections[0].options[0]

    monkeypatch.setattr(publish_config_module, "select_menu", fake_select_menu)

    result = publish_config_module._select_visibility(
        default_visibility="private",
        console=app_module.console,
        interactive_terminal=True,
    )

    assert result == "private"
    assert captured_keys == ["private", "public"]
    assert captured_show_header == [False]


def test_contract_edit_writes_hidden_contract_from_flags(
    tmp_path: Path, monkeypatch: MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)

    result = runner.invoke(
        app_module.app,
        [
            "contract",
            "edit",
            "--modes",
            "generate,search,index",
            "--mode-inputs",
            "generate=text,image",
            "--mode-outputs",
            "generate=text",
            "--mode-inputs",
            "search=image",
            "--mode-inputs",
            "index=image",
            "--json",
        ],
    )

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["ok"] is True
    assert payload["data"]["resources"]["vector_db"] is False
    assert payload["data"]["modes"]["generate"]["outputs"] == ["text"]
    assert payload["data"]["modes"]["search"]["inputs"] == [
        {"name": "image", "kind": "image", "required": True, "description": "", "multiple": False}
    ]
    assert payload["data"]["modes"]["index"]["inputs"] == [
        {"name": "image", "kind": "image", "required": True, "description": "", "multiple": False}
    ]
    contract_text = (tmp_path / PROJECT_CONFIG_RELATIVE_PATH).read_text(encoding="utf-8")
    assert "schema_version = 3" in contract_text
    assert "[capabilities]" in contract_text
    assert "vector = false" in contract_text
    assert "[modes.generate]" in contract_text
    assert "[modes.search]" in contract_text
    assert "[modes.index]" in contract_text


def test_contract_edit_vector_db_flag_preserves_default_public_modes(
    tmp_path: Path, monkeypatch: MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)

    result = runner.invoke(
        app_module.app,
        [
            "contract",
            "edit",
            "--vector-db",
            "--json",
        ],
    )

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["data"]["resources"]["vector_db"] is True
    assert set(payload["data"]["modes"]) == {"generate"}


def test_contract_edit_supports_generate_and_search_without_index(
    tmp_path: Path, monkeypatch: MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)

    result = runner.invoke(
        app_module.app,
        [
            "contract",
            "edit",
            "--modes",
            "generate,search",
            "--json",
        ],
    )

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["data"]["resources"]["vector_db"] is False
    assert set(payload["data"]["modes"]) == {"generate", "search"}


def test_contract_edit_supports_search_only_with_vector_db(
    tmp_path: Path, monkeypatch: MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)

    result = runner.invoke(
        app_module.app,
        [
            "contract",
            "edit",
            "--modes",
            "search",
            "--vector-db",
            "--mode-inputs",
            "search=image",
            "--json",
        ],
    )

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["data"]["resources"]["vector_db"] is True
    assert set(payload["data"]["modes"]) == {"search"}
    assert payload["data"]["modes"]["search"]["inputs"] == [
        {"name": "image", "kind": "image", "required": True, "description": "", "multiple": False}
    ]


def test_contract_edit_supports_arbitrary_modes_with_generic_flags(
    tmp_path: Path, monkeypatch: MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)

    result = runner.invoke(
        app_module.app,
        [
            "contract",
            "edit",
            "--modes",
            "rank,rerank",
            "--mode-inputs",
            "rank=text,json",
            "--mode-outputs",
            "rerank=json",
            "--json",
        ],
    )

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["data"]["resources"]["vector_db"] is False
    assert set(payload["data"]["modes"]) == {"rank", "rerank"}
    assert payload["data"]["modes"]["rank"]["inputs"] == [
        {"name": "text", "kind": "text", "required": True, "description": "", "multiple": False},
        {"name": "json", "kind": "json", "required": True, "description": "", "multiple": False},
    ]
    assert payload["data"]["modes"]["rerank"]["outputs"] == ["json"]


def test_contract_edit_allows_search_without_vector_db(
    tmp_path: Path, monkeypatch: MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)

    result = runner.invoke(
        app_module.app,
        [
            "contract",
            "edit",
            "--modes",
            "search",
            "--no-vector-db",
            "--json",
        ],
    )

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["data"]["resources"]["vector_db"] is False
    assert set(payload["data"]["modes"]) == {"search"}


def test_contract_edit_rejects_mode_inputs_when_mode_disabled(
    tmp_path: Path, monkeypatch: MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)

    result = runner.invoke(
        app_module.app,
        [
            "contract",
            "edit",
            "--modes",
            "search",
            "--vector-db",
            "--mode-inputs",
            "generate=text",
            "--json",
        ],
    )

    assert result.exit_code != 0
    assert "mode input/output flags require enabled modes: generate" in result.stdout


def test_prompt_public_modes_passes_console_to_prompt_wrapper() -> None:
    console_marker = object()
    captured_console: list[Any] = []

    def fake_prompt_text(
        message: str,
        *,
        console: Any,
        default: str | None = None,
        show_header: bool = False,
        title: str | None = None,
        subtitle: str | None = None,
        details: Any | None = None,
    ) -> str:
        _ = message, default, show_header, title, subtitle, details
        captured_console.append(console)
        return "search"

    runtime = SimpleNamespace(
        require_tty=lambda: None,
        prompt_text=fake_prompt_text,
        console=console_marker,
    )

    result = app_module.contract_commands.prompt_public_operations(
        runtime=runtime,
        default=["generate"],
    )

    assert result == ["search"]
    assert captured_console == [console_marker]


def test_prompt_contract_config_search_only_skips_vector_prompt(
    monkeypatch: MonkeyPatch,
) -> None:
    prompt_vector_defaults: list[bool] = []

    def fake_prompt_public_modes(*, default: list[str]) -> list[str]:
        assert default == ["generate"]
        return ["search"]

    monkeypatch.setattr(app_module, "_prompt_public_modes", fake_prompt_public_modes)
    monkeypatch.setattr(
        app_module,
        "_prompt_vector_db_support",
        lambda **kwargs: prompt_vector_defaults.append(kwargs["default"]) or False,
    )
    monkeypatch.setattr(app_module, "_prompt_fine_tune_support", lambda **kwargs: False)

    config = app_module._prompt_contract_config()
    assert prompt_vector_defaults == [False]

    assert config == ProjectConfig(
        schema_version=3,
        capabilities={"vector": False, "tuning": False},
        resources=ResourceConfig(vector_db=False),
        modes=ModesConfig(
            {
                "search": ModeContract(
                    inputs=[InputDefinition(name="text", kind="text", required=True)]
                ),
            }
        ),
    )


def test_prompt_contract_config_generate_only_skips_vector_prompt(
    monkeypatch: MonkeyPatch,
) -> None:
    prompt_vector_defaults: list[bool] = []

    def fake_prompt_public_modes(*, default: list[str]) -> list[str]:
        assert default == ["generate"]
        return ["generate"]

    monkeypatch.setattr(app_module, "_prompt_public_modes", fake_prompt_public_modes)
    monkeypatch.setattr(
        app_module,
        "_prompt_vector_db_support",
        lambda **kwargs: prompt_vector_defaults.append(kwargs["default"]) or False,
    )
    monkeypatch.setattr(app_module, "_prompt_fine_tune_support", lambda **kwargs: False)

    config = app_module._prompt_contract_config()
    assert prompt_vector_defaults == [False]

    assert config == ProjectConfig(
        schema_version=3,
        capabilities={"vector": False, "tuning": False},
        resources=ResourceConfig(vector_db=False),
        modes=ModesConfig(
            {
                "generate": ModeContract(
                    inputs=[InputDefinition(name="prompt", kind="text", required=True)],
                    outputs=["text"],
                ),
            }
        ),
    )


def test_contract_show_resolved_defaults_to_generate(
    tmp_path: Path, monkeypatch: MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    (tmp_path / ".aimp").mkdir()
    (tmp_path / "app").mkdir()
    (tmp_path / PROJECT_CONFIG_RELATIVE_PATH).write_text(
        "schema_version = 3\n\n"
        "[capabilities]\n"
        "vector = false\n"
        "tuning = false\n\n"
        "[modes.generate]\n"
        "enabled = true\n"
        'outputs = ["text"]\n\n'
        "[[modes.generate.inputs]]\n"
        'name = "text"\n'
        'kind = "text"\n'
        "required = true\n",
        encoding="utf-8",
    )

    result = runner.invoke(app_module.app, ["contract", "show", "--json"])

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["ok"] is True
    assert payload["data"]["resources"]["vector_db"] is False
    assert payload["data"]["modes"]["generate"]["inputs"] == [
        {"name": "text", "kind": "text", "required": True, "description": "", "multiple": False}
    ]


def test_contract_migrate_command_removed(tmp_path: Path, monkeypatch: MonkeyPatch) -> None:
    monkeypatch.chdir(tmp_path)
    (tmp_path / "aimp.config.toml").write_text(
        '[interface.input]\nprimary = "text"\nattachments = ["image"]\n\n'
        '[interface.output]\nprimary = "text"\nattachments = []\n\n'
        '[capabilities]\nactions = ["search"]\n',
        encoding="utf-8",
    )

    result = runner.invoke(app_module.app, ["contract", "migrate", "--json"])

    assert result.exit_code != 0
    assert "No such command 'migrate'" in result.stdout


def test_publish_configuration_wizard_selects_supported_tiers_without_default(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    prompt_values = iter(
        [
            "Demo Model",
            "agents, codex",
            "studio/article.mdx",
            "0.25",
        ]
    )

    class FakeGateway:
        def get_publish_metadata(self) -> Any:
            return SimpleNamespace(
                hardware_tiers=[
                    SimpleNamespace(
                        id="cpu-basic",
                        label="CPU Basic",
                        description="CPU tier",
                        base_cost_hourly=0.05,
                    ),
                    SimpleNamespace(
                        id="gpu-t4",
                        label="NVIDIA T4",
                        description="GPU tier",
                        base_cost_hourly=0.50,
                    ),
                ],
                platform_fee_pct=0.3,
            )

    recorded_titles: list[str] = []
    recorded_defaults: list[str | None] = []

    def fake_prompt_text(
        message: str,
        console: Any,
        default: str | None = None,
        show_header: bool = False,
        title: str | None = None,
        subtitle: str | None = None,
        details: Any | None = None,
    ) -> str:
        _ = console, show_header, subtitle, details
        recorded_titles.append(title or message)
        recorded_defaults.append(default)
        return next(prompt_values)

    monkeypatch.setattr(
        publish_config_module,
        "prompt_text",
        fake_prompt_text,
    )
    monkeypatch.setattr(
        publish_config_module,
        "select_menu",
        lambda sections, show_header=True, title=None, subtitle=None, details=None: next(
            option for option in sections[0].options if option.key == "private"
        ),
    )

    def fake_select_multi_menu(
        sections: list[Any],
        preselected_keys: list[str] | None = None,
        show_header: bool = True,
        title: str | None = None,
        subtitle: str | None = None,
        details: Any | None = None,
    ) -> list[str]:
        _ = sections, preselected_keys, show_header, title, subtitle, details
        return ["cpu-basic", "gpu-t4"]

    def fake_confirm_action(
        message: str,
        console: Any,
        default: bool = True,
        confirm_label: str = "Confirm",
        cancel_label: str = "Cancel",
        confirm_description: str = "Proceed with this action.",
        cancel_description: str = "Return without making changes.",
        show_header: bool = False,
        title: str | None = None,
        subtitle: str | None = None,
        details: Any | None = None,
    ) -> bool:
        _ = (
            message,
            console,
            default,
            confirm_label,
            cancel_label,
            confirm_description,
            cancel_description,
            show_header,
            title,
            subtitle,
            details,
        )
        return True

    monkeypatch.setattr(
        publish_config_module,
        "select_multi_menu",
        fake_select_multi_menu,
    )
    monkeypatch.setattr(
        publish_config_module,
        "confirm_action",
        fake_confirm_action,
    )

    config = publish_config_module.run_publish_configuration_wizard(
        project_dir=tmp_path,
        gateway=FakeGateway(),
        existing_config=None,
        console=app_module.console,
        interactive_terminal=True,
    )

    assert config.hardware.model_dump() == {"supported_tiers": ["cpu-basic", "gpu-t4"]}
    assert config.pricing == {"developer_margin": 0.25}
    assert config.studio.visibility == "private"
    assert recorded_titles == [
        "Studio Name",
        "Tags",
        "Article Path",
        "Developer Margin",
    ]
    assert recorded_defaults[0] is None


def test_main_without_args_uses_launcher_on_tty(monkeypatch: MonkeyPatch) -> None:
    calls: list[str] = []

    monkeypatch.setattr(sys, "argv", ["ai"])
    monkeypatch.setattr(sys, "stdin", FakeTTYStream(is_tty=True))
    monkeypatch.setattr(sys, "stdout", FakeTTYStream(is_tty=True))
    monkeypatch.setattr(app_module, "interactive_launcher", lambda: calls.append("launcher"))

    app_module.main()

    assert calls == ["launcher"]


def test_main_without_args_prints_help_without_tty(monkeypatch: MonkeyPatch) -> None:
    fake_command = FakeCommand()

    monkeypatch.setattr(sys, "argv", ["ai"])
    monkeypatch.setattr(sys, "stdin", FakeTTYStream(is_tty=False))
    monkeypatch.setattr(sys, "stdout", FakeTTYStream(is_tty=False))
    monkeypatch.setattr(app_module, "get_command", lambda _app: fake_command)

    app_module.main()

    assert fake_command.calls == [{"args": ["--help"], "prog_name": "ai", "standalone_mode": False}]


def test_launcher_model_actions_prompt_for_slug(monkeypatch: MonkeyPatch) -> None:
    inspect_calls: list[dict[str, Any]] = []
    pull_calls: list[dict[str, Any]] = []
    captured_callbacks: list[Any] = []

    monkeypatch.setattr(app_module, "model_inspect", lambda **kwargs: inspect_calls.append(kwargs))
    monkeypatch.setattr(app_module, "model_pull", lambda **kwargs: pull_calls.append(kwargs))
    monkeypatch.setattr(
        app_module,
        "run_interactive_launcher_flow",
        lambda *, console, config_store, callbacks: captured_callbacks.append(callbacks),
    )

    app_module.interactive_launcher()
    callbacks = captured_callbacks[0]
    inspect_result = callbacks.inspect_model("demo-model")
    pull_result = callbacks.pull_model("demo-model")

    assert inspect_calls == [
        {
            "slug": "demo-model",
            "asset_id": None,
            "modes": None,
            "gateway": None,
            "api_key": None,
            "json_output": False,
            "debug": False,
        }
    ]
    assert isinstance(inspect_result, LauncherActionResult)
    assert inspect_result.title == "Inspect Model"
    assert pull_calls == [
        {
            "slug": "demo-model",
            "asset_id": None,
            "gateway": None,
            "api_key": None,
            "json_output": False,
            "debug": False,
        }
    ]
    assert isinstance(pull_result, LauncherActionResult)
    assert pull_result.title == "Pull Metadata"


def test_launcher_project_actions_dispatch_to_contract_and_publish_commands(
    monkeypatch: MonkeyPatch,
) -> None:
    captured_callbacks: list[Any] = []
    project_configure_calls: list[dict[str, Any]] = []
    contract_validate_calls: list[dict[str, Any]] = []
    contract_show_calls: list[dict[str, Any]] = []
    publish_calls: list[dict[str, Any]] = []

    monkeypatch.setattr(
        app_module,
        "project_configure",
        lambda **kwargs: project_configure_calls.append(kwargs),
    )
    monkeypatch.setattr(
        app_module,
        "contract_validate",
        lambda **kwargs: contract_validate_calls.append(kwargs),
    )
    monkeypatch.setattr(
        app_module,
        "contract_show",
        lambda **kwargs: contract_show_calls.append(kwargs),
    )
    monkeypatch.setattr(app_module, "publish", lambda **kwargs: publish_calls.append(kwargs))
    monkeypatch.setattr(
        app_module,
        "run_interactive_launcher_flow",
        lambda *, console, config_store, callbacks: captured_callbacks.append(callbacks),
    )

    app_module.interactive_launcher()
    callbacks = captured_callbacks[0]
    configure_result = callbacks.configure_project()
    validate_result = callbacks.validate_contract()
    show_result = callbacks.show_contract()
    publish_result = callbacks.configure_publish()

    assert project_configure_calls == [
        {
            "modes": None,
            "mode_inputs": None,
            "mode_outputs": None,
            "vector_db": None,
            "fine_tune": None,
            "json_output": False,
            "debug": False,
        }
    ]
    assert contract_validate_calls == [
        {
            "json_output": False,
            "debug": False,
        }
    ]
    assert isinstance(configure_result, LauncherActionResult)
    assert configure_result.title == "Configure Project"
    assert isinstance(validate_result, LauncherActionResult)
    assert validate_result.title == "Validate Contract"
    assert isinstance(show_result, LauncherActionResult)
    assert show_result.title == "Show Contract"
    assert isinstance(publish_result, LauncherActionResult)
    assert publish_result.title == "Configure Publish"
    assert contract_show_calls == [
        {
            "json_output": False,
            "debug": False,
        }
    ]
    assert publish_calls == [
        {
            "gateway": None,
            "api_key": None,
            "parallel": 3,
            "configure": True,
            "verbose": False,
            "python_bin": None,
            "json_output": False,
            "debug": False,
        }
    ]


def test_fine_tune_get_human_output_shows_publishable_derived_model_hints(
    monkeypatch: MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        app_module,
        "resolve_auth_context",
        lambda **_kwargs: SimpleNamespace(api_key="pk_test", gateway_url="http://localhost:8080"),
    )
    monkeypatch.setattr(app_module, "GatewayClient", FakeFineTuneGateway)

    result = runner.invoke(
        app_module.app,
        [
            "fine-tune",
            "get",
            "--job",
            "job-1",
        ],
    )

    assert result.exit_code == 0
    assert "Derived model slug" in result.stdout
    assert "vision-pro-tuned" in result.stdout
    assert "ai model inspect --slug vision-pro-tuned" in result.stdout
    assert 'client.models.execute(model="vision-pro-tuned"' in result.stdout


def test_publish_remote_slug_path_uses_gateway_publish_without_local_build(
    monkeypatch: MonkeyPatch,
) -> None:
    class FakeRemotePublishGateway:
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            _ = args, kwargs

        def publish_model_by_slug(self, slug: str) -> PublishResponse:
            assert slug == "vision-pro-tuned"
            return PublishResponse(
                id="derived-1",
                slug=slug,
                visibility="public",
                readiness={"is_ready": True, "blocking_reasons": []},
                url="http://localhost:3000/studio/models/vision-pro-tuned",
            )

        def close(self) -> None:
            return None

    monkeypatch.setattr(
        app_module,
        "resolve_auth_context",
        lambda **_kwargs: SimpleNamespace(api_key="pk_test", gateway_url="http://localhost:8080"),
    )
    monkeypatch.setattr(app_module, "GatewayClient", FakeRemotePublishGateway)

    result = runner.invoke(
        app_module.app,
        [
            "publish",
            "--slug",
            "vision-pro-tuned",
            "--json",
        ],
    )

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["ok"] is True
    assert payload["data"]["slug"] == "vision-pro-tuned"
    assert payload["data"]["visibility"] == "public"


def test_interactive_launcher_delegates_to_shared_flow(monkeypatch: MonkeyPatch) -> None:
    captured_calls: list[dict[str, Any]] = []

    def fake_launcher_flow(*, console: Any, config_store: Any, callbacks: Any) -> None:
        captured_calls.append(
            {
                "console": console,
                "config_store": config_store,
                "callbacks": callbacks,
            }
        )

    monkeypatch.setattr(app_module, "run_interactive_launcher_flow", fake_launcher_flow)

    app_module.interactive_launcher()

    assert len(captured_calls) == 1
    assert captured_calls[0]["config_store"] is config_store


def test_launcher_init_prompts_for_name_and_confirms(monkeypatch: MonkeyPatch) -> None:
    init_calls: list[dict[str, Any]] = []
    captured_callbacks: list[Any] = []

    monkeypatch.setattr(app_module, "init", lambda **kwargs: init_calls.append(kwargs))
    monkeypatch.setattr(
        app_module,
        "run_interactive_launcher_flow",
        lambda *, console, config_store, callbacks: captured_callbacks.append(callbacks),
    )

    app_module.interactive_launcher()
    callbacks = captured_callbacks[0]
    callbacks.init_project("demo-model")

    assert init_calls == [
        {
            "name": "demo-model",
            "yes": True,
            "json_output": False,
            "debug": False,
        }
    ]


def test_launcher_login_prompts_for_gateway_and_api_key(monkeypatch: MonkeyPatch) -> None:
    config_store.clear()
    login_calls: list[dict[str, Any]] = []
    captured_callbacks: list[Any] = []

    monkeypatch.setattr(config_store, "get_gateway_url", lambda: "http://localhost:8080")
    monkeypatch.setattr(app_module, "login", lambda **kwargs: login_calls.append(kwargs))
    monkeypatch.setattr(
        app_module,
        "run_interactive_launcher_flow",
        lambda *, console, config_store, callbacks: captured_callbacks.append(callbacks),
    )

    app_module.interactive_launcher()
    callbacks = captured_callbacks[0]
    result = callbacks.login("http://localhost:8080", "pk_live")

    assert login_calls == [
        {
            "gateway": "http://localhost:8080",
            "api_key": "pk_live",
            "stdin": False,
            "json_output": False,
            "debug": False,
        }
    ]
    assert isinstance(result, LauncherActionResult)
    assert result.title == "Login"


def test_launcher_jobs_callbacks_use_structured_json_and_detail_output(
    monkeypatch: MonkeyPatch,
) -> None:
    captured_callbacks: list[Any] = []
    jobs_list_calls: list[dict[str, Any]] = []
    jobs_get_calls: list[dict[str, Any]] = []

    def fake_jobs_list(**kwargs: Any) -> None:
        jobs_list_calls.append(kwargs)
        config_module.console.print_json(
            json.dumps(
                {
                    "ok": True,
                    "data": {
                        "results": [
                            {
                                "job_type": "build",
                                "job_id": "build-1",
                                "model_slug": "vision-pro",
                                "status": "running",
                                "created_at": "2026-03-18T10:00:00Z",
                            }
                        ]
                    },
                }
            )
        )

    def fake_jobs_get(**kwargs: Any) -> None:
        jobs_get_calls.append(kwargs)
        config_module.console.print("Loaded build job build-1")

    monkeypatch.setattr(app_module, "jobs_list", fake_jobs_list)
    monkeypatch.setattr(app_module, "jobs_get", fake_jobs_get)
    monkeypatch.setattr(
        app_module,
        "run_interactive_launcher_flow",
        lambda *, console, config_store, callbacks: captured_callbacks.append(callbacks),
    )

    app_module.interactive_launcher()
    callbacks = captured_callbacks[0]
    jobs = callbacks.list_jobs("build")
    detail_result = callbacks.get_job_detail("build", "build-1")

    assert jobs_list_calls == [
        {
            "type": "build",
            "model": None,
            "status": None,
            "page": 1,
            "page_size": 20,
            "gateway": None,
            "api_key": None,
            "json_output": True,
            "debug": False,
        }
    ]
    assert isinstance(jobs, list)
    assert jobs == [
        LauncherJobItem(
            job_id="build-1",
            job_type="build",
            model_slug="vision-pro",
            status="running",
            created_at="2026-03-18T10:00:00Z",
        )
    ]
    assert jobs_get_calls == [
        {
            "type": "build",
            "job": "build-1",
            "gateway": None,
            "api_key": None,
            "json_output": False,
            "debug": False,
        }
    ]
    assert isinstance(detail_result, LauncherActionResult)
    assert detail_result.title == "Job Details"
    assert "Loaded build job build-1" in detail_result.content


def test_run_interactive_action_captures_human_output() -> None:
    result = app_module._run_interactive_action(
        title="Validate Contract",
        subtitle="Validate the local hidden contract file.",
        status="success",
        fallback_success_message="Validated contract.",
        callback=lambda: config_module.console.print("Validated: .aimp/project.toml"),
    )

    assert result is not None
    assert result.status == "success"
    assert "Validated: .aimp/project.toml" in result.content


def test_run_interactive_action_converts_exit_errors_to_detail_result() -> None:
    def failing_callback() -> None:
        config_module.console.print("Not authenticated. Run: ai login")
        raise typer.Exit(code=5)

    result = app_module._run_interactive_action(
        title="Publish Project",
        subtitle="Build and push the current local project.",
        status="success",
        fallback_success_message="Publish completed.",
        callback=failing_callback,
    )

    assert result is not None
    assert result.status == "error"
    assert "Not authenticated. Run: ai login" in result.content
