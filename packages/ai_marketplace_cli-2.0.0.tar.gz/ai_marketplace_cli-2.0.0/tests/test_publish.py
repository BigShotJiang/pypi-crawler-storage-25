"""Tests for CLI publish helpers."""

from __future__ import annotations

import json
import subprocess
import sys
import tarfile
from collections.abc import Callable
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import pytest
from rich.console import Console
from rich.progress import SpinnerColumn, TextColumn

from aimp_cli.core.config import build_command_context
from aimp_cli.clients.docker import DockerAccessStatus, RegistryAuthStatus
from aimp_cli.core.errors import CliError
from aimp_cli.domain.models import (
    CapabilitiesConfig,
    InputDefinition,
    ModeContract,
    ModeResourcesConfig,
    ModeReadinessPayload,
    ModesConfig,
    PublishBuildJob,
    PublishBuildJobCreateRequest,
    PublishBuildJobListResponse,
    PublishRequest,
    PublishResponse,
    ResourceConfig,
    StudioPublishPayload,
    VectorCollectionConfig,
    VectorResourceCollectionsConfig,
)
from aimp_cli.domain.project import (
    FINE_TUNE_MODULE_RELATIVE_PATH,
    FINE_TUNE_SCHEMA_MODULE_RELATIVE_PATH,
    ProjectConfig,
    default_tuning_workspace_config,
)
from aimp_cli.domain.publish_config import resolve_studio_file_paths
from aimp_cli.domain.protocols import PublishGatewayProtocol, UploadClientProtocol
from aimp_cli.domain.runtime_packages import OFFICIAL_RUNTIME_DEPENDENCY_SPECS
from aimp_cli.operations.publish.core import (
    _find_active_publish_build_job,
    _load_runtime_dependency_specs,
    _build_studio_publish_payload,
    _build_contract_python_candidates,
    _confirm_remote_build_cancel,
    _format_runtime_package_index_targets,
    _reject_legacy_runtime_path_sources,
    _managed_progress,
    _managed_status,
    _wait_for_runtime_package_index_visibility,
    _verify_runtime_packages_downloadable,
    build_mode_readiness_payload,
    build_publish_payload,
    create_source_bundle_archive,
    extract_contract_from_python,
    extract_mode_readiness_from_python,
    publish_model_by_slug,
    run_publish,
    wait_for_publish_build_job,
)
from aimp_cli.operations.scaffold.init_project import create_project_scaffold


@dataclass(slots=True)
class FakeUploadResult:
    """Minimal upload result used by publish tests."""

    storage_uri: str
    artifact_id: str = "artifact-1"
    size_bytes: int = 1


class FakeDockerBase:
    """Typed Docker test double implementing the publish protocol."""

    def inspect_daemon_access(self) -> DockerAccessStatus:
        return DockerAccessStatus(ok=True)

    def build_image(
        self,
        *,
        context_dir: Path,
        tag: str,
        dockerfile: str | None,
        on_line: Callable[[str], None],
    ) -> None:
        _ = context_dir, tag, dockerfile, on_line

    def verify_runtime_sdk(self, image_tag: str) -> None:
        _ = image_tag

    def tag_image(self, source: str, target: str) -> None:
        _ = source, target

    def push_image(self, image_ref: str, on_line: Callable[[str], None]) -> None:
        _ = image_ref, on_line

    def get_image_manifest(self, image_ref: str) -> ImageManifest:
        _ = image_ref
        return ImageManifest(
            digest="sha256:test",
            total_size=1,
            raw_manifest={},
            layers=[ImageManifestLayer(digest="sha256:layer", size=1)],
            media_type="application/vnd.oci.image.manifest.v1+json",
        )

    def save_image(self, image_tag: str, output_path: Path) -> None:
        _ = image_tag
        output_path.write_text("archive", encoding="utf-8")

    def get_registry_auth_status(self, registry_host: str) -> RegistryAuthStatus:
        _ = registry_host
        return RegistryAuthStatus(
            state="configured",
            message="Docker registry credentials configured",
        )

    def get_registry_basic_auth_header(self, registry_host: str) -> str | None:
        _ = registry_host
        return None


class FakeGatewayBase:
    """Typed Gateway test double implementing the publish protocol."""

    def __init__(self) -> None:
        self.build_job_request: PublishBuildJobCreateRequest | None = None
        self.build_job = PublishBuildJob(
            job_id="job-1",
            slug="demo-model",
            version="0.1.0",
            status="succeeded",
        )
        self.stream_lines: list[str] | None = None

    def get_model(self, slug: str) -> None:
        _ = slug
        return None

    def upload_studio_media(
        self,
        *,
        file_path: Path,
        media_type: str,
    ) -> dict[str, Any]:
        _ = file_path, media_type
        return {
            "storage_uri": "s3://studio/media/object",
            "public_url": "https://cdn.example.com/object",
        }

    def create_publish_build_job(
        self,
        request: PublishBuildJobCreateRequest,
    ) -> PublishBuildJob:
        self.build_job_request = request
        return self.build_job

    def get_publish_build_job(self, job_id: str) -> PublishBuildJob:
        assert job_id == self.build_job.job_id
        return self.build_job

    @contextmanager
    def stream_job(self, job_id: str) -> Any:
        job = {
            "job_id": job_id,
            "job_type": "build",
            "model_slug": self.build_job.slug,
            "status": self.build_job.status,
            "timeline": self.build_job.timeline or [],
            "logs": self.build_job.logs or [],
            "details": {"version": self.build_job.version},
        }
        snapshot_payload = {
            "job": job,
            "timeline_count": len(job["timeline"]),
            "log_count": len(job["logs"]),
        }
        lines = self.stream_lines or [
            "event: snapshot",
            f"data: {json.dumps(snapshot_payload)}",
            "",
            "event: terminal",
            f"data: {json.dumps(snapshot_payload)}",
            "",
        ]
        yield iter(lines)

    def list_publish_build_jobs(
        self,
        *,
        model_slug: str | None = None,
        status: str | None = None,
        page: int = 1,
        page_size: int = 20,
    ) -> PublishBuildJobListResponse:
        _ = model_slug, status, page, page_size
        return PublishBuildJobListResponse(results=[], pagination={"total_items": 0})

    def cancel_publish_build_job(self, job_id: str) -> Any:
        assert job_id == self.build_job.job_id
        return SimpleNamespace(cancel_state="canceled")

    def delete_publish_build_job(self, job_id: str) -> None:
        assert job_id == self.build_job.job_id

    def publish(self, request: PublishRequest | dict[str, Any]) -> PublishResponse:
        _ = request
        raise NotImplementedError

    def publish_model_by_slug(self, slug: str) -> PublishResponse:
        _ = slug
        raise NotImplementedError


@pytest.fixture(autouse=True)
def _stub_runtime_dependency_checks(monkeypatch: pytest.MonkeyPatch) -> None:
    """Keep publish tests focused on orchestration, not external package indexes."""
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._load_runtime_dependency_specs",
        lambda project_dir: {
            "ai-marketplace-framework": OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-framework"],
            "ai-marketplace-sdk": OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-sdk"],
        },
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._verify_runtime_packages_downloadable",
        lambda **kwargs: None,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._reject_legacy_runtime_path_sources",
        lambda project_dir: None,
    )


def test_load_runtime_dependency_specs_requires_exact_runtime_pins(tmp_path: Path) -> None:
    (tmp_path / "pyproject.toml").write_text(
        "\n".join(
            [
                "[project]",
                'name = "demo"',
                "dependencies = [",
                '    "ai-marketplace-framework>=0.1.1,<0.2.0",',
                '    "ai-marketplace-sdk==0.2.0",',
                '    "pydantic>=2.10,<3",',
                "]",
            ]
        ),
        encoding="utf-8",
    )

    with pytest.raises(CliError) as exc_info:
        _load_runtime_dependency_specs(tmp_path)

    assert exc_info.value.code == "runtime_dependencies_must_be_exact"
    assert OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-framework"] in exc_info.value.message
    assert "ai-marketplace-framework>=0.1.1,<0.2.0" in exc_info.value.message


def test_reject_legacy_runtime_path_sources_fails_with_remediation(tmp_path: Path) -> None:
    (tmp_path / "pyproject.toml").write_text(
        "\n".join(
            [
                "[project]",
                'name = "demo"',
                "dependencies = [",
                f'    "{OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-framework"]}",',
                f'    "{OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-sdk"]}",',
                "]",
                "",
                "[tool.uv.sources]",
                'ai-marketplace-framework = { path = "../framework/python" }',
                'ai-marketplace-sdk = { path = "../sdk/python" }',
            ]
        ),
        encoding="utf-8",
    )

    with pytest.raises(CliError) as exc_info:
        _reject_legacy_runtime_path_sources(tmp_path)

    assert exc_info.value.code == "runtime_path_sources_unsupported"
    assert "Remove [tool.uv.sources] from pyproject.toml" in exc_info.value.message
    assert "published PyPI packages only" in exc_info.value.message


def test_verify_runtime_packages_downloadable_uses_uv_without_pip(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[dict[str, Any]] = []

    monkeypatch.delenv("AIMP_PYTHON_PACKAGE_EXTRA_INDEX_URL", raising=False)
    monkeypatch.delenv("AIMP_PYTHON_PACKAGE_INDEX_USERNAME", raising=False)
    monkeypatch.delenv("AIMP_PYTHON_PACKAGE_INDEX_PASSWORD", raising=False)

    def _fake_run(cmd: list[str], **kwargs: Any) -> subprocess.CompletedProcess[str]:
        calls.append({"cmd": cmd, "env": kwargs.get("env")})
        return subprocess.CompletedProcess(cmd, 0, stdout="", stderr="")

    monkeypatch.setattr("aimp_cli.operations.publish.core.shutil.which", lambda name: "/usr/bin/uv")
    monkeypatch.setattr("aimp_cli.operations.publish.core.subprocess.run", _fake_run)
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._wait_for_runtime_package_index_visibility",
        lambda **_: None,
    )

    _verify_runtime_packages_downloadable(
        dependency_specs={
            "ai-marketplace-framework": OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-framework"],
            "ai-marketplace-sdk": OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-sdk"],
        },
        python_bin="/tmp/python-no-pip",
        python_package_index=None,
    )

    assert len(calls) == 1
    assert calls[0]["cmd"][:7] == [
        "/usr/bin/uv",
        "pip",
        "install",
        "--dry-run",
        "--no-deps",
        "--no-sources",
        "--target",
    ]
    assert calls[0]["cmd"][8:] == [
        "--python",
        "/tmp/python-no-pip",
        OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-framework"],
        OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-sdk"],
    ]
    assert "UV_INDEX" not in (calls[0]["env"] or {})


def test_verify_runtime_packages_downloadable_uses_private_index_env(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    captured: dict[str, Any] = {}

    def _fake_run(cmd: list[str], **kwargs: Any) -> subprocess.CompletedProcess[str]:
        captured["cmd"] = cmd
        captured["env"] = kwargs.get("env") or {}
        return subprocess.CompletedProcess(cmd, 0, stdout="", stderr="")

    monkeypatch.setenv(
        "AIMP_PYTHON_PACKAGE_EXTRA_INDEX_URL",
        "https://pip.pkg.github.com/acme/simple",
    )
    monkeypatch.setenv("AIMP_PYTHON_PACKAGE_INDEX_USERNAME", "octocat")
    monkeypatch.setenv("AIMP_PYTHON_PACKAGE_INDEX_PASSWORD", "ghp_test_token")
    monkeypatch.setattr("aimp_cli.operations.publish.core.shutil.which", lambda name: "/usr/bin/uv")
    monkeypatch.setattr("aimp_cli.operations.publish.core.subprocess.run", _fake_run)
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._wait_for_runtime_package_index_visibility",
        lambda **_: None,
    )

    _verify_runtime_packages_downloadable(
        dependency_specs={
            "ai-marketplace-framework": OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-framework"],
            "ai-marketplace-sdk": OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-sdk"],
        },
        python_bin=None,
        python_package_index=None,
    )

    assert captured["cmd"][:4] == ["/usr/bin/uv", "pip", "install", "--dry-run"]
    assert "--extra-index-url" in captured["cmd"]
    index_arg = captured["cmd"].index("--extra-index-url")
    assert (
        captured["cmd"][index_arg + 1]
        == "https://octocat:ghp_test_token@pip.pkg.github.com/acme/simple"
    )
    assert "UV_INDEX" not in captured["env"]


def test_verify_runtime_packages_downloadable_accepts_unauthenticated_extra_index(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    captured: dict[str, Any] = {}

    def _fake_run(cmd: list[str], **kwargs: Any) -> subprocess.CompletedProcess[str]:
        captured["cmd"] = cmd
        captured["env"] = kwargs.get("env") or {}
        return subprocess.CompletedProcess(cmd, 0, stdout="", stderr="")

    monkeypatch.setenv("AIMP_PYTHON_PACKAGE_EXTRA_INDEX_URL", "https://test.pypi.org/simple/")
    monkeypatch.delenv("AIMP_PYTHON_PACKAGE_INDEX_USERNAME", raising=False)
    monkeypatch.delenv("AIMP_PYTHON_PACKAGE_INDEX_PASSWORD", raising=False)
    monkeypatch.setattr("aimp_cli.operations.publish.core.shutil.which", lambda name: "/usr/bin/uv")
    monkeypatch.setattr("aimp_cli.operations.publish.core.subprocess.run", _fake_run)
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._wait_for_runtime_package_index_visibility",
        lambda **_: None,
    )

    _verify_runtime_packages_downloadable(
        dependency_specs={
            "ai-marketplace-framework": OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-framework"],
            "ai-marketplace-sdk": OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-sdk"],
        },
        python_bin=None,
        python_package_index=None,
    )

    assert "--extra-index-url" in captured["cmd"]
    index_arg = captured["cmd"].index("--extra-index-url")
    assert captured["cmd"][index_arg + 1] == "https://test.pypi.org/simple/"
    assert "UV_INDEX" not in captured["env"]


def test_verify_runtime_packages_downloadable_rejects_partial_extra_index_credentials(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv(
        "AIMP_PYTHON_PACKAGE_EXTRA_INDEX_URL",
        "https://pip.pkg.github.com/acme/simple",
    )
    monkeypatch.delenv("AIMP_PYTHON_PACKAGE_INDEX_USERNAME", raising=False)
    monkeypatch.setenv("AIMP_PYTHON_PACKAGE_INDEX_PASSWORD", "ghp_test_token")
    monkeypatch.setattr("aimp_cli.operations.publish.core.shutil.which", lambda name: "/usr/bin/uv")
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._wait_for_runtime_package_index_visibility",
        lambda **_: None,
    )

    with pytest.raises(CliError) as exc_info:
        _verify_runtime_packages_downloadable(
            dependency_specs={
                "ai-marketplace-framework": OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-framework"],
                "ai-marketplace-sdk": OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-sdk"],
            },
            python_bin=None,
            python_package_index=None,
        )

    assert exc_info.value.code == "python_package_index_config_incomplete"


def test_verify_runtime_packages_downloadable_surfaces_registry_failure(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def _fake_run(cmd: list[str], **kwargs: Any) -> subprocess.CompletedProcess[str]:
        _ = kwargs
        raise subprocess.CalledProcessError(
            returncode=1,
            cmd=cmd,
            stderr="No solution found when resolving dependencies",
        )

    monkeypatch.setattr("aimp_cli.operations.publish.core.shutil.which", lambda name: "/usr/bin/uv")
    monkeypatch.setattr("aimp_cli.operations.publish.core.subprocess.run", _fake_run)
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._wait_for_runtime_package_index_visibility",
        lambda **_: None,
    )

    with pytest.raises(CliError) as exc_info:
        _verify_runtime_packages_downloadable(
            dependency_specs={
                "ai-marketplace-framework": OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-framework"],
                "ai-marketplace-sdk": OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-sdk"],
            },
            python_bin=None,
            python_package_index=None,
        )

    assert exc_info.value.code == "runtime_packages_unavailable"
    assert "configured package index" in exc_info.value.message
    assert "https://pypi.org/simple/" in exc_info.value.message
    assert "No solution found when resolving dependencies" in exc_info.value.message


def test_wait_for_runtime_package_index_visibility_skips_when_index_check_is_indeterminate(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._missing_runtime_packages_from_indexes",
        lambda **_: None,
    )
    sleep_calls: list[float] = []
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.time.sleep",
        lambda seconds: sleep_calls.append(seconds),
    )

    _wait_for_runtime_package_index_visibility(
        dependency_specs={
            "ai-marketplace-framework": OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-framework"],
            "ai-marketplace-sdk": OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-sdk"],
        },
        python_package_index=None,
    )

    assert sleep_calls == []


def test_wait_for_runtime_package_index_visibility_waits_for_propagation(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    missing_responses = iter(
        [
            {"ai-marketplace-sdk": "0.2.0"},
            {},
        ]
    )
    messages: list[str] = []
    sleep_calls: list[float] = []

    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._missing_runtime_packages_from_indexes",
        lambda **_: next(missing_responses),
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.console.print",
        lambda message: messages.append(str(message)),
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.time.sleep",
        lambda seconds: sleep_calls.append(seconds),
    )

    _wait_for_runtime_package_index_visibility(
        dependency_specs={
            "ai-marketplace-framework": OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-framework"],
            "ai-marketplace-sdk": OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-sdk"],
        },
        python_package_index=None,
    )

    assert len(messages) == 1
    assert "ai-marketplace-sdk==0.2.0" in messages[0]
    assert sleep_calls == [10.0]


def test_wait_for_runtime_package_index_visibility_times_out_with_redacted_indexes(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._missing_runtime_packages_from_indexes",
        lambda **_: {"ai-marketplace-sdk": "0.2.0"},
    )
    monkeypatch.setattr("aimp_cli.operations.publish.core.time.sleep", lambda seconds: None)
    monkeypatch.setattr("aimp_cli.operations.publish.core.console.print", lambda message: None)

    with pytest.raises(CliError) as exc_info:
        _wait_for_runtime_package_index_visibility(
            dependency_specs={
                "ai-marketplace-framework": OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-framework"],
                "ai-marketplace-sdk": OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-sdk"],
            },
            python_package_index={
                "extra_index_url": "https://pip.pkg.github.com/acme/simple",
                "username": "octocat",
                "password": "ghp_secret",
                "authenticated_extra_index_url": (
                    "https://octocat:ghp_secret@pip.pkg.github.com/acme/simple"
                ),
            },
        )

    assert exc_info.value.code == "runtime_packages_unavailable"
    assert "ai-marketplace-sdk==0.2.0" in exc_info.value.message
    assert "https://pypi.org/simple/" in exc_info.value.message
    assert "https://pip.pkg.github.com/acme/simple/" in exc_info.value.message
    assert "ghp_secret" not in exc_info.value.message


def test_format_runtime_package_index_targets_redacts_credentials() -> None:
    formatted = _format_runtime_package_index_targets(
        {
            "extra_index_url": "https://pip.pkg.github.com/acme/simple",
            "authenticated_extra_index_url": (
                "https://octocat:ghp_secret@pip.pkg.github.com/acme/simple"
            ),
        }
    )

    assert formatted == "https://pypi.org/simple/, https://pip.pkg.github.com/acme/simple/"


def test_confirm_remote_build_cancel_non_tty_defaults_to_keep(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Non-interactive sessions should not auto-cancel remote builds."""

    class _StdinStub:
        @staticmethod
        def isatty() -> bool:
            return False

    monkeypatch.setattr("aimp_cli.operations.publish.core.sys.stdin", _StdinStub())

    assert _confirm_remote_build_cancel("job-123") is False


def test_wait_for_publish_build_job_status_message_includes_job_status(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """SSE status updates should include the current job status and job ID."""

    class _StatusStub:
        def __init__(self) -> None:
            self.messages: list[str] = []

        def __enter__(self) -> _StatusStub:
            return self

        def __exit__(self, exc_type, exc, tb) -> None:
            _ = exc_type, exc, tb

        def update(self, message: str) -> None:
            self.messages.append(message)

    status_stub = _StatusStub()

    class _ConsoleStub:
        @staticmethod
        def status(*args: Any, **kwargs: Any) -> _StatusStub:
            _ = args, kwargs
            return status_stub

    class _GatewayStub:
        def get_publish_build_job(self, job_id: str) -> PublishBuildJob:
            return PublishBuildJob(
                job_id=job_id,
                slug="demo-model",
                version="0.1.0",
                status="succeeded",
            )

        @contextmanager
        def stream_job(self, job_id: str) -> Any:
            yield iter(
                [
                    "event: snapshot",
                    (
                        "data: "
                        + json.dumps(
                            {
                                "job": {
                                    "job_id": job_id,
                                    "job_type": "build",
                                    "model_slug": "demo-model",
                                    "status": "queued",
                                    "timeline": [],
                                    "logs": [],
                                    "details": {"version": "0.1.0"},
                                },
                                "timeline_count": 0,
                                "log_count": 0,
                            }
                        )
                    ),
                    "",
                    "event: terminal",
                    (
                        "data: "
                        + json.dumps(
                            {
                                "job": {
                                    "job_id": job_id,
                                    "job_type": "build",
                                    "model_slug": "demo-model",
                                    "status": "succeeded",
                                    "timeline": [],
                                    "logs": [],
                                    "details": {"version": "0.1.0"},
                                },
                                "timeline_count": 0,
                                "log_count": 0,
                            }
                        )
                    ),
                    "",
                ]
            )

    monkeypatch.setattr("aimp_cli.operations.publish.core.console", _ConsoleStub())
    wait_for_publish_build_job(
        gateway=_GatewayStub(),
        job_id="job-123",
        context=build_command_context("publish.wait", debug=False, json_output=False),
    )

    # Status message should include job status and ID, but NOT 'Ctrl+C to stop watching'
    assert any("queued" in message for message in status_stub.messages)
    assert any("job-123" in message for message in status_stub.messages)
    assert not any("Ctrl+C" in message for message in status_stub.messages)


def test_wait_for_publish_build_job_prints_only_new_logs(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """SSE watching should print only log entries that were not shown previously."""

    class _StatusStub:
        def __enter__(self) -> _StatusStub:
            return self

        def __exit__(self, exc_type, exc, tb) -> None:
            _ = exc_type, exc, tb

        def update(self, message: str) -> None:
            _ = message

    printed: list[str] = []

    class _ConsoleStub:
        @staticmethod
        def status(*args: Any, **kwargs: Any) -> _StatusStub:
            _ = args, kwargs
            return _StatusStub()

        @staticmethod
        def print(message: str, **kwargs: Any) -> None:
            _ = kwargs
            printed.append(message)

    class _GatewayStub:
        def get_publish_build_job(self, job_id: str) -> PublishBuildJob:
            return PublishBuildJob(
                job_id=job_id,
                slug="demo-model",
                version="0.1.0",
                status="succeeded",
                logs=[
                    {"level": "info", "message": "Downloading source bundle"},
                    {"level": "warning", "message": "Pushing image"},
                    {"level": "error", "message": "final failure line"},
                ],
            )

        @contextmanager
        def stream_job(self, job_id: str) -> Any:
            yield iter(
                [
                    "event: snapshot",
                    (
                        "data: "
                        + json.dumps(
                            {
                                "job": {
                                    "job_id": job_id,
                                    "job_type": "build",
                                    "model_slug": "demo-model",
                                    "status": "running",
                                    "timeline": [],
                                    "logs": [
                                        {
                                            "level": "info",
                                            "message": "Downloading source bundle",
                                        }
                                    ],
                                    "details": {"version": "0.1.0"},
                                },
                                "timeline_count": 0,
                                "log_count": 1,
                            }
                        )
                    ),
                    "",
                    "event: logs",
                    (
                        "data: "
                        + json.dumps(
                            {
                                "job_id": job_id,
                                "job_type": "build",
                                "offset": 1,
                                "count": 1,
                                "items": [
                                    {
                                        "level": "warning",
                                        "message": "Pushing image",
                                    }
                                ],
                            }
                        )
                    ),
                    "",
                    "event: terminal",
                    (
                        "data: "
                        + json.dumps(
                            {
                                "job": {
                                    "job_id": job_id,
                                    "job_type": "build",
                                    "model_slug": "demo-model",
                                    "status": "succeeded",
                                    "timeline": [],
                                    "logs": [
                                        {
                                            "level": "info",
                                            "message": "Downloading source bundle",
                                        },
                                        {
                                            "level": "warning",
                                            "message": "Pushing image",
                                        },
                                        {
                                            "level": "error",
                                            "message": "final failure line",
                                        },
                                    ],
                                    "details": {"version": "0.1.0"},
                                },
                                "timeline_count": 0,
                                "log_count": 3,
                            }
                        )
                    ),
                    "",
                ]
            )

    monkeypatch.setattr("aimp_cli.operations.publish.core.console", _ConsoleStub())

    wait_for_publish_build_job(
        gateway=_GatewayStub(),
        job_id="job-123",
        context=build_command_context("publish.wait", debug=False, json_output=False),
    )

    assert printed == [
        "[dim]  Downloading source bundle[/dim]",
        "[yellow]⚠ Pushing image[/yellow]",
        "[red]✗ final failure line[/red]",
    ]


def test_find_active_publish_build_job_consumes_list_summary_shape() -> None:
    """Active-build preflight should accept publish-build summary rows from /api/jobs."""

    class _GatewayStub:
        def list_publish_build_jobs(
            self,
            *,
            model_slug: str | None = None,
            status: str | None = None,
            page: int = 1,
            page_size: int = 20,
        ) -> PublishBuildJobListResponse:
            _ = status, page, page_size
            return PublishBuildJobListResponse(
                results=[
                    PublishBuildJob(
                        job_id="job-active",
                        slug=model_slug or "demo-model",
                        version="0.1.0",
                        status="running",
                        created_at="2026-03-19T00:00:00+00:00",
                    )
                ],
                pagination={"total_items": 1},
                model_slug=model_slug,
            )

    active_job = _find_active_publish_build_job(
        gateway=_GatewayStub(),
        slug="demo-model",
    )

    assert active_job == {
        "job_id": "job-active",
        "job_type": None,
        "slug": "demo-model",
        "version": "0.1.0",
        "status": "running",
        "timeline": [],
        "error_code": None,
        "error_message": None,
        "logs": [],
        "created_at": "2026-03-19T00:00:00+00:00",
        "started_at": None,
        "finished_at": None,
    }


def test_managed_live_display_prevents_nested_status_progress_live_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Managed publish live helpers should degrade nested live usage safely."""
    test_console = Console(record=True, force_terminal=False)
    monkeypatch.setattr("aimp_cli.operations.publish.core.console", test_console)
    monkeypatch.setattr("aimp_cli.operations.publish.core._LIVE_DISPLAY_DEPTH", 0)

    with _managed_status("outer"):
        with _managed_progress(
            SpinnerColumn(spinner_name="line"),
            TextColumn("{task.description}"),
            transient=True,
        ) as progress:
            task_id = progress.add_task("inner", total=1)
            progress.update(task_id, completed=1)

    assert progress.__class__.__name__ == "_NoopProgress"


def _fake_extract_contract(**kwargs: Any) -> SimpleNamespace:
    _ = kwargs
    return SimpleNamespace(
        schema_version=3,
        modes={
            "generate": {"inputs": ["text"]},
            "search": {"inputs": ["text"]},
            "index": {"inputs": ["text"]},
        },
        parameters={},
    )


def _fake_mode_readiness(**kwargs: Any) -> ModeReadinessPayload:
    _ = kwargs
    return ModeReadinessPayload.model_validate(
        {
            "generate": {
                "declared": True,
                "implemented": True,
                "reason": None,
            },
            "search": {
                "declared": True,
                "implemented": True,
                "reason": None,
            },
            "index": {
                "declared": True,
                "implemented": True,
                "reason": None,
            },
        }
    )


def _fake_project_config(project_dir: Path) -> ProjectConfig:
    _ = project_dir
    config = ProjectConfig(
        resources=ResourceConfig(
            vector_db=VectorResourceCollectionsConfig(
                collections=[
                    VectorCollectionConfig(
                        alias="docs",
                        name="Documents",
                        description="Document embeddings used by vector-backed modes.",
                    )
                ]
            )
        ),
        modes=ModesConfig(
            {
                "generate": ModeContract(
                    inputs=[InputDefinition(name="text", kind="text", required=True)],
                    outputs=["text"],
                ),
                "search": ModeContract(
                    inputs=[InputDefinition(name="text", kind="text", required=True)],
                    enabled=True,
                    resources=ModeResourcesConfig(vector_aliases=["docs"]),
                ),
                "index": ModeContract(
                    inputs=[InputDefinition(name="text", kind="text", required=True)],
                    enabled=True,
                    resources=ModeResourcesConfig(vector_aliases=["docs"]),
                ),
            },
        ),
    )
    config.tuning = default_tuning_workspace_config(config)
    return config


def _fake_publish_config(project_dir: Path) -> SimpleNamespace:
    _ = project_dir
    return SimpleNamespace(
        studio=SimpleNamespace(
            name="Demo Model",
            tags=["example"],
            visibility="private",
            article_mdx_file="studio/article.mdx",
            cover_file=None,
            cover_url=None,
        ),
        pricing={"developer_margin": 0},
        hardware=SimpleNamespace(supported_tiers=["cpu-basic"]),
    )


def _build_fake_upload_client(_gateway: PublishGatewayProtocol) -> UploadClientProtocol:
    return _FakeUploadClient()


class _FakeUploadClient:
    """Upload client test double."""

    def upload_file(
        self,
        *,
        file_path: Path,
        slug: str,
        version: str,
        artifact_type: ArtifactType,
        content_type: str,
        metadata: dict[str, Any] | None,
        concurrency: int,
        on_progress: Any | None,
    ) -> FakeUploadResult:
        _ = (
            file_path,
            slug,
            version,
            artifact_type,
            content_type,
            metadata,
            concurrency,
            on_progress,
        )
        return FakeUploadResult(storage_uri="s3://models/demo-model.tar")


def test_build_publish_payload_includes_tuning_when_enabled() -> None:
    tuning_config = default_tuning_workspace_config()
    mode_readiness = ModeReadinessPayload.model_validate(
        {
            "generate": {
                "declared": True,
                "implemented": True,
                "reason": None,
            },
            "search": {
                "declared": True,
                "implemented": True,
                "reason": None,
            },
            "index": {
                "declared": True,
                "implemented": True,
                "reason": None,
            },
        }
    )
    payload = build_publish_payload(
        slug="demo-model",
        version="0.1.0",
        publish_build_job_id="job-1",
        project_config=ProjectConfig(
            schema_version=2,
            resources=ResourceConfig(
                vector_db=VectorResourceCollectionsConfig(
                    collections=[
                        VectorCollectionConfig(
                            alias="docs",
                            name="Documents",
                            description="Document embeddings used by vector-backed modes.",
                        )
                    ]
                )
            ),
            modes=ModesConfig(
                {
                    "generate": ModeContract(
                        inputs=[InputDefinition(name="text", kind="text", required=True)],
                        outputs=["text"],
                    ),
                    "search": ModeContract(
                        inputs=[InputDefinition(name="text", kind="text", required=True)],
                        enabled=True,
                        resources=ModeResourcesConfig(vector_aliases=["docs"]),
                    ),
                    "index": ModeContract(
                        inputs=[InputDefinition(name="text", kind="text", required=True)],
                        enabled=True,
                        resources=ModeResourcesConfig(vector_aliases=["docs"]),
                    ),
                },
            ),
        ),
        mode_readiness=mode_readiness,
        parameters={},
        tuning_contract=tuning_config.model_dump(by_alias=True),
        publish_config=SimpleNamespace(
            studio=SimpleNamespace(
                name="Demo Model",
                tags=["example"],
                visibility="private",
            ),
            pricing={"developer_margin": 0},
            hardware=SimpleNamespace(supported_tiers=["cpu-basic"]),
        ),
        studio=StudioPublishPayload(
            name="Demo Model",
            tags=["example"],
            visibility="private",
            article={"format": "tiptap-json", "schema_version": 1, "content": {"type": "doc"}},
        ),
    )

    assert payload.tuning is not None
    assert payload.tuning.output_kind == "lora"
    assert payload.mode_readiness["generate"].implemented is True
    assert payload.publish_build_job_id == "job-1"
    serialized = payload.model_dump(exclude_none=True)
    assert "enabled" not in serialized["modes"]["generate"]
    assert "enabled" not in serialized["modes"]["search"]
    assert "enabled" not in serialized["modes"]["index"]


def test_build_publish_payload_excludes_disabled_modes_from_serialized_request() -> None:
    payload = build_publish_payload(
        slug="demo-model",
        version="0.1.0",
        publish_build_job_id="job-1",
        project_config=ProjectConfig(
            schema_version=2,
            resources=ResourceConfig(vector_db=False),
            modes=ModesConfig(
                {
                    "generate": ModeContract(
                        inputs=[InputDefinition(name="text", kind="text", required=True)],
                        enabled=True,
                        outputs=["text"],
                    ),
                    "search": ModeContract(
                        inputs=[InputDefinition(name="text", kind="text", required=True)],
                        enabled=False,
                        resources=ModeResourcesConfig(vector_aliases=["docs"]),
                    ),
                },
            ),
        ),
        mode_readiness=ModeReadinessPayload.model_validate(
            {
                "generate": {
                    "declared": True,
                    "implemented": True,
                    "reason": None,
                },
                "search": {
                    "declared": True,
                    "implemented": False,
                    "reason": "search() is not implemented by this model",
                },
            }
        ),
        parameters={},
        tuning_contract=None,
        publish_config=SimpleNamespace(
            studio=SimpleNamespace(
                name="Demo Model",
                tags=["example"],
                visibility="private",
            ),
            pricing={"developer_margin": 0},
            hardware=SimpleNamespace(supported_tiers=["cpu-basic"]),
        ),
        studio=StudioPublishPayload(
            name="Demo Model",
            tags=["example"],
            visibility="private",
            article={"format": "tiptap-json", "schema_version": 1, "content": {"type": "doc"}},
        ),
    )

    serialized = payload.model_dump(exclude_none=True)
    assert list(serialized["modes"].keys()) == ["generate"]
    assert list(serialized["mode_readiness"].keys()) == ["generate"]


def test_build_studio_publish_payload_preserves_cover_media_ref(tmp_path: Path) -> None:
    """Local cover uploads must carry media_ref into the publish payload."""

    class FakeGateway(FakeGatewayBase):
        def upload_studio_media(
            self,
            *,
            file_path: Path,
            media_type: str,
        ) -> dict[str, Any]:
            _ = file_path, media_type
            return {
                "media_ref": "signed-cover-ref",
                "storage_uri": "s3://studio/media/cover.png",
                "public_url": "https://cdn.example.com/cover.png",
            }

    article_path, cover_path = (
        tmp_path / "studio" / "article.mdx",
        tmp_path / "studio" / "cover.png",
    )
    article_path.parent.mkdir(parents=True, exist_ok=True)
    article_path.write_text("# Demo\n", encoding="utf-8")
    cover_path.write_bytes(b"png")

    publish_config = SimpleNamespace(
        studio=SimpleNamespace(
            article_mdx_file="studio/article.mdx",
            cover_file="studio/cover.png",
            cover_url=None,
            name="Demo Model",
            tags=["example"],
            visibility="private",
        )
    )

    resolved_article_path, resolved_cover_path = resolve_studio_file_paths(tmp_path, publish_config)
    assert resolved_article_path == article_path
    assert resolved_cover_path == cover_path

    payload = _build_studio_publish_payload(
        project_dir=tmp_path,
        publish_config=publish_config,
        gateway=FakeGateway(),
    )

    assert payload.cover is not None
    assert payload.cover.media_ref == "signed-cover-ref"
    assert payload.cover.public_url == "https://cdn.example.com/cover.png"


def test_build_contract_python_candidates_prefers_explicit_then_venv_then_cli(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Explicit and active project interpreters must take precedence."""
    monkeypatch.setenv("VIRTUAL_ENV", "/project/.venv")
    monkeypatch.setattr(sys, "executable", "/tool/python3.13")

    assert _build_contract_python_candidates("/custom/python") == [
        "/custom/python",
        "/project/.venv/bin/python",
        "/project/.venv/Scripts/python.exe",
        "/project/.venv/Scripts/python",
        "/tool/python3.13",
        "python",
        "python3",
    ]


def test_build_contract_python_candidates_prefers_cli_python_without_venv(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The running CLI interpreter must win when no project venv is active."""
    monkeypatch.delenv("VIRTUAL_ENV", raising=False)
    monkeypatch.setattr(sys, "executable", "/tool/python3.13")

    assert _build_contract_python_candidates(None) == [
        "/tool/python3.13",
        "python",
        "python3",
    ]


def test_extract_contract_from_python_reports_candidates_on_failure(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Failure output should include interpreter candidates for diagnosis."""
    module_path = tmp_path / "agent.py"
    module_path.write_text("from aimp_sdk import Model\n", encoding="utf-8")
    fake_sdk = tmp_path / "site-packages" / "aimp_sdk" / "__init__.py"
    fake_sdk.parent.mkdir(parents=True)
    fake_sdk.write_text('"""fake sdk"""', encoding="utf-8")

    monkeypatch.setitem(sys.modules, "aimp_sdk", SimpleNamespace(__file__=str(fake_sdk)))
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._build_contract_python_candidates",
        lambda _python_bin: ["/tool/python3.13", "python3"],
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.subprocess.run",
        lambda *args, **kwargs: subprocess.CompletedProcess(
            args=args[0],
            returncode=1,
            stdout="",
            stderr="boom",
        ),
    )

    with pytest.raises(Exception, match=r"python candidates tried: /tool/python3\.13, python3"):
        extract_contract_from_python(project_dir=tmp_path, python_bin=None)


def test_extract_contract_from_python_rejects_legacy_vector_resource_shapes(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Legacy vector resource payloads must fail before remote publish starts."""
    module_path = tmp_path / "agent.py"
    module_path.write_text("from aimp_sdk import Model\n", encoding="utf-8")
    fake_sdk = tmp_path / "site-packages" / "aimp_sdk" / "__init__.py"
    fake_sdk.parent.mkdir(parents=True)
    fake_sdk.write_text('"""fake sdk"""', encoding="utf-8")

    monkeypatch.setitem(sys.modules, "aimp_sdk", SimpleNamespace(__file__=str(fake_sdk)))
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._build_contract_python_candidates",
        lambda _python_bin: ["/tool/python3.13"],
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.subprocess.run",
        lambda *args, **kwargs: subprocess.CompletedProcess(
            args=args[0],
            returncode=0,
            stdout=json.dumps(
                {
                    "schema_version": 4,
                    "capabilities": {"vector": True, "tuning": False},
                    "resources": {"vector_db": {"aliases": ["Documents"]}},
                    "modes": {
                        "search": {
                            "inputs": [{"name": "query", "kind": "text", "required": True}],
                            "resources": {"vector_aliases": ["Documents"]},
                        }
                    },
                    "parameters": {},
                }
            ),
            stderr="",
        ),
    )

    with pytest.raises(CliError) as exc_info:
        extract_contract_from_python(project_dir=tmp_path, python_bin=None)

    assert exc_info.value.code == "legacy_python_contract_shape"
    assert "resources.vector_db.collections" in exc_info.value.message
    assert exc_info.value.extra["legacy_shape"] == "resources.vector_db.aliases"


def test_extract_contract_and_mode_readiness_from_unified_init_project(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)
    project_dir = create_project_scaffold("demo-model")

    contract = extract_contract_from_python(project_dir=project_dir, python_bin=sys.executable)
    readiness = extract_mode_readiness_from_python(
        project_dir=project_dir,
        python_bin=sys.executable,
    )

    assert sorted(contract.modes.keys()) == ["generate", "index", "search"]
    assert contract.modes["generate"].inputs[0].name == "prompt"
    assert contract.modes["search"].inputs[0].name == "query"
    assert contract.modes["index"].inputs[0].name == "text"
    assert readiness["generate"].implemented is True
    assert readiness["search"].implemented is True
    assert readiness["index"].implemented is True


def test_extract_mode_readiness_from_python_detects_missing_public_methods(
    tmp_path: Path,
) -> None:
    contract_path = tmp_path / "contract.toml"
    app_path = tmp_path / "agent.py"
    contract_path.write_text("[agent]\nname = 'demo'\nversion = '0.1.0'\nauthor = 'test'\ndescription = 'demo'\n", encoding="utf-8")
    app_path.write_text(
        (
            "from aimp_sdk import Agent, Mode, inputs_schema, outputs_schema, parameters_schema, text\n\n"
            "class GenerateMode(Mode):\n"
            "    name = 'generate'\n"
            "    inputs = inputs_schema(\n"
                "        input_data=text(description='Primary input'),\n"
            "    )\n"
            "    outputs = outputs_schema(ok=text())\n"
            "    parameters = parameters_schema()\n\n"
            "    def run(self, inputs, params):\n"
            "        return {'ok': 'yes'}\n\n"
            "class DemoAgent(Agent):\n"
            "    modes = [GenerateMode]\n"
        ),
        encoding="utf-8",
    )

    readiness = extract_mode_readiness_from_python(
        project_dir=tmp_path,
        python_bin=sys.executable,
        mode_names=["generate", "search", "index"],
    )

    assert readiness["generate"].implemented is True
    assert readiness["search"].implemented is False
    assert readiness["index"].implemented is False
    assert readiness["index"].reason == "index() is not implemented by this model"


def test_build_mode_readiness_payload_marks_declared_but_missing_modes() -> None:
    implementation_status = ModeReadinessPayload.model_validate(
        {
            "generate": {"declared": True, "implemented": True, "reason": None},
            "search": {"declared": True, "implemented": True, "reason": None},
            "index": {
                "declared": True,
                "implemented": False,
                "reason": "index() is not implemented by this model",
            },
        }
    )

    payload = build_mode_readiness_payload(
        modes=ModesConfig.model_validate(
            {
                "search": {"inputs": [{"name": "image", "kind": "image", "required": True}]},
                "index": {"inputs": [{"name": "image", "kind": "image", "required": True}]},
            }
        ),
        implementation_status=implementation_status,
    )

    assert "generate" not in payload
    assert payload["search"].declared is True
    assert payload["search"].implemented is True
    assert payload["index"].declared is True
    assert payload["index"].implemented is False
    assert payload["index"].reason == "index() is not implemented by this model"


def test_create_source_bundle_archive_respects_dockerignore(tmp_path: Path) -> None:
    """Source bundle must mirror Docker context exclusions for remote builds."""
    build_context = tmp_path

    (build_context / "Dockerfile").write_text("FROM python:3.13-slim\n", encoding="utf-8")
    (build_context / ".dockerignore").write_text(
        "\n".join(
            [
                "ignored.txt",
                "build/",
                "!build/keep.txt",
                "Dockerfile",
            ]
        ),
        encoding="utf-8",
    )
    (build_context / "included.txt").write_text("keep", encoding="utf-8")
    (build_context / "ignored.txt").write_text("drop", encoding="utf-8")
    (build_context / "build").mkdir()
    (build_context / "build" / "keep.txt").write_text("keep", encoding="utf-8")
    (build_context / "build" / "drop.txt").write_text("drop", encoding="utf-8")

    bundle_path = create_source_bundle_archive(build_context=build_context, dockerfile=None)
    try:
        with tarfile.open(bundle_path, mode="r:gz") as archive:
            names = set(archive.getnames())
    finally:
        bundle_path.unlink(missing_ok=True)

    assert ".dockerignore" in names
    assert "Dockerfile" in names
    assert "included.txt" in names
    assert "build/keep.txt" in names
    assert "ignored.txt" not in names
    assert "build/drop.txt" not in names


def test_create_source_bundle_archive_forces_pyproject_when_dockerignore_excludes_project_files(
    tmp_path: Path,
) -> None:
    """Source bundles must keep the dependency manifest for remote Docker builds."""
    build_context = tmp_path

    (build_context / "Dockerfile").write_text(
        (
            "FROM python:3.13-slim\n"
            "COPY pyproject.toml ./\n"
            "COPY agent.py ./agent.py\n"
            "RUN pip install --no-cache-dir .\n"
        ),
        encoding="utf-8",
    )
    (build_context / ".dockerignore").write_text("*\n", encoding="utf-8")
    (build_context / "pyproject.toml").write_text("[project]\nname='demo'\nversion='0.1.0'\n", encoding="utf-8")
    (build_context / "agent.py").write_text("print('ok')\n", encoding="utf-8")

    bundle_path = create_source_bundle_archive(build_context=build_context, dockerfile=None)
    try:
        with tarfile.open(bundle_path, mode="r:gz") as archive:
            names = set(archive.getnames())
    finally:
        bundle_path.unlink(missing_ok=True)

    assert "pyproject.toml" in names
    assert "agent.py" not in names


def test_codex_source_bundle_installs_project_after_copy(tmp_path: Path) -> None:
    """The bundled Dockerfile must install the project package from copied source."""
    project_dir = tmp_path
    (project_dir / "Dockerfile").write_text(
        (
            "FROM python\n"
            "COPY pyproject.toml ./\n"
            "COPY agent.py ./agent.py\n"
            "COPY model ./model\n"
            "RUN pip install --no-cache-dir .\n"
            "CMD python agent.py\n"
        ),
        encoding="utf-8",
    )
    (project_dir / "pyproject.toml").write_text("[project]\nname='demo'\nversion='0.1.0'\n", encoding="utf-8")

    bundle_path = create_source_bundle_archive(build_context=project_dir, dockerfile=None)
    try:
        with tarfile.open(bundle_path, mode="r:gz") as archive:
            dockerfile = archive.extractfile("Dockerfile")
            assert dockerfile is not None
            dockerfile_content = dockerfile.read().decode("utf-8")
    finally:
        bundle_path.unlink(missing_ok=True)

    copy_manifest_index = dockerfile_content.index("COPY pyproject.toml ./")
    copy_model_index = dockerfile_content.index("COPY model ./model")
    run_index = dockerfile_content.index("RUN pip install --no-cache-dir .")
    assert copy_manifest_index < copy_model_index < run_index


def test_run_publish_does_not_require_local_docker_access(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Remote publish should not fail when local Docker access is unavailable."""

    class FakeDocker(FakeDockerBase):
        def inspect_daemon_access(self) -> DockerAccessStatus:
            return DockerAccessStatus(
                ok=False,
                code="docker_permission_denied",
                message="Docker is installed, but this shell cannot access the Docker daemon.",
                hint="Refresh shell/session permissions, then run `make dev-up`.",
                detail="permission denied while trying to connect to docker.sock",
            )

    class FakeGateway(FakeGatewayBase):
        def publish(self, request: PublishRequest | dict[str, Any]) -> PublishResponse:
            assert isinstance(request, PublishRequest)
            return PublishResponse(
                id="asset-1",
                slug="demo-model",
                visibility="private",
                readiness={"is_ready": True, "blocking_reasons": []},
                url="http://localhost:3000/studio/models/demo-model",
            )

    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_contract_from_python", _fake_extract_contract
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_mode_readiness_from_python",
        _fake_mode_readiness,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_project_config", _fake_project_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_publish_config", _fake_publish_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._build_studio_publish_payload",
        lambda **kwargs: StudioPublishPayload(
            name="Demo Model",
            tags=["example"],
            visibility="private",
            article={"format": "tiptap-json", "schema_version": 1, "content": {"type": "doc"}},
        ),
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.resolve_docker_build_spec",
        lambda project_dir: (project_dir, None),
    )

    tmp_path.joinpath("agent.py").write_text("print('ok')\n", encoding="utf-8")
    result = run_publish(
        project_dir=tmp_path,
        gateway=FakeGateway(),
        docker=FakeDocker(),
        context=build_command_context("publish", debug=False, json_output=True),
        python_bin=None,
        parallel=3,
        verbose=False,
        upload_client_factory=_build_fake_upload_client,
    )

    assert result["publish_build_job_id"] == "job-1"


def test_run_publish_resumes_watch_when_active_build_exists(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """When an active build exists and --force is not set, publish resumes watching it."""
    get_job_calls: list[str] = []
    publish_calls: list[Any] = []

    class FakeGateway(FakeGatewayBase):
        def __init__(self) -> None:
            super().__init__()
            self.build_job = PublishBuildJob(
                job_id="job-active",
                slug=tmp_path.name,
                version="0.1.0",
                status="succeeded",
            )

        def list_publish_build_jobs(
            self,
            *,
            model_slug: str | None = None,
            status: str | None = None,
            page: int = 1,
            page_size: int = 20,
        ) -> PublishBuildJobListResponse:
            _ = status, page, page_size
            return PublishBuildJobListResponse(
                results=[
                    PublishBuildJob(
                        job_id="job-active",
                        slug=model_slug or tmp_path.name,
                        version="0.1.0",
                        status="running",
                    )
                ],
                pagination={"total_items": 1},
                model_slug=model_slug,
            )

        def get_publish_build_job(self, job_id: str) -> PublishBuildJob:
            get_job_calls.append(job_id)
            return self.build_job

        def create_publish_build_job(
            self,
            request: PublishBuildJobCreateRequest,
        ) -> PublishBuildJob:
            _ = request
            raise AssertionError("create_publish_build_job should not be called on resume")

        def publish(self, request: PublishRequest | dict[str, Any]) -> PublishResponse:
            publish_calls.append(request)
            return PublishResponse(
                id="asset-resumed",
                slug=tmp_path.name,
                visibility="private",
                readiness={"is_ready": False, "blocking_reasons": []},
                url=f"http://localhost:3000/studio/models/{tmp_path.name}",
            )

    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_contract_from_python", _fake_extract_contract
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_mode_readiness_from_python",
        _fake_mode_readiness,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_project_config", _fake_project_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_publish_config", _fake_publish_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._build_studio_publish_payload",
        lambda **kwargs: StudioPublishPayload(
            name="Demo Model",
            tags=["example"],
            visibility="private",
            article={"format": "tiptap-json", "schema_version": 1, "content": {"type": "doc"}},
        ),
    )

    tmp_path.joinpath("agent.py").write_text("print('ok')\n", encoding="utf-8")

    result = run_publish(
        project_dir=tmp_path,
        gateway=FakeGateway(),
        docker=FakeDockerBase(),
        context=build_command_context("publish", debug=False, json_output=True),
        python_bin=None,
        parallel=3,
        verbose=False,
        upload_client_factory=_build_fake_upload_client,
    )

    # Must have resumed watching the existing build
    assert get_job_calls == ["job-active"]
    # Must have finalized publish with the existing job ID
    assert len(publish_calls) == 1
    assert result["id"] == "asset-resumed"


def test_run_publish_autosyncs_vector_collections_into_final_publish_request(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Final publish must use synced vector collections, not stale local config."""
    publish_requests: list[PublishRequest] = []
    config_state = {
        "current": ProjectConfig(
            capabilities=CapabilitiesConfig(vector=True, tuning=False),
            resources=ResourceConfig(vector_db=False),
            modes=ModesConfig(
                {
                    "generate": ModeContract(
                        inputs=[InputDefinition(name="text", kind="text", required=True)],
                        outputs=["text"],
                    ),
                    "search": ModeContract(
                        inputs=[InputDefinition(name="query", kind="text", required=True)],
                        outputs=["json"],
                        resources=ModeResourcesConfig(vector_aliases=["docs"]),
                    ),
                    "index": ModeContract(
                        inputs=[InputDefinition(name="text", kind="text", required=True)],
                        outputs=["json"],
                        resources=ModeResourcesConfig(vector_aliases=["docs"]),
                    ),
                },
            ),
        )
    }

    class FakeGateway(FakeGatewayBase):
        def publish(self, request: PublishRequest | dict[str, Any]) -> PublishResponse:
            assert isinstance(request, PublishRequest)
            publish_requests.append(request)
            return PublishResponse(
                id="asset-1",
                slug="demo-model",
                visibility="private",
                readiness={"is_ready": True, "blocking_reasons": []},
                url="http://localhost:3000/studio/models/demo-model",
            )

    def _extract_contract_with_vector_resources(**kwargs: Any) -> SimpleNamespace:
        _ = kwargs
        return SimpleNamespace(
            schema_version=4,
            resources={
                "vector_db": {
                    "collections": [
                        {
                            "alias": "docs",
                            "name": "Documents",
                            "description": "Document embeddings used by vector-backed modes.",
                        }
                    ]
                }
            },
            modes={
                "generate": {
                    "inputs": [{"name": "text", "kind": "text", "required": True}],
                },
                "search": {
                    "inputs": [{"name": "query", "kind": "text", "required": True}],
                    "resources": {"vector_aliases": ["docs"]},
                },
                "index": {
                    "inputs": [{"name": "text", "kind": "text", "required": True}],
                    "resources": {"vector_aliases": ["docs"]},
                },
            },
            parameters={},
        )

    def _load_project_config(project_dir: Path) -> ProjectConfig:
        _ = project_dir
        return config_state["current"].model_copy(deep=True)

    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_contract_from_python",
        _extract_contract_with_vector_resources,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_mode_readiness_from_python",
        _fake_mode_readiness,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_project_config",
        _load_project_config,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.write_project_config",
        lambda _project_dir, config: config_state.update(
            {"current": config.model_copy(deep=True)}
        )
        or (tmp_path / ".aimp" / "project.toml"),
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_publish_config",
        _fake_publish_config,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._build_studio_publish_payload",
        lambda **kwargs: StudioPublishPayload(
            name="Demo Model",
            tags=["example"],
            visibility="private",
            article={"format": "tiptap-json", "schema_version": 1, "content": {"type": "doc"}},
        ),
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.resolve_docker_build_spec",
        lambda project_dir: (project_dir, None),
    )

    tmp_path.joinpath("agent.py").write_text("print('ok')\n", encoding="utf-8")

    run_publish(
        project_dir=tmp_path,
        gateway=FakeGateway(),
        docker=FakeDockerBase(),
        context=build_command_context("publish", debug=False, json_output=True),
        python_bin=None,
        parallel=3,
        verbose=False,
        upload_client_factory=_build_fake_upload_client,
    )

    assert len(publish_requests) == 1
    assert publish_requests[0].resources.vector_collections == [
        VectorCollectionConfig(
            alias="docs",
            name="Documents",
            description="Document embeddings used by vector-backed modes.",
        )
    ]


def test_run_publish_rejects_legacy_runtime_path_sources_before_registry_check(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._reject_legacy_runtime_path_sources",
        _reject_legacy_runtime_path_sources,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_contract_from_python", _fake_extract_contract
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_project_config", _fake_project_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._verify_runtime_packages_downloadable",
        lambda **kwargs: (_ for _ in ()).throw(
            AssertionError("registry preflight should not run for legacy path-source manifests")
        ),
    )

    (tmp_path / "agent.py").write_text("print('ok')\n", encoding="utf-8")
    (tmp_path / "pyproject.toml").write_text(
        "\n".join(
            [
                "[project]",
                'name = "demo-model"',
                "dependencies = [",
                f'    "{OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-framework"]}",',
                f'    "{OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-sdk"]}",',
                "]",
                "",
                "[tool.uv.sources]",
                'ai-marketplace-framework = { path = "../framework/python" }',
                'ai-marketplace-sdk = { path = "../sdk/python" }',
            ]
        ),
        encoding="utf-8",
    )

    with pytest.raises(CliError) as exc_info:
        run_publish(
            project_dir=tmp_path,
            gateway=FakeGatewayBase(),
            docker=FakeDockerBase(),
            context=build_command_context("publish", debug=False, json_output=True),
            python_bin=None,
            parallel=3,
            verbose=False,
            upload_client_factory=_build_fake_upload_client,
        )

    assert exc_info.value.code == "runtime_path_sources_unsupported"
    assert "Remove [tool.uv.sources] from pyproject.toml" in exc_info.value.message


def test_run_publish_force_cancel_active_build_avoids_nested_live_error(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Force-cancel path should complete without nested Rich live display failures."""

    class FakeGateway(FakeGatewayBase):
        def __init__(self) -> None:
            super().__init__()
            self.active_job = PublishBuildJob(
                job_id="job-active",
                slug=tmp_path.name,
                version="0.1.0",
                status="running",
            )
            self.build_job = PublishBuildJob(
                job_id="job-new",
                slug=tmp_path.name,
                version="0.2.0",
                status="succeeded",
            )
            self.deleted_jobs: list[str] = []

        def list_publish_build_jobs(
            self,
            *,
            model_slug: str | None = None,
            status: str | None = None,
            page: int = 1,
            page_size: int = 20,
        ) -> PublishBuildJobListResponse:
            _ = model_slug, status, page, page_size
            return PublishBuildJobListResponse(
                results=[self.active_job],
                pagination={"total_items": 1},
                model_slug=model_slug,
            )

        def cancel_publish_build_job(self, job_id: str) -> Any:
            assert job_id == "job-active"
            return SimpleNamespace(cancel_state="requested")

        def get_publish_build_job(self, job_id: str) -> PublishBuildJob:
            if job_id == "job-active":
                return PublishBuildJob(
                    job_id=job_id,
                    slug=tmp_path.name,
                    version="0.1.0",
                    status="canceled",
                )
            assert job_id == "job-new"
            return self.build_job

        def delete_publish_build_job(self, job_id: str) -> None:
            self.deleted_jobs.append(job_id)

        def publish(self, request: PublishRequest | dict[str, Any]) -> PublishResponse:
            assert isinstance(request, PublishRequest)
            return PublishResponse(
                id="asset-force",
                slug=tmp_path.name,
                visibility="private",
                readiness={"is_ready": True, "blocking_reasons": []},
                url=f"http://localhost:3000/studio/models/{tmp_path.name}",
            )

    test_console = Console(record=True, force_terminal=False)
    monkeypatch.setattr("aimp_cli.operations.publish.core.console", test_console)
    monkeypatch.setattr("aimp_cli.operations.publish.core._LIVE_DISPLAY_DEPTH", 0)
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_contract_from_python", _fake_extract_contract
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_mode_readiness_from_python",
        _fake_mode_readiness,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_project_config", _fake_project_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_publish_config", _fake_publish_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._build_studio_publish_payload",
        lambda **kwargs: StudioPublishPayload(
            name="Demo Model",
            tags=["example"],
            visibility="private",
            article={"format": "tiptap-json", "schema_version": 1, "content": {"type": "doc"}},
        ),
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.resolve_docker_build_spec",
        lambda project_dir: (project_dir, None),
    )

    tmp_path.joinpath("agent.py").write_text("print('ok')\n", encoding="utf-8")
    gateway = FakeGateway()
    result = run_publish(
        project_dir=tmp_path,
        gateway=gateway,
        docker=FakeDockerBase(),
        context=build_command_context("publish", debug=False, json_output=True),
        python_bin=None,
        parallel=3,
        verbose=False,
        force=True,
        upload_client_factory=_build_fake_upload_client,
    )

    assert result["id"] == "asset-force"
    assert gateway.deleted_jobs == ["job-active"]


def test_run_publish_forwards_publish_build_job_id(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Publish should finalize from the trusted remote build job reference."""

    class FakeGateway(FakeGatewayBase):
        def publish(self, request: PublishRequest | dict[str, Any]) -> PublishResponse:
            assert isinstance(request, PublishRequest)
            assert request.publish_build_job_id == "job-1"
            return PublishResponse(
                id="asset-1",
                slug="demo-model",
                visibility="private",
                readiness={"is_ready": True, "blocking_reasons": []},
                url="http://localhost:3000/studio/models/demo-model",
            )

    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_contract_from_python", _fake_extract_contract
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_mode_readiness_from_python",
        _fake_mode_readiness,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_project_config", _fake_project_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_publish_config", _fake_publish_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._build_studio_publish_payload",
        lambda **kwargs: StudioPublishPayload(
            name="Demo Model",
            tags=["example"],
            visibility="private",
            article={"format": "tiptap-json", "schema_version": 1, "content": {"type": "doc"}},
        ),
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.resolve_docker_build_spec",
        lambda project_dir: (project_dir, None),
    )

    app_path = tmp_path / "agent.py"
    app_path.write_text("print('ok')\n", encoding="utf-8")
    (tmp_path / ".aimp").mkdir()
    (tmp_path / ".aimp" / "contract.toml").write_text(
        "schema_version = 1\n\n[interface]\ninputs = ['text']\noutputs = ['text']\n",
        encoding="utf-8",
    )

    result = run_publish(
        project_dir=tmp_path,
        gateway=FakeGateway(),
        docker=FakeDockerBase(),
        context=build_command_context("publish", debug=False, json_output=True),
        python_bin=None,
        parallel=3,
        verbose=False,
        upload_client_factory=_build_fake_upload_client,
    )

    assert result["id"] == "asset-1"


def test_run_publish_returns_visibility_and_readiness(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Publish should surface visibility/readiness from the Gateway response."""

    class FakeGateway(FakeGatewayBase):
        def publish(self, request: PublishRequest | dict[str, Any]) -> PublishResponse:
            assert isinstance(request, PublishRequest)
            assert request.pricing == {"developer_margin": 0}
            assert request.supported_hardware_tiers == ["cpu-basic"]
            assert request.studio.name == "Demo Model"
            assert request.tuning is not None
            return PublishResponse(
                id="8ac15d57-4705-4a1f-86c1-ff81eb477c60",
                slug="demo-model",
                visibility="private",
                readiness={
                    "is_ready": False,
                    "blocking_reasons": ["publish_pricing_not_configured"],
                },
                url="http://localhost:3000/studio/models/demo-model",
            )

    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_contract_from_python", _fake_extract_contract
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_mode_readiness_from_python",
        _fake_mode_readiness,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_project_config", _fake_project_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_publish_config", _fake_publish_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._build_studio_publish_payload",
        lambda **kwargs: StudioPublishPayload(
            name="Demo Model",
            tags=["example"],
            visibility="private",
            article={"format": "tiptap-json", "schema_version": 1, "content": {"type": "doc"}},
        ),
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.resolve_docker_build_spec",
        lambda project_dir: (project_dir, None),
    )

    app_path = tmp_path / "agent.py"
    app_path.write_text("print('ok')\n", encoding="utf-8")
    result = run_publish(
        project_dir=tmp_path,
        gateway=FakeGateway(),
        docker=FakeDockerBase(),
        context=build_command_context("publish", debug=False, json_output=True),
        python_bin=None,
        parallel=3,
        verbose=False,
        upload_client_factory=_build_fake_upload_client,
    )

    assert result["id"] == "8ac15d57-4705-4a1f-86c1-ff81eb477c60"
    assert result["visibility"] == "private"
    assert result["readiness"]["is_ready"] is False
    assert result["url"] == "http://localhost:3000/studio/models/demo-model"
    assert "status" not in result


def test_run_publish_does_not_send_layer_request_to_remote_build(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Publish should create remote build jobs without legacy layer payloads."""

    class FakeGateway(FakeGatewayBase):
        def __init__(self) -> None:
            super().__init__()

        def publish(self, request: PublishRequest | dict[str, Any]) -> PublishResponse:
            assert isinstance(request, PublishRequest)
            return PublishResponse(
                id="asset-1",
                slug="demo-model",
                visibility="private",
                readiness={"is_ready": True, "blocking_reasons": []},
                url="http://localhost:3000/studio/models/demo-model",
            )

    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_contract_from_python", _fake_extract_contract
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_mode_readiness_from_python",
        _fake_mode_readiness,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_project_config", _fake_project_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_publish_config", _fake_publish_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._build_studio_publish_payload",
        lambda **kwargs: StudioPublishPayload(
            name="Demo Model",
            tags=["example"],
            visibility="private",
            article={"format": "tiptap-json", "schema_version": 1, "content": {"type": "doc"}},
        ),
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.resolve_docker_build_spec",
        lambda project_dir: (project_dir, None),
    )

    gateway = FakeGateway()
    tmp_path.joinpath("agent.py").write_text("print('ok')\n", encoding="utf-8")
    result = run_publish(
        project_dir=tmp_path,
        gateway=gateway,
        docker=FakeDockerBase(),
        context=build_command_context("publish", debug=False, json_output=True),
        python_bin=None,
        parallel=3,
        verbose=False,
        upload_client_factory=_build_fake_upload_client,
    )

    assert gateway.build_job_request is not None
    assert "layer_request" not in gateway.build_job_request.model_dump()
    assert "layers" not in result


def test_run_publish_includes_tuning_when_enabled_in_root_contract(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Publish should forward tuning metadata from the root project contract."""

    captured_tuning: list[dict[str, Any] | None] = []

    class FakeGateway(FakeGatewayBase):
        def publish(self, request: PublishRequest | dict[str, Any]) -> PublishResponse:
            assert isinstance(request, PublishRequest)
            captured_tuning.append(request.tuning)
            return PublishResponse(
                id="8ac15d57-4705-4a1f-86c1-ff81eb477c60",
                slug="demo-model",
                visibility="private",
                readiness={"is_ready": True, "blocking_reasons": []},
                url="http://localhost:3000/studio/models/demo-model",
            )

    tuning_config = default_tuning_workspace_config()
    tuning_contract = tuning_config.model_dump(by_alias=True)
    tuning_schema = tuning_contract["schema"]

    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_contract_from_python", _fake_extract_contract
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_mode_readiness_from_python",
        _fake_mode_readiness,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_project_config",
        lambda project_dir: ProjectConfig(
            resources=ResourceConfig(
                vector_db=VectorResourceCollectionsConfig(
                    collections=[
                        VectorCollectionConfig(
                            alias="docs",
                            name="Documents",
                            description="Document embeddings used by vector-backed modes.",
                        )
                    ]
                )
            ),
            modes=ModesConfig(
                {
                    "generate": ModeContract(
                        inputs=[InputDefinition(name="text", kind="text", required=True)],
                        outputs=["text"],
                    ),
                    "search": ModeContract(
                        inputs=[InputDefinition(name="text", kind="text", required=True)],
                        enabled=True,
                        resources=ModeResourcesConfig(vector_aliases=["docs"]),
                    ),
                    "index": ModeContract(
                        inputs=[InputDefinition(name="text", kind="text", required=True)],
                        enabled=True,
                        resources=ModeResourcesConfig(vector_aliases=["docs"]),
                    ),
                },
            ),
            tuning=tuning_config,
        ),
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_publish_config", _fake_publish_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._build_studio_publish_payload",
        lambda **kwargs: StudioPublishPayload(
            name="Demo Model",
            tags=["example"],
            visibility="private",
            article={"format": "tiptap-json", "schema_version": 1, "content": {"type": "doc"}},
        ),
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.resolve_docker_build_spec",
        lambda project_dir: (project_dir, None),
    )

    app_path = tmp_path / "agent.py"
    app_path.write_text("print('ok')\n", encoding="utf-8")
    schema_path = tmp_path / FINE_TUNE_SCHEMA_MODULE_RELATIVE_PATH
    schema_path.parent.mkdir(parents=True, exist_ok=True)
    schema_path.write_text(
        "from aimp_sdk import FineTuneSchema, TuningJsonField\n", encoding="utf-8"
    )
    runtime_path = tmp_path / FINE_TUNE_MODULE_RELATIVE_PATH
    runtime_path.parent.mkdir(parents=True, exist_ok=True)
    runtime_path.write_text("def tune(model, input_data):\n    return {}\n", encoding="utf-8")

    result = run_publish(
        project_dir=tmp_path,
        gateway=FakeGateway(),
        docker=FakeDockerBase(),
        context=build_command_context("publish", debug=False, json_output=True),
        python_bin=None,
        parallel=3,
        verbose=False,
        upload_client_factory=_build_fake_upload_client,
    )

    assert result["slug"] == "demo-model"
    assert len(captured_tuning) == 1
    assert captured_tuning[0] is not None
    assert captured_tuning[0].model_dump(by_alias=True) == tuning_contract


def test_publish_model_by_slug_returns_publish_response() -> None:
    class FakeGateway(FakeGatewayBase):
        def publish_model_by_slug(self, slug: str) -> PublishResponse:
            assert slug == "vision-pro-tuned"
            return PublishResponse(
                id="derived-1",
                slug=slug,
                visibility="public",
                readiness={"is_ready": True, "blocking_reasons": []},
                url="http://localhost:3000/studio/models/vision-pro-tuned",
            )

    result = publish_model_by_slug(gateway=FakeGateway(), slug="vision-pro-tuned")

    assert result == {
        "id": "derived-1",
        "slug": "vision-pro-tuned",
        "visibility": "public",
        "readiness": {"is_ready": True, "blocking_reasons": []},
        "url": "http://localhost:3000/studio/models/vision-pro-tuned",
    }


class TestSyncSdkModesToConfig:
    """Tests for _sync_sdk_modes_to_config function."""

    def test_no_changes_when_modes_match(self) -> None:
        from aimp_cli.operations.publish.core import _sync_sdk_modes_to_config
        from aimp_cli.domain.models import InputDefinition, SdkContract, SdkModeContract

        sdk_contract = SdkContract(
            schema_version=4,
            resources={
                "vector_db": {
                    "collections": [
                        {
                            "alias": "docs",
                            "name": "Documents",
                            "description": "Document embeddings used by vector-backed modes.",
                        }
                    ]
                }
            },
            modes={
                "generate": SdkModeContract(
                    inputs=[{"name": "text", "kind": "text", "required": True}],
                ),
            },
            parameters={},
        )
        project_config = ProjectConfig(
            resources=ResourceConfig(vector_db=False),
            modes=ModesConfig(
                {
                    "generate": ModeContract(
                        inputs=[InputDefinition(name="text", kind="text", required=True)],
                        outputs=["text"],
                    ),
                }
            ),
        )

        result = _sync_sdk_modes_to_config(
            sdk_contract=sdk_contract,
            project_config=project_config,
        )

        assert result.has_changes
        assert result.added_modes == []
        assert result.updated_resources
        assert project_config.resources.vector_collections == [
            VectorCollectionConfig(
                alias="docs",
                name="Documents",
                description="Document embeddings used by vector-backed modes.",
            )
        ]

    def test_adds_new_mode_from_sdk(self) -> None:
        from aimp_cli.operations.publish.core import _sync_sdk_modes_to_config
        from aimp_cli.domain.models import InputDefinition, SdkContract, SdkModeContract

        sdk_contract = SdkContract(
            schema_version=4,
            resources={
                "vector_db": {
                    "collections": [
                        {
                            "alias": "docs",
                            "name": "Documents",
                            "description": "Document embeddings used by vector-backed modes.",
                        }
                    ]
                }
            },
            modes={
                "generate": SdkModeContract(
                    inputs=[{"name": "text", "kind": "text", "required": True}],
                ),
                "search": SdkModeContract(
                    inputs=[{"name": "query", "kind": "text", "required": True}],
                    description="Search for similar images",
                    resources=ModeResourcesConfig(vector_aliases=["docs"]),
                ),
            },
            parameters={},
        )
        project_config = ProjectConfig(
            resources=ResourceConfig(vector_db=False),
            modes=ModesConfig(
                {
                    "generate": ModeContract(
                        inputs=[InputDefinition(name="text", kind="text", required=True)],
                        outputs=["text"],
                    ),
                }
            ),
        )

        result = _sync_sdk_modes_to_config(
            sdk_contract=sdk_contract,
            project_config=project_config,
        )

        assert result.has_changes
        assert result.added_modes == ["search"]
        assert "search" in project_config.modes
        search_mode = project_config.modes["search"]
        assert len(search_mode.inputs) == 1
        assert search_mode.inputs[0].name == "query"
        assert search_mode.inputs[0].kind == "text"
        assert search_mode.outputs is None
        assert search_mode.description == "Search for similar images"
        assert search_mode.resources is not None
        assert search_mode.resources.vector_aliases == ["docs"]
        assert project_config.resources.vector_collections == [
            VectorCollectionConfig(
                alias="docs",
                name="Documents",
                description="Document embeddings used by vector-backed modes.",
            )
        ]

    def test_syncs_vector_aliases_from_sdk_contract(self) -> None:
        from aimp_cli.operations.publish.core import _sync_sdk_modes_to_config
        from aimp_cli.domain.models import InputDefinition, SdkContract, SdkModeContract

        sdk_contract = SdkContract(
            schema_version=4,
            resources={
                "vector_db": {
                    "collections": [
                        {
                            "alias": "docs",
                            "name": "Documents",
                            "description": "Document embeddings used by vector-backed modes.",
                        }
                    ]
                }
            },
            modes={
                "generate": SdkModeContract(),
                "search": SdkModeContract(
                    resources=ModeResourcesConfig(vector_aliases=["docs"]),
                ),
            },
            parameters={},
        )
        project_config = ProjectConfig(
            resources=ResourceConfig(vector_db=False),
            modes=ModesConfig(
                {
                    "generate": ModeContract(
                        inputs=[InputDefinition(name="text", kind="text", required=True)],
                        outputs=["text"],
                    ),
                }
            ),
        )

        result = _sync_sdk_modes_to_config(
            sdk_contract=sdk_contract,
            project_config=project_config,
        )

        assert result.has_changes
        assert result.updated_resources
        assert "search" in project_config.modes
        assert project_config.resources.vector_db_enabled is True
        assert project_config.resources.vector_aliases == ["docs"]
        assert project_config.resources.vector_collections == [
            VectorCollectionConfig(
                alias="docs",
                name="Documents",
                description="Document embeddings used by vector-backed modes.",
            )
        ]
        assert project_config.modes["search"].resources is not None
        assert project_config.modes["search"].resources.vector_aliases == ["docs"]

    def test_preserves_existing_toml_config(self) -> None:
        from aimp_cli.operations.publish.core import _sync_sdk_modes_to_config
        from aimp_cli.domain.models import InputDefinition, SdkContract, SdkModeContract

        sdk_contract = SdkContract(
            schema_version=4,
            modes={
                "generate": SdkModeContract(
                    inputs=[{"name": "text", "kind": "text", "required": True}],
                ),
            },
            parameters={},
        )
        project_config = ProjectConfig(
            resources=ResourceConfig(vector_db=False),
            modes=ModesConfig(
                {
                    "generate": ModeContract(
                        inputs=[
                            InputDefinition(name="image", kind="image", required=True),
                            InputDefinition(name="text", kind="text", required=True),
                        ],
                        outputs=["json"],
                        description="Custom description",
                    ),
                }
            ),
        )

        result = _sync_sdk_modes_to_config(
            sdk_contract=sdk_contract,
            project_config=project_config,
        )

        assert not result.has_changes
        generate_mode = project_config.modes["generate"]
        assert len(generate_mode.inputs) == 2
        input_names = {inp.name for inp in generate_mode.inputs}
        assert input_names == {"image", "text"}
        assert generate_mode.outputs == ["json"]
        assert generate_mode.description == "Custom description"

    def test_syncs_multiple_new_modes(self) -> None:
        from aimp_cli.operations.publish.core import _sync_sdk_modes_to_config
        from aimp_cli.domain.models import InputDefinition, SdkContract, SdkModeContract

        sdk_contract = SdkContract(
            schema_version=4,
            resources={
                "vector_db": {
                    "collections": [
                        {
                            "alias": "docs",
                            "name": "Documents",
                            "description": "Document embeddings used by vector-backed modes.",
                        }
                    ]
                }
            },
            modes={
                "generate": SdkModeContract(),
                "search": SdkModeContract(
                    resources=ModeResourcesConfig(vector_aliases=["docs"]),
                ),
                "classify": SdkModeContract(
                    inputs=[{"name": "image", "kind": "image", "required": True}],
                ),
            },
            parameters={},
        )
        project_config = ProjectConfig(
            resources=ResourceConfig(vector_db=False),
            modes=ModesConfig(
                {
                    "generate": ModeContract(
                        inputs=[InputDefinition(name="text", kind="text", required=True)],
                        outputs=["text"],
                    ),
                }
            ),
        )

        result = _sync_sdk_modes_to_config(
            sdk_contract=sdk_contract,
            project_config=project_config,
        )

        assert result.has_changes
        assert sorted(result.added_modes) == ["classify", "search"]
        assert "search" in project_config.modes
        assert "classify" in project_config.modes
        assert len(project_config.modes["classify"].inputs) == 1
        assert project_config.modes["classify"].inputs[0].name == "image"
        assert project_config.modes["classify"].inputs[0].kind == "image"
        assert project_config.resources.vector_db_enabled is True
        assert project_config.resources.vector_aliases == ["docs"]
