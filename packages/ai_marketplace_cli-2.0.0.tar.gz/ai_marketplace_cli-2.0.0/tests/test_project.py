"""Tests for unified project scaffolding and local config helpers."""

from __future__ import annotations

import tomllib
from pathlib import Path

from pytest import MonkeyPatch

from aimp_cli.domain.runtime_packages import OFFICIAL_RUNTIME_DEPENDENCY_SPECS
from aimp_cli.domain.models import (
    InputDefinition,
    ModeContract,
    ModeResourcesConfig,
    ModesConfig,
    ResourceConfig,
    VectorCollectionConfig,
    VectorResourceCollectionsConfig,
)
from aimp_cli.domain.project import (
    PROJECT_CONFIG_RELATIVE_PATH,
    PUBLISH_CONFIG_RELATIVE_PATH,
    ProjectConfig,
    build_local_publish_metadata,
    create_project_files,
    load_project_config,
    load_publish_config,
    resolve_project_mode_names,
    serialize_publish_config_toml,
)
from aimp_cli.operations.scaffold.sync import create_legacy_project_files, sync_project_scaffold


def test_create_project_files_creates_unified_deployable_scaffold(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)
    project_dir = create_project_files("demo-model")

    assert (project_dir / "model" / "model.py").exists()
    assert (project_dir / "agent.py").exists()
    assert (project_dir / "contract.toml").exists()
    assert (project_dir / ".aimp" / "project.toml").exists()
    assert (project_dir / ".aimp" / "publish.toml").exists()
    assert (project_dir / "Dockerfile").exists()
    assert (project_dir / "pyproject.toml").exists()
    assert (project_dir / "AGENTS.md").exists()
    assert (project_dir / "studio" / "article.mdx").exists()
    assert (project_dir / "studio" / "cover.jpg").exists()
    assert (project_dir / ".agents" / "skills" / "SKILL_INDEX.md").exists()
    assert (project_dir / ".agents" / "skills" / "model-development" / "SKILL.md").exists()
    assert (project_dir / ".agents" / "skills" / "studio-article-media" / "SKILL.md").exists()
    assert (project_dir / ".agents" / "skills" / "publish-readiness" / "SKILL.md").exists()
    assert (project_dir / ".agents" / "skills" / "tuning-development" / "SKILL.md").exists()
    assert (project_dir / ".agents" / "skills" / "ci-quality-gates" / "SKILL.md").exists()
    assert not (project_dir / ".aimp" / "sdk" / "python").exists()
    assert not any(path.name == "__pycache__" for path in project_dir.rglob("__pycache__"))

    app_text = (project_dir / "agent.py").read_text(encoding="utf-8")
    model_text = (project_dir / "model" / "model.py").read_text(encoding="utf-8")
    vector_text = (project_dir / "model" / "vector.py").read_text(encoding="utf-8")
    modes_text = (project_dir / "model" / "modes.py").read_text(encoding="utf-8")
    schemas_text = (project_dir / "model" / "schemas.py").read_text(encoding="utf-8")
    agents_text = (project_dir / "AGENTS.md").read_text(encoding="utf-8")
    docker_text = (project_dir / "Dockerfile").read_text(encoding="utf-8")
    pyproject_text = (project_dir / "pyproject.toml").read_text(encoding="utf-8")

    assert "class DemoModelAgent(Agent):" in app_text
    assert "models = [Example]" in app_text
    assert "from aimp_framework.base import Agent" in app_text
    assert "class GenerateMode(Mode):" not in app_text
    assert "from model.model import Example" in app_text
    assert "train = [ExampleTrainer]" in model_text
    assert "vectors = [DocsVector]" in model_text
    assert "metric = Metric.COSINE" in vector_text
    assert (project_dir / "model" / "vector.py").exists()
    assert (project_dir / "model" / "modes.py").exists()
    assert (project_dir / "model" / "schemas.py").exists()
    assert (project_dir / "model" / "trainer.py").exists()
    assert (project_dir / "model" / "engine.py").exists()
    assert "class SearchMode(Mode):" in modes_text
    assert "class IndexMode(Mode):" in modes_text
    assert "class GenerateInput(Schema):" in schemas_text
    assert "class LoraParameters(Schema):" in schemas_text
    assert not (project_dir / "scripts" / "build.py").exists()
    assert "# syntax=docker/dockerfile:1.7" in docker_text
    assert "RUN --mount=type=secret,id=python_package_extra_index_pip_conf," in docker_text
    assert "pip install --no-cache-dir ." in docker_text
    assert f'"{OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-framework"]}"' in pyproject_text
    assert f'"{OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-sdk"]}"' in pyproject_text
    assert "[tool.uv.sources]" not in pyproject_text
    assert 'RUN python -m aimp_sdk.build_runner --module /app/agent.py' in docker_text
    assert "`agent.py`" in agents_text
    assert "`model-development`" in agents_text
    assert "`studio-article-media`" in agents_text
    assert "`publish-readiness`" in agents_text


def test_create_project_files_does_not_add_local_uv_sources_when_runtime_repo_is_adjacent(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    repo_root = tmp_path / "workspace"
    (repo_root / "framework" / "python").mkdir(parents=True)
    (repo_root / "framework" / "python" / "pyproject.toml").write_text(
        '[project]\nname = "ai-marketplace-framework"\nversion = "0.1.0"\n',
        encoding="utf-8",
    )
    (repo_root / "sdk" / "python").mkdir(parents=True)
    (repo_root / "sdk" / "python" / "pyproject.toml").write_text(
        '[project]\nname = "ai-marketplace-sdk"\nversion = "0.1.0"\n',
        encoding="utf-8",
    )

    monkeypatch.chdir(repo_root)
    project_dir = create_project_files("demo-model")
    pyproject_text = (project_dir / "pyproject.toml").read_text(encoding="utf-8")

    assert "[tool.uv.sources]" not in pyproject_text


def test_official_runtime_dependency_specs_match_cli_manifest() -> None:
    cli_manifest = Path(__file__).resolve().parents[1] / "pyproject.toml"
    payload = tomllib.loads(cli_manifest.read_text(encoding="utf-8"))

    assert payload["project"]["dependencies"][:2] == [
        OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-framework"],
        OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-sdk"],
    ]


def test_load_project_and_publish_config_for_unified_project(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)
    project_dir = create_project_files("demo-model")

    project_config = load_project_config(project_dir)
    publish_config = load_publish_config(project_dir)

    assert resolve_project_mode_names(project_config) == ["generate", "search", "index"]
    assert [item.name for item in project_config.modes["generate"].inputs] == ["prompt"]
    assert [item.name for item in project_config.modes["search"].inputs] == ["query"]
    assert [item.name for item in project_config.modes["index"].inputs] == ["text", "source"]
    assert project_config.capabilities.vector is True
    assert project_config.capabilities.tuning is False
    assert project_config.resources.model_dump(exclude_none=True) == {
        "vector_db": {
            "collections": [
                {
                    "alias": "docs",
                    "name": "Documents",
                    "description": "Document embeddings used by vector-backed modes.",
                }
            ]
        }
    }
    assert publish_config.studio.article_mdx_file == "studio/article.mdx"
    assert publish_config.hardware.supported_tiers == ["cpu-basic"]
    assert publish_config.python_packages is None


def test_load_project_config_does_not_infer_vector_resources_from_capabilities(
    tmp_path: Path,
) -> None:
    config_path = tmp_path / PROJECT_CONFIG_RELATIVE_PATH
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(
        "\n".join(
            [
                "schema_version = 3",
                "",
                "[capabilities]",
                "vector = true",
                "tuning = false",
                "",
                "[modes.generate]",
                'outputs = ["text"]',
                "",
                "[[modes.generate.inputs]]",
                'name = "prompt"',
                'kind = "text"',
                "required = true",
            ]
        ),
        encoding="utf-8",
    )

    project_config = load_project_config(tmp_path)

    assert project_config.capabilities.vector is True
    assert project_config.resources.model_dump(exclude_none=True) == {"vector_db": False}


def test_load_project_config_rejects_root_contract_file(tmp_path: Path) -> None:
    (tmp_path / "aimp.config.toml").write_text(
        '[interface.input]\nprimary = "text"\nattachments = ["image"]\n\n'
        '[interface.output]\nprimary = "text"\nattachments = []\n\n'
        '[capabilities]\nactions = ["search", "index"]\n',
        encoding="utf-8",
    )

    try:
        load_project_config(tmp_path)
    except RuntimeError as exc:
        assert "Root contract file is no longer supported" in str(exc)
    else:
        raise AssertionError("Expected root contract rejection")


def test_build_local_publish_metadata_and_serialize() -> None:
    publish_config, article = build_local_publish_metadata(
        {
            "name": "Codex",
            "tags": ["agent"],
            "visibility": "public",
            "studio": {
                "article": {
                    "format": "tiptap-json",
                    "schema_version": 1,
                    "content": {"type": "doc"},
                }
            },
            "supported_hardware_tiers": ["cpu-basic", "gpu-t4"],
            "hardware_tier": "gpu-t4",
            "pricing": {"developer_margin": 0.1, "platform_fee_pct": 0.3},
        }
    )
    assert "##" in article
    serialized = serialize_publish_config_toml(publish_config)
    assert 'name = "Codex"' in serialized
    assert 'supported_tiers = ["cpu-basic", "gpu-t4"]' in serialized
    assert "base_cost" not in serialized


def test_load_publish_config_accepts_python_package_index_section(tmp_path: Path) -> None:
    publish_path = tmp_path / PUBLISH_CONFIG_RELATIVE_PATH
    publish_path.parent.mkdir(parents=True, exist_ok=True)
    publish_path.write_text(
        "schema_version = 4\n\n"
        '[studio]\nname = "Demo"\ntags = ["example"]\nvisibility = "private"\n'
        'article_mdx_file = "studio/article.mdx"\n\n'
        '[hardware]\nsupported_tiers = ["cpu-basic"]\n\n'
        "[pricing]\ndeveloper_margin = 0\n\n"
        "[python_packages]\n"
        'extra_index_url = "https://test.pypi.org/simple/"\n',
        encoding="utf-8",
    )

    publish_config = load_publish_config(tmp_path)
    serialized = serialize_publish_config_toml(publish_config)

    assert publish_config.python_packages is not None
    assert publish_config.python_packages.extra_index_url == "https://test.pypi.org/simple/"
    assert '[python_packages]\nextra_index_url = "https://test.pypi.org/simple/"' in serialized


def test_legacy_scaffold_helper_remains_available_for_sync_tests(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)
    previous_config = ProjectConfig(
        schema_version=3,
        capabilities={"vector": True, "tuning": False},
        resources=ResourceConfig(
            vector_db=VectorResourceCollectionsConfig(
                collections=[
                    VectorCollectionConfig(
                        alias="docs",
                        name="Documents",
                        description="Document embeddings used by vector-backed modes.",
                    )
                ]
            )
        ),
        modes=ModesConfig(
            {
                "generate": ModeContract(
                    inputs=[InputDefinition(name="text", kind="text", required=True)],
                    outputs=["text"],
                ),
                "search": ModeContract(
                    inputs=[InputDefinition(name="text", kind="text", required=True)],
                    resources=ModeResourcesConfig(vector_aliases=["docs"]),
                ),
                "index": ModeContract(
                    inputs=[InputDefinition(name="text", kind="text", required=True)],
                    resources=ModeResourcesConfig(vector_aliases=["docs"]),
                ),
            }
        ),
    )
    next_config = ProjectConfig(
        schema_version=3,
        capabilities={"vector": False, "tuning": False},
        resources=ResourceConfig(vector_db=False),
        modes=ModesConfig(
            {
                "generate": ModeContract(
                    inputs=[InputDefinition(name="text", kind="text", required=True)],
                    outputs=["text"],
                ),
            }
        ),
    )

    project_dir = create_legacy_project_files("demo-model", contract_config=previous_config)
    summary = sync_project_scaffold(project_dir, next_config, previous_config=previous_config)

    assert "app/modes/search/mode.py" in summary["deleted"]
    assert "app/modes/index/mode.py" in summary["deleted"]
    assert "app/modes/generate/mode.py" in summary["preserved"]


def test_manual_config_files_still_load(tmp_path: Path) -> None:
    (tmp_path / ".aimp").mkdir()
    (tmp_path / PROJECT_CONFIG_RELATIVE_PATH).write_text(
        "schema_version = 3\n\n"
        "[capabilities]\n"
        "vector = false\n"
        "tuning = false\n\n"
        "[modes.generate]\n"
        "enabled = true\n"
        'outputs = ["text"]\n\n'
        "[[modes.generate.inputs]]\n"
        'name = "prompt"\n'
        'kind = "text"\n'
        "required = true\n",
        encoding="utf-8",
    )
    (tmp_path / PUBLISH_CONFIG_RELATIVE_PATH).write_text(
        "schema_version = 4\n\n"
        '[studio]\nname = "Demo"\ntags = ["example"]\nvisibility = "public"\n'
        'cover_file = "studio/cover.jpg"\n'
        'article_mdx_file = "studio/article.mdx"\n\n'
        '[hardware]\nsupported_tiers = ["cpu-basic"]\n\n'
        "[pricing]\ndeveloper_margin = 0.1\n",
        encoding="utf-8",
    )

    project_config = load_project_config(tmp_path)
    publish_config = load_publish_config(tmp_path)

    assert resolve_project_mode_names(project_config) == ["generate"]
    assert project_config.modes["generate"].outputs == ["text"]
    assert publish_config.studio.cover_file == "studio/cover.jpg"
