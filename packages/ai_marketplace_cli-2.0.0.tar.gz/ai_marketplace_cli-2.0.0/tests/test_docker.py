"""Tests for Docker access diagnostics."""

from __future__ import annotations

import json
import subprocess

import pytest

from aimp_cli.core.config import build_command_context
from aimp_cli.clients.docker import DockerClient
from aimp_cli.core.errors import CliError


def test_inspect_daemon_access_reports_permission_denied(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Docker socket permission failures should be reported explicitly."""
    docker = DockerClient(build_command_context("publish", debug=False, json_output=False))

    monkeypatch.setattr("aimp_cli.clients.docker.shutil.which", lambda _name: "/usr/bin/docker")

    def fail(*args: object, **kwargs: object) -> subprocess.CompletedProcess[str]:
        raise subprocess.CalledProcessError(
            1,
            ["docker", "info"],
            stderr=(
                "permission denied while trying to connect to the docker API at "
                "unix:///var/run/docker.sock"
            ),
        )

    monkeypatch.setattr("aimp_cli.clients.docker.subprocess.run", fail)

    result = docker.inspect_daemon_access()

    assert result.ok is False
    assert result.code == "docker_permission_denied"
    assert "cannot access the Docker daemon" in str(result.message)
    assert result.detail is not None
    assert "docker.sock" in result.detail


def test_inspect_daemon_access_reports_unreachable_daemon(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Generic docker-info failures should map to daemon unreachable."""
    docker = DockerClient(build_command_context("publish", debug=False, json_output=False))

    monkeypatch.setattr("aimp_cli.clients.docker.shutil.which", lambda _name: "/usr/bin/docker")

    def fail(*args: object, **kwargs: object) -> subprocess.CompletedProcess[str]:
        raise subprocess.CalledProcessError(
            1,
            ["docker", "info"],
            stderr="Cannot connect to the Docker daemon at unix:///var/run/docker.sock",
        )

    monkeypatch.setattr("aimp_cli.clients.docker.subprocess.run", fail)

    result = docker.inspect_daemon_access()

    assert result.ok is False
    assert result.code == "docker_not_running"
    assert "not running or not reachable" in str(result.message)
    assert result.detail is not None
    assert "Cannot connect" in result.detail


def test_get_image_manifest_uses_buildx_without_insecure_for_single_manifest(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Single-manifest images should be inspected without the unsupported flag."""
    docker = DockerClient(build_command_context("publish", debug=False, json_output=False))
    calls: list[list[str]] = []

    descriptor = {
        "mediaType": "application/vnd.oci.image.manifest.v1+json",
        "digest": "sha256:manifest",
        "size": 2002,
    }
    raw_manifest = {
        "schemaVersion": 2,
        "mediaType": "application/vnd.oci.image.manifest.v1+json",
        "config": {"digest": "sha256:config", "size": 10},
        "layers": [
            {
                "digest": "sha256:layer1",
                "size": 100,
                "mediaType": "application/vnd.oci.image.layer.v1.tar+gzip",
            }
        ],
    }

    def fake_run(
        args: list[str],
        *,
        capture_output: bool = True,
    ) -> subprocess.CompletedProcess[str]:
        calls.append(args)
        payload = descriptor if "--format" in args else raw_manifest
        return subprocess.CompletedProcess(args=args, returncode=0, stdout=json.dumps(payload))

    monkeypatch.setattr(docker, "_run", fake_run)

    manifest = docker.get_image_manifest("127.0.0.1:5050/demo/model:0.1.0")

    assert all("--insecure" not in call for call in calls)
    assert calls == [
        [
            "buildx",
            "imagetools",
            "inspect",
            "--format",
            "{{json .Manifest}}",
            "127.0.0.1:5050/demo/model:0.1.0",
        ],
        [
            "buildx",
            "imagetools",
            "inspect",
            "--raw",
            "127.0.0.1:5050/demo/model:0.1.0",
        ],
    ]
    assert manifest.digest == "sha256:manifest"
    assert manifest.total_size == 110
    assert len(manifest.layers) == 1


def test_get_image_manifest_resolves_publishable_manifest_from_oci_index(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """OCI indexes should resolve to the concrete platform manifest with layers."""
    docker = DockerClient(build_command_context("publish", debug=False, json_output=False))
    calls: list[list[str]] = []
    image_ref = "127.0.0.1:5050/demo/model:0.1.0"
    child_ref = (
        "127.0.0.1:5050/demo/model@"
        "sha256:realmanifest000000000000000000000000000000000000000000000000000001"
    )

    descriptor = {
        "mediaType": "application/vnd.oci.image.index.v1+json",
        "digest": "sha256:index",
        "size": 856,
        "manifests": [
            {
                "mediaType": "application/vnd.oci.image.manifest.v1+json",
                "digest": (
                    "sha256:realmanifest000000000000000000000000000000000000000000000000000001"
                ),
                "size": 2002,
                "platform": {"architecture": "amd64", "os": "linux"},
            },
            {
                "mediaType": "application/vnd.oci.image.manifest.v1+json",
                "digest": "sha256:attestation0000000000000000000000000000000000000000000000000001",
                "size": 566,
                "annotations": {"vnd.docker.reference.type": "attestation-manifest"},
                "platform": {"architecture": "unknown", "os": "unknown"},
            },
        ],
    }
    raw_manifest = {
        "schemaVersion": 2,
        "mediaType": "application/vnd.oci.image.manifest.v1+json",
        "config": {"digest": "sha256:config", "size": 20},
        "layers": [
            {"digest": "sha256:layer1", "size": 101, "mediaType": "layer/type"},
            {"digest": "sha256:layer2", "size": 202, "mediaType": "layer/type"},
        ],
    }

    def fake_run(
        args: list[str],
        *,
        capture_output: bool = True,
    ) -> subprocess.CompletedProcess[str]:
        calls.append(args)
        if args[-1] == image_ref:
            payload = descriptor
        elif args[-1] == child_ref:
            payload = raw_manifest
        else:
            raise AssertionError(f"Unexpected Docker args: {args}")
        return subprocess.CompletedProcess(args=args, returncode=0, stdout=json.dumps(payload))

    monkeypatch.setattr(docker, "_run", fake_run)

    manifest = docker.get_image_manifest(image_ref)

    assert manifest.digest == (
        "sha256:realmanifest000000000000000000000000000000000000000000000000000001"
    )
    assert manifest.total_size == 323
    assert [layer.digest for layer in manifest.layers] == ["sha256:layer1", "sha256:layer2"]
    assert manifest.raw_manifest["mediaType"] == "application/vnd.oci.image.manifest.v1+json"
    assert calls == [
        [
            "buildx",
            "imagetools",
            "inspect",
            "--format",
            "{{json .Manifest}}",
            image_ref,
        ],
        ["buildx", "imagetools", "inspect", "--raw", child_ref],
    ]


def test_get_image_manifest_rejects_ambiguous_platform_indexes(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Multi-platform indexes should fail explicitly instead of guessing."""
    docker = DockerClient(build_command_context("publish", debug=False, json_output=False))

    descriptor = {
        "mediaType": "application/vnd.oci.image.index.v1+json",
        "digest": "sha256:index",
        "manifests": [
            {
                "digest": "sha256:linuxamd64",
                "platform": {"architecture": "amd64", "os": "linux"},
            },
            {
                "digest": "sha256:linuxarm64",
                "platform": {"architecture": "arm64", "os": "linux"},
            },
        ],
    }

    monkeypatch.setattr(
        docker,
        "_run",
        lambda args, *, capture_output=True: subprocess.CompletedProcess(
            args=args,
            returncode=0,
            stdout=json.dumps(descriptor),
        ),
    )

    with pytest.raises(CliError) as exc_info:
        docker.get_image_manifest("registry.example.com/demo/model:0.1.0")

    error = exc_info.value
    assert error.code == "registry_manifest_ambiguous"
    assert "single-platform image" in str(error.hint)


def test_get_image_manifest_surfaces_manifest_inspection_failures(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Manifest inspection errors should be returned as structured CLI errors."""
    docker = DockerClient(build_command_context("publish", debug=False, json_output=False))

    def fail(args: list[str], *, capture_output: bool = True) -> subprocess.CompletedProcess[str]:
        raise subprocess.CalledProcessError(
            125,
            ["docker", *args],
            stderr="unknown flag: --insecure",
        )

    monkeypatch.setattr(docker, "_run", fail)

    with pytest.raises(CliError) as exc_info:
        docker.get_image_manifest("127.0.0.1:5050/demo/model:0.1.0")

    error = exc_info.value
    assert error.code == "registry_manifest_inspection_failed"
    assert "make verify-registry" in str(error.hint)
    assert error.extra["docker_diagnostic"] == "unknown flag: --insecure"
