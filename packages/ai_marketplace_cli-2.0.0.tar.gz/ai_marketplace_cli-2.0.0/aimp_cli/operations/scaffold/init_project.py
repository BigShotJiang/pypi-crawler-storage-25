"""Unified project scaffolding helpers for framework + platform projects."""

from __future__ import annotations

import shutil
from importlib import resources
from pathlib import Path

from aimp_cli.domain.models import (
    CapabilitiesConfig,
    InputDefinition,
    ModeContract,
    ModeResourcesConfig,
    ModesConfig,
    ResourceConfig,
    VectorCollectionConfig,
    VectorResourceCollectionsConfig,
)
from aimp_cli.domain.project_config import (
    ProjectConfig,
    default_agent_contract_metadata,
    write_agent_contract,
    write_project_config,
)
from aimp_cli.domain.publish_config import (
    PublishHardwareConfig,
    PublishMetadataConfig,
    PublishStudioConfig,
)
from aimp_cli.domain.serialization import serialize_publish_config_toml
from aimp_cli.operations.scaffold.renderers import (
    render_built_in_skill_templates,
    render_dockerfile,
    render_dockerignore,
    render_project_agents_md,
    render_pyproject_toml,
    render_studio_article_mdx,
    write_default_studio_cover,
)

_PLACEHOLDER_TOKENS = {
    "{{project_name}}": "project_name",
    "{{ project_name }}": "project_name",
}


def _template_root() -> resources.abc.Traversable:
    return resources.files("aimp_cli.assets").joinpath("project_template")


def _to_pascal_case(value: str) -> str:
    cleaned = "".join(character if character.isalnum() else " " for character in value)
    return "".join(part.capitalize() for part in cleaned.split()) or "Agent"


def _default_project_config() -> ProjectConfig:
    return ProjectConfig(
        schema_version=3,
        capabilities=CapabilitiesConfig(vector=True, tuning=False),
        resources=ResourceConfig(
            vector_db=VectorResourceCollectionsConfig(
                collections=[
                    VectorCollectionConfig(
                        alias="docs",
                        name="Documents",
                        description="Document embeddings used by vector-backed modes.",
                    )
                ]
            )
        ),
        modes=ModesConfig(
            {
                "generate": ModeContract(
                    inputs=[InputDefinition(name="prompt", kind="text", required=True)],
                    enabled=True,
                    outputs=["text"],
                    description="Generate text from a prompt.",
                ),
                "search": ModeContract(
                    inputs=[InputDefinition(name="query", kind="text", required=True)],
                    enabled=True,
                    outputs=["json"],
                    description="Search indexed documents in the docs vector collection.",
                    resources=ModeResourcesConfig(vector_aliases=["docs"]),
                ),
                "index": ModeContract(
                    inputs=[
                        InputDefinition(name="text", kind="text", required=True),
                        InputDefinition(name="source", kind="text", required=True),
                    ],
                    enabled=True,
                    outputs=["json"],
                    description="Index document content into the docs vector collection.",
                    resources=ModeResourcesConfig(vector_aliases=["docs"]),
                ),
            }
        ),
    )


def _default_publish_config(project_name: str) -> PublishMetadataConfig:
    return PublishMetadataConfig(
        schema_version=4,
        studio=PublishStudioConfig(
            name=_to_pascal_case(project_name),
            tags=["example", "starter"],
            visibility="private",
            cover_file="studio/cover.jpg",
            article_mdx_file="studio/article.mdx",
        ),
        hardware=PublishHardwareConfig(supported_tiers=["cpu-basic"]),
        pricing={"developer_margin": 0},
    )


def _apply_placeholders(project_dir: Path, *, project_name: str) -> None:
    replacements = {"project_name": project_name}

    for path in sorted(
        project_dir.rglob("*"),
        key=lambda candidate: len(candidate.parts),
        reverse=True,
    ):
        renamed_path = path
        for token, key in _PLACEHOLDER_TOKENS.items():
            if token in renamed_path.name:
                renamed_path = renamed_path.with_name(
                    renamed_path.name.replace(token, replacements[key])
                )
        if renamed_path != path:
            path.rename(renamed_path)
            path = renamed_path

        if not path.is_file():
            continue

        try:
            contents = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue

        rendered = contents
        for token, key in _PLACEHOLDER_TOKENS.items():
            rendered = rendered.replace(token, replacements[key])
        if rendered != contents:
            path.write_text(rendered, encoding="utf-8")


def _write_text(project_dir: Path, relative_path: str, contents: str) -> None:
    destination = project_dir / relative_path
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(contents, encoding="utf-8")


def _remove_python_cache_dirs(project_dir: Path) -> None:
    for cache_dir in project_dir.rglob("__pycache__"):
        shutil.rmtree(cache_dir, ignore_errors=True)


def _render_agent_bridge(project_name: str) -> str:
    agent_class_name = _to_pascal_case(project_name)
    if not agent_class_name.endswith("Agent"):
        agent_class_name = f"{agent_class_name}Agent"
    return "\n".join(
        [
            "from __future__ import annotations",
            "",
            "from aimp_framework.base import Agent",
            "",
            "from model.model import Example",
            "",
            "",
            f"class {agent_class_name}(Agent):",
            "    models = [Example]",
            "",
        ]
    )


def _render_agents_md() -> str:
    return render_project_agents_md()


def _write_platform_files(project_dir: Path, *, project_name: str) -> None:
    project_config = _default_project_config()
    publish_config = _default_publish_config(project_name)

    write_agent_contract(project_dir, default_agent_contract_metadata(project_name))
    write_project_config(project_dir, project_config)
    _write_text(
        project_dir,
        ".aimp/publish.toml",
        serialize_publish_config_toml(publish_config),
    )
    _write_text(
        project_dir,
        "pyproject.toml",
        render_pyproject_toml(project_name, project_dir=project_dir),
    )
    _write_text(project_dir, "agent.py", _render_agent_bridge(project_name))
    _write_text(project_dir, "Dockerfile", render_dockerfile())
    _write_text(project_dir, ".dockerignore", render_dockerignore())
    _write_text(project_dir, "AGENTS.md", _render_agents_md())
    _write_text(project_dir, "studio/article.mdx", render_studio_article_mdx())
    write_default_studio_cover(project_dir / "studio" / "cover.jpg")
    for relative_path, template in render_built_in_skill_templates(project_config).items():
        _write_text(project_dir, str(relative_path), template)


def create_project_scaffold(name: str) -> Path:
    """Create one full deployable project from the packaged framework template."""
    project_name = name.strip()
    project_dir = Path(project_name).resolve()
    if project_dir.exists():
        raise RuntimeError(f'Directory "{project_name}" already exists')

    with resources.as_file(_template_root()) as template_dir:
        shutil.copytree(
            template_dir,
            project_dir,
            ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.pyo"),
        )

    _apply_placeholders(project_dir, project_name=project_name)
    _write_platform_files(project_dir, project_name=project_name)
    _remove_python_cache_dirs(project_dir)
    return project_dir
