"""Template rendering for scaffolded project files."""

from __future__ import annotations

import json
import re
import shutil
from pathlib import Path
from typing import Any

from aimp_cli.clients.studio_article import default_studio_article_mdx
from aimp_cli.domain.constants import (
    APP_PACKAGE_RELATIVE_PATH,
    DEFAULT_AGENT_NAME,
    EMBEDDER_PACKAGE_NAME,
    FINE_TUNE_SCHEMA_MODULE_RELATIVE_PATH,
    GENERATOR_PACKAGE_NAME,
    SKILLS_RELATIVE_PATH,
    TUNING_ASSETS_RELATIVE_PATH,
    TUNING_BUNDLE_FILE_NAME,
    TUNING_HIDDEN_DIR_PATH,
    TUNING_HIDDEN_HELPERS_FILE,
    TUNING_HIDDEN_INIT_FILE,
    TUNING_HIDDEN_SCHEMA_FILE_NAME,
    TUNING_HIDDEN_SCHEMA_TYPES_FILE,
    TUNING_PREPARE_SCRIPT_FILE_NAME,
    TUNING_README_FILE_NAME,
)
from aimp_cli.domain.models import (
    InputDefinition,
    MediaType,
    ModeContract,
    ModeResourcesConfig,
    TuningSchemaConfig,
    TuningSchemaFieldConfig,
)
from aimp_cli.domain.runtime_packages import ordered_runtime_dependency_specs
from aimp_cli.domain.project_config import (
    ProjectConfig,
    default_project_config,
    resolve_project_operation_names,
)

MODES_PACKAGE_NAME = "modes"


def _template_root() -> Path:
    return Path(__file__).resolve().parent / "templates"


def _render_template(template_name: str, values: dict[str, str] | None = None) -> str:
    template_path = _template_root() / template_name
    content = template_path.read_text(encoding="utf-8")
    rendered = content
    for key, value in (values or {}).items():
        rendered = rendered.replace(f"{{{{{key}}}}}", value)
    unresolved = re.findall(r"\{\{[a-zA-Z0-9_]+\}\}", rendered)
    if unresolved:
        placeholders = ", ".join(sorted(set(unresolved)))
        raise RuntimeError(
            f"Unresolved scaffold template placeholders in {template_name}: {placeholders}"
        )
    return rendered


def _to_pascal_case(value: str) -> str:
    parts = [part.strip() for part in re.split(r"[^a-zA-Z0-9]+", value) if part.strip()]
    return "".join(part[:1].upper() + part[1:] for part in parts)


def build_class_name(name: str) -> str:
    """Build the scaffolded model class name."""
    base = _to_pascal_case(name) or "Model"
    if not re.match(r"^[A-Za-z]", base):
        base = f"Model{base}"
    return base if base.endswith("Model") else f"{base}Model"


def _input_description(op_name: str, name: str, kind: str) -> str:
    special_cases = {
        ("generate", "text"): "Primary text input for this mode",
        ("search", "text"): "Text query to search against the index",
        ("index", "text"): "Text content to embed and store in the index",
        ("index", "metadata"): "Optional metadata to store alongside the indexed vector",
    }
    special = special_cases.get((op_name, name)) or special_cases.get((op_name, kind))
    if special is not None:
        return special
    return f"{kind.title()} input for this mode"


def _python_literal(value: Any) -> str:
    return repr(value)


def _fine_tune_schema_import_line(config: Any) -> str:
    field_class_map = {
        "image": "ImageField",
        "audio": "AudioField",
        "video": "VideoField",
        "text": "TuningTextField",
        "file": "FileField",
        "json": "TuningJsonField",
    }
    imported_classes = ["FineTuneSchema"]
    for field in config.input_schema.fields:
        field_class = field_class_map[field.type]
        if field_class not in imported_classes:
            imported_classes.append(field_class)
    return f"from aimp_sdk import {', '.join(imported_classes)}"


def render_fine_tune_schema_module(config: Any) -> str:
    """Render the fine-tune schema scaffold."""
    field_class_map = {
        "image": "ImageField",
        "audio": "AudioField",
        "video": "VideoField",
        "text": "TuningTextField",
        "file": "FileField",
        "json": "TuningJsonField",
    }
    field_lines: list[str] = []
    for field in config.input_schema.fields:
        arguments = [f"required={'True' if field.required else 'False'}"]
        if field.description:
            arguments.append(f'description="{field.description}"')
        if field.multiple:
            arguments.append("multiple=True")
        field_lines.append(
            f"    {field.key} = {field_class_map[field.type]}({', '.join(arguments)})"
        )
    return _render_template(
        "tuning/schema.py.tpl",
        {
            "imports": _fine_tune_schema_import_line(config),
            "field_lines": ("\n" + "\n".join(field_lines)) if field_lines else "",
        },
    )


def _builder_name_for_input_kind(kind: MediaType) -> str:
    builder_map = {
        "text": "text",
        "image": "image",
        "audio": "audio",
        "video": "video",
        "file": "file",
        "json": "json",
    }
    return builder_map[kind]


def _mode_file_name(mode_name: str) -> str:
    return mode_name.replace("-", "_")


def _model_class_name(model_name: str) -> str:
    return f"{_to_pascal_case(model_name)}Model"


def _mode_class_name(mode_name: str) -> str:
    return f"{_to_pascal_case(mode_name) or 'Generate'}Mode"


def _knowledge_class_name(name: str) -> str:
    return f"{_to_pascal_case(name)}Knowledge"


def _render_input_field_line(input_def: Any) -> str:
    builder_name = _builder_name_for_input_kind(input_def.kind)
    parts = [
        f"description={_python_literal(input_def.description or _input_description('generate', input_def.name, input_def.kind))}"
    ]
    if not input_def.required:
        parts.append("required=False")
    if input_def.multiple:
        parts.append("multiple=True")
    return f"        {input_def.name}={builder_name}({', '.join(parts)}),"


def _mode_input_lines(mode_name: str, mode_config: Any) -> tuple[list[str], list[str]]:
    imports: list[str] = []
    lines: list[str] = []
    if mode_name == "generate":
        imports.append("text")
        return imports, ["        prompt=text(description='Primary text input for this mode'),"]
    if mode_name == "search":
        imports.append("text")
        return imports, [
            "        query=text(description='Text query to search against the index'),"
        ]
    if mode_name == "index":
        imports.append("text")
        return imports, ["        items=text(description='Text items to index', multiple=True),"]
    for input_def in mode_config.inputs:
        imports.append(_builder_name_for_input_kind(input_def.kind))
        lines.append(_render_input_field_line(input_def))
    return imports, lines


def _mode_output_spec(mode_name: str, mode_config: Any) -> tuple[list[str], list[str], str]:
    if mode_name == "generate":
        return ["text"], ["        result=text(),"], "result"
    if mode_name == "search":
        return ["text"], ["        results=text(multiple=True),"], "results"
    if mode_name == "index":
        return ["integer"], ["        indexed=integer(),"], "indexed"
    outputs = list(mode_config.outputs or ["text"])
    imports: list[str] = []
    lines: list[str] = []
    if len(outputs) == 1:
        kind = outputs[0]
        imports.append(
            "text" if kind in {"text", "image", "audio", "video", "file", "json"} else kind
        )
        helper = "text" if kind == "text" else kind
        lines.append(f"        result={helper}(),")
        return imports, lines, "result"
    for index, kind in enumerate(outputs, start=1):
        imports.append(
            "text" if kind in {"text", "image", "audio", "video", "file", "json"} else kind
        )
        helper = "text" if kind == "text" else kind
        lines.append(f"        output_{index}={helper}(),")
    return imports, lines, "result"


def _mode_parameters(mode_name: str) -> tuple[list[str], list[str]]:
    if mode_name != "search":
        return [], []
    return ["parameters_schema", "integer"], [
        "    parameters = parameters_schema(",
        "        limit=integer(description='Maximum matches to return', default=10, min=1, max=50),",
        "    )",
    ]


def _render_mode_schemas_module(mode_name: str, mode_config: Any) -> str:
    mode_class = _mode_class_name(mode_name)
    schema_base = mode_class.removesuffix("Mode")
    imports = {"inputs_schema", "outputs_schema"}
    input_imports, input_lines = _mode_input_lines(mode_name, mode_config)
    output_imports, output_lines, _output_name = _mode_output_spec(mode_name, mode_config)
    parameter_imports, parameter_lines = _mode_parameters(mode_name)
    imports.update(input_imports)
    imports.update(output_imports)
    imports.update(parameter_imports)

    lines = [f"from aimp_sdk import {', '.join(sorted(imports))}", "", ""]
    lines.extend(
        [
            f"{schema_base}Inputs = inputs_schema(",
            *input_lines,
            ")",
            "",
            f"{schema_base}Outputs = outputs_schema(",
            *output_lines,
            ")",
        ]
    )
    if parameter_lines:
        lines.extend(["", *parameter_lines])
        lines[-3] = f"{schema_base}Parameters = parameters_schema("
    else:
        lines.extend(["", f"{schema_base}Parameters = None"])
    lines.extend(["", ""])
    return "\n".join(lines)


def _render_mode_service_module(
    mode_name: str,
    mode_config: Any,
    *,
    model_name: str = GENERATOR_PACKAGE_NAME,
    knowledge_name: str | None = None,
) -> str:
    model_class = _model_class_name(model_name)
    knowledge_class = _knowledge_class_name(knowledge_name) if knowledge_name else None
    lines = [f"from app.{model_name}.model import {model_class}"]
    if knowledge_name and knowledge_class:
        lines.append(f"from app.{model_name}.knowledge.{knowledge_name} import {knowledge_class}")
    lines.extend(["", ""])
    signature = ["inputs", "params", f"model: {model_class}"]
    if knowledge_class:
        signature.append(f"docs: {knowledge_class}")
    lines.append(f"def execute({', '.join(signature)}):")
    if mode_name == "generate":
        lines.extend(
            [
                "    return {'result': model.generate(inputs.prompt)}",
            ]
        )
    elif mode_name == "search":
        lines.extend(
            [
                "    vector = model.embed(inputs.query)",
                "    hits = docs.search(vector, top_k=params.limit)",
                "    return {'results': [hit.text for hit in hits]}",
            ]
        )
    elif mode_name == "index":
        lines.extend(
            [
                "    vectors = model.embed_many(inputs.items)",
                "    docs.insert_many(inputs.items, vectors)",
                "    return {'indexed': len(inputs.items)}",
            ]
        )
    else:
        input_name = mode_config.inputs[0].name if mode_config.inputs else "text"
        lines.extend(
            [
                f"    return {{'result': model.generate(getattr(inputs, {_python_literal(input_name)}))}}",
            ]
        )
    lines.extend(["", ""])
    return "\n".join(lines)


def _render_mode_module(
    mode_name: str,
    mode_config: Any,
    *,
    model_name: str = GENERATOR_PACKAGE_NAME,
    knowledge_name: str | None = None,
) -> str:
    """Render one mode module — the public flow that orchestrates model(s)."""
    mode_class = _mode_class_name(mode_name)
    model_class = _model_class_name(model_name)
    lines = ["from aimp_sdk import Mode"]
    lines.append(f"from app.{model_name}.model import {model_class}")
    knowledge_class = None
    if knowledge_name:
        knowledge_class = _knowledge_class_name(knowledge_name)
        lines.append(f"from app.{model_name}.knowledge.{knowledge_name} import {knowledge_class}")
    schema_base = mode_class.removesuffix("Mode")
    lines.append(
        f"from .schemas import {schema_base}Inputs, {schema_base}Outputs, {schema_base}Parameters"
    )
    lines.append("from .service import execute")
    lines.extend(["", "", f"class {mode_class}(Mode):"])
    lines.append(f"    inputs = {schema_base}Inputs")
    lines.append(f"    outputs = {schema_base}Outputs")
    lines.append(f"    parameters = {schema_base}Parameters")
    lines.extend(["", f"    model: {model_class}"])
    if knowledge_class:
        lines.append(f"    docs: {knowledge_class}")
    lines.extend(
        [
            "",
            "    def run(self, inputs, params):",
            "        return execute(",
            "            inputs,",
            "            params,",
            "            self.model,",
        ]
    )
    if knowledge_class:
        lines.append("            self.docs,")
    lines.extend(["        )"])
    lines.extend(["", ""])
    return "\n".join(lines)


def _render_mode_package(
    mode_name: str,
    mode_config: Any,
    *,
    model_name: str = GENERATOR_PACKAGE_NAME,
    knowledge_name: str | None = None,
) -> dict[Path, str]:
    package_dir = APP_PACKAGE_RELATIVE_PATH / MODES_PACKAGE_NAME / _mode_file_name(mode_name)
    mode_class = _mode_class_name(mode_name)
    return {
        package_dir / "__init__.py": f"from .mode import {mode_class}\n\n__all__ = ['{mode_class}']\n",
        package_dir / "mode.py": _render_mode_module(
            mode_name,
            mode_config,
            model_name=model_name,
            knowledge_name=knowledge_name,
        ),
        package_dir / "service.py": _render_mode_service_module(
            mode_name,
            mode_config,
            model_name=model_name,
            knowledge_name=knowledge_name,
        ),
        package_dir / "schemas.py": _render_mode_schemas_module(mode_name, mode_config),
    }


def _render_generator_model(tuning_class_name: str = "GeneratorTuning") -> str:
    return "\n".join(
        [
            "from aimp_sdk import Tunable, TuneResult",
            f"from app.{GENERATOR_PACKAGE_NAME}.tuning import {tuning_class_name}",
            "",
            "",
            f"class {_model_class_name(GENERATOR_PACKAGE_NAME)}(Tunable):",
            f"    tuning = {tuning_class_name}",
            "",
            "    def setup(self, ctx) -> None:",
            "        # Load process-local runtime state once here.",
            "        # Example: self.llm = load_model(ctx.artifacts_dir)",
            "        self.artifacts_dir = ctx.artifacts_dir",
            "",
            "    def generate(self, prompt: str) -> str:",
            "        # Replace this with your real inference pipeline.",
            "        return prompt",
            "",
                "    def tune(self, session) -> TuneResult:",
                f"        # session.params      -> {tuning_class_name} fields",
                "        # session.data        -> training dataset",
                "        # session.adapter_dir -> save your LoRA weights here",
                "        record_count = sum(1 for _ in session.data)",
                "        return TuneResult(metrics={'validation_loss': 0.0, 'records': record_count})",
            "",
            "",
        ]
    )


def _render_generator_tuning(class_name: str = "GeneratorTuning") -> str:
    return "\n".join(
        [
            '"""Fine-tune schema for the generator model."""',
            "",
            "from __future__ import annotations",
            "",
            "from aimp_sdk import FineTuneSchema, TuningJsonField",
            "",
            "",
            f"class {class_name}(FineTuneSchema):",
            '    """Explicit training input contract for the generator model."""',
            "",
            '    input = TuningJsonField(required=True, description="Structured fine-tune record.")',
            "",
        ]
    )


def _render_embedder_model() -> str:
    return "\n".join(
        [
            "from aimp_sdk import Model",
            "",
            "",
            f"class {_model_class_name(EMBEDDER_PACKAGE_NAME)}(Model):",
            '    """Owns text embedding. No tuning, no generation — just embed and embed_many."""',
            "",
            "    def setup(self, ctx) -> None:",
            "        self.artifacts_dir = ctx.artifacts_dir",
            "",
            "    def embed(self, text: str) -> list[float]:",
            "        # Replace with your real embedding model.",
            "        return [float(len(text))]",
            "",
            "    def embed_many(self, texts: list[str]) -> list[list[float]]:",
            "        return [self.embed(t) for t in texts]",
            "",
            "",
        ]
    )


def _render_docs_knowledge() -> str:
    return "\n".join(
        [
            "from aimp_sdk import VectorKnowledge",
            "",
            "",
            "class DocsKnowledge(VectorKnowledge):",
            '    alias = "docs"',
            '    name = "Documents"',
            '    description = "Document embeddings used by vector-backed modes."',
            "",
        ]
    )


def render_default_model_packages(
    contract_config: ProjectConfig | None = None,
    agent_name: str = DEFAULT_AGENT_NAME,
) -> dict[Path, str]:
    """Render all model package files (generator/ and embedder/).

    Models are internal execution packages — no tools or mode files
    are generated here. Modes live in the top-level ``app/modes/`` directory.
    """
    config = contract_config or default_project_config()

    rendered: dict[Path, str] = {}

    # ── generator package ──
    gen = APP_PACKAGE_RELATIVE_PATH / GENERATOR_PACKAGE_NAME
    rendered[gen / "__init__.py"] = ""
    rendered[gen / "model.py"] = _render_generator_model()
    if config.tuning is not None and config.tuning.supported:
        rendered[FINE_TUNE_SCHEMA_MODULE_RELATIVE_PATH] = _render_generator_tuning()

    # ── embedder package ──
    emb = APP_PACKAGE_RELATIVE_PATH / EMBEDDER_PACKAGE_NAME
    rendered[emb / "__init__.py"] = ""
    rendered[emb / "model.py"] = _render_embedder_model()
    rendered[emb / "knowledge" / "__init__.py"] = ""
    rendered[emb / "knowledge" / "docs.py"] = _render_docs_knowledge()

    return rendered


def render_modes_package(
    contract_config: ProjectConfig | None = None,
    agent_name: str = DEFAULT_AGENT_NAME,
) -> dict[Path, str]:
    """Render all public mode files under ``app/modes/``.

    Each mode is a public flow that orchestrates one or more models.
    """
    config = contract_config or default_project_config()

    rendered: dict[Path, str] = {}

    modes_dir = APP_PACKAGE_RELATIVE_PATH / MODES_PACKAGE_NAME
    rendered[modes_dir / "__init__.py"] = ""

    # ── built-in modes ──
    if config.modes.get("generate") and config.modes["generate"].enabled:
        rendered.update(
            _render_mode_package(
                "generate",
                config.modes.get("generate")
                or ModeContract(
                    inputs=[InputDefinition(name="text", kind="text", required=True)],
                    enabled=True,
                    outputs=["text"],
                ),
                model_name=GENERATOR_PACKAGE_NAME,
            )
        )

    if config.modes.get("search") and config.modes["search"].enabled:
        rendered.update(
            _render_mode_package(
                "search",
                config.modes.get("search")
                or ModeContract(
                    inputs=[InputDefinition(name="text", kind="text", required=True)],
                    enabled=True,
                    resources=ModeResourcesConfig(vector_aliases=["docs"]),
                ),
                model_name=EMBEDDER_PACKAGE_NAME,
                knowledge_name="docs",
            )
        )

    if config.modes.get("index") and config.modes["index"].enabled:
        rendered.update(
            _render_mode_package(
                "index",
                config.modes.get("index")
                or ModeContract(
                    inputs=[InputDefinition(name="text", kind="text", required=True)],
                    enabled=True,
                    resources=ModeResourcesConfig(vector_aliases=["docs"]),
                ),
                model_name=EMBEDDER_PACKAGE_NAME,
                knowledge_name="docs",
            )
        )

    # ── custom modes (non-built-in) ──
    for mode_name, mode_config in config.modes.items():
        if mode_name in {"generate", "search", "index"}:
            continue
        if not mode_config.enabled:
            continue
        target_model = GENERATOR_PACKAGE_NAME
        knowledge_name = None
        if mode_config.resources is not None and mode_config.resources.vector_aliases:
            target_model = EMBEDDER_PACKAGE_NAME
            knowledge_name = mode_config.resources.vector_aliases[0]
        rendered.update(
            _render_mode_package(
                mode_name,
                mode_config,
                model_name=target_model,
                knowledge_name=knowledge_name,
            )
        )

    return rendered


def render_agent_module(
    name: str,
    contract_config: ProjectConfig | None = None,
    agent_name: str = DEFAULT_AGENT_NAME,
) -> str:
    """Render ``agent.py`` — assembly only, no business logic."""
    config = contract_config or default_project_config()
    base = _to_pascal_case(name) or "Agent"
    agent_class_name = base if base.endswith("Agent") else f"{base}Agent"
    enabled_modes = [mode_name for mode_name, mode in config.modes.items() if mode.enabled]
    import_lines = ["from aimp_framework.base import Agent"]
    mode_names: list[str] = []
    for mode_name in enabled_modes:
        mode_class = _mode_class_name(mode_name)
        file_name = _mode_file_name(mode_name)
        import_lines.append(f"from app.modes.{file_name}.mode import {mode_class}")
        mode_names.append(mode_class)
    return "\n".join(
        [
            *import_lines,
            "",
            "",
            f"class {agent_class_name}(Agent):",
            f"    modes = [{', '.join(mode_names)}]",
            "",
        ]
    )


def render_agent_package_init(
    contract_config: ProjectConfig | None = None,
    agent_name: str = DEFAULT_AGENT_NAME,
) -> dict[Path, str]:
    """Render ``__init__.py`` files for the scaffolded app package."""
    return {
        APP_PACKAGE_RELATIVE_PATH / "__init__.py": "",
        APP_PACKAGE_RELATIVE_PATH / MODES_PACKAGE_NAME / "__init__.py": "",
        APP_PACKAGE_RELATIVE_PATH / GENERATOR_PACKAGE_NAME / "__init__.py": "",
        APP_PACKAGE_RELATIVE_PATH / EMBEDDER_PACKAGE_NAME / "__init__.py": "",
        APP_PACKAGE_RELATIVE_PATH / EMBEDDER_PACKAGE_NAME / "knowledge" / "__init__.py": "",
    }


def _runtime_dependency_specs() -> tuple[str, str]:
    return ordered_runtime_dependency_specs()


def render_pyproject_toml(project_name: str, *, project_dir: Path | None = None) -> str:
    """Render the default project ``pyproject.toml``."""
    normalized_name = project_name.strip() or "agent-project"
    framework_spec, sdk_spec = _runtime_dependency_specs()
    _ = project_dir
    return "\n".join(
        [
            "[build-system]",
            'requires = ["hatchling"]',
            'build-backend = "hatchling.build"',
            "",
            "[project]",
            f'name = "{normalized_name}"',
            'version = "0.1.0"',
            f'description = "{normalized_name} agent"',
            'requires-python = ">=3.10"',
            "dependencies = [",
            f'    "{framework_spec}",',
            f'    "{sdk_spec}",',
            '    "pydantic>=2.10,<3",',
            "]",
            "",
            "[tool.hatch.build.targets.wheel]",
            'packages = ["model"]',
            "",
            "[tool.uv]",
            "package = false",
        ]
    )


def render_dockerfile() -> str:
    """Render the default Dockerfile."""
    return "\n".join(
        [
            "# syntax=docker/dockerfile:1.7",
            "",
            "FROM python:3.13-slim",
            "",
            "WORKDIR /app",
            "",
            "ENV PYTHONUNBUFFERED=1",
            "",
            "COPY pyproject.toml ./",
            "COPY agent.py ./agent.py",
            "COPY contract.toml ./contract.toml",
            "COPY model ./model",
            "",
            (
                "RUN --mount=type=secret,id=python_package_extra_index_pip_conf,"
                "target=/etc/pip.conf,required=false \\"
            ),
            "    pip install --no-cache-dir .",
            "",
            'RUN python -m aimp_sdk.build_runner --module /app/agent.py',
            "",
            'CMD ["python", "-m", "aimp_sdk.agent_worker", "--module", "/app/agent.py"]',
            "",
        ]
    )


def render_dockerignore() -> str:
    """Render the default .dockerignore."""
    return _render_template("dockerignore.tpl")

def render_studio_article_mdx() -> str:
    """Render the default Studio article."""
    return _render_template(
        "studio/article/article.mdx.tpl",
        {"article_source": default_studio_article_mdx()},
    )


def render_project_agents_md() -> str:
    """Render the project-local AGENTS.md file."""
    return _render_template("AGENTS.md.tpl")


def render_test_modules(name: str) -> dict[Path, str]:
    """Render the default project smoke tests."""
    agent_class_name = _to_pascal_case(name) or "Agent"
    agent_class_name = (
        agent_class_name if agent_class_name.endswith("Agent") else f"{agent_class_name}Agent"
    )
    return {
        Path("tests") / "test_app_import.py": "\n".join(
            [
                "from pathlib import Path",
                "from aimp_sdk.agent_loader import load_agent_class",
                "",
                "",
                "AGENT_PATH = Path(__file__).resolve().parents[1] / 'agent.py'",
                "",
                "def test_agent_import() -> None:",
                "    agent_cls = load_agent_class(str(AGENT_PATH))",
                f"    assert agent_cls.__name__ == '{agent_class_name}'",
                "",
            ]
        ),
        Path("tests") / "test_contract.py": "\n".join(
            [
                "from pathlib import Path",
                "from aimp_sdk.loader import load_contract",
                "",
                "",
                "AGENT_PATH = Path(__file__).resolve().parents[1] / 'agent.py'",
                "",
                "def test_contract_is_valid() -> None:",
                "    contract = load_contract(str(AGENT_PATH))",
                "    assert contract['schema_version'] >= 4",
                "    assert 'generate' in contract['modes']",
                "",
            ]
        ),
        Path("tests") / "test_dispatch.py": "\n".join(
            [
                "from pathlib import Path",
                "from aimp_sdk.agent_loader import load_agent_class",
                "",
                "",
                "AGENT_PATH = Path(__file__).resolve().parents[1] / 'agent.py'",
                "",
                "def test_generate_dispatch() -> None:",
                "    agent_cls = load_agent_class(str(AGENT_PATH))",
                "    agent = agent_cls()",
                "    assert agent.dispatch('generate', {'prompt': 'hello'}, {}) == {'result': 'hello'}",
                "",
            ]
        ),
    }


def _default_studio_cover_source_path() -> Path:
    return Path(__file__).resolve().parents[2] / "assets" / "default-cover.jpg"


def write_default_studio_cover(cover_path: Path) -> None:
    """Write the packaged default Studio cover to a project path."""
    cover_path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(_default_studio_cover_source_path(), cover_path)


def _consumer_tuning_placeholder(field: TuningSchemaFieldConfig) -> Any:
    if field.type == "text":
        value: Any = f"replace-with-{field.key.replace('_', '-')}"
    elif field.type == "json":
        value = {"example": field.key}
    elif field.type == "image":
        value = f"assets/{field.key}-example.png"
    elif field.type == "audio":
        value = f"assets/{field.key}-example.wav"
    elif field.type == "video":
        value = f"assets/{field.key}-example.mp4"
    else:
        value = f"assets/{field.key}-example.bin"
    return [value] if field.multiple else value


def _consumer_tuning_example_payload(schema_contract: dict[str, Any]) -> dict[str, Any]:
    schema = TuningSchemaConfig.model_validate(schema_contract)
    return {
        "records": [{field.key: _consumer_tuning_placeholder(field) for field in schema.fields}]
    }


def _build_field_definitions(schema: TuningSchemaConfig) -> str:
    lines: list[str] = []
    for field in schema.fields:
        python_type = "list[Any]" if field.multiple else "Any"
        default = "[]" if field.multiple else "None"

        field_line = f"    {field.key}: {python_type}"
        if not field.required:
            field_line += f" = {default}"

        if field.description:
            lines.append(f'    """{field.description}"""')

        lines.append(f"{field_line}\n")

    return "\n".join(lines)


def _render_schema_types(schema_contract: dict[str, Any], model_slug: str) -> str:
    schema = TuningSchemaConfig.model_validate(schema_contract)
    field_definitions = _build_field_definitions(schema)

    return _render_template(
        ".tuning/schema_types.py.tpl",
        {
            "model_slug": model_slug,
            "field_definitions": field_definitions,
            "schema_file_name": TUNING_HIDDEN_SCHEMA_FILE_NAME,
            "bundle_file_name": TUNING_BUNDLE_FILE_NAME,
        },
    )


def _render_helpers() -> str:
    return _render_template(
        ".tuning/helpers.py.tpl",
        {
            "schema_file_name": TUNING_HIDDEN_SCHEMA_FILE_NAME,
            "bundle_file_name": TUNING_BUNDLE_FILE_NAME,
        },
    )


def _render_init_py() -> str:
    return _render_template(".tuning/__init__.py.tpl")


def create_consumer_tuning_scaffold(
    output_dir: Path,
    *,
    model_slug: str,
    schema_contract: dict[str, Any],
) -> list[str]:
    """Create a consumer-facing fine-tune scaffold from a published schema."""
    schema = TuningSchemaConfig.model_validate(schema_contract)

    output_dir.mkdir(parents=True, exist_ok=True)
    assets_dir = output_dir / TUNING_ASSETS_RELATIVE_PATH
    assets_dir.mkdir(parents=True, exist_ok=True)

    tuning_dir = output_dir / TUNING_HIDDEN_DIR_PATH
    tuning_dir.mkdir(parents=True, exist_ok=True)

    schema_fields = "\n".join(
        (
            f"    - `{field.key}`: {field.type} "
            f"({'required' if field.required else 'optional'})"
            + (" [multiple]" if field.multiple else "")
        )
        for field in schema.fields
    )

    managed_files: dict[Path, str] = {
        output_dir / TUNING_PREPARE_SCRIPT_FILE_NAME: _render_template(
            "prepare_bundle.py.tpl",
            {
                "model_slug": model_slug,
                "schema_fields": schema_fields,
                "bundle_file_name": TUNING_BUNDLE_FILE_NAME,
            },
        ),
        output_dir / TUNING_README_FILE_NAME: _render_template(
            "fine_tune_readme.md.tpl",
            {
                "model_slug": model_slug,
                "schema_fields": schema_fields,
                "bundle_file_name": TUNING_BUNDLE_FILE_NAME,
            },
        ),
        assets_dir / "README.md": _render_template("assets_README.md.tpl"),
    }

    managed_files.update(
        {
            tuning_dir / TUNING_HIDDEN_SCHEMA_FILE_NAME: json.dumps(schema.model_dump(), indent=2)
            + "\n",
            tuning_dir / TUNING_HIDDEN_SCHEMA_TYPES_FILE.name: _render_schema_types(
                schema_contract, model_slug
            ),
            tuning_dir / TUNING_HIDDEN_HELPERS_FILE.name: _render_helpers(),
            tuning_dir / TUNING_HIDDEN_INIT_FILE.name: _render_init_py(),
        }
    )

    for file_path, contents in managed_files.items():
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(contents, encoding="utf-8")

    return [str(file_path.relative_to(output_dir)) for file_path in managed_files]


def regenerate_tuning_scaffold(
    output_dir: Path,
    *,
    model_slug: str,
    schema_contract: dict[str, Any],
) -> list[str]:
    """Regenerate the hidden .tuning/ folder without overwriting user edits."""
    schema = TuningSchemaConfig.model_validate(schema_contract)

    tuning_dir = output_dir / TUNING_HIDDEN_DIR_PATH
    tuning_dir.mkdir(parents=True, exist_ok=True)

    managed_files: dict[Path, str] = {
        tuning_dir / TUNING_HIDDEN_SCHEMA_FILE_NAME: json.dumps(schema.model_dump(), indent=2)
        + "\n",
        tuning_dir / TUNING_HIDDEN_SCHEMA_TYPES_FILE.name: _render_schema_types(
            schema_contract, model_slug
        ),
        tuning_dir / TUNING_HIDDEN_HELPERS_FILE.name: _render_helpers(),
        tuning_dir / TUNING_HIDDEN_INIT_FILE.name: _render_init_py(),
    }

    for file_path, contents in managed_files.items():
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(contents, encoding="utf-8")

    return [str(file_path.relative_to(output_dir)) for file_path in managed_files]


def _skill_template_path(name: str) -> str:
    return f"skills/{name}.md.tpl"


def render_built_in_skill_templates(config: ProjectConfig) -> dict[Path, str]:
    """Render project-local skill files for the generated scaffold."""
    operations = ", ".join(resolve_project_operation_names(config))
    vector_enabled = "true" if config.capabilities.vector else "false"
    values = {"operations": operations, "vector_enabled": vector_enabled}
    return {
        SKILLS_RELATIVE_PATH / "SKILL_INDEX.md": _render_template("skills/SKILL_INDEX.md.tpl"),
        SKILLS_RELATIVE_PATH / "model-development" / "SKILL.md": _render_template(
            _skill_template_path("model-development"),
            values,
        ),
        SKILLS_RELATIVE_PATH / "tuning-development" / "SKILL.md": _render_template(
            _skill_template_path("tuning-development")
        ),
        SKILLS_RELATIVE_PATH / "publish-readiness" / "SKILL.md": _render_template(
            _skill_template_path("publish-readiness")
        ),
        SKILLS_RELATIVE_PATH / "studio-article-media" / "SKILL.md": _render_template(
            _skill_template_path("studio-article-media")
        ),
        SKILLS_RELATIVE_PATH / "ci-quality-gates" / "SKILL.md": _render_template(
            _skill_template_path("ci-quality-gates")
        ),
    }
