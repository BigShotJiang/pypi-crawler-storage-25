"""Scaffold synchronization and project creation."""

from __future__ import annotations

import shutil
from pathlib import Path

from aimp_cli.domain.constants import (
    AGENT_ENTRYPOINT_RELATIVE_PATH,
    DEFAULT_AGENT_NAME,
)
from aimp_cli.domain.project_config import (
    ProjectConfig,
    default_agent_contract_metadata,
    default_project_config,
    write_agent_contract,
    write_project_config,
)

from .init_project import create_project_scaffold
from .renderers import (
    render_agent_module,
    render_agent_package_init,
    render_built_in_skill_templates,
    render_default_model_packages,
    render_dockerfile,
    render_dockerignore,
    render_modes_package,
    render_project_agents_md,
    render_pyproject_toml,
    render_studio_article_mdx,
    render_test_modules,
    write_default_studio_cover,
)


def _cleanup_legacy_directories(project_dir: Path, summary: dict[str, list[str]]) -> None:
    """Remove scaffold directories replaced by the current layout."""
    for old_dir in ("components", "vectors"):
        old_path = project_dir / old_dir
        if old_path.is_dir():
            shutil.rmtree(old_path)
            summary["deleted"].append(f"{old_dir}/")
    old_apps = project_dir / "apps"
    if old_apps.is_dir():
        shutil.rmtree(old_apps)
        summary["deleted"].append("apps/")

    old_flat_dirs = [
        project_dir / "app" / "models",
        project_dir / "app" / "tools",
        project_dir / "app" / "knowledge",
    ]
    for old_flat in old_flat_dirs:
        if old_flat.is_dir():
            shutil.rmtree(old_flat)
            summary["deleted"].append(str(old_flat.relative_to(project_dir)) + "/")

    # Remove legacy tools/ subdirectories inside model packages
    app_dir = project_dir / "app"
    if app_dir.is_dir():
        for child in app_dir.iterdir():
            if child.is_dir():
                tools_dir = child / "tools"
                if tools_dir.is_dir():
                    shutil.rmtree(tools_dir)
                    summary["deleted"].append(str(tools_dir.relative_to(project_dir)) + "/")


def _sync_rendered_files(
    project_dir: Path,
    rendered: dict[Path, str],
    previous_rendered: dict[Path, str],
    summary: dict[str, list[str]],
) -> None:
    """Write rendered files, update/create as needed, track deletions."""
    for relative_path, contents in rendered.items():
        absolute_path = project_dir / relative_path
        absolute_path.parent.mkdir(parents=True, exist_ok=True)
        if not absolute_path.exists():
            absolute_path.write_text(contents, encoding="utf-8")
            summary["created"].append(str(relative_path))
            continue
        current_content = absolute_path.read_text(encoding="utf-8")
        if current_content == contents:
            summary["preserved"].append(str(relative_path))
            continue
        previous_contents = previous_rendered.get(relative_path)
        if previous_contents is None or current_content == previous_contents:
            absolute_path.write_text(contents, encoding="utf-8")
            summary["updated"].append(str(relative_path))
        else:
            summary["preserved"].append(str(relative_path))

    for relative_path, previous_contents in previous_rendered.items():
        if relative_path in rendered:
            continue
        absolute_path = project_dir / relative_path
        if not absolute_path.exists():
            continue
        current_content = absolute_path.read_text(encoding="utf-8")
        if current_content == previous_contents:
            absolute_path.unlink()
            summary["deleted"].append(str(relative_path))
        else:
            summary["preserved"].append(str(relative_path))


def sync_project_scaffold(
    project_dir: Path,
    config: ProjectConfig,
    previous_config: ProjectConfig | None = None,
    agent_name: str = DEFAULT_AGENT_NAME,
) -> dict[str, list[str]]:
    """Create or update scaffold-owned wiring files for the current contract."""
    summary = {"created": [], "updated": [], "deleted": [], "preserved": []}

    _cleanup_legacy_directories(project_dir, summary)

    # Render and write agent.py
    agent_path = project_dir / AGENT_ENTRYPOINT_RELATIVE_PATH
    agent_path.parent.mkdir(parents=True, exist_ok=True)
    rendered_agent = render_agent_module(project_dir.name, config, agent_name=agent_name)
    if not agent_path.exists():
        agent_path.write_text(rendered_agent, encoding="utf-8")
        summary["created"].append(str(AGENT_ENTRYPOINT_RELATIVE_PATH))
    else:
        current_agent = agent_path.read_text(encoding="utf-8")
        if current_agent != rendered_agent:
            agent_path.write_text(rendered_agent, encoding="utf-8")
            summary["updated"].append(str(AGENT_ENTRYPOINT_RELATIVE_PATH))
        else:
            summary["preserved"].append(str(AGENT_ENTRYPOINT_RELATIVE_PATH))

    # Delete legacy resources.py
    legacy_resources_path = project_dir / "resources.py"
    if legacy_resources_path.exists():
        legacy_resources_path.unlink()
        summary["deleted"].append("resources.py")

    legacy_tuning_path = project_dir / "app" / "generator" / "tuning.py"
    if legacy_tuning_path.exists():
        legacy_tuning_path.unlink()
        summary["deleted"].append("app/generator/tuning.py")

    # Create legacy app package __init__.py files
    for relative_path, contents in render_agent_package_init(config, agent_name).items():
        absolute_path = project_dir / relative_path
        absolute_path.parent.mkdir(parents=True, exist_ok=True)
        if not absolute_path.exists():
            absolute_path.write_text(contents, encoding="utf-8")
            summary["created"].append(str(relative_path))

    # Sync model packages (generator/ and embedder/)
    rendered_models = render_default_model_packages(config, agent_name=agent_name)
    previous_rendered_models = (
        render_default_model_packages(previous_config, agent_name=agent_name)
        if previous_config
        else {}
    )
    _sync_rendered_files(project_dir, rendered_models, previous_rendered_models, summary)

    # Sync modes package (app/modes/)
    rendered_modes = render_modes_package(config, agent_name=agent_name)
    previous_rendered_modes = (
        render_modes_package(previous_config, agent_name=agent_name) if previous_config else {}
    )
    _sync_rendered_files(project_dir, rendered_modes, previous_rendered_modes, summary)

    return summary


def create_legacy_project_files(
    name: str,
    *,
    contract_config: ProjectConfig | None = None,
    include_skills: bool = True,
    agent_name: str = DEFAULT_AGENT_NAME,
) -> Path:
    """Create a new model project scaffold."""
    project_dir = Path(name).resolve()
    if project_dir.exists():
        raise RuntimeError(f'Directory "{name}" already exists')
    resolved_contract = contract_config or default_project_config()
    project_dir.mkdir(parents=True)
    (project_dir / "pyproject.toml").write_text(
        render_pyproject_toml(project_dir.name, project_dir=project_dir), encoding="utf-8"
    )
    (project_dir / "Dockerfile").write_text(render_dockerfile(), encoding="utf-8")
    (project_dir / ".dockerignore").write_text(render_dockerignore(), encoding="utf-8")
    (project_dir / "AGENTS.md").write_text(render_project_agents_md(), encoding="utf-8")
    write_agent_contract(project_dir, default_agent_contract_metadata(project_dir.name))
    write_project_config(project_dir, resolved_contract)
    sync_project_scaffold(project_dir, resolved_contract, agent_name=agent_name)
    for relative_path, contents in render_test_modules(project_dir.name).items():
        absolute_path = project_dir / relative_path
        absolute_path.parent.mkdir(parents=True, exist_ok=True)
        absolute_path.write_text(contents, encoding="utf-8")
    studio_dir = project_dir / "studio"
    (studio_dir / "media").mkdir(parents=True, exist_ok=True)
    (studio_dir / "article.mdx").write_text(render_studio_article_mdx(), encoding="utf-8")
    write_default_studio_cover(studio_dir / "cover.jpg")
    if include_skills:
        for relative_path, template in render_built_in_skill_templates(resolved_contract).items():
            absolute_path = project_dir / relative_path
            absolute_path.parent.mkdir(parents=True, exist_ok=True)
            absolute_path.write_text(template, encoding="utf-8")
    return project_dir


def create_project_files(
    name: str,
    *,
    contract_config: ProjectConfig | None = None,
    include_skills: bool = True,
    agent_name: str = DEFAULT_AGENT_NAME,
) -> Path:
    """Create the unified project scaffold used by `aimp init`."""
    _ = contract_config, include_skills, agent_name
    return create_project_scaffold(name)
