---
name: model-development
description: Use when editing model code under `model/*` or additional model packages.
---

# Model Development

## Local Facts

- Current public modes: `{{operations}}`
- Current `capabilities.vector`: `{{vector_enabled}}`
- `agent.py` registers models through `models = [...]`
- `contract.toml` is public metadata only
- `.aimp/project.toml` is the hidden source of enabled modes and capabilities

## Edit Here

- `model/modes.py`: public mode orchestration
- `model/schemas.py`: public input and parameter schemas
- `model/model.py`: model declaration and ownership
- `model/vector.py`: vector declarations and storage/query helpers
- `model/trainer.py`: fine-tune behavior
- `model/engine.py`: build-time and runtime loading hooks

## Rules

- Keep `agent.py` assembly-only
- Put public behavior in `model/modes.py`
- Keep schemas in `model/schemas.py`
- Declare model ownership in `model/model.py`
- Declare vectors in `model/vector.py` and register them in `model/model.py`
- Use `owner.models.get(OtherModel)` for cross-model orchestration
- Keep `Mode.run()` JSON-compatible
- Do not use `**kwargs`
- Do not fetch remote weights or assets in request-path code

## Patterns

```python
class GenerateMode(Mode):
    input_schema = GenerateInput
    parameter_schema = GenerateParameters

    def run(self, owner, data, params=None, context=None):
        return {"text": owner.generate(data.prompt)}
```

```python
class SearchMode(Mode):
    input_schema = SearchInput
    parameter_schema = SearchParameters
    vectors = [DocsVector]

    def run(self, owner, data, params=None, context=None):
        docs = owner.vectors.get(DocsVector)
        embedding = DocsVector.embed(data.query, dimension=docs.dimension)
        hits = docs.objects.search(embedding, limit=params.top_k if params else 10)
        return {"results": [hit.payload for hit in hits]}
```

## Commands

```bash
ai contract show --json
ai contract validate --json
```
