---
name: ci-quality-gates
description: Use when running the canonical local verification sequence before publish.
---

# CI Quality Gates

## Verification Order

1. Run `py_compile` on touched Python files when the change is structural.
2. Run targeted tests for the changed area.
3. Run `ai contract validate --json` when public surface or scaffold config changed.
4. Run publish-facing checks only after contract and tests are green.

## Commands

```bash
python3 -m py_compile <touched files>
ai contract validate --json
uv run pytest
ai publish --configure --json
```
