---
name: publish-readiness
description: Use when preparing a project for `ai publish` or checking publish inputs.
---

# Publish Readiness

## Inspect First

- `contract.toml`
- `.aimp/project.toml`
- `.aimp/publish.toml`
- `agent.py`
- `model/`
- `studio/article.mdx`
- `studio/cover.jpg`

## Common Checks

- `contract.toml` contains public agent metadata only
- `.aimp/project.toml` matches implemented public modes
- `.aimp/publish.toml` points to the correct Studio files and hardware intent
- `agent.py` stays assembly-only
- public modes in the hidden contract are actually implemented
- runtime downloads are not hidden inside request-path code
- build-time preparation lives in `model/engine.py` or the owning model package

## Commands

```bash
ai contract show --json
ai contract validate --json
ai publish --configure --json
ai push
```
