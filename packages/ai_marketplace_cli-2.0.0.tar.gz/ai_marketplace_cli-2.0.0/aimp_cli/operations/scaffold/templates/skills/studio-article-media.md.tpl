---
name: studio-article-media
description: Use when editing local Studio article files or syncing publish metadata.
---

# Studio Article and Media

## Local Files

- `studio/article.mdx`
- `studio/cover.jpg`
- `.aimp/publish.toml`

## Rules

- Treat `studio/article.mdx` as human-facing marketplace copy, not internal engineering notes
- Keep `studio/cover.jpg` aligned with the article and listing metadata
- Update `.aimp/publish.toml` if article or cover paths change
- Do not move product behavior details into the article; keep code guidance in `model/*` skills

## What To Produce

- a clear title and positioning
- concise capability summary
- realistic usage examples
- limits or prerequisites when they matter
- copy that matches the published model identity in `.aimp/publish.toml`

## Commands

```bash
ai model pull --slug <model-slug> --json
ai publish --configure --json
```
