# Project Skills

Open these local skills based on the task:

- `model-development`: use before editing `model/*`, `agent.py`, or additional model packages such as `model2/*`
- `studio-article-media`: use before editing `studio/article.mdx`, `studio/cover.jpg`, or Studio-facing copy
- `publish-readiness`: use before changing `contract.toml`, `.aimp/publish.toml`, hardware, pricing, or release flow
- `tuning-development`: use before editing `tuning.py` or `model/trainer.py`
- `ci-quality-gates`: use before final verification or when a task changes public behavior
