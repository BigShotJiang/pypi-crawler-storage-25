---
name: tuning-development
description: Use when enabling fine-tune, editing tuning schema/runtime, or building tuning bundles.
---

# Tuning Development

## Agent Workflow

- Read the local schema and contract before changing tuning files.

## Local Facts

- Fine-tune configuration must be declared in `.aimp/project.toml` via `ai init --with-tuning` or `ai contract edit --fine-tune`.
- Fine-tune logic must be implemented via the `tune(self, tuning)` method inside the relevant execution model.
- The matching schema must be declared in `tuning.py` and attached to the execution model explicitly.
- The platform handles remote job isolation. Local debugging runs fine-tuning in a single trial loop.

## Author Flow

1. Enable fine-tune support with `ai contract edit --fine-tune --json`.
2. Edit `tuning.py` to declare what fields the client must provide in the training dataset (`ImageField`, `TextField`, etc).
3. Overwrite or strictly implement the `tune(self, tuning)` method inside the owning model.
4. The platform will pass dataset records via `tuning.train_dataset`, validation records via `tuning.validation_dataset`, and trial parameters via `tuning.params`.
5. Publish the enabled model with `ai push`.

Example:
```python
# tuning.py
from aimp_sdk import FineTuneSchema, ImageField

class GeneratorTuning(FineTuneSchema):
    image = ImageField(description="Training sample")

# model/model.py
from aimp_sdk import Model, TuneResult

class GeneratorModel(Model):
    tuning = GeneratorTuning

    def tune(self, tuning) -> TuneResult:
        learning_rate = tuning.params.learning_rate
        epochs = tuning.params.epochs
        for record in tuning.train_dataset:
            # record.image matches the tuning schema Field above
            train_step(tuning.resolve_path(record.image), learning_rate=learning_rate)
        validation_loss = evaluate(tuning.validation_dataset)
        return TuneResult(metrics={"validation_loss": validation_loss, "epochs": epochs})
```

## Consumer Flow

1. Inspect schema with `ai fine-tune schema --model <model-slug> --json`.
2. Generate a workspace with `ai fine-tune scaffold --model <model-slug> --json`.
3. Fill `bundle.json` and local `assets/`, or edit `prepare_bundle.py`.
4. Create a job with `ai fine-tune create --model <model-slug> --output-dir . --json`.
5. Track jobs with `ai fine-tune list --json` and `ai fine-tune get --job <job-id> --json`.

## Commands

```bash
ai contract edit --fine-tune --json
ai fine-tune schema --json
ai fine-tune schema --model <model-slug> --json
ai fine-tune scaffold --model <model-slug> --json
ai fine-tune create --model <model-slug> --output-dir . --json
```
