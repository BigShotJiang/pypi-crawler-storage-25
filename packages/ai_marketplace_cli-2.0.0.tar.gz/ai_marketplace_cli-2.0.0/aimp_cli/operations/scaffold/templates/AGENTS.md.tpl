# AGENTS.md

This file is a router. Open the matching local skill before editing.

## Read First

- `agent.py`
- `contract.toml`
- `.aimp/project.toml`
- `.aimp/publish.toml`

## Use These Skills

- `model-development`: edit `model/*` or any additional model package such as `model2/*`
- `studio-article-media`: edit `studio/article.mdx` or `studio/cover.jpg`
- `publish-readiness`: edit `contract.toml` or `.aimp/publish.toml`, or prepare a release
- `tuning-development`: edit `tuning.py` or `model/trainer.py`
- `ci-quality-gates`: run the canonical local verification sequence

## Source Of Truth

- `agent.py` is assembly-only and registers model classes through `models = [...]`
- `model/modes.py` owns public mode behavior
- `model/schemas.py` owns public input and parameter schemas
- `model/model.py` declares `modes`, `train`, `engine`, and `vectors`
- `model/vector.py` owns vector-backed storage/query behavior
- `model/engine.py` owns build-time and runtime loading hooks
- `contract.toml` is public agent metadata only
- `.aimp/project.toml` is the hidden scaffold contract for enabled modes and capabilities
- `.aimp/publish.toml` stores publish intent only

## Global Rules

- Keep `agent.py` thin; do not put business logic there
- Do not define mode schemas or parameters in `contract.toml`
- Keep dependency and packaging changes in `pyproject.toml`, not in hidden vendored paths
- Prefer non-interactive CLI usage with explicit flags
- Prefer `--json` whenever supported
