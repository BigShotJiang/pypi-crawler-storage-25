# syntax=docker/dockerfile:1.7

FROM python:3.13-slim

WORKDIR /app

ENV PYTHONUNBUFFERED=1

COPY pyproject.toml ./
COPY agent.py ./agent.py
COPY contract.toml ./contract.toml
COPY model ./model

RUN --mount=type=secret,id=python_package_extra_index_pip_conf,target=/etc/pip.conf,required=false \
    pip install --no-cache-dir .

RUN python -m aimp_sdk.build_runner --module /app/agent.py

CMD ["python", "-m", "aimp_sdk.agent_worker", "--module", "/app/agent.py"]
