"""Fine-tune scaffold defaults."""

from __future__ import annotations

from aimp_cli.domain.models import (
    TuningConfig,
    TuningDatasetRequirementsConfig,
    TuningDatasetSpecConfig,
    TuningObjectiveConfig,
    TuningParameterDefinition,
    TuningSchemaConfig,
    TuningSchemaFieldConfig,
    TuningSplitPolicyConfig,
)
from aimp_cli.domain.project_config import ProjectConfig, default_project_config


def default_tuning_workspace_config(
    project_config: ProjectConfig | None = None,
) -> TuningConfig:
    """Return the default explicit fine-tune contract scaffold."""
    base_config = project_config or default_project_config()
    search_mode = base_config.modes.get("search")
    image_search_contract = (
        base_config.capabilities.vector
        and search_mode is not None
        and any(inp.kind == "image" for inp in search_mode.inputs)
    )
    if image_search_contract:
        fields = [
            TuningSchemaFieldConfig(
                key="query_image",
                type="image",
                required=True,
                description="Query image used for retrieval tuning.",
            ),
            TuningSchemaFieldConfig(
                key="candidate_image",
                type="image",
                required=True,
                description="Target image that should rank close to the query image.",
            ),
        ]
    else:
        fields = [
            TuningSchemaFieldConfig(
                key="input",
                type="json",
                required=True,
                description="Structured fine-tune record.",
            )
        ]
    return TuningConfig(
        supported=True,
        output_kind="lora",
        dataset_requirements=TuningDatasetRequirementsConfig(format="aimp_tuning_bundle_v1"),
        objective=TuningObjectiveConfig(name="validation_loss", direction="minimize"),
        split_policy=TuningSplitPolicyConfig(strategy="auto", validation_ratio=0.1),
        dataset_spec=TuningDatasetSpecConfig(format="aimp_tuning_bundle_v1"),
        input_schema=TuningSchemaConfig(fields=fields),
        parameters={
            "learning_rate": TuningParameterDefinition(
                kind="float",
                default=1e-5,
                min=1e-6,
                max=1e-4,
                log=True,
                required=True,
            ),
            "epochs": TuningParameterDefinition(
                kind="integer",
                default=3,
                min=1,
                max=5,
                required=True,
            ),
            "batch_size": TuningParameterDefinition(
                kind="select",
                default=16,
                options=[8, 16, 32],
                required=True,
            ),
        },
    )
