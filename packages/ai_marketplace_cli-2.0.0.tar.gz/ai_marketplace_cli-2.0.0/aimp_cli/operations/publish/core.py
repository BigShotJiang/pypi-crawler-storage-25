"""Publish workflow implementation."""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
import time
import tomllib
from collections.abc import Iterator
from contextlib import contextmanager
from fnmatch import fnmatch
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlparse, urlunparse
from urllib.request import urlopen

from rich.errors import LiveError
from rich.progress import (
    BarColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeElapsedColumn,
)

from aimp_cli.clients.gateway import UploadClient
from aimp_cli.clients.studio_article import (
    collect_local_media_references,
    parse_constrained_mdx,
    replace_media_sources,
)
from aimp_cli.core.config import CommandContext, console
from aimp_cli.core.errors import (
    CliError,
    coerce_cli_error,
    environment_error,
    remote_state_error,
    usage_error,
)
from aimp_cli.core.launcher import confirm_action
from aimp_cli.domain.constants import (
    AGENT_ENTRYPOINT_RELATIVE_PATH,
    FINE_TUNE_SCHEMA_MODULE_RELATIVE_PATH,
)
from aimp_cli.domain.models import (
    DEFAULT_MODEL_VERSION,
    ModelLookupResponse,
    ModeReadinessPayload,
    PublishBuildJob,
    PublishBuildJobCreateRequest,
    PublishRequest,
    SdkContract,
    StudioCoverPayload,
    StudioPublishPayload,
)
from aimp_cli.domain.project_config import (
    ProjectConfig,
    load_project_config,
    write_project_config,
)
from aimp_cli.domain.protocols import (
    DockerBackendProtocol,
    PublishGatewayProtocol,
    UploadClientFactoryProtocol,
    UploadClientProtocol,
)
from aimp_cli.domain.publish_config import (
    PublishPythonPackagesConfig,
    load_publish_config,
    load_studio_article_source,
    resolve_studio_file_paths,
)
from aimp_cli.domain.runtime_packages import (
    OFFICIAL_RUNTIME_DEPENDENCY_SPECS,
    RUNTIME_DEPENDENCY_NAMES,
)
from aimp_cli.presentation.renderers import render_publish_build_job
from aimp_cli.utils.docker_build import resolve_docker_build_spec
from aimp_cli.utils.execution_stream import ExecutionStreamCallbacks, watch_execution_stream

_ACTIVE_JOB_STATUSES = {"queued", "running"}
_LIVE_DISPLAY_DEPTH = 0
_DEFAULT_PYPI_SIMPLE_INDEX_URL = "https://pypi.org/simple/"
_RUNTIME_PACKAGE_INDEX_PROPAGATION_ATTEMPTS = 6
_RUNTIME_PACKAGE_INDEX_PROPAGATION_INTERVAL_SECONDS = 10.0
_RUNTIME_PACKAGE_INDEX_TIMEOUT_SECONDS = 5.0


def _runtime_pythonpaths() -> list[str]:
    repo_root = Path(__file__).resolve().parents[4]
    paths: list[str] = []
    for candidate in (repo_root / "sdk" / "python", repo_root / "framework" / "python"):
        if candidate.exists():
            paths.append(str(candidate))
    for module_name in ("aimp_sdk", "aimp_framework"):
        try:
            module = __import__(module_name)
        except ModuleNotFoundError:
            continue
        module_path = Path(module.__file__).resolve().parent.parent
        candidate = str(module_path)
        if candidate not in paths:
            paths.append(candidate)
    return paths


def _build_contract_pythonpath(
    *,
    project_dir: Path,
    env: dict[str, str],
) -> str:
    paths = [*_runtime_pythonpaths(), str(project_dir.resolve())]
    existing = env.get("PYTHONPATH")
    if existing:
        paths.append(existing)
    return os.pathsep.join(paths)


def _raise_legacy_vector_contract_shape(
    *,
    project_dir: Path,
    raw_resources: Any,
) -> None:
    """Reject legacy vector contract payloads emitted by stale authoring runtimes."""
    if not isinstance(raw_resources, dict):
        return
    vector_db = raw_resources.get("vector_db", False)
    legacy_shape: str | None = None
    if vector_db is True:
        legacy_shape = "resources.vector_db=true"
    elif isinstance(vector_db, dict) and "aliases" in vector_db:
        legacy_shape = "resources.vector_db.aliases"
    if legacy_shape is None:
        return
    raise usage_error(
        (
            f"Python authoring for '{project_dir.name}' emitted legacy vector resources "
            f"({legacy_shape}). This CLI only accepts "
            "resources.vector_db.collections for vector-enabled models."
        ),
        code="legacy_python_contract_shape",
        hint=(
            "Use the repo-aligned CLI/runtime packages. For local development run "
            "`uv run --project cli ai ...`, or reinstall the tool with "
            "`uv tool install ./cli --force`."
        ),
        extra={"project_dir": str(project_dir), "legacy_shape": legacy_shape},
    )


def _load_project_pyproject(project_dir: Path) -> dict[str, Any]:
    """Load and validate the project's ``pyproject.toml``."""
    pyproject_path = project_dir / "pyproject.toml"
    if not pyproject_path.exists():
        raise usage_error(
            "pyproject.toml is required for publish",
            code="pyproject_missing",
        )
    try:
        payload = tomllib.loads(pyproject_path.read_text(encoding="utf-8"))
    except tomllib.TOMLDecodeError as exc:
        raise usage_error(
            f"pyproject.toml is invalid: {exc}",
            code="pyproject_invalid",
        ) from exc
    if not isinstance(payload, dict):
        raise usage_error(
            "pyproject.toml must parse to a table payload",
            code="pyproject_invalid",
        )
    return payload


def _load_runtime_dependency_specs(project_dir: Path) -> dict[str, str]:
    """Load runtime package dependency specs from the project pyproject."""
    payload = _load_project_pyproject(project_dir)
    project = payload.get("project")
    if not isinstance(project, dict):
        raise usage_error(
            "pyproject.toml must define a [project] table",
            code="pyproject_missing_project",
        )
    dependencies = project.get("dependencies")
    if not isinstance(dependencies, list):
        raise usage_error(
            "pyproject.toml must define [project].dependencies as an array",
            code="pyproject_missing_dependencies",
        )
    resolved: dict[str, str] = {}
    for raw in dependencies:
        if not isinstance(raw, str):
            continue
        stripped = raw.strip()
        for name in RUNTIME_DEPENDENCY_NAMES:
            if _matches_runtime_dependency_name(stripped, name):
                resolved[name] = stripped
    missing = [name for name in RUNTIME_DEPENDENCY_NAMES if name not in resolved]
    if missing:
        raise usage_error(
            "pyproject.toml must declare runtime package dependencies: " + ", ".join(missing),
            code="runtime_dependencies_missing",
        )
    for package_name in RUNTIME_DEPENDENCY_NAMES:
        actual_spec = resolved[package_name]
        expected_spec = OFFICIAL_RUNTIME_DEPENDENCY_SPECS[package_name]
        if actual_spec != expected_spec:
            raise usage_error(
                (
                    "pyproject.toml must pin official runtime packages exactly for remote publish. "
                    f"Expected {expected_spec!r} but found {actual_spec!r}."
                ),
                code="runtime_dependencies_must_be_exact",
            )
    return resolved


def _legacy_runtime_path_sources(project_dir: Path) -> dict[str, str]:
    """Return runtime path sources declared via ``[tool.uv.sources]``."""
    payload = _load_project_pyproject(project_dir)
    tool = payload.get("tool")
    if not isinstance(tool, dict):
        return {}
    uv = tool.get("uv")
    if not isinstance(uv, dict):
        return {}
    sources = uv.get("sources")
    if not isinstance(sources, dict):
        return {}

    legacy_sources: dict[str, str] = {}
    for package_name in RUNTIME_DEPENDENCY_NAMES:
        source = sources.get(package_name)
        if not isinstance(source, dict):
            continue
        path_value = source.get("path")
        if isinstance(path_value, str) and path_value.strip():
            legacy_sources[package_name] = path_value.strip()
    return legacy_sources


def _reject_legacy_runtime_path_sources(project_dir: Path) -> None:
    """Reject local runtime path sources for remote publish."""
    legacy_sources = _legacy_runtime_path_sources(project_dir)
    if not legacy_sources:
        return
    package_names = ", ".join(RUNTIME_DEPENDENCY_NAMES)
    raise usage_error(
        (
            f"This project uses local runtime path sources for {package_names}. "
            "Remote publish supports published PyPI packages only. "
            "Remove [tool.uv.sources] from pyproject.toml or re-scaffold with "
            "the current CLI, then retry."
        ),
        code="runtime_path_sources_unsupported",
    )


def _matches_runtime_dependency_name(spec: str, package_name: str) -> bool:
    pattern = rf"^\s*{re.escape(package_name)}(?:\[[^]]+\])?(?:$|[\s<>=!~@(;])"
    return re.match(pattern, spec) is not None


def _extra_package_index_from_env() -> dict[str, str] | None:
    extra_index_url = os.getenv("AIMP_PYTHON_PACKAGE_EXTRA_INDEX_URL", "").strip()
    username = os.getenv("AIMP_PYTHON_PACKAGE_INDEX_USERNAME", "").strip()
    password = os.getenv("AIMP_PYTHON_PACKAGE_INDEX_PASSWORD", "")

    if not any((extra_index_url, username, password)):
        return None

    missing: list[str] = []
    if not extra_index_url:
        missing.append("AIMP_PYTHON_PACKAGE_EXTRA_INDEX_URL")
    if bool(username) != bool(password):
        if not username:
            missing.append("AIMP_PYTHON_PACKAGE_INDEX_USERNAME")
        if not password:
            missing.append("AIMP_PYTHON_PACKAGE_INDEX_PASSWORD")
    if missing:
        raise environment_error(
            "Python package extra index config is incomplete: " + ", ".join(missing),
            code="python_package_index_config_incomplete",
        )

    parsed = urlparse(extra_index_url)
    if parsed.scheme not in {"http", "https"}:
        raise environment_error(
            "AIMP_PYTHON_PACKAGE_EXTRA_INDEX_URL must use http or https.",
            code="python_package_index_config_invalid",
        )
    if not parsed.netloc:
        raise environment_error(
            "AIMP_PYTHON_PACKAGE_EXTRA_INDEX_URL must include a hostname.",
            code="python_package_index_config_invalid",
        )

    if not username and not password:
        return {"extra_index_url": extra_index_url}

    netloc = f"{quote(username, safe='')}:{quote(password, safe='')}@{parsed.netloc}"
    return {
        "extra_index_url": extra_index_url,
        "username": username,
        "password": password,
        "authenticated_extra_index_url": urlunparse(parsed._replace(netloc=netloc)),
    }


def _python_package_index_from_publish_config(
    publish_config: PublishPythonPackagesConfig | None,
) -> dict[str, str] | None:
    if publish_config is None:
        return None
    payload = {"extra_index_url": publish_config.extra_index_url}
    if publish_config.username is not None and publish_config.password is not None:
        payload["username"] = publish_config.username
        payload["password"] = publish_config.password
        parsed = urlparse(publish_config.extra_index_url)
        netloc = (
            f"{quote(publish_config.username, safe='')}:{quote(publish_config.password, safe='')}"
            f"@{parsed.netloc}"
        )
        payload["authenticated_extra_index_url"] = urlunparse(parsed._replace(netloc=netloc))
    return payload


def _resolve_python_package_index(
    publish_config: PublishPythonPackagesConfig | None,
) -> dict[str, str] | None:
    env_override = _extra_package_index_from_env()
    if env_override is not None:
        return env_override
    return _python_package_index_from_publish_config(publish_config)


def _normalize_simple_index_url(index_url: str) -> str:
    normalized = index_url.strip()
    if not normalized:
        return _DEFAULT_PYPI_SIMPLE_INDEX_URL
    return normalized.rstrip("/") + "/"


def _redact_package_index_url(index_url: str) -> str:
    parsed = urlparse(index_url)
    if not parsed.netloc or "@" not in parsed.netloc:
        return _normalize_simple_index_url(index_url)
    _, _, host = parsed.netloc.rpartition("@")
    return _normalize_simple_index_url(urlunparse(parsed._replace(netloc=host)))


def _runtime_package_index_urls(
    python_package_index: dict[str, str] | None,
) -> tuple[str, ...]:
    urls = [_DEFAULT_PYPI_SIMPLE_INDEX_URL]
    if python_package_index is not None:
        extra_index_url = str(python_package_index.get("extra_index_url", "")).strip()
        if extra_index_url:
            urls.append(extra_index_url)

    normalized_urls: list[str] = []
    seen: set[str] = set()
    for url in urls:
        normalized = _normalize_simple_index_url(url)
        if normalized in seen:
            continue
        normalized_urls.append(normalized)
        seen.add(normalized)
    return tuple(normalized_urls)


def _format_runtime_package_index_targets(
    python_package_index: dict[str, str] | None,
) -> str:
    return ", ".join(
        _redact_package_index_url(url) for url in _runtime_package_index_urls(python_package_index)
    )


def _minimum_runtime_package_version(spec: str, package_name: str) -> str | None:
    suffix = re.sub(
        rf"^\s*{re.escape(package_name)}(?:\[[^]]+\])?\s*",
        "",
        spec.strip(),
        count=1,
    )
    if not suffix:
        return None
    requirement_part = suffix.split(";", 1)[0].strip()
    if requirement_part.startswith("@"):
        return None
    minimum_version: str | None = None
    for clause in requirement_part.split(","):
        stripped = clause.strip()
        if not stripped:
            continue
        match = re.match(r"^(==|>=|~=)\s*([A-Za-z0-9_.!+-]+)$", stripped)
        if match is None:
            continue
        operator, version = match.groups()
        if operator == "==":
            return version
        if minimum_version is None:
            minimum_version = version
    return minimum_version


def _runtime_package_simple_index_url(index_url: str, package_name: str) -> str:
    normalized_name = re.sub(r"[-_.]+", "-", package_name).lower()
    return _normalize_simple_index_url(index_url) + f"{normalized_name}/"


def _fetch_runtime_package_simple_index(index_url: str, package_name: str) -> str:
    project_url = _runtime_package_simple_index_url(index_url, package_name)
    with urlopen(project_url, timeout=_RUNTIME_PACKAGE_INDEX_TIMEOUT_SECONDS) as response:
        return response.read().decode("utf-8", errors="replace")


def _simple_index_contains_package_version(
    package_name: str,
    version: str,
    page_content: str,
) -> bool:
    normalized_name_pattern = re.escape(package_name).replace(r"\-", "[-_]+")
    version_pattern = re.compile(
        rf"{normalized_name_pattern}[-_]+{re.escape(version)}(?:[-_.]|%2B)",
        re.IGNORECASE,
    )
    return version_pattern.search(page_content) is not None


def _missing_runtime_packages_from_indexes(
    *,
    dependency_specs: dict[str, str],
    python_package_index: dict[str, str] | None,
) -> dict[str, str] | None:
    index_urls = _runtime_package_index_urls(python_package_index)
    missing: dict[str, str] = {}
    for package_name in RUNTIME_DEPENDENCY_NAMES:
        required_version = _minimum_runtime_package_version(
            dependency_specs[package_name],
            package_name,
        )
        if required_version is None:
            continue

        found = False
        had_fetch_error = False
        for index_url in index_urls:
            try:
                page_content = _fetch_runtime_package_simple_index(index_url, package_name)
            except (HTTPError, URLError, OSError):
                had_fetch_error = True
                continue
            if _simple_index_contains_package_version(
                package_name,
                required_version,
                page_content,
            ):
                found = True
                break
        if found:
            continue
        if had_fetch_error:
            return None
        missing[package_name] = required_version
    return missing


def _wait_for_runtime_package_index_visibility(
    *,
    dependency_specs: dict[str, str],
    python_package_index: dict[str, str] | None,
) -> None:
    missing = _missing_runtime_packages_from_indexes(
        dependency_specs=dependency_specs,
        python_package_index=python_package_index,
    )
    if missing is None or not missing:
        return

    checked_indexes = _format_runtime_package_index_targets(python_package_index)
    missing_display = ", ".join(
        f"{package_name}=={version}" for package_name, version in missing.items()
    )
    propagation_window_seconds = int(
        _RUNTIME_PACKAGE_INDEX_PROPAGATION_ATTEMPTS
        * _RUNTIME_PACKAGE_INDEX_PROPAGATION_INTERVAL_SECONDS
    )
    console.print(
        "Runtime package release not yet visible on package index; "
        f"waiting up to {propagation_window_seconds}s "
        f"for propagation. Checked: {checked_indexes}. Missing: {missing_display}."
    )

    for _ in range(1, _RUNTIME_PACKAGE_INDEX_PROPAGATION_ATTEMPTS):
        time.sleep(_RUNTIME_PACKAGE_INDEX_PROPAGATION_INTERVAL_SECONDS)
        missing = _missing_runtime_packages_from_indexes(
            dependency_specs=dependency_specs,
            python_package_index=python_package_index,
        )
        if missing is None or not missing:
            return

    missing_display = ", ".join(
        f"{package_name}=={version}" for package_name, version in missing.items()
    )
    raise usage_error(
        (
            "Published runtime packages are not yet visible on the package index. "
            f"Checked: {checked_indexes}. Missing: {missing_display}."
        ),
        code="runtime_packages_unavailable",
    )


def _verify_runtime_packages_downloadable(
    *,
    dependency_specs: dict[str, str],
    python_bin: str | None,
    python_package_index: dict[str, str] | None,
) -> None:
    """Fail early when runtime packages cannot be resolved from a publishable index."""
    effective_python_package_index = python_package_index
    if effective_python_package_index is None:
        effective_python_package_index = _extra_package_index_from_env()

    _wait_for_runtime_package_index_visibility(
        dependency_specs=dependency_specs,
        python_package_index=effective_python_package_index,
    )

    uv_bin = shutil.which("uv")
    if not uv_bin:
        raise environment_error(
            "uv is required to verify publishable runtime packages.",
            code="uv_missing_for_publish_validation",
        )

    interpreter = python_bin or sys.executable
    env = os.environ.copy()
    with tempfile.TemporaryDirectory(prefix="aimp-runtime-download-") as temp_dir:
        cmd = [
            uv_bin,
            "pip",
            "install",
            "--dry-run",
            "--no-deps",
            "--no-sources",
            "--target",
            temp_dir,
            "--python",
            interpreter,
        ]
        if effective_python_package_index is not None:
            cmd.extend(
                [
                    "--extra-index-url",
                    effective_python_package_index.get("authenticated_extra_index_url")
                    or effective_python_package_index["extra_index_url"],
                ]
            )
        cmd.extend([dependency_specs[name] for name in RUNTIME_DEPENDENCY_NAMES])
        try:
            subprocess.run(
                cmd,
                check=True,
                capture_output=True,
                text=True,
                env=env,
            )
        except subprocess.CalledProcessError as exc:
            detail = (exc.stderr or exc.stdout or "").strip()
            raise usage_error(
                (
                    "Published runtime packages are not downloadable from the configured "
                    f"package index. Checked: "
                    f"{_format_runtime_package_index_targets(effective_python_package_index)}. "
                    "Release `ai-marketplace-framework` and "
                    "`ai-marketplace-sdk` before remote publish."
                )
                + (f" Details: {detail}" if detail else ""),
                code="runtime_packages_unavailable",
            ) from exc


class _SyncResult:
    """Result of syncing SDK modes to TOML config."""

    def __init__(self, added_modes: list[str], updated_resources: bool) -> None:
        self.added_modes = added_modes
        self.updated_resources = updated_resources

    @property
    def has_changes(self) -> bool:
        return bool(self.added_modes) or self.updated_resources


def _sync_sdk_modes_to_config(
    *,
    sdk_contract: SdkContract,
    project_config: ProjectConfig,
) -> _SyncResult:
    """Sync SDK-declared modes to project config.

    Adds new modes from SDK that aren't in TOML, preserving existing TOML config.
    Syncs resources from Python authoring declarations.

    Args:
        sdk_contract: Contract extracted from SDK @mode decorators.
        project_config: Current project config from contract.toml.

    Returns:
        _SyncResult with list of added modes and whether resources were updated.
    """
    from aimp_cli.domain.models import (
        InputDefinition,
        ModeContract,
        ModesConfig,
        ResourceConfig,
        SdkModeContract,
    )

    normalized_sdk_modes: dict[str, SdkModeContract] = {}
    for mode_name, raw_mode in dict(sdk_contract.modes).items():
        if isinstance(raw_mode, SdkModeContract):
            normalized_sdk_modes[mode_name] = raw_mode
        else:
            payload = dict(raw_mode or {})
            raw_inputs = payload.get("inputs")
            if isinstance(raw_inputs, list):
                normalized_inputs: list[dict[str, Any]] = []
                for item in raw_inputs:
                    if isinstance(item, str):
                        normalized_inputs.append({"name": item, "kind": item, "required": True})
                    else:
                        normalized_inputs.append(item)
                payload["inputs"] = normalized_inputs
            normalized_sdk_modes[mode_name] = SdkModeContract.model_validate(payload)

    sdk_mode_names = set(normalized_sdk_modes.keys())
    toml_mode_names = set(project_config.modes.names())

    added_modes: list[str] = []
    updated_resources = False
    new_modes: dict[str, ModeContract] = dict(project_config.modes.root)

    for mode_name in sorted(sdk_mode_names - toml_mode_names):
        sdk_mode = normalized_sdk_modes[mode_name]
        input_defs: list[InputDefinition] = []
        if sdk_mode.inputs:
            for inp in sdk_mode.inputs:
                if inp.kind not in ("text", "image", "audio", "video", "file", "json"):
                    continue
                input_defs.append(
                    InputDefinition(
                        name=inp.name,
                        kind=inp.kind,
                        required=inp.required,
                        description=inp.description or "",
                        multiple=inp.multiple,
                        label=inp.label,
                        default=inp.default,
                    )
                )
        if not input_defs:
            input_defs = [InputDefinition(name="text", kind="text", required=True)]

        new_modes[mode_name] = ModeContract(
            inputs=input_defs,
            outputs=["text"] if mode_name == "generate" else None,
            description=sdk_mode.description or "",
            resources=sdk_mode.resources.model_copy(deep=True) if sdk_mode.resources else None,
        )
        added_modes.append(mode_name)

    sdk_resources = ResourceConfig.model_validate(getattr(sdk_contract, "resources", {}) or {})
    alias_names = {
        alias
        for sdk_mode in normalized_sdk_modes.values()
        if sdk_mode.resources is not None
        for alias in sdk_mode.resources.vector_aliases
    }
    if alias_names:
        declared_aliases = {alias.lower() for alias in sdk_resources.vector_aliases}
        if not declared_aliases:
            raise ValueError(
                "resources.vector_db.collections must declare all mode-scoped vector aliases"
            )
        missing_aliases = [
            alias for alias in sorted(alias_names) if alias.lower() not in declared_aliases
        ]
        if missing_aliases:
            raise ValueError(
                "modes.*.resources.vector_aliases contains undeclared aliases: "
                + ", ".join(missing_aliases)
            )
    sdk_resources_changed = project_config.resources.model_dump(
        exclude_none=True
    ) != sdk_resources.model_dump(exclude_none=True)
    if sdk_resources_changed:
        project_config.resources = sdk_resources.model_copy(deep=True)
        project_config.capabilities.vector = project_config.resources.vector_db_enabled
        updated_resources = True

    if added_modes:
        project_config.modes = ModesConfig(new_modes)

    return _SyncResult(added_modes=added_modes, updated_resources=updated_resources)


class _NoopStatus:
    """No-op status handle used when a live display is already active."""

    def __init__(self, message: str) -> None:
        self.message = message

    def update(self, message: str) -> None:
        """Accept status updates without owning the console live display."""
        self.message = message


class _NoopProgress:
    """No-op progress handle used when a live display is already active."""

    def __init__(self) -> None:
        self._next_task_id = 0

    def add_task(self, *_args: Any, **_kwargs: Any) -> int:
        """Return a stable task identifier without rendering progress."""
        self._next_task_id += 1
        return self._next_task_id

    def update(self, *_args: Any, **_kwargs: Any) -> None:
        """Accept progress updates without rendering output."""

    def stop(self) -> None:
        """Mirror the Rich Progress stop API for callers."""


@contextmanager
def _managed_status(message: str, *, spinner: str = "line") -> Iterator[Any]:
    """Render a status spinner only when no other live display owns the console."""
    global _LIVE_DISPLAY_DEPTH

    if _LIVE_DISPLAY_DEPTH > 0:
        yield _NoopStatus(message)
        return

    status_manager = console.status(message, spinner=spinner)
    _LIVE_DISPLAY_DEPTH += 1
    try:
        try:
            status = status_manager.__enter__()
        except LiveError:
            yield _NoopStatus(message)
            return
        try:
            yield status
        finally:
            status_manager.__exit__(None, None, None)
    finally:
        _LIVE_DISPLAY_DEPTH -= 1


@contextmanager
def _managed_progress(*columns: Any, transient: bool) -> Iterator[Progress | _NoopProgress]:
    """Render progress only when no other live display owns the console."""
    global _LIVE_DISPLAY_DEPTH

    if _LIVE_DISPLAY_DEPTH > 0:
        yield _NoopProgress()
        return

    progress_manager = Progress(*columns, console=console, transient=transient)
    _LIVE_DISPLAY_DEPTH += 1
    try:
        try:
            progress = progress_manager.__enter__()
        except LiveError:
            yield _NoopProgress()
            return
        try:
            yield progress
        finally:
            progress_manager.__exit__(None, None, None)
    finally:
        _LIVE_DISPLAY_DEPTH -= 1


def _slug_to_name(value: str) -> str:
    parts = [part for part in value.replace("_", "-").split("-") if part]
    return " ".join(part[:1].upper() + part[1:] for part in parts) if parts else value


def _find_active_publish_build_job(
    *,
    gateway: PublishGatewayProtocol,
    slug: str,
) -> dict[str, Any] | None:
    """Return one active publish-build job payload for the target model when present."""
    payload = gateway.list_publish_build_jobs(model_slug=slug, page_size=100)
    for job in payload.results:
        if job.status in _ACTIVE_JOB_STATUSES:
            return job.model_dump()
    return None


def _extract_active_publish_build_job_from_error(error: CliError) -> dict[str, Any] | None:
    """Extract one existing publish-build job payload from a structured conflict error."""
    if error.code != "active_job_exists":
        return None
    if not isinstance(error.extra, dict):
        return None
    if error.extra.get("job_type") != "build":
        return None
    existing_job = error.extra.get("existing_job")
    return existing_job if isinstance(existing_job, dict) else None


def _raise_active_publish_build_error(
    *,
    slug: str,
    existing_job: dict[str, Any],
    request_id: str,
) -> None:
    """Raise a stable CLI conflict error for an existing active publish build job."""
    job_id = str(existing_job.get("job_id") or "").strip() or "unknown"
    status = str(existing_job.get("status") or "queued").strip() or "queued"
    raise remote_state_error(
        f"Active publish build job already exists for model '{slug}' ({job_id}, {status}).",
        code="active_job_exists",
        request_id=request_id,
        hint="Run `ai publish --force` to cancel the active build and start a new one.",
        http_status=409,
        extra={
            "job_type": "build",
            "model_slug": slug,
            "existing_job": existing_job,
        },
    )


def build_default_model_info(slug: str) -> ModelLookupResponse:
    """Return default model info for a new slug."""
    return ModelLookupResponse(
        id="",
        slug=slug,
        name=_slug_to_name(slug),
        version=DEFAULT_MODEL_VERSION,
        visibility="private",
        asset_type="model",
    )


def _build_contract_python_candidates(python_bin: str | None) -> list[str]:
    """Return ordered Python interpreter candidates for contract extraction."""
    candidates: list[str] = []
    seen: set[str] = set()

    def add(candidate: str | None) -> None:
        if not candidate:
            return
        normalized = candidate.strip()
        if not normalized or normalized in seen:
            return
        seen.add(normalized)
        candidates.append(normalized)

    add(python_bin)
    venv = os.getenv("VIRTUAL_ENV")
    if venv:
        add(str(Path(venv) / "bin" / "python"))
        add(str(Path(venv) / "Scripts" / "python.exe"))
        add(str(Path(venv) / "Scripts" / "python"))
    add(sys.executable)
    add("python")
    add("python3")
    return candidates


def extract_contract_from_python(
    *,
    project_dir: Path,
    python_bin: str | None,
) -> SdkContract:
    """Extract operations contract from ``agent.py`` using the project interpreter."""
    module_path = project_dir / AGENT_ENTRYPOINT_RELATIVE_PATH
    if not module_path.exists():
        raise environment_error(
            f"{AGENT_ENTRYPOINT_RELATIVE_PATH} not found. Run: ai init",
            code="missing_project_file",
        )
    resolved_candidates = _build_contract_python_candidates(python_bin)
    last_error = ""
    for candidate in resolved_candidates:
        env = os.environ.copy()
        env["PYTHONPATH"] = _build_contract_pythonpath(
            project_dir=project_dir,
            env=env,
        )
        try:
            completed = subprocess.run(
                [candidate, "-m", "aimp_sdk.contract", "--module", str(module_path)],
                check=False,
                capture_output=True,
                text=True,
                env=env,
            )
        except OSError as error:
            last_error = str(error)
            continue
        output = (completed.stdout or completed.stderr or "").strip()
        if completed.returncode != 0:
            last_error = output or f"Contract extraction failed with exit {completed.returncode}"
            continue
        if not output:
            raise usage_error("No contract output from Python", code="contract_extraction_failed")
        try:
            payload = json.loads(output)
            if not isinstance(payload, dict):
                raise ValueError("Contract extraction must return a JSON object")
            _raise_legacy_vector_contract_shape(
                project_dir=project_dir,
                raw_resources=payload.get("resources"),
            )
            normalized_modes: dict[str, Any] = {}
            raw_modes = payload.get("modes") or {}
            if isinstance(raw_modes, dict):
                for mode_name, raw_mode in raw_modes.items():
                    if not isinstance(raw_mode, dict):
                        continue
                    normalized_modes[str(mode_name)] = {
                        "inputs": raw_mode.get("inputs") or [],
                        "parameters": raw_mode.get("parameters") or {},
                        "description": raw_mode.get("description"),
                        "spaces": raw_mode.get("spaces"),
                        "resources": raw_mode.get("resources"),
                    }
            normalized_payload = {
                "schema_version": payload.get("schema_version"),
                "capabilities": payload.get("capabilities") or {},
                "resources": payload.get("resources") or {},
                "modes": normalized_modes,
                "parameters": payload.get("parameters") or {},
                "tuning": payload.get("tuning"),
            }
            return SdkContract.model_validate(normalized_payload)
        except (ValueError, TypeError) as error:
            raise usage_error(
                f"Contract extraction returned invalid JSON: {error}",
                code="contract_extraction_failed",
            ) from error
    if last_error:
        tried = ", ".join(resolved_candidates)
        raise usage_error(
            f"{last_error} (python candidates tried: {tried})",
            code="contract_extraction_failed",
        )
    raise environment_error(
        "Python contract extraction failed",
        code="python_not_found",
        hint="Provide --python or activate the project virtual environment.",
    )


def extract_tuning_schema_from_python(
    *,
    project_dir: Path,
    python_bin: str | None,
) -> dict[str, Any] | None:
    """Extract explicit fine-tune schema from ``tuning.py`` when present."""
    module_path = project_dir / FINE_TUNE_SCHEMA_MODULE_RELATIVE_PATH
    if not module_path.exists():
        return None

    resolved_candidates = _build_contract_python_candidates(python_bin)
    last_error = ""
    for candidate in resolved_candidates:
        env = os.environ.copy()
        env["PYTHONPATH"] = _build_contract_pythonpath(
            project_dir=project_dir,
            env=env,
        )
        try:
            completed = subprocess.run(
                [candidate, "-m", "aimp_sdk.tuning_contract", "--module", str(module_path)],
                check=False,
                capture_output=True,
                text=True,
                env=env,
            )
        except OSError as error:
            last_error = str(error)
            continue
        output = (completed.stdout or completed.stderr or "").strip()
        if completed.returncode != 0:
            last_error = (
                output or f"Tuning schema extraction failed with exit {completed.returncode}"
            )
            continue
        if not output:
            raise usage_error("No tuning schema output from Python", code="tuning_schema_failed")
        try:
            return json.loads(output)
        except (ValueError, TypeError) as error:
            raise usage_error(
                f"Tuning schema extraction returned invalid JSON: {error}",
                code="tuning_schema_failed",
            ) from error
    if last_error:
        tried = ", ".join(resolved_candidates)
        raise usage_error(
            f"{last_error} (python candidates tried: {tried})",
            code="tuning_schema_failed",
        )
    return None


def extract_mode_readiness_from_python(
    *,
    project_dir: Path,
    python_bin: str | None,
    mode_names: list[str] | None = None,
) -> ModeReadinessPayload:
    """Extract SDK-level public mode implementation verification from ``agent.py``."""
    module_path = project_dir / AGENT_ENTRYPOINT_RELATIVE_PATH
    if not module_path.exists():
        raise environment_error(
            f"{AGENT_ENTRYPOINT_RELATIVE_PATH} not found. Run: ai init",
            code="missing_project_file",
        )

    resolved_candidates = _build_contract_python_candidates(python_bin)
    last_error = ""
    for candidate in resolved_candidates:
        env = os.environ.copy()
        env["PYTHONPATH"] = _build_contract_pythonpath(
            project_dir=project_dir,
            env=env,
        )
        try:
            completed = subprocess.run(
                [candidate, "-m", "aimp_sdk.mode_readiness", "--module", str(module_path)],
                check=False,
                capture_output=True,
                text=True,
                env=env,
            )
        except OSError as error:
            last_error = str(error)
            continue
        output = (completed.stdout or completed.stderr or "").strip()
        if completed.returncode != 0:
            last_error = (
                output or f"Mode readiness extraction failed with exit {completed.returncode}"
            )
            continue
        if not output:
            raise usage_error(
                "No mode readiness output from Python",
                code="mode_readiness_failed",
            )
        try:
            payload = json.loads(output)
        except (ValueError, TypeError) as error:
            raise usage_error(
                f"Mode readiness extraction returned invalid JSON: {error}",
                code="mode_readiness_failed",
            ) from error

        modes = mode_names or list(payload.keys())
        normalized_payload: dict[str, dict[str, Any]] = {}
        for mode in modes:
            entry = payload.get(mode) or {}
            implemented = bool(entry.get("implemented"))
            reason = entry.get("reason")
            if not implemented and not reason:
                reason = f"{mode}() is not implemented by this model"
            normalized_payload[mode] = {
                "declared": True,
                "implemented": implemented,
                "reason": reason,
            }
        return ModeReadinessPayload.model_validate(normalized_payload)

    if last_error:
        tried = ", ".join(resolved_candidates)
        raise usage_error(
            f"{last_error} (python candidates tried: {tried})",
            code="mode_readiness_failed",
        )
    raise environment_error(
        "Python mode readiness extraction failed",
        code="python_not_found",
        hint="Provide --python or activate the project virtual environment.",
    )


def build_mode_readiness_payload(
    *,
    modes: Any,
    implementation_status: ModeReadinessPayload,
) -> ModeReadinessPayload:
    """Combine contract-declared modes with SDK method overrides."""
    payload: dict[str, dict[str, Any]] = {}
    for mode_name in modes.names():
        readiness = implementation_status.get(mode_name)
        implemented = bool(readiness.implemented) if readiness is not None else False
        reason = readiness.reason if readiness is not None else None
        if not implemented and not reason:
            reason = f"{mode_name}() is not implemented by this model"
        payload[mode_name] = {
            "declared": True,
            "implemented": implemented,
            "reason": None if implemented else reason,
        }

    return ModeReadinessPayload.model_validate(payload)


def build_publish_payload(
    *,
    slug: str,
    version: str,
    publish_build_job_id: str,
    project_config: ProjectConfig,
    mode_readiness: ModeReadinessPayload,
    parameters: dict[str, Any],
    tuning_contract: dict[str, Any] | None,
    publish_config: Any,
    studio: StudioPublishPayload,
) -> PublishRequest:
    """Build the publish request."""
    return PublishRequest(
        slug=slug,
        version=version,
        publish_build_job_id=publish_build_job_id,
        resources=project_config.resources,
        modes=project_config.modes,
        mode_readiness=mode_readiness,
        parameters=parameters,
        tuning=tuning_contract,
        pricing=publish_config.pricing,
        supported_hardware_tiers=publish_config.hardware.supported_tiers,
        studio=studio,
    )


def _default_upload_client_factory(gateway: PublishGatewayProtocol) -> UploadClientProtocol:
    """Build the default upload client for publish operations."""
    return UploadClient(gateway)


def _build_studio_publish_payload(
    *,
    project_dir: Path,
    publish_config: Any,
    gateway: PublishGatewayProtocol,
) -> StudioPublishPayload:
    """Build the Studio metadata payload for publish."""
    article_path, cover_path = resolve_studio_file_paths(project_dir, publish_config)
    article_source = load_studio_article_source(project_dir, publish_config)
    article_payload = parse_constrained_mdx(article_source)

    replacements: dict[str, str] = {}
    for reference in collect_local_media_references(article_payload, article_path=article_path):
        if not reference.resolved_path.exists() or not reference.resolved_path.is_file():
            raise usage_error(
                f"Studio media file not found: {reference.source}",
                code="studio_media_not_found",
            )
        upload_result = gateway.upload_studio_media(
            file_path=reference.resolved_path,
            media_type=reference.media_type,
        )
        public_url = str(upload_result.get("public_url") or "").strip()
        if not public_url:
            raise usage_error(
                f"Studio media upload missing public_url for {reference.source}",
                code="studio_media_public_url_missing",
            )
        replacements[reference.source] = public_url

    article_payload = replace_media_sources(article_payload, replacements)

    cover_payload: StudioCoverPayload | None = None
    if cover_path is not None:
        upload_result = gateway.upload_studio_media(file_path=cover_path, media_type="image")
        cover_payload = StudioCoverPayload(
            media_ref=str(upload_result.get("media_ref") or "").strip() or None,
            storage_uri=str(upload_result.get("storage_uri") or "").strip() or None,
            public_url=str(upload_result.get("public_url") or "").strip() or None,
        )
    elif getattr(publish_config.studio, "cover_url", None):
        cover_payload = StudioCoverPayload(public_url=publish_config.studio.cover_url)

    return StudioPublishPayload(
        name=publish_config.studio.name,
        tags=list(publish_config.studio.tags),
        visibility=publish_config.studio.visibility,
        article=article_payload,
        cover=cover_payload,
    )


def _load_dockerignore_patterns(build_context: Path) -> list[str]:
    """Load ordered ``.dockerignore`` patterns for the build context."""
    dockerignore_path = build_context / ".dockerignore"
    if not dockerignore_path.exists():
        return []

    patterns: list[str] = []
    for raw_line in dockerignore_path.read_text(encoding="utf-8").splitlines():
        candidate = raw_line.strip()
        if not candidate or candidate.startswith("#"):
            continue
        patterns.append(candidate)
    return patterns


def _dockerignore_matches(relative_path: Path, *, pattern: str, is_dir: bool) -> bool:
    """Return whether one relative path matches a simplified Docker ignore pattern."""
    normalized_path = relative_path.as_posix()
    normalized_pattern = pattern.lstrip("/")
    dir_only = normalized_pattern.endswith("/")
    normalized_pattern = normalized_pattern.rstrip("/")
    if not normalized_pattern:
        return False

    if dir_only:
        path_parts = [part for part in relative_path.parts if part not in {"."}]
        if "/" not in normalized_pattern:
            return any(fnmatch(part, normalized_pattern) for part in path_parts)

        ancestor_paths = ["/".join(path_parts[:index]) for index in range(1, len(path_parts) + 1)]
        if not is_dir and ancestor_paths:
            ancestor_paths = ancestor_paths[:-1]
        if pattern.startswith("/"):
            return any(fnmatch(candidate, normalized_pattern) for candidate in ancestor_paths)
        suffix_candidates: list[str] = []
        for candidate in ancestor_paths:
            parts = candidate.split("/")
            suffix_candidates.extend("/".join(parts[index:]) for index in range(len(parts)))
        return any(fnmatch(candidate, normalized_pattern) for candidate in suffix_candidates)

    if "/" not in normalized_pattern:
        path_parts = [part for part in relative_path.parts if part not in {"."}]
        return any(fnmatch(part, normalized_pattern) for part in path_parts)

    candidates = [normalized_path]
    if not pattern.startswith("/"):
        path_parts = normalized_path.split("/")
        candidates.extend("/".join(path_parts[index:]) for index in range(1, len(path_parts)))
    return any(fnmatch(candidate, normalized_pattern) for candidate in candidates)


def _should_include_in_bundle(
    relative_path: Path,
    *,
    is_dir: bool,
    patterns: list[str],
    forced_includes: set[str],
) -> bool:
    """Apply ordered Docker ignore rules to a context-relative path."""
    normalized_path = relative_path.as_posix()
    for forced_include in forced_includes:
        normalized_forced = forced_include.rstrip("/")
        if normalized_path == normalized_forced:
            return True
        if normalized_forced and normalized_path.startswith(f"{normalized_forced}/"):
            return True

    include = True
    for pattern in patterns:
        negated = pattern.startswith("!")
        candidate = pattern[1:] if negated else pattern
        if _dockerignore_matches(relative_path, pattern=candidate, is_dir=is_dir):
            include = negated
    return include


def create_source_bundle_archive(*, build_context: Path, dockerfile: str | None) -> Path:
    """Create a compressed source bundle for remote publish builds."""
    patterns = _load_dockerignore_patterns(build_context)
    forced_includes = {
        ".dockerignore",
        dockerfile or "Dockerfile",
        "pyproject.toml",
    }
    bundle_fd, bundle_name = tempfile.mkstemp(prefix="aimp-source-bundle-", suffix=".tar.gz")
    os.close(bundle_fd)
    bundle_path = Path(bundle_name)
    with tarfile.open(bundle_path, mode="w:gz") as archive:
        for path in build_context.rglob("*"):
            relative_path = path.relative_to(build_context)
            if not _should_include_in_bundle(
                relative_path,
                is_dir=path.is_dir(),
                patterns=patterns,
                forced_includes=forced_includes,
            ):
                continue
            archive.add(path, arcname=str(relative_path))
    return bundle_path


def _is_terminal_build_status(status_value: str) -> bool:
    """Return whether one publish build status is terminal."""
    return status_value in {"succeeded", "failed", "canceled"}


def wait_for_publish_build_job(
    *,
    gateway: PublishGatewayProtocol,
    job_id: str,
    context: CommandContext,
) -> PublishBuildJob:
    """Watch one remote publish build job until it reaches a terminal state."""
    latest_snapshot: dict[str, Any] = {}

    def build_status_message(payload: dict[str, Any]) -> str:
        """Build the live remote build status line from one execution-like payload."""
        model_slug = str(payload.get("model_slug") or payload.get("slug") or "").strip()
        details = payload.get("details")
        details_payload = details if isinstance(details, dict) else {}
        version = str(payload.get("version") or details_payload.get("version") or "").strip()
        status_value = str(payload.get("status") or "unknown").strip()
        summary = f"Remote build: {status_value}"
        if model_slug:
            summary += f" · {model_slug}"
            if version:
                summary += f":{version}"
        summary += f" · job {job_id[:8]}"
        return summary

    def update_status_from_execution(execution: dict[str, Any], status_handle: Any) -> None:
        """Render one execution snapshot into the live status display."""
        status_handle.update(build_status_message(execution))

    def render_log_items(items: list[dict[str, Any]]) -> None:
        for log_entry in items:
            log_level = log_entry.get("level", "info")
            message = str(log_entry.get("message") or "")
            if log_level == "error":
                console.print(f"[red]✗ {message}[/red]", soft_wrap=True)
            elif log_level == "warning":
                console.print(f"[yellow]⚠ {message}[/yellow]", soft_wrap=True)
            else:
                console.print(f"[dim]  {message}[/dim]", soft_wrap=True)

    with _managed_status("Remote build queued", spinner="line") as status:
        watch_execution_stream(
            gateway=gateway,
            job_id=job_id,
            context=context,
            callbacks=ExecutionStreamCallbacks(
                on_snapshot=lambda execution: (
                    latest_snapshot.clear(),
                    latest_snapshot.update(execution),
                    update_status_from_execution(execution, status),
                ),
                on_status=lambda payload: status.update(
                    build_status_message({**latest_snapshot, "status": payload.get("status")})
                ),
                on_logs=lambda items, _payload: render_log_items(items),
                on_terminal=lambda execution: (
                    latest_snapshot.clear(),
                    latest_snapshot.update(execution),
                    update_status_from_execution(execution, status),
                ),
            ),
        )
    return gateway.get_publish_build_job(job_id)


def _confirm_remote_build_cancel(job_id: str) -> bool:
    """Prompt for remote build cancellation using the interactive TUI."""
    if not sys.stdin.isatty():
        return False
    return confirm_action(
        f"Cancel remote build {job_id[:8]}?",
        console=console,
        show_header=False,
        confirm_label="Cancel Build",
        cancel_label="Keep Running",
        confirm_description="Cancel the remote build job and remove it from history.",
        cancel_description="Stop watching locally; the build continues running remotely.",
        title="Stop Watching",
        subtitle=f"Build job {job_id[:8]} is still running remotely.",
    )


def cancel_publish_build_job(
    *,
    gateway: PublishGatewayProtocol,
    job_id: str,
    poll_interval_seconds: float,
) -> None:
    """Cancel one remote build job and remove it from history."""
    payload = gateway.cancel_publish_build_job(job_id)
    if payload.cancel_state == "requested":
        with _managed_status("Canceling remote build...", spinner="line") as status:
            while True:
                try:
                    job = gateway.get_publish_build_job(job_id)
                except CliError as error:
                    if error.http_status == 404:
                        return
                    raise
                status.update(f"Canceling remote build: {job.status} · job {job.job_id[:8]}")
                if job.status == "canceled":
                    gateway.delete_publish_build_job(job_id)
                    return
                time.sleep(poll_interval_seconds)
    gateway.delete_publish_build_job(job_id)


def run_publish(
    *,
    project_dir: Path,
    gateway: PublishGatewayProtocol,
    docker: DockerBackendProtocol | None = None,
    context: CommandContext,
    python_bin: str | None,
    parallel: int,
    verbose: bool,
    force: bool = False,
    upload_client_factory: UploadClientFactoryProtocol = _default_upload_client_factory,
) -> dict[str, Any]:
    """Run the full publish flow."""
    slug = project_dir.name.replace(" ", "-").lower()
    bundle_path: Path | None = None
    try:
        # ── Phase 1: Extract local contract and configuration ──────────────────
        with _managed_status("Extracting contract…", spinner="line"):
            sdk_contract = extract_contract_from_python(
                project_dir=project_dir, python_bin=python_bin
            )
            model_info = gateway.get_model(slug) or build_default_model_info(slug)
            project_config = load_project_config(project_dir)
            _reject_legacy_runtime_path_sources(project_dir)
            runtime_dependency_specs = _load_runtime_dependency_specs(project_dir)

        sync_result = _sync_sdk_modes_to_config(
            sdk_contract=sdk_contract,
            project_config=project_config,
        )
        if sync_result.has_changes:
            write_project_config(project_dir, project_config)
            project_config = load_project_config(project_dir)
            if sync_result.added_modes:
                console.print(
                    f"[green]Auto-synced modes to contract.toml:[/green] "
                    f"{', '.join(sync_result.added_modes)}"
                )
            if sync_result.updated_resources:
                console.print("[green]Auto-synced runtime resources from Python authoring[/green]")

        with _managed_status("Extracting mode readiness…", spinner="line"):
            sdk_mode_readiness = extract_mode_readiness_from_python(
                project_dir=project_dir,
                python_bin=python_bin,
                mode_names=project_config.modes.names(),
            )
            mode_readiness = build_mode_readiness_payload(
                modes=project_config.modes,
                implementation_status=sdk_mode_readiness,
            )
            publish_config = load_publish_config(project_dir)
            python_package_index = _resolve_python_package_index(
                getattr(publish_config, "python_packages", None)
            )
            tuning_contract: dict[str, Any] | None = None
            if project_config.tuning is not None:
                tuning_contract = project_config.tuning.model_dump(by_alias=True)
            sdk_parameters: dict[str, Any] = sdk_contract.parameters or {}

        # ── Phase 2: Check for active build and decide path ────────────────────
        #
        #   • No existing job  → full upload + new build (Phase 3)
        #   • Active job + --force → cancel it, then proceed to Phase 3
        #   • Active job, no --force → resume watching it directly (skip Phase 3)
        #
        resume_job_id: str | None = None
        existing_job = _find_active_publish_build_job(gateway=gateway, slug=slug)
        if existing_job is not None:
            job_id = str(existing_job.get("job_id") or "").strip()
            job_status = str(existing_job.get("status") or "queued").strip()
            if force:
                with _managed_status(f"Canceling build {job_id[:8]}…", spinner="line"):
                    cancel_publish_build_job(
                        gateway=gateway,
                        job_id=job_id,
                        poll_interval_seconds=1.0,
                    )
            else:
                console.print(
                    f"Active build {job_id[:8]} ({job_status}) found — resuming watch.\n"
                    "Use --force to cancel it and start a new build."
                )
                resume_job_id = job_id

        # ── Phase 3: Fresh upload + create remote build job ────────────────────
        if resume_job_id is None:
            with _managed_progress(
                SpinnerColumn(spinner_name="line", style="info"),
                TextColumn("[progress.description]{task.description}", style="primary"),
                BarColumn(bar_width=None, style="border", complete_style="info"),
                TextColumn("[progress.percentage]{task.percentage:>3.0f}%", style="muted"),
                TimeElapsedColumn(),
                transient=not verbose,
            ) as progress:
                task_id = progress.add_task("Initializing…", total=100)

                progress.update(task_id, description="Verifying published runtime packages")
                _verify_runtime_packages_downloadable(
                    dependency_specs=runtime_dependency_specs,
                    python_bin=python_bin,
                    python_package_index=python_package_index,
                )
                progress.update(task_id, completed=15)

                progress.update(task_id, description="Resolving build context")
                build_context, dockerfile = resolve_docker_build_spec(project_dir)
                progress.update(task_id, completed=25)

                progress.update(task_id, description="Packaging source bundle")
                bundle_path = create_source_bundle_archive(
                    build_context=build_context,
                    dockerfile=dockerfile,
                )
                progress.update(task_id, completed=45)

                progress.update(task_id, completed=50, description="Uploading source bundle")
                upload_client = upload_client_factory(gateway)
                upload_result = upload_client.upload_file(
                    file_path=bundle_path,
                    slug=slug,
                    version=model_info.version,
                    artifact_type="source_bundle",
                    content_type="application/gzip",
                    metadata={
                        "original_name": model_info.name,
                        "bundle_type": "publish_source",
                    },
                    concurrency=parallel,
                    on_progress=None,
                )

                progress.update(task_id, completed=75, description="Creating remote build job")
                try:
                    fresh_build_job = gateway.create_publish_build_job(
                        PublishBuildJobCreateRequest(
                            slug=slug,
                            version=model_info.version,
                            source_artifact_uri=upload_result.storage_uri,
                            source_artifact_id=upload_result.artifact_id,
                            dockerfile_path=dockerfile or "Dockerfile",
                            build_context_path=".",
                            requested_hardware_tiers=list(publish_config.hardware.supported_tiers),
                            python_package_index=python_package_index,
                        )
                    )
                except CliError as error:
                    race_job = _extract_active_publish_build_job_from_error(error)
                    if race_job is None:
                        raise
                    if not context.json_output:
                        render_publish_build_job(console, race_job)
                    if force:
                        race_job_id = str(race_job.get("job_id") or "").strip()
                        progress.stop()
                        cancel_publish_build_job(
                            gateway=gateway,
                            job_id=race_job_id,
                            poll_interval_seconds=1.0,
                        )
                        raise usage_error(
                            f"Build {race_job_id[:8]} canceled. Run `ai publish --force`"
                            " again to start a new build.",
                            code="publish_force_retry",
                            request_id=context.request_id,
                        ) from error
                    _raise_active_publish_build_error(
                        slug=slug,
                        existing_job=race_job,
                        request_id=context.request_id,
                    )
                resume_job_id = fresh_build_job.job_id
                progress.update(task_id, completed=100, description="Remote build job created")

        # ── Phase 4: Watch the remote build ────────────────────────────────────
        assert resume_job_id is not None
        try:
            build_job = wait_for_publish_build_job(
                gateway=gateway,
                job_id=resume_job_id,
                context=context,
            )
        except KeyboardInterrupt as error:
            if _confirm_remote_build_cancel(resume_job_id):
                cancel_publish_build_job(
                    gateway=gateway,
                    job_id=resume_job_id,
                    poll_interval_seconds=1.0,
                )
                raise usage_error(
                    "Remote publish build canceled and removed",
                    code="publish_build_canceled",
                    extra={"job_id": resume_job_id},
                ) from error
            console.print(
                f"\nStopped watching remote publish build. "
                f"Job {resume_job_id[:8]} is still running remotely."
            )
            raise

        if build_job.status != "succeeded":
            raise environment_error(
                build_job.error_message or "Remote publish build failed",
                code=build_job.error_code or "publish_build_failed",
                extra={"job_id": build_job.job_id},
            )

        # ── Phase 5: Finalize publish ──────────────────────────────────────────
        with _managed_status("Preparing Studio metadata", spinner="line"):
            studio_payload = _build_studio_publish_payload(
                project_dir=project_dir,
                publish_config=publish_config,
                gateway=gateway,
            )

        with _managed_status("Finalizing registration", spinner="line"):
            publish_response = gateway.publish(
                build_publish_payload(
                    slug=slug,
                    version=model_info.version,
                    publish_build_job_id=build_job.job_id,
                    project_config=project_config,
                    mode_readiness=mode_readiness,
                    parameters=sdk_parameters,
                    tuning_contract=tuning_contract,
                    publish_config=publish_config,
                    studio=studio_payload,
                )
            )

        return {
            "id": publish_response.id,
            "slug": publish_response.slug,
            "visibility": publish_response.visibility,
            "readiness": publish_response.readiness,
            "url": publish_response.url,
            "publish_build_job_id": build_job.job_id,
            "request_id": context.request_id,
        }
    except LiveError as error:
        raise environment_error(
            "Publish output renderer encountered a live display conflict",
            code="publish_live_display_conflict",
            request_id=context.request_id,
            hint="Retry the publish command or use `--json` for non-interactive automation.",
        ) from error
    except CliError:
        raise
    except RuntimeError as error:
        raise coerce_cli_error(error, request_id=context.request_id) from error
    finally:
        if bundle_path is not None:
            bundle_path.unlink(missing_ok=True)


def publish_model_by_slug(*, gateway: PublishGatewayProtocol, slug: str) -> dict[str, Any]:
    """Publish one existing remote model without rebuilding local artifacts."""
    publish_response = gateway.publish_model_by_slug(slug)
    return {
        "id": publish_response.id,
        "slug": publish_response.slug,
        "visibility": publish_response.visibility,
        "readiness": publish_response.readiness,
        "url": publish_response.url,
    }
