"""Publish-specific service helpers."""

from __future__ import annotations

from typing import Any


def build_publish_success_message(result: dict[str, Any]) -> str:
    """Build the human-readable publish success summary."""
    readiness = result.get("readiness")
    readiness_payload = readiness if isinstance(readiness, dict) else {}
    is_ready = bool(readiness_payload.get("is_ready"))
    blocking_reasons = readiness_payload.get("blocking_reasons")
    reasons = blocking_reasons if isinstance(blocking_reasons, list) else []

    lines = [
        "Deployment successful.",
        f"Slug: {result['slug']}",
        f"Visibility: {result.get('visibility', 'unknown')}",
        f"Ready: {'yes' if is_ready else 'no'}",
        f"URL: {result['url']}",
    ]
    if not is_ready and reasons:
        lines.append("Blocking reasons:")
        lines.extend(f"- {reason}" for reason in reasons)
    return "\n".join(lines)
