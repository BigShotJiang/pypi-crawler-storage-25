"""Local publish metadata builders."""

from __future__ import annotations

from typing import Any

from aimp_cli.clients.studio_article import default_studio_article_mdx, tiptap_to_constrained_mdx
from aimp_cli.domain.constants import DEFAULT_HARDWARE_TIER, DEFAULT_STUDIO_ARTICLE_MDX_FILE
from aimp_cli.domain.publish_config import (
    PublishHardwareConfig,
    PublishMetadataConfig,
    PublishStudioConfig,
)


class RemoteModelPublishSnapshot(PublishMetadataConfig):
    """Subset of remote studio metadata used by ``model pull``."""

    id: str
    slug: str


def build_local_publish_metadata(
    remote_payload: dict[str, Any],
    *,
    article_file: str = DEFAULT_STUDIO_ARTICLE_MDX_FILE,
) -> tuple[PublishMetadataConfig, str]:
    """Build local publish config and constrained article from remote model metadata."""
    article_payload = remote_payload.get("studio", {}).get("article") or remote_payload.get(
        "article"
    )
    article_source = ""
    if isinstance(article_payload, dict):
        article_format = str(article_payload.get("format") or "").strip()
        if article_format == "tiptap-json":
            article_source = tiptap_to_constrained_mdx(article_payload)
        elif article_format == "mdx":
            article_source = str(article_payload.get("content") or "")
    if not article_source.strip():
        article_source = default_studio_article_mdx()

    studio = remote_payload.get("studio") if isinstance(remote_payload.get("studio"), dict) else {}
    supported_hardware_tiers = remote_payload.get("supported_hardware_tiers")
    tiers = (
        [str(item).strip() for item in supported_hardware_tiers if str(item).strip()]
        if isinstance(supported_hardware_tiers, list)
        else []
    )
    if not tiers:
        tiers = [str(remote_payload.get("hardware_tier") or DEFAULT_HARDWARE_TIER).strip()]
    return (
        PublishMetadataConfig(
            schema_version=4,
            studio=PublishStudioConfig(
                name=str(
                    remote_payload.get("name") or remote_payload.get("slug") or "Model"
                ).strip(),
                tags=[str(tag).strip() for tag in (studio.get("tags") or []) if str(tag).strip()],
                visibility=str(remote_payload.get("visibility") or "private").strip() or "private",
                cover_file=studio.get("cover_file"),
                cover_url=studio.get("cover_url"),
                article_mdx_file=article_file,
            ),
            hardware=PublishHardwareConfig(supported_tiers=tiers),
            pricing={
                "developer_margin": float(
                    remote_payload.get("pricing", {}).get("developer_margin", 0) or 0
                )
            },
        ),
        article_source,
    )
