from __future__ import annotations

from typing import Any

from aimp_framework.base import Engine

class ExampleEngine(Engine):
    """Tiny engine wrapper for build-time and runtime hooks."""

    def build(self) -> None:
        return None

    def load(self, context=None, config=None) -> Any:
        _ = context, config
        return {
            "engine": "example",
            "status": "loaded",
        }
