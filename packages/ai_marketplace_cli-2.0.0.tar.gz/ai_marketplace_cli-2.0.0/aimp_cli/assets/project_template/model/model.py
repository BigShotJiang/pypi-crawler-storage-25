from aimp_framework.base import Model
from .engine import ExampleEngine
from .modes import GenerateMode, IndexMode, SearchMode
from .trainer import ExampleTrainer
from .vector import DocsVector


class Example(Model):
    """Reference model shipped with the scaffolded project."""

    modes = [GenerateMode, SearchMode, IndexMode]
    train = [ExampleTrainer]
    engine = ExampleEngine()
    vectors = [DocsVector]
