from aimp_framework.base import FileField, IntegerField, NumberField, Schema, TextField


class GenerateInput(Schema):
    prompt = TextField(
        description="The prompt to generate text from",
        required=True,
    )


class GenerateParameters(Schema):
    max_tokens = IntegerField(
        default=100,
        min=1,
        max=4096,
        step=1,
        label="Max Tokens",
        description="Maximum number of tokens to generate",
    )
    temperature = NumberField(
        default=0.7,
        min=0.0,
        max=2.0,
        step=0.1,
        label="Temperature",
        description="Controls randomness. Lower = more focused.",
    )


class SearchInput(Schema):
    query = TextField(
        description="Search query text",
        required=True,
    )


class SearchParameters(Schema):
    top_k = IntegerField(
        default=5,
        min=1,
        max=50,
        step=1,
        label="Top K",
        description="Number of results to return",
    )


class IndexInput(Schema):
    text = TextField(
        description="Document text to store in the docs vector collection",
        required=True,
    )
    source = TextField(
        description="Stable source identifier used for filtering search results",
        required=True,
    )


class LoraInput(Schema):
    dataset = FileField(
        description="Dataset file for LoRA tuning",
        required=True,
    )


class LoraParameters(Schema):
    epochs = IntegerField(
        default=3,
        min=1,
        max=100,
        step=1,
        label="Epochs",
        description="Number of training epochs",
    )
    learning_rate = NumberField(
        default=0.001,
        min=0.00001,
        max=1.0,
        step=0.00001,
        label="Learning Rate",
        description="Learning rate for LoRA tuning",
    )
