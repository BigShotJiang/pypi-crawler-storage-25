from .model import Example

__all__ = ["Example"]
