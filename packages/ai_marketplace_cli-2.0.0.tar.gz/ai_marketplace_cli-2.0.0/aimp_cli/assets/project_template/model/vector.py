from __future__ import annotations

from typing import Any

from aimp_framework.base import Metric, StringField, TextField, Vector


class DocsVector(Vector):
    alias = "docs"
    name = "Documents"
    description = "Document embeddings used by vector-backed modes."
    dimension = 8
    metric = Metric.COSINE
    default_limit = 5

    text = TextField(required=True)
    source = StringField(required=True, filterable=True)

    @classmethod
    def embed(cls, text: str, *, dimension: int | None = None) -> list[float]:
        size = dimension or cls.dimension or 8
        normalized = str(text or "").strip()
        if not normalized:
            return [0.0] * size

        buckets = [0.0] * size
        for index, character in enumerate(normalized):
            buckets[index % size] += (ord(character) % 97) / 97.0

        scale = max(len(normalized), 1)
        return [round(value / scale, 6) for value in buckets]

    @staticmethod
    def normalize_hits(raw_hits: list[Any]) -> list[dict[str, Any]]:
        normalized: list[dict[str, Any]] = []
        for item in raw_hits:
            payload = getattr(item, "payload", None)
            normalized.append(
                {
                    "id": getattr(item, "id", ""),
                    "score": float(getattr(item, "score", 0.0)),
                    "payload": payload if isinstance(payload, dict) else {},
                }
            )
        return normalized
