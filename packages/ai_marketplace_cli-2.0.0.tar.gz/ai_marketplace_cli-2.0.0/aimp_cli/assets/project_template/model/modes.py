from aimp_framework.base import Mode

from .schemas import (
    GenerateInput,
    GenerateParameters,
    IndexInput,
    SearchInput,
    SearchParameters,
)
from .vector import DocsVector


class GenerateMode(Mode):
    """Text generation mode exposed by the starter model."""

    name = "generate"
    description = "Generate text from a prompt"
    input_schema = GenerateInput
    parameter_schema = GenerateParameters

    def run(self, owner, data, params=None, context=None):
        _ = owner, context
        _ = params.max_tokens if params else 100
        _ = params.temperature if params else 0.7
        text = f"[generated text for: {data.prompt[:50]}...]"
        return {
            "text": text,
            "tokens_used": len(text.split()),
        }


class SearchMode(Mode):
    name = "search"
    description = "Search for relevant information in the knowledge base"
    input_schema = SearchInput
    parameter_schema = SearchParameters
    vectors = [DocsVector]

    def run(self, owner, data, params=None):
        docs = owner.vectors.get(DocsVector)
        embedding = DocsVector.embed(data.query, dimension=docs.dimension)
        hits = docs.objects.search(embedding, limit=params.top_k if params else 5)
        return {
            "results": DocsVector.normalize_hits(hits),
            "count": len(hits),
        }


class IndexMode(Mode):
    name = "index"
    description = "Index document content into the docs vector collection"
    input_schema = IndexInput
    vectors = [DocsVector]

    def run(self, owner, data, params=None, context=None):
        _ = params, context
        docs = owner.vectors.get(DocsVector)
        embedding = DocsVector.embed(data.text, dimension=docs.dimension)
        vector_id = docs.objects.index(
            embedding,
            text=data.text,
            source=data.source,
        )
        return {
            "id": vector_id,
            "status": "indexed",
        }
