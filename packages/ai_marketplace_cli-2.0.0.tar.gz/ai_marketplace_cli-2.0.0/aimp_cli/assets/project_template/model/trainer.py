"""Starter fine-tune hook for the example model."""

from __future__ import annotations

import uuid

from aimp_framework.base import Trainer, TrainingResult

from .schemas import LoraInput, LoraParameters


class ExampleTrainer(Trainer):
    name = "fine_tune"
    description = "Fine-tune the model using LoRA adapters"
    input_schema = LoraInput
    parameter_schema = LoraParameters

    def run(self, owner, data, params=None):
        _ = owner
        _ = data.dataset
        _ = params.epochs if params else 3
        _ = params.learning_rate if params else 0.001
        job_id = f"job-{uuid.uuid4().hex[:8]}"
        return TrainingResult(
            job_id=job_id,
            status="submitted",
        ).model_dump()
