"""Typing protocols for CLI service dependencies."""

from __future__ import annotations

from collections.abc import Callable, Iterator
from contextlib import AbstractContextManager
from pathlib import Path
from typing import Any, Protocol

from aimp_cli.clients.docker import DockerAccessStatus, RegistryAuthStatus
from aimp_cli.domain.models import (
    ArtifactType,
    AuthResponse,
    FineTuneJobListResponse,
    FineTuneJobResponse,
    JobCancelResponse,
    ModelLookupResponse,
    PublishBuildJob,
    PublishBuildJobCreateRequest,
    PublishBuildJobListResponse,
    PublishMetadataResponse,
    PublishRequest,
    PublishResponse,
    StudioModelDetailResponse,
)


class AuthGatewayProtocol(Protocol):
    """Gateway methods used by auth flows."""

    def authenticate(self, api_key: str) -> AuthResponse:
        """Validate an API key."""

    def get_current_user(self) -> AuthResponse | None:
        """Return the current authenticated user."""

    def close(self) -> None:
        """Close underlying resources."""


class PublishMetadataGatewayProtocol(Protocol):
    """Gateway methods used by publish configuration flows."""

    def get_publish_metadata(self) -> PublishMetadataResponse:
        """Return publish metadata for the current user."""


class ModelGatewayProtocol(Protocol):
    """Gateway methods used by model inspection flows."""

    def get_model(self, slug: str) -> ModelLookupResponse | None:
        """Look up a model by slug."""

    def get_studio_model(self, model_id: str) -> StudioModelDetailResponse:
        """Return detailed studio model metadata."""

    def get_studio_model_analytics(self, model_id: str) -> dict[str, Any]:
        """Return analytics for a studio model."""

    def get_model_rates(self, model_id: str, actions: list[str]) -> dict[str, Any]:
        """Return action rates for a studio model."""

    def close(self) -> None:
        """Close underlying resources."""


class JobStreamGatewayProtocol(Protocol):
    """Gateway methods used by unified SSE job watching."""

    def stream_job(self, job_id: str) -> AbstractContextManager[Iterator[str]]:
        """Open one live SSE stream for a single job."""


class PublishGatewayProtocol(JobStreamGatewayProtocol, Protocol):
    """Gateway methods used by the publish pipeline."""

    def get_model(self, slug: str) -> ModelLookupResponse | None:
        """Look up a model by slug."""

    def upload_studio_media(
        self,
        *,
        file_path: Path,
        media_type: str,
    ) -> dict[str, Any]:
        """Upload Studio media and return the trusted completion payload."""

    def publish(self, request: PublishRequest | dict[str, Any]) -> PublishResponse:
        """Publish a model build."""

    def publish_model_by_slug(self, slug: str) -> PublishResponse:
        """Publish one existing remote model by slug."""

    def create_publish_build_job(
        self,
        request: PublishBuildJobCreateRequest,
    ) -> PublishBuildJob:
        """Create a remote publish build job."""

    def get_publish_build_job(self, job_id: str) -> PublishBuildJob:
        """Get one remote publish build job."""

    def list_publish_build_jobs(
        self,
        *,
        model_slug: str | None = None,
        status: str | None = None,
        page: int = 1,
        page_size: int = 20,
    ) -> PublishBuildJobListResponse:
        """List publish build jobs within the authenticated workspace."""

    def cancel_publish_build_job(self, job_id: str) -> JobCancelResponse:
        """Cancel one publish build job."""

    def delete_publish_build_job(self, job_id: str) -> None:
        """Delete one terminal publish build job."""


class JobsGatewayProtocol(Protocol):
    """Gateway methods used by unified job read commands."""

    def list_publish_build_jobs(
        self,
        *,
        model_slug: str | None = None,
        status: str | None = None,
        page: int = 1,
        page_size: int = 20,
    ) -> PublishBuildJobListResponse:
        """List publish build jobs within the authenticated workspace."""

    def get_publish_build_job(self, job_id: str) -> PublishBuildJob:
        """Get one publish build job."""

    def list_fine_tune_jobs(
        self,
        *,
        model_slug: str | None = None,
        status: str | None = None,
        page: int = 1,
        page_size: int = 20,
    ) -> FineTuneJobListResponse:
        """List fine-tune jobs within the authenticated workspace."""

    def get_fine_tune_job(self, *, job_id: str) -> FineTuneJobResponse:
        """Get one fine-tune job."""

    def cancel_publish_build_job(self, job_id: str) -> JobCancelResponse:
        """Cancel one publish build job."""

    def delete_publish_build_job(self, job_id: str) -> None:
        """Delete one terminal publish build job."""

    def cancel_fine_tune_job(self, *, job_id: str) -> JobCancelResponse:
        """Cancel one fine-tune job."""

    def delete_fine_tune_job(self, *, job_id: str) -> None:
        """Delete one terminal fine-tune job."""


class DockerBackendProtocol(Protocol):
    """Docker operations required by the publish flow."""

    def inspect_daemon_access(self) -> DockerAccessStatus:
        """Return Docker daemon diagnostics."""

    def build_image(
        self,
        *,
        context_dir: Path,
        tag: str,
        dockerfile: str | None,
        on_line: Callable[[str], None],
    ) -> None:
        """Build an image."""

    def verify_runtime_sdk(self, image_tag: str) -> None:
        """Validate runtime SDK import within the built image."""

    def tag_image(self, source: str, target: str) -> None:
        """Tag an image."""

    def push_image(self, image_ref: str, on_line: Callable[[str], None]) -> None:
        """Push an image to the registry."""

    def save_image(self, image_tag: str, output_path: Path) -> None:
        """Archive an image to disk."""

    def get_registry_auth_status(self, registry_host: str) -> RegistryAuthStatus:
        """Return registry auth availability."""

    def get_registry_basic_auth_header(self, registry_host: str) -> str | None:
        """Return a basic auth header when available."""


class UploadResultProtocol(Protocol):
    """Upload result attributes consumed by the publish flow."""

    storage_uri: str


class UploadClientProtocol(Protocol):
    """Artifact upload client contract."""

    def upload_file(
        self,
        *,
        file_path: Path,
        slug: str,
        version: str,
        artifact_type: ArtifactType,
        content_type: str,
        metadata: dict[str, Any] | None,
        concurrency: int,
        on_progress: Any | None,
    ) -> UploadResultProtocol:
        """Upload an artifact file."""


UploadClientFactoryProtocol = Callable[[PublishGatewayProtocol], UploadClientProtocol]
