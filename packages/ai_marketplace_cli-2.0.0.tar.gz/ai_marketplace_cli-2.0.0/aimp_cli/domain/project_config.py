"""Project metadata and hidden scaffold configuration persistence."""

from __future__ import annotations

import tomllib
from pathlib import Path

from pydantic import BaseModel, ConfigDict, Field

from aimp_cli.domain.models import (
    CapabilitiesConfig,
    ModeContract,
    ModesConfig,
    ResourceConfig,
    TuningConfig,
)

from .constants import (
    AGENT_CONTRACT_RELATIVE_PATH,
    DEFAULT_CONTRACT_SCHEMA_VERSION,
    PROJECT_CONFIG_FILE_NAME,
    PROJECT_CONFIG_RELATIVE_PATH,
)


class AgentContractMetadata(BaseModel):
    """Public agent metadata written to ``contract.toml``."""

    model_config = ConfigDict(extra="forbid")

    name: str
    version: str = "0.1.0"
    author: str = "username"
    description: str = "Generated with ai init"


class ProjectConfig(BaseModel):
    """Hidden scaffold configuration loaded from ``.aimp/project.toml``."""

    model_config = ConfigDict(extra="forbid")

    schema_version: int = DEFAULT_CONTRACT_SCHEMA_VERSION
    capabilities: CapabilitiesConfig = Field(default_factory=CapabilitiesConfig)
    resources: ResourceConfig = Field(default_factory=ResourceConfig, exclude=True)
    modes: ModesConfig
    tuning: TuningConfig | None = None


def default_project_config() -> ProjectConfig:
    """Return the default hidden project configuration."""
    from aimp_cli.domain.models import InputDefinition
    from aimp_cli.operations.scaffold.tuning import default_tuning_workspace_config

    config = ProjectConfig(
        schema_version=DEFAULT_CONTRACT_SCHEMA_VERSION,
        capabilities=CapabilitiesConfig(vector=False, tuning=True),
        resources=ResourceConfig(vector_db=False),
        modes=ModesConfig(
            {
                "generate": ModeContract(
                    inputs=[InputDefinition(name="prompt", kind="text", required=True)],
                    enabled=True,
                    outputs=["text"],
                ),
            }
        ),
    )
    config.tuning = default_tuning_workspace_config(config)
    return config


def default_agent_contract_metadata(project_name: str) -> AgentContractMetadata:
    """Return default public metadata for a new scaffolded agent."""
    normalized_name = project_name.strip() or "agent"
    return AgentContractMetadata(
        name=normalized_name,
        version="0.1.0",
        author="username",
        description=f"{normalized_name} agent",
    )


def load_project_config(project_dir: Path) -> ProjectConfig:
    """Load and validate ``.aimp/project.toml``."""
    config_path = project_dir / PROJECT_CONFIG_RELATIVE_PATH
    if not config_path.exists():
        legacy_path = project_dir / "aimp.config.toml"
        if legacy_path.exists():
            raise RuntimeError(
                "Root contract file is no longer supported: aimp.config.toml. "
                f"Use {PROJECT_CONFIG_FILE_NAME} instead."
            )
        if (project_dir / AGENT_CONTRACT_RELATIVE_PATH).exists():
            raise RuntimeError(
                f"Project config file not found: {PROJECT_CONFIG_FILE_NAME}. Run: ai init"
            )
        raise RuntimeError(f"Config file not found: {PROJECT_CONFIG_FILE_NAME}. Run: ai init")
    raw = tomllib.loads(config_path.read_text(encoding="utf-8"))
    if "parameters" in raw:
        raise RuntimeError(f"parameters are not allowed in {PROJECT_CONFIG_FILE_NAME}")
    try:
        schema_version = int(raw.get("schema_version", 0))
    except (TypeError, ValueError) as exc:
        raise RuntimeError(
            f"schema_version = {DEFAULT_CONTRACT_SCHEMA_VERSION} is required"
        ) from exc
    if schema_version != DEFAULT_CONTRACT_SCHEMA_VERSION:
        raise RuntimeError(
            f"schema_version = {DEFAULT_CONTRACT_SCHEMA_VERSION} is required. "
            "Run: ai contract migrate"
        )
    return ProjectConfig(
        schema_version=DEFAULT_CONTRACT_SCHEMA_VERSION,
        capabilities=CapabilitiesConfig.model_validate(raw.get("capabilities") or {}),
        resources=ResourceConfig.model_validate(raw.get("resources") or {}),
        modes=ModesConfig.model_validate(raw.get("modes") or raw.get("operations") or {}),
        tuning=(
            TuningConfig.model_validate(raw["tuning"])
            if isinstance(raw.get("tuning"), dict)
            else None
        ),
    )


def resolve_project_mode_names(config: ProjectConfig) -> list[str]:
    """Return enabled public mode names in canonical order."""
    return [name for name, mode in config.modes.items() if mode.enabled]


resolve_project_operation_names = resolve_project_mode_names


def write_project_config(project_dir: Path, config: ProjectConfig) -> Path:
    """Write the hidden scaffold configuration file."""
    from .serialization import serialize_project_config_toml

    config_path = project_dir / PROJECT_CONFIG_RELATIVE_PATH
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(serialize_project_config_toml(config), encoding="utf-8")
    return config_path


def write_agent_contract(project_dir: Path, metadata: AgentContractMetadata) -> Path:
    """Write the public metadata-only agent contract."""
    from .serialization import serialize_agent_contract_toml

    contract_path = project_dir / AGENT_CONTRACT_RELATIVE_PATH
    contract_path.parent.mkdir(parents=True, exist_ok=True)
    contract_path.write_text(serialize_agent_contract_toml(metadata), encoding="utf-8")
    return contract_path
