"""TOML serialization helpers for public agent metadata and local project config."""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any

from aimp_cli.domain.publish_config import PublishMetadataConfig

from .constants import (
    DEFAULT_CONTRACT_SCHEMA_VERSION,
    DEFAULT_PUBLISH_SCHEMA_VERSION,
    DEFAULT_STUDIO_ARTICLE_MDX_FILE,
    DEFAULT_STUDIO_COVER_FILE,
)
from .project_config import (
    AgentContractMetadata,
    ProjectConfig,
    default_agent_contract_metadata,
    default_project_config,
)

def _format_toml_array(values: Sequence[Any]) -> str:
    return "[" + ", ".join(_to_toml_literal(value) or '""' for value in values) + "]"


def _append_toml_table(lines: list[str], table_name: str, values: dict[str, Any]) -> None:
    """Append a TOML table for scalar values."""
    lines.extend(["", f"[{table_name}]"])
    for key, value in values.items():
        literal = _to_toml_literal(value)
        if literal is not None:
            lines.append(f"{key} = {literal}")


def _serialize_input_definition(inp: Any) -> list[str]:
    """Serialize a single InputDefinition to TOML array-of-tables entries."""
    lines: list[str] = []
    lines.append(f'name = "{_escape_toml_string(inp.name)}"')
    lines.append(f'kind = "{inp.kind}"')
    lines.append(f"required = {'true' if inp.required else 'false'}")
    if inp.description:
        lines.append(f'description = "{_escape_toml_string(inp.description)}"')
    if inp.multiple:
        lines.append("multiple = true")
    if inp.label:
        lines.append(f'label = "{_escape_toml_string(inp.label)}"')
    if inp.default is not None:
        default_literal = _to_toml_literal(inp.default)
        if default_literal:
            lines.append(f"default = {default_literal}")
    return lines


def serialize_agent_contract_toml(metadata: AgentContractMetadata) -> str:
    """Serialize the public metadata-only ``contract.toml``."""
    lines = [
        "[agent]",
        f'name = "{_escape_toml_string(metadata.name)}"',
        f'version = "{_escape_toml_string(metadata.version)}"',
        f'author = "{_escape_toml_string(metadata.author)}"',
        f'description = "{_escape_toml_string(metadata.description)}"',
    ]
    return "\n".join(lines) + "\n"


def serialize_project_config_toml(config: ProjectConfig) -> str:
    """Serialize ``.aimp/project.toml`` in stable canonical order."""
    lines = [
        "# Hidden project config managed by the CLI",
        f"schema_version = {DEFAULT_CONTRACT_SCHEMA_VERSION}",
        "",
        "[capabilities]",
    ]
    lines.append(f"vector = {'true' if config.capabilities.vector else 'false'}")
    lines.append(
        f"tuning = {'true' if (config.capabilities.tuning or config.tuning is not None) else 'false'}"
    )
    lines.extend(["", "[resources]"])
    if isinstance(config.resources.vector_db, bool):
        lines.append(f"vector_db = {'true' if config.resources.vector_db else 'false'}")
    else:
        lines.append("")
        lines.append("[resources.vector_db]")
        for collection in config.resources.vector_collections:
            lines.append("")
            lines.append("[[resources.vector_db.collections]]")
            lines.append(f'alias = "{_escape_toml_string(collection.alias)}"')
            lines.append(f'name = "{_escape_toml_string(collection.name)}"')
            lines.append(f'description = "{_escape_toml_string(collection.description)}"')
    if config.resources.timeout:
        lines.append(f'timeout = "{_escape_toml_string(config.resources.timeout)}"')
    for op_name, op_config in config.modes.items():
        lines.append("")
        lines.append(f"[modes.{op_name}]")
        lines.append(f"enabled = {'true' if op_config.enabled else 'false'}")
        # Mode-level keys must appear before [[modes.<name>.inputs]] tables; otherwise TOML
        # attaches trailing keys to the last inputs[] element (invalid for InputDefinition).
        if op_config.outputs:
            lines.append(f"outputs = {_format_toml_array(op_config.outputs)}")
        if op_config.description:
            lines.append(f'description = "{_escape_toml_string(op_config.description)}"')
        if op_config.resources is not None and op_config.resources.vector_aliases:
            lines.extend(
                [
                    "",
                    f"[modes.{op_name}.resources]",
                    f"vector_aliases = {_format_toml_array(op_config.resources.vector_aliases)}",
                ]
            )
        for inp in op_config.inputs:
            lines.append("")
            lines.append("[[modes.{}.inputs]]".format(op_name))
            lines.extend(_serialize_input_definition(inp))
    if config.tuning is not None:
        lines.extend(
            [
                "",
                "[tuning]",
                f"supported = {'true' if config.tuning.supported else 'false'}",
                f'output_kind = "{config.tuning.output_kind}"',
            ]
        )
        _append_toml_table(
            lines,
            "tuning.dataset_requirements",
            config.tuning.dataset_requirements.model_dump(by_alias=True),
        )
        _append_toml_table(lines, "tuning.objective", config.tuning.objective.model_dump())
        _append_toml_table(lines, "tuning.split_policy", config.tuning.split_policy.model_dump())
        _append_toml_table(
            lines,
            "tuning.dataset_spec",
            config.tuning.dataset_spec.model_dump(by_alias=True),
        )
        lines.extend(
            [
                "",
                "[tuning.schema]",
            ]
        )
        for field in config.tuning.input_schema.fields:
            lines.extend(
                [
                    "",
                    "[[tuning.schema.fields]]",
                    f'key = "{field.key}"',
                    f'type = "{field.type}"',
                    f"required = {'true' if field.required else 'false'}",
                    f"multiple = {'true' if field.multiple else 'false'}",
                ]
            )
            if field.description:
                lines.append(f'description = "{field.description}"')
        for name, parameter in config.tuning.parameters.items():
            lines.extend(
                [
                    "",
                    f"[tuning.parameters.{name}]",
                    f'kind = "{parameter.kind}"',
                    f"default = {_format_toml_value(parameter.default)}",
                    f"required = {'true' if parameter.required else 'false'}",
                ]
            )
            if parameter.min is not None:
                lines.append(f"min = {_format_toml_value(parameter.min)}")
            if parameter.max is not None:
                lines.append(f"max = {_format_toml_value(parameter.max)}")
            if parameter.step is not None:
                lines.append(f"step = {_format_toml_value(parameter.step)}")
            if parameter.log:
                lines.append("log = true")
            if parameter.options:
                lines.append(f"options = {_format_toml_array(parameter.options)}")
    return "\n".join(lines) + "\n"


def _escape_toml_string(value: str) -> str:
    return value.replace("\\", "\\\\").replace('"', '\\"')


def _format_toml_value(value: object) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, str):
        return f'"{_escape_toml_string(value)}"'
    return repr(value)


def _to_toml_literal(value: Any) -> str | None:
    if value is None:
        return None
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        return str(value)
    if isinstance(value, str):
        return f'"{_escape_toml_string(value)}"'
    if isinstance(value, list):
        return "[" + ", ".join(filter(None, (_to_toml_literal(item) for item in value))) + "]"
    if isinstance(value, dict):
        items = []
        for key, item in value.items():
            item_literal = _to_toml_literal(item)
            if item_literal is None:
                continue
            items.append(f"{key} = {item_literal}")
        return "{ " + ", ".join(items) + " }"
    raise RuntimeError(f"Unsupported TOML literal value: {value!r}")


def publish_config_toml_template() -> str:
    """Return default hidden publish config text."""
    return (
        "# Hidden publish state managed by the CLI\n"
        f"schema_version = {DEFAULT_PUBLISH_SCHEMA_VERSION}\n\n"
        "[studio]\n"
        'name = "Example Model"\n'
        'tags = ["example", "starter"]\n'
        'visibility = "private"\n'
        f'cover_file = "{DEFAULT_STUDIO_COVER_FILE}"\n'
        f'article_mdx_file = "{DEFAULT_STUDIO_ARTICLE_MDX_FILE}"\n\n'
        "[hardware]\n"
        'supported_tiers = ["cpu-basic"]\n'
        "\n"
        "[pricing]\n"
        "developer_margin = 0\n"
    )


def agent_contract_toml_template(project_name: str = "agent") -> str:
    """Return default scaffolded ``contract.toml`` text."""
    return serialize_agent_contract_toml(default_agent_contract_metadata(project_name))


def project_config_toml_template() -> str:
    """Return default scaffolded ``.aimp/project.toml`` text."""
    return serialize_project_config_toml(default_project_config())


def serialize_publish_config_toml(config: PublishMetadataConfig) -> str:
    """Serialize hidden publish config in stable canonical order."""
    lines = [
        "# Hidden publish state managed by the CLI",
        f"schema_version = {DEFAULT_PUBLISH_SCHEMA_VERSION}",
        "",
        "[studio]",
        f'name = "{_escape_toml_string(config.studio.name)}"',
        f"tags = {_format_toml_array(config.studio.tags)}",
        f'visibility = "{config.studio.visibility}"',
    ]
    if config.studio.cover_file:
        lines.append(f'cover_file = "{_escape_toml_string(config.studio.cover_file)}"')
    if config.studio.cover_url:
        lines.append(f'cover_url = "{_escape_toml_string(config.studio.cover_url)}"')
    lines.append(f'article_mdx_file = "{_escape_toml_string(config.studio.article_mdx_file)}"')
    lines.extend(
        [
            "",
            "[hardware]",
            f"supported_tiers = {_format_toml_array(config.hardware.supported_tiers)}",
            "",
            "[pricing]",
        ]
    )
    developer_margin = config.pricing.get("developer_margin", 0)
    lines.append(f"developer_margin = {developer_margin}")
    if config.python_packages is not None:
        lines.extend(
            [
                "",
                "[python_packages]",
                f'extra_index_url = "{_escape_toml_string(config.python_packages.extra_index_url)}"',
            ]
        )
        if config.python_packages.username is not None:
            lines.append(f'username = "{_escape_toml_string(config.python_packages.username)}"')
        if config.python_packages.password is not None:
            lines.append(f'password = "{_escape_toml_string(config.python_packages.password)}"')
    return "\n".join(lines) + "\n"
