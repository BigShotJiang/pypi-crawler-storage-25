"""Interactive launcher orchestration helpers."""

from __future__ import annotations

import io
import json
import shutil
from collections.abc import Callable, Iterator
from contextlib import contextmanager
from typing import Any, Literal

import typer
from rich.console import Console

from aimp_cli.core.config import ZINC_THEME
from aimp_cli.core.launcher import LauncherActionResult
from aimp_cli.utils.interactive import LauncherCallbacks, LauncherJobItem


@contextmanager
def interactive_console_capture(console: Console) -> Iterator[Console]:
    """Temporarily route CLI output into a recording console for the launcher."""
    import aimp_cli.core.config as config_module
    import aimp_cli.operations.publish.core as publish_module

    original_config_console = config_module.console
    original_publish_console = publish_module.console
    recording_console = Console(
        theme=ZINC_THEME,
        record=True,
        force_terminal=False,
        file=io.StringIO(),
        width=max(shutil.get_terminal_size((100, 30)).columns - 5, 80),
    )
    config_module.console = recording_console
    publish_module.console = recording_console
    try:
        yield recording_console
    finally:
        config_module.console = original_config_console
        publish_module.console = original_publish_console


def export_interactive_output(
    recording_console: Console | None,
    *,
    fallback_message: str,
) -> str:
    """Convert recorded Rich output into plain text for the detail screen."""
    if recording_console is None:
        return fallback_message
    captured = recording_console.export_text(clear=False).strip()
    return captured or fallback_message


def run_interactive_action(
    *,
    capture_console: Callable[[], Iterator[Console]],
    title: str,
    subtitle: str | None,
    status: Literal["info", "success", "error"],
    fallback_success_message: str,
    callback: Callable[[], None],
) -> LauncherActionResult | None:
    """Execute one existing CLI command and capture its human-readable output."""
    recording_console: Console | None = None
    try:
        with capture_console() as recording_console:
            callback()
    except typer.Exit as exit_error:
        if exit_error.exit_code == 0:
            return None
        return LauncherActionResult(
            title=title,
            subtitle=subtitle,
            content=export_interactive_output(
                recording_console,
                fallback_message=f"Command failed with exit code {exit_error.exit_code}.",
            ),
            status="error",
        )
    except Exception as error:
        return LauncherActionResult(
            title=title,
            subtitle=subtitle,
            content=export_interactive_output(
                recording_console,
                fallback_message=f"Unexpected error: {error}",
            ),
            status="error",
        )
    return LauncherActionResult(
        title=title,
        subtitle=subtitle,
        content=export_interactive_output(
            recording_console,
            fallback_message=fallback_success_message,
        ),
        status=status,
    )


def _format_json_error(payload: dict[str, Any]) -> str:
    """Convert one JSON error envelope into plain text for the detail screen."""
    error = payload.get("error")
    if not isinstance(error, dict):
        return "Command failed."

    lines = [str(error.get("message") or "Command failed.")]
    hint = error.get("hint")
    if isinstance(hint, str) and hint.strip():
        lines.append(f"Hint: {hint.strip()}")
    code = error.get("code")
    if isinstance(code, str) and code.strip():
        lines.append(f"Code: {code.strip()}")
    return "\n".join(lines)


def _parse_interactive_json_output(captured_text: str) -> dict[str, Any] | None:
    """Parse JSON output emitted by CLI commands running in interactive mode."""
    text = captured_text.strip()
    if not text:
        return None
    try:
        payload = json.loads(text)
    except json.JSONDecodeError:
        return None
    return payload if isinstance(payload, dict) else None


def run_interactive_json_action(
    *,
    capture_console: Callable[[], Iterator[Console]],
    title: str,
    subtitle: str | None,
    callback: Callable[[], None],
) -> dict[str, Any] | LauncherActionResult | None:
    """Execute one JSON-emitting CLI command and return structured data."""
    recording_console: Console | None = None
    exit_code = 0
    try:
        with capture_console() as recording_console:
            callback()
    except typer.Exit as exit_error:
        exit_code = int(exit_error.exit_code)
    except Exception as error:
        return LauncherActionResult(
            title=title,
            subtitle=subtitle,
            content=export_interactive_output(
                recording_console,
                fallback_message=f"Unexpected error: {error}",
            ),
            status="error",
        )

    captured_text = export_interactive_output(recording_console, fallback_message="")
    payload = _parse_interactive_json_output(captured_text)
    if payload is None:
        if exit_code == 0:
            return LauncherActionResult(
                title=title,
                subtitle=subtitle,
                content="Structured interactive output was not available.",
                status="error",
            )
        return LauncherActionResult(
            title=title,
            subtitle=subtitle,
            content=captured_text or f"Command failed with exit code {exit_code}.",
            status="error",
        )

    if payload.get("ok") is True:
        data = payload.get("data")
        return data if isinstance(data, dict) else {}

    return LauncherActionResult(
        title=title,
        subtitle=subtitle,
        content=_format_json_error(payload),
        status="error",
    )


def launch_interactive_launcher(
    *,
    console: Console,
    config_store: object,
    run_interactive_launcher_flow: Callable[..., None],
    capture_console: Callable[[], Iterator[Console]],
    run_interactive_action: Callable[..., LauncherActionResult | None],
    init_project: Callable[[str], None],
    configure_project: Callable[[], None],
    validate_contract: Callable[[], None],
    show_contract: Callable[[], None],
    configure_publish: Callable[[], None],
    publish_project: Callable[[], None],
    create_fine_tune_job: Callable[[str, str], None],
    list_jobs: Callable[[str], None],
    get_job_detail: Callable[[str, str], None],
    cancel_job: Callable[[str, str], None],
    delete_job: Callable[[str, str], None],
    login: Callable[[str | None, str | None], None],
    auth: Callable[[], None],
    logout: Callable[[], None],
    inspect_model: Callable[[str], None],
    pull_model: Callable[[str], None],
    list_active_build: Callable[[str], None] | None = None,
    cancel_build: Callable[[str], None] | None = None,
) -> None:
    """Launch the interactive human-oriented CLI workflow."""
    callbacks = LauncherCallbacks(
        init_project=lambda name: run_interactive_action(
            title="Create Project",
            subtitle="Scaffold a new model project in the current workspace.",
            status="success",
            fallback_success_message=f"Created project '{name}'.",
            callback=lambda: init_project(name),
        ),
        configure_project=lambda: run_interactive_action(
            title="Configure Project",
            subtitle="Update local capabilities and synchronize scaffold files.",
            status="success",
            fallback_success_message="Project configuration updated.",
            callback=configure_project,
        ),
        validate_contract=lambda: run_interactive_action(
            title="Validate Contract",
            subtitle="Validate the local hidden contract file.",
            status="success",
            fallback_success_message="Contract validation completed.",
            callback=validate_contract,
        ),
        show_contract=lambda: run_interactive_action(
            title="Show Contract",
            subtitle="Inspect the current local hidden contract.",
            status="info",
            fallback_success_message="Displayed the current contract.",
            callback=show_contract,
        ),
        configure_publish=lambda: run_interactive_action(
            title="Configure Publish",
            subtitle="Edit local publish configuration without publishing.",
            status="success",
            fallback_success_message="Publish configuration updated.",
            callback=configure_publish,
        ),
        publish_project=lambda: run_interactive_action(
            title="Publish Project",
            subtitle="Build and push the current local project.",
            status="success",
            fallback_success_message="Publish completed.",
            callback=publish_project,
        ),
        create_fine_tune_job=lambda model_slug, dataset_path: run_interactive_action(
            title="Create Fine-tune Job",
            subtitle="Upload a bundle or workspace and create a fine-tune job.",
            status="success",
            fallback_success_message=f"Fine-tune job requested for '{model_slug}'.",
            callback=lambda: create_fine_tune_job(model_slug, dataset_path),
        ),
        list_jobs=lambda job_type: _coerce_launcher_jobs(
            run_interactive_json_action(
                capture_console=capture_console,
                title="Browse Jobs",
                subtitle=f"Load {job_type} jobs for the current workspace.",
                callback=lambda: list_jobs(job_type),
            )
        ),
        get_job_detail=lambda job_type, job_id: run_interactive_action(
            title="Job Details",
            subtitle=f"Inspect one {job_type} job.",
            status="info",
            fallback_success_message=f"Loaded {job_type} job '{job_id}'.",
            callback=lambda: get_job_detail(job_type, job_id),
        ),
        cancel_job=lambda job_type, job_id: run_interactive_action(
            title="Cancel Job",
            subtitle=f"Cancel and remove one {job_type} job.",
            status="success",
            fallback_success_message=f"Canceled and removed {job_type} job '{job_id}'.",
            callback=lambda: cancel_job(job_type, job_id),
        ),
        delete_job=lambda job_type, job_id: run_interactive_action(
            title="Delete Job",
            subtitle=f"Delete one terminal {job_type} job.",
            status="success",
            fallback_success_message=f"Deleted {job_type} job '{job_id}'.",
            callback=lambda: delete_job(job_type, job_id),
        ),
        login=lambda gateway, api_key: run_interactive_action(
            title="Login",
            subtitle="Authenticate this machine with the platform.",
            status="success",
            fallback_success_message="Authenticated successfully.",
            callback=lambda: login(gateway, api_key),
        ),
        auth=lambda: run_interactive_action(
            title="Session Status",
            subtitle="Show detailed authentication and session info.",
            status="info",
            fallback_success_message="Loaded session details.",
            callback=auth,
        ),
        logout=lambda: run_interactive_action(
            title="Logout",
            subtitle="Remove stored credentials from this machine.",
            status="success",
            fallback_success_message="Local credentials cleared.",
            callback=logout,
        ),
        inspect_model=lambda slug: run_interactive_action(
            title="Inspect Model",
            subtitle="Fetch remote model metadata, pricing, and rates.",
            status="info",
            fallback_success_message=f"Loaded model '{slug}'.",
            callback=lambda: inspect_model(slug),
        ),
        pull_model=lambda slug: run_interactive_action(
            title="Pull Metadata",
            subtitle="Sync remote model metadata into local project files.",
            status="success",
            fallback_success_message=f"Pulled metadata for '{slug}'.",
            callback=lambda: pull_model(slug),
        ),
        list_active_build=list_active_build if list_active_build is not None else lambda slug: None,
        cancel_build=lambda job_id: run_interactive_action(
            title="Cancel Build",
            subtitle="Cancel the active publish build job.",
            status="success",
            fallback_success_message=f"Build {job_id[:8]} canceled.",
            callback=lambda: cancel_build(job_id),
        )
        if cancel_build is not None
        else lambda job_id: None,
    )
    run_interactive_launcher_flow(
        console=console,
        config_store=config_store,
        callbacks=callbacks,
    )


def _coerce_launcher_jobs(
    result: dict[str, Any] | LauncherActionResult | None,
) -> list[LauncherJobItem] | LauncherActionResult | None:
    """Normalize JSON job payloads into launcher rows."""
    if result is None or isinstance(result, LauncherActionResult):
        return result

    rows = result.get("results")
    if not isinstance(rows, list):
        return []

    items: list[LauncherJobItem] = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        job_id = str(row.get("job_id") or "").strip()
        job_type = str(row.get("job_type") or "").strip()
        model_slug = str(row.get("model_slug") or "").strip()
        status = str(row.get("status") or "").strip()
        if not job_id or not job_type or not model_slug or not status:
            continue
        created_at = row.get("created_at")
        items.append(
            LauncherJobItem(
                job_id=job_id,
                job_type=job_type,
                model_slug=model_slug,
                status=status,
                created_at=str(created_at) if created_at else None,
            )
        )
    return items
