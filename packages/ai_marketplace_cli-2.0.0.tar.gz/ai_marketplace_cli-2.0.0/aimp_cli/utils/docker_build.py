"""Docker build-context discovery helpers."""

from __future__ import annotations

import re
from pathlib import Path


def extract_docker_context_sources(content: str) -> list[str]:
    """Extract relative COPY/ADD sources from a Dockerfile."""
    sources: list[str] = []
    for raw_line in content.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        match = re.match(r"^(COPY|ADD)\s+(.+)$", line, flags=re.IGNORECASE)
        if match is None:
            continue
        operands = match.group(2).strip()
        if operands.startswith("--"):
            continue
        parts = [part for part in re.split(r"\s+", operands) if part]
        if len(parts) < 2:
            continue
        for source in parts[:-1]:
            cleaned = source.strip()
            if cleaned and cleaned not in {".", "./"}:
                sources.append(cleaned)
    return sources


def resolve_docker_build_spec(project_dir: Path) -> tuple[Path, str | None]:
    """Resolve Docker build context root and optional Dockerfile path."""
    dockerfile_path = project_dir / "Dockerfile"
    if not dockerfile_path.exists():
        raise RuntimeError("Dockerfile not found")
    sources = extract_docker_context_sources(dockerfile_path.read_text(encoding="utf-8"))
    context_root = project_dir
    for source in sources:
        relative_parts = [part for part in Path(source).parts if part not in {"."}]
        depth = 0
        while depth < len(relative_parts):
            candidate_root = (
                project_dir.parents[depth] if depth < len(project_dir.parents) else None
            )
            if candidate_root is None:
                break
            if (candidate_root / source).exists():
                context_root = candidate_root
                break
            depth += 1
    if context_root == project_dir:
        return context_root, None
    return context_root, str(dockerfile_path.relative_to(context_root))
