"""Contract and project configuration command handlers."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import typer
from rich.panel import Panel
from rich.pretty import Pretty

from aimp_cli.core.launcher import (
    LauncherOption,
    LauncherSection,
    select_multi_menu,
    select_multi_menu_fallback,
)
from aimp_cli.domain.models import (
    CapabilitiesConfig,
    InputDefinition,
    MEDIA_TYPE_ORDER,
    ModeContract,
    ModeResourcesConfig,
    ModesConfig,
    ResourceConfig,
)
from aimp_cli.domain.constants import (
    AGENT_ENTRYPOINT_RELATIVE_PATH,
    PROJECT_CONFIG_FILE_NAME,
    PROJECT_CONFIG_RELATIVE_PATH,
)
from aimp_cli.domain.project_config import (
    ProjectConfig,
    default_project_config,
    load_project_config,
    resolve_project_operation_names,
    write_project_config,
)
from aimp_cli.operations.scaffold.tuning import default_tuning_workspace_config

from .common import CommandRuntime, exit_with_error

_MEDIA_TYPE_DESCRIPTIONS: dict[str, str] = {
    "text": "Natural-language prompts, responses, and plain text payloads.",
    "image": "Raster images such as PNG, JPG, or WebP inputs and outputs.",
    "audio": "Audio clips or generated audio responses.",
    "video": "Video files or generated video outputs.",
    "file": "Generic binary files or documents that do not fit a narrower modality.",
    "json": "Structured JSON payloads for advanced machine-to-machine contracts.",
}


def _noop() -> None:
    """Shared no-op handler for passive launcher options."""


def parse_csv_values(raw: str | None) -> list[str] | None:
    """Parse a comma-separated CLI flag into normalized string items."""
    if raw is None:
        return None
    values = [item.strip().lower() for item in raw.split(",") if item.strip()]
    if not values:
        return []
    deduplicated: list[str] = []
    for value in values:
        if value not in deduplicated:
            deduplicated.append(value)
    return deduplicated


def build_multi_select_section(
    *,
    title: str,
    values: list[str],
    descriptions: dict[str, str],
) -> list[LauncherSection]:
    """Build a single-section multi-select menu from canonical option values."""
    return [
        LauncherSection(
            title=title,
            options=[
                LauncherOption(
                    key=value,
                    label=value.capitalize(),
                    description=descriptions[value],
                    handler=_noop,
                )
                for value in values
            ],
        )
    ]


def prompt_multi_select_values(
    *,
    runtime: CommandRuntime,
    title: str,
    subtitle: str,
    values: list[str],
    descriptions: dict[str, str],
    preselected: list[str],
) -> list[str]:
    """Prompt for multi-select values using the launcher TUI or plain fallback."""
    sections = build_multi_select_section(
        title=title,
        values=values,
        descriptions=descriptions,
    )
    try:
        selected = select_multi_menu(
            sections,
            preselected_keys=preselected,
            show_header=False,
            title=title,
            subtitle=subtitle,
        )
    except Exception:
        selected = select_multi_menu_fallback(
            sections,
            console=runtime.console,
            preselected_keys=preselected,
            show_header=False,
            title=title,
            subtitle=subtitle,
        )
    if selected is None:
        raise typer.Exit(code=0)
    return selected


def normalize_modalities(
    values: list[str],
    *,
    field_name: str,
) -> list[str]:
    """Normalize modality arrays in canonical order."""
    normalized: list[str] = []
    if not values:
        raise ValueError(f"{field_name} must be a non-empty array")
    for value in values:
        item = str(value).strip().lower()
        if item not in MEDIA_TYPE_ORDER:
            raise ValueError(f"{field_name} contains unsupported modality: {item}")
        if item not in normalized:
            normalized.append(item)
    return [item for item in MEDIA_TYPE_ORDER if item in normalized]


def normalize_inputs_to_definitions(
    inputs: list[InputDefinition] | list[str],
    *,
    field_name: str,
) -> list[InputDefinition]:
    """Normalize inputs to InputDefinition objects.

    Accepts either:
    - list[InputDefinition] (from existing config) - returned as-is
    - list[str] (from CLI flags) - converted to InputDefinition with name=kind=modality
    """
    if not inputs:
        raise ValueError(f"{field_name} must be a non-empty array")

    normalized: list[InputDefinition] = []
    seen_names: set[str] = set()

    for inp in inputs:
        if isinstance(inp, InputDefinition):
            if inp.name in seen_names:
                raise ValueError(f"{field_name} has duplicate input name: {inp.name}")
            seen_names.add(inp.name)
            if inp.kind not in MEDIA_TYPE_ORDER:
                raise ValueError(f"{field_name} contains unsupported modality: {inp.kind}")
            normalized.append(inp)
        else:
            kind = str(inp).strip().lower()
            if kind not in MEDIA_TYPE_ORDER:
                raise ValueError(f"{field_name} contains unsupported modality: {kind}")
            if kind in seen_names:
                raise ValueError(f"{field_name} has duplicate input name: {kind}")
            seen_names.add(kind)
            normalized.append(InputDefinition(name=kind, kind=kind, required=True))

    return normalized


def normalize_cli_operations(operations: list[str]) -> list[str]:
    """Normalize CLI operation flags to canonical public mode names."""
    from aimp_cli.domain.models import FORBIDDEN_PLATFORM_MODES

    normalized: list[str] = []
    for operation in operations:
        item = str(operation).strip().lower()
        if not item:
            continue
        if item in FORBIDDEN_PLATFORM_MODES:
            raise ValueError(f"Reserved mode: {item}")
        if item not in normalized:
            normalized.append(item)
    if not normalized:
        raise ValueError("CLI contracts must declare at least one public mode")
    return normalized


def normalize_mode_name(value: str, *, field_name: str) -> str:
    """Normalize one CLI mode name."""
    from aimp_cli.domain.models import FORBIDDEN_PLATFORM_MODES

    mode_name = str(value).strip().lower()
    if not mode_name:
        raise ValueError(f"{field_name} must include a non-empty mode name")
    if mode_name in FORBIDDEN_PLATFORM_MODES:
        raise ValueError(f"Reserved mode: {mode_name}")
    return mode_name


def parse_mode_modality_flags(
    values: list[str] | None,
    *,
    field_name: str,
) -> dict[str, list[str]]:
    """Parse repeated ``<mode>=<csv>`` CLI flags into normalized mode modality maps."""
    if not values:
        return {}

    parsed: dict[str, list[str]] = {}
    for raw_value in values:
        candidate = str(raw_value).strip()
        if "=" not in candidate:
            raise ValueError(f"{field_name} entries must use <mode>=<csv>")
        raw_mode_name, raw_modalities = candidate.split("=", 1)
        mode_name = normalize_mode_name(raw_mode_name, field_name=field_name)
        modalities = parse_csv_values(raw_modalities)
        if not modalities:
            raise ValueError(f"{field_name} for mode '{mode_name}' must not be empty")
        if mode_name in parsed:
            raise ValueError(f"Duplicate {field_name} entry for mode '{mode_name}'")
        parsed[mode_name] = normalize_modalities(
            modalities,
            field_name=f"modes.{mode_name}.{field_name.removeprefix('--mode-')}",
        )
    return parsed


def prompt_public_operations(*, runtime: CommandRuntime, default: list[str]) -> list[str]:
    """Prompt for independent public modes."""
    runtime.require_tty()
    default_value = ",".join(default)
    raw_value = runtime.prompt_text(
        "Enter one or more public modes as a comma-separated list.",
        console=runtime.console,
        default=default_value or "generate",
        show_header=False,
        title="Public Modes",
        subtitle=(
            "Use any mode names you need. Public mode names no longer imply runtime resources."
        ),
    )
    if raw_value is None:
        raise typer.Exit(code=0)
    return normalize_cli_operations(parse_csv_values(raw_value) or [])


def prompt_vector_db_support(*, runtime: CommandRuntime, default: bool) -> bool:
    """Prompt for Vector DB support using semantic select labels."""
    runtime.require_tty()
    confirmed = runtime.confirm_action(
        "Does this model support Vector DB?",
        console=runtime.console,
        default=default,
        confirm_label="Support Vector DB",
        cancel_label="No Vector DB",
        confirm_description="Expose trusted vector resource capability to model code when allowed.",
        cancel_description="Keep this model without vector resource capability.",
        show_header=False,
        title="Vector DB Support",
        subtitle=(
            "Choose whether this model exposes vector resource capability."
        ),
    )
    return bool(confirmed)


def prompt_fine_tune_support(*, runtime: CommandRuntime, default: bool) -> bool:
    """Prompt for fine-tune support as a project capability."""
    runtime.require_tty()
    confirmed = runtime.confirm_action(
        "Does this project support fine-tune?",
        console=runtime.console,
        default=default,
        confirm_label="Enable Fine-Tune",
        cancel_label="Disable Fine-Tune",
        confirm_description=(
            "Expose a fine-tune contract for the unified project."
        ),
        cancel_description="Keep this project without a fine-tune capability.",
        show_header=False,
        title="Fine-Tune Support",
        subtitle="Choose whether this project exposes a fine-tune contract to customers.",
    )
    return bool(confirmed)


def prompt_contract_config(
    *,
    existing: ProjectConfig | None = None,
    prompt_public_operations_fn: Any,
    prompt_multi_select_values_fn: Any,
    prompt_vector_db_support_fn: Any,
    prompt_fine_tune_support_fn: Any,
) -> ProjectConfig:
    """Interactively prompt for hidden contract settings.

    The init flow asks only about *mode names* and fine-tune support.
    Per-mode input/output modalities default to ``["text"]`` and can be
    customised later via ``ai contract edit``.
    """
    current = existing or default_project_config()
    selected_operations = prompt_public_operations_fn(default=current.modes.names())
    vector_db_enabled = prompt_vector_db_support_fn(
        default=current.resources.vector_db_enabled
    )

    operations_dict: dict[str, ModeContract] = {}
    for op_name in selected_operations:
        existing_op = current.modes.get(op_name)
        if op_name == "generate":
            operations_dict[op_name] = ModeContract(
                inputs=(
                    list(existing_op.inputs)
                    if existing_op is not None
                    else [InputDefinition(name="text", kind="text", required=True)]
                ),
                outputs=list(existing_op.outputs) if existing_op is not None else ["text"],
            )
        else:
            operations_dict[op_name] = ModeContract(
                inputs=(
                    list(existing_op.inputs)
                    if existing_op is not None
                    else [InputDefinition(name="text", kind="text", required=True)]
                ),
            )

    resources = ResourceConfig(vector_db=vector_db_enabled)
    base_config = ProjectConfig(
        schema_version=current.schema_version,
        capabilities=CapabilitiesConfig(
            vector=vector_db_enabled,
            tuning=current.tuning is not None,
        ),
        resources=resources,
        modes=ModesConfig(operations_dict),
    )
    fine_tune_enabled = prompt_fine_tune_support_fn(default=current.tuning is not None)
    return ProjectConfig(
        schema_version=base_config.schema_version,
        capabilities=CapabilitiesConfig(
            vector=base_config.resources.vector_db_enabled,
            tuning=fine_tune_enabled,
        ),
        resources=base_config.resources,
        modes=base_config.modes,
        tuning=(
            current.tuning
            if current.tuning is not None and fine_tune_enabled
            else (default_tuning_workspace_config(base_config) if fine_tune_enabled else None)
        ),
    )


def build_contract_from_flags(
    *,
    existing: ProjectConfig | None,
    modes_flag: str | None,
    mode_inputs_flags: list[str] | None,
    mode_outputs_flags: list[str] | None,
    vector_db_flag: bool | None,
    fine_tune_flag: bool | None,
) -> ProjectConfig:
    """Build a hidden contract from CLI flags, preserving omitted values."""
    base = existing or default_project_config()
    parsed_operations = parse_csv_values(modes_flag)
    if parsed_operations is not None:
        selected_operations = normalize_cli_operations(parsed_operations)
    else:
        selected_operations = list(base.modes.names())

    parsed_mode_inputs = parse_mode_modality_flags(
        mode_inputs_flags,
        field_name="--mode-inputs",
    )
    parsed_mode_outputs = parse_mode_modality_flags(
        mode_outputs_flags,
        field_name="--mode-outputs",
    )

    selected_mode_names = set(selected_operations)
    unexpected_mode_flags = sorted(
        (set(parsed_mode_inputs) | set(parsed_mode_outputs)) - selected_mode_names
    )
    if unexpected_mode_flags:
        raise ValueError(
            "mode input/output flags require enabled modes: " + ", ".join(unexpected_mode_flags)
        )

    resolved_vector_db = (
        bool(vector_db_flag)
        if vector_db_flag is not None
        else base.resources.vector_db_enabled
    )
    ops_dict: dict[str, ModeContract] = {}
    for mode_name in selected_operations:
        existing_mode = base.modes.get(mode_name)
        inputs = parsed_mode_inputs.get(
            mode_name,
            list(existing_mode.inputs) if existing_mode is not None else ["text"],
        )
        outputs = parsed_mode_outputs.get(mode_name)
        if outputs is None:
            if existing_mode is not None and existing_mode.outputs is not None:
                outputs = list(existing_mode.outputs)
            elif mode_name == "generate":
                outputs = ["text"]

        ops_dict[mode_name] = ModeContract(
            inputs=normalize_inputs_to_definitions(inputs, field_name=f"modes.{mode_name}.inputs"),
            outputs=(
                normalize_modalities(outputs, field_name=f"modes.{mode_name}.outputs")
                if outputs is not None
                else None
            ),
            description=existing_mode.description if existing_mode is not None else "",
            resources=existing_mode.resources.model_copy(deep=True) if existing_mode and existing_mode.resources else None,
        )
    next_config = ProjectConfig(
        schema_version=base.schema_version,
        capabilities=CapabilitiesConfig(
            vector=resolved_vector_db,
            tuning=base.tuning is not None,
        ),
        resources=ResourceConfig(vector_db=resolved_vector_db),
        modes=ModesConfig(ops_dict),
        tuning=base.tuning,
    )
    tuning_enabled = base.tuning is not None if fine_tune_flag is None else bool(fine_tune_flag)
    return ProjectConfig(
        schema_version=next_config.schema_version,
        capabilities=CapabilitiesConfig(
            vector=next_config.resources.vector_db_enabled,
            tuning=tuning_enabled,
        ),
        resources=next_config.resources,
        modes=next_config.modes,
        tuning=(
            base.tuning
            if tuning_enabled and base.tuning is not None
            else (default_tuning_workspace_config(next_config) if tuning_enabled else None)
        ),
    )


def write_project_contract_and_sync(
    *,
    project_dir: Path,
    config: ProjectConfig,
    previous_config: ProjectConfig | None = None,
) -> tuple[Path, dict[str, list[str]]]:
    """Persist the contract without writing legacy scaffold files."""
    _ = previous_config
    config_path = write_project_config(project_dir, config)
    return config_path, {"created": [], "updated": [], "deleted": [], "preserved": []}


def format_scaffold_sync_lines(sync_summary: dict[str, list[str]]) -> list[str]:
    """Format scaffold synchronization summary for human output."""
    lines: list[str] = []
    if sync_summary["created"]:
        lines.append("Created: " + ", ".join(sync_summary["created"]))
    if sync_summary["updated"]:
        lines.append("Updated: " + ", ".join(sync_summary["updated"]))
    if sync_summary.get("deleted"):
        lines.append("Deleted: " + ", ".join(sync_summary["deleted"]))
    if sync_summary["preserved"]:
        lines.append("Preserved: " + ", ".join(sync_summary["preserved"]))
    return lines


def contract_edit_command(
    *,
    runtime: CommandRuntime,
    modes: str | None,
    mode_inputs: list[str] | None,
    mode_outputs: list[str] | None,
    vector_db: bool | None,
    fine_tune: bool | None,
    json_output: bool,
    debug: bool,
    prompt_contract_config_fn: Any,
) -> None:
    """Edit the hidden local contract."""
    context = runtime.build_command_context("contract.edit", debug=debug, json_output=json_output)
    try:
        existing = (
            load_project_config(Path.cwd())
            if (Path.cwd() / PROJECT_CONFIG_RELATIVE_PATH).exists()
            else None
        )
        if (
            modes is None
            and not mode_inputs
            and not mode_outputs
            and vector_db is None
            and fine_tune is None
        ):
            runtime.require_tty()
            config = prompt_contract_config_fn(existing)
        else:
            config = build_contract_from_flags(
                existing=existing,
                modes_flag=modes,
                mode_inputs_flags=mode_inputs,
                mode_outputs_flags=mode_outputs,
                vector_db_flag=vector_db,
                fine_tune_flag=fine_tune,
            )
        config_path, sync_summary = write_project_contract_and_sync(
            project_dir=Path.cwd(),
            config=config,
            previous_config=existing,
        )
        sync_lines = format_scaffold_sync_lines(sync_summary)
        runtime.emit_result(
            {
                "project_config_file": str(config_path.relative_to(Path.cwd())),
                "capabilities": config.capabilities.model_dump(),
                "resources": config.resources.model_dump(),
                "modes": config.modes.model_dump(exclude_none=True),
                "tuning": config.tuning.model_dump(by_alias=True) if config.tuning else None,
                "scaffold_sync": sync_summary,
                "request_id": context.request_id,
            },
            json_output=json_output,
            success_message=(
                f"Wrote: {config_path.relative_to(Path.cwd())}\n"
                "Modes: " + ", ".join(resolve_project_operation_names(config)) + "\n"
                f"Vector: {'enabled' if config.capabilities.vector else 'disabled'}\n"
                f"Fine-Tune: {'enabled' if config.tuning is not None else 'disabled'}\n"
                + (("\n" + "\n".join(sync_lines)) if sync_lines else "")
            ),
            title="CONTRACT",
        )
    except Exception as error:
        exit_with_error(
            error,
            json_output=json_output,
            request_id=context.request_id,
            context=context,
        )


def contract_validate_command(*, runtime: CommandRuntime, json_output: bool, debug: bool) -> None:
    """Validate the hidden local contract."""
    context = runtime.build_command_context(
        "contract.validate",
        debug=debug,
        json_output=json_output,
    )
    try:
        config = load_project_config(Path.cwd())
        runtime.emit_result(
            {
                "project_config_file": PROJECT_CONFIG_FILE_NAME,
                "capabilities": config.capabilities.model_dump(),
                "resources": config.resources.model_dump(),
                "modes": config.modes.model_dump(exclude_none=True),
                "tuning": config.tuning.model_dump(by_alias=True) if config.tuning else None,
                "request_id": context.request_id,
            },
            json_output=json_output,
            success_message=(
                f"Validated: {PROJECT_CONFIG_FILE_NAME}\n"
                "Modes: "
                + ", ".join(resolve_project_operation_names(config))
                + f"\nFine-Tune: {'enabled' if config.tuning is not None else 'disabled'}"
            ),
            title="CONTRACT",
        )
    except Exception as error:
        exit_with_error(
            error,
            json_output=json_output,
            request_id=context.request_id,
            context=context,
        )


def contract_show_command(
    *,
    runtime: CommandRuntime,
    json_output: bool,
    debug: bool,
) -> None:
    """Show the hidden local contract."""
    context = runtime.build_command_context("contract.show", debug=debug, json_output=json_output)
    try:
        config = load_project_config(Path.cwd())
        payload = {
            "project_config_file": PROJECT_CONFIG_FILE_NAME,
            "schema_version": config.schema_version,
            "capabilities": config.capabilities.model_dump(),
            "resources": config.resources.model_dump(),
            "modes": config.modes.model_dump(exclude_none=True),
            "tuning": config.tuning.model_dump(by_alias=True) if config.tuning else None,
            "request_id": context.request_id,
        }
        if json_output:
            runtime.emit_result(payload, json_output=True)
        else:
            runtime.console.print(Panel(Pretty(payload, expand_all=True), title=" CONTRACT "))
    except Exception as error:
        exit_with_error(
            error,
            json_output=json_output,
            request_id=context.request_id,
            context=context,
        )


def _extract_sdk_contract(
    project_dir: Path,
    python_bin: str | None,
) -> dict[str, Any]:
    """Extract full contract from SDK."""
    import json
    import os
    import subprocess

    from aimp_cli.operations.publish.core import (
        _build_contract_python_candidates,
        _build_contract_pythonpath,
    )

    module_path = project_dir / AGENT_ENTRYPOINT_RELATIVE_PATH
    if not module_path.exists():
        return {}

    resolved_candidates = _build_contract_python_candidates(python_bin)

    for candidate in resolved_candidates:
        env = os.environ.copy()
        env["PYTHONPATH"] = _build_contract_pythonpath(
            project_dir=project_dir,
            env=env,
        )
        try:
            completed = subprocess.run(
                [candidate, "-m", "aimp_sdk.contract", "--module", str(module_path)],
                check=False,
                capture_output=True,
                text=True,
                env=env,
            )
        except OSError:
            continue
        output = (completed.stdout or completed.stderr or "").strip()
        if completed.returncode != 0 or not output:
            continue
        try:
            contract = json.loads(output)
            return contract if isinstance(contract, dict) else {}
        except (ValueError, TypeError):
            continue
    return {}


def contract_diff_command(
    *,
    runtime: CommandRuntime,
    python_bin: str | None = None,
    json_output: bool = False,
    debug: bool = False,
) -> None:
    """Compare hidden project config with SDK-declared modes.

    Shows differences between:
    - Modes declared in TOML but not implemented in SDK
    - Modes implemented in SDK but not declared in TOML
    - Input/output modality mismatches
    """
    context = runtime.build_command_context("contract.diff", debug=debug, json_output=json_output)
    try:
        project_dir = Path.cwd()
        if not (project_dir / PROJECT_CONFIG_RELATIVE_PATH).exists():
            raise FileNotFoundError(f"No {PROJECT_CONFIG_FILE_NAME} found. Run 'ai init' first.")

        toml_config = load_project_config(project_dir)
        sdk_contract = _extract_sdk_contract(project_dir, python_bin)
        sdk_operations = sdk_contract.get("modes", {}) if isinstance(sdk_contract, dict) else {}
        sdk_resources = sdk_contract.get("resources", {}) if isinstance(sdk_contract, dict) else {}

        toml_operations = set(toml_config.modes.names())
        sdk_operation_names = set(sdk_operations.keys())

        missing_implementations = sorted(toml_operations - sdk_operation_names)
        extra_implementations = sorted(sdk_operation_names - toml_operations)

        modality_mismatches: list[dict[str, Any]] = []
        for op_name in sorted(toml_operations & sdk_operation_names):
            toml_op = toml_config.modes.get(op_name)
            sdk_op = sdk_operations.get(op_name, {})
            sdk_inputs_list: list[dict[str, Any]] = sdk_op.get("inputs", [])
            toml_inputs_list: list[InputDefinition] = list(toml_op.inputs) if toml_op else []
            sdk_inputs = {(inp.get("name"), inp.get("kind")) for inp in sdk_inputs_list}
            toml_inputs = {(inp.name, inp.kind) for inp in toml_inputs_list}
            if sdk_inputs != toml_inputs:
                modality_mismatches.append(
                    {
                        "operation": op_name,
                        "field": "inputs",
                        "toml": sorted([f"{n}:{k}" for n, k in toml_inputs]),
                        "sdk": sorted([f"{n}:{k}" for n, k in sdk_inputs]),
                    }
                )

        diff_result = {
            "toml_operations": sorted(toml_operations),
            "sdk_operations": sorted(sdk_operation_names),
            "toml_resources": toml_config.resources.model_dump(exclude_none=True),
            "sdk_resources": sdk_resources,
            "missing_implementations": missing_implementations,
            "extra_implementations": extra_implementations,
            "modality_mismatches": modality_mismatches,
            "has_drift": bool(
                missing_implementations
                or extra_implementations
                or modality_mismatches
                or toml_config.resources.model_dump(exclude_none=True) != sdk_resources
            ),
        }

        if json_output:
            runtime.emit_result(
                {**diff_result, "request_id": context.request_id},
                json_output=True,
            )
            return

        if not diff_result["has_drift"]:
            runtime.console.print("[green]Contract is in sync with SDK.[/green]")
            return

        if missing_implementations:
            runtime.console.print(
                "[yellow]Missing implementations: TOML declares but SDK doesn't implement[/yellow]"
            )
            for op in missing_implementations:
                runtime.console.print(f"  - {op}")

        if extra_implementations:
            runtime.console.print(
                "[yellow]Extra implementations: SDK implements but TOML doesn't declare[/yellow]"
            )
            for op in extra_implementations:
                runtime.console.print(f"  - {op}")

        if modality_mismatches:
            runtime.console.print("[yellow]Modality mismatches:[/yellow]")
            for mismatch in modality_mismatches:
                runtime.console.print(f"  - {mismatch['operation']}.{mismatch['field']}:")
                runtime.console.print(f"    TOML: {mismatch['toml']}")
                runtime.console.print(f"    SDK:  {mismatch['sdk']}")
        if diff_result["toml_resources"] != diff_result["sdk_resources"]:
            runtime.console.print("[yellow]Resource drift:[/yellow]")
            runtime.console.print(f"  TOML: {diff_result['toml_resources']}")
            runtime.console.print(f"  SDK:  {diff_result['sdk_resources']}")

    except Exception as error:
        exit_with_error(
            error,
            json_output=json_output,
            request_id=context.request_id,
            context=context,
        )


def _sdk_inputs_match_toml_inputs(sdk_inputs: list[dict[str, Any]], toml_inputs: list[Any]) -> bool:
    """Check if SDK input definitions match TOML input definitions."""
    if len(sdk_inputs) != len(toml_inputs):
        return False
    for sdk_inp, toml_inp in zip(sdk_inputs, toml_inputs):
        toml_dict = toml_inp if isinstance(toml_inp, dict) else toml_inp.model_dump()
        if sdk_inp.get("name") != toml_dict.get("name"):
            return False
        if sdk_inp.get("kind") != toml_dict.get("kind"):
            return False
        if sdk_inp.get("required", True) != toml_dict.get("required", True):
            return False
    return True


def _input_defs_from_sdk(sdk_inputs: list[dict[str, Any]]) -> list[Any]:
    """Convert SDK input dicts to InputDefinition objects."""
    from aimp_cli.domain.models import InputDefinition

    input_defs: list[InputDefinition] = []
    for inp in sdk_inputs:
        if inp.get("kind") not in ("text", "image", "audio", "video", "file", "json"):
            continue
        input_defs.append(
            InputDefinition(
                name=inp.get("name", "text"),
                kind=inp.get("kind", "text"),
                required=inp.get("required", True),
                description=inp.get("description", ""),
                multiple=inp.get("multiple", False),
                label=inp.get("label"),
                default=inp.get("default"),
            )
        )
    return input_defs


def contract_sync_command(
    *,
    runtime: CommandRuntime,
    python_bin: str | None = None,
    dry_run: bool = False,
    json_output: bool = False,
    debug: bool = False,
) -> None:
    """Synchronize hidden project config with SDK-declared modes.

    Updates .aimp/project.toml to match modes declared in SDK.
    Does NOT modify resources (those are TOML-only source of truth).

    Use --dry-run to see what would change without writing.
    """
    context = runtime.build_command_context("contract.sync", debug=debug, json_output=json_output)
    try:
        project_dir = Path.cwd()
        if not (project_dir / PROJECT_CONFIG_RELATIVE_PATH).exists():
            raise FileNotFoundError(f"No {PROJECT_CONFIG_FILE_NAME} found. Run 'ai init' first.")

        toml_config = load_project_config(project_dir)
        sdk_contract = _extract_sdk_contract(project_dir, python_bin)
        sdk_operations = sdk_contract.get("modes", {}) if isinstance(sdk_contract, dict) else {}
        sdk_resources = sdk_contract.get("resources", {}) if isinstance(sdk_contract, dict) else {}

        if not sdk_operations:
            raise RuntimeError(
                "Failed to extract modes from SDK. Check agent.py and the unified project bridge."
            )

        toml_operations = set(toml_config.modes.names())
        sdk_operation_names = set(sdk_operations.keys())

        changes: dict[str, Any] = {
            "added_operations": [],
            "removed_operations": [],
            "updated_inputs": [],
            "updated_resources": (
                toml_config.resources.model_dump(exclude_none=True) != sdk_resources
            ),
        }

        for op_name in sdk_operation_names - toml_operations:
            changes["added_operations"].append(op_name)

        for op_name in toml_operations - sdk_operation_names:
            changes["removed_operations"].append(op_name)

        for op_name in sorted(sdk_operation_names & toml_operations):
            toml_op = toml_config.modes.get(op_name)
            sdk_op = sdk_operations.get(op_name, {})
            sdk_inputs = list(sdk_op.get("inputs", []))
            toml_inputs = list(toml_op.inputs) if toml_op else []
            if not _sdk_inputs_match_toml_inputs(sdk_inputs, toml_inputs):
                changes["updated_inputs"].append(
                    {
                        "operation": op_name,
                        "toml_inputs": [
                            inp.model_dump() if hasattr(inp, "model_dump") else inp
                            for inp in toml_inputs
                        ],
                        "sdk_inputs": sdk_inputs,
                    }
                )

        has_changes = bool(
            changes["added_operations"]
            or changes["removed_operations"]
            or changes["updated_inputs"]
        )

        if not has_changes:
            runtime.console.print("[green]Contract is already in sync. No changes needed.[/green]")
            return

        if not dry_run:
            new_operations: dict[str, ModeContract] = {}
            for op_name in sorted(sdk_operation_names):
                sdk_op = sdk_operations.get(op_name, {})
                toml_op = toml_config.modes.get(op_name)
                sdk_inputs = sdk_op.get("inputs", [])
                if sdk_inputs:
                    input_defs = _input_defs_from_sdk(sdk_inputs)
                elif toml_op and toml_op.inputs:
                    input_defs = list(toml_op.inputs)
                else:
                    from aimp_cli.domain.models import InputDefinition

                    input_defs = [InputDefinition(name="text", kind="text", required=True)]

                sdk_outputs = sdk_op.get("outputs")
                toml_outputs = toml_op.outputs if toml_op else None
                outputs = sdk_outputs if sdk_outputs else toml_outputs

                new_operations[op_name] = ModeContract(
                    inputs=input_defs,
                    outputs=normalize_modalities(outputs, field_name=f"modes.{op_name}.outputs")
                    if outputs
                    else None,
                    description=sdk_op.get("description", toml_op.description if toml_op else ""),
                    resources=ModeResourcesConfig.model_validate(sdk_op["resources"])
                    if isinstance(sdk_op.get("resources"), dict)
                    else (
                        toml_op.resources.model_copy(deep=True)
                        if toml_op and toml_op.resources is not None
                        else None
                    ),
                )

            new_config = ProjectConfig(
                schema_version=toml_config.schema_version,
                capabilities=CapabilitiesConfig(
                    vector=ResourceConfig.model_validate(sdk_resources or {}).vector_db_enabled,
                    tuning=toml_config.tuning is not None,
                ),
                resources=ResourceConfig.model_validate(sdk_resources or {}),
                modes=ModesConfig(new_operations),
                tuning=toml_config.tuning,
            )

            write_project_config(project_dir, new_config)

        if json_output:
            runtime.emit_result(
                {"changes": changes, "dry_run": dry_run, "request_id": context.request_id},
                json_output=True,
            )
            return

        if dry_run:
            runtime.console.print("[yellow]Dry run - would make the following changes:[/yellow]")

        if changes["added_operations"]:
            runtime.console.print(f"[green]Added modes: {changes['added_operations']}[/green]")
        if changes["removed_operations"]:
            runtime.console.print(f"[red]Removed modes: {changes['removed_operations']}[/red]")
        if changes["updated_inputs"]:
            for update in changes["updated_inputs"]:
                runtime.console.print(f"[yellow]Updated {update['operation']} inputs:[/yellow]")
                runtime.console.print(f"  TOML: {update['toml_inputs']}")
                runtime.console.print(f"  SDK:  {update['sdk_inputs']}")
        if changes["updated_resources"]:
            runtime.console.print("[yellow]Updated resources from Python authoring.[/yellow]")

        if not dry_run:
            runtime.console.print(f"\n[green]Updated: {PROJECT_CONFIG_FILE_NAME}[/green]")

    except Exception as error:
        exit_with_error(
            error,
            json_output=json_output,
            request_id=context.request_id,
            context=context,
        )
