"""Publish command handlers."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from aimp_cli.core.errors import auth_error, usage_error
from aimp_cli.domain.constants import PUBLISH_CONFIG_FILE_NAME
from aimp_cli.operations.publish.config import ensure_publish_config
from aimp_cli.operations.publish.core import publish_model_by_slug

from .common import CommandRuntime, exit_with_error


def run_publish_command(
    *,
    runtime: CommandRuntime,
    gateway: str | None,
    api_key: str | None,
    slug: str | None,
    parallel: int,
    verbose: bool,
    json_output: bool,
    debug: bool,
    python_bin: str | None,
    configure_only: bool,
    force: bool,
    build_publish_success_message: Any,
) -> None:
    """Run the publish flow or configure-only flow."""
    context = runtime.build_command_context("publish", debug=debug, json_output=json_output)
    try:
        auth_context = runtime.resolve_auth_context(gateway=gateway, api_key=api_key)
        if not auth_context.api_key:
            raise auth_error(
                "Not authenticated. Run: ai login",
                code="not_authenticated",
                request_id=context.request_id,
            )
        client = runtime.gateway_client_cls(auth_context, context)
        try:
            if slug is not None:
                normalized_slug = slug.strip()
                if not normalized_slug:
                    raise usage_error(
                        "--slug must be non-empty",
                        code="invalid_publish_slug",
                        request_id=context.request_id,
                    )
                if configure_only:
                    raise usage_error(
                        "--configure cannot be used with --slug",
                        code="invalid_publish_mode",
                        request_id=context.request_id,
                    )
                if python_bin is not None:
                    raise usage_error(
                        "--python cannot be used with --slug",
                        code="invalid_publish_mode",
                        request_id=context.request_id,
                    )
                if force:
                    raise usage_error(
                        "--force cannot be used with --slug",
                        code="invalid_publish_mode",
                        request_id=context.request_id,
                    )
                if verbose:
                    raise usage_error(
                        "--verbose cannot be used with --slug",
                        code="invalid_publish_mode",
                        request_id=context.request_id,
                    )
                if not json_output and runtime.has_interactive_terminal():
                    confirmed = runtime.confirm_action(
                        f"Publish '{normalized_slug}' now?",
                        console=runtime.console,
                        confirm_label="Publish model",
                        cancel_label="Keep private",
                        confirm_description=(
                            "Make this existing model public using the normal publish flow."
                        ),
                        cancel_description="Leave the model private and exit.",
                        title="Publish Existing Model",
                        subtitle=f"Model slug: {normalized_slug}",
                    )
                    if not confirmed:
                        raise usage_error(
                            f"Publish canceled. Model '{normalized_slug}' remains private.",
                            code="publish_canceled_by_user",
                            request_id=context.request_id,
                        )
                result = publish_model_by_slug(gateway=client, slug=normalized_slug)
                result["request_id"] = context.request_id
                runtime.emit_result(
                    result,
                    json_output=json_output,
                    success_message=build_publish_success_message(result),
                    title="PUBLISH",
                )
                return
            publish_config = ensure_publish_config(
                project_dir=Path.cwd(),
                gateway=client,
                configure_only=configure_only,
                console=runtime.console,
                interactive_terminal=runtime.has_interactive_terminal(),
            )
            if configure_only:
                runtime.emit_result(
                    {
                        "publish_config_file": PUBLISH_CONFIG_FILE_NAME,
                        "studio_name": publish_config.studio.name,
                        "hardware_tiers": publish_config.hardware.supported_tiers,
                        "request_id": context.request_id,
                    },
                    json_output=json_output,
                    success_message=(
                        f"Wrote: {PUBLISH_CONFIG_FILE_NAME}\n"
                        "Supported hardware: " + ", ".join(publish_config.hardware.supported_tiers)
                    ),
                    title="PUBLISH CONFIG",
                )
                return
            result = runtime.run_publish(
                project_dir=Path.cwd(),
                gateway=client,
                context=context,
                python_bin=python_bin,
                parallel=parallel,
                verbose=verbose,
                force=force,
            )
        finally:
            client.close()
        runtime.emit_result(
            result,
            json_output=json_output,
            success_message=build_publish_success_message(result),
            title="PUBLISH",
        )
    except Exception as error:
        exit_with_error(
            error,
            json_output=json_output,
            request_id=context.request_id,
            context=context,
        )
