"""Unified workspace job read commands."""

from __future__ import annotations

import time
from datetime import UTC, datetime
from math import ceil
from typing import Any

from aimp_cli.core.errors import CliError, auth_error, usage_error
from aimp_cli.domain.models import (
    FineTuneJobListResponse,
    FineTuneJobResponse,
    JobDetailResponse,
    JobListEntry,
    JobsListResponse,
    PublishBuildJob,
    PublishBuildJobListResponse,
)

from .common import CommandRuntime, exit_with_error

MAX_REMOTE_PAGE_SIZE = 100
VALID_LIST_TYPES = {"all", "build", "fine-tune"}
VALID_DETAIL_TYPES = {"build", "fine-tune"}
VALID_MUTATION_TYPES = {"build", "fine-tune"}
TERMINAL_JOB_STATUSES = {"succeeded", "failed", "canceled"}


def _parse_timestamp(value: str | None) -> datetime:
    """Parse one optional ISO timestamp for deterministic job sorting."""
    if not value:
        return datetime.min.replace(tzinfo=UTC)

    normalized = value.strip()
    if not normalized:
        return datetime.min.replace(tzinfo=UTC)

    try:
        parsed = datetime.fromisoformat(normalized.replace("Z", "+00:00"))
    except ValueError:
        return datetime.min.replace(tzinfo=UTC)
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=UTC)
    return parsed


def _job_sort_key(item: JobListEntry) -> tuple[datetime, str]:
    """Return a stable descending sort key for unified job rows."""
    return (_parse_timestamp(item.created_at), item.job_id)


def _build_job_entry(job: PublishBuildJob) -> JobListEntry:
    """Normalize one publish build job into the unified job list shape."""
    return JobListEntry(
        job_type="build",
        job_id=job.job_id,
        model_slug=job.slug,
        status=job.status,
        created_at=job.created_at,
        started_at=job.started_at,
        finished_at=job.finished_at,
        job=job.model_dump(),
    )


def _fine_tune_job_entry(job: FineTuneJobResponse) -> JobListEntry:
    """Normalize one fine-tune job into the unified job list shape."""
    return JobListEntry(
        job_type="fine-tune",
        job_id=job.job_id,
        model_slug=job.model_slug,
        status=job.status,
        created_at=job.created_at,
        started_at=job.started_at,
        finished_at=job.finished_at,
        job=job.model_dump(),
    )


def _build_combined_pagination(*, total_items: int, page: int, page_size: int) -> dict[str, Any]:
    """Build pagination metadata for merged multi-source job output."""
    total_pages = ceil(total_items / page_size) if total_items else 0
    return {
        "page": page,
        "page_size": page_size,
        "total_items": total_items,
        "total_pages": total_pages,
        "has_next": total_pages > 0 and page < total_pages,
        "has_previous": total_pages > 0 and page > 1,
    }


def _collect_build_jobs(
    *,
    client: Any,
    model: str | None,
    status: str | None,
    limit: int,
) -> PublishBuildJobListResponse:
    """Fetch enough build jobs to support merged pagination in ``type=all`` mode."""
    page = 1
    collected: list[PublishBuildJob] = []
    pagination: dict[str, Any] = {}

    while len(collected) < limit:
        remaining = limit - len(collected)
        payload = client.list_publish_build_jobs(
            model_slug=model,
            status=status,
            page=page,
            page_size=min(MAX_REMOTE_PAGE_SIZE, remaining),
        )
        collected.extend(payload.results)
        pagination = payload.pagination
        if not payload.pagination.get("has_next") or not payload.results:
            break
        page += 1

    return PublishBuildJobListResponse(results=collected, pagination=pagination, model_slug=model)


def _collect_fine_tune_jobs(
    *,
    client: Any,
    model: str | None,
    status: str | None,
    limit: int,
) -> FineTuneJobListResponse:
    """Fetch enough fine-tune jobs to support merged pagination in ``type=all`` mode."""
    page = 1
    collected: list[FineTuneJobResponse] = []
    pagination: dict[str, Any] = {}

    while len(collected) < limit:
        remaining = limit - len(collected)
        payload = client.list_fine_tune_jobs(
            model_slug=model,
            status=status,
            page=page,
            page_size=min(MAX_REMOTE_PAGE_SIZE, remaining),
        )
        collected.extend(payload.results)
        pagination = payload.pagination
        if not payload.pagination.get("has_next") or not payload.results:
            break
        page += 1

    return FineTuneJobListResponse(results=collected, pagination=pagination)


def _cancel_and_delete_build_job(*, client: Any, job_id: str) -> dict[str, Any]:
    """Cancel one build job and remove it from history."""
    payload = client.cancel_publish_build_job(job_id)
    if payload.cancel_state == "requested":
        while True:
            try:
                job = client.get_publish_build_job(job_id)
            except CliError as error:
                if error.http_status == 404:
                    break
                raise
            if job.status == "canceled":
                client.delete_publish_build_job(job_id)
                break
            time.sleep(1.0)
    else:
        client.delete_publish_build_job(job_id)
    return {
        "job_type": "build",
        "job_id": job_id,
        "action": "canceled_and_deleted",
    }


def _cancel_and_delete_fine_tune_job(*, client: Any, job_id: str) -> dict[str, Any]:
    """Cancel one fine-tune job and remove it from history."""
    payload = client.cancel_fine_tune_job(job_id=job_id)
    if payload.cancel_state == "canceled":
        client.delete_fine_tune_job(job_id=job_id)
    return {
        "job_type": "fine-tune",
        "job_id": job_id,
        "action": "canceled_and_deleted",
    }


def jobs_list_command(
    *,
    runtime: CommandRuntime,
    job_type: str,
    model: str | None,
    status: str | None,
    page: int,
    page_size: int,
    gateway: str | None,
    api_key: str | None,
    json_output: bool,
    debug: bool,
    render_jobs_list: Any,
) -> None:
    """List unified workspace jobs from the CLI."""
    context = runtime.build_command_context("jobs.list", debug=debug, json_output=json_output)
    try:
        normalized_type = job_type.strip().lower()
        if normalized_type not in VALID_LIST_TYPES:
            raise usage_error(
                "--type must be one of: all,build,fine-tune",
                code="invalid_job_type",
                request_id=context.request_id,
            )
        auth_context = runtime.resolve_auth_context(gateway=gateway, api_key=api_key)
        if not auth_context.api_key:
            raise auth_error(
                "Not authenticated. Run: ai login",
                code="not_authenticated",
                request_id=context.request_id,
            )

        client = runtime.gateway_client_cls(auth_context, context)
        try:
            if normalized_type == "build":
                build_payload = client.list_publish_build_jobs(
                    model_slug=model,
                    status=status,
                    page=page,
                    page_size=page_size,
                )
                payload = JobsListResponse(
                    type="build",
                    filters={"model": model, "status": status},
                    results=[_build_job_entry(job) for job in build_payload.results],
                    pagination=build_payload.pagination,
                    sources={"build": build_payload.pagination},
                )
            elif normalized_type == "fine-tune":
                fine_tune_payload = client.list_fine_tune_jobs(
                    model_slug=model,
                    status=status,
                    page=page,
                    page_size=page_size,
                )
                payload = JobsListResponse(
                    type="fine-tune",
                    filters={"model": model, "status": status},
                    results=[_fine_tune_job_entry(job) for job in fine_tune_payload.results],
                    pagination=fine_tune_payload.pagination,
                    sources={"fine_tune": fine_tune_payload.pagination},
                )
            else:
                limit = page * page_size
                build_payload = _collect_build_jobs(
                    client=client,
                    model=model,
                    status=status,
                    limit=limit,
                )
                fine_tune_payload = _collect_fine_tune_jobs(
                    client=client,
                    model=model,
                    status=status,
                    limit=limit,
                )
                combined = [
                    *[_build_job_entry(job) for job in build_payload.results],
                    *[_fine_tune_job_entry(job) for job in fine_tune_payload.results],
                ]
                combined.sort(key=_job_sort_key, reverse=True)
                page_start = (page - 1) * page_size
                page_end = page_start + page_size
                total_items = int(build_payload.pagination.get("total_items", 0)) + int(
                    fine_tune_payload.pagination.get("total_items", 0)
                )
                payload = JobsListResponse(
                    type="all",
                    filters={"model": model, "status": status},
                    results=combined[page_start:page_end],
                    pagination=_build_combined_pagination(
                        total_items=total_items,
                        page=page,
                        page_size=page_size,
                    ),
                    sources={
                        "build": build_payload.pagination,
                        "fine_tune": fine_tune_payload.pagination,
                    },
                )
        finally:
            client.close()

        result = payload.model_dump()
        if json_output:
            runtime.emit_result(result, json_output=True)
        else:
            render_jobs_list(result)
    except Exception as error:
        exit_with_error(
            error,
            json_output=json_output,
            request_id=context.request_id,
            context=context,
        )


def jobs_get_command(
    *,
    runtime: CommandRuntime,
    job_type: str,
    job: str,
    gateway: str | None,
    api_key: str | None,
    json_output: bool,
    debug: bool,
    render_job_detail: Any,
) -> None:
    """Get one job from the selected job type."""
    context = runtime.build_command_context("jobs.get", debug=debug, json_output=json_output)
    try:
        normalized_type = job_type.strip().lower()
        if normalized_type not in VALID_DETAIL_TYPES:
            raise usage_error(
                "--type must be one of: build,fine-tune",
                code="invalid_job_type",
                request_id=context.request_id,
            )
        auth_context = runtime.resolve_auth_context(gateway=gateway, api_key=api_key)
        if not auth_context.api_key:
            raise auth_error(
                "Not authenticated. Run: ai login",
                code="not_authenticated",
                request_id=context.request_id,
            )

        client = runtime.gateway_client_cls(auth_context, context)
        try:
            if normalized_type == "build":
                payload = JobDetailResponse(
                    job_type="build",
                    job=client.get_publish_build_job(job).model_dump(),
                )
            else:
                payload = JobDetailResponse(
                    job_type="fine-tune",
                    job=client.get_fine_tune_job(job_id=job).model_dump(),
                )
        finally:
            client.close()

        result = payload.model_dump()
        if json_output:
            runtime.emit_result(result, json_output=True)
        else:
            render_job_detail(result)
    except Exception as error:
        exit_with_error(
            error,
            json_output=json_output,
            request_id=context.request_id,
            context=context,
        )


def jobs_cancel_command(
    *,
    runtime: CommandRuntime,
    job_type: str,
    job: str,
    gateway: str | None,
    api_key: str | None,
    json_output: bool,
    debug: bool,
    render_job_action: Any,
) -> None:
    """Cancel one job and remove it from history."""
    context = runtime.build_command_context("jobs.cancel", debug=debug, json_output=json_output)
    try:
        normalized_type = job_type.strip().lower()
        if normalized_type not in VALID_MUTATION_TYPES:
            raise usage_error(
                "--type must be one of: build,fine-tune",
                code="invalid_job_type",
                request_id=context.request_id,
            )
        auth_context = runtime.resolve_auth_context(gateway=gateway, api_key=api_key)
        if not auth_context.api_key:
            raise auth_error(
                "Not authenticated. Run: ai login",
                code="not_authenticated",
                request_id=context.request_id,
            )

        client = runtime.gateway_client_cls(auth_context, context)
        try:
            if normalized_type == "build":
                result = _cancel_and_delete_build_job(client=client, job_id=job)
            else:
                result = _cancel_and_delete_fine_tune_job(client=client, job_id=job)
        finally:
            client.close()

        if json_output:
            runtime.emit_result(result, json_output=True)
        else:
            render_job_action(result)
    except Exception as error:
        exit_with_error(
            error,
            json_output=json_output,
            request_id=context.request_id,
            context=context,
        )


def jobs_delete_command(
    *,
    runtime: CommandRuntime,
    job_type: str,
    job: str,
    gateway: str | None,
    api_key: str | None,
    json_output: bool,
    debug: bool,
    render_job_action: Any,
) -> None:
    """Delete one terminal job from history."""
    context = runtime.build_command_context("jobs.delete", debug=debug, json_output=json_output)
    try:
        normalized_type = job_type.strip().lower()
        if normalized_type not in VALID_MUTATION_TYPES:
            raise usage_error(
                "--type must be one of: build,fine-tune",
                code="invalid_job_type",
                request_id=context.request_id,
            )
        auth_context = runtime.resolve_auth_context(gateway=gateway, api_key=api_key)
        if not auth_context.api_key:
            raise auth_error(
                "Not authenticated. Run: ai login",
                code="not_authenticated",
                request_id=context.request_id,
            )

        client = runtime.gateway_client_cls(auth_context, context)
        try:
            if normalized_type == "build":
                build_job = client.get_publish_build_job(job)
                if build_job.status not in TERMINAL_JOB_STATUSES:
                    raise usage_error(
                        "Delete requires a terminal job. Use `ai jobs cancel` first.",
                        code="job_not_terminal",
                        request_id=context.request_id,
                    )
                client.delete_publish_build_job(job)
            else:
                fine_tune_job = client.get_fine_tune_job(job_id=job)
                if fine_tune_job.status not in TERMINAL_JOB_STATUSES:
                    raise usage_error(
                        "Delete requires a terminal job. Use `ai jobs cancel` first.",
                        code="job_not_terminal",
                        request_id=context.request_id,
                    )
                client.delete_fine_tune_job(job_id=job)
        finally:
            client.close()

        result = {
            "job_type": normalized_type,
            "job_id": job,
            "action": "deleted",
        }
        if json_output:
            runtime.emit_result(result, json_output=True)
        else:
            render_job_action(result)
    except Exception as error:
        exit_with_error(
            error,
            json_output=json_output,
            request_id=context.request_id,
            context=context,
        )
