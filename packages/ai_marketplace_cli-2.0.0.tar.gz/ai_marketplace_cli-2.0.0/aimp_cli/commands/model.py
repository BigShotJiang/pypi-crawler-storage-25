"""Model command handlers."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from aimp_cli.core.errors import auth_error, remote_state_error, usage_error
from aimp_cli.domain.constants import (
    DEFAULT_STUDIO_ARTICLE_MDX_FILE,
    LEGACY_PUBLISH_CONFIG_FILE_NAME,
    PUBLISH_CONFIG_FILE_NAME,
    PUBLISH_CONFIG_RELATIVE_PATH,
)
from aimp_cli.domain.publish_config import load_publish_config
from aimp_cli.domain.serialization import serialize_publish_config_toml
from aimp_cli.operations.publish.local_metadata import build_local_publish_metadata

from .common import CommandRuntime, exit_with_error


def resolve_model_operations(detail: Any) -> list[str]:
    """Resolve model execution operations from studio detail payloads."""
    operations = getattr(detail, "modes", {}) or {}
    if isinstance(operations, dict):
        return [name for name in operations if operations.get(name) is not None]
    execution = getattr(detail, "execution", {}) or {}
    if isinstance(execution, dict):
        operations = execution.get("modes")
        if isinstance(operations, list):
            normalized = [
                str(item).strip() for item in operations if isinstance(item, str) and item.strip()
            ]
            if normalized:
                return normalized
    return ["generate"]


def model_inspect_command(
    *,
    runtime: CommandRuntime,
    slug: str | None,
    asset_id: str | None,
    actions: str | None,
    gateway: str | None,
    api_key: str | None,
    json_output: bool,
    debug: bool,
    render_model_inspect: Any,
) -> None:
    """Inspect model metadata and pricing."""
    context = runtime.build_command_context("model.inspect", debug=debug, json_output=json_output)
    try:
        if not slug and not asset_id:
            raise usage_error(
                "Provide --slug or --id",
                code="missing_model_selector",
                request_id=context.request_id,
            )
        auth_context = runtime.resolve_auth_context(gateway=gateway, api_key=api_key)
        if not auth_context.api_key:
            raise auth_error(
                "Not authenticated. Run: ai login",
                code="not_authenticated",
                request_id=context.request_id,
            )
        client = runtime.gateway_client_cls(auth_context, context)
        try:
            model_id = asset_id
            if not model_id and slug:
                model = client.get_model(slug)
                if model is None:
                    raise remote_state_error(
                        f"Model not found for slug '{slug}'",
                        code="model_not_found",
                        request_id=context.request_id,
                        http_status=404,
                    )
                model_id = model.id
            if model_id is None:
                raise remote_state_error(
                    "Model lookup did not return an asset identifier",
                    code="model_id_missing",
                    request_id=context.request_id,
                )
            detail = client.get_studio_model(model_id)
            action_list = (
                [item.strip() for item in actions.split(",") if item.strip()]
                if actions
                else resolve_model_operations(detail)
            ) or ["generate"]
            analytics: dict[str, Any] = {}
            analytics_error = None
            try:
                analytics = client.get_studio_model_analytics(model_id)
            except Exception as error:
                analytics_error = str(error)
            rates: dict[str, Any] | None = None
            rates_error = None
            try:
                rates = client.get_model_rates(model_id, action_list)
            except Exception as error:
                rates_error = str(error)
        finally:
            client.close()
        output = {
            "model": {
                "id": detail.id,
                "slug": detail.slug,
                "name": detail.name,
                "status": detail.status,
                "version": detail.version,
                "supported_hardware_tiers": detail.supported_hardware_tiers,
                "hardware_tier": detail.hardware_tier,
                "pricing": detail.pricing,
                "execution": detail.execution,
                "selected_modes": action_list,
                "studio_article": detail.studio.get("article") if detail.studio else None,
            },
            "storage": {"model_size_bytes": analytics.get("model_size_bytes")},
            "layer_pool": analytics.get("layer_pool"),
            "rates": rates,
            "partial_errors": {"analytics": analytics_error, "rates": rates_error},
            "request_id": context.request_id,
        }
        if json_output:
            runtime.emit_result(output, json_output=True)
        else:
            render_model_inspect(output)
    except Exception as error:
        exit_with_error(
            error,
            json_output=json_output,
            request_id=context.request_id,
            context=context,
        )


def model_pull_command(
    *,
    runtime: CommandRuntime,
    slug: str | None,
    asset_id: str | None,
    gateway: str | None,
    api_key: str | None,
    json_output: bool,
    debug: bool,
) -> None:
    """Pull remote metadata into local project files."""
    context = runtime.build_command_context("model.pull", debug=debug, json_output=json_output)
    try:
        if not slug and not asset_id:
            raise usage_error(
                "Provide --slug or --id",
                code="missing_model_selector",
                request_id=context.request_id,
            )
        auth_context = runtime.resolve_auth_context(gateway=gateway, api_key=api_key)
        if not auth_context.api_key:
            raise auth_error(
                "Not authenticated. Run: ai login",
                code="not_authenticated",
                request_id=context.request_id,
            )
        client = runtime.gateway_client_cls(auth_context, context)
        try:
            model_id = asset_id
            if not model_id and slug:
                model = client.get_model(slug)
                if model is None:
                    raise remote_state_error(
                        f"Model not found for slug '{slug}'",
                        code="model_not_found",
                        request_id=context.request_id,
                        http_status=404,
                    )
                model_id = model.id
            if model_id is None:
                raise remote_state_error(
                    "Model lookup did not return an asset identifier",
                    code="model_id_missing",
                    request_id=context.request_id,
                )
            detail = client.get_studio_model(model_id)
        finally:
            client.close()
        if (Path.cwd() / LEGACY_PUBLISH_CONFIG_FILE_NAME).exists():
            raise usage_error(
                "Root publish config is no longer supported: aimp.publish.toml. "
                "Remove it and run: ai publish --configure",
                code="legacy_publish_config_unsupported",
            )
        try:
            local_publish_config = load_publish_config(Path.cwd())
            article_file = (
                local_publish_config.studio.article_mdx_file or DEFAULT_STUDIO_ARTICLE_MDX_FILE
            )
        except Exception:
            article_file = DEFAULT_STUDIO_ARTICLE_MDX_FILE
        publish_config, studio_article = build_local_publish_metadata(
            detail.model_dump(),
            article_file=article_file,
        )
        article_relative = publish_config.studio.article_mdx_file or article_file
        article_path = Path.cwd() / article_relative
        article_path.parent.mkdir(parents=True, exist_ok=True)
        publish_config_path = Path.cwd() / PUBLISH_CONFIG_RELATIVE_PATH
        publish_config_path.parent.mkdir(parents=True, exist_ok=True)
        article_path.write_text(studio_article, encoding="utf-8")
        publish_config_path.write_text(
            serialize_publish_config_toml(publish_config),
            encoding="utf-8",
        )
        runtime.emit_result(
            {
                "model_id": detail.id,
                "slug": detail.slug,
                "article_mdx_file": str(article_path.relative_to(Path.cwd())),
                "publish_config_file": PUBLISH_CONFIG_FILE_NAME,
                "request_id": context.request_id,
            },
            json_output=json_output,
            success_message=(
                f"Model ID: {detail.id}\n"
                f"Wrote: {article_path.relative_to(Path.cwd())}\n"
                f"Wrote: {PUBLISH_CONFIG_FILE_NAME}"
            ),
            title="PULL",
        )
    except Exception as error:
        exit_with_error(
            error,
            json_output=json_output,
            request_id=context.request_id,
            context=context,
        )
