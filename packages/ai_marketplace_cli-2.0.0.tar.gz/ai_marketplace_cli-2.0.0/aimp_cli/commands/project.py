"""Project command handlers."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import typer

from aimp_cli.commands.common import CommandRuntime, exit_with_error
from aimp_cli.core.errors import usage_error
from aimp_cli.operations.scaffold.init_project import create_project_scaffold


def prompt_project_name(*, runtime: CommandRuntime) -> str:
    runtime.require_tty()
    name = runtime.prompt_text(
        "Project name",
        console=runtime.console,
        show_header=False,
        title="Create Project",
        subtitle="Choose the directory name for the new unified project.",
    )
    if name is None:
        raise typer.Exit(code=0)
    return name.strip()


def init_command(
    *,
    runtime: CommandRuntime,
    name: str | None,
    yes: bool,
    json_output: bool,
    debug: bool,
    prompt_project_name_fn: Any,
) -> None:
    context = runtime.build_command_context("init", debug=debug, json_output=json_output)
    try:
        resolved_name = (name or "").strip()
        if not resolved_name:
            resolved_name = prompt_project_name_fn()
        if not resolved_name:
            raise usage_error(
                "Project name is required",
                code="project_name_required",
                request_id=context.request_id,
            )
        if Path(resolved_name).resolve().exists():
            raise usage_error(
                f'Directory "{resolved_name}" already exists',
                code="validation_error",
                request_id=context.request_id,
            )
        if not yes:
            runtime.require_tty()
            if not runtime.confirm_action(
                f"Create project '{resolved_name}'?",
                console=runtime.console,
                default=True,
                confirm_label="Create Project",
                cancel_label="Cancel",
                confirm_description="Scaffold the unified framework and platform project.",
                cancel_description="Exit without creating a project.",
                show_header=False,
                title="Confirm Project Creation",
            ):
                raise typer.Exit(code=0)
        project_dir = create_project_scaffold(resolved_name)
        runtime.emit_result(
            {
                "project_dir": str(project_dir),
                "entrypoint": "agent.py",
                "next_steps": [f"cd {project_dir.name}", "uv sync", "ai publish --configure", "ai push"],
                "request_id": context.request_id,
            },
            json_output=json_output,
            success_message=(
                f"Project created: {project_dir}\n\n"
                "Next steps:\n"
                f"  cd {project_dir.name}\n"
                "  uv sync\n"
                "  ai publish --configure\n"
                "  ai push"
            ),
            title="INIT",
        )
    except typer.Exit:
        raise
    except Exception as error:
        exit_with_error(
            error,
            json_output=json_output,
            request_id=context.request_id,
            context=context,
        )
