"""Fine-tune command handlers."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from aimp_cli.core.errors import (
    CliError,
    auth_error,
    environment_error,
    remote_state_error,
    usage_error,
)
from aimp_cli.core.launcher import confirm_action
from aimp_cli.domain.discovery import find_project_root
from aimp_cli.operations.scaffold.renderers import create_consumer_tuning_scaffold
from aimp_cli.utils.execution_stream import ExecutionStreamCallbacks, watch_execution_stream

from .common import CommandRuntime, exit_with_error

_ACTIVE_JOB_STATUSES = {"queued", "running"}


def _build_fine_tune_status_message(execution: dict[str, Any], job_id: str) -> str:
    """Build the live fine-tune status line for one execution payload."""
    model_slug = str(execution.get("model_slug") or execution.get("slug") or "").strip()
    status = str(execution.get("status") or "unknown").strip()
    summary = f"Fine-tune: {status}"
    if model_slug:
        summary += f" · {model_slug}"
    summary += f" · job {job_id[:8]}"
    return summary


def _render_fine_tune_log_items(*, runtime: CommandRuntime, items: list[dict[str, Any]]) -> None:
    """Render streamed fine-tune log entries using the same style as publish-build."""
    for log_entry in items:
        log_level = log_entry.get("level", "info")
        message = str(log_entry.get("message") or "")
        if log_level == "error":
            runtime.console.print(f"[red]✗ {message}[/red]", soft_wrap=True)
        elif log_level == "warning":
            runtime.console.print(f"[yellow]⚠ {message}[/yellow]", soft_wrap=True)
        else:
            runtime.console.print(f"[dim]  {message}[/dim]", soft_wrap=True)


def _find_active_fine_tune_job(*, client: Any, model_slug: str) -> dict[str, Any] | None:
    """Return one active fine-tune job payload for the target model when present."""
    payload = client.list_fine_tune_jobs(model_slug=model_slug, page_size=100)
    for job in payload.results:
        if job.status in _ACTIVE_JOB_STATUSES:
            return job.model_dump()
    return None


def _extract_active_fine_tune_job_from_error(error: CliError) -> dict[str, Any] | None:
    """Extract one existing fine-tune job payload from a structured conflict error."""
    if error.code != "active_job_exists":
        return None
    if not isinstance(error.extra, dict):
        return None
    if error.extra.get("job_type") != "fine-tune":
        return None
    existing_job = error.extra.get("existing_job")
    return existing_job if isinstance(existing_job, dict) else None


def _build_active_fine_tune_error(
    *,
    model_slug: str,
    existing_job: dict[str, Any],
    request_id: str,
) -> CliError:
    """Build a stable CLI conflict error for an existing active fine-tune job."""
    job_id = str(existing_job.get("job_id") or "").strip() or "unknown"
    status = str(existing_job.get("status") or "queued").strip() or "queued"
    return remote_state_error(
        (f"Active fine-tune job already exists for model '{model_slug}' ({job_id}, {status})."),
        code="active_job_exists",
        request_id=request_id,
        hint=(
            f"Run `ai fine-tune create --model {model_slug} --force`"
            " to cancel the active job and start a new one."
        ),
        http_status=409,
        extra={
            "job_type": "fine-tune",
            "model_slug": model_slug,
            "existing_job": existing_job,
        },
    )


def fine_tune_schema_command(
    *,
    runtime: CommandRuntime,
    model: str | None,
    gateway: str | None,
    api_key: str | None,
    json_output: bool,
    debug: bool,
    load_local_tuning_contract: Any,
) -> None:
    """Show the fine-tune schema for a local or published model."""
    context = runtime.build_command_context(
        "fine_tune.schema",
        debug=debug,
        json_output=json_output,
    )
    try:
        if model:
            auth_context = runtime.resolve_auth_context(gateway=gateway, api_key=api_key)
            if not auth_context.api_key:
                raise auth_error(
                    "Not authenticated. Run: ai login",
                    code="not_authenticated",
                    request_id=context.request_id,
                )
            client = runtime.gateway_client_cls(auth_context, context)
            try:
                detail = client.get_marketplace_model_detail(model)
            finally:
                client.close()
            schema_contract = detail.get("tuning_schema")
            if not isinstance(schema_contract, dict):
                raise remote_state_error(
                    f"Model '{model}' does not expose a fine-tune schema",
                    code="fine_tune_schema_missing",
                    request_id=context.request_id,
                    http_status=404,
                )
            payload = {
                "model": model,
                "schema": schema_contract,
                "request_id": context.request_id,
            }
        else:
            project_dir = find_project_root(Path.cwd())
            payload = {
                "project_root": str(project_dir),
                "schema": load_local_tuning_contract(project_dir)["schema"],
                "request_id": context.request_id,
            }
        runtime.emit_result(
            payload,
            json_output=json_output,
            success_message=(
                "Fine-tune schema fields: "
                + ", ".join(
                    str(field.get("key") or "").strip()
                    for field in payload["schema"].get("fields", [])
                    if isinstance(field, dict) and str(field.get("key") or "").strip()
                )
            ),
            title="FINE-TUNE SCHEMA",
        )
    except Exception as error:
        exit_with_error(
            error,
            json_output=json_output,
            request_id=context.request_id,
            context=context,
        )


def fine_tune_scaffold_command(
    *,
    runtime: CommandRuntime,
    model: str,
    output: Path | None,
    regenerate: bool,
    gateway: str | None,
    api_key: str | None,
    json_output: bool,
    debug: bool,
    default_fine_tune_scaffold_output_dir: Any,
) -> None:
    """Generate a consumer-facing fine-tune scaffold from a published schema.

    Args:
        regenerate: If True, only update .tuning/ folder, preserve user edits.
    """
    context = runtime.build_command_context(
        "fine_tune.scaffold",
        debug=debug,
        json_output=json_output,
    )
    try:
        auth_context = runtime.resolve_auth_context(gateway=gateway, api_key=api_key)
        if not auth_context.api_key:
            raise auth_error(
                "Not authenticated. Run: ai login",
                code="not_authenticated",
                request_id=context.request_id,
            )
        client = runtime.gateway_client_cls(auth_context, context)
        try:
            detail = client.get_marketplace_model_detail(model)
        finally:
            client.close()
        if not bool(detail.get("tuning_supported", False)):
            raise remote_state_error(
                f"Model '{model}' does not support fine-tune",
                code="fine_tune_not_supported",
                request_id=context.request_id,
                http_status=400,
            )
        schema_contract = detail.get("tuning_schema")
        if not isinstance(schema_contract, dict):
            raise remote_state_error(
                f"Model '{model}' does not expose a fine-tune schema",
                code="fine_tune_schema_missing",
                request_id=context.request_id,
                http_status=400,
            )
        output_dir = (
            output.expanduser().resolve()
            if output
            else default_fine_tune_scaffold_output_dir(model)
        )

        if regenerate:
            from aimp_cli.operations.scaffold.renderers import regenerate_tuning_scaffold

            files = regenerate_tuning_scaffold(
                output_dir,
                model_slug=model,
                schema_contract=schema_contract,
            )
            success_msg = (
                f"Regenerated .tuning/ for {model}\n"
                f"Your prepare_bundle.py edits preserved.\n"
                f"Output: {output_dir}"
            )
        else:
            files = create_consumer_tuning_scaffold(
                output_dir,
                model_slug=model,
                schema_contract=schema_contract,
            )
            success_msg = (
                f"Scaffolded: {output_dir}\n"
                f"Edit prepare_bundle.py, then run:\n"
                f"  python prepare_bundle.py\n"
                f"  ai fine-tune create --model {model} --output-dir {output_dir}"
            )

        payload = {
            "model": model,
            "output_dir": str(output_dir),
            "files": files,
            "regenerated": regenerate,
            "request_id": context.request_id,
        }
        runtime.emit_result(
            payload,
            json_output=json_output,
            success_message=success_msg,
            title="FINE-TUNE SCAFFOLD",
        )
    except Exception as error:
        exit_with_error(
            error,
            json_output=json_output,
            request_id=context.request_id,
            context=context,
        )


def fine_tune_create_command(
    *,
    runtime: CommandRuntime,
    model: str,
    bundle: Path | None,
    workspace: Path | None,
    output_dir: Path | None,
    max_trials: int,
    force: bool = False,
    gateway: str | None,
    api_key: str | None,
    json_output: bool,
    debug: bool,
    resolve_fine_tune_output_dir: Any,
    resolve_fine_tune_bundle_path: Any,
    create_tuning_bundle_archive: Any,
    render_fine_tune_job: Any,
) -> None:
    """Create a new fine-tune job for a published model."""
    context = runtime.build_command_context(
        "fine_tune.create",
        debug=debug,
        json_output=json_output,
    )
    try:
        if bundle is not None and (workspace is not None or output_dir is not None):
            raise usage_error(
                "Use either --bundle or one workspace/output directory source",
                code="invalid_dataset_source",
                request_id=context.request_id,
            )

        auth_context = runtime.resolve_auth_context(gateway=gateway, api_key=api_key)
        if not auth_context.api_key:
            raise auth_error(
                "Not authenticated. Run: ai login",
                code="not_authenticated",
                request_id=context.request_id,
            )

        client = runtime.gateway_client_cls(auth_context, context)
        try:
            detail = client.get_marketplace_model_detail(model)
            if not bool(detail.get("tuning_supported", False)):
                raise remote_state_error(
                    f"Model '{model}' does not support fine-tune",
                    code="fine_tune_not_supported",
                    request_id=context.request_id,
                    http_status=400,
                )
            if str(detail.get("tuning_output_kind") or "").strip().lower() != "lora":
                raise remote_state_error(
                    f"Model '{model}' must expose LoRA fine-tune output in V1",
                    code="fine_tune_output_invalid",
                    request_id=context.request_id,
                    http_status=400,
                )
            schema_contract = detail.get("tuning_schema")
            if not isinstance(schema_contract, dict):
                raise remote_state_error(
                    f"Model '{model}' does not expose a fine-tune schema",
                    code="fine_tune_schema_missing",
                    request_id=context.request_id,
                    http_status=400,
                )
            resolved_output_dir = resolve_fine_tune_output_dir(
                model_slug=model,
                workspace=workspace,
                output_dir=output_dir,
            )
            if bundle is not None:
                bundle_path = resolve_fine_tune_bundle_path(bundle=bundle)
            else:
                bundle_path = resolved_output_dir / "bundle.json"
                workspace_exists = resolved_output_dir.exists()
                workspace_has_files = workspace_exists and any(resolved_output_dir.iterdir())
                if not workspace_has_files:
                    files = create_consumer_tuning_scaffold(
                        resolved_output_dir,
                        model_slug=model,
                        schema_contract=schema_contract,
                    )
                    payload = {
                        "model": model,
                        "job_created": False,
                        "output_dir": str(resolved_output_dir),
                        "files": files,
                        "next_step": (
                            f"Run `python prepare_bundle.py` in {resolved_output_dir} "
                            f"to generate {bundle_path.name}, then rerun: "
                            f"ai fine-tune create --model {model} "
                            f"--output-dir {resolved_output_dir}"
                        ),
                        "request_id": context.request_id,
                    }
                    runtime.emit_result(
                        payload,
                        json_output=json_output,
                        success_message=(
                            f"Scaffolded: {resolved_output_dir}\n"
                            "Next:\n"
                            "  python prepare_bundle.py\n"
                            f"  ai fine-tune create --model {model} --output-dir {resolved_output_dir}"
                        ),
                        title="FINE-TUNE CREATE",
                    )
                    return
                if not bundle_path.exists() or not bundle_path.is_file():
                    raise usage_error(
                        f"Fine-tune bundle not found at {bundle_path}. "
                        f"Run `python prepare_bundle.py` in {resolved_output_dir} first.",
                        code="dataset_not_found",
                        request_id=context.request_id,
                    )
            temp_bundle, content_type = create_tuning_bundle_archive(
                schema_contract=schema_contract,
                bundle_path=bundle_path,
            )
            existing_job = _find_active_fine_tune_job(client=client, model_slug=model)
            if existing_job is not None:
                if not json_output:
                    render_fine_tune_job(existing_job)
                if not force:
                    raise _build_active_fine_tune_error(
                        model_slug=model,
                        existing_job=existing_job,
                        request_id=context.request_id,
                    )
                job_id = str(existing_job.get("job_id") or "").strip()
                job_status = str(existing_job.get("status") or "queued").strip()
                created_at = str(existing_job.get("created_at") or "").strip()
                subtitle = f"Job {job_id[:8]} is {job_status}"
                if created_at:
                    subtitle += f" · Created {created_at}"
                confirmed = confirm_action(
                    f"Cancel the active fine-tune for '{model}' and start a new one?",
                    console=runtime.console,
                    confirm_label="Cancel old job",
                    cancel_label="Keep existing job",
                    confirm_description="Cancel the active fine-tune and start a fresh one.",
                    cancel_description="Keep the current fine-tune and exit.",
                    title="Active Fine-tune Conflict",
                    subtitle=subtitle,
                )
                if not confirmed:
                    raise usage_error(
                        f"Fine-tune canceled. Active job {job_id[:8]} is still {job_status}.",
                        code="fine_tune_canceled_by_user",
                        request_id=context.request_id,
                    )
                client.cancel_fine_tune_job(job_id=job_id)
            upload_client = runtime.upload_client_cls(client)
            upload_version = f"0.0.0-{context.request_id[:12]}"
            try:
                upload_result = upload_client.upload_file(
                    file_path=Path(temp_bundle.name),
                    slug=model,
                    version=upload_version,
                    artifact_type="fine_tune_dataset",
                    content_type=content_type,
                    metadata={
                        "purpose": "fine_tune_dataset",
                        "bundle_format": "aimp_tuning_bundle_v1",
                    },
                    concurrency=1,
                    on_progress=None,
                )
            finally:
                Path(temp_bundle.name).unlink(missing_ok=True)
            try:
                job = client.create_fine_tune_job(
                    model_slug=model,
                    dataset_ref=upload_result.storage_uri,
                    budget={"max_trials": max_trials},
                )
            except CliError as error:
                existing_job = _extract_active_fine_tune_job_from_error(error)
                if existing_job is None:
                    raise
                if not json_output:
                    render_fine_tune_job(existing_job)
                if force:
                    job_id = str(existing_job.get("job_id") or "").strip()
                    client.cancel_fine_tune_job(job_id=job_id)
                    raise usage_error(
                        f"Fine-tune {job_id[:8]} canceled."
                        " Run `ai fine-tune create --force` again to start a new one.",
                        code="fine_tune_force_retry",
                        request_id=context.request_id,
                    ) from error
                raise _build_active_fine_tune_error(
                    model_slug=model,
                    existing_job=existing_job,
                    request_id=context.request_id,
                ) from error
            latest_execution: dict[str, Any] = {}
            if json_output:
                watch_execution_stream(
                    gateway=client,
                    job_id=job.job_id,
                    context=context,
                )
            else:
                with runtime.console.status("Fine-tune queued", spinner="line") as status:
                    watch_execution_stream(
                        gateway=client,
                        job_id=job.job_id,
                        context=context,
                        callbacks=ExecutionStreamCallbacks(
                            on_snapshot=lambda execution: (
                                latest_execution.clear(),
                                latest_execution.update(execution),
                                status.update(
                                    _build_fine_tune_status_message(execution, job.job_id)
                                ),
                            ),
                            on_status=lambda payload: status.update(
                                _build_fine_tune_status_message(
                                    {**latest_execution, "status": payload.get("status")},
                                    job.job_id,
                                )
                            ),
                            on_logs=lambda items, _payload: _render_fine_tune_log_items(
                                runtime=runtime,
                                items=items,
                            ),
                            on_terminal=lambda execution: (
                                latest_execution.clear(),
                                latest_execution.update(execution),
                                status.update(
                                    _build_fine_tune_status_message(execution, job.job_id)
                                ),
                            ),
                        ),
                    )
            job = client.get_fine_tune_job(job_id=job.job_id)
        finally:
            client.close()
        if job.status == "failed":
            raise environment_error(
                job.error_message or "Fine-tune failed",
                code=job.error_code or "fine_tune_failed",
                request_id=context.request_id,
                extra={"job_id": job.job_id},
            )
        if job.status == "canceled":
            raise remote_state_error(
                "Fine-tune canceled",
                code="fine_tune_canceled",
                request_id=context.request_id,
                extra={"job_id": job.job_id},
            )
        payload = job.model_dump()
        payload["job_created"] = True
        if bundle is None:
            payload["output_dir"] = str(resolved_output_dir)
        if json_output:
            runtime.emit_result(payload, json_output=True)
        else:
            render_fine_tune_job(payload)
    except Exception as error:
        exit_with_error(
            error,
            json_output=json_output,
            request_id=context.request_id,
            context=context,
        )


def fine_tune_list_command(
    *,
    runtime: CommandRuntime,
    model: str | None,
    status: str | None,
    page: int,
    page_size: int,
    gateway: str | None,
    api_key: str | None,
    json_output: bool,
    debug: bool,
    render_fine_tune_list: Any,
) -> None:
    """List workspace-scoped fine-tune jobs."""
    context = runtime.build_command_context("fine_tune.list", debug=debug, json_output=json_output)
    try:
        auth_context = runtime.resolve_auth_context(gateway=gateway, api_key=api_key)
        if not auth_context.api_key:
            raise auth_error(
                "Not authenticated. Run: ai login",
                code="not_authenticated",
                request_id=context.request_id,
            )
        client = runtime.gateway_client_cls(auth_context, context)
        try:
            payload = client.list_fine_tune_jobs(
                model_slug=model,
                status=status,
                page=page,
                page_size=page_size,
            )
        finally:
            client.close()
        result = payload.model_dump()
        if json_output:
            runtime.emit_result(result, json_output=True)
        else:
            render_fine_tune_list(result)
    except Exception as error:
        exit_with_error(
            error,
            json_output=json_output,
            request_id=context.request_id,
            context=context,
        )


def fine_tune_get_command(
    *,
    runtime: CommandRuntime,
    job: str,
    gateway: str | None,
    api_key: str | None,
    json_output: bool,
    debug: bool,
    render_fine_tune_job: Any,
) -> None:
    """Get a single fine-tune job."""
    context = runtime.build_command_context("fine_tune.get", debug=debug, json_output=json_output)
    try:
        auth_context = runtime.resolve_auth_context(gateway=gateway, api_key=api_key)
        if not auth_context.api_key:
            raise auth_error(
                "Not authenticated. Run: ai login",
                code="not_authenticated",
                request_id=context.request_id,
            )
        client = runtime.gateway_client_cls(auth_context, context)
        try:
            payload = client.get_fine_tune_job(job_id=job)
        finally:
            client.close()
        result = payload.model_dump()
        if json_output:
            runtime.emit_result(result, json_output=True)
        else:
            render_fine_tune_job(result)
    except Exception as error:
        exit_with_error(
            error,
            json_output=json_output,
            request_id=context.request_id,
            context=context,
        )
