from contexere.data.context import confirm_partial_rag

def test_confirm_partial_rag_match_complete():
    match, project, date, step = confirm_partial_rag('ERP26pGa')
    assert match is not None
    assert project == 'ERP'
    assert date == '26pG'
    assert step == 'a'

    match, project, date, step = confirm_partial_rag('ERP26pGa_')
    assert match is None

def test_confirm_partial_rag_match_complete_lower_case():
    match, project, date, step = confirm_partial_rag('erp26pGa')
    assert match is not None
    assert project == 'erp'
    assert date == '26pG'
    assert step == 'a'

    match, project, date, step = confirm_partial_rag('ERP26pGa_')
    assert match is None

def test_confirm_partial_rag_match_counter():
    match, project, date, step = confirm_partial_rag('a')
    assert match is not None
    assert project is None
    assert date == ''
    assert step == 'a'

    match, project, date, step = confirm_partial_rag('aa')
    assert match is None
    assert project is None
    assert date is None
    assert step is None

    match, project, date, step = confirm_partial_rag('aaa')
    assert match is None

def test_confirm_partial_date_rag_match():
    match, project, date, step = confirm_partial_rag('Ga')
    assert match is not None
    assert project is None
    assert date == 'G'
    assert step == 'a'

    match, project, date, step = confirm_partial_rag('pGa')
    assert match is not None
    assert project is None
    assert date == 'pG'
    assert step == 'a'

    match, project, date, step = confirm_partial_rag('26pGa')
    assert match is not None
    assert project is None
    assert date == '26pG'
    assert step == 'a'

    match, project, date, step = confirm_partial_rag('q5a')
    assert match is not None
    assert project is None
    assert date == 'q5'
    assert step == 'a'