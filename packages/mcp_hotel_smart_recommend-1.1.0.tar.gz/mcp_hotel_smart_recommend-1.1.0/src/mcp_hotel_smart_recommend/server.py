"""
国内酒店智能推荐 MCP Server
数据源：官方旅行商品库（FlyAI MCP API）
能力：国内酒店搜索、万豪集团酒店搜索
"""
import json
import hashlib
import hmac
import secrets
import time
import gzip
import base64
import os
import re

import httpx
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("hotel-smart-recommend")

# ============ 配置 ============
MCP_URL = "https://flyai.open.fliggy.com/mcp"
API_KEY = os.environ.get("API_KEY", "")
SIGN_SECRET = os.environ.get("SIGN_SECRET", "")
MCP_TIMEOUT = 60

# 星级中文映射
STAR_MAP = {"1": "经济型", "2": "经济型", "3": "舒适型", "4": "高档型", "5": "豪华型/五星级"}
STAR_FILTER_MAP = {
    "经济型": ["经济型"], "舒适型": ["舒适型"], "高档型": ["高档型"],
    "豪华型": ["豪华型", "五星级"], "五星级": ["豪华型", "五星级"]
}

# ============ MCP通信层 ============

def sha256_hex(data: str) -> str:
    return hashlib.sha256(data.encode("utf-8")).hexdigest()

def normalize_auth(auth: str) -> str:
    auth = (auth or "").strip()
    return f"Bearer {auth}" if auth and not auth.startswith("Bearer ") else auth

def generate_ff_ctx(sign_secret: str) -> str:
    ctx_obj = {
        "os": "linux", "arch": "x64", "nodeVersion": "v22.22.2",
        "cpuCount": os.cpu_count() or 4, "deviceMemory": 8,
        "clientSurface": "cli", "timezoneOffset": -480,
        "deviceId": secrets.token_hex(8)
    }
    ctx_json = json.dumps(ctx_obj, separators=(",", ":"))
    compressed = gzip.compress(ctx_json.encode("utf-8"))
    if sign_secret:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        aes_key = hashlib.sha256(sign_secret.encode("utf-8")).digest()
        iv = secrets.token_bytes(12)
        encrypted = AESGCM(aes_key).encrypt(iv, compressed, None)
        payload = b"\x01" + iv + encrypted
        return base64.b64encode(payload).decode("ascii")
    return base64.b64encode(compressed).decode("ascii")

def generate_sign_headers(body: str, auth: str, sign_secret: str) -> dict:
    ts = str(int(time.time() * 1000))
    nonce = secrets.token_hex(16)
    body_hash = sha256_hex(body)
    auth_hash = sha256_hex(normalize_auth(auth))
    signing_string = f"POST\n/mcp\n{ts}\n{nonce}\n{body_hash}\n{auth_hash}"
    sig = base64.urlsafe_b64encode(
        hmac.new(sign_secret.encode("utf-8"), signing_string.encode("utf-8"), hashlib.sha256).digest()
    ).rstrip(b"=").decode("ascii")
    return {
        "x-flyai-sign-ver": "7", "x-flyai-sign-alg": "hmac-sha256",
        "x-flyai-ts": ts, "x-flyai-nonce": nonce, "x-flyai-sign": sig
    }

def call_mcp(tool_name: str, arguments: dict) -> dict:
    body = json.dumps({
        "jsonrpc": "2.0", "id": 1, "method": "tools/call",
        "params": {"name": tool_name, "arguments": arguments}
    }, ensure_ascii=False, separators=(",", ":"))
    auth = f"Bearer {API_KEY}"
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/event-stream",
        "Authorization": auth,
        "x-ff-ctx": generate_ff_ctx(SIGN_SECRET),
        "x-ttid": "ai2c(sk.clawhub)",
        "User-Agent": "flyai-cli/1.0.6 (Python/3.x)"
    }
    headers.update(generate_sign_headers(body, auth, SIGN_SECRET))
    try:
        resp = httpx.post(MCP_URL, headers=headers, content=body, timeout=MCP_TIMEOUT)
        ct = resp.headers.get("content-type", "")
        if "text/event-stream" in ct:
            for line in resp.text.split("\n"):
                if line.startswith("data:"):
                    try:
                        return json.loads(line[5:].strip())
                    except json.JSONDecodeError:
                        continue
            return {"error": "SSE解析失败"}
        return resp.json()
    except httpx.TimeoutException:
        return {"error": "请求超时，请稍后重试"}
    except Exception as e:
        return {"error": f"请求异常: {str(e)}"}

def parse_mcp_result(result: dict):
    if "error" in result:
        err = result["error"]
        if isinstance(err, dict):
            code = err.get("code", 0)
            msg = err.get("message", "未知错误")
            if code == -32601:
                return {"error": f"该功能当前不可用: {msg}"}
            if code == -32600:
                return {"error": f"认证失败: {msg}"}
            return {"error": f"API错误({code}): {msg}"}
        return {"error": str(err)}
    content = result.get("result", {}).get("content", [])
    if content and content[0].get("type") == "text":
        try:
            return json.loads(content[0]["text"])
        except json.JSONDecodeError:
            return content[0]["text"]
    return result

# ============ 业务逻辑层 ============

def _do_search_hotels(dest_name: str, poi_name: str = "", check_in: str = "",
                      check_out: str = "", hotel_stars: str = "", max_price: int = 0,
                      hotel_types: str = "", sort: str = "", key_words: str = "",
                      limit: int = 10) -> dict:
    args = {"destName": dest_name, "limit": limit}
    if poi_name: args["poiName"] = poi_name
    if check_in: args["checkInDate"] = check_in
    if check_out: args["checkOutDate"] = check_out
    if hotel_stars: args["hotelStars"] = hotel_stars
    if max_price > 0: args["maxPrice"] = max_price
    if hotel_types: args["hotelTypes"] = hotel_types
    if sort: args["sort"] = sort
    if key_words: args["keyWords"] = key_words

    raw = call_mcp("search_hotels", args)
    data = parse_mcp_result(raw)
    if isinstance(data, dict) and "error" in data:
        return data

    # 客户端硬过滤
    if isinstance(data, dict) and "data" in data:
        items = data["data"].get("itemList", [])
        filtered = []
        for item in items:
            if max_price > 0:
                price_str = item.get("price", "¥0")
                try:
                    price_num = int(re.sub(r"[^\d]", "", price_str))
                    if price_num > max_price:
                        continue
                except (ValueError, TypeError):
                    pass
            if hotel_stars:
                target_stars = set()
                for s in hotel_stars.split(","):
                    s = s.strip()
                    if s in STAR_FILTER_MAP:
                        target_stars.update(STAR_FILTER_MAP[s])
                if target_stars:
                    item_star = item.get("starDesc", "")
                    if item_star not in target_stars:
                        continue
            filtered.append(item)
        data["data"]["itemList"] = filtered[:limit]
    return data

def _do_search_marriott(dest_name: str, check_in: str = "", check_out: str = "",
                        max_price: int = 0, sort: str = "", limit: int = 10) -> dict:
    args = {"destName": dest_name, "limit": limit}
    if check_in: args["checkInDate"] = check_in
    if check_out: args["checkOutDate"] = check_out
    if max_price > 0: args["maxPrice"] = max_price
    if sort: args["sort"] = sort
    raw = call_mcp("search_marriott_hotels", args)
    data = parse_mcp_result(raw)
    if isinstance(data, dict) and "data" in data and max_price > 0:
        items = data["data"].get("itemList", [])
        filtered = []
        for item in items:
            price_str = item.get("price", "¥0")
            try:
                price_num = int(re.sub(r"[^\d]", "", price_str.split("起")[0]))
                if price_num <= max_price:
                    filtered.append(item)
            except (ValueError, TypeError):
                filtered.append(item)
        data["data"]["itemList"] = filtered[:limit]
    return data

# ============ 输出格式化层 ============

def format_hotels(data: dict, desc: str = "") -> str:
    if isinstance(data, dict) and "error" in data:
        return f"搜索失败: {data['error']}"
    if not isinstance(data, dict) or "data" not in data:
        return "未获取到有效数据"
    items = data["data"].get("itemList", [])
    if not items:
        return f"未找到符合条件的酒店。{desc}建议调整筛选条件后重试。"
    lines = [f"找到 {len(items)} 家酒店{desc}：", ""]
    for i, h in enumerate(items, 1):
        name = h.get("name", "未知酒店")
        star = h.get("starDesc", "")
        price = h.get("price", "暂无报价")
        price = price if "起/晚" in price or "/晚" in price else f"{price}起/晚"
        poi = h.get("interestsPoi", "")
        addr = h.get("address", "")
        url = h.get("detailUrl") or h.get("jumpUrl", "")
        star_str = f" · {star}" if star else ""
        poi_str = f" · 近{poi}" if poi else ""
        lines.append(f"{i}. {name}{star_str}")
        lines.append(f"   💰 {price}{poi_str}")
        if addr: lines.append(f"   📍 {addr}")
        if url: lines.append(f"   🔗 [点击预订]({url})")
        lines.append("")
    sys_msg = data.get("systemMessage") or data.get("data", {}).get("systemMessage")
    if sys_msg: lines.append(f"📌 {sys_msg}")
    lines.append("\n> 数据来源：官方商品库，价格实时更新，点击链接可直接预订")
    return "\n".join(lines)

def format_marriott(data: dict, desc: str = "") -> str:
    if isinstance(data, dict) and "error" in data:
        return f"搜索失败: {data['error']}"
    if not isinstance(data, dict) or "data" not in data:
        return "未获取到有效数据"
    items = data["data"].get("itemList", [])
    if not items:
        return f"未找到符合条件的万豪酒店。{desc}建议调整筛选条件后重试。"
    lines = [f"找到 {len(items)} 家万豪集团酒店{desc}：", ""]
    for i, h in enumerate(items, 1):
        name = h.get("name", "未知酒店")
        star = h.get("star", "")
        price = h.get("price", "暂无报价")
        price = price if "起/晚" in price or "/晚" in price else f"{price}起/晚"
        brand = h.get("brandName", "")
        poi = h.get("interestsPoi", "")
        addr = h.get("address", "")
        url = h.get("detailUrl", "")
        brand_str = f" [{brand}]" if brand else ""
        star_str = f" · {star}" if star else ""
        poi_str = f" · 近{poi}" if poi else ""
        lines.append(f"{i}. {name}{brand_str}{star_str}")
        lines.append(f"   💰 {price}{poi_str}")
        if addr: lines.append(f"   📍 {addr}")
        if url: lines.append(f"   🔗 [点击预订]({url})")
        lines.append("")
    sys_msg = data.get("systemMessage") or data.get("data", {}).get("systemMessage")
    if sys_msg: lines.append(f"📌 {sys_msg}")
    lines.append("\n> 数据来源：官方商品库·万豪集团专区，价格实时更新，点击链接可直接预订")
    return "\n".join(lines)

# ============ MCP工具定义 ============

@mcp.tool()
def search_hotels(dest: str, max_price: int = 0, hotel_stars: str = "",
                  checkin: str = "", checkout: str = "", poi: str = "",
                  hotel_type: str = "", sort: str = "", keywords: str = "",
                  limit: int = 10) -> str:
    """搜索国内酒店，返回实时价格和可预订链接。支持按城市、星级、价格、附近地标等多维度筛选，酒店名称精确匹配。

    Args:
        dest: 目的地城市/区域（必填），如：深圳、上海外滩、三亚
        max_price: 最高价格/晚，如：500
        hotel_stars: 星级，如：5（豪华型）、4（高档型）、3（舒适型）
        checkin: 入住日期 YYYY-MM-DD
        checkout: 退房日期 YYYY-MM-DD
        poi: 附近景点/地标，如：外滩、长隆
        hotel_type: 酒店类型（酒店/民宿/客栈）
        sort: 排序方式：rate_desc(好评优先)/price_asc(价格升序)/price_desc(价格降序)/distance_asc(距离优先)
        keywords: 搜索关键词，如：万豪、亲子
        limit: 返回数量，默认10
    """
    if not API_KEY or not SIGN_SECRET:
        return "错误：服务接口密钥未配置，请检查环境变量设置"
    data = _do_search_hotels(dest, poi, checkin, checkout, hotel_stars, max_price,
                             hotel_type, sort, keywords, limit)
    desc = f"（{dest}"
    if max_price: desc += f"·{max_price}元内"
    if hotel_stars: desc += f"·{hotel_stars}星级"
    desc += "）"
    return format_hotels(data, desc)

@mcp.tool()
def search_marriott_hotels(dest: str, max_price: int = 0,
                           checkin: str = "", checkout: str = "",
                           sort: str = "", limit: int = 10) -> str:
    """搜索万豪集团旗下酒店（万豪/喜来登/JW/威斯汀/丽思卡尔顿/万丽/万枫等），返回实时价格和可预订链接。

    Args:
        dest: 目的地城市/区域（必填），如：深圳、上海、三亚
        max_price: 最高价格/晚，如：1000
        checkin: 入住日期 YYYY-MM-DD
        checkout: 退房日期 YYYY-MM-DD
        sort: 排序方式：rate_desc/price_asc/price_desc/distance_asc
        limit: 返回数量，默认10
    """
    if not API_KEY or not SIGN_SECRET:
        return "错误：服务接口密钥未配置，请检查环境变量设置"
    data = _do_search_marriott(dest, checkin, checkout, max_price, sort, limit)
    desc = f"（{dest}·万豪集团"
    if max_price: desc += f"·{max_price}元内"
    desc += "）"
    return format_marriott(data, desc)

def main():
    mcp.run()

if __name__ == "__main__":
    main()
