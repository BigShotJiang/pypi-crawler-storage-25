# 国内酒店智能推荐 MCP Server

这是一个专注国内酒店的智能推荐MCP服务，为AI助手、旅行智能体及Cursor/Cherry Studio/Windsurf等IDE提供覆盖全国范围的酒店实时检索与推荐能力，满足各类国内酒店查询需求，并返回最优价格与可直接预订的链接。该服务支持通过城市名称、热门景点、地标商圈、酒店名称等多种目标地点进行精准搜索，并提供灵活的星级筛选、价格区间设置、入住退房日期配置、距离排序等专业筛选功能。此外，服务内置万豪/喜来登/JW/威斯汀/丽思卡尔顿/万丽/万枫等国际品牌专区，支持按品牌一键筛选，返回酒店实时价格、星级评定、周边地标及预订链接等结构化数据。整个服务通过标准MCP协议交互，智能完成从地点解析、酒店筛选、价格比较到预订链接生成的完整服务流程，为旅行智能体搭建、AI编程助手集成及对话式旅行应用提供精准、高效的国内酒店检索解决方案。

## 工具列表

### search_hotels - 国内酒店搜索

搜索国内酒店，返回实时价格和可预订链接。支持按城市、星级、价格、附近地标等多维度筛选，酒店名称精确匹配。

参数：
- `dest`（必填）：目的地城市/区域，如"深圳""上海外滩""三亚"
- `max_price`：最高价格/晚，如：500
- `hotel_stars`：星级，如：5（豪华型）、4（高档型）、3（舒适型）
- `checkin`：入住日期 YYYY-MM-DD
- `checkout`：退房日期 YYYY-MM-DD
- `poi`：附近景点/地标，如：外滩、长隆
- `hotel_type`：酒店类型（酒店/民宿/客栈）
- `sort`：排序（rate_desc/price_asc/price_desc/distance_asc）
- `keywords`：搜索关键词，如：万豪、亲子
- `limit`：返回数量，默认10

### search_marriott_hotels - 万豪集团酒店搜索

搜索万豪集团旗下酒店（万豪/喜来登/JW/威斯汀/丽思卡尔顿/万丽/万枫等），返回实时价格和可预订链接。

参数：
- `dest`（必填）：目的地城市/区域
- `max_price`：最高价格/晚
- `checkin`：入住日期 YYYY-MM-DD
- `checkout`：退房日期 YYYY-MM-DD
- `sort`：排序方式
- `limit`：返回数量，默认10

## 安装

```bash
pip install mcp-hotel-smart-recommend
```

或使用 uvx 直接运行：

```bash
uvx mcp-hotel-smart-recommend
```

## 配置

支持以下环境变量（托管部署时由平台自动配置，无需手动设置）：

| 变量名 | 说明 | 是否必填 |
|--------|------|---------|
| API_KEY | 服务接口密钥 | 选填 |
| SIGN_SECRET | 服务签名密钥 | 选填 |

### 在 MCP 客户端中配置

```json
{
  "mcpServers": {
    "hotel-smart-recommend": {
      "command": "uvx",
      "args": ["mcp-hotel-smart-recommend"],
      "env": {}
    }
  }
}
```

## 适用场景

- **AI编程助手**：在Cursor/Windsurf中直接调用酒店搜索，为旅行规划项目提供数据
- **旅行智能体**：给旅行AI Agent接入酒店能力，实现"查酒店→比价→给链接"闭环
- **对话式旅行应用**：低延迟响应，适配实时对话场景

## 技术特性

- 基于MCP（Model Context Protocol）标准
- 客户端星级硬过滤，确保结果精确
- 价格二次校验，避免超出预算
- 结构化JSON返回，易于Agent解析
- SSE流式响应支持

## License

MIT
