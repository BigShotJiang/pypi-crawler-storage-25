import logging
import os
import re

from dagz.integ.db_config import DbConfig, TruncateResult

logger = logging.getLogger('dagz.cassandra')

SYSTEM_KEYSPACES = frozenset({
    'system', 'system_schema', 'system_auth',
    'system_distributed', 'system_traces',
    'system_virtual_schema', 'system_views',
})


def _retryable_truncate_errors():
    from cassandra import ReadFailure, WriteTimeout
    from cassandra.cluster import NoHostAvailable
    return (NoHostAvailable, ReadFailure, WriteTimeout)


_CQL_IDENT_RE = re.compile(r'^[a-zA-Z_][a-zA-Z0-9_]*$')


def _quote_ident(name: str) -> str:
    """Quote a CQL identifier, validating it contains no injection characters."""
    if not _CQL_IDENT_RE.match(name):
        raise ValueError(f"Invalid CQL identifier: {name!r}")
    return f'"{name}"'


class CassandraConfig(DbConfig):
    def __init__(self):
        super().__init__(__name__)
        self._orig_connect = None

    def default_should_reroute(self, keyspace):
        return keyspace is not None and keyspace not in SYSTEM_KEYSPACES

    def truncate(self, keyspace, **connect_kwargs) -> TruncateResult:
        from cassandra.cluster import Cluster
        from cassandra.query import SimpleStatement
        try:
            from cassandra.concurrent import execute_concurrent
        except ImportError:
            execute_concurrent = None

        cluster = Cluster(**connect_kwargs)
        try:
            session = cluster.connect()
            rows = session.execute(
                "SELECT table_name FROM system_schema.tables WHERE keyspace_name = %s",
                [keyspace],
            )
            tables = [row.table_name for row in rows]
            if tables:
                logger.info(f"Truncating keyspace `{keyspace}`: {len(tables)} tables")
                statements = [SimpleStatement(f"TRUNCATE {_quote_ident(keyspace)}.{_quote_ident(t)}") for t in tables]
                if execute_concurrent and len(statements) > 1:
                    execute_concurrent(session, [(stmt, []) for stmt in statements], concurrency=10)
                else:
                    for stmt in statements:
                        session.execute(stmt)
            return TruncateResult(db_exists=True, tables=tables)
        finally:
            cluster.shutdown()

    def install_hooks(self, session):
        try:
            from cassandra.cluster import Cluster  # type: ignore[import-not-found]
        except ImportError:
            return None

        self._orig_connect = Cluster.connect
        _orig_connect = self._orig_connect
        _config = self

        def _patched_connect(self, keyspace=None, wait_for_all_pools=True):
            if _config.should_reroute(keyspace):
                keyspace = _config.reroute_db(keyspace)
            return _orig_connect(self, keyspace, wait_for_all_pools)

        Cluster.connect = _patched_connect
        return self.unhook

    def unhook(self):
        if not self._orig_connect:
            return
        from cassandra.cluster import Cluster
        Cluster.connect = self._orig_connect
        self._orig_connect = None

    @staticmethod
    def truncate_session(session, keyspace, retries=5):
        """Truncate every table in `keyspace` using an existing connected session.

        Unlike `truncate()`, this does not open a new Cluster; it reuses the
        session the caller has already wired up (e.g. cqlengine's). Retries on
        transient cluster errors (NoHostAvailable / ReadFailure / WriteTimeout).
        Skips the SELECT COUNT(*) check — TRUNCATE on an empty table is cheap,
        and the COUNT round trips dominate at high test cadence.
        """
        import random
        import time
        from cassandra.concurrent import execute_concurrent
        retryable = _retryable_truncate_errors()

        def _do_truncate():
            rows = session.execute(
                "SELECT table_name FROM system_schema.tables WHERE keyspace_name = %s",
                [keyspace],
            )
            tables = [row["table_name"] if isinstance(row, dict) else row.table_name for row in rows]
            if not tables:
                return
            stmts = [
                (session.prepare(f"TRUNCATE {_quote_ident(keyspace)}.{_quote_ident(t)}"), ())
                for t in tables
            ]
            execute_concurrent(session, stmts, concurrency=10)

        for attempt in range(1, retries + 1):
            try:
                _do_truncate()
                return
            except retryable:
                if attempt == retries:
                    raise
                delay = attempt + random.random()
                logger.warning(
                    "truncate_session attempt %d/%d failed, retrying in %.1fs",
                    attempt, retries, delay,
                )
                time.sleep(delay)

    # -- Cassandra-specific helpers for use in conftest.py --

    @staticmethod
    def get_auth_provider(django_settings):
        """Build a PlainTextAuthProvider from Django settings, or None."""
        username = getattr(django_settings, 'CASSANDRA_USERNAME', None)
        password = getattr(django_settings, 'CASSANDRA_PASSWORD', None)
        if username and password:
            from cassandra.auth import PlainTextAuthProvider  # type: ignore[import-not-found]
            return PlainTextAuthProvider(username=username, password=password)
        return None

    def rewrite_keyspace_settings(self, django_settings):
        """Append the active worker suffix to per-test CASSANDRA*KEYSPACE*
        settings in Django.

        Skips system keyspaces (system_auth, etc.) so auth/replication settings
        keep working. Also rewrites the keys of any CASSANDRA*REPLICATION_MAP*
        dict so projects that look up replication by keyspace name keep working.
        """
        suffix = self._session.worker_suffix
        rename_map = {}
        keyspace_attrs = []
        replication_map_attrs = []
        for attr in dir(django_settings):
            if 'CASSANDRA' not in attr:
                continue
            if 'KEYSPACE' in attr:
                keyspace_attrs.append(attr)
            elif 'REPLICATION_MAP' in attr:
                replication_map_attrs.append(attr)

        def _renamed(value):
            if value in SYSTEM_KEYSPACES:
                return value
            new = value + suffix
            rename_map[value] = new
            return new

        for attr in keyspace_attrs:
            val = getattr(django_settings, attr)
            if isinstance(val, str):
                new_val = _renamed(val)
                if new_val != val:
                    setattr(django_settings, attr, new_val)
                    logger.info(f'Rewrote {attr}: {val} -> {new_val}')
            elif isinstance(val, (set, frozenset)):
                new_val = {_renamed(v) for v in val}
                setattr(django_settings, attr, new_val)
                logger.info(f'Rewrote {attr}: {val} -> {new_val}')

        for attr in replication_map_attrs:
            val = getattr(django_settings, attr)
            if isinstance(val, dict):
                new_val = {rename_map.get(k, k): v for k, v in val.items()}
                setattr(django_settings, attr, new_val)
                logger.info(f'Rewrote keys in {attr}')

    @staticmethod
    def ensure_keyspace(cql_session, keyspace, replication=None):
        """Create a keyspace if it doesn't exist."""
        if replication is None:
            replication = {'class': 'SimpleStrategy', 'replication_factor': 1}
        repl_str = ', '.join(f"'{k}': '{v}'" for k, v in replication.items())
        cql_session.execute(
            f"CREATE KEYSPACE IF NOT EXISTS {_quote_ident(keyspace)} WITH replication = {{{repl_str}}}"
        )
        logger.info(f'Ensured keyspace {keyspace}')

    @staticmethod
    def keyspace_has_tables(cql_session, keyspace):
        rows = cql_session.execute(
            "SELECT table_name FROM system_schema.tables WHERE keyspace_name = %s",
            [keyspace],
        )
        return len(list(rows)) > 0

    @staticmethod
    def full_sync(keyspace):
        """Sync all cqlengine models to the keyspace."""
        from cassandra.cqlengine import management  # type: ignore[import-not-found]
        for model in CassandraConfig.discover_models():
            management.sync_table(model, keyspaces=[keyspace])
        logger.info(f'Full sync complete for keyspace {keyspace}')

    @staticmethod
    def register_udts(keyspace):
        """Register UDTs for all cqlengine models in the keyspace."""
        from cassandra.cqlengine import columns as cql_columns  # type: ignore[import-not-found]
        from cassandra.cqlengine import usertype  # type: ignore[import-not-found]

        for model in CassandraConfig.discover_models():
            for col in model._columns.values():
                udts = {}
                cql_columns.resolve_udts(col, udts)
                for udt in udts.values():
                    usertype.register_for_keyspace(keyspace, udt)
        logger.info(f'Registered UDTs for keyspace {keyspace}')

    @staticmethod
    def discover_models():
        """Recursively find all non-abstract cqlengine Model subclasses."""
        from cassandra.cqlengine import models  # type: ignore[import-not-found]
        result = []
        queue = list(models.Model.__subclasses__())
        while queue:
            cls = queue.pop()
            queue.extend(cls.__subclasses__())
            if getattr(cls, '__abstract__', False):
                continue
            result.append(cls)
        return result


CASSANDRA_CONFIG = CassandraConfig()


def patch_cassandra_forking():
    try:
        from cassandra.cluster import _clusters_for_shutdown, _shutdown_clusters  # type: ignore[import-not-found]
    except ImportError:
        return

    def _before_fork():
        _shutdown_clusters()

    def _after_fork_child():
        _clusters_for_shutdown.clear()
        try:
            from cassandra.cqlengine.connection import _connections  # type: ignore[import-not-found]
            for conn in _connections.values():
                conn.cluster = None
                conn.session = None
        except ImportError:
            pass

    os.register_at_fork(before=_before_fork, after_in_child=_after_fork_child)
