"""Allow running as: python -m subsplease_dl"""

from .cli import main

if __name__ == "__main__":
    main()
