"""Tmux session management for background anime downloads."""

from __future__ import annotations

import re
import shutil
from pathlib import Path
from typing import Optional

from .api import Release
from .downloader import DownloadError, build_download_cmd

SESSION_PREFIX = "spdl"
_MAX_NAME_LEN = 30


def _slug(text: str) -> str:
    """Convert a show title into a safe tmux session name segment."""
    text = text.lower()
    text = re.sub(r"[^a-z0-9]+", "-", text)
    text = text.strip("-")
    return text[:_MAX_NAME_LEN]


def _session_name(show: str, episode: str) -> str:
    return f"{SESSION_PREFIX}-{_slug(show)}-ep{_slug(episode)}"


def _require_tmux() -> None:
    if not shutil.which("tmux"):
        raise RuntimeError(
            "tmux is not installed.\n"
            "  Ubuntu/Debian:  apt install tmux\n"
            "  macOS:          brew install tmux"
        )


def _require_libtmux():
    try:
        import libtmux  # noqa: F401
    except ImportError:
        raise RuntimeError(
            "libtmux is not installed. Run: pip install libtmux"
        )


def _get_server():
    import libtmux

    return libtmux.Server()


def session_exists(name: str) -> bool:
    """Return True if a tmux session with this name is running."""
    _require_tmux()
    _require_libtmux()
    server = _get_server()
    try:
        return server.sessions.get(session_name=name) is not None
    except Exception:
        return False


def list_sessions() -> list[dict]:
    """List all active subsplease-dl tmux sessions."""
    _require_tmux()
    _require_libtmux()
    server = _get_server()
    results = []
    try:
        for s in server.sessions:
            if s.name.startswith(SESSION_PREFIX + "-"):
                results.append(
                    {
                        "name": s.name,
                        "windows": len(s.windows),
                        "created": s.get("session_created", ""),
                    }
                )
    except Exception:
        pass
    return results


def kill_session(name: str) -> bool:
    """Kill a named tmux session. Returns True if it existed."""
    _require_tmux()
    _require_libtmux()
    server = _get_server()
    try:
        s = server.sessions.get(session_name=name)
        if s:
            s.kill()
            return True
    except Exception:
        pass
    return False


def attach_session(name: str) -> None:
    """Attach to an existing tmux session (replaces current process)."""
    import os

    _require_tmux()
    os.execvp("tmux", ["tmux", "attach-session", "-t", name])


def spawn_download(
    release: Release,
    quality: str = "1080",
    output_dir: Optional[Path] = None,
    client: Optional[str] = None,
    extra_args: Optional[list[str]] = None,
    attach: bool = False,
) -> str:
    """
    Spawn a new detached tmux session that downloads the given release.

    Returns the tmux session name.
    Raises DownloadError if no magnet is available.
    Raises RuntimeError if tmux or libtmux are missing.
    """
    _require_tmux()
    _require_libtmux()

    magnet = release.get_magnet(quality)
    if not magnet:
        raise DownloadError(
            f"No {quality}p download available for "
            f'"{release.show}" episode {release.episode}. '
            f"Available: {', '.join(release.available_qualities) or 'none'}"
        )

    output_dir = output_dir or Path.cwd()
    output_dir.mkdir(parents=True, exist_ok=True)

    try:
        cmd_list = build_download_cmd(
            magnet, output_dir, client=client, extra_args=extra_args
        )
    except DownloadError:
        raise

    session_name = _session_name(release.show, release.episode)

    import libtmux

    server = libtmux.Server()
    cmd_str = " ".join(_shell_quote(c) for c in cmd_list)

    # Kill stale session with the same name if it exists
    try:
        old = server.sessions.get(session_name=session_name)
        if old:
            old.kill()
    except Exception:
        pass

    session = server.new_session(
        session_name=session_name,
        start_directory=str(output_dir),
        detach=not attach,
    )
    window = session.active_window
    pane = window.active_pane
    pane.send_keys(cmd_str)

    return session_name


def spawn_watch(
    show_title: str,
    quality: str = "1080",
    output_dir: Optional[Path] = None,
    client: Optional[str] = None,
    poll_interval: int = 300,
) -> str:
    """
    Spawn a long-running tmux session that polls for new episodes of a show
    and downloads them automatically.

    Returns the tmux session name.
    """
    _require_tmux()
    _require_libtmux()

    import sys

    session_name = f"{SESSION_PREFIX}-watch-{_slug(show_title)}"
    output_dir = output_dir or Path.cwd()
    output_dir.mkdir(parents=True, exist_ok=True)

    out_arg = str(output_dir)
    client_arg = f"--client {client}" if client else ""
    interval_arg = str(poll_interval)
    quality_arg = quality

    # Build the watch command using the CLI's --watch flag via subprocess
    python_exe = sys.executable
    watch_cmd = (
        f"{python_exe} -m subsplease_dl watch "
        f'"{show_title}" '
        f"--quality {quality_arg} "
        f"--output {out_arg} "
        f"--interval {interval_arg} "
        + (f"--client {client}" if client else "")
    ).strip()

    import libtmux

    server = libtmux.Server()

    try:
        old = server.sessions.get(session_name=session_name)
        if old:
            old.kill()
    except Exception:
        pass

    session = server.new_session(
        session_name=session_name,
        start_directory=str(output_dir),
        detach=True,
    )
    pane = session.active_window.active_pane
    pane.send_keys(watch_cmd)

    return session_name


def _shell_quote(s: str) -> str:
    """Minimal shell quoting — wrap in single quotes and escape existing ones."""
    return "'" + s.replace("'", "'\\''") + "'"
