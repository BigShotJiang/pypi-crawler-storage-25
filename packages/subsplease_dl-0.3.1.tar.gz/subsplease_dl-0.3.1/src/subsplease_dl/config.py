"""User configuration management for subsplease-dl.

Config is stored at ~/.config/subsplease-dl/config.toml
"""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Any

try:
    import tomllib  # Python 3.11+
except ImportError:
    try:
        import tomli as tomllib  # type: ignore[no-redef]
    except ImportError:
        tomllib = None  # type: ignore[assignment]

try:
    import tomli_w  # type: ignore[import]
except ImportError:
    tomli_w = None  # type: ignore[assignment]


# ── Default settings ──────────────────────────────────────────────────────────

DEFAULTS: dict[str, Any] = {
    "download_dir": "/sdcard/SubsPlease",
    "quality": "1080",
    "client": "aria2c",
    "connections": 16,      # aria2c -x  (connections per server)
    "split": 16,            # aria2c -s  (file segments)
    "max_concurrent": 3,    # aria2c --max-concurrent-downloads
    "seed_time": 0,         # aria2c --seed-time (0 = stop seeding immediately)
    "max_upload_limit": "1K",
    "tmux": False,
    "poll_interval": 300,   # seconds between watch polls
}

# Human-readable descriptions for the config keys
DESCRIPTIONS: dict[str, str] = {
    "download_dir":      "Default directory where episodes are saved",
    "quality":           "Preferred quality: 1080, 720, or 480",
    "client":            "Torrent client binary (aria2c, webtorrent, transmission-cli)",
    "connections":       "Max connections per server for aria2c (-x flag)",
    "split":             "Number of file segments for aria2c (-s flag)",
    "max_concurrent":    "Max concurrent downloads for aria2c",
    "seed_time":         "Minutes to seed after download (0 = stop immediately)",
    "max_upload_limit":  "Upload speed cap for aria2c (e.g. 1K, 100K, 0 for unlimited)",
    "tmux":              "Always use tmux for background downloads (true/false)",
    "poll_interval":     "Seconds between checks in watch mode",
}

VALID_QUALITIES = ("1080", "720", "480")


def _config_path() -> Path:
    """Return the path to the user config file."""
    xdg = os.environ.get("XDG_CONFIG_HOME")
    if xdg:
        base = Path(xdg)
    elif sys.platform == "win32":
        base = Path(os.environ.get("APPDATA", Path.home()))
    else:
        base = Path.home() / ".config"
    return base / "subsplease-dl" / "config.toml"


def load() -> dict[str, Any]:
    """Load config from disk, merged over defaults."""
    cfg = dict(DEFAULTS)
    path = _config_path()
    if not path.exists():
        return cfg
    if tomllib is None:
        return cfg  # Can't parse TOML without a library
    try:
        with open(path, "rb") as f:
            user = tomllib.load(f)
        cfg.update(user)
    except Exception:
        pass
    return cfg


def save(cfg: dict[str, Any]) -> None:
    """Write config to disk."""
    path = _config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    if tomli_w is not None:
        with open(path, "wb") as f:
            tomli_w.dump(cfg, f)
    else:
        # Fallback: write a basic TOML manually (handles str, int, bool)
        lines = [
            "# subsplease-dl configuration",
            "# Edit manually or use: subsplease-dl config set <key> <value>",
            "",
        ]
        for k, v in cfg.items():
            desc = DESCRIPTIONS.get(k)
            if desc:
                lines.append(f"# {desc}")
            if isinstance(v, bool):
                lines.append(f"{k} = {'true' if v else 'false'}")
            elif isinstance(v, str):
                lines.append(f'{k} = "{v}"')
            else:
                lines.append(f"{k} = {v}")
            lines.append("")
        path.write_text("\n".join(lines))


def get(key: str, fallback: Any = None) -> Any:
    """Get a single config value."""
    return load().get(key, DEFAULTS.get(key, fallback))


def set_value(key: str, raw_value: str) -> None:
    """Set and persist a single config value (type-coerced from string)."""
    if key not in DEFAULTS:
        raise KeyError(f"Unknown config key: {key!r}")
    cfg = load()
    default = DEFAULTS[key]
    if isinstance(default, bool):
        cfg[key] = raw_value.lower() in ("true", "1", "yes", "on")
    elif isinstance(default, int):
        cfg[key] = int(raw_value)
    else:
        cfg[key] = raw_value
    save(cfg)


def reset() -> None:
    """Reset config to defaults."""
    save(dict(DEFAULTS))


def as_display_rows() -> list[tuple[str, str, str, str]]:
    """Return (key, value, default, description) rows for display."""
    cfg = load()
    rows = []
    for k, default in DEFAULTS.items():
        current = cfg.get(k, default)
        changed = current != default
        rows.append((k, str(current), str(default), DESCRIPTIONS.get(k, ""), changed))
    return rows
