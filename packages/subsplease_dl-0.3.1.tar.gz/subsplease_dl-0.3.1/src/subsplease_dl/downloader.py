"""Download handling — aria2c, webtorrent, or magnet-link fallback."""

from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path
from typing import Optional

from .api import Release
from . import config as cfg_mod


class DownloadError(Exception):
    pass


def _has(cmd: str) -> bool:
    return shutil.which(cmd) is not None


def pick_client() -> Optional[str]:
    """Return the configured (or first available) download client."""
    preferred = cfg_mod.get("client")
    if preferred and _has(preferred):
        return preferred
    for client in ("aria2c", "webtorrent", "transmission-cli", "qbittorrent-nox"):
        if _has(client):
            return client
    return None


def build_aria2c_cmd(
    magnet: str,
    output_dir: Path,
    *,
    connections: Optional[int] = None,
    split: Optional[int] = None,
    max_concurrent: Optional[int] = None,
    seed_time: Optional[int] = None,
    max_upload_limit: Optional[str] = None,
    extra_args: Optional[list[str]] = None,
) -> list[str]:
    """Build an aria2c command with optimal segmented-download settings."""
    cfg = cfg_mod.load()
    conn = connections if connections is not None else cfg.get("connections", 16)
    seg = split if split is not None else cfg.get("split", 16)
    mcd = max_concurrent if max_concurrent is not None else cfg.get("max_concurrent", 3)
    st = seed_time if seed_time is not None else cfg.get("seed_time", 0)
    ul = max_upload_limit or cfg.get("max_upload_limit", "1K")

    cmd = [
        "aria2c",
        f"--max-connection-per-server={conn}",
        f"--split={seg}",
        f"--min-split-size=1M",
        f"--max-concurrent-downloads={mcd}",
        f"--seed-time={st}",
        f"--max-upload-limit={ul}",
        "--file-allocation=none",
        "--continue=true",
        "--bt-stop-timeout=300",
        f"--dir={output_dir}",
        magnet,
    ]
    if extra_args:
        cmd.extend(extra_args)
    return cmd


def build_webtorrent_cmd(
    magnet: str,
    output_dir: Path,
    extra_args: Optional[list[str]] = None,
) -> list[str]:
    cmd = ["webtorrent", "download", magnet, "--out", str(output_dir)]
    if extra_args:
        cmd.extend(extra_args)
    return cmd


def build_transmission_cmd(
    magnet: str,
    output_dir: Path,
    extra_args: Optional[list[str]] = None,
) -> list[str]:
    cmd = ["transmission-cli", magnet, "-w", str(output_dir)]
    if extra_args:
        cmd.extend(extra_args)
    return cmd


def build_download_cmd(
    magnet: str,
    output_dir: Path,
    client: Optional[str] = None,
    extra_args: Optional[list[str]] = None,
) -> list[str]:
    """Build a shell command list for downloading a magnet link."""
    client = client or pick_client()
    if client == "aria2c":
        return build_aria2c_cmd(magnet, output_dir, extra_args=extra_args)
    elif client == "webtorrent":
        return build_webtorrent_cmd(magnet, output_dir, extra_args=extra_args)
    elif client in ("transmission-cli", "transmission"):
        return build_transmission_cmd(magnet, output_dir, extra_args=extra_args)
    elif client:
        return [client, magnet]
    raise DownloadError(
        "No supported torrent client found.\n\n"
        "Install one of: aria2c, webtorrent-cli, transmission-cli\n"
        "  Ubuntu/Debian / Termux:  pkg install aria2  (or: apt install aria2)\n"
        "  macOS:                   brew install aria2\n"
        "  npm global:              npm install -g webtorrent-cli"
    )


def download_foreground(
    release: Release,
    quality: str = "1080",
    output_dir: Optional[Path] = None,
    client: Optional[str] = None,
    extra_args: Optional[list[str]] = None,
) -> int:
    """Download in the foreground (blocking). Returns the exit code."""
    magnet = release.get_magnet(quality)
    if not magnet and release.best_quality:
        magnet = release.get_magnet(release.best_quality)
    if not magnet:
        raise DownloadError(
            f'No download available for "{release.show}" episode {release.episode}. '
            f"Available qualities: {', '.join(release.available_qualities) or 'none'}"
        )
    output_dir = output_dir or Path(cfg_mod.get("download_dir"))
    output_dir.mkdir(parents=True, exist_ok=True)
    cmd = build_download_cmd(magnet, output_dir, client=client, extra_args=extra_args)
    return subprocess.call(cmd)


def open_magnet(magnet: str) -> None:
    """Open a magnet link with the OS default handler."""
    if sys.platform == "darwin":
        subprocess.Popen(["open", magnet])
    elif sys.platform == "win32":
        subprocess.Popen(["start", magnet], shell=True)
    else:
        subprocess.Popen(["xdg-open", magnet])
