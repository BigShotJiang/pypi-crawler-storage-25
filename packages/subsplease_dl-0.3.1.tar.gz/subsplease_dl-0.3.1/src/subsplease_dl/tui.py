"""Interactive terminal UI for subsplease-dl — browse, search, download."""

from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path
from typing import Optional

from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from . import api, config as cfg_mod, downloader, tmux

console = Console()


# ── fzf helpers ───────────────────────────────────────────────────────────────

def _has_fzf() -> bool:
    return shutil.which("fzf") is not None


def _fzf_select(items: list[str], prompt: str, multi: bool = False) -> list[str]:
    """
    Run fzf with the given items. Returns selected item(s), or [] on cancel.
    """
    args = [
        "fzf",
        f"--prompt={prompt}  ",
        "--ansi",
        "--layout=reverse",
        "--border=rounded",
        "--height=60%",
        "--info=inline",
        "--bind=ctrl-c:abort",
    ]
    if multi:
        args += ["--multi", "--bind=tab:toggle+down"]

    proc = subprocess.run(
        args,
        input="\n".join(items),
        capture_output=True,
        text=True,
    )
    if proc.returncode != 0:
        return []
    return [line for line in proc.stdout.strip().splitlines() if line]


# ── questionary helpers ────────────────────────────────────────────────────────

def _q_autocomplete(prompt: str, choices: list[str]) -> Optional[str]:
    try:
        import questionary
        from questionary import Style

        style = Style(
            [
                ("qmark", "fg:#00b4d8 bold"),
                ("question", "bold"),
                ("answer", "fg:#90e0ef bold"),
                ("pointer", "fg:#00b4d8 bold"),
                ("highlighted", "fg:#caf0f8"),
                ("selected", "fg:#90e0ef"),
                ("separator", "fg:#555555"),
                ("instruction", "fg:#555555"),
            ]
        )
        return questionary.autocomplete(
            prompt,
            choices=choices,
            match_middle=True,
            style=style,
        ).ask()
    except KeyboardInterrupt:
        return None


def _q_select(prompt: str, choices: list[str]) -> Optional[str]:
    try:
        import questionary
        return questionary.select(prompt, choices=choices, use_shortcuts=False).ask()
    except KeyboardInterrupt:
        return None


def _q_checkbox(prompt: str, choices: list[str]) -> list[str]:
    try:
        import questionary
        result = questionary.checkbox(prompt, choices=choices).ask()
        return result or []
    except KeyboardInterrupt:
        return []


def _q_confirm(prompt: str, default: bool = True) -> bool:
    try:
        import questionary
        return questionary.confirm(prompt, default=default).ask() or False
    except KeyboardInterrupt:
        return False


# ── Main TUI flow ─────────────────────────────────────────────────────────────

def run_tui(
    quality: Optional[str] = None,
    output_dir: Optional[Path] = None,
    client: Optional[str] = None,
    use_tmux: Optional[bool] = None,
) -> None:
    """
    Full interactive flow:
      1. Load all airing shows
      2. Fuzzy-search to pick a show
      3. Pick episode(s)
      4. Confirm quality + destination
      5. Download
    """
    cfg = cfg_mod.load()
    quality = quality or str(cfg.get("quality", "1080"))
    output_dir = output_dir or Path(str(cfg.get("download_dir", "/sdcard/SubsPlease")))
    client = client or str(cfg.get("client", "aria2c")) or None
    use_tmux = use_tmux if use_tmux is not None else bool(cfg.get("tmux", False))

    console.print(
        Panel(
            "[bold cyan]subsplease-dl[/]  [dim]— interactive downloader[/]\n\n"
            "[dim]Type to search · Arrow keys to navigate · Enter to select[/]\n"
            + ("[dim]Tab to multi-select (fzf)[/]" if _has_fzf() else ""),
            border_style="cyan",
        )
    )

    # ── Step 1: pick a show ───────────────────────────────────────────────────
    show_result = _pick_show()
    if not show_result:
        console.print("[dim]Cancelled.[/]")
        return

    # ── Step 2: pick episode(s) ───────────────────────────────────────────────
    selected_episodes = _pick_episodes(show_result, quality)
    if not selected_episodes:
        console.print("[dim]Cancelled.[/]")
        return

    # ── Step 3: confirm quality ───────────────────────────────────────────────
    quality = _pick_quality(quality)

    # ── Step 4: confirm download ──────────────────────────────────────────────
    ep_label = (
        selected_episodes[0].episode
        if len(selected_episodes) == 1
        else f"{len(selected_episodes)} episodes"
    )
    use_tmux_confirmed = _confirm_download(
        show=show_result.title,
        ep_label=ep_label,
        quality=quality,
        output_dir=output_dir,
        use_tmux=use_tmux,
    )
    if use_tmux_confirmed is None:
        console.print("[dim]Cancelled.[/]")
        return

    use_tmux = use_tmux_confirmed

    # ── Step 5: download ──────────────────────────────────────────────────────
    _do_downloads(selected_episodes, quality, output_dir, client, use_tmux, show_result.title)


# ── Sub-steps ─────────────────────────────────────────────────────────────────

def _pick_show() -> Optional[api.ShowResult]:
    """Interactive show picker. Returns the chosen ShowResult."""
    with console.status("[cyan]Loading show list…[/]"):
        sched = api.schedule()

    # Flatten schedule into a sorted list of ShowResult objects
    all_shows: list[api.ShowResult] = []
    for day, shows in sched.items():
        for s in shows:
            all_shows.append(s)
    all_shows.sort(key=lambda s: s.title.lower())

    titles = [s.title for s in all_shows]
    title_to_show = {s.title: s for s in all_shows}

    if _has_fzf():
        chosen = _fzf_select(titles, "Search show")
        if not chosen:
            return None
        return title_to_show.get(chosen[0])
    else:
        console.print(
            "\n[dim]Start typing a show name (Tab/arrows to navigate, Enter to select)[/]\n"
        )
        chosen = _q_autocomplete("Search show", titles)
        if not chosen:
            return None
        return title_to_show.get(chosen)


def _pick_episodes(
    show: api.ShowResult,
    quality: str,
) -> list[api.ShowEpisode]:
    """Load and pick episode(s) for the given show."""
    with console.status(f"[cyan]Loading episodes for [bold]{show.title}[/]…[/]"):
        details = api.show_details_by_page(show.page)

    if not details or not details.episodes:
        console.print(f"[yellow]No episodes found for '{show.title}'.[/]")
        return []

    episodes = details.episodes

    def _label(ep: api.ShowEpisode) -> str:
        qualities = " | ".join(f"{q}p" for q in ep.available_qualities)
        has_q = quality in ep.available_qualities
        marker = "✓" if has_q else "⚠"
        return f"Episode {ep.episode:>5}  [{marker} {qualities}]  {ep.release_date[:16]}"

    labels = [_label(ep) for ep in episodes]
    label_to_ep = dict(zip(labels, episodes))

    if _has_fzf():
        console.print(
            f"\n[dim]Multi-select with Tab · Enter to confirm[/]"
        )
        chosen_labels = _fzf_select(list(reversed(labels)), f"{show.title} — episodes", multi=True)
    else:
        console.print(
            f"\n[bold cyan]{show.title}[/] — [dim]Space to select · Enter to confirm[/]"
        )
        chosen_labels = _q_checkbox("Select episode(s)", list(reversed(labels)))

    return [label_to_ep[l] for l in chosen_labels if l in label_to_ep]


def _pick_quality(current: str) -> str:
    """Let the user pick or confirm quality."""
    if _has_fzf():
        chosen = _fzf_select(["1080p", "720p", "480p"], f"Quality  (current: {current}p)")
        return chosen[0].replace("p", "") if chosen else current
    choices = ["1080p", "720p", "480p"]
    idx = {"1080": 0, "720": 1, "480": 2}.get(current, 0)
    # Reorder so current is first
    ordered = [choices[idx]] + [c for i, c in enumerate(choices) if i != idx]
    chosen = _q_select(f"Quality  (current: {current}p)", ordered)
    if chosen is None:
        return current
    return chosen.replace("p", "")


def _confirm_download(
    show: str,
    ep_label: str,
    quality: str,
    output_dir: Path,
    use_tmux: bool,
) -> Optional[bool]:
    """
    Show a summary and ask whether to run foreground or background.
    Returns True = tmux, False = foreground, None = cancel.
    """
    console.print(
        Panel(
            f"  [bold white]{show}[/]  —  {ep_label}\n"
            f"  Quality:   [cyan]{quality}p[/]\n"
            f"  Save to:   [dim]{output_dir}[/]",
            title="[bold]Download summary[/]",
            border_style="cyan",
        )
    )

    if _has_fzf():
        opts = [
            "▶  Download now (foreground)",
            "⏩  Download in tmux (background)",
            "✕  Cancel",
        ]
        chosen = _fzf_select(opts, "How to download")
        if not chosen or "Cancel" in chosen[0]:
            return None
        return "tmux" in chosen[0]
    else:
        opts = [
            "Download now (foreground)",
            "Download in tmux (background)",
            "Cancel",
        ]
        default_idx = 1 if use_tmux else 0
        ordered = [opts[default_idx]] + [o for i, o in enumerate(opts) if i != default_idx]
        chosen = _q_select("How to download?", ordered)
        if chosen is None or chosen == "Cancel":
            return None
        return "tmux" in chosen


def _do_downloads(
    episodes: list[api.ShowEpisode],
    quality: str,
    output_dir: Path,
    client: Optional[str],
    use_tmux: bool,
    show_title: str,
) -> None:
    """Execute downloads for all selected episodes."""
    output_dir.mkdir(parents=True, exist_ok=True)

    for ep in episodes:
        release = api.Release(
            show=show_title,
            episode=ep.episode,
            page="",
            time="",
            release_date=ep.release_date,
            downloads=ep.downloads,
        )

        # Fallback quality
        dl_quality = quality if ep.get_magnet(quality) else (ep.best_quality or quality)
        if dl_quality != quality:
            console.print(
                f"[yellow]⚠[/]  {quality}p not available for ep {ep.episode}, "
                f"using {dl_quality}p"
            )

        if use_tmux:
            try:
                session = tmux.spawn_download(
                    release, quality=dl_quality, output_dir=output_dir, client=client
                )
                console.print(
                    f"[green]✓[/]  Ep [bold]{ep.episode}[/] → tmux session [cyan]{session}[/]  "
                    f"[dim](attach: tmux attach -t {session})[/]"
                )
            except (downloader.DownloadError, RuntimeError) as exc:
                console.print(f"[red]✗[/]  Ep {ep.episode}: {exc}")
        else:
            console.print(
                f"[bold]↓[/]  Downloading ep [bold]{ep.episode}[/] ({dl_quality}p)…"
            )
            try:
                rc = downloader.download_foreground(
                    release, quality=dl_quality, output_dir=output_dir, client=client
                )
                if rc == 0:
                    console.print(f"[green]✓[/]  Ep {ep.episode} done.")
                else:
                    console.print(f"[yellow]⚠[/]  Ep {ep.episode} client exited {rc}.")
            except downloader.DownloadError as exc:
                console.print(f"[red]✗[/]  {exc}")
