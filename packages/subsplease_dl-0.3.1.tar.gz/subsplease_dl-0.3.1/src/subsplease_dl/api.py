"""SubsPlease.org API client."""

from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from typing import Generator, Optional

import requests

BASE_URL = "https://subsplease.org"
API_URL = f"{BASE_URL}/api/"
DEFAULT_TIMEOUT = 15
DEFAULT_TZ = "UTC"

_session = requests.Session()
_session.headers.update(
    {
        "User-Agent": (
            "Mozilla/5.0 (X11; Linux x86_64; rv:120.0) Gecko/20100101 Firefox/120.0"
        ),
        "Referer": BASE_URL + "/",
        "X-Requested-With": "XMLHttpRequest",
        "Accept": "application/json, text/javascript, */*; q=0.01",
    }
)


@dataclass
class TorrentEntry:
    resolution: str
    magnet: str
    torrent: str = ""


@dataclass
class Release:
    """A single episode release from SubsPlease."""

    show: str
    episode: str
    page: str
    time: str
    release_date: str
    downloads: list[TorrentEntry] = field(default_factory=list)

    @property
    def available_qualities(self) -> list[str]:
        return [d.resolution for d in sorted(self.downloads, key=lambda d: int(d.resolution), reverse=True)]

    def get_magnet(self, quality: str = "1080") -> Optional[str]:
        for d in self.downloads:
            if d.resolution == quality:
                return d.magnet
        return None

    def get_torrent_url(self, quality: str = "1080") -> Optional[str]:
        for d in self.downloads:
            if d.resolution == quality:
                return d.torrent or None
        return None

    @property
    def best_quality(self) -> Optional[str]:
        for q in ("1080", "720", "480"):
            if self.get_magnet(q):
                return q
        return None


@dataclass
class ShowResult:
    """A show (from schedule or search)."""

    title: str
    page: str
    image_url: str
    air_time: str = ""
    day: str = ""


@dataclass
class ShowEpisode:
    """One episode entry from a show's episode list."""

    episode: str
    release_date: str
    downloads: list[TorrentEntry] = field(default_factory=list)

    def get_magnet(self, quality: str = "1080") -> Optional[str]:
        for d in self.downloads:
            if d.resolution == quality:
                return d.magnet
        return None

    @property
    def available_qualities(self) -> list[str]:
        return [d.resolution for d in sorted(self.downloads, key=lambda d: int(d.resolution), reverse=True)]

    @property
    def best_quality(self) -> Optional[str]:
        for q in ("1080", "720", "480"):
            if self.get_magnet(q):
                return q
        return None


@dataclass
class ShowDetails:
    """Full show details including episode list."""

    title: str
    page: str
    episodes: list[ShowEpisode] = field(default_factory=list)
    batches: list[ShowEpisode] = field(default_factory=list)


def _get(params: dict) -> Optional[dict | list]:
    """Make a GET request to the SubsPlease API. Returns parsed JSON or None."""
    try:
        resp = _session.get(API_URL, params=params, timeout=DEFAULT_TIMEOUT)
        resp.raise_for_status()
        text = resp.text.strip()
        if not text:
            return None
        return resp.json()
    except requests.exceptions.JSONDecodeError:
        return None


def _parse_downloads(raw: list) -> list[TorrentEntry]:
    """Parse a downloads list from the API (list of {res, magnet, torrent?})."""
    entries = []
    for item in raw or []:
        res = str(item.get("res", ""))
        if res in ("480", "720", "1080"):
            entries.append(
                TorrentEntry(
                    resolution=res,
                    magnet=item.get("magnet", ""),
                    torrent=item.get("torrent", ""),
                )
            )
    return entries


def latest(limit: int = 20, tz: str = DEFAULT_TZ) -> list[Release]:
    """
    Return the latest episode releases.

    The API returns a dict keyed by "{show} - {episode}". Each value has:
      time, release_date, show, episode, downloads=[{res, magnet}], page
    """
    data = _get({"f": "latest", "l": limit, "tz": tz})
    releases: list[Release] = []
    if not isinstance(data, dict):
        return releases
    for _key, item in data.items():
        releases.append(
            Release(
                show=item.get("show", ""),
                episode=str(item.get("episode", "")),
                page=item.get("page", ""),
                time=item.get("time", ""),
                release_date=item.get("release_date", ""),
                downloads=_parse_downloads(item.get("downloads", [])),
            )
        )
    return releases


def schedule(tz: str = DEFAULT_TZ) -> dict[str, list[ShowResult]]:
    """
    Return the weekly airing schedule.

    Returns a dict keyed by weekday name (Monday … Sunday), each being a list
    of ShowResult objects for shows airing that day.
    """
    data = _get({"f": "schedule", "tz": tz})
    if not isinstance(data, dict):
        return {}
    raw_schedule = data.get("schedule", {})
    result: dict[str, list[ShowResult]] = {}
    for day, shows in raw_schedule.items():
        result[day] = [
            ShowResult(
                title=s.get("title", ""),
                page=s.get("page", ""),
                image_url=BASE_URL + s.get("image_url", ""),
                air_time=s.get("time", ""),
                day=day,
            )
            for s in (shows or [])
        ]
    return result


def search(query: str, limit: int = 20) -> list[ShowResult]:
    """
    Search for shows by name using the weekly schedule (fuzzy title match).

    The SubsPlease search API endpoint is Cloudflare-restricted, so we use the
    full schedule as the source of truth and rank results by similarity.
    """
    sched = schedule()
    query_lower = query.lower()
    matches: list[tuple[int, ShowResult]] = []

    for day, shows in sched.items():
        for show in shows:
            title_lower = show.title.lower()
            if query_lower in title_lower:
                # Closer match = lower score (shorter title that still contains the query)
                score = len(title_lower) - len(query_lower)
                matches.append((score, show))

    matches.sort(key=lambda t: t[0])
    return [s for _, s in matches[:limit]]


def show_details_by_page(page_slug: str) -> Optional[ShowDetails]:
    """
    Return all episodes for a show using its page slug.

    Fetches the show's HTML page to extract the SID, then queries the API.
    """
    sid = _scrape_sid(page_slug)
    if sid:
        return show_details(sid, page_slug)
    return None


def show_details(sid: str, page_slug: str = "") -> Optional[ShowDetails]:
    """Return all episodes and batches for a show by its SID."""
    data = _get({"f": "show", "tz": DEFAULT_TZ, "sid": sid})
    if not isinstance(data, dict):
        return None

    def _parse_ep_list(raw: list) -> list[ShowEpisode]:
        eps = []
        for item in raw or []:
            eps.append(
                ShowEpisode(
                    episode=str(item.get("episode", "")),
                    release_date=item.get("release_date", ""),
                    downloads=_parse_downloads(item.get("downloads", [])),
                )
            )
        eps.sort(key=lambda e: _ep_sort_key(e.episode))
        return eps

    # Infer title from page slug if not in data
    title = page_slug.replace("-", " ").title() if page_slug else f"Show {sid}"

    return ShowDetails(
        title=title,
        page=page_slug,
        episodes=_parse_ep_list(data.get("episode", [])),
        batches=_parse_ep_list(data.get("batch", [])),
    )


def _scrape_sid(page_slug: str) -> Optional[str]:
    """Scrape the show's SID from its HTML page."""
    try:
        url = f"{BASE_URL}/shows/{page_slug}/"
        resp = _session.get(url, timeout=DEFAULT_TIMEOUT)
        resp.raise_for_status()
        # The SID is typically in a JS variable: var sid = "1234";
        m = re.search(r'(?:var\s+)?sid\s*[=:]\s*["\']?(\d+)["\']?', resp.text)
        if m:
            return m.group(1)
        # Also try data-attributes
        m = re.search(r'data-(?:show-)?sid=["\'](\d+)["\']', resp.text)
        if m:
            return m.group(1)
    except Exception:
        pass
    return None


def _ep_sort_key(ep: str) -> float:
    try:
        return float(ep)
    except ValueError:
        return 0.0


def show_page_url(page_slug: str) -> str:
    return f"{BASE_URL}/shows/{page_slug}/"


def poll_latest(
    interval: int = 60,
    tz: str = DEFAULT_TZ,
    seen_keys: Optional[set[str]] = None,
) -> Generator[Release, None, None]:
    """
    Generator that polls /api/?f=latest and yields new releases.

    Args:
        interval: Seconds between polls.
        tz: Timezone string for the API.
        seen_keys: Set of (show, episode) strings already seen. Mutated in place.
    """
    if seen_keys is None:
        seen_keys = set()

    while True:
        try:
            for release in latest(tz=tz):
                key = f"{release.show}|{release.episode}"
                if key not in seen_keys:
                    seen_keys.add(key)
                    yield release
        except Exception:
            pass
        time.sleep(interval)
