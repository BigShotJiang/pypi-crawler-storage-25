"""Click-based CLI for subsplease-dl."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Optional

import click
from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from . import api, config as cfg_mod, downloader, tmux, tui as tui_mod

console = Console()
err_console = Console(stderr=True)


def _quality_choices():
    return click.Choice(["1080", "720", "480"], case_sensitive=False)


def _abort(msg: str) -> None:
    err_console.print(f"[bold red]Error:[/] {msg}")
    sys.exit(1)


def _cfg_quality() -> str:
    return str(cfg_mod.get("quality", "1080"))


def _cfg_output() -> str:
    return str(cfg_mod.get("download_dir", "/sdcard/SubsPlease"))


def _cfg_interval() -> int:
    return int(cfg_mod.get("poll_interval", 300))


def _cfg_tmux() -> bool:
    return bool(cfg_mod.get("tmux", False))


# ── Root group ────────────────────────────────────────────────────────────────

@click.group(context_settings={"help_option_names": ["-h", "--help"]})
@click.version_option(package_name="subsplease-dl")
def main():
    """
    \b
    subsplease-dl — download anime from SubsPlease.org

    Downloads episodes via aria2c/webtorrent with multi-threaded segmented
    downloading. Runs persistent watch daemons inside tmux sessions.

    \b
    Quick start:
      subsplease-dl latest
      subsplease-dl search "One Piece"
      subsplease-dl download --show "One Piece"
      subsplease-dl config show
    """


# ── config ────────────────────────────────────────────────────────────────────

@main.group()
def config():
    """View and change user settings (quality, download dir, threads, …)."""


@config.command(name="show")
def config_show():
    """Show all current settings."""
    rows = cfg_mod.as_display_rows()
    path = cfg_mod._config_path()

    table = Table(
        title=f"Settings  [dim]({path})[/]",
        box=box.ROUNDED,
        header_style="bold cyan",
        expand=True,
    )
    table.add_column("Key", style="bold white", min_width=18)
    table.add_column("Value", min_width=20)
    table.add_column("Default", style="dim", min_width=14)
    table.add_column("Description", style="dim")

    for key, value, default, desc, changed in rows:
        value_text = Text(value, style="bold green" if changed else "white")
        table.add_row(key, value_text, default, desc)

    console.print(table)
    console.print(
        "\n[dim]Change a setting:  [bold]subsplease-dl config set <key> <value>[/][/]"
    )


@config.command(name="set")
@click.argument("key")
@click.argument("value")
def config_set(key: str, value: str):
    """Set a config value. Example: subsplease-dl config set quality 720"""
    try:
        cfg_mod.set_value(key, value)
        console.print(f"[green]Set[/] [bold]{key}[/] = [cyan]{value}[/]")
    except KeyError as exc:
        valid = ", ".join(cfg_mod.DEFAULTS.keys())
        _abort(f"{exc}\nValid keys: {valid}")
    except ValueError as exc:
        _abort(str(exc))


@config.command(name="reset")
@click.confirmation_option(prompt="Reset all settings to defaults?")
def config_reset():
    """Reset all settings back to defaults."""
    cfg_mod.reset()
    console.print("[green]Settings reset to defaults.[/]")


@config.command(name="path")
def config_path():
    """Print the path to the config file."""
    console.print(str(cfg_mod._config_path()))


# ── tui ──────────────────────────────────────────────────────────────────────

@main.command()
@click.option("-q", "--quality", default=None, type=_quality_choices(),
              help="Override quality (default: from config).")
@click.option("-o", "--output", "output_dir", default=None, type=click.Path(),
              help="Override output directory (default: from config).")
@click.option("--client", default=None, help="Override torrent client.")
@click.option("--tmux", "use_tmux", is_flag=True, default=False,
              help="Force background download via tmux.")
def tui(
    quality: Optional[str],
    output_dir: Optional[str],
    client: Optional[str],
    use_tmux: bool,
):
    """
    Interactive show browser — search, pick episodes, download.

    \b
    Uses fzf if installed (best experience), otherwise falls back to
    an interactive prompt. Install fzf for the best experience:
      Ubuntu/Termux:  pkg install fzf
      macOS:          brew install fzf
    """
    out = Path(output_dir) if output_dir else None
    tui_mod.run_tui(
        quality=quality,
        output_dir=out,
        client=client,
        use_tmux=use_tmux or None,
    )


# ── search ────────────────────────────────────────────────────────────────────

@main.command()
@click.argument("query", nargs=-1, required=True)
@click.option("-l", "--limit", default=20, show_default=True, help="Max results.")
def search(query: tuple[str, ...], limit: int):
    """Search for a currently-airing anime by name."""
    q = " ".join(query)
    with console.status(f"Searching for [bold]{q}[/]…"):
        results = api.search(q, limit=limit)

    if not results:
        console.print(f"[yellow]No results found for '{q}'.[/]")
        console.print("[dim]Only currently-airing shows are indexed. Try 'latest' for recent releases.[/]")
        return

    table = Table(
        title=f"Search: {q}",
        box=box.ROUNDED,
        header_style="bold cyan",
        expand=True,
    )
    table.add_column("#", style="dim", width=4, justify="right")
    table.add_column("Title", style="bold white")
    table.add_column("Day", style="green", width=10)
    table.add_column("Time (UTC)", width=10)
    table.add_column("Page slug", style="blue")

    for i, r in enumerate(results, 1):
        table.add_row(str(i), r.title, r.day, r.air_time, r.page)

    console.print(table)
    console.print(
        "\n[dim]Tip: [bold]subsplease-dl episodes --page <PAGE-SLUG>[/] to list episodes.[/]"
    )


# ── schedule ──────────────────────────────────────────────────────────────────

@main.command()
@click.option("--day", default=None, help="Filter to a specific day (Monday, Tuesday, …).")
def schedule(day: Optional[str]):
    """Show the weekly airing schedule."""
    with console.status("Fetching schedule…"):
        sched = api.schedule()

    if not sched:
        console.print("[yellow]Could not load schedule.[/]")
        return

    days = list(sched.keys())
    if day:
        day_cap = day.capitalize()
        if day_cap not in sched:
            _abort(f"Unknown day '{day}'. Valid: {', '.join(days)}")
        days = [day_cap]

    for d in days:
        shows = sched.get(d, [])
        if not shows:
            continue
        table = Table(title=d, box=box.SIMPLE_HEAD, header_style="bold cyan", expand=True)
        table.add_column("Title", style="bold white")
        table.add_column("Time (UTC)", width=10)
        table.add_column("Page slug", style="blue")

        for s in shows:
            table.add_row(s.title, s.air_time, s.page)

        console.print(table)


# ── latest ────────────────────────────────────────────────────────────────────

@main.command()
@click.option("-l", "--limit", default=20, show_default=True, help="Number of releases.")
@click.option("-q", "--quality", default=None, type=_quality_choices(),
              help="Quality to highlight (default: from config).")
def latest(limit: int, quality: Optional[str]):
    """Show the latest episode releases."""
    quality = quality or _cfg_quality()

    with console.status("Fetching latest releases…"):
        releases = api.latest(limit=limit)

    if not releases:
        console.print("[yellow]No releases found.[/]")
        return

    table = Table(
        title="Latest Releases — SubsPlease.org",
        box=box.ROUNDED,
        header_style="bold cyan",
        expand=True,
    )
    table.add_column("Show", style="bold white", min_width=24)
    table.add_column("Ep", justify="right", width=6)
    table.add_column("Release Date", style="dim", width=32)
    table.add_column("Qualities", width=16)

    for r in releases:
        qualities_str = "  ".join(
            f"[green]{q}p[/]" if q == quality else f"[dim]{q}p[/]"
            for q in r.available_qualities
        )
        table.add_row(r.show, r.episode, r.release_date, Text.from_markup(qualities_str))

    console.print(table)
    console.print(
        "\n[dim]Tip: [bold]subsplease-dl download --show \"<name>\"[/] to download the latest episode.[/]"
    )


# ── episodes ──────────────────────────────────────────────────────────────────

@main.command()
@click.option("--page", required=True, help="Show page slug (from search/schedule).")
@click.option("-q", "--quality", default=None, type=_quality_choices())
@click.option("--batches", is_flag=True, help="Show batch releases instead of episodes.")
def episodes(page: str, quality: Optional[str], batches: bool):
    """List all episodes for a show (by page slug)."""
    quality = quality or _cfg_quality()

    with console.status(f"Fetching episodes for {page}…"):
        details = api.show_details_by_page(page)

    if not details:
        _abort(f"Could not load show '{page}'. Check the slug with 'search' or 'schedule'.")

    ep_list = details.batches if batches else details.episodes
    label = "Batches" if batches else "Episodes"

    if not ep_list:
        console.print(f"[yellow]No {label.lower()} found for '{page}'.[/]")
        return

    table = Table(
        title=f"{details.title} — {label}",
        box=box.ROUNDED,
        header_style="bold cyan",
        expand=True,
    )
    table.add_column("Episode", justify="right", width=8)
    table.add_column("Release Date", style="dim", width=32)
    table.add_column("Qualities", width=16)

    for ep in ep_list:
        qualities_str = "  ".join(
            f"[green]{q}p[/]" if q == quality else f"[dim]{q}p[/]"
            for q in ep.available_qualities
        )
        table.add_row(ep.episode, ep.release_date, Text.from_markup(qualities_str))

    console.print(table)
    console.print(
        f"\n[dim]Download: [bold]subsplease-dl download --page {page} --episode <EP>[/][/]"
    )


# ── download ──────────────────────────────────────────────────────────────────

@main.command()
@click.option("--page", default=None, help="Show page slug.")
@click.option("--episode", default=None, help="Episode number/label (omit for latest).")
@click.option("--show", "show_name", default=None,
              help="Search for a show by name (picks the first match).")
@click.option("-q", "--quality", default=None, type=_quality_choices(),
              help="Quality (default: from config).")
@click.option("-o", "--output", "output_dir", default=None, type=click.Path(),
              help="Output directory (default: from config).")
@click.option("--client", default=None, help="Torrent client (aria2c, webtorrent, …).")
@click.option("-x", "--connections", default=None, type=int,
              help="Connections per server for aria2c (default: from config).")
@click.option("-s", "--split", default=None, type=int,
              help="File segments for aria2c (default: from config).")
@click.option("--tmux", "use_tmux", is_flag=True, default=False,
              help="Run in a detached tmux session.")
@click.option("--magnet-only", is_flag=True, help="Print magnet link and exit.")
def download(
    page: Optional[str],
    episode: Optional[str],
    show_name: Optional[str],
    quality: Optional[str],
    output_dir: Optional[str],
    client: Optional[str],
    connections: Optional[int],
    split: Optional[int],
    use_tmux: bool,
    magnet_only: bool,
):
    """
    Download an episode by page slug, or by show name (auto-picks latest).

    \b
    Examples:
      subsplease-dl download --show "One Piece"
      subsplease-dl download --page one-piece --episode 1161
      subsplease-dl download --show "One Piece" --tmux
      subsplease-dl download --show "One Piece" --magnet-only
    """
    quality = quality or _cfg_quality()
    out = Path(output_dir) if output_dir else Path(_cfg_output())
    use_tmux = use_tmux or _cfg_tmux()

    release = _resolve_release(page, episode, show_name, quality)

    if magnet_only:
        magnet = release.get_magnet(quality) or release.get_magnet(release.best_quality or "")
        if not magnet:
            _abort(f"No {quality}p magnet available.")
        console.print(magnet)
        return

    cfg = cfg_mod.load()
    extra_args: list[str] = []
    if connections is not None:
        extra_args += [f"--max-connection-per-server={connections}",
                       f"--split={connections}"]
    elif split is not None:
        extra_args += [f"--split={split}"]

    if use_tmux:
        try:
            session = tmux.spawn_download(
                release, quality=quality, output_dir=out, client=client
            )
            console.print(
                Panel(
                    f"[bold green]Download started[/] in tmux session [cyan]{session}[/]\n\n"
                    f"  Show:    [white]{release.show}[/] ep {release.episode} ({quality}p)\n"
                    f"  Dir:     [dim]{out}[/]\n\n"
                    f"  Attach:  [bold]tmux attach -t {session}[/]\n"
                    f"  Kill:    [bold]subsplease-dl sessions kill {session}[/]",
                    title="[bold]Background Download[/]",
                    border_style="green",
                )
            )
        except (downloader.DownloadError, RuntimeError) as exc:
            _abort(str(exc))
        return

    console.print(
        f"[bold]Downloading[/] [cyan]{release.show}[/] ep [cyan]{release.episode}[/] "
        f"({quality}p)  [dim]connections={cfg.get('connections',16)}  "
        f"split={cfg.get('split',16)}[/]\n"
        f"[dim]→ {out}[/]\n"
    )
    try:
        rc = downloader.download_foreground(
            release, quality=quality, output_dir=out, client=client,
            extra_args=extra_args or None,
        )
        if rc != 0:
            _abort(f"Download client exited with code {rc}.")
    except downloader.DownloadError as exc:
        _abort(str(exc))


# ── watch ─────────────────────────────────────────────────────────────────────

@main.command()
@click.argument("show_title", nargs=-1, required=True)
@click.option("-q", "--quality", default=None, type=_quality_choices())
@click.option("-o", "--output", "output_dir", default=None, type=click.Path())
@click.option("--interval", default=None, type=int,
              help="Poll interval in seconds (default: from config).")
@click.option("--client", default=None)
@click.option("--tmux", "use_tmux", is_flag=True, default=False,
              help="Spawn a dedicated tmux session for this watcher.")
def watch(
    show_title: tuple[str, ...],
    quality: Optional[str],
    output_dir: Optional[str],
    interval: Optional[int],
    client: Optional[str],
    use_tmux: bool,
):
    """
    Poll for new episodes and download them automatically.

    \b
    Example:
        subsplease-dl watch "One Piece" --tmux
        subsplease-dl watch "One Piece" --quality 720 --interval 180
    """
    title = " ".join(show_title)
    quality = quality or _cfg_quality()
    out = Path(output_dir) if output_dir else Path(_cfg_output())
    interval = interval if interval is not None else _cfg_interval()
    use_tmux = use_tmux or _cfg_tmux()

    if use_tmux:
        try:
            session = tmux.spawn_watch(
                title, quality=quality, output_dir=out, client=client, poll_interval=interval
            )
            console.print(
                Panel(
                    f"[bold green]Watcher started[/] in tmux session [cyan]{session}[/]\n\n"
                    f"  Show:     [white]{title}[/]  ({quality}p)\n"
                    f"  Dir:      [dim]{out}[/]\n"
                    f"  Interval: {interval}s\n\n"
                    f"  Attach:   [bold]tmux attach -t {session}[/]\n"
                    f"  Kill:     [bold]subsplease-dl sessions kill {session}[/]",
                    title="[bold]Background Watcher[/]",
                    border_style="green",
                )
            )
        except RuntimeError as exc:
            _abort(str(exc))
        return

    console.print(
        f"[bold]Watching[/] for new episodes of [cyan]{title}[/] "
        f"(every {interval}s, {quality}p) — press Ctrl+C to stop.\n"
    )
    seen: set[str] = set()
    with console.status("Seeding already-seen episodes…"):
        for r in api.latest(limit=50):
            if title.lower() in r.show.lower():
                seen.add(f"{r.show}|{r.episode}")

    console.print(f"[dim]Seeded {len(seen)} already-seen episodes. Polling…[/]\n")

    try:
        for release in api.poll_latest(interval=interval, seen_keys=seen):
            if title.lower() not in release.show.lower():
                continue
            magnet = release.get_magnet(quality)
            if not magnet:
                console.print(
                    f"[yellow]⚠[/]  No {quality}p for [cyan]{release.show}[/] ep {release.episode}, "
                    f"available: {', '.join(release.available_qualities)}"
                )
                continue
            console.print(
                f"[green]↓[/]  [bold]{release.show}[/] ep [bold]{release.episode}[/] ({quality}p)"
            )
            try:
                rc = downloader.download_foreground(
                    release, quality=quality, output_dir=out, client=client
                )
                if rc != 0:
                    console.print(f"[yellow]  Client exited with code {rc}[/]")
            except downloader.DownloadError as exc:
                console.print(f"[red]  {exc}[/]")
    except KeyboardInterrupt:
        console.print("\n[dim]Stopped.[/]")


# ── sessions ──────────────────────────────────────────────────────────────────

@main.group()
def sessions():
    """Manage active tmux download sessions."""


@sessions.command(name="list")
def sessions_list():
    """List all active subsplease-dl tmux sessions."""
    try:
        active = tmux.list_sessions()
    except RuntimeError as exc:
        _abort(str(exc))
        return

    if not active:
        console.print("[dim]No active subsplease-dl sessions.[/]")
        return

    table = Table(title="Active Download Sessions", box=box.ROUNDED, header_style="bold cyan")
    table.add_column("Session name", style="bold cyan")
    table.add_column("Windows", justify="right", width=8)

    for s in active:
        table.add_row(s["name"], str(s["windows"]))

    console.print(table)
    console.print(
        "\n[dim]Attach:  [bold]tmux attach -t <name>[/]   "
        "Kill:  [bold]subsplease-dl sessions kill <name>[/][/]"
    )


@sessions.command(name="kill")
@click.argument("name")
def sessions_kill(name: str):
    """Kill a named tmux session."""
    try:
        killed = tmux.kill_session(name)
    except RuntimeError as exc:
        _abort(str(exc))
        return
    if killed:
        console.print(f"[green]Killed session[/] [cyan]{name}[/].")
    else:
        console.print(f"[yellow]Session '{name}' not found.[/]")


@sessions.command(name="attach")
@click.argument("name")
def sessions_attach(name: str):
    """Attach to a running tmux session (replaces current terminal)."""
    tmux.attach_session(name)


# ── magnet ────────────────────────────────────────────────────────────────────

@main.command()
@click.option("--page", required=True, help="Show page slug.")
@click.option("--episode", required=True, help="Episode number.")
@click.option("-q", "--quality", default=None, type=_quality_choices())
@click.option("--open", "open_link", is_flag=True, help="Open with system default handler.")
def magnet(page: str, episode: str, quality: Optional[str], open_link: bool):
    """Print (or open) the magnet link for a specific episode."""
    quality = quality or _cfg_quality()

    with console.status(f"Fetching episode {episode} of {page}…"):
        details = api.show_details_by_page(page)

    if not details:
        _abort(f"Could not load show '{page}'.")

    ep_map = {e.episode: e for e in details.episodes}
    ep = ep_map.get(episode)
    if not ep:
        available = ", ".join(sorted(ep_map.keys(), key=api._ep_sort_key)[-10:])
        _abort(f"Episode {episode!r} not found. Recent: {available}")

    link = ep.get_magnet(quality)
    if not link:
        _abort(f"No {quality}p magnet. Available: {', '.join(ep.available_qualities)}")

    if open_link:
        downloader.open_magnet(link)
        console.print(f"[green]Opened magnet for {details.title} ep {episode}.[/]")
    else:
        console.print(link)


# ── Helpers ───────────────────────────────────────────────────────────────────

def _resolve_release(
    page: Optional[str],
    episode: Optional[str],
    show_name: Optional[str],
    quality: str,
) -> "api.Release":
    if page:
        with console.status(f"Fetching show details for '{page}'…"):
            details = api.show_details_by_page(page)
        if not details:
            _abort(f"Could not load show '{page}'.")
        if episode:
            ep_map = {e.episode: e for e in details.episodes}
            ep = ep_map.get(episode)
            if not ep:
                available = ", ".join(sorted(ep_map.keys(), key=api._ep_sort_key)[-10:])
                _abort(f"Episode {episode!r} not found. Recent: {available}")
            return _episode_to_release(ep, details.title, page)
        if not details.episodes:
            _abort(f"No episodes found for '{page}'.")
        return _episode_to_release(details.episodes[-1], details.title, page)

    if show_name:
        with console.status(f"Searching latest releases for '{show_name}'…"):
            releases = api.latest(limit=50)
        matches = [r for r in releases if show_name.lower() in r.show.lower()]
        if matches:
            return matches[-1]
        with console.status(f"Searching schedule for '{show_name}'…"):
            results = api.search(show_name, limit=3)
        if not results:
            _abort(f"No shows found matching '{show_name}'.")
        show_result = results[0]
        with console.status(f"Fetching latest episode of '{show_result.title}'…"):
            details = api.show_details_by_page(show_result.page)
        if not details or not details.episodes:
            _abort(f"No episodes found for '{show_result.title}'.")
        return _episode_to_release(details.episodes[-1], details.title, show_result.page)

    _abort(
        "Specify --page and/or --episode, or --show <name>.\n\n"
        "  Examples:\n"
        "    subsplease-dl download --show 'One Piece'\n"
        "    subsplease-dl download --page one-piece --episode 1161\n"
        "    subsplease-dl download --page one-piece  # latest episode"
    )
    raise SystemExit(1)


def subs_shortcut() -> None:
    """Entry point for the `subs` command — launches TUI directly."""
    tui_mod.run_tui()


def _episode_to_release(ep: "api.ShowEpisode", show: str, page: str) -> "api.Release":
    return api.Release(
        show=show,
        episode=ep.episode,
        page=page,
        time="",
        release_date=ep.release_date,
        downloads=ep.downloads,
    )
