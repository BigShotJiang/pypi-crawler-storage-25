import json
import os
import urllib.error
import urllib.request
from datetime import datetime, timedelta


class PipelineOrchestrator:

    def __init__(self, spark, catalog=None, schema=None):
        self.spark = spark
        self._dependency_columns = None
        self._task_run_columns = None
        self._group_columns = None
        self._group_schedule_columns = None
        self._dataset_execution_policy_columns = None
        self._pipeline_execution_config_columns = None
        self._connection_config_columns = None
        self._bronze_ingestion_config_columns = None
        resolved_catalog = catalog or os.getenv("GSS_SPARK_FLOW_CATALOG")
        resolved_schema = schema or os.getenv("GSS_SPARK_FLOW_SCHEMA")
        self._set_default_namespace(catalog=resolved_catalog, schema=resolved_schema)

    # -------------------------------------
    # Internal helpers
    # -------------------------------------

    def _clean(self, value):
        if value is None:
            return None
        cleaned = str(value).replace("'", "").strip()
        return cleaned if cleaned else None

    def _set_default_namespace(self, catalog=None, schema=None):
        catalog_name = self._clean(catalog)
        schema_name = self._clean(schema)

        if catalog_name:
            self.spark.sql(f"USE CATALOG {catalog_name}")
        if schema_name:
            self.spark.sql(f"USE {schema_name}")

    def _sql_str_or_null(self, value):
        cleaned = self._clean(value)
        if cleaned is None:
            return "NULL"
        return f"'{cleaned}'"

    def _sql_literal_or_null(self, value):
        if value is None:
            return "NULL"
        escaped = str(value).replace("'", "''").strip()
        if not escaped:
            return "NULL"
        return f"'{escaped}'"

    def _parameters_json_or_null(self, parameters):
        if parameters is None:
            return "NULL"
        if isinstance(parameters, str):
            return self._sql_literal_or_null(parameters)
        return self._sql_literal_or_null(json.dumps(parameters, sort_keys=True))

    def _parse_parameters_json(self, parameters_json):
        if not parameters_json:
            return {}
        if isinstance(parameters_json, dict):
            return parameters_json
        try:
            parsed = json.loads(parameters_json)
        except Exception as exc:
            raise ValueError(f"Invalid parameters_json: {parameters_json}") from exc
        if parsed is None:
            return {}
        if not isinstance(parsed, dict):
            raise ValueError("parameters_json must decode to a JSON object")
        return parsed

    def _json_safe(self, value):
        if isinstance(value, dict):
            return {key: self._json_safe(val) for key, val in value.items()}
        if isinstance(value, list):
            return [self._json_safe(item) for item in value]
        if isinstance(value, tuple):
            return [self._json_safe(item) for item in value]
        if isinstance(value, datetime):
            return value.isoformat()
        return value

    def _normalize_dependency_mode(self, mode):
        normalized = str(mode or "hard").lower().strip()
        if normalized not in {"hard", "soft"}:
            raise ValueError("dependency_mode must be 'hard' or 'soft'")
        return normalized

    def _normalize_execution_engine(self, engine):
        normalized = str(engine or "").lower().strip()
        if normalized not in {"fabric", "databricks"}:
            raise ValueError("execution_engine must be 'fabric' or 'databricks'")
        return normalized

    def _normalize_medallion_layer(self, layer):
        if layer is None:
            return None
        normalized = str(layer or "").lower().strip()
        if not normalized:
            return None
        if normalized not in {"bronze", "silver", "gold"}:
            raise ValueError("medallion_layer must be 'bronze', 'silver' or 'gold'")
        return normalized

    def _normalize_freshness_hours(self, freshness_hours):
        if freshness_hours is None:
            return None
        hours = int(freshness_hours)
        if hours <= 0:
            raise ValueError("freshness_hours must be > 0")
        return hours

    def _normalize_execution_order(self, execution_order):
        if execution_order is None:
            raise ValueError("execution_order is required")
        return int(execution_order)

    def _normalize_min_interval_minutes(self, min_interval_minutes):
        if min_interval_minutes is None:
            return None
        minutes = int(min_interval_minutes)
        if minutes <= 0:
            raise ValueError("min_interval_minutes must be > 0")
        return minutes

    def _normalize_is_active(self, is_active):
        if is_active is None:
            return True
        if isinstance(is_active, bool):
            return is_active
        normalized = str(is_active).strip().lower()
        if normalized in {"1", "true", "t", "yes", "y", "si", "s"}:
            return True
        if normalized in {"0", "false", "f", "no", "n"}:
            return False
        raise ValueError("is_active must be a boolean-like value")

    def _http_json(self, method, url, token, payload=None, timeout=60):
        if not token:
            raise ValueError(f"Missing bearer token for {url}")

        data = None
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        }
        if payload is not None:
            data = json.dumps(payload).encode("utf-8")

        request = urllib.request.Request(
            url=url,
            data=data,
            headers=headers,
            method=method,
        )

        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                body = response.read().decode("utf-8")
                return {
                    "status_code": response.status,
                    "headers": dict(response.headers.items()),
                    "body": json.loads(body) if body else None,
                }
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8")
            raise RuntimeError(
                f"HTTP {exc.code} calling {url}: {body}"
            ) from exc

    def _get_dependency_columns(self):
        if self._dependency_columns is not None:
            return self._dependency_columns
        try:
            self._dependency_columns = {
                row[0]
                for row in self.spark.sql("DESCRIBE metadata.pipeline_dependency").collect()
                if row[0] and not row[0].startswith("#")
            }
        except Exception:
            self._dependency_columns = set()
        return self._dependency_columns

    def _get_group_columns(self):
        if self._group_columns is not None:
            return self._group_columns
        try:
            self._group_columns = {
                row[0]
                for row in self.spark.sql("DESCRIBE metadata.pipeline_dependency_group").collect()
                if row[0] and not row[0].startswith("#")
            }
        except Exception:
            self._group_columns = set()
        return self._group_columns

    def _require_group_columns(self, required_columns):
        existing = self._get_group_columns()
        missing = [col for col in required_columns if col not in existing]
        if missing:
            raise ValueError(
                "metadata.pipeline_dependency_group is missing columns: "
                f"{missing}. Re-run init_metadata_layer to apply migrations."
            )

    def _get_group_schedule_columns(self):
        if self._group_schedule_columns is not None:
            return self._group_schedule_columns
        try:
            self._group_schedule_columns = {
                row[0]
                for row in self.spark.sql("DESCRIBE metadata.pipeline_dependency_group_schedule").collect()
                if row[0] and not row[0].startswith("#")
            }
        except Exception:
            self._group_schedule_columns = set()
        return self._group_schedule_columns

    def _require_group_schedule_columns(self, required_columns):
        existing = self._get_group_schedule_columns()
        missing = [col for col in required_columns if col not in existing]
        if missing:
            raise ValueError(
                "metadata.pipeline_dependency_group_schedule is missing columns: "
                f"{missing}. Re-run init_metadata_layer to apply migrations."
            )

    def _get_dataset_execution_policy_columns(self):
        if self._dataset_execution_policy_columns is not None:
            return self._dataset_execution_policy_columns
        try:
            self._dataset_execution_policy_columns = {
                row[0]
                for row in self.spark.sql("DESCRIBE metadata.dataset_execution_policy").collect()
                if row[0] and not row[0].startswith("#")
            }
        except Exception:
            self._dataset_execution_policy_columns = set()
        return self._dataset_execution_policy_columns

    def _require_dataset_execution_policy_columns(self, required_columns):
        existing = self._get_dataset_execution_policy_columns()
        missing = [col for col in required_columns if col not in existing]
        if missing:
            raise ValueError(
                "metadata.dataset_execution_policy is missing columns: "
                f"{missing}. Re-run init_metadata_layer to apply migrations."
            )

    def _get_pipeline_execution_config_columns(self):
        if self._pipeline_execution_config_columns is not None:
            return self._pipeline_execution_config_columns
        try:
            self._pipeline_execution_config_columns = {
                row[0]
                for row in self.spark.sql("DESCRIBE metadata.pipeline_execution_config").collect()
                if row[0] and not row[0].startswith("#")
            }
        except Exception:
            self._pipeline_execution_config_columns = set()
        return self._pipeline_execution_config_columns

    def _require_pipeline_execution_config_columns(self, required_columns):
        existing = self._get_pipeline_execution_config_columns()
        missing = [col for col in required_columns if col not in existing]
        if missing:
            raise ValueError(
                "metadata.pipeline_execution_config is missing columns: "
                f"{missing}. Re-run init_metadata_layer to apply migrations."
            )

    def _get_connection_config_columns(self):
        if self._connection_config_columns is not None:
            return self._connection_config_columns
        try:
            self._connection_config_columns = {
                row[0]
                for row in self.spark.sql("DESCRIBE metadata.connection_config").collect()
                if row[0] and not row[0].startswith("#")
            }
        except Exception:
            self._connection_config_columns = set()
        return self._connection_config_columns

    def _require_connection_config_columns(self, required_columns):
        existing = self._get_connection_config_columns()
        missing = [col for col in required_columns if col not in existing]
        if missing:
            raise ValueError(
                "metadata.connection_config is missing columns: "
                f"{missing}. Re-run init_metadata_layer to apply migrations."
            )

    def _get_bronze_ingestion_config_columns(self):
        if self._bronze_ingestion_config_columns is not None:
            return self._bronze_ingestion_config_columns
        try:
            self._bronze_ingestion_config_columns = {
                row[0]
                for row in self.spark.sql("DESCRIBE metadata.bronze_ingestion_config").collect()
                if row[0] and not row[0].startswith("#")
            }
        except Exception:
            self._bronze_ingestion_config_columns = set()
        return self._bronze_ingestion_config_columns

    def _require_bronze_ingestion_config_columns(self, required_columns):
        existing = self._get_bronze_ingestion_config_columns()
        missing = [col for col in required_columns if col not in existing]
        if missing:
            raise ValueError(
                "metadata.bronze_ingestion_config is missing columns: "
                f"{missing}. Re-run init_metadata_layer to apply migrations."
            )

    def _require_dependency_columns(self, required_columns):
        existing = self._get_dependency_columns()
        missing = [col for col in required_columns if col not in existing]
        if missing:
            raise ValueError(
                "metadata.pipeline_dependency is missing columns: "
                f"{missing}. Re-run init_metadata_layer to apply migrations."
            )

    def _get_task_run_columns(self):
        if self._task_run_columns is not None:
            return self._task_run_columns
        try:
            self._task_run_columns = {
                row[0]
                for row in self.spark.sql("DESCRIBE metadata.task_run").collect()
                if row[0] and not row[0].startswith("#")
            }
        except Exception:
            self._task_run_columns = set()
        return self._task_run_columns

    def _require_task_run_columns(self, required_columns):
        existing = self._get_task_run_columns()
        missing = [col for col in required_columns if col not in existing]
        if missing:
            raise ValueError(
                "metadata.task_run is missing columns: "
                f"{missing}. Re-run init_metadata_layer to apply migrations."
            )

    def _dependency_node(self, pipeline_name, dataset=None):
        dataset_part = dataset if dataset is not None else "*"
        return f"{pipeline_name}::{dataset_part}"

    def _parse_dependency_node(self, node):
        pipeline_name, dataset = node.split("::", 1)
        return {
            "pipeline_name": pipeline_name,
            "dataset": None if dataset == "*" else dataset,
        }

    def _fetch_dependencies(self, child_pipeline, child_dataset=None):
        child = self._clean(child_pipeline)
        if child is None:
            raise ValueError("pipeline_name is required")
        child_ds = self._clean(child_dataset)

        cols = self._get_dependency_columns()
        parent_dataset_expr = "parent_dataset" if "parent_dataset" in cols else "NULL as parent_dataset"
        child_dataset_expr = "child_dataset" if "child_dataset" in cols else "NULL as child_dataset"
        mode_expr = "dependency_mode" if "dependency_mode" in cols else "'hard' as dependency_mode"
        freshness_expr = "freshness_hours" if "freshness_hours" in cols else "NULL as freshness_hours"

        if child_ds is None:
            dataset_filter = ""
        elif "child_dataset" in cols:
            dataset_filter = f"AND (child_dataset IS NULL OR child_dataset = '{child_ds}')"
        else:
            dataset_filter = ""

        rows = self.spark.sql(f"""
        SELECT
            parent_pipeline,
            {parent_dataset_expr},
            child_pipeline,
            {child_dataset_expr},
            {mode_expr},
            {freshness_expr}
        FROM metadata.pipeline_dependency
        WHERE child_pipeline = '{child}'
        {dataset_filter}
        ORDER BY parent_pipeline
        """).collect()

        return [
            {
                "parent_pipeline": row[0],
                "parent_dataset": row[1],
                "child_pipeline": row[2],
                "child_dataset": row[3],
                "dependency_mode": self._normalize_dependency_mode(row[4]),
                "freshness_hours": int(row[5]) if row[5] is not None else None,
            }
            for row in rows
        ]

    def _get_dataset_execution_policy(self, dataset):
        dataset_clean = self._clean(dataset)
        if dataset_clean is None:
            return None

        self._require_dataset_execution_policy_columns(
            {
                "dataset",
                "min_interval_minutes",
                "schedule_expr",
                "timezone",
                "skip_if_fresh",
                "is_active",
            }
        )

        rows = self.spark.sql(f"""
        SELECT
            dataset,
            min_interval_minutes,
            schedule_expr,
            timezone,
            COALESCE(skip_if_fresh, true) AS skip_if_fresh,
            COALESCE(is_active, true) AS is_active,
            created_ts,
            updated_ts
        FROM metadata.dataset_execution_policy
        WHERE dataset = '{dataset_clean}'
        ORDER BY updated_ts DESC
        LIMIT 1
        """).collect()

        if not rows:
            return None

        row = rows[0]
        return {
            "dataset": row[0],
            "min_interval_minutes": int(row[1]) if row[1] is not None else None,
            "schedule_expr": row[2],
            "timezone": row[3],
            "skip_if_fresh": bool(row[4]) if row[4] is not None else True,
            "is_active": bool(row[5]) if row[5] is not None else True,
            "created_ts": row[6],
            "updated_ts": row[7],
        }

    def _get_last_successful_task_run_for_dataset(self, dataset):
        dataset_clean = self._clean(dataset)
        if dataset_clean is None:
            return None

        self._require_task_run_columns({"dataset"})

        rows = self.spark.sql(f"""
        SELECT
            t.task_run_id,
            t.run_id,
            r.pipeline_name,
            t.dataset,
            t.start_ts,
            t.end_ts
        FROM metadata.task_run t
        LEFT JOIN metadata.run r
            ON t.run_id = r.run_id
        WHERE t.dataset = '{dataset_clean}'
          AND t.status = 'SUCCESS'
        ORDER BY COALESCE(t.end_ts, t.start_ts) DESC
        LIMIT 1
        """).collect()

        if not rows:
            return None

        row = rows[0]
        return {
            "task_run_id": row[0],
            "run_id": row[1],
            "pipeline_name": row[2],
            "dataset": row[3],
            "start_ts": row[4],
            "end_ts": row[5],
        }

    def _get_last_run(self, pipeline_name, dataset=None, success_only=False):
        pipeline = self._clean(pipeline_name)
        dataset_clean = self._clean(dataset)
        status_filter = "AND r.status = 'SUCCESS'" if success_only else ""

        if dataset_clean is None:
            rows = self.spark.sql(f"""
            SELECT r.run_id, r.status, r.start_ts, r.end_ts
            FROM metadata.run r
            WHERE r.pipeline_name = '{pipeline}'
            {status_filter}
            ORDER BY r.start_ts DESC
            LIMIT 1
            """).collect()
        else:
            self._require_task_run_columns({"dataset"})
            rows = self.spark.sql(f"""
            SELECT r.run_id, r.status, r.start_ts, r.end_ts
            FROM metadata.run r
            WHERE r.pipeline_name = '{pipeline}'
            {status_filter}
              AND r.run_id IN (
                  SELECT DISTINCT t.run_id
                  FROM metadata.task_run t
                  WHERE t.dataset = '{dataset_clean}'
              )
            ORDER BY r.start_ts DESC
            LIMIT 1
            """).collect()

        if not rows:
            return None
        row = rows[0]
        return {
            "run_id": row[0],
            "status": row[1],
            "start_ts": row[2],
            "end_ts": row[3],
        }

    def _get_run_change_stats(self, run_id, dataset=None):
        run = self._clean(run_id)
        dataset_clean = self._clean(dataset)

        if dataset_clean is None:
            rows = self.spark.sql(f"""
            SELECT
                SUM(COALESCE(rows_inserted, 0)) AS rows_inserted,
                SUM(COALESCE(rows_updated, 0)) AS rows_updated,
                SUM(COALESCE(rows_deleted, 0)) AS rows_deleted,
                SUM(COALESCE(rows_out, 0))      AS rows_out
            FROM metadata.task_run
            WHERE run_id = '{run}'
            """).collect()
        else:
            self._require_task_run_columns({"dataset"})
            rows = self.spark.sql(f"""
            SELECT
                SUM(COALESCE(rows_inserted, 0)) AS rows_inserted,
                SUM(COALESCE(rows_updated, 0)) AS rows_updated,
                SUM(COALESCE(rows_deleted, 0)) AS rows_deleted,
                SUM(COALESCE(rows_out, 0))      AS rows_out
            FROM metadata.task_run
            WHERE run_id = '{run}'
              AND dataset = '{dataset_clean}'
            """).collect()

        row = rows[0]
        return {
            "rows_inserted": int(row[0] or 0),
            "rows_updated": int(row[1] or 0),
            "rows_deleted": int(row[2] or 0),
            "rows_out": int(row[3] or 0),
        }

    # -------------------------------------
    # Dependency CRUD
    # -------------------------------------

    def add_dependency(
        self,
        parent_pipeline,
        child_pipeline,
        parent_dataset=None,
        child_dataset=None,
        dependency_mode="hard",
        freshness_hours=None,
        validate_cycles=True,
    ):
        parent = self._clean(parent_pipeline)
        child = self._clean(child_pipeline)
        parent_ds = self._clean(parent_dataset)
        child_ds = self._clean(child_dataset)
        mode = self._normalize_dependency_mode(dependency_mode)
        freshness = self._normalize_freshness_hours(freshness_hours)

        if not parent or not child:
            raise ValueError("parent_pipeline and child_pipeline are required")
        if parent == child and parent_ds == child_ds:
            raise ValueError("A pipeline/dataset node cannot depend on itself")

        advanced_requested = (
            parent_ds is not None
            or child_ds is not None
            or mode != "hard"
            or freshness is not None
        )
        if advanced_requested:
            self._require_dependency_columns(
                {"parent_dataset", "child_dataset", "dependency_mode", "freshness_hours"}
            )

        cols = self._get_dependency_columns()
        insert_columns = ["parent_pipeline", "child_pipeline"]
        insert_values = [f"'{parent}'", f"'{child}'"]
        match_conditions = [f"parent_pipeline = '{parent}'", f"child_pipeline = '{child}'"]

        if "parent_dataset" in cols:
            insert_columns.append("parent_dataset")
            insert_values.append(self._sql_str_or_null(parent_ds))
            if parent_ds is None:
                match_conditions.append("parent_dataset IS NULL")
            else:
                match_conditions.append(f"parent_dataset = '{parent_ds}'")

        if "child_dataset" in cols:
            insert_columns.append("child_dataset")
            insert_values.append(self._sql_str_or_null(child_ds))
            if child_ds is None:
                match_conditions.append("child_dataset IS NULL")
            else:
                match_conditions.append(f"child_dataset = '{child_ds}'")

        if "dependency_mode" in cols:
            insert_columns.append("dependency_mode")
            insert_values.append(f"'{mode}'")
            match_conditions.append(f"dependency_mode = '{mode}'")

        if "freshness_hours" in cols:
            insert_columns.append("freshness_hours")
            insert_values.append("NULL" if freshness is None else str(freshness))
            if freshness is None:
                match_conditions.append("freshness_hours IS NULL")
            else:
                match_conditions.append(f"freshness_hours = {freshness}")

        self.spark.sql(f"""
        INSERT INTO metadata.pipeline_dependency ({', '.join(insert_columns)})
        SELECT {', '.join(insert_values)}
        WHERE NOT EXISTS (
            SELECT 1
            FROM metadata.pipeline_dependency
            WHERE {' AND '.join(match_conditions)}
        )
        """)

        if validate_cycles:
            cycles = self.detect_cycles()
            if cycles:
                self.remove_dependency(
                    parent_pipeline=parent,
                    child_pipeline=child,
                    parent_dataset=parent_ds,
                    child_dataset=child_ds,
                    dependency_mode=mode if "dependency_mode" in cols else None,
                    freshness_hours=freshness if "freshness_hours" in cols else None,
                )
                sample_cycle = " -> ".join(cycles[0])
                raise ValueError(
                    "Dependency would create a cycle. "
                    f"Example cycle: {sample_cycle}"
                )

    def remove_dependency(
        self,
        parent_pipeline,
        child_pipeline,
        parent_dataset=None,
        child_dataset=None,
        dependency_mode=None,
        freshness_hours=None,
    ):
        parent = self._clean(parent_pipeline)
        child = self._clean(child_pipeline)
        parent_ds = self._clean(parent_dataset)
        child_ds = self._clean(child_dataset)
        mode = self._clean(dependency_mode)
        freshness = None if freshness_hours is None else int(freshness_hours)

        where = [f"parent_pipeline = '{parent}'", f"child_pipeline = '{child}'"]
        cols = self._get_dependency_columns()

        if "parent_dataset" in cols and parent_dataset is not None:
            where.append(f"parent_dataset = '{parent_ds}'")
        if "child_dataset" in cols and child_dataset is not None:
            where.append(f"child_dataset = '{child_ds}'")
        if "dependency_mode" in cols and dependency_mode is not None:
            where.append(f"dependency_mode = '{mode}'")
        if "freshness_hours" in cols and freshness_hours is not None:
            where.append(f"freshness_hours = {freshness}")

        self.spark.sql(f"""
        DELETE FROM metadata.pipeline_dependency
        WHERE {' AND '.join(where)}
        """)

    def list_dependencies(self, pipeline_name=None, direction="child", dataset=None):
        normalized_direction = str(direction).lower().strip()
        if normalized_direction not in {"child", "parent"}:
            raise ValueError("direction must be 'child' or 'parent'")

        cols = self._get_dependency_columns()
        parent_dataset_expr = "parent_dataset" if "parent_dataset" in cols else "NULL as parent_dataset"
        child_dataset_expr = "child_dataset" if "child_dataset" in cols else "NULL as child_dataset"
        mode_expr = "dependency_mode" if "dependency_mode" in cols else "'hard' as dependency_mode"
        freshness_expr = "freshness_hours" if "freshness_hours" in cols else "NULL as freshness_hours"

        where_clauses = []
        if pipeline_name is not None:
            pipeline = self._clean(pipeline_name)
            field = "child_pipeline" if normalized_direction == "child" else "parent_pipeline"
            where_clauses.append(f"{field} = '{pipeline}'")

            dataset_clean = self._clean(dataset)
            if dataset_clean is not None:
                if normalized_direction == "child" and "child_dataset" in cols:
                    where_clauses.append(f"(child_dataset IS NULL OR child_dataset = '{dataset_clean}')")
                if normalized_direction == "parent" and "parent_dataset" in cols:
                    where_clauses.append(f"(parent_dataset IS NULL OR parent_dataset = '{dataset_clean}')")

        where_sql = ""
        if where_clauses:
            where_sql = "WHERE " + " AND ".join(where_clauses)

        order_sql = "ORDER BY child_pipeline, parent_pipeline"
        if normalized_direction == "child":
            order_sql = "ORDER BY child_pipeline, child_dataset, parent_pipeline, parent_dataset"
        elif normalized_direction == "parent":
            order_sql = "ORDER BY parent_pipeline, parent_dataset, child_pipeline, child_dataset"

        rows = self.spark.sql(f"""
        SELECT
            parent_pipeline,
            {parent_dataset_expr},
            child_pipeline,
            {child_dataset_expr},
            {mode_expr},
            {freshness_expr}
        FROM metadata.pipeline_dependency
        {where_sql}
        {order_sql}
        """).collect()

        return [
            {
                "parent_pipeline": row[0],
                "parent_dataset": row[1],
                "child_pipeline": row[2],
                "child_dataset": row[3],
                "dependency_mode": self._normalize_dependency_mode(row[4]),
                "freshness_hours": int(row[5]) if row[5] is not None else None,
            }
            for row in rows
        ]

    # -------------------------------------
    # Dataset execution policy CRUD
    # -------------------------------------

    def add_dataset_execution_policy(
        self,
        dataset,
        min_interval_minutes=None,
        schedule_expr=None,
        timezone=None,
        skip_if_fresh=True,
        is_active=True,
    ):
        self._require_dataset_execution_policy_columns(
            {
                "dataset",
                "min_interval_minutes",
                "schedule_expr",
                "timezone",
                "skip_if_fresh",
                "is_active",
                "created_ts",
                "updated_ts",
            }
        )

        dataset_clean = self._clean(dataset)
        interval = self._normalize_min_interval_minutes(min_interval_minutes)
        schedule = self._clean(schedule_expr)
        timezone_clean = self._clean(timezone)
        skip = self._normalize_is_active(skip_if_fresh)
        active = self._normalize_is_active(is_active)

        if not dataset_clean:
            raise ValueError("dataset is required")
        if interval is None and not schedule:
            raise ValueError("min_interval_minutes or schedule_expr is required")

        interval_expr = "NULL" if interval is None else str(interval)

        self.spark.sql(f"""
        MERGE INTO metadata.dataset_execution_policy t
        USING (
            SELECT
                '{dataset_clean}' AS dataset,
                {interval_expr} AS min_interval_minutes,
                {self._sql_str_or_null(schedule)} AS schedule_expr,
                {self._sql_str_or_null(timezone_clean)} AS timezone,
                {str(skip).upper()} AS skip_if_fresh,
                {str(active).upper()} AS is_active,
                current_timestamp() AS current_ts
        ) s
        ON t.dataset = s.dataset
        WHEN MATCHED THEN UPDATE SET
            min_interval_minutes = s.min_interval_minutes,
            schedule_expr = s.schedule_expr,
            timezone = s.timezone,
            skip_if_fresh = s.skip_if_fresh,
            is_active = s.is_active,
            updated_ts = s.current_ts
        WHEN NOT MATCHED THEN INSERT (
            dataset,
            min_interval_minutes,
            schedule_expr,
            timezone,
            skip_if_fresh,
            is_active,
            created_ts,
            updated_ts
        ) VALUES (
            s.dataset,
            s.min_interval_minutes,
            s.schedule_expr,
            s.timezone,
            s.skip_if_fresh,
            s.is_active,
            s.current_ts,
            s.current_ts
        )
        """)

    def remove_dataset_execution_policy(self, dataset):
        dataset_clean = self._clean(dataset)
        if not dataset_clean:
            raise ValueError("dataset is required")

        self.spark.sql(f"""
        DELETE FROM metadata.dataset_execution_policy
        WHERE dataset = '{dataset_clean}'
        """)

    def list_dataset_execution_policies(self, dataset=None, active_only=True):
        self._require_dataset_execution_policy_columns(
            {
                "dataset",
                "min_interval_minutes",
                "schedule_expr",
                "timezone",
                "skip_if_fresh",
                "is_active",
            }
        )

        where = []
        if dataset is not None:
            dataset_clean = self._clean(dataset)
            where.append(f"dataset = '{dataset_clean}'")
        if active_only:
            where.append("COALESCE(is_active, true) = true")

        where_sql = ""
        if where:
            where_sql = "WHERE " + " AND ".join(where)

        rows = self.spark.sql(f"""
        SELECT
            dataset,
            min_interval_minutes,
            schedule_expr,
            timezone,
            COALESCE(skip_if_fresh, true) AS skip_if_fresh,
            COALESCE(is_active, true) AS is_active,
            created_ts,
            updated_ts
        FROM metadata.dataset_execution_policy
        {where_sql}
        ORDER BY dataset
        """).collect()

        return [
            {
                "dataset": row[0],
                "min_interval_minutes": int(row[1]) if row[1] is not None else None,
                "schedule_expr": row[2],
                "timezone": row[3],
                "skip_if_fresh": bool(row[4]) if row[4] is not None else True,
                "is_active": bool(row[5]) if row[5] is not None else True,
                "created_ts": row[6],
                "updated_ts": row[7],
            }
            for row in rows
        ]

    def get_dataset_execution_decision(self, dataset, reference_ts=None, pipeline_name=None):
        pipeline = self._clean(pipeline_name)
        dataset_clean = self._clean(dataset)
        if not dataset_clean:
            return {
                "pipeline_name": pipeline,
                "dataset": None,
                "has_dataset_execution_policy": False,
                "dataset_execution_policy_active": False,
                "should_process": True,
                "decision": "PROCESS",
                "reason": "dataset_not_defined",
            }

        try:
            policy = self._get_dataset_execution_policy(dataset_clean)
        except ValueError as exc:
            if "metadata.dataset_execution_policy is missing columns" not in str(exc):
                raise
            return {
                "pipeline_name": pipeline,
                "dataset": dataset_clean,
                "has_dataset_execution_policy": False,
                "dataset_execution_policy_active": False,
                "should_process": True,
                "decision": "PROCESS",
                "reason": "policy_table_unavailable",
                "message": str(exc),
            }

        if policy is None:
            return {
                "pipeline_name": pipeline,
                "dataset": dataset_clean,
                "has_dataset_execution_policy": False,
                "dataset_execution_policy_active": False,
                "should_process": True,
                "decision": "PROCESS",
                "reason": "policy_not_configured",
            }

        if not policy["is_active"]:
            return {
                "pipeline_name": pipeline,
                "dataset": dataset_clean,
                "has_dataset_execution_policy": True,
                "dataset_execution_policy_active": False,
                "should_process": True,
                "decision": "PROCESS",
                "reason": "policy_inactive",
                "policy": policy,
            }

        if not policy["skip_if_fresh"] or policy["min_interval_minutes"] is None:
            return {
                "pipeline_name": pipeline,
                "dataset": dataset_clean,
                "has_dataset_execution_policy": True,
                "dataset_execution_policy_active": True,
                "should_process": True,
                "decision": "PROCESS",
                "reason": "freshness_skip_disabled",
                "policy": policy,
            }

        last_success = self._get_last_successful_task_run_for_dataset(dataset_clean)
        if last_success is None:
            return {
                "pipeline_name": pipeline,
                "dataset": dataset_clean,
                "has_dataset_execution_policy": True,
                "dataset_execution_policy_active": True,
                "should_process": True,
                "decision": "PROCESS",
                "reason": "dataset_never_succeeded",
                "policy": policy,
            }

        last_success_ts = last_success["end_ts"] or last_success["start_ts"]
        if last_success_ts is None:
            return {
                "pipeline_name": pipeline,
                "dataset": dataset_clean,
                "has_dataset_execution_policy": True,
                "dataset_execution_policy_active": True,
                "should_process": True,
                "decision": "PROCESS",
                "reason": "last_success_without_timestamp",
                "policy": policy,
                "last_success": last_success,
            }

        now = reference_ts or datetime.utcnow()
        elapsed = now.replace(tzinfo=None) - last_success_ts.replace(tzinfo=None)
        min_interval = timedelta(minutes=policy["min_interval_minutes"])
        next_eligible_ts = last_success_ts.replace(tzinfo=None) + min_interval

        if elapsed < min_interval:
            return {
                "pipeline_name": pipeline,
                "dataset": dataset_clean,
                "has_dataset_execution_policy": True,
                "dataset_execution_policy_active": True,
                "should_process": False,
                "decision": "SKIP_FRESH",
                "reason": "dataset_loaded_within_min_interval",
                "policy": policy,
                "last_success": last_success,
                "last_success_ts": last_success_ts,
                "reused_run_id": last_success["run_id"],
                "reused_task_run_id": last_success["task_run_id"],
                "min_interval_minutes": policy["min_interval_minutes"],
                "next_eligible_ts": next_eligible_ts,
            }

        return {
            "pipeline_name": pipeline,
            "dataset": dataset_clean,
            "has_dataset_execution_policy": True,
            "dataset_execution_policy_active": True,
            "should_process": True,
            "decision": "PROCESS",
            "reason": "dataset_stale",
            "policy": policy,
            "last_success": last_success,
            "last_success_ts": last_success_ts,
            "min_interval_minutes": policy["min_interval_minutes"],
            "next_eligible_ts": next_eligible_ts,
        }

    # -------------------------------------
    # Pipeline execution config CRUD
    # -------------------------------------

    def add_fabric_pipeline_config(
        self,
        pipeline_name,
        group_id,
        pipeline_id,
        parameters=None,
        medallion_layer=None,
        is_active=True,
    ):
        self.add_pipeline_execution_config(
            pipeline_name=pipeline_name,
            medallion_layer=medallion_layer,
            execution_engine="fabric",
            fabric_group_id=group_id,
            fabric_pipeline_id=pipeline_id,
            parameters=parameters,
            is_active=is_active,
        )

    def add_databricks_pipeline_config(
        self,
        pipeline_name,
        workspace,
        path,
        parameters=None,
        medallion_layer=None,
        is_active=True,
    ):
        self.add_pipeline_execution_config(
            pipeline_name=pipeline_name,
            medallion_layer=medallion_layer,
            execution_engine="databricks",
            databricks_workspace=workspace,
            databricks_path=path,
            parameters=parameters,
            is_active=is_active,
        )

    def add_pipeline_execution_config(
        self,
        pipeline_name,
        execution_engine,
        fabric_group_id=None,
        fabric_pipeline_id=None,
        databricks_workspace=None,
        databricks_path=None,
        parameters=None,
        medallion_layer=None,
        is_active=True,
    ):
        self._require_pipeline_execution_config_columns(
            {
                "pipeline_name",
                "medallion_layer",
                "execution_engine",
                "fabric_group_id",
                "fabric_pipeline_id",
                "databricks_workspace",
                "databricks_path",
                "parameters_json",
                "is_active",
                "created_ts",
                "updated_ts",
            }
        )

        pipeline = self._clean(pipeline_name)
        layer = self._normalize_medallion_layer(medallion_layer)
        engine = self._normalize_execution_engine(execution_engine)
        active = self._normalize_is_active(is_active)

        fabric_group = self._clean(fabric_group_id)
        fabric_pipeline = self._clean(fabric_pipeline_id)
        db_workspace = self._clean(databricks_workspace)
        db_path = self._clean(databricks_path)

        if not pipeline:
            raise ValueError("pipeline_name is required")
        if engine == "fabric" and (not fabric_group or not fabric_pipeline):
            raise ValueError("Fabric pipelines require group_id and pipeline_id")
        if engine == "databricks" and (not db_workspace or not db_path):
            raise ValueError("Databricks pipelines require workspace and path")

        self.spark.sql(f"""
        MERGE INTO metadata.pipeline_execution_config t
        USING (
            SELECT
                {self._sql_literal_or_null(pipeline)} AS pipeline_name,
                {self._sql_literal_or_null(layer)} AS medallion_layer,
                '{engine}' AS execution_engine,
                {self._sql_literal_or_null(fabric_group)} AS fabric_group_id,
                {self._sql_literal_or_null(fabric_pipeline)} AS fabric_pipeline_id,
                {self._sql_literal_or_null(db_workspace)} AS databricks_workspace,
                {self._sql_literal_or_null(db_path)} AS databricks_path,
                {self._parameters_json_or_null(parameters)} AS parameters_json,
                {str(active).upper()} AS is_active,
                current_timestamp() AS current_ts
        ) s
        ON t.pipeline_name = s.pipeline_name
        WHEN MATCHED THEN UPDATE SET
            medallion_layer = s.medallion_layer,
            execution_engine = s.execution_engine,
            fabric_group_id = s.fabric_group_id,
            fabric_pipeline_id = s.fabric_pipeline_id,
            databricks_workspace = s.databricks_workspace,
            databricks_path = s.databricks_path,
            parameters_json = s.parameters_json,
            is_active = s.is_active,
            updated_ts = s.current_ts
        WHEN NOT MATCHED THEN INSERT (
            pipeline_name,
            medallion_layer,
            execution_engine,
            fabric_group_id,
            fabric_pipeline_id,
            databricks_workspace,
            databricks_path,
            parameters_json,
            is_active,
            created_ts,
            updated_ts
        ) VALUES (
            s.pipeline_name,
            s.medallion_layer,
            s.execution_engine,
            s.fabric_group_id,
            s.fabric_pipeline_id,
            s.databricks_workspace,
            s.databricks_path,
            s.parameters_json,
            s.is_active,
            s.current_ts,
            s.current_ts
        )
        """)

    def remove_pipeline_execution_config(self, pipeline_name):
        pipeline = self._clean(pipeline_name)
        if not pipeline:
            raise ValueError("pipeline_name is required")

        self.spark.sql(f"""
        DELETE FROM metadata.pipeline_execution_config
        WHERE pipeline_name = '{pipeline}'
        """)

    def list_pipeline_execution_configs(
        self,
        pipeline_name=None,
        execution_engine=None,
        medallion_layer=None,
        active_only=True,
    ):
        self._require_pipeline_execution_config_columns(
            {
                "pipeline_name",
                "medallion_layer",
                "execution_engine",
                "fabric_group_id",
                "fabric_pipeline_id",
                "databricks_workspace",
                "databricks_path",
                "parameters_json",
                "is_active",
            }
        )

        where = []
        if pipeline_name is not None:
            pipeline = self._clean(pipeline_name)
            where.append(f"pipeline_name = '{pipeline}'")
        if medallion_layer is not None:
            layer = self._normalize_medallion_layer(medallion_layer)
            where.append(f"medallion_layer = '{layer}'")
        if execution_engine is not None:
            engine = self._normalize_execution_engine(execution_engine)
            where.append(f"execution_engine = '{engine}'")
        if active_only:
            where.append("COALESCE(is_active, true) = true")

        where_sql = ""
        if where:
            where_sql = "WHERE " + " AND ".join(where)

        rows = self.spark.sql(f"""
        SELECT
            pipeline_name,
            medallion_layer,
            execution_engine,
            fabric_group_id,
            fabric_pipeline_id,
            databricks_workspace,
            databricks_path,
            parameters_json,
            COALESCE(is_active, true) AS is_active,
            created_ts,
            updated_ts
        FROM metadata.pipeline_execution_config
        {where_sql}
        ORDER BY pipeline_name
        """).collect()

        return [
            {
                "pipeline_name": row[0],
                "medallion_layer": row[1],
                "execution_engine": row[2],
                "fabric_group_id": row[3],
                "fabric_pipeline_id": row[4],
                "databricks_workspace": row[5],
                "databricks_path": row[6],
                "parameters_json": row[7],
                "is_active": bool(row[8]) if row[8] is not None else True,
                "created_ts": row[9],
                "updated_ts": row[10],
            }
            for row in rows
        ]

    def get_pipeline_execution_config(self, pipeline_name, active_only=True):
        configs = self.list_pipeline_execution_configs(
            pipeline_name=pipeline_name,
            active_only=active_only,
        )
        if not configs:
            raise ValueError(f"Pipeline '{pipeline_name}' has no active execution config")
        if len(configs) > 1:
            raise ValueError(f"Pipeline '{pipeline_name}' has multiple execution configs")
        config = configs[0]
        config["parameters"] = self._parse_parameters_json(config.get("parameters_json"))
        return config

    # -------------------------------------
    # Bronze ingestion config CRUD
    # -------------------------------------

    def add_connection_config(
        self,
        connection_key,
        fabric_connection_id,
        connection_type,
        description=None,
        is_active=True,
    ):
        self._require_connection_config_columns(
            {
                "connection_key",
                "fabric_connection_id",
                "connection_type",
                "description",
                "is_active",
                "created_ts",
                "updated_ts",
            }
        )

        key = self._clean(connection_key)
        fabric_id = self._clean(fabric_connection_id)
        conn_type = self._clean(connection_type)
        description_clean = self._clean(description)
        active = self._normalize_is_active(is_active)

        if not key:
            raise ValueError("connection_key is required")
        if not conn_type:
            raise ValueError("connection_type is required")

        self.spark.sql(f"""
        MERGE INTO metadata.connection_config t
        USING (
            SELECT
                {self._sql_literal_or_null(key)} AS connection_key,
                {self._sql_literal_or_null(fabric_id)} AS fabric_connection_id,
                {self._sql_literal_or_null(conn_type)} AS connection_type,
                {self._sql_literal_or_null(description_clean)} AS description,
                {str(active).upper()} AS is_active,
                current_timestamp() AS current_ts
        ) s
        ON t.connection_key = s.connection_key
        WHEN MATCHED THEN UPDATE SET
            fabric_connection_id = s.fabric_connection_id,
            connection_type = s.connection_type,
            description = s.description,
            is_active = s.is_active,
            updated_ts = s.current_ts
        WHEN NOT MATCHED THEN INSERT (
            connection_key,
            fabric_connection_id,
            connection_type,
            description,
            is_active,
            created_ts,
            updated_ts
        ) VALUES (
            s.connection_key,
            s.fabric_connection_id,
            s.connection_type,
            s.description,
            s.is_active,
            s.current_ts,
            s.current_ts
        )
        """)

    def add_bronze_ingestion_config(
        self,
        dataset,
        source_connection_key,
        source_database,
        source_schema,
        source_table,
        source_query,
        sink_path_template,
        sink_connection_key="adls_bronze",
        source_connection_type="SQL Server",
        sink_connection_type="Azure Data Lake Storage Gen2",
        sink_file_format="Parquet",
        is_cdc=False,
        is_active=True,
    ):
        self._require_bronze_ingestion_config_columns(
            {
                "dataset",
                "source_connection_key",
                "source_connection_type",
                "source_database",
                "source_schema",
                "source_table",
                "source_query",
                "sink_connection_key",
                "sink_connection_type",
                "sink_path_template",
                "sink_file_format",
                "is_cdc",
                "is_active",
                "created_ts",
                "updated_ts",
            }
        )

        dataset_clean = self._clean(dataset)
        source_key = self._clean(source_connection_key)
        source_type = self._clean(source_connection_type)
        database = self._clean(source_database)
        schema = self._clean(source_schema)
        table = self._clean(source_table)
        query = str(source_query).strip() if source_query is not None else None
        sink_key = self._clean(sink_connection_key)
        sink_type = self._clean(sink_connection_type)
        sink_path = str(sink_path_template).strip() if sink_path_template is not None else None
        file_format = self._clean(sink_file_format)
        cdc = self._normalize_is_active(is_cdc)
        active = self._normalize_is_active(is_active)

        if not dataset_clean:
            raise ValueError("dataset is required")
        if not source_key:
            raise ValueError("source_connection_key is required")
        if not database:
            raise ValueError("source_database is required")
        if not schema:
            raise ValueError("source_schema is required")
        if not table:
            raise ValueError("source_table is required")
        if not query:
            raise ValueError("source_query is required")
        if not sink_key:
            raise ValueError("sink_connection_key is required")
        if not sink_path:
            raise ValueError("sink_path_template is required")

        self.spark.sql(f"""
        MERGE INTO metadata.bronze_ingestion_config t
        USING (
            SELECT
                {self._sql_literal_or_null(dataset_clean)} AS dataset,
                {self._sql_literal_or_null(source_key)} AS source_connection_key,
                {self._sql_literal_or_null(source_type)} AS source_connection_type,
                {self._sql_literal_or_null(database)} AS source_database,
                {self._sql_literal_or_null(schema)} AS source_schema,
                {self._sql_literal_or_null(table)} AS source_table,
                {self._sql_literal_or_null(query)} AS source_query,
                {self._sql_literal_or_null(sink_key)} AS sink_connection_key,
                {self._sql_literal_or_null(sink_type)} AS sink_connection_type,
                {self._sql_literal_or_null(sink_path)} AS sink_path_template,
                {self._sql_literal_or_null(file_format)} AS sink_file_format,
                {str(cdc).upper()} AS is_cdc,
                {str(active).upper()} AS is_active,
                current_timestamp() AS current_ts
        ) s
        ON t.dataset = s.dataset
        WHEN MATCHED THEN UPDATE SET
            source_connection_key = s.source_connection_key,
            source_connection_type = s.source_connection_type,
            source_database = s.source_database,
            source_schema = s.source_schema,
            source_table = s.source_table,
            source_query = s.source_query,
            sink_connection_key = s.sink_connection_key,
            sink_connection_type = s.sink_connection_type,
            sink_path_template = s.sink_path_template,
            sink_file_format = s.sink_file_format,
            is_cdc = s.is_cdc,
            is_active = s.is_active,
            updated_ts = s.current_ts
        WHEN NOT MATCHED THEN INSERT (
            dataset,
            source_connection_key,
            source_connection_type,
            source_database,
            source_schema,
            source_table,
            source_query,
            sink_connection_key,
            sink_connection_type,
            sink_path_template,
            sink_file_format,
            is_cdc,
            is_active,
            created_ts,
            updated_ts
        ) VALUES (
            s.dataset,
            s.source_connection_key,
            s.source_connection_type,
            s.source_database,
            s.source_schema,
            s.source_table,
            s.source_query,
            s.sink_connection_key,
            s.sink_connection_type,
            s.sink_path_template,
            s.sink_file_format,
            s.is_cdc,
            s.is_active,
            s.current_ts,
            s.current_ts
        )
        """)

    def _resolve_execution_step(self, step=None, pipeline_name=None, dataset=None):
        if step is None:
            step = {}
        pipeline = self._clean(pipeline_name or step.get("pipeline_name"))
        dataset_clean = self._clean(dataset or step.get("dataset"))

        if not pipeline:
            raise ValueError("pipeline_name is required")

        resolved = dict(step)
        resolved["pipeline_name"] = pipeline
        resolved["dataset"] = dataset_clean
        return resolved

    def _build_execution_parameters(self, config, step, runtime_parameters=None):
        parameters = {}
        parameters.update(config.get("parameters") or {})
        parameters.update({
            "pipeline_name": step["pipeline_name"],
            "dataset": step.get("dataset"),
        })
        if step.get("group_name") is not None:
            parameters["group_name"] = step.get("group_name")
        if step.get("step") is not None:
            parameters["orchestrator_step"] = step.get("step")
        if runtime_parameters:
            parameters.update(runtime_parameters)
        return parameters

    def execute_dataset(
        self,
        step=None,
        pipeline_name=None,
        dataset=None,
        runtime_parameters=None,
        fabric_token=None,
        databricks_token=None,
        timeout=60,
        dry_run=False,
    ):
        step = self._resolve_execution_step(
            step=step,
            pipeline_name=pipeline_name,
            dataset=dataset,
        )
        config = self.get_pipeline_execution_config(step["pipeline_name"])
        parameters = self._build_execution_parameters(
            config=config,
            step=step,
            runtime_parameters=runtime_parameters,
        )

        engine = self._normalize_execution_engine(config["execution_engine"])
        if engine == "fabric":
            return self._execute_fabric_pipeline(
                config=config,
                parameters=parameters,
                token=fabric_token,
                timeout=timeout,
                dry_run=dry_run,
            )
        if engine == "databricks":
            return self._execute_databricks_notebook(
                config=config,
                parameters=parameters,
                token=databricks_token,
                timeout=timeout,
                dry_run=dry_run,
            )

        raise ValueError(f"Unsupported execution_engine: {engine}")

    def _execute_fabric_pipeline(self, config, parameters, token=None, timeout=60, dry_run=False):
        group_id = self._clean(config.get("fabric_group_id"))
        pipeline_id = self._clean(config.get("fabric_pipeline_id"))
        if not group_id or not pipeline_id:
            raise ValueError("Fabric execution config requires fabric_group_id and fabric_pipeline_id")

        url = (
            "https://api.fabric.microsoft.com/v1/"
            f"workspaces/{group_id}/items/{pipeline_id}/jobs/instances?jobType=Pipeline"
        )
        payload = {
            "executionData": {
                "parameters": parameters,
            }
        }

        if dry_run:
            return {
                "execution_engine": "fabric",
                "url": url,
                "payload": payload,
                "dry_run": True,
            }

        bearer_token = token or os.getenv("GSS_SPARK_FLOW_FABRIC_TOKEN") or os.getenv("FABRIC_TOKEN")
        response = self._http_json("POST", url, bearer_token, payload=payload, timeout=timeout)
        return {
            "execution_engine": "fabric",
            "pipeline_name": config["pipeline_name"],
            "fabric_group_id": group_id,
            "fabric_pipeline_id": pipeline_id,
            "response": response,
        }

    def _execute_databricks_notebook(self, config, parameters, token=None, timeout=60, dry_run=False):
        workspace = self._clean(config.get("databricks_workspace"))
        notebook_path = self._clean(config.get("databricks_path"))
        if not workspace or not notebook_path:
            raise ValueError("Databricks execution config requires databricks_workspace and databricks_path")

        databricks_job_id = parameters.get("databricks_job_id") or parameters.get("job_id")
        existing_cluster_id = parameters.get("existing_cluster_id")
        new_cluster = parameters.get("new_cluster")
        libraries = parameters.get("libraries")
        timeout_seconds = parameters.get("timeout_seconds")
        infrastructure_keys = {
            "databricks_job_id",
            "job_id",
            "existing_cluster_id",
            "new_cluster",
            "libraries",
            "timeout_seconds",
        }
        notebook_parameters = {
            key: "" if value is None else str(value)
            for key, value in parameters.items()
            if key not in infrastructure_keys
        }

        if databricks_job_id:
            url = f"{workspace.rstrip('/')}/api/2.1/jobs/run-now"
            payload = {
                "job_id": int(databricks_job_id),
                "notebook_params": notebook_parameters,
            }
        else:
            if not existing_cluster_id and not new_cluster:
                raise ValueError(
                    "Databricks notebook execution requires databricks_job_id/job_id, "
                    "existing_cluster_id or new_cluster in parameters_json"
                )

            url = f"{workspace.rstrip('/')}/api/2.1/jobs/runs/submit"
            task = {
                "task_key": "run_notebook",
                "notebook_task": {
                    "notebook_path": notebook_path,
                    "base_parameters": notebook_parameters,
                },
            }
            if existing_cluster_id:
                task["existing_cluster_id"] = existing_cluster_id
            if new_cluster:
                task["new_cluster"] = new_cluster
            if libraries:
                task["libraries"] = libraries

            payload = {
                "run_name": f"{config['pipeline_name']}::{parameters.get('dataset') or '*'}",
                "tasks": [task],
            }
            if timeout_seconds is not None:
                payload["timeout_seconds"] = int(timeout_seconds)

        if dry_run:
            return {
                "execution_engine": "databricks",
                "url": url,
                "payload": payload,
                "dry_run": True,
            }

        bearer_token = (
            token
            or os.getenv("GSS_SPARK_FLOW_DATABRICKS_TOKEN")
            or os.getenv("DATABRICKS_TOKEN")
        )
        response = self._http_json("POST", url, bearer_token, payload=payload, timeout=timeout)
        return {
            "execution_engine": "databricks",
            "pipeline_name": config["pipeline_name"],
            "databricks_workspace": workspace,
            "databricks_path": notebook_path,
            "response": response,
        }

    # -------------------------------------
    # Group CRUD
    # -------------------------------------

    def add_group_target(
        self,
        group_name,
        pipeline_name,
        dataset,
        execution_order,
        is_active=True,
    ):
        self._require_group_columns(
            {"group_name", "pipeline_name", "dataset", "execution_order", "is_active", "created_ts", "updated_ts"}
        )

        group = self._clean(group_name)
        pipeline = self._clean(pipeline_name)
        dataset_clean = self._clean(dataset)
        order = self._normalize_execution_order(execution_order)
        active = self._normalize_is_active(is_active)

        if not group:
            raise ValueError("group_name is required")
        if not pipeline:
            raise ValueError("pipeline_name is required")
        if not dataset_clean:
            raise ValueError("dataset is required")

        self.spark.sql(f"""
        MERGE INTO metadata.pipeline_dependency_group t
        USING (
            SELECT
                '{group}' AS group_name,
                '{pipeline}' AS pipeline_name,
                '{dataset_clean}' AS dataset,
                {order} AS execution_order,
                {str(active).upper()} AS is_active,
                current_timestamp() AS current_ts
        ) s
        ON t.group_name = s.group_name
           AND t.pipeline_name = s.pipeline_name
           AND t.dataset = s.dataset
        WHEN MATCHED THEN UPDATE SET
            execution_order = s.execution_order,
            is_active = s.is_active,
            updated_ts = s.current_ts
        WHEN NOT MATCHED THEN INSERT (
            group_name,
            pipeline_name,
            dataset,
            execution_order,
            is_active,
            created_ts,
            updated_ts
        ) VALUES (
            s.group_name,
            s.pipeline_name,
            s.dataset,
            s.execution_order,
            s.is_active,
            s.current_ts,
            s.current_ts
        )
        """)

    def remove_group_target(self, group_name, pipeline_name, dataset):
        group = self._clean(group_name)
        pipeline = self._clean(pipeline_name)
        dataset_clean = self._clean(dataset)

        if not group or not pipeline or not dataset_clean:
            raise ValueError("group_name, pipeline_name and dataset are required")

        self.spark.sql(f"""
        DELETE FROM metadata.pipeline_dependency_group
        WHERE group_name = '{group}'
          AND pipeline_name = '{pipeline}'
          AND dataset = '{dataset_clean}'
        """)

    def list_group_targets(self, group_name=None, active_only=True):
        self._require_group_columns(
            {"group_name", "pipeline_name", "dataset", "execution_order", "is_active"}
        )

        where = []
        if group_name is not None:
            group = self._clean(group_name)
            where.append(f"group_name = '{group}'")
        if active_only and "is_active" in self._get_group_columns():
            where.append("COALESCE(is_active, true) = true")

        where_sql = ""
        if where:
            where_sql = "WHERE " + " AND ".join(where)

        rows = self.spark.sql(f"""
        SELECT
            group_name,
            pipeline_name,
            dataset,
            execution_order,
            COALESCE(is_active, true) AS is_active,
            created_ts,
            updated_ts
        FROM metadata.pipeline_dependency_group
        {where_sql}
        ORDER BY group_name, execution_order, pipeline_name, dataset
        """).collect()

        return [
            {
                "group_name": row[0],
                "pipeline_name": row[1],
                "dataset": row[2],
                "execution_order": int(row[3]) if row[3] is not None else None,
                "is_active": bool(row[4]) if row[4] is not None else True,
                "created_ts": row[5],
                "updated_ts": row[6],
            }
            for row in rows
        ]

    def add_group_schedule(
        self,
        schedule_name,
        group_name,
        schedule_expr,
        timezone=None,
        is_active=True,
    ):
        self._require_group_schedule_columns(
            {"schedule_name", "group_name", "schedule_expr", "timezone", "is_active", "created_ts", "updated_ts"}
        )

        schedule = self._clean(schedule_name)
        group = self._clean(group_name)
        expr = self._clean(schedule_expr)
        timezone_clean = self._clean(timezone)
        active = self._normalize_is_active(is_active)

        if not schedule:
            raise ValueError("schedule_name is required")
        if not group:
            raise ValueError("group_name is required")
        if not expr:
            raise ValueError("schedule_expr is required")

        self.spark.sql(f"""
        MERGE INTO metadata.pipeline_dependency_group_schedule t
        USING (
            SELECT
                '{schedule}' AS schedule_name,
                '{group}' AS group_name,
                '{expr}' AS schedule_expr,
                {self._sql_str_or_null(timezone_clean)} AS timezone,
                {str(active).upper()} AS is_active,
                current_timestamp() AS current_ts
        ) s
        ON t.schedule_name = s.schedule_name
        WHEN MATCHED THEN UPDATE SET
            group_name = s.group_name,
            schedule_expr = s.schedule_expr,
            timezone = s.timezone,
            is_active = s.is_active,
            updated_ts = s.current_ts
        WHEN NOT MATCHED THEN INSERT (
            schedule_name,
            group_name,
            schedule_expr,
            timezone,
            is_active,
            created_ts,
            updated_ts
        ) VALUES (
            s.schedule_name,
            s.group_name,
            s.schedule_expr,
            s.timezone,
            s.is_active,
            s.current_ts,
            s.current_ts
        )
        """)

    def remove_group_schedule(self, schedule_name):
        schedule = self._clean(schedule_name)
        if not schedule:
            raise ValueError("schedule_name is required")

        self.spark.sql(f"""
        DELETE FROM metadata.pipeline_dependency_group_schedule
        WHERE schedule_name = '{schedule}'
        """)

    def list_group_schedules(self, group_name=None, active_only=True):
        self._require_group_schedule_columns(
            {"schedule_name", "group_name", "schedule_expr", "timezone", "is_active"}
        )

        where = []
        if group_name is not None:
            group = self._clean(group_name)
            where.append(f"group_name = '{group}'")
        if active_only and "is_active" in self._get_group_schedule_columns():
            where.append("COALESCE(is_active, true) = true")

        where_sql = ""
        if where:
            where_sql = "WHERE " + " AND ".join(where)

        rows = self.spark.sql(f"""
        SELECT
            schedule_name,
            group_name,
            schedule_expr,
            timezone,
            COALESCE(is_active, true) AS is_active,
            created_ts,
            updated_ts
        FROM metadata.pipeline_dependency_group_schedule
        {where_sql}
        ORDER BY group_name, schedule_name
        """).collect()

        return [
            {
                "schedule_name": row[0],
                "group_name": row[1],
                "schedule_expr": row[2],
                "timezone": row[3],
                "is_active": bool(row[4]) if row[4] is not None else True,
                "created_ts": row[5],
                "updated_ts": row[6],
            }
            for row in rows
        ]

    # -------------------------------------
    # Group execution plan
    # -------------------------------------

    def validate_group(self, group_name):
        targets = self.list_group_targets(group_name=group_name, active_only=True)
        if not targets:
            raise ValueError(f"Group '{group_name}' has no active targets")

        duplicated = set()
        seen = set()
        for target in targets:
            key = (target["pipeline_name"], target["dataset"])
            if key in seen:
                duplicated.add(key)
            seen.add(key)

        if duplicated:
            formatted = ", ".join(
                [f"{pipeline} dataset={dataset}" for pipeline, dataset in sorted(duplicated)]
            )
            raise ValueError(f"Group '{group_name}' contains duplicated targets: {formatted}")

        self.assert_acyclic()
        return True

    def _build_execution_plan_for_targets(self, group_name, targets, include_dataset_decisions=True):
        all_dependencies = self.list_dependencies()

        reverse_graph = {}
        node_priority = {}
        group_target_nodes = set()

        for dep in all_dependencies:
            parent_node = self._dependency_node(dep["parent_pipeline"], dep.get("parent_dataset"))
            child_node = self._dependency_node(dep["child_pipeline"], dep.get("child_dataset"))
            reverse_graph.setdefault(child_node, []).append(dep)

        required_nodes = set()
        required_edges = []

        def visit(node, inherited_order):
            existing_order = node_priority.get(node)
            should_propagate = existing_order is None or inherited_order < existing_order
            if should_propagate:
                node_priority[node] = inherited_order
            if node in required_nodes and not should_propagate:
                return

            required_nodes.add(node)
            for dep in reverse_graph.get(node, []):
                parent_node = self._dependency_node(dep["parent_pipeline"], dep.get("parent_dataset"))
                required_edges.append((parent_node, node))
                visit(parent_node, inherited_order)

        for target in targets:
            target_node = self._dependency_node(target["pipeline_name"], target["dataset"])
            group_target_nodes.add(target_node)
            visit(target_node, target["execution_order"])

        indegree = {node: 0 for node in required_nodes}
        children_by_parent = {node: set() for node in required_nodes}
        for parent_node, child_node in required_edges:
            if parent_node not in required_nodes or child_node not in required_nodes:
                continue
            if child_node not in children_by_parent[parent_node]:
                children_by_parent[parent_node].add(child_node)
                indegree[child_node] += 1

        def node_sort_key(node):
            node_data = self._parse_dependency_node(node)
            return (
                node_priority.get(node, 0),
                node_data["pipeline_name"],
                node_data["dataset"] or "",
            )

        available = sorted(
            [node for node, degree in indegree.items() if degree == 0],
            key=node_sort_key,
        )
        ordered_nodes = []

        while available:
            current = available.pop(0)
            ordered_nodes.append(current)

            for child_node in sorted(children_by_parent.get(current, set()), key=node_sort_key):
                indegree[child_node] -= 1
                if indegree[child_node] == 0:
                    available.append(child_node)
            available.sort(key=node_sort_key)

        if len(ordered_nodes) != len(required_nodes):
            raise ValueError(
                f"Unable to build execution plan for group '{group_name}' because the graph is cyclic or incomplete"
            )

        plan = []
        for position, node in enumerate(ordered_nodes, start=1):
            node_data = self._parse_dependency_node(node)
            step = {
                "group_name": self._clean(group_name),
                "step": position,
                "pipeline_name": node_data["pipeline_name"],
                "dataset": node_data["dataset"],
                "execution_order": node_priority.get(node),
                "is_group_target": node in group_target_nodes,
            }

            if include_dataset_decisions:
                decision = self.get_dataset_execution_decision(
                    dataset=node_data["dataset"],
                    pipeline_name=node_data["pipeline_name"],
                )
                step.update({
                    "should_process": decision["should_process"],
                    "decision": decision["decision"],
                    "decision_reason": decision["reason"],
                    "has_dataset_execution_policy": decision.get("has_dataset_execution_policy"),
                    "dataset_execution_policy_active": decision.get("dataset_execution_policy_active"),
                    "reused_run_id": decision.get("reused_run_id"),
                    "reused_task_run_id": decision.get("reused_task_run_id"),
                    "next_eligible_ts": decision.get("next_eligible_ts"),
                    "min_interval_minutes": decision.get("min_interval_minutes"),
                })

            plan.append(step)
        return plan

    def get_group_execution_plan(self, group_name, include_dataset_decisions=True):
        self.validate_group(group_name)
        targets = self.list_group_targets(group_name=group_name, active_only=True)
        return self._build_execution_plan_for_targets(
            group_name=group_name,
            targets=targets,
            include_dataset_decisions=include_dataset_decisions,
        )

    def get_group_execution_plan_with_configs(
        self,
        group_name,
        runtime_parameters=None,
        require_execution_config=True,
        include_inactive_configs=False,
        require_parent_latest_success=True,
        require_parent_changes=False,
        require_parent_newer_than_child=False,
        novelty_mode="abm",
    ):
        plan = self.get_group_execution_plan(
            group_name=group_name,
            include_dataset_decisions=False,
        )

        enriched_plan = []
        for step in plan:
            dependency_decision = self.get_dependency_diagnostics(
                pipeline_name=step["pipeline_name"],
                dataset=step["dataset"],
                require_parent_latest_success=require_parent_latest_success,
                require_parent_changes=require_parent_changes,
                require_parent_newer_than_child=require_parent_newer_than_child,
                novelty_mode=novelty_mode,
                validate_cycles=False,
            )
            dataset_decision = self.get_dataset_execution_decision(
                pipeline_name=step["pipeline_name"],
                dataset=step["dataset"],
            )

            execution_config = None
            execution_parameters = {}
            config_error = None
            try:
                execution_config = self.get_pipeline_execution_config(
                    pipeline_name=step["pipeline_name"],
                    active_only=not include_inactive_configs,
                )
                execution_parameters = self._build_execution_parameters(
                    config=execution_config,
                    step=step,
                    runtime_parameters=runtime_parameters,
                )
            except ValueError as exc:
                config_error = str(exc)
                if require_execution_config:
                    raise

            enriched_step = dict(step)
            enriched_step.update({
                "dependency_decision": dependency_decision,
                "dataset_execution_decision": dataset_decision,
                "can_execute": dependency_decision["can_execute"],
                "blocking_reasons": dependency_decision["blocking_reasons"],
                "warnings": dependency_decision["warnings"],
                "should_process": dataset_decision["should_process"],
                "decision": dataset_decision["decision"],
                "decision_reason": dataset_decision["reason"],
                "has_dataset_execution_policy": dataset_decision.get("has_dataset_execution_policy"),
                "dataset_execution_policy_active": dataset_decision.get("dataset_execution_policy_active"),
                "medallion_layer": execution_config.get("medallion_layer") if execution_config else None,
                "execution_engine": execution_config.get("execution_engine") if execution_config else None,
                "execution_config": execution_config,
                "execution_parameters": execution_parameters,
                "execution_config_error": config_error,
            })
            enriched_plan.append(enriched_step)

        return enriched_plan

    def _pipeline_config_for_plan_step(
        self,
        step,
        include_inactive_configs=False,
        require_execution_config=True,
        require_medallion_layer=True,
    ):
        try:
            config = self.get_pipeline_execution_config(
                pipeline_name=step["pipeline_name"],
                active_only=not include_inactive_configs,
            )
        except ValueError as exc:
            if require_execution_config:
                raise
            return None, str(exc)

        if require_medallion_layer and not config.get("medallion_layer"):
            message = (
                f"Pipeline '{step['pipeline_name']}' has no medallion_layer "
                "in metadata.pipeline_execution_config"
            )
            if require_execution_config:
                raise ValueError(message)
            return config, message

        return config, None

    def _medallion_plan_item(self, step, config=None, config_error=None, include_execution_details=False):
        item = {
            "pipeline_name": step["pipeline_name"],
            "dataset": step["dataset"],
        }
        if include_execution_details:
            item.update({
                "source_step": step["step"],
                "execution_order": step.get("execution_order"),
                "execution_engine": config.get("execution_engine") if config else None,
                "execution_config": config,
                "execution_config_error": config_error,
            })
        return item

    def _build_medallion_stages(
        self,
        plan,
        include_inactive_configs=False,
        require_execution_config=True,
        include_execution_details=False,
    ):
        stages_by_layer = {
            "bronze": [],
            "silver": [],
            "gold": [],
        }

        for step in plan:
            config, config_error = self._pipeline_config_for_plan_step(
                step=step,
                include_inactive_configs=include_inactive_configs,
                require_execution_config=require_execution_config,
                require_medallion_layer=True,
            )
            layer = config.get("medallion_layer") if config else None
            if layer not in stages_by_layer:
                if require_execution_config:
                    raise ValueError(
                        f"Pipeline '{step['pipeline_name']}' has invalid medallion_layer '{layer}'"
                    )
                continue

            stages_by_layer[layer].append(
                self._medallion_plan_item(
                    step=step,
                    config=config,
                    config_error=config_error,
                    include_execution_details=include_execution_details,
                )
            )

        stages = []
        for index, layer in enumerate(["bronze", "silver", "gold"], start=1):
            stages.append({
                "step": index,
                "layer": layer,
                "parallel": layer == "bronze",
                "items": stages_by_layer[layer],
            })
        return stages

    def get_group_medallion_execution_plan(
        self,
        group_name,
        include_inactive_configs=False,
        require_execution_config=True,
        include_execution_details=False,
    ):
        self.validate_group(group_name)
        targets = self.list_group_targets(group_name=group_name, active_only=True)

        grouped_plan = []
        for index, target in enumerate(targets, start=1):
            target_plan = self._build_execution_plan_for_targets(
                group_name=group_name,
                targets=[target],
                include_dataset_decisions=False,
            )
            grouped_plan.append({
                "step": index,
                "pipeline_name": target["pipeline_name"],
                "dataset": target["dataset"],
                "steps": self._build_medallion_stages(
                    plan=target_plan,
                    include_inactive_configs=include_inactive_configs,
                    require_execution_config=require_execution_config,
                    include_execution_details=include_execution_details,
                ),
            })

        return grouped_plan

    def get_group_medallion_execution_plan_json(self, group_name, **kwargs):
        plan = self.get_group_medallion_execution_plan(group_name=group_name, **kwargs)
        payload = {
            "group_name": self._clean(group_name),
            "steps": self._json_safe(plan),
        }
        return json.dumps(payload, sort_keys=True)

    def get_group_execution_plan_json(self, group_name, **kwargs):
        plan = self.get_group_execution_plan_with_configs(group_name=group_name, **kwargs)
        payload = {
            "group_name": self._clean(group_name),
            "steps": self._json_safe(plan),
        }
        return json.dumps(payload, sort_keys=True)

    # -------------------------------------
    # Cycle detection
    # -------------------------------------

    def _build_dependency_graph(self):
        deps = self.list_dependencies()
        graph = {}
        for dep in deps:
            parent_node = self._dependency_node(dep["parent_pipeline"], dep.get("parent_dataset"))
            child_node = self._dependency_node(dep["child_pipeline"], dep.get("child_dataset"))

            if parent_node not in graph:
                graph[parent_node] = []
            if child_node not in graph:
                graph[child_node] = []
            graph[parent_node].append(child_node)
        return graph

    def detect_cycles(self):
        graph = self._build_dependency_graph()
        visited = set()
        in_stack = set()
        path = []
        cycles = []
        seen_cycle_keys = set()

        def dfs(node):
            visited.add(node)
            in_stack.add(node)
            path.append(node)

            for nxt in graph.get(node, []):
                if nxt not in visited:
                    dfs(nxt)
                elif nxt in in_stack:
                    idx = path.index(nxt)
                    cycle = path[idx:] + [nxt]
                    key = tuple(cycle)
                    if key not in seen_cycle_keys:
                        seen_cycle_keys.add(key)
                        cycles.append(cycle)

            path.pop()
            in_stack.remove(node)

        for node in list(graph.keys()):
            if node not in visited:
                dfs(node)

        return cycles

    def assert_acyclic(self):
        cycles = self.detect_cycles()
        if cycles:
            sample_cycle = " -> ".join(cycles[0])
            raise ValueError(f"Dependency graph has cycles. Example: {sample_cycle}")
        return True

    # -------------------------------------
    # Execution guards
    # -------------------------------------

    def get_dependency_diagnostics(
        self,
        pipeline_name,
        dataset=None,
        require_parent_latest_success=True,
        require_parent_changes=False,
        require_parent_newer_than_child=False,
        novelty_mode="abm",
        validate_cycles=True,
    ):
        pipeline = self._clean(pipeline_name)
        dataset_clean = self._clean(dataset)
        blocking_reasons = []
        warnings = []

        if validate_cycles:
            cycles = self.detect_cycles()
            if cycles:
                sample_cycle = " -> ".join(cycles[0])
                blocking_reasons.append({
                    "code": "dependency_cycle",
                    "severity": "hard",
                    "message": f"Dependency graph has cycles. Example: {sample_cycle}",
                })
                return {
                    "can_execute": False,
                    "blocking_reasons": blocking_reasons,
                    "warnings": warnings,
                }

        deps = self._fetch_dependencies(pipeline, child_dataset=dataset_clean)
        if not deps:
            return {
                "can_execute": True,
                "blocking_reasons": [],
                "warnings": [],
            }

        child_last_success = None
        if require_parent_newer_than_child:
            child_last_success = self._get_last_run(
                pipeline_name=pipeline,
                dataset=dataset_clean,
                success_only=True,
            )

        now = datetime.utcnow()

        for dep in deps:
            severity = self._normalize_dependency_mode(dep.get("dependency_mode"))
            collector = warnings if severity == "soft" else blocking_reasons

            parent = dep["parent_pipeline"]
            parent_dataset = dep.get("parent_dataset")

            parent_last = self._get_last_run(
                pipeline_name=parent,
                dataset=parent_dataset,
                success_only=False,
            )
            parent_success = self._get_last_run(
                pipeline_name=parent,
                dataset=parent_dataset,
                success_only=True,
            )

            if parent_last is None:
                collector.append({
                    "code": "parent_never_ran",
                    "severity": severity,
                    "parent_pipeline": parent,
                    "parent_dataset": parent_dataset,
                    "message": (
                        f"Parent '{parent}'"
                        f"{' dataset=' + parent_dataset if parent_dataset else ''} has no runs."
                    ),
                })
                continue

            if require_parent_latest_success and parent_last["status"] != "SUCCESS":
                collector.append({
                    "code": "parent_latest_not_success",
                    "severity": severity,
                    "parent_pipeline": parent,
                    "parent_dataset": parent_dataset,
                    "run_id": parent_last["run_id"],
                    "status": parent_last["status"],
                    "message": (
                        f"Latest run of parent '{parent}'"
                        f"{' dataset=' + parent_dataset if parent_dataset else ''} "
                        f"is '{parent_last['status']}', expected SUCCESS."
                    ),
                })
                continue

            if parent_success is None:
                collector.append({
                    "code": "parent_without_success",
                    "severity": severity,
                    "parent_pipeline": parent,
                    "parent_dataset": parent_dataset,
                    "message": (
                        f"Parent '{parent}'"
                        f"{' dataset=' + parent_dataset if parent_dataset else ''} has no SUCCESS run."
                    ),
                })
                continue

            if require_parent_newer_than_child and child_last_success is not None:
                if parent_success["start_ts"] <= child_last_success["start_ts"]:
                    collector.append({
                        "code": "parent_not_newer_than_child",
                        "severity": severity,
                        "parent_pipeline": parent,
                        "parent_dataset": parent_dataset,
                        "parent_run_id": parent_success["run_id"],
                        "child_run_id": child_last_success["run_id"],
                        "message": (
                            f"Parent '{parent}'"
                            f"{' dataset=' + parent_dataset if parent_dataset else ''} "
                            f"has no newer SUCCESS run than child '{pipeline}'"
                            f"{' dataset=' + dataset_clean if dataset_clean else ''}."
                        ),
                    })
                    continue

            freshness_hours = dep.get("freshness_hours")
            if freshness_hours is not None:
                max_age = timedelta(hours=int(freshness_hours))
                age = now - parent_success["start_ts"].replace(tzinfo=None)
                if age > max_age:
                    collector.append({
                        "code": "parent_freshness_expired",
                        "severity": severity,
                        "parent_pipeline": parent,
                        "parent_dataset": parent_dataset,
                        "run_id": parent_success["run_id"],
                        "freshness_hours": freshness_hours,
                        "parent_start_ts": parent_success["start_ts"],
                        "message": (
                            f"Parent '{parent}'"
                            f"{' dataset=' + parent_dataset if parent_dataset else ''} "
                            f"exceeded freshness window ({freshness_hours}h)."
                        ),
                    })
                    continue

            if require_parent_changes:
                stats = self._get_run_change_stats(
                    run_id=parent_success["run_id"],
                    dataset=parent_dataset,
                )
                mode = str(novelty_mode).lower().strip()
                if mode == "rows_out":
                    changed = stats["rows_out"] > 0
                else:
                    changed = (
                        stats["rows_inserted"] > 0
                        or stats["rows_updated"] > 0
                        or stats["rows_deleted"] > 0
                    )
                if not changed:
                    collector.append({
                        "code": "parent_without_changes",
                        "severity": severity,
                        "parent_pipeline": parent,
                        "parent_dataset": parent_dataset,
                        "run_id": parent_success["run_id"],
                        "rows_inserted": stats["rows_inserted"],
                        "rows_updated": stats["rows_updated"],
                        "rows_deleted": stats["rows_deleted"],
                        "rows_out": stats["rows_out"],
                        "message": (
                            f"Parent '{parent}'"
                            f"{' dataset=' + parent_dataset if parent_dataset else ''} "
                            f"last SUCCESS run has no changes (mode={novelty_mode})."
                        ),
                    })

        return {
            "can_execute": len(blocking_reasons) == 0,
            "blocking_reasons": blocking_reasons,
            "warnings": warnings,
        }

    def get_blocking_reasons(
        self,
        pipeline_name,
        dataset=None,
        require_parent_latest_success=True,
        require_parent_changes=False,
        require_parent_newer_than_child=False,
        novelty_mode="abm",
        validate_cycles=True,
    ):
        diagnostics = self.get_dependency_diagnostics(
            pipeline_name=pipeline_name,
            dataset=dataset,
            require_parent_latest_success=require_parent_latest_success,
            require_parent_changes=require_parent_changes,
            require_parent_newer_than_child=require_parent_newer_than_child,
            novelty_mode=novelty_mode,
            validate_cycles=validate_cycles,
        )
        return diagnostics["blocking_reasons"]

    def can_execute(
        self,
        pipeline_name,
        dataset=None,
        require_parent_latest_success=True,
        require_parent_changes=False,
        require_parent_newer_than_child=False,
        novelty_mode="abm",
        validate_cycles=True,
    ):
        diagnostics = self.get_dependency_diagnostics(
            pipeline_name=pipeline_name,
            dataset=dataset,
            require_parent_latest_success=require_parent_latest_success,
            require_parent_changes=require_parent_changes,
            require_parent_newer_than_child=require_parent_newer_than_child,
            novelty_mode=novelty_mode,
            validate_cycles=validate_cycles,
        )
        return diagnostics["can_execute"]

    def assert_can_execute(
        self,
        pipeline_name,
        dataset=None,
        require_parent_latest_success=True,
        require_parent_changes=False,
        require_parent_newer_than_child=False,
        novelty_mode="abm",
        validate_cycles=True,
    ):
        diagnostics = self.get_dependency_diagnostics(
            pipeline_name=pipeline_name,
            dataset=dataset,
            require_parent_latest_success=require_parent_latest_success,
            require_parent_changes=require_parent_changes,
            require_parent_newer_than_child=require_parent_newer_than_child,
            novelty_mode=novelty_mode,
            validate_cycles=validate_cycles,
        )
        if diagnostics["blocking_reasons"]:
            formatted = "; ".join(
                [r.get("message", r.get("code", "blocked")) for r in diagnostics["blocking_reasons"]]
            )
            raise RuntimeError(f"Pipeline '{pipeline_name}' blocked: {formatted}")
        return True
