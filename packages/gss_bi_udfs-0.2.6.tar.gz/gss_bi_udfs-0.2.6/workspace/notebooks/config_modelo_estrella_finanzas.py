# Databricks/Fabric notebook source

# COMMAND ----------

from gss_spark_flow import PipelineOrchestrator
from gss_spark_flow.context import PipelineContext
from gss_spark_flow.init_metadata import init_metadata_layer


# COMMAND ----------

CATALOG = "operaciones_dev"
METADATA_SCHEMA = "metadata"
BRONZE_SCHEMA = "bronze"
SILVER_SCHEMA = "silver"
GOLD_SCHEMA = "gold"

MASTER_BRONZE_PIPELINE = "0.Master_Sancor_Load_Table"
DAILY_GROUP = "modelo_estrella_finanzas"
CDC_GROUP = "modelo_estrella_finanzas_cdc_hourly"
TIMEZONE = "America/Argentina/Cordoba"

DAILY_SCHEDULE_NAME = "modelo_estrella_finanzas_daily"
CDC_SCHEDULE_NAME = "modelo_estrella_finanzas_cdc_hourly"
DAILY_SCHEDULE_EXPR = "0 0 6 * * ?"
CDC_SCHEDULE_EXPR = "0 0 * * * ?"
DAILY_DATASET_MIN_INTERVAL_MINUTES = 1440

FABRIC_WORKSPACE_ID = None  # TODO: completar workspace/group id de Fabric.
MASTER_BRONZE_FABRIC_PIPELINE_ID = None  # TODO: completar item id del pipeline Fabric bronze.
DATABRICKS_WORKSPACE = None  # TODO: completar workspace Databricks si silver/gold ejecutan notebooks Databricks.
SILVER_DATABRICKS_PATH_PREFIX = None  # TODO: ejemplo "/Shared/modelo_estrella/silver".
GOLD_DATABRICKS_PATH_PREFIX = None  # TODO: ejemplo "/Shared/modelo_estrella/gold".

CDC_SOURCE_ID = "artbd01.cdc.dbo_emis_cuenta_corriente_ct"
CDC_WATERMARK_COLUMN = None  # TODO: completar columna real del watermark CDC.
CDC_WATERMARK_TYPE = None  # Ejemplos validos: "timestamp", "date", "long", "string".

DATASETS = [
    {"id": "artbd01.cdc.dbo_emis_cuenta_corriente_ct", "query": "SELECT * FROM cdc.dbo_emis_cuenta_corriente_ct", "notebooks": ["fact_art_cdc"]},
    {"id": "artbd01.dbo.afip_tipos_contrataciones", "query": "SELECT * FROM dbo.afip_tipos_contrataciones", "notebooks": ["fact_art"]},
    {"id": "artbd01.dbo.emis_codificador", "query": "SELECT * FROM dbo.emis_codificador", "notebooks": ["fact_art"]},
    {"id": "artbd01.dbo.emis_contrato_intermediarios", "query": "SELECT * FROM dbo.emis_contrato_intermediarios", "notebooks": ["fact_art"]},
    {"id": "artbd01.dbo.emis_contrato_tarifas", "query": "SELECT * FROM dbo.emis_contrato_tarifas", "notebooks": ["fact_art"]},
    {"id": "artbd01.dbo.emis_contratos", "query": "SELECT * FROM dbo.emis_contratos", "notebooks": ["fact_art"]},
    {"id": "artbd01.dbo.emis_ctacte_movimientos", "query": "SELECT * FROM dbo.emis_ctacte_movimientos", "notebooks": ["fact_art"]},
    {"id": "artbd01.dbo.emis_ctacte_movimientos_agrupaciones", "query": "SELECT * FROM dbo.emis_ctacte_movimientos_agrupaciones", "notebooks": ["fact_art"]},
    {"id": "artbd01.dbo.emis_ctacte_movimientos_detalle_agrupaciones", "query": "SELECT * FROM dbo.emis_ctacte_movimientos_detalle_agrupaciones", "notebooks": ["fact_art"]},
    {"id": "artbd01.dbo.emis_cuenta_corriente", "query": "SELECT * FROM dbo.emis_cuenta_corriente", "notebooks": ["fact_art"]},
    {"id": "artbd01.dbo.emis_distribucion_cobranza_por_modalidad", "query": "SELECT * FROM dbo.emis_distribucion_cobranza_por_modalidad where periodo_imputacion>202401", "notebooks": ["fact_art"]},
    {"id": "artbd01.dbo.emis_maximas_modificaciones", "query": "SELECT * FROM dbo.emis_maximas_modificaciones", "notebooks": ["fact_art"]},
    {"id": "artbd01.dbo.emis_proceso", "query": "SELECT * FROM dbo.emis_proceso", "notebooks": ["fact_art"]},
    {"id": "artbd01.dbo.empresas", "query": "SELECT * FROM dbo.empresas", "notebooks": ["fact_art"]},
    {"id": "artbd01.dbo.organizadores_aux", "query": "SELECT * FROM dbo.organizadores_aux", "notebooks": ["fact_art"]},
    {"id": "artbd01.dbo.productores_aux", "query": "SELECT * FROM dbo.productores_aux", "notebooks": ["fact_art"]},
    {"id": "artbd01.dbo.seg_saldos", "query": "SELECT * FROM dbo.seg_saldos", "notebooks": ["fact_art"]},
    {"id": "bup.bup.addresses", "query": "SELECT * FROM bup.addresses", "notebooks": ["dim_bup"]},
    {"id": "bup.bup.administrativefreezeperiods", "query": "SELECT * FROM bup.administrativefreezeperiods", "notebooks": ["dim_bup"]},
    {"id": "bup.bup.cities", "query": "SELECT * FROM bup.cities", "notebooks": ["dim_bup"]},
    {"id": "bup.bup.emails", "query": "SELECT * FROM bup.emails", "notebooks": ["dim_bup"]},
    {"id": "bup.bup.fraudrisklevels", "query": "SELECT * FROM bup.fraudrisklevels", "notebooks": ["dim_bup"]},
    {"id": "bup.bup.genders", "query": "SELECT * FROM bup.genders", "notebooks": ["dim_bup"]},
    {"id": "bup.bup.legalpersons", "query": "SELECT * FROM bup.legalpersons", "notebooks": ["dim_bup"]},
    {"id": "bup.bup.maritalstatus", "query": "SELECT * FROM bup.maritalstatus", "notebooks": ["dim_bup"]},
    {"id": "bup.bup.naturalpersons", "query": "SELECT * FROM bup.naturalpersons", "notebooks": ["dim_bup"]},
    {"id": "bup.bup.persons", "query": "SELECT * FROM bup.persons", "notebooks": ["dim_bup"]},
    {"id": "bup.bup.phones", "query": "SELECT * FROM bup.phones", "notebooks": ["dim_bup"]},
    {"id": "dwgssprotmp.dwo.dim_publiccontract", "query": "SELECT * FROM dwo.dim_publiccontract", "notebooks": ["fact_art"]},
    {"id": "dwgssprotmp.dwo.int_dim_clientactive_bds", "query": "SELECT * FROM dwo.int_dim_clientactive_bds", "notebooks": ["dim_bup"]},
    {"id": "odscommon.common.vw_channel_subchannel", "query": "SELECT * FROM common.vw_channel_subchannel", "notebooks": ["dim_channel"]},
    {"id": "odscommon.employee.vw_active_employee", "query": "SELECT * FROM employee.vw_active_employee", "notebooks": ["dim_bup"]},
    {"id": "referencedata.gss.hmbusinessunit", "query": "SELECT * FROM gss.hmbusinessunit", "notebooks": ["dim_business_unit"]},
    {"id": "referencedata.gss.hmcurrency", "query": "SELECT * FROM gss.hmcurrency", "notebooks": ["dim_currency"]},
    {"id": "referencedata.gss.hmgsscompanies", "query": "SELECT * FROM gss.hmgsscompanies", "notebooks": ["dim_company"]},
    {"id": "timepro.insudb.benefitprogramadhesion", "query": "SELECT * FROM insudb.benefitprogramadhesion", "notebooks": ["dim_bup"]},
    {"id": "timepro.insudb.businessoff", "query": "SELECT * FROM insudb.businessoff", "notebooks": ["dim_intermediary"]},
    {"id": "timepro.insudb.company", "query": "SELECT * FROM insudb.company", "notebooks": ["dim_intermediary"]},
    {"id": "timepro.insudb.gen_cover", "query": "SELECT * FROM insudb.gen_cover", "notebooks": ["dim_product"]},
    {"id": "timepro.insudb.int_sancor", "query": "SELECT * FROM insudb.int_sancor", "notebooks": ["dim_intermediary"]},
    {"id": "timepro.insudb.intermedia", "query": "SELECT * FROM insudb.intermedia", "notebooks": ["dim_intermediary"]},
    {"id": "timepro.insudb.life_cover", "query": "SELECT * FROM insudb.life_cover", "notebooks": ["dim_product"]},
    {"id": "timepro.insudb.logauth0user", "query": "SELECT * FROM insudb.logauth0user", "notebooks": ["dim_bup"]},
    {"id": "timepro.insudb.prodmaster", "query": "SELECT * FROM insudb.prodmaster", "notebooks": ["dim_product"]},
    {"id": "timepro.insudb.prodpolicydoc", "query": "SELECT * FROM insudb.prodpolicydoc", "notebooks": ["dim_product"]},
    {"id": "timepro.insudb.specialoperativecodes", "query": "SELECT * FROM timepro.insudb.specialoperativecodes", "notebooks": ["fact_art"]},
    {"id": "timepro.insudb.statisticcorpbusinessinterm", "query": "SELECT * FROM timepro.insudb.statisticcorpbusinessinterm", "notebooks": ["fact_art"]},
    {"id": "timepro.insudb.tab_gencov", "query": "SELECT * FROM insudb.tab_gencov", "notebooks": ["dim_product"]},
    {"id": "timepro.insudb.table10", "query": "SELECT * FROM insudb.table10", "notebooks": ["dim_product"]},
    {"id": "timepro.insudb.table7550", "query": "SELECT * FROM insudb.table7550", "notebooks": ["dim_product"]},
    {"id": "timeprotmp.extrared.synchrotimeusersintermed", "query": "SELECT * FROM extrared.synchrotimeusersintermed", "notebooks": ["dim_intermediary"]},
]

BRONZE_ONLY_DATASETS = [
    {"id": "prevencionsalud.dbo.subcta_contratos", "query": "SELECT * FROM dbo.subcta_contratos", "notebooks": []},
]

BRONZE_SOURCE_CONNECTIONS = {
    "artbd01": {
        "connection_key": "source_artbd01",
        "fabric_connection_id": "0b07f3c5-441c-411b-b50b-c8015c503bd0",
        "description": "GSSAZ-ConectorPro-ARTBD01",
    },
    "bup": {
        "connection_key": "source_bup",
        "fabric_connection_id": "01728dc7-8fd4-482a-bbdc-1a4dfb8e577e",
        "description": "GSSAZ-ConectorPro-BUP",
    },
    "dwgssprotmp": {
        "connection_key": "source_dwgssprotmp",
        "fabric_connection_id": "55dde3f5-7b3c-49a5-afc1-e75b2c29bab7",
        "description": "GSSAZ-ConectorPro-DWGSSProTmp",
    },
    "odscommon": {
        "connection_key": "source_odscommon",
        "fabric_connection_id": "6e8b5a3b-1533-44ba-8ad3-05a08f48d15f",
        "description": "GSSAZ-ConectorPro-ODSCommon",
    },
    "prevencionsalud": {
        "connection_key": "source_prevencionsalud",
        "fabric_connection_id": "53ea691f-b9b3-4065-8208-77177788508b",
        "description": "GSSAZ-ConectorPro-PrevencionSalud",
    },
    "referencedata": {
        "connection_key": "source_referencedata",
        "fabric_connection_id": "0a194b32-add8-499f-b915-14a6f724eb29",
        "description": "GSSAZ-Conector-ReferenceData",
    },
    "timepro": {
        "connection_key": "source_timepro",
        "fabric_connection_id": "b96455db-7436-4621-8b08-9b8d82f9fdcf",
        "description": "GSSAZ-ConectorPro-TimePro",
    },
    "timeprotmp": {
        "connection_key": "source_timeprotmp",
        "fabric_connection_id": "8c4bb983-6db9-484f-b6f2-28636a9692a4",
        "description": "GSSAZ-ConectorPro-TimeProTmp",
    },
}

DIMENSIONS = [
    "dim_bup",
    "dim_channel",
    "dim_business_unit",
    "dim_currency",
    "dim_company",
    "dim_intermediary",
    "dim_product",
]
FACTS = ["fact_art_cdc", "fact_art"]
ALL_MODEL_DATASETS = DIMENSIONS + FACTS


# COMMAND ----------

def bronze_table(source_id):
    return f"{CATALOG}.{BRONZE_SCHEMA}.{source_id.replace('.', '_')}"


def bronze_ingestion_rows():
    return DATASETS + BRONZE_ONLY_DATASETS


def source_parts(source_id):
    parts = [part.strip() for part in source_id.split(".")]
    if len(parts) != 3:
        raise ValueError(f"Invalid source dataset id: {source_id}")
    return parts


def bronze_sink_path(source_id):
    database, schema, table = source_parts(source_id)
    return f"bronze/{database}/{schema}/{table}"


def layer_table(layer, dataset):
    return f"{CATALOG}.{layer}.{dataset}"


def silver_pipeline(dataset):
    return f"silver/{dataset}"


def gold_pipeline(dataset):
    return f"gold/{dataset}"


def silver_databricks_path(dataset):
    if not SILVER_DATABRICKS_PATH_PREFIX:
        return None
    return f"{SILVER_DATABRICKS_PATH_PREFIX.rstrip('/')}/{dataset}"


def gold_databricks_path(dataset):
    if not GOLD_DATABRICKS_PATH_PREFIX:
        return None
    return f"{GOLD_DATABRICKS_PATH_PREFIX.rstrip('/')}/{dataset}"


def rows_for_dataset(dataset):
    return [row for row in DATASETS if dataset in row["notebooks"]]


def is_cdc_dataset(source_id):
    return source_id == CDC_SOURCE_ID


# Contrato de metadata.dataset_execution_policy
# - Aplica solo a datasets fuente cuya recarga se decide por frescura propia.
# - En este modelo se carga unicamente para fuentes bronze no-CDC.
# - Los datasets CDC quedan excluidos de esta tabla porque su frecuencia efectiva
#   se gobierna por watermark_state + dataset_config.watermark_*.
# - Silver/Gold no se cargan aca: su ejecucion la gobierna pipeline_dependency.
NON_CDC_SOURCE_DATASETS = [row for row in DATASETS if not is_cdc_dataset(row["id"])]


def register_dataset_config(pipeline_name, dataset, source_table, target_table, watermark_column=None, watermark_type=None):
    ctx = PipelineContext(
        spark=spark,
        pipeline_name=pipeline_name,
        dataset=dataset,
        auto_start=False,
    )
    ctx.set_dataset_config(
        source_table=source_table,
        target_table=target_table,
        merge_keys=None,
        watermark_column=watermark_column,
        watermark_type=watermark_type,
    )


# COMMAND ----------

init_metadata_layer(spark, catalog=CATALOG, schema=METADATA_SCHEMA)
spark.sql(f"USE CATALOG {CATALOG}")
spark.sql(f"USE {METADATA_SCHEMA}")

orch = PipelineOrchestrator(spark, catalog=CATALOG, schema=METADATA_SCHEMA)


# COMMAND ----------

if FABRIC_WORKSPACE_ID and MASTER_BRONZE_FABRIC_PIPELINE_ID:
    orch.add_fabric_pipeline_config(
        pipeline_name=MASTER_BRONZE_PIPELINE,
        group_id=FABRIC_WORKSPACE_ID,
        pipeline_id=MASTER_BRONZE_FABRIC_PIPELINE_ID,
        medallion_layer="bronze",
        is_active=True,
    )
else:
    print("Pipeline execution config bronze pendiente: completar FABRIC_WORKSPACE_ID y MASTER_BRONZE_FABRIC_PIPELINE_ID.")

if DATABRICKS_WORKSPACE and SILVER_DATABRICKS_PATH_PREFIX:
    for dataset in ALL_MODEL_DATASETS:
        orch.add_databricks_pipeline_config(
            pipeline_name=silver_pipeline(dataset),
            workspace=DATABRICKS_WORKSPACE,
            path=silver_databricks_path(dataset),
            medallion_layer="silver",
            is_active=True,
        )
else:
    print("Pipeline execution config silver pendiente: completar DATABRICKS_WORKSPACE y SILVER_DATABRICKS_PATH_PREFIX.")

if DATABRICKS_WORKSPACE and GOLD_DATABRICKS_PATH_PREFIX:
    for dataset in ALL_MODEL_DATASETS:
        orch.add_databricks_pipeline_config(
            pipeline_name=gold_pipeline(dataset),
            workspace=DATABRICKS_WORKSPACE,
            path=gold_databricks_path(dataset),
            medallion_layer="gold",
            is_active=True,
        )
else:
    print("Pipeline execution config gold pendiente: completar DATABRICKS_WORKSPACE y GOLD_DATABRICKS_PATH_PREFIX.")


# COMMAND ----------

orch.add_connection_config(
    connection_key="adls_bronze",
    fabric_connection_id="5361d8af-4e00-491b-8289-6672056594b8",
    connection_type="Azure Data Lake Storage Gen2",
    description="Destino bronze ADLS Gen2",
    is_active=True,
)

for connection in BRONZE_SOURCE_CONNECTIONS.values():
    orch.add_connection_config(
        connection_key=connection["connection_key"],
        fabric_connection_id=connection["fabric_connection_id"],
        connection_type="SQL Server",
        description=connection["description"],
        is_active=True,
    )

for row in bronze_ingestion_rows():
    source_database, source_schema, source_table = source_parts(row["id"])
    source_connection = BRONZE_SOURCE_CONNECTIONS[source_database]
    orch.add_bronze_ingestion_config(
        dataset=row["id"],
        source_connection_key=source_connection["connection_key"],
        source_database=source_database,
        source_schema=source_schema,
        source_table=source_table,
        source_query=row["query"],
        sink_path_template=bronze_sink_path(row["id"]),
        sink_connection_key="adls_bronze",
        is_cdc=is_cdc_dataset(row["id"]),
        is_active=True,
    )


# COMMAND ----------

for row in DATASETS:
    is_cdc = row["id"] == CDC_SOURCE_ID
    register_dataset_config(
        pipeline_name=MASTER_BRONZE_PIPELINE,
        dataset=row["id"],
        source_table=row["query"],
        target_table=bronze_table(row["id"]),
        watermark_column=CDC_WATERMARK_COLUMN if is_cdc else None,
        watermark_type=CDC_WATERMARK_TYPE if is_cdc else None,
    )

for dataset in ALL_MODEL_DATASETS:
    source_tables = ",".join([bronze_table(row["id"]) for row in rows_for_dataset(dataset)])
    register_dataset_config(
        pipeline_name=silver_pipeline(dataset),
        dataset=dataset,
        source_table=source_tables,
        target_table=layer_table(SILVER_SCHEMA, dataset),
    )
    register_dataset_config(
        pipeline_name=gold_pipeline(dataset),
        dataset=dataset,
        source_table=layer_table(SILVER_SCHEMA, dataset),
        target_table=layer_table(GOLD_SCHEMA, dataset),
    )


# COMMAND ----------

for row in NON_CDC_SOURCE_DATASETS:
    orch.add_dataset_execution_policy(
        dataset=row["id"],
        min_interval_minutes=DAILY_DATASET_MIN_INTERVAL_MINUTES,
        schedule_expr=DAILY_SCHEDULE_EXPR,
        timezone=TIMEZONE,
        skip_if_fresh=True,
        is_active=True,
    )


# COMMAND ----------

for row in DATASETS:
    for dataset in row["notebooks"]:
        orch.add_dependency(
            parent_pipeline=MASTER_BRONZE_PIPELINE,
            parent_dataset=row["id"],
            child_pipeline=silver_pipeline(dataset),
            child_dataset=dataset,
            dependency_mode="hard",
        )

for dataset in ALL_MODEL_DATASETS:
    orch.add_dependency(
        parent_pipeline=silver_pipeline(dataset),
        parent_dataset=dataset,
        child_pipeline=gold_pipeline(dataset),
        child_dataset=dataset,
        dependency_mode="hard",
    )

# La fact ART final espera a todas las dimensiones gold.
for dimension in DIMENSIONS:
    orch.add_dependency(
        parent_pipeline=gold_pipeline(dimension),
        parent_dataset=dimension,
        child_pipeline=gold_pipeline("fact_art"),
        child_dataset="fact_art",
        dependency_mode="hard",
    )


# COMMAND ----------

for index, dataset in enumerate(DIMENSIONS, start=1):
    orch.add_group_target(
        group_name=DAILY_GROUP,
        pipeline_name=gold_pipeline(dataset),
        dataset=dataset,
        execution_order=10 + index,
        is_active=True,
    )

orch.add_group_target(
    group_name=DAILY_GROUP,
    pipeline_name=gold_pipeline("fact_art"),
    dataset="fact_art",
    execution_order=100,
    is_active=True,
)

orch.add_group_target(
    group_name=CDC_GROUP,
    pipeline_name=gold_pipeline("fact_art_cdc"),
    dataset="fact_art_cdc",
    execution_order=10,
    is_active=True,
)

orch.add_group_schedule(
    schedule_name=DAILY_SCHEDULE_NAME,
    group_name=DAILY_GROUP,
    schedule_expr=DAILY_SCHEDULE_EXPR,
    timezone=TIMEZONE,
    is_active=True,
)

orch.add_group_schedule(
    schedule_name=CDC_SCHEDULE_NAME,
    group_name=CDC_GROUP,
    schedule_expr=CDC_SCHEDULE_EXPR,
    timezone=TIMEZONE,
    is_active=True,
)


# COMMAND ----------

print("Dataset config")
spark.sql("""
SELECT pipeline_name, dataset, source_table, target_table, watermark_column, watermark_type, merge_keys
FROM metadata.dataset_config
WHERE pipeline_name = '0.Master_Sancor_Load_Table'
   OR pipeline_name LIKE 'silver/%'
   OR pipeline_name LIKE 'gold/%'
ORDER BY pipeline_name, dataset
""").show(300, truncate=False)

print("Connection config")
spark.sql("""
SELECT connection_key, fabric_connection_id, connection_type, description, is_active
FROM metadata.connection_config
ORDER BY connection_key
""").show(100, truncate=False)

print("Bronze ingestion config")
spark.sql("""
SELECT
    dataset,
    source_connection_key,
    source_database,
    source_schema,
    source_table,
    source_query,
    sink_connection_key,
    sink_path_template,
    sink_file_format,
    is_cdc,
    is_active
FROM metadata.bronze_ingestion_config
ORDER BY dataset
""").show(300, truncate=False)

print("Dependencies")
spark.sql("""
SELECT parent_pipeline, parent_dataset, child_pipeline, child_dataset, dependency_mode, freshness_hours
FROM metadata.pipeline_dependency
WHERE parent_pipeline = '0.Master_Sancor_Load_Table'
   OR parent_pipeline LIKE 'silver/%'
   OR parent_pipeline LIKE 'gold/%'
   OR child_pipeline LIKE 'silver/%'
   OR child_pipeline LIKE 'gold/%'
ORDER BY child_pipeline, child_dataset, parent_pipeline, parent_dataset
""").show(300, truncate=False)

print("Dataset execution policy")
spark.sql("""
SELECT dataset, min_interval_minutes, schedule_expr, timezone, skip_if_fresh, is_active
FROM metadata.dataset_execution_policy
ORDER BY dataset
""").show(300, truncate=False)

print("Pipeline execution config")
spark.sql("""
SELECT pipeline_name, medallion_layer, execution_engine, fabric_group_id, fabric_pipeline_id, databricks_workspace, databricks_path, is_active
FROM metadata.pipeline_execution_config
WHERE pipeline_name = '0.Master_Sancor_Load_Table'
   OR pipeline_name LIKE 'silver/%'
   OR pipeline_name LIKE 'gold/%'
ORDER BY medallion_layer, pipeline_name
""").show(300, truncate=False)

print("Groups")
spark.sql("""
SELECT group_name, pipeline_name, dataset, execution_order, is_active
FROM metadata.pipeline_dependency_group
WHERE group_name IN ('modelo_estrella_finanzas', 'modelo_estrella_finanzas_cdc_hourly')
ORDER BY group_name, execution_order
""").show(100, truncate=False)

print("Schedules")
spark.sql("""
SELECT schedule_name, group_name, schedule_expr, timezone, is_active
FROM metadata.pipeline_dependency_group_schedule
WHERE group_name IN ('modelo_estrella_finanzas', 'modelo_estrella_finanzas_cdc_hourly')
ORDER BY group_name, schedule_name
""").show(100, truncate=False)


# COMMAND ----------

print("Daily execution plan")
for step in orch.get_group_execution_plan(DAILY_GROUP):
    print(step)

print("Daily medallion execution plan")
for step in orch.get_group_medallion_execution_plan(DAILY_GROUP, require_execution_config=False):
    print(step)

print("CDC hourly execution plan")
for step in orch.get_group_execution_plan(CDC_GROUP):
    print(step)

print("CDC hourly medallion execution plan")
for step in orch.get_group_medallion_execution_plan(CDC_GROUP, require_execution_config=False):
    print(step)
