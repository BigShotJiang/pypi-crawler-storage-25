# DER - Metadata layer (`init_metadata.py`)

Este DER documenta las tablas creadas por `gss_spark_flow/init_metadata.py`.
Las relaciones son logicas: el script crea tablas Delta y columnas, pero no define
constraints fisicas de clave primaria o foranea.

```mermaid
erDiagram
    RUN {
        string run_id PK "Identificador unico de la ejecucion"
        string pipeline_name "Pipeline ejecutado"
        string git_sha "Version del codigo usada"
        string triggered_by "Usuario, job o sistema disparador"
        string trigger_type "Tipo de disparo: manual, schedule, dependencia, etc."
        timestamp start_ts "Inicio de la ejecucion"
        timestamp end_ts "Fin de la ejecucion"
        string status "Estado final o actual"
        int sla_minutes "SLA esperado en minutos"
        bigint duration_ms "Duracion total en milisegundos"
        string spark_app_id "Aplicacion Spark asociada"
    }

    TASK_RUN {
        string task_run_id PK "Identificador unico de la tarea ejecutada"
        string run_id FK "Ejecucion padre"
        string task_name "Nombre de la tarea"
        string dataset "Dataset procesado"
        timestamp start_ts "Inicio de la tarea"
        timestamp end_ts "Fin de la tarea"
        string status "Estado de la tarea"
        bigint rows_in "Filas leidas"
        bigint rows_out "Filas emitidas"
        bigint rows_inserted "Filas insertadas"
        bigint rows_updated "Filas actualizadas"
        bigint rows_deleted "Filas eliminadas"
        bigint target_rows_total "Total de filas en el destino luego del proceso"
        bigint duration_ms "Duracion de la tarea en milisegundos"
        string watermark_in "Watermark de entrada"
        string watermark_out "Watermark de salida"
        string decision "Decision operativa: PROCESS, SKIP_FRESH, etc."
        string skip_reason "Motivo por el cual se salteo la tarea"
        string reused_run_id FK "Ejecucion previa reutilizada"
        string reused_task_run_id FK "Tarea previa reutilizada"
    }

    ERROR_LOG {
        string error_id PK "Identificador unico del error"
        string run_id FK "Ejecucion donde ocurrio el error"
        string task_name "Tarea donde ocurrio el error"
        string error_type "Clasificacion tecnica o funcional del error"
        string message "Mensaje resumido"
        string stacktrace "Detalle tecnico del error"
        timestamp created_ts "Momento de registro"
    }

    WATERMARK_STATE {
        string pipeline_name FK "Pipeline asociado al estado incremental"
        string dataset FK "Dataset asociado al estado incremental"
        string last_watermark "Ultimo valor procesado"
        string watermark_column "Columna usada como watermark"
        string watermark_type "Tipo/formato del watermark"
        string last_run_id FK "Ultima ejecucion que actualizo el estado"
        timestamp updated_ts "Ultima actualizacion del estado"
    }

    DATASET_CONFIG {
        string pipeline_name PK "Pipeline propietario de la configuracion"
        string dataset PK "Dataset configurado"
        string source_table "Tabla origen"
        string target_table "Tabla destino"
        string watermark_column "Columna usada para procesamiento incremental"
        string watermark_type "Tipo/formato del watermark"
        string merge_keys "Claves de merge en formato texto"
        timestamp updated_ts "Ultima actualizacion de la configuracion"
    }

    CONNECTION_CONFIG {
        string connection_key PK "Alias logico de la conexion"
        string fabric_connection_id "Id de conexion configurado en Fabric"
        string connection_type "Tipo de conexion: SQL Server, ADLS Gen2, etc."
        string description "Descripcion funcional de la conexion"
        boolean is_active "Indica si la conexion esta habilitada"
        timestamp created_ts "Fecha de creacion"
        timestamp updated_ts "Fecha de ultima actualizacion"
    }

    BRONZE_INGESTION_CONFIG {
        string dataset PK "Dataset bronze ingestable"
        string source_connection_key FK "Conexion origen usada por Copy Data"
        string source_connection_type "Tipo de origen esperado por Fabric"
        string source_database "Base de datos origen"
        string source_schema "Schema origen"
        string source_table "Tabla origen"
        string source_query "Consulta origen: select completo o con filtro CDC"
        string sink_connection_key FK "Conexion destino usada por Copy Data"
        string sink_connection_type "Tipo de destino esperado por Fabric"
        string sink_path_template "Ruta parametrizada de destino"
        string sink_file_format "Formato de archivo destino"
        boolean is_cdc "Indica si la consulta aplica filtro CDC"
        boolean is_active "Indica si la ingesta esta habilitada"
        timestamp created_ts "Fecha de creacion"
        timestamp updated_ts "Fecha de ultima actualizacion"
    }

    PIPELINE_DEPENDENCY {
        string parent_pipeline FK "Pipeline del que depende"
        string parent_dataset FK "Dataset del que depende"
        string child_pipeline FK "Pipeline dependiente"
        string child_dataset FK "Dataset dependiente"
        string dependency_mode "Modo de dependencia"
        int freshness_hours "Maxima antiguedad aceptada de la dependencia"
    }

    PIPELINE_DEPENDENCY_GROUP {
        string group_name PK "Grupo de ejecucion"
        string pipeline_name FK "Pipeline incluido en el grupo"
        string dataset FK "Dataset incluido en el grupo"
        int execution_order "Orden relativo dentro del grupo"
        boolean is_active "Indica si la entrada esta habilitada"
        timestamp created_ts "Fecha de creacion"
        timestamp updated_ts "Fecha de ultima actualizacion"
    }

    PIPELINE_DEPENDENCY_GROUP_SCHEDULE {
        string schedule_name PK "Nombre de la planificacion"
        string group_name FK "Grupo planificado"
        string schedule_expr "Expresion de schedule"
        string timezone "Zona horaria del schedule"
        boolean is_active "Indica si la planificacion esta habilitada"
        timestamp created_ts "Fecha de creacion"
        timestamp updated_ts "Fecha de ultima actualizacion"
    }

    DATASET_EXECUTION_POLICY {
        string dataset PK "Dataset al que aplica la politica"
        int min_interval_minutes "Intervalo minimo entre cargas exitosas"
        string schedule_expr "Expresion opcional de calendario del dataset"
        string timezone "Zona horaria del calendario"
        boolean skip_if_fresh "Permite saltear si el dataset sigue fresco"
        boolean is_active "Indica si la politica esta habilitada"
        timestamp created_ts "Fecha de creacion"
        timestamp updated_ts "Fecha de ultima actualizacion"
    }

    PIPELINE_EXECUTION_CONFIG {
        string pipeline_name PK "Nombre logico del pipeline"
        string medallion_layer "Capa del medallero: bronze, silver o gold"
        string execution_engine "Motor de ejecucion: fabric o databricks"
        string fabric_group_id "Group/workspace id de Fabric"
        string fabric_pipeline_id "Id del pipeline de Fabric"
        string databricks_workspace "Workspace de Databricks"
        string databricks_path "Path del job/notebook/pipeline en Databricks"
        string parameters_json "Parametros de ejecucion serializados como JSON"
        boolean is_active "Indica si la configuracion esta habilitada"
        timestamp created_ts "Fecha de creacion"
        timestamp updated_ts "Fecha de ultima actualizacion"
    }

    LINEAGE {
        string run_id FK "Ejecucion observada"
        string task_name "Tarea observada"
        string input_table "Tabla de entrada"
        string output_table "Tabla de salida"
        timestamp created_ts "Momento de registro"
    }

    DATA_QUALITY {
        string run_id FK "Ejecucion evaluada"
        string task_name "Tarea evaluada"
        string check_name "Nombre del control"
        double metric_value "Valor medido"
        double threshold_value "Umbral esperado"
        string status "Resultado del control"
        timestamp created_ts "Momento de registro"
    }

    SCHEMA_VERSION {
        string version PK "Version registrada del esquema de metadata"
        timestamp applied_ts "Momento de aplicacion"
        string description "Descripcion de la inicializacion o migracion"
        string modified_tables "Tablas creadas o columnas agregadas"
    }

    RUN ||--o{ TASK_RUN : contiene
    RUN ||--o{ ERROR_LOG : registra
    RUN ||--o{ LINEAGE : produce
    RUN ||--o{ DATA_QUALITY : evalua
    RUN ||--o{ WATERMARK_STATE : actualiza

    DATASET_CONFIG ||--o{ WATERMARK_STATE : define_incrementalidad
    DATASET_CONFIG ||--o{ TASK_RUN : parametriza
    DATASET_CONFIG ||--o{ PIPELINE_DEPENDENCY_GROUP : agrupa
    DATASET_CONFIG ||--o{ PIPELINE_DEPENDENCY : parent
    DATASET_CONFIG ||--o{ PIPELINE_DEPENDENCY : child
    DATASET_EXECUTION_POLICY ||--o{ DATASET_CONFIG : decide_recarga
    CONNECTION_CONFIG ||--o{ BRONZE_INGESTION_CONFIG : origen
    CONNECTION_CONFIG ||--o{ BRONZE_INGESTION_CONFIG : destino
    BRONZE_INGESTION_CONFIG ||--o{ DATASET_CONFIG : alimenta_bronze

    PIPELINE_DEPENDENCY_GROUP ||--o{ PIPELINE_DEPENDENCY_GROUP_SCHEDULE : programa
    PIPELINE_EXECUTION_CONFIG ||--o{ RUN : ejecuta
    PIPELINE_EXECUTION_CONFIG ||--o{ DATASET_CONFIG : configura
    PIPELINE_EXECUTION_CONFIG ||--o{ PIPELINE_DEPENDENCY_GROUP : agrupa
```

## Sentido de las entidades

| Tabla | Proposito |
| --- | --- |
| `run` | Cabecera de una ejecucion completa de pipeline. Permite auditar quien ejecuto, cuando, con que version de codigo, estado, duracion y aplicacion Spark. |
| `task_run` | Detalle operativo por tarea/dataset dentro de una ejecucion. Guarda tiempos, estado, conteos de filas, cambios aplicados y watermarks de entrada/salida. |
| `error_log` | Bitacora de errores asociados a una ejecucion y, opcionalmente, a una tarea concreta. Conserva mensaje y stacktrace para diagnostico. |
| `watermark_state` | Estado incremental vigente por pipeline/dataset. Indica hasta que valor se proceso y que ejecucion actualizo ese valor. |
| `dataset_config` | Configuracion funcional de cada dataset de un pipeline: origen, destino, columna incremental, tipo de watermark y claves de merge. |
| `connection_config` | Catalogo de conexiones logicas usadas por las configuraciones tecnicas. Permite centralizar el `fabric_connection_id` y evitar repetirlo por dataset. |
| `bronze_ingestion_config` | Configuracion fisica de ingesta hacia bronze para Copy Data de Fabric: origen SQL, consulta, destino ADLS Gen2, ruta y formato. Se define una vez por dataset. |
| `pipeline_dependency` | Dependencias entre datasets/pipelines. Modela que un proceso hijo depende de un proceso padre y con que frescura esperada. |
| `pipeline_dependency_group` | Agrupacion ordenada de datasets/pipelines para orquestacion. Permite activar/desactivar miembros y definir orden de ejecucion. |
| `pipeline_dependency_group_schedule` | Planificaciones asociadas a grupos de dependencia. Define expresion de calendario, zona horaria y estado activo. |
| `dataset_execution_policy` | Politica propia del dataset para decidir si debe recargarse o si puede reutilizar una carga exitosa reciente. No depende de `pipeline_name`. |
| `pipeline_execution_config` | Configuracion tecnica para ejecutar un pipeline segun su plataforma y capa del medallero. Para Fabric guarda `group_id`, `pipeline_id` y parametros; para Databricks guarda `workspace`, `path` y parametros. |
| `lineage` | Trazabilidad tecnica de entradas y salidas por ejecucion/tarea. Sirve para entender que tablas alimentaron que resultados. |
| `data_quality` | Resultado de controles de calidad por ejecucion/tarea. Guarda metrica medida, umbral y estado del control. |
| `schema_version` | Historial de inicializaciones/migraciones del esquema de metadata. Registra version aplicada y cambios estructurales detectados. |

## Notas de modelado

- `run.run_id`, `task_run.task_run_id`, `error_log.error_id`, `schema_version.version`,
  `connection_config.connection_key`, `pipeline_dependency_group.group_name` y
  `pipeline_dependency_group_schedule.schedule_name`
  funcionan como identificadores logicos.
- `dataset_config` se interpreta con clave logica compuesta por `pipeline_name` + `dataset`.
- `bronze_ingestion_config` se interpreta con clave logica `dataset`. Un mismo dataset
  bronze debe tener una sola definicion canonica de ingesta, independiente del pipeline que
  lo consuma.
- `connection_config` centraliza ids de conexion de Fabric. Las tablas de configuracion
  referencian `connection_key` para no repetir `fabric_connection_id` en cada dataset.
- `dataset_execution_policy` se interpreta con clave logica `dataset`. La decision de saltear
  una carga se basa en la ultima tarea `SUCCESS` registrada para ese dataset y
  `min_interval_minutes`; `schedule_expr` queda disponible para planificacion externa o
  validaciones posteriores de calendario.
- `pipeline_execution_config` se interpreta con clave logica `pipeline_name`.
  `medallion_layer` clasifica el pipeline como `bronze`, `silver` o `gold`; se espera
  que un mismo `pipeline_name` pertenezca a una unica capa.
  El campo `execution_engine` determina que columnas especificas deben completarse:
  `fabric_group_id` + `fabric_pipeline_id` para Fabric, o `databricks_workspace` +
  `databricks_path` para Databricks.
- `parameters_json` queda como texto JSON para admitir parametros heterogeneos por
  plataforma sin modificar el esquema por cada variacion.
- `pipeline_dependency` referencia dos veces a `dataset_config`: una como padre y otra como hijo.
- `schema_version` queda aislada del flujo operativo porque registra cambios de estructura,
  no eventos de ejecucion.
