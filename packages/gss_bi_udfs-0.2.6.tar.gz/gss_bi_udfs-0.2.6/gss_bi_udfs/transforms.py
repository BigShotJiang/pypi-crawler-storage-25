import re

from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.functions import concat_ws, col, xxhash64
from pyspark.sql.types import StringType

from .utils import get_default_value_by_type


def _normalize_column_name(column_name: str) -> str:
    normalized = re.sub(r"[^a-zA-Z0-9_]", "_", column_name.strip().lower())
    normalized = re.sub(r"_+", "_", normalized).strip("_")
    return normalized or column_name


def clean_dataset(
        df: DataFrame,
        *,
        normalize_column_names: bool = True,
        trim_strings: bool = True,
        empty_strings_as_null: bool = True,
        drop_empty_rows: bool = True,
        drop_duplicates: bool = False,
        fillna: dict | None = None
    ) -> DataFrame:
        """
        Aplica limpieza básica y reutilizable sobre un DataFrame Spark.

        Parametros:
            df: DataFrame de Spark de entrada.
            normalize_column_names: Normaliza nombres de columnas.
            trim_strings: Quita espacios al inicio y fin en columnas string.
            empty_strings_as_null: Convierte strings vacíos en null.
            drop_empty_rows: Elimina filas donde todas las columnas son null.
            drop_duplicates: Elimina filas duplicadas.
            fillna: Diccionario opcional para completar nulos con valores específicos.

        Retorna:
            DataFrame limpio.
        """

        result = df

        if normalize_column_names:
            used_names = set()
            renamed_columns = []

            for old_name in result.columns:
                base_name = _normalize_column_name(old_name)
                new_name = base_name
                suffix = 2

                while new_name in used_names:
                    new_name = f"{base_name}_{suffix}"
                    suffix += 1

                used_names.add(new_name)
                renamed_columns.append(col(old_name).alias(new_name))

            result = result.select(*renamed_columns)

        string_cols = [
            field.name
            for field in result.schema.fields
            if isinstance(field.dataType, StringType)
        ]

        for column_name in string_cols:
            clean_col = col(column_name)

            if trim_strings:
                clean_col = F.trim(clean_col)

            if empty_strings_as_null:
                clean_col = F.when(clean_col == "", F.lit(None)).otherwise(clean_col)

            result = result.withColumn(column_name, clean_col)

        if drop_empty_rows:
            result = result.dropna(how="all")

        if drop_duplicates:
            result = result.dropDuplicates()

        if fillna:
            result = result.fillna(fillna)

        return result


def add_hashid(
        df: DataFrame,
        columns: list[str],
        new_col_name: str = "hashid"
    ) -> DataFrame:
        """
        Agrega una columna hash (PK) a partir de la concatenación de columnas
        y reordena el DataFrame dejando el hash como primera columna.

        Parametros:
            df: DataFrame de Spark de entrada
            columns: Lista de columnas a concatenar
            new_col_name: Nombre de la columna hash (default: hashid)
            
        Retorna:
            DataFrame con hash agregado
        """

        if not columns:
            raise ValueError("La lista de columnas no puede estar vacía")

        # Concatenación segura
        concatenated = concat_ws("|", *[col(c).cast("string") for c in columns])

        # Hash rápido y determinístico (ideal para PK técnica)
        df_with_hash = df.withColumn(new_col_name, xxhash64(concatenated))

        # Reordenar columnas
        original_cols = [c for c in df.columns if c != new_col_name]
        new_cols = [new_col_name] + original_cols

        return df_with_hash.select(*new_cols)
    

def get_default_record(spark, df: DataFrame) -> DataFrame:
    """
    Crea un DataFrame con un único registro de valores por defecto según el esquema de df:
    Parámetros:
        spark: SparkSession activo.
        df (DataFrame): DataFrame de Spark del cual se tomará el esquema.
        
    Retorna:
        DataFrame: DataFrame con un único registro con valores por defecto.
    """
    defaults = [
        get_default_value_by_type(field.dataType)
            .cast(field.dataType)
            .alias(field.name)
        for field in df.schema.fields
    ]

    return spark.range(1).select(*defaults)
