"""Core semantic diff engine."""
