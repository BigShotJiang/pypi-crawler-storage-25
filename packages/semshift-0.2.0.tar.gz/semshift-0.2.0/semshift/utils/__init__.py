"""Utility helpers for semshift."""
