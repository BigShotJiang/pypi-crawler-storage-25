from typing import Any

import httpx
import pytest
import respx

from pybdl.api.version import VersionAPI
from pybdl.config import BDLConfig


@pytest.fixture
def version_api(dummy_config: BDLConfig) -> VersionAPI:
    return VersionAPI(dummy_config)


@pytest.mark.unit
def test_get_version(respx_mock: respx.MockRouter, version_api: VersionAPI, api_url: str) -> None:
    url = f"{api_url}/version?lang=en&format=json"
    payload = {"version": "1.2.3", "build": "2025-06-11"}
    respx_mock.get(url).mock(return_value=httpx.Response(200, json=payload))
    result = version_api.get_version()
    assert result["version"] == "1.2.3"
    assert result["build"] == "2025-06-11"


@pytest.mark.asyncio
async def test_aget_version(monkeypatch: pytest.MonkeyPatch) -> None:
    api = VersionAPI(BDLConfig(api_key="dummy"))

    async def fake_afetch_single_result(
        endpoint: str,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        results_key: str | None = None,
    ) -> dict[str, str]:
        assert endpoint == "version"
        return {"version": "2.0.0", "build": "future"}

    monkeypatch.setattr(api, "afetch_single_result", fake_afetch_single_result)
    result = await api.aget_version()
    assert result["version"] == "2.0.0"
    assert result["build"] == "future"
