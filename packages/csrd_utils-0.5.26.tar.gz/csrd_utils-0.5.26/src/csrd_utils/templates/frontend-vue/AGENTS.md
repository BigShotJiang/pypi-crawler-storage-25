# Frontend (Vue 3 + TypeScript) — Agent & Developer Guide

This document explains the generated frontend architecture and how to extend it.

## Stack

| Tool        | Version | Purpose                  |
|-------------|---------|--------------------------|
| Vue         | 3.5+    | Reactive UI framework    |
| Vue Router  | 4.5+    | Client-side routing      |
| TypeScript  | 5.8+    | Type safety              |
| Vite        | 6+      | Dev server & bundler     |

No component library — styles are plain CSS so you can swap in any framework.

## Project Structure

```
src/
├── api/            # HTTP client & per-resource API modules
│   ├── client.ts   # fetch wrapper, token management, error interception
│   ├── auth.ts     # login / signup calls
│   ├── items.ts    # CRUD for items resource
│   └── users.ts    # admin user / role management calls
├── composables/    # Vue composables — reactive wrappers around API modules
│   ├── useAuth.ts  # auth state, login/signup/logout, JWT decode
│   ├── useItems.ts # items CRUD with loading/error state
│   ├── useUsers.ts # user admin with loading/error/success state
│   └── useToast.ts # global toast notification system
├── router/         # route definitions + navigation guards
│   └── index.ts
├── views/          # page-level components (one per route)
│   ├── DashboardView.vue
│   ├── LoginView.vue
│   ├── SignupView.vue
│   ├── admin/
│   │   └── UserAdminView.vue
│   └── items/
│       ├── ItemListView.vue
│       └── ItemFormView.vue
├── App.vue         # root layout: navbar, router-view, toast container
├── main.ts         # app bootstrap
└── env.d.ts        # Vite + Vue type shims
```

## Architecture Rules

### Three-layer separation

```
views/  →  composables/  →  api/
  UI          state          HTTP
```

1. **Views** render UI and call composable methods. They never import from `api/`.
2. **Composables** own reactive state (`ref`, `computed`), call API functions, and handle loading/error patterns. They re-export types from their API module.
3. **API modules** are pure async functions — no reactive state, no UI logic. Each module maps to one backend resource.

This separation means you can:
- Swap the HTTP layer (e.g. replace `fetch` with `axios`) without touching views.
- Test composables by mocking `api/` functions.
- Reuse composables across multiple views.

### Import direction

Imports flow **downward only** — never upward:

- `views/` → `composables/` ✓
- `composables/` → `api/` ✓
- `api/` → `composables/` ✗ (never)
- `views/` → `api/` ✗ (never — go through a composable)

**Exception**: `api/client.ts` uses a callback (`onAuthCleared`) to notify `useAuth` of 401 responses without importing it. This avoids a circular dependency.

### Types

Types (interfaces) are defined in `api/` modules alongside the functions that use them, then **re-exported** from the corresponding composable:

```ts
// In composables/useItems.ts
export type { Item, ItemCreate }
```

Views import types from the composable, not from `api/`:

```ts
// In views/items/ItemListView.vue
import { useItems, type Item } from '../../composables/useItems'
```

### Routes are lazy-loaded

All route components use dynamic `() => import(...)` syntax for code-splitting. This means each page is a separate chunk — the initial bundle only contains the shell.

## How To: Add a New Resource

Example: adding a `Project` resource with list + create views.

### 1. Create the API module

```ts
// src/api/projects.ts
import { request } from './client'

export interface Project {
  id: string
  name: string
  status: string
}

export interface ProjectCreate {
  name: string
  status: string
}

export async function listProjects(): Promise<Project[]> {
  return request<Project[]>('/projects')
}

export async function createProject(payload: ProjectCreate): Promise<Project> {
  return request<Project>('/projects', { method: 'POST', body: payload })
}
```

### 2. Create the composable

```ts
// src/composables/useProjects.ts
import { ref } from 'vue'
import {
  listProjects,
  createProject,
  type Project,
  type ProjectCreate,
} from '../api/projects'

export type { Project, ProjectCreate }

export function useProjects() {
  const projects = ref<Project[]>([])
  const loading = ref(false)
  const error = ref('')

  async function loadAll() {
    loading.value = true
    error.value = ''
    try {
      projects.value = await listProjects()
    } catch (e: any) {
      error.value = e.message || 'Failed to load projects'
    } finally {
      loading.value = false
    }
  }

  async function create(payload: ProjectCreate): Promise<boolean> {
    error.value = ''
    try {
      await createProject(payload)
      return true
    } catch (e: any) {
      error.value = e.message || 'Failed to create project'
      return false
    }
  }

  return { projects, loading, error, loadAll, create }
}
```

### 3. Create the view(s)

```vue
<!-- src/views/projects/ProjectListView.vue -->
<script setup lang="ts">
import { onMounted } from 'vue'
import { useProjects } from '../../composables/useProjects'

const { projects, loading, error, loadAll } = useProjects()
onMounted(loadAll)
</script>

<template>
  <div>
    <h1>Projects</h1>
    <div v-if="loading">Loading...</div>
    <div v-else-if="error" class="error">{{ error }}</div>
    <ul v-else>
      <li v-for="p in projects" :key="p.id">{{ p.name }} — {{ p.status }}</li>
    </ul>
  </div>
</template>
```

### 4. Add the route

```ts
// In src/router/index.ts — add the lazy import and route entry:

const ProjectListView = () => import('../views/projects/ProjectListView.vue')

// In the routes array:
{ path: '/projects', name: 'projects', component: ProjectListView },
```

### 5. Add a nav link (optional)

In `App.vue`, add inside the authenticated `<template>` block:

```html
<router-link to="/projects">Projects</router-link>
```

## How To: Add Role-Gated Pages

The router guard already supports `meta.admin`. To gate a route to admin users:

```ts
{ path: '/admin/settings', component: SettingsView, meta: { admin: true } }
```

For custom role checks, extend the `beforeEach` guard in `router/index.ts`.

## How To: Change the HTTP Client

All HTTP calls go through `api/client.ts`. To switch to `axios`:

1. Install: `npm install axios`
2. Replace the `request()` function body in `client.ts`.
3. Keep the same function signature — composables and views don't change.

## How To: Add a UI Component Library

The template ships with plain CSS. To add a library (e.g. PrimeVue, Vuetify):

1. Install the library: `npm install primevue`
2. Register it in `main.ts` (before `app.mount()`).
3. Replace HTML elements in views with library components.
4. Remove the CSS in `App.vue` that you no longer need.

## API Proxy

During development, Vite proxies `/api` requests to the gateway service. This is configured in `vite.config.ts` under `server.proxy`. In production, configure your reverse proxy (nginx, Caddy, etc.) to route `/api` to the gateway.

## Path Aliases

`@/` is aliased to `src/` in both TypeScript and Vite configs. You can use it for deep imports:

```ts
import { useAuth } from '@/composables/useAuth'
```

## Toast Notifications

Use the `useToast` composable anywhere to show notifications:

```ts
const { success, error, info } = useToast()
success('Item created!')
error('Something went wrong')
info('Processing...')
```

Toasts auto-dismiss (4s info/success, 5s error). The container is rendered in `App.vue`.

## Auth Flow

1. User submits login form → `useAuth.login()` → `api/auth.login()` → POST `/api/token`
2. JWT is stored in `localStorage` and decoded for user info + roles.
3. `api/client.ts` attaches the `Authorization: Bearer` header to every request.
4. On 401 response, the client clears the token, shows a toast, and redirects to `/login`.
5. On app load, expired tokens are discarded automatically (30s grace window).

## Non-Negotiable Conventions

- **Views never import from `api/`** — always go through a composable.
- **Composables re-export types** from their API module.
- **Routes are always lazy-loaded** — no eager `import` for view components.
- **No direct `fetch()` calls** — always use `request()` from `api/client.ts`.
- **Error handling lives in composables** — views read `error` refs, they don't try/catch API calls (except login/signup which have form-local error state).
