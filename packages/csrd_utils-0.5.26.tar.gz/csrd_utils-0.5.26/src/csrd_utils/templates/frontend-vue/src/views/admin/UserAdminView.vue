<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useUsers } from '../../composables/useUsers'

const newRole = ref('')
const { users, userInfo, userRoles, loading, error, successMsg, loadAll, lookup, addRole } = useUsers()

async function selectUser(userId: string) {
  await lookup(userId)
}

async function handleAddRole() {
  if (!newRole.value.trim()) return
  const role = newRole.value.trim().toUpperCase()
  const ok = await addRole(role)
  if (ok) newRole.value = ''
}

onMounted(loadAll)
</script>

<template>
  <div class="admin-users">
    <h1>User Administration</h1>

    <div v-if="loading && !userInfo" class="status">Loading...</div>
    <div v-if="error && !userInfo" class="message error">{{ error }}</div>

    <div v-if="users.length > 0" class="user-table-section">
      <table class="table">
        <thead>
          <tr>
            <th>Username</th>
            <th>ID</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="u in users" :key="u.id" :class="{ selected: userInfo?.id === u.id }">
            <td>{{ u.username }}</td>
            <td class="id-cell">{{ u.id }}</td>
            <td>
              <button class="btn btn-sm" @click="selectUser(u.id)">Manage</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <div v-if="error && userInfo" class="message error">{{ error }}</div>
    <div v-if="successMsg" class="message success">{{ successMsg }}</div>

    <div v-if="userInfo" class="user-card">
      <h2>{{ userInfo.username }}</h2>
      <p class="user-id">ID: {{ userInfo.id }}</p>

      <div v-if="userRoles" class="roles-section">
        <h3>Roles</h3>
        <div class="role-list">
          <span v-if="userRoles.roles.length === 0" class="no-roles">No roles assigned</span>
          <span v-for="role in userRoles.roles" :key="role" class="role-badge">
            {{ role }}
          </span>
        </div>

        <div class="add-role">
          <input
            v-model="newRole"
            type="text"
            placeholder="Role name (e.g. ADMIN)"
            @keyup.enter="handleAddRole"
          />
          <button class="btn btn-sm btn-primary" @click="handleAddRole">Add Role</button>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.admin-users h1 {
  margin-bottom: 1.5rem;
}

.status {
  padding: 2rem;
  text-align: center;
  color: #666;
}

.user-table-section {
  margin-bottom: 2rem;
}

.table {
  width: 100%;
  border-collapse: collapse;
}

.table th,
.table td {
  padding: 0.75rem;
  text-align: left;
  border-bottom: 1px solid #ddd;
}

.table th {
  font-weight: 600;
  font-size: 0.85rem;
  text-transform: uppercase;
  color: #666;
}

.id-cell {
  font-family: monospace;
  font-size: 0.8rem;
  color: #888;
}

tr.selected {
  background: #f0f4ff;
}

.message {
  padding: 0.75rem;
  border-radius: 4px;
  margin-bottom: 1rem;
  font-size: 0.9rem;
}

.error {
  background: #f8d7da;
  color: #721c24;
}

.success {
  background: #d4edda;
  color: #155724;
}

.user-card {
  border: 1px solid #ddd;
  border-radius: 8px;
  padding: 1.5rem;
  background: #fff;
}

.user-card h2 {
  margin-bottom: 0.25rem;
}

.user-id {
  color: #666;
  font-size: 0.85rem;
  font-family: monospace;
  margin-bottom: 1.5rem;
}

.roles-section h3 {
  font-size: 1rem;
  margin-bottom: 0.75rem;
}

.role-list {
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
  margin-bottom: 1rem;
}

.role-badge {
  display: inline-block;
  padding: 0.25rem 0.75rem;
  background: #1a1a2e;
  color: #fff;
  border-radius: 12px;
  font-size: 0.8rem;
  font-weight: 600;
}

.no-roles {
  color: #999;
  font-size: 0.85rem;
}

.add-role {
  display: flex;
  gap: 0.5rem;
  align-items: center;
}

.add-role input {
  padding: 0.35rem 0.5rem;
  border: 1px solid #ccc;
  border-radius: 4px;
  font-size: 0.85rem;
  width: 200px;
}
</style>
