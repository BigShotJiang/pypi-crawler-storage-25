<script setup lang="ts">
import { ref, onMounted, computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useItems } from '../../composables/useItems'

const route = useRoute()
const router = useRouter()
const { loading, error, load, save } = useItems()

const name = ref('')
const description = ref('')
const saving = ref(false)

const itemId = computed(() => route.params.id as string | undefined)
const isEdit = computed(() => !!itemId.value)
const title = computed(() => (isEdit.value ? 'Edit Item' : 'New Item'))

async function loadItem() {
  if (!itemId.value) return
  const item = await load(itemId.value)
  if (item) {
    name.value = item.name
    description.value = item.description
  }
}

async function handleSubmit() {
  saving.value = true
  const ok = await save({ name: name.value, description: description.value }, itemId.value)
  saving.value = false
  if (ok) router.push('/items')
}

onMounted(loadItem)
</script>

<template>
  <div class="item-form">
    <h1>{{ title }}</h1>

    <div v-if="loading" class="status">Loading...</div>

    <form v-else class="form" @submit.prevent="handleSubmit">
      <div class="form-group">
        <label for="name">Name</label>
        <input id="name" v-model="name" type="text" required />
      </div>
      <div class="form-group">
        <label for="description">Description</label>
        <textarea id="description" v-model="description" rows="4"></textarea>
      </div>
      <div v-if="error" class="error">{{ error }}</div>
      <div class="form-actions">
        <button class="btn btn-primary" type="submit" :disabled="saving">
          {{ saving ? 'Saving...' : 'Save' }}
        </button>
        <button class="btn" type="button" @click="router.push('/items')">Cancel</button>
      </div>
    </form>
  </div>
</template>

<style scoped>
.item-form {
  max-width: 600px;
}

.form {
  display: flex;
  flex-direction: column;
  gap: 1rem;
  margin-top: 1.5rem;
}

.form-group {
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
}

.form-group label {
  font-size: 0.85rem;
  font-weight: 600;
}

.form-group input,
.form-group textarea {
  padding: 0.5rem;
  border: 1px solid #ccc;
  border-radius: 4px;
  font-size: 0.95rem;
  font-family: inherit;
}

.error {
  color: #dc3545;
  font-size: 0.85rem;
}

.form-actions {
  display: flex;
  gap: 0.75rem;
}

.status {
  padding: 2rem;
  color: #666;
}
</style>
