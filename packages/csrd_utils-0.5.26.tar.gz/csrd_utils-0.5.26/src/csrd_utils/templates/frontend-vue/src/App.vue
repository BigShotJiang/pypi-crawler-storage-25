<script setup lang="ts">
import { useAuth } from './composables/useAuth'
import { useToast } from './composables/useToast'

const { isAuthenticated, isAdmin, user, logout } = useAuth()
const { toasts } = useToast()
</script>

<template>
  <div class="app">
    <nav class="navbar">
      <div class="nav-brand">${workspace_name}</div>
      <div class="nav-links">
        <template v-if="isAuthenticated">
          <router-link to="/">Dashboard</router-link>
          <router-link to="/items">Items</router-link>
          <router-link v-if="isAdmin" to="/admin/users">Admin</router-link>
          <span class="nav-user">{{ user?.username }}</span>
          <button class="btn btn-sm" @click="logout">Logout</button>
        </template>
        <template v-else>
          <router-link to="/login">Login</router-link>
          <router-link to="/signup">Sign Up</router-link>
        </template>
      </div>
    </nav>
    <main class="content">
      <router-view />
    </main>
    <div class="toast-container">
      <div
        v-for="toast in toasts"
        :key="toast.id"
        class="toast"
        :class="`toast-$${toast.type}`"
      >
        {{ toast.message }}
      </div>
    </div>
  </div>
</template>

<style>
*,
*::before,
*::after {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

body {
  font-family: system-ui, -apple-system, sans-serif;
  color: #1a1a2e;
  background: #f5f5f5;
}

.app {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

.navbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0.75rem 1.5rem;
  background: #1a1a2e;
  color: #eee;
}

.nav-brand {
  font-weight: 700;
  font-size: 1.1rem;
}

.nav-links {
  display: flex;
  align-items: center;
  gap: 1rem;
}

.nav-links a {
  color: #ccc;
  text-decoration: none;
}

.nav-links a.router-link-active {
  color: #fff;
}

.nav-user {
  color: #aaa;
  font-size: 0.85rem;
}

.content {
  flex: 1;
  padding: 2rem;
  max-width: 960px;
  margin: 0 auto;
  width: 100%;
}

.btn {
  padding: 0.5rem 1rem;
  border: 1px solid #ccc;
  border-radius: 4px;
  background: #fff;
  cursor: pointer;
  font-size: 0.9rem;
}

.btn:hover {
  background: #f0f0f0;
}

.btn-primary {
  background: #1a1a2e;
  color: #fff;
  border-color: #1a1a2e;
}

.btn-primary:hover {
  background: #2a2a4e;
}

.btn-danger {
  background: #dc3545;
  color: #fff;
  border-color: #dc3545;
}

.btn-danger:hover {
  background: #c82333;
}

.btn-sm {
  padding: 0.25rem 0.5rem;
  font-size: 0.8rem;
}

.toast-container {
  position: fixed;
  top: 1rem;
  right: 1rem;
  z-index: 9999;
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  max-width: 400px;
}

.toast {
  padding: 0.75rem 1rem;
  border-radius: 6px;
  color: #fff;
  font-size: 0.9rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
  animation: slide-in 0.25s ease-out;
}

.toast-error {
  background: #dc3545;
}

.toast-info {
  background: #1a1a2e;
}

.toast-success {
  background: #28a745;
}

@keyframes slide-in {
  from {
    transform: translateX(100%);
    opacity: 0;
  }
  to {
    transform: translateX(0);
    opacity: 1;
  }
}
</style>
