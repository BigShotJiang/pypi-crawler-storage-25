<script setup lang="ts">
import { useAuth } from '../composables/useAuth'

const { user, isAdmin } = useAuth()
</script>

<template>
  <div class="dashboard">
    <h1>Dashboard</h1>
    <p>Welcome{{ user?.username ? `, $${user.username}` : '' }}.</p>
    <div class="quick-links">
      <h2>Quick Links</h2>
      <ul>
        <li><router-link to="/items">Manage Items</router-link></li>
        <li v-if="isAdmin"><router-link to="/admin/users">User Administration</router-link></li>
      </ul>
    </div>
  </div>
</template>

<style scoped>
.dashboard h1 {
  margin-bottom: 0.5rem;
}

.quick-links {
  margin-top: 2rem;
}

.quick-links h2 {
  font-size: 1.1rem;
  margin-bottom: 0.5rem;
}

.quick-links ul {
  list-style: none;
}

.quick-links a {
  color: #1a1a2e;
}
</style>
