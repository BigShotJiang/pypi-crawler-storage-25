<script setup lang="ts">
import { ref } from 'vue'
import { useAuth } from '../composables/useAuth'

const { signup } = useAuth()

const username = ref('')
const password = ref('')
const confirmPassword = ref('')
const error = ref('')
const loading = ref(false)

async function handleSubmit() {
  error.value = ''

  if (password.value !== confirmPassword.value) {
    error.value = 'Passwords do not match'
    return
  }

  loading.value = true
  try {
    await signup(username.value, password.value)
  } catch (e: any) {
    error.value = e.message || 'Sign up failed'
  } finally {
    loading.value = false
  }
}
</script>

<template>
  <div class="auth-page">
    <h1>Sign Up</h1>
    <form class="auth-form" @submit.prevent="handleSubmit">
      <div class="form-group">
        <label for="username">Username</label>
        <input id="username" v-model="username" type="text" required autocomplete="username" />
      </div>
      <div class="form-group">
        <label for="password">Password</label>
        <input id="password" v-model="password" type="password" required autocomplete="new-password" />
      </div>
      <div class="form-group">
        <label for="confirm-password">Confirm Password</label>
        <input id="confirm-password" v-model="confirmPassword" type="password" required autocomplete="new-password" />
      </div>
      <div v-if="error" class="error">{{ error }}</div>
      <button class="btn btn-primary" type="submit" :disabled="loading">
        {{ loading ? 'Creating account...' : 'Sign Up' }}
      </button>
      <p class="auth-link">
        Already have an account? <router-link to="/login">Login</router-link>
      </p>
    </form>
  </div>
</template>

<style scoped>
.auth-page {
  max-width: 400px;
  margin: 4rem auto;
}

.auth-form {
  display: flex;
  flex-direction: column;
  gap: 1rem;
  margin-top: 1.5rem;
}

.form-group {
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
}

.form-group label {
  font-size: 0.85rem;
  font-weight: 600;
}

.form-group input {
  padding: 0.5rem;
  border: 1px solid #ccc;
  border-radius: 4px;
  font-size: 0.95rem;
}

.error {
  color: #dc3545;
  font-size: 0.85rem;
}

.auth-link {
  font-size: 0.85rem;
  text-align: center;
}
</style>
