<script setup lang="ts">
import { onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useItems, type Item } from '../../composables/useItems'

const router = useRouter()
const { items, loading, error, loadAll, remove } = useItems()

async function handleDelete(item: Item) {
  if (!confirm(`Delete "$${item.name}"?`)) return
  await remove(item)
}

onMounted(loadAll)
</script>

<template>
  <div class="item-list">
    <div class="list-header">
      <h1>Items</h1>
      <button class="btn btn-primary" @click="router.push('/items/new')">
        + New Item
      </button>
    </div>

    <div v-if="loading" class="status">Loading...</div>
    <div v-else-if="error" class="status error">{{ error }}</div>
    <div v-else-if="items.length === 0" class="status">No items yet.</div>

    <table v-else class="table">
      <thead>
        <tr>
          <th>Name</th>
          <th>Description</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="item in items" :key="item.id">
          <td>{{ item.name }}</td>
          <td>{{ item.description }}</td>
          <td class="actions">
            <button class="btn btn-sm" @click="router.push(`/items/$${item.id}/edit`)">
              Edit
            </button>
            <button class="btn btn-sm btn-danger" @click="handleDelete(item)">
              Delete
            </button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<style scoped>
.list-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1.5rem;
}

.status {
  padding: 2rem;
  text-align: center;
  color: #666;
}

.error {
  color: #dc3545;
}

.table {
  width: 100%;
  border-collapse: collapse;
}

.table th,
.table td {
  padding: 0.75rem;
  text-align: left;
  border-bottom: 1px solid #ddd;
}

.table th {
  font-weight: 600;
  font-size: 0.85rem;
  text-transform: uppercase;
  color: #666;
}

.actions {
  display: flex;
  gap: 0.5rem;
}
</style>
