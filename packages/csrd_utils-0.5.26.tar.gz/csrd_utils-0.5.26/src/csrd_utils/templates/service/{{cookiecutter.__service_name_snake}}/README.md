# {{ cookiecutter.service_name }}

{{ cookiecutter.service_description }}

## Setup

```bash
# Install dependencies
uv sync
```

## Run

```bash
uvicorn {{ cookiecutter.__service_name_snake }}:build_app --factory --port {{ cookiecutter.port }}
```

## Docker

```bash
docker compose up --build
```

## Test

```bash
pytest
```
