"""
TTS Inference Script for amazingvmsloth

Usage:
    py scripts/infer_tts.py --model_dir ./output_tts --text "Hello world" --output out.wav

Supports:
  - REAL VITS models (facebook/mms-tts-eng fine-tuned) → direct waveform, high quality
  - Toy TinyTransformerTTS → Griffin-Lim, low quality
"""
import argparse
import json
import os
import sys

import torch


def save_wav(path: str, waveform: torch.Tensor, sample_rate: int):
    """Save waveform as standard WAV file using built-in wave module."""
    import wave
    import numpy as np
    waveform = waveform.cpu().to(torch.float32)  # Cast from bfloat16/float16
    waveform_np = waveform.numpy().squeeze()
    waveform_np = waveform_np / max(abs(waveform_np).max(), 1e-6)
    waveform_int16 = (waveform_np * 32767).astype("int16")
    with wave.open(path, "wb") as wav_file:
        wav_file.setnchannels(1)
        wav_file.setsampwidth(2)
        wav_file.setframerate(sample_rate)
        wav_file.writeframes(waveform_int16.tobytes())


def main():
    parser = argparse.ArgumentParser(description="TTS Inference")
    parser.add_argument("--model_dir", required=True, help="Path to training output directory")
    parser.add_argument("--text", required=True, help="Text to synthesize")
    parser.add_argument("--output", default="output.wav", help="Output .wav file path")
    parser.add_argument("--device", default="auto", help="cpu or cuda")
    parser.add_argument("--duration", type=float, default=0, help="Target duration in seconds (toy model only)")
    args = parser.parse_args()

    # Detect model type
    config_path = os.path.join(args.model_dir, "config.json")
    model_path = os.path.join(args.model_dir, "model.pt")
    vits_model_bin = os.path.join(args.model_dir, "pytorch_model.bin")
    vits_model_safe = os.path.join(args.model_dir, "model.safetensors")

    is_vits = os.path.exists(vits_model_bin) or os.path.exists(vits_model_safe)
    is_toy = os.path.exists(model_path)

    if not is_vits and not is_toy:
        print(f"ERROR: No model found in {args.model_dir}")
        print("Expected: pytorch_model.bin (VITS) or model.pt (toy)")
        sys.exit(1)

    # Device
    if args.device == "auto":
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    else:
        device = torch.device(args.device)
    print(f"[infer] Using device: {device}")

    # ========================================================================
    # REAL VITS PATH
    # ========================================================================
    if is_vits:
        print(f"[infer] Loading REAL VITS model from: {args.model_dir}")
        from transformers import VitsModel, VitsTokenizer
        from amazingvmsloth.tasks.base import apply_lora_to_module

        tokenizer = VitsTokenizer.from_pretrained(args.model_dir)
        model = VitsModel.from_pretrained(args.model_dir)

        # Re-apply LoRA architecture and load weights
        model = apply_lora_to_module(model, r=8, lora_alpha=16)
        state_dict = torch.load(os.path.join(args.model_dir, "model.pt"), map_location=device, weights_only=False)
        model.load_state_dict(state_dict)

        model.to(device)
        model.eval()
        print(f"[infer] VITS loaded: {sum(p.numel() for p in model.parameters())/1e6:.1f}M params")

        # Tokenize
        inputs = tokenizer(args.text, return_tensors="pt")
        input_ids = inputs["input_ids"].to(device)

        print(f"[infer] Synthesizing: '{args.text}'")
        with torch.no_grad():
            outputs = model(input_ids)
            waveform = outputs.waveform.squeeze(0).cpu()  # (T,)

        # Save
        save_wav(args.output, waveform, 16000)
        duration = waveform.shape[0] / 16000
        print(f"[infer] Saved {duration:.1f}s REAL VITS audio to: {os.path.abspath(args.output)}")
        return

    # ========================================================================
    # TOY TinyTransformerTTS PATH
    # ========================================================================
    with open(config_path, "r", encoding="utf-8") as f:
        cfg = json.load(f)

    model_type = cfg.get("model_type", "TinyTransformerTTS")
    if model_type == "TinyTransformerTTS":
        from amazingvmsloth.tasks.tts import TinyTransformerTTS
        from amazingvmsloth.tasks.base import apply_lora_to_module
        model = TinyTransformerTTS(
            vocab_size=cfg.get("vocab_size", 256),
            d_model=cfg.get("d_model", 512),
            n_layers=cfg.get("n_layers", 6),
            n_mels=cfg.get("n_mels", 80),
            max_mel_len=cfg.get("max_mel_len", 256),
        )
        model = apply_lora_to_module(model, r=cfg.get("lora_r", 8), lora_alpha=cfg.get("lora_alpha", 16))
        state_dict = torch.load(model_path, map_location=device, weights_only=False)
        model.load_state_dict(state_dict)
        model.to(device)
        model.eval()
        print(f"[infer] Loaded toy {model_type} with {sum(p.numel() for p in model.parameters()):,} params")

        from amazingvmsloth.tasks.base import CharTokenizer
        tokenizer = CharTokenizer(vocab_size=cfg.get("vocab_size", 256))
        tokens = tokenizer([args.text], max_length=512, return_tensors="pt")
        input_ids = tokens["input_ids"].to(device)

        if args.duration > 0:
            sample_rate = cfg.get("sample_rate", 24000)
            hop_length = cfg.get("hop_length", 256)
            target_frames = int(args.duration * sample_rate / hop_length)
            model.max_mel_len = target_frames
            print(f"[infer] Target duration: {args.duration}s ({target_frames} mel frames)")

        print(f"[infer] Synthesizing: '{args.text}'")
        with torch.no_grad():
            mel = model(input_ids)  # (1, n_mels, T)

        # Griffin-Lim
        import torchaudio
        mel_lin = torch.exp(mel.clamp(min=-10, max=10))
        sample_rate = cfg.get("sample_rate", 24000)
        n_fft = cfg.get("n_fft", 1024)
        hop_length = cfg.get("hop_length", 256)
        n_mels = cfg.get("n_mels", 80)
        n_stft = n_fft // 2 + 1
        inv_mel = torchaudio.transforms.InverseMelScale(n_stft=n_stft, n_mels=n_mels, sample_rate=sample_rate).to(device)
        spec = inv_mel(mel_lin.squeeze(0))
        griffin = torchaudio.transforms.GriffinLim(n_fft=n_fft, hop_length=hop_length, n_iter=60).to(device)
        waveform = griffin(spec)
        save_wav(args.output, waveform, sample_rate)
        duration = waveform.shape[0] / sample_rate
        print(f"[infer] Saved {duration:.1f}s toy audio to: {os.path.abspath(args.output)}")
    else:
        print(f"ERROR: Unsupported model_type: {model_type}")
        sys.exit(1)


if __name__ == "__main__":
    main()
