"""
Generic PyTorch trainer with LoRA for arbitrary model architectures.
Supports any nn.Module — not just HuggingFace Transformers.

Used by:
  - TTS trainer (Kokoro, Piper-style, custom StyleTTS2)
  - Diffusion trainer (Stable Diffusion, Flux, CogVideoX)
  - Any custom PyTorch model with nn.Linear layers

Key features:
  - Auto-discovers nn.Linear layers and applies LoRA
  - Char-level / phoneme-level tokenizer fallback
  - Works with models that don't have .from_pretrained()
  - Supports single-file datasets (auto-duplicates)
"""
import os
import json
import math
import time
import random
from typing import Optional, Dict, Any, List, Callable, Union, Tuple
from dataclasses import dataclass, asdict
from pathlib import Path

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset


# ---------------------------------------------------------------------------
# Generic Char / Phoneme Tokenizer
# ---------------------------------------------------------------------------

class CharTokenizer:
    """Dead-simple character-level tokenizer.

    Works with ANY text — no vocab files, no HF dependencies.
    Maps ASCII + common unicode chars to IDs.
    """

    def __init__(self, vocab_size: int = 256):
        self.vocab_size = vocab_size
        self.pad_token_id = 0
        self.eos_token_id = 1
        self.unk_token_id = 2
        self.bos_token_id = 3
        # Reserve first 4 IDs for special tokens
        self._offset = 4

    def __call__(self, text: Union[str, List[str]], max_length: int = 512, padding: bool = True, truncation: bool = True, return_tensors: str = "pt") -> Dict[str, torch.Tensor]:
        if isinstance(text, str):
            text = [text]
        all_ids = []
        for t in text:
            ids = [self.bos_token_id]
            for ch in t:
                code = ord(ch)
                if code < self.vocab_size - self._offset:
                    ids.append(code + self._offset)
                else:
                    ids.append(self.unk_token_id)
            ids.append(self.eos_token_id)
            if truncation and len(ids) > max_length:
                ids = ids[:max_length]
            all_ids.append(ids)

        if padding:
            max_len = max(len(seq) for seq in all_ids)
            max_len = min(max_len, max_length)
            padded = []
            masks = []
            for seq in all_ids:
                if len(seq) < max_len:
                    seq = seq + [self.pad_token_id] * (max_len - len(seq))
                else:
                    seq = seq[:max_len]
                mask = [1 if i != self.pad_token_id else 0 for i in seq]
                padded.append(seq)
                masks.append(mask)
        else:
            padded = all_ids
            masks = [[1] * len(seq) for seq in all_ids]

        if return_tensors == "pt":
            return {
                "input_ids": torch.tensor(padded, dtype=torch.long),
                "attention_mask": torch.tensor(masks, dtype=torch.long),
            }
        return {"input_ids": padded, "attention_mask": masks}

    def encode(self, text: str, max_length: int = 512) -> List[int]:
        out = self([text], max_length=max_length, return_tensors=None)
        return out["input_ids"][0]

    def decode(self, ids: Union[List[int], torch.Tensor]) -> str:
        if isinstance(ids, torch.Tensor):
            ids = ids.tolist()
        chars = []
        for i in ids:
            if i == self.pad_token_id or i == self.eos_token_id or i == self.bos_token_id:
                continue
            if i == self.unk_token_id:
                chars.append("?")
            else:
                code = i - self._offset
                if 0 <= code < self.vocab_size:
                    try:
                        chars.append(chr(code))
                    except ValueError:
                        chars.append("?")
        return "".join(chars)


# ---------------------------------------------------------------------------
# Raw LoRA applicator (works on ANY nn.Module)
# ---------------------------------------------------------------------------

def apply_lora_to_module(
    module: nn.Module,
    r: int = 16,
    lora_alpha: int = 32,
    target_modules: Optional[List[str]] = None,
    merge_weights: bool = False,
) -> nn.Module:
    """Inject LoRA layers into all nn.Linear submodules matching target_modules.

    If target_modules is None, applies to ALL nn.Linear layers.
    """
    import re

    replaced = 0
    for name, m in module.named_modules():
        if not isinstance(m, nn.Linear):
            continue
        # Check target name filter
        if target_modules is not None:
            if not any(t in name for t in target_modules):
                continue
        # Skip nn.MultiheadAttention internals (in_proj / out_proj)
        # PyTorch accesses these as raw nn.Linear attributes
        parent_name = ".".join(name.split(".")[:-1])
        if parent_name:
            parent = module.get_submodule(parent_name)
            if isinstance(parent, nn.MultiheadAttention):
                continue
        # Replace with LoRA linear
        parent_name = ".".join(name.split(".")[:-1])
        child_name = name.split(".")[-1]
        parent = module.get_submodule(parent_name) if parent_name else module
        lora_layer = LoRALinear(m, r=r, lora_alpha=lora_alpha)
        setattr(parent, child_name, lora_layer)
        replaced += 1

    # Freeze base weights, keep LoRA trainable
    trainable = 0
    total = 0
    for p in module.parameters():
        total += p.numel()
        if "lora_A" in str(id(p)) or "lora_B" in str(id(p)):
            # This heuristic is weak; better to check by name
            pass

    # Proper freeze: anything NOT containing "lora_" in name gets frozen
    for name, p in module.named_parameters():
        if "lora_" not in name:
            p.requires_grad = False
        else:
            trainable += p.numel()

    print(f"[lora] Applied LoRA to {replaced} layers. {trainable:,} params trainable / {sum(p.numel() for p in module.parameters()):,} total")
    return module


class LoRALinear(nn.Module):
    """Drop-in replacement for nn.Linear with LoRA."""

    def __init__(self, base_layer: nn.Linear, r: int = 16, lora_alpha: int = 32, dropout: float = 0.0):
        super().__init__()
        self.base_layer = base_layer
        self.r = r
        self.lora_alpha = lora_alpha
        self.scaling = lora_alpha / r
        self.lora_dropout = nn.Dropout(dropout) if dropout > 0 else nn.Identity()
        in_f = base_layer.in_features
        out_f = base_layer.out_features
        self.lora_A = nn.Parameter(torch.zeros(in_f, r))
        self.lora_B = nn.Parameter(torch.zeros(r, out_f))
        nn.init.kaiming_uniform_(self.lora_A, a=math.sqrt(5))
        nn.init.zeros_(self.lora_B)
        # Freeze base
        self.base_layer.weight.requires_grad = False
        if self.base_layer.bias is not None:
            self.base_layer.bias.requires_grad = False

    @property
    def weight(self):
        return self.base_layer.weight

    @property
    def bias(self):
        return self.base_layer.bias

    @property
    def in_features(self):
        return self.base_layer.in_features

    @property
    def out_features(self):
        return self.base_layer.out_features

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        base = self.base_layer(x)
        lora = self.lora_dropout(x) @ self.lora_A @ self.lora_B * self.scaling
        return base + lora


# ---------------------------------------------------------------------------
# Generic Trainer Config
# ---------------------------------------------------------------------------

@dataclass
class RawTrainingConfig:
    output_dir: str = "./output"
    num_train_epochs: int = 3
    per_device_train_batch_size: int = 1
    gradient_accumulation_steps: int = 4
    learning_rate: float = 2e-4
    max_steps: int = 0
    bf16: bool = True
    fp16: bool = False
    max_grad_norm: float = 1.0
    logging_steps: int = 10
    save_steps: int = 0
    seed: int = 42
    compile_model: bool = False
    silent: bool = False


# ---------------------------------------------------------------------------
# Generic Trainer Base Class
# ---------------------------------------------------------------------------

class RawTrainer:
    """Train any PyTorch model + LoRA with a simple MSE or CE loss."""

    def __init__(
        self,
        model: nn.Module,
        train_dataset: Dataset,
        collate_fn: Optional[Callable] = None,
        loss_fn: Optional[Callable] = None,
        config: Optional[RawTrainingConfig] = None,
    ):
        self.model = model
        self.train_dataset = train_dataset
        self.config = config or RawTrainingConfig()
        self.collate_fn = collate_fn
        self.loss_fn = loss_fn or nn.MSELoss()
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self._global_step = 0
        self._log_history: List[Dict[str, Any]] = []

    def _setup(self):
        torch.manual_seed(self.config.seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(self.config.seed)
        self.model.to(self.device)
        trainable = [p for p in self.model.parameters() if p.requires_grad]
        self.optimizer = torch.optim.AdamW(trainable, lr=self.config.learning_rate)
        self.dataloader = DataLoader(
            self.train_dataset,
            batch_size=self.config.per_device_train_batch_size,
            shuffle=True,
            collate_fn=self.collate_fn,
            num_workers=0,
            pin_memory=torch.cuda.is_available(),
        )

    def train(self) -> Dict[str, Any]:
        self._setup()
        if not self.config.silent:
            print(f"\n{'='*60}")
            print(f"  Raw PyTorch Training (Generic)")
            print(f"  Epochs: {self.config.num_train_epochs}")
            print(f"  Batch:  {self.config.per_device_train_batch_size}")
            print(f"  Accum:  {self.config.gradient_accumulation_steps}")
            print(f"  LR:     {self.config.learning_rate}")
            print(f"{'='*60}\n")

        from tqdm import tqdm
        total_steps_est = max(1, len(self.dataloader) // self.config.gradient_accumulation_steps * self.config.num_train_epochs)
        if self.config.max_steps > 0:
            total_steps_est = min(total_steps_est, self.config.max_steps)
        pbar = tqdm(total=total_steps_est, desc="Training", unit="step")

        start_time = time.time()
        self.model.train()

        for epoch in range(self.config.num_train_epochs):
            epoch_loss = 0.0
            step_count = 0
            accum_loss = 0.0

            for i, batch in enumerate(self.dataloader):
                # batch is a dict of tensors or custom structure
                if isinstance(batch, dict):
                    batch = {k: v.to(self.device) if isinstance(v, torch.Tensor) else v for k, v in batch.items()}

                loss = self._compute_loss(batch)
                if loss is None:
                    continue

                loss = loss / self.config.gradient_accumulation_steps
                loss.backward()
                accum_loss += loss.item() * self.config.gradient_accumulation_steps

                if (i + 1) % self.config.gradient_accumulation_steps == 0 or i == len(self.dataloader) - 1:
                    if self.config.max_grad_norm > 0:
                        nn.utils.clip_grad_norm_(self.model.parameters(), self.config.max_grad_norm)
                    self.optimizer.step()
                    self.optimizer.zero_grad(set_to_none=True)

                    self._global_step += 1
                    step_count += 1
                    epoch_loss += accum_loss
                    accum_loss = 0.0

                    pbar.update(1)
                    avg = epoch_loss / step_count if step_count > 0 else 0
                    pbar.set_postfix({"loss": f"{avg:.4f}"})

                    if self._global_step % self.config.logging_steps == 0 and not self.config.silent:
                        print(f"Step {self._global_step} | Loss: {avg:.4f}")

                    if self.config.max_steps > 0 and self._global_step >= self.config.max_steps:
                        print(f"\nMax steps {self.config.max_steps} reached. Stopping.")
                        pbar.close()
                        return self._build_result(start_time)

        pbar.close()
        return self._build_result(start_time)

    def _compute_loss(self, batch: Any) -> Optional[torch.Tensor]:
        """Override in subclass, or pass a model that returns loss in forward()."""
        # Default: assume batch has 'inputs' and 'targets' keys
        if isinstance(batch, dict):
            inputs = batch.get("inputs", batch.get("input_ids"))
            targets = batch.get("targets", batch.get("labels"))
            if inputs is not None and targets is not None:
                outputs = self.model(inputs)
                if isinstance(outputs, torch.Tensor):
                    return self.loss_fn(outputs, targets)
        # Fallback: model is callable with batch dict
        outputs = self.model(**batch)
        if isinstance(outputs, dict) and "loss" in outputs:
            return outputs["loss"]
        if hasattr(outputs, "loss"):
            return outputs.loss
        return None

    def _build_result(self, start_time: float) -> Dict[str, Any]:
        total_time = time.time() - start_time
        return {
            "global_step": self._global_step,
            "total_time": total_time,
            "log_history": self._log_history,
        }


# ---------------------------------------------------------------------------
# Dataset utilities (auto-expand single files)
# ---------------------------------------------------------------------------

def auto_expand_dataset(dataset: Dataset, min_size: int = 50) -> Dataset:
    """If a dataset has < min_size samples, repeat it until it reaches min_size."""
    n = len(dataset)
    if n >= min_size:
        return dataset
    repeats = math.ceil(min_size / max(n, 1))
    from torch.utils.data import ConcatDataset
    return ConcatDataset([dataset] * repeats)
