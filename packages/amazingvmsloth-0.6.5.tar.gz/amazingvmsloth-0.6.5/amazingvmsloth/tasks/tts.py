"""
Text-to-Speech (TTS) trainer using the generic PyTorch base.

Supports:
  - Any PyTorch model with nn.Linear layers (Kokoro, custom StyleTTS2, etc.)
  - Single-file datasets (auto-expanded)
  - Char-level tokenizer fallback (no HF tokenizer required)
  - Audio→mel-spectrogram preprocessing
  - MSE loss on spectrogram / CE on codec tokens
"""
import os
import json
import math
import time
from typing import Optional, Dict, Any, List, Union
from dataclasses import dataclass
from pathlib import Path

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset

from amazingvmsloth.tasks.base import (
    RawTrainer, RawTrainingConfig, CharTokenizer, apply_lora_to_module, auto_expand_dataset
)


@dataclass
class TTSConfig(RawTrainingConfig):
    """TTS-specific config."""
    sample_rate: int = 24000
    n_fft: int = 1024
    hop_length: int = 256
    n_mels: int = 80
    max_audio_len: int = 128000  # max samples (~5.3s at 24kHz)
    transcript_column: str = "text"
    audio_column: str = "audio"


class SimpleAudioDataset(Dataset):
    """Dataset of (audio_path, transcript) pairs."""

    def __init__(self, data_source: Union[str, List[Dict[str, Any]]], transcript_col: str = "text", audio_col: str = "audio"):
        self.samples = []
        if isinstance(data_source, str):
            if os.path.isfile(data_source):
                ext = Path(data_source).suffix.lower()
                if ext in ('.wav', '.mp3', '.flac', '.ogg'):
                    # Single audio file
                    transcript = Path(data_source).stem.replace("_", " ").replace("-", " ")
                    self.samples.append({audio_col: data_source, transcript_col: transcript})
                elif ext in ('.json', '.jsonl'):
                    with open(data_source, 'r', encoding='utf-8') as f:
                        if ext == '.jsonl':
                            self.samples = [json.loads(line) for line in f if line.strip()]
                        else:
                            data = json.load(f)
                            self.samples = data if isinstance(data, list) else [data]
                elif ext == '.csv':
                    import csv
                    with open(data_source, 'r', encoding='utf-8') as f:
                        self.samples = list(csv.DictReader(f))
                else:
                    raise ValueError(f"Unsupported file: {data_source}")
            elif os.path.isdir(data_source):
                # Folder of audio files
                exts = ('.wav', '.mp3', '.flac', '.ogg', '.m4a')
                files = sorted([f for f in os.listdir(data_source) if f.lower().endswith(exts)])
                # Look for metadata
                meta_path = os.path.join(data_source, "metadata.jsonl")
                if os.path.exists(meta_path):
                    with open(meta_path, 'r', encoding='utf-8') as f:
                        self.samples = [json.loads(line) for line in f if line.strip()]
                else:
                    for f in files:
                        path = os.path.join(data_source, f)
                        transcript = Path(f).stem.replace("_", " ").replace("-", " ")
                        self.samples.append({audio_col: path, transcript_col: transcript})
            else:
                raise FileNotFoundError(data_source)
        elif isinstance(data_source, list):
            self.samples = data_source
        else:
            raise TypeError(f"Unsupported data_source: {type(data_source)}")

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        return self.samples[idx]


def load_audio_to_mel(path: str, sample_rate: int = 24000, n_fft: int = 1024, hop_length: int = 256, n_mels: int = 80, max_len: int = 16000) -> torch.Tensor:
    """Load audio file to mel spectrogram (n_mels, T)."""
    try:
        import torchaudio
        waveform, sr = torchaudio.load(path)
        if sr != sample_rate:
            waveform = torchaudio.functional.resample(waveform, sr, sample_rate)
        if waveform.shape[0] > 1:
            waveform = waveform.mean(dim=0, keepdim=True)
        # Pad / truncate
        if waveform.shape[1] > max_len:
            waveform = waveform[:, :max_len]
        elif waveform.shape[1] < max_len:
            waveform = torch.nn.functional.pad(waveform, (0, max_len - waveform.shape[1]))
        # Mel spectrogram
        mel_transform = torchaudio.transforms.MelSpectrogram(
            sample_rate=sample_rate, n_fft=n_fft, hop_length=hop_length, n_mels=n_mels
        )
        mel = mel_transform(waveform).squeeze(0)  # (n_mels, T)
        # Log scale
        mel = torch.clamp(mel, min=1e-5)
        mel = torch.log(mel)
        return mel
    except Exception:
        return torch.zeros(n_mels, max_len // hop_length + 1)


def tts_collate_fn(batch: List[Dict[str, Any]], tokenizer: Any, max_text_len: int = 512, sample_rate: int = 24000, n_fft: int = 1024, hop_length: int = 256, n_mels: int = 80, max_audio_len: int = 16000) -> Dict[str, torch.Tensor]:
    """Collate TTS batch: tokenize text + load audio to mel."""
    texts = [b.get("text", b.get("transcript", "")) for b in batch]
    audio_paths = [b.get("audio", b.get("audio_path", "")) for b in batch]

    # Tokenize text
    if hasattr(tokenizer, "__call__"):
        tokens = tokenizer(texts, max_length=max_text_len, padding=True, truncation=True, return_tensors="pt")
    else:
        # Fallback char tokenizer
        tok = CharTokenizer()
        tokens = tok(texts, max_length=max_text_len, padding=True, return_tensors="pt")

    # Load audio mels
    mels = [load_audio_to_mel(p, sample_rate, n_fft, hop_length, n_mels, max_audio_len) for p in audio_paths]
    # Find max time dim
    max_t = max(m.shape[1] for m in mels)
    padded_mels = []
    masks = []
    for m in mels:
        if m.shape[1] < max_t:
            pad = max_t - m.shape[1]
            m = torch.nn.functional.pad(m, (0, pad))
        padded_mels.append(m)
        masks.append(torch.cat([torch.ones(m.shape[1] - pad if m.shape[1] < max_t else max_t), torch.zeros(pad if m.shape[1] < max_t else 0)]))

    tokens["mel_spectrogram"] = torch.stack(padded_mels)
    tokens["mel_mask"] = torch.stack([torch.cat([torch.ones(m.shape[1]), torch.zeros(max_t - m.shape[1])]) if m.shape[1] < max_t else torch.ones(max_t) for m in mels]).float()
    return tokens


class GenericTTSTrainer(RawTrainer):
    """TTS trainer using generic LoRA + mel-spectrogram MSE loss.

    Works with ANY model that takes token IDs and outputs a mel-spectrogram
    (or anything where we can compute MSE against target mels).
    """

    def __init__(self, model, train_dataset, tokenizer, config: Optional[TTSConfig] = None):
        self.tokenizer = tokenizer
        cfg = config or TTSConfig()
        collate = lambda batch: tts_collate_fn(
            batch, tokenizer,
            max_text_len=cfg.max_seq_length if hasattr(cfg, "max_seq_length") else 512,
            sample_rate=cfg.sample_rate,
            n_fft=cfg.n_fft,
            hop_length=cfg.hop_length,
            n_mels=cfg.n_mels,
            max_audio_len=cfg.max_audio_len,
        )
        super().__init__(model, train_dataset, collate_fn=collate, config=cfg)
        self.tts_config = cfg

    def _compute_loss(self, batch: Dict[str, torch.Tensor]) -> torch.Tensor:
        """Forward model and compute MSE against mel spectrogram."""
        input_ids = batch["input_ids"].to(self.device)
        attention_mask = batch.get("attention_mask")
        if attention_mask is not None:
            attention_mask = attention_mask.to(self.device)
        target_mel = batch["mel_spectrogram"].to(self.device)
        mel_mask = batch.get("mel_mask")
        if mel_mask is not None:
            mel_mask = mel_mask.to(self.device)

        # Try different forward signatures
        try:
            outputs = self.model(input_ids=input_ids, attention_mask=attention_mask, mel_spectrogram=target_mel)
        except TypeError:
            try:
                outputs = self.model(input_ids, attention_mask)
            except TypeError:
                try:
                    outputs = self.model(input_ids)
                except TypeError:
                    outputs = self.model(input_ids=input_ids)

        if isinstance(outputs, dict) and "loss" in outputs:
            return outputs["loss"]
        if hasattr(outputs, "loss") and outputs.loss is not None:
            return outputs.loss
        if isinstance(outputs, torch.Tensor):
            # Assume it's the predicted mel
            pred = outputs
        elif hasattr(outputs, "mel"):
            pred = outputs.mel
        elif hasattr(outputs, "spectrogram"):
            pred = outputs.spectrogram
        else:
            # Try last element
            pred = outputs[-1] if isinstance(outputs, (list, tuple)) else outputs

        # Align shapes if needed (e.g. TinyTransformerTTS outputs fixed max_mel_len)
        if pred.dim() == 3 and target_mel.dim() == 3 and pred.shape[-1] != target_mel.shape[-1]:
            pred = F.interpolate(pred, size=target_mel.shape[-1], mode="linear", align_corners=False)

        # MSE on mel spectrogram
        loss = F.mse_loss(pred, target_mel)
        if mel_mask is not None:
            loss = (loss * mel_mask.unsqueeze(1)).sum() / mel_mask.sum().clamp(min=1)
        return loss


# ---------------------------------------------------------------------------
# Tiny Transformer TTS (fallback when no HF model is available)
# ---------------------------------------------------------------------------

class TinyTransformerTTS(nn.Module):
    """Small transformer TTS model: text tokens → mel spectrogram.

    Works with char-level tokenization, produces mel-spectrogram frames.
    Overfits well to single-voice datasets.
    """

    def __init__(self, vocab_size: int = 256, d_model: int = 512, n_layers: int = 6, n_mels: int = 80, max_mel_len: int = 2048):
        super().__init__()
        self.vocab_size = vocab_size
        self.d_model = d_model
        self.n_mels = n_mels
        self.max_mel_len = max_mel_len
        self.embedding = nn.Embedding(vocab_size, d_model)
        self.pos_emb = nn.Parameter(torch.zeros(1, 512, d_model))
        encoder_layer = nn.TransformerEncoderLayer(d_model=d_model, nhead=8, dim_feedforward=d_model * 4, dropout=0.1, batch_first=True)
        self.encoder = nn.TransformerEncoder(encoder_layer, num_layers=n_layers)
        self.mel_proj = nn.Linear(d_model, n_mels)
        self.time_proj = nn.Linear(d_model, n_mels)

    def forward(self, input_ids: torch.Tensor, attention_mask: Optional[torch.Tensor] = None, mel_spectrogram: Optional[torch.Tensor] = None, **kwargs) -> torch.Tensor:
        bsz, seq_len = input_ids.shape
        x = self.embedding(input_ids)
        if seq_len <= self.pos_emb.shape[1]:
            x = x + self.pos_emb[:, :seq_len, :]
        else:
            x = x + F.interpolate(self.pos_emb.permute(0, 2, 1), size=seq_len, mode="linear").permute(0, 2, 1)
        if attention_mask is not None:
            # Convert padding mask to key_padding_mask (True = pad)
            key_mask = (attention_mask == 0)
        else:
            key_mask = None
        x = self.encoder(x, src_key_padding_mask=key_mask)
        # Pool to mel frames (average pooling across sequence -> upsample to mel length)
        pooled = x.mean(dim=1)  # (B, d_model)
        # Predict mel frames autoregressively or directly
        mel = self.mel_proj(x).permute(0, 2, 1)  # (B, n_mels, seq_len)
        if mel.shape[2] < self.max_mel_len:
            mel = F.interpolate(mel, size=self.max_mel_len, mode="linear")
        elif mel.shape[2] > self.max_mel_len:
            mel = mel[:, :, :self.max_mel_len]
        return mel


# ---------------------------------------------------------------------------
# REAL TTS: VITS-based end-to-end text-to-waveform trainer
# ---------------------------------------------------------------------------

def load_audio_16k(path: str, max_samples: int = 320000) -> torch.Tensor:
    """Load audio file, resample to 16kHz, return mono waveform (T,)."""
    try:
        import torchaudio
        # Try soundfile backend first (avoids torchcodec issues)
        try:
            torchaudio.set_audio_backend("soundfile")
        except Exception:
            pass
        waveform, sr = torchaudio.load(path)
        if waveform.shape[0] > 1:
            waveform = waveform.mean(dim=0, keepdim=True)
        if sr != 16000:
            waveform = torchaudio.functional.resample(waveform, sr, 16000)
        waveform = waveform.squeeze(0)
        if waveform.shape[0] > max_samples:
            waveform = waveform[:max_samples]
        elif waveform.shape[0] < max_samples:
            waveform = torch.nn.functional.pad(waveform, (0, max_samples - waveform.shape[0]))
        return waveform
    except Exception as e:
        # Fallback: try standard wave module for WAV files
        if path.lower().endswith('.wav'):
            try:
                import wave
                import struct
                import numpy as np
                with wave.open(path, 'rb') as wf:
                    nchannels = wf.getnchannels()
                    sampwidth = wf.getsampwidth()
                    sr = wf.getframerate()
                    nframes = wf.getnframes()
                    raw = wf.readframes(nframes)
                    if sampwidth == 2:
                        data = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
                    elif sampwidth == 4:
                        data = np.frombuffer(raw, dtype=np.int32).astype(np.float32) / 2147483648.0
                    else:
                        data = np.frombuffer(raw, dtype=np.uint8).astype(np.float32) / 128.0 - 1.0
                    if nchannels > 1:
                        data = data.reshape(-1, nchannels).mean(axis=1)
                    waveform = torch.from_numpy(data)
                    if sr != 16000:
                        # Simple linear interpolation resampling
                        old_len = waveform.shape[0]
                        new_len = int(old_len * 16000 / sr)
                        waveform = torch.nn.functional.interpolate(
                            waveform.unsqueeze(0).unsqueeze(0), size=new_len, mode='linear', align_corners=False
                        ).squeeze()
                    if waveform.shape[0] > max_samples:
                        waveform = waveform[:max_samples]
                    elif waveform.shape[0] < max_samples:
                        waveform = torch.nn.functional.pad(waveform, (0, max_samples - waveform.shape[0]))
                    return waveform
            except Exception as e2:
                print(f"[warning] Wave fallback failed for '{path}': {e2}")
        print(f"[warning] Failed to load audio '{path}': {e}")
        return torch.zeros(max_samples)


class VITSAudioDataset(Dataset):
    """Dataset for VITS training: (audio_path, transcript) pairs.

    Audio is CACHED in RAM to avoid disk I/O every epoch.
    """

    def __init__(self, data_source: Union[str, List[Dict[str, Any]]], transcript_col: str = "text", audio_col: str = "audio", max_samples: int = 160000, cache: bool = True):
        self.samples = []
        self.max_samples = max_samples
        self._cache: Dict[int, torch.Tensor] = {}  # idx -> waveform tensor
        self._cache_audio = cache

        if isinstance(data_source, str):
            if os.path.isfile(data_source):
                ext = Path(data_source).suffix.lower()
                if ext in ('.wav', '.mp3', '.flac', '.ogg'):
                    transcript = Path(data_source).stem.replace("_", " ").replace("-", " ")
                    self.samples.append({audio_col: data_source, transcript_col: transcript})
                elif ext in ('.json', '.jsonl'):
                    with open(data_source, 'r', encoding='utf-8') as f:
                        if ext == '.jsonl':
                            self.samples = [json.loads(line) for line in f if line.strip()]
                        else:
                            data = json.load(f)
                            self.samples = data if isinstance(data, list) else [data]
                elif ext == '.csv':
                    import csv
                    with open(data_source, 'r', encoding='utf-8') as f:
                        self.samples = list(csv.DictReader(f))
                else:
                    raise ValueError(f"Unsupported file: {data_source}")
            elif os.path.isdir(data_source):
                exts = ('.wav', '.mp3', '.flac', '.ogg', '.m4a')
                files = sorted([f for f in os.listdir(data_source) if f.lower().endswith(exts)])
                meta_path = os.path.join(data_source, "metadata.jsonl")
                if os.path.exists(meta_path):
                    with open(meta_path, 'r', encoding='utf-8') as f:
                        self.samples = [json.loads(line) for line in f if line.strip()]
                else:
                    for f in files:
                        path = os.path.join(data_source, f)
                        transcript = Path(f).stem.replace("_", " ").replace("-", " ")
                        self.samples.append({audio_col: path, transcript_col: transcript})
            else:
                raise FileNotFoundError(data_source)
        elif isinstance(data_source, list):
            self.samples = data_source
        else:
            raise TypeError(f"Unsupported data_source: {type(data_source)}")

        # Pre-load all audio into RAM
        if self._cache_audio:
            print(f"[VITSAudioDataset] Caching {len(self.samples)} audio files to RAM (max {max_samples} samples each)...")
            import time
            t0 = time.time()
            for idx in range(len(self.samples)):
                path = self.samples[idx].get(audio_col, self.samples[idx].get("audio_path", ""))
                try:
                    self._cache[idx] = load_audio_16k(path, max_samples=self.max_samples)
                except Exception as e:
                    print(f"  [warning] Failed to cache '{path}': {e}, using silence")
                    self._cache[idx] = torch.zeros(self.max_samples)
            print(f"[VITSAudioDataset] Cached in {time.time()-t0:.1f}s")

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        if self._cache_audio and idx in self._cache:
            return {"audio": self._cache[idx], "text": self.samples[idx].get("text", self.samples[idx].get("transcript", ""))}
        return self.samples[idx]


def vits_collate_fn(batch: List[Dict[str, Any]], tokenizer: Any, max_text_len: int = 512, max_samples: int = 160000) -> Dict[str, torch.Tensor]:
    """Collate VITS batch: tokenize text + stack audio waveforms (cached or load)."""
    texts = [b.get("text", b.get("transcript", "")) for b in batch]

    # Tokenize text
    if hasattr(tokenizer, "__call__"):
        tokens = tokenizer(texts, max_length=max_text_len, padding=True, truncation=True, return_tensors="pt")
    else:
        tok = CharTokenizer()
        tokens = tok(texts, max_length=max_text_len, padding=True, return_tensors="pt")

    # Audio: if cached, use tensor directly; otherwise load from path
    waveforms = []
    for b in batch:
        if isinstance(b.get("audio"), torch.Tensor):
            waveforms.append(b["audio"])
        else:
            path = b.get("audio", b.get("audio_path", ""))
            waveforms.append(load_audio_16k(path, max_samples=max_samples))

    max_len = max(w.shape[0] for w in waveforms)
    padded = torch.stack([torch.nn.functional.pad(w, (0, max_len - w.shape[0])) for w in waveforms])
    lengths = torch.tensor([w.shape[0] for w in waveforms], dtype=torch.long)

    tokens["waveform"] = padded
    tokens["waveform_lengths"] = lengths
    return tokens


class VITSTrainer(RawTrainer):
    """REAL TTS trainer using Facebook MMS VITS.

    End-to-end text → waveform. No mel-spectrogram, no Griffin-Lim.
    Fine-tunes a pre-trained VITS model with naive waveform MSE loss.
    """

    def __init__(self, model, tokenizer, train_dataset, config: Optional[TTSConfig] = None, max_audio_seconds: float = 10.0):
        self.tokenizer = tokenizer
        cfg = config or TTSConfig()
        # VITS uses 16kHz
        max_samples = int(max_audio_seconds * 16000)
        collate = lambda batch: vits_collate_fn(
            batch, tokenizer,
            max_text_len=cfg.max_seq_length if hasattr(cfg, "max_seq_length") else 512,
            max_samples=max_samples,
        )
        super().__init__(model, train_dataset, collate_fn=collate, config=cfg)
        self.tts_config = cfg

    def _compute_loss(self, batch: Dict[str, torch.Tensor]) -> torch.Tensor:
        """Forward VITS and compute MSE on waveform."""
        input_ids = batch["input_ids"].to(self.device)
        attention_mask = batch.get("attention_mask")
        if attention_mask is not None:
            attention_mask = attention_mask.to(self.device)
        target_waveform = batch["waveform"].to(self.device)  # (B, T)
        waveform_lengths = batch["waveform_lengths"].to(self.device)

        # VITS forward
        with torch.amp.autocast(device_type='cuda' if torch.cuda.is_available() else 'cpu', enabled=self.config.bf16 and torch.cuda.is_available()):
            outputs = self.model(input_ids=input_ids, attention_mask=attention_mask)

        pred_waveform = outputs.waveform  # (B, T_pred) - may be bfloat16

        # Align lengths: truncate/pad to min of pred and target
        min_len = min(pred_waveform.shape[-1], target_waveform.shape[-1])
        pred_waveform = pred_waveform[:, :min_len]
        target_waveform = target_waveform[:, :min_len].to(pred_waveform.dtype)

        # Create mask from waveform_lengths
        mask = torch.arange(min_len, device=self.device).unsqueeze(0) < waveform_lengths.unsqueeze(1)
        mask = mask.to(pred_waveform.dtype)

        loss = F.mse_loss(pred_waveform, target_waveform, reduction='none')
        loss = (loss * mask).sum() / mask.sum().clamp(min=1)
        return loss


__all__ = ["GenericTTSTrainer", "VITSTrainer", "TTSConfig", "SimpleAudioDataset", "VITSAudioDataset", "tts_collate_fn", "vits_collate_fn", "load_audio_to_mel", "load_audio_16k", "TinyTransformerTTS"]
