"""Task-specific trainers for generative models.

Tasks:
  - text-generation: standard LLM fine-tuning (existing AmazingTrainer)
  - text-to-speech: TTS model fine-tuning (Qwen3-TTS, Bark, etc.)
  - text-to-image: diffusion model LoRA (Stable Diffusion, Flux, etc.)
  - text-to-video: video diffusion LoRA (CogVideo, SVD, etc.)
  - image-to-image: image editing/editing diffusion
  - audio-to-audio: audio style transfer, voice conversion
"""

from typing import Dict, Type, Any

# Registry of task trainers
_TASK_REGISTRY: Dict[str, Type] = {}


def register_task(name: str, trainer_cls: Type):
    """Register a task trainer."""
    _TASK_REGISTRY[name] = trainer_cls


def get_task_trainer(name: str) -> Type:
    """Get a task trainer by name."""
    if name not in _TASK_REGISTRY:
        raise ValueError(f"Unknown task: {name}. Registered tasks: {list(_TASK_REGISTRY.keys())}")
    return _TASK_REGISTRY[name]


def list_tasks() -> list:
    """List all registered tasks."""
    return list(_TASK_REGISTRY.keys())


# Lazy imports to avoid heavy dependencies at import time
def _import_tts_trainer():
    from amazingvmsloth.tasks.tts import TTSTrainer
    return TTSTrainer


def _import_diffusion_trainer():
    from amazingvmsloth.tasks.diffusion import DiffusionLoRATrainer
    return DiffusionLoRATrainer


def _import_video_diffusion_trainer():
    from amazingvmsloth.tasks.diffusion import VideoDiffusionLoRATrainer
    return VideoDiffusionLoRATrainer


# Register tasks
_TASK_REGISTRY["text-generation"] = None  # Uses existing AmazingTrainer
_TASK_REGISTRY["text-to-speech"] = _import_tts_trainer
_TASK_REGISTRY["tts"] = _import_tts_trainer
_TASK_REGISTRY["text-to-image"] = _import_diffusion_trainer
_TASK_REGISTRY["image-generation"] = _import_diffusion_trainer
_TASK_REGISTRY["text-to-video"] = _import_video_diffusion_trainer
_TASK_REGISTRY["video-generation"] = _import_video_diffusion_trainer


__all__ = ["get_task_trainer", "list_tasks", "register_task"]
