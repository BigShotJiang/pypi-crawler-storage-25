import torch
import torch.nn as nn
from typing import Optional, Type
from transformers import PreTrainedModel
from amazingvmsloth.lora import apply_lora, LoRAConfig
from amazingvmsloth.attention import patch_attention


class BaseModelPatcher:
    def __init__(self, model: PreTrainedModel):
        self.model = model

    def patch(self) -> PreTrainedModel:
        raise NotImplementedError

    def get_lora_config(self) -> LoRAConfig:
        return LoRAConfig()

    def get_target_modules(self) -> list:
        raise NotImplementedError


class LlamaPatcher(BaseModelPatcher):
    def patch(self) -> PreTrainedModel:
        self.model = patch_attention(self.model)
        return self.model

    def get_lora_config(self) -> LoRAConfig:
        return LoRAConfig(
            r=16,
            lora_alpha=16,
            target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
            use_rslora=True,
            use_manual_gradients=False,
        )

    def get_target_modules(self) -> list:
        return ["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"]


class MistralPatcher(BaseModelPatcher):
    def patch(self) -> PreTrainedModel:
        self.model = patch_attention(self.model)
        return self.model

    def get_lora_config(self) -> LoRAConfig:
        return LoRAConfig(
            r=16,
            lora_alpha=16,
            target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
            use_rslora=True,
        )

    def get_target_modules(self) -> list:
        return ["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"]


class Qwen2Patcher(BaseModelPatcher):
    def patch(self) -> PreTrainedModel:
        self.model = patch_attention(self.model)
        return self.model

    def get_lora_config(self) -> LoRAConfig:
        return LoRAConfig(
            r=16,
            lora_alpha=16,
            target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
            use_rslora=True,
        )

    def get_target_modules(self) -> list:
        return ["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"]


class VisionLanguagePatcher(BaseModelPatcher):
    """Patcher for vision-language models (LLaVA, Qwen-VL, BLIP-2, etc.).

    Freezes vision encoder, applies LoRA to LLM + projection layers.
    """
    def patch(self) -> PreTrainedModel:
        from amazingvmsloth.multimodal import patch_multimodal_model
        self.model = patch_attention(self.model)
        self.model = patch_multimodal_model(self.model, modality="vision")
        return self.model

    def get_lora_config(self) -> LoRAConfig:
        return LoRAConfig(
            r=16,
            lora_alpha=16,
            target_modules=[
                "q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj",
                "mm_projector", "vision_projector", "image_projection", "visual_projection",
                "multi_modal_projector", "merger", "vision_merger",
            ],
            use_rslora=True,
        )

    def get_target_modules(self) -> list:
        return [
            "q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj",
            "mm_projector", "vision_projector", "image_projection", "visual_projection",
            "multi_modal_projector", "merger", "vision_merger",
        ]


class AudioLanguagePatcher(BaseModelPatcher):
    """Patcher for audio-language models (Whisper, Qwen-Audio, etc.).

    Freezes audio encoder, applies LoRA to decoder / LLM.
    """
    def patch(self) -> PreTrainedModel:
        from amazingvmsloth.multimodal import patch_multimodal_model
        self.model = patch_attention(self.model)
        self.model = patch_multimodal_model(self.model, modality="audio")
        return self.model

    def get_lora_config(self) -> LoRAConfig:
        return LoRAConfig(
            r=16,
            lora_alpha=16,
            target_modules=[
                "q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj",
                "audio_projection", "encoder_projection", "proj_out",
            ],
            use_rslora=True,
        )

    def get_target_modules(self) -> list:
        return [
            "q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj",
            "audio_projection", "encoder_projection", "proj_out",
        ]


class VideoLanguagePatcher(BaseModelPatcher):
    """Patcher for video-language models (Video-LLaMA, VideoChatGPT, etc.)."""
    def patch(self) -> PreTrainedModel:
        from amazingvmsloth.multimodal import patch_multimodal_model
        self.model = patch_attention(self.model)
        self.model = patch_multimodal_model(self.model, modality="video")
        return self.model

    def get_lora_config(self) -> LoRAConfig:
        return LoRAConfig(
            r=16,
            lora_alpha=16,
            target_modules=[
                "q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj",
                "mm_projector", "video_projector", "temporal_projection", "vision_projector",
            ],
            use_rslora=True,
        )

    def get_target_modules(self) -> list:
        return [
            "q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj",
            "mm_projector", "video_projector", "temporal_projection", "vision_projector",
        ]


class _FastRMSNorm(nn.Module):
    def __init__(self, original_norm):
        super().__init__()
        # Copy weight to avoid shared-tensor issues on save_pretrained
        self.weight = nn.Parameter(original_norm.weight.data.clone(), requires_grad=original_norm.weight.requires_grad)
        self.variance_epsilon = getattr(original_norm, "eps", 1e-6)

    def forward(self, hidden_states):
        input_dtype = hidden_states.dtype
        hidden_states = hidden_states.to(torch.float32)
        variance = hidden_states.pow(2).mean(-1, keepdim=True)
        hidden_states = hidden_states * torch.rsqrt(variance + self.variance_epsilon)
        return (self.weight * hidden_states).to(input_dtype)


_MODEL_REGISTRY = {
    "llama": LlamaPatcher,
    "mistral": MistralPatcher,
    "qwen2": Qwen2Patcher,
    "qwen": Qwen2Patcher,
    "qwen3": Qwen2Patcher,
    "qwen3_5": Qwen2Patcher,
    # Multimodal models
    "llava": VisionLanguagePatcher,
    "llava_next": VisionLanguagePatcher,
    "paligemma": VisionLanguagePatcher,
    "qwen2_vl": VisionLanguagePatcher,
    "qwen_vl": VisionLanguagePatcher,
    "blip_2": VisionLanguagePatcher,
    "fuyu": VisionLanguagePatcher,
    "whisper": AudioLanguagePatcher,
    "video_llama": VideoLanguagePatcher,
    "video_chatgpt": VideoLanguagePatcher,
    # TTS models
    "qwen3_tts": AudioLanguagePatcher,
    "bark": AudioLanguagePatcher,
    "parler_tts": AudioLanguagePatcher,
    "xtts": AudioLanguagePatcher,
}


def auto_patch_model(
    model: PreTrainedModel,
    apply_lora_patch: bool = True,
    lora_config: Optional[LoRAConfig] = None,
    lora_r: int = 16,
    lora_alpha: int = 16,
    modality: str = "text",
) -> PreTrainedModel:
    model_type = _detect_model_type(model)
    patcher_cls = _MODEL_REGISTRY.get(model_type)

    # If model type not in registry but modality is multimodal, try to infer patcher
    if patcher_cls is None and modality != "text":
        if modality in ("vision", "image"):
            patcher_cls = VisionLanguagePatcher
        elif modality in ("audio", "sound"):
            patcher_cls = AudioLanguagePatcher
        elif modality in ("video", "clip"):
            patcher_cls = VideoLanguagePatcher

    if patcher_cls is None:
        print(f"[amazingvmsloth] No specific patcher for model type '{model_type}', using generic patches")
        model = patch_attention(model)
        if apply_lora_patch:
            config = lora_config or LoRAConfig(r=lora_r, lora_alpha=lora_alpha)
            model = apply_lora(model, config=config)
        return model

    patcher = patcher_cls(model)
    model = patcher.patch()

    if apply_lora_patch:
        config = lora_config or patcher.get_lora_config()
        if config.r != lora_r:
            config.r = lora_r
        if config.lora_alpha != lora_alpha:
            config.lora_alpha = lora_alpha
        model = apply_lora(model, config=config)

    print(f"[amazingvmsloth] Model patched and LoRA applied (type={model_type}, modality={modality})")
    return model


def _detect_model_type(model: PreTrainedModel) -> str:
    config = getattr(model, "config", None)
    if config is not None:
        model_type = getattr(config, "model_type", "").lower()
        if model_type in _MODEL_REGISTRY:
            return model_type

    class_name = type(model).__name__.lower()
    for key in _MODEL_REGISTRY:
        if key in class_name:
            return key

    for name, module in model.named_modules():
        module_type = type(module).__name__.lower()
        for key in _MODEL_REGISTRY:
            if key in module_type:
                return key

    return ""
