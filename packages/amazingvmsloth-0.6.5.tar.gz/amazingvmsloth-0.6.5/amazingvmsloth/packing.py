import torch
from typing import List, Dict, Any, Optional, Iterable
from dataclasses import dataclass


class PackingCollator:
    def __init__(self, max_seq_length: int = 2048, pad_token_id: int = 0, eos_token_id: int = 0):
        self.max_seq_length = max_seq_length
        self.pad_token_id = pad_token_id
        self.eos_token_id = eos_token_id

    def __call__(self, features: List[Dict[str, Any]]) -> Dict[str, torch.Tensor]:
        all_ids = []
        seq_lengths = []

        for f in features:
            ids = f["input_ids"]
            if isinstance(ids, torch.Tensor):
                ids = ids.tolist()
            if isinstance(ids, list) and isinstance(ids[0], list):
                ids = ids[0]
            if ids:
                all_ids.extend(ids + [self.eos_token_id])
                seq_lengths.append(len(ids) + 1)

        return self._pack(all_ids, seq_lengths)

    def _pack(self, all_token_ids: List[int], seq_lengths: List[int]) -> Dict[str, torch.Tensor]:
        chunks_input_ids = []
        chunks_attention_mask = []
        chunks_labels = []
        chunks_position_ids = []

        offset = 0
        seq_idx = 0
        consumed = 0

        while offset < len(all_token_ids):
            chunk_ids = []
            chunk_labels = []
            chunk_attn = []
            chunk_pos = []
            pos_counter = 0

            while offset < len(all_token_ids) and len(chunk_ids) < self.max_seq_length:
                remaining_in_seq = seq_lengths[seq_idx] - consumed

                if remaining_in_seq <= 0:
                    seq_idx += 1
                    consumed = 0
                    if seq_idx >= len(seq_lengths):
                        break
                    continue

                space_left = self.max_seq_length - len(chunk_ids)
                take = min(remaining_in_seq, space_left)

                for i in range(take):
                    global_pos = offset + i
                    chunk_ids.append(all_token_ids[global_pos])
                    chunk_attn.append(1)

                    if consumed + i == 0 and len(chunk_ids) > 1:
                        chunk_labels.append(-100)
                        pos_counter = 0
                    else:
                        chunk_labels.append(all_token_ids[global_pos])

                    chunk_pos.append(pos_counter)
                    pos_counter += 1

                offset += take
                consumed += take

                if consumed >= seq_lengths[seq_idx]:
                    seq_idx += 1
                    consumed = 0
                    pos_counter = 0
                    if seq_idx >= len(seq_lengths):
                        break

            pad_len = self.max_seq_length - len(chunk_ids)
            if pad_len > 0:
                chunk_ids.extend([self.pad_token_id] * pad_len)
                chunk_attn.extend([0] * pad_len)
                chunk_labels.extend([-100] * pad_len)
                chunk_pos.extend([0] * pad_len)

            chunks_input_ids.append(chunk_ids)
            chunks_attention_mask.append(chunk_attn)
            chunks_labels.append(chunk_labels)
            chunks_position_ids.append(chunk_pos)

        if not chunks_input_ids:
            chunks_input_ids = [[self.pad_token_id] * self.max_seq_length]
            chunks_attention_mask = [[0] * self.max_seq_length]
            chunks_labels = [[-100] * self.max_seq_length]
            chunks_position_ids = [[0] * self.max_seq_length]

        return {
            "input_ids": torch.tensor(chunks_input_ids, dtype=torch.long),
            "attention_mask": torch.tensor(chunks_attention_mask, dtype=torch.float32),
            "labels": torch.tensor(chunks_labels, dtype=torch.long),
            "position_ids": torch.tensor(chunks_position_ids, dtype=torch.long),
        }


class SmartCollator:
    def __init__(self, max_seq_length: int = 2048, pad_token_id: int = 0):
        self.max_seq_length = max_seq_length
        self.pad_token_id = pad_token_id

    def __call__(self, features: List[Dict[str, Any]]) -> Dict[str, torch.Tensor]:
        batch_ids = []
        for f in features:
            ids = f["input_ids"]
            if isinstance(ids, torch.Tensor):
                ids = ids.tolist()
            if isinstance(ids, list) and ids and isinstance(ids[0], list):
                ids = ids[0]
            batch_ids.append(ids[:self.max_seq_length])

        max_len = max(len(ids) for ids in batch_ids)

        input_ids = []
        attention_mask = []
        labels = []

        for ids in batch_ids:
            pad_len = max_len - len(ids)
            input_ids.append(ids + [self.pad_token_id] * pad_len)
            attention_mask.append([1] * len(ids) + [0] * pad_len)
            labels.append(ids + [-100] * pad_len)

        return {
            "input_ids": torch.tensor(input_ids, dtype=torch.long),
            "attention_mask": torch.tensor(attention_mask, dtype=torch.float32),
            "labels": torch.tensor(labels, dtype=torch.long),
        }


class BatchCollator:
    """Stacks pre-packed tensor dicts into a batch. Assumes all samples are already padded."""
    def __call__(self, features: List[Dict[str, Any]]) -> Dict[str, torch.Tensor]:
        batch = {}
        for key in features[0].keys():
            values = [f[key] for f in features]
            if isinstance(values[0], torch.Tensor):
                batch[key] = torch.stack(values)
            else:
                batch[key] = values
        return batch


def prepack_dataset(dataset, tokenizer, max_seq_length: int = 2048):
    """
    Pre-pack tokenized sequences into fixed-length chunks.
    
    Concatenates all input_ids with EOS, splits into chunks of max_seq_length.
    Returns a list of dicts with tensor values ready for DataLoader + BatchCollator.
    """
    eos_token_id = getattr(tokenizer, "eos_token_id", 0) or 0
    pad_token_id = getattr(tokenizer, "pad_token_id", 0) or 0
    
    all_ids = []
    for example in dataset:
        ids = example["input_ids"]
        if isinstance(ids, torch.Tensor):
            ids = ids.tolist()
        if isinstance(ids, list) and ids and isinstance(ids[0], list):
            ids = ids[0]
        if ids:
            all_ids.extend(ids)
            all_ids.append(eos_token_id)
    
    # Remove trailing EOS to avoid empty padding at the end
    if all_ids and all_ids[-1] == eos_token_id:
        all_ids = all_ids[:-1]
    
    if not all_ids:
        return [{
            "input_ids": torch.zeros(max_seq_length, dtype=torch.long),
            "attention_mask": torch.zeros(max_seq_length, dtype=torch.float32),
            "labels": torch.full((max_seq_length,), -100, dtype=torch.long),
            "position_ids": torch.zeros(max_seq_length, dtype=torch.long),
        }]
    
    chunks = []
    for start in range(0, len(all_ids), max_seq_length):
        chunk_ids = all_ids[start:start + max_seq_length]
        actual_len = len(chunk_ids)
        pad_len = max_seq_length - actual_len
        
        input_ids = chunk_ids + [pad_token_id] * pad_len
        attention_mask = [1] * actual_len + [0] * pad_len
        labels = chunk_ids + [-100] * pad_len
        position_ids = list(range(actual_len)) + [0] * pad_len
        
        chunks.append({
            "input_ids": torch.tensor(input_ids, dtype=torch.long),
            "attention_mask": torch.tensor(attention_mask, dtype=torch.float32),
            "labels": torch.tensor(labels, dtype=torch.long),
            "position_ids": torch.tensor(position_ids, dtype=torch.long),
        })
    
    return chunks
