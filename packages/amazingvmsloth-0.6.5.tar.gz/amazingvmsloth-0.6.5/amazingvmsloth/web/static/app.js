/**
 * amazingvmsloth Web Dashboard Frontend
 * Real-time training monitoring via Server-Sent Events
 */

const presets = {
  fast: { model: "Qwen/Qwen2.5-0.5B", dataset: "tatsu-lab/alpaca", max_steps: 500, batch_size: 2, grad_accum: 4, lora_r: 16, lora_alpha: 32, lr: 0.0002, max_seq_length: 512, quant: "none", format: "auto", optimizer: "adamw", output_dir: "./output_fast", cpu: false, modality: "text", image_size: 336, num_video_frames: 8 },
  vram: { model: "Qwen/Qwen2.5-0.5B", dataset: "tatsu-lab/alpaca", max_steps: 500, batch_size: 1, grad_accum: 8, lora_r: 8, lora_alpha: 16, lr: 0.0002, max_seq_length: 256, quant: "4bit", format: "auto", optimizer: "paged_adamw_8bit", output_dir: "./output_vram", cpu: false, modality: "text", image_size: 336, num_video_frames: 8 },
  distill: { model: "Qwen/Qwen2.5-0.5B", dataset: "Roman1111111/claude-opus-4.6-10000x", max_steps: 1000, batch_size: 2, grad_accum: 4, lora_r: 16, lora_alpha: 32, lr: 0.0002, max_seq_length: 512, quant: "none", format: "chat", optimizer: "adamw", output_dir: "./output_distill", cpu: false, modality: "text", image_size: 336, num_video_frames: 8 },
  code: { model: "Qwen/Qwen2.5-0.5B", dataset: "Modotte/CodeX-2M-Thinking", max_steps: 500, batch_size: 2, grad_accum: 4, lora_r: 16, lora_alpha: 32, lr: 0.0002, max_seq_length: 512, quant: "none", format: "chat", optimizer: "adamw", output_dir: "./output_code", cpu: false, modality: "text", image_size: 336, num_video_frames: 8 },
  vision: { model: "llava-hf/llava-1.5-7b-hf", dataset: "liuhaotian/LLaVA-Instruct-150K", max_steps: 500, batch_size: 1, grad_accum: 4, lora_r: 16, lora_alpha: 32, lr: 0.0002, max_seq_length: 512, quant: "4bit", format: "vision", optimizer: "adamw", output_dir: "./output_vision", cpu: false, modality: "vision", image_size: 336, num_video_frames: 8, task: "text-generation" },
  audio: { model: "openai/whisper-base", dataset: "mozilla-foundation/common_voice_11_0", max_steps: 500, batch_size: 1, grad_accum: 4, lora_r: 16, lora_alpha: 32, lr: 0.0002, max_seq_length: 448, quant: "none", format: "audio", optimizer: "adamw", output_dir: "./output_audio", cpu: false, modality: "audio", image_size: 336, num_video_frames: 8, task: "text-generation" },
  tts: { model: "Qwen/Qwen3-TTS-12Hz-0.6B-Base", dataset: "./my_voice_samples", max_steps: 1000, batch_size: 1, grad_accum: 4, lora_r: 16, lora_alpha: 32, lr: 2e-4, max_seq_length: 512, quant: "none", format: "audio", optimizer: "adamw", output_dir: "./output_tts", cpu: false, modality: "audio", image_size: 336, num_video_frames: 8, task: "text-to-speech" },
  sd_lora: { model: "runwayml/stable-diffusion-v1-5", dataset: "./my_images", max_steps: 1000, batch_size: 1, grad_accum: 4, lora_r: 16, lora_alpha: 32, lr: 1e-4, max_seq_length: 77, quant: "none", format: "auto", optimizer: "adamw", output_dir: "./output_sd_lora", cpu: false, modality: "text", image_size: 512, num_video_frames: 8, task: "text-to-image" },
};

let sse = null;
let chart = null;
let history = [];

function applyPreset(name) {
  const p = presets[name];
  if (!p) return;
  document.getElementById("model").value = p.model;
  document.getElementById("dataset").value = p.dataset;
  document.getElementById("max_steps").value = p.max_steps;
  document.getElementById("batch_size").value = p.batch_size;
  document.getElementById("grad_accum").value = p.grad_accum;
  document.getElementById("lora_r").value = p.lora_r;
  document.getElementById("lora_alpha").value = p.lora_alpha;
  document.getElementById("lr").value = p.lr;
  document.getElementById("max_seq_length").value = p.max_seq_length;
  document.getElementById("quant").value = p.quant;
  document.getElementById("dataset_format").value = p.format;
  document.getElementById("optimizer").value = p.optimizer;
  document.getElementById("output_dir").value = p.output_dir;
  document.getElementById("cpu").checked = !!p.cpu;
  document.getElementById("modality").value = p.modality || "text";
  document.getElementById("image_size").value = p.image_size || 336;
  document.getElementById("num_video_frames").value = p.num_video_frames || 8;
  document.getElementById("task").value = p.task || "text-generation";
  logLine(`[web] Loaded preset: ${name}`, "info");
}

function getFormData() {
  return {
    model: document.getElementById("model").value,
    dataset: document.getElementById("dataset").value,
    max_steps: parseInt(document.getElementById("max_steps").value),
    batch_size: parseInt(document.getElementById("batch_size").value),
    grad_accum: parseInt(document.getElementById("grad_accum").value),
    lora_r: parseInt(document.getElementById("lora_r").value),
    lora_alpha: parseInt(document.getElementById("lora_alpha").value),
    lr: parseFloat(document.getElementById("lr").value),
    max_seq_length: parseInt(document.getElementById("max_seq_length").value),
    quant: document.getElementById("quant").value,
    dataset_format: document.getElementById("dataset_format").value,
    optimizer: document.getElementById("optimizer").value,
    output_dir: document.getElementById("output_dir").value,
    modality: document.getElementById("modality").value,
    task: document.getElementById("task").value,
    image_size: parseInt(document.getElementById("image_size").value) || 336,
    num_video_frames: parseInt(document.getElementById("num_video_frames").value) || 8,
    bf16: true,
    cpu: document.getElementById("cpu").checked,
  };
}

async function startTraining() {
  const btn = document.getElementById("startBtn");
  btn.disabled = true;
  document.getElementById("stopBtn").disabled = false;
  clearLogs();
  history = [];
  updateChart();
  setStatus("starting", "Starting training...");

  try {
    const resp = await fetch("/api/start", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(getFormData()),
    });
    if (!resp.ok) {
      const err = await resp.json();
      logLine(`[web] Failed to start: ${err.error || resp.statusText}`, "err");
      setStatus("error", err.error || "Failed");
      btn.disabled = false;
      return;
    }
    logLine("[web] Training job started! Connecting to log stream...", "info");
    connectSSE();
  } catch (e) {
    logLine(`[web] Network error: ${e.message}`, "err");
    setStatus("error", e.message);
    btn.disabled = false;
  }
}

async function stopTraining() {
  try {
    const resp = await fetch("/api/stop", { method: "POST" });
    const data = await resp.json();
    logLine(`[web] Stop requested: ${data.status}`, "warn");
    setStatus("stopping", "Stopping...");
  } catch (e) {
    logLine(`[web] Stop error: ${e.message}`, "err");
  }
}

function connectSSE() {
  if (sse) sse.close();
  sse = new EventSource("/api/logs");
  sse.onmessage = (ev) => {
    try {
      const data = JSON.parse(ev.data);
      const line = data.line || "";
      const status = data.status || {};
      if (line) {
        parseAndLog(line);
      }
      updateMetrics(status);
    } catch (e) {
      // ignore parse errors
    }
  };
  sse.onerror = () => {
    // Will auto-reconnect or end when training stops
    if (sse) sse.close();
    document.getElementById("startBtn").disabled = false;
    document.getElementById("stopBtn").disabled = true;
  };
}

function parseAndLog(line) {
  let cls = "";
  if (line.includes("ERROR") || line.includes("Traceback") || line.includes("CRASH")) cls = "err";
  else if (line.includes("warning") || line.includes("WARNING") || line.includes("Stop requested")) cls = "warn";
  else if (line.includes("web]")) cls = "info";
  logLine(line, cls);

  // Extract metrics from log lines for chart
  const stepMatch = line.match(/Step\s*\[(\d+)\/(\d+)\].*Loss:\s*([\d.]+)/);
  if (stepMatch) {
    const step = parseInt(stepMatch[1]);
    const loss = parseFloat(stepMatch[3]);
    const vramMatch = line.match(/VRAM:\s*([\d.]+)/);
    const vram = vramMatch ? parseFloat(vramMatch[1]) : null;
    pushHistory(step, loss, vram);
  }
  // Also parse from tqdm-style lines
  const tqdmMatch = line.match(/(\d+)\/\d+.*loss=([\d.]+)/);
  if (tqdmMatch && !stepMatch) {
    const step = parseInt(tqdmMatch[1]);
    const loss = parseFloat(tqdmMatch[2]);
    pushHistory(step, loss, null);
  }
}

function pushHistory(step, loss, vram) {
  // deduplicate by step
  const existing = history.find(h => h.step === step);
  if (existing) {
    existing.loss = loss;
    if (vram !== null) existing.vram = vram;
  } else {
    history.push({ step, loss, vram: vram || 0 });
  }
  if (history.length > 500) history.shift();
  updateChart();
}

function updateMetrics(status) {
  const state = status.state || "idle";
  const step = status.step || 0;
  const total = status.total_steps || 1;
  const loss = status.loss || 0;
  const vram = status.vram || 0;
  const elapsed = status.elapsed || 0;
  const msg = status.message || "";

  document.getElementById("mStep").textContent = step;
  document.getElementById("mLoss").textContent = loss > 0 ? loss.toFixed(4) : "--";
  document.getElementById("mVram").textContent = vram > 0 ? vram.toFixed(1) : "--";
  document.getElementById("mTime").textContent = formatTime(elapsed);

  const pct = total > 0 ? Math.round((step / total) * 100) : 0;
  const bar = document.getElementById("progressBar");
  bar.style.width = pct + "%";
  bar.textContent = pct + "%";

  if (state === "training") {
    setStatus("running", msg || `Training step ${step}/${total}`);
  } else if (state === "done") {
    setStatus("done", msg || "Training complete!");
    document.getElementById("startBtn").disabled = false;
    document.getElementById("stopBtn").disabled = true;
  } else if (state === "error") {
    setStatus("error", msg || "Error occurred");
    document.getElementById("startBtn").disabled = false;
    document.getElementById("stopBtn").disabled = true;
  } else if (state === "stopping") {
    setStatus("stopping", "Stopping...");
  } else if (state === "loading") {
    setStatus("running", msg || "Loading...");
  }
}

function setStatus(kind, text) {
  const dot = document.getElementById("statusDot");
  const txt = document.getElementById("statusText");
  dot.className = "dot " + kind;
  txt.textContent = text;
}

function formatTime(s) {
  if (!s) return "--";
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  if (m < 60) return `${m}m${sec}s`;
  const h = Math.floor(m / 60);
  return `${h}h${m % 60}m`;
}

function logLine(text, cls) {
  const consoleEl = document.getElementById("logConsole");
  const div = document.createElement("div");
  div.className = cls || "";
  div.textContent = text;
  consoleEl.appendChild(div);
  consoleEl.scrollTop = consoleEl.scrollHeight;
}

function clearLogs() {
  document.getElementById("logConsole").innerHTML = "";
}

function initChart() {
  const ctx = document.getElementById("lossChart").getContext("2d");
  chart = new Chart(ctx, {
    type: "line",
    data: {
      labels: [],
      datasets: [{
        label: "Loss",
        data: [],
        borderColor: "#58a6ff",
        backgroundColor: "rgba(88,166,255,0.1)",
        fill: true,
        tension: 0.3,
        pointRadius: 0,
        borderWidth: 2,
      }],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      animation: false,
      interaction: { mode: "index", intersect: false },
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: "rgba(13,17,23,0.95)",
          titleColor: "#c9d1d9",
          bodyColor: "#58a6ff",
          borderColor: "#30363d",
          borderWidth: 1,
        },
      },
      scales: {
        x: { display: false },
        y: {
          grid: { color: "#30363d" },
          ticks: { color: "#8b949e", font: { size: 11 } },
        },
      },
    },
  });
}

function updateChart() {
  if (!chart) return;
  const steps = history.map(h => h.step);
  const losses = history.map(h => h.loss);
  chart.data.labels = steps;
  chart.data.datasets[0].data = losses;
  chart.update("none");
}

// Poll status periodically as fallback
setInterval(async () => {
  if (!sse || sse.readyState !== EventSource.OPEN) {
    try {
      const resp = await fetch("/api/status");
      const status = await resp.json();
      updateMetrics(status);
    } catch (e) { /* ignore */ }
  }
}, 3000);

window.addEventListener("load", () => {
  initChart();
  logLine("[web] amazingvmsloth dashboard loaded. Ready.", "info");
});
