"""Web dashboard for amazingvmsloth."""
from .server import run_server, create_app

__all__ = ["run_server", "create_app"]
