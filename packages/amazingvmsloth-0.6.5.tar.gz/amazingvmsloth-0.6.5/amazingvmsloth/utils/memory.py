import torch
from typing import Dict, Optional


def get_memory_stats(device: Optional[torch.device] = None) -> Dict[str, float]:
    if not torch.cuda.is_available():
        return {"total_gb": 0, "used_gb": 0, "free_gb": 0}

    idx = device.index if device and device.type == "cuda" else 0
    props = torch.cuda.get_device_properties(idx)
    total_mem = getattr(props, "total_memory", getattr(props, "total_mem", 0))
    total = total_mem / 1024**3
    allocated = torch.cuda.memory_allocated(idx) / 1024**3
    reserved = torch.cuda.memory_reserved(idx) / 1024**3
    free = total - reserved

    return {
        "total_gb": round(total, 2),
        "used_gb": round(allocated, 2),
        "reserved_gb": round(reserved, 2),
        "free_gb": round(free, 2),
    }


def print_memory_stats(label: str = ""):
    stats = get_memory_stats()
    prefix = f"[{label}] " if label else "[amazingvmsloth] "
    print(f"{prefix}VRAM: {stats['used_gb']:.2f} used / {stats['reserved_gb']:.2f} reserved / {stats['total_gb']:.2f} total ({stats['free_gb']:.2f} free)")


def estimate_memory_requirements(
    model_params_b: float,
    seq_length: int = 2048,
    batch_size: int = 1,
    lora_r: int = 16,
    bits: int = 4,
    num_gpus: int = 1,
) -> Dict[str, float]:
    if bits == 4:
        model_mem = model_params_b * 0.5
    elif bits == 8:
        model_mem = model_params_b * 1.0
    else:
        model_mem = model_params_b * 2.0

    lora_mem = model_params_b * (2 * lora_r / 4096) * 2
    activation_mem = seq_length * batch_size * model_params_b * 0.001
    optimizer_mem = lora_mem * 8
    grad_mem = lora_mem * 2

    total = model_mem + lora_mem + activation_mem + optimizer_mem + grad_mem
    per_gpu = total / num_gpus

    return {
        "model_gb": round(model_mem, 2),
        "lora_gb": round(lora_mem, 2),
        "activations_gb": round(activation_mem, 2),
        "optimizer_gb": round(optimizer_mem, 2),
        "gradients_gb": round(grad_mem, 2),
        "total_gb": round(total, 2),
        "per_gpu_gb": round(per_gpu, 2),
    }


def garbage_collect_cuda():
    import gc
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        torch.cuda.synchronize()
