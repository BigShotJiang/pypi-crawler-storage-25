import sys
import torch
from typing import Dict, Any, Optional


def get_system_info() -> Dict[str, Any]:
    info = {
        "pytorch_version": torch.__version__,
        "cuda_available": torch.cuda.is_available(),
        "cuda_version": torch.version.cuda or "N/A",
        "platform": "Windows" if sys.platform.startswith("win") else "Linux",
    }
    
    if torch.cuda.is_available():
        props = torch.cuda.get_device_properties(0)
        info["gpu_name"] = props.name
        info["gpu_count"] = torch.cuda.device_count()
        info["gpu_memory_gb"] = round(props.total_memory / 1024**3, 1)
        info["cuda_compute"] = f"{props.major}.{props.minor}"
        info["bf16_supported"] = torch.cuda.is_bf16_supported()
    else:
        info["gpu_name"] = "CPU only"
        info["gpu_count"] = 0
        info["gpu_memory_gb"] = 0.0
        info["cuda_compute"] = "N/A"
        info["bf16_supported"] = False
    
    # Check optional optimizations
    try:
        import flash_attn
        info["flash_attn"] = True
    except ImportError:
        info["flash_attn"] = False
    
    try:
        import xformers
        info["xformers"] = True
    except ImportError:
        info["xformers"] = False
    
    try:
        import bitsandbytes
        info["bitsandbytes"] = True
    except ImportError:
        info["bitsandbytes"] = False
    
    try:
        import triton
        info["triton"] = True
    except ImportError:
        info["triton"] = False
    
    return info


def print_banner(info: Optional[Dict[str, Any]] = None, model_name: Optional[str] = None):
    if info is None:
        info = get_system_info()
    
    # ASCII art header
    print()
    print("  " + "=" * 58)
    print("   \\   / |    amazingvmsloth - Fast LLM Fine-Tuning")
    print("    O^O / \_/ \\   Minimal VRAM. Maximum Speed.")
    print("   \\        /")
    print("    \"-____-\"     ")
    print("  " + "=" * 58)
    print()
    
    # System info
    print(f"  Platform:     {info['platform']}")
    print(f"  PyTorch:      {info['pytorch_version']}")
    print(f"  CUDA:         {info['cuda_version']} (Compute {info['cuda_compute']})")
    
    if info['cuda_available']:
        print(f"  GPU:          {info['gpu_name']} x{info['gpu_count']}")
        print(f"  VRAM:         {info['gpu_memory_gb']} GB")
        print(f"  BFloat16:     {'Yes' if info['bf16_supported'] else 'No'}")
    
    # Optimizations
    opts = []
    if info.get("flash_attn"):
        opts.append("FlashAttention")
    if info.get("xformers"):
        opts.append("XFormers")
    if info.get("bitsandbytes"):
        opts.append("bitsandbytes")
    if info.get("triton"):
        opts.append("Triton")
    
    if opts:
        print(f"  Optimizations: {', '.join(opts)}")
    else:
        print(f"  Optimizations: None (install flash-attn, xformers for speed)")
    
    if model_name:
        print()
        print(f"  Model:        {model_name}")
    
    print()
    print("  " + "=" * 58)
    print()


def print_model_loading(model_name: str, quant: str = "4bit", estimated_vram_gb: float = 0.0):
    print(f"\n  [amazingvmsloth] Loading model: {model_name}")
    print(f"  [amazingvmsloth] Quantization: {quant}")
    if estimated_vram_gb > 0:
        print(f"  [amazingvmsloth] Estimated VRAM: ~{estimated_vram_gb:.1f} GB")
    print()


def print_training_start(config: Any):
    print()
    print("  " + "=" * 58)
    print("   Training Configuration")
    print("  " + "=" * 58)
    print(f"  Epochs:       {config.num_train_epochs}")
    print(f"  Batch size:   {config.per_device_train_batch_size}")
    print(f"  Grad accum:   {config.gradient_accumulation_steps}")
    print(f"  LR:           {config.learning_rate}")
    print(f"  Max length:   {config.max_seq_length}")
    print(f"  Optimizer:    {config.optim}")
    print(f"  Packing:      {config.packing}")
    print(f"  Checkpoint:   {'Yes' if config.gradient_checkpointing else 'No'}")
    print(f"  Compile:      {'Yes' if config.compile_model else 'No'}")
    print("  " + "=" * 58)
    print()
