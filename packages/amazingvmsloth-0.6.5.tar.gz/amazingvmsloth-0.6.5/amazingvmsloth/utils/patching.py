import torch
from typing import Optional, Dict
from transformers import PreTrainedModel
from amazingvmsloth.lora import LoRALayer, get_lora_state_dict, merge_and_unload


def patch_model_for_training(model: PreTrainedModel) -> PreTrainedModel:
    for name, param in model.named_parameters():
        if "lora_" not in name:
            param.requires_grad = False

    if hasattr(model, "gradient_checkpointing_enable"):
        model.gradient_checkpointing_enable(
            gradient_checkpointing_kwargs={"use_reentrant": False}
        )
    return model


def save_lora_weights(model: PreTrainedModel, path: str):
    lora_dict = get_lora_state_dict(model)
    if lora_dict:
        torch.save(lora_dict, path)
    else:
        print("[amazingvmsloth] No LoRA weights found to save")


def load_lora_weights(model: PreTrainedModel, path: str) -> PreTrainedModel:
    import os
    if os.path.isdir(path):
        pt_path = os.path.join(path, "lora_weights.pt")
        if os.path.isfile(pt_path):
            path = pt_path
        else:
            raise FileNotFoundError(f"No lora_weights.pt found in directory: {path}")
    lora_dict = torch.load(path, map_location="cpu")
    modules_dict = dict(model.named_modules())
    for name, module in model.named_modules():
        if isinstance(module, LoRALayer):
            for adapter_name in module.lora_A:
                a_key = f"{name}.lora_A.{adapter_name}"
                b_key = f"{name}.lora_B.{adapter_name}"
                if a_key in lora_dict:
                    module.lora_A[adapter_name].data.copy_(lora_dict[a_key])
                if b_key in lora_dict:
                    module.lora_B[adapter_name].data.copy_(lora_dict[b_key])
    print(f"[amazingvmsloth] LoRA weights loaded from {path}")
    return model


def get_model_info(model: PreTrainedModel) -> Dict:
    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    lora_params = 0
    base_params = 0
    for name, param in model.named_parameters():
        if "lora_" in name:
            lora_params += param.numel()
        else:
            base_params += param.numel()

    return {
        "total_params": total_params,
        "trainable_params": trainable_params,
        "lora_params": lora_params,
        "base_params": base_params,
        "trainable_pct": 100 * trainable_params / total_params if total_params > 0 else 0,
        "size_gb": total_params * 2 / 1024**3,
        "size_gb_4bit": total_params * 0.5 / 1024**3,
    }
