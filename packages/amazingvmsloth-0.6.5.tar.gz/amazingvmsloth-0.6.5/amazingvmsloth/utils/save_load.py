import torch
import os
from typing import Optional, Dict
from transformers import PreTrainedModel, PreTrainedTokenizer
from amazingvmsloth.lora import LoRALayer, get_lora_state_dict, merge_and_unload


def save_model(
    model: PreTrainedModel,
    tokenizer: Optional[PreTrainedTokenizer],
    output_dir: str,
    merge_lora: bool = False,
    safe_serialization: bool = True,
):
    os.makedirs(output_dir, exist_ok=True)

    if merge_lora:
        model = merge_and_unload(model)

    if hasattr(model, "save_pretrained"):
        model.save_pretrained(output_dir, safe_serialization=safe_serialization)
    if tokenizer is not None and hasattr(tokenizer, "save_pretrained"):
        tokenizer.save_pretrained(output_dir)

    if not merge_lora:
        lora_dict = get_lora_state_dict(model)
        if lora_dict:
            torch.save(lora_dict, os.path.join(output_dir, "lora_weights.pt"))

    print(f"[amazingvmsloth] Model saved to {output_dir}")


def load_model_for_inference(
    model_path: str,
    device: str = "auto",
    dtype: torch.dtype = torch.bfloat16,
    lora_path: Optional[str] = None,
):
    from transformers import AutoModelForCausalLM, AutoTokenizer

    model = AutoModelForCausalLM.from_pretrained(
        model_path,
        torch_dtype=dtype,
        device_map=device,
    )
    tokenizer = AutoTokenizer.from_pretrained(model_path)

    if lora_path is not None:
        from amazingvmsloth.utils.patching import load_lora_weights
        load_lora_weights(model, lora_path)

    return model, tokenizer
