import torch
import torch.nn as nn
from typing import Optional, Dict, List, Iterator, Tuple
from collections import defaultdict
import psutil


class PagedAdamW8bit(torch.optim.Optimizer):
    def __init__(
        self,
        params: Iterator[nn.Parameter],
        lr: float = 1e-4,
        betas: Tuple[float, float] = (0.9, 0.999),
        eps: float = 1e-8,
        weight_decay: float = 0.01,
        page_size: int = 2048,
        offload_threshold_mb: float = 1024,
    ):
        defaults = dict(lr=lr, betas=betas, eps=eps, weight_decay=weight_decay)
        super().__init__(params, defaults)
        self.page_size = page_size
        self.offload_threshold_mb = offload_threshold_mb
        self._paged_buffers: Dict[int, torch.Tensor] = {}
        self._cpu_states: Dict[int, torch.Tensor] = {}
        self._step_count = 0

    @torch.no_grad()
    def step(self, closure=None):
        loss = None
        if closure is not None:
            with torch.enable_grad():
                loss = closure()

        for group in self.param_groups:
            lr = group["lr"]
            beta1, beta2 = group["betas"]
            eps = group["eps"]
            wd = group["weight_decay"]

            for p in group["params"]:
                if p.grad is None:
                    continue

                state = self.state[p]
                if len(state) == 0:
                    state["step"] = 0
                    state["exp_avg"] = torch.zeros_like(p, dtype=torch.float32)
                    state["exp_avg_sq"] = torch.zeros_like(p, dtype=torch.float32)

                    numel = p.numel()
                    if numel > self.page_size and p.is_cuda:
                        param_id = id(p)
                        self._paged_buffers[param_id] = True
                        if self._should_offload(numel):
                            state["exp_avg"] = state["exp_avg"].cpu()
                            state["exp_avg_sq"] = state["exp_avg_sq"].cpu()
                            self._cpu_states[param_id] = True

                state["step"] += 1
                step = state["step"]

                grad = p.grad
                if grad.dtype != torch.float32:
                    grad = grad.float()

                exp_avg = state["exp_avg"]
                exp_avg_sq = state["exp_avg_sq"]

                if exp_avg.device != grad.device:
                    exp_avg = exp_avg.to(grad.device)
                    exp_avg_sq = exp_avg_sq.to(grad.device)
                    state["exp_avg"] = exp_avg
                    state["exp_avg_sq"] = exp_avg_sq

                p_data = p.data.float()

                exp_avg.mul_(beta1).add_(grad, alpha=1 - beta1)
                exp_avg_sq.mul_(beta2).addcmul_(grad, grad, value=1 - beta2)

                bias_correction1 = 1 - beta1 ** step
                bias_correction2 = 1 - beta2 ** step
                step_size = lr / bias_correction1

                denom = (exp_avg_sq.sqrt() / (bias_correction2 ** 0.5)).add_(eps)

                p_data.addcdiv_(exp_avg, denom, value=-step_size)

                if wd > 0:
                    p_data.add_(p_data, alpha=-wd * lr)

                p.data.copy_(p_data)

                if id(p) in self._cpu_states:
                    if not p.grad.is_cuda:
                        continue
                    state["exp_avg"] = exp_avg.cpu()
                    state["exp_avg_sq"] = exp_avg_sq.cpu()

        self._step_count += 1
        return loss

    def _should_offload(self, numel: int) -> bool:
        if not torch.cuda.is_available():
            return False
        free_mem = torch.cuda.mem_get_info()[0] / 1024**2
        param_mem = numel * 4 * 2 / 1024**2
        return free_mem < self.offload_threshold_mb and free_mem < param_mem * 3


class CpuOffloadedAdamW(torch.optim.Optimizer):
    def __init__(
        self,
        params: Iterator[nn.Parameter],
        lr: float = 1e-4,
        betas: Tuple[float, float] = (0.9, 0.999),
        eps: float = 1e-8,
        weight_decay: float = 0.01,
    ):
        defaults = dict(lr=lr, betas=betas, eps=eps, weight_decay=weight_decay)
        super().__init__(params, defaults)

    @torch.no_grad()
    def step(self, closure=None):
        loss = None
        if closure is not None:
            with torch.enable_grad():
                loss = closure()

        for group in self.param_groups:
            lr = group["lr"]
            beta1, beta2 = group["betas"]
            eps = group["eps"]
            wd = group["weight_decay"]

            for p in group["params"]:
                if p.grad is None:
                    continue

                state = self.state[p]
                if len(state) == 0:
                    state["step"] = 0
                    state["exp_avg"] = torch.zeros_like(p, dtype=torch.float32, device="cpu")
                    state["exp_avg_sq"] = torch.zeros_like(p, dtype=torch.float32, device="cpu")

                state["step"] += 1
                step = state["step"]

                grad = p.grad.detach().to(device="cpu", dtype=torch.float32)
                p_data = p.data.detach().to(device="cpu", dtype=torch.float32)

                exp_avg = state["exp_avg"]
                exp_avg_sq = state["exp_avg_sq"]

                exp_avg.mul_(beta1).add_(grad, alpha=1 - beta1)
                exp_avg_sq.mul_(beta2).addcmul_(grad, grad, value=1 - beta2)

                bias_correction1 = 1 - beta1 ** step
                bias_correction2 = 1 - beta2 ** step
                step_size = lr / bias_correction1

                denom = (exp_avg_sq.sqrt() / (bias_correction2 ** 0.5)).add_(eps)
                p_data.addcdiv_(exp_avg, denom, value=-step_size)

                if wd > 0:
                    p_data.add_(p_data, alpha=-wd * lr)

                p.data.copy_(p_data.to(p.device))

        return loss


def create_optimizer(
    model: nn.Module,
    optimizer_type: str = "paged_adamw_8bit",
    lr: float = 1e-4,
    weight_decay: float = 0.01,
    betas: Tuple[float, float] = (0.9, 0.999),
    eps: float = 1e-8,
    **kwargs,
) -> torch.optim.Optimizer:
    trainable_params = [p for p in model.parameters() if p.requires_grad]
    param_groups = [
        {
            "params": trainable_params,
            "lr": lr,
            "weight_decay": weight_decay,
        }
    ]

    if optimizer_type == "paged_adamw_8bit":
        try:
            import bitsandbytes as bnb
            optimizer = bnb.optim.PagedAdamW8bit(
                param_groups,
                lr=lr,
                betas=betas,
                eps=eps,
                weight_decay=weight_decay,
            )
            print("[amazingvmsloth] Using bitsandbytes PagedAdamW8bit")
        except ImportError:
            optimizer = PagedAdamW8bit(
                param_groups,
                lr=lr,
                betas=betas,
                eps=eps,
                weight_decay=weight_decay,
            )
            print("[amazingvmsloth] Using custom PagedAdamW8bit (bitsandbytes not found)")
    elif optimizer_type == "cpu_offloaded_adamw":
        optimizer = CpuOffloadedAdamW(
            param_groups,
            lr=lr,
            betas=betas,
            eps=eps,
            weight_decay=weight_decay,
        )
        print("[amazingvmsloth] Using CPU-offloaded AdamW")
    elif optimizer_type == "adamw":
        optimizer = torch.optim.AdamW(
            param_groups,
            lr=lr,
            betas=betas,
            eps=eps,
            weight_decay=weight_decay,
        )
        print("[amazingvmsloth] Using standard AdamW")
    else:
        raise ValueError(f"Unknown optimizer type: {optimizer_type}")

    return optimizer
