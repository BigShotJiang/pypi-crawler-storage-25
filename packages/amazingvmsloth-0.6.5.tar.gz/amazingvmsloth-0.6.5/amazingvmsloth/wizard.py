"""
Hardware-aware training config wizard for amazingvmsloth.

Analyzes your system and recommends optimal training settings.
Can generate ready-to-run CLI commands or JSON config files.
"""

import json
import sys
import torch
from typing import Dict, Any, Optional, List, Tuple
from dataclasses import dataclass, asdict

from amazingvmsloth.utils.banner import get_system_info
from amazingvmsloth.utils.memory import estimate_memory_requirements


# Common open models with approximate sizes
MODEL_CATALOG = {
    # Tiny models (< 1B) - great for testing
    "Qwen/Qwen2.5-0.5B": {"params_b": 0.5, "type": "qwen2", "seq_len": 32768},
    "Qwen/Qwen3-0.6B": {"params_b": 0.6, "type": "qwen3", "seq_len": 32768},
    "microsoft/Phi-3-mini-4k-instruct": {"params_b": 3.8, "type": "phi3", "seq_len": 4096},
    
    # Small models (1-3B)
    "Qwen/Qwen2.5-1.5B": {"params_b": 1.5, "type": "qwen2", "seq_len": 32768},
    "unsloth/Qwen2.5-1.5B-bnb-4bit": {"params_b": 1.5, "type": "qwen2", "seq_len": 32768, "pre_quantized": True},
    "Qwen/Qwen3-1.7B": {"params_b": 1.7, "type": "qwen3", "seq_len": 32768},
    "Qwen/Qwen3-4B": {"params_b": 4.0, "type": "qwen3", "seq_len": 32768},
    "meta-llama/Llama-3.2-1B": {"params_b": 1.0, "type": "llama", "seq_len": 128000},
    "meta-llama/Llama-3.2-3B": {"params_b": 3.0, "type": "llama", "seq_len": 128000},
    "HuggingFaceTB/SmolLM2-1.7B": {"params_b": 1.7, "type": "llama", "seq_len": 8192},
    
    # Medium models (7-9B)
    "unsloth/Llama-3.1-8B-bnb-4bit": {"params_b": 8.0, "type": "llama", "seq_len": 128000, "pre_quantized": True},
    "unsloth/Mistral-7B-v0.3-bnb-4bit": {"params_b": 7.0, "type": "mistral", "seq_len": 32768, "pre_quantized": True},
    "Qwen/Qwen2.5-7B": {"params_b": 7.0, "type": "qwen2", "seq_len": 32768},
    "meta-llama/Meta-Llama-3-8B": {"params_b": 8.0, "type": "llama", "seq_len": 8192},
    
    # Large models (14B+)
    "unsloth/Qwen2.5-14B-bnb-4bit": {"params_b": 14.0, "type": "qwen2", "seq_len": 32768, "pre_quantized": True},
    "unsloth/Llama-3.1-70B-bnb-4bit": {"params_b": 70.0, "type": "llama", "seq_len": 128000, "pre_quantized": True},
}


@dataclass
class RecommendedConfig:
    model: str
    quant: str
    lora_r: int
    lora_alpha: int
    batch_size: int
    grad_accum: int
    max_seq_length: int
    epochs: int
    lr: float
    optimizer: str
    gradient_checkpointing: bool
    packing: bool
    compile: bool
    offload_layers: int
    cpu: bool
    estimated_vram_gb: float
    estimated_ram_gb: float
    estimated_time_per_epoch_hr: float
    reasoning: List[str]


def get_ram_gb() -> float:
    """Get total system RAM in GB."""
    try:
        import psutil
        return psutil.virtual_memory().total / 1024**3
    except ImportError:
        # Fallback: rough guess
        return 16.0


def detect_hardware() -> Dict[str, Any]:
    """Comprehensive hardware detection."""
    info = get_system_info()
    info["ram_gb"] = round(get_ram_gb(), 1)
    
    # CPU info
    info["cpu_count"] = torch.multiprocessing.cpu_count() if hasattr(torch.multiprocessing, "cpu_count") else sys.cpu_count()
    if info["cpu_count"] is None:
        info["cpu_count"] = 8
    info["cpu_physical"] = info["cpu_count"] // 2
    
    # Classify hardware tier
    if info["cuda_available"]:
        vram = info["gpu_memory_gb"]
        if vram >= 24:
            info["tier"] = "high_end"
            info["tier_name"] = "High-End (24GB+)"
        elif vram >= 12:
            info["tier"] = "mid_range"
            info["tier_name"] = "Mid-Range (12-24GB)"
        elif vram >= 6:
            info["tier"] = "entry_level"
            info["tier_name"] = "Entry-Level (6-12GB)"
        else:
            info["tier"] = "low_vram"
            info["tier_name"] = "Low VRAM (4-6GB)"
    else:
        info["tier"] = "cpu_only"
        info["tier_name"] = "CPU Only"
    
    return info


def estimate_training_time(
    params_b: float,
    seq_length: int,
    batch_size: int,
    grad_accum: int,
    dataset_size: int = 50000,
    hardware_tier: str = "mid_range",
) -> float:
    """Estimate hours per epoch. Very rough heuristic."""
    # Base tokens/sec for different tiers (rough estimates)
    tokens_per_sec = {
        "high_end": 8000,
        "mid_range": 3000,
        "entry_level": 1500,
        "low_vram": 800,
        "cpu_only": 200,
    }.get(hardware_tier, 1000)
    
    # Adjust for sequence length
    tokens_per_sec *= min(1.0, 2048 / max(seq_length, 1))
    
    # Adjust for model size
    tokens_per_sec *= min(1.0, 7.0 / max(params_b, 0.5))
    
    total_tokens = dataset_size * seq_length
    effective_batch = batch_size * grad_accum
    steps_per_epoch = total_tokens / (seq_length * effective_batch)
    
    seconds_per_step = (seq_length * effective_batch) / tokens_per_sec
    hours_per_epoch = (steps_per_epoch * seconds_per_step) / 3600
    
    return round(hours_per_epoch, 1)


def suggest_models(hardware: Dict[str, Any]) -> List[Tuple[str, Dict[str, Any]]]:
    """Suggest models that fit the user's hardware."""
    vram = hardware.get("gpu_memory_gb", 0)
    ram = hardware.get("ram_gb", 16)
    tier = hardware["tier"]
    suggestions = []
    
    for name, meta in MODEL_CATALOG.items():
        params = meta["params_b"]
        pre_quant = meta.get("pre_quantized", False)
        
        # Estimate memory with 4-bit quant and modest LoRA
        mem = estimate_memory_requirements(
            model_params_b=params,
            seq_length=min(2048, meta.get("seq_len", 2048)),
            batch_size=1,
            lora_r=16,
            bits=4,
            num_gpus=1,
        )
        required_vram = mem["total_gb"] * 1.3  # safety margin
        required_ram = params * 0.5  # roughly for CPU offloading
        
        if tier == "cpu_only":
            # CPU training: need model to fit in RAM
            if required_ram < ram * 0.8:
                fit = "fits"
            elif required_ram < ram * 1.2:
                fit = "tight"
            else:
                fit = "too_large"
        else:
            if required_vram < vram * 0.8:
                fit = "fits"
            elif required_vram < vram * 1.1:
                fit = "tight"
            else:
                fit = "too_large"
        
        if fit != "too_large":
            suggestions.append((name, meta, fit, required_vram))
    
    # Sort: pre-quantized first, then by size
    suggestions.sort(key=lambda x: (not MODEL_CATALOG[x[0]].get("pre_quantized", False), x[1]["params_b"]))
    return suggestions


def generate_config(
    model_name: str,
    hardware: Dict[str, Any],
    dataset_size: int = 50000,
    aggressive: bool = False,
) -> RecommendedConfig:
    """Generate optimal training config for given model + hardware."""
    meta = MODEL_CATALOG.get(model_name)
    if meta is None:
        # Try to guess from model name
        if "0.5" in model_name or "500M" in model_name.lower():
            meta = {"params_b": 0.5, "type": "unknown", "seq_len": 32768}
        elif "1.5" in model_name:
            meta = {"params_b": 1.5, "type": "unknown", "seq_len": 32768}
        elif "3" in model_name or "3.2" in model_name:
            meta = {"params_b": 3.0, "type": "unknown", "seq_len": 128000}
        elif "7" in model_name or "8" in model_name:
            meta = {"params_b": 7.5, "type": "unknown", "seq_len": 8192}
        elif "14" in model_name:
            meta = {"params_b": 14.0, "type": "unknown", "seq_len": 32768}
        elif "70" in model_name:
            meta = {"params_b": 70.0, "type": "unknown", "seq_len": 128000}
        else:
            meta = {"params_b": 7.0, "type": "unknown", "seq_len": 8192}
    
    params_b = meta["params_b"]
    tier = hardware["tier"]
    vram = hardware.get("gpu_memory_gb", 0)
    ram = hardware.get("ram_gb", 16)
    reasoning = []
    
    # Defaults
    config = {
        "model": model_name,
        "quant": "4bit",
        "lora_r": 16,
        "lora_alpha": 16,
        "batch_size": 2,
        "grad_accum": 4,
        "max_seq_length": 2048,
        "epochs": 3,
        "lr": 2e-4,
        "optimizer": "paged_adamw_8bit",
        "gradient_checkpointing": True,
        "packing": True,
        "compile": False,
        "offload_layers": 0,
        "cpu": False,
    }
    
    # Tier-specific tuning
    if tier == "cpu_only":
        config["cpu"] = True
        config["quant"] = "none"
        config["optimizer"] = "adamw"
        config["compile"] = True  # Try compile, fallback gracefully
        config["batch_size"] = 1
        config["grad_accum"] = 2
        config["max_seq_length"] = 512
        config["packing"] = True
        reasoning.append("CPU mode: no quantization, fp32/bf16, pre-packing enabled")
        
        if params_b < 2.0:
            config["batch_size"] = 2
            reasoning.append(f"Small model ({params_b}B): can use batch_size=2 on CPU")
        
        if ram < 16:
            config["max_seq_length"] = 256
            reasoning.append("Low RAM: reducing sequence length to 256")
    
    elif tier == "low_vram":
        config["quant"] = "4bit"
        config["batch_size"] = 1
        config["grad_accum"] = 8
        config["max_seq_length"] = 512
        config["gradient_checkpointing"] = True
        config["packing"] = True
        reasoning.append("Low VRAM (4-6GB): using 4-bit quant, batch_size=1, aggressive accumulation")
        
        # Model-size-aware LoRA rank on low VRAM
        if params_b <= 3:
            config["lora_r"] = 16
            config["lora_alpha"] = 16
            reasoning.append(f"Small model ({params_b}B): can use lora_r=16 within 4-6GB VRAM")
            if params_b <= 1:
                config["batch_size"] = 2
                config["grad_accum"] = 4
                reasoning.append("Tiny model: can increase batch size to 2")
        elif params_b <= 7:
            config["lora_r"] = 8
            config["lora_alpha"] = 16
            reasoning.append(f"Medium model ({params_b}B): conservative lora_r=8")
        else:
            config["lora_r"] = 4
            config["lora_alpha"] = 8
            reasoning.append(f"Large model ({params_b}B): minimal lora_r=4")
        
        if params_b > 7:
            config["offload_layers"] = 4
            config["max_seq_length"] = 256
            reasoning.append(f"Large model ({params_b}B): enabling layer offloading (4 layers on GPU)")
        
        if params_b > 14:
            config["offload_layers"] = 2
            config["lora_r"] = 4
            reasoning.append("Very large model: minimal GPU layers, tiny LoRA rank")
    
    elif tier == "entry_level":
        config["quant"] = "4bit"
        config["batch_size"] = 1
        config["grad_accum"] = 4
        config["max_seq_length"] = 1024
        config["lora_r"] = 16
        config["gradient_checkpointing"] = True
        reasoning.append("Entry-level (6-12GB): 4-bit quant, moderate settings")
        
        if params_b <= 3:
            config["batch_size"] = 2
            config["max_seq_length"] = 2048
            reasoning.append("Small model: can increase batch size and sequence length")
        
        if params_b > 14:
            config["offload_layers"] = 8
            reasoning.append("Large model: partial layer offloading")
    
    elif tier == "mid_range":
        config["quant"] = "4bit"
        config["batch_size"] = 2
        config["grad_accum"] = 2
        config["max_seq_length"] = 2048
        config["lora_r"] = 32
        config["gradient_checkpointing"] = True
        config["compile"] = True
        reasoning.append("Mid-range (12-24GB): 4-bit quant, can use larger LoRA, torch.compile")
        
        if params_b <= 3:
            config["batch_size"] = 4
            config["grad_accum"] = 1
            config["quant"] = "none"
            config["compile"] = True
            reasoning.append("Small model: full precision training for best quality")
        
        if params_b > 30:
            config["offload_layers"] = 12
            reasoning.append("Very large model: offloading some layers to CPU")
    
    elif tier == "high_end":
        config["quant"] = "none"
        config["batch_size"] = 4
        config["grad_accum"] = 1
        config["max_seq_length"] = 4096
        config["lora_r"] = 64
        config["gradient_checkpointing"] = False
        config["compile"] = True
        reasoning.append("High-end (24GB+): full precision, no grad checkpointing, torch.compile")
        
        if params_b > 30:
            config["quant"] = "8bit"
            reasoning.append("Very large model: 8-bit to fit in VRAM")
    
    # Aggressive mode overrides
    if aggressive:
        config["max_seq_length"] = int(config["max_seq_length"] * 1.5)
        config["batch_size"] = max(1, config["batch_size"] + 1)
        config["lora_r"] = min(128, config["lora_r"] * 2)
        reasoning.append("Aggressive mode: pushing hardware harder")
    
    # Pre-quantized models
    if meta.get("pre_quantized"):
        config["quant"] = "4bit"  # They already are
        reasoning.append("Pre-quantized model: faster loading, reliable on Windows")
    
    # Estimate memory
    mem = estimate_memory_requirements(
        model_params_b=params_b,
        seq_length=config["max_seq_length"],
        batch_size=config["batch_size"],
        lora_r=config["lora_r"],
        bits=4 if config["quant"] == "4bit" else (8 if config["quant"] == "8bit" else 16),
        num_gpus=1,
    )
    
    estimated_vram = mem["total_gb"] * 1.3
    estimated_ram = params_b * 0.5 if config["cpu"] else 0
    
    # Time estimate
    time_hr = estimate_training_time(
        params_b=params_b,
        seq_length=config["max_seq_length"],
        batch_size=config["batch_size"],
        grad_accum=config["grad_accum"],
        dataset_size=dataset_size,
        hardware_tier=tier,
    )
    
    return RecommendedConfig(
        model=config["model"],
        quant=config["quant"],
        lora_r=config["lora_r"],
        lora_alpha=config["lora_alpha"],
        batch_size=config["batch_size"],
        grad_accum=config["grad_accum"],
        max_seq_length=config["max_seq_length"],
        epochs=config["epochs"],
        lr=config["lr"],
        optimizer=config["optimizer"],
        gradient_checkpointing=config["gradient_checkpointing"],
        packing=config["packing"],
        compile=config["compile"],
        offload_layers=config["offload_layers"],
        cpu=config["cpu"],
        estimated_vram_gb=round(estimated_vram, 1),
        estimated_ram_gb=round(estimated_ram, 1),
        estimated_time_per_epoch_hr=time_hr,
        reasoning=reasoning,
    )


def config_to_cli_args(config: RecommendedConfig) -> str:
    """Convert config to a CLI command string."""
    args = [
        "amazingvmsloth train",
        f"--model {config.model}",
        f"--dataset YOUR_DATASET",  # User must fill this
        f"--output-dir ./output-{config.model.split('/')[-1]}",
        f"--epochs {config.epochs}",
        f"--batch-size {config.batch_size}",
        f"--grad-accum {config.grad_accum}",
        f"--lr {config.lr}",
        f"--lora-r {config.lora_r}",
        f"--lora-alpha {config.lora_alpha}",
        f"--max-seq-length {config.max_seq_length}",
        f"--quant {config.quant}",
        f"--optimizer {config.optimizer}",
    ]
    
    if config.gradient_checkpointing:
        args.append("--gradient-checkpointing")
    if config.packing:
        args.append("--packing")
    if config.compile:
        args.append("--compile")
    if config.cpu:
        args.append("--cpu")
    if config.offload_layers > 0:
        args.append(f"--offload-layers {config.offload_layers}")
    
    return " \\\n    ".join(args)


def print_wizard_banner():
    print()
    print("  " + "=" * 58)
    print("   Training Config Wizard")
    print("   Let me analyze your hardware and suggest settings")
    print("  " + "=" * 58)
    print()


def run_wizard_interactive(model_name: Optional[str] = None, aggressive: bool = False, json_output: Optional[str] = None):
    """Run the interactive wizard."""
    print_wizard_banner()
    
    hardware = detect_hardware()
    
    print("  Hardware Profile")
    print("  " + "-" * 40)
    print(f"  Tier:         {hardware['tier_name']}")
    if hardware['cuda_available']:
        print(f"  GPU:          {hardware['gpu_name']}")
        print(f"  VRAM:         {hardware['gpu_memory_gb']} GB")
        print(f"  CUDA:         {hardware['cuda_version']}")
    print(f"  RAM:          {hardware['ram_gb']} GB")
    print(f"  CPU cores:    {hardware['cpu_physical']} physical / {hardware['cpu_count']} logical")
    print()
    
    # Model selection
    if model_name is None:
        suggestions = suggest_models(hardware)
        print("  Suggested Models (that fit your hardware):")
        print("  " + "-" * 40)
        for i, (name, meta, fit, vram) in enumerate(suggestions[:8], 1):
            fit_icon = "✓" if fit == "fits" else "~"
            pre = " [pre-quantized]" if meta.get("pre_quantized") else ""
            print(f"  {i}. {fit_icon} {name} ({meta['params_b']}B){pre}")
            print(f"     Est VRAM: ~{vram:.1f} GB")
        print()
        
        choice = input("  Enter model name (or pick 1-{}): ".format(min(8, len(suggestions))))
        choice = choice.strip()
        
        if choice.isdigit():
            idx = int(choice) - 1
            if 0 <= idx < len(suggestions):
                model_name = suggestions[idx][0]
            else:
                print("  Invalid choice, using first suggestion")
                model_name = suggestions[0][0] if suggestions else "unsloth/Qwen2.5-1.5B-bnb-4bit"
        else:
            model_name = choice if choice else (suggestions[0][0] if suggestions else "unsloth/Qwen2.5-1.5B-bnb-4bit")
    
    print(f"\n  Selected model: {model_name}")
    
    # Generate config
    config = generate_config(model_name, hardware, aggressive=aggressive)
    
    print()
    print("  " + "=" * 58)
    print("   Recommended Configuration")
    print("  " + "=" * 58)
    print(f"  Model:          {config.model}")
    print(f"  Quantization:   {config.quant}")
    print(f"  LoRA rank:      {config.lora_r} (alpha={config.lora_alpha})")
    print(f"  Batch size:     {config.batch_size}")
    print(f"  Grad accum:     {config.grad_accum}")
    print(f"  Max seq length: {config.max_seq_length}")
    print(f"  Epochs:         {config.epochs}")
    print(f"  Learning rate:  {config.lr}")
    print(f"  Optimizer:      {config.optimizer}")
    print(f"  Grad checkpoint:{'Yes' if config.gradient_checkpointing else 'No'}")
    print(f"  Packing:        {'Yes' if config.packing else 'No'}")
    print(f"  torch.compile:  {'Yes' if config.compile else 'No'}")
    if config.offload_layers > 0:
        print(f"  Offload layers: {config.offload_layers}")
    if config.cpu:
        print(f"  CPU mode:       Yes")
    print()
    print(f"  Est VRAM:       ~{config.estimated_vram_gb} GB")
    print(f"  Est RAM:        ~{config.estimated_ram_gb} GB")
    print(f"  Est time/epoch: ~{config.estimated_time_per_epoch_hr} hr")
    print()
    
    print("  Reasoning:")
    for r in config.reasoning:
        print(f"    • {r}")
    print()
    
    # CLI command
    print("  " + "=" * 58)
    print("   Ready-to-Run Command")
    print("  " + "=" * 58)
    print("  (Replace YOUR_DATASET with your dataset name/path)")
    print()
    print("  " + config_to_cli_args(config))
    print()
    
    # Save JSON if requested
    if json_output:
        data = asdict(config)
        with open(json_output, "w") as f:
            json.dump(data, f, indent=2)
        print(f"  Config saved to: {json_output}")
        print()
    
    # Offer to run
    if json_output is None:
        run = input("  Save this config to a JSON file? (path or 'n'): ").strip()
        if run and run.lower() != "n":
            data = asdict(config)
            with open(run, "w") as f:
                json.dump(data, f, indent=2)
            print(f"  Saved to {run}")
    
    return config


def run_wizard_quick(model_name: str, aggressive: bool = False, json_output: Optional[str] = None) -> RecommendedConfig:
    """Non-interactive quick wizard."""
    hardware = detect_hardware()
    config = generate_config(model_name, hardware, aggressive=aggressive)
    
    print_wizard_banner()
    print(f"  Hardware: {hardware['tier_name']}")
    if hardware['cuda_available']:
        print(f"  GPU: {hardware['gpu_name']} ({hardware['gpu_memory_gb']} GB VRAM)")
    print(f"  RAM: {hardware['ram_gb']} GB")
    print()
    
    print(f"  Model: {config.model}")
    print(f"  Est VRAM: ~{config.estimated_vram_gb} GB")
    print()
    
    print("  Recommended settings:")
    print(f"    quant={config.quant}, lora_r={config.lora_r}, batch={config.batch_size}, "
          f"accum={config.grad_accum}, seq_len={config.max_seq_length}")
    print()
    
    print("  Command:")
    print("  " + config_to_cli_args(config))
    print()
    
    if json_output:
        data = asdict(config)
        with open(json_output, "w") as f:
            json.dump(data, f, indent=2)
        print(f"  Saved to {json_output}")
    
    return config


if __name__ == "__main__":
    # Simple CLI for testing
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("--model", help="Model name")
    p.add_argument("--aggressive", action="store_true")
    p.add_argument("--json", help="Save config to JSON file")
    p.add_argument("--non-interactive", action="store_true", help="Skip prompts")
    a = p.parse_args()
    
    if a.non_interactive or a.model:
        run_wizard_quick(a.model or "unsloth/Qwen2.5-1.5B-bnb-4bit", a.aggressive, a.json)
    else:
        run_wizard_interactive(a.model, a.aggressive, a.json)
