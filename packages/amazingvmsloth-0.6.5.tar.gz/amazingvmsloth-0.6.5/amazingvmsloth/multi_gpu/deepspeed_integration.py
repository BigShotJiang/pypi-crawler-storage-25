import os
import torch
import torch.distributed as dist
from typing import Optional, Dict, Any


class DeepSpeedConfig:
    def __init__(
        self,
        stage: int = 2,
        offload_optimizer: bool = True,
        offload_param: bool = False,
        zero3_save_16bit_model: bool = True,
        gradient_accumulation_steps: int = 1,
        gradient_clipping: float = 1.0,
    ):
        self.stage = stage
        self.offload_optimizer = offload_optimizer
        self.offload_param = offload_param
        self.zero3_save_16bit_model = zero3_save_16bit_model
        self.gradient_accumulation_steps = gradient_accumulation_steps
        self.gradient_clipping = gradient_clipping

    def to_dict(self) -> Dict[str, Any]:
        config = {
            "train_batch_size": "auto",
            "train_micro_batch_size_per_gpu": "auto",
            "gradient_accumulation_steps": self.gradient_accumulation_steps,
            "gradient_clipping": self.gradient_clipping,
            "zero_optimization": {
                "stage": self.stage,
                "overlap_comm": True,
                "contiguous_gradients": True,
                "reduce_bucket_size": 5e7,
                "stage3_prefetch_bucket_size": "auto",
                "stage3_param_persistence_threshold": "auto",
            },
            "bf16": {"enabled": True},
            "zero3_save_16bit_model": self.zero3_save_16bit_model,
        }

        if self.offload_optimizer:
            config["zero_optimization"]["offload_optimizer"] = {
                "device": "cpu",
                "pin_memory": True,
            }
        if self.offload_param and self.stage == 3:
            config["zero_optimization"]["offload_param"] = {
                "device": "cpu",
                "pin_memory": True,
            }

        return config


def setup_deepspeed(
    model: torch.nn.Module,
    config: Optional[DeepSpeedConfig] = None,
    optimizer: Optional[torch.optim.Optimizer] = None,
    lr_scheduler: Optional[Any] = None,
) -> Any:
    try:
        import deepspeed
    except ImportError:
        print("[amazingvmsloth] deepspeed not installed. Install with: pip install deepspeed")
        return model, optimizer, lr_scheduler

    if config is None:
        config = DeepSpeedConfig()

    ds_config = config.to_dict()

    model_engine, optimizer, _, lr_scheduler = deepspeed.initialize(
        model=model,
        optimizer=optimizer,
        lr_scheduler=lr_scheduler,
        config_params=ds_config,
    )

    print(f"[amazingvmsloth] DeepSpeed ZeRO-{config.stage} initialized")
    if config.offload_optimizer:
        print("[amazingvmsloth] Optimizer offloading to CPU enabled")

    return model_engine, optimizer, lr_scheduler
