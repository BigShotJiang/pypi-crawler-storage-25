import torch
import torch.nn as nn
from typing import Optional, List, Dict, Any
from collections import OrderedDict


class PipelineParallelWrapper:
    def __init__(
        self,
        model: nn.Module,
        num_stages: int = 2,
        split_points: Optional[List[str]] = None,
        device_ids: Optional[List[int]] = None,
    ):
        self.model = model
        self.num_stages = num_stages
        self.split_points = split_points
        self.device_ids = device_ids or list(range(torch.cuda.device_count()))
        self.stages: List[nn.Module] = []
        self._split_model()

    def _split_model(self):
        if self.split_points is None:
            self._auto_split()
        else:
            self._manual_split()

    def _auto_split(self):
        layers = []
        for name, module in self.model.named_modules():
            if any(key in name for key in ["layers", "blocks", "h"]):
                if not any(key in n for n in [m[0] for m in layers]):
                    layers.append((name, module))

        if not layers:
            self.stages = [self.model]
            return

        n_per_stage = max(1, len(layers) // self.num_stages)
        for i in range(self.num_stages):
            start = i * n_per_stage
            end = start + n_per_stage if i < self.num_stages - 1 else len(layers)
            stage_modules = OrderedDict()
            for name, module in layers[start:end]:
                stage_modules[name] = module
            if stage_modules:
                stage = nn.ModuleDict(stage_modules)
                self.stages.append(stage)

    def _manual_split(self):
        children = list(self.model.named_children())
        n_per_stage = max(1, len(children) // self.num_stages)
        for i in range(self.num_stages):
            start = i * n_per_stage
            end = start + n_per_stage if i < self.num_stages - 1 else len(children)
            stage_modules = OrderedDict(children[start:end])
            self.stages.append(nn.ModuleDict(stage_modules))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        for i, stage in enumerate(self.stages):
            device = torch.device(f"cuda:{self.device_ids[i % len(self.device_ids)]}")
            x = x.to(device)
            if isinstance(stage, nn.ModuleDict):
                for module in stage.values():
                    x = module(x) if not isinstance(module, nn.ModuleDict) else x
            else:
                x = stage(x)
        return x
