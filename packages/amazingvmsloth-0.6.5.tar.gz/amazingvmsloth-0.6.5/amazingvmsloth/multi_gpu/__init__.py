import os
import datetime
import torch
import torch.nn as nn
import torch.distributed as dist
from typing import Optional, Dict, Any, List

from amazingvmsloth.multi_gpu.deepspeed_integration import DeepSpeedConfig, setup_deepspeed
from amazingvmsloth.multi_gpu.pipeline import PipelineParallelWrapper


def setup_distributed(
    backend: str = "nccl",
    init_method: Optional[str] = None,
    timeout_minutes: int = 30,
) -> bool:
    if not torch.cuda.is_available():
        print("[amazingvmsloth] No CUDA devices found")
        return False

    if dist.is_initialized():
        print("[amazingvmsloth] Distributed already initialized")
        return True

    n_gpus = torch.cuda.device_count()
    if n_gpus <= 1:
        print(f"[amazingvmsloth] Single GPU detected (count={n_gpus}), no distributed setup needed")
        return False

    if "RANK" not in os.environ:
        os.environ.setdefault("MASTER_ADDR", "localhost")
        os.environ.setdefault("MASTER_PORT", "29500")
        os.environ.setdefault("RANK", "0")
        os.environ.setdefault("LOCAL_RANK", "0")
        os.environ.setdefault("WORLD_SIZE", str(n_gpus))

    try:
        dist.init_process_group(
            backend=backend,
            init_method=init_method,
            timeout=datetime.timedelta(minutes=timeout_minutes),
        )
        rank = dist.get_rank()
        world_size = dist.get_world_size()
        local_rank = int(os.environ.get("LOCAL_RANK", 0))
        torch.cuda.set_device(local_rank)
        print(f"[amazingvmsloth] Distributed: rank={rank}, world_size={world_size}, local_rank={local_rank}")
        return True
    except Exception as e:
        print(f"[amazingvmsloth] Distributed init failed: {e}")
        return False


def wrap_model_ddp(
    model: nn.Module,
    device_ids: Optional[List[int]] = None,
    output_device: Optional[int] = None,
    find_unused_parameters: bool = False,
    gradient_as_bucket_view: bool = True,
) -> nn.Module:
    if not dist.is_initialized():
        return model

    local_rank = int(os.environ.get("LOCAL_RANK", 0))
    if device_ids is None:
        device_ids = [local_rank]
    if output_device is None:
        output_device = local_rank

    model = nn.parallel.DistributedDataParallel(
        model,
        device_ids=device_ids,
        output_device=output_device,
        find_unused_parameters=find_unused_parameters,
        gradient_as_bucket_view=gradient_as_bucket_view,
        static_graph=True,
    )
    print(f"[amazingvmsloth] Model wrapped with DDP (device_ids={device_ids})")
    return model


def wrap_model_fsdp(
    model: nn.Module,
    sharding_strategy: str = "FULL_SHARD",
    mixed_precision: bool = True,
    cpu_offload: bool = False,
    wrap_layer_cls: Optional[str] = None,
) -> nn.Module:
    try:
        from torch.distributed.fsdp import (
            FullyShardedDataParallel as FSDP,
            ShardingStrategy,
            MixedPrecision,
            CPUOffload,
        )
    except ImportError:
        print("[amazingvmsloth] FSDP not available (requires PyTorch >= 2.0)")
        return model

    if not dist.is_initialized():
        print("[amazingvmsloth] FSDP requires distributed init — call setup_distributed() first")
        return model

    strategy_map = {
        "FULL_SHARD": ShardingStrategy.FULL_SHARD,
        "SHARD_GRAD_OP": ShardingStrategy.SHARD_GRAD_OP,
        "NO_SHARD": ShardingStrategy.NO_SHARD,
        "HYBRID_SHARD": ShardingStrategy.HYBRID_SHARD,
    }
    strategy = strategy_map.get(sharding_strategy, ShardingStrategy.FULL_SHARD)

    mp_policy = None
    if mixed_precision:
        mp_policy = MixedPrecision(
            param_dtype=torch.bfloat16,
            reduce_dtype=torch.bfloat16,
            buffer_dtype=torch.bfloat16,
        )

    cpu_offload_policy = CPUOffload(offload_params=cpu_offload)

    auto_wrap_policy = None
    if wrap_layer_cls:
        try:
            from torch.distributed.fsdp.wrap import transformer_auto_wrap_policy
            import importlib
            parts = wrap_layer_cls.rsplit(".", 1)
            module = importlib.import_module(parts[0])
            cls = getattr(module, parts[1])
            auto_wrap_policy = transformer_auto_wrap_policy(transformer_layer_cls={cls})
        except Exception as e:
            print(f"[amazingvmsloth] Could not create auto wrap policy: {e}")

    model = FSDP(
        model,
        sharding_strategy=strategy,
        mixed_precision=mp_policy,
        cpu_offload=cpu_offload_policy,
        auto_wrap_policy=auto_wrap_policy,
        device_id=torch.cuda.current_device(),
    )
    print(f"[amazingvmsloth] Model wrapped with FSDP (strategy={sharding_strategy})")
    return model


def cleanup_distributed():
    if dist.is_initialized():
        dist.destroy_process_group()
        print("[amazingvmsloth] Distributed process group destroyed")


def get_world_size() -> int:
    if dist.is_initialized():
        return dist.get_world_size()
    return 1


def get_rank() -> int:
    if dist.is_initialized():
        return dist.get_rank()
    return 0


def is_main_process() -> bool:
    return get_rank() == 0


def barrier():
    if dist.is_initialized():
        dist.barrier()


def all_reduce_tensor(tensor: torch.Tensor, op=dist.ReduceOp.SUM) -> torch.Tensor:
    if not dist.is_initialized():
        return tensor
    dist.all_reduce(tensor, op=op)
    return tensor


__all__ = [
    "setup_distributed",
    "wrap_model_ddp",
    "wrap_model_fsdp",
    "cleanup_distributed",
    "get_world_size",
    "get_rank",
    "is_main_process",
    "barrier",
    "all_reduce_tensor",
    "DeepSpeedConfig",
    "setup_deepspeed",
    "PipelineParallelWrapper",
]
