"""
Multimodal training support for amazingvmsloth.
Handles vision (images), audio, and video preprocessing for
multimodal language models (LLaVA, Qwen-VL, Whisper, Video-LLaMA, etc.).
"""
import os
import base64
import io
from typing import Optional, List, Dict, Any, Union, Tuple
from pathlib import Path

import torch
import torch.nn as nn


try:
    from PIL import Image
    _PIL_AVAILABLE = True
except ImportError:
    _PIL_AVAILABLE = False

try:
    import numpy as np
    _NUMPY_AVAILABLE = True
except ImportError:
    _NUMPY_AVAILABLE = False


# ---------------------------------------------------------------------------
# Vision Processor
# ---------------------------------------------------------------------------

class VisionProcessor:
    """Preprocess images for vision-language models.

    Supports:
      - CLIP-style: 224x224, ImageNet normalize
      - LLaVA-style: 336x336 or 448x448
      - Qwen-VL style: dynamic aspect ratio
    """

    def __init__(
        self,
        image_size: int = 336,
        mode: str = "rgb",
        normalize: bool = True,
        mean: Tuple[float, float, float] = (0.48145466, 0.4578275, 0.40821073),
        std: Tuple[float, float, float] = (0.26862954, 0.26130258, 0.27577711),
    ):
        if not _PIL_AVAILABLE:
            raise ImportError("PIL (Pillow) is required for image processing. Install: pip install Pillow")
        self.image_size = image_size
        self.mode = mode
        self.normalize = normalize
        self.mean = torch.tensor(mean).view(3, 1, 1)
        self.std = torch.tensor(std).view(3, 1, 1)

    def load_image(self, path_or_bytes: Union[str, bytes, io.BytesIO]) -> Image.Image:
        """Load image from file path, bytes, or BytesIO."""
        if isinstance(path_or_bytes, str):
            if path_or_bytes.startswith("data:image"):
                # Base64 encoded image
                b64 = path_or_bytes.split(",")[1]
                path_or_bytes = base64.b64decode(b64)
            img = Image.open(path_or_bytes)
        elif isinstance(path_or_bytes, bytes):
            img = Image.open(io.BytesIO(path_or_bytes))
        elif isinstance(path_or_bytes, io.BytesIO):
            img = Image.open(path_or_bytes)
        else:
            raise TypeError(f"Expected str, bytes, or BytesIO, got {type(path_or_bytes)}")
        return img.convert("RGB" if self.mode == "rgb" else "L")

    def preprocess(self, path_or_bytes: Union[str, bytes, io.BytesIO]) -> torch.Tensor:
        """Preprocess a single image → (C, H, W) tensor."""
        img = self.load_image(path_or_bytes)
        img = img.resize((self.image_size, self.image_size), Image.LANCZOS)
        if not _NUMPY_AVAILABLE:
            raise ImportError("numpy is required for image preprocessing")
        arr = np.array(img).astype(np.float32) / 255.0
        tensor = torch.from_numpy(arr).permute(2, 0, 1)  # HWC → CHW
        if self.normalize:
            tensor = (tensor - self.mean) / self.std
        return tensor

    def preprocess_batch(self, items: List[Union[str, bytes]]) -> torch.Tensor:
        """Preprocess a batch of images → (B, C, H, W) tensor."""
        tensors = [self.preprocess(item) for item in items]
        return torch.stack(tensors)


# ---------------------------------------------------------------------------
# Audio Processor
# ---------------------------------------------------------------------------

class AudioProcessor:
    """Preprocess audio for audio-language models (Whisper, Qwen-Audio, etc.).

    Supports:
      - Whisper-style: 16kHz, 30s clips, log-mel spectrogram
      - Raw waveform: resample to target rate
    """

    def __init__(
        self,
        sample_rate: int = 16000,
        n_mels: int = 80,
        n_fft: int = 400,
        hop_length: int = 160,
        chunk_length: int = 30,
    ):
        self.sample_rate = sample_rate
        self.n_mels = n_mels
        self.n_fft = n_fft
        self.hop_length = hop_length
        self.chunk_length = chunk_length
        self.max_samples = sample_rate * chunk_length

    def _load_audio(self, path_or_bytes: Union[str, bytes]) -> np.ndarray:
        """Load audio to waveform. Supports wav, mp3, flac."""
        try:
            if isinstance(path_or_bytes, str):
                if path_or_bytes.startswith("data:audio"):
                    b64 = path_or_bytes.split(",")[1]
                    path_or_bytes = base64.b64decode(b64)
                # Try librosa first (best quality)
                import librosa
                waveform, sr = librosa.load(path_or_bytes, sr=self.sample_rate, mono=True)
                return waveform
            else:
                import librosa
                import soundfile as sf
                waveform, sr = sf.read(io.BytesIO(path_or_bytes), dtype="float32")
                if len(waveform.shape) > 1:
                    waveform = waveform.mean(axis=1)  # stereo → mono
                if sr != self.sample_rate:
                    waveform = librosa.resample(waveform, orig_sr=sr, target_sr=self.sample_rate)
                return waveform
        except ImportError:
            # Fallback: try scipy / wave
            import wave
            if isinstance(path_or_bytes, str):
                wf = wave.open(path_or_bytes, "rb")
            else:
                wf = wave.open(io.BytesIO(path_or_bytes), "rb")
            nchannels, sampwidth, framerate, nframes = wf.getnchannels(), wf.getsampwidth(), wf.getframerate(), wf.getnframes()
            raw = wf.readframes(nframes)
            wf.close()
            import array
            fmt = {1: "b", 2: "h", 4: "i"}.get(sampwidth, "h")
            samples = array.array(fmt, raw)
            waveform = np.array(samples, dtype=np.float32)
            if nchannels == 2:
                waveform = waveform.reshape(-1, 2).mean(axis=1)
            # Normalize to [-1, 1]
            max_val = float(2 ** (sampwidth * 8 - 1))
            waveform = waveform / max_val
            if framerate != self.sample_rate:
                # Simple linear resample (not great but works without librosa)
                old_len = len(waveform)
                new_len = int(old_len * self.sample_rate / framerate)
                indices = np.linspace(0, old_len - 1, new_len)
                waveform = np.interp(indices, np.arange(old_len), waveform)
            return waveform

    def _log_mel_spectrogram(self, waveform: np.ndarray) -> torch.Tensor:
        """Convert waveform to log-mel spectrogram (Whisper-style)."""
        if not _NUMPY_AVAILABLE:
            raise ImportError("numpy required")
        # Pad or truncate to max length
        if len(waveform) > self.max_samples:
            waveform = waveform[:self.max_samples]
        else:
            waveform = np.pad(waveform, (0, self.max_samples - len(waveform)))

        # Compute STFT
        window = np.hanning(self.n_fft)
        hop = self.hop_length
        frames = []
        for i in range(0, len(waveform) - self.n_fft + 1, hop):
            frame = waveform[i:i + self.n_fft] * window
            spec_frame = np.fft.rfft(frame)
            frames.append(np.abs(spec_frame) ** 2)
        spectrogram = np.array(frames).T  # (n_fft//2+1, n_frames)

        # Mel filterbank (simplified triangular)
        mel_bins = self._triangular_filterbank(self.n_fft // 2 + 1, self.n_mels)
        mel_spec = mel_bins @ spectrogram  # (n_mels, n_frames)

        # Log scale
        log_spec = np.log10(np.clip(mel_spec, a_min=1e-10, a_max=None))
        return torch.from_numpy(log_spec).float()

    def _triangular_filterbank(self, num_freq: int, num_mel: int) -> np.ndarray:
        """Simple triangular mel filterbank (no librosa dependency)."""
        def hz_to_mel(hz):
            return 2595 * np.log10(1 + hz / 700)
        def mel_to_hz(mel):
            return 700 * (10 ** (mel / 2595) - 1)

        low_freq = 0
        high_freq = self.sample_rate // 2
        mel_points = np.linspace(hz_to_mel(low_freq), hz_to_mel(high_freq), num_mel + 2)
        hz_points = mel_to_hz(mel_points)
        bin_points = np.floor((num_freq) * hz_points / high_freq).astype(int)
        bin_points = np.clip(bin_points, 0, num_freq - 1)

        filterbank = np.zeros((num_mel, num_freq))
        for i in range(num_mel):
            left, center, right = bin_points[i], bin_points[i + 1], bin_points[i + 2]
            if center > left:
                for j in range(left, center):
                    filterbank[i, j] = (j - left) / (center - left)
            if right > center:
                for j in range(center, right):
                    filterbank[i, j] = (right - j) / (right - center)
        return filterbank

    def preprocess(self, path_or_bytes: Union[str, bytes]) -> torch.Tensor:
        """Preprocess audio → (n_mels, n_frames) log-mel spectrogram tensor."""
        waveform = self._load_audio(path_or_bytes)
        return self._log_mel_spectrogram(waveform)

    def preprocess_batch(self, items: List[Union[str, bytes]]) -> List[torch.Tensor]:
        """Audio lengths vary, so return list of tensors."""
        return [self.preprocess(item) for item in items]


# ---------------------------------------------------------------------------
# Video Processor
# ---------------------------------------------------------------------------

class VideoProcessor:
    """Preprocess video for video-language models.

    Extracts frames uniformly and processes each as an image.
    Supports Video-LLaMA, VideoChatGPT, etc.
    """

    def __init__(
        self,
        num_frames: int = 8,
        image_size: int = 336,
        vision_processor: Optional[VisionProcessor] = None,
    ):
        self.num_frames = num_frames
        self.vision_processor = vision_processor or VisionProcessor(image_size=image_size)

    def _extract_frames(self, path_or_bytes: Union[str, bytes]) -> List[Image.Image]:
        """Extract uniformly spaced frames from a video file."""
        if not _PIL_AVAILABLE:
            raise ImportError("PIL required for video frame extraction")
        try:
            import cv2
            if isinstance(path_or_bytes, str):
                cap = cv2.VideoCapture(path_or_bytes)
            else:
                cap = cv2.VideoCapture(io.BytesIO(path_or_bytes).read())
            total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
            if total_frames <= 0:
                cap.release()
                return []
            indices = np.linspace(0, total_frames - 1, self.num_frames, dtype=int)
            frames = []
            for idx in indices:
                cap.set(cv2.CAP_PROP_POS_FRAMES, idx)
                ret, frame = cap.read()
                if ret:
                    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                    frames.append(Image.fromarray(frame))
            cap.release()
            return frames
        except ImportError:
            # Fallback: try decord (better for ML)
            try:
                from decord import VideoReader, cpu
                if isinstance(path_or_bytes, str):
                    vr = VideoReader(path_or_bytes, ctx=cpu(0))
                else:
                    vr = VideoReader(io.BytesIO(path_or_bytes), ctx=cpu(0))
                total_frames = len(vr)
                indices = np.linspace(0, total_frames - 1, self.num_frames, dtype=int)
                frames = vr.get_batch(indices).asnumpy()
                return [Image.fromarray(f) for f in frames]
            except ImportError:
                raise ImportError(
                    "Video processing requires opencv-python or decord. "
                    "Install: pip install opencv-python  OR  pip install decord"
                )

    def preprocess(self, path_or_bytes: Union[str, bytes]) -> torch.Tensor:
        """Preprocess video → (num_frames, C, H, W) tensor."""
        frames = self._extract_frames(path_or_bytes)
        if not frames:
            # Return blank frames if extraction failed
            blank = torch.zeros(3, self.vision_processor.image_size, self.vision_processor.image_size)
            return blank.unsqueeze(0).repeat(self.num_frames, 1, 1, 1)
        tensors = [self.vision_processor.preprocess(f) for f in frames]
        # Pad or truncate to exactly num_frames
        if len(tensors) < self.num_frames:
            # Repeat last frame
            while len(tensors) < self.num_frames:
                tensors.append(tensors[-1] if tensors else blank)
        elif len(tensors) > self.num_frames:
            tensors = tensors[:self.num_frames]
        return torch.stack(tensors)

    def preprocess_batch(self, items: List[Union[str, bytes]]) -> torch.Tensor:
        """Batch of videos → (B, num_frames, C, H, W) tensor."""
        tensors = [self.preprocess(item) for item in items]
        return torch.stack(tensors)


# ---------------------------------------------------------------------------
# Multimodal Dataset Collator
# ---------------------------------------------------------------------------

class MultimodalCollator:
    """Collator that handles mixed text + image/audio/video batches.

    Each batch item is a dict with:
      - 'input_ids', 'attention_mask', 'labels' (text tokens)
      - optional 'pixel_values' or 'images' (vision)
      - optional 'audio_features' or 'spectrogram' (audio)
      - optional 'video_frames' (video)
    """

    def __init__(
        self,
        modality: str = "vision",
        pad_token_id: int = 0,
    ):
        self.modality = modality
        self.pad_token_id = pad_token_id

    def __call__(self, batch: List[Dict[str, Any]]) -> Dict[str, torch.Tensor]:
        # Text collating (same as before)
        max_len = max(len(item["input_ids"]) for item in batch)
        input_ids = []
        attention_mask = []
        labels = []
        for item in batch:
            seq = item["input_ids"]
            pad_len = max_len - len(seq)
            input_ids.append(seq + [self.pad_token_id] * pad_len)
            attention_mask.append([1] * len(seq) + [0] * pad_len)
            labels.append(item.get("labels", seq) + [-100] * pad_len)

        result = {
            "input_ids": torch.tensor(input_ids, dtype=torch.long),
            "attention_mask": torch.tensor(attention_mask, dtype=torch.long),
            "labels": torch.tensor(labels, dtype=torch.long),
        }

        # Add media tensors if present
        if self.modality == "vision":
            images = [item.get("pixel_values") or item.get("images") for item in batch if item.get("pixel_values") or item.get("images")]
            if images:
                result["pixel_values"] = torch.stack(images)
        elif self.modality == "audio":
            audio = [item.get("audio_features") or item.get("spectrogram") for item in batch if item.get("audio_features") or item.get("spectrogram")]
            if audio:
                # Audio lengths vary — pad to max length in batch
                max_audio_len = max(a.shape[-1] for a in audio)
                padded = []
                for a in audio:
                    pad_len = max_audio_len - a.shape[-1]
                    if pad_len > 0:
                        a = torch.nn.functional.pad(a, (0, pad_len))
                    padded.append(a)
                result["audio_features"] = torch.stack(padded)
        elif self.modality == "video":
            videos = [item.get("video_frames") for item in batch if item.get("video_frames")]
            if videos:
                result["video_frames"] = torch.stack(videos)

        return result


# ---------------------------------------------------------------------------
# Model Patcher Helpers for Multimodal
# ---------------------------------------------------------------------------

def patch_multimodal_model(model, modality: str = "vision"):
    """Patch a multimodal model for efficient training.

    Freezes vision/audio encoders, applies LoRA to LLM + projection layers.
    """
    # Freeze vision/audio encoder weights (don't train them)
    encoder_prefixes = {
        "vision": ["vision_model", "vision_tower", "visual", "image_encoder", "clip"],
        "audio": ["encoder", "audio_encoder", "audio_tower", "whisper_encoder"],
        "video": ["vision_model", "video_encoder", "visual"],
    }
    prefixes = encoder_prefixes.get(modality, [])

    frozen_count = 0
    trainable_count = 0
    for name, param in model.named_parameters():
        should_freeze = any(p in name.lower() for p in prefixes)
        if should_freeze:
            param.requires_grad = False
            frozen_count += 1
        else:
            # Keep trainable for LoRA / projection / LLM
            trainable_count += 1

    print(f"[multimodal] Frozen {frozen_count} encoder params, {trainable_count} params remain trainable")
    return model


def get_multimodal_lora_targets(modality: str = "vision") -> List[str]:
    """Get target module names for LoRA in multimodal models."""
    base_targets = ["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"]
    if modality == "vision":
        # Also train the vision-language projection / connector
        return base_targets + ["mm_projector", "vision_projector", "image_projection", "visual_projection"]
    elif modality == "audio":
        return base_targets + ["audio_projection", "encoder_projection"]
    elif modality == "video":
        return base_targets + ["mm_projector", "video_projector", "temporal_projection"]
    return base_targets


# ---------------------------------------------------------------------------
# Format helpers for multimodal datasets
# ---------------------------------------------------------------------------

def format_image_text_pair(
    instruction: str,
    image_path: str,
    response: str,
    tokenizer: Any,
    image_token: str = "<image>",
) -> str:
    """Format image + text into a prompt string for vision-language models."""
    # LLaVA-style: <image>\nInstruction\nResponse
    prompt = f"{image_token}\n{instruction}\n{response}"
    return prompt


def format_audio_text_pair(
    instruction: str,
    audio_path: str,
    response: str,
    tokenizer: Any,
    audio_token: str = "<audio>",
) -> str:
    """Format audio + text into a prompt string."""
    prompt = f"{audio_token}\n{instruction}\n{response}"
    return prompt


def format_video_text_pair(
    instruction: str,
    video_path: str,
    response: str,
    tokenizer: Any,
    video_token: str = "<video>",
) -> str:
    """Format video + text into a prompt string."""
    prompt = f"{video_token}\n{instruction}\n{response}"
    return prompt


# ---------------------------------------------------------------------------
# Convenience factory
# ---------------------------------------------------------------------------

def create_processor(modality: str, **kwargs):
    """Factory to create the right preprocessor for a modality."""
    if modality in ("vision", "image"):
        return VisionProcessor(**kwargs)
    elif modality in ("audio", "sound"):
        return AudioProcessor(**kwargs)
    elif modality in ("video", "clip"):
        return VideoProcessor(**kwargs)
    else:
        raise ValueError(f"Unknown modality: {modality}. Choose: vision, audio, video")
