import torch
import torch.nn as nn
from typing import Dict, List, Optional, Callable, Any, Set
from transformers import PreTrainedModel


class SelectiveGradientCheckpointing:
    def __init__(self, model: PreTrainedModel, checkpoint_every_n: int = 1):
        self.model = model
        self.checkpoint_every_n = checkpoint_every_n
        self._original_forward = {}
        self._checkpointed_layers: Set[str] = set()

    def enable(self):
        if hasattr(self.model, "gradient_checkpointing_enable"):
            self.model.gradient_checkpointing_enable(
                gradient_checkpointing_kwargs={"use_reentrant": False}
            )
        self._setup_selective()
        self._make_inputs_require_grad()
        print(f"[amazingvmsloth] Selective gradient checkpointing enabled (every {self.checkpoint_every_n} layers)")

    def _setup_selective(self):
        for name, module in self.model.named_modules():
            layer_num = self._extract_layer_number(name)
            if layer_num is not None:
                if layer_num % self.checkpoint_every_n == 0:
                    self._checkpointed_layers.add(name)

    def _extract_layer_number(self, name: str) -> Optional[int]:
        parts = name.split(".")
        for part in reversed(parts):
            if part.isdigit():
                return int(part)
        return None

    def _make_inputs_require_grad(self):
        def make_inputs_require_grad(module, input, output):
            output.requires_grad_(True)

        if hasattr(self.model, "model") and hasattr(self.model.model, "embed_tokens"):
            self.model.model.embed_tokens.register_forward_hook(make_inputs_require_grad)
        elif hasattr(self.model, "get_input_embeddings"):
            embed = self.model.get_input_embeddings()
            if embed is not None:
                embed.register_forward_hook(make_inputs_require_grad)


class GradientAccumulator:
    def __init__(self, accumulation_steps: int = 1):
        self.accumulation_steps = accumulation_steps
        self._accumulated_steps = 0
        self._accumulated_loss = 0.0

    def should_step(self) -> bool:
        self._accumulated_steps += 1
        return self._accumulated_steps % self.accumulation_steps == 0

    def accumulate(self, loss: torch.Tensor) -> torch.Tensor:
        scaled_loss = loss / self.accumulation_steps
        self._accumulated_loss += scaled_loss.item()
        return scaled_loss

    def reset(self):
        self._accumulated_steps = 0
        self._accumulated_loss = 0.0

    @property
    def mean_loss(self) -> float:
        if self._accumulated_steps == 0:
            return 0.0
        return self._accumulated_loss * self.accumulation_steps / self._accumulated_steps


def enable_gradient_checkpointing(
    model: PreTrainedModel,
    checkpoint_every_n: int = 1,
    use_reentrant: bool = False,
) -> PreTrainedModel:
    sg = SelectiveGradientCheckpointing(model, checkpoint_every_n)
    sg.enable()

    if hasattr(model, "gradient_checkpointing_enable"):
        try:
            model.gradient_checkpointing_enable(
                gradient_checkpointing_kwargs={"use_reentrant": use_reentrant}
            )
        except TypeError:
            model.gradient_checkpointing_enable()

    return model


def set_gradient_requirements(
    model: PreTrainedModel,
    trainable_module_names: Optional[List[str]] = None,
    freeze_embeddings: bool = True,
    freeze_layer_norm: bool = False,
    freeze_lm_head: bool = True,
) -> PreTrainedModel:
    for name, param in model.named_parameters():
        param.requires_grad = False

    for name, param in model.named_parameters():
        if trainable_module_names:
            for tmn in trainable_module_names:
                if tmn in name:
                    param.requires_grad = True
                    break
        else:
            if "lora_" in name:
                param.requires_grad = True

    if not freeze_layer_norm:
        for name, param in model.named_parameters():
            if "norm" in name.lower():
                param.requires_grad = True

    if freeze_embeddings:
        for name, param in model.named_parameters():
            if "embed" in name.lower():
                param.requires_grad = False

    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    total = sum(p.numel() for p in model.parameters())
    print(f"[amazingvmsloth] Trainable: {trainable:,} / {total:,} ({100*trainable/total:.2f}%)")
    return model
