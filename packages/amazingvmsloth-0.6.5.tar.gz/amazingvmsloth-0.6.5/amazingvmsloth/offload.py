import torch
import torch.nn as nn
from typing import Optional, Dict, List, Tuple
from transformers import PreTrainedModel


def create_auto_device_map(model: PreTrainedModel, max_gpu_layers: int = 2) -> Dict[str, str]:
    n_layers = 0
    layer_prefixes = set()
    for name, module in model.named_modules():
        for attr in ["layers", "blocks", "h"]:
            if hasattr(module, attr) and attr in name:
                for part in name.split("."):
                    if part.isdigit():
                        n_layers = max(n_layers, int(part) + 1)
                        layer_prefixes.add(name.rsplit(".", 1)[0])
                break

    if n_layers == 0:
        for name, module in model.named_modules():
            mn = type(module).__name__.lower()
            if "decoderlayer" in mn or "transformerblock" in mn:
                n_layers += 1

    device_map = {}
    gpu_layers = set(range(min(max_gpu_layers, n_layers)))

    for name, _ in model.named_modules():
        is_embed = any(k in name.lower() for k in ["embed_tokens", "embed", "wte"])
        is_norm = name.endswith("norm") or "layernorm" in name.lower()
        is_lm_head = any(k in name.lower() for k in ["lm_head"]) and "norm" not in name.lower()

        layer_idx = None
        for part in name.split("."):
            if part.isdigit():
                layer_idx = int(part)
                break

        if is_embed or is_lm_head or is_norm:
            device_map[name] = "cuda:0"
        elif layer_idx is not None and layer_idx in gpu_layers:
            device_map[name] = "cuda:0"
        elif layer_idx is not None:
            device_map[name] = "cpu"
        elif "rotary_emb" in name:
            device_map[name] = "cuda:0"

    return device_map


def apply_dispatch_offload(
    model: PreTrainedModel,
    max_gpu_layers: int = 2,
    verbose: bool = True,
) -> PreTrainedModel:
    try:
        from accelerate import dispatch_model, infer_auto_device_map
    except ImportError:
        print("[amazingvmsloth] accelerate not found, falling back to device_map='auto'")
        return model

    n_layers = 0
    for name, module in model.named_modules():
        for attr in ["layers", "blocks", "h"]:
            if hasattr(module, attr):
                for part in name.split("."):
                    if part.isdigit():
                        n_layers = max(n_layers, int(part) + 1)
                break

    if n_layers == 0:
        if verbose:
            print("[amazingvmsloth] Could not detect layers, using device_map='auto'")
        return model

    try:
        no_split = []
        for name, module in model.named_modules():
            mt = type(module).__name__
            if any(k in mt for k in ["Attention", "MLP", "DecoderLayer", "Block"]):
                cls = type(module)
                if cls not in no_split:
                    no_split.append(cls)

        max_memory = {}
        if torch.cuda.is_available():
            total = torch.cuda.get_device_properties(0).total_memory / 1024**3
            max_memory[0] = f"{max(1.0, total * 0.7):.1f}GiB"
        max_memory["cpu"] = "30GiB"

        device_map = infer_auto_device_map(
            model,
            max_memory=max_memory,
            no_split_module_classes=no_split,
        )

        if verbose:
            gpu_count = sum(1 for v in device_map.values() if v == 0 or v == "cuda:0")
            cpu_count = sum(1 for v in device_map.values() if v == "cpu")
            print(f"[amazingvmsloth] Auto device map: {gpu_count} modules on GPU, {cpu_count} on CPU")

        model = dispatch_model(model, device_map=device_map)

    except Exception as e:
        if verbose:
            print(f"[amazingvmsloth] dispatch_model failed: {e}")
            print("[amazingvmsloth] Falling back to simple device_map")

        device_map = create_auto_device_map(model, max_gpu_layers)
        try:
            model = dispatch_model(model, device_map=device_map)
        except Exception as e2:
            if verbose:
                print(f"[amazingvmsloth] Fallback dispatch also failed: {e2}")
            return model

    return model


def estimate_model_size_gb(model_name: str) -> float:
    try:
        from transformers import AutoConfig
        config = AutoConfig.from_pretrained(model_name)
        vocab = getattr(config, "vocab_size", 32000)
        n_layers = getattr(config, "num_hidden_layers", 32)
        h_size = getattr(config, "hidden_size", 4096)
        i_size = getattr(config, "intermediate_size", 11008)
        params = n_layers * (3 * h_size * i_size + 2 * h_size * h_size) + vocab * h_size
        return params / 1e9
    except Exception:
        return 7.0
