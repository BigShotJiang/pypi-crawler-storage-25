import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional, Tuple
from transformers import PreTrainedModel

_flash_available = False
try:
    from flash_attn import flash_attn_func
    _flash_available = True
except ImportError:
    pass

_xformers_available = False
try:
    from xformers.ops import memory_efficient_attention
    _xformers_available = True
except ImportError:
    pass


def is_flash_available() -> bool:
    return _flash_available


class EfficientAttention(nn.Module):
    def __init__(self, original_module, config=None):
        super().__init__()
        self.original_module = original_module
        self.config = config
        self._use_flash = False
        self.num_heads = getattr(original_module, "num_heads", 32)
        self.num_kv_heads = getattr(original_module, "num_kv_groups", None) or getattr(
            original_module, "num_key_value_heads", self.num_heads
        )
        self.head_dim = getattr(original_module, "head_dim", 128)
        self.hidden_size = self.num_heads * self.head_dim

    def _try_flash_attention(self, q, k, v, attention_mask=None):
        if not _flash_available:
            return None
        if q.dtype != torch.float16 and q.dtype != torch.bfloat16:
            return None
        if q.size(1) > 8192 and q.device.type != "cuda":
            return None

        try:
            seq_len = q.size(1)
            q_4d = q.view(q.size(0), seq_len, self.num_heads, self.head_dim)
            k_4d = k.view(k.size(0), k.size(1), self.num_kv_heads, self.head_dim)
            v_4d = v.view(v.size(0), v.size(1), self.num_kv_heads, self.head_dim)

            if self.num_kv_heads != self.num_heads:
                n_rep = self.num_heads // self.num_kv_heads
                k_4d = k_4d.unsqueeze(2).expand(-1, -1, n_rep, -1, -1).reshape(q.size(0), -1, self.num_heads, self.head_dim)
                v_4d = v_4d.unsqueeze(2).expand(-1, -1, n_rep, -1, -1).reshape(q.size(0), -1, self.num_heads, self.head_dim)

            output = flash_attn_func(q_4d, k_4d, v_4d, causal=True)
            return output.view(q.size(0), seq_len, -1)
        except Exception:
            return None

    def _sdpa_attention(self, q, k, v, attention_mask=None):
        if hasattr(F, "scaled_dot_product_attention"):
            is_causal = attention_mask is None
            output = F.scaled_dot_product_attention(
                q, k, v,
                attn_mask=attention_mask,
                is_causal=is_causal,
            )
            return output
        return None

    def forward(self, hidden_states, attention_mask=None, position_ids=None, **kwargs):
        return self.original_module(
            hidden_states,
            attention_mask=attention_mask,
            position_ids=position_ids,
            **kwargs,
        )


class PatchedLlamaAttention(nn.Module):
    def __init__(self, original_attn, config=None):
        super().__init__()
        self.q_proj = original_attn.q_proj
        self.k_proj = original_attn.k_proj
        self.v_proj = original_attn.v_proj
        self.o_proj = original_attn.o_proj
        self.rotary_emb = original_attn.rotary_emb
        self.config = config

        model_config = getattr(original_attn, "config", None)
        self.hidden_size = getattr(model_config, "hidden_size", 4096)
        self.num_heads = getattr(model_config, "num_attention_heads", 32)
        self.head_dim = getattr(model_config, "head_dim", self.hidden_size // self.num_heads)
        self.num_key_value_heads = getattr(model_config, "num_key_value_heads", self.num_heads)
        self.num_key_value_groups = self.num_heads // self.num_key_value_heads
        self.max_position_embeddings = getattr(model_config, "max_position_embeddings", 4096)

    def _shape(self, tensor, seq_len, bsz):
        return tensor.view(bsz, seq_len, self.num_heads, self.head_dim).transpose(1, 2)

    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_value=None,
        output_attentions: bool = False,
        use_cache: bool = False,
        **kwargs,
    ) -> Tuple[torch.Tensor, Optional[torch.Tensor], Optional[Tuple[torch.Tensor]]]:
        bsz, q_len, _ = hidden_states.size()

        query_states = self.q_proj(hidden_states)
        key_states = self.k_proj(hidden_states)
        value_states = self.v_proj(hidden_states)

        query_states = query_states.view(bsz, q_len, self.num_heads, self.head_dim).transpose(1, 2)
        key_states = key_states.view(bsz, q_len, self.num_key_value_heads, self.head_dim).transpose(1, 2)
        value_states = value_states.view(bsz, q_len, self.num_key_value_heads, self.head_dim).transpose(1, 2)

        cos, sin = self.rotary_emb(value_states, position_ids)
        query_states, key_states = _apply_rotary_pos_emb(query_states, key_states, cos, sin)

        if past_key_value is not None:
            key_states = torch.cat([past_key_value[0], key_states], dim=2)
            value_states = torch.cat([past_key_value[1], value_states], dim=2)
        past_key_value = (key_states, value_states) if use_cache else None

        if self.num_key_value_groups > 1:
            key_states = _repeat_kv(key_states, self.num_key_value_groups)
            value_states = _repeat_kv(value_states, self.num_key_value_groups)

        attn_output = _efficient_attn(query_states, key_states, value_states, attention_mask)

        attn_output = attn_output.transpose(1, 2).contiguous()
        attn_output = attn_output.reshape(bsz, q_len, self.hidden_size)
        attn_output = self.o_proj(attn_output)

        if not output_attentions:
            attn_weights = None

        return attn_output, attn_weights, past_key_value


def _apply_rotary_pos_emb(q, k, cos, sin):
    def _rotate_half(x):
        x1 = x[..., : x.shape[-1] // 2]
        x2 = x[..., x.shape[-1] // 2 :]
        return torch.cat((-x2, x1), dim=-1)

    q_embed = (q * cos) + (_rotate_half(q) * sin)
    k_embed = (k * cos) + (_rotate_half(k) * sin)
    return q_embed, k_embed


def _repeat_kv(hidden_states, n_rep):
    if n_rep == 1:
        return hidden_states
    bsz, num_heads, seq_len, head_dim = hidden_states.shape
    hidden_states = hidden_states[:, :, None, :, :].expand(bsz, num_heads, n_rep, seq_len, head_dim)
    return hidden_states.reshape(bsz, num_heads * n_rep, seq_len, head_dim)


def _efficient_attn(q, k, v, mask=None):
    bsz, n_heads, seq_len, head_dim = q.shape

    if _flash_available and q.is_cuda and q.dtype in (torch.float16, torch.bfloat16):
        try:
            q_4d = q.transpose(1, 2)
            k_4d = k.transpose(1, 2)
            v_4d = v.transpose(1, 2)
            out = flash_attn_func(q_4d, k_4d, v_4d, causal=True)
            return out.transpose(1, 2)
        except Exception:
            pass

    if _xformers_available and q.is_cuda and q.dtype in (torch.float16, torch.bfloat16):
        try:
            q_3d = q.transpose(1, 2).reshape(bsz * seq_len, n_heads, head_dim)
            k_3d = k.transpose(1, 2).reshape(bsz * seq_len, n_heads, head_dim)
            v_3d = v.transpose(1, 2).reshape(bsz * seq_len, n_heads, head_dim)
            attn_bias = mask if mask is not None else None
            out = memory_efficient_attention(q_3d, k_3d, v_3d, attn_bias=attn_bias)
            return out.reshape(bsz, seq_len, n_heads, head_dim).transpose(1, 2)
        except Exception:
            pass

    if hasattr(F, "scaled_dot_product_attention"):
        is_causal = mask is None
        return F.scaled_dot_product_attention(q, k, v, attn_mask=mask, is_causal=is_causal)

    attn_weights = torch.matmul(q, k.transpose(2, 3)) / (q.shape[-1] ** 0.5)
    if mask is not None:
        attn_weights = attn_weights + mask
    attn_weights = F.softmax(attn_weights, dim=-1, dtype=torch.float32).to(q.dtype)
    return torch.matmul(attn_weights, v)


def patch_attention(model: PreTrainedModel) -> PreTrainedModel:
    if hasattr(model, "config"):
        model.config._attn_implementation = "sdpa"

    modules_dict = dict(model.named_modules())
    patched_count = 0

    for name, module in list(modules_dict.items()):
        module_type = type(module).__name__
        if "Attention" in module_type or "SdpaAttention" in module_type:
            has_rotary = hasattr(module, "rotary_emb")
            if not has_rotary:
                continue
            try:
                patched = PatchedLlamaAttention(module, getattr(model, "config", None))
                parts = name.rsplit(".", 1)
                if len(parts) == 2:
                    parent = modules_dict.get(parts[0])
                    if parent is not None:
                        setattr(parent, parts[1], patched)
                        patched_count += 1
            except Exception as e:
                print(f"[amazingvmsloth] Could not patch attention {name}: {e}")

    skipped = sum(1 for name, m in modules_dict.items()
                  if ("Attention" in type(m).__name__ or "SdpaAttention" in type(m).__name__)
                  and not hasattr(m, "rotary_emb"))

    print(f"[amazingvmsloth] Patched {patched_count} attention layers, {skipped} using native SDPA (no rotary_emb on module)")
    flash_status = "available" if _flash_available else "not available (install flash-attn for speedup)"
    xformers_status = "available" if _xformers_available else "not available (pip install xformers for speedup)"
    print(f"[amazingvmsloth] Flash attention: {flash_status}")
    print(f"[amazingvmsloth] XFormers attention: {xformers_status}")
    print(f"[amazingvmsloth] Attention implementation: {'xformers' if _xformers_available else 'SDPA'}")
    return model
