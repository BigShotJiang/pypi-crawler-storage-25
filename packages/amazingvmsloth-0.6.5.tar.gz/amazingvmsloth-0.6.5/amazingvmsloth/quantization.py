import torch
import torch.nn as nn
import gc
from typing import Optional, Dict, Any
from transformers import PreTrainedModel, BitsAndBytesConfig


def _clear_gpu_memory():
    """Clear GPU memory before loading a model."""
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        torch.cuda.ipc_collect()


def quantize_model_4bit(
    model_name_or_path: str,
    compute_dtype: torch.dtype = torch.bfloat16,
    quant_type: str = "nf4",
    use_double_quant: bool = True,
    quant_storage: torch.dtype = torch.uint8,
    device_map: Optional[Dict] = None,
    **kwargs,
) -> PreTrainedModel:
    from transformers import AutoModelForCausalLM

    _clear_gpu_memory()

    bnb_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type=quant_type,
        bnb_4bit_compute_dtype=compute_dtype,
        bnb_4bit_use_double_quant=use_double_quant,
        bnb_4bit_quant_storage=quant_storage,
    )

    if device_map is None:
        n_gpus = torch.cuda.device_count()
        if n_gpus > 1:
            device_map = "auto"
        else:
            # Use max_memory to prevent OOM during loading on small GPUs
            if torch.cuda.is_available() and "max_memory" not in kwargs:
                vram_gb = torch.cuda.get_device_properties(0).total_memory / 1024**3
                # Leave 1GB headroom for loading overhead (quantization temps)
                max_gpu_mem = int((vram_gb - 1.0) * 1024**3)
                max_gpu_mem = max(max_gpu_mem, int(0.5 * 1024**3))  # At least 0.5GB
                kwargs["max_memory"] = {0: max_gpu_mem, "cpu": "50GB"}
            device_map = {"": 0}

    print(f"[amazingvmsloth] Loading model from {model_name_or_path}...")
    try:
        model = AutoModelForCausalLM.from_pretrained(
            model_name_or_path,
            quantization_config=bnb_config,
            device_map=device_map,
            dtype=compute_dtype,
            low_cpu_mem_usage=True,
            **kwargs,
        )
    except Exception as e:
        print(f"[amazingvmsloth] Model loading failed: {e}")
        raise

    model = _prepare_model_for_kbit_training(model)
    print(f"[amazingvmsloth] Model quantized to 4-bit ({quant_type}, double_quant={use_double_quant})")
    return model


def quantize_model_8bit(
    model_name_or_path: str,
    compute_dtype: torch.dtype = torch.bfloat16,
    llm_int8_threshold: float = 6.0,
    device_map: Optional[Dict] = None,
    **kwargs,
) -> PreTrainedModel:
    _clear_gpu_memory()

    from transformers import AutoModelForCausalLM

    bnb_config = BitsAndBytesConfig(
        load_in_8bit=True,
        llm_int8_threshold=llm_int8_threshold,
    )

    if device_map is None:
        n_gpus = torch.cuda.device_count()
        if n_gpus > 1:
            device_map = "auto"
        else:
            if torch.cuda.is_available() and "max_memory" not in kwargs:
                vram_gb = torch.cuda.get_device_properties(0).total_memory / 1024**3
                max_gpu_mem = int((vram_gb - 1.0) * 1024**3)
                max_gpu_mem = max(max_gpu_mem, int(0.5 * 1024**3))
                kwargs["max_memory"] = {0: max_gpu_mem, "cpu": "50GB"}
            device_map = {"": 0}

    print(f"[amazingvmsloth] Loading model from {model_name_or_path}...")
    try:
        model = AutoModelForCausalLM.from_pretrained(
            model_name_or_path,
            quantization_config=bnb_config,
            device_map=device_map,
            dtype=compute_dtype,
            low_cpu_mem_usage=True,
            **kwargs,
        )
    except Exception as e:
        print(f"[amazingvmsloth] Model loading failed: {e}")
        raise

    model = _prepare_model_for_kbit_training(model)
    print(f"[amazingvmsloth] Model quantized to 8-bit")
    return model


def _prepare_model_for_kbit_training(model: PreTrainedModel) -> PreTrainedModel:
    # Only convert layer norm / bias params to float32 for training stability.
    # Do NOT touch 4-bit / 8-bit Linear weights — that destroys quantization.
    for name, param in model.named_parameters():
        if param.ndim == 1:
            # Norm scalars + biases → float32
            if "norm" in name.lower() or "bias" in name.lower():
                param.data = param.data.to(torch.float32)
                param.requires_grad = True
            else:
                param.requires_grad = False
        else:
            param.requires_grad = False

    # Gradient checkpointing will be enabled by the trainer — don't double-enable.
    return model


def _enable_gradient_checkpointing(model: PreTrainedModel):
    if hasattr(model, "gradient_checkpointing_enable"):
        model.gradient_checkpointing_enable(
            gradient_checkpointing_kwargs={"use_reentrant": False}
        )
    elif hasattr(model, "enable_input_require_grads"):
        model.enable_input_require_grads()

    def _make_inputs_require_grad(module, input, output):
        output.requires_grad_(True)

    if hasattr(model, "model") and hasattr(model.model, "embed_tokens"):
        model.model.embed_tokens.register_forward_hook(_make_inputs_require_grad)
    elif hasattr(model, "get_input_embeddings"):
        embed = model.get_input_embeddings()
        if embed is not None:
            embed.register_forward_hook(_make_inputs_require_grad)


def get_vram_usage() -> Dict[str, float]:
    if not torch.cuda.is_available():
        return {"total_gb": 0.0, "used_gb": 0.0, "free_gb": 0.0, "reserved_gb": 0.0}

    props = torch.cuda.get_device_properties(0)
    total_mem = getattr(props, "total_memory", getattr(props, "total_mem", 0))
    total = total_mem / 1024**3
    reserved = torch.cuda.memory_reserved(0) / 1024**3
    allocated = torch.cuda.memory_allocated(0) / 1024**3
    free = total - reserved

    return {
        "total_gb": round(total, 2),
        "used_gb": round(allocated, 2),
        "reserved_gb": round(reserved, 2),
        "free_gb": round(free, 2),
    }
