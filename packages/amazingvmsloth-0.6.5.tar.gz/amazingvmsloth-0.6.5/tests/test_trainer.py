import torch
import torch.nn as nn
from amazingvmsloth.trainer import TrainingConfig, AmazingTrainer
from amazingvmsloth.gradient import GradientAccumulator, set_gradient_requirements
from amazingvmsloth.optimizer import create_optimizer, PagedAdamW8bit, CpuOffloadedAdamW


def test_training_config_defaults():
    config = TrainingConfig()
    assert config.bf16 is True
    assert config.gradient_checkpointing is False
    assert config.optim == "paged_adamw_8bit"
    assert config.packing is True
    print("test_training_config_defaults: PASSED")


def test_gradient_accumulator():
    acc = GradientAccumulator(accumulation_steps=4)
    assert acc.should_step() is False
    assert acc.should_step() is False
    assert acc.should_step() is False
    assert acc.should_step() is True
    print("test_gradient_accumulator: PASSED")


def test_gradient_accumulator_accumulate():
    acc = GradientAccumulator(accumulation_steps=2)
    loss = torch.tensor(4.0)
    scaled = acc.accumulate(loss)
    assert abs(scaled.item() - 2.0) < 1e-5
    print("test_gradient_accumulator_accumulate: PASSED")


def test_paged_optimizer():
    model = nn.Linear(128, 64)
    opt = PagedAdamW8bit(model.parameters(), lr=1e-3)

    x = torch.randn(4, 128)
    y = model(x).sum()
    y.backward()
    opt.step()

    assert model.weight.grad is not None
    print("test_paged_optimizer: PASSED")


def test_cpu_offloaded_optimizer():
    model = nn.Linear(128, 64)
    opt = CpuOffloadedAdamW(model.parameters(), lr=1e-3)

    x = torch.randn(4, 128)
    y = model(x).sum()
    y.backward()
    opt.step()

    assert model.weight.grad is not None
    print("test_cpu_offloaded_optimizer: PASSED")


def test_create_optimizer_default():
    model = nn.Linear(128, 64)
    for p in model.parameters():
        p.requires_grad = True
    opt = create_optimizer(model, optimizer_type="adamw", lr=1e-3)
    assert isinstance(opt, torch.optim.AdamW)
    print("test_create_optimizer_default: PASSED")


def test_set_gradient_requirements():
    model = nn.Sequential(
        nn.Linear(64, 32),
        nn.Linear(32, 10),
    )
    for p in model.parameters():
        p.requires_grad = True

    model = set_gradient_requirements(model, trainable_module_names=["1"])
    assert not model[0].weight.requires_grad
    assert model[1].weight.requires_grad
    print("test_set_gradient_requirements: PASSED")


if __name__ == "__main__":
    test_training_config_defaults()
    test_gradient_accumulator()
    test_gradient_accumulator_accumulate()
    test_paged_optimizer()
    test_cpu_offloaded_optimizer()
    test_create_optimizer_default()
    test_set_gradient_requirements()
    print("\nAll trainer/optimizer tests passed!")
