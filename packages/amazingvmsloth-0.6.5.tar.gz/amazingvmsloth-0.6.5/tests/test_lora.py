import torch
import torch.nn as nn
from amazingvmsloth.lora import LoRAConfig, LoRALayer, apply_lora, get_lora_state_dict, merge_and_unload


def test_lora_config_defaults():
    config = LoRAConfig()
    assert config.r == 16
    assert config.lora_alpha == 16
    assert config.use_rslora is True
    assert config.use_manual_gradients is False
    print("test_lora_config_defaults: PASSED")


def test_lora_layer_creation():
    base = nn.Linear(512, 256)
    config = LoRAConfig(r=8, lora_alpha=8)
    layer = LoRALayer(base, config)

    assert layer.in_features == 512
    assert layer.out_features == 256
    assert "default" in layer.lora_A
    assert "default" in layer.lora_B
    assert layer.lora_A["default"].shape == (8, 512)
    assert layer.lora_B["default"].shape == (256, 8)
    print("test_lora_layer_creation: PASSED")


def test_lora_forward():
    base = nn.Linear(128, 64)
    config = LoRAConfig(r=4, lora_alpha=4, use_manual_gradients=False)
    layer = LoRALayer(base, config)
    layer.eval()

    x = torch.randn(2, 10, 128)
    base_out = base(x)

    with torch.no_grad():
        layer.lora_B["default"].fill_(0.1)
    lora_out = layer(x)

    assert lora_out.shape == base_out.shape
    assert not torch.allclose(lora_out, base_out, atol=1e-4)
    print("test_lora_forward: PASSED")


def test_lora_manual_gradients():
    base = nn.Linear(128, 64)
    config = LoRAConfig(r=4, lora_alpha=4, use_manual_gradients=True)
    layer = LoRALayer(base, config)
    layer.train()

    x = torch.randn(2, 10, 128, requires_grad=True)
    out = layer(x)
    loss = out.sum()
    loss.backward()

    assert layer.lora_A["default"].grad is not None
    assert layer.lora_B["default"].grad is not None
    print("test_lora_manual_gradients: PASSED")


def test_rslora_scaling():
    import math
    config = LoRAConfig(r=16, lora_alpha=16, use_rslora=True)
    expected_scale = 16 / math.sqrt(16)
    base = nn.Linear(128, 64)
    layer = LoRALayer(base, config)
    actual = layer.scaling["default"].item()
    assert abs(actual - expected_scale) < 1e-5
    print("test_rslora_scaling: PASSED")


def test_apply_lora_to_simple_model():
    model = nn.Sequential(
        nn.Linear(256, 128),
        nn.ReLU(),
        nn.Linear(128, 64),
    )
    config = LoRAConfig(r=8, target_modules=["0", "2"])
    model = apply_lora(model, config=config)

    lora_count = sum(1 for m in model.modules() if isinstance(m, LoRALayer))
    assert lora_count == 2
    print("test_apply_lora_to_simple_model: PASSED")


def test_lora_state_dict():
    base = nn.Linear(128, 64)
    config = LoRAConfig(r=4)
    layer = LoRALayer(base, config)

    state = {}
    for name in layer.lora_A:
        state[f"lora_A.{name}"] = layer.lora_A[name].data
        state[f"lora_B.{name}"] = layer.lora_B[name].data

    assert "lora_A.default" in state
    assert "lora_B.default" in state
    print("test_lora_state_dict: PASSED")


if __name__ == "__main__":
    test_lora_config_defaults()
    test_lora_layer_creation()
    test_lora_forward()
    test_lora_manual_gradients()
    test_rslora_scaling()
    test_apply_lora_to_simple_model()
    test_lora_state_dict()
    print("\nAll LoRA tests passed!")
