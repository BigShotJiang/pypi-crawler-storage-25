import torch
from amazingvmsloth.attention import is_flash_available, _efficient_attn, _apply_rotary_pos_emb, _repeat_kv
from amazingvmsloth.quantization import get_vram_usage
from amazingvmsloth.utils.memory import estimate_memory_requirements, garbage_collect_cuda


def test_flash_available():
    result = is_flash_available()
    assert isinstance(result, bool)
    print(f"test_flash_available: PASSED (flash={result})")


def test_repeat_kv():
    if not torch.cuda.is_available():
        print("test_repeat_kv: SKIPPED (no CUDA)")
        return

    x = torch.randn(1, 4, 10, 64, device="cuda")
    out = _repeat_kv(x, 2)
    assert out.shape == (1, 8, 10, 64)
    print("test_repeat_kv: PASSED")


def test_efficient_attn_fallback():
    if not torch.cuda.is_available():
        print("test_efficient_attn_fallback: SKIPPED (no CUDA)")
        return

    q = torch.randn(1, 8, 10, 64, device="cuda")
    k = torch.randn(1, 8, 10, 64, device="cuda")
    v = torch.randn(1, 8, 10, 64, device="cuda")
    out = _efficient_attn(q, k, v)
    assert out.shape == (1, 8, 10, 64)
    print("test_efficient_attn_fallback: PASSED")


def test_vram_usage():
    usage = get_vram_usage()
    assert "total_gb" in usage
    assert "used_gb" in usage
    print(f"test_vram_usage: PASSED ({usage})")


def test_memory_estimate():
    mem = estimate_memory_requirements(
        model_params_b=7.0,
        seq_length=2048,
        batch_size=2,
        lora_r=16,
        bits=4,
        num_gpus=1,
    )
    assert mem["total_gb"] > 0
    assert mem["per_gpu_gb"] > 0
    print(f"test_memory_estimate: PASSED (per_gpu={mem['per_gpu_gb']} GB)")


def test_garbage_collect():
    garbage_collect_cuda()
    print("test_garbage_collect: PASSED")


if __name__ == "__main__":
    test_flash_available()
    test_repeat_kv()
    test_efficient_attn_fallback()
    test_vram_usage()
    test_memory_estimate()
    test_garbage_collect()
    print("\nAll quantization/attention tests passed!")
