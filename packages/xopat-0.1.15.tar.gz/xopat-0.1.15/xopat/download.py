import os
import platform
import urllib.request
import zipfile
from pathlib import Path

GITHUB_REPO = "RationAI/xopat-deploy"
# Default binary versions. Overridden during PyPI build
# (see .github/workflows/pypi-publish.yml).
WSI_VERSION = "wsi-v1.0.2"
XOPAT_VERSION = "xopat-v1.0.6"


def get_platform():
    system = platform.system()
    if system == "Windows":
        return "windows"
    elif system == "Linux":
        return "linux"
    else:
        raise RuntimeError(f"Unsupported platform: {system}")


def is_windows():
    return get_platform() == "windows"


def get_binaries_dir():
    # On Colab, use /content/.xopat (survives kernel restart)
    if os.path.exists("/content") and "COLAB_RELEASE_TAG" in os.environ:
        return Path("/content/.xopat")
    return Path.home() / ".xopat"


def download_url(filename, tag):
    return f"https://github.com/{GITHUB_REPO}/releases/download/{tag}/{filename}"


def progress_hook(block_num, block_size, total_size):
    downloaded = block_num * block_size
    if total_size > 0:
        pct = min(100, downloaded * 100 // total_size)
        mb = downloaded / (1024 * 1024)
        total_mb = total_size / (1024 * 1024)
        if int(mb) != int((downloaded - block_size) / (1024 * 1024)) or pct == 100:
            print(f"\r  {mb:.1f}/{total_mb:.1f} MB ({pct}%)", end="", flush=True)


def download_and_extract(url, dest_dir):
    dest_dir.mkdir(parents=True, exist_ok=True)
    zip_path = dest_dir / "download.zip"
    print(f"Downloading {url}")
    urllib.request.urlretrieve(url, zip_path, reporthook=progress_hook)
    print()
    with zipfile.ZipFile(zip_path, "r") as z:
        z.extractall(dest_dir)
    zip_path.unlink()
    print("Download complete.")


def get_wsi_binary():
    plat = get_platform()
    dest = get_binaries_dir() / "wsi" / WSI_VERSION / plat
    binary_name = "wsi_service_binary.exe" if plat == "windows" else "wsi_service_binary"
    binary = dest / binary_name

    if not binary.exists():
        filename = f"wsi_service_binary_{plat}_{WSI_VERSION}.zip"
        url = download_url(filename, WSI_VERSION)
        download_and_extract(url, dest)

    if not binary.exists():
        raise FileNotFoundError(f"WSI-Service binary not found after download: {binary}")

    if plat == "linux":
        binary.chmod(0o755)

    return binary


def get_xopat_binary():
    plat = get_platform()
    dest = get_binaries_dir() / "xopat" / XOPAT_VERSION / plat
    binary_name = "xopat_binary.exe" if plat == "windows" else "xopat_binary"
    binary = dest / binary_name

    if not binary.exists():
        filename = f"xopat_{plat}_{XOPAT_VERSION}.zip"
        url = download_url(filename, XOPAT_VERSION)
        download_and_extract(url, dest)

    if not binary.exists():
        raise FileNotFoundError(f"xOpat binary not found after download: {binary}")

    if plat == "linux":
        binary.chmod(0o755)

    return binary