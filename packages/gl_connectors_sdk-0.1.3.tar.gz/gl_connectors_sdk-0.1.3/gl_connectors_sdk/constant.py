"""GLConnector Constants."""

DEFAULT_API_URL = "https://connector.gdplabs.id"
DEFAULT_SERVICE_PREFIX = "CONNECTOR"
