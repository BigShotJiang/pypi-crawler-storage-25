"""fBISG: measurement-error corrected race prediction via Gibbs sampling.

Implements the collapsed Gibbs sampler from the wru R package's ``sample_me``
C++ function.  Each sweep updates every individual's race assignment by
sampling from:

    log P(race=j | ...) = log(n_jg + N_jg + 1)
                        + log P(surname | race=j)
                        [+ log P(first | race=j)]
                        [+ log P(middle | race=j)]

where ``n_jg`` tracks current race-assignment counts per geography,
``N_jg`` is the Census count (the measurement-error piece), and the +1
acts as a uniform pseudo-count.

Posterior race probabilities are the posterior means (proportion of post-
burn-in samples assigned to each race).
"""

from __future__ import annotations

import warnings

import numpy as np
import pandas as pd

from .surnames import RACE_KEYS

_EPS = 1e-8
_N_RACES = len(RACE_KEYS)

try:
    from numba import njit

    @njit
    def _gibbs_sweep_numba(
        race_assign, geo_idx, n_rg, N_rg,
        lik_last, lik_first, lik_mid,
        use_first, use_mid,
        rng_state,
    ):
        """One Gibbs sweep over all individuals (Numba-accelerated)."""
        n = len(race_assign)
        j_range = N_rg.shape[0]
        log_probs = np.empty(j_range)

        for i in range(n):
            old_r = race_assign[i]
            g = geo_idx[i]

            n_rg[old_r, g] -= 1

            for j in range(j_range):
                log_probs[j] = np.log(n_rg[j, g] + N_rg[j, g] + 1)
                log_probs[j] += np.log(lik_last[i, j] + _EPS)
                if use_first:
                    log_probs[j] += np.log(lik_first[i, j] + _EPS)
                if use_mid:
                    log_probs[j] += np.log(lik_mid[i, j] + _EPS)

            # Log-sum-exp and sample
            max_lp = log_probs[0]
            for j in range(1, j_range):
                if log_probs[j] > max_lp:
                    max_lp = log_probs[j]
            total = 0.0
            for j in range(j_range):
                log_probs[j] = np.exp(log_probs[j] - max_lp)
                total += log_probs[j]
            for j in range(j_range):
                log_probs[j] /= total

            # Categorical sample using linear search
            u = np.random.random()
            cumsum = 0.0
            new_r = j_range - 1
            for j in range(j_range):
                cumsum += log_probs[j]
                if u < cumsum:
                    new_r = j
                    break

            race_assign[i] = new_r
            n_rg[new_r, g] += 1

    _HAS_NUMBA = True
except ImportError:
    _HAS_NUMBA = False


def _gibbs_sweep_numpy(
    race_assign: np.ndarray,
    geo_idx: np.ndarray,
    n_rg: np.ndarray,
    N_rg: np.ndarray,
    lik_last: np.ndarray,
    lik_first: np.ndarray | None,
    lik_mid: np.ndarray | None,
) -> None:
    """One Gibbs sweep over all individuals (pure NumPy)."""
    n = len(race_assign)
    log_probs = np.empty(_N_RACES)

    for i in range(n):
        old_r = race_assign[i]
        g = geo_idx[i]

        n_rg[old_r, g] -= 1

        for j in range(_N_RACES):
            log_probs[j] = np.log(n_rg[j, g] + N_rg[j, g] + 1)
            log_probs[j] += np.log(lik_last[i, j] + _EPS)
            if lik_first is not None:
                log_probs[j] += np.log(lik_first[i, j] + _EPS)
            if lik_mid is not None:
                log_probs[j] += np.log(lik_mid[i, j] + _EPS)

        # Softmax
        log_probs -= log_probs.max()
        probs = np.exp(log_probs)
        probs /= probs.sum()

        # Sample
        new_r = np.searchsorted(np.cumsum(probs), np.random.random())
        new_r = min(new_r, _N_RACES - 1)

        race_assign[i] = new_r
        n_rg[new_r, g] += 1


def _run_gibbs(
    N_rg: np.ndarray,
    lik_last: np.ndarray,
    lik_first: np.ndarray | None,
    lik_mid: np.ndarray | None,
    geo_idx: np.ndarray,
    race_init: np.ndarray,
    n_samples: int,
    burnin: int,
) -> np.ndarray:
    """Run the fBISG Gibbs sampler.

    Returns an (N, 5) array of posterior race probabilities.
    """
    n = len(race_init)
    n_geos = N_rg.shape[1]

    race_assign = race_init.copy()

    # Initialize n_rg from current assignments
    n_rg = np.zeros((_N_RACES, n_geos), dtype=np.float64)
    for i in range(n):
        n_rg[race_assign[i], geo_idx[i]] += 1

    # Accumulator for posterior
    race_counts = np.zeros((n, _N_RACES), dtype=np.float64)

    total_sweeps = burnin + n_samples
    use_numba = _HAS_NUMBA and n > 1000

    for sweep in range(total_sweeps):
        if use_numba:
            _gibbs_sweep_numba(
                race_assign, geo_idx, n_rg, N_rg,
                lik_last,
                lik_first if lik_first is not None else np.zeros((n, _N_RACES)),
                lik_mid if lik_mid is not None else np.zeros((n, _N_RACES)),
                lik_first is not None,
                lik_mid is not None,
                0,
            )
        else:
            _gibbs_sweep_numpy(
                race_assign, geo_idx, n_rg, N_rg,
                lik_last, lik_first, lik_mid,
            )

        if sweep >= burnin:
            for i in range(n):
                race_counts[i, race_assign[i]] += 1

    # Posterior means
    posteriors = race_counts / n_samples
    return posteriors


def predict_race_me(
    df: pd.DataFrame,
    census_df: pd.DataFrame,
    geo_merge_keys: list[str],
    geo_col_map: dict[str, str],
    first_name_col: str | None = None,
    middle_name_col: str | None = None,
    n_samples: int = 1000,
    burnin: int = 200,
) -> pd.DataFrame:
    """fBISG prediction using the Gibbs sampler.

    Parameters
    ----------
    df : DataFrame
        Voter file with name likelihoods (``lik_whi`` ... ``lik_oth``)
        already merged.
    census_df : DataFrame
        Census data with geographic identifiers and ``r_whi`` ... ``r_oth``.
    geo_merge_keys : list of str
        Census column names for geographic merge.
    geo_col_map : dict
        Mapping from Census geo names to voter file column names.
    first_name_col, middle_name_col : str or None
        First/middle name columns (likelihoods must already be in df).
    n_samples, burnin : int
        MCMC parameters.

    Returns
    -------
    DataFrame
        df with ``pred_whi`` ... ``pred_oth`` columns added.
    """
    from .fips import state_to_fips

    result = df.copy()

    # --- Build N_rg: Census race counts by geography ---
    # Get raw counts from census_df (before normalization)
    # We need to re-download or reconstruct counts; for now use proportions
    # scaled by a pseudo-count as the R package does
    r_cols = [f"r_{k}" for k in RACE_KEYS]

    # Map each voter to a geo index
    # Build a combined geo key for both census and voter file
    pad_widths = {"county": 3, "tract": 6, "block_group": 1, "block": 4, "place": 5, "zcta": 5}

    def _make_geo_key(frame, col_map, is_census=False):
        parts = []
        for gk in geo_merge_keys:
            if is_census:
                col = gk
            else:
                col = col_map[gk]
            vals = frame[col].astype(str).str.strip()
            if gk == "state" and not is_census:
                vals = vals.str.upper().map(lambda s: state_to_fips(s) if len(s) == 2 else s)
            if gk in pad_widths:
                vals = vals.str.zfill(pad_widths[gk])
            if is_census and gk == "state":
                vals = vals.str.zfill(2)
            parts.append(vals)
        return parts[0].str.cat(parts[1:], sep="_")

    census_geo_key = _make_geo_key(census_df, geo_col_map, is_census=True)
    voter_geo_key = _make_geo_key(result, geo_col_map, is_census=False)

    # Build unique geo index
    unique_geos = census_geo_key.unique()
    geo_to_idx = {g: i for i, g in enumerate(unique_geos)}
    n_geos = len(unique_geos)

    geo_idx = voter_geo_key.map(geo_to_idx).values
    valid_geo = ~pd.isna(voter_geo_key.map(geo_to_idx))
    if not valid_geo.all():
        warnings.warn(
            f"fBISG: {(~valid_geo).sum()} rows have unmatched geography; "
            "falling back to BISG for those rows"
        )
        geo_idx = np.where(valid_geo, geo_idx, 0).astype(int)

    # Build N_rg matrix (5 races × n_geos) from census proportions
    # Use proportions × 1000 as pseudo-counts (similar to Census total pop)
    N_rg = np.zeros((_N_RACES, n_geos), dtype=np.float64)
    for i, gk in enumerate(unique_geos):
        mask = census_geo_key == gk
        if mask.any():
            row = census_df.loc[mask].iloc[0]
            for j, key in enumerate(RACE_KEYS):
                # Scale proportions to approximate counts
                N_rg[j, i] = row[f"r_{key}"] * 1000.0

    # Build likelihood matrices
    lik_last = np.column_stack([result[f"lik_{k}"].fillna(1.0).values for k in RACE_KEYS])

    lik_first = None
    if first_name_col and f"lik_first_{RACE_KEYS[0]}" in result.columns:
        lik_first = np.column_stack([
            result[f"lik_first_{k}"].fillna(1.0).values for k in RACE_KEYS
        ])

    lik_mid = None
    if middle_name_col and f"lik_mid_{RACE_KEYS[0]}" in result.columns:
        lik_mid = np.column_stack([
            result[f"lik_mid_{k}"].fillna(1.0).values for k in RACE_KEYS
        ])

    # Initialize race from max likelihood
    init_probs = lik_last.copy()
    for j, key in enumerate(RACE_KEYS):
        init_probs[:, j] *= np.array([N_rg[j, g] for g in geo_idx])
    race_init = init_probs.argmax(axis=1).astype(np.int32)

    # Run Gibbs
    posteriors = _run_gibbs(
        N_rg, lik_last, lik_first, lik_mid,
        geo_idx.astype(np.int32), race_init,
        n_samples=n_samples, burnin=burnin,
    )

    for j, key in enumerate(RACE_KEYS):
        result[f"pred_{key}"] = posteriors[:, j]

    return result
