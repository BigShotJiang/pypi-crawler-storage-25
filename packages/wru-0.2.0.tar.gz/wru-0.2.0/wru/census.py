"""Census API client for downloading race demographics by geography."""

from __future__ import annotations

import os
import time
import warnings
from pathlib import Path
from typing import Literal

import pandas as pd
import requests

from .fips import state_to_fips
from .surnames import RACE_KEYS

GeoLevel = Literal["county", "tract", "block_group", "block", "place", "zcta"]

_API_BASE = {
    2020: "https://api.census.gov/data/2020/dec/pl",
    2010: "https://api.census.gov/data/2010/dec/sf1",
}

_API_BASE_DHC = {
    2020: "https://api.census.gov/data/2020/dec/dhc",
}

# 2020 PL (redistricting) table P2: Hispanic Origin by Race
_VARS_2020: dict[str, list[str]] = {
    "whi": ["P2_005N"],                          # Not Hispanic, White alone
    "bla": ["P2_006N"],                          # Not Hispanic, Black alone
    "his": ["P2_002N"],                          # Hispanic or Latino
    "asi": ["P2_008N", "P2_009N"],               # Asian + NHPI
    "oth": ["P2_007N", "P2_010N", "P2_011N"],   # AIAN + SOR + Two+
}

# 2020 DHC table P11: Hispanic Origin by Race (used for ZCTA queries)
_VARS_2020_DHC: dict[str, list[str]] = {
    "whi": ["P11_005N"],
    "bla": ["P11_006N"],
    "his": ["P11_002N"],
    "asi": ["P11_008N", "P11_009N"],
    "oth": ["P11_007N", "P11_010N", "P11_011N"],
}

# 2010 SF1 table P5/P4 (P005/P004): Hispanic Origin by Race
_VARS_2010: dict[str, list[str]] = {
    "whi": ["P005003"],
    "bla": ["P005004"],
    "his": ["P004003"],
    "asi": ["P005006", "P005007"],
    "oth": ["P005005", "P005008", "P005009"],
}

_GEO_HIERARCHY: dict[str, list[str]] = {
    "county":      ["state", "county"],
    "tract":       ["state", "county", "tract"],
    "block_group": ["state", "county", "tract", "block group"],
    "block":       ["state", "county", "tract", "block"],
    "place":       ["state", "place"],
    "zcta":        ["state", "zip code tabulation area (or part)"],
}

_CACHE_DIR = Path(os.environ.get("WRU_CACHE_DIR", Path.home() / ".cache" / "wru"))


def _all_census_vars(year: int, use_dhc: bool = False) -> list[str]:
    if use_dhc:
        var_map = _VARS_2020_DHC
    else:
        var_map = _VARS_2020 if year == 2020 else _VARS_2010
    seen: list[str] = []
    for vlist in var_map.values():
        for v in vlist:
            if v not in seen:
                seen.append(v)
    return seen


def _build_api_url(
    state_fips: str,
    geo: GeoLevel,
    year: int,
    census_key: str | None,
) -> str:
    use_dhc = geo == "zcta"
    base = _API_BASE_DHC[year] if use_dhc else _API_BASE[year]
    variables = ",".join(_all_census_vars(year, use_dhc=use_dhc))

    geo_api_name = {
        "county": "county",
        "tract": "tract",
        "block_group": "block group",
        "block": "block",
        "place": "place",
        "zcta": "zip code tabulation area (or part)",
    }[geo]

    url = f"{base}?get={variables}&for={geo_api_name}:*&in=state:{state_fips}"

    if geo in ("tract", "block_group", "block"):
        url = f"{base}?get={variables}&for={geo_api_name}:*&in=state:{state_fips}&in=county:*"
    if geo in ("block_group", "block"):
        url = f"{base}?get={variables}&for={geo_api_name}:*&in=state:{state_fips}&in=county:*&in=tract:*"

    if census_key:
        url += f"&key={census_key}"

    return url


def _fetch_census_json(url: str, max_retries: int = 3, timeout: int = 300) -> list[list[str]]:
    for attempt in range(max_retries):
        try:
            resp = requests.get(url, timeout=timeout)
            resp.raise_for_status()
            return resp.json()
        except (requests.RequestException, ValueError) as e:
            if attempt == max_retries - 1:
                raise RuntimeError(f"Census API request failed after {max_retries} attempts: {e}") from e
            time.sleep(2 ** attempt)
    return []


def census_geo_api(
    state: str,
    geo: GeoLevel = "tract",
    year: int = 2020,
    census_key: str | None = None,
    cache: bool = True,
) -> pd.DataFrame:
    """Download Census race demographics for a given state and geography level.

    Returns a DataFrame with geographic identifiers and ``r_whi`` ... ``r_oth``
    columns representing P(race | geography).

    Parameters
    ----------
    state : str
        Two-letter state abbreviation (e.g. "NJ").
    geo : str
        Geographic level: "county", "tract", "block_group", "block", or "place".
    year : int
        Census year (2020 or 2010).
    census_key : str or None
        Census API key. If None, reads from CENSUS_API_KEY env var.
    cache : bool
        Cache downloaded data to disk as parquet files.
    """
    state = state.upper()
    fips = state_to_fips(state)
    key = census_key or os.environ.get("CENSUS_API_KEY")

    if year not in _API_BASE:
        raise ValueError(f"Unsupported census year: {year}. Use 2020 or 2010.")

    cache_path = _CACHE_DIR / f"census_{year}_{state}_{geo}.parquet"
    if cache and cache_path.exists():
        return pd.read_parquet(cache_path)

    url = _build_api_url(fips, geo, year, key)
    data = _fetch_census_json(url)

    if len(data) < 2:
        warnings.warn(f"No census data returned for state={state}, geo={geo}, year={year}")
        return pd.DataFrame()

    header = data[0]
    rows = data[1:]
    df = pd.DataFrame(rows, columns=header)

    use_dhc = geo == "zcta"
    var_map = _VARS_2020_DHC if use_dhc else (_VARS_2020 if year == 2020 else _VARS_2010)
    all_vars = _all_census_vars(year, use_dhc=use_dhc)
    for v in all_vars:
        df[v] = pd.to_numeric(df[v], errors="coerce").fillna(0).astype(int)

    for race_key, var_list in var_map.items():
        df[f"r_{race_key}"] = sum(df[v] for v in var_list).astype(float)

    # Normalize to get P(race | geo)
    r_cols = [f"r_{k}" for k in RACE_KEYS]
    total = df[r_cols].sum(axis=1).clip(lower=1)
    for col in r_cols:
        df[col] = df[col] / total

    # Standardize geo column names
    rename_map = {
        "block group": "block_group",
        "zip code tabulation area (or part)": "zcta",
    }
    df = df.rename(columns=rename_map)

    # Keep only geo identifiers and race proportions
    geo_cols = [c for c in ["state", "county", "tract", "block_group", "block", "place", "zcta"] if c in df.columns]
    df = df[geo_cols + r_cols].copy()

    if cache:
        _CACHE_DIR.mkdir(parents=True, exist_ok=True)
        df.to_parquet(cache_path, index=False)

    return df


def get_census_data(
    states: str | list[str],
    geo: GeoLevel = "tract",
    year: int = 2020,
    census_key: str | None = None,
    cache: bool = True,
) -> dict[str, pd.DataFrame]:
    """Download Census geographic race data for one or more states.

    Returns a dict mapping state abbreviation -> DataFrame of geographic
    race proportions.

    Parameters
    ----------
    states : str or list of str
        State abbreviation(s).
    geo : str
        Geographic level.
    year : int
        Census year.
    census_key : str or None
        Census API key.
    cache : bool
        Cache to disk.
    """
    if isinstance(states, str):
        states = [states]

    result = {}
    for st in states:
        st = st.upper()
        result[st] = census_geo_api(st, geo=geo, year=year, census_key=census_key, cache=cache)

    return result


# ---------------------------------------------------------------------------
# DHC P12 age/sex data
# ---------------------------------------------------------------------------

# 2020 DHC P12 race table prefixes -> wru race keys
_P12_RACE_TABLES: dict[str, list[str]] = {
    "whi": ["P12I"],            # White alone, not Hispanic
    "bla": ["P12J"],            # Black alone, not Hispanic
    "his": ["P12H"],            # Hispanic or Latino
    "asi": ["P12L", "P12M"],    # Asian + NHPI, not Hispanic
    "oth": ["P12K", "P12N", "P12O"],  # AIAN + Other + Two+, not Hispanic
}

# Age bin boundaries matching Census P12 age groups (23 bins)
_AGE_BINS = [
    (0, 4), (5, 9), (10, 14), (15, 17), (18, 19),
    (20, 20), (21, 21), (22, 24), (25, 29), (30, 34),
    (35, 39), (40, 44), (45, 49), (50, 54), (55, 59),
    (60, 61), (62, 64), (65, 66), (67, 69), (70, 74),
    (75, 79), (80, 84), (85, 199),
]

# Male age cells: 003-025 (23 cells), Female age cells: 027-049 (23 cells)
_MALE_CELLS = [f"{i:03d}" for i in range(3, 26)]
_FEMALE_CELLS = [f"{i:03d}" for i in range(27, 50)]


def age_to_bin(age: int) -> int:
    """Convert integer age to Census P12 age bin index (1-23). Returns 0 if invalid."""
    if not isinstance(age, (int, float)) or pd.isna(age):
        return 0
    age = int(age)
    for i, (lo, hi) in enumerate(_AGE_BINS):
        if lo <= age <= hi:
            return i + 1
    return 0


def _build_p12_vars(age: bool, sex: bool) -> list[str]:
    """Build the list of DHC P12 variables needed for age/sex conditioning."""
    var_list = []
    for race_key, prefixes in _P12_RACE_TABLES.items():
        for prefix in prefixes:
            var_list.append(f"{prefix}_001N")  # total
            if sex or age:
                var_list.append(f"{prefix}_002N")  # male total
                var_list.append(f"{prefix}_026N")  # female total
            if age:
                for cell in _MALE_CELLS + _FEMALE_CELLS:
                    var_list.append(f"{prefix}_{cell}N")
    return var_list


def _build_dhc_api_url(
    state_fips: str,
    geo: GeoLevel,
    year: int,
    variables: list[str],
    census_key: str | None,
) -> list[str]:
    """Build DHC API URLs, chunking variables to stay under API limits."""
    base = _API_BASE_DHC[year]
    geo_api_name = {
        "county": "county", "tract": "tract", "block_group": "block group",
        "block": "block", "place": "place",
        "zcta": "zip code tabulation area (or part)",
    }[geo]

    geo_clause = f"for={geo_api_name}:*&in=state:{state_fips}"
    if geo in ("tract", "block_group", "block"):
        geo_clause = f"for={geo_api_name}:*&in=state:{state_fips}&in=county:*"
    if geo in ("block_group", "block"):
        geo_clause = f"for={geo_api_name}:*&in=state:{state_fips}&in=county:*&in=tract:*"

    key_clause = f"&key={census_key}" if census_key else ""

    # Census API has a ~50 variable limit per request
    chunk_size = 48
    urls = []
    for i in range(0, len(variables), chunk_size):
        chunk = variables[i:i + chunk_size]
        url = f"{base}?get={','.join(chunk)}&{geo_clause}{key_clause}"
        urls.append(url)
    return urls


def census_geo_api_dhc(
    state: str,
    geo: GeoLevel = "tract",
    year: int = 2020,
    age: bool = True,
    sex: bool = True,
    census_key: str | None = None,
    cache: bool = True,
) -> pd.DataFrame:
    """Download DHC P12 age/sex/race data for a state.

    Returns a DataFrame with geographic identifiers and race proportion
    columns for each age/sex combination: ``r_{agebin}_{sex}_{race}``.

    Parameters
    ----------
    state : str
        Two-letter state abbreviation.
    geo : str
        Geographic level.
    year : int
        Census year (2020 only for DHC).
    age : bool
        Include age conditioning.
    sex : bool
        Include sex conditioning.
    census_key : str or None
        Census API key.
    cache : bool
        Cache to disk.
    """
    state = state.upper()
    fips = state_to_fips(state)
    key = census_key or os.environ.get("CENSUS_API_KEY")

    if year not in _API_BASE_DHC:
        raise ValueError(f"DHC data only available for year 2020, got {year}")

    suffix = f"_age{int(age)}_sex{int(sex)}"
    cache_path = _CACHE_DIR / f"census_dhc_{year}_{state}_{geo}{suffix}.parquet"
    if cache and cache_path.exists():
        return pd.read_parquet(cache_path)

    all_vars = _build_p12_vars(age, sex)
    urls = _build_dhc_api_url(fips, geo, year, all_vars, key)

    # Fetch all chunks and merge on geo columns
    merged_df = None
    for url in urls:
        data = _fetch_census_json(url)
        if len(data) < 2:
            continue
        chunk_df = pd.DataFrame(data[1:], columns=data[0])
        if merged_df is None:
            merged_df = chunk_df
        else:
            geo_cols = [c for c in merged_df.columns if not c.startswith("P12")]
            merged_df = merged_df.merge(chunk_df, on=list(geo_cols), how="outer")

    if merged_df is None or merged_df.empty:
        warnings.warn(f"No DHC data returned for state={state}, geo={geo}")
        return pd.DataFrame()

    df = merged_df

    # Convert all P12 columns to numeric
    for col in df.columns:
        if col.startswith("P12"):
            df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0).astype(int)

    # Standardize geo column names
    rename_map = {
        "block group": "block_group",
        "zip code tabulation area (or part)": "zcta",
    }
    df = df.rename(columns=rename_map)

    # Build race proportion columns for each age/sex combination
    if age and sex:
        _build_age_sex_cols(df)
    elif age:
        _build_age_only_cols(df)
    elif sex:
        _build_sex_only_cols(df)
    else:
        _build_marginal_cols(df)

    # Keep geo + r_ columns
    geo_cols = [c for c in ["state", "county", "tract", "block_group", "block", "place", "zcta"] if c in df.columns]
    r_cols = [c for c in df.columns if c.startswith("r_")]
    df = df[geo_cols + r_cols].copy()

    if cache:
        _CACHE_DIR.mkdir(parents=True, exist_ok=True)
        df.to_parquet(cache_path, index=False)

    return df


def _race_total(df: pd.DataFrame, race_key: str) -> pd.Series:
    """Sum the _001N (total) columns for a race group."""
    prefixes = _P12_RACE_TABLES[race_key]
    return sum(df[f"{p}_001N"] for p in prefixes).astype(float)


def _race_cell(df: pd.DataFrame, race_key: str, cell: str) -> pd.Series:
    """Sum a specific cell across prefixes for a race group."""
    prefixes = _P12_RACE_TABLES[race_key]
    total = pd.Series(0, index=df.index, dtype=float)
    for p in prefixes:
        col = f"{p}_{cell}N"
        if col in df.columns:
            total = total + df[col].astype(float)
    return total


def _build_age_sex_cols(df: pd.DataFrame) -> None:
    """Build r_{agebin}_{sex}_{race} columns."""
    new_cols = {}
    for race_key in RACE_KEYS:
        denom = _race_total(df, race_key).clip(lower=1)
        for age_idx in range(23):
            ab = age_idx + 1
            new_cols[f"r_{ab}_0_{race_key}"] = _race_cell(df, race_key, _MALE_CELLS[age_idx]) / denom
            new_cols[f"r_{ab}_1_{race_key}"] = _race_cell(df, race_key, _FEMALE_CELLS[age_idx]) / denom
    new_df = pd.DataFrame(new_cols, index=df.index)
    for col in new_df.columns:
        df[col] = new_df[col]


def _build_age_only_cols(df: pd.DataFrame) -> None:
    """Build r_{agebin}_{race} columns (summing male+female)."""
    new_cols = {}
    for race_key in RACE_KEYS:
        denom = _race_total(df, race_key).clip(lower=1)
        for age_idx in range(23):
            ab = age_idx + 1
            m = _race_cell(df, race_key, _MALE_CELLS[age_idx])
            f = _race_cell(df, race_key, _FEMALE_CELLS[age_idx])
            new_cols[f"r_{ab}_{race_key}"] = (m + f) / denom
    new_df = pd.DataFrame(new_cols, index=df.index)
    for col in new_df.columns:
        df[col] = new_df[col]


def _build_sex_only_cols(df: pd.DataFrame) -> None:
    """Build r_0_{race} (male) and r_1_{race} (female) columns."""
    for race_key in RACE_KEYS:
        denom = _race_total(df, race_key).clip(lower=1)
        df[f"r_0_{race_key}"] = _race_cell(df, race_key, "002") / denom  # male total
        df[f"r_1_{race_key}"] = _race_cell(df, race_key, "026") / denom  # female total


def _build_marginal_cols(df: pd.DataFrame) -> None:
    """Build simple r_{race} columns (no age/sex)."""
    r_cols = [f"r_{k}" for k in RACE_KEYS]
    for race_key in RACE_KEYS:
        df[f"r_{race_key}"] = _race_total(df, race_key)
    total = df[r_cols].sum(axis=1).clip(lower=1)
    for col in r_cols:
        df[col] = df[col] / total


def get_census_data_dhc(
    states: str | list[str],
    geo: GeoLevel = "tract",
    year: int = 2020,
    age: bool = True,
    sex: bool = True,
    census_key: str | None = None,
    cache: bool = True,
) -> dict[str, pd.DataFrame]:
    """Download DHC age/sex/race data for one or more states."""
    if isinstance(states, str):
        states = [states]
    result = {}
    for st in states:
        st = st.upper()
        result[st] = census_geo_api_dhc(
            st, geo=geo, year=year, age=age, sex=sex,
            census_key=census_key, cache=cache,
        )
    return result
