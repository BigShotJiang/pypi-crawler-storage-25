"""Core BISG / BIFSG race prediction."""

from __future__ import annotations

import os
import warnings
from typing import Literal

import numpy as np
import pandas as pd

from .census import GeoLevel, census_geo_api, get_census_data
from .surnames import RACE_KEYS, merge_names, merge_surnames

# Default P(party | race) from Pew Research / voter registration studies.
# Rows: party (0=other, 1=Dem, 2=Rep). Cols: whi, bla, his, asi, oth.
_DEFAULT_PARTY_PRIORS = pd.DataFrame(
    {
        "r_pid_whi": [0.34, 0.26, 0.40],
        "r_pid_bla": [0.12, 0.80, 0.08],
        "r_pid_his": [0.27, 0.48, 0.25],
        "r_pid_asi": [0.30, 0.47, 0.23],
        "r_pid_oth": [0.36, 0.38, 0.26],
    },
    index=[0, 1, 2],
)
_DEFAULT_PARTY_PRIORS.index.name = "PID"


def predict_race(
    voter_file: pd.DataFrame,
    surname_col: str = "surname",
    first_name_col: str | None = None,
    middle_name_col: str | None = None,
    census_geo: GeoLevel | None = None,
    census_data: dict[str, pd.DataFrame] | None = None,
    census_key: str | None = None,
    census_year: int = 2020,
    surname_year: int = 2010,
    surname_only: bool = False,
    state_col: str = "state",
    county_col: str = "county",
    tract_col: str = "tract",
    block_group_col: str = "block_group",
    block_col: str = "block",
    place_col: str = "place",
    zcta_col: str = "zcta",
    age_col: str | None = None,
    sex_col: str | None = None,
    party_col: str | None = None,
    party_data: pd.DataFrame | None = None,
    use_wru_names: bool = True,
    impute_missing: bool = True,
    cache: bool = True,
    method: Literal["bisg", "fbisg"] = "bisg",
    n_samples: int = 1000,
    burnin: int = 200,
) -> pd.DataFrame:
    """Predict race/ethnicity using BISG or BIFSG.

    Computes posterior race probabilities via Bayes' rule::

        P(race | names, geo [, age, sex, party]) ∝
            P(last|race) [× P(first|race)] [× P(middle|race)]
            × P(race | geo [, age, sex])
            [× P(party | race)]

    Parameters
    ----------
    voter_file : DataFrame
        Input data with name and (optionally) geographic columns.
    surname_col : str
        Column with last names.
    first_name_col, middle_name_col : str or None
        Columns with first / middle names for BIFSG.
    census_geo : str or None
        Geographic level: "county", "tract", "block_group", "block",
        "place", or "zcta".
    census_data : dict or None
        Pre-downloaded Census data from :func:`get_census_data`.
    census_key : str or None
        Census API key (or ``CENSUS_API_KEY`` env var).
    census_year : int
        Census year (2020 or 2010).
    surname_year : int
        Census surname list year (only used when ``use_wru_names=False``).
    surname_only : bool
        Predict from names alone, no geography.
    state_col ... zcta_col : str
        Column names for geographic identifiers.
    age_col : str or None
        Column with integer ages for age conditioning (requires DHC data).
    sex_col : str or None
        Column with sex codes (0=male, 1=female) for sex conditioning.
    party_col : str or None
        Column with party ID (0=other, 1=Dem, 2=Rep) for party conditioning.
    party_data : DataFrame or None
        Custom P(party|race) table. Index = party codes, columns =
        ``r_pid_whi`` ... ``r_pid_oth``. Uses built-in Pew-based table
        if None.
    use_wru_names : bool
        Use the wru augmented name dictionaries (requires ``pyreadr``
        for first download).
    impute_missing : bool
        Impute unmatched names with column means.
    cache : bool
        Cache Census data to disk.
    method : str
        ``"bisg"`` for standard BISG/BIFSG, ``"fbisg"`` for the
        measurement-error Gibbs sampler.
    n_samples, burnin : int
        MCMC parameters for ``method="fbisg"``.

    Returns
    -------
    DataFrame
        Copy of voter_file with ``pred_whi`` ... ``pred_oth`` columns.
    """
    # --- Name likelihoods ---
    if use_wru_names and (first_name_col or middle_name_col):
        df = merge_names(
            voter_file,
            surname_col=surname_col,
            first_name_col=first_name_col,
            middle_name_col=middle_name_col,
            use_wru_names=True,
            impute_missing=impute_missing,
        )
    elif use_wru_names:
        try:
            df = merge_names(
                voter_file,
                surname_col=surname_col,
                use_wru_names=True,
                impute_missing=impute_missing,
            )
        except ImportError:
            df = merge_surnames(voter_file, surname_col=surname_col, year=surname_year, impute_missing=impute_missing)
    else:
        df = merge_surnames(voter_file, surname_col=surname_col, year=surname_year, impute_missing=impute_missing)

    if surname_only:
        for key in RACE_KEYS:
            df[f"pred_{key}"] = df[f"pred_{key}_surname"]
        _cleanup_internal_cols(df)
        return df

    if census_geo is None:
        raise ValueError("census_geo is required when surname_only=False")

    # --- Geographic data ---
    geo_col_map = {
        "state": state_col,
        "county": county_col,
        "tract": tract_col,
        "block_group": block_group_col,
        "block": block_col,
        "place": place_col,
        "zcta": zcta_col,
    }
    geo_merge_keys = _geo_merge_keys(census_geo)

    need_dhc = age_col is not None or sex_col is not None
    if need_dhc:
        census_df = _get_dhc_census_for_voter_file(
            df, census_geo, census_data, census_key, census_year,
            state_col, geo_col_map, geo_merge_keys, age_col, sex_col, cache,
        )
    else:
        census_df = _get_census_for_voter_file(
            df, census_geo, census_data, census_key, census_year,
            state_col, geo_col_map, geo_merge_keys, cache,
        )

    if census_df.empty:
        warnings.warn("No census data available; falling back to name-only predictions")
        for key in RACE_KEYS:
            df[f"pred_{key}"] = df[f"pred_{key}_surname"]
        _cleanup_internal_cols(df)
        return df

    # --- fBISG Gibbs sampler ---
    if method == "fbisg":
        from .gibbs import predict_race_me
        result = predict_race_me(
            df, census_df, geo_merge_keys, geo_col_map,
            first_name_col=first_name_col,
            middle_name_col=middle_name_col,
            n_samples=n_samples,
            burnin=burnin,
        )
        _cleanup_internal_cols(result)
        return result

    # --- Merge geo data ---
    if need_dhc:
        df = _merge_dhc_geo_data(df, census_df, geo_col_map, geo_merge_keys, age_col, sex_col)
    else:
        df = _merge_geo_data(df, census_df, geo_col_map, geo_merge_keys)

    # --- Party conditioning ---
    if party_col is not None:
        pid_table = party_data if party_data is not None else _DEFAULT_PARTY_PRIORS
        df = _merge_party(df, party_col, pid_table)

    # --- BISG: unnormalized posterior ---
    for key in RACE_KEYS:
        df[f"_unnorm_{key}"] = df[f"lik_{key}"] * df[f"r_{key}"]
        if f"r_pid_{key}" in df.columns:
            df[f"_unnorm_{key}"] = df[f"_unnorm_{key}"] * df[f"r_pid_{key}"]

    unnorm_cols = [f"_unnorm_{k}" for k in RACE_KEYS]
    total = df[unnorm_cols].sum(axis=1).clip(lower=1e-12)
    for key in RACE_KEYS:
        df[f"pred_{key}"] = df[f"_unnorm_{key}"] / total

    # Fall back to name-only for rows with no geo match
    no_geo = df[[f"r_{k}" for k in RACE_KEYS]].isna().all(axis=1)
    if no_geo.any():
        for key in RACE_KEYS:
            df.loc[no_geo, f"pred_{key}"] = df.loc[no_geo, f"pred_{key}_surname"]

    _cleanup_internal_cols(df)
    return df


# ---------------------------------------------------------------------------
# Geography helpers
# ---------------------------------------------------------------------------

def _geo_merge_keys(census_geo: str) -> list[str]:
    mapping = {
        "county":      ["state", "county"],
        "tract":       ["state", "county", "tract"],
        "block_group": ["state", "county", "tract", "block_group"],
        "block":       ["state", "county", "tract", "block"],
        "place":       ["state", "place"],
        "zcta":        ["state", "zcta"],
    }
    return mapping[census_geo]


def _get_census_for_voter_file(
    df, census_geo, census_data, census_key, census_year,
    state_col, geo_col_map, geo_merge_keys, cache,
):
    states = df[state_col].dropna().str.upper().unique().tolist()

    if census_data is not None:
        frames = []
        for st in states:
            if st in census_data:
                frames.append(census_data[st])
            else:
                warnings.warn(f"No pre-downloaded census data for state {st}")
        return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()

    key = census_key or os.environ.get("CENSUS_API_KEY")
    data = get_census_data(states, geo=census_geo, year=census_year, census_key=key, cache=cache)
    frames = [v for v in data.values() if not v.empty]
    return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()


def _get_dhc_census_for_voter_file(
    df, census_geo, census_data, census_key, census_year,
    state_col, geo_col_map, geo_merge_keys, age_col, sex_col, cache,
):
    """Download DHC P12 age/sex data for states in the voter file."""
    from .census import get_census_data_dhc
    states = df[state_col].dropna().str.upper().unique().tolist()

    if census_data is not None:
        frames = []
        for st in states:
            if st in census_data:
                frames.append(census_data[st])
        return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()

    key = census_key or os.environ.get("CENSUS_API_KEY")
    data = get_census_data_dhc(
        states, geo=census_geo, year=census_year,
        age=age_col is not None, sex=sex_col is not None,
        census_key=key, cache=cache,
    )
    frames = [v for v in data.values() if not v.empty]
    return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()


def _merge_geo_data(df, census_df, geo_col_map, geo_merge_keys):
    from .fips import state_to_fips

    df = df.copy()
    for census_key in geo_merge_keys:
        voter_col = geo_col_map[census_key]
        if voter_col not in df.columns:
            raise ValueError(
                f"Column {voter_col!r} not found in voter file "
                f"(needed for census_geo merge on {census_key!r})"
            )
        df[f"_merge_{census_key}"] = df[voter_col].astype(str).str.strip()

    if "state" in geo_merge_keys:
        df["_merge_state"] = df["_merge_state"].str.upper().map(
            lambda s: state_to_fips(s) if len(s) == 2 else s
        )

    pad_widths = {"county": 3, "tract": 6, "block_group": 1, "block": 4, "place": 5, "zcta": 5}
    for key in geo_merge_keys:
        if key in pad_widths:
            width = pad_widths[key]
            df[f"_merge_{key}"] = df[f"_merge_{key}"].str.zfill(width)
            census_df[key] = census_df[key].astype(str).str.zfill(width)

    census_df["state"] = census_df["state"].astype(str).str.zfill(2)

    merge_left = [f"_merge_{k}" for k in geo_merge_keys]
    merge_right = geo_merge_keys

    r_cols = [f"r_{k}" for k in RACE_KEYS]
    df = df.merge(
        census_df[merge_right + r_cols],
        left_on=merge_left, right_on=merge_right,
        how="left", suffixes=("", "_census"),
    )

    for k in geo_merge_keys:
        for suffix in ["", "_census"]:
            col = f"_merge_{k}" if not suffix else f"{k}_census"
            if col in df.columns:
                df = df.drop(columns=[col])

    return df


def _merge_dhc_geo_data(df, census_df, geo_col_map, geo_merge_keys, age_col, sex_col):
    """Merge DHC age/sex-specific race data, picking the right r_* for each row."""
    from .census import age_to_bin
    from .fips import state_to_fips

    df = df.copy()

    # Build age bin column
    if age_col and age_col in df.columns:
        df["_agecat"] = df[age_col].apply(age_to_bin)
    else:
        df["_agecat"] = 0

    # Build sex column
    if sex_col and sex_col in df.columns:
        df["_sex"] = df[sex_col].astype(int)
    else:
        df["_sex"] = -1

    # Build merge keys
    for census_key in geo_merge_keys:
        voter_col = geo_col_map[census_key]
        if voter_col not in df.columns:
            raise ValueError(f"Column {voter_col!r} not found in voter file")
        df[f"_merge_{census_key}"] = df[voter_col].astype(str).str.strip()

    if "state" in geo_merge_keys:
        df["_merge_state"] = df["_merge_state"].str.upper().map(
            lambda s: state_to_fips(s) if len(s) == 2 else s
        )

    pad_widths = {"county": 3, "tract": 6, "block_group": 1, "block": 4, "place": 5, "zcta": 5}
    for key in geo_merge_keys:
        if key in pad_widths:
            width = pad_widths[key]
            df[f"_merge_{key}"] = df[f"_merge_{key}"].str.zfill(width)
            census_df[key] = census_df[key].astype(str).str.zfill(width)
    census_df["state"] = census_df["state"].astype(str).str.zfill(2)

    # The DHC census_df has columns like r_{agecat}_{sex}_{race}
    # We need to pick the right one per row based on _agecat and _sex
    merge_left = [f"_merge_{k}" for k in geo_merge_keys]
    merge_right = geo_merge_keys

    # Merge all DHC columns
    r_pattern_cols = [c for c in census_df.columns if c.startswith("r_")]
    df = df.merge(
        census_df[merge_right + r_pattern_cols],
        left_on=merge_left, right_on=merge_right,
        how="left", suffixes=("", "_census"),
    )

    # Pick the correct r_* for each row
    for key in RACE_KEYS:
        df[f"r_{key}"] = np.nan
        for _, row in df[["_agecat", "_sex"]].drop_duplicates().iterrows():
            ac, sx = int(row["_agecat"]), int(row["_sex"])
            mask = (df["_agecat"] == ac) & (df["_sex"] == sx)
            col = f"r_{ac}_{sx}_{key}"
            if col in df.columns:
                df.loc[mask, f"r_{key}"] = df.loc[mask, col]
            else:
                # Try marginal columns
                for fallback in [f"r_{ac}_{key}", f"r_{key}"]:
                    if fallback in df.columns:
                        df.loc[mask, f"r_{key}"] = df.loc[mask, fallback]
                        break

    # Cleanup
    drop_cols = [c for c in df.columns if c.startswith("_merge_") or c.endswith("_census")]
    drop_cols += ["_agecat", "_sex"]
    drop_cols += [c for c in df.columns if c.startswith("r_") and c not in [f"r_{k}" for k in RACE_KEYS]]
    df = df.drop(columns=[c for c in drop_cols if c in df.columns])

    return df


def _merge_party(df, party_col, pid_table):
    """Merge P(party | race) onto voter file."""
    df = df.copy()
    pid_vals = df[party_col].astype(int)
    for key in RACE_KEYS:
        col = f"r_pid_{key}"
        df[col] = pid_vals.map(pid_table[col]).fillna(1.0)
    return df


def _cleanup_internal_cols(df: pd.DataFrame) -> None:
    to_drop = (
        [f"pred_{k}_surname" for k in RACE_KEYS]
        + [f"lik_{k}" for k in RACE_KEYS]
        + [f"_unnorm_{k}" for k in RACE_KEYS]
        + [f"r_{k}" for k in RACE_KEYS]
        + [f"r_pid_{k}" for k in RACE_KEYS]
    )
    existing = [c for c in to_drop if c in df.columns]
    df.drop(columns=existing, inplace=True)
