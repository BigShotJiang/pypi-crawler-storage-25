"""Census surname and name dictionary data: download, cache, and lookup."""

from __future__ import annotations

import io
import os
import tempfile
import zipfile
from pathlib import Path

import pandas as pd
import requests

_SURNAME_URLS = {
    2010: "https://www2.census.gov/topics/genealogy/2010surnames/names.zip",
}

_WRU_NAME_URLS = {
    "last": "https://github.com/kosukeimai/wru/releases/download/v2.0.0/wru-data-census_last_c.rds",
    "last_aug": "https://github.com/kosukeimai/wru/releases/download/v2.0.0/wru-data-last_c.rds",
    "first": "https://github.com/kosukeimai/wru/releases/download/v2.0.0/wru-data-first_c.rds",
    "middle": "https://github.com/kosukeimai/wru/releases/download/v2.0.0/wru-data-mid_c.rds",
}

_CACHE_DIR = Path(os.environ.get("WRU_CACHE_DIR", Path.home() / ".cache" / "wru"))

RACE_COLS = ["pctwhite", "pctblack", "pcthispanic", "pctapi", "pctother"]
RACE_KEYS = ["whi", "bla", "his", "asi", "oth"]

# 2020 Census national race shares (matches R wru 3.0.3 race.margin values).
NATIONAL_RACE_PRIORS = {
    "whi": 0.5783619,
    "bla": 0.1205021,
    "his": 0.1872988,
    "asi": 0.06106737,
    "oth": 0.05276981,
}

_surname_cache: dict[int, pd.DataFrame] = {}
_wru_name_cache: dict[str, pd.DataFrame] = {}


# ---------------------------------------------------------------------------
# Census surname list (2010)
# ---------------------------------------------------------------------------

def _download_2010_surnames() -> pd.DataFrame:
    """Download and parse the 2010 Census surname list."""
    cache_path = _CACHE_DIR / "surnames_2010.parquet"
    if cache_path.exists():
        return pd.read_parquet(cache_path)

    url = _SURNAME_URLS[2010]
    resp = requests.get(url, timeout=120)
    resp.raise_for_status()

    with zipfile.ZipFile(io.BytesIO(resp.content)) as zf:
        csv_name = [n for n in zf.namelist() if n.endswith(".csv")][0]
        with zf.open(csv_name) as f:
            df = pd.read_csv(f)

    df.columns = df.columns.str.strip().str.lower()
    df = df.rename(columns={"name": "surname"})
    df["surname"] = df["surname"].str.upper().str.strip()

    for col in ["pctwhite", "pctblack", "pcthispanic", "pctapi", "pctaian", "pct2prace"]:
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0.0)

    df["pctother"] = df["pctaian"] + df["pct2prace"]

    for col in RACE_COLS:
        df[col] = df[col] / 100.0

    # Floor suppressed zeros so no race probability is exactly 0
    for col in RACE_COLS:
        df[col] = df[col].clip(lower=1e-4)

    race_sum = df[RACE_COLS].sum(axis=1).clip(lower=1e-12)
    for col in RACE_COLS:
        df[col] = df[col] / race_sum

    df = df[["surname", "rank", "count", "prop100k"] + RACE_COLS].copy()
    df = df.set_index("surname")

    _CACHE_DIR.mkdir(parents=True, exist_ok=True)
    df.to_parquet(cache_path)
    return df


def get_surnames(year: int = 2010) -> pd.DataFrame:
    """Load the Census surname list, indexed by surname.

    Columns include P(race | surname) for each of the 5 race categories.
    """
    if year in _surname_cache:
        return _surname_cache[year]
    if year == 2010:
        df = _download_2010_surnames()
    else:
        raise ValueError(f"Surname data for year {year} is not supported yet (use 2010)")
    _surname_cache[year] = df
    return df


# ---------------------------------------------------------------------------
# wru augmented name dictionaries (first, middle, last)
# ---------------------------------------------------------------------------

def _download_wru_name_dict(name_type: str) -> pd.DataFrame:
    """Download a wru name dictionary from GitHub releases.

    Returns a DataFrame indexed by name with columns ``c_whi`` ... ``c_oth``
    containing P(name | race) likelihoods.
    """
    if name_type not in _WRU_NAME_URLS:
        raise ValueError(
            f"Unknown name type {name_type!r}; "
            f"use {', '.join(repr(k) for k in _WRU_NAME_URLS)}"
        )

    cache_path = _CACHE_DIR / f"wru_names_{name_type}.parquet"
    if cache_path.exists():
        return pd.read_parquet(cache_path)

    import pyreadr

    url = _WRU_NAME_URLS[name_type]
    resp = requests.get(url, timeout=120, allow_redirects=True)
    resp.raise_for_status()

    tmp = tempfile.NamedTemporaryFile(suffix=".rds", delete=False)
    try:
        tmp.write(resp.content)
        tmp.close()
        result = pyreadr.read_r(tmp.name)
    finally:
        os.unlink(tmp.name)

    df = result[None]

    # Standardize column names: c_whi_first -> c_whi, first_name -> name
    # Both "last" (census_last_c) and "last_aug" (last_c) use last_name / _last suffix
    base_type = "last" if name_type.startswith("last") else name_type
    name_col_map = {"last": "last_name", "first": "first_name", "middle": "middle_name"}
    name_col = name_col_map[base_type]
    suffix = f"_{base_type}" if base_type != "middle" else "_middle"

    df = df.rename(columns={name_col: "name"})
    for key in RACE_KEYS:
        old_col = f"c_{key}{suffix}"
        if old_col in df.columns:
            df = df.rename(columns={old_col: f"c_{key}"})

    df["name"] = df["name"].str.upper().str.strip()
    keep_cols = ["name"] + [f"c_{k}" for k in RACE_KEYS]
    df = df[[c for c in keep_cols if c in df.columns]].copy()
    df = df.set_index("name")

    _CACHE_DIR.mkdir(parents=True, exist_ok=True)
    df.to_parquet(cache_path)
    return df


def get_name_dict(name_type: str) -> pd.DataFrame:
    """Load a wru name dictionary.

    Parameters
    ----------
    name_type : str
        ``'last'`` (default Census-based, 162K names, no zeros),
        ``'last_aug'`` (augmented, 354K names, may have zeros),
        ``'first'``, or ``'middle'``.

    Returns a DataFrame indexed by name with ``c_whi`` ... ``c_oth`` columns
    containing P(name | race) likelihoods.

    Requires ``pyreadr`` for first download (cached as parquet afterwards).
    """
    if name_type in _wru_name_cache:
        return _wru_name_cache[name_type]
    df = _download_wru_name_dict(name_type)
    _wru_name_cache[name_type] = df
    return df


# ---------------------------------------------------------------------------
# Name cleaning helpers
# ---------------------------------------------------------------------------

def _clean_names(series: pd.Series) -> pd.Series:
    """Uppercase, strip whitespace and common suffixes."""
    s = series.str.upper().str.strip()
    s = s.str.replace(r"\s+(JR|SR|III|II|IV)\.?$", "", regex=True)
    s = s.str.replace(r"[^A-Z\s\-']", "", regex=True)
    s = s.str.strip()
    return s


def _lookup_likelihoods(
    names: pd.Series,
    name_dict: pd.DataFrame,
    try_split: bool = False,
) -> pd.DataFrame:
    """Look up P(name|race) likelihoods for a series of names.

    Returns a DataFrame aligned with ``names`` containing ``c_whi`` ... ``c_oth``.
    Unmatched rows have NaN.
    """
    idx = name_dict.index
    cleaned = _clean_names(names)

    # Direct lookup
    result = cleaned.map(lambda s: name_dict.loc[s] if isinstance(s, str) and s in idx else None)

    # For unmatched surnames: try first segment of hyphenated/space-split names
    unmatched = result.isna()
    if try_split and unmatched.any():
        first_part = cleaned[unmatched].str.split(r"[\s\-]").str[0]
        result[unmatched] = first_part.map(
            lambda s: name_dict.loc[s] if isinstance(s, str) and s in idx else None
        )

    out = pd.DataFrame(index=names.index, columns=[f"c_{k}" for k in RACE_KEYS], dtype=float)
    matched_mask = result.notna()
    if matched_mask.any():
        matched_df = pd.DataFrame(result[matched_mask].tolist(), index=out.index[matched_mask])
        for col in out.columns:
            if col in matched_df.columns:
                out.loc[matched_mask, col] = matched_df[col].values
    return out


# ---------------------------------------------------------------------------
# Public merge functions
# ---------------------------------------------------------------------------

def merge_surnames(
    voter_file: pd.DataFrame,
    surname_col: str = "surname",
    year: int = 2010,
    impute_missing: bool = True,
) -> pd.DataFrame:
    """Merge surname-based race probabilities onto a voter file (Census list).

    Adds ``lik_whi`` ... ``lik_oth`` columns with P(surname | race) values.
    """
    surnames_df = get_surnames(year)
    df = voter_file.copy()

    cleaned = _clean_names(df[surname_col])
    lk = _lookup_likelihoods(df[surname_col], surnames_df.rename(
        columns={pc: f"c_{rk}" for pc, rk in zip(RACE_COLS, RACE_KEYS)}
    ), try_split=True)

    # lk columns are P(race|surname) from Census; convert to likelihood
    for key in RACE_KEYS:
        df[f"pred_{key}_surname"] = lk[f"c_{key}"]
        prior = NATIONAL_RACE_PRIORS[key]
        df[f"lik_{key}"] = lk[f"c_{key}"] / prior

    # Impute missing with column means (matches R's colMeans approach)
    unmatched = df["lik_whi"].isna()
    if impute_missing and unmatched.any():
        for key in RACE_KEYS:
            for prefix in ["pred", "lik"]:
                col = f"{prefix}_{key}_surname" if prefix == "pred" else f"lik_{key}"
                fill = df.loc[~unmatched, col].mean() if (~unmatched).any() else 0.2
                df.loc[unmatched, col] = fill
    elif unmatched.any():
        for key in RACE_KEYS:
            df[f"pred_{key}_surname"] = df[f"pred_{key}_surname"].fillna(0.2)
            df[f"lik_{key}"] = df[f"lik_{key}"].fillna(1.0)

    return df


def merge_names(
    voter_file: pd.DataFrame,
    surname_col: str = "surname",
    first_name_col: str | None = None,
    middle_name_col: str | None = None,
    use_wru_names: bool = True,
    impute_missing: bool = True,
) -> pd.DataFrame:
    """Merge name-based race likelihoods onto a voter file.

    Uses the wru augmented name dictionaries (P(name|race)) for last, first,
    and middle names. The combined likelihood is the product of all available
    name factors::

        P(names | race) = P(last|race) × P(first|race) × P(middle|race)

    Adds ``lik_whi`` ... ``lik_oth`` columns with the combined likelihood,
    and ``pred_*_surname`` columns with P(race | surname) from the Census list.

    Parameters
    ----------
    voter_file : DataFrame
    surname_col : str
        Column with last names.
    first_name_col : str or None
        Column with first names (optional).
    middle_name_col : str or None
        Column with middle names (optional).
    use_wru_names : bool
        If True, use the wru augmented dictionaries. If False or if pyreadr
        is unavailable, fall back to the Census surname list.
    impute_missing : bool
        Impute missing names with column means of matched rows.
    """
    df = voter_file.copy()

    # --- Last name likelihoods ---
    if use_wru_names:
        try:
            last_dict = get_name_dict("last")
            last_lk = _lookup_likelihoods(df[surname_col], last_dict, try_split=True)
            for key in RACE_KEYS:
                df[f"lik_last_{key}"] = last_lk[f"c_{key}"]
        except ImportError:
            use_wru_names = False

    if not use_wru_names:
        # Fallback to Census surname list
        surnames_df = get_surnames(2010)
        renamed = surnames_df.rename(columns={pc: f"c_{rk}" for pc, rk in zip(RACE_COLS, RACE_KEYS)})
        last_lk = _lookup_likelihoods(df[surname_col], renamed, try_split=True)
        for key in RACE_KEYS:
            df[f"lik_last_{key}"] = last_lk[f"c_{key}"] / NATIONAL_RACE_PRIORS[key]

    # Also store P(race|surname) for fallback display
    if use_wru_names:
        # For wru dict, P(race|surname) ∝ P(surname|race) × P(race)
        for key in RACE_KEYS:
            df[f"pred_{key}_surname"] = df[f"lik_last_{key}"] * NATIONAL_RACE_PRIORS[key]
        row_sum = sum(df[f"pred_{k}_surname"] for k in RACE_KEYS)
        row_sum = row_sum.clip(lower=1e-12)
        for key in RACE_KEYS:
            df[f"pred_{key}_surname"] = df[f"pred_{key}_surname"] / row_sum
    else:
        for key in RACE_KEYS:
            df[f"pred_{key}_surname"] = last_lk[f"c_{key}"]

    # --- First name likelihoods ---
    if first_name_col and first_name_col in df.columns:
        try:
            first_dict = get_name_dict("first")
            first_lk = _lookup_likelihoods(df[first_name_col], first_dict)
            for key in RACE_KEYS:
                df[f"lik_first_{key}"] = first_lk[f"c_{key}"]
        except ImportError:
            pass

    # --- Middle name likelihoods ---
    if middle_name_col and middle_name_col in df.columns:
        try:
            mid_dict = get_name_dict("middle")
            mid_lk = _lookup_likelihoods(df[middle_name_col], mid_dict)
            for key in RACE_KEYS:
                df[f"lik_mid_{key}"] = mid_lk[f"c_{key}"]
        except ImportError:
            pass

    # --- Combine into lik_* (product of all available name factors) ---
    for key in RACE_KEYS:
        combined = df[f"lik_last_{key}"].copy()
        if f"lik_first_{key}" in df.columns:
            has_first = df[f"lik_first_{key}"].notna()
            combined = combined.where(~has_first, combined * df[f"lik_first_{key}"])
        if f"lik_mid_{key}" in df.columns:
            has_mid = df[f"lik_mid_{key}"].notna()
            combined = combined.where(~has_mid, combined * df[f"lik_mid_{key}"])
        df[f"lik_{key}"] = combined

    # --- Impute missing: fill raw likelihoods with colMeans, then recompute
    #     pred_*_surname from imputed likelihoods (matches R's approach of
    #     imputing c_*_last then multiplying by race.margin and normalizing) ---
    unmatched = df["lik_whi"].isna()
    if impute_missing and unmatched.any() and (~unmatched).any():
        for key in RACE_KEYS:
            df.loc[unmatched, f"lik_{key}"] = df.loc[~unmatched, f"lik_{key}"].mean()
        # Recompute P(race|surname) from imputed likelihoods
        for key in RACE_KEYS:
            df.loc[unmatched, f"pred_{key}_surname"] = (
                df.loc[unmatched, f"lik_{key}"] * NATIONAL_RACE_PRIORS[key]
            )
        row_sum = sum(df.loc[unmatched, f"pred_{k}_surname"] for k in RACE_KEYS).clip(lower=1e-12)
        for key in RACE_KEYS:
            df.loc[unmatched, f"pred_{key}_surname"] = df.loc[unmatched, f"pred_{key}_surname"] / row_sum
    elif unmatched.any():
        for key in RACE_KEYS:
            df[f"lik_{key}"] = df[f"lik_{key}"].fillna(1.0)
            df[f"pred_{key}_surname"] = df[f"pred_{key}_surname"].fillna(0.2)

    # Clean up per-name intermediate columns
    for prefix in ["lik_last_", "lik_first_", "lik_mid_"]:
        cols = [c for c in df.columns if c.startswith(prefix)]
        df = df.drop(columns=cols)

    return df
