"""wru: Who Are You? Bayesian Prediction of Racial Category Using Surname and Geolocation.

Python implementation of the BISG/BIFSG/fBISG methods from Imai & Khanna (2016).
"""

from .census import census_geo_api, census_geo_api_dhc, get_census_data, get_census_data_dhc
from .predict import predict_race
from .surnames import get_name_dict, get_surnames, merge_names, merge_surnames

__all__ = [
    "predict_race",
    "get_census_data",
    "get_census_data_dhc",
    "census_geo_api",
    "census_geo_api_dhc",
    "get_surnames",
    "get_name_dict",
    "merge_surnames",
    "merge_names",
]

__version__ = "0.2.0"
