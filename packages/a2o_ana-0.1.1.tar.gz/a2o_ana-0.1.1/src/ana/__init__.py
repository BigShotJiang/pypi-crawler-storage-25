"""ana — out-of-the-box NATS-based agent-to-agent protocol.

Three things make this package useful:

1. **Envelope schemas** — `Query` / `Reply` / `Ack` / `Discovery` pydantic models
   that capture the de-facto wire format used across multi-bot fleets.
2. **Subject convention** — `<prefix>.<agent>.<verb>.<topic>`, with a
   `SubjectScheme` helper so you can pick a different prefix per fleet.
3. **AgentBus** — async client over `nats-py` that wires the two together,
   plus a publish auditor and an optional reply-await helper.

A 5-line bot::

    import asyncio
    from ana import AgentBus

    async def main():
        async with AgentBus("my-bot") as bus:
            await bus.query("other-bot", "what's your status?")

    asyncio.run(main())
"""
from __future__ import annotations

from ana.audit import PublishAuditor
from ana.client import AgentBus
from ana.envelope import Ack, Discovery, Envelope, Query, Reply, parse_envelope
from ana.subjects import SubjectScheme

__all__ = [
    "Ack",
    "AgentBus",
    "Discovery",
    "Envelope",
    "PublishAuditor",
    "Query",
    "Reply",
    "SubjectScheme",
    "parse_envelope",
]

__version__ = "0.1.0"
