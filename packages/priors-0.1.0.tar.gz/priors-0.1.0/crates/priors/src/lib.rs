//! Priors for prior-fitted networks.
