"""Priors for prior-fitted networks."""

from ._priors import __version__

__all__ = ["__version__"]
