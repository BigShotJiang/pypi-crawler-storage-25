# priors

Priors for prior-fitted networks.

## Installation

```bash
pip install priors
```

```toml
# Cargo.toml
[dependencies]
priors = "0.1"
```

## License

[MIT](LICENSE)
