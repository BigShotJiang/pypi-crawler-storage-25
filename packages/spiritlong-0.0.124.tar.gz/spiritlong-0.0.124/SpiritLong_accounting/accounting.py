
#!/usr/bin/python3
# coding=utf-8
##################################################################
#              ____     _     _ __  __                 
#             / __/__  (_)___(_) /_/ /  ___  ___  ___ _
#            _\ \/ _ \/ / __/ / __/ /__/ _ \/ _ \/ _ `/
#           /___/ .__/_/_/ /_/\__/____/\___/_//_/\_, / 
#              /_/                              /___/  
# 
# Copyright (c) 2026 Chongqing Spiritlong Technology Co., Ltd.
# All rights reserved.
# @author	arthuryang
# @brief	财务处理
##################################################################

import	os
import	SpiritLong_utility
import	accounting

from	SpiritLong_database.database_SQLite	import	SQLiteDatabase



## 财务类
class accounting:
	## 初始化
	#	db		数据库
	#	SVN_path	SVN:SPIRITLONG所在路径
	def __init__(self, db, SVN_path):
		pass


if __name__ == '__main__':

	db	= SQLiteDatabase('SpiritLong_accounting/accounting.db')
	schema_filename	= "SpiritLong_accounting/SQLITE数据库结构accounting.xlsx"

	db.import_excel_schema(schema_filename)

	# path		= r'C:\Users\yangs\Documents\SVN\SPIRITLONG\财务\数据\2023\原始数据\账户对账\重庆灵悠科技有限公司'
	# filename	= os.path.join(path, 'ICC4602 对账记录 2023-09-01_2023-09-30.xlsx')
	# records		= get_balance_from_xlsx(filename)
	# for r in records:
	# 	print(r)
	