#!/usr/bin/python3
# coding=utf-8
###################################################################
#           ____     _     _ __  __                 
#          / __/__  (_)___(_) /_/ /  ___  ___  ___ _
#         _\ \/ _ \/ / __/ / __/ /__/ _ \/ _ \/ _ `/
#        /___/ .__/_/_/ /_/\__/____/\___/_//_/\_, / 
#           /_/                              /___/  
# Copyright (c) 2026 Chongqing Spiritlong Technology Co., Ltd.
# All rights reserved.  
# @author	arthuryang
# @brief	日常工作，此为入口文件
#
###################################################################  

import	accounting
import	database
import	file_middle
import	file_original
import	file_report

## 读取当月原始数据到数据库
def import_original_to_databaase():
	pass

if __name__ == '__main__':
	pass