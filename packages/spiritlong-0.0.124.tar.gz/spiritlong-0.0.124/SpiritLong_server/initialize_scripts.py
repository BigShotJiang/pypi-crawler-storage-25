initialize_scripts	= {}

initialize_scripts['Aliyun_Debian_13'] 	= r'''#!/bin/bash
###################################################################
#           ____     _     _ __  __                 
#          / __/__  (_)___(_) /_/ /  ___  ___  ___ _
#         _\ \/ _ \/ / __/ / __/ /__/ _ \/ _ \/ _ `/
#        /___/ .__/_/_/ /_/\__/____/\___/_//_/\_, / 
#           /_/                              /___/  
# Copyright (c) 2026 Chongqing Spiritlong Technology Co., Ltd.
# All rights reserved.  
# @author	arthuryang
# @brief	云服务器初始化脚本
#
###################################################################  

# 阿里云 Debian 13.4
# 初始化服务器，安装软件包并配置，不包含修改密钥/密码的操作

# 需要提供以下环境变量
#	HOSTNAME			本机主机名
#	PORT_SSH			SSH端口号
#	PORT_MYSQL			MySQL端口号
#	MYSQL_SPIRITLONG_PASSWORD	MySQL的spiritlong账号的密码
# /data下是数据所在
#	/data/database	数据库文件
#	/data/www	本机默认http网站目录

# ------------ 安装软件包 ------------
apt-get update
apt-get -y install vim subversion pip python3 default-libmysqlclient-dev pkg-config ssh
# python 需要手动创建符号连接
ln -sf python3 /usr/bin/python
PYTHON_VERSION=$(python --version | grep '[0-9].[0-9]*' -o)
# Debian 13使用python3.13，其pip需要手动设置，才能安装外部的pip包
mv /usr/lib/python$PYTHON_VERSION/{EXTERNALLY-MANAGED,EXTERNALLY-MANNAGED.backup}

# 安装公司的python包，以及其他基本的pip包
pip install -U pip
pip install spiritlong websockets uwsgi werkzeug asyncio

# mysqlclient需要编译，应确保编译工具链存在。spiritlong默认不会安装此包，但SpiritLong_database需要
pip install mysqlclient

# 服务：nginx/mariadb/adminer，注意需要先安装apache2才好安装php-fpm，装好后卸载apache2
apt-get -y install apache2 
apt-get -y install php-fpm
apt-get -y remove apache2
apt-get -y install nginx mariadb-server adminer uwsgi nodejs npm redis uwsgi-plugin-python3 rsyslog



# ------------ hostname ------------
echo $HOSTNAME > /etc/hostname
hostname -F /etc/hostname
echo "set HOSTNAME to $HOSTNAME"

# ------------ root bashrc ------------
cat >>/root/.bashrc <<EOF
export LS_OPTIONS='--color=auto'
eval "\$(dircolors)"
alias ls='ls \$LS_OPTIONS'
alias ll='ls \$LS_OPTIONS -l'
alias l='ls \$LS_OPTIONS -lA'
EOF
.  ~/.bashrc
echo "root .bashrc modified"

# ------------ 配置sshd ------------
# 删除这些选项
sed -i '/^#\?Port/d' /etc/ssh/sshd_config
sed -i '/^#\?PermitRootLogin/d' /etc/ssh/sshd_config
sed -i '/^#\?TCPKeepAlive/d' /etc/ssh/sshd_config
sed -i '/^#\?ClientAliveInterval/d' /etc/ssh/sshd_config
sed -i '/^#\?ClientAliveCountMax/d' /etc/ssh/sshd_config

# 添加这些选项
cat >>/etc/ssh/sshd_config <<EOF
Port $PORT_SSH
PermitRootLogin	yes
TCPKeepAlive yes
ClientAliveInterval 10
ClientAliveCountMax 3
EOF
service ssh restart && echo "ssh server work well. port is $PORT_SSH"

# ------------ 配置vim ------------
# 默认配置无需修改，只增加
cat >>/etc/vim/vimrc <<EOF

syntax on
set background=dark
au BufReadPost * if line("'\"") > 1 && line("'\"") <= line("$") | exe "normal! g'\"" | endif
filetype plugin indent on
set showcmd
set showmatch
set incsearch
set mouse=a
" 设置vim中python默认8空格缩进和TAB
autocmd FileType python setlocal noet ts=8 sw=8 sts=8
set number
EOF
echo "vim configuration...done"

# ------------ Nginx ------------
# 设置一个默认网页
mkdir -p /data/www
cat > /data/www/index.html <<EOF
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>SPIRITLONG SERVICE</title>
	</head>

	<body>
		<p>建设中</p>
	</body>
</html>
EOF

# 设置默认网页和adminer的nginx配置
cat > /etc/nginx/sites-available/default <<EOF
server {
	listen 80 default_server;
	listen [::]:80 default_server;
	
	server_name _;

	location / {
		root	/data/www;
		index	index.html;
	}

	location /adminer {
		root	/usr/share;
		index	adminer.php;
	}
	
	location ~ \.php$ {
		root		/usr/share;
		fastcgi_pass	unix:/var/run/php/php-fpm.sock;
		fastcgi_index	adminer.php;
		fastcgi_param	SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
		include		fastcgi_params;
	}
	
	location ~ /\.ht {
		deny all;
	}
}
EOF
service nginx restart && echo "nginx work well"


# ------------ mysql ------------
service mysql stop
# 移动数据库文件目录
MYSQL_PATH=/data/Database/mysql
mkdir -p $MYSQL_PATH
MYSQL_LOG_PATH=/data/Database/mysql_log
chown mysql $MYSQL_PATH -R
chgrp mysql $MYSQL_PATH -R
# 日志目录
mkdir -p $MYSQL_LOG_PATH
#mv /var/lib/mysql $MYSQL_PATH
chown mysql $MYSQL_LOG_PATH -R
chgrp mysql $MYSQL_LOG_PATH -R

# 初始化数据库文件目录
mariadb-install-db --user=mysql --datadir=$MYSQL_PATH

# 设置端口
sed -i "s/^#\? \?port.*/port	= $PORT_MYSQL/" /etc/mysql/my.cnf
MYSQL_CONFIG_FILE=/etc/mysql/mariadb.conf.d/50-server.cnf
cp $MYSQL_CONFIG_FILE /etc/mysql/mariadb.conf.d/50-server.cnf.backup
sed -i 's/^\(bind-address\)/#\1/g' $MYSQL_CONFIG_FILE
sed -i 's/^#\? \?\(skip-name-resolve\)/\1/g' $MYSQL_CONFIG_FILE
# 注意使用双引号来替换变量，且用&作为分隔符
sed -i "s&^#\? \?\(datadir\s*= \).*&\1$MYSQL_PATH&" $MYSQL_CONFIG_FILE
sed -i "s&^#\? \?\(log_error\s*= \).*&\1$MYSQL_LOG_PATH/error.log&" $MYSQL_CONFIG_FILE

service mysql start && echo "mysql server ready"

# 创建数据库用户spiritlong，并授权全部权限
MYSQL_SPIRITLONG_USER_PASSWORD=$(strings /dev/urandom |tr -dc [:alnum:] | head -c${1:-20})
mysql -e "CREATE USER 'spiritlong'@'localhost' IDENTIFIED BY '$MYSQL_SPIRITLONG_USER_PASSWORD';"
mysql -e "grant all privileges on *.* to 'spiritlong'@'localhost' WITH GRANT OPTION;flush privileges;"

# ------------ 保存配置 ------------
cat > /root/$HOSTNAME.config <<EOF
SSH port		$PORT_SSH
MySQL port		$PORT_MYSQL
MySQL password 
	spiritlong@localhost	$MYSQL_SPIRITLONG_USER_PASSWORD
EOF

'''