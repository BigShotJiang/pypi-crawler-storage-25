# pylint: disable=C0114, C0115, C0116, R0913, R0917, W0718, R0902, R0912, R0914, R0915, R1702
import os
import traceback
import logging
import numpy as np
from ..config.constants import constants
from ..config.defaults import DEFAULTS
from ..core.framework import TaskBase
from ..core.colors import color_str
from ..core.exceptions import InvalidOptionError
from .utils import (
    read_img, write_img, extension_supported_input, get_output_filename, extension_raw)
from .stack_framework import ImageSequenceManager, SequentialTask
from .exif import copy_exif_from_file_to_file
from .denoise import denoise
from .sharpen import unsharp_mask


class FocusStackBase(TaskBase, ImageSequenceManager):
    def __init__(self, name, stack_algo, enabled=True, apply_postifx=False, **kwargs):
        ImageSequenceManager.__init__(self, name, **kwargs)
        TaskBase.__init__(self, name, enabled)
        default_params = DEFAULTS["focus_stack_params"]
        self.apply_postifx = apply_postifx
        self.stack_algo = stack_algo
        self.exif_path = kwargs.pop("exif_path", "")
        self.prefix = kwargs.pop("prefix", default_params["prefix"])
        self.denoise_amount = kwargs.pop(
            "denoise_amount", default_params["denoise_amount"]
        )
        self.sharpen_amount = (
            kwargs.pop(
                "sharpen_amount_percent", default_params["sharpen_amount_percent"]
            )
            / 100.0
        )
        self.sharpen_radius = kwargs.pop(
            "sharpen_radius", default_params["sharpen_radius"]
        )
        self.sharpen_threshold = kwargs.pop(
            "sharpen_threshold", default_params["sharpen_threshold"]
        )
        self.plot_stack = kwargs.pop(
            "plot_stack", DEFAULTS["focus_stack_params"]["plot_stack"]
        )
        self.stack_algo.set_process(self)
        self.plot_path = kwargs.pop(
            "plot_path", DEFAULTS["image_sequence_manager"]["plots_path"]
        )
        self.frame_count = -1

    def add_postfix(self, filename):
        if self.apply_postifx:
            algo_class = self.stack_algo.__class__.__name__
            postfix = ""
            if algo_class.startswith("Pyramid"):
                postfix = "_pyram"
            elif algo_class.startswith("DepthMap"):
                postfix = "_depmp"
            root, ext = os.path.splitext(filename)
            return root + postfix + ext
        return filename

    def focus_stack(self, filenames):
        self.sub_message_r(
            color_str(": reading input files", constants.LOG_COLOR_LEVEL_3)
        )
        input_filename = os.path.basename(filenames[0])
        output_filename = self.add_postfix(
            os.path.join(
                self.output_full_path(),
                self.prefix + get_output_filename(input_filename),
            )
        )
        filename = os.path.basename(output_filename)
        self.callback(constants.CALLBACK_UPDATE_FRAME_STATUS, self.name, filename, 0)
        n_frames = len(filenames)
        if n_frames > 1:
            self.sub_message_r(
                color_str(
                    f": focus stacking: blending {n_frames} frames",
                    constants.LOG_COLOR_LEVEL_3,
                )
            )
            self.stack_algo.set_output_filename(filename)
            stacked_img = self.stack_algo.focus_stack()
        else:
            self.sub_message_r(
                color_str(
                    ": focus stack made of a single file, skip blending",
                    constants.LOG_COLOR_LEVEL_3,
                )
            )
            stacked_img = read_img(filenames[0])
        if self.denoise_amount > 0.0:
            self.sub_message_r(
                color_str(": denoise image", constants.LOG_COLOR_LEVEL_3)
            )
            stacked_img = denoise(stacked_img, self.denoise_amount)
        if self.sharpen_amount > 0.0:
            self.sub_message_r(
                color_str(": sharpen image", constants.LOG_COLOR_LEVEL_3)
            )
            stacked_img = unsharp_mask(
                stacked_img,
                self.sharpen_amount,
                self.sharpen_radius,
                self.sharpen_threshold,
            )
        write_img(output_filename, stacked_img)
        if self.exif_path != "":
            if (
                stacked_img.dtype == np.uint16
                and os.path.splitext(output_filename)[-1].lower() == ".png"
            ):
                self.sub_message_r(
                    color_str(
                        ": exif not supported for 16-bit PNG format",
                        constants.LOG_COLOR_WARNING,
                    ),
                    level=logging.WARNING,
                )
            else:
                self.sub_message_r(
                    color_str(": copy exif data", constants.LOG_COLOR_LEVEL_3)
                )
                if not os.path.exists(self.exif_path):
                    raise RuntimeError(f"path {self.exif_path} does not exist.")
                try:
                    _dirpath, _, fnames = next(os.walk(self.exif_path))
                    fnames = sorted(
                        [name for name in fnames if extension_supported_input(name)]
                    )
                    if len(fnames) == 0:
                        raise RuntimeError(
                            f"path {self.exif_path} does not contain image files."
                        )

                    # Try to match the extension of the first input file
                    input_ext = os.path.splitext(filenames[0])[1].lower()
                    exif_filename_only = fnames[0]
                    for name in fnames:
                        if os.path.splitext(name)[1].lower() == input_ext:
                            exif_filename_only = name
                            break
                    else:
                        # Fallback: prefer non-RAW files (JPG/TIFF/PNG) over RAW
                        for name in fnames:
                            if not extension_raw(name):
                                exif_filename_only = name
                                break

                    exif_filename = os.path.join(self.exif_path, exif_filename_only)
                    copy_exif_from_file_to_file(exif_filename, output_filename)
                    self.sub_message_r(" " * 60)
                except Exception as e:
                    traceback.print_exc()
                    self.sub_message_r(
                        color_str(
                            f": failed to copy EXIF data: {str(e)}",
                            constants.LOG_COLOR_WARNING,
                        ),
                        level=logging.WARNING,
                    )
        self.callback(constants.CALLBACK_UPDATE_FRAME_STATUS, self.name, filename, 1000)
        if self.plot_stack:
            idx_str = f"{self.frame_count + 1:04d}" if self.frame_count >= 0 else ""
            caption = f"{self.name}: {self.stack_algo.algo_name()}"
            if idx_str != "":
                caption += f"\nbunch: {idx_str}"
            self.callback(
                constants.CALLBACK_SAVE_PLOT,
                self.id,
                self.output_path,
                caption,
                output_filename,
            )
        if self.frame_count >= 0:
            self.frame_count += 1

    def init(self, job, working_path=""):
        if working_path == "":
            working_path = job.working_path
        ImageSequenceManager.init(self, job)
        if self.exif_path is None:
            self.exif_path = job.action_path(0)
        if self.exif_path != "":
            self.exif_path = os.path.join(working_path, self.exif_path)

    def end_job(self):
        ImageSequenceManager.end_job(self)


def get_bunches(collection, n_frames, n_overlap):
    if n_frames == n_overlap:
        raise RuntimeError(
            f"Can't get bunch collection, total number of frames ({n_frames}) "
            "is equal to the number of overlapping grames"
        )
    if len(collection) < n_frames:
        return [collection]
    bunches = [
        collection[x: x + n_frames]
        for x in range(0, len(collection) - n_overlap, n_frames - n_overlap)
    ]
    return bunches


class FocusStackBunch(SequentialTask, FocusStackBase):
    def __init__(self, name, stack_algo, enabled=True, **kwargs):
        SequentialTask.__init__(self, name, enabled)
        FocusStackBase.__init__(self, name, stack_algo, enabled, False, **kwargs)
        self._chunks = None
        self.frame_count = 0
        self.frames = kwargs.get(
            "frames", DEFAULTS["focus_stack_bunch_params"]["frames"]
        )
        self.overlap = kwargs.get(
            "overlap", DEFAULTS["focus_stack_bunch_params"]["overlap"]
        )
        self.denoise_amount = kwargs.get("denoise_amount", 0)
        self.stack_algo.set_do_step_callback(False)
        if self.overlap >= self.frames:
            raise InvalidOptionError(
                "overlap", self.overlap, "overlap must be smaller than batch size"
            )

    def sequential_processing(self):
        return True

    def init(self, job, _working_path=""):
        FocusStackBase.init(self, job, self.working_path)

    def begin(self):
        SequentialTask.begin(self)
        self._chunks = get_bunches(
            sorted(self.input_filepaths()), self.frames, self.overlap
        )
        self.callback(constants.CALLBACK_ADD_STATUS_BOX, self.output_path)
        for chunk in self._chunks:
            filename = chunk[0]
            file_path = self.output_full_path()
            filename = self.add_postfix(
                os.path.join(file_path, self.prefix + os.path.basename(filename))
            )
            self.callback(constants.CALLBACK_ADD_FRAME, self.output_path, filename, 1)
        self.set_counts(len(self._chunks))

    def end(self):
        SequentialTask.end(self)

    def end_job(self):
        FocusStackBase.end_job(self)

    def run_step(self, action_count=-1):
        self.print_message(
            color_str(
                f"fusing bunch {action_count + 1}/{self.total_action_counts}",
                constants.LOG_COLOR_LEVEL_2,
            )
        )
        img_files = self._chunks[action_count]
        filename = self.prefix + os.path.basename(img_files[0])
        self.callback(
            constants.CALLBACK_UPDATE_FRAME_STATUS, self.output_path, filename, 0
        )
        self.stack_algo.init(img_files)
        self.focus_stack(self._chunks[action_count])
        self.callback(
            constants.CALLBACK_UPDATE_FRAME_STATUS, self.output_path, filename, 1000
        )
        return True


class FocusStack(FocusStackBase):
    def __init__(self, name, stack_algo, enabled=True, **kwargs):
        super().__init__(name, stack_algo, enabled, True, **kwargs)
        self.stack_algo.set_do_step_callback(True)
        self.shape = None

    def run_core(self):
        self.set_filelist()
        img_files = sorted(self.input_filepaths())
        self.stack_algo.init(img_files)
        self.callback(
            "step_counts",
            self.id,
            self.name,
            self.stack_algo.total_steps(self.num_input_filepaths()),
        )
        self.callback(constants.CALLBACK_ADD_STATUS_BOX, self.output_path)
        filename = img_files[0]
        file_path = self.output_full_path()
        filename = self.add_postfix(
            os.path.join(file_path, self.prefix + os.path.basename(filename))
        )
        self.callback(constants.CALLBACK_ADD_FRAME, self.output_path, filename, 1)
        self.focus_stack(img_files)
        return True

    def init(self, job, _working_path=""):
        FocusStackBase.init(self, job, self.working_path)

    def end_job(self):
        FocusStackBase.end_job(self)
