from yta_editor.transformations.effects.video import VideoEffectSingleNodeBaseInput
from yta_editor_nodes.processor.video.waving_frame import WavingFrameVideoNodeProcessor
from yta_editor_parameters.values.abstract import VideoEditorParameterValue
from yta_editor_parameters.values import ConstantVideoEditorParameterValue
from yta_validation.parameter import ParameterValidator


class WavingFrameVideoEffect(VideoEffectSingleNodeBaseInput):
    """
    The effect that will modify the frames and
    transform them into waving frames according
    to the provided conditions.
    """

    _parameter_values_to_skip_process: dict[str, any] = {}

    def __init__(
        self,
        amplitude: VideoEditorParameterValue = ConstantVideoEditorParameterValue(0.05),
        frequency: VideoEditorParameterValue = ConstantVideoEditorParameterValue(10.0),
        speed: VideoEditorParameterValue = ConstantVideoEditorParameterValue(2.0),
        do_use_transparent_pixels: VideoEditorParameterValue = ConstantVideoEditorParameterValue(False),
        do_use_gpu: bool = True
    ):
        ParameterValidator.validate_mandatory_instance_of('amplitude', amplitude, VideoEditorParameterValue)
        ParameterValidator.validate_mandatory_instance_of('frequency', frequency, VideoEditorParameterValue)
        ParameterValidator.validate_mandatory_instance_of('speed', speed, VideoEditorParameterValue)
        ParameterValidator.validate_mandatory_instance_of('do_use_transparent_pixels', do_use_transparent_pixels, VideoEditorParameterValue)

        super().__init__(
            node_processor = WavingFrameVideoNodeProcessor,
            parameters = {
                'amplitude': amplitude,
                'frequency': frequency,
                'speed': speed,
                'do_use_transparent_pixels': do_use_transparent_pixels
            },
            do_use_gpu = do_use_gpu
        )