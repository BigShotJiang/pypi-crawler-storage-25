from yta_editor.transformations.effects.video import VideoEffectSingleNodeBaseInput
from yta_editor_nodes.processor.transparency import TransparencyNodeProcessor
from yta_editor_parameters.values.abstract import VideoEditorParameterValue
from yta_editor_parameters.values import ConstantVideoEditorParameterValue
from yta_validation.parameter import ParameterValidator


class TransparencyVideoEffect(VideoEffectSingleNodeBaseInput):
    """
    The effect that will change the transparency of the
    element according to the provided conditions.
    """

    _parameter_values_to_skip_process: dict[str, any] = {
        'transparency': 1.0
    }

    def __init__(
        self,
        transparency: VideoEditorParameterValue = ConstantVideoEditorParameterValue(1.0),
        do_use_gpu: bool = True
    ):
        ParameterValidator.validate_mandatory_bool('do_use_gpu', do_use_gpu)
        ParameterValidator.validate_mandatory_instance_of('transparency', transparency, VideoEditorParameterValue)

        super().__init__(
            node_processor = TransparencyNodeProcessor,
            parameters = {
                'transparency': transparency
            },
            do_use_gpu = do_use_gpu
        )