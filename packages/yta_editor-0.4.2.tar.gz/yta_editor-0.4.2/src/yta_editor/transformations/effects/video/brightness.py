from yta_editor.transformations.effects.video import VideoEffectSingleNodeBaseInput
from yta_editor_nodes.processor import BrightnessNodeProcessor
from yta_editor_parameters.values.abstract import VideoEditorParameterValue
from yta_editor_parameters.values import ConstantVideoEditorParameterValue
from yta_validation.parameter import ParameterValidator


class BrightnessVideoEffect(VideoEffectSingleNodeBaseInput):
    """
    The effect that will change the brightness of the
    element according to the provided conditions.
    """

    _parameter_values_to_skip_process: dict[str, any] = {
        'factor': 1.0
    }

    def __init__(
        self,
        brightness: VideoEditorParameterValue = ConstantVideoEditorParameterValue(2.0),
        do_use_gpu: bool = True
    ):
        ParameterValidator.validate_mandatory_bool('do_use_gpu', do_use_gpu)
        ParameterValidator.validate_mandatory_instance_of('brightness', brightness, VideoEditorParameterValue)

        super().__init__(
            node_processor = BrightnessNodeProcessor,
            parameters = {
                'factor': brightness
            },
            do_use_gpu = do_use_gpu
        )