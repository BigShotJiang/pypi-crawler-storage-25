"""
TODO: Check if this class can be refactored, moved
to somewhere else or put in other library.
"""
from yta_editor_frame.buffer import FrameBuffer
from yta_constants.enum import YTAEnum as Enum
import numpy as np


class FrameAdapterMode(Enum):
    """
    The different modes we have to adapt the frames to
    a specific resolution.
    """

    ALPHA_BACKGROUND = 'alpha_background'
    """
    A full transparent frame will be created with the
    expected resolution and the original frame will be
    placed in the middle.
    """

class FrameAdapter:
    """
    A class to modify the frames and adapt them to the 
    resolution we need for the timeline. This is needed
    to be able to use them as inputs in the nodes.
    """

    @staticmethod
    def adapt(
        frame: 'FrameBuffer',
        size: tuple[int, int] = (1920, 10809),
        mode: FrameAdapterMode = FrameAdapterMode.ALPHA_BACKGROUND
    ) -> 'FrameBuffer':
        """
        Adapt the `frame` provided to fit the `size` provided
        by using the `adapt_mode` given as parameter.
        """
        mode = FrameAdapterMode.to_enum(mode)

        if frame.size == size:
            return frame
        
        # TODO: Adapt it
        if mode == FrameAdapterMode.ALPHA_BACKGROUND:
            if frame.has_gpu:
                frame_as_texture = frame._moderngl_texture
                # TODO: Adapt by using GPU, with a node
                # raise Exception('GPU is prioritized but we do not have the functionality yet')
                # TODO: By now I do the same than with CPU
                frame_as_numpy = _adapt_with_alpha(
                    frame = frame.as_numpy_ndarray(),
                    size = size
                )

                return FrameBuffer.from_numpy_ndarray(frame_as_numpy)

                return frame
            else:
                # Maybe what we have is the 'av.VideoFrame' so we
                # force it to have the 'np.ndarray' to work with
                frame_as_numpy = _adapt_with_alpha(
                    frame = frame.as_numpy_ndarray(),
                    size = size
                )

                return FrameBuffer.from_numpy_ndarray(frame_as_numpy)
        else:
            raise Exception('Mode that is declared but not existing yet.')

    # TODO: Deprecated, expecting 'FrameBuffer' now
    @staticmethod
    def adapt_old(
        frame: np.ndarray,
        resolution: tuple[int, int] = (1920, 1080),
        mode: FrameAdapterMode = FrameAdapterMode.ALPHA_BACKGROUND
    ) -> np.ndarray:
        """
        Adapt the `frame` provided to fit the expected and
        also given `resolution` by using the `adapt_mode`
        provided as parameter.
        """
        mode = FrameAdapterMode.to_enum(mode)

        if frame.size == resolution:
            return frame

        # TODO: Improve this, please
        if mode == FrameAdapterMode.ALPHA_BACKGROUND:
            return _adapt_with_alpha(
                frame = frame,
                resolution = resolution
            )

# Specific methods below
def _adapt_with_alpha(
    frame: np.ndarray,
    size: tuple[int, int]
) -> np.ndarray:
    """
    Creates a fully alpha background with the `size`
    given and puts the `frame` provided in the middle of
    it.

    This is the functionality to be done when using the
    `ALPHA_BACKGROUND` option.
    """
    if frame.ndim != 3:
        raise Exception('The frame must be HxWxC.')

    src_h, src_w, src_c = frame.shape

    if src_c not in (3, 4):
        raise Exception('The frame must be RGB or GBA.')

    # Final transparent frame
    dst = np.zeros((size[1], size[0], 4), dtype = frame.dtype)

    # RGBA if necessary
    if src_c == 3:
        src_rgba = np.empty((src_h, src_w, 4), dtype = frame.dtype)
        src_rgba[..., :3] = frame
        src_rgba[..., 3] = np.iinfo(frame.dtype).max
    else:
        src_rgba = frame

    # Offsets to center
    offset_x = (size[0] - src_w) // 2
    offset_y = (size[1] - src_h) // 2

    if (
        offset_x < 0 or
        offset_y < 0
    ):
        # TODO: Do rescale and crop if needed
        raise Exception('Original frame is bigger than the size requested.')

    # Copy it
    dst[
        offset_y:offset_y + src_h,
        offset_x:offset_x + src_w
    ] = src_rgba

    # Force it to be continuous to avoid PyAv errors
    dst = np.ascontiguousarray(dst)

    return dst

# TODO: Create the GPU node that does this
