# jing
This is a python libary, used for download stock data and perform data analisys.

## Data layout

The project now uses a source-first layout under `data/`:

```text
data/
  raw/
    yahoo/us/
    baostock/cn/
    akshare/cn/
    akshare/hk/
    binance/bn/
    list/
  parquet/
  duckdb/
```

Examples:

- US Yahoo CSV: `data/raw/yahoo/us/AAPL.csv`
- CN BaoStock CSV: `data/raw/baostock/cn/sh.601088.csv`
- HK AkShare CSV: `data/raw/akshare/hk/00700.csv`
- list files: `data/raw/list/us.txt`

## Installation
```bash
pip install jing

## Only 2 class exported

### downloader `D`
- **Function**: download the data from internet to local file system
- **Parameter**:
  - `_market` (str): us, cn, hk, default is us
- **Return Value**: No return value

### sample code

```python
import jing

d = jing.D(_market='hk')
d.download('00005')

d = jing.D(_market='cn', _source='akshare')
d.download('600519')
