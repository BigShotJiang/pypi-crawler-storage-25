import multiprocessing
from queue import Empty
import os

from .downloader_yahooer import Yahooer
from .downloader_aker import AKER
from .downloader_baostock import BAOSTOCK
from .downloader_bn import BN
from .data_paths import normalize_source

import pandas as pd

import warnings
warnings.filterwarnings("ignore")

pd.set_option('display.max_columns', None)

# 设置最大重试次数
MAX_RETRIES = 3

# 下载结果状态
STATUS_OK = "ok"
STATUS_LOW = "low"

def _record_paths(list_path):
    """根据股票列表路径，派生记录文件路径"""
    base = list_path.rsplit('.', 1)[0]
    return base + "_ok.txt", base + "_low.txt"

def _load_record_set(path):
    """从记录文件加载股票代码集合"""
    if not os.path.exists(path):
        return set()
    with open(path, 'r') as f:
        return {line.strip() for line in f if line.strip()}

def _append_record(path, code):
    """追加一条记录到文件"""
    with open(path, 'a') as f:
        f.write(code + '\n')

def producer(queue, market, source=""):
    """生产者函数，读取股票列表并写入队列，优先入队'数据太少'的，跳过已'下载成功'的"""
    if market == 'us':
        inst = Yahooer()
    elif market == 'cn':
        inst = AKER(market) if source == 'akshare' else BAOSTOCK()
    elif market == 'bn':
        inst = BN()
    else:
        inst = AKER(market)

    list_path = inst.getListPath()
    print(list_path)

    ok_path, low_path = _record_paths(list_path)
    ok_set = _load_record_set(ok_path)
    low_set = _load_record_set(low_path)

    # 先入队"数据太少"的（优先重试）
    n_low = 0
    for code in low_set:
        queue.put((code, 0))
        n_low += 1

    # 再入队不在 ok_set 和 low_set 中的新任务
    n_new = 0
    try:
        with open(list_path, 'r') as file:
            for line in file:
                code = line.strip()
                if code in ok_set or code in low_set:
                    continue
                queue.put((code, 0))
                n_new += 1
    except FileNotFoundError:
        print(f"File '{list_path}' not found.")
    except Exception as e:
        print(f"An error occurred: {e}")

    print(f"生产者完成：优先重试 {n_low} 个数据太少，新任务 {n_new} 个")

def consumer(queue, failed_queue, result_queue, inst):
    """消费者函数，从队列获取任务并下载数据"""
    print(f"消费者 starts")
    while True:
        try:
            code, retries = queue.get(timeout=3)  # 从队列获取任务
        except Empty:
            break  # 队列为空时，退出循环

        try:
            df = inst.getK(code)
            if df is None:
                print(f"{code} 下载失败0")
            elif len(df) <= 10:
                print(f"{code} 数据太少")
                result_queue.put((code, STATUS_LOW))
            else:
                print(f"{code} 下载成功")
                result_queue.put((code, STATUS_OK))
        except Exception as e:
            print(f"{code} 下载失败: {e}")
            if retries < MAX_RETRIES:
                failed_queue.put((code, retries + 1))  # 重新加入失败队列
            else:
                print(f"{code} 达到最大重试次数，放弃")

def _drain_queue(src_queue, dst_queue=None):
    """安全排空队列，用 get(timeout) 替代不可靠的 empty()"""
    items = []
    while True:
        try:
            item = src_queue.get(timeout=1)
            items.append(item)
            if dst_queue is not None:
                dst_queue.put(item)
        except Empty:
            break
    return items

class D:
    def __init__(self, _market="cn", _source="") -> None:
        self.market = _market
        self.source = normalize_source(_source, _market) if _source else _source
        if self.market == 'us':
            self.inst = Yahooer()
        elif self.market == 'hk':
            self.inst = AKER(self.market)
        elif self.market == 'cn':
            if self.source == 'akshare':
                self.inst = AKER(self.market)
            else:
                self.inst = BAOSTOCK(self.market)
        elif self.market == 'bn':
            self.inst = BN()
        else:
            self.inst = Yahooer()

    def download(self, _code=""):
        self.code = _code
        if len(_code) > 0:
            self.inst.getK(self.code)
        else:
            self.concurrent_download()

    def _start_consumers(self, queue, failed_queue, result_queue, num_consumers):
        """启动消费者进程并等待完成"""
        consumers = []
        for _ in range(num_consumers):
            p = multiprocessing.Process(target=consumer, args=(queue, failed_queue, result_queue, self.inst))
            p.start()
            consumers.append(p)
        for p in consumers:
            p.join()
        return consumers

    def concurrent_download(self):
        queue = multiprocessing.Queue()
        failed_queue = multiprocessing.Queue()
        result_queue = multiprocessing.Queue()

        # 获取记录文件路径
        list_path = self.inst.getListPath()
        ok_path, low_path = _record_paths(list_path)

        # 启动多个消费者进程
        num_consumers = 10
        consumers = []
        for i in range(num_consumers):
            p = multiprocessing.Process(target=consumer, args=(queue, failed_queue, result_queue, self.inst))
            print(f"worker {i} starts")
            p.start()
            consumers.append(p)

        # 生产者进程
        producer_process = multiprocessing.Process(target=producer, args=(queue, self.market, self.source))
        producer_process.start()
        producer_process.join()

        # 等待所有消费者完成
        for p in consumers:
            p.join()
            if p.is_alive():
                print(f"{p.name} 未正常退出，尝试 terminate()")
                p.terminate()

        # 保存下载结果到记录文件
        self._save_results(result_queue, ok_path, low_path)

        print("总体完成，处理失败任务...")

        # 将 queue 中可能残留的未处理任务转入 failed_queue，避免丢失
        leftover = _drain_queue(queue, failed_queue)
        if leftover:
            print(f"发现 {len(leftover)} 个残留任务，加入重试队列")

        # 处理失败任务（最多重试 MAX_RETRIES 次）
        retry_attempt = 1
        while retry_attempt <= MAX_RETRIES:
            failed_items = _drain_queue(failed_queue)

            if not failed_items:
                print("没有失败任务，重试结束")
                break

            print(f"开始第 {retry_attempt} 轮重试，共 {len(failed_items)} 个任务...")
            for item in failed_items:
                queue.put(item)

            self._start_consumers(queue, failed_queue, result_queue, num_consumers)

            # 保存本轮下载结果
            self._save_results(result_queue, ok_path, low_path)

            # 将 queue 中可能残留的未处理任务转入 failed_queue
            leftover = _drain_queue(queue, failed_queue)
            if leftover:
                print(f"第 {retry_attempt} 轮重试后有 {len(leftover)} 个残留任务")

            retry_attempt += 1

        print("所有任务完成")

    def _save_results(self, result_queue, ok_path, low_path):
        """从结果队列中取出结果并追加写入记录文件"""
        results = _drain_queue(result_queue)
        ok_count = 0
        low_count = 0
        for code, status in results:
            if status == STATUS_OK:
                _append_record(ok_path, code)
                ok_count += 1
            elif status == STATUS_LOW:
                _append_record(low_path, code)
                low_count += 1
        if ok_count or low_count:
            print(f"记录结果：{ok_count} 个下载成功，{low_count} 个数据太少")

if __name__=="__main__":
    d = D(_market='cn')
    #d.download('601088')
    d.download()
