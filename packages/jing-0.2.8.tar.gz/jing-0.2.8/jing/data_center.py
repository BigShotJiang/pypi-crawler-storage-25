#!/usr/bin/env python
# -*- coding: UTF-8 -*-

import os
import glob
import pandas as pd
from datetime import datetime

from .data_paths import get_raw_csv_path, normalize_source
from .util_file_set import FileSet

class DataCenter:
    def __init__(self, market='us', source='') -> None:
        self.market = market
        self.source = normalize_source(source, market)
        self.date = '2024-11-30'
        self.fs = FileSet(self.market, self.source)

    def one(self, _id, _date=""):
        today = datetime.today()
        self.date = today.strftime("%Y-%m-%d")
        if self.market == 'us':
            pass
        elif self.market == 'hk':
            pass
        else:
            pass

        if len(_date) > 0:
            self.date = _date

        df = self.fs.fetch(_id, self.date, self.market, self.source)
        return df

    def list(self, market="cn"):
        return self.listD(market)

    def listD(self, market="cn"):
        return self.fs.list(market, self.source)

    def csv(self, _id, _date=""):
        path = get_raw_csv_path(self.source, self.market, _id)
        df = pd.read_csv(path)
        # print(df.dtypes)
        # print(df["Date"])
        # print(df["Date"].dtype)
        if len(_date) > 0:
            return df.loc[df['Date'] <= _date]
        return df
    
if __name__ == "__main__":
    dc = DataCenter('us')
    df = dc.one("IONQ")
    print(df)
    df = dc.list()
    print(df['code'])
