from __future__ import annotations

import os
from pathlib import Path


# ---------------------------------------------------------------------------
# Data root
# ---------------------------------------------------------------------------

def get_data_root() -> Path:
    """Return the data root directory.

    Uses $PHOME/data if PHOME env var is set, otherwise ~/.jing/data.
    """
    phome = os.environ.get("PHOME")
    if phome:
        return Path(phome) / "data"
    return Path.home() / ".jing" / "data"


# ---------------------------------------------------------------------------
# Lookup tables
# ---------------------------------------------------------------------------

SOURCE_ALIASES: dict[str, str] = {
    "yf": "yahoo",
    "yahooer": "yahoo",
    "yahoo": "yahoo",
    "ak": "akshare",
    "aker": "akshare",
    "akshare": "akshare",
    "bs": "baostock",
    "baostock": "baostock",
    "bn": "binance",
    "binance": "binance",
    "ft": "futu",
    "futu": "futu",
}

DEFAULT_SOURCE_BY_MARKET: dict[str, str] = {
    "us": "yahoo",
    "cn": "baostock",
    "hk": "akshare",
    "bn": "binance",
}

LIST_NAME_BY_MARKET_AND_SOURCE: dict[tuple[str, str], str] = {
    ("us", "yahoo"): "us.txt",
    ("cn", "baostock"): "cn_baostock.txt",
    ("cn", "akshare"): "cn.txt",
    ("hk", "akshare"): "hk.txt",
    ("bn", "binance"): "bn.txt",
}


# ---------------------------------------------------------------------------
# Public helpers
# ---------------------------------------------------------------------------

def normalize_source(source: str | None, market: str | None = None) -> str:
    """Resolve shorthand source name to canonical name.

    If *source* is empty/None, fall back to the default source for *market*.
    """
    if source:
        return SOURCE_ALIASES.get(source, source)
    if market:
        return DEFAULT_SOURCE_BY_MARKET.get(market, "")
    return ""


def ensure_directory(path: Path) -> Path:
    """Create *path* (and parents) if it doesn't exist, then return it."""
    path.mkdir(parents=True, exist_ok=True)
    return path


def get_raw_dir(source: str | None, market: str) -> Path:
    """Return ``<data_root>/raw/<source>/<market>``."""
    src = normalize_source(source, market)
    return get_data_root() / "raw" / src / market


def get_raw_csv_path(source: str | None, market: str, code: str) -> Path:
    """Return the full path to a raw CSV file."""
    return get_raw_dir(source, market) / f"{code}.csv"


def get_market_list_path(market: str, source: str | None = None) -> Path:
    """Return the path to the stock list file for *market* + *source*."""
    src = normalize_source(source, market)
    list_name = LIST_NAME_BY_MARKET_AND_SOURCE.get((market, src), f"{market}.txt")
    return get_data_root() / "raw" / "list" / list_name
