#!/usr/bin/env python
# -*- encoding: utf8 -*-

marketSourceMap = {
    'cn': 'baostock',
    'hk': 'akshare',
    'us': 'yahoo',
    'bn': 'binance',
    'BN': 'binance',
}
