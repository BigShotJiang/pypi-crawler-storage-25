#!/usr/bin/env python
# -*- coding: UTF-8 -*-

import glob
import pandas
import os
import pandas as pd
from .data_paths import get_raw_csv_path, get_raw_dir, normalize_source
from .util_meta import marketSourceMap

import warnings
warnings.filterwarnings("ignore")

class FileSet:
    def __init__(self, _market='us', _source='') -> None:
        self.market = _market
        self.source = normalize_source(_source or marketSourceMap.get(_market, ''), _market)
        self.dir_path = get_raw_dir(self.source, self.market)

        if not os.path.isdir(self.dir_path):
            raise IsADirectoryError

    def fetch(self, _id, _date="", _market="us", _source=""):
        if len(_market) > 0:
            self.market = _market
        self.source = normalize_source(_source or self.source or marketSourceMap.get(self.market, ''), self.market)
        file_path = get_raw_csv_path(self.source, self.market, _id)
        df = pd.read_csv(file_path)
        if len(_date) > 0:
            df = df[df['Date'] <= _date]
        return df
    def list(self, _market="us", _source=""):
        if len(_market) > 0:
            self.market = _market
        self.source = normalize_source(_source or self.source or marketSourceMap.get(self.market, ''), self.market)
        bsDir = get_raw_dir(self.source, self.market)
        os.chdir(bsDir)

        pattern = "*.csv"
        fileList = glob.glob(pattern)

        df = pd.DataFrame(fileList, columns=["FileName"])
        df["code"] = df["FileName"].str[:-4]
        return df
        

if __name__ == "__main__":
    fs = FileSet()
    df = fs.fetch('IONQ', '2024-11-20', 'us', 'yahoo')
    print(df)
    print(fs.list())
