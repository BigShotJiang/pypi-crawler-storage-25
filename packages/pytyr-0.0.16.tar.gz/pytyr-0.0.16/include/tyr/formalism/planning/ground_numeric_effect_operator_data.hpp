/*
 * Copyright (C) 2025-2026 Dominik Drexler
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

#ifndef TYR_FORMALISM_PLANNING_GROUND_NUMERIC_EFFECT_OPERATOR_DATA_HPP_
#define TYR_FORMALISM_PLANNING_GROUND_NUMERIC_EFFECT_OPERATOR_DATA_HPP_

#include "tyr/common/types.hpp"
#include "tyr/common/types_utils.hpp"
#include "tyr/common/variant.hpp"
#include "tyr/formalism/planning/declarations.hpp"
#include "tyr/formalism/planning/ground_numeric_effect_index.hpp"

namespace tyr
{
template<>
struct Data<formalism::planning::GroundNumericEffectOperator<formalism::FluentTag>>
{
    using Variant = ::cista::offset::variant<Index<formalism::planning::GroundNumericEffect<formalism::Assign, formalism::FluentTag>>,
                                             Index<formalism::planning::GroundNumericEffect<formalism::Increase, formalism::FluentTag>>,
                                             Index<formalism::planning::GroundNumericEffect<formalism::Decrease, formalism::FluentTag>>,
                                             Index<formalism::planning::GroundNumericEffect<formalism::ScaleUp, formalism::FluentTag>>,
                                             Index<formalism::planning::GroundNumericEffect<formalism::ScaleDown, formalism::FluentTag>>>;

    Variant value;

    template<typename C>
    using ViewVariant = std::variant<View<Index<formalism::planning::GroundNumericEffect<formalism::Assign, formalism::FluentTag>>, C>,
                                     View<Index<formalism::planning::GroundNumericEffect<formalism::Increase, formalism::FluentTag>>, C>,
                                     View<Index<formalism::planning::GroundNumericEffect<formalism::Decrease, formalism::FluentTag>>, C>,
                                     View<Index<formalism::planning::GroundNumericEffect<formalism::ScaleUp, formalism::FluentTag>>, C>,
                                     View<Index<formalism::planning::GroundNumericEffect<formalism::ScaleDown, formalism::FluentTag>>, C>>;

    Data() = default;
    Data(Variant value_) : value(value_) {}
    // Python constructor
    template<typename C>
    Data(ViewVariant<C> value_) : value(std::visit([](const auto& view) -> Variant { return Variant(view.get_index()); }, value_))
    {
    }

    void clear() noexcept { tyr::clear(value); }

    friend bool operator==(const Data& lhs, const Data& rhs) { return EqualTo<Variant> {}(lhs.value, rhs.value); }
    friend bool operator!=(const Data& lhs, const Data& rhs) { return lhs.value != rhs.value; }
    friend bool operator<=(const Data& lhs, const Data& rhs) { return lhs.value <= rhs.value; }
    friend bool operator<(const Data& lhs, const Data& rhs) { return lhs.value < rhs.value; }
    friend bool operator>=(const Data& lhs, const Data& rhs) { return lhs.value >= rhs.value; }
    friend bool operator>(const Data& lhs, const Data& rhs) { return lhs.value > rhs.value; }

    auto cista_members() const noexcept { return std::tie(value); }
    auto identifying_members() const noexcept { return std::tie(value); }
};

template<>
struct Data<formalism::planning::GroundNumericEffectOperator<formalism::AuxiliaryTag>>
{
    using Variant = ::cista::offset::variant<Index<formalism::planning::GroundNumericEffect<formalism::Increase, formalism::AuxiliaryTag>>>;

    Variant value;

    template<typename C>
    using ViewVariant = std::variant<View<Index<formalism::planning::GroundNumericEffect<formalism::Increase, formalism::AuxiliaryTag>>, C>>;

    Data() = default;
    Data(Variant value_) : value(value_) {}
    // Python constructor
    template<typename C>
    Data(ViewVariant<C> value_) : value(std::visit([](const auto& view) -> Variant { return Variant(view.get_index()); }, value_))
    {
    }

    void clear() noexcept
    {
        value.destruct();
        new (&value) Variant {};
    }

    friend bool operator==(const Data& lhs, const Data& rhs) { return EqualTo<Variant> {}(lhs.value, rhs.value); }
    friend bool operator!=(const Data& lhs, const Data& rhs) { return lhs.value != rhs.value; }
    friend bool operator<=(const Data& lhs, const Data& rhs) { return lhs.value <= rhs.value; }
    friend bool operator<(const Data& lhs, const Data& rhs) { return lhs.value < rhs.value; }
    friend bool operator>=(const Data& lhs, const Data& rhs) { return lhs.value >= rhs.value; }
    friend bool operator>(const Data& lhs, const Data& rhs) { return lhs.value > rhs.value; }

    auto cista_members() const noexcept { return std::tie(value); }
    auto identifying_members() const noexcept { return std::tie(value); }
};

static_assert(!uses_trivial_storage_v<formalism::planning::GroundNumericEffectOperator<formalism::FluentTag>>);
static_assert(!uses_trivial_storage_v<formalism::planning::GroundNumericEffectOperator<formalism::AuxiliaryTag>>);
}

#endif
