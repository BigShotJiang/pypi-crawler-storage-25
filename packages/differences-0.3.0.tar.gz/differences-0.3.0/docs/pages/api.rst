.. py:module:: differences

ATTgt
*****

.. python-apigen-entity-summary:: differences.ATTgt

.. note::

   :meth:`~differences.ATTgt.fit` and :meth:`~differences.ATTgt.aggregate` both accept
   an ``n_jobs`` argument for parallel computation of the group-time ATTs and the
   multiplier bootstrap (via :obj:`joblib`). Pass ``n_jobs=-1`` to use all cores.
