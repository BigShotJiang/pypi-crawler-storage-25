.. image:: imgs/logo/bw/logo_name_bw.png
   :align: center
   :width: 50%
   :target: index.html

Highlights 🚀
=============

difference-in-differences estimation and inference for Python, for the following use cases

- Balanced panels, unbalanced panels & repeated cross-section
- Two + Multiple time periods
- Fixed + Staggered treatment timing
- Binary + Multi-Valued treatment
- Heterogeneous treatment effects & triple difference


the `ATTgt <api/differences.ATTgt.html>`_  class implements the estimation procedures suggested by Callaway and Sant'Anna (2021), Sant'Anna and Zhao (2020) and the
multi-valued treatment case discussed in Callaway, Goodman-Bacon & Sant'Anna (2021)


.. toctree::
   :caption: Installation
   :hidden:

   pages/installation.rst


.. toctree::
   :caption: API
   :hidden:
   :maxdepth: 2

   pages/api.rst