from differences.models.attgt.attgt import ATTgt
from differences.models.attgt.results import ATTgtResult
