"""Tests for the Immutable Python SDK."""

from __future__ import annotations

import json

import httpx
import pytest

from getimmutable import ImmutableClient, ImmutableError


BASE = "https://test.getimmutable.dev"


def _mock_transport(responses: dict[str, tuple[int, dict]]) -> httpx.MockTransport:
    """Create a mock transport that returns canned responses based on path."""

    def handler(request: httpx.Request) -> httpx.Response:
        path = request.url.path
        for key, (status, body) in responses.items():
            if key in path:
                return httpx.Response(status, json=body)
        return httpx.Response(404, json={"error": "Not found"})

    return handler


@pytest.fixture()
def client(monkeypatch: pytest.MonkeyPatch) -> ImmutableClient:
    """Return a client with mocked httpx.request."""
    return ImmutableClient(api_key="imk_test_key", base_url=BASE)


class TestTrack:
    def test_track_returns_queued(self, monkeypatch: pytest.MonkeyPatch) -> None:
        response_body = {"id": "evt_123", "status": "queued"}

        def mock_request(*args, **kwargs):
            return httpx.Response(202, json=response_body)

        monkeypatch.setattr(httpx, "request", mock_request)
        client = ImmutableClient(api_key="imk_test", base_url=BASE)

        result = client.track({"actor_id": "user_1", "action": "doc.created"})
        assert result["id"] == "evt_123"
        assert result["status"] == "queued"

    def test_track_duplicate_returns_200(self, monkeypatch: pytest.MonkeyPatch) -> None:
        def mock_request(*args, **kwargs):
            return httpx.Response(200, json={"id": "evt_123", "status": "duplicate"})

        monkeypatch.setattr(httpx, "request", mock_request)
        client = ImmutableClient(api_key="imk_test", base_url=BASE)

        result = client.track({
            "actor_id": "user_1",
            "action": "doc.created",
            "idempotency_key": "idem_1",
        })
        assert result["status"] == "duplicate"


class TestTrackBatch:
    def test_batch_returns_events(self, monkeypatch: pytest.MonkeyPatch) -> None:
        def mock_request(*args, **kwargs):
            return httpx.Response(202, json={
                "events": [
                    {"id": "evt_1", "status": "queued"},
                    {"id": "evt_2", "status": "queued"},
                ],
            })

        monkeypatch.setattr(httpx, "request", mock_request)
        client = ImmutableClient(api_key="imk_test", base_url=BASE)

        result = client.track_batch([
            {"actor_id": "user_1", "action": "doc.created"},
            {"actor_id": "user_1", "action": "doc.updated"},
        ])
        assert len(result["events"]) == 2
        assert result["events"][0]["status"] == "queued"


class TestGetEvents:
    def test_query_with_filters(self, monkeypatch: pytest.MonkeyPatch) -> None:
        def mock_request(method, url, **kwargs):
            assert kwargs.get("params", {}).get("actor_id") == "user_1"
            return httpx.Response(200, json={
                "data": [{"id": "evt_1", "action": "doc.created"}],
                "pagination": {"has_more": False, "next_cursor": None, "total": 1},
            })

        monkeypatch.setattr(httpx, "request", mock_request)
        client = ImmutableClient(api_key="imk_test", base_url=BASE)

        result = client.get_events(actor_id="user_1")
        assert len(result["data"]) == 1
        assert result["pagination"]["has_more"] is False


class TestGetEvent:
    def test_returns_event_with_integrity(self, monkeypatch: pytest.MonkeyPatch) -> None:
        def mock_request(*args, **kwargs):
            return httpx.Response(200, json={
                "data": {
                    "id": "evt_1",
                    "actor": {"id": "user_1", "name": "Sarah", "type": None},
                    "action": "doc.created",
                    "integrity": {"event_hash": "abc123", "previous_event_hash": None},
                },
            })

        monkeypatch.setattr(httpx, "request", mock_request)
        client = ImmutableClient(api_key="imk_test", base_url=BASE)

        result = client.get_event("evt_1")
        assert result["data"]["integrity"]["event_hash"] == "abc123"


class TestVerify:
    def test_valid_chain(self, monkeypatch: pytest.MonkeyPatch) -> None:
        def mock_request(*args, **kwargs):
            return httpx.Response(200, json={
                "data": {"valid": True, "events_checked": 500, "breaks": []},
            })

        monkeypatch.setattr(httpx, "request", mock_request)
        client = ImmutableClient(api_key="imk_test", base_url=BASE)

        result = client.verify()
        assert result["data"]["valid"] is True
        assert result["data"]["events_checked"] == 500

    def test_invalid_chain(self, monkeypatch: pytest.MonkeyPatch) -> None:
        def mock_request(*args, **kwargs):
            return httpx.Response(200, json={
                "data": {
                    "valid": False,
                    "events_checked": 500,
                    "breaks": [{"event_id": "evt_1", "type": "hash_mismatch"}],
                },
            })

        monkeypatch.setattr(httpx, "request", mock_request)
        client = ImmutableClient(api_key="imk_test", base_url=BASE)

        result = client.verify()
        assert result["data"]["valid"] is False
        assert len(result["data"]["breaks"]) == 1

    def test_verify_with_limit(self, monkeypatch: pytest.MonkeyPatch) -> None:
        def mock_request(method, url, **kwargs):
            assert kwargs.get("params", {}).get("limit") == 100
            return httpx.Response(200, json={
                "data": {"valid": True, "events_checked": 100, "breaks": []},
            })

        monkeypatch.setattr(httpx, "request", mock_request)
        client = ImmutableClient(api_key="imk_test", base_url=BASE)

        result = client.verify(limit=100)
        assert result["data"]["events_checked"] == 100


class TestViewerToken:
    def test_creates_token(self, monkeypatch: pytest.MonkeyPatch) -> None:
        def mock_request(*args, **kwargs):
            return httpx.Response(200, json={"token": "jwt_test", "expires_at": 1774537200})

        monkeypatch.setattr(httpx, "request", mock_request)
        client = ImmutableClient(api_key="imk_test", base_url=BASE)

        result = client.create_viewer_token(tenant_id="org_1", ttl=3600)
        assert result["token"] == "jwt_test"
        assert result["expires_at"] == 1774537200


class TestAlerts:
    def test_query_alerts(self, monkeypatch: pytest.MonkeyPatch) -> None:
        def mock_request(*args, **kwargs):
            return httpx.Response(200, json={
                "data": [{"id": "alert_1", "rule_type": "new_country", "reason": "Login from GB"}],
                "pagination": {"has_more": False, "next_cursor": None, "total": 1},
            })

        monkeypatch.setattr(httpx, "request", mock_request)
        client = ImmutableClient(api_key="imk_test", base_url=BASE)

        result = client.get_alerts(rule_type="new_country")
        assert len(result["data"]) == 1
        assert result["pagination"]["total"] == 1


class TestExports:
    def test_create_export(self, monkeypatch: pytest.MonkeyPatch) -> None:
        def mock_request(*args, **kwargs):
            return httpx.Response(202, json={"data": {"id": "exp_1", "status": "pending"}})

        monkeypatch.setattr(httpx, "request", mock_request)
        client = ImmutableClient(api_key="imk_test", base_url=BASE)

        result = client.create_export(actor_id="user_1")
        assert result["data"]["id"] == "exp_1"
        assert result["data"]["status"] == "pending"

    def test_get_export(self, monkeypatch: pytest.MonkeyPatch) -> None:
        def mock_request(*args, **kwargs):
            return httpx.Response(200, json={
                "data": {
                    "id": "exp_1",
                    "status": "completed",
                    "total_rows": 1247,
                    "download_url": "https://example.com/download",
                },
            })

        monkeypatch.setattr(httpx, "request", mock_request)
        client = ImmutableClient(api_key="imk_test", base_url=BASE)

        result = client.get_export("exp_1")
        assert result["data"]["status"] == "completed"
        assert result["data"]["total_rows"] == 1247


class TestErrorHandling:
    def test_401_raises_error(self, monkeypatch: pytest.MonkeyPatch) -> None:
        def mock_request(*args, **kwargs):
            return httpx.Response(401, json={"error": "Invalid API key"})

        monkeypatch.setattr(httpx, "request", mock_request)
        client = ImmutableClient(api_key="imk_bad", base_url=BASE)

        with pytest.raises(ImmutableError) as exc_info:
            client.track({"actor_id": "user_1", "action": "test"})

        assert exc_info.value.status_code == 401
        assert "Invalid API key" in str(exc_info.value)

    def test_422_raises_error(self, monkeypatch: pytest.MonkeyPatch) -> None:
        def mock_request(*args, **kwargs):
            return httpx.Response(422, json={"message": "Validation failed", "errors": {"action": ["required"]}})

        monkeypatch.setattr(httpx, "request", mock_request)
        client = ImmutableClient(api_key="imk_test", base_url=BASE)

        with pytest.raises(ImmutableError) as exc_info:
            client.track({"actor_id": "user_1"})

        assert exc_info.value.status_code == 422

    def test_timeout_raises_error(self, monkeypatch: pytest.MonkeyPatch) -> None:
        def mock_request(*args, **kwargs):
            raise httpx.ReadTimeout("timed out")

        monkeypatch.setattr(httpx, "request", mock_request)
        client = ImmutableClient(api_key="imk_test", base_url=BASE, timeout=0.001)

        with pytest.raises(ImmutableError, match="timed out"):
            client.track({"actor_id": "user_1", "action": "test"})


class TestPendingEvent:
    def test_fluent_builder(self, monkeypatch: pytest.MonkeyPatch) -> None:
        captured: dict = {}

        def mock_request(method, url, **kwargs):
            captured["body"] = kwargs.get("json", {})
            return httpx.Response(202, json={"id": "evt_1", "status": "queued"})

        monkeypatch.setattr(httpx, "request", mock_request)
        client = ImmutableClient(api_key="imk_test", base_url=BASE)

        result = (
            client.actor("user_1", name="Sarah Chen", type="user")
            .idempotency_key("idem_1")
            .version(1)
            .session("sess_abc")
            .action_category("documents")
            .target("folder", "folder_1", "Reports")
            .track("document.created", "document", {"size": 1024})
        )

        assert result["status"] == "queued"
        body = captured["body"]
        assert body["actor_id"] == "user_1"
        assert body["actor_name"] == "Sarah Chen"
        assert body["actor_type"] == "user"
        assert body["action"] == "document.created"
        assert body["resource"] == "document"
        assert body["idempotency_key"] == "idem_1"
        assert body["version"] == 1
        assert body["session_id"] == "sess_abc"
        assert body["action_category"] == "documents"
        assert body["metadata"] == {"size": 1024}
        assert len(body["targets"]) == 1
        assert body["targets"][0]["type"] == "folder"

    def test_minimal_builder(self, monkeypatch: pytest.MonkeyPatch) -> None:
        captured: dict = {}

        def mock_request(method, url, **kwargs):
            captured["body"] = kwargs.get("json", {})
            return httpx.Response(202, json={"id": "evt_1", "status": "queued"})

        monkeypatch.setattr(httpx, "request", mock_request)
        client = ImmutableClient(api_key="imk_test", base_url=BASE)

        client.actor("user_1").track("login")

        body = captured["body"]
        assert body["actor_id"] == "user_1"
        assert body["action"] == "login"
        assert "actor_name" not in body
        assert "actor_type" not in body
        assert "targets" not in body


    def test_resource_as_dict(self, monkeypatch: pytest.MonkeyPatch) -> None:
        captured: dict = {}

        def mock_request(method, url, **kwargs):
            captured["body"] = kwargs.get("json", {})
            return httpx.Response(202, json={"id": "evt_1", "status": "queued"})

        monkeypatch.setattr(httpx, "request", mock_request)
        client = ImmutableClient(api_key="imk_test", base_url=BASE)

        client.actor("user_1").track(
            "document.created",
            {"type": "document", "id": "doc_456", "name": "Q4 Report"},
        )

        body = captured["body"]
        assert body["resource"] == "document"
        assert body["resource_id"] == "doc_456"
        assert body["resource_name"] == "Q4 Report"

    def test_empty_metadata_excluded(self, monkeypatch: pytest.MonkeyPatch) -> None:
        captured: dict = {}

        def mock_request(method, url, **kwargs):
            captured["body"] = kwargs.get("json", {})
            return httpx.Response(202, json={"id": "evt_1", "status": "queued"})

        monkeypatch.setattr(httpx, "request", mock_request)
        client = ImmutableClient(api_key="imk_test", base_url=BASE)

        client.actor("user_1").track("login", metadata={})

        body = captured["body"]
        assert "metadata" not in body


class TestAuthHeader:
    def test_sends_bearer_token(self, monkeypatch: pytest.MonkeyPatch) -> None:
        captured: dict = {}

        def mock_request(method, url, **kwargs):
            captured["headers"] = kwargs.get("headers", {})
            return httpx.Response(202, json={"id": "evt_1", "status": "queued"})

        monkeypatch.setattr(httpx, "request", mock_request)
        client = ImmutableClient(api_key="imk_my_key", base_url=BASE)

        client.track({"actor_id": "user_1", "action": "test"})
        assert captured["headers"]["Authorization"] == "Bearer imk_my_key"

    def test_url_construction(self, monkeypatch: pytest.MonkeyPatch) -> None:
        captured: dict = {}

        def mock_request(method, url, **kwargs):
            captured["url"] = str(url)
            return httpx.Response(202, json={"id": "evt_1", "status": "queued"})

        monkeypatch.setattr(httpx, "request", mock_request)
        client = ImmutableClient(api_key="imk_test", base_url="https://getimmutable.dev")

        client.track({"actor_id": "user_1", "action": "test"})
        assert captured["url"] == "https://getimmutable.dev/api/v1/events"
