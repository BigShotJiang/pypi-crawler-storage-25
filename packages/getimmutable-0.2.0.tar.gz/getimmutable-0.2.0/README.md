# getimmutable

Python SDK for the [Immutable](https://getimmutable.dev) audit log API. Tamper-evident audit logs for B2B SaaS.

## Installation

```bash
pip install getimmutable
```

Requires Python 3.10+.

## Quick Start

```python
from getimmutable import ImmutableClient

client = ImmutableClient(
    api_key="imk_your_api_key",
    base_url="https://getimmutable.dev",
)

# Fluent builder
client.actor("user_123", name="Sarah Chen") \
    .track("document.created", "document", {"size": 1024})

# Query events
events = client.get_events(actor_id="user_123")

# Verify chain integrity
result = client.verify()
print(result["data"]["valid"])  # True
```

## Documentation

Full documentation at [docs.getimmutable.dev/sdks/python](https://docs.getimmutable.dev/sdks/python).

## License

MIT
