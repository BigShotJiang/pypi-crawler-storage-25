"""Unit tests for the ``tts:playback`` event normalisation in
``CallEventStream._normalize_event``.

Mirrors test_audio_playback.py — same wire-format → typed-event mapping,
same drop-on-unknown-phase contract. The two events share most of the
parser machinery, so if one breaks the other should too.
"""

from __future__ import annotations

from typing import Any

from dvgateway.streams.call_events import CallEventStream
from dvgateway.types import InjectTtsResult, TtsPlaybackEvent


class _NoopLogger:
    def debug(self, ctx: dict, msg: str) -> None: ...
    def info(self, ctx: dict, msg: str) -> None: ...
    def warn(self, ctx: dict, msg: str) -> None: ...
    def error(self, ctx: dict, msg: str) -> None: ...


def _make_stream() -> CallEventStream:
    return CallEventStream(ws_pool=None, logger=_NoopLogger())  # type: ignore[arg-type]


def _normalize(raw: dict[str, Any]) -> Any:
    return _make_stream()._normalize_event(raw)


def test_complete_event_full_payload() -> None:
    raw = {
        "event": "tts:playback",
        "linkedId": "1777432210.78",
        "injectId": "tts-9f4c3e12",
        "phase": "complete",
        "durationMs": 2640,
        "errorReason": "",
        "tenantId": "tenant-xyz",
        "serverId": "gw-seoul-01",
        "ts": 1713779200123,
    }
    evt = _normalize(raw)
    assert isinstance(evt, TtsPlaybackEvent)
    assert evt.type == "tts:playback"
    assert evt.linked_id == "1777432210.78"
    assert evt.inject_id == "tts-9f4c3e12"
    assert evt.phase == "complete"
    assert evt.duration_ms == 2640
    assert evt.error_reason is None  # empty string normalised to None
    assert evt.tenant_id == "tenant-xyz"
    assert evt.server_id == "gw-seoul-01"


def test_start_phase_minimal_payload() -> None:
    """Start phase typically has no duration_ms — should still parse."""
    raw = {
        "event": "tts:playback",
        "linkedId": "lid",
        "injectId": "tts-1",
        "phase": "start",
    }
    evt = _normalize(raw)
    assert isinstance(evt, TtsPlaybackEvent)
    assert evt.phase == "start"
    assert evt.duration_ms is None
    assert evt.error_reason is None


def test_canceled_phase_carries_reason() -> None:
    """Each cancel reason from the gateway vocabulary should pass through."""
    for reason in ("preempted", "barge_in", "hangup", "user_request"):
        raw = {
            "event": "tts:playback",
            "linkedId": "lid",
            "injectId": "tts-1",
            "phase": "canceled",
            "durationMs": 519,
            "errorReason": reason,
        }
        evt = _normalize(raw)
        assert isinstance(evt, TtsPlaybackEvent), f"reason={reason} failed"
        assert evt.phase == "canceled"
        assert evt.error_reason == reason
        assert evt.duration_ms == 519


def test_failed_phase_carries_error_reason() -> None:
    raw = {
        "event": "tts:playback",
        "linkedId": "lid",
        "injectId": "tts-1",
        "phase": "failed",
        "durationMs": 1200,
        "errorReason": "channel_lost",
    }
    evt = _normalize(raw)
    assert isinstance(evt, TtsPlaybackEvent)
    assert evt.phase == "failed"
    assert evt.error_reason == "channel_lost"


def test_unknown_phase_is_dropped() -> None:
    raw = {
        "event": "tts:playback",
        "linkedId": "lid",
        "injectId": "tts-1",
        "phase": "garbage_phase",
    }
    assert _normalize(raw) is None


def test_all_terminal_phases_parse() -> None:
    for phase in ("start", "complete", "canceled", "failed"):
        raw = {
            "event": "tts:playback",
            "linkedId": "lid",
            "injectId": "tts-1",
            "phase": phase,
        }
        evt = _normalize(raw)
        assert isinstance(evt, TtsPlaybackEvent), f"phase={phase} failed"
        assert evt.phase == phase


def test_inject_tts_result_default_empty_id() -> None:
    """Legacy gateways (<1.3.9.3) don't surface inject_id — default empty."""
    r = InjectTtsResult()
    assert r.inject_id == ""
    r2 = InjectTtsResult(inject_id="tts-1")
    assert r2.inject_id == "tts-1"
