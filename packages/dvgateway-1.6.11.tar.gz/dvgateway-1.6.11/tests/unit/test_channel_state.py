"""Unit tests for the ``channel:state`` event normalisation in
``CallEventStream._normalize_event``.

We exercise the parser directly with a synthetic raw dict (the same shape the
gateway publishes over /api/v1/ws/callinfo) and assert the resulting
``ChannelStateChangeEvent`` dataclass mirrors the wire format.
"""

from __future__ import annotations

from typing import Any

from dvgateway.streams.call_events import CallEventStream
from dvgateway.types import ChannelStateChangeEvent


class _NoopLogger:
    def debug(self, ctx: dict, msg: str) -> None: ...
    def info(self, ctx: dict, msg: str) -> None: ...
    def warn(self, ctx: dict, msg: str) -> None: ...
    def error(self, ctx: dict, msg: str) -> None: ...


def _make_stream() -> CallEventStream:
    """Construct a CallEventStream with a None ws_pool — only _normalize_event
    is exercised, which doesn't touch the pool."""
    return CallEventStream(ws_pool=None, logger=_NoopLogger())  # type: ignore[arg-type]


def _normalize(raw: dict[str, Any]) -> Any:
    return _make_stream()._normalize_event(raw)


def test_b_leg_up_event_full_payload() -> None:
    """Canonical click-to-call B-leg answer event."""
    raw = {
        "event": "channel:state",
        "linkedId": "1777432210.78",
        "channelId": "1777432210.79",
        "leg": "b",
        "state": "up",
        "direction": "outbound",
        "sipResponseCode": 200,
        "did": "025550100",
        "caller": "01012345678",
        "callerName": "Hong Gildong",
        "callee": "1001",
        "tenantId": "tenant-xyz",
        "serverId": "gw-seoul-01",
        "ts": 1713779200123,
    }
    evt = _normalize(raw)
    assert isinstance(evt, ChannelStateChangeEvent)
    assert evt.type == "channel:state"
    assert evt.linked_id == "1777432210.78"
    assert evt.channel_id == "1777432210.79"
    assert evt.leg == "b"
    assert evt.state == "up"
    assert evt.direction == "outbound"
    assert evt.sip_response_code == 200
    assert evt.did == "025550100"
    assert evt.caller == "01012345678"
    assert evt.caller_name == "Hong Gildong"
    assert evt.callee == "1001"
    assert evt.tenant_id == "tenant-xyz"
    assert evt.server_id == "gw-seoul-01"


def test_identity_fields_omitted_by_legacy_gateway() -> None:
    """Gateways prior to v1.4.3.1 do not emit did/caller/callerName/callee on
    channel:state — the SDK must still parse the event and leave those
    fields as None for backward compatibility."""
    raw = {
        "event": "channel:state",
        "linkedId": "lid-legacy",
        "channelId": "ch-legacy",
        "leg": "b",
        "state": "up",
    }
    evt = _normalize(raw)
    assert isinstance(evt, ChannelStateChangeEvent)
    assert evt.did is None
    assert evt.caller is None
    assert evt.caller_name is None
    assert evt.callee is None


def test_empty_string_identity_fields_normalized_to_none() -> None:
    """Defensive: if a future gateway emits "" instead of omitting the field,
    the SDK normalises it to None so "value present" vs "absent" semantics
    remain unambiguous for downstream code."""
    raw = {
        "event": "channel:state",
        "linkedId": "lid-empty",
        "channelId": "ch-empty",
        "leg": "a",
        "state": "up",
        "did": "",
        "caller": "",
        "callerName": "",
        "callee": "",
    }
    evt = _normalize(raw)
    assert isinstance(evt, ChannelStateChangeEvent)
    assert evt.did is None
    assert evt.caller is None
    assert evt.caller_name is None
    assert evt.callee is None


def test_a_leg_ring_event_minimal_payload() -> None:
    """Ring on A-leg with no SIP code or tenant — should still parse."""
    raw = {
        "event": "channel:state",
        "linkedId": "1777432210.78",
        "channelId": "1777432210.78",
        "leg": "a",
        "state": "ring",
    }
    evt = _normalize(raw)
    assert isinstance(evt, ChannelStateChangeEvent)
    assert evt.leg == "a"
    assert evt.state == "ring"
    assert evt.sip_response_code is None
    assert evt.tenant_id is None
    assert evt.direction == "outbound"  # default


def test_terminal_failure_states_parse() -> None:
    """All terminal failure states must round-trip."""
    for state in ("busy", "no_answer", "rejected", "down"):
        raw = {
            "event": "channel:state",
            "linkedId": "lid",
            "channelId": "ch",
            "leg": "b",
            "state": state,
        }
        evt = _normalize(raw)
        assert isinstance(evt, ChannelStateChangeEvent), f"state={state} failed to parse"
        assert evt.state == state


def test_unknown_state_is_dropped() -> None:
    """States outside the documented enum return None — caller drops the event."""
    raw = {
        "event": "channel:state",
        "linkedId": "lid",
        "channelId": "ch",
        "leg": "b",
        "state": "garbage_state",
    }
    assert _normalize(raw) is None


def test_invalid_leg_defaults_to_a() -> None:
    """Unknown leg values default to 'a' (not 'b' — defensive: don't fire
    spurious B-leg-answered handlers on malformed events)."""
    raw = {
        "event": "channel:state",
        "linkedId": "lid",
        "channelId": "ch",
        "leg": "z",
        "state": "up",
    }
    evt = _normalize(raw)
    assert isinstance(evt, ChannelStateChangeEvent)
    assert evt.leg == "a"


def test_inbound_direction_preserved() -> None:
    raw = {
        "event": "channel:state",
        "linkedId": "lid",
        "channelId": "ch",
        "leg": "a",
        "state": "up",
        "direction": "inbound",
    }
    evt = _normalize(raw)
    assert isinstance(evt, ChannelStateChangeEvent)
    assert evt.direction == "inbound"


def test_zero_sip_response_code_normalised_to_none() -> None:
    """Gateway emits sipResponseCode=0 when unknown. SDK normalises it to None
    so application code can use a simple ``if event.sip_response_code:`` check."""
    raw = {
        "event": "channel:state",
        "linkedId": "lid",
        "channelId": "ch",
        "leg": "b",
        "state": "up",
        "sipResponseCode": 0,
    }
    evt = _normalize(raw)
    assert isinstance(evt, ChannelStateChangeEvent)
    assert evt.sip_response_code is None
