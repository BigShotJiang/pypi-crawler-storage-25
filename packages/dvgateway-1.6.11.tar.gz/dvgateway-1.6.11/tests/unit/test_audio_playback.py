"""Unit tests for the ``audio:playback`` event normalisation in
``CallEventStream._normalize_event``.

We exercise the parser directly with a synthetic raw dict (the same shape the
gateway publishes over /api/v1/ws/callinfo) and assert the resulting
``AudioPlaybackEvent`` dataclass mirrors the wire format.
"""

from __future__ import annotations

from typing import Any

from dvgateway.streams.call_events import CallEventStream
from dvgateway.types import AudioPlaybackEvent


class _NoopLogger:
    def debug(self, ctx: dict, msg: str) -> None: ...
    def info(self, ctx: dict, msg: str) -> None: ...
    def warn(self, ctx: dict, msg: str) -> None: ...
    def error(self, ctx: dict, msg: str) -> None: ...


def _make_stream() -> CallEventStream:
    return CallEventStream(ws_pool=None, logger=_NoopLogger())  # type: ignore[arg-type]


def _normalize(raw: dict[str, Any]) -> Any:
    return _make_stream()._normalize_event(raw)


def test_complete_event_full_payload() -> None:
    raw = {
        "event": "audio:playback",
        "linkedId": "1777432210.78",
        "playbackId": "pb-9f4c3e12",
        "url": "https://cdn.example.com/menu.wav",
        "phase": "complete",
        "durationMs": 4860,
        "errorReason": "",
        "tenantId": "tenant-xyz",
        "serverId": "gw-seoul-01",
        "ts": 1713779200123,
    }
    evt = _normalize(raw)
    assert isinstance(evt, AudioPlaybackEvent)
    assert evt.type == "audio:playback"
    assert evt.linked_id == "1777432210.78"
    assert evt.playback_id == "pb-9f4c3e12"
    assert evt.url == "https://cdn.example.com/menu.wav"
    assert evt.phase == "complete"
    assert evt.duration_ms == 4860
    assert evt.error_reason is None  # empty string normalised to None
    assert evt.tenant_id == "tenant-xyz"
    assert evt.server_id == "gw-seoul-01"


def test_start_phase_minimal_payload() -> None:
    """Start phase typically has no duration_ms — should still parse."""
    raw = {
        "event": "audio:playback",
        "linkedId": "lid",
        "playbackId": "pb-1",
        "url": "https://example.com/a.wav",
        "phase": "start",
    }
    evt = _normalize(raw)
    assert isinstance(evt, AudioPlaybackEvent)
    assert evt.phase == "start"
    assert evt.duration_ms is None
    assert evt.error_reason is None


def test_failed_phase_carries_error_reason() -> None:
    raw = {
        "event": "audio:playback",
        "linkedId": "lid",
        "playbackId": "pb-1",
        "url": "https://example.com/missing.wav",
        "phase": "failed",
        "durationMs": 0,
        "errorReason": "fetch_failed",
    }
    evt = _normalize(raw)
    assert isinstance(evt, AudioPlaybackEvent)
    assert evt.phase == "failed"
    assert evt.error_reason == "fetch_failed"


def test_canceled_phase_with_partial_duration() -> None:
    raw = {
        "event": "audio:playback",
        "linkedId": "lid",
        "playbackId": "pb-1",
        "url": "url",
        "phase": "canceled",
        "durationMs": 1200,
    }
    evt = _normalize(raw)
    assert isinstance(evt, AudioPlaybackEvent)
    assert evt.phase == "canceled"
    assert evt.duration_ms == 1200


def test_unknown_phase_is_dropped() -> None:
    raw = {
        "event": "audio:playback",
        "linkedId": "lid",
        "playbackId": "pb-1",
        "url": "url",
        "phase": "garbage_phase",
    }
    assert _normalize(raw) is None


def test_all_terminal_phases_parse() -> None:
    for phase in ("start", "complete", "canceled", "failed"):
        raw = {
            "event": "audio:playback",
            "linkedId": "lid",
            "playbackId": "pb-1",
            "url": "url",
            "phase": phase,
        }
        evt = _normalize(raw)
        assert isinstance(evt, AudioPlaybackEvent), f"phase={phase} failed"
        assert evt.phase == phase


def test_play_audio_result_carries_playback_id() -> None:
    """Smoke test for the PlayAudioResult dataclass — playback_id default is
    empty string so legacy gateways (no playbackId in response) still work."""
    from dvgateway.types import PlayAudioResult

    r = PlayAudioResult()
    assert r.playback_id == ""
    r2 = PlayAudioResult(completed=True, duration_ms=4860, playback_id="pb-1")
    assert r2.playback_id == "pb-1"
