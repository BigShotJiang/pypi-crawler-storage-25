"""Unit tests for DVGatewayClient.warm_transfer.

A stub HTTP client stands in for the gateway so REST calls are captured
but never touch a network. Mirrors the approach used in
``test_play_audio.py``.
"""

from __future__ import annotations

import base64
from dataclasses import dataclass
from typing import Any, AsyncIterable

import pytest

from dvgateway.client import DVGatewayClient
from dvgateway.types import TtsAdapter, TtsOptions, WarmTransferResult


@dataclass
class _StubResponse:
    status: int = 200
    data: Any = None


class _StubHttp:
    """Records HTTP calls and returns canned responses."""

    def __init__(self, post_response: Any = None) -> None:
        self.posts: list[tuple[str, Any]] = []
        self._post_response = post_response or {}

    async def post(self, path: str, body: Any = None) -> Any:
        self.posts.append((path, body))
        return _StubResponse(status=200, data=self._post_response)


class _NoopLogger:
    def debug(self, *a, **k): pass
    def info(self, *a, **k): pass
    def warn(self, *a, **k): pass
    def error(self, *a, **k): pass


def _make_client(post_response: Any = None) -> tuple[DVGatewayClient, _StubHttp]:
    gw = DVGatewayClient.__new__(DVGatewayClient)  # bypass __init__
    http = _StubHttp(post_response=post_response)
    gw._http = http  # type: ignore[assignment]
    gw._logger = _NoopLogger()  # type: ignore[assignment]
    return gw, http


@pytest.mark.asyncio
async def test_warm_transfer_connects() -> None:
    gw, http = _make_client(
        post_response={
            "connected": True,
            "timedOut": False,
            "error": "",
            "agentChannel": "PJSIP/1001-00000042",
            "bridgeId": "bridge-xyz",
            "whisperPlayed": False,
        }
    )

    result = await gw.warm_transfer(
        "call-a",
        destination="1001",
        whisper_text="VIP 고객입니다",
        hold_audio_url="https://cdn.example.com/hold.mp3",
        timeout_ms=30_000,
    )

    assert isinstance(result, WarmTransferResult)
    assert result.connected is True
    assert result.timed_out is False
    assert result.error is None  # empty string → None
    assert result.agent_channel == "PJSIP/1001-00000042"
    assert result.bridge_id == "bridge-xyz"
    assert result.whisper_played is False

    assert len(http.posts) == 1
    path, body = http.posts[0]
    assert path == "/api/v1/transfer/warm/call-a"
    assert body == {
        "destination": "1001",
        "timeoutMs": 30_000,
        "context": "from-internal",
        "whisperText": "VIP 고객입니다",
        "holdAudioUrl": "https://cdn.example.com/hold.mp3",
    }


@pytest.mark.asyncio
async def test_warm_transfer_timeout() -> None:
    gw, _http = _make_client(
        post_response={
            "connected": False,
            "timedOut": True,
            "error": "no_answer",
            "agentChannel": "",
            "bridgeId": "",
            "whisperPlayed": False,
        }
    )

    result = await gw.warm_transfer(
        "call-b",
        destination="1002",
        timeout_ms=5_000,
    )
    assert result.connected is False
    assert result.timed_out is True
    assert result.error == "no_answer"
    assert result.agent_channel is None
    assert result.bridge_id is None
    assert result.whisper_played is False


@pytest.mark.asyncio
async def test_warm_transfer_error_response() -> None:
    gw, _http = _make_client(
        post_response={
            "connected": False,
            "timedOut": False,
            "error": "originate_failed",
            "agentChannel": "",
            "bridgeId": "",
            "whisperPlayed": False,
        }
    )

    result = await gw.warm_transfer(
        "call-c",
        destination="1003",
    )
    assert result.connected is False
    assert result.timed_out is False
    assert result.error == "originate_failed"
    assert result.agent_channel is None
    assert result.bridge_id is None


@pytest.mark.asyncio
async def test_warm_transfer_empty_destination_raises() -> None:
    gw, _http = _make_client()
    with pytest.raises(ValueError):
        await gw.warm_transfer("call-d", destination="")


@pytest.mark.asyncio
async def test_warm_transfer_invalid_timeout_raises() -> None:
    gw, _http = _make_client()
    with pytest.raises(ValueError):
        await gw.warm_transfer("call-e", destination="1004", timeout_ms=0)


# ─── whisper_tts (SDK-side TTS synthesis) ────────────────────────────────


class _StubTtsAdapter(TtsAdapter):
    """Yields the provided fake PCM bytes in fixed chunks."""

    def __init__(self, pcm: bytes, chunk_size: int = 4) -> None:
        self._pcm = pcm
        self._chunk_size = chunk_size
        self.synthesize_calls: list[str] = []

    async def synthesize(
        self, text: str, options: TtsOptions | None = None
    ) -> AsyncIterable[bytes]:
        self.synthesize_calls.append(text)
        for i in range(0, len(self._pcm), self._chunk_size):
            yield self._pcm[i : i + self._chunk_size]


@pytest.mark.asyncio
async def test_warm_transfer_with_whisper_tts_uploads_base64_pcm() -> None:
    """Supplying whisper_tts should synthesize locally and ship base64 PCM.

    The gateway never sees whisperText alone in this path — it sees
    whisperPcm (preferred) and may also see whisperText for logs/CDR.
    """
    fake_pcm = b"\x00\x01\x00\x02\x00\x03\x00\x04\x00\x05\x00\x06"
    tts = _StubTtsAdapter(fake_pcm, chunk_size=4)
    gw, http = _make_client(
        post_response={
            "connected": True,
            "agentChannel": "PJSIP/1001-1",
            "bridgeId": "br-1",
            "whisperPlayed": True,
        }
    )

    result = await gw.warm_transfer(
        "call-tts",
        destination="01026132471",
        whisper_text="VIP 고객 연결",
        whisper_tts=tts,
        outbound=True,
        context="cos-all",
    )

    # SDK should have asked the adapter to synthesize.
    assert tts.synthesize_calls == ["VIP 고객 연결"]

    # Gateway should have received base64-encoded PCM matching the adapter
    # output exactly (chunks concatenated).
    assert len(http.posts) == 1
    _, body = http.posts[0]
    assert "whisperPcm" in body, f"body missing whisperPcm: {body}"
    decoded = base64.b64decode(body["whisperPcm"])
    assert decoded == fake_pcm

    # whisperText is still forwarded — gateway uses it for logs / CDR even
    # when PCM wins precedence-wise.
    assert body["whisperText"] == "VIP 고객 연결"
    assert result.whisper_played is True


@pytest.mark.asyncio
async def test_warm_transfer_whisper_tts_without_text_is_noop() -> None:
    """Supplying whisper_tts but no whisper_text must not synthesize."""
    tts = _StubTtsAdapter(b"\x00\x01\x00\x02", chunk_size=4)
    gw, http = _make_client(
        post_response={"connected": True, "whisperPlayed": False}
    )

    await gw.warm_transfer(
        "call-tts-no-text",
        destination="1001",
        whisper_tts=tts,
    )

    assert tts.synthesize_calls == []
    _, body = http.posts[0]
    assert "whisperPcm" not in body
    assert "whisperText" not in body


@pytest.mark.asyncio
async def test_warm_transfer_empty_pcm_omits_field() -> None:
    """If the adapter yields no bytes, whisperPcm must NOT be sent.

    Empty PCM in the body would cause the gateway to fail with
    bad_pcm_format. Better to leave the field off and let the gateway
    surface no_request / no_tts_provider depending on whisperText.
    """
    tts = _StubTtsAdapter(b"", chunk_size=4)
    gw, http = _make_client(
        post_response={
            "connected": True,
            "whisperPlayed": False,
            "whisperSkipReason": "no_tts_provider",
        }
    )

    result = await gw.warm_transfer(
        "call-empty-pcm",
        destination="1001",
        whisper_text="should fall back to gateway TTS",
        whisper_tts=tts,
    )

    _, body = http.posts[0]
    assert "whisperPcm" not in body
    assert body["whisperText"] == "should fall back to gateway TTS"
    assert result.whisper_skip_reason == "no_tts_provider"


@pytest.mark.asyncio
async def test_warm_transfer_propagates_whisper_skip_reason() -> None:
    """The new whisperSkipReason field round-trips into WarmTransferResult."""
    gw, _http = _make_client(
        post_response={
            "connected": True,
            "agentChannel": "PJSIP/1001-1",
            "bridgeId": "br-2",
            "whisperPlayed": False,
            "whisperSkipReason": "synthesize_failed",
        }
    )

    result = await gw.warm_transfer(
        "call-fail",
        destination="1001",
        whisper_text="this will fail synthesis",
    )

    assert result.connected is True
    assert result.whisper_played is False
    assert result.whisper_skip_reason == "synthesize_failed"


@pytest.mark.asyncio
async def test_warm_transfer_skip_reason_empty_normalized_to_none() -> None:
    """Empty-string skip reason must surface as None (parity with other fields)."""
    gw, _http = _make_client(
        post_response={
            "connected": True,
            "whisperPlayed": True,
            "whisperSkipReason": "",  # gateway sets when whisper played
        }
    )

    result = await gw.warm_transfer("call-ok", destination="1001")
    assert result.whisper_skip_reason is None
