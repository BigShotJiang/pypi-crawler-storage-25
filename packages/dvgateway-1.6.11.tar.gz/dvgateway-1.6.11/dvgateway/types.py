"""
DVGateway SDK — Public Type Definitions

Core types for interacting with the DVGateway real-time voice media gateway.
All adapters and pipeline components are built on these interfaces.
"""

from __future__ import annotations

import abc
from dataclasses import dataclass, field
from datetime import datetime
from typing import (
    Any,
    AsyncIterable,
    Awaitable,
    Callable,
    Generic,
    Literal,
    Protocol,
    TypeVar,
)

# ─── Authentication ────────────────────────────────────────────────────────


@dataclass(frozen=True)
class ApiKeyAuth:
    type: Literal["apiKey"] = "apiKey"
    api_key: str = ""


@dataclass(frozen=True)
class JwtAuth:
    type: Literal["jwt"] = "jwt"
    token: str = ""


Auth = ApiKeyAuth | JwtAuth

# ─── Reconnection ──────────────────────────────────────────────────────────


@dataclass
class ReconnectOptions:
    """WebSocket reconnection strategy."""

    max_attempts: int = 10
    initial_delay_ms: int = 2000
    max_delay_ms: int = 30_000
    backoff_multiplier: float = 2.0
    on_reconnect: Callable[[int], None] | None = None
    on_max_attempts_reached: Callable[[], None] | None = None


# ─── Security ─────────────────────────────────────────────────────────────


@dataclass
class MtlsOptions:
    cert: bytes = b""
    key: bytes = b""
    ca: bytes | None = None


@dataclass
class SecurityOptions:
    mask_pii: bool = True
    mtls: MtlsOptions | None = None
    force_tls: bool = True


# ─── Client Options ────────────────────────────────────────────────────────


@dataclass
class DVGatewayOptions:
    """Options for creating a DVGatewayClient instance."""

    base_url: str = "http://localhost:8080"
    auth: Auth = field(default_factory=lambda: ApiKeyAuth(api_key="dev-no-auth"))
    tenant_id: str | None = None
    timeout: int = 30_000
    reconnect: ReconnectOptions = field(default_factory=ReconnectOptions)
    security: SecurityOptions = field(default_factory=SecurityOptions)
    logger: Logger | None = None


# ─── Session ──────────────────────────────────────────────────────────────

StreamDir = Literal["both", "in", "out"]


@dataclass
class CallSession:
    """A 1:1 call session."""

    linked_id: str = ""
    conf_id: str | None = None
    dir: StreamDir = "both"
    caller: str | None = None
    """Caller phone number (CALLERID(num)), e.g. '01012345678'."""
    caller_name: str | None = None
    """Caller display name (CALLERID(name)), e.g. '홍길동'."""
    callee: str | None = None
    """Called number (EXTEN / B-leg), e.g. '025001000'."""
    did: str | None = None
    """DID (Direct Inward Dialing) main number."""
    call_id: str | None = None
    """Business system call ID (from ARI args)."""
    agent_number: str | None = None
    """Agent extension number."""
    started_at: datetime = field(default_factory=datetime.now)
    stream_url: str = ""
    tenant_id: str | None = None
    server_id: str | None = None
    """Gateway server ID (multi-server deployments)."""
    custom_value_1: str | None = None
    """User-defined custom variable 1 (dialplan CUSTOM_VALUE_01)."""
    custom_value_2: str | None = None
    """User-defined custom variable 2 (dialplan CUSTOM_VALUE_02)."""
    custom_value_3: str | None = None
    """User-defined custom variable 3 (dialplan CUSTOM_VALUE_03)."""
    metadata: dict[str, str] | None = None


@dataclass
class ConferenceParticipant:
    linked_id: str = ""
    caller: str | None = None
    joined_at: datetime = field(default_factory=datetime.now)


@dataclass
class ConferenceSession:
    conf_id: str = ""
    tenant_id: str | None = None
    server_id: str | None = None
    participants: list[ConferenceParticipant] = field(default_factory=list)
    started_at: datetime = field(default_factory=datetime.now)
    metadata: dict[str, str] | None = None


# ─── Call Events ──────────────────────────────────────────────────────────


@dataclass(frozen=True)
class CallNewEvent:
    type: Literal["call:new"] = "call:new"
    session: CallSession = field(default_factory=CallSession)
    tenant_id: str | None = None
    timestamp: datetime = field(default_factory=datetime.now)


@dataclass(frozen=True)
class CallEndedEvent:
    type: Literal["call:ended"] = "call:ended"
    linked_id: str = ""
    duration_sec: float = 0.0
    timestamp: datetime = field(default_factory=datetime.now)


@dataclass(frozen=True)
class ConfJoinEvent:
    type: Literal["conf:join"] = "conf:join"
    linked_id: str = ""
    conf_id: str = ""
    caller: str | None = None
    timestamp: datetime = field(default_factory=datetime.now)


@dataclass(frozen=True)
class ConfLeaveEvent:
    type: Literal["conf:leave"] = "conf:leave"
    linked_id: str = ""
    conf_id: str = ""
    timestamp: datetime = field(default_factory=datetime.now)


@dataclass(frozen=True)
class ConfEndedEvent:
    type: Literal["conf:ended"] = "conf:ended"
    conf_id: str = ""
    timestamp: datetime = field(default_factory=datetime.now)


@dataclass(frozen=True)
class TTSCompleteEvent:
    """Fired when the gateway's TTS Player finishes injecting a Play() session
    into the call's Asterisk channel.

    Semantics:
      - Fires exactly once per Player.Play() end (normal EOF, explicit stop,
        or concurrent preemption; stale sessions are suppressed by the gateway).
      - Means the gateway has written ALL PCM frames, including the fade-out
        trailer, to Asterisk. A small RTP-side buffer (~20-40ms) still
        separates this from actual audio reaching the caller's phone, which
        is negligible for IVR / voice-bot turn management.

    Use cases:
      - Wait for AI reply to finish before unmuting caller VAD.
      - Chain sequential TTS messages without overlap (greeting → menu).
      - Log accurate playback-complete timestamps for latency analysis.

    Wire format (from /api/v1/ws/callinfo)::

        {"event":"tts:complete","linkedId":"...","tenantId":"...","serverId":"..."}
    """
    type: Literal["tts:complete"] = "tts:complete"
    linked_id: str = ""
    tenant_id: str | None = None
    server_id: str | None = None
    timestamp: datetime = field(default_factory=datetime.now)


@dataclass(frozen=True)
class ChannelStateChangeEvent:
    """Fired when an Asterisk channel transitions through a state worth surfacing
    to SDK consumers — primarily for **B-leg answer detection in click-to-call
    outbound flows**.

    Use case: in 2-leg outbound (where A-leg is auto-answered immediately via
    ``EXEC_AA=yes`` and B-leg rings until the callee picks up), the gateway
    starts emitting RTP frames the moment A-leg is up — well before B-leg
    answers. Application code that triggers a greeting TTS on the first RTP
    chunk plays it during ringback, where the callee can't hear it. Subscribe
    to ``channel:state`` and wait for ``leg=="b"`` and ``state=="up"`` to start
    the greeting at the correct instant.

    Wire format (from /api/v1/ws/callinfo)::

        {
          "event":           "channel:state",
          "linkedId":        "1777432210.78",
          "channelId":       "1777432210.79",
          "leg":             "b",
          "state":           "up",
          "direction":       "outbound",
          "sipResponseCode": 200,
          "tenantId":        "tenant-xyz",
          "serverId":        "gw-seoul-01",
          "ts":              1713779200123
        }

    Source events in the gateway:

    - AMI Newstate (ChannelStateDesc Ring/Ringing/Up/Down)         → state ring/up/down
    - AMI DialEnd  (DialStatus BUSY/NOANSWER/CANCEL/CHANUNAVAIL...) → state busy/no_answer/rejected

    Leg semantics:

    - ``"a"``: originating channel — the side our PBX created. For click-to-call
      this is our agent / IVR side that auto-answered.
    - ``"b"``: any subsequent channel created via Dial/Originate that shares the
      same ``linkedId``. For click-to-call this is the external callee.
      Multi-leg flows (e.g. agent re-attempts) collapse to all subsequent legs
      being ``"b"`` — disambiguate via ``channel_id`` if needed.

    Field semantics:

    - ``state``: monotonic per leg — ``ring → up`` or ``ring → busy/no_answer/rejected``.
      ``down`` may follow any of the above when the channel is destroyed.
    - ``sip_response_code``: optional. ``0`` when not yet captured by the
      gateway. Future enrichment via dialplan vars / Hangup cause mapping
      will populate it for diagnostic / billing-exclusion use cases.
    - ``ts``: gateway-side wall-clock at publish time (unix millis). Use for
      ringback duration / time-to-answer analytics.

    Example::

        async def on_state(event: ChannelStateChangeEvent) -> None:
            if event.leg == "b" and event.state == "up":
                # B-leg answered — safe to start greeting now
                await gw.inject_tts(event.linked_id, greeting_audio())

        gw.on_channel_state(on_state)
    """
    type: Literal["channel:state"] = "channel:state"
    linked_id: str = ""
    channel_id: str = ""
    leg: Literal["a", "b"] = "a"
    state: Literal["ring", "up", "down", "busy", "no_answer", "rejected"] = "ring"
    direction: Literal["inbound", "outbound"] = "outbound"
    sip_response_code: int | None = None
    # Identity fields — gateway v1.4.3.1+. Older gateways omit these via the
    # wire `omitempty` tag, so each is independently optional. Early Newstate
    # events that fire before `call:new` registers the session may also leave
    # these as None even on a new gateway. SDK 1.6.8+.
    did: str | None = None
    caller: str | None = None  # CALLERID(num)
    caller_name: str | None = None  # CALLERID(name) — empty when carrier omits
    callee: str | None = None  # EXTEN / B-leg number
    tenant_id: str | None = None
    server_id: str | None = None
    timestamp: datetime = field(default_factory=datetime.now)


@dataclass(frozen=True)
class CallDtmfEvent:
    """Fired when the gateway receives an AMI DTMFBegin / DTMFEnd event.

    Phase is ``"begin"`` (caller just pressed the digit) or ``"end"`` (caller
    released it — ``duration_ms`` is populated).

    Wire format (from /api/v1/ws/callinfo)::

        {
          "event":      "call:dtmf",
          "linkedId":   "1775805184.495",
          "digit":      "1",
          "phase":      "end",
          "durationMs": 120,
          "direction":  "received",
          "tenantId":   "tenant-xyz",
          "serverId":   "gw-seoul-01",
          "ts":         1713779200123
        }

    Gateway env controls:
      - ``GW_DTMF_ENABLED`` (default ``true``) — master switch.
      - ``GW_DTMF_PHASE_FILTER`` (default ``"end"``) — set to ``"both"`` to
        also receive begin-phase events.
    """
    type: Literal["call:dtmf"] = "call:dtmf"
    linked_id: str = ""
    digit: str = ""
    phase: Literal["begin", "end"] = "end"
    duration_ms: int | None = None
    direction: Literal["received", "sent"] | None = None
    tenant_id: str | None = None
    server_id: str | None = None
    timestamp: datetime = field(default_factory=datetime.now)


@dataclass(frozen=True)
class AudioPlaybackEvent:
    """Fired across the lifecycle of a :meth:`DVGatewayClient.play_audio` call
    so application code can synchronise on **accurate** playback completion
    instead of estimating with hard-coded fallbacks (e.g. the legacy "+8s
    magic constant" pattern).

    Phase contract — exactly **one** terminal phase fires per playback:

    - ``"start"``     — gateway is about to pump PCM frames to Asterisk.
                        ``duration_ms`` is 0. Optional but cheap; useful as
                        a timeline anchor.
    - ``"complete"``  — all PCM frames written to Asterisk (full audio
                        played). ``duration_ms`` = wall-clock playback length.
    - ``"canceled"``  — caller invoked ``DELETE /api/v1/play/{linkedId}``
                        or DTMF interrupted via ``interrupt_on_dtmf=True``.
                        ``duration_ms`` = elapsed before stop took effect.
    - ``"failed"``    — gateway returned an error mid-playback.
                        ``error_reason`` classifies it for retry routing:

                        * ``"fetch_failed"``    — URL download/cache miss
                          (transient — application can retry).
                        * ``"decode_failed"``   — transcode error / bad
                          audio format (terminal — do not retry).
                        * ``"channel_lost"``    — RTP/WS to Asterisk dropped
                          mid-play (call probably hung up — terminal).
                        * ``"playback_failed"`` — generic player error.

    Use case — DTMF prompt audio with accurate timeout extension::

        playback_id = await gw.play_audio(linked_id, prompt_url, wait_for_completion=False)
        audio_done = asyncio.Event()
        actual_ms = 0

        async def on_pb(ev: AudioPlaybackEvent) -> None:
            nonlocal actual_ms
            if ev.playback_id != playback_id:
                return
            if ev.phase in ("complete", "canceled", "failed"):
                actual_ms = ev.duration_ms or 0
                audio_done.set()

        gw.on_audio_playback(on_pb)
        try:
            await asyncio.wait_for(audio_done.wait(), timeout=30.0)
            effective_timeout_ms = base_timeout_ms + actual_ms + 500  # accurate
        except asyncio.TimeoutError:
            effective_timeout_ms = base_timeout_ms + 8000  # conservative fallback

    Wire format (from /api/v1/ws/callinfo)::

        {
          "event":       "audio:playback",
          "linkedId":    "1777432210.78",
          "playbackId":  "9f4c3e12-…",
          "url":         "https://cdn.example.com/menu.wav",
          "phase":       "complete",
          "durationMs":  4860,
          "errorReason": "",
          "tenantId":    "tenant-xyz",
          "serverId":    "gw-seoul-01",
          "ts":          1713779200123
        }

    The ``playback_id`` is stable across all phases of one playback so
    application code can correlate start → complete/canceled/failed for the
    right session even when multiple audios play sequentially in the same call.
    """
    type: Literal["audio:playback"] = "audio:playback"
    linked_id: str = ""
    playback_id: str = ""
    url: str = ""
    phase: Literal["start", "complete", "canceled", "failed"] = "start"
    duration_ms: int | None = None
    error_reason: str | None = None
    tenant_id: str | None = None
    server_id: str | None = None
    timestamp: datetime = field(default_factory=datetime.now)


@dataclass(frozen=True)
class TtsPlaybackEvent:
    """Fired across the lifecycle of a :meth:`DVGatewayClient.inject_tts`
    call so application code can react to the *real* end of injected speech
    (start / complete / canceled / failed) without relying on the legacy
    ``tts:complete`` event that doesn't distinguish those cases.

    Phase contract — exactly **one** terminal phase fires per inject:

    - ``"start"``     — gateway is about to pump PCM frames to Asterisk.
                        ``duration_ms`` is 0. Optional but cheap; useful
                        as a timeline anchor.
    - ``"complete"``  — all PCM frames written to Asterisk (full audio
                        played). ``duration_ms`` = wall-clock playback
                        length, deterministic since the gateway ticker
                        runs at exactly 20ms (frame_count × 20).
    - ``"canceled"``  — playback was stopped before natural EOF.
                        ``error_reason`` classifies the cancel cause:

                        * ``"preempted"``     — a newer ``inject_tts`` call
                          arrived for the same call_id (most common).
                        * ``"barge_in"``      — gateway-side VAD detected
                          caller speech and stopped TTS automatically.
                        * ``"hangup"``        — the call ended mid-playback.
                        * ``"user_request"``  — DELETE /api/v1/tts/{lid}
                          or ``{"cmd":"stop"}`` over the WS.

                        ``duration_ms`` = elapsed before stop took effect.
    - ``"failed"``    — gateway returned an error mid-playback.
                        ``error_reason``:

                        * ``"channel_lost"``    — RTP/WS to Asterisk
                          dropped (call probably hung up — terminal).
                        * ``"playback_failed"`` — generic player error.

    Use case — **wait for the real end of injected speech**::

        playback_done = asyncio.Event()
        captured_phase: str = ""

        def on_tp(ev: TtsPlaybackEvent) -> None:
            nonlocal captured_phase
            if ev.linked_id != linked_id:
                return
            if ev.phase in ("complete", "canceled", "failed"):
                captured_phase = ev.phase
                playback_done.set()

        unsub = gw.on_tts_playback(on_tp)
        try:
            await gw.inject_tts(linked_id, audio_chunks)
            await playback_done.wait()
        finally:
            unsub()

    Pre-1.6.1 fallback — older SDKs / older gateways still see only
    ``tts:complete`` (legacy). Application code that wants forward-compat
    can ``hasattr(gw, 'on_tts_playback')`` and fall back to ``on_tts_complete``
    (which fires alongside the terminal phase).

    Wire format (from /api/v1/ws/callinfo)::

        {
          "event":       "tts:playback",
          "linkedId":    "1777432210.78",
          "injectId":    "tts-9f4c3e12-…",
          "phase":       "complete",
          "durationMs":  2640,
          "errorReason": "",
          "tenantId":    "tenant-xyz",
          "serverId":    "gw-seoul-01",
          "ts":          1713779200123
        }

    Available since SDK 1.6.1 (gateway v1.3.9.3+ required).
    """
    type: Literal["tts:playback"] = "tts:playback"
    linked_id: str = ""
    inject_id: str = ""
    phase: Literal["start", "complete", "canceled", "failed"] = "start"
    duration_ms: int | None = None
    error_reason: str | None = None
    tenant_id: str | None = None
    server_id: str | None = None
    timestamp: datetime = field(default_factory=datetime.now)


CallEvent = (
    CallNewEvent
    | CallEndedEvent
    | ConfJoinEvent
    | ConfLeaveEvent
    | ConfEndedEvent
    | TTSCompleteEvent
    | CallDtmfEvent
    | ChannelStateChangeEvent
    | AudioPlaybackEvent
    | TtsPlaybackEvent
)


# ─── DTMF Collection ──────────────────────────────────────────────────────


@dataclass(frozen=True)
class DTMFResult:
    """Result of :meth:`DVGatewayClient.collect_dtmf`.

    Semantics:
      - ``digits``: the sequence of DTMF digits received, excluding the
        terminator key (if any). Empty string when ``timed_out`` is True
        and nothing was received.
      - ``timed_out``: True when the first-key or inter-digit timeout
        elapsed before the completion condition was met. Note a collection
        that reaches ``max_digits`` exactly is NOT considered timed-out.
      - ``terminated_by_key``: True iff the terminator key ended the
        collection. Mutually exclusive with ``timed_out`` and with
        "max_digits reached".
    """

    digits: str = ""
    timed_out: bool = False
    terminated_by_key: bool = False


# ─── Warm Transfer ─────────────────────────────────────────────────────────


@dataclass(frozen=True)
class WarmTransferResult:
    """Result of :meth:`DVGatewayClient.warm_transfer`.

    Fields:
      - ``connected``: True when the agent channel answered and was bridged
        to the caller.
      - ``timed_out``: True when the agent did not answer before
        ``timeout_ms`` elapsed.
      - ``error``: Reason string on failure (e.g. ``"no_answer"``,
        ``"originate_failed"``). Server-side empty strings are normalized
        to ``None``.
      - ``agent_channel``: Asterisk channel name that answered. ``None``
        when no channel was created. Empty strings normalized to ``None``.
      - ``bridge_id``: Bridge identifier holding caller + agent. ``None``
        when no bridge was created. Empty strings normalized to ``None``.
      - ``whisper_played``: True when the whisper prompt was actually
        played to the agent before the bridge was formed. False when no
        cloud TTS provider is configured for the tenant, when whisper
        synthesis or playback failed, or when ``whisper_text`` was empty.
      - ``whisper_skip_reason``: Machine-readable tag explaining why the
        whisper was not played, when ``whisper_played`` is False and the
        caller asked for whisper. ``None`` when whisper played or when no
        whisper was requested. Available since SDK 1.6.9 / gateway 1.4.3.5.
        Values:

        * ``"no_request"`` — neither ``whisper_text`` nor ``whisper_tts``
          was supplied.
        * ``"no_tts_provider"`` — only ``whisper_text`` was supplied AND
          the gateway has no per-tenant cloud TTS configured. Either
          supply ``whisper_tts`` (a ``TtsAdapter`` you own) or have an
          admin configure ``/etc/dvgateway/apikeys/<tenantId>.json``.
        * ``"synthesize_failed"`` — gateway-side TTS errored (HTTP, quota,
          network).
        * ``"bad_pcm_format"`` — SDK-supplied PCM was not 2-byte aligned;
          your ``TtsAdapter`` likely emitted a non-slin16 stream.
        * ``"play_failed"`` — ARI rejected the audio file.
        * ``"timeout"`` — playback did not complete within the gateway's
          whisper timeout (audio likely still played, but the orchestrator
          gave up waiting and bridged).
        * ``"cancelled"`` — caller cancelled before playback.

      - ``mixed_stream_started``: True when the mixed-audio capture stream
        attached to the warm bridge (only set when the request specified
        ``stream_mixed_to_external_media=True``). Available since SDK 1.6.6
        / gateway 1.4.0.0.
      - ``mixed_stream_url``: WebSocket URL to subscribe to in order to
        receive captured mixed audio. ``None`` when the capture stream
        is disabled or failed to start. Empty strings normalized to ``None``.
    """

    connected: bool = False
    timed_out: bool = False
    error: str | None = None
    agent_channel: str | None = None
    bridge_id: str | None = None
    whisper_played: bool = False
    whisper_skip_reason: str | None = None
    mixed_stream_started: bool = False
    mixed_stream_url: str | None = None


# ─── Play Audio ────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class InjectTtsResult:
    """Result of :meth:`DVGatewayClient.inject_tts`.

    Returned by the synchronous (HTTP POST) path so callers can correlate
    the call's return value with the ``tts:playback`` events fired during
    the playback. The streaming WebSocket path also surfaces ``inject_id``
    via a ``tts:open`` text frame at handshake time — SDK 1.6.1+ parses
    that to populate the same field.

    Semantics:
      - ``inject_id``: stable per-injection identifier (UUID) generated
        by the gateway. Match against :class:`TtsPlaybackEvent.inject_id`
        to correlate the result with its lifecycle events when multiple
        TTS injections happen sequentially in the same call. Empty string
        when speaking to a gateway older than v1.3.9.3 (no inject_id is
        surfaced — legacy ``tts:complete`` is the only signal).

    Available since SDK 1.6.1.
    """

    inject_id: str = ""


@dataclass(frozen=True)
class PlayAudioResult:
    """Result of :meth:`DVGatewayClient.play_audio`.

    Semantics:
      - ``completed``: True when the gateway reports playback finished
        naturally (or with ``wait_for_completion=False``, always False —
        the call returns immediately after the gateway accepts the
        request).
      - ``interrupted_by_dtmf``: the DTMF digit that interrupted playback
        when ``interrupt_on_dtmf=True``. ``None`` when playback was not
        interrupted. Server-side empty strings are normalized to ``None``.
      - ``duration_ms``: actual playback duration in milliseconds (from
        the gateway). ``0`` when ``wait_for_completion=False``.
      - ``playback_id``: stable per-playback identifier (UUID) generated
        by the gateway. Match against :class:`AudioPlaybackEvent.playback_id`
        to correlate the result with its lifecycle events when multiple
        audios play sequentially in the same call. Available since SDK 1.6.0.
    """

    completed: bool = False
    interrupted_by_dtmf: str | None = None
    duration_ms: int = 0
    playback_id: str = ""


# ─── Audio ────────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class RawAudioChunk:
    """Raw audio frame as received from the gateway (slin16 PCM)."""

    linked_id: str = ""
    dir: Literal["in", "out", "mixed"] = "mixed"
    raw: bytes = b""
    timestamp_ms: float = 0.0


@dataclass(frozen=True)
class AudioChunk:
    """Normalized audio frame for AI adapters."""

    linked_id: str = ""
    dir: Literal["in", "out", "mixed"] = "mixed"
    samples: list[float] = field(default_factory=list)
    sample_rate: int = 16000
    duration_ms: float = 0.0
    timestamp_ms: float = 0.0


# ─── Transcription ────────────────────────────────────────────────────────


@dataclass(frozen=True)
class TranscriptWord:
    word: str = ""
    start_ms: float = 0.0
    end_ms: float = 0.0
    confidence: float | None = None


@dataclass(frozen=True)
class SentimentResult:
    """Sentiment analysis result from STT provider."""

    sentiment: Literal["positive", "neutral", "negative"] = "neutral"
    """Segment-level sentiment: positive, neutral, or negative."""
    sentiment_score: float = 0.0
    """Sentiment confidence score (0.0–1.0)."""


@dataclass(frozen=True)
class TranscriptResult:
    linked_id: str = ""
    text: str = ""
    is_final: bool = False
    speaker: str | None = None
    confidence: float | None = None
    language: str | None = None
    words: list[TranscriptWord] | None = None
    timestamp_ms: float = 0.0
    sentiment: SentimentResult | None = None
    """Sentiment analysis result. Present when sentiment is enabled on the STT adapter."""


# ─── TTS ──────────────────────────────────────────────────────────────────


@dataclass
class HumanVoiceOptions:
    """Human-like voice optimization options.

    Controls how natural and human-like the synthesized speech sounds.
    Each TTS provider maps these options to its own API parameters:

    - ElevenLabs: stability ↓, style ↑, multilingual model selection
    - OpenAI gpt-4o-mini-tts: voiceInstructions with natural speech directives

    Default preset is optimized for Korean (ko-KR) natural conversational speech.
    """

    natural_pauses: bool = True
    """Enable natural pauses between sentences and clauses."""
    breathing_sounds: bool = True
    """Include subtle breathing sounds between phrases."""
    filler_words: bool = True
    """Allow filler words (Korean: 음, 어, 그 / English: um, uh, well)."""
    exclamations: bool = True
    """Natural exclamations (Korean: 아, 네, 맞아요 / English: oh, right, I see)."""
    emotional_range: float = 0.6
    """Emotional expressiveness range (0.0–1.0). ElevenLabs → style parameter."""
    speech_variation: float = 0.7
    """Speech variation / naturalness (0.0–1.0). ElevenLabs → 1 - stability."""


HUMAN_VOICE_DEFAULTS_KO = HumanVoiceOptions(
    natural_pauses=True,
    breathing_sounds=True,
    filler_words=True,
    exclamations=True,
    emotional_range=0.6,
    speech_variation=0.7,
)
"""Default HumanVoiceOptions optimized for Korean conversational speech."""

HUMAN_VOICE_DEFAULTS_EN = HumanVoiceOptions(
    natural_pauses=True,
    breathing_sounds=True,
    filler_words=False,
    exclamations=True,
    emotional_range=0.5,
    speech_variation=0.6,
)
"""HumanVoiceOptions optimized for English conversational speech."""


@dataclass
class VoiceInfo:
    """Voice metadata returned from voice fetch APIs."""

    id: str = ""
    label: str = ""


@dataclass
class TtsOptions:
    voice_id: str | None = None
    speed: float | None = None
    pitch: float | None = None
    language: str | None = None
    human_voice: HumanVoiceOptions | None = None
    """Human-like voice optimization. Default: Korean-optimized preset."""


# ─── LLM ──────────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class Message:
    role: Literal["system", "user", "assistant"] = "user"
    content: str = ""


@dataclass
class LlmOptions:
    model: str | None = None
    system_prompt: str | None = None
    max_tokens: int | None = None
    temperature: float | None = None


# ─── AI Adapter Interfaces ────────────────────────────────────────────────


class SttAdapter(abc.ABC):
    """Speech-to-Text adapter interface."""

    @abc.abstractmethod
    async def start_stream(self, linked_id: str, audio_stream: AsyncIterable[AudioChunk]) -> None:
        """Begin streaming audio for transcription."""

    @abc.abstractmethod
    def on_transcript(self, handler: Callable[[TranscriptResult], None]) -> None:
        """Register a handler for transcription results."""

    @abc.abstractmethod
    async def stop(self) -> None:
        """Stop the stream and release resources."""


class TtsAdapter(abc.ABC):
    """Text-to-Speech adapter interface."""

    @abc.abstractmethod
    def synthesize(self, text: str, options: TtsOptions | None = None) -> AsyncIterable[bytes]:
        """Synthesize text to speech. Returns async iterable of 16kHz slin16 PCM chunks."""


class LlmAdapter(abc.ABC):
    """Large Language Model adapter interface."""

    @abc.abstractmethod
    def chat(self, messages: list[Message], options: LlmOptions | None = None) -> AsyncIterable[str]:
        """Generate a streaming chat completion. Returns async iterable of text tokens."""


# ─── Pipeline Hooks (Phase 1) ─────────────────────────────────────────────


@dataclass
class HookContext:
    """Context passed to pipeline hooks (on_before_chat / on_after_chat)."""

    session: CallSession
    turn_number: int = 0
    pipeline_config: dict[str, Any] | None = None


@dataclass
class HistoryOptions:
    """Conversation history management options."""

    max_turns: int = 0
    """Max conversation turns to keep (0 = unlimited)."""

    summarize_on_trim: bool = False
    """Generate summary of trimmed messages."""

    summarizer: Callable[[list[Message]], str | Awaitable[str]] | None = None
    """Custom summarization function."""


@dataclass
class PipelineConfig:
    """Pipeline config fetched from gateway (set via dashboard)."""

    llm_provider: str = ""
    llm_model: str = ""
    system_prompt: str = ""
    max_tokens: int = 0
    temperature: float | None = None
    webhook_url: str = ""
    webhook_timeout: int = 0
    fallback_provider: str = ""
    fallback_model: str = ""
    max_turns: int = 0
    summarize_on_trim: bool = False
    greeting_text: str = ""
    greeting_enabled: bool = False
    comfort_noise: bool = False


# Type aliases for hook callbacks
BeforeChatHook = Callable[[list[Message], HookContext], list[Message] | Awaitable[list[Message]]]
AfterChatHook = Callable[[str, list[Message], HookContext], str | Awaitable[str]]


# ─── Pipeline ─────────────────────────────────────────────────────────────


@dataclass
class PipelineOptions:
    dir: StreamDir = "both"
    end_of_utterance_silence_ms: int = 500
    submit_to_minutes: bool = True


# ─── Logging ──────────────────────────────────────────────────────────────


class Logger(Protocol):
    """Logger interface — compatible with any structured logger."""

    def debug(self, ctx: dict[str, Any], msg: str) -> None: ...
    def info(self, ctx: dict[str, Any], msg: str) -> None: ...
    def warn(self, ctx: dict[str, Any], msg: str) -> None: ...
    def error(self, ctx: dict[str, Any], msg: str) -> None: ...


# ─── Utility ──────────────────────────────────────────────────────────────

Unsubscribe = Callable[[], None]

T = TypeVar("T")
E = TypeVar("E", bound=Exception)


@dataclass(frozen=True)
class Ok(Generic[T]):
    value: T
    ok: Literal[True] = True


@dataclass(frozen=True)
class Err(Generic[E]):
    error: E
    ok: Literal[False] = False


Result = Ok[T] | Err[E]
