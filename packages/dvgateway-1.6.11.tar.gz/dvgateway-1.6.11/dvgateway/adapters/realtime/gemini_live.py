"""
Google Gemini Live API — Speech-to-Speech Adapter

Drop-in alternative to OpenAIRealtimeAdapter. Same RealtimeSpeechAdapter
interface, same callbacks, same pipeline_type="s2s" dashboard integration.

Architecture:
  DVGateway audio in (16kHz PCM)
      ↓ (Gemini Live native input rate — no resampling)
  Gemini Live API (WebSocket, BidiGenerateContent)
      ↓ gemini-live-2.5-flash-preview processes end-to-end
  DVGateway audio out (24kHz → 16kHz downsample)

Supported endpoints:
- "ai-studio" (default): AI Studio global endpoint (API key auth)
- "vertex": Vertex AI regional endpoint (Bearer access token auth)

Audio format:
  Input:  PCM16 16kHz mono, base64, MIME "audio/pcm;rate=16000"
  Output: PCM16 24kHz mono, base64 (downsampled to 16kHz for DVGateway)

API Reference:
  https://ai.google.dev/gemini-api/docs/live-api
  https://ai.google.dev/api/live
"""

from __future__ import annotations

import asyncio
import base64
import logging
import json
import time
from dataclasses import dataclass
from typing import Any, AsyncIterable, Callable, Literal
from urllib.parse import quote

import websockets
import websockets.asyncio.client
import websockets.exceptions

from dvgateway.audio.codec import float32_to_slin16, resample, slin16_to_float32
from dvgateway.types import AudioChunk, TranscriptResult

from dvgateway.adapters.realtime.openai_realtime import (
    RealtimeSpeechAdapter,
    RealtimeSpeechActivityEvent,
    RealtimeToolCall,
)

AI_STUDIO_URL = (
    "wss://generativelanguage.googleapis.com/ws/"
    "google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent"
)
GEMINI_OUTPUT_SAMPLE_RATE = 24000
DV_SAMPLE_RATE = 16000
INPUT_CHUNK_MS = 20
INPUT_SAMPLES_16K = round(DV_SAMPLE_RATE * INPUT_CHUNK_MS / 1000)  # 320 samples

# Prebuilt voices available on half-cascade Gemini Live models.
# Native-audio models support the full Google Cloud TTS catalog.
GeminiLiveVoice = Literal[
    "Puck",     # Conversational, friendly (default)
    "Charon",   # Deep, authoritative
    "Kore",     # Neutral, professional
    "Fenrir",   # Warm, approachable
    "Aoede",    # Bright, energetic
    "Leda",     # Soft, calm
    "Orus",     # Resonant, mature
    "Zephyr",   # Light, airy
]

GeminiLiveModel = Literal[
    "gemini-live-2.5-flash-preview",        # Current preview, multimodal I/O
    "gemini-2.5-flash-native-audio",        # Native audio (replaces Sept 2025 preview)
    "gemini-2.0-flash-live-001",            # Legacy
]

GeminiLiveEndpoint = Literal["ai-studio", "vertex"]


@dataclass
class GeminiLiveTurnDetectionOptions:
    """Turn detection / VAD configuration for Gemini Live.

    mode="server_vad" (default): server-side VAD auto-detects boundaries.
    mode="none": client-side — set automaticActivityDetection.disabled and
    call send_activity_start() / send_activity_end() manually.

    Attributes:
        threshold: **OpenAI-compat alias** — accepts OpenAI Realtime's
            numeric ``threshold`` (0.0–1.0) and maps it onto Gemini's
            three-level sensitivity so configs can be ported without
            renaming. The mapping inverts the direction so user intent
            is preserved (OpenAI: higher=less sensitive; Gemini:
            HIGH=more sensitive)::

                threshold < 0.3   → start/end_sensitivity = "HIGH"
                0.3 ≤ x ≤ 0.7     → "MEDIUM"  (OpenAI default 0.5)
                threshold > 0.7   → "LOW"

            Ignored when ``start_sensitivity`` or ``end_sensitivity``
            is set explicitly — those win.
    """
    mode: Literal["server_vad", "none"] = "server_vad"
    start_sensitivity: Literal["LOW", "MEDIUM", "HIGH"] | None = None
    end_sensitivity: Literal["LOW", "MEDIUM", "HIGH"] | None = None
    prefix_padding_ms: int | None = None
    silence_duration_ms: int | None = None
    threshold: float | None = None


@dataclass
class GeminiLiveTool:
    """Function/tool declaration (same schema as Gemini Generative API)."""
    name: str
    description: str = ""
    parameters: dict[str, object] | None = None


#: Tool-choice strategy (mirrors OpenAIRealtimeAdapter's ``tool_choice``).
#:
#: Accepted values::
#:
#:     "auto"     → {"function_calling_config": {"mode": "AUTO"}}
#:     "none"     → {"function_calling_config": {"mode": "NONE"}}
#:     "required" → {"function_calling_config": {"mode": "ANY"}}
#:     {"type": "function", "name": "fn"}
#:                → {"function_calling_config":
#:                    {"mode": "ANY", "allowed_function_names": ["fn"]}}
#:
#: Default when ``tools`` is set and no explicit choice is given: ``"auto"``
#: (matches OpenAI default). Default when ``tools`` is empty: ``None`` — no
#: ``tool_config`` is sent.
#:
#: Reference: https://ai.google.dev/api/live#toolconfig
GeminiLiveToolChoice = (
    Literal["auto", "none", "required"] | dict[str, str]
)


def build_gemini_tool_config(
    choice: str | dict[str, str],
) -> dict[str, object]:
    """Convert an OpenAI-style ``tool_choice`` into Gemini's ``tool_config``.

    Pure function — exported for unit tests and any caller that wants to
    emit the raw protocol object directly (e.g. custom
    BidiGenerateContent clients).

    Args:
        choice: One of ``"auto"`` / ``"none"`` / ``"required"`` or
            ``{"type": "function", "name": "fn"}``.

    Returns:
        ``{"function_calling_config": ...}`` ready to drop into the
        Gemini Live ``setup`` message.
    """
    if choice == "auto":
        return {"function_calling_config": {"mode": "AUTO"}}
    if choice == "none":
        return {"function_calling_config": {"mode": "NONE"}}
    if choice == "required":
        return {"function_calling_config": {"mode": "ANY"}}
    if isinstance(choice, dict) and choice.get("type") == "function":
        name = choice.get("name")
        if not name:
            raise ValueError(
                "tool_choice dict with type='function' requires a 'name' field"
            )
        return {
            "function_calling_config": {
                "mode": "ANY",
                "allowed_function_names": [name],
            }
        }
    raise ValueError(f"Unsupported tool_choice value: {choice!r}")


_logger = logging.getLogger("dvgateway.adapters.gemini_live")


def parse_rate_from_mime(mime: str) -> int | None:
    """Extract the sample rate from a MIME type like ``audio/pcm;rate=24000``.

    Returns ``None`` when no ``rate=`` parameter is present so the caller
    can fall back to a default. Exposed for unit tests.
    """
    import re

    m = re.search(r"[;\s]rate=(\d+)", mime, re.IGNORECASE)
    if not m:
        return None
    n = int(m.group(1))
    return n if n > 0 else None


def peak_amplitude(samples: object) -> float:
    """Peak ``abs(sample)`` across an iterable of float samples.

    Used by the first-chunk diagnostic to surface "Gemini sent silent
    bytes" vs "Gemini sent valid audio" in the logs.
    """
    peak = 0.0
    for s in samples:  # type: ignore[union-attr]
        v = abs(float(s))
        if v > peak:
            peak = v
    return peak


def _normalize_max_output_tokens(
    explicit: int | None,
    alias: int | str | None,
) -> int | None:
    """Fold OpenAI's ``max_response_tokens`` alias into Gemini's
    ``max_output_tokens``. Explicit ``max_output_tokens`` wins over the
    alias; OpenAI's ``"inf"`` sentinel (unlimited) is treated as "no
    cap". Returned ``None`` = no cap (the Gemini default).

    Exported privately (underscore-prefix) because production callers
    should pass the normalized arg — no legitimate reason to resolve
    the alias outside the adapter.
    """
    if explicit is not None:
        return explicit
    if alias is None or alias == "inf":
        return None
    return int(alias)


def map_threshold_to_sensitivity(
    threshold: float | None,
) -> str | None:
    """Map OpenAI's numeric ``threshold`` (0.0–1.0, higher = less
    sensitive) onto Gemini's three-level sensitivity
    (``HIGH`` = more sensitive).

    Returns ``None`` for an undefined or out-of-range input so the
    caller can fall through to explicit ``start_sensitivity`` /
    ``end_sensitivity`` or Gemini's own defaults.

    ::

        threshold < 0.3  → "HIGH"   (OpenAI low threshold = very permissive)
        0.3 … 0.7        → "MEDIUM" (OpenAI default 0.5 → Gemini default)
        threshold > 0.7  → "LOW"    (OpenAI high threshold = strict)

    The inversion (OpenAI "higher = less sensitive" ↔ Gemini
    "HIGH = more sensitive") is deliberate and preserves user intent.
    """
    if threshold is None:
        return None
    try:
        t = float(threshold)
    except (TypeError, ValueError):
        return None
    if t != t or t < 0.0 or t > 1.0:  # NaN or out of range
        return None
    if t < 0.3:
        return "HIGH"
    if t > 0.7:
        return "LOW"
    return "MEDIUM"


@dataclass
class _SessionDiagnostics:
    """Per-session runtime diagnostics fed by the 2-second heartbeat.

    Tracks send rate, last server message time + type, and per-turn flags
    so an operator can determine — from logs alone — which layer is
    stuck when Gemini appears unresponsive. Lifecycle is tied to
    ``start_session()`` / ``stop()`` / WS close.
    """

    start_time: float
    chunks_sent_total: int = 0
    chunks_sent_since_heartbeat: int = 0
    last_server_message_at: float = 0.0
    last_server_message_type: str = "(none yet)"
    heartbeat_task: asyncio.Task[None] | None = None
    silence_warned: bool = False
    turn_started_at: float = 0.0
    turn_number: int = 0
    saw_input_this_turn: bool = False
    saw_output_this_turn: bool = False


def classify_server_message(msg: dict[str, object]) -> str:
    """Return a short tag describing the dominant type of a Gemini
    server message — surfaced in the per-session heartbeat so an
    operator can see at a glance what Gemini was doing when it went
    quiet. Exported for unit tests.
    """
    if "setupComplete" in msg or "setup_complete" in msg:
        return "setupComplete"
    sc = msg.get("serverContent") or msg.get("server_content")
    if isinstance(sc, dict):
        model_turn = sc.get("modelTurn") or sc.get("model_turn")
        if isinstance(model_turn, dict):
            parts = model_turn.get("parts")
            if isinstance(parts, list):
                for p in parts:
                    if isinstance(p, dict):
                        inline = p.get("inlineData") or p.get("inline_data")
                        if isinstance(inline, dict) and inline.get("data"):
                            return "modelTurn(audio)"
                for p in parts:
                    if isinstance(p, dict) and p.get("text"):
                        return "modelTurn(text)"
        if sc.get("turnComplete") is True or sc.get("turn_complete") is True:
            return "turnComplete"
        if sc.get("generationComplete") is True or sc.get("generation_complete") is True:
            return "generationComplete"
        if sc.get("interrupted") is True:
            return "interrupted"
        input_t = sc.get("inputTranscription") or sc.get("input_transcription")
        if isinstance(input_t, dict) and input_t.get("text") is not None:
            return "inputTranscription"
        output_t = sc.get("outputTranscription") or sc.get("output_transcription")
        if isinstance(output_t, dict) and output_t.get("text") is not None:
            return "outputTranscription"
        return "serverContent(other)"
    if "toolCall" in msg or "tool_call" in msg:
        return "toolCall"
    if "toolCallCancellation" in msg or "tool_call_cancellation" in msg:
        return "toolCallCancellation"
    if "goAway" in msg or "go_away" in msg:
        return "goAway"
    if "sessionResumptionUpdate" in msg or "session_resumption_update" in msg:
        return "sessionResumptionUpdate"
    if "usageMetadata" in msg or "usage_metadata" in msg:
        return "usageMetadata"
    return "unknown:" + ",".join(msg.keys())


class GeminiLiveAdapter(RealtimeSpeechAdapter):
    """Google Gemini Live speech-to-speech adapter.

    Drop-in replacement for OpenAIRealtimeAdapter. Use the same S2S wiring
    (stream_audio(pipeline_type="s2s"), inject_tts, on_speech_activity →
    post_vad) — only the adapter import changes.

    Example::

        from dvgateway.adapters.realtime import GeminiLiveAdapter

        adapter = GeminiLiveAdapter(
            api_key=os.environ["GEMINI_API_KEY"],
            model="gemini-live-2.5-flash-preview",
            voice="Puck",
            language="ko-KR",
        )
    """

    def __init__(
        self,
        api_key: str = "",
        *,
        access_token: str = "",
        project: str = "",
        location: str = "",
        endpoint: GeminiLiveEndpoint = "ai-studio",
        model: GeminiLiveModel = "gemini-live-2.5-flash-preview",
        voice: GeminiLiveVoice = "Puck",
        instructions: str = "You are a helpful voice assistant. Keep answers concise and conversational.",
        turn_detection: GeminiLiveTurnDetectionOptions | dict[str, object] | None = None,
        input_transcription: bool = True,
        output_transcription: bool = True,
        language: str = "",
        temperature: float = 0.8,
        max_output_tokens: int | None = None,
        max_response_tokens: int | str | None = None,
        tools: list[GeminiLiveTool | dict[str, object]] | None = None,
        tool_choice: str | dict[str, str] | None = None,
        output_gain_db: float = 0.0,
    ) -> None:
        """Build a GeminiLiveAdapter.

        Args:
            output_gain_db: Linear gain applied to every audio chunk
                BEFORE it leaves the adapter, in dBFS. Default ``0``
                (no change). Gemini Live's half-cascade models emit
                around ``-40 dBFS`` peak — roughly 30 dB quieter than
                OpenAI Realtime — so a phone sink needs compensation.
                Recommended: ``24`` for ``gemini-live-2.5-flash-preview``;
                ``0``–``12`` for ``gemini-2.5-flash-native-audio``.
                Values outside ``[-24, +40]`` dB are permitted but
                logged as a warning.
        """
        if endpoint == "ai-studio" and not api_key:
            raise ValueError('GeminiLiveAdapter: api_key is required when endpoint="ai-studio"')
        if endpoint == "vertex" and not (access_token and project and location):
            raise ValueError(
                'GeminiLiveAdapter: access_token, project, and location are required when endpoint="vertex"'
            )

        self._endpoint = endpoint
        self._api_key = api_key
        self._access_token = access_token
        self._project = project
        self._location = location
        self._model = model
        self._voice = voice
        self._instructions = instructions
        if isinstance(turn_detection, dict):
            self._turn_detection = GeminiLiveTurnDetectionOptions(**turn_detection)
        else:
            self._turn_detection = turn_detection or GeminiLiveTurnDetectionOptions()
        self._input_transcription = input_transcription
        self._output_transcription = output_transcription
        self._language = language
        self._temperature = temperature
        # Fold OpenAI-compat alias `max_response_tokens` into the Gemini
        # field. Explicit `max_output_tokens` wins. OpenAI's sentinel
        # `"inf"` (unlimited) is treated as "no cap".
        self._max_output_tokens = _normalize_max_output_tokens(
            max_output_tokens, max_response_tokens,
        )

        # Normalize tool list
        self._tools: list[dict[str, object]] = []
        for t in (tools or []):
            if isinstance(t, dict):
                self._tools.append(t)
            else:
                td: dict[str, object] = {"name": t.name}
                if t.description:
                    td["description"] = t.description
                if t.parameters is not None:
                    td["parameters"] = t.parameters
                self._tools.append(td)

        # Default to "auto" when tools are declared but no explicit
        # choice is given — matches OpenAIRealtimeAdapter so the two
        # adapters stay drop-in-compatible.
        if tool_choice is None:
            self._tool_choice: str | dict[str, str] | None = (
                "auto" if self._tools else None
            )
        else:
            self._tool_choice = tool_choice
        # Gemini Live's BidiGenerateContentSetup does not accept a
        # tool_config field — sending one makes Gemini close the WS
        # with code=1011 (bad setup). Warn explicitly when the caller
        # passed an explicit non-default value so they don't waste
        # hours debugging why their `required` setting isn't being
        # respected.
        if tool_choice is not None and tool_choice != "auto":
            _logger.warning(
                "[GeminiLive] tool_choice=%r ignored — Gemini Live "
                "BidiGenerateContent setup has no tool_config field. "
                "Tools default to AUTO calling mode. To pin a specific "
                "function, add an explicit instruction in your "
                "system_instruction prompt.",
                tool_choice,
            )

        # Output gain — see `output_gain_db` docstring. Warn on
        # nonsensical values but never clamp; some sinks are non-phone
        # (file, WebRTC) and wider ranges may be intentional.
        self._output_gain_db = float(output_gain_db)
        if self._output_gain_db < -24 or self._output_gain_db > 40:
            _logger.warning(
                "[GeminiLive] output_gain_db=%s is outside the sensible "
                "[-24, +40] dB range — this is almost certainly a "
                "mis-configuration",
                self._output_gain_db,
            )
        self._output_gain_linear = (
            1.0 if self._output_gain_db == 0 else 10 ** (self._output_gain_db / 20)
        )

        self._audio_output_handler: Callable[[bytes, str], None] | None = None
        self._transcript_handler: Callable[[TranscriptResult], None] | None = None
        self._error_handler: Callable[[Exception, str | None], None] | None = None
        self._tool_call_handler: Callable[[RealtimeToolCall], None] | None = None
        self._speech_activity_handler: Callable[[RealtimeSpeechActivityEvent], None] | None = None

        self._sessions: dict[str, websockets.asyncio.client.ClientConnection] = {}  # type: ignore[type-arg]
        self._input_transcript_buf: dict[str, str] = {}
        self._output_transcript_buf: dict[str, str] = {}
        self._caller_speaking: dict[str, bool] = {}
        # Per-session diagnostic flags (one-shot per session lifecycle).
        self._logged_first_audio: set[str] = set()
        self._warned_text_only: set[str] = set()
        self._session_diag: dict[str, _SessionDiagnostics] = {}
        self._ws_lock = asyncio.Lock()
        self._stopped = False

    def on_audio_output(self, handler: Callable[[bytes, str], None]) -> None:
        self._audio_output_handler = handler

    def on_transcript(self, handler: Callable[[TranscriptResult], None]) -> None:
        self._transcript_handler = handler

    def on_error(self, handler: Callable[[Exception, str | None], None]) -> None:
        self._error_handler = handler

    def on_tool_call(self, handler: Callable[[RealtimeToolCall], None]) -> None:
        self._tool_call_handler = handler

    def on_speech_activity(
        self,
        handler: Callable[[RealtimeSpeechActivityEvent], None],
    ) -> None:
        """Register a handler for speech activity events.

        Gemini Live does NOT emit explicit speech_started/stopped events like
        OpenAI Realtime. This adapter approximates caller speech activity from:

        - ``serverContent.interrupted=True`` → caller barged in while AI was
          responding. Fires ``speaking=True``.
        - ``serverContent.turnComplete=True`` → turn boundary. Fires
          ``speaking=False`` if caller was marked speaking.

        For precise VAD, set ``turn_detection.mode="none"`` and call
        :meth:`send_activity_start` / :meth:`send_activity_end` manually.
        """
        self._speech_activity_handler = handler

    def submit_tool_result(self, linked_id: str, call_id: str, result: object) -> None:
        """Submit a tool-call result back to the model."""
        ws = self._sessions.get(linked_id)
        if not ws:
            return

        if isinstance(result, dict):
            response = result
        else:
            response = {"result": result}

        self._send_event(ws, {
            "tool_response": {
                "function_responses": [{
                    "id": call_id,
                    "name": "",
                    "response": response,
                }],
            },
        })

    def send_activity_start(self, linked_id: str) -> None:
        """Mark caller speech onset (manual VAD mode only).

        No-op unless ``turn_detection.mode == "none"``. Sends
        ``realtime_input.activity_start`` and fires on_speech_activity.
        """
        if self._turn_detection.mode != "none":
            return
        ws = self._sessions.get(linked_id)
        if not ws:
            return
        self._send_event(ws, {"realtime_input": {"activity_start": {}}})
        self._caller_speaking[linked_id] = True
        if self._speech_activity_handler:
            self._speech_activity_handler(RealtimeSpeechActivityEvent(
                linked_id=linked_id,
                side="caller",
                speaking=True,
                timestamp_ms=time.time() * 1000,
            ))

    def send_activity_end(self, linked_id: str) -> None:
        """Mark caller speech end (manual VAD mode only)."""
        if self._turn_detection.mode != "none":
            return
        ws = self._sessions.get(linked_id)
        if not ws:
            return
        self._send_event(ws, {"realtime_input": {"activity_end": {}}})
        self._caller_speaking[linked_id] = False
        if self._speech_activity_handler:
            self._speech_activity_handler(RealtimeSpeechActivityEvent(
                linked_id=linked_id,
                side="caller",
                speaking=False,
                timestamp_ms=time.time() * 1000,
            ))

    async def start_session(self, linked_id: str, audio_in: AsyncIterable[AudioChunk]) -> None:
        self._stopped = False
        ws = await self._connect_live(linked_id)
        self._sessions[linked_id] = ws
        self._input_transcript_buf[linked_id] = ""
        self._output_transcript_buf[linked_id] = ""
        self._caller_speaking[linked_id] = False

        # Initialize per-session diagnostics — the heartbeat task is
        # launched below after the setup message is sent so its first
        # tick reflects a live session.
        now = time.monotonic()
        diag = _SessionDiagnostics(
            start_time=now,
            last_server_message_at=now,
            turn_started_at=now,
        )
        self._session_diag[linked_id] = diag
        _logger.info(
            "[GeminiLive] session starting linked_id=%s model=%s voice=%s "
            "output_gain_db=%s",
            linked_id, self._model, self._voice, self._output_gain_db,
        )

        # ── Build setup message ──
        setup: dict[str, object] = {
            "model": self._resolve_model_path(),
            "generation_config": {
                "response_modalities": ["AUDIO"],
                "speech_config": self._build_speech_config(),
                "temperature": self._temperature,
            },
            "system_instruction": {"parts": [{"text": self._instructions}]},
            "realtime_input_config": self._build_realtime_input_config(),
        }
        if self._max_output_tokens is not None:
            gen_cfg = setup["generation_config"]
            if isinstance(gen_cfg, dict):
                gen_cfg["max_output_tokens"] = self._max_output_tokens
        if self._input_transcription:
            setup["input_audio_transcription"] = {}
        if self._output_transcription:
            setup["output_audio_transcription"] = {}
        if self._tools:
            setup["tools"] = [{"function_declarations": self._tools}]
            # NOTE: do NOT include `tool_config` here. The Gemini Live
            # BidiGenerateContentSetup schema does NOT have a tool_config
            # field — it lives on GenerateContentRequest, not on the Live
            # setup. Sending it makes Gemini close the WS immediately
            # with code=1011 (bad setup), which manifests as
            # "session_age=0s chunks_sent=N" and zero audio output. The
            # `tool_choice` constructor arg is preserved for forward
            # compat (and because `build_gemini_tool_config` is exported
            # for callers using the regular GenerateContent API), but it
            # has no effect on Live sessions — see the constructor
            # warning.

        self._send_event(ws, {"setup": setup})

        # Kick off the 2-second heartbeat now that setup is in flight.
        diag.heartbeat_task = asyncio.ensure_future(self._heartbeat_loop(linked_id))

        # Pipe audio in background (guarded for exception visibility)
        asyncio.ensure_future(self._pipe_audio_guarded(linked_id, ws, audio_in))

        # Read server messages. Capture close code + reason on the way
        # out — these are the single most important diagnostic values
        # for any "Gemini disconnected us in N milliseconds" failure
        # (bad API key, bad setup payload, quota, region block, etc.).
        # Previously we swallowed the ConnectionClosed silently, which
        # left the operator with zero clue why the session died.
        close_reason = "no_close_event"
        try:
            async for message in ws:
                if self._stopped or linked_id not in self._sessions:
                    break
                try:
                    event = json.loads(message if isinstance(message, str) else message.decode("utf-8"))
                    self._handle_server_message(event, linked_id)
                except (json.JSONDecodeError, UnicodeDecodeError):
                    pass
        except websockets.exceptions.ConnectionClosed as exc:
            # Log the close code/reason explicitly. Common codes:
            #   1000 Normal closure — "quota" typically in reason
            #   1001 Going away — server shutdown / goAway message
            #   1006 Abnormal closure — network drop, no close frame
            #   1008 Policy violation — auth / content policy / model
            #        not found
            #   1011 Internal error — malformed setup, unsupported model
            code = getattr(exc, "code", 0) or getattr(exc, "rcvd", None) and exc.rcvd.code  # type: ignore[attr-defined]
            reason = getattr(exc, "reason", "") or (
                getattr(exc, "rcvd", None) and exc.rcvd.reason  # type: ignore[attr-defined]
            ) or "(no reason string)"
            close_reason = f"ws-close({code}) {reason!r}"
            _logger.warning(
                "[GeminiLive] WS closed linked_id=%s code=%s reason=%r — "
                "Gemini terminated the session. Common causes by code: "
                "1000=quota/normal, 1001=goAway, 1006=network, "
                "1008=auth/policy/model-not-found, 1011=bad setup "
                "(unsupported model / invalid setup fields).",
                linked_id, code, reason,
            )
            # Specific hint for the most common 1008 sub-cause: model
            # name deprecated by Google. Surface the discovery helper
            # inline so the operator doesn't have to dig through docs.
            import re as _re

            if code == 1008 and _re.search(
                r"not (?:found|supported)|bidiGenerateContent",
                str(reason),
                _re.IGNORECASE,
            ):
                _logger.warning(
                    "[GeminiLive] Model %r appears to be deprecated, "
                    "renamed, or unavailable for this API key. Discover "
                    "currently Live-capable models with:\n"
                    "  from dvgateway.adapters.realtime import "
                    "list_gemini_live_models\n"
                    "  models = await list_gemini_live_models(api_key)\n"
                    "  print([m['name'] for m in models])\n"
                    "Then pass the chosen name (without the 'models/' "
                    "prefix) as the `model` arg.",
                    self._model,
                )
        except Exception as exc:
            # Any other exception in the read loop — still want it
            # visible in the session teardown reason.
            close_reason = f"ws-error({type(exc).__name__}) {exc!s}"
            _logger.error(
                "[GeminiLive] WS read loop error linked_id=%s: %s",
                linked_id, exc,
            )
        finally:
            # Include the captured close reason in the teardown log so
            # one line explains the whole failure.
            self._tear_down_session(linked_id, reason=f"start_session_exit: {close_reason}")

    async def stop(self, linked_id: str | None = None) -> None:
        if linked_id:
            ws = self._sessions.get(linked_id)
            if ws:
                await ws.close(1000, "session ended")
            self._tear_down_session(linked_id, reason="stop(linked_id)")
        else:
            self._stopped = True
            for lid, ws in list(self._sessions.items()):
                await ws.close(1000, "adapter stopped")
                self._tear_down_session(lid, reason="stop(all)")

    def _tear_down_session(self, linked_id: str, reason: str) -> None:
        """Release per-session resources — WS entry, buffers, heartbeat."""
        diag = self._session_diag.pop(linked_id, None)
        if diag and diag.heartbeat_task and not diag.heartbeat_task.done():
            diag.heartbeat_task.cancel()
        if diag:
            age = round(time.monotonic() - diag.start_time)
            _logger.info(
                "[GeminiLive] session ended linked_id=%s reason=%r age=%ds "
                "chunks_sent=%d turns=%d",
                linked_id, reason, age, diag.chunks_sent_total, diag.turn_number,
            )
        self._sessions.pop(linked_id, None)
        self._input_transcript_buf.pop(linked_id, None)
        self._output_transcript_buf.pop(linked_id, None)
        self._caller_speaking.pop(linked_id, None)
        self._logged_first_audio.discard(linked_id)
        self._warned_text_only.discard(linked_id)

    async def _heartbeat_loop(self, linked_id: str) -> None:
        """Emit a per-session heartbeat every 2 seconds.

        The heartbeat intentionally fires regardless of activity — an
        operator scrolling the journal should see whether the SDK is
        sending audio out and whether Gemini is answering, at a glance.
        Also drives the silence watchdog that warns when Gemini has
        been quiet for 10+ seconds while the SDK kept sending audio.
        """
        try:
            while True:
                await asyncio.sleep(2.0)
                diag = self._session_diag.get(linked_id)
                if diag is None:
                    return
                now = time.monotonic()
                since_server = now - diag.last_server_message_at
                session_age = round(now - diag.start_time)
                _logger.info(
                    "[GeminiLive] heartbeat linked_id=%s session_age=%ds "
                    "chunks_total=%d chunks_last_2s=%d last_server_msg=%s "
                    "server_silent_for=%ds turn=%d",
                    linked_id, session_age,
                    diag.chunks_sent_total, diag.chunks_sent_since_heartbeat,
                    diag.last_server_message_type, round(since_server),
                    diag.turn_number,
                )
                diag.chunks_sent_since_heartbeat = 0

                # Silence watchdog — fire WARN once per contiguous gap.
                if (
                    since_server > 10.0
                    and not diag.silence_warned
                    and diag.chunks_sent_total > 100
                ):
                    diag.silence_warned = True
                    _logger.warning(
                        "[GeminiLive] WARNING Gemini has been silent for %ds "
                        "while SDK sent %d audio chunks to it (last_msg=%s). "
                        "Most likely causes: (1) server_vad not detecting user "
                        "speech — input too quiet, wrong format, or filtered as "
                        "noise, (2) model stuck post-response — session in "
                        "locked state after a long turn, (3) Gemini WS silently "
                        "dropped or quota-limited. linked_id=%s",
                        round(since_server), diag.chunks_sent_total,
                        diag.last_server_message_type, linked_id,
                    )
                if since_server < 5.0:
                    # Fresh activity → re-arm the watchdog for the next gap.
                    diag.silence_warned = False
        except asyncio.CancelledError:
            # Normal session teardown — _tear_down_session already calls
            # _caller_speaking.pop(linked_id) per-session, so clearing the
            # entire shared dict here would corrupt other live sessions' VAD state.
            return

    # ── Private helpers ─────────────────────────────────────────────────────

    def _resolve_model_path(self) -> str:
        if self._endpoint == "vertex":
            return (
                f"projects/{self._project}/locations/{self._location}/"
                f"publishers/google/models/{self._model}"
            )
        return f"models/{self._model}"

    def _build_speech_config(self) -> dict[str, object]:
        cfg: dict[str, object] = {
            "voice_config": {"prebuilt_voice_config": {"voice_name": self._voice}},
        }
        if self._language:
            cfg["language_code"] = self._language
        return cfg

    def _build_realtime_input_config(self) -> dict[str, object]:
        td = self._turn_detection
        if td.mode == "none":
            return {"automatic_activity_detection": {"disabled": True}}
        vad: dict[str, object] = {"disabled": False}

        # Normalize OpenAI-style numeric `threshold` into Gemini's
        # 3-level sensitivity. Only fills whichever of start/end isn't
        # set explicitly — so mix-and-match still works.
        mapped_sens = map_threshold_to_sensitivity(td.threshold)
        start_sens = td.start_sensitivity or mapped_sens
        end_sens = td.end_sensitivity or mapped_sens

        if start_sens:
            vad["start_of_speech_sensitivity"] = f"START_SENSITIVITY_{start_sens}"
        if end_sens:
            vad["end_of_speech_sensitivity"] = f"END_SENSITIVITY_{end_sens}"
        if td.prefix_padding_ms is not None:
            vad["prefix_padding_ms"] = td.prefix_padding_ms
        if td.silence_duration_ms is not None:
            vad["silence_duration_ms"] = td.silence_duration_ms
        return {"automatic_activity_detection": vad}

    async def _connect_live(self, linked_id: str) -> websockets.asyncio.client.ClientConnection:  # type: ignore[type-arg]
        if self._endpoint == "vertex":
            url = (
                f"wss://{self._location}-aiplatform.googleapis.com/ws/"
                "google.cloud.aiplatform.v1.LlmBidiService/BidiGenerateContent"
            )
            extra_headers = {"Authorization": f"Bearer {self._access_token}"}
            url_for_log = f"{url} (vertex, project={self._project}, location={self._location})"
        else:
            url = f"{AI_STUDIO_URL}?key={quote(self._api_key)}"
            extra_headers = {}
            # Mask the API key: show only the trailing 4 characters so
            # operators can eyeball-compare against their config file
            # without exposing the full key in logs.
            masked_key = (
                "***" + self._api_key[-4:] if len(self._api_key) >= 4 else "***"
            )
            url_for_log = f"{AI_STUDIO_URL}?key={masked_key}"

        _logger.info(
            "[GeminiLive] connecting linked_id=%s url=%s", linked_id, url_for_log,
        )
        try:
            # websockets.asyncio.client renamed extra_headers to
            # additional_headers (the legacy name is removed in 14+).
            ws = await websockets.asyncio.client.connect(
                url, additional_headers=extra_headers
            )
        except Exception as exc:
            # Distinguish the two most common early-fail modes so the
            # operator knows which knob to check first:
            #   - InvalidStatusCode 401/403 → auth (API key bad/missing)
            #   - OSError / TimeoutError     → network / region block
            _logger.error(
                "[GeminiLive] connect FAILED linked_id=%s err_type=%s err=%s",
                linked_id, type(exc).__name__, exc,
            )
            raise
        _logger.info("[GeminiLive] WS handshake complete linked_id=%s", linked_id)
        return ws

    async def _pipe_audio_guarded(
        self,
        linked_id: str,
        ws: websockets.asyncio.client.ClientConnection,  # type: ignore[type-arg]
        audio_in: AsyncIterable[Any],
    ) -> None:
        """Wrapper that routes exceptions from the background audio pump to on_error."""
        try:
            await self._pipe_audio_in(linked_id, ws, audio_in)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            if self._error_handler:
                try:
                    self._error_handler(exc, linked_id)
                except Exception:
                    pass
            else:
                import traceback
                traceback.print_exc()

    async def _pipe_audio_in(
        self,
        linked_id: str,
        ws: websockets.asyncio.client.ClientConnection,  # type: ignore[type-arg]
        audio_in: AsyncIterable[Any],
    ) -> None:
        _logger.info("[GeminiLive] pipeAudioIn starting linked_id=%s", linked_id)
        diag = self._session_diag.get(linked_id)
        started_at = time.monotonic()
        exit_reason = "iterator_ended"
        try:
            async for chunk in audio_in:
                if self._stopped:
                    exit_reason = "adapter_stopped"
                    break
                if linked_id not in self._sessions:
                    exit_reason = "session_gone"
                    break

                # Accept AudioChunk or raw slin16 bytes (same tolerance as OpenAI adapter)
                if isinstance(chunk, (bytes, bytearray, memoryview)):
                    samples_16k = slin16_to_float32(bytes(chunk))
                else:
                    samples_attr = getattr(chunk, "samples", None)
                    if samples_attr is None:
                        raise TypeError(
                            f"Gemini Live adapter expected AudioChunk or bytes, "
                            f"got {type(chunk).__name__}"
                        )
                    # If upstream sends non-16kHz audio, resample; otherwise pass through.
                    chunk_sr = getattr(chunk, "sample_rate", DV_SAMPLE_RATE)
                    if chunk_sr == DV_SAMPLE_RATE:
                        samples_16k = samples_attr
                    else:
                        samples_16k = resample(samples_attr, chunk_sr, DV_SAMPLE_RATE)

                # Split into 20ms frames
                offset = 0
                length = len(samples_16k)
                while offset < length:
                    end = min(offset + INPUT_SAMPLES_16K, length)
                    frame = samples_16k[offset:end]
                    offset = end

                    pcm16 = float32_to_slin16(frame)
                    b64 = base64.b64encode(pcm16).decode("ascii")

                    self._send_event(ws, {
                        "realtime_input": {
                            "media_chunks": [
                                {"mime_type": "audio/pcm;rate=16000", "data": b64},
                            ],
                        },
                    })

                    # Increment AFTER the send is enqueued so the heartbeat
                    # reflects frames that actually went out on the wire.
                    if diag:
                        diag.chunks_sent_total += 1
                        diag.chunks_sent_since_heartbeat += 1
        finally:
            dur = round(time.monotonic() - started_at)
            _logger.info(
                "[GeminiLive] pipeAudioIn ended linked_id=%s reason=%s "
                "duration=%ds chunks_sent=%d",
                linked_id, exit_reason, dur,
                diag.chunks_sent_total if diag else 0,
            )

    def _handle_server_message(self, msg: dict[str, Any], linked_id: str) -> None:
        # Update diagnostic state FIRST — the heartbeat + silence watchdog
        # need to see this message's arrival timestamp even if one of the
        # branches below returns early.
        diag = self._session_diag.get(linked_id)
        if diag is not None:
            diag.last_server_message_at = time.monotonic()
            diag.last_server_message_type = classify_server_message(msg)

        # Setup complete (camelCase or snake_case from the wire)
        if "setupComplete" in msg or "setup_complete" in msg:
            _logger.info("[GeminiLive] session setup complete linked_id=%s", linked_id)
            return

        # ── Server content: main response channel ──
        # Accept both camelCase (per the spec) and snake_case (observed in
        # Live preview deployments). Falling back keeps audio flowing
        # through a Google backend rename.
        sc = msg.get("serverContent") or msg.get("server_content")
        if isinstance(sc, dict):
            model_turn = sc.get("modelTurn") or sc.get("model_turn")
            if isinstance(model_turn, dict):
                parts = model_turn.get("parts", [])
                if isinstance(parts, list):
                    audio_count = 0
                    text_count = 0

                    for part in parts:
                        if not isinstance(part, dict):
                            continue
                        inline = part.get("inlineData") or part.get("inline_data")
                        b64 = inline.get("data") if isinstance(inline, dict) else None

                        if b64:
                            audio_count += 1
                            mime = (
                                inline.get("mimeType")
                                or inline.get("mime_type")
                                or ""
                            )
                            source_rate = parse_rate_from_mime(mime) or GEMINI_OUTPUT_SAMPLE_RATE

                            pcm_src = base64.b64decode(b64)
                            samples_src = slin16_to_float32(pcm_src)
                            if source_rate != DV_SAMPLE_RATE:
                                samples_16k = resample(
                                    samples_src, source_rate, DV_SAMPLE_RATE,
                                )
                            else:
                                samples_16k = list(samples_src)

                            # Apply user-configured output gain. Gemini
                            # half-cascade models emit around -40 dBFS
                            # peak — ~30 dB quieter than OpenAI Realtime
                            # — which is barely audible over a phone
                            # line. `float32_to_slin16` below clamps to
                            # [-1.0, 1.0] so values above unity clip
                            # cleanly.
                            if self._output_gain_linear != 1.0:
                                gain = self._output_gain_linear
                                samples_16k = [s * gain for s in samples_16k]

                            pcm_16k = float32_to_slin16(samples_16k)

                            # First-chunk diagnostic — `peak` is measured
                            # on the PRE-gain source so the log shows the
                            # upstream level instead of a gain-hidden
                            # reading.
                            if linked_id not in self._logged_first_audio:
                                self._logged_first_audio.add(linked_id)
                                import math

                                peak = peak_amplitude(samples_src)
                                peak_db = (
                                    20 * math.log10(peak) if peak > 0 else -96.0
                                )
                                _logger.info(
                                    "[GeminiLive] first audio chunk linked_id=%s "
                                    "mime=%r source_rate=%dHz src_bytes=%d "
                                    "dst_bytes=%d peak=%.4f (%.1fdBFS) "
                                    "output_gain_db=%s",
                                    linked_id, mime, source_rate,
                                    len(pcm_src), len(pcm_16k), peak, peak_db,
                                    self._output_gain_db,
                                )
                                if peak < 1e-4:
                                    _logger.warning(
                                        "[GeminiLive] first audio chunk is silent "
                                        "(peak < -80dBFS) linked_id=%s — check "
                                        "Gemini model + responseModalities",
                                        linked_id,
                                    )
                                elif peak_db < -30 and self._output_gain_db < 12:
                                    # Nudge operators toward the fix when
                                    # Gemini is emitting quiet audio and
                                    # they haven't compensated.
                                    _logger.warning(
                                        "[GeminiLive] source peak %.1fdBFS is "
                                        "quiet for a phone sink (< -30 dBFS) "
                                        "and output_gain_db=%s is not "
                                        "compensating. Recommended: "
                                        "output_gain_db=24 for half-cascade.",
                                        peak_db, self._output_gain_db,
                                    )

                            if self._audio_output_handler:
                                self._audio_output_handler(pcm_16k, linked_id)
                        elif part.get("text"):
                            text_count += 1

                    # If Gemini sends text but never audio, the call is
                    # silent. Log exactly once per session so the operator
                    # doesn't have to guess between "Gemini broken" /
                    # "wiring broken" / "responseModalities ignored".
                    if (
                        text_count > 0
                        and audio_count == 0
                        and linked_id not in self._warned_text_only
                    ):
                        self._warned_text_only.add(linked_id)
                        _logger.warning(
                            "[GeminiLive] received TEXT-only response "
                            "(no inline_data) linked_id=%s parts=%d — the "
                            "model is not producing audio. Likely cause: "
                            "generationConfig.responseModalities did not "
                            "reach Gemini. Verify the setup message field "
                            "naming.",
                            linked_id, len(parts),
                        )

            # Interruption / barge-in
            if sc.get("interrupted") is True:
                turn_dur_ms = (
                    round((time.monotonic() - diag.turn_started_at) * 1000)
                    if diag else 0
                )
                _logger.info(
                    "[GeminiLive] barge-in detected (interrupted=True) linked_id=%s "
                    "turn=%d turn_duration=%dms",
                    linked_id, diag.turn_number if diag else 0, turn_dur_ms,
                )
                if not self._caller_speaking.get(linked_id):
                    self._caller_speaking[linked_id] = True
                    if self._speech_activity_handler:
                        self._speech_activity_handler(RealtimeSpeechActivityEvent(
                            linked_id=linked_id,
                            side="caller",
                            speaking=True,
                            timestamp_ms=time.time() * 1000,
                        ))

            turn_complete = sc.get("turnComplete")
            if turn_complete is None:
                turn_complete = sc.get("turn_complete")
            generation_complete = sc.get("generationComplete")
            if generation_complete is None:
                generation_complete = sc.get("generation_complete")

            if turn_complete is True or generation_complete is True:
                if self._caller_speaking.get(linked_id):
                    self._caller_speaking[linked_id] = False
                    if self._speech_activity_handler:
                        self._speech_activity_handler(RealtimeSpeechActivityEvent(
                            linked_id=linked_id,
                            side="caller",
                            speaking=False,
                            timestamp_ms=time.time() * 1000,
                        ))

            # Incremental transcription accumulation. First chunk per
            # turn is the critical diagnostic: if it never arrives,
            # Gemini's server_vad is not picking up the user's voice.
            input_tx = sc.get("inputTranscription") or sc.get("input_transcription")
            if isinstance(input_tx, dict) and input_tx.get("text") is not None:
                self._input_transcript_buf[linked_id] = (
                    self._input_transcript_buf.get(linked_id, "") + input_tx["text"]
                )
                if diag and not diag.saw_input_this_turn:
                    diag.saw_input_this_turn = True
                    _logger.info(
                        "[GeminiLive] first input_transcription linked_id=%s "
                        "turn=%d text=%r",
                        linked_id, diag.turn_number,
                        (input_tx["text"] or "")[:100],
                    )
            output_tx = sc.get("outputTranscription") or sc.get("output_transcription")
            if isinstance(output_tx, dict) and output_tx.get("text") is not None:
                self._output_transcript_buf[linked_id] = (
                    self._output_transcript_buf.get(linked_id, "") + output_tx["text"]
                )
                if diag and not diag.saw_output_this_turn:
                    diag.saw_output_this_turn = True
                    _logger.info(
                        "[GeminiLive] first output_transcription linked_id=%s "
                        "turn=%d text=%r",
                        linked_id, diag.turn_number,
                        (output_tx["text"] or "")[:100],
                    )

            # Flush accumulated transcripts on turn completion
            if turn_complete is True:
                input_text = self._input_transcript_buf.get(linked_id, "")
                output_text = self._output_transcript_buf.get(linked_id, "")
                turn_dur_ms = (
                    round((time.monotonic() - diag.turn_started_at) * 1000)
                    if diag else 0
                )
                _logger.info(
                    "[GeminiLive] turn_complete linked_id=%s turn=%d "
                    "duration=%dms input=%r output=%r",
                    linked_id, diag.turn_number if diag else 0, turn_dur_ms,
                    input_text[:100], output_text[:100],
                )
                if input_text.strip() and self._transcript_handler:
                    self._transcript_handler(TranscriptResult(
                        linked_id=linked_id,
                        text=input_text,
                        is_final=True,
                        speaker="customer",
                        timestamp_ms=time.time() * 1000,
                    ))
                if output_text.strip() and self._transcript_handler:
                    self._transcript_handler(TranscriptResult(
                        linked_id=linked_id,
                        text=output_text,
                        is_final=True,
                        speaker="agent",
                        timestamp_ms=time.time() * 1000,
                    ))
                self._input_transcript_buf[linked_id] = ""
                self._output_transcript_buf[linked_id] = ""
                # Advance turn counter + reset per-turn flags so the NEXT
                # turn's first input/output transcription gets logged again.
                if diag:
                    diag.turn_number += 1
                    diag.turn_started_at = time.monotonic()
                    diag.saw_input_this_turn = False
                    diag.saw_output_this_turn = False

        # Tool calls (camelCase or snake_case)
        tool_call = msg.get("toolCall") or msg.get("tool_call")
        if isinstance(tool_call, dict):
            fns = tool_call.get("functionCalls") or tool_call.get("function_calls") or []
            if isinstance(fns, list):
                for fc in fns:
                    if isinstance(fc, dict) and fc.get("name"):
                        args_str = json.dumps(fc.get("args") or {})
                        _logger.info(
                            "[GeminiLive] tool_call linked_id=%s name=%s args=%s",
                            linked_id, fc["name"],
                            args_str[:200] + "…" if len(args_str) > 200 else args_str,
                        )
                        if self._tool_call_handler:
                            self._tool_call_handler(RealtimeToolCall(
                                call_id=fc.get("id", ""),
                                name=fc["name"],
                                args=fc.get("args", {}) or {},
                                linked_id=linked_id,
                            ))

        # goAway — server signals session will close
        go_away = msg.get("goAway") or msg.get("go_away")
        if isinstance(go_away, dict):
            time_left = go_away.get("timeLeft") or go_away.get("time_left") or "unknown"
            if self._error_handler:
                self._error_handler(
                    RuntimeError(f"Gemini Live goAway: session closing in {time_left}"),
                    linked_id,
                )

    def _send_event(
        self,
        ws: websockets.asyncio.client.ClientConnection,  # type: ignore[type-arg]
        event: dict[str, object],
    ) -> None:
        asyncio.ensure_future(self._send_event_locked(ws, event))

    async def _send_event_locked(
        self,
        ws: websockets.asyncio.client.ClientConnection,  # type: ignore[type-arg]
        event: dict[str, object],
    ) -> None:
        async with self._ws_lock:
            try:
                await ws.send(json.dumps(event))
            except websockets.exceptions.ConnectionClosed:
                pass


# ─── Live model registry ────────────────────────────────────────────────────
#
# Google rotates Gemini Live model IDs every few months — `gemini-live-2.5-
# flash-preview` for example was renamed in late 2025, leaving every SDK
# pinned to that ID with `code=1008 reason="...is not found... or is not
# supported for bidiGenerateContent"` from the WS handshake. The fix is
# not to hard-code a default at all but to read the live registry at
# runtime via `models.list` and pick a current model.

_live_model_cache: dict[str, dict[str, object]] = {}


async def list_gemini_live_models(
    api_key: str,
    *,
    cache_ttl_s: float = 300.0,
) -> list[dict[str, str]]:
    """Fetch the current set of Gemini models that support
    ``bidiGenerateContent`` (Live API).

    Hits Google's ``models.list`` endpoint, filters by supported
    generation method, and caches per API key for ``cache_ttl_s``
    (default 5 minutes).

    Use at startup — or on a 1008 "not found" WS close — to discover
    which Live-capable models are currently live without redeploying.

    Args:
        api_key: AI Studio API key.
        cache_ttl_s: Cache TTL per API key. Set 0 to bypass the cache
            (useful right after a 1008 close to pick up a fresh
            registry).

    Returns:
        A list of dicts with keys ``name``, ``displayName``,
        ``description``, ``version``. ``name`` is the full resource
        path (e.g. ``models/gemini-2.5-flash-native-audio-preview-09-2025``);
        strip the ``models/`` prefix before passing to the adapter.

    Example::

        from dvgateway.adapters.realtime import (
            GeminiLiveAdapter, list_gemini_live_models,
        )

        api_key = os.environ["GEMINI_API_KEY"]
        live = await list_gemini_live_models(api_key)
        # Prefer native-audio variants when available.
        model = next(
            (m["name"] for m in live if "native-audio" in m["name"]),
            next((m["name"] for m in live if "flash" in m["name"]), None),
        )
        if not model:
            raise RuntimeError("No Gemini Live-capable models available")

        adapter = GeminiLiveAdapter(
            api_key=api_key,
            model=model.removeprefix("models/"),
            voice="Puck",
        )
    """
    if not api_key:
        raise ValueError("list_gemini_live_models: api_key is required")

    cached = _live_model_cache.get(api_key)
    if cache_ttl_s > 0 and cached is not None:
        fetched_at = float(cached.get("fetched_at", 0.0))  # type: ignore[arg-type]
        if time.monotonic() - fetched_at < cache_ttl_s:
            return cached["models"]  # type: ignore[return-value]

    # aiohttp is already a runtime dep of the SDK (transport/http_client)
    # so we don't pull in a new dependency here.
    import aiohttp

    url = (
        "https://generativelanguage.googleapis.com/v1beta/models?"
        f"key={quote(api_key)}&pageSize=200"
    )
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as resp:
            if resp.status != 200:
                body = await resp.text()
                raise RuntimeError(
                    f"list_gemini_live_models: HTTP {resp.status} from "
                    f"models.list — {body[:200]}"
                )
            data = await resp.json()

    all_models = data.get("models") or []
    live_models: list[dict[str, str]] = [
        {
            "name":        str(m.get("name", "")),
            "displayName": str(m.get("displayName", "")),
            "description": str(m.get("description", "")),
            "version":     str(m.get("version", "")),
        }
        for m in all_models
        if isinstance(m, dict)
        and "bidiGenerateContent" in (m.get("supportedGenerationMethods") or [])
    ]

    _live_model_cache[api_key] = {
        "models": live_models,
        "fetched_at": time.monotonic(),
    }
    return live_models


def _reset_live_model_cache() -> None:
    """Reset the module-level live-model cache. Exposed for tests;
    production callers should use ``cache_ttl_s`` in
    :func:`list_gemini_live_models` instead.
    """
    _live_model_cache.clear()
