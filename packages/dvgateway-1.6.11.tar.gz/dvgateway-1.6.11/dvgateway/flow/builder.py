"""VoiceFlow Builder — fluent stage-graph runtime for SDK voice flows.

A ``VoiceFlow`` describes a directed graph of stages. Each stage declares
its required audio mode (``none`` / ``tts-only`` / ``stt-only`` / ``full``)
and behavior via ``on_enter``. The runtime spawns a per-call execution that:

  1. Listens for ``call:new`` events (filtered by tenant, optionally by DID)
  2. Enters the start stage — calls ``gw.attach_audio`` if mode != ``"none"``
  3. Runs ``on_enter``; the context exposes ``say()``, ``play_audio()``,
     ``collect_dtmf()``, ``transition_to()``, ``hangup()``, ``set_var()``
     / ``get_var()``
  4. Transitions on DTMF (per ``on_dtmf`` map) or explicit ``transition_to``
  5. Detaches/reattaches audio when the next stage's mode differs
  6. Tears down on ``call:ended`` or ``ctx.hangup()``

Calls that did NOT enter with ``flow=true`` (i.e. ExternalMedia attached
at StasisStart) are ignored — ``attach_audio`` would 404 anyway and the
flow runtime trusts the gateway's ``flow_mode`` flag implicitly.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from typing import (
    TYPE_CHECKING,
    Any,
    Awaitable,
    Callable,
    Literal,
    Optional,
)

from dvgateway.types import (
    CallDtmfEvent,
    CallEndedEvent,
    CallNewEvent,
    CallSession,
    DTMFResult,
    Logger,
    TtsAdapter,
    Unsubscribe,
)

if TYPE_CHECKING:
    from dvgateway.client import DVGatewayClient


FlowAudioMode = Literal["none", "tts-only", "stt-only", "full"]
"""Stage audio requirement.

  - ``"none"``     — detach (silence on the line; DTMF still arrives)
  - ``"tts-only"`` — attach with dir='out' (gateway → caller)
  - ``"stt-only"`` — attach with dir='in' (caller → gateway)
  - ``"full"``     — attach with dir='both' (default conversational mode)
"""


def _audio_mode_to_dir(mode: FlowAudioMode) -> Optional[Literal["both", "in", "out"]]:
    if mode == "none":
        return None
    if mode == "tts-only":
        return "out"
    if mode == "stt-only":
        return "in"
    if mode == "full":
        return "both"
    raise ValueError(f"unknown audio mode: {mode!r}")


# ─── Public API ─────────────────────────────────────────────────────────────


@dataclass
class FlowContext:
    """Per-call context passed to every stage's ``on_enter``.

    Wraps the parent client with helpers that auto-bind ``linked_id``.
    Variables are scoped to a single call execution.
    """

    linked_id: str
    session: CallSession
    client: "DVGatewayClient"
    _vars: dict[str, Any] = field(default_factory=dict)
    _execution: "_FlowExecution" = field(repr=False, default=None)  # type: ignore[assignment]

    async def say(self, text: str, tts: TtsAdapter) -> None:
        """Inject TTS into this call. Equivalent to
        ``client.say(linked_id, text, tts)``.
        """
        await self.client.say(self.linked_id, text, tts)

    async def play_audio(
        self, url: str, *, interrupt_on_dtmf: bool = False
    ) -> None:
        """Play a URL through the parent client."""
        await self.client.play_audio(
            linked_id=self.linked_id,
            url=url,
            interrupt_on_dtmf=interrupt_on_dtmf,
        )

    async def collect_dtmf(
        self,
        *,
        max_digits: int = 1,
        timeout_ms: int = 5000,
        inter_digit_timeout_ms: int = 2000,
        terminator: str = "#",
    ) -> DTMFResult:
        """Collect DTMF digits with the same semantics as
        ``client.collect_dtmf``.
        """
        return await self.client.collect_dtmf(
            linked_id=self.linked_id,
            max_digits=max_digits,
            timeout_ms=timeout_ms,
            inter_digit_timeout_ms=inter_digit_timeout_ms,
            terminator=terminator,
        )

    def transition_to(self, stage_name: str) -> None:
        """Schedule a transition. Effective once ``on_enter`` returns."""
        if not self._execution._stages.get(stage_name):
            raise ValueError(f"transition_to: unknown stage {stage_name!r}")
        self._execution._next_stage = stage_name

    async def hangup(self) -> None:
        """Hangup the call and end the flow."""
        await self.client.hangup(self.linked_id)
        self._execution._ended = True

    def set_var(self, key: str, value: Any) -> None:
        """Set a per-call variable."""
        self._vars[key] = value

    def get_var(self, key: str, default: Any = None) -> Any:
        """Read a per-call variable."""
        return self._vars.get(key, default)


@dataclass
class FlowStage:
    """Stage definition.

    ``on_enter`` runs once when the stage is entered. Use ``on_dtmf`` for
    one-key transitions; for multi-digit input call ``ctx.collect_dtmf``
    inside ``on_enter``.
    """

    audio: FlowAudioMode = "none"
    on_enter: Optional[Callable[[FlowContext], Awaitable[None]]] = None
    on_dtmf: Optional[dict[str, str]] = None
    on_exit: Optional[Callable[[FlowContext], Awaitable[None]]] = None


# ─── Builder ────────────────────────────────────────────────────────────────


class VoiceFlowBuilder:
    """Fluent builder for a stage-graph voice flow."""

    def __init__(self, client: "DVGatewayClient", logger: Logger) -> None:
        self._client = client
        self._logger = logger
        self._stages: dict[str, FlowStage] = {}
        self._start_stage: Optional[str] = None
        self._did_filter: Optional[str] = None

    def stage(
        self,
        name: str,
        *,
        audio: FlowAudioMode = "none",
        on_enter: Optional[Callable[[FlowContext], Awaitable[None]]] = None,
        on_dtmf: Optional[dict[str, str]] = None,
        on_exit: Optional[Callable[[FlowContext], Awaitable[None]]] = None,
    ) -> "VoiceFlowBuilder":
        """Register a stage. Names must be unique per flow."""
        if name in self._stages:
            raise ValueError(f"stage {name!r} already registered")
        self._stages[name] = FlowStage(
            audio=audio,
            on_enter=on_enter,
            on_dtmf=dict(on_dtmf) if on_dtmf else None,
            on_exit=on_exit,
        )
        return self

    def start_stage(self, name: str) -> "VoiceFlowBuilder":
        """Designate the entry stage for new calls."""
        self._start_stage = name
        return self

    def for_did(self, did: str) -> "VoiceFlowBuilder":
        """Only enter this flow for calls whose called number (DID) matches.

        Useful when multiple flows share one gateway — without this, the
        first registered flow would consume every flow=true call.
        """
        self._did_filter = did
        return self

    def start(self) -> Unsubscribe:
        """Activate the flow. Returns an unsubscribe callable that, when
        invoked, stops accepting new calls; in-flight executions continue.
        """
        if not self._start_stage:
            raise RuntimeError("flow.start() called without start_stage()")
        if self._start_stage not in self._stages:
            raise RuntimeError(
                f"start_stage {self._start_stage!r} not registered"
            )
        for name, stage in self._stages.items():
            if stage.on_dtmf:
                for digit, target in stage.on_dtmf.items():
                    if target not in self._stages:
                        raise RuntimeError(
                            f"stage {name!r} on_dtmf[{digit!r}] → unknown stage {target!r}"
                        )

        executions: dict[str, _FlowExecution] = {}
        # Strong references to in-flight flow tasks. asyncio.ensure_future()
        # only weakly holds the resulting Task; without an explicit set the
        # task can be garbage-collected mid-flight under memory pressure
        # (or during loop shutdown), at which point Python sends
        # GeneratorExit through the coroutine. If the task's current
        # `await` (or a nested cleanup await) cannot service GeneratorExit,
        # asyncio raises:
        #
        #     RuntimeError: coroutine ignored GeneratorExit
        #     Task was destroyed but it is pending!
        #
        # Holding the task in this set until done_callback fires keeps the
        # GC from prematurely destroying it.
        running_tasks: set[asyncio.Task[None]] = set()

        def on_new_call(ev: CallNewEvent) -> None:
            session = ev.session
            if self._did_filter and session.did != self._did_filter and session.callee != self._did_filter:
                return
            exec_ = _FlowExecution(
                client=self._client,
                logger=self._logger,
                stages=self._stages,
                start_stage=self._start_stage or "",
                session=session,
            )
            executions[session.linked_id] = exec_

            async def _run_and_cleanup() -> None:
                try:
                    await exec_.run()
                except asyncio.CancelledError:
                    # Cooperative cancellation — propagate so the asyncio
                    # task system can mark the task cancelled cleanly.
                    self._logger.debug(
                        {"linked_id": session.linked_id},
                        "VoiceFlow execution cancelled",
                    )
                    raise
                except GeneratorExit:
                    # Coroutine is being closed (typically GC of an
                    # unfinished task or event-loop shutdown). Returning
                    # without awaiting anything else is the only safe
                    # option; awaiting after GeneratorExit raises
                    # `RuntimeError: coroutine ignored GeneratorExit`.
                    self._logger.warning(
                        {"linked_id": session.linked_id},
                        "VoiceFlow execution destroyed mid-flight (GC) — cleanup skipped",
                    )
                    return
                except Exception:
                    self._logger.exception(
                        {"linked_id": session.linked_id},
                        "VoiceFlow execution raised — terminating",
                    )
                finally:
                    executions.pop(session.linked_id, None)

            task = asyncio.ensure_future(_run_and_cleanup())
            running_tasks.add(task)
            task.add_done_callback(running_tasks.discard)

        def on_call_ended(ev: CallEndedEvent) -> None:
            exec_ = executions.get(ev.linked_id)
            if exec_:
                exec_.notify_ended()

        unsub_new = self._client.on("call:new", on_new_call)
        unsub_end = self._client.on("call:ended", on_call_ended)
        self._logger.info(
            {
                "start_stage": self._start_stage,
                "stage_count": len(self._stages),
                "did_filter": self._did_filter or "any",
            },
            "VoiceFlow started",
        )

        def stop() -> None:
            unsub_new()
            unsub_end()
            # Cancel any in-flight flow tasks and let them surface
            # CancelledError through their existing handler. Without this
            # the tasks would survive past stop() and could log spurious
            # "ended" events long after the builder is supposedly idle.
            # Tasks are not awaited here (stop() is sync) — caller is
            # responsible for shutting down the event loop afterwards.
            for task in list(running_tasks):
                if not task.done():
                    task.cancel()
            self._logger.info(
                {"in_flight": len(running_tasks)},
                "VoiceFlow stopped (in-flight tasks cancelled)",
            )

        return stop


# ─── Execution ─────────────────────────────────────────────────────────────


class _FlowExecution:
    def __init__(
        self,
        *,
        client: "DVGatewayClient",
        logger: Logger,
        stages: dict[str, FlowStage],
        start_stage: str,
        session: CallSession,
    ) -> None:
        self._client = client
        self._logger = logger
        self._stages = stages
        self._session = session
        self._current_stage = start_stage
        self._current_audio_mode: FlowAudioMode = "none"
        self._next_stage: Optional[str] = None
        self._ended = False
        self._vars: dict[str, Any] = {}
        self._dtmf_unsub: Optional[Unsubscribe] = None
        self._dtmf_signal: Optional[asyncio.Event] = None

    def notify_ended(self) -> None:
        self._ended = True
        if self._dtmf_signal:
            self._dtmf_signal.set()

    async def run(self) -> None:
        linked_id = self._session.linked_id
        self._logger.debug(
            {"linked_id": linked_id, "start_stage": self._current_stage},
            "Flow execution started",
        )
        try:
            while not self._ended:
                stage_name = self._current_stage
                stage = self._stages.get(stage_name)
                if not stage:
                    self._logger.error(
                        {"linked_id": linked_id, "stage_name": stage_name},
                        "Flow stage not found — terminating execution",
                    )
                    return

                # Reconcile audio mode before on_enter runs.
                try:
                    await self._reconcile_audio(stage.audio)
                except Exception:
                    return  # _reconcile_audio sets _ended and logs

                self._attach_dtmf_router(stage.on_dtmf)

                ctx = self._make_context()
                try:
                    if stage.on_enter:
                        await stage.on_enter(ctx)
                except Exception as err:
                    self._logger.error(
                        {
                            "linked_id": linked_id,
                            "stage_name": stage_name,
                            "err": str(err),
                        },
                        "Flow stage on_enter raised — terminating execution",
                    )
                    self._detach_dtmf_router()
                    return

                next_stage = self._next_stage
                self._next_stage = None

                if not next_stage and not stage.on_dtmf:
                    self._detach_dtmf_router()
                    return

                if not next_stage and stage.on_dtmf:
                    next_stage = await self._wait_for_dtmf_transition()
                    if not next_stage:
                        return

                if stage.on_exit:
                    try:
                        await stage.on_exit(self._make_context())
                    except Exception as err:
                        self._logger.warning(
                            {
                                "linked_id": linked_id,
                                "stage_name": stage_name,
                                "err": str(err),
                            },
                            "Flow stage on_exit raised — continuing",
                        )

                self._detach_dtmf_router()
                self._current_stage = next_stage
        finally:
            self._detach_dtmf_router()
            try:
                await self._client.detach_audio(linked_id)
            except Exception:
                pass
            self._logger.debug({"linked_id": linked_id}, "Flow execution ended")

    async def _reconcile_audio(self, target: FlowAudioMode) -> None:
        if target == self._current_audio_mode:
            return
        linked_id = self._session.linked_id
        target_dir = _audio_mode_to_dir(target)
        current_dir = _audio_mode_to_dir(self._current_audio_mode)

        if current_dir and (target_dir is None or current_dir != target_dir):
            try:
                await self._client.detach_audio(linked_id)
            except Exception as err:
                self._logger.warning(
                    {"linked_id": linked_id, "err": str(err)},
                    "Flow detach_audio failed — continuing",
                )

        if target_dir:
            try:
                await self._client.attach_audio(linked_id, target_dir)
            except Exception as err:
                self._logger.error(
                    {"linked_id": linked_id, "err": str(err)},
                    "Flow attach_audio failed — terminating execution (call may not be flow=true)",
                )
                self._ended = True
                raise

        self._current_audio_mode = target

    def _attach_dtmf_router(
        self, on_dtmf: Optional[dict[str, str]]
    ) -> None:
        self._detach_dtmf_router()
        if not on_dtmf:
            return
        linked_id = self._session.linked_id
        self._dtmf_signal = asyncio.Event()

        def _on_dtmf(ev: CallDtmfEvent) -> None:
            if ev.linked_id != linked_id:
                return
            if ev.phase != "end":
                return
            target = on_dtmf.get(ev.digit)
            if not target:
                return
            self._next_stage = target
            if self._dtmf_signal:
                self._dtmf_signal.set()

        self._dtmf_unsub = self._client.on("call:dtmf", _on_dtmf)

    def _detach_dtmf_router(self) -> None:
        if self._dtmf_unsub:
            try:
                self._dtmf_unsub()
            except Exception:
                pass
            self._dtmf_unsub = None
        self._dtmf_signal = None

    async def _wait_for_dtmf_transition(self) -> Optional[str]:
        if self._next_stage:
            r = self._next_stage
            self._next_stage = None
            return r
        if not self._dtmf_signal:
            return None
        # Wake periodically so call:ended can break us out.
        while not self._ended:
            try:
                await asyncio.wait_for(self._dtmf_signal.wait(), timeout=0.25)
            except asyncio.TimeoutError:
                continue
            if self._next_stage:
                r = self._next_stage
                self._next_stage = None
                return r
            return None
        return None

    def _make_context(self) -> FlowContext:
        return FlowContext(
            linked_id=self._session.linked_id,
            session=self._session,
            client=self._client,
            _vars=self._vars,
            _execution=self,
        )
