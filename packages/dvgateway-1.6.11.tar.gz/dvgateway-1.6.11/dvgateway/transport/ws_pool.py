"""
WebSocket Connection Pool

Manages WebSocket connections with:
- Automatic reconnection (exponential backoff with jitter)
- Active subscription restoration after reconnect
- Proper cleanup on close

Uses the modern ``websockets.asyncio.client`` API (websockets ≥ 13). The
legacy ``websockets.client.WebSocketClientProtocol`` has a known race in its
``_drain_helper`` that fires an ``AssertionError`` when the keepalive ping
runs concurrently with a transport close — observed in production logs as::

    websockets.client - ERROR - keepalive ping failed
    File ".../websockets/legacy/protocol.py", line 308, in _drain_helper
        assert waiter is None or waiter.cancelled()
    AssertionError

The new asyncio API does not wrap ``asyncio.StreamReader/Writer`` and so does
not exhibit this race.
"""

from __future__ import annotations

import asyncio
import random
from dataclasses import dataclass, field
from typing import Callable, Protocol

import websockets
import websockets.asyncio.client
import websockets.exceptions

from dvgateway.auth.manager import AuthManager
from dvgateway.types import Logger, ReconnectOptions


@dataclass
class WsSubscription:
    id: str
    path: str
    params: dict[str, str] = field(default_factory=dict)
    on_message: Callable[[bytes], None] = lambda _: None
    on_close: Callable[[], None] | None = None


class SimulatedSocket(Protocol):
    """Handle returned from a simulated route's ``on_subscribe`` callback.

    Forwards outbound sends from the WsPool into the simulator and lets
    the pool close the virtual connection on ``unsubscribe``.
    """

    def send(self, data: bytes) -> None: ...
    def send_text(self, text: str) -> None: ...
    def close(self) -> None: ...


class SimulatedRoute(Protocol):
    """Route interceptor used by the simulator to replace real WebSocket
    connections with in-process virtual sockets.

    When :meth:`matches` returns true for a subscription's ``path`` +
    ``params``, :meth:`on_subscribe` is invoked and the returned handle
    receives all outbound sends, while inbound frames are pushed back
    into the subscription's ``on_message`` callback.

    Registered via :meth:`WsPool.add_simulated_route` — production code
    should never touch this.
    """

    def matches(self, path: str, params: dict[str, str]) -> bool: ...
    def on_subscribe(self, sub: WsSubscription) -> SimulatedSocket: ...


class WsPool:
    """WebSocket connection pool with automatic reconnection."""

    def __init__(self, auth: AuthManager, reconnect: ReconnectOptions, logger: Logger) -> None:
        self._auth = auth
        self._logger = logger
        self._reconnect = reconnect

        self._connections: dict[str, _ManagedConnection] = {}
        self._event_handlers: dict[str, list[Callable[..., None]]] = {}
        #: Simulated routes registered by the SDK simulator; checked
        #: before opening any real WebSocket connection.
        self._simulated_routes: list[SimulatedRoute] = []

    def add_simulated_route(self, route: SimulatedRoute) -> Callable[[], None]:
        """Register a simulated route and return a disposer.

        Any existing connection whose path+params match the new route is
        cut over to the simulator: any pending real-WS attempt is
        cancelled, a virtual socket is attached, and a synthetic
        ``connected`` event is emitted. This lets ``simulate()`` be
        called after the pipeline has already started its subscriptions.
        """
        self._simulated_routes.append(route)

        # Cut over any live connections that now match this route.
        for sub_id, conn in list(self._connections.items()):
            if conn.closed or conn.simulated is not None:
                continue
            if not route.matches(conn.subscription.path, conn.subscription.params):
                continue

            if conn.reconnect_task and not conn.reconnect_task.done():
                conn.reconnect_task.cancel()
                conn.reconnect_task = None
            if conn.ws is not None:
                try:
                    asyncio.ensure_future(conn.ws.close(1000, "replaced by simulator"))
                except Exception:
                    pass
                conn.ws = None
            conn.reconnect_attempts = 0
            conn.simulated = route.on_subscribe(conn.subscription)
            # Fire "connected" on the next loop iteration so any
            # handler registered right after add_simulated_route() still
            # catches the event.
            asyncio.get_event_loop().call_soon(self.emit, "connected", sub_id)

        def _dispose() -> None:
            try:
                self._simulated_routes.remove(route)
            except ValueError:
                pass

        return _dispose

    def on(self, event: str, handler: Callable[..., None]) -> None:
        """Register an event handler."""
        self._event_handlers.setdefault(event, []).append(handler)

    def once(self, event: str, handler: Callable[..., None]) -> None:
        """Register a one-time event handler."""
        def wrapper(*args: object) -> None:
            handler(*args)
            handlers = self._event_handlers.get(event, [])
            if wrapper in handlers:
                handlers.remove(wrapper)

        self.on(event, wrapper)

    def emit(self, event: str, *args: object) -> None:
        """Emit an event to all registered handlers."""
        for handler in self._event_handlers.get(event, []):
            handler(*args)

    async def subscribe(self, sub: WsSubscription) -> None:
        """Open a managed WebSocket connection for a subscription.

        If any registered simulated route matches, the subscription is
        served from the simulator instead of opening a real socket.
        """
        conn = _ManagedConnection(subscription=sub)
        self._connections[sub.id] = conn

        # Check simulated routes first — matches intercept before we
        # open a real socket. This is how the SDK simulator replaces
        # the gateway end-to-end.
        for route in self._simulated_routes:
            if route.matches(sub.path, sub.params):
                conn.simulated = route.on_subscribe(sub)
                # Fire "connected" synchronously. This path contains no
                # `await`, so `subscribe()` returns without yielding to
                # the event loop — callers that schedule a check
                # immediately after `await subscribe(...)` (e.g. the
                # TTS injector's fallback-to-HTTP detection) would see
                # the connection as not-yet-ready if we deferred the
                # emit to `call_soon`. Callers MUST register their
                # "connected" handler before calling subscribe().
                self.emit("connected", sub.id)
                return

        await self._connect(conn)

    def unsubscribe(self, sub_id: str) -> None:
        """Close a specific subscription."""
        conn = self._connections.get(sub_id)
        if not conn:
            return
        conn.closed = True
        if conn.reconnect_task and not conn.reconnect_task.done():
            conn.reconnect_task.cancel()
        if conn.simulated is not None:
            try:
                conn.simulated.close()
            finally:
                conn.simulated = None
        if conn.ws:
            asyncio.ensure_future(conn.ws.close(1000, "unsubscribed"))
        del self._connections[sub_id]
        self._logger.debug({"id": sub_id}, "WebSocket subscription closed")

    def close_all(self) -> None:
        """Close all connections."""
        for sub_id in list(self._connections.keys()):
            self.unsubscribe(sub_id)

    async def send(self, sub_id: str, data: bytes) -> None:
        """Send binary data through a subscription's WebSocket."""
        conn = self._connections.get(sub_id)
        if not conn:
            return
        if conn.simulated is not None:
            conn.simulated.send(data)
            return
        if conn.ws:
            await conn.ws.send(data)

    async def send_text(self, sub_id: str, text: str) -> None:
        """Send a text message through a subscription's WebSocket."""
        conn = self._connections.get(sub_id)
        if not conn:
            return
        if conn.simulated is not None:
            conn.simulated.send_text(text)
            return
        if conn.ws:
            await conn.ws.send(text)

    async def _connect(self, conn: _ManagedConnection) -> None:
        if conn.closed:
            return

        try:
            url = await self._auth.build_ws_url(conn.subscription.path, conn.subscription.params)
        except Exception as e:
            self._logger.error({"err": str(e), "id": conn.subscription.id}, "Failed to build WebSocket URL")
            self._schedule_reconnect(conn)
            return

        self._logger.debug({"id": conn.subscription.id, "path": conn.subscription.path}, "Opening WebSocket")

        try:
            # websockets.asyncio.client.connect — new asyncio API. Keepalive
            # params (ping_interval / ping_timeout) and open_timeout transfer
            # verbatim from the legacy API.
            ws = await websockets.asyncio.client.connect(
                url, open_timeout=10, ping_interval=30, ping_timeout=60
            )
        except Exception as e:
            self._logger.error({"err": str(e), "id": conn.subscription.id}, "WebSocket connection failed")
            self._schedule_reconnect(conn)
            return

        conn.ws = ws
        conn.reconnect_attempts = 0
        self._logger.debug({"id": conn.subscription.id}, "WebSocket connected")
        self.emit("connected", conn.subscription.id)

        # Start reading messages in the background
        conn.read_task = asyncio.ensure_future(self._read_loop(conn))

    async def _read_loop(self, conn: _ManagedConnection) -> None:
        assert conn.ws is not None
        try:
            async for message in conn.ws:
                if conn.closed:
                    break
                if isinstance(message, bytes):
                    conn.subscription.on_message(message)
                else:
                    conn.subscription.on_message(message.encode("utf-8"))
        except websockets.exceptions.ConnectionClosed:
            pass
        except Exception as e:
            self._logger.error({"id": conn.subscription.id, "err": str(e)}, "WebSocket error")
        finally:
            if not conn.closed:
                self._logger.warn({"id": conn.subscription.id}, "WebSocket closed unexpectedly")
                if conn.subscription.on_close:
                    conn.subscription.on_close()
                self._schedule_reconnect(conn)

    def _schedule_reconnect(self, conn: _ManagedConnection) -> None:
        if conn.closed:
            return
        max_attempts = self._reconnect.max_attempts
        if conn.reconnect_attempts >= max_attempts:
            self._logger.error(
                {"id": conn.subscription.id, "attempts": conn.reconnect_attempts},
                "Max reconnect attempts reached",
            )
            if self._reconnect.on_max_attempts_reached:
                self._reconnect.on_max_attempts_reached()
            self.emit("maxAttemptsReached", conn.subscription.id)
            return

        jitter = random.random() * 0.3
        base = self._reconnect.initial_delay_ms * (self._reconnect.backoff_multiplier ** conn.reconnect_attempts)
        delay_ms = min(base * (1 + jitter), self._reconnect.max_delay_ms)
        conn.reconnect_attempts += 1

        self._logger.info(
            {"id": conn.subscription.id, "attempt": conn.reconnect_attempts, "delay_ms": round(delay_ms)},
            "Scheduling WebSocket reconnect",
        )

        async def _reconnect_after_delay() -> None:
            await asyncio.sleep(delay_ms / 1000.0)
            if self._reconnect.on_reconnect:
                self._reconnect.on_reconnect(conn.reconnect_attempts)
            self.emit("reconnecting", conn.subscription.id, conn.reconnect_attempts)
            await self._connect(conn)

        conn.reconnect_task = asyncio.ensure_future(_reconnect_after_delay())


@dataclass
class _ManagedConnection:
    subscription: WsSubscription = field(default_factory=WsSubscription)
    ws: websockets.asyncio.client.ClientConnection | None = None  # type: ignore[type-arg]
    reconnect_attempts: int = 0
    closed: bool = False
    reconnect_task: asyncio.Task[None] | None = None
    read_task: asyncio.Task[None] | None = None
    #: Populated when a simulated route claims this subscription.
    simulated: SimulatedSocket | None = None
