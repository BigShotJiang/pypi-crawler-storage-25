from __future__ import annotations

import contextlib
import threading
from typing import TYPE_CHECKING

import pytest

from dbxignore import cli, daemon, reconcile, state
from tests.conftest import BlockingMarkers, _poll_until, setup_daemon_state

if TYPE_CHECKING:
    from pathlib import Path

    from tests.conftest import FakePsutilProcess


# ---- singleton lock ---------------------------------------------------------


def test_acquire_singleton_lock_succeeds_on_fresh_state_dir(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """First acquisition on an empty state dir succeeds and returns a
    non-None file handle. The handle is what the caller holds for the
    daemon's lifetime; closing it releases the lock."""
    monkeypatch.setattr(state, "user_state_dir", lambda: tmp_path)
    fh = daemon._acquire_singleton_lock()
    assert fh is not None
    fh.close()


def test_acquire_singleton_lock_returns_none_when_already_held(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Second acquisition while the first is still held returns None.
    This is the singleton gate — a state-based check (read state.json →
    is_daemon_alive) would have a non-atomic read-then-write window
    where two concurrent daemon launches could both proceed."""
    monkeypatch.setattr(state, "user_state_dir", lambda: tmp_path)
    first = daemon._acquire_singleton_lock()
    assert first is not None
    try:
        second = daemon._acquire_singleton_lock()
        assert second is None
    finally:
        first.close()


def test_acquire_singleton_lock_after_release_succeeds(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """After the first holder closes its handle, the lock is released
    and a fresh acquisition succeeds. Verifies the close-releases-lock
    contract that all the cross-platform locking primitives provide."""
    monkeypatch.setattr(state, "user_state_dir", lambda: tmp_path)
    first = daemon._acquire_singleton_lock()
    assert first is not None
    first.close()
    second = daemon._acquire_singleton_lock()
    assert second is not None
    second.close()


def test_acquire_singleton_lock_seeks_to_byte_zero_before_locking(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """``msvcrt.locking`` on Windows locks from the file's current cursor
    position (Python docs: "The lock starts at the file's current
    position"). Without an explicit seek to 0, two concurrent fresh
    launches that both end at different cursors after the placeholder
    write can lock different byte ranges and both succeed — defeating
    the singleton. The implementation must seek to 0 before locking so
    every contender competes for byte 0 regardless of the file's
    pre-existing size or the cursor's post-write position.

    Test surface: pre-populate the lock file with 100 bytes (so the
    placeholder-write branch is skipped and the cursor would otherwise
    sit at EOF after the ``"ab+"`` open). Acquire the lock. Assert the
    cursor is at 0 — proving ``seek(0)`` ran before the lock primitive.
    Cross-platform: fcntl.flock doesn't care about cursor on POSIX, but
    the seek is harmless and the contract is consistent.
    """
    monkeypatch.setattr(state, "user_state_dir", lambda: tmp_path)
    lock_path = tmp_path / "daemon.lock"
    lock_path.write_bytes(b"x" * 100)

    fh = daemon._acquire_singleton_lock()
    assert fh is not None
    try:
        assert fh.tell() == 0, (
            f"expected cursor at byte 0 after lock, got {fh.tell()} — "
            "_acquire_singleton_lock must seek to 0 before locking so "
            "all contenders compete for byte 0 regardless of file size"
        )
    finally:
        fh.close()


def test_run_refuses_when_singleton_lock_is_held(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path, caplog: pytest.LogCaptureFixture
) -> None:
    """daemon.run() refuses to start when daemon.lock is already held.

    The test process itself acquires the lock, then calls daemon.run() —
    which sees contention and refuses with an ERROR log. Deterministic,
    no subprocess, no timing dependency.
    """
    monkeypatch.setattr(state, "user_state_dir", lambda: tmp_path)
    monkeypatch.setattr(state, "default_path", lambda: tmp_path / "state.json")
    monkeypatch.setattr(daemon.roots_module, "discover", lambda: [tmp_path])  # type: ignore[attr-defined]
    monkeypatch.setattr(daemon, "_configured_logging", contextlib.nullcontext)

    lock_holder = daemon._acquire_singleton_lock()
    assert lock_holder is not None, "test process should be able to acquire fresh lock"
    try:
        caplog.set_level("ERROR", logger="dbxignore.daemon")
        daemon.run()
        assert any("already running" in rec.message.lower() for rec in caplog.records)
    finally:
        lock_holder.close()


def test_run_refuses_when_state_shows_alive_daemon_without_lock(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    caplog: pytest.LogCaptureFixture,
    fake_psutil_process: FakePsutilProcess,
) -> None:
    """Defense-in-depth: a state.json points at an alive daemon PID but
    no daemon.lock is held. The new daemon's lock-acquire succeeds (no
    contention), so without a state-check after acquisition two daemons
    would run on the same Dropbox roots.

    Test: write a state.json with a daemon pid (no daemon_create_time),
    mock psutil to claim that pid is a live python process, call
    daemon.run(), assert it refuses and releases the lock.
    """
    monkeypatch.setattr(state, "user_state_dir", lambda: tmp_path)
    monkeypatch.setattr(state, "default_path", lambda: tmp_path / "state.json")
    monkeypatch.setattr(daemon.roots_module, "discover", lambda: [tmp_path])  # type: ignore[attr-defined]
    monkeypatch.setattr(daemon, "_configured_logging", contextlib.nullcontext)

    # Pick a pid that's not our own so the self-exclusion branch doesn't
    # short-circuit. 99999 is in the "almost certainly unused" range; the
    # mocked psutil makes its existence claim deterministic regardless.
    alien_pid = 99999
    s = state.State(daemon_pid=alien_pid)
    state.write(s, tmp_path / "state.json")

    fake_psutil_process(name="python.exe")

    caplog.set_level("ERROR", logger="dbxignore.daemon")

    # Run daemon in a background thread so that — if the state-check
    # were missing and the daemon proceeded past it into the main sweep
    # loop — the test could assert the absence of the early-refusal exit
    # and clean up via stop_event rather than hanging until pytest-
    # timeout fires. With the state-check in place, the thread exits in
    # milliseconds.
    stop_event = threading.Event()
    t = threading.Thread(target=daemon.run, args=(stop_event,), daemon=True)
    t.start()
    t.join(timeout=2.0)
    daemon_returned_early = not t.is_alive()
    if not daemon_returned_early:
        stop_event.set()
        t.join(timeout=5.0)

    assert daemon_returned_early, (
        "daemon should have refused on alive-daemon-in-state scenario but "
        "instead proceeded to the main loop — defense-in-depth state-check "
        "missing"
    )
    assert any("already running" in rec.message.lower() for rec in caplog.records), (
        f"expected refusal log, got: {[r.message for r in caplog.records]}"
    )

    # Lock must have been released so a future invocation (after the
    # alien daemon dies) can acquire. If we leaked the handle, this
    # acquisition would fail.
    fh = daemon._acquire_singleton_lock()
    assert fh is not None, "lock must be released after refusal"
    fh.close()


@pytest.mark.timeout(30)
def test_singleton_lock_not_released_while_worker_alive(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """Singleton lock must not be released until the initial-sweep worker has
    actually exited — even when the graceful-exit join times out first.

    Guards the path where:
    1. Inner finally's bounded join times out (worker still alive).
    2. Closing singleton_lock immediately after would let a second
       daemon acquire the lock and run concurrently.
    3. The outer finally joins the worker first (no timeout) so the
       lock is released only once the worker is gone.

    Mechanics: monkeypatch ``_INITIAL_SWEEP_JOIN_TIMEOUT_S`` to near-zero
    so the inner join fires quickly; use ``BlockingMarkers`` to keep the
    worker alive; set stop_event; poll for the "did not exit" warning that
    marks the inner join having timed out; then verify the lock is still
    held before opening the gate.
    """
    root = tmp_path / "root"
    root.mkdir()
    (root / ".dropboxignore").write_text("")

    state_dir = setup_daemon_state(monkeypatch, tmp_path, root)
    monkeypatch.setattr(daemon, "_configured_logging", contextlib.nullcontext)
    # Collapse the graceful-exit window so the warning fires in milliseconds.
    monkeypatch.setattr(daemon, "_INITIAL_SWEEP_JOIN_TIMEOUT_S", 0.01)

    # Stub Observer so this test is independent of FSEvents/inotify semantics.
    # On macOS, FSEvents can emit synthetic "created" events for the existing
    # .dropboxignore at observer-start time. Those events queue in the
    # debouncer, fire `_dispatch` → `reconcile_subtree` → `markers.is_ignored`
    # which blocks on the gate. Then `debouncer.stop()` (no timeout) hangs
    # waiting for that in-flight emit to finish, and the test's "did not exit"
    # WARNING never fires. The contract under test is the daemon's lock
    # release ordering, not watchdog event delivery — stubbing Observer
    # isolates the architectural assertion from platform watcher quirks.
    class _NoOpObserver:
        def schedule(self, *args: object, **kwargs: object) -> None: ...
        def start(self) -> None: ...
        def stop(self) -> None: ...
        def join(self) -> None: ...

    monkeypatch.setattr(daemon, "Observer", _NoOpObserver)

    gate = threading.Event()
    blocking = BlockingMarkers(gate)
    monkeypatch.setattr(reconcile, "markers", blocking)
    monkeypatch.setattr(cli, "markers", blocking)

    caplog.set_level("WARNING", logger="dbxignore.daemon")
    stop = threading.Event()
    t = threading.Thread(target=daemon.run, args=(stop,), daemon=True)
    t.start()

    # Wait for the daemon to reach state=starting (early state.json written).
    assert _poll_until(
        lambda: (state_dir / "state.json").exists(),
        timeout_s=5.0,
    ), "daemon never wrote early state.json"

    # Signal shutdown while the worker is still blocked on the gate.
    stop.set()

    # The inner join(0.01s) should time out quickly; wait for the warning.
    # Generous timeout because observer.stop() + observer.join() on the
    # path between stop.set() and the warning can be slower on macOS
    # FSEvents than on Linux inotify or Windows ReadDirectoryChangesW —
    # observed at >5s on a macos-latest CI runner. 15s leaves headroom
    # without masking a real "monkeypatch didn't fire" bug.
    assert _poll_until(
        lambda: any("did not exit" in r.message for r in caplog.records),
        timeout_s=15.0,
    ), "inner join never timed out — monkeypatch may not have taken effect"

    # The outer finally is now blocking on worker.join() — lock must still
    # be held; a second acquire must fail.
    second = daemon._acquire_singleton_lock()
    assert second is None, (
        "singleton lock was released while the initial-sweep worker was still "
        "alive — outer finally must join the worker before closing the lock"
    )

    # Open the gate so the worker can exit, unblocking the outer join.
    gate.set()
    t.join(timeout=10.0)
    assert not t.is_alive(), "daemon thread should have exited after gate opened"

    # Lock must now be acquirable.
    third = daemon._acquire_singleton_lock()
    assert third is not None, "singleton lock must be released after worker exits"
    third.close()
