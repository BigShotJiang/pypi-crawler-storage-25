"""Read/write the Dropbox 'ignore' NTFS alternate data stream.

Dropbox treats a file or directory as ignored if it has an NTFS alternate
data stream named ``com.dropbox.ignored`` containing any non-empty value.
This module exposes three operations via Python's built-in ``open()``,
which on Windows passes the ``path:streamname`` syntax through to
``CreateFileW`` at the kernel level — so no subprocess or pywin32 needed.
"""

from __future__ import annotations

import logging
import os
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pathlib import Path

logger = logging.getLogger(__name__)

STREAM_NAME = "com.dropbox.ignored"
_MARKER_VALUE = "1"
_LONG_PATH_PREFIX = "\\\\?\\"
_UNC_LONG_PATH_PREFIX = "\\\\?\\UNC\\"


def _stream_path(path: Path) -> str:
    """Return the ``\\\\?\\…:streamname`` path for ``path``.

    ``path`` must be absolute — the ``\\\\?\\`` long-path prefix is only
    meaningful before a full path. Callers normalize at the CLI/daemon
    boundary; relative paths here are a caller bug.

    UNC paths (``\\\\server\\share\\…``) use the ``\\\\?\\UNC\\`` form
    rather than ``\\\\?\\`` directly; the latter concatenates to
    ``\\\\?\\\\\\server\\…`` which the Win32 object manager does not
    interpret as a valid long path.
    """
    if not path.is_absolute():
        raise ValueError(f"markers requires an absolute path; got {path!r}")
    raw = str(path)
    if raw.startswith("\\\\"):
        return f"{_UNC_LONG_PATH_PREFIX}{raw[2:]}:{STREAM_NAME}"
    return f"{_LONG_PATH_PREFIX}{raw}:{STREAM_NAME}"


def is_ignored(path: Path) -> bool:
    """Return True if ``path`` bears a non-empty com.dropbox.ignored stream."""
    try:
        with open(_stream_path(path), encoding="ascii") as f:
            return bool(f.read(1))
    except FileNotFoundError:
        return False


def set_ignored(path: Path) -> None:
    """Mark ``path`` as ignored by Dropbox.

    Raises ``FileNotFoundError`` if ``path`` vanished before the write;
    raises ``PermissionError`` if the stream cannot be written. Callers
    (notably ``reconcile._reconcile_path``) catch and log both per the
    design's failure-mode contract.
    """
    with open(_stream_path(path), "w", encoding="ascii") as f:
        f.write(_MARKER_VALUE)


def clear_ignored(path: Path) -> None:
    """Remove the Dropbox ignore marker from ``path`` (no-op if absent)."""
    try:
        os.remove(_stream_path(path))
    except FileNotFoundError:
        logger.debug("clear_ignored: stream absent or path gone: %s", path)
