# Response dataclasses for the Ironflow API.

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass
class Trade:
    source: str
    #: Full market identifier. Native HL perps use the base symbol (e.g. ``BTC-PERP``);
    #: HIP-3 builder-deployed markets are namespaced as ``<builder>:<base>`` (e.g. ``flx:GAS-PERP``).
    market: str
    #: HIP-3 builder/issuer namespace. Empty string for native HL markets.
    issuer: str
    #: Base market symbol with any issuer namespace stripped. Equal to ``market`` for native HL perps.
    base_market: str
    market_type: str
    timestamp: int
    block_number: int
    sequence: int
    price: str
    size: str
    side: str
    address: str
    fee: str
    realized_pnl: str
    hash: str
    # v3 identity fields (HIP-3 cutover, 2026-04-27).
    venue: str = ""
    market_class: str = ""
    market_id: int = 0
    quote_asset: str = ""
    display_symbol: str = ""
    # v3 fills-specific fields.
    notional: str = ""
    oid: int = 0
    tid: int = 0
    fee_token: str = ""
    liquidation: bool = False


@dataclass
class BookLevel:
    price: str
    size: str


@dataclass
class BookSnapshot:
    source: str
    market: str
    #: HIP-3 builder/issuer namespace. Empty string for native HL markets.
    issuer: str
    #: Base market symbol with any issuer namespace stripped.
    base_market: str
    timestamp: int
    bids: list[BookLevel]
    asks: list[BookLevel]
    # v3 identity fields.
    venue: str = ""
    market_class: str = ""
    market_id: int = 0
    quote_asset: str = ""
    display_symbol: str = ""


@dataclass
class Candle:
    source: str
    market: str
    #: Echoes the ``issuer`` filter used in the request. Empty if not filtered.
    issuer: str
    #: Echoes the ``base_market`` filter used in the request. Empty if not filtered.
    base_market: str
    interval: str
    timestamp: int
    open: str
    high: str
    low: str
    close: str
    volume: str
    trade_count: int


@dataclass
class FundingRate:
    source: str
    market: str
    #: HIP-3 builder/issuer namespace. Empty string for native HL markets.
    issuer: str
    #: Base market symbol with any issuer namespace stripped.
    base_market: str
    timestamp: int
    rate: str
    sequence: int
    # v3 identity fields. funding_rates_v3 is perp-only — no market_class.
    venue: str = ""
    market_id: int = 0
    quote_asset: str = ""
    display_symbol: str = ""


@dataclass
class Liquidation:
    source: str
    market: str
    #: HIP-3 builder/issuer namespace. Empty string for native HL markets.
    issuer: str
    #: Base market symbol with any issuer namespace stripped.
    base_market: str
    market_type: str
    timestamp: int
    block_number: int
    address: str
    side: str
    price: str
    size: str
    account_value: str
    leverage_type: str
    bankrupt: bool
    sequence: int
    liquidator: str = ""
    realized_pnl: str = ""
    margin_requirement: str = ""
    hash: str = ""
    detection_method: str = ""
    # v3 identity fields. liquidations_v3 is perp-only — no market_class.
    venue: str = ""
    market_id: int = 0
    quote_asset: str = ""
    display_symbol: str = ""


@dataclass
class OpenInterest:
    source: str
    market: str
    #: HIP-3 builder/issuer namespace. Empty string for native HL markets.
    issuer: str
    #: Base market symbol with any issuer namespace stripped.
    base_market: str
    timestamp: int
    open_interest: str
    #: Always ``"0"`` post-HIP-3 cutover. ``open_interest_v3`` dropped this column;
    #: the field is kept for backwards-compat but never populated.
    volume_24h: str
    # v3 identity fields. open_interest_v3 is perp-only — no market_class.
    venue: str = ""
    market_id: int = 0
    quote_asset: str = ""
    display_symbol: str = ""


@dataclass
class MarkPrice:
    source: str
    market: str
    #: HIP-3 builder/issuer namespace. Empty string for native HL markets.
    issuer: str
    #: Base market symbol with any issuer namespace stripped.
    base_market: str
    timestamp: int
    mark_price: str
    #: Always ``"0"`` post-HIP-3 cutover. ``mark_prices_v3`` carries only ``price``.
    oracle_price: str
    #: Always ``"0"`` post-HIP-3 cutover. ``mark_prices_v3`` carries only ``price``.
    funding_rate: str
    # v3 identity fields. mark_prices_v3 is perp-only — no market_class.
    venue: str = ""
    market_id: int = 0
    quote_asset: str = ""
    display_symbol: str = ""


@dataclass
class Deposit:
    source: str
    #: HIP-3 builder/issuer namespace. Empty string for native HL (non-market-scoped event).
    issuer: str
    #: Base market symbol for market-scoped deposits. Empty for global deposits.
    base_market: str
    market_type: str
    timestamp: int
    block_number: int
    address: str
    token: str
    amount: str
    fee: str
    sequence: int
    origin: str = ""
    tx_hash: str = ""


@dataclass
class Withdrawal:
    source: str
    #: HIP-3 builder/issuer namespace. Empty string for native HL (non-market-scoped event).
    issuer: str
    #: Base market symbol for market-scoped withdrawals. Empty for global withdrawals.
    base_market: str
    market_type: str
    timestamp: int
    block_number: int
    address: str
    token: str
    amount: str
    fee: str
    net_amount: str
    sequence: int
    destination: str = ""
    tx_hash: str = ""
    nonce: int = 0


@dataclass
class OrderStatus:
    source: str
    market: str
    #: HIP-3 builder/issuer namespace. Empty string for native HL markets.
    issuer: str
    #: Base market symbol with any issuer namespace stripped.
    base_market: str
    market_type: str
    timestamp: int
    block_number: int
    address: str
    order_id: str
    status: str
    side: str
    price: str
    size: str
    is_trigger: bool
    reduce_only: bool
    sequence: int
    client_order_id: str = ""
    original_size: str = ""
    order_type: str = ""
    time_in_force: str = ""
    trigger_price: str = ""
    trigger_condition: str = ""
    # v3 identity fields (HIP-3 cutover).
    venue: str = ""
    market_class: str = ""
    market_id: int = 0
    quote_asset: str = ""
    display_symbol: str = ""


# ─── Vault Operations ─────────────────────────────────────────────────


@dataclass
class VaultOperation:
    source: str
    #: HIP-3 builder/issuer namespace. Empty string for native HL (non-market-scoped event).
    issuer: str
    #: Base market symbol for market-scoped vault ops. Empty for global vault ops.
    base_market: str
    market_type: str
    timestamp: int
    block_number: int
    address: str
    vault: str
    operation: str
    token: str
    requested_amount: str
    net_amount: str
    commission: str
    closing_cost: str
    basis: str
    sequence: int
    tx_hash: str = ""


# ─── Triggers ─────────────────────────────────────────────────────────


@dataclass
class Trigger:
    id: int
    user_id: int
    name: str
    channel: str
    rule: dict[str, Any]
    webhook_url: str
    is_active: bool
    created_at: str = ""


# ─── Cohorts ──────────────────────────────────────────────────────────


@dataclass
class CohortInfo:
    name: str
    description: str = ""


@dataclass
class CohortAddressEntry:
    address: str
    value: str | None = None


@dataclass
class CohortAddresses:
    addresses: list[CohortAddressEntry]
    fetched_at: int


# ─── Analytics ────────────────────────────────────────────────────────


@dataclass
class NetFlow:
    source: str
    address: str
    bucket: int
    deposits: str
    withdrawals: str
    net_flow: str


@dataclass
class LiquidationLevel:
    source: str
    market: str
    price_bucket: str
    side: str
    count: int
    total_size: str


@dataclass
class OrderFlow:
    source: str
    market: str
    total_orders: int
    filled_orders: int
    cancelled: int
    fill_rate: str


@dataclass
class VaultLeaderboardEntry:
    source: str
    vault: str
    total_deposits: str
    total_withdrawals: str
    net_flow: str
    unique_users: int


@dataclass
class FundingStats:
    source: str
    market: str
    bucket: int
    avg_rate: str
    min_rate: str
    max_rate: str
    cumulative_rate: str


@dataclass
class DataFreshness:
    latest_timestamp: str
    age_seconds: float
    total_rows: int


@dataclass
class VenueStatus:
    status: str
    markets: int
    streams: dict[str, DataFreshness]
    events: dict[str, DataFreshness]


@dataclass
class PlatformStats:
    total_events: int
    total_markets: int
    event_types_active: int
    oldest_data_days: int


@dataclass
class StatusResponse:
    status: str
    timestamp: int
    uptime: str
    venues: dict[str, VenueStatus]
    platform: PlatformStats | None = None


# ─── Account ──────────────────────────────────────────────────────────


@dataclass
class MeLimits:
    requests_per_min: int
    info_requests_per_min: int
    history_window_ms: int
    websocket_connections: int
    address_tracking: int
    full_analytics: bool


@dataclass
class MeResponse:
    tier: str
    active: bool
    limits: MeLimits


@dataclass
class HealthResponse:
    status: str


# ─── Markets registry ─────────────────────────────────────────────────


@dataclass
class Market:
    market_id: int
    source: str
    market_class: str  # "perp" | "spot" | "prediction" | "option"
    issuer: str
    base_asset: str
    quote_asset: str
    base_market: str
    display_symbol: str
    active_from_ms: int
    hl_coin: str | None = None


# ─── System metrics & history ─────────────────────────────────────────


@dataclass
class APIMetrics:
    latency_p50_ms: float
    latency_p99_ms: float
    error_rate: float
    websocket_clients: int


@dataclass
class PipelineMetrics:
    streaming_latency_ms: float
    events_per_sec: float


@dataclass
class SyntheticMetrics:
    ws_latency_ms: float
    ws_latency_p50_ms: float
    query_latencies: dict[str, float]


@dataclass
class StatusMetricsResponse:
    timestamp: int
    api: APIMetrics
    pipeline: PipelineMetrics
    synthetic: SyntheticMetrics


@dataclass
class UptimePoint:
    ts: int
    status: str  # "operational" | "degraded" | "down"
    fresh_sec: float


@dataclass
class StatusHistoryResponse:
    period: str
    uptime_percent: float
    points: list[UptimePoint]


# ─── Per-address wallet analytics (v0.31.0+) ──────────────────────────
#
# Designed to mirror Hyperliquid's `/info` user-scoped surface
# (clearinghouseState, userFunding, userNonFundingLedgerUpdates) so
# consumers porting from HL's API can re-use most of their parsing
# code.


@dataclass
class AssetPosition:
    """One open market position. `size` is signed (positive = long)."""

    market: str
    market_class: str  # "perp" | "spot" | "prediction" | "option"
    size: float
    entry_price: float
    mark_price: float
    position_value: float
    unrealized_pnl: float
    realized_pnl: float
    return_on_equity: float = 0.0


@dataclass
class UserMarginSummary:
    total_position_value: float
    total_unrealized_pnl: float
    total_realized_pnl: float
    open_markets_count: int


@dataclass
class UserState:
    """Snapshot of an address's current open positions + uPnL.

    Mirrors HL's `clearinghouseState` /info request. `as_of_ts` carries
    the wall-clock (unix ms) of the latest mark_price used; detect
    staleness if the poller is lagging.
    """

    address: str
    as_of_ts: int
    asset_positions: list[AssetPosition]
    margin_summary: UserMarginSummary


@dataclass
class UserFundingPayment:
    """One bucket of funding payments. Signed: + received, - paid."""

    bucket_start: int
    market: str
    market_class: str
    funding_payment: float
    avg_position: float
    avg_funding_rate: float
    interval_count: int


@dataclass
class UserMakerTakerBreakdown:
    market: str
    market_class: str
    maker_fills: int
    taker_fills: int
    maker_notional: float
    taker_notional: float
    maker_fee: float  # often negative on maker side = rebate
    taker_fee: float
    total_fills: int
    pct_maker: float  # [0, 1]


@dataclass
class UserMakerTakerResponse:
    address: str
    data: list[UserMakerTakerBreakdown]
    total: UserMakerTakerBreakdown
    from_ts: int  # `from` is a Python keyword, renamed
    to_ts: int


@dataclass
class UserLedgerEntry:
    """Non-fill ledger event. `amount` is signed: + into account, - out.

    Phase b will extend the `type` field with rewardsClaim,
    spotTransfer, delegate, undelegate sourced from the misc_events
    LedgerUpdate parser.
    """

    ts: int
    type: str
    token: str
    amount: float
    tx_hash: str = ""
    details: dict | None = None


# ─── Cross-wallet ranking (v0.34+) ──────────────────────────────────


@dataclass
class PnLLeaderboardRow:
    """One ranked wallet on the global Smart Money leaderboard."""

    address: str
    realized_pnl: float
    volume_usd: float
    fills: int
    wins: int  # fills where realized_pnl > 0
    losses: int  # fills where realized_pnl < 0
    win_rate: float  # wins / (wins + losses)
    maker_fills: int
    taker_fills: int
    pct_maker: float  # maker_fills / fills
    markets_count: int  # distinct markets traded in window


@dataclass
class MarketTopWalletRow:
    """One ranked wallet for a single market."""

    address: str
    volume_usd: float
    fills: int
    realized_pnl: float
    pct_maker: float


@dataclass
class MarketSnapshotRow:
    """Anchored market state — single-call replacement for N×3 fan-out."""

    market_id: int
    display_symbol: str
    market_class: str
    mark_price: float
    issuer: str = ""
    mark_24h_ago: float | None = None
    change_24h_pct: float | None = None  # decimal (0.0123 = +1.23%)
    open_interest_base: float | None = None
    open_interest_usd: float | None = None
    funding_rate: float | None = None
    mark_ts_ms: int | None = None
    # Notional traded over the last 24h, USD. Buy-side fills only —
    # HL emits two fills per trade and filtering to side='buy' avoids
    # double-counting.
    volume_24h_usd: float | None = None


@dataclass
class UserSummary:
    """Aggregate stats for one address over a window — single CH agg."""

    address: str
    from_ts: int  # `from` is a Python keyword, renamed
    to_ts: int
    fills: int
    volume_usd: float
    realized_pnl: float
    wins: int = 0
    losses: int = 0
    win_rate: float = 0.0
    maker_fills: int = 0
    taker_fills: int = 0
    pct_maker: float = 0.0
    markets_count: int = 0
    first_fill_ts: int | None = None
    last_fill_ts: int | None = None


@dataclass
class UserPnLSeriesPoint:
    """One time-bucket of realized PnL for a wallet."""

    bucket_start: int
    realized_pnl: float


# ─── Wallet labels (v0.36+) ─────────────────────────────────────────


@dataclass
class WalletLabel:
    """One precomputed label attached to an address.

    `kind` is one of "whale", "smart_money", "vault", "vault_leader".
    `rank` is 1-based within the category (0 for unranked kinds).
    `priority` resolves overlaps when one address has multiple labels —
    higher wins.
    """

    kind: str
    name: str
    priority: int
    rank: int = 0
    value: float = 0.0


@dataclass
class WalletLabelCounts:
    whales: int
    smart_money: int
    vaults: int
    vault_leaders: int


@dataclass
class WalletLabelsResponse:
    """Precomputed wallet labels — fetch once, look up locally.

    `labels` maps lowercase-hex address → list of labels. Edge-cached
    server-side; refresh every few minutes is sufficient.
    """

    generated_at: int
    ttl_seconds: int
    source: str
    labels: dict[str, list[WalletLabel]]
    counts: WalletLabelCounts
