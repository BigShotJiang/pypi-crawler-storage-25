#!/bin/bash
# ============================================================
# brr global setup — built-in, updates automatically with brr upgrades
# ============================================================

set -Eeuo pipefail

export DEBIAN_FRONTEND=noninteractive
export NEEDRESTART_MODE=a

# Suppress needrestart interactive prompts (runs as dpkg hook under sudo,
# so exported env vars don't reach it)
if [ -d /etc/needrestart/conf.d ]; then
  echo "\$nrconf{restart} = 'a';" | sudo tee /etc/needrestart/conf.d/no-prompt.conf >/dev/null
fi

# Retry failed apt downloads up to 3 times (avoids transient mirror timeouts)
echo 'Acquire::Retries "3";' | sudo tee /etc/apt/apt.conf.d/80-retries >/dev/null

# Source config if available (copied to remote via file_mounts)
if [ -f "/opt/brr/staging/config.env" ]; then
  source "/opt/brr/staging/config.env"
fi

# Defaults (used if config.env not present)
CLUSTER_USER="${CLUSTER_USER:-$USER}"
DOTFILES_REPO="${DOTFILES_REPO:-}"

info() {
  echo "[setup] $*"
}

append_line_once() {
  # Usage: append_line_once "line" "/path/to/file"
  local line="$1"
  local file="$2"
  if [ ! -f "$file" ] || ! grep -Fqx "$line" "$file"; then
    echo "$line" >> "$file"
  fi
}

ensure_aws_cli() {
  if ! command -v aws >/dev/null 2>&1; then
    info "Installing AWS CLI v2"
    local tmpdir
    tmpdir="$(mktemp -d)"
    curl -sSL "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "$tmpdir/awscliv2.zip"
    unzip -q "$tmpdir/awscliv2.zip" -d "$tmpdir"
    sudo "$tmpdir/aws/install" --update
    rm -rf "$tmpdir"
  fi
}

# --- Base packages ---
if ! dpkg -s nfs-common curl unzip bzip2 make perl >/dev/null 2>&1; then
  info "Installing base packages"
  sudo apt-get update -y
  sudo apt-get install -y nfs-common curl unzip bzip2 make perl
else
  info "Base packages already installed"
fi

# --- GNU Stow (for dotfiles) ---
# Install stow 2.4+ from source (Ubuntu's apt ships 2.3.1 which has a bug
# with --dotfiles on directories)
if ! stow --version 2>&1 | grep -qE '2\.[4-9]|[3-9]\.'; then
  info "Installing GNU Stow 2.4.0 from source"
  _stow_tmp="$(mktemp -d)"
  curl -sSL "https://ftp.gnu.org/gnu/stow/stow-2.4.0.tar.gz" | tar xz -C "$_stow_tmp"
  (cd "$_stow_tmp/stow-2.4.0" && ./configure --quiet && make -s && sudo make -s install)
  rm -rf "$_stow_tmp"
else
  info "stow already at $(stow --version 2>&1 | head -1)"
fi

# --- Filesystem mounts (EFS / virtiofs) ---
if [ "${PROVIDER:-aws}" = "aws" ] && [ -n "${EFS_ID:-}" ]; then
  REGION="${AWS_REGION:-$(curl -s http://169.254.169.254/latest/meta-data/placement/region)}"
  EFS_DNS="${EFS_ID}.efs.${REGION}.amazonaws.com"
  MOUNT_POINT="/shared"

  if mountpoint -q "$MOUNT_POINT" 2>/dev/null; then
    info "EFS already mounted at $MOUNT_POINT"
  else
    info "Mounting EFS $EFS_ID at $MOUNT_POINT"
    sudo mkdir -p "$MOUNT_POINT"

    # Retry mount (mount target DNS may take a moment to propagate)
    for i in 1 2 3 4 5; do
      if sudo mount -t nfs4 -o nfsvers=4.1,rsize=1048576,wsize=1048576,soft,timeo=600,retrans=2,noresvport \
        "$EFS_DNS:/" "$MOUNT_POINT" 2>/dev/null; then
        break
      fi
      info "Mount attempt $i failed, retrying in 5s..."
      sleep 5
    done

    if mountpoint -q "$MOUNT_POINT"; then
      sudo chown ubuntu:ubuntu "$MOUNT_POINT"
      info "EFS mounted at $MOUNT_POINT"
    else
      info "WARNING: Failed to mount EFS after 5 attempts"
    fi
  fi

  # Add to fstab for persistence across reboots
  if ! grep -q "$EFS_ID" /etc/fstab 2>/dev/null; then
    echo "$EFS_DNS:/ $MOUNT_POINT nfs4 nfsvers=4.1,rsize=1048576,wsize=1048576,soft,timeo=600,retrans=2,noresvport,_netdev 0 0" \
      | sudo tee -a /etc/fstab >/dev/null
  fi

  # Save ray_bootstrap_config.yaml before bind-mount shadows it
  # (Ray writes this during file_mounts, before our setup_commands run)
  if [ -f "$HOME/ray_bootstrap_config.yaml" ] && [ ! -L "$HOME/ray_bootstrap_config.yaml" ]; then
    cp "$HOME/ray_bootstrap_config.yaml" /tmp/ray_bootstrap_config.yaml
  fi

  # Persistent home directory on EFS
  if ! mountpoint -q "$HOME" 2>/dev/null; then
    if [ ! -d "$MOUNT_POINT/home/ubuntu" ]; then
      info "First boot: seeding persistent home on $MOUNT_POINT"
      mkdir -p "$MOUNT_POINT/home/ubuntu"
      rsync -a "$HOME/" "$MOUNT_POINT/home/ubuntu/"
    fi
    sudo mount --bind "$MOUNT_POINT/home/ubuntu" "$HOME"
    info "Home bind-mounted from $MOUNT_POINT"
  fi

  # Redirect ray_bootstrap_config.yaml to instance-local /tmp so clusters
  # sharing $HOME don't overwrite each other's autoscaling config.
  if [ ! -L "$HOME/ray_bootstrap_config.yaml" ]; then
    rm -f "$HOME/ray_bootstrap_config.yaml"
    ln -s /tmp/ray_bootstrap_config.yaml "$HOME/ray_bootstrap_config.yaml"
  fi

  # Persistent code directory
  mkdir -p "$HOME/code"
fi

# --- Shared filesystem mount (Nebius virtiofs) ---
if [ "${PROVIDER:-}" = "nebius" ] && [ -n "${NEBIUS_FILESYSTEM_ID:-}" ]; then
  MOUNT_POINT="/shared"

  if mountpoint -q "$MOUNT_POINT" 2>/dev/null; then
    info "Filesystem already mounted at $MOUNT_POINT"
  else
    info "Mounting shared filesystem at $MOUNT_POINT"
    sudo mkdir -p "$MOUNT_POINT"
    sudo mount -t virtiofs brr-shared "$MOUNT_POINT"
    sudo chown ubuntu:ubuntu "$MOUNT_POINT"
    info "Filesystem mounted at $MOUNT_POINT"
  fi

  # Add to fstab for persistence across reboots
  if ! grep -q 'brr-shared' /etc/fstab 2>/dev/null; then
    echo "brr-shared $MOUNT_POINT virtiofs defaults 0 0" | sudo tee -a /etc/fstab >/dev/null
  fi

  # Save ray_bootstrap_config.yaml before bind-mount shadows it
  if [ -f "$HOME/ray_bootstrap_config.yaml" ] && [ ! -L "$HOME/ray_bootstrap_config.yaml" ]; then
    cp "$HOME/ray_bootstrap_config.yaml" /tmp/ray_bootstrap_config.yaml
  fi

  # Persistent home directory on shared filesystem
  if ! mountpoint -q "$HOME" 2>/dev/null; then
    if [ ! -d "$MOUNT_POINT/home/ubuntu" ]; then
      info "First boot: seeding persistent home on $MOUNT_POINT"
      mkdir -p "$MOUNT_POINT/home/ubuntu"
      rsync -a "$HOME/" "$MOUNT_POINT/home/ubuntu/"
    fi
    sudo mount --bind "$MOUNT_POINT/home/ubuntu" "$HOME"
    info "Home bind-mounted from $MOUNT_POINT"
  fi

  # Redirect ray_bootstrap_config.yaml to instance-local /tmp so clusters
  # sharing $HOME don't overwrite each other's autoscaling config.
  if [ ! -L "$HOME/ray_bootstrap_config.yaml" ]; then
    rm -f "$HOME/ray_bootstrap_config.yaml"
    ln -s /tmp/ray_bootstrap_config.yaml "$HOME/ray_bootstrap_config.yaml"
  fi

  # Persistent code directory
  mkdir -p "$HOME/code"
fi

# --- Shared filesystem mount (Verda) ---
# VERDA_SHARED_MOUNT_TARGET takes one of three forms:
#   host:/path     → NFS mount
#   LABEL=... / UUID=... / /dev/...  → block device
#   (empty)        → discover at runtime via lsblk for the most recently
#                    attached block device (shared NVMe volumes appear as
#                    /dev/vdX on Verda instances).
if [ "${PROVIDER:-}" = "verda" ] && [ -n "${VERDA_SHARED_VOLUME_ID:-}" ]; then
  MOUNT_POINT="/shared"

  if mountpoint -q "$MOUNT_POINT" 2>/dev/null; then
    info "Verda shared filesystem already mounted at $MOUNT_POINT"
  else
    info "Mounting Verda shared filesystem at $MOUNT_POINT"
    sudo mkdir -p "$MOUNT_POINT"

    _verda_mounted=0
    _target="${VERDA_SHARED_MOUNT_TARGET:-}"

    case "$_target" in
      *":/"*)
        for i in 1 2 3 4 5; do
          if sudo mount -t nfs4 -o nfsvers=4.1,rsize=1048576,wsize=1048576,soft,timeo=600,retrans=2,noresvport \
            "$_target" "$MOUNT_POINT" 2>/dev/null; then
            _verda_mounted=1
            break
          fi
          info "NFS mount attempt $i failed, retrying in 5s..."
          sleep 5
        done
        ;;
      LABEL=*|UUID=*|/dev/*)
        if sudo mount "$_target" "$MOUNT_POINT" 2>/dev/null; then
          _verda_mounted=1
        fi
        ;;
      "")
        # Autodiscover: first unmounted non-OS disk with no partitions.
        # VERDA mounts the OS volume at /, so the shared volume is the
        # next attached block device to surface (typically /dev/vdb or
        # /dev/nvme1n1).
        for dev in $(lsblk -dno NAME,TYPE 2>/dev/null | awk '$2=="disk"{print "/dev/"$1}'); do
          if [ "$dev" = "/dev/$(lsblk -no PKNAME $(findmnt -n -o SOURCE /) 2>/dev/null)" ]; then
            continue
          fi
          if findmnt --source "$dev" >/dev/null 2>&1; then
            continue
          fi
          if sudo mount "$dev" "$MOUNT_POINT" 2>/dev/null; then
            _target="$dev"
            _verda_mounted=1
            break
          fi
        done
        ;;
    esac

    if [ "$_verda_mounted" = "1" ]; then
      sudo chown "$USER:$USER" "$MOUNT_POINT"
      info "Verda shared filesystem mounted at $MOUNT_POINT (source: $_target)"
    else
      info "WARNING: Failed to mount Verda shared filesystem"
    fi
  fi

  # Add to fstab for persistence across reboots (only if we have a concrete target)
  if [ -n "${VERDA_SHARED_MOUNT_TARGET:-}" ] && ! grep -q "$MOUNT_POINT" /etc/fstab 2>/dev/null; then
    case "$VERDA_SHARED_MOUNT_TARGET" in
      *":/"*)
        echo "$VERDA_SHARED_MOUNT_TARGET $MOUNT_POINT nfs4 nfsvers=4.1,rsize=1048576,wsize=1048576,soft,timeo=600,retrans=2,noresvport,_netdev 0 0" \
          | sudo tee -a /etc/fstab >/dev/null
        ;;
      LABEL=*|UUID=*|/dev/*)
        echo "$VERDA_SHARED_MOUNT_TARGET $MOUNT_POINT auto defaults,nofail 0 2" \
          | sudo tee -a /etc/fstab >/dev/null
        ;;
    esac
  fi

  # Save ray_bootstrap_config.yaml before bind-mount shadows it
  if [ -f "$HOME/ray_bootstrap_config.yaml" ] && [ ! -L "$HOME/ray_bootstrap_config.yaml" ]; then
    cp "$HOME/ray_bootstrap_config.yaml" /tmp/ray_bootstrap_config.yaml
  fi

  # Persistent home directory on shared filesystem. Bind to "$MOUNT_POINT/home/$USER"
  # so Verda (SSH user = root, $HOME = /root) and Ubuntu-based providers (ubuntu,
  # /home/ubuntu) both get isolated persistent homes keyed by their SSH user.
  _home_dir="$MOUNT_POINT/home/$USER"
  if mountpoint -q "$MOUNT_POINT" 2>/dev/null && ! mountpoint -q "$HOME" 2>/dev/null; then
    if [ ! -d "$_home_dir" ]; then
      info "First boot: seeding persistent home on $MOUNT_POINT"
      sudo mkdir -p "$_home_dir"
      sudo chown "$USER:$USER" "$_home_dir"
      rsync -a "$HOME/" "$_home_dir/"
    fi
    sudo mount --bind "$_home_dir" "$HOME"
    info "Home bind-mounted from $_home_dir"
  fi

  # Redirect ray_bootstrap_config.yaml to instance-local /tmp
  if [ ! -L "$HOME/ray_bootstrap_config.yaml" ]; then
    rm -f "$HOME/ray_bootstrap_config.yaml"
    ln -s /tmp/ray_bootstrap_config.yaml "$HOME/ray_bootstrap_config.yaml"
  fi

  # Persistent code directory
  mkdir -p "$HOME/code"
fi

# --- Ensure-mount helper (handles cached node restarts) ---
# When Ray restarts a cached stopped node, it skips setup_commands and runs
# worker_start_ray_commands directly. The NFS/virtiofs mount comes back via
# fstab, but the home bind-mount does not. This helper waits for the fstab
# mount and re-establishes the bind-mount so $HOME/code/ is available.
sudo tee /usr/local/bin/brr-ensure-mount >/dev/null <<'ENSURE_MOUNT'
#!/bin/bash
MOUNT_POINT="/shared"

# Exit early if no shared filesystem in fstab
grep -q "$MOUNT_POINT" /etc/fstab 2>/dev/null || exit 0

# Ensure the fstab mount is up (virtiofs may not auto-mount on reboot)
for i in $(seq 1 60); do
  mountpoint -q "$MOUNT_POINT" 2>/dev/null && break
  sudo mount "$MOUNT_POINT" 2>/dev/null || true
  echo "[brr-ensure-mount] Waiting for $MOUNT_POINT ($i/60)..."
  sleep 5
done

if ! mountpoint -q "$MOUNT_POINT" 2>/dev/null; then
  echo "[brr-ensure-mount] ERROR: $MOUNT_POINT not mounted after 5 minutes"
  exit 1
fi

# Re-establish home bind-mount if needed. Use the current user's home
# directory name so this works for Verda (root) as well as ubuntu-based
# providers (ubuntu).
_home_dir="$MOUNT_POINT/home/$USER"
if [ -d "$_home_dir" ] && ! mountpoint -q "$HOME" 2>/dev/null; then
  sudo mount --bind "$_home_dir" "$HOME"
  echo "[brr-ensure-mount] Home bind-mounted from $_home_dir"
fi

# Redirect ray_bootstrap_config.yaml to instance-local /tmp
if [ ! -L "$HOME/ray_bootstrap_config.yaml" ]; then
  rm -f "$HOME/ray_bootstrap_config.yaml"
  ln -s /tmp/ray_bootstrap_config.yaml "$HOME/ray_bootstrap_config.yaml"
fi
ENSURE_MOUNT
sudo chmod +x /usr/local/bin/brr-ensure-mount

# --- AWS CLI ---
if [ "${PROVIDER:-aws}" = "aws" ]; then
  ensure_aws_cli
fi

# --- GitHub SSH access (copied via file_mounts) ---
if [ -f "/opt/brr/staging/github_key" ]; then
  info "Configuring GitHub SSH access"
  mkdir -p "$HOME/.ssh" && chmod 700 "$HOME/.ssh"
  cp "/opt/brr/staging/github_key" "$HOME/.ssh/github_key"
  chmod 600 "$HOME/.ssh/github_key"

  if ! grep -q 'Host github.com' "$HOME/.ssh/config" 2>/dev/null; then
    cat >> "$HOME/.ssh/config" <<'SSHCFG'
Host github.com
  IdentityFile ~/.ssh/github_key
  StrictHostKeyChecking accept-new
SSHCFG
    chmod 600 "$HOME/.ssh/config"
  fi
  info "GitHub SSH access configured"
fi

# --- AI coding tools (configured via `brr configure tools`) ---

_ensure_node() {
  if command -v node >/dev/null 2>&1; then
    return
  fi
  info "Installing Node.js (required for Codex/Gemini CLI)"
  curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
  sudo apt-get install -y nodejs
}

if [ "${INSTALL_CLAUDE_CODE:-}" = "true" ]; then
  if ! command -v claude >/dev/null 2>&1; then
    info "Installing Claude Code"
    curl -fsSL https://claude.ai/install.sh | bash
  else
    info "Claude Code already installed"
  fi
fi


if [ "${INSTALL_CODEX:-}" = "true" ]; then
  _ensure_node
  if ! command -v codex >/dev/null 2>&1; then
    info "Installing Codex"
    npm install -g @openai/codex
  else
    info "Codex already installed"
  fi
fi

if [ "${INSTALL_GEMINI:-}" = "true" ]; then
  _ensure_node
  if ! command -v gemini >/dev/null 2>&1; then
    info "Installing Gemini CLI"
    npm install -g @google/gemini-cli
  else
    info "Gemini CLI already installed"
  fi
fi

# --- Dotfiles ---
if [ -n "$DOTFILES_REPO" ]; then
  DOTFILES_DIR="$HOME/dotfiles"
  if [ -d "$DOTFILES_DIR/.git" ]; then
    info "Updating dotfiles repository"
    git -C "$DOTFILES_DIR" fetch --all --quiet || true
    git -C "$DOTFILES_DIR" pull --ff-only --quiet || true
  else
    info "Cloning dotfiles repository"
    git clone "$DOTFILES_REPO" "$DOTFILES_DIR"
  fi
  if [ -x "$DOTFILES_DIR/install.sh" ]; then
    info "Running dotfiles install script"
    # Run without inheriting set -Eeuo pipefail — dotfiles scripts often have
    # commands that return non-zero for idempotency (apt, git clone, etc.)
    (cd "$DOTFILES_DIR" && set +Eeu && ./install.sh) || info "dotfiles install.sh exited non-zero (continuing)"
  fi
else
  info "Skipping dotfiles (DOTFILES_REPO not set)"
fi

# --- Python environment (uv, venv, Ray) ---
UV_REAL="$HOME/.local/lib/uv"
if [ ! -x "$UV_REAL" ]; then
  info "Installing uv package manager"
  curl -LsSf https://astral.sh/uv/install.sh | UV_INSTALL_DIR="$HOME/.local/lib" UV_NO_MODIFY_PATH=1 sh
else
  info "uv already installed: ($("$UV_REAL" --version 2>/dev/null || true))"
fi

# Route uv cache to local disk (EFS doesn't support flock).
export UV_CACHE_DIR="/tmp/uv"
export UV_PYTHON_INSTALL_DIR="/opt/uv/python"

# Persistent directories for venv and Python installs (survive reboot for cached node restarts)
sudo mkdir -p /opt/brr /opt/uv /opt/venvs
sudo chown "$USER:$USER" /opt/brr /opt/uv /opt/venvs

# Pre-install Python versions
"$UV_REAL" python install --no-bin 3.10 3.11 3.12 3.13

# Create virtual environment at /opt/brr/venv (persistent across reboots)
VENVDIR="/opt/brr/venv"
_WANT_PY="${PYTHON_VERSION:-3.11}"
if [ ! -d "$VENVDIR" ]; then
  info "Creating Python ${_WANT_PY} virtual environment at $VENVDIR"
  "$UV_REAL" venv --python "$_WANT_PY" "$VENVDIR"
else
  info "Virtual environment already exists at $VENVDIR"
fi

# Install Ray in the virtual environment if missing
if ! "$VENVDIR/bin/python" -c "import ray" >/dev/null 2>&1; then
  info "Installing Ray into the virtual environment"
  ( . "$VENVDIR/bin/activate" && "$UV_REAL" pip install 'ray[default]' )
else
  info "Ray already installed in the virtual environment"
fi

# Install boto3 in the venv (required by Ray's built-in AWS provider)
if [ "${PROVIDER:-aws}" = "aws" ]; then
  if ! "$VENVDIR/bin/python" -c "import boto3" >/dev/null 2>&1; then
    info "Installing boto3 into the virtual environment"
    ( . "$VENVDIR/bin/activate" && "$UV_REAL" pip install 'boto3>=1.4.8' )
  else
    info "boto3 already installed in the virtual environment"
  fi
fi

# Install pip into the venv (uv venv doesn't include it) and symlink so
# Ray's auto-injected "pip install" commands use the venv pip, not the
# PEP 668-blocked system pip.
if [ ! -x "$VENVDIR/bin/pip" ]; then
  info "Installing pip into the virtual environment"
  ( . "$VENVDIR/bin/activate" && "$UV_REAL" pip install pip )
fi
sudo ln -sf "$VENVDIR/bin/pip" /usr/local/bin/pip
sudo ln -sf "$VENVDIR/bin/pip3" /usr/local/bin/pip3

# --- Nebius provider support ---
if [ "${PROVIDER:-}" = "nebius" ]; then
  # Install Nebius SDK so the node provider can create workers
  if ! "$VENVDIR/bin/python" -c "import nebius" >/dev/null 2>&1; then
    info "Installing Nebius SDK into the virtual environment"
    ( . "$VENVDIR/bin/activate" && "$UV_REAL" pip install nebius )
  else
    info "Nebius SDK already installed in the virtual environment"
  fi

  # Copy node provider to a persistent location (/tmp is cleared on reboot).
  if [ -d "/opt/brr/staging/provider_lib" ]; then
    sudo mkdir -p /opt/brr
    sudo cp -r /opt/brr/staging/provider_lib /opt/brr/provider_lib
    sudo chmod -R a+rX /opt/brr/provider_lib
    info "Installed node provider to /opt/brr/provider_lib"
  fi

  # Set PYTHONPATH in /etc/environment so it's available to all processes
  # (including non-interactive SSH commands like `ray start`).
  if ! grep -q 'PYTHONPATH.*/opt/brr/provider_lib' /etc/environment 2>/dev/null; then
    echo 'PYTHONPATH=/opt/brr/provider_lib' | sudo tee -a /etc/environment >/dev/null
  fi

  # Place credentials where the SDK expects them
  if [ -f "/opt/brr/staging/nebius_credentials.json" ]; then
    mkdir -p "$HOME/.nebius"
    cp "/opt/brr/staging/nebius_credentials.json" "$HOME/.nebius/credentials.json"
    info "Nebius credentials configured"
  fi

  # Configure AWS CLI for Object Storage access. ~/.aws lives on the shared
  # virtiofs (bind-mounted from /shared/home), and `aws configure set` does an
  # unlocked truncate-then-write — concurrent autoscaler workers racing on
  # this file corrupt it (and corruption is sticky: subsequent `aws configure
  # set` calls fail to parse the file, so every worker that boots after dies
  # in setup.sh and the autoscaler tears it down). Head always runs setup.sh
  # to completion before the autoscaler launches workers, so workers can just
  # inherit whatever the head wrote.
  if [ -n "${NEBIUS_S3_ACCESS_KEY_ID:-}" ] && [ -n "${NEBIUS_S3_SECRET_KEY:-}" ]; then
    ensure_aws_cli
    if [ -f "$HOME/.aws/credentials" ] && [ -f "$HOME/.aws/config" ]; then
      info "AWS CLI already configured (shared \$HOME)"
    else
      aws configure set aws_access_key_id "$NEBIUS_S3_ACCESS_KEY_ID"
      aws configure set aws_secret_access_key "$NEBIUS_S3_SECRET_KEY"
      aws configure set region "${NEBIUS_REGION:-eu-north1}"
      aws configure set endpoint_url "https://storage.${NEBIUS_REGION:-eu-north1}.nebius.cloud:443"
      info "AWS CLI configured for Nebius Object Storage"
    fi
  fi
fi

# --- Verda firewall (ufw lockdown) ---
# Verda has no cloud-level firewall, so every instance port is public by
# default. Lock down to SSH only — single-node clusters need nothing else
# externally, and the Ray dashboard / agent / GCS should never be on the
# open internet. Multi-node clusters need a worker allowlist mechanism
# that isn't wired up yet; those templates are currently single-node only.
if [ "${PROVIDER:-}" = "verda" ]; then
  if ! command -v ufw >/dev/null 2>&1; then
    info "Installing ufw"
    sudo -E apt-get -o DPkg::Lock::Timeout=300 install -y ufw
  fi
  if ! sudo ufw status 2>/dev/null | grep -q "Status: active"; then
    info "Enabling ufw (default deny incoming, allow SSH)"
    sudo ufw --force reset >/dev/null
    sudo ufw default deny incoming
    sudo ufw default allow outgoing
    sudo ufw allow in on lo
    sudo ufw allow 22/tcp
    sudo ufw --force enable
    info "ufw active — only SSH (22/tcp) and loopback are allowed inbound"
  else
    info "ufw already active"
    # Still ensure SSH is allowed (idempotent) so we don't lock ourselves out
    sudo ufw allow 22/tcp >/dev/null
  fi
fi

# --- Verda provider support ---
if [ "${PROVIDER:-}" = "verda" ]; then
  # Install Verda SDK so the node provider can create workers
  if ! "$VENVDIR/bin/python" -c "import verda" >/dev/null 2>&1; then
    info "Installing Verda SDK into the virtual environment"
    ( . "$VENVDIR/bin/activate" && "$UV_REAL" pip install verda )
  else
    info "Verda SDK already installed in the virtual environment"
  fi

  # Copy node provider to a persistent location (/tmp is cleared on reboot).
  if [ -d "/opt/brr/staging/provider_lib" ]; then
    sudo mkdir -p /opt/brr
    sudo cp -r /opt/brr/staging/provider_lib /opt/brr/provider_lib
    sudo chmod -R a+rX /opt/brr/provider_lib
    info "Installed node provider to /opt/brr/provider_lib"
  fi

  # Set PYTHONPATH in /etc/environment so it's available to all processes
  # (including non-interactive SSH commands like `ray start`).
  if ! grep -q 'PYTHONPATH.*/opt/brr/provider_lib' /etc/environment 2>/dev/null; then
    echo 'PYTHONPATH=/opt/brr/provider_lib' | sudo tee -a /etc/environment >/dev/null
  fi

  # Keep the autoscaler's tag file on local disk. /shared may be NFS-backed
  # and `fcntl.flock` on NFS can be unreliable; /tmp avoids that class of bug.
  if ! grep -q 'VERDA_TAG_STORE_PATH' /etc/environment 2>/dev/null; then
    echo 'VERDA_TAG_STORE_PATH=/tmp/verda-tags.json' | sudo tee -a /etc/environment >/dev/null
  fi

  # Place Verda credentials (OAuth client id/secret) where the SDK expects them
  if [ -f "/opt/brr/staging/verda_credentials" ]; then
    mkdir -p "$HOME/.verda"
    cp "/opt/brr/staging/verda_credentials" "$HOME/.verda/credentials"
    chmod 600 "$HOME/.verda/credentials"
    info "Verda credentials configured"
  fi
fi

# --- Shell environment ---
UV_DIR="$HOME/.local/bin"

# Migration: move real binary from old locations to ~/.local/lib/uv
if [ -x "$UV_DIR/.uv-real" ]; then
  mv "$UV_DIR/.uv-real" "$UV_REAL"
fi
# If old wrapper left a script at ~/.local/bin/uv, it gets overwritten below.

# Wrapper — routes caches and venvs to local disk, then execs real uv.
mkdir -p "$UV_DIR"
cat > "$UV_DIR/uv" <<'UVWRAP'
#!/bin/bash
export UV_CACHE_DIR="/tmp/uv"
export UV_PYTHON_INSTALL_DIR="/opt/uv/python"
_repo_root=$(timeout 3 git rev-parse --show-toplevel 2>/dev/null)
if [ -n "$_repo_root" ]; then
  _venv="/opt/venvs/$(basename "$_repo_root")"
  export UV_PROJECT_ENVIRONMENT="$_venv"
  mkdir -p "$_venv"
  if [ -f "$_venv/pyvenv.cfg" ]; then
    export VIRTUAL_ENV="$_venv"
  fi
fi
exec "$HOME/.local/lib/uv" "$@"
UVWRAP
chmod +x "$UV_DIR/uv"

# Symlink uvx
ln -sf "$UV_REAL"x "$UV_DIR/uvx" 2>/dev/null || true

# python/python3 wrappers in ~/.local/bin
for cmd in python python3; do
  cat > "$UV_DIR/$cmd" <<'PYWRAP'
#!/bin/bash
exec "$HOME/.local/bin/uv" run CMDNAME "$@"
PYWRAP
  sed -i "s/CMDNAME/$cmd/" "$UV_DIR/$cmd"
  chmod +x "$UV_DIR/$cmd"
done

# Symlink system tools from base venv into ~/.local/bin so they're available
# without putting all of /opt/brr/venv/bin on PATH (which would shadow our wrappers).
for tool in ray pip; do
  [ -x "$VENVDIR/bin/$tool" ] && ln -sf "$VENVDIR/bin/$tool" "$UV_DIR/$tool"
done
info "Installed uv/python wrappers in $UV_DIR"

# Shell environment — env vars (sourced by login/interactive shells)
sudo tee /etc/profile.d/brr.sh >/dev/null <<'BRRSH'
# brr shell environment
case ":$PATH:" in
  *":$HOME/.local/bin:"*) ;;
  *) export PATH="$HOME/.local/bin:$PATH" ;;
esac

export UV_PYTHON_INSTALL_DIR="/opt/uv/python"
export RAY_AUTH_MODE=token
BRRSH
# Also source from /etc/bash.bashrc for non-login bash shells (tmux)
if ! grep -q 'profile.d/brr.sh' /etc/bash.bashrc 2>/dev/null; then
  echo '[ -f /etc/profile.d/brr.sh ] && . /etc/profile.d/brr.sh' | sudo tee -a /etc/bash.bashrc >/dev/null
fi
info "Installed /etc/profile.d/brr.sh"

# Ray auth token — set in /etc/environment so it's available to all processes
# (including non-interactive SSH commands like `ray start` on workers)
if ! grep -q RAY_AUTH_MODE /etc/environment 2>/dev/null; then
  echo 'RAY_AUTH_MODE=token' | sudo tee -a /etc/environment >/dev/null
fi

# --- Configure sshd to detect dead connections ---
info "Configuring sshd ClientAlive settings"
sudo tee /etc/ssh/sshd_config.d/brr-keepalive.conf >/dev/null <<'SSHD'
ClientAliveInterval 60
ClientAliveCountMax 3
SSHD
sudo systemctl restart sshd 2>/dev/null || sudo systemctl restart ssh

# --- Idle shutdown daemon ---
if [ "${IDLE_SHUTDOWN_ENABLED}" = "true" ]; then
  info "Installing idle-shutdown daemon"

  sudo cp "/opt/brr/staging/idle-shutdown.sh" /usr/local/bin/idle-shutdown
  sudo chmod 755 /usr/local/bin/idle-shutdown

  sudo tee /etc/systemd/system/idle-shutdown.service >/dev/null <<UNIT
[Unit]
Description=Idle auto-shutdown daemon
After=network.target

[Service]
Type=simple
ExecStart=/usr/local/bin/idle-shutdown
Environment="IDLE_SHUTDOWN_TIMEOUT_MIN=${IDLE_SHUTDOWN_TIMEOUT_MIN}"
Environment="IDLE_SHUTDOWN_GRACE_MIN=${IDLE_SHUTDOWN_GRACE_MIN}"
Environment="IDLE_SHUTDOWN_CPU_THRESHOLD=${IDLE_SHUTDOWN_CPU_THRESHOLD}"
Environment="IDLE_SHUTDOWN_NET_THRESHOLD_KBPS=${IDLE_SHUTDOWN_NET_THRESHOLD_KBPS}"
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal
SyslogIdentifier=idle-shutdown

[Install]
WantedBy=multi-user.target
UNIT

  sudo systemctl daemon-reload
  sudo systemctl enable idle-shutdown.service
  sudo systemctl restart idle-shutdown.service
  info "idle-shutdown daemon installed and started"
else
  if systemctl is-active idle-shutdown.service >/dev/null 2>&1; then
    info "Disabling idle-shutdown daemon (IDLE_SHUTDOWN_ENABLED=false)"
    sudo systemctl stop idle-shutdown.service
    sudo systemctl disable idle-shutdown.service
  else
    info "Idle-shutdown daemon disabled"
  fi
fi

# GPU detection (informational)
if command -v nvidia-smi >/dev/null 2>&1; then
  info "GPU detected:"
  nvidia-smi --query-gpu=name,memory.total,driver_version --format=csv,noheader || true
else
  info "No GPU detected (nvidia-smi not found)"
fi
