"""Regression tests for tm_parser.leadership and the Leadership-section
parsing flow in pdf.py.

Issue: scouts whose PDFs contain an "Advancement Remarks" section caused
the whole scout to be dropped because:
  1. "Advancement Remarks" was not in Config.SECTION_MARKERS, so the
     leadership section never terminated at the boundary and remark prose
     got fed to get_leadership_dates.
  2. get_leadership_dates raised on inputs that did not match the
     "date - date" shape, propagating out of parse_scout and dropping the
     scout entirely.
"""

from more_itertools import grouper

from tm_parser.config import Config
from tm_parser.leadership import get_leadership_dates
from tm_parser.utils import section_markers_test


def test_advancement_remarks_is_a_section_marker():
    assert "Advancement Remarks" in Config.SECTION_MARKERS
    assert section_markers_test("Advancement Remarks") is True


def test_get_leadership_dates_parses_range():
    result = get_leadership_dates("10/01/25 - 03/31/26")
    assert result["Start Date"].isoformat() == "2025-10-01"
    assert result["End Date"].isoformat() == "2026-03-31"
    assert result["For Rank"] is True


def test_get_leadership_dates_marks_no_count():
    result = get_leadership_dates("10/01/25 - 03/31/26 #")
    assert result["For Rank"] is False


def test_get_leadership_dates_returns_none_on_remarks_prose():
    # Crepeau-style remark line, previously crashed with ValueError.
    assert (
        get_leadership_dates(
            "Star Review Board: Rob Snow, Mike Hedrick, Andy Jones, Daniel Sporer"
        )
        is None
    )


def test_get_leadership_dates_returns_none_on_none_input():
    # Odd-length leadership section: grouper pairs the trailing item with
    # None. Previously crashed with AttributeError.
    assert get_leadership_dates(None) is None


def test_get_leadership_dates_returns_none_on_non_string():
    assert get_leadership_dates(42) is None


def test_crepeau_leadership_section_no_longer_crashes():
    # Crepeau, Christopher's Leadership section from the troop 162 fixture.
    # Pre-fix: "Advancement Remarks" was not a section marker, so the last
    # two tokens leaked into the leadership list and crashed
    # get_leadership_dates with ValueError, dropping the entire scout.
    #
    # Post-fix: section_markers_test() now splits at "Advancement Remarks"
    # so the leadership list contains only valid (position, range) pairs.
    leadership_only = [
        "Asst Patrol Leader",
        "10/01/25 - 03/31/26 #",
        "Librarian",
        "07/01/25 - 09/30/25",
        "Librarian",
        "10/01/25 - 03/31/26",
        "Patrol Leader",
        "09/15/24 - 03/31/25",
    ]
    parsed = [
        {position: get_leadership_dates(value)}
        for position, value in grouper(leadership_only, 2)
    ]
    assert len(parsed) == 4
    assert all(next(iter(d.values())) is not None for d in parsed)
