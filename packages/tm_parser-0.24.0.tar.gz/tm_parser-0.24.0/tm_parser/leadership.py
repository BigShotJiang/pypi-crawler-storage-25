from .utils import get_date


def get_leadership_dates(line):
    """takes in "date - date #" and splits it into two dates and
    whether it counts for rank advancement (denoted by not having
    a hash symbol.

    Returns None if the input is missing or doesn't match the expected
    "date - date" shape, so a malformed entry on a single scout doesn't
    abort the whole parse."""
    if not isinstance(line, str) or " - " not in line:
        return None
    parts = line.split(" - ", 1)
    item1, item2 = parts[0], parts[1]
    item2, *rank_no_counts = item2.split()
    return {
        "Start Date": get_date(item1),
        "End Date": get_date(item2),
        "For Rank": not rank_no_counts,
    }
