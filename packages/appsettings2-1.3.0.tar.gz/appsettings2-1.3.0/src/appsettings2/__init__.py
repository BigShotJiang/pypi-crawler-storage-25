# SPDX-FileCopyrightText: © 2025 Shaun Wilson
# SPDX-License-Identifier: MIT

__version__ = '1.3.0'
__commit__ = '0abc123'

from .Configuration import Configuration
from .ConfigurationBuilder import ConfigurationBuilder
from .ConfigurationException import ConfigurationException
from .helpers import getConfiguration
from . import helpers
from . import providers


__all__ = [
    '__version__', '__commit__',
    'Configuration',
    'ConfigurationBuilder',
    'ConfigurationException',
    'getConfiguration',
    'helpers',
    'providers'
]
