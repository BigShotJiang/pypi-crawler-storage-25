import json

from openclaw_route_check.cli import main


def test_cli_session_json(capsys):
    code = main(["--session", "agent:main:telegram:group:-1003710118964", "--json"])
    output = json.loads(capsys.readouterr().out)

    assert code == 0
    assert output["results"][0]["resolved"]["channel"] == "telegram"
    assert output["results"][0]["resolved"]["target"] == "-1003710118964"


def test_cli_version(capsys):
    try:
        main(["--version"])
    except SystemExit as exc:
        assert exc.code == 0

    assert "openclaw-route-check 0.1.2" in capsys.readouterr().out


def test_cli_missing_announce_target_exits_nonzero(tmp_path, capsys):
    announce = tmp_path / "announce.json"
    announce.write_text('{"delivery": {"channel": "telegram"}}', encoding="utf-8")

    code = main(["--announce", str(announce), "--json"])
    output = json.loads(capsys.readouterr().out)

    assert code == 1
    assert output["ok"] is False
    assert output["results"][0]["findings"][0]["code"] == "missing-announce-target"


def test_cli_markdown_for_all_crons(tmp_path, capsys):
    jobs = tmp_path / "jobs.json"
    jobs.write_text(
        """
        {
          "jobs": [
            {
              "id": "safe",
              "type": "cron",
              "cron": "*/5 * * * *",
              "delivery": {"channel": "telegram", "target": "-1001"}
            }
          ]
        }
        """,
        encoding="utf-8",
    )

    code = main(["--jobs", str(jobs), "--all-crons", "--markdown"])
    output = capsys.readouterr().out

    assert code == 0
    assert "# OpenClaw Route Check" in output
    assert "cron: `safe`" in output
