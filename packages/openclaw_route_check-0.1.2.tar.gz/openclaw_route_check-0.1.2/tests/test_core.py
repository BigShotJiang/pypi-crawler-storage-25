from openclaw_route_check.core import (
    analyze_announce,
    analyze_job,
    analyze_session,
    find_job,
    load_jobs,
    resolved_channel,
    resolved_target,
    resolved_thread,
)


def codes(result):
    return {finding.code for finding in result.findings}


def test_explicit_announce_resolution():
    result = analyze_announce(
        {
            "delivery": {
                "channel": "telegram",
                "target": "-1003710118964",
                "thread_id": "77",
            }
        }
    )

    assert result.ok
    assert resolved_channel(result.route) == "telegram"
    assert resolved_target(result.route) == "-1003710118964"
    assert resolved_thread(result.route) == "77"
    assert result.findings == []


def test_ambiguous_routing_detection():
    result = analyze_job(
        {
            "id": "ambiguous-last",
            "type": "cron",
            "cron": "0 * * * *",
            "delivery": {"channel": "last", "target": "last"},
        }
    )

    assert "ambiguous-channel-last" in codes(result)
    assert "ambiguous-target-last" in codes(result)
    assert result.confidence < 100


def test_thread_topic_loss_from_session_key():
    result = analyze_announce(
        {
            "sessionKey": "agent:main:telegram:group:-1003710118964:topic:77",
            "delivery": {"channel": "telegram", "target": "-1003710118964"},
        }
    )

    assert "likely-thread-loss" in codes(result)
    assert resolved_thread(result.route) == "77"


def test_session_and_delivery_target_mismatch():
    result = analyze_announce(
        {
            "sessionKey": "agent:main:telegram:group:-1003710118964",
            "delivery": {"channel": "telegram", "target": "-100999"},
        }
    )

    assert "session-target-mismatch" in codes(result)


def test_missing_announce_target_is_error():
    result = analyze_announce({"delivery": {"channel": "telegram"}})

    assert not result.ok
    assert "missing-announce-target" in codes(result)


def test_session_key_parsing():
    result = analyze_session("agent:main:telegram:group:-1003710118964")

    assert result.route.session_channel == "telegram"
    assert result.route.session_target == "-1003710118964"
    assert result.route.session_behavior == "session-target"


def test_jobs_loader_and_finder():
    jobs = load_jobs(
        {
            "jobs": [
                {
                    "id": "429c62e0-2b1f-4179-bac3-792f405d09ae",
                    "cron": "*/15 * * * *",
                    "announce": {"channel": "telegram", "target": "-1003710118964"},
                }
            ]
        }
    )

    assert find_job(jobs, "429c62e0-2b1f-4179-bac3-792f405d09ae") == jobs[0]

