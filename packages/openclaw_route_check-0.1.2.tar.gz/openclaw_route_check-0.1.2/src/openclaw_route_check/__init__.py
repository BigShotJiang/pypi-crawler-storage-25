"""Static OpenClaw routing analysis."""

from .core import CheckResult, Finding, Route, analyze_announce, analyze_job, analyze_session

__all__ = [
    "CheckResult",
    "Finding",
    "Route",
    "analyze_announce",
    "analyze_job",
    "analyze_session",
]

__version__ = "0.1.2"
