from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterable, Mapping


CHANNEL_KEYS = ("channel", "transport", "provider", "driver", "via")
TARGET_KEYS = (
    "target",
    "chat",
    "chat_id",
    "chatId",
    "room",
    "room_id",
    "to",
    "recipient",
    "target_id",
    "targetId",
    "channel_id",
    "channelId",
)
THREAD_KEYS = (
    "thread",
    "thread_id",
    "threadId",
    "topic",
    "topic_id",
    "topicId",
    "message_thread_id",
    "messageThreadId",
    "forum_topic_id",
    "forumTopicId",
)
SESSION_KEYS = ("sessionKey", "session_key", "session", "sessionId", "session_id")
ROUTE_CONTAINERS = ("route", "routing", "delivery", "announce", "target", "destination")
JOB_ID_KEYS = ("id", "job_id", "jobId", "uuid", "name")


@dataclass(frozen=True)
class Finding:
    severity: str
    code: str
    message: str


@dataclass
class Route:
    channel: str | None = None
    target: str | None = None
    thread: str | None = None
    session_key: str | None = None
    session_channel: str | None = None
    session_target: str | None = None
    session_thread: str | None = None
    session_behavior: str = "none"
    source: str = "input"


@dataclass
class CheckResult:
    subject: str
    kind: str
    route: Route
    findings: list[Finding] = field(default_factory=list)

    @property
    def confidence(self) -> int:
        score = 100
        for finding in self.findings:
            if finding.severity == "error":
                score -= 30
            elif finding.severity == "warning":
                score -= 15
            else:
                score -= 5
        return max(0, score)

    @property
    def ok(self) -> bool:
        return not any(f.severity == "error" for f in self.findings)


def analyze_session(session_key: str) -> CheckResult:
    route = route_from_mapping({"sessionKey": session_key}, source="session")
    findings = evaluate_route(route, require_target=False, warn_session_dependency=False)
    return CheckResult(subject=session_key, kind="session", route=route, findings=findings)


def analyze_channel_target(
    channel: str | None,
    target: str | None,
    *,
    thread: str | None = None,
    session_key: str | None = None,
) -> CheckResult:
    route = Route(
        channel=clean(channel),
        target=clean(target),
        thread=clean(thread),
        session_key=clean(session_key),
        source="channel-target",
    )
    if route.session_key:
        merge_session(route, parse_session_key(route.session_key))
    findings = evaluate_route(route, require_target=True)
    return CheckResult(subject="channel-target", kind="channel-target", route=route, findings=findings)


def analyze_announce(config: Mapping[str, Any], *, subject: str = "announce") -> CheckResult:
    route = route_from_mapping(config, source=subject)
    findings = evaluate_route(route, require_target=True)
    return CheckResult(subject=subject, kind="announce", route=route, findings=findings)


def analyze_job(job: Mapping[str, Any]) -> CheckResult:
    subject = first_value(job, JOB_ID_KEYS) or "job"
    route = route_from_mapping(job, source=str(subject))
    findings = evaluate_route(route, require_target=False)
    if is_cron_job(job) and (not route.channel or not route.target):
        findings.append(
            Finding(
                "warning",
                "implicit-routing",
                "Cron job does not define both an explicit channel and target; production routing may depend on runtime context.",
            )
        )
    return CheckResult(subject=str(subject), kind="cron" if is_cron_job(job) else "job", route=route, findings=findings)


def evaluate_route(route: Route, *, require_target: bool, warn_session_dependency: bool = True) -> list[Finding]:
    findings: list[Finding] = []

    if require_target and not resolved_target(route):
        findings.append(
            Finding(
                "error",
                "missing-announce-target",
                "No explicit delivery target or usable session target was found.",
            )
        )

    channel = resolved_channel(route)
    if channel and channel.lower() == "last":
        findings.append(
            Finding(
                "warning",
                "ambiguous-channel-last",
                "`channel: last` depends on mutable conversation state and is ambiguous in static routing.",
            )
        )

    if route.target and route.target.lower() == "last":
        findings.append(
            Finding(
                "warning",
                "ambiguous-target-last",
                "`target: last` depends on mutable conversation state and is ambiguous in static routing.",
            )
        )

    if route.session_key:
        if route.channel and route.session_channel and route.channel != route.session_channel:
            findings.append(
                Finding(
                    "warning",
                    "session-channel-mismatch",
                    f"sessionKey channel `{route.session_channel}` differs from delivery channel `{route.channel}`.",
                )
            )
        if route.target and route.session_target and route.target != route.session_target:
            findings.append(
                Finding(
                    "warning",
                    "session-target-mismatch",
                    f"sessionKey target `{route.session_target}` differs from delivery target `{route.target}`.",
                )
            )
        if warn_session_dependency and route.session_thread and not route.thread:
            findings.append(
                Finding(
                    "warning",
                    "likely-thread-loss",
                    "sessionKey contains a thread/topic but delivery config has no explicit thread/topic field.",
                )
            )
        if warn_session_dependency and (not route.channel or not route.target):
            findings.append(
                Finding(
                    "info",
                    "session-routing",
                    "Routing relies on session target behavior; verify the runtime session is still available.",
                )
            )

    if route.thread and route.session_thread and route.thread != route.session_thread:
        findings.append(
            Finding(
                "warning",
                "thread-topic-mismatch",
                f"sessionKey thread/topic `{route.session_thread}` differs from delivery thread/topic `{route.thread}`.",
            )
        )

    if is_thread_like(route.target) and not route.thread:
        findings.append(
            Finding(
                "warning",
                "likely-thread-loss",
                "Target looks thread/topic-specific, but no dedicated thread/topic field was found.",
            )
        )

    return findings


def route_from_mapping(config: Mapping[str, Any], *, source: str) -> Route:
    flattened = flatten_route_fields(config)
    route = Route(
        channel=clean(first_value(flattened, CHANNEL_KEYS)),
        target=clean(first_value(flattened, TARGET_KEYS)),
        thread=clean(first_value(flattened, THREAD_KEYS)),
        session_key=clean(first_value(flattened, SESSION_KEYS)),
        source=source,
    )
    if route.session_key:
        merge_session(route, parse_session_key(route.session_key))
    return route


def flatten_route_fields(value: Any) -> dict[str, Any]:
    out: dict[str, Any] = {}

    def visit(node: Any, *, allowed_depth: int) -> None:
        if not isinstance(node, Mapping):
            return
        for key, item in node.items():
            if key not in out and item is not None and not isinstance(item, (Mapping, list)):
                out[str(key)] = item
        if allowed_depth <= 0:
            return
        for key, item in node.items():
            if key in ROUTE_CONTAINERS or any(token in str(key).lower() for token in ("route", "deliver", "announce", "target")):
                visit(item, allowed_depth=allowed_depth - 1)

    visit(value, allowed_depth=4)
    return out


def parse_session_key(session_key: str) -> Route:
    parts = session_key.split(":")
    route = Route(session_key=session_key, session_behavior="opaque")
    if len(parts) >= 5:
        route.session_channel = clean(parts[2])
        route.session_target = clean(parts[4])
        route.session_behavior = "session-target"
    if len(parts) >= 7 and parts[5].lower() in {"thread", "topic", "message_thread", "message_thread_id"}:
        route.session_thread = clean(parts[6])
        route.session_behavior = "session-target-thread"
    elif len(parts) >= 6 and looks_numeric(parts[5]):
        route.session_thread = clean(parts[5])
        route.session_behavior = "session-target-thread"
    return route


def merge_session(route: Route, session_route: Route) -> None:
    route.session_channel = session_route.session_channel
    route.session_target = session_route.session_target
    route.session_thread = session_route.session_thread
    route.session_behavior = session_route.session_behavior


def load_jobs(data: Any) -> list[Mapping[str, Any]]:
    if isinstance(data, list):
        return [item for item in data if isinstance(item, Mapping)]
    if isinstance(data, Mapping):
        for key in ("jobs", "crons", "cronJobs", "cron_jobs"):
            if isinstance(data.get(key), list):
                return [item for item in data[key] if isinstance(item, Mapping)]
        if any(key in data for key in JOB_ID_KEYS):
            return [data]
    return []


def is_cron_job(job: Mapping[str, Any]) -> bool:
    return any(key in job for key in ("cron", "schedule", "crontab", "interval")) or str(job.get("type", "")).lower() == "cron"


def find_job(jobs: Iterable[Mapping[str, Any]], job_id: str) -> Mapping[str, Any] | None:
    for job in jobs:
        if clean(first_value(job, JOB_ID_KEYS)) == job_id:
            return job
    return None


def first_value(mapping: Mapping[str, Any], keys: Iterable[str]) -> Any:
    for key in keys:
        if key in mapping and mapping[key] is not None:
            return mapping[key]
    return None


def resolved_channel(route: Route) -> str | None:
    return route.channel or route.session_channel


def resolved_target(route: Route) -> str | None:
    return route.target or route.session_target


def resolved_thread(route: Route) -> str | None:
    return route.thread or route.session_thread


def clean(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def looks_numeric(value: str) -> bool:
    return value.lstrip("-").isdigit()


def is_thread_like(value: str | None) -> bool:
    if not value:
        return False
    lower = value.lower()
    return "thread" in lower or "topic" in lower
