from __future__ import annotations

import json
from dataclasses import asdict

from .core import CheckResult, resolved_channel, resolved_target, resolved_thread


def result_to_dict(result: CheckResult) -> dict[str, object]:
    return {
        "subject": result.subject,
        "kind": result.kind,
        "ok": result.ok,
        "confidence": result.confidence,
        "resolved": {
            "channel": resolved_channel(result.route),
            "target": resolved_target(result.route),
            "thread": resolved_thread(result.route),
            "sessionTargetBehavior": result.route.session_behavior,
        },
        "route": asdict(result.route),
        "findings": [asdict(finding) for finding in result.findings],
    }


def render_json(results: list[CheckResult]) -> str:
    payload = {
        "ok": all(result.ok for result in results),
        "results": [result_to_dict(result) for result in results],
    }
    return json.dumps(payload, indent=2, sort_keys=True)


def render_markdown(results: list[CheckResult]) -> str:
    lines = ["# OpenClaw Route Check", ""]
    for result in results:
        status = "OK" if result.ok else "FAIL"
        lines.extend(
            [
                f"## {result.kind}: `{result.subject}`",
                "",
                f"- Status: **{status}**",
                f"- Confidence: **{result.confidence}**",
                f"- Resolved channel: `{display(resolved_channel(result.route))}`",
                f"- Resolved target/chat: `{display(resolved_target(result.route))}`",
                f"- Thread/topic: `{display(resolved_thread(result.route))}`",
                f"- Session target behavior: `{result.route.session_behavior}`",
                "",
            ]
        )
        if result.findings:
            lines.append("| Severity | Code | Message |")
            lines.append("| --- | --- | --- |")
            for finding in result.findings:
                lines.append(f"| {finding.severity} | `{finding.code}` | {finding.message} |")
            lines.append("")
        else:
            lines.extend(["No routing risks detected.", ""])
    return "\n".join(lines).rstrip() + "\n"


def render_terminal(results: list[CheckResult]) -> str:
    chunks: list[str] = []
    for result in results:
        status = "OK" if result.ok else "FAIL"
        chunks.extend(
            [
                f"{result.kind}: {result.subject} [{status}] confidence={result.confidence}",
                f"  channel: {display(resolved_channel(result.route))}",
                f"  target/chat: {display(resolved_target(result.route))}",
                f"  thread/topic: {display(resolved_thread(result.route))}",
                f"  session behavior: {result.route.session_behavior}",
            ]
        )
        if result.findings:
            chunks.append("  findings:")
            for finding in result.findings:
                chunks.append(f"    - {finding.severity} {finding.code}: {finding.message}")
        else:
            chunks.append("  findings: none")
    return "\n".join(chunks)


def display(value: object) -> str:
    return "-" if value is None else str(value)

