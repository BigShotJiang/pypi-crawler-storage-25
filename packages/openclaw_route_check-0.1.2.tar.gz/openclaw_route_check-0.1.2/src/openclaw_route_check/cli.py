from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from . import __version__
from .core import analyze_announce, analyze_channel_target, analyze_job, analyze_session, find_job, load_jobs
from .render import render_json, render_markdown, render_terminal


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="openclaw-route-check",
        description="Statically check OpenClaw routing for jobs, sessions, announce config, and channel/target pairs.",
    )
    parser.add_argument("--jobs", default="jobs.json", help="Path to jobs.json. Defaults to ./jobs.json.")
    parser.add_argument("--job", help="Check one cron/job by id, uuid, job_id, or name.")
    parser.add_argument("--all-crons", action="store_true", help="Check every cron-like job in jobs.json.")
    parser.add_argument("--session", help="Check a session key such as agent:main:telegram:group:-1003710118964.")
    parser.add_argument("--announce", help="Path to announce delivery JSON config.")
    parser.add_argument("--channel", help="Explicit channel to check.")
    parser.add_argument("--target", help="Explicit target/chat to check.")
    parser.add_argument("--thread", help="Explicit thread/topic id to check.")
    parser.add_argument("--session-key", help="Session key to compare with --channel/--target/--thread.")
    parser.add_argument("--json", action="store_true", help="Emit machine-readable JSON.")
    parser.add_argument("--markdown", action="store_true", help="Emit Markdown suitable for CI summaries.")
    parser.add_argument("--strict", action="store_true", help="Exit non-zero on warnings as well as errors.")
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        results = collect_results(args)
    except RouteCheckError as exc:
        print(f"openclaw-route-check: {exc}", file=sys.stderr)
        return 2

    if not results:
        print("openclaw-route-check: no checks requested", file=sys.stderr)
        return 2

    if args.json:
        output = render_json(results)
    elif args.markdown:
        output = render_markdown(results)
    else:
        output = render_terminal(results)
    print(output)

    if any(not result.ok for result in results):
        return 1
    if args.strict and any(result.findings for result in results):
        return 1
    return 0


def collect_results(args: argparse.Namespace):
    results = []
    if args.session:
        results.append(analyze_session(args.session))

    if args.channel or args.target or args.thread or args.session_key:
        results.append(analyze_channel_target(args.channel, args.target, thread=args.thread, session_key=args.session_key))

    if args.announce:
        data = load_json(Path(args.announce))
        if not isinstance(data, dict):
            raise RouteCheckError("--announce must point to a JSON object")
        results.append(analyze_announce(data, subject=Path(args.announce).name))

    if args.job or args.all_crons:
        jobs = load_jobs(load_json(Path(args.jobs)))
        if args.job:
            job = find_job(jobs, args.job)
            if job is None:
                raise RouteCheckError(f"job `{args.job}` not found in {args.jobs}")
            results.append(analyze_job(job))
        if args.all_crons:
            cron_results = []
            for job in jobs:
                result = analyze_job(job)
                if result.kind == "cron":
                    cron_results.append(result)
            results.extend(cron_results)

    return results


def load_json(path: Path) -> Any:
    if not path.exists():
        raise RouteCheckError(f"{path} does not exist")
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise RouteCheckError(f"{path} is not valid JSON: {exc}") from exc


class RouteCheckError(Exception):
    pass


if __name__ == "__main__":
    raise SystemExit(main())
