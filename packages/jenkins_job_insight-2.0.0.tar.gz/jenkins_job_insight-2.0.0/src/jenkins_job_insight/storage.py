"""SQLite storage for analysis results."""

import json
import os
from datetime import datetime, timedelta, timezone
from pathlib import Path
from collections.abc import Callable
from typing import get_args

import aiosqlite
from simple_logger.logger import get_logger

from jenkins_job_insight.encryption import strip_sensitive_from_response
from jenkins_job_insight.models import (
    HistoryClassificationLiteral,
    OverrideClassificationLiteral,
)

logger = get_logger(name=__name__, level=os.environ.get("LOG_LEVEL", "INFO"))

DB_PATH = Path(os.getenv("DB_PATH", "/data/results.db"))

# Primary (override) classifications — derived from the OverrideClassificationLiteral
# type so the SQL filter stays in sync with the model definition.
PRIMARY_CLASSIFICATIONS: tuple[str, ...] = get_args(OverrideClassificationLiteral)

# History classifications — derived from HistoryClassificationLiteral so the
# write-side validation in set_test_classification stays in sync with the model.
HISTORY_CLASSIFICATIONS: tuple[str, ...] = get_args(HistoryClassificationLiteral)
_PRIMARY_CLASSIFICATIONS_SQL = (
    "(" + ", ".join(f"'{c}'" for c in PRIMARY_CLASSIFICATIONS) + ")"
)


def parse_result_json(raw: str | None, *, job_id: str = "") -> dict | None:
    """Decode and validate a ``result_json`` blob.

    Args:
        raw: The raw JSON string from the database, or None.
        job_id: Optional job_id for log messages.

    Returns:
        Parsed dict when valid, None when *raw* is empty/malformed.
    """
    if not raw:
        return None
    try:
        data = json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        logger.warning(
            f"parse_result_json: malformed JSON for job_id={job_id}, skipping"
        )
        return None
    if not isinstance(data, dict):
        logger.warning(
            f"parse_result_json: result_json is not a dict for job_id={job_id}, skipping"
        )
        return None
    return data


async def _migrate_add_column(
    db: aiosqlite.Connection,
    table: str,
    column: str,
    column_def: str,
) -> None:
    """Add a column to a table if it does not already exist.

    Args:
        db: Active database connection.
        table: Table name.
        column: Column name to check/add.
        column_def: Full column definition (e.g. "TEXT NOT NULL DEFAULT ''").
    """
    cursor = await db.execute(f"PRAGMA table_info({table})")
    columns = {row[1] for row in await cursor.fetchall()}
    if column not in columns:
        await db.execute(f"ALTER TABLE {table} ADD COLUMN {column} {column_def}")
        logger.info(f"Migration: added {column} column to {table}")
    else:
        logger.debug(f"Migration: {table} already has {column} column")


async def init_db() -> None:
    """Initialize the database schema.

    Creates the results table if it does not exist.
    """
    logger.info(f"Initializing database at {DB_PATH}")
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS results (
                job_id TEXT PRIMARY KEY,
                jenkins_url TEXT,
                status TEXT,
                result_json TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                analysis_started_at TIMESTAMP
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS comments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                job_id TEXT NOT NULL,
                test_name TEXT NOT NULL,
                child_job_name TEXT NOT NULL DEFAULT '',
                child_build_number INTEGER NOT NULL DEFAULT 0,
                comment TEXT NOT NULL,
                error_signature TEXT NOT NULL DEFAULT '',
                username TEXT NOT NULL DEFAULT '',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await db.execute(
            "CREATE INDEX IF NOT EXISTS idx_comments_job_id ON comments (job_id)"
        )
        await db.execute(
            "CREATE INDEX IF NOT EXISTS idx_comments_test_name ON comments (test_name)"
        )
        await db.execute(
            "CREATE INDEX IF NOT EXISTS idx_comments_error_signature ON comments (error_signature)"
        )
        await db.execute("""
            CREATE TABLE IF NOT EXISTS failure_reviews (
                job_id TEXT NOT NULL,
                test_name TEXT NOT NULL,
                child_job_name TEXT NOT NULL DEFAULT '',
                child_build_number INTEGER NOT NULL DEFAULT 0,
                reviewed BOOLEAN DEFAULT 0,
                username TEXT NOT NULL DEFAULT '',
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (job_id, test_name, child_job_name, child_build_number)
            )
        """)

        # Migration: add child_build_number to existing tables
        # (needed when upgrading from versions without this column)
        logger.info("Running database migrations...")
        for table in ("comments", "failure_reviews"):
            await _migrate_add_column(
                db, table, "child_build_number", "INTEGER NOT NULL DEFAULT 0"
            )

        # Migration: add username to comments and failure_reviews
        for table in ("comments", "failure_reviews"):
            await _migrate_add_column(db, table, "username", "TEXT NOT NULL DEFAULT ''")

        # Migration: add error_signature to comments table
        await _migrate_add_column(
            db, "comments", "error_signature", "TEXT NOT NULL DEFAULT ''"
        )

        # Migration: rebuild failure_reviews with correct 4-column PRIMARY KEY
        # ALTER TABLE cannot change PKs in SQLite, so we need a full rebuild
        cursor = await db.execute("PRAGMA table_info(failure_reviews)")
        columns = {row[1] for row in await cursor.fetchall()}
        if "child_build_number" in columns:
            # Check if PK includes child_build_number by inspecting table SQL
            cursor = await db.execute(
                "SELECT sql FROM sqlite_master WHERE type='table' AND name='failure_reviews'"
            )
            create_sql = (await cursor.fetchone())[0]
            if (
                "child_build_number" not in create_sql.split("PRIMARY KEY")[1]
                if "PRIMARY KEY" in create_sql
                else ""
            ):
                logger.info(
                    "Migration: rebuilding failure_reviews table with 4-column PRIMARY KEY"
                )
                await db.execute(
                    "ALTER TABLE failure_reviews RENAME TO failure_reviews_old"
                )
                await db.execute("""
                    CREATE TABLE failure_reviews (
                        job_id TEXT NOT NULL,
                        test_name TEXT NOT NULL,
                        child_job_name TEXT NOT NULL DEFAULT '',
                        child_build_number INTEGER NOT NULL DEFAULT 0,
                        reviewed BOOLEAN DEFAULT 0,
                        username TEXT NOT NULL DEFAULT '',
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        PRIMARY KEY (job_id, test_name, child_job_name, child_build_number)
                    )
                """)
                await db.execute("""
                    INSERT INTO failure_reviews (job_id, test_name, child_job_name, child_build_number, reviewed, username, updated_at)
                    SELECT job_id, test_name, child_job_name, child_build_number, reviewed, COALESCE(username, ''), updated_at
                    FROM failure_reviews_old
                """)
                await db.execute("DROP TABLE failure_reviews_old")
                logger.info("Migration: failure_reviews table rebuilt successfully")

        # Ensure test_classifications table exists before running migrations.
        # On a fresh DB the table may not exist yet, so CREATE TABLE must come
        # before any ALTER TABLE migrations.
        await db.execute("""
            CREATE TABLE IF NOT EXISTS test_classifications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                test_name TEXT NOT NULL,
                job_name TEXT NOT NULL DEFAULT '',
                parent_job_name TEXT NOT NULL DEFAULT '',
                classification TEXT NOT NULL,
                reason TEXT NOT NULL DEFAULT '',
                references_info TEXT NOT NULL DEFAULT '',
                created_by TEXT NOT NULL DEFAULT '',
                job_id TEXT NOT NULL DEFAULT '',
                child_build_number INTEGER NOT NULL DEFAULT 0,
                visible INTEGER NOT NULL DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Migrations: add columns to test_classifications table
        await _migrate_add_column(
            db, "test_classifications", "parent_job_name", "TEXT NOT NULL DEFAULT ''"
        )
        await _migrate_add_column(
            db, "test_classifications", "references_info", "TEXT NOT NULL DEFAULT ''"
        )
        await _migrate_add_column(
            db, "test_classifications", "job_id", "TEXT NOT NULL DEFAULT ''"
        )
        await _migrate_add_column(
            db, "test_classifications", "visible", "INTEGER NOT NULL DEFAULT 1"
        )
        await _migrate_add_column(
            db,
            "test_classifications",
            "child_build_number",
            "INTEGER NOT NULL DEFAULT 0",
        )

        # Migrations: add columns to results table
        await _migrate_add_column(db, "results", "completed_at", "TIMESTAMP")
        await _migrate_add_column(db, "results", "analysis_started_at", "TIMESTAMP")

        # failure_history: denormalized table for fast history queries
        await db.execute("""
            CREATE TABLE IF NOT EXISTS failure_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                job_id TEXT NOT NULL,
                job_name TEXT NOT NULL,
                build_number INTEGER NOT NULL,
                test_name TEXT NOT NULL,
                error_message TEXT NOT NULL DEFAULT '',
                error_signature TEXT NOT NULL DEFAULT '',
                classification TEXT NOT NULL DEFAULT '',
                child_job_name TEXT NOT NULL DEFAULT '',
                child_build_number INTEGER NOT NULL DEFAULT 0,
                analyzed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await db.execute(
            "CREATE INDEX IF NOT EXISTS idx_fh_test_name ON failure_history (test_name)"
        )
        await db.execute(
            "CREATE INDEX IF NOT EXISTS idx_fh_error_signature ON failure_history (error_signature)"
        )
        await db.execute(
            "CREATE INDEX IF NOT EXISTS idx_fh_job_name ON failure_history (job_name)"
        )
        await db.execute(
            "CREATE INDEX IF NOT EXISTS idx_fh_analyzed_at ON failure_history (analyzed_at)"
        )
        await db.execute(
            "CREATE INDEX IF NOT EXISTS idx_fh_job_test ON failure_history (job_name, test_name)"
        )
        await db.execute(
            "CREATE INDEX IF NOT EXISTS idx_fh_job_context ON failure_history (job_id, test_name, child_job_name, child_build_number)"
        )
        await db.execute(
            "CREATE INDEX IF NOT EXISTS idx_fh_classification ON failure_history (classification)"
        )

        await db.execute(
            "CREATE INDEX IF NOT EXISTS idx_tc_test_name ON test_classifications (test_name)"
        )
        await db.execute(
            "CREATE INDEX IF NOT EXISTS idx_tc_job_id_visible ON test_classifications (job_id, visible)"
        )
        await db.execute(
            "CREATE INDEX IF NOT EXISTS idx_tc_classification ON test_classifications (classification)"
        )

        await db.commit()

    # Backfill failure_history from existing results (runs once when table is empty).
    # This runs synchronously in the lifespan hook, which means the server does not
    # accept requests until it finishes.  This is acceptable because:
    #  1. The backfill only runs once — when failure_history is empty but results exist.
    #  2. Subsequent startups skip it instantly (the table is no longer empty).
    #  3. The expected data volume (hundreds to low-thousands of results) completes
    #     in under a second on typical hardware.
    await backfill_failure_history()


def _validate_child_identifier_pairing(
    child_job_name: str, child_build_number: int
) -> None:
    """Validate child_job_name / child_build_number pairing.

    This validator only rejects *structurally invalid* combinations.
    Callers are responsible for giving semantic meaning to the valid ones.

    Valid combinations (structural):
    - Both empty  (``""``, ``0``) -- top-level (no child context).
    - Name set, build ``0``       -- accepted; callers decide the semantics
      (e.g. ``_mirror_classification_to_failure_history`` treats this as a wildcard
      targeting all builds of that child job, while ``add_comment`` and
      ``set_reviewed`` store it literally).
    - Both set    (name, N>0)     -- specific child build.

    Invalid:
    - Name empty, build > 0       -- a build number without a job name is meaningless.
    - Any negative build number.
    """
    if child_build_number < 0:
        raise ValueError("child_build_number must not be negative")
    if not child_job_name and child_build_number > 0:
        raise ValueError("child_job_name is required when child_build_number is set")


async def add_comment(
    job_id: str,
    test_name: str,
    comment: str,
    child_job_name: str = "",
    child_build_number: int = 0,
    error_signature: str = "",
    username: str = "",
) -> int:
    """Add a comment to a test failure."""
    logger.debug(
        f"add_comment: job_id={job_id}, test_name={test_name}, comment_len={len(comment)}"
    )
    _validate_child_identifier_pairing(child_job_name, child_build_number)
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute(
            "INSERT INTO comments (job_id, test_name, child_job_name, child_build_number, comment, error_signature, username) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (
                job_id,
                test_name,
                child_job_name,
                child_build_number,
                comment,
                error_signature,
                username,
            ),
        )
        await db.commit()
        return cursor.lastrowid


async def delete_comment(comment_id: int, username: str, job_id: str = "") -> bool:
    """Delete a comment. Username check is a UI courtesy, not security.

    DESIGN DECISION: No authentication in this project.
    All users are trusted. Username matching is a UI convenience
    (shows delete button only for your own comments), NOT a security control.
    Any user can delete any comment. See issue #55 for future auth plans.

    Returns True if deleted, False if not found.
    """
    logger.debug(f"delete_comment: comment_id={comment_id}, job_id={job_id}")
    async with aiosqlite.connect(DB_PATH) as db:
        # Build query with optional scoping filters
        query = "DELETE FROM comments WHERE id = ?"
        params: list = [comment_id]
        if username:
            query += " AND username = ?"
            params.append(username)
        if job_id:
            query += " AND job_id = ?"
            params.append(job_id)
        cursor = await db.execute(query, params)
        await db.commit()
        deleted = cursor.rowcount > 0
        logger.debug(f"delete_comment: comment_id={comment_id}, deleted={deleted}")
        return deleted


async def get_comments_for_job(job_id: str) -> list[dict]:
    """Get all comments for a specific job."""
    logger.debug(f"get_comments_for_job: job_id={job_id}")
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            "SELECT id, job_id, test_name, child_job_name, child_build_number, comment, error_signature, username, created_at "
            "FROM comments WHERE job_id = ? ORDER BY created_at ASC",
            (job_id,),
        )
        rows = await cursor.fetchall()
        result = [dict(row) for row in rows]
        logger.debug(f"get_comments_for_job: job_id={job_id}, count={len(result)}")
        return result


async def set_reviewed(
    job_id: str,
    test_name: str,
    reviewed: bool,
    child_job_name: str = "",
    child_build_number: int = 0,
    username: str = "",
) -> None:
    """Set or update the reviewed state for a test failure."""
    logger.debug(
        f"set_reviewed: job_id={job_id}, test_name={test_name}, reviewed={reviewed}"
    )
    _validate_child_identifier_pairing(child_job_name, child_build_number)
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT OR REPLACE INTO failure_reviews (job_id, test_name, child_job_name, child_build_number, reviewed, username, updated_at) "
            "VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)",
            (job_id, test_name, child_job_name, child_build_number, reviewed, username),
        )
        await db.commit()


async def get_reviews_for_job(job_id: str) -> dict[str, dict]:
    """Get all review states for a specific job."""
    logger.debug(f"get_reviews_for_job: job_id={job_id}")
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            "SELECT test_name, child_job_name, child_build_number, reviewed, username, updated_at "
            "FROM failure_reviews WHERE job_id = ?",
            (job_id,),
        )
        rows = await cursor.fetchall()
        result = {}
        for row in rows:
            if row["child_job_name"] != "":
                key = f"{row['child_job_name']}#{row['child_build_number']}::{row['test_name']}"
            else:
                key = row["test_name"]
            result[key] = {
                "reviewed": bool(row["reviewed"]),
                "username": row["username"],
                "updated_at": row["updated_at"],
            }
        logger.debug(f"get_reviews_for_job: job_id={job_id}, count={len(result)}")
        return result


async def get_review_status(job_id: str) -> dict:
    """Get review summary for a job (used by dashboard)."""
    logger.debug(f"get_review_status: job_id={job_id}")
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute(
            "SELECT result_json FROM results WHERE job_id = ?", (job_id,)
        )
        row = await cursor.fetchone()
        total_failures = 0
        if row and row[0]:
            result_data = parse_result_json(row[0], job_id=job_id)
            if result_data is not None:
                total_failures = count_all_failures(result_data)

        cursor = await db.execute(
            "SELECT COUNT(*) FROM failure_reviews WHERE job_id = ? AND reviewed = 1",
            (job_id,),
        )
        reviewed_count = (await cursor.fetchone())[0]

        cursor = await db.execute(
            "SELECT COUNT(*) FROM comments WHERE job_id = ?", (job_id,)
        )
        comment_count = (await cursor.fetchone())[0]

        logger.debug(
            f"get_review_status: job_id={job_id}, total_failures={total_failures}, reviewed_count={reviewed_count}, comment_count={comment_count}"
        )
        return {
            "total_failures": total_failures,
            "reviewed_count": reviewed_count,
            "comment_count": comment_count,
        }


async def get_historical_comments(
    test_names: list[str] | None = None,
    error_signatures: list[str] | None = None,
    exclude_job_id: str | None = None,
) -> list[dict]:
    """Get historical comments for similar failures across jobs.

    Matches by test name OR by error signature.
    No arbitrary limit -- returns all matching comments.
    """
    logger.debug(
        f"get_historical_comments: test_names_count={len(test_names) if test_names else 0}, signatures_count={len(error_signatures) if error_signatures else 0}, exclude_job_id={exclude_job_id}"
    )
    conditions: list[str] = []
    params: list[str] = []

    if test_names:
        placeholders = ",".join("?" for _ in test_names)
        conditions.append(f"test_name IN ({placeholders})")
        params.extend(test_names)

    if error_signatures:
        placeholders = ",".join("?" for _ in error_signatures)
        conditions.append(f"error_signature IN ({placeholders})")
        params.extend(error_signatures)

    if not conditions:
        return []

    where = " OR ".join(conditions)
    if exclude_job_id:
        where = f"({where}) AND job_id != ?"
        params.append(exclude_job_id)

    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            f"SELECT id, job_id, test_name, child_job_name, child_build_number, comment, error_signature, username, created_at "
            f"FROM comments WHERE {where} ORDER BY created_at DESC",
            params,
        )
        rows = await cursor.fetchall()
        result = [dict(row) for row in rows]
        logger.debug(f"get_historical_comments: count={len(result)}")
        return result


def _build_status_update_clause(
    status: str,
    result_json: str | None = None,
) -> tuple[list[str], list]:
    """Build the SET clause parts and params for a status update.

    Returns the set-clause fragments and the corresponding parameter list.
    The caller must append the trailing ``job_id`` parameter.

    Args:
        status: New status value.
        result_json: Serialized result JSON. When not None, ``result_json``
            is included in the update.

    Returns:
        Tuple of (set_parts, params).
    """
    set_parts = ["status = ?"]
    params: list = [status]

    if result_json is not None:
        set_parts.append("result_json = ?")
        params.append(result_json)

    if status == "running":
        set_parts.append(
            "analysis_started_at = COALESCE(analysis_started_at, CURRENT_TIMESTAMP)"
        )
    if status == "completed":
        set_parts.append("completed_at = COALESCE(completed_at, CURRENT_TIMESTAMP)")

    return set_parts, params


async def save_result(
    job_id: str,
    jenkins_url: str,
    status: str,
    result: dict | None = None,
) -> None:
    """Save or update an analysis result.

    Args:
        job_id: Unique identifier for the analysis job.
        jenkins_url: URL of the analyzed Jenkins build.
        status: Current status of the analysis.
        result: Optional result data to store.
    """
    logger.debug(f"Saving result for job_id: {job_id} (status: {status})")
    result_json = json.dumps(result) if result is not None else None
    async with aiosqlite.connect(DB_PATH) as db:
        # Insert the row if it doesn't exist yet (preserves created_at / analysis_started_at).
        await db.execute(
            """
            INSERT OR IGNORE INTO results (job_id, jenkins_url, status, result_json)
            VALUES (?, ?, ?, ?)
            """,
            (job_id, jenkins_url, status, result_json),
        )
        # Update the row (handles both fresh inserts and existing rows).
        set_parts, params = _build_status_update_clause(status, result_json)
        set_parts.insert(0, "jenkins_url = COALESCE(NULLIF(?, ''), jenkins_url)")
        params.insert(0, jenkins_url)
        params.append(job_id)
        sql = f"UPDATE results SET {', '.join(set_parts)} WHERE job_id = ?"
        await db.execute(sql, params)
        await db.commit()


async def update_status(
    job_id: str,
    status: str,
    result: dict | None = None,
) -> None:
    """Update the status of an existing analysis result.

    Unlike save_result, this uses UPDATE to preserve the original created_at timestamp.
    Only updates result_json when result is explicitly provided.

    Args:
        job_id: Unique identifier for the analysis job.
        status: New status for the analysis.
        result: Optional result data to store. When None, result_json is not modified.
    """
    logger.debug(f"Updating status for job_id: {job_id} (status: {status})")
    async with aiosqlite.connect(DB_PATH) as db:
        result_json = json.dumps(result) if result is not None else None
        set_parts, params = _build_status_update_clause(status, result_json)
        params.append(job_id)
        sql = f"UPDATE results SET {', '.join(set_parts)} WHERE job_id = ?"
        cursor = await db.execute(sql, params)

        if cursor.rowcount == 0:
            logger.warning(f"update_status: no row found for job_id={job_id}")
        await db.commit()


async def patch_result_json(
    job_id: str,
    patch_fn: Callable[[dict], None],
) -> None:
    """Atomically read-modify-write the ``result_json`` blob for *job_id*.

    The *patch_fn* is called with the parsed ``result`` dict and is expected
    to mutate it in place.  The read and write happen inside a single
    ``BEGIN IMMEDIATE`` transaction so concurrent patches are serialized
    by SQLite's write lock.

    If the row does not exist or ``result_json`` is empty, this is a no-op.
    """
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            cursor = await db.execute(
                "SELECT result_json FROM results WHERE job_id = ?", (job_id,)
            )
            row = await cursor.fetchone()
            if not row or not row[0]:
                await db.execute("ROLLBACK")
                return
            result_data = parse_result_json(row[0], job_id=job_id)
            if result_data is None:
                await db.execute("ROLLBACK")
                return
            patch_fn(result_data)
            await db.execute(
                "UPDATE results SET result_json = ? WHERE job_id = ?",
                (json.dumps(result_data), job_id),
            )
            await db.commit()
        except Exception:
            await db.execute("ROLLBACK")
            raise


async def get_result(job_id: str, *, strip_sensitive: bool = True) -> dict | None:
    """Retrieve an analysis result by job ID.

    Args:
        job_id: Unique identifier for the analysis job.
        strip_sensitive: When ``True`` (the default), credential fields
            inside ``request_params`` are removed so they never reach API
            consumers.  Pass ``False`` only when the caller needs to
            read-modify-write the full ``result_json`` back to the database.

    Returns:
        Result dictionary if found, None otherwise.
    """
    logger.debug(f"get_result: job_id={job_id}")
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            "SELECT * FROM results WHERE job_id = ?",
            (job_id,),
        )
        row = await cursor.fetchone()
        if row:
            logger.debug(
                f"get_result: job_id={job_id}, found=True, status={row['status']}"
            )
            parsed = parse_result_json(row["result_json"], job_id=job_id)
            if parsed and strip_sensitive:
                parsed = strip_sensitive_from_response(parsed)
            return {
                "job_id": row["job_id"],
                "jenkins_url": row["jenkins_url"],
                "status": row["status"],
                "result": parsed,
                "created_at": row["created_at"],
                "completed_at": row["completed_at"]
                if "completed_at" in row.keys()
                else None,
                "analysis_started_at": row["analysis_started_at"]
                if "analysis_started_at" in row.keys()
                else None,
            }
        logger.debug(f"get_result: job_id={job_id}, found=False")
        return None


async def list_results(limit: int = 50) -> list[dict]:
    """List recent analysis results.

    Args:
        limit: Maximum number of results to return.

    Returns:
        List of result summary dictionaries.
    """
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            """
            SELECT job_id, jenkins_url, status, created_at
            FROM results
            ORDER BY created_at DESC
            LIMIT ?
            """,
            (limit,),
        )
        rows = await cursor.fetchall()
        return [dict(row) for row in rows]


def count_all_failures(result_data: dict) -> int:
    """Count all failures including those in nested child job analyses.

    Walks the top-level ``failures`` list, then recursively counts failures in
    ``child_job_analyses`` (top-level key) and ``failed_children`` (nested key
    inside each child).

    Args:
        result_data: Parsed result dictionary from result_json.

    Returns:
        Total number of failures across all levels.
    """
    count = len(result_data.get("failures", []))
    for child in result_data.get("child_job_analyses", []):
        count += _count_child_failures_recursive(child)
    return count


def _count_child_failures_recursive(child: dict) -> int:
    """Recursively count failures in a child job analysis dict.

    Each child has a ``failures`` list and a ``failed_children`` list that can
    nest arbitrarily deep.

    Args:
        child: A single child job analysis dictionary.

    Returns:
        Total number of failures for this child and its descendants.
    """
    count = len(child.get("failures", []))
    for nested in child.get("failed_children", []):
        count += _count_child_failures_recursive(nested)
    return count


def _failure_to_history_row(
    failure: dict,
    job_id: str,
    job_name: str,
    build_number: int,
    child_job_name: str = "",
    child_build_number: int = 0,
    analyzed_at: str = "",
) -> tuple:
    """Convert a single failure dict to a failure_history row tuple.

    Args:
        analyzed_at: Timestamp for when the job was originally analyzed.
            If empty, the DB column default (CURRENT_TIMESTAMP) is used.
    """
    analysis = failure.get("analysis", {})
    classification = (
        "" if isinstance(analysis, str) else analysis.get("classification", "")
    )
    return (
        job_id,
        job_name,
        build_number,
        failure.get("test_name", ""),
        failure.get("error", ""),
        failure.get("error_signature", ""),
        classification,
        child_job_name,
        child_build_number,
        analyzed_at,
    )


def _extract_failures_for_history(
    result_data: dict,
    job_id: str,
    job_name: str,
    build_number: int,
    analyzed_at: str = "",
) -> list[tuple]:
    """Extract all failures from result_data into flat tuples for insertion.

    Walks top-level failures and recursively walks child_job_analyses
    and nested failed_children, using the same traversal as
    count_all_failures().

    Args:
        result_data: Parsed result dictionary from result_json.
        job_id: The job identifier.
        job_name: Top-level job name.
        build_number: Top-level build number.
        analyzed_at: Original analysis timestamp from results.created_at.
            Used during backfill to preserve historical chronology.

    Returns:
        List of tuples ready for INSERT:
        (job_id, job_name, build_number, test_name, error_message,
         error_signature, classification, child_job_name, child_build_number, analyzed_at)
    """
    rows: list[tuple] = []

    # Top-level failures (no child context)
    for f in result_data.get("failures", []):
        rows.append(
            _failure_to_history_row(
                f, job_id, job_name, build_number, analyzed_at=analyzed_at
            )
        )

    # Child job analyses (recursive)
    for child in result_data.get("child_job_analyses", []):
        _extract_child_failures_for_history(
            child, job_id, job_name, build_number, rows, analyzed_at=analyzed_at
        )

    return rows


def _extract_child_failures_for_history(
    child: dict,
    job_id: str,
    job_name: str,
    build_number: int,
    rows: list[tuple],
    analyzed_at: str = "",
) -> None:
    """Recursively extract failures from a child job analysis dict.

    Args:
        child: A single child job analysis dictionary.
        job_id: The top-level job identifier.
        job_name: Top-level job name.
        build_number: Top-level build number.
        rows: Accumulator list for insertion tuples.
        analyzed_at: Original analysis timestamp for historical chronology.
    """
    child_job = child.get("job_name", "")
    child_build = child.get("build_number", 0)

    for f in child.get("failures", []):
        rows.append(
            _failure_to_history_row(
                f,
                job_id,
                job_name,
                build_number,
                child_job,
                child_build,
                analyzed_at=analyzed_at,
            )
        )

    for nested in child.get("failed_children", []):
        _extract_child_failures_for_history(
            nested, job_id, job_name, build_number, rows, analyzed_at=analyzed_at
        )


async def populate_failure_history(
    job_id: str, result_data: dict, analyzed_at: str = ""
) -> None:
    """Populate failure_history from a completed analysis result.

    Extracts all failures (top-level and nested children) and inserts
    them into the failure_history table. Idempotent: skips if rows
    already exist for this job_id.

    Args:
        job_id: Unique identifier for the analysis job.
        result_data: Parsed result dictionary from result_json.
        analyzed_at: Original analysis timestamp (results.created_at).
            Used during backfill to preserve historical chronology.
            If empty, the DB default (CURRENT_TIMESTAMP) is used.
    """
    logger.debug(f"populate_failure_history: job_id={job_id}")
    job_name = result_data.get("job_name", "")
    build_number = result_data.get("build_number", 0)

    rows = _extract_failures_for_history(
        result_data, job_id, job_name, build_number, analyzed_at=analyzed_at
    )
    if not rows:
        logger.debug(
            f"populate_failure_history: job_id={job_id}, no failures to insert"
        )
        return

    async with aiosqlite.connect(DB_PATH) as db:
        # Delete existing rows for this job_id (supports re-analysis)
        await db.execute(
            "DELETE FROM failure_history WHERE job_id = ?",
            (job_id,),
        )

        # Use analyzed_at when provided (backfill), otherwise let the DB default apply
        if analyzed_at:
            await db.executemany(
                """
                INSERT INTO failure_history
                    (job_id, job_name, build_number, test_name, error_message,
                     error_signature, classification, child_job_name, child_build_number, analyzed_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                rows,
            )
        else:
            await db.executemany(
                """
                INSERT INTO failure_history
                    (job_id, job_name, build_number, test_name, error_message,
                     error_signature, classification, child_job_name, child_build_number)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                # Strip the analyzed_at field (last element) when not backfilling
                [row[:-1] for row in rows],
            )
        await db.commit()
        logger.info(
            f"Populated failure_history with {len(rows)} rows for job_id={job_id}"
        )


async def backfill_failure_history() -> None:
    """Backfill failure_history from existing completed results.

    Runs once at startup when the failure_history table is empty but
    the results table has completed rows. Uses the same extraction
    logic as populate_failure_history().
    """
    async with aiosqlite.connect(DB_PATH) as db:
        # Find completed results that are NOT yet in failure_history.
        # This makes the backfill resumable: if it crashes mid-way,
        # remaining jobs are picked up on next startup.
        cursor = await db.execute(
            "SELECT r.job_id, r.result_json, r.created_at FROM results r "
            "LEFT JOIN failure_history fh ON r.job_id = fh.job_id "
            "WHERE r.status = 'completed' AND r.result_json IS NOT NULL AND fh.job_id IS NULL"
        )
        rows = await cursor.fetchall()

    if not rows:
        logger.info(
            "All completed results already in failure_history, nothing to backfill"
        )
        return

    logger.info(f"Backfilling failure_history from {len(rows)} missing results")
    backfilled = 0
    for job_id, result_json_str, created_at in rows:
        result_data = parse_result_json(result_json_str, job_id=job_id)
        if result_data is None:
            continue
        # Skip completed results with zero failures — they have nothing to
        # insert into failure_history, so without this guard the LEFT JOIN
        # would find them "missing" on every startup and reprocess them.
        if count_all_failures(result_data) == 0:
            continue
        # Use the original created_at timestamp to preserve historical chronology
        await populate_failure_history(
            job_id, result_data, analyzed_at=created_at or ""
        )
        backfilled += 1

    logger.info(f"Backfill complete: processed {backfilled}/{len(rows)} results")


async def _get_failure_stats(
    db: aiosqlite.Connection,
    job_filter: str,
    params: list,
) -> tuple[int, str | None, str | None, str]:
    """Return (failure_count, first_seen, last_seen, last_classification).

    Args:
        db: Open aiosqlite connection with row_factory set.
        job_filter: SQL fragment for optional job_name/exclude_job_id filtering.
        params: Bind parameters matching the job_filter placeholders
                (first element is always test_name).
    """
    # Failure count — count distinct builds (job_ids) where this test
    # failed, not raw rows. A test can fail multiple times in different
    # child jobs within the same build, and counting rows would inflate
    # the failure count relative to total_runs (which counts builds).
    cursor = await db.execute(
        f"SELECT COUNT(DISTINCT job_id) FROM failure_history WHERE test_name = ?{job_filter}",
        params,
    )
    failures = (await cursor.fetchone())[0]

    if failures == 0:
        return 0, None, None, ""

    # First and last seen
    cursor = await db.execute(
        f"SELECT MIN(analyzed_at), MAX(analyzed_at) FROM failure_history WHERE test_name = ?{job_filter}",
        params,
    )
    row = await cursor.fetchone()
    first_seen = row[0]
    last_seen = row[1]

    # Last classification (most recent failure)
    cursor = await db.execute(
        f"SELECT classification FROM failure_history WHERE test_name = ?{job_filter} ORDER BY analyzed_at DESC, id DESC LIMIT 1",
        params,
    )
    last_classification = (await cursor.fetchone())[0] or ""

    return failures, first_seen, last_seen, last_classification


async def _get_classification_breakdown(
    db: aiosqlite.Connection,
    job_filter: str,
    params: list,
) -> dict[str, int]:
    """Return a dict mapping classification labels to their counts.

    Args:
        db: Open aiosqlite connection with row_factory set.
        job_filter: SQL fragment for optional job_name/exclude_job_id filtering.
        params: Bind parameters matching the job_filter placeholders
                (first element is always test_name).
    """
    cursor = await db.execute(
        f"SELECT classification, COUNT(*) FROM failure_history WHERE test_name = ?{job_filter} GROUP BY classification",
        params,
    )
    classifications: dict[str, int] = {}
    for row in await cursor.fetchall():
        if row[0]:
            classifications[row[0]] = row[1]
    return classifications


async def _get_related_comments(
    db: aiosqlite.Connection,
    test_name: str,
    signatures: set[str],
    exclude_job_id: str,
) -> list[dict]:
    """Return comments related to a test by name or error signature.

    Args:
        db: Open aiosqlite connection with row_factory set.
        test_name: Full test name to look up.
        signatures: Set of error_signature hashes from recent runs.
        exclude_job_id: Exclude comments from this job ID.
    """
    comment_conditions = ["test_name = ?"]
    comment_params: list = [test_name]
    if signatures:
        placeholders = ",".join("?" for _ in signatures)
        comment_conditions.append(f"error_signature IN ({placeholders})")
        comment_params.extend(signatures)

    comment_where = " OR ".join(comment_conditions)
    if exclude_job_id:
        comment_where = f"({comment_where}) AND job_id != ?"
        comment_params.append(exclude_job_id)
    cursor = await db.execute(
        f"SELECT comment, username, created_at FROM comments WHERE {comment_where} ORDER BY created_at DESC",
        comment_params,
    )
    return [dict(row) for row in await cursor.fetchall()]


async def get_test_history(
    test_name: str,
    limit: int = 20,
    job_name: str = "",
    exclude_job_id: str = "",
) -> dict:
    """Get pass/fail history for a specific test.

    Args:
        test_name: Full test name to look up.
        limit: Maximum number of recent runs to return.
        job_name: Optional filter by job name.
        exclude_job_id: Exclude results from this job ID.

    Returns:
        Dict with test_name, total_runs, failures, passes, failure_rate,
        first_seen, last_seen, last_classification, classifications,
        recent_runs, comments, consecutive_failures, note.
    """
    logger.debug(
        f"get_test_history: test_name={test_name}, limit={limit}, job_name={job_name}"
    )
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row

        # Build optional job_name filter
        job_filter = ""
        params: list = [test_name]
        if job_name:
            job_filter = " AND job_name = ?"
            params.append(job_name)
        if exclude_job_id:
            job_filter += " AND job_id != ?"
            params.append(exclude_job_id)

        failures, first_seen, last_seen, last_classification = await _get_failure_stats(
            db, job_filter, params
        )

        if failures == 0:
            return {
                "test_name": test_name,
                "total_runs": 0,
                "failures": 0,
                "passes": 0,
                "failure_rate": 0.0,
                "first_seen": None,
                "last_seen": None,
                "last_classification": "",
                "classifications": {},
                "recent_runs": [],
                "comments": [],
                "consecutive_failures": 0,
                "note": "No failure records found for this test.",
            }

        classifications = await _get_classification_breakdown(db, job_filter, params)

        # Recent runs (failures only, since we only track failures)
        cursor = await db.execute(
            f"""SELECT job_id, job_name, build_number, error_message, error_signature,
                       classification, child_job_name, child_build_number, analyzed_at
                FROM failure_history WHERE test_name = ?{job_filter}
                ORDER BY analyzed_at DESC, id DESC LIMIT ?""",
            [*params, limit],
        )
        recent_runs = [dict(row) for row in await cursor.fetchall()]

        # Total failure record count — computed with a separate unbounded query
        # so the value is not capped by the `limit` parameter used for recent_runs.
        # NOTE: failure_history only records failures (not passes), so this is
        # the total number of recorded failure events, not a true consecutive
        # streak (an intervening pass would not be detected).
        # Adding pass tracking is deferred to a future enhancement.
        cursor = await db.execute(
            f"SELECT COUNT(*) FROM failure_history WHERE test_name = ?{job_filter}",
            params,
        )
        consecutive_failures = (await cursor.fetchone())[0]

        # Count only completed results for the denominator so that
        # pending/running/failed analyses don't inflate total_runs.
        if job_name:
            total_query = (
                "SELECT COUNT(DISTINCT job_id) FROM results "
                "WHERE status = 'completed' "
                "AND json_extract(result_json, '$.job_name') = ?"
            )
            total_params: list = [job_name]
        else:
            # Without job_name filtering, pass count cannot be accurately derived.
            # failure_history only records failures, not total test executions,
            # so total_runs == failures and passes would always be 0 (100% failure).
            total_query = None
            total_params = []
        if total_query is not None:
            if exclude_job_id:
                total_query += " AND job_id != ?"
                total_params.append(exclude_job_id)
            cursor = await db.execute(total_query, total_params)
            total_runs = (await cursor.fetchone())[0]
            passes = max(0, total_runs - failures)
            failure_rate = round(failures / total_runs, 4) if total_runs > 0 else 0.0
        else:
            total_runs = failures
            passes = None
            failure_rate = None

        # Collect error signatures for comment lookup
        signatures = {
            r["error_signature"] for r in recent_runs if r.get("error_signature")
        }

        comments = await _get_related_comments(
            db, test_name, signatures, exclude_job_id
        )

    logger.debug(
        f"get_test_history: test_name={test_name}, failures={failures}, passes={passes}, recent_runs={len(recent_runs)}"
    )
    note = (
        "Pass count is estimated from total analyzed builds minus recorded failures."
        if passes is not None
        else "Pass/fail stats unavailable without job_name — failure_history only records failures."
    )
    return {
        "test_name": test_name,
        "total_runs": total_runs,
        "failures": failures,
        "passes": passes,
        "failure_rate": failure_rate,
        "first_seen": first_seen,
        "last_seen": last_seen,
        "last_classification": last_classification,
        "classifications": classifications,
        "recent_runs": recent_runs,
        "comments": comments,
        "consecutive_failures": consecutive_failures,
        "note": note,
    }


async def search_by_signature(signature: str, exclude_job_id: str = "") -> dict:
    """Find all tests that failed with the same error signature.

    Args:
        signature: Error signature hash to search for.
        exclude_job_id: Exclude results from this job ID.

    Returns:
        Dict with signature, total_occurrences, unique_tests, tests list,
        last_classification, and comments.
    """
    logger.debug(
        f"search_by_signature: signature={signature}, exclude_job_id={exclude_job_id}"
    )
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row

        # Build optional exclude filter
        exclude_filter = ""
        base_params: list = [signature]
        if exclude_job_id:
            exclude_filter = " AND job_id != ?"
            base_params.append(exclude_job_id)

        # Total occurrences
        cursor = await db.execute(
            f"SELECT COUNT(*) FROM failure_history WHERE error_signature = ?{exclude_filter}",
            base_params,
        )
        total_occurrences = (await cursor.fetchone())[0]

        if total_occurrences == 0:
            return {
                "signature": signature,
                "total_occurrences": 0,
                "unique_tests": 0,
                "tests": [],
                "last_classification": "",
                "comments": [],
            }

        # Tests with this signature and their occurrence counts
        cursor = await db.execute(
            f"SELECT test_name, COUNT(*) as occurrences FROM failure_history "
            f"WHERE error_signature = ?{exclude_filter} GROUP BY test_name ORDER BY occurrences DESC",
            base_params,
        )
        tests = [dict(row) for row in await cursor.fetchall()]
        unique_tests = len(tests)

        # Last classification
        cursor = await db.execute(
            f"SELECT classification FROM failure_history "
            f"WHERE error_signature = ?{exclude_filter} ORDER BY analyzed_at DESC, id DESC LIMIT 1",
            base_params,
        )
        last_classification = (await cursor.fetchone())[0] or ""

        # Comments related to this signature
        comments_query = (
            "SELECT comment, username, created_at FROM comments "
            "WHERE error_signature = ?"
        )
        comments_params: list[str] = [signature]
        if exclude_job_id:
            comments_query += " AND job_id != ?"
            comments_params.append(exclude_job_id)
        comments_query += " ORDER BY created_at DESC"
        cursor = await db.execute(comments_query, comments_params)
        comments = [dict(row) for row in await cursor.fetchall()]

    logger.debug(
        f"search_by_signature: signature={signature}, total_occurrences={total_occurrences}, unique_tests={unique_tests}"
    )
    return {
        "signature": signature,
        "total_occurrences": total_occurrences,
        "unique_tests": unique_tests,
        "tests": tests,
        "last_classification": last_classification,
        "comments": comments,
    }


async def get_job_stats(job_name: str, exclude_job_id: str = "") -> dict:
    """Get aggregate statistics for a specific job name.

    Args:
        job_name: The job name to get statistics for.
        exclude_job_id: Exclude results from this job ID.

    Returns:
        Dict with job_name, total_builds_analyzed, builds_with_failures,
        overall_failure_rate, most_common_failures, and recent_trend.
    """
    logger.debug(f"get_job_stats: job_name={job_name}, exclude_job_id={exclude_job_id}")
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row

        # Build optional exclude filter
        exclude_filter = ""
        exclude_params: list = []
        if exclude_job_id:
            exclude_filter = " AND job_id != ?"
            exclude_params = [exclude_job_id]

        # Total completed builds — count from results table (not failure_history)
        # so that builds with zero failures are included in the denominator.
        # Uses json_extract to match job_name stored in result_json.
        total_builds_query = (
            "SELECT COUNT(DISTINCT job_id) FROM results "
            "WHERE status = 'completed' AND "
            "json_extract(result_json, '$.job_name') = ?"
        )
        total_builds_params: list = [job_name]
        if exclude_job_id:
            total_builds_query += " AND job_id != ?"
            total_builds_params.append(exclude_job_id)
        cursor = await db.execute(total_builds_query, total_builds_params)
        total_builds = (await cursor.fetchone())[0]

        if total_builds == 0:
            return {
                "job_name": job_name,
                "total_builds_analyzed": 0,
                "builds_with_failures": 0,
                "overall_failure_rate": 0.0,
                "most_common_failures": [],
                "recent_trend": "stable",
            }

        # Builds with failures (distinct job_ids in failure_history for this job)
        cursor = await db.execute(
            f"SELECT COUNT(DISTINCT job_id) FROM failure_history WHERE job_name = ?{exclude_filter}",
            [job_name] + exclude_params,
        )
        builds_with_failures = (await cursor.fetchone())[0]

        overall_failure_rate = (
            builds_with_failures / total_builds if total_builds > 0 else 0.0
        )

        # Most common failures
        # GROUP BY test_name, classification to avoid non-deterministic
        # classification values when a test has been reclassified over time.
        cursor = await db.execute(
            f"SELECT test_name, COUNT(*) as count, classification "
            f"FROM failure_history WHERE job_name = ?{exclude_filter} "
            f"GROUP BY test_name, classification ORDER BY count DESC LIMIT 10",
            [job_name, *exclude_params],
        )
        most_common = [dict(row) for row in await cursor.fetchall()]

        # Recent trend: compare last 7 days vs previous 7 days
        now = datetime.now(tz=timezone.utc)
        seven_days_ago = (now - timedelta(days=7)).strftime("%Y-%m-%d %H:%M:%S")
        fourteen_days_ago = (now - timedelta(days=14)).strftime("%Y-%m-%d %H:%M:%S")

        cursor = await db.execute(
            f"SELECT COUNT(DISTINCT job_id) FROM failure_history "
            f"WHERE job_name = ? AND analyzed_at >= ?{exclude_filter}",
            [job_name, seven_days_ago] + exclude_params,
        )
        recent_failures = (await cursor.fetchone())[0]

        cursor = await db.execute(
            f"SELECT COUNT(DISTINCT job_id) FROM failure_history "
            f"WHERE job_name = ? AND analyzed_at >= ? AND analyzed_at < ?{exclude_filter}",
            [job_name, fourteen_days_ago, seven_days_ago] + exclude_params,
        )
        previous_failures = (await cursor.fetchone())[0]

        if recent_failures < previous_failures:
            recent_trend = "improving"
        elif recent_failures > previous_failures:
            recent_trend = "worsening"
        else:
            recent_trend = "stable"

    return {
        "job_name": job_name,
        "total_builds_analyzed": total_builds,
        "builds_with_failures": builds_with_failures,
        "overall_failure_rate": round(overall_failure_rate, 4),
        "most_common_failures": most_common,
        "recent_trend": recent_trend,
    }


DEFAULT_DASHBOARD_LIMIT = 500


async def list_results_for_dashboard(
    limit: int = DEFAULT_DASHBOARD_LIMIT,
) -> list[dict]:
    """List analysis results with summary data for dashboard display.

    Unlike list_results, this function also extracts key fields from result_json
    for any row that has a stored result (job_name, build_number, failure_count).

    Args:
        limit: Maximum number of results to return.  ``0`` means no limit —
            all rows are returned.  Defaults to :data:`DEFAULT_DASHBOARD_LIMIT`.

    Returns:
        List of result dictionaries enriched with summary data from result_json.
    """
    if limit < 0:
        raise ValueError("limit must be >= 0")

    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        sql = """
            SELECT r.job_id, r.jenkins_url, r.status, r.result_json,
                r.created_at, r.completed_at, r.analysis_started_at,
                (SELECT COUNT(*) FROM failure_reviews fr
                 WHERE fr.job_id = r.job_id AND fr.reviewed = 1) AS reviewed_count,
                (SELECT COUNT(*) FROM comments c
                 WHERE c.job_id = r.job_id) AS comment_count
            FROM results r
            ORDER BY r.created_at DESC
        """
        params: tuple = ()
        if limit > 0:
            sql += " LIMIT ?"
            params = (limit,)
        cursor = await db.execute(sql, params)
        rows = await cursor.fetchall()
        results = []
        for row in rows:
            entry: dict = {
                "job_id": row["job_id"],
                "jenkins_url": row["jenkins_url"],
                "status": row["status"],
                "created_at": row["created_at"],
                "completed_at": row["completed_at"]
                if "completed_at" in row.keys()
                else None,
                "analysis_started_at": row["analysis_started_at"]
                if "analysis_started_at" in row.keys()
                else None,
                "reviewed_count": row["reviewed_count"],
                "comment_count": row["comment_count"],
            }
            result_data = parse_result_json(row["result_json"], job_id=row["job_id"])
            if result_data:
                entry["job_name"] = result_data.get("job_name", "")
                if "build_number" in result_data:
                    entry["build_number"] = result_data["build_number"]
                entry["failure_count"] = count_all_failures(result_data)
                child_jobs = result_data.get("child_job_analyses", [])
                if child_jobs:
                    entry["child_job_count"] = len(child_jobs)
                if result_data.get("summary"):
                    entry["summary"] = result_data["summary"]
                if result_data.get("error"):
                    entry["error"] = result_data["error"]
            results.append(entry)
        return results


async def get_parent_job_name_for_test(test_name: str, job_id: str = "") -> str:
    """Look up the parent pipeline job name for a test from failure_history.

    Args:
        test_name: The test name to look up.
        job_id: When provided, scopes the lookup to a specific analysis job
                to avoid cross-job leakage.
    """
    async with aiosqlite.connect(DB_PATH) as db:
        if job_id:
            query = (
                "SELECT job_name FROM failure_history "
                "WHERE test_name = ? AND job_id = ? "
                "ORDER BY analyzed_at DESC, id DESC LIMIT 1"
            )
            params: tuple = (test_name, job_id)
        else:
            query = (
                "SELECT job_name FROM failure_history "
                "WHERE test_name = ? "
                "ORDER BY analyzed_at DESC, id DESC LIMIT 1"
            )
            params = (test_name,)
        cursor = await db.execute(query, params)
        row = await cursor.fetchone()
        return row[0] if row else ""


async def _mirror_classification_to_failure_history(
    db: aiosqlite.Connection,
    *,
    classification: str,
    test_name: str,
    job_name: str,
    child_build_number: int,
    job_id: str,
) -> None:
    """Mirror a classification into the failure_history table.

    When child_build_number is 0 and job_name is set, it acts as a wildcard:
    all builds (child_build_number > 0) for that job_name are updated.
    Otherwise, only the exact (test_name, job_name, child_build_number, job_id)
    row is updated.
    """
    if child_build_number == 0 and job_name:
        await db.execute(
            "UPDATE failure_history SET classification = ? "
            "WHERE test_name = ? AND child_job_name = ? AND child_build_number > 0 AND job_id = ?",
            [classification, test_name, job_name, job_id],
        )
    else:
        await db.execute(
            "UPDATE failure_history SET classification = ? "
            "WHERE test_name = ? AND child_job_name = ? AND child_build_number = ? AND job_id = ?",
            [classification, test_name, job_name, child_build_number, job_id],
        )


async def set_test_classification(
    test_name: str,
    classification: str,
    *,
    job_id: str,
    reason: str = "",
    job_name: str = "",
    parent_job_name: str = "",
    created_by: str = "",
    references: str = "",
    child_build_number: int = 0,
    visible: int = 1,
) -> int:
    """Set a classification for a test (e.g., FLAKY, REGRESSION).

    Can be set by the AI during analysis or by humans.

    Args:
        job_id: Required — scopes the classification to a specific analysis job.
        visible: Whether the classification is immediately visible.
            Set to 0 during AI analysis; revealed after analysis completes.
    """
    if classification not in HISTORY_CLASSIFICATIONS:
        raise ValueError(
            f"Invalid classification: {classification}. "
            f"Valid: {', '.join(sorted(HISTORY_CLASSIFICATIONS))}"
        )
    if visible not in (0, 1):
        raise ValueError(f"visible must be 0 or 1, got {visible}")
    if not job_id or not job_id.strip():
        raise ValueError("job_id is required for test classification")
    _validate_child_identifier_pairing(job_name, child_build_number)
    logger.debug(
        f"set_test_classification: test_name={test_name}, classification={classification}, "
        f"parent_job_name={parent_job_name}, job_id={job_id}, visible={visible}"
    )
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute(
            "INSERT INTO test_classifications (test_name, job_name, parent_job_name, classification, reason, references_info, created_by, job_id, child_build_number, visible) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                test_name,
                job_name,
                parent_job_name,
                classification,
                reason,
                references,
                created_by,
                job_id,
                child_build_number,
                visible,
            ),
        )

        # Mirror classification into failure_history so that filters on
        # failure_history.classification (used by get_all_failures, get_test_history)
        # reflect manual/AI reclassifications from test_classifications.
        # Only mirror when visible=1 to prevent hidden AI classifications from
        # leaking into failure_history before analysis completes.
        # When visible=0, make_classifications_visible() handles the mirror.
        if visible:
            await _mirror_classification_to_failure_history(
                db,
                classification=classification,
                test_name=test_name,
                job_name=job_name,
                child_build_number=child_build_number,
                job_id=job_id,
            )

        await db.commit()
        return cursor.lastrowid


async def get_test_classifications(
    test_name: str = "",
    classification: str = "",
    job_name: str = "",
    parent_job_name: str = "",
    job_id: str = "",
) -> list[dict]:
    """Get visible test classifications in the primary (override) domain.

    Only returns classifications with visible=1 **and** a primary
    classification (CODE ISSUE / PRODUCT BUG).  History-system labels
    (FLAKY, REGRESSION, etc.) written by ``set_test_classification()``
    are intentionally excluded because they belong to the history
    domain and are consumed via ``failure_history`` queries (e.g.
    ``get_all_failures()``, ``get_test_history()``), not here.

    The ``_PRIMARY_CLASSIFICATIONS_SQL`` filter is intentional: the
    ``POST /history/classify`` endpoint writes history labels that are
    never meant to appear in this reader.  History labels are consumed
    via ``GET /history/failures`` instead.

    During AI analysis, classifications are created with visible=0 and
    revealed after analysis completes via make_classifications_visible().
    """
    logger.debug(
        f"get_test_classifications: test_name={test_name!r}, classification={classification!r}, "
        f"job_name={job_name!r}, parent_job_name={parent_job_name!r}, job_id={job_id!r}"
    )
    conditions = [
        "tc.visible = 1",
        f"tc.classification IN {_PRIMARY_CLASSIFICATIONS_SQL}",
    ]
    params: list[str] = []

    if test_name:
        conditions.append("tc.test_name = ?")
        params.append(test_name)
    if classification:
        conditions.append("tc.classification = ?")
        params.append(classification)
    if job_name:
        conditions.append("tc.job_name = ?")
        params.append(job_name)
    if parent_job_name:
        conditions.append("tc.parent_job_name = ?")
        params.append(parent_job_name)
    if job_id:
        conditions.append("tc.job_id = ?")
        params.append(job_id)

    where = " AND ".join(conditions)

    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            f"SELECT tc.id, tc.test_name, tc.job_name, tc.parent_job_name, tc.classification, "
            f"tc.reason, tc.references_info, tc.created_by, tc.job_id, tc.child_build_number, tc.created_at "
            f"FROM test_classifications tc "
            f"WHERE {where} "
            f"ORDER BY tc.created_at DESC, tc.id DESC",
            params,
        )
        rows = await cursor.fetchall()
        result = [dict(row) for row in rows]
        logger.debug(f"get_test_classifications: count={len(result)}")
        return result


async def make_classifications_visible(job_id: str) -> None:
    """Make all classifications for a job visible after analysis completes.

    Also mirrors classifications into failure_history. The mirror is deferred
    from set_test_classification (which creates rows with visible=0 during
    analysis) to here so that failure_history doesn't leak hidden AI labels.
    """
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        # Fetch hidden classifications before flipping so we can mirror them.
        # ORDER BY created_at DESC ensures latest-wins when deduplicating
        # by (test_name, job_name, child_build_number) below.
        cursor = await db.execute(
            "SELECT tc.id, test_name, job_name, child_build_number, classification "
            "FROM test_classifications tc WHERE job_id = ? AND visible = 0 "
            "ORDER BY tc.created_at DESC, tc.id DESC",
            (job_id,),
        )
        all_rows = await cursor.fetchall()

        # Deduplicate: keep only the latest classification per key
        # (latest-wins, since we ordered by created_at DESC).
        seen: set[tuple[str, str, int]] = set()
        rows = []
        for row in all_rows:
            key = (row["test_name"], row["job_name"], row["child_build_number"])
            if key not in seen:
                seen.add(key)
                rows.append(row)

        await db.execute(
            "UPDATE test_classifications SET visible = 1 WHERE job_id = ? AND visible = 0",
            (job_id,),
        )

        # Mirror each newly-visible classification into failure_history
        for row in rows:
            await _mirror_classification_to_failure_history(
                db,
                classification=row["classification"],
                test_name=row["test_name"],
                job_name=row["job_name"],
                child_build_number=row["child_build_number"],
                job_id=job_id,
            )

        await db.commit()
    logger.debug(
        f"make_classifications_visible: job_id={job_id}, mirrored={len(rows)} classifications"
    )


async def get_all_failures(
    search: str = "",
    job_name: str = "",
    classification: str = "",
    limit: int = 50,
    offset: int = 0,
) -> dict:
    """Get paginated failure history with optional filters.

    Returns dict with 'failures' list and 'total' count.

    Args:
        search: Free-text search across test_name, error_message, and job_name.
        job_name: Exact match filter on job_name column.
        classification: Exact match filter on classification column.
        limit: Maximum number of rows to return.
        offset: Number of rows to skip for pagination.

    Returns:
        Dict with ``failures`` (list of row dicts) and ``total`` (int).
    """
    logger.debug(
        f"get_all_failures: search={search!r}, job_name={job_name!r}, classification={classification!r}, limit={limit}, offset={offset}"
    )
    conditions: list[str] = []
    params: list[str | int] = []

    if search:
        conditions.append(
            "(test_name LIKE ? OR error_message LIKE ? OR job_name LIKE ?)"
        )
        params.extend([f"%{search}%", f"%{search}%", f"%{search}%"])
    if job_name:
        conditions.append("job_name = ?")
        params.append(job_name)
    if classification:
        conditions.append("classification = ?")
        params.append(classification)

    where = " AND ".join(conditions) if conditions else "1=1"

    async with aiosqlite.connect(DB_PATH) as db:
        # Get total count
        cursor = await db.execute(
            f"SELECT COUNT(*) FROM failure_history WHERE {where}",
            params,
        )
        total = (await cursor.fetchone())[0]

        # Get paginated results
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            f"SELECT id, job_id, job_name, build_number, test_name, error_message, "
            f"error_signature, classification, child_job_name, child_build_number, analyzed_at "
            f"FROM failure_history WHERE {where} ORDER BY analyzed_at DESC, id DESC LIMIT ? OFFSET ?",
            [*params, limit, offset],
        )
        rows = await cursor.fetchall()
        logger.debug(f"get_all_failures: total={total}, returned={len(rows)}")
        return {
            "failures": [dict(row) for row in rows],
            "total": total,
        }


async def delete_job(job_id: str) -> bool:
    """Delete an analyzed job and all its related data."""
    async with aiosqlite.connect(DB_PATH) as db:
        # Delete from all related tables
        await db.execute("DELETE FROM comments WHERE job_id = ?", (job_id,))
        await db.execute("DELETE FROM failure_reviews WHERE job_id = ?", (job_id,))
        await db.execute("DELETE FROM failure_history WHERE job_id = ?", (job_id,))
        await db.execute("DELETE FROM test_classifications WHERE job_id = ?", (job_id,))
        cursor = await db.execute("DELETE FROM results WHERE job_id = ?", (job_id,))
        job_existed = cursor.rowcount > 0
        await db.commit()

        return job_existed


async def override_classification(
    job_id: str,
    test_name: str,
    classification: str,
    child_job_name: str = "",
    child_build_number: int = 0,
    username: str = "",
    parent_job_name: str = "",
) -> list[str]:
    """Override the classification of a failure in failure_history.

    Updates ALL failure_history rows sharing the same error_signature
    (within the same job) so that grouped failures stay in sync.
    Also inserts a test_classifications entry so the AI can learn from
    human overrides.

    Args:
        job_id: The analysis job ID.
        test_name: Fully qualified test name (representative test from the group).
        classification: New classification ("CODE ISSUE" or "PRODUCT BUG").
        child_job_name: Child job name (for pipeline analyses).
        child_build_number: Child build number.
        username: User who made the override.
        parent_job_name: Parent pipeline job name (for test_classifications).

    Returns:
        List of all test names in the affected signature group.
    """
    logger.debug(
        f"override_classification: job_id={job_id}, test_name={test_name}, "
        f"classification={classification}, username={username}"
    )
    _validate_child_identifier_pairing(child_job_name, child_build_number)
    if child_job_name and child_build_number == 0:
        raise ValueError(
            "override_classification requires child_build_number when child_job_name is set"
        )
    async with aiosqlite.connect(DB_PATH) as db:
        # Look up the error_signature for this test so we can update
        # ALL tests in the same group (same signature, same job).
        # Scope by child context when provided so that identically-named
        # tests in different child jobs resolve the correct signature.
        sig_query = (
            "SELECT error_signature FROM failure_history "
            "WHERE job_id = ? AND test_name = ?"
        )
        sig_params: list = [job_id, test_name]
        if child_job_name:
            sig_query += " AND child_job_name = ? AND child_build_number = ?"
            sig_params.extend([child_job_name, child_build_number])
        else:
            sig_query += " AND child_job_name = '' AND child_build_number = 0"
        sig_query += " LIMIT 1"

        cursor = await db.execute(sig_query, sig_params)
        row = await cursor.fetchone()
        error_signature = row[0] if row and row[0] else ""

        if error_signature:
            # Update ALL tests sharing the same error_signature in this job
            if child_job_name:
                await db.execute(
                    """UPDATE failure_history
                       SET classification = ?
                       WHERE job_id = ? AND error_signature = ?
                       AND child_job_name = ? AND child_build_number = ?""",
                    (
                        classification,
                        job_id,
                        error_signature,
                        child_job_name,
                        child_build_number,
                    ),
                )
            else:
                await db.execute(
                    """UPDATE failure_history
                       SET classification = ?
                       WHERE job_id = ? AND error_signature = ?
                       AND child_job_name = '' AND child_build_number = 0""",
                    (classification, job_id, error_signature),
                )
        else:
            # No signature -- fall back to exact test_name match
            if child_job_name:
                await db.execute(
                    """UPDATE failure_history
                       SET classification = ?
                       WHERE job_id = ? AND test_name = ?
                       AND child_job_name = ? AND child_build_number = ?""",
                    (
                        classification,
                        job_id,
                        test_name,
                        child_job_name,
                        child_build_number,
                    ),
                )
            else:
                await db.execute(
                    """UPDATE failure_history
                       SET classification = ?
                       WHERE job_id = ? AND test_name = ?
                       AND child_job_name = '' AND child_build_number = 0""",
                    (classification, job_id, test_name),
                )

        # Find all test_names in this signature group
        if error_signature:
            if child_job_name:
                group_cursor = await db.execute(
                    "SELECT DISTINCT test_name FROM failure_history "
                    "WHERE job_id = ? AND error_signature = ? "
                    "AND child_job_name = ? AND child_build_number = ?",
                    (job_id, error_signature, child_job_name, child_build_number),
                )
            else:
                group_cursor = await db.execute(
                    "SELECT DISTINCT test_name FROM failure_history "
                    "WHERE job_id = ? AND error_signature = ? "
                    "AND child_job_name = '' AND child_build_number = 0",
                    (job_id, error_signature),
                )
            group_tests = [row[0] for row in await group_cursor.fetchall()]
        else:
            group_tests = [test_name]

        # Persist override for ALL tests in the group
        for t in group_tests:
            await db.execute(
                "INSERT INTO test_classifications "
                "(test_name, job_name, parent_job_name, job_id, classification, "
                "reason, created_by, visible, child_build_number) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?)",
                (
                    t,
                    child_job_name,
                    parent_job_name,
                    job_id,
                    classification,
                    "User override",
                    username,
                    child_build_number,
                ),
            )

        await db.commit()
    logger.info(
        f"Classification overridden: job_id={job_id}, test_name={test_name}, "
        f"classification={classification}, by={username or 'unknown'}"
    )
    return group_tests


async def get_effective_classification(
    job_id: str,
    test_name: str,
    child_job_name: str = "",
    child_build_number: int = 0,
) -> str:
    """Return the primary classification override for a failure.

    Only considers the primary override domain: ``CODE ISSUE`` and
    ``PRODUCT BUG``.  History-system classifications (``FLAKY``,
    ``REGRESSION``, ``KNOWN_BUG``, etc.) stored in
    ``test_classifications`` are intentionally ignored.

    Checks ``test_classifications`` first for a visible user override
    (latest by ``id``, limited to ``CODE ISSUE`` / ``PRODUCT BUG``).
    If no matching override exists, falls back to the
    ``failure_history`` row.  This two-step lookup ensures overrides
    survive even when ``failure_history`` rows are missing or rebuilt
    from ``result_json``.

    Returns:
        The classification string (``"CODE ISSUE"`` or
        ``"PRODUCT BUG"``), or ``""`` if no row exists in either table.
    """
    _child_job_name = child_job_name or ""
    _child_build_number = child_build_number or 0

    async with aiosqlite.connect(DB_PATH) as db:
        # 1. Prefer visible override from test_classifications
        override_row = await (
            await db.execute(
                "SELECT classification FROM test_classifications"
                " WHERE test_name = ? AND job_id = ? AND job_name = ?"
                " AND child_build_number = ? AND visible = 1"
                f" AND classification IN {_PRIMARY_CLASSIFICATIONS_SQL}"
                " ORDER BY id DESC LIMIT 1",
                [test_name, job_id, _child_job_name, _child_build_number],
            )
        ).fetchone()
        if override_row and override_row[0]:
            return override_row[0]

        # 2. Fall back to failure_history (same domain filter so that
        #    mirrored history-system labels like FLAKY don't leak through)
        fh_query = (
            "SELECT classification FROM failure_history"
            " WHERE job_id = ? AND test_name = ?"
            f" AND classification IN {_PRIMARY_CLASSIFICATIONS_SQL}"
        )
        fh_params: list = [job_id, test_name]
        if child_job_name:
            fh_query += " AND child_job_name = ? AND child_build_number = ?"
            fh_params.extend([child_job_name, child_build_number])
        else:
            fh_query += " AND child_job_name = '' AND child_build_number = 0"
        fh_query += " LIMIT 1"

        fh_row = await (await db.execute(fh_query, fh_params)).fetchone()
        return fh_row[0] if fh_row and fh_row[0] else ""


async def mark_stale_results_failed() -> list[dict]:
    """Mark orphaned pending/running jobs as failed. Return waiting jobs for resumption.

    Pending and running jobs have lost their background task and cannot recover,
    so they are marked as failed.  Waiting jobs were polling Jenkins and can be
    safely resumed by re-creating their background task.

    Returns:
        List of dicts with ``job_id`` and ``result_data`` for each waiting job.
    """
    waiting_jobs: list[dict] = []
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row

        # Mark pending/running as failed (background task is gone)
        cursor = await db.execute(
            "UPDATE results SET status = 'failed' "
            "WHERE status IN ('pending', 'running')"
        )
        if cursor.rowcount > 0:
            logger.warning(
                f"Marked {cursor.rowcount} stale pending/running job(s) as failed on startup"
            )

        # Collect waiting jobs for resumption instead of failing them
        cursor = await db.execute(
            "SELECT job_id, result_json FROM results WHERE status = 'waiting'"
        )
        rows = await cursor.fetchall()
        for row in rows:
            if row["result_json"]:
                result_data = parse_result_json(
                    row["result_json"], job_id=row["job_id"]
                )
                stored_params = (
                    result_data.get("request_params") if result_data else None
                )
                is_resumable = (
                    result_data is not None
                    and isinstance(stored_params, dict)
                    and bool(stored_params)
                    and "job_name" in result_data
                    and "build_number" in result_data
                )
                if is_resumable:
                    waiting_jobs.append(
                        {
                            "job_id": row["job_id"],
                            "result_data": result_data,
                        }
                    )
                else:
                    logger.warning(
                        f"Marking unrecoverable waiting job {row['job_id']} as failed"
                    )
                    await db.execute(
                        "UPDATE results SET status = 'failed' WHERE job_id = ?",
                        (row["job_id"],),
                    )

        # Mark waiting jobs without result_json as failed (unrecoverable)
        cursor = await db.execute(
            "UPDATE results SET status = 'failed' "
            "WHERE status = 'waiting' AND (result_json IS NULL OR result_json = '')"
        )
        if cursor.rowcount > 0:
            logger.warning(
                f"Marked {cursor.rowcount} unrecoverable waiting job(s) as failed (missing result data)"
            )

        await db.commit()

    if waiting_jobs:
        logger.info(f"Found {len(waiting_jobs)} waiting job(s) to resume")

    return waiting_jobs


async def get_ai_configs() -> list[dict]:
    """Get distinct AI provider/model pairs from completed analysis results.

    Queries the results table for unique (ai_provider, ai_model) combinations
    from successfully completed analyses. These represent known-working configs.

    Returns:
        List of dicts with 'ai_provider' and 'ai_model' keys.
    """
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute(
            """
            SELECT DISTINCT
                json_extract(result_json, '$.ai_provider') as ai_provider,
                json_extract(result_json, '$.ai_model') as ai_model
            FROM results
            WHERE status = 'completed'
              AND json_extract(result_json, '$.ai_provider') IS NOT NULL
              AND json_extract(result_json, '$.ai_provider') != ''
              AND json_extract(result_json, '$.ai_model') IS NOT NULL
              AND json_extract(result_json, '$.ai_model') != ''
            ORDER BY ai_provider, ai_model
            """
        )
        rows = await cursor.fetchall()
        return [{"ai_provider": row[0], "ai_model": row[1]} for row in rows]
