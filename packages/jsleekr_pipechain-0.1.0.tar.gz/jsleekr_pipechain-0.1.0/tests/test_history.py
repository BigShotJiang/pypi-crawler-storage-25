"""Tests for pipechain.history module."""

import pytest
from pipechain.history import RunRecord, ExecutionHistory
from pipechain.result import PipelineResult, StepResult, StepStatus


def _make_result(name="test", success=True):
    steps = [StepResult(step_name="s1", status=StepStatus.SUCCESS if success else StepStatus.FAILED,
                        duration_ms=50.0, error=ValueError("fail") if not success else None)]
    return PipelineResult(pipeline_name=name, step_results=steps, total_duration_ms=100.0,
                         error=ValueError("fail") if not success else None)


class TestRunRecord:
    def test_to_dict(self):
        r = RunRecord(pipeline_name="test", run_id="r1", started_at=1.0)
        d = r.to_dict()
        assert d["pipeline_name"] == "test"
        assert d["run_id"] == "r1"

    def test_from_dict(self):
        d = {"pipeline_name": "test", "run_id": "r1", "started_at": 1.0}
        r = RunRecord.from_dict(d)
        assert r.pipeline_name == "test"
        assert r.run_id == "r1"

    def test_roundtrip(self):
        r = RunRecord(pipeline_name="test", run_id="r1", started_at=1.0,
                      success=True, total_steps=3)
        d = r.to_dict()
        r2 = RunRecord.from_dict(d)
        assert r2.pipeline_name == r.pipeline_name
        assert r2.success == r.success


class TestExecutionHistory:
    def test_record_run(self):
        h = ExecutionHistory()
        result = _make_result()
        record = h.record_run(result, run_id="test_1")
        assert record.success is True
        assert h.total_runs == 1

    def test_get_runs(self):
        h = ExecutionHistory()
        h.record_run(_make_result(name="a"), run_id="r1")
        h.record_run(_make_result(name="b"), run_id="r2")
        assert len(h.get_runs()) == 2

    def test_get_runs_filtered(self):
        h = ExecutionHistory()
        h.record_run(_make_result(name="a"), run_id="r1")
        h.record_run(_make_result(name="b"), run_id="r2")
        assert len(h.get_runs(pipeline_name="a")) == 1

    def test_get_runs_success_only(self):
        h = ExecutionHistory()
        h.record_run(_make_result(success=True), run_id="r1")
        h.record_run(_make_result(success=False), run_id="r2")
        assert len(h.get_runs(success_only=True)) == 1

    def test_get_runs_limit(self):
        h = ExecutionHistory()
        for i in range(10):
            h.record_run(_make_result(), run_id=f"r{i}")
        assert len(h.get_runs(limit=5)) == 5

    def test_get_run(self):
        h = ExecutionHistory()
        h.record_run(_make_result(), run_id="specific")
        r = h.get_run("specific")
        assert r is not None
        assert r.run_id == "specific"

    def test_get_run_not_found(self):
        h = ExecutionHistory()
        assert h.get_run("nope") is None

    def test_latest(self):
        h = ExecutionHistory()
        h.record_run(_make_result(), run_id="r1")
        h.record_run(_make_result(), run_id="r2")
        assert h.latest().run_id == "r2"

    def test_latest_filtered(self):
        h = ExecutionHistory()
        h.record_run(_make_result(name="a"), run_id="r1")
        h.record_run(_make_result(name="b"), run_id="r2")
        assert h.latest(pipeline_name="a").run_id == "r1"

    def test_latest_empty(self):
        h = ExecutionHistory()
        assert h.latest() is None

    def test_clear_all(self):
        h = ExecutionHistory()
        h.record_run(_make_result(), run_id="r1")
        count = h.clear()
        assert count == 1
        assert h.total_runs == 0

    def test_clear_specific(self):
        h = ExecutionHistory()
        h.record_run(_make_result(name="a"), run_id="r1")
        h.record_run(_make_result(name="b"), run_id="r2")
        count = h.clear(pipeline_name="a")
        assert count == 1
        assert h.total_runs == 1

    def test_max_records(self):
        h = ExecutionHistory(max_records=5)
        for i in range(10):
            h.record_run(_make_result(), run_id=f"r{i}")
        assert h.total_runs == 5

    def test_persistence(self, tmp_path):
        f = str(tmp_path / "history.json")
        h1 = ExecutionHistory(history_file=f)
        h1.record_run(_make_result(), run_id="persist")

        h2 = ExecutionHistory(history_file=f)
        assert h2.total_runs == 1
        assert h2.get_run("persist") is not None

    def test_failed_run_details(self):
        h = ExecutionHistory()
        r = _make_result(success=False)
        record = h.record_run(r, run_id="fail")
        assert record.success is False
        assert record.error is not None
        assert record.failed_steps == 1

    def test_step_details_recorded(self):
        h = ExecutionHistory()
        record = h.record_run(_make_result(), run_id="detail")
        assert len(record.step_details) == 1
        assert record.step_details[0]["name"] == "s1"
