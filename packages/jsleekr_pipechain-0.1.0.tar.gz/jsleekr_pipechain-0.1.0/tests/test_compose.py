"""Tests for pipechain.compose module."""

import pytest
from pipechain.compose import compose, merge
from pipechain.pipeline import Pipeline
from pipechain.step import Step
from pipechain.context import Context


class TestCompose:
    def test_sequential_composition(self):
        p1 = Pipeline("step1")
        p1.add_step(Step("a", lambda ctx: ctx.set("val", 1) or 1))

        p2 = Pipeline("step2")
        p2.add_step(Step("b", lambda ctx: ctx.set("val", ctx.get("val", 0) + 10) or 11))

        composed = compose(p1, p2)
        ctx = Context()
        result = composed.run(context=ctx)
        assert result.success
        assert ctx.get("val") == 11

    def test_compose_name(self):
        p1 = Pipeline("a")
        p2 = Pipeline("b")
        composed = compose(p1, p2, name="custom")
        assert composed.name == "custom"

    def test_compose_default_name(self):
        p1 = Pipeline("a")
        p2 = Pipeline("b")
        composed = compose(p1, p2)
        assert "composed" in composed.name

    def test_compose_failure_propagates(self):
        p1 = Pipeline("ok")
        p1.add_step(Step("a", lambda ctx: 1))

        p2 = Pipeline("fail")
        p2.add_step(Step("b", lambda ctx: (_ for _ in ()).throw(ValueError("boom"))))

        composed = compose(p1, p2)
        result = composed.run()
        assert not result.success

    def test_compose_empty_pipelines(self):
        p1 = Pipeline("empty1")
        p2 = Pipeline("empty2")
        composed = compose(p1, p2)
        result = composed.run()
        assert result.success

    def test_compose_three_pipelines(self):
        p1 = Pipeline("p1")
        p1.add_step(Step("a", lambda ctx: ctx.set("seq", [1]) or 1))

        p2 = Pipeline("p2")
        p2.add_step(Step("b", lambda ctx: ctx.get("seq", []).append(2) or 2))

        p3 = Pipeline("p3")
        p3.add_step(Step("c", lambda ctx: ctx.get("seq", []).append(3) or 3))

        composed = compose(p1, p2, p3)
        ctx = Context()
        result = composed.run(context=ctx)
        assert result.success
        assert ctx.get("seq") == [1, 2, 3]

    def test_compose_shared_context(self):
        p1 = Pipeline("p1")
        p1.add_step(Step("a", lambda ctx: ctx.set("from_p1", True) or True))

        p2 = Pipeline("p2")
        p2.add_step(Step("b", lambda ctx: ctx.get("from_p1")))

        composed = compose(p1, p2)
        ctx = Context()
        result = composed.run(context=ctx)
        assert result.success


class TestMerge:
    def test_parallel_merge(self):
        p1 = Pipeline("p1")
        p1.add_step(Step("a", lambda ctx: ctx.set("p1_done", True) or 1))

        p2 = Pipeline("p2")
        p2.add_step(Step("b", lambda ctx: ctx.set("p2_done", True) or 2))

        merged = merge(p1, p2)
        ctx = Context()
        result = merged.run(context=ctx)
        assert result.success
        assert ctx.get("p1_done") is True
        assert ctx.get("p2_done") is True

    def test_merge_name(self):
        p1 = Pipeline("a")
        p2 = Pipeline("b")
        merged = merge(p1, p2, name="custom")
        assert merged.name == "custom"

    def test_merge_default_name(self):
        p1 = Pipeline("a")
        p2 = Pipeline("b")
        merged = merge(p1, p2)
        assert "merged" in merged.name

    def test_merge_failure(self):
        p1 = Pipeline("ok")
        p1.add_step(Step("a", lambda ctx: 1))

        p2 = Pipeline("fail")
        p2.add_step(Step("b", lambda ctx: (_ for _ in ()).throw(ValueError("boom"))))

        merged = merge(p1, p2)
        result = merged.run()
        assert not result.success

    def test_merge_all_independent(self):
        merged = merge(Pipeline("a"), Pipeline("b"), Pipeline("c"))
        levels = merged.execution_plan()
        # All sub-pipelines should be in one level (parallel)
        assert len(levels) == 1
