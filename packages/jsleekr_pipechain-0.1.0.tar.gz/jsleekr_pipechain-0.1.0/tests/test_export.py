"""Tests for pipechain.export module."""

import pytest
from pipechain.export import to_dot, to_mermaid, to_ascii, to_json_graph
from pipechain.pipeline import Pipeline
from pipechain.step import Step
from pipechain.retry import RetryPolicy


@pytest.fixture
def sample_pipeline():
    p = Pipeline("etl_demo")
    p.add_step(Step("extract", lambda ctx: None, tags=["io"]))
    p.add_step(Step("transform", lambda ctx: None, depends_on=["extract"], tags=["cpu"]))
    p.add_step(Step("validate", lambda ctx: None, depends_on=["extract"]))
    p.add_step(Step("load", lambda ctx: None, depends_on=["transform", "validate"],
                     cache_key="load_v1", retry_policy=RetryPolicy(max_retries=3)))
    return p


class TestToDot:
    def test_basic(self, sample_pipeline):
        dot = to_dot(sample_pipeline)
        assert "digraph" in dot
        assert "etl_demo" in dot
        assert "extract" in dot
        assert "transform" in dot
        assert "->" in dot

    def test_attributes(self, sample_pipeline):
        dot = to_dot(sample_pipeline)
        assert "tags:" in dot
        assert "retries:" in dot
        assert "cached" in dot

    def test_direction(self, sample_pipeline):
        dot = to_dot(sample_pipeline, rankdir="LR")
        assert "rankdir=LR" in dot

    def test_empty_pipeline(self):
        p = Pipeline("empty")
        dot = to_dot(p)
        assert "digraph" in dot

    def test_no_deps(self):
        p = Pipeline("test")
        p.add_step(Step("a", lambda ctx: None))
        p.add_step(Step("b", lambda ctx: None))
        dot = to_dot(p)
        assert "->" not in dot


class TestToMermaid:
    def test_basic(self, sample_pipeline):
        md = to_mermaid(sample_pipeline)
        assert "graph TB" in md
        assert "extract" in md
        assert "-->" in md

    def test_direction(self, sample_pipeline):
        md = to_mermaid(sample_pipeline, direction="LR")
        assert "graph LR" in md

    def test_tags(self, sample_pipeline):
        md = to_mermaid(sample_pipeline)
        assert "#io" in md
        assert "#cpu" in md

    def test_cached(self, sample_pipeline):
        md = to_mermaid(sample_pipeline)
        assert "cached" in md

    def test_empty_pipeline(self):
        p = Pipeline("empty")
        md = to_mermaid(p)
        assert "graph TB" in md


class TestToAscii:
    def test_basic(self, sample_pipeline):
        ascii_art = to_ascii(sample_pipeline)
        assert "etl_demo" in ascii_art
        assert "extract" in ascii_art


class TestToJsonGraph:
    def test_basic(self, sample_pipeline):
        g = to_json_graph(sample_pipeline)
        assert g["name"] == "etl_demo"
        assert len(g["nodes"]) == 4
        assert len(g["edges"]) == 4

    def test_node_attributes(self, sample_pipeline):
        g = to_json_graph(sample_pipeline)
        load_node = next(n for n in g["nodes"] if n["id"] == "load")
        assert load_node["has_cache"] is True
        assert load_node["has_retry"] is True

    def test_edge_structure(self, sample_pipeline):
        g = to_json_graph(sample_pipeline)
        sources = {e["source"] for e in g["edges"]}
        targets = {e["target"] for e in g["edges"]}
        assert "extract" in sources
        assert "load" in targets

    def test_empty_pipeline(self):
        p = Pipeline("empty")
        g = to_json_graph(p)
        assert g["nodes"] == []
        assert g["edges"] == []

    def test_node_tags(self, sample_pipeline):
        g = to_json_graph(sample_pipeline)
        extract = next(n for n in g["nodes"] if n["id"] == "extract")
        assert "io" in extract["tags"]
