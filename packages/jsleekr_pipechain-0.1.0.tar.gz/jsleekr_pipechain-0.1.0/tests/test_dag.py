"""Tests for pipechain.dag module."""

import pytest
from pipechain.dag import DAG, CycleError, MissingDependencyError


class TestDAGBasic:
    def test_add_node(self):
        d = DAG()
        d.add_node("a")
        assert "a" in d.nodes

    def test_add_edge(self):
        d = DAG()
        d.add_edge("b", "a")  # b depends on a
        assert "a" in d.nodes
        assert "b" in d.nodes
        assert d.edge_count == 1

    def test_dependencies(self):
        d = DAG()
        d.add_edge("b", "a")
        assert d.dependencies("b") == {"a"}
        assert d.dependencies("a") == set()

    def test_dependents(self):
        d = DAG()
        d.add_edge("b", "a")
        assert d.dependents("a") == {"b"}
        assert d.dependents("b") == set()

    def test_all_dependencies(self):
        d = DAG()
        d.add_edge("c", "b")
        d.add_edge("b", "a")
        assert d.all_dependencies("c") == {"a", "b"}

    def test_node_count(self):
        d = DAG()
        d.add_node("a")
        d.add_node("b")
        assert d.node_count == 2

    def test_repr(self):
        d = DAG()
        d.add_node("a")
        assert "DAG" in repr(d)


class TestDAGValidation:
    def test_valid_dag(self):
        d = DAG()
        d.add_edge("b", "a")
        d.add_edge("c", "b")
        d.validate()  # Should not raise

    def test_cycle_detection(self):
        d = DAG()
        d.add_edge("a", "b")
        d.add_edge("b", "a")
        with pytest.raises(CycleError):
            d.validate()

    def test_cycle_three_nodes(self):
        d = DAG()
        d.add_edge("a", "b")
        d.add_edge("b", "c")
        d.add_edge("c", "a")
        with pytest.raises(CycleError):
            d.validate()

    def test_self_loop(self):
        d = DAG()
        d.add_edge("a", "a")
        with pytest.raises(CycleError):
            d.validate()

    def test_missing_dependency(self):
        d = DAG()
        d.add_node("a")
        d._edges["a"].add("nonexistent")
        with pytest.raises(MissingDependencyError):
            d.validate()

    def test_cycle_error_message(self):
        try:
            raise CycleError(["a", "b", "a"])
        except CycleError as e:
            assert e.cycle == ["a", "b", "a"]
            assert "Cycle" in str(e)

    def test_missing_dep_error_message(self):
        try:
            raise MissingDependencyError("a", "b")
        except MissingDependencyError as e:
            assert e.step == "a"
            assert e.missing == "b"


class TestTopologicalSort:
    def test_linear(self):
        d = DAG()
        d.add_edge("c", "b")
        d.add_edge("b", "a")
        order = d.topological_sort()
        assert order.index("a") < order.index("b")
        assert order.index("b") < order.index("c")

    def test_diamond(self):
        d = DAG()
        d.add_edge("d", "b")
        d.add_edge("d", "c")
        d.add_edge("b", "a")
        d.add_edge("c", "a")
        order = d.topological_sort()
        assert order.index("a") < order.index("b")
        assert order.index("a") < order.index("c")
        assert order.index("b") < order.index("d")
        assert order.index("c") < order.index("d")

    def test_independent_nodes(self):
        d = DAG()
        d.add_node("a")
        d.add_node("b")
        d.add_node("c")
        order = d.topological_sort()
        assert set(order) == {"a", "b", "c"}

    def test_single_node(self):
        d = DAG()
        d.add_node("a")
        assert d.topological_sort() == ["a"]

    def test_empty(self):
        d = DAG()
        assert d.topological_sort() == []


class TestExecutionLevels:
    def test_linear_chain(self):
        d = DAG()
        d.add_edge("c", "b")
        d.add_edge("b", "a")
        levels = d.execution_levels()
        assert levels == [["a"], ["b"], ["c"]]

    def test_parallel_steps(self):
        d = DAG()
        d.add_node("a")
        d.add_node("b")
        d.add_node("c")
        levels = d.execution_levels()
        assert len(levels) == 1
        assert set(levels[0]) == {"a", "b", "c"}

    def test_diamond(self):
        d = DAG()
        d.add_edge("d", "b")
        d.add_edge("d", "c")
        d.add_edge("b", "a")
        d.add_edge("c", "a")
        levels = d.execution_levels()
        assert levels[0] == ["a"]
        assert set(levels[1]) == {"b", "c"}
        assert levels[2] == ["d"]

    def test_fan_out(self):
        d = DAG()
        d.add_edge("b", "a")
        d.add_edge("c", "a")
        d.add_edge("d", "a")
        levels = d.execution_levels()
        assert levels[0] == ["a"]
        assert set(levels[1]) == {"b", "c", "d"}

    def test_fan_in(self):
        d = DAG()
        d.add_edge("d", "a")
        d.add_edge("d", "b")
        d.add_edge("d", "c")
        levels = d.execution_levels()
        assert set(levels[0]) == {"a", "b", "c"}
        assert levels[1] == ["d"]

    def test_complex_dag(self):
        d = DAG()
        d.add_edge("b", "a")
        d.add_edge("c", "a")
        d.add_edge("d", "b")
        d.add_edge("d", "c")
        d.add_edge("e", "c")
        d.add_edge("f", "d")
        d.add_edge("f", "e")
        levels = d.execution_levels()
        assert levels[0] == ["a"]
        assert set(levels[1]) == {"b", "c"}
        assert set(levels[2]) == {"d", "e"}
        assert levels[3] == ["f"]

    def test_empty(self):
        d = DAG()
        assert d.execution_levels() == []
