"""Tests for pipechain.checkpoint module."""

import pytest
from pipechain.checkpoint import Checkpoint


class TestCheckpoint:
    @pytest.fixture
    def cp_dir(self, tmp_path):
        return str(tmp_path / "checkpoints")

    def test_start_run(self, cp_dir):
        cp = Checkpoint(cp_dir)
        run_id = cp.start_run("test_pipe")
        assert run_id is not None
        assert "test_pipe" in run_id

    def test_custom_run_id(self, cp_dir):
        cp = Checkpoint(cp_dir)
        run_id = cp.start_run("test_pipe", run_id="custom_123")
        assert run_id == "custom_123"

    def test_mark_completed(self, cp_dir):
        cp = Checkpoint(cp_dir)
        cp.start_run("test")
        cp.mark_completed("s1")
        assert cp.is_completed("s1")
        assert not cp.is_completed("s2")

    def test_mark_failed(self, cp_dir):
        cp = Checkpoint(cp_dir)
        cp.start_run("test")
        cp.mark_failed("s1")
        assert cp.is_failed("s1")

    def test_completed_clears_failed(self, cp_dir):
        cp = Checkpoint(cp_dir)
        cp.start_run("test")
        cp.mark_failed("s1")
        cp.mark_completed("s1")
        assert cp.is_completed("s1")
        assert not cp.is_failed("s1")

    def test_completed_steps(self, cp_dir):
        cp = Checkpoint(cp_dir)
        cp.start_run("test")
        cp.mark_completed("s1")
        cp.mark_completed("s2")
        assert cp.completed_steps == {"s1", "s2"}

    def test_failed_steps(self, cp_dir):
        cp = Checkpoint(cp_dir)
        cp.start_run("test")
        cp.mark_failed("s1")
        assert cp.failed_steps == {"s1"}

    def test_load(self, cp_dir):
        cp1 = Checkpoint(cp_dir)
        run_id = cp1.start_run("test", run_id="run_1")
        cp1.mark_completed("s1")
        cp1.mark_completed("s2")
        cp1.mark_failed("s3")

        cp2 = Checkpoint(cp_dir)
        assert cp2.load("run_1") is True
        assert cp2.is_completed("s1")
        assert cp2.is_completed("s2")
        assert cp2.is_failed("s3")

    def test_load_nonexistent(self, cp_dir):
        cp = Checkpoint(cp_dir)
        assert cp.load("nonexistent") is False

    def test_list_checkpoints(self, cp_dir):
        cp = Checkpoint(cp_dir)
        cp.start_run("pipe_a", run_id="run_a")
        cp.mark_completed("s1")
        cp.start_run("pipe_b", run_id="run_b")
        cps = cp.list_checkpoints()
        assert len(cps) == 2

    def test_delete(self, cp_dir):
        cp = Checkpoint(cp_dir)
        cp.start_run("test", run_id="run_1")
        assert cp.delete("run_1") is True
        assert cp.load("run_1") is False

    def test_delete_nonexistent(self, cp_dir):
        cp = Checkpoint(cp_dir)
        assert cp.delete("nope") is False

    def test_clear(self, cp_dir):
        cp = Checkpoint(cp_dir)
        cp.start_run("a", run_id="run_a")
        cp.start_run("b", run_id="run_b")
        count = cp.clear()
        assert count == 2
        assert cp.list_checkpoints() == []

    def test_run_id_property(self, cp_dir):
        cp = Checkpoint(cp_dir)
        assert cp.run_id is None
        cp.start_run("test", run_id="my_run")
        assert cp.run_id == "my_run"

    def test_new_run_clears_state(self, cp_dir):
        cp = Checkpoint(cp_dir)
        cp.start_run("test", run_id="run_1")
        cp.mark_completed("s1")
        cp.start_run("test", run_id="run_2")
        assert not cp.is_completed("s1")

    def test_persistence(self, cp_dir):
        cp1 = Checkpoint(cp_dir)
        cp1.start_run("test", run_id="persist_test")
        cp1.mark_completed("step_a")

        # Load in new instance
        cp2 = Checkpoint(cp_dir)
        cp2.load("persist_test")
        assert cp2.is_completed("step_a")
