"""Tests for pipechain.testing module."""

import pytest
from pipechain.testing import PipelineAssertions, run_and_assert, MockStep
from pipechain.pipeline import Pipeline
from pipechain.step import Step
from pipechain.context import Context
from pipechain.result import PipelineResult, StepResult, StepStatus


class TestPipelineAssertions:
    def _success_result(self):
        return PipelineResult(pipeline_name="test", step_results=[
            StepResult(step_name="s1", status=StepStatus.SUCCESS, output=42, duration_ms=10.0),
        ], total_duration_ms=15.0)

    def _failed_result(self):
        return PipelineResult(pipeline_name="test", step_results=[
            StepResult(step_name="s1", status=StepStatus.FAILED, error=ValueError("boom")),
        ])

    def test_assert_success(self):
        PipelineAssertions(self._success_result()).assert_success()

    def test_assert_success_fails(self):
        with pytest.raises(AssertionError, match="failed"):
            PipelineAssertions(self._failed_result()).assert_success()

    def test_assert_failed(self):
        PipelineAssertions(self._failed_result()).assert_failed()

    def test_assert_failed_fails(self):
        with pytest.raises(AssertionError, match="succeeded"):
            PipelineAssertions(self._success_result()).assert_failed()

    def test_assert_step_status(self):
        PipelineAssertions(self._success_result()).assert_step_status("s1", StepStatus.SUCCESS)

    def test_assert_step_status_wrong(self):
        with pytest.raises(AssertionError):
            PipelineAssertions(self._success_result()).assert_step_status("s1", StepStatus.FAILED)

    def test_assert_step_output(self):
        PipelineAssertions(self._success_result()).assert_step_output("s1", 42)

    def test_assert_step_output_wrong(self):
        with pytest.raises(AssertionError):
            PipelineAssertions(self._success_result()).assert_step_output("s1", 99)

    def test_assert_context_value(self):
        ctx = Context({"key": "val"})
        PipelineAssertions(self._success_result(), ctx).assert_context_value("key", "val")

    def test_assert_context_value_no_ctx(self):
        with pytest.raises(AssertionError, match="No context"):
            PipelineAssertions(self._success_result()).assert_context_value("key", "val")

    def test_assert_context_has(self):
        ctx = Context({"a": 1, "b": 2})
        PipelineAssertions(self._success_result(), ctx).assert_context_has("a", "b")

    def test_assert_context_has_missing(self):
        ctx = Context({"a": 1})
        with pytest.raises(AssertionError, match="missing"):
            PipelineAssertions(self._success_result(), ctx).assert_context_has("a", "c")

    def test_assert_duration_under(self):
        PipelineAssertions(self._success_result()).assert_duration_under(100.0)

    def test_assert_duration_over(self):
        with pytest.raises(AssertionError, match="exceeds"):
            PipelineAssertions(self._success_result()).assert_duration_under(1.0)

    def test_assert_step_count(self):
        PipelineAssertions(self._success_result()).assert_step_count(1)

    def test_assert_step_count_wrong(self):
        with pytest.raises(AssertionError):
            PipelineAssertions(self._success_result()).assert_step_count(5)

    def test_assert_no_retries(self):
        PipelineAssertions(self._success_result()).assert_no_retries()

    def test_assert_no_retries_fails(self):
        r = PipelineResult(pipeline_name="test", step_results=[
            StepResult(step_name="s1", status=StepStatus.SUCCESS, retries=2),
        ])
        with pytest.raises(AssertionError, match="retries"):
            PipelineAssertions(r).assert_no_retries()

    def test_assert_steps_ran(self):
        PipelineAssertions(self._success_result()).assert_steps_ran("s1")

    def test_assert_steps_ran_missing(self):
        with pytest.raises(AssertionError, match="did not run"):
            PipelineAssertions(self._success_result()).assert_steps_ran("s2")

    def test_assert_steps_skipped(self):
        r = PipelineResult(pipeline_name="test", step_results=[
            StepResult(step_name="s1", status=StepStatus.SKIPPED),
        ])
        PipelineAssertions(r).assert_steps_skipped("s1")

    def test_step_not_found(self):
        with pytest.raises(AssertionError, match="not found"):
            PipelineAssertions(self._success_result()).assert_step_status("nope", StepStatus.SUCCESS)

    def test_chaining(self):
        r = self._success_result()
        (
            PipelineAssertions(r)
            .assert_success()
            .assert_step_count(1)
            .assert_step_status("s1", StepStatus.SUCCESS)
            .assert_step_output("s1", 42)
            .assert_no_retries()
        )


class TestRunAndAssert:
    def test_basic(self):
        p = Pipeline("test")
        p.add_step(Step("s1", lambda ctx: 42))
        assertions = run_and_assert(p)
        assertions.assert_success()

    def test_with_context(self):
        p = Pipeline("test")
        p.add_step(Step("s1", lambda ctx: ctx.get("x") + 1))
        ctx = Context({"x": 41})
        run_and_assert(p, context=ctx).assert_success().assert_step_output("s1", 42)


class TestMockStep:
    def test_basic(self):
        ms = MockStep("test", return_value=42)
        assert not ms.called

    def test_call_tracking(self):
        ms = MockStep("test", return_value=42)
        p = Pipeline("test")
        p.add_step(ms)
        p.run()
        assert ms.called
        assert ms.call_count == 1

    def test_assert_called(self):
        ms = MockStep("test")
        p = Pipeline("test")
        p.add_step(ms)
        p.run()
        ms.assert_called()

    def test_assert_called_fails(self):
        ms = MockStep("test")
        with pytest.raises(AssertionError, match="not called"):
            ms.assert_called()

    def test_assert_not_called(self):
        ms = MockStep("test")
        ms.assert_not_called()

    def test_assert_not_called_fails(self):
        ms = MockStep("test")
        p = Pipeline("test")
        p.add_step(ms)
        p.run()
        with pytest.raises(AssertionError, match="was called"):
            ms.assert_not_called()

    def test_assert_called_times(self):
        ms = MockStep("test")
        p = Pipeline("test")
        p.add_step(ms)
        p.run()
        ms.assert_called_times(1)

    def test_return_value(self):
        ms = MockStep("test", return_value=42)
        p = Pipeline("test")
        p.add_step(ms)
        ctx = Context()
        p.run(context=ctx)
        assert ctx.get("test.output") == 42

    def test_with_deps(self):
        ms = MockStep("test", depends_on=["a"])
        assert ms.depends_on == ["a"]
