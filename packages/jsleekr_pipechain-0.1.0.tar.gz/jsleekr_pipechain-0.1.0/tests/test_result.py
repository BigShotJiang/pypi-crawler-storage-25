"""Tests for pipechain.result module."""

import pytest
from pipechain.result import StepResult, PipelineResult, StepStatus


class TestStepStatus:
    def test_all_values(self):
        assert StepStatus.PENDING.value == "pending"
        assert StepStatus.RUNNING.value == "running"
        assert StepStatus.SUCCESS.value == "success"
        assert StepStatus.FAILED.value == "failed"
        assert StepStatus.SKIPPED.value == "skipped"
        assert StepStatus.CACHED.value == "cached"
        assert StepStatus.RETRYING.value == "retrying"


class TestStepResult:
    def test_success_result(self):
        r = StepResult(step_name="s1", status=StepStatus.SUCCESS, output=42)
        assert r.success is True
        assert r.output == 42

    def test_failed_result(self):
        err = ValueError("bad")
        r = StepResult(step_name="s1", status=StepStatus.FAILED, error=err)
        assert r.success is False
        assert r.error is err

    def test_cached_is_success(self):
        r = StepResult(step_name="s1", status=StepStatus.CACHED, cached=True)
        assert r.success is True

    def test_skipped_not_success(self):
        r = StepResult(step_name="s1", status=StepStatus.SKIPPED)
        assert r.success is False

    def test_repr(self):
        r = StepResult(step_name="s1", status=StepStatus.SUCCESS, duration_ms=123.4)
        s = repr(r)
        assert "s1" in s
        assert "success" in s

    def test_default_values(self):
        r = StepResult(step_name="s1", status=StepStatus.PENDING)
        assert r.output is None
        assert r.error is None
        assert r.duration_ms == 0.0
        assert r.retries == 0
        assert r.cached is False
        assert r.skipped_reason is None


class TestPipelineResult:
    def test_empty_pipeline_success(self):
        r = PipelineResult(pipeline_name="test")
        assert r.success is True

    def test_all_success(self):
        r = PipelineResult(pipeline_name="test", step_results=[
            StepResult(step_name="s1", status=StepStatus.SUCCESS),
            StepResult(step_name="s2", status=StepStatus.SUCCESS),
        ])
        assert r.success is True

    def test_one_failure(self):
        r = PipelineResult(pipeline_name="test", step_results=[
            StepResult(step_name="s1", status=StepStatus.SUCCESS),
            StepResult(step_name="s2", status=StepStatus.FAILED),
        ])
        assert r.success is False

    def test_skipped_counts_as_success(self):
        r = PipelineResult(pipeline_name="test", step_results=[
            StepResult(step_name="s1", status=StepStatus.SUCCESS),
            StepResult(step_name="s2", status=StepStatus.SKIPPED),
        ])
        assert r.success is True

    def test_failed_steps(self):
        r = PipelineResult(pipeline_name="test", step_results=[
            StepResult(step_name="s1", status=StepStatus.SUCCESS),
            StepResult(step_name="s2", status=StepStatus.FAILED),
            StepResult(step_name="s3", status=StepStatus.FAILED),
        ])
        assert len(r.failed_steps) == 2

    def test_succeeded_steps(self):
        r = PipelineResult(pipeline_name="test", step_results=[
            StepResult(step_name="s1", status=StepStatus.SUCCESS),
            StepResult(step_name="s2", status=StepStatus.CACHED),
            StepResult(step_name="s3", status=StepStatus.FAILED),
        ])
        assert len(r.succeeded_steps) == 2

    def test_skipped_steps(self):
        r = PipelineResult(pipeline_name="test", step_results=[
            StepResult(step_name="s1", status=StepStatus.SKIPPED),
        ])
        assert len(r.skipped_steps) == 1

    def test_cached_steps(self):
        r = PipelineResult(pipeline_name="test", step_results=[
            StepResult(step_name="s1", status=StepStatus.CACHED),
        ])
        assert len(r.cached_steps) == 1

    def test_summary_passed(self):
        r = PipelineResult(pipeline_name="test", step_results=[
            StepResult(step_name="s1", status=StepStatus.SUCCESS),
        ], total_duration_ms=100.0)
        s = r.summary()
        assert "PASSED" in s

    def test_summary_failed(self):
        r = PipelineResult(pipeline_name="test", step_results=[
            StepResult(step_name="s1", status=StepStatus.FAILED, error=ValueError("bad")),
        ])
        s = r.summary()
        assert "FAILED" in s
        assert "s1" in s

    def test_repr(self):
        r = PipelineResult(pipeline_name="test")
        s = repr(r)
        assert "test" in s
