"""Tests for pipechain.diff module."""

import pytest
from pipechain.diff import diff_pipelines, PipelineDiff
from pipechain.pipeline import Pipeline
from pipechain.step import Step
from pipechain.retry import RetryPolicy


class TestPipelineDiff:
    def test_no_changes(self):
        d = PipelineDiff()
        assert not d.has_changes
        assert d.change_count == 0

    def test_has_changes(self):
        d = PipelineDiff(added_steps=["s1"])
        assert d.has_changes
        assert d.change_count == 1

    def test_summary_no_changes(self):
        d = PipelineDiff()
        assert "No changes" in d.summary()

    def test_summary_with_changes(self):
        d = PipelineDiff(added_steps=["s1"], removed_steps=["s2"])
        s = d.summary()
        assert "Added" in s
        assert "Removed" in s


class TestDiffPipelines:
    def test_identical(self):
        p1 = Pipeline("test")
        p1.add_step(Step("s1", lambda ctx: None))

        p2 = Pipeline("test")
        p2.add_step(Step("s1", lambda ctx: None))

        diff = diff_pipelines(p1, p2)
        assert not diff.has_changes

    def test_added_step(self):
        p1 = Pipeline("test")
        p1.add_step(Step("s1", lambda ctx: None))

        p2 = Pipeline("test")
        p2.add_step(Step("s1", lambda ctx: None))
        p2.add_step(Step("s2", lambda ctx: None))

        diff = diff_pipelines(p1, p2)
        assert diff.added_steps == ["s2"]

    def test_removed_step(self):
        p1 = Pipeline("test")
        p1.add_step(Step("s1", lambda ctx: None))
        p1.add_step(Step("s2", lambda ctx: None))

        p2 = Pipeline("test")
        p2.add_step(Step("s1", lambda ctx: None))

        diff = diff_pipelines(p1, p2)
        assert diff.removed_steps == ["s2"]

    def test_modified_tags(self):
        p1 = Pipeline("test")
        p1.add_step(Step("s1", lambda ctx: None, tags=["old"]))

        p2 = Pipeline("test")
        p2.add_step(Step("s1", lambda ctx: None, tags=["new"]))

        diff = diff_pipelines(p1, p2)
        assert len(diff.modified_steps) == 1
        assert diff.modified_steps[0]["field"] == "tags"

    def test_modified_timeout(self):
        p1 = Pipeline("test")
        p1.add_step(Step("s1", lambda ctx: None, timeout=5.0))

        p2 = Pipeline("test")
        p2.add_step(Step("s1", lambda ctx: None, timeout=10.0))

        diff = diff_pipelines(p1, p2)
        assert any(m["field"] == "timeout" for m in diff.modified_steps)

    def test_modified_retry(self):
        p1 = Pipeline("test")
        p1.add_step(Step("s1", lambda ctx: None, retry_policy=RetryPolicy(max_retries=1)))

        p2 = Pipeline("test")
        p2.add_step(Step("s1", lambda ctx: None, retry_policy=RetryPolicy(max_retries=5)))

        diff = diff_pipelines(p1, p2)
        assert any(m["field"] == "retry.max_retries" for m in diff.modified_steps)

    def test_modified_cache(self):
        p1 = Pipeline("test")
        p1.add_step(Step("s1", lambda ctx: None, cache_key="v1"))

        p2 = Pipeline("test")
        p2.add_step(Step("s1", lambda ctx: None, cache_key="v2"))

        diff = diff_pipelines(p1, p2)
        assert any(m["field"] == "cache_key" for m in diff.modified_steps)

    def test_dependency_change(self):
        p1 = Pipeline("test")
        p1.add_step(Step("a", lambda ctx: None))
        p1.add_step(Step("b", lambda ctx: None, depends_on=["a"]))

        p2 = Pipeline("test")
        p2.add_step(Step("a", lambda ctx: None))
        p2.add_step(Step("c", lambda ctx: None))
        p2.add_step(Step("b", lambda ctx: None, depends_on=["a", "c"]))

        diff = diff_pipelines(p1, p2)
        assert len(diff.dependency_changes) == 1

    def test_config_change_concurrency(self):
        p1 = Pipeline("test", max_concurrency=4)
        p2 = Pipeline("test", max_concurrency=8)
        diff = diff_pipelines(p1, p2)
        assert any(c["field"] == "max_concurrency" for c in diff.config_changes)

    def test_config_change_fail_fast(self):
        p1 = Pipeline("test", fail_fast=True)
        p2 = Pipeline("test", fail_fast=False)
        diff = diff_pipelines(p1, p2)
        assert any(c["field"] == "fail_fast" for c in diff.config_changes)

    def test_complex_diff(self):
        p1 = Pipeline("test")
        p1.add_step(Step("a", lambda ctx: None))
        p1.add_step(Step("b", lambda ctx: None, depends_on=["a"]))
        p1.add_step(Step("c", lambda ctx: None))

        p2 = Pipeline("test")
        p2.add_step(Step("a", lambda ctx: None, tags=["modified"]))
        p2.add_step(Step("b", lambda ctx: None, depends_on=["a"]))
        p2.add_step(Step("d", lambda ctx: None))  # c removed, d added

        diff = diff_pipelines(p1, p2)
        assert diff.added_steps == ["d"]
        assert diff.removed_steps == ["c"]
        assert len(diff.modified_steps) == 1

    def test_empty_pipelines(self):
        diff = diff_pipelines(Pipeline("a"), Pipeline("b"))
        assert not diff.has_changes
