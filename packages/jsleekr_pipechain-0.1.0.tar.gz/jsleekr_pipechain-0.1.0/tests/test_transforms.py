"""Tests for pipechain.transforms module."""

import pytest
from pipechain.transforms import ContextTransformer
from pipechain.context import Context


class TestContextTransformer:
    def test_pluck(self):
        ctx = Context({"a": 1, "b": 2, "c": 3})
        t = ContextTransformer(ctx)
        assert t.pluck("a", "c") == {"a": 1, "c": 3}

    def test_pluck_missing(self):
        ctx = Context({"a": 1})
        t = ContextTransformer(ctx)
        assert t.pluck("a", "missing") == {"a": 1}

    def test_rename(self):
        ctx = Context({"old": 42})
        t = ContextTransformer(ctx)
        assert t.rename("old", "new") is True
        assert ctx.get("new") == 42
        assert not ctx.has("old")

    def test_rename_missing(self):
        ctx = Context()
        t = ContextTransformer(ctx)
        assert t.rename("missing", "new") is False

    def test_transform_value(self):
        ctx = Context({"x": 10})
        t = ContextTransformer(ctx)
        result = t.transform_value("x", lambda v: v * 2)
        assert result == 20
        assert ctx.get("x") == 20

    def test_transform_value_missing(self):
        ctx = Context()
        t = ContextTransformer(ctx)
        assert t.transform_value("x", lambda v: v * 2) is None

    def test_copy(self):
        ctx = Context({"src": 42})
        t = ContextTransformer(ctx)
        assert t.copy("src", "dst") is True
        assert ctx.get("dst") == 42
        assert ctx.get("src") == 42  # Original preserved

    def test_copy_missing(self):
        ctx = Context()
        t = ContextTransformer(ctx)
        assert t.copy("missing", "dst") is False

    def test_default_not_exists(self):
        ctx = Context()
        t = ContextTransformer(ctx)
        assert t.default("x", 42) == 42
        assert ctx.get("x") == 42

    def test_default_exists(self):
        ctx = Context({"x": 10})
        t = ContextTransformer(ctx)
        assert t.default("x", 42) == 10
        assert ctx.get("x") == 10

    def test_require_all_present(self):
        ctx = Context({"a": 1, "b": 2})
        t = ContextTransformer(ctx)
        assert t.require("a", "b") == {"a": 1, "b": 2}

    def test_require_missing(self):
        ctx = Context({"a": 1})
        t = ContextTransformer(ctx)
        with pytest.raises(KeyError, match="Missing"):
            t.require("a", "b")

    def test_validate_valid(self):
        ctx = Context({"x": 10})
        t = ContextTransformer(ctx)
        assert t.validate("x", lambda v: v > 0) is True

    def test_validate_invalid(self):
        ctx = Context({"x": -1})
        t = ContextTransformer(ctx)
        assert t.validate("x", lambda v: v > 0) is False

    def test_validate_with_message(self):
        ctx = Context({"x": -1})
        t = ContextTransformer(ctx)
        with pytest.raises(ValueError, match="must be positive"):
            t.validate("x", lambda v: v > 0, "must be positive")

    def test_validate_missing(self):
        ctx = Context()
        t = ContextTransformer(ctx)
        assert t.validate("x", lambda v: v > 0) is False

    def test_flatten(self):
        ctx = Context({"step1.a": 1, "step1.b": 2, "step2.c": 3})
        t = ContextTransformer(ctx)
        result = t.flatten("step1")
        assert result == {"a": 1, "b": 2}

    def test_flatten_with_target(self):
        ctx = Context({"step1.a": 1, "step1.b": 2})
        t = ContextTransformer(ctx)
        t.flatten("step1", target_key="result")
        assert ctx.get("result") == {"a": 1, "b": 2}

    def test_collect_outputs(self):
        ctx = Context({"s1.output": 10, "s2.output": 20, "s3.output": 30})
        t = ContextTransformer(ctx)
        outputs = t.collect_outputs("s1", "s2", "s4")
        assert outputs == {"s1": 10, "s2": 20}

    def test_pipe(self):
        ctx = Context({"x": "  hello  "})
        t = ContextTransformer(ctx)
        result = t.pipe("x", str.strip, str.upper)
        assert result == "HELLO"
        assert ctx.get("x") == "HELLO"

    def test_pipe_none(self):
        ctx = Context()
        t = ContextTransformer(ctx)
        result = t.pipe("x", str.strip)
        assert result is None
