"""Tests for pipechain.builder module."""

import pytest
from pipechain.builder import StepBuilder, PipelineBuilder
from pipechain.context import Context
from pipechain.cache import MemoryCache
from pipechain.retry import RetryPolicy
from pipechain.hooks import HookType
from pipechain.result import StepStatus


class TestStepBuilder:
    def test_basic_build(self):
        s = StepBuilder("s1", lambda ctx: 42).build()
        assert s.name == "s1"

    def test_depends_on(self):
        s = StepBuilder("s1", lambda ctx: 42).depends_on("a", "b").build()
        assert s.depends_on == ["a", "b"]

    def test_retry_int(self):
        s = StepBuilder("s1", lambda ctx: 42).retry(3).build()
        assert s.retry_policy.max_retries == 3

    def test_retry_policy(self):
        p = RetryPolicy.exponential(max_retries=5)
        s = StepBuilder("s1", lambda ctx: 42).retry(p).build()
        assert s.retry_policy.max_retries == 5

    def test_cache(self):
        s = StepBuilder("s1", lambda ctx: 42).cache("key", 60).build()
        assert s.cache_key == "key"
        assert s.cache_ttl == 60

    def test_when(self):
        cond = lambda ctx: True
        s = StepBuilder("s1", lambda ctx: 42).when(cond).build()
        assert s.condition is cond

    def test_timeout(self):
        s = StepBuilder("s1", lambda ctx: 42).timeout(5.0).build()
        assert s.timeout == 5.0

    def test_tag(self):
        s = StepBuilder("s1", lambda ctx: 42).tag("a", "b").build()
        assert s.tags == ["a", "b"]

    def test_describe(self):
        s = StepBuilder("s1", lambda ctx: 42).describe("My step").build()
        assert s.description == "My step"

    def test_chained(self):
        s = (
            StepBuilder("s1", lambda ctx: 42)
            .depends_on("a")
            .retry(3)
            .cache("k", 60)
            .timeout(5.0)
            .tag("etl")
            .describe("desc")
            .build()
        )
        assert s.name == "s1"
        assert s.depends_on == ["a"]
        assert s.retry_policy.max_retries == 3
        assert s.tags == ["etl"]


class TestPipelineBuilder:
    def test_basic_run(self):
        result = (
            PipelineBuilder("test")
            .step("s1", lambda ctx: 42)
            .run()
        )
        assert result.success

    def test_chained_steps(self):
        result = (
            PipelineBuilder("test")
            .step("s1", lambda ctx: 10)
            .step("s2", lambda ctx: ctx.get("s1.output") + 20)
            .depends_on("s1")
            .run()
        )
        assert result.success

    def test_concurrency(self):
        p = (
            PipelineBuilder("test")
            .concurrency(8)
            .step("s1", lambda ctx: 42)
            .build()
        )
        assert p.max_concurrency == 8

    def test_with_cache(self):
        cache = MemoryCache()
        call_count = [0]
        def fn(ctx):
            call_count[0] += 1
            return 42

        builder = (
            PipelineBuilder("test")
            .with_cache(cache)
            .step("s1", fn)
            .cache("k")
        )
        builder.run()
        builder.run()
        assert call_count[0] == 1  # Second run cached

    def test_fail_fast(self):
        p = PipelineBuilder("test").fail_fast(False).step("s1", lambda ctx: 42).build()
        assert p.fail_fast is False

    def test_hooks(self):
        events = []
        result = (
            PipelineBuilder("test")
            .on(HookType.BEFORE_PIPELINE, lambda **kw: events.append("before"))
            .on(HookType.AFTER_PIPELINE, lambda **kw: events.append("after"))
            .step("s1", lambda ctx: 42)
            .run()
        )
        assert "before" in events
        assert "after" in events

    def test_with_context(self):
        ctx = Context({"init": 10})
        result = (
            PipelineBuilder("test")
            .step("s1", lambda ctx: ctx.get("init") + 32)
            .run(context=ctx)
        )
        assert result.success
        assert ctx.get("s1.output") == 42

    def test_build_returns_pipeline(self):
        p = (
            PipelineBuilder("test")
            .step("s1", lambda ctx: 42)
            .build()
        )
        assert p.name == "test"
        assert len(p.steps) == 1

    def test_retry_on_step(self):
        attempts = [0]
        def flaky(ctx):
            attempts[0] += 1
            if attempts[0] < 2:
                raise ValueError("fail")
            return "ok"

        result = (
            PipelineBuilder("test")
            .step("s1", flaky)
            .retry(3)
            .run()
        )
        assert result.success

    def test_conditional_step(self):
        result = (
            PipelineBuilder("test")
            .step("s1", lambda ctx: 42)
            .when(lambda ctx: False)
            .run()
        )
        assert result.step_results[0].status == StepStatus.SKIPPED

    def test_tagged_steps(self):
        result = (
            PipelineBuilder("test")
            .step("s1", lambda ctx: 1)
            .tag("fast")
            .step("s2", lambda ctx: 2)
            .tag("slow")
            .run(tags=["fast"])
        )
        statuses = {r.step_name: r.status for r in result.step_results}
        assert statuses["s1"] == StepStatus.SUCCESS
        assert statuses["s2"] == StepStatus.SKIPPED

    def test_describe_step(self):
        p = (
            PipelineBuilder("test")
            .step("s1", lambda ctx: 42)
            .describe("My description")
            .build()
        )
        assert p.get_step("s1").description == "My description"

    def test_timeout_step(self):
        p = (
            PipelineBuilder("test")
            .step("s1", lambda ctx: 42)
            .timeout(5.0)
            .build()
        )
        assert p.get_step("s1").timeout == 5.0

    def test_multiple_depends(self):
        result = (
            PipelineBuilder("test")
            .step("a", lambda ctx: 1)
            .step("b", lambda ctx: 2)
            .step("c", lambda ctx: 3)
            .depends_on("a", "b")
            .run()
        )
        assert result.success

    def test_empty_pipeline(self):
        result = PipelineBuilder("test").run()
        assert result.success
