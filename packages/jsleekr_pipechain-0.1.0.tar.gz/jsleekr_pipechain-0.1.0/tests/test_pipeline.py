"""Tests for pipechain.pipeline module."""

import asyncio
import pytest
from pipechain.pipeline import Pipeline
from pipechain.step import Step, step
from pipechain.context import Context
from pipechain.result import StepStatus
from pipechain.retry import RetryPolicy
from pipechain.cache import MemoryCache
from pipechain.hooks import HookType


class TestPipelineCreation:
    def test_basic(self):
        p = Pipeline("test")
        assert p.name == "test"
        assert len(p.steps) == 0

    def test_with_options(self):
        p = Pipeline("test", max_concurrency=2, fail_fast=False, description="desc")
        assert p.max_concurrency == 2
        assert p.fail_fast is False
        assert p.description == "desc"

    def test_add_step(self):
        p = Pipeline("test")
        s = p.add_step(Step("s1", lambda ctx: None))
        assert isinstance(s, Step)
        assert len(p.steps) == 1

    def test_add_callable(self):
        p = Pipeline("test")
        s = p.add_step(lambda ctx: None, name="s1")
        assert isinstance(s, Step)
        assert s.name == "s1"

    def test_add_invalid(self):
        p = Pipeline("test")
        with pytest.raises(TypeError):
            p.add_step(42)

    def test_add_duplicate_name(self):
        p = Pipeline("test")
        p.add_step(Step("s1", lambda ctx: None))
        with pytest.raises(ValueError, match="already exists"):
            p.add_step(Step("s1", lambda ctx: None))

    def test_remove_step(self):
        p = Pipeline("test")
        p.add_step(Step("s1", lambda ctx: None))
        assert p.remove_step("s1") is True
        assert len(p.steps) == 0

    def test_remove_nonexistent(self):
        p = Pipeline("test")
        assert p.remove_step("nope") is False

    def test_get_step(self):
        p = Pipeline("test")
        p.add_step(Step("s1", lambda ctx: None))
        assert p.get_step("s1") is not None
        assert p.get_step("nope") is None

    def test_step_names_topological(self):
        p = Pipeline("test")
        p.add_step(Step("c", lambda ctx: None, depends_on=["b"]))
        p.add_step(Step("a", lambda ctx: None))
        p.add_step(Step("b", lambda ctx: None, depends_on=["a"]))
        names = p.step_names
        assert names.index("a") < names.index("b")
        assert names.index("b") < names.index("c")

    def test_repr(self):
        p = Pipeline("test")
        assert "test" in repr(p)


class TestPipelineValidation:
    def test_valid_pipeline(self):
        p = Pipeline("test")
        p.add_step(Step("a", lambda ctx: None))
        p.add_step(Step("b", lambda ctx: None, depends_on=["a"]))
        assert p.validate() == []

    def test_missing_dependency(self):
        p = Pipeline("test")
        p.add_step(Step("b", lambda ctx: None, depends_on=["a"]))
        warnings = p.validate()
        assert len(warnings) > 0


class TestPipelineExecution:
    def test_simple_run(self):
        p = Pipeline("test")
        p.add_step(Step("s1", lambda ctx: 42))
        result = p.run()
        assert result.success
        assert len(result.step_results) == 1
        assert result.step_results[0].status == StepStatus.SUCCESS

    def test_step_output_in_context(self):
        p = Pipeline("test")
        p.add_step(Step("s1", lambda ctx: 42))
        ctx = Context()
        p.run(context=ctx)
        assert ctx.get("s1.output") == 42

    def test_chained_steps(self):
        def s1(ctx): return 10
        def s2(ctx): return ctx.get("s1.output") + 20

        p = Pipeline("test")
        p.add_step(Step("s1", s1))
        p.add_step(Step("s2", s2, depends_on=["s1"]))
        ctx = Context()
        result = p.run(context=ctx)
        assert result.success
        assert ctx.get("s2.output") == 30

    def test_parallel_steps(self):
        results = []
        def s1(ctx):
            results.append("s1")
            return 1
        def s2(ctx):
            results.append("s2")
            return 2
        def s3(ctx):
            results.append("s3")
            return 3

        p = Pipeline("test")
        p.add_step(Step("s1", s1))
        p.add_step(Step("s2", s2))
        p.add_step(Step("s3", s3))
        result = p.run()
        assert result.success
        assert set(results) == {"s1", "s2", "s3"}

    def test_fail_fast(self):
        def s1(ctx): raise ValueError("boom")
        def s2(ctx): return 42  # Should be skipped

        p = Pipeline("test", fail_fast=True)
        p.add_step(Step("s1", s1))
        p.add_step(Step("s2", s2, depends_on=["s1"]))
        result = p.run()
        assert not result.success
        assert result.step_results[0].status == StepStatus.FAILED

    def test_no_fail_fast(self):
        call_count = [0]
        def s1(ctx):
            raise ValueError("boom")
        def s2(ctx):
            call_count[0] += 1
            return 42

        p = Pipeline("test", fail_fast=False)
        p.add_step(Step("s1", s1))
        p.add_step(Step("s2", s2))
        result = p.run()
        assert not result.success

    def test_dry_run(self):
        called = [False]
        def s1(ctx):
            called[0] = True
        p = Pipeline("test")
        p.add_step(Step("s1", s1))
        result = p.run(dry_run=True)
        assert not called[0]
        assert result.step_results[0].status == StepStatus.SKIPPED

    def test_conditional_step_skip(self):
        p = Pipeline("test")
        p.add_step(Step("s1", lambda ctx: 42, condition=lambda ctx: False))
        result = p.run()
        assert result.step_results[0].status == StepStatus.SKIPPED

    def test_conditional_step_run(self):
        p = Pipeline("test")
        p.add_step(Step("s1", lambda ctx: 42, condition=lambda ctx: True))
        result = p.run()
        assert result.step_results[0].status == StepStatus.SUCCESS

    def test_tag_filter(self):
        p = Pipeline("test")
        p.add_step(Step("s1", lambda ctx: 1, tags=["etl"]))
        p.add_step(Step("s2", lambda ctx: 2, tags=["report"]))
        result = p.run(tags=["etl"])
        statuses = {r.step_name: r.status for r in result.step_results}
        assert statuses["s1"] == StepStatus.SUCCESS
        assert statuses["s2"] == StepStatus.SKIPPED

    def test_duration_tracked(self):
        p = Pipeline("test")
        p.add_step(Step("s1", lambda ctx: 42))
        result = p.run()
        assert result.total_duration_ms > 0
        assert result.step_results[0].duration_ms >= 0

    def test_empty_pipeline(self):
        p = Pipeline("test")
        result = p.run()
        assert result.success
        assert len(result.step_results) == 0


class TestPipelineAsync:
    @pytest.mark.asyncio
    async def test_async_step(self):
        async def s1(ctx):
            return 42
        p = Pipeline("test")
        p.add_step(Step("s1", s1))
        result = await p.async_run()
        assert result.success

    @pytest.mark.asyncio
    async def test_mixed_sync_async(self):
        def s1(ctx): return 1
        async def s2(ctx): return ctx.get("s1.output") + 1

        p = Pipeline("test")
        p.add_step(Step("s1", s1))
        p.add_step(Step("s2", s2, depends_on=["s1"]))
        result = await p.async_run()
        assert result.success


class TestPipelineRetry:
    def test_retry_success_after_failures(self):
        attempts = [0]
        def flaky(ctx):
            attempts[0] += 1
            if attempts[0] < 3:
                raise ValueError("not yet")
            return "ok"

        p = Pipeline("test")
        p.add_step(Step("s1", flaky, retry_policy=RetryPolicy(
            max_retries=3, base_delay=0.01, jitter=False
        )))
        result = p.run()
        assert result.success
        assert result.step_results[0].retries == 2

    def test_retry_all_fail(self):
        def always_fail(ctx):
            raise ValueError("always")

        p = Pipeline("test")
        p.add_step(Step("s1", always_fail, retry_policy=RetryPolicy(
            max_retries=2, base_delay=0.01, jitter=False
        )))
        result = p.run()
        assert not result.success
        assert result.step_results[0].retries == 2


class TestPipelineCache:
    def test_cache_hit(self):
        call_count = [0]
        def s1(ctx):
            call_count[0] += 1
            return 42

        cache = MemoryCache()
        p = Pipeline("test", cache=cache)
        p.add_step(Step("s1", s1, cache_key="s1_key"))

        # First run - cache miss
        r1 = p.run()
        assert r1.success
        assert call_count[0] == 1
        assert r1.step_results[0].status == StepStatus.SUCCESS

        # Second run - cache hit
        r2 = p.run()
        assert r2.success
        assert call_count[0] == 1  # Not called again
        assert r2.step_results[0].status == StepStatus.CACHED

    def test_cache_with_ttl(self):
        import time
        call_count = [0]
        def s1(ctx):
            call_count[0] += 1
            return 42

        cache = MemoryCache()
        p = Pipeline("test", cache=cache)
        p.add_step(Step("s1", s1, cache_key="s1_key", cache_ttl=0.01))

        p.run()
        assert call_count[0] == 1
        time.sleep(0.02)
        p.run()
        assert call_count[0] == 2  # Cache expired


class TestPipelineHooks:
    def test_before_after_pipeline(self):
        events = []
        p = Pipeline("test")
        p.add_step(Step("s1", lambda ctx: 42))
        p.on(HookType.BEFORE_PIPELINE, lambda **kw: events.append("before"))
        p.on(HookType.AFTER_PIPELINE, lambda **kw: events.append("after"))
        p.run()
        assert events == ["before", "after"]

    def test_before_after_step(self):
        events = []
        p = Pipeline("test")
        p.add_step(Step("s1", lambda ctx: 42))
        p.on(HookType.BEFORE_STEP, lambda **kw: events.append(f"before:{kw['step'].name}"))
        p.on(HookType.AFTER_STEP, lambda **kw: events.append(f"after:{kw['step'].name}"))
        p.run()
        assert "before:s1" in events
        assert "after:s1" in events

    def test_error_hook(self):
        errors = []
        p = Pipeline("test")
        p.add_step(Step("s1", lambda ctx: (_ for _ in ()).throw(ValueError("boom"))))
        p.on(HookType.ON_STEP_ERROR, lambda **kw: errors.append(kw["error"]))
        p.run()
        assert len(errors) == 1

    def test_skip_hook(self):
        skips = []
        p = Pipeline("test")
        p.add_step(Step("s1", lambda ctx: 42, condition=lambda ctx: False))
        p.on(HookType.ON_STEP_SKIP, lambda **kw: skips.append(kw["step"].name))
        p.run()
        assert skips == ["s1"]

    def test_cache_hook(self):
        cached = []
        cache = MemoryCache()
        p = Pipeline("test", cache=cache)
        p.add_step(Step("s1", lambda ctx: 42, cache_key="k"))
        p.on(HookType.ON_STEP_CACHED, lambda **kw: cached.append(kw["step"].name))
        p.run()  # First run, no cache
        p.run()  # Second run, cached
        assert cached == ["s1"]

    def test_retry_hook(self):
        retries = []
        attempts = [0]
        def flaky(ctx):
            attempts[0] += 1
            if attempts[0] < 2:
                raise ValueError("fail")
            return "ok"

        p = Pipeline("test")
        p.add_step(Step("s1", flaky, retry_policy=RetryPolicy(
            max_retries=2, base_delay=0.01, jitter=False
        )))
        p.on(HookType.ON_STEP_RETRY, lambda **kw: retries.append(kw["attempt"]))
        p.run()
        assert len(retries) == 1


class TestPipelineVisualize:
    def test_visualize(self):
        p = Pipeline("test")
        p.add_step(Step("a", lambda ctx: None))
        p.add_step(Step("b", lambda ctx: None, depends_on=["a"]))
        viz = p.visualize()
        assert "test" in viz
        assert "a" in viz
        assert "b" in viz

    def test_execution_plan(self):
        p = Pipeline("test")
        p.add_step(Step("a", lambda ctx: None))
        p.add_step(Step("b", lambda ctx: None, depends_on=["a"]))
        p.add_step(Step("c", lambda ctx: None, depends_on=["a"]))
        levels = p.execution_plan()
        assert levels[0] == ["a"]
        assert set(levels[1]) == {"b", "c"}


class TestPipelineEdgeCases:
    def test_step_returns_none(self):
        p = Pipeline("test")
        p.add_step(Step("s1", lambda ctx: None))
        result = p.run()
        assert result.success

    def test_context_passed_through(self):
        p = Pipeline("test")
        p.add_step(Step("s1", lambda ctx: ctx.get("init_val") * 2))
        ctx = Context({"init_val": 21})
        result = p.run(context=ctx)
        assert ctx.get("s1.output") == 42

    def test_many_steps(self):
        p = Pipeline("test")
        for i in range(20):
            deps = [f"s{i-1}"] if i > 0 else []
            p.add_step(Step(f"s{i}", lambda ctx, idx=i: idx, depends_on=deps))
        result = p.run()
        assert result.success
        assert len(result.step_results) == 20
