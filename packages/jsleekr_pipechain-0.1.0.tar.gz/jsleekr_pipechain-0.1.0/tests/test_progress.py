"""Tests for pipechain.progress module."""

import pytest
from pipechain.progress import ProgressTracker
from pipechain.result import StepStatus


class TestProgressTracker:
    def test_start(self):
        pt = ProgressTracker()
        pt.start(5)
        assert pt.progress == 0.0

    def test_progress_after_completion(self):
        pt = ProgressTracker()
        pt.start(4)
        pt.step_completed("s1", StepStatus.SUCCESS)
        assert pt.progress == 0.25
        pt.step_completed("s2", StepStatus.SUCCESS)
        assert pt.progress == 0.5

    def test_progress_with_failure(self):
        pt = ProgressTracker()
        pt.start(2)
        pt.step_completed("s1", StepStatus.FAILED)
        assert pt.progress == 0.5

    def test_progress_with_skip(self):
        pt = ProgressTracker()
        pt.start(2)
        pt.step_completed("s1", StepStatus.SKIPPED)
        assert pt.progress == 0.5

    def test_progress_cached(self):
        pt = ProgressTracker()
        pt.start(2)
        pt.step_completed("s1", StepStatus.CACHED)
        assert pt.progress == 0.5

    def test_full_progress(self):
        pt = ProgressTracker()
        pt.start(2)
        pt.step_completed("s1", StepStatus.SUCCESS)
        pt.step_completed("s2", StepStatus.SUCCESS)
        assert pt.progress == 1.0

    def test_zero_total(self):
        pt = ProgressTracker()
        pt.start(0)
        assert pt.progress == 1.0

    def test_elapsed(self):
        pt = ProgressTracker()
        pt.start(1)
        assert pt.elapsed_ms >= 0.0

    def test_elapsed_not_started(self):
        pt = ProgressTracker()
        assert pt.elapsed_ms == 0.0

    def test_eta(self):
        pt = ProgressTracker()
        pt.start(4)
        pt.step_completed("s1", StepStatus.SUCCESS)
        eta = pt.eta_ms
        assert eta is not None
        assert eta >= 0

    def test_eta_not_started(self):
        pt = ProgressTracker()
        pt.start(4)
        assert pt.eta_ms is None

    def test_eta_complete(self):
        pt = ProgressTracker()
        pt.start(1)
        pt.step_completed("s1", StepStatus.SUCCESS)
        assert pt.eta_ms == 0.0

    def test_step_started(self):
        pt = ProgressTracker()
        pt.start(1)
        pt.step_started("s1")
        assert pt._current_step == "s1"

    def test_bar(self):
        pt = ProgressTracker(bar_width=10)
        pt.start(2)
        pt.step_completed("s1", StepStatus.SUCCESS)
        bar = pt.bar()
        assert "#" in bar
        assert "50%" in bar

    def test_bar_with_failure(self):
        pt = ProgressTracker(bar_width=10)
        pt.start(2)
        pt.step_completed("s1", StepStatus.FAILED)
        bar = pt.bar()
        assert "failed" in bar

    def test_bar_with_current(self):
        pt = ProgressTracker(bar_width=10)
        pt.start(2)
        pt.step_started("my_step")
        bar = pt.bar()
        assert "my_step" in bar

    def test_callback(self):
        events = []
        pt = ProgressTracker()
        pt.on_progress(lambda data: events.append(data))
        pt.start(1)
        pt.step_started("s1")
        pt.step_completed("s1", StepStatus.SUCCESS)
        assert len(events) == 2
        assert events[0]["event"] == "step_started"
        assert events[1]["event"] == "step_completed"

    def test_callback_data(self):
        events = []
        pt = ProgressTracker()
        pt.on_progress(lambda data: events.append(data))
        pt.start(1)
        pt.step_started("s1")
        pt.step_completed("s1", StepStatus.SUCCESS)
        assert events[1]["status"] == "success"
        assert events[1]["progress"] == 1.0

    def test_summary(self):
        pt = ProgressTracker()
        pt.start(3)
        pt.step_completed("s1", StepStatus.SUCCESS)
        pt.step_completed("s2", StepStatus.FAILED)
        pt.step_completed("s3", StepStatus.SKIPPED)
        s = pt.summary()
        assert s["total"] == 3
        assert s["completed"] == 1
        assert s["failed"] == 1
        assert s["skipped"] == 1
        assert s["progress"] == 1.0

    def test_multiple_callbacks(self):
        c1, c2 = [], []
        pt = ProgressTracker()
        pt.on_progress(lambda d: c1.append(d))
        pt.on_progress(lambda d: c2.append(d))
        pt.start(1)
        pt.step_started("s1")
        assert len(c1) == 1
        assert len(c2) == 1
