"""Tests for pipechain.cli module."""

import os
import pytest
import tempfile
from pathlib import Path
from pipechain.cli import main, load_pipeline_from_file, format_result_table
from pipechain.result import PipelineResult, StepResult, StepStatus


@pytest.fixture
def pipeline_file(tmp_path):
    """Create a simple pipeline file for testing."""
    code = '''
from pipechain import Pipeline, Step

pipeline = Pipeline("test_cli")
pipeline.add_step(Step("s1", lambda ctx: 42))
pipeline.add_step(Step("s2", lambda ctx: ctx.get("s1.output") + 8, depends_on=["s1"]))
'''
    f = tmp_path / "test_pipeline.py"
    f.write_text(code)
    return str(f)


@pytest.fixture
def failing_pipeline_file(tmp_path):
    code = '''
from pipechain import Pipeline, Step

def fail(ctx):
    raise ValueError("intentional failure")

pipeline = Pipeline("failing")
pipeline.add_step(Step("s1", fail))
'''
    f = tmp_path / "fail_pipeline.py"
    f.write_text(code)
    return str(f)


@pytest.fixture
def no_pipeline_file(tmp_path):
    code = "x = 42"
    f = tmp_path / "no_pipeline.py"
    f.write_text(code)
    return str(f)


@pytest.fixture
def invalid_pipeline_file(tmp_path):
    code = "pipeline = 'not a pipeline'"
    f = tmp_path / "invalid_pipeline.py"
    f.write_text(code)
    return str(f)


class TestLoadPipeline:
    def test_load_valid(self, pipeline_file):
        p = load_pipeline_from_file(pipeline_file)
        assert p.name == "test_cli"

    def test_load_not_found(self):
        with pytest.raises(FileNotFoundError):
            load_pipeline_from_file("/nonexistent/file.py")

    def test_load_no_pipeline_var(self, no_pipeline_file):
        with pytest.raises(AttributeError, match="No 'pipeline'"):
            load_pipeline_from_file(no_pipeline_file)

    def test_load_invalid_type(self, invalid_pipeline_file):
        with pytest.raises(TypeError, match="must be a Pipeline"):
            load_pipeline_from_file(invalid_pipeline_file)


class TestFormatResultTable:
    def test_format_success(self):
        r = PipelineResult(pipeline_name="test", step_results=[
            StepResult(step_name="s1", status=StepStatus.SUCCESS, duration_ms=10.0),
        ], total_duration_ms=15.0)
        table = format_result_table(r)
        assert "s1" in table
        assert "OK" in table
        assert "PASSED" in table

    def test_format_failure(self):
        r = PipelineResult(pipeline_name="test", step_results=[
            StepResult(step_name="s1", status=StepStatus.FAILED, duration_ms=5.0),
        ])
        table = format_result_table(r)
        assert "FAIL" in table
        assert "FAILED" in table

    def test_format_cached(self):
        r = PipelineResult(pipeline_name="test", step_results=[
            StepResult(step_name="s1", status=StepStatus.CACHED, cached=True),
        ])
        table = format_result_table(r)
        assert "CACHE" in table
        assert "yes" in table

    def test_format_skipped(self):
        r = PipelineResult(pipeline_name="test", step_results=[
            StepResult(step_name="s1", status=StepStatus.SKIPPED),
        ])
        table = format_result_table(r)
        assert "SKIP" in table


class TestCLICommands:
    def test_no_command(self):
        ret = main([])
        assert ret == 0

    def test_run_success(self, pipeline_file):
        ret = main(["run", pipeline_file])
        assert ret == 0

    def test_run_failure(self, failing_pipeline_file):
        ret = main(["run", failing_pipeline_file])
        assert ret == 1

    def test_run_dry_run(self, pipeline_file):
        ret = main(["run", pipeline_file, "--dry-run"])
        assert ret == 0

    def test_run_json(self, pipeline_file):
        ret = main(["run", pipeline_file, "--json"])
        assert ret == 0

    def test_run_bad_file(self):
        ret = main(["run", "/nonexistent.py"])
        assert ret == 1

    def test_validate_success(self, pipeline_file):
        ret = main(["validate", pipeline_file])
        assert ret == 0

    def test_validate_bad_file(self):
        ret = main(["validate", "/nonexistent.py"])
        assert ret == 1

    def test_visualize(self, pipeline_file):
        ret = main(["visualize", pipeline_file])
        assert ret == 0

    def test_visualize_bad_file(self):
        ret = main(["visualize", "/nonexistent.py"])
        assert ret == 1

    def test_plan(self, pipeline_file):
        ret = main(["plan", pipeline_file])
        assert ret == 0

    def test_plan_bad_file(self):
        ret = main(["plan", "/nonexistent.py"])
        assert ret == 1
