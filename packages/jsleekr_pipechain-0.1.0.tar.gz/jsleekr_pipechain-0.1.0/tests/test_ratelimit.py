"""Tests for pipechain.ratelimit module."""

import time
import pytest
from pipechain.ratelimit import RateLimiter


class TestRateLimiter:
    def test_create(self):
        rl = RateLimiter(rate=10, burst=5)
        assert rl.rate == 10
        assert rl.burst == 5

    def test_acquire_within_burst(self):
        rl = RateLimiter(rate=100, burst=3)
        assert rl.acquire() is True
        assert rl.acquire() is True
        assert rl.acquire() is True

    def test_acquire_timeout(self):
        rl = RateLimiter(rate=1, burst=1, per=10.0)
        rl.acquire()  # Use the one token
        assert rl.acquire(timeout=0.01) is False

    def test_tokens_refill(self):
        rl = RateLimiter(rate=100, burst=2, per=1.0)
        rl.acquire()
        rl.acquire()
        time.sleep(0.05)
        assert rl.available_tokens > 0

    def test_available_tokens(self):
        rl = RateLimiter(rate=10, burst=5)
        assert rl.available_tokens == 5.0
        rl.acquire()
        assert rl.available_tokens < 5.0

    def test_reset(self):
        rl = RateLimiter(rate=10, burst=5)
        rl.acquire()
        rl.acquire()
        rl.reset()
        assert rl.available_tokens == 5.0

    def test_repr(self):
        rl = RateLimiter(rate=10, burst=5)
        r = repr(rl)
        assert "10" in r
        assert "5" in r

    def test_burst_cap(self):
        rl = RateLimiter(rate=1000, burst=3, per=1.0)
        # Even after time passes, tokens don't exceed burst
        time.sleep(0.1)
        assert rl.available_tokens <= 3.0

    def test_rate_limiting_effect(self):
        rl = RateLimiter(rate=100, burst=1, per=1.0)
        rl.acquire()
        start = time.time()
        rl.acquire()  # Should wait ~10ms
        elapsed = time.time() - start
        assert elapsed >= 0.005  # At least some delay

    @pytest.mark.asyncio
    async def test_async_acquire(self):
        rl = RateLimiter(rate=100, burst=3)
        assert await rl.async_acquire() is True
        assert await rl.async_acquire() is True

    @pytest.mark.asyncio
    async def test_async_acquire_timeout(self):
        rl = RateLimiter(rate=1, burst=1, per=10.0)
        await rl.async_acquire()
        assert await rl.async_acquire(timeout=0.01) is False

    def test_high_rate(self):
        rl = RateLimiter(rate=10000, burst=100)
        for _ in range(100):
            assert rl.acquire() is True
