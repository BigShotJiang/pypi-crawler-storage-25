"""Tests for pipechain.context module."""

import pytest
import threading
from pipechain.context import Context


class TestContextBasicOps:
    """Test basic get/set/delete operations."""

    def test_set_and_get(self):
        ctx = Context()
        ctx.set("key", "value")
        assert ctx.get("key") == "value"

    def test_get_default(self):
        ctx = Context()
        assert ctx.get("missing") is None
        assert ctx.get("missing", 42) == 42

    def test_has_key(self):
        ctx = Context()
        ctx.set("exists", True)
        assert ctx.has("exists")
        assert not ctx.has("missing")

    def test_delete_existing(self):
        ctx = Context()
        ctx.set("key", "value")
        assert ctx.delete("key") is True
        assert not ctx.has("key")

    def test_delete_nonexistent(self):
        ctx = Context()
        assert ctx.delete("missing") is False

    def test_initial_data(self):
        ctx = Context({"a": 1, "b": 2})
        assert ctx.get("a") == 1
        assert ctx.get("b") == 2

    def test_keys(self):
        ctx = Context({"a": 1, "b": 2})
        assert sorted(ctx.keys()) == ["a", "b"]

    def test_items(self):
        ctx = Context({"a": 1})
        items = ctx.items()
        assert ("a", 1) in items

    def test_len(self):
        ctx = Context({"a": 1, "b": 2})
        assert len(ctx) == 2

    def test_clear(self):
        ctx = Context({"a": 1, "b": 2})
        ctx.clear()
        assert len(ctx) == 0

    def test_merge(self):
        ctx = Context({"a": 1})
        ctx.merge({"b": 2, "c": 3})
        assert ctx.get("a") == 1
        assert ctx.get("b") == 2
        assert ctx.get("c") == 3

    def test_merge_overwrite(self):
        ctx = Context({"a": 1})
        ctx.merge({"a": 99})
        assert ctx.get("a") == 99

    def test_to_dict(self):
        ctx = Context({"a": 1})
        d = ctx.to_dict()
        assert d == {"a": 1}
        d["a"] = 999
        assert ctx.get("a") == 1  # Not affected

    def test_repr(self):
        ctx = Context({"a": 1})
        assert "Context" in repr(ctx)

    def test_set_none_value(self):
        ctx = Context()
        ctx.set("key", None)
        assert ctx.has("key")
        assert ctx.get("key") is None

    def test_set_complex_value(self):
        ctx = Context()
        ctx.set("data", {"nested": [1, 2, 3]})
        assert ctx.get("data") == {"nested": [1, 2, 3]}


class TestContextNamespace:
    """Test namespace operations."""

    def test_namespace_basic(self):
        ctx = Context()
        ctx.set("step1.output", "data1")
        ctx.set("step1.status", "ok")
        ctx.set("step2.output", "data2")
        ns = ctx.namespace("step1")
        assert ns == {"output": "data1", "status": "ok"}

    def test_namespace_empty(self):
        ctx = Context()
        assert ctx.namespace("nonexistent") == {}

    def test_namespace_no_partial_match(self):
        ctx = Context()
        ctx.set("step1_extra", "value")
        assert ctx.namespace("step1") == {}


class TestContextSnapshot:
    """Test snapshot and rollback."""

    def test_snapshot_and_rollback(self):
        ctx = Context({"a": 1})
        snap_id = ctx.snapshot()
        ctx.set("a", 999)
        ctx.rollback(snap_id)
        assert ctx.get("a") == 1

    def test_rollback_latest(self):
        ctx = Context({"a": 1})
        ctx.snapshot()
        ctx.set("a", 2)
        ctx.snapshot()
        ctx.set("a", 3)
        ctx.rollback()  # Should rollback to second snapshot
        assert ctx.get("a") == 2

    def test_rollback_no_snapshots(self):
        ctx = Context()
        with pytest.raises(ValueError, match="No snapshots"):
            ctx.rollback()

    def test_rollback_invalid_id(self):
        ctx = Context()
        ctx.snapshot()
        with pytest.raises(ValueError, match="Invalid snapshot"):
            ctx.rollback(99)

    def test_snapshot_is_deep_copy(self):
        ctx = Context({"data": [1, 2, 3]})
        ctx.snapshot()
        ctx.get("data").append(4)
        ctx.rollback()
        assert ctx.get("data") == [1, 2, 3]

    def test_multiple_snapshots(self):
        ctx = Context({"v": 0})
        s0 = ctx.snapshot()
        ctx.set("v", 1)
        s1 = ctx.snapshot()
        ctx.set("v", 2)
        ctx.rollback(s0)
        assert ctx.get("v") == 0


class TestContextThreadSafety:
    """Test thread safety."""

    def test_concurrent_writes(self):
        ctx = Context()
        errors = []

        def writer(prefix, count):
            try:
                for i in range(count):
                    ctx.set(f"{prefix}_{i}", i)
            except Exception as e:
                errors.append(e)

        threads = [
            threading.Thread(target=writer, args=(f"t{t}", 100))
            for t in range(5)
        ]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert not errors
        assert len(ctx) == 500

    def test_concurrent_read_write(self):
        ctx = Context({"counter": 0})
        errors = []

        def reader():
            try:
                for _ in range(100):
                    ctx.get("counter")
            except Exception as e:
                errors.append(e)

        def writer():
            try:
                for i in range(100):
                    ctx.set("counter", i)
            except Exception as e:
                errors.append(e)

        threads = [
            threading.Thread(target=reader),
            threading.Thread(target=writer),
            threading.Thread(target=reader),
        ]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert not errors
