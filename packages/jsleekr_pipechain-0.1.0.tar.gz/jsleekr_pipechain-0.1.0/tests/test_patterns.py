"""Tests for pipechain.patterns module."""

import pytest
from pipechain.patterns import (
    map_step, filter_step, reduce_step, batch_step,
    delay_step, log_step, branch_step,
)
from pipechain.context import Context
from pipechain.pipeline import Pipeline
from pipechain.step import Step


class TestMapStep:
    def test_basic(self):
        s = map_step("double", lambda x: x * 2, "input")
        ctx = Context({"input": [1, 2, 3]})
        p = Pipeline("test")
        p.add_step(s)
        p.run(context=ctx)
        assert ctx.get("double.output") == [2, 4, 6]

    def test_empty_input(self):
        s = map_step("double", lambda x: x * 2, "input")
        ctx = Context()
        p = Pipeline("test")
        p.add_step(s)
        p.run(context=ctx)
        assert ctx.get("double.output") == []

    def test_custom_output_key(self):
        s = map_step("double", lambda x: x * 2, "input", output_key="result")
        ctx = Context({"input": [1, 2]})
        p = Pipeline("test")
        p.add_step(s)
        p.run(context=ctx)
        assert ctx.get("result") == [2, 4]

    def test_with_deps(self):
        s = map_step("double", lambda x: x * 2, "src.output", depends_on=["src"])
        assert s.depends_on == ["src"]


class TestFilterStep:
    def test_basic(self):
        s = filter_step("evens", lambda x: x % 2 == 0, "input")
        ctx = Context({"input": [1, 2, 3, 4, 5]})
        p = Pipeline("test")
        p.add_step(s)
        p.run(context=ctx)
        assert ctx.get("evens.output") == [2, 4]

    def test_empty_input(self):
        s = filter_step("evens", lambda x: x % 2 == 0, "input")
        ctx = Context()
        p = Pipeline("test")
        p.add_step(s)
        p.run(context=ctx)
        assert ctx.get("evens.output") == []

    def test_filter_all(self):
        s = filter_step("none", lambda x: False, "input")
        ctx = Context({"input": [1, 2, 3]})
        p = Pipeline("test")
        p.add_step(s)
        p.run(context=ctx)
        assert ctx.get("none.output") == []

    def test_filter_none(self):
        s = filter_step("all", lambda x: True, "input")
        ctx = Context({"input": [1, 2, 3]})
        p = Pipeline("test")
        p.add_step(s)
        p.run(context=ctx)
        assert ctx.get("all.output") == [1, 2, 3]


class TestReduceStep:
    def test_sum(self):
        s = reduce_step("total", lambda a, b: a + b, "input", initial=0)
        ctx = Context({"input": [1, 2, 3, 4]})
        p = Pipeline("test")
        p.add_step(s)
        p.run(context=ctx)
        assert ctx.get("total.output") == 10

    def test_no_initial(self):
        s = reduce_step("total", lambda a, b: a + b, "input")
        ctx = Context({"input": [1, 2, 3]})
        p = Pipeline("test")
        p.add_step(s)
        p.run(context=ctx)
        assert ctx.get("total.output") == 6

    def test_with_initial(self):
        s = reduce_step("concat", lambda a, b: a + [b], "input", initial=[])
        ctx = Context({"input": [1, 2, 3]})
        p = Pipeline("test")
        p.add_step(s)
        p.run(context=ctx)
        assert ctx.get("concat.output") == [1, 2, 3]


class TestBatchStep:
    def test_basic(self):
        results = []
        def process(batch):
            results.append(len(batch))
            return [x * 2 for x in batch]

        s = batch_step("batched", process, "input", batch_size=3)
        ctx = Context({"input": [1, 2, 3, 4, 5]})
        p = Pipeline("test")
        p.add_step(s)
        p.run(context=ctx)
        assert results == [3, 2]  # Two batches: 3 + 2
        assert ctx.get("batched.output") == [2, 4, 6, 8, 10]

    def test_single_batch(self):
        s = batch_step("batched", lambda b: [x + 1 for x in b], "input", batch_size=100)
        ctx = Context({"input": [1, 2, 3]})
        p = Pipeline("test")
        p.add_step(s)
        p.run(context=ctx)
        assert ctx.get("batched.output") == [2, 3, 4]

    def test_empty_input(self):
        s = batch_step("batched", lambda b: b, "input", batch_size=10)
        ctx = Context()
        p = Pipeline("test")
        p.add_step(s)
        p.run(context=ctx)
        assert ctx.get("batched.output") == []

    def test_non_list_return(self):
        s = batch_step("batched", lambda b: sum(b), "input", batch_size=2)
        ctx = Context({"input": [1, 2, 3, 4]})
        p = Pipeline("test")
        p.add_step(s)
        p.run(context=ctx)
        assert ctx.get("batched.output") == [3, 7]  # Sum of each batch


class TestDelayStep:
    def test_delay(self):
        s = delay_step("wait", 0.01)
        assert s.name == "wait"
        assert s.is_async is True

    @pytest.mark.asyncio
    async def test_delay_runs(self):
        import time
        s = delay_step("wait", 0.01)
        ctx = Context()
        start = time.time()
        await s.execute(ctx)
        assert time.time() - start >= 0.005


class TestLogStep:
    def test_log(self):
        s = log_step("log1", "hello")
        ctx = Context()
        p = Pipeline("test")
        p.add_step(s)
        p.run(context=ctx)
        logs = ctx.get("_logs")
        assert len(logs) == 1
        assert logs[0]["message"] == "hello"

    def test_multiple_logs(self):
        ctx = Context()
        p = Pipeline("test")
        p.add_step(log_step("l1", "first"))
        p.add_step(log_step("l2", "second"))
        p.run(context=ctx)
        logs = ctx.get("_logs")
        assert len(logs) == 2


class TestBranchStep:
    def test_true_branch(self):
        s = branch_step(
            "branch",
            lambda ctx: ctx.get("flag"),
            if_true=lambda ctx: "yes",
            if_false=lambda ctx: "no",
        )
        ctx = Context({"flag": True})
        p = Pipeline("test")
        p.add_step(s)
        p.run(context=ctx)
        assert ctx.get("branch.output") == "yes"

    def test_false_branch(self):
        s = branch_step(
            "branch",
            lambda ctx: ctx.get("flag"),
            if_true=lambda ctx: "yes",
            if_false=lambda ctx: "no",
        )
        ctx = Context({"flag": False})
        p = Pipeline("test")
        p.add_step(s)
        p.run(context=ctx)
        assert ctx.get("branch.output") == "no"
