"""Integration tests combining multiple pipechain features."""

import asyncio
import pytest
from pipechain import Pipeline, Step, Context, step
from pipechain.builder import PipelineBuilder
from pipechain.cache import MemoryCache
from pipechain.compose import compose, merge
from pipechain.hooks import HookType
from pipechain.patterns import map_step, filter_step, reduce_step, batch_step
from pipechain.retry import RetryPolicy
from pipechain.result import StepStatus
from pipechain.template import PipelineTemplate, clone_pipeline
from pipechain.testing import run_and_assert, MockStep
from pipechain.transforms import ContextTransformer
from pipechain.metrics import MetricsCollector
from pipechain.export import to_dot, to_mermaid, to_json_graph
from pipechain.serialize import pipeline_to_json, json_to_pipeline, pipeline_to_dict


class TestETLPipeline:
    """Full ETL pipeline integration test."""

    def test_etl_flow(self):
        @step(name="extract")
        def extract(ctx: Context):
            return [
                {"name": "Alice", "age": 30, "dept": "eng"},
                {"name": "Bob", "age": 25, "dept": "sales"},
                {"name": "Carol", "age": 35, "dept": "eng"},
                {"name": "Dave", "age": 28, "dept": "eng"},
            ]

        @step(name="filter_eng", depends_on=["extract"])
        def filter_eng(ctx: Context):
            users = ctx.get("extract.output")
            return [u for u in users if u["dept"] == "eng"]

        @step(name="enrich", depends_on=["filter_eng"])
        def enrich(ctx: Context):
            users = ctx.get("filter_eng.output")
            for u in users:
                u["senior"] = u["age"] >= 30
            return users

        @step(name="summarize", depends_on=["enrich"])
        def summarize(ctx: Context):
            users = ctx.get("enrich.output")
            return {
                "total": len(users),
                "seniors": sum(1 for u in users if u["senior"]),
            }

        pipe = Pipeline("etl")
        pipe.add_step(extract)
        pipe.add_step(filter_eng)
        pipe.add_step(enrich)
        pipe.add_step(summarize)

        ctx = Context()
        result = pipe.run(context=ctx)
        assert result.success
        assert ctx.get("summarize.output") == {"total": 3, "seniors": 2}

    def test_etl_with_cache_and_retry(self):
        call_counts = {"extract": 0, "transform": 0}

        def extract(ctx):
            call_counts["extract"] += 1
            return list(range(10))

        transform_attempts = [0]
        def transform(ctx):
            call_counts["transform"] += 1
            transform_attempts[0] += 1
            if transform_attempts[0] < 2:
                raise ValueError("transient failure")
            return [x * 2 for x in ctx.get("extract.output")]

        cache = MemoryCache()
        pipe = Pipeline("cached_etl", cache=cache)
        pipe.add_step(Step("extract", extract, cache_key="extract_v1"))
        pipe.add_step(Step("transform", transform, depends_on=["extract"],
                          retry_policy=RetryPolicy(max_retries=3, base_delay=0.01, jitter=False)))

        # First run
        r1 = pipe.run()
        assert r1.success
        assert call_counts["extract"] == 1

        # Second run: extract should be cached
        transform_attempts[0] = 0
        r2 = pipe.run()
        assert r2.success
        assert call_counts["extract"] == 1  # Still 1 - cached!


class TestBuilderIntegration:
    def test_builder_with_hooks_and_cache(self):
        events = []
        cache = MemoryCache()

        result = (
            PipelineBuilder("test")
            .with_cache(cache)
            .on(HookType.BEFORE_PIPELINE, lambda **kw: events.append("start"))
            .on(HookType.AFTER_PIPELINE, lambda **kw: events.append("end"))
            .step("s1", lambda ctx: 42)
            .cache("s1_key")
            .step("s2", lambda ctx: ctx.get("s1.output") + 8)
            .depends_on("s1")
            .run()
        )
        assert result.success
        assert events == ["start", "end"]


class TestCompositionIntegration:
    def test_compose_independent_pipelines(self):
        p1 = Pipeline("extract")
        p1.add_step(Step("fetch", lambda ctx: ctx.set("data", [1, 2, 3]) or [1, 2, 3]))

        p2 = Pipeline("transform")
        p2.add_step(Step("double", lambda ctx: [x * 2 for x in ctx.get("data", [])]))

        composed = compose(p1, p2, name="etl")
        ctx = Context()
        result = composed.run(context=ctx)
        assert result.success

    def test_merge_parallel_pipelines(self):
        p1 = Pipeline("users")
        p1.add_step(Step("fetch_users", lambda ctx: ctx.set("users", ["alice"]) or 1))

        p2 = Pipeline("orders")
        p2.add_step(Step("fetch_orders", lambda ctx: ctx.set("orders", [100]) or 1))

        merged = merge(p1, p2, name="fetch_all")
        ctx = Context()
        result = merged.run(context=ctx)
        assert result.success
        assert ctx.get("users") == ["alice"]
        assert ctx.get("orders") == [100]


class TestPatternsIntegration:
    def test_map_filter_reduce_pipeline(self):
        pipe = Pipeline("data_proc")
        pipe.add_step(Step("source", lambda ctx: ctx.set("data", list(range(1, 11))) or 1))
        pipe.add_step(map_step("squared", lambda x: x ** 2, "data", depends_on=["source"]))
        pipe.add_step(filter_step("big", lambda x: x > 25, "squared.output", depends_on=["squared"]))
        pipe.add_step(reduce_step("total", lambda a, b: a + b, "big.output", initial=0, depends_on=["big"]))

        ctx = Context()
        result = pipe.run(context=ctx)
        assert result.success
        # Squares > 25: 36, 49, 64, 81, 100 -> sum = 330
        assert ctx.get("total.output") == 330


class TestTemplateIntegration:
    def test_template_instantiation(self):
        tmpl = PipelineTemplate("etl_tmpl")
        tmpl.add_slot("extract")
        tmpl.add_slot("transform", depends_on=["extract"])
        tmpl.add_slot("load", depends_on=["transform"])

        pipe = tmpl.instantiate({
            "extract": lambda ctx: [1, 2, 3],
            "transform": lambda ctx: [x * 2 for x in ctx.get("extract.output")],
            "load": lambda ctx: len(ctx.get("transform.output")),
        })

        ctx = Context()
        result = pipe.run(context=ctx)
        assert result.success
        assert ctx.get("load.output") == 3

    def test_clone_and_modify(self):
        orig = Pipeline("v1")
        orig.add_step(Step("s1", lambda ctx: 1))
        orig.add_step(Step("s2", lambda ctx: 2, depends_on=["s1"]))

        cloned = clone_pipeline(orig, new_name="v2", step_overrides={
            "s1": lambda ctx: 10,
        })
        ctx = Context()
        cloned.run(context=ctx)
        assert ctx.get("s1.output") == 10


class TestMetricsIntegration:
    def test_metrics_across_runs(self):
        mc = MetricsCollector()
        pipe = Pipeline("metrics_test")
        pipe.add_step(Step("s1", lambda ctx: 42))

        for _ in range(5):
            result = pipe.run()
            mc.record_pipeline_run(result)

        pm = mc.get_pipeline_metrics("metrics_test")
        assert pm.run_count == 5
        assert pm.success_rate == 1.0


class TestExportIntegration:
    def test_export_all_formats(self):
        pipe = Pipeline("export_test")
        pipe.add_step(Step("a", lambda ctx: 1))
        pipe.add_step(Step("b", lambda ctx: 2, depends_on=["a"], tags=["fast"]))

        dot = to_dot(pipe)
        assert "digraph" in dot

        md = to_mermaid(pipe)
        assert "graph" in md

        jg = to_json_graph(pipe)
        assert len(jg["nodes"]) == 2


class TestSerializeIntegration:
    def test_roundtrip(self):
        pipe = Pipeline("serialize_test")
        pipe.add_step(Step("a", lambda ctx: 1, tags=["etl"]))
        pipe.add_step(Step("b", lambda ctx: 2, depends_on=["a"]))

        json_str = pipeline_to_json(pipe)
        restored = json_to_pipeline(json_str, {
            "a": lambda ctx: 1,
            "b": lambda ctx: 2,
        })
        result = restored.run()
        assert result.success


class TestMockStepIntegration:
    def test_mock_in_pipeline(self):
        mock_extract = MockStep("extract", return_value=[1, 2, 3])
        mock_load = MockStep("load", return_value="done", depends_on=["extract"])

        pipe = Pipeline("test")
        pipe.add_step(mock_extract)
        pipe.add_step(mock_load)

        (
            run_and_assert(pipe)
            .assert_success()
            .assert_step_output("extract", [1, 2, 3])
            .assert_step_output("load", "done")
        )

        mock_extract.assert_called_times(1)
        mock_load.assert_called_times(1)


class TestTransformsIntegration:
    def test_transformer_in_steps(self):
        def process(ctx: Context):
            t = ContextTransformer(ctx)
            t.default("counter", 0)
            t.transform_value("counter", lambda x: x + 1)
            return ctx.get("counter")

        pipe = Pipeline("test")
        pipe.add_step(Step("s1", process))
        ctx = Context()
        pipe.run(context=ctx)
        assert ctx.get("counter") == 1

    def test_collect_outputs(self):
        pipe = Pipeline("test")
        pipe.add_step(Step("a", lambda ctx: 1))
        pipe.add_step(Step("b", lambda ctx: 2))
        pipe.add_step(Step("collect", lambda ctx: ContextTransformer(ctx).collect_outputs("a", "b"),
                          depends_on=["a", "b"]))
        ctx = Context()
        pipe.run(context=ctx)
        assert ctx.get("collect.output") == {"a": 1, "b": 2}


class TestAsyncIntegration:
    @pytest.mark.asyncio
    async def test_mixed_sync_async_pipeline(self):
        def sync_step(ctx):
            return 10

        async def async_step(ctx):
            await asyncio.sleep(0.01)
            return ctx.get("sync.output") + 32

        pipe = Pipeline("mixed")
        pipe.add_step(Step("sync", sync_step))
        pipe.add_step(Step("async", async_step, depends_on=["sync"]))

        result = await pipe.async_run()
        assert result.success

    @pytest.mark.asyncio
    async def test_parallel_async_steps(self):
        async def slow_a(ctx):
            await asyncio.sleep(0.02)
            return "a"

        async def slow_b(ctx):
            await asyncio.sleep(0.02)
            return "b"

        pipe = Pipeline("parallel")
        pipe.add_step(Step("a", slow_a))
        pipe.add_step(Step("b", slow_b))

        result = await pipe.async_run()
        assert result.success
        # Both should run in ~20ms total (parallel), not ~40ms
        assert result.total_duration_ms < 100
