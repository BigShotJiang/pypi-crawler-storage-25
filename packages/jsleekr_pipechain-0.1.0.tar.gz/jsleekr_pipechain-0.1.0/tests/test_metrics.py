"""Tests for pipechain.metrics module."""

import pytest
from pipechain.metrics import StepMetrics, PipelineMetrics, MetricsCollector
from pipechain.result import StepResult, PipelineResult, StepStatus


class TestStepMetrics:
    def test_default_values(self):
        m = StepMetrics(step_name="s1")
        assert m.run_count == 0
        assert m.failure_rate == 0.0
        assert m.cache_hit_rate == 0.0
        assert m.avg_duration_ms == 0.0

    def test_failure_rate(self):
        m = StepMetrics(step_name="s1", run_count=10, failure_count=3)
        assert m.failure_rate == 0.3

    def test_cache_hit_rate(self):
        m = StepMetrics(step_name="s1", run_count=10, cache_hit_count=4)
        assert m.cache_hit_rate == 0.4

    def test_avg_duration(self):
        m = StepMetrics(step_name="s1", durations_ms=[10.0, 20.0, 30.0])
        assert m.avg_duration_ms == 20.0

    def test_median_duration(self):
        m = StepMetrics(step_name="s1", durations_ms=[10.0, 20.0, 100.0])
        assert m.median_duration_ms == 20.0

    def test_p95_duration(self):
        m = StepMetrics(step_name="s1", durations_ms=list(range(100)))
        assert m.p95_duration_ms >= 94

    def test_p95_single(self):
        m = StepMetrics(step_name="s1", durations_ms=[10.0])
        assert m.p95_duration_ms == 10.0

    def test_min_max_duration(self):
        m = StepMetrics(step_name="s1", durations_ms=[5.0, 10.0, 15.0])
        assert m.min_duration_ms == 5.0
        assert m.max_duration_ms == 15.0

    def test_empty_min_max(self):
        m = StepMetrics(step_name="s1")
        assert m.min_duration_ms == 0.0
        assert m.max_duration_ms == 0.0

    def test_median_empty(self):
        m = StepMetrics(step_name="s1")
        assert m.median_duration_ms == 0.0


class TestPipelineMetrics:
    def test_default_values(self):
        m = PipelineMetrics(pipeline_name="test")
        assert m.run_count == 0
        assert m.success_rate == 0.0
        assert m.avg_duration_ms == 0.0

    def test_success_rate(self):
        m = PipelineMetrics(pipeline_name="test", run_count=10, success_count=8)
        assert m.success_rate == 0.8

    def test_slowest_steps(self):
        m = PipelineMetrics(pipeline_name="test", step_metrics={
            "fast": StepMetrics(step_name="fast", durations_ms=[10.0]),
            "slow": StepMetrics(step_name="slow", durations_ms=[100.0]),
        })
        slowest = m.slowest_steps
        assert slowest[0][0] == "slow"

    def test_most_failed(self):
        m = PipelineMetrics(pipeline_name="test", step_metrics={
            "reliable": StepMetrics(step_name="reliable", run_count=10, failure_count=1),
            "flaky": StepMetrics(step_name="flaky", run_count=10, failure_count=5),
        })
        failed = m.most_failed_steps
        assert failed[0][0] == "flaky"

    def test_slowest_empty(self):
        m = PipelineMetrics(pipeline_name="test")
        assert m.slowest_steps == []


class TestMetricsCollector:
    def _make_result(self, name="test", success=True, duration=100.0, steps=None):
        step_results = steps or [
            StepResult(step_name="s1", status=StepStatus.SUCCESS, duration_ms=50.0),
        ]
        return PipelineResult(
            pipeline_name=name,
            step_results=step_results,
            total_duration_ms=duration,
        )

    def test_record_success(self):
        mc = MetricsCollector()
        mc.record_pipeline_run(self._make_result())
        pm = mc.get_pipeline_metrics("test")
        assert pm is not None
        assert pm.run_count == 1
        assert pm.success_count == 1

    def test_record_failure(self):
        mc = MetricsCollector()
        mc.record_pipeline_run(self._make_result(steps=[
            StepResult(step_name="s1", status=StepStatus.FAILED, duration_ms=50.0,
                       error=ValueError("fail")),
        ]))
        pm = mc.get_pipeline_metrics("test")
        assert pm.failure_count == 1

    def test_record_multiple_runs(self):
        mc = MetricsCollector()
        mc.record_pipeline_run(self._make_result(duration=100.0))
        mc.record_pipeline_run(self._make_result(duration=200.0))
        pm = mc.get_pipeline_metrics("test")
        assert pm.run_count == 2
        assert pm.avg_duration_ms == 150.0

    def test_step_metrics_tracked(self):
        mc = MetricsCollector()
        mc.record_pipeline_run(self._make_result())
        pm = mc.get_pipeline_metrics("test")
        assert "s1" in pm.step_metrics
        assert pm.step_metrics["s1"].success_count == 1

    def test_skipped_step(self):
        mc = MetricsCollector()
        mc.record_pipeline_run(self._make_result(steps=[
            StepResult(step_name="s1", status=StepStatus.SKIPPED),
        ]))
        pm = mc.get_pipeline_metrics("test")
        assert pm.step_metrics["s1"].skip_count == 1

    def test_cached_step(self):
        mc = MetricsCollector()
        mc.record_pipeline_run(self._make_result(steps=[
            StepResult(step_name="s1", status=StepStatus.CACHED, cached=True, duration_ms=1.0),
        ]))
        pm = mc.get_pipeline_metrics("test")
        assert pm.step_metrics["s1"].cache_hit_count == 1
        assert pm.step_metrics["s1"].success_count == 1

    def test_retries_tracked(self):
        mc = MetricsCollector()
        mc.record_pipeline_run(self._make_result(steps=[
            StepResult(step_name="s1", status=StepStatus.SUCCESS, duration_ms=50.0, retries=3),
        ]))
        pm = mc.get_pipeline_metrics("test")
        assert pm.step_metrics["s1"].total_retries == 3

    def test_get_nonexistent(self):
        mc = MetricsCollector()
        assert mc.get_pipeline_metrics("nope") is None

    def test_get_all(self):
        mc = MetricsCollector()
        mc.record_pipeline_run(self._make_result(name="a"))
        mc.record_pipeline_run(self._make_result(name="b"))
        assert len(mc.get_all_metrics()) == 2

    def test_reset_specific(self):
        mc = MetricsCollector()
        mc.record_pipeline_run(self._make_result(name="a"))
        mc.record_pipeline_run(self._make_result(name="b"))
        mc.reset("a")
        assert mc.get_pipeline_metrics("a") is None
        assert mc.get_pipeline_metrics("b") is not None

    def test_reset_all(self):
        mc = MetricsCollector()
        mc.record_pipeline_run(self._make_result(name="a"))
        mc.record_pipeline_run(self._make_result(name="b"))
        mc.reset()
        assert len(mc.get_all_metrics()) == 0

    def test_summary(self):
        mc = MetricsCollector()
        mc.record_pipeline_run(self._make_result())
        s = mc.summary("test")
        assert "test" in s
        assert "Runs: 1" in s

    def test_summary_nonexistent(self):
        mc = MetricsCollector()
        s = mc.summary("nope")
        assert "No metrics" in s

    def test_summary_with_failures(self):
        mc = MetricsCollector()
        mc.record_pipeline_run(self._make_result(steps=[
            StepResult(step_name="s1", status=StepStatus.FAILED, duration_ms=50.0,
                       error=ValueError("fail")),
        ]))
        s = mc.summary("test")
        assert "failure" in s.lower()
