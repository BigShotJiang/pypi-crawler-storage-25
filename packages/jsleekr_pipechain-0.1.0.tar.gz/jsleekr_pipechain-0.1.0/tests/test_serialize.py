"""Tests for pipechain.serialize module."""

import json
import pytest
from pipechain.serialize import (
    pipeline_to_dict, pipeline_to_json, dict_to_pipeline,
    json_to_pipeline, validate_definition, _step_to_dict,
)
from pipechain.pipeline import Pipeline
from pipechain.step import Step
from pipechain.retry import RetryPolicy


class TestPipelineToDict:
    def test_basic(self):
        p = Pipeline("test")
        p.add_step(Step("s1", lambda ctx: None))
        d = pipeline_to_dict(p)
        assert d["name"] == "test"
        assert len(d["steps"]) == 1
        assert d["steps"][0]["name"] == "s1"

    def test_with_deps(self):
        p = Pipeline("test")
        p.add_step(Step("a", lambda ctx: None))
        p.add_step(Step("b", lambda ctx: None, depends_on=["a"]))
        d = pipeline_to_dict(p)
        assert d["steps"][1]["depends_on"] == ["a"]

    def test_with_retry(self):
        p = Pipeline("test")
        p.add_step(Step("s1", lambda ctx: None, retry_policy=RetryPolicy(max_retries=3)))
        d = pipeline_to_dict(p)
        assert d["steps"][0]["retry"]["max_retries"] == 3

    def test_with_tags(self):
        p = Pipeline("test")
        p.add_step(Step("s1", lambda ctx: None, tags=["etl"]))
        d = pipeline_to_dict(p)
        assert d["steps"][0]["tags"] == ["etl"]

    def test_with_cache(self):
        p = Pipeline("test")
        p.add_step(Step("s1", lambda ctx: None, cache_key="k", cache_ttl=60))
        d = pipeline_to_dict(p)
        assert d["steps"][0]["cache_key"] == "k"
        assert d["steps"][0]["cache_ttl"] == 60

    def test_with_timeout(self):
        p = Pipeline("test")
        p.add_step(Step("s1", lambda ctx: None, timeout=5.0))
        d = pipeline_to_dict(p)
        assert d["steps"][0]["timeout"] == 5.0

    def test_pipeline_options(self):
        p = Pipeline("test", max_concurrency=8, fail_fast=False, description="desc")
        d = pipeline_to_dict(p)
        assert d["max_concurrency"] == 8
        assert d["fail_fast"] is False
        assert d["description"] == "desc"


class TestPipelineToJson:
    def test_basic(self):
        p = Pipeline("test")
        p.add_step(Step("s1", lambda ctx: None))
        j = pipeline_to_json(p)
        data = json.loads(j)
        assert data["name"] == "test"

    def test_roundtrip(self):
        p = Pipeline("test")
        p.add_step(Step("s1", lambda ctx: None, description="step one"))
        j = pipeline_to_json(p)
        data = json.loads(j)
        assert data["steps"][0]["description"] == "step one"


class TestDictToPipeline:
    def test_basic(self):
        data = {
            "name": "test",
            "steps": [{"name": "s1"}, {"name": "s2", "depends_on": ["s1"]}],
        }
        p = dict_to_pipeline(data)
        assert p.name == "test"
        assert len(p.steps) == 2

    def test_with_registry(self):
        data = {
            "name": "test",
            "steps": [{"name": "s1"}],
        }
        p = dict_to_pipeline(data, step_registry={"s1": lambda ctx: 42})
        result = p.run()
        assert result.success

    def test_placeholder_raises(self):
        data = {
            "name": "test",
            "steps": [{"name": "s1"}],
        }
        p = dict_to_pipeline(data)
        result = p.run()
        assert not result.success

    def test_with_retry(self):
        data = {
            "name": "test",
            "steps": [{"name": "s1", "retry": {"max_retries": 5, "base_delay": 0.5}}],
        }
        p = dict_to_pipeline(data, step_registry={"s1": lambda ctx: 42})
        assert p.get_step("s1").retry_policy.max_retries == 5

    def test_with_tags(self):
        data = {
            "name": "test",
            "steps": [{"name": "s1", "tags": ["etl", "fast"]}],
        }
        p = dict_to_pipeline(data, step_registry={"s1": lambda ctx: 42})
        assert p.get_step("s1").tags == ["etl", "fast"]

    def test_options(self):
        data = {
            "name": "test",
            "max_concurrency": 8,
            "fail_fast": False,
            "description": "my desc",
            "steps": [],
        }
        p = dict_to_pipeline(data)
        assert p.max_concurrency == 8
        assert p.fail_fast is False
        assert p.description == "my desc"


class TestJsonToPipeline:
    def test_basic(self):
        j = '{"name": "test", "steps": [{"name": "s1"}]}'
        p = json_to_pipeline(j, step_registry={"s1": lambda ctx: 42})
        assert p.name == "test"
        result = p.run()
        assert result.success


class TestValidateDefinition:
    def test_valid(self):
        data = {
            "name": "test",
            "steps": [{"name": "s1"}, {"name": "s2", "depends_on": ["s1"]}],
        }
        assert validate_definition(data) == []

    def test_missing_name(self):
        errors = validate_definition({"steps": []})
        assert any("name" in e for e in errors)

    def test_name_not_string(self):
        errors = validate_definition({"name": 123, "steps": []})
        assert any("string" in e for e in errors)

    def test_missing_steps(self):
        errors = validate_definition({"name": "test"})
        assert any("steps" in e for e in errors)

    def test_steps_not_list(self):
        errors = validate_definition({"name": "test", "steps": "bad"})
        assert any("list" in e for e in errors)

    def test_step_not_dict(self):
        errors = validate_definition({"name": "test", "steps": ["bad"]})
        assert any("dictionary" in e for e in errors)

    def test_step_missing_name(self):
        errors = validate_definition({"name": "test", "steps": [{}]})
        assert any("name" in e for e in errors)

    def test_duplicate_step_name(self):
        errors = validate_definition({
            "name": "test",
            "steps": [{"name": "s1"}, {"name": "s1"}],
        })
        assert any("Duplicate" in e for e in errors)

    def test_depends_on_not_list(self):
        errors = validate_definition({
            "name": "test",
            "steps": [{"name": "s1", "depends_on": "bad"}],
        })
        assert any("list" in e for e in errors)

    def test_retry_not_dict(self):
        errors = validate_definition({
            "name": "test",
            "steps": [{"name": "s1", "retry": "bad"}],
        })
        assert any("dictionary" in e for e in errors)

    def test_retry_max_not_int(self):
        errors = validate_definition({
            "name": "test",
            "steps": [{"name": "s1", "retry": {"max_retries": "bad"}}],
        })
        assert any("int" in e for e in errors)

    def test_roundtrip_validation(self):
        p = Pipeline("test")
        p.add_step(Step("a", lambda ctx: None))
        p.add_step(Step("b", lambda ctx: None, depends_on=["a"]))
        d = pipeline_to_dict(p)
        assert validate_definition(d) == []
