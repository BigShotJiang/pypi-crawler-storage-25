"""Tests for pipechain.errors module."""

import pytest
from pipechain.errors import (
    PipechainError, StepExecutionError, PipelineValidationError,
    StepTimeoutError, DependencyError, CycleDetectedError,
    ContextError, SerializationError,
)


class TestPipechainError:
    def test_base_error(self):
        e = PipechainError("test")
        assert str(e) == "test"
        assert isinstance(e, Exception)


class TestStepExecutionError:
    def test_basic(self):
        orig = ValueError("bad value")
        e = StepExecutionError("s1", orig, attempt=2)
        assert e.step_name == "s1"
        assert e.original_error is orig
        assert e.attempt == 2
        assert "s1" in str(e)
        assert "attempt 2" in str(e)

    def test_default_attempt(self):
        e = StepExecutionError("s1", ValueError())
        assert e.attempt == 0

    def test_is_pipechain_error(self):
        e = StepExecutionError("s1", ValueError())
        assert isinstance(e, PipechainError)


class TestPipelineValidationError:
    def test_basic(self):
        e = PipelineValidationError("pipe", ["err1", "err2"])
        assert e.pipeline_name == "pipe"
        assert e.errors == ["err1", "err2"]
        assert "pipe" in str(e)
        assert "err1" in str(e)
        assert "err2" in str(e)

    def test_single_error(self):
        e = PipelineValidationError("pipe", ["only one"])
        assert len(e.errors) == 1


class TestStepTimeoutError:
    def test_basic(self):
        e = StepTimeoutError("s1", 5.0)
        assert e.step_name == "s1"
        assert e.timeout == 5.0
        assert "5.0s" in str(e)


class TestDependencyError:
    def test_basic(self):
        e = DependencyError("s2", "s1")
        assert e.step_name == "s2"
        assert e.missing_dep == "s1"
        assert "s2" in str(e)
        assert "s1" in str(e)


class TestCycleDetectedError:
    def test_basic(self):
        e = CycleDetectedError(["a", "b", "a"])
        assert e.cycle == ["a", "b", "a"]
        assert "a -> b -> a" in str(e)


class TestContextError:
    def test_basic(self):
        e = ContextError("bad context")
        assert isinstance(e, PipechainError)


class TestSerializationError:
    def test_basic(self):
        e = SerializationError("bad data", data={"key": "val"})
        assert e.data == {"key": "val"}
        assert "bad data" in str(e)

    def test_no_data(self):
        e = SerializationError("error")
        assert e.data is None
