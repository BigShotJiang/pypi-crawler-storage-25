"""Tests for pipechain.step module."""

import asyncio
import pytest
from pipechain.step import Step, step
from pipechain.context import Context
from pipechain.retry import RetryPolicy


class TestStepCreation:
    def test_basic_step(self):
        def fn(ctx): return 42
        s = Step("test", fn)
        assert s.name == "test"
        assert s.depends_on == []
        assert s.is_async is False

    def test_async_step(self):
        async def fn(ctx): return 42
        s = Step("test", fn)
        assert s.is_async is True

    def test_with_dependencies(self):
        s = Step("test", lambda ctx: None, depends_on=["a", "b"])
        assert s.depends_on == ["a", "b"]

    def test_with_retry_policy(self):
        p = RetryPolicy(max_retries=5)
        s = Step("test", lambda ctx: None, retry_policy=p)
        assert s.retry_policy.max_retries == 5

    def test_default_no_retry(self):
        s = Step("test", lambda ctx: None)
        assert s.retry_policy.max_retries == 0

    def test_with_tags(self):
        s = Step("test", lambda ctx: None, tags=["etl", "slow"])
        assert s.tags == ["etl", "slow"]

    def test_with_description(self):
        s = Step("test", lambda ctx: None, description="My step")
        assert s.description == "My step"

    def test_description_from_docstring(self):
        def fn(ctx):
            """My docstring"""
            pass
        s = Step("test", fn)
        assert s.description == "My docstring"

    def test_with_timeout(self):
        s = Step("test", lambda ctx: None, timeout=5.0)
        assert s.timeout == 5.0

    def test_repr(self):
        s = Step("test", lambda ctx: None, depends_on=["a"])
        r = repr(s)
        assert "test" in r
        assert "depends_on" in r

    def test_repr_no_deps(self):
        s = Step("test", lambda ctx: None)
        r = repr(s)
        assert "test" in r
        assert "depends_on" not in r


class TestStepExecution:
    @pytest.mark.asyncio
    async def test_sync_execution(self):
        def fn(ctx):
            return ctx.get("input", 0) + 1
        s = Step("test", fn)
        ctx = Context({"input": 41})
        result = await s.execute(ctx)
        assert result == 42

    @pytest.mark.asyncio
    async def test_async_execution(self):
        async def fn(ctx):
            return ctx.get("input", 0) + 1
        s = Step("test", fn)
        ctx = Context({"input": 41})
        result = await s.execute(ctx)
        assert result == 42

    @pytest.mark.asyncio
    async def test_sync_exception(self):
        def fn(ctx):
            raise ValueError("boom")
        s = Step("test", fn)
        with pytest.raises(ValueError, match="boom"):
            await s.execute(Context())

    @pytest.mark.asyncio
    async def test_async_exception(self):
        async def fn(ctx):
            raise ValueError("boom")
        s = Step("test", fn)
        with pytest.raises(ValueError, match="boom"):
            await s.execute(Context())

    @pytest.mark.asyncio
    async def test_timeout(self):
        async def slow(ctx):
            await asyncio.sleep(10)
        s = Step("test", slow, timeout=0.05)
        with pytest.raises(asyncio.TimeoutError):
            await s.execute(Context())


class TestStepCondition:
    def test_no_condition_always_runs(self):
        s = Step("test", lambda ctx: None)
        assert s.should_run(Context()) is True

    def test_condition_true(self):
        s = Step("test", lambda ctx: None, condition=lambda ctx: True)
        assert s.should_run(Context()) is True

    def test_condition_false(self):
        s = Step("test", lambda ctx: None, condition=lambda ctx: False)
        assert s.should_run(Context()) is False

    def test_condition_uses_context(self):
        s = Step(
            "test", lambda ctx: None,
            condition=lambda ctx: ctx.get("enabled", False),
        )
        assert s.should_run(Context()) is False
        assert s.should_run(Context({"enabled": True})) is True


class TestStepCacheKey:
    def test_no_cache_key(self):
        s = Step("test", lambda ctx: None)
        assert s.get_cache_key(Context()) is None

    def test_static_cache_key(self):
        s = Step("test", lambda ctx: None, cache_key="my_key")
        assert s.get_cache_key(Context()) == "my_key"


class TestStepDecorator:
    def test_basic_decorator(self):
        @step()
        def my_step(ctx):
            return 42
        assert isinstance(my_step, Step)
        assert my_step.name == "my_step"

    def test_decorator_with_name(self):
        @step(name="custom_name")
        def my_step(ctx):
            return 42
        assert my_step.name == "custom_name"

    def test_decorator_with_depends(self):
        @step(depends_on=["a", "b"])
        def my_step(ctx):
            pass
        assert my_step.depends_on == ["a", "b"]

    def test_decorator_with_retry_int(self):
        @step(retry=3)
        def my_step(ctx):
            pass
        assert my_step.retry_policy.max_retries == 3

    def test_decorator_with_retry_policy(self):
        @step(retry=RetryPolicy.exponential(max_retries=5))
        def my_step(ctx):
            pass
        assert my_step.retry_policy.max_retries == 5

    def test_decorator_with_tags(self):
        @step(tags=["etl"])
        def my_step(ctx):
            pass
        assert my_step.tags == ["etl"]

    def test_decorator_with_cache(self):
        @step(cache_key="my_key", cache_ttl=60)
        def my_step(ctx):
            pass
        assert my_step.cache_key == "my_key"
        assert my_step.cache_ttl == 60

    def test_decorator_async(self):
        @step()
        async def my_step(ctx):
            pass
        assert my_step.is_async is True

    def test_decorator_preserves_name(self):
        @step()
        def my_step(ctx):
            """My doc"""
            pass
        assert my_step.__doc__ == "My doc"
