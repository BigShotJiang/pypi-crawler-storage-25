"""Tests for pipechain.groups module."""

import pytest
from pipechain.groups import StepGroup, GroupRegistry


class TestStepGroup:
    def test_create(self):
        g = StepGroup("etl")
        assert g.name == "etl"
        assert len(g) == 0

    def test_add(self):
        g = StepGroup("etl")
        g.add("s1", "s2")
        assert len(g) == 2

    def test_add_chaining(self):
        g = StepGroup("etl").add("s1").add("s2")
        assert len(g) == 2

    def test_remove(self):
        g = StepGroup("etl")
        g.add("s1")
        assert g.remove("s1") is True
        assert len(g) == 0

    def test_remove_nonexistent(self):
        g = StepGroup("etl")
        assert g.remove("s1") is False

    def test_contains(self):
        g = StepGroup("etl")
        g.add("s1")
        assert g.contains("s1") is True
        assert g.contains("s2") is False

    def test_step_names(self):
        g = StepGroup("etl")
        g.add("s1", "s2")
        assert g.step_names == {"s1", "s2"}

    def test_description(self):
        g = StepGroup("etl", description="Extract-Transform-Load")
        assert g.description == "Extract-Transform-Load"

    def test_repr(self):
        g = StepGroup("etl")
        g.add("s1")
        assert "etl" in repr(g)

    def test_deduplicate(self):
        g = StepGroup("etl")
        g.add("s1", "s1", "s1")
        assert len(g) == 1


class TestGroupRegistry:
    def test_create(self):
        reg = GroupRegistry()
        g = reg.create("etl")
        assert isinstance(g, StepGroup)
        assert g.name == "etl"

    def test_create_duplicate(self):
        reg = GroupRegistry()
        reg.create("etl")
        with pytest.raises(ValueError, match="already exists"):
            reg.create("etl")

    def test_get(self):
        reg = GroupRegistry()
        reg.create("etl")
        assert reg.get("etl") is not None
        assert reg.get("nope") is None

    def test_delete(self):
        reg = GroupRegistry()
        reg.create("etl")
        assert reg.delete("etl") is True
        assert reg.get("etl") is None

    def test_delete_nonexistent(self):
        reg = GroupRegistry()
        assert reg.delete("nope") is False

    def test_list_groups(self):
        reg = GroupRegistry()
        reg.create("a")
        reg.create("b")
        assert len(reg.list_groups()) == 2

    def test_groups_for_step(self):
        reg = GroupRegistry()
        g1 = reg.create("a")
        g1.add("s1", "s2")
        g2 = reg.create("b")
        g2.add("s2", "s3")
        groups = reg.groups_for_step("s2")
        names = {g.name for g in groups}
        assert names == {"a", "b"}

    def test_groups_for_step_none(self):
        reg = GroupRegistry()
        assert reg.groups_for_step("s1") == []

    def test_steps_in_groups(self):
        reg = GroupRegistry()
        g1 = reg.create("a")
        g1.add("s1")
        g2 = reg.create("b")
        g2.add("s2")
        steps = reg.steps_in_groups("a", "b")
        assert steps == {"s1", "s2"}

    def test_steps_in_groups_unknown(self):
        reg = GroupRegistry()
        assert reg.steps_in_groups("nope") == set()

    def test_len(self):
        reg = GroupRegistry()
        assert len(reg) == 0
        reg.create("a")
        assert len(reg) == 1

    def test_contains(self):
        reg = GroupRegistry()
        reg.create("a")
        assert "a" in reg
        assert "b" not in reg
