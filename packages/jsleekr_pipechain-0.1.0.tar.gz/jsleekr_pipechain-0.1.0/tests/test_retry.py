"""Tests for pipechain.retry module."""

import pytest
import time
from pipechain.retry import RetryPolicy


class TestRetryPolicyConfig:
    def test_default_values(self):
        p = RetryPolicy()
        assert p.max_retries == 3
        assert p.base_delay == 1.0
        assert p.max_delay == 60.0
        assert p.exponential_base == 2.0
        assert p.jitter is True

    def test_none_policy(self):
        p = RetryPolicy.none()
        assert p.max_retries == 0

    def test_linear_policy(self):
        p = RetryPolicy.linear(max_retries=5, delay=2.0)
        assert p.max_retries == 5
        assert p.exponential_base == 1.0
        assert p.jitter is False

    def test_exponential_policy(self):
        p = RetryPolicy.exponential(max_retries=4, base_delay=0.5, max_delay=30.0)
        assert p.max_retries == 4
        assert p.base_delay == 0.5
        assert p.max_delay == 30.0


class TestRetryPolicyShouldRetry:
    def test_should_retry_within_limit(self):
        p = RetryPolicy(max_retries=3)
        assert p.should_retry(ValueError(), 0) is True
        assert p.should_retry(ValueError(), 1) is True
        assert p.should_retry(ValueError(), 2) is True

    def test_should_not_retry_at_limit(self):
        p = RetryPolicy(max_retries=3)
        assert p.should_retry(ValueError(), 3) is False

    def test_no_retry_on_excluded(self):
        p = RetryPolicy(max_retries=3, no_retry_on=(TypeError,))
        assert p.should_retry(TypeError(), 0) is False

    def test_retry_only_on_specified(self):
        p = RetryPolicy(max_retries=3, retry_on=(ValueError,))
        assert p.should_retry(ValueError(), 0) is True
        assert p.should_retry(TypeError(), 0) is False

    def test_no_retry_zero_max(self):
        p = RetryPolicy(max_retries=0)
        assert p.should_retry(ValueError(), 0) is False

    def test_keyboard_interrupt_never_retried(self):
        p = RetryPolicy(max_retries=3)
        assert p.should_retry(KeyboardInterrupt(), 0) is False

    def test_system_exit_never_retried(self):
        p = RetryPolicy(max_retries=3)
        assert p.should_retry(SystemExit(), 0) is False


class TestRetryPolicyDelay:
    def test_exponential_delay(self):
        p = RetryPolicy(base_delay=1.0, exponential_base=2.0, jitter=False)
        assert p.get_delay(0) == 1.0
        assert p.get_delay(1) == 2.0
        assert p.get_delay(2) == 4.0

    def test_max_delay_cap(self):
        p = RetryPolicy(base_delay=1.0, exponential_base=2.0, max_delay=5.0, jitter=False)
        assert p.get_delay(10) == 5.0

    def test_linear_delay(self):
        p = RetryPolicy.linear(delay=2.0)
        assert p.get_delay(0) == 2.0
        assert p.get_delay(1) == 2.0
        assert p.get_delay(5) == 2.0

    def test_jitter_in_range(self):
        p = RetryPolicy(base_delay=1.0, exponential_base=1.0, jitter=True)
        for _ in range(50):
            delay = p.get_delay(0)
            assert 0.5 <= delay <= 1.0

    def test_wait_sync(self):
        p = RetryPolicy(base_delay=0.01, exponential_base=1.0, jitter=False)
        start = time.time()
        p.wait(0)
        elapsed = time.time() - start
        assert elapsed >= 0.005  # At least some delay


class TestRetryPolicyAsync:
    @pytest.mark.asyncio
    async def test_async_wait(self):
        p = RetryPolicy(base_delay=0.01, exponential_base=1.0, jitter=False)
        start = time.time()
        await p.async_wait(0)
        elapsed = time.time() - start
        assert elapsed >= 0.005
