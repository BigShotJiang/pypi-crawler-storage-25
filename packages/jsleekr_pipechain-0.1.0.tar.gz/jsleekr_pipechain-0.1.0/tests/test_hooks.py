"""Tests for pipechain.hooks module."""

import pytest
from pipechain.hooks import HookType, Hook, HookRegistry


class TestHookType:
    def test_all_values(self):
        types = [
            HookType.BEFORE_PIPELINE, HookType.AFTER_PIPELINE,
            HookType.BEFORE_STEP, HookType.AFTER_STEP,
            HookType.ON_STEP_ERROR, HookType.ON_STEP_RETRY,
            HookType.ON_STEP_SKIP, HookType.ON_STEP_CACHED,
        ]
        assert len(types) == 8
        assert all(isinstance(t.value, str) for t in types)


class TestHook:
    def test_create_hook(self):
        def cb(**kwargs): pass
        h = Hook(hook_type=HookType.BEFORE_STEP, callback=cb, name="test")
        assert h.hook_type == HookType.BEFORE_STEP
        assert h.name == "test"

    def test_repr(self):
        def my_func(**kwargs): pass
        h = Hook(hook_type=HookType.BEFORE_STEP, callback=my_func)
        assert "before_step" in repr(h)

    def test_repr_with_name(self):
        h = Hook(hook_type=HookType.BEFORE_STEP, callback=lambda **kw: None, name="custom")
        assert "custom" in repr(h)

    def test_default_priority(self):
        h = Hook(hook_type=HookType.BEFORE_STEP, callback=lambda **kw: None)
        assert h.priority == 0


class TestHookRegistry:
    def test_register(self):
        reg = HookRegistry()
        h = reg.register(HookType.BEFORE_STEP, lambda **kw: None)
        assert isinstance(h, Hook)
        assert reg.count(HookType.BEFORE_STEP) == 1

    def test_unregister(self):
        reg = HookRegistry()
        h = reg.register(HookType.BEFORE_STEP, lambda **kw: None)
        assert reg.unregister(h) is True
        assert reg.count(HookType.BEFORE_STEP) == 0

    def test_unregister_nonexistent(self):
        reg = HookRegistry()
        h = Hook(hook_type=HookType.BEFORE_STEP, callback=lambda **kw: None)
        assert reg.unregister(h) is False

    def test_get_hooks(self):
        reg = HookRegistry()
        reg.register(HookType.BEFORE_STEP, lambda **kw: None)
        reg.register(HookType.BEFORE_STEP, lambda **kw: None)
        assert len(reg.get_hooks(HookType.BEFORE_STEP)) == 2

    def test_get_hooks_empty(self):
        reg = HookRegistry()
        assert len(reg.get_hooks(HookType.BEFORE_STEP)) == 0

    def test_fire(self):
        reg = HookRegistry()
        results = []
        reg.register(HookType.BEFORE_STEP, lambda **kw: results.append("a"))
        reg.register(HookType.BEFORE_STEP, lambda **kw: results.append("b"))
        reg.fire(HookType.BEFORE_STEP)
        assert results == ["a", "b"]

    def test_fire_with_kwargs(self):
        reg = HookRegistry()
        received = {}
        def cb(**kwargs):
            received.update(kwargs)
        reg.register(HookType.BEFORE_STEP, cb)
        reg.fire(HookType.BEFORE_STEP, step_name="s1", value=42)
        assert received["step_name"] == "s1"
        assert received["value"] == 42

    def test_fire_returns_values(self):
        reg = HookRegistry()
        reg.register(HookType.BEFORE_STEP, lambda **kw: 1)
        reg.register(HookType.BEFORE_STEP, lambda **kw: 2)
        results = reg.fire(HookType.BEFORE_STEP)
        assert results == [1, 2]

    def test_priority_ordering(self):
        reg = HookRegistry()
        order = []
        reg.register(HookType.BEFORE_STEP, lambda **kw: order.append("b"), priority=10)
        reg.register(HookType.BEFORE_STEP, lambda **kw: order.append("a"), priority=0)
        reg.fire(HookType.BEFORE_STEP)
        assert order == ["a", "b"]

    def test_clear_specific_type(self):
        reg = HookRegistry()
        reg.register(HookType.BEFORE_STEP, lambda **kw: None)
        reg.register(HookType.AFTER_STEP, lambda **kw: None)
        reg.clear(HookType.BEFORE_STEP)
        assert reg.count(HookType.BEFORE_STEP) == 0
        assert reg.count(HookType.AFTER_STEP) == 1

    def test_clear_all(self):
        reg = HookRegistry()
        reg.register(HookType.BEFORE_STEP, lambda **kw: None)
        reg.register(HookType.AFTER_STEP, lambda **kw: None)
        reg.clear()
        assert reg.count() == 0

    def test_count_total(self):
        reg = HookRegistry()
        reg.register(HookType.BEFORE_STEP, lambda **kw: None)
        reg.register(HookType.AFTER_STEP, lambda **kw: None)
        reg.register(HookType.ON_STEP_ERROR, lambda **kw: None)
        assert reg.count() == 3

    @pytest.mark.asyncio
    async def test_async_fire(self):
        reg = HookRegistry()
        results = []
        reg.register(HookType.BEFORE_STEP, lambda **kw: results.append("sync"))

        async def async_hook(**kw):
            results.append("async")

        reg.register(HookType.BEFORE_STEP, async_hook)
        await reg.async_fire(HookType.BEFORE_STEP)
        assert results == ["sync", "async"]
