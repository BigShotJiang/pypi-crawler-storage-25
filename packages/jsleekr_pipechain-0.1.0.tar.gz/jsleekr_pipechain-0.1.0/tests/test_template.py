"""Tests for pipechain.template module."""

import pytest
from pipechain.template import PipelineTemplate, clone_pipeline
from pipechain.pipeline import Pipeline
from pipechain.step import Step
from pipechain.context import Context
from pipechain.retry import RetryPolicy


class TestPipelineTemplate:
    def test_basic(self):
        tmpl = PipelineTemplate("etl")
        tmpl.add_slot("extract")
        tmpl.add_slot("transform", depends_on=["extract"])
        tmpl.add_slot("load", depends_on=["transform"])
        assert tmpl.slots == ["extract", "transform", "load"]

    def test_instantiate_with_impls(self):
        tmpl = PipelineTemplate("etl")
        tmpl.add_slot("extract")
        tmpl.add_slot("load", depends_on=["extract"])

        pipe = tmpl.instantiate({
            "extract": lambda ctx: [1, 2, 3],
            "load": lambda ctx: ctx.get("extract.output"),
        })
        result = pipe.run()
        assert result.success

    def test_instantiate_missing_impl(self):
        tmpl = PipelineTemplate("etl")
        tmpl.add_slot("extract")
        pipe = tmpl.instantiate()
        result = pipe.run()
        assert not result.success  # Placeholder raises

    def test_defaults(self):
        tmpl = PipelineTemplate("etl")
        tmpl.add_slot("extract")
        tmpl.set_default("extract", lambda ctx: 42)
        pipe = tmpl.instantiate()
        result = pipe.run()
        assert result.success

    def test_override_default(self):
        tmpl = PipelineTemplate("etl")
        tmpl.add_slot("extract")
        tmpl.set_default("extract", lambda ctx: 42)
        pipe = tmpl.instantiate({"extract": lambda ctx: 99})
        ctx = Context()
        pipe.run(context=ctx)
        assert ctx.get("extract.output") == 99

    def test_name_suffix(self):
        tmpl = PipelineTemplate("etl")
        tmpl.add_slot("extract")
        tmpl.set_default("extract", lambda ctx: 1)
        pipe = tmpl.instantiate(name_suffix="_v2")
        assert pipe.name == "etl_v2"

    def test_with_tags(self):
        tmpl = PipelineTemplate("etl")
        tmpl.add_slot("extract", tags=["io"])
        tmpl.set_default("extract", lambda ctx: 1)
        pipe = tmpl.instantiate()
        assert pipe.get_step("extract").tags == ["io"]

    def test_with_retry(self):
        tmpl = PipelineTemplate("etl")
        tmpl.add_slot("extract", retry=3)
        tmpl.set_default("extract", lambda ctx: 1)
        pipe = tmpl.instantiate()
        assert pipe.get_step("extract").retry_policy.max_retries == 3

    def test_with_timeout(self):
        tmpl = PipelineTemplate("etl")
        tmpl.add_slot("extract", timeout=5.0)
        tmpl.set_default("extract", lambda ctx: 1)
        pipe = tmpl.instantiate()
        assert pipe.get_step("extract").timeout == 5.0

    def test_unfilled_slots(self):
        tmpl = PipelineTemplate("etl")
        tmpl.add_slot("a")
        tmpl.add_slot("b")
        tmpl.set_default("a", lambda ctx: 1)
        assert tmpl.unfilled_slots == ["b"]

    def test_chaining(self):
        tmpl = (
            PipelineTemplate("etl")
            .add_slot("a")
            .add_slot("b", depends_on=["a"])
            .set_default("a", lambda ctx: 1)
            .set_default("b", lambda ctx: 2)
        )
        pipe = tmpl.instantiate()
        result = pipe.run()
        assert result.success

    def test_repr(self):
        tmpl = PipelineTemplate("etl")
        tmpl.add_slot("a")
        assert "etl" in repr(tmpl)

    def test_pipeline_kwargs(self):
        tmpl = PipelineTemplate("etl")
        tmpl.add_slot("a")
        tmpl.set_default("a", lambda ctx: 1)
        pipe = tmpl.instantiate(max_concurrency=8)
        assert pipe.max_concurrency == 8


class TestClonePipeline:
    def test_basic_clone(self):
        orig = Pipeline("test")
        orig.add_step(Step("s1", lambda ctx: 42))
        clone = clone_pipeline(orig)
        assert clone.name == "test_clone"
        assert len(clone.steps) == 1

    def test_custom_name(self):
        orig = Pipeline("test")
        orig.add_step(Step("s1", lambda ctx: 42))
        clone = clone_pipeline(orig, new_name="test_v2")
        assert clone.name == "test_v2"

    def test_override_step(self):
        orig = Pipeline("test")
        orig.add_step(Step("s1", lambda ctx: 42))
        clone = clone_pipeline(orig, step_overrides={"s1": lambda ctx: 99})
        ctx = Context()
        clone.run(context=ctx)
        assert ctx.get("s1.output") == 99

    def test_preserves_deps(self):
        orig = Pipeline("test")
        orig.add_step(Step("a", lambda ctx: 1))
        orig.add_step(Step("b", lambda ctx: 2, depends_on=["a"]))
        clone = clone_pipeline(orig)
        assert clone.get_step("b").depends_on == ["a"]

    def test_preserves_tags(self):
        orig = Pipeline("test")
        orig.add_step(Step("a", lambda ctx: 1, tags=["etl"]))
        clone = clone_pipeline(orig)
        assert clone.get_step("a").tags == ["etl"]

    def test_preserves_config(self):
        orig = Pipeline("test", max_concurrency=8, fail_fast=False)
        orig.add_step(Step("s1", lambda ctx: 1))
        clone = clone_pipeline(orig)
        assert clone.max_concurrency == 8
        assert clone.fail_fast is False

    def test_independent_execution(self):
        orig = Pipeline("test")
        orig.add_step(Step("s1", lambda ctx: 1))

        clone = clone_pipeline(orig)
        ctx1, ctx2 = Context(), Context()
        orig.run(context=ctx1)
        clone.run(context=ctx2)
        assert ctx1.get("s1.output") == 1
        assert ctx2.get("s1.output") == 1
