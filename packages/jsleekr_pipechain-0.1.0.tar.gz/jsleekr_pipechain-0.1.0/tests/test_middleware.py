"""Tests for pipechain.middleware module."""

import logging
import pytest
from pipechain.middleware import (
    Middleware, LoggingMiddleware, TimingMiddleware,
    ValidatorMiddleware, TransformMiddleware, MiddlewareChain,
)
from pipechain.step import Step
from pipechain.context import Context


class TestMiddleware:
    @pytest.mark.asyncio
    async def test_base_middleware_passthrough(self):
        m = Middleware()
        s = Step("test", lambda ctx: 42)
        ctx = Context()
        result = await m(s, ctx, self._make_async(42))
        assert result == 42

    @pytest.mark.asyncio
    async def test_middleware_name(self):
        m = Middleware("custom")
        assert m.name == "custom"

    @pytest.mark.asyncio
    async def test_middleware_default_name(self):
        m = Middleware()
        assert m.name == "Middleware"

    def test_repr(self):
        m = Middleware("test")
        assert "test" in repr(m)

    @staticmethod
    def _make_async(value):
        async def fn():
            return value
        return fn


class TestLoggingMiddleware:
    @pytest.mark.asyncio
    async def test_logs_success(self, caplog):
        m = LoggingMiddleware()
        s = Step("my_step", lambda ctx: 42)
        ctx = Context()
        with caplog.at_level(logging.INFO, logger="pipechain.steps"):
            result = await m(s, ctx, self._make_async(42))
        assert result == 42
        assert any("Starting" in r.message and "my_step" in r.message for r in caplog.records)
        assert any("Completed" in r.message and "my_step" in r.message for r in caplog.records)

    @pytest.mark.asyncio
    async def test_logs_failure(self, caplog):
        m = LoggingMiddleware()
        s = Step("fail_step", lambda ctx: None)
        ctx = Context()

        async def fail():
            raise ValueError("boom")

        with caplog.at_level(logging.ERROR, logger="pipechain.steps"):
            with pytest.raises(ValueError):
                await m(s, ctx, fail)
        assert any("Failed" in r.message for r in caplog.records)

    @staticmethod
    def _make_async(value):
        async def fn():
            return value
        return fn


class TestTimingMiddleware:
    @pytest.mark.asyncio
    async def test_stores_timing(self):
        m = TimingMiddleware()
        s = Step("timed", lambda ctx: 42)
        ctx = Context()

        async def fn():
            return 42

        await m(s, ctx, fn)
        assert ctx.has("timed.duration_ms")
        assert ctx.get("timed.duration_ms") >= 0


class TestValidatorMiddleware:
    @pytest.mark.asyncio
    async def test_input_valid(self):
        m = ValidatorMiddleware(input_validator=lambda ctx: ctx.has("required"))
        s = Step("test", lambda ctx: 42)
        ctx = Context({"required": True})

        async def fn():
            return 42

        result = await m(s, ctx, fn)
        assert result == 42

    @pytest.mark.asyncio
    async def test_input_invalid(self):
        m = ValidatorMiddleware(input_validator=lambda ctx: ctx.has("required"))
        s = Step("test", lambda ctx: 42)
        ctx = Context()

        async def fn():
            return 42

        with pytest.raises(ValueError, match="Input validation failed"):
            await m(s, ctx, fn)

    @pytest.mark.asyncio
    async def test_output_valid(self):
        m = ValidatorMiddleware(output_validator=lambda x: x > 0)
        s = Step("test", lambda ctx: 42)
        ctx = Context()

        async def fn():
            return 42

        result = await m(s, ctx, fn)
        assert result == 42

    @pytest.mark.asyncio
    async def test_output_invalid(self):
        m = ValidatorMiddleware(output_validator=lambda x: x > 0)
        s = Step("test", lambda ctx: -1)
        ctx = Context()

        async def fn():
            return -1

        with pytest.raises(ValueError, match="Output validation failed"):
            await m(s, ctx, fn)

    @pytest.mark.asyncio
    async def test_no_validators(self):
        m = ValidatorMiddleware()
        s = Step("test", lambda ctx: 42)
        ctx = Context()

        async def fn():
            return 42

        result = await m(s, ctx, fn)
        assert result == 42


class TestTransformMiddleware:
    @pytest.mark.asyncio
    async def test_transforms_output(self):
        m = TransformMiddleware(lambda x: x * 2)
        s = Step("test", lambda ctx: 21)
        ctx = Context()

        async def fn():
            return 21

        result = await m(s, ctx, fn)
        assert result == 42

    @pytest.mark.asyncio
    async def test_transforms_to_string(self):
        m = TransformMiddleware(str)
        s = Step("test", lambda ctx: 42)
        ctx = Context()

        async def fn():
            return 42

        result = await m(s, ctx, fn)
        assert result == "42"


class TestMiddlewareChain:
    @pytest.mark.asyncio
    async def test_empty_chain(self):
        chain = MiddlewareChain()

        async def fn():
            return 42

        s = Step("test", lambda ctx: 42)
        result = await chain.execute(s, Context(), fn)
        assert result == 42

    @pytest.mark.asyncio
    async def test_single_middleware(self):
        chain = MiddlewareChain()
        chain.use(TransformMiddleware(lambda x: x * 2))

        async def fn():
            return 21

        s = Step("test", lambda ctx: 21)
        result = await chain.execute(s, Context(), fn)
        assert result == 42

    @pytest.mark.asyncio
    async def test_chained_middlewares(self):
        chain = MiddlewareChain()
        chain.use(TransformMiddleware(lambda x: x + 1))  # Applied second
        chain.use(TransformMiddleware(lambda x: x * 2))  # Applied first

        async def fn():
            return 10

        s = Step("test", lambda ctx: 10)
        result = await chain.execute(s, Context(), fn)
        # fn() -> 10, inner transform: 10*2=20, outer transform: 20+1=21
        assert result == 21

    @pytest.mark.asyncio
    async def test_fluent_api(self):
        chain = (
            MiddlewareChain()
            .use(TimingMiddleware())
            .use(TransformMiddleware(str))
        )
        assert chain.count == 2

    def test_count(self):
        chain = MiddlewareChain()
        assert chain.count == 0
        chain.use(Middleware())
        assert chain.count == 1

    def test_repr(self):
        chain = MiddlewareChain()
        chain.use(Middleware("a"))
        chain.use(Middleware("b"))
        r = repr(chain)
        assert "a" in r
        assert "b" in r

    @pytest.mark.asyncio
    async def test_middleware_order(self):
        order = []

        class TrackMiddleware(Middleware):
            async def __call__(self, step, ctx, next_fn):
                order.append(f"before:{self.name}")
                result = await next_fn()
                order.append(f"after:{self.name}")
                return result

        chain = MiddlewareChain()
        chain.use(TrackMiddleware("outer"))
        chain.use(TrackMiddleware("inner"))

        async def fn():
            order.append("execute")
            return 42

        s = Step("test", lambda ctx: 42)
        await chain.execute(s, Context(), fn)
        assert order == ["before:outer", "before:inner", "execute", "after:inner", "after:outer"]
