"""Tests for pipechain.cache module."""

import os
import time
import tempfile
import pytest
from pipechain.cache import CacheBackend, MemoryCache, FileCache


class TestMemoryCache:
    def test_set_and_get(self):
        c = MemoryCache()
        c.set("k", "v")
        hit, val = c.get("k")
        assert hit is True
        assert val == "v"

    def test_get_miss(self):
        c = MemoryCache()
        hit, val = c.get("missing")
        assert hit is False
        assert val is None

    def test_has(self):
        c = MemoryCache()
        c.set("k", "v")
        assert c.has("k") is True
        assert c.has("missing") is False

    def test_delete(self):
        c = MemoryCache()
        c.set("k", "v")
        assert c.delete("k") is True
        assert c.has("k") is False

    def test_delete_nonexistent(self):
        c = MemoryCache()
        assert c.delete("k") is False

    def test_clear(self):
        c = MemoryCache()
        c.set("a", 1)
        c.set("b", 2)
        count = c.clear()
        assert count == 2
        assert c.size == 0

    def test_ttl_not_expired(self):
        c = MemoryCache()
        c.set("k", "v", ttl=10.0)
        hit, val = c.get("k")
        assert hit is True
        assert val == "v"

    def test_ttl_expired(self):
        c = MemoryCache()
        c.set("k", "v", ttl=0.01)
        time.sleep(0.02)
        hit, val = c.get("k")
        assert hit is False

    def test_ttl_has_expired(self):
        c = MemoryCache()
        c.set("k", "v", ttl=0.01)
        time.sleep(0.02)
        assert c.has("k") is False

    def test_size(self):
        c = MemoryCache()
        assert c.size == 0
        c.set("a", 1)
        assert c.size == 1

    def test_overwrite(self):
        c = MemoryCache()
        c.set("k", "v1")
        c.set("k", "v2")
        hit, val = c.get("k")
        assert val == "v2"

    def test_complex_values(self):
        c = MemoryCache()
        c.set("k", {"nested": [1, 2, 3]})
        hit, val = c.get("k")
        assert val == {"nested": [1, 2, 3]}

    def test_none_value(self):
        c = MemoryCache()
        c.set("k", None)
        hit, val = c.get("k")
        assert hit is True
        assert val is None


class TestFileCache:
    @pytest.fixture
    def cache_dir(self, tmp_path):
        return str(tmp_path / "test_cache")

    def test_set_and_get(self, cache_dir):
        c = FileCache(cache_dir)
        c.set("k", "v")
        hit, val = c.get("k")
        assert hit is True
        assert val == "v"

    def test_get_miss(self, cache_dir):
        c = FileCache(cache_dir)
        hit, val = c.get("missing")
        assert hit is False

    def test_has(self, cache_dir):
        c = FileCache(cache_dir)
        c.set("k", "v")
        assert c.has("k") is True
        assert c.has("missing") is False

    def test_delete(self, cache_dir):
        c = FileCache(cache_dir)
        c.set("k", "v")
        assert c.delete("k") is True
        assert c.has("k") is False

    def test_delete_nonexistent(self, cache_dir):
        c = FileCache(cache_dir)
        assert c.delete("missing") is False

    def test_clear(self, cache_dir):
        c = FileCache(cache_dir)
        c.set("a", 1)
        c.set("b", 2)
        count = c.clear()
        assert count == 2

    def test_ttl_not_expired(self, cache_dir):
        c = FileCache(cache_dir)
        c.set("k", "v", ttl=10.0)
        hit, val = c.get("k")
        assert hit is True

    def test_ttl_expired(self, cache_dir):
        c = FileCache(cache_dir)
        c.set("k", "v", ttl=0.01)
        time.sleep(0.02)
        hit, val = c.get("k")
        assert hit is False

    def test_complex_values(self, cache_dir):
        c = FileCache(cache_dir)
        data = {"users": [{"name": "Alice"}, {"name": "Bob"}]}
        c.set("k", data)
        hit, val = c.get("k")
        assert val == data

    def test_persistence(self, cache_dir):
        c1 = FileCache(cache_dir)
        c1.set("k", "v")
        c2 = FileCache(cache_dir)
        hit, val = c2.get("k")
        assert hit is True
        assert val == "v"

    def test_overwrite(self, cache_dir):
        c = FileCache(cache_dir)
        c.set("k", "v1")
        c.set("k", "v2")
        hit, val = c.get("k")
        assert val == "v2"


class TestCacheBackendMakeKey:
    def test_deterministic(self):
        k1 = CacheBackend.make_key("a", "b")
        k2 = CacheBackend.make_key("a", "b")
        assert k1 == k2

    def test_different_inputs(self):
        k1 = CacheBackend.make_key("a")
        k2 = CacheBackend.make_key("b")
        assert k1 != k2

    def test_key_length(self):
        k = CacheBackend.make_key("test")
        assert len(k) == 16
