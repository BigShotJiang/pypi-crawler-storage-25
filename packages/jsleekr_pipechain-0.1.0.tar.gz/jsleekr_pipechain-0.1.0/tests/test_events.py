"""Tests for pipechain.events module."""

import pytest
from pipechain.events import EventType, Event, EventEmitter


class TestEventType:
    def test_all_types_exist(self):
        assert len(EventType) == 10

    def test_values_are_strings(self):
        for et in EventType:
            assert isinstance(et.value, str)


class TestEvent:
    def test_create(self):
        e = Event(event_type=EventType.STEP_START, data={"step": "s1"})
        assert e.event_type == EventType.STEP_START
        assert e.data["step"] == "s1"

    def test_timestamp(self):
        e = Event(event_type=EventType.STEP_START)
        assert e.timestamp > 0

    def test_repr(self):
        e = Event(event_type=EventType.STEP_START, data={"step": "s1"})
        assert "step_start" in repr(e)

    def test_default_data(self):
        e = Event(event_type=EventType.STEP_START)
        assert e.data == {}


class TestEventEmitter:
    def test_emit_and_listen(self):
        emitter = EventEmitter()
        received = []
        emitter.on(EventType.STEP_START, lambda e: received.append(e))
        emitter.emit(EventType.STEP_START, step="s1")
        assert len(received) == 1
        assert received[0].data["step"] == "s1"

    def test_on_all(self):
        emitter = EventEmitter()
        received = []
        emitter.on_all(lambda e: received.append(e))
        emitter.emit(EventType.STEP_START)
        emitter.emit(EventType.STEP_END)
        assert len(received) == 2

    def test_off(self):
        emitter = EventEmitter()
        handler = lambda e: None
        emitter.on(EventType.STEP_START, handler)
        assert emitter.off(EventType.STEP_START, handler) is True
        assert emitter.listener_count(EventType.STEP_START) == 0

    def test_off_nonexistent(self):
        emitter = EventEmitter()
        assert emitter.off(EventType.STEP_START, lambda e: None) is False

    def test_off_all(self):
        emitter = EventEmitter()
        handler = lambda e: None
        emitter.on_all(handler)
        assert emitter.off_all(handler) is True

    def test_off_all_nonexistent(self):
        emitter = EventEmitter()
        assert emitter.off_all(lambda e: None) is False

    def test_history(self):
        emitter = EventEmitter()
        emitter.emit(EventType.STEP_START, step="s1")
        emitter.emit(EventType.STEP_END, step="s1")
        assert len(emitter.history) == 2

    def test_history_by_type(self):
        emitter = EventEmitter()
        emitter.emit(EventType.STEP_START, step="s1")
        emitter.emit(EventType.STEP_END, step="s1")
        emitter.emit(EventType.STEP_START, step="s2")
        starts = emitter.history_by_type(EventType.STEP_START)
        assert len(starts) == 2

    def test_history_max(self):
        emitter = EventEmitter(max_history=5)
        for i in range(10):
            emitter.emit(EventType.STEP_START, step=f"s{i}")
        assert len(emitter.history) == 5

    def test_clear_history(self):
        emitter = EventEmitter()
        emitter.emit(EventType.STEP_START)
        count = emitter.clear_history()
        assert count == 1
        assert len(emitter.history) == 0

    def test_disable(self):
        emitter = EventEmitter()
        received = []
        emitter.on(EventType.STEP_START, lambda e: received.append(e))
        emitter.disable()
        emitter.emit(EventType.STEP_START)
        assert len(received) == 0
        assert len(emitter.history) == 0

    def test_enable(self):
        emitter = EventEmitter()
        emitter.disable()
        emitter.enable()
        emitter.emit(EventType.STEP_START)
        assert len(emitter.history) == 1

    def test_enabled_property(self):
        emitter = EventEmitter()
        assert emitter.enabled is True
        emitter.disable()
        assert emitter.enabled is False

    def test_listener_count_specific(self):
        emitter = EventEmitter()
        emitter.on(EventType.STEP_START, lambda e: None)
        emitter.on(EventType.STEP_START, lambda e: None)
        assert emitter.listener_count(EventType.STEP_START) == 2

    def test_listener_count_total(self):
        emitter = EventEmitter()
        emitter.on(EventType.STEP_START, lambda e: None)
        emitter.on(EventType.STEP_END, lambda e: None)
        emitter.on_all(lambda e: None)
        assert emitter.listener_count() == 3

    def test_clear_listeners_specific(self):
        emitter = EventEmitter()
        emitter.on(EventType.STEP_START, lambda e: None)
        emitter.on(EventType.STEP_END, lambda e: None)
        emitter.clear_listeners(EventType.STEP_START)
        assert emitter.listener_count(EventType.STEP_START) == 0
        assert emitter.listener_count(EventType.STEP_END) == 1

    def test_clear_listeners_all(self):
        emitter = EventEmitter()
        emitter.on(EventType.STEP_START, lambda e: None)
        emitter.on_all(lambda e: None)
        emitter.clear_listeners()
        assert emitter.listener_count() == 0

    def test_timeline(self):
        emitter = EventEmitter()
        emitter.emit(EventType.PIPELINE_START, pipeline="test")
        emitter.emit(EventType.STEP_START, step="s1")
        tl = emitter.timeline()
        assert len(tl) == 2
        assert tl[0]["type"] == "pipeline_start"
        assert tl[0]["offset_ms"] == 0.0  # First event
        assert tl[1]["offset_ms"] >= 0.0

    def test_timeline_empty(self):
        emitter = EventEmitter()
        assert emitter.timeline() == []

    def test_multiple_listeners_same_type(self):
        emitter = EventEmitter()
        results = []
        emitter.on(EventType.STEP_START, lambda e: results.append("a"))
        emitter.on(EventType.STEP_START, lambda e: results.append("b"))
        emitter.emit(EventType.STEP_START)
        assert results == ["a", "b"]

    def test_emit_returns_event(self):
        emitter = EventEmitter()
        e = emitter.emit(EventType.STEP_START, key="val")
        assert isinstance(e, Event)
        assert e.data["key"] == "val"
