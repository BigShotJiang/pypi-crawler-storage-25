"""Fluent builder API for constructing pipelines."""

from __future__ import annotations

from typing import Any, Callable, List, Optional, Union

from pipechain.cache import CacheBackend
from pipechain.context import Context
from pipechain.hooks import HookType
from pipechain.pipeline import Pipeline
from pipechain.result import PipelineResult
from pipechain.retry import RetryPolicy
from pipechain.step import Step


class StepBuilder:
    """Fluent builder for a single step."""

    def __init__(self, name: str, fn: Callable[..., Any]) -> None:
        self._name = name
        self._fn = fn
        self._depends_on: List[str] = []
        self._retry_policy: Optional[RetryPolicy] = None
        self._cache_key: Optional[str] = None
        self._cache_ttl: Optional[float] = None
        self._condition: Optional[Callable[[Context], bool]] = None
        self._timeout: Optional[float] = None
        self._tags: List[str] = []
        self._description: Optional[str] = None

    def depends_on(self, *deps: str) -> StepBuilder:
        """Set step dependencies."""
        self._depends_on = list(deps)
        return self

    def retry(self, policy_or_count: Union[RetryPolicy, int] = 3) -> StepBuilder:
        """Set retry policy."""
        if isinstance(policy_or_count, int):
            self._retry_policy = RetryPolicy(max_retries=policy_or_count, base_delay=0.1, jitter=False)
        else:
            self._retry_policy = policy_or_count
        return self

    def cache(self, key: str, ttl: Optional[float] = None) -> StepBuilder:
        """Enable caching for this step."""
        self._cache_key = key
        self._cache_ttl = ttl
        return self

    def when(self, condition: Callable[[Context], bool]) -> StepBuilder:
        """Set conditional execution."""
        self._condition = condition
        return self

    def timeout(self, seconds: float) -> StepBuilder:
        """Set execution timeout."""
        self._timeout = seconds
        return self

    def tag(self, *tags: str) -> StepBuilder:
        """Add tags to this step."""
        self._tags.extend(tags)
        return self

    def describe(self, description: str) -> StepBuilder:
        """Set step description."""
        self._description = description
        return self

    def build(self) -> Step:
        """Build the Step instance."""
        return Step(
            name=self._name,
            fn=self._fn,
            depends_on=self._depends_on if self._depends_on else None,
            retry_policy=self._retry_policy,
            cache_key=self._cache_key,
            cache_ttl=self._cache_ttl,
            condition=self._condition,
            timeout=self._timeout,
            tags=self._tags if self._tags else None,
            description=self._description,
        )


class PipelineBuilder:
    """Fluent builder for constructing pipelines.

    Usage:
        result = (
            PipelineBuilder("etl")
            .step("extract", extract_fn)
            .step("transform", transform_fn).depends_on("extract")
            .step("load", load_fn).depends_on("transform")
            .run()
        )
    """

    def __init__(self, name: str) -> None:
        self._name = name
        self._steps: List[StepBuilder] = []
        self._current_step: Optional[StepBuilder] = None
        self._max_concurrency: int = 4
        self._cache: Optional[CacheBackend] = None
        self._fail_fast: bool = True
        self._description: str = ""
        self._hooks: List[tuple] = []

    def step(self, name: str, fn: Callable[..., Any]) -> PipelineBuilder:
        """Add a new step."""
        if self._current_step:
            self._steps.append(self._current_step)
        self._current_step = StepBuilder(name, fn)
        return self

    def depends_on(self, *deps: str) -> PipelineBuilder:
        """Set dependencies on current step."""
        if self._current_step:
            self._current_step.depends_on(*deps)
        return self

    def retry(self, policy_or_count: Union[RetryPolicy, int] = 3) -> PipelineBuilder:
        """Set retry on current step."""
        if self._current_step:
            self._current_step.retry(policy_or_count)
        return self

    def cache(self, key: str, ttl: Optional[float] = None) -> PipelineBuilder:
        """Set cache on current step."""
        if self._current_step:
            self._current_step.cache(key, ttl)
        return self

    def when(self, condition: Callable[[Context], bool]) -> PipelineBuilder:
        """Set condition on current step."""
        if self._current_step:
            self._current_step.when(condition)
        return self

    def timeout(self, seconds: float) -> PipelineBuilder:
        """Set timeout on current step."""
        if self._current_step:
            self._current_step.timeout(seconds)
        return self

    def tag(self, *tags: str) -> PipelineBuilder:
        """Add tags to current step."""
        if self._current_step:
            self._current_step.tag(*tags)
        return self

    def describe(self, description: str) -> PipelineBuilder:
        """Set description on current step."""
        if self._current_step:
            self._current_step.describe(description)
        return self

    def concurrency(self, max_workers: int) -> PipelineBuilder:
        """Set max concurrency for the pipeline."""
        self._max_concurrency = max_workers
        return self

    def with_cache(self, backend: CacheBackend) -> PipelineBuilder:
        """Set the cache backend for the pipeline."""
        self._cache = backend
        return self

    def fail_fast(self, enabled: bool = True) -> PipelineBuilder:
        """Set fail-fast behavior."""
        self._fail_fast = enabled
        return self

    def on(self, hook_type: HookType, callback: Callable) -> PipelineBuilder:
        """Register a lifecycle hook."""
        self._hooks.append((hook_type, callback))
        return self

    def build(self) -> Pipeline:
        """Build and return the Pipeline."""
        if self._current_step:
            self._steps.append(self._current_step)
            self._current_step = None

        pipeline = Pipeline(
            name=self._name,
            max_concurrency=self._max_concurrency,
            cache=self._cache,
            fail_fast=self._fail_fast,
            description=self._description,
        )

        for sb in self._steps:
            pipeline.add_step(sb.build())

        for hook_type, callback in self._hooks:
            pipeline.on(hook_type, callback)

        return pipeline

    def run(self, context: Optional[Context] = None, **kwargs: Any) -> PipelineResult:
        """Build and run the pipeline."""
        pipeline = self.build()
        return pipeline.run(context=context, **kwargs)
