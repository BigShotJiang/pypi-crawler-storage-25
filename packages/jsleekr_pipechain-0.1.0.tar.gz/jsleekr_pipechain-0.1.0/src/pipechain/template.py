"""Pipeline templating and cloning utilities."""

from __future__ import annotations

import copy
from typing import Any, Callable, Dict, List, Optional

from pipechain.pipeline import Pipeline
from pipechain.step import Step
from pipechain.context import Context
from pipechain.retry import RetryPolicy


class PipelineTemplate:
    """Template for creating parameterized pipeline instances.

    Templates allow defining a pipeline structure once and instantiating
    it with different configurations and step implementations.
    """

    def __init__(self, name: str, description: str = "") -> None:
        self._name = name
        self._description = description
        self._step_defs: List[Dict[str, Any]] = []
        self._defaults: Dict[str, Any] = {}

    def add_slot(
        self,
        name: str,
        depends_on: Optional[List[str]] = None,
        tags: Optional[List[str]] = None,
        retry: Optional[int] = None,
        timeout: Optional[float] = None,
        description: str = "",
    ) -> "PipelineTemplate":
        """Add a step slot to the template."""
        self._step_defs.append({
            "name": name,
            "depends_on": depends_on or [],
            "tags": tags or [],
            "retry": retry,
            "timeout": timeout,
            "description": description,
        })
        return self

    def set_default(self, slot_name: str, fn: Callable) -> "PipelineTemplate":
        """Set a default implementation for a slot."""
        self._defaults[slot_name] = fn
        return self

    def instantiate(
        self,
        implementations: Optional[Dict[str, Callable]] = None,
        name_suffix: str = "",
        **pipeline_kwargs: Any,
    ) -> Pipeline:
        """Create a Pipeline instance from this template.

        Args:
            implementations: Mapping of slot names to callables.
            name_suffix: Optional suffix for the pipeline name.
            **pipeline_kwargs: Additional Pipeline constructor args.
        """
        impls = dict(self._defaults)
        if implementations:
            impls.update(implementations)

        pipeline_name = f"{self._name}{name_suffix}" if name_suffix else self._name
        pipeline = Pipeline(
            name=pipeline_name,
            description=self._description,
            **pipeline_kwargs,
        )

        for step_def in self._step_defs:
            name = step_def["name"]
            fn = impls.get(name)
            if fn is None:
                def placeholder(ctx, sn=name):
                    raise NotImplementedError(f"No implementation for slot '{sn}'")
                fn = placeholder

            retry_policy = None
            if step_def["retry"]:
                retry_policy = RetryPolicy(
                    max_retries=step_def["retry"],
                    base_delay=0.1,
                    jitter=False,
                )

            step = Step(
                name=name,
                fn=fn,
                depends_on=step_def["depends_on"] if step_def["depends_on"] else None,
                retry_policy=retry_policy,
                timeout=step_def["timeout"],
                tags=step_def["tags"] if step_def["tags"] else None,
                description=step_def["description"],
            )
            pipeline.add_step(step)

        return pipeline

    @property
    def slots(self) -> List[str]:
        """Return all slot names."""
        return [d["name"] for d in self._step_defs]

    @property
    def unfilled_slots(self) -> List[str]:
        """Return slots without default implementations."""
        return [d["name"] for d in self._step_defs if d["name"] not in self._defaults]

    def __repr__(self) -> str:
        return f"PipelineTemplate({self._name!r}, slots={len(self._step_defs)})"


def clone_pipeline(
    pipeline: Pipeline,
    new_name: Optional[str] = None,
    step_overrides: Optional[Dict[str, Callable]] = None,
) -> Pipeline:
    """Clone a pipeline with optional step function overrides.

    Args:
        pipeline: Pipeline to clone.
        new_name: New name for the clone. Defaults to original name + '_clone'.
        step_overrides: Map of step names to new callables.
    """
    overrides = step_overrides or {}
    name = new_name or f"{pipeline.name}_clone"

    cloned = Pipeline(
        name=name,
        max_concurrency=pipeline.max_concurrency,
        cache=pipeline.cache,
        fail_fast=pipeline.fail_fast,
        description=pipeline.description,
    )

    for step in pipeline.steps:
        fn = overrides.get(step.name, step.fn)
        cloned_step = Step(
            name=step.name,
            fn=fn,
            depends_on=list(step.depends_on) if step.depends_on else None,
            retry_policy=step.retry_policy,
            cache_key=step.cache_key,
            cache_ttl=step.cache_ttl,
            condition=step.condition,
            timeout=step.timeout,
            tags=list(step.tags) if step.tags else None,
            description=step.description,
        )
        cloned.add_step(cloned_step)

    return cloned
