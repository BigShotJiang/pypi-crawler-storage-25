"""Execution history tracking for audit and debugging."""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional


@dataclass
class RunRecord:
    """Record of a single pipeline run."""
    pipeline_name: str
    run_id: str
    started_at: float
    ended_at: float = 0.0
    success: bool = False
    total_steps: int = 0
    passed_steps: int = 0
    failed_steps: int = 0
    skipped_steps: int = 0
    cached_steps: int = 0
    duration_ms: float = 0.0
    error: Optional[str] = None
    step_details: List[Dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "pipeline_name": self.pipeline_name,
            "run_id": self.run_id,
            "started_at": self.started_at,
            "ended_at": self.ended_at,
            "success": self.success,
            "total_steps": self.total_steps,
            "passed_steps": self.passed_steps,
            "failed_steps": self.failed_steps,
            "skipped_steps": self.skipped_steps,
            "cached_steps": self.cached_steps,
            "duration_ms": self.duration_ms,
            "error": self.error,
            "step_details": self.step_details,
        }

    @staticmethod
    def from_dict(data: Dict[str, Any]) -> "RunRecord":
        return RunRecord(
            pipeline_name=data["pipeline_name"],
            run_id=data["run_id"],
            started_at=data["started_at"],
            ended_at=data.get("ended_at", 0.0),
            success=data.get("success", False),
            total_steps=data.get("total_steps", 0),
            passed_steps=data.get("passed_steps", 0),
            failed_steps=data.get("failed_steps", 0),
            skipped_steps=data.get("skipped_steps", 0),
            cached_steps=data.get("cached_steps", 0),
            duration_ms=data.get("duration_ms", 0.0),
            error=data.get("error"),
            step_details=data.get("step_details", []),
        )


class ExecutionHistory:
    """Persistent execution history for pipeline runs."""

    def __init__(self, history_file: Optional[str] = None, max_records: int = 1000) -> None:
        self._file = Path(history_file) if history_file else None
        self._max_records = max_records
        self._records: List[RunRecord] = []
        if self._file and self._file.exists():
            self._load()

    def record_run(self, result: Any, run_id: Optional[str] = None) -> RunRecord:
        """Record a pipeline result."""
        from pipechain.result import StepStatus

        record = RunRecord(
            pipeline_name=result.pipeline_name,
            run_id=run_id or f"run_{int(time.time() * 1000)}",
            started_at=time.time() - result.total_duration_ms / 1000,
            ended_at=time.time(),
            success=result.success,
            total_steps=len(result.step_results),
            passed_steps=len(result.succeeded_steps),
            failed_steps=len(result.failed_steps),
            skipped_steps=len(result.skipped_steps),
            cached_steps=len(result.cached_steps),
            duration_ms=result.total_duration_ms,
            error=str(result.error) if result.error else None,
            step_details=[
                {
                    "name": sr.step_name,
                    "status": sr.status.value,
                    "duration_ms": sr.duration_ms,
                    "retries": sr.retries,
                    "cached": sr.cached,
                    "error": str(sr.error) if sr.error else None,
                }
                for sr in result.step_results
            ],
        )

        self._records.append(record)
        if len(self._records) > self._max_records:
            self._records = self._records[-self._max_records:]

        if self._file:
            self._save()

        return record

    def get_runs(
        self,
        pipeline_name: Optional[str] = None,
        limit: int = 50,
        success_only: bool = False,
    ) -> List[RunRecord]:
        """Get run records with optional filters."""
        records = self._records
        if pipeline_name:
            records = [r for r in records if r.pipeline_name == pipeline_name]
        if success_only:
            records = [r for r in records if r.success]
        return records[-limit:]

    def get_run(self, run_id: str) -> Optional[RunRecord]:
        """Get a specific run by ID."""
        for r in self._records:
            if r.run_id == run_id:
                return r
        return None

    def latest(self, pipeline_name: Optional[str] = None) -> Optional[RunRecord]:
        """Get the latest run record."""
        records = self._records
        if pipeline_name:
            records = [r for r in records if r.pipeline_name == pipeline_name]
        return records[-1] if records else None

    @property
    def total_runs(self) -> int:
        return len(self._records)

    def clear(self, pipeline_name: Optional[str] = None) -> int:
        """Clear history. Returns count cleared."""
        if pipeline_name:
            before = len(self._records)
            self._records = [r for r in self._records if r.pipeline_name != pipeline_name]
            count = before - len(self._records)
        else:
            count = len(self._records)
            self._records.clear()
        if self._file:
            self._save()
        return count

    def _save(self) -> None:
        """Save history to file."""
        if self._file:
            self._file.parent.mkdir(parents=True, exist_ok=True)
            data = [r.to_dict() for r in self._records]
            self._file.write_text(json.dumps(data, indent=2))

    def _load(self) -> None:
        """Load history from file."""
        if self._file and self._file.exists():
            try:
                data = json.loads(self._file.read_text())
                self._records = [RunRecord.from_dict(d) for d in data]
            except (json.JSONDecodeError, KeyError):
                self._records = []
