"""Cache backends for step result caching."""

from __future__ import annotations

import hashlib
import json
import os
import pickle
import time
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Optional, Tuple


class CacheBackend(ABC):
    """Abstract cache backend."""

    @abstractmethod
    def get(self, key: str) -> Tuple[bool, Any]:
        """Get a cached value. Returns (hit, value)."""
        ...

    @abstractmethod
    def set(self, key: str, value: Any, ttl: Optional[float] = None) -> None:
        """Set a cached value with optional TTL in seconds."""
        ...

    @abstractmethod
    def delete(self, key: str) -> bool:
        """Delete a cached entry. Returns True if it existed."""
        ...

    @abstractmethod
    def clear(self) -> int:
        """Clear all cached entries. Returns count deleted."""
        ...

    @abstractmethod
    def has(self, key: str) -> bool:
        """Check if a key exists and is not expired."""
        ...

    @staticmethod
    def make_key(*parts: Any) -> str:
        """Create a cache key from parts."""
        raw = json.dumps(parts, sort_keys=True, default=str)
        return hashlib.sha256(raw.encode()).hexdigest()[:16]


class MemoryCache(CacheBackend):
    """In-memory cache backend."""

    def __init__(self) -> None:
        self._store: dict[str, Tuple[Any, Optional[float]]] = {}

    def get(self, key: str) -> Tuple[bool, Any]:
        if key not in self._store:
            return False, None
        value, expires_at = self._store[key]
        if expires_at is not None and time.time() > expires_at:
            del self._store[key]
            return False, None
        return True, value

    def set(self, key: str, value: Any, ttl: Optional[float] = None) -> None:
        expires_at = time.time() + ttl if ttl is not None else None
        self._store[key] = (value, expires_at)

    def delete(self, key: str) -> bool:
        if key in self._store:
            del self._store[key]
            return True
        return False

    def clear(self) -> int:
        count = len(self._store)
        self._store.clear()
        return count

    def has(self, key: str) -> bool:
        hit, _ = self.get(key)
        return hit

    @property
    def size(self) -> int:
        """Number of entries (including possibly expired)."""
        return len(self._store)


class FileCache(CacheBackend):
    """File-system cache backend using pickle serialization."""

    def __init__(self, cache_dir: str = ".pipechain_cache") -> None:
        self._cache_dir = Path(cache_dir)
        self._cache_dir.mkdir(parents=True, exist_ok=True)

    def _path(self, key: str) -> Path:
        safe_key = hashlib.sha256(key.encode()).hexdigest()
        return self._cache_dir / f"{safe_key}.cache"

    def _meta_path(self, key: str) -> Path:
        safe_key = hashlib.sha256(key.encode()).hexdigest()
        return self._cache_dir / f"{safe_key}.meta"

    def get(self, key: str) -> Tuple[bool, Any]:
        path = self._path(key)
        meta_path = self._meta_path(key)
        if not path.exists():
            return False, None
        # Check TTL
        if meta_path.exists():
            meta = json.loads(meta_path.read_text())
            if meta.get("expires_at") is not None and time.time() > meta["expires_at"]:
                path.unlink(missing_ok=True)
                meta_path.unlink(missing_ok=True)
                return False, None
        try:
            with open(path, "rb") as f:
                value = pickle.load(f)
            return True, value
        except Exception:
            return False, None

    def set(self, key: str, value: Any, ttl: Optional[float] = None) -> None:
        path = self._path(key)
        meta_path = self._meta_path(key)
        with open(path, "wb") as f:
            pickle.dump(value, f)
        meta = {
            "key": key,
            "created_at": time.time(),
            "expires_at": time.time() + ttl if ttl is not None else None,
        }
        meta_path.write_text(json.dumps(meta))

    def delete(self, key: str) -> bool:
        path = self._path(key)
        meta_path = self._meta_path(key)
        existed = path.exists()
        path.unlink(missing_ok=True)
        meta_path.unlink(missing_ok=True)
        return existed

    def clear(self) -> int:
        count = 0
        for p in self._cache_dir.iterdir():
            if p.suffix in (".cache", ".meta"):
                p.unlink()
                count += 1
        return count // 2  # Each entry has 2 files

    def has(self, key: str) -> bool:
        hit, _ = self.get(key)
        return hit
