"""Serialization utilities for pipeline definitions."""

from __future__ import annotations

import json
from typing import Any, Dict, List, Optional

from pipechain.pipeline import Pipeline
from pipechain.step import Step
from pipechain.retry import RetryPolicy


def pipeline_to_dict(pipeline: Pipeline) -> Dict[str, Any]:
    """Serialize a pipeline to a dictionary."""
    return {
        "name": pipeline.name,
        "description": pipeline.description,
        "max_concurrency": pipeline.max_concurrency,
        "fail_fast": pipeline.fail_fast,
        "steps": [_step_to_dict(s) for s in pipeline.steps],
    }


def _step_to_dict(step: Step) -> Dict[str, Any]:
    """Serialize a step to a dictionary."""
    d: Dict[str, Any] = {
        "name": step.name,
    }
    if step.depends_on:
        d["depends_on"] = step.depends_on
    if step.description:
        d["description"] = step.description
    if step.tags:
        d["tags"] = step.tags
    if step.timeout:
        d["timeout"] = step.timeout
    if step.cache_key:
        d["cache_key"] = step.cache_key
    if step.cache_ttl:
        d["cache_ttl"] = step.cache_ttl
    if step.retry_policy.max_retries > 0:
        d["retry"] = {
            "max_retries": step.retry_policy.max_retries,
            "base_delay": step.retry_policy.base_delay,
            "max_delay": step.retry_policy.max_delay,
            "exponential_base": step.retry_policy.exponential_base,
            "jitter": step.retry_policy.jitter,
        }
    return d


def pipeline_to_json(pipeline: Pipeline, indent: int = 2) -> str:
    """Serialize a pipeline to JSON string."""
    return json.dumps(pipeline_to_dict(pipeline), indent=indent)


def dict_to_pipeline(
    data: Dict[str, Any],
    step_registry: Optional[Dict[str, Any]] = None,
) -> Pipeline:
    """Deserialize a pipeline from a dictionary.

    Args:
        data: Pipeline definition dictionary.
        step_registry: Optional mapping of step names to callables.
            If not provided, steps will have placeholder functions.
    """
    registry = step_registry or {}

    pipeline = Pipeline(
        name=data["name"],
        max_concurrency=data.get("max_concurrency", 4),
        fail_fast=data.get("fail_fast", True),
        description=data.get("description", ""),
    )

    for step_data in data.get("steps", []):
        name = step_data["name"]
        fn = registry.get(name, _placeholder_fn(name))

        retry_policy = RetryPolicy.none()
        if "retry" in step_data:
            r = step_data["retry"]
            retry_policy = RetryPolicy(
                max_retries=r.get("max_retries", 3),
                base_delay=r.get("base_delay", 1.0),
                max_delay=r.get("max_delay", 60.0),
                exponential_base=r.get("exponential_base", 2.0),
                jitter=r.get("jitter", True),
            )

        step = Step(
            name=name,
            fn=fn,
            depends_on=step_data.get("depends_on"),
            retry_policy=retry_policy,
            cache_key=step_data.get("cache_key"),
            cache_ttl=step_data.get("cache_ttl"),
            timeout=step_data.get("timeout"),
            tags=step_data.get("tags"),
            description=step_data.get("description"),
        )
        pipeline.add_step(step)

    return pipeline


def json_to_pipeline(
    json_str: str,
    step_registry: Optional[Dict[str, Any]] = None,
) -> Pipeline:
    """Deserialize a pipeline from a JSON string."""
    data = json.loads(json_str)
    return dict_to_pipeline(data, step_registry)


def _placeholder_fn(name: str):
    """Create a placeholder function for a step."""
    def placeholder(ctx):
        raise NotImplementedError(
            f"Step '{name}' has no implementation. "
            f"Provide it via step_registry."
        )
    placeholder.__name__ = name
    placeholder.__doc__ = f"Placeholder for step '{name}'"
    return placeholder


def validate_definition(data: Dict[str, Any]) -> List[str]:
    """Validate a pipeline definition dictionary. Returns list of errors."""
    errors: List[str] = []

    if "name" not in data:
        errors.append("Missing required field: 'name'")
    elif not isinstance(data["name"], str):
        errors.append("Field 'name' must be a string")

    if "steps" not in data:
        errors.append("Missing required field: 'steps'")
    elif not isinstance(data["steps"], list):
        errors.append("Field 'steps' must be a list")
    else:
        step_names = set()
        for i, step in enumerate(data["steps"]):
            if not isinstance(step, dict):
                errors.append(f"Step {i} must be a dictionary")
                continue
            if "name" not in step:
                errors.append(f"Step {i} missing required field: 'name'")
            else:
                if step["name"] in step_names:
                    errors.append(f"Duplicate step name: '{step['name']}'")
                step_names.add(step["name"])

            if "depends_on" in step:
                if not isinstance(step["depends_on"], list):
                    errors.append(f"Step '{step.get('name', i)}': depends_on must be a list")
                else:
                    for dep in step["depends_on"]:
                        if dep not in step_names and dep not in {
                            s.get("name") for s in data["steps"]
                        }:
                            errors.append(
                                f"Step '{step.get('name', i)}' depends on "
                                f"'{dep}' which is not defined"
                            )

            if "retry" in step:
                retry = step["retry"]
                if not isinstance(retry, dict):
                    errors.append(f"Step '{step.get('name', i)}': retry must be a dictionary")
                elif "max_retries" in retry and not isinstance(retry["max_retries"], int):
                    errors.append(f"Step '{step.get('name', i)}': retry.max_retries must be int")

    return errors
