"""Pipeline: the main orchestrator that runs steps in DAG order."""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any, Callable, Dict, List, Optional, Union

from pipechain.cache import CacheBackend, MemoryCache
from pipechain.context import Context
from pipechain.dag import DAG
from pipechain.hooks import HookRegistry, HookType
from pipechain.result import PipelineResult, StepResult, StepStatus
from pipechain.retry import RetryPolicy
from pipechain.step import Step

logger = logging.getLogger("pipechain")


class Pipeline:
    """DAG-based pipeline that orchestrates step execution.

    Features:
    - Automatic dependency resolution via DAG
    - Parallel execution of independent steps
    - Retry with configurable policies
    - Result caching
    - Conditional step execution
    - Lifecycle hooks
    - Dry-run mode

    Usage:
        pipe = Pipeline("etl")
        pipe.add_step(Step("extract", extract_fn))
        pipe.add_step(Step("transform", transform_fn, depends_on=["extract"]))
        pipe.add_step(Step("load", load_fn, depends_on=["transform"]))
        result = pipe.run()
    """

    def __init__(
        self,
        name: str,
        max_concurrency: int = 4,
        cache: Optional[CacheBackend] = None,
        fail_fast: bool = True,
        description: Optional[str] = None,
    ) -> None:
        self.name = name
        self.max_concurrency = max_concurrency
        self.cache = cache
        self.fail_fast = fail_fast
        self.description = description or ""
        self._steps: Dict[str, Step] = {}
        self._dag = DAG()
        self._hooks = HookRegistry()

    def add_step(self, step_or_fn: Union[Step, Callable], **kwargs: Any) -> Step:
        """Add a step to the pipeline.

        Accepts either a Step instance or a callable (which will be wrapped).
        """
        if isinstance(step_or_fn, Step):
            s = step_or_fn
        elif callable(step_or_fn):
            name = kwargs.pop("name", step_or_fn.__name__)
            s = Step(name=name, fn=step_or_fn, **kwargs)
        else:
            raise TypeError(f"Expected Step or callable, got {type(step_or_fn)}")

        if s.name in self._steps:
            raise ValueError(f"Step '{s.name}' already exists in pipeline '{self.name}'")

        self._steps[s.name] = s
        self._dag.add_node(s.name)
        for dep in s.depends_on:
            self._dag.add_edge(s.name, dep)

        return s

    def remove_step(self, name: str) -> bool:
        """Remove a step from the pipeline."""
        if name not in self._steps:
            return False
        # Rebuild DAG without this step
        del self._steps[name]
        self._rebuild_dag()
        return True

    def _rebuild_dag(self) -> None:
        """Rebuild the DAG from current steps."""
        self._dag = DAG()
        for s in self._steps.values():
            self._dag.add_node(s.name)
            for dep in s.depends_on:
                self._dag.add_edge(s.name, dep)

    def get_step(self, name: str) -> Optional[Step]:
        """Get a step by name."""
        return self._steps.get(name)

    @property
    def steps(self) -> List[Step]:
        """Return all steps."""
        return list(self._steps.values())

    @property
    def step_names(self) -> List[str]:
        """Return all step names in topological order."""
        return self._dag.topological_sort()

    def execution_plan(self) -> List[List[str]]:
        """Return the execution plan showing parallel groups."""
        return self._dag.execution_levels()

    def validate(self) -> List[str]:
        """Validate the pipeline. Returns a list of warnings."""
        warnings: List[str] = []
        try:
            self._dag.validate()
        except Exception as e:
            warnings.append(str(e))
        # Check for orphan dependencies
        for s in self._steps.values():
            for dep in s.depends_on:
                if dep not in self._steps:
                    warnings.append(f"Step '{s.name}' depends on '{dep}' which is not in the pipeline")
        return warnings

    def on(
        self,
        hook_type: HookType,
        callback: Callable[..., Any],
        name: Optional[str] = None,
        priority: int = 0,
    ) -> None:
        """Register a lifecycle hook."""
        self._hooks.register(hook_type, callback, name, priority)

    def run(
        self,
        context: Optional[Context] = None,
        dry_run: bool = False,
        tags: Optional[List[str]] = None,
    ) -> PipelineResult:
        """Run the pipeline synchronously."""
        loop = asyncio.new_event_loop()
        try:
            return loop.run_until_complete(self.async_run(context, dry_run, tags))
        finally:
            loop.close()

    async def async_run(
        self,
        context: Optional[Context] = None,
        dry_run: bool = False,
        tags: Optional[List[str]] = None,
    ) -> PipelineResult:
        """Run the pipeline asynchronously."""
        ctx = context if context is not None else Context()
        result = PipelineResult(pipeline_name=self.name)
        start_time = time.perf_counter()

        # Fire before_pipeline hooks
        await self._hooks.async_fire(
            HookType.BEFORE_PIPELINE,
            pipeline=self, context=ctx,
        )

        try:
            levels = self.execution_plan()

            for level in levels:
                # Filter steps by tags if specified
                level_steps = []
                for name in level:
                    s = self._steps[name]
                    if tags and not any(t in s.tags for t in tags):
                        result.step_results.append(StepResult(
                            step_name=name,
                            status=StepStatus.SKIPPED,
                            skipped_reason="Tag filter",
                        ))
                        continue
                    level_steps.append(s)

                if dry_run:
                    for s in level_steps:
                        result.step_results.append(StepResult(
                            step_name=s.name,
                            status=StepStatus.SKIPPED,
                            skipped_reason="Dry run",
                        ))
                    continue

                # Execute steps in this level concurrently
                semaphore = asyncio.Semaphore(self.max_concurrency)
                tasks = []
                for s in level_steps:
                    tasks.append(self._run_step(s, ctx, semaphore, result))

                step_results = await asyncio.gather(*tasks, return_exceptions=True)

                for sr in step_results:
                    if isinstance(sr, Exception):
                        result.error = sr
                        break
                    result.step_results.append(sr)
                    if sr.status == StepStatus.FAILED and self.fail_fast:
                        # Skip remaining levels
                        result.error = sr.error
                        # Mark remaining steps as skipped
                        remaining = set()
                        for future_level in levels[levels.index(level) + 1:]:
                            remaining.update(future_level)
                        for name in remaining:
                            result.step_results.append(StepResult(
                                step_name=name,
                                status=StepStatus.SKIPPED,
                                skipped_reason=f"Skipped due to failure in '{sr.step_name}'",
                            ))
                        break

                if result.error and self.fail_fast:
                    break

        finally:
            result.total_duration_ms = (time.perf_counter() - start_time) * 1000

            # Fire after_pipeline hooks
            await self._hooks.async_fire(
                HookType.AFTER_PIPELINE,
                pipeline=self, context=ctx, result=result,
            )

        return result

    async def _run_step(
        self,
        step: Step,
        ctx: Context,
        semaphore: asyncio.Semaphore,
        pipeline_result: PipelineResult,
    ) -> StepResult:
        """Execute a single step with retry and caching."""
        async with semaphore:
            start_time = time.perf_counter()

            # Check condition
            if not step.should_run(ctx):
                sr = StepResult(
                    step_name=step.name,
                    status=StepStatus.SKIPPED,
                    skipped_reason="Condition not met",
                )
                await self._hooks.async_fire(
                    HookType.ON_STEP_SKIP,
                    step=step, context=ctx, result=sr,
                )
                return sr

            # Check cache
            if self.cache and step.cache_key:
                cache_key = step.get_cache_key(ctx)
                if cache_key:
                    hit, cached_value = self.cache.get(cache_key)
                    if hit:
                        sr = StepResult(
                            step_name=step.name,
                            status=StepStatus.CACHED,
                            output=cached_value,
                            cached=True,
                            duration_ms=(time.perf_counter() - start_time) * 1000,
                        )
                        ctx.set(f"{step.name}.output", cached_value)
                        await self._hooks.async_fire(
                            HookType.ON_STEP_CACHED,
                            step=step, context=ctx, result=sr,
                        )
                        return sr

            # Fire before_step hooks
            await self._hooks.async_fire(
                HookType.BEFORE_STEP,
                step=step, context=ctx,
            )

            # Execute with retry
            last_error = None
            retries = 0

            for attempt in range(step.retry_policy.max_retries + 1):
                try:
                    output = await step.execute(ctx)
                    duration_ms = (time.perf_counter() - start_time) * 1000

                    # Store output in context
                    ctx.set(f"{step.name}.output", output)

                    # Cache the result
                    if self.cache and step.cache_key:
                        cache_key = step.get_cache_key(ctx)
                        if cache_key:
                            self.cache.set(cache_key, output, step.cache_ttl)

                    sr = StepResult(
                        step_name=step.name,
                        status=StepStatus.SUCCESS,
                        output=output,
                        duration_ms=duration_ms,
                        retries=retries,
                    )

                    # Fire after_step hooks
                    await self._hooks.async_fire(
                        HookType.AFTER_STEP,
                        step=step, context=ctx, result=sr,
                    )

                    return sr

                except Exception as e:
                    last_error = e
                    if step.retry_policy.should_retry(e, attempt):
                        retries += 1
                        await self._hooks.async_fire(
                            HookType.ON_STEP_RETRY,
                            step=step, context=ctx, error=e, attempt=attempt,
                        )
                        await step.retry_policy.async_wait(attempt)
                    else:
                        break

            # All retries exhausted
            duration_ms = (time.perf_counter() - start_time) * 1000
            sr = StepResult(
                step_name=step.name,
                status=StepStatus.FAILED,
                error=last_error,
                duration_ms=duration_ms,
                retries=retries,
            )

            await self._hooks.async_fire(
                HookType.ON_STEP_ERROR,
                step=step, context=ctx, result=sr, error=last_error,
            )

            return sr

    def visualize(self) -> str:
        """Return an ASCII visualization of the pipeline DAG."""
        levels = self.execution_plan()
        lines = [f"Pipeline: {self.name}", ""]

        for i, level in enumerate(levels):
            lines.append(f"  Level {i}:")
            for name in level:
                step = self._steps[name]
                deps = f" <- [{', '.join(step.depends_on)}]" if step.depends_on else ""
                tags = f" #{', #'.join(step.tags)}" if step.tags else ""
                lines.append(f"    [{name}]{deps}{tags}")
            if i < len(levels) - 1:
                lines.append("      |")
                lines.append("      v")

        return "\n".join(lines)

    def __repr__(self) -> str:
        return f"Pipeline({self.name!r}, steps={len(self._steps)})"
