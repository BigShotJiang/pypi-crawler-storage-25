"""Pipeline execution context for sharing data between steps."""

from __future__ import annotations

import copy
import threading
from typing import Any, Dict, Optional


class Context:
    """Thread-safe execution context for sharing data between pipeline steps.

    The context acts as a shared data store that steps can read from and write to.
    It supports namespaced keys (e.g., 'step_name.key') and provides snapshot
    capability for rollback scenarios.
    """

    def __init__(self, initial_data: Optional[Dict[str, Any]] = None) -> None:
        self._data: Dict[str, Any] = dict(initial_data or {})
        self._lock = threading.RLock()
        self._snapshots: list[Dict[str, Any]] = []

    def set(self, key: str, value: Any) -> None:
        """Set a value in the context."""
        with self._lock:
            self._data[key] = value

    def get(self, key: str, default: Any = None) -> Any:
        """Get a value from the context."""
        with self._lock:
            return self._data.get(key, default)

    def has(self, key: str) -> bool:
        """Check if a key exists in the context."""
        with self._lock:
            return key in self._data

    def delete(self, key: str) -> bool:
        """Delete a key from the context. Returns True if it existed."""
        with self._lock:
            if key in self._data:
                del self._data[key]
                return True
            return False

    def keys(self) -> list[str]:
        """Return all keys in the context."""
        with self._lock:
            return list(self._data.keys())

    def items(self) -> list[tuple[str, Any]]:
        """Return all items in the context."""
        with self._lock:
            return list(self._data.items())

    def snapshot(self) -> int:
        """Take a snapshot of the current state. Returns snapshot index."""
        with self._lock:
            snap = copy.deepcopy(self._data)
            self._snapshots.append(snap)
            return len(self._snapshots) - 1

    def rollback(self, snapshot_id: Optional[int] = None) -> None:
        """Rollback to a previous snapshot. Defaults to the most recent."""
        with self._lock:
            if not self._snapshots:
                raise ValueError("No snapshots available for rollback")
            if snapshot_id is None:
                snapshot_id = len(self._snapshots) - 1
            if snapshot_id < 0 or snapshot_id >= len(self._snapshots):
                raise ValueError(f"Invalid snapshot ID: {snapshot_id}")
            self._data = copy.deepcopy(self._snapshots[snapshot_id])

    def clear(self) -> None:
        """Clear all data from the context."""
        with self._lock:
            self._data.clear()

    def merge(self, data: Dict[str, Any]) -> None:
        """Merge a dictionary into the context."""
        with self._lock:
            self._data.update(data)

    def namespace(self, prefix: str) -> Dict[str, Any]:
        """Get all values under a namespace prefix."""
        with self._lock:
            result = {}
            prefix_dot = f"{prefix}."
            for k, v in self._data.items():
                if k.startswith(prefix_dot):
                    result[k[len(prefix_dot):]] = v
            return result

    def to_dict(self) -> Dict[str, Any]:
        """Return a copy of all data."""
        with self._lock:
            return copy.deepcopy(self._data)

    def __len__(self) -> int:
        with self._lock:
            return len(self._data)

    def __repr__(self) -> str:
        with self._lock:
            return f"Context({self._data})"
