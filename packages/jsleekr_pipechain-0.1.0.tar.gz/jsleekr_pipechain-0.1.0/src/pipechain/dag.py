"""DAG (Directed Acyclic Graph) utilities for step dependency resolution."""

from __future__ import annotations

from collections import defaultdict, deque
from typing import Dict, List, Set


class CycleError(Exception):
    """Raised when a cycle is detected in the DAG."""
    def __init__(self, cycle: List[str]) -> None:
        self.cycle = cycle
        super().__init__(f"Cycle detected in DAG: {' -> '.join(cycle)}")


class MissingDependencyError(Exception):
    """Raised when a step depends on a non-existent step."""
    def __init__(self, step: str, missing: str) -> None:
        self.step = step
        self.missing = missing
        super().__init__(f"Step '{step}' depends on '{missing}', which does not exist")


class DAG:
    """Directed Acyclic Graph for managing step dependencies.

    Provides topological sorting and parallel execution level computation.
    """

    def __init__(self) -> None:
        self._nodes: Set[str] = set()
        self._edges: Dict[str, Set[str]] = defaultdict(set)  # node -> dependencies
        self._reverse_edges: Dict[str, Set[str]] = defaultdict(set)  # node -> dependents

    def add_node(self, name: str) -> None:
        """Add a node to the DAG."""
        self._nodes.add(name)

    def add_edge(self, from_node: str, to_node: str) -> None:
        """Add a dependency edge: from_node depends on to_node."""
        self._nodes.add(from_node)
        self._nodes.add(to_node)
        self._edges[from_node].add(to_node)
        self._reverse_edges[to_node].add(from_node)

    def dependencies(self, node: str) -> Set[str]:
        """Get direct dependencies of a node."""
        return set(self._edges.get(node, set()))

    def dependents(self, node: str) -> Set[str]:
        """Get direct dependents of a node."""
        return set(self._reverse_edges.get(node, set()))

    def all_dependencies(self, node: str) -> Set[str]:
        """Get all transitive dependencies of a node."""
        visited: Set[str] = set()
        queue = deque(self._edges.get(node, set()))
        while queue:
            dep = queue.popleft()
            if dep not in visited:
                visited.add(dep)
                queue.extend(self._edges.get(dep, set()) - visited)
        return visited

    def validate(self) -> None:
        """Validate the DAG: check for cycles and missing dependencies."""
        # Check for missing dependencies
        for node, deps in self._edges.items():
            for dep in deps:
                if dep not in self._nodes:
                    raise MissingDependencyError(node, dep)

        # Check for cycles using DFS
        WHITE, GRAY, BLACK = 0, 1, 2
        color: Dict[str, int] = {n: WHITE for n in self._nodes}
        path: List[str] = []

        def dfs(node: str) -> None:
            color[node] = GRAY
            path.append(node)
            for dep in self._edges.get(node, set()):
                if color[dep] == GRAY:
                    cycle_start = path.index(dep)
                    raise CycleError(path[cycle_start:] + [dep])
                if color[dep] == WHITE:
                    dfs(dep)
            path.pop()
            color[node] = BLACK

        for node in self._nodes:
            if color[node] == WHITE:
                dfs(node)

    def topological_sort(self) -> List[str]:
        """Return nodes in topological order (dependencies first)."""
        self.validate()
        in_degree: Dict[str, int] = {n: 0 for n in self._nodes}
        for node, deps in self._edges.items():
            in_degree.setdefault(node, 0)
            # in_degree counts how many deps point TO this node
            # but our edges are "node depends on dep", so reverse
        for node in self._nodes:
            for dep in self._edges.get(node, set()):
                in_degree[node] = in_degree.get(node, 0)

        # Kahn's algorithm
        in_degree = {n: 0 for n in self._nodes}
        for node, deps in self._edges.items():
            in_degree[node] += len(deps)

        queue = deque(sorted(n for n in self._nodes if in_degree[n] == 0))
        result: List[str] = []

        while queue:
            node = queue.popleft()
            result.append(node)
            for dependent in sorted(self._reverse_edges.get(node, set())):
                in_degree[dependent] -= 1
                if in_degree[dependent] == 0:
                    queue.append(dependent)

        return result

    def execution_levels(self) -> List[List[str]]:
        """Return steps grouped by execution level for parallel execution.

        Steps in the same level have no dependencies on each other and
        can be executed in parallel.
        """
        self.validate()
        remaining = set(self._nodes)
        completed: Set[str] = set()
        levels: List[List[str]] = []

        while remaining:
            # Find all nodes whose dependencies are all completed
            ready = sorted([
                n for n in remaining
                if self._edges.get(n, set()).issubset(completed)
            ])
            if not ready:
                # This shouldn't happen after validate(), but just in case
                raise CycleError(list(remaining))
            levels.append(ready)
            completed.update(ready)
            remaining -= set(ready)

        return levels

    @property
    def nodes(self) -> Set[str]:
        return set(self._nodes)

    @property
    def node_count(self) -> int:
        return len(self._nodes)

    @property
    def edge_count(self) -> int:
        return sum(len(deps) for deps in self._edges.values())

    def __repr__(self) -> str:
        return f"DAG(nodes={self.node_count}, edges={self.edge_count})"
