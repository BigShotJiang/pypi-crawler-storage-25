"""Result types for step and pipeline execution."""

from __future__ import annotations

import enum
from dataclasses import dataclass, field
from typing import Any, Optional


class StepStatus(enum.Enum):
    """Status of a step execution."""
    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    SKIPPED = "skipped"
    CACHED = "cached"
    RETRYING = "retrying"


@dataclass
class StepResult:
    """Result of executing a single step."""
    step_name: str
    status: StepStatus
    output: Any = None
    error: Optional[Exception] = None
    duration_ms: float = 0.0
    retries: int = 0
    cached: bool = False
    skipped_reason: Optional[str] = None

    @property
    def success(self) -> bool:
        return self.status in (StepStatus.SUCCESS, StepStatus.CACHED)

    def __repr__(self) -> str:
        return (
            f"StepResult(name={self.step_name!r}, status={self.status.value}, "
            f"duration={self.duration_ms:.1f}ms, retries={self.retries})"
        )


@dataclass
class PipelineResult:
    """Result of executing a complete pipeline."""
    pipeline_name: str
    step_results: list[StepResult] = field(default_factory=list)
    total_duration_ms: float = 0.0
    error: Optional[Exception] = None

    @property
    def success(self) -> bool:
        return all(r.success or r.status == StepStatus.SKIPPED for r in self.step_results)

    @property
    def failed_steps(self) -> list[StepResult]:
        return [r for r in self.step_results if r.status == StepStatus.FAILED]

    @property
    def succeeded_steps(self) -> list[StepResult]:
        return [r for r in self.step_results if r.success]

    @property
    def skipped_steps(self) -> list[StepResult]:
        return [r for r in self.step_results if r.status == StepStatus.SKIPPED]

    @property
    def cached_steps(self) -> list[StepResult]:
        return [r for r in self.step_results if r.status == StepStatus.CACHED]

    def summary(self) -> str:
        """Return a human-readable summary."""
        total = len(self.step_results)
        ok = len(self.succeeded_steps)
        fail = len(self.failed_steps)
        skip = len(self.skipped_steps)
        cached = len(self.cached_steps)
        status = "PASSED" if self.success else "FAILED"
        lines = [
            f"Pipeline '{self.pipeline_name}' {status}",
            f"  Steps: {total} total, {ok} passed, {fail} failed, {skip} skipped, {cached} cached",
            f"  Duration: {self.total_duration_ms:.1f}ms",
        ]
        if self.failed_steps:
            lines.append("  Failed steps:")
            for r in self.failed_steps:
                lines.append(f"    - {r.step_name}: {r.error}")
        return "\n".join(lines)

    def __repr__(self) -> str:
        status = "SUCCESS" if self.success else "FAILED"
        return (
            f"PipelineResult(name={self.pipeline_name!r}, status={status}, "
            f"steps={len(self.step_results)}, duration={self.total_duration_ms:.1f}ms)"
        )
