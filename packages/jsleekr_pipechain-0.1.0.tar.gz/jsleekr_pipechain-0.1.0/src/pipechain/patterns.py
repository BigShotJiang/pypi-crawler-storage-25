"""Common step patterns and utilities."""

from __future__ import annotations

import asyncio
import time
from typing import Any, Callable, Dict, List, Optional, TypeVar

from pipechain.context import Context
from pipechain.step import Step


def map_step(
    name: str,
    fn: Callable[[Any], Any],
    input_key: str,
    output_key: Optional[str] = None,
    **kwargs: Any,
) -> Step:
    """Create a step that maps a function over a list.

    Args:
        name: Step name.
        fn: Function to apply to each item.
        input_key: Context key containing the input list.
        output_key: Context key for output. Defaults to '{name}.output'.
    """
    out_key = output_key or f"{name}.output"

    def mapper(ctx: Context):
        data = ctx.get(input_key, [])
        result = [fn(item) for item in data]
        ctx.set(out_key, result)
        return result

    return Step(name=name, fn=mapper, **kwargs)


def filter_step(
    name: str,
    predicate: Callable[[Any], bool],
    input_key: str,
    output_key: Optional[str] = None,
    **kwargs: Any,
) -> Step:
    """Create a step that filters a list.

    Args:
        name: Step name.
        predicate: Filter function.
        input_key: Context key containing the input list.
        output_key: Context key for output.
    """
    out_key = output_key or f"{name}.output"

    def filterer(ctx: Context):
        data = ctx.get(input_key, [])
        result = [item for item in data if predicate(item)]
        ctx.set(out_key, result)
        return result

    return Step(name=name, fn=filterer, **kwargs)


def reduce_step(
    name: str,
    fn: Callable[[Any, Any], Any],
    input_key: str,
    initial: Any = None,
    output_key: Optional[str] = None,
    **kwargs: Any,
) -> Step:
    """Create a step that reduces a list to a single value.

    Args:
        name: Step name.
        fn: Reduce function (accumulator, current) -> accumulator.
        input_key: Context key containing the input list.
        initial: Initial accumulator value.
        output_key: Context key for output.
    """
    out_key = output_key or f"{name}.output"

    def reducer(ctx: Context):
        from functools import reduce as _reduce
        data = ctx.get(input_key, [])
        if initial is not None:
            result = _reduce(fn, data, initial)
        else:
            result = _reduce(fn, data)
        ctx.set(out_key, result)
        return result

    return Step(name=name, fn=reducer, **kwargs)


def batch_step(
    name: str,
    fn: Callable[[List[Any]], Any],
    input_key: str,
    batch_size: int = 100,
    output_key: Optional[str] = None,
    **kwargs: Any,
) -> Step:
    """Create a step that processes data in batches.

    Args:
        name: Step name.
        fn: Function to apply to each batch.
        input_key: Context key containing the input list.
        batch_size: Number of items per batch.
        output_key: Context key for output.
    """
    out_key = output_key or f"{name}.output"

    def batcher(ctx: Context):
        data = ctx.get(input_key, [])
        results = []
        for i in range(0, len(data), batch_size):
            batch = data[i:i + batch_size]
            result = fn(batch)
            if isinstance(result, list):
                results.extend(result)
            else:
                results.append(result)
        ctx.set(out_key, results)
        return results

    return Step(name=name, fn=batcher, **kwargs)


def delay_step(
    name: str,
    seconds: float,
    **kwargs: Any,
) -> Step:
    """Create a step that introduces a delay.

    Useful for rate limiting or waiting for external systems.
    """
    async def delayer(ctx: Context):
        await asyncio.sleep(seconds)
        return seconds

    return Step(name=name, fn=delayer, description=f"Delay {seconds}s", **kwargs)


def log_step(
    name: str,
    message: str,
    **kwargs: Any,
) -> Step:
    """Create a step that logs a message to context."""
    def logger(ctx: Context):
        logs = ctx.get("_logs", [])
        logs.append({"step": name, "message": message, "time": time.time()})
        ctx.set("_logs", logs)
        return message

    return Step(name=name, fn=logger, description=f"Log: {message}", **kwargs)


def branch_step(
    name: str,
    condition: Callable[[Context], bool],
    if_true: Callable[[Context], Any],
    if_false: Callable[[Context], Any],
    **kwargs: Any,
) -> Step:
    """Create a step that branches based on a condition."""
    def brancher(ctx: Context):
        if condition(ctx):
            return if_true(ctx)
        return if_false(ctx)

    return Step(name=name, fn=brancher, **kwargs)
