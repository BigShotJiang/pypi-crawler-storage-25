"""Pipeline diff and comparison utilities."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set

from pipechain.pipeline import Pipeline


@dataclass
class PipelineDiff:
    """Result of comparing two pipelines."""
    added_steps: List[str] = field(default_factory=list)
    removed_steps: List[str] = field(default_factory=list)
    modified_steps: List[Dict[str, Any]] = field(default_factory=list)
    dependency_changes: List[Dict[str, Any]] = field(default_factory=list)
    config_changes: List[Dict[str, Any]] = field(default_factory=list)

    @property
    def has_changes(self) -> bool:
        return bool(
            self.added_steps or self.removed_steps or
            self.modified_steps or self.dependency_changes or
            self.config_changes
        )

    @property
    def change_count(self) -> int:
        return (
            len(self.added_steps) + len(self.removed_steps) +
            len(self.modified_steps) + len(self.dependency_changes) +
            len(self.config_changes)
        )

    def summary(self) -> str:
        """Return a human-readable diff summary."""
        if not self.has_changes:
            return "No changes"

        lines = []
        if self.added_steps:
            lines.append(f"Added steps: {', '.join(self.added_steps)}")
        if self.removed_steps:
            lines.append(f"Removed steps: {', '.join(self.removed_steps)}")
        if self.modified_steps:
            for m in self.modified_steps:
                lines.append(f"Modified step '{m['name']}': {m['field']} changed")
        if self.dependency_changes:
            for d in self.dependency_changes:
                lines.append(f"Dependency change for '{d['step']}': {d['change']}")
        if self.config_changes:
            for c in self.config_changes:
                lines.append(f"Config '{c['field']}': {c['old']} -> {c['new']}")
        return "\n".join(lines)


def diff_pipelines(old: Pipeline, new: Pipeline) -> PipelineDiff:
    """Compare two pipelines and return their differences."""
    result = PipelineDiff()

    old_names = {s.name for s in old.steps}
    new_names = {s.name for s in new.steps}

    # Added/removed steps
    result.added_steps = sorted(new_names - old_names)
    result.removed_steps = sorted(old_names - new_names)

    # Modified steps (compare common steps)
    common = old_names & new_names
    for name in sorted(common):
        old_step = old.get_step(name)
        new_step = new.get_step(name)
        if old_step is None or new_step is None:
            continue

        # Compare tags
        if set(old_step.tags) != set(new_step.tags):
            result.modified_steps.append({
                "name": name,
                "field": "tags",
                "old": old_step.tags,
                "new": new_step.tags,
            })

        # Compare timeout
        if old_step.timeout != new_step.timeout:
            result.modified_steps.append({
                "name": name,
                "field": "timeout",
                "old": old_step.timeout,
                "new": new_step.timeout,
            })

        # Compare retry
        if old_step.retry_policy.max_retries != new_step.retry_policy.max_retries:
            result.modified_steps.append({
                "name": name,
                "field": "retry.max_retries",
                "old": old_step.retry_policy.max_retries,
                "new": new_step.retry_policy.max_retries,
            })

        # Compare cache
        if old_step.cache_key != new_step.cache_key:
            result.modified_steps.append({
                "name": name,
                "field": "cache_key",
                "old": old_step.cache_key,
                "new": new_step.cache_key,
            })

        # Compare dependencies
        old_deps = set(old_step.depends_on)
        new_deps = set(new_step.depends_on)
        if old_deps != new_deps:
            added_deps = new_deps - old_deps
            removed_deps = old_deps - new_deps
            changes = []
            if added_deps:
                changes.append(f"added {added_deps}")
            if removed_deps:
                changes.append(f"removed {removed_deps}")
            result.dependency_changes.append({
                "step": name,
                "change": ", ".join(changes),
                "old": sorted(old_deps),
                "new": sorted(new_deps),
            })

    # Pipeline config changes
    if old.max_concurrency != new.max_concurrency:
        result.config_changes.append({
            "field": "max_concurrency",
            "old": old.max_concurrency,
            "new": new.max_concurrency,
        })
    if old.fail_fast != new.fail_fast:
        result.config_changes.append({
            "field": "fail_fast",
            "old": old.fail_fast,
            "new": new.fail_fast,
        })

    return result
