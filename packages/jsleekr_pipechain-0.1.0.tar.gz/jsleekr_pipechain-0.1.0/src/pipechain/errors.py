"""Custom exception types for pipechain."""

from __future__ import annotations

from typing import Any, Dict, List, Optional


class PipechainError(Exception):
    """Base exception for pipechain."""
    pass


class StepExecutionError(PipechainError):
    """Error during step execution."""
    def __init__(
        self,
        step_name: str,
        original_error: Exception,
        attempt: int = 0,
    ) -> None:
        self.step_name = step_name
        self.original_error = original_error
        self.attempt = attempt
        super().__init__(
            f"Step '{step_name}' failed on attempt {attempt}: {original_error}"
        )


class PipelineValidationError(PipechainError):
    """Error during pipeline validation."""
    def __init__(self, pipeline_name: str, errors: List[str]) -> None:
        self.pipeline_name = pipeline_name
        self.errors = errors
        super().__init__(
            f"Pipeline '{pipeline_name}' validation failed:\n"
            + "\n".join(f"  - {e}" for e in errors)
        )


class StepTimeoutError(PipechainError):
    """Error when a step exceeds its timeout."""
    def __init__(self, step_name: str, timeout: float) -> None:
        self.step_name = step_name
        self.timeout = timeout
        super().__init__(
            f"Step '{step_name}' timed out after {timeout}s"
        )


class DependencyError(PipechainError):
    """Error in step dependency resolution."""
    def __init__(self, step_name: str, missing_dep: str) -> None:
        self.step_name = step_name
        self.missing_dep = missing_dep
        super().__init__(
            f"Step '{step_name}' depends on '{missing_dep}' which does not exist"
        )


class CycleDetectedError(PipechainError):
    """Error when a cycle is detected in the DAG."""
    def __init__(self, cycle: List[str]) -> None:
        self.cycle = cycle
        super().__init__(f"Cycle detected: {' -> '.join(cycle)}")


class ContextError(PipechainError):
    """Error in context operations."""
    pass


class SerializationError(PipechainError):
    """Error during pipeline serialization/deserialization."""
    def __init__(self, message: str, data: Any = None) -> None:
        self.data = data
        super().__init__(message)
