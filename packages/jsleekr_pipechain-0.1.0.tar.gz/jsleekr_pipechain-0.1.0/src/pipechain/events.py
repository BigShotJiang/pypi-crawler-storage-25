"""Event emitter for pipeline observability and monitoring."""

from __future__ import annotations

import enum
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional


class EventType(enum.Enum):
    """Types of events emitted during pipeline execution."""
    PIPELINE_START = "pipeline_start"
    PIPELINE_END = "pipeline_end"
    STEP_START = "step_start"
    STEP_END = "step_end"
    STEP_SKIP = "step_skip"
    STEP_RETRY = "step_retry"
    STEP_CACHE_HIT = "step_cache_hit"
    CONTEXT_SET = "context_set"
    CONTEXT_SNAPSHOT = "context_snapshot"
    CONTEXT_ROLLBACK = "context_rollback"


@dataclass
class Event:
    """An event emitted during pipeline execution."""
    event_type: EventType
    timestamp: float = field(default_factory=time.time)
    data: Dict[str, Any] = field(default_factory=dict)

    def __repr__(self) -> str:
        return f"Event({self.event_type.value}, data={self.data})"


class EventEmitter:
    """Event emitter with typed listeners and event history.

    Supports both synchronous event handling and event history
    for post-execution analysis.
    """

    def __init__(self, max_history: int = 1000) -> None:
        self._listeners: Dict[EventType, List[Callable[[Event], Any]]] = {
            et: [] for et in EventType
        }
        self._global_listeners: List[Callable[[Event], Any]] = []
        self._history: List[Event] = []
        self._max_history = max_history
        self._enabled = True

    def on(self, event_type: EventType, listener: Callable[[Event], Any]) -> None:
        """Register a listener for a specific event type."""
        self._listeners[event_type].append(listener)

    def on_all(self, listener: Callable[[Event], Any]) -> None:
        """Register a listener for all event types."""
        self._global_listeners.append(listener)

    def off(self, event_type: EventType, listener: Callable[[Event], Any]) -> bool:
        """Remove a specific listener. Returns True if found."""
        try:
            self._listeners[event_type].remove(listener)
            return True
        except ValueError:
            return False

    def off_all(self, listener: Callable[[Event], Any]) -> bool:
        """Remove a global listener. Returns True if found."""
        try:
            self._global_listeners.remove(listener)
            return True
        except ValueError:
            return False

    def emit(self, event_type: EventType, **data: Any) -> Event:
        """Emit an event and notify all listeners."""
        event = Event(event_type=event_type, data=data)

        if not self._enabled:
            return event

        # Store in history
        if len(self._history) >= self._max_history:
            self._history.pop(0)
        self._history.append(event)

        # Notify type-specific listeners
        for listener in self._listeners.get(event_type, []):
            listener(event)

        # Notify global listeners
        for listener in self._global_listeners:
            listener(event)

        return event

    @property
    def history(self) -> List[Event]:
        """Get event history."""
        return list(self._history)

    def history_by_type(self, event_type: EventType) -> List[Event]:
        """Get events of a specific type."""
        return [e for e in self._history if e.event_type == event_type]

    def clear_history(self) -> int:
        """Clear event history. Returns count cleared."""
        count = len(self._history)
        self._history.clear()
        return count

    def enable(self) -> None:
        """Enable event emission."""
        self._enabled = True

    def disable(self) -> None:
        """Disable event emission (no-op emits)."""
        self._enabled = False

    @property
    def enabled(self) -> bool:
        return self._enabled

    def listener_count(self, event_type: Optional[EventType] = None) -> int:
        """Count listeners."""
        if event_type:
            return len(self._listeners.get(event_type, []))
        return sum(len(ls) for ls in self._listeners.values()) + len(self._global_listeners)

    def clear_listeners(self, event_type: Optional[EventType] = None) -> None:
        """Clear listeners."""
        if event_type:
            self._listeners[event_type] = []
        else:
            for et in EventType:
                self._listeners[et] = []
            self._global_listeners.clear()

    def timeline(self) -> List[Dict[str, Any]]:
        """Get a timeline representation of events."""
        if not self._history:
            return []
        base_time = self._history[0].timestamp
        return [
            {
                "offset_ms": (e.timestamp - base_time) * 1000,
                "type": e.event_type.value,
                **e.data,
            }
            for e in self._history
        ]
