"""Middleware system for wrapping step execution with cross-cutting concerns."""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any, Callable, Optional, Awaitable

from pipechain.context import Context
from pipechain.step import Step

# Type for middleware: receives step, context, and next function
MiddlewareFn = Callable[[Step, Context, Callable[..., Any]], Any]

logger = logging.getLogger("pipechain.middleware")


class Middleware:
    """Base class for pipeline middleware.

    Middleware wraps step execution, allowing cross-cutting concerns like
    logging, timing, validation, and transformation to be applied uniformly.
    """

    def __init__(self, name: Optional[str] = None) -> None:
        self.name = name or self.__class__.__name__

    async def __call__(self, step: Step, ctx: Context, next_fn: Callable) -> Any:
        """Execute the middleware. Must call next_fn() to continue the chain."""
        return await next_fn()

    def __repr__(self) -> str:
        return f"Middleware({self.name})"


class LoggingMiddleware(Middleware):
    """Middleware that logs step execution start/end and duration."""

    def __init__(self, logger_name: str = "pipechain.steps") -> None:
        super().__init__("logging")
        self._logger = logging.getLogger(logger_name)

    async def __call__(self, step: Step, ctx: Context, next_fn: Callable) -> Any:
        self._logger.info("Starting step: %s", step.name)
        start = time.perf_counter()
        try:
            result = await next_fn()
            elapsed = (time.perf_counter() - start) * 1000
            self._logger.info("Completed step: %s (%.1fms)", step.name, elapsed)
            return result
        except Exception as e:
            elapsed = (time.perf_counter() - start) * 1000
            self._logger.error("Failed step: %s (%.1fms) - %s", step.name, elapsed, e)
            raise


class TimingMiddleware(Middleware):
    """Middleware that stores step timing in context."""

    def __init__(self) -> None:
        super().__init__("timing")

    async def __call__(self, step: Step, ctx: Context, next_fn: Callable) -> Any:
        start = time.perf_counter()
        result = await next_fn()
        elapsed = (time.perf_counter() - start) * 1000
        ctx.set(f"{step.name}.duration_ms", elapsed)
        return result


class ValidatorMiddleware(Middleware):
    """Middleware that validates step input/output using callable validators."""

    def __init__(
        self,
        input_validator: Optional[Callable[[Context], bool]] = None,
        output_validator: Optional[Callable[[Any], bool]] = None,
    ) -> None:
        super().__init__("validator")
        self._input_validator = input_validator
        self._output_validator = output_validator

    async def __call__(self, step: Step, ctx: Context, next_fn: Callable) -> Any:
        if self._input_validator and not self._input_validator(ctx):
            raise ValueError(f"Input validation failed for step '{step.name}'")
        result = await next_fn()
        if self._output_validator and not self._output_validator(result):
            raise ValueError(f"Output validation failed for step '{step.name}'")
        return result


class TransformMiddleware(Middleware):
    """Middleware that transforms step output before storing."""

    def __init__(self, transform: Callable[[Any], Any]) -> None:
        super().__init__("transform")
        self._transform = transform

    async def __call__(self, step: Step, ctx: Context, next_fn: Callable) -> Any:
        result = await next_fn()
        return self._transform(result)


class MiddlewareChain:
    """Chain of middleware that wraps step execution."""

    def __init__(self) -> None:
        self._middlewares: list[Middleware] = []

    def use(self, middleware: Middleware) -> "MiddlewareChain":
        """Add a middleware to the chain. Returns self for chaining."""
        self._middlewares.append(middleware)
        return self

    async def execute(self, step: Step, ctx: Context, final_fn: Callable) -> Any:
        """Execute the middleware chain around the final function."""
        if not self._middlewares:
            return await final_fn()

        async def build_chain(index: int) -> Any:
            if index >= len(self._middlewares):
                return await final_fn()
            middleware = self._middlewares[index]
            return await middleware(step, ctx, lambda: build_chain(index + 1))

        return await build_chain(0)

    @property
    def count(self) -> int:
        return len(self._middlewares)

    def __repr__(self) -> str:
        names = [m.name for m in self._middlewares]
        return f"MiddlewareChain({names})"
