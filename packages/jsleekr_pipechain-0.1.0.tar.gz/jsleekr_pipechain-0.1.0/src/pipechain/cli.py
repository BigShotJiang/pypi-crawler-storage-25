"""CLI interface for pipechain."""

from __future__ import annotations

import argparse
import importlib.util
import json
import sys
import time
from pathlib import Path
from typing import Optional

from pipechain import __version__
from pipechain.pipeline import Pipeline
from pipechain.result import StepStatus


def load_pipeline_from_file(filepath: str) -> Pipeline:
    """Load a pipeline from a Python file.

    The file must define a variable named 'pipeline' of type Pipeline.
    """
    path = Path(filepath).resolve()
    if not path.exists():
        raise FileNotFoundError(f"Pipeline file not found: {filepath}")

    spec = importlib.util.spec_from_file_location("pipeline_module", str(path))
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load module from: {filepath}")

    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    pipeline = getattr(module, "pipeline", None)
    if pipeline is None:
        raise AttributeError(f"No 'pipeline' variable found in {filepath}")
    if not isinstance(pipeline, Pipeline):
        raise TypeError(f"'pipeline' must be a Pipeline instance, got {type(pipeline)}")

    return pipeline


def format_result_table(result) -> str:
    """Format pipeline result as a table."""
    lines = []
    # Header
    lines.append(f"{'Step':<30} {'Status':<10} {'Duration':<12} {'Retries':<8} {'Cached':<7}")
    lines.append("-" * 70)

    for sr in result.step_results:
        status_icon = {
            StepStatus.SUCCESS: "OK",
            StepStatus.FAILED: "FAIL",
            StepStatus.SKIPPED: "SKIP",
            StepStatus.CACHED: "CACHE",
        }.get(sr.status, sr.status.value)

        lines.append(
            f"{sr.step_name:<30} {status_icon:<10} {sr.duration_ms:>8.1f}ms  "
            f"{sr.retries:<8} {'yes' if sr.cached else 'no':<7}"
        )

    lines.append("-" * 70)
    status = "PASSED" if result.success else "FAILED"
    lines.append(f"Total: {result.total_duration_ms:.1f}ms | Status: {status}")
    return "\n".join(lines)


def cmd_run(args: argparse.Namespace) -> int:
    """Run a pipeline from a file."""
    try:
        pipeline = load_pipeline_from_file(args.file)
    except Exception as e:
        print(f"Error loading pipeline: {e}", file=sys.stderr)
        return 1

    print(f"Running pipeline: {pipeline.name}")
    if args.dry_run:
        print("(dry run mode)")
    print()

    result = pipeline.run(dry_run=args.dry_run, tags=args.tags)
    print(format_result_table(result))

    if args.json:
        output = {
            "pipeline": result.pipeline_name,
            "success": result.success,
            "duration_ms": result.total_duration_ms,
            "steps": [
                {
                    "name": sr.step_name,
                    "status": sr.status.value,
                    "duration_ms": sr.duration_ms,
                    "retries": sr.retries,
                    "cached": sr.cached,
                    "error": str(sr.error) if sr.error else None,
                }
                for sr in result.step_results
            ],
        }
        print()
        print(json.dumps(output, indent=2))

    return 0 if result.success else 1


def cmd_validate(args: argparse.Namespace) -> int:
    """Validate a pipeline file."""
    try:
        pipeline = load_pipeline_from_file(args.file)
    except Exception as e:
        print(f"Error loading pipeline: {e}", file=sys.stderr)
        return 1

    warnings = pipeline.validate()
    if warnings:
        print(f"Pipeline '{pipeline.name}' has {len(warnings)} warning(s):")
        for w in warnings:
            print(f"  - {w}")
        return 1
    else:
        print(f"Pipeline '{pipeline.name}' is valid ({len(pipeline.steps)} steps)")
        return 0


def cmd_visualize(args: argparse.Namespace) -> int:
    """Visualize the pipeline DAG."""
    try:
        pipeline = load_pipeline_from_file(args.file)
    except Exception as e:
        print(f"Error loading pipeline: {e}", file=sys.stderr)
        return 1

    print(pipeline.visualize())
    return 0


def cmd_plan(args: argparse.Namespace) -> int:
    """Show the execution plan."""
    try:
        pipeline = load_pipeline_from_file(args.file)
    except Exception as e:
        print(f"Error loading pipeline: {e}", file=sys.stderr)
        return 1

    levels = pipeline.execution_plan()
    print(f"Execution plan for '{pipeline.name}':")
    print()
    for i, level in enumerate(levels):
        parallel = " (parallel)" if len(level) > 1 else ""
        print(f"  Level {i}{parallel}: {', '.join(level)}")
    print()
    print(f"Total: {len(pipeline.steps)} steps in {len(levels)} levels")
    return 0


def main(argv: Optional[list[str]] = None) -> int:
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        prog="pipechain",
        description="Lightweight DAG-based data pipeline runner",
    )
    parser.add_argument("--version", action="version", version=f"pipechain {__version__}")

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # run command
    run_parser = subparsers.add_parser("run", help="Run a pipeline")
    run_parser.add_argument("file", help="Path to pipeline Python file")
    run_parser.add_argument("--dry-run", action="store_true", help="Dry run mode")
    run_parser.add_argument("--json", action="store_true", help="Output as JSON")
    run_parser.add_argument("--tags", nargs="+", help="Filter steps by tags")

    # validate command
    validate_parser = subparsers.add_parser("validate", help="Validate a pipeline")
    validate_parser.add_argument("file", help="Path to pipeline Python file")

    # visualize command
    viz_parser = subparsers.add_parser("visualize", help="Visualize the pipeline DAG")
    viz_parser.add_argument("file", help="Path to pipeline Python file")

    # plan command
    plan_parser = subparsers.add_parser("plan", help="Show execution plan")
    plan_parser.add_argument("file", help="Path to pipeline Python file")

    args = parser.parse_args(argv)

    if args.command is None:
        parser.print_help()
        return 0

    commands = {
        "run": cmd_run,
        "validate": cmd_validate,
        "visualize": cmd_visualize,
        "plan": cmd_plan,
    }

    return commands[args.command](args)


if __name__ == "__main__":
    sys.exit(main())
