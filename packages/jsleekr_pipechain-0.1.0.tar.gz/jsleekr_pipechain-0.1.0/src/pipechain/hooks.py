"""Hook system for pipeline lifecycle events."""

from __future__ import annotations

import enum
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional


class HookType(enum.Enum):
    """Types of hooks that can be registered."""
    BEFORE_PIPELINE = "before_pipeline"
    AFTER_PIPELINE = "after_pipeline"
    BEFORE_STEP = "before_step"
    AFTER_STEP = "after_step"
    ON_STEP_ERROR = "on_step_error"
    ON_STEP_RETRY = "on_step_retry"
    ON_STEP_SKIP = "on_step_skip"
    ON_STEP_CACHED = "on_step_cached"


@dataclass
class Hook:
    """A registered hook callback."""
    hook_type: HookType
    callback: Callable[..., Any]
    name: Optional[str] = None
    priority: int = 0  # Lower = higher priority

    def __repr__(self) -> str:
        name = self.name or self.callback.__name__
        return f"Hook({self.hook_type.value}, {name}, priority={self.priority})"


class HookRegistry:
    """Registry for managing pipeline hooks."""

    def __init__(self) -> None:
        self._hooks: Dict[HookType, List[Hook]] = {ht: [] for ht in HookType}

    def register(
        self,
        hook_type: HookType,
        callback: Callable[..., Any],
        name: Optional[str] = None,
        priority: int = 0,
    ) -> Hook:
        """Register a hook callback."""
        hook = Hook(hook_type=hook_type, callback=callback, name=name, priority=priority)
        self._hooks[hook_type].append(hook)
        self._hooks[hook_type].sort(key=lambda h: h.priority)
        return hook

    def unregister(self, hook: Hook) -> bool:
        """Unregister a previously registered hook."""
        hooks = self._hooks.get(hook.hook_type, [])
        try:
            hooks.remove(hook)
            return True
        except ValueError:
            return False

    def get_hooks(self, hook_type: HookType) -> List[Hook]:
        """Get all hooks for a given type, sorted by priority."""
        return list(self._hooks.get(hook_type, []))

    def fire(self, hook_type: HookType, **kwargs: Any) -> List[Any]:
        """Fire all hooks of a given type. Returns list of return values."""
        results = []
        for hook in self.get_hooks(hook_type):
            result = hook.callback(**kwargs)
            results.append(result)
        return results

    async def async_fire(self, hook_type: HookType, **kwargs: Any) -> List[Any]:
        """Fire all hooks asynchronously."""
        import asyncio
        results = []
        for hook in self.get_hooks(hook_type):
            result = hook.callback(**kwargs)
            if asyncio.iscoroutine(result):
                result = await result
            results.append(result)
        return results

    def clear(self, hook_type: Optional[HookType] = None) -> None:
        """Clear hooks. If hook_type is None, clear all."""
        if hook_type is None:
            for ht in HookType:
                self._hooks[ht] = []
        else:
            self._hooks[hook_type] = []

    def count(self, hook_type: Optional[HookType] = None) -> int:
        """Count registered hooks."""
        if hook_type is None:
            return sum(len(hooks) for hooks in self._hooks.values())
        return len(self._hooks.get(hook_type, []))
