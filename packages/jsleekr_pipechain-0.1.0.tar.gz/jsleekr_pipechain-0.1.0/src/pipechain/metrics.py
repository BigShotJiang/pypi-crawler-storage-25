"""Metrics collection for pipeline execution monitoring."""

from __future__ import annotations

import statistics
import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class StepMetrics:
    """Aggregated metrics for a single step across runs."""
    step_name: str
    run_count: int = 0
    success_count: int = 0
    failure_count: int = 0
    skip_count: int = 0
    cache_hit_count: int = 0
    total_retries: int = 0
    durations_ms: List[float] = field(default_factory=list)

    @property
    def failure_rate(self) -> float:
        if self.run_count == 0:
            return 0.0
        return self.failure_count / self.run_count

    @property
    def cache_hit_rate(self) -> float:
        if self.run_count == 0:
            return 0.0
        return self.cache_hit_count / self.run_count

    @property
    def avg_duration_ms(self) -> float:
        if not self.durations_ms:
            return 0.0
        return statistics.mean(self.durations_ms)

    @property
    def median_duration_ms(self) -> float:
        if not self.durations_ms:
            return 0.0
        return statistics.median(self.durations_ms)

    @property
    def p95_duration_ms(self) -> float:
        if len(self.durations_ms) < 2:
            return self.avg_duration_ms
        sorted_d = sorted(self.durations_ms)
        idx = int(len(sorted_d) * 0.95)
        return sorted_d[min(idx, len(sorted_d) - 1)]

    @property
    def min_duration_ms(self) -> float:
        if not self.durations_ms:
            return 0.0
        return min(self.durations_ms)

    @property
    def max_duration_ms(self) -> float:
        if not self.durations_ms:
            return 0.0
        return max(self.durations_ms)


@dataclass
class PipelineMetrics:
    """Aggregated metrics for a pipeline across runs."""
    pipeline_name: str
    run_count: int = 0
    success_count: int = 0
    failure_count: int = 0
    durations_ms: List[float] = field(default_factory=list)
    step_metrics: Dict[str, StepMetrics] = field(default_factory=dict)

    @property
    def success_rate(self) -> float:
        if self.run_count == 0:
            return 0.0
        return self.success_count / self.run_count

    @property
    def avg_duration_ms(self) -> float:
        if not self.durations_ms:
            return 0.0
        return statistics.mean(self.durations_ms)

    @property
    def slowest_steps(self) -> List[tuple[str, float]]:
        """Return steps sorted by average duration (slowest first)."""
        items = [
            (name, m.avg_duration_ms)
            for name, m in self.step_metrics.items()
            if m.durations_ms
        ]
        return sorted(items, key=lambda x: x[1], reverse=True)

    @property
    def most_failed_steps(self) -> List[tuple[str, float]]:
        """Return steps sorted by failure rate (highest first)."""
        items = [
            (name, m.failure_rate)
            for name, m in self.step_metrics.items()
            if m.run_count > 0
        ]
        return sorted(items, key=lambda x: x[1], reverse=True)


class MetricsCollector:
    """Collects and aggregates pipeline execution metrics."""

    def __init__(self) -> None:
        self._pipeline_metrics: Dict[str, PipelineMetrics] = {}

    def record_pipeline_run(self, result) -> None:
        """Record metrics from a PipelineResult."""
        name = result.pipeline_name
        if name not in self._pipeline_metrics:
            self._pipeline_metrics[name] = PipelineMetrics(pipeline_name=name)

        pm = self._pipeline_metrics[name]
        pm.run_count += 1
        if result.success:
            pm.success_count += 1
        else:
            pm.failure_count += 1
        pm.durations_ms.append(result.total_duration_ms)

        for sr in result.step_results:
            if sr.step_name not in pm.step_metrics:
                pm.step_metrics[sr.step_name] = StepMetrics(step_name=sr.step_name)

            sm = pm.step_metrics[sr.step_name]
            sm.run_count += 1

            from pipechain.result import StepStatus
            if sr.status == StepStatus.SUCCESS:
                sm.success_count += 1
                sm.durations_ms.append(sr.duration_ms)
            elif sr.status == StepStatus.FAILED:
                sm.failure_count += 1
                sm.durations_ms.append(sr.duration_ms)
            elif sr.status == StepStatus.SKIPPED:
                sm.skip_count += 1
            elif sr.status == StepStatus.CACHED:
                sm.cache_hit_count += 1
                sm.success_count += 1
                sm.durations_ms.append(sr.duration_ms)

            sm.total_retries += sr.retries

    def get_pipeline_metrics(self, name: str) -> Optional[PipelineMetrics]:
        """Get metrics for a specific pipeline."""
        return self._pipeline_metrics.get(name)

    def get_all_metrics(self) -> Dict[str, PipelineMetrics]:
        """Get all pipeline metrics."""
        return dict(self._pipeline_metrics)

    def reset(self, name: Optional[str] = None) -> None:
        """Reset metrics. If name provided, only reset that pipeline."""
        if name:
            self._pipeline_metrics.pop(name, None)
        else:
            self._pipeline_metrics.clear()

    def summary(self, name: str) -> str:
        """Return a human-readable metrics summary."""
        pm = self._pipeline_metrics.get(name)
        if not pm:
            return f"No metrics for pipeline '{name}'"

        lines = [
            f"Metrics for '{name}':",
            f"  Runs: {pm.run_count} ({pm.success_count} ok, {pm.failure_count} failed)",
            f"  Success rate: {pm.success_rate:.1%}",
            f"  Avg duration: {pm.avg_duration_ms:.1f}ms",
        ]

        if pm.slowest_steps:
            lines.append("  Slowest steps:")
            for step_name, avg in pm.slowest_steps[:5]:
                lines.append(f"    {step_name}: {avg:.1f}ms avg")

        if any(m.failure_rate > 0 for m in pm.step_metrics.values()):
            lines.append("  Steps with failures:")
            for step_name, rate in pm.most_failed_steps:
                if rate > 0:
                    lines.append(f"    {step_name}: {rate:.1%} failure rate")

        return "\n".join(lines)
