"""Step definition and decorator for pipeline steps."""

from __future__ import annotations

import asyncio
import functools
import inspect as _inspect
from typing import Any, Callable, Dict, List, Optional, Union

from pipechain.cache import CacheBackend
from pipechain.context import Context
from pipechain.retry import RetryPolicy


class Step:
    """A single step in a pipeline DAG.

    A step wraps a callable (sync or async) that receives a Context and returns
    a result. Steps can declare dependencies on other steps, retry policies,
    caching behavior, and conditional execution.
    """

    def __init__(
        self,
        name: str,
        fn: Callable[..., Any],
        depends_on: Optional[List[str]] = None,
        retry_policy: Optional[RetryPolicy] = None,
        cache_key: Optional[str] = None,
        cache_ttl: Optional[float] = None,
        condition: Optional[Callable[[Context], bool]] = None,
        timeout: Optional[float] = None,
        tags: Optional[List[str]] = None,
        description: Optional[str] = None,
    ) -> None:
        self.name = name
        self.fn = fn
        self.depends_on: List[str] = list(depends_on or [])
        self.retry_policy = retry_policy or RetryPolicy.none()
        self.cache_key = cache_key
        self.cache_ttl = cache_ttl
        self.condition = condition
        self.timeout = timeout
        self.tags: List[str] = list(tags or [])
        self.description = description or fn.__doc__ or ""
        self._is_async = _inspect.iscoroutinefunction(fn)

    @property
    def is_async(self) -> bool:
        return self._is_async

    async def execute(self, ctx: Context) -> Any:
        """Execute the step function with the given context."""
        if self._is_async:
            if self.timeout:
                return await asyncio.wait_for(self.fn(ctx), timeout=self.timeout)
            return await self.fn(ctx)
        else:
            loop = asyncio.get_event_loop()
            if self.timeout:
                return await asyncio.wait_for(
                    loop.run_in_executor(None, self.fn, ctx),
                    timeout=self.timeout,
                )
            return await loop.run_in_executor(None, self.fn, ctx)

    def should_run(self, ctx: Context) -> bool:
        """Check if the step's condition allows it to run."""
        if self.condition is None:
            return True
        return self.condition(ctx)

    def get_cache_key(self, ctx: Context) -> Optional[str]:
        """Get the cache key for this step execution."""
        if self.cache_key is None:
            return None
        if callable(self.cache_key):
            return self.cache_key(ctx)
        return self.cache_key

    def __repr__(self) -> str:
        deps = f", depends_on={self.depends_on}" if self.depends_on else ""
        return f"Step({self.name!r}{deps})"


def step(
    name: Optional[str] = None,
    depends_on: Optional[List[str]] = None,
    retry: Optional[Union[RetryPolicy, int]] = None,
    cache_key: Optional[str] = None,
    cache_ttl: Optional[float] = None,
    condition: Optional[Callable[[Context], bool]] = None,
    timeout: Optional[float] = None,
    tags: Optional[List[str]] = None,
    description: Optional[str] = None,
) -> Callable:
    """Decorator to create a Step from a function.

    Usage:
        @step(name="load_data", depends_on=["init"])
        def load_data(ctx: Context) -> dict:
            return {"users": [...]}

        @step("transform", depends_on=["load_data"], retry=3)
        async def transform(ctx: Context) -> list:
            data = ctx.get("load_data.output")
            return [transform_user(u) for u in data["users"]]
    """
    def decorator(fn: Callable) -> Step:
        step_name = name or fn.__name__
        retry_policy = None
        if isinstance(retry, int):
            retry_policy = RetryPolicy(max_retries=retry)
        elif isinstance(retry, RetryPolicy):
            retry_policy = retry

        s = Step(
            name=step_name,
            fn=fn,
            depends_on=depends_on,
            retry_policy=retry_policy,
            cache_key=cache_key,
            cache_ttl=cache_ttl,
            condition=condition,
            timeout=timeout,
            tags=tags,
            description=description,
        )
        functools.update_wrapper(s, fn)
        return s

    return decorator
