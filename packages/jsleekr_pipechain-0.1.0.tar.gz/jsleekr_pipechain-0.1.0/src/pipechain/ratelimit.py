"""Rate limiting for step execution."""

from __future__ import annotations

import asyncio
import time
import threading
from typing import Optional


class RateLimiter:
    """Token bucket rate limiter for controlling step execution rate.

    Useful for steps that call external APIs with rate limits.
    """

    def __init__(
        self,
        rate: float,
        burst: int = 1,
        per: float = 1.0,
    ) -> None:
        """
        Args:
            rate: Number of operations per time period.
            burst: Maximum burst size (token bucket capacity).
            per: Time period in seconds (default 1.0 = per second).
        """
        self._rate = rate
        self._burst = burst
        self._per = per
        self._tokens = float(burst)
        self._last_refill = time.monotonic()
        self._lock = threading.Lock()

    def _refill(self) -> None:
        """Refill tokens based on elapsed time."""
        now = time.monotonic()
        elapsed = now - self._last_refill
        self._tokens = min(
            self._burst,
            self._tokens + elapsed * (self._rate / self._per),
        )
        self._last_refill = now

    def acquire(self, timeout: Optional[float] = None) -> bool:
        """Acquire a token synchronously. Returns True if acquired."""
        deadline = time.monotonic() + timeout if timeout else None

        while True:
            with self._lock:
                self._refill()
                if self._tokens >= 1.0:
                    self._tokens -= 1.0
                    return True

            if deadline and time.monotonic() >= deadline:
                return False

            # Wait a bit before retrying
            wait_time = self._per / self._rate
            if deadline:
                wait_time = min(wait_time, deadline - time.monotonic())
            if wait_time > 0:
                time.sleep(wait_time)

    async def async_acquire(self, timeout: Optional[float] = None) -> bool:
        """Acquire a token asynchronously."""
        deadline = time.monotonic() + timeout if timeout else None

        while True:
            with self._lock:
                self._refill()
                if self._tokens >= 1.0:
                    self._tokens -= 1.0
                    return True

            if deadline and time.monotonic() >= deadline:
                return False

            wait_time = self._per / self._rate
            if deadline:
                wait_time = min(wait_time, deadline - time.monotonic())
            if wait_time > 0:
                await asyncio.sleep(wait_time)

    @property
    def available_tokens(self) -> float:
        """Get current available tokens."""
        with self._lock:
            self._refill()
            return self._tokens

    @property
    def rate(self) -> float:
        return self._rate

    @property
    def burst(self) -> int:
        return self._burst

    def reset(self) -> None:
        """Reset the rate limiter to full capacity."""
        with self._lock:
            self._tokens = float(self._burst)
            self._last_refill = time.monotonic()

    def __repr__(self) -> str:
        return f"RateLimiter(rate={self._rate}, burst={self._burst}, per={self._per})"
