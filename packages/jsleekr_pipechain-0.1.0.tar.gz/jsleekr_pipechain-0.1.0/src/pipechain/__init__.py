"""pipechain - Lightweight DAG-based data pipeline runner."""

__version__ = "0.1.0"

from pipechain.step import Step, step
from pipechain.pipeline import Pipeline
from pipechain.context import Context
from pipechain.result import StepResult, PipelineResult, StepStatus
from pipechain.retry import RetryPolicy
from pipechain.cache import CacheBackend, MemoryCache, FileCache
from pipechain.hooks import HookType, Hook
from pipechain.compose import compose, merge
from pipechain.builder import PipelineBuilder, StepBuilder
from pipechain.errors import (
    PipechainError, StepExecutionError, PipelineValidationError,
    StepTimeoutError, DependencyError, CycleDetectedError,
)

__all__ = [
    # Core
    "Step",
    "step",
    "Pipeline",
    "Context",
    "StepResult",
    "PipelineResult",
    "StepStatus",
    # Config
    "RetryPolicy",
    "CacheBackend",
    "MemoryCache",
    "FileCache",
    "HookType",
    "Hook",
    # Composition
    "compose",
    "merge",
    # Builder
    "PipelineBuilder",
    "StepBuilder",
    # Errors
    "PipechainError",
    "StepExecutionError",
    "PipelineValidationError",
    "StepTimeoutError",
    "DependencyError",
    "CycleDetectedError",
]
