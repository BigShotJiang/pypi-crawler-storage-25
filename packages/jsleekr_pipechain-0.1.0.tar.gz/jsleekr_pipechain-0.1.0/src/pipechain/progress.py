"""Progress tracking for pipeline execution."""

from __future__ import annotations

import sys
import time
from typing import Any, Callable, IO, Optional

from pipechain.result import StepStatus


class ProgressTracker:
    """Track and display pipeline execution progress.

    Provides both callback-based and text-based progress reporting.
    """

    def __init__(
        self,
        total_steps: int = 0,
        output: IO = sys.stderr,
        show_bar: bool = True,
        bar_width: int = 30,
    ) -> None:
        self._total = total_steps
        self._completed = 0
        self._failed = 0
        self._skipped = 0
        self._current_step: Optional[str] = None
        self._output = output
        self._show_bar = show_bar
        self._bar_width = bar_width
        self._start_time: Optional[float] = None
        self._callbacks: list[Callable[[dict], None]] = []
        self._step_times: dict[str, float] = {}

    def start(self, total_steps: int) -> None:
        """Start tracking with known total."""
        self._total = total_steps
        self._completed = 0
        self._failed = 0
        self._skipped = 0
        self._start_time = time.time()

    def step_started(self, step_name: str) -> None:
        """Mark a step as started."""
        self._current_step = step_name
        self._step_times[step_name] = time.time()
        self._notify({
            "event": "step_started",
            "step": step_name,
            "progress": self.progress,
        })

    def step_completed(self, step_name: str, status: StepStatus) -> None:
        """Mark a step as completed."""
        elapsed = 0.0
        if step_name in self._step_times:
            elapsed = (time.time() - self._step_times[step_name]) * 1000

        if status in (StepStatus.SUCCESS, StepStatus.CACHED):
            self._completed += 1
        elif status == StepStatus.FAILED:
            self._failed += 1
        elif status == StepStatus.SKIPPED:
            self._skipped += 1

        self._notify({
            "event": "step_completed",
            "step": step_name,
            "status": status.value,
            "duration_ms": elapsed,
            "progress": self.progress,
        })

    @property
    def progress(self) -> float:
        """Get progress as a float between 0.0 and 1.0."""
        if self._total == 0:
            return 1.0
        done = self._completed + self._failed + self._skipped
        return min(done / self._total, 1.0)

    @property
    def elapsed_ms(self) -> float:
        """Get elapsed time in milliseconds."""
        if self._start_time is None:
            return 0.0
        return (time.time() - self._start_time) * 1000

    @property
    def eta_ms(self) -> Optional[float]:
        """Estimate remaining time in milliseconds."""
        p = self.progress
        if p <= 0:
            return None
        if p >= 1.0:
            return 0.0
        return self.elapsed_ms * (1.0 - p) / p

    def on_progress(self, callback: Callable[[dict], None]) -> None:
        """Register a progress callback."""
        self._callbacks.append(callback)

    def _notify(self, data: dict) -> None:
        """Notify all registered callbacks."""
        for cb in self._callbacks:
            cb(data)

    def bar(self) -> str:
        """Generate a progress bar string."""
        p = self.progress
        filled = int(self._bar_width * p)
        bar = "#" * filled + "-" * (self._bar_width - filled)
        pct = int(p * 100)
        done = self._completed + self._failed + self._skipped
        parts = [f"[{bar}] {pct}% ({done}/{self._total})"]
        if self._current_step:
            parts.append(f"  {self._current_step}")
        if self._failed > 0:
            parts.append(f"  ({self._failed} failed)")
        return "".join(parts)

    def summary(self) -> dict:
        """Get a summary of progress."""
        return {
            "total": self._total,
            "completed": self._completed,
            "failed": self._failed,
            "skipped": self._skipped,
            "progress": self.progress,
            "elapsed_ms": self.elapsed_ms,
            "eta_ms": self.eta_ms,
        }
