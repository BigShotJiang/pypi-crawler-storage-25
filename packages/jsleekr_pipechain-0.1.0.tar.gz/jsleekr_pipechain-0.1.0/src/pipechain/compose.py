"""Pipeline composition utilities for combining multiple pipelines."""

from __future__ import annotations

from typing import Any, Callable, List, Optional

from pipechain.context import Context
from pipechain.pipeline import Pipeline
from pipechain.step import Step
from pipechain.result import PipelineResult


def compose(*pipelines: Pipeline, name: Optional[str] = None) -> Pipeline:
    """Compose multiple pipelines into a sequential mega-pipeline.

    Each pipeline runs as a single step in the composed pipeline, in order.
    Context is shared across all pipelines.

    Args:
        *pipelines: Pipelines to compose.
        name: Name for the composed pipeline.

    Returns:
        A new Pipeline that runs each input pipeline as a step.
    """
    composed_name = name or f"composed({', '.join(p.name for p in pipelines)})"
    composed = Pipeline(composed_name)

    prev_name: Optional[str] = None
    for p in pipelines:
        step_name = f"sub:{p.name}"

        def make_fn(pipeline: Pipeline):
            def run_sub(ctx: Context) -> PipelineResult:
                result = pipeline.run(context=ctx)
                if not result.success:
                    raise RuntimeError(
                        f"Sub-pipeline '{pipeline.name}' failed: "
                        + ", ".join(f"{s.step_name}: {s.error}" for s in result.failed_steps)
                    )
                return result
            return run_sub

        deps = [prev_name] if prev_name else []
        composed.add_step(Step(
            name=step_name,
            fn=make_fn(p),
            depends_on=deps,
            description=f"Run sub-pipeline: {p.name}",
        ))
        prev_name = step_name

    return composed


def merge(*pipelines: Pipeline, name: Optional[str] = None) -> Pipeline:
    """Merge multiple pipelines to run in parallel as a single pipeline.

    All pipelines run concurrently. Context is shared.

    Args:
        *pipelines: Pipelines to merge.
        name: Name for the merged pipeline.

    Returns:
        A new Pipeline that runs all input pipelines as parallel steps.
    """
    merged_name = name or f"merged({', '.join(p.name for p in pipelines)})"
    merged = Pipeline(merged_name)

    for p in pipelines:
        step_name = f"sub:{p.name}"

        def make_fn(pipeline: Pipeline):
            def run_sub(ctx: Context) -> PipelineResult:
                result = pipeline.run(context=ctx)
                if not result.success:
                    raise RuntimeError(
                        f"Sub-pipeline '{pipeline.name}' failed: "
                        + ", ".join(f"{s.step_name}: {s.error}" for s in result.failed_steps)
                    )
                return result
            return run_sub

        merged.add_step(Step(
            name=step_name,
            fn=make_fn(p),
            description=f"Run sub-pipeline: {p.name}",
        ))

    return merged
