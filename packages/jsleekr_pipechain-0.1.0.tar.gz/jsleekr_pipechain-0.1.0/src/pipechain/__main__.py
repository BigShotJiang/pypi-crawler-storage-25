"""Allow running pipechain as ``python -m pipechain``."""
import sys

from pipechain.cli import main

sys.exit(main())
