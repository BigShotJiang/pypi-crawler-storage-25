"""Data transformation utilities for context values."""

from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional, Sequence

from pipechain.context import Context


class ContextTransformer:
    """Utility for transforming and validating context data."""

    def __init__(self, ctx: Context) -> None:
        self._ctx = ctx

    def pluck(self, *keys: str) -> Dict[str, Any]:
        """Extract multiple keys from context into a dict."""
        return {k: self._ctx.get(k) for k in keys if self._ctx.has(k)}

    def rename(self, old_key: str, new_key: str) -> bool:
        """Rename a context key."""
        if not self._ctx.has(old_key):
            return False
        value = self._ctx.get(old_key)
        self._ctx.set(new_key, value)
        self._ctx.delete(old_key)
        return True

    def transform_value(self, key: str, fn: Callable[[Any], Any]) -> Any:
        """Apply a transformation function to a value in-place."""
        value = self._ctx.get(key)
        if value is not None:
            new_value = fn(value)
            self._ctx.set(key, new_value)
            return new_value
        return None

    def copy(self, src_key: str, dst_key: str) -> bool:
        """Copy a value from one key to another."""
        if not self._ctx.has(src_key):
            return False
        self._ctx.set(dst_key, self._ctx.get(src_key))
        return True

    def default(self, key: str, value: Any) -> Any:
        """Set a default value if key doesn't exist. Returns the value."""
        if not self._ctx.has(key):
            self._ctx.set(key, value)
            return value
        return self._ctx.get(key)

    def require(self, *keys: str) -> Dict[str, Any]:
        """Get multiple keys, raising if any are missing."""
        missing = [k for k in keys if not self._ctx.has(k)]
        if missing:
            raise KeyError(f"Missing required context keys: {missing}")
        return {k: self._ctx.get(k) for k in keys}

    def validate(self, key: str, validator: Callable[[Any], bool], message: str = "") -> bool:
        """Validate a context value. Returns True if valid."""
        value = self._ctx.get(key)
        if value is None:
            return False
        if not validator(value):
            if message:
                raise ValueError(f"Validation failed for '{key}': {message}")
            return False
        return True

    def flatten(self, prefix: str, target_key: Optional[str] = None) -> Dict[str, Any]:
        """Flatten namespaced keys into a dict and optionally store it."""
        data = self._ctx.namespace(prefix)
        if target_key:
            self._ctx.set(target_key, data)
        return data

    def collect_outputs(self, *step_names: str) -> Dict[str, Any]:
        """Collect outputs from multiple steps."""
        return {
            name: self._ctx.get(f"{name}.output")
            for name in step_names
            if self._ctx.has(f"{name}.output")
        }

    def pipe(self, key: str, *fns: Callable[[Any], Any]) -> Any:
        """Apply a sequence of transforms to a value."""
        value = self._ctx.get(key)
        for fn in fns:
            if value is None:
                break
            value = fn(value)
        self._ctx.set(key, value)
        return value
