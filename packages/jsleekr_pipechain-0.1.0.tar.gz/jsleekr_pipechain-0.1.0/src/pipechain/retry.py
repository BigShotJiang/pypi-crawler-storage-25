"""Retry policies for step execution."""

from __future__ import annotations

import asyncio
import random
import time
from dataclasses import dataclass, field
from typing import Optional, Tuple, Type


@dataclass
class RetryPolicy:
    """Configurable retry policy with exponential backoff and jitter.

    Args:
        max_retries: Maximum number of retry attempts (0 = no retries).
        base_delay: Base delay in seconds before first retry.
        max_delay: Maximum delay in seconds (caps exponential growth).
        exponential_base: Multiplier for exponential backoff (default 2.0).
        jitter: Whether to add random jitter to delays.
        retry_on: Tuple of exception types to retry on. None = retry on all.
        no_retry_on: Tuple of exception types to never retry on.
    """
    max_retries: int = 3
    base_delay: float = 1.0
    max_delay: float = 60.0
    exponential_base: float = 2.0
    jitter: bool = True
    retry_on: Optional[Tuple[Type[Exception], ...]] = None
    no_retry_on: Tuple[Type[Exception], ...] = field(
        default_factory=lambda: (KeyboardInterrupt, SystemExit)
    )

    def should_retry(self, error: Exception, attempt: int) -> bool:
        """Determine if we should retry for the given error and attempt."""
        if attempt >= self.max_retries:
            return False
        if self.no_retry_on and isinstance(error, self.no_retry_on):
            return False
        if self.retry_on is not None:
            return isinstance(error, self.retry_on)
        return True

    def get_delay(self, attempt: int) -> float:
        """Calculate delay for the given attempt number (0-indexed)."""
        delay = self.base_delay * (self.exponential_base ** attempt)
        delay = min(delay, self.max_delay)
        if self.jitter:
            delay = delay * (0.5 + random.random() * 0.5)
        return delay

    def wait(self, attempt: int) -> None:
        """Synchronously wait for the calculated delay."""
        delay = self.get_delay(attempt)
        time.sleep(delay)

    async def async_wait(self, attempt: int) -> None:
        """Asynchronously wait for the calculated delay."""
        delay = self.get_delay(attempt)
        await asyncio.sleep(delay)

    @staticmethod
    def none() -> RetryPolicy:
        """Create a policy that never retries."""
        return RetryPolicy(max_retries=0)

    @staticmethod
    def linear(max_retries: int = 3, delay: float = 1.0) -> RetryPolicy:
        """Create a policy with linear (constant) delays."""
        return RetryPolicy(
            max_retries=max_retries,
            base_delay=delay,
            exponential_base=1.0,
            jitter=False,
        )

    @staticmethod
    def exponential(
        max_retries: int = 3,
        base_delay: float = 1.0,
        max_delay: float = 60.0,
    ) -> RetryPolicy:
        """Create a policy with exponential backoff and jitter."""
        return RetryPolicy(
            max_retries=max_retries,
            base_delay=base_delay,
            max_delay=max_delay,
            jitter=True,
        )
