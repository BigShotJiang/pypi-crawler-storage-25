"""Export pipeline DAGs to various graph formats."""

from __future__ import annotations

from typing import Optional

from pipechain.pipeline import Pipeline


def to_dot(pipeline: Pipeline, rankdir: str = "TB") -> str:
    """Export pipeline DAG as Graphviz DOT format.

    Args:
        pipeline: Pipeline to export.
        rankdir: Graph direction: TB (top-bottom), LR (left-right).
    """
    lines = [
        f'digraph "{pipeline.name}" {{',
        f'  rankdir={rankdir};',
        '  node [shape=box, style="rounded,filled", fillcolor="#e8f4fd"];',
        "",
    ]

    for step in pipeline.steps:
        label = step.name
        attrs = []
        if step.tags:
            attrs.append(f"tags: {', '.join(step.tags)}")
        if step.timeout:
            attrs.append(f"timeout: {step.timeout}s")
        if step.retry_policy.max_retries > 0:
            attrs.append(f"retries: {step.retry_policy.max_retries}")
        if step.cache_key:
            attrs.append("cached")

        if attrs:
            label += f"\\n({', '.join(attrs)})"

        lines.append(f'  "{step.name}" [label="{label}"];')

    lines.append("")

    for step in pipeline.steps:
        for dep in step.depends_on:
            lines.append(f'  "{dep}" -> "{step.name}";')

    lines.append("}")
    return "\n".join(lines)


def to_mermaid(pipeline: Pipeline, direction: str = "TB") -> str:
    """Export pipeline DAG as Mermaid diagram.

    Args:
        pipeline: Pipeline to export.
        direction: Graph direction: TB, BT, LR, RL.
    """
    lines = [
        f"graph {direction}",
    ]

    for step in pipeline.steps:
        extras = []
        if step.tags:
            extras.append(f"#{', #'.join(step.tags)}")
        if step.cache_key:
            extras.append("cached")

        label = step.name
        if extras:
            label += f" ({', '.join(extras)})"

        lines.append(f"  {step.name}[{label}]")

    lines.append("")

    for step in pipeline.steps:
        for dep in step.depends_on:
            lines.append(f"  {dep} --> {step.name}")

    return "\n".join(lines)


def to_ascii(pipeline: Pipeline) -> str:
    """Export pipeline DAG as ASCII art (alias for pipeline.visualize())."""
    return pipeline.visualize()


def to_json_graph(pipeline: Pipeline) -> dict:
    """Export pipeline DAG as a JSON graph structure.

    Returns a dict with 'nodes' and 'edges' arrays suitable for
    visualization libraries like D3.js or vis.js.
    """
    nodes = []
    edges = []

    for step in pipeline.steps:
        nodes.append({
            "id": step.name,
            "label": step.name,
            "description": step.description,
            "tags": step.tags,
            "has_cache": step.cache_key is not None,
            "has_retry": step.retry_policy.max_retries > 0,
            "timeout": step.timeout,
        })
        for dep in step.depends_on:
            edges.append({
                "source": dep,
                "target": step.name,
            })

    return {
        "name": pipeline.name,
        "nodes": nodes,
        "edges": edges,
    }
