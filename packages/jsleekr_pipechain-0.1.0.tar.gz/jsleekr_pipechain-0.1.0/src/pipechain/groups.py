"""Step groups for organizing and running subsets of pipeline steps."""

from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional, Set

from pipechain.step import Step


class StepGroup:
    """A named group of steps that can be selected for execution.

    Groups allow organizing steps into logical units (e.g., 'extract',
    'transform', 'load') and running only specific groups.
    """

    def __init__(self, name: str, description: str = "") -> None:
        self.name = name
        self.description = description
        self._step_names: Set[str] = set()

    def add(self, *step_names: str) -> "StepGroup":
        """Add step names to this group."""
        self._step_names.update(step_names)
        return self

    def remove(self, step_name: str) -> bool:
        """Remove a step from this group."""
        if step_name in self._step_names:
            self._step_names.discard(step_name)
            return True
        return False

    def contains(self, step_name: str) -> bool:
        """Check if a step is in this group."""
        return step_name in self._step_names

    @property
    def step_names(self) -> Set[str]:
        return set(self._step_names)

    def __len__(self) -> int:
        return len(self._step_names)

    def __repr__(self) -> str:
        return f"StepGroup({self.name!r}, steps={len(self._step_names)})"


class GroupRegistry:
    """Registry for managing step groups."""

    def __init__(self) -> None:
        self._groups: Dict[str, StepGroup] = {}

    def create(self, name: str, description: str = "") -> StepGroup:
        """Create a new group."""
        if name in self._groups:
            raise ValueError(f"Group '{name}' already exists")
        group = StepGroup(name, description)
        self._groups[name] = group
        return group

    def get(self, name: str) -> Optional[StepGroup]:
        """Get a group by name."""
        return self._groups.get(name)

    def delete(self, name: str) -> bool:
        """Delete a group."""
        if name in self._groups:
            del self._groups[name]
            return True
        return False

    def list_groups(self) -> List[StepGroup]:
        """List all groups."""
        return list(self._groups.values())

    def groups_for_step(self, step_name: str) -> List[StepGroup]:
        """Get all groups containing a step."""
        return [g for g in self._groups.values() if g.contains(step_name)]

    def steps_in_groups(self, *group_names: str) -> Set[str]:
        """Get all step names in the given groups (union)."""
        result: Set[str] = set()
        for name in group_names:
            group = self._groups.get(name)
            if group:
                result.update(group.step_names)
        return result

    def __len__(self) -> int:
        return len(self._groups)

    def __contains__(self, name: str) -> bool:
        return name in self._groups
