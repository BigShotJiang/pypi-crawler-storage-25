"""Testing utilities for pipeline validation and assertions."""

from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional, Set

from pipechain.context import Context
from pipechain.pipeline import Pipeline
from pipechain.result import PipelineResult, StepResult, StepStatus
from pipechain.step import Step


class PipelineAssertions:
    """Assertion helpers for testing pipeline behavior."""

    def __init__(self, result: PipelineResult, context: Optional[Context] = None) -> None:
        self.result = result
        self.context = context

    def assert_success(self) -> "PipelineAssertions":
        """Assert the pipeline ran successfully."""
        if not self.result.success:
            failed = [f"{s.step_name}: {s.error}" for s in self.result.failed_steps]
            raise AssertionError(
                f"Pipeline '{self.result.pipeline_name}' failed. "
                f"Failed steps: {failed}"
            )
        return self

    def assert_failed(self) -> "PipelineAssertions":
        """Assert the pipeline failed."""
        if self.result.success:
            raise AssertionError(
                f"Pipeline '{self.result.pipeline_name}' succeeded but was expected to fail"
            )
        return self

    def assert_step_status(self, step_name: str, expected: StepStatus) -> "PipelineAssertions":
        """Assert a specific step has the expected status."""
        sr = self._get_step_result(step_name)
        if sr.status != expected:
            raise AssertionError(
                f"Step '{step_name}' status is {sr.status.value}, expected {expected.value}"
            )
        return self

    def assert_step_output(self, step_name: str, expected: Any) -> "PipelineAssertions":
        """Assert a step produced the expected output."""
        sr = self._get_step_result(step_name)
        if sr.output != expected:
            raise AssertionError(
                f"Step '{step_name}' output is {sr.output!r}, expected {expected!r}"
            )
        return self

    def assert_context_value(self, key: str, expected: Any) -> "PipelineAssertions":
        """Assert a context value matches expected."""
        if self.context is None:
            raise AssertionError("No context provided for assertion")
        actual = self.context.get(key)
        if actual != expected:
            raise AssertionError(
                f"Context key '{key}' is {actual!r}, expected {expected!r}"
            )
        return self

    def assert_context_has(self, *keys: str) -> "PipelineAssertions":
        """Assert context contains all specified keys."""
        if self.context is None:
            raise AssertionError("No context provided for assertion")
        missing = [k for k in keys if not self.context.has(k)]
        if missing:
            raise AssertionError(f"Context missing keys: {missing}")
        return self

    def assert_duration_under(self, max_ms: float) -> "PipelineAssertions":
        """Assert total duration is under a threshold."""
        if self.result.total_duration_ms > max_ms:
            raise AssertionError(
                f"Duration {self.result.total_duration_ms:.1f}ms exceeds {max_ms}ms"
            )
        return self

    def assert_step_count(self, expected: int) -> "PipelineAssertions":
        """Assert the number of step results."""
        actual = len(self.result.step_results)
        if actual != expected:
            raise AssertionError(f"Expected {expected} steps, got {actual}")
        return self

    def assert_no_retries(self) -> "PipelineAssertions":
        """Assert no steps required retries."""
        retried = [s for s in self.result.step_results if s.retries > 0]
        if retried:
            names = [s.step_name for s in retried]
            raise AssertionError(f"Steps required retries: {names}")
        return self

    def assert_steps_ran(self, *step_names: str) -> "PipelineAssertions":
        """Assert specific steps ran (not skipped)."""
        ran = {s.step_name for s in self.result.step_results
               if s.status not in (StepStatus.SKIPPED,)}
        missing = set(step_names) - ran
        if missing:
            raise AssertionError(f"Steps did not run: {missing}")
        return self

    def assert_steps_skipped(self, *step_names: str) -> "PipelineAssertions":
        """Assert specific steps were skipped."""
        skipped = {s.step_name for s in self.result.step_results
                   if s.status == StepStatus.SKIPPED}
        not_skipped = set(step_names) - skipped
        if not_skipped:
            raise AssertionError(f"Steps were not skipped: {not_skipped}")
        return self

    def _get_step_result(self, step_name: str) -> StepResult:
        """Get a step result by name."""
        for sr in self.result.step_results:
            if sr.step_name == step_name:
                return sr
        raise AssertionError(f"Step '{step_name}' not found in results")


def run_and_assert(pipeline: Pipeline, **kwargs: Any) -> PipelineAssertions:
    """Run a pipeline and return assertion helpers."""
    context = kwargs.pop("context", Context())
    result = pipeline.run(context=context, **kwargs)
    return PipelineAssertions(result, context)


class MockStep(Step):
    """A step that records its calls for testing."""

    def __init__(self, name: str, return_value: Any = None, **kwargs: Any) -> None:
        self.call_count = 0
        self.call_args: List[Context] = []
        self._return_value = return_value

        def mock_fn(ctx: Context) -> Any:
            self.call_count += 1
            self.call_args.append(ctx)
            return self._return_value

        super().__init__(name=name, fn=mock_fn, **kwargs)

    @property
    def called(self) -> bool:
        return self.call_count > 0

    def assert_called(self) -> None:
        if not self.called:
            raise AssertionError(f"MockStep '{self.name}' was not called")

    def assert_not_called(self) -> None:
        if self.called:
            raise AssertionError(
                f"MockStep '{self.name}' was called {self.call_count} times"
            )

    def assert_called_times(self, n: int) -> None:
        if self.call_count != n:
            raise AssertionError(
                f"MockStep '{self.name}' called {self.call_count} times, expected {n}"
            )
