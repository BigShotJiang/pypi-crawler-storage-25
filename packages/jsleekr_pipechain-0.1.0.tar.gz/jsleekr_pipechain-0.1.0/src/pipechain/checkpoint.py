"""Checkpoint support for resumable pipeline execution."""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

from pipechain.result import StepStatus


class Checkpoint:
    """Tracks pipeline execution state for resume capability.

    Saves which steps have completed so a failed pipeline can be
    resumed from the point of failure.
    """

    def __init__(self, checkpoint_dir: str = ".pipechain_checkpoints") -> None:
        self._dir = Path(checkpoint_dir)
        self._dir.mkdir(parents=True, exist_ok=True)
        self._completed: Set[str] = set()
        self._failed: Set[str] = set()
        self._pipeline_name: Optional[str] = None
        self._run_id: Optional[str] = None
        self._metadata: Dict[str, Any] = {}

    def start_run(self, pipeline_name: str, run_id: Optional[str] = None) -> str:
        """Start tracking a new run."""
        self._pipeline_name = pipeline_name
        self._run_id = run_id or f"{pipeline_name}_{int(time.time())}"
        self._completed.clear()
        self._failed.clear()
        self._metadata = {
            "pipeline_name": pipeline_name,
            "run_id": self._run_id,
            "started_at": time.time(),
        }
        self._save()
        return self._run_id

    def mark_completed(self, step_name: str) -> None:
        """Mark a step as completed."""
        self._completed.add(step_name)
        self._failed.discard(step_name)
        self._save()

    def mark_failed(self, step_name: str) -> None:
        """Mark a step as failed."""
        self._failed.add(step_name)
        self._save()

    def is_completed(self, step_name: str) -> bool:
        """Check if a step was already completed."""
        return step_name in self._completed

    def is_failed(self, step_name: str) -> bool:
        """Check if a step previously failed."""
        return step_name in self._failed

    @property
    def completed_steps(self) -> Set[str]:
        return set(self._completed)

    @property
    def failed_steps(self) -> Set[str]:
        return set(self._failed)

    def _checkpoint_path(self) -> Path:
        """Get the path for the current checkpoint file."""
        return self._dir / f"{self._run_id}.json"

    def _save(self) -> None:
        """Save checkpoint state to disk."""
        if self._run_id is None:
            return
        data = {
            **self._metadata,
            "completed": sorted(self._completed),
            "failed": sorted(self._failed),
            "updated_at": time.time(),
        }
        self._checkpoint_path().write_text(json.dumps(data, indent=2))

    def load(self, run_id: str) -> bool:
        """Load a previous checkpoint. Returns True if found."""
        path = self._dir / f"{run_id}.json"
        if not path.exists():
            return False
        data = json.loads(path.read_text())
        self._pipeline_name = data.get("pipeline_name")
        self._run_id = run_id
        self._completed = set(data.get("completed", []))
        self._failed = set(data.get("failed", []))
        self._metadata = data
        return True

    def list_checkpoints(self) -> List[Dict[str, Any]]:
        """List all available checkpoints."""
        checkpoints = []
        for path in sorted(self._dir.glob("*.json")):
            try:
                data = json.loads(path.read_text())
                checkpoints.append({
                    "run_id": path.stem,
                    "pipeline_name": data.get("pipeline_name"),
                    "completed": len(data.get("completed", [])),
                    "failed": len(data.get("failed", [])),
                    "started_at": data.get("started_at"),
                })
            except (json.JSONDecodeError, KeyError):
                continue
        return checkpoints

    def delete(self, run_id: str) -> bool:
        """Delete a checkpoint."""
        path = self._dir / f"{run_id}.json"
        if path.exists():
            path.unlink()
            return True
        return False

    def clear(self) -> int:
        """Clear all checkpoints. Returns count deleted."""
        count = 0
        for path in self._dir.glob("*.json"):
            path.unlink()
            count += 1
        return count

    @property
    def run_id(self) -> Optional[str]:
        return self._run_id
