from __future__ import annotations

import json
from pathlib import Path

from unclog.scan.project import resolve_project_paths, scan_project


def test_scan_project_for_missing_path_returns_non_existing_scope(tmp_path: Path) -> None:
    ghost = tmp_path / "ghost"
    scope = scan_project(ghost)
    assert scope.exists is False
    assert scope.claude_md_text == ""
    assert scope.claude_local_md_text == ""
    assert scope.has_claudeignore is False
    assert scope.name == "ghost"


def test_scan_project_reads_claude_md_and_claudeignore(tmp_path: Path) -> None:
    project = tmp_path / "draper"
    project.mkdir()
    (project / "CLAUDE.md").write_text("# Draper\nuse yarn\n", encoding="utf-8")
    (project / ".claudeignore").write_text("node_modules/\n", encoding="utf-8")
    scope = scan_project(project)
    assert scope.exists is True
    assert scope.name == "draper"
    assert "Draper" in scope.claude_md_text
    assert scope.claude_md_bytes > 0
    assert scope.has_claudeignore is True


def test_scan_project_local_claude_md_read_separately(tmp_path: Path) -> None:
    project = tmp_path / "p"
    project.mkdir()
    (project / "CLAUDE.local.md").write_text("local only\n", encoding="utf-8")
    scope = scan_project(project)
    assert scope.claude_md_text == ""
    assert scope.claude_local_md_text == "local only\n"


def test_resolve_paths_explicit_project_wins(tmp_path: Path) -> None:
    out = resolve_project_paths(
        explicit_project=tmp_path / "x",
        cwd=tmp_path / "cwd",
        known_projects=(tmp_path / "other",),
    )
    assert out == ((tmp_path / "x").resolve(),)


def test_resolve_paths_returns_all_known_by_default(tmp_path: Path) -> None:
    a = tmp_path / "a"
    b = tmp_path / "b"
    out = resolve_project_paths(
        explicit_project=None,
        cwd=tmp_path,
        known_projects=(a, b, a),  # duplicate should collapse
    )
    assert out == (a.resolve(), b.resolve())


def test_resolve_paths_cwd_known_project(tmp_path: Path) -> None:
    project = tmp_path / "proj"
    project.mkdir()
    out = resolve_project_paths(
        explicit_project=None,
        cwd=project,
        known_projects=(project,),
    )
    assert out == (project.resolve(),)


def test_resolve_paths_cwd_has_claude_md_gets_appended(tmp_path: Path) -> None:
    project = tmp_path / "proj"
    project.mkdir()
    (project / "CLAUDE.md").write_text("hi\n", encoding="utf-8")
    out = resolve_project_paths(
        explicit_project=None,
        cwd=project,
        known_projects=(),
    )
    assert out == (project.resolve(),)


def test_resolve_paths_known_projects_plus_unregistered_cwd(tmp_path: Path) -> None:
    known_a = tmp_path / "known"
    cwd_project = tmp_path / "new"
    cwd_project.mkdir()
    (cwd_project / "CLAUDE.md").write_text("hi\n", encoding="utf-8")
    out = resolve_project_paths(
        explicit_project=None,
        cwd=cwd_project,
        known_projects=(known_a,),
    )
    assert out == (known_a.resolve(), cwd_project.resolve())


def test_resolve_paths_empty_when_no_known_and_cwd_not_project(tmp_path: Path) -> None:
    out = resolve_project_paths(
        explicit_project=None,
        cwd=tmp_path,
        known_projects=(),
    )
    assert out == ()


def test_scan_project_loads_hooks_from_both_settings_files(tmp_path: Path) -> None:
    project = tmp_path / "app"
    (project / ".claude").mkdir(parents=True)
    (project / ".claude" / "settings.json").write_text(
        json.dumps(
            {
                "hooks": {
                    "SessionStart": [
                        {"hooks": [{"type": "command", "command": "seed-context"}]}
                    ]
                }
            }
        ),
        encoding="utf-8",
    )
    (project / ".claude" / "settings.local.json").write_text(
        json.dumps(
            {
                "hooks": {
                    "UserPromptSubmit": [
                        {"hooks": [{"type": "command", "command": "local-notes"}]}
                    ]
                }
            }
        ),
        encoding="utf-8",
    )
    scope = scan_project(project)
    events = sorted(h.event for h in scope.hooks)
    commands = sorted(h.command for h in scope.hooks)
    assert events == ["SessionStart", "UserPromptSubmit"]
    assert commands == ["local-notes", "seed-context"]
    assert all(h.source_scope == "project" for h in scope.hooks)


def test_scan_project_returns_empty_hooks_when_absent(tmp_path: Path) -> None:
    project = tmp_path / "quiet"
    project.mkdir()
    scope = scan_project(project)
    assert scope.hooks == ()


def test_scan_project_skips_hooks_when_project_claude_is_the_global_home(
    tmp_path: Path,
) -> None:
    """``$HOME`` as a project must not re-read global settings as project hooks.

    Claude Code records every directory you've ever opened under
    ``~/.claude.json``'s ``projects{}`` map, including ``$HOME``. If the
    project scanner reads ``$HOME/.claude/settings.json``, it double-
    counts the global settings file — once globally, once as "project."
    """
    claude_home = tmp_path / ".claude"
    claude_home.mkdir()
    (claude_home / "settings.json").write_text(
        json.dumps(
            {
                "hooks": {
                    "SessionStart": [
                        {"hooks": [{"type": "command", "command": "global-cmd"}]}
                    ]
                }
            }
        ),
        encoding="utf-8",
    )
    scope = scan_project(tmp_path, claude_home=claude_home)
    assert scope.hooks == ()


def test_scan_project_skips_malformed_settings_without_crashing(tmp_path: Path) -> None:
    project = tmp_path / "broken"
    (project / ".claude").mkdir(parents=True)
    (project / ".claude" / "settings.json").write_text("{{not json", encoding="utf-8")
    (project / ".claude" / "settings.local.json").write_text(
        json.dumps(
            {"hooks": {"SessionStart": [{"hooks": [{"type": "command", "command": "ok"}]}]}}
        ),
        encoding="utf-8",
    )
    scope = scan_project(project)
    assert [h.command for h in scope.hooks] == ["ok"]
