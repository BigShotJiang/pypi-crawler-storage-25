from __future__ import annotations

import os
import time
from datetime import UTC, datetime, timedelta
from pathlib import Path
from types import MappingProxyType

from unclog.findings import detect
from unclog.findings.thresholds import Thresholds
from unclog.scan.config import ClaudeConfig, McpServer, Settings
from unclog.scan.filesystem import Agent, Command, InstalledPlugin, Skill
from unclog.scan.session import SessionSystemBlock
from unclog.scan.stats import ActivityIndex
from unclog.state import GlobalScope, InstallationState

NOW = datetime(2026, 4, 17, tzinfo=UTC)


def _state(
    *,
    claude_home: Path = Path("/fake/.claude"),
    skills: tuple[Skill, ...] = (),
    agents: tuple[Agent, ...] = (),
    commands: tuple[Command, ...] = (),
    plugins: tuple[InstalledPlugin, ...] = (),
    config: ClaudeConfig | None = None,
    settings: Settings | None = None,
    latest_session: SessionSystemBlock | None = None,
    activity: ActivityIndex | None = None,
    mcp_invocations: dict[str, int] | None = None,
    mcp_probes: dict | None = None,  # type: ignore[type-arg]
    project_scopes: tuple = (),
) -> InstallationState:
    return InstallationState(
        generated_at=NOW,
        claude_home=claude_home,
        global_scope=GlobalScope(
            claude_home=claude_home,
            config=config,
            settings=settings if settings is not None else Settings(),
            claude_md_bytes=0,
            claude_md_text="",
            claude_local_md_bytes=0,
            claude_local_md_text="",
            skills=skills,
            agents=agents,
            commands=commands,
            installed_plugins=plugins,
            latest_session=latest_session,
            activity=activity if activity is not None else ActivityIndex(),
            mcp_invocations=MappingProxyType(mcp_invocations or {}),
            mcp_probes=MappingProxyType(mcp_probes or {}),
        ),
        project_scopes=project_scopes,
    )


def _make_command(tmp_path: Path, slug: str) -> Command:
    path = tmp_path / f"{slug}.md"
    path.write_text(f"{slug}!", encoding="utf-8")
    return Command(name=slug, slug=slug, path=path, total_bytes=path.stat().st_size)


def _age_file(path: Path, *, days: int) -> None:
    ts = time.time() - days * 86400
    os.utime(path, (ts, ts))


def _active_index(days_ago: int = 1) -> ActivityIndex:
    last = NOW - timedelta(days=days_ago)
    return ActivityIndex(last_active_overall=last)


# --- dead_mcp / unused_mcp -----------------------------------------------


def _session_with_tools(*tool_names: str) -> SessionSystemBlock:
    tools = tuple({"name": name, "description": "...", "input_schema": {}} for name in tool_names)
    return SessionSystemBlock(
        session_path=Path("/fake/.claude/projects/x/a.jsonl"),
        system_text="sys",
        tools_json="[...]",
        tools=tools,
        system_tokens=5,
        tools_tokens=5,
    )


def test_dead_mcp_flags_configured_but_absent_from_session() -> None:
    config = ClaudeConfig(
        mcp_servers=MappingProxyType(
            {
                "github": McpServer(name="github"),
                "notion": McpServer(name="notion"),
            }
        )
    )
    session = _session_with_tools("mcp__github__list_repos", "Read")
    state = _state(config=config, latest_session=session, activity=_active_index())
    findings = detect(state, state.global_scope.activity, Thresholds(), now=NOW)
    dead = [f for f in findings if f.type == "dead_mcp"]
    assert [f.id for f in dead] == ["dead_mcp:notion"]
    assert dead[0].auto_checked is False
    assert dead[0].action.primitive == "comment_out_mcp"
    assert dead[0].action.server_name == "notion"


def test_dead_mcp_skipped_when_no_session() -> None:
    config = ClaudeConfig(mcp_servers=MappingProxyType({"github": McpServer(name="github")}))
    state = _state(config=config, latest_session=None, activity=_active_index())
    findings = detect(state, state.global_scope.activity, Thresholds(), now=NOW)
    assert [f for f in findings if f.type == "dead_mcp"] == []


def test_dead_mcp_uses_probe_results_when_present() -> None:
    """When --probe-mcps ran, failed probes become dead_mcp regardless of session."""
    from unclog.scan.mcp_probe import ProbeResult

    config = ClaudeConfig(
        mcp_servers=MappingProxyType(
            {
                "healthy": McpServer(name="healthy"),
                "broken": McpServer(name="broken"),
            }
        )
    )
    probes = {
        "healthy": ProbeResult(name="healthy", ok=True, tool_count=3, tools_tokens=900),
        "broken": ProbeResult(
            name="broken",
            ok=False,
            error="command not found: broken-server",
            stderr_tail="sh: broken-server: command not found",
        ),
    }
    # No session: would yield nothing via fallback, but probe path kicks in.
    state = _state(
        config=config,
        latest_session=None,
        activity=_active_index(),
        mcp_probes=probes,
    )
    findings = detect(state, state.global_scope.activity, Thresholds(), now=NOW)
    dead = [f for f in findings if f.type == "dead_mcp"]
    assert [f.id for f in dead] == ["dead_mcp:broken"]
    assert dead[0].evidence["source"] == "probe"
    assert "command not found" in dead[0].reason
    assert "broken-server" in dead[0].evidence["stderr_tail"]


def test_dead_mcp_probe_success_suppresses_session_fallback() -> None:
    """Probe-ok servers must NOT be flagged dead even if the last session didn't use them."""
    from unclog.scan.mcp_probe import ProbeResult

    config = ClaudeConfig(
        mcp_servers=MappingProxyType({"github": McpServer(name="github")})
    )
    # Session shows only Read, not github — session-only path would flag it.
    session = _session_with_tools("Read")
    probes = {
        "github": ProbeResult(name="github", ok=True, tool_count=2, tools_tokens=500),
    }
    state = _state(
        config=config,
        latest_session=session,
        activity=_active_index(),
        mcp_probes=probes,
    )
    findings = detect(state, state.global_scope.activity, Thresholds(), now=NOW)
    assert [f for f in findings if f.type == "dead_mcp"] == []


def test_unused_mcp_flags_loaded_but_zero_invocations() -> None:
    config = ClaudeConfig(mcp_servers=MappingProxyType({"github": McpServer(name="github")}))
    session = _session_with_tools("mcp__github__list_repos")
    # Default mcp_invocations is empty — "github" is loaded, never called.
    state = _state(config=config, latest_session=session, activity=_active_index())
    findings = detect(state, state.global_scope.activity, Thresholds(), now=NOW)
    unused = [f for f in findings if f.type == "unused_mcp"]
    assert [f.id for f in unused] == ["unused_mcp:github"]
    assert unused[0].auto_checked is False
    assert unused[0].action.primitive == "comment_out_mcp"
    assert unused[0].action.server_name == "github"


def test_unused_mcp_respects_invocation_count() -> None:
    config = ClaudeConfig(mcp_servers=MappingProxyType({"github": McpServer(name="github")}))
    session = _session_with_tools("mcp__github__list_repos")
    state = _state(
        config=config,
        latest_session=session,
        activity=_active_index(),
        mcp_invocations={"github": 3},
    )
    findings = detect(state, state.global_scope.activity, Thresholds(), now=NOW)
    assert [f for f in findings if f.type == "unused_mcp"] == []


# --- stale_plugin / disabled_plugin_residue ------------------------------


def _plugin(name: str, marketplace: str | None, installed_at_iso: str) -> InstalledPlugin:
    return InstalledPlugin(
        name=name,
        marketplace=marketplace,
        version="1.0.0",
        install_path=None,
        installed_at=installed_at_iso,
        git_commit_sha=None,
    )


def test_stale_plugin_flags_old_enabled_plugin() -> None:
    plugin = _plugin("superpower", "antonin", "2025-10-01T00:00:00Z")
    settings = Settings(
        enabled_plugins=MappingProxyType({"superpower@antonin": True}),
    )
    state = _state(plugins=(plugin,), settings=settings, activity=_active_index())
    findings = detect(state, state.global_scope.activity, Thresholds(stale_plugin_days=90), now=NOW)
    stale = [f for f in findings if f.type == "stale_plugin"]
    assert len(stale) == 1
    assert stale[0].id == "stale_plugin:superpower@antonin"
    assert stale[0].action.primitive == "disable_plugin"
    assert stale[0].auto_checked is False


def test_stale_plugin_emits_even_for_recent_plugin() -> None:
    # v0.1: age gate dropped. Every enabled plugin is a candidate so the
    # user sees its token cost and can choose to disable.
    plugin = _plugin("fresh", None, (NOW - timedelta(days=10)).isoformat().replace("+00:00", "Z"))
    settings = Settings(enabled_plugins=MappingProxyType({"fresh": True}))
    state = _state(plugins=(plugin,), settings=settings, activity=_active_index())
    findings = detect(state, state.global_scope.activity, Thresholds(stale_plugin_days=90), now=NOW)
    stale = [f for f in findings if f.type == "stale_plugin"]
    assert len(stale) == 1
    assert stale[0].auto_checked is False


def test_stale_plugin_skips_disabled_plugins() -> None:
    plugin = _plugin("off", None, "2025-01-01T00:00:00Z")
    settings = Settings(enabled_plugins=MappingProxyType({"off": False}))
    state = _state(plugins=(plugin,), settings=settings, activity=_active_index())
    findings = detect(state, state.global_scope.activity, Thresholds(), now=NOW)
    assert [f for f in findings if f.type == "stale_plugin"] == []


def test_disabled_plugin_residue_flag_only_when_recent() -> None:
    plugin = _plugin(
        "superpower", "antonin", (NOW - timedelta(days=30)).isoformat().replace("+00:00", "Z")
    )
    settings = Settings(enabled_plugins=MappingProxyType({"superpower@antonin": False}))
    state = _state(plugins=(plugin,), settings=settings, activity=_active_index())
    findings = detect(state, state.global_scope.activity, Thresholds(stale_plugin_days=90), now=NOW)
    residue = [f for f in findings if f.type == "disabled_plugin_residue"]
    assert len(residue) == 1
    assert residue[0].action.primitive == "flag_only"


def test_disabled_plugin_residue_offers_uninstall_once_aged() -> None:
    plugin = _plugin("old-plug", None, "2024-01-01T00:00:00Z")
    settings = Settings(enabled_plugins=MappingProxyType({"old-plug": False}))
    state = _state(plugins=(plugin,), settings=settings, activity=_active_index())
    findings = detect(state, state.global_scope.activity, Thresholds(stale_plugin_days=90), now=NOW)
    residue = [f for f in findings if f.type == "disabled_plugin_residue"]
    assert len(residue) == 1
    assert residue[0].action.primitive == "uninstall_plugin"


# --- missing_claudeignore ------------------------------------------------


def test_missing_claudeignore_flags_project_with_node_modules(tmp_path: Path) -> None:
    project_dir = tmp_path / "draper"
    project_dir.mkdir()
    (project_dir / "node_modules").mkdir()
    resolved = project_dir.resolve()
    state = _state(
        activity=_active_index(),
        project_scopes=(_project_scope(resolved),),
    )
    findings = detect(state, state.global_scope.activity, Thresholds(), now=NOW)
    miss = [f for f in findings if f.type == "missing_claudeignore"]
    assert len(miss) == 1
    assert miss[0].scope.project_path == resolved
    assert miss[0].action.primitive == "flag_only"


def test_missing_claudeignore_skipped_when_ignore_present(tmp_path: Path) -> None:
    project_dir = tmp_path / "draper"
    project_dir.mkdir()
    (project_dir / "node_modules").mkdir()
    (project_dir / ".claudeignore").write_text("node_modules\n", encoding="utf-8")
    resolved = project_dir.resolve()
    state = _state(
        activity=_active_index(),
        project_scopes=(_project_scope(resolved, has_claudeignore=True),),
    )
    findings = detect(state, state.global_scope.activity, Thresholds(), now=NOW)
    assert [f for f in findings if f.type == "missing_claudeignore"] == []


def test_missing_claudeignore_ignores_stale_project_paths(tmp_path: Path) -> None:
    nowhere = tmp_path / "gone"  # directory does not exist
    state = _state(
        activity=_active_index(),
        project_scopes=(_project_scope(nowhere, exists=False),),
    )
    findings = detect(state, state.global_scope.activity, Thresholds(), now=NOW)
    assert [f for f in findings if f.type == "missing_claudeignore"] == []


def test_missing_claudeignore_respects_project_narrowing(tmp_path: Path) -> None:
    """`--project PATH` narrows state.project_scopes to a single entry; the
    detector must follow that narrowing rather than re-expand via
    ~/.claude.json. Regression: B1 in the pre-ship audit."""
    narrowed = tmp_path / "narrowed"
    narrowed.mkdir()
    (narrowed / "node_modules").mkdir()
    other = tmp_path / "other"
    other.mkdir()
    (other / "node_modules").mkdir()
    # config.projects has BOTH, but project_scopes only has the narrowed one.
    config = ClaudeConfig(
        projects=MappingProxyType(
            {
                narrowed.resolve(): _project_record(narrowed.resolve()),
                other.resolve(): _project_record(other.resolve()),
            }
        )
    )
    state = _state(
        config=config,
        activity=_active_index(),
        project_scopes=(_project_scope(narrowed.resolve()),),
    )
    findings = detect(state, state.global_scope.activity, Thresholds(), now=NOW)
    miss = [f for f in findings if f.type == "missing_claudeignore"]
    assert len(miss) == 1
    assert miss[0].scope.project_path == narrowed.resolve()


def _project_record(path: Path):  # type: ignore[no-untyped-def]
    from unclog.scan.config import ProjectRecord

    return ProjectRecord(path=path)


# --- heavy_hook ---------------------------------------------------------


def _hook(event: str, command: str, *, scope: str = "global", matcher: str | None = None):  # type: ignore[no-untyped-def]
    from unclog.scan.config import Hook

    return Hook(
        event=event,
        matcher=matcher,
        command=command,
        source_scope=scope,
        source_path=Path(f"/fake/{scope}/settings.json"),
    )


def _project_scope(  # type: ignore[no-untyped-def]
    path: Path,
    *,
    hooks: tuple = (),
    exists: bool = True,
    has_claudeignore: bool = False,
):
    from unclog.scan.project import ProjectScope

    return ProjectScope(
        path=path,
        name=path.name,
        exists=exists,
        claude_md_path=path / "CLAUDE.md",
        claude_md_text="",
        claude_md_bytes=0,
        claude_local_md_path=path / "CLAUDE.local.md",
        claude_local_md_text="",
        claude_local_md_bytes=0,
        has_claudeignore=has_claudeignore,
        hooks=hooks,
    )


def test_heavy_hook_flags_session_start_and_user_prompt_submit() -> None:
    settings = Settings(
        hooks=(
            _hook("SessionStart", "echo primed"),
            _hook("UserPromptSubmit", "inject-notes.sh"),
            _hook("PreToolUse", "audit-tool"),  # not every-turn; skipped
        )
    )
    state = _state(settings=settings)
    findings = detect(state, state.global_scope.activity, Thresholds(), now=NOW)
    heavy = [f for f in findings if f.type == "heavy_hook"]
    assert len(heavy) == 2
    events = sorted(f.evidence["event"] for f in heavy)
    assert events == ["SessionStart", "UserPromptSubmit"]
    assert all(f.action.primitive == "flag_only" for f in heavy)
    assert all(f.token_savings is None for f in heavy)


def test_heavy_hook_covers_project_scoped_hooks(tmp_path: Path) -> None:
    project = tmp_path / "app"
    scope = _project_scope(
        project, hooks=(_hook("UserPromptSubmit", "ctx.sh", scope="project"),)
    )
    state = _state(project_scopes=(scope,))
    findings = detect(state, state.global_scope.activity, Thresholds(), now=NOW)
    heavy = [f for f in findings if f.type == "heavy_hook"]
    assert len(heavy) == 1
    assert heavy[0].scope.kind == "project"
    assert heavy[0].scope.project_path == project
    assert heavy[0].evidence["source_scope"] == "project"


def test_heavy_hook_emits_nothing_when_only_tool_events_registered() -> None:
    settings = Settings(
        hooks=(
            _hook("PreToolUse", "a"),
            _hook("PostToolUse", "b"),
        )
    )
    state = _state(settings=settings)
    findings = detect(state, state.global_scope.activity, Thresholds(), now=NOW)
    assert [f for f in findings if f.type == "heavy_hook"] == []


# --- detector isolation --------------------------------------------------


def test_detect_isolates_a_single_broken_detector(monkeypatch) -> None:  # type: ignore[no-untyped-def]
    """Regression: one broken detector used to crash the whole audit.

    The user had a detector raise an unexpected exception on real data
    and the entire scan aborted. ``detect()`` now runs each detector in
    its own ``try``/``except`` and threads the failure out via
    ``warnings`` so the user sees a one-line notice instead of a trace.
    """
    from unclog.findings.detectors import dead_mcp, heavy_hook

    def _broken(*args, **kwargs):  # type: ignore[no-untyped-def]
        raise RuntimeError("simulated detector bug")

    monkeypatch.setattr(dead_mcp, "detect", _broken)

    settings = Settings(hooks=(_hook("UserPromptSubmit", "ctx.sh"),))
    state = _state(settings=settings)
    warnings: list[str] = []

    findings = detect(
        state, state.global_scope.activity, Thresholds(), now=NOW, warnings=warnings
    )

    # heavy_hook still produced its finding even though dead_mcp blew up.
    assert [f.type for f in findings if f.type == "heavy_hook"]
    assert any("dead_mcp" in w and "simulated detector bug" in w for w in warnings)
    # Sanity: other detectors weren't swept up by the failure.
    assert len(warnings) == 1

    # Double-check the imported-but-untouched heavy_hook module is the one we used.
    assert hasattr(heavy_hook, "detect")
