from importlib.resources import files
from pathlib import Path
import shutil

def display(n):
    if not isinstance(n, int) or not (1 <= n <= 22):
        raise ValueError("Please choose a number from 1 to 22.")

    filename = f"{n}.py"
    source = files("labdawg").joinpath("templates", filename)
    destination = Path.cwd() / filename

    with source.open("rb") as src, open(destination, "wb") as dst:
        shutil.copyfileobj(src, dst)

    print("1")
