"""
Trainly Python SDK

AI observability and tracing for Python applications with V1 OAuth Authentication.
"""

import warnings as _warnings

from .client import TrainlyClient
from .v1_client import TrainlyV1Client
from .analytics import AnalyticsClient
from .observe import ObserveDecorator
from .guards import Guard, GuardResult, GuardFeedback, GuardFailure
from .prompt import Prompt

from .models import (
    # Core models
    QueryResponse,
    ChunkScore,
    Usage,
    UploadResult,
    FileInfo,
    FileListResult,
    FileDeleteResult,
    BulkUploadResult,
    BulkUploadFileResult,
    TrainlyError,
    StreamChunk,
    # Analytics models
    QueryTrace,
    QueryTraceDetails,
    TokenUsage,
    TimingBreakdown,
    ChunkInfo,
    MetricsSummary,
    CostBreakdown,
    PerformanceStats,
    # General-purpose invoke & agent models
    ToolDefinition,
    ToolCall,
    InvokeResult,
    InvokeValidation,
    ValidationOutcome,
)

__version__ = "0.6.0"

# Deprecated sub-clients and models that are lazy-loaded with warnings
_DEPRECATED_CLIENTS = {
    "TestingClient": ".testing",
    "FineTuningClient": ".fine_tuning",
    "ConfigClient": ".config",
    "VersionsClient": ".versions",
}

_DEPRECATED_MODELS = {
    "TestSuite": ".models",
    "TestCase": ".models",
    "TestRun": ".models",
    "TestRunResults": ".models",
    "TestAnalytics": ".models",
    "TestAssertion": ".models",
    "TestResult": ".models",
    "PaginatedSuites": ".models",
    "PreferencePair": ".models",
    "TrainingJob": ".models",
    "PaginatedPairs": ".models",
    "BatchResult": ".models",
    "ValidationResults": ".models",
    "ChatSettings": ".models",
    "RagConfig": ".models",
    "ChunkingConfig": ".models",
    "RetrievalConfig": ".models",
    "RerankingConfig": ".models",
    "ValidationPolicy": ".models",
    "RepairLoopConfig": ".models",
    "PublishedVersion": ".models",
    "VersionDiff": ".models",
    "FileSnapshot": ".models",
}


def __getattr__(name):
    if name in _DEPRECATED_CLIENTS:
        _warnings.warn(
            f"{name} is deprecated and will be removed in a future version. "
            f"Use TrainlyClient or ObserveDecorator for observability workflows.",
            DeprecationWarning,
            stacklevel=2,
        )
        import importlib
        module = importlib.import_module(_DEPRECATED_CLIENTS[name], __name__)
        return getattr(module, name)

    if name in _DEPRECATED_MODELS:
        _warnings.warn(
            f"{name} is deprecated and will be removed in a future version. "
            f"Use the observability API (ObserveDecorator) instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        import importlib
        module = importlib.import_module(_DEPRECATED_MODELS[name], __name__)
        return getattr(module, name)

    raise AttributeError(f"module 'trainly' has no attribute {name!r}")


__all__ = [
    # Primary exports — Observability
    "TrainlyClient",
    "TrainlyV1Client",
    "AnalyticsClient",
    "ObserveDecorator",
    "Guard",
    "GuardResult",
    "GuardFeedback",
    "GuardFailure",
    "Prompt",
    # Core models
    "QueryResponse",
    "ChunkScore",
    "Usage",
    "UploadResult",
    "FileInfo",
    "FileListResult",
    "FileDeleteResult",
    "BulkUploadResult",
    "BulkUploadFileResult",
    "TrainlyError",
    "StreamChunk",
    # Analytics models
    "QueryTrace",
    "QueryTraceDetails",
    "TokenUsage",
    "TimingBreakdown",
    "ChunkInfo",
    "MetricsSummary",
    "CostBreakdown",
    "PerformanceStats",
    # General-purpose invoke & agent models
    "ToolDefinition",
    "ToolCall",
    "InvokeResult",
    "InvokeValidation",
    "ValidationOutcome",
    # Deprecated — sub-clients (lazy-loaded with warnings)
    "TestingClient",
    "FineTuningClient",
    "ConfigClient",
    "VersionsClient",
    # Deprecated — testing models (lazy-loaded with warnings)
    "TestSuite",
    "TestCase",
    "TestRun",
    "TestRunResults",
    "TestAnalytics",
    "TestAssertion",
    "TestResult",
    "PaginatedSuites",
    # Deprecated — fine-tuning models (lazy-loaded with warnings)
    "PreferencePair",
    "TrainingJob",
    "PaginatedPairs",
    "BatchResult",
    "ValidationResults",
    # Deprecated — config models (lazy-loaded with warnings)
    "ChatSettings",
    "RagConfig",
    "ChunkingConfig",
    "RetrievalConfig",
    "RerankingConfig",
    "ValidationPolicy",
    "RepairLoopConfig",
    # Deprecated — version models (lazy-loaded with warnings)
    "PublishedVersion",
    "VersionDiff",
    "FileSnapshot",
]
