"""LangChain adapter — wrap-around middleware for tool call governance."""

from __future__ import annotations

import asyncio
import logging
import uuid
from collections.abc import Callable
from dataclasses import asdict, replace
from typing import TYPE_CHECKING, Any

from edictum.approval import ApprovalStatus
from edictum.audit import AuditAction, AuditEvent
from edictum.envelope import Principal, create_envelope
from edictum.findings import Finding, PostCallResult, build_findings
from edictum.pipeline import CheckPipeline
from edictum.session import Session, validate_session_id
from edictum.workflow.state import build_workflow_snapshot

logger = logging.getLogger(__name__)
_MAX_WORKFLOW_APPROVAL_ROUNDS = 32

if TYPE_CHECKING:
    from edictum import Edictum


class LangChainAdapter:
    """Translate Edictum pipeline decisions into LangChain middleware format.

    The adapter does NOT contain governance logic -- that lives in
    CheckPipeline. The adapter only:
    1. Creates envelopes from LangChain ToolCallRequest
    2. Manages pending state (envelope + span) between pre/post
    3. Translates PreDecision/PostDecision into LangChain output format
    4. Handles observe mode (block -> allow conversion)
    """

    def __init__(
        self,
        guard: Edictum,
        session_id: str | None = None,
        principal: Principal | None = None,
        principal_resolver: Callable[[str, dict[str, Any]], Principal] | None = None,
    ):
        self._guard = guard
        self._pipeline = CheckPipeline(guard)
        self._session_id = session_id or str(uuid.uuid4())
        self._session = Session(self._session_id, guard.backend)
        self._call_index = 0
        self._pending: dict[str, tuple[Any, Any]] = {}
        self._pending_decisions: dict[str, Any] = {}
        self._principal = principal
        self._principal_resolver = principal_resolver
        self._parent_session_id: str | None = None

    @property
    def session_id(self) -> str:
        return self._session_id

    def set_principal(self, principal: Principal) -> None:
        """Update the principal for subsequent tool calls."""
        self._principal = principal

    def _resolve_principal(self, tool_name: str, tool_input: dict[str, Any]) -> Principal | None:
        """Resolve principal: resolver overrides static."""
        if self._principal_resolver is not None:
            return self._principal_resolver(tool_name, tool_input)
        return self._principal

    def _audit_parent_session_id(self) -> str | None:
        value = self._parent_session_id
        if not isinstance(value, str) or not value:
            return None
        try:
            validate_session_id(value)
        except ValueError:
            return None
        return value

    def as_middleware(
        self,
        on_postcondition_warn: Callable[[Any, list[Finding]], Any] | None = None,
    ) -> Any:
        """Return a @wrap_tool_call decorated function for LangChain.

        Args:
            on_postcondition_warn: Optional callback invoked when postconditions
                detect issues. Receives (original_result, violations) and returns
                the (possibly transformed) result.

        Usage::

            from langchain.agents.middleware import wrap_tool_call

            guard = Edictum(...)
            adapter = LangChainAdapter(guard)
            middleware = adapter.as_middleware()
            # Pass to agent as tool_call_middleware=[middleware]
        """
        from langchain.agents.middleware import wrap_tool_call

        adapter = self

        @wrap_tool_call
        def edictum_middleware(request, handler):
            loop = asyncio.get_event_loop()
            pre_result = loop.run_until_complete(adapter._pre_tool_call(request))
            if pre_result is not None:
                return pre_result

            result = handler(request)

            post_result = loop.run_until_complete(adapter._post_tool_call(request, result))
            if not post_result.postconditions_passed and on_postcondition_warn:
                try:
                    return on_postcondition_warn(post_result.result, post_result.violations)
                except Exception:
                    logger.exception("on_postcondition_warn callback raised")
            return post_result.result

        return edictum_middleware

    def as_tool_wrapper(
        self,
        on_postcondition_warn: Callable[[Any, list[Finding]], Any] | None = None,
    ) -> Callable:
        """Return a plain ToolCallWrapper for ToolNode(wrap_tool_call=...).

        Args:
            on_postcondition_warn: Optional callback invoked when postconditions
                detect issues. Receives (original_result, violations) and returns
                the (possibly transformed) result. If None, postcondition
                warnings are logged but the original result is returned unchanged.

        Usage::

            adapter = LangChainAdapter(guard)
            tool_node = ToolNode(tools=tools, wrap_tool_call=adapter.as_tool_wrapper())
            agent = create_react_agent(model, tools=tool_node)

            # With remediation:
            tool_node = ToolNode(
                tools=tools,
                wrap_tool_call=adapter.as_tool_wrapper(
                    on_postcondition_warn=lambda result, violations: redact_pii(result, violations)
                ),
            )
        """
        adapter = self

        def _run_async(coro):
            """Run coroutine from sync context, handling nested event loops."""
            try:
                loop = asyncio.get_running_loop()
            except RuntimeError:
                loop = None

            if loop is not None and loop.is_running():
                import concurrent.futures

                with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                    return pool.submit(asyncio.run, coro).result()
            else:
                return asyncio.run(coro)

        def wrapper(request, handler):
            pre_result = _run_async(adapter._pre_tool_call(request))
            if pre_result is not None:
                return pre_result
            result = handler(request)
            post_result = _run_async(adapter._post_tool_call(request, result))
            if not post_result.postconditions_passed and on_postcondition_warn:
                try:
                    return on_postcondition_warn(post_result.result, post_result.violations)
                except Exception:
                    logger.exception("on_postcondition_warn callback raised")
            return post_result.result

        return wrapper

    def as_async_tool_wrapper(
        self,
        on_postcondition_warn: Callable[[Any, list[Finding]], Any] | None = None,
    ) -> Callable:
        """Return an async ToolCallWrapper for ToolNode(wrap_tool_call=...).

        Args:
            on_postcondition_warn: Optional callback invoked when postconditions
                detect issues. Receives (original_result, violations) and returns
                the (possibly transformed) result.

        Usage::

            adapter = LangChainAdapter(guard)
            tool_node = ToolNode(tools=tools, wrap_tool_call=adapter.as_async_tool_wrapper())
            agent = create_react_agent(model, tools=tool_node)
        """
        adapter = self

        async def wrapper(request, handler):
            pre_result = await adapter._pre_tool_call(request)
            if pre_result is not None:
                return pre_result
            result = await handler(request)
            post_result = await adapter._post_tool_call(request, result)
            if not post_result.postconditions_passed and on_postcondition_warn:
                try:
                    return on_postcondition_warn(post_result.result, post_result.violations)
                except Exception:
                    logger.exception("on_postcondition_warn callback raised")
            return post_result.result

        return wrapper

    async def _pre_tool_call(self, request: Any) -> Any | None:
        """Run pre-execution governance. Returns denial ToolMessage or None to allow."""
        tool_name = request.tool_call["name"]
        tool_args = request.tool_call["args"]
        tool_call_id = request.tool_call["id"]

        envelope = create_envelope(
            tool_name=tool_name,
            tool_input=tool_args,
            run_id=self._session_id,
            call_index=self._call_index,
            tool_use_id=tool_call_id,
            environment=self._guard.environment,
            registry=self._guard.tool_registry,
            principal=self._resolve_principal(tool_name, tool_args),
        )
        self._call_index += 1

        await self._session.increment_attempts()

        span = self._guard.telemetry.start_tool_span(envelope)

        try:
            decision = await self._pipeline.pre_execute(envelope, self._session)
            await self._emit_workflow_events(envelope, decision.workflow_events)

            # Observe mode: convert block to allow with WOULD_DENY audit
            if self._guard.mode == "observe" and decision.action == "block":
                await self._emit_audit_pre(envelope, decision, audit_action=AuditAction.CALL_WOULD_DENY)
                span.set_attribute("governance.action", "would_deny")
                span.set_attribute("governance.would_deny_reason", decision.reason)
                self._pending[tool_call_id] = (envelope, span)
                self._pending_decisions[tool_call_id] = decision
                return None  # allow through

            # Block
            if decision.action == "block":
                await self._emit_audit_pre(envelope, decision)
                self._guard.telemetry.record_denial(envelope, decision.reason)
                if self._guard._on_deny:
                    try:
                        self._guard._on_deny(envelope, decision.reason or "", decision.decision_name)
                    except Exception:
                        logger.exception("on_deny callback raised")
                span.set_attribute("governance.action", "denied")
                self._guard.telemetry.set_span_error(span, decision.reason or "denied")
                span.end()
                self._pending.pop(tool_call_id, None)
                self._pending_decisions.pop(tool_call_id, None)
                return self._deny(decision.reason or "", tool_call_id)

            if decision.action == "pending_approval":
                blocked_result, decision = await self._resolve_pending_approval(envelope, decision, span, tool_call_id)
                if blocked_result is not None:
                    self._pending.pop(tool_call_id, None)
                    self._pending_decisions.pop(tool_call_id, None)
                    return blocked_result

            # Handle per-rule observed blocks
            if decision.observed:
                for cr in decision.contracts_evaluated:
                    if cr.get("observed") and not cr.get("passed"):
                        await self._guard.audit_sink.emit(
                            AuditEvent(
                                action=AuditAction.CALL_WOULD_DENY,
                                run_id=envelope.run_id,
                                call_id=envelope.call_id,
                                call_index=envelope.call_index,
                                session_id=self._session_id,
                                parent_session_id=self._audit_parent_session_id(),
                                tool_name=envelope.tool_name,
                                tool_args=self._guard.redaction.redact_args(envelope.args),
                                side_effect=envelope.side_effect.value,
                                environment=envelope.environment,
                                principal=asdict(envelope.principal) if envelope.principal else None,
                                decision_source="precondition",
                                decision_name=cr["name"],
                                reason=cr["message"],
                                mode="observe",
                                policy_version=self._guard.policy_version,
                                policy_error=decision.policy_error,
                            )
                        )

            # Allow
            await self._emit_audit_pre(envelope, decision)
            if self._guard._on_allow:
                try:
                    self._guard._on_allow(envelope)
                except Exception:
                    logger.exception("on_allow callback raised")
            span.set_attribute("governance.action", "allowed")
            self._pending[tool_call_id] = (envelope, span)
            self._pending_decisions[tool_call_id] = decision
            return None
        except Exception:
            if tool_call_id not in self._pending:
                span.end()
            raise

    async def _post_tool_call(self, request: Any, result: Any) -> PostCallResult:
        """Run post-execution governance. Returns PostCallResult with violations."""
        tool_call_id = request.tool_call["id"]
        pending = self._pending.pop(tool_call_id, None)
        if not pending:
            return PostCallResult(result=result)

        decision = self._pending_decisions.pop(tool_call_id, None)
        if decision is None:
            _, span = pending
            span.end()
            return PostCallResult(result=result)

        envelope, span = pending

        try:
            tool_success = self._check_tool_success(envelope.tool_name, result)

            post_decision = await self._pipeline.post_execute(envelope, result, tool_success)

            effective_response = (
                post_decision.redacted_response if post_decision.redacted_response is not None else result
            )

            workflow_events: list[dict] = []
            if (
                tool_success
                and decision.workflow_involved
                and decision.workflow_stage_id
                and self._guard._workflow_runtime
            ):
                workflow_events = await self._guard._workflow_runtime.record_result(
                    self._session,
                    decision.workflow_stage_id,
                    envelope,
                )
            workflow = decision.workflow
            if decision.workflow_involved and self._guard._workflow_runtime is not None:
                workflow_state = await self._guard._workflow_runtime.state(self._session)
                workflow = build_workflow_snapshot(self._guard._workflow_runtime.definition, workflow_state)

            await self._session.record_execution(envelope.tool_name, success=tool_success)

            action = AuditAction.CALL_EXECUTED if tool_success else AuditAction.CALL_FAILED
            await self._guard.audit_sink.emit(
                AuditEvent(
                    action=action,
                    run_id=envelope.run_id,
                    call_id=envelope.call_id,
                    call_index=envelope.call_index,
                    session_id=self._session_id,
                    parent_session_id=self._audit_parent_session_id(),
                    tool_name=envelope.tool_name,
                    tool_args=self._guard.redaction.redact_args(envelope.args),
                    side_effect=envelope.side_effect.value,
                    environment=envelope.environment,
                    principal=asdict(envelope.principal) if envelope.principal else None,
                    tool_success=tool_success,
                    postconditions_passed=post_decision.postconditions_passed,
                    contracts_evaluated=post_decision.contracts_evaluated,
                    session_attempt_count=await self._session.attempt_count(),
                    session_execution_count=await self._session.execution_count(),
                    mode=self._guard.mode,
                    policy_version=self._guard.policy_version,
                    policy_error=post_decision.policy_error,
                    workflow=workflow,
                )
            )
            await self._emit_workflow_events(envelope, workflow_events)

            span.set_attribute("governance.tool_success", tool_success)
            span.set_attribute("governance.postconditions_passed", post_decision.postconditions_passed)

            if tool_success:
                self._guard.telemetry.set_span_ok(span)
            else:
                self._guard.telemetry.set_span_error(span, "tool execution failed")
        finally:
            span.end()

        findings = build_findings(post_decision)
        return PostCallResult(
            result=effective_response,
            postconditions_passed=post_decision.postconditions_passed,
            violations=findings,
        )

    async def _emit_audit_pre(self, envelope: Any, decision: Any, audit_action: AuditAction | None = None) -> None:
        if audit_action is None:
            audit_action = AuditAction.CALL_DENIED if decision.action == "block" else AuditAction.CALL_ALLOWED

        await self._guard.audit_sink.emit(
            AuditEvent(
                action=audit_action,
                run_id=envelope.run_id,
                call_id=envelope.call_id,
                call_index=envelope.call_index,
                session_id=self._session_id,
                parent_session_id=self._audit_parent_session_id(),
                tool_name=envelope.tool_name,
                tool_args=self._guard.redaction.redact_args(envelope.args),
                side_effect=envelope.side_effect.value,
                environment=envelope.environment,
                principal=asdict(envelope.principal) if envelope.principal else None,
                decision_source=decision.decision_source,
                decision_name=decision.decision_name,
                reason=decision.reason,
                hooks_evaluated=decision.hooks_evaluated,
                contracts_evaluated=decision.contracts_evaluated,
                session_attempt_count=await self._session.attempt_count(),
                session_execution_count=await self._session.execution_count(),
                mode=self._guard.mode,
                policy_version=self._guard.policy_version,
                policy_error=decision.policy_error,
                workflow=decision.workflow,
            )
        )

    async def _emit_workflow_events(self, envelope: Any, events: list[dict]) -> None:
        for record in events:
            workflow = record.get("workflow")
            action_name = record.get("action")
            if not isinstance(workflow, dict) or not isinstance(action_name, str):
                continue
            action = AuditAction.WORKFLOW_STAGE_ADVANCED
            if action_name == AuditAction.WORKFLOW_COMPLETED.value:
                action = AuditAction.WORKFLOW_COMPLETED
            await self._guard.audit_sink.emit(
                AuditEvent(
                    action=action,
                    run_id=envelope.run_id,
                    call_id=envelope.call_id,
                    call_index=envelope.call_index,
                    session_id=self._session_id,
                    parent_session_id=self._audit_parent_session_id(),
                    tool_name=envelope.tool_name,
                    tool_args=self._guard.redaction.redact_args(envelope.args),
                    side_effect=envelope.side_effect.value,
                    environment=envelope.environment,
                    principal=asdict(envelope.principal) if envelope.principal else None,
                    mode=self._guard.mode,
                    policy_version=self._guard.policy_version,
                    workflow=dict(workflow),
                )
            )

    async def _resolve_pending_approval(
        self,
        envelope: Any,
        decision: Any,
        span: Any,
        tool_call_id: str,
    ) -> tuple[Any | None, Any]:
        current = decision
        for _ in range(_MAX_WORKFLOW_APPROVAL_ROUNDS):
            blocked_result = await self._handle_approval(envelope, current, span, tool_call_id)
            if blocked_result is not None:
                return blocked_result, current
            if (
                current.decision_source != "workflow"
                or not current.workflow_stage_id
                or self._guard._workflow_runtime is None
            ):
                return None, replace(current, action="allow")
            await self._guard._workflow_runtime.record_approval(self._session, current.workflow_stage_id)
            current = await self._pipeline.pre_execute(envelope, self._session)
            await self._emit_workflow_events(envelope, current.workflow_events)
            if current.action != "pending_approval":
                return None, current
        raise RuntimeError(f"workflow: exceeded maximum approval rounds ({_MAX_WORKFLOW_APPROVAL_ROUNDS})")

    async def _handle_approval(
        self,
        envelope: Any,
        decision: Any,
        span: Any,
        tool_call_id: str,
    ) -> Any | None:
        if self._guard._approval_backend is None:
            reason = "Approval required but no approval backend configured"
            await self._emit_audit_pre(envelope, decision, audit_action=AuditAction.CALL_DENIED)
            self._guard.telemetry.record_denial(envelope, reason)
            if self._guard._on_deny:
                try:
                    self._guard._on_deny(envelope, reason, decision.decision_name)
                except Exception:
                    logger.exception("on_deny callback raised")
            span.set_attribute("governance.action", "denied")
            self._guard.telemetry.set_span_error(span, reason)
            span.end()
            return self._deny(reason, tool_call_id)

        principal_dict = asdict(envelope.principal) if envelope.principal else None
        approval_request = await self._guard._approval_backend.request_approval(
            tool_name=envelope.tool_name,
            tool_args=envelope.args,
            message=decision.approval_message or decision.reason or "",
            timeout=decision.approval_timeout,
            timeout_action=decision.approval_timeout_action,
            principal=principal_dict,
        )
        await self._emit_audit_pre(envelope, decision, audit_action=AuditAction.CALL_APPROVAL_REQUESTED)

        approval_decision = await self._guard._approval_backend.wait_for_decision(
            approval_id=approval_request.approval_id,
            timeout=decision.approval_timeout,
        )

        approved = approval_decision.approved
        if approval_decision.status == ApprovalStatus.TIMEOUT:
            await self._emit_audit_pre(envelope, decision, audit_action=AuditAction.CALL_APPROVAL_TIMEOUT)
            if decision.approval_timeout_action == "allow":
                approved = True
        elif approval_decision.approved:
            await self._emit_audit_pre(envelope, decision, audit_action=AuditAction.CALL_APPROVAL_GRANTED)
        else:
            await self._emit_audit_pre(envelope, decision, audit_action=AuditAction.CALL_APPROVAL_DENIED)

        if approved:
            span_action = "approved"
            if approval_decision.status == ApprovalStatus.TIMEOUT and decision.approval_timeout_action == "allow":
                span_action = "timeout_allow"
            span.set_attribute("governance.action", span_action)
            return None

        reason = approval_decision.reason or decision.reason or "Approval blocked"
        if not approved and approval_decision.status == ApprovalStatus.TIMEOUT:
            reason = f"Approval timed out: {reason}"
        self._guard.telemetry.record_denial(envelope, reason)
        if self._guard._on_deny:
            try:
                self._guard._on_deny(envelope, reason, decision.decision_name)
            except Exception:
                logger.exception("on_deny callback raised")
        span.set_attribute("governance.action", "denied")
        self._guard.telemetry.set_span_error(span, reason)
        span.end()
        return self._deny(f"Approval blocked: {reason}", tool_call_id)

    def _check_tool_success(self, tool_name: str, result: Any) -> bool:
        if self._guard._success_check is not None:
            return bool(self._guard._success_check(tool_name, result))
        if result is None:
            return True
        # Check for LangChain ToolMessage with error content
        content = getattr(result, "content", None)
        if isinstance(content, str):
            content_lower = content[:7].lower()
            if content_lower.startswith("error:") or content_lower.startswith("fatal:"):
                return False
        if isinstance(result, dict):
            if result.get("is_error"):
                return False
        if isinstance(result, str):
            lower = result[:7].lower()
            if lower.startswith("error:") or lower.startswith("fatal:"):
                return False
        return True

    def _deny(self, reason: str, tool_call_id: str) -> Any:
        """Return a LangChain ToolMessage denial."""
        try:
            from langchain.messages import ToolMessage
        except ImportError:
            from dataclasses import dataclass as _dc

            @_dc
            class ToolMessage:  # type: ignore[no-redef]
                content: str
                tool_call_id: str

        return ToolMessage(content=f"DENIED: {reason}", tool_call_id=tool_call_id)
