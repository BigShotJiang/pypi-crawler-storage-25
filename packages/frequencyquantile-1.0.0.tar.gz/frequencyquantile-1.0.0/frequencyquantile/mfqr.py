"""
Multi-Frequency Quantile Regression (MFQR)
===========================================

Implements the MFQR methodology introduced by Adebayo (2026, Applied
Economics 58:3922-3941), which combines EEMD decomposition with
quantile regression at each frequency level.

Three-step procedure:
    1. Decompose Y and X into IMFs via EEMD
    2. Run quantile regression on each (IMF_k[Y], IMF_k[X]) pair
    3. Collect results across quantiles and frequencies

References
----------
Adebayo T.S. (2026). "Response of sectoral CO2 emissions to climate
and economic policy uncertainties: a multi-frequency quantile analysis",
*Applied Economics*, 58(20): 3922-3941.

Li G., Li Y., Tsai C-L. (2015). "Quantile Correlations and Quantile
Autoregressive Modeling", JASA, 110(509): 246-261.
"""

import numpy as np
import pandas as pd
from dataclasses import dataclass, field
from typing import Optional, List, Dict

from .decomposition import eemd_decompose
from .utils import quantile_regression, add_intercept


@dataclass
class MFQRResult:
    """Container for MFQR results at one frequency level."""
    frequency_level: int
    frequency_label: str
    quantiles: np.ndarray
    coefficients: np.ndarray    # β₁(τ) for each τ
    intercepts: np.ndarray      # β₀(τ) for each τ
    std_errors: np.ndarray
    t_stats: np.ndarray
    p_values: np.ndarray
    n_obs: int = 0


class MFQR:
    """
    Multi-Frequency Quantile Regression.

    Decomposes response (Y) and factor (X) series into IMFs using EEMD,
    then runs quantile regression at each frequency level and quantile.

    Parameters
    ----------
    n_imfs : number of EEMD frequency levels
    quantiles : list of quantile levels (default: 0.05 to 0.95 by 0.05)
    noise_width : EEMD noise parameter
    n_trials : EEMD ensemble size

    Example
    -------
    >>> mfqr = MFQR(n_imfs=5)
    >>> results = mfqr.fit(y_series, x_series)
    >>> mfqr.summary()
    """

    def __init__(self, n_imfs: int = 5,
                 quantiles: Optional[List[float]] = None,
                 noise_width: float = 0.05,
                 n_trials: int = 100):
        self.n_imfs = n_imfs
        self.quantiles = np.array(quantiles or
                                  [0.05, 0.10, 0.15, 0.20, 0.25, 0.30,
                                   0.35, 0.40, 0.45, 0.50, 0.55, 0.60,
                                   0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95])
        self.noise_width = noise_width
        self.n_trials = n_trials
        self.results_: List[MFQRResult] = []
        self.y_name: str = "Y"
        self.x_name: str = "X"

    def fit(self, y: np.ndarray, x: np.ndarray,
            y_name: str = "Y", x_name: str = "X") -> "MFQR":
        """
        Run MFQR: decompose + quantile-regress at each level.

        Parameters
        ----------
        y : response time series
        x : factor time series
        y_name, x_name : variable labels for output
        """
        from scipy.stats import norm

        self.y_name = y_name
        self.x_name = x_name

        y = np.asarray(y, dtype=float)
        x = np.asarray(x, dtype=float)
        n = min(len(y), len(x))
        y, x = y[:n], x[:n]

        # Step 1: EEMD decomposition
        dec_y = eemd_decompose(y, n_imfs=self.n_imfs,
                               noise_width=self.noise_width,
                               n_trials=self.n_trials)
        dec_x = eemd_decompose(x, n_imfs=self.n_imfs,
                               noise_width=self.noise_width,
                               n_trials=self.n_trials)

        K = min(dec_y["n_imfs"], dec_x["n_imfs"])
        self.results_ = []

        # Step 2: QR at each frequency
        for k in range(K):
            imf_y = dec_y["imfs"][k]
            imf_x = dec_x["imfs"][k]
            T = min(len(imf_y), len(imf_x))
            imf_y, imf_x = imf_y[:T], imf_x[:T]

            Xmat = add_intercept(imf_x.reshape(-1, 1))
            n_q = len(self.quantiles)
            coefs = np.zeros(n_q)
            intercepts = np.zeros(n_q)
            ses = np.zeros(n_q)
            tstats = np.zeros(n_q)
            pvals = np.zeros(n_q)

            for j, tau in enumerate(self.quantiles):
                try:
                    beta, res = quantile_regression(imf_y, Xmat, tau)
                    intercepts[j] = beta[0]
                    coefs[j] = beta[1]

                    # Bootstrap SE
                    B = 200
                    boot_coefs = np.empty(B)
                    for b in range(B):
                        idx = np.random.choice(T, T, replace=True)
                        try:
                            bb, _ = quantile_regression(imf_y[idx], Xmat[idx], tau)
                            boot_coefs[b] = bb[1]
                        except Exception:
                            boot_coefs[b] = coefs[j]
                    ses[j] = np.std(boot_coefs, ddof=1)
                    tstats[j] = coefs[j] / ses[j] if ses[j] > 0 else 0
                    pvals[j] = 2 * (1 - norm.cdf(abs(tstats[j])))
                except Exception:
                    coefs[j] = np.nan
                    ses[j] = np.nan

            freq_label = f"IMF{k + 1}"
            if k < K // 3:
                freq_label += " (High freq / Short-term)"
            elif k < 2 * K // 3:
                freq_label += " (Medium freq / Medium-term)"
            else:
                freq_label += " (Low freq / Long-term)"

            self.results_.append(MFQRResult(
                frequency_level=k + 1,
                frequency_label=freq_label,
                quantiles=self.quantiles.copy(),
                coefficients=coefs,
                intercepts=intercepts,
                std_errors=ses,
                t_stats=tstats,
                p_values=pvals,
                n_obs=T,
            ))

        return self

    def summary(self) -> pd.DataFrame:
        """
        Summary table of MFQR coefficients across frequencies and quantiles.
        """
        rows = []
        for res in self.results_:
            for j, tau in enumerate(res.quantiles):
                sig = ""
                p = res.p_values[j]
                if not np.isnan(p):
                    if p < 0.01: sig = "***"
                    elif p < 0.05: sig = "**"
                    elif p < 0.10: sig = "*"
                rows.append({
                    "Frequency": res.frequency_label,
                    "Level": res.frequency_level,
                    "Quantile": tau,
                    f"β({self.x_name})": res.coefficients[j],
                    "Std.Error": res.std_errors[j],
                    "t-stat": res.t_stats[j],
                    "p-value": res.p_values[j],
                    "Sig": sig,
                })
        return pd.DataFrame(rows)

    def coefficient_matrix(self) -> pd.DataFrame:
        """
        Pivot table: rows = quantiles, columns = frequency levels.
        Values = β₁(τ) coefficients.
        """
        df = self.summary()
        return df.pivot_table(values=f"β({self.x_name})",
                              index="Quantile",
                              columns="Level")

    def significance_matrix(self) -> pd.DataFrame:
        """
        Pivot table: rows = quantiles, columns = frequency levels.
        Values = significance stars.
        """
        df = self.summary()
        return df.pivot_table(values="Sig",
                              index="Quantile",
                              columns="Level",
                              aggfunc="first")
