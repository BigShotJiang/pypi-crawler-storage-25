"""
Uncertain Quantile Autoregressive (UQAR) Model
================================================

Implements the uncertain QAR model of Shi & Sheng (2025, Comm. Stat. -
Simulation and Computation, 54(6): 1869-1889).

Handles imprecise/interval-valued observations under Liu's uncertainty
theory, with parameter estimation, residual analysis, hypothesis
testing, order selection, and prediction with confidence intervals.

References
----------
Shi Y., Sheng Y. (2025). "Uncertain quantile autoregressive model",
*Communications in Statistics - Simulation and Computation*,
54(6): 1869-1889.

Liu B. (2007). *Uncertainty Theory*, 2nd edn. Springer.
Li T., Hu X. (2022). "A new quantile regression model based on
uncertainty theory", *J. Xinjiang University*, 39(5): 530-541.
"""

import numpy as np
import pandas as pd
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Tuple
from scipy.optimize import minimize


# ── Uncertain variable helpers ────────────────────────────────────────

def linear_dist_inverse(a: float, b: float, alpha: float) -> float:
    """Inverse uncertainty distribution for L(a,b): U⁻¹(α) = a + (b-a)α."""
    return a + (b - a) * alpha


def normal_uncertain_inverse(e: float, sigma: float, alpha: float) -> float:
    """Inverse for normal uncertain N(e, σ): e + σ√3/π · ln(α/(1-α))."""
    if alpha <= 0 or alpha >= 1:
        return e
    return e + sigma * np.sqrt(3) / np.pi * np.log(alpha / (1 - alpha))


# ── Uncertain quantile loss ──────────────────────────────────────────

def uncertain_quantile_loss(r: float, s: float) -> float:
    """q_s(r) = s·r if r ≥ 0, (s-1)·r otherwise."""
    return s * r if r >= 0 else (s - 1) * r


# ── Core model ────────────────────────────────────────────────────────

@dataclass
class UncertainQARResult:
    """Result container for one quantile."""
    quantile: float
    order: int
    coefficients: np.ndarray     # [c_s0, c_s1, ..., c_sk]
    residual_mean: float
    residual_std: float
    hypothesis_passed: bool
    ste: float                    # Summation of Test Errors
    forecast: float
    confidence_interval: Tuple[float, float]


class UncertainQAR:
    """
    Uncertain Quantile Autoregressive Model.

    For imprecise observations X_1, ..., X_n given as intervals L(a,b)
    (linear uncertainty distribution), estimates QAR parameters at
    different uncertainty quantiles s.

    Parameters
    ----------
    order : AR order k (or None for automatic via cross-validation)
    max_order : maximum order for cross-validation
    quantiles : list of uncertainty quantiles s ∈ (0,1)
    sig_level : significance level β for hypothesis testing

    Example
    -------
    >>> # Data as list of (lower, upper) interval pairs
    >>> data = [(2.26, 2.36), (3.18, 3.28), ...]
    >>> model = UncertainQAR(order=3, quantiles=[0.1, 0.3, 0.5, 0.7, 0.9])
    >>> model.fit(data)
    >>> model.summary()
    """

    def __init__(self, order: Optional[int] = None,
                 max_order: int = 5,
                 quantiles: Optional[List[float]] = None,
                 sig_level: float = 0.05,
                 n_integration: int = 100):
        self.order = order
        self.max_order = max_order
        self.quantiles = quantiles or [0.1, 0.3, 0.5, 0.7, 0.9]
        self.sig_level = sig_level
        self.n_int = n_integration  # quadrature points
        self.results_: Dict[float, UncertainQARResult] = {}
        self._data: Optional[np.ndarray] = None  # (n, 2) lower/upper
        self._midpoints: Optional[np.ndarray] = None

    def _expected_value(self, a: float, b: float) -> float:
        """E[L(a,b)] = (a+b)/2."""
        return (a + b) / 2

    def _inverse_dist(self, idx: int, alpha: float) -> float:
        """U_t^{-1}(α) for observation t."""
        a, b = self._data[idx]
        return linear_dist_inverse(a, b, alpha)

    def _omega_inv(self, idx: int, alpha: float, c_sign: float) -> float:
        """
        ω_{t-i}^{-1}(α) = U_{t-i}^{-1}(1-α) if c_si ≥ 0, else U_{t-i}^{-1}(α).
        """
        if c_sign >= 0:
            return self._inverse_dist(idx, 1 - alpha)
        return self._inverse_dist(idx, alpha)

    def _objective(self, params: np.ndarray, s: float, k: int) -> float:
        """
        Minimisation objective (Eq. 4 in paper).
        Numerical integration over α ∈ (0,1).
        """
        n = len(self._data)
        alphas = np.linspace(0.01, 0.99, self.n_int)
        total = 0.0

        for t in range(k, n):
            x_mid = self._midpoints[t]
            fitted = params[0]
            for i in range(1, k + 1):
                fitted += params[i] * self._midpoints[t - i]

            if x_mid < fitted:
                # (s-1) term
                integral = 0.0
                for alpha in alphas:
                    u_t = self._inverse_dist(t, alpha)
                    pred = params[0]
                    for i in range(1, k + 1):
                        pred += params[i] * self._omega_inv(t - i, alpha, params[i])
                    integral += (u_t - pred)
                integral *= (s - 1) / self.n_int
                total += integral
            else:
                # s term
                integral = 0.0
                for alpha in alphas:
                    u_t = self._inverse_dist(t, alpha)
                    pred = params[0]
                    for i in range(1, k + 1):
                        pred += params[i] * self._omega_inv(t - i, alpha, params[i])
                    integral += (u_t - pred)
                integral *= s / self.n_int
                total += integral

        return abs(total)

    def _compute_ate(self, k: int) -> float:
        """Average Training Error for order selection (Eq. 18)."""
        s = 0.5
        n = len(self._data)
        params0 = np.zeros(k + 1)
        params0[0] = np.mean(self._midpoints)
        result = minimize(self._objective, params0, args=(s, k),
                          method="Nelder-Mead",
                          options={"maxiter": 2000, "xatol": 1e-6})
        params = result.x

        ate = 0.0
        for t in range(k, n):
            fitted = params[0]
            for i in range(1, k + 1):
                fitted += params[i] * self._midpoints[t - i]
            ate += (self._midpoints[t] - fitted) ** 2
        return ate / (n - k)

    def _estimate_quantile(self, s: float, k: int) -> np.ndarray:
        """Estimate parameters for quantile s and order k."""
        params0 = np.zeros(k + 1)
        params0[0] = np.mean(self._midpoints)

        result = minimize(self._objective, params0, args=(s, k),
                          method="Nelder-Mead",
                          options={"maxiter": 5000, "xatol": 1e-8})
        return result.x

    def _residual_analysis(self, params: np.ndarray, s: float, k: int):
        """Compute expected value and std of residuals (Eqs. 7-10)."""
        n = len(self._data)
        alphas = np.linspace(0.01, 0.99, self.n_int)
        residuals_exp = []

        for t in range(k, n):
            integral = 0.0
            for alpha in alphas:
                u_t = self._inverse_dist(t, alpha)
                pred = params[0]
                for i in range(1, k + 1):
                    pred += params[i] * self._omega_inv(t - i, alpha, params[i])
                integral += (u_t - pred)
            residuals_exp.append(integral / self.n_int)

        e_hat = np.mean(residuals_exp)

        # Variance
        var_terms = []
        for t in range(k, n):
            integral = 0.0
            for alpha in alphas:
                u_t = self._inverse_dist(t, alpha)
                pred = params[0]
                for i in range(1, k + 1):
                    pred += params[i] * self._omega_inv(t - i, alpha, params[i])
                integral += (u_t - pred - e_hat) ** 2
            var_terms.append(integral / self.n_int)
        sigma_hat = np.sqrt(np.mean(var_terms))

        return e_hat, sigma_hat

    def _hypothesis_test(self, params: np.ndarray, e_hat: float,
                         sigma_hat: float, s: float, k: int) -> bool:
        """
        Uncertainty hypothesis testing (Section 4).
        H0: e_s = ê_s and σ_s = σ̂_s
        """
        n = len(self._data)
        beta = self.sig_level
        threshold = beta * (n - k)

        # Compute residual bounds
        rejections = 0
        U_inv_beta = normal_uncertain_inverse(e_hat, sigma_hat, beta)
        U_inv_1mbeta = normal_uncertain_inverse(e_hat, sigma_hat, 1 - beta)

        for t in range(k, n):
            # W_{s,t}^{-1}(β) and W_{s,t}^{-1}(1-β)
            resid = self._midpoints[t] - params[0]
            for i in range(1, k + 1):
                resid -= params[i] * self._midpoints[t - i]

            # Simplified: check if residual is extreme
            W_inv_beta = resid - 1.96 * sigma_hat
            W_inv_1mbeta = resid + 1.96 * sigma_hat

            if W_inv_1mbeta < U_inv_beta or W_inv_beta > U_inv_1mbeta:
                rejections += 1

        return rejections < threshold

    def _compute_ste(self, params: np.ndarray, k: int,
                     train_end: int) -> float:
        """Summation of Test Errors (model selection)."""
        n = len(self._data)
        alphas = np.linspace(0.01, 0.99, self.n_int)
        ste = 0.0

        for t in range(train_end, n):
            integral = 0.0
            for alpha in alphas:
                u_t = self._inverse_dist(t, alpha)
                pred = params[0]
                for i in range(1, k + 1):
                    if t - i >= 0:
                        pred += params[i] * self._omega_inv(t - i, alpha, params[i])
                integral += (u_t - pred) ** 2
            ste += integral / self.n_int

        return ste

    def fit(self, data, verbose: bool = True) -> "UncertainQAR":
        """
        Fit the Uncertain QAR model.

        Parameters
        ----------
        data : list of (lower, upper) tuples, or (n,2) array
        verbose : print progress

        Returns
        -------
        self
        """
        self._data = np.asarray(data, dtype=float)
        if self._data.ndim == 1:
            # Precise observations → treat as zero-width intervals
            self._data = np.column_stack([self._data, self._data])
        self._midpoints = np.mean(self._data, axis=1)
        n = len(self._data)

        # Order selection via cross-validation
        if self.order is None:
            if verbose:
                print("Selecting order via cross-validation (ATE)...")
            ates = {}
            for k in range(1, self.max_order + 1):
                ates[k] = self._compute_ate(k)
                if verbose:
                    print(f"  k={k}: ATE = {ates[k]:.6f}")
            self.order = min(ates, key=ates.get)
            if verbose:
                print(f"  => Selected order k = {self.order}")

        k = self.order
        train_end = int(0.8 * n)

        # Fit for each quantile
        self.results_ = {}
        for s in self.quantiles:
            if verbose:
                print(f"\nQuantile s = {s}:")

            # Estimate parameters
            params = self._estimate_quantile(s, k)
            if verbose:
                print(f"  Coefficients: {params}")

            # Residual analysis
            e_hat, sigma_hat = self._residual_analysis(params, s, k)
            if verbose:
                print(f"  e_hat_s = {e_hat:.4f}, sigma_hat_s = {sigma_hat:.4f}")

            # Hypothesis testing
            passed = self._hypothesis_test(params, e_hat, sigma_hat, s, k)
            if verbose:
                status = "[OK] PASSED" if passed else "[X] REJECTED"
                print(f"  Hypothesis test: {status}")

            # STE
            ste = self._compute_ste(params, k, train_end)

            # Forecast X_{n+1}
            forecast = params[0]
            for i in range(1, k + 1):
                if n - i >= 0:
                    forecast += params[i] * self._expected_value(*self._data[n - i])
            forecast += e_hat

            # Confidence interval
            b_s = 1.96 * sigma_hat  # approximate
            ci = (forecast - b_s, forecast + b_s)

            if verbose:
                print(f"  STE = {ste:.4f}")
                print(f"  Forecast = {forecast:.4f}, 95% CI = [{ci[0]:.4f}, {ci[1]:.4f}]")

            self.results_[s] = UncertainQARResult(
                quantile=s, order=k,
                coefficients=params,
                residual_mean=e_hat,
                residual_std=sigma_hat,
                hypothesis_passed=passed,
                ste=ste,
                forecast=forecast,
                confidence_interval=ci,
            )

        return self

    def summary(self) -> pd.DataFrame:
        """Summary table across all quantiles."""
        rows = []
        for s, res in self.results_.items():
            row = {
                "Quantile (s)": s,
                "Order (k)": res.order,
                "e_hat_s": res.residual_mean,
                "sigma_hat_s": res.residual_std,
                "H0 Test": "Pass" if res.hypothesis_passed else "Reject",
                "STE": res.ste,
                "Forecast": res.forecast,
                "CI Lower": res.confidence_interval[0],
                "CI Upper": res.confidence_interval[1],
            }
            # Add coefficients
            for i, c in enumerate(res.coefficients):
                row[f"c_s{i}"] = c
            rows.append(row)
        return pd.DataFrame(rows)

    def optimal_quantile(self) -> float:
        """Return the quantile with smallest STE among those that passed H₀."""
        passed = {s: r for s, r in self.results_.items() if r.hypothesis_passed}
        if not passed:
            return min(self.results_, key=lambda s: self.results_[s].ste)
        return min(passed, key=lambda s: passed[s].ste)
