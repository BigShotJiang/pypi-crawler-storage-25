"""
Quantile Autoregressive (QAR) Model & Modified Box-Jenkins Procedure
=====================================================================

Implements Sections 3.1 – 3.4 of Li, Li & Tsai (2015, JASA 110:246-261):
    - QPACF for model identification
    - QAR estimation
    - QACF of residuals for diagnostics
    - Box-Pierce-type test Q_BP(K)
    - Full modified three-stage procedure

References
----------
Li G., Li Y., Tsai C-L. (2015). "Quantile Correlations and Quantile
Autoregressive Modeling", *Journal of the American Statistical
Association*, 110(509): 246–261.

Koenker R., Xiao Z. (2006). "Quantile Autoregression", JASA 101:980-990.
"""

import warnings
import numpy as np
import pandas as pd
from dataclasses import dataclass, field
from typing import Optional, List, Dict

from .utils import (
    psi_tau, rho_tau, quantile_regression, ols,
    add_intercept, estimate_density_at_zero,
    bofinger_bandwidth,
)


# ── QPACF ─────────────────────────────────────────────────────────────

def qpacf(y: np.ndarray, tau: float, max_lag: int = 15,
           bandwidth_scale: float = 0.6) -> Dict:
    """
    Compute the sample Quantile Partial Autocorrelation Function (QPACF).

    Parameters
    ----------
    y : 1-D time series
    tau : quantile level in (0,1)
    max_lag : largest lag to compute
    bandwidth_scale : multiplier for Bofinger bandwidth (default 0.6, as
                      recommended by Koenker & Xiao 2006)

    Returns
    -------
    dict with:
        'lag'      : array of lags 1..max_lag
        'qpacf'    : φ̂_{kk,τ} values
        'se'       : asymptotic standard errors
        'ci_lower' : lower 95% confidence band
        'ci_upper' : upper 95% confidence band
    """
    y = np.asarray(y, dtype=float)
    n = len(y)
    results = {"lag": [], "qpacf": [], "se": [], "ci_lower": [], "ci_upper": []}

    for k in range(1, max_lag + 1):
        T = n - k
        if T < k + 2:
            break

        # Build Z_{t,k-1} = (y_{t-1}, ..., y_{t-k+1})
        Y_t = y[k:]
        Y_tk = y[:n - k]  # y_{t-k}

        if k == 1:
            Zstar = np.ones((T, 1))  # intercept only
        else:
            Z_cols = [y[k - j:n - j] for j in range(1, k)]
            Zstar = add_intercept(np.column_stack(Z_cols))

        # OLS: X = y_{t-k} on Z
        _, X_res = ols(Y_tk, Zstar)
        sigma2_xz = np.mean(X_res ** 2)

        # Quantile regression: Y_t on Z
        beta_qr, qr_res = quantile_regression(Y_t, Zstar, tau)
        psi = psi_tau(qr_res, tau)

        # φ̂_{kk,τ}
        phi_hat = np.mean(psi * Y_tk) / np.sqrt((tau - tau ** 2) * sigma2_xz)

        # Asymptotic SE via density estimation
        try:
            f_hat = estimate_density_at_zero(Y_t, Zstar, tau,
                                            bandwidth_scale=bandwidth_scale)
            # Simplified variance from Theorem 3
            A0 = np.mean(np.outer(Y_tk, np.ones(Zstar.shape[1])) * Zstar, axis=0)
            Omega30 = Zstar.T @ Zstar / T
            Omega31 = (Zstar.T * f_hat) @ Zstar / T
            Omega31_inv = np.linalg.pinv(Omega31)

            delta = Y_tk - A0 @ Omega31_inv @ Zstar.T @ np.diag(f_hat) @ np.ones(T) / T
            Omega32 = np.mean(Y_t ** 2) - 2 * A0 @ Omega31_inv @ A0 + \
                      A0 @ Omega31_inv @ Omega30 @ Omega31_inv @ A0
            Omega32 = max(Omega32, 1e-10)
            var_phi = (tau * (1 - tau)) * Omega32 / ((tau - tau ** 2) * sigma2_xz)
            se = np.sqrt(max(var_phi, 0) / T)
        except Exception:
            se = 1.0 / np.sqrt(T)

        results["lag"].append(k)
        results["qpacf"].append(phi_hat)
        results["se"].append(se)
        results["ci_lower"].append(-1.96 * se)
        results["ci_upper"].append(1.96 * se)

    for key in results:
        results[key] = np.array(results[key])
    return results


# ── QACF of residuals ─────────────────────────────────────────────────

def qacf(residuals: np.ndarray, tau: float, max_lag: int = 15) -> Dict:
    """
    Compute the Quantile Autocorrelation Function of QAR residuals.

    Parameters
    ----------
    residuals : QAR quantile residuals ê_{t,τ}
    tau : quantile level
    max_lag : number of lags

    Returns
    -------
    dict with 'lag', 'qacf', 'se', 'ci_lower', 'ci_upper'
    """
    e = np.asarray(residuals, dtype=float)
    n = len(e)
    results = {"lag": [], "qacf": [], "se": [], "ci_lower": [], "ci_upper": []}

    mu_e = e.mean()
    sigma2_e = np.var(e)

    for k in range(1, max_lag + 1):
        T = n - k
        if T < 5:
            break
        et = e[k:]
        et_k = e[:n - k]

        psi_val = psi_tau(et, tau)
        r_k = np.mean(psi_val * (et_k - mu_e)) / np.sqrt((tau - tau ** 2) * sigma2_e)
        se = 1.0 / np.sqrt(T)

        results["lag"].append(k)
        results["qacf"].append(r_k)
        results["se"].append(se)
        results["ci_lower"].append(-1.96 * se)
        results["ci_upper"].append(1.96 * se)

    for key in results:
        results[key] = np.array(results[key])
    return results


# ── Box-Pierce-type test ──────────────────────────────────────────────

def qbp_test(residuals: np.ndarray, tau: float, K: int = 6,
             p: int = 0) -> Dict:
    """
    Quantile Box-Pierce test Q_BP(K) = n Σ_{j=1}^{K} r²_{j,τ}.

    Under the null of correct specification (iid errors), this is
    approximately χ²_{K-p}.

    Parameters
    ----------
    residuals : QAR residuals
    tau : quantile level
    K : number of lags
    p : order of the fitted QAR model

    Returns
    -------
    dict with 'Q_BP', 'df', 'p_value'
    """
    from scipy.stats import chi2

    ac = qacf(residuals, tau, max_lag=K)
    n = len(residuals)
    Q = n * np.sum(ac["qacf"] ** 2)
    df = max(K - p, 1)
    pval = 1 - chi2.cdf(Q, df)
    return {"Q_BP": Q, "df": df, "p_value": pval}


# ── QAR Model ─────────────────────────────────────────────────────────

@dataclass
class QARModel:
    """
    Quantile Autoregressive model Q_τ(y_t | F_{t-1}) = φ_0(τ) + Σ φ_j(τ) y_{t-j}.

    Attributes
    ----------
    tau : quantile level
    lags : list of active lags (e.g., [1, 2, 5])
    coefficients : dict mapping lag → coefficient
    intercept : intercept φ_0(τ)
    residuals : quantile residuals
    se : standard errors of coefficients
    """
    tau: float
    lags: List[int] = field(default_factory=list)
    coefficients: Dict[int, float] = field(default_factory=dict)
    intercept: float = 0.0
    residuals: Optional[np.ndarray] = None
    se: Dict[int, float] = field(default_factory=dict)
    n_obs: int = 0

    def fit(self, y: np.ndarray, lags: Optional[List[int]] = None,
            max_lag: int = 1) -> "QARModel":
        """
        Estimate QAR model via quantile regression.

        Parameters
        ----------
        y : 1-D time series
        lags : explicit lag list, or None to use 1..max_lag
        max_lag : if lags is None, use [1, ..., max_lag]
        """
        y = np.asarray(y, dtype=float)
        if lags is None:
            lags = list(range(1, max_lag + 1))
        self.lags = sorted(lags)
        p = max(self.lags)
        n = len(y) - p
        self.n_obs = n

        # Design matrix
        Y = y[p:]
        X_cols = [y[p - lag:len(y) - lag] for lag in self.lags]
        Xstar = add_intercept(np.column_stack(X_cols))

        beta, res = quantile_regression(Y, Xstar, self.tau)
        self.intercept = beta[0]
        for i, lag in enumerate(self.lags):
            self.coefficients[lag] = beta[i + 1]
        self.residuals = res

        # Standard errors via sandwich estimator
        try:
            f_hat = estimate_density_at_zero(Y, Xstar, self.tau)
            J = (Xstar.T * f_hat) @ Xstar / n
            J_inv = np.linalg.pinv(J)
            H = (self.tau * (1 - self.tau)) * (Xstar.T @ Xstar) / n
            V = J_inv @ H @ J_inv / n
            ses = np.sqrt(np.maximum(np.diag(V), 0))
            self.se[0] = ses[0]
            for i, lag in enumerate(self.lags):
                self.se[lag] = ses[i + 1]
        except Exception:
            self.se = {lag: np.nan for lag in [0] + self.lags}

        return self

    def predict(self, y_history: np.ndarray, steps: int = 1) -> np.ndarray:
        """One-step-ahead conditional quantile forecast."""
        y_hist = np.asarray(y_history, dtype=float).copy()
        forecasts = []
        for _ in range(steps):
            val = self.intercept
            for lag in self.lags:
                if lag <= len(y_hist):
                    val += self.coefficients[lag] * y_hist[-lag]
            forecasts.append(val)
            y_hist = np.append(y_hist, val)
        return np.array(forecasts)

    def summary(self) -> pd.DataFrame:
        """Summary table of coefficients."""
        from scipy.stats import norm
        rows = []
        for lag in [0] + self.lags:
            coef = self.intercept if lag == 0 else self.coefficients[lag]
            se = self.se.get(lag, np.nan)
            z = coef / se if se > 0 and not np.isnan(se) else np.nan
            p = 2 * (1 - norm.cdf(abs(z))) if not np.isnan(z) else np.nan
            stars = ""
            if not np.isnan(p):
                if p < 0.01: stars = "***"
                elif p < 0.05: stars = "**"
                elif p < 0.10: stars = "*"
            name = "intercept" if lag == 0 else f"y(t-{lag})"
            rows.append({"Variable": name, "Coef": coef, "Std.Err": se,
                          "z-stat": z, "P>|z|": p, "Sig": stars})
        return pd.DataFrame(rows)


# ── Three-Stage Procedure ─────────────────────────────────────────────

def three_stage_procedure(y: np.ndarray, tau: float,
                          K: int = 15, alpha: float = 0.05,
                          verbose: bool = True) -> QARModel:
    """
    Modified Box-Jenkins three-stage procedure for QAR models
    (Section 3.3 of Li, Li & Tsai 2015).

    Stage 1: Identify tentative order via QPACF
    Stage 2: Estimate model
    Stage 3: Backward elimination + Q_BP diagnostic

    Parameters
    ----------
    y : time series
    tau : quantile level
    K : maximum lag
    alpha : significance level
    verbose : print progress

    Returns
    -------
    QARModel : the final selected model
    """
    y = np.asarray(y, dtype=float)

    # Stage 1: QPACF
    pacf = qpacf(y, tau, max_lag=K)
    significant = []
    for i, k in enumerate(pacf["lag"]):
        if abs(pacf["qpacf"][i]) > abs(pacf["ci_upper"][i]):
            significant.append(int(k))

    if len(significant) == 0:
        if verbose:
            print(f"[Stage 1] No significant QPACF lags at tau={tau:.2f}. "
                  "Fitting intercept-only model.")
        model = QARModel(tau=tau)
        model.intercept = np.quantile(y, tau)
        model.residuals = y - model.intercept
        model.n_obs = len(y)
        return model

    max_sig_lag = max(significant)
    lags = list(range(1, max_sig_lag + 1))
    if verbose:
        print(f"[Stage 1] QPACF suggests QAR({max_sig_lag}) at tau={tau:.2f}.")
        print(f"          Significant lags: {significant}")

    # Stage 2: Estimate full model
    model = QARModel(tau=tau)
    model.fit(y, lags=lags)
    if verbose:
        print(f"[Stage 2] Estimated QAR({max_sig_lag}) with lags {lags}.")

    # Stage 3: Backward elimination
    current_lags = list(lags)
    while len(current_lags) > 0:
        model.fit(y, lags=current_lags)
        summ = model.summary()

        # Find the lag with largest p-value > alpha (excluding intercept)
        lag_rows = summ[summ["Variable"] != "intercept"]
        insig = lag_rows[lag_rows["P>|z|"] > alpha]
        if insig.empty:
            break

        worst = insig.loc[insig["P>|z|"].idxmax()]
        worst_lag = int(worst["Variable"].replace("y(t-", "").replace(")", ""))
        current_lags.remove(worst_lag)
        if verbose:
            print(f"[Stage 3] Removing lag {worst_lag} (p={worst['P>|z|']:.4f}).")

        if len(current_lags) == 0:
            break

    # Final model
    if len(current_lags) > 0:
        model.fit(y, lags=current_lags)
    else:
        model = QARModel(tau=tau)
        model.intercept = np.quantile(y, tau)
        model.residuals = y - model.intercept
        model.n_obs = len(y)

    # Diagnostic
    if model.residuals is not None:
        bp = qbp_test(model.residuals, tau, K=K, p=len(current_lags))
        if verbose:
            print(f"[Stage 3] Final lags: {current_lags}")
            print(f"          Q_BP({K}) = {bp['Q_BP']:.3f}, p-value = {bp['p_value']:.4f}")
            if bp["p_value"] < alpha:
                print("          [!] Q_BP test rejects -- consider larger K or alternative model.")
            else:
                print("          [OK] Model passes Q_BP diagnostic.")

    return model
