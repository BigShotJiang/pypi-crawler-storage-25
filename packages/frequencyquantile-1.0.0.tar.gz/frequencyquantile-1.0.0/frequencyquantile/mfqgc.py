"""
Multi-Frequency Quantile Granger Causality (MFQGC)
====================================================

Implements the MFQGC methodology introduced by Adebayo (2026, Applied
Economics 58:3922-3941), integrating:
    - EEMD decomposition (Wu & Huang, 2009)
    - Quantile series generation (Li, Li & Tsai, 2015)
    - Granger causality testing (Granger, 1969)

Three-step procedure:
    1. Decompose Y and X into k levels using EEMD
    2. Generate quantile (τ) series for each decomposition of Y
    3. Granger causality between quantile series of Y and decomposed X

References
----------
Adebayo T.S. (2026). "Response of sectoral CO2 emissions ...",
*Applied Economics*, 58(20): 3922-3941.

Granger C.W.J. (1969). "Investigating Causal Relations by Econometric
Models and Cross-Spectral Methods", *Econometrica*, 37(3): 424-438.
"""

import numpy as np
import pandas as pd
from dataclasses import dataclass, field
from typing import Optional, List, Dict

from .decomposition import eemd_decompose
from .utils import quantile_regression, add_intercept


@dataclass
class MFQGCResult:
    """Results for one frequency level of MFQGC."""
    frequency_level: int
    frequency_label: str
    quantiles: np.ndarray
    f_stats: np.ndarray
    p_values: np.ndarray
    optimal_lags: np.ndarray
    n_obs: int = 0


class MFQGC:
    """
    Multi-Frequency Quantile Granger Causality.

    Tests whether X Granger-causes Y across different quantiles and
    frequency decomposition levels.

    Parameters
    ----------
    n_imfs : number of EEMD decomposition levels
    quantiles : list of quantile levels
    max_lag : maximum lag for VAR/Granger test
    noise_width : EEMD noise parameter
    n_trials : EEMD ensemble size

    Example
    -------
    >>> mfqgc = MFQGC(n_imfs=5)
    >>> results = mfqgc.fit(y_series, x_series)
    >>> mfqgc.summary()
    """

    def __init__(self, n_imfs: int = 5,
                 quantiles: Optional[List[float]] = None,
                 max_lag: int = 8,
                 noise_width: float = 0.05,
                 n_trials: int = 100):
        self.n_imfs = n_imfs
        self.quantiles = np.array(quantiles or
                                  [0.05, 0.10, 0.20, 0.30, 0.40, 0.50,
                                   0.60, 0.70, 0.80, 0.90, 0.95])
        self.max_lag = max_lag
        self.noise_width = noise_width
        self.n_trials = n_trials
        self.results_: List[MFQGCResult] = []
        self.y_name: str = "Y"
        self.x_name: str = "X"

    def _select_lag_aic(self, y: np.ndarray, x: np.ndarray) -> int:
        """Select optimal lag via AIC for bivariate VAR."""
        from statsmodels.tsa.api import VAR
        try:
            data = np.column_stack([y, x])
            model = VAR(data)
            result = model.select_order(maxlags=min(self.max_lag, len(y) // 3 - 1))
            return max(result.aic, 1)
        except Exception:
            return 1

    def _granger_test(self, y: np.ndarray, x: np.ndarray,
                      lag: int) -> Dict:
        """
        Standard Granger causality test: does x Granger-cause y?

        Restricted:   y_t = Σ α_μ y_{t-μ} + ε_t
        Unrestricted: y_t = Σ α_μ y_{t-μ} + Σ β_μ x_{t-μ} + ε_t

        F-test on joint significance of β coefficients.
        """
        from scipy.stats import f as f_dist

        n = len(y) - lag
        if n < lag + 2:
            return {"f_stat": np.nan, "p_value": np.nan}

        Y = y[lag:]
        # Restricted model: y lags only
        Xr_cols = [y[lag - m:len(y) - m] for m in range(1, lag + 1)]
        Xr = add_intercept(np.column_stack(Xr_cols))

        # Unrestricted: y lags + x lags
        Xu_cols = Xr_cols + [x[lag - m:len(x) - m] for m in range(1, lag + 1)]
        Xu = add_intercept(np.column_stack(Xu_cols))

        # OLS
        try:
            beta_r = np.linalg.lstsq(Xr, Y, rcond=None)[0]
            beta_u = np.linalg.lstsq(Xu, Y, rcond=None)[0]
        except Exception:
            return {"f_stat": np.nan, "p_value": np.nan}

        SSR_r = np.sum((Y - Xr @ beta_r) ** 2)
        SSR_u = np.sum((Y - Xu @ beta_u) ** 2)
        q = lag  # number of restrictions
        df2 = n - 2 * lag - 1

        if df2 <= 0 or SSR_u <= 0:
            return {"f_stat": np.nan, "p_value": np.nan}

        F = ((SSR_r - SSR_u) / q) / (SSR_u / df2)
        p = 1 - f_dist.cdf(F, q, df2)
        return {"f_stat": F, "p_value": p}

    def fit(self, y: np.ndarray, x: np.ndarray,
            y_name: str = "Y", x_name: str = "X") -> "MFQGC":
        """
        Run MFQGC analysis.

        Parameters
        ----------
        y : response time series
        x : factor time series
        y_name, x_name : labels
        """
        self.y_name = y_name
        self.x_name = x_name

        y = np.asarray(y, dtype=float)
        x = np.asarray(x, dtype=float)
        n = min(len(y), len(x))
        y, x = y[:n], x[:n]

        # Step 1: EEMD decomposition
        dec_y = eemd_decompose(y, n_imfs=self.n_imfs,
                               noise_width=self.noise_width,
                               n_trials=self.n_trials)
        dec_x = eemd_decompose(x, n_imfs=self.n_imfs,
                               noise_width=self.noise_width,
                               n_trials=self.n_trials)

        K = min(dec_y["n_imfs"], dec_x["n_imfs"])
        self.results_ = []

        for k in range(K):
            imf_y = dec_y["imfs"][k]
            imf_x = dec_x["imfs"][k]
            T = min(len(imf_y), len(imf_x))
            imf_y, imf_x = imf_y[:T], imf_x[:T]

            n_q = len(self.quantiles)
            fstats = np.zeros(n_q)
            pvals = np.zeros(n_q)
            opt_lags = np.zeros(n_q, dtype=int)

            for j, tau in enumerate(self.quantiles):
                # Step 2: Generate quantile series for Y at τ
                # Using rolling QAR(1) fitted values
                try:
                    Xmat = add_intercept(imf_y[:-1].reshape(-1, 1))
                    Y_qr = imf_y[1:]
                    beta, _ = quantile_regression(Y_qr, Xmat, tau)
                    y_tau = Xmat @ beta  # τ-th conditional quantile series
                except Exception:
                    y_tau = imf_y[1:]

                # Step 3: Granger causality
                x_k = imf_x[1:len(y_tau) + 1]
                lag = self._select_lag_aic(y_tau, x_k)
                opt_lags[j] = lag
                gc = self._granger_test(y_tau, x_k, lag)
                fstats[j] = gc["f_stat"]
                pvals[j] = gc["p_value"]

            freq_label = f"IMF{k + 1}"
            if k < K // 3:
                freq_label += " (High freq)"
            elif k < 2 * K // 3:
                freq_label += " (Medium freq)"
            else:
                freq_label += " (Low freq)"

            self.results_.append(MFQGCResult(
                frequency_level=k + 1,
                frequency_label=freq_label,
                quantiles=self.quantiles.copy(),
                f_stats=fstats,
                p_values=pvals,
                optimal_lags=opt_lags,
                n_obs=T,
            ))

        return self

    def summary(self) -> pd.DataFrame:
        """Summary table of Granger causality results."""
        rows = []
        for res in self.results_:
            for j, tau in enumerate(res.quantiles):
                sig = ""
                p = res.p_values[j]
                if not np.isnan(p):
                    if p < 0.01: sig = "***"
                    elif p < 0.05: sig = "**"
                    elif p < 0.10: sig = "*"
                rows.append({
                    "Frequency": res.frequency_label,
                    "Level": res.frequency_level,
                    "Quantile": tau,
                    "F-stat": res.f_stats[j],
                    "p-value": res.p_values[j],
                    "Lag": res.optimal_lags[j],
                    "Sig": sig,
                    "Causal": "Yes" if p < 0.05 else ("Weak" if p < 0.10 else "No"),
                })
        df = pd.DataFrame(rows)
        df.attrs["direction"] = f"{self.x_name} → {self.y_name}"
        return df

    def causality_matrix(self) -> pd.DataFrame:
        """
        Pivot table of significance: rows = quantiles, cols = frequencies.
        """
        df = self.summary()
        return df.pivot_table(values="Sig",
                              index="Quantile",
                              columns="Level",
                              aggfunc="first")

    def pvalue_matrix(self) -> pd.DataFrame:
        """Pivot of p-values."""
        df = self.summary()
        return df.pivot_table(values="p-value",
                              index="Quantile",
                              columns="Level")
