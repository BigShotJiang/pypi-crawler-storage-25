"""
Publication-Quality Tables for frequencyquantile
=================================================

Formatted summary tables with colour-coded significance stars.

Author : Dr Merwan Roudane
"""

import numpy as np
import pandas as pd
from tabulate import tabulate
from typing import Optional, Dict


class FrequencyQuantileTable:
    """
    Generates publication-quality summary tables.

    Example
    -------
    >>> tbl = FrequencyQuantileTable()
    >>> tbl.qar_summary(model)
    >>> tbl.mfqr_summary(mfqr_result)
    """

    def __init__(self, fmt: str = "fancy_grid"):
        """
        Parameters
        ----------
        fmt : tabulate format ('fancy_grid', 'latex', 'html', 'pipe', ...)
        """
        self.fmt = fmt

    def _format_sig(self, p: float) -> str:
        if np.isnan(p):
            return ""
        if p < 0.01:
            return "***"
        if p < 0.05:
            return "**"
        if p < 0.10:
            return "*"
        return ""

    # ── QAR Summary ───────────────────────────────────────────────────

    def qar_summary(self, model, show: bool = True) -> str:
        """Print QAR model summary table."""
        df = model.summary()
        df["Coef"] = df["Coef"].map(lambda x: f"{x:.4f}")
        df["Std.Err"] = df["Std.Err"].map(lambda x: f"{x:.4f}" if not np.isnan(x) else "-")
        df["z-stat"] = df["z-stat"].map(lambda x: f"{x:.3f}" if not np.isnan(x) else "-")
        df["P>|z|"] = df["P>|z|"].map(lambda x: f"{x:.4f}" if not np.isnan(x) else "-")

        header = (f"+==========================================+\n"
                  f"|  QAR Model Summary -- tau = {model.tau:.2f}          |\n"
                  f"|  n = {model.n_obs}, lags = {model.lags}   |\n"
                  f"+==========================================+\n")
        tbl = tabulate(df, headers="keys", tablefmt=self.fmt,
                       showindex=False, numalign="right")
        result = header + tbl + "\n*** p<0.01, ** p<0.05, * p<0.10"
        if show:
            print(result)
        return result

    # ── MFQR Summary ──────────────────────────────────────────────────

    def mfqr_summary(self, mfqr, show: bool = True) -> str:
        """Print MFQR results as a formatted table."""
        df = mfqr.summary()
        x_col = [c for c in df.columns if c.startswith("β(")][0]

        display_df = df[["Frequency", "Quantile", x_col,
                         "Std.Error", "t-stat", "p-value", "Sig"]].copy()
        display_df[x_col] = display_df[x_col].map(lambda x: f"{x:.4f}")
        display_df["Std.Error"] = display_df["Std.Error"].map(
            lambda x: f"{x:.4f}" if not np.isnan(x) else "-")
        display_df["t-stat"] = display_df["t-stat"].map(
            lambda x: f"{x:.3f}" if not np.isnan(x) else "-")
        display_df["p-value"] = display_df["p-value"].map(
            lambda x: f"{x:.4f}" if not np.isnan(x) else "-")

        header = (f"+=================================================+\n"
                  f"|  Multi-Frequency Quantile Regression (MFQR)      |\n"
                  f"|  {mfqr.x_name} -> {mfqr.y_name}                 |\n"
                  f"+=================================================+\n")
        tbl = tabulate(display_df, headers="keys", tablefmt=self.fmt,
                       showindex=False, numalign="right")
        result = header + tbl + "\n*** p<0.01, ** p<0.05, * p<0.10"
        if show:
            print(result)
        return result

    # ── MFQGC Summary ─────────────────────────────────────────────────

    def mfqgc_summary(self, mfqgc, show: bool = True) -> str:
        """Print MFQGC Granger causality results."""
        df = mfqgc.summary()
        display_df = df[["Frequency", "Quantile", "Lag",
                         "F-stat", "p-value", "Sig", "Causal"]].copy()
        display_df["F-stat"] = display_df["F-stat"].map(
            lambda x: f"{x:.3f}" if not np.isnan(x) else "-")
        display_df["p-value"] = display_df["p-value"].map(
            lambda x: f"{x:.4f}" if not np.isnan(x) else "-")

        direction = df.attrs.get("direction", f"{mfqgc.x_name} -> {mfqgc.y_name}")
        header = (f"+=====================================================+\n"
                  f"| Multi-Frequency Quantile Granger Causality (MFQGC)  |\n"
                  f"| Direction: {direction:<42s} |\n"
                  f"+=====================================================+\n")
        tbl = tabulate(display_df, headers="keys", tablefmt=self.fmt,
                       showindex=False, numalign="right")
        result = header + tbl + "\n*** p<0.01, ** p<0.05, * p<0.10"
        if show:
            print(result)
        return result

    # ── Uncertain QAR Summary ─────────────────────────────────────────

    def uncertain_qar_summary(self, uqar, show: bool = True) -> str:
        """Print Uncertain QAR summary."""
        df = uqar.summary()

        # Format columns
        for col in df.columns:
            if col in ("Quantile (s)", "Order (k)", "H0 Test"):
                continue
            if col.startswith("c_s"):
                df[col] = df[col].map(lambda x: f"{x:.4f}")
            elif col in ("e_hat_s", "sigma_hat_s", "STE", "Forecast", "CI Lower", "CI Upper"):
                df[col] = df[col].map(lambda x: f"{x:.4f}")

        optimal = uqar.optimal_quantile()
        header = (f"+=================================================+\n"
                  f"|  Uncertain Quantile Autoregressive Model          |\n"
                  f"|  Order k = {uqar.order}, Optimal quantile s = {optimal:.1f}   |\n"
                  f"+=================================================+\n")
        tbl = tabulate(df, headers="keys", tablefmt=self.fmt,
                       showindex=False, numalign="right")
        result = header + tbl
        if show:
            print(result)
        return result

    # ── LaTeX export ──────────────────────────────────────────────────

    def to_latex(self, df: pd.DataFrame, caption: str = "",
                 label: str = "") -> str:
        """Convert DataFrame to LaTeX table."""
        latex = df.to_latex(index=False, escape=False,
                            caption=caption, label=label)
        return latex
