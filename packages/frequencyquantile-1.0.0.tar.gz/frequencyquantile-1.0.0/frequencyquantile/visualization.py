"""
Publication-Quality Visualisations for frequencyquantile
========================================================

Beautiful, modern plots for all three paper methods:
    - QPACF / QACF lollipop plots (Paper 1)
    - MFQR heatmaps & coefficient surfaces (Paper 2)
    - MFQGC causality heatmaps (Paper 2)
    - Uncertain QAR forecast fan charts (Paper 3)
    - EEMD decomposition panel plots

Author : Dr Merwan Roudane
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from matplotlib.patches import FancyBboxPatch
import seaborn as sns
from typing import Optional, Dict, List

# ── Global style ──────────────────────────────────────────────────────
_PALETTE = {
    "bg_dark": "#0D1117",
    "bg_card": "#161B22",
    "text": "#E6EDF3",
    "text_dim": "#8B949E",
    "accent": "#58A6FF",
    "accent2": "#F78166",
    "accent3": "#3FB950",
    "accent4": "#D2A8FF",
    "grid": "#21262D",
    "pos": "#3FB950",
    "neg": "#F85149",
    "neutral": "#8B949E",
}

_CMAP_COEFF = sns.diverging_palette(10, 220, as_cmap=True)
_CMAP_PVAL = sns.light_palette("#F85149", as_cmap=True, reverse=True)
_CMAP_SIG = mcolors.ListedColormap(["#F85149", "#F78166", "#58A6FF", "#3FB950"])


def _apply_dark_style(ax, fig=None):
    """Apply dark-mode styling to axes."""
    ax.set_facecolor(_PALETTE["bg_card"])
    ax.tick_params(colors=_PALETTE["text_dim"], which="both")
    ax.spines["bottom"].set_color(_PALETTE["grid"])
    ax.spines["left"].set_color(_PALETTE["grid"])
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.xaxis.label.set_color(_PALETTE["text"])
    ax.yaxis.label.set_color(_PALETTE["text"])
    ax.title.set_color(_PALETTE["text"])
    if fig is not None:
        fig.patch.set_facecolor(_PALETTE["bg_dark"])


class FrequencyQuantilePlotter:
    """
    Publication-quality plotter for frequencyquantile results.

    Example
    -------
    >>> plotter = FrequencyQuantilePlotter()
    >>> plotter.plot_qpacf(pacf_result, title="QPACF at τ=0.05")
    """

    def __init__(self, style: str = "dark", figsize: tuple = (12, 6)):
        self.style = style
        self.figsize = figsize
        plt.rcParams.update({
            "font.family": "sans-serif",
            "font.sans-serif": ["Inter", "Segoe UI", "Helvetica", "Arial"],
            "font.size": 11,
            "axes.titlesize": 14,
            "axes.labelsize": 12,
        })

    # ── Paper 1: QPACF / QACF ────────────────────────────────────────

    def plot_qpacf(self, pacf_result: Dict, tau: float = None,
                   title: str = None, ax=None, save: str = None):
        """
        Lollipop plot of QPACF with confidence bands.
        """
        if ax is None:
            fig, ax = plt.subplots(figsize=self.figsize)
        else:
            fig = ax.get_figure()
        _apply_dark_style(ax, fig)

        lags = pacf_result["lag"]
        vals = pacf_result["qpacf"]
        ci_lo = pacf_result["ci_lower"]
        ci_hi = pacf_result["ci_upper"]

        # Confidence band
        ax.fill_between(lags, ci_lo, ci_hi, alpha=0.15, color=_PALETTE["accent"],
                        label="95% CI")
        ax.axhline(0, color=_PALETTE["grid"], lw=1)

        # Lollipops
        colors = [_PALETTE["pos"] if v > 0 else _PALETTE["neg"] for v in vals]
        significant = [abs(v) > abs(c) for v, c in zip(vals, ci_hi)]
        for i, (lag, val, col, sig) in enumerate(zip(lags, vals, colors, significant)):
            lw = 2.5 if sig else 1.2
            alpha = 1.0 if sig else 0.5
            ax.vlines(lag, 0, val, colors=col, lw=lw, alpha=alpha)
            marker = "D" if sig else "o"
            ms = 8 if sig else 5
            ax.plot(lag, val, marker, color=col, markersize=ms, alpha=alpha,
                    markeredgecolor="white", markeredgewidth=0.5)

        tau_str = f"τ = {tau}" if tau else ""
        ax.set_title(title or f"Quantile Partial Autocorrelation Function (QPACF) {tau_str}",
                     fontweight="bold", pad=15)
        ax.set_xlabel("Lag")
        ax.set_ylabel("QPACF")
        ax.set_xticks(lags)

        if save:
            fig.savefig(save, dpi=300, bbox_inches="tight", facecolor=fig.get_facecolor())
        return fig, ax

    def plot_qacf(self, acf_result: Dict, tau: float = None,
                  title: str = None, ax=None, save: str = None):
        """Lollipop plot of QACF of residuals."""
        return self.plot_qpacf(acf_result, tau=tau,
                               title=title or f"Quantile ACF of Residuals (τ={tau})",
                               ax=ax, save=save)

    def plot_multi_qpacf(self, y: np.ndarray, taus: List[float],
                         max_lag: int = 15, save: str = None):
        """Plot QPACF for multiple quantiles side by side."""
        from .qar import qpacf as _qpacf

        n_tau = len(taus)
        fig, axes = plt.subplots(1, n_tau, figsize=(5 * n_tau, 5), sharey=True)
        fig.patch.set_facecolor(_PALETTE["bg_dark"])

        if n_tau == 1:
            axes = [axes]

        for i, tau in enumerate(taus):
            pacf = _qpacf(y, tau, max_lag=max_lag)
            self.plot_qpacf(pacf, tau=tau, ax=axes[i])

        fig.suptitle("QPACF Across Quantiles", fontsize=16,
                     fontweight="bold", color=_PALETTE["text"], y=1.02)
        plt.tight_layout()

        if save:
            fig.savefig(save, dpi=300, bbox_inches="tight",
                        facecolor=fig.get_facecolor())
        return fig

    # ── Paper 2: MFQR Heatmap ────────────────────────────────────────

    def plot_mfqr_heatmap(self, mfqr, title: str = None,
                          save: str = None):
        """
        Heatmap of MFQR coefficients (rows=quantiles, cols=frequencies).
        Annotated with significance stars.
        """
        coef_mat = mfqr.coefficient_matrix()
        sig_mat = mfqr.significance_matrix()

        fig, ax = plt.subplots(figsize=(max(8, coef_mat.shape[1] * 2), 10))
        _apply_dark_style(ax, fig)

        # Build annotation matrix
        annot = coef_mat.copy().astype(str)
        for r in annot.index:
            for c in annot.columns:
                val = coef_mat.loc[r, c]
                star = sig_mat.loc[r, c] if (r, c) in sig_mat.stack().index else ""
                if pd.notna(star) and star:
                    annot.loc[r, c] = f"{val:.3f}{star}"
                else:
                    annot.loc[r, c] = f"{val:.3f}"

        # Column labels
        freq_labels = [f"IMF{c}" for c in coef_mat.columns]

        sns.heatmap(coef_mat, annot=annot, fmt="", cmap=_CMAP_COEFF,
                    center=0, linewidths=0.5, linecolor=_PALETTE["grid"],
                    ax=ax, cbar_kws={"label": "Coefficient β₁(τ)",
                                      "shrink": 0.8},
                    xticklabels=freq_labels,
                    yticklabels=[f"{q:.2f}" for q in coef_mat.index])
        ax.set_xlabel("Frequency Level", fontweight="bold")
        ax.set_ylabel("Quantile (τ)", fontweight="bold")
        ax.set_title(title or f"MFQR: {mfqr.x_name} → {mfqr.y_name}",
                     fontweight="bold", pad=15)

        plt.tight_layout()
        if save:
            fig.savefig(save, dpi=300, bbox_inches="tight",
                        facecolor=fig.get_facecolor())
        return fig, ax

    # ── Paper 2: MFQGC Heatmap ───────────────────────────────────────

    def plot_mfqgc_heatmap(self, mfqgc, title: str = None,
                           save: str = None):
        """
        Heatmap of MFQGC p-values with significance annotations.
        """
        pval_mat = mfqgc.pvalue_matrix()
        sig_mat = mfqgc.causality_matrix()

        fig, ax = plt.subplots(figsize=(max(8, pval_mat.shape[1] * 2), 10))
        _apply_dark_style(ax, fig)

        annot = pval_mat.copy().astype(str)
        for r in annot.index:
            for c in annot.columns:
                val = pval_mat.loc[r, c]
                star = sig_mat.loc[r, c] if (r, c) in sig_mat.stack().index else ""
                if pd.notna(star) and star:
                    annot.loc[r, c] = f"{val:.3f}{star}"
                else:
                    annot.loc[r, c] = f"{val:.3f}"

        freq_labels = [f"IMF{c}" for c in pval_mat.columns]

        sns.heatmap(pval_mat, annot=annot, fmt="", cmap=_CMAP_PVAL,
                    vmin=0, vmax=0.15, linewidths=0.5,
                    linecolor=_PALETTE["grid"], ax=ax,
                    cbar_kws={"label": "p-value", "shrink": 0.8},
                    xticklabels=freq_labels,
                    yticklabels=[f"{q:.2f}" for q in pval_mat.index])
        ax.set_xlabel("Frequency Level", fontweight="bold")
        ax.set_ylabel("Quantile (τ)", fontweight="bold")
        ax.set_title(title or f"MFQGC: {mfqgc.x_name} → {mfqgc.y_name}",
                     fontweight="bold", pad=15)

        plt.tight_layout()
        if save:
            fig.savefig(save, dpi=300, bbox_inches="tight",
                        facecolor=fig.get_facecolor())
        return fig, ax

    # ── EEMD Decomposition Plot ───────────────────────────────────────

    def plot_eemd(self, decomp: Dict, series_name: str = "Series",
                  save: str = None):
        """Panel plot of EEMD decomposition."""
        imfs = decomp["imfs"]
        residual = decomp["residual"]
        n_panels = imfs.shape[0] + 1
        fig, axes = plt.subplots(n_panels, 1, figsize=(14, 2.5 * n_panels),
                                 sharex=True)
        fig.patch.set_facecolor(_PALETTE["bg_dark"])

        colors = plt.cm.viridis(np.linspace(0.2, 0.9, imfs.shape[0]))

        for i in range(imfs.shape[0]):
            _apply_dark_style(axes[i], fig)
            axes[i].plot(imfs[i], color=colors[i], lw=1.2, alpha=0.9)
            axes[i].set_ylabel(f"IMF{i + 1}", fontweight="bold",
                              color=_PALETTE["text"])
            axes[i].axhline(0, color=_PALETTE["grid"], lw=0.5)

        _apply_dark_style(axes[-1], fig)
        axes[-1].plot(residual, color=_PALETTE["accent2"], lw=1.5)
        axes[-1].set_ylabel("Residual", fontweight="bold",
                           color=_PALETTE["text"])

        fig.suptitle(f"EEMD Decomposition — {series_name}", fontsize=16,
                     fontweight="bold", color=_PALETTE["text"], y=1.01)
        plt.tight_layout()

        if save:
            fig.savefig(save, dpi=300, bbox_inches="tight",
                        facecolor=fig.get_facecolor())
        return fig

    # ── Paper 3: Uncertain QAR Forecast ───────────────────────────────

    def plot_uncertain_forecast(self, uqar, data=None,
                                title: str = None, save: str = None):
        """
        Fan chart of uncertain QAR forecasts across quantiles.
        """
        fig, ax = plt.subplots(figsize=self.figsize)
        _apply_dark_style(ax, fig)

        results = uqar.results_
        quantiles = sorted(results.keys())
        forecasts = [results[s].forecast for s in quantiles]
        ci_lows = [results[s].confidence_interval[0] for s in quantiles]
        ci_highs = [results[s].confidence_interval[1] for s in quantiles]
        passed = [results[s].hypothesis_passed for s in quantiles]

        if data is not None:
            mids = np.mean(np.asarray(data), axis=1) if np.ndim(data) > 1 else data
            t = np.arange(len(mids))
            ax.plot(t, mids, color=_PALETTE["accent"], lw=1.5, alpha=0.8,
                    label="Observed (midpoints)")

        # Forecast points
        t_fc = len(mids) if data is not None else 0
        colors_q = plt.cm.coolwarm(np.linspace(0.1, 0.9, len(quantiles)))
        for i, (s, fc, lo, hi, ok) in enumerate(zip(quantiles, forecasts,
                                                       ci_lows, ci_highs, passed)):
            marker = "D" if ok else "x"
            label = f"s={s}" + (" ✓" if ok else " ✗")
            ax.errorbar(t_fc + i * 0.15, fc, yerr=[[fc - lo], [hi - fc]],
                        fmt=marker, color=colors_q[i], capsize=5,
                        markersize=8, label=label, lw=1.5)

        optimal = uqar.optimal_quantile()
        ax.axhline(results[optimal].forecast, color=_PALETTE["accent3"],
                   ls="--", lw=1, alpha=0.7,
                   label=f"Optimal (s={optimal})")

        ax.set_title(title or "Uncertain QAR — Multi-Quantile Forecast",
                     fontweight="bold", pad=15)
        ax.set_xlabel("Time")
        ax.set_ylabel("Value")
        ax.legend(fontsize=9, loc="upper left", framealpha=0.7,
                 facecolor=_PALETTE["bg_card"], edgecolor=_PALETTE["grid"],
                 labelcolor=_PALETTE["text"])

        plt.tight_layout()
        if save:
            fig.savefig(save, dpi=300, bbox_inches="tight",
                        facecolor=fig.get_facecolor())
        return fig, ax

    # ── QAR Model Summary Plot ────────────────────────────────────────

    def plot_qar_summary(self, models: Dict[float, "QARModel"],
                         title: str = None, save: str = None):
        """
        Plot QAR coefficients across quantiles.

        Parameters
        ----------
        models : dict[tau → QARModel]
        """
        fig, ax = plt.subplots(figsize=self.figsize)
        _apply_dark_style(ax, fig)

        taus = sorted(models.keys())
        all_lags = set()
        for m in models.values():
            all_lags.update(m.lags)
        all_lags = sorted(all_lags)

        colors = plt.cm.viridis(np.linspace(0.2, 0.9, len(all_lags)))
        for i, lag in enumerate(all_lags):
            coefs = [models[tau].coefficients.get(lag, 0.0) for tau in taus]
            ax.plot(taus, coefs, 'o-', color=colors[i], lw=2, markersize=6,
                    label=f"y(t-{lag})")

        ax.axhline(0, color=_PALETTE["grid"], lw=1)
        ax.set_xlabel("Quantile (τ)", fontweight="bold")
        ax.set_ylabel("Coefficient φ(τ)", fontweight="bold")
        ax.set_title(title or "QAR Coefficient Functions φ(τ)",
                     fontweight="bold", pad=15)
        ax.legend(fontsize=9, facecolor=_PALETTE["bg_card"],
                 edgecolor=_PALETTE["grid"], labelcolor=_PALETTE["text"])

        plt.tight_layout()
        if save:
            fig.savefig(save, dpi=300, bbox_inches="tight",
                        facecolor=fig.get_facecolor())
        return fig, ax
