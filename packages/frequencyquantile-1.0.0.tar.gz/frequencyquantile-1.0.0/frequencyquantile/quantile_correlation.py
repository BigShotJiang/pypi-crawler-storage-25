"""
Quantile Correlation (QCOR) and Quantile Partial Correlation (QPCOR)
=====================================================================

Implements Definitions (2.1) – (2.4) and Theorems 1 – 2 of
Li, Li & Tsai (2015, JASA 110:246-261).

References
----------
Li G., Li Y., Tsai C-L. (2015). "Quantile Correlations and Quantile
Autoregressive Modeling", *Journal of the American Statistical
Association*, 110(509): 246–261.
"""

import numpy as np
from .utils import psi_tau, quantile_regression, ols, add_intercept


# ── Population-level definitions (for documentation / small samples) ──

def qcov(Y: np.ndarray, X: np.ndarray, tau: float) -> float:
    """
    Sample quantile covariance (Eq. 2.1, numerator).

    qcov_τ{Y, X} = (1/n) Σ ψ_τ(Y_i − Q̂_τ,Y)(X_i − X̄)
    """
    Y, X = np.asarray(Y, float), np.asarray(X, float)
    Q_tau = np.quantile(Y, tau)
    return np.mean(psi_tau(Y - Q_tau, tau) * (X - X.mean()))


def qcor(Y: np.ndarray, X: np.ndarray, tau: float) -> float:
    """
    Sample quantile correlation (Eq. 2.1).

    qcor_τ{Y, X} = qcov_τ{Y,X} / √[(τ − τ²) · σ²_X]
    """
    return qcov(Y, X, tau) / np.sqrt((tau - tau ** 2) * np.var(X))


def qpcor(Y: np.ndarray, X: np.ndarray, Z: np.ndarray, tau: float) -> float:
    """
    Sample quantile partial correlation (Eq. 2.4).

    Controls for the linear effect of Z on both the τ-th quantile of Y
    and the mean of X.

    Parameters
    ----------
    Y : (n,) response
    X : (n,) variable of interest
    Z : (n, q) covariates to partial out
    tau : quantile level
    """
    Y = np.asarray(Y, float)
    X = np.asarray(X, float)
    Z = np.asarray(Z, float)
    if Z.ndim == 1:
        Z = Z.reshape(-1, 1)
    n = len(Y)

    Zstar = add_intercept(Z)

    # OLS of X on Z → residuals
    _, X_res = ols(X, Zstar)

    # Quantile regression of Y on Z
    beta_qr, Y_qres = quantile_regression(Y, Zstar, tau)

    sigma2_xz = np.mean(X_res ** 2)
    numerator = np.mean(psi_tau(Y_qres, tau) * X)
    return numerator / np.sqrt((tau - tau ** 2) * sigma2_xz)


# ── Convenience wrappers with standard-error output ───────────────────

def sample_qcor(Y: np.ndarray, X: np.ndarray, tau: float):
    """
    Compute sample QCOR with asymptotic standard error (Theorem 1).

    Returns
    -------
    dict with keys: 'qcor', 'se', 'z_stat', 'p_value'
    """
    from scipy.stats import norm as _norm

    Y, X = np.asarray(Y, float), np.asarray(X, float)
    n = len(Y)
    Q_tau = np.quantile(Y, tau)
    psi = psi_tau(Y - Q_tau, tau)
    mu_X = X.mean()
    sigma2_X = np.var(X)

    qcov_val = np.mean(psi * (X - mu_X))
    qcor_val = qcov_val / np.sqrt((tau - tau ** 2) * sigma2_X)

    # Nadaraya-Watson estimate of μ_{X|Y} = E(X | Y = Q_τ,Y)
    from scipy.stats import gaussian_kde
    try:
        joint = np.vstack([Y, X])
        kde_joint = gaussian_kde(joint)
        kde_y = gaussian_kde(Y)
        # E(X | Y ≈ Q_tau) via local averaging
        h = 1.06 * Y.std() * n ** (-1 / 5)
        w = np.exp(-0.5 * ((Y - Q_tau) / h) ** 2)
        w /= w.sum() + 1e-15
        mu_xy = np.sum(w * X)
    except Exception:
        mu_xy = mu_X

    Omega11 = np.mean((X - mu_X) ** 4) - sigma2_X ** 2
    Omega12 = np.mean((psi * (X - mu_xy)) ** 2) - qcov_val ** 2
    Omega13 = np.mean(psi * (X - mu_xy) * (X - mu_X) ** 2) - sigma2_X * qcov_val

    var_qcor = (1 / (tau - tau ** 2)) * (
        Omega11 * qcov_val ** 2 / (4 * sigma2_X ** 3)
        - Omega13 * qcov_val / sigma2_X ** 2
        + Omega12 / sigma2_X
    )
    se = np.sqrt(max(var_qcor, 0) / n)
    z = qcor_val / se if se > 0 else 0.0
    p = 2 * (1 - _norm.cdf(abs(z)))

    return {"qcor": qcor_val, "se": se, "z_stat": z, "p_value": p}


def sample_qpcor(Y: np.ndarray, X: np.ndarray, Z: np.ndarray, tau: float):
    """
    Compute sample QPCOR with asymptotic standard error (Theorem 2).

    Returns
    -------
    dict with keys: 'qpcor', 'se', 'z_stat', 'p_value'
    """
    from scipy.stats import norm as _norm

    qpcor_val = qpcor(Y, X, Z, tau)

    # Bootstrap SE (simpler and more robust than analytic Ω₂ formula)
    n = len(Y)
    B = 500
    boot_vals = np.empty(B)
    for b in range(B):
        idx = np.random.choice(n, n, replace=True)
        boot_vals[b] = qpcor(Y[idx], X[idx], Z[idx], tau)
    se = np.std(boot_vals, ddof=1)
    z = qpcor_val / se if se > 0 else 0.0
    p = 2 * (1 - _norm.cdf(abs(z)))

    return {"qpcor": qpcor_val, "se": se, "z_stat": z, "p_value": p}
