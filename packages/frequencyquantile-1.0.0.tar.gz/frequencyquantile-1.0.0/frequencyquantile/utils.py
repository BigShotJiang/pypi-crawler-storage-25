"""
Shared helpers used across the library.
"""

import numpy as np
from scipy.optimize import linprog


# ── Check-function and psi ────────────────────────────────────────────
def rho_tau(u: np.ndarray, tau: float) -> np.ndarray:
    """Quantile check function  ρ_τ(u) = u·[τ − I(u < 0)]."""
    return u * (tau - (u < 0).astype(float))


def psi_tau(u: np.ndarray, tau: float) -> np.ndarray:
    """Quantile score function  ψ_τ(u) = τ − I(u < 0)."""
    return tau - (u < 0).astype(float)


# ── Quantile regression via linear programming ────────────────────────
def quantile_regression(y: np.ndarray, X: np.ndarray, tau: float):
    """
    Solve quantile regression  min_β Σ ρ_τ(y_i − x_i'β)
    using the interior-point LP reformulation.

    Parameters
    ----------
    y : (n,) response vector
    X : (n, p) design matrix (**include** intercept column if wanted)
    tau : quantile level in (0, 1)

    Returns
    -------
    beta : (p,) coefficient vector
    residuals : (n,) vector  y − X @ beta
    """
    n, p = X.shape
    # LP:  min c'z  s.t. A_eq z = b_eq, z >= 0
    # z = [β+, β−, u+, u−]  with β = β+ − β−, resid = u+ − u−
    c = np.concatenate([np.zeros(2 * p), tau * np.ones(n), (1 - tau) * np.ones(n)])
    A_eq = np.hstack([X, -X, np.eye(n), -np.eye(n)])
    b_eq = y.copy()
    bounds = [(0, None)] * (2 * p + 2 * n)

    res = linprog(c, A_eq=A_eq, b_eq=b_eq, bounds=bounds, method="highs")
    if not res.success:
        raise RuntimeError(f"Quantile regression LP failed: {res.message}")

    beta = res.x[:p] - res.x[p:2 * p]
    residuals = y - X @ beta
    return beta, residuals


def ols(y: np.ndarray, X: np.ndarray):
    """Ordinary least-squares  (X'X)^{-1} X'y."""
    beta = np.linalg.lstsq(X, y, rcond=None)[0]
    return beta, y - X @ beta


# ── Density estimation (Hendricks–Koenker sandwich) ───────────────────
def bofinger_bandwidth(n: int, tau: float) -> float:
    """Bofinger (1975) bandwidth h_B for density estimation."""
    from scipy.stats import norm
    q = norm.ppf(tau)
    phi_q = norm.pdf(q)
    return n ** (-1 / 5) * (4.5 * phi_q ** 4 / (2 * q ** 2 + 1) ** 2) ** (1 / 5)


def hall_sheather_bandwidth(n: int, tau: float, alpha: float = 0.05) -> float:
    """Hall–Sheather (1988) bandwidth h_HS."""
    from scipy.stats import norm
    q = norm.ppf(tau)
    z_alpha = norm.ppf(1 - alpha / 2)
    phi_q = norm.pdf(q)
    return n ** (-1 / 3) * z_alpha ** (2 / 3) * (1.5 * phi_q ** 2 / (2 * q ** 2 + 1)) ** (1 / 3)


def estimate_density_at_zero(y: np.ndarray, X: np.ndarray, tau: float,
                             bandwidth_scale: float = 0.6,
                             bandwidth_kind: str = "bofinger") -> np.ndarray:
    """
    Hendricks–Koenker (1992) difference-quotient density estimator.

    Returns f̂_{t-1}(0)  for each observation.
    """
    n = X.shape[0]
    if bandwidth_kind == "bofinger":
        h = bandwidth_scale * bofinger_bandwidth(n, tau)
    else:
        h = bandwidth_scale * hall_sheather_bandwidth(n, tau)

    tau_lo = max(tau - h, 0.01)
    tau_hi = min(tau + h, 0.99)

    beta_lo, _ = quantile_regression(y, X, tau_lo)
    beta_hi, _ = quantile_regression(y, X, tau_hi)

    q_lo = X @ beta_lo
    q_hi = X @ beta_hi
    denom = q_hi - q_lo
    denom[denom == 0] = 1e-10
    return 2 * h / denom


# ── Misc ──────────────────────────────────────────────────────────────
def add_intercept(X: np.ndarray) -> np.ndarray:
    """Prepend a column of ones to X."""
    n = X.shape[0] if X.ndim > 1 else len(X)
    return np.column_stack([np.ones(n), X])


def ensure_2d(arr: np.ndarray) -> np.ndarray:
    arr = np.asarray(arr, dtype=float)
    if arr.ndim == 1:
        arr = arr.reshape(-1, 1)
    return arr
