"""
frequencyquantile — Multi-Frequency Quantile Econometrics Toolkit
=================================================================

A unified Python library implementing three families of quantile methods:

1. **Quantile Correlations & QAR Modeling** (Li, Li & Tsai, 2015, JASA)
   - QCOR, QPCOR, QPACF, QACF, modified Box-Jenkins procedure

2. **Multi-Frequency Quantile Regression & Causality** (Adebayo, 2026, Applied Economics)
   - MFQR and MFQGC via EEMD decomposition

3. **Uncertain Quantile Autoregressive Model** (Shi & Sheng, 2025, Comm. Stat.)
   - QAR under uncertainty theory with hypothesis testing

Author : Dr Merwan Roudane
Email  : merwanroudane920@gmail.com
GitHub : https://github.com/merwanroudane/frequencyquantile
License: MIT
"""

__version__ = "1.0.0"
__author__ = "Dr Merwan Roudane"
__email__ = "merwanroudane920@gmail.com"

# ── Paper 1: Quantile Correlations & QAR ──────────────────────────────
from .quantile_correlation import (
    qcov,
    qcor,
    qpcor,
    sample_qcor,
    sample_qpcor,
)
from .qar import (
    QARModel,
    qpacf,
    qacf,
    qbp_test,
    three_stage_procedure,
)

# ── Paper 2: Multi-Frequency Quantile Methods ─────────────────────────
from .decomposition import eemd_decompose
from .mfqr import MFQR
from .mfqgc import MFQGC

# ── Paper 3: Uncertain QAR ────────────────────────────────────────────
from .uncertain_qar import UncertainQAR

# ── Visualisation & Tables ────────────────────────────────────────────
from .visualization import FrequencyQuantilePlotter
from .tables import FrequencyQuantileTable

__all__ = [
    # Paper 1
    "qcov", "qcor", "qpcor", "sample_qcor", "sample_qpcor",
    "QARModel", "qpacf", "qacf", "qbp_test", "three_stage_procedure",
    # Paper 2
    "eemd_decompose", "MFQR", "MFQGC",
    # Paper 3
    "UncertainQAR",
    # Viz & Tables
    "FrequencyQuantilePlotter", "FrequencyQuantileTable",
]
