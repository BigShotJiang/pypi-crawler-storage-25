"""
Ensemble Empirical Mode Decomposition (EEMD) wrapper
====================================================

Provides a clean interface to PyEMD's EEMD for decomposing time series
into Intrinsic Mode Functions (IMFs) at different frequency levels.

Based on: Wu Z., Huang N.E. (2009). "Ensemble Empirical Mode
Decomposition: A Noise-Assisted Data Analysis Method",
*Advances in Adaptive Data Analysis*, 1(1): 1-41.
"""

import numpy as np
import pandas as pd
from typing import Optional, Dict, List


def eemd_decompose(series: np.ndarray,
                   n_imfs: Optional[int] = None,
                   noise_width: float = 0.05,
                   n_trials: int = 100,
                   random_seed: int = 42) -> Dict:
    """
    Decompose a time series into IMFs via EEMD.

    Parameters
    ----------
    series : 1-D array
    n_imfs : number of IMFs to keep (None = all)
    noise_width : standard deviation of added Gaussian noise
    n_trials : number of EEMD ensemble trials
    random_seed : for reproducibility

    Returns
    -------
    dict with:
        'imfs'     : (K, n) array of IMFs (high→low frequency)
        'residual' : (n,) residual trend
        'n_imfs'   : number of IMFs
        'labels'   : list of labels ['IMF1', ..., 'IMFk', 'Residual']
    """
    from PyEMD import EEMD

    series = np.asarray(series, dtype=float)
    t = np.arange(len(series))

    eemd = EEMD(trials=n_trials, noise_width=noise_width)
    eemd.noise_seed(random_seed)
    # Use single-process mode to avoid Windows multiprocessing spawn issues
    eemd.parallel = False
    eemd.processes = 1

    imfs = eemd.eemd(series, t)

    if n_imfs is not None and n_imfs < imfs.shape[0]:
        # Keep first n_imfs, collapse remainder into residual
        kept = imfs[:n_imfs]
        residual = imfs[n_imfs:].sum(axis=0)
    else:
        kept = imfs[:-1]  # all except last
        residual = imfs[-1]
        n_imfs = kept.shape[0]

    labels = [f"IMF{i + 1}" for i in range(kept.shape[0])] + ["Residual"]

    return {
        "imfs": kept,
        "residual": residual,
        "n_imfs": kept.shape[0],
        "labels": labels,
    }


def decompose_dataframe(df: pd.DataFrame,
                        columns: Optional[List[str]] = None,
                        n_imfs: int = 5,
                        **kwargs) -> Dict[str, Dict]:
    """
    Decompose multiple columns of a DataFrame via EEMD.

    Parameters
    ----------
    df : DataFrame with time-series columns
    columns : columns to decompose (None = all numeric)
    n_imfs : number of IMFs per variable

    Returns
    -------
    dict[column_name → EEMD result dict]
    """
    if columns is None:
        columns = df.select_dtypes(include=[np.number]).columns.tolist()

    results = {}
    for col in columns:
        results[col] = eemd_decompose(df[col].dropna().values,
                                      n_imfs=n_imfs, **kwargs)
    return results
