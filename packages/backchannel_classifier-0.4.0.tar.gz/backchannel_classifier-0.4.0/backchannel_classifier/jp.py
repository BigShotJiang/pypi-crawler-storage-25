"""
Japanese Backchannel (Aizuchi) Classifier
Usage: from backchannel_classifier.jp import is_backchannel_ja
"""

import re
import pickle
import numpy as np
import os

_MODEL = None
_DIR = os.path.dirname(os.path.abspath(__file__))


def extract_features_ja(text):
    """Extract features from Japanese text for aizuchi detection"""
    text = text.strip()
    char_len = len(text)

    # Count Japanese characters (hiragana + katakana + kanji)
    hiragana = len(re.findall(r'[\u3040-\u309F]', text))
    katakana = len(re.findall(r'[\u30A0-\u30FF]', text))
    kanji = len(re.findall(r'[\u4E00-\u9FFF]', text))
    jp_chars = hiragana + katakana + kanji

    # Word-like segments (split on spaces — ASR output is usually space-separated)
    words = text.split()
    word_count = len(words)

    # === Backchannel markers (positive indicators) ===

    # Core acknowledgment: はい, ええ, うん
    has_hai = 1 if re.search(r'はい|はーい|はいはい', text) else 0
    has_ee = 1 if re.search(r'ええ|えぇ', text) else 0
    has_un = 1 if re.search(r'うん|うんうん', text) else 0

    # Agreement: そう, そうですね, そうだね, そっか
    has_sou = 1 if re.search(r'そう(?:です(?:ね|か|よね)|だね|だよね|ね|そう|なんだ|なんですね)?|そっか', text) else 0

    # Understanding: なるほど
    has_naruhodo = 1 if re.search(r'なるほど', text) else 0

    # Surprise/reaction sounds: へー, ほー, えー (standalone)
    has_hee = 1 if re.search(r'へー+|へぇ+|ほー+|ほぉ+', text) else 0
    has_e_surprise = 1 if re.search(r'^えー+$|^えぇ+$|^えっ$', text) else 0

    # Filler/hesitation: えーと, あのー, うーん, んー, あー
    has_filler = 1 if re.search(r'えー?と|えっと|あのー?|うー+ん|んー+|あー+|まあ|まぁ|そのー?|なんか|なんていうか', text) else 0

    # Emotional reaction: すごい, やばい, ほんと, まじ, うそ
    has_reaction = 1 if re.search(r'すご(?:い|ーい|いね|いですね)|やば(?:い|っ)|ほんと(?:う|に|ですか)?|まじ(?:で|っすか)?|マジ(?:で)?|うそ(?:ー)?|うっそ', text) else 0

    # Empathy: よかった, たいへん, 大丈夫, かわいそう, 残念
    has_empathy = 1 if re.search(r'よかった(?:ですね|ね)?|たいへん(?:ですね)?|大丈夫(?:です)?|かわいそう|残念(?:ですね)?', text) else 0

    # Standalone particles as backchannels: ね, よね, だよね, ですよね, でしょ
    has_particle_bc = 1 if re.search(r'^(?:ね|ねー+|よね|だよね|ですよね|でしょ|でしょう|だね|ですね)$', text) else 0

    # Informal: ふーん, あっそ, っす, っすね, じゃん
    has_informal = 1 if re.search(r'ふー+ん|あっそ|っす(?:ね)?$|じゃん$|なー$|ガチ(?:で)?', text) else 0

    # Polite acknowledgment: わかりました, 承知しました, かしこまりました
    has_polite_ack = 1 if re.search(r'わかりました|わかった|承知(?:しました|いたしました)|かしこまりました', text) else 0

    # === Negative indicators (NOT backchannel) ===

    # Question words: 何, どこ, いつ, なぜ, どう, 誰, いくつ, いくら
    has_question = 1 if re.search(r'何|どこ|いつ|なぜ|どう(?:して|やって|いう)|誰|いく(?:つ|ら)|どれ|どの|どちら|ですか$', text) else 0

    # Conjunctions continuing thought: でも, しかし, それで, だから, けど, ただ, が
    has_continuation = 1 if re.search(r'でも|しかし|それで|だから|けど|ただ|ですが|だけど|それから|あと(?!ー)', text) else 0

    # Request/command: ください, ましょう, たい, ほしい, お願い
    has_request = 1 if re.search(r'ください|ましょう|(?:し|き|み|い)たい(?:です)?|ほしい|お願い|してほしい|教えて|頼む', text) else 0

    # Negation: ない, ません, いいえ, 違う, いや
    has_negation = 1 if re.search(r'ない(?:です)?$|ません|いいえ|違(?:う|います)|いや(?!ー)|じゃない', text) else 0

    # Has verb endings (polite/dictionary form) suggesting real content
    has_verb = 1 if re.search(r'ます$|ました$|ません$|する$|した$|できる|できます|あります|います|思います|考え', text) else 0

    # Has kanji content (real responses tend to have more kanji)
    kanji_ratio = kanji / max(char_len, 1)

    # === Remaining ratio (key feature) ===
    remaining = text
    for pattern in [
        # Core aizuchi
        'はい', 'ええ', 'うん', 'うんうん', 'はいはい',
        # Agreement
        'そうですね', 'そうですか', 'そうだね', 'そうだよね', 'そうなんだ', 'そうなんですね',
        'そうそう', 'そうね', 'そっか', 'そう',
        # Understanding
        'なるほど', 'なるほどね', 'なるほどですね',
        'わかりました', 'わかった', '分かります',
        'あぁそうか', 'あそっか',
        # Surprise
        'へー', 'へぇ', 'ほー', 'ほぉ', 'えー', 'えぇ', 'えっ',
        # Fillers
        'えーと', 'えっと', 'あのー', 'あの', 'うーん', 'んー', 'あー',
        'まあ', 'まぁ', 'そのー', 'その', 'なんか',
        # Reaction
        'すごい', 'すごいね', 'すごいですね', 'やばい', 'やばっ',
        'ほんと', 'ほんとう', 'ほんとに', 'ほんとですか',
        'まじ', 'まじで', 'マジ', 'マジで',
        'うそ', 'うっそ', 'うそー',
        # Empathy
        'よかった', 'よかったね', 'よかったですね',
        'たいへん', 'たいへんですね',
        '大丈夫', '大丈夫です',
        'かわいそう', '残念', '残念ですね',
        # Particles
        'ね', 'ねー', 'よね', 'だよね', 'ですよね', 'でしょ', 'でしょう',
        'だね', 'ですね', 'です', 'よ',
        # Informal
        'ふーん', 'あっそ', 'っす', 'っすね', 'じゃん', 'なー',
        'ガチ', 'ガチで',
        # Polite
        '承知しました', '承知いたしました', 'かしこまりました',
        # Connectors (neutral)
        'ああ', 'あぁ', 'あ',
        # Elongation marks
        'ー',
        ' ',
    ]:
        remaining = remaining.replace(pattern, '')
    # Also strip elongated vowels via regex
    remaining = re.sub(r'ー+', '', remaining)
    remaining = re.sub(r'っ+', '', remaining)
    remaining_len = len(remaining)
    remaining_ratio = remaining_len / max(char_len, 1)

    return np.array([
        char_len, jp_chars, word_count,
        hiragana, katakana, kanji,
        has_hai, has_ee, has_un,
        has_sou, has_naruhodo,
        has_hee, has_e_surprise, has_filler,
        has_reaction, has_empathy,
        has_particle_bc, has_informal, has_polite_ack,
        has_question, has_continuation, has_request,
        has_negation, has_verb,
        kanji_ratio, remaining_len, remaining_ratio,
    ])


FEATURE_NAMES_JA = [
    'char_len', 'jp_chars', 'word_count',
    'hiragana', 'katakana', 'kanji',
    'has_hai', 'has_ee', 'has_un',
    'has_sou', 'has_naruhodo',
    'has_hee', 'has_e_surprise', 'has_filler',
    'has_reaction', 'has_empathy',
    'has_particle_bc', 'has_informal', 'has_polite_ack',
    'has_question', 'has_continuation', 'has_request',
    'has_negation', 'has_verb',
    'kanji_ratio', 'remaining_len', 'remaining_ratio',
]


def _load_model_ja():
    global _MODEL
    if _MODEL is None:
        import warnings
        pkl_path = os.path.join(_DIR, 'backchannel_model_ja.pkl')
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                with open(pkl_path, 'rb') as f:
                    data = pickle.load(f)
                _MODEL = data['model']
                # verify it works with current sklearn
                test_features = extract_features_ja("はい").reshape(1, -1)
                _MODEL.predict(test_features)
        except Exception:
            _MODEL = _retrain_model_ja(pkl_path)
    return _MODEL


def _retrain_model_ja(pkl_path):
    """Retrain Japanese model from inline data when pkl is incompatible"""
    import random
    from sklearn.ensemble import GradientBoostingClassifier

    import importlib.util
    train_path = os.path.join(os.path.dirname(_DIR), 'train_ja.py')
    if os.path.exists(train_path):
        spec = importlib.util.spec_from_file_location("train_ja_module", train_path)
        train_mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(train_mod)
        pos_examples = train_mod.augment_backchannels_ja(train_mod.BACKCHANNELS_JA)
        neg_examples = list(train_mod.REAL_RESPONSES_JA)
    else:
        raise RuntimeError("Cannot retrain: train_ja.py not found alongside package")

    random.seed(42)
    X_pos = np.array([extract_features_ja(t) for t in pos_examples])
    X_neg = np.array([extract_features_ja(t) for t in neg_examples])
    X = np.vstack([X_pos, X_neg])
    y = np.array([1] * len(pos_examples) + [0] * len(neg_examples))
    indices = list(range(len(X)))
    random.shuffle(indices)
    X = X[indices]
    y = y[indices]

    model = GradientBoostingClassifier(n_estimators=100, max_depth=4, random_state=42)
    model.fit(X, y)

    try:
        with open(pkl_path, 'wb') as f:
            pickle.dump({'model': model, 'feature_names': FEATURE_NAMES_JA}, f)
    except Exception:
        pass

    return model


def is_backchannel_ja(text: str, threshold: float = 0.5) -> tuple:
    """
    Detect if Japanese text is a backchannel (aizuchi).

    Returns: (is_backchannel: bool, confidence: float)
    """
    if not text or not text.strip():
        return False, 0.0

    model = _load_model_ja()
    features = extract_features_ja(text).reshape(1, -1)
    prob = model.predict_proba(features)[0]
    bc_prob = prob[1]
    return bc_prob >= threshold, float(bc_prob)


if __name__ == '__main__':
    import sys
    if len(sys.argv) > 1:
        text = ' '.join(sys.argv[1:])
        is_bc, conf = is_backchannel_ja(text)
        print(f"'{text}' -> {'BACKCHANNEL' if is_bc else 'REAL RESPONSE'} (confidence: {conf:.4f})")
    else:
        print("Japanese Backchannel (Aizuchi) Detector - type text to classify (ctrl+c to exit)")
        while True:
            try:
                text = input("> ")
                is_bc, conf = is_backchannel_ja(text)
                label = "BACKCHANNEL" if is_bc else "REAL RESPONSE"
                print(f"  -> {label} (confidence: {conf:.4f})")
            except (KeyboardInterrupt, EOFError):
                break
