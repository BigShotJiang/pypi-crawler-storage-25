"""
comprehensive test suite for thai backchannel classifier.
run: python -m pytest tests/ -v
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from detect import is_backchannel

# === backchannel (should be True) ===

class TestBackchannels:
    """inputs that should be classified as backchannels"""

    # basic polite particles
    def test_krab(self): assert is_backchannel("ครับ")[0] == True
    def test_krab_repeat(self): assert is_backchannel("ครับๆ")[0] == True
    def test_krab_space_repeat(self): assert is_backchannel("ครับ ๆ")[0] == True
    def test_ka(self): assert is_backchannel("ค่ะ")[0] == True
    def test_ka_repeat(self): assert is_backchannel("ค่ะๆ")[0] == True
    def test_kub(self): assert is_backchannel("คับ")[0] == True
    def test_ka_variant(self): assert is_backchannel("คะ")[0] == True
    def test_ka_variant2(self): assert is_backchannel("ค่า")[0] == True
    def test_ja(self): assert is_backchannel("จ้ะ")[0] == True
    def test_jaa(self): assert is_backchannel("จ้า")[0] == True

    # dai + particle
    def test_dai_krab(self): assert is_backchannel("ได้ครับ")[0] == True
    def test_dai_ka(self): assert is_backchannel("ได้ค่ะ")[0] == True
    def test_dai_ka2(self): assert is_backchannel("ได้คะ")[0] == True
    def test_dai_ja(self): assert is_backchannel("ได้จ้ะ")[0] == True

    # filler sounds
    def test_hmm(self): assert is_backchannel("อืม")[0] == True
    def test_hmm_repeat(self): assert is_backchannel("อืมๆ")[0] == True
    def test_ue(self): assert is_backchannel("อือ")[0] == True
    def test_ueo(self): assert is_backchannel("อื้อ")[0] == True
    def test_er(self): assert is_backchannel("เออ")[0] == True
    def test_er2(self): assert is_backchannel("เอ่อ")[0] == True
    def test_ah(self): assert is_backchannel("อ่า")[0] == True
    def test_aha_krab(self): assert is_backchannel("อ่าฮะ ครับ")[0] == True
    def test_aha_ka(self): assert is_backchannel("อ่าฮะ ค่ะ")[0] == True

    # oh
    def test_oh(self): assert is_backchannel("อ๋อ")[0] == True
    def test_oh_krab(self): assert is_backchannel("อ๋อครับ")[0] == True
    def test_oh_ka(self): assert is_backchannel("อ๋อค่ะ")[0] == True
    def test_oh_space_krab(self): assert is_backchannel("อ๋อ ครับ")[0] == True

    # agreement
    def test_chai(self): assert is_backchannel("ใช่")[0] == True
    def test_chai_repeat(self): assert is_backchannel("ใช่ๆ")[0] == True
    def test_chai_triple(self): assert is_backchannel("ใช่ๆๆ")[0] == True
    def test_chai_krab(self): assert is_backchannel("ใช่ครับ")[0] == True
    def test_chai_ka(self): assert is_backchannel("ใช่ค่ะ")[0] == True
    def test_chaai(self): assert is_backchannel("ช่าย")[0] == True
    def test_jing(self): assert is_backchannel("จริง")[0] == True
    def test_jing_krab(self): assert is_backchannel("จริงครับ")[0] == True
    def test_jing_duay(self): assert is_backchannel("จริงด้วย")[0] == True
    def test_thuk(self): assert is_backchannel("ถูก")[0] == True
    def test_thuk_krab(self): assert is_backchannel("ถูกครับ")[0] == True
    def test_naenon(self): assert is_backchannel("แน่นอน")[0] == True

    # ok variants
    def test_ok_krab(self): assert is_backchannel("โอเคครับ")[0] == True
    def test_ok_ka(self): assert is_backchannel("โอเคค่ะ")[0] == True

    # question-like backchannels
    def test_reu(self): assert is_backchannel("เหรอ")[0] == True
    def test_ror(self): assert is_backchannel("หรอ")[0] == True
    def test_ngan_reu(self): assert is_backchannel("งั้นเหรอ")[0] == True

    # compound backchannels
    def test_krab_hello(self): assert is_backchannel("ครับ ฮัลโหล")[0] == True
    def test_krab_hello2(self): assert is_backchannel("ครับฮัลโหล")[0] == True
    def test_hello(self): assert is_backchannel("ฮัลโหล")[0] == True
    def test_krab_phom(self): assert is_backchannel("ครับผม")[0] == True
    def test_ah_chai(self): assert is_backchannel("อ่ะ ใช่ๆๆ")[0] == True

    # asr tone/vowel variants
    def test_hmm_tone(self): assert is_backchannel("อื้ม")[0] == True
    def test_ah_long(self): assert is_backchannel("อ๊าา")[0] == True
    def test_ah_tone(self): assert is_backchannel("อ้า")[0] == True
    def test_ah_tone2(self): assert is_backchannel("อ๊า")[0] == True
    def test_uem(self): assert is_backchannel("อึม")[0] == True


# === real responses (should be False) ===

class TestRealResponses:
    """inputs that should NOT be classified as backchannels"""

    # greetings
    def test_sawasdee_krab(self): assert is_backchannel("สวัสดีครับ")[0] == False
    def test_sawasdee_ka(self): assert is_backchannel("สวัสดีค่ะ")[0] == False
    def test_thanks_krab(self): assert is_backchannel("ขอบคุณครับ")[0] == False
    def test_thanks_ka(self): assert is_backchannel("ขอบคุณค่ะ")[0] == False
    def test_thanks_mak(self): assert is_backchannel("ขอบคุณมากครับ")[0] == False

    # negations
    def test_mai_krab(self): assert is_backchannel("ไม่ครับ")[0] == False
    def test_mai_ka(self): assert is_backchannel("ไม่ค่ะ")[0] == False
    def test_mai_chai_krab(self): assert is_backchannel("ไม่ใช่ครับ")[0] == False
    def test_mai_chai_ka(self): assert is_backchannel("ไม่ใช่ค่ะ")[0] == False
    def test_yang_krab(self): assert is_backchannel("ยังครับ")[0] == False
    def test_mai_ao(self): assert is_backchannel("ไม่เอาครับ")[0] == False

    # questions
    def test_taorai(self): assert is_backchannel("ราคาเท่าไหร่ครับ")[0] == False
    def test_tonmai(self): assert is_backchannel("ทำไมครับ")[0] == False
    def test_arai(self): assert is_backchannel("อะไรครับ")[0] == False
    def test_tinai(self): assert is_backchannel("ที่ไหนครับ")[0] == False
    def test_yangngai(self): assert is_backchannel("ยังไงครับ")[0] == False
    def test_muarai(self): assert is_backchannel("เมื่อไหร่ครับ")[0] == False
    def test_gimong(self): assert is_backchannel("กี่โมงครับ")[0] == False

    # requests
    def test_booking(self): assert is_backchannel("ผมต้องการจองตั๋วครับ")[0] == False
    def test_price_ask(self): assert is_backchannel("อยากสอบถามเรื่องราคาค่ะ")[0] == False
    def test_check(self): assert is_backchannel("ช่วยเช็คให้หน่อยได้ไหมครับ")[0] == False
    def test_room(self): assert is_backchannel("มีห้องว่างไหมครับ")[0] == False
    def test_cancel(self): assert is_backchannel("อยากยกเลิกการจองค่ะ")[0] == False
    def test_receipt(self): assert is_backchannel("ขอใบเสร็จด้วยครับ")[0] == False
    def test_manager(self): assert is_backchannel("ขอคุยกับผู้จัดการหน่อยได้ไหมครับ")[0] == False
    def test_help(self): assert is_backchannel("ช่วยด้วยครับ")[0] == False

    # backchannel + continuation (tricky edge cases)
    def test_chai_taewar(self): assert is_backchannel("ใช่ แต่ว่า")[0] == False
    def test_krab_laewkor(self): assert is_backchannel("ครับ แล้วก็")[0] == False
    def test_ka_tae(self): assert is_backchannel("ค่ะ แต่ขอถามอีกอย่าง")[0] == False
    def test_dai_tae(self): assert is_backchannel("ได้ครับ แต่ขอเปลี่ยนวัน")[0] == False
    def test_jing_tae(self): assert is_backchannel("จริงครับ แต่ผมคิดว่า")[0] == False
    def test_thuk_tae(self): assert is_backchannel("ถูกค่ะ แต่มีอีกเรื่อง")[0] == False
    def test_oh_laew(self): assert is_backchannel("อ๋อ แล้วเรื่องที่สอง")[0] == False
    def test_hmm_tae(self): assert is_backchannel("อืม แต่ว่าผมไม่แน่ใจ")[0] == False
    def test_er_laew(self): assert is_backchannel("เออ แล้วอีกอย่าง")[0] == False
    def test_ok_ngan(self): assert is_backchannel("โอเค งั้นผมขอ")[0] == False
    def test_dai_laew(self): assert is_backchannel("ได้ แล้วเรื่องราคา")[0] == False
    def test_chai_laew(self): assert is_backchannel("ใช่ แล้วอีกอย่าง")[0] == False

    # short real responses
    def test_mai(self): assert is_backchannel("ไม่")[0] == False
    def test_yang(self): assert is_backchannel("ยัง")[0] == False
    def test_ao(self): assert is_backchannel("เอา")[0] == False
    def test_dai_loei(self): assert is_backchannel("ได้เลย")[0] == False
    def test_ok_dai(self): assert is_backchannel("โอเค ได้เลยครับ")[0] == False
    def test_toklong(self): assert is_backchannel("ตกลงค่ะ")[0] == False
    def test_ao_loei(self): assert is_backchannel("เอาเลยครับ")[0] == False
    def test_mai_pen_rai(self): assert is_backchannel("ไม่เป็นไรครับ")[0] == False

    # medium-length real content
    def test_twin_room(self): assert is_backchannel("ผมอยากได้ห้องเตียงคู่ครับ")[0] == False
    def test_breakfast(self): assert is_backchannel("มีอาหารเช้ารวมด้วยไหมครับ")[0] == False
    def test_checkin(self): assert is_backchannel("เช็คอินกี่โมงครับ")[0] == False
    def test_credit(self): assert is_backchannel("จ่ายผ่านบัตรเครดิตได้ไหมครับ")[0] == False
    def test_package(self): assert is_backchannel("แพ็คเกจนี้รวมอะไรบ้างครับ")[0] == False
    def test_payment(self): assert is_backchannel("มีปัญหาเรื่องการชำระเงินค่ะ")[0] == False


# === confidence checks ===

class TestConfidence:
    """confidence should be high for clear cases"""

    def test_krab_high_conf(self):
        _, conf = is_backchannel("ครับ")
        assert conf > 0.9

    def test_real_low_conf(self):
        _, conf = is_backchannel("ผมต้องการจองตั๋วครับ")
        assert conf < 0.1

    def test_hmm_high_conf(self):
        _, conf = is_backchannel("อืม")
        assert conf > 0.9

    def test_question_low_conf(self):
        _, conf = is_backchannel("ราคาเท่าไหร่ครับ")
        assert conf < 0.1


# === edge cases ===

class TestEdgeCases:
    """empty/whitespace/unusual inputs"""

    def test_empty(self): assert is_backchannel("")[0] == False
    def test_space(self): assert is_backchannel("  ")[0] == False
    def test_whitespace_krab(self): assert is_backchannel(" ครับ ")[0] == True
    def test_whitespace_real(self): assert is_backchannel(" ไม่ครับ ")[0] == False
