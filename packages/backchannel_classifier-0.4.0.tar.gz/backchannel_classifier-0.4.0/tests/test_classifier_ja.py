"""
comprehensive test suite for japanese backchannel (aizuchi) classifier.
run: python3 -m pytest tests/test_classifier_ja.py -v
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from backchannel_classifier.jp import is_backchannel_ja


# === aizuchi (should be True) ===

class TestAizuchi:
    """inputs that should be classified as aizuchi (backchannels)"""

    # core acknowledgment
    def test_hai(self): assert is_backchannel_ja("はい")[0] == True
    def test_hai_hai(self): assert is_backchannel_ja("はいはい")[0] == True
    def test_haai(self): assert is_backchannel_ja("はーい")[0] == True
    def test_ee(self): assert is_backchannel_ja("ええ")[0] == True
    def test_un(self): assert is_backchannel_ja("うん")[0] == True
    def test_un_un(self): assert is_backchannel_ja("うんうん")[0] == True

    # agreement: そう variants
    def test_sou(self): assert is_backchannel_ja("そう")[0] == True
    def test_sou_sou(self): assert is_backchannel_ja("そうそう")[0] == True
    def test_sou_desu_ne(self): assert is_backchannel_ja("そうですね")[0] == True
    def test_sou_desu_ka(self): assert is_backchannel_ja("そうですか")[0] == True
    def test_sou_nan_da(self): assert is_backchannel_ja("そうなんだ")[0] == True
    def test_sou_nan_desu_ne(self): assert is_backchannel_ja("そうなんですね")[0] == True
    def test_sou_da_ne(self): assert is_backchannel_ja("そうだね")[0] == True
    def test_sou_da_yo_ne(self): assert is_backchannel_ja("そうだよね")[0] == True
    def test_sokka(self): assert is_backchannel_ja("そっか")[0] == True

    # understanding
    def test_naruhodo(self): assert is_backchannel_ja("なるほど")[0] == True
    def test_naruhodo_ne(self): assert is_backchannel_ja("なるほどね")[0] == True
    def test_aa(self): assert is_backchannel_ja("ああ")[0] == True
    def test_aa_naruhodo(self): assert is_backchannel_ja("ああなるほど")[0] == True
    def test_wakarimashita(self): assert is_backchannel_ja("わかりました")[0] == True
    def test_wakatta(self): assert is_backchannel_ja("わかった")[0] == True

    # surprise / reaction
    def test_hee(self): assert is_backchannel_ja("へー")[0] == True
    def test_hee_long(self): assert is_backchannel_ja("へぇー")[0] == True
    def test_hoo(self): assert is_backchannel_ja("ほー")[0] == True
    def test_ee_surprise(self): assert is_backchannel_ja("えー")[0] == True
    def test_honto(self): assert is_backchannel_ja("ほんと")[0] == True
    def test_honto_ni(self): assert is_backchannel_ja("ほんとに")[0] == True
    def test_maji(self): assert is_backchannel_ja("まじ")[0] == True
    def test_majide(self): assert is_backchannel_ja("まじで")[0] == True
    def test_maji_katakana(self): assert is_backchannel_ja("マジで")[0] == True
    def test_uso(self): assert is_backchannel_ja("うそ")[0] == True

    # fillers
    def test_eeto(self): assert is_backchannel_ja("えーと")[0] == True
    def test_etto(self): assert is_backchannel_ja("えっと")[0] == True
    def test_ano(self): assert is_backchannel_ja("あのー")[0] == True
    def test_uun(self): assert is_backchannel_ja("うーん")[0] == True
    def test_nn(self): assert is_backchannel_ja("んー")[0] == True
    def test_aa_filler(self): assert is_backchannel_ja("あー")[0] == True
    def test_maa(self): assert is_backchannel_ja("まあ")[0] == True

    # emotional reaction
    def test_sugoi(self): assert is_backchannel_ja("すごい")[0] == True
    def test_sugoi_ne(self): assert is_backchannel_ja("すごいね")[0] == True
    def test_yabai(self): assert is_backchannel_ja("やばい")[0] == True
    def test_yokatta(self): assert is_backchannel_ja("よかった")[0] == True
    def test_yokatta_ne(self): assert is_backchannel_ja("よかったね")[0] == True
    def test_zannen(self): assert is_backchannel_ja("残念")[0] == True

    # standalone particles
    def test_ne(self): assert is_backchannel_ja("ね")[0] == True
    def test_ne_long(self): assert is_backchannel_ja("ねー")[0] == True
    def test_yone(self): assert is_backchannel_ja("よね")[0] == True
    def test_da_yo_ne(self): assert is_backchannel_ja("だよね")[0] == True
    def test_desu_yo_ne(self): assert is_backchannel_ja("ですよね")[0] == True
    def test_desho(self): assert is_backchannel_ja("でしょ")[0] == True

    # informal
    def test_fuun(self): assert is_backchannel_ja("ふーん")[0] == True
    def test_asso(self): assert is_backchannel_ja("あっそ")[0] == True
    def test_ssu_ne(self): assert is_backchannel_ja("っすね")[0] == True

    # polite formal
    def test_shouchi(self): assert is_backchannel_ja("承知しました")[0] == True
    def test_kashikomari(self): assert is_backchannel_ja("かしこまりました")[0] == True

    # compound aizuchi
    def test_a_sou_nan_da(self): assert is_backchannel_ja("あ、そうなんだ")[0] == True
    def test_hee_sou_desu_ka(self): assert is_backchannel_ja("へー、そうなんですか")[0] == True
    def test_ee_sou_desu_ne(self): assert is_backchannel_ja("ええ、そうですね")[0] == True
    def test_hai_wakarimashita(self): assert is_backchannel_ja("はい、わかりました")[0] == True

    # ASR elongation
    def test_haai_long(self): assert is_backchannel_ja("はーーい")[0] == True
    def test_eee_long(self): assert is_backchannel_ja("えーーー")[0] == True
    def test_hee_long2(self): assert is_backchannel_ja("へーーー")[0] == True


# === real responses (should be False) ===

class TestRealResponses:
    """inputs that should NOT be classified as aizuchi"""

    # greetings
    def test_ohayou(self): assert is_backchannel_ja("おはようございます")[0] == False
    def test_konnichiwa(self): assert is_backchannel_ja("こんにちは")[0] == False
    def test_arigatou(self): assert is_backchannel_ja("ありがとうございます")[0] == False
    def test_sumimasen(self): assert is_backchannel_ja("すみません")[0] == False
    def test_yoroshiku(self): assert is_backchannel_ja("よろしくお願いします")[0] == False

    # negations
    def test_iie(self): assert is_backchannel_ja("いいえ")[0] == False
    def test_chigaimasu(self): assert is_backchannel_ja("違います")[0] == False
    def test_arimasen(self): assert is_backchannel_ja("ありません")[0] == False
    def test_mada_desu(self): assert is_backchannel_ja("まだです")[0] == False

    # questions
    def test_nanji(self): assert is_backchannel_ja("何時ですか")[0] == False
    def test_itsu(self): assert is_backchannel_ja("いつですか")[0] == False
    def test_doko(self): assert is_backchannel_ja("どこですか")[0] == False
    def test_ikura(self): assert is_backchannel_ja("いくらですか")[0] == False
    def test_naze(self): assert is_backchannel_ja("なぜですか")[0] == False
    def test_dare(self): assert is_backchannel_ja("誰ですか")[0] == False
    def test_doushitara(self): assert is_backchannel_ja("どうすればいいですか")[0] == False
    def test_yoyaku_dekiru(self): assert is_backchannel_ja("予約できますか")[0] == False

    # requests
    def test_onegai(self): assert is_backchannel_ja("お願いします")[0] == False
    def test_yoyaku_shitai(self): assert is_backchannel_ja("予約したいです")[0] == False
    def test_henko_shitai(self): assert is_backchannel_ja("変更したいです")[0] == False
    def test_oshiete(self): assert is_backchannel_ja("教えてください")[0] == False
    def test_cancel(self): assert is_backchannel_ja("キャンセルしたいです")[0] == False
    def test_ryoushusho(self): assert is_backchannel_ja("領収書をください")[0] == False

    # informational
    def test_name(self): assert is_backchannel_ja("名前は山田です")[0] == False
    def test_ashita(self): assert is_backchannel_ja("明日行きます")[0] == False
    def test_credit(self): assert is_backchannel_ja("クレジットカードで払います")[0] == False
    def test_tokyo(self): assert is_backchannel_ja("東京から来ました")[0] == False

    # medium-length real content
    def test_yoyaku_kakunin(self): assert is_backchannel_ja("すみません、予約の確認をしたいんですが")[0] == False
    def test_mitsumori(self): assert is_backchannel_ja("見積もりをいただけますか")[0] == False
    def test_zaiko(self): assert is_backchannel_ja("この商品はまだ在庫がありますか")[0] == False
    def test_haitatsu(self): assert is_backchannel_ja("配送はいつ届きますか")[0] == False

    # tricky: aizuchi-like start + continuation = real
    def test_hai_shitsumon(self): assert is_backchannel_ja("はい、質問があります")[0] == False
    def test_hai_yoyaku(self): assert is_backchannel_ja("はい、予約をお願いします")[0] == False
    def test_ee_tada(self): assert is_backchannel_ja("ええ、ただ一つ確認したいことがあります")[0] == False
    def test_sou_demo(self): assert is_backchannel_ja("そうですね、でも少し気になることがあって")[0] == False
    def test_sou_tada(self): assert is_backchannel_ja("そうですね、ただ値段が高いので")[0] == False
    def test_naruhodo_tsumari(self): assert is_backchannel_ja("なるほど、つまりそういうことですね")[0] == False
    def test_naruhodo_sorede(self): assert is_backchannel_ja("なるほど、それで今後はどうなりますか")[0] == False
    def test_wakari_dewa(self): assert is_backchannel_ja("わかりました、では変更をお願いします")[0] == False
    def test_un_demo(self): assert is_backchannel_ja("うん、でもちょっと待って")[0] == False
    def test_un_sorekara(self): assert is_backchannel_ja("うん、それから別の件なんだけど")[0] == False
    def test_hee_motto(self): assert is_backchannel_ja("へー、もっと詳しく教えてください")[0] == False
    def test_sugoi_douyatte(self): assert is_backchannel_ja("すごいですね、どうやったんですか")[0] == False
    def test_majide_komaru(self): assert is_backchannel_ja("まじで、それは困りますね")[0] == False

    # short real responses
    def test_hai_onegai(self): assert is_backchannel_ja("はい、お願いします")[0] == False
    def test_ii_desu_yo(self): assert is_backchannel_ja("いいですよ")[0] == False
    def test_sou_shimashou(self): assert is_backchannel_ja("そうしましょう")[0] == False
    def test_ii_to_omou(self): assert is_backchannel_ja("いいと思います")[0] == False
    def test_kekkou(self): assert is_backchannel_ja("結構です")[0] == False


# === confidence checks ===

class TestConfidence:
    """confidence should be high for clear cases"""

    def test_hai_high_conf(self):
        _, conf = is_backchannel_ja("はい")
        assert conf > 0.9

    def test_real_low_conf(self):
        _, conf = is_backchannel_ja("予約したいです")
        assert conf < 0.1

    def test_naruhodo_high_conf(self):
        _, conf = is_backchannel_ja("なるほど")
        assert conf > 0.9

    def test_question_low_conf(self):
        _, conf = is_backchannel_ja("いくらですか")
        assert conf < 0.1


# === edge cases ===

class TestEdgeCases:
    """empty/whitespace/unusual inputs"""

    def test_empty(self): assert is_backchannel_ja("")[0] == False
    def test_space(self): assert is_backchannel_ja("  ")[0] == False
    def test_whitespace_hai(self): assert is_backchannel_ja(" はい ")[0] == True
    def test_whitespace_real(self): assert is_backchannel_ja(" いいえ ")[0] == False
