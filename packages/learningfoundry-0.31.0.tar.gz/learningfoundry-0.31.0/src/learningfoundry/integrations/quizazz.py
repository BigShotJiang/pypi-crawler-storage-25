# Copyright 2026 Pointmatic
# SPDX-License-Identifier: Apache-2.0
"""quizazz integration — QuizProvider backed by the quizazz package."""

from pathlib import Path

from learningfoundry.exceptions import IntegrationError


class QuizazzProvider:
    """QuizProvider implementation backed by the quizazz package.

    Delegates to ``quizazz.compile_assessment()`` to produce a
    manifest dict from a single assessment YAML file.

    Requires the ``quizazz`` package:
        pip install learningfoundry[quizazz]
    """

    def compile_assessment(self, ref_path: Path, base_dir: Path) -> dict:  # type: ignore[type-arg]
        """Compile an assessment YAML file into a renderable manifest dict.

        Args:
            ref_path: Path to the assessment YAML file (relative to base_dir).
            base_dir: Root directory for resolving paths within the YAML.

        Returns:
            Compiled quiz manifest dict (questions, nav tree).

        Raises:
            IntegrationError: If quizazz raises any error during
                validation or compilation.
            ImportError: If quizazz is not installed.
        """
        try:
            from quizazz import (
                compile_assessment,
            )
        except ImportError as exc:
            raise ImportError(
                "quizazz is not installed. "
                "Install it with: pip install learningfoundry[quizazz]"
            ) from exc

        try:
            return compile_assessment(ref_path, base_dir)  # type: ignore[no-any-return]
        except Exception as exc:
            raise IntegrationError(
                f"quizazz failed to compile assessment `{ref_path}`: {exc}"
            ) from exc
