# DISCORD COLOUR

Discord Colour is a python package/module developed by me, it uses code blocks to 
make coloured text, It uses things like diff - and + for green and red text.

 ---
Its usage is mainly intended for bots, crash reports etc..
But it could be used by users too.
Its purpose is to make it easier to implement code blocks for your bot, or your crash reports etc.


 ---

Installation:
``pip install discord_colour``\
usage : ```Color.green(text)```

It also allows you to make codeblocks with ``Codeblock.codeblock(text)``.

- More updates *may* be added but for now, I see the package as finished.