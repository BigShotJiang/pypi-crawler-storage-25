class Codeblock:
    @classmethod
    def codeblock(cls, text):
        return f"```\n{text}\n```"