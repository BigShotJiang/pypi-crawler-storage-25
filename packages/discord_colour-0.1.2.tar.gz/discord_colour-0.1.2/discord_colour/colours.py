class Colour:

    @classmethod
    def green(cls, text):
        return f"```diff\n+ {text}\n```"

    @classmethod
    def red(cls, text):
        return f"```diff\n- {text}\n```"

    @classmethod
    def blue(cls, text):
        return f"```fix\n {text}\n```"

    @classmethod
    def light_blue(cls, text):
        return f"```yaml\n {text}\n```"