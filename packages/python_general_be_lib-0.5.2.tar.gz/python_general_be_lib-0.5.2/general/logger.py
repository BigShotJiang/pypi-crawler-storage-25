import logging
import logging.config
from datetime import datetime
from time import time

from fastapi import HTTPException

from .exception.crud_exceptions import InternalServerException

__all__ = ["init_logger", "log"]

COLOR = {
    "HEADER": "\033[95m",
    "BLUE": "\033[94m",
    "GREEN": "\033[92m",
    "RED": "\033[91m",
    "ENDC": "\033[0m",
}

color = COLOR['BLUE']
end_color = COLOR['ENDC']
exc_color = COLOR['RED']

LOGGING_CONFIG = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "logformatter": {
            "format": "[%(asctime)s] %(levelname)s - %(message)s"
        }
    },
    "handlers": {
        "logconsole": {
            "class": "logging.StreamHandler",
            "level": "INFO",
            "formatter": "logformatter",
            "stream": "ext://sys.stderr"
        }
    },
    "root": {
        "level": "INFO",
        "handlers": ["logconsole"]
    }
}


class EndpointFilter(logging.Filter):
    """Filtro per escludere endpoint specifici dai log di accesso uvicorn.

    Attributes:
        endpoint (str): Stringa da cercare nel messaggio di log.
            I log che la contengono vengono soppressi.
    """

    def __init__(self, endpoint: str = '', *args, **kwargs):
        """Inizializza il filtro con l'endpoint da sopprimere.

        Args:
            endpoint (str): Stringa dell'endpoint da filtrare (es. ``"/health"``).
        """
        super().__init__(*args, **kwargs)
        self.endpoint = endpoint

    def filter(self, record: logging.LogRecord) -> bool:
        """Restituisce ``False`` se il messaggio contiene l'endpoint da filtrare.

        Args:
            record (LogRecord): Record di log da valutare.

        Returns:
            bool: ``True`` se il log deve essere emesso, ``False`` se deve essere
                soppresso.
        """
        return record.getMessage().find(self.endpoint) == -1


def init_logger(*filtering_endpoints: str):
    """Inizializza il logger con configurazione standard e filtraggio endpoint.

    Configura il logging con formato ``[timestamp] LEVEL - message`` su stderr
    al livello INFO. Applica ``EndpointFilter`` al logger ``uvicorn.access`` per
    sopprimere i log degli endpoint indicati (utile per health check e metriche).

    Args:
        *filtering_endpoints (str): Endpoint da escludere dai log di accesso
            (es. ``"/health"``, ``"/metrics"``).

    Example:
        >>> init_logger("/health", "/metrics", "/ping")
    """
    logging.config.dictConfig(LOGGING_CONFIG)
    logging.info("Logger setted up")
    for filtering_endpoint in filtering_endpoints:
        logging.getLogger("uvicorn.access").addFilter(EndpointFilter(filtering_endpoint))


def log(func):
    """Decorator per il logging automatico di chiamate a funzione.

    Logga nome della funzione, argomenti, durata di esecuzione ed eventuali
    eccezioni. In caso di eccezione:
    - ``HTTPException`` → viene propagata direttamente (senza traceback).
    - Qualsiasi altra eccezione → viene convertita in ``InternalServerException``.

    Args:
        func (Callable): Funzione da decorare.

    Returns:
        Callable: Funzione wrapper con logging integrato.

    Example:
        >>> @log
        ... def get_users():
        ...     pass

        Output nei log::

            [2024-01-15 10:30] INFO - get_users | args: () | kwargs: {}
            [2024-01-15 10:30] INFO - get_users completed in 0.045 seconds
    """

    def wrapper(*args, **kwargs):
        func_name = f"{func.__name__}"
        start = time()
        logging.info(f"[{datetime.now().strftime('%Y-%m-%d %H:%M')}] {color} {func_name} {end_color}| args: {args} | kwargs: {kwargs}")
        try:
            result = func(*args, **kwargs)
        except Exception as e:
            logging.exception(f"[{datetime.now().strftime('%Y-%m-%d %H:%M')}] Exception {exc_color} {func_name} {end_color}: {repr(e)}")
            raise e.with_traceback(None) if isinstance(e, HTTPException) else InternalServerException(repr(e))
        else:
            logging.info(f"{color} {func_name} {end_color} completed in {time() - start} seconds")
        return result

    return wrapper
