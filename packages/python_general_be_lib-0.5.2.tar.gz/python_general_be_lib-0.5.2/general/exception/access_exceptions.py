from .exception_interface import ExceptionInterface


class ForbiddenException(ExceptionInterface):
    status_code = 403
    default_message = "Risorsa non accessibile da questo utente"


class UnauthorizedException(ExceptionInterface):
    status_code = 401
    default_message = "Non autorizzato"
