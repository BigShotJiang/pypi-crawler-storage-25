from fastapi import HTTPException


class ExceptionInterface(HTTPException):
    status_code: int
    default_message: str

    def __init__(self, custom_message: str = None):
        detail = f"{self.default_message} - {custom_message}" if custom_message else self.default_message
        super().__init__(status_code=self.status_code, detail=detail)
