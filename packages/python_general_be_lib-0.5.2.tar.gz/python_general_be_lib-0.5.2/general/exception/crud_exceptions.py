from .exception_interface import ExceptionInterface


class BadRequestException(ExceptionInterface):
    status_code = 400
    default_message = "Richiesta non corretta"


class EntityNotFoundException(ExceptionInterface):
    status_code = 404
    default_message = "Dato non trovato"


class ServiceUnavailableException(ExceptionInterface):
    status_code = 503
    default_message = "Servizio momentaneamente non disponibile, riprovare più tardi"


class UnprocessableEntityException(ExceptionInterface):
    status_code = 422
    default_message = "Entità non processabile"


class HasNoAttributeException(ExceptionInterface):
    status_code = 400
    default_message = "Richiesta non corretta"

    def __init__(self, attr: str = ""):
        if attr:
            super().__init__(custom_message=f"Attributo {attr} non presente", )
        else:
            super().__init__(custom_message="Alcuni attributi non sono presenti per questa entità", )


class InternalServerException(ExceptionInterface):
    status_code = 500
    default_message = "Impossibile gestire la richiesta al momento"
