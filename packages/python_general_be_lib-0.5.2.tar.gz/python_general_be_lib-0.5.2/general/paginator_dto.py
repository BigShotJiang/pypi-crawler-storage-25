__all__ = ["PaginatorRequestModel", "PaginatorResponseModel"]

from typing import Optional

from pydantic import Field

from .interface.base.base_model import ExtBaseModel


class PaginatorBaseModel(ExtBaseModel):
    """Modello base condiviso per request e response di paginazione.

    Tutti i campi usano alias italiani per compatibilità con l'API esposta.
    Eredita la configurazione da ``ExtBaseModel`` (``from_attributes=True``,
    ``populate_by_name=True``).

    Attributes:
        page (int): Numero di pagina corrente (1-based). Alias: ``numeroPagina``.
        limit (int | None): Numero di elementi per pagina. Alias: ``numeroElementi``.
        order_by (str | None): Campo usato per l'ordinamento. Alias: ``campoOrdinamento``.
        asc (bool): Ordinamento crescente se ``True``. Alias: ``crescente``.
    """
    page: int = Field(alias="numeroPagina")
    limit: Optional[int] = Field(default=None, alias="numeroElementi")
    order_by: Optional[str] = Field(default=None, alias="campoOrdinamento")
    asc: bool = Field(alias="crescente")


class PaginatorRequestModel(PaginatorBaseModel):
    """Modello di richiesta per endpoint paginati.

    Da usare come body o query param in endpoint che supportano paginazione.
    Eredita tutti i campi da ``PaginatorBaseModel``.

    Example:
        >>> request = PaginatorRequestModel(
        ...     numeroPagina=2,
        ...     numeroElementi=20,
        ...     campoOrdinamento="name",
        ...     crescente=True
        ... )
    """
    pass


class PaginatorResponseModel[ResponseType](PaginatorBaseModel):
    """Modello di risposta generico per risultati paginati.

    Estende ``PaginatorBaseModel`` aggiungendo il numero totale di pagine
    e la lista dei dati della pagina corrente.

    Type Parameters:
        ResponseType: Tipo degli elementi nella lista ``data``.

    Attributes:
        tot_pages (int): Numero totale di pagine calcolato dal repository.
            Alias: ``pagineTotali``.
        data (list[ResponseType]): Lista degli elementi della pagina corrente.

    Example:
        >>> response = PaginatorResponseModel[UserModel](
        ...     numeroPagina=1,
        ...     numeroElementi=20,
        ...     campoOrdinamento="name",
        ...     crescente=True,
        ...     pagineTotali=5,
        ...     data=[...]
        ... )
        >>> response.tot_pages
        5
    """

    tot_pages: int = Field(alias="pagineTotali")
    data: list[ResponseType]
