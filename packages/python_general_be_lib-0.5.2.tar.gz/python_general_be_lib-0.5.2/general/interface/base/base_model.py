__all__ = ["ExtBaseModel", "CamelExtBaseModel"]

from pydantic import BaseModel, ConfigDict
from pydantic.alias_generators import to_camel


class ConfigModel(BaseModel):
    """Modello Pydantic base con configurazione condivisa.

    Abilita:
    - ``from_attributes=True``: validazione da oggetti ORM SQLAlchemy.
    - ``populate_by_name=True``: accetta sia il nome Python che l'alias.
    - ``arbitrary_types_allowed=True``: consente tipi non standard (es. ``WKBElement``).
    - ``validate_default=True``: valida i valori di default alla creazione.
    """
    model_config = ConfigDict(from_attributes=True, populate_by_name=True, arbitrary_types_allowed=True, validate_default=True)


class CamelConfigModel(ConfigModel):
    """Estende ``ConfigModel`` aggiungendo la generazione automatica di alias camelCase."""
    model_config = ConfigDict(alias_generator=to_camel)

    @classmethod
    def get_attr_by_alias(cls, alias: str) -> str:
        """Restituisce il nome del campo Python dato un alias camelCase.

        Utile per risalire al nome interno del campo quando si riceve
        un payload con chiavi in camelCase.

        Args:
            alias (str): Alias camelCase del campo (es. ``"myField"``).

        Returns:
            str: Nome Python del campo (es. ``"my_field"``),
                oppure l'alias stesso se non trovato.

        Example:
            >>> class MyModel(CamelExtBaseModel):
            ...     my_field: str
            >>> MyModel.get_attr_by_alias("myField")
            'my_field'
        """
        for name, field in cls.model_fields.items():
            if field.alias == alias:
                return name
        return alias


class ExtBaseModel(ConfigModel):
    """Modello Pydantic con configurazione standard per l'integrazione ORM.

    Eredita da ``ConfigModel``. Da usare come base per tutti i modelli
    che devono essere validati a partire da entità SQLAlchemy.
    """
    pass


class CamelExtBaseModel(CamelConfigModel):
    """Modello Pydantic con alias camelCase automatici e integrazione ORM.

    Eredita da ``CamelConfigModel``. Da usare quando l'API espone
    campi in camelCase ma internamente si lavora con snake_case.
    """
    pass
