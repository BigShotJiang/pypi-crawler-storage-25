__all__ = ["GeomMetadata"]

from typing import Any, Type

from geoalchemy2 import WKBElement
from pydantic import BaseModel
from sqlalchemy import Connection, Table, Column

from .crud_metadata import CrudMetadata


class GeomMetadata(CrudMetadata):

    def intersects(self, from_table: str, geom: WKBElement, polygon_column_name: str, polygon_column_srid: int, connection: Connection = None, tolerance: float = 0.0, columns: list[str] = None,
                   where: dict[str, Any] = None, not_where: dict[str, Any] = None, limit: int = 0, geom_srid: int = 4326, parsing_model: Type[BaseModel] | BaseModel = None, intersection: bool = False,
                   intersection_area: bool = False):

        keep_open = False if connection is None else True
        connection = self.open_connection if connection is None else connection
        table = self.get_table(name=from_table)
        polygon_column = table.c[polygon_column_name]
        result = self._intersects(table=table, connection=connection, polygon_column=polygon_column, polygon_column_srid=polygon_column_srid, geom=geom, tolerance=tolerance, where=where, not_where=not_where,
                                  columns=columns, limit=limit, geom_srid=geom_srid, intersection=intersection, intersection_area=intersection_area)
        return self._return(connection=connection, result=result, keep_open=keep_open, commit=False, parsing_model=parsing_model)

    def _intersects(self, table: Table, geom: WKBElement, polygon_column: Column, polygon_column_srid: int, connection: Connection = None, tolerance: float = 0.0, columns: list[str] = None, where: dict[str, Any] = None,
                    not_where: dict[str, Any] = None, limit: int = 0, geom_srid: int = 4326, intersection: bool = False, intersection_area: bool = False):
        if where is None:
            where = {}
        if not_where is None:
            not_where = {}

        stmt = self._select(table, columns)

        intersecting_geom = self._geom_condition(geom=geom, geom_srid=geom_srid, polygon_column_srid=polygon_column_srid, buffer=tolerance)

        if intersection:
            stmt = stmt.add_columns(polygon_column.ST_Intersection(intersecting_geom).label("intersection"))
        if intersection_area:
            stmt = stmt.add_columns(polygon_column.ST_Intersection(intersecting_geom).ST_Transform(3857).ST_Area().label("intersection_area"))

        eq_where = [self._eq_where(table.c[column], condition) for column, condition in where.items()]
        eq_where.extend([self._eq_where(table.c[column], condition, True) for column, condition in not_where.items()])

        geom_condition = polygon_column.ST_Intersects(intersecting_geom)

        eq_where.append(geom_condition)

        stmt = stmt.where(*eq_where)

        stmt = self._add_limit_offset_condition(stmt, limit)
        return self.execute(connection=connection, stmt=stmt, mapping=True)

    def contains(self, from_table: str, geom: WKBElement, polygon_column_name: str, polygon_column_srid: int, connection: Connection = None, tolerance: float = 0.0, columns: list[str] = None,
                 where: dict[str, Any] = None, limit: int = 0, contained: bool = False, geom_srid: int = 4326, parsing_model: Type[BaseModel] | BaseModel = None):

        keep_open = False if connection is None else True
        connection = self.open_connection if connection is None else connection
        table = self.get_table(name=from_table)
        polygon_column = table.c[polygon_column_name]
        result = self._contains(table=table, connection=connection, polygon_column=polygon_column, polygon_column_srid=polygon_column_srid, geom=geom, tolerance=tolerance, where=where, contained=contained,
                                columns=columns, limit=limit, geom_srid=geom_srid)
        return self._return(connection=connection, result=result, keep_open=keep_open, commit=False, parsing_model=parsing_model)

    def _contains(self, table: Table, geom: WKBElement, polygon_column: Column, polygon_column_srid: int, connection: Connection = None, tolerance: float = 0.0, columns: list[str] = None, where: dict[str, Any] = None,
                  limit: int = 0, contained: bool = False, geom_srid: int = 4326):
        if columns is None:
            columns = []
        if where is None:
            where = {}

        stmt = self._select(table, columns)
        eq_where = [self._eq_where(table.c[column], condition) for column, condition in where.items()]

        geom_condition = self._geom_condition(geom=geom, geom_srid=geom_srid, polygon_column_srid=polygon_column_srid, buffer=tolerance)
        geom_condition = polygon_column.ST_Contains(geom_condition) if not contained else geom_condition.ST_Contains(polygon_column)

        eq_where.append(geom_condition)

        stmt = stmt.where(*eq_where)
        stmt = self._add_limit_offset_condition(stmt, limit)
        return self.execute(connection=connection, stmt=stmt, mapping=True)

    def _geom_condition(self, geom: WKBElement, polygon_column_srid: int = 4326, geom_srid: int = 4326, buffer: float = 0):
        geom_condition = geom.ST_Transform(polygon_column_srid) if geom_srid != polygon_column_srid else geom
        geom_condition = geom_condition.ST_Buffer(buffer) if buffer else geom_condition

        return geom_condition
