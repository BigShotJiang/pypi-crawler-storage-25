__all__ = ["CrudMetadata"]

import logging
from typing import Optional, Any, Type, Iterable, Sequence

from pydantic import BaseModel
from sqlalchemy import MetaData, Engine, Column, Table, inspect, Connection, select, RowMapping, CursorResult, not_

from ...exception.crud_exceptions import HasNoAttributeException


class CrudMetadata:
    __slots__ = "schema", "metadata", "engine", "engine_inspection"

    @property
    def open_connection(self):
        return self.engine.connect()

    def __init__(self, engine: Engine, schema_name: str = None, reflect: bool = True):
        self.schema = schema_name
        self.metadata = MetaData(schema_name) if schema_name else MetaData()
        self.engine = engine
        self.engine_inspection = inspect(self.engine)
        if reflect:
            self.metadata.reflect(bind=self.engine, schema=schema_name)

    # ---------------------------

    def _handle_exception(self, connection: Connection, e: Exception, to_raise: bool = True):
        connection.close()
        logging.error(e)
        if to_raise:
            raise e

    def commit(self, connection: Connection):
        try:
            connection.commit()
        except Exception as e:
            self._handle_exception(connection, e)

    def has_columns(self, *columns: Iterable[str], table: Table):
        return all([column in [c.key for c in table.c] for column in columns])

    def _select(self, table: Table, columns: list[str] = None):
        try:
            stmt = table.select() if not columns else select(*[table.c[column] for column in columns])
        except:
            raise HasNoAttributeException()
        return stmt

    def _return(self, connection: Connection, result: CursorResult | RowMapping | Sequence[RowMapping] | Sequence[dict] = None, keep_open: bool = False, commit: bool = True,
                parsing_model: Type[BaseModel] | BaseModel = None):
        if keep_open:
            return result
        else:
            if commit:
                self.commit(connection=connection)
            result = result if parsing_model is None else [parsing_model(**r) for r in result]
            connection.close()
        return result

    def create_table(self, name: str, columns: Iterable[Column], **kwargs):
        table = Table(name=name, metadata=self.metadata, *columns, **kwargs)
        table.create(self.engine)

    def drop_table(self, name: str):
        table = self.get_table(name=name)
        table.drop(self.engine)
        self.metadata.remove(table=table)

    def find(self, from_table: str, connection: Connection = None, where: dict[str, Any] = None, columns: list[str] = None, limit: int = 0, parsing_model: Type[BaseModel] = None, **kwhere):
        keep_open = False if connection is None else True
        connection = self.open_connection if connection is None else connection
        table = self.get_table(name=from_table)
        result = self._find(table=table, connection=connection, where=where, columns=columns, limit=limit, **kwhere)
        return self._return(connection=connection, result=result, keep_open=keep_open, commit=False, parsing_model=parsing_model)

    def _find(self, table: Table, connection: Connection, where: dict[str, Any] = None, columns: list[str] = None, limit: int = 0, **kwhere):
        if where is None:
            where = kwhere if kwhere else {}
        stmt = self._select(table=table, columns=columns)
        stmt = stmt.where(*[self._eq_where(table.c[column], condition) for column, condition in where.items()])
        stmt = self._add_limit_offset_condition(stmt, limit)
        return self.execute(connection=connection, stmt=stmt, mapping=True)

    def insert(self, from_table: str, connection: Connection = None, models: list[Type[BaseModel] | BaseModel] = None, values: list[dict[str, Any]] = None, returning: bool = True,
               parsing_model: Type[BaseModel] | BaseModel = None):
        keep_open = False if connection is None else True
        connection = self.open_connection if connection is None else connection
        table = self.get_table(name=from_table)
        values_condition = values if values else []
        values_condition.extend([model.model_dump(exclude_none=True) for model in models]) if models else values_condition
        result = self._insert(table=table, connection=connection, values=values_condition, returning=returning)
        return self._return(connection=connection, result=result, keep_open=keep_open, commit=True, parsing_model=parsing_model)

    def _insert(self, table: Table, connection: Connection, values: list[dict[str, Any]] = None, returning: bool = True):
        if values:
            stmt = table.insert().values(values)
            stmt = stmt if not returning else stmt.returning()
            return self.execute(connection=connection, stmt=stmt, mapping=True)
        else:
            return []

    def update(self, from_table: str, connection: Connection = None, where: dict[str, Any] = None, returning: bool = True, parsing_model: Type[BaseModel] | BaseModel = None, **kwargs):
        keep_open = False if connection is None else True
        connection = self.open_connection if connection is None else connection
        table = self.get_table(name=from_table)
        result = self._update(table=table, connection=connection, where=where, returning=returning, **kwargs)
        return self._return(connection=connection, result=result, keep_open=keep_open, commit=True, parsing_model=parsing_model)

    def _update(self, table: Table, connection: Connection, where: dict[str, Any] = None, returning: bool = True, **kwargs):
        if where is None:
            where = {}
        stmt = table.update()
        stmt = stmt.where(*[self._eq_where(table.c[column], condition) for column, condition in where.items()])
        stmt = stmt.values(**kwargs)
        stmt = stmt if not returning else stmt.returning()
        return self.execute(connection=connection, stmt=stmt, mapping=True)

    def delete(self, from_table: str, connection: Connection = None, where: dict[str, Any] = None, **kwhere):
        keep_open = False if connection is None else True
        connection = self.open_connection if connection is None else connection
        table = self.get_table(name=from_table)
        num_rows = self._delete(table=table, connection=connection, where=where, **kwhere)
        if not num_rows or keep_open:
            return num_rows
        else:
            self.commit(connection)
        connection.close()
        return num_rows

    def _delete(self, table: Table, connection: Connection, where: dict[str, Any] = None, **kwhere):
        if where is None:
            where = kwhere if kwhere else {}
        stmt = table.delete()
        stmt = stmt.where(*[self._eq_where(table.c[column], condition) for column, condition in where.items()])
        return self.execute(connection=connection, stmt=stmt).rowcount

    # --------------

    def execute(self, connection: Connection, stmt, mapping: bool = False):
        try:
            result = connection.execute(stmt)
        except Exception as e:
            self._handle_exception(connection, e)
        else:
            if mapping:
                result = result.mappings().all()
            return result

    def _get_table(self, name: str):
        if self.schema is not None:
            table_name = name if name.startswith(f"{self.schema}.") else f"{self.schema}.{name}"
        else:
            table_name = name
        return self.metadata.tables.get(table_name)

    def get_table(self, name: str) -> Optional[Table]:
        table = self._get_table(name=name)
        if table is None:
            table = Table(name, self.metadata, schema=self.schema, autoload_with=self.engine)
        return table

    def has_table(self, name: str):
        return self.engine_inspection.has_table(name, self.schema)

    def _add_limit_offset_condition(self, stmt, limit: int, page: int = None):
        if limit and limit > 0:
            stmt = stmt.limit(limit)
            if page and page > 0:
                offset = (page - 1) * limit
                stmt = stmt.offset(offset)
        return stmt

    def _eq_where(self, col: Column, condition, neq: bool = False):
        eq_where = col.in_(condition) if isinstance(condition, list) else col == condition if str(col.type) != "ARRAY" else condition == col.any_()
        if neq:
            not_(eq_where)
        return eq_where
