__all__ = ["ViewRepository"]

import logging
from time import time
from typing import Type

from geoalchemy2 import Geometry
from sqlalchemy import text

from .crud_repository import CrudRepository
from ..base import Base


class ViewRepository[Entity: Base | Type[Base]](CrudRepository[Entity]):
    """Repository per la gestione di viste e viste materializzate PostgreSQL.

    Estende ``CrudRepository`` aggiungendo metodi per la creazione e il refresh
    di viste database. La query che definisce la vista deve essere specificata
    nell'attributo ``select_stmt`` della sottoclasse.

    Attributes:
        select_stmt (str): Query SQL che definisce il corpo della vista.
        materialized (bool): Se ``True``, gestisce una vista materializzata.
            Default: ``False``.

    Example:
        >>> class ActiveUsersView(ViewRepository[UserView]):
        ...     select_stmt = "SELECT * FROM users WHERE active = true"
        ...     materialized = True
        ...
        >>> repo = ActiveUsersView(entity=UserView, model=UserModel, engine=engine)
        >>> repo.create(drop_before=True)
        >>> repo.refresh_materialized_view()
    """
    select_stmt: str
    materialized: bool = False

    @property
    def view_name(self):
        """Nome completo della vista nel formato ``schema.tablename``.

        Returns:
            str: Nome qualificato della vista (es. ``"public.active_users"``).
        """
        return f"{self.entity.__table_args__['schema']}.{self.entity.__tablename__}"

    def create(self, drop_before: bool = False, visualizer_db_role: str = None):
        """Crea la vista (o vista materializzata) sul database.

        Per le viste materializzate, crea automaticamente un indice univoco
        sulla chiave primaria dell'entità. Se la vista ha colonne geometriche
        e viene fornito un ruolo visualizzatore, assegna il permesso SELECT.

        Esegue le operazioni in un'unica transazione. Gli errori vengono
        loggati ma non rilanciati.

        Args:
            drop_before (bool): Se ``True``, esegue un ``DROP VIEW/MATERIALIZED VIEW``
                (con ``CASCADE``) prima di creare la nuova vista. Utile per aggiornare
                la definizione della vista. Default: ``False``.
            visualizer_db_role (str, optional): Nome del ruolo PostgreSQL a cui
                assegnare il permesso ``SELECT`` sulla vista. Viene applicato solo
                se la vista contiene colonne di tipo ``Geometry``.

        Note:
            - Per viste normali usa ``CREATE OR REPLACE VIEW``.
            - Per viste materializzate usa ``CREATE MATERIALIZED VIEW IF NOT EXISTS``.
            - Il tempo di creazione viene loggato a livello INFO.
        """
        logging.info(f"Creating view {self.view_name}")
        start = time()
        stmts = []

        try:
            if drop_before:
                drop_stmt = f"drop materialized view if exists {self.view_name} cascade;" if self.materialized else f"drop view if exists {self.view_name} cascade;"
                stmts.append(drop_stmt)
            create_stmt = f"create materialized view if not exists {self.view_name} as {self.select_stmt};" if self.materialized else f"create or replace view {self.view_name} as {self.select_stmt};"
            stmts.append(create_stmt)
            if self.materialized:
                unique_id_index = f"create unique index on {self.view_name} ({self.entity.primary_key()[0].name});"
                stmts.append(unique_id_index)
            if visualizer_db_role and any([isinstance(col.type, Geometry) for col in self.entity.columns()]):
                grant_visualized = f"grant select on table {self.view_name} to {visualizer_db_role}"
                stmts.append(grant_visualized)

            with self.open_session as session:
                for stmt in stmts:
                    session.execute(text(stmt))
                    session.flush()
                session.commit()
            logging.info(f"Created {self.view_name} in {time() - start}")
        except Exception as e:
            logging.error(f"{self.entity.__table__.name} creation error - {repr(e)}")

    def refresh_materialized_view(self, concurrently: bool = True):
        """Esegue il refresh di una vista materializzata.

        Il refresh aggiorna i dati della vista materializzata rieseguendo
        la query definita in ``select_stmt``.

        Args:
            concurrently (bool): Se ``True``, usa ``REFRESH MATERIALIZED VIEW CONCURRENTLY``
                che permette letture concorrenti durante il refresh (richiede che
                esista un indice univoco sulla vista). Se ``False``, blocca le letture
                durante il refresh ma non richiede l'indice. Default: ``True``.

        Note:
            Il tempo di refresh viene loggato a livello INFO.
            Richiede che la vista sia effettivamente materializzata
            (``self.materialized = True``).
        """
        logging.info(f"Refreshing {self.view_name}")
        start = time()
        stmt_str = f"refresh materialized view concurrently {self.view_name}" if concurrently else f"refresh materialized view {self.view_name}"
        stmt = text(stmt_str)
        with self.open_session as session:
            session.execute(stmt)
            session.commit()
        logging.info(f"Refreshed {self.view_name} in {time() - start}")
