__all__ = ["ManyToManyRepository"]

from typing import Type, Any

from pydantic import BaseModel
from sqlalchemy.orm import Session

from .crud_repository import CrudRepository
from ..base import Base


class ManyToManyRepository[Entity: Base | Type[Base]](CrudRepository[Entity]):
    """Repository per la gestione differenziale di collezioni in relazioni many-to-many.

    Estende ``CrudRepository`` con metodi per sincronizzare collezioni di entità
    figlie rispetto a un parent, gestendo automaticamente insert, update e delete
    in base alle differenze tra la lista corrente e quella desiderata.
    """

    def diff_upsert_from_parent(self, session: Session, parent: Type[Base], children: list[Type[BaseModel]], relationship_attribute: str, child_fks: dict[str, Any], child_pk: str = "id") -> list[Entity]:
        """Sincronizza la collezione di figli di un parent tramite upsert differenziale.

        Elimina i figli attualmente associati al parent che non sono presenti
        nella nuova lista (identificati per chiave primaria), imposta le FK
        su tutti i nuovi figli ed esegue un upsert su tutta la lista.

        Args:
            session (Session): Sessione corrente (obbligatoria, non viene creata internamente).
            parent (Base): Entità padre già caricata con la relazione inizializzata.
            children (list[BaseModel]): Nuova lista desiderata di figli (modelli Pydantic).
            relationship_attribute (str): Nome dell'attributo di relazione sul parent
                (es. ``"tags"``, ``"items"``).
            child_fks (dict[str, Any]): Chiavi esterne da impostare su ogni figlio
                prima dell'upsert (es. ``{"parent_id": parent.id}``).
            child_pk (str): Nome del campo chiave primaria dei figli. Default: ``"id"``.

        Returns:
            list[Entity]: Entità figlie risultanti dopo la sincronizzazione.

        Example:
            >>> repo.diff_upsert_from_parent(
            ...     session=session,
            ...     parent=order,
            ...     children=new_items,
            ...     relationship_attribute="items",
            ...     child_fks={"order_id": order.id}
            ... )
        """
        ids = {getattr(child, child_pk) for child in children if getattr(child, child_pk)}
        for child in getattr(parent, relationship_attribute):
            if getattr(child, child_pk) not in ids:
                session.delete(child)

        for model in children:
            for key, value in child_fks.items():
                setattr(model, key, value)

        entities = self.upsert(session=session, models=children)

        return entities

    def diff_update_from_parent(self, session: Session, parent: Type[Base], children: list[Type[BaseModel]], relationship_attribute: str) -> list[Entity]:
        """Aggiorna la collezione di figli mantenendo l'ordine posizionale.

        Confronta la dimensione della nuova lista con quella esistente:
        - Se la nuova lista è più lunga: aggiorna i figli esistenti e inserisce i nuovi.
        - Se è più corta: aggiorna i figli rimanenti ed elimina quelli in eccesso.
        - Se ha la stessa dimensione: aggiorna tutti i figli in posizione.

        Args:
            session (Session): Sessione corrente.
            parent (Base): Entità padre con la relazione caricata.
            children (list[BaseModel]): Nuova lista di figli nell'ordine desiderato.
            relationship_attribute (str): Nome dell'attributo di relazione sul parent.

        Returns:
            list[Entity]: Entità figlie aggiornate.
        """
        relationship_children = getattr(parent, relationship_attribute)
        current_size = len(relationship_children)
        size_updating = len(children)
        diff = size_updating - current_size

        if diff > 0:
            self._apply_updates(entities=relationship_children, models=children, count=current_size)
            entities = self.insert(session=session, models=children[current_size:])
            entities.extend(relationship_children)
        elif diff < 0:
            self._apply_updates(entities=relationship_children, models=children, count=size_updating)
            for cp in relationship_children[size_updating:]:
                session.delete(cp)
            entities = relationship_children[:size_updating]
        else:
            self._apply_updates(entities=relationship_children, models=children, count=current_size)
            entities = relationship_children
        return entities

    def diff_update_left_right(self, session: Session, parent: Type[Base], children: list[Type[BaseModel]], relationship_attribute: str, left_fks: dict[str, Any], right_fks: list[str]) -> list[Entity]:
        """Aggiornamento differenziale con gestione separata per nuovi e figli esistenti.

        Distingue tra:
        - ``left_fks``: attributi FK da impostare sui **nuovi** figli da inserire.
        - ``right_fks``: attributi da aggiornare sui figli **già presenti**.

        Args:
            session (Session): Sessione corrente.
            parent (Base): Entità padre con la relazione caricata.
            children (list[BaseModel]): Nuova lista di figli nell'ordine desiderato.
            relationship_attribute (str): Nome dell'attributo di relazione sul parent.
            left_fks (dict[str, Any]): Attributi FK da impostare sui nuovi figli
                (es. ``{"parent_id": parent.id}``).
            right_fks (list[str]): Nomi degli attributi da aggiornare sui figli
                già presenti (es. ``["quantity", "position"]``).

        Returns:
            list[Entity]: Entità figlie risultanti dopo la sincronizzazione.
        """
        size_new = len(children)

        relationship_children = getattr(parent, relationship_attribute)

        size = len(relationship_children)
        entities = []
        if size_new < size:
            for r_child in relationship_children[size_new:]:
                session.delete(r_child)
        elif size < size_new:
            for i in range(size, size_new):
                for key, value in left_fks.items():
                    setattr(children[i], key, value)
            entities = self.insert(session=session, models=children[size:size_new])
            size_new = size
        for i in range(size_new):
            for key in right_fks:
                setattr(relationship_children[i], key, getattr(children[i], key))
        entities.extend(relationship_children[:size_new])
        return entities

    def diff_update(self, session: Session, entities: list[Type[Base]], models: list[Type[BaseModel]]) -> list[Entity]:
        """Aggiornamento differenziale diretto tra entità esistenti e nuovi modelli.

        Operazione senza parent: confronta direttamente due liste per posizione.
        Inserisce i nuovi elementi, aggiorna quelli esistenti ed elimina quelli
        in eccesso rispetto alla nuova lista.

        Args:
            session (Session): Sessione corrente.
            entities (list[Base]): Lista corrente di entità ORM.
            models (list[BaseModel]): Nuova lista di modelli Pydantic desiderata.

        Returns:
            list[Entity]: Entità risultanti dopo la sincronizzazione.
        """
        current_size = len(entities)
        new_size = len(models)

        diff = new_size - current_size

        if diff > 0:
            self._apply_updates(entities=entities, models=models, count=current_size)
            entities.extend(self.insert(session=session, models=models[current_size:]))
        elif diff < 0:
            self._apply_updates(entities=entities, models=models, count=new_size)
            for entity in entities[new_size:]:
                session.delete(entity)
            entities = entities[:new_size]
        else:
            self._apply_updates(entities=entities, models=models, count=current_size)
        return entities

    def _apply_updates(self, entities: list[Type[Base]], models: list[Type[BaseModel]], count: int):
        """Applica in-place i valori dei modelli alle entità ORM per posizione.

        Itera sulle prime ``count`` coppie (entità, modello) e imposta
        gli attributi sull'entità usando ``model_dump(exclude_none=True)``.

        Args:
            entities (list[Base]): Lista di entità ORM da aggiornare.
            models (list[BaseModel]): Lista di modelli con i nuovi valori.
            count (int): Numero di elementi da aggiornare (da 0 a count-1).
        """
        for i in range(count):
            for attr, value in models[i].model_dump(exclude_none=True).items():
                setattr(entities[i], attr, value)
