__all__ = ["CrudRepository"]

import logging
import math
from typing import Any, Type, Sequence, Iterable, Optional, Mapping

from pydantic import BaseModel
from sqlalchemy import select, delete, update, insert, Row, RowMapping, ColumnElement, Select, Insert, Update, Delete
from sqlalchemy.engine.base import Engine
from sqlalchemy.exc import DataError, IntegrityError, NoResultFound, OperationalError
from sqlalchemy.inspection import inspect
from sqlalchemy.orm import Session, load_only, defer
from sqlalchemy.sql.functions import count

from .handler.base_handler import BaseHandler
from .handler.statement_manager import StatementManager
from ...exception.crud_exceptions import HasNoAttributeException, EntityNotFoundException, ServiceUnavailableException, BadRequestException
from ...interface.base.declarative_base import Base
from ...paginator_dto import PaginatorResponseModel


class CrudRepository[Entity: Base | Type[Base]]:
    """Repository ORM generico con operazioni CRUD complete su una singola entità SQLAlchemy.

    Fornisce metodi per trovare, inserire, aggiornare, eliminare e contare
    record, con supporto a paginazione, colonne parziali, sessioni esterne
    e modelli di parsing alternativi.

    Le eccezioni SQLAlchemy vengono catturate e risollevate come eccezioni
    HTTP-friendly (400, 404, 503).

    Attributes:
        entity (Type[Base]): Classe ORM dell'entità gestita.
        model (Type[BaseModel]): Modello Pydantic per la serializzazione dei risultati.
        engine (Engine): Istanza SQLAlchemy Engine.
        columns (ReadOnlyColumnCollection): Colonne della tabella dell'entità.
        stmt_manager (StatementManager): Orchestratore degli handler per i filtri.

    Example:
        >>> repo = CrudRepository(entity=User, model=UserModel, engine=engine)
        >>> repo.create()
        >>> users = repo.find(active=True, limit=10)
    """
    __slots__ = "model", "entity", "engine", "columns", "stmt_manager", "relationship_attributes"

    model: Type[BaseModel] | BaseModel
    entity: Entity
    engine: Type[Engine] | Engine
    stmt_manager: StatementManager | Type[StatementManager]

    @property
    def open_session(self):
        """Apre e restituisce una nuova sessione SQLAlchemy.

        Returns:
            Session: Nuova sessione associata all'engine configurato.
        """
        return Session(self.engine)

    def __init__(self, entity: Entity, model: Type[BaseModel] | BaseModel, engine: Type[Engine] | Engine, handlers: list[BaseHandler | Type[BaseHandler]] = None,
                 handler_class: Type[BaseHandler] | BaseHandler = None) -> None:
        """Inizializza il repository con l'entità, il modello e l'engine.

        Args:
            entity (Type[Base]): Classe ORM dell'entità da gestire.
            model (Type[BaseModel]): Modello Pydantic usato per la serializzazione.
            engine (Engine): Istanza SQLAlchemy Engine connessa al database.
            handlers (list[BaseHandler], optional): Handler aggiuntivi per la
                costruzione dei filtri WHERE (es. ``JsonHandler``, ``ILikeHandler``).
            handler_class (Type[BaseHandler], optional): Classe handler custom
                da usare come handler base al posto di ``BaseHandler``.
        """
        self.entity = entity
        self.model = model
        self.engine = engine
        self.columns = self.entity.columns()

        base_handler = handler_class(self.columns) if handler_class else BaseHandler(self.columns)

        self.stmt_manager = StatementManager(handlers=handlers, base_handler=base_handler)

    # -------------------------

    def _handle_exception(self, session: Session, e: Exception):
        """Chiude la sessione, logga l'errore e rilancia un'eccezione HTTP-friendly.

        Mapping delle eccezioni SQLAlchemy:
        - ``OperationalError`` → ``ServiceUnavailableException`` (503)
        - ``NoResultFound`` → ``EntityNotFoundException`` (404)
        - ``DataError`` | ``IntegrityError`` → ``BadRequestException`` (400)
        - Altro → rilancia l'eccezione originale.

        Args:
            session (Session): Sessione da chiudere.
            e (Exception): Eccezione catturata da gestire.

        Raises:
            ServiceUnavailableException: Se il DB non è raggiungibile.
            EntityNotFoundException: Se nessun record corrisponde.
            BadRequestException: Se i dati sono malformati o violano un constraint.
        """
        session.close()
        logging.error(e)
        match e:
            case OperationalError():
                raise ServiceUnavailableException()
            case NoResultFound():
                raise EntityNotFoundException()
            case DataError() | IntegrityError():
                raise BadRequestException()
            case _:
                raise e

    def commit(self, session: Session):
        """Esegue il commit sulla sessione, gestendo eventuali eccezioni.

        Args:
            session (Session): Sessione su cui eseguire il commit.

        Raises:
            ServiceUnavailableException | BadRequestException: In caso di errore
                durante il commit.
        """
        try:
            session.commit()
        except Exception as e:
            self._handle_exception(session, e)

    def _entity_has_columns(self, *columns: Iterable[str], entity: Type[Base] | Base = None):
        """Verifica che tutte le colonne specificate esistano sull'entità.

        Args:
            *columns (str): Nomi delle colonne da verificare.
            entity (Type[Base], optional): Entità su cui verificare. Se ``None``,
                usa ``self.entity``.

        Returns:
            bool: ``True`` se tutte le colonne sono presenti, ``False`` altrimenti.
        """
        return all([column in entity.columns_names() for column in columns])

    def _select(self, entity: Type[Base] | Base, columns: list[str] = None, exclude_columns: list[str] = None):
        """Costruisce lo statement SELECT con opzioni di caricamento parziale.

        Supporta ``load_only`` per caricare solo le colonne specificate e
        ``defer`` per escludere colonne dal caricamento. Le colonne di
        relazione vengono ignorate nel ``load_only``.

        Args:
            entity (Type[Base]): Entità su cui costruire il SELECT.
            columns (list[str], optional): Colonne da caricare (``load_only``).
                Le colonne di relazione vengono filtrate automaticamente.
            exclude_columns (list[str], optional): Colonne da escludere (``defer``).

        Returns:
            Select: Statement SELECT configurato.

        Raises:
            HasNoAttributeException: Se una colonna specificata non esiste sull'entità.
        """
        try:
            stmt = select(entity)
            if columns:
                relationship_attributes = set(entity.__mapper__.relationships.keys())
                entity_columns = {column for column in columns if column not in relationship_attributes}
                stmt = stmt.options(load_only(*[getattr(self.entity, column) for column in entity_columns]))
            if exclude_columns:
                stmt = stmt.options(defer(*[getattr(self.entity, column) for column in exclude_columns]))
        except AttributeError:
            raise HasNoAttributeException()
        return stmt

    def _return(self, session: Session, entities: Sequence[Row] | Sequence[Row | RowMapping | Type[Base]], keep_open: bool = False,
                commit: bool = True, parsing_model: Type[BaseModel] | BaseModel = None) -> list[Entity] | list[BaseModel]:
        """Serializza le entità e chiude la sessione se necessario.

        Se ``keep_open=True`` (sessione esterna), restituisce le entità grezze
        senza chiudere la sessione. Altrimenti esegue il commit (se richiesto),
        serializza con ``model_validate`` e chiude la sessione.

        Args:
            session (Session): Sessione corrente.
            entities (Sequence): Entità SQLAlchemy da serializzare.
            keep_open (bool): Se ``True``, non chiude la sessione e non serializza.
            commit (bool): Se ``True`` e ``keep_open=False``, esegue il commit.
            parsing_model (Type[BaseModel], optional): Modello alternativo per la
                serializzazione. Se ``None``, usa ``self.model``.

        Returns:
            list[Entity] | list[BaseModel]: Entità grezze o modelli serializzati.
        """
        if keep_open:
            return entities
        else:
            if commit:
                self.commit(session=session)
            return_model = parsing_model or self.model
            models = [return_model.model_validate(entity) for entity in entities]
            session.close()
        return models

    def create(self):
        """Crea la tabella sul database se non esiste ancora.

        Controlla la presenza della tabella tramite ispezione del database.
        Se la tabella non esiste, la crea usando la definizione dell'entità.
        Non fa nulla se la tabella è già presente.

        Note:
            Gli errori di creazione vengono loggati ma non rilanciati.
        """
        if not inspect(self.engine).has_table(table_name=self.entity.__table__.name, schema=self.entity.__table__.schema):
            try:
                self.entity.__table__.create(self.engine)
            except Exception as e:
                logging.error(f"{self.entity.__table__.name} creation error - {repr(e)}")
        else:
            pass

    def find(self, session: Session = None, where: dict[str, Any] = None, columns: list[str] = None, exclude_columns: list[str] = None, limit: int = 0, parsing_model: Type[BaseModel] = None, **kwhere) -> list[Entity]:
        """Cerca i record che corrispondono ai criteri specificati.

        I filtri possono essere passati come dizionario ``where`` o come
        keyword arguments. Supporta caricamento parziale delle colonne,
        limit e modelli di parsing alternativi.

        Args:
            session (Session, optional): Sessione esterna. Se ``None``, ne viene
                creata una nuova che viene chiusa al termine.
            where (dict[str, Any], optional): Filtri come dizionario
                ``{colonna: valore}``. Ha precedenza su ``**kwhere``.
            columns (list[str], optional): Colonne da includere nel risultato.
            exclude_columns (list[str], optional): Colonne da escludere dal risultato.
            limit (int): Numero massimo di risultati. 0 = nessun limite. Default: 0.
            parsing_model (Type[BaseModel], optional): Modello Pydantic alternativo
                per la serializzazione del risultato.
            **kwhere: Filtri aggiuntivi come keyword arguments.

        Returns:
            list[Entity]: Lista di modelli serializzati (o entità grezze se
                sessione esterna).

        Example:
            >>> repo.find(active=True, limit=10)
            >>> repo.find(where={"role": ["admin", "editor"]})
        """
        keep_open = False if session is None else True
        session = self.open_session if session is None else session
        entities = self._find(session=session, where=where, columns=columns, exclude_columns=exclude_columns, limit=limit, **kwhere)
        return self._return(session=session, entities=entities, keep_open=keep_open, commit=False, parsing_model=parsing_model)

    def _find(self, session: Session, where: dict[str, Any] = None, columns: list[str] = None, exclude_columns: list[str] = None, limit: int = 0, **kwhere):
        if where is None:
            where = kwhere if kwhere else {}
        stmt = self._select(entity=self.entity, columns=columns, exclude_columns=exclude_columns)
        stmt = self.stmt_manager.prepare_statement(stmt=stmt, **where)
        stmt = self.stmt_manager.limit_offset_condition(stmt=stmt, limit=limit)
        return self.execute(session, stmt)

    def insert(self, session: Session = None, models: list[Type[BaseModel] | BaseModel] = None, returning: bool = True, parsing_model: Type[BaseModel] | BaseModel = None) -> list[Entity]:
        """Inserisce una lista di record nel database.

        Usa un'istruzione ``INSERT`` bulk. Se ``returning=True``, restituisce
        le righe inserite (con valori generati dal DB come sequenze e default).

        Args:
            session (Session, optional): Sessione esterna. Se ``None``, ne viene
                creata una nuova con commit automatico.
            models (list[BaseModel], optional): Lista di modelli Pydantic da inserire.
                I campi ``None`` vengono esclusi con ``exclude_none=True``.
            returning (bool): Se ``True``, usa ``RETURNING`` per recuperare le righe
                inserite. Default: ``True``.
            parsing_model (Type[BaseModel], optional): Modello alternativo per la
                serializzazione del risultato.

        Returns:
            list[Entity]: Lista di entità inserite (serializzate con il modello).

        Example:
            >>> repo.insert(models=[UserModel(name="Mario", email="m@example.com")])
        """
        keep_open = False if session is None else True
        session = self.open_session if session is None else session
        entities = self._insert(session=session, models=models, returning=returning)
        return self._return(session=session, entities=entities, keep_open=keep_open, commit=True, parsing_model=parsing_model)

    def _insert(self, session: Session, models: list[Type[BaseModel] | BaseModel] = None, returning: bool = True):
        if models is None:
            models = []
        values = [model.model_dump(exclude_none=True) for model in models]
        if values:
            stmt = insert(self.entity)
            stmt = stmt if not returning else stmt.returning(self.entity)
            return self.execute(session=session, stmt=stmt, values=values)
        else:
            return []

    def add(self, session: Session = None, entities: list[Type[Base]] = None, parsing_model: Type[BaseModel] | BaseModel = None):
        """Inserisce entità ORM già istanziate tramite ``session.add_all``.

        Utile per inserire entità con relazioni già configurate, dove l'ORM
        gestisce le FK automaticamente. A differenza di ``insert``, accetta
        oggetti ORM e non modelli Pydantic.

        Args:
            session (Session, optional): Sessione esterna.
            entities (list[Base], optional): Lista di istanze ORM da aggiungere.
            parsing_model (Type[BaseModel], optional): Modello alternativo per la
                serializzazione del risultato.

        Returns:
            list[Entity]: Entità aggiunte (serializzate o grezze).

        Raises:
            ServiceUnavailableException | BadRequestException: In caso di errore
                durante l'aggiunta.
        """
        keep_open = False if session is None else True
        session = self.open_session if session is None else session
        try:
            session.add_all(entities)
        except Exception as e:
            self._handle_exception(session, e)
        return self._return(session=session, entities=entities, keep_open=keep_open, commit=True, parsing_model=parsing_model)

    def update(self, session: Session = None, where: dict[str, Any] = None, returning: bool = True, parsing_model: Type[BaseModel] | BaseModel = None, **kwargs) -> list[Entity]:
        """Aggiorna i record che soddisfano i criteri ``where`` con i valori in ``**kwargs``.

        Args:
            session (Session, optional): Sessione esterna.
            where (dict[str, Any], optional): Filtri per selezionare i record da
                aggiornare. Se ``None``, aggiorna tutti i record (usare con cautela).
            returning (bool): Se ``True``, usa ``RETURNING`` per recuperare le righe
                aggiornate. Default: ``True``.
            parsing_model (Type[BaseModel], optional): Modello alternativo per la
                serializzazione del risultato.
            **kwargs: Valori da impostare sui record trovati
                (es. ``name="Luigi"``, ``active=False``).

        Returns:
            list[Entity]: Lista di entità aggiornate.

        Example:
            >>> repo.update(where={"id": 1}, name="Luigi", email="luigi@example.com")
        """
        keep_open = False if session is None else True
        session = self.open_session if session is None else session
        entities = self._update(session=session, where=where, returning=returning, **kwargs)
        return self._return(session=session, entities=entities, keep_open=keep_open, commit=True, parsing_model=parsing_model)

    def _update(self, session: Session, where: dict[str, Any] = None, returning: bool = True, **kwargs):
        if where is None:
            where = {}
        stmt = update(self.entity)
        stmt = self.stmt_manager.prepare_statement(stmt=stmt, **where)
        stmt = stmt.values(**kwargs)
        stmt = stmt if not returning else stmt.returning(self.entity)
        return self.execute(session, stmt)

    def delete(self, session: Session = None, where: dict[str, Any] = None, **kwhere) -> int:
        """Elimina i record che soddisfano i criteri specificati.

        I filtri possono essere passati come dizionario ``where`` o come
        keyword arguments. Il commit viene eseguito automaticamente se la
        sessione è interna.

        Args:
            session (Session, optional): Sessione esterna. Se fornita, il commit
                non viene eseguito automaticamente.
            where (dict[str, Any], optional): Filtri come dizionario.
                Ha precedenza su ``**kwhere``.
            **kwhere: Filtri come keyword arguments.

        Returns:
            int: Numero di righe eliminate.

        Example:
            >>> repo.delete(id=5)
            >>> repo.delete(where={"active": False})
        """
        keep_open = False if session is None else True
        session = self.open_session if session is None else session
        num_rows = self._delete(session=session, where=where, **kwhere)
        if not num_rows or keep_open:
            return num_rows
        else:
            self.commit(session)
        session.close()
        return num_rows

    def _delete(self, session: Session, where: dict[str, Any] = None, **kwhere):
        if where is None:
            where = kwhere if kwhere else {}
        stmt = delete(self.entity)
        stmt = self.stmt_manager.prepare_statement(stmt=stmt, **where)
        try:
            result = session.execute(stmt)
        except Exception as e:
            self._handle_exception(session, e)
        else:
            return result.rowcount

    def upsert(self, session: Session = None, models: list[Type[BaseModel] | BaseModel] = None, parsing_model: Type[BaseModel] | BaseModel = None) -> list[Entity]:
        """Esegue un insert per i nuovi record e un update per quelli esistenti.

        Per ogni modello con chiave primaria valorizzata, verifica se il record
        esiste nel database:
        - Se esiste → aggiorna i campi sull'entità ORM esistente.
        - Se non esiste (o PK assente) → esegue un insert.

        Args:
            session (Session, optional): Sessione esterna.
            models (list[BaseModel], optional): Lista di modelli Pydantic da processare.
                I campi ``None`` vengono ignorati durante l'update (``exclude_none=True``).
            parsing_model (Type[BaseModel], optional): Modello alternativo per la
                serializzazione del risultato.

        Returns:
            list[Entity]: Lista di entità inserite e aggiornate.

        Example:
            >>> repo.upsert(models=[
            ...     UserModel(id=1, name="Mario"),   # → update
            ...     UserModel(name="Nuovo"),          # → insert
            ... ])
        """
        keep_open = False if session is None else True
        session = self.open_session if session is None else session
        entities = self._upsert(session=session, models=models)
        return self._return(session=session, entities=entities, keep_open=keep_open, commit=True, parsing_model=parsing_model)

    def _upsert(self, session: Session, models: list[Type[BaseModel] | BaseModel] = None):
        if models is None:
            models = []
        updates = {}
        for i, model in enumerate(models):
            pks = {pk.name: getattr(model, pk.name) for pk in self.entity.primary_key()}
            if any([not value for value in pks.values()]):
                continue
            else:
                updates[i] = session.get(self.entity, pks)
        inserts = [models[i] for i in range(len(models)) if i not in updates.keys()]

        result = self._insert(session=session, models=inserts)
        for i, entity in updates.items():
            if entity:
                for attr, value in models[i].model_dump(exclude_none=True).items():
                    setattr(entity, attr, value)

        result.extend(updates.values())

        return result

    def count(self, session: Session = None, where: dict[str, Any] = None, **kwhere):
        """Conta i record che soddisfano i criteri specificati.

        Esegue una query ``SELECT COUNT(pk)`` con i filtri forniti.

        Args:
            session (Session, optional): Sessione esterna.
            where (dict[str, Any], optional): Filtri come dizionario.
            **kwhere: Filtri come keyword arguments.

        Returns:
            int: Numero di record corrispondenti.

        Example:
            >>> total = repo.count(active=True)
        """
        keep_open = False if session is None else True
        session = self.open_session if session is None else session
        count_ = self._count(session=session, where=where, **kwhere)
        if keep_open:
            pass
        else:
            session.close()
        return count_

    def _count(self, session: Session, where: dict[str, Any] = None, **kwhere):
        pk = self.entity.primary_key()[0]
        if where is None:
            where = kwhere if kwhere else {}
        stmt = select(count(pk))
        stmt = self.stmt_manager.prepare_statement(stmt=stmt, **where)
        result = session.execute(stmt).all()[0]
        return result[0]

    def _preconf_count(self, session: Session, where: Optional[ColumnElement[Any]]):
        """Conta i record usando una clausola WHERE già costruita (ColumnElement).

        Usato internamente da ``_paging_find`` per riusare la clausola WHERE
        già applicata allo statement di selezione.

        Args:
            session (Session): Sessione corrente.
            where (ColumnElement): Clausola WHERE precostruita dallo statement.

        Returns:
            int: Numero totale di record corrispondenti.
        """
        pk = self.entity.primary_key()[0]
        stmt = select(count(pk))
        stmt = stmt.where(where)
        result = session.execute(stmt).all()[0]
        return result[0]

    def paging_find(self, session: Session = None, where: dict[str, Any] = None, columns: list[str] = None, exclude_columns: list[str] = None, limit: int = 0, page: int = 1, order_by: str = None, asc: bool = True,
                    parsing_model: Type[BaseModel] = None, **kwhere) -> PaginatorResponseModel[Entity]:
        """Esegue una ricerca paginata con supporto a ordinamento e offset.

        Calcola il numero totale di pagine in base al count reale dei record
        filtrati, e restituisce solo la pagina richiesta.

        Args:
            session (Session, optional): Sessione esterna.
            where (dict[str, Any], optional): Filtri come dizionario.
            columns (list[str], optional): Colonne da includere.
            exclude_columns (list[str], optional): Colonne da escludere.
            limit (int): Numero di elementi per pagina. Default: 0 (nessun limite).
            page (int): Numero di pagina richiesta (1-based). Default: 1.
            order_by (str, optional): Colonna per l'ordinamento.
            asc (bool): Ordinamento crescente se ``True``. Default: ``True``.
            parsing_model (Type[BaseModel], optional): Modello alternativo per
                la serializzazione.
            **kwhere: Filtri come keyword arguments.

        Returns:
            PaginatorResponseModel[Entity]: Oggetto con ``data``, ``tot_pages``,
                ``page``, ``limit``, ``order_by``, ``asc``.

        Example:
            >>> result = repo.paging_find(active=True, limit=20, page=2, order_by="name")
            >>> result.data        # lista degli elementi della pagina
            >>> result.tot_pages   # numero totale di pagine
        """
        keep_open = False if session is None else True
        session = self.open_session if session is None else session
        paginated = self._paging_find(session=session, where=where, columns=columns, exclude_columns=exclude_columns, limit=limit, page=page, order_by=order_by, asc=asc, **kwhere)
        if not keep_open:
            paginated.data = [parsing_model.model_validate(entity) for entity in paginated.data] if parsing_model else [self.model.model_validate(entity) for entity in paginated.data]
            session.close()
        return paginated

    def _paging_find(self, session: Session, where: dict[str, Any] = None, columns: list[str] = None, exclude_columns: list[str] = None, limit: int = 0, page: int = 1, order_by: str = None, asc: bool = True, **kwhere):
        if where is None:
            where = kwhere if kwhere else {}
        stmt = self._select(entity=self.entity, columns=columns, exclude_columns=exclude_columns)
        stmt = self.stmt_manager.prepare_statement(stmt=stmt, **where)

        row_numbers = self._preconf_count(session=session, where=stmt.whereclause)

        stmt = self.stmt_manager.limit_offset_condition(stmt=stmt, limit=limit, page=page)
        if order_by:
            stmt = self.stmt_manager.order_by_condition(stmt=stmt, order_by=order_by, asc=asc)

        entities = self.execute(session, stmt)
        return self.parse_pagination(limit=limit, page=page, order_by=order_by, count=row_numbers, asc=asc, data=entities)

    def parse_pagination(self, limit: int, page: int, order_by: str, asc: bool, count: int, data: Sequence[Row] | Sequence[Row | RowMapping] | Sequence[RowMapping]) -> PaginatorResponseModel:
        """Costruisce il ``PaginatorResponseModel`` dai dati di paginazione.

        Calcola il numero totale di pagine. Se ``limit`` è 0 (nessun limite),
        usa la lunghezza dei dati come limit effettivo. Se non viene fornito
        ``order_by``, usa la chiave primaria come campo di ordinamento di default.

        Args:
            limit (int): Numero di elementi per pagina.
            page (int): Pagina corrente.
            order_by (str): Campo di ordinamento usato.
            asc (bool): Direzione dell'ordinamento.
            count (int): Numero totale di record filtrati.
            data (Sequence): Entità della pagina corrente.

        Returns:
            PaginatorResponseModel: Risposta paginata completa.
        """
        limit = limit if limit else len(data)
        order_by = order_by if order_by else self.entity.primary_key()[0].name
        tot_pages = math.ceil(count / limit) if count and limit > 0 else 1

        return PaginatorResponseModel(limit=limit, page=page, order_by=order_by, asc=asc, tot_pages=tot_pages, data=data)

    def execute(self, session: Session, stmt: Select | Insert | Update | Delete, values: Sequence[Mapping[str, Any]] | Mapping[str, Any] = None):
        """Esegue uno statement SQLAlchemy e restituisce i risultati scalari.

        In caso di errore, delega la gestione a ``_handle_exception``.

        Args:
            session (Session): Sessione su cui eseguire lo statement.
            stmt (Select | Insert | Update | Delete): Statement da eseguire.
            values (Sequence[Mapping] | Mapping, optional): Parametri per
                statement bulk (es. valori per INSERT multiplo).

        Returns:
            list: Lista di risultati scalari (via ``.scalars().all()``).

        Raises:
            ServiceUnavailableException | EntityNotFoundException | BadRequestException:
                In caso di errori SQLAlchemy.
        """
        try:
            result = session.execute(statement=stmt, params=values)
        except Exception as e:
            self._handle_exception(session, e)
        else:
            rows = result.scalars().all()
            return rows
