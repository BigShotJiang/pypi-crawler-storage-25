__all__ = ["GeometryRepository"]

from typing import Any, Type

from geoalchemy2 import WKBElement, Geometry
from pydantic import BaseModel
from sqlalchemy import literal_column, Column
from sqlalchemy.orm import Session

from .crud_repository import CrudRepository
from ..base import Base


class GeometryRepository[Entity: Base | Type[Base]](CrudRepository[Entity]):
    """Repository ORM con operazioni spaziali PostGIS tramite GeoAlchemy2.

    Estende ``CrudRepository`` aggiungendo metodi per query geografiche:
    intersezione, contenimento e ricerca per prossimità. Gestisce
    automaticamente la riproiezione tra SRID diversi e il buffering geometrico.

    La sottoclasse deve definire l'attributo ``geom_column`` con la colonna
    geometrica su cui operare.

    Attributes:
        geom_column (Column[Geometry]): Colonna geometrica PostGIS dell'entità.

    Example:
        >>> class ZoneRepository(GeometryRepository[Zone]):
        ...     geom_column = Zone.geom
        ...
        >>> repo = ZoneRepository(entity=Zone, model=ZoneModel, engine=engine)
        >>> results = repo.intersects(geom=my_wkb_element)
    """
    __slots__ = "geom_column"
    geom_column: Column[Geometry]

    @property
    def geom_srid(self):
        """SRID della colonna geometrica configurata.

        Returns:
            int: SRID (es. 4326, 32632) della colonna geometrica.
        """
        return self.geom_column.type.srid

    def intersects(self, geom: WKBElement, session: Session = None, tolerance: float = 0.0, columns: list[str] = None, exclude_columns: list[str] = None, where: dict[str, Any] = None, not_where: dict[str, Any] = None,
                   limit: int = 0, geom_srid: int = 4326, parsing_model: Type[BaseModel] | BaseModel = None) -> list[Entity]:
        """Restituisce le entità la cui geometria interseca quella fornita.

        Supporta buffer opzionale, filtri aggiuntivi positivi e negativi,
        e riproiezione automatica se l'SRID della geometria differisce da
        quello della colonna.

        Args:
            geom (WKBElement): Geometria di riferimento per l'intersezione.
            session (Session, optional): Sessione esterna.
            tolerance (float): Buffer applicato alla geometria prima dell'intersezione
                (nelle unità del SRID della colonna). Default: 0.0 (nessun buffer).
            columns (list[str], optional): Colonne da includere nel risultato.
            exclude_columns (list[str], optional): Colonne da escludere.
            where (dict[str, Any], optional): Filtri aggiuntivi positivi.
            not_where (dict[str, Any], optional): Filtri aggiuntivi negativi (NOT).
            limit (int): Numero massimo di risultati. Default: 0 (nessun limite).
            geom_srid (int): SRID della geometria fornita. Default: 4326.
            parsing_model (Type[BaseModel], optional): Modello alternativo per
                la serializzazione.

        Returns:
            list[Entity]: Entità che intersecano la geometria fornita.

        Example:
            >>> repo.intersects(geom=point, tolerance=100.0, where={"active": True})
        """
        keep_open = False if session is None else True
        session = self.open_session if session is None else session
        entities = self._intersects(session=session, geom=geom, tolerance=tolerance, where=where, not_where=not_where, columns=columns, exclude_columns=exclude_columns, limit=limit, geom_srid=geom_srid)
        return self._return(session=session, entities=entities, keep_open=keep_open, commit=False, parsing_model=parsing_model)

    def _intersects(self, session: Session, geom: WKBElement, tolerance: float = 0.0, columns: list[str] = None, exclude_columns: list[str] = None, where: dict[str, Any] = None, not_where: dict[str, Any] = None,
                    limit: int = 0, geom_srid: int = 4326):
        if where is None:
            where = {}
        if not_where is None:
            not_where = {}

        stmt = self._select(entity=self.entity, columns=columns, exclude_columns=exclude_columns)

        intersecting_geom = self._geom_condition(geom=geom, geom_srid=geom_srid, buffer=tolerance)

        stmt = self.stmt_manager.prepare_statement(stmt=stmt, **where)
        stmt = self.stmt_manager.prepare_statement(stmt=stmt, neq=True, **not_where)

        stmt = stmt.where(self.geom_column.ST_Intersects(intersecting_geom))
        stmt = self.stmt_manager.limit_offset_condition(stmt=stmt, limit=limit)

        return self.execute(session, stmt)

    def contains(self, geom: WKBElement, session: Session = None, tolerance: float = 0.0, columns: list[str] = None, exclude_columns: list[str] = None, where: dict[str, Any] = None, limit: int = 0,
                 contained: bool = False, geom_srid: int = 4326, parsing_model: Type[BaseModel] | BaseModel = None) -> list[Entity]:
        """Restituisce le entità che contengono (o sono contenute in) una geometria.

        Il parametro ``contained`` inverte la direzione del contenimento:
        - ``False`` (default): cerca le entità la cui geometria **contiene** ``geom``.
        - ``True``: cerca le entità la cui geometria è **contenuta in** ``geom``.

        Args:
            geom (WKBElement): Geometria di riferimento.
            session (Session, optional): Sessione esterna.
            tolerance (float): Buffer applicato alla geometria. Default: 0.0.
            columns (list[str], optional): Colonne da includere.
            exclude_columns (list[str], optional): Colonne da escludere.
            where (dict[str, Any], optional): Filtri aggiuntivi.
            limit (int): Numero massimo di risultati. Default: 0.
            contained (bool): Se ``True``, inverte la direzione del contenimento.
                Default: ``False``.
            geom_srid (int): SRID della geometria fornita. Default: 4326.
            parsing_model (Type[BaseModel], optional): Modello alternativo.

        Returns:
            list[Entity]: Entità che soddisfano la condizione di contenimento.

        Example:
            >>> # Entità che contengono il punto:
            >>> repo.contains(geom=point)
            >>> # Entità contenute nel poligono:
            >>> repo.contains(geom=polygon, contained=True)
        """
        keep_open = False if session is None else True
        session = self.open_session if session is None else session
        entities = self._contains(session=session, geom=geom, tolerance=tolerance, where=where, contained=contained, columns=columns, exclude_columns=exclude_columns, limit=limit, geom_srid=geom_srid)
        return self._return(session=session, entities=entities, keep_open=keep_open, commit=False, parsing_model=parsing_model)

    def _contains(self, session: Session, geom: WKBElement, tolerance: float = 0.0, columns: list[str] = None, exclude_columns: list[str] = None, where: dict[str, Any] = None, limit: int = 0, contained: bool = False,
                  geom_srid: int = 4326):
        if where is None:
            where = {}

        stmt = self._select(entity=self.entity, columns=columns, exclude_columns=exclude_columns)
        stmt = self.stmt_manager.prepare_statement(stmt=stmt, **where)

        geom_condition = self._geom_condition(geom=geom, geom_srid=geom_srid, buffer=tolerance)
        geom_condition = self.geom_column.ST_Contains(geom_condition) if not contained else geom_condition.ST_Contains(self.geom_column)

        stmt = stmt.where(geom_condition)

        stmt = self.stmt_manager.limit_offset_condition(stmt=stmt, limit=limit)
        return self.execute(session, stmt)

    def nearest(self, geom: WKBElement, session: Session = None, columns: list[str] = None, exclude_columns: list[str] = None, limit: int = 1, where: dict[str, Any] = None, geom_srid: int = 4326,
                parsing_model: Type[BaseModel] | BaseModel = None) -> list[Entity]:
        """Restituisce le entità più vicine alla geometria fornita, ordinate per distanza.

        Aggiunge una colonna ``distance`` ai risultati con la distanza calcolata
        tramite ``ST_Distance``, e ordina i risultati in modo crescente.

        Args:
            geom (WKBElement): Geometria di riferimento per il calcolo della distanza.
            session (Session, optional): Sessione esterna.
            columns (list[str], optional): Colonne da includere.
            exclude_columns (list[str], optional): Colonne da escludere.
            limit (int): Numero di entità più vicine da restituire. Default: 1.
            where (dict[str, Any], optional): Filtri aggiuntivi.
            geom_srid (int): SRID della geometria fornita. Default: 4326.
            parsing_model (Type[BaseModel], optional): Modello alternativo.

        Returns:
            list[Entity]: Entità ordinate dalla più vicina alla più lontana.

        Example:
            >>> nearest = repo.nearest(geom=my_point, limit=5)
        """
        keep_open = False if session is None else True
        session = self.open_session if session is None else session
        entities = self._nearest(session=session, geom=geom, where=where, columns=columns, exclude_columns=exclude_columns, limit=limit, geom_srid=geom_srid)
        return self._return(session=session, entities=entities, keep_open=keep_open, commit=False, parsing_model=parsing_model)

    def _nearest(self, session: Session, geom: WKBElement, columns: list[str] = None, exclude_columns: list[str] = None, limit: int = 1, where: dict[str, Any] = None, geom_srid: int = 4326, distance: bool = True):
        if where is None:
            where = {}
        stmt = self._select(entity=self.entity, columns=columns, exclude_columns=exclude_columns)

        geom_condition = self._geom_condition(geom=geom, geom_srid=geom_srid)

        distance_col = self.geom_column.ST_Distance(geom_condition).label("distance")

        if distance:
            stmt = stmt.add_columns(distance_col)

        stmt = self.stmt_manager.prepare_statement(stmt=stmt, **where)
        stmt = stmt.order_by(literal_column("distance"))
        stmt = self.stmt_manager.limit_offset_condition(stmt=stmt, limit=limit)

        rows = self.execute(session, stmt)
        return rows

    def _geom_condition(self, geom: WKBElement, geom_srid: int = 4326, buffer: float = 0):
        """Prepara la geometria per le query applicando riproiezione e buffer.

        Se l'SRID della geometria fornita differisce da quello della colonna,
        applica ``ST_Transform``. Se è specificato un buffer > 0, applica
        ``ST_Buffer`` dopo la riproiezione.

        Args:
            geom (WKBElement): Geometria di input.
            geom_srid (int): SRID della geometria di input. Default: 4326.
            buffer (float): Distanza del buffer (nelle unità del SRID della colonna).
                0 = nessun buffer. Default: 0.

        Returns:
            WKBElement: Geometria pronta per l'uso nelle condizioni PostGIS.
        """
        geom_condition = geom.ST_Transform(self.geom_srid) if geom_srid != self.geom_srid else geom
        geom_condition = geom_condition.ST_Buffer(buffer) if buffer else geom_condition

        return geom_condition
