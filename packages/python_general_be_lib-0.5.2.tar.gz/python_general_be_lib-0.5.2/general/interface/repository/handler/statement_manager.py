__all__ = ["StatementManager"]

from ast import Delete
from typing import Type

from sqlalchemy import Select, Update

from general.exception.crud_exceptions import HasNoAttributeException
from .base_handler import BaseHandler


class StatementManager:
    """Orchestratore degli handler per la costruzione di statement SQLAlchemy.

    Gestisce una pipeline di ``BaseHandler`` che viene eseguita in sequenza
    per costruire le clausole WHERE, ORDER BY, LIMIT e OFFSET degli statement.

    L'ordine di esecuzione è: handler aggiuntivi (nell'ordine fornito) → handler base.

    Attributes:
        _handlers (list[BaseHandler]): Handler aggiuntivi registrati.
        _base_handler (BaseHandler): Handler principale, sempre eseguito per ultimo.
    """
    __slots__ = "_handlers", "_base_handler"

    def __init__(self, handlers: list[BaseHandler | Type[BaseHandler]] = None, base_handler: BaseHandler = None):
        """Inizializza il manager con la lista di handler e l'handler base obbligatorio.

        Args:
            handlers (list[BaseHandler], optional): Handler aggiuntivi da eseguire
                prima dell'handler base (es. ``JsonHandler``, ``ILikeHandler``).
            base_handler (BaseHandler): Handler principale per i filtri standard.
                Obbligatorio: solleva ``ValueError`` se non fornito.

        Raises:
            ValueError: Se ``base_handler`` non è fornito.
        """
        if not base_handler:
            raise ValueError("StatemantManager: base_handler is not set")
        self._handlers = handlers if handlers else []
        self._base_handler = base_handler

    def prepare_statement(self, stmt: Select | Update | Delete, neq: bool = False, **where):
        """Passa lo statement attraverso tutti gli handler registrati applicando i filtri WHERE.

        Ogni handler riceve lo statement e il dizionario ``where``, può modificarlo
        (es. estrarre le proprie chiavi) e restituisce lo statement aggiornato.
        L'handler base viene eseguito per ultimo con le chiavi rimanenti.

        Args:
            stmt (Select | Update | Delete): Statement su cui applicare i filtri.
            neq (bool): Se ``True``, applica la negazione a tutti i filtri. Default: ``False``.
            **where: Filtri come keyword arguments ``{colonna: valore}``.

        Returns:
            Select | Update | Delete: Statement con tutte le clausole WHERE applicate.
        """
        for handler in self._handlers:
            stmt = handler.handle(stmt=stmt, neq=neq, where=where)
        stmt = self._base_handler.handle(stmt=stmt, neq=neq, where=where)
        return stmt

    def order_by_condition(self, stmt: Select, order_by: str, asc: bool):
        """Aggiunge la clausola ORDER BY allo statement.

        Args:
            stmt (Select): Statement di selezione su cui aggiungere l'ordinamento.
            order_by (str): Nome della colonna per l'ordinamento.
            asc (bool): Se ``True``, ordinamento crescente (ASC); se ``False``, decrescente (DESC).

        Returns:
            Select: Statement con la clausola ORDER BY aggiunta.

        Raises:
            HasNoAttributeException: Se la colonna ``order_by`` non esiste sull'entità.
        """
        try:
            stmt = stmt.order_by(self._base_handler.columns[order_by].asc()) if asc else stmt.order_by(self._base_handler.columns[order_by].desc())
        except KeyError:
            raise HasNoAttributeException(order_by)
        return stmt

    def limit_offset_condition(self, stmt: Select, limit: int, page: int = None):
        """Aggiunge le clausole LIMIT e OFFSET allo statement per la paginazione.

        Non applica nessuna modifica se ``limit`` è 0 o negativo.
        L'offset viene calcolato come ``(page - 1) * limit``.

        Args:
            stmt (Select): Statement su cui applicare LIMIT/OFFSET.
            limit (int): Numero massimo di righe da restituire. 0 = nessun limite.
            page (int, optional): Numero di pagina (1-based). Se ``None`` o <= 0,
                non viene applicato nessun offset.

        Returns:
            Select: Statement con LIMIT e/o OFFSET applicati.
        """
        if limit and limit > 0:
            stmt = stmt.limit(limit)
            if page and page > 0:
                offset = (page - 1) * limit
                stmt = stmt.offset(offset)
        return stmt
