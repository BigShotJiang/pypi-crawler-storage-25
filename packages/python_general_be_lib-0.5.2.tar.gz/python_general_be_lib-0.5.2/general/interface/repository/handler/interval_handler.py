__all__ = ["IntervalHandler"]

from typing import Any

from sqlalchemy import Column, Select, Update, Delete, or_
from sqlalchemy.sql.base import ReadOnlyColumnCollection

from .base_handler import BaseHandler


class IntervalHandler(BaseHandler):
    """Handler per filtri su intervalli (range) di valori ordinabili.

    Gestisce coppie di parametri "da/a" (es. date, numeri) traducendoli in
    condizioni ``>=`` e ``<=``. Supporta la semantica di "infinito come NULL"
    per il limite superiore.

    Attributes:
        from\\_ (Any): Chiave nel dizionario ``where`` per il limite inferiore.
        to\\_ (Any): Chiave nel dizionario ``where`` per il limite superiore.
        inf_is_none (bool): Se ``True``, un valore ``NULL`` nella colonna ``to_``
            viene trattato come "senza limite superiore" (infinito).

    Example:
        >>> handler = IntervalHandler(
        ...     columns=Event.columns(),
        ...     from_="start_date",
        ...     to_="end_date",
        ...     inf_is_none=True
        ... )
        >>> repo.find(where={"start_date": "2024-01-01", "end_date": "2024-12-31"})
        # WHERE start_date >= '2024-01-01' AND (end_date <= '2024-12-31' OR end_date IS NULL)
    """
    __slots__ = "from_", "to_", "inf_is_none", "from_alias", "to_alias", "between"
    from_: Any
    to_: Any
    from_alias: str
    to_alias: str
    inf_is_none: bool

    def __init__(self, columns: ReadOnlyColumnCollection[str, Column[Any]], from_: Any = None, from_alias: str = None, to_: Any = None, to_alias: str = None, inf_is_none: bool = False):
        """Inizializza l'handler con le chiavi per il limite inferiore e superiore.

        Args:
            columns (ReadOnlyColumnCollection): Colonne della tabella.
            from\\_ (Any, optional): Chiave nel ``where`` per il limite inferiore
                (condizione ``>=``). Default: ``None`` (disabilitato).
            to\\_ (Any, optional): Chiave nel ``where`` per il limite superiore
                (condizione ``<=``). Default: ``None`` (disabilitato).
            inf_is_none (bool): Se ``True``, aggiunge ``OR col IS NULL`` alla
                condizione sul limite superiore per trattare NULL come infinito.
                Default: ``False``.
        """
        self.columns = columns
        self.from_ = from_
        self.to_ = to_
        self.from_alias = from_alias if from_alias else str(from_)
        self.to_alias = to_alias if to_alias else str(to_)
        self.inf_is_none = inf_is_none
        self.between = True if self.from_alias == self.to_alias else False

    def handle(self, stmt: Select | Update | Delete, where: dict[str, Any] = None, **kwargs):
        """Applica le condizioni di range allo statement estraendo i valori da ``where``.

        Estrae e rimuove in-place le chiavi ``from_`` e ``to_`` dal dizionario
        ``where``, quindi aggiunge le relative condizioni allo statement.
        Se una chiave non è presente in ``where``, quella condizione viene ignorata.

        Args:
            stmt (Select | Update | Delete): Statement su cui applicare le condizioni.
            where (dict[str, Any]): Dizionario dei filtri. Le chiavi di intervallo
                vengono estratte e rimosse in-place.
            **kwargs: Ignorati (compatibilità con l'interfaccia base).

        Returns:
            Select | Update | Delete: Statement con le condizioni di range aggiunte.

        Note:
            - Limite inferiore: ``col >= value``
            - Limite superiore: ``col <= value`` oppure ``(col <= value OR col IS NULL)``
              se ``inf_is_none=True``.
        """
        from_condition = where.pop(self.from_alias, None)
        to_condition = where.pop(self.to_alias, None) if not self.between else from_condition
        if from_condition:
            stmt = stmt.where(self.columns[self.from_] >= from_condition)
        if to_condition:
            condition = self.columns[self.to_] <= to_condition
            if self.inf_is_none:
                condition = or_(condition, self.columns[self.to_] == None)
            stmt = stmt.where(condition)
        return stmt
