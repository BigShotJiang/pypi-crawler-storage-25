__all__ = ["JsonHandler"]

from typing import Any

from sqlalchemy import Column, Select, Update, Delete
from sqlalchemy.sql.base import ReadOnlyColumnCollection

from .base_handler import BaseHandler


class JsonHandler(BaseHandler):
    """Handler per filtri su colonne di tipo JSON/JSONB.

    Intercetta automaticamente le chiavi nel dizionario ``where`` che non
    corrispondono a colonne reali della tabella e le interpreta come chiavi
    interne al campo JSON. Trova la prima colonna di tipo ``dict`` (JSON/JSONB)
    e applica filtri con ``col['key'].as_string() == str(value)``.

    Attributes:
        json_column (str): Nome della colonna JSON/JSONB rilevata automaticamente.

    Example:
        Se la tabella ha una colonna ``metadata`` di tipo JSONB e si vuole
        filtrare per ``metadata->>'status' = 'active'``:

        >>> handler = JsonHandler(entity.columns())
        >>> repo.find(where={"status": "active"})
        # "status" non è una colonna → viene cercato dentro il campo JSON
    """
    __slots__ = "json_column"
    json_column: str

    def __init__(self, columns: ReadOnlyColumnCollection[str, Column[Any]]):
        """Inizializza l'handler rilevando automaticamente la colonna JSON.

        Itera sulle colonne e seleziona la prima con ``python_type == dict``.
        Le colonne che non supportano ``python_type`` (es. geometrie) vengono ignorate.

        Args:
            columns (ReadOnlyColumnCollection): Colonne della tabella.
        """
        self.columns = columns
        for key, column in columns.items():
            try:
                if column.type.python_type == dict:
                    self.json_column = key
                    break
            except NotImplementedError:
                continue

    def handle(self, stmt: Select | Update | Delete, where: dict[str, Any] = None, **kwargs):
        """Estrae i filtri JSON dal dizionario ``where`` e li applica allo statement.

        Le chiavi in ``where`` non presenti tra le colonne della tabella vengono
        considerate chiavi JSON e rimosse dal dizionario (per non essere processate
        dagli handler successivi). Per ognuna viene aggiunta la condizione
        ``json_col['key'].as_string() == str(value)``.

        Args:
            stmt (Select | Update | Delete): Statement su cui applicare i filtri.
            where (dict[str, Any]): Dizionario dei filtri. Le chiavi JSON vengono
                estratte e rimosse in-place.
            **kwargs: Ignorati (compatibilità con l'interfaccia base).

        Returns:
            Select | Update | Delete: Statement con le condizioni JSON aggiunte.
        """
        json_keys = {key for key in where.keys() if key not in self.columns}
        json_conditions = {key: where.pop(key) for key in json_keys}
        stmt = stmt.where(*[self.columns[self.json_column][key].as_string() == str(value) for key, value in json_conditions.items()])
        return stmt
