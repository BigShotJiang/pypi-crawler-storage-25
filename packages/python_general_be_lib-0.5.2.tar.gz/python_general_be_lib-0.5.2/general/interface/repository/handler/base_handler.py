__all__ = ["BaseHandler"]

from typing import Any

from sqlalchemy import Select, Update, Delete, Column, not_
from sqlalchemy.sql.base import ReadOnlyColumnCollection


class BaseHandler:
    """Handler base per la costruzione di filtri WHERE su statement SQLAlchemy.

    Gestisce i casi standard di uguaglianza, liste (``IN``) e colonne di tipo
    ``ARRAY``. Può essere esteso per supportare logiche di filtraggio personalizzate.

    Attributes:
        columns (ReadOnlyColumnCollection): Colonne della tabella su cui operare.
    """
    __slots__ = "columns"

    def __init__(self, columns: ReadOnlyColumnCollection[str, Column[Any]]):
        """Inizializza l'handler con la collezione di colonne dell'entità.

        Args:
            columns (ReadOnlyColumnCollection): Colonne della tabella, tipicamente
                ottenute da ``Entity.__table__.c``.
        """
        self.columns = columns

    def handle(self, stmt: Select | Update | Delete, neq: bool = False, where: dict[str, Any] = None):
        """Applica i filtri WHERE allo statement per tutte le coppie chiave-valore in ``where``.

        Per ogni coppia ``{colonna: valore}`` delega la costruzione della condizione
        a ``_handle`` e la aggiunge allo statement con ``.where()``.

        Args:
            stmt (Select | Update | Delete): Statement SQLAlchemy su cui applicare i filtri.
            neq (bool): Se ``True``, applica la negazione (``NOT``) a ogni condizione.
                Default: ``False``.
            where (dict[str, Any]): Dizionario ``{nome_colonna: valore}`` con i filtri.

        Returns:
            Select | Update | Delete: Statement arricchito con le clausole WHERE.
        """
        stmt = stmt.where(*[self._handle(column=self.columns[column], condition=condition, neq=neq) for column, condition in where.items()])
        return stmt

    def _handle(self, column: Column, condition: Any, neq: bool = False):
        """Costruisce la singola condizione WHERE per una colonna.

        Logica applicata:
        - ``list`` → ``col IN (values)``
        - Tipo ``ARRAY`` → ``value = ANY(col)``
        - Scalare → ``col == value``

        Se ``neq=True``, la condizione viene negata con ``NOT``.

        Args:
            column (Column): Colonna SQLAlchemy su cui applicare la condizione.
            condition (Any): Valore o lista di valori da confrontare.
            neq (bool): Se ``True``, nega la condizione. Default: ``False``.

        Returns:
            ColumnElement: Espressione booleana SQLAlchemy.
        """
        eq_where = column.in_(condition) if isinstance(condition, list) else column == condition if str(column.type) != "ARRAY" else condition == column.any_()
        if neq:
            eq_where = not_(eq_where)
        return eq_where
