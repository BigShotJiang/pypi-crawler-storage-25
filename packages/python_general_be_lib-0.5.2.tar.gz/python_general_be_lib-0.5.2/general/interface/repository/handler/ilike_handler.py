__all__ = ["ILikeHandler"]

from typing import Any

from sqlalchemy import Column, Select, Update, Delete, or_
from sqlalchemy.sql.base import ReadOnlyColumnCollection

from .base_handler import BaseHandler


class ILikeHandler(BaseHandler):
    """Handler per ricerche case-insensitive (ILIKE) su più colonne tramite un alias.

    Permette di esporre un singolo parametro di ricerca testuale (es. ``"search"``)
    che viene applicato come ``ILIKE '%value%'`` su un insieme di colonne con ``OR``.

    Attributes:
        ilike_aliases (list[str]): Chiavi nel dizionario ``where`` che attivano
            la ricerca ILIKE (es. ``["search", "q"]``).
        ilike_attributes (list[str]): Nomi delle colonne su cui applicare ILIKE
            (es. ``["name", "surname", "email"]``).

    Example:
        >>> handler = ILikeHandler(
        ...     columns=User.columns(),
        ...     ilike_aliases=["search"],
        ...     ilike_attributes=["name", "surname"]
        ... )
        >>> repo.find(where={"search": "mario"})
        # WHERE name ILIKE '%mario%' OR surname ILIKE '%mario%'
    """
    __slots__ = "ilike_aliases", "ilike_attributes"
    ilike_aliases: list[str]
    ilike_attributes: list[str]

    def __init__(self, columns: ReadOnlyColumnCollection[str, Column[Any]], ilike_aliases: list[str] = None, ilike_attributes: list[str] = None):
        """Inizializza l'handler validando che le colonne ILIKE esistano sull'entità.

        Args:
            columns (ReadOnlyColumnCollection): Colonne della tabella.
            ilike_aliases (list[str], optional): Chiavi alias che attivano la ricerca.
                Default: lista vuota.
            ilike_attributes (list[str], optional): Colonne su cui applicare ILIKE.
                Default: lista vuota.

        Raises:
            ValueError: Se uno degli ``ilike_attributes`` non è presente tra le colonne.
        """
        self.columns = columns
        self.ilike_aliases = ilike_aliases if ilike_aliases is not None else []
        self.ilike_attributes = ilike_attributes if ilike_attributes is not None else []

        for ilike_attribute in self.ilike_attributes:
            if ilike_attribute not in self.columns:
                raise ValueError(f"{ilike_attribute} not in columns")

    def handle(self, stmt: Select | Update | Delete, where: dict[str, Any] = None, **kwargs):
        """Applica i filtri ILIKE allo statement per ogni alias trovato in ``where``.

        Per ogni alias presente in ``ilike_aliases`` e trovato in ``where``,
        estrae il valore, lo rimuove dal dizionario e aggiunge la condizione ILIKE
        su tutte le colonne in ``ilike_attributes`` con ``OR``.

        Args:
            stmt (Select | Update | Delete): Statement su cui applicare i filtri.
            where (dict[str, Any]): Dizionario dei filtri. Gli alias ILIKE vengono
                estratti e rimossi in-place.
            **kwargs: Ignorati (compatibilità con l'interfaccia base).

        Returns:
            Select | Update | Delete: Statement con le condizioni ILIKE aggiunte.
        """
        for alias in self.ilike_aliases:
            condition = where.pop(alias, None)
            if condition:
                stmt = stmt.where(self._handle(alias, condition))
        return stmt

    def _handle(self, alias: str, condition: str, neq: bool = False):
        """Costruisce la condizione ILIKE con OR su tutte le colonne configurate.

        Args:
            alias (str): Alias attivato (usato per identificare la ricerca, non la colonna).
            condition (str): Stringa da cercare (viene wrappata con ``%``).
            neq (bool): Non utilizzato in questa implementazione.

        Returns:
            ColumnElement: Espressione ``OR(col1 ILIKE '%val%', col2 ILIKE '%val%', ...)``.
        """
        return or_(*[self.columns[col].ilike(f'%{condition}%') for col in self.ilike_attributes])
