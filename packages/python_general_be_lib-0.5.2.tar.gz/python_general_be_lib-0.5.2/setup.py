from setuptools import setup, find_packages

setup(
    name="python-general-be-lib",
    version="0.5.2",
    packages=find_packages(include=["general*"]),
    python_requires=">=3.12",
    install_requires=[
        "fastapi>=0.100.0",
        "pydantic>=2.0.0",
        "sqlalchemy>=2.0.0",
        "geoalchemy2>=0.14.0",
    ],
)