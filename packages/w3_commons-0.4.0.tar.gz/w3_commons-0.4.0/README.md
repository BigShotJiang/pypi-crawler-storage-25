# Python commons module
This Python package provides common functions, utility functions and classes that are used in several other our projects.

## Dependencies
UV is used to manage dependencies. Examples:

- Installing: ```uv sync --locked --no-editable ```


## Build

```
uv build
```

## Running Tests

```
uv run pytest
```

## Development

Common rules: [Python Development](https://github.com/unitprotocol/wiki/wiki/Python-Development)