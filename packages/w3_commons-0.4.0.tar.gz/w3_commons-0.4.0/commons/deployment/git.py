import subprocess
from typing import List


class GitRepo:
    """
    Simple minimum required git client.
    """

    def __init__(self, path):
        """
        :param path: path to root of git repository.
        """
        self.path = path

    def _call(self, *args) -> str:
        return subprocess.check_output(['git', *args], cwd=self.path).decode()

    @property
    def is_clean(self) -> bool:
        """
        Check if repository is clean.
        """
        return self._call('status', '--short') == ''

    @property
    def active_branch(self) -> str:
        """
        Get active branch name.
        """
        return [
            b[1:].strip()
            for b in self._call('branch').split('\n') if b.startswith('*')
        ][0]

    @property
    def branches(self) -> List[str]:
        """
        Get list of all branches.
        """
        return [
            b[1:].strip()
            for b in self._call('branch', '--all').split('\n')
        ]

    def rev_parse(self, rev: str, short: bool = False) -> str:
        """
        Get result of `git rev-parse`
        """
        args = ['rev-parse']
        if short:
            args.append('--short')
        args.append(rev)
        return self._call(*args).strip()
