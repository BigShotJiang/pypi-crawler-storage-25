import os
import re
from functools import lru_cache
from subprocess import call, DEVNULL
from typing import List

import sys
from argparse import ArgumentParser
from os.path import join, dirname, realpath

from commons.cli import CliCommand, CommandError
from commons.deployment.git import GitRepo
from commons.utils import cached_property


class DockerRunner(CliCommand):
    """
    Command for managing build and invocation of dockerized stuff.
    """

    description = "Manages build & invocation of dockerized stuff."
    epilog = "Folders config/ and data/ in the current directory will be mounted as config and data dir respectively."
    allow_extra_args = True

    _root_dir: str
    _default_image_name: str

    def __init__(self, root_dir: str, default_image_name: str = None) -> None:
        """
        :param root_dir: Root dir of project
        :param default_image_name: image name that will be used by default if not passed in command args
        """
        super().__init__()
        self._root_dir = root_dir
        self._default_image_name = default_image_name

    def _add_base_arguments(self, parser: ArgumentParser):
        super()._add_base_arguments(parser)
        subparsers = parser.add_subparsers(
            title='subcommands',
            help='(see subcommand help at subcommand --help)'
        )
        self._add_build_arguments(subparsers)
        self._add_start_arguments(subparsers)
        self._add_stop_arguments(subparsers)
        self._add_tools_arguments(subparsers)

    def _add_build_arguments(self, subparsers):
        p_build = subparsers.add_parser('build', help='Builds a metadata oracle docker image.')
        p_build.set_defaults(func=self.build)
        p_build.add_argument('--code-artifact-auth-token', help='AWS CodeArtifact Auth Token', required=True)
        p_build.add_argument('--dirty', action='store_true', help='Allow build for non-clean git repository')
        p_build.add_argument('--tags', nargs='+', default=[], help='Additional tags to docker image')
        p_build.add_argument('--labels', nargs='+', default=[], help='Additional labels to docker image')
        p_build.add_argument('--build-arg', nargs='+', default=[], help='--build-arg to pass to docker build')
        p_build.add_argument(
            '--image-name', type=str, default=self._default_image_name,
            help='Image (repository) name, defaults to ' + self._default_image_name
        )
        p_build.add_argument('--push', action='store_true', help='Push image and the tags to the repository after build')
        return p_build

    def _add_start_arguments(self, subparsers):
        p_start = subparsers.add_parser('start',
                                        help='Starts the daemon in docker (extra args are forwarded to the daemon).')
        p_start.add_argument('--name', type=str, help='container name to use instead of the default')
        p_start.add_argument('--tag', default='latest', help='Tag to select the desired docker image')
        p_start.set_defaults(func=self.start)
        return p_start

    def _add_stop_arguments(self, subparsers):
        p_stop = subparsers.add_parser('stop', help='Stops the dockerized daemon.')
        p_stop.add_argument('--name', type=str, help='container name to use instead of the default')
        p_stop.set_defaults(func=self.stop)
        return p_stop

    def _add_tools_arguments(self, subparsers):
        tools = set()
        for dir_path, _, filenames in os.walk(self._bin_dir):
            assert dir_path.startswith(self._bin_dir)
            if not filenames:
                continue
            subdir = re.sub(f'^{re.escape(os.path.sep)}+', '', dir_path[len(self._bin_dir):])
            for filename in filenames:
                tools.add(filename if not subdir else os.path.join(subdir, filename))

        for tool_name in sorted(tools - {'fo-daemon'}, key=lambda t: (1 if '/' in t else 0, t)):
            self._add_tool_arguments(tool_name, subparsers)

    def _add_tool_arguments(self, tool_name: str, subparsers):
        p_tool = subparsers.add_parser(tool_name, help=f'Runs {tool_name} tool (extra args are forwarded to the tool).')
        p_tool.add_argument('--tag', default='latest', help='Tag to select the desired docker image')
        p_tool.set_defaults(func=self.tool)
        p_tool.set_defaults(tool_name=tool_name)
        return p_tool

    def handle(self):
        sys.exit(
            self.args.func()
        )

    def build(self):
        """
        Run docker build and push if needed
        """
        tags = self._get_tags()
        labels = self._get_labels()
        rc = self._build_image(tags, labels)

        if self.args.push and rc == 0:
            rc = self._push_image(tags)
        return rc

    @property
    def _bin_dir(self):
        return os.path.join(self._root_dir, 'bin')

    @cached_property
    def _git_repo(self) -> GitRepo:
        repo = GitRepo(self._root_dir)
        if self._repo_is_dirty(repo) and not self.args.dirty:
            raise CommandError('Git repository is not clean')
        return repo

    @lru_cache(maxsize=None)
    def _repo_is_dirty(self, repo: GitRepo):
        return not repo.is_clean

    def _get_tags(self):
        return self.args.tags + self._get_tags_by_repo() or ['latest']

    def _get_tags_by_repo(self):
        """
        Get image tags from git repository.
        """
        commit_short = self._git_repo.rev_parse('HEAD', short=True)
        tags = [commit_short + ('-dirty' if not self._git_repo.is_clean else '')]

        def is_release_branch(name):
            return re.match(r'release-\d\.\d(\.\d)?$', name)

        def get_version(name):
            return name.split('-', 1)[-1]

        branch_name = self._git_repo.active_branch
        if is_release_branch(branch_name):
            version = get_version(branch_name)
            all_versions = sorted(
                [get_version(branch) for branch in self._git_repo.branches if is_release_branch(branch)],
                key=lambda v: [int(v) for v in v.split('.')]
            )
            if version == all_versions[-1]:
                tags.append('latest')
            tags.append(version)

        return tags

    def _get_labels(self):
        return self.args.labels + self._get_labels_by_repo()

    def _get_labels_by_repo(self) -> List[str]:
        """
        Get image labels from git repository.
        """
        commit = self._git_repo.rev_parse('HEAD')
        return [
            f"GitCommit={commit + ('-dirty' if not self._git_repo.is_clean else '')}",
        ]

    def _build_image(self, tags: List[str], labels: List[str]):
        cmd = ['docker', 'build']
        cmd.extend(
            self._get_build_docker_args(tags, labels)
        )
        return call(cmd)

    def _get_build_docker_args(self, tags: List[str], labels: List[str]):
        args = []
        for tag in tags:
            args.extend(['-t', f'{self.image_name}:{tag}'])
        for label in labels:
            args.extend(['--label', label])
        for arg in self.args.build_args:
            args.extend(['--build-arg', arg])
        args.extend([
            '-f', join(dirname(__file__), 'Dockerfile'),
            realpath(join(dirname(__file__), '..'))
        ])
        return args

    def _push_image(self, tags: List[str]):
        rc = 0
        for tag in tags:
            rc = call(['docker', 'push', f'{self.args.image_name}:{tag}'])
            if rc != 0:
                break
        return rc

    def start(self):
        """
        Run docker container. If the container already exists, it will be removed.
        """
        container_name = self._get_container_name()
        call(['docker', 'rm', container_name], stdout=DEVNULL, stderr=DEVNULL)

        start_params = [
            'docker', 'docker', 'run',
        ]
        start_params.extend(self._get_run_docker_args(container_name))
        os.execlp(*start_params)  # does not return

    def _get_run_docker_args(self, container_name: str):
        cmd = [
            '-d',
            '--name', container_name,
            '--network', 'host',
            *self._get_mounts()
        ]
        cmd.extend([
            f'{self.args.image_name}:{self.args.tag}',
            *self.extra_args
        ])
        return cmd

    def stop(self):
        """
        Stop docker container.
        """
        self._no_extra_args()
        return call(['docker', 'stop', '-t', '15', self._get_container_name()])

    def tool(self):
        """
        Run command within docker container with tool's entrypoint.
        """
        image_name_with_tag = f'{self.args.image_name}:{self.args.tag}'
        os.execlp('docker', 'docker', 'run', '-it', '--rm',
                  '--network', 'host',
                  *self._get_mounts(),
                  '--entrypoint', '/app/venv/bin/python3',
                  image_name_with_tag,
                  f'/app/bin/{self.args.tool_name}', *self.extra_args)

    def _no_extra_args(self):
        if self.extra_args:
            raise CommandError(f'Unrecognized arguments: {self.extra_args}')

    def _get_container_name(self):
        return self.args.name

    @staticmethod
    def _get_mounts() -> List[str]:
        result = list()
        for dir_ in ('config', 'data'):
            if not os.path.isdir(dir_):
                raise CommandError(f'Subdirectory {dir_}/ is not found in the current working dir')
            result.extend(['-v', f'{realpath(dir_)}:/app/{dir_}'])
        return result
