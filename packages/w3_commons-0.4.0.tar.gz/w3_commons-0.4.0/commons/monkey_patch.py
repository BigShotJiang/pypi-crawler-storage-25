"""
:mod:`unitprotocol.monkey_patch` - collection of (hopefully temporary) monkey patches
"""
from commons.utils import locked


def patch_web3_websocket_provider():
    """
    Fix for web3 using non-thread safe WebsocketProvider constructor.
    """
    import threading
    import web3.providers.websocket
    from typing import Optional, Union, Any
    from eth_typing import URI

    class WebsocketProvider(web3.providers.websocket.WebsocketProvider):
        """
        A thread-safe implementation of the `web3.providers.websocket.WebsocketProvider` class.
        """
        _lock = threading.Lock()

        def __init__(self, endpoint_uri: Optional[Union[URI, str]] = None, websocket_kwargs: Optional[Any] = None,
                     websocket_timeout: int = web3.providers.websocket.DEFAULT_WEBSOCKET_TIMEOUT) -> None:
            with locked(self._lock):
                super().__init__(endpoint_uri, websocket_kwargs, websocket_timeout)

    web3.WebsocketProvider = WebsocketProvider
    web3.providers.WebsocketProvider = WebsocketProvider
    web3.providers.websocket.WebsocketProvider = WebsocketProvider
