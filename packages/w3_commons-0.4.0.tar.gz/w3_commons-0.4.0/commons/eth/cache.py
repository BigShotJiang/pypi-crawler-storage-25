import os
from abc import ABC, abstractmethod
from enum import Enum, auto
from logging import Logger
from os.path import dirname
from typing import Dict

from eth_typing import HexStr
from eth_utils import to_hex

from commons.eth.utils import clean_web3_data, retry_w3_call
from commons.io import json_save, json_load
from commons.log import get_class_logger
from commons.type_check import check_dict

from web3.exceptions import BlockNotFound, TransactionNotFound


class _Web3Cache(ABC):
    """
    Web3 entities disk-based cache base class.
    """
    _web3: "Web3"
    _cache_file: str
    _entity_name: str
    _not_found_ex: type
    _auto_flush_percent: int

    logger: Logger

    _cache: Dict[str, dict] = None
    _initial_size: int = None

    def __init__(self, web3: "Web3", cache_file: str, entity_name: str, not_found_ex: type,
                 preload_cache: bool = False, auto_flush_percent: int = 10):
        """
        Ctor.
        :param cache_file: file to use (you might want to have separate caches, not a huge pile)
        :param entity_name: user-friendly name of cached entities
        :param not_found_ex: exception type signaling that an entity is not on chain
        :param preload_cache: load cache from disk immediately
        :param auto_flush_percent: flush cache after this percent growth (use None to disable auto-flush)
        """
        self._web3 = web3
        self._cache_file = cache_file
        self._entity_name = entity_name
        assert issubclass(not_found_ex, Exception)
        self._not_found_ex = not_found_ex
        self._auto_flush_percent = auto_flush_percent

        self.logger = get_class_logger(self)

        if preload_cache:
            self._get_cache()

    @abstractmethod
    def _fetch(self, hash_):
        """
        Must fetch an entity from a node
        :param hash_: entity hash
        :return: serialization-friendly entity structure
        """
        raise NotImplementedError()

    def __getitem__(self, hash_):
        hash_ = (hash_ if isinstance(hash_, str) else to_hex(hash_)).lower()    # canonical form

        self._get_cache()
        if hash_ not in self._cache:
            self._cache[hash_] = self._fetch(hash_)

            if self._auto_flush_percent is not None:
                if 0 == self._initial_size:
                    if len(self._cache) >= 100:
                        self.flush()
                else:
                    if len(self._cache) / self._initial_size >= 1 + self._auto_flush_percent / 100:
                        self.flush()

        return self._cache[hash_]

    def __contains__(self, item):
        try:
            dummy = self[item]
            return True
        except self._not_found_ex:
            return False

    def __setitem__(self, key, value):  # not an abstract method
        raise NotImplementedError()

    def __len__(self):
        return len(self._get_cache())

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.flush()

    def flush(self):
        if self._cache is None:
            return

        assert len(self._cache) >= self._initial_size
        if len(self._cache) == self._initial_size:
            return

        cache_dir = dirname(self._cache_file)
        if cache_dir:
            os.makedirs(cache_dir, exist_ok=True)

        json_save(self._cache_file, self._cache)
        self._initial_size = len(self._cache)
        self.logger.debug('%s', f'flush: saved {len(self._cache)} cached {self._entity_name}s')

    def _get_cache(self) -> Dict[str, dict]:
        # TODO sqlite/leveldb/mongodb
        if self._cache is None:
            if os.path.exists(self._cache_file):
                self._cache = check_dict(json_load(self._cache_file))
            else:
                self._cache = dict()

            self._initial_size = len(self._cache)
            self.logger.debug('%s', f'_get_cache: loaded {self._initial_size} cached {self._entity_name}s')

        return self._cache


class TxCache(_Web3Cache):
    r"""
    Caches transactions info.

    .. code-block:: python
    c = TxCache(web3, cache_file)
    if c[tx_hash]['input'] ...
    # ...
    c.flush()
    """

    def __init__(self, web3: "Web3", cache_file: str, preload_cache: bool = False):
        """
        Ctor.
        :param cache_file: file to use (you might want to have separate caches, not a huge pile)
        :param preload_cache: load cache from disk immediately
        """
        super().__init__(web3, cache_file, 'transaction', TransactionNotFound, preload_cache)

    def _fetch(self, hash_):
        """
        Gets transaction info & receipt.
        :param hash_: tx hash
        :return: non-typed dict

        Throws TransactionNotFound if transaction is not found.
        """
        data = check_dict(clean_web3_data(retry_w3_call(lambda: self._web3.eth.get_transaction(HexStr(hash_)))))
        data.update(check_dict(clean_web3_data(retry_w3_call(
            lambda: self._web3.eth.get_transaction_receipt(HexStr(hash_))))))

        return data


class BlockCache(_Web3Cache):
    r"""
    Caches block info.

    .. code-block:: python
    c = BlockCache(web3, cache_file, BlockCache.TxCacheMode.NONE)
    print(c[block_hash]['timestamp'])
    # ...
    c.flush()
    """
    class TxCacheMode(Enum):
        """
        Mode of block transaction info retrieval & caching.
        """
        # No transaction info
        NONE = auto()
        # Only list of hashes
        HASHES = auto()
        # Full transactions info
        FULL = auto()

    _mode: TxCacheMode

    def __init__(self, web3: "Web3", cache_file: str, mode: TxCacheMode, preload_cache: bool = False):
        """
        Ctor.
        :param cache_file: file to use (you might want to have separate caches, not a huge pile)
        :param preload_cache: load cache from disk immediately
        """
        super().__init__(web3, cache_file, 'block', BlockNotFound, preload_cache)
        self._mode = mode

    def _fetch(self, hash_):
        """
        Gets block data.
        :param hash_: block hash
        :return: non-typed dict

        Throws BlockNotFound if block is not found.
        """
        def custom_repeater(exc: Exception):
            if isinstance(exc, BlockNotFound):
                return False
            return None

        data = check_dict(clean_web3_data(retry_w3_call(
            lambda: self._web3.eth.get_block(
                block_identifier=HexStr(hash_),
                full_transactions=self._mode is BlockCache.TxCacheMode.FULL
            ),
            custom_repeater=custom_repeater
        )))

        if self._mode is BlockCache.TxCacheMode.NONE:
            data.pop('transactions')

        return data
