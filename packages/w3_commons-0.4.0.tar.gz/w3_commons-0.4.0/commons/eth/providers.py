import re
from logging import Logger
from typing import List, Union, Any, Dict, Callable, Optional, Tuple

import requests
from web3 import Web3
from web3.middleware import simple_cache_middleware
from web3.providers import JSONBaseProvider, WebsocketProvider, HTTPProvider
from web3.types import RPCEndpoint, RPCResponse
from web3.datastructures import NamedElementOnion
from web3.providers.auto import WS_SCHEMES, HTTP_SCHEMES
from urllib.parse import urlparse
from eth_typing import URI

from commons.eth import ProtocolNotSupported, RPCProviderError, is_transient_rpc_error
from commons.eth.utils import is_poa
from commons.exceptions import AppError
from commons.log import get_class_logger


def get_web3_with_multi_provider(
        uri_list: List[str],
        private_key: str = None,
        timeout: float = None,
        use_tx2: bool = None,
        get_requests_kwargs: Callable[[str], Dict] = None,
        get_session: Callable[[URI], Optional[requests.Session]] = None,
) -> Web3:
    """
    Create Web3 instance with `MultiProvider` for given settings.

    :param uri_list: List of URIs for the web3 providers
    :param private_key: Private key for signing transactions
    :param timeout: Timeout for the request
    :param use_tx2: Use EIP-1559 support for transaction making. If not specified, it will be detected implicitly
    :param get_requests_kwargs: A callable function to get the requests kwargs for each provider uri
    :param get_session: A function returning custom http session for the given url. If no session is returned,
    the default one will be automatically created and cached by web3 lib.
    :return: A web3 object with multiple providersWeb3
    raises: ProtocolNotSupported: If one of the uris has unsupported protocol.
    """
    if get_requests_kwargs is None:
        def get_requests_kwargs(_):
            return {}

    def no_retries(middleware):
        if isinstance(middleware, NamedElementOnion):
            try:
                middleware.remove('http_retry_request')  # that is handled by us
            except ValueError:  # not found
                pass
        elif isinstance(middleware, (list, tuple)) and 'http_retry_request' not in (m[1] for m in middleware):
            pass
        else:
            raise AppError(f'Don\'t know how to work with middleware {type(middleware)}')

    def make_http_provider(uri: URI, request_kwargs: Dict):
        params = get_requests_kwargs(str(uri)) or {}
        params.update(request_kwargs)
        custom_session = get_session and get_session(uri)

        http_provider = HTTPProvider(uri, params, custom_session)
        no_retries(http_provider.middlewares)
        return http_provider

    uri_list = [URI(x) for x in uri_list]
    http_request_kwargs = {'timeout': timeout} if timeout is not None else {}
    providers = []
    for uri in uri_list:
        parsed_uri = urlparse(uri)
        if parsed_uri.scheme in WS_SCHEMES:
            providers.append(WebsocketProvider(uri, {'max_size': 100_000_000}))
        elif parsed_uri.scheme in HTTP_SCHEMES:
            providers.append(make_http_provider(uri, http_request_kwargs))
        else:
            raise ProtocolNotSupported(f'Protocol "{parsed_uri.scheme}" is not supported.')
    multi_provider = MultiProvider(providers)

    w3 = Web3(multi_provider)

    if private_key is not None:
        from web3.middleware import construct_sign_and_send_raw_middleware
        from eth_account import Account

        account = Account.from_key(private_key.strip())
        w3.middleware_onion.add(construct_sign_and_send_raw_middleware(account))
        w3.eth.default_account = account.address

    if use_tx2 is not None:
        from commons.eth.transactions import _tx2_support_cache
        from commons.eth.utils import retry_w3_call
        chain_id = retry_w3_call(lambda: w3.eth.chain_id)
        _tx2_support_cache[chain_id] = use_tx2

    "That 's our performance hint. No big problem if erroneously detected."
    for uri in uri_list:
        parsed = urlparse(uri)
        if re.search(r'\.infura\.io\.?$', parsed.hostname, re.I):
            w3.limited_node = True
            break

    no_retries(w3.middleware_onion)

    if is_poa(w3):
        from web3.middleware import geth_poa_middleware
        w3.middleware_onion.inject(geth_poa_middleware, layer=0)

    w3.middleware_onion.add(simple_cache_middleware)

    return w3


class MultiProvider(JSONBaseProvider):
    """
    Multi endpoint uri supported. Move unsuccessful endpoint uri to end of list.
    Http and websocket uri supported.
    """
    _providers: List[Tuple[int, Union[HTTPProvider, WebsocketProvider]]] = []
    _count_before_restore_order: int
    _requests_before_reset_order: int
    logger: Logger = None

    def __init__(
        self,
        providers: List[Union[WebsocketProvider, HTTPProvider]],
        requests_before_reset_order: Union[int, None] = None,
    ):
        """
        @param providers: list of WebsocketProvider or HTTPProvider
        @param requests_before_reset_order: number of requests before order is restored. len(providers) + 20 default
        """
        super().__init__()
        self.logger = get_class_logger(self)
        self._providers = list(enumerate(providers))
        self._requests_before_reset_order = requests_before_reset_order or (len(self._providers) + 20)
        self._count_before_restore_order = self._requests_before_reset_order

    def make_request(self, method: RPCEndpoint, params: Any) -> RPCResponse:
        """
        Make RPCEndpoint request by first provider in provider list, and return
        result id success and move current provider to and of list of providers id unsuccess
        """
        if self._providers[0][0] != 0:  # the order is broken
            self._count_before_restore_order -= 1
            if self._count_before_restore_order < 0:
                self._count_before_restore_order = self._requests_before_reset_order
                self._providers = sorted(self._providers, key=lambda x: x[0])
                self.logger.info("Provider's order is restored")

        provider = self._providers[0][1]

        try:
            response = provider.make_request(method, params)
        except Exception as error:
            self.logger.warning(f"Provider {provider.endpoint_uri} error: {str(error)}")
            self.switch_endpoint()
            raise RPCProviderError(str(error)) from error

        if 'error' in response and is_transient_rpc_error(ValueError(response['error'])):
            self.logger.warning(f"Provider {provider.endpoint_uri} error: {response['error']}")
            self.switch_endpoint()
            raise RPCProviderError(response['error'])
        else:
            return response

    def switch_endpoint(self) -> None:
        """
        Switch the endpoint to the next provider in the list.
        """
        self._providers = self._providers[1:] + self._providers[:1]
        self.logger.info(f"Switched provider to {self._providers[0][1].endpoint_uri}")
