from web3 import Web3
from web3.types import BlockData, _Hash32

from commons.eth.utils import retry_w3_call
from commons.log import get_class_logger
from commons.type_check import check_mapping, check_uint
from commons.utils import cached_method, cached_property
from commons.eth.providers import MultiProvider


class BlockUtils:
    """
    Provides methods for block operations
    """
    # TODO move the block cache to the middleware, see middleware.*_cache_middleware.

    class NoSuchBlock(Exception):
        """
        Raised when a block cannot be found
        """
        pass

    class StaleChain(Exception):
        """
        Raised when a chain is stale
        """
        pass

    def __init__(self, w3: Web3):
        self.w3 = w3
        self.logger = get_class_logger(self)

    @cached_method(maxsize=1000)
    def _get_block(self, number: int):
        """
        Despite the fact that w3.eth.get_block typed to return BlockData in fact web3.datastructures.AttributeDict
        is returned
        """
        self.logger.debug(f'Requesting non-cached block #{number}')
        return check_mapping(self.w3.eth.get_block(number))

    def get_block(self, number: int):
        """
        Despite the fact that w3.eth.get_block typed to return BlockData in fact web3.datastructures.AttributeDict
        is returned
        """
        return retry_w3_call(lambda: self._get_block(number))

    @cached_method(maxsize=1000)
    def get_transaction(self, tx_hash: _Hash32):
        """
        Returns tx by its hash
        """
        return retry_w3_call(lambda: check_mapping(self.w3.eth.get_transaction(tx_hash)))

    def _get_latest_block_number(self) -> int:
        """
        Get the latest block number
        """
        return check_uint(self.w3.eth.block_number)

    def get_latest_block_number(self) -> int:
        """
        Get the latest block number
        """
        return retry_w3_call(lambda: self._get_latest_block_number())

    def _get_latest_block(self) -> BlockData:
        """
        Get the latest block
        """
        return self._get_block(self._get_latest_block_number())

    def get_latest_block(self) -> BlockData:
        """
        Get the latest block
        """
        return self.get_block(self.get_latest_block_number())

    @cached_property
    def avg_block_time(self) -> float:
        """
        Average block time, in seconds, calculated over 1000 blocks
        """
        latest = self.get_latest_block()
        if 0 == latest.number:
            return 1

        back_number = max(latest.number - 1000, 0)
        avg_time = (latest.timestamp - self.get_block(back_number).timestamp) / (latest.number - back_number)

        self.logger.debug(f'avg_block_time: {avg_time}')
        return avg_time

    def _get_latest_block_safe(self, timestamp):
        latest = self._get_latest_block()
        if latest.timestamp < timestamp:
            self.logger.warning(
                f'Requested the latest block <= timestamp {timestamp}, '
                f'but the most recent block (num={latest.number}) is stale (timestamp: {latest.timestamp})'
            )
            # In this case we can't just treat the latest chain block as satisfying the request,
            # since more blocks having their timestamp <= requested may appear.
            assert isinstance(self.w3.provider, MultiProvider)
            self.w3.provider.switch_endpoint()
            raise self.StaleChain()
        return latest

    @cached_method(maxsize=1000)
    def get_latest_block_before(self, timestamp: int):
        """
        Returns the latest block which timestamp <= timestamp
        :param timestamp: unix timestamp in seconds
        :return: block dict
        """

        latest = retry_w3_call(
            lambda: self._get_latest_block_safe(timestamp),
            custom_repeater=lambda e: True if isinstance(e, self.StaleChain) else None
        )
        if latest.timestamp == timestamp:
            return latest
        if 0 == latest.number:
            raise self.NoSuchBlock()
        upper = latest

        lower = self.get_block(0)   # TODO lazy load of block 0 (likely won't be needed after the first jump)
        if lower.timestamp > timestamp:
            raise self.NoSuchBlock()
        if lower.timestamp == timestamp:
            return lower

        jumps = 0
        jump_from_upper = True
        while True:
            assert lower.timestamp < timestamp < upper.timestamp
            assert upper.number > lower.number

            if upper.number == lower.number + 1:
                # Found adjacent blocks
                self.logger.debug(
                    f'get_latest_block_before(-{latest.timestamp - timestamp} seconds): '
                    f'found in {jumps} jumps {latest.number - lower.number} blocks back'
                )
                return lower

            if jump_from_upper:
                middle_num = upper.number - max(round((upper.timestamp - timestamp) / self.avg_block_time), 1)
                if middle_num <= lower.number:
                    middle_num = (upper.number + lower.number) // 2
                    if middle_num <= lower.number:
                        middle_num = lower.number + 1
            else:
                middle_num = lower.number + max(round((timestamp - lower.timestamp) / self.avg_block_time), 1)
                if middle_num >= upper.number:
                    middle_num = (upper.number + lower.number) // 2
                    if middle_num >= upper.number:
                        middle_num = upper.number - 1
            self.logger.debug(f'get_latest_block_before: expecting: {lower.number} < {middle_num} < {upper.number}')
            assert lower.number < middle_num < upper.number

            jumps += 1
            middle = self.get_block(middle_num)
            if middle.timestamp == timestamp:
                self.logger.debug(
                    f'get_latest_block_before(-{latest.timestamp - timestamp} seconds): '
                    f'found in {jumps} jumps {latest.number - middle.number} blocks back'
                )
                return middle
            elif middle.timestamp > timestamp:
                upper = middle
                jump_from_upper = True
            else:
                lower = middle
                jump_from_upper = False
