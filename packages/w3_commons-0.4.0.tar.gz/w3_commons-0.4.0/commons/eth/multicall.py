import dataclasses
import operator
from functools import partial
from itertools import repeat
from typing import List, Optional, Callable, Any

from eth_typing import Address, HexStr, BlockNumber, AnyAddress
from eth_utils import to_canonical_address
from web3 import Web3
from web3.contract import Contract
from web3.contract.contract import ContractFunction
from web3.exceptions import ContractLogicError

from commons.eth.utils import check_address, retry_w3_call, decode_call
from commons.utils import chunk


MULTICALL_ABI = [
    {
        "type": "function",
        "name": "aggregate",
        "inputs": [
            {
                "name": "",
                "type": "tuple[]",
                "internalType": "struct IMulticall.Call[]",
                "components": [
                    {
                        "name": "target",
                        "type": "address",
                        "internalType": "address"
                    },
                    {
                        "name": "callData",
                        "type": "bytes",
                        "internalType": "bytes"
                    }
                ]
            }
        ],
        "outputs": [
            {
                "name": "",
                "type": "uint256",
                "internalType": "uint256"
            },
            {
                "name": "",
                "type": "bytes[]",
                "internalType": "bytes[]"
            }
        ],
        "stateMutability": "view"
    },
    {
        "type": "function",
        "name": "tryAggregate",
        "inputs": [
            {
                "name": "",
                "type": "bool",
                "internalType": "bool"
            },
            {
                "name": "",
                "type": "tuple[]",
                "internalType": "struct IMulticall.Call[]",
                "components": [
                    {
                        "name": "target",
                        "type": "address",
                        "internalType": "address"
                    },
                    {
                        "name": "callData",
                        "type": "bytes",
                        "internalType": "bytes"
                    }
                ]
            }
        ],
        "outputs": [
            {
                "name": "",
                "type": "tuple[]",
                "internalType": "struct IMulticall.Result[]",
                "components": [
                    {
                        "name": "success",
                        "type": "bool",
                        "internalType": "bool"
                    },
                    {
                        "name": "returnData",
                        "type": "bytes",
                        "internalType": "bytes"
                    }
                ]
            }
        ],
        "stateMutability": "view"
    }
]


@dataclasses.dataclass
class MulticallItem:
    """
    Contains data for Multicall.aggregate method
    """
    address: Address
    encoded_function_call: HexStr
    decode_func: Callable
    tag: Optional[Any] = None

    @classmethod
    def create(
            cls,
            fn: ContractFunction,
            address: Optional[Address] = None,
            decode_func: Optional[Callable[[bytes], Any]] = None,
            tag: Optional[Any] = None
    ) -> 'MulticallItem':
        """
        Creates Multicall item by provided contract function

        :param fn: contract function instance
        :param address: address to override call recipient
        :param decode_func: function to override the method response decode function
        :param tag: tag to associate with result of the call
        """
        return cls(
            address=address or to_canonical_address(fn.address),
            decode_func=decode_func or partial(decode_call, fn),
            encoded_function_call=fn._encode_transaction_data(),
            tag=tag
        )


class Multicall:
    """
    Calls Mulicall contract from blockchain for multiple call aggregation
    """
    _w3: Web3
    _multicall: Contract

    def __init__(self, w3: Web3, abi: list | None = None, address: AnyAddress | None = None):
        if not abi:
            abi = MULTICALL_ABI

        if not address:
            address = {
                1: '0x5BA1e12693Dc8F9c48aAD8770482f4739bEeD696',
                56: '0xed386Fe855C1EFf2f843B910923Dd8846E45C5A4',
                42161: '0x5BA1e12693Dc8F9c48aAD8770482f4739bEeD696',
                10: '0x5BA1e12693Dc8F9c48aAD8770482f4739bEeD696',
                137: '0x5BA1e12693Dc8F9c48aAD8770482f4739bEeD696',
                43114: '0xed52B87FA63ebf9B8B58A4b731655b76a5a567c0',
            }[w3.eth.chain_id]

        self._multicall = w3.eth.contract(
            abi=abi,
            address=to_canonical_address(address)
        )
        self._w3 = w3

    @staticmethod
    def generate_multicall_items(
            contract: Contract,
            function_name: str,
            arguments: List[tuple] = None,
            addresses: Optional[List[Address]] = None,
            decode_func: Optional[Callable] = None,
            tags: Optional[List] = None
    ) -> List[MulticallItem]:
        """
        Generates list of MulticallItem by parameters

        :param contract: The contract object.
        :param function_name: The name of the function.
        :param arguments: The arguments for the function. Defaults to None.
        :param addresses: The addresses to use. Defaults to None.
        :param decode_func: The function to decode. Defaults to None.
        :param tags: The tags to use. Defaults to None.
        """
        if not (arguments or addresses):
            raise ValueError('Provide addresses or/and arguments parameters')

        if len(set(len(l) for l in [arguments, addresses, tags] if l)) != 1:
            raise ValueError('Lists with different length are provided')

        fn = contract.get_function_by_name(function_name)

        return [
            MulticallItem.create(
                fn=fn(*args),
                address=address,
                decode_func=decode_func,
                tag=tag
            )
            for address, args, tag in zip(
                addresses or repeat(contract.address),
                arguments or repeat(None),
                tags or repeat(None)
            )
        ]

    def _address_bytes_to_canonical(self, address: bytes) -> bytes:
        return to_canonical_address(check_address(self._w3.codec.decode(['address'], address)[0]))

    def aggregate(
            self,
            items: List[MulticallItem],
            raise_error: bool = True,
            chunk_size: Optional[int] = None,
            attach_tags: bool = True,
            block_identifier: Optional['BlockNumber'] = 'latest',
            add_error_to_results: bool = False
    ) -> list:
        """
        Calls Multicall contract tryAggregate function,
        checks results and matches results with tags (if attach_tags is True)

        :param items: The Multicall items.
        :param raise_error: Whether to raise error.
        :param chunk_size: The multicall chunk size.
        :param attach_tags: Whether to attach tags to results.
        :param block_identifier: The block number at which aggregate should be called.
        :param add_error_to_results: Whether to add error to result list.
        """
        results = []
        for chunk_items in ([items] if chunk_size is None else chunk(items, chunk_size)):
            answers = retry_w3_call(
                lambda: self._multicall.functions.tryAggregate(
                    False,
                    [
                        (item.address, item.encoded_function_call)
                        for item in chunk_items
                    ]
                ).call(block_identifier=block_identifier)
            )

            for item, (is_success, result_bytes) in zip(chunk_items, answers):
                if is_success:
                    if len(result_bytes):
                        results.append(item.decode_func(result_bytes))
                    else:
                        results.append(None)

                else:
                    error = ContractLogicError(f'Response for {item} is unsuccessful: {result_bytes}')
                    if raise_error:
                        raise error

                    if add_error_to_results:
                        results.append(error)
                    else:
                        results.append(None)
        if attach_tags:
            results = list(zip(map(operator.attrgetter('tag'), items), results))
        return results

    def aggregate_calls(
            self,
            items: List[ContractFunction],
            raise_error: bool = True,
            chunk_size: Optional[int] = None,
            block_identifier: Optional[BlockNumber] = 'latest',
            add_error_to_results=False
    ) -> list:
        """
        Calls Multicall contract tryAggregate function

        :param items: Contract functions filled with arguments
        :param raise_error: Whether to raise error.
        :param chunk_size: The multicall chunk size.
        :param block_identifier: The block number at which aggregate should be called.
        :param add_error_to_results: Whether to add error to result list.
        """
        return self.aggregate(
            list(map(MulticallItem.create, items)),
            raise_error=raise_error,
            chunk_size=chunk_size,
            attach_tags=False,
            block_identifier=block_identifier,
            add_error_to_results=add_error_to_results
        )
