import asyncio.exceptions
import concurrent.futures
import errno
import re
import socket
from json import JSONDecodeError
from ssl import SSLError
from typing import Union

import requests.exceptions
import websockets.exceptions
from web3.exceptions import Web3Exception

from commons.exceptions import AppError

Web3RPCErrorTypes = (ValueError, Web3Exception)


class ProtocolNotSupported(AppError):
    """
    Not supported protocol for use by web 3 provider
    """
    pass


class TransactionError(AppError):
    """
    Error related to transactions.
    """
    def __init__(self, *args, receipt=None, **kwargs):
        super(TransactionError, self).__init__(*args, **kwargs)
        self.receipt = receipt


class ArchiveAccessError(AppError):
    """
    Access to the chain archive data
    """
    pass


class RetryOperation(RuntimeError):
    """
    A special flag-like exception to extend retry_w3_call behaviour.
    """
    pass


class RPCProviderError(RuntimeError):
    """
    Error related to RPC calls.
    """
    pass


def is_network_timeout(e: Exception) -> bool:
    """
    Heuristic to check if an error is a network timeout of some kind.
    """
    import requests.exceptions
    import concurrent.futures

    if isinstance(e, OSError) and e.errno == errno.ETIMEDOUT:
        return True

    if isinstance(e, requests.exceptions.HTTPError) and e.response is not None \
            and getattr(e.response, 'status_code', None) in (504, 408):
        return True

    type_list = [concurrent.futures.TimeoutError, requests.exceptions.Timeout]

    try:
        import asyncio.exceptions
        type_list.append(asyncio.exceptions.TimeoutError)
    except ImportError:
        pass

    return isinstance(e, tuple(type_list))


def is_execution_timeout(e: Exception) -> bool:
    """
    Heuristic to check if an error is an EVM static call execution timeout error.
    """
    if not isinstance(e, Web3RPCErrorTypes):
        return False

    # args: ({'code': -32000, 'message': 'execution aborted (timeout = 5s)'}, )
    if not e.args or not isinstance(e.args[0], dict):
        return False

    if not isinstance(e.args[0].get('code'), int) or e.args[0]['code'] != -32000:
        return False

    return (isinstance(e.args[0].get('message'), str)
            and re.match(r'^execution aborted \(timeout = \d+(?:\.\d+)?s\)$', e.args[0]['message']) is not None)


def is_revert(e: Exception, check_message: str = None, check_regexp: Union[str, re.Pattern] = None) -> bool:
    """
    Heuristic to check if an error is an EVM revert error.
    :param e: exception to check
    :param check_message: check the revert reason for a strict match
    :param check_regexp: check the revert reason using regexp match
    :return: true if the exception is a revert
    """
    if check_message is not None and check_regexp is not None:
        raise ValueError('check_message and check_regexp specified both')

    if not isinstance(e, Web3RPCErrorTypes):
        return False

    if not e.args:
        return False

    if isinstance(e.args[0], str):
        message = e.args[0]
    elif isinstance(e.args[0], dict) and 'message' in e.args[0]:
        message = e.args[0]['message']
    else:
        return False

    if message.startswith('execution reverted: VM Exception while processing transaction: revert'):
        contract_message = message[70:]
    elif message.startswith('execution reverted'):
        contract_message = message[20:]
    elif message.startswith('VM Exception while processing transaction: revert'):
        contract_message = message[50:]
    elif 'execution was reverted: ' in message:
        contract_message = message.split('execution was reverted: ')[-1]
    elif message.startswith("Error: VM Exception while processing transaction: reverted with reason string '"):
        # error message in single quotes
        contract_message = message[79:]
        if check_message:
            check_message += "'"
    else:
        return False

    if check_message is not None:
        return contract_message == check_message

    if check_regexp is not None:
        if not isinstance(check_regexp, re.Pattern):
            check_regexp = re.compile(check_regexp)
        return check_regexp.match(contract_message) is not None

    return True


def is_transient_gaierror(e: Exception) -> bool:
    """
    Heuristic to check if an error is a transient getaddrinfo error.
    """
    return isinstance(e, socket.gaierror) and -3 == e.errno     # [Errno -3] Try again


def is_transient_transport_error(e: Exception) -> bool:
    """
    Heuristic to check if an error is a transient HTTP/WS error.
    """
    if (isinstance(e, websockets.exceptions.WebSocketException)
            and not isinstance(e, (websockets.exceptions.InvalidURI, websockets.exceptions.PayloadTooBig))):
        return True

    if (isinstance(e, requests.exceptions.RequestException) and not isinstance(e, (
            requests.exceptions.URLRequired, requests.exceptions.MissingSchema, requests.exceptions.InvalidSchema,
            requests.exceptions.InvalidURL, requests.exceptions.InvalidHeader, requests.exceptions.InvalidProxyURL
    ))):
        return True

    return isinstance(e, SSLError)


def is_transient_rpc_error(e: Exception) -> bool:
    """
    Heuristic to check if an error is a transient node malfunction.
    """
    if isinstance(e, JSONDecodeError):
        # Most likely an error on the provider's side
        return True

    if not isinstance(e, Web3RPCErrorTypes):
        return False

    if not e.args or not isinstance(e.args[0], dict):
        return False

    def msg2str() -> str:
        ret = e.args[0].get('message')
        return ret if isinstance(ret, str) else ''

    if e.args[0].get('code') == -32000 and msg2str().startswith('Block information is incomplete'):
        # Perhaps, xDai-specific.
        return True

    if e.args[0] in (
        # Observed on BSC & polygon in transient cases
        {'code': -32603, 'message': 'internal error'},

        # Observed while using the `getLogs()` method
        {'code': -32603, 'message': 'request failed or timed out'},

        # Looks like an Infura bug
        # https://github.com/MetaMask/metamask-extension/issues/7234
        {'code': -32000, 'message': 'header not found'},

        # Perhaps, xDai-specific. Hopefully, on the next iteration eth_gasPrice will yield a better guess.
        {'code': -32010, 'message': 'FeeTooLow'},

        # harmony one
        {'code': -32000, 'message': 'rate: Wait(n=1) would exceed context deadline'},

        # Perhaps, Optimism-specific.
        {'code': -32001, 'message': 'rpc method is not whitelisted'},

        # Perhaps, xDai- or blockpi-specific
        {'code': -32000, 'message': 'rpc error: code = Internal desc = network not supported'},
        {'code': -32000, 'message': 'max message response size exceed. upgrade your plan at https://blockpi.io'}
    ):
        return True

    return False


def is_archive_access_error(e: Exception) -> bool:
    """
    Heuristic to check if an error is an archive access error.
    """
    if not e.args or not isinstance(e.args[0], dict):
        return False

    error_message = e.args[0].get('message', '')
    if (
            'missing trie node' in error_message or
            'Upgrade to an archive plan' in error_message  # polygon
    ):
        return True
