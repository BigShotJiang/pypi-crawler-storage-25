# -*- coding: utf-8 -*-
from typing import Union
from eth_typing import Hash32, HexStr
from eth_utils import to_canonical_address
from hexbytes import HexBytes


TxHash = Union[Hash32, HexBytes, HexStr]


ZERO_ADDRESS = to_canonical_address('0x0000000000000000000000000000000000000000')






