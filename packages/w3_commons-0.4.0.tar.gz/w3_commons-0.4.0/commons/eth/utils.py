import itertools
from typing import Callable, Optional, List, Tuple, Type

from eth_abi.exceptions import DecodingError
from eth_typing import Primitives, HexStr
from eth_utils import to_canonical_address, to_checksum_address
from hexbytes import HexBytes
from web3 import Web3
from web3._utils.abi import get_abi_output_types, map_abi_data
from web3._utils.normalizers import BASE_RETURN_NORMALIZERS
from web3.contract import Contract
from web3.contract.contract import ContractFunction
from web3.contract.utils import ACCEPTABLE_EMPTY_STRINGS
from web3.datastructures import AttributeDict
from web3.exceptions import TimeExhausted, StaleBlockchain, BlockNotFound, BadFunctionCallOutput, Web3Exception

from commons.eth import RetryOperation, is_network_timeout, is_execution_timeout, is_transient_gaierror, \
    is_transient_transport_error, is_transient_rpc_error, is_archive_access_error, ArchiveAccessError, RPCProviderError
from commons.eth.types import ZERO_ADDRESS
from commons.type_check import check_list
from commons.utils import retry_call

Web3RPCErrorTypes: Tuple[Type[Exception], ...] = (ValueError, Web3Exception)


def to_bytes32(primitive: Primitives = None, hexstr: HexStr = None, text: str = None):
    """
    Converts a primitive, hex string or text to bytes32.
    """
    bytes = Web3.to_bytes(primitive=primitive, hexstr=hexstr, text=text)
    if len(bytes) > 32:
        raise ValueError('Length too long for bytes32')
    return bytes.rjust(32, b'\0')


def check_address(arg):
    """
    Check if the argument is a valid Ethereum address.
    """
    if not Web3.is_address(arg):
        raise TypeError('Not an address')
    return arg


def check_address_list(arg) -> List:
    """
    Check if the items in the argument list are valid Ethereum addresses.
    """
    for item in check_list(arg):
        check_address(item)
    return arg


def clean_web3_data(data):
    """
    Cleans a data structure so that it becomes serializable.
    """
    if isinstance(data, (dict, AttributeDict)):
        # Make dicts great^W dicts again
        return {k: clean_web3_data(v) for k, v in data.items()}
    if isinstance(data, list):
        return list(map(clean_web3_data, data))
    if isinstance(data, bytes):
        data = HexBytes(data)
    if isinstance(data, HexBytes):
        return data.hex()

    return data


def get_web3_error_message(e: Exception) -> Optional[str]:
    """
    Get error message from web3 call
    :param e: call exception
    :return: error message
    """
    if not e.args:
        return None
    arg = e.args[0]
    message = None
    if isinstance(arg, dict):
        if 'message' in arg:
            message = arg['message']
        elif 'error' in arg:
            message = arg['error']
    elif isinstance(arg, str):
        message = arg
    return message


def contract_call_to_bytes(contract_call: ContractFunction) -> bytes:
    """
    Encode Contract call to bytes
    """
    return Web3.to_bytes(hexstr=contract_call._encode_transaction_data())


def is_zero_address(addr):
    """
    Check if the argument is the zero address.
    """
    return to_canonical_address(addr) == ZERO_ADDRESS


def is_poa(w3: Web3) -> bool:
    """
    Heuristic to check if a web3 interface is connected to a POA/POS network.
    """

    # It's easier to assume POA/POS by default, since there are so many of them: 4, 5, 42, 56, 100, 137, 250, ...
    return retry_w3_call(lambda: w3.eth.chain_id >= 4)


def retry_w3_call(call: Callable, standard_delay_secs: int = 1, attempts: int = 12, exponential_backoff=True,
                  retry_timeouts=True, deadline: float = None, retry_transport_errors=True,
                  custom_repeater: Callable[[Exception], Optional[bool]] = None):
    """
    Invokes a web3 call and retries in case of transient errors (e.g. network errors)
    :param call: code to execute
    :param standard_delay_secs: delay between retry attempts (see also exponential_backoff), in seconds
    :param attempts: max number of attempts to do
    :param exponential_backoff: increase delay exponentially
    :param retry_timeouts: also retry on timeout errors
    :param deadline: unix ts at which the work must be interrupted
    :param retry_transport_errors: also retry on HTTP/WS errors
    :param custom_repeater: custom rule for the should_repeat function.
                        Should return a bool value to (not)repeat or None to skip custom_repeater decision
    :return: the call result
    """

    def should_repeat(e):
        return _w3_call_should_repeat(e, retry_timeouts, retry_transport_errors, custom_repeater)

    def wrapped_call():
        try:
            return call()
        except Web3RPCErrorTypes as e:
            if is_archive_access_error(e):
                raise ArchiveAccessError(e)
            raise

    return retry_call(wrapped_call, should_repeat, standard_delay_secs, attempts, exponential_backoff, deadline)


def _w3_call_should_repeat(e: Exception, retry_timeouts, retry_transport_errors, custom_repeater) -> bool:
    if isinstance(e, RetryOperation):
        return True

    if isinstance(e, RPCProviderError):
        return True

    if custom_repeater:
        res = custom_repeater(e)
        if res is not None:
            return res

    if is_network_timeout(e) or is_execution_timeout(e):
        return retry_timeouts  # other cases are not considered since we have a direct order

    if is_transient_rpc_error(e):
        return True

    if is_transient_gaierror(e):
        # Maybe a temporary name resolution failure
        return True

    if isinstance(e, (TimeExhausted, StaleBlockchain)):
        # Note that in the case of TimeExhausted just repeating the wait call might not be enough -
        # transaction resubmission may be needed.
        return True

    if is_transient_transport_error(e):
        return retry_transport_errors

    if isinstance(e, BlockNotFound):
        # Sometimes a node can't find the block which just has been reported by eth_blockNumber
        # (consistency? nobody cares about dis shit these days).
        # TODO more fine-grained solution needed (if the block is too far - dont repeat)
        return True

    return False


def is_call_acceptable_by_contract(contract: Contract, call: bytes) -> bool:
    """
    Checks that contract can accept method call
    :param contract: contract to check
    :param call: method call
    :return: check result
    """
    data = HexBytes(call)
    selector = data[:4]

    try:
        contract.get_function_by_selector(selector)
        return True
    except ValueError:
        return False


def filter_contracts_by_method_call(contracts: List[Contract], call: bytes) -> List[Contract]:
    """
    Returns contracts which can call the method described in call
    :param contracts: contracts to filter
    :param call: method calldata
    :return: filtered contracts
    """
    return [c for c in contracts if is_call_acceptable_by_contract(c, call)]


def try_stringify_address(value):
    """
    Converts input value to a Web3 checksum address if it is an integer within a specific range,
    otherwise returns original value.
    """
    if (isinstance(value, int) and
            0x1000000000000000000000000000000 <= value <= 0xffffffffffffffffffffffffffffffffffffffff):
        # looks like an address
        return to_checksum_address('0x{:040x}'.format(value))

    return value


def decode_call(fn: ContractFunction, return_data: bytes):
    """
    Decodes return bytes for ContractFunction call. (copy from web3 internal)

    :param fn: contract function
    :param return_data: the call raw return value
    """
    fb_abi = fn.abi
    address = fn.address
    web3 = fn.web3
    function_identifier = fn.function_identifier
    normalizers = fn._return_data_normalizers

    output_types = get_abi_output_types(fb_abi)

    try:
        output_data = web3.codec.decode(output_types, return_data)
    except DecodingError as e:
        # Provide a more helpful error message than the one provided by
        # eth-abi-utils
        is_missing_code_error = (
                return_data in ACCEPTABLE_EMPTY_STRINGS
                and web3.eth.get_code(address) in ACCEPTABLE_EMPTY_STRINGS)
        if is_missing_code_error:
            msg = (
                "Could not transact with/call contract function, is contract "
                "deployed correctly and chain synced?"
            )
        else:
            msg = (
                f"Could not decode contract function call to {function_identifier} with "
                f"return data: {str(return_data)}, output_types: {output_types}"
            )
        raise BadFunctionCallOutput(msg) from e

    _normalizers = itertools.chain(
        BASE_RETURN_NORMALIZERS,
        normalizers,
    )
    normalized_data = map_abi_data(_normalizers, output_types, output_data)

    if len(normalized_data) == 1:
        return normalized_data[0]
    else:
        return normalized_data
