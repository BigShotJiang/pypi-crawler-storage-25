import os
import time
from logging import Logger
from typing import Dict, Optional, List, Any, cast, Union

from eth_utils import to_checksum_address, event_abi_to_log_topic
from hexbytes import HexBytes
from web3 import Web3
from web3.contract.contract import ContractEvent
from web3._utils.events import get_event_data
from web3.datastructures import AttributeDict
from web3.exceptions import Web3Exception
from web3.types import EventData

from commons.eth.utils import retry_w3_call, get_web3_error_message, clean_web3_data
from commons.io import json_load, json_save
from commons.log import get_class_logger
from commons.type_check import check_uint, check_list, check_mapping

Web3RPCErrorTypes = (ValueError, Web3Exception)


def _normalize_contract_events(contract_event: Union[ContractEvent, List[ContractEvent]]) -> List[ContractEvent]:
    events = contract_event if isinstance(contract_event, list) else [contract_event]
    if not events:
        raise ValueError('At least one contract event is required')
    return events


def _validate_events_belong_to_one_contract(events: List[ContractEvent]) -> None:
    first_event = events[0]
    for event in events[1:]:
        if event.address != first_event.address:
            raise ValueError('All events must belong to the same contract address')
        if event.w3 is not first_event.w3:
            raise ValueError('All events must belong to the same web3 instance')


class EventFetcher:
    r"""
    Reads and caches certain events from blockchain.

    If parameter finality_blocks is specified, it changes the caching behavior. Final blocks are no longer re-checked
    for new events (in the absense of the parameter, all the blocks since max(event_block) are rechecked). Plus, all
    non-final blocks are rechecked. If the show_non_final_events option is set then events from non-final blocks are
    reported during iteration but not saved to the cache. If show_non_final_events is False, non-final blocks are not
    examined even if explicitly requested in cache_up.
    If the events are rare, it's highly recommended to specify finality_blocks to save on chain tail re-fetches.

    .. code-block:: python
    f = EventFetcher(event)
    f.cache_up(max_block)
    for e in f:
        # ...
    """
    events: List[ContractEvent]
    w3: Web3
    min_block: int
    argument_filters: Optional[Dict[str, Any]]
    _cache_dir: Optional[str]
    _request_period: Optional[int]
    _max_blocks_per_request: Optional[int]
    _finality_blocks: Optional[int]
    _show_non_final_events: bool

    logger: Logger

    _codename: str = None
    _cache: List[Dict] = None

    # This is the last final block _checked for events_, not just last final block
    _max_final_block = None

    # FIXME TODO remove this (superseded by _max_final_block) after the users switched to finality_blocks usage
    _latest_checked_block: int = -1

    def __init__(self,
                 event: Union[ContractEvent, List[ContractEvent]],
                 min_block: int = 0,
                 argument_filters: Optional[Dict[str, Any]] = None,
                 cache_dir: str = None,
                 request_period: Optional[int] = None,
                 max_blocks_per_request: Optional[int] = None,
                 finality_blocks: Optional[int] = None,
                 show_non_final_events: bool = False):
        """
        :param event: contract event
        :param min_block: build cache from this block, inclusive
        :param argument_filters: arguments filters for eth_getLogs
        :param cache_dir: dir to cache events in files. If not specified, then memory will be used
        :param request_period: time (in seconds) to wait between log fetch requests
        :param max_blocks_per_request: max blocks to examine per one eth_getLogs request
        :param finality_blocks: number of descendant blocks to consider a parent block final
        :param show_non_final_events: (requires finality_blocks) if true, events from non-final blocks will be reported
        """
        events = _normalize_contract_events(event)
        _validate_events_belong_to_one_contract(events)
        if len(events) > 1 and argument_filters:
            raise ValueError('argument_filters are supported only for a single contract event')
        self.events = events
        self.w3 = self.events[0].w3
        check_uint(min_block)
        self.min_block = min_block
        self.argument_filters = argument_filters
        self._cache_dir = cache_dir
        self._request_period = request_period
        self._max_blocks_per_request = max_blocks_per_request
        self._finality_blocks = finality_blocks
        if show_non_final_events and self._finality_blocks is None:
            raise ValueError('show_non_final_events makes no sense without finality_blocks')
        self._show_non_final_events = show_non_final_events
        self.logger = get_class_logger(self).getChild(self.codename)

    @property
    def codename(self) -> str:
        """
        Get the codename of the event.
        """
        if self._codename is None:
            # cache it since chain_id may be expensive
            event_names = ','.join(sorted({e.event_name for e in self.events}))
            self._codename = f'{self.w3.eth.chain_id}.' \
                                 f'{to_checksum_address(self.events[0].address)}.' \
                             f'{event_names}'

        return self._codename

    def cache_up(self, to_block: int = None) -> None:
        """
        Caches events.
        :param to_block: cache up to this block, inclusive; may be implicitly lowered if finality_blocks is active
                         (see the class doc for details)
        """
        cache = self._get_cache()

        current_block = retry_w3_call(lambda: self.w3.eth.block_number)
        if to_block is None:
            to_block = current_block
        check_uint(to_block)
        if self._finality_blocks is not None and not self._show_non_final_events:
            to_block = min(to_block, current_block - self._finality_blocks)
            if to_block < 0:
                return  # nothing to fetch

        if self._finality_blocks is None:
            current_final_block = None
        else:
            # Max final block that will be checked during this cache_up call
            current_final_block = min(current_block - self._finality_blocks, to_block)
            if current_final_block < 0:
                current_final_block = None

        from_block = max(self.min_block, self._last_event_block() + 1)
        if self._finality_blocks is None:
            from_block = max(from_block, self._latest_checked_block + 1)
        elif self._max_final_block is not None:
            from_block = max(from_block, self._max_final_block + 1)

        if from_block > to_block:
            return  # already in the cache
        self.logger.debug('%s', f'cache_up: loading all the events '
                                f'in the block range [{from_block}, {to_block}]; '
                                f'current_final_block: {current_final_block}')

        initial_cache_size = len(cache)
        events = get_events(
            self.events, from_block, to_block,
            argument_filters=self.argument_filters, request_period=self._request_period,
            **({} if self._max_blocks_per_request is None else dict(request_limit=self._max_blocks_per_request))
        )
        cache.extend(events)

        self._latest_checked_block = max(min(current_block - 100, to_block), 0)     # rude finality replacement

        self._save_cache(initial_cache_size, cache, current_final_block)

    @property
    def _file_cache_is_used(self) -> bool:
        return self._cache_dir is not None

    def _get_cache(self) -> List[Dict]:
        # lazy load
        if self._cache is None:
            if self._file_cache_is_used and os.path.exists(self._cache_file_name):
                data = json_load(self._cache_file_name)

                if isinstance(data, list):  # version 1
                    self._cache = [event_data_from_serializable(e) for e in check_list(data)]
                else:
                    check_mapping(data)
                    if 2 != data.get('version'):
                        raise NotImplementedError(f'unsupported {self.__class__.__name__} cache version')
                    self._cache = [event_data_from_serializable(e) for e in check_list(data['cache'])]
                    if data['max_final_block'] is not None:
                        self._max_final_block = check_uint(data['max_final_block'])

                self.logger.debug('%s', f'_get_cache: loaded {len(self._cache)} cached events, '
                                        f'last event block is {self._last_event_block()}, '
                                        f'max final block is {self._max_final_block}')

            else:
                self._cache = list()

        return self._cache

    def _save_cache(self, initial_cache_size, cache, current_final_block):
        if current_final_block is not None and current_final_block > (self._max_final_block or -1):
            max_final_block = current_final_block
        else:
            max_final_block = self._max_final_block

        # If we fetched some event twice that's our fault.
        assert len(cache) == len(set((e['blockNumber'], e['transactionIndex'], e['logIndex']) for e in cache))

        if self._file_cache_is_used:
            serializable_cache = [event_data_to_serializable(e) for e in cache]

            # We don't save non-final events
            if self._finality_blocks is not None:
                if max_final_block is None:
                    serializable_cache = []
                else:
                    serializable_cache = [e for e in serializable_cache if e['blockNumber'] <= max_final_block]

            if len(serializable_cache) == initial_cache_size and max_final_block == self._max_final_block:
                return

            os.makedirs(self._cache_dir, exist_ok=True)
            json_save(self._cache_file_name, {
                'version': 2,
                'cache': serializable_cache,
                'max_final_block': max_final_block
            })

            self.logger.debug('%s', f'_save_cache: saved {len(serializable_cache)} cached events, '
                                    f'max final block is {max_final_block}')

        self._cache = cache
        self._max_final_block = max_final_block

    @property
    def _cache_file_name(self) -> str:
        # TODO sqlite or leveldb
        return os.path.join(self._cache_dir, f'event.{self.codename}.json')

    # Heavy op, so not a prop
    def _last_event_block(self) -> int:
        assert self._cache is not None
        return -1 if not self._cache else max(check_uint(e['blockNumber']) for e in self._cache)

    def __iter__(self):
        return iter(self._get_cache())


def get_events(
    contract_event: Union[ContractEvent, List[ContractEvent]],
    from_block: int = 0,
    to_block: Optional[int] = None,
    request_limit: int = 10_000,
    argument_filters: Optional[Dict[str, Any]] = None,
    request_period: Optional[int] = None
) -> List[EventData]:
    """
    Returns events of type 'contract_event' from 'from_block' block number to
    'to_block' block number (both are inclusive), 'request_limit' is a count of observable
    blocks per one request.

    :param contract_event: event to fetch
    :param from_block: start block number
    :param to_block: end block number
    :param request_limit: logs per request
    :param request_period: time (in seconds) to wait between log fetch requests
    """
    events_to_collect = _normalize_contract_events(contract_event)
    _validate_events_belong_to_one_contract(events_to_collect)

    first_event = events_to_collect[0]
    topic_to_event = None
    topics_filter = None
    if len(events_to_collect) > 1:
        if argument_filters:
            raise ValueError('argument_filters are supported only for a single contract event')
        topic_to_event = dict()
        for event in events_to_collect:
            topic_to_event[event_abi_to_log_topic(event._get_event_abi())] = event
        topics_filter = [HexBytes(topic) for topic in topic_to_event.keys()]

    if to_block is None:
        to_block = retry_w3_call(lambda: first_event.w3.eth.block_number)
    else:
        assert from_block <= to_block, f'Should be {from_block} <= {to_block}'

    events = []

    # sometimes getLogs toBlock parameter is not synced with 'contract_event.w3.eth.block_number'
    def custom_repeater(exc: Exception) -> Optional[bool]:
        patterns = [
            "Receipt not available for 'To' block",
            "could not be found",
            "too many requests"
        ]
        if isinstance(exc, Web3RPCErrorTypes) and any(p in str(exc) for p in patterns):
            return True

    request_start = None
    while from_block <= to_block:
        if request_start and request_period:
            time_spent = time.time() - request_start
            if time_spent < request_period:
                time.sleep(request_period - time_spent)

        batch_to_block = min(from_block + request_limit - 1, to_block)
        # eth_getLogs (fromBlock and toBlock are inclusive)
        try:
            request_start = time.time()
            if len(events_to_collect) == 1:
                events.extend(
                    retry_w3_call(
                        lambda: events_to_collect[0].get_logs(
                            fromBlock=from_block, toBlock=batch_to_block, argument_filters=argument_filters
                        ),
                        custom_repeater=custom_repeater
                    )
                )
            else:
                logs = retry_w3_call(
                    lambda: first_event.w3.eth.get_logs({
                        'fromBlock': from_block,
                        'toBlock': batch_to_block,
                        'address': first_event.address,
                        'topics': [topics_filter]
                    }),
                    custom_repeater=custom_repeater
                )

                for log in logs:
                    if not log.get('topics'):
                        continue
                    event = topic_to_event.get(bytes(log['topics'][0])) if topic_to_event is not None else None
                    if event is None:
                        continue
                    events.append(get_event_data(first_event.w3.codec, event._get_event_abi(), log))
        except Web3RPCErrorTypes as e:
            message = get_web3_error_message(e)
            if message and message.startswith('exceed maximum block range:'):
                request_limit = int(message.replace('exceed maximum block range: ', ''))
                continue
            raise
        from_block = batch_to_block + 1
    return events


def event_data_to_serializable(event_data: EventData) -> dict:
    """
    Converts event data to serializable dict.
    """
    return clean_web3_data(event_data)


def event_data_from_serializable(event_data: dict) -> EventData:
    """
    Converts serializable dict to event data.
    """
    if event_data.get('blockHash') is not None:
        event_data['blockHash'] = HexBytes(event_data['blockHash'])
    if event_data.get('transactionHash') is not None:
        event_data['transactionHash'] = HexBytes(event_data['transactionHash'])
    return cast(EventData, AttributeDict.recursive(event_data))
