from typing import Callable, Optional, Dict
from time import time, sleep

from eth_utils import to_hex, to_checksum_address
from eth_abi import decode as decode_abi
from hexbytes import HexBytes
from web3 import Web3
from web3.contract import Contract
from web3.exceptions import TimeExhausted, StaleBlockchain, TransactionNotFound, Web3Exception
from web3.types import TxReceipt

from commons.eth import TransactionError, RetryOperation, is_network_timeout, \
    is_transient_gaierror, is_transient_transport_error, is_transient_rpc_error
from commons.eth.types import TxHash
from commons.eth.utils import get_web3_error_message, is_poa, retry_w3_call
from commons.type_check import check_uint
from commons.log import get_fn_logger

Web3RPCErrorTypes = (ValueError, Web3Exception)


def transact(web3: "Web3", curried_fn, tx_args: dict = None, deadline: float = None, attempts: int = 8, custom_repeater: Callable[[Exception], Optional[bool]] = None):
    """
    Tries its best to send a transaction on time, with a lot of heuristics.
    :param web3: web3 interface
    :param curried_fn: result of contract.functions.fnName(fn_args) invocation
    :param tx_args: transaction args (note that gasPrice and nonce will be overwritten)
    :param deadline: unix ts at which the work must be interrupted
    :param custom_repeater: custom rule for the should_repeat function.
                            Should return a bool value to (not)repeat or None to skip custom_repeater decision
    :return: tx_hash, tx_receipt

    NOTE: concurrent transacting using the same account is NOT supported.
    """
    max_gas_premium = 20    # eth.gas_price x 20

    logger = get_fn_logger(transact)
    gas_step = max_gas_premium ** (1 / check_uint(attempts - 1)) if attempts > 1 else 1

    tx_args = dict() if tx_args is None else dict(tx_args)  # copy

    if {'nonce', 'gasPrice', 'maxPriorityFeePerGas', 'maxFeePerGas'} & tx_args.keys():
        raise ValueError('Some tx args will be overwritten')

    if 'from' not in tx_args:
        if not web3.eth.default_account and not web3.eth.accounts:
            raise ValueError('Can\'t get \'from\' parameter')
        tx_args['from'] = web3.eth.default_account or web3.eth.accounts[0]

    # x1test (chainId 195) problem with pending txs fix
    nonce_block_identifier = 'latest' if web3.eth.chain_id == 195 else 'pending'

    def get_nonce():
        return web3.eth.get_transaction_count(tx_args['from'], block_identifier=nonce_block_identifier)

    tx_args['nonce'] = check_uint(retry_w3_call(get_nonce, deadline=deadline))

    gas_params = create_gas_params(web3, gas_step, deadline)
    attempt = 0

    def call():
        # In the case when eth_gasPrice() is unreliable/constant we'll have to use
        # web3.gas_strategies.time_based.construct_time_based_gas_price_strategy, but that will require moving
        # the block cache to the middleware, see middleware.*_cache_middleware.
        nonlocal attempt
        attempt += 1

        tx_args.update(
            gas_params.values()
        )

        logger.debug('%s', f'Transacting: {curried_fn}, tx_args: {tx_args}')
        try:
            tx_hash_ = curried_fn.transact(tx_args)

            if deadline is None:
                # Fast block inclusion is typical for poa/pos networks.
                receipt_timeout = 4 * 60 if is_poa(web3) else 8 * 60
            else:
                receipt_timeout = int(max(deadline - time(), 0) / (attempts - attempt + 1)) + 1

            tx_receipt = wait_for_transaction_receipt(web3, tx_hash_, timeout=receipt_timeout)
            if not tx_receipt['status']:
                if 'error' in tx_receipt:
                    raise ValueError(tx_receipt['error'])
                else:
                    raise TransactionError(
                        f'Transaction {tx_hash_.hex()} {curried_fn} failed for unknown reasons', receipt=tx_receipt
                    )

        except TimeExhausted as e:
            logger.warning(f'Transaction {curried_fn} timed out: {e}')
            gas_params.increase()
            raise RetryOperation()
        except Web3RPCErrorTypes as e:
            message = get_transaction_error_message(e) or ''
            logger.warning(f'Transaction {curried_fn} failed: {message}')

            if (message in ('nonce too low', 'wrong transaction nonce')
                    or 'nonce too low' in message
                    or message.startswith(('OldNonce, Current nonce', 'ALREADY_EXISTS'))
                    or message == 'AlreadyKnown'
                    or message == 'already known'):
                # Only needed for sluggish nodes which report stale get_transaction_count above.
                tx_args['nonce'] += 1
                logger.warning("Wrong transaction nonce. The node is unreliable")
                raise RetryOperation()
            elif (message.startswith('Transaction ran out of gas')
                  or message.startswith('OutOfGas')):
                # This may be due to incorrect gas estimation
                # (for example, if the gas is dependent on any other contract calls at the moment).
                # Resubmitting will result in a new estimate
                logger.warning("Transaction ran out of gas")
                raise RetryOperation()

            gas_params.increase()

            # gnosis error
            if message == 'INTERNAL_ERROR: could not replace existing tx':
                raise RetryOperation()

            if (message in ('transaction underpriced', 'gas price too low')
                    or 'less than block base fee' in message
                    or 'FeeTooLow' in message
                    or message.startswith('failed to deduct transaction costs from user balance: '  # cronos message
                                          'the tx gasfeecap is lower than the tx baseFee')):
                raise RetryOperation()
            else:
                raise
        assert attempt <= attempts
        return tx_hash_, tx_receipt

    tx_hash, tx_receipt = retry_w3_call(call, attempts=attempts, deadline=deadline, custom_repeater=custom_repeater)

    logger.debug('%s', f'Executed {curried_fn}: {tx_hash.hex()}')
    return tx_hash, tx_receipt


class _TxGasParams:
    """
    Base class for managing transaction gas parameters.
    Transaction parameters are calculated based on set of base parameters (received from the chain)
    and transaction attempt number.
    """

    def __init__(self, web3: Web3, gas_step: float, deadline: float):
        """
        :param web3: Web3 handle
        :param gas_step: multiplier to increase base values (see _next_values())
        :param deadline: unix ts at which the work must be interrupted
        """
        self._web3 = web3
        self._gas_step = gas_step
        self._deadline = deadline
        self._attempt = 0
        self._values = None

    def values(self) -> Dict:
        """
        Get current gas parameters.
        """
        if self._values is None:
            self._values = self._base_params()
        return dict(self._gas_params(self._values))

    def increase(self):
        """
        Increase gas parameters using heuristic formula.
        """
        self._attempt += 1
        base_values = self._base_params()
        new_values = {
            key: self._next_value(base_value, self._values.get(key, 0), self._attempt)
            for key, base_value in base_values.items()
        }
        self._values = new_values

    def _next_value(self, initial_value, prev_value, attempt) -> int:
        """
        Heuristic formula to increase one base value
        :param initial_value: initial base value (from _base_values() call)
        :param prev_value: previous calculated value
        :param attempt: transaction attempt number
        :return: next value
        """
        return int(max(
            initial_value * self._gas_step ** attempt,
            prev_value * 1.125 + 1
        ))

    def _base_params(self) -> Dict:
        """
        Base parameters from the source (chain)
        :return: base parameters
        """
        raise NotImplemented

    def _gas_params(self, base_params: Dict) -> Dict:
        """
        Calculate gas parameters based on base parameters
        :param base_params: base parameters
        :return: gas parameters
        """
        raise NotImplemented


class _OldTxGasParams(_TxGasParams):
    """
    Calculation of transaction gas parameters for old transactions
    """

    def _base_params(self) -> Dict:
        return {
            'gasPrice': retry_w3_call(lambda: self._web3.eth.gas_price, deadline=self._deadline),
        }

    def _gas_params(self, base_params: Dict) -> Dict:
        return base_params


class _AuroraTxGasParams(_OldTxGasParams):
    """
    Increases gasLimit for the Aurora chain
    """
    def _base_params(self) -> Dict:
        return {**super()._base_params(), 'gas': 30_000_000}


class _Tx2GasParams(_TxGasParams):
    """
    Calculation of transaction gas parameters for type 2 transactions (eip-1559)
    """

    def _base_params(self) -> Dict:
        max_priority_fee = retry_w3_call(lambda: self._web3.eth.max_priority_fee, deadline=self._deadline)
        return {
            'maxPriorityFeePerGas': max_priority_fee,
            'baseFeePerGas': retry_w3_call(
                lambda: self._web3.eth.get_block('latest')['baseFeePerGas'], deadline=self._deadline
            ),
        }

    def _gas_params(self, base_params: Dict) -> Dict:
        return {
            'maxPriorityFeePerGas': base_params['maxPriorityFeePerGas'],
            'maxFeePerGas': base_params['maxPriorityFeePerGas'] + base_params['baseFeePerGas'],
        }


class _CeloTx2GasParams(_Tx2GasParams):
    """
    Calculation of transaction gas parameters for type 2 transactions (eip-1559) for Celo chain.
    Celo chain contains baseFeePerGas as parameter gasPriceMinimum at the smart-contract GasPriceMinimum

    https://docs.celo.org/celo-codebase/protocol/transactions/gas-pricing#selecting-a-transaction-gas-price
    """
    _gas_price_minimum_contract: Contract

    def __init__(self, web3: Web3, gas_step: float, deadline: float):
        super(_CeloTx2GasParams, self).__init__(web3, gas_step, deadline)
        # https://github.com/celo-tools/celo-web-wallet/blob/41277d9ef2e4cf047ee90929a3f30d0104e5bfbb/src/config.ts#L90
        self._gas_price_minimum_contract = self._web3.eth.contract(
            address=to_checksum_address('0xDfca3a8d7699D8bAfe656823AD60C17cb8270ECC'),
            abi=[
                {
                    'inputs': [], 'name': 'gasPriceMinimum',
                    'outputs': [{'internalType': 'uint256', 'name': '', 'type': 'uint256'}],
                    'stateMutability': 'view', 'type': 'function'
                }
            ]
        )

    def _base_params(self) -> Dict:
        max_priority_fee = retry_w3_call(lambda: self._web3.eth.max_priority_fee, deadline=self._deadline)
        return {
            'maxPriorityFeePerGas': max_priority_fee,
            'baseFeePerGas': retry_w3_call(
                self._gas_price_minimum_contract.functions.gasPriceMinimum().call, deadline=self._deadline
            ),
        }


class _GnosisTx2GasParams(_Tx2GasParams):
    """
    Fixes problem: FeeTooLow, EffectivePriorityFeePerGas too low 0 < 1000000000, BaseFee: 53
    """
    def _base_params(self) -> Dict:
        base_params = super()._base_params()
        # Ensure minimum priority fee of 1 gwei (1,000,000,000 wei) to avoid FeeTooLow errors
        base_params['baseFeePerGas'] = max(base_params['baseFeePerGas'], 1_000_000_000)  # min 1 GWEI
        return base_params


class _GnosisTxGasParams(_OldTxGasParams):
    def _base_params(self) -> Dict:
        base_params = super()._base_params()
        base_params['gasPrice'] = int(base_params['gasPrice'] * 1.25)
        return base_params


def create_gas_params(web3: Web3, gas_step: float, deadline: float) -> _TxGasParams:
    """
    Creates _TxGasParams instance. Chooses class by tx type support and the chain id
    :param web3: Web3 handle
    :param gas_step: multiplier to increase base values (see _next_values())
    :param deadline: unix ts at which the work must be interrupted
    :return: instance of _TxGasParams
    """
    if is_tx2_support(web3):
        gas_params_class = {
            42220: _CeloTx2GasParams,
            100: _GnosisTx2GasParams
        }.get(web3.eth.chain_id, _Tx2GasParams)
    else:
        gas_params_class = {
            1313161554: _AuroraTxGasParams
        }.get(web3.eth.chain_id, _OldTxGasParams)
    return gas_params_class(web3, gas_step=gas_step, deadline=deadline)


def wait_for_transaction_receipt(web3: "Web3", txn_hash: TxHash, timeout: int = 10 * 60, poll_latency: float = 1.0) \
        -> TxReceipt:
    """
    A smarter version of web3.wait_for_transaction_receipt. A hybrid of wait_for_transaction_receipt & retry_w3_call.
    :param web3: Web3 handle
    :param txn_hash: hash of the transaction
    :param timeout: max total wait time (actual wait time may be a bit longer)
    :param poll_latency: minimal poll time
    :return: tx receipt, throws TimeExhausted on error
    """
    logger = get_fn_logger(wait_for_transaction_receipt)
    stop_time = time() + check_uint(timeout)
    logger.debug('%s', f'Called for {to_hex(txn_hash)}, timeout: {timeout}')

    def should_repeat(e):
        if is_transient_gaierror(e):
            # May be a temporary name resolution failure
            return True

        if is_transient_rpc_error(e):
            return True

        if isinstance(e, StaleBlockchain):
            return True

        if is_transient_transport_error(e):
            return True

        return is_network_timeout(e)

    def go2sleep(how_long: float):
        sleep_time = min(how_long, stop_time - time())
        if sleep_time < 0:
            raise TimeExhausted(f"Transaction {to_hex(txn_hash)} is not in the chain, after {timeout} seconds")
        sleep(sleep_time)

    current_poll_latency = poll_latency
    while True:

        # Gets the tx receipt, repeating on network errors (the original version gives up too soon).
        current_delay = poll_latency
        while True:
            try:
                txn_receipt = web3.eth.get_transaction_receipt(txn_hash)
                break
            except TransactionNotFound:
                txn_receipt = None
                break
            except Exception as exc:
                logger.warning(f'While executing web3.eth.get_transaction_receipt: {exc.__class__.__name__}: {exc}')
                if not should_repeat(exc):
                    raise exc
                go2sleep(current_delay)
                current_delay *= 1.5

        # Process the receipt as usual.

        # FIXME: The check for a null `blockHash` is due to parity's
        # non-standard implementation of the JSON-RPC API and should
        # be removed once the formal spec for the JSON-RPC endpoints
        # has been finalized.
        if txn_receipt is not None and txn_receipt['blockHash'] is not None:
            return txn_receipt

        go2sleep(current_poll_latency)
        current_poll_latency *= 1.1


def get_transaction_error_message(e: Exception) -> Optional[str]:
    """
    Get error message from transaction execution exception
    :param e: transaction execution exception
    :return: error message
    """
    message = get_web3_error_message(e)
    if message and message.startswith('Reverted 0x'):
        try:
            message = bytes.fromhex(message[11:]).decode('utf-8')
        except UnicodeError:
            # 19 = len('Reverted 0x') + 4 bytes of error code
            message = decode_abi(['string'], HexBytes(message[19:]))[0]
    return message


_tx2_support_cache = dict()


def is_tx2_support(w3: Web3) -> bool:
    """
    Heuristic to check if a network supports type 2 transactions (eip-1559)
    """
    chain_id = retry_w3_call(lambda: w3.eth.chain_id)
    if chain_id not in _tx2_support_cache:
        def check_max_priority_fee_per_gas_method() -> bool:
            try:
                # Check if the method eth_maxPriorityFeePerGas exists
                _ = w3.eth._max_priority_fee()
                return True
            except Web3RPCErrorTypes as e:
                if e.args and isinstance(e.args[0], dict) and (
                    e.args[0].get('code') == -32601 or  # Method not found
                    e.args[0].get('message') == 'rpc method is not whitelisted'
                ):
                    return False
                elif (e.args and isinstance(e.args[0], dict)
                      and e.args[0].get('message') == 'Method eth_maxPriorityFeePerGas not supported.'):
                    return False
                else:
                    raise
        latest_block = retry_w3_call(lambda: w3.eth.get_block('latest'))

        # We check 2 conditions because there are networks
        # that don't support eip-1559, but satisfy one of these conditions
        _tx2_support_cache[chain_id] = \
            retry_w3_call(check_max_priority_fee_per_gas_method) and 'baseFeePerGas' in latest_block

    return _tx2_support_cache[chain_id]
