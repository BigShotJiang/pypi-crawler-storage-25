"""
:mod:`unitprotocol.io` - I/O helpers
"""
import os

import yaml
import json

# ujson produced a malformed file in a long json case. Standard json now has a .so backend, so it's fast.
# import ujson


def yaml_load(file_name: str):
    """
    Load and parse a YAML file.
    """
    with open(file_name, 'r') as fh:
        return yaml.safe_load(fh)


def yaml_save(file_name: str, data):
    """
    Save data as yaml. Slow, for small amounts of data only.
    """
    with open(file_name, 'w') as fh:
        yaml.dump(data, fh, default_flow_style=False)


def json_load(file_name: str):
    """
    Load and parse a JSON file.
    """
    with open(file_name, 'r') as fh:
        return json.load(fh)


def json_save(file_name: str, data):
    """
    Save data as compact json. Fast, safe, not human-readable.
    """
    tmp_file_name = f'{file_name}.tmp'
    with open(tmp_file_name, 'w') as f:
        json.dump(data, f)
    os.replace(tmp_file_name, file_name)
