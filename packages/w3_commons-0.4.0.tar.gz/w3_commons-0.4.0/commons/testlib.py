import platform
import re
import subprocess
from typing import Dict, Union, Tuple, List, Callable
import pytest


def parametrized(test_data: Dict[str, dict]):
    """
    Decorator that allows you to parametrize tests using a dictionary.
    The keys of the dictionary are used as test ids and the values as arguments for the test function.

    :param test_data: A dictionary with test ids as keys and dictionaries of arguments as values.
    :return: A pytest.mark.parametrize decorator that can be applied to a test function.
    """
    tests_ids = list(test_data.keys())
    argnames = None
    argvalues = []
    for test_id, values in test_data.items():
        if argnames is None:
            argnames = list(values.keys())
        else:
            assert argnames == list(values.keys()), "invalid test parametrization setup"
        argvalues.append(values.values())

    return pytest.mark.parametrize(','.join(argnames), argvalues, ids=tests_ids)


def fn_stub(expected_args: Union[Tuple, Dict, List[Tuple]], return_value) -> Callable:
    """
    Function stub: checks args, returns predefined value.

    :param expected_args: tuple (or a list of such tuples) or dict of the allowed args (anything else is an error)
    :param return_value: value to return, if Callable - called, if Exception class/instance - raised
    :return: a function stub
    """
    def inner(*args, **kwargs):
        passed = tuple(args)
        if isinstance(expected_args, list):
            assert passed in expected_args, 'Unexpected call arguments'
        elif isinstance(expected_args, dict):
            assert kwargs == expected_args, 'Unexpected call keyword arguments'
        else:
            assert passed == expected_args, 'Unexpected call arguments'

        if isinstance(return_value, type) and issubclass(return_value, Exception):
            raise return_value()
        if isinstance(return_value, Exception):
            raise return_value

        return return_value(*args, **kwargs) if isinstance(return_value, Callable) else return_value

    return inner


def async_fn_stub(expected_args: Union[Tuple, Dict, List[Tuple]], return_value) -> Callable:
    """
    Create an asynchronous function stub that wraps a synchronous function stub created by `fn_stub`.

    :param expected_args: tuple (or a list of such tuples) or dict of the allowed args (anything else is an error)
    :param return_value: value to return, if Callable - called, if Exception class/instance - raised
    :return: an asynchronous function stub that wraps the synchronous function stub
    """
    fn = fn_stub(expected_args=expected_args, return_value=return_value)

    async def inner(*args, **kwargs):
        return fn(*args, **kwargs)

    return inner


def stub(**attributes):
    """
    Returns a stub object with predefined attributes - convenient to build limited versions of objects on the fly.
    """
    class _Inner:
        def __contains__(self, item):
            return item in attributes

        def __getattr__(self, item):
            if item not in attributes:
                raise AttributeError(item)
            return attributes[item]

    return _Inner()


@pytest.fixture(scope='session')
def port_generator():
    """
    Fixture that provides a generator of available network ports that can be used to run tests.
    :return: A generator of available network ports.
    """
    open_ports = set()
    if platform.system() == 'Linux':
        try:
            for line in subprocess.getoutput('netstat -nlt').split('\n'):
                match = re.search(r'^tcp\s+\d+\s+\d+\s+[\d.]+:(\d+)', line)
                if match:
                    open_ports.add(int(match.group(1)))
        except Exception:
            pass

    start_port = 8181
    return (start_port + i for i in range(10000) if start_port + i not in open_ports)
