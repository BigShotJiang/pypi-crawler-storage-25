import logging
from typing import Callable
from commons.utils import get_fn_name


def get_class_logger(obj):
    """
    Get the logger for the given class or object's class.
    """
    klass = obj if isinstance(obj, type) else obj.__class__
    return logging.getLogger(f'{klass.__module__}.{klass.__name__}')


def get_fn_logger(fn: Callable):
    """
    Get the logger for the given function.
    """
    return logging.getLogger(get_fn_name(fn))


def configure_logging(level=logging.DEBUG):
    """
    Configure basic logging.
    :param level: logging level
    """
    fmt = '[%(asctime)s] %(process)d [Thread %(thread)d] [%(levelname)s] {%(name)s} %(message)s'
    logging.basicConfig(format=fmt, level=level)
