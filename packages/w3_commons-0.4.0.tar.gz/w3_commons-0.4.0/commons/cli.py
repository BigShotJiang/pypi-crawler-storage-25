from typing import Tuple, List

import sys
from abc import ABC, abstractmethod
from argparse import Namespace, ArgumentParser
from commons.exceptions import AppError


class CommandError(AppError):
    """
    Raises if command cannot be executed for a known reason
    """
    pass


class CliCommand(ABC):
    """
    Base class for cli commands
    """

    description: str = None
    epilog: str = None
    args: Namespace
    extra_args: []
    allow_extra_args = False

    def run(self):
        """
        Run command execution
        """
        try:
            self.args, self.extra_args = self._parse_arguments()
            if self.extra_args and not self.allow_extra_args:
                raise CommandError(f'Unrecognized arguments: {self.extra_args}')
            self._prepare()
            self.handle()
        except CommandError as e:
            print(f'{e}', file=sys.stderr)
            sys.exit(1)

    def _parse_arguments(self) -> Tuple[Namespace, List]:
        parser = ArgumentParser(description=self.description, epilog=self.epilog)
        self._add_base_arguments(parser)
        self.add_arguments(parser)
        return parser.parse_known_args()

    def _add_base_arguments(self, parser: ArgumentParser):
        """
        Add base arguments to implement in abstract commands
        """
        pass

    def _prepare(self):
        """
        Preparation before handling. Can be implement in abstract commands
        """
        pass

    def add_arguments(self, parser: ArgumentParser):
        """
        Add custom command line arguments
        """
        pass

    @abstractmethod
    def handle(self):
        """
        The actual logic of the command
        """
        raise NotImplementedError()
