"""
This module contains a set of utility functions commonly used in Python development.
"""
import asyncio

import functools
from threading import RLock

import sys
import weakref
from decimal import Decimal
from time import sleep, time
from typing import Callable, Iterable, Iterator, Tuple, Any, List, Union, Coroutine

from itertools import islice, groupby
from contextlib import contextmanager

from commons.exceptions import RetryLimitReachedError, RetryDeadlineExceededError


def get_fn_name(fn: Callable):
    """
    Get the fully qualified name of the given function.
    """
    mod = getattr(fn, '__module__', None)
    return f'{mod}.{fn.__name__}' if mod else fn.__name__


def retry_call(
        call: Callable, should_repeat_call: Callable[[Exception], bool],
        standard_delay_secs: int = 1, attempts: int = 10, exponential_backoff=True,
        deadline: float = None
):
    """
    Invokes a `call` and retries in case of transient errors (e.g. network errors).

    :param call: code to execute
    :param should_repeat_call: fn which tells if the exception occurred during the last call is not fatal
    :param standard_delay_secs: delay between retry attempts (see also exponential_backoff), in seconds
    :param attempts: max number of attempts to do
    :param exponential_backoff: increase delay exponentially
    :param deadline: unix ts at which the work must be interrupted
    :return: the call result
    """
    if attempts < 1:
        raise ValueError('bad attempts value')

    from commons.log import get_fn_logger
    logger = get_fn_logger(retry_call)
    executed_attempts = 0
    delay = None
    last = False
    while True:
        assert executed_attempts < attempts
        executed_attempts += 1

        try:
            return call()
        except Exception as e:
            if not should_repeat_call(e):
                raise

            if executed_attempts == attempts:
                raise RetryLimitReachedError('Retry limit reached for ' + get_fn_name(call)) from e

            if deadline is not None and (last or time() >= deadline):
                raise RetryDeadlineExceededError('Execution deadline exceeded for ' + get_fn_name(call)) from e

            logger.warning(
                f'While executing {get_fn_name(call)} (attempt #{executed_attempts}): {e.__class__.__name__}: {e}'
            )
        if delay is None:
            delay = standard_delay_secs
            continue    # the first retry is instant (optimistic)

        if deadline is not None:
            till_deadline = max(deadline - time(), 0)
            if delay > till_deadline:
                delay = till_deadline
                last = True

        logger.info(f'Sleeping for {delay} seconds')
        sleep(delay)
        if exponential_backoff:
            delay *= 2


async def async_retry_call(call: Callable[[], Coroutine],
                           should_repeat_call: Callable[[Exception], bool],
                           standard_delay_secs: int = 1, attempts: int = 10, exponential_backoff=True,
                           deadline: float = None) -> Coroutine:
    """
    Invokes a coroutine `call` and retries in case of transient errors (e.g. network errors).

    :param call: code to execute
    :param should_repeat_call: fn which tells if the exception occurred during the last call is not fatal
    :param standard_delay_secs: delay between retry attempts (see also exponential_backoff), in seconds
    :param attempts: max number of attempts to do
    :param exponential_backoff: increase delay exponentially
    :param deadline: unix ts at which the work must be interrupted
    :return: the call result
    """

    if attempts < 1:
        raise ValueError('bad attempts value')

    from commons.log import get_fn_logger
    logger = get_fn_logger(async_retry_call)
    executed_attempts = 0
    delay = None
    last = False
    while True:
        assert executed_attempts < attempts
        executed_attempts += 1

        try:
            result = await call()
            return result
        except Exception as e:
            if not should_repeat_call(e):
                raise

            if executed_attempts == attempts:
                raise RetryLimitReachedError('Retry limit reached for ' + get_fn_name(call)) from e

            if deadline is not None and (last or time() >= deadline):
                raise RetryDeadlineExceededError('Execution deadline exceeded for ' + get_fn_name(call)) from e

            logger.warning(
                f'While executing {get_fn_name(call)} (attempt #{executed_attempts}): {e.__class__.__name__}: {e}'
            )

        if delay is None:
            delay = standard_delay_secs
            continue    # the first retry is instant (optimistic)

        if deadline is not None:
            till_deadline = max(deadline - time(), 0)
            if delay > till_deadline:
                delay = till_deadline
                last = True

        logger.info(f'Sleeping for {delay} seconds')
        await asyncio.sleep(delay)

        if exponential_backoff:
            delay *= 2


def chunk(it: Iterable, size: int) -> Iterable:
    """
    Splits `it` to chunks with size `size`
    """
    assert size or isinstance(size, int) and size > 0
    it = iter(it)
    return iter(lambda: tuple(islice(it, size)), ())


def group_by(data: Iterable, key: Callable, reversed_sort: bool = False) -> Iterator[Tuple[Any, list]]:
    """
    Groups `data` by `key`
    """
    yield from ((key, list(group)) for key, group in groupby(sorted(data, key=key, reverse=reversed_sort), key))


def check_attributes(attrs: List[str], func: Callable = bool):
    """
    Checks object attributes by func
    """
    def _check_attributes(method):
        def wrapper(self, *args, **kwargs):
            for attr in attrs:
                value = getattr(self, attr)
                if not func(value):
                    raise ValueError(
                        f'Attribute self.{attr} should be filled before method call. Current value: {value}'
                    )
            return method(self, *args, **kwargs)
        return wrapper
    return _check_attributes


def to_thousands_str(val: Union[int, float, Decimal]) -> str:
    """
    Convert a number to a string representation with thousands abbreviated as "K".
    """
    return f'{int(val / 1000)}K'


def first(subscriptable):
    """
    Get the first element of a subscriptable.
    """
    return subscriptable[0]


def second(subscriptable):
    """
    Get the second element of a subscriptable.
    """
    return subscriptable[1]


def identity(x):
    """
    Shortcut for lambda that returns the input as output.
    """
    return x


@contextmanager
def locked(lock):
    """
    Contextmanager which locks and releases a lock in the safest way
    :param lock: Lock or RLock
    """
    while not lock.acquire():   # may be interrupted by a signal, so a loop is needed
        pass

    try:
        yield
    finally:
        lock.release()


def batch(iterable: Iterable, max_batch_size: int):
    """
    Batches an iterable into lists of given maximum size, yielding them one by one.
    """
    _batch = []
    for element in iterable:
        _batch.append(element)
        if len(_batch) >= max_batch_size:
            yield _batch
            _batch = []
    if len(_batch) > 0:
        yield _batch


_NOT_FOUND = object()


class cached_property:
    """
    A custom version of functools.cached_property, allowing parallel computation for distinct instances
    to avoid the following issue: https://github.com/python/cpython/issues/87634
    """

    def __init__(self, func):
        self.func = func
        self.attrname = None
        self.__doc__ = func.__doc__
        self.locks = weakref.WeakKeyDictionary()

    def __set_name__(self, owner, name):
        if self.attrname is None:
            self.attrname = name
        elif name != self.attrname:
            raise TypeError(
                "Cannot assign the same cached_property to two different names "
                f"({self.attrname!r} and {name!r})."
            )

    def __get__(self, instance, owner=None):
        if instance is None:
            return self
        if self.attrname is None:
            raise TypeError(
                "Cannot use cached_property instance without calling __set_name__ on it.")
        try:
            cache = instance.__dict__
        except AttributeError:  # not all objects have __dict__ (e.g. class defines slots)
            msg = (
                f"No '__dict__' attribute on {type(instance).__name__!r} "
                f"instance to cache {self.attrname!r} property."
            )
            raise TypeError(msg) from None
        val = cache.get(self.attrname, _NOT_FOUND)
        if val is _NOT_FOUND:
            with self.locks.setdefault(instance, RLock()):
                # check if another thread filled cache while we awaited lock
                val = cache.get(self.attrname, _NOT_FOUND)
                if val is _NOT_FOUND:
                    val = self.func(instance)
                    try:
                        cache[self.attrname] = val
                    except TypeError:
                        msg = (
                            f"The '__dict__' attribute on {type(instance).__name__!r} instance "
                            f"does not support item assignment for caching {self.attrname!r} property."
                        )
                        raise TypeError(msg) from None
        return val


def cached_method(*lru_args, **lru_kwargs):
    """
    Per-instance cache for class methods using lru_cache() inside
    """
    def decorator(func):

        @functools.wraps(func)
        def wrapped_func(self, *args, **kwargs):
            # We're storing the wrapped method inside the instance. If we had
            # a strong reference to self the instance would never die.
            self_weak = weakref.ref(self)

            @functools.wraps(func)
            @functools.lru_cache(*lru_args, **lru_kwargs)
            def _cached_method(*args, **kwargs):
                return func(self_weak(), *args, **kwargs)

            setattr(self, func.__name__, _cached_method)
            return _cached_method(*args, **kwargs)

        return wrapped_func

    return decorator


def die(message):
    """
    Print an error message and exit.
    """
    print(message, file=sys.stderr)
    sys.exit(1)
