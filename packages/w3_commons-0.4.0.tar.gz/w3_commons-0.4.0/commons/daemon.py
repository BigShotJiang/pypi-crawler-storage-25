# -*- coding: utf-8 -*-
#
#   module unitprotocol.daemon
#
from abc import ABCMeta
from typing import Dict, Tuple, MutableMapping, MutableSequence, Union, Optional, List
from logging import Logger
from signal import signal, SIGTERM, SIGQUIT, SIGINT
from time import sleep, time
import json
import threading
import socket
import socketserver
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

from commons.log import get_class_logger
from commons.utils import locked


class BaseDaemon(metaclass=ABCMeta):
    """
    A base class for daemons that run in the background and respond to signals.
    """
    logger: Logger

    _health_endpoint: Optional[str]
    _prev_sig_handlers: Dict
    _got_signal: bool = False
    _status_exporter: '_StatusExporter' = None

    def __init__(self, health_endpoint: str = None):
        self.logger = get_class_logger(self)
        self._health_endpoint = health_endpoint
        self._prev_sig_handlers = dict()

    def serve_forever(self):
        """
        Initializes the daemon.
        """
        self.logger.info('Starting')

        if self._got_signal:
            raise RuntimeError('reuse is not possible')

        self._install_sig_handler()
        self._setup_status_exporter()

        self._serve_forever_internal()

        self._close()

    def _serve_forever_internal(self):
        raise NotImplementedError()

    def _setup_status_exporter(self):
        if self._health_endpoint and self._status_exporter is None:
            health_endpoint = self._health_endpoint.split(':')
            self._status_exporter = _StatusExporter((health_endpoint[0], int(health_endpoint[1])))

    def _sig_handler(self, _signum, _frame):
        self.logger.info(f'Got signal {_signum}')
        if self._got_signal:
            return
        self._got_signal = True
        for (signum_, prev) in self._prev_sig_handlers.items():
            signal(signum_, prev)

    def _install_sig_handler(self):
        for signum in (SIGTERM, SIGQUIT, SIGINT):
            self._prev_sig_handlers[signum] = signal(signum, self._sig_handler)

    def _close(self):
        self.logger.info('_close(): exiting the loop')


class _StatusExporter:
    """
    Simple http export of the health status, for internal network/usage only.
    See export_health_parameter fn.
    """

    endpoint: Tuple[str, int]

    logger: Logger
    _server: socketserver.ThreadingTCPServer = None
    _health_parameters: Dict[str, bool] = dict()
    # Perhaps, a lock is not necessary, but just to be sure that the status thread always reads a consistent dict.
    _health_lock: threading.Lock = threading.Lock()

    def __init__(self, endpoint: Tuple[str, int]):
        self.endpoint = endpoint
        self.logger = get_class_logger(self)

        self._status_thread = threading.Thread(target=self._status_thread_loop, daemon=True)
        self._status_thread.start()

    def export_health_parameter(self, parameter: str, value: bool) -> None:
        """
        Sets the value of some health parameters. Health is ok when all the parameters are True.
        :param parameter: parameter codename
        :param value: true if the parameter is ok
        """
        with locked(self._health_lock):
            self._health_parameters[parameter] = value

        (self.logger.debug if value else self.logger.warning)(f"parameter '{parameter}' was set to {value}")

    def set_health_parameters_dict(self, parameters: Dict[str, bool]) -> None:
        """
        Completely replaces current health parameters with new ones.
        """
        with locked(self._health_lock):
            # Copying to make sure they won't be modified in the unlocked state
            self._health_parameters = dict(parameters)

    def get_health(self) -> bool:
        """
        Returns whether all health parameters are set to True.
        """
        with locked(self._health_lock):
            return all(self._health_parameters.values())

    def get_health_parameters(self) -> Dict[str, bool]:
        """
        Returns all health parameters.
        """
        with locked(self._health_lock):
            # Copying to make sure they won't be modified in the unlocked state
            return dict(self._health_parameters)

    def clear_health_parameters(self):
        """
        Clears all health parameters.
        """
        with locked(self._health_lock):
            self._health_parameters.clear()

    def _status_thread_loop(self):
        def make_handler(*args):
            return self._TCPHandler(*args, exporter=self)

        with socketserver.ThreadingTCPServer(self.endpoint, make_handler) as server:
            self._server = server
            self._server.serve_forever()

    def close(self):
        """
        Close the server
        """
        if self._server:
            self._server.server_close()

    class _TCPHandler(socketserver.BaseRequestHandler):
        _exporter: '_StatusExporter'

        def __init__(self, request, client_address, server, exporter: '_StatusExporter'):
            # BaseRequestHandler does all the processing in the ctor, so we have to act first.
            self._exporter = exporter
            super().__init__(request, client_address, server)

        def handle(self):
            # self.request is the TCP socket connected to the client
            self.request.recv(4096)
            self.request.shutdown(socket.SHUT_RD)

            result = self._exporter.get_health_parameters()
            result['health'] = all(result.values())
            content = json.dumps(result)

            raw = f"HTTP/1.0 200 OK\r\n" \
                  f"content-length: {len(content)}\r\n" \
                  f"content-type: application/json\r\n" \
                  f"\r\n" \
                  f"{content}"
            self.request.sendall(raw.encode('utf8'))


class SleepMixin:
    """
    Mixin class that provides a `_sleep` method for sleeping for a certain number of seconds.
    The `_sleep` method can be interrupted by setting the `_got_signal` attribute to True.
    """

    def _sleep(self, seconds: float, sleep_interval: float = 0.1):
        end_ts = time() + seconds
        for _ in range(int(seconds / sleep_interval)):
            if self._got_signal or time() >= end_ts:
                return
            sleep(sleep_interval)


class ThreadingHttpEndpointServer:
    """
    A class for running a HTTP server that exposes a given data object through an endpoint.
    The server runs in a separate thread and can be closed with the `close_data_server` method.
    """
    _data_server: ThreadingHTTPServer = None
    _endpoint: List[str]
    _data: Union[MutableMapping, MutableSequence]  # pointer to object

    def __init__(self, endpoint: str, data: Union[MutableMapping, MutableSequence], logger: Optional[Logger] = None):
        self._endpoint = endpoint.split(':')
        self.set_data(data)
        self.logger = logger or get_class_logger(self)

    def set_data(self, data: Union[MutableMapping, MutableSequence]):
        """
        Set the data that will be served by the server.
        """
        self._data = data

    def close_data_server(self):
        """
        Shut down the data server.
        """
        if self._data_server:
            self._data_server.shutdown()

    def _prepare_response(self, req: BaseHTTPRequestHandler) -> Tuple[int, Union[MutableMapping, MutableSequence]]:
        return (200 if self._data else 404, self._data)

    def start_server(self):
        """
        Start the HTTP server for handling data requests.
        """
        server = self

        class HttpRequestHandler(BaseHTTPRequestHandler):
            """
            HTTP request handler for a server that responds to GET requests.
            """

            def do_GET(self):
                """
                Serve a GET request.
                """
                status_code, data = server._prepare_response(self)
                if server.logger:
                    server.logger.debug('%s', f'Data requested. Status code: {status_code}')
                self.send_response(status_code)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps(data).encode(encoding='utf_8'))

            def end_headers(self):
                self.send_header('Access-Control-Allow-Origin', '*')
                super().end_headers()

        def _data_exported_run():
            with ThreadingHTTPServer((self._endpoint[0], int(self._endpoint[1])), HttpRequestHandler) as server:
                self._data_server = server
                server.serve_forever()

        threading.Thread(target=_data_exported_run, daemon=True).start()
