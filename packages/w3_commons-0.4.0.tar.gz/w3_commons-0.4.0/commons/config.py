import os
from typing import Union, List, Dict, Optional, Set, Callable, Any, Tuple, Type, IO
from abc import ABCMeta, abstractmethod
from enum import Enum
from io import StringIO
import logging
import tempfile
import dataclasses
from contextlib import contextmanager
import json

import yaml
import requests

from commons.log import get_class_logger
from commons.exceptions import ConfigError


class ConfigReader(metaclass=ABCMeta):
    """
    Interface of a class that parses config files.
    """
    @abstractmethod
    def read(self, io: IO) -> Dict:
        """
        Parses config content from the IO.
        Disposal of the IO is not the reader's task.
        """
        raise NotImplementedError()


class YamlReader(ConfigReader):
    """
    ConfigReader subclass for reading and parsing config in YAML format.
    """
    def read(self, io: IO) -> Dict:
        """
        Parses config content from the IO.
        """
        return yaml.safe_load(io)


class JsonReader(ConfigReader):
    """
    ConfigReader subclass for reading and parsing config in JSON format.
    """
    def read(self, io: IO) -> Dict:
        """
        Parses config content from the IO.
        """
        return json.load(io)


class Config:
    """
    Base app-agnostic configuration.
    Works with any file format yielding a dicts-lists-scalars structure from the parser (the root object has to be dict,
    though).
    """

    class RemoteProtocol(Enum):
        """
        Protocols used in querying remote files or values.
        """
        # a file in a local filesystem
        FILE = 'file'

        # AWS S3
        S3 = 's3'

        # AWS Systems Manager parameter
        SSM = 'ssm'

        HTTP = 'http'
        HTTPS = 'https'

        @classmethod
        def aws_dependent(cls) -> Set:
            """Protocols requiring calls to AWS services to function."""
            return {cls.S3, cls.SSM}

        @property
        def sep(self) -> str:
            """Path components separator used by the protocol."""
            return os.sep if self is self.FILE else '/'

        def is_absolute_path(self, path_fragment: str) -> bool:
            """Checks if a path fragment is absolute in the terms of the protocol."""
            return self is self.FILE and os.path.isabs(path_fragment)

    def __init__(self, file_name: str,
                 reader: Optional[ConfigReader] = None,
                 supported_file_protocols: Set[RemoteProtocol] = frozenset(RemoteProtocol) - {RemoteProtocol.HTTP},
                 supported_value_protocols: Set[RemoteProtocol] = frozenset(RemoteProtocol) - {RemoteProtocol.HTTP},
                 value_protocol_common_prefix: str = 'include:',
                 logger: logging.Logger = None):
        """
        Ctor
        :param file_name: file name to read config from
        :param reader: config file format reader (defaults to YAML)
        :param supported_file_protocols: remote protocols allowed during file lookups (e.g. includes)
        :param supported_value_protocols: remote protocols allowed during value lookup
        :param value_protocol_common_prefix: required prefix before the protocol to treat value as a lookup request
        :param logger: logger to use
        """
        assert ''.join(p.value for p in self.RemoteProtocol).islower(), "values must be in lower case"

        if logger is None:
            logger = get_class_logger(self)
        if self._get_boto3() is None and ((supported_file_protocols | supported_value_protocols)
                                          & self.RemoteProtocol.aws_dependent()):
            logger.warning('AWS API (boto3) is not installed, some remote protocols will not be available')
            supported_file_protocols -= self.RemoteProtocol.aws_dependent()
            supported_value_protocols -= self.RemoteProtocol.aws_dependent()

        self._file_name = file_name
        self._reader = reader if reader is not None else YamlReader()
        self._supported_file_protocols = supported_file_protocols
        self._supported_value_protocols = supported_value_protocols
        self._value_protocol_common_prefix = value_protocol_common_prefix
        self._logger = logger

        main_path = self._Path.parse(file_name)
        if main_path.is_relative:   # no protocol specified
            main_path = self._Path(self.RemoteProtocol.FILE, main_path.path)
        self._main_path = main_path
        self._cfg = self._load([main_path])
        self._load_string_values()
        self._logger.info('%s', f'Loaded config from {file_name}')

    @property
    def filename(self) -> str:
        """
        Returns filename the config read from
        """
        return self._file_name

    @property
    def full(self) -> Dict:
        """Full config data."""
        return self._cfg

    def get(self, key: str, default=None):
        """
        Gets config value by key.
        """
        return self._cfg.get(key, default)

    def __len__(self) -> int:
        """
        Returns total number of keys in top-level dict.
        """
        return len(self._cfg)

    def __getitem__(self, item):
        """
        Gets config value by key.
        """
        return self._cfg[item]

    def __contains__(self, item) -> bool:
        """
        Checks if the config has the key.
        """
        return item in self._cfg

    @dataclasses.dataclass(frozen=True)
    class _Path:
        protocol: Optional['Config.RemoteProtocol']
        path: str   # protocol-specific path

        @property
        def is_relative(self):
            """
            Check if the path is relative.
            """
            return self.protocol is None

        @classmethod
        def parse(cls, path: str, with_prefix: str = '') -> 'Config._Path':
            """
            Parse a path string and return a _Path object.
            """
            path_lower = path.lower()
            with_prefix = with_prefix.lower()
            for proto in Config.RemoteProtocol:
                if path_lower.startswith(f'{with_prefix}{proto.value}://'):
                    return cls(proto, path[len(with_prefix) + len(proto.value) + 3:])
            return cls(None, path)

        def __str__(self):
            return self.path if self.protocol is None else f'{self.protocol.value}://{self.path}'

    @classmethod
    def _join_paths(cls, parent: 'Config._Path', child: 'Config._Path') -> 'Config._Path':
        # The function knows too much about the outside world to place it in _Path.
        if not child.is_relative:
            return child

        proto = parent.protocol     # new path has the same protocol in this case
        if child.path.startswith(proto.sep) and not (proto is cls.RemoteProtocol.FILE):
            # TODO that may require protocol-specific rebuilding of parent_path.path, e.g.
            # to keep the current bucket in case of S3.
            raise ConfigError(f'Include starting with {proto.sep} is not supported yet in the '
                              f'case of {proto.value} ({child.path})')

        if proto.is_absolute_path(child.path) or proto.sep not in parent.path:
            # Different cases, the same result - relative path replaces entire parent path.
            return cls._Path(proto, child.path)
        else:
            if parent.path.endswith(proto.sep):
                raise ConfigError(f'Can\'t make a path relative to {parent.path}')
            dir_, _ = parent.path.rsplit(proto.sep, maxsplit=1)
            return cls._Path(proto, f'{dir_}{proto.sep}{child.path}')

    def _load(self, include_chain: List['Config._Path']) -> Dict:
        """
        Loads a config fragment, recursively processing includes.
        :param include_chain: chain to check for include loops, file to load has to be specified in include_path[-1]
        :return: loaded data structure
        """
        assert include_chain
        description = str(include_chain[-1])
        if len(include_chain) > 1:
            description += f' (include chain: {", ".join(map(str, include_chain[:-1]))})'

        self._logger.debug('%s', f'About to load a config {"part " if len(include_chain) > 1 else ""}'
                                 f'from {description}')

        with self._open_content(include_chain[-1]) as fh:
            data = self._reader.read(fh)

        if not isinstance(data, dict):
            raise ConfigError('Config is not a mapping: ' + description)

        def load_includes(files) -> List[Dict]:
            if isinstance(files, str):
                files = [files]
            if not isinstance(files, list):
                raise ConfigError('Malformed include/override found in ' + description)

            def canonical_path(path: 'Config._Path') -> 'Config._Path':
                """Canonicalization for better comparison."""
                assert not path.is_relative, "must be processed before"

                if path.protocol is self.RemoteProtocol.FILE:
                    return self._Path(self.RemoteProtocol.FILE, os.path.realpath(path.path))

                return path

            parent_path = include_chain[-1]
            assert not parent_path.is_relative
            canonical_include_chain = list(map(canonical_path, include_chain))

            resulting_subconfigs = list()
            for sub_file in files:
                if not isinstance(sub_file, str):
                    raise ConfigError(f'Malformed include/override found in {description}')
                # Resolving relative paths right away, for simplicity.
                sub_path = self._join_paths(parent_path, self._Path.parse(sub_file))

                if canonical_path(sub_path) in canonical_include_chain:
                    raise ConfigError(f'Include loop found at {canonical_path(sub_path)} '
                                      f'while processing {description}')

                resulting_subconfigs.append(self._load(include_chain + [sub_path]))

            return resulting_subconfigs

        def process_includes(item):
            if 'include' in item:
                for addon in load_includes(item.pop('include')):
                    collision = set(item) & set(addon)
                    if collision:
                        raise ConfigError(f'Colliding keys ({", ".join(collision)}) found in an include '
                                          f'while processing {description}')
                    item.update(addon)
            if 'override' in item:
                for addon in load_includes(item.pop('override')):
                    item.update(addon)
            return item

        return self._walk_item(data, process_includes, dict)

    def _load_string_values(self) -> None:
        """Loads included string values in-place."""
        def load_value(value):
            path = self._Path.parse(value, self._value_protocol_common_prefix)
            return value if path.is_relative else self._load_string_value(self._resolve_string_value_path(path))

        self._cfg = self._walk_item(self._cfg, load_value, str)

    def _resolve_string_value_path(self, path: 'Config._Path') -> 'Config._Path':
        """
        Resolves relative local-file string includes against the main config file location.
        """
        if (
            path.protocol is self.RemoteProtocol.FILE
            and not path.protocol.is_absolute_path(path.path)
            and self._main_path.protocol is self.RemoteProtocol.FILE
        ):
            return self._join_paths(self._main_path, self._Path(None, path.path))

        return path

    @staticmethod
    def _walk_item(item, cb: Callable[[Any], Any], type_filter: Optional[Union[Type, Tuple[Type]]]) -> Any:
        """
        Helper function to recursively transform a data structure.
        :param item: data to transform
        :param cb: callback to apply, gets an item and must return some new or the same item
        :param type_filter: invoke cb only for items of the specified types
        :return: transformed data structure
        """
        if type_filter is None or isinstance(item, type_filter):
            item = cb(item)

        if isinstance(item, dict):
            return dict((k, Config._walk_item(v, cb, type_filter)) for (k, v) in item.items())

        if isinstance(item, list):
            return [Config._walk_item(v, cb, type_filter) for v in item]

        return item

    @contextmanager
    def _open_content(self, path: 'Config._Path') -> IO:
        """
        Opens content of different protocols. Must be used as a context manager.
        :param path: protocol and protocol-specific path
        :return: open IO object
        """
        assert not path.is_relative, "must be processed before"

        if path.protocol not in self._supported_file_protocols:
            raise ConfigError(f'Remote protocol "{path.protocol.value}" is not allowed while loading {path}')

        if path.protocol is self.RemoteProtocol.S3:
            tmp = self._load_s3(path.path)
            with open(tmp) as fh:
                os.unlink(tmp)
                yield fh

        elif path.protocol is self.RemoteProtocol.SSM:
            import botocore.exceptions  # can't be moved above since AWS support may be unavailable
            try:
                ssm = self._get_boto3().client('ssm')
                parameter = ssm.get_parameter(Name=path.path, WithDecryption=True)['Parameter']['Value']
            except botocore.exceptions.ClientError as e:
                raise ConfigError(f'Error in SSM.get_parameter({path.path})') from e

            yield StringIO(parameter)

        elif path.protocol is self.RemoteProtocol.FILE:
            with open(path.path, 'r') as fh:
                yield fh

        elif path.protocol in (self.RemoteProtocol.HTTP, self.RemoteProtocol.HTTPS):
            resp = requests.get(str(path))
            if 200 != resp.status_code:
                raise ConfigError(f'Error downloading {path}: status code {resp.status_code}')

            yield StringIO(resp.text)

        else:
            raise NotImplementedError()

    def _load_string_value(self, path: 'Config._Path') -> str:
        """
        Loads content of different protocols into a string.
        :param path: protocol and protocol-specific path
        :return: value loaded
        """
        assert not path.is_relative, "must be processed before"

        if path.protocol not in self._supported_value_protocols:
            raise ConfigError(f'Remote protocol "{path.protocol.value}" is not allowed while loading a '
                              f'string from {path}')

        if path.protocol is self.RemoteProtocol.S3:
            tmp = self._load_s3(path.path)
            with open(tmp) as fh:
                os.unlink(tmp)
                return fh.read()

        elif path.protocol is self.RemoteProtocol.SSM:
            import botocore.exceptions  # can't be moved above since AWS support may be unavailable
            try:
                ssm = self._get_boto3().client('ssm')
                return ssm.get_parameter(Name=path.path, WithDecryption=True)['Parameter']['Value']
            except botocore.exceptions.ClientError as e:
                raise ConfigError(f'Error in SSM.get_parameter({path.path})') from e

        elif path.protocol is self.RemoteProtocol.FILE:
            with open(path.path, 'r') as fh:
                return fh.read()

        elif path.protocol in (self.RemoteProtocol.HTTP, self.RemoteProtocol.HTTPS):
            resp = requests.get(str(path))
            if 200 != resp.status_code:
                raise ConfigError(f'Error downloading {path}: status code {resp.status_code}')

            return resp.text

        else:
            raise NotImplementedError()

    def _load_s3(self, path: str) -> str:
        """
        Downloads S3 file into a local file.
        :param path: bucket/path.
        :return: local file name, must be removed by the caller.
        """
        import botocore.exceptions

        if '/' not in path or path.startswith('/'):
            raise ConfigError(f'Invalid S3 bucket/path combination: {path}')
        bucket, path = path.split('/', 1)

        fh, tmp = tempfile.mkstemp()
        os.close(fh)

        self._logger.debug('%s', f'Invoking s3.download_file(Bucket={bucket}, Key={path}, To={tmp})')
        try:
            s3 = self._get_boto3().resource('s3')
            s3.meta.client.download_file(bucket, path, tmp)
        except botocore.exceptions.ClientError as e:
            raise ConfigError(f'Error downloading {bucket}/{path} from S3') from e

        return tmp

    @staticmethod
    def _get_boto3():
        try:
            import boto3
            return boto3
        except ImportError:
            return
