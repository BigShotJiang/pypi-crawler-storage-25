# -*- coding: utf-8 -*-
#
#   module unitprotocol.type_check
#

from typing import Dict, List, Mapping, Tuple, Callable


def check_list(arg) -> List:
    """
    Check that the given argument is a list.
    """
    return _check(arg, list, 'a list')


def check_tuple(arg) -> Tuple:
    """
    Check that the given argument is a tuple.
    """
    return _check(arg, tuple, 'a tuple')


def check_dict(arg) -> Dict:
    """
    Check that the given argument is a dictionary.
    """
    return _check(arg, dict, 'a dict')


def check_mapping(arg) -> Mapping:
    """
    Check that the given argument is a mapping.
    """
    return _check(arg, Mapping, 'a Mapping')


def check_int(arg) -> int:
    """
    Validates that the given argument is an integer.
    """
    return _check(arg, int, 'an int')


def check_uint(arg) -> int:
    """
    Check if the argument is a non-negative integer.
    """
    if not isinstance(arg, int) or arg < 0:
        raise TypeError('not a uint')
    return arg


def check_str(arg) -> str:
    """
    Validates that the given argument is a string.
    """
    return _check(arg, str, 'a string')


def check_int_list(arg) -> List[int]:
    """
    Validates that the given argument is a list of integers.
    """
    return _check_list(arg, check_int, 'an int list')


def check_uint_list(arg) -> List[int]:
    """
    Check if the items in the argument list are non-negative integers.
    """
    return _check_list(arg, check_uint, 'an uint list')


def check_uint_tuple(arg) -> Tuple[int]:
    """
    Check if the items in the argument tuple are non-negative integers
    """
    return _check_list(arg, check_uint, 'an uint tuple', tuple)


def check_str_list(arg) -> List[str]:
    """
    Validates that the given argument is a list of strings.
    """
    return _check_list(arg, check_str, 'a string list')


def check_int_tuple(arg) -> Tuple[int]:
    """
    Validates that the given argument is a tuple of integers.
    """
    return _check_list(arg, check_int, 'an int tuple', tuple)


def check_str_tuple(arg) -> Tuple[str]:
    """
    Check if the input argument is a tuple of strings.
    """
    return _check_list(arg, check_str, 'a string tuple', tuple)


def _check(arg, t: type, desc: str):
    """
    Check if the input argument is of the specified type.
    :param arg: the argument to be validated
    :param t: the expected type of the argument
    :param desc: a description of the expected type, used in error messages
    :return: the same arg
    """
    if not isinstance(arg, t):
        raise TypeError('not ' + desc)
    return arg


def _check_list(arg, item_check: Callable, desc: str, list_t=list):
    """
    Check if the input argument is a list of the specified type.
    :param arg: the argument to be validated
    :param item_check: item check function
    :param desc: a description of the expected type, used in error messages
    :param list_t: the expected type of the list, default is `list`
    :return: the same list
    """
    if not isinstance(arg, list_t):
        raise TypeError('not ' + desc)
    for item in arg:
        try:
            item_check(item)
        except TypeError:
            raise TypeError('not ' + desc)
    return arg
