
class AppError(RuntimeError):
    """
    Exception class for errors that occur during the execution of the application.
    """


class ConfigError(ValueError):
    """
    Exception class for errors related to the configuration of the application.
    """


class RetryLimitReachedError(AppError):
    """
    Raised when the maximum number of retry attempts has been reached.
    """


class RetryDeadlineExceededError(AppError):
    """
    Raised when the deadline for retrying a call has been exceeded.
    """
