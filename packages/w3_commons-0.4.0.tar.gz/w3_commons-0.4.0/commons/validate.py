import re
from typing import Any, Dict, Collection, List, Callable, Iterable

from eth_utils import to_checksum_address
from marshmallow import validate, ValidationError, fields
from web3 import Web3


class Positive(validate.Range):
    """
    Ensures a field's value is a positive number.
    """

    def __init__(self, **kwargs):
        super().__init__(0, min_inclusive=False, **kwargs)


class NotEmpty(validate.Length):
    """
    Validate that a sequence is not empty.
    """
    def __init__(self, **kwargs):
        error = kwargs.pop('error', 'Is empty.')
        super().__init__(min=1, error=error, **kwargs)


class HostPort(validate.Validator):
    """
    Validator for strings in the format '<host>:<port>'.
    """
    pattern = re.compile(r'^[a-zA-Z\d.-]+:\d+$')

    def __call__(self, value: Any) -> Any:
        if not self.pattern.match(value):
            raise ValidationError('Invalid host:port format.')
        return value


class AddressField(fields.Str):
    """
    Field for a Web3 address.
    """
    def deserialize(self, *args, **kwargs):
        value = super().deserialize(*args, **kwargs)
        if not Web3.is_address(value):
            raise ValidationError('Is not a Web3 address.')
        return to_checksum_address(value)


def fields_together(data: Dict, fields: Collection[str]):
    """
    Validate that data contains given fields together or neither of them.

    :param data: A dictionary of data to validate.
    :param fields: A list of field names to validate.
    :raises ValidationError: If some of the fields are present in the data and some are missing.
    """
    missing_fields = []
    for field in fields:
        if field not in data:
            missing_fields.append(field)

    if missing_fields and len(missing_fields) != len(fields):
        raise ValidationError({
            field: "Missing data for field."
            for field in missing_fields
        })


def one_field_present(data: Dict, fields: List[str]) -> None:
    """
    Validate that only one of the given fields is present in the data.

    :param data: A dictionary of data to validate.
    :param fields: A list of field names to validate.
    :raises ValidationError: If none or more than one of the fields are present in the data, or all fields are missing.
    """
    present_fields = []
    for field in fields:
        if field in data:
            present_fields.append(field)

    if len(present_fields) == 0:
        raise ValidationError(f'All fields {fields} are missing in the data.')
    elif len(present_fields) != 1:
        raise ValidationError(f'Only one field from {fields} must be present. But {present_fields} are present')


class NoDuplicates(validate.Validator):
    """
    Validate that a sequence doesn't have duplicate entries
    """
    def __init__(self, **kwargs):
        self.key = kwargs.pop('key')
        super().__init__(**kwargs)

    def __call__(self, value: Any) -> Any:
        super().__call__(value)
        keys = set()
        for i, entry in enumerate(value):
            key_value = self.key(entry)
            if key_value in keys:
                raise ValidationError({
                    f'{i}': f'entry has duplicate entry key: {key_value}.'
                })
            keys.add(key_value)

        return value
