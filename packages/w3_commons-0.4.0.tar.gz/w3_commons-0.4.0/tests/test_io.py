import pytest
from commons.io import json_load, json_save, yaml_load, yaml_save

TEST_DATA = {'data': 'some data'}


@pytest.mark.parametrize(
    'dump, load',
    [
        (json_save, json_load),
        (yaml_save, yaml_load)
    ]
)
def test(tmp_path, dump, load):
    path = str((tmp_path / 'file').resolve())
    dump(path, TEST_DATA)
    assert TEST_DATA == load(path)
