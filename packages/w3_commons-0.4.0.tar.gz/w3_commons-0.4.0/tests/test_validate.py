import pytest
from marshmallow import ValidationError
from web3 import Web3

from commons.validate import one_field_present, fields_together, AddressField, HostPort, NotEmpty, Positive, \
    NoDuplicates


def _test_validator(validator, value, is_valid):
    if is_valid:
        assert validator(value) == value
    else:
        with pytest.raises(ValidationError):
            validator(value)


@pytest.mark.parametrize("value, is_valid", [
    ('127.0.0.1:8080', True),
    ('test.com:8080', True),
    ('test.com', False),
    (':8080', False),
    ('127.0.0.1:invalid_port', False)
])
def test_host_port_validator(value, is_valid):
    _test_validator(HostPort(), value, is_valid)


@pytest.mark.parametrize("value, is_valid", [
    ('', False),
    ('abc', True),
    ([], False),
    ([1, 2, 3], True),
])
def test_not_empty_validator(value, is_valid):
    _test_validator(NotEmpty(), value, is_valid)


@pytest.mark.parametrize("value, is_valid", [
    (-1, False),
    (0, False),
    (1, True),
    (1.0, True)
])
def test_positive_validator(value, is_valid):
    _test_validator(Positive(), value, is_valid)


@pytest.mark.parametrize("value, is_valid", [
    ('0x742d35Cc6634C0532925a3b844Bc454e4438f44e', True),
    ('0x742d35Cc6634C0532925a3b844Bc454e4438f44', False),
    ('0x', False),
    ('', False),
    (123, False),
])
def test_address_field(value, is_valid):
    field = AddressField()
    if is_valid:
        assert field.deserialize(value) == Web3.to_checksum_address(value)
    else:
        with pytest.raises(ValidationError):
            field.deserialize(value)


@pytest.mark.parametrize("data, fields, expected_error", [
    ({}, ["field1", "field2"], None),
    ({"field1": "value1", "field2": "value2"}, ["field1", "field2"], None),
    ({"field1": "value1"}, ["field1", "field2"], {"field2": "Missing data for field."}),
])
def test_fields_together(data, fields, expected_error):
    if expected_error:
        with pytest.raises(ValidationError) as e:
            fields_together(data, fields)
        assert e.value.messages == expected_error
    else:
        fields_together(data, fields)


@pytest.mark.parametrize("data, fields, expected_error", [
    ({"field1": "value1"}, ["field1", "field2"], None),
    ({"field1": "value1", "field2": "value2"}, ["field1", "field2"],
     "Only one field from ['field1', 'field2'] must be present. But ['field1', 'field2'] are present"),
    ({}, ["field1", "field2"], "All fields ['field1', 'field2'] are missing in the data.")
])
def test_one_field_present(data, fields, expected_error):
    if expected_error:
        with pytest.raises(ValidationError) as e:
            one_field_present(data, fields)
        assert str(e.value) == expected_error
    else:
        one_field_present(data, fields)


@pytest.mark.parametrize("data, key, expected_error", [
    [[1, 2, 3], int, None],
    [[], int, None],
    [[1, 2, 3, 3], int, {'3': 'entry has duplicate entry key: 3.'}],
    [[1, 3, 2, 2, 2,  3], int, {'3': 'entry has duplicate entry key: 2.'}]
])
def test_no_duplicates(data, key, expected_error):
    validator = NoDuplicates(key=key)
    if expected_error:
        with pytest.raises(ValidationError) as e:
            validator(data)
        assert e.value.messages == expected_error
    else:
        validator(data)
