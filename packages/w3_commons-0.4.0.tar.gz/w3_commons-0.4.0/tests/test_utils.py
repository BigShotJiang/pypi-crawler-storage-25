import time
import pytest
from decimal import Decimal
from logging import Logger

from commons.exceptions import RetryDeadlineExceededError, RetryLimitReachedError
from commons.log import get_class_logger, get_fn_logger
from commons.utils import get_fn_name, retry_call, to_thousands_str, async_retry_call


def some_func():
    pass


class SomeClass:
    pass


class CallableObj:
    calls = 0

    __name__ = 'CallableObj'

    def __init__(self, exceptions_calls_count=0):
        self.exceptions_calls_count = exceptions_calls_count

    def __call__(self, *args, **kwargs):
        self.calls += 1
        if self.calls >= self.exceptions_calls_count:
            return
        raise Exception()


class AsyncCallableObj:
    calls = 0

    __name__ = 'AsyncCallableObj'

    def __init__(self, exceptions_calls_count=0):
        self.exceptions_calls_count = exceptions_calls_count

    async def __call__(self, *args, **kwargs):
        self.calls += 1
        if self.calls >= self.exceptions_calls_count:
            return
        raise Exception()


def test_get_class_logger():
    logger = get_class_logger(SomeClass)
    assert isinstance(logger, Logger)
    assert logger.name == f'{__name__}.SomeClass'


def test_get_fn_logger():
    logger = get_fn_logger(some_func)
    assert isinstance(logger, Logger)
    assert logger.name == f'{__name__}.some_func'


def test_get_fn_name():
    assert get_fn_name(some_func) == f'{__name__}.some_func'


def test_retry_call():
    callable = CallableObj(3)
    retry_call(callable, lambda x: True, standard_delay_secs=0)
    assert callable.calls == 3


def test_retry_limit_reached():
    callable = CallableObj(3)

    with pytest.raises(RetryLimitReachedError) as exc:
        retry_call(callable, lambda x: True, standard_delay_secs=0, attempts=2)

    assert exc.value.__cause__ is not None
    exc.match('Retry limit reached for tests.test_utils.CallableObj')
    assert callable.calls == 2


def test_retry_call_bad_attempts():
    with pytest.raises(ValueError) as exc:
        retry_call(lambda : True, lambda x: True, attempts=0)
    exc.match('bad attempts value')


def test_retry_deadline_reached(monkeypatch):
    now = 100.0
    sleep_calls = []

    def _fake_time():
        return now

    def _fake_sleep(delay):
        nonlocal now
        sleep_calls.append(delay)
        now += delay

    monkeypatch.setattr('commons.utils.time', _fake_time)
    monkeypatch.setattr('commons.utils.sleep', _fake_sleep)

    callable = CallableObj(4)
    with pytest.raises(RetryDeadlineExceededError) as exc:
        retry_call(
            callable,
            should_repeat_call=lambda x: True,
            standard_delay_secs=1,
            attempts=4,
            exponential_backoff=False,
            deadline=_fake_time() + 0.5
        )
    assert exc.value.__cause__ is not None
    exc.match('Execution deadline exceeded for tests.test_utils.CallableObj')
    assert callable.calls == 3
    assert len(sleep_calls) == 1
    assert sleep_calls[0] == pytest.approx(0.5)


def test_retry_call_unrecoverable_error():
    callable = CallableObj(3)
    with pytest.raises(Exception):
        retry_call(callable, lambda x: False, standard_delay_secs=0)
    assert callable.calls == 1


def test_retry_call_exponential_backoff(monkeypatch):
    sleep_calls = []

    monkeypatch.setattr('commons.utils.sleep', lambda delay: sleep_calls.append(delay))
    callable = CallableObj(4)

    retry_call(callable, lambda x: True, standard_delay_secs=1, attempts=4, exponential_backoff=True)

    assert callable.calls == 4
    assert sleep_calls == [1, 2]


@pytest.mark.asyncio
async def test_async_retry_call():
    async_callable = AsyncCallableObj(3)
    await async_retry_call(async_callable, lambda x: True, standard_delay_secs=0)
    assert async_callable.calls == 3


@pytest.mark.asyncio
async def test_async_retry_call_limit_reached():
    async_callable = AsyncCallableObj(3)

    with pytest.raises(RetryLimitReachedError) as exc:
        await async_retry_call(async_callable, lambda x: True, standard_delay_secs=0, attempts=2)

    assert exc.value.__cause__ is not None
    exc.match('Retry limit reached for tests.test_utils.AsyncCallableObj')
    assert async_callable.calls == 2


@pytest.mark.asyncio
async def test_async_retry_call_bad_attempts():
    with pytest.raises(ValueError) as exc:
        await async_retry_call(lambda: True, lambda x: True, attempts=0)
    exc.match('bad attempts value')


@pytest.mark.asyncio
async def test_async_retry_deadline_reached(monkeypatch):
    now = 100.0
    sleep_calls = []

    def _fake_time():
        return now

    async def _fake_sleep(delay):
        nonlocal now
        sleep_calls.append(delay)
        now += delay

    monkeypatch.setattr('commons.utils.time', _fake_time)
    monkeypatch.setattr('commons.utils.asyncio.sleep', _fake_sleep)

    async_callable = AsyncCallableObj(4)

    with pytest.raises(RetryDeadlineExceededError) as exc:
        await async_retry_call(
            async_callable,
            should_repeat_call=lambda x: True,
            standard_delay_secs=1,
            attempts=4,
            exponential_backoff=False,
            deadline=_fake_time() + 0.5
        )
    assert exc.value.__cause__ is not None
    exc.match('Execution deadline exceeded for tests.test_utils.AsyncCallableObj')
    assert async_callable.calls == 3
    assert len(sleep_calls) == 1
    assert sleep_calls[0] == pytest.approx(0.5)


@pytest.mark.asyncio
async def test_async_retry_call_unrecoverable_error():
    callable = AsyncCallableObj(3)
    with pytest.raises(Exception):
        await async_retry_call(callable, lambda x: False, standard_delay_secs=0)
    assert callable.calls == 1


@pytest.mark.asyncio
async def test_async_retry_call_exponential_backoff(monkeypatch):
    sleep_calls = []

    async def _fake_sleep(delay):
        sleep_calls.append(delay)

    monkeypatch.setattr('commons.utils.asyncio.sleep', _fake_sleep)
    callable = AsyncCallableObj(4)

    await async_retry_call(callable, lambda x: True, standard_delay_secs=1, attempts=4, exponential_backoff=True)

    assert callable.calls == 4
    assert sleep_calls == [1, 2]


@pytest.mark.parametrize(
    'val, res',
    [
        (110_000, '110K'),
        (1500.5, '1K'),
        (Decimal('200000.5'), '200K')
    ]
)
def test_to_thousands_str(val, res):
    assert to_thousands_str(val) == res
