import pytest
from commons import type_check


@pytest.mark.parametrize(
    'check_func, input, is_raises',
    [
        (type_check.check_list, [], False),
        (type_check.check_list, tuple(), True),

        (type_check.check_dict, {}, False),
        (type_check.check_dict, [], True),

        (type_check.check_mapping, {}, False),
        (type_check.check_mapping, [], True),

        (type_check.check_int, 1, False),
        (type_check.check_int, 1., True),

        (type_check.check_str, 'str', False),
        (type_check.check_str, None, True),

        (type_check.check_int_list, [1], False),
        (type_check.check_int_list, [], False),
        (type_check.check_int_list, ['1'], True),
        (type_check.check_int_list, (1,), True),

        (type_check.check_int_tuple, (1,), False),
        (type_check.check_int_tuple, tuple(), False),
        (type_check.check_int_tuple, ('1',), True),
        (type_check.check_int_tuple, [1], True),

        (type_check.check_str_list, [""], False),
        (type_check.check_str_list, [], False),
        (type_check.check_str_list, [1], True),
        (type_check.check_str_list, ("",), True),

        (type_check.check_str_tuple, ("",), False),
        (type_check.check_str_tuple, tuple(), False),
        (type_check.check_str_tuple, (1,), True),
        (type_check.check_str_tuple, [""], True),
    ]
)
def test(check_func, input, is_raises):
    print(check_func, input, is_raises)
    if is_raises:
        with pytest.raises(TypeError):
            check_func(input)
    else:
        assert input is check_func(input)
