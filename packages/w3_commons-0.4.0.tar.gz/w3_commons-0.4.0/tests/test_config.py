import re
import copy
import pytest
import yaml

from typing import Dict, Any
from commons.testlib import stub
from commons.config import Config
from commons.exceptions import ConfigError


DEL = '_$#DEL'
CONFIG_DICT = {
    'http_proxy': 'user:password@proxy.com:2203',
}


def change_dict(data, path, val):
    data = copy.deepcopy(data)
    if path is None:
        return data

    target = data

    keys = path.split('.') if isinstance(path, str) else path
    assert isinstance(keys, (tuple, list)), 'Path type error'
    for i, key in enumerate(keys):
        if i == len(keys) - 1:
            if val == DEL:
                del target[key]
            else:
                target[key] = val
        else:
            target = target[key]
    return data


@pytest.fixture
def config_generator_factory(tmp_path):
    def _(path, val):
        file = tmp_path / 'fo-config.yaml'
        yaml.dump(change_dict(CONFIG_DICT, path, val), file.open('w'), default_flow_style=False)
        return str(file.resolve())

    return _


@pytest.fixture
def include_factory(tmp_path):
    def _(data):
        include_file = tmp_path / 'include.yaml'
        yaml.dump(data, include_file.open('w'))
        return str(include_file.resolve())

    return _


@pytest.fixture
def config(config_generator_factory):
    return Config(config_generator_factory(None, None))


@pytest.mark.parametrize(
    'key, default, expected_value',
    [
        ('http_proxy', None, CONFIG_DICT['http_proxy']),
        ('_http_proxy', 'some value', 'some value'),
    ]
)
def test_get(config: Config, key, default, expected_value):
    assert expected_value == config.get(key, default)


@pytest.mark.parametrize(
    'key, contains',
    [
        ('http_proxy', True),
        ('_http_proxy', False),
    ]
)
def test_in(config: Config, key, contains):
    assert (key in config) == contains


def test_load_yaml_non_dict_config(tmp_path):
    file = tmp_path / 'fo-config.yaml'
    file.write_text('str')

    with pytest.raises(ConfigError, match='Config is not a mapping'):
        Config(str(file.resolve()))


def test_load_yaml_include(include_factory, config_generator_factory):
    include_data = {'some': 'data'}
    additional_data = {'foo': 'bar'}

    config = Config(
        config_generator_factory(
            'section_with_include',
            {
                'include': include_factory(include_data),
                **additional_data
            },
        )
    )
    assert config.get('section_with_include') == {**include_data, **additional_data}


@pytest.mark.parametrize('include_type', ['include', 'override'])
def test_load_yaml_include_loop(tmp_path, config_generator_factory, include_type):
    include_file = tmp_path / 'include.yaml'
    path = str(include_file.resolve())
    yaml.dump({'include': path, 'foo': 'bar'}, include_file.open('w'))

    with pytest.raises(ConfigError, match='Include loop found'):
        Config(
            config_generator_factory(
                'section_with_include',
                {
                    include_type: path,
                },
            )
        )


@pytest.mark.parametrize('include_value', [2, False, {'x': 'y'}, [2], [False], [['str']], [{'x': 'y'}]])
@pytest.mark.parametrize('include_type', ['include', 'override'])
def test_load_yaml_include_empty_path(config_generator_factory, include_value, include_type):
    with pytest.raises(ConfigError, match='Malformed include/override'):
        Config(
            config_generator_factory(
                'section_with_include',
                {
                    include_type: include_value,
                },
            )
        )


def test_load_yaml_include_colliding_keys(include_factory, config_generator_factory):
    include_data = {'some': 'data'}

    with pytest.raises(ConfigError, match=re.escape('Colliding keys (some) found in an include while processing')):
        Config(
            config_generator_factory(
                'section_with_include',
                {
                    'include': include_factory(include_data),
                    **include_data
                },
            )
    )


def test_load_yaml_override(include_factory, config_generator_factory):
    include_data = {'some': 'data'}
    additional_data = {'foo': 'bar', 'some': 'old_data'}

    config = Config(
        config_generator_factory(
            'section_with_include',
            {
                'override': include_factory(include_data),
                **additional_data
            },
        )
    )
    assert config.get('section_with_include') == {**additional_data, **include_data, }


@pytest.fixture
def webserver_factory(mocker):
    def _(content: Dict[str, Any]):
        def web_server(url, *args, **kwargs):
            if url not in content:
                pytest.fail(f'Unexpected url requested: {url}')
            text = content[url] if isinstance(content[url], str) else yaml.dump(content[url], default_flow_style=False)
            return stub(status_code=200, text=text)

        mocker.patch('requests.get').side_effect = web_server

    return _


def test_include_bad_relative_path(webserver_factory):
    webserver_factory({
        'https://example.com/some/conf.yaml': {'section_with_include': {'include': '/other.yaml'}},
        'https://example.com/some/': {'section_with_include': {'include': 'other.yaml'}}
    })

    with pytest.raises(ConfigError, match='Include starting with .*is not supported yet'):
        Config('https://example.com/some/conf.yaml')

    with pytest.raises(ConfigError, match='Can\'t make a path relative to'):
        Config('https://example.com/some/')


def test_https_includes(webserver_factory):
    webserver_factory({
        'https://example.com/some/conf.yaml': {'x': 'y', 'section_with_include': {'include': [
            'other.yaml',
            'https://example.org/conf'
        ]}},
        'https://example.com/some/other.yaml': {'foo': 'bar'},
        'https://example.org/conf': {'baz': 100}
    })

    assert Config('https://example.com/some/conf.yaml')._cfg == {
        'x': 'y',
        'section_with_include': {
            'foo': 'bar',
            'baz': 100,
        },
    }


def test_https_include_loop(webserver_factory):
    webserver_factory({
        'https://example.com/some/conf.yaml': {'x': 'y', 'section_with_include': {'include': [
            'other.yaml',
            'https://example.org/conf'
        ]}},
        'https://example.com/some/other.yaml': {'foo': 'bar'},
        'https://example.org/conf': {'baz': {'include': 'HTTPS://example.com/some/conf.yaml'}}
    })

    with pytest.raises(ConfigError, match='Include loop found'):
        Config('https://example.com/some/conf.yaml')


def test_supported_file_protocols(config_generator_factory):
    with pytest.raises(ConfigError, match='Remote protocol .+ is not allowed'):
        Config('https://example.com/some/conf.yaml', supported_file_protocols={Config.RemoteProtocol.FILE})

    with pytest.raises(ConfigError, match='Remote protocol .+ is not allowed'):
        Config(
            config_generator_factory(
                'section_with_include',
                {
                    'include': 'https://example.com/some/conf.yaml',
                },
            ),
            supported_file_protocols={Config.RemoteProtocol.FILE}
        )


@pytest.mark.parametrize('url', ['https://example.com/some/c.yaml', 'https://example.com/some/conf.yaml'])
def test_supported_value_protocols(webserver_factory, url):
    webserver_factory({
        'https://example.com/some/c.yaml': {'x': 'y', 'baz': 'include:s3://bucket/path'},
        'https://example.com/some/conf.yaml': {'x': 'y', 'section_with_include': {'include': 'other.yaml'}},
        'https://example.com/some/other.yaml': {'foo': 'bar', 'baz': 'include:s3://bucket/path'},
    })

    with pytest.raises(ConfigError, match='Remote protocol .+ is not allowed while loading a string'):
        Config(url, supported_value_protocols={Config.RemoteProtocol.FILE, Config.RemoteProtocol.HTTPS})


def test_included_values(webserver_factory):
    webserver_factory({
        'https://example.com/some/c': 'c value',
        'https://example.com/some/conf.yaml': {
            'foo': 'bar',
            'foo2': [4, 'include:https://example.com/some/c', 11],
            'baz': 'include:https://example.com/some/c',
            'baz2': 'https://example.com/some/c',
            'baz3': 'include:c',
        },
    })

    assert Config('https://example.com/some/conf.yaml')._cfg == {
            'foo': 'bar',
            'foo2': [4, 'c value', 11],
            'baz': 'c value',
            'baz2': 'https://example.com/some/c',
            'baz3': 'include:c',
        }
