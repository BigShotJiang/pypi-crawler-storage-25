"""Shared helpers for governed-action Control API support."""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Optional
from uuid import uuid4

from ._version import __version__ as _SDK_VERSION

_PRESET_BY_ACTION: Dict[str, Dict[str, str]] = {
    "github.issue.create": {
        "connector": "github",
        "route_operation": "issues/create",
        "action_name": "issue.create",
        "resource_type": "issue",
    },
    "slack.message.send": {
        "connector": "slack",
        "route_operation": "messages/send",
        "action_name": "message.send",
        "resource_type": "message",
    },
    "linear.issue.create": {
        "connector": "linear",
        "route_operation": "issues",
        "action_name": "issue.create",
        "resource_type": "issue",
    },
    "pagerduty.incident.trigger": {
        "connector": "pagerduty",
        "route_operation": "incidents",
        "action_name": "incident.trigger",
        "resource_type": "incident",
    },
    "http.request": {
        "connector": "http",
        "route_operation": "",
        "action_name": "request",
        "resource_type": "request",
    },
}

_PRESET_BY_ROUTE: Dict[str, Dict[str, str]] = {
    f"{preset['connector']}/{preset['route_operation']}".rstrip("/"): preset
    for preset in _PRESET_BY_ACTION.values()
}

_PRESET_BY_CONNECTOR_AND_ACTION: Dict[str, Dict[str, str]] = {
    f"{preset['connector']}:{preset['action_name']}": preset
    for preset in _PRESET_BY_ACTION.values()
}


def canonical_json(value: Any) -> str:
    """Match Control's stable JSON encoding for hashes and signatures."""
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def stable_hash(value: Any) -> str:
    """Return a sha256 hash of the canonical JSON payload."""
    payload = canonical_json(value).encode("utf-8")
    return f"sha256:{hashlib.sha256(payload).hexdigest()}"


def parse_tenant_id(api_key: str) -> str:
    """Extract tenant_id from an nram_<tenant>_<signature> API key."""
    parts = api_key.split("_", 2)
    if len(parts) < 3 or parts[0] != "nram":
        raise ValueError("Invalid Novyx API key format")
    return parts[1]


def utc_now_iso() -> str:
    """Return the current UTC timestamp in ISO 8601 Z format."""
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def future_iso(seconds: int) -> str:
    """Return a UTC timestamp offset into the future."""
    return (datetime.now(timezone.utc) + timedelta(seconds=seconds)).isoformat().replace("+00:00", "Z")


def resolve_control_target(
    action: str,
    *,
    connector: Optional[str] = None,
    operation: Optional[str] = None,
    resource_type: Optional[str] = None,
) -> Dict[str, str]:
    """Resolve a governed action shortcut into a concrete Control target."""
    preset: Optional[Dict[str, str]] = None

    if connector and operation:
        route_key = f"{connector}/{operation}".rstrip("/")
        preset = _PRESET_BY_ROUTE.get(route_key)
        if not preset:
            action_name = action if action not in _PRESET_BY_ROUTE else action
            return {
                "connector": connector,
                "route_operation": operation,
                "action_name": action_name,
                "resource_type": resource_type or connector,
            }

    if not preset and action in _PRESET_BY_ACTION:
        preset = _PRESET_BY_ACTION[action]

    if not preset and action in _PRESET_BY_ROUTE:
        preset = _PRESET_BY_ROUTE[action]

    if not preset and connector:
        preset = _PRESET_BY_CONNECTOR_AND_ACTION.get(f"{connector}:{action}")

    if preset:
        resolved = dict(preset)
        if resource_type:
            resolved["resource_type"] = resource_type
        return resolved

    supported = ", ".join(sorted(_PRESET_BY_ACTION))
    raise ValueError(
        "Unsupported governed action shortcut. "
        f"Use one of: {supported}, or pass connector= and operation= explicitly."
    )


def build_action_envelope(
    *,
    tenant_id: str,
    action_name: str,
    connector: str,
    route_operation: str,
    payload: Dict[str, Any],
    resource_ref: str,
    resource_type: str,
    parameters: Optional[Dict[str, Any]] = None,
    risk_tier: str = "high",
    environment: str = "production",
    agent_id: str = "agt_novyx_sdk",
    agent_key_id: Optional[str] = None,
    agent_type: str = "service",
    framework: str = "novyx-sdk",
    framework_version: Optional[str] = None,
    delegated_by_type: str = "user",
    delegated_by_id: str = "usr_owner_default",
    justification: Optional[str] = None,
    scope: Optional[list[str]] = None,
    metadata: Optional[Dict[str, Any]] = None,
    policy_context: Optional[Dict[str, Any]] = None,
    action_id: Optional[str] = None,
    trace_id: Optional[str] = None,
    idempotency_key: Optional[str] = None,
    expires_in_seconds: int = 300,
    delegation_expires_in_seconds: int = 3600,
) -> Dict[str, Any]:
    """Build a valid strata.action.v0 envelope for Novyx Control."""
    # Default framework_version to the live SDK version. Caller can override
    # if they're embedding this envelope inside another framework.
    if framework_version is None:
        framework_version = _SDK_VERSION
    action_suffix = uuid4().hex[:12]
    resolved_action_id = action_id or f"act_{action_suffix}"
    resolved_trace_id = trace_id or f"trc_{action_suffix}"
    issued_at = utc_now_iso()
    expires_at = future_iso(expires_in_seconds)
    delegation_expires_at = future_iso(delegation_expires_in_seconds)
    request_parameters = parameters if parameters is not None else payload
    resolved_scope = scope or [f"{connector}.{action_name}"]
    resolved_agent_key_id = agent_key_id or f"key_{agent_id}"

    envelope: Dict[str, Any] = {
        "version": "strata.action.v0",
        "action_id": resolved_action_id,
        "tenant_id": tenant_id,
        "trace_id": resolved_trace_id,
        "issued_at": issued_at,
        "expires_at": expires_at,
        "idempotency_key": idempotency_key or f"idem_{action_suffix}",
        "risk_tier": risk_tier,
        "actor": {
            "agent_id": agent_id,
            "agent_key_id": resolved_agent_key_id,
            "agent_type": agent_type,
            "framework": framework,
            "framework_version": framework_version,
        },
        "delegation": {
            "delegation_id": f"del_{action_suffix}",
            "delegated_by": {
                "type": delegated_by_type,
                "id": delegated_by_id,
            },
            "scope": resolved_scope,
            "justification": justification or f"Governed {connector}.{action_name} request via Novyx SDK",
            "expires_at": delegation_expires_at,
        },
        "operation": {
            "connector": connector,
            "action": action_name,
            "resource_type": resource_type,
            "resource_ref": resource_ref,
            "environment": environment,
        },
        "request": {
            "payload_hash": stable_hash(payload),
            "payload_schema": f"{connector}.{action_name}.v1",
            "parameters": request_parameters,
            "body": payload,
        },
        "policy_context": {
            "policy_ids": [f"pol_{connector}_{action_name.replace('.', '_')}_v1"],
            "requires_approval": risk_tier != "low" or environment == "production",
            "approval_policy": f"{connector}-policy",
        },
        "metadata": {
            "source": "novyx.sdk",
            "sdk": "novyx",
            "sdk_version": framework_version,
            "route_operation": route_operation,
        },
    }

    if metadata:
        envelope["metadata"].update(metadata)
    if policy_context:
        envelope["policy_context"].update(policy_context)

    return envelope


def normalize_action_response(data: Dict[str, Any]) -> Dict[str, Any]:
    """Add stable top-level fields to Control action responses."""
    if not isinstance(data, dict):
        return {"raw": data}

    result = dict(data)
    action = result.get("action")
    approval = result.get("approval")

    if isinstance(action, dict):
        result.setdefault("id", action.get("action_id") or action.get("id"))
        result.setdefault("status", action.get("status"))
        result.setdefault("trace_id", action.get("trace_id") or action.get("traceId"))
        if isinstance(action.get("approval"), dict):
            result.setdefault("approval_id", action["approval"].get("approval_id"))

    if isinstance(approval, dict):
        result.setdefault("approval_id", approval.get("approval_id"))
        if "status" not in result and approval.get("status"):
            result["status"] = approval["status"]

    result.setdefault("executed", result.get("status") == "executed")
    return result
