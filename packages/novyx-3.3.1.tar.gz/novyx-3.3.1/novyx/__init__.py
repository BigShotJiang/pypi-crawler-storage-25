"""
Novyx SDK — Agent memory infrastructure.

Store, recall, rollback, eval, and cryptographic audit for AI agents.

Quick Start (sync):
    >>> from novyx import Novyx
    >>> nx = Novyx(api_key="nram_your_key_here")
    >>> nx.remember("User prefers dark mode", tags=["ui"])
    >>> memories = nx.recall("user preferences")
    >>> health = nx.eval_run()
    >>> print(f"Memory health: {health['health_score']}")

Quick Start (async):
    >>> from novyx import AsyncNovyx
    >>> async with AsyncNovyx(api_key="nram_your_key") as nx:
    ...     await nx.remember("User prefers dark mode")
    ...     result = await nx.recall("user preferences")
"""

from .client import ListResult, Memory, Novyx, NovyxSession, SearchResult
from .exceptions import (
    NovyxAuthError,
    NovyxError,
    NovyxForbiddenError,
    NovyxNotFoundError,
    NovyxRateLimitError,
    NovyxSecurityError,
    NovyxUpgradeRequired,  # Legacy alias
)


# Lazy import for AsyncNovyx — avoids httpx dependency at import time
def __getattr__(name):
    if name == "AsyncNovyx":
        from .async_client import AsyncNovyx

        return AsyncNovyx
    raise AttributeError(f"module 'novyx' has no attribute {name}")


from ._version import __version__
__all__ = [
    "Novyx",
    "AsyncNovyx",
    "NovyxSession",
    "Memory",
    "SearchResult",
    "ListResult",
    "NovyxError",
    "NovyxAuthError",
    "NovyxForbiddenError",
    "NovyxRateLimitError",
    "NovyxNotFoundError",
    "NovyxSecurityError",
    "NovyxUpgradeRequired",
]
