"""Shared HTTP response handling for sync and async SDK clients."""

from __future__ import annotations

from typing import Any, Callable

from .exceptions import (
    NovyxAuthError,
    NovyxError,
    NovyxForbiddenError,
    NovyxNotFoundError,
    NovyxRateLimitError,
)

EMPTY_RESPONSE = object()


def raise_known_response_error(
    status_code: int,
    text: str,
    json_loader: Callable[[], Any],
) -> None:
    """Raise structured SDK exceptions for common API status codes."""
    if status_code == 401:
        raise NovyxAuthError("Invalid API key or unauthorized")

    if status_code not in {403, 404, 429}:
        return

    data = {}
    if text:
        try:
            parsed = json_loader()
            if isinstance(parsed, dict):
                data = parsed
        except Exception:
            data = {}

    if status_code == 403:
        raise NovyxForbiddenError(data.get("error", "Forbidden"), data)
    if status_code == 404:
        raise NovyxNotFoundError(data.get("error", "Not found"))
    raise NovyxRateLimitError(data.get("error", "Rate limit exceeded"), data)


def parse_json_response(
    status_code: int,
    text: str,
    json_loader: Callable[[], Any],
) -> Any:
    """Parse a JSON API response after known status codes are handled."""
    if status_code == 204 or not text:
        return EMPTY_RESPONSE

    try:
        response_data = json_loader()
    except Exception:
        if status_code >= 400:
            raise NovyxError(f"HTTP {status_code}: {text[:200]}")
        raise NovyxError(f"Invalid JSON response: {text[:200]}")

    if status_code >= 400:
        raise NovyxError(f"HTTP {status_code}: {response_data}")

    return response_data
