"""Single source of truth for the novyx SDK version.

Both `novyx/__init__.py` and the sync/async clients + control envelope
import from here so the published version, User-Agent header, and
governed-action `framework_version` metadata can never drift.

When releasing, bump this string AND `sdk/setup.py`. The publish
workflow verifies they match before uploading.
"""

__version__ = "3.3.1"
