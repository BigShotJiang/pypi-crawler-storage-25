"""Unit tests for Novyx SDK client."""
from unittest.mock import Mock, patch

import pytest
from novyx import (
    Novyx,
    NovyxAuthError,
    NovyxError,
    NovyxForbiddenError,
    NovyxNotFoundError,
    NovyxRateLimitError,
)


@pytest.fixture
def nx():
    """Create Novyx client with test API key."""
    return Novyx(api_key="nram_test_12345678", api_url="https://test.example.com")


@pytest.fixture
def control_nx():
    """Create Novyx client configured for Novyx Control."""
    return Novyx(
        api_key="nram_test_12345678",
        api_url="https://test.example.com",
        control_url="https://control.example.com",
        control_api_key="strata_test_default_key",
    )


@pytest.fixture
def mock_response():
    """Create mock response object."""
    response = Mock()
    response.status_code = 200
    response.text = '{"success": true}'
    response.json.return_value = {"success": True}
    response.content = b"test content"
    return response


# ============================================================================
# Initialization & Auth Tests
# ============================================================================

def test_init_valid_key():
    """Test initialization with valid API key."""
    nx = Novyx(api_key="nram_tenant_signature")
    assert nx.api_key == "nram_tenant_signature"
    assert nx.api_url == "https://novyx-ram-api.fly.dev"


def test_init_invalid_key():
    """Test initialization with invalid API key format."""
    with pytest.raises(NovyxAuthError):
        Novyx(api_key="invalid_key")


def test_headers(nx):
    """Test request headers include auth token."""
    headers = nx._headers()
    assert headers["Authorization"] == "Bearer nram_test_12345678"
    assert headers["Content-Type"] == "application/json"


# ============================================================================
# Error Handling Tests
# ============================================================================

@patch('novyx.client.requests.request')
def test_error_401_raises_auth_error(mock_request, nx):
    """Test 401 response raises NovyxAuthError."""
    mock_response = Mock()
    mock_response.status_code = 401
    mock_request.return_value = mock_response

    with pytest.raises(NovyxAuthError):
        nx._request("GET", "/test")


@patch('novyx.client.requests.request')
def test_error_403_raises_forbidden_error(mock_request, nx):
    """Test 403 response raises NovyxForbiddenError."""
    mock_response = Mock()
    mock_response.status_code = 403
    mock_response.text = '{"error": "Pro tier required"}'
    mock_response.json.return_value = {"error": "Pro tier required"}
    mock_request.return_value = mock_response

    with pytest.raises(NovyxForbiddenError) as exc_info:
        nx._request("GET", "/test")

    assert "Pro tier required" in str(exc_info.value)


@patch('novyx.client.requests.request')
def test_error_404_raises_not_found_error(mock_request, nx):
    """Test 404 response raises NovyxNotFoundError."""
    mock_response = Mock()
    mock_response.status_code = 404
    mock_response.text = '{"error": "Not found"}'
    mock_response.json.return_value = {"error": "Not found"}
    mock_request.return_value = mock_response

    with pytest.raises(NovyxNotFoundError):
        nx._request("GET", "/test")


@patch('novyx.client.requests.request')
def test_error_429_raises_rate_limit_error(mock_request, nx):
    """Test 429 response raises NovyxRateLimitError."""
    mock_response = Mock()
    mock_response.status_code = 429
    mock_response.text = '{"error": "Rate limit exceeded", "current": 100, "limit": 100}'
    mock_response.json.return_value = {
        "error": "Rate limit exceeded",
        "current": 100,
        "limit": 100
    }
    mock_request.return_value = mock_response

    with pytest.raises(NovyxRateLimitError) as exc_info:
        nx._request("GET", "/test")

    assert exc_info.value.current == 100
    assert exc_info.value.limit == 100


@patch('novyx.client.requests.request')
def test_error_500_invalid_json_raises_novyx_error(mock_request, nx):
    """Test invalid JSON error bodies still raise a readable NovyxError."""
    mock_response = Mock()
    mock_response.status_code = 500
    mock_response.text = "internal failure"
    mock_response.json.side_effect = ValueError("not json")
    mock_request.return_value = mock_response

    with pytest.raises(NovyxError) as exc_info:
        nx._request("GET", "/test")

    assert "HTTP 500: internal failure" in str(exc_info.value)


# ============================================================================
# Memory Methods Tests
# ============================================================================

@patch('novyx.client.requests.request')
def test_remember(mock_request, nx, mock_response):
    """Test remember() stores a memory."""
    mock_response.json.return_value = {"uuid": "test-uuid", "message": "Stored"}
    mock_request.return_value = mock_response

    result = nx.remember("Test memory", tags=["test"], importance=7)

    assert result["uuid"] == "test-uuid"
    mock_request.assert_called_once()
    call_kwargs = mock_request.call_args[1]
    assert call_kwargs["json"]["observation"] == "Test memory"
    assert call_kwargs["json"]["tags"] == ["test"]
    assert call_kwargs["json"]["importance"] == 7


@patch('novyx.client.requests.request')
def test_remember_with_metadata(mock_request, nx, mock_response):
    """Test remember() sends metadata as its own field."""
    mock_response.json.return_value = {"uuid": "test-uuid"}
    mock_request.return_value = mock_response

    nx.remember("Test", metadata={"key": "value"})

    call_kwargs = mock_request.call_args[1]
    assert call_kwargs["json"]["metadata"] == {"key": "value"}


@patch('novyx.client.requests.request')
def test_remember_with_metadata_and_context(mock_request, nx, mock_response):
    """Test remember() sends both context and metadata when both provided."""
    mock_response.json.return_value = {"uuid": "test-uuid"}
    mock_request.return_value = mock_response

    nx.remember("Test", context="repo/pr#1", metadata={"repo": "test"})

    call_kwargs = mock_request.call_args[1]
    assert call_kwargs["json"]["context"] == "repo/pr#1"
    assert call_kwargs["json"]["metadata"] == {"repo": "test"}


@patch('novyx.client.requests.request')
def test_recall(mock_request, nx, mock_response):
    """Test recall() searches memories."""
    mock_response.json.return_value = [
        {"observation": "Test memory", "score": 0.95, "uuid": "test-uuid"}
    ]
    mock_request.return_value = mock_response

    result = nx.recall("test query", limit=5)

    assert len(result) == 1
    assert result.memories[0].observation == "Test memory"
    assert result.query == "test query"
    mock_request.assert_called_once()


@patch('novyx.client.requests.request')
def test_memories(mock_request, nx, mock_response):
    """Test memories() lists all memories."""
    mock_response.json.return_value = {
        "memories": [
            {"uuid": "test-1", "observation": "Memory 1"},
            {"uuid": "test-2", "observation": "Memory 2"}
        ]
    }
    mock_request.return_value = mock_response

    memories = nx.memories(limit=100)

    assert len(memories) == 2
    assert memories[0]["uuid"] == "test-1"


@patch('novyx.client.requests.request')
def test_memory(mock_request, nx, mock_response):
    """Test memory() gets specific memory by ID."""
    mock_response.json.return_value = {"uuid": "test-uuid", "observation": "Test"}
    mock_request.return_value = mock_response

    memory = nx.memory("test-uuid")

    assert memory["uuid"] == "test-uuid"
    assert "/v1/memories/test-uuid" in mock_request.call_args.kwargs["url"]


@patch('novyx.client.requests.request')
def test_forget(mock_request, nx, mock_response):
    """Test forget() deletes a memory."""
    mock_response.json.return_value = {"success": True}
    mock_request.return_value = mock_response

    result = nx.forget("test-uuid")

    assert result is True
    assert mock_request.call_args.kwargs["method"] == "DELETE"


@patch('novyx.client.requests.request')
def test_stats(mock_request, nx, mock_response):
    """Test stats() returns memory statistics."""
    mock_response.json.return_value = {"total_memories": 42, "avg_importance": 5.5}
    mock_request.return_value = mock_response

    stats = nx.stats()

    assert stats["total_memories"] == 42
    assert "/v1/memories/stats" in mock_request.call_args.kwargs["url"]


@patch('novyx.client.requests.request')
def test_create_agent(mock_request, nx, mock_response):
    """Test create_agent() posts the expected payload."""
    mock_response.json.return_value = {"id": "agt_123", "name": "planner"}
    mock_request.return_value = mock_response

    result = nx.create_agent(
        name="planner",
        provider="openai",
        model="gpt-4o",
        description="Plans work",
        instructions="You are a planning agent.",
    )

    assert result["id"] == "agt_123"
    call_kwargs = mock_request.call_args.kwargs
    assert call_kwargs["method"] == "POST"
    assert call_kwargs["url"].endswith("/v1/agents")
    assert call_kwargs["json"]["name"] == "planner"
    assert call_kwargs["json"]["description"] == "Plans work"


@patch('novyx.client.requests.request')
def test_list_agents(mock_request, nx, mock_response):
    """Test list_agents() sends status and pagination params."""
    mock_response.json.return_value = {"items": [{"id": "agt_123"}], "total": 1}
    mock_request.return_value = mock_response

    result = nx.list_agents(status="active", limit=25, offset=50)

    assert result["total"] == 1
    call_kwargs = mock_request.call_args.kwargs
    assert call_kwargs["method"] == "GET"
    assert call_kwargs["params"] == {"status": "active", "limit": 25, "offset": 50}


@patch('novyx.client.requests.request')
def test_request_action_builds_and_submits_governed_envelope(mock_request, control_nx, mock_response):
    """Test request_action() builds a valid envelope and hits the Control route."""
    mock_response.json.return_value = {
        "action": {"action_id": "act_123", "status": "pending_approval", "trace_id": "trc_123"},
        "approval": {"approval_id": "apr_123", "status": "pending"},
        "policy": {"decision": "require_approval", "requires_approval": True},
    }
    mock_request.return_value = mock_response

    result = control_nx.request_action(
        "github.issue.create",
        payload={"owner": "acme", "repo": "api", "title": "Bug report"},
        resource_ref="github://acme/api/issues",
        parameters={"owner": "acme", "repo": "api"},
        agent_id="agt_planner",
    )

    assert result["id"] == "act_123"
    assert result["approval_id"] == "apr_123"
    call_kwargs = mock_request.call_args.kwargs
    assert call_kwargs["method"] == "POST"
    assert call_kwargs["url"].endswith("/v1/actions/github/issues/create")
    envelope = call_kwargs["json"]
    assert envelope["tenant_id"] == "test"
    assert envelope["actor"]["agent_id"] == "agt_planner"
    assert envelope["operation"]["connector"] == "github"
    assert envelope["operation"]["action"] == "issue.create"
    assert envelope["request"]["body"]["title"] == "Bug report"


@patch('novyx.client.requests.request')
def test_request_action_supports_http_route_without_extra_operation_segment(mock_request, control_nx, mock_response):
    """Test request_action() targets /v1/actions/http for http.request."""
    mock_response.json.return_value = {
        "action": {"action_id": "act_http", "status": "executed"},
    }
    mock_request.return_value = mock_response

    result = control_nx.request_action(
        "http.request",
        payload={"method": "POST", "url": "https://api.example.com/users/delete", "body": {"id": "u_291"}},
        resource_ref="https://api.example.com/users/delete",
        risk_tier="low",
        environment="staging",
    )

    assert result["executed"] is True
    call_kwargs = mock_request.call_args.kwargs
    assert call_kwargs["url"].endswith("/v1/actions/http")


@patch('novyx.client.requests.request')
def test_approve_accepts_submit_response_and_uses_control_route(mock_request, control_nx, mock_response):
    """Test approve() resolves approval_id from a submit response payload."""
    mock_response.json.return_value = {
        "action": {"action_id": "act_123", "status": "executed"},
        "approval": {"approval_id": "apr_123", "status": "approved"},
    }
    mock_request.return_value = mock_response

    result = control_nx.approve(
        {"id": "act_123", "approval": {"approval_id": "apr_123"}},
        approver_id="usr_operator_1",
    )

    assert result["status"] == "executed"
    call_kwargs = mock_request.call_args.kwargs
    assert call_kwargs["method"] == "POST"
    assert call_kwargs["url"].endswith("/v1/approvals/apr_123/approve")
    assert call_kwargs["json"]["approver_id"] == "usr_operator_1"


@patch('novyx.client.requests.request')
def test_audit_accepts_action_id_for_governed_action_detail(mock_request, control_nx, mock_response):
    """Test audit('act_...') returns Control action evidence details."""
    mock_response.json.return_value = {
        "action": {"action_id": "act_123", "status": "executed"},
    }
    mock_request.return_value = mock_response

    result = control_nx.audit("act_123")

    assert result["id"] == "act_123"
    call_kwargs = mock_request.call_args.kwargs
    assert call_kwargs["method"] == "GET"
    assert call_kwargs["url"].endswith("/v1/actions/act_123")


@patch('novyx.client.requests.request')
def test_draft_memory(mock_request, nx, mock_response):
    """Test draft_memory() creates a reviewable draft."""
    mock_response.json.return_value = {"draft_id": "drf_test123", "status": "draft"}
    mock_request.return_value = mock_response

    result = nx.draft_memory("Draft this", tags=["draft"], importance=6, confidence=0.8)

    assert result["draft_id"] == "drf_test123"
    call_kwargs = mock_request.call_args[1]
    assert call_kwargs["json"]["observation"] == "Draft this"
    assert call_kwargs["json"]["tags"] == ["draft"]
    assert call_kwargs["json"]["importance"] == 6
    assert call_kwargs["json"]["confidence"] == 0.8
    assert call_kwargs["url"].endswith("/v1/memory-drafts")


@patch('novyx.client.requests.request')
def test_draft_memory_with_branch(mock_request, nx, mock_response):
    """Test draft_memory() can attach a branch/session identifier."""
    mock_response.json.return_value = {"draft_id": "drf_test123", "status": "draft", "branch_id": "branch-1"}
    mock_request.return_value = mock_response

    result = nx.draft_memory("Draft this", branch_id="branch-1")

    assert result["branch_id"] == "branch-1"
    call_kwargs = mock_request.call_args[1]
    assert call_kwargs["json"]["branch_id"] == "branch-1"


@patch('novyx.client.requests.request')
def test_memory_drafts(mock_request, nx, mock_response):
    """Test memory_drafts() lists drafts."""
    mock_response.json.return_value = {"total_count": 1, "drafts": [{"draft_id": "drf_1"}]}
    mock_request.return_value = mock_response

    result = nx.memory_drafts(status="draft")

    assert result["total_count"] == 1
    call_kwargs = mock_request.call_args[1]
    assert call_kwargs["params"]["status"] == "draft"
    assert call_kwargs["url"].endswith("/v1/memory-drafts")


@patch('novyx.client.requests.request')
def test_memory_branch(mock_request, nx, mock_response):
    """Test memory_branch() fetches grouped review info."""
    mock_response.json.return_value = {"branch_id": "branch-1", "total_drafts": 2}
    mock_request.return_value = mock_response

    result = nx.memory_branch("branch-1")

    assert result["branch_id"] == "branch-1"
    call_kwargs = mock_request.call_args[1]
    assert call_kwargs["url"].endswith("/v1/memory-branches/branch-1")


@patch('novyx.client.requests.request')
def test_merge_draft(mock_request, nx, mock_response):
    """Test merge_draft() merges a draft."""
    mock_response.json.return_value = {"draft_id": "drf_1", "status": "merged", "memory_id": "mem_1"}
    mock_request.return_value = mock_response

    result = nx.merge_draft("drf_1", supersede_memory_id="mem_old")

    assert result["status"] == "merged"
    call_kwargs = mock_request.call_args[1]
    assert call_kwargs["json"]["supersede_memory_id"] == "mem_old"
    assert call_kwargs["url"].endswith("/v1/memory-drafts/drf_1/merge")


@patch('novyx.client.requests.request')
def test_draft_diff(mock_request, nx, mock_response):
    """Test draft_diff() fetches a field-level diff."""
    mock_response.json.return_value = {"draft_id": "drf_1", "recommendation": "merge_or_supersede"}
    mock_request.return_value = mock_response

    result = nx.draft_diff("drf_1", compare_to="mem_old")

    assert result["draft_id"] == "drf_1"
    call_kwargs = mock_request.call_args[1]
    assert call_kwargs["params"]["compare_to"] == "mem_old"
    assert call_kwargs["url"].endswith("/v1/memory-drafts/drf_1/diff")


@patch('novyx.client.requests.request')
def test_reject_draft(mock_request, nx, mock_response):
    """Test reject_draft() rejects a draft."""
    mock_response.json.return_value = {"draft_id": "drf_1", "status": "rejected"}
    mock_request.return_value = mock_response

    result = nx.reject_draft("drf_1", reason="bad memory")

    assert result["status"] == "rejected"
    call_kwargs = mock_request.call_args[1]
    assert call_kwargs["json"]["reason"] == "bad memory"
    assert call_kwargs["url"].endswith("/v1/memory-drafts/drf_1/reject")


@patch('novyx.client.requests.request')
def test_merge_branch(mock_request, nx, mock_response):
    """Test merge_branch() merges all open drafts in a branch."""
    mock_response.json.return_value = {"branch_id": "branch-1", "merged_count": 2}
    mock_request.return_value = mock_response

    result = nx.merge_branch("branch-1")

    assert result["merged_count"] == 2
    call_kwargs = mock_request.call_args[1]
    assert call_kwargs["url"].endswith("/v1/memory-branches/branch-1/merge")


@patch('novyx.client.requests.request')
def test_reject_branch(mock_request, nx, mock_response):
    """Test reject_branch() rejects all open drafts in a branch."""
    mock_response.json.return_value = {"branch_id": "branch-1", "rejected_drafts": 2}
    mock_request.return_value = mock_response

    result = nx.reject_branch("branch-1", reason="bad branch")

    assert result["branch_id"] == "branch-1"
    call_kwargs = mock_request.call_args[1]
    assert call_kwargs["json"]["reason"] == "bad branch"
    assert call_kwargs["url"].endswith("/v1/memory-branches/branch-1/reject")


# ============================================================================
# Rollback Methods Tests
# ============================================================================

@patch('novyx.client.requests.request')
def test_rollback(mock_request, nx, mock_response):
    """Test rollback() executes rollback."""
    mock_response.json.return_value = {
        "success": True,
        "rolled_back_to": "2026-01-15T10:00:00Z",
        "artifacts_restored": 5,
        "operations_undone": 10
    }
    mock_request.return_value = mock_response

    result = nx.rollback("2 hours ago")

    assert result["success"] is True
    assert result["artifacts_restored"] == 5
    assert "/v1/rollback" in mock_request.call_args.kwargs["url"]
    assert mock_request.call_args.kwargs["json"]["target"] == "2 hours ago"


@patch('novyx.client.requests.request')
def test_rollback_preview(mock_request, nx, mock_response):
    """Test rollback_preview() shows preview."""
    mock_response.json.return_value = {
        "target_timestamp": "2026-01-15T10:00:00Z",
        "artifacts_modified": 3,
        "safe_rollback": True
    }
    mock_request.return_value = mock_response

    preview = nx.rollback_preview("1 hour ago")

    assert preview["artifacts_modified"] == 3
    assert "/v1/rollback/preview" in mock_request.call_args.kwargs["url"]


@patch('novyx.client.requests.request')
def test_rollback_history(mock_request, nx, mock_response):
    """Test rollback_history() lists past rollbacks."""
    mock_response.json.return_value = [
        {"rollback_id": "rb-1", "executed_at": "2026-01-15T10:00:00Z"}
    ]
    mock_request.return_value = mock_response

    history = nx.rollback_history(limit=10)

    assert len(history) == 1
    assert history[0]["rollback_id"] == "rb-1"


# ============================================================================
# Audit Methods Tests
# ============================================================================

@patch('novyx.client.requests.request')
def test_audit(mock_request, nx, mock_response):
    """Test audit() retrieves audit entries."""
    mock_response.json.return_value = {
        "entries": [
            {"timestamp": "2026-01-15T10:00:00Z", "operation": "CREATE"}
        ]
    }
    mock_request.return_value = mock_response

    audit = nx.audit(limit=50, operation="CREATE")

    assert len(audit) == 1
    assert audit[0]["operation"] == "CREATE"
    assert "/v1/audit" in mock_request.call_args.kwargs["url"]


@patch('novyx.client.requests.request')
def test_audit_export(mock_request, nx, mock_response):
    """Test audit_export() exports audit log."""
    mock_response.content = b"timestamp,operation\n2026-01-15,CREATE"
    mock_request.return_value = mock_response

    data = nx.audit_export(format="csv")

    assert b"timestamp" in data
    assert mock_request.call_args[1]["params"]["format"] == "csv"


@patch('novyx.client.requests.request')
def test_audit_verify(mock_request, nx, mock_response):
    """Test audit_verify() verifies integrity."""
    mock_response.json.return_value = {"valid": True, "errors": []}
    mock_request.return_value = mock_response

    verification = nx.audit_verify()

    assert verification["valid"] is True
    assert "/v1/audit/verify" in mock_request.call_args.kwargs["url"]


# ============================================================================
# Trace Methods Tests
# ============================================================================

@patch('novyx.client.requests.request')
def test_trace_create(mock_request, nx, mock_response):
    """Test trace_create() creates trace session."""
    mock_response.json.return_value = {
        "trace_id": "trace-123",
        "agent_id": "my-agent",
        "created_at": "2026-01-15T10:00:00Z"
    }
    mock_request.return_value = mock_response

    trace = nx.trace_create("my-agent", session_id="session-123")

    assert trace["trace_id"] == "trace-123"
    assert mock_request.call_args.kwargs["json"]["agent_id"] == "my-agent"
    assert "/v1/traces" in mock_request.call_args.kwargs["url"]


@patch('novyx.client.requests.request')
def test_trace_step(mock_request, nx, mock_response):
    """Test trace_step() adds step to trace."""
    mock_response.json.return_value = {
        "step_id": "step-1",
        "circuit_breaker_triggered": False
    }
    mock_request.return_value = mock_response

    result = nx.trace_step("trace-123", "action", "send_email", metadata={"to": "test@example.com"})

    assert result["circuit_breaker_triggered"] is False
    assert "/v1/traces/trace-123/steps" in mock_request.call_args.kwargs["url"]


@patch('novyx.client.requests.request')
def test_trace_complete(mock_request, nx, mock_response):
    """Test trace_complete() finalizes trace."""
    mock_response.json.return_value = {
        "trace_id": "trace-123",
        "status": "completed",
        "signature": "abc123",
        "total_steps": 5
    }
    mock_request.return_value = mock_response

    result = nx.trace_complete("trace-123")

    assert result["status"] == "completed"
    assert result["total_steps"] == 5
    assert "/v1/traces/trace-123/complete" in mock_request.call_args.kwargs["url"]


@patch('novyx.client.requests.request')
def test_trace_verify(mock_request, nx, mock_response):
    """Test trace_verify() verifies trace integrity."""
    mock_response.json.return_value = {
        "trace_id": "trace-123",
        "valid": True,
        "steps_verified": 5
    }
    mock_request.return_value = mock_response

    verification = nx.trace_verify("trace-123")

    assert verification["valid"] is True
    assert "/v1/traces/trace-123/verify" in mock_request.call_args.kwargs["url"]


# ============================================================================
# Usage & Plans Tests
# ============================================================================

@patch('novyx.client.requests.request')
def test_usage(mock_request, nx, mock_response):
    """Test usage() returns usage stats."""
    mock_response.json.return_value = {
        "tier": "pro",
        "api_calls": {"current": 100, "limit": 100_000, "unlimited": False},
        "memories": {"current": 50, "limit": None, "unlimited": True}
    }
    mock_request.return_value = mock_response

    usage = nx.usage()

    assert usage["tier"] == "pro"
    assert usage["api_calls"]["current"] == 100
    assert usage["memories"]["unlimited"] is True


@patch('novyx.client.requests.request')
def test_plans(mock_request, nx, mock_response):
    """Test plans() returns available plans."""
    mock_response.json.return_value = [
        {
            "plan_id": "free",
            "name": "Free",
            "price_cents": 0,
            "price_display": "Free",
            "memory_limit": 5_000
        },
        {
            "plan_id": "pro",
            "name": "Pro",
            "price_cents": 3900,
            "price_display": "$39/mo",
            "memory_limit": None
        }
    ]
    mock_request.return_value = mock_response

    plans = nx.plans()

    assert len(plans) == 2
    assert plans[0]["plan_id"] == "free"
    assert plans[1]["memory_limit"] is None


# ============================================================================
# Health Check Test
# ============================================================================

@patch('novyx.client.requests.get')
def test_health(mock_get, nx):
    """Test health() checks API status."""
    mock_response = Mock()
    mock_response.json.return_value = {"status": "healthy", "version": "1.0.0"}
    mock_get.return_value = mock_response

    health = nx.health()

    assert health["status"] == "healthy"
    mock_get.assert_called_once()


# ============================================================================
# Integration-style Test
# ============================================================================

@patch('novyx.client.requests.request')
def test_full_workflow(mock_request, nx, mock_response):
    """Test a full workflow: remember, recall, audit, rollback."""
    # Mock remember
    mock_response.json.return_value = {"uuid": "mem-123"}
    mock_request.return_value = mock_response

    mem_result = nx.remember("Test memory")
    assert mem_result["uuid"] == "mem-123"

    # Mock recall
    mock_response.json.return_value = [{"uuid": "mem-123", "score": 0.95}]
    memories = nx.recall("test")
    assert len(memories) == 1

    # Mock audit
    mock_response.json.return_value = {"entries": [{"operation": "CREATE"}]}
    audit = nx.audit()
    assert len(audit) == 1

    # Mock rollback
    mock_response.json.return_value = {"success": True, "artifacts_restored": 1}
    rb_result = nx.rollback("1 hour ago")
    assert rb_result["success"] is True


# ============================================================================
# Eval Methods Tests
# ============================================================================

@patch('novyx.client.requests.request')
def test_eval_run(mock_request, nx, mock_response):
    """Test eval_run() runs a health evaluation."""
    mock_response.json.return_value = {
        "eval_id": "eval_abc123",
        "health_score": 91.2,
        "breakdown": {
            "recall_consistency": 95.0,
            "drift_score": 88.0,
            "conflict_score": 100.0,
            "staleness_score": 72.0,
        },
        "memory_count": 500,
        "created_at": "2026-03-08T00:00:00Z",
    }
    mock_request.return_value = mock_response

    result = nx.eval_run()

    assert result["health_score"] == 91.2
    assert result["breakdown"]["recall_consistency"] == 95.0
    assert "/v1/eval/run" in mock_request.call_args.kwargs["url"]
    assert mock_request.call_args.kwargs["method"] == "POST"


@patch('novyx.client.requests.request')
def test_eval_run_with_min_score(mock_request, nx, mock_response):
    """Test eval_run() with min_score threshold."""
    mock_response.json.return_value = {
        "eval_id": "eval_abc123",
        "health_score": 91.2,
        "passed": True,
        "min_score": 80.0,
    }
    mock_request.return_value = mock_response

    result = nx.eval_run(min_score=80.0)

    assert result["passed"] is True
    assert mock_request.call_args.kwargs["json"]["min_score"] == 80.0


@patch('novyx.client.requests.request')
def test_eval_gate(mock_request, nx, mock_response):
    """Test eval_gate() CI/CD quality gate."""
    mock_response.json.return_value = {
        "eval_id": "eval_abc123",
        "health_score": 95.0,
        "passed": True,
        "min_score": 80.0,
    }
    mock_request.return_value = mock_response

    result = nx.eval_gate(min_score=80.0)

    assert result["passed"] is True
    assert "/v1/eval/gate" in mock_request.call_args.kwargs["url"]
    assert mock_request.call_args.kwargs["json"]["min_score"] == 80.0


@patch('novyx.client.requests.request')
def test_eval_history(mock_request, nx, mock_response):
    """Test eval_history() lists past evals."""
    mock_response.json.return_value = {
        "entries": [
            {"eval_id": "eval_1", "health_score": 90.0, "created_at": "2026-03-08T00:00:00Z"},
            {"eval_id": "eval_2", "health_score": 85.0, "created_at": "2026-03-07T00:00:00Z"},
        ],
        "total_count": 2,
        "has_more": False,
    }
    mock_request.return_value = mock_response

    result = nx.eval_history(limit=50)

    assert len(result["entries"]) == 2
    assert result["entries"][0]["health_score"] == 90.0
    assert "/v1/eval/history" in mock_request.call_args.kwargs["url"]


@patch('novyx.client.requests.request')
def test_eval_drift(mock_request, nx, mock_response):
    """Test eval_drift() returns drift analysis."""
    mock_response.json.return_value = {
        "memory_count_delta": 12,
        "avg_importance_delta": 0.3,
        "top_new_topics": ["budget"],
        "top_lost_topics": [],
    }
    mock_request.return_value = mock_response

    result = nx.eval_drift(days=7)

    assert result["memory_count_delta"] == 12
    assert "/v1/eval/drift" in mock_request.call_args.kwargs["url"]
    assert mock_request.call_args.kwargs["params"]["days"] == 7


@patch('novyx.client.requests.request')
def test_eval_baseline_create(mock_request, nx, mock_response):
    """Test eval_baseline_create() saves a baseline."""
    mock_response.json.return_value = {
        "id": "bl_abc123",
        "query": "capital of France",
        "expected_observation": "Paris",
        "created_at": "2026-03-08T00:00:00Z",
    }
    mock_request.return_value = mock_response

    result = nx.eval_baseline_create("capital of France", "Paris")

    assert result["id"] == "bl_abc123"
    assert "/v1/eval/baselines" in mock_request.call_args.kwargs["url"]
    assert mock_request.call_args.kwargs["json"]["query"] == "capital of France"
    assert mock_request.call_args.kwargs["json"]["expected_observation"] == "Paris"


@patch('novyx.client.requests.request')
def test_eval_baselines(mock_request, nx, mock_response):
    """Test eval_baselines() lists all baselines."""
    mock_response.json.return_value = {
        "baselines": [
            {"id": "bl_1", "query": "capital of France", "expected_observation": "Paris"},
        ],
        "total_count": 1,
    }
    mock_request.return_value = mock_response

    result = nx.eval_baselines()

    assert len(result["baselines"]) == 1
    assert "/v1/eval/baselines" in mock_request.call_args.kwargs["url"]
    assert mock_request.call_args.kwargs["method"] == "GET"


@patch('novyx.client.requests.request')
def test_eval_baseline_delete(mock_request, nx, mock_response):
    """Test eval_baseline_delete() deletes a baseline."""
    mock_response.json.return_value = {"success": True}
    mock_request.return_value = mock_response

    result = nx.eval_baseline_delete("bl_abc123")

    assert result is True
    assert "/v1/eval/baselines/bl_abc123" in mock_request.call_args.kwargs["url"]
    assert mock_request.call_args.kwargs["method"] == "DELETE"


# ===========================================================================
# Phases 1, 4, 5: Custom policies, governance dashboard, agent-scoped
# ===========================================================================


@patch('novyx.client.requests.request')
def test_create_policy_tenant_wide(mock_request, nx, mock_response):
    """create_policy() without agent_id POSTs tenant-wide policy."""
    mock_response.json.return_value = {
        "policy_name": "pii_protection",
        "agent_id": None,
        "action": "created",
        "version": 1,
    }
    mock_request.return_value = mock_response

    result = nx.create_policy(
        "pii_protection",
        rules=[{"match": "ssn", "severity": "critical"}],
        description="Block PII",
        whitelisted_domains=["internal.company.com"],
    )

    assert result["policy_name"] == "pii_protection"
    call_kwargs = mock_request.call_args.kwargs
    assert call_kwargs["method"] == "POST"
    assert call_kwargs["url"].endswith("/v1/control/policies")
    body = call_kwargs["json"]
    assert body["name"] == "pii_protection"
    assert body["rules"] == [{"match": "ssn", "severity": "critical"}]
    assert body["whitelisted_domains"] == ["internal.company.com"]
    assert "agent_id" not in body  # tenant-wide


@patch('novyx.client.requests.request')
def test_create_policy_agent_scoped(mock_request, nx, mock_response):
    """create_policy() with agent_id includes it in payload."""
    mock_response.json.return_value = {"policy_name": "billing_block", "agent_id": "billing-bot"}
    mock_request.return_value = mock_response

    nx.create_policy(
        "billing_block",
        rules=[{"match": "wire_transfer", "severity": "critical"}],
        agent_id="billing-bot",
    )

    body = mock_request.call_args.kwargs["json"]
    assert body["agent_id"] == "billing-bot"


@patch('novyx.client.requests.request')
def test_list_policies_tenant_only(mock_request, nx, mock_response):
    """list_policies() without agent_id sends no params."""
    mock_response.json.return_value = {"policies": [], "mode": "enforcement"}
    mock_request.return_value = mock_response

    nx.list_policies()

    call_kwargs = mock_request.call_args.kwargs
    assert call_kwargs["method"] == "GET"
    assert call_kwargs["url"].endswith("/v1/control/policies")
    # params is None or absent
    assert call_kwargs.get("params") in (None, {})


@patch('novyx.client.requests.request')
def test_list_policies_with_agent(mock_request, nx, mock_response):
    """list_policies(agent_id=...) sends the agent_id query param."""
    mock_response.json.return_value = {"policies": []}
    mock_request.return_value = mock_response

    nx.list_policies(agent_id="billing-bot")

    assert mock_request.call_args.kwargs["params"] == {"agent_id": "billing-bot"}


@patch('novyx.client.requests.request')
def test_get_policy_tenant_wide(mock_request, nx, mock_response):
    """get_policy() without agent_id sends no agent_id param."""
    mock_response.json.return_value = {"name": "pii", "scope": "tenant"}
    mock_request.return_value = mock_response

    result = nx.get_policy("pii")

    assert result["scope"] == "tenant"
    call_kwargs = mock_request.call_args.kwargs
    assert call_kwargs["url"].endswith("/v1/control/policies/pii")
    assert call_kwargs.get("params") in (None, {})


@patch('novyx.client.requests.request')
def test_get_policy_agent_scoped(mock_request, nx, mock_response):
    """get_policy(agent_id=...) sends the agent_id query param."""
    mock_response.json.return_value = {"name": "pii", "scope": "agent", "agent_id": "billing-bot"}
    mock_request.return_value = mock_response

    nx.get_policy("pii", agent_id="billing-bot")

    assert mock_request.call_args.kwargs["params"] == {"agent_id": "billing-bot"}


@patch('novyx.client.requests.request')
def test_update_policy_increments_version(mock_request, nx, mock_response):
    """update_policy() PUTs to the named endpoint."""
    mock_response.json.return_value = {"policy_name": "pii", "version": 2, "action": "updated"}
    mock_request.return_value = mock_response

    nx.update_policy(
        "pii",
        rules=[{"match": "ssn", "severity": "high"}],
        description="updated",
    )

    call_kwargs = mock_request.call_args.kwargs
    assert call_kwargs["method"] == "PUT"
    assert call_kwargs["url"].endswith("/v1/control/policies/pii")
    assert call_kwargs["json"]["description"] == "updated"


@patch('novyx.client.requests.request')
def test_delete_policy_tenant_wide(mock_request, nx, mock_response):
    """delete_policy() DELETEs the named endpoint without agent_id."""
    mock_response.json.return_value = {"policy_name": "pii", "action": "disabled"}
    mock_request.return_value = mock_response

    nx.delete_policy("pii")

    call_kwargs = mock_request.call_args.kwargs
    assert call_kwargs["method"] == "DELETE"
    assert call_kwargs["url"].endswith("/v1/control/policies/pii")
    assert call_kwargs.get("params") in (None, {})


@patch('novyx.client.requests.request')
def test_delete_policy_agent_scoped(mock_request, nx, mock_response):
    """delete_policy(agent_id=...) targets the agent-scoped version."""
    mock_response.json.return_value = {"policy_name": "billing_block"}
    mock_request.return_value = mock_response

    nx.delete_policy("billing_block", agent_id="billing-bot")

    assert mock_request.call_args.kwargs["params"] == {"agent_id": "billing-bot"}


@patch('novyx.client.requests.request')
def test_governance_dashboard_default_window(mock_request, nx, mock_response):
    """governance_dashboard() defaults to 7d window."""
    mock_response.json.return_value = {"window": "7d", "totals": {"evaluations": 0}}
    mock_request.return_value = mock_response

    result = nx.governance_dashboard()

    assert result["window"] == "7d"
    call_kwargs = mock_request.call_args.kwargs
    assert call_kwargs["method"] == "GET"
    assert call_kwargs["url"].endswith("/v1/control/dashboard")
    assert call_kwargs["params"]["window"] == "7d"
    assert "bucket" not in call_kwargs["params"]


@patch('novyx.client.requests.request')
def test_governance_dashboard_custom_window_and_bucket(mock_request, nx, mock_response):
    """governance_dashboard() forwards window and bucket."""
    mock_response.json.return_value = {"window": "24h", "bucket": "hour"}
    mock_request.return_value = mock_response

    nx.governance_dashboard(window="24h", bucket="hour")

    params = mock_request.call_args.kwargs["params"]
    assert params == {"window": "24h", "bucket": "hour"}


@patch('novyx.client.requests.request')
def test_agent_violations_default_limit(mock_request, nx, mock_response):
    """agent_violations() sends default limit and the agent_id in path."""
    mock_response.json.return_value = {"agent_id": "billing-bot", "violations": [], "total": 0}
    mock_request.return_value = mock_response

    nx.agent_violations("billing-bot")

    call_kwargs = mock_request.call_args.kwargs
    assert call_kwargs["method"] == "GET"
    assert call_kwargs["url"].endswith("/v1/control/agents/billing-bot/violations")
    assert call_kwargs["params"]["limit"] == 50


@patch('novyx.client.requests.request')
def test_agent_violations_with_window(mock_request, nx, mock_response):
    """agent_violations() forwards since/until."""
    mock_response.json.return_value = {"agent_id": "billing-bot", "violations": []}
    mock_request.return_value = mock_response

    nx.agent_violations(
        "billing-bot",
        limit=10,
        since="2026-04-01T00:00:00Z",
        until="2026-04-10T00:00:00Z",
    )

    params = mock_request.call_args.kwargs["params"]
    assert params["limit"] == 10
    assert params["since"] == "2026-04-01T00:00:00Z"
    assert params["until"] == "2026-04-10T00:00:00Z"
