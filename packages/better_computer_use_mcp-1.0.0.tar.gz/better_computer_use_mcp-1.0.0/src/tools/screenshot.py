from mcp.types import Tool, ImageContent
from typing import Any
from pyautogui import screenshot
import io
import base64

TOOL_DEFINITION = Tool(
    name="screenshot",
    description="take a screenshot",
    inputSchema={
        "type": "object",
        "properties": {},
        "required": []
    }
)


async def execute(arguments: Any) -> list[ImageContent]:
    img = screenshot()
    img_bytes = io.BytesIO()
    img.save(img_bytes, format='PNG')
    img_bytes.seek(0)
    img_base64 = base64.b64encode(img_bytes.read()).decode()
    
    return [ImageContent(
        type="image",
        data=img_base64,
        mimeType="image/png"
    )]


screenshot_tool = {
    "definition": TOOL_DEFINITION,
    "execute": execute
}
