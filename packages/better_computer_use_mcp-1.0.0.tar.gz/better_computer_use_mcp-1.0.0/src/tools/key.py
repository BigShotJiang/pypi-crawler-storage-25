from mcp.types import Tool, TextContent
from typing import Any
from pyautogui import press, hotkey

TOOL_DEFINITION = Tool(
    name="shortcut",
    description="press the specified key",
    inputSchema={
        "type": "object",
        "properties": {
            "key": {
                "type": "string",
                "description": "key to press (e.g., 'enter', 'win + r)"
            }
        },
        "required": ["key"]
    }
)


async def execute(arguments: Any) -> list[TextContent]:
    key = arguments.get("key", "")
    
    if "+" in key:
        keys = [k.strip() for k in key.split("+")]
        hotkey(*keys)
    else:
        press(key)
    
    return [TextContent(
        type="text",
        text=f"Pressed: {key}"
    )]


shortcut_tool = {
    "definition": TOOL_DEFINITION,
    "execute": execute
}
