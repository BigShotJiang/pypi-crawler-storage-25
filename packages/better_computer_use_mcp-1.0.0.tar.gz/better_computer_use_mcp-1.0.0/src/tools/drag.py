

from mcp.types import Tool, TextContent
from typing import Any
from pyautogui import moveTo, mouseDown, dragTo, mouseUp

TOOL_DEFINITION = Tool(
    name="drag",
    description="drag from start coordinates to end coordinates",
    inputSchema={
        "type": "object",
        "properties": {
            "startx": {
                "type": "number",
                "description": "X axis to start dragging"
            },
            "starty": {
                "type": "number",
                "description": "Y axis to start dragging"
            },
            "endx": {
                "type": "number",
                "description": "X axis to end dragging"
            },
            "endy": {
                "type": "number",
                "description": "Y axis to end dragging"
            },
            "button": {
                "type": "string",
                "description": "Button to click(left, right, middle)",
                "default": "left"
            }
        },
        "required": ["startx", "starty", "endx", "endy"]
    }
)


async def execute(arguments: Any) -> list[TextContent]:
    startx = arguments.get("startx", 0)
    starty = arguments.get("starty", 0)
    endx = arguments.get("endx", 0)
    endy = arguments.get("endy", 0)
    button = arguments.get("button", "left")
    
    moveTo(startx, starty)
    mouseDown(button=button)
    dragTo(endx, endy, button=button)
    mouseUp(button=button)
    
    return [TextContent(
        type="text",
        text=f"Dragged from ({startx}, {starty}) to ({endx}, {endy}) with {button} button"
    )]


drag_tool = {
    "definition": TOOL_DEFINITION,
    "execute": execute
}
