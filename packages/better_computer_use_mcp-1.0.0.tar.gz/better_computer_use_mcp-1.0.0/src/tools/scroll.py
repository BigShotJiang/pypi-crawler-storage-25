from mcp.types import Tool, TextContent
from typing import Any
from pyautogui import scroll, hscroll, moveTo

TOOL_DEFINITION = Tool(
    name="scroll",
    description="scroll the screen",
    inputSchema={
        "type": "object",
        "properties": {
            "params": {
                "type": "string",
                "description": "Scroll direction and distance (e.g., 'up', 'down:500', 'left:150', 'right:400')- default 300px"
            },
            "coordinate": {
                "type": "object",
                "description": "Scroll position (x, y coordinates)",
                "properties": {
                    "x": {
                        "type": "number",
                        "description": "X coordinate"
                    },
                    "y": {
                        "type": "number",
                        "description": "Y coordinate"
                    }
                }
            }
        },
        "required": ["params", "coordinate"]
    }
)


async def execute(arguments: Any) -> list[TextContent]:
    params = arguments.get("params", "")
    coordinate = arguments.get("coordinate", {"x": 0, "y": 0})
    
    default_distance = 300
    
    if ":" in params:
        direction, distance_str = params.split(":")
        try:
            distance = int(distance_str)
        except:
            distance = default_distance
    else:
        direction = params
        distance = default_distance
    
    direction = direction.lower().strip()
    
    x = coordinate.get("x", 0)
    y = coordinate.get("y", 0)
    moveTo(x, y)
    
    if direction == "up":
        scroll(distance)
    elif direction == "down":
        scroll(-distance)
    elif direction == "left":
        hscroll(-distance)
    elif direction == "right":
        hscroll(distance)
    else:
        return [TextContent(
            type="text",
            text=f"Invalid direction: {direction}"
        )]
    
    return [TextContent(
        type="text",
        text=f"Scrolled {direction} {distance}px at ({x}, {y})"
    )]


scroll_tool = {
    "definition": TOOL_DEFINITION,
    "execute": execute
}
