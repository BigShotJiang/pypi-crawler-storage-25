from mcp.types import Tool, TextContent
from typing import Any
from pyperclip import copy, paste

TOOL_DEFINITION = Tool(
    name="type",
    description="type the specified text",
    inputSchema={
        "type": "object",
        "properties": {
            "text": {
                "type": "string",
                "description": "text to type"
            }
        },
        "required": ["text"]
    }
)


async def execute(arguments: Any) -> list[TextContent]:
    text = arguments.get("text", "")
    
    try:
        original_clipboard = paste()
    except:
        original_clipboard = ""
    
    copy(text)
    
    paste()
    
    if original_clipboard:
        copy(original_clipboard)
    
    return [TextContent(
        type="text",
        text=f"Typed: {text}"
    )]


type_tool = {
    "definition": TOOL_DEFINITION,
    "execute": execute
}
