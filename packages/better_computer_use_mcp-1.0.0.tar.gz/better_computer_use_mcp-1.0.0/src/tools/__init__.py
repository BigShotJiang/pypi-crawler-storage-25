from .click import click_tool
from .type import type_tool
from .drag import drag_tool
from .scroll import scroll_tool
from .mouse_position import mouse_position_tool
from .screenshot import screenshot_tool
from .key import shortcut_tool
from .double_click import double_click_tool
from .move import move_tool

TOOL_REGISTRY = {
    "click": click_tool,
    "type": type_tool,
    "get_screenshot": screenshot_tool,
    "drag": drag_tool,
    "scroll": scroll_tool,
    "mouse_position": mouse_position_tool,
    "shortcut": shortcut_tool,
    "double_click": double_click_tool,
    "move": move_tool,
}
