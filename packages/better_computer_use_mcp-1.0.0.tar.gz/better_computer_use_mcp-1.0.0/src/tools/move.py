from mcp.types import Tool, TextContent
from typing import Any
from pyautogui import moveTo

TOOL_DEFINITION = Tool(
    name="move",
    description="move the mouse to the specified coordinates",
    inputSchema={
        "type": "object",
        "properties": {
            "x": {
                "type": "number",
                "description": "X axis to move"
            },
            "y": {
                "type": "number",
                "description": "Y axis to move"
            }
        },
        "required": ["x", "y"]
    }
)


async def execute(arguments: Any) -> list[TextContent]:
    x = arguments.get("x", 0)
    y = arguments.get("y", 0)
    
    moveTo(x, y)
    
    return [TextContent(
        type="text",
        text=f"Moved to ({x}, {y})"
    )]


move_tool = {
    "definition": TOOL_DEFINITION,
    "execute": execute
}
