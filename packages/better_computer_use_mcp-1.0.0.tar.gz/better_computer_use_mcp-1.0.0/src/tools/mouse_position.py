from mcp.types import Tool, TextContent
from typing import Any
from pyautogui import position

TOOL_DEFINITION = Tool(
    name="mouse_position",
    description="get current mouse position",
    inputSchema={
        "type": "object",
        "properties": {},
        "required": []
    }
)


async def execute(arguments: Any) -> list[TextContent]:
    x, y = position()
    return [TextContent(
        type="text",
        text=f"Mouse position: ({x}, {y})"
    )]


mouse_position_tool = {
    "definition": TOOL_DEFINITION,
    "execute": execute
}
