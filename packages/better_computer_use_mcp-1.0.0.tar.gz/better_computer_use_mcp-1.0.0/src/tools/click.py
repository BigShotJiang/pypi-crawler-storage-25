

from mcp.types import Tool, TextContent
from typing import Any
from pyautogui import click

TOOL_DEFINITION = Tool(
    name="click",
    description="click at the specified coordinates",
    inputSchema={
        "type": "object",
        "properties": {
            "x": {
                "type": "number",
                "description": "X axis to click"
            },
            "y": {
                "type": "number",
                "description": "Y axis to click"
            },
            "button": {
                "type": "string",
                "description": "Button to click(left, right, middle)",
                "default": "left"
            }
        },
        "required": ["x", "y"]
    }
)


async def execute(arguments: Any) -> list[TextContent]:
    x = arguments.get("x", 0)
    y = arguments.get("y", 0)
    button = arguments.get("button", "left")
    click(x, y, button=button)
    return [TextContent(
        type="text",
        text=f"Clicked at ({x}, {y}) with {button} button"
    )]


click_tool = {
    "definition": TOOL_DEFINITION,
    "execute": execute
}
