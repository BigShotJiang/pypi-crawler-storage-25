#!/usr/bin/env python3
"""
Python MCP Server
Model Context Protocol Server implementation
"""

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent
import json
from typing import Any
from .tools import TOOL_REGISTRY
import pyautogui

pyautogui.FAILSAFE = False

server = Server("better-computer-use")


@server.list_resources()
async def list_resources() -> list[dict]:
    return []


@server.read_resource()
async def read_resource(uri: str) -> str:
    return ""


@server.list_tools()
async def list_tools() -> list[Tool]:
    return [tool["definition"] for tool in TOOL_REGISTRY.values()]


@server.call_tool()
async def call_tool(name: str, arguments: Any) -> list[TextContent]:
    if name in TOOL_REGISTRY:
        tool = TOOL_REGISTRY[name]
        return await tool["execute"](arguments)
    else:
        return [TextContent(
            type="text",
            text=f"Unknown tool: {name}"
        )]


async def main():

    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options()
        )


import asyncio
asyncio.run(main())
