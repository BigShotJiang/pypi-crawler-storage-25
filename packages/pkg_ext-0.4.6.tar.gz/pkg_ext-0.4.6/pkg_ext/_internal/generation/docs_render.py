"""Markdown rendering functions for docs generation."""

from __future__ import annotations

from collections.abc import Callable, Sequence
from pathlib import Path
from textwrap import dedent
from typing import TYPE_CHECKING

from zero_3rdparty.sections import slug, wrap_section

from pkg_ext._internal.changelog.actions import ChangelogAction
from pkg_ext._internal.config import PKG_EXT_TOOL_NAME, Stability
from pkg_ext._internal.generation.docs_constants import MD_CONFIG
from pkg_ext._internal.generation.docs_version import (
    SymbolChange,
    get_field_since_version,
    get_symbol_since_version,
    get_symbol_stability,
)
from pkg_ext._internal.models.api_dump import (
    ClassDump,
    ClassFieldInfo,
    CLICommandDump,
    CLIParamInfo,
    ExceptionDump,
    FuncParamInfo,
    FunctionDump,
    GlobalVarDump,
    GroupDump,
    ParamKind,
    SymbolDump,
    TypeAliasDump,
)
from pkg_ext._internal.signature_parser import CLI_CONTEXT_TYPE_NAMES

if TYPE_CHECKING:
    from pkg_ext._internal.generation.docs import SymbolContext


def _format_param(p: FuncParamInfo) -> str:
    parts = [p.name]
    if p.type_annotation:
        parts.append(f": {p.type_annotation}")
    if p.default:
        parts.append(f" = {p.default.value_repr}")
    return "".join(parts)


def _format_function_signature(func: FunctionDump) -> str:
    params: list[str] = []
    saw_keyword_only = False
    for p in func.signature.parameters:
        if p.kind == ParamKind.POSITIONAL_ONLY:
            params.append(_format_param(p))
        elif p.kind == ParamKind.VAR_POSITIONAL:
            params.append(f"*{p.name}")
        elif p.kind == ParamKind.VAR_KEYWORD:
            params.append(f"**{p.name}")
        elif p.kind == ParamKind.KEYWORD_ONLY:
            if not saw_keyword_only:
                if not any(x.kind == ParamKind.VAR_POSITIONAL for x in func.signature.parameters):
                    params.append("*")
                saw_keyword_only = True
            params.append(_format_param(p))
        else:
            params.append(_format_param(p))
    pos_only_count = sum(1 for p in func.signature.parameters if p.kind == ParamKind.POSITIONAL_ONLY)
    if pos_only_count:
        params.insert(pos_only_count, "/")
    ret = f" -> {func.signature.return_annotation}" if func.signature.return_annotation else ""
    return f"def {func.name}({', '.join(params)}){ret}:\n    ..."


def _format_cli_param(p: CLIParamInfo) -> str:
    """Format a CLI param for signature display."""
    parts = [p.param_name]
    if p.type_annotation:
        parts.append(f": {p.type_annotation}")
    if p.required:
        parts.append(" = ...")
    elif p.default_repr:
        parts.append(f" = {p.default_repr}")
    return "".join(parts)


def _format_cli_command_signature(cmd: CLICommandDump) -> str:
    """Format CLI command signature, filtering out Context params and showing clean defaults."""
    cli_param_names = {p.param_name for p in cmd.cli_params}
    params = [
        _format_cli_param(p) for p in cmd.cli_params if p.type_annotation not in CLI_CONTEXT_TYPE_NAMES and not p.hidden
    ]
    # Include non-CLI params that aren't Context types
    for p in cmd.signature.parameters:
        if p.name in cli_param_names or p.type_annotation in CLI_CONTEXT_TYPE_NAMES:
            continue
        params.append(_format_param(p))
    prefix = "*, " if params else ""
    ret = f" -> {cmd.signature.return_annotation}" if cmd.signature.return_annotation else ""
    return f"def {cmd.name}({prefix}{', '.join(params)}){ret}:\n    ..."


def render_cli_params_table(cli_params: list[CLIParamInfo]) -> str:
    """Render CLI parameters as a markdown table."""
    visible = [p for p in cli_params if not p.hidden and p.type_annotation not in CLI_CONTEXT_TYPE_NAMES]
    if not visible:
        return ""

    has_envvar = any(p.envvar for p in visible)
    cols = ["Flag", "Type", "Default"]
    if has_envvar:
        cols.append("Env Var")
    cols.append("Description")

    header = "| " + " | ".join(cols) + " |"
    sep = "|" + "|".join("---" for _ in cols) + "|"

    rows = []
    for p in visible:
        if p.is_argument:
            flag_str = f"`{p.param_name}` (arg)"
        else:
            flag_str = ", ".join(f"`{f}`" for f in p.flags) if p.flags else "-"
        type_str = f"`{p.type_annotation}`" if p.type_annotation else "-"
        default_str = "*required*" if p.required else f"`{p.default_repr}`" if p.default_repr else "-"
        help_str = (p.help or "-").replace("|", "\\|")
        if p.choices:
            help_str += f" [{', '.join(p.choices)}]"

        row = [flag_str, type_str, default_str]
        if has_envvar:
            row.append(f"`{p.envvar}`" if p.envvar else "-")
        row.append(help_str)
        rows.append("| " + " | ".join(row) + " |")

    return "\n".join([header, sep, *rows])


def _format_field(f: ClassFieldInfo) -> str:
    parts = [f"    {f.name}"]
    if f.type_annotation:
        parts.append(f": {f.type_annotation}")
    if f.default:
        parts.append(f" = {f.default.value_repr}")
    return "".join(parts)


def _format_class_signature(cls: ClassDump) -> str:
    bases = f"({', '.join(cls.direct_bases)})" if cls.direct_bases else ""
    header = f"class {cls.name}{bases}:"
    if not cls.fields:
        return f"{header}\n    ..."
    field_lines = [_format_field(f) for f in cls.fields if not f.is_computed]
    return f"{header}\n" + "\n".join(field_lines)


def _format_exception_signature(exc: ExceptionDump) -> str:
    bases = f"({', '.join(exc.direct_bases)})" if exc.direct_bases else ""
    return f"class {exc.name}{bases}:\n    ..."


def format_signature(symbol: SymbolDump) -> str:
    match symbol:
        case FunctionDump():
            return _format_function_signature(symbol)
        case CLICommandDump():
            return _format_cli_command_signature(symbol)
        case ClassDump():
            return _format_class_signature(symbol)
        case ExceptionDump():
            return _format_exception_signature(symbol)
        case TypeAliasDump():
            return f"{symbol.name} = {symbol.alias_target}"
        case GlobalVarDump():
            ann = f": {symbol.annotation}" if symbol.annotation else ""
            val = f" = {symbol.value_repr}" if symbol.value_repr else ""
            return f"{symbol.name}{ann}{val}"
    return f"# {symbol.name}"


def format_docstring(docstring: str) -> str:
    if not docstring:
        return ""
    return dedent(docstring).strip()


def render_env_var_table(symbol: ClassDump) -> str:
    rows: list[str] = []
    for f in symbol.fields or []:
        for env_var in f.env_vars or []:
            default = f.default.value_repr if f.default else "-"
            rows.append(f"| `{env_var}` | `{f.name}` | {f.type_annotation or '-'} | {default} |")
    if not rows:
        return ""
    header = "### Environment Variables\n\n| Variable | Field | Type | Default |\n|----------|-------|------|---------|"
    return f"{header}\n" + "\n".join(rows)


def should_show_field_table(
    fields: list[ClassFieldInfo] | None,
    field_versions: dict[str, str] | None = None,
) -> bool:
    if not fields:
        return False
    visible = [f for f in fields if not f.is_computed]
    if any(f.deprecated or f.description for f in visible):
        return True
    if field_versions and any(field_versions.get(f.name) for f in visible):
        return True
    return False


def render_field_table(
    fields: list[ClassFieldInfo] | None,
    field_versions: dict[str, str] | None = None,
) -> str:
    if not fields:
        return ""
    visible = [f for f in fields if not f.is_computed]
    if not visible:
        return ""

    has_deprecated = any(f.deprecated for f in visible)
    has_description = any(f.description for f in visible)
    has_since = field_versions and any(field_versions.get(f.name) for f in visible)

    cols = ["Field", "Type", "Default"]
    if has_since:
        cols.append("Since")
    if has_deprecated:
        cols.append("Deprecated")
    if has_description:
        cols.append("Description")

    header = "| " + " | ".join(cols) + " |"
    separator = "|" + "|".join("---" for _ in cols) + "|"

    rows = []
    for f in visible:
        default = f"`{f.default.value_repr}`" if f.default else "-"
        row = [f.name, f"`{f.type_annotation}`" if f.type_annotation else "-", default]
        if has_since and field_versions:
            row.append(field_versions.get(f.name) or "-")
        if has_deprecated:
            row.append(f.deprecated or "-")
        if has_description:
            row.append((f.description or "-").replace("|", "\\|"))
        rows.append("| " + " | ".join(row) + " |")

    return "\n".join([header, separator, *rows])


def _build_field_versions(
    symbol_name: str,
    fields: list[ClassFieldInfo] | None,
    changelog_actions: Sequence[ChangelogAction],
) -> dict[str, str]:
    if not fields:
        return {}
    return {
        f.name: v
        for f in fields
        if not f.is_computed and (v := get_field_since_version(symbol_name, f.name, changelog_actions))
    }


def render_since_badge(version: str | None) -> str:
    return f"> **Since:** {version}" if version else ""


def render_stability_badge(
    symbol_name: str,
    group_name: str,
    changelog_actions: Sequence[ChangelogAction],
) -> str:
    stability = get_symbol_stability(symbol_name, group_name, changelog_actions)
    if stability == Stability.experimental:
        return "> **Experimental**"
    if stability == Stability.deprecated:
        return "> **Deprecated**"
    return ""


def calculate_source_link(
    symbol_doc_path: Path,
    module_path: str,
    pkg_src_dir: Path,
    pkg_import_name: str,
    line_number: int | None,
) -> str:
    rel_module = module_path.replace(".", "/") + ".py"
    source_file = pkg_src_dir / pkg_import_name / rel_module
    rel_path = source_file.relative_to(symbol_doc_path.parent, walk_up=True)
    if line_number:
        return f"{rel_path}#L{line_number}"
    return str(rel_path)


def _render_symbol_type_table(symbol: SymbolDump, changelog_actions: Sequence[ChangelogAction]) -> str | None:
    if isinstance(symbol, CLICommandDump) and symbol.cli_params:
        if table := render_cli_params_table(symbol.cli_params):
            return "\n".join(["**CLI Options:**", "", table])
    if isinstance(symbol, ClassDump) and symbol.fields:
        field_versions = _build_field_versions(symbol.name, symbol.fields, changelog_actions)
        if should_show_field_table(symbol.fields, field_versions):
            return render_field_table(symbol.fields, field_versions)
    return None


def _format_example_link(example_link: tuple[str, str]) -> str:
    url, desc = example_link
    return f"- [Example: {desc}]({url})" if desc else f"- [Example]({url})"


def render_inline_symbol(
    ctx: SymbolContext,
    changelog_actions: Sequence[ChangelogAction] | None = None,
    changes: list[SymbolChange] | None = None,
    *,
    symbol_doc_path: Path | None = None,
    pkg_src_dir: Path | None = None,
    pkg_import_name: str | None = None,
    example_link: tuple[str, str] | None = None,
) -> str:
    symbol = ctx.symbol
    changelog_actions = changelog_actions or []

    since_badge = render_since_badge(get_symbol_since_version(symbol.name, changelog_actions))
    anchor_id = f"{slug(symbol.name)}_def"
    lines = [f'<a id="{anchor_id}"></a>\n\n### {symbol.type.value}: `{symbol.name}`']
    if symbol_doc_path and pkg_src_dir and pkg_import_name:
        source_link = calculate_source_link(
            symbol_doc_path,
            symbol.module_path,
            pkg_src_dir,
            pkg_import_name,
            symbol.line_number,
        )
        lines.append(f"- [source]({source_link})")
    if example_link:
        lines.append(_format_example_link(example_link))
    if since_badge:
        lines.append(since_badge)
    lines.extend(["", "```python", format_signature(symbol), "```"])

    docstring = format_docstring(symbol.docstring)
    if docstring:
        lines.extend(["", docstring])
    if type_table := _render_symbol_type_table(symbol, changelog_actions):
        lines.extend(["", type_table])
    if changes:
        lines.extend(["", _render_changes_content(changes)])

    return "\n".join(lines)


def _render_symbol_main_section(
    symbol: SymbolDump,
    group: GroupDump,
    source_link: str,
    changelog_actions: Sequence[ChangelogAction],
    example_link: tuple[str, str] | None = None,
) -> str:
    section_id = f"{slug(symbol.name)}_def"
    stability = render_stability_badge(symbol.name, group.name, changelog_actions)
    since_badge = render_since_badge(get_symbol_since_version(symbol.name, changelog_actions))
    docstring = format_docstring(symbol.docstring)

    lines = [f"## {symbol.type.value}: {symbol.name}", f"- [source]({source_link})"]
    if example_link:
        lines.append(_format_example_link(example_link))
    if stability:
        lines.append(stability)
    if since_badge:
        lines.append(since_badge)
    lines.extend(["", "```python", format_signature(symbol), "```"])
    if docstring:
        lines.extend(["", docstring])
    return wrap_section("\n".join(lines), section_id, PKG_EXT_TOOL_NAME, MD_CONFIG)


def render_symbol_page(
    ctx: SymbolContext,
    group: GroupDump,
    symbol_doc_path: Path,
    pkg_src_dir: Path,
    pkg_import_name: str,
    changes: list[SymbolChange] | None = None,
    changelog_actions: Sequence[ChangelogAction] | None = None,
    *,
    has_env_vars_fn: Callable[[ClassDump], bool] | None = None,
    example_link: tuple[str, str] | None = None,
) -> str:
    symbol = ctx.symbol
    changelog_actions = changelog_actions or []

    source_link = calculate_source_link(
        symbol_doc_path,
        symbol.module_path,
        pkg_src_dir,
        pkg_import_name,
        symbol.line_number,
    )
    main_content = _render_symbol_main_section(symbol, group, source_link, changelog_actions, example_link)
    parts = [f"# {symbol.name}", "", main_content]

    if has_env_vars_fn and isinstance(symbol, ClassDump) and has_env_vars_fn(symbol):
        if env_table := render_env_var_table(symbol):
            parts.extend(["", env_table])

    if isinstance(symbol, CLICommandDump) and symbol.cli_params:
        if table := render_cli_params_table(symbol.cli_params):
            parts.extend(["", "### CLI Options", "", table])

    if isinstance(symbol, ClassDump) and symbol.fields:
        field_versions = _build_field_versions(symbol.name, symbol.fields, changelog_actions)
        if should_show_field_table(symbol.fields, field_versions):
            if table := render_field_table(symbol.fields, field_versions):
                parts.extend(["", "### Fields", "", table])

    if changes:
        parts.extend(["", render_changes_section(changes, symbol.name)])

    return "\n".join(parts)


def _render_changes_content(changes: list[SymbolChange]) -> str:
    lines = [
        "### Changes",
        "",
        "| Version | Change |",
        "|---------|--------|",
    ]
    for c in changes:
        lines.append(f"| {c.version} | {c.description} |")
    return "\n".join(lines)


def render_changes_section(changes: list[SymbolChange], symbol_name: str) -> str:
    if not changes:
        return ""
    section_id = f"{slug(symbol_name)}_changes"
    return wrap_section(_render_changes_content(changes), section_id, PKG_EXT_TOOL_NAME, MD_CONFIG)
