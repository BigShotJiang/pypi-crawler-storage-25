#pragma once
#include <CGAL/Simple_cartesian.h>
#include <CGAL/Bbox_2.h>
#include <CGAL/Bbox_3.h>

typedef CGAL::Simple_cartesian<double> Kernel;
typedef Kernel::Point_2      CGALPoint2;
typedef Kernel::Vector_2     CGALVector2;
typedef Kernel::Direction_2  CGALDirection2;
typedef Kernel::Segment_2    CGALSegment2;
typedef Kernel::Line_2       CGALLine2;
typedef Kernel::Ray_2 CGALRay2;
typedef Kernel::Triangle_2 CGALTriangle2;
typedef Kernel::Circle_2 CGALCircle2;
typedef Kernel::Iso_rectangle_2 CGALIsoRectangle2;
typedef Kernel::Weighted_point_2 CGALWeightedPoint2;
typedef Kernel::Aff_transformation_2 CGALAffTransformation2;

// ─── 3D Typedefs ──────────────────────────────────────────
typedef Kernel::Point_3   CGALPoint3;
typedef Kernel::Vector_3  CGALVector3;
// typedef Kernel::Bbox_3    CGALBbox3;
typedef CGAL::Bbox_3 CGALBbox3;
typedef Kernel::Direction_3 CGALDirection3;
typedef Kernel::Segment_3 CGALSegment3;
typedef Kernel::Line_3 CGALLine3;
typedef Kernel::Plane_3 CGALPlane3;
typedef Kernel::Ray_3 CGALRay3;
typedef Kernel::Triangle_3 CGALTriangle3;
typedef Kernel::Sphere_3 CGALSphere3;
typedef Kernel::Tetrahedron_3 CGALTetrahedron3;
typedef Kernel::Iso_cuboid_3 CGALIsoCuboid3;
typedef Kernel::Circle_3 CGALCircle3;
typedef Kernel::Weighted_point_3 CGALWeightedPoint3;
typedef Kernel::Aff_transformation_3 CGALAffTransformation3;



// ─── Point2 ───────────────────────────────────────────────
// struct Point2 {
//     CGALPoint2 p;
//     Point2(double x, double y) : p(x, y) {}
//     Point2(CGALPoint2 pt) : p(pt) {}
//     double x() const { return CGAL::to_double(p.x()); }
//     double y() const { return CGAL::to_double(p.y()); }
// };
// ─── Point2 ───────────────────────────────────────────────
struct Point2 {
    CGALPoint2 p;

    // --- Creation ---
    Point2() : p(CGAL::ORIGIN) {}
    Point2(double x, double y) : p(x, y) {}
    Point2(int x, int y) : p(x, y) {}
    Point2(CGALPoint2 pt) : p(pt) {}
    // Point2(const WeightedPoint2& wp) : p(wp.wp.point()) {}  // add after WeightedPoint2 defined

    // --- Coordinate access ---
    double x()  const { return CGAL::to_double(p.x()); }
    double y()  const { return CGAL::to_double(p.y()); }
    double hx() const { return CGAL::to_double(p.hx()); }
    double hy() const { return CGAL::to_double(p.hy()); }
    double hw() const { return CGAL::to_double(p.hw()); }

    // --- Convenience ---
    double cartesian(int i)   const { return CGAL::to_double(p.cartesian(i)); }
    double homogeneous(int i) const { return CGAL::to_double(p.homogeneous(i)); }
    double operator[](int i)  const { return CGAL::to_double(p.cartesian(i)); }
    int    dimension()        const { return p.dimension(); }
};

// ─── Vector2 ──────────────────────────────────────────────
struct Vector2 {
    CGALVector2 v;
    Vector2(double x, double y) : v(x, y) {}
    Vector2(CGALVector2 vec) : v(vec) {}
    double x() const { return CGAL::to_double(v.x()); }
    double y() const { return CGAL::to_double(v.y()); }
};

// ─── Direction2 ───────────────────────────────────────────
struct Direction2 {
    CGALDirection2 d;
    Direction2(double x, double y) : d(x, y) {}
    Direction2(CGALDirection2 dir) : d(dir) {}
    double dx()       const { return CGAL::to_double(d.dx()); }
    double dy()       const { return CGAL::to_double(d.dy()); }
    double delta(int i) const { return CGAL::to_double(d.delta(i)); }
};

// ─── Bbox2 ────────────────────────────────────────────────
// struct Bbox2 {
//     double xmin, ymin, xmax, ymax;
//     Bbox2(double xmin, double ymin, double xmax, double ymax)
//         : xmin(xmin), ymin(ymin), xmax(xmax), ymax(ymax) {}
// };
// ─── Bbox2 ────────────────────────────────────────────────
struct Bbox2 {
    CGAL::Bbox_2 b;
    Bbox2() : b() {}
    Bbox2(double xmin, double ymin, double xmax, double ymax)
        : b(xmin, ymin, xmax, ymax) {}
    Bbox2(CGAL::Bbox_2 bbox) : b(bbox) {}
    double xmin() const { return b.xmin(); }
    double ymin() const { return b.ymin(); }
    double xmax() const { return b.xmax(); }
    double ymax() const { return b.ymax(); }
};


// ─── Segment2 ─────────────────────────────────────────────
struct Segment2 {
    CGALSegment2 s;
    Segment2(const Point2& p, const Point2& q)
        : s(CGALPoint2(p.x(), p.y()), CGALPoint2(q.x(), q.y())) {}
    Segment2(CGALSegment2 seg) : s(seg) {}
};

// ─── Line2 (stub — full impl later) ──────────────────────
// Replace the Line2 stub with this:
struct Ray2; // forward declare Ray2 before Line2

struct Line2 {
    CGALLine2 l;
    Line2(CGALLine2 line) : l(line) {}
    Line2(double a, double b, double c) : l(a, b, c) {}
    Line2(const Point2& p, const Point2& q) : l(CGALPoint2(p.x(), p.y()), CGALPoint2(q.x(), q.y())) {}
    Line2(const Point2& p, const Direction2& d) : l(CGALPoint2(p.x(), p.y()), d.d) {}
    Line2(const Point2& p, const Vector2& v) : l(CGALPoint2(p.x(), p.y()), v.v) {}
    Line2(const Segment2& s) : l(s.s) {}
    // Line2(const Ray2& r) : l(r.r) {}
    double a() const { return CGAL::to_double(l.a()); }
    double b() const { return CGAL::to_double(l.b()); }
    double c() const { return CGAL::to_double(l.c()); }
};

// ─── Ray2 ─────────────────────────────────────────────────
struct Ray2 {
    CGALRay2 r;
    Ray2(CGALRay2 ray) : r(ray) {}
    Ray2(const Point2& p, const Point2& q)
        : r(CGALPoint2(p.x(), p.y()), CGALPoint2(q.x(), q.y())) {}
    Ray2(const Point2& p, const Direction2& d)
        : r(CGALPoint2(p.x(), p.y()), d.d) {}
    Ray2(const Point2& p, const Vector2& v)
        : r(CGALPoint2(p.x(), p.y()), v.v) {}
    Ray2(const Point2& p, const Line2& l)
        : r(CGALPoint2(p.x(), p.y()), l.l) {}
};

// ─── Triangle2 ────────────────────────────────────────────
struct Triangle2 {
    CGALTriangle2 t;
    Triangle2(CGALTriangle2 tri) : t(tri) {}
    Triangle2(const Point2& p, const Point2& q, const Point2& r)
        : t(CGALPoint2(p.x(), p.y()),
            CGALPoint2(q.x(), q.y()),
            CGALPoint2(r.x(), r.y())) {}
};


// ─── Circle2 ──────────────────────────────────────────────
struct Circle2 {
    CGALCircle2 c;
    Circle2(CGALCircle2 circle) : c(circle) {}
    // From center, squared_radius, orientation (1=CCW, -1=CW)
    Circle2(const Point2& center, double squared_radius, int ori = 1)
        : c(CGALPoint2(center.x(), center.y()),
            squared_radius,
            ori >= 0 ? CGAL::COUNTERCLOCKWISE : CGAL::CLOCKWISE) {}
    // From three points
    Circle2(const Point2& p, const Point2& q, const Point2& r)
        : c(CGALPoint2(p.x(), p.y()),
            CGALPoint2(q.x(), q.y()),
            CGALPoint2(r.x(), r.y())) {}
    // From two points (diameter), orientation
    Circle2(const Point2& p, const Point2& q, int ori = 1)
        : c(CGALPoint2(p.x(), p.y()),
            CGALPoint2(q.x(), q.y()),
            ori >= 0 ? CGAL::COUNTERCLOCKWISE : CGAL::CLOCKWISE) {}
    // From center only, orientation
    Circle2(const Point2& center, int ori = 1)
        : c(CGALPoint2(center.x(), center.y()),
            ori >= 0 ? CGAL::COUNTERCLOCKWISE : CGAL::CLOCKWISE) {}
};



// ─── IsoRectangle2 ────────────────────────────────────────
struct IsoRectangle2 {
    CGALIsoRectangle2 r;
    IsoRectangle2(CGALIsoRectangle2 rect) : r(rect) {}
    // From two diagonal opposite vertices
    IsoRectangle2(const Point2& p, const Point2& q)
        : r(CGALPoint2(p.x(), p.y()), CGALPoint2(q.x(), q.y())) {}
    // From four vertices: left, right, bottom, top
    IsoRectangle2(const Point2& left, const Point2& right,
                  const Point2& bottom, const Point2& top)
        : r(CGALPoint2(left.x(),   left.y()),
            CGALPoint2(right.x(),  right.y()),
            CGALPoint2(bottom.x(), bottom.y()),
            CGALPoint2(top.x(),    top.y())) {}
    // From min/max coordinates
    IsoRectangle2(double min_x, double min_y, double max_x, double max_y)
        : r(CGALPoint2(min_x, min_y), CGALPoint2(max_x, max_y)) {}
    // From Bbox2
    // IsoRectangle2(const Bbox2& bbox)
    //     : r(CGALPoint2(bbox.xmin, bbox.ymin),
    //         CGALPoint2(bbox.xmax, bbox.ymax)) {}
        IsoRectangle2(const Bbox2& bbox)
    : r(CGALPoint2(bbox.xmin(), bbox.ymin()),
        CGALPoint2(bbox.xmax(), bbox.ymax())) {}
};


// ─── WeightedPoint2 ───────────────────────────────────────
struct WeightedPoint2 {
    CGALWeightedPoint2 wp;
    WeightedPoint2(CGALWeightedPoint2 p) : wp(p) {}
    // From origin
    WeightedPoint2() : wp(CGAL::ORIGIN) {}
    // From point only, weight 0
    WeightedPoint2(const Point2& p)
        : wp(CGALPoint2(p.x(), p.y())) {}
    // From point and weight
    WeightedPoint2(const Point2& p, double w)
        : wp(CGALPoint2(p.x(), p.y()), w) {}
    // From x, y coordinates, weight 0
    WeightedPoint2(double x, double y)
        : wp(CGALPoint2(x, y)) {}
};

// ─── AffTransformation2 ───────────────────────────────────
struct AffTransformation2 {
    CGALAffTransformation2 t;
    AffTransformation2(CGALAffTransformation2 t) : t(t) {}
    // Identity
    AffTransformation2()
        : t(CGAL::IDENTITY) {}
    // Translation
    AffTransformation2(const Vector2& v)
        : t(CGAL::TRANSLATION, v.v) {}
    // Scaling
    AffTransformation2(double s)
        : t(CGAL::SCALING, s) {}
    // Reflection
    AffTransformation2(const Line2& l)
        : t(CGAL::REFLECTION, l.l) {}
    // Rotation by sine/cosine
    AffTransformation2(double sine, double cosine)
        : t(CGAL::ROTATION, sine, cosine) {}
    // General affine with translation
    AffTransformation2(double m00, double m01, double m02,
                       double m10, double m11, double m12)
        : t(m00, m01, m02, m10, m11, m12) {}
    // General linear (no translation)
    AffTransformation2(double m00, double m01,
                       double m10, double m11)
        : t(m00, m01, m10, m11) {}
};


// // At bottom of types.h after all structs defined:
// inline Point2 point2_from_weighted(const WeightedPoint2& wp) {
//     auto pt = wp.wp.point();
//     return Point2(CGAL::to_double(pt.x()), CGAL::to_double(pt.y()));
// }


// ─── Point3 ───────────────────────────────────────────────
struct Point3 {
    CGALPoint3 p;

    Point3() : p(CGAL::ORIGIN) {}
    Point3(double x, double y, double z) : p(x, y, z) {}
    Point3(int x, int y, int z) : p(x, y, z) {}
    Point3(CGALPoint3 pt) : p(pt) {}

    double x()  const { return CGAL::to_double(p.x()); }
    double y()  const { return CGAL::to_double(p.y()); }
    double z()  const { return CGAL::to_double(p.z()); }
    double hx() const { return CGAL::to_double(p.hx()); }
    double hy() const { return CGAL::to_double(p.hy()); }
    double hz() const { return CGAL::to_double(p.hz()); }
    double hw() const { return CGAL::to_double(p.hw()); }

    double cartesian(int i)   const { return CGAL::to_double(p.cartesian(i)); }
    double homogeneous(int i) const { return CGAL::to_double(p.homogeneous(i)); }
    double operator[](int i)  const { return CGAL::to_double(p.cartesian(i)); }
    int    dimension()        const { return p.dimension(); }
};

// ─── Vector3 ──────────────────────────────────────────────
struct Vector3 {
    CGALVector3 v;
    Vector3() : v(CGAL::NULL_VECTOR) {}

    Vector3(double x, double y, double z) : v(x, y, z) {}
    Vector3(int x, int y, int z) : v(x, y, z) {}
    Vector3(CGALVector3 vec) : v(vec) {}

    double x()  const { return CGAL::to_double(v.x()); }
    double y()  const { return CGAL::to_double(v.y()); }
    double z()  const { return CGAL::to_double(v.z()); }
    double hx() const { return CGAL::to_double(v.hx()); }
    double hy() const { return CGAL::to_double(v.hy()); }
    double hz() const { return CGAL::to_double(v.hz()); }
    double hw() const { return CGAL::to_double(v.hw()); }

    double cartesian(int i)   const { return CGAL::to_double(v.cartesian(i)); }
    double homogeneous(int i) const { return CGAL::to_double(v.homogeneous(i)); }
    double operator[](int i)  const { return CGAL::to_double(v.cartesian(i)); }
    int    dimension()        const { return v.dimension(); }
};

// ─── Direction3 ───────────────────────────────────────────
struct Direction3 {
    CGALDirection3 d;
    Direction3(CGALDirection3 dir) : d(dir) {}
    Direction3(double x, double y, double z) : d(x, y, z) {}
    double dx()        const { return CGAL::to_double(d.dx()); }
    double dy()        const { return CGAL::to_double(d.dy()); }
    double dz()        const { return CGAL::to_double(d.dz()); }
    double delta(int i) const { return CGAL::to_double(d.delta(i)); }
};

// ─── Bbox3 ────────────────────────────────────────────────
struct Bbox3 {
    CGAL::Bbox_3 b;
    Bbox3() : b() {}
    Bbox3(double xmin, double ymin, double zmin,
          double xmax, double ymax, double zmax)
        : b(xmin, ymin, zmin, xmax, ymax, zmax) {}
    Bbox3(CGAL::Bbox_3 bbox) : b(bbox) {}
    double xmin() const { return b.xmin(); }
    double ymin() const { return b.ymin(); }
    double zmin() const { return b.zmin(); }
    double xmax() const { return b.xmax(); }
    double ymax() const { return b.ymax(); }
    double zmax() const { return b.zmax(); }
};

// ─── Segment3 ─────────────────────────────────────────────
struct Segment3 {
    CGALSegment3 s;
    Segment3(CGALSegment3 seg) : s(seg) {}
    Segment3(const Point3& p, const Point3& q)
        : s(CGALPoint3(p.x(), p.y(), p.z()),
            CGALPoint3(q.x(), q.y(), q.z())) {}
};

// ─── Line3 stub ───────────────────────────────────────────
// struct Line3 {
//     Kernel::Line_3 l;
//     Line3(Kernel::Line_3 line) : l(line) {}
// };

// ─── Line3 ────────────────────────────────────────────────
struct Line3 {
    CGALLine3 l;
    Line3(CGALLine3 line) : l(line) {}
    Line3(const Point3& p, const Point3& q)
        : l(CGALPoint3(p.x(), p.y(), p.z()),
            CGALPoint3(q.x(), q.y(), q.z())) {}
    Line3(const Point3& p, const Direction3& d)
        : l(CGALPoint3(p.x(), p.y(), p.z()), d.d) {}
    Line3(const Point3& p, const Vector3& v)
        : l(CGALPoint3(p.x(), p.y(), p.z()), v.v) {}
    Line3(const Segment3& s) : l(s.s) {}
};

// // ─── Plane3 stub (full impl later) ───────────────────────
// struct Plane3 {
//     Kernel::Plane_3 p;
//     Plane3(Kernel::Plane_3 plane) : p(plane) {}
// };


// ─── Plane3 ───────────────────────────────────────────────
struct Plane3 {
    CGALPlane3 p;
    Plane3(CGALPlane3 plane) : p(plane) {}
    // From a, b, c, d coefficients
    Plane3(double a, double b, double c, double d) : p(a, b, c, d) {}
    // From three points
    Plane3(const Point3& p1, const Point3& p2, const Point3& p3)
        : p(CGALPoint3(p1.x(), p1.y(), p1.z()),
            CGALPoint3(p2.x(), p2.y(), p2.z()),
            CGALPoint3(p3.x(), p3.y(), p3.z())) {}
    // From point and vector
    Plane3(const Point3& pt, const Vector3& v)
        : p(CGALPoint3(pt.x(), pt.y(), pt.z()), v.v) {}
    // From point and direction
    Plane3(const Point3& pt, const Direction3& d)
        : p(CGALPoint3(pt.x(), pt.y(), pt.z()), d.d) {}
    // From line and point
    Plane3(const Line3& l, const Point3& pt)
        : p(l.l, CGALPoint3(pt.x(), pt.y(), pt.z())) {}
    // From ray and point
    // Plane3(const Ray3& r, const Point3& pt)
    //     : p(r.r, CGALPoint3(pt.x(), pt.y(), pt.z())) {}
    // From segment and point
    // Plane3(const Segment3& s, const Point3& pt)
    //     : p(s.s, CGALPoint3(pt.x(), pt.y(), pt.z())) {}
    double a() const { return CGAL::to_double(p.a()); }
    double b() const { return CGAL::to_double(p.b()); }
    double c() const { return CGAL::to_double(p.c()); }
    double d() const { return CGAL::to_double(p.d()); }
};



// ─── Ray3 ─────────────────────────────────────────────────
struct Ray3 {
    CGALRay3 r;
    Ray3(CGALRay3 ray) : r(ray) {}
    Ray3(const Point3& p, const Point3& q)
        : r(CGALPoint3(p.x(), p.y(), p.z()),
            CGALPoint3(q.x(), q.y(), q.z())) {}
    Ray3(const Point3& p, const Direction3& d)
        : r(CGALPoint3(p.x(), p.y(), p.z()), d.d) {}
    Ray3(const Point3& p, const Vector3& v)
        : r(CGALPoint3(p.x(), p.y(), p.z()), v.v) {}
    Ray3(const Point3& p, const Line3& l)
        : r(CGALPoint3(p.x(), p.y(), p.z()), l.l) {}
};

// ─── Triangle3 ────────────────────────────────────────────
struct Triangle3 {
    CGALTriangle3 t;
    Triangle3(CGALTriangle3 tri) : t(tri) {}
    Triangle3(const Point3& p, const Point3& q, const Point3& r)
        : t(CGALPoint3(p.x(), p.y(), p.z()),
            CGALPoint3(q.x(), q.y(), q.z()),
            CGALPoint3(r.x(), r.y(), r.z())) {}
};


// ─── Sphere3 ──────────────────────────────────────────────
struct Sphere3 {
    CGALSphere3 s;
    Sphere3(CGALSphere3 sphere) : s(sphere) {}
    // From center, squared_radius, orientation
    Sphere3(const Point3& center, double squared_radius, int ori = 1)
        : s(CGALPoint3(center.x(), center.y(), center.z()),
            squared_radius,
            ori >= 0 ? CGAL::COUNTERCLOCKWISE : CGAL::CLOCKWISE) {}
    // From four points
    Sphere3(const Point3& p, const Point3& q,
            const Point3& r, const Point3& s_)
        : s(CGALPoint3(p.x(), p.y(), p.z()),
            CGALPoint3(q.x(), q.y(), q.z()),
            CGALPoint3(r.x(), r.y(), r.z()),
            CGALPoint3(s_.x(), s_.y(), s_.z())) {}
    // From three points, orientation
    Sphere3(const Point3& p, const Point3& q,
            const Point3& r, int ori = 1)
        : s(CGALPoint3(p.x(), p.y(), p.z()),
            CGALPoint3(q.x(), q.y(), q.z()),
            CGALPoint3(r.x(), r.y(), r.z()),
            ori >= 0 ? CGAL::COUNTERCLOCKWISE : CGAL::CLOCKWISE) {}
    // From two points, orientation
    Sphere3(const Point3& p, const Point3& q, int ori = 1)
        : s(CGALPoint3(p.x(), p.y(), p.z()),
            CGALPoint3(q.x(), q.y(), q.z()),
            ori >= 0 ? CGAL::COUNTERCLOCKWISE : CGAL::CLOCKWISE) {}
    // From center only, orientation
    Sphere3(const Point3& center, int ori = 1)
        : s(CGALPoint3(center.x(), center.y(), center.z()),
            ori >= 0 ? CGAL::COUNTERCLOCKWISE : CGAL::CLOCKWISE) {}
};


// ─── Tetrahedron3 ─────────────────────────────────────────
struct Tetrahedron3 {
    CGALTetrahedron3 t;
    Tetrahedron3(CGALTetrahedron3 tet) : t(tet) {}
    Tetrahedron3(const Point3& p0, const Point3& p1,
                 const Point3& p2, const Point3& p3)
        : t(CGALPoint3(p0.x(), p0.y(), p0.z()),
            CGALPoint3(p1.x(), p1.y(), p1.z()),
            CGALPoint3(p2.x(), p2.y(), p2.z()),
            CGALPoint3(p3.x(), p3.y(), p3.z())) {}
};

// ─── IsoCuboid3 ───────────────────────────────────────────
struct IsoCuboid3 {
    CGALIsoCuboid3 c;
    IsoCuboid3(CGALIsoCuboid3 cuboid) : c(cuboid) {}
    // From two diagonal opposite vertices
    IsoCuboid3(const Point3& p, const Point3& q)
        : c(CGALPoint3(p.x(), p.y(), p.z()),
            CGALPoint3(q.x(), q.y(), q.z())) {}
    // From six vertices: left, right, bottom, top, far, close
    IsoCuboid3(const Point3& left,  const Point3& right,
               const Point3& bottom, const Point3& top,
               const Point3& far,   const Point3& close)
        : c(CGALPoint3(left.x(),   left.y(),   left.z()),
            CGALPoint3(right.x(),  right.y(),  right.z()),
            CGALPoint3(bottom.x(), bottom.y(), bottom.z()),
            CGALPoint3(top.x(),    top.y(),    top.z()),
            CGALPoint3(far.x(),    far.y(),    far.z()),
            CGALPoint3(close.x(),  close.y(),  close.z())) {}
    // From min/max coordinates
    IsoCuboid3(double min_x, double min_y, double min_z,
               double max_x, double max_y, double max_z)
        : c(CGALPoint3(min_x, min_y, min_z),
            CGALPoint3(max_x, max_y, max_z)) {}
    // From Bbox3
    IsoCuboid3(const Bbox3& bbox)
        : c(CGALPoint3(bbox.xmin(), bbox.ymin(), bbox.zmin()),
            CGALPoint3(bbox.xmax(), bbox.ymax(), bbox.zmax())) {}
};


// ─── Circle3 ──────────────────────────────────────────────
struct Circle3 {
    CGALCircle3 c;
    Circle3(CGALCircle3 circle) : c(circle) {}
    // From center, squared radius, plane
    Circle3(const Point3& center, double sq_r, const Plane3& plane)
        : c(CGALPoint3(center.x(), center.y(), center.z()), sq_r, plane.p) {}
    // From center, squared radius, normal vector
    Circle3(const Point3& center, double sq_r, const Vector3& n)
        : c(CGALPoint3(center.x(), center.y(), center.z()), sq_r, n.v) {}
    // From three points
    Circle3(const Point3& p, const Point3& q, const Point3& r)
        : c(CGALPoint3(p.x(), p.y(), p.z()),
            CGALPoint3(q.x(), q.y(), q.z()),
            CGALPoint3(r.x(), r.y(), r.z())) {}
    // From two spheres
    Circle3(const Sphere3& s1, const Sphere3& s2) : c(s1.s, s2.s) {}
    // From sphere and plane
    Circle3(const Sphere3& s, const Plane3& plane) : c(s.s, plane.p) {}
    // From plane and sphere
    Circle3(const Plane3& plane, const Sphere3& s) : c(plane.p, s.s) {}
};


// ─── WeightedPoint3 ───────────────────────────────────────
struct WeightedPoint3 {
    CGALWeightedPoint3 wp;
    WeightedPoint3(CGALWeightedPoint3 p) : wp(p) {}
    // From origin
    WeightedPoint3() : wp(CGAL::ORIGIN) {}
    // From point only, weight 0
    WeightedPoint3(const Point3& p)
        : wp(CGALPoint3(p.x(), p.y(), p.z())) {}
    // From point and weight
    WeightedPoint3(const Point3& p, double w)
        : wp(CGALPoint3(p.x(), p.y(), p.z()), w) {}
    // From x, y, z coordinates, weight 0
    WeightedPoint3(double x, double y, double z)
        : wp(CGALPoint3(x, y, z)) {}
};


// ─── AffTransformation3 ───────────────────────────────────
struct AffTransformation3 {
    CGALAffTransformation3 t;
    AffTransformation3(CGALAffTransformation3 t) : t(t) {}
    // Identity
    AffTransformation3()
        : t(CGAL::IDENTITY) {}
    // Translation
    AffTransformation3(const Vector3& v)
        : t(CGAL::TRANSLATION, v.v) {}
    // Scaling
    AffTransformation3(double s)
        : t(CGAL::SCALING, s) {}
    // General affine with translation (12 params)
    AffTransformation3(double m00, double m01, double m02, double m03,
                       double m10, double m11, double m12, double m13,
                       double m20, double m21, double m22, double m23)
        : t(m00, m01, m02, m03,
            m10, m11, m12, m13,
            m20, m21, m22, m23) {}
    // General linear no translation (9 params)
    AffTransformation3(double m00, double m01, double m02,
                       double m10, double m11, double m12,
                       double m20, double m21, double m22)
        : t(m00, m01, m02,
            m10, m11, m12,
            m20, m21, m22) {}
};