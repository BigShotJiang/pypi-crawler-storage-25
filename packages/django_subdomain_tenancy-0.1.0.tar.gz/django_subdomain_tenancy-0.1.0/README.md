## django_subdomain_tenancy


django-subdomain-tenancy is a Django multi-tenant app where each subdomain is a tenant, 
simplifying deployment, scalability, and per-client management.

Detailed documentation is in the "docs" directory.

### Quick start

#### 1. Add `django_subdomain_tenancy.apps.SubdomainConfig` to your `INSTALLED_APPS` setting like this:

```python
    INSTALLED_APPS = [
        ...,
        "django_subdomain_tenancy.apps.SubdomainConfig",
    ]
```

#### 2. Add this configs in `settings.py`:

```python
    AUTH_USER_MODEL = 'subdomain.CustomUser'
    LOGIN_URL = '/accounts/login/' 
    LOGIN_REDIRECT_URL = "/"
    LOGOUT_REDIRECT_URL = "/"

    LANGUAGE_CODE = "pt-BR" OR "en"

    EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
    
    EMAIL_HOST = XXXXXXXXX
    EMAIL_PORT = XXXXXXXXX
    EMAIL_USE_TLS = XXXXXXXXX
    EMAIL_HOST_USER = XXXXXXXXX
    EMAIL_HOST_PASSWORD = XXXXXXXXX
    DEFAULT_FROM_EMAIL = XXXXXXXXX


```
    
#### 3. Include the polls URLconf in your project urls.py like this::

```python
    path("", include("django_subdomain_tenancy.urls")),
```

#### 4. Run `python3 manage.py migrate` to create the models.

#### 5. Create a record in instance table for master dubdomain:

```python
    insert into django_subdomain_tenancy_intance 
    values(1, "Master Tenant", "master", 1);
```

#### 6. Create SuperUser `administrator`
    (It needs to be this way, because they're the only user who can log in to all the subdomains.), 
    and set id instance `1`:

    ``python3 manage.py createsuperuser``

#### 7. Visit the `/` For Login in the system fronend,
    `/admin/` Logging is only allowed using the master subdomain.

#### 8. For the development environment, add one more instance; I'll use the test subdomain cobaia:

```python
    insert into django_subdomain_tenancy_intance 
    values(2, "Cobaia Tenant", "cobaia", 1);
```

If use Linux or Mac add the following lines to the `/etc/hosts` file:
```python
    127.0.0.1 master.localhost
    127.0.0.1 cobaia.localhost
```

If you're using Windows, you're starting the project the wrong way.

#### 9. Access tenant urls:

```python
    master.localhost:8000
    cobaia.localhost:8000
```

Simple Login Frontend: `/accounts/login/`