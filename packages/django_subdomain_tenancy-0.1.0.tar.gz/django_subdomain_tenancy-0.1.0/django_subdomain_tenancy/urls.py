from django.urls import path, include
from .views import (    
    CustomLoginView,
    login_view,
    CustomPasswordResetView
)

urlpatterns = [    
    path('admin/login/', login_view, name='admin_login'),   
    path('admin/password_reset/', CustomPasswordResetView.as_view(), name='password_reset'),    
    path("accounts/login/", CustomLoginView.as_view(), name='login_view'),
    path("accounts/", include("django.contrib.auth.urls")),
]