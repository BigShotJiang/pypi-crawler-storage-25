import threading
from django.contrib.auth import authenticate, login
from django.shortcuts import render, redirect
from django.contrib.auth.forms import PasswordResetForm as DefaultPasswordResetForm
from django.core.mail import send_mail, EmailMultiAlternatives
from django.template import loader
from django.contrib.auth.views import LoginView, PasswordResetView
from django.contrib.auth.forms import AuthenticationForm
from django.utils.translation import gettext as _

def send_email_async(subject, message, from_email, recipient_list, fail_silently):
    send_mail(subject, message, from_email, recipient_list, fail_silently)

class CustomPasswordResetForm(DefaultPasswordResetForm):
    def send_mail(self, subject_template_name, email_template_name, context, from_email, to_email, html_email_template_name=None):
        subject = loader.render_to_string(subject_template_name, context)
        subject = "".join(subject.splitlines())
        body = loader.render_to_string(email_template_name, context)
        email_message = EmailMultiAlternatives(subject, body, from_email, [to_email])
        if html_email_template_name is not None:
            html_email = loader.render_to_string(html_email_template_name, context)
            email_message.attach_alternative(html_email, "text/html")
        thread = threading.Thread(target=send_email_async, args=(subject, body, from_email, [to_email], False))
        thread.start()

class CustomPasswordResetView(PasswordResetView):
    form_class = CustomPasswordResetForm        
    template_name = 'registration/password_reset_form.html'

class CustomAuthenticationForm(AuthenticationForm):    
    def clean(self):
        subdomain = self.request.build_absolute_uri('/').split('.')[0]
        subdomain = subdomain.replace('http://', '').replace('https://', '')
        subdomain = str(subdomain) + '_'
        username = self.cleaned_data.get("username")
        password = self.cleaned_data.get("password")
        if username == 'administrator':
            username = 'master_' + username    
        else:
            username = subdomain + username
        
        if username is not None and password:
            self.user_cache = authenticate(self.request, username=username, password=password)
            if self.user_cache is None:
                raise self.get_invalid_login_error()
            else:            
                if self.user_cache.groups.filter(name='Socket').exists():
                    raise self.get_invalid_login_error()                    
                self.confirm_login_allowed(self.user_cache)
        return self.cleaned_data

class CustomLoginView(LoginView):    
    authentication_form = CustomAuthenticationForm
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        subdomain = self.request.build_absolute_uri('/').split('.')[0]
        subdomain = subdomain.replace('http://', '').replace('https://', '')
        context['domain'] = subdomain        
        return context

def login_view(request):
    if request.method == 'POST':        
        raw_username = request.POST.get('username')
        password = request.POST.get('password')
        instance = getattr(request, 'instance', None)
        if not instance:
            return render(request, 'admin/custom_login.html', {'error': _("Invalid Instance.")})
        full_username = f"{instance.subdomain.lower()}_{raw_username}"
        user = authenticate(request, username=full_username, password=password)
        if user:
            login(request, user)
            return redirect('/admin/')
        else:
            return render(request, 'admin/custom_login.html', {'error': _("Invalid username or password.")})
    return render(request, 'admin/custom_login.html')

def account_login_view(request):
    if request.method == 'POST':        
        raw_username = request.POST.get('username')
        password = request.POST.get('password')
        instance = getattr(request, 'instance', None)
        if not instance:
            return render(request, 'admin/custom_login.html', {'error': _("Invalid Instance.")})
        full_username = f"{instance.subdomain.lower()}_{raw_username}"
        user = authenticate(request, username=full_username, password=password)        
        if user:
            login(request, user)
            return redirect('/admin/')
        else:
            return render(request, 'admin/custom_login.html', {'error': _("Invalid username or password.")})
    return render(request, 'admin/custom_login.html')
