from django.utils.deprecation import MiddlewareMixin
from .models import *
from django.http import Http404

class InstanceMiddleware(MiddlewareMixin):
    def process_request(self, request):
        host = request.get_host().split(':')[0]        
        subdomain = host.split('.')[0].lower()        
        try:
            request.instance = Instance.objects.filter(subdomain=subdomain).first()
        except Instance.DoesNotExist:
            request.instance = None
                    
        if request.path.startswith('/admin/'):
            allowed_subdomain = 'master'  # Subdomínio permitido
            
            if subdomain != allowed_subdomain:
                raise Http404("Not found.")            
        if request.instance is None and request.method == 'GET':
            raise Http404("Instance not found.")