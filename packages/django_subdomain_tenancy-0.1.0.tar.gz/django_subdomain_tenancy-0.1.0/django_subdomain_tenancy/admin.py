from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.contrib.auth.models import Group
from django import forms
from django.contrib.auth.forms import UserCreationForm, UserChangeForm
from django.core.exceptions import ValidationError
from django.utils.translation import gettext as _

from .models import *

class CustomUserAdminForm(UserCreationForm):
    class Meta:
        model = CustomUser
        fields = ['username', 'email', 'password1', 'password2', 'instance', 'groups']
    
    def __init__(self, *args, **kwargs):        
        super().__init__(*args, **kwargs)                
    
    def clean_email(self):        
        email = self.cleaned_data.get('email')
        instance = self.cleaned_data.get('instance')
        prefix_add = str(instance.subdomain.lower()) + '_'
        user_query = CustomUser.objects.filter(username__startswith=prefix_add, email=email)
        
        if user_query:
            raise ValidationError(_("There is already a registered user with this email!"))
        return email
    
    def save(self, commit=True):
        user = super().save(commit=False)
        if user is None:
            raise ValueError(_("The user instance was not created correctly."))
        
        prefix = user.instance.subdomain.lower()
        raw_username = self.cleaned_data.get('raw_username')

        if raw_username:
            user.username = f"{prefix}_{raw_username}"
        
        if commit:            
            user.save()            
            self.save_m2m()
        else:            
            user.save()
            
            if user.is_superuser:
                user.is_staff = True
            else:
                user.is_staff = False
            user.save()
            self.save_m2m()

        return user
class CustomUserEditForm(UserChangeForm):
    raw_username = forms.CharField(label=_("User"), max_length=150)

    class Meta:
        model = CustomUser
        fields = ['raw_username', 'instance', 'groups']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.instance and self.instance.username:
            self.fields['raw_username'].initial = self.instance.display_username
            self.fields['email'].required = True

    def clean_email(self):        
        email = self.cleaned_data.get('email')
        raw_username = self.cleaned_data.get('raw_username')        
        instance_selected = self.cleaned_data.get('instance')
        prefix_edit = str(instance_selected.subdomain.lower()) + '_'
        username_edit = str(prefix_edit) + str(raw_username)
        user_query = CustomUser.objects.filter(username__startswith=prefix_edit, email=email).exclude(username=username_edit)
        
        if user_query:
            raise ValidationError(_("There is already a registered user with this email!"))
        return email

    def save(self, commit=True):
        user = super().save(commit=False)
        if user is None:
            raise ValueError(_("The user instance was not created correctly."))
        
        prefix = user.instance.subdomain.lower()
        raw_username = self.cleaned_data.get('raw_username')

        if raw_username:
            user.username = f"{prefix}_{raw_username}"

        if commit:
            user.save()
            self.save_m2m()
            
        return user


class CustomUserAdmin(UserAdmin):
    form = CustomUserEditForm
    add_form = CustomUserAdminForm
    model = CustomUser

    def get_list_display(self, request):
        if request.user.is_superuser or request.user.groups.filter(name='Suporte').exists():
            return ['id', 'instance', 'username', 'email', 'first_name', 'last_name', 'is_staff', 'is_superuser', 'is_active', 'last_login']
        else:
            if request.user.groups.filter(id=2).exists():
                return ['id', 'instance', 'username', 'email', 'first_name', 'last_name', 'is_active', 'last_login']
            elif request.user.groups.filter(id=3).exists():                
                return ['id', 'instance', 'username', 'email', 'first_name', 'last_name', 'is_staff', 'is_superuser', 'is_active', 'last_login']

    def get_readonly_fields(self, request, obj=None):        
        if request.user.is_superuser:
            return []
        else: 
            return ['instance']
    
    def save_model(self, request, obj, form, change):        
        if request.user.is_superuser:            
            obj.instance = form.cleaned_data['instance']
            if change:                
                obj.username = str(obj.instance.subdomain) + '_' + str(obj.username.split('_')[1])        
            else:
                obj.username = str(obj.instance.subdomain) + '_' + str(obj.username)        
        else:
            obj.instance = Instance.objects.filter(id=request.user.instance_id).first()
            if change:
                obj.username = str(request.user.instance.subdomain) + '_' + str(obj.username.split('_')[1])
            else:
                obj.username = str(request.user.instance.subdomain) + '_' + str(obj.username)
        
        super().save_model(request, obj, form, change)
        
        if change:
            if obj.is_superuser:
                obj.is_staff = True
            else:
                obj.is_staff = False
            obj.save()
        else:
            new_user = CustomUser.objects.filter(id=obj.id).first()
            
            if new_user.is_superuser:
                obj.is_staff = True
            else:
                obj.is_staff = False
            obj.save()
        
    
    fieldsets = (
        (None, {'fields': ('instance', 'raw_username', 'email', 'password')}),
        (_("Permissions"), {'fields': ('groups', 'is_active')}),
    )
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('instance', 'username', 'email', 'password1', 'password2', 'groups'),            
        }),
    )

    def has_delete_permission(self, request, obj=None):
        return False

admin.site.register(CustomUser, CustomUserAdmin)