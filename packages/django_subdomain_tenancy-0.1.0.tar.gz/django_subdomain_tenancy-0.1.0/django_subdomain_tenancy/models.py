from django.db import models
from django.contrib.auth.models import AbstractUser, BaseUserManager, Group, Permission
from django.utils.translation import gettext as _

ACTIVE_INACTIVE = (
    (1, _("Active"),), 
    (0, _("Inactive"),)
)

class Instance(models.Model):
    name = models.CharField(max_length=200, default='', verbose_name='Nome')    
    subdomain = models.CharField(
        max_length=100,  # Reduzi de 300
        unique=True,
        blank=False,
        null=False,
        db_index=True,
        verbose_name=_('Subdomain')
    )
    status_instance = models.SmallIntegerField(default=1, null=False, verbose_name=_("Instance Status"), choices=ACTIVE_INACTIVE)    
    
    class Meta:
        verbose_name = _("Instance")
        verbose_name_plural = _("Instances")
        ordering = ('-id',)

    def __str__(self):
        return str(self.id) + " - " + str(self.name)

class CustomUserManager(BaseUserManager):
    def create_user(self, username, password=None, instance=None, **extra_fields):
        if not instance:
            raise ValueError(_("It is necessary to inform the instance"))
        if not username:
            raise ValueError(_("The username field is required"))

        prefix = instance.subdomain.lower()
        full_username = f"{prefix}_{username}"

        extra_fields.setdefault('is_active', True)
        user = self.model(username=full_username, instance=instance, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, username, password=None, instance=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
                
        instance_object = Instance.objects.filter(id=instance).first()
        return self.create_user(username, password, instance_object, **extra_fields)


class CustomUser(AbstractUser):
    username = models.CharField(max_length=150, unique=True)
    instance = models.ForeignKey(Instance, on_delete=models.CASCADE)
    
    groups = models.ManyToManyField(
        Group,
        related_name='customuser_groups',        
        help_text=_("Groups to which this user belongs. They will inherit all permissions from these groups.")
    )

    user_permissions = models.ManyToManyField(
        Permission,
        related_name='customuser_permissions',
        blank=True,
        help_text=_("Specific permissions assigned directly to this user.")
    )

    objects = CustomUserManager()

    USERNAME_FIELD = 'username'
    REQUIRED_FIELDS = ['instance']

    class Meta:
        verbose_name = _("User")
        verbose_name_plural = _("Users")

    def __str__(self):
        return f"{self.username} ({self.instance.name})"

    @property
    def display_username(self):        
        return self.username.split('_', 1)[-1]
    
    def display_avatar(self):
        return self.instance.avatar_base64