<p>
  <img src="../.github/assets/readme/zpe-masthead.gif" alt="ZPE-Robotics Masthead" width="100%">
</p>

# FAQ

<p>
  <img src="../.github/assets/readme/section-bars/what-this-is.svg" alt="WHAT THIS IS" width="100%">
</p>

Short answers about the current ZPE-Robotics package, blocker state, and
release boundary.

<p>
  <img src="../.github/assets/readme/section-bars/questions.svg" alt="QUESTIONS" width="100%">
</p>

## Is this repo public?

Yes. The GitHub repo is public, and the package acquisition surface is public
via `pip install zpe-robotics`. That does not mean engineering is
complete or release-ready.

## Is this repo release-ready?

No. Engineering carries named open blockers: benchmark gate `B3` fails, red-team
attack `3` fails, attack `4` only partially withstands, attack `7` remains open,
and the robotics `.zpbot` path is not routed through a current ZPE-IMC Rust ABI. Each blocker is
tracked with an honest description in `proofs/ENGINEERING_BLOCKERS.md`.

## What is actually green right now?

The technical release surface is aligned for the standalone package wedge, and
benchmark gates `B1`, `B2`, `B4`, and `B5` pass. Red-team attacks `1`, `2`,
`5`, and `6` also withstand. Attack `5` is threshold-selected at `3.22` on the
declared Phase 10 holdout surface. The bounded-lossy archive/search claim is
ratified by `proofs/narrow_claim/NARROW_CLAIM_GATE.json`.

## What is still blocked?

The governing blockers are:

- `B3` because searchability is present but strict bit-exact replay is not
- red-team attack `3` because strict `np.array_equal` fails on the current
  round-trip path
- current Python encode/decode still does not route through a robotics Rust ABI
- external third-party reproduction remains open

Attack `5` is no longer a blocker-facing failure on the declared Phase 10
surface: the current evidence records `threshold=3.22`,
`false_positive_rate=0.05`, and `recall=0.9`.

## Is the package available today?

Yes. The current package acquisition surface is `pip install zpe-robotics`.
That does not change blocker status.

## What claim is ratified now?

Only the bounded-lossy archive/search claim: `.zpbot` archive/replay
infrastructure, decoded PrimitiveIndex search, VLA token export, and the
declared proof surfaces. It is not a lossless codec, not search without decode,
not live robot control, and not Robotics Rust ABI routing.

<p>
  <img src="../.github/assets/readme/section-bars/setup-and-verification.svg" alt="SETUP AND VERIFICATION" width="100%">
</p>

## How do I verify the current truth quickly?

Use `AUDITOR_PLAYBOOK.md` for the shortest honest replay path. The current
proof anchors are:

- `../proofs/ENGINEERING_BLOCKERS.md`
- `../proofs/narrow_claim/NARROW_CLAIM_GATE.json`
- `../proofs/enterprise_benchmark/GATE_VERDICTS.json`
- `../proofs/red_team/red_team_report.json`
- `../proofs/runbooks/TECHNICAL_RELEASE_SURFACE.md`

<p>
  <img src="../.github/assets/readme/section-bars/evidence-and-claims.svg" alt="EVIDENCE AND CLAIMS" width="100%">
</p>

## Why can package metadata look greener than these docs?

The `0.1.0` package description on PyPI reflects the March 18 release metadata.
The repo docs were updated on March 21 to reflect the later blocker-state
evidence. Until a new package release is intentionally cut, the repo docs are
the current authority for engineering status.

## Is this repo using ZPE-IMC at runtime?

No. IMC is the documentation and release-hygiene reference model for this repo.
It is not a current runtime dependency, and no robotics `.zpbot` Rust ABI is
wired into this package today.

## Are the historical proof bundles still current?

No. They are lineage only. Keep them for provenance, not for current status.

## What real data supports the benchmark story?

The current real-dataset benchmark used `lerobot/columbia_cairlab_pusht_real`
and reported `187.1345x` compression. That result is real, but it is still
bounded because the corpus run used `136` episodes at `10 Hz`, below the
`200` episode / `50 Hz` target.

<p>
  <img src="../.github/assets/readme/section-bars/license-and-ip.svg" alt="LICENSE AND IP" width="100%">
</p>

## Which legal text is authoritative?

`../LICENSE` is the legal source of truth. `LEGAL_BOUNDARIES.md` and the
support docs are routing summaries only.

<p>
  <img src="../.github/assets/readme/section-bars/faq-and-support.svg" alt="FAQ AND SUPPORT" width="100%">
</p>

If your question is not answered here:

- support routing: `SUPPORT.md`
- audit route: `AUDITOR_PLAYBOOK.md`
- release boundary: `../proofs/runbooks/TECHNICAL_RELEASE_SURFACE.md`
