import http
from dataclasses import dataclass

import requests

from .config import Config
from .exceptions import AuthenticationError, RequestConnectionError


@dataclass
class Credentials:
    username: str
    password: str


class AuthManager:
    """
    Encapsulates authentication with the API.

    Handles access token retrieval and automatic insertion into session headers.
    """

    def __init__(self, config: Config, credentials: Credentials, session: requests.Session) -> None:
        self._credentials = credentials
        self._config = config
        self._session = session
        self._token: str | None = None

    def ensure_authentication(self) -> None:
        """
        Check whether authentication has occurred with the API, if not, attempt to authenticate.
        """
        if self._token is None:
            self._authenticate()

    def _authenticate(self) -> None:
        """
        Authenticate with the API.
        """
        try:
            resp = self._session.post(
                url=f"{self._config.base_url}/login",
                json={"username": self._credentials.username, "password": self._credentials.password},
                timeout=self._config.http_timeout_seconds,
            )
        except requests.exceptions.ConnectionError as exc:
            raise RequestConnectionError(self._config.base_url) from exc

        if resp.status_code == http.HTTPStatus.UNAUTHORIZED:
            raise AuthenticationError
        resp.raise_for_status()

        self._token = resp.json()["access_token"]
        self._session.headers.update({"Authorization": f"Bearer {self._token}"})
