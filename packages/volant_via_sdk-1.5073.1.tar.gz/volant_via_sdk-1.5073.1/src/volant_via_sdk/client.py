import http
from typing import BinaryIO

import requests

from volant_via_sdk.exceptions import BadRequestError, RequestConnectionError

from .auth import AuthManager, Credentials
from .config import DEFAULT_CONFIG, Config
from .services import CostDatasetsService


class Client:
    """
    Via SDK Client.
    """

    def __init__(self, credentials: Credentials, config: Config = DEFAULT_CONFIG) -> None:
        self._config = config
        self._session = requests.Session()
        self._auth = AuthManager(config=config, credentials=credentials, session=self._session)

        # Services
        self.cost_datasets = CostDatasetsService(self._make_request)

    def _make_request(
        self,
        method: http.HTTPMethod,
        path: str,
        files: dict[str, tuple[str, BinaryIO | bytes, str]] | None = None,
        data: dict[str, str] | None = None,
    ) -> requests.Response:
        """
        Wrap API requests ensuring authentication and common error scenarios are handled.
        """
        self._auth.ensure_authentication()

        url = f"{self._config.base_url}{path}"
        try:
            resp = self._session.request(
                method=method, url=url, timeout=self._config.http_timeout_seconds, files=files, data=data
            )
        except requests.exceptions.ConnectionError as exc:
            raise RequestConnectionError(url) from exc

        if resp.status_code == http.HTTPStatus.BAD_REQUEST:
            try:
                payload = resp.json()
                error_message = payload["errors"][0]["detail"]
            except Exception:  # noqa: BLE001
                error_message = resp.text

            raise BadRequestError(error_message)

        return resp
