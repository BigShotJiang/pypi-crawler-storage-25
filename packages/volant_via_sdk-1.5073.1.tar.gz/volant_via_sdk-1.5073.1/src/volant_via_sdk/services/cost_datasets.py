import http
import json
from dataclasses import dataclass
from typing import Any, BinaryIO, Protocol
from uuid import UUID

import numpy as np
import numpy.typing as npt
import pyproj
import rasterio  # pyright: ignore[reportMissingTypeStubs]
import rasterio.transform  # pyright: ignore[reportMissingTypeStubs]
import rasterio.warp  # pyright: ignore[reportMissingTypeStubs]

from volant_via_sdk.exceptions import BadRequestError, ResourceNotFoundError


@dataclass
class Georeference:
    """Geospatial reference information in native CRS."""

    crs: pyproj.CRS
    """Projection"""
    shape: tuple[int, int]
    """Shape of expected raster data grids (height, width) defined in cells."""
    affine_transform: rasterio.Affine
    """Conventional Affine Transform to allow conversion from real to cell coordinates."""

    @property
    def height(self) -> int:
        """Height of the underlying raster data."""
        return self.shape[0]

    @property
    def width(self) -> int:
        """Width of the underlying raster data."""
        return self.shape[1]


@dataclass
class PersistedCostDataset:
    id: UUID
    name: str
    chart_id: str
    georeference: Georeference


class _Response(Protocol):
    @property
    def status_code(self) -> int: ...
    def json(self) -> dict[str, Any]: ...


class _RequestFunction(Protocol):
    def __call__(
        self,
        method: http.HTTPMethod,
        path: str,
        files: dict[str, tuple[str, BinaryIO | bytes, str]] | None = None,
        data: dict[str, str] | None = None,
    ) -> _Response: ...


class CostDatasetsService:
    """
    Capabilities associated with Cost Datasets.

    TODO: Extend functionality to temporal cost datasets
    """

    def __init__(self, transport: _RequestFunction) -> None:
        self._make_request = transport

    def get_chart_georeference(self, chart_id: str) -> Georeference:
        """
        Get georeference information for a chart which allows creation of a conformant cost dataset.
        """
        resp = self._make_request(method=http.HTTPMethod.GET, path=f"/charts/{chart_id}")

        if resp.status_code == http.HTTPStatus.NOT_FOUND:
            raise ResourceNotFoundError

        payload = resp.json()
        georeference = payload["data"]["attributes"]["georeference"]

        return Georeference(
            affine_transform=rasterio.transform.Affine.from_gdal(*georeference["affine_transform"]),
            crs=pyproj.CRS(georeference["crs"]),
            shape=tuple(georeference["shape"]),
        )

    def reproject_to_chart[TDataType: np.number](
        self, src_raster: npt.NDArray[TDataType], src_georeference: Georeference, chart_georeference: Georeference
    ) -> npt.NDArray[TDataType]:
        """
        Reproject raster data to match chart georeference information.
        """
        dst_raster = np.full(chart_georeference.shape, 0, dtype=src_raster.dtype)

        rasterio.warp.reproject(  # pyright: ignore[reportUnknownMemberType]
            source=src_raster,
            destination=dst_raster,
            src_transform=src_georeference.affine_transform,
            src_crs=src_georeference.crs,
            dst_transform=chart_georeference.affine_transform,
            dst_crs=chart_georeference.crs,
            resampling=rasterio.warp.Resampling.bilinear,
        )

        return dst_raster

    def create_cost_dataset_from_raster_data(
        self, raster: npt.NDArray[np.float32], georeference: Georeference, name: str, chart_id: str
    ) -> PersistedCostDataset:
        """
        Create a Cost Dataset from raster data.

        Raster data must conform to the georeference for the supplied `chart_id`
        """
        if raster.shape != georeference.shape:
            raise BadRequestError("Raster shape must match georeference shape.")

        if np.any(raster < 0):
            raise BadRequestError("Raster must not contain negative values")

        with rasterio.MemoryFile() as mf:
            with mf.open(  # pyright: ignore[reportUnknownMemberType]
                driver="GTiff",
                height=georeference.height,
                width=georeference.width,
                count=1,  # Only a single band
                dtype=np.float32,
                crs=georeference.crs,
                transform=georeference.affine_transform,
            ) as dataset:  # pyright: ignore[reportUnknownVariableType]
                dataset.write(raster, 1)  # pyright: ignore[reportUnknownMemberType]

            files = {"geotiff": (f"{name}.tif", mf.read(), "image/tiff")}  # pyright: ignore[reportUnknownVariableType, reportUnknownMemberType]
            data = {
                "chart_id": chart_id,
                "name": name,
                "valid_time_ranges": json.dumps([{"start": None, "end": None}]),  # Single band
            }

            resp = self._make_request(method=http.HTTPMethod.POST, path="/cost_datasets/", files=files, data=data)  # pyright: ignore[reportUnknownArgumentType]
            payload = resp.json()

            return PersistedCostDataset(
                id=UUID(payload["data"]["id"]),
                name=payload["data"]["name"],
                chart_id=payload["data"]["attributes"]["chart_id"],
                georeference=Georeference(
                    crs=pyproj.CRS.from_string(payload["data"]["attributes"]["georeference"]["crs"]),
                    shape=tuple(payload["data"]["attributes"]["georeference"]["shape"]),
                    affine_transform=rasterio.Affine.from_gdal(
                        *payload["data"]["attributes"]["georeference"]["affine_transform"]
                    ),
                ),
            )
