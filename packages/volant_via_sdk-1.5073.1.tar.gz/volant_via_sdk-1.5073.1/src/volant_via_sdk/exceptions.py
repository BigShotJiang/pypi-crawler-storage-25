class APIError(Exception):
    """Base class for all API-related errors."""


class ClientError(APIError):
    """4xx errors indicating the client request was invalid."""


class AuthenticationError(ClientError):
    """Invalid credentials."""

    def __init__(self) -> None:
        super().__init__("Invalid credentials")


class ResourceNotFoundError(ClientError):
    """Requested resource was not found."""

    def __init__(self) -> None:
        super().__init__("Resource not found")


class BadRequestError(ClientError):
    """Request failed validation."""


class RequestConnectionError(APIError):
    """Request failed to connect."""

    def __init__(self, url: str) -> None:
        super().__init__(f"Connection failed when calling: {url}")
