from dataclasses import dataclass

DEFAULT_BASE_URL = "https://via.volantautonomy.com/api/v1.0"
HTTP_TIMEOUT_SECONDS = 10


@dataclass
class Config:
    base_url: str = DEFAULT_BASE_URL
    http_timeout_seconds: int = HTTP_TIMEOUT_SECONDS


DEFAULT_CONFIG = Config()
