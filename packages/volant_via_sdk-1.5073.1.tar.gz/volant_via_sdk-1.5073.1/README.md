# Volant Via SDK

SDK and utilities for the Via API

## Installation

Run `pip install volant-via-sdk`

## Basic Usage

```python
import volant_via_sdk

credentials = volant_via_sdk.Credentials(username="username", password="password")
client = volant_via_sdk.Client(credentials=credentials)

chart_georeference = client.cost_datasets.get_chart_georeference("bath")
```

## Further Information

### Auth

An authentication token is automatically retrieved when any request is made with the credentials provided when
instantiating the client, no manual authentication is required.

### Cost Datasets Examples

### From GeoTiff

Creating a Cost Dataset using a DEM. This example will produce a cost field that favours flight in area of low terrain
elevation.

```python
import os

import rasterio

from volant_via_sdk import Client, Credentials
from volant_via_sdk.services.cost_datasets import Georeference

# Open a GeoTiff (Stored locally as "example.tif")
# An example tif could be obtained from services such as OpenTopography:
# https://portal.opentopography.org/API/globaldem?demtype=NASADEM&south=51.33&north=51.42&west=-2.45&east=-2.28&outputFormat=GTiff&API_Key=demoapikeyot2022
with rasterio.open("./example.tif") as src:
    example_raster_data = src.read(1)
    src_georeference = Georeference(crs=src.crs, shape=[src.height, src.width], affine_transform=src.transform)

# Setup the client using credentials
client = Client(credentials=Credentials(username=os.environ["USERNAME"], password=os.environ["PASSWORD"]))

# Get the georeference for the desired chart
chart_georeference = client.cost_datasets.get_chart_georeference("bath")

# Reproject the downloaded raster data to fit the chart bounds and projection
reprojected_example_raster = client.cost_datasets.reproject_to_chart(
    src_raster=example_raster_data, src_georeference=src_georeference, chart_georeference=chart_georeference
)

# Cost Datasets cannot contain any negative values!
reprojected_example_raster[reprojected_example_raster < 0] = 0

# Upload the raster as a Cost Dataset
persisted_cost_dataset = client.cost_datasets.create_cost_dataset_from_raster_data(
    raster=reprojected_example_raster, georeference=chart_georeference, name="Example Cost Dataset", chart_id="bath"
)
```

### From Arbitrary Data

Creating a cost dataset from an arbitrary grid of data.

```python
import os

import numpy as np

from volant_via_sdk import Client, Credentials

# Setup the client using credentials
client = Client(credentials=Credentials(username=os.environ["USERNAME"], password=os.environ["PASSWORD"]))

# Get the georeference for the desired chart
chart_georeference = client.cost_datasets.get_chart_georeference("bath")

# Build a grid of data from the chart's shape (no reprojection required as it will already match)
raster_grid = np.zeros(chart_georeference.shape, dtype=np.float32)
# Create a stripe across the north side and left side. Note that Cost Datasets expect a North-Down representation such
# that (0, 0) is the NW corner.
raster_grid[20:30, :] = 1
raster_grid[:, 20:30] = 2

client.cost_datasets.create_cost_dataset_from_raster_data(
    raster=raster_grid, georeference=chart_georeference, name="Example Cost Dataset", chart_id="bath"
)

```
