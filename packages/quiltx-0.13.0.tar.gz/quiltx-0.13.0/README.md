# quiltx

[![PyPI](https://img.shields.io/pypi/v/quiltx)](https://pypi.org/project/quiltx/)

Quilt extension toolkit for working with [Quilt](https://quiltdata.com) catalogs.

## Quick start

```bash
# See available tools
uvx quiltx

# Sign in to a catalog: mints a qk_... API key from your username/password,
# stores it in your system keyring, and sets it as the default catalog.
uvx quiltx catalog login --catalog open.quiltdata.com --username you@example.com
uvx quiltx catalog default open.quiltdata.com

# Get help for any tool
uvx quiltx <tool> --help
```

`quiltx catalog login` accepts either `--username` / `--password` (admin
catalogs) or `--api-key qk_...` (paste an existing key, or the only path
for SSO-only catalogs — see below). Both DNS names (`open.quiltdata.com`)
and full URLs (`https://open.quiltdata.com/`) are accepted as `--catalog`
arguments and normalized to the bare DNS.

### Tools

- **bucket** — Register cross-account S3 buckets with Quilt (policy, SNS, notifications)
- **catalog** — Manage Quilt catalogs:
  - **catalog login** — Mint and store a `qk_...` API key from username/password (or paste one with `--api-key`)
  - **catalog default** — Read, set, or clear the default catalog (auto-runs `login` when the DNS has no stored key)
  - **catalog list** — List catalogs with stored credentials
  - **catalog forget** — Delete the keyring entry for a catalog
  - **catalog acl** — Declarative access-control-list (ACL) reconciliation from YAML
  - **catalog stack** — Discover the Quilt CloudFormation stack and cache metadata
- **ecs** — ECS task tools:
  - **ecs shell** — Interactive shell access to running ECS tasks via Session Manager
  - **ecs run-migration** — Re-run the registry migration task for a stack
- **logs** — Display and tail CloudWatch logs for the configured catalog

### Python API

See [README_DEV.md](README_DEV.md) for programmatic usage of ECS, ACL, config,
and stack APIs.

### Persistent install (optional)

```bash
uv tool install -U quiltx
# Now use without the uvx prefix:
quiltx --list
```

## Catalog ACL

`quiltx catalog acl` declaratively manages a Quilt stack's access control lists
(ACLs) from a single YAML file with exactly two top-level blocks:
`policies:` and `roles:`. Policy audiences synthesize cumulative managed roles,
while static roles compose named policies and optional inline bucket grants.
Instead of clicking through the catalog admin UI, you define the desired state
in version-controlled YAML and let the tool reconcile it against the server.

### YAML example

```yaml
# Access control lists for a Quilt stack
policies:
  public:
    sso.groups: [Everyone]
    buckets.read: [quilt-example]
    config.default_role: true
  internal:
    sso.groups: [Employees]
    buckets.read_write: [quilt-bake, quilt-dev]
    buckets.read: [quilt-leadership]

roles:
  exec:
    sso.groups: [Executives]
    config.policies: [public, internal]
    buckets.read_write: [quilt-leadership]
    config.is_admin: true
```

Policy order matters. In this example `public` synthesizes the `public` role,
and `internal` synthesizes `internal_public`, which cumulatively includes both
`public` and `internal`. Reordering the policies changes those synthesized role
names and who receives which cumulative grants.

### Usage

```bash
# Show current server ACL state
uvx quiltx catalog acl

# Preview changes (dry run)
uvx quiltx catalog acl config.yml --dry-run

# Preview with full detail
uvx quiltx catalog acl config.yml --dry-run --verbose

# Apply changes (with confirmation prompt)
uvx quiltx catalog acl config.yml

# Apply without prompting
uvx quiltx catalog acl config.yml --yes
```

## SSO-only catalogs

`quiltx catalog login --username --password` only works on catalogs that
accept username/password at `/api/login`. SSO-only catalogs reject U/P with
the catalog's own error (e.g. "SSO is required"). In that case:

1. Open the catalog UI in your browser and mint an API key from the
   account/keys page.
2. Paste it with `--api-key`:

```bash
uvx quiltx catalog login --catalog quilt.example.com --api-key qk_...
```

## Corporate TLS proxies

If catalog requests fail with `CERTIFICATE_VERIFY_FAILED` (common on
networks with TLS-inspection proxies or self-signed catalog certs), point
Python at your organization's CA bundle by exporting one of the standard
environment variables before running quiltx:

```bash
export SSL_CERT_FILE=/path/to/corp-root.pem
# or: export REQUESTS_CA_BUNDLE=/path/to/corp-root.pem

uvx quiltx catalog login --catalog quilt.example.com --username you@example.com
```

## Local catalog testing (`--insecure`)

When developing against a local catalog build, pass `--insecure` to allow
plain `http://localhost`:

```bash
uvx quiltx catalog login --catalog localhost --insecure --username admin
uvx quiltx catalog acl --catalog localhost --insecure config.yml
```

`--insecure` is **only** accepted when the catalog DNS resolves to
`localhost`; any other target is rejected. The flag is never persisted —
it must be passed on every command that hits the catalog.

## ECS

```bash
# Open an interactive shell inside the registry service task
uvx quiltx ecs shell

# Dry-run the registry migration relaunch using cached stack metadata
uvx quiltx ecs run-migration --dry-run

# Start the migration task and wait for completion
uvx quiltx ecs run-migration
```

## License

MIT
