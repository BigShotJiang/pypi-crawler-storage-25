"""
Policy engine client API — upload, validate, and query status.

Uses the shared ``sasy.config`` channel for all connections.
"""

import re
import logging
from pathlib import Path

from sasy.config import get_channel, get_config
from sasy.proto import policy_engine_pb2 as pe
from sasy.proto import policy_engine_pb2_grpc as pe_grpc

logger = logging.getLogger(__name__)


def _metadata() -> list[tuple[str, str]]:
    return get_config().get_metadata()


# ── File helpers ──────────────────────────────────────────

def resolve_includes(path: Path) -> str:
    """Recursively resolve ``#include`` directives to produce a self-contained policy.

    Args:
        path: Path to the root .dl policy file.

    Returns:
        Policy source with all includes inlined.

    Raises:
        FileNotFoundError: If the policy file or an included file doesn't exist.
    """
    if not path.exists():
        raise FileNotFoundError(f"Policy file not found: {path}")

    lines = []
    for line in path.read_text().splitlines():
        stripped = line.strip()
        if stripped.startswith("#include"):
            m = re.search(r'"([^"]+)"', stripped)
            if m:
                inc_path = path.parent / m.group(1)
                lines.append(resolve_includes(inc_path))
            continue
        lines.append(line)
    return "\n".join(lines)


def find_functors(policy_path: Path) -> str:
    """Auto-detect custom C++ functors for a policy file.

    Looks for:
    - ``functors.cpp`` in the same directory
    - ``<name>_functors.cpp`` alongside ``<name>_policy.dl``

    Args:
        policy_path: Path to the policy .dl file.

    Returns:
        Functor source code, or empty string if none found.
    """
    candidates = [
        policy_path.parent / "functors.cpp",
        policy_path.parent / (
            policy_path.stem
            .replace("_policy_souffle", "_functors")
            .replace("_policy", "_functors")
            + ".cpp"
        ),
    ]
    stem = policy_path.stem
    if "_policy" in stem:
        base = stem.split("_policy")[0]
        candidates.append(policy_path.parent / f"{base}_functors.cpp")

    for fp in candidates:
        if fp.exists():
            logger.info("Found functors: %s", fp.name)
            return fp.read_text()
    return ""


# ── gRPC API ─────────────────────────────────────────────

def upload_policy(
    policy_source: str,
    backend: str = "",
    hot_reload: bool = False,
    functor_source: str = "",
    timeout: float = 600,
) -> pe.UploadPolicyResponse:
    """Upload and apply a new policy via gRPC.

    Args:
        policy_source: Soufflé policy source (with optional dot notation sugar).
        backend: Target backend (``"souffle"``, ``"souffle-interpreted"``, ``"ddlog"``).
            Empty string keeps the current backend.
        hot_reload: If True, serve old policy during build and swap when ready.
        functor_source: Optional custom C++ functor source code.
        timeout: gRPC call timeout in seconds.

    Returns:
        UploadPolicyResponse with ``accepted``, ``message``, and ``error_output`` fields.
    """
    stub = pe_grpc.PolicyEngineStub(get_channel())  # type: ignore
    return stub.UploadPolicy(
        pe.UploadPolicyRequest(
            policy_source=policy_source,
            backend=backend,
            hot_reload=hot_reload,
            functor_source=functor_source,
        ),
        metadata=_metadata(),
        timeout=timeout,
    )


def validate_policy(policy_source: str) -> pe.ValidatePolicyResponse:
    """Validate policy source without applying it.

    Args:
        policy_source: Soufflé policy source to validate.

    Returns:
        ValidatePolicyResponse with ``valid``, ``error_output``, and ``desugared_source``.
    """
    stub = pe_grpc.PolicyEngineStub(get_channel())  # type: ignore
    return stub.ValidatePolicy(
        pe.ValidatePolicyRequest(policy_source=policy_source),
        metadata=_metadata(),
    )


def get_evaluator_status() -> pe.EvaluatorStatusResponse:
    """Get the current evaluator backend status.

    Returns:
        EvaluatorStatusResponse with ``backend``, ``alive``, and ``policy_path``.
    """
    stub = pe_grpc.PolicyEngineStub(get_channel())  # type: ignore
    return stub.GetEvaluatorStatus(
        pe.EvaluatorStatusRequest(),
        metadata=_metadata(),
    )


# ── Convenience: upload from file ────────────────────────

def upload_policy_file(
    path: Path,
    backend: str = "",
    hot_reload: bool = False,
    timeout: float = 600,
) -> pe.UploadPolicyResponse:
    """Upload a policy file (resolving includes and auto-detecting functors).

    Args:
        path: Path to the .dl policy file.
        backend: Target backend (empty = keep current).
        hot_reload: Serve old policy during build.
        timeout: gRPC call timeout.

    Returns:
        UploadPolicyResponse.
    """
    policy_source = resolve_includes(path)
    functor_source = find_functors(path)
    return upload_policy(
        policy_source=policy_source,
        backend=backend,
        hot_reload=hot_reload,
        functor_source=functor_source,
        timeout=timeout,
    )
