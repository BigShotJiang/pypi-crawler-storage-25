"""
Shared configuration and gRPC channel management for SASY.

All services (policy engine, reference monitor, credential server,
observability) run on a single SASY binary endpoint. This module
provides the shared URL, TLS, and auth configuration plus a cached
gRPC channel reused across all subsystems.

Environment variables:
    SASY_URL          SASY endpoint (default: sasy.fly.dev:443)
    TLS_CA_PATH       CA certificate for server verification
    TLS_CERT_PATH     Client certificate for mTLS
    TLS_KEY_PATH      Client private key for mTLS

For local development, set ``SASY_URL=localhost:10089`` in ``.env``.
"""

import logging
import threading
from pathlib import Path
from typing import Optional

import grpc
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

from sasy.auth.hooks import AuthHook, NoAuthHook

logger = logging.getLogger(__name__)

_channel_lock = threading.Lock()
_cached_channel: Optional[grpc.Channel] = None


class SasyConfig(BaseSettings):
    """Global SASY configuration.

    Single endpoint for all services, with TLS and auth settings.
    """

    model_config = SettingsConfigDict(
        env_file=".env",
        extra="ignore",
        arbitrary_types_allowed=True,
    )

    url: str = Field(
        default="sasy.fly.dev:443",
        description="SASY binary URL (host:port)",
        alias="SASY_URL",
    )

    # TLS
    ca_path: Optional[str] = Field(default=None, alias="TLS_CA_PATH")
    cert_path: Optional[str] = Field(default=None, alias="TLS_CERT_PATH")
    key_path: Optional[str] = Field(default=None, alias="TLS_KEY_PATH")

    # Auth
    auth_hook: AuthHook = Field(
        default_factory=NoAuthHook,
        description="Auth hook for gRPC metadata (API key, JWT, etc.)",
    )

    def load_ca_cert(self) -> Optional[bytes]:
        if self.ca_path and Path(self.ca_path).exists():
            return Path(self.ca_path).read_bytes()
        return None

    def load_cert(self) -> Optional[bytes]:
        if self.cert_path and Path(self.cert_path).exists():
            return Path(self.cert_path).read_bytes()
        return None

    def load_key(self) -> Optional[bytes]:
        if self.key_path and Path(self.key_path).exists():
            return Path(self.key_path).read_bytes()
        return None

    def create_channel(self) -> grpc.Channel:
        """Create a gRPC channel. Always uses TLS (system CAs if none configured)."""
        ca_cert = self.load_ca_cert()
        client_cert = self.load_cert()
        client_key = self.load_key()

        if client_cert and client_key and ca_cert:
            logger.debug("Creating mTLS channel to %s", self.url)
            credentials = grpc.ssl_channel_credentials(
                root_certificates=ca_cert,
                private_key=client_key,
                certificate_chain=client_cert,
            )
        elif ca_cert:
            logger.debug("Creating TLS channel to %s (custom CA)", self.url)
            credentials = grpc.ssl_channel_credentials(root_certificates=ca_cert)
        else:
            # No certs configured — use system root CAs (works for cloud endpoints)
            logger.debug("Creating TLS channel to %s (system CAs)", self.url)
            credentials = grpc.ssl_channel_credentials()

        return grpc.secure_channel(self.url, credentials)

    def get_metadata(self) -> list[tuple[str, str]]:
        """Get auth metadata for gRPC calls."""
        return self.auth_hook.get_metadata()


# ── Singleton config and channel ──────────────────────────

_config: Optional[SasyConfig] = None


def get_config() -> SasyConfig:
    """Get the global SASY configuration (creates on first call)."""
    global _config
    if _config is None:
        _config = SasyConfig()
    return _config


def get_channel() -> grpc.Channel:
    """Get a shared gRPC channel (creates on first call, thread-safe)."""
    global _cached_channel

    if _cached_channel is not None:
        return _cached_channel

    with _channel_lock:
        if _cached_channel is not None:
            return _cached_channel
        _cached_channel = get_config().create_channel()
        return _cached_channel


_cached_async_channel: Optional[grpc.aio.Channel] = None


def get_async_channel() -> grpc.aio.Channel:
    """Get a shared async gRPC channel (creates on first call)."""
    global _cached_async_channel

    if _cached_async_channel is not None:
        return _cached_async_channel

    cfg = get_config()
    ca = cfg.load_ca_cert()
    cert = cfg.load_cert()
    key = cfg.load_key()

    if cert and key and ca:
        creds = grpc.ssl_channel_credentials(
            root_certificates=ca, private_key=key, certificate_chain=cert,
        )
    elif ca:
        creds = grpc.ssl_channel_credentials(root_certificates=ca)
    else:
        creds = grpc.ssl_channel_credentials()

    _cached_async_channel = grpc.aio.secure_channel(cfg.url, creds)
    return _cached_async_channel


def reset_channel() -> None:
    """Reset cached channels (e.g. after config change)."""
    global _cached_channel, _cached_async_channel
    with _channel_lock:
        _cached_channel = None
        _cached_async_channel = None


def configure(
    url: Optional[str] = None,
    ca_path: Optional[str] = None,
    cert_path: Optional[str] = None,
    key_path: Optional[str] = None,
    auth_hook: Optional[AuthHook] = None,
) -> SasyConfig:
    """Configure the shared SASY connection.

    Args:
        url: SASY binary URL (host:port)
        ca_path: Path to CA certificate for TLS
        cert_path: Path to client certificate for mTLS
        key_path: Path to client private key for mTLS
        auth_hook: Auth hook for gRPC metadata
    """
    cfg = get_config()
    if url is not None:
        cfg.url = url
    if ca_path is not None:
        cfg.ca_path = ca_path
    if cert_path is not None:
        cfg.cert_path = cert_path
    if key_path is not None:
        cfg.key_path = key_path
    if auth_hook is not None:
        cfg.auth_hook = auth_hook
    reset_channel()
    return cfg
