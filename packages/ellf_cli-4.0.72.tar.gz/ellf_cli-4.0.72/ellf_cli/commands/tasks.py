import builtins
import json
from collections.abc import Sequence
from typing import Any, Optional, Union
from uuid import UUID

import httpx
from radicli import Arg
from wasabi import msg

from ellf_pam_sdk.models import TaskDetail, TaskSummary

from ..cli import cli
from ..errors import BrokerError, CLIError, EllfError, HTTPXErrors
from ..messages import Messages
from ..query import delete_job, resolve_recipe, resolve_task, start_job, stop_job
from ..ui import (
    print_args_table,
    print_info_table,
    print_logs,
    print_mutation_result,
    print_recipes_help,
    print_table_with_select,
)
from ._recipe_subcommand import (
    create_from_recipe,
    create_from_recipe_file,
    request_recipes,
)
from ._state import get_auth_state, get_saved_settings


@cli.subcommand_with_extra(
    "tasks",
    "create",
    exists_ok=Arg("--exists-ok", help=Messages.exists_ok),
    no_start=Arg("--no-start", help=Messages.no_start),
    no_wait=Arg("--no-wait", help=Messages.no_wait.format(noun="task")),
    _show_help=Arg("--help", "-h", help=Messages.help),
)
def create(
    exists_ok: bool = False,
    no_start: bool = False,
    no_wait: bool = False,
    _show_help: bool = False,
    _extra: builtins.list[str] = [],
) -> UUID | None:
    """
    Create a new task. The available task recipes are fetched from your
    cluster and are added as dynamic subcommands. You can see more details
    and available arguments by calling the subcommand with --help, e.g. create
    [name] --help
    """
    # TODO: We should just get one recipe here, rather than all of them. That
    # will also save us from having to query for all the objects.
    # Steps here:
    # 1. Parse the CLI string into a recipe plan
    # 2. Create the record in PAM DB
    # 3. Tell the cluster to start the job
    auth = get_auth_state()
    settings = get_saved_settings()
    is_file_mode = settings.recipes_file is not None
    try:
        schemas = request_recipes(auth=auth, is_action=False)
    except EllfError as e:
        raise CLIError(Messages.E009, e)
    except HTTPXErrors as e:
        raise CLIError(Messages.E009, e)
    if not _extra:
        print_recipes_help(schemas, "Create a new task", "tasks create")
        return None
    args = [*_extra]
    name = args.pop(0)
    if name not in schemas:
        opts = f"Available: {', '.join(schemas.keys())}"
        raise CLIError(Messages.E010.format(noun="task", name=name), opts)
    if is_file_mode:
        schema = schemas[name]
        job_spec = create_from_recipe_file(
            schema, args, command="tasks", show_help=_show_help, job_type="task"
        )
        msg.good(Messages.T002.format(noun="task", name=job_spec.name))
        print_args_table(job_spec.plan.args or {}, job_spec.plan.cli_names or {})
        if not no_start:
            response = auth.broker_client.jobs.start_job(job_spec)
            if response.cluster_change is not None:
                msg.good(Messages.T005.format(noun="task", name=job_spec.job_id))
            elif response.cluster_error is not None:
                raise CLIError(
                    Messages.E025.format(noun="task", name=job_spec.job_id),
                    response.cluster_error,
                )
        return job_spec.job_id
    schema = resolve_recipe(name, cluster_id=auth.cluster_id)
    task_id, plan = create_from_recipe(
        schema, args, command="tasks", show_help=_show_help, exists_ok=exists_ok
    )
    msg.good(Messages.T002.format(noun="task", name=task_id))
    print_args_table(plan.args, schema.form_schema.cli_names)
    if not no_start:
        try:
            start(task_id, no_wait=no_wait)
        except Exception:
            auth.client.task.delete(id=task_id)
            raise
    return task_id


@cli.subcommand(
    "tasks",
    "list",
    # fmt: off
    select=Arg(
        "--select",
        help=Messages.select.format(
            opts=[*builtins.list(TaskSummary.model_fields), "state"]
        ),
    ),
    as_json=Arg("--json", help=Messages.as_json),
    # fmt: on
)
def list(
    select: builtins.list[str] = ["id", "name", "state", "project_name"],
    as_json: bool = False,
) -> Sequence[TaskSummary]:
    """
    List the tasks on the cluster. By default, this includes their ID, name
    and current state, e.g. created or completed
    """
    auth = get_auth_state()
    items = builtins.list(auth.client.task.all(page_size=100))
    if "state" in select and items:
        job_ids = [item.id for item in items]
        try:
            statuses = auth.broker_client.jobs.get_batch_status(job_ids).statuses
        except (BrokerError, *HTTPXErrors):
            statuses = {}
        enriched = []
        for item in items:
            d = item.model_dump(include=set(s for s in select if s != "state"))
            status = statuses.get(str(item.id))
            d["state"] = status.state.value if status else "unknown"
            enriched.append(d)
        print_table_with_select(enriched, select=select, as_json=as_json)
    else:
        print_table_with_select(items, select=select, as_json=as_json)
    return items


@cli.subcommand(
    "tasks",
    "info",
    name_or_id=Arg(help=Messages.name_or_id.format(noun="task")),
    project_id=Arg(help=Messages.project_id.format(noun="task")),
    cluster_id=Arg(help=Messages.cluster_id.format(noun="task")),
    select=Arg(
        "--select",
        help=Messages.select.format(opts=builtins.list(TaskDetail.model_fields)),
    ),
    as_json=Arg("--json", help=Messages.as_json),
)
def info(
    name_or_id: Union[str, UUID],
    cluster_id: Optional[UUID] = None,
    project_id: Optional[UUID] = None,
    select: Optional[builtins.list[str]] = None,
    as_json: bool = False,
) -> TaskDetail:
    """Print information about a task on the cluster"""
    auth = get_auth_state()
    res = resolve_task(name_or_id, cluster_id=cluster_id, project_id=project_id)
    try:
        status = auth.broker_client.jobs.get_status(res.id)
        msg.text(f"State: {status.state.value}", icon="info")
    except (BrokerError, *HTTPXErrors):
        pass
    print_info_table(res, exclude=["plan"], as_json=as_json, select=select)
    return res


@cli.subcommand(
    "tasks",
    "logs",
    name_or_id=Arg(help=Messages.name_or_id_optional.format(noun="task")),
    project_id=Arg(help=Messages.project_id.format(noun="task")),
    cluster_id=Arg(help=Messages.cluster_id.format(noun="task")),
    as_json=Arg("--json", help=Messages.as_json),
    show_errors=Arg(
        "--errors", help="Show structured error information instead of full logs"
    ),
    query=Arg("--query", help="Filter log lines matching this text (requires Loki)"),
)
def logs(
    name_or_id: Optional[Union[str, UUID]] = None,
    project_id: Optional[UUID] = None,
    cluster_id: Optional[UUID] = None,
    as_json: bool = False,
    show_errors: bool = False,
    query: Optional[str] = None,
) -> str | None:
    """Get logs for a task on the cluster"""
    job = resolve_task(name_or_id, cluster_id=cluster_id, project_id=project_id)
    auth = get_auth_state()
    if job.last_execution_id is None:
        raise CLIError(Messages.E051.format(noun="task", name=job.name, id=job.id))
    if show_errors:
        try:
            resp = auth.broker_client.jobs.errors(job_id=job.last_execution_id)
        except BrokerError as e:
            raise CLIError(Messages.E011.format(noun="task"), e)
        if as_json:
            print(resp.model_dump_json(indent=2))
        else:
            msg.text(f"State: {resp.state}", icon="info")
            if resp.errors:
                for err in resp.errors:
                    msg.fail(err.message)
                    if err.traceback:
                        print(err.traceback)
                        print()
            elif resp.tail:
                msg.warn("No structured errors found. Last 50 lines:")
                print(resp.tail)
            else:
                msg.good("No errors found")
        return None
    try:
        text = auth.broker_client.jobs.logs(job_id=job.last_execution_id, query=query)
    except BrokerError as e:
        raise CLIError(Messages.E011.format(noun="task"), e)
    print_logs(text, as_json=as_json)
    return text


@cli.subcommand(
    "tasks",
    "start",
    name_or_id=Arg(help=Messages.name_or_id_optional.format(noun="task")),
    project_id=Arg(help=Messages.project_id.format(noun="task")),
    cluster_id=Arg(help=Messages.cluster_id.format(noun="task")),
    worker_class=Arg(
        "--worker-class",
        help=Messages.recipe_worker_class.format(noun="task"),
    ),
    no_wait=Arg("--no-wait", help=Messages.no_wait.format(noun="task")),
    as_json=Arg("--json", help=Messages.as_json),
)
def start(
    name_or_id: Optional[Union[str, UUID]] = None,
    project_id: Optional[UUID] = None,
    cluster_id: Optional[UUID] = None,
    worker_class: Optional[str] = None,
    no_wait: bool = False,
    as_json: bool = False,
) -> UUID:
    """Start a task on the cluster"""
    job = resolve_task(name_or_id, cluster_id=cluster_id, project_id=project_id)
    start_job(
        job,
        worker_class,
        get_auth_state(),
        wait=not no_wait,
        quiet=as_json,
    )
    if as_json:
        print_mutation_result(
            {"id": str(job.id), "status": "started"}, "", as_json=True
        )
    return job.id


@cli.subcommand(
    "tasks",
    "stop",
    name_or_id=Arg(help=Messages.name_or_id_optional.format(noun="task")),
    project_id=Arg(help=Messages.project_id.format(noun="task")),
    cluster_id=Arg(help=Messages.cluster_id.format(noun="task")),
    as_json=Arg("--json", help=Messages.as_json),
)
def stop(
    name_or_id: Optional[Union[str, UUID]] = None,
    project_id: Optional[UUID] = None,
    cluster_id: Optional[UUID] = None,
    as_json: bool = False,
) -> UUID:
    """Stop a task on the cluster"""
    job = resolve_task(name_or_id, cluster_id=cluster_id, project_id=project_id)
    stop_job(job, get_auth_state(), quiet=as_json)
    if as_json:
        print_mutation_result(
            {"id": str(job.id), "status": "stopped"}, "", as_json=True
        )
    return job.id


@cli.subcommand(
    "tasks",
    "delete",
    name_or_id=Arg(help=Messages.name_or_id.format(noun="task")),
    project_id=Arg(help=Messages.project_id.format(noun="task")),
    cluster_id=Arg(help=Messages.cluster_id.format(noun="task")),
    as_json=Arg("--json", help=Messages.as_json),
)
def delete(
    name_or_id: Union[str, UUID],
    project_id: Optional[UUID] = None,
    cluster_id: Optional[UUID] = None,
    as_json: bool = False,
) -> UUID:
    """Delete a task by name or ID"""
    job = resolve_task(name_or_id, cluster_id=cluster_id, project_id=project_id)
    delete_job(job, get_auth_state(), quiet=as_json)
    if as_json:
        print_mutation_result({"id": str(job.id), "deleted": True}, "", as_json=True)
    return job.id


@cli.subcommand(
    "tasks",
    "questions",
    name_or_id=Arg(help=Messages.name_or_id_optional.format(noun="task")),
    project_id=Arg(help=Messages.project_id.format(noun="task")),
    cluster_id=Arg(help=Messages.cluster_id.format(noun="task")),
    as_json=Arg("--json", help=Messages.as_json),
)
def questions(
    name_or_id: Optional[Union[str, UUID]] = None,
    project_id: Optional[UUID] = None,
    cluster_id: Optional[UUID] = None,
    as_json: bool = False,
) -> builtins.list[dict[str, Any]]:
    """Fetch a batch of questions from a running annotation task.

    Mirrors the web app: asks the broker for a Prodigy login token, then talks
    to the task pod directly via its public task_url. Note that requesting a
    batch reserves those questions for this CLI's session — they will not be
    handed to other annotators until they are answered or another session
    runs out of work and steals them.
    """
    job = resolve_task(name_or_id, cluster_id=cluster_id, project_id=project_id)
    auth = get_auth_state()
    try:
        login = auth.broker_client.jobs.prodigy_login(job.id)
    except (BrokerError, *HTTPXErrors) as e:
        raise CLIError(Messages.E058.format(name=job.name), e)
    if not login.task_url:
        raise CLIError(Messages.E058.format(name=job.name))
    task_url = login.task_url.rstrip("/")
    login_path = f"{task_url}/login?login_token={login.login_token}"
    try:
        with httpx.Client(follow_redirects=True, timeout=30.0) as client:
            client.get(login_path).raise_for_status()
            resp = client.post(f"{task_url}/get_session_questions", json={})
            resp.raise_for_status()
            data = resp.json()
    except HTTPXErrors as e:
        raise CLIError(Messages.E059.format(name=job.name), e)
    tasks_out: builtins.list[dict[str, Any]] = data.get("tasks") or []
    if as_json:
        print(json.dumps(tasks_out, default=str))
    else:
        progress = data.get("progress")
        if progress is not None:
            msg.text(f"Progress: {progress:.1%}", icon="info")
        msg.text(f"Fetched {len(tasks_out)} question(s)", icon="info")
        rows = [_question_row(t) for t in tasks_out]
        print_table_with_select(
            rows, select=["_task_hash", "_input_hash", "preview"], as_json=False
        )
    return tasks_out


def _question_row(task: dict[str, Any]) -> dict[str, Any]:
    preview = task.get("text") or task.get("html") or task.get("label") or ""
    if isinstance(preview, str) and len(preview) > 80:
        preview = preview[:77] + "..."
    return {
        "_task_hash": task.get("_task_hash"),
        "_input_hash": task.get("_input_hash"),
        "preview": preview,
    }
