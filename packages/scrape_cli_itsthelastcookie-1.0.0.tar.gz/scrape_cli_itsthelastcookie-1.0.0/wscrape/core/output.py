"""Output serialization for wscrape results (JSON and CSV)."""

from __future__ import annotations

import csv
import io
import json
import logging
from pathlib import Path
from typing import Any

from wscrape.core.parser import PageData
from wscrape.exceptions import OutputError

logger = logging.getLogger("wscrape.output")


def serialise_json(results: list[PageData]) -> str:
    """Serialise results to a JSON string."""
    return json.dumps([r.to_dict() for r in results], indent=2, ensure_ascii=False)


def serialise_csv(results: list[PageData]) -> str:
    """Serialise results to a CSV string.

    The ``links`` field is stored as a semicolon-separated string.
    """
    buf = io.StringIO()
    fieldnames = ["url", "title", "text", "links", "depth"]
    writer = csv.DictWriter(buf, fieldnames=fieldnames, quoting=csv.QUOTE_ALL)
    writer.writeheader()
    for r in results:
        row = r.to_dict()
        row["links"] = ";".join(row["links"])
        writer.writerow(row)
    return buf.getvalue()


def serialise(results: list[PageData], fmt: str = "json") -> str:
    """Serialise *results* to the requested format (``json`` or ``csv``)."""
    if fmt == "json":
        return serialise_json(results)
    if fmt == "csv":
        return serialise_csv(results)
    raise OutputError(f"Unsupported format: {fmt!r}")


def save(content: str, path: str) -> Path:
    """Write *content* to *path* and return the resolved :class:`Path`."""
    try:
        dest = Path(path).resolve()
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(content, encoding="utf-8")
        logger.info("Results saved to %s", dest)
        return dest
    except OSError as exc:
        raise OutputError(f"Cannot write to {path}: {exc}") from exc
