"""BFS web crawler with rate limiting and same-domain restriction."""

from __future__ import annotations

import asyncio
import logging
from collections import deque
from typing import TYPE_CHECKING
from urllib.parse import urldefrag, urlparse

from wscrape.core.fetcher import Fetcher
from wscrape.core.parser import PageData, Parser

if TYPE_CHECKING:
    from wscrape.config import ScrapeConfig

logger = logging.getLogger("wscrape.crawler")


class Crawler:
    """BFS crawler that respects depth limits, rate limits, and same-domain policy."""

    def __init__(self, config: ScrapeConfig) -> None:
        self._config = config
        self._visited: set[str] = set()
        self._results: list[PageData] = []

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def run(self) -> list[PageData]:
        """Execute the crawl and return a list of :class:`PageData` results."""
        start_url = self._normalise(self._config.url)
        allowed_domain = urlparse(start_url).netloc

        queue: deque[tuple[str, int]] = deque()
        queue.append((start_url, 0))

        async with Fetcher(self._config) as fetcher:
            while queue:
                url, depth = queue.popleft()
                canon = self._normalise(url)

                if canon in self._visited:
                    continue
                self._visited.add(canon)

                logger.info("Crawling [depth=%d] %s", depth, canon)

                try:
                    html = await fetcher.fetch(canon)
                except Exception as exc:
                    logger.error("Skipping %s: %s", canon, exc)
                    continue

                page = Parser.parse(html, canon, depth=depth)
                self._results.append(page)

                # Enqueue child links when deep crawling is enabled
                if self._config.deep and depth < self._config.max_depth:
                    for link in page.links:
                        norm_link = self._normalise(link)
                        if norm_link not in self._visited and self._same_domain(norm_link, allowed_domain):
                            queue.append((norm_link, depth + 1))

                # Rate-limit between requests
                if self._config.rate_ms > 0:
                    await asyncio.sleep(self._config.rate_ms / 1000.0)

        logger.info("Crawl complete. %d page(s) scraped.", len(self._results))
        return self._results

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _normalise(url: str) -> str:
        """Strip fragment and trailing slash for deduplication."""
        defragged, _ = urldefrag(url)
        return defragged.rstrip("/")

    @staticmethod
    def _same_domain(url: str, allowed: str) -> bool:
        return urlparse(url).netloc == allowed
