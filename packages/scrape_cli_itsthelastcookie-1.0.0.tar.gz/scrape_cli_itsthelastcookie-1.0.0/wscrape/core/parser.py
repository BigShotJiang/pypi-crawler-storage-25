"""HTML parser that extracts structured data from a page."""

from __future__ import annotations

import logging
import re
from dataclasses import asdict, dataclass, field
from typing import Any
from urllib.parse import urljoin, urlparse

from lxml import html as lxml_html

logger = logging.getLogger("wscrape.parser")


@dataclass
class PageData:
    """Structured representation of a scraped page."""

    url: str
    title: str
    text: str
    links: list[str] = field(default_factory=list)
    depth: int = 0

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


_WHITESPACE_RE = re.compile(r"\s+")


class Parser:
    """Extract title, body text, and links from raw HTML."""

    @staticmethod
    def parse(html: str, url: str, depth: int = 0) -> PageData:
        """Parse *html* and return a :class:`PageData` instance.

        Parameters
        ----------
        html:
            Raw HTML string.
        url:
            The URL the HTML was fetched from (used for resolving relative links).
        depth:
            The crawl depth at which this page was discovered.
        """
        try:
            tree = lxml_html.fromstring(html)
        except Exception as exc:
            from wscrape.exceptions import ParseError

            raise ParseError(url, reason=str(exc)) from exc

        # --- title ---
        title_el = tree.find(".//title")
        title = (title_el.text_content().strip()) if title_el is not None else ""

        # --- text content ---
        # Remove script/style elements before extracting text
        for tag in tree.iter("script", "style", "noscript"):
            tag.drop_tree()
        raw_text = tree.text_content()
        text = _WHITESPACE_RE.sub(" ", raw_text).strip()

        # --- links ---
        links: list[str] = []
        for anchor in tree.iter("a"):
            href = anchor.get("href")
            if href:
                absolute = urljoin(url, href.strip())
                # Only keep http(s) links
                parsed = urlparse(absolute)
                if parsed.scheme in ("http", "https"):
                    links.append(absolute)

        return PageData(url=url, title=title, text=text, links=links, depth=depth)

    @staticmethod
    def css(html: str, selector: str) -> list[str]:
        """Return text content of elements matching a CSS *selector*."""
        from lxml.cssselect import CSSSelector

        tree = lxml_html.fromstring(html)
        sel = CSSSelector(selector)
        return [el.text_content().strip() for el in sel(tree)]

    @staticmethod
    def xpath(html: str, expression: str) -> list[str]:
        """Return text content of elements matching an XPath *expression*."""
        tree = lxml_html.fromstring(html)
        results = tree.xpath(expression)
        out: list[str] = []
        for r in results:
            if isinstance(r, str):
                out.append(r.strip())
            else:
                out.append(r.text_content().strip())
        return out
