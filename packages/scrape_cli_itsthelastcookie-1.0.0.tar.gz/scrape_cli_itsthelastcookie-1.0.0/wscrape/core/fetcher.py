"""Async HTTP fetcher with retries, exponential backoff, and timeout handling."""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING

import httpx

if TYPE_CHECKING:
    from wscrape.config import ScrapeConfig

logger = logging.getLogger("wscrape.fetcher")


class Fetcher:
    """Async HTTP fetcher backed by ``httpx.AsyncClient``."""

    def __init__(self, config: ScrapeConfig) -> None:
        self._config = config
        self._client: httpx.AsyncClient | None = None

    async def __aenter__(self) -> "Fetcher":
        headers = {"User-Agent": self._config.user_agent, **self._config.headers}
        self._client = httpx.AsyncClient(
            headers=headers,
            timeout=httpx.Timeout(self._config.timeout),
            follow_redirects=True,
            verify=self._config.verify_ssl,
        )
        return self

    async def __aexit__(self, *exc: object) -> None:
        if self._client:
            await self._client.aclose()
            self._client = None

    async def fetch(self, url: str) -> str:
        """Fetch *url* and return the response body as text.

        Retries up to ``config.max_retries`` times with exponential backoff.
        Raises :class:`wscrape.exceptions.FetchError` on failure.
        """
        from wscrape.exceptions import FetchError

        assert self._client is not None, "Fetcher must be used as an async context manager"

        last_exc: Exception | None = None
        for attempt in range(1, self._config.max_retries + 1):
            try:
                logger.debug("GET %s (attempt %d/%d)", url, attempt, self._config.max_retries)
                resp = await self._client.get(url)
                resp.raise_for_status()
                return resp.text
            except (httpx.HTTPStatusError, httpx.RequestError, httpx.TimeoutException) as exc:
                last_exc = exc
                wait = 2 ** (attempt - 1)  # 1s, 2s, 4s …
                logger.warning(
                    "Attempt %d for %s failed (%s). Retrying in %ds …",
                    attempt,
                    url,
                    exc,
                    wait,
                )
                await asyncio.sleep(wait)

        raise FetchError(url, reason=str(last_exc))
