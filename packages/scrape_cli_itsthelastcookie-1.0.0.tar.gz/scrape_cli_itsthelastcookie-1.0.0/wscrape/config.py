"""Configuration for wscrape."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class ScrapeConfig:
    """Immutable configuration object for a scrape/crawl session."""

    url: str
    deep: bool = False
    max_depth: int = 1
    rate_ms: int = 200
    save: bool = False
    output: str = "output.json"
    fmt: str = "json"  # "json" | "csv"
    max_retries: int = 3
    timeout: float = 30.0
    user_agent: str = (
        "Mozilla/5.0 (compatible; wscrape/1.0; +https://github.com/wscrape/wscrape)"
    )
    headers: dict[str, str] = field(default_factory=dict)
    verify_ssl: bool = True

    def __post_init__(self) -> None:
        if self.fmt not in ("json", "csv"):
            raise ValueError(f"Unsupported format: {self.fmt!r}. Use 'json' or 'csv'.")
        if self.max_depth < 0:
            raise ValueError("max_depth must be >= 0")
        if self.rate_ms < 0:
            raise ValueError("rate_ms must be >= 0")
