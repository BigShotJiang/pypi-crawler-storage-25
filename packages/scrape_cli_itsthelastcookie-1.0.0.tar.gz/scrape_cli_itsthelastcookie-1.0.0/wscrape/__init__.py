"""
wscrape — fast async web scraper, CLI tool, and AI agent skill.

Usage as a Python library / AI skill::

    from wscrape import run_scraper

    results = run_scraper("https://example.com", deep=True, max_depth=2)
    for page in results:
        print(page["url"], page["title"])

Usage as an async function::

    import asyncio
    from wscrape import async_run_scraper

    results = asyncio.run(async_run_scraper("https://example.com"))
"""

from __future__ import annotations

__version__ = "1.0.0"

import asyncio
from typing import Any

from wscrape.config import ScrapeConfig
from wscrape.core.crawler import Crawler
from wscrape.core.parser import PageData


async def async_run_scraper(
    url: str,
    *,
    deep: bool = False,
    max_depth: int = 1,
    rate: int = 200,
) -> list[dict[str, Any]]:
    """Async entry point for programmatic / AI-agent usage.

    Parameters
    ----------
    url:
        The target URL to scrape.
    deep:
        If ``True``, recursively crawl same-domain links.
    max_depth:
        Maximum crawl depth (only relevant when *deep* is ``True``).
    rate:
        Delay between requests in milliseconds.

    Returns
    -------
    list[dict]:
        A list of dicts, each containing ``url``, ``title``, ``text``,
        ``links``, and ``depth`` keys — ready for AI consumption.
    """
    config = ScrapeConfig(
        url=url,
        deep=deep,
        max_depth=max_depth,
        rate_ms=rate,
    )
    pages: list[PageData] = await Crawler(config).run()
    return [p.to_dict() for p in pages]


def run_scraper(
    url: str,
    *,
    deep: bool = False,
    max_depth: int = 1,
    rate: int = 200,
) -> list[dict[str, Any]]:
    """Synchronous wrapper around :func:`async_run_scraper`.

    This is the recommended entry point for AI agents (Claude, OpenAI, etc.)
    that call tools synchronously.  It returns structured JSON-serialisable data.

    Example::

        from wscrape import run_scraper
        data = run_scraper("https://example.com", deep=True, max_depth=2)
    """
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    if loop and loop.is_running():
        # Already inside an event loop (e.g. Jupyter, some agent runtimes).
        import concurrent.futures

        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            future = pool.submit(
                asyncio.run,
                async_run_scraper(url, deep=deep, max_depth=max_depth, rate=rate),
            )
            return future.result()
    else:
        return asyncio.run(
            async_run_scraper(url, deep=deep, max_depth=max_depth, rate=rate)
        )


__all__ = [
    "__version__",
    "async_run_scraper",
    "run_scraper",
    "ScrapeConfig",
]
