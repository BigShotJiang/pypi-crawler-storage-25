"""Command-line interface for wscrape."""

from __future__ import annotations

import argparse
import asyncio
import logging
import sys

from wscrape.config import ScrapeConfig
from wscrape.core.crawler import Crawler
from wscrape.core.output import save, serialise


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="wscrape",
        description="wscrape — fast async web scraper, CLI tool, and AI agent skill.",
    )
    p.add_argument("url", help="Target URL to scrape")
    p.add_argument(
        "--deep",
        action="store_true",
        default=False,
        help="Recursively crawl links on the same domain",
    )
    p.add_argument(
        "--save",
        action="store_true",
        default=False,
        help="Save output to a file",
    )
    p.add_argument(
        "--output",
        default="output.json",
        help="Output file path (default: output.json)",
    )
    p.add_argument(
        "--format",
        dest="fmt",
        choices=["json", "csv"],
        default="json",
        help="Output format (default: json)",
    )
    p.add_argument(
        "--max-depth",
        type=int,
        default=1,
        help="Maximum recursion depth for --deep (default: 1)",
    )
    p.add_argument(
        "--rate",
        type=int,
        default=200,
        help="Delay between requests in milliseconds (default: 200)",
    )
    p.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        default=False,
        help="Enable verbose/debug logging",
    )
    p.add_argument(
        "--no-verify",
        dest="verify",
        action="store_false",
        default=True,
        help="Disable SSL certificate verification",
    )
    return p


def main(argv: list[str] | None = None) -> None:
    """CLI entry point."""
    parser = _build_parser()
    args = parser.parse_args(argv)

    # Logging
    level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        stream=sys.stderr,
    )

    config = ScrapeConfig(
        url=args.url,
        deep=args.deep,
        max_depth=args.max_depth,
        rate_ms=args.rate,
        save=args.save,
        output=args.output,
        fmt=args.fmt,
        verify_ssl=args.verify,
    )

    results = asyncio.run(Crawler(config).run())
    output = serialise(results, fmt=config.fmt)

    if config.save:
        dest = save(output, config.output)
        print(f"Results saved to {dest}", file=sys.stderr)
    else:
        print(output)


if __name__ == "__main__":
    main()
