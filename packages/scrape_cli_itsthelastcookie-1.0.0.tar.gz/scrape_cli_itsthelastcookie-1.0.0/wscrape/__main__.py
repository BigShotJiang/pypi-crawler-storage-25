"""Allow running wscrape as ``python -m wscrape``."""

from wscrape.cli import main

if __name__ == "__main__":
    main()
