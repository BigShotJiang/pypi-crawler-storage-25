# Copyright 2026 James G Willmore
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Config class for loading YAML configuration files with environment variable substitution."""
from dotenv import load_dotenv
from pyaml_env import parse_config


class Config:
    """Wrapper class for the config.yaml file. It loads the .env file and the config.yaml file and provides methods to access the configuration values."""

    def __init__(self, yaml_path="config.yaml", env_path=".env"):
        """Initialize Config by loading the .env file and YAML configuration.

        :param yaml_path: YAML configuration file. Defaults to 'config.yaml'.
        :type yaml_path: str, optional
        :param env_path: .env file containing environment variables that may be substituted as values in the YAML configuration file. Defaults to '.env'.
        :type env_path: str, optional
        """
        load_dotenv(env_path, verbose=True, override=True)
        self.__config = parse_config(yaml_path)

    def get_config(self):
        """Retrieve the loaded configuration values.

        :returns: configuration values
        :rtype: dict
        """
        return self.__config

    def get_config_key(self, key):
        """Retrieve a specific configuration value. Returns None if the key is not found.

        :param key: the key of the configuration value to retrieve
        :type key: str

        :returns: the value of the configuration key or None if the key is not found
        :rtype: object
        """
        return self.__config[key] if key in self.__config else None
