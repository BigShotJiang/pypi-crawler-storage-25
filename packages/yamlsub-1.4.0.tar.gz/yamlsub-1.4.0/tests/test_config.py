# Copyright 2026 James G Willmore
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Unit tests for the Config class."""
import os

from yamlsub import Config


class TestConfig:
    """Unit tests for the Config class."""

    def test_config(self):
        """Test the Config class."""
        # path valid when running test from top level directory
        env_path = os.path.join(os.getcwd(), "tests", "resources", ".test_env")
        yaml_path = os.path.join(os.getcwd(), "tests", "resources", "test-config.yaml")

        cfg = Config(yaml_path=yaml_path, env_path=env_path)

        assert cfg.get_config() is not None
        empty_key = cfg.get_config_key("empty_key")
        assert empty_key is None
        key2 = cfg.get_config_key("auth_keys")["key2"]
        assert key2 == "env_test_key2"
