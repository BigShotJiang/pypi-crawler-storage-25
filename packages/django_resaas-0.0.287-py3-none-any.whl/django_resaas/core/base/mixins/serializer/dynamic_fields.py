class DynamicFieldsMixin:

    def get_fields(self):
        fields = super().get_fields()

        include = self.context.get("include_fields")
        exclude = self.context.get("exclude_fields", [])

        if isinstance(include, str):
            include = include.split(",")

        if isinstance(exclude, str):
            exclude = exclude.split(",")

        declared = set(self._declared_fields.keys())

        if include:
            valid_fields = set(fields.keys())

            # 🔥 inclui também campos declarados
            include = [f for f in include if f in valid_fields or f in declared]

            fields = {k: v for k, v in fields.items() if k in include}

        for field in exclude:
            fields.pop(field, None)

        return fields