from __future__ import annotations

__all__ = ["__version__"]

__version__ = "0.14.2"
