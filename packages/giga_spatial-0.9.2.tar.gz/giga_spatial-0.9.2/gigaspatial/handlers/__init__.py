from gigaspatial.handlers.boundaries import AdminBoundaries
from gigaspatial.handlers.ghsl import (
    GHSLDataConfig,
    GHSLDataDownloader,
    GHSLDataReader,
    GHSLDataHandler,
)
from gigaspatial.handlers.google_open_buildings import (
    GoogleOpenBuildingsConfig,
    GoogleOpenBuildingsDownloader,
    GoogleOpenBuildingsReader,
    GoogleOpenBuildingsHandler,
)
from gigaspatial.handlers.microsoft_global_buildings import (
    MSBuildingsConfig,
    MSBuildingsDownloader,
    MSBuildingsReader,
    MSBuildingsHandler,
)
from gigaspatial.handlers.google_ms_combined_buildings import (
    GoogleMSBuildingsConfig,
    GoogleMSBuildingsDownloader,
    GoogleMSBuildingsReader,
    GoogleMSBuildingsHandler,
)
from gigaspatial.handlers.osm import OSMLocationFetcher
from gigaspatial.handlers.overture import OvertureAmenityFetcher
from gigaspatial.handlers.mapbox_image import MapboxImageDownloader
from gigaspatial.handlers.maxar_image import MaxarConfig, MaxarImageDownloader
from gigaspatial.handlers.worldpop import (
    WPPopulationConfig,
    WPPopulationReader,
    WPPopulationDownloader,
    WPPopulationHandler,
    WorldPopRestClient,
)
from gigaspatial.handlers.ookla_speedtest import (
    OoklaSpeedtestConfig,
    OoklaSpeedtestDownloader,
    OoklaSpeedtestReader,
    OoklaSpeedtestHandler,
)
from gigaspatial.handlers.opencellid import (
    OpenCellIDConfig,
    OpenCellIDDownloader,
    OpenCellIDReader,
    OpenCellIDHandler,
)
from gigaspatial.handlers.hdx import HDXConfig, HDXDownloader, HDXReader, HDXHandler
from gigaspatial.handlers.rwi import RWIConfig, RWIDownloader, RWIReader, RWIHandler
from gigaspatial.handlers.unicef import (
    UnicefDataFetcher,
    GeoRepoClient,
    get_country_boundaries_by_iso3,
)
from gigaspatial.handlers.giga import (
    GigaSchoolLocationFetcher,
    GigaSchoolProfileFetcher,
    GigaSchoolMeasurementsFetcher,
)
from gigaspatial.handlers.healthsites import HealthSitesFetcher
from gigaspatial.handlers.srtm import (
    NasaSRTMConfig,
    NasaSRTMDownloader,
    NasaSRTMReader,
    NasaSRTMHandler,
    SRTMParser,
    SRTMManager,
)
from gigaspatial.handlers.gee import (
    GEEDatasetEntry,
    GEEDatasetRegistry,
    GEEConfig,
    GEEProfiler,
)
from gigaspatial.handlers.mlab import MLabConfig, MLabHandler
from gigaspatial.handlers.unicef.sdg import UnicefDataFetcher
