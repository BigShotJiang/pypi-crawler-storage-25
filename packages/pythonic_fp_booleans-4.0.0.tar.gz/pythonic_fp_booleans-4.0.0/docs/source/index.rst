pythonic-fp-booleans
====================

Project
`Pythonic FP - Booleans <https://pypi.org/project/pythonic-fp-booleans/>`_
one of the
`Pythonic FP <https://grscheller.github.io/pythonic-fp/>`_
PyPI projects.

|RELEASE_STRING|

.. toctree::
    :caption: Overview
    :hidden:

    self

.. toctree::
    :caption: User Documentation

    description
    usage
    releases
    changelog

.. toctree::
    :caption: API Documentation
    :maxdepth: 1

    api/index
