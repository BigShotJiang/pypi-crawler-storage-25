# SPDX-FileCopyrightText: © 2026 Shaun Wilson
# SPDX-License-Identifier: MIT

__version__ = '0.0.3'
__commit__ = '7ac5fb9'
__all__ = [
    '__version__', '__commit__',
    'authorization',
    'middleware',
    'utils'
]
