# Pascal — Autonomous AI Employee

An autonomous AI agent that works like a real employee: receives tasks, plans, executes, and reports back.

## Getting Started

### Install

```bash
pip install pascal-agent
```

Or with all optional features:
```bash
pip install "pascal-agent[all]"
```

### Run

```bash
pascal
```

That's it. On first run, Pascal auto-detects your LLM provider or walks you through setup.

### Manual setup (optional)

```bash
# Interactive setup
pascal setup

# Or set individually
pascal config set provider openai
pascal config set model gpt-5.4-mini
pascal config
```

**Provider setup:**

| Provider | Auth | How |
|----------|------|-----|
| OpenAI | API key | `export OPENAI_API_KEY=sk-...` |
| Anthropic | API key | `export ANTHROPIC_API_KEY=sk-ant-...` |
| Codex | ChatGPT Pro OAuth | `codex auth login` (free with Pro subscription) |

## Usage

```bash
# Interactive mode (default)
pascal
> Summarize the files in this directory
> Read README.md and explain the architecture
> exit

# One-shot task
pascal "Write a Python script that downloads weather data"

# Set a mission (persistent context)
pascal --mission "You are a data analyst for the marketing team"

# Check current state
pascal --status

# Always-on daemon with Telegram
pascal --daemon

# Resume a paused task
pascal --resume task_abc123
```

## Configuration

### Config file (`~/.pascal/pascal.toml`)

```toml
[pascal]
model = "gpt-5.4-mini"
provider = "openai"           # openai | anthropic | codex
db_path = "~/.pascal/state.db"
max_effect = "E2"             # E0=read E1=analyze E2=write E3=push E4=merge E5=delete
max_tool_rounds = 10          # max tool calls per LLM turn
```

### CLI config commands

```bash
pascal config                          # Show all settings
pascal config set model gpt-5.4-mini   # Set a value
pascal config get provider             # Get a value
```

### Environment variables (override config file)

```bash
PASCAL_MODEL=gpt-5.4-mini
PASCAL_PROVIDER=openai
PASCAL_MAX_EFFECT=E2
```

API keys can be set as environment variables or saved to `~/.pascal/.env` (auto-loaded).

### Optional integrations

**Telegram bot** (`~/.pascal/telegram.json`):
```json
{"bot_token": "123:ABC...", "owner_chat_id": 12345}
```

**MCP tool servers** (`~/.pascal/mcp.json`):
```json
[{"name": "chrome", "command": "npx", "args": ["chrome-devtools-mcp@latest"]}]
```

**Custom skills** (`~/.pascal/skills/my-skill.md`):
```yaml
---
name: my-skill
description: What this skill does
---
Instructions for Pascal when this skill is activated...
```

## How It Works

```
pascal "Do something"
    |
    v
Desk render (state.py + desk.py)
    ->
Prompt + tool schemas (prompt.py + schemas.py)
    ->
LLM picks one action or tool call
    ->
actions.py dispatches built-ins or named MCP tools
    ->
governance.py + effect.py + trust.py gate execution
    ->
tools.py / sandbox.py / mcp.py execute
    ->
state.py + receipts.py persist outcome
    ->
compaction.py trims prompt pressure when needed
    |
    v
Task complete / wait / escalate
```

Plans are declarative: `plan` stores a tree on the active task, and each `plan` call executes one pending leaf before returning the next frontier.

Delegation is mode-aware: one-shot CLI runs delegate inline, while daemon/REPL modes spawn a background child task and use `check_delegate` to collect the result.

Built-in actions cover shell, editor, computer, UIA, code, task management, planning, delegation, reply, and memory/rule updates. Connected MCP tools can also be exposed directly by name.

Safety is layered:
- `effect.py` classifies side effects and applies `compute_threshold()`
- `governance.py` blocks stagnation and repeated bad loops
- `trust.py` scans for injection, credentials, and destructive patterns
- `sandbox.py` and workspace-bounded tools constrain execution
- `receipts.py` writes an append-only JSONL ledger

## Daemon Mode

Always-on operation with Telegram integration:

```bash
# Setup Telegram first
echo '{"bot_token": "YOUR_TOKEN", "owner_chat_id": YOUR_ID}' > ~/.pascal/telegram.json

# Start daemon
pascal --daemon
```

Features:
- Telegram DM for tasks and approvals
- Adaptive heartbeat (5min active, 30min idle)
- Auto-restart on crash
- STOP/PAUSE control (`~/.pascal/STOP` or `~/.pascal/PAUSE` file)

## Development

```bash
git clone https://gitlab.com/laum0621/pascal.git
cd pascal
pip install -e ".[dev]"

# Tests
python -m pytest tests/ --ignore=tests/test_uia_integration.py -q

# Lint
python -m ruff check src/ tests/

# Type check
python -m mypy src/pascal/
```

## Project Structure

```
src/pascal/
  loop.py ........... Main orchestration loop
  actions.py ........ Action dispatch, plan execution, delegate lifecycle
  state.py .......... SQLite state, checkpoints, plans, memories
  desk.py ........... State -> prompt compiler
  tools.py .......... Built-in editor/computer/uia/channel tools
  mcp.py ............ MCP connections, discovery, and tool calls
  governance.py ..... Stagnation and repetition checks
  effect.py ......... Effect classification + compute_threshold()
  compaction.py ..... Token budgeting and session summaries
  sandbox.py ........ Shell/code isolation
  receipts.py ....... Append-only JSONL ledger
  scheduler.py ...... Bounded periodic checks and webhooks
  daemon.py ......... Always-on Telegram runtime
  config.py ......... Config loader and LLM factory
  schemas.py ........ Tool schemas, including named MCP tools
  prompt.py ......... Base system prompt + PASCAL.md loading
  types.py .......... Shared DTOs and plan tree types
  llm/ .............. OpenAI, Anthropic, Codex providers
  channels/ ......... Telegram adapter
  uia.py ............ Windows UI Automation
```

## License

MIT
