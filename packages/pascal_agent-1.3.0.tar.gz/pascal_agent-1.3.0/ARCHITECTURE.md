# Pascal Architecture Reference

## Overview

Pascal is a local autonomous runtime for long-lived task execution. Durable state lives in SQLite. Each turn, Pascal renders a desk from that state, asks the LLM for tool calls, executes one or more actions under governance, records the result, and repeats until it should continue, wait, or escalate.

Pascal is broader than a coding agent:

- The same runtime can operate on shell commands, local files, Windows UI, Telegram notifications, and MCP tools.
- Claude Code and Codex are delegate targets inside Pascal rather than the main runtime.
- CLI, REPL, and daemon modes share the same action layer and safety model.

## Runtime Shape

```text
CLI / REPL / daemon / scheduler
              |
              v
           loop.py
  (desk render, prompt assembly,
   LLM call, governance, record)
              |
              v
         actions.py
 (built-in actions + direct MCP fallback)
        /         |          \
       v          v           v
   tools.py    mcp.py     sandbox.py

actions.py delegates plan logic to plan.py
and delegate logic to delegate.py.
```

Supporting modules:

- `state.py` persists 13 tables: tasks, notifications, rules, run_lock, history, context, todos, memories, conversations, checkpoints, node_executions, task_artifacts, stagnation_log.
- `desk.py` compiles durable state into the model-facing working document.
- `governance.py`, `effect.py`, and `trust.py` gate actions before side effects happen.
- `compaction.py` manages prompt budget pressure and restart thresholds.
- `receipts.py` writes an append-only JSONL ledger beside the SQLite store.

## Core Modules

| Module | Purpose |
| --- | --- |
| `src/pascal/__main__.py` | CLI entrypoints, setup/config commands, one-shot run, resume, and REPL wiring. |
| `src/pascal/actions.py` | Action handlers, verification, and MCP fallback dispatch. Plan and delegate logic extracted into `plan.py` and `delegate.py`. |
| `src/pascal/plan.py` | Plan parsing, validation, and single-leaf execution. Extracted from `actions.py`. |
| `src/pascal/delegate.py` | Delegate handler — spawns Claude Code / Codex CLI subprocesses (sync and async). Extracted from `actions.py`. |
| `src/pascal/loop.py` | Main orchestration loop and tool-call execution. |
| `src/pascal/state.py` | SQLite persistence (13 tables). Includes node_executions (parallel plan execution state), task_artifacts (shift handoff/evidence), and stagnation_log. |
| `src/pascal/desk.py` | State-to-prompt compiler. |
| `src/pascal/schemas.py` | Function schemas for built-in actions and connected MCP tools. |
| `src/pascal/mcp.py` | MCP connection manager, tool discovery, and tool calls. |
| `src/pascal/governance.py` | Stagnation detection and repetition handling. |
| `src/pascal/effect.py` | Effect classification, `max_effect`, and `compute_threshold()`. |
| `src/pascal/compaction.py` | Token estimation, prompt budget checks, and session summaries. |
| `src/pascal/sandbox.py` | Shell/code isolation and safe environment setup. |
| `src/pascal/tools.py` | Built-in editor/computer/UIA/channel tools. |
| `src/pascal/daemon.py` | Always-on runtime with Telegram, scheduler wakeups, and shared loop execution. |
| `src/pascal/scheduler.py` | Bounded periodic checks for overdue work, stale work, routines, and webhooks. |
| `src/pascal/receipts.py` | Append-only JSONL audit ledger. |
| `src/pascal/types.py` | Shared DTOs, plan tree types, and normalized LLM responses. |

## Governance And Safety

Pascal does not trust the model’s self-reported confidence or effect level. Safety is enforced in code:

1. `effect.py` classifies shell commands and tool calls into `E0` through `E5`.
2. `effect.py::compute_threshold()` combines effect level with the recent error streak to decide `go`, `caution`, or `block`.
3. `governance.py` detects repeated actions and stagnation before Pascal loops on the same move.
4. `trust.py` scans action inputs for injection attempts, credentials, and destructive patterns.
5. `sandbox.py` and workspace-bounded tools constrain execution.

Important consequence: higher-effect moves are gated by current runtime conditions, not just by the tool that was chosen.

## Declarative Plans

Plans are stored in `tasks.plan_json` using `TaskPlan` and `PlanNode` from `types.py`.

- A plan is a tree, not a hidden executor state machine.
- Each `plan` call executes exactly one pending leaf.
- Failed leaves keep attempts and error state.
- `patch_node_id` lets the model repair only the broken subtree instead of rebuilding the whole plan.

This keeps the plan visible, resumable, and serializable inside the same task record as the rest of the runtime state.

## Delegation

`delegate` launches Claude Code or Codex as a child task.

- In one-shot CLI mode, delegation runs inline and returns the child result directly.
- In daemon and REPL modes, delegation runs in the background and the parent loop can continue.
- `check_delegate` retrieves the finished background result and clears its stored payload.

The delegate lifecycle is mode-aware because background work only makes sense in long-lived runtimes.

## MCP Integration

Pascal supports MCP in two ways:

- `execute(tool=...)` can call a remote MCP tool.
- `schemas.py` can expose connected MCP tools directly by name, and `actions.py::execute_action()` now dispatches those names without a Pascal wrapper action.

This keeps frequent built-ins first-class while letting external systems plug in naturally.

## Desk And Prompt Model

`desk.py` renders the runtime state into a structured working document. Typical sections include:

- identity
- active task and queue
- todos
- notifications
- rules
- memories and procedures
- plan progress and failed nodes
- recent history
- working context
- repetition warnings

`prompt.py` supplies the base system prompt and loads `PASCAL.md` instructions from:

1. `~/.pascal/PASCAL.md`
2. `<workspace>/PASCAL.md`

Project instructions come second, so they override global instructions when both are present.

## Execution Flow

```text
state.py + desk.py
    -> prompt.py + schemas.py
    -> LLM provider
    -> action/tool call
    -> actions.py dispatch
    -> governance/effect/trust checks
    -> built-in tool, sandbox, or MCP execution
    -> normalized observation + history/ledger write
    -> compaction check
    -> next loop turn
```

`loop.py` also refreshes tool schemas when MCP connectivity changes, so newly connected MCP tools can appear in later turns without restarting the process.

## Runtime Modes

- One-shot CLI: runs until completion, wait, or escalation.
- REPL: persistent loop with wake events from user input.
- Daemon: persistent loop with wake events from Telegram and scheduler signals.

All three share the same action handlers and storage model.

## Configuration

Resolved by `config.py` in this order:

1. CLI overrides
2. Environment variables
3. TOML config (`<cwd>/pascal.toml`, then `~/.pascal/pascal.toml`)
4. `PascalConfig` defaults

Common runtime files under `~/.pascal/`:

- `pascal.toml`
- `.env`
- `PASCAL.md`
- `state.db`
- `telegram.json`
- `mcp.json`
- `audit.jsonl`
- `STOP` / `PAUSE`

Temporary run data lives under `.pascal_tmp` inside the active workspace.

## Key Design Decisions

- Desk-as-prompt instead of raw transcript. The model sees the current working state, not an ever-growing chat log.
- Declarative plans instead of hidden auto-execution. Advancing one leaf per `plan` call keeps failures local and repairable.
- First-class common tools plus direct MCP extension. Core actions stay precise while external systems plug in by name.
- Shared runtime across modes. CLI, REPL, and daemon reuse the same loop and dispatch layer.
- Separate mutable state and append-only ledger. SQLite is optimized for live runtime state; JSONL is optimized for simple audit traces.
- Compaction as a first-class concern. Prompt budget and restart handling live in `compaction.py`, not as scattered ad hoc logic.
