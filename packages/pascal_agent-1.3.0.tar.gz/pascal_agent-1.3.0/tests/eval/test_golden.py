"""Golden eval tests for Pascal — regression gate for all future changes.

Uses MockLLM + real PascalStore. No frameworks beyond pytest.
Each test is a self-contained scenario that exercises a specific capability.
"""

from __future__ import annotations

import json

import pytest

from conftest import MockLLM

from pascal.loop import LoopRunner, run_loop
from pascal.prompt import load_instruction_hierarchy, instruction_file_paths, _INSTRUCTION_FILENAMES
from pascal.state import PascalStore
from pascal.tools import resolve_tool_effect
from pascal.schemas import build_tool_schemas


# ── Helpers ──────────────────────────────────────────────

def _tc(action_name: str, **params) -> str:
    """Shorthand: build action JSON for MockLLM."""
    return json.dumps({"action": action_name, **params})


# ── 1. File create + read ────────────────────────────────

class TestFileOperations:
    async def test_create_and_read_file(self, tmp_path):
        """Write a file via editor, then read it back."""
        store = PascalStore(str(tmp_path / "eval.db"))
        task_id = store.add_task("Create and read a file")

        llm = MockLLM([
            _tc("pick_task", task_id=task_id),
            _tc("editor", op="write", path=str(tmp_path / "hello.txt"), content="Hello Pascal"),
            _tc("editor", op="read", path=str(tmp_path / "hello.txt")),
            _tc("complete_task", summary="File created and verified"),
        ])

        actions = await run_loop(store, llm, max_iterations=10, workspace=str(tmp_path))
        assert any(a["action"] == "complete_task" for a in actions)
        assert (tmp_path / "hello.txt").read_text() == "Hello Pascal"
        store.close()

    async def test_modify_existing_file(self, tmp_path):
        """Overwrite an existing file."""
        (tmp_path / "existing.txt").write_text("old content")
        store = PascalStore(str(tmp_path / "eval.db"))
        task_id = store.add_task("Update existing.txt")

        llm = MockLLM([
            _tc("pick_task", task_id=task_id),
            _tc("editor", op="write", path=str(tmp_path / "existing.txt"), content="new content"),
            _tc("complete_task", summary="Updated"),
        ])

        await run_loop(store, llm, max_iterations=10, workspace=str(tmp_path))
        assert (tmp_path / "existing.txt").read_text() == "new content"
        store.close()

    async def test_list_directory(self, tmp_path):
        """List directory contents via editor."""
        (tmp_path / "a.txt").write_text("a")
        (tmp_path / "b.txt").write_text("b")
        store = PascalStore(str(tmp_path / "eval.db"))
        task_id = store.add_task("List directory")

        llm = MockLLM([
            _tc("pick_task", task_id=task_id),
            _tc("editor", op="list", path=str(tmp_path)),
            _tc("complete_task", summary="Listed files"),
        ])

        actions = await run_loop(store, llm, max_iterations=10, workspace=str(tmp_path))
        assert any(a["action"] == "complete_task" for a in actions)
        store.close()


# ── 2. Shell commands ────────────────────────────────────

class TestShellCommands:
    async def test_shell_echo(self, tmp_path):
        """Run a simple echo command."""
        store = PascalStore(str(tmp_path / "eval.db"))
        task_id = store.add_task("Run echo")

        llm = MockLLM([
            _tc("pick_task", task_id=task_id),
            _tc("shell", command="echo hello"),
            _tc("complete_task", summary="Echo done"),
        ])

        actions = await run_loop(store, llm, max_iterations=10, workspace=str(tmp_path))
        assert any(a["action"] == "shell" for a in actions)
        store.close()

    async def test_shell_chain(self, tmp_path):
        """Two sequential shell commands."""
        store = PascalStore(str(tmp_path / "eval.db"))
        task_id = store.add_task("Create file via shell")

        llm = MockLLM([
            _tc("pick_task", task_id=task_id),
            _tc("shell", command=f"echo content > {tmp_path}/shell_out.txt"),
            _tc("shell", command=f"cat {tmp_path}/shell_out.txt"),
            _tc("complete_task", summary="Shell chain done"),
        ])

        actions = await run_loop(store, llm, max_iterations=10, workspace=str(tmp_path))
        assert sum(1 for a in actions if a["action"] == "shell") == 2
        store.close()


# ── 3. Plan tree ─────────────────────────────────────────

class TestPlanTree:
    async def test_plan_creation(self, tmp_path):
        """Create a plan with steps."""
        store = PascalStore(str(tmp_path / "eval.db"))
        task_id = store.add_task("Multi-step plan")

        plan_tree = {
            "goal": "Setup project",
            "steps": [
                {"id": "s1", "action": "shell", "command": "echo step1", "description": "First step"},
                {"id": "s2", "action": "shell", "command": "echo step2", "description": "Second step"},
            ],
        }

        llm = MockLLM([
            _tc("pick_task", task_id=task_id),
            json.dumps({"action": "plan", "reason": "multi-step work", "plan_tree": plan_tree}),
            _tc("complete_task", summary="Plan executed"),
        ])

        actions = await run_loop(store, llm, max_iterations=10, workspace=str(tmp_path))
        assert any(a["action"] == "plan" for a in actions)
        store.close()


# ── 4. Error recovery ───────────────────────────────────

class TestErrorRecovery:
    async def test_read_nonexistent_then_create(self, tmp_path):
        """Fail to read a missing file, then create it."""
        store = PascalStore(str(tmp_path / "eval.db"))
        task_id = store.add_task("Handle missing file")

        llm = MockLLM([
            _tc("pick_task", task_id=task_id),
            _tc("editor", op="read", path=str(tmp_path / "missing.txt")),
            _tc("editor", op="write", path=str(tmp_path / "missing.txt"), content="created"),
            _tc("complete_task", summary="File created after initial miss"),
        ])

        await run_loop(store, llm, max_iterations=10, workspace=str(tmp_path))
        assert (tmp_path / "missing.txt").read_text() == "created"
        store.close()


# ── 5. Multi-step composite ─────────────────────────────

class TestComposite:
    async def test_task_create_and_complete(self, tmp_path):
        """Create a subtask, do work, complete both."""
        store = PascalStore(str(tmp_path / "eval.db"))
        task_id = store.add_task("Main task")

        llm = MockLLM([
            _tc("pick_task", task_id=task_id),
            _tc("create_subtask", subtask_goal="Write config file"),
            _tc("editor", op="write", path=str(tmp_path / "config.json"),
                content='{"key": "value"}'),
            _tc("complete_task", summary="Config written"),
        ])

        actions = await run_loop(store, llm, max_iterations=10, workspace=str(tmp_path))
        assert any(a["action"] == "create_subtask" for a in actions)
        assert (tmp_path / "config.json").exists()
        store.close()

    async def test_memorize_and_continue(self, tmp_path):
        """Memorize a fact, then continue with work."""
        store = PascalStore(str(tmp_path / "eval.db"))
        task_id = store.add_task("Learn and do")

        llm = MockLLM([
            _tc("pick_task", task_id=task_id),
            _tc("memorize", memory_kind="fact", memory_content="Project uses Python 3.12"),
            _tc("editor", op="write", path=str(tmp_path / "note.txt"), content="noted"),
            _tc("complete_task", summary="Done"),
        ])

        actions = await run_loop(store, llm, max_iterations=10, workspace=str(tmp_path))
        assert any(a["action"] == "memorize" for a in actions)
        store.close()


# ── 6. Effect levels (v1.2 validation) ──────────────────

class TestEffectLevels:
    def test_computer_click_is_e2(self):
        """v1.2: computer click/type/hotkey should be E2."""
        assert resolve_tool_effect("computer", {"op": "click"}) == "E2"
        assert resolve_tool_effect("computer", {"op": "type"}) == "E2"
        assert resolve_tool_effect("computer", {"op": "hotkey"}) == "E2"

    def test_computer_scroll_is_e1(self):
        """Scroll stays at E1."""
        assert resolve_tool_effect("computer", {"op": "scroll"}) == "E1"

    def test_computer_screenshot_is_e0(self):
        """Screenshot is read-only."""
        assert resolve_tool_effect("computer", {"op": "screenshot"}) == "E0"

    def test_uia_not_in_public_tools(self):
        """v1.2: UIA should not appear in public tool schemas."""
        tools = build_tool_schemas(mode="cli")
        names = {t["function"]["name"] for t in tools}
        assert "uia" not in names


# ── 7. System prompt caching ────────────────────────────

class TestSystemPromptCache:
    def test_cache_initialized(self, tmp_path):
        """System prompt cache should be populated at init."""
        store = PascalStore(str(tmp_path / "eval.db"))
        runner = LoopRunner(store, MockLLM([]), workspace=str(tmp_path))
        assert "cli" in runner._system_prompt_cache
        assert "daemon" in runner._system_prompt_cache
        assert not runner._sp_dirty
        store.close()

    def test_invalidation_sets_dirty(self, tmp_path):
        """_invalidate_system_prompt should set dirty flag."""
        store = PascalStore(str(tmp_path / "eval.db"))
        runner = LoopRunner(store, MockLLM([]), workspace=str(tmp_path))
        runner._invalidate_system_prompt()
        assert runner._sp_dirty
        store.close()


# ── 8. microCompact ──────────────────────────────────────

class TestMicroCompact:
    def test_clears_old_tool_results(self):
        """microCompact should replace old tool results with placeholder."""
        from pascal.types import Message, Role
        messages = [
            Message(role=Role.SYSTEM, content="system"),
        ]
        for i in range(10):
            messages.append(Message(role=Role.TOOL, tool_call_id=f"tc_{i}",
                                    content="x" * 500))

        LoopRunner._micro_compact(messages, keep_recent=3)

        tool_msgs = [m for m in messages if m.role == Role.TOOL]
        cleared = [m for m in tool_msgs if m.content.startswith("[cleared:")]
        kept = [m for m in tool_msgs if not m.content.startswith("[cleared:")]
        assert len(cleared) == 7
        assert len(kept) == 3

    def test_preserves_short_results(self):
        """Short tool results should not be cleared."""
        from pascal.types import Message, Role
        messages = [
            Message(role=Role.TOOL, tool_call_id="tc_0", content="ok"),
            Message(role=Role.TOOL, tool_call_id="tc_1", content="ok"),
        ]
        LoopRunner._micro_compact(messages, keep_recent=1)
        assert messages[0].content == "ok"  # short, not cleared
        assert messages[1].content == "ok"  # kept as recent


# ── 9. Instruction Chain (v1.3) ─────────────────────────

class TestInstructionChain:
    def test_instruction_filenames(self):
        """v1.3: Three instruction file types in priority order."""
        assert _INSTRUCTION_FILENAMES == ("PASCAL.md", "AGENTS.md", "CLAUDE.md")

    def test_instruction_file_paths_global_only(self):
        """Without workspace, only global paths returned."""
        paths = instruction_file_paths()
        names = [p.name for p in paths]
        assert names == ["PASCAL.md", "AGENTS.md", "CLAUDE.md"]

    def test_instruction_file_paths_with_workspace(self, tmp_path):
        """With workspace, both global and project paths returned."""
        paths = instruction_file_paths(str(tmp_path))
        names = [p.name for p in paths]
        # 3 global + 3 project = 6
        assert len(names) == 6
        assert names == ["PASCAL.md", "AGENTS.md", "CLAUDE.md",
                         "PASCAL.md", "AGENTS.md", "CLAUDE.md"]

    @pytest.fixture(autouse=True)
    def _isolate_home(self, tmp_path, monkeypatch):
        """Isolate all instruction chain tests from real ~/.pascal/ files."""
        fakehome = tmp_path / "fakehome"
        fakehome.mkdir()
        (fakehome / ".pascal").mkdir()
        from pathlib import Path
        monkeypatch.setattr(Path, "home", classmethod(lambda cls: fakehome))

    def test_load_empty(self, tmp_path):
        """No instruction files → empty string."""
        result = load_instruction_hierarchy(str(tmp_path))
        assert result == ""

    def test_load_pascal_md_only(self, tmp_path):
        """Single PASCAL.md in workspace."""
        (tmp_path / "PASCAL.md").write_text("Project rules here")
        result = load_instruction_hierarchy(str(tmp_path))
        assert "Project rules here" in result
        assert "Project Instructions (PASCAL.md)" in result

    def test_load_agents_md(self, tmp_path):
        """AGENTS.md in workspace (Codex compat)."""
        (tmp_path / "AGENTS.md").write_text("Codex rules")
        result = load_instruction_hierarchy(str(tmp_path))
        assert "Codex rules" in result
        assert "AGENTS.md" in result

    def test_load_claude_md(self, tmp_path):
        """CLAUDE.md in workspace (Claude Code compat)."""
        (tmp_path / "CLAUDE.md").write_text("Claude Code rules")
        result = load_instruction_hierarchy(str(tmp_path))
        assert "Claude Code rules" in result
        assert "CLAUDE.md" in result

    def test_priority_order(self, tmp_path):
        """All three files: PASCAL.md listed first, CLAUDE.md last (higher attention)."""
        (tmp_path / "PASCAL.md").write_text("pascal rules")
        (tmp_path / "AGENTS.md").write_text("agents rules")
        (tmp_path / "CLAUDE.md").write_text("claude rules")
        result = load_instruction_hierarchy(str(tmp_path))
        # Later = higher priority in LLM attention
        pascal_pos = result.index("pascal rules")
        agents_pos = result.index("agents rules")
        claude_pos = result.index("claude rules")
        assert pascal_pos < agents_pos < claude_pos

    def test_global_before_project(self, tmp_path):
        """Global instructions loaded before project (project has higher priority)."""
        # _isolate_home fixture already set Path.home() → tmp_path/fakehome
        global_dir = tmp_path / "fakehome" / ".pascal"
        (global_dir / "PASCAL.md").write_text("GLOBAL_MARKER")
        project_dir = tmp_path / "project"
        project_dir.mkdir()
        (project_dir / "PASCAL.md").write_text("PROJECT_MARKER")

        result = load_instruction_hierarchy(str(project_dir))
        assert "GLOBAL_MARKER" in result
        assert "PROJECT_MARKER" in result
        assert result.index("GLOBAL_MARKER") < result.index("PROJECT_MARKER")
        assert "Global Instructions (PASCAL.md)" in result
        assert "Project Instructions (PASCAL.md)" in result

    def test_whitespace_only_file_excluded(self, tmp_path):
        """Whitespace-only instruction files should not appear in output."""
        (tmp_path / "PASCAL.md").write_text("   \n  \t  ")
        result = load_instruction_hierarchy(str(tmp_path))
        assert result == ""

    def test_mtime_tracking_covers_all_files(self, tmp_path):
        """v1.3: mtime tracking should cover all 6 instruction files."""
        store = PascalStore(str(tmp_path / "eval.db"))
        runner = LoopRunner(store, MockLLM([]), workspace=str(tmp_path))
        mtimes = runner._instruction_mtimes
        # Should have entries for all instruction file paths
        assert len(mtimes) == 6  # 3 global + 3 project
        store.close()

    def test_mtime_dirty_on_new_file(self, tmp_path):
        """Creating an instruction file should trigger dirty flag."""
        store = PascalStore(str(tmp_path / "eval.db"))
        runner = LoopRunner(store, MockLLM([]), workspace=str(tmp_path))
        assert not runner._sp_dirty

        # Create a new instruction file
        (tmp_path / "PASCAL.md").write_text("new rules")

        # Snapshot should differ now
        new_mtimes = runner._snapshot_instruction_mtimes()
        assert new_mtimes != runner._instruction_mtimes
        store.close()


# ── 10. Skill prompt patch (v1.4a) ──────────────────────

class TestSkillPromptPatch:
    def test_skill_in_schema(self):
        """v1.4a: skill should appear in tool schemas."""
        tools = build_tool_schemas(mode="cli")
        names = {t["function"]["name"] for t in tools}
        assert "skill" in names

    def test_skill_schema_params(self):
        """Skill schema should have name (required) and args (optional)."""
        tools = build_tool_schemas(mode="cli")
        skill_tool = next(t for t in tools if t["function"]["name"] == "skill")
        params = skill_tool["function"]["parameters"]
        assert "name" in params["properties"]
        assert "name" in params["required"]

    def test_parse_frontmatter(self):
        """Parse YAML-like frontmatter from skill content."""
        from pascal.tools import _parse_skill_frontmatter
        content = """---
name: code-review
description: Review code changes
allowed_tools: [editor, shell, plan]
context: inline
---

Review the code carefully.
"""
        fm, body = _parse_skill_frontmatter(content)
        assert fm["name"] == "code-review"
        assert fm["description"] == "Review code changes"
        assert fm["allowed_tools"] == ["editor", "shell", "plan"]
        assert fm["context"] == "inline"
        assert "Review the code carefully." in body

    def test_parse_frontmatter_when_to_use(self):
        """when_to_use field is parsed from frontmatter."""
        from pascal.tools import _parse_skill_frontmatter
        content = "---\nname: test\nwhen_to_use: When reviewing PRs\n---\nBody"
        fm, body = _parse_skill_frontmatter(content)
        assert fm["when_to_use"] == "When reviewing PRs"

    def test_parse_frontmatter_no_yaml(self):
        """Content without frontmatter returns empty dict."""
        from pascal.tools import _parse_skill_frontmatter
        fm, body = _parse_skill_frontmatter("Just plain text")
        assert fm == {}
        assert body == "Just plain text"

    def test_scan_skills_dir(self, tmp_path):
        """scan_skills_dir reads only frontmatter for token estimation."""
        from pascal.tools import scan_skills_dir
        from pathlib import Path
        fakehome = tmp_path / "fakehome"
        skills_dir = fakehome / ".pascal" / "skills"
        skills_dir.mkdir(parents=True)
        (skills_dir / "review.md").write_text(
            "---\nname: review\ndescription: Code review\n"
            "when_to_use: When reviewing PRs\nallowed_tools: [editor, shell]\n---\n"
            "Long body content that should not be loaded during scan " * 100
        )
        original_home = Path.home
        Path.home = classmethod(lambda cls: fakehome)
        try:
            results = scan_skills_dir()
            assert len(results) == 1
            assert results[0]["name"] == "review"
            assert results[0]["when_to_use"] == "When reviewing PRs"
            assert results[0]["estimated_tokens"] > 0
            assert results[0]["allowed_tools"] == ["editor", "shell"]
        finally:
            Path.home = original_home

    async def test_skill_load_and_inject(self, tmp_path):
        """Full flow: LLM calls skill, body injected as transient message."""
        skills_dir = tmp_path / "fakehome" / ".pascal" / "skills"
        skills_dir.mkdir(parents=True)
        (skills_dir / "test-skill.md").write_text("""---
name: test-skill
description: A test skill
context: inline
---

You are now in test mode. Follow these instructions carefully.
""")
        # Monkeypatch Path.home
        from pathlib import Path
        original_home = Path.home
        Path.home = classmethod(lambda cls: tmp_path / "fakehome")

        try:
            store = PascalStore(str(tmp_path / "eval.db"))
            task_id = store.add_task("Use a skill")

            llm = MockLLM([
                _tc("pick_task", task_id=task_id),
                _tc("skill", name="test-skill"),
                _tc("complete_task", summary="Skill used"),
            ])

            actions = await run_loop(store, llm, max_iterations=10, workspace=str(tmp_path))
            assert any(a["action"] == "skill" for a in actions)
            # Active skill cleared on task completion (v1.4a deactivation)
            active = store.get_context("active_skill")
            assert active is None  # cleared by complete_task
            store.close()
        finally:
            Path.home = original_home

    async def test_skill_not_found(self, tmp_path):
        """Calling a nonexistent skill should return error."""
        from pascal.tools import skill as skill_fn
        result = await skill_fn({"name": "nonexistent-skill"})
        assert result["ok"] is False
        assert "not found" in result["error"]

    def test_allowlist_filters_tools(self):
        """v1.4b: allowlist restricts tool schemas to specified set."""
        tools_full = build_tool_schemas(mode="cli")
        tools_restricted = build_tool_schemas(mode="cli", allowlist=["editor", "shell"])
        full_names = {t["function"]["name"] for t in tools_full}
        restricted_names = {t["function"]["name"] for t in tools_restricted}
        # Restricted should have editor, shell + always-allowed (think, skill, complete_task, fail_task, escalate)
        assert "editor" in restricted_names
        assert "shell" in restricted_names
        assert "think" in restricted_names  # always allowed
        assert "skill" in restricted_names  # always allowed
        assert "computer" not in restricted_names  # filtered out
        assert "code" not in restricted_names  # filtered out
        assert len(restricted_names) < len(full_names)

    def test_skill_effect_level(self):
        """Skill should be E0 (read-only)."""
        from pascal.tools import resolve_tool_effect
        assert resolve_tool_effect("skill") == "E0"

    def test_paths_in_desk(self, tmp_path):
        """v1.4c: desk should show Related paths from active skill."""
        from pascal.desk import Desk
        store = PascalStore(str(tmp_path / "eval.db"))
        store.set_context("active_skill", {
            "name": "frontend",
            "description": "Frontend work",
            "paths": ["src/components/**", "src/pages/**"],
        })
        desk = Desk(store)
        rendered = desk.render()
        assert "Related paths" in rendered
        assert "src/components/**" in rendered
        store.close()

    def test_plan_mode_restricts_tools(self, tmp_path):
        """v1.6: plan mode should restrict to read-only tools."""
        store = PascalStore(str(tmp_path / "eval.db"))
        task_id = store.add_task("Plan something")
        store.activate_task(task_id)
        store.set_context(f"task_mode:{task_id}", "plan")
        runner = LoopRunner(store, MockLLM([]), workspace=str(tmp_path))
        runner._refresh_tool_preset()
        mode = runner.state.cached_mode or "cli"
        tools = runner._tool_schemas_cache[mode]
        names = {t["function"]["name"] for t in tools}
        # Plan mode: think, plan, skill, editor(read), shell(read) + terminal actions
        assert "think" in names
        assert "plan" in names
        assert "skill" in names
        assert "editor" in names  # read/list allowed for planning
        assert "shell" in names   # read-only commands allowed for planning
        assert "computer" not in names  # desktop interaction blocked in plan mode
        assert "code" not in names      # execution blocked in plan mode
        store.close()

    def test_delegate_hidden_from_llm(self):
        """v1.5: delegate hidden from schema, blocked at loop dispatch level."""
        from pascal.loop import _HIDDEN_FROM_LLM
        assert "delegate" in _HIDDEN_FROM_LLM
        assert "check_delegate" in _HIDDEN_FROM_LLM
        # But still in ACTION_HANDLERS for internal use
        from pascal.actions import ACTION_HANDLERS
        assert "delegate" in ACTION_HANDLERS

    def test_desk_shows_active_skill(self, tmp_path):
        """Desk should display active skill section."""
        from pascal.desk import Desk
        store = PascalStore(str(tmp_path / "eval.db"))
        store.set_context("active_skill", {
            "name": "code-review",
            "description": "Review code changes",
            "allowed_tools": ["editor", "shell"],
        })
        desk = Desk(store)
        rendered = desk.render()
        assert "Active Skill" in rendered
        assert "code-review" in rendered
        assert "editor, shell" in rendered
        store.close()
