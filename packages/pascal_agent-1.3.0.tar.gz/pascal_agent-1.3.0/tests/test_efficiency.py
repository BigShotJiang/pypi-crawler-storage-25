"""Efficiency-focused regressions: fewer prompt tokens, fewer wasted turns."""

from __future__ import annotations

import json

from conftest import MockLLM, j

from pascal.desk import Desk
from pascal.loop import run_loop
from pascal.state import PascalStore
from pascal.types import LLMResponse, Role, ToolCall


class TestDeskEfficiency:
    def test_working_memory_is_summarized_not_raw_json(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        store.set_context("mission", "Keep prompts small")
        store.set_context("identity", {"name": "Pascal", "tag": "UNIQUE_IDENTITY_TOKEN"})
        for i in range(10):
            store.set_context(f"ctx_{i}", {"value": f"payload_{i}", "nested": ["x", "y", "z"]})

        rendered = Desk(store).render()

        assert "```json" not in rendered
        assert rendered.count("UNIQUE_IDENTITY_TOKEN") == 1
        assert "## Working Memory" in rendered
        assert "... 2 more context keys hidden" in rendered
        store.close()


class TestLoopEfficiency:
    async def test_single_task_auto_pick_and_auto_idle_save_llm_calls(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        target = tmp_path / "hello.txt"
        store.add_task("Write hello.txt")

        llm = MockLLM([
            json.dumps({
                "action": "execute",
                "tool": "editor",
                "tool_params": {"op": "write", "path": str(target), "content": "hello"},
                "reason": "write the file",
            }),
            j(action="complete_task", summary="Created hello.txt", reason="done"),
        ])

        actions = await run_loop(store, llm, max_iterations=10, workspace=str(tmp_path))

        assert llm.call_count == 2
        assert [a["action"] for a in actions] == ["execute", "complete_task", "wait"]
        assert actions[-1]["result"]["auto"] is True
        assert target.read_text() == "hello"
        procedures = store.get_memories(kind="procedure")
        assert any("Created hello.txt" in p["content"] for p in procedures)
        store.close()

    async def test_failed_command_feedback_names_the_bad_command(self, tmp_path):
        """In the tool-use loop, failed command results are sent back as TOOL
        messages containing the error status.  Verify the LLM sees the error."""
        store = PascalStore(str(tmp_path / "t.db"))
        store.add_task("Inspect a file")
        captured_tool_contents: list[str] = []

        class CaptureLLM:
            def __init__(self):
                self._responses = [
                    [ToolCall(id="tc_1", name="execute", params={"command": "bad command", "reason": "try shell first"})],
                    [ToolCall(id="tc_2", name="wait", params={"reason": "done"})],
                ]
                self._index = 0

            async def chat(self, messages, tools=None):
                for msg in messages:
                    if msg.role == Role.TOOL:
                        captured_tool_contents.append(msg.content)
                if self._index >= len(self._responses):
                    return LLMResponse(tool_calls=[ToolCall(id="tc_end", name="wait", params={"reason": "done"})])
                resp = self._responses[self._index]
                self._index += 1
                return LLMResponse(tool_calls=resp)

        await run_loop(
            store,
            CaptureLLM(),
            max_iterations=5,
            execute_command=lambda _cmd: None,
        )

        # The execute result should be sent as a TOOL message with error status
        assert len(captured_tool_contents) >= 1
        error_msg = captured_tool_contents[0]
        assert "error" in error_msg.lower()
        store.close()
