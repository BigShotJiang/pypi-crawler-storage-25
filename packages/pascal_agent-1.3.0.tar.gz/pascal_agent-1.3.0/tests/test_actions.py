from __future__ import annotations

from pascal.actions import ACTION_HANDLERS, VALID_ACTIONS, execute_action
from pascal.schemas import build_tool_schemas
from pascal.state import PascalStore
from pascal.tools import set_workspace


class TestFirstClassActionHandlers:
    async def test_first_class_editor_action_writes_file(self, tmp_path):
        set_workspace(str(tmp_path))
        store = PascalStore(str(tmp_path / "t.db"))
        target = tmp_path / "written.txt"

        result = await execute_action(
            store,
            {"op": "write", "path": str(target), "content": "hello"},
            "editor",
            max_effect="E2",
        )

        assert result["status"] == "ok"
        assert result["tool"] == "editor"
        assert target.read_text() == "hello"
        store.close()

    async def test_first_class_shell_action_uses_execute_command(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))

        result = await execute_action(
            store,
            {"command": "echo hello"},
            "shell",
            max_effect="E0",
            execute_command=lambda command: f"ran:{command}",
        )

        assert result == {"output": "ran:echo hello", "status": "ok"}
        store.close()

    async def test_legacy_execute_editor_shim_still_routes_to_editor(self, tmp_path):
        set_workspace(str(tmp_path))
        store = PascalStore(str(tmp_path / "t.db"))
        target = tmp_path / "shim.txt"

        result = await execute_action(
            store,
            {
                "tool": "editor",
                "tool_params": {"op": "write", "path": str(target), "content": "shimmed"},
            },
            "execute",
            max_effect="E2",
        )

        assert result["status"] == "ok"
        assert result["tool"] == "editor"
        assert target.read_text() == "shimmed"
        store.close()

    async def test_unknown_action_name_falls_back_to_mcp_tool(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))

        class _FakeMCPManager:
            def has_tool(self, name: str) -> bool:
                return name == "slack_post"

            async def call_tool(self, name: str, params: dict[str, str]) -> dict[str, str]:
                assert name == "slack_post"
                assert params == {"channel": "#ops", "text": "ship it"}
                return {"ok": True, "output": "posted", "error": ""}

        result = await execute_action(
            store,
            {"channel": "#ops", "text": "ship it"},
            "slack_post",
            mcp_manager=_FakeMCPManager(),
        )

        assert result["status"] == "ok"
        assert result["tool"] == "slack_post"
        assert result["output"] == "posted"
        store.close()

    def test_action_registry_exposes_first_class_tools_and_removes_handle_notification(self):
        for action in ("shell", "editor", "computer", "uia", "code", "channel_reply", "execute", "check_delegate"):
            assert action in ACTION_HANDLERS
            assert action in VALID_ACTIONS
        assert "handle_notification" not in ACTION_HANDLERS
        assert "handle_notification" not in VALID_ACTIONS

    def test_delegate_hidden_from_public_schemas(self):
        """v1.5: delegate/check_delegate hidden from public surface."""
        tool_names = {tool["function"]["name"] for tool in build_tool_schemas(mode="cli")}
        assert "delegate" not in tool_names
        assert "check_delegate" not in tool_names
