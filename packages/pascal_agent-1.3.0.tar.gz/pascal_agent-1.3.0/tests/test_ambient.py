"""Tests for ambient companion: identity, procedures, create_task."""
from __future__ import annotations


from conftest import MockLLM, j
from pascal.desk import Desk
from pascal.loop import run_loop
from pascal.state import PascalStore


class TestIdentityOnDesk:
    def test_identity_rendered(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        store.set_context("identity", {
            "name": "Pascal",
            "personality": "calm and practical",
        })
        desk = Desk(store)
        rendered = desk.render()
        assert "## Identity" in rendered
        assert "Pascal" in rendered
        assert "calm and practical" in rendered
        store.close()

    def test_identity_protected_from_truncation(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        store.set_context("identity", {"name": "Pascal"})
        for i in range(20):
            store.add_memory(kind="fact", content=f"Filler memory number {i} " * 20)
        desk = Desk(store)
        rendered = desk.render()
        assert "## Identity" in rendered
        store.close()

    def test_no_identity_no_section(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        desk = Desk(store)
        rendered = desk.render()
        assert "## Identity" not in rendered
        store.close()


class TestProceduresOnDesk:
    def test_procedure_shown_separately(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        store.add_task("Check email")
        store.activate_task(store.get_pending_tasks()[0]["id"])
        store.add_memory(kind="procedure", content='{"name": "check email", "steps": ["open mail", "read inbox"]}')
        store.add_memory(kind="fact", content="Sky is blue")
        desk = Desk(store)
        rendered = desk.render()
        assert "## Known Procedures" in rendered
        assert "check email" in rendered
        assert "open mail" in rendered
        store.close()

    def test_no_procedures_no_section(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        store.add_memory(kind="fact", content="just a fact")
        desk = Desk(store)
        rendered = desk.render()
        assert "## Known Procedures" not in rendered
        store.close()

class TestCreateTask:
    async def test_create_task_e1_auto(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        llm = MockLLM([
            j(action="create_task", goal="Check if new emails arrived", priority="normal",
              estimated_effect="E1", reason="idle observation",
              expected_evidence="task created", stop_condition="task exists"),
            j(action="wait", reason="done", expected_evidence="n/a", stop_condition="n/a"),
        ])
        actions = await run_loop(store, llm, max_iterations=3)
        assert any(a["action"] == "create_task" for a in actions)
        created = [a for a in actions if a["action"] == "create_task"][0]
        assert created["result"].get("created")
        tasks = store.get_pending_tasks()
        assert any("email" in t["goal"].lower() for t in tasks)
        store.close()

    async def test_create_task_e2_blocked(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        llm = MockLLM([
            j(action="create_task", goal="Reorganize project files", priority="normal",
              estimated_effect="E3", reason="would improve structure",
              expected_evidence="task created", stop_condition="task exists"),
            j(action="wait", reason="done", expected_evidence="n/a", stop_condition="n/a"),
        ])
        actions = await run_loop(store, llm, max_iterations=3)
        created = [a for a in actions if a["action"] == "create_task"][0]
        task_id = created["result"]["created"]
        task = store.connection.execute("SELECT status FROM tasks WHERE id = ?", (task_id,)).fetchone()
        assert task["status"] == "blocked"
        store.close()

    async def test_create_task_no_goal_error(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        llm = MockLLM([
            j(action="create_task", goal="", reason="empty",
              expected_evidence="n/a", stop_condition="n/a"),
            j(action="wait", reason="done", expected_evidence="n/a", stop_condition="n/a"),
        ])
        actions = await run_loop(store, llm, max_iterations=3)
        created = [a for a in actions if a["action"] == "create_task"][0]
        assert created["result"].get("error")
        store.close()


    def test_procedure_not_in_memories_section(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        store.add_task("work")
        store.activate_task(store.get_pending_tasks()[0]["id"])
        store.add_memory(kind="procedure", content='{"name": "my proc", "steps": ["a", "b"]}')
        store.add_memory(kind="fact", content="a fact")
        desk = Desk(store)
        rendered = desk.render()
        # Procedures should render in their own section, not in Memories
        assert "Known Procedures" in rendered
        assert "my proc" in rendered
        store.close()
