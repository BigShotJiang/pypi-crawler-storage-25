from __future__ import annotations

import asyncio
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pascal.loop as loop_module
import pascal.tools as tools_module
from pascal.actions import ActionContext, _handle_channel_reply, execute_action
from pascal.llm.anthropic import AnthropicProvider
from pascal.llm.openai import OpenAIProvider
from pascal.state import PascalStore
from pascal.tools import channel_reply, set_channel_bot
from pascal.types import PlanNode


class TestLLMParsingStability:
    def test_openai_parse_response_handles_empty_choices(self):
        response = SimpleNamespace(
            choices=[],
            usage=SimpleNamespace(prompt_tokens=1, completion_tokens=2, total_tokens=3),
        )

        parsed = OpenAIProvider._parse_response(response)

        assert parsed.text is None
        assert parsed.tool_calls == []
        assert parsed.usage.total_tokens == 3

    def test_anthropic_parse_response_includes_usage(self):
        response = SimpleNamespace(
            content=[SimpleNamespace(type="text", text="hello")],
            usage=SimpleNamespace(input_tokens=4, output_tokens=5),
        )

        parsed = AnthropicProvider._parse_response(response)

        assert parsed.text == "hello"
        assert parsed.usage.prompt_tokens == 4
        assert parsed.usage.completion_tokens == 5
        assert parsed.usage.total_tokens == 9


class TestTelegramTimeoutGuards:
    async def test_channel_reply_wraps_send_message_in_wait_for(self, monkeypatch):
        timeouts = []

        async def fake_wait_for(awaitable, timeout):
            timeouts.append(timeout)
            return await awaitable

        monkeypatch.setattr(asyncio, "wait_for", fake_wait_for)
        tools_module._reply_timestamps.clear()
        bot = AsyncMock()
        set_channel_bot(bot, owner_chat_id=12345)

        result = await channel_reply({"text": "hello"})

        assert result["ok"] is True
        assert timeouts == [15]
        bot.send_message.assert_called_once_with(chat_id=12345, text="hello")
        set_channel_bot(None, 0)

    async def test_channel_reply_notification_wraps_send_message_in_wait_for(self, monkeypatch, tmp_path):
        timeouts = []

        async def fake_wait_for(awaitable, timeout):
            timeouts.append(timeout)
            return await awaitable

        monkeypatch.setattr(asyncio, "wait_for", fake_wait_for)
        store = PascalStore(str(tmp_path / "test.db"))
        notif_id = store.push_notification(
            source="telegram",
            message="hello",
            metadata={"chat_id": "777"},
        )
        bot = AsyncMock()
        set_channel_bot(bot, owner_chat_id=777)

        result = await _handle_channel_reply(
            ActionContext(store=store, max_effect="E3"),
            {"notification_id": notif_id, "text": "reply"},
        )

        assert result["reply_sent"] is True
        assert timeouts == [15]
        bot.send_message.assert_called_once_with(chat_id=777, text="reply")
        set_channel_bot(None, 0)
        store.close()

    async def test_notify_channel_wraps_send_message_in_wait_for(self, monkeypatch):
        timeouts = []

        async def fake_wait_for(awaitable, timeout):
            timeouts.append(timeout)
            return await awaitable

        monkeypatch.setattr(asyncio, "wait_for", fake_wait_for)
        bot = AsyncMock()
        set_channel_bot(bot, owner_chat_id=999)

        await loop_module._notify_channel("status update")

        assert timeouts == [15]
        bot.send_message.assert_called_once_with(chat_id=999, text="status update")
        set_channel_bot(None, 0)


class TestNotificationHandlingGuards:
    async def test_channel_reply_returns_already_handled_without_sending_reply(self, tmp_path):
        store = PascalStore(str(tmp_path / "test.db"))
        notif_id = store.push_notification(
            source="telegram",
            message="hello",
            metadata={"chat_id": "777"},
        )
        store.handle_notification(notif_id)
        bot = AsyncMock()
        set_channel_bot(bot, owner_chat_id=777)

        result = await _handle_channel_reply(
            ActionContext(store=store, max_effect="E3"),
            {"notification_id": notif_id, "text": "reply again"},
        )

        assert result["already_handled"] is True
        bot.send_message.assert_not_called()
        set_channel_bot(None, 0)
        store.close()

    async def test_channel_reply_warns_when_reply_claims_execution_without_prior_execute(self, tmp_path):
        store = PascalStore(str(tmp_path / "test.db"))
        notif_id = store.push_notification(
            source="cli",
            message="크롬 켜줘",
        )

        result = await _handle_channel_reply(
            ActionContext(store=store, max_effect="E3"),
            {"notification_id": notif_id, "text": "크롬 켰어"},
        )

        assert result["warning"] == "no prior execute found"
        assert result["reply_text"] == "크롬 켰어"
        store.close()

    async def test_unsolicited_channel_reply_is_blocked_at_e2(self, tmp_path):
        store = PascalStore(str(tmp_path / "test.db"))

        result = await execute_action(
            store,
            {"action": "channel_reply", "text": "hello"},
            "channel_reply",
            max_effect="E2",
        )

        assert result["status"] == "error"
        assert result["escalate"] is True
        store.close()


class TestPlanNodeRecursionGuard:
    def test_find_node_returns_none_for_cycle(self):
        root = PlanNode(id="root", title="plan", kind="branch")
        root.children.append(root)

        assert root.find_node("missing") is None
