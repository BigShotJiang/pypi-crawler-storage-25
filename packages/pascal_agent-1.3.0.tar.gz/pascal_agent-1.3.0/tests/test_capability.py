"""Tests for capability gating (effect level + error streak)."""

from __future__ import annotations

from pascal.effect import compute_threshold


class TestComputeThreshold:
    def test_e0_always_go(self):
        assert compute_threshold("E0", recent_error_streak=99) == "go"

    def test_e5_always_block(self):
        assert compute_threshold("E5", recent_error_streak=0) == "block"

    def test_low_effects_go_by_default(self):
        assert compute_threshold("E1") == "go"
        assert compute_threshold("E2") == "go"
        assert compute_threshold("E3") == "go"

    def test_e4_is_caution(self):
        assert compute_threshold("E4") == "caution"

    def test_error_streak_causes_caution(self):
        assert compute_threshold("E2", recent_error_streak=3) == "caution"

    def test_high_error_streak_blocks_high_effects(self):
        assert compute_threshold("E3", recent_error_streak=5) == "block"
        assert compute_threshold("E4", recent_error_streak=5) == "block"

    def test_high_error_streak_cautions_low_effects(self):
        assert compute_threshold("E2", recent_error_streak=5) == "caution"
