"""Phase 1 tests: commitment fields + effect ladder."""

from __future__ import annotations

import json

from conftest import MockLLM, j

from pascal.desk import Desk
from pascal.effect import classify_command, check_allowed
from pascal.loop import run_loop
from pascal.state import PascalStore


# ── Commitment fields ────────────────────────────────────────────

class TestCommitment:
    def test_fields_created(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task(
            "Fix auth bug",
            promised_to=["customer_a", "support_lead"],
            due_at="2026-03-21T18:00:00+09:00",
            proof_required=["test_pass_log"],
            depends_on=["task_xyz"],
        )
        task = store.connection.execute("SELECT * FROM tasks WHERE id = ?", (tid,)).fetchone()
        assert json.loads(task["promised_to"]) == ["customer_a", "support_lead"]
        assert task["due_at"] == "2026-03-21T18:00:00+09:00"
        assert json.loads(task["proof_required"]) == ["test_pass_log"]
        assert json.loads(task["depends_on"]) == ["task_xyz"]
        store.close()

    def test_fields_nullable(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task("Simple task")
        task = store.connection.execute("SELECT * FROM tasks WHERE id = ?", (tid,)).fetchone()
        assert task["promised_to"] is None
        assert task["due_at"] is None
        store.close()

    def test_desk_renders_commitment(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task(
            "Deploy hotfix",
            promised_to=["ops_team"],
            due_at="2026-03-22T10:00:00Z",
            proof_required=["deploy_log"],
        )
        store.activate_task(tid)
        desk = Desk(store)
        rendered = desk.render()
        assert "ops_team" in rendered
        assert "2026-03-22" in rendered
        assert "deploy_log" in rendered
        store.close()

    def test_desk_renders_without_commitment(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task("No commitment task")
        store.activate_task(tid)
        desk = Desk(store)
        rendered = desk.render()
        assert "No commitment task" in rendered
        assert "Promised" not in rendered
        store.close()


# ── Effect Ladder ────────────────────────────────────────────────

class TestEffect:
    def test_hard_e5_rm_rf(self):
        assert classify_command("rm -rf /") == "E5"
        assert classify_command("rm -rf /", llm_assessment="E0") == "E5"  # hard override

    def test_hard_e5_sudo(self):
        assert classify_command("sudo apt install") == "E5"

    def test_hard_e5_drop_table(self):
        assert classify_command("DROP TABLE users") == "E5"

    def test_hard_e4_git_push_main(self):
        assert classify_command("git push origin main") == "E4"

    def test_hard_e4_curl_post(self):
        assert classify_command("curl -X POST https://api.example.com") == "E4"

    def test_hard_e3_git_push_branch(self):
        assert classify_command("git push origin feature-x") == "E3"

    def test_llm_assessment_ignored(self):
        """LLM self-report is no longer trusted — default E3 if no hard rule."""
        assert classify_command("python analyze.py", llm_assessment="E0") == "E3"
        assert classify_command("python analyze.py", llm_assessment="E1") == "E3"

    def test_safe_commands_e0(self):
        assert classify_command("echo hello") == "E0"
        assert classify_command("ls -la") == "E0"
        assert classify_command("git status") == "E0"

    def test_network_get_e1(self):
        """Network GET is E1 — can exfiltrate data to remote servers."""
        assert classify_command("curl https://example.com") == "E1"
        assert classify_command("wget https://example.com") == "E1"

    def test_write_commands_e2(self):
        assert classify_command("mv a.txt b.txt") == "E2"
        assert classify_command("cp a.txt b.txt") == "E2"

    def test_permission_commands_e3(self):
        assert classify_command("chmod 644 file.txt") == "E3"
        assert classify_command("chown user:group file.txt") == "E3"

    def test_unknown_defaults_e3(self):
        assert classify_command("some_obscure_command --flag") == "E3"

    def test_allowed_within_limit(self):
        assert check_allowed("E1", "E2") is True
        assert check_allowed("E2", "E2") is True

    def test_blocked_above_limit(self):
        assert check_allowed("E3", "E2") is False
        assert check_allowed("E5", "E2") is False

    async def test_loop_escalates_on_high_effect(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task("Deploy to prod")
        llm = MockLLM([
            j(action="pick_task", task_id=tid, reason="start"),
            j(action="execute", command="git push origin main", reason="deploy",
              effect_level="E4"),
        ])
        actions = await run_loop(store, llm, max_effect="E2", max_iterations=5)
        # Effect gate now blocks in pre-execute (no execute action emitted).
        # The LLM gets error feedback and the loop continues/stops.
        action_types = [a["action"] for a in actions]
        assert "execute" not in action_types, "execute should be blocked by pre-execute effect gate"
        store.close()
