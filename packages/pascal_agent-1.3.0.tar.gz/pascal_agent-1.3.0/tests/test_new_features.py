"""Tests for recently added Pascal features: PlanNode new fields, node_executions, task_artifacts."""

from __future__ import annotations

import json

import pytest

from pascal.types import PlanNode
from pascal.state import PascalStore


# ── PlanNode new fields roundtrip ────────────────────────────────

class TestPlanNodeNewFields:
    def test_new_fields_roundtrip(self):
        node = PlanNode(
            id="s0",
            title="parallel step",
            kind="branch",
            branch_mode="parallel",
            executor="codex",
            budget_seconds=300,
            proof_required=["test passes"],
            children=[
                PlanNode(
                    id="c0", title="child", kind="leaf",
                    done_when="ok", action={"action": "execute", "command": "echo hi"},
                )
            ],
        )
        d = node.to_dict()
        restored = PlanNode.from_dict(d)

        assert restored.branch_mode == "parallel"
        assert restored.executor == "codex"
        assert restored.budget_seconds == 300
        assert restored.proof_required == ["test passes"]

    def test_new_fields_in_dict(self):
        node = PlanNode(
            id="s0",
            title="parallel step",
            kind="branch",
            branch_mode="parallel",
            executor="codex",
            budget_seconds=300,
            proof_required=["test passes"],
            children=[
                PlanNode(
                    id="c0", title="child", kind="leaf",
                    done_when="ok", action={"action": "execute", "command": "echo hi"},
                )
            ],
        )
        d = node.to_dict()

        assert d["branch_mode"] == "parallel"
        assert d["executor"] == "codex"
        assert d["budget_seconds"] == 300
        assert d["proof_required"] == ["test passes"]

    def test_defaults_not_serialized(self):
        """serial branch_mode and None fields are omitted from to_dict."""
        leaf = PlanNode(
            id="s0", title="step", kind="leaf",
            done_when="ok", action={"action": "execute", "command": "ls"},
        )
        d = leaf.to_dict()

        assert "branch_mode" not in d
        assert "executor" not in d
        assert "budget_seconds" not in d
        assert "proof_required" not in d

    def test_defaults_after_roundtrip(self):
        """from_dict populates correct defaults when fields are absent."""
        leaf = PlanNode(
            id="s0", title="step", kind="leaf",
            done_when="ok", action={"action": "execute", "command": "ls"},
        )
        restored = PlanNode.from_dict(leaf.to_dict())

        assert restored.branch_mode == "serial"
        assert restored.executor is None
        assert restored.budget_seconds is None
        assert restored.proof_required is None

    def test_proof_required_multiple_items(self):
        node = PlanNode(
            id="s0", title="verified step", kind="branch",
            branch_mode="serial",
            proof_required=["test passes", "lint clean", "coverage 90%"],
            children=[
                PlanNode(
                    id="c0", title="child", kind="leaf",
                    done_when="ok", action={"action": "execute", "command": "pytest"},
                )
            ],
        )
        restored = PlanNode.from_dict(node.to_dict())
        assert restored.proof_required == ["test passes", "lint clean", "coverage 90%"]


# ── node_executions CRUD ─────────────────────────────────────────

class TestNodeExecutionsCRUD:
    def test_create_and_get_roundtrip(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task("test task")

        exec_id = store.create_node_execution(tid, "node-1")

        row = store.get_node_execution(tid, "node-1")
        assert row is not None
        assert row["id"] == exec_id
        assert row["task_id"] == tid
        assert row["node_id"] == "node-1"
        assert row["status"] == "pending"
        assert row["executor"] == "local"
        store.close()

    def test_create_with_custom_executor_and_revision(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task("test task")

        exec_id = store.create_node_execution(tid, "node-2", executor="codex", plan_revision=3)

        row = store.get_node_execution(tid, "node-2")
        assert row["executor"] == "codex"
        assert row["plan_revision"] == 3
        store.close()

    def test_update_status_running(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task("test task")
        exec_id = store.create_node_execution(tid, "node-1")

        store.update_node_execution(exec_id, status="running")

        row = store.get_node_execution(tid, "node-1")
        assert row["status"] == "running"
        store.close()

    def test_update_status_done(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task("test task")
        exec_id = store.create_node_execution(tid, "node-1")

        store.update_node_execution(exec_id, status="done")

        row = store.get_node_execution(tid, "node-1")
        assert row["status"] == "done"
        store.close()

    def test_update_status_failed(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task("test task")
        exec_id = store.create_node_execution(tid, "node-1")

        store.update_node_execution(exec_id, status="failed")

        row = store.get_node_execution(tid, "node-1")
        assert row["status"] == "failed"
        store.close()

    def test_get_active_returns_only_claimed_and_running(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task("test task")

        e_pending = store.create_node_execution(tid, "node-pending")
        e_claimed = store.create_node_execution(tid, "node-claimed")
        e_running = store.create_node_execution(tid, "node-running")
        e_done    = store.create_node_execution(tid, "node-done")
        e_failed  = store.create_node_execution(tid, "node-failed")

        store.update_node_execution(e_claimed, status="claimed")
        store.update_node_execution(e_running, status="running")
        store.update_node_execution(e_done,    status="done")
        store.update_node_execution(e_failed,  status="failed")

        active = store.get_active_node_executions(tid)
        active_ids = {r["id"] for r in active}

        assert e_claimed in active_ids
        assert e_running in active_ids
        assert e_pending not in active_ids
        assert e_done    not in active_ids
        assert e_failed  not in active_ids
        store.close()

    def test_get_active_empty_when_none_active(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task("test task")
        store.create_node_execution(tid, "node-1")

        assert store.get_active_node_executions(tid) == []
        store.close()

    def test_evidence_json_storage(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task("test task")
        exec_id = store.create_node_execution(tid, "node-1")

        evidence = json.dumps({"output": "tests passed", "exit_code": 0})
        store.update_node_execution(exec_id, evidence_json=evidence)

        row = store.get_node_execution(tid, "node-1")
        assert row["evidence_json"] == evidence
        parsed = json.loads(row["evidence_json"])
        assert parsed["exit_code"] == 0
        store.close()

    def test_get_returns_most_recent_for_node(self, tmp_path):
        """When a node is re-executed, get_node_execution returns the latest row."""
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task("test task")

        e1 = store.create_node_execution(tid, "node-1")
        store.update_node_execution(e1, status="failed")

        e2 = store.create_node_execution(tid, "node-1")
        store.update_node_execution(e2, status="running")

        row = store.get_node_execution(tid, "node-1")
        assert row["id"] == e2
        assert row["status"] == "running"
        store.close()


# ── task_artifacts CRUD ──────────────────────────────────────────

class TestTaskArtifactsCRUD:
    def test_add_and_get_latest_roundtrip(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task("test task")

        art_id = store.add_artifact(tid, "progress", "Step 1 done", "Ran the tests successfully.")

        row = store.get_latest_artifact(tid, "progress")
        assert row is not None
        assert row["id"] == art_id
        assert row["task_id"] == tid
        assert row["kind"] == "progress"
        assert row["title"] == "Step 1 done"
        assert row["content"] == "Ran the tests successfully."
        store.close()

    def test_get_latest_returns_newest(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task("test task")

        # Insert artifacts one at a time to ensure the second row has a
        # strictly later created_at, even on fast hardware (same-millisecond
        # inserts resolve via the auto-generated row ID ordering).
        art_id1 = store.add_artifact(tid, "handoff", "Shift 1", "First handoff note.")

        # Force a distinct timestamp by using a small update that bumps the
        # DB clock. We verify the artifact inserted AFTER always wins.
        import time; time.sleep(0.01)  # 10 ms — well within SQLite resolution
        art_id2 = store.add_artifact(tid, "handoff", "Shift 2", "Second handoff note.")

        row = store.get_latest_artifact(tid, "handoff")
        assert row["id"] == art_id2
        assert row["title"] == "Shift 2"
        store.close()

    def test_get_latest_returns_none_when_absent(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task("test task")

        assert store.get_latest_artifact(tid, "evidence") is None
        store.close()

    def test_get_task_artifacts_returns_list(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task("test task")

        store.add_artifact(tid, "progress",  "p1", "content 1")
        store.add_artifact(tid, "evidence",  "e1", "content 2")
        store.add_artifact(tid, "handoff",   "h1", "content 3")

        artifacts = store.get_task_artifacts(tid)
        assert len(artifacts) == 3
        store.close()

    def test_get_task_artifacts_ordering_newest_first(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task("test task")

        import time
        store.add_artifact(tid, "scratch", "first",  "a"); time.sleep(0.01)
        store.add_artifact(tid, "scratch", "second", "b"); time.sleep(0.01)
        store.add_artifact(tid, "scratch", "third",  "c")

        artifacts = store.get_task_artifacts(tid)
        titles = [a["title"] for a in artifacts]
        assert titles == ["third", "second", "first"]
        store.close()

    def test_get_task_artifacts_fields(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task("test task")

        store.add_artifact(tid, "evidence", "My Evidence", "details here")

        artifacts = store.get_task_artifacts(tid)
        assert len(artifacts) == 1
        row = artifacts[0]
        assert "id" in row
        assert "kind" in row
        assert "title" in row
        assert "created_at" in row
        # content is not returned by get_task_artifacts (only by get_latest_artifact)
        assert "content" not in row
        store.close()

    def test_get_task_artifacts_isolated_by_task(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        tid1 = store.add_task("task one")
        tid2 = store.add_task("task two")

        store.add_artifact(tid1, "progress", "t1 artifact", "for task 1")
        store.add_artifact(tid2, "progress", "t2 artifact", "for task 2")

        assert len(store.get_task_artifacts(tid1)) == 1
        assert len(store.get_task_artifacts(tid2)) == 1
        assert store.get_task_artifacts(tid1)[0]["title"] == "t1 artifact"
        store.close()

    @pytest.mark.parametrize("kind", ["handoff", "progress", "evidence", "scratch"])
    def test_valid_kind_constraint(self, tmp_path, kind):
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task("test task")

        art_id = store.add_artifact(tid, kind, f"{kind} artifact", "content")
        row = store.get_latest_artifact(tid, kind)
        assert row["kind"] == kind
        store.close()

    def test_invalid_kind_raises(self, tmp_path):
        import sqlite3
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task("test task")

        with pytest.raises(sqlite3.IntegrityError):
            store.add_artifact(tid, "invalid_kind", "title", "content")
        store.close()

    def test_content_truncated_at_10000_chars(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task("test task")
        long_content = "x" * 15000

        store.add_artifact(tid, "scratch", "big artifact", long_content)

        row = store.get_latest_artifact(tid, "scratch")
        assert len(row["content"]) == 10000
        store.close()
