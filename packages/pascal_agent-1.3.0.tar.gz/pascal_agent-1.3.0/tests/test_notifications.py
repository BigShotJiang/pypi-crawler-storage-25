"""Tests for notification event typing and auto-expiry."""

from __future__ import annotations

import sqlite3

from pascal.desk import Desk
from pascal.state import PascalStore


class TestNotificationStore:
    def test_migrate_notifications_adds_event_type_column_for_legacy_db(self, tmp_path):
        db_path = tmp_path / "legacy.db"
        conn = sqlite3.connect(db_path)
        conn.executescript(
            """
            CREATE TABLE notifications (
                id TEXT PRIMARY KEY,
                source TEXT NOT NULL,
                message TEXT NOT NULL,
                priority TEXT DEFAULT 'normal' CHECK (priority IN ('urgent', 'normal', 'low')),
                metadata TEXT DEFAULT '{}',
                status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'handled', 'dismissed')),
                received_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
                handled_at TEXT
            );
            """
        )
        conn.execute(
            "INSERT INTO notifications (id, source, message) VALUES ('notif_legacy', 'legacy', 'hello')"
        )
        conn.commit()
        conn.close()

        store = PascalStore(str(db_path))

        cols = {
            row[1]
            for row in store.connection.execute("PRAGMA table_info(notifications)").fetchall()
        }
        assert "event_type" in cols
        row = store.connection.execute(
            "SELECT event_type FROM notifications WHERE id = 'notif_legacy'"
        ).fetchone()
        assert row["event_type"] == "external_event"
        store.close()

    def test_push_notification_persists_event_type_and_can_exclude_low_priority(self, tmp_path):
        store = PascalStore(str(tmp_path / "test.db"))
        user_message_id = store.push_notification(
            source="user",
            message="Summarize this",
            priority="normal",
            event_type="user_message",
        )
        low_priority_id = store.push_notification(
            source="scheduler",
            message="Daily reminder",
            priority="low",
        )

        all_pending = store.get_pending_notifications()
        filtered = store.get_pending_notifications(include_low=False)

        assert [notif["id"] for notif in all_pending] == [user_message_id, low_priority_id]
        assert [notif["id"] for notif in filtered] == [user_message_id]

        rows = store.connection.execute(
            "SELECT id, event_type FROM notifications ORDER BY received_at ASC"
        ).fetchall()
        event_types = {row["id"]: row["event_type"] for row in rows}
        assert event_types[user_message_id] == "user_message"
        assert event_types[low_priority_id] == "external_event"
        store.close()

    def test_expire_stale_notifications_dismisses_only_old_pending_rows(self, tmp_path):
        store = PascalStore(str(tmp_path / "test.db"))
        stale_id = store.push_notification(source="slack", message="Old alert", priority="urgent")
        fresh_id = store.push_notification(source="slack", message="Fresh alert", priority="normal")
        handled_id = store.push_notification(source="slack", message="Already handled", priority="urgent")
        store.handle_notification(handled_id)

        store.connection.execute(
            """
            UPDATE notifications
            SET received_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now', '-31 minutes')
            WHERE id IN (?, ?)
            """,
            (stale_id, handled_id),
        )
        store.connection.execute(
            """
            UPDATE notifications
            SET received_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now', '-5 minutes')
            WHERE id = ?
            """,
            (fresh_id,),
        )
        store.connection.commit()

        expired = store.expire_stale_notifications(max_age_minutes=30)

        assert expired == 1
        stale = store.connection.execute(
            "SELECT status, handled_at FROM notifications WHERE id = ?",
            (stale_id,),
        ).fetchone()
        fresh = store.connection.execute(
            "SELECT status, handled_at FROM notifications WHERE id = ?",
            (fresh_id,),
        ).fetchone()
        handled = store.connection.execute(
            "SELECT status FROM notifications WHERE id = ?",
            (handled_id,),
        ).fetchone()
        assert stale["status"] == "dismissed"
        assert stale["handled_at"] is not None
        assert fresh["status"] == "pending"
        assert fresh["handled_at"] is None
        assert handled["status"] == "handled"
        store.close()


class TestNotificationDesk:
    def test_render_expires_stale_notifications_before_showing_them(self, tmp_path):
        store = PascalStore(str(tmp_path / "test.db"))
        stale_id = store.push_notification(source="slack", message="Stale alert", priority="urgent")
        store.push_notification(source="slack", message="Fresh alert", priority="normal")
        store.connection.execute(
            """
            UPDATE notifications
            SET received_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now', '-31 minutes')
            WHERE id = ?
            """,
            (stale_id,),
        )
        store.connection.commit()

        rendered = Desk(store).render()

        stale = store.connection.execute(
            "SELECT status, handled_at FROM notifications WHERE id = ?",
            (stale_id,),
        ).fetchone()
        assert "Fresh alert" in rendered
        assert "Stale alert" not in rendered
        assert stale["status"] == "dismissed"
        assert stale["handled_at"] is not None
        store.close()

    def test_render_delta_shows_urgent_and_normal_notifications_but_skips_low(self, tmp_path):
        store = PascalStore(str(tmp_path / "test.db"))
        store.push_notification(
            source="telegram",
            message="Server is down!",
            priority="urgent",
            event_type="external_event",
        )
        store.push_notification(
            source="user",
            message="Can you summarize this?",
            priority="normal",
            event_type="user_message",
        )
        store.push_notification(
            source="scheduler",
            message="Routine reminder",
            priority="low",
            event_type="routine",
        )

        delta = Desk(store).render_delta()
        summary_line = next(
            line for line in delta.splitlines() if "Can you summarize this?" in line
        )

        assert "Server is down!" in delta
        assert "Can you summarize this?" in delta
        assert "Routine reminder" not in delta
        assert "[URGENT]" in delta
        assert "external_event" in delta
        assert "user_message" in delta
        assert "[URGENT]" not in summary_line
        store.close()


class _FakeMCPManager:
    def __init__(self) -> None:
        self.connected_servers: list[str] = []

    async def connect_all(self, configs) -> None:
        self.connected_servers = []

    async def disconnect_all(self) -> None:
        return None


class TestMainNotificationEvents:
    def test_push_notification_with_user_message_event_type(self, tmp_path):
        """Direct test: push_notification with event_type=user_message works.
        (_run_one_task was removed as dead code; this tests the underlying API.)"""
        store = PascalStore(str(tmp_path / "test.db"))
        store.push_notification(
            source="user", message="hello from repl",
            priority="normal", event_type="user_message",
        )
        notifs = store.get_pending_notifications()
        assert len(notifs) == 1
        assert notifs[0]["message"] == "hello from repl"
        assert notifs[0]["event_type"] == "user_message"
        store.close()
