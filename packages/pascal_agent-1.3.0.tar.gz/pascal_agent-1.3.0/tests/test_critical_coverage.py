"""Critical coverage tests for config.py, compaction.py, and types.py."""

from __future__ import annotations

import datetime
import os

import pytest

from pascal.compaction import (
    DEFAULT_TOKEN_BUDGET,
    PROVIDER_TOKEN_BUDGETS,
    build_session_summary,
    estimate_tokens,
    messages_too_long,
    token_budget,
)
from pascal.config import load_config, resolve_max_tool_rounds
from pascal.types import Message, PascalConfig, Role, extract_json, json_safe, safe_json_loads


# ── config.py ────────────────────────────────────────────────────


class TestLoadConfig:
    def test_returns_pascal_config_with_defaults(self, monkeypatch):
        # Remove any overriding env vars so defaults come through.
        # Local pascal.toml may set a non-default provider, so we only
        # assert structural correctness here rather than specific defaults.
        monkeypatch.delenv("PASCAL_MODEL", raising=False)
        monkeypatch.delenv("PASCAL_PROVIDER", raising=False)
        monkeypatch.delenv("PASCAL_BASE_URL", raising=False)
        monkeypatch.delenv("PASCAL_DB_PATH", raising=False)

        cfg = load_config()

        assert isinstance(cfg, PascalConfig)
        assert isinstance(cfg.model, str) and cfg.model
        assert isinstance(cfg.provider, str) and cfg.provider

    def test_env_var_model_override(self, monkeypatch):
        monkeypatch.setenv("PASCAL_MODEL", "claude-opus-4")
        monkeypatch.delenv("PASCAL_PROVIDER", raising=False)

        cfg = load_config()

        assert cfg.model == "claude-opus-4"

    def test_env_var_provider_override(self, monkeypatch):
        monkeypatch.delenv("PASCAL_MODEL", raising=False)
        monkeypatch.setenv("PASCAL_PROVIDER", "anthropic")

        cfg = load_config()

        assert cfg.provider == "anthropic"

    def test_both_env_vars_override(self, monkeypatch):
        monkeypatch.setenv("PASCAL_MODEL", "gemini-2.0")
        monkeypatch.setenv("PASCAL_PROVIDER", "openai")

        cfg = load_config()

        assert cfg.model == "gemini-2.0"
        assert cfg.provider == "openai"

    def test_kwarg_overrides_env(self, monkeypatch):
        monkeypatch.setenv("PASCAL_MODEL", "env-model")

        cfg = load_config(model="kwarg-model")

        assert cfg.model == "kwarg-model"


class TestResolveMaxToolRounds:
    def test_returns_daemon_default_when_no_config(self):
        cfg = PascalConfig()

        result = resolve_max_tool_rounds(cfg, daemon_mode=True)

        assert result == 3

    def test_returns_single_turn_default_when_not_daemon(self):
        cfg = PascalConfig()

        result = resolve_max_tool_rounds(cfg, daemon_mode=False)

        assert result == 1

    def test_config_max_tool_rounds_used(self):
        cfg = PascalConfig()
        cfg.max_tool_rounds = 7

        result = resolve_max_tool_rounds(cfg)

        assert result == 7

    def test_config_max_inner_turns_used_when_no_tool_rounds(self):
        cfg = PascalConfig()
        cfg.max_inner_turns = 5

        result = resolve_max_tool_rounds(cfg)

        assert result == 5

    def test_cli_args_override_config(self):
        cfg = PascalConfig()
        cfg.max_tool_rounds = 10

        class FakeArgs:
            max_tool_rounds = 2
            max_inner_turns = None

        result = resolve_max_tool_rounds(cfg, FakeArgs())

        assert result == 2

    def test_minimum_is_one(self):
        cfg = PascalConfig()
        cfg.max_tool_rounds = 0

        result = resolve_max_tool_rounds(cfg)

        assert result == 1


# ── compaction.py ────────────────────────────────────────────────


class TestEstimateTokens:
    def test_empty_string_returns_zero(self):
        assert estimate_tokens("") == 0

    def test_ascii_short_text(self):
        # "hello world" → 2 words → int(2 * 1.3) = 2
        result = estimate_tokens("hello world")
        assert result == 2

    def test_ascii_longer_text(self):
        text = "the quick brown fox jumps over the lazy dog"
        # 9 words → int(9 * 1.3) = 11
        result = estimate_tokens(text)
        assert result == 11

    def test_cjk_korean_characters(self):
        # Korean syllables are in 0xAC00-0xD7AF range
        korean = "안녕하세요"  # 5 Korean characters, no ASCII words
        result = estimate_tokens(korean)
        # cjk_chars=5, non_cjk_text="     " (spaces), split() → 0 words
        # int(0 * 1.3 + 5 * 1.5) = int(7.5) = 7
        assert result == 7

    def test_cjk_mixed_with_ascii(self):
        # 2 ASCII words + 2 Korean chars
        text = "hello 안녕 world"
        result = estimate_tokens(text)
        # cjk_chars=2, non_cjk_text="hello   world", split() → 2 words
        # int(2 * 1.3 + 2 * 1.5) = int(2.6 + 3.0) = int(5.6) = 5
        assert result == 5

    def test_cjk_chinese_characters(self):
        # CJK Unified Ideographs: 0x4E00-0x9FFF
        chinese = "\u4e2d\u6587"  # 2 Chinese chars
        result = estimate_tokens(chinese)
        # cjk_chars=2, word_tokens=0 → int(3.0) = 3
        assert result == 3


class TestTokenBudget:
    def test_default_budget_for_unknown_model(self):
        assert token_budget("unknown-model-xyz") == DEFAULT_TOKEN_BUDGET

    def test_gpt4o_budget(self):
        assert token_budget("gpt-4o") == PROVIDER_TOKEN_BUDGETS["gpt-4o"]

    def test_gpt54_budget(self):
        assert token_budget("gpt-5.4") == PROVIDER_TOKEN_BUDGETS["gpt-5.4"]

    def test_claude_sonnet_budget(self):
        assert token_budget("claude-sonnet-4") == PROVIDER_TOKEN_BUDGETS["claude-sonnet"]

    def test_claude_opus_budget(self):
        assert token_budget("claude-opus-latest") == PROVIDER_TOKEN_BUDGETS["claude-opus"]

    def test_gemini_budget(self):
        assert token_budget("gemini-2.0-flash") == PROVIDER_TOKEN_BUDGETS["gemini"]

    def test_case_insensitive(self):
        assert token_budget("GPT-4O") == PROVIDER_TOKEN_BUDGETS["gpt-4o"]


class TestMessagesTooLong:
    def test_empty_messages_not_too_long(self):
        assert not messages_too_long([], "gpt-5.4")

    def test_short_messages_not_too_long(self):
        msgs = [Message(role=Role.USER, content="hello")]
        assert not messages_too_long(msgs, "gpt-5.4")

    def test_over_budget_detected(self):
        # Use a model with a small budget and very long content
        # DEFAULT_TOKEN_BUDGET=30_000; generate ~31k tokens worth of text
        # 1.3 tokens/word → need ~24k words to exceed 30k tokens
        big_content = " ".join(["word"] * 25_000)
        msgs = [Message(role=Role.USER, content=big_content)]
        assert messages_too_long(msgs, "unknown-model")

    def test_messages_with_none_content_treated_as_empty(self):
        msgs = [Message(role=Role.USER, content="")]
        assert not messages_too_long(msgs, "gpt-5.4")


class TestBuildSessionSummary:
    def test_empty_actions_returns_empty_string(self):
        assert build_session_summary([]) == ""

    def test_single_complete_task(self):
        actions = [
            {"action": "complete_task", "result": {"summary": "wrote the file"}, "reason": ""}
        ]
        summary = build_session_summary(actions)
        assert "wrote the file" in summary
        assert "Completed:" in summary
        assert "Actions taken so far: 1" in summary

    def test_failed_task_appears_in_summary(self):
        actions = [
            {"action": "fail_task", "reason": "permission denied"}
        ]
        summary = build_session_summary(actions)
        assert "Failed:" in summary
        assert "permission denied" in summary

    def test_pick_task_sets_active(self):
        actions = [
            {"action": "pick_task", "result": {"activated": "task-42"}}
        ]
        summary = build_session_summary(actions)
        assert "Active task: task-42" in summary

    def test_action_count_always_present(self):
        actions = [
            {"action": "shell", "result": {}},
            {"action": "shell", "result": {}},
        ]
        summary = build_session_summary(actions)
        assert "Actions taken so far: 2" in summary

    def test_non_empty_for_any_action(self):
        actions = [{"action": "shell", "result": {}}]
        summary = build_session_summary(actions)
        assert len(summary) > 0


# ── types.py ─────────────────────────────────────────────────────


class TestExtractJson:
    def test_plain_json_object(self):
        text = '{"action": "shell", "command": "ls"}'
        result = extract_json(text)
        assert result == '{"action": "shell", "command": "ls"}'

    def test_json_with_surrounding_text(self):
        text = 'Here is the action: {"action": "wait"} please proceed'
        result = extract_json(text)
        assert result == '{"action": "wait"}'

    def test_no_json_raises_value_error(self):
        with pytest.raises(ValueError, match="No JSON"):
            extract_json("no json here at all")

    def test_nested_braces(self):
        text = '{"outer": {"inner": "value"}}'
        result = extract_json(text)
        import json
        parsed = json.loads(result)
        assert parsed["outer"]["inner"] == "value"

    def test_json_in_code_fence(self):
        text = '```json\n{"action": "wait"}\n```'
        result = extract_json(text)
        assert '"action"' in result
        assert '"wait"' in result

    def test_incomplete_json_raises_value_error(self):
        with pytest.raises(ValueError, match="No complete JSON"):
            extract_json('{"unclosed": "brace"')


class TestSafeJsonLoads:
    def test_valid_json_string(self):
        result = safe_json_loads('{"key": "value"}')
        assert result == {"key": "value"}

    def test_invalid_json_with_none_default_returns_empty_dict(self):
        # When default=None (or omitted), the function returns {} on failure.
        result = safe_json_loads("not valid json", default=None)
        assert result == {}

    def test_invalid_json_with_explicit_default_returns_default(self):
        result = safe_json_loads("not valid json", default="fallback")
        assert result == "fallback"

    def test_invalid_json_returns_default_dict(self):
        result = safe_json_loads("bad json")
        assert result == {}

    def test_already_dict_passthrough(self):
        d = {"already": "parsed"}
        result = safe_json_loads(d)
        assert result == d

    def test_already_list_passthrough(self):
        lst = [1, 2, 3]
        result = safe_json_loads(lst)
        assert result == lst

    def test_non_string_non_collection_returns_default(self):
        result = safe_json_loads(42)
        assert result == {}

    def test_json_array_string(self):
        result = safe_json_loads("[1, 2, 3]")
        assert result == [1, 2, 3]


class TestJsonSafe:
    def test_datetime_becomes_string(self):
        dt = datetime.datetime(2024, 1, 15, 12, 0, 0)
        result = json_safe(dt)
        assert result == "<datetime>"

    def test_set_becomes_string(self):
        s = {1, 2, 3}
        result = json_safe(s)
        assert result == "<set>"

    def test_dataclass_serialized_without_data_field(self):
        from pascal.types import ContentBlock
        block = ContentBlock(type="image", data="base64data", mime_type="image/png")
        result = json_safe(block)
        assert isinstance(result, dict)
        assert "type" in result
        assert "mime_type" in result
        # data field must be excluded
        assert "data" not in result

    def test_dataclass_tool_call(self):
        from pascal.types import ToolCall
        tc = ToolCall(id="tc1", name="shell", params={"command": "ls"})
        result = json_safe(tc)
        assert isinstance(result, dict)
        assert result["id"] == "tc1"
        assert result["name"] == "shell"
