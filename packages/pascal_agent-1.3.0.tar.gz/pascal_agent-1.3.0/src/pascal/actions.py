"""Pascal action handlers — dispatches to plan.py and delegate.py for plan/delegate logic.

Each handler processes one action type and returns a result dict.
Called by the main loop's dispatcher in loop.py.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import tempfile
from dataclasses import dataclass, field
from typing import Any, Callable

from pascal.delegate import handle_delegate, handle_check_delegate
from pascal.effect import classify_command, check_allowed, get_max_effect, escalation_message, effect_to_int
from pascal.mcp import MCPManager
from pascal.plan import handle_plan
from pascal.receipts import Ledger
from pascal.sandbox import SandboxManager
from pascal.state import PascalStore
from pascal.tools import (
    execute_tool, TOOL_REGISTRY, resolve_tool_effect,
    get_channel_bot, get_owner_chat_id,
)
from pascal.trust import scan_tool_input
from pascal.types import Message, Role

logger = logging.getLogger(__name__)

_PROTECTED_CONTEXT_KEYS = frozenset({"mission", "identity", "routines"})
_PROTECTED_CONTEXT_PREFIXES = ("task_mode:", "active_skill")

_EXECUTION_CLAIM_KEYWORDS = (
    "켰",
    "열었",
    "실행",
    "launched",
    "opened",
    "created",
    "완료",
)
_COMPLETE_TASK_FAILURE_WINDOW = 3
_COMPLETE_TASK_HISTORY_SCAN_LIMIT = 20
_OUTPUT_SOFT_LIMIT = 4000   # chars — show more context than old 2000 hard limit
_OUTPUT_HARD_LIMIT = 8000   # chars — absolute max to prevent context blowup




@dataclass
class ActionContext:
    """Bundles runtime dependencies for action handlers.

    Replaces the 9-parameter kwargs signature. Handlers access only what they need.
    Inspired by OpenAI Agents SDK RunContext / Claude Code tool context patterns.
    """
    store: PascalStore
    llm: Any = None
    max_effect: str | None = None
    sandbox: SandboxManager | None = None
    mcp_manager: MCPManager | None = None
    execute_command: Callable[[str], str] | None = None
    thought_buffer: list[str] = field(default_factory=list)
    ledger: Ledger | None = None
    skip_verification: bool = False
    notify_fn: Callable[[str], Any] | None = None
    temp_root: str = ""  # session temp dir inside workspace
    mode: str = "oneshot"
    # Governance callbacks — set by LoopRunner so plan steps share the same
    # stagnation/trust/effect checks as direct loop actions.
    governance_fn: Callable[[str, dict], str | None] | None = None
    on_step_complete_fn: Callable[[str, dict, dict], None] | None = None

    async def notify(self, msg: str) -> None:
        if self.notify_fn is not None:
            await self.notify_fn(msg)

    def check_governance(self, action: str, decision: dict) -> str | None:
        """Run loop-level governance checks. Returns error string or None if allowed.

        If governance_fn is not wired, blocks side-effecting actions as a safety fallback.
        """
        if self.governance_fn is not None:
            return self.governance_fn(action, decision)
        # Fallback: allow read-only, block side-effects when governance is not configured
        if action in ("think", "editor") and str(decision.get("op", "")).strip() in ("read", "list", ""):
            return None
        if action in ("shell", "code", "computer", "uia", "channel_reply", "delegate"):
            return f"governance not configured: {action} blocked (safety fallback)"
        return None

    def record_step_complete(self, action: str, decision: dict, result: dict) -> None:
        """Notify loop of step completion for trust/stagnation tracking."""
        if self.on_step_complete_fn is not None:
            self.on_step_complete_fn(action, decision, result)


_OUTPUT_MAX_LINES = 150  # SWE-agent ACI pattern: hard line cap preserves context window

def _truncate_output(text: str) -> str:
    """Truncate output by chars AND lines. SWE-agent pattern: line-based cap for context preservation."""
    if not text or not text.strip():
        return "Command completed successfully with no output."
    # Line-based cap first (most impactful for context window)
    lines = text.splitlines()
    if len(lines) > _OUTPUT_MAX_LINES:
        text = "\n".join(lines[:_OUTPUT_MAX_LINES]) + f"\n... [{len(lines)} lines total, showing first {_OUTPUT_MAX_LINES}]"
    # Then char-based cap
    if len(text) <= _OUTPUT_HARD_LIMIT:
        return text
    return text[:_OUTPUT_HARD_LIMIT] + f"\n... [truncated, {len(text)} chars total]"


async def _handle_think(ctx: ActionContext, decision: dict[str, Any]) -> dict[str, Any]:
    thought = str(decision.get("thought") or decision.get("reason") or "").strip()
    if thought:
        ctx.thought_buffer.append(thought)
        # Persist latest reasoning to context so it survives compaction/restart
        ctx.store.set_context("last_reasoning", thought, ttl_hours=1)
    return {"thought": thought, "status": "ok"}


async def _handle_plan(ctx: ActionContext, decision: dict[str, Any]) -> dict[str, Any]:
    return await handle_plan(ctx, decision, VALID_ACTIONS)


async def _handle_delegate_action(ctx: ActionContext, decision: dict[str, Any]) -> dict[str, Any]:
    return await handle_delegate(ctx, decision)


async def _handle_check_delegate_action(ctx: ActionContext, decision: dict[str, Any]) -> dict[str, Any]:
    return await handle_check_delegate(ctx, decision)


# ── First-class tool handlers (split from _handle_execute) ──


async def _handle_shell(ctx: ActionContext, decision: dict[str, Any]) -> dict[str, Any]:
    """Run a shell command."""
    command = str(decision.get("command") or "").strip()
    if not command:
        return {"error": "no command provided", "status": "error"}
    llm_effect = str(decision.get("effect_level") or "")
    cmd_level = classify_command(command, llm_assessment=llm_effect)
    allowed_max = get_max_effect(ctx.max_effect)
    if not check_allowed(cmd_level, allowed_max):
        return {
            "error": escalation_message(command, cmd_level, allowed_max),
            "status": "error", "effect_level": cmd_level, "escalate": True,
        }
    scan_result = scan_tool_input("shell", {"command": command})
    if scan_result.verdict == "block":
        return {"error": f"blocked by trust scanner: {scan_result.reason}", "status": "error"}
    if scan_result.verdict == "warn":
        logger.warning("Trust scanner warning: %s", scan_result.reason)
    if ctx.execute_command:
        try:
            output = ctx.execute_command(command)
            status = "ok" if output is not None else "error"
        except Exception as exc:
            output = str(exc)
            status = "unknown"
    else:
        sb = ctx.sandbox or SandboxManager()
        sb_result = sb.run(command, timeout=60)
        output = sb_result.output
        status = sb_result.status
    active = ctx.store.get_active_task()
    if active:
        ctx.store.update_task(active["id"], progress=f"Ran: {command[:100]}")
    safe_output = "" if output is None else str(output)
    return {"output": _truncate_output(safe_output), "status": status}


async def _handle_builtin_tool(
    ctx: ActionContext, tool_name: str, tool_params: dict[str, Any],
) -> dict[str, Any]:
    """Dispatch a built-in or MCP tool call. Shared by editor/computer/uia handlers + execute shim."""
    scan = scan_tool_input(tool_name, tool_params)
    if scan.verdict == "block":
        return {"error": f"blocked by trust scanner: {scan.reason}", "status": "error"}
    tool_effect = resolve_tool_effect(tool_name, tool_params)
    if tool_effect is None:
        if ctx.mcp_manager is not None and ctx.mcp_manager.has_tool(tool_name):
            all_specs = ctx.mcp_manager.all_tool_specs() if hasattr(ctx.mcp_manager, "all_tool_specs") else []
            specs = [s for s in all_specs if s.name == tool_name]
            tool_effect = "E3" if (specs and specs[0].side_effects) else "E0"
        else:
            tool_effect = "E1"
    allowed_max = get_max_effect(ctx.max_effect)
    if not check_allowed(tool_effect, allowed_max):
        return {
            "error": escalation_message(tool_name, tool_effect, allowed_max),
            "status": "error", "effect_level": tool_effect, "escalate": True,
        }
    use_mcp = (ctx.mcp_manager is not None and ctx.mcp_manager.has_tool(tool_name)
                and (tool_name not in TOOL_REGISTRY or "uid" in tool_params))
    if use_mcp and ctx.mcp_manager is not None:
        tool_result = await ctx.mcp_manager.call_tool(tool_name, tool_params)
    elif tool_name in TOOL_REGISTRY:
        tool_result = await execute_tool(tool_name, tool_params)
    elif ctx.mcp_manager is not None and ctx.mcp_manager.has_tool(tool_name):
        tool_result = await ctx.mcp_manager.call_tool(tool_name, tool_params)
    else:
        return {"error": f"Unknown tool: {tool_name}", "status": "error"}
    active = ctx.store.get_active_task()
    if active:
        ctx.store.update_task(active["id"], progress=f"Tool: {tool_name}")
    result_dict: dict[str, Any] = {
        "output": _truncate_output(tool_result.get("output") or ""),
        "status": "ok" if tool_result.get("ok") else "error",
        "error": tool_result.get("error", ""),
        "tool": tool_name,
    }
    if tool_result.get("attachment") is not None:
        result_dict["attachment"] = tool_result["attachment"]
    return result_dict


async def _handle_editor_tool(ctx: ActionContext, decision: dict[str, Any]) -> dict[str, Any]:
    """File operations: read, write, list."""
    op = decision.get("op")
    if not op:
        return {"error": "editor requires 'op' parameter (read, write, or list)", "status": "error"}
    params: dict[str, Any] = {"op": op, "path": decision.get("path")}
    if "content" in decision:
        params["content"] = decision["content"]
    return await _handle_builtin_tool(ctx, "editor", params)


async def _handle_computer_tool(ctx: ActionContext, decision: dict[str, Any]) -> dict[str, Any]:
    """Screen interaction: screenshot, click, type, hotkey, scroll."""
    params = {k: v for k, v in decision.items()
              if k in ("op", "x", "y", "button", "text", "keys", "clicks", "region") and v is not None}
    return await _handle_builtin_tool(ctx, "computer", params)


async def _handle_uia_tool(ctx: ActionContext, decision: dict[str, Any]) -> dict[str, Any]:
    """Windows UI Automation."""
    params = {k: v for k, v in decision.items()
              if k in (
                  "op", "title", "window_title", "ref", "text", "name",
                  "control_type", "timeout", "max_depth", "interactive_only", "clear_first",
              ) and v is not None}
    return await _handle_builtin_tool(ctx, "uia", params)


async def _handle_code(ctx: ActionContext, decision: dict[str, Any]) -> dict[str, Any]:
    """Run a Python code snippet in sandbox."""
    code = str(decision.get("code") or "").strip()
    if not code:
        return {"error": "no code provided", "status": "error"}
    scan_result = scan_tool_input("code", {"code": code})
    if scan_result.verdict == "block":
        return {"error": f"blocked by trust scanner: {scan_result.reason}", "status": "error"}
    allowed_max = get_max_effect(ctx.max_effect)
    if not check_allowed("E2", allowed_max):
        return {"error": escalation_message("python code", "E2", allowed_max), "status": "error", "escalate": True}
    sb = ctx.sandbox or SandboxManager()
    # Write temp file in session_temp_root (inside workspace) so path checker allows it.
    # GPT Pro pattern: allowed_write_roots = [workspace, temp_root]
    tmp_dir = ctx.temp_root or None
    if tmp_dir:
        os.makedirs(tmp_dir, exist_ok=True)
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False,
                                 encoding="utf-8", dir=tmp_dir) as f:
        f.write(code)
        script_path = f.name
    python_cmd = "python" if os.name == "nt" else "python3"
    try:
        sb_result = sb.run(f"{python_cmd} {script_path}", timeout=60)
    finally:
        try:
            os.unlink(script_path)
        except OSError:
            pass
    active = ctx.store.get_active_task()
    if active:
        ctx.store.update_task(active["id"], progress=f"Code: {code[:80]}")
    return {"output": _truncate_output(sb_result.output), "status": sb_result.status}


async def _handle_channel_reply(ctx: ActionContext, decision: dict[str, Any]) -> dict[str, Any]:
    """Send a message to the connected channel. If notification_id is given, auto-mark as handled."""
    text = str(decision.get("text") or decision.get("reply_text") or "").strip()
    if not text:
        return {"error": "text is required for channel_reply", "status": "error"}
    notif_id = str(decision.get("notification_id") or "").strip()

    # Check notification status (if replying)
    notif = None
    if notif_id:
        notif = ctx.store.connection.execute(
            "SELECT source, message, metadata, status FROM notifications WHERE id = ?", (notif_id,),
        ).fetchone()
        if notif and notif["status"] in ("handled", "dismissed"):
            return {"already_handled": True, "status": "ok"}
        allowed_max = get_max_effect(ctx.max_effect)
        if not check_allowed("E2", allowed_max):
            return {"error": f"reply suppressed: E2 exceeds max_effect {allowed_max}", "status": "error"}
        from pascal.trust import scan as _trust_scan
        reply_scan = _trust_scan(text)
        if reply_scan.verdict == "block":
            return {"error": f"reply blocked by trust scanner: {reply_scan.reason}", "status": "error"}
    else:
        allowed_max = get_max_effect(ctx.max_effect)
        if not check_allowed("E3", allowed_max):
            return {
                "error": escalation_message("channel_reply", "E3", allowed_max),
                "status": "error", "effect_level": "E3", "escalate": True,
            }
        scan = scan_tool_input("channel_reply", {"text": text})
        if scan.verdict == "block":
            return {"error": f"blocked by trust scanner: {scan.reason}", "status": "error"}
        tool_result = await execute_tool("channel_reply", {"text": text})
        active = ctx.store.get_active_task()
        if active:
            ctx.store.update_task(active["id"], progress="Tool: channel_reply")
        result_dict: dict[str, Any] = {
            "output": _truncate_output(tool_result.get("output") or ""),
            "status": "ok" if tool_result.get("ok") else "error",
            "error": tool_result.get("error", ""),
            "tool": "channel_reply",
            "reply_sent": bool(tool_result.get("ok")),
            "text": text,
            "reply_text": text,
        }
        return result_dict

    # Execution claim guard
    warning = ""
    if text and _reply_claims_execution(text):
        recent_history = ctx.store.get_recent_history(limit=10)
        if not _has_recent_successful_execute(recent_history):
            warning = "no prior execute found"

    # Send via channel bot
    reply_sent = False
    chat_id = 0
    has_channel = get_channel_bot() is not None or os.environ.get("PASCAL_SLACK_WEBHOOK") or os.environ.get("PASCAL_DISCORD_WEBHOOK")
    if not has_channel and not notif_id:
        # Unsolicited outbound with no channel → error
        return {"error": "No channel configured (not in daemon mode)", "status": "error", "reply_text": text}
    if get_channel_bot() is not None:
        if notif:
            try:
                meta = json.loads(notif["metadata"]) if notif["metadata"] else {}
            except (ValueError, TypeError):
                meta = {}
            chat_id = int(meta.get("chat_id", get_owner_chat_id() or 0))
        else:
            chat_id = int(get_owner_chat_id() or 0)
        if chat_id:
            try:
                await asyncio.wait_for(get_channel_bot().send_message(chat_id=chat_id, text=text), timeout=15)
                reply_sent = True
            except Exception as e:
                logger.warning("Channel reply failed: %s", e)

    # Webhook fallback
    if not reply_sent:
        source = notif["source"] if notif else ""
        reply_url = ""
        if "slack" in source:
            reply_url = os.environ.get("PASCAL_SLACK_WEBHOOK", "")
        elif "discord" in source:
            reply_url = os.environ.get("PASCAL_DISCORD_WEBHOOK", "")
        if reply_url:
            from pascal.scheduler import send_webhook
            reply_sent = send_webhook(reply_url, text)

    # Auto-mark notification as handled only after a successful reply.
    if notif_id and reply_sent:
        ctx.store.handle_notification(notif_id)
        if notif:
            ctx.store.push_conversation_turn(notif["source"], "user", notif["message"])
            ctx.store.push_conversation_turn(notif["source"], "assistant", text)

    return {
        "status": "ok" if reply_sent else "error",
        "reply_text": text,
        "reply_sent": reply_sent,
        **({"error": "channel reply was not sent"} if not reply_sent else {}),
        **({"notification_handled": notif_id} if notif_id and reply_sent else {}),
        **({"warning": warning} if warning else {}),
    }


async def _handle_execute(ctx: ActionContext, decision: dict[str, Any]) -> dict[str, Any]:
    """Invoke an MCP tool that is not exposed as a first-class Pascal tool."""
    tool_name = str(decision.get("tool") or "").strip()
    tool_params = decision.get("tool_params") or {}
    if not tool_name:
        return {"error": "execute requires 'tool' parameter", "status": "error"}
    if not isinstance(tool_params, dict):
        return {"error": "tool_params must be a dict", "status": "error"}
    return await _handle_builtin_tool(ctx, tool_name, tool_params)


async def _handle_create_task(ctx: ActionContext, decision: dict[str, Any]) -> dict[str, Any]:
    goal = str(decision.get("goal") or "").strip()
    if not goal:
        return {"error": "goal is required for create_task", "status": "error"}
    priority = str(decision.get("priority") or "normal").strip()
    if priority not in ("urgent", "normal", "low"):
        priority = "normal"
    task_id = ctx.store.add_task(goal, priority=priority, source="agent")
    estimated_effect = str(decision.get("estimated_effect") or "E1").strip()
    if effect_to_int(estimated_effect) >= 2:
        ctx.store.update_task(
            task_id,
            status="blocked",
            progress=f"Awaiting approval (agent-initiated, {estimated_effect})",
        )
        await ctx.notify(f"📋 제안: {goal}\n효과 수준 {estimated_effect} -- 승인이 필요합니다.")
    return {"created": task_id, "goal": goal, "source": "agent", "status": "ok"}


async def _handle_pick_task(ctx: ActionContext, decision: dict[str, Any]) -> dict[str, Any]:
    task_id = str(decision.get("task_id") or "").strip()
    if not task_id:
        return {"error": "task_id is required -- choose which task to activate", "status": "error"}
    if not task_id.startswith("task_"):
        return {"error": f"invalid task_id '{task_id}' -- expected a task_ ID", "status": "error"}
    current = ctx.store.get_active_task()
    if current and current["id"] == task_id:
        return {"activated": task_id, "already_active": True, "status": "ok"}
    target = ctx.store.connection.execute(
        "SELECT id, status FROM tasks WHERE id = ?", (task_id,),
    ).fetchone()
    if target is None:
        return {"error": f"task {task_id} not found", "status": "error"}
    if target["status"] in ("done", "failed"):
        return {"error": f"task {task_id} is '{target['status']}' (terminal) -- pick a pending or paused task", "status": "error"}
    if current and current["id"] != task_id:
        ctx.store.pause_active_task("switching to another task")
    ctx.store.activate_task(task_id)
    task_row = ctx.store.connection.execute("SELECT goal FROM tasks WHERE id = ?", (task_id,)).fetchone()
    goal = task_row["goal"] if task_row else task_id
    await ctx.notify(f"▶ 시작: {goal}")
    return {"activated": task_id, "status": "ok"}


async def _handle_create_subtask(ctx: ActionContext, decision: dict[str, Any]) -> dict[str, Any]:
    active = ctx.store.get_active_task()
    if not active:
        return {"error": "no active task to create subtask under", "status": "error"}
    goal = str(decision.get("subtask_goal") or "").strip()
    if not goal:
        return {"error": "subtask_goal is required", "status": "error"}
    priority = str(decision.get("subtask_priority") or "normal").strip()
    if priority not in ("urgent", "normal", "low"):
        priority = "normal"
    subtask_id = ctx.store.add_task(
        goal, priority=priority, source="agent", parent_id=active["id"],
    )
    return {"created": subtask_id, "parent": active["id"], "goal": goal, "status": "ok"}


async def _handle_dismiss_notification(ctx: ActionContext, decision: dict[str, Any]) -> dict[str, Any]:
    notif_id = str(decision.get("notification_id") or "").strip()
    if not notif_id:
        return {"error": "notification_id is required", "status": "error"}
    ctx.store.dismiss_notification(notif_id)
    return {"dismissed": notif_id, "status": "ok"}


def _clear_active_skill(ctx: ActionContext) -> None:
    """Clear active skill on task exit (complete/fail/block/pause)."""
    if ctx.store.get_context("active_skill"):
        ctx.store.set_context("active_skill", None)


async def _handle_pause_task(ctx: ActionContext, decision: dict[str, Any]) -> dict[str, Any]:
    pause_reason = str(decision.get("pause_reason") or "interrupted")
    paused = ctx.store.pause_active_task(pause_reason)
    _clear_active_skill(ctx)
    return {"paused": paused, "status": "ok"}


async def _handle_complete_task(ctx: ActionContext, decision: dict[str, Any]) -> dict[str, Any]:
    active = ctx.store.get_active_task()
    if active:
        summary = str(decision.get("summary") or "completed")
        guard_history = ctx.store.get_recent_history(limit=_COMPLETE_TASK_HISTORY_SCAN_LIMIT)
        if _recent_execute_failure_streak(guard_history, active["id"]):
            reason = (
                f"Cannot complete: the last {_COMPLETE_TASK_FAILURE_WINDOW} recent execute "
                "actions for this task failed or returned empty output."
            )
            ctx.store.update_task(active["id"], progress=f"Completion blocked: {reason}")
            return {"error": reason, "retry": True, "status": "error"}

        history = ctx.store.get_recent_history(limit=5)
        proof_required = None
        if active.get("proof_required"):
            try:
                proof_required = json.loads(active["proof_required"])
            except (json.JSONDecodeError, TypeError):
                pass
        # Auto-verify: if E2+ side effects occurred and no read-back followed, require proof
        if not proof_required and not ctx.skip_verification:
            has_side_effect = any(
                h.get("summary", "").startswith(("shell:", "code:", "editor: write", "computer:", "uia:"))
                for h in history
            )
            last_was_read = history and any(
                kw in (history[-1].get("summary") or "")
                for kw in ("editor: read", "screenshot", "uia: snapshot", "read_file")
            )
            if has_side_effect and not last_was_read:
                ctx.store.update_task(active["id"], progress="Verify before completing: run a read-back action")
                return {"error": "Side effects detected but no read-back verification. Run a read-only action first.", "retry": True, "status": "error"}

        # Verification: run when proof_required is explicitly set on the task.
        if proof_required and ctx.llm is not None and not ctx.skip_verification:
            passed, reason = await _verify_completion(
                ctx.llm, active["goal"], summary, history, proof_required=proof_required,
            )
        else:
            passed, reason = True, "no_proof_required"
        if not passed:
            ctx.store.update_task(active["id"], progress=f"Verification failed: {reason}")
            return {"error": f"verification_failed: {reason}", "retry": True, "status": "error"}
        ctx.store.update_task(active["id"], status="done", result=summary)
        _clear_active_skill(ctx)
        # Auto-memorize: extract detailed, reusable procedure from task history
        _auto_memorize_procedure(ctx.store, {**active, "result": summary}, history)
        await ctx.notify(f"✓ 완료: {active['goal']}\n{summary}")
        return {"completed": active["id"], "summary": summary, "verified": True, "status": "ok"}
    return {"error": "no active task", "status": "error"}


async def _handle_block_task(ctx: ActionContext, decision: dict[str, Any]) -> dict[str, Any]:
    active = ctx.store.get_active_task()
    if active:
        reason = str(decision.get("reason") or "blocked")
        ctx.store.update_task(active["id"], status="blocked", progress=f"Blocked: {reason}")
        _clear_active_skill(ctx)
        return {"blocked": active["id"], "reason": reason, "status": "ok"}
    return {"error": "no active task", "status": "error"}


async def _handle_fail_task(ctx: ActionContext, decision: dict[str, Any]) -> dict[str, Any]:
    active = ctx.store.get_active_task()
    if active:
        reason = str(decision.get("reason") or "failed")
        ctx.store.update_task(active["id"], status="failed", progress=f"Failed: {reason}")
        _clear_active_skill(ctx)
        _auto_postmortem(ctx.store, active, reason)
        await ctx.notify(f"✗ 실패: {active['goal']}\n{reason}")
        return {"failed": active["id"], "reason": reason, "status": "ok"}
    return {"error": "no active task", "status": "error"}


async def _handle_add_todo(ctx: ActionContext, decision: dict[str, Any]) -> dict[str, Any]:
    title = str(decision.get("todo_title") or decision.get("title") or "").strip()
    active = ctx.store.get_active_task()
    if not active:
        return {"error": "no active task to add todo to", "status": "error"}
    if not title:
        return {"error": "empty todo title", "status": "error"}
    todo_id = ctx.store.add_todo(task_id=active["id"], title=title)
    return {"added": todo_id, "title": title, "status": "ok"}


async def _handle_complete_todo(ctx: ActionContext, decision: dict[str, Any]) -> dict[str, Any]:
    todo_id = str(decision.get("todo_id") or "").strip()
    if not todo_id:
        return {"error": "no todo_id", "status": "error"}
    ctx.store.complete_todo(todo_id)
    return {"completed": todo_id, "status": "ok"}


async def _handle_memorize(ctx: ActionContext, decision: dict[str, Any]) -> dict[str, Any]:
    kind = str(decision.get("memory_kind") or "").strip()
    content = str(decision.get("memory_content") or "").strip()
    if not content:
        return {"error": "empty memory content", "status": "error"}
    if kind not in ("fact", "lesson", "preference", "procedure"):
        return {"error": f"invalid memory_kind '{kind}' -- must be fact|lesson|preference|procedure", "status": "error"}
    active = ctx.store.get_active_task()
    mem_id = ctx.store.add_memory(
        kind=kind, content=content,
        source_task_id=active["id"] if active else None,
    )
    return {"memorized": mem_id, "kind": kind, "status": "ok"}


async def _handle_add_rule(ctx: ActionContext, decision: dict[str, Any]) -> dict[str, Any]:
    rule = str(decision.get("rule") or "").strip()
    if rule:
        rule_id = ctx.store.add_rule(rule, mutable=True, added_by="agent")
        return {"added": rule_id, "rule": rule, "status": "ok"}
    return {"error": "empty rule", "status": "error"}


async def _handle_remove_rule(ctx: ActionContext, decision: dict[str, Any]) -> dict[str, Any]:
    rule_id = str(decision.get("rule_id") or "").strip()
    if rule_id:
        removed = ctx.store.remove_rule(rule_id)
        return {"removed": removed, "rule_id": rule_id, "status": "ok"}
    return {"error": "no rule_id", "status": "error"}


async def _handle_set_context(ctx: ActionContext, decision: dict[str, Any]) -> dict[str, Any]:
    key = str(decision.get("key") or "").strip()
    value = decision.get("value")
    if not key:
        return {"error": "no key", "status": "error"}
    if key in _PROTECTED_CONTEXT_KEYS or any(key.startswith(p) for p in _PROTECTED_CONTEXT_PREFIXES):
        return {"error": f"context key '{key}' is protected and cannot be modified by the agent", "status": "error"}
    ttl = decision.get("ttl_hours")
    if isinstance(ttl, (int, float)) and ttl > 0:
        ctx.store.set_context(key, value, ttl_hours=int(ttl))
    else:
        ctx.store.set_context(key, value)
    return {"set": key, "status": "ok"}


async def _handle_escalate(ctx: ActionContext, decision: dict[str, Any]) -> dict[str, Any]:
    question = str(decision.get("question") or "Need human input")
    return {"escalated": True, "question": question, "status": "ok"}


async def _handle_wait(ctx: ActionContext, decision: dict[str, Any]) -> dict[str, Any]:
    return {"waiting": True, "reason": str(decision.get("wait_reason") or ""), "status": "ok"}


async def _handle_skill(ctx: ActionContext, decision: dict[str, Any]) -> dict[str, Any]:
    """Load a skill and prepare it for transient injection into conversation."""
    from pascal.tools import skill as _skill_fn
    name = str(decision.get("name") or "").strip()
    if not name:
        return {"error": "skill name is required", "status": "error"}
    args = str(decision.get("args") or "").strip()

    result = await _skill_fn({"name": name})
    if not result.get("ok"):
        return {"error": result.get("error", "skill not found"), "status": "error"}

    body = result.get("output", "")
    fm = result.get("frontmatter", {})
    skill_name = result.get("skill_name", name)

    # Store active skill in context for desk display
    ctx.store.set_context("active_skill", {
        "name": skill_name,
        "description": fm.get("description", ""),
        "allowed_tools": fm.get("allowed_tools"),
        "context": fm.get("context", "inline"),
        "paths": fm.get("paths"),
    })

    return {
        "status": "ok",
        "skill_name": skill_name,
        "body": body,
        "args": args,
        "frontmatter": fm,
        "output": f"Skill '{skill_name}' activated. Instructions loaded.",
    }


# ── Handler registry ──────────────────────────────────────────────

ACTION_HANDLERS: dict[str, Callable] = {
    "think": _handle_think,
    "plan": _handle_plan,
    "delegate": _handle_delegate_action,
    "check_delegate": _handle_check_delegate_action,
    # First-class tools (Loop v2)
    "shell": _handle_shell,
    "editor": _handle_editor_tool,
    "computer": _handle_computer_tool,
    "uia": _handle_uia_tool,
    "code": _handle_code,
    "skill": _handle_skill,
    "channel_reply": _handle_channel_reply,
    # Backward-compat shim for plan steps / legacy callers
    "execute": _handle_execute,
    "create_task": _handle_create_task,
    "pick_task": _handle_pick_task,
    "create_subtask": _handle_create_subtask,
    "dismiss_notification": _handle_dismiss_notification,
    "pause_task": _handle_pause_task,
    "complete_task": _handle_complete_task,
    "block_task": _handle_block_task,
    "fail_task": _handle_fail_task,
    "add_todo": _handle_add_todo,
    "complete_todo": _handle_complete_todo,
    "memorize": _handle_memorize,
    "add_rule": _handle_add_rule,
    "remove_rule": _handle_remove_rule,
    "set_context": _handle_set_context,
    "escalate": _handle_escalate,
    "wait": _handle_wait,
}

# Valid actions -- single source of truth (must match ACTION_HANDLERS keys)
VALID_ACTIONS = frozenset(ACTION_HANDLERS)


# ── Public dispatch function ──────────────────────────────────────

async def execute_action(
    store: PascalStore,
    decision: dict[str, Any],
    action: str,
    *,
    ctx: ActionContext | None = None,
    llm=None,
    max_effect: str | None = None,
    sandbox: SandboxManager | None = None,
    mcp_manager: MCPManager | None = None,
    execute_command: Callable[[str], str] | None = None,
    thought_buffer: list[str] | None = None,
    ledger: Ledger | None = None,
    skip_verification: bool = False,
    notify_fn: Callable[[str], Any] | None = None,
    mode: str = "oneshot",
) -> dict[str, Any]:
    """Execute a single action and return the result.

    Accepts either an ActionContext (preferred) or individual kwargs (backward compat).
    """
    if ctx is None:
        ctx = ActionContext(
            store=store,
            llm=llm,
            max_effect=max_effect,
            sandbox=sandbox,
            mcp_manager=mcp_manager,
            execute_command=execute_command,
            thought_buffer=thought_buffer or [],
            ledger=ledger,
            skip_verification=skip_verification,
            notify_fn=notify_fn,
            mode=mode,
        )
    handler = ACTION_HANDLERS.get(action)
    if handler is not None:
        return await handler(ctx, decision)
    if ctx.mcp_manager is not None and ctx.mcp_manager.has_tool(action):
        return await _handle_builtin_tool(ctx, action, decision)
    return {"error": f"unhandled action: {action}", "status": "error"}




# ── Verifier ──────────────────────────────────────────────────────

async def _verify_completion(
    llm,
    task_goal: str,
    task_summary: str,
    recent_history: list[dict[str, Any]],
    proof_required: list[str] | None = None,
) -> tuple[bool, str]:
    """Ask the LLM to verify whether the task was actually completed."""
    from pascal.types import extract_json as _extract_json
    history_text = "\n".join(f"- {h['summary']}" for h in recent_history[-5:])
    proof_text = ""
    if proof_required:
        proof_text = f"\nRequired proof: {', '.join(proof_required)}"
    messages = [
        Message(
            role=Role.SYSTEM,
            content=(
                "You verify task completion. Return JSON only.\n"
                '{"passed": true/false, "reason": "why"}\n'
                "Be strict: did the actions actually accomplish the goal?\n"
                "Check that claimed evidence matches what actually happened."
            ),
        ),
        Message(
            role=Role.USER,
            content=f"Goal: {task_goal}\nClaimed result: {task_summary}{proof_text}\nRecent actions:\n{history_text}",
        ),
    ]
    try:
        response = await llm.chat(messages, tools=[])
        payload = json.loads(_extract_json(response.text or "{}"))
        return bool(payload.get("passed")), str(payload.get("reason") or "")
    except Exception as exc:
        logger.warning("Verification error: %s", exc)
        return False, str(exc)


# ── Auto post-mortem ──────────────────────────────────────────────

def _auto_postmortem(store: PascalStore, task: dict[str, Any], failure_reason: str) -> None:
    """Generate a lesson from task failure. No LLM needed -- just pattern extraction."""
    try:
        history = store.get_recent_history(limit=10)
        actions = []
        errors = []
        for h in history:
            if h.get("task_id") == task["id"]:
                actions.append(h["summary"])
                details = h.get("details")
                if isinstance(details, str):
                    try:
                        details = json.loads(details)
                    except Exception:
                        details = {}
                if isinstance(details, dict):
                    result = details.get("result", {})
                    if isinstance(result, dict) and result.get("error"):
                        errors.append(result["error"][:100])
        lesson = f"Task '{task['goal']}' failed: {failure_reason}."
        if errors:
            lesson += f" Errors: {'; '.join(errors[:3])}"
        if actions:
            lesson += f" Attempted: {'; '.join(actions[-3:])}"
        store.add_memory(kind="lesson", content=lesson, source_task_id=task["id"])
        logger.info("Auto post-mortem lesson: %s", lesson[:100])
    except Exception:
        logger.warning("Post-mortem failed", exc_info=True)


def _auto_memorize_procedure(
    store: PascalStore, task: dict[str, Any], history: list[dict[str, Any]]
) -> None:
    """Extract a detailed, reusable procedure from completed task history.

    Saves actual commands, tools, and parameters -- not just action names.
    This creates a 'work manual' entry that Pascal can replay for similar tasks.
    """
    try:
        task_actions = [h for h in history if h.get("task_id") == task["id"]]
        if len(task_actions) < 1:
            return

        steps = []
        for h in task_actions:
            details = h.get("details")
            if isinstance(details, str):
                try:
                    details = json.loads(details)
                except (json.JSONDecodeError, TypeError):
                    continue
            if not isinstance(details, dict):
                continue

            dec = details.get("decision", {})
            res = details.get("result", {})
            action_type = dec.get("action", "")

            # Skip think, pick_task, wait -- not part of the procedure
            if action_type in ("think", "pick_task", "wait", "complete_task", ""):
                continue
            # Skip failed actions
            if isinstance(res, dict) and res.get("status") == "error":
                continue

            step: dict[str, Any] = {"action": action_type}
            if action_type == "execute":
                if dec.get("tool"):
                    step["tool"] = dec["tool"]
                    # Generalize params: keep structure but mark variable values
                    params = dec.get("tool_params", {})
                    if isinstance(params, dict):
                        step["tool_params"] = {
                            k: v if k in ("region",) else f"<{k}>"
                            for k, v in params.items()
                        }
                elif dec.get("command"):
                    step["command"] = dec["command"]
            elif action_type == "delegate":
                step["tool"] = dec.get("tool", "")
                step["task_pattern"] = dec.get("task", "")[:60]
            elif action_type == "plan":
                plan_steps = dec.get("steps", [])
                step["step_count"] = len(plan_steps)

            steps.append(step)

        if not steps:
            return

        import platform as _platform
        task_summary = str(task.get("result") or "")
        proc = json.dumps({
            "name": task["goal"][:80],
            "platform": _platform.system(),
            "steps": steps[-8:],  # Keep last 8 successful steps max
            "summary": task_summary[:100],
        }, ensure_ascii=False)

        store.add_memory(kind="procedure", content=proc, source_task_id=task["id"])
        logger.info("Auto-memorized procedure: %s (%d steps)", task["goal"][:40], len(steps))
    except Exception:
        logger.warning("Auto-memorize failed", exc_info=True)


def _recent_execute_failure_streak(
    history: list[dict[str, Any]],
    task_id: str,
    *,
    window: int = _COMPLETE_TASK_FAILURE_WINDOW,
) -> bool:
    """Return True when the last N execute actions for a task all failed or were empty."""
    recent_executes: list[dict[str, Any]] = []
    for h in reversed(history):
        if h.get("task_id") != task_id:
            continue
        details = h.get("details")
        if isinstance(details, str):
            try:
                details = json.loads(details)
            except (json.JSONDecodeError, TypeError):
                details = {}
        if not isinstance(details, dict):
            continue
        decision = details.get("decision", {})
        rec_action = decision.get("action", "") if isinstance(decision, dict) else ""
        if rec_action not in ("execute", "shell", "editor", "computer", "uia", "code"):
            continue
        result = details.get("result", {})
        recent_executes.append(result if isinstance(result, dict) else {})
        if len(recent_executes) >= window:
            break
    if len(recent_executes) < window:
        return False
    return all(_execute_result_failed_or_empty(result) for result in recent_executes)


def _reply_claims_execution(reply_text: str) -> bool:
    lowered = reply_text.casefold()
    return any(keyword in lowered for keyword in _EXECUTION_CLAIM_KEYWORDS)


def _has_recent_successful_execute(history: list[dict[str, Any]]) -> bool:
    for h in reversed(history):
        details = h.get("details")
        if isinstance(details, str):
            try:
                details = json.loads(details)
            except (json.JSONDecodeError, TypeError):
                details = {}
        if not isinstance(details, dict):
            continue
        decision = details.get("decision", {})
        rec_action = decision.get("action", "") if isinstance(decision, dict) else ""
        if rec_action not in ("execute", "shell", "editor", "computer", "uia", "code"):
            continue
        result = details.get("result", {})
        if isinstance(result, dict) and not _execute_result_failed_or_empty(result):
            return True
    return False


def _execute_result_failed_or_empty(result: dict[str, Any]) -> bool:
    """Treat explicit failures as insufficient completion evidence.

    Successful commands often emit no stdout (mkdir, touch, git add), so a blank
    output stream alone is not enough to call the step a failure once status=ok
    is recorded.
    """
    if not isinstance(result, dict):
        return False
    status = str(result.get("status") or "").strip().lower()
    if status == "ok":
        return False
    if status in {"error", "unknown"}:
        return True
    error = result.get("error")
    if isinstance(error, str) and error.strip():
        return True
    if result.get("attachment") is not None:
        return False
    output = result.get("output")
    if isinstance(output, str):
        return not output.strip()
    return not bool(output)
