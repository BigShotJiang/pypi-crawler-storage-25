"""Tool schemas for Pascal function calling."""

from __future__ import annotations

from typing import Any, Literal


SchemaMode = Literal["cli", "daemon"]


def _object_schema(
    properties: dict[str, Any],
    required: list[str] | None = None,
) -> dict[str, Any]:
    return {
        "type": "object",
        "properties": properties,
        "required": required or [],
        "additionalProperties": False,
    }


def _tool(
    name: str,
    description: str,
    properties: dict[str, Any],
    required: list[str] | None = None,
) -> dict[str, Any]:
    return {
        "type": "function",
        "function": {
            "name": name,
            "description": description,
            "parameters": _object_schema(properties, required),
        },
    }


_REGION_SCHEMA = _object_schema(
    {
        "x": {"type": "integer", "description": "Region origin X"},
        "y": {"type": "integer", "description": "Region origin Y"},
        "w": {"type": "integer", "description": "Region width"},
        "h": {"type": "integer", "description": "Region height"},
    },
    ["x", "y", "w", "h"],
)


_TOOLS: dict[str, dict[str, Any]] = {
    "think": _tool(
        "think",
        "Internal reasoning. Use sparingly — only when stuck, before planning, or after restart. Prefer acting over thinking.",
        {
            "thought": {"type": "string", "description": "Your reasoning"},
        },
        ["thought"],
    ),
    "shell": _tool(
        "shell",
        "Run a shell command.",
        {
            "command": {"type": "string", "description": "Shell command to run"},
            "reason": {"type": "string"},
        },
        ["command"],
    ),
    "editor": _tool(
        "editor",
        "Read, write, or list files.",
        {
            "op": {
                "type": "string",
                "enum": ["read", "write", "list"],
                "description": "File operation",
            },
            "path": {"type": "string", "description": "File or directory path"},
            "content": {"type": "string", "description": "Content to write for write"},
            "reason": {"type": "string"},
        },
        ["op", "path"],
    ),
    "computer": _tool(
        "computer",
        "Screen interaction: screenshot, click, type, hotkey, scroll.",
        {
            "op": {
                "type": "string",
                "enum": ["screenshot", "click", "type", "hotkey", "scroll"],
                "description": "Screen operation",
            },
            "x": {"type": "integer", "description": "X coordinate for click"},
            "y": {"type": "integer", "description": "Y coordinate for click"},
            "button": {
                "type": "string",
                "enum": ["left", "right", "middle", "double"],
                "description": "Mouse button for click",
            },
            "text": {"type": "string", "description": "Text to type"},
            "keys": {
                "oneOf": [
                    {"type": "string", "description": "Hotkey combo like ctrl+c"},
                    {"type": "array", "items": {"type": "string"}, "description": "Hotkey sequence"},
                ],
            },
            "clicks": {"type": "integer", "description": "Scroll amount; negative scrolls up"},
            "region": _REGION_SCHEMA,
            "reason": {"type": "string"},
        },
        ["op"],
    ),
    "skill": _tool(
        "skill",
        "Activate a skill — loads its instructions into the conversation as a prompt patch.",
        {
            "name": {"type": "string", "description": "Skill name (filename without .md, or frontmatter name)"},
            "args": {"type": "string", "description": "Optional arguments for the skill"},
        },
        ["name"],
    ),
    "code": _tool(
        "code",
        "Run a Python code snippet in sandbox.",
        {
            "code": {"type": "string", "description": "Python code to execute"},
            "reason": {"type": "string"},
        },
        ["code"],
    ),
    "channel_reply": _tool(
        "channel_reply",
        "Send a message to the connected channel (Telegram/Slack/Discord).",
        {
            "text": {"type": "string", "description": "Message text to send"},
            "notification_id": {"type": "string", "description": "Notification being answered"},
            "reason": {"type": "string"},
        },
        ["text"],
    ),
    "execute": _tool(
        "execute",
        "Invoke an MCP tool that is not exposed as a first-class Pascal tool.",
        {
            "tool": {"type": "string", "description": "MCP tool name"},
            "tool_params": {"type": "object", "description": "Parameters for the MCP tool"},
            "reason": {"type": "string"},
        },
        ["tool"],
    ),
    "plan": _tool(
        "plan",
        "Create or patch a multi-step execution plan.",
        {
            "reason": {"type": "string"},
            "plan_tree": {
                "type": "object",
                "description": (
                    "Plan tree. Each node: {id, title, kind: branch|leaf, status, done_when, action}. "
                    "Branch nodes have children and optional branch_mode: serial(default)|parallel. "
                    "Leaf nodes can set executor: local(default)|claude-code|codex, "
                    "budget_seconds: max wall-clock time, proof_required: [list of evidence needed]."
                ),
            },
            "steps": {
                "type": "array",
                "description": "Legacy flat steps array",
                "items": {"type": "object"},
            },
            "patch_node_id": {"type": "string", "description": "Failed node ID to repair"},
        },
        ["reason"],
    ),
    "delegate": _tool(
        "delegate",
        "Delegate a task to Claude Code or Codex CLI asynchronously. Returns a child task ID immediately; call check_delegate later to retrieve the result.",
        {
            "tool": {
                "type": "string",
                "enum": ["claude-code", "codex"],
                "description": "Which agent to delegate to",
            },
            "task": {"type": "string", "description": "Task description for the delegate"},
            "context": {"type": "string", "description": "Additional context"},
            "success_criteria": {"type": "string"},
            "timeout": {"type": "integer", "description": "Timeout in seconds (max 600)"},
        },
        ["tool", "task"],
    ),
    "check_delegate": _tool(
        "check_delegate",
        "Check whether an async delegate task has finished and retrieve its result when ready.",
        {
            "task_id": {
                "type": "string",
                "description": "Child delegate task ID returned by delegate",
            },
        },
        ["task_id"],
    ),
    "pick_task": _tool(
        "pick_task",
        "Activate a pending task to work on.",
        {
            "task_id": {
                "type": "string",
                "description": "Task ID to activate",
                "pattern": "^task_",
            },
            "reason": {"type": "string"},
        },
        ["task_id"],
    ),
    "create_task": _tool(
        "create_task",
        "Create a new task.",
        {
            "goal": {"type": "string", "description": "What the task should accomplish"},
            "priority": {"type": "string", "enum": ["urgent", "normal", "low"]},
            "estimated_effect": {"type": "string", "description": "E0-E5 effect level"},
        },
        ["goal"],
    ),
    "create_subtask": _tool(
        "create_subtask",
        "Create a subtask under the active task.",
        {
            "subtask_goal": {"type": "string"},
            "subtask_priority": {"type": "string", "enum": ["urgent", "normal", "low"]},
        },
        ["subtask_goal"],
    ),
    "dismiss_notification": _tool(
        "dismiss_notification",
        "Dismiss a notification without handling it.",
        {
            "notification_id": {"type": "string"},
        },
        ["notification_id"],
    ),
    "pause_task": _tool(
        "pause_task",
        "Pause the current active task.",
        {
            "pause_reason": {"type": "string"},
        },
    ),
    "block_task": _tool(
        "block_task",
        "Block the current active task while waiting for external input.",
        {
            "reason": {"type": "string"},
        },
    ),
    "fail_task": _tool(
        "fail_task",
        "Mark the current active task as failed.",
        {
            "reason": {"type": "string"},
        },
        ["reason"],
    ),
    "complete_task": _tool(
        "complete_task",
        "Mark the current active task as done.",
        {
            "summary": {"type": "string", "description": "What was accomplished"},
        },
        ["summary"],
    ),
    "add_todo": _tool(
        "add_todo",
        "Add a TODO item to the active task.",
        {
            "todo_title": {"type": "string"},
        },
        ["todo_title"],
    ),
    "complete_todo": _tool(
        "complete_todo",
        "Mark a TODO item as done.",
        {
            "todo_id": {"type": "string"},
        },
        ["todo_id"],
    ),
    "memorize": _tool(
        "memorize",
        "Save a memory for future reference.",
        {
            "memory_kind": {
                "type": "string",
                "enum": ["fact", "lesson", "preference", "procedure"],
            },
            "memory_content": {"type": "string"},
        },
        ["memory_kind", "memory_content"],
    ),
    "add_rule": _tool(
        "add_rule",
        "Add a behavior rule.",
        {
            "rule": {"type": "string"},
        },
        ["rule"],
    ),
    "remove_rule": _tool(
        "remove_rule",
        "Remove a mutable rule.",
        {
            "rule_id": {"type": "string"},
        },
        ["rule_id"],
    ),
    "set_context": _tool(
        "set_context",
        "Set a working memory key-value pair.",
        {
            "key": {"type": "string"},
            "value": {},
            "ttl_hours": {"type": "number", "description": "Optional TTL in hours"},
        },
        ["key", "value"],
    ),
    "wait": _tool(
        "wait",
        "Do nothing and wait for new events.",
        {
            "wait_reason": {"type": "string"},
        },
    ),
    "escalate": _tool(
        "escalate",
        "Ask a human for help.",
        {
            "question": {"type": "string", "description": "What you need help with"},
        },
        ["question"],
    ),
}


_BASE_TOOL_ORDER = (
    "think",
    "shell",
    "editor",
    "computer",
    "code",
    "skill",
    "plan",
    "pick_task",
    "create_task",
    "create_subtask",
    "dismiss_notification",
    "pause_task",
    "block_task",
    "fail_task",
    "complete_task",
    "add_todo",
    "complete_todo",
    "memorize",
    "add_rule",
    "remove_rule",
    "set_context",
    "wait",
    "escalate",
)


def build_tool_schemas(
    *, mode: SchemaMode = "cli", has_mcp: bool = False, mcp_specs: list | None = None,
    allowlist: list[str] | None = None,
) -> list[dict[str, Any]]:
    """Build the Pascal tool list for CLI or daemon runtime.

    mcp_specs: list of MCPToolSpec objects to expose as individual tools.
    allowlist: if provided, only include tools whose names are in this list.
               Always includes 'think' and 'skill' for safety (can't get stuck).
    """
    if mode not in ("cli", "daemon"):
        raise ValueError(f"Unknown schema mode: {mode}")

    tool_names = list(_BASE_TOOL_ORDER)
    if has_mcp:
        tool_names.append("execute")
    if mode == "daemon":
        tool_names.append("channel_reply")
    # Apply allowlist filter (skill allowedTools enforcement)
    if allowlist is not None:
        always_allowed = {"think", "skill", "complete_task", "fail_task", "escalate"}
        allowed_set = set(allowlist) | always_allowed
        tool_names = [n for n in tool_names if n in allowed_set]
    tools = [_TOOLS[name] for name in tool_names]

    # Append individual MCP tool schemas so the LLM sees them by name
    # When allowlist is active, skip MCP tools unless explicitly in the allowlist
    if mcp_specs:
        for spec in mcp_specs:
            if allowlist is not None and spec.name not in allowed_set:
                continue
            tools.append({
                "type": "function",
                "function": {
                    "name": spec.name,
                    "description": f"[MCP:{spec.server_name}] {spec.description}",
                    "parameters": spec.parameters or {"type": "object", "properties": {}},
                },
            })
    return tools
