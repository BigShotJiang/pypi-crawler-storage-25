"""pascal/types.py -- 공유 DTO. 최소한만 정의."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class Role(str, Enum):
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"
    TOOL = "tool"


@dataclass
class ContentBlock:
    type: str
    data: str = ""
    mime_type: str = ""
    detail: str = "auto"
    tool_use_id: str = ""
    tool_name: str = ""


@dataclass
class Message:
    role: Role
    content: str = ""
    tool_call_id: str = ""
    tool_calls: list["ToolCall"] = field(default_factory=list)
    attachments: list[ContentBlock] = field(default_factory=list)


@dataclass
class ToolCall:
    id: str
    name: str
    params: dict[str, Any] = field(default_factory=dict)


@dataclass
class TokenUsage:
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0


@dataclass
class LLMResponse:
    text: str | None = None
    tool_calls: list[ToolCall] = field(default_factory=list)
    usage: TokenUsage = field(default_factory=TokenUsage)
    finish_reason: str = ""


@dataclass
class StreamChunk:
    """Incremental output from streaming LLM call."""
    delta_text: str = ""
    tool_call_index: int | None = None
    tool_call_id: str = ""
    tool_call_name: str = ""
    tool_call_args_delta: str = ""
    finish_reason: str = ""
    usage: TokenUsage | None = None


# ── Observation (loop orchestration layer) ───────────────────

class ActionStatus(str, Enum):
    """Normalized action outcome status."""
    OK = "ok"
    ERROR = "error"
    UNKNOWN = "unknown"


@dataclass
class Observation:
    """Structured observation of an action's result.

    Created from the raw result dict inside LoopRunner._observe_result().
    Serves as the normalization layer between execute_action() output
    and loop orchestration (recording, feedback, stop decisions).

    The raw_result is preserved for backward compatibility — history/ledger
    continue to receive the original dict unchanged.
    """
    action_type: str
    status: ActionStatus
    result_summary: str
    error: str = ""
    attachment: ContentBlock | None = None
    raw_result: dict[str, Any] = field(default_factory=dict)

    @staticmethod
    def from_result(action_type: str, result: Any) -> "Observation":
        """Create an Observation from a raw action result dict."""
        r = result if isinstance(result, dict) else {}

        # Status extraction
        status = ActionStatus.OK
        raw_status = r.get("status")
        if raw_status in ("ok", "error", "unknown"):
            status = ActionStatus(raw_status)
        elif r.get("error"):
            status = ActionStatus.ERROR

        # Summary extraction
        summary = ""
        if r.get("error"):
            summary = f"ERROR: {r['error'][:200]}"
        elif r.get("output"):
            summary = str(r["output"])[:200]
        elif r.get("thought"):
            summary = str(r["thought"])[:200]

        # Attachment extraction
        attachment = None
        if isinstance(r.get("attachment"), ContentBlock):
            attachment = r["attachment"]

        return Observation(
            action_type=action_type,
            status=status,
            result_summary=summary,
            error=str(r.get("error") or ""),
            attachment=attachment,
            raw_result=r,
        )


# ── Plan Tree ────────────────────────────────────────────────────

PlanNodeKind = str  # "branch" | "leaf"
PlanNodeStatus = str  # "pending" | "active" | "done" | "failed" | "blocked" | "skipped"

_VALID_NODE_KINDS = frozenset({"branch", "leaf"})
_VALID_NODE_STATUSES = frozenset({"pending", "active", "done", "failed", "blocked", "skipped"})
_PLAN_FORBIDDEN_ACTIONS = frozenset({"plan", "complete_task", "fail_task", "wait", "escalate"})


@dataclass
class PlanNode:
    """A single node in the plan tree."""
    id: str
    title: str
    kind: PlanNodeKind  # "branch" or "leaf"
    status: PlanNodeStatus = "pending"

    # Leaf-only: what action to execute and how to know it worked
    done_when: str | None = None
    action: dict[str, Any] | None = None  # Pascal action payload (never "plan")

    # Branch-only: ordered children and execution mode
    children: list["PlanNode"] = field(default_factory=list)
    branch_mode: str = "serial"  # "serial" | "parallel" — how to execute children

    # Execution hints (static scheduling metadata)
    executor: str | None = None  # "local" | "claude-code" | "codex" — who runs this leaf
    budget_seconds: int | None = None  # max wall-clock time for this node
    proof_required: list[str] | None = None  # evidence needed before marking done

    # Runtime repair metadata
    attempts: int = 0
    last_error: str | None = None

    def validate(self) -> list[str]:
        """Return list of validation errors. Empty = valid."""
        errors = []
        if self.kind not in _VALID_NODE_KINDS:
            errors.append(f"Node {self.id}: invalid kind '{self.kind}'")
        if self.status not in _VALID_NODE_STATUSES:
            errors.append(f"Node {self.id}: invalid status '{self.status}'")
        if self.kind == "leaf":
            if not self.done_when or not self.done_when.strip():
                errors.append(f"Node {self.id}: leaf requires done_when")
            if not self.action:
                errors.append(f"Node {self.id}: leaf requires action")
            elif self.action.get("action") in _PLAN_FORBIDDEN_ACTIONS:
                errors.append(f"Node {self.id}: leaf action '{self.action.get('action')}' is not allowed inside a plan")
            if self.children:
                errors.append(f"Node {self.id}: leaf must not have children")
        if self.kind == "branch":
            if not self.children:
                errors.append(f"Node {self.id}: branch requires children")
            if self.action is not None:
                errors.append(f"Node {self.id}: branch must not have action")
            for child in self.children:
                errors.extend(child.validate())
        return errors

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"id": self.id, "title": self.title, "kind": self.kind, "status": self.status}
        if self.done_when:
            d["done_when"] = self.done_when
        if self.action:
            d["action"] = self.action
        if self.children:
            d["children"] = [c.to_dict() for c in self.children]
        if self.branch_mode != "serial":
            d["branch_mode"] = self.branch_mode
        if self.executor:
            d["executor"] = self.executor
        if self.budget_seconds:
            d["budget_seconds"] = self.budget_seconds
        if self.proof_required:
            d["proof_required"] = self.proof_required
        if self.attempts:
            d["attempts"] = self.attempts
        if self.last_error:
            d["last_error"] = self.last_error
        return d

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "PlanNode":
        return PlanNode(
            id=data["id"],
            title=data.get("title", ""),
            kind=data.get("kind", "leaf"),
            status=data.get("status", "pending"),
            done_when=data.get("done_when"),
            action=data.get("action"),
            children=[PlanNode.from_dict(c) for c in data.get("children", [])],
            branch_mode=data.get("branch_mode", "serial"),
            executor=data.get("executor"),
            budget_seconds=data.get("budget_seconds"),
            proof_required=data.get("proof_required"),
            attempts=data.get("attempts", 0),
            last_error=data.get("last_error"),
        )

    def get_leaves(self) -> list["PlanNode"]:
        """Return all leaf nodes in depth-first order."""
        if self.kind == "leaf":
            return [self]
        leaves = []
        for child in self.children:
            leaves.extend(child.get_leaves())
        return leaves

    def find_node(self, node_id: str, _depth: int = 0) -> "PlanNode | None":
        if _depth > 50:
            return None
        if self.id == node_id:
            return self
        for child in self.children:
            found = child.find_node(node_id, _depth + 1)
            if found:
                return found
        return None

    def next_pending_leaf(self) -> "PlanNode | None":
        """Find the next pending leaf in depth-first order."""
        if self.kind == "leaf":
            return self if self.status == "pending" else None
        for child in self.children:
            found = child.next_pending_leaf()
            if found:
                return found
        return None

    def count_by_status(self) -> dict[str, int]:
        counts: dict[str, int] = {}
        if self.kind == "leaf":
            counts[self.status] = counts.get(self.status, 0) + 1
        for child in self.children:
            for status, count in child.count_by_status().items():
                counts[status] = counts.get(status, 0) + count
        return counts


@dataclass
class TaskPlan:
    """The execution plan for a task. Stored as JSON in tasks.plan_json."""
    version: int = 1
    revision: int = 0  # incremented on each replan
    active_node_id: str | None = None
    root: PlanNode | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "version": self.version,
            "revision": self.revision,
            "active_node_id": self.active_node_id,
            "root": self.root.to_dict() if self.root else None,
        }

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "TaskPlan":
        root_data = data.get("root")
        return TaskPlan(
            version=data.get("version", 1),
            revision=data.get("revision", 0),
            active_node_id=data.get("active_node_id"),
            root=PlanNode.from_dict(root_data) if root_data else None,
        )

    def validate(self) -> list[str]:
        if self.root is None:
            return ["Plan has no root node"]
        return self.root.validate()

    def pending_leaves(self) -> list[PlanNode]:
        """Get all pending leaves for compilation to steps array."""
        if self.root is None:
            return []
        return [leaf for leaf in self.root.get_leaves() if leaf.status == "pending"]

    def failed_leaves(self) -> list[PlanNode]:
        if self.root is None:
            return []
        return [leaf for leaf in self.root.get_leaves() if leaf.status == "failed"]


@dataclass
class PascalConfig:
    """Pascal configuration."""

    model: str = "gpt-5.4"
    provider: str = "openai"
    base_url: str = ""
    db_path: str = "~/.pascal/state.db"
    max_effect: str = "E2"  # E0-E5, daemon mode overrides to E3
    max_inner_turns: int | None = None
    max_tool_rounds: int | None = None


# ── Shared utilities (break circular deps) ──────────────────

def extract_json(text: str) -> str:
    """Extract the first complete JSON object from LLM response.

    Uses brace counting instead of rfind to avoid grabbing stray braces
    from error messages or prose that follows the JSON.
    """
    raw = text.strip()
    if raw.startswith("```"):
        raw = raw.strip("`")
        if raw.startswith("json"):
            raw = raw[4:].strip()
    start = raw.find("{")
    if start == -1:
        raise ValueError("No JSON object found")
    depth = 0
    in_string = False
    escape = False
    for i in range(start, len(raw)):
        ch = raw[i]
        if escape:
            escape = False
            continue
        if in_string:
            if ch == "\\":
                escape = True
            elif ch == '"':
                in_string = False
            continue
        if ch == '"':
            in_string = True
            continue
        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                return raw[start:i + 1]
    raise ValueError("No complete JSON object found")


def json_safe(obj: Any) -> Any:
    """Handle non-serializable objects in json.dumps (ContentBlock, dataclasses)."""
    if hasattr(obj, "__dataclass_fields__"):
        return {k: getattr(obj, k) for k in obj.__dataclass_fields__ if k != "data"}
    return f"<{type(obj).__name__}>"


def safe_json_loads(raw: Any, default: Any = None) -> Any:
    """Parse JSON string safely, returning default on failure."""
    if not isinstance(raw, str):
        return raw if isinstance(raw, (dict, list)) else (default if default is not None else {})
    try:
        return json.loads(raw)
    except (json.JSONDecodeError, TypeError, ValueError):
        return default if default is not None else {}
