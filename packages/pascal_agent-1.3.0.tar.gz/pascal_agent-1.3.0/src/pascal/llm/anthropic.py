"""pascal/llm/anthropic.py -- Anthropic 프로바이더."""

from __future__ import annotations

import logging
from types import ModuleType
from typing import TYPE_CHECKING, Any, Literal, TypeAlias

if TYPE_CHECKING:
    from anthropic import AsyncAnthropic
    from anthropic.types import (
        Base64ImageSourceParam,
        ImageBlockParam,
        MessageParam,
        TextBlockParam,
        ToolParam,
        ToolResultBlockParam,
        ToolUseBlockParam,
    )
else:
    AsyncAnthropic = Any
    Base64ImageSourceParam = dict[str, object]
    ImageBlockParam = dict[str, object]
    MessageParam = dict[str, object]
    TextBlockParam = dict[str, object]
    ToolParam = dict[str, object]
    ToolResultBlockParam = dict[str, object]
    ToolUseBlockParam = dict[str, object]

try:
    import anthropic as anthropic_module
except ImportError:  # pragma: no cover - optional dependency
    anthropic: ModuleType | None = None
else:
    anthropic = anthropic_module

from pascal.types import ContentBlock, LLMResponse, Message, Role, StreamChunk, TokenUsage, ToolCall

logger = logging.getLogger(__name__)

AnthropicImageMediaType = Literal["image/jpeg", "image/png", "image/gif", "image/webp"]
AnthropicContentBlock: TypeAlias = TextBlockParam | ImageBlockParam
AnthropicAssistantBlock: TypeAlias = AnthropicContentBlock | ToolUseBlockParam


class AnthropicProvider:
    """Anthropic Claude API를 사용하는 LLM 프로바이더."""

    _client: AsyncAnthropic

    def __init__(self, model: str = "claude-sonnet-4-20250514", base_url: str = "") -> None:
        if anthropic is None:
            raise ImportError(
                "Anthropic provider requires optional dependency: pip install pascal[anthropic]"
            )
        from anthropic import AsyncAnthropic

        if base_url:
            self._client = AsyncAnthropic(base_url=base_url)
        else:
            self._client = AsyncAnthropic()
        self._model = model

    @property
    def model(self) -> str:
        return self._model

    def _prepare_messages(
        self, messages: list[Message], tools: list[dict] | None = None,
    ) -> tuple[str | None, list[MessageParam], list | None]:
        """Convert Pascal messages to Anthropic API format. Shared by chat/chat_stream."""
        system_parts: list[str] = []
        api_messages: list[MessageParam] = []

        for m in messages:
            if m.role == Role.SYSTEM:
                system_parts.append(m.content)
            elif m.role == Role.ASSISTANT:
                content = self._build_assistant_content(m)
                api_messages.append({"role": "assistant", "content": content})
            elif m.role == Role.TOOL:
                tool_result: ToolResultBlockParam = {
                    "type": "tool_result",
                    "tool_use_id": m.tool_call_id,
                    "content": m.content,
                }
                if api_messages and api_messages[-1]["role"] == "user" and isinstance(api_messages[-1]["content"], list):
                    api_messages[-1]["content"].append(tool_result)
                else:
                    api_messages.append({"role": "user", "content": [tool_result]})
            else:
                user_msg = self._convert_user_message(m)
                if api_messages and api_messages[-1]["role"] == "user":
                    prev = api_messages[-1]
                    if isinstance(prev["content"], list):
                        if isinstance(user_msg["content"], list):
                            prev["content"].extend(user_msg["content"])
                        else:
                            prev["content"].append({"type": "text", "text": str(user_msg["content"])})
                    elif isinstance(prev["content"], str):
                        api_messages[-1] = {"role": "user", "content": [
                            {"type": "text", "text": prev["content"]},
                            {"type": "text", "text": str(user_msg.get("content", ""))},
                        ]}
                else:
                    api_messages.append(user_msg)

        system = "\n\n".join(system_parts) if system_parts else None
        converted_tools = self._convert_tools(tools) if tools else None
        return system, api_messages, converted_tools

    async def chat(
        self,
        messages: list[Message],
        tools: list[dict] | None = None,
    ) -> LLMResponse:
        system, api_messages, converted_tools = self._prepare_messages(messages, tools)

        if system is not None and converted_tools is not None:
            response = await self._client.messages.create(
                model=self._model,
                max_tokens=4096,
                messages=api_messages,
                system=system,
                tools=converted_tools,
            )
        elif system is not None:
            response = await self._client.messages.create(
                model=self._model,
                max_tokens=4096,
                messages=api_messages,
                system=system,
            )
        elif converted_tools is not None:
            response = await self._client.messages.create(
                model=self._model,
                max_tokens=4096,
                messages=api_messages,
                tools=converted_tools,
            )
        else:
            response = await self._client.messages.create(
                model=self._model,
                max_tokens=4096,
                messages=api_messages,
            )
        return self._parse_response(response)

    async def chat_stream(
        self,
        messages: list[Message],
        tools: list[dict] | None = None,
    ):
        """Streaming LLM call. Yields StreamChunk objects."""
        system, api_messages, converted_tools = self._prepare_messages(messages, tools)

        kwargs: dict[str, Any] = {
            "model": self._model,
            "max_tokens": 4096,
            "messages": api_messages,
            "stream": True,
        }
        if system is not None:
            kwargs["system"] = system
        if converted_tools is not None:
            kwargs["tools"] = converted_tools

        # Track tool call state across stream events
        current_tool_index = -1
        current_tool_id = ""
        current_tool_name = ""

        async with self._client.messages.stream(**{k: v for k, v in kwargs.items() if k != "stream"}) as stream:
            async for event in stream:
                event_type = getattr(event, "type", "")

                if event_type == "content_block_start":
                    block = getattr(event, "content_block", None)
                    if block and getattr(block, "type", "") == "tool_use":
                        current_tool_index += 1
                        current_tool_id = getattr(block, "id", "")
                        current_tool_name = getattr(block, "name", "")
                        yield StreamChunk(
                            tool_call_index=current_tool_index,
                            tool_call_id=current_tool_id,
                            tool_call_name=current_tool_name,
                        )

                elif event_type == "content_block_delta":
                    delta = getattr(event, "delta", None)
                    if delta:
                        delta_type = getattr(delta, "type", "")
                        if delta_type == "text_delta":
                            yield StreamChunk(delta_text=getattr(delta, "text", ""))
                        elif delta_type == "input_json_delta":
                            yield StreamChunk(
                                tool_call_index=current_tool_index,
                                tool_call_id=current_tool_id,
                                tool_call_name=current_tool_name,
                                tool_call_args_delta=getattr(delta, "partial_json", ""),
                            )

                elif event_type == "message_delta":
                    stop = getattr(getattr(event, "delta", None), "stop_reason", None)
                    if stop:
                        yield StreamChunk(finish_reason=stop)

    def _build_assistant_content(self, msg: Message) -> list[AnthropicAssistantBlock] | str:
        content: list[AnthropicAssistantBlock] = list(self._build_content_blocks(msg))
        tool_calls = getattr(msg, "tool_calls", None) or []
        if not tool_calls:
            return content or msg.content

        for tc in tool_calls:
            content.append(
                {
                    "type": "tool_use",
                    "id": tc.id,
                    "name": tc.name,
                    "input": tc.params,
                }
            )
        return content

    def _convert_user_message(self, msg: Message) -> MessageParam:
        content = self._build_content_blocks(msg)
        return {"role": "user", "content": content or msg.content}

    def _build_content_blocks(self, msg: Message) -> list[AnthropicContentBlock]:
        content: list[AnthropicContentBlock] = []
        if msg.content:
            content.append({"type": "text", "text": msg.content})
        for attachment in msg.attachments:
            block = self._convert_attachment(attachment)
            if block is not None:
                content.append(block)
        return content

    def _convert_attachment(self, attachment: ContentBlock) -> AnthropicContentBlock | None:
        if attachment.type == "image":
            media_type = self._normalize_image_media_type(attachment.mime_type)
            if media_type is None:
                logger.warning("Unsupported Anthropic image media type: %s", attachment.mime_type)
                return None
            source: Base64ImageSourceParam = {
                "type": "base64",
                "media_type": media_type,
                "data": attachment.data,
            }
            image_block: ImageBlockParam = {
                "type": "image",
                "source": source,
            }
            return image_block
        if attachment.type == "text":
            text_block: TextBlockParam = {"type": "text", "text": attachment.data}
            return text_block

        logger.warning("Unsupported content block for Anthropic provider: %s", attachment.type)
        return None

    @staticmethod
    def _normalize_image_media_type(mime_type: str) -> AnthropicImageMediaType | None:
        if mime_type == "image/jpeg":
            return "image/jpeg"
        if mime_type == "image/png":
            return "image/png"
        if mime_type == "image/gif":
            return "image/gif"
        if mime_type == "image/webp":
            return "image/webp"
        return None

    @staticmethod
    def _convert_tools(tools: list[dict]) -> list[ToolParam]:
        default_schema: dict[str, object] = {"type": "object", "properties": {}}
        result: list[ToolParam] = []
        for t in tools:
            func = t.get("function", t)
            name: str = func["name"]
            description: str = func.get("description", "")
            input_schema: dict[str, object] = func.get("parameters", default_schema)
            result.append(
                {
                    "name": name,
                    "description": description,
                    "input_schema": input_schema,
                }
            )
        return result

    @staticmethod
    def _parse_response(response) -> LLMResponse:
        text_parts = []
        tool_calls = []

        for block in response.content:
            if block.type == "text":
                text_parts.append(block.text)
            elif block.type == "tool_use":
                tool_calls.append(
                    ToolCall(
                        id=block.id,
                        name=block.name,
                        params=block.input,
                    )
                )

        text = "\n".join(text_parts) if text_parts else None
        usage = TokenUsage()
        if hasattr(response, "usage") and response.usage:
            usage = TokenUsage(
                prompt_tokens=getattr(response.usage, "input_tokens", 0) or 0,
                completion_tokens=getattr(response.usage, "output_tokens", 0) or 0,
                total_tokens=(getattr(response.usage, "input_tokens", 0) or 0) + (getattr(response.usage, "output_tokens", 0) or 0),
            )
        return LLMResponse(
            text=text, tool_calls=tool_calls, usage=usage,
            finish_reason=getattr(response, "stop_reason", "") or "",
        )
