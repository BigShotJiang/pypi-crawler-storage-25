"""pascal/llm/openai.py -- OpenAI 호환 프로바이더."""

from __future__ import annotations

import json
import logging
from typing import Literal, TypeAlias

import openai
from openai.types.chat import (
    ChatCompletionAssistantMessageParam,
    ChatCompletionContentPartImageParam,
    ChatCompletionContentPartParam,
    ChatCompletionContentPartTextParam,
    ChatCompletionFunctionToolParam,
    ChatCompletionMessageFunctionToolCallParam,
    ChatCompletionMessageParam,
    ChatCompletionSystemMessageParam,
    ChatCompletionToolMessageParam,
    ChatCompletionUserMessageParam,
)

from pascal.types import ContentBlock, LLMResponse, Message, Role, StreamChunk, TokenUsage, ToolCall

logger = logging.getLogger(__name__)

OpenAIImageDetail = Literal["auto", "low", "high"]
OpenAITextContent: TypeAlias = str | list[ChatCompletionContentPartTextParam]


class OpenAIProvider:
    """OpenAI Chat Completions API를 사용하는 LLM 프로바이더."""

    def __init__(self, model: str = "gpt-5.4", base_url: str = "") -> None:
        if base_url:
            self._client = openai.AsyncOpenAI(base_url=base_url)
        else:
            self._client = openai.AsyncOpenAI()
        self._model = model

    async def chat(
        self,
        messages: list[Message],
        tools: list[dict] | None = None,
    ) -> LLMResponse:
        api_messages: list[ChatCompletionMessageParam] = [self._convert_message(m) for m in messages]
        api_tools = self._convert_tools(tools) if tools else None

        if api_tools is not None:
            response = await self._client.chat.completions.create(
                model=self._model,
                messages=api_messages,
                tools=api_tools,
            )
        else:
            response = await self._client.chat.completions.create(
                model=self._model,
                messages=api_messages,
            )
        return self._parse_response(response)

    @property
    def model(self) -> str:
        return self._model

    async def chat_stream(
        self,
        messages: list[Message],
        tools: list[dict] | None = None,
    ):
        """Streaming LLM call. Yields StreamChunk objects."""
        api_messages: list[ChatCompletionMessageParam] = [self._convert_message(m) for m in messages]
        api_tools = self._convert_tools(tools) if tools else None
        kwargs: dict = {"model": self._model, "messages": api_messages, "stream": True}
        if api_tools is not None:
            kwargs["tools"] = api_tools
        stream = await self._client.chat.completions.create(**kwargs)
        async for chunk in stream:
            if not chunk.choices:
                continue
            delta = chunk.choices[0].delta
            finish = chunk.choices[0].finish_reason or ""
            if delta.content:
                yield StreamChunk(delta_text=delta.content, finish_reason=finish)
            if delta.tool_calls:
                for tc in delta.tool_calls:
                    sc = StreamChunk(
                        tool_call_index=tc.index,
                        tool_call_id=tc.id or "",
                        finish_reason=finish,
                    )
                    if tc.function:
                        sc.tool_call_name = tc.function.name or ""
                        sc.tool_call_args_delta = tc.function.arguments or ""
                    yield sc
            elif not delta.content:
                # Finish-only chunk (no content, no tool calls)
                if finish:
                    yield StreamChunk(finish_reason=finish)

    def _convert_message(self, msg: Message) -> ChatCompletionMessageParam:
        if msg.role == Role.TOOL:
            tool_message: ChatCompletionToolMessageParam = {
                "role": "tool",
                "tool_call_id": msg.tool_call_id,
                "content": msg.content,
            }
            return tool_message

        if msg.role == Role.SYSTEM:
            system_message: ChatCompletionSystemMessageParam = {
                "role": "system",
                "content": self._convert_text_content(msg),
            }
            return system_message

        if msg.role == Role.USER:
            user_message: ChatCompletionUserMessageParam = {
                "role": "user",
                "content": self._convert_content(msg),
            }
            return user_message

        if msg.role == Role.ASSISTANT and getattr(msg, "tool_calls", None):
            assistant_tool_calls: list[ChatCompletionMessageFunctionToolCallParam] = [
                {
                    "id": tc.id,
                    "type": "function",
                    "function": {
                        "name": tc.name,
                        "arguments": json.dumps(tc.params),
                    },
                }
                for tc in msg.tool_calls
            ]
            assistant_message: ChatCompletionAssistantMessageParam = {
                "role": "assistant",
                "content": self._convert_text_content(msg) or None,
                "tool_calls": assistant_tool_calls,
            }
            return assistant_message

        plain_assistant_message: ChatCompletionAssistantMessageParam = {
            "role": "assistant",
            "content": self._convert_text_content(msg),
        }
        return plain_assistant_message

    def _convert_content(self, msg: Message) -> str | list[ChatCompletionContentPartParam]:
        if not msg.attachments:
            return msg.content

        blocks: list[ChatCompletionContentPartParam] = []
        if msg.content:
            blocks.append({"type": "text", "text": msg.content})
        for attachment in msg.attachments:
            block = self._convert_attachment(attachment)
            if block is not None:
                blocks.append(block)
        return blocks

    def _convert_text_content(self, msg: Message) -> OpenAITextContent:
        if not msg.attachments:
            return msg.content

        blocks: list[ChatCompletionContentPartTextParam] = []
        if msg.content:
            blocks.append({"type": "text", "text": msg.content})
        for attachment in msg.attachments:
            if attachment.type == "text":
                blocks.append({"type": "text", "text": attachment.data})
            else:
                logger.warning(
                    "Unsupported non-text content block for OpenAI %s message: %s",
                    msg.role.value,
                    attachment.type,
                )
        return blocks

    def _convert_attachment(self, attachment: ContentBlock) -> ChatCompletionContentPartParam | None:
        if attachment.type == "image":
            image_block: ChatCompletionContentPartImageParam = {
                "type": "image_url",
                "image_url": {
                    "url": f"data:{attachment.mime_type};base64,{attachment.data}",
                    "detail": self._normalize_image_detail(attachment.detail),
                },
            }
            return image_block
        if attachment.type == "text":
            text_block: ChatCompletionContentPartTextParam = {"type": "text", "text": attachment.data}
            return text_block

        logger.warning("Unsupported content block for OpenAI provider: %s", attachment.type)
        return None

    @staticmethod
    def _normalize_image_detail(detail: str) -> OpenAIImageDetail:
        if detail == "low":
            return "low"
        if detail == "high":
            return "high"
        return "auto"

    @staticmethod
    def _convert_tools(tools: list[dict]) -> list[ChatCompletionFunctionToolParam]:
        default_parameters: dict[str, object] = {"type": "object", "properties": {}}
        result: list[ChatCompletionFunctionToolParam] = []
        for tool in tools:
            func = tool.get("function", tool)
            name: str = func["name"]
            description: str = func.get("description", "")
            parameters: dict[str, object] = func.get("parameters", default_parameters)
            result.append(
                {
                    "type": "function",
                    "function": {
                        "name": name,
                        "description": description,
                        "parameters": parameters,
                    },
                }
            )
        return result

    @classmethod
    def _parse_response(cls, response) -> LLMResponse:
        if not response.choices:
            return LLMResponse(text=None, tool_calls=[], usage=cls._parse_usage(getattr(response, "usage", None)))
        choice = response.choices[0]
        msg = choice.message

        return LLMResponse(
            text=msg.content,
            tool_calls=cls._parse_tool_calls(msg.tool_calls or []),
            usage=cls._parse_usage(getattr(response, "usage", None)),
            finish_reason=choice.finish_reason or "",
        )

    @staticmethod
    def _parse_tool_calls(raw_tool_calls) -> list[ToolCall]:
        tool_calls: list[ToolCall] = []
        for tc in raw_tool_calls:
            try:
                params = json.loads(tc.function.arguments)
            except json.JSONDecodeError:
                params = {}
            tool_calls.append(
                ToolCall(
                    id=tc.id,
                    name=tc.function.name,
                    params=params,
                )
            )
        return tool_calls

    @staticmethod
    def _parse_usage(raw_usage) -> TokenUsage:
        if raw_usage is None:
            return TokenUsage()
        return TokenUsage(
            prompt_tokens=int(getattr(raw_usage, "prompt_tokens", 0) or 0),
            completion_tokens=int(getattr(raw_usage, "completion_tokens", 0) or 0),
            total_tokens=int(getattr(raw_usage, "total_tokens", 0) or 0),
        )
