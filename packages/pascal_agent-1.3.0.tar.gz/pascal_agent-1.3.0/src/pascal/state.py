"""Pascal state -- SQLite store for the working-document loop.

13 tables:
  tasks, notifications, rules, run_lock, history, context, todos, memories,
  conversations, checkpoints, node_executions, task_artifacts, stagnation_log
  (+ memories_fts virtual table)
"""

from __future__ import annotations

import json
import logging
import re
import sqlite3
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path

from pascal.types import json_safe as _json_safe
from typing import Any, Callable

logger = logging.getLogger(__name__)


_SCHEMA = """
PRAGMA journal_mode = WAL;

CREATE TABLE IF NOT EXISTS tasks (
    id TEXT PRIMARY KEY,
    goal TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending'
        CHECK (status IN ('pending', 'active', 'paused', 'blocked', 'done', 'failed')),
    progress TEXT DEFAULT '',
    result TEXT,
    priority TEXT DEFAULT 'normal' CHECK (priority IN ('urgent', 'normal', 'low')),
    source TEXT DEFAULT 'human',
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE TABLE IF NOT EXISTS notifications (
    id TEXT PRIMARY KEY,
    source TEXT NOT NULL,
    message TEXT NOT NULL,
    priority TEXT DEFAULT 'normal' CHECK (priority IN ('urgent', 'normal', 'low')),
    event_type TEXT DEFAULT 'external_event',
    metadata TEXT DEFAULT '{}',
    status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'handled', 'dismissed')),
    received_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    handled_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_notif_status ON notifications(status, received_at);

CREATE TABLE IF NOT EXISTS rules (
    id TEXT PRIMARY KEY,
    rule TEXT NOT NULL,
    tier TEXT NOT NULL DEFAULT 'learned'
        CHECK (tier IN ('policy', 'operator', 'learned', 'ephemeral')),
    mutable INTEGER NOT NULL DEFAULT 1 CHECK (mutable IN (0, 1)),
    added_by TEXT NOT NULL DEFAULT 'human' CHECK (added_by IN ('human', 'agent')),
    expires_at TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

-- Concurrency: single-run lock
CREATE TABLE IF NOT EXISTS run_lock (
    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
    locked_by TEXT NOT NULL,
    locked_at TEXT NOT NULL,
    expires_at TEXT NOT NULL
);


CREATE TABLE IF NOT EXISTS history (
    id TEXT PRIMARY KEY,
    summary TEXT NOT NULL,
    task_id TEXT REFERENCES tasks(id),
    details TEXT DEFAULT '{}',
    idem_key TEXT,
    action_status TEXT DEFAULT 'ok' CHECK (action_status IN ('ok', 'error', 'unknown')),
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE INDEX IF NOT EXISTS idx_history_time ON history(created_at);
CREATE UNIQUE INDEX IF NOT EXISTS idx_history_idem ON history(idem_key) WHERE idem_key IS NOT NULL;

CREATE TRIGGER IF NOT EXISTS history_no_update
BEFORE UPDATE ON history BEGIN
    SELECT RAISE(ABORT, 'history is append-only: updates not allowed');
END;

CREATE TRIGGER IF NOT EXISTS history_no_delete
BEFORE DELETE ON history BEGIN
    SELECT RAISE(ABORT, 'history is append-only: deletes not allowed');
END;

CREATE TABLE IF NOT EXISTS context (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE TABLE IF NOT EXISTS todos (
    id TEXT PRIMARY KEY,
    task_id TEXT NOT NULL REFERENCES tasks(id),
    title TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending'
        CHECK (status IN ('pending', 'done', 'skipped')),
    ordinal INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE INDEX IF NOT EXISTS idx_todos_task ON todos(task_id, ordinal);

CREATE TABLE IF NOT EXISTS memories (
    id TEXT PRIMARY KEY,
    kind TEXT NOT NULL CHECK (kind IN ('fact', 'lesson', 'preference', 'procedure')),
    content TEXT NOT NULL,
    source_task_id TEXT REFERENCES tasks(id),
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE INDEX IF NOT EXISTS idx_memories_kind ON memories(kind, created_at);

CREATE TABLE IF NOT EXISTS conversations (
    id TEXT PRIMARY KEY,
    channel TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('user', 'assistant')),
    content TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE INDEX IF NOT EXISTS idx_convo_channel ON conversations(channel, created_at DESC);

"""


class PascalStore:
    """Minimal persistence for the Pascal loop."""

    def __init__(self, db_path: str) -> None:
        path = Path(db_path).expanduser()
        path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(path))
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA foreign_keys = ON")
        self._conn.executescript(_SCHEMA)
        self._conn.commit()
        self._migrate_commitments()
        self._migrate_context_ttl()
        self._migrate_checkpoints()
        self._migrate_memory_fts()
        self._migrate_task_hierarchy()
        self._migrate_plan_json()
        self._migrate_notifications()
        self._migrate_stagnation_log()
        self._migrate_history_pruning()
        self._migrate_node_executions()
        self._migrate_task_artifacts()
        self._embedding_fn: Callable[[str], list[float]] | None = None

    @property
    def connection(self) -> sqlite3.Connection:
        return self._conn

    def close(self) -> None:
        self._conn.close()

    # ── Run lock (concurrency) ───────────────────────────────────

    _LOCK_TTL_SECONDS = 300  # 5 minutes; refresh_lock extends during active runs
    _lock_owner: str = ""

    def acquire_lock(self, run_id: str) -> bool:
        """Try to acquire the single-run lock. Returns True if acquired."""
        now = datetime.now(timezone.utc)
        expires = now.strftime("%Y-%m-%dT%H:%M:%S.%fZ")
        new_expires = (now + timedelta(seconds=self._LOCK_TTL_SECONDS)).strftime(
            "%Y-%m-%dT%H:%M:%S.%fZ"
        )
        # Clear expired locks (commit separately to ensure cleanup)
        self._conn.execute(
            "DELETE FROM run_lock WHERE expires_at < ?", (expires,),
        )
        self._conn.commit()
        try:
            self._conn.execute(
                "INSERT INTO run_lock (singleton, locked_by, locked_at, expires_at) VALUES (1, ?, ?, ?)",
                (run_id, expires, new_expires),
            )
            self._conn.commit()
            self._lock_owner = run_id
            return True
        except sqlite3.IntegrityError:
            return False

    def refresh_lock(self) -> None:
        """Extend the lock TTL. Only the lock owner can refresh."""
        if not self._lock_owner:
            return
        new_expires = (
            datetime.now(timezone.utc) + timedelta(seconds=self._LOCK_TTL_SECONDS)
        ).strftime("%Y-%m-%dT%H:%M:%S.%fZ")
        self._conn.execute(
            "UPDATE run_lock SET expires_at = ? WHERE singleton = 1 AND locked_by = ?",
            (new_expires, self._lock_owner),
        )
        self._conn.commit()

    def release_lock(self, force: bool = False) -> None:
        """Release the lock. Only the lock owner can release, unless force=True."""
        if self._lock_owner:
            self._conn.execute(
                "DELETE FROM run_lock WHERE singleton = 1 AND locked_by = ?",
                (self._lock_owner,),
            )
        elif force:
            # Daemon startup: clear stale/expired locks from previous crash
            now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")
            self._conn.execute(
                "DELETE FROM run_lock WHERE singleton = 1 AND expires_at < ?",
                (now,),
            )
        self._conn.commit()
        self._lock_owner = ""

    # ── Tasks ────────────────────────────────────────────────────

    # Valid state transitions -- any transition not here is rejected
    _TASK_TRANSITIONS: dict[str, set[str]] = {
        "pending": {"active", "blocked", "done", "failed"},
        "active": {"paused", "blocked", "done", "failed"},
        "paused": {"active", "done", "failed"},
        "blocked": {"active", "done", "failed"},
        "done": set(),      # terminal
        "failed": {"active", "pending"},  # can retry
    }

    def add_task(
        self,
        goal: str,
        *,
        priority: str = "normal",
        source: str = "human",
        promised_to: list[str] | None = None,
        due_at: str | None = None,
        proof_required: list[str] | None = None,
        depends_on: list[str] | None = None,
        parent_id: str | None = None,
    ) -> str:
        task_id = _make_id("task")
        self._conn.execute(
            "INSERT INTO tasks (id, goal, priority, source, promised_to, due_at, proof_required, depends_on, parent_id) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (task_id, goal, priority, source,
             json.dumps(promised_to) if promised_to else None,
             due_at,
             json.dumps(proof_required) if proof_required else None,
             json.dumps(depends_on) if depends_on else None,
             parent_id),
        )
        self._conn.commit()
        return task_id

    def get_active_task(self) -> dict[str, Any] | None:
        row = self._conn.execute(
            "SELECT * FROM tasks WHERE status = 'active' ORDER BY updated_at DESC LIMIT 1",
        ).fetchone()
        return dict(row) if row else None

    def get_pending_tasks(self) -> list[dict[str, Any]]:
        rows = self._conn.execute(
            """SELECT * FROM tasks WHERE status = 'pending'
               ORDER BY CASE priority WHEN 'urgent' THEN 0 WHEN 'normal' THEN 1 ELSE 2 END,
                        created_at ASC""",
        ).fetchall()
        return [dict(r) for r in rows]

    def activate_task(self, task_id: str) -> None:
        task = self._conn.execute("SELECT status FROM tasks WHERE id = ?", (task_id,)).fetchone()
        if task is None:
            raise KeyError(f"Unknown task: {task_id}")
        allowed = self._TASK_TRANSITIONS.get(task["status"], set())
        if "active" not in allowed:
            raise ValueError(f"Cannot activate task in '{task['status']}' state (allowed: {allowed})")
        # Ensure single active task invariant
        self._conn.execute(
            "UPDATE tasks SET status = 'paused', updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') "
            "WHERE status = 'active' AND id != ?",
            (task_id,),
        )
        self._conn.execute(
            "UPDATE tasks SET status = 'active', updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?",
            (task_id,),
        )
        self._conn.commit()

    def update_task(self, task_id: str, *, status: str | None = None, progress: str | None = None, result: str | None = None) -> None:
        task = self._conn.execute("SELECT * FROM tasks WHERE id = ?", (task_id,)).fetchone()
        if task is None:
            raise KeyError(f"Unknown task: {task_id}")
        # Enforce valid state transitions
        if status is not None and status != task["status"]:
            allowed = self._TASK_TRANSITIONS.get(task["status"], set())
            if status not in allowed:
                raise ValueError(
                    f"Invalid task transition: {task['status']} -> {status} "
                    f"(allowed: {allowed or 'none -- terminal state'})"
                )
        self._conn.execute(
            """UPDATE tasks SET status = ?, progress = ?, result = ?,
               updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?""",
            (
                status if status is not None else task["status"],
                progress if progress is not None else task["progress"],
                result if result is not None else task["result"],
                task_id,
            ),
        )
        self._conn.commit()

    def pause_active_task(self, reason: str = "") -> str | None:
        """Pause the current active task. Returns task_id if paused."""
        active = self.get_active_task()
        if active is None:
            return None
        self.update_task(active["id"], status="paused", progress=f"Paused: {reason}")
        return active["id"]

    # ── Plan Tree ─────────────────────────────────────────────────

    def get_task_plan(self, task_id: str) -> dict[str, Any] | None:
        """Get the plan tree for a task. Returns raw dict or None."""
        row = self._conn.execute(
            "SELECT plan_json FROM tasks WHERE id = ?", (task_id,),
        ).fetchone()
        if row is None or not row["plan_json"]:
            return None
        try:
            return json.loads(row["plan_json"])
        except (json.JSONDecodeError, TypeError):
            return None

    def set_task_plan(self, task_id: str, plan: dict[str, Any]) -> None:
        """Store/update the plan tree for a task."""
        self._conn.execute(
            "UPDATE tasks SET plan_json = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?",
            (json.dumps(plan, ensure_ascii=False, default=_json_safe), task_id),
        )
        self._conn.commit()

    def clear_task_plan(self, task_id: str) -> None:
        """Remove the plan tree from a task."""
        self._conn.execute(
            "UPDATE tasks SET plan_json = NULL, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?",
            (task_id,),
        )
        self._conn.commit()

    # ── Notifications ────────────────────────────────────────────

    def push_notification(
        self,
        *,
        source: str,
        message: str,
        priority: str = "normal",
        metadata: dict[str, Any] | None = None,
        event_type: str = "external_event",
    ) -> str:
        notif_id = _make_id("notif")
        self._conn.execute(
            "INSERT INTO notifications (id, source, message, priority, event_type, metadata) VALUES (?, ?, ?, ?, ?, ?)",
            (
                notif_id,
                source,
                message,
                priority,
                event_type,
                json.dumps(metadata or {}, ensure_ascii=False, default=_json_safe),
            ),
        )
        self._conn.commit()
        return notif_id

    def expire_stale_notifications(self, max_age_minutes: int = 30) -> int:
        cursor = self._conn.execute(
            """UPDATE notifications SET status = 'dismissed', handled_at = strftime('%Y-%m-%dT%H:%M:%fZ','now')
               WHERE status = 'pending'
               AND received_at < strftime('%Y-%m-%dT%H:%M:%fZ', 'now', ?)""",
            (f"-{max_age_minutes} minutes",),
        )
        self._conn.commit()
        return cursor.rowcount

    def get_pending_notifications(self, include_low: bool = True) -> list[dict[str, Any]]:
        where = "WHERE status = 'pending'"
        if not include_low:
            where += " AND priority != 'low'"
        rows = self._conn.execute(
            f"""SELECT * FROM notifications {where}
               ORDER BY CASE priority WHEN 'urgent' THEN 0 WHEN 'normal' THEN 1 ELSE 2 END,
                        received_at ASC
               LIMIT 10""",
        ).fetchall()
        return [dict(r) for r in rows]

    def handle_notification(self, notif_id: str) -> None:
        self._conn.execute(
            "UPDATE notifications SET status = 'handled', handled_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?",
            (notif_id,),
        )
        self._conn.commit()

    def dismiss_notification(self, notif_id: str) -> None:
        self._conn.execute(
            "UPDATE notifications SET status = 'dismissed', handled_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?",
            (notif_id,),
        )
        self._conn.commit()

    # ── Rules ────────────────────────────────────────────────────

    _RULE_TIERS = ("policy", "operator", "learned", "ephemeral")

    def add_rule(self, rule: str, *, tier: str = "learned", mutable: bool = True, added_by: str = "human", ttl_hours: int | None = None) -> str:
        if tier not in self._RULE_TIERS:
            tier = "learned"
        # policy tier is always immutable, agent cannot add policy/operator
        if tier == "policy":
            mutable = False
            added_by = "human"
        if tier == "operator" and added_by == "agent":
            tier = "learned"  # agent can't escalate to operator tier
        expires_at = None
        if tier == "ephemeral" or ttl_hours is not None:
            hours = ttl_hours if ttl_hours is not None else 24
            expires_at = (datetime.now(timezone.utc) + timedelta(hours=hours)).strftime(
                "%Y-%m-%dT%H:%M:%S.%fZ"
            )
        rule_id = _make_id("rule")
        self._conn.execute(
            "INSERT INTO rules (id, rule, tier, mutable, added_by, expires_at) VALUES (?, ?, ?, ?, ?, ?)",
            (rule_id, rule, tier, int(mutable), added_by, expires_at),
        )
        self._conn.commit()
        return rule_id

    def get_rules(self) -> list[dict[str, Any]]:
        # Clean expired ephemeral rules
        now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")
        self._conn.execute(
            "DELETE FROM rules WHERE expires_at IS NOT NULL AND expires_at < ?", (now,),
        )
        self._conn.commit()
        # Return sorted by tier priority: policy > operator > learned > ephemeral
        rows = self._conn.execute(
            """SELECT * FROM rules ORDER BY
               CASE tier WHEN 'policy' THEN 0 WHEN 'operator' THEN 1
                         WHEN 'learned' THEN 2 WHEN 'ephemeral' THEN 3 END,
               created_at ASC""",
        ).fetchall()
        return [dict(r) for r in rows]

    def remove_rule(self, rule_id: str) -> bool:
        """Remove a mutable rule. Returns False if rule is immutable."""
        rule = self._conn.execute("SELECT mutable FROM rules WHERE id = ?", (rule_id,)).fetchone()
        if rule is None:
            return False
        if not rule["mutable"]:
            return False
        self._conn.execute("DELETE FROM rules WHERE id = ?", (rule_id,))
        self._conn.commit()
        return True

    # ── History ──────────────────────────────────────────────────

    def record(
        self,
        summary: str,
        *,
        task_id: str | None = None,
        details: dict[str, Any] | None = None,
        idem_key: str | None = None,
        action_status: str = "ok",
    ) -> None:
        if action_status not in ("ok", "error", "unknown"):
            action_status = "ok"
        try:
            self._conn.execute(
                "INSERT OR IGNORE INTO history (id, summary, task_id, details, idem_key, action_status) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (_make_id("hist"), summary, task_id, json.dumps(details or {}, ensure_ascii=False, default=_json_safe),
                 idem_key, action_status),
            )
            self._conn.commit()
        except sqlite3.IntegrityError:
            pass  # duplicate idem_key

    def get_recent_history(self, limit: int = 10) -> list[dict[str, Any]]:
        rows = self._conn.execute(
            "SELECT * FROM history ORDER BY created_at DESC LIMIT ?", (limit,),
        ).fetchall()
        return [dict(r) for r in reversed(rows)]

    def get_context(self, key: str) -> Any | None:
        row = self._conn.execute(
            "SELECT value, expires_at FROM context WHERE key = ?", (key,),
        ).fetchone()
        if row is None:
            return None
        # Respect TTL: if expired, clean up and return None
        if row["expires_at"]:
            from datetime import datetime, timezone
            try:
                if datetime.fromisoformat(row["expires_at"].replace("Z", "+00:00")) < datetime.now(timezone.utc):
                    self._conn.execute("DELETE FROM context WHERE key = ?", (key,))
                    self._conn.commit()
                    return None
            except (ValueError, TypeError):
                pass
        try:
            return json.loads(row["value"])
        except (json.JSONDecodeError, TypeError):
            return row["value"]

    # ── TODOs ─────────────────────────────────────────────────────

    def add_todo(self, *, task_id: str, title: str) -> str:
        todo_id = _make_id("todo")
        max_ord = self._conn.execute(
            "SELECT COALESCE(MAX(ordinal), 0) AS m FROM todos WHERE task_id = ?",
            (task_id,),
        ).fetchone()["m"]
        self._conn.execute(
            "INSERT INTO todos (id, task_id, title, ordinal) VALUES (?, ?, ?, ?)",
            (todo_id, task_id, title, max_ord + 1),
        )
        self._conn.commit()
        return todo_id

    def complete_todo(self, todo_id: str) -> None:
        self._conn.execute(
            "UPDATE todos SET status = 'done' WHERE id = ?", (todo_id,),
        )
        self._conn.commit()

    def get_todos(self, task_id: str) -> list[dict[str, Any]]:
        rows = self._conn.execute(
            "SELECT * FROM todos WHERE task_id = ? ORDER BY ordinal ASC",
            (task_id,),
        ).fetchall()
        return [dict(r) for r in rows]

    # ── Memories ─────────────────────────────────────────────────

    def add_memory(self, *, kind: str, content: str, source_task_id: str | None = None) -> str:
        # Dedup: skip if identical memory already exists
        existing = self._conn.execute(
            "SELECT id FROM memories WHERE kind = ? AND content = ? LIMIT 1",
            (kind, content.strip()),
        ).fetchone()
        if existing:
            return existing["id"]

        mem_id = _make_id("mem")
        self._conn.execute(
            "INSERT INTO memories (id, kind, content, source_task_id) VALUES (?, ?, ?, ?)",
            (mem_id, kind, content, source_task_id),
        )
        # Update FTS index
        try:
            rowid = self._conn.execute("SELECT rowid FROM memories WHERE id = ?", (mem_id,)).fetchone()
            if rowid:
                self._conn.execute(
                    "INSERT INTO memories_fts(rowid, content, kind) VALUES (?, ?, ?)",
                    (rowid[0], content, kind),
                )
        except Exception:
            pass  # FTS update failure is non-fatal
        self._conn.commit()
        self._prune_memories()
        return mem_id

    def _prune_memories(self, max_entries: int = 500) -> None:
        count = self._conn.execute("SELECT COUNT(*) FROM memories").fetchone()[0]
        if count <= max_entries:
            return
        to_delete = count - max_entries
        ids = self._conn.execute(
            "SELECT id FROM memories ORDER BY created_at ASC LIMIT ?", (to_delete,),
        ).fetchall()
        for row in ids:
            self.delete_memory(row["id"])

    def delete_memory(self, mem_id: str) -> bool:
        """Delete a memory and its FTS5 index entry. Returns True if deleted."""
        row = self._conn.execute(
            "SELECT rowid, content, kind FROM memories WHERE id = ?", (mem_id,),
        ).fetchone()
        if not row:
            return False
        # Remove from FTS5 content-synced table (requires explicit delete command)
        try:
            self._conn.execute(
                "INSERT INTO memories_fts(memories_fts, rowid, content, kind) VALUES('delete', ?, ?, ?)",
                (row["rowid"], row["content"], row["kind"]),
            )
        except Exception:
            pass  # FTS cleanup failure is non-fatal
        self._conn.execute("DELETE FROM memories WHERE id = ?", (mem_id,))
        self._conn.commit()
        return True

    def get_memories(self, *, kind: str | None = None, limit: int = 20) -> list[dict[str, Any]]:
        if kind:
            rows = self._conn.execute(
                "SELECT * FROM memories WHERE kind = ? ORDER BY created_at DESC LIMIT ?",
                (kind, limit),
            ).fetchall()
        else:
            rows = self._conn.execute(
                "SELECT * FROM memories ORDER BY created_at DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [dict(r) for r in rows]

    def search_memories(self, query: str, *, limit: int = 8) -> list[dict[str, Any]]:
        """Search memories by relevance. Tries embedding similarity, then FTS5, then recency."""
        if not query or not query.strip():
            return self.get_memories(limit=limit)

        # Tier 1: Embedding-based semantic search (if provider available)
        if self._embedding_fn is not None:
            try:
                return self._search_by_embedding(query, limit)
            except Exception:
                pass  # fall through to FTS5

        # Tier 2: FTS5 keyword search
        try:
            import re as _re
            clean = _re.sub(r'[^\w\s]', ' ', query)
            tokens = [t for t in clean.split() if t.strip() and len(t) > 1]
            if not tokens:
                return self.get_memories(limit=limit)
            fts_query = " OR ".join(f'"{t}"*' for t in tokens[:10])
            rows = self._conn.execute(
                """SELECT m.* FROM memories m
                   JOIN memories_fts f ON m.rowid = f.rowid
                   WHERE memories_fts MATCH ?
                   ORDER BY rank
                   LIMIT ?""",
                (fts_query, limit),
            ).fetchall()
            if rows:
                return [dict(r) for r in rows]
        except Exception:
            logger.debug("FTS search failed, falling back to recency", exc_info=True)
        # Tier 3: Recent memories
        return self.get_memories(limit=limit)

    def set_embedding_fn(self, fn: Callable[[str], list[float]]) -> None:
        """Set an embedding function: fn(text) -> list[float]. Enables semantic memory search."""
        self._embedding_fn = fn

    def _search_by_embedding(self, query: str, limit: int) -> list[dict[str, Any]]:
        """Semantic search using cosine similarity of embeddings."""
        embed = self._embedding_fn
        if embed is None:
            return []
        query_emb = embed(query)
        all_mems = self.get_memories(limit=100)
        if not all_mems:
            return []
        scored = []
        for mem in all_mems:
            mem_emb = embed(mem["content"][:500])
            sim = _cosine_similarity(query_emb, mem_emb)
            scored.append((sim, mem))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [m for _, m in scored[:limit]]

    # ── Conversations ─────────────────────────────────────────────

    def push_conversation_turn(self, channel: str, role: str, content: str) -> str:
        turn_id = _make_id("conv")
        self._conn.execute(
            "INSERT INTO conversations (id, channel, role, content) VALUES (?, ?, ?, ?)",
            (turn_id, channel, role, content),
        )
        self._conn.commit()
        return turn_id

    def get_recent_conversation(self, channel: str, limit: int = 10) -> list[dict[str, Any]]:
        rows = self._conn.execute(
            "SELECT * FROM conversations WHERE channel = ? ORDER BY created_at DESC LIMIT ?",
            (channel, limit),
        ).fetchall()
        return [dict(r) for r in reversed(rows)]  # oldest first for natural reading

    # ── Context (with TTL) ───────────────────────────────────────

    def set_context(self, key: str, value: Any, ttl_hours: int | None = None) -> None:
        expires_at = None
        if ttl_hours is not None and ttl_hours > 0:
            expires_at = (datetime.now(timezone.utc) + timedelta(hours=ttl_hours)).strftime(
                "%Y-%m-%dT%H:%M:%S.%fZ"
            )
        val = json.dumps(value, ensure_ascii=False, default=_json_safe) if not isinstance(value, str) else value
        self._conn.execute(
            """INSERT INTO context (key, value, expires_at, updated_at)
               VALUES (?, ?, ?, strftime('%Y-%m-%dT%H:%M:%fZ','now'))
               ON CONFLICT(key) DO UPDATE SET value=excluded.value, expires_at=excluded.expires_at,
               updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now')""",
            (key, val, expires_at),
        )
        self._conn.commit()
        self._enforce_context_limit()

    def get_all_context(self) -> dict[str, Any]:
        self.cleanup_expired_context()
        rows = self._conn.execute("SELECT key, value FROM context ORDER BY key").fetchall()
        result = {}
        for row in rows:
            try:
                result[row["key"]] = json.loads(row["value"])
            except (json.JSONDecodeError, TypeError):
                result[row["key"]] = row["value"]
        return result

    def delete_context(self, key: str) -> bool:
        cursor = self._conn.execute("DELETE FROM context WHERE key = ?", (key,))
        self._conn.commit()
        return cursor.rowcount > 0

    def cleanup_expired_context(self) -> int:
        now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")
        cursor = self._conn.execute(
            "DELETE FROM context WHERE expires_at IS NOT NULL AND expires_at < ?", (now,),
        )
        self._conn.commit()
        return cursor.rowcount

    def _enforce_context_limit(self, max_entries: int = 100) -> None:
        count = self._conn.execute("SELECT COUNT(*) FROM context").fetchone()[0]
        if count <= max_entries:
            return
        to_delete = count - max_entries
        self._conn.execute(
            "DELETE FROM context WHERE key IN "
            "(SELECT key FROM context ORDER BY updated_at ASC LIMIT ?)",
            (to_delete,),
        )
        self._conn.commit()

    # ── Checkpoints ──────────────────────────────────────────────

    def save_checkpoint(self, task_id: str, iteration: int, loop_state: dict[str, Any]) -> str:
        cp_id = _make_id("cp")
        pending_notifs = [r["id"] for r in self._conn.execute(
            "SELECT id FROM notifications WHERE status = 'pending'"
        ).fetchall()]
        recent_hist = [r["id"] for r in self._conn.execute(
            "SELECT id FROM history ORDER BY created_at DESC LIMIT 5"
        ).fetchall()]
        ctx_keys = [r["key"] for r in self._conn.execute("SELECT key FROM context").fetchall()]
        task = self._conn.execute(
            "SELECT status, progress FROM tasks WHERE id = ?", (task_id,),
        ).fetchone()
        snapshot = {
            "task_id": task_id,
            "task_status": task["status"] if task else None,
            "task_progress": task["progress"] if task else None,
            "iteration": iteration,
            "has_unknown_step": loop_state.get("has_unknown_step", False),
            "thought_buffer": loop_state.get("thought_buffer", []),
            "error_feedback": loop_state.get("error_feedback", ""),
            "compaction_count": loop_state.get("compaction_count", 0),
            "consecutive_errors": loop_state.get("consecutive_errors", 0),
            "active_context_keys": ctx_keys,
            "pending_notification_ids": pending_notifs,
            "recent_history_ids": recent_hist,
        }
        self._conn.execute(
            "INSERT INTO checkpoints (id, task_id, iteration, snapshot_json) VALUES (?, ?, ?, ?)",
            (cp_id, task_id, iteration, json.dumps(snapshot, ensure_ascii=False, default=_json_safe)),
        )
        self._conn.commit()
        self._prune_checkpoints(task_id)
        return cp_id

    def get_latest_checkpoint(self, task_id: str) -> dict[str, Any] | None:
        row = self._conn.execute(
            "SELECT * FROM checkpoints WHERE task_id = ? ORDER BY iteration DESC, created_at DESC LIMIT 1",
            (task_id,),
        ).fetchone()
        if not row:
            return None
        return {
            "id": row["id"], "task_id": row["task_id"],
            "iteration": row["iteration"],
            "snapshot": json.loads(row["snapshot_json"]),
            "created_at": row["created_at"],
        }

    def _prune_checkpoints(self, task_id: str, keep: int = 10) -> None:
        self._conn.execute(
            "DELETE FROM checkpoints WHERE task_id = ? AND id NOT IN "
            "(SELECT id FROM checkpoints WHERE task_id = ? ORDER BY created_at DESC LIMIT ?)",
            (task_id, task_id, keep),
        )
        self._conn.commit()

    # ── Migrations ───────────────────────────────────────────────

    # Whitelist of valid identifiers for dynamic SQL in migrations
    _VALID_TABLES = frozenset({"tasks", "context", "memories", "checkpoints", "notifications", "rules", "history", "conversations", "todos"})
    _VALID_COL_TYPES = frozenset({"TEXT", "INTEGER", "REAL", "BLOB", "INTEGER DEFAULT 0"})
    _IDENT_RE = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]*$")

    def _ensure_column(self, table: str, column: str, col_type: str = "TEXT") -> None:
        # Validate identifiers to prevent SQL injection (defense-in-depth)
        if table not in self._VALID_TABLES:
            raise ValueError(f"Invalid table name for migration: {table}")
        if not self._IDENT_RE.match(column):
            raise ValueError(f"Invalid column name for migration: {column}")
        if col_type not in self._VALID_COL_TYPES:
            raise ValueError(f"Invalid column type for migration: {col_type}")
        try:
            self._conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {col_type}")
            self._conn.commit()
        except sqlite3.OperationalError:
            pass

    def _migrate_commitments(self) -> None:
        for col in ("promised_to", "due_at", "proof_required", "depends_on"):
            self._ensure_column("tasks", col)

    def _migrate_context_ttl(self) -> None:
        self._ensure_column("context", "expires_at")

    def _migrate_checkpoints(self) -> None:
        self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS checkpoints (
                id TEXT PRIMARY KEY,
                task_id TEXT NOT NULL REFERENCES tasks(id),
                iteration INTEGER NOT NULL,
                snapshot_json TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
            );
            CREATE INDEX IF NOT EXISTS idx_checkpoints_task
                ON checkpoints(task_id, created_at DESC);
        """)
        self._conn.commit()

    def _migrate_memory_fts(self) -> None:
        """Create FTS5 virtual table for memory search."""
        self._conn.executescript("""
            CREATE VIRTUAL TABLE IF NOT EXISTS memories_fts
                USING fts5(content, kind, content=memories, content_rowid=rowid);
        """)
        # Populate FTS from existing data (skip rows already indexed)
        self._conn.execute("""
            INSERT INTO memories_fts(rowid, content, kind)
            SELECT m.rowid, m.content, m.kind FROM memories m
            WHERE m.rowid NOT IN (SELECT rowid FROM memories_fts)
        """)
        self._conn.commit()

    def _migrate_task_hierarchy(self) -> None:
        """Add parent_id for hierarchical task decomposition."""
        self._ensure_column("tasks", "parent_id", "TEXT")

    def _migrate_plan_json(self) -> None:
        """Add plan_json for plan tree storage."""
        self._ensure_column("tasks", "plan_json", "TEXT")

    def _migrate_notifications(self) -> None:
        cols = {
            row[1]
            for row in self._conn.execute("PRAGMA table_info(notifications)").fetchall()
        }
        if "event_type" not in cols:
            self._conn.execute(
                "ALTER TABLE notifications ADD COLUMN event_type TEXT DEFAULT 'external_event'"
            )
            self._conn.commit()


    def _migrate_history_pruning(self) -> None:
        """Replace rigid no-delete trigger with one that allows pruning old rows."""
        self._conn.executescript("""
            DROP TRIGGER IF EXISTS history_no_delete;
            CREATE TRIGGER IF NOT EXISTS history_no_delete_recent
            BEFORE DELETE ON history
            WHEN OLD.created_at > strftime('%Y-%m-%dT%H:%M:%fZ', 'now', '-30 days')
            BEGIN
                SELECT RAISE(ABORT, 'cannot delete history newer than 30 days');
            END;
        """)
        self._conn.commit()

    def prune_history(self, keep_days: int = 30) -> int:
        """Delete history rows older than keep_days. Returns count deleted."""
        cursor = self._conn.execute(
            "DELETE FROM history WHERE created_at < strftime('%Y-%m-%dT%H:%M:%fZ', 'now', ?)",
            (f"-{keep_days} days",),
        )
        self._conn.commit()
        return cursor.rowcount

    def _migrate_node_executions(self) -> None:
        """Track parallel plan node execution state."""
        self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS node_executions (
                id TEXT PRIMARY KEY,
                task_id TEXT NOT NULL REFERENCES tasks(id),
                plan_revision INTEGER NOT NULL DEFAULT 0,
                node_id TEXT NOT NULL,
                executor TEXT NOT NULL DEFAULT 'local',
                status TEXT NOT NULL DEFAULT 'pending'
                    CHECK (status IN ('pending', 'claimed', 'running', 'done', 'failed', 'verified')),
                worker_task_id TEXT,
                claim_json TEXT DEFAULT '{}',
                evidence_json TEXT DEFAULT '{}',
                heartbeat_at TEXT,
                verified_at TEXT,
                created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
            );
            CREATE INDEX IF NOT EXISTS idx_nexec_task ON node_executions(task_id, node_id);
        """)
        self._conn.commit()

    # ── Node execution CRUD ────────────────────────────────────

    def create_node_execution(
        self, task_id: str, node_id: str, *,
        executor: str = "local", plan_revision: int = 0,
    ) -> str:
        exec_id = _make_id("nexec")
        self._conn.execute(
            "INSERT INTO node_executions (id, task_id, plan_revision, node_id, executor) "
            "VALUES (?, ?, ?, ?, ?)",
            (exec_id, task_id, plan_revision, node_id, executor),
        )
        self._conn.commit()
        return exec_id

    def update_node_execution(
        self, exec_id: str, *,
        status: str | None = None,
        worker_task_id: str | None = None,
        claim_json: str | None = None,
        evidence_json: str | None = None,
        verified_at: str | None = None,
    ) -> None:
        parts, vals = [], []
        if status:
            parts.append("status = ?"); vals.append(status)
        if worker_task_id:
            parts.append("worker_task_id = ?"); vals.append(worker_task_id)
        if claim_json:
            parts.append("claim_json = ?"); vals.append(claim_json)
        if evidence_json:
            parts.append("evidence_json = ?"); vals.append(evidence_json)
        if verified_at:
            parts.append("verified_at = ?"); vals.append(verified_at)
        if not parts:
            return
        parts.append("heartbeat_at = strftime('%Y-%m-%dT%H:%M:%fZ','now')")
        vals.append(exec_id)
        self._conn.execute(f"UPDATE node_executions SET {', '.join(parts)} WHERE id = ?", vals)
        self._conn.commit()

    def get_node_execution(self, task_id: str, node_id: str) -> dict[str, Any] | None:
        row = self._conn.execute(
            "SELECT * FROM node_executions WHERE task_id = ? AND node_id = ? ORDER BY created_at DESC LIMIT 1",
            (task_id, node_id),
        ).fetchone()
        return dict(row) if row else None

    def get_active_node_executions(self, task_id: str) -> list[dict[str, Any]]:
        rows = self._conn.execute(
            "SELECT * FROM node_executions WHERE task_id = ? AND status IN ('claimed', 'running') ORDER BY created_at",
            (task_id,),
        ).fetchall()
        return [dict(r) for r in rows]

    def _migrate_task_artifacts(self) -> None:
        """Durable per-task artifacts for shift handoff continuity."""
        self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS task_artifacts (
                id TEXT PRIMARY KEY,
                task_id TEXT NOT NULL REFERENCES tasks(id),
                kind TEXT NOT NULL CHECK (kind IN ('handoff', 'progress', 'evidence', 'scratch')),
                title TEXT NOT NULL,
                content TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
            );
            CREATE INDEX IF NOT EXISTS idx_artifacts_task ON task_artifacts(task_id, kind, created_at DESC);
        """)
        self._conn.commit()

    # ── Task artifacts CRUD ────────────────────────────────────

    def add_artifact(self, task_id: str, kind: str, title: str, content: str) -> str:
        art_id = _make_id("art")
        self._conn.execute(
            "INSERT INTO task_artifacts (id, task_id, kind, title, content) VALUES (?, ?, ?, ?, ?)",
            (art_id, task_id, kind, title, content[:10000]),
        )
        self._conn.commit()
        return art_id

    def get_latest_artifact(self, task_id: str, kind: str) -> dict[str, Any] | None:
        row = self._conn.execute(
            "SELECT * FROM task_artifacts WHERE task_id = ? AND kind = ? ORDER BY created_at DESC LIMIT 1",
            (task_id, kind),
        ).fetchone()
        return dict(row) if row else None

    def get_task_artifacts(self, task_id: str) -> list[dict[str, Any]]:
        rows = self._conn.execute(
            "SELECT id, kind, title, created_at FROM task_artifacts WHERE task_id = ? ORDER BY created_at DESC LIMIT 20",
            (task_id,),
        ).fetchall()
        return [dict(r) for r in rows]

    def _migrate_stagnation_log(self) -> None:
        self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS stagnation_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                signature TEXT NOT NULL,
                raw_command TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'attempted',
                run_id TEXT,
                created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
            );
            CREATE INDEX IF NOT EXISTS idx_stag_sig ON stagnation_log(signature, created_at);
        """)
        self._conn.commit()

    # ── Stagnation tracking ────────────────────────────────────

    def record_stagnation(self, signature: str, raw_command: str, status: str = "attempted") -> None:
        """Persist a stagnation event so 'Do Not Repeat' survives compaction/restart."""
        self._conn.execute(
            "INSERT INTO stagnation_log (signature, raw_command, status) VALUES (?, ?, ?)",
            (signature, raw_command[:200], status),
        )
        self._conn.commit()

    def count_recent_signature(self, signature: str, minutes: int = 30) -> int:
        row = self._conn.execute(
            "SELECT COUNT(*) FROM stagnation_log "
            "WHERE signature = ? AND created_at > strftime('%Y-%m-%dT%H:%M:%fZ', 'now', ?)",
            (signature, f"-{minutes} minutes"),
        ).fetchone()
        return row[0] if row else 0

    def get_blocked_signatures(self, limit: int = 10, hours: int = 2) -> list[dict]:
        rows = self._conn.execute(
            "SELECT signature, raw_command, COUNT(*) as cnt, MAX(created_at) as last_seen "
            "FROM stagnation_log "
            "WHERE created_at > strftime('%Y-%m-%dT%H:%M:%fZ', 'now', ?) "
            "GROUP BY signature HAVING cnt >= 2 "
            "ORDER BY last_seen DESC LIMIT ?",
            (f"-{hours} hours", limit),
        ).fetchall()
        return [dict(r) for r in rows]

    def get_failed_actions(self, limit: int = 10, hours: int = 2) -> list[dict]:
        rows = self._conn.execute(
            "SELECT summary, details FROM history "
            "WHERE action_status = 'error' "
            "AND created_at > strftime('%Y-%m-%dT%H:%M:%fZ', 'now', ?) "
            "ORDER BY created_at DESC LIMIT ?",
            (f"-{hours} hours", limit),
        ).fetchall()
        return [dict(r) for r in rows]




def _make_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:10]}"


def _cosine_similarity(a: list[float], b: list[float]) -> float:
    """Cosine similarity between two embedding vectors. No numpy dependency."""
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = sum(x * x for x in a) ** 0.5
    norm_b = sum(x * x for x in b) ** 0.5
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)
