"""Pascal main loop — tool-use loop architecture.

Claude Code / Codex / ReAct inspired:
  LLM → N tool_calls → execute sequentially → tool_results back to LLM → repeat

No JSON serialization for tool_calls — Message.tool_calls is used directly.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
from dataclasses import dataclass, field
from typing import Any, Callable

from pascal.actions import execute_action, _auto_postmortem, ActionContext
from pascal.compaction import (
    build_session_summary as _build_session_summary_standalone,
    estimate_tokens as _estimate_tokens_standalone,
    messages_too_long as _messages_too_long_standalone,
    token_budget as _token_budget_standalone,
    MAX_COMPACTIONS_BEFORE_RESTART as _MAX_COMPACTIONS_BEFORE_RESTART,
    MAX_RESTART_DEPTH as _MAX_RESTART_DEPTH,
    TOOL_RESULT_CHAR_BUDGET as _TOOL_RESULT_CHAR_BUDGET,
)
from pascal.effect import compute_threshold
from pascal.governance import (
    count_stagnation as _count_stagnation,
    recent_error_streak as _recent_error_streak,
    stagnation_signature as _stagnation_signature,
    SIDE_EFFECT_ACTIONS as _SIDE_EFFECT_ACTIONS,
    STAGNATION_HARD_STOP as _STAGNATION_HARD_STOP,
    STAGNATION_NUDGE as _STAGNATION_NUDGE,
    STAGNATION_REPLAN as _STAGNATION_REPLAN,
)
from pascal.desk import Desk
from pascal.effect import check_allowed, classify_command, effect_to_int, get_max_effect
from pascal.mcp import MCPManager
from pascal.prompt import CLI_MODE_BLOCK, DAEMON_MODE_BLOCK, REPL_MODE_BLOCK, SYSTEM_PROMPT, load_instruction_hierarchy, instruction_file_paths
from pascal.receipts import Ledger
from pascal.sandbox import SandboxManager
from pascal.state import PascalStore
from pascal.types import json_safe as _json_safe
from pascal.tools import (
    cleanup_tools,
    resolve_tool_effect,
    set_workspace,
    get_approval_callback,
    get_channel_bot,
    get_owner_chat_id,
)
from pascal.types import ActionStatus, ContentBlock, LLMResponse, Message, Observation, Role, ToolCall

logger = logging.getLogger(__name__)

_MAX_PARSE_RETRIES = 3
_DEFAULT_MAX_TOOL_ROUNDS = 10
# Token budget — provider-aware; fallback to 30k for unknown providers.
# Roughly 75% of context window to leave room for system prompt + response.
_TERMINAL_ACTIONS = frozenset({"wait", "escalate", "complete_task", "fail_task"})
_BATCH_BREAK_ACTIONS = frozenset({
    "plan", "delegate", "skill", "wait", "escalate",
    "complete_task", "fail_task", "block_task",
})
# Tools hidden from LLM but callable internally (plan steps, skill fork)
_HIDDEN_FROM_LLM = frozenset({"delegate", "check_delegate"})
# Backward compat alias (used by tests/external code)
TERMINAL_ACTIONS = _TERMINAL_ACTIONS




def normalize_result(action: str, result: Any) -> dict[str, Any]:
    """Guarantee a normalized tool result with an explicit status field."""
    if not isinstance(result, dict):
        return {
            "status": "error",
            "error": f"invalid result type from {action}: {type(result).__name__}",
            "output": "",
        }

    normalized = dict(result)
    if action == "channel_reply" and normalized.get("reply_sent") is False:
        normalized["status"] = "error"
        normalized.pop("notification_handled", None)

    status = str(normalized.get("status") or "").strip().lower()
    if status in {"ok", "error", "unknown"}:
        normalized["status"] = status
        return normalized
    if normalized.get("error"):
        normalized["status"] = "error"
    else:
        normalized["status"] = "ok"
    return normalized


# ── Loop State ─────────────────────────────────────────────

@dataclass
class LoopState:
    """Mutable per-run state."""
    actions_taken: list[dict[str, Any]] = field(default_factory=list)
    consecutive_errors: int = 0
    thought_buffer: list[str] = field(default_factory=list)
    error_feedback: str = ""
    has_unknown_step: bool = False
    last_attachment: ContentBlock | None = None
    skip_verification: bool = False
    last_observation: Observation | None = None
    force_full_render: bool = True
    cached_mode: str = ""
    # Session metrics
    total_prompt_tokens: int = 0
    total_completion_tokens: int = 0
    compaction_count: int = 0
    restart_depth: int = 0


@dataclass
class ToolUseResult:
    """Outcome of one inner tool-use loop pass."""
    stop_reason: str = ""  # text_response / terminal_action / stagnation / max_errors / round_cap
    terminal_action: str | None = None
    terminal_decision: dict[str, Any] = field(default_factory=dict)
    terminal_result: dict[str, Any] = field(default_factory=dict)
    terminal_obs: Observation | None = None


# ── Loop Runner ────────────────────────────────────────────

class LoopRunner:
    """Orchestrates the Pascal tool-use loop."""

    def __init__(
        self,
        store: PascalStore,
        llm,
        *,
        verifier_llm=None,
        ledger: Ledger | None = None,
        mcp_manager: MCPManager | None = None,
        max_effect: str | None = None,
        max_iterations: int = 50,
        max_tool_rounds: int | None = None,
        max_inner_turns: int = 1,  # deprecated alias for max_tool_rounds
        on_action: Callable[[dict[str, Any]], None] | None = None,
        execute_command: Callable[[str], str] | None = None,
        workspace: str | None = None,
        wake_event: "asyncio.Event | None" = None,
        mode: str | None = None,
    ):
        self.store = store
        self.llm = llm
        self.verifier_llm = verifier_llm
        self.ledger = ledger
        self.mcp_manager = mcp_manager
        self.max_effect = max_effect
        self.on_action = on_action
        self.execute_command = execute_command
        self.wake_event = wake_event
        self.mode = mode or ("daemon" if wake_event is not None else "oneshot")
        self._pending_user_messages: list[str] = []
        self._iteration_limit = max_iterations if max_iterations > 0 else 999_999
        # Priority: max_tool_rounds > max_inner_turns (deprecated alias) > default
        if max_tool_rounds is not None:
            self._max_tool_rounds = max(1, max_tool_rounds)
        elif max_inner_turns > 1:
            self._max_tool_rounds = max(1, max_inner_turns)
        else:
            self._max_tool_rounds = _DEFAULT_MAX_TOOL_ROUNDS
        self.state = LoopState()

        import uuid as _uuid
        self.run_id = f"run_{_uuid.uuid4().hex[:8]}"

        self._locked = not store.acquire_lock(self.run_id)
        if self._locked:
            return

        try:
            # Identity seed
            if not store.get_context("identity"):
                from datetime import datetime, timezone
                store.set_context("identity", {
                    "name": "Pascal",
                    "companion_since": datetime.now(timezone.utc).strftime("%Y-%m-%d"),
                    "personality": "Calm, practical, opinionated when it matters. Minimal unnecessary talk.",
                })

            # Desk + tool schemas
            self.desk = Desk(store)

            from pascal.schemas import build_tool_schemas
            has_mcp = bool(mcp_manager and mcp_manager.connected_servers)
            self._last_has_mcp = has_mcp
            self._tool_schemas_cache = {
                "cli": build_tool_schemas(mode="cli", has_mcp=has_mcp),
                "repl": build_tool_schemas(mode="cli", has_mcp=has_mcp),
                "daemon": build_tool_schemas(mode="daemon", has_mcp=has_mcp),
            }

            ws = workspace or os.getcwd()
            self._workspace = ws
            set_workspace(ws)
            self.sandbox = SandboxManager(workspace=ws)

            # Session temp root — all temp files go here, inside workspace
            # GPT Pro pattern: allowed_write_roots = [workspace, temp_root]
            self._temp_root = os.path.join(ws, ".pascal_tmp", self.run_id)
            os.makedirs(self._temp_root, exist_ok=True)

            # Action context — single object for all handler calls
            self.action_ctx = ActionContext(
                store=store, llm=verifier_llm, max_effect=max_effect,
                sandbox=self.sandbox, mcp_manager=mcp_manager,
                execute_command=execute_command,
                thought_buffer=self.state.thought_buffer,
                ledger=ledger, notify_fn=_notify_channel,
                temp_root=self._temp_root,
                mode=self.mode,
                governance_fn=self._plan_step_governance,
                on_step_complete_fn=self._plan_step_complete,
            )

            # System prompt cache — render once at init, invalidate on dirty triggers
            self._system_prompt_cache: dict[str, str] = {
                "cli": self._render_system_prompt("cli"),
                "repl": self._render_system_prompt("repl"),
                "daemon": self._render_system_prompt("daemon"),
            }
            self._sp_dirty = False
            # Track instruction file mtimes for dirty detection (v1.3 prep)
            self._instruction_mtimes = self._snapshot_instruction_mtimes()

            # Restore restart depth from previous session
            prev_depth = store.get_context("restart_depth")
            if isinstance(prev_depth, int):
                self.state.restart_depth = prev_depth

            # Resume context
            self.resume_context, resumed_unknown, resumed_state = _compile_resume_context(store)
            if resumed_unknown:
                self.state.has_unknown_step = True
            if resumed_state.get("compaction_count"):
                self.state.compaction_count = resumed_state["compaction_count"]
            if resumed_state.get("consecutive_errors"):
                self.state.consecutive_errors = resumed_state["consecutive_errors"]
        except Exception:
            store.release_lock()
            raise

        # Auto-pick sole actionable task
        if not store.get_active_task():
            actionable = _get_actionable_pending_tasks(store)
            if len(actionable) == 1:
                store.activate_task(actionable[0]["id"])
                logger.info("Auto-picked sole actionable task: %s", actionable[0]["goal"][:80])

    def inject_user_message(self, text: str) -> None:
        """Inject a user message directly into the conversation (REPL mode)."""
        self._pending_user_messages.append(text)

    # ── Initial messages ──────────────────────────────────

    def _render_system_prompt(self, mode: str) -> str:
        """Render the system prompt for the active runtime mode."""
        if mode == "daemon":
            mode_block = DAEMON_MODE_BLOCK
        elif mode == "repl":
            mode_block = REPL_MODE_BLOCK
        else:
            mode_block = CLI_MODE_BLOCK
        base_prompt = f"{SYSTEM_PROMPT}{mode_block}"
        # Instruction hierarchy (global + project, 3 file types)
        instructions = load_instruction_hierarchy(self._workspace)
        if instructions:
            base_prompt += f"\n\n{instructions}"
        static_prompt = self.desk.render_static()
        if static_prompt:
            return f"{base_prompt}\n\n{static_prompt}"
        return base_prompt

    def _build_initial_messages(self) -> list[Message]:
        """Build the initial message list with full desk render."""
        system_prompt = self._render_system_prompt(self._refresh_tool_preset())

        desk_prompt = self.desk.render(
            has_unknown_step=self.state.has_unknown_step,
            include_static=False,
            session_metrics=self._session_metrics(),
        )
        user_content = f"Your desk:\n\n{desk_prompt}"
        if self.resume_context:
            user_content += f"\n\n## Resume Context\n{self.resume_context}"
        if self.state.error_feedback:
            user_content += f"\n\n## ERROR from previous\n{self.state.error_feedback}"
            self.state.error_feedback = ""
        user_content += "\n\nDecide your next action."

        messages = [Message(role=Role.SYSTEM, content=system_prompt)]
        messages.append(Message(role=Role.USER, content=user_content))
        return messages

    # ── Tool preset selection ────────────────────────────

    # Plan mode — read-only tools + plan. editor(read/list) and shell(read-only)
    # are allowed via schema; write ops still gated by effect ladder.
    _PLAN_MODE_TOOLS = ["think", "plan", "editor", "shell", "skill",
                        "complete_task", "fail_task", "escalate"]

    def _refresh_tool_preset(self) -> str:
        """Recompute and cache the runtime mode. Rebuilds tool schemas if MCP/skill/plan state changed."""
        if get_channel_bot() is not None:
            mode = "daemon"
        elif self.mode == "repl":
            mode = "repl"
        else:
            mode = "cli"
        self.state.cached_mode = mode
        # Check plan mode — restricts to read-only + plan tools
        active_task = self.store.get_active_task()
        task_mode = None
        if active_task:
            task_mode = self.store.get_context(f"task_mode:{active_task['id']}")
        # Check active skill's allowedTools
        active_skill = self.store.get_context("active_skill")
        allowlist = None
        if task_mode == "plan":
            allowlist = self._PLAN_MODE_TOOLS
        elif isinstance(active_skill, dict) and active_skill.get("allowed_tools"):
            at = active_skill["allowed_tools"]
            allowlist = at if isinstance(at, list) else [at]
        allowlist_key = tuple(allowlist) if allowlist else ()
        # Dynamic tool schema refresh — pick up new MCP connections or skill changes
        mcp_manager = self.action_ctx.mcp_manager
        has_mcp = bool(mcp_manager and mcp_manager.connected_servers)
        mcp_specs = mcp_manager.all_tool_specs() if mcp_manager and has_mcp else None
        mcp_key = tuple(s.name for s in mcp_specs) if mcp_specs else ()
        if (has_mcp != self._last_has_mcp
                or mcp_key != getattr(self, "_last_mcp_key", ())
                or allowlist_key != getattr(self, "_last_allowlist_key", ())):
            from pascal.schemas import build_tool_schemas
            self._tool_schemas_cache = {
                "cli": build_tool_schemas(mode="cli", has_mcp=has_mcp, mcp_specs=mcp_specs, allowlist=allowlist),
                "repl": build_tool_schemas(mode="cli", has_mcp=has_mcp, mcp_specs=mcp_specs, allowlist=allowlist),
                "daemon": build_tool_schemas(mode="daemon", has_mcp=has_mcp, mcp_specs=mcp_specs, allowlist=allowlist),
            }
            self._last_has_mcp = has_mcp
            self._last_mcp_key = mcp_key
            self._last_allowlist_key = allowlist_key
        return mode

    def _select_tool_preset(self) -> str:
        """Return cached runtime mode (avoids repeated global checks inside a turn)."""
        return self.state.cached_mode or self._refresh_tool_preset()

    # ── LLM call ──────────────────────────────────────────

    def _invalidate_system_prompt(self) -> None:
        """Mark system prompt cache as dirty. Re-rendered on next LLM call."""
        self._sp_dirty = True

    def _snapshot_instruction_mtimes(self) -> dict[str, float]:
        """Capture mtimes of all instruction files for staleness detection."""
        result = {}
        for p in instruction_file_paths(self._workspace):
            try:
                result[str(p)] = p.stat().st_mtime if p.is_file() else 0.0
            except OSError:
                result[str(p)] = 0.0
        return result

    async def _call_llm(self, messages: list[Message]) -> LLMResponse | None:
        """Call LLM with tool schemas. Uses streaming when available."""
        try:
            mode = self._select_tool_preset()
            # Check instruction file mtimes for staleness
            current_mtimes = self._snapshot_instruction_mtimes()
            if current_mtimes != self._instruction_mtimes:
                self._sp_dirty = True
                self._instruction_mtimes = current_mtimes
            # Use cached system prompt; re-render only when dirty
            if self._sp_dirty:
                self._system_prompt_cache = {
                    "cli": self._render_system_prompt("cli"),
                    "repl": self._render_system_prompt("repl"),
                    "daemon": self._render_system_prompt("daemon"),
                }
                self._sp_dirty = False
            if messages and messages[0].role == Role.SYSTEM:
                messages[0].content = self._system_prompt_cache[mode]
            tools = self._tool_schemas_cache[mode]

            # Try streaming if adapter supports it
            if hasattr(self.llm, "chat_stream"):
                response = await self._call_llm_streaming(messages, tools)
            else:
                response = await _llm_call_with_retry(
                    self.llm, messages, tools=tools,
                    daemon_mode=self.mode == "daemon",
                )
        except Exception as exc:
            logger.error("LLM call failed after retries: %s", exc)
            self.state.consecutive_errors += 1
            if self.state.consecutive_errors >= _MAX_PARSE_RETRIES:
                self.store.record("Loop stopped: repeated LLM failures")
            return None
        if response is None:
            self.state.consecutive_errors += 1
            return None
        if not response.text and not response.tool_calls:
            self.state.consecutive_errors += 1
            if self.state.consecutive_errors >= _MAX_PARSE_RETRIES:
                self.store.record("Loop stopped: repeated empty LLM responses")
            return None
        # Accumulate token usage
        if response.usage:
            self.state.total_prompt_tokens += response.usage.prompt_tokens
            self.state.total_completion_tokens += response.usage.completion_tokens
        return response

    async def _call_llm_streaming(self, messages: list[Message], tools: list) -> LLMResponse:
        """Stream LLM response, accumulating tool_calls and emitting text deltas."""
        from pascal.types import TokenUsage as _TokenUsage
        text_parts: list[str] = []
        tc_builders: dict[int, dict] = {}  # index -> {id, name, args_parts}
        finish_reason = ""
        usage = _TokenUsage()

        async for chunk in self.llm.chat_stream(messages, tools=tools):
            if chunk.delta_text:
                text_parts.append(chunk.delta_text)
                # Emit progressive text to callback
                if self.on_action:
                    self.on_action({"action": "stream_delta", "text": chunk.delta_text})
            if chunk.tool_call_index is not None:
                idx = chunk.tool_call_index
                if idx not in tc_builders:
                    tc_builders[idx] = {"id": "", "name": "", "args_parts": []}
                if chunk.tool_call_id:
                    tc_builders[idx]["id"] = chunk.tool_call_id
                if chunk.tool_call_name:
                    tc_builders[idx]["name"] = chunk.tool_call_name
                if chunk.tool_call_args_delta:
                    tc_builders[idx]["args_parts"].append(chunk.tool_call_args_delta)
            if chunk.finish_reason:
                finish_reason = chunk.finish_reason
            if chunk.usage:
                usage = chunk.usage

        # Assemble tool calls (with size guard and error reporting)
        assembled_tcs: list[ToolCall] = []
        _MAX_ARGS_SIZE = 50_000  # 50KB per tool call — prevent unbounded accumulation
        for idx in sorted(tc_builders):
            b = tc_builders[idx]
            args_str = "".join(b["args_parts"])
            if len(args_str) > _MAX_ARGS_SIZE:
                logger.warning("Streaming tool call args too large (%d bytes), truncating", len(args_str))
                args_str = args_str[:_MAX_ARGS_SIZE]
            try:
                params = json.loads(args_str) if args_str else {}
            except json.JSONDecodeError:
                logger.warning("Malformed tool call args from streaming: %s...", args_str[:100])
                params = {"_parse_error": True, "_raw_args": args_str[:200]}
            assembled_tcs.append(ToolCall(id=b["id"], name=b["name"], params=params))

        return LLMResponse(
            text="".join(text_parts) or None,
            tool_calls=assembled_tcs,
            usage=usage,
            finish_reason=finish_reason,
        )

    # ── Safety checks (unchanged) ─────────────────────────

    def _plan_effect_level(self, decision: dict[str, Any]) -> str:
        max_level = "E1"
        for step in _iter_plan_actions(decision):
            step_action = str(step.get("action") or "").strip()
            step_level = self._decision_effect_level(step_action, step)
            if step_level is not None and effect_to_int(step_level) > effect_to_int(max_level):
                max_level = step_level
        return max_level

    def _decision_effect_level(self, action: str, decision: dict[str, Any]) -> str | None:
        if action == "plan":
            return self._plan_effect_level(decision)
        if action == "delegate":
            return "E2"
        # First-class tools — use resolve_tool_effect for granular sub-action levels
        if action == "shell":
            command = str(decision.get("command") or "").strip()
            return classify_command(command) if command else None
        if action in ("editor", "computer", "uia"):
            # Build tool_params from decision for resolve_tool_effect lookup
            return resolve_tool_effect(action, decision) or "E1"
        if action == "code":
            return "E2"
        if action == "channel_reply":
            notif_id = str(decision.get("notification_id") or "").strip()
            return "E2" if notif_id else "E3"
        # Legacy execute shim
        if action != "execute":
            return None
        tool_name = str(decision.get("tool") or "").strip()
        if tool_name:
            tool_effect = resolve_tool_effect(tool_name, decision.get("tool_params"))
            if tool_effect is not None:
                return tool_effect
            if self.mcp_manager is not None and self.mcp_manager.has_tool(tool_name):
                specs = [spec for spec in self.mcp_manager.all_tool_specs() if spec.name == tool_name]
                return "E3" if (specs and specs[0].side_effects) else "E0"
            return "E1"
        command = str(decision.get("command") or "").strip()
        if command:
            return classify_command(command)
        return None

    # ── Plan-step governance (callbacks for ActionContext) ──

    def _plan_step_governance(self, action: str, decision: dict) -> str | None:
        """Governance check for plan steps — delegates to unified _pre_execute_checks.

        Returns error string if blocked, None if allowed.
        """
        signal = self._pre_execute_checks(action, decision, iteration=0)
        if signal == "break":
            return self.state.error_feedback or "stagnation hard stop"
        if signal == "continue":
            return self.state.error_feedback or "blocked by safety check"
        return None

    def _plan_step_complete(self, action: str, decision: dict, result: dict) -> None:
        """Record plan step completion for stagnation tracking."""
        # Append to actions_taken for stagnation tracking
        self.state.actions_taken.append({
            "action": action,
            "decision": {**decision, "action": action},
            "result": result,
            "source": "plan_step",
        })

    def _pre_execute_checks(self, action: str, decision: dict, iteration: int) -> str | None:
        """Returns 'break' (stagnation=stop loop), 'continue' (block=skip), or None."""
        if action == "think":
            recent_thinks = sum(1 for a in reversed(self.state.actions_taken[-5:]) if a["action"] == "think")
            if recent_thinks >= 2:
                self.state.error_feedback = "You have been thinking too long. Execute an action now."
                return "continue"

        if action in ("execute", "shell", "editor", "computer", "uia", "code", "channel_reply", "plan"):
            cmd = _stagnation_signature(action, decision)
            stag_count = _count_stagnation(self.state.actions_taken, cmd) if cmd else 0

            # Graduated response: nudge(3) → replan(5) → stop(7)
            # GPT Pro + browser-use pattern: soft nudge first, hard stop last resort
            if stag_count >= _STAGNATION_HARD_STOP:
                # Level 3: hard stop — only after 7+ repeats
                self.store.record_stagnation(cmd, cmd, status="hard_stop")
                self.state.error_feedback = (
                    f"HARD STOP: '{cmd}' repeated {stag_count} times. Loop terminated. "
                    "Escalate to human or fail the task."
                )
                self.store.record(
                    f"Stagnation hard stop: repeated {stag_count} times",
                    task_id=(self.store.get_active_task() or {}).get("id"),
                    details={"action": "escalate", "command": cmd, "reason": "stagnation_hard_stop",
                             "count": stag_count},
                    action_status="error",
                )
                active = self.store.get_active_task()
                if active:
                    _auto_postmortem(self.store, active, f"Stagnation: repeated '{cmd}' {stag_count}x")
                self.state.actions_taken.append({
                    "iteration": iteration, "action": "escalate",
                    "reason": "stagnation_hard_stop", "result": {"stagnation": True},
                })
                return "break"
            elif stag_count >= _STAGNATION_REPLAN:
                # Level 2: force replan — block this action, demand different approach
                self.store.record_stagnation(cmd, cmd, status="replan")
                self.state.error_feedback = (
                    f"Stagnation warning: '{cmd}' repeated {stag_count} times. "
                    "This action is BLOCKED. You MUST try a completely different approach. "
                    "Tool priority: API > Shell > Screenshot"
                )
                return "continue"
            elif stag_count >= _STAGNATION_NUDGE:
                # Level 1: soft nudge — warn but allow (browser-use pattern)
                self.state.error_feedback = (
                    f"Repetition notice: '{cmd}' repeated {stag_count} times. "
                    "Consider a different approach if this isn't making progress."
                )

        effect_level = self._decision_effect_level(action, decision)
        if effect_level is None or effect_to_int(effect_level) == 0:
            return None
        if not check_allowed(effect_level, get_max_effect(self.max_effect)):
            self.state.error_feedback = (
                f"Effect level {effect_level} exceeds max allowed {get_max_effect(self.max_effect)}. "
                "Choose a lower-effect action or escalate to a human."
            )
            return "continue"

        recent_errors = _recent_error_streak(self.state.actions_taken)
        threshold = compute_threshold(effect_level, recent_error_streak=recent_errors)
        if threshold == "go":
            return None
        should_block = threshold == "block" or (
            threshold == "caution" and (effect_to_int(effect_level) >= 4 or recent_errors >= 3)
        )
        if not should_block:
            return None

        self.state.error_feedback = (
            f"Safety gate: {action} at {effect_level} blocked ({recent_errors} recent errors). "
            "Choose a lower-effect step or escalate."
        )
        return "continue"

    # ── Observe + Record ──────────────────────────────────

    def _observe_result(self, action: str, decision: dict, result: Any) -> Observation:
        """Create Observation from raw result. Updates loop state."""
        obs = Observation.from_result(action, result)
        self.state.last_observation = obs

        if obs.status == ActionStatus.UNKNOWN:
            self.state.has_unknown_step = True
        elif obs.status == ActionStatus.OK and action in _SIDE_EFFECT_ACTIONS:
            self.state.has_unknown_step = False

        # Vision: save attachment for next USER message
        if obs.attachment:
            self.state.last_attachment = obs.attachment

        # Clear thought buffer after non-think
        if action != "think":
            self.state.thought_buffer.clear()

        return obs

    def _record_and_update(
        self, obs: Observation, decision: dict,
        reason: str, expected_evidence: str, stop_condition: str, iteration: int,
    ) -> None:
        """Record action to history + ledger. No control flow."""
        action = obs.action_type
        result = obs.raw_result

        active = self.store.get_active_task()
        active_id = active["id"] if active else None
        idem_key = f"{active_id or 'notask'}:{iteration}:{len(self.state.actions_taken)}:{action}"

        action_record = {
            "iteration": iteration,
            "action": action,
            "decision": decision,
            "reason": reason,
            "result": result,
        }
        self.state.actions_taken.append(action_record)
        if self.on_action:
            self.on_action(action_record)
        _broadcast_action(action_record)

        self.store.record(
            f"{action}: {reason}" if reason else action,
            task_id=active_id,
            details={"decision": decision, "result": result},
            idem_key=idem_key,
            action_status=obs.status,
        )

        if self.ledger is not None:
            self.ledger.record_action(action, decision, result)

    # ── Stop conditions (unchanged) ───────────────────────

    async def _check_stop(self, action: str, decision: dict, result: Any,
                          obs: Observation, iteration: int) -> str | None:
        """Returns 'break', 'continue', or None."""
        if (
            self.wake_event is None
            and action == "complete_task"
            and obs.status == ActionStatus.OK
            and not _has_actionable_work(self.store)
        ):
            auto_wait = {
                "iteration": iteration, "action": "wait",
                "reason": "auto-idle after completion",
                "result": {"waiting": True, "auto": True},
            }
            self.state.actions_taken.append(auto_wait)
            if self.on_action:
                self.on_action(auto_wait)
            _broadcast_action(auto_wait)
            self.store.record(
                "wait: auto-idle after completion",
                details={"decision": {"action": "wait", "auto": True}, "result": auto_wait["result"]},
                action_status="ok",
            )
            return "break"

        if action == "wait":
            if self.wake_event is not None:
                self.wake_event.clear()
                while not self.wake_event.is_set():
                    self.store.refresh_lock()
                    try:
                        await asyncio.wait_for(self.wake_event.wait(), timeout=60)
                    except asyncio.TimeoutError:
                        pass
                return "continue"
            else:
                return "break"

        if action == "escalate":
            if self.wake_event is not None and get_approval_callback() is not None:
                active = self.store.get_active_task()
                if active:
                    question = str(decision.get("question") or "Need human input")
                    await get_approval_callback()(get_owner_chat_id(), active["id"], question)
                    self.store.update_task(active["id"], status="blocked",
                                          progress=f"Awaiting approval: {question}")
                    return "continue"
            return "break"

        if isinstance(result, dict) and result.get("escalate"):
            return "break"
        return None

    async def _cleanup(self) -> None:
        await cleanup_tools()
        self.store.release_lock()
        # Clean session temp root
        if hasattr(self, '_temp_root') and os.path.isdir(self._temp_root):
            import shutil
            try:
                shutil.rmtree(self._temp_root, ignore_errors=True)
            except Exception:
                pass
            # Prune old temp dirs (keep 5 most recent)
            parent = os.path.dirname(self._temp_root)
            if os.path.isdir(parent):
                try:
                    dirs = sorted(
                        (d for d in os.scandir(parent) if d.is_dir()),
                        key=lambda d: d.stat().st_mtime,
                    )
                    for d in dirs[:-5]:
                        shutil.rmtree(d.path, ignore_errors=True)
                except Exception:
                    pass

    # ── Tool use loop (NEW — Claude Code / Codex pattern) ─

    async def _execute_parallel(
        self, tool_calls: list[ToolCall], messages: list[Message], iteration: int,
    ) -> None:
        """Execute independent E0 tool calls in parallel via asyncio.gather."""

        async def _run_one(tc: ToolCall) -> tuple[ToolCall, dict]:
            action = tc.name.strip().lower()
            decision = dict(tc.params) if tc.params else {}
            self.action_ctx.skip_verification = self.state.skip_verification
            try:
                result = await execute_action(self.store, decision, action, ctx=self.action_ctx)
            except Exception as exc:
                result = {"error": f"handler crash: {exc}", "status": "error"}
            return tc, normalize_result(action, result)

        results = await asyncio.gather(*[_run_one(tc) for tc in tool_calls])

        # Process results in deterministic order
        for tc, result in results:
            action = tc.name.strip().lower()
            decision = dict(tc.params) if tc.params else {}
            record_decision = {**decision, "action": action}
            obs = self._observe_result(action, decision, result)
            reason = str(decision.get("reason") or decision.get("thought") or "")
            self._record_and_update(obs, record_decision, reason, "", "", iteration)
            messages.append(Message(
                role=Role.TOOL, tool_call_id=tc.id,
                content=json.dumps(result, ensure_ascii=False, default=_json_safe),
            ))

    async def _execute_sequential(
        self, tool_calls: list[ToolCall], messages: list[Message], iteration: int,
        _append_tool_error, _close_remaining,
    ) -> ToolUseResult | None:
        """Execute tool calls sequentially with safety gates. Returns ToolUseResult or None to continue."""
        last_terminal: ToolUseResult | None = None
        for idx, tc in enumerate(tool_calls):
            action = tc.name.strip().lower()
            decision = dict(tc.params) if tc.params else {}
            record_decision = {**decision, "action": action}

            # Runtime allowlist enforcement
            if hasattr(self, '_last_allowlist_key') and self._last_allowlist_key:
                _always_allowed = {"think", "skill", "complete_task", "fail_task", "escalate"}
                if action not in (set(self._last_allowlist_key) | _always_allowed):
                    _append_tool_error(tc.id, f"tool '{action}' not in active allowlist")
                    _close_remaining(tool_calls, idx + 1, "blocked: tool not in allowlist")
                    break

            # Block tools hidden from LLM
            if action in _HIDDEN_FROM_LLM:
                _append_tool_error(tc.id, f"tool '{action}' is not available")
                _close_remaining(tool_calls, idx + 1, "blocked: hidden tool")
                break

            # Safety check
            signal = self._pre_execute_checks(action, decision, iteration)
            if signal == "break":
                _append_tool_error(tc.id, "stagnation detected, loop terminated")
                _close_remaining(tool_calls, idx + 1, "skipped: loop terminated after earlier stagnation")
                return ToolUseResult(stop_reason="stagnation")
            if signal == "continue":
                feedback = self.state.error_feedback or "blocked"
                _append_tool_error(tc.id, feedback)
                _close_remaining(tool_calls, idx + 1, "skipped: earlier tool call was blocked; replan required")
                if "Stagnation" in feedback or "Repetition" in feedback:
                    self.state.actions_taken.append({
                        "iteration": iteration, "action": action,
                        "decision": record_decision,
                        "reason": "blocked_by_stagnation_replan",
                        "result": {"status": "error", "blocked": True},
                    })
                break

            # Execute
            self.action_ctx.skip_verification = self.state.skip_verification
            try:
                result = await execute_action(self.store, decision, action, ctx=self.action_ctx)
            except Exception as exc:
                logger.error("Action handler crashed: %s %s", action, exc)
                result = {"error": f"handler crash: {exc}", "status": "error"}
            result = normalize_result(action, result)

            # Dirty-flag triggers for system prompt cache
            if action in ("add_rule", "remove_rule"):
                self._invalidate_system_prompt()
            elif action == "set_context" and decision.get("key") == "identity":
                self._invalidate_system_prompt()

            # Observe + record
            obs = self._observe_result(action, decision, result)
            reason = str(decision.get("reason") or decision.get("thought") or "")
            self._record_and_update(obs, record_decision, reason, "", "", iteration)

            # Tool result message
            result_content = json.dumps(result, ensure_ascii=False, default=_json_safe)
            if len(result_content) > _TOOL_RESULT_CHAR_BUDGET:
                result_content = json.dumps({
                    "status": result.get("status", "ok"), "error": result.get("error", ""),
                    "truncated": True, "preview": result_content[:_TOOL_RESULT_CHAR_BUDGET],
                }, ensure_ascii=False)
            messages.append(Message(role=Role.TOOL, tool_call_id=tc.id, content=result_content))

            # Skill transient injection
            if action == "skill" and result.get("status") == "ok":
                skill_body = result.get("body", "")[:5000]
                skill_name = result.get("skill_name", decision.get("name", ""))
                skill_args = result.get("args", "")
                if skill_body:
                    inject_content = f"[skill:{skill_name}]"
                    if skill_args:
                        inject_content += f"\nARGUMENTS: {skill_args}"
                    inject_content += f"\n\n{skill_body}"
                    messages.append(Message(role=Role.USER, content=inject_content))

            # Batch break actions
            if action in _BATCH_BREAK_ACTIONS:
                _close_remaining(tool_calls, idx + 1, f"skipped: '{action}' ended the tool batch; replan required")
                if action in _TERMINAL_ACTIONS:
                    last_terminal = ToolUseResult(
                        stop_reason="terminal_action", terminal_action=action,
                        terminal_decision=decision, terminal_result=result, terminal_obs=obs,
                    )
                break

            # Failure → stop batch
            if obs.status != ActionStatus.OK:
                _close_remaining(tool_calls, idx + 1, f"skipped: '{action}' failed; replan required")
                break

        return last_terminal  # None = continue loop, ToolUseResult = stop

    async def _tool_use_loop(self, messages: list[Message], iteration: int) -> ToolUseResult:
        """Inner tool-use loop.

        Termination is driven by the LLM's finish_reason:
          - "end_turn" / "stop" → LLM chose to stop (text response or done)
          - "tool_calls" / "tool_use" → LLM wants to use tools, continue loop
        """

        def _append_tool_error(tc_id: str, error: str) -> None:
            messages.append(Message(
                role=Role.TOOL, tool_call_id=tc_id,
                content=json.dumps({"status": "error", "error": error}, ensure_ascii=False),
            ))

        def _close_remaining(tool_calls: list[ToolCall], start: int, error: str) -> None:
            for skipped in tool_calls[start:]:
                _append_tool_error(skipped.id, error)

        for _round in range(self._max_tool_rounds):
            # Vision: pending attachment → USER message
            if self.state.last_attachment is not None:
                messages.append(Message(
                    role=Role.USER, content="[screenshot attached]",
                    attachments=[self.state.last_attachment],
                ))
                self.state.last_attachment = None

            # LLM call
            response = await self._call_llm(messages)
            if response is None:
                if self.state.consecutive_errors >= _MAX_PARSE_RETRIES:
                    return ToolUseResult(stop_reason="max_errors")
                continue

            # Extract tool_calls from function calling response
            tool_calls = list(response.tool_calls or [])
            self.state.consecutive_errors = 0
            finish = (response.finish_reason or "").lower()

            # ── finish_reason-based termination ──
            # No tool_calls and LLM signaled stop → text response, done
            if not tool_calls:
                if response.text:
                    messages.append(Message(role=Role.ASSISTANT, content=response.text))
                    text_record = {
                        "iteration": iteration, "action": "text_response",
                        "reason": response.text,
                        "result": {"text": response.text},
                    }
                    self.state.actions_taken.append(text_record)
                    if self.on_action:
                        self.on_action(text_record)
                    _broadcast_action(text_record)
                return ToolUseResult(stop_reason="end_turn")

            # Assistant message — tool_calls directly, no JSON serialization
            messages.append(Message(
                role=Role.ASSISTANT,
                content=response.text or "",
                tool_calls=tool_calls,
            ))

            # Parallel execution for independent E0 read-only calls
            all_e0 = len(tool_calls) > 1 and all(
                effect_to_int(self._decision_effect_level(tc.name.strip().lower(), dict(tc.params or {})) or "E0") == 0
                and tc.name.strip().lower() not in _TERMINAL_ACTIONS
                and tc.name.strip().lower() not in _BATCH_BREAK_ACTIONS
                for tc in tool_calls
            )
            if all_e0:
                await self._execute_parallel(tool_calls, messages, iteration)
                continue

            seq_result = await self._execute_sequential(
                tool_calls, messages, iteration, _append_tool_error, _close_remaining,
            )
            if seq_result is not None:
                return seq_result

            # finish_reason says LLM is done (no more tool calls expected)
            if finish in ("end_turn", "stop"):
                return ToolUseResult(stop_reason="end_turn")

        return ToolUseResult(stop_reason="round_cap")

    # Text JSON fallback removed — all providers now support function calling.

    def _session_metrics(self) -> dict[str, Any]:
        return {
            "actions": len(self.state.actions_taken),
            "compactions": self.state.compaction_count,
            "total_tokens": self.state.total_prompt_tokens + self.state.total_completion_tokens,
            "restart_depth": self.state.restart_depth,
        }

    # ── Context management ────────────────────────────────

    def _token_budget(self) -> int:
        return _token_budget_standalone(getattr(self.llm, "model", "") or "")

    @staticmethod
    def _estimate_tokens(text: str) -> int:
        return _estimate_tokens_standalone(text)

    def _messages_too_long(self, messages: list[Message]) -> bool:
        return _messages_too_long_standalone(messages, getattr(self.llm, "model", "") or "")

    _SAFETY_KEYWORDS = ("error", "failed", "blocked", "escalat", "stagnation", "trust scanner")

    @staticmethod
    def _micro_compact(messages: list[Message], keep_recent: int = 5) -> None:
        """Clear old tool result content in-place. Claude Code microCompact pattern.

        Replaces bulky tool results with a placeholder, preserving message structure.
        Delays full compaction by reducing token count incrementally.
        Safety-relevant results (errors, blocks, escalations) are preserved.
        """
        tool_msgs = [m for m in messages if m.role == Role.TOOL]
        clear_targets = tool_msgs[:-keep_recent] if len(tool_msgs) > keep_recent else []
        for msg in clear_targets:
            if msg.content and len(msg.content) > 200:
                if any(kw in msg.content.lower() for kw in LoopRunner._SAFETY_KEYWORDS):
                    continue
                msg.content = f"[cleared: {msg.content[:80]}]"

    async def _compact_messages(self, messages: list[Message]) -> list[Message]:
        """Trim messages while preserving assistant-tool batch integrity.

        Summarizes dropped context for handoff, saves full dropped messages to
        scratch, and rebuilds with fresh desk state.
        """
        if not messages:
            return messages
        system = messages[0]
        tail = messages[1:]

        # Semantic selection: keep recent messages + any containing errors/proofs
        keep_count = 8
        recent = tail[-keep_count:]
        # Also preserve older messages that contain error/failure info (survives compaction)
        older = tail[:-keep_count] if len(tail) > keep_count else []
        preserved = []
        for msg in older:
            content = msg.content or ""
            if any(kw in content.lower() for kw in ("error", "failed", "blocked", "stagnation", "proof", "evidence")):
                preserved.append(msg)
        if preserved:
            recent = preserved[-3:] + recent  # keep up to 3 error/proof messages

        # Ensure no orphaned TOOL or partial batches
        while recent:
            first = recent[0]
            if first.role == Role.TOOL:
                idx = len(messages) - len(recent) - 1
                while idx >= 1 and messages[idx].role == Role.TOOL:
                    idx -= 1
                if idx >= 1 and messages[idx].role == Role.ASSISTANT:
                    recent = [messages[idx]] + recent
                    continue
                recent = recent[1:]
                continue
            if first.role == Role.ASSISTANT and first.tool_calls:
                needed = len(first.tool_calls)
                found = sum(1 for m in recent[1:1 + needed] if m.role == Role.TOOL)
                if found < needed:
                    recent = recent[1 + found:]
                    continue
            break

        # Save dropped messages to scratch file (filesystem-as-memory)
        recent_ids = {id(m) for m in recent}
        dropped = [m for m in tail if id(m) not in recent_ids]
        scratch_ref = ""
        if dropped:
            scratch_ref = self._save_scratch(dropped)

        summary = ""
        if dropped:
            # Always use heuristic summary — no LLM call during compaction.
            # microCompact handles gradual content reduction before full compaction.
            summary = self._build_session_summary()

        delta_raw = self.desk.render_delta(observation=self.state.last_observation, session_metrics=self._session_metrics())
        delta_content = f"[context_compacted]\n{delta_raw[:8000]}"
        if summary:
            delta_content += f"\n\n## Session Summary\n{summary}"
        if scratch_ref:
            delta_content += f"\n\nFull prior context saved to: {scratch_ref} (use read_file if needed)"
        if dropped:
            self.state.compaction_count += 1
        delta = Message(role=Role.USER, content=delta_content)
        return [system, delta, *recent]

    async def _prepare_restart(self) -> None:
        """Save session state and signal daemon to spawn a fresh LoopRunner."""
        new_depth = self.state.restart_depth + 1
        self.store.set_context("restart_depth", new_depth, ttl_hours=2)

        # Try to memorize session lessons before dying
        try:
            summary = self._build_session_summary()
            if summary:
                self.store.add_memory(
                    kind="lesson",
                    content=f"[auto-restart #{new_depth}] {summary}",
                    source_task_id=(self.store.get_active_task() or {}).get("id"),
                )
        except Exception:
            logger.warning("Failed to save restart memory, continuing")

        self.store.record(
            f"auto-restart: compaction limit reached (depth {new_depth})",
            details={"restart_depth": new_depth, "compaction_count": self.state.compaction_count,
                     "total_tokens": self.state.total_prompt_tokens + self.state.total_completion_tokens},
        )
        self.state.actions_taken.append({
            "action": "auto-restart", "reason": "compaction limit reached",
            "result": {"restart_depth": new_depth},
        })

        # Shift handoff: write durable artifact so next session knows what happened
        self._write_shift_handoff("restart")

        logger.info("Auto-restart triggered (depth %d, compactions %d)", new_depth, self.state.compaction_count)

    def _build_session_summary(self) -> str:
        return _build_session_summary_standalone(self.state.actions_taken)

    def _write_shift_handoff(self, reason: str) -> None:
        """Write a shift handoff artifact — the next session reads this FIRST.

        Anthropic long-running harness pattern: each session is a 'shift'.
        The handoff document captures what was done, what's pending, and what to do next.
        """
        active = self.store.get_active_task()
        if not active:
            return
        task_id = active["id"]

        # Gather shift state
        history = self.store.get_recent_history(limit=15)
        task_history = [h for h in history if h.get("task_id") == task_id]
        plan_data = self.store.get_task_plan(task_id)
        thoughts = list(self.state.thought_buffer[-5:])

        # Build handoff document
        lines = [
            f"# Shift Handoff — {reason}",
            f"## Task: {active['goal']}",
            f"**Status**: {active['status']} | **Progress**: {active.get('progress', '')}",
            "",
            "## What was done this session",
        ]
        for h in task_history[-8:]:
            status_mark = "✓" if h.get("action_status") == "ok" else "✗"
            lines.append(f"- {status_mark} {h['summary']}")

        if plan_data:
            from pascal.types import TaskPlan
            plan = TaskPlan.from_dict(plan_data)
            counts = plan.root.count_by_status() if plan.root else {}
            lines.append("")
            lines.append(f"## Plan status: {counts}")
            next_leaf = plan.root.next_pending_leaf() if plan.root else None
            if next_leaf:
                lines.append(f"**Next pending**: {next_leaf.id} — {next_leaf.title}")
            failed = plan.failed_leaves()
            if failed:
                lines.append(f"**Failed nodes**: {', '.join(f.id for f in failed[:3])}")

        if thoughts:
            lines.append("")
            lines.append("## Last reasoning")
            for t in thoughts[-3:]:
                lines.append(f"- {t[:200]}")

        lines.append("")
        lines.append(f"## Session metrics")
        lines.append(f"- Actions: {len(self.state.actions_taken)}")
        lines.append(f"- Tokens: {self.state.total_prompt_tokens + self.state.total_completion_tokens}")
        lines.append(f"- Compactions: {self.state.compaction_count}")
        lines.append(f"- Restart depth: {self.state.restart_depth}")

        handoff_content = "\n".join(lines)
        self.store.add_artifact(task_id, "handoff", f"Shift handoff ({reason})", handoff_content)
        logger.info("Shift handoff written for task %s (%s)", task_id, reason)

    def _save_scratch(self, messages: list[Message]) -> str:
        """Save dropped messages to session temp root (inside workspace, readable by editor)."""
        from pathlib import Path as _Path
        scratch_dir = _Path(self._temp_root) if hasattr(self, '_temp_root') else _Path.home() / ".pascal" / "scratch"
        scratch_dir.mkdir(parents=True, exist_ok=True)
        path = scratch_dir / f"context_{self.state.compaction_count}.md"
        lines = []
        for msg in messages:
            role = msg.role.value if hasattr(msg.role, "value") else str(msg.role)
            content = (msg.content or "")[:2000]
            lines.append(f"## [{role}]\n{content}\n")
        path.write_text("\n".join(lines), encoding="utf-8")
        # Prune old scratch files (keep newest 10)
        scratch_files = sorted(scratch_dir.glob("context_*.md"), key=lambda p: p.stat().st_mtime)
        for old in scratch_files[:-10]:
            try:
                old.unlink()
            except OSError:
                pass
        return str(path)

    # ── Main loop ─────────────────────────────────────────

    # ── Helpers for run() ────────────────────────────────────

    def _save_checkpoint_for(self, result: ToolUseResult, iteration: int) -> None:
        snap = {
            "has_unknown_step": self.state.has_unknown_step,
            "compaction_count": self.state.compaction_count,
            "consecutive_errors": self.state.consecutive_errors,
            "thought_buffer": list(self.state.thought_buffer),
            "error_feedback": self.state.error_feedback,
        }
        active = self.store.get_active_task()
        if active:
            self.store.save_checkpoint(active["id"], iteration, snap)
        elif result.terminal_action in ("complete_task", "fail_task"):
            for h in self.store.get_recent_history(limit=3):
                if h.get("task_id"):
                    self.store.save_checkpoint(h["task_id"], iteration, snap)
                    break

    def _prepare_next_messages(self, messages: list[Message]) -> list[Message]:
        """Prepare messages for the next iteration (desk sync / user input)."""
        self._refresh_tool_preset()
        if self.state.force_full_render:
            self.state.force_full_render = False
            return self._build_initial_messages()
        if self._pending_user_messages:
            user_text = "\n".join(self._pending_user_messages)
            self._pending_user_messages.clear()
            messages.append(Message(role=Role.USER, content=user_text))
        else:
            delta = self.desk.render_delta(
                observation=self.state.last_observation,
                session_metrics=self._session_metrics(),
            )
            messages.append(Message(
                role=Role.USER,
                content=f"[desk update]\n{delta}\n\nDecide your next action.",
            ))
        return messages

    async def _wait_for_input(self) -> None:
        """Park until wake_event or pending user message (daemon/REPL mode)."""
        assert self.wake_event is not None
        self.wake_event.clear()
        while not self.wake_event.is_set():
            self.store.refresh_lock()
            if self._pending_user_messages:
                break
            try:
                await asyncio.wait_for(self.wake_event.wait(), timeout=60)
            except asyncio.TimeoutError:
                pass

    # ── Main loop (single while — Anthropic CU pattern) ───

    async def run(self) -> list[dict[str, Any]]:
        """Run the tool-use loop. Returns action log."""
        if self._locked:
            return [{"action": "wait", "reason": "another run is active", "result": {"locked": True}}]

        messages: list[Message] = self._build_initial_messages()
        if self._pending_user_messages:
            user_text = "\n".join(self._pending_user_messages)
            self._pending_user_messages.clear()
            messages.append(Message(role=Role.USER, content=user_text))
        self.state.force_full_render = False

        try:
            for iteration in range(self._iteration_limit):
                self.store.refresh_lock()

                # Compaction check (before LLM call, not after)
                # microCompact first: clear old tool results to delay full compaction
                if iteration > 0 and self._messages_too_long(messages):
                    self._micro_compact(messages)
                if iteration > 0 and self._messages_too_long(messages):
                    messages = await self._compact_messages(messages)
                    if self.state.compaction_count >= _MAX_COMPACTIONS_BEFORE_RESTART:
                        if self.state.restart_depth >= _MAX_RESTART_DEPTH:
                            logger.warning("Max restart depth (%d) reached", _MAX_RESTART_DEPTH)
                        else:
                            await self._prepare_restart()
                            break

                # Tool use loop
                result = await self._tool_use_loop(messages, iteration)
                self._save_checkpoint_for(result, iteration)

                # Terminal action → check stop
                if result.terminal_action and result.terminal_obs is not None:
                    stop = await self._check_stop(
                        result.terminal_action, result.terminal_decision,
                        result.terminal_result, result.terminal_obs, iteration,
                    )
                    if stop == "break":
                        break
                    if stop == "continue":
                        self.state.force_full_render = True

                # Non-terminal stops
                elif result.stop_reason in ("stagnation", "max_errors"):
                    break
                elif result.stop_reason == "end_turn":
                    if self.wake_event is not None:
                        if not self._pending_user_messages:
                            await self._wait_for_input()
                    else:
                        break

                # Prepare next iteration
                messages = self._prepare_next_messages(messages)

        finally:
            if self.state.restart_depth > 0 and self.state.compaction_count < _MAX_COMPACTIONS_BEFORE_RESTART:
                self.store.set_context("restart_depth", 0)
            await self._cleanup()

        return self.state.actions_taken


async def run_loop(
    store: PascalStore,
    llm,
    *,
    verifier_llm=None,
    ledger: Ledger | None = None,
    mcp_manager: MCPManager | None = None,
    max_effect: str | None = None,
    max_iterations: int = 50,
    max_tool_rounds: int | None = None,
    on_action: Callable[[dict[str, Any]], None] | None = None,
    execute_command: Callable[[str], str] | None = None,
    workspace: str | None = None,
    wake_event: "asyncio.Event | None" = None,
    mode: str | None = None,
) -> list[dict[str, Any]]:
    """Run the Pascal loop. Returns the action log."""
    runner = LoopRunner(
        store, llm,
        verifier_llm=verifier_llm, ledger=ledger, mcp_manager=mcp_manager,
        max_effect=max_effect, max_iterations=max_iterations,
        max_tool_rounds=max_tool_rounds,
        on_action=on_action, execute_command=execute_command,
        workspace=workspace, wake_event=wake_event, mode=mode,
    )
    return await runner.run()


# ── Helpers ───────────────────────────────────────────────

def _get_actionable_pending_tasks(store: PascalStore) -> list[dict[str, Any]]:
    pending = store.get_pending_tasks()
    if not pending:
        return []
    done_ids = {
        r["id"] for r in store.connection.execute("SELECT id FROM tasks WHERE status = 'done'").fetchall()
    }
    actionable = []
    for task in pending:
        deps = []
        if task.get("depends_on"):
            try:
                deps = json.loads(task["depends_on"])
            except (json.JSONDecodeError, TypeError):
                deps = []
        if deps and not all(dep in done_ids for dep in deps):
            continue
        actionable.append(task)
    actionable.sort(key=lambda t: (
        {"urgent": 0, "normal": 1, "low": 2}.get(t.get("priority", "normal"), 1),
        t.get("due_at") or "9999", t.get("created_at") or "",
    ))
    return actionable


def _has_actionable_work(store: PascalStore) -> bool:
    if store.get_active_task():
        return True
    if store.get_pending_notifications():
        return True
    return bool(_get_actionable_pending_tasks(store))




def _iter_plan_actions(decision: dict[str, Any]):
    steps = decision.get("steps")
    if isinstance(steps, list):
        for step in steps:
            if isinstance(step, dict):
                yield step
    plan_tree = decision.get("plan_tree")
    if not isinstance(plan_tree, dict):
        return
    stack = [plan_tree]
    while stack:
        node = stack.pop()
        action = node.get("action")
        if isinstance(action, dict):
            yield action
        children = node.get("children")
        if isinstance(children, list):
            for child in reversed(children):
                if isinstance(child, dict):
                    stack.append(child)



async def _llm_call_with_retry(
    llm, messages, max_retries: int = 3, tools: list | None = None,
    *, daemon_mode: bool = False,
) -> LLMResponse:
    effective_retries = max_retries if not daemon_mode else max(max_retries, 20)
    backoff_cap = 30 if not daemon_mode else 300
    last_exc = None
    for attempt in range(effective_retries):
        try:
            return await llm.chat(messages, tools=tools or [])
        except Exception as exc:
            last_exc = exc
            exc_str = str(exc).lower()
            if any(kw in exc_str for kw in ("429", "rate", "timeout", "502", "503", "504", "connection")):
                wait = min(2 ** attempt, backoff_cap)
                logger.warning("LLM transient error (attempt %d/%d), retrying in %ds: %s",
                               attempt + 1, effective_retries, wait, exc)
                await asyncio.sleep(wait)
                continue
            raise
    assert last_exc is not None, "LLM retry loop exhausted with no exception"
    raise last_exc


async def _notify_channel(message: str) -> None:
    from pascal.trust import scan as _trust_scan
    if _trust_scan(message).verdict == "block":
        logger.warning("Status message blocked by trust scanner")
        return
    try:
        bot = get_channel_bot()
        owner = get_owner_chat_id()
        if bot is not None and owner:
            await asyncio.wait_for(bot.send_message(chat_id=owner, text=message), timeout=15)
            return
    except Exception:
        logger.debug("Channel notification via bot failed", exc_info=True)
    try:
        from pascal.scheduler import send_webhook
        import os as _os
        for url_key in ("PASCAL_SLACK_WEBHOOK", "PASCAL_DISCORD_WEBHOOK"):
            url = _os.environ.get(url_key, "")
            if url:
                send_webhook(url, message)
                return
    except Exception:
        logger.debug("Channel notification via webhook failed", exc_info=True)


_status_callbacks: list = []


def add_status_callback(fn) -> None:
    if fn not in _status_callbacks:
        _status_callbacks.append(fn)


def clear_status_callbacks() -> None:
    """Remove all status callbacks (use on loop restart to prevent duplicates)."""
    _status_callbacks.clear()


def _broadcast_action(action_record: dict[str, Any]) -> None:
    action = action_record.get("action", "?")
    reason = action_record.get("reason", "")
    result = action_record.get("result", {})
    status = result.get("status", "") if isinstance(result, dict) else ""
    icons = {"execute": ">", "shell": ">", "editor": "\U0001f4c4", "computer": "\U0001f5a5",
             "uia": "\U0001f5b1", "code": "\U0001f40d", "channel_reply": "!",
             "think": "\U0001f4ad", "pick_task": "+", "complete_task": "\u2713",
             "fail_task": "\u2717", "delegate": "\u2192", "plan": "\U0001f4cb", "wait": ".", "escalate": "?",
             "memorize": "\U0001f4dd"}
    icon = icons.get(action, " ")
    summary = f"[{icon}] {action}: {reason}"
    if status and status != "ok":
        summary += f" ({status})"
    for fn in _status_callbacks:
        try:
            fn(summary)
        except Exception:
            pass




def _compile_resume_context(store: PascalStore) -> tuple[str, bool, dict]:
    parts: list[str] = []
    has_unknown = False
    restored_state: dict = {}
    active = store.get_active_task()
    if active:
        cp = store.get_latest_checkpoint(active["id"])
        if cp:
            snap = cp.get("snapshot") or {}
            parts.append(f"Resuming task: {active['goal']} (from checkpoint)")
            has_unknown = bool(snap.get("has_unknown_step"))
            restored_state["compaction_count"] = snap.get("compaction_count", 0)
            restored_state["consecutive_errors"] = snap.get("consecutive_errors", 0)
        if active.get("progress"):
            parts.append(f"Last progress: {active['progress']}")
        todos = store.get_todos(active["id"])
        if todos:
            done = sum(1 for t in todos if t["status"] == "done")
            parts.append(f"TODOs: {done}/{len(todos)} completed")
            next_todo = next((t for t in todos if t["status"] == "pending"), None)
            if next_todo:
                parts.append(f"Next step: {next_todo['title']}")

    # Load shift handoff artifact (Anthropic long-running pattern)
    if active:
        handoff = store.get_latest_artifact(active["id"], "handoff")
        if handoff:
            parts.append("## Previous shift handoff")
            parts.append(handoff["content"][:3000])

    history = store.get_recent_history(limit=5)
    if history:
        parts.append("Recent actions:")
        for h in history:
            parts.append(f"  - {h['summary']}")

    for channel in ("telegram", "discord"):
        convos = store.get_recent_conversation(channel, limit=5)
        if convos:
            parts.append(f"Recent conversation ({channel}):")
            for c in convos:
                parts.append(f"  [{c['role']}] {c['content'][:80]}")

    return "\n".join(parts), has_unknown, restored_state
