"""Compaction — token budget management and message compression.

Extracted from loop.py to keep orchestration clean.
"""

from __future__ import annotations

from typing import Any

from pascal.types import Message

# Token budget — provider-aware; fallback to 30k for unknown providers.
DEFAULT_TOKEN_BUDGET = 30_000
PROVIDER_TOKEN_BUDGETS: dict[str, int] = {
    "gpt-4o": 96_000,
    "gpt-5.4": 96_000,
    "claude-sonnet": 150_000,
    "claude-opus": 150_000,
    "claude-haiku": 150_000,
    "gemini": 750_000,
}
TOOL_RESULT_CHAR_BUDGET = 8_000
MAX_COMPACTIONS_BEFORE_RESTART = 3
MAX_RESTART_DEPTH = 5


def _is_cjk_character(ch: str) -> bool:
    codepoint = ord(ch)
    return (
        0x3040 <= codepoint <= 0x30FF
        or 0x31F0 <= codepoint <= 0x31FF
        or 0x3400 <= codepoint <= 0x4DBF
        or 0x4E00 <= codepoint <= 0x9FFF
        or 0xAC00 <= codepoint <= 0xD7AF
        or 0xF900 <= codepoint <= 0xFAFF
    )


def token_budget(model: str) -> int:
    """Provider-aware token budget."""
    for prefix, budget in PROVIDER_TOKEN_BUDGETS.items():
        if prefix in model.lower():
            return budget
    return DEFAULT_TOKEN_BUDGET


def estimate_tokens(text: str) -> int:
    """Fast token estimate that does not undercount CJK text."""
    cjk_chars = sum(1 for ch in text if _is_cjk_character(ch))
    non_cjk_text = "".join(" " if _is_cjk_character(ch) else ch for ch in text)
    word_tokens = len(non_cjk_text.split()) * 1.3
    return int(word_tokens + (cjk_chars * 1.5))


def messages_too_long(messages: list[Message], model: str) -> bool:
    """Check if messages exceed token budget."""
    total = sum(estimate_tokens(m.content or "") for m in messages)
    return total > token_budget(model)


def build_session_summary(actions_taken: list[dict[str, Any]]) -> str:
    """Build a concise summary from the action log. No LLM call needed."""
    if not actions_taken:
        return ""
    completed: list[str] = []
    failed: list[str] = []
    current = None
    for rec in actions_taken:
        action = rec.get("action", "")
        result = rec.get("result", {})
        if action == "complete_task":
            summary = (result.get("summary") or rec.get("reason", ""))[:80] if isinstance(result, dict) else ""
            completed.append(summary)
        elif action == "fail_task":
            failed.append(rec.get("reason", "")[:80])
        elif action == "pick_task":
            task_id = (result.get("activated") or "") if isinstance(result, dict) else ""
            current = task_id
    lines: list[str] = []
    if completed:
        lines.append(f"Completed: {'; '.join(completed)}")
    if failed:
        lines.append(f"Failed: {'; '.join(failed)}")
    if current:
        lines.append(f"Active task: {current}")
    lines.append(f"Actions taken so far: {len(actions_taken)}")
    return "\n".join(lines)
