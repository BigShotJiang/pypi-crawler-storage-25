"""Plan parsing, validation, and single-leaf execution.

Extracted from actions.py -- handles declarative plan trees (one leaf per iteration).
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from pascal.effect import check_allowed, get_max_effect, effect_to_int
from pascal.trust import scan_tool_input
from pascal.types import PlanNode, TaskPlan

if TYPE_CHECKING:
    from pascal.actions import ActionContext

logger = logging.getLogger(__name__)

_PLAN_MAX_STEPS = 20

# Actions that cannot appear inside plan steps (enforced at validation + runtime)
PLAN_FORBIDDEN_ACTIONS = frozenset({"plan", "complete_task", "fail_task", "wait", "escalate"})


def _plan_step_scan_params(action: str, step: dict) -> dict[str, Any] | None:
    """Build scan_tool_input params for a plan step. Returns None if no scan needed."""
    if action == "shell":
        cmd = str(step.get("command") or "").strip()
        return {"command": cmd} if cmd else None
    if action == "code":
        code = str(step.get("code") or "").strip()
        return {"code": code} if code else None
    if action == "delegate":
        task = str(step.get("task") or "").strip()
        return {"task": task} if task else None
    if action in ("editor", "computer", "uia"):
        return {k: v for k, v in step.items() if k != "action"}
    if action == "channel_reply":
        text = str(step.get("text") or step.get("reply_text") or "").strip()
        return {"text": text} if text else None
    return None


def _build_progress_summary(counts: dict[str, int]) -> str:
    total = sum(counts.values())
    done = counts.get("done", 0)
    failed = counts.get("failed", 0)
    pending = counts.get("pending", 0)
    if total == 0:
        return "0/0 done"
    return f"{done}/{total} done" + (f", {failed} failed" if failed else "") + (f", {pending} pending" if pending else "")


def _finalize_plan_result(
    ctx: ActionContext, task_id: str, *, plan: TaskPlan,
    executed: int, executed_node_id: str | None = None,
    step_result: dict[str, Any] | None = None, force_status: str | None = None,
) -> dict[str, Any]:
    plan.active_node_id = None
    ctx.store.set_task_plan(task_id, plan.to_dict())
    counts = plan.root.count_by_status() if plan.root else {}
    total = len(plan.root.get_leaves()) if plan.root else 0
    next_leaf = plan.root.next_pending_leaf() if plan.root else None
    result: dict[str, Any] = {
        "plan_stored": True,
        "plan_completed": counts.get("pending", 0) == 0 and counts.get("failed", 0) == 0,
        "executed": executed, "status": force_status or "ok",
        "status_counts": counts, "leaves_total": total,
        "progress_summary": _build_progress_summary(counts),
    }
    if executed_node_id:
        result["executed_node_id"] = executed_node_id
    if next_leaf is not None:
        result["next_pending_node_id"] = next_leaf.id
    if isinstance(step_result, dict) and step_result.get("attachment"):
        result["attachment"] = step_result["attachment"]
    if counts.get("failed", 0) > 0:
        failed = plan.failed_leaves()
        result["failed_node"] = failed[0].to_dict() if failed else None
        if force_status is None:
            result["status"] = "error"
    return result


def _parse_plan_input(
    ctx: ActionContext, decision: dict[str, Any], active: dict[str, Any],
    valid_actions: frozenset[str],
) -> TaskPlan | dict[str, Any]:
    """Parse plan input (tree/steps/existing). Returns TaskPlan or error dict."""
    plan_tree_data = decision.get("plan_tree")
    steps = decision.get("steps") or []
    patch_node_id = decision.get("patch_node_id")
    existing_data = ctx.store.get_task_plan(active["id"])
    existing_plan = TaskPlan.from_dict(existing_data) if existing_data else None

    if plan_tree_data:
        try:
            root = PlanNode.from_dict(plan_tree_data)
        except (KeyError, TypeError) as e:
            return {"error": f"invalid plan_tree: {e}", "status": "error"}
        plan = TaskPlan(root=root)
        errors = plan.validate()
        if errors:
            return {"error": f"plan validation failed: {'; '.join(errors[:5])}", "status": "error"}
    elif steps:
        if len(steps) > _PLAN_MAX_STEPS:
            return {"error": f"plan has {len(steps)} steps, max is {_PLAN_MAX_STEPS}", "status": "error"}
        children = []
        for i, step in enumerate(steps):
            if not isinstance(step, dict):
                return {"error": f"step {i} must be a dict", "status": "error"}
            step_action = str(step.get("action") or "").strip()
            if not step_action or step_action not in valid_actions or step_action in PLAN_FORBIDDEN_ACTIONS:
                return {"error": f"step {i}: action '{step_action}' is not allowed inside a plan", "status": "error"}
            children.append(PlanNode(
                id=f"s{i}",
                title=str(step.get("reason") or step.get("command") or step.get("tool") or f"step {i}"),
                kind="leaf",
                done_when=str(step.get("done_when") or step.get("expected_evidence") or "action completes successfully"),
                action=step,
            ))
        root = PlanNode(id="root", title=active["goal"][:80], kind="branch", children=children)
        plan = TaskPlan(root=root)
    elif existing_plan is not None:
        plan = existing_plan
    else:
        return {"error": "plan requires 'plan_tree' or 'steps'", "status": "error"}

    # Subtree repair
    if patch_node_id:
        if existing_plan is None or existing_plan.root is None:
            return {"error": "patch_node_id specified but no existing plan", "status": "error"}
        target = existing_plan.root.find_node(patch_node_id)
        if target is None or plan.root is None:
            return {"error": f"patch target node '{patch_node_id}' not found in existing plan", "status": "error"}
        target.kind = "branch"
        target.children = plan.root.children if plan.root.kind == "branch" else [plan.root]
        target.status = "pending"
        target.action = None
        target.last_error = None
        target.attempts = 0
        existing_plan.revision += 1
        plan = existing_plan

    if not patch_node_id and (plan_tree_data or steps):
        plan.revision = (plan.revision or 0)
    ctx.store.set_task_plan(active["id"], plan.to_dict())
    return plan


async def _execute_plan_leaf(
    ctx: ActionContext, plan: TaskPlan, leaf: PlanNode, active: dict[str, Any],
    valid_actions: frozenset[str],
) -> dict[str, Any]:
    """Execute one plan leaf: governance, trust scan, dispatch, record."""
    from pascal.actions import execute_action

    task_id = active["id"]
    step = leaf.action or {}
    step_action = str(step.get("action") or "").strip()

    if not step_action or step_action not in valid_actions or step_action in PLAN_FORBIDDEN_ACTIONS:
        leaf.status = "failed"
        leaf.last_error = f"action '{step_action}' is not allowed inside a plan"
        return _finalize_plan_result(ctx, task_id, plan=plan, executed=0, executed_node_id=leaf.id, force_status="error")

    gov_error = ctx.check_governance(step_action, step)
    if gov_error:
        leaf.status = "failed"
        leaf.last_error = gov_error[:200]
        return _finalize_plan_result(ctx, task_id, plan=plan, executed=0, executed_node_id=leaf.id, force_status="error")

    _scan_input = _plan_step_scan_params(step_action, step)
    if _scan_input is not None:
        _scan = scan_tool_input(step_action, _scan_input)
        if _scan.verdict == "block":
            leaf.status = "failed"
            leaf.last_error = f"blocked by trust scanner: {_scan.reason}"
            return _finalize_plan_result(ctx, task_id, plan=plan, executed=0, executed_node_id=leaf.id, force_status="error")

    # Record node execution start
    import json as _json
    exec_id = ctx.store.create_node_execution(
        task_id, leaf.id,
        executor=leaf.executor or "local",
        plan_revision=plan.revision,
    )
    ctx.store.update_node_execution(exec_id, status="running", claim_json=_json.dumps(step, default=str))

    try:
        step_result = await execute_action(ctx.store, step, step_action, ctx=ctx)
    except Exception as exc:
        leaf.status = "failed"
        leaf.attempts += 1
        leaf.last_error = f"crash: {exc!r}"[:200]
        ctx.store.update_node_execution(exec_id, status="failed", evidence_json=_json.dumps({"error": str(exc)[:200]}))
        logger.error("Plan step %s crashed: %s", leaf.id, exc, exc_info=True)
        return _finalize_plan_result(ctx, task_id, plan=plan, executed=0, executed_node_id=leaf.id, force_status="error")

    step_reason = str(step.get("reason") or step.get("command") or step.get("tool") or "")
    ctx.store.record(
        f"{step_action}: {step_reason}" if step_reason else step_action,
        task_id=task_id,
        details={"decision": step, "result": step_result, "plan_node_id": leaf.id},
        action_status=step_result.get("status", "ok") if isinstance(step_result, dict) else "ok",
    )
    if ctx.ledger is not None:
        ctx.ledger.record_action(step_action, step, step_result)
    if isinstance(step_result, dict):
        ctx.record_step_complete(step_action, step, step_result)

    step_status = step_result.get("status", "ok") if isinstance(step_result, dict) else "ok"
    if isinstance(step_result, dict) and (step_result.get("error") or step_result.get("escalate")):
        leaf.status = "failed"
        leaf.attempts += 1
        leaf.last_error = str(step_result.get("error") or "escalated")[:200]
        ctx.store.update_node_execution(exec_id, status="failed", evidence_json=_json.dumps(step_result, default=str)[:2000])
        return _finalize_plan_result(ctx, task_id, plan=plan, executed=1, executed_node_id=leaf.id, step_result=step_result, force_status="error")
    if step_status == "unknown":
        leaf.status = "failed"
        leaf.attempts += 1
        leaf.last_error = "Action returned unknown status (side effect uncertain). Needs verification."
        ctx.store.update_node_execution(exec_id, status="failed", evidence_json=_json.dumps({"status": "unknown"}))
        return _finalize_plan_result(ctx, task_id, plan=plan, executed=1, executed_node_id=leaf.id, step_result=step_result, force_status="unknown")

    # Mark done (or claimed if proof_required — verifier will promote to verified later)
    final_status = "done" if not leaf.proof_required else "claimed"
    leaf.status = "done"
    ctx.store.update_node_execution(
        exec_id, status=final_status,
        evidence_json=_json.dumps(step_result, default=str)[:2000] if isinstance(step_result, dict) else "{}",
    )
    return _finalize_plan_result(ctx, task_id, plan=plan, executed=1, executed_node_id=leaf.id, step_result=step_result if isinstance(step_result, dict) else None)


async def handle_plan(ctx: ActionContext, decision: dict[str, Any], valid_actions: frozenset[str]) -> dict[str, Any]:
    """Top-level plan handler: parse input, pick next leaf, execute it."""
    active = ctx.store.get_active_task()
    if not active:
        return {"error": "no active task to plan for", "status": "error"}

    result = _parse_plan_input(ctx, decision, active, valid_actions)
    if isinstance(result, dict):
        return result  # error
    plan = result

    leaf = plan.root.next_pending_leaf() if plan.root else None
    if leaf is None:
        force_status = "error" if plan.failed_leaves() else "ok"
        return _finalize_plan_result(ctx, active["id"], plan=plan, executed=0, force_status=force_status)

    leaf.status = "active"
    plan.active_node_id = leaf.id
    ctx.store.set_task_plan(active["id"], plan.to_dict())

    return await _execute_plan_leaf(ctx, plan, leaf, active, valid_actions)
