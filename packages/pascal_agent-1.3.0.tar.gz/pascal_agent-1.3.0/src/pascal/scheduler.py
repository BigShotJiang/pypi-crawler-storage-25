"""Scheduler -- bounded tick for periodic checks. Not a daemon.

Usage:
  pascal --tick                              # manual
  */5 * * * * pascal --tick                  # cron
"""

from __future__ import annotations

import json
import logging
import os
import urllib.error
import urllib.request
from datetime import datetime, timedelta, timezone
from typing import Any, Callable

from pascal.state import PascalStore

logger = logging.getLogger(__name__)


def _cron_field_matches(field: str, value: int) -> bool:
    """Match a single cron field against a value. Supports *, integers, and */N step."""
    if field == "*":
        return True
    if field.startswith("*/"):
        try:
            step = int(field[2:])
            return step > 0 and value % step == 0
        except (ValueError, TypeError):
            return False
    try:
        return int(field) == value
    except (ValueError, TypeError):
        return False


def _cron_matches(cron_expr: str, dt: datetime) -> bool:
    """Simple cron matching: 'minute hour day month weekday'.
    Supports *, integers, and */N step. Weekday: 0=Monday ... 6=Sunday."""
    try:
        parts = cron_expr.strip().split()
        if len(parts) != 5:
            return False
        checks = [
            (parts[0], dt.minute),
            (parts[1], dt.hour),
            (parts[2], dt.day),
            (parts[3], dt.month),
            (parts[4], dt.weekday()),
        ]
        return all(_cron_field_matches(field, value) for field, value in checks)
    except (ValueError, TypeError):
        return False


def send_webhook(url: str, text: str) -> bool:
    """Send a message via webhook (Slack or Discord)."""
    if not url:
        return False
    payload = json.dumps(
        {"text": text} if "slack" in url else {"content": text[:2000], "username": "Pascal"}
    ).encode("utf-8")
    req = urllib.request.Request(
        url, data=payload,
        headers={"Content-Type": "application/json"}, method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return resp.status in (200, 204)
    except (urllib.error.URLError, OSError) as exc:
        logger.warning("Webhook send failed: %s", exc)
        return False


class Scheduler:
    def __init__(self, store: PascalStore, emit: Callable[[str], None] | None = None):
        self.store = store
        self._emit = emit or print
        self._slack_url = os.environ.get("PASCAL_SLACK_WEBHOOK", "")
        self._discord_url = os.environ.get("PASCAL_DISCORD_WEBHOOK", "")

    def tick(self) -> dict[str, Any]:
        """One bounded tick. Returns summary."""
        overdue = self._check_overdue()
        stale = self._check_stale()
        expired = self.store.cleanup_expired_context()
        pending = self._count_pending_notifications()

        for item in overdue:
            promised = ""
            if item.get("promised_to"):
                try:
                    names = json.loads(item["promised_to"])
                    promised = f"\nPromised to: {', '.join(names)}"
                except (json.JSONDecodeError, TypeError):
                    pass
            msg = f"Overdue: {item['goal']}\nDue: {item['due_at']}{promised}"
            self._broadcast(msg)

        for item in stale:
            self._broadcast(f"Stale ({item['status']}): {item['goal']}")

        due_routines = self._check_routines()

        return {
            "overdue": len(overdue),
            "stale": len(stale),
            "expired_context": expired,
            "pending_notifications": pending,
            "due_routines": due_routines,
        }

    def _broadcast(self, message: str) -> None:
        """Send to CLI + any configured webhooks."""
        self._emit(message)
        if self._slack_url:
            send_webhook(self._slack_url, message)
        if self._discord_url:
            send_webhook(self._discord_url, message)

    def _check_overdue(self) -> list[dict[str, Any]]:
        now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")
        rows = self.store.connection.execute(
            "SELECT id, goal, status, due_at, promised_to FROM tasks "
            "WHERE due_at IS NOT NULL AND due_at < ? AND status NOT IN ('done', 'failed') "
            "ORDER BY due_at ASC", (now,),
        ).fetchall()
        return [dict(r) for r in rows]

    def _check_stale(self, days: int = 3) -> list[dict[str, Any]]:
        cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).strftime("%Y-%m-%dT%H:%M:%S.%fZ")
        rows = self.store.connection.execute(
            "SELECT id, goal, status, updated_at FROM tasks "
            "WHERE status IN ('active', 'paused') "
            "AND updated_at < ?", (cutoff,),
        ).fetchall()
        return [dict(r) for r in rows]

    def _count_pending_notifications(self) -> int:
        row = self.store.connection.execute(
            "SELECT COUNT(*) FROM notifications WHERE status = 'pending'"
        ).fetchone()
        return row[0] if row else 0

    def _check_routines(self) -> int:
        """Check context for due routines, create notifications for them."""
        routines = self.store.get_context("routines")
        if not routines or not isinstance(routines, list):
            return 0
        now = datetime.now(timezone.utc)
        dedup_prefix = now.strftime("%Y%m%d%H")
        fired = 0
        for r in routines:
            name = r.get("name", "")
            cron = r.get("cron", "")
            goal = r.get("task_goal", "")
            if not cron or not goal:
                continue
            if not _cron_matches(cron, now):
                continue
            idem_key = f"routine:{name}:{dedup_prefix}"
            existing = self.store.connection.execute(
                "SELECT id FROM notifications WHERE metadata LIKE ? AND status != 'dismissed'",
                (f'%{idem_key}%',),
            ).fetchone()
            if existing:
                continue
            self.store.push_notification(
                source="routine",
                message=f"[Routine: {name}] {goal}",
                priority="normal",
                event_type="timer",
                metadata={"routine_name": name, "idem_key": idem_key},
            )
            fired += 1
        return fired


