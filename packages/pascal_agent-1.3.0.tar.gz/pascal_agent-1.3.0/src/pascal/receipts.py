"""Append-only audit ledger — plain JSONL, no frills."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from pascal.types import json_safe as _json_safe


class Ledger:
    """Append-only JSONL ledger."""

    def __init__(self, path: str | Path) -> None:
        self._path = Path(path).expanduser().resolve()
        self._path.parent.mkdir(parents=True, exist_ok=True)

    def record(self, kind: str, payload: dict[str, Any]) -> None:
        """Append an entry."""
        entry = {
            "time": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
            "kind": kind,
            **payload,
        }
        line = json.dumps(entry, ensure_ascii=False, default=_json_safe) + "\n"
        with open(self._path, "a", encoding="utf-8") as f:
            f.write(line)

    def record_action(self, action: str, decision: dict[str, Any], result: dict[str, Any]) -> None:
        self.record("action", {"action": action, "decision": decision, "result": result})
