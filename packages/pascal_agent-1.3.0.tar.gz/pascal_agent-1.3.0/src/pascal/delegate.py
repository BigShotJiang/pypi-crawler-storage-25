"""Delegate handler -- spawn Claude Code / Codex CLI subprocesses.

Extracted from actions.py -- handles sync (one-shot) and async (daemon/repl) delegation.
"""

from __future__ import annotations

import asyncio
import logging
import os
from typing import TYPE_CHECKING, Any

from pascal.effect import check_allowed, get_max_effect, escalation_message
from pascal.sandbox import decode_subprocess_output, make_safe_env
from pascal.trust import scan_tool_input

if TYPE_CHECKING:
    from pascal.actions import ActionContext

logger = logging.getLogger(__name__)

DELEGATE_TOOLS = {
    "claude-code": ["claude", "--print", "-p"],
    "codex": ["codex", "-q"],
}
_DELEGATE_MAX_TIMEOUT = 600
_DELEGATE_RESULT_PREFIX = "delegate_result:"
_DELEGATE_BACKGROUND_TASKS: set[asyncio.Task[Any]] = set()


def _persist_delegate_error(
    ctx: ActionContext, child_task_id: str, result_key: str,
    tool_name: str, error_text: str, status: str = "error",
) -> dict[str, Any]:
    """Persist delegate error to task + context and return error payload."""
    try:
        ctx.store.update_task(child_task_id, status="failed", progress=error_text, result=error_text)
        ctx.store.set_context(result_key, {
            "status": status, "tool": tool_name, "task_id": child_task_id,
            "output": "", "stderr": "", "error": error_text,
        }, ttl_hours=24)
    except Exception:
        logger.exception("failed to persist delegate error for %s", child_task_id)
    return {
        "status": status, "tool": tool_name, "output": "", "stderr": "",
        "error": error_text, "task_id": child_task_id,
    }


async def handle_delegate(ctx: ActionContext, decision: dict[str, Any]) -> dict[str, Any]:
    """Delegate a task to Claude Code or Codex CLI."""
    tool_name = str(decision.get("tool") or "").strip()
    if tool_name not in DELEGATE_TOOLS:
        return {"error": f"Unknown delegate tool '{tool_name}'. Available: {', '.join(DELEGATE_TOOLS)}", "status": "error"}

    task_desc = str(decision.get("task") or "").strip()
    if not task_desc:
        return {"error": "delegate requires a 'task' field", "status": "error"}

    context = str(decision.get("context") or "").strip()
    success_criteria = str(decision.get("success_criteria") or "").strip()

    combined_text = f"{task_desc}\n{context}\n{success_criteria}"
    scan_result = scan_tool_input("delegate", {"task": combined_text})
    if scan_result.verdict == "block":
        return {"error": f"blocked by trust scanner: {scan_result.reason}", "status": "error"}

    allowed_max = get_max_effect(ctx.max_effect)
    if not check_allowed("E2", allowed_max):
        return {
            "error": escalation_message(f"delegate:{tool_name}", "E2", allowed_max),
            "status": "error", "effect_level": "E2", "escalate": True,
        }

    prompt_parts = [task_desc]
    if context:
        prompt_parts.append(f"\nContext: {context}")
    if success_criteria:
        prompt_parts.append(f"\nSuccess criteria: {success_criteria}")
    prompt = "\n".join(prompt_parts)

    cmd_base = DELEGATE_TOOLS[tool_name]
    cmd = cmd_base + [prompt]
    timeout = min(int(decision.get("timeout") or 300), _DELEGATE_MAX_TIMEOUT)

    active = ctx.store.get_active_task()
    child_task_id = ctx.store.add_task(
        task_desc,
        priority=str(active["priority"]) if active else "normal",
        source="agent",
        parent_id=str(active["id"]) if active else None,
    )
    is_background = ctx.mode in ("daemon", "repl")
    progress = (
        f"Delegated to {tool_name}; running asynchronously"
        if is_background
        else f"Delegated to {tool_name}; running now"
    )
    ctx.store.update_task(child_task_id, status="blocked", progress=progress)
    if active:
        ctx.store.update_task(active["id"], progress=f"Delegated {child_task_id} to {tool_name}")

    result_key = f"{_DELEGATE_RESULT_PREFIX}{child_task_id}"

    async def _run_delegate(*, persist_result: bool) -> dict[str, Any]:
        import shutil as _shutil
        from pathlib import Path as _P

        from pascal.actions import _truncate_output

        proc = None
        refresh_task = None
        safe_env, tmp_home = make_safe_env()

        def _cleanup_tmp() -> None:
            try:
                if os.path.isdir(tmp_home):
                    _shutil.rmtree(tmp_home, ignore_errors=True)
                from pascal.sandbox import _sandbox_temp_dirs
                if tmp_home in _sandbox_temp_dirs:
                    _sandbox_temp_dirs.remove(tmp_home)
            except Exception:
                pass

        try:
            real_home = _P.home()
            auth_files = {
                ".codex": ["auth.json"],
                ".claude": ["auth.json", "config.toml"],
            }
            for auth_dir, allowed_files in auth_files.items():
                src = real_home / auth_dir
                dst = _P(tmp_home) / auth_dir
                if not src.is_dir():
                    continue
                try:
                    dst.mkdir(exist_ok=True)
                    for filename in allowed_files:
                        src_file = src / filename
                        if src_file.exists():
                            _shutil.copy2(str(src_file), str(dst / filename))
                except Exception:
                    pass

            ctx.store.refresh_lock()

            workspace = ctx.sandbox._restricted._workspace if ctx.sandbox else ""
            cwd = workspace if workspace and os.path.isdir(workspace) else os.getcwd()
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=cwd,
                env=safe_env,
            )

            async def _refresh_until_done() -> None:
                while proc.returncode is None:
                    await asyncio.sleep(60)
                    ctx.store.refresh_lock()

            refresh_task = asyncio.create_task(_refresh_until_done())
            try:
                stdout_bytes, stderr_bytes = await asyncio.wait_for(proc.communicate(), timeout=timeout)
            finally:
                if refresh_task is not None:
                    refresh_task.cancel()
                    try:
                        await refresh_task
                    except asyncio.CancelledError:
                        pass

            stdout = decode_subprocess_output(stdout_bytes)
            stderr = decode_subprocess_output(stderr_bytes)
            ok = proc.returncode == 0

            # Structured evidence package (Anthropic multi-agent pattern:
            # workers return compressed findings, not raw dumps)
            import json as _json
            evidence = {
                "exit_code": proc.returncode,
                "output_lines": len(stdout.splitlines()),
                "summary": (stdout.strip()[:500] or f"Delegate {'completed' if ok else 'failed'} via {tool_name}"),
                "errors": stderr.strip()[:500] if stderr else "",
            }

            payload = {
                "status": "ok" if ok else "error",
                "tool": tool_name,
                "output": stdout[:8000],
                "stderr": stderr[:2000] if stderr else "",
                "task_id": child_task_id,
                "evidence": evidence,
            }
            if ok:
                summary = _truncate_output(stdout.strip() or f"Delegate completed via {tool_name}")
                ctx.store.update_task(
                    child_task_id,
                    status="done",
                    progress=f"Delegate completed via {tool_name}",
                    result=summary,
                )
                # Persist evidence as durable artifact
                ctx.store.add_artifact(
                    child_task_id, "evidence",
                    f"Delegate result: {tool_name}",
                    _json.dumps(evidence, ensure_ascii=False),
                )
            else:
                error_text = stderr.strip() or stdout.strip() or f"{tool_name} exited with code {proc.returncode}"
                summary = _truncate_output(error_text)
                payload["error"] = summary
                ctx.store.update_task(
                    child_task_id,
                    status="failed",
                    progress=f"Delegate failed via {tool_name}: {summary}",
                    result=summary,
                )
            if persist_result:
                ctx.store.set_context(result_key, payload, ttl_hours=24)
            return payload
        except asyncio.TimeoutError:
            if proc is not None:
                try:
                    proc.kill()
                except ProcessLookupError:
                    pass
            return _persist_delegate_error(
                ctx, child_task_id, result_key, tool_name,
                f"delegate:{tool_name} timed out ({timeout}s)", status="unknown",
            )
        except FileNotFoundError:
            return _persist_delegate_error(
                ctx, child_task_id, result_key, tool_name,
                f"'{cmd_base[0]}' not found. Is {tool_name} installed?",
            )
        except Exception as exc:
            logger.exception("delegate background task failed for %s", child_task_id)
            return _persist_delegate_error(
                ctx, child_task_id, result_key, tool_name,
                f"delegate failed: {exc}",
            )
        finally:
            _cleanup_tmp()

    if not is_background:
        result = await _run_delegate(persist_result=False)
        result["delegate"] = True
        result["child_task_id"] = child_task_id
        return result

    background_task = asyncio.create_task(_run_delegate(persist_result=True))
    _DELEGATE_BACKGROUND_TASKS.add(background_task)
    background_task.add_done_callback(_DELEGATE_BACKGROUND_TASKS.discard)

    return {
        "child_task_id": child_task_id,
        "status": "spawned",
        "tool": tool_name,
        "delegate": True,
    }


async def handle_check_delegate(ctx: ActionContext, decision: dict[str, Any]) -> dict[str, Any]:
    """Check the status of an async delegate and retrieve its result once ready."""
    task_id = str(decision.get("task_id") or decision.get("child_task_id") or "").strip()
    if not task_id:
        return {"error": "check_delegate requires a 'task_id' field", "status": "error"}

    row = ctx.store.connection.execute("SELECT * FROM tasks WHERE id = ?", (task_id,)).fetchone()
    if row is None:
        return {"error": f"Unknown delegate task '{task_id}'", "status": "error"}

    task = dict(row)
    if task["status"] not in {"done", "failed"}:
        return {"status": "running", "task_id": task_id}

    result_key = f"{_DELEGATE_RESULT_PREFIX}{task_id}"
    payload = ctx.store.get_context(result_key)
    if payload is not None:
        ctx.store.delete_context(result_key)
    if payload is None:
        payload = {
            "status": "ok" if task["status"] == "done" else "error",
            "tool": "delegate",
            "output": task.get("result") or "",
            "stderr": "",
            "task_id": task_id,
        }
        if task["status"] == "failed" and task.get("result"):
            payload["error"] = task["result"]

    return {
        "status": task["status"],
        "task_id": task_id,
        "result": payload,
        "delegate": True,
        "tool": payload.get("tool", "delegate"),
    }
