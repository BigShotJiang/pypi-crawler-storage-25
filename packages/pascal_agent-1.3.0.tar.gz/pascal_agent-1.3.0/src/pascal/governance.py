"""Governance — stagnation detection and safety gating.

Extracted from loop.py to keep orchestration clean.
"""

from __future__ import annotations

from typing import Any

# Graduated stagnation thresholds (GPT Pro + browser-use pattern)
STAGNATION_NUDGE = 3       # soft warning, action still allowed
STAGNATION_REPLAN = 5      # block action, force different approach
STAGNATION_HARD_STOP = 7   # terminate loop

SIDE_EFFECT_ACTIONS = frozenset({
    "execute", "shell", "editor", "computer", "uia", "code", "channel_reply",
})

# Observation actions: lower stagnation weight (GPT Pro + browser-use pattern)
_OBSERVATION_SIGNATURES = frozenset({
    "computer:screenshot", "editor:read", "editor:list", "uia:snapshot",
})


def recent_error_streak(actions_taken: list[dict[str, Any]]) -> int:
    """Count consecutive recent errors in action history."""
    streak = 0
    for rec in reversed(actions_taken):
        result = rec.get("result")
        if not isinstance(result, dict):
            break
        status = str(result.get("status") or "").strip().lower()
        if status not in {"error", "unknown"}:
            break
        if rec.get("action") not in SIDE_EFFECT_ACTIONS and rec.get("action") != "plan":
            break
        streak += 1
    return streak


def stagnation_signature(action: str, decision: dict[str, Any]) -> str:
    """Build stagnation signature: family:op:target."""
    if action == "shell":
        return str(decision.get("command") or "").strip()
    if action in ("editor", "computer", "uia"):
        op = str(decision.get("op") or "").strip()
        target = str(
            decision.get("path") or decision.get("ref") or decision.get("title")
            or f"{decision.get('x', '')},{decision.get('y', '')}"
            if decision.get("x") else ""
        ).strip()
        parts = [action, op] if op else [action]
        if target and target != ",":
            parts.append(target[:60])
        return ":".join(parts)
    if action == "code":
        code = str(decision.get("code") or "").strip()[:80]
        return f"code:{code}" if code else "code"
    if action == "execute":
        command = str(decision.get("command") or "").strip()
        if command:
            return command
        tool = str(decision.get("tool") or "").strip()
        tool_params = decision.get("tool_params") or {}
        if not isinstance(tool_params, dict):
            tool_params = {}
        op = str(tool_params.get("op") or "").strip()
        if tool:
            return f"{tool}:{op}" if op else tool
    return ""


def count_stagnation(actions_taken: list[dict[str, Any]], current_signature: str) -> int:
    """Count consecutive repetitions of the same signature.

    Observation actions (screenshot, read) counted at half weight.
    """
    count = 0
    is_observation = current_signature in _OBSERVATION_SIGNATURES
    for record in reversed(actions_taken):
        rec_decision = record.get("decision") or {}
        if not isinstance(rec_decision, dict):
            rec_decision = {}
        rec_action = str(rec_decision.get("action") or record.get("action") or "").strip()
        if rec_action not in ("execute", "shell", "editor", "computer", "uia", "code", "plan"):
            continue
        sig = stagnation_signature(rec_action, rec_decision)
        if not sig:
            continue
        if sig == current_signature:
            count += 1
        else:
            break
    if is_observation:
        count = count // 2
    return count
