"""pascal/config.py -- PascalConfig 로드 (환경변수 + 기본값)."""

from __future__ import annotations

import os
import tomllib
from pathlib import Path

from pascal.types import PascalConfig


def _load_dotenv() -> None:
    """Load ~/.pascal/.env into os.environ (won't overwrite existing vars)."""
    env_path = Path.home() / ".pascal" / ".env"
    if not env_path.is_file():
        return
    try:
        for line in env_path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, value = line.partition("=")
            key = key.strip()
            value = value.strip().strip("'\"")
            if key and key not in os.environ:  # don't overwrite
                os.environ[key] = value
    except OSError:
        pass


# Auto-load on import
_load_dotenv()

_ENV_MAP: dict[str, tuple[str, type]] = {
    "model": ("PASCAL_MODEL", str),
    "provider": ("PASCAL_PROVIDER", str),
    "base_url": ("PASCAL_BASE_URL", str),
    "db_path": ("PASCAL_DB_PATH", str),
    "max_effect": ("PASCAL_MAX_EFFECT", str),
}

_EXTRA_ENV_MAP: dict[str, tuple[str, type]] = {
    "max_inner_turns": ("PASCAL_MAX_INNER_TURNS", int),
    "max_tool_rounds": ("PASCAL_MAX_TOOL_ROUNDS", int),
}


def _config_paths() -> list[Path]:
    seen: set[Path] = set()
    paths: list[Path] = []
    for path in (Path.cwd() / "pascal.toml", Path.home() / ".pascal" / "pascal.toml"):
        try:
            key = path.resolve()
        except OSError:
            key = path.absolute()
        if key in seen:
            continue
        seen.add(key)
        paths.append(path)
    return paths


def _load_toml_config() -> dict[str, object]:
    for path in _config_paths():
        if not path.is_file():
            continue
        with path.open("rb") as f:
            payload = tomllib.load(f)
        section = payload.get("pascal")
        if isinstance(section, dict):
            return section
    return {}


def _load_typed_values(raw: dict[str, object], mapping: dict[str, tuple[str, type]]) -> dict[str, object]:
    values: dict[str, object] = {}
    for field_name, (_, conv) in mapping.items():
        if field_name not in raw or raw[field_name] is None:
            continue
        values[field_name] = conv(raw[field_name])
    return values


def _resolve_extra_value(
    name: str,
    *,
    toml_values: dict[str, object],
    overrides: dict[str, object],
) -> int | None:
    value = toml_values.get(name)
    env_key, conv = _EXTRA_ENV_MAP[name]
    env_val = os.environ.get(env_key)
    if env_val is not None:
        value = conv(env_val)
    if name in overrides and overrides[name] is not None:
        value = overrides[name]
    if value is None:
        return None
    return max(1, int(str(value)))


def load_config(**overrides) -> PascalConfig:
    """PascalConfig를 생성한다. 우선순위: overrides > 환경변수 > pascal.toml > 기본값."""
    toml_values = _load_toml_config()
    kwargs: dict[str, object] = _load_typed_values(toml_values, _ENV_MAP)
    for field_name, (env_key, conv) in _ENV_MAP.items():
        env_val = os.environ.get(env_key)
        if env_val is not None:
            kwargs[field_name] = conv(env_val)
    kwargs.update({k: v for k, v in overrides.items() if k in _ENV_MAP and v is not None})

    config = PascalConfig(**kwargs)  # type: ignore[arg-type]  # kwargs built from validated ENV_MAP
    max_inner = _resolve_extra_value("max_inner_turns", toml_values=toml_values, overrides=overrides)
    if max_inner is not None:
        config.max_inner_turns = max_inner
    max_tool = _resolve_extra_value("max_tool_rounds", toml_values=toml_values, overrides=overrides)
    if max_tool is not None:
        config.max_tool_rounds = max_tool
    return config


def resolve_max_tool_rounds(config: PascalConfig, args=None, *, daemon_mode: bool = False) -> int:
    """Resolve max_tool_rounds: CLI > config > mode default."""
    cli_rounds = getattr(args, "max_tool_rounds", None) if args else None
    if cli_rounds is not None:
        return max(1, int(cli_rounds))
    config_rounds = getattr(config, "max_tool_rounds", None)
    if config_rounds is not None:
        return max(1, int(config_rounds))
    cli_turns = getattr(args, "max_inner_turns", None) if args else None
    if cli_turns is not None:
        return max(1, int(cli_turns))
    config_turns = getattr(config, "max_inner_turns", None)
    if config_turns is not None:
        return max(1, int(config_turns))
    return 3 if daemon_mode else 1


def create_llm(config: PascalConfig):
    """Create an LLM provider from config. Avoids duplication between __main__ and daemon."""
    if config.provider == "codex":
        from pascal.llm.codex import CodexProvider
        return CodexProvider(model=config.model)
    elif config.provider == "openai":
        from pascal.llm.openai import OpenAIProvider
        return OpenAIProvider(model=config.model, base_url=config.base_url)
    elif config.provider == "anthropic":
        from pascal.llm.anthropic import AnthropicProvider
        return AnthropicProvider(model=config.model, base_url=config.base_url)
    else:
        raise ValueError(f"Unknown provider: {config.provider}")
