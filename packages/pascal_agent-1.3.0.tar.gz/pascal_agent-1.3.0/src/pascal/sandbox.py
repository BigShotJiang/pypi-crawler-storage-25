"""Sandbox -- isolated command execution.

Docker (if available) → RestrictedSandbox (fallback).
Ported from Dorothy2. Zero framework dependencies.
"""

from __future__ import annotations

import locale
import logging
import os
import re
import shlex
import shutil
import subprocess
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path

logger = logging.getLogger(__name__)

_MAX_OUTPUT = 10_000

# Env vars to strip in restricted/delegate mode
_STRIPPED_ENV_KEYS = {
    "AWS_ACCESS_KEY_ID", "AWS_SECRET_ACCESS_KEY", "AWS_SESSION_TOKEN",
    "GOOGLE_APPLICATION_CREDENTIALS", "AZURE_CLIENT_SECRET",
    "DATABASE_URL", "DB_PASSWORD", "OPENAI_API_KEY",
    "ANTHROPIC_API_KEY", "GITHUB_TOKEN", "NPM_TOKEN",
    "DOCKER_HOST", "KUBECONFIG",
}


@dataclass
class SandboxResult:
    ok: bool
    stdout: str = ""
    stderr: str = ""
    return_code: int = -1
    elapsed_ms: float = 0.0
    sandbox_type: str = ""
    error: str = ""

    @property
    def status(self) -> str:
        if self.error and "timeout" in self.error.lower():
            return "unknown"
        return "ok" if self.ok else "error"

    @property
    def output(self) -> str:
        return (self.stdout + self.stderr)[:_MAX_OUTPUT]


class DockerSandbox:
    """Run commands in Docker with --rm, --read-only, --network none, resource limits."""

    def __init__(self, image: str = "python:3.12-slim", workspace: str = ""):
        self._image = image
        self._workspace = workspace
        self._available: bool | None = None

    def is_available(self) -> bool:
        if self._available is not None:
            return self._available
        try:
            r = subprocess.run(["docker", "info"], capture_output=True, timeout=5)
            self._available = r.returncode == 0
        except Exception:
            self._available = False
        return self._available

    def execute(self, command: str, *, timeout: int = 60, allow_network: bool = False) -> SandboxResult:
        t0 = time.time()
        cmd = [
            "docker", "run", "--rm",
            "--memory", "512m", "--cpus", "1.0", "--pids-limit", "64",
            "--read-only", "--tmpfs", "/tmp:size=100m",
        ]
        if not allow_network:
            cmd += ["--network", "none"]
        if self._workspace and os.path.isdir(self._workspace):
            cmd += ["-v", f"{os.path.realpath(self._workspace)}:/workspace", "-w", "/workspace"]
        cmd += [self._image, "sh", "-c", command]

        try:
            result = subprocess.run(cmd, capture_output=True, timeout=timeout)
        except subprocess.TimeoutExpired:
            return SandboxResult(ok=False, elapsed_ms=(time.time() - t0) * 1000,
                                 sandbox_type="docker", error=f"Timeout ({timeout}s)")
        except Exception as e:
            return SandboxResult(ok=False, elapsed_ms=(time.time() - t0) * 1000,
                                 sandbox_type="docker", error=f"Docker error: {e}")

        stdout = _truncate(decode_subprocess_output(result.stdout))
        stderr = _truncate(decode_subprocess_output(result.stderr))
        return SandboxResult(
            ok=result.returncode == 0, stdout=stdout, stderr=stderr,
            return_code=result.returncode, elapsed_ms=(time.time() - t0) * 1000,
            sandbox_type="docker",
        )


# Patterns that indicate shell features requiring sh -c wrapping
_SHELL_FEATURES = re.compile(r"[|><;`$&]|\b&&\b|\b\|\|\b")
_WIN_CMD_BUILTINS = {
    "assoc",
    "call",
    "cd",
    "chdir",
    "cls",
    "copy",
    "del",
    "dir",
    "echo",
    "erase",
    "exit",
    "for",
    "ftype",
    "if",
    "md",
    "mkdir",
    "move",
    "popd",
    "pushd",
    "rd",
    "ren",
    "rename",
    "rmdir",
    "set",
    "start",
    "title",
    "type",
}
_WIN_BATCH_EXTENSIONS = {".bat", ".cmd"}


_GUI_LAUNCHERS = re.compile(
    r"^\s*(?:start\b|open\s+-a\b|xdg-open\b)", re.I,
)


def _is_gui_launcher(command: str) -> bool:
    """Return True if the command launches a GUI app (needs real user env)."""
    return bool(_GUI_LAUNCHERS.search(command))


def _needs_shell(command: str) -> bool:
    """Return True if the command uses shell syntax that needs shell wrapping."""
    return bool(_SHELL_FEATURES.search(command))


def _first_command_token(command: str) -> str:
    try:
        parts = shlex.split(command, posix=False)
    except ValueError:
        return ""
    if not parts:
        return ""
    return parts[0].strip().strip("\"'")


def _needs_cmd_shell(command: str) -> bool:
    """Return True if the command should run under cmd.exe on Windows."""
    if os.name != "nt":
        return False
    first = _first_command_token(command)
    if not first:
        return False
    first_path = Path(first)
    if first_path.suffix.lower() in _WIN_BATCH_EXTENSIONS:
        return True
    return first_path.name.lower() in _WIN_CMD_BUILTINS


def _check_blocked_command_patterns(command: str) -> str | None:
    """Block structurally dangerous shell patterns regardless of effect level."""
    # Block symlink/junction/hardlink creation
    if re.search(r'\bln\b\s+.*-s', command):
        return "Symlink creation is not allowed in restricted sandbox"
    if re.search(r'\bmklink\b', command, re.I):
        return "mklink is not allowed in restricted sandbox"
    if re.search(r'New-Item.*SymbolicLink', command, re.I):
        return "Symlink creation is not allowed in restricted sandbox"
    # Block relative traversal patterns
    if re.search(r'\.\.[/\\]', command):
        return "Relative path traversal (../) is not allowed in restricted sandbox"
    return None


def _scan_paths_in_command(command: str, workspace: str) -> list[dict[str, str]]:
    """Advisory path scan for logging, not as a blocking security boundary."""
    if not workspace:
        return []
    ws = Path(workspace).resolve()
    path_patterns = (
        re.compile(
            r'(?:^|\s)(/[\w./-]{3,}|[a-zA-Z]:\\[\w.\\ /-]+|\\\\[\w.$ -]+\\[\w.$\\ -]+)'
        ),
        re.compile(
            r"""['"](/[\w./ -]{3,}|[a-zA-Z]:\\[\w.\\ /-]+|\\\\[\w.$ -]+\\[\w.$\\ -]+)['"]"""
        ),
    )
    detected: list[dict[str, str]] = []
    seen: set[tuple[str, str]] = set()
    for pattern in path_patterns:
        for match in pattern.finditer(command):
            path_str = match.group(1)
            try:
                resolved = Path(path_str).resolve()
            except (OSError, ValueError):
                continue
            resolved_str = str(resolved)
            key = (path_str, resolved_str)
            if key in seen:
                continue
            seen.add(key)
            status = "inside" if resolved == ws or resolved.is_relative_to(ws) else "outside"
            detected.append({
                "path": path_str,
                "resolved": resolved_str,
                "status": status,
            })
    return detected


def _shell_argv(command: str) -> list[str]:
    if os.name == "nt":
        if shutil.which("pwsh"):
            return ["pwsh", "-NoProfile", "-NonInteractive", "-Command", command]
        logger.warning("pwsh not found; falling back to cmd.exe for shell execution")
        return ["cmd", "/d", "/s", "/c", command]
    return ["sh", "-c", command]


# Track temp directories created by make_safe_env for cleanup
_sandbox_temp_dirs: list[str] = []
_SANDBOX_TEMP_MAX = 50  # trigger cleanup when this many accumulate


def decode_subprocess_output(data: bytes | None, *, preferred_encoding: str | None = None) -> str:
    """Decode subprocess bytes without assuming Windows commands emit UTF-8."""
    if not data:
        return ""

    candidates: list[str] = []
    seen: set[str] = set()

    def _add(encoding: str | None) -> None:
        if not encoding:
            return
        normalized = encoding.strip()
        if not normalized:
            return
        key = normalized.lower()
        if key in seen:
            return
        seen.add(key)
        candidates.append(normalized)

    _add("utf-8")
    _add(preferred_encoding)
    _add(locale.getpreferredencoding(False))
    if os.name == "nt":
        _add("cp949")
        _add("mbcs")

    for encoding in candidates:
        try:
            return data.decode(encoding)
        except (LookupError, UnicodeDecodeError):
            continue

    fallback = candidates[-1] if candidates else "utf-8"
    return data.decode(fallback, errors="replace")


def make_safe_env() -> tuple[dict[str, str], str]:
    """Create a stripped env dict + temp HOME. Shared by sandbox and delegate.

    Temp directories are tracked and cleaned up periodically via cleanup_sandbox_temps().
    """
    safe_env = {}
    for k, v in os.environ.items():
        if k.upper() in _STRIPPED_ENV_KEYS:
            continue
        k_up = k.upper()
        if any(pat in k_up for pat in ("SECRET", "TOKEN", "PASSWORD", "CREDENTIAL", "PRIVATE_KEY")):
            continue
        safe_env[k] = v
    tmp_home = tempfile.mkdtemp(prefix="pascal_sandbox_")
    _sandbox_temp_dirs.append(tmp_home)
    # Proactive cleanup: remove old temp dirs when too many accumulate
    if len(_sandbox_temp_dirs) > _SANDBOX_TEMP_MAX:
        cleanup_sandbox_temps(keep_last=5)
    safe_env["HOME"] = tmp_home
    safe_env["TMPDIR"] = tmp_home
    safe_env.setdefault("PYTHONUTF8", "1")
    safe_env.setdefault("PYTHONIOENCODING", "utf-8")
    # Windows: also override user profile and temp directories
    if os.name == "nt":
        safe_env["USERPROFILE"] = tmp_home
        safe_env["TEMP"] = tmp_home
        safe_env["TMP"] = tmp_home
        safe_env["APPDATA"] = os.path.join(tmp_home, "AppData", "Roaming")
        safe_env["LOCALAPPDATA"] = os.path.join(tmp_home, "AppData", "Local")
    return safe_env, tmp_home


def cleanup_sandbox_temps(keep_last: int = 0) -> int:
    """Remove tracked sandbox temp directories. Returns count removed."""
    import shutil
    removed = 0
    to_remove = _sandbox_temp_dirs[:-keep_last] if keep_last else list(_sandbox_temp_dirs)
    for tmp_dir in to_remove:
        try:
            if os.path.isdir(tmp_dir):
                shutil.rmtree(tmp_dir, ignore_errors=True)
                removed += 1
        except Exception:
            pass
        if tmp_dir in _sandbox_temp_dirs:
            _sandbox_temp_dirs.remove(tmp_dir)
    return removed


class RestrictedSandbox:
    """Subprocess with stripped env vars, workspace boundary, temp HOME."""

    def __init__(self, workspace: str = ""):
        self._workspace = workspace

    def execute(self, command: str, *, timeout: int = 60, allow_network: bool = True) -> SandboxResult:
        t0 = time.time()
        cwd = self._workspace if self._workspace and os.path.isdir(self._workspace) else None

        blocked_err = _check_blocked_command_patterns(command)
        if blocked_err:
            return SandboxResult(ok=False, elapsed_ms=0, sandbox_type="restricted",
                                 error=blocked_err)

        # Network isolation: block outbound commands when not allowed
        if not allow_network:
            _NET_PATTERNS = ("curl ", "wget ", "Invoke-WebRequest", "Invoke-RestMethod",
                             "requests.", "httpx.", "urllib", "fetch(", "nc ", "ncat ")
            cmd_lower = command.lower()
            if any(p.lower() in cmd_lower for p in _NET_PATTERNS):
                return SandboxResult(ok=False, elapsed_ms=0, sandbox_type="restricted",
                                     error="Blocked: network access not allowed in restricted sandbox")

        detected_paths = _scan_paths_in_command(command, self._workspace)
        outside_paths = [entry for entry in detected_paths if entry["status"] == "outside"]
        if outside_paths and self._workspace:
            paths_str = ", ".join(e["path"] for e in outside_paths[:3])
            return SandboxResult(
                ok=False, elapsed_ms=0, sandbox_type="restricted",
                error=f"Blocked: command references paths outside workspace: {paths_str}",
            )

        # GUI app launchers need the real user environment (profile, LOCALAPPDATA, etc.)
        use_real_env = _is_gui_launcher(command)
        if use_real_env:
            safe_env = dict(os.environ)
            tmp_home = ""
        else:
            safe_env, tmp_home = make_safe_env()

        # shell=False by default; wrap with cmd/pwsh/sh only when needed
        if _needs_cmd_shell(command):
            cmd: list[str] | str = ["cmd", "/d", "/s", "/c", command]
        elif _needs_shell(command):
            cmd = _shell_argv(command)
        else:
            try:
                cmd = shlex.split(command)
            except ValueError:
                # Malformed command -- fall back to platform-appropriate shell
                cmd = _shell_argv(command)

        try:
            result = subprocess.run(
                cmd, shell=False, capture_output=True,
                timeout=timeout, cwd=cwd, env=safe_env,
            )
        except subprocess.TimeoutExpired:
            return SandboxResult(ok=False, elapsed_ms=(time.time() - t0) * 1000,
                                 sandbox_type="restricted", error=f"Timeout ({timeout}s)")
        except FileNotFoundError as e:
            return SandboxResult(ok=False, elapsed_ms=(time.time() - t0) * 1000,
                                 sandbox_type="restricted", error=f"Command not found: {e}")
        except Exception as e:
            return SandboxResult(ok=False, elapsed_ms=(time.time() - t0) * 1000,
                                 sandbox_type="restricted", error=f"Execution error: {e}")
        finally:
            # Clean up this invocation's temp dir immediately
            import shutil as _shutil
            try:
                if os.path.isdir(tmp_home):
                    _shutil.rmtree(tmp_home, ignore_errors=True)
                if tmp_home in _sandbox_temp_dirs:
                    _sandbox_temp_dirs.remove(tmp_home)
            except Exception:
                pass

        stdout = _truncate(decode_subprocess_output(result.stdout))
        stderr = _truncate(decode_subprocess_output(result.stderr))
        return SandboxResult(
            ok=result.returncode == 0, stdout=stdout, stderr=stderr,
            return_code=result.returncode, elapsed_ms=(time.time() - t0) * 1000,
            sandbox_type="restricted",
        )


class SandboxManager:
    """Auto-selects Docker if available, falls back to Restricted."""

    def __init__(self, workspace: str = "", prefer_docker: bool = True):
        self._docker = DockerSandbox(workspace=workspace)
        self._restricted = RestrictedSandbox(workspace=workspace)
        self._prefer_docker = prefer_docker

    def run(self, command: str, *, timeout: int = 60, allow_network: bool = False) -> SandboxResult:
        if self._prefer_docker and self._docker.is_available():
            result = self._docker.execute(command, timeout=timeout, allow_network=allow_network)
            if not result.ok and "Docker" in result.error:
                return self._restricted.execute(command, timeout=timeout, allow_network=allow_network)
            return result
        return self._restricted.execute(command, timeout=timeout, allow_network=allow_network)



def _truncate(text: str) -> str:
    if len(text) <= _MAX_OUTPUT:
        return text
    return text[:_MAX_OUTPUT] + f"\n... [truncated, {len(text)} chars total]"
