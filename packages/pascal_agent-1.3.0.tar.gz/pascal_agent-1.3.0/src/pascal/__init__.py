"""Pascal -- autonomous AI employee built on a working-document loop."""

__version__ = "1.3.0"

# Force UTF-8 stdout/stderr on Windows (cp949 cannot encode Unicode symbols)
import sys as _sys
if _sys.stdout and _sys.stdout.encoding and _sys.stdout.encoding.lower() not in ("utf-8", "utf8"):
    import io as _io
    try:
        _sys.stdout = _io.TextIOWrapper(
            _sys.stdout.buffer, encoding="utf-8", errors="replace", line_buffering=True,
        )
        _sys.stderr = _io.TextIOWrapper(
            _sys.stderr.buffer, encoding="utf-8", errors="replace", line_buffering=True,
        )
    except Exception:
        pass
