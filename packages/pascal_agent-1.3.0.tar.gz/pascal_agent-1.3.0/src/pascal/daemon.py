"""Pascal daemon -- always-on mode with Telegram + loop + scheduler."""
from __future__ import annotations

import asyncio
import logging
from pathlib import Path

from pascal.config import create_llm
from pascal.loop import run_loop
from pascal.receipts import Ledger
from pascal.state import PascalStore
from pascal import tools

logger = logging.getLogger(__name__)

_PASCAL_DIR = Path.home() / ".pascal"


def _check_stop_pause() -> str:
    """Check for STOP/PAUSE control files. Returns 'stop', 'pause', or ''."""
    if (_PASCAL_DIR / "STOP").exists():
        return "stop"
    if (_PASCAL_DIR / "PAUSE").exists():
        return "pause"
    return ""


async def _resilient(coro_fn, name: str, max_retries: int = 10):
    """Run a coroutine with automatic restart on crash."""
    for attempt in range(max_retries):
        try:
            await coro_fn()
            return  # clean exit
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("%s crashed, retry %d/%d", name, attempt + 1, max_retries)
            await asyncio.sleep(min(2 ** attempt, 60))
    logger.critical("%s exceeded max retries, giving up", name)
    raise RuntimeError(f"{name} failed after {max_retries} retries")


def _compute_interval(store: PascalStore) -> int:
    """Adaptive heartbeat: 5min if work exists, 30min if idle."""
    if store.get_active_task():
        return 300
    if store.get_pending_tasks():
        return 300
    if store.get_pending_notifications():
        return 300
    return 1800


def _resolve_max_tool_rounds(config, args) -> int:
    from pascal.config import resolve_max_tool_rounds
    return resolve_max_tool_rounds(config, args, daemon_mode=True)


async def _scheduler_loop(store: PascalStore, wake_event: asyncio.Event):
    """Periodic scheduler tick with adaptive interval. Wakes loop on events or due routines."""
    from pascal.scheduler import Scheduler
    scheduler = Scheduler(store, emit=logger.info)
    while True:
        interval = _compute_interval(store)
        await asyncio.sleep(interval)
        try:
            result = scheduler.tick()
            if (result.get("overdue") or result.get("stale")
                    or result.get("pending_notifications") or result.get("due_routines")):
                wake_event.set()
        except Exception:
            logger.exception("Scheduler tick failed")


async def run_daemon(config, args) -> None:
    """Main daemon entry point. Runs Telegram bot + Pascal loop + scheduler."""
    # Daemon always shows INFO-level logs (need to see messages/actions)
    if not logging.root.handlers:
        logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s", datefmt="%H:%M:%S")
    store = PascalStore(config.db_path)
    # Clear only expired locks from previous crash -- never evict a live lock
    store.release_lock(force=True)
    from pascal.__main__ import _try_connect_embedding
    _try_connect_embedding(store)
    wake_event = asyncio.Event()

    # LLM provider
    llm = create_llm(config)

    # Audit ledger
    ledger_path = Path(config.db_path).parent / "audit.jsonl"
    ledger = Ledger(str(ledger_path))

    # MCP (optional)
    from pascal.mcp import MCPManager
    mcp_manager = MCPManager()
    try:
        from pascal.__main__ import _load_mcp_configs
        mcp_configs = _load_mcp_configs(config)
        if mcp_configs:
            await mcp_manager.connect_all(mcp_configs)
    except Exception:
        logger.warning("MCP init failed, continuing without MCP")

    # Telegram
    from pascal.channels.telegram import load_telegram_config, create_telegram_bot
    tg_config = load_telegram_config()
    bot, start_polling, send_approval, owner_chat_id = create_telegram_bot(
        store, wake_event, tg_config,
    )
    tools.set_channel_bot(bot, owner_chat_id, store=store)
    tools.set_approval_callback(send_approval)

    # Mission
    if getattr(args, "mission", None):
        store.set_context("mission", args.mission)

    # Identity seeding moved to run_loop() --works in both daemon and one-shot mode

    # Live status broadcast → Telegram + Discord webhooks
    from pascal.loop import add_status_callback
    from pascal.scheduler import send_webhook
    import os as _os
    discord_url = _os.environ.get("PASCAL_DISCORD_WEBHOOK", "")
    slack_url = _os.environ.get("PASCAL_SLACK_WEBHOOK", "")

    def _broadcast_to_messengers(summary: str) -> None:
        """Send live action status to configured channels."""
        # Skip think actions to avoid noise
        if summary.startswith("[💭]"):
            return
        if discord_url:
            send_webhook(discord_url, summary)
        if slack_url:
            send_webhook(slack_url, summary)

    add_status_callback(_broadcast_to_messengers)

    print(f"Pascal daemon starting (model: {config.model})")
    print(f"Telegram: owner={owner_chat_id}")
    print(f"DB: {config.db_path}")
    if mcp_manager.connected_servers:
        print(f"MCP: {', '.join(mcp_manager.connected_servers)}")
    if discord_url:
        print("Discord webhook: configured")
    if slack_url:
        print("Slack webhook: configured")

    def _log_action(action: dict) -> None:
        a = action["action"]
        reason = action.get("reason", "")
        result = action.get("result", {})
        status = result.get("status", "") if isinstance(result, dict) else ""
        logger.info("  [%s] %s %s", a, reason, f"({status})" if status else "")

    base_max_tool_rounds = _resolve_max_tool_rounds(config, args)

    async def loop_task():
        """Run the Pascal loop continuously. Respects STOP/PAUSE control files."""
        while True:
            signal = _check_stop_pause()
            if signal == "stop":
                logger.info("STOP file detected --shutting down gracefully")
                return
            if signal == "pause":
                logger.info("PAUSE file detected --waiting...")
                while _check_stop_pause() == "pause":
                    await asyncio.sleep(5)
                if _check_stop_pause() == "stop":
                    return
                logger.info("PAUSE cleared --resuming")
            try:
                await run_loop(
                    store, llm,
                    verifier_llm=llm,
                    ledger=ledger,
                    mcp_manager=mcp_manager if mcp_manager.connected_servers else None,
                    max_effect=getattr(args, "max_effect", None) or config.max_effect or "unlimited",
                    max_iterations=0,
                    max_tool_rounds=base_max_tool_rounds,
                    wake_event=wake_event,
                    mode="daemon",
                    on_action=_log_action,
                )
            except Exception:
                logger.exception("Loop cycle error")
            logger.info("Loop cycle complete, restarting")
            await asyncio.sleep(1)

    try:
        await asyncio.gather(
            _resilient(start_polling, "telegram"),
            _resilient(loop_task, "loop"),
            _resilient(lambda: _scheduler_loop(store, wake_event), "scheduler"),  # adaptive interval
        )
    finally:
        await mcp_manager.disconnect_all()
        store.close()
