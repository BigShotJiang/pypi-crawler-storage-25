"""Effect Ladder -- classify and gate action side effects.

Hard-rules only:
1. Hard patterns: commands that are ALWAYS a specific level (regex-based).
2. Safe commands: explicitly classified as E0 (read-only).
3. Fallback: unrecognized commands default to E2 (conservative).
LLM self-reported effect_level is ignored.
"""

from __future__ import annotations

import os
import re
from typing import Literal

EFFECT_LEVELS = {
    "E0": "observe",
    "E1": "transform",
    "E2": "draft",
    "E3": "stage",
    "E4": "commit",
    "E5": "irreversible",
}

DEFAULT_MAX_EFFECT = "E2"

_HARD_RULES: list[tuple[str, re.Pattern]] = [
    # E5 -- irreversible
    ("E5", re.compile(r"\brm\b\s+.*-[rRf]", re.I)),
    ("E5", re.compile(r"\brm\b\s+-[rRf]", re.I)),
    ("E5", re.compile(r"\bsudo\b")),
    ("E5", re.compile(r"\bmkfs\b")),
    ("E5", re.compile(r"\bshutdown\b")),
    ("E5", re.compile(r"\breboot\b")),
    ("E5", re.compile(r"\bdd\b\s+.*of=")),
    ("E5", re.compile(r"\bdrop\s+(table|database)\b", re.I)),
    ("E5", re.compile(r"\btruncate\s+table\b", re.I)),
    ("E5", re.compile(r"\bchmod\b.*777")),
    ("E5", re.compile(r"\bkubectl\s+delete\b")),
    ("E5", re.compile(r"\bformat\s+[a-z]:", re.I)),
    # E5 -- Windows irreversible
    ("E5", re.compile(r"\brd\s+/s\s+/q\b", re.I)),
    ("E5", re.compile(r"\bdel\s+/[sfq]", re.I)),
    ("E5", re.compile(r"\bRemove-Item\b.*-Recurse", re.I)),
    # E5 -- shell wrappers hiding arbitrary commands
    ("E5", re.compile(r"\bpowershell\b.*-(?:e|EncodedCommand)\s", re.I)),
    ("E5", re.compile(r"\bcmd\s+/c\s+.*(?:del|rd|format)\b", re.I)),
    # E4 -- real external writes
    ("E4", re.compile(r"\bgit\s+push\s+.*(?:main|master)\b")),
    ("E4", re.compile(r"\bgit\s+merge\b")),
    ("E4", re.compile(r"\bgh\s+pr\s+merge\b")),
    ("E4", re.compile(r"\bgh\s+issue\s+(?:edit|close|delete)\b")),
    ("E4", re.compile(r"\bcurl\b.*-X\s*(?:POST|PUT|DELETE|PATCH)", re.I)),
    ("E4", re.compile(r"\bcurl\b.*--request\s+(?:POST|PUT|DELETE|PATCH)", re.I)),
    ("E4", re.compile(r"\bcurl\b.*(?:-d\s|--data)", re.I)),
    ("E4", re.compile(r"\bcurl\b.*(?:-F\s|--form)", re.I)),
    ("E4", re.compile(r"\bcurl\b.*(?:-T\s|--upload-file)", re.I)),
    ("E4", re.compile(r"\bnpm\s+publish\b")),
    ("E4", re.compile(r"\bkubectl\s+(?:apply|create|patch|scale)\b")),
    ("E4", re.compile(r"\bterraform\s+(?:apply|destroy)\b")),
    ("E4", re.compile(r"\bscp\b")),
    ("E4", re.compile(r"\brsync\b.*[^-](?:--delete|--remove)")),
    ("E4", re.compile(r"\bpsql\b.*-c\b")),
    ("E4", re.compile(r"\bmysql\b.*-e\b")),
    ("E4", re.compile(r"\bInvoke-WebRequest\b.*-Method\s+(?:Post|Put|Delete|Patch)", re.I)),
    # E3 -- staging / filesystem writes
    ("E3", re.compile(r"\bgit\s+push\b")),
    ("E3", re.compile(r"\bdocker\s+push\b")),
    ("E3", re.compile(r"\bchmod\b")),
    ("E3", re.compile(r"\bchown\b")),
    ("E3", re.compile(r"\brsync\b")),
    ("E3", re.compile(r"\bpip\s+install\b")),
    ("E3", re.compile(r"\bnpm\s+install\b")),
    # PowerShell: read-only cmdlets via wrapper are E0 (must be before generic E3)
    ("E0", re.compile(r"\bpowershell\b.*\b(?:Get-Content|Get-ChildItem|Get-Item|Get-Location|Get-Process|Get-Date|Select-String|Test-Path|Measure-Object|Format-Table|Sort-Object|Where-Object|Select-Object|ForEach-Object)\b", re.I)),
    ("E3", re.compile(r"\bpowershell\b", re.I)),
    ("E3", re.compile(r"\bcmd\s+/c\b", re.I)),
    # E2 -- local writes
    ("E2", re.compile(r"\bmv\b")),
    ("E2", re.compile(r"\bcp\b")),
    ("E2", re.compile(r"\btee\b")),
    ("E2", re.compile(r"\bmkdir\b")),
    ("E2", re.compile(r"\bmove\b", re.I)),  # Windows move
    ("E2", re.compile(r"\bcopy\b", re.I)),  # Windows copy
    # E0 -- read-only (explicit safe commands, Unix)
    ("E0", re.compile(r"^\s*(?:ls|cat|head|tail|wc|file|stat|echo|pwd|whoami|date|which|find|grep|rg|fd|tree|du|df)\b")),
    ("E0", re.compile(r"^\s*(?:git\s+(?:status|log|diff|show|branch|remote))\b")),
    # python/node -c can execute arbitrary code including file writes — E2, not E0
    ("E2", re.compile(r"^\s*(?:python|python3|node)\s+-c\b")),
    # curl GET: E1 not E0 — can exfiltrate local data to remote servers
    ("E1", re.compile(r"^\s*curl\b(?!.*(?:-X|-d\b|--data|--request|-F\b|--form|-T\b|--upload))", re.I)),
    # E0 -- read-only (Windows equivalents)
    ("E0", re.compile(r"^\s*(?:dir|type|where|hostname|ver|systeminfo|whoami|set)\b", re.I)),
    ("E0", re.compile(r"^\s*(?:Get-Content|Get-ChildItem|Get-Item|Get-Location|Get-Process|Get-Date)\b", re.I)),
    ("E0", re.compile(r"^\s*(?:Select-String|Test-Path|Measure-Object)\b", re.I)),
    # Network GET: E1 — can exfiltrate data
    ("E1", re.compile(r"^\s*(?:Invoke-WebRequest|wget|curl)\b(?!.*(?:-Method|-d\b|--data|-F\b|--form|--post))", re.I)),
]

# Shell meta-characters that separate independent commands
_PIPE_SPLIT = re.compile(r"\s*(?:\|(?!\|)|&&|\|\||;|\$\(|`)\s*")


def _classify_single(segment: str) -> str:
    """Classify a single command segment against hard rules.

    Unrecognized commands default to E3 (stage) — conservative for arbitrary binaries.
    """
    for level, pattern in _HARD_RULES:
        if pattern.search(segment):
            return level
    return "E3"


def classify_command(command: str, llm_assessment: str = "") -> str:
    """Classify a shell command's effect level. Hard rules only -- LLM self-report is ignored.

    Splits on pipe, &&, ||, ;, $(), and backtick boundaries to prevent
    a dangerous command from hiding behind a safe prefix like 'echo'.
    Returns the highest (most dangerous) level found across all segments.
    """
    segments = _PIPE_SPLIT.split(command)
    worst = "E0"
    for seg in segments:
        seg = seg.strip()
        if not seg:
            continue
        level = _classify_single(seg)
        if effect_to_int(level) > effect_to_int(worst):
            worst = level
    # Empty or whitespace-only command → conservative E3
    if worst == "E0" and not any(seg.strip() for seg in segments):
        return "E3"
    return worst


def effect_to_int(level: str) -> int:
    if level and len(level) == 2 and level[0] == "E" and level[1].isdigit():
        return int(level[1])
    return 0


def check_allowed(command_level: str, max_level: str) -> bool:
    if max_level == "unlimited":
        return True
    return effect_to_int(command_level) <= effect_to_int(max_level)


def get_max_effect(cli_max: str | None = None) -> str:
    if cli_max == "unlimited":
        return "unlimited"
    if cli_max and cli_max in EFFECT_LEVELS:
        return cli_max
    env = os.environ.get("PASCAL_MAX_EFFECT", "")
    if env == "unlimited":
        return "unlimited"
    if env in EFFECT_LEVELS:
        return env
    return DEFAULT_MAX_EFFECT


def escalation_message(command: str, level: str, max_level: str) -> str:
    return (
        f"Effect escalation: '{command[:80]}' is {level} ({EFFECT_LEVELS.get(level, '?')}), "
        f"but max allowed is {max_level} ({EFFECT_LEVELS.get(max_level, '?')}). "
        f"Use --max-effect {level} to allow."
    )

# ── Capability gating (merged from capability.py) ────────

Decision = Literal["go", "caution", "block"]

_HIGH_ERROR_STREAK = 3
_VERY_HIGH_ERROR_STREAK = 5


def compute_threshold(
    effect_level: str,
    *,
    recent_error_streak: int = 0,
) -> Decision:
    """Gate actions by effect level and recent failure streak."""
    level = effect_to_int(effect_level)
    if level == 0:
        return "go"
    if level >= 5:
        return "block"
    streak = max(0, int(recent_error_streak))
    if streak >= _VERY_HIGH_ERROR_STREAK:
        return "block" if level >= 3 else "caution"
    if streak >= _HIGH_ERROR_STREAK:
        return "caution"
    if level >= 4:
        return "caution"
    return "go"
