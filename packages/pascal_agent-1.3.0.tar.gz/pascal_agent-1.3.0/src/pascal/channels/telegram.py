"""Telegram channel adapter -- aiogram 3.x, DM-only, single user."""
from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


def load_telegram_config() -> dict[str, Any]:
    """Load bot_token and owner_chat_id from ~/.pascal/telegram.json."""
    config_path = Path.home() / ".pascal" / "telegram.json"
    if not config_path.exists():
        raise FileNotFoundError(
            f"Telegram config not found at {config_path}. "
            'Create it with: {"bot_token": "...", "owner_chat_id": 12345}'
        )
    return json.loads(config_path.read_text(encoding="utf-8"))


def create_telegram_bot(store, wake_event, config: dict[str, Any]):
    """Create aiogram Bot + Dispatcher. Returns (bot, start_coro, send_approval, owner_chat_id).

    start_coro is an async function that runs the long poll loop.
    send_approval is an async function for approval request buttons.
    """
    from aiogram import Bot, Dispatcher, Router, F
    from aiogram.types import (
        Message, CallbackQuery,
        InlineKeyboardMarkup, InlineKeyboardButton,
    )

    bot_token = config["bot_token"]
    owner_chat_id = int(config["owner_chat_id"])

    bot = Bot(token=bot_token)
    dp = Dispatcher()
    router = Router()
    dp.include_router(router)

    @router.message()
    async def on_message(message: Message):
        if message.chat.id != owner_chat_id:
            return
        if not message.text:
            return
        # Immediate ack -- user knows we received it
        try:
            from aiogram.types import ReactionTypeEmoji
            await message.react([ReactionTypeEmoji(emoji="👀")])
        except Exception:
            pass
        store.push_notification(
            source="telegram",
            message=message.text,
            priority="normal",
            metadata={
                "chat_id": str(message.chat.id),
                "message_id": str(message.message_id),
                "user": message.from_user.full_name if message.from_user else "unknown",
            },
        )
        wake_event.set()
        logger.info("Telegram message -> notification: %s", message.text[:80])

    @router.callback_query(F.data.startswith("approve:") | F.data.startswith("deny:"))
    async def on_approval(callback: CallbackQuery):
        if callback.message and callback.message.chat.id != owner_chat_id:
            return
        parts = (callback.data or "").split(":", 1)
        if len(parts) != 2:
            return
        action_type, task_id = parts
        approved = action_type == "approve"
        store.push_notification(
            source="approval",
            message=f"{'approved' if approved else 'denied'}: {task_id}",
            priority="urgent",
            metadata={"task_id": task_id, "approved": approved},
        )
        await callback.answer("Approved!" if approved else "Denied.")
        try:
            msg = callback.message
            if msg is not None and hasattr(msg, "edit_reply_markup"):
                await msg.edit_reply_markup(reply_markup=None)
        except Exception:
            pass
        wake_event.set()
        logger.info("Approval %s for task %s", action_type, task_id)

    async def send_approval_request(chat_id: int, task_id: str, question: str):
        keyboard = InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="Approve", callback_data=f"approve:{task_id}"),
            InlineKeyboardButton(text="Deny", callback_data=f"deny:{task_id}"),
        ]])
        await bot.send_message(chat_id, f"Approval needed:\n{question}", reply_markup=keyboard)

    async def start_polling():
        logger.info("Telegram bot starting (owner: %d)", owner_chat_id)
        try:
            await dp.start_polling(bot, handle_signals=False)
        finally:
            await bot.session.close()

    return bot, start_polling, send_approval_request, owner_chat_id
