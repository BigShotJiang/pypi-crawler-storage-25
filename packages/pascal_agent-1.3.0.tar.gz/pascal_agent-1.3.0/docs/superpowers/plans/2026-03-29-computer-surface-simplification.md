# Computer Surface Simplification Implementation Plan

> **For agentic workers:** REQUIRED: Use superpowers:subagent-driven-development (if subagents available) or superpowers:executing-plans to implement this plan. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make `computer` the only model-visible desktop interface while keeping Windows UIA code as an internal, quarantined implementation detail until a later cleanup pass.

**Architecture:** Collapse the public desktop contract onto `computer` so the prompt, tool schema, desk text, and runtime registry all tell the same story: screenshot-first, coordinate-driven interaction. Do not hard-delete `src/pascal/uia.py` in the same pass. Instead, remove `uia` from the model-facing surface and leave a narrow compatibility path that returns a redirect/error if legacy action payloads still reference it.

**Tech Stack:** Python 3.12+, pytest, pyautogui, optional pywinauto, Pascal's existing tool schema + action dispatcher architecture.

---

## Step 0

### Scope Challenge

- Existing code already solves the main interaction problem through `computer` in [prompt.py](C:\Users\laum3\Downloads\Pascal\src\pascal\prompt.py), [schemas.py](C:\Users\laum3\Downloads\Pascal\src\pascal\schemas.py), and [tools.py](C:\Users\laum3\Downloads\Pascal\src\pascal\tools.py).
- Existing code also still exposes a second desktop control language through `uia`, `ref`, and snapshot-driven control in [actions.py](C:\Users\laum3\Downloads\Pascal\src\pascal\actions.py), [tools.py](C:\Users\laum3\Downloads\Pascal\src\pascal\tools.py), and [uia.py](C:\Users\laum3\Downloads\Pascal\src\pascal\uia.py).
- This is already a coherence bug: [test_loop.py](C:\Users\laum3\Downloads\Pascal\tests\test_loop.py) expects the minimal preset to exclude `uia`, while the runtime still carries it in several public places.
- Minimum viable change is not "delete all UIA code." Minimum viable change is "remove UIA from the public contract and align every exposed layer around `computer`."
- Full deletion of `uia.py` is a second-phase cleanup, not part of this plan. Doing both in one pass mixes interface surgery with backend removal and increases rollback cost.

### What Already Exists

- `computer` already covers screenshot, click, type, hotkey, and scroll.
- The prompt already teaches the model a screenshot-first coordinate loop.
- `uia.py` is already isolated in one file plus related helpers in `tools.py`.
- The test suite already has one explicit signal that `uia` should not be in the minimal tool preset.

### Not In Scope

- Full deletion of [uia.py](C:\Users\laum3\Downloads\Pascal\src\pascal\uia.py).
- Designing a new semantic desktop abstraction on top of accessibility APIs.
- Adding browser DOM/CDP automation as a first-class backend.
- Reworking the sandbox failures currently isolated in `tests/test_sandbox_budget.py`.

## Chunk 1: Align The Public Contract

### Task 1: Remove `uia` from the model-facing prompt/schema/desk surface

**Files:**
- Modify: `C:\Users\laum3\Downloads\Pascal\src\pascal\prompt.py`
- Modify: `C:\Users\laum3\Downloads\Pascal\src\pascal\desk.py`
- Modify: `C:\Users\laum3\Downloads\Pascal\src\pascal\schemas.py`
- Test: `C:\Users\laum3\Downloads\Pascal\tests\test_loop.py`

- [ ] **Step 1: Write the failing tests that define the new public contract**

Add or update assertions in `tests/test_loop.py` so they verify:

```python
tool_names = {t["function"]["name"] for t in build_tool_schemas(preset="minimal")}
assert "uia" not in tool_names

standard_names = {t["function"]["name"] for t in build_tool_schemas(preset="standard")}
assert "uia" not in standard_names

full_names = {t["function"]["name"] for t in build_tool_schemas(preset="full")}
assert "uia" not in full_names

prompt = runner._render_system_prompt("minimal")
assert "UIA first" not in prompt
assert "screenshot fallback" not in prompt
assert "computer(action=\"click\"" in prompt
```

- [ ] **Step 2: Run the focused test and confirm it fails for the right reason**

Run:

```powershell
python -m pytest -q tests/test_loop.py::TestDeskRendering::test_minimal_prompt_keeps_desktop_and_notification_guidance
```

Expected: FAIL because some combination of schema, prompt, or desk text still exposes `uia`.

- [ ] **Step 3: Update the public contract**

Implement the smallest coherent diff:

- Remove `uia` from every preset in `schemas.py`.
- Remove `UIA first` and other UIA-first guidance from `desk.py`.
- Remove public prompt language that suggests `uia` is a model-visible action.
- Keep the screenshot-first `computer` guidance intact and explicit.

- [ ] **Step 4: Re-run the focused test and confirm it passes**

Run:

```powershell
python -m pytest -q tests/test_loop.py::TestDeskRendering::test_minimal_prompt_keeps_desktop_and_notification_guidance
```

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add tests/test_loop.py src/pascal/prompt.py src/pascal/desk.py src/pascal/schemas.py
git commit -m "refactor: remove uia from public desktop contract"
```

## Chunk 2: Remove The Public Runtime Entry Point

### Task 2: Stop treating `uia` as a first-class public action

**Files:**
- Modify: `C:\Users\laum3\Downloads\Pascal\src\pascal\actions.py`
- Modify: `C:\Users\laum3\Downloads\Pascal\src\pascal\tools.py`
- Test: `C:\Users\laum3\Downloads\Pascal\tests\test_actions.py`
- Test: `C:\Users\laum3\Downloads\Pascal\tests\test_tools.py`

- [ ] **Step 1: Write failing tests for the runtime surface**

Add tests that express the intended boundary:

```python
from pascal.tools import TOOL_REGISTRY
assert "uia" not in TOOL_REGISTRY

result = await execute_action(
    store,
    {"action": "click", "ref": "e1"},
    "uia",
    max_effect="E2",
)
assert result["status"] == "error"
assert "use computer" in result["error"].lower()
```

Also update the old registry expectation:

```python
for action in ("shell", "editor", "computer", "code", "channel_reply", "execute"):
    assert action in ACTION_HANDLERS
assert "uia" not in ACTION_HANDLERS
```

- [ ] **Step 2: Run the targeted tests to verify the old public surface still exists**

Run:

```powershell
python -m pytest -q tests/test_actions.py tests/test_tools.py
```

Expected: FAIL because `uia` is still registered and still behaves like a first-class action/tool.

- [ ] **Step 3: Apply the runtime boundary change**

Implement the public-surface removal with backwards-compatible failure semantics:

- Remove `uia` from `ACTION_HANDLERS` and `VALID_ACTIONS`.
- Remove `uia` from `TOOL_REGISTRY`, `TOOL_EFFECTS`, and `_TOOL_SUBACTION_EFFECTS`.
- Keep private UIA helper functions in `tools.py` if they are still referenced internally or likely to be reused later.
- Add a narrow legacy-compat path in `execute_action()` or a dedicated shim so if older persisted plan/action payloads call `uia`, the runtime returns a clear structured error such as:

```python
{"error": "The public 'uia' action was removed. Use computer screenshot/click/type flow instead.", "status": "error"}
```

This keeps rollback and migration safer than deleting the codepath outright.

- [ ] **Step 4: Re-run the targeted tests**

Run:

```powershell
python -m pytest -q tests/test_actions.py tests/test_tools.py
```

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add tests/test_actions.py tests/test_tools.py src/pascal/actions.py src/pascal/tools.py
git commit -m "refactor: remove public uia runtime entry points"
```

## Chunk 3: Quarantine UIA As Internal Code

### Task 3: Keep UIA code importable, but mark it internal and stop testing it as public API

**Files:**
- Modify: `C:\Users\laum3\Downloads\Pascal\src\pascal\uia.py`
- Modify: `C:\Users\laum3\Downloads\Pascal\tests\test_uia.py`

- [ ] **Step 1: Rewrite the module and test intent around internal use**

Update module docstrings and tests so they stop claiming UIA is a public tool family.

Examples:

```python
"""Internal Windows UI Automation helpers.

This module is not part of Pascal's model-visible tool surface.
It remains available for future internal desktop backends and operator-only integrations.
"""
```

And in tests:

```python
def test_uia_is_not_in_public_tool_registry():
    from pascal.tools import TOOL_REGISTRY
    assert "uia" not in TOOL_REGISTRY
```

Keep the unit tests for `UIElement`, ref assignment, stale-ref handling, and renderer helpers if the file remains in-tree. Those tests now validate a private utility module, not a public runtime surface.

- [ ] **Step 2: Run the focused UIA test module**

Run:

```powershell
python -m pytest -q tests/test_uia.py
```

Expected: PASS.

- [ ] **Step 3: Commit**

```bash
git add tests/test_uia.py src/pascal/uia.py
git commit -m "test: quarantine uia as internal helper module"
```

## Chunk 4: Document The New Boundary And Verify The Suite

### Task 4: Update docs and verify the coherent desktop story end to end

**Files:**
- Modify: `C:\Users\laum3\Downloads\Pascal\README.md`
- Modify: `C:\Users\laum3\Downloads\Pascal\ARCHITECTURE.md`

- [ ] **Step 1: Update docs to match the new contract**

Make the docs say:

- public desktop interaction is `computer`
- UIA may still exist internally for Windows-specific backend work
- model-visible desktop reasoning is screenshot-first and coordinate-driven

Do not claim `uia` is still a public tool/action.

- [ ] **Step 2: Run the focused desktop-control regression suite**

Run:

```powershell
python -m pytest -q tests/test_loop.py tests/test_actions.py tests/test_tools.py tests/test_uia.py
```

Expected: PASS.

- [ ] **Step 3: Run the full suite to compare against baseline**

Run:

```powershell
python -m pytest -q
```

Expected:

- no new failures in loop/action/tool/UIA areas
- existing baseline may still include the current sandbox failures in `tests/test_sandbox_budget.py` unless fixed separately

- [ ] **Step 4: Commit**

```bash
git add README.md ARCHITECTURE.md tests/test_loop.py tests/test_actions.py tests/test_tools.py tests/test_uia.py
git commit -m "docs: clarify computer-only desktop surface"
```

## Failure Modes To Watch

- Legacy persisted actions or plans may still contain `"uia"` and need a structured redirect instead of a crash.
- Tests may still encode contradictory assumptions, especially around public registry vs minimal schema.
- Documentation drift can reintroduce the old mixed mental model even if runtime behavior is correct.
- If coordinate-only desktop flows prove too brittle in real Windows app automation, this plan must not delete internal UIA code prematurely.

## Why This Plan Is The Recommended Shape

- It reduces public complexity without giving up the option of internal Windows-specific capability later.
- It makes the prompt, schema, registry, and tests all agree on one desktop language.
- It keeps the diff targeted: interface simplification first, backend deletion later if still warranted.
- It is reversible. If the simplification hurts real-world automation quality, reintroducing an internal backend is far cheaper than restoring a deleted subsystem from scratch.
