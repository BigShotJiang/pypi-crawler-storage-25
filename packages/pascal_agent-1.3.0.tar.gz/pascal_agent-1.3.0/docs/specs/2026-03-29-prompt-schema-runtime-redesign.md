# Pascal Agent — Prompt/Schema/Runtime Redesign Spec

**Date:** 2026-03-29
**Status:** Approved
**Authors:** GPT 5.4 Pro (architecture), Claude Opus 4.6 (refinement + implementation spec)

## Summary

Fix 7 critical bugs by enforcing a single invariant: the tool schema is the sole source of truth for what the LLM can do, and every tool result is an unambiguous success or failure.

- **Prompt** = identity and policy (who Pascal is, how to prioritize)
- **Schema** = capability (what tools exist, what params they accept)
- **Desk** = state (what's happening right now)
- **Runtime** = contracts (validation before dispatch, honest errors after)

These four layers never overlap.

## The 7 Bugs and Their Structural Fixes

| Bug | Root Cause | Fix | Layer |
|-----|-----------|-----|-------|
| #1 Tool name = action | `action` param collides with tool name | Rename to `op` + enum validation + delete silent auto-correct | Schema + Runtime |
| #2 Same URL 6x | In-memory stagnation, exact string match | DB-persisted stagnation with URL normalization | Runtime |
| #3 notif_ as task_id | No ID format validation | `pattern: "^task_"` + runtime rejection | Schema + Runtime |
| #4 Percent-encoding | Rule buried in prompt | Rule in shell tool description + runtime error on % | Schema + Runtime |
| #5 Think loops | 4-think threshold, resets on restart | 2-think threshold, DB-persisted | Runtime |
| #6 channel_reply in CLI | Tool exists but silently fails | Excluded from CLI schema + reply_sent=false is error | Schema + Runtime |
| #7 Repeat after compaction | Compaction drops failure memory | Do Not Repeat from DB + compaction includes Failed Approaches | Desk + Runtime |

## Migration Phases

### Phase 1: Stop the Bleeding
1. Delete silent auto-correction in tools.py
2. Add normalize_result() post-dispatch
3. Add task_id validation in pick_task handler

### Phase 2: Schema Overhaul
4. Rename action -> op on computer, editor, uia
5. Add uia to schema as first-class tool
6. Replace preset system with mode-based build_tool_schemas(mode, has_mcp)
7. Add additionalProperties: false to all schemas

### Phase 3: Runtime Hardening
8. Add validate_tool_call() pre-dispatch
9. Create stagnation_log DB table, replace in-memory detection
10. Lower think threshold to 2, persist in DB

### Phase 4: Desk & Prompt
11. Rewrite SYSTEM_PROMPT to ~800 tokens
12. Add Do Not Repeat section to desk render
13. Remove tool lists from desk
14. Update compaction prompt for Failed Approaches

### Phase 5: Verification
15. Replay audit.jsonl scenarios against new system
16. Add regression tests

## Key Design Decisions

1. **op rename over atomic tools**: 3-line fix vs 38-tool explosion. Same bug prevention, far less complexity.
2. **think kept with 2-consecutive limit**: Model needs reasoning ability, just not infinite loops.
3. **LLM compaction summary kept**: Adds Failed Approaches section rather than replacing with pure deterministic resume.
4. **Shell kept for URLs**: Runtime validates percent-encoding rather than creating new browser_search tool.
5. **Legacy plan steps kept**: Auto-wrapped into tree for backward compat.

## Files Changed

| File | Change |
|------|--------|
| schemas.py | Rewrite: action->op, mode-based, uia added, additionalProperties:false |
| prompt.py | Rewrite to ~800 tokens |
| desk.py | Add Do Not Repeat, remove tool lists |
| loop.py | Add validate/normalize, DB stagnation, mode presets, read op not action |
| tools.py | Delete silent auto-correct, fix channel_reply error handling |
| state.py | Add stagnation_log table |
| actions.py | Read params["op"] not params["action"] |
