# Pascal Agent — Full Prompt/Schema/Runtime Redesign

## Your Role
You are the architect for Pascal, an autonomous AI employee runtime. Your job is to redesign the **prompt system, tool schema contract, and runtime feedback loop** from scratch, using the architectural patterns from Claude Code, Codex CLI, and Anthropic CU as reference.

## Current State: Broken

Pascal is currently non-functional ("폐기물 수준"). The audit log reveals 7 critical failure modes that all stem from one root cause: **the prompt, schema, and runtime layers have no shared contract**.

### 7 Failure Modes (from audit.jsonl analysis)

1. **Tool Name = Action confusion**: LLM calls `computer(action="computer")` instead of `computer(action="screenshot")`, and `uia(action="uia")` instead of `uia(action="snapshot")`. The runtime **silently auto-corrects** this in tools.py, hiding the error from the LLM so it never learns.

2. **Same URL opened 6+ times**: YouTube search for "랄로" opened 6 times across compactions. Stagnation detection uses exact string match, so `start chrome "url"` vs `start chrome url` (with/without quotes) bypasses it. Runner restart also resets the counter.

3. **Notification ID confused with Task ID**: LLM calls `pick_task(task_id="notif_64c796401e")` — notifications and tasks look identical in the desk render.

4. **URL percent-encoding despite explicit rule**: Prompt says "use raw text, not percent-encoding" but it's buried in line 89 of 165 and LLM ignores it.

5. **Think loops**: 3-4 consecutive `think` actions before any real action. The runtime allows 4 before blocking, and the counter resets on runner restart.

6. **channel_reply in CLI mode**: Returns `reply_sent: false` but NOT as an error. Notification is marked as handled even though nothing was sent. LLM thinks it succeeded.

7. **Same actions repeated after context compaction**: Compaction summary doesn't preserve what was already tried/failed, so the LLM starts over.

## Reference Architectures Analyzed

### Codex CLI (GPT 5.4, Rust) — verified against source
- **Prompt**: Single `prompt.md` compiled via `include_str!()`. Model-specific variations via runtime template substitution. Organized: Identity → How You Work → Planning → Task Execution → Validation → Tool Guidelines.
- **Schema**: `ToolSpec` enum (6 variants: Function, ToolSearch, LocalShell, ImageGeneration, WebSearch, Freeform). Tools are JSON schemas (`ToolDefinition` → `ResponsesApiTool`) passed separately from prompt in the `Prompt` struct's `tools` field.
- **Key pattern**: Prompt provides **narrative guidance** (when to use tools), schema provides **structure** (how to call them). They don't repeat each other.
- **Anti-confusion**: Explicit warning `"NEVER try applypatch or apply-patch, only apply_patch"` (verbatim in prompt.md).
- **Loop**: `submission_loop()` → `spawn_turn()` → stream `ResponseEvent`s → tool execution → continue if `sess.has_pending_input()`.
- **Error handling**: Tool errors injected directly into conversation history as `FunctionCallOutput`. No silent corrections.
- **Stagnation**: Token budget enforces progress. Compact task runs automatically.

### Anthropic CU (Claude, Python) — verified against docs + reference impl
- **Tool**: Anthropic-defined tool type (`computer_20250124` or `computer_20251124` depending on model). Schema is built into the model and unmodifiable — you pass the tool type but NOT an input_schema. 16 actions total (screenshot, left_click, type, key, mouse_move, scroll, left_click_drag, right_click, middle_click, double_click, triple_click, left_mouse_down, left_mouse_up, hold_key, wait, zoom).
- **Anti-screenshot-loop**: Explicit prompt: "After each step, take a screenshot and carefully evaluate... Only when you confirm a step was executed correctly should you move on."
- **Loop**: Simple `while True` loop. No tool calls = done. No built-in max_iterations (documentation example shows it but reference implementation does not enforce it).
- **Error handling**: `is_error: true` flag in tool results. Clear signal. 466-499 tokens system prompt overhead.
- **Anti-stagnation**: No built-in deduplication or watchdog. The harness developer is responsible for implementing these.

### Claude Code (Claude, TypeScript)
- **Loop**: 15 lines. No tool calls = done (`stop_reason`).
- **Tools = Actions**: No meta-tool or wrapper. Each tool IS the action.
- **Termination**: `stop_reason="end_turn"` — single check.

## What I Need From You

Design a new prompt/schema/runtime contract for Pascal that makes these bugs **structurally impossible**. Not "add more instructions to the prompt" — redesign the architecture.

### Deliverables

#### 1. New Schema Architecture
- How should Pascal's tool schemas be structured?
- Should `action` field be renamed to avoid tool-name confusion? (e.g., `op`, `sub_action`)
- Should `uia` be a real schema tool or removed?
- How should tool descriptions relate to the system prompt?
- Should the prompt reference tools at all, or let schemas be self-documenting?

#### 2. New System Prompt Architecture
- What sections should exist and in what order?
- How should the prompt be modular (always-present vs. contextual)?
- What should the desk render include vs. exclude?
- How should mode awareness work (CLI vs daemon)?
- How should anti-patterns be communicated?
- Target token budget?

#### 3. New Runtime Contract
- How should tool errors be reported? (never silent)
- How should stagnation detection work across compactions?
- How should compaction preserve failure memory?
- How should channel_reply behave in CLI mode? (not in schema? hard error?)
- How should pick_task validate task IDs?
- What validation should happen before tool dispatch?

#### 4. Desk Render Redesign
- What should the desk show each iteration?
- How should it differ between full render and delta render?
- Should it include tool documentation or leave that to schemas?
- How should mode/environment be displayed?

### Constraints
- Model: GPT-5.4 via Codex Responses API (OpenAI function calling)
- Platform: Windows 11 (cmd.exe shell, NOT PowerShell/bash)
- Tools: shell, editor, computer, uia, code, channel_reply, + meta tools (plan, delegate, etc.)
- Must support both CLI (one-shot) and daemon (Telegram) modes
- Korean + English bilingual user
- Simplicity first — 3 lines over a module, no over-engineering

### Output Format
Provide:
1. **Architecture overview** — one paragraph summary of the new contract
2. **Schema definitions** — actual JSON tool schemas (or pseudocode)
3. **System prompt draft** — actual text, not description of text
4. **Desk render spec** — what sections, what order, what conditions
5. **Runtime validation rules** — what checks happen before/after tool dispatch
6. **Migration path** — what to change first, second, third

Focus on making bugs structurally impossible rather than adding more prompt instructions to prevent them.
