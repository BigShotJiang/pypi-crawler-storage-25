"""Cortex Router — routes queries to the right brain regions.

Phase 1 of sparse activation: given a query, activate only 1-3 relevant
cortices out of potentially dozens. This is the first and most critical
gate — it prevents O(n²) global search by constraining retrieval to
domain-specific subgraphs.

Routing combines:
- Semantic similarity (query embedding vs cortex centroid)
- Keyword matching (query terms vs domain keywords)
- Recency (recently active cortices get priority)
- Default fallback when no cortex matches well
"""

from __future__ import annotations

import math
import time
from dataclasses import dataclass, field
from typing import Optional

from .cortex import MemoryCortex, CortexConfig, CORTEX_HIERARCHY, HIERARCHY_WEIGHTS, HIERARCHY_DECAY_DAYS
from .config import Config
from .math_utils import cosine_sim


@dataclass
class RouteResult:
    """Result of routing a query to cortices."""
    cortex: MemoryCortex
    score: float
    reasoning: str = ""


class CortexRouter:
    """Routes queries to the most relevant cortices.

    Only 1-3 cortices are activated per query — this is the fundamental
    mechanism that keeps retrieval cost bounded regardless of total memory count.

    Usage:
        router = CortexRouter()
        router.add_cortex(dev_cortex)
        router.add_cortex(personal_cortex)

        # Route a query
        active = router.route("Redis connection pool config")
        # Returns top-2 cortices: [dev_cortex (0.82), infra_cortex (0.45)]

        # Recall from activated cortices only
        results = router.recall("Redis pool", context=ctx)
    """

    def __init__(self, config: Config | None = None,
                 brain: object | None = None):
        self.cfg = config or Config.get()
        self.cortices: list[MemoryCortex] = []
        self._default_cortex: MemoryCortex | None = None
        self._embedder = None
        self.brain = brain  # BrainSphere for O(1) hub center lookup

        # Routing stats
        self.total_routes: int = 0
        self.route_history: list[tuple[str, list[str], float]] = []  # (query, cortices, latency)

    # ── Cortex management ────────────────────────────────

    def add_cortex(self, cortex: MemoryCortex):
        """Register a new cortex."""
        if cortex.config.name in {c.config.name for c in self.cortices}:
            raise ValueError(f"Cortex '{cortex.config.name}' already exists")
        self.cortices.append(cortex)

    def remove_cortex(self, name: str):
        """Remove a cortex by name."""
        self.cortices = [c for c in self.cortices if c.config.name != name]

    def get_cortex(self, name: str) -> MemoryCortex | None:
        for c in self.cortices:
            if c.config.name == name:
                return c
        return None

    @property
    def default_cortex(self) -> MemoryCortex:
        """Lazily create a default fallback cortex."""
        if self._default_cortex is None:
            self._default_cortex = MemoryCortex(CortexConfig(
                name="general",
                description="Default fallback cortex for uncategorized memories",
                domain_keywords=[],
            ))
        return self._default_cortex

    # ── Routing ──────────────────────────────────────────

    def route(self, query: str = "",
              query_embedding: list[float] | None = None,
              max_cortices: int = 3,
              min_score: float = 0.1) -> list[RouteResult]:
        """Route a query to the most relevant cortices.

        Only 1-3 cortices are activated. If no cortex scores above min_score,
        the default cortex is used as fallback.

        Returns list of (cortex, score), sorted by score descending.
        """
        t0 = time.perf_counter()

        if not self.cortices:
            # No cortices registered — use default
            result = RouteResult(
                cortex=self.default_cortex,
                score=1.0,
                reasoning="No cortices registered, using default",
            )
            return [result]

        embedder = self._get_embedder()
        if query_embedding is None and query:
            query_embedding = embedder.encode(query)

        # O(1) pre-filter via BrainSphere hub centers (when available)
        candidate_cortices = self.cortices
        if self.brain and query_embedding:
            centers = self.brain.get_relevant_centers(
                query_embedding, top_k=max_cortices * 2, min_similarity=0.05)
            center_names = {c.cortex_name for c in centers}
            if center_names:
                # Narrow to cortices with matching hub centers
                narrowed = [c for c in self.cortices if c.config.name in center_names]
                if narrowed:
                    candidate_cortices = narrowed

        # Score candidate cortices with hierarchy weighting
        scored: list[RouteResult] = []
        for cortex in candidate_cortices:
            score = cortex.route(
                query_embedding=query_embedding,
                query_text=query,
            )
            # Apply hierarchy weight multiplier
            hierarchy_weight = HIERARCHY_WEIGHTS.get(
                cortex.config.hierarchy_level, 1.0)
            adjusted_score = score * hierarchy_weight
            if adjusted_score >= min_score:
                scored.append(RouteResult(
                    cortex=cortex,
                    score=adjusted_score,
                    reasoning=f"route={score:.3f}*hier={hierarchy_weight:.2f}={adjusted_score:.3f}",
                ))

        # Sort by hierarchy-adjusted score, higher-priority cortices win ties
        scored.sort(key=lambda r: (
            -r.score,
            r.cortex.config.hierarchy_level,
        ))
        scored = scored[:max_cortices]

        # Fallback to default cortex if nothing matched
        if not scored:
            scored = [RouteResult(
                cortex=self.default_cortex,
                score=0.5,
                reasoning="Fallback — no cortex matched query",
            )]

        latency = (time.perf_counter() - t0) * 1000
        self.total_routes += 1
        self.route_history.append((
            query[:80],
            [r.cortex.config.name for r in scored],
            latency,
        ))

        return scored

    def recall(self, query: str = "",
               context=None,
               max_items: int = 10,
               query_embedding: list[float] | None = None) -> list[tuple[MemoryCortex, 'MemoryContext']]:
        """Route and recall from activated cortices.

        Only the activated cortices participate in retrieval — everything
        else is completely dormant.

        Returns list of (cortex, MemoryContext) from each activated cortex.
        """
        from .scheduler import AgentContext
        if context is None:
            context = AgentContext(task_type="conversation")

        routes = self.route(query, query_embedding=query_embedding)

        results: list[tuple[MemoryCortex, 'MemoryContext']] = []
        for route_result in routes:
            ctx = route_result.cortex.recall(
                query=query,
                context=context,
                max_items=max_items,
            )
            results.append((route_result.cortex, ctx))

        return results

    # ── Hierarchy Operations ──────────────────────────────

    def propagate_down(self, source_cortex_name: str,
                       boost_importance: float = 0.1) -> dict:
        """Propagate importance from a higher-priority cortex down to lower ones.

        When a high-priority cortex (e.g., Reflection) forms a pattern, it should
        boost the importance of related memories in lower-priority cortices
        (e.g., Episodic). This is how strategic insights amplify tactical memories.

        Uses embedding similarity between the source cortex centroid and anchors
        in target cortices to determine what to boost.

        Returns stats dict: {cortex_name: anchors_boosted}
        """
        source = self.get_cortex(source_cortex_name)
        if not source:
            return {}
        source_level = source.config.hierarchy_level
        source_centroid = source.centroid
        if not source_centroid:
            return {}

        stats: dict[str, int] = {}
        for target in self.cortices:
            if target.config.name == source_cortex_name:
                continue
            # Only propagate DOWN (to higher level numbers = lower priority)
            if target.config.hierarchy_level <= source_level:
                continue

            boosted = 0
            for anchor in target.graph.anchors.values():
                if not anchor.embedding:
                    continue
                sim = cosine_sim(source_centroid, anchor.embedding)
                if sim > 0.6:  # relevant to the high-priority insight
                    anchor.vector.importance = min(1.0, anchor.vector.importance + boost_importance * sim)
                    boosted += 1

            if boosted:
                stats[target.config.name] = boosted

        return stats

    def get_hierarchy_summary(self) -> dict:
        """Return a summary of the cortex hierarchy."""
        by_level: dict[int, list[str]] = {}
        for c in self.cortices:
            level = c.config.hierarchy_level
            by_level.setdefault(level, []).append(c.config.name)

        return {
            "total_cortices": len(self.cortices),
            "by_level": {f"L{lv}({list(CORTEX_HIERARCHY.keys())[lv] if lv < len(CORTEX_HIERARCHY) else 'unknown'})": names
                        for lv, names in sorted(by_level.items())},
            "hierarchy_weights": {str(k): v for k, v in HIERARCHY_WEIGHTS.items()},
        }

    # ── Cortex creation ──────────────────────────────────

    def find_or_create_cortex(self, name: str,
                              domain_keywords: list[str] | None = None,
                              **kwargs) -> MemoryCortex:
        """Find an existing cortex or create a new one.

        If the cortex already exists, returns it. Otherwise creates a new
        cortex with the given domain keywords and config overrides.
        """
        existing = self.get_cortex(name)
        if existing:
            return existing

        cortex_config = CortexConfig(
            name=name,
            domain_keywords=domain_keywords or [],
            **kwargs,
        )
        cortex = MemoryCortex(cortex_config, self.cfg)
        self.add_cortex(cortex)
        return cortex

    # ── Health ───────────────────────────────────────────

    @property
    def stats(self) -> dict:
        total_anchors = sum(len(c.graph.anchors) for c in self.cortices)
        return {
            "cortices": len(self.cortices),
            "total_anchors": total_anchors,
            "total_routes": self.total_routes,
            "recent_routes": self.route_history[-5:] if self.route_history else [],
        }

    def _get_embedder(self):
        if self._embedder is None:
            from .embedding import get_embedder
            self._embedder = get_embedder()
        return self._embedder
