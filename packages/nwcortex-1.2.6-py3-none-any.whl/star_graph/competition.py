from .consolidation.competition import *
