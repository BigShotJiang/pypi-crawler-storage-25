"""F1-F5 Falsifiability Criteria auto-checker for yuragi.

See ``docs/theory.md`` Section 6 for the criteria definitions. This script
implements the Proposed Evaluation Protocol so that researchers can
reproduce and challenge yuragi's core claims with a single command.

Criteria
--------
- **F1** — Dissociation rate ⊥ ECE (Pearson |r| < 0.7)
- **F2** — Semantic uncertainty proxy ⊥ yuragi dissociation
           (Pearson |r| < 0.7; uses :func:`yuragi.metrics.semantic_entropy`
           as a stand-in for SPUQ, which is not on PyPI)
- **F3** — Factual questions produce higher dissociation than opinion
           questions (mean diff > 0.1)
- **F4** — Recovery decay rate λ_recovery < λ_decay (ratio < 0.8)
- **F5** — Trilayer measurements disagree by more than 0.05 on >50%
           of prompts (implies a non-trivial trilayer decomposition)

Modes
-----
- **dry_run** (default): synthetic deterministic data generated via a
  seeded ``numpy.random.Generator``. All criteria pass by construction so
  the protocol itself — CLI, JSON schema, tests — can be exercised in CI
  without any LLM access.
- **real** (``--real``): runs the yuragi scanner / decay experiment /
  trilayer pipeline against real ollama models. Requires ``--seed``.

Usage
-----
.. code-block:: bash

    python benchmarks/falsifiability_check.py                    # dry_run
    python benchmarks/falsifiability_check.py --output fc.json
    python benchmarks/falsifiability_check.py --real --seed 42 \\
        --models ollama/llama3.2 --n-prompts 5

JSON schema v1::

    {
      "$schema": "yuragi/falsifiability/v1",
      "version": "0.2.0",
      "generated_at": "2026-04-11T12:00:00+00:00",
      "mode": "dry_run" | "real",
      "seed": 42,
      "models": ["ollama/llama3.2"],
      "n_prompts_per_category": 10,
      "duration_seconds": 12.3,
      "total_api_calls": 0,
      "thresholds": {"F1": 0.7, "F2": 0.7, "F3": 0.1, "F4": 0.8, "F5": 0.5},
      "criteria": {
        "F1": {"pass": true, "value": 0.12, "ci": [-0.18, 0.41], "n": 60,
               "threshold": 0.7, "unit": "pearson_r", "notes": "...",
               "provenance": {"source": "dry_run_synthetic"}},
        ...
      },
      "overall_verdict": {"all_pass": true, "unable": []}
    }
"""

from __future__ import annotations

import argparse
import json
import math
import statistics
import sys
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from yuragi import __version__ as _yuragi_version

# Defaults -----------------------------------------------------------------

DEFAULT_MODELS: list[str] = ["ollama/llama3.2"]
DEFAULT_OUTPUT: Path = Path("docs/bench/falsifiability.json")
DEFAULT_THRESHOLDS: dict[str, float] = {
    "F1": 0.7,   # |r(dissociation, ece)| must stay below this
    "F2": 0.7,   # |r(semantic_entropy, dissociation)| must stay below this
    "F3": 0.1,   # mean(factual) - mean(opinion) must exceed this
    "F4": 0.8,   # lambda_recovery / lambda_decay must stay below this
    "F5": 0.5,   # fraction of prompts with trilayer disagreement > 0.05
}

# Data structures ----------------------------------------------------------


@dataclass
class CriterionOutcome:
    """Result of running a single falsifiability criterion."""

    pass_: bool | None                 # None == unable_to_determine
    value: float | None
    ci: tuple[float, float] | None
    n: int
    threshold: float
    unit: str
    notes: str
    provenance: dict[str, Any] = field(default_factory=dict)

    def to_json(self) -> dict[str, Any]:
        return {
            "pass": self.pass_,
            "value": self.value,
            "ci": list(self.ci) if self.ci is not None else None,
            "n": self.n,
            "threshold": self.threshold,
            "unit": self.unit,
            "notes": self.notes,
            "provenance": dict(self.provenance),
        }


@dataclass
class FalsifiabilityResult:
    """Top-level result object serialised to JSON."""

    version: str
    seed: int | None
    mode: str                           # "dry_run" | "real"
    models: list[str]
    n_prompts_per_category: int
    duration_seconds: float
    total_api_calls: int
    thresholds: dict[str, float]
    criteria: dict[str, CriterionOutcome]
    generated_at: str

    def to_json(self) -> dict[str, Any]:
        return {
            "$schema": "yuragi/falsifiability/v1",
            "version": self.version,
            "generated_at": self.generated_at,
            "mode": self.mode,
            "seed": self.seed,
            "models": list(self.models),
            "n_prompts_per_category": self.n_prompts_per_category,
            "duration_seconds": round(self.duration_seconds, 3),
            "total_api_calls": self.total_api_calls,
            "thresholds": dict(self.thresholds),
            "criteria": {k: v.to_json() for k, v in self.criteria.items()},
            "overall_verdict": {
                "all_pass": all(
                    c.pass_ is True for c in self.criteria.values()
                ),
                "unable": [k for k, v in self.criteria.items() if v.pass_ is None],
            },
        }


@dataclass
class RealContext:
    """Context for real-mode execution."""

    models: list[str]
    n_prompts: int
    seed: int
    factual_prompts: list[str]
    opinion_prompts: list[str]
    num_samples: int = 5
    num_variants: int = 3
    verbose: bool = False
    api_calls: int = 0


# Stats helpers ------------------------------------------------------------


def _pearson_r(xs: list[float], ys: list[float]) -> float | None:
    """Pure-Python Pearson r, returns ``None`` if undefined."""
    if len(xs) != len(ys) or len(xs) < 2:
        return None
    n = len(xs)
    mean_x = sum(xs) / n
    mean_y = sum(ys) / n
    num = sum((a - mean_x) * (b - mean_y) for a, b in zip(xs, ys))
    var_x = sum((a - mean_x) ** 2 for a in xs)
    var_y = sum((b - mean_y) ** 2 for b in ys)
    denom = math.sqrt(var_x * var_y)
    if denom == 0:
        return None
    return num / denom


def _bootstrap_pearson_ci(
    xs: list[float],
    ys: list[float],
    *,
    n_iterations: int = 1000,
    seed: int = 0,
    ci_level: float = 0.95,
) -> tuple[float, float] | None:
    """Stdlib-only percentile bootstrap CI for Pearson r."""
    import random

    n = len(xs)
    if n != len(ys) or n < 2:
        return None
    rng = random.Random(seed)
    samples: list[float] = []
    for _ in range(n_iterations):
        idx = [rng.randint(0, n - 1) for _ in range(n)]
        rb = _pearson_r([xs[i] for i in idx], [ys[i] for i in idx])
        if rb is not None:
            samples.append(rb)
    if not samples:
        return None
    samples.sort()
    alpha = (1.0 - ci_level) / 2.0
    lo = samples[max(0, int(alpha * len(samples)))]
    hi = samples[min(len(samples) - 1, int((1 - alpha) * len(samples)))]
    return (lo, hi)


# Dry-run synthetic data generator -----------------------------------------


def _synthetic_series(
    seed: int,
    n: int,
    correlation: float = 0.1,
    noise: float = 0.2,
) -> tuple[list[float], list[float]]:
    """Deterministic synthetic (x, y) series with tunable correlation.

    Used by dry_run mode so F1 / F2 return a low-correlation pair and the
    protocol validates without any LLM access.
    """
    import random

    rng = random.Random(seed)
    xs = [rng.random() for _ in range(n)]
    ys = [
        max(0.0, min(1.0, correlation * x + noise * rng.random()))
        for x in xs
    ]
    return xs, ys


# Criterion implementations ------------------------------------------------


class F1OrthogonalityECE:
    """F1 — Dissociation ⊥ ECE."""

    id = "F1"
    description = "|r(dissociation_rate, ECE)| < 0.7"

    def run_dry(self, seed: int, n: int) -> CriterionOutcome:
        xs, ys = _synthetic_series(seed=seed, n=n * 3, correlation=0.05)
        r_val = _pearson_r(xs, ys) or 0.0
        ci = _bootstrap_pearson_ci(xs, ys, n_iterations=500, seed=seed + 1) or (0.0, 0.0)
        return CriterionOutcome(
            pass_=abs(r_val) < DEFAULT_THRESHOLDS["F1"],
            value=r_val,
            ci=ci,
            n=len(xs),
            threshold=DEFAULT_THRESHOLDS["F1"],
            unit="pearson_r",
            notes="dry_run synthetic series; low-correlation by construction",
            provenance={"source": "dry_run_synthetic"},
        )

    def run_real(self, ctx: RealContext) -> CriterionOutcome:
        try:
            from yuragi.config import YuragiConfig
            from yuragi.core import Scanner
            from yuragi.metrics.calibration import expected_calibration_error
        except ImportError as err:
            return _unable(self, reason=f"import failed: {err}")

        xs: list[float] = []
        ys: list[float] = []
        prompts = ctx.factual_prompts + ctx.opinion_prompts
        for model in ctx.models:
            scanner = Scanner(
                model=model,
                num_samples=ctx.num_samples,
                num_variants=ctx.num_variants,
                config=YuragiConfig(seed=ctx.seed),
            )
            for p in prompts:
                try:
                    r = scanner.scan(p)
                    ctx.api_calls += r.total_api_calls
                    xs.append(r.dissociation_rate)
                    ys.append(expected_calibration_error(r.perturbation_results))
                except Exception as err:
                    if ctx.verbose:
                        print(f"  F1 scan failed on {model} / {p[:30]!r}: {err}")
        if len(xs) < 2:
            return _unable(self, reason=f"insufficient data (n={len(xs)})")
        r_val = _pearson_r(xs, ys)
        ci = _bootstrap_pearson_ci(xs, ys, n_iterations=2000, seed=ctx.seed)
        if r_val is None:
            return _unable(self, reason="pearson_r undefined (zero variance?)")
        return CriterionOutcome(
            pass_=abs(r_val) < DEFAULT_THRESHOLDS["F1"],
            value=r_val,
            ci=ci,
            n=len(xs),
            threshold=DEFAULT_THRESHOLDS["F1"],
            unit="pearson_r",
            notes="real ollama trace; dissociation vs ECE per (model, prompt) pair",
            provenance={
                "source": "real",
                "models": list(ctx.models),
                "n_pairs": len(xs),
            },
        )


class F2OrthogonalitySemanticEntropy:
    """F2 — Semantic uncertainty ⊥ dissociation.

    SPUQ is not available on PyPI, so yuragi's own ``semantic_entropy``
    implementation (Farquhar et al., Nature 2024) is used as a proxy for
    "model-reported semantic uncertainty". The ``provenance`` field makes
    this substitution explicit so reviewers can judge the claim.
    """

    id = "F2"
    description = "|r(semantic_entropy, dissociation_rate)| < 0.7 [SPUQ proxy]"

    def run_dry(self, seed: int, n: int) -> CriterionOutcome:
        xs, ys = _synthetic_series(seed=seed + 10, n=n * 3, correlation=0.08)
        r_val = _pearson_r(xs, ys) or 0.0
        ci = _bootstrap_pearson_ci(xs, ys, n_iterations=500, seed=seed + 11) or (0.0, 0.0)
        return CriterionOutcome(
            pass_=abs(r_val) < DEFAULT_THRESHOLDS["F2"],
            value=r_val,
            ci=ci,
            n=len(xs),
            threshold=DEFAULT_THRESHOLDS["F2"],
            unit="pearson_r",
            notes="dry_run synthetic; SPUQ proxy via semantic_entropy",
            provenance={
                "source": "dry_run_synthetic",
                "spuq_available": False,
                "proxy": "yuragi.metrics.semantic_entropy",
            },
        )

    def run_real(self, ctx: RealContext) -> CriterionOutcome:
        try:
            from yuragi.config import YuragiConfig
            from yuragi.core import Scanner
            from yuragi.metrics.semantic_entropy import semantic_entropy
        except ImportError as err:
            return _unable(self, reason=f"import failed: {err}")

        xs: list[float] = []
        ys: list[float] = []
        prompts = ctx.factual_prompts + ctx.opinion_prompts
        for model in ctx.models:
            scanner = Scanner(
                model=model,
                num_samples=ctx.num_samples,
                num_variants=ctx.num_variants,
                config=YuragiConfig(seed=ctx.seed),
            )
            for p in prompts:
                try:
                    r = scanner.scan(p)
                    ctx.api_calls += r.total_api_calls
                    samples_text = [pr.perturbed_response.text for pr in r.perturbation_results]
                    xs.append(semantic_entropy(samples_text))
                    ys.append(r.dissociation_rate)
                except Exception as err:
                    if ctx.verbose:
                        print(f"  F2 scan failed on {model} / {p[:30]!r}: {err}")
        if len(xs) < 2:
            return _unable(self, reason=f"insufficient data (n={len(xs)})")
        r_val = _pearson_r(xs, ys)
        ci = _bootstrap_pearson_ci(xs, ys, n_iterations=2000, seed=ctx.seed + 12)
        if r_val is None:
            return _unable(self, reason="pearson_r undefined")
        return CriterionOutcome(
            pass_=abs(r_val) < DEFAULT_THRESHOLDS["F2"],
            value=r_val,
            ci=ci,
            n=len(xs),
            threshold=DEFAULT_THRESHOLDS["F2"],
            unit="pearson_r",
            notes="real ollama trace; SPUQ proxy via semantic_entropy",
            provenance={
                "source": "real",
                "spuq_available": False,
                "proxy": "yuragi.metrics.semantic_entropy",
                "models": list(ctx.models),
                "n_pairs": len(xs),
            },
        )


class F3FactualVsOpinion:
    """F3 — mean(factual dissociation) > mean(opinion dissociation) + 0.1."""

    id = "F3"
    description = "mean(factual dissociation) - mean(opinion dissociation) > 0.1"

    def run_dry(self, seed: int, n: int) -> CriterionOutcome:
        import random

        rng = random.Random(seed + 20)
        f_rates = [max(0.0, min(1.0, rng.gauss(0.45, 0.05))) for _ in range(n)]
        o_rates = [max(0.0, min(1.0, rng.gauss(0.20, 0.05))) for _ in range(n)]
        diff = statistics.fmean(f_rates) - statistics.fmean(o_rates)
        return CriterionOutcome(
            pass_=diff > DEFAULT_THRESHOLDS["F3"],
            value=diff,
            ci=None,
            n=len(f_rates) + len(o_rates),
            threshold=DEFAULT_THRESHOLDS["F3"],
            unit="mean_diff",
            notes="dry_run synthetic gaussians",
            provenance={"source": "dry_run_synthetic"},
        )

    def run_real(self, ctx: RealContext) -> CriterionOutcome:
        try:
            from yuragi.config import YuragiConfig
            from yuragi.core import Scanner
        except ImportError as err:
            return _unable(self, reason=f"import failed: {err}")

        f_rates: list[float] = []
        o_rates: list[float] = []
        for model in ctx.models:
            scanner = Scanner(
                model=model,
                num_samples=ctx.num_samples,
                num_variants=ctx.num_variants,
                config=YuragiConfig(seed=ctx.seed),
            )
            for p in ctx.factual_prompts:
                try:
                    r = scanner.scan(p)
                    ctx.api_calls += r.total_api_calls
                    f_rates.append(r.dissociation_rate)
                except Exception as err:
                    if ctx.verbose:
                        print(f"  F3 factual fail: {err}")
            for p in ctx.opinion_prompts:
                try:
                    r = scanner.scan(p)
                    ctx.api_calls += r.total_api_calls
                    o_rates.append(r.dissociation_rate)
                except Exception as err:
                    if ctx.verbose:
                        print(f"  F3 opinion fail: {err}")
        if not f_rates or not o_rates:
            return _unable(self, reason=f"insufficient data (f={len(f_rates)}, o={len(o_rates)})")
        diff = statistics.fmean(f_rates) - statistics.fmean(o_rates)
        return CriterionOutcome(
            pass_=diff > DEFAULT_THRESHOLDS["F3"],
            value=diff,
            ci=None,
            n=len(f_rates) + len(o_rates),
            threshold=DEFAULT_THRESHOLDS["F3"],
            unit="mean_diff",
            notes=f"real; n_factual={len(f_rates)}, n_opinion={len(o_rates)}",
            provenance={
                "source": "real",
                "models": list(ctx.models),
                "factual_mean": statistics.fmean(f_rates),
                "opinion_mean": statistics.fmean(o_rates),
            },
        )


class F4RecoveryAsymmetry:
    """F4 — λ_recovery / λ_decay < 0.8 (recovery is slower than decay)."""

    id = "F4"
    description = "lambda_recovery / lambda_decay < 0.8"

    def run_dry(self, seed: int, n: int) -> CriterionOutcome:
        import random

        rng = random.Random(seed + 30)
        ratios = [max(0.0, rng.gauss(0.35, 0.1)) for _ in range(n)]
        mean_ratio = statistics.fmean(ratios)
        return CriterionOutcome(
            pass_=mean_ratio < DEFAULT_THRESHOLDS["F4"],
            value=mean_ratio,
            ci=None,
            n=len(ratios),
            threshold=DEFAULT_THRESHOLDS["F4"],
            unit="lambda_ratio",
            notes="dry_run synthetic: asymmetric recovery by construction",
            provenance={"source": "dry_run_synthetic"},
        )

    def run_real(self, ctx: RealContext) -> CriterionOutcome:
        try:
            from yuragi.analysis.decay import DecayExperiment
        except ImportError as err:
            return _unable(self, reason=f"import failed: {err}")

        ratios: list[float] = []
        for model in ctx.models:
            exp = DecayExperiment(model=model, num_samples=min(3, ctx.num_samples))
            for p in ctx.factual_prompts[: min(ctx.n_prompts, 5)]:
                try:
                    r = exp.run(p)
                    # lambda_recovery proxy: inverse of recovery_after_praise
                    # (faster recovery → larger value → smaller lambda_ratio).
                    # Fall back to 0.35 if shape is degenerate.
                    decay_rate = max(getattr(r, "decay_rate", 0.1), 1e-6)
                    rec = max(0.0, getattr(r, "recovery_after_praise", 0.0))
                    lam_rec = 1.0 - min(0.99, rec)
                    ratios.append(lam_rec / decay_rate)
                except Exception as err:
                    if ctx.verbose:
                        print(f"  F4 decay fail: {err}")
        if not ratios:
            return _unable(self, reason="no DecayExperiment runs produced ratios")
        mean_ratio = statistics.fmean(ratios)
        return CriterionOutcome(
            pass_=mean_ratio < DEFAULT_THRESHOLDS["F4"],
            value=mean_ratio,
            ci=None,
            n=len(ratios),
            threshold=DEFAULT_THRESHOLDS["F4"],
            unit="lambda_ratio",
            notes=f"lambda_recovery proxy = 1 - recovery_after_praise; n={len(ratios)}",
            provenance={
                "source": "real",
                "approximation": "recovery_after_praise proxy",
                "models": list(ctx.models),
            },
        )


class F5TrilayerDiversity:
    """F5 — trilayer disagreement > 0.05 on more than 50% of prompts."""

    id = "F5"
    description = "trilayer max_discrepancy > 0.05 on > 50% of prompts"

    def run_dry(self, seed: int, n: int) -> CriterionOutcome:
        import random

        rng = random.Random(seed + 40)
        diffs = [abs(rng.gauss(0.15, 0.05)) for _ in range(n * 3)]
        hits = sum(1 for d in diffs if d > 0.05)
        rate = hits / len(diffs)
        return CriterionOutcome(
            pass_=rate > DEFAULT_THRESHOLDS["F5"],
            value=rate,
            ci=None,
            n=len(diffs),
            threshold=DEFAULT_THRESHOLDS["F5"],
            unit="diversity_rate",
            notes="dry_run synthetic; most diffs exceed 0.05 by construction",
            provenance={"source": "dry_run_synthetic"},
        )

    def run_real(self, ctx: RealContext) -> CriterionOutcome:
        try:
            from yuragi.analysis.trilayer import measure_trilayer
        except ImportError as err:
            return _unable(self, reason=f"import failed: {err}")

        diffs: list[float] = []
        for model in ctx.models:
            for p in (ctx.factual_prompts + ctx.opinion_prompts)[: ctx.n_prompts]:
                try:
                    tr = measure_trilayer(p, model=model, num_samples=ctx.num_samples)
                    diffs.append(tr.max_discrepancy)
                    ctx.api_calls += 2 + ctx.num_samples  # logprob + sampling + verbalized
                except Exception as err:
                    if ctx.verbose:
                        print(f"  F5 trilayer fail: {err}")
        if not diffs:
            return _unable(self, reason="no trilayer measurements")
        hits = sum(1 for d in diffs if d > 0.05)
        rate = hits / len(diffs)
        return CriterionOutcome(
            pass_=rate > DEFAULT_THRESHOLDS["F5"],
            value=rate,
            ci=None,
            n=len(diffs),
            threshold=DEFAULT_THRESHOLDS["F5"],
            unit="diversity_rate",
            notes=f"real trilayer; hits={hits}/{len(diffs)}",
            provenance={"source": "real", "models": list(ctx.models)},
        )


# Runner -------------------------------------------------------------------


_ALL_CRITERIA = {
    "F1": F1OrthogonalityECE(),
    "F2": F2OrthogonalitySemanticEntropy(),
    "F3": F3FactualVsOpinion(),
    "F4": F4RecoveryAsymmetry(),
    "F5": F5TrilayerDiversity(),
}


def _unable(criterion, reason: str) -> CriterionOutcome:
    """Build an ``unable_to_determine`` outcome for a criterion."""
    return CriterionOutcome(
        pass_=None,
        value=None,
        ci=None,
        n=0,
        threshold=DEFAULT_THRESHOLDS[criterion.id],
        unit="",
        notes=f"unable_to_determine: {reason}",
        provenance={"source": "error"},
    )


def run_falsifiability(
    *,
    mode: str = "dry_run",
    models: list[str] | None = None,
    n_prompts: int = 10,
    seed: int | None = None,
    criteria: list[str] | None = None,
    verbose: bool = False,
) -> FalsifiabilityResult:
    """Run all selected F1-F5 criteria and return a ``FalsifiabilityResult``."""
    if mode not in ("dry_run", "real"):
        raise ValueError(f"mode must be 'dry_run' or 'real', got {mode!r}")
    if mode == "real" and seed is None:
        raise ValueError("--seed is required when --real is set")
    if seed is None:
        seed = 0

    selected_ids = criteria or list(_ALL_CRITERIA.keys())
    selected = {k: _ALL_CRITERIA[k] for k in selected_ids if k in _ALL_CRITERIA}
    if not selected:
        raise ValueError(f"no valid criteria selected: {criteria!r}")

    # Load question banks lazily (data package is small but still)
    from yuragi.data.standard_questions import FACTUAL, OPINION

    factual_prompts = list(FACTUAL)[:n_prompts]
    opinion_prompts = list(OPINION)[:n_prompts]

    start = time.perf_counter()
    outcomes: dict[str, CriterionOutcome] = {}

    if mode == "dry_run":
        for cid, crit in selected.items():
            outcomes[cid] = crit.run_dry(seed=seed, n=n_prompts)
        api_calls = 0
    else:
        ctx = RealContext(
            models=models or DEFAULT_MODELS,
            n_prompts=n_prompts,
            seed=seed,
            factual_prompts=factual_prompts,
            opinion_prompts=opinion_prompts,
            verbose=verbose,
        )
        for cid, crit in selected.items():
            try:
                outcomes[cid] = crit.run_real(ctx)
            except Exception as err:
                outcomes[cid] = _unable(crit, reason=f"run_real raised: {err}")
        api_calls = ctx.api_calls

    duration = time.perf_counter() - start

    return FalsifiabilityResult(
        version=_yuragi_version,
        seed=seed,
        mode=mode,
        models=list(models or DEFAULT_MODELS) if mode == "real" else [],
        n_prompts_per_category=n_prompts,
        duration_seconds=duration,
        total_api_calls=api_calls,
        thresholds=dict(DEFAULT_THRESHOLDS),
        criteria=outcomes,
        generated_at=datetime.now(tz=timezone.utc).isoformat(),
    )


# Rendering ----------------------------------------------------------------


def _render_markdown_table(result: FalsifiabilityResult) -> str:
    """Render a compact Markdown summary to stdout."""
    lines = [
        f"# Falsifiability check — yuragi {result.version}",
        "",
        f"- mode: `{result.mode}` / seed: `{result.seed}` / duration: {result.duration_seconds:.2f}s",
        f"- models: {', '.join(result.models) if result.models else '(none — dry_run)'}",
        f"- api_calls: {result.total_api_calls}",
        "",
        "| ID | Description | Value | Threshold | Pass? | Notes |",
        "|----|-------------|------:|----------:|:-----:|-------|",
    ]
    for cid, out in result.criteria.items():
        crit = _ALL_CRITERIA.get(cid)
        desc = crit.description if crit else ""
        val = "n/a" if out.value is None else f"{out.value:+.3f}"
        threshold = f"{out.threshold:.2f}"
        pass_str = "?" if out.pass_ is None else ("Y" if out.pass_ else "N")
        lines.append(
            f"| {cid} | {desc} | {val} | {threshold} | {pass_str} | {out.notes[:60]} |"
        )
    lines.append("")
    verdict = result.to_json()["overall_verdict"]
    if verdict["all_pass"]:
        lines.append("**Overall**: all criteria pass within thresholds.")
    else:
        failed = [
            cid
            for cid, out in result.criteria.items()
            if out.pass_ is False
        ]
        unable = verdict["unable"]
        lines.append(
            f"**Overall**: failed={failed}, unable_to_determine={unable}."
        )
    return "\n".join(lines)


# CLI ----------------------------------------------------------------------


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="F1-F5 Falsifiability Criteria auto-checker for yuragi",
    )
    parser.add_argument(
        "--real",
        action="store_true",
        help="Run against real LLMs via ollama (requires --seed)",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=None,
        help="Seed for determinism. Required with --real.",
    )
    parser.add_argument(
        "--models",
        type=str,
        default=",".join(DEFAULT_MODELS),
        help="Comma-separated model names (default: ollama/llama3.2)",
    )
    parser.add_argument(
        "--n-prompts",
        type=int,
        default=10,
        help="Prompts per category (factual/opinion) — default 10",
    )
    parser.add_argument(
        "--criteria",
        type=str,
        default="F1,F2,F3,F4,F5",
        help="Comma-separated subset of criteria to run",
    )
    parser.add_argument(
        "--output",
        "-o",
        type=Path,
        default=None,
        help="JSON output path (default: print to stdout only)",
    )
    parser.add_argument(
        "--no-table",
        action="store_true",
        help="Suppress the Markdown table on stdout",
    )
    parser.add_argument(
        "--allow-hosted",
        action="store_true",
        help="Allow non-ollama models (default: ollama/* only)",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Print per-call debug messages (real mode only)",
    )
    args = parser.parse_args(argv)

    models = [m.strip() for m in args.models.split(",") if m.strip()]
    if args.real and not args.allow_hosted:
        blocked = [m for m in models if not m.startswith("ollama/")]
        if blocked:
            print(
                f"Refusing to use non-ollama models without --allow-hosted: {blocked}",
                file=sys.stderr,
            )
            return 2

    selected = [c.strip() for c in args.criteria.split(",") if c.strip()]

    try:
        result = run_falsifiability(
            mode="real" if args.real else "dry_run",
            models=models,
            n_prompts=args.n_prompts,
            seed=args.seed,
            criteria=selected,
            verbose=args.verbose,
        )
    except ValueError as err:
        print(f"error: {err}", file=sys.stderr)
        return 2

    payload = result.to_json()
    if args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(payload, indent=2) + "\n")

    if not args.no_table:
        print(_render_markdown_table(result))
        print()
        if args.output is None:
            print(json.dumps(payload, indent=2))

    all_pass = payload["overall_verdict"]["all_pass"]
    return 0 if all_pass else 1


if __name__ == "__main__":
    raise SystemExit(main())
