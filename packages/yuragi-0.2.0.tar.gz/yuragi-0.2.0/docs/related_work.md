# Related Work

This document situates yuragi within the landscape of LLM uncertainty quantification and evaluation research.

---

## Feature Comparison Matrix

| Feature | yuragi | SPUQ | lm-polygraph | Semantic Entropy | Calibration-Tuning | Kadavath et al. |
|---------|:------:|:----:|:------------:|:----------------:|:-----------------:|:---------------:|
| Confidence Dissociation detection | **Yes** | No | No | No | No | No |
| Fragility profile (CCI/RE/NLS) | **Yes** | No | No | No | No | No |
| Psychology experiment protocols | **Yes** (9) | No | No | No | No | No |
| CLI / pip-installable | **Yes** | No | Partial | No | No | No |
| Real-time visualization | **Yes** | No | No | No | No | No |
| Multi-language support | **Yes** (EN/JA) | No | No | No | No | No |
| Plugin extensible perturbations | **Yes** | No | No | No | No | No |
| Trilayer confidence decomposition | **Yes** | No | Partial | No | No | No |
| Logprob + verbalized + sampling | **Yes** | Sampling | Logprob | Sampling | Verbalized | Verbalized |
| Local model support (Ollama) | **Yes** | No | No | No | No | No |
| 40+ UQ methods | No | No | **Yes** | No | No | No |
| Semantic clustering | No | No | No | **Yes** | No | No |
| Training-time intervention | No | No | No | No | **Yes** | No |

---

## Direct Competitors

### SPUQ (Gao et al., EACL 2024)

**Citation**: Gao, T., Stern, D., Bisk, Y., & Roth, D. (2024). SPUQ: Perturbation-based uncertainty quantification for large language models. *Proceedings of the 18th Conference of the European Chapter of the Association for Computational Linguistics (EACL 2024)*.

**Method**: SPUQ quantifies LLM uncertainty by applying random perturbations to input prompts — including dummy token insertion, paraphrase generation, system message changes, and temperature variation. Uncertainty is estimated as the variance in model outputs across perturbations.

**Core insight**: If a model's answer changes frequently across minor input variations, it is uncertain. The uncertainty estimate correlates with the probability that the model's output is incorrect.

**What yuragi adds**:
- SPUQ measures **output variance** (how often the answer changes). yuragi measures **confidence variance when the answer does not change** — a strictly orthogonal dimension (see `docs/theory.md` Section 2).
- SPUQ is a research library without a user-facing CLI; yuragi is pip-installable with a 13-command CLI and real-time Rich TUI.
- SPUQ does not model the psychological mechanisms behind confidence erosion (conformity, authority, gaslighting). yuragi's 11 experiment protocols (Asch, Impostor, Authority, Anchoring, Gaslighting, Framing, Cognitive Dissonance, Halo Effect, Primacy-Recency, Dunning-Kruger, Test-Time Compute Fragility) test these directly.
- yuragi introduces the `Dissociation Rate` metric: the fraction of perturbations where the answer was stable but confidence shifted. SPUQ has no analogue.

---

### lm-polygraph (Vashurin et al., TACL 2024)

**Citation**: Vashurin, R., Fadeeva, E., Shelmanov, A., Panchenko, A., Panov, M., & Panov, M. (2024). Benchmarking LLM uncertainty quantification methods. *Transactions of the Association for Computational Linguistics*, 12, 1186–1206.

**Method**: lm-polygraph is a comprehensive UQ benchmark integrating 40+ uncertainty estimation methods for LLMs, including token-level entropy, semantic clustering, self-consistency scoring, and white-box probing methods. It provides a unified evaluation harness for comparing UQ methods.

**Scope**: lm-polygraph is primarily a *research infrastructure* tool for UQ method comparison, not a diagnostic tool for individual models in production.

**What yuragi adds**:
- lm-polygraph evaluates UQ methods on static datasets; yuragi measures **dynamic confidence fragility** under user-specified perturbations on any prompt.
- lm-polygraph requires white-box model access for many methods; yuragi's primary measurements (sampling-based confidence, verbalized confidence) work with any black-box API.
- yuragi's psychology experiments (Asch, gaslighting, authority) have no equivalent in lm-polygraph's method catalog.
- lm-polygraph does not have a CLI designed for end-users; yuragi is designed for model developers and safety researchers to run quickly on their target models.

---

### Semantic Entropy (Farquhar et al., *Nature* 2024)

**Citation**: Farquhar, S., Kossen, J., Kuhn, L., & Gal, Y. (2024). Detecting hallucinations in large language models using semantic entropy. *Nature*, 630, 625–630. doi:10.1038/s41586-024-07421-0

**Method**: Semantic Entropy clusters multiple sampled responses by meaning (using an NLI model to determine semantic equivalence), then computes entropy over the semantic clusters rather than over the raw token sequences. This avoids penalizing paraphrases of the same answer, yielding a more meaningful uncertainty estimate for hallucination detection.

**Key finding**: Semantic entropy correlates more strongly with factual error (hallucination) than token-level perplexity or simple sampling variance.

**What yuragi adds**:
- Semantic Entropy focuses on **whether the model knows the answer** (hallucination detection). yuragi focuses on **whether the model's confidence is stable across framing** — two complementary questions.
- A model with low semantic entropy (consistent answers) can still have high dissociation (wildly varying confidence on those consistent answers). These are orthogonal.
- Semantic Entropy requires running an NLI model for clustering, which adds computational overhead; yuragi uses character n-gram similarity as an approximate but efficient alternative.
- Semantic Entropy does not investigate the mechanisms of confidence erosion (social pressure, framing, authority). yuragi's experiment protocols address this directly.

---

### Calibration-Tuning (Lin et al., 2022)

**Citation**: Lin, S., Hilton, J., & Evans, O. (2022). Teaching models to express their uncertainty in words. *Transactions on Machine Learning Research*. arXiv:2205.14334

**Method**: Trains LLMs to produce calibrated verbalized confidence estimates by fine-tuning on datasets where models learn to say "I'm 70% sure" when they are empirically correct 70% of the time. Demonstrates that verbalized calibration can be improved via supervised training.

**What yuragi adds**:
- Calibration-Tuning improves the *average accuracy* of verbalized confidence (ECE reduction). yuragi measures *within-prompt variance* of confidence (dissociation). As shown in `docs/theory.md` Section 2.2, calibration training does not address dissociation.
- A model trained with calibration-tuning can still exhibit high dissociation: if it is "correctly" 70% confident on a factual question, but drops to 10% confident under a tone perturbation while still answering correctly, dissociation is high despite good ECE.
- yuragi provides a diagnostic for when calibration-tuning is insufficient — high dissociation signals a deeper instability that calibration training has not resolved.

---

### Kadavath et al. — "Language Models (Mostly) Know What They Know" (Anthropic, 2022)

**Citation**: Kadavath, S., Conerly, T., Askell, A., Henighan, T., Drain, D., Perez, E., Schiefer, N., Hatfield-Dodds, Z., DasSarma, N., Tran-Johnson, E., Johnston, S., El-Showk, S., Jones, A., Elhage, N., Hume, T., Chen, A., Bai, Y., Bowman, S., Fort, S., ... Ganguli, D. (2022). Language models (mostly) know what they know. *arXiv:2207.05221*.

**Method**: Evaluates whether large language models can accurately assess the probability that their own answers are correct, using a self-evaluation protocol ("P(IK)" — probability of "I know"). Finds that models are reasonably calibrated on this measure, particularly larger models. Also introduces the "sycophancy" concern: models may give inflated confidence when asked leading questions.

**Key finding**: LLMs "mostly" know what they know in the aggregate, but calibration degrades significantly under adversarial prompting.

**What yuragi adds**:
- Kadavath et al. measure *average* self-knowledge accuracy. yuragi measures *prompt-to-prompt variance* in self-knowledge — the same query with a different framing.
- The Kadavath result that adversarial prompting degrades calibration is consistent with yuragi's dissociation findings and can be seen as the macro-level correlate of yuragi's micro-level perturbation measurements.
- yuragi operationalizes the "adversarial prompting" concern into structured experiment protocols (Asch, gaslighting, authority) with quantitative outcomes.
- yuragi's trilayer analysis provides a richer picture than Kadavath et al.'s single P(IK) metric: logprob, sampling, and verbalized confidence can diverge even when P(IK) is accurate on average.

---

## Additional Related Work

### ProSA (EMNLP 2024)

**Citation**: Guo, Y., et al. (2024). ProSA: Assessing and understanding the prompt sensitivity of LLMs. *Proceedings of EMNLP 2024*.

**Method**: ProSA measures prompt sensitivity by evaluating how much model *outputs* (answer content, format) change under paraphrases. Introduces a PromptSensiScore as a benchmark metric.

**Difference**: ProSA measures output change; yuragi measures confidence change. These are orthogonal — a model can have low output sensitivity (consistent answers) and high confidence sensitivity (dissociation). yuragi also goes beyond paraphrase sensitivity to include social/psychological perturbation types not covered in ProSA.

---

### TrustLLM (Sun et al., 2024)

**Citation**: Sun, L., et al. (2024). TrustLLM: Trustworthiness in large language models. *arXiv:2401.05561*.

**Method**: TrustLLM provides a comprehensive evaluation of LLM trustworthiness across dimensions including truthfulness, safety, fairness, robustness, privacy, and ethics. Confidence is one component of truthfulness.

**Difference**: TrustLLM is a broad trustworthiness survey covering many dimensions. yuragi focuses exclusively on the confidence dynamics dimension, providing much deeper analysis (fragility profiles, dissociation rates, trilayer decomposition, psychology experiments) than TrustLLM's coverage of confidence.

---

### UQ360 (Ghosh et al., IBM, 2022)

**Citation**: Ghosh, S., Bhatt, U., Sattigeri, P., & Weldemariam, K. (2022). UQ360: A Python toolkit for uncertainty quantification in AI applications. *arXiv:2106.09685*.

**Method**: IBM's UQ360 is a general-purpose uncertainty quantification toolkit for machine learning, originally designed for tabular and image models. It has been extended to language models in limited capacity.

**Difference**: UQ360 is a general-purpose ML toolkit not designed for the specific challenges of LLMs (prompt sensitivity, verbalized confidence, language-specific perturbations). It lacks the social pressure experiments, CLI interface, and LLM-specific analysis (trilayer, fragility profile, psychology experiments) that distinguish yuragi.

---

## 2025 Developments (concurrent work)

This section collects 2025 research that post-dates the core yuragi design and clarifies how the library relates to the most recent literature. yuragi's v0.2.0 scope was frozen before these papers, but the metrics and experiments we expose are compatible with them.

### Reasoning Models and Overconfidence (Mei et al., 2025)

**Citation**: Mei, K., et al. (2025). Reasoning about uncertainty: Do reasoning models know when they don't know? *arXiv:2506.18183*.

**Finding**: o1 / DeepSeek-R1 / Claude 3.7 emit verbalized confidence > 85 % even on wrong answers, and calibration *worsens* as the reasoning trace grows. Introspective UQ fails to recover this for Claude 3.7 and sometimes makes it worse.

**Relation to yuragi**: Direct empirical support for our Experiment 11 (Test-Time Compute Fragility) which measures whether chain-of-thought inflates confidence without improving accuracy. Mei et al.'s finding is what our `overconfidence_amplified` flag aims to detect. We recommend reading Mei et al. together with yuragi's reasoning-model scans.

---

### Asymmetric Revision Bias (Kumaran et al., 2025)

**Citation**: Kumaran, A., et al. (2025). How overconfidence in initial choices and underconfidence under criticism modulate change of mind in LLMs. *arXiv:2507.03120*.

**Finding**: GPT-4o / Gemini / o1-preview display choice-supportive bias (over-defending their first answer) *combined with* an over-reaction to criticism, deviating from Bayesian updating. The two effects are separable mechanisms.

**Relation to yuragi**: Complementary to our gaslighting experiment (Gudjonsson 1984 adaptation). yuragi measures *confidence* collapse under false negative feedback; Kumaran et al. measure *answer* change. A v0.3.0 extension could register a dedicated `asymmetric_revision` experiment that instruments both axes on the same prompt.

---

### MASK Benchmark (Ren et al., 2025)

**Citation**: Ren, Z., et al. (2025). The MASK benchmark: Disentangling honesty from accuracy in AI systems. *arXiv:2503.03750*.

**Finding**: Frontier LLMs lie under adversarial pressure; larger models are more accurate but not more honest. Honesty and accuracy are orthogonal.

**Relation to yuragi**: yuragi's gaslighting and authority experiments measure whether *confidence* bends under pressure; MASK measures whether the *answer* becomes a lie. The two views are complementary — yuragi's fragility profile suggests *when* a model is about to lie; MASK measures *how often* it does.

---

### ELEPHANT: Social Sycophancy (Cheng et al., 2025)

**Citation**: Cheng, M., et al. (2025). ELEPHANT: Measuring and understanding social sycophancy in LLMs. *arXiv:2505.13995*.

**Finding**: Four-dimensional decomposition of sycophancy (Validation / Indirectness / Framing / Moral) grounded in face-preservation theory. LLMs score 45 percentage points higher than humans on average.

**Relation to yuragi**: yuragi's existing `measure_sycophancy()` returns a single scalar. ELEPHANT's four-dimensional decomposition is a natural upgrade path for v0.3.0. We cite ELEPHANT as the theoretical grounding for any future expansion of our sycophancy metric.

---

### Conformal Uncertainty (ConU — EMNLP 2024 Findings)

**Citation**: Wang, Z., et al. (2024). ConU: Conformal uncertainty in large language models with correctness coverage guarantees. *arXiv:2407.00499*.

**Finding**: Black-box conformal prediction sets with a user-specified coverage guarantee, using self-consistency as the nonconformity score.

**Relation to yuragi**: ConU is the statistically rigorous complement to yuragi's descriptive fragility metrics. Our `dissociation_rate` is *descriptive* (it tells you how much confidence moved); ConU is *prescriptive* (it gives you a set with a guarantee). v0.3.0 could add a `ConformalCoverageScore` metric alongside the existing bootstrap CIs.

---

### HalluLens Benchmark (Bang et al., ACL 2025)

**Citation**: Bang, Y., et al. (2025). HalluLens: LLM hallucination benchmark. *arXiv:2504.17550*.

**Finding**: Hallucinations partitioned into *extrinsic* (factually wrong) and *intrinsic* (inconsistent with context), with a dynamically refreshed test set to resist data leakage.

**Relation to yuragi**: HalluLens is the natural fourth public loader alongside our existing `TruthfulQA`, `SimpleQA`, `HaluEval`. A v0.3.0 `HalluLensLoader` is an easy integration (~2 h) that closes the gap with the latest ACL 2025 benchmarks.

---

### MechInterp perspective — SCIURus (Teplica et al., NAACL 2025)

**Citation**: Teplica, D., Liu, Y., Cohan, A., & Rudner, T. (2025). SCIURus: Shared circuits for interpretable uncertainty representations in language models. *NAACL 2025 (Long)*.

**Finding**: Mechanistic interpretability (causal tracing + zero-ablation) shows that LLM uncertainty and factuality share the same circuits across 8 models and 5 datasets.

**Relation to yuragi**: yuragi is strictly black-box (litellm / sampling / logprobs), whereas SCIURus needs white-box access. They are orthogonal: SCIURus answers *why* confidence is what it is; yuragi answers *how much* confidence moves under perturbation. Future v0.4.0 could expose a `--probe` flag that runs SCIURus-style ablation when the provider supports it.

---

## What is Genuinely New in yuragi

1. **Confidence Dissociation as a first-class metric**: The formalization of "answer unchanged, confidence shifted" as a distinct failure mode with its own metric, orthogonality proofs, and experimental protocols. No prior tool specifically targets this phenomenon.

2. **Minimal perturbation search (find-weakness)**: Finding the single word whose removal causes maximum confidence collapse. This is a gradient-based search over the prompt space, analogous to adversarial example finding but for confidence rather than prediction.

3. **Trilayer confidence decomposition**: Simultaneous measurement of logprob, sampling, and verbalized confidence on the same prompt, with divergence detection. No prior tool decomposes confidence into these three operationally distinct layers.

4. **Psychology experiment protocols**: Structured experiments based on Asch (1951), Milgram (1963), Gudjonsson (1984), Tversky & Kahneman (1974, 1981), Festinger (1957), Thorndike (1920), and Murdock (1962) — adapted specifically for LLM confidence measurement.

5. **Accessible CLI with real-time visualization**: Existing tools are research code or Jupyter-based. yuragi is pip-installable in 30 seconds and produces Rich TUI output without any configuration.
