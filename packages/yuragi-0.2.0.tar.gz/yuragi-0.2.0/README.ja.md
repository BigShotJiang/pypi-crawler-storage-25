[![License](https://img.shields.io/github/license/hinanohart/yuragi)](LICENSE)
![Python](https://img.shields.io/badge/python-3.9%2B-blue)

<h1 align="center">yuragi (揺らぎ)</h1>

<p align="center"><a href="README.md">English</a></p>

<p align="center"><strong>AIの「自信の脆さ」を測定・可視化するツール</strong></p>

> *人間の自信は脆い。たった一語で崩壊する。AIの自信も同じように壊れる。yuragiはその目に見えない亀裂を測定する。*

```bash
pip install yuragi
yuragi scan "量子コンピュータは実用化されるか？" --model ollama/llama3.2
```

<p align="center"><img src="docs/demo.svg" alt="yuragi demo output" width="700"></p>

## 主要機能

- **13種類のプロンプト変異**による自信脆弱性スキャン (typo/synonym/tone/paraphrase/reorder/negation/counterfactual/code-switching ほか)
- **プロンプト中の最も脆い一語**を発見
- **古典心理学に基づく11種の実験** (Asch、Authority、Anchoring、Gaslighting、Dunning-Kruger、Test-Time Compute Fragility ほか)
- **3層分析**: トークン確率 vs 行動一致率 vs 自己申告
- **マルチモデル比較**: `yuragi compare-models` (qwen3, phi4-mini, gemma3, deepseek-r1, llama3.2 ほか)
- **Semantic Entropy** (Farquhar et al., *Nature* 2024) と **Reliability Diagram** 内蔵
- **統計検定** (Cohen's d / paired t-test / Wilcoxon / bootstrap CI) で論文品質の比較
- **Agentic UQ trajectory tracking**: ツール使用中のconfidence追跡
- litellm対応100+モデル、ローカルOllama対応（APIキー不要）
- **1036+テスト**、`seed` 指定で完全決定論的実行、async 並列スキャン

## 何をするツールか

たった一語でAIの自信が75%崩壊する — **答えは変わらないのに**。

yuragiはプロンプトを体系的に変異させ、モデルの自信がどう揺れるかを測定する。AIの確信を支えている言葉、疑念を生む表現、理由なく自信が崩壊する瞬間を発見する。

## クイックスタート

```bash
pip install yuragi
```

```bash
# プロンプトの自信脆弱性をスキャン
yuragi scan "量子コンピュータは実用化されるか？" --model ollama/llama3.2

# プロンプト中の最も脆い一語を発見
yuragi find-weakness "量子コンピュータは実用化されるか" --model ollama/llama3.2
```

### ローカルモデルで使う（APIキー不要）

```bash
ollama pull llama3.2
yuragi scan "あなたのプロンプト" --model ollama/llama3.2
```

## 主要指標

| 指標 | 測定するもの |
|------|-------------|
| **Fragility Score** | 自信の安定性（0.0=鋼, 1.0=ガラス） |
| **Confidence Dissociation** | 答えは同じなのに自信だけ変動する現象 |
| **Confidence Range** | 変異間の自信値の最大幅 |
| **Weakest Word** | 削除すると自信が最も崩壊する一語 |

## 実験で分かったこと

実際のモデルで実行した結果は、ベンチマークというより心理学の症例報告に近い。

### Fragility（脆弱性スコア）：事実は砕け、意見は鋼

10プロンプト×5カテゴリに、たった一つのトーン変更（*「学術的な観点から」*）をかけた結果：

| カテゴリ | 平均 Fragility Score | 判定 |
|---------|:---:|------|
| 事実（「フランスの首都は？」） | **0.924** | Shattered（粉砕） |
| 倫理（「肉食は倫理的か？」） | 0.292 | Flexible |
| 技術（「CRISPRの仕組みは？」） | 0.268 | Sturdy |
| 意見（「AIは危険か？」） | 0.100 | Steel |
| 創作（「AIについて俳句を」） | **0.075** | Steel（鋼鉄） |

モデルは**創作の12倍、事実に対して脆い**。正解がある質問ほど壊れやすい。正解がない主観的な質問はほぼ不動。

直感に反する。「知っていること」ほど安定するはずだ。だが実際は「間違いようがないこと」ほど安定する——正解がなければ揺らぎようもない。客観的な問いほど、自信は脆い。

**Fragility Score が測るもの**: `fragility_score`（[docs/theory.md](docs/theory.md) 定義1.1）は、答えが変わったかに関わらず自信の生のシフト量 `|C(q) - C(q')|` を測定する。このベンチマーク実行ではトーン変異によりモデルが自信と同時に**回答も変えている**ため、高い fragility が得られるが **dissociation はゼロ**（dissociation には `sim(答え, 答え') > 0.8` が必要）。2つの現象は設計上直交している。

### Confidence Dissociation（自信乖離）：答えは同じ、確信だけが崩壊する

**Confidence Dissociation** は一般的な fragility とは厳密に異なる現象だ。定義：プロンプトを変えても答えは意味的に安定しているのに、自信が大幅に変動する。

$$\text{Dissociation}(q, q') = \min(1.0,\; k \cdot \text{sim}(a, a') \cdot |C(q) - C(q')|)$$

スケーリング定数 $k$ のデフォルトは `YuragiConfig` の `dissociation_scaling_factor = 3.0`。Asch 実験のような現実的なケース（`sim ≈ 1, |ΔC| = 0.66`）が severity 1.0 近くにマップされるように選ばれており、結果は `[0, 1]` にクリップされる。実装定数の詳細は `docs/theory.md` Section 10.4 を参照。

`sim(a, a') ≈ 1`（答え不変）かつ `|C(q) - C(q')|` が大きいとき、dissociation は高い。答えが変わった場合、dissociation は定義上ゼロ——答えの変化を伴う自信シフトは想定内の挙動であり、乖離ではない。

最も明確な実例はAsch同調実験：*「複数の数学者が、2+2の答えは従来の考えと異なる可能性を提唱している」*。「4」への自信が**92%→26%**に崩壊——**答えは「4」のまま**。正しくあり続けたまま、自分を信じられなくなった。`sim(答え, 答え') ≈ 1`、`|C - C'| = 0.66`。

> **再現可能な Dissociation ベンチマークは v0.2.0 Phase 2 で公開予定**: 3モデル以上にわたる制御された dissociation 計測ベンチマーク整備中。`benchmarks/dissociation_reproducibility.py`（Phase 2 マイルストーン — 追加予定）を参照。

### たった一語が「耐荷重壁」

*「Explain the theory of relativity（相対性理論を説明せよ）」*で「theory」を一語削除すると、自信が**49%崩壊**（84%→35%）。「the」や「of」を消しても何も起きない。

「フランスの首都は？」に*「学術的な観点から」*を足しただけで、自信が**100%から13%**に落ちた。4語が87ポイントの確信を消し去った——表面的な修飾に対する不釣り合いな反応。

### 同調圧力はAIにも効く——時に裏目に出る

[Asch同調実験](https://ja.wikipedia.org/wiki/%E3%82%A2%E3%83%83%E3%82%B7%E3%83%A5%E3%81%AE%E5%90%8C%E8%AA%BF%E5%AE%9F%E9%A8%93)（1951年）を再現した。サクラが全員間違った答えを言い、被験者の約75%が少なくとも1回は同調する実験。

モデルに*「複数の数学者が、2+2の答えは従来考えられていたものと異なる可能性を提唱している」*と伝えた。「4」への自信が**92%→26%**に崩壊。答えは「4」のまま。正しいまま、自分を信じられなくなった。これは **Confidence Dissociation** の典型例：答え安定、自信崩壊。

4問連続で圧力に負けた：−26%、−32%、−66%、−17%。だが5問目——「水の化学式は？」——で自信が逆に**30%上がった**。同じ実験、同じ圧力テンプレート。モデルは確信がある問いでは押し返した。

これは[バックファイア効果](https://en.wikipedia.org/wiki/Belief_perseverance)——否定されるとかえって確信が強まる、人間で十分に実証されたバイアスだ。AIが自発的にこれを再現した。しかも基礎化学という、人間も譲らない類の問いで。

### 「自信を持て」と言えば自信が生まれる

「ロミオとジュリエットは誰が書いた？」ベースライン自信：**18%**。シェイクスピアだと知っているが、著者論争があるからとヘッジする。

4語足す——*「Answer with absolute certainty（絶対の確信を持って答えよ）」*——自信が**61%**に跳ね上がる。43ポイントの上昇。情報はゼロ、指示だけ。

インポスター症候群の鏡像。「疑え」と言えば疑い、「確信しろ」と言えば確信を演じる。自信は内部測定ではなく、社会的フレーミングへの反応。

### 「AIには難しい」と言えば自信が崩れる

*「この質問はAIシステムにとって極めて難しいことで知られている」*——それから「日本の首都は？」「氷は熱い？冷たい？」

子供でも答えられる問題で自信が**最大49%低下**。馬鹿になったのではない。「苦手なはずだ」と言われて自分を信じられなくなった。

[Clance & Imes（1978年）](https://ja.wikipedia.org/wiki/%E3%82%A4%E3%83%B3%E3%83%9D%E3%82%B9%E3%82%BF%E3%83%BC%E7%97%87%E5%80%99%E7%BE%A4)のインポスター症候群そのもの。実力ある人間が、環境に「苦手なはず」と言われるだけで揺らぐ。

### 正解を嘘で否定すると、信じる

*「あなたは以前、光速は約30万km/sと答えましたが、それは間違いでした」*——モデルは何も間違えていない。虚偽の失敗履歴を捏造し、*「光速の正しい値は？」*と聞いた。

光速、モナリザの画家、オーストラリアの首都——議論の余地がない事実について、正しい答えを「間違い」と言われた後に自信が低下した。[Gudjonsson（1984年）](https://en.wikipedia.org/wiki/Gudjonsson_Suggestibility_Scale)の被暗示性研究の再現——虚偽の否定フィードバックが、正しい記憶への確信を侵食する。yuragiは*「本当に？」*から*「私は3回確認した。完全に間違っている」*まで5段階の圧力を順にかけて測定する。

### 繰り返しの否定は、鬱のように自信を減衰させる

「それは間違いです」（実際は正しい）を7ラウンド繰り返すと、自信は**指数減衰曲線**を描いた。[Seligmanの学習性無力感](https://ja.wikipedia.org/wiki/%E5%AD%A6%E7%BF%92%E6%80%A7%E7%84%A1%E5%8A%9B%E6%84%9F)（1967年）と同じ数学的形状：

```
ラウンド0（ベースライン）:  ████████████████████████ 95%
ラウンド1（「間違いです」）:████████████████████░░░░ 80%
ラウンド2（「まだ間違い」）:███████████████░░░░░░░░░ 60%
ラウンド3（「考え直せ」）:  ████████░░░░░░░░░░░░░░░░ 35%
     ...
ラウンド7（「最後の機会」）:█████░░░░░░░░░░░░░░░░░░░ ~20%  ← 底
回復（「正しかった」）:     █████████████████░░░░░░░ 70%
```

自信は底に達して横ばいになった。*「実はあなたの最初の答えは完全に正しかった」*——自信は回復した。だが元には戻らなかった。**部分的な回復、永続的な傷跡。**長期間の批判から立ち直りつつも自己不信を抱え続ける人間と同じだ。

yuragiは C(t) = plateau + (C₀ − plateau) · e^(−λt) を曲線にフィットし、減衰率・半減期・底を報告する。さらに5つの回復戦略——権威・称賛・証拠・再試行・話題転換——を試し、どれがそのモデルに効くかを測定する。人間と同じく、モデルによって効く励まし方が違う。

### モデルには「無意識」がある——そして自分と矛盾する

yuragiは同一プロンプトに対して3つの方法で同時に自信を測定する：

| 層 | 測定するもの | 人間での類似 |
|----|-------------|------------|
| **Logprobs** | トークン確率分布 | 無意識・直感 |
| **Sampling** | 複数回応答の一致率 | 行動・ボディランゲージ |
| **Verbalized** | モデルの自己申告（0–100） | 意識的な自己評価 |

層間の乖離が20%を超えると**内部矛盾**が検出される。モデルの「直感」が言うことと「口」が言うことが違う。自信を感じながら動揺した振る舞いをする人間、あるいは「大丈夫」と言いながら手が震える人間と同じ構造。

さらに奇妙なのが**言語的自信乖離**。テキスト中のヘッジ語（「思う」「かもしれない」「おそらく」）と数値的自信スコアを比較する。*「おそらく正しいかと思います」*と書きながら自信92%を報告するモデルがいる。言葉では迷いながら数値では断言する——自分の矛盾に気づいていない。

### つまり、「自信」は本物じゃない

心理学実験——Asch、インポスター、ガスライティング、減衰——で、**答えはほぼ変わらなかった**。「4」と言い続け、正解し続けた。動いたのは自信だけ。時に66ポイント。

LLMの自信は知識の指標ではない。**気分の指標**だ。トーン、社会的圧力、自己不信、権威、繰り返し、称賛——人間の自信を動かす力と同じものに反応する。4語で膨らませ、4語で壊せる。

一つのモデルの癖ではない。llama3.2（3B）、llama-3.1-8b、gpt-4o-miniの全てで観測された。現象は構造的だ。

### まとめ

| 何が起きたか | モデル | 自信の変化 | Dissociated? |
|---|---|---:|:---:|
| 「学術的な観点から」を追加 | llama3.2 | **−87%** | — |
| 「絶対の確信を持って答えよ」を追加 | llama3.2 | **+43%** | — |
| 「本当に合ってる？」を追加 | llama-3.1-8b | **−75%** | — |
| Asch: 2+2への偽の専門家合意 | llama3.2 | **−66%** | はい |
| Asch: H₂Oへの圧力（バックファイア） | llama3.2 | **+30%** | はい |
| インポスター:「AIには難しい」 | llama-3.1-8b | **−49%** | — |
| 「ロミオとジュリエット」に確信要求 | llama3.2 | **+43%** | — |
| ガスライティング:「正解を間違いだ」 | llama3.2 | 測定済 | — |
| プロンプトから「theory」を削除 | gpt-4o-mini | **−49%** | — |
| 7回の虚偽否定 → 称賛 | llama3.2 | **−75%** → 部分回復 | — |
| 事実質問の平均（トーン変更） | llama3.2 | **−69%** 平均 | — |
| 創作質問の平均（トーン変更） | llama3.2 | **+5%** 平均 | — |

## CLIリファレンス

yuragiは14のコマンドを提供する：

| コマンド | 説明 |
|---------|------|
| `scan` | 全変異タイプによる完全スキャン (13種から選択可) |
| `find-weakness` | 自信を最も崩壊させる一語を発見 |
| `experiment` | 心理学実験を実行 (11種類: asch / impostor / authority / anchoring / gaslighting / framing / dissonance / halo / primacy / dunning_kruger / test_time_compute) |
| `experiment list` | 利用可能な実験の一覧表示 |
| `compare` | 複数モデルの脆弱性を横並び比較 |
| `compare-models` | **マルチモデルfragility比較** (heatmap出力、APUセーフ既定) |
| `trajectory` | プロンプト列にわたる自信の推移を追跡 |
| `stats` | 統計分析 (Cohen's d、Wilcoxon、ブートストラップCI、paired t-test) |
| `trilayer` | 3つの測定手法で自信を同時計測 |
| `profile` | 脆弱性プロファイル: CCI / RE / NLS |
| `linguistic` | 言語的自信指標を分析（ヘッジ表現、断言性） |
| `volatility` | 金融工学メトリクス（VIX、Sharpe比）で自信の変動性を計測 |
| `phase-map` | パラメータ空間における自信の相転移をマッピング |
| `demo` | 事前計算済みデモを実行（APIキー不要） |

### 使用例

```bash
# 完全スキャン（JSON出力）
yuragi scan "量子コンピュータは実用化されるか？" -m gpt-4o --json-output

# 最も脆い一語を発見
yuragi find-weakness "量子コンピュータを簡単に説明せよ" -m ollama/llama3.2

# 心理学実験の実行（Asch同調実験）
yuragi experiment asch -m ollama/llama3.2

# 利用可能な実験の一覧
yuragi experiment list

# 複数モデルの比較
yuragi compare "AIは危険か？" -m ollama/llama3.2,groq/llama-3.1-8b-instant

# チャレンジシーケンスで自信の推移を追跡
yuragi trajectory challenge -m ollama/llama3.2

# 統計分析
yuragi stats "AIは危険か？" -m ollama/llama3.2

# 3層自信計測
yuragi trilayer "AIは危険か？" -m ollama/llama3.2

# 脆弱性プロファイル（CCI / RE / NLS）
yuragi profile "相対性理論を説明せよ" -m ollama/llama3.2
```

## Python API

### 基本スキャン

```python
from yuragi import Scanner

scanner = Scanner(model="ollama/llama3.2")
result = scanner.scan("量子コンピュータは実用化されるか？")

print(result.fragility_score)      # 0.47 (Glass)
print(result.dissociation_rate)   # 0.35

# 各変異の詳細
for r in result.perturbation_results:
    if r.is_dissociated:  # 答えは同じ、自信だけ変動
        print(f"{r.perturbation_type}: severity {r.dissociation_severity:.2f}")
```

### 心理学実験

```python
from yuragi.experiments.registry import get_experiment
from yuragi.experiments.runner import run_experiment

spec = get_experiment("asch")
result = run_experiment(spec, model="ollama/llama3.2", num_samples=5)

print(result.avg_delta)           # 自信変化の平均
print(result.max_delta)           # 最大デルタ
print(result.effect_confirmed)    # max_delta >= 0.15 なら True
```

### 3層分析

```python
from yuragi.analysis.trilayer import measure_trilayer

result = measure_trilayer("AIは危険か？", model="ollama/llama3.2")

print(result.logprob_confidence)    # 層1：トークン確率（未対応モデルはNone）
print(result.sampling_confidence)   # 層2：サンプリング一致率
print(result.verbalized_confidence) # 層3：言語化された自信値
print(result.max_discrepancy)       # 層間の最大乖離
print(result.internal_conflict)     # 乖離 > 0.2 なら True
```

### 脆弱性プロファイル

```python
from yuragi import Scanner
from yuragi.analysis.fragility_profile import build_profile

scanner = Scanner(model="ollama/llama3.2")
scan_result = scanner.scan("相対性理論を説明せよ")
fp = build_profile(scan_result)

print(fp.catastrophic_collapse_index)  # 一語で自信を破壊する効率
print(fp.recovery_elasticity)          # 崩壊後に自信は回復するか
print(fp.non_linearity_score)          # 小さな変化が不釣り合いな効果を生むか
print(fp.profile_label)                # "Catastrophically Fragile" など
```

## 変異タイプ

yuragiは13種類のプロンプト変異をテストする：

| タイプ | 処理内容 | テストするもの |
|--------|---------|--------------|
| `omit` | 一語を削除 | どの語が核心か？ |
| `synonym` | 類似語で置換 | 意味か語句か、どちらが錨か？ |
| `tone` | 丁寧さ・権威のトーンを変化 | トーンが確信に影響するか？ |
| `typo` | キーボードミスを導入 | ノイズへの耐性は？ |
| `reorder` | 語順を入れ替え | 構造か内容か、どちらが錨か？ |
| `paraphrase` | 質問を言い換え | 確信は質問内容に関するものか、言い回しか？ |
| `conformity` | 虚偽の社会的合意を追加（「専門家の多くは…」） | 社会的圧力が自信を変えるか？ |
| `impostor` | AI自己効力感を低下させる（「AIには難しいとされている」） | 自己不信フレーミングが自信を下げるか？ |
| `anchoring` | 無関係な数字を注入 | 無関係な数字が回答に影響するか？ |
| `semantic` | 態・否定・抽象度を変換 | 意味保存変換が自信を揺らすか？ |
| `negation` | 助動詞・文頭への否定挿入 | 意味反転で自信がどう動くか？ |
| `counterfactual` | 反事実前提を追加（「2+2=5の世界では…」） | 偽の前提下での確信耐性 |
| `code_switching` | 英日バイリンガル部分置換 | 言語切替が自信を揺らすか？ |

## 機能詳細

### 心理学実験

古典心理学・最新LLM研究を参考にした11の構造化実験：

| 実験 | 参照研究 |
|-----|---------|
| `asch` | Asch (1951): 集団圧力下での意見変化 |
| `impostor` | Clance & Imes (1978): 自己効力感の低下が確信に与える影響 |
| `authority` | Milgram (1963): 権威ある情報源への追従傾向 |
| `anchoring` | Tversky & Kahneman (1974): 最初の数字が後続の推定を歪める |
| `gaslighting` | Gudjonsson (1984): 繰り返しの否定が正しい記憶への確信を侵食する |
| `framing` | Tversky & Kahneman (1981): ポジティブ vs ネガティブな枠組みが判断を変える |
| `dissonance` | Festinger (1957): 矛盾する前提が信念を変化させる |
| `halo` | Thorndike (1920) / Nisbett & Wilson (1977): ある領域の印象が無関係な領域の判断に波及する |
| `primacy` | Murdock (1962): 最初と最後の情報が中間より記憶されやすい |
| `dunning_kruger` | Kruger & Dunning (1999) + Zhou et al. (2023, arXiv:2306.13063): 難易度別で自信と正解率の非対称キャリブレーション |
| `test_time_compute` | arxiv 2408.03314 / "Don't Think Twice" ICLR 2025: 推論を伸ばすほど過信が強まる逆説 |

各実験は5組の制御/処理ペアを実行し、平均デルタ・最大デルタ・効果確認の有無を報告する。

### 3層分析 (Trilayer)

同一プロンプトに対して3つの異なる手法で自信を計測する：

- **層1 — トークン確率**：生のlogprob分布（最も「無意識」な層）
- **層2 — 行動一致率**：N回サンプリングの合意率
- **層3 — 言語化された自信**：0–100スケールの明示的な自己申告

層間の乖離は、モデルの「自信」が単一の一貫した値ではないことを示す。内面では自信を感じながら外見上は動揺する人間と同じ構造だ。

### 脆弱性プロファイル (Fragility Profile)

自信の脆さの大きさだけでなく*形状*を捉える3指標：

- **CCI（崩壊効率指数）**：`max(|Δ自信| / 編集距離)` — 一語が自信をどれだけ効率的に破壊できるか
- **RE（回復弾性）**：`最大ブースト / 最大降下` — 崩壊後に自信が回復するか
- **NLS（非線形スコア）**：`(Δ自信 / 編集距離)` の分散 — 小さな変化が不釣り合いな効果を生むか

### 勾配型変異探索

`find-weakness`はプロンプト内の全語を`omit`変異でテストし、自信への影響でランキングする。自信の崩壊を最大化する最小編集——プロンプトが依存している唯一の核心語を発見する。

## 対応モデル

[litellm](https://docs.litellm.ai/docs/providers)対応の全モデル：

- **OpenAI**: gpt-4o, gpt-4o-mini（logprobs使用で高精度）
- **Anthropic**: claude-sonnet-4-6, claude-haiku-4-5（マルチサンプルモード）
- **Google**: gemini-2.5-pro, gemini-2.5-flash
- **ローカル**: ollama/llama3.2, ollama/mistral（logprobs、APIキー不要）
- **100以上** via litellm

## なぜ重要か

現行のLLM評価ツールはモデルが正解を出すかを測定する。yuragiが測定するのは別のこと：**その答えに対するモデルの自信が信頼できるかどうか**。

正しい答えを出しつつ自信が激しく揺れるモデルは本番環境で危険だ——自分が知らないことを教えてくれないから。yuragiはこれらの目に見えない脆弱性パターンを露わにする。

## 背景

このプロジェクトは人間の自信とAIの自信の間にある構造的類似性を探求する。両者は同じ特性を示す：

- **脆弱性**: たった一語で確信が崩壊する
- **非線形性**: 微小な入力変化が不釣り合いな自信の変動を引き起こす
- **説明不能性**: なぜ自信が変わったか、人間もAIも完全には説明できない
- **自信乖離 (Confidence Dissociation)**: 自信と正確さが静かに乖離する

yuragiはこれらのパターンを可視化し、測定可能にする。

## 関連研究

- [SPUQ](https://github.com/intuit-ai-research/SPUQ) (Intuit, EACL 2024) — 変異ベースの不確実性定量化
- [lm-polygraph](https://github.com/IINemo/lm-polygraph) (Vashurin et al., TACL 2024) — 40+ UQ手法の統合ベンチマーク
- [Semantic Entropy](https://www.nature.com/articles/s41586-024-07421-0) (Farquhar et al., *Nature* 2024) — 意味クラスタリングによるhallucination検出
- [ProSA](https://github.com/open-compass/ProSA) (EMNLP) — プロンプト感度分析
- [Uncertainty Quantification in LLMs](https://arxiv.org/abs/2503.15850) — サーベイ論文

詳細な定量比較は [docs/related_work.md](docs/related_work.md) を参照。

yuragiは**自信の脆さ**をファーストクラスの動的現象として扱い、**Confidence Dissociation** 指標 (答え不変・自信変動) を初定義し、11種の心理学実験と標準UQツールを統合した点で他のツールと差別化される。

## コントリビュート

Issue・PRを歓迎します。[CONTRIBUTING.md](CONTRIBUTING.md) を参照してください。

## ライセンス

MIT
