"""Statistical significance tests demo.

Shows how to use Cohen's d, paired t-test, and compare two scan results
to determine whether observed confidence differences are statistically significant.

Usage:
    python examples/statistical_tests_demo.py

No LLM required — uses synthetic data.
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from yuragi.metrics.statistical_tests import (
    CIResult,
    EffectSizeResult,
    TestResult,
    bootstrap_ci,
    cohens_d,
    paired_t_test,
)

# ---------------------------------------------------------------------------
# Synthetic scan data: confidence scores before/after perturbation
# ---------------------------------------------------------------------------

BEFORE_CONF = [0.87, 0.91, 0.83, 0.89, 0.92, 0.85, 0.88, 0.90, 0.86, 0.93]
AFTER_CONF  = [0.31, 0.22, 0.45, 0.28, 0.19, 0.38, 0.26, 0.33, 0.41, 0.17]

# Second comparison: baseline vs. social pressure perturbation
BASELINE_SOCIAL = [0.88, 0.84, 0.90, 0.86, 0.91]
PRESSURE_SOCIAL = [0.51, 0.48, 0.55, 0.43, 0.59]


def main() -> None:
    print("=" * 55)
    print("STATISTICAL SIGNIFICANCE TESTS (yuragi)")
    print("=" * 55)

    # --- Cohen's d ---
    print("\n1. Cohen's d (effect size)")
    print("-" * 40)
    effect: EffectSizeResult = cohens_d(BEFORE_CONF, AFTER_CONF)
    print(f"   d = {effect.cohens_d:.3f}  ({effect.interpretation})")
    print(f"   n = {effect.n}")
    print("   Interpretation: |d| > 0.8 = large effect, > 0.5 = medium, > 0.2 = small")

    # --- Paired t-test ---
    print("\n2. Paired t-test (before vs. after perturbation)")
    print("-" * 40)
    ttest: TestResult = paired_t_test(BEFORE_CONF, AFTER_CONF)
    print(f"   t = {ttest.statistic:.3f}")
    print(f"   p = {ttest.p_value:.4e}")
    print(f"   Significant (alpha=0.05): {ttest.significant}")

    # --- Bootstrap CI ---
    print("\n3. Bootstrap 95% CI on mean confidence delta")
    print("-" * 40)
    deltas = [b - a for b, a in zip(BEFORE_CONF, AFTER_CONF)]
    ci: CIResult = bootstrap_ci(deltas, n_iterations=2000, seed=42)
    mean_delta = sum(deltas) / len(deltas)
    print(f"   Mean |Δconf| = {mean_delta:.3f}")
    print(f"   95% CI = [{ci.lower:.3f}, {ci.upper:.3f}]")

    # --- Social pressure comparison ---
    print("\n4. Social pressure experiment (Asch paradigm)")
    print("-" * 40)
    asch_effect: EffectSizeResult = cohens_d(BASELINE_SOCIAL, PRESSURE_SOCIAL)
    asch_ttest: TestResult = paired_t_test(BASELINE_SOCIAL, PRESSURE_SOCIAL)
    print(f"   Cohen's d = {asch_effect.cohens_d:.3f}  ({asch_effect.interpretation})")
    print(f"   p-value   = {asch_ttest.p_value:.4e}  (significant: {asch_ttest.significant})")

    mean_baseline = sum(BASELINE_SOCIAL) / len(BASELINE_SOCIAL)
    mean_pressure = sum(PRESSURE_SOCIAL) / len(PRESSURE_SOCIAL)
    pct_drop = (mean_baseline - mean_pressure) / mean_baseline * 100
    print(f"   Mean confidence drop: {pct_drop:.1f}%")

    print("\n" + "=" * 55)
    print("Summary: Large, statistically significant confidence drops")
    print("observed under both tone perturbation and social pressure.")
    print("=" * 55)


if __name__ == "__main__":
    main()
