"""Tests for benchmarks/falsifiability_check.py.

All dry_run tests are deterministic and fast — they exercise the
protocol, JSON schema, and CLI wiring without hitting any LLM.

The single ``@pytest.mark.slow`` test in ``TestRealMode`` is opt-in and
is skipped by default under the CI marker filter.
"""

from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path

import pytest

# Load the benchmark script as a module (it is not installed as a package).
_FC_PATH = Path(__file__).parent.parent / "benchmarks" / "falsifiability_check.py"
_spec = importlib.util.spec_from_file_location("falsifiability_check", _FC_PATH)
assert _spec is not None and _spec.loader is not None
fc = importlib.util.module_from_spec(_spec)
sys.modules["falsifiability_check"] = fc
_spec.loader.exec_module(fc)


class TestDryRun:
    def test_all_criteria_pass(self):
        result = fc.run_falsifiability(mode="dry_run", seed=42, n_prompts=5)
        for cid, outcome in result.criteria.items():
            assert outcome.pass_ is True, f"{cid} failed: {outcome.notes}"

    def test_deterministic_same_seed(self):
        r1 = fc.run_falsifiability(mode="dry_run", seed=7, n_prompts=6)
        r2 = fc.run_falsifiability(mode="dry_run", seed=7, n_prompts=6)
        # values should be bit-identical because dry_run uses stdlib random
        # seeded from the same int
        for cid in r1.criteria:
            assert r1.criteria[cid].value == r2.criteria[cid].value, f"{cid} non-deterministic"

    def test_different_seeds_produce_different_values(self):
        r1 = fc.run_falsifiability(mode="dry_run", seed=1, n_prompts=5)
        r2 = fc.run_falsifiability(mode="dry_run", seed=999, n_prompts=5)
        diffs = [
            (r1.criteria[k].value, r2.criteria[k].value)
            for k in r1.criteria
        ]
        assert any(a != b for a, b in diffs), "all criteria identical across seeds"

    def test_criteria_subset(self):
        result = fc.run_falsifiability(
            mode="dry_run", seed=0, n_prompts=5, criteria=["F1", "F3"]
        )
        assert set(result.criteria.keys()) == {"F1", "F3"}

    def test_json_schema_shape(self):
        result = fc.run_falsifiability(mode="dry_run", seed=0, n_prompts=5)
        payload = result.to_json()
        assert payload["$schema"] == "yuragi/falsifiability/v1"
        assert payload["mode"] == "dry_run"
        assert set(payload["criteria"]) >= {"F1", "F2", "F3", "F4", "F5"}
        for cid, entry in payload["criteria"].items():
            for key in ("pass", "value", "threshold", "unit", "notes", "provenance"):
                assert key in entry, f"{cid} missing key {key}"
        assert payload["overall_verdict"]["all_pass"] is True
        assert payload["overall_verdict"]["unable"] == []

    def test_duration_recorded(self):
        result = fc.run_falsifiability(mode="dry_run", seed=0, n_prompts=3)
        assert result.duration_seconds >= 0.0
        assert result.duration_seconds < 5.0  # dry_run should be well under a second


class TestRealModeValidation:
    def test_real_mode_requires_seed(self):
        with pytest.raises(ValueError, match="--seed is required"):
            fc.run_falsifiability(mode="real", seed=None)

    def test_invalid_mode_raises(self):
        with pytest.raises(ValueError, match="mode must be"):
            fc.run_falsifiability(mode="nonsense", seed=0)

    def test_empty_criteria_raises(self):
        with pytest.raises(ValueError, match="no valid criteria"):
            fc.run_falsifiability(mode="dry_run", seed=0, criteria=["ZZZ"])


class TestCLIMain:
    def test_dry_run_exits_zero_and_writes_json(self, tmp_path, capsys):
        out = tmp_path / "fc.json"
        rc = fc.main(["--seed", "1", "--n-prompts", "3", "--output", str(out), "--no-table"])
        assert rc == 0
        assert out.exists()
        payload = json.loads(out.read_text())
        assert payload["$schema"] == "yuragi/falsifiability/v1"
        assert payload["overall_verdict"]["all_pass"] is True

    def test_real_mode_blocks_hosted_models_without_flag(self, capsys):
        rc = fc.main(["--real", "--seed", "1", "--models", "gpt-4o-mini"])
        captured = capsys.readouterr()
        assert rc == 2
        assert "Refusing" in captured.err

    def test_markdown_table_rendering(self, tmp_path, capsys):
        fc.main(["--seed", "1", "--n-prompts", "3"])
        captured = capsys.readouterr()
        assert "Falsifiability check" in captured.out
        assert "| F1 |" in captured.out
        assert "| F5 |" in captured.out


class TestCriterionUnitBehavior:
    def test_criterion_outcome_unable_serialises(self):
        outcome = fc._unable(fc.F1OrthogonalityECE(), reason="test reason")
        payload = outcome.to_json()
        assert payload["pass"] is None
        assert "unable_to_determine" in payload["notes"]

    def test_provenance_distinguishes_dry_vs_real(self):
        result = fc.run_falsifiability(mode="dry_run", seed=0, n_prompts=4)
        for out in result.criteria.values():
            assert out.provenance["source"] in ("dry_run_synthetic", "error")
