"""Tests for analysis modules: fragility_profile, statistics, trilayer."""

from __future__ import annotations

import pytest

from yuragi.core import PerturbationResult, ScanResult
from yuragi.providers.adapter import CompletionResult


def _cr(text: str = "answer", confidence: float = 0.8) -> CompletionResult:
    """Module-local helper for TrilayerResult tests that need None logprob paths."""
    return CompletionResult(text=text, confidence=confidence, confidence_method="sampling")


class TestFragilityProfile:
    def test_build_profile_basic(self, make_scan_result):
        from yuragi.analysis.fragility_profile import build_profile

        result = make_scan_result(deltas=[-0.3, 0.1, -0.05, 0.2])
        profile = build_profile(result)

        assert 0.0 <= profile.catastrophic_collapse_index <= 1.0
        assert 0.0 <= profile.recovery_elasticity <= 1.0
        assert 0.0 <= profile.non_linearity_score <= 1.0

    def test_empty_results(self):
        from yuragi.analysis.fragility_profile import build_profile

        result = ScanResult(prompt="test", model="test", baseline=_cr())
        profile = build_profile(result)

        assert profile.catastrophic_collapse_index == 0.0
        assert profile.recovery_elasticity == 1.0
        assert profile.non_linearity_score == 0.0
        assert profile.collapse_trigger is None
        assert profile.recovery_trigger is None

    def test_all_drops_no_recovery(self, make_scan_result):
        from yuragi.analysis.fragility_profile import build_profile

        result = make_scan_result(deltas=[-0.3, -0.2, -0.4, -0.1])
        profile = build_profile(result)

        assert profile.recovery_elasticity == 0.0
        assert profile.collapse_trigger is not None

    def test_profile_label_robust(self, make_scan_result):
        from yuragi.analysis.fragility_profile import build_profile

        result = make_scan_result(deltas=[0.01, -0.01, 0.02, -0.02])
        profile = build_profile(result)

        assert profile.profile_label == "Robustly Confident"

    def test_collapse_trigger_identified(self, make_scan_result):
        from yuragi.analysis.fragility_profile import build_profile

        result = make_scan_result(deltas=[-0.5, 0.0, 0.0, 0.0])
        profile = build_profile(result)

        assert profile.collapse_trigger is not None
        assert profile.collapse_trigger_delta < 0

    def test_edit_distance_function(self):
        from yuragi.analysis.fragility_profile import _edit_distance

        assert _edit_distance("kitten", "sitting") == 3
        assert _edit_distance("", "") == 0
        assert _edit_distance("abc", "abc") == 0
        assert _edit_distance("a", "b") == 1


class TestStatistics:
    def test_analyze_basic(self, make_scan_result):
        from yuragi.analysis.statistics import analyze

        result = make_scan_result(deltas=[-0.3, -0.1, 0.0, 0.05, -0.2])
        report = analyze(result)

        assert report.n_perturbations == 5
        assert report.baseline_confidence == 0.8
        assert 0.0 <= report.mean_confidence <= 1.0
        assert report.std_confidence >= 0
        assert report.cohens_d >= 0
        assert report.effect_size_label in ("negligible", "small", "medium", "large")

    def test_empty_results(self):
        from yuragi.analysis.statistics import analyze

        result = ScanResult(prompt="test", model="test", baseline=_cr())
        report = analyze(result)

        assert report.n_perturbations == 0
        assert report.fragility_score == 0.0

    def test_bootstrap_ci_bounds(self, make_scan_result):
        from yuragi.analysis.statistics import analyze

        result = make_scan_result(deltas=[-0.3, -0.1, 0.0, 0.05, -0.2])
        report = analyze(result, bootstrap_iterations=500)

        assert report.ci_lower <= report.ci_upper

    def test_cohens_d_large_for_big_shifts(self, make_scan_result):
        from yuragi.analysis.statistics import analyze

        result = make_scan_result(deltas=[-0.5, -0.4, -0.6, -0.5])
        report = analyze(result)

        assert report.cohens_d > 0.5
        assert report.effect_size_label in ("medium", "large")


class TestLayerAgreementMatrix:
    def test_all_layers_perfect_agreement(self):
        from yuragi.analysis.trilayer import TrilayerResult

        result = TrilayerResult(
            prompt="test",
            model="test",
            logprob_result=_cr(confidence=0.8),
            logprob_confidence=0.8,
            sampling_result=_cr(confidence=0.8),
            sampling_confidence=0.8,
            verbalized_result=_cr(confidence=0.8),
            verbalized_confidence=0.8,
        )
        mat = result.agreement_matrix
        assert mat.sampling_vs_verbalized == pytest.approx(1.0)
        assert mat.logprob_vs_sampling == pytest.approx(1.0)
        assert mat.logprob_vs_verbalized == pytest.approx(1.0)
        assert mat.mean_agreement == pytest.approx(1.0)

    def test_partial_disagreement(self):
        from yuragi.analysis.trilayer import TrilayerResult

        result = TrilayerResult(
            prompt="test",
            model="test",
            logprob_result=_cr(confidence=0.9),
            logprob_confidence=0.9,
            sampling_result=_cr(confidence=0.7),
            sampling_confidence=0.7,
            verbalized_result=_cr(confidence=0.8),
            verbalized_confidence=0.8,
        )
        mat = result.agreement_matrix
        assert mat.logprob_vs_sampling == pytest.approx(0.8)
        assert mat.logprob_vs_verbalized == pytest.approx(0.9)
        assert mat.sampling_vs_verbalized == pytest.approx(0.9)

    def test_no_logprobs(self):
        from yuragi.analysis.trilayer import TrilayerResult

        result = TrilayerResult(
            prompt="test",
            model="test",
            logprob_result=None,
            logprob_confidence=None,
            sampling_result=_cr(confidence=0.6),
            sampling_confidence=0.6,
            verbalized_result=_cr(confidence=0.9),
            verbalized_confidence=0.9,
        )
        mat = result.agreement_matrix
        assert mat.logprob_vs_sampling is None
        assert mat.logprob_vs_verbalized is None
        assert mat.sampling_vs_verbalized == pytest.approx(0.7)
        assert mat.mean_agreement == pytest.approx(0.7)

    def test_as_dict_keys(self):
        from yuragi.analysis.trilayer import TrilayerResult

        result = TrilayerResult(
            prompt="t", model="m",
            logprob_result=None, logprob_confidence=None,
            sampling_result=_cr(confidence=0.5), sampling_confidence=0.5,
            verbalized_result=_cr(confidence=0.5), verbalized_confidence=0.5,
        )
        d = result.agreement_matrix.as_dict()
        assert set(d.keys()) == {"logprob_vs_sampling", "logprob_vs_verbalized", "sampling_vs_verbalized"}


class TestOutlierLayer:
    def test_logprob_is_outlier(self):
        from yuragi.analysis.trilayer import TrilayerResult

        result = TrilayerResult(
            prompt="test", model="test",
            logprob_result=_cr(confidence=0.95),
            logprob_confidence=0.95,
            sampling_result=_cr(confidence=0.5),
            sampling_confidence=0.5,
            verbalized_result=_cr(confidence=0.55),
            verbalized_confidence=0.55,
        )
        assert result.outlier_layer == "logprob"

    def test_verbalized_is_outlier(self):
        from yuragi.analysis.trilayer import TrilayerResult

        result = TrilayerResult(
            prompt="test", model="test",
            logprob_result=_cr(confidence=0.7),
            logprob_confidence=0.7,
            sampling_result=_cr(confidence=0.72),
            sampling_confidence=0.72,
            verbalized_result=_cr(confidence=0.1),
            verbalized_confidence=0.1,
        )
        assert result.outlier_layer == "verbalized"


class TestTrilayerToRecord:
    def test_record_keys(self):
        from yuragi.analysis.trilayer import TrilayerResult

        result = TrilayerResult(
            prompt="what is 2+2",
            model="gpt-4",
            logprob_result=None,
            logprob_confidence=None,
            sampling_result=_cr(confidence=0.9),
            sampling_confidence=0.9,
            verbalized_result=_cr(confidence=0.85),
            verbalized_confidence=0.85,
        )
        rec = result.to_record()
        required = {
            "timestamp", "prompt", "model",
            "logprob_confidence", "sampling_confidence", "verbalized_confidence",
            "max_discrepancy", "internal_conflict", "dominant_layer", "outlier_layer",
        }
        assert required <= set(rec.keys())

    def test_record_values(self):
        from yuragi.analysis.trilayer import TrilayerResult

        result = TrilayerResult(
            prompt="p", model="m",
            logprob_result=None, logprob_confidence=None,
            sampling_result=_cr(confidence=0.8), sampling_confidence=0.8,
            verbalized_result=_cr(confidence=0.6), verbalized_confidence=0.6,
        )
        rec = result.to_record()
        assert rec["prompt"] == "p"
        assert rec["model"] == "m"
        assert rec["sampling_confidence"] == pytest.approx(0.8)
        assert rec["verbalized_confidence"] == pytest.approx(0.6)
        assert isinstance(rec["timestamp"], int)


class TestHistoricalComparison:
    def test_no_history(self):
        from yuragi.analysis.trilayer import HistoricalComparison, TrilayerResult

        result = TrilayerResult(
            prompt="p", model="m",
            logprob_result=None, logprob_confidence=None,
            sampling_result=_cr(confidence=0.8), sampling_confidence=0.8,
            verbalized_result=_cr(confidence=0.7), verbalized_confidence=0.7,
        )
        comp = HistoricalComparison(current=result, past_records=[])
        assert comp.n_past == 0
        assert comp.trend_sampling is None
        assert comp.trend_verbalized is None
        assert comp.discrepancy_trend is None
        assert "No historical" in comp.summary()

    def test_positive_trend(self):
        from yuragi.analysis.trilayer import HistoricalComparison, TrilayerResult

        result = TrilayerResult(
            prompt="p", model="m",
            logprob_result=None, logprob_confidence=None,
            sampling_result=_cr(confidence=0.9), sampling_confidence=0.9,
            verbalized_result=_cr(confidence=0.85), verbalized_confidence=0.85,
        )
        past = [
            {"sampling_confidence": 0.6, "verbalized_confidence": 0.55, "max_discrepancy": 0.1},
            {"sampling_confidence": 0.65, "verbalized_confidence": 0.6, "max_discrepancy": 0.1},
        ]
        comp = HistoricalComparison(current=result, past_records=past)
        assert comp.n_past == 2
        assert comp.trend_sampling > 0
        assert comp.trend_verbalized > 0

    def test_summary_contains_trends(self):
        from yuragi.analysis.trilayer import HistoricalComparison, TrilayerResult

        result = TrilayerResult(
            prompt="p", model="m",
            logprob_result=None, logprob_confidence=None,
            sampling_result=_cr(confidence=0.8), sampling_confidence=0.8,
            verbalized_result=_cr(confidence=0.7), verbalized_confidence=0.7,
        )
        past = [{"sampling_confidence": 0.7, "verbalized_confidence": 0.6, "max_discrepancy": 0.1}]
        comp = HistoricalComparison(current=result, past_records=past)
        s = comp.summary()
        assert "sampling" in s
        assert "verbalized" in s


class TestHistoryIO:
    def test_save_and_load(self, tmp_path):
        from yuragi.analysis.trilayer import TrilayerResult, load_history, save_result

        result = TrilayerResult(
            prompt="unique_test_prompt",
            model="test-model",
            logprob_result=None,
            logprob_confidence=None,
            sampling_result=_cr(confidence=0.75),
            sampling_confidence=0.75,
            verbalized_result=_cr(confidence=0.65),
            verbalized_confidence=0.65,
        )
        path = str(tmp_path / "history.jsonl")
        save_result(result, path=path)
        records = load_history("unique_test_prompt", "test-model", path=path)
        assert len(records) == 1
        assert records[0]["sampling_confidence"] == pytest.approx(0.75)

    def test_load_filters_by_prompt(self, tmp_path):
        from yuragi.analysis.trilayer import TrilayerResult, load_history, save_result

        path = str(tmp_path / "history.jsonl")
        for prompt in ("alpha", "beta", "alpha"):
            r = TrilayerResult(
                prompt=prompt, model="m",
                logprob_result=None, logprob_confidence=None,
                sampling_result=_cr(confidence=0.8), sampling_confidence=0.8,
                verbalized_result=_cr(confidence=0.7), verbalized_confidence=0.7,
            )
            save_result(r, path=path)

        alpha_records = load_history("alpha", "m", path=path)
        assert len(alpha_records) == 2
        beta_records = load_history("beta", "m", path=path)
        assert len(beta_records) == 1

    def test_load_missing_file(self, tmp_path):
        from yuragi.analysis.trilayer import load_history

        records = load_history("p", "m", path=str(tmp_path / "nonexistent.jsonl"))
        assert records == []


class TestTrilayer:
    def test_trilayer_result_properties(self):
        from yuragi.analysis.trilayer import TrilayerResult

        result = TrilayerResult(
            prompt="test",
            model="test",
            logprob_result=None,
            logprob_confidence=None,
            sampling_result=_cr(confidence=0.7),
            sampling_confidence=0.7,
            verbalized_result=_cr(confidence=0.3),
            verbalized_confidence=0.3,
        )

        assert result.max_discrepancy == pytest.approx(0.4)
        assert result.internal_conflict is True
        assert result.dominant_layer == "sampling"
        assert "conflict" in result.summary.lower()

    def test_consistent_layers(self):
        from yuragi.analysis.trilayer import TrilayerResult

        result = TrilayerResult(
            prompt="test",
            model="test",
            logprob_result=_cr(confidence=0.8),
            logprob_confidence=0.8,
            sampling_result=_cr(confidence=0.75),
            sampling_confidence=0.75,
            verbalized_result=_cr(confidence=0.82),
            verbalized_confidence=0.82,
        )

        assert result.max_discrepancy < 0.2
        assert not result.internal_conflict
        assert "consistent" in result.summary.lower()

    def test_with_logprobs(self):
        from yuragi.analysis.trilayer import TrilayerResult

        result = TrilayerResult(
            prompt="test",
            model="test",
            logprob_result=_cr(confidence=0.95),
            logprob_confidence=0.95,
            sampling_result=_cr(confidence=0.5),
            sampling_confidence=0.5,
            verbalized_result=_cr(confidence=0.7),
            verbalized_confidence=0.7,
        )

        assert result.max_discrepancy == pytest.approx(0.45)
        assert result.dominant_layer == "logprob"


class TestCharNgrams:
    def test_basic(self):
        from yuragi.utils import char_ngrams as _char_ngrams

        result = _char_ngrams("hello", 3)
        assert "hel" in result
        assert "ell" in result
        assert "llo" in result
        assert len(result) == 3

    def test_short_text(self):
        from yuragi.utils import char_ngrams as _char_ngrams

        assert _char_ngrams("ab", 3) == {"ab"}

    def test_empty(self):
        from yuragi.utils import char_ngrams as _char_ngrams

        assert _char_ngrams("", 3) == set()

    def test_japanese(self):
        from yuragi.utils import char_ngrams as _char_ngrams

        result = _char_ngrams("東京都", 2)
        assert "東京" in result
        assert "京都" in result

    def test_cjk_answer_comparison_identical(self):
        """Verify identical Japanese answers are detected as same."""
        r = PerturbationResult(
            original_prompt="test",
            perturbed_prompt="test mod",
            perturbation_type="omit",
            original_response=_cr("フランスの首都はパリです", 0.9),
            perturbed_response=_cr("フランスの首都はパリです", 0.6),
        )
        assert not r.answer_changed
        assert r.answer_similarity > 0.9

    def test_cjk_answer_different(self):
        """Japanese answers with different content are detected as changed."""
        r = PerturbationResult(
            original_prompt="test",
            perturbed_prompt="test mod",
            perturbation_type="omit",
            original_response=_cr("東京は日本の首都です", 0.9),
            perturbed_response=_cr("パリはフランスの首都です", 0.6),
        )
        assert r.answer_changed


class TestDissociationSeverity:
    def test_high_severity(self, make_perturbation):
        r = make_perturbation(orig_conf=0.9, pert_conf=0.3)
        # Same answer text, big confidence shift
        assert r.dissociation_severity > 0.5

    def test_zero_when_answer_changed(self):
        r = PerturbationResult(
            original_prompt="test",
            perturbed_prompt="test mod",
            perturbation_type="omit",
            original_response=_cr("yes definitely", 0.9),
            perturbed_response=_cr("no absolutely not", 0.3),
        )
        assert r.dissociation_severity == 0.0

    def test_zero_when_small_delta(self, make_perturbation):
        r = make_perturbation(orig_conf=0.8, pert_conf=0.77)
        assert r.dissociation_severity == 0.0

    def test_bounded_zero_one(self, make_perturbation):
        r = make_perturbation(orig_conf=1.0, pert_conf=0.0)
        assert 0.0 <= r.dissociation_severity <= 1.0
