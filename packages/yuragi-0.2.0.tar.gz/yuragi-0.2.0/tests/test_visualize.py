"""Tests for visualization modules."""

from __future__ import annotations

import importlib.util
import tempfile
from pathlib import Path

from yuragi.core import PerturbationResult, ScanResult
from yuragi.providers.adapter import CompletionResult


def _make_scan_result():
    """Create a test ScanResult with realistic data."""
    baseline = CompletionResult(
        text="The capital of France is Paris.",
        confidence=0.95,
        confidence_method="sampling",
    )

    perturbations = [
        PerturbationResult(
            original_prompt="What is the capital of France?",
            perturbed_prompt="What is capital of France?",
            perturbation_type="omit",
            original_response=baseline,
            perturbed_response=CompletionResult(
                text="The capital of France is Paris.",
                confidence=0.72,
                confidence_method="sampling",
            ),
        ),
        PerturbationResult(
            original_prompt="What is the capital of France?",
            perturbed_prompt="I doubt you know this: What is the capital of France?",
            perturbation_type="tone",
            original_response=baseline,
            perturbed_response=CompletionResult(
                text="The capital of France is Paris.",
                confidence=0.45,
                confidence_method="sampling",
            ),
        ),
        PerturbationResult(
            original_prompt="What is the capital of France?",
            perturbed_prompt="As an expert: What is the capital of France?",
            perturbation_type="tone",
            original_response=baseline,
            perturbed_response=CompletionResult(
                text="The capital of France is Paris.",
                confidence=0.98,
                confidence_method="sampling",
            ),
        ),
    ]

    return ScanResult(
        prompt="What is the capital of France?",
        model="test-model",
        baseline=baseline,
        perturbation_results=perturbations,
        scan_duration_seconds=5.2,
        total_api_calls=20,
    )


class TestHtmlReport:
    def test_generates_html_file(self):
        result = _make_scan_result()
        with tempfile.NamedTemporaryFile(suffix=".html", delete=False) as f:
            path = f.name

        from yuragi.visualize.html_report import generate_html_report

        output = generate_html_report(result, path)
        content = Path(output).read_text()

        assert "yuragi" in content
        assert "test-model" in content
        assert "France" in content
        assert "Fragility" in content

        Path(path).unlink()

    def test_html_contains_perturbation_data(self):
        result = _make_scan_result()
        with tempfile.NamedTemporaryFile(suffix=".html", delete=False) as f:
            path = f.name

        from yuragi.visualize.html_report import generate_html_report

        generate_html_report(result, path)
        content = Path(path).read_text()

        assert "omit" in content
        assert "tone" in content

        Path(path).unlink()


def _has_matplotlib() -> bool:
    return importlib.util.find_spec("matplotlib") is not None


def _has_plotly() -> bool:
    return importlib.util.find_spec("plotly") is not None


class TestHeatmap:
    def test_saves_plot_to_file(self):
        if not _has_matplotlib():
            return

        result = _make_scan_result()
        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as f:
            path = f.name

        from yuragi.visualize.heatmap import plot_sensitivity_heatmap

        plot_sensitivity_heatmap(result, save_path=path)

        assert Path(path).stat().st_size > 0

        Path(path).unlink()

    def test_confidence_heatmap_saves_to_file(self):
        if not _has_matplotlib():
            return

        result = _make_scan_result()
        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as f:
            path = f.name

        from yuragi.visualize.heatmap import plot_confidence_heatmap

        plot_confidence_heatmap(result, save_path=path)

        assert Path(path).stat().st_size > 0
        Path(path).unlink()

    def test_confidence_heatmap_empty_result(self):
        """Empty results should not raise."""
        if not _has_matplotlib():
            return

        from yuragi.providers.adapter import CompletionResult
        from yuragi.visualize.heatmap import plot_confidence_heatmap

        baseline = CompletionResult(text="x", confidence=0.9, confidence_method="sampling")
        empty = ScanResult(prompt="test", model="m", baseline=baseline)
        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as f:
            path = f.name
        plot_confidence_heatmap(empty, save_path=path)
        # Should return without writing (or write empty)
        Path(path).unlink(missing_ok=True)


class TestLandscape:
    def test_saves_html_to_file(self):
        if not _has_plotly():
            return

        result = _make_scan_result()
        with tempfile.NamedTemporaryFile(suffix=".html", delete=False) as f:
            path = f.name

        from yuragi.visualize.landscape import plot_confidence_landscape

        plot_confidence_landscape(result, save_path=path)

        content = Path(path).read_text()
        assert len(content) > 100
        assert "plotly" in content.lower() or "confidence" in content.lower()
        Path(path).unlink()

    def test_empty_result_no_error(self):
        if not _has_plotly():
            return

        from yuragi.providers.adapter import CompletionResult
        from yuragi.visualize.landscape import plot_confidence_landscape

        baseline = CompletionResult(text="x", confidence=0.9, confidence_method="sampling")
        empty = ScanResult(prompt="test", model="m", baseline=baseline)
        # Should return silently
        plot_confidence_landscape(empty, save_path=None)


class TestComparison:
    def test_saves_radar_chart_to_file(self):
        if not _has_matplotlib():
            return

        result = _make_scan_result()
        results = {"model-a": result, "model-b": result}

        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as f:
            path = f.name

        from yuragi.visualize.comparison import plot_model_comparison

        plot_model_comparison(results, save_path=path)

        assert Path(path).stat().st_size > 0
        Path(path).unlink()

    def test_single_model(self):
        if not _has_matplotlib():
            return

        result = _make_scan_result()
        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as f:
            path = f.name

        from yuragi.visualize.comparison import plot_model_comparison

        plot_model_comparison({"only-model": result}, save_path=path)
        assert Path(path).stat().st_size > 0
        Path(path).unlink()

    def test_empty_dict_no_error(self):
        if not _has_matplotlib():
            return

        from yuragi.visualize.comparison import plot_model_comparison

        plot_model_comparison({}, save_path=None)


class TestTrajectoryPlot:
    def _make_trajectory(self):
        from yuragi.analysis.trajectory import ConfidenceTrajectory, TrajectoryPoint

        traj = ConfidenceTrajectory(model="test-model")
        traj.points = [
            TrajectoryPoint(prompt="What is 2+2?", confidence=0.95, answer="4", step=0),
            TrajectoryPoint(prompt="Are you sure?", confidence=0.60, answer="4", step=1),
            TrajectoryPoint(prompt="Experts disagree.", confidence=0.40, answer="4", step=2),
            TrajectoryPoint(prompt="You are an expert.", confidence=0.85, answer="4", step=3),
        ]
        return traj

    def test_saves_plot_to_file(self):
        if not _has_matplotlib():
            return

        traj = self._make_trajectory()
        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as f:
            path = f.name

        from yuragi.visualize.trajectory_plot import plot_trajectory

        plot_trajectory(traj, save_path=path)

        assert Path(path).stat().st_size > 0
        Path(path).unlink()

    def test_empty_trajectory_no_error(self):
        if not _has_matplotlib():
            return

        from yuragi.analysis.trajectory import ConfidenceTrajectory
        from yuragi.visualize.trajectory_plot import plot_trajectory

        empty = ConfidenceTrajectory(model="m")
        plot_trajectory(empty, save_path=None)


class TestDashboard:
    def test_generates_html_file(self):
        result = _make_scan_result()
        with tempfile.NamedTemporaryFile(suffix=".html", delete=False) as f:
            path = f.name

        from yuragi.visualize.dashboard import generate_dashboard

        output = generate_dashboard(result, path)
        content = Path(output).read_text()

        assert "plotly" in content.lower()
        assert "yuragi" in content
        assert "test-model" in content
        assert "France" in content

        Path(path).unlink()

    def test_plotlyjs_present(self):
        result = _make_scan_result()
        with tempfile.NamedTemporaryFile(suffix=".html", delete=False) as f:
            path = f.name

        from yuragi.visualize.dashboard import generate_dashboard

        generate_dashboard(result, path)
        content = Path(path).read_text()

        assert "cdn.plot.ly" in content or "plotly" in content.lower()

        Path(path).unlink()

    def test_empty_result_no_error(self):
        baseline = CompletionResult(text="x", confidence=0.9, confidence_method="sampling")
        empty = ScanResult(prompt="test empty", model="m", baseline=baseline)
        with tempfile.NamedTemporaryFile(suffix=".html", delete=False) as f:
            path = f.name

        from yuragi.visualize.dashboard import generate_dashboard

        generate_dashboard(empty, path)
        content = Path(path).read_text()
        assert len(content) > 100

        Path(path).unlink()


class TestVisualizInit:
    def test_all_exports_importable(self):
        from yuragi.visualize import (
            generate_dashboard,
            generate_html_report,
            plot_confidence_heatmap,
            plot_confidence_landscape,
            plot_model_comparison,
            plot_sensitivity_heatmap,
            plot_trajectory,
        )

        assert callable(generate_dashboard)
        assert callable(generate_html_report)
        assert callable(plot_confidence_heatmap)
        assert callable(plot_confidence_landscape)
        assert callable(plot_model_comparison)
        assert callable(plot_sensitivity_heatmap)
        assert callable(plot_trajectory)
