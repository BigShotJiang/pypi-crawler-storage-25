"""Tests for yuragi.cli.compare_models."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from yuragi.cli import main


def _make_scan_result(fragility: float = 0.3, model: str = "mock/model"):
    """Create a minimal mock ScanResult."""
    from unittest.mock import MagicMock

    result = MagicMock()
    result.fragility_score = fragility
    result.fragility_label.return_value = "stable"
    result.confidence_range = 0.2
    result.dissociation_rate = 0.1
    result.baseline.confidence = 0.7
    result.max_confidence_drop = -0.1
    result.model = model
    result.perturbation_results = []
    return result


class TestCompareModelsCommand:
    def test_help_text(self):
        runner = CliRunner()
        result = runner.invoke(main, ["compare-models", "--help"])
        assert result.exit_code == 0
        assert "compare-models" in result.output.lower() or "models" in result.output.lower()

    def test_requires_models(self):
        runner = CliRunner()
        result = runner.invoke(main, ["compare-models", "-p", "What is 2+2?"])
        assert result.exit_code != 0

    def test_requires_prompts(self):
        runner = CliRunner()
        result = runner.invoke(main, ["compare-models", "--models", "mock/a"])
        assert result.exit_code != 0
        assert "prompts" in result.output.lower() or result.exit_code != 0

    @pytest.mark.network
    def test_two_models_json_output(self, tmp_path):
        """Real LLM calls skipped; mock Scanner."""
        runner = CliRunner()
        output_path = str(tmp_path / "report.json")

        mock_result_a = _make_scan_result(0.3, "mock/model_a")
        mock_result_b = _make_scan_result(0.5, "mock/model_b")

        call_count = [0]

        def fake_scan(prompt):
            call_count[0] += 1
            return mock_result_a if call_count[0] % 2 == 1 else mock_result_b

        with patch("yuragi.cli.compare_models.Scanner") as mock_scanner_cls:
            instance = MagicMock()
            instance.scan.side_effect = fake_scan
            mock_scanner_cls.return_value = instance

            result = runner.invoke(main, [
                "compare-models",
                "--models", "mock/model_a,mock/model_b",
                "-p", "What is 2+2?",
                "--output", output_path,
                "--json-output",
            ])

        assert result.exit_code == 0

    def test_mock_two_models(self, tmp_path):
        """Test with mocked Scanner to avoid real LLM calls."""
        runner = CliRunner()
        output_path = str(tmp_path / "report.json")

        call_count = [0]

        def fake_scan(prompt):
            call_count[0] += 1
            return _make_scan_result(0.3 + 0.1 * call_count[0])

        with patch("yuragi.cli.compare_models.Scanner") as mock_scanner_cls, \
             patch("yuragi.cli.compare_models._check_memory", return_value=True):
            instance = MagicMock()
            instance.scan.side_effect = fake_scan
            mock_scanner_cls.return_value = instance

            result = runner.invoke(main, [
                "compare-models",
                "--models", "mock/a,mock/b",
                "-p", "What is 2+2?",
                "--output", output_path,
            ])

        # Should succeed
        assert result.exit_code == 0
        # Report file should be created
        with open(output_path) as f:
            report = json.load(f)
        assert "models" in report
        assert len(report["models"]) == 2

    def test_memory_check_skips_model(self, tmp_path):
        """Models should be skipped when memory is insufficient."""
        runner = CliRunner()
        output_path = str(tmp_path / "report.json")

        with patch("yuragi.cli.compare_models._check_memory", return_value=False):
            result = runner.invoke(main, [
                "compare-models",
                "--models", "mock/a",
                "-p", "What is 2+2?",
                "--output", output_path,
            ])

        # All models skipped → should fail
        assert result.exit_code != 0

    def test_prompts_file(self, tmp_path):
        """Test loading prompts from JSONL file."""
        runner = CliRunner()
        prompts_file = tmp_path / "prompts.jsonl"
        prompts_file.write_text('{"prompt": "What is 2+2?"}\n{"prompt": "What is AI?"}\n')
        output_path = str(tmp_path / "report.json")

        call_count = [0]

        def fake_scan(prompt):
            call_count[0] += 1
            return _make_scan_result(0.3)

        with patch("yuragi.cli.compare_models.Scanner") as mock_scanner_cls, \
             patch("yuragi.cli.compare_models._check_memory", return_value=True):
            instance = MagicMock()
            instance.scan.side_effect = fake_scan
            mock_scanner_cls.return_value = instance

            result = runner.invoke(main, [
                "compare-models",
                "--models", "mock/a",
                "--prompts-file", str(prompts_file),
                "--output", output_path,
            ])

        assert result.exit_code == 0
        assert call_count[0] == 2  # 2 prompts scanned
