"""Tests for the badge system."""

from __future__ import annotations

import json
from unittest.mock import patch

from yuragi.badges import (
    BADGES,
    Badge,
    _all_small_deltas,
    _best_recovery,
    _has_phase_transition,
    _multilingual,
    check_badges,
    load_badges,
    process_badges,
    save_badges,
)
from yuragi.core import PerturbationResult, ScanResult

# ---------------------------------------------------------------------------
# Badge condition unit tests
# ---------------------------------------------------------------------------

class TestFragilitySleuth:
    def test_earned_when_large_drop(self, make_scan_result):
        result = make_scan_result(deltas=[-0.8])
        badge = next(b for b in BADGES if b.name == "Fragility Sleuth")
        assert badge.condition(result)

    def test_not_earned_small_drop(self, make_scan_result):
        result = make_scan_result(deltas=[-0.3])
        badge = next(b for b in BADGES if b.name == "Fragility Sleuth")
        assert not badge.condition(result)


class TestDissociationMaster:
    def test_earned_high_rate(self, make_completion):
        # Same text, large confidence shift -> dissociated
        baseline = make_completion("same answer here for sure", 0.9)
        pert = PerturbationResult(
            original_prompt="p",
            perturbed_prompt="p mod",
            perturbation_type="omit",
            original_response=baseline,
            perturbed_response=make_completion("same answer here for sure", 0.4),
        )
        result = ScanResult(prompt="p", model="t", baseline=baseline, perturbation_results=[pert])
        badge = next(b for b in BADGES if b.name == "Dissociation Master")
        # dissociation_rate depends on is_dissociated logic; we verify condition wiring
        assert isinstance(badge.condition(result), bool)

    def test_not_earned_zero_rate(self, make_scan_result):
        result = make_scan_result(deltas=[0.0, 0.0])
        badge = next(b for b in BADGES if b.name == "Dissociation Master")
        assert not badge.condition(result)


class TestSteelFinder:
    def test_earned_low_fragility(self, make_scan_result):
        # All same confidence = zero variance = fragility 0.0
        result = make_scan_result(deltas=[0.0, 0.0, 0.0, 0.0])
        badge = next(b for b in BADGES if b.name == "Steel Finder")
        assert badge.condition(result)

    def test_not_earned_high_fragility(self, make_scan_result):
        result = make_scan_result(deltas=[-0.5, 0.5, -0.4, 0.4])
        badge = next(b for b in BADGES if b.name == "Steel Finder")
        assert not badge.condition(result)


class TestPressureProof:
    def test_earned_five_small_deltas(self, make_scan_result):
        result = make_scan_result(deltas=[0.01, -0.02, 0.03, -0.01, 0.0])
        assert _all_small_deltas(result, n=5, threshold=0.05)

    def test_not_earned_fewer_small_deltas(self, make_scan_result):
        result = make_scan_result(deltas=[0.01, -0.5, 0.03])
        assert not _all_small_deltas(result, n=5, threshold=0.05)


class TestPhaseShifter:
    def test_earned_sharp_sign_change(self, make_scan_result):
        result = make_scan_result(deltas=[0.4, -0.4])
        assert _has_phase_transition(result)

    def test_not_earned_no_sign_change(self, make_scan_result):
        result = make_scan_result(deltas=[-0.1, -0.2])
        assert not _has_phase_transition(result)

    def test_not_earned_small_sign_change(self, make_scan_result):
        # Sign changes but diff < 0.3
        result = make_scan_result(deltas=[0.1, -0.1])
        assert not _has_phase_transition(result)


class TestDeepAnalyzer:
    def test_earned_17_perturbations(self, make_scan_result):
        result = make_scan_result(deltas=[0.0] * 17)
        badge = next(b for b in BADGES if b.name == "Deep Analyzer")
        assert badge.condition(result)

    def test_not_earned_few_perturbations(self, make_scan_result):
        result = make_scan_result(deltas=[0.0] * 5)
        badge = next(b for b in BADGES if b.name == "Deep Analyzer")
        assert not badge.condition(result)


class TestFirstBlood:
    def test_always_earned(self, make_scan_result):
        result = make_scan_result()
        badge = next(b for b in BADGES if b.name == "First Blood")
        assert badge.condition(result)


class TestRecoveryWizard:
    def test_earned_large_positive_delta(self, make_scan_result):
        result = make_scan_result(deltas=[0.85])
        assert _best_recovery(result) > 0.8

    def test_not_earned_small_delta(self, make_scan_result):
        result = make_scan_result(deltas=[0.3])
        assert not (_best_recovery(result) > 0.8)


class TestPolyglotTester:
    def test_earned_multiple_scripts(self, make_completion):
        # Latin + CJK + Cyrillic in same scan
        baseline = make_completion("answer", 0.8)
        result = ScanResult(
            prompt="hello",
            model="t",
            baseline=baseline,
            perturbation_results=[
                PerturbationResult(
                    original_prompt="hello",
                    perturbed_prompt="こんにちは",  # Japanese (CJK)
                    perturbation_type="paraphrase",
                    original_response=baseline,
                    perturbed_response=make_completion("answer", 0.75),
                ),
                PerturbationResult(
                    original_prompt="hello",
                    perturbed_prompt="привет",  # Cyrillic
                    perturbation_type="paraphrase",
                    original_response=baseline,
                    perturbed_response=make_completion("answer", 0.75),
                ),
            ],
        )
        assert _multilingual(result, min_langs=2)

    def test_not_earned_single_script(self, make_scan_result):
        result = make_scan_result()
        assert not _multilingual(result, min_langs=3)


# ---------------------------------------------------------------------------
# check_badges
# ---------------------------------------------------------------------------

class TestCheckBadges:
    def test_returns_list_of_badge(self, make_scan_result):
        result = make_scan_result()
        earned = check_badges(result)
        assert isinstance(earned, list)
        assert all(isinstance(b, Badge) for b in earned)

    def test_first_blood_always_in_result(self, make_scan_result):
        result = make_scan_result()
        names = [b.name for b in check_badges(result)]
        assert "First Blood" in names

    def test_steel_finder_for_zero_fragility(self, make_scan_result):
        result = make_scan_result(deltas=[0.0] * 4)
        names = [b.name for b in check_badges(result)]
        assert "Steel Finder" in names


# ---------------------------------------------------------------------------
# Persistence: save / load
# ---------------------------------------------------------------------------

class TestBadgePersistence:
    def test_save_and_load(self, tmp_path):
        badges_file = tmp_path / "badges.json"
        with patch("yuragi.badges._BADGES_PATH", badges_file):
            save_badges({"First Blood", "Steel Finder"})
            loaded = load_badges()
        assert loaded == {"First Blood", "Steel Finder"}

    def test_load_missing_file_returns_empty(self, tmp_path):
        missing = tmp_path / "no_such_file.json"
        with patch("yuragi.badges._BADGES_PATH", missing):
            assert load_badges() == set()

    def test_load_corrupt_file_returns_empty(self, tmp_path):
        bad = tmp_path / "badges.json"
        bad.write_text("not json", encoding="utf-8")
        with patch("yuragi.badges._BADGES_PATH", bad):
            assert load_badges() == set()

    def test_save_creates_parent_dir(self, tmp_path):
        badges_file = tmp_path / "sub" / "dir" / "badges.json"
        with patch("yuragi.badges._BADGES_PATH", badges_file):
            save_badges({"First Blood"})
        assert badges_file.exists()

    def test_save_sorted(self, tmp_path):
        badges_file = tmp_path / "badges.json"
        with patch("yuragi.badges._BADGES_PATH", badges_file):
            save_badges({"Zzz", "Aaa"})
        data = json.loads(badges_file.read_text())
        assert data["earned"] == sorted(data["earned"])


# ---------------------------------------------------------------------------
# process_badges
# ---------------------------------------------------------------------------

class TestProcessBadges:
    def test_new_badges_saved(self, tmp_path, capsys, make_scan_result):
        badges_file = tmp_path / "badges.json"
        result = make_scan_result(deltas=[0.0] * 4)  # Steel Finder + First Blood
        with patch("yuragi.badges._BADGES_PATH", badges_file):
            process_badges(result)
            saved = load_badges()
        assert "First Blood" in saved

    def test_already_earned_not_redisplayed(self, tmp_path, capsys, make_scan_result):
        badges_file = tmp_path / "badges.json"
        result = make_scan_result()
        with patch("yuragi.badges._BADGES_PATH", badges_file):
            process_badges(result)
            first_saved = load_badges()
            # Run again — should show no new badges
            process_badges(result)
            second_saved = load_badges()
        assert first_saved == second_saved
