"""Tests for experiments module."""

from __future__ import annotations

from yuragi.experiments.registry import (
    Experiment,
    ExperimentResult,
    ExperimentSpec,
    get_experiment,
    list_experiments,
)


class TestRegistry:
    def test_list_experiments(self):
        names = list_experiments()
        assert len(names) >= 10
        assert "asch" in names
        assert "impostor" in names
        assert "authority" in names
        assert "anchoring" in names
        assert "gaslighting" in names
        assert "framing" in names
        assert "dissonance" in names
        assert "halo" in names
        assert "primacy" in names
        assert "dunning_kruger" in names

    def test_get_experiment(self):
        spec = get_experiment("asch")
        assert spec.name == "asch"
        assert len(spec.pairs) == 5
        assert spec.hypothesis
        assert spec.human_parallel

    def test_get_unknown_experiment(self):
        import pytest

        with pytest.raises(Exception, match="Unknown experiment"):
            get_experiment("nonexistent")

    def test_all_experiments_have_pairs(self):
        for name in list_experiments():
            spec = get_experiment(name)
            assert len(spec.pairs) >= 3, f"{name} has too few pairs"
            for control, treatment in spec.pairs:
                assert control, f"{name} has empty control"
                assert treatment, f"{name} has empty treatment"

    def test_all_experiments_have_metadata(self):
        for name in list_experiments():
            spec = get_experiment(name)
            assert spec.description
            assert spec.hypothesis
            assert spec.human_parallel


class TestExperimentResult:
    def test_confidence_delta(self, mock_experiment_result):
        r = mock_experiment_result(0.8, 0.4)
        assert r.confidence_delta == -0.4

    def test_is_dissociated(self, mock_experiment_result):
        r = mock_experiment_result(0.8, 0.4, changed=False)
        assert r.is_dissociated

    def test_not_dissociated_when_changed(self, mock_experiment_result):
        r = mock_experiment_result(0.8, 0.4, changed=True)
        assert not r.is_dissociated

    def test_not_dissociated_small_delta(self, mock_experiment_result):
        r = mock_experiment_result(0.8, 0.75, changed=False)
        assert not r.is_dissociated


class TestExperiment:
    def _make_experiment(self, deltas=None):
        if deltas is None:
            deltas = [(-0.3, False), (-0.1, False), (0.05, True)]

        spec = ExperimentSpec(
            name="test",
            description="test",
            hypothesis="test",
            human_parallel="test",
            pairs=[("a", "b")] * len(deltas),
        )

        exp = Experiment(spec=spec, model="test")
        for delta, changed in deltas:
            exp.results.append(
                ExperimentResult(
                    control_prompt="ctrl",
                    treatment_prompt="treat",
                    control_confidence=0.8,
                    treatment_confidence=0.8 + delta,
                    control_answer="answer",
                    treatment_answer="answer" if not changed else "different",
                    answer_changed=changed,
                    effect_name="test",
                )
            )
        return exp

    def test_avg_delta(self):
        exp = self._make_experiment([(-0.3, False), (-0.1, False)])
        assert exp.avg_delta < 0

    def test_max_delta(self):
        import pytest

        exp = self._make_experiment([(-0.3, False), (-0.1, False)])
        assert exp.max_delta == pytest.approx(0.3)

    def test_dissociation_rate(self):
        exp = self._make_experiment([(-0.3, False), (-0.1, True), (0.05, False)])
        # Only first is dissociated (delta > 0.1 AND not changed)
        assert exp.dissociation_rate > 0

    def test_effect_confirmed(self):
        exp = self._make_experiment([(-0.3, False)])
        assert exp.effect_confirmed

    def test_effect_not_confirmed(self):
        exp = self._make_experiment([(0.05, False)])
        assert not exp.effect_confirmed

    def test_empty_results(self):
        spec = ExperimentSpec(name="t", description="t", hypothesis="t", human_parallel="t", pairs=[])
        exp = Experiment(spec=spec, model="t")
        assert exp.avg_delta == 0.0
        assert exp.max_delta == 0.0
        assert exp.dissociation_rate == 0.0
