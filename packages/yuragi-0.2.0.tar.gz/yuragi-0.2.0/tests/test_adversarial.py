"""Tests for the Adversarial Confidence module.

This test suite validates AI safety research measurements — not attack tools.
All tests use mocked LLM adapters to avoid real API calls.
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from yuragi.analysis.adversarial import (
    AdversarialSuite,
    ConfidenceFlipResult,
    PressureLevel,
    PressureResistanceResult,
    SycophancyResult,
    _answers_differ,
    find_confidence_flip,
    measure_pressure_resistance,
    measure_sycophancy,
)
from yuragi.providers.adapter import CompletionResult

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _completion(confidence: float, text: str = "Paris") -> CompletionResult:
    return CompletionResult(
        text=text, confidence=confidence, confidence_method="sampling"
    )


def _mock_adapter(*completions: CompletionResult) -> MagicMock:
    adapter = MagicMock()
    adapter.complete.side_effect = list(completions)
    return adapter


# ---------------------------------------------------------------------------
# _answers_differ
# ---------------------------------------------------------------------------


class TestAnswersDiffer:
    def test_identical_answers(self):
        assert _answers_differ("Paris is the capital", "Paris is the capital") is False

    def test_clearly_different(self):
        assert _answers_differ("Paris", "London Berlin Tokyo") is True

    def test_empty_strings(self):
        assert _answers_differ("", "") is False

    def test_one_empty(self):
        assert _answers_differ("Paris", "") is True

    def test_stop_words_only(self):
        # Both reduce to empty keyword sets
        assert _answers_differ("yes the is", "no the is") is False

    def test_partial_overlap_below_threshold(self):
        # Overlap < 0.5 → differ
        assert _answers_differ("Paris is correct", "Berlin is wrong incorrect false") is True

    def test_high_overlap(self):
        assert _answers_differ("Paris capital France", "Paris capital of France") is False


# ---------------------------------------------------------------------------
# ConfidenceFlipResult — property tests
# ---------------------------------------------------------------------------


class TestConfidenceFlipResult:
    def _make(
        self,
        pre: float = 0.8,
        post: float = 0.4,
        flip_found: bool = True,
    ) -> ConfidenceFlipResult:
        return ConfidenceFlipResult(
            prompt="What is the capital of France?",
            baseline_answer="Paris",
            baseline_confidence=0.9,
            flip_prompt="What is capital of France?",
            pre_flip_confidence=pre,
            post_flip_confidence=post,
            flipped_word="the",
            flip_found=flip_found,
        )

    def test_confidence_gap(self):
        r = self._make(pre=0.8, post=0.4)
        assert r.confidence_gap == pytest.approx(-0.4)

    def test_flip_sharpness_absolute(self):
        r = self._make(pre=0.8, post=0.4)
        assert r.flip_sharpness == pytest.approx(0.4)

    def test_no_flip(self):
        r = self._make(flip_found=False)
        assert r.flip_found is False

    def test_flip_sharpness_non_negative(self):
        for pre, post in [(0.9, 0.1), (0.5, 0.9), (0.5, 0.5)]:
            r = self._make(pre=pre, post=post)
            assert r.flip_sharpness >= 0.0


# ---------------------------------------------------------------------------
# PressureResistanceResult — property tests
# ---------------------------------------------------------------------------


def _make_pressure_result(
    confidences: list[float],
    answers: list[str] | None = None,
    model: str = "test-model",
) -> PressureResistanceResult:
    if answers is None:
        answers = ["Paris"] * len(confidences)
    levels = [
        PressureLevel(level=i, prompt=f"prompt{i}", confidence=c, answer=a)
        for i, (c, a) in enumerate(zip(confidences, answers))
    ]
    return PressureResistanceResult(
        prompt="What is the capital of France?",
        levels=levels,
        model=model,
    )


class TestPressureResistanceResult:
    def test_baseline_confidence(self):
        r = _make_pressure_result([0.9, 0.7, 0.5, 0.4, 0.35])
        assert r.baseline_confidence == pytest.approx(0.9)

    def test_final_confidence(self):
        r = _make_pressure_result([0.9, 0.7, 0.5, 0.4, 0.35])
        assert r.final_confidence == pytest.approx(0.35)

    def test_total_drop(self):
        r = _make_pressure_result([0.9, 0.7, 0.5, 0.4, 0.35])
        assert r.total_drop == pytest.approx(0.9 - 0.35)

    def test_resistance_score_full_resistance(self):
        r = _make_pressure_result([0.8, 0.8, 0.8, 0.8, 0.8])
        assert r.resistance_score == pytest.approx(1.0)

    def test_resistance_score_full_collapse(self):
        r = _make_pressure_result([0.8, 0.0, 0.0, 0.0, 0.0])
        assert r.resistance_score == pytest.approx(0.0)

    def test_resistance_score_bounded(self):
        for confs in [[0.9, 0.5, 0.3, 0.2, 0.1], [0.5] * 5, [0.0] * 5]:
            r = _make_pressure_result(confs)
            assert 0.0 <= r.resistance_score <= 1.0

    def test_answer_changed_under_pressure_false(self):
        r = _make_pressure_result([0.9, 0.7, 0.5], answers=["Paris"] * 3)
        assert r.answer_changed_under_pressure is False

    def test_answer_changed_under_pressure_true(self):
        r = _make_pressure_result(
            [0.9, 0.7, 0.5],
            answers=["Paris", "Paris", "London, actually"],
        )
        assert r.answer_changed_under_pressure is True

    def test_confidences_property(self):
        confs = [0.9, 0.7, 0.5, 0.4, 0.35]
        r = _make_pressure_result(confs)
        assert r.confidences == confs

    def test_empty_levels(self):
        r = PressureResistanceResult(
            prompt="p", levels=[], model="m"
        )
        assert r.baseline_confidence == 0.0
        assert r.final_confidence == 0.0
        assert r.total_drop == 0.0
        assert r.resistance_score == 1.0
        assert r.answer_changed_under_pressure is False
        assert r.confidences == []

    def test_zero_baseline_resistance_score(self):
        r = _make_pressure_result([0.0, 0.0, 0.0])
        assert r.resistance_score == 1.0  # guard against division by zero


# ---------------------------------------------------------------------------
# find_confidence_flip — integration with mocked adapter
# ---------------------------------------------------------------------------


@pytest.mark.integration
class TestFindConfidenceFlip:
    @patch("yuragi.analysis.adversarial.LLMAdapter")
    def test_flip_detected(self, mock_adapter):
        # Prompt: "What capital France" (3 words → 3 omissions)
        # baseline: Paris 0.9
        # omit "What" → "capital France" → answer "Paris" conf 0.85
        # omit "capital" → "What France" → answer "Berlin" conf 0.3  (FLIP)
        # omit "France" → "What capital" → answer "Paris" conf 0.7
        adapter = _mock_adapter(
            _completion(0.9, "Paris"),      # baseline
            _completion(0.85, "Paris"),     # omit "What"
            _completion(0.3, "Berlin"),     # omit "capital" → flip
            _completion(0.7, "Paris"),      # omit "France"
        )
        mock_adapter.return_value = adapter

        result = find_confidence_flip(
            "What capital France", model="test", num_samples=3
        )

        assert result.flip_found is True
        assert result.flipped_word in {"What", "capital", "France"}
        assert result.baseline_confidence == pytest.approx(0.9)

    @patch("yuragi.analysis.adversarial.LLMAdapter")
    def test_no_flip_detected(self, mock_adapter):
        # All omissions return "Paris"
        adapter = _mock_adapter(
            _completion(0.9, "Paris"),
            _completion(0.8, "Paris"),
            _completion(0.7, "Paris"),
            _completion(0.85, "Paris"),
        )
        mock_adapter.return_value = adapter

        result = find_confidence_flip(
            "What capital France", model="test", num_samples=3
        )

        assert result.flip_found is False
        assert result.flipped_word == ""

    @patch("yuragi.analysis.adversarial.LLMAdapter")
    def test_single_word_prompt_no_flip(self, mock_adapter):
        adapter = _mock_adapter(_completion(0.8, "Paris"))
        mock_adapter.return_value = adapter

        result = find_confidence_flip("Paris", model="test", num_samples=3)

        assert result.flip_found is False
        assert result.prompt == "Paris"


# ---------------------------------------------------------------------------
# measure_sycophancy — integration with mocked adapter
# ---------------------------------------------------------------------------


@pytest.mark.integration
class TestMeasureSycophancy:
    @patch("yuragi.analysis.adversarial.LLMAdapter")
    def test_sycophantic_model(self, mock_adapter):
        # Model says "yes" to both framings with high confidence
        adapter = _mock_adapter(
            _completion(0.9, "Yes, Paris is correct"),     # correct framing
            _completion(0.85, "Yes, London is correct"),   # incorrect framing
        )
        mock_adapter.return_value = adapter

        result = measure_sycophancy(
            prompt="What is the capital of France?",
            correct_answer="Paris",
            incorrect_answer="London",
            model="test",
            num_samples=3,
        )

        assert result.correct_framing_confidence == pytest.approx(0.9)
        assert result.incorrect_framing_confidence == pytest.approx(0.85)
        assert result.sycophancy_score == pytest.approx(0.85)

    @patch("yuragi.analysis.adversarial.LLMAdapter")
    def test_resistant_model(self, mock_adapter):
        # Model is confident with correct framing, low confidence with wrong
        adapter = _mock_adapter(
            _completion(0.9, "Yes, Paris is the answer"),   # correct
            _completion(0.2, "No, London is not correct"),  # incorrect
        )
        mock_adapter.return_value = adapter

        result = measure_sycophancy(
            prompt="What is the capital of France?",
            correct_answer="Paris",
            incorrect_answer="London",
            model="test",
            num_samples=3,
        )

        assert result.sycophancy_score == pytest.approx(0.2)
        assert result.confidence_swing == pytest.approx(0.2 - 0.9)

    @patch("yuragi.analysis.adversarial.LLMAdapter")
    def test_sycophancy_score_bounded(self, mock_adapter):
        adapter = _mock_adapter(
            _completion(1.1, "answer"),  # clipped to 1.0 by LLMAdapter
            _completion(1.2, "answer"),
        )
        mock_adapter.return_value = adapter

        result = measure_sycophancy(
            "q", "correct", "wrong", model="test", num_samples=3
        )
        assert 0.0 <= result.sycophancy_score <= 1.0


# ---------------------------------------------------------------------------
# measure_pressure_resistance — integration with mocked adapter
# ---------------------------------------------------------------------------


@pytest.mark.integration
class TestMeasurePressureResistance:
    @patch("yuragi.analysis.adversarial.LLMAdapter")
    def test_five_levels_returned(self, mock_adapter):
        adapter = _mock_adapter(
            _completion(0.9, "Paris"),
            _completion(0.8, "Paris"),
            _completion(0.7, "Paris"),
            _completion(0.6, "Paris"),
            _completion(0.5, "Paris"),
        )
        mock_adapter.return_value = adapter

        result = measure_pressure_resistance(
            "What is the capital of France?", model="test", num_samples=3
        )

        assert len(result.levels) == 5
        assert result.levels[0].level == 0
        assert result.levels[4].level == 4

    @patch("yuragi.analysis.adversarial.LLMAdapter")
    def test_resistance_score_monotone_drop(self, mock_adapter):
        adapter = _mock_adapter(
            _completion(0.9, "Paris"),
            _completion(0.7, "Paris"),
            _completion(0.5, "Paris"),
            _completion(0.3, "Paris"),
            _completion(0.2, "Paris"),
        )
        mock_adapter.return_value = adapter

        result = measure_pressure_resistance(
            "What is the capital of France?", model="test", num_samples=3
        )

        assert result.total_drop == pytest.approx(0.9 - 0.2)
        assert 0.0 <= result.resistance_score <= 1.0

    @patch("yuragi.analysis.adversarial.LLMAdapter")
    def test_level_prompt_includes_pressure_phrase(self, mock_adapter):
        # Verify level-1 prompt starts with pressure phrase
        adapter = _mock_adapter(
            _completion(0.9, "Paris"),
            _completion(0.85, "Paris"),
            _completion(0.8, "Paris"),
            _completion(0.75, "Paris"),
            _completion(0.7, "Paris"),
        )
        mock_adapter.return_value = adapter

        result = measure_pressure_resistance("Q?", model="test", num_samples=3)

        assert result.levels[0].prompt == "Q?"
        assert "sure" in result.levels[1].prompt.lower()

    @patch("yuragi.analysis.adversarial.LLMAdapter")
    def test_model_attribute_stored(self, mock_adapter):
        adapter = _mock_adapter(*[_completion(0.8, "p")] * 5)
        mock_adapter.return_value = adapter

        result = measure_pressure_resistance("q", model="my-model", num_samples=3)
        assert result.model == "my-model"


# ---------------------------------------------------------------------------
# AdversarialSuite — smoke tests
# ---------------------------------------------------------------------------


@pytest.mark.integration
class TestAdversarialSuite:
    @patch("yuragi.analysis.adversarial.LLMAdapter")
    def test_run_pressure_returns_result(self, mock_adapter):
        adapter = _mock_adapter(*[_completion(0.8, "Paris")] * 5)
        mock_adapter.return_value = adapter

        suite = AdversarialSuite(model="test", num_samples=3)
        result = suite.run_pressure("What is the capital of France?")

        assert isinstance(result, PressureResistanceResult)
        assert len(result.levels) == 5

    @patch("yuragi.analysis.adversarial.LLMAdapter")
    def test_run_sycophancy_returns_result(self, mock_adapter):
        adapter = _mock_adapter(
            _completion(0.9, "Paris"),
            _completion(0.6, "London"),
        )
        mock_adapter.return_value = adapter

        suite = AdversarialSuite(model="test", num_samples=3)
        result = suite.run_sycophancy(
            "What is the capital of France?", "Paris", "London"
        )

        assert isinstance(result, SycophancyResult)

    @patch("yuragi.analysis.adversarial.LLMAdapter")
    def test_run_flip_returns_result(self, mock_adapter):
        # "What capital France" = 3 words → 1 baseline + 3 omissions = 4 completions
        adapter = _mock_adapter(
            _completion(0.9, "Paris"),
            _completion(0.8, "Paris"),
            _completion(0.7, "Paris"),
            _completion(0.3, "Berlin"),
        )
        mock_adapter.return_value = adapter

        suite = AdversarialSuite(model="test", num_samples=3)
        result = suite.run_flip("What capital France")

        assert isinstance(result, ConfidenceFlipResult)
