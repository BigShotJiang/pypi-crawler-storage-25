"""Centralized configuration for all yuragi thresholds and tuning parameters.

Every magic number in the codebase lives here.  Users can override any value
by constructing a custom ``YuragiConfig`` and passing it to the relevant API.

    from yuragi.config import YuragiConfig

    cfg = YuragiConfig(dissociation_scaling_factor=5.0)
    result = Scanner(model="ollama/llama3.2", config=cfg).scan("...")

When no config is supplied, ``DEFAULT_CONFIG`` (all defaults) is used.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class YuragiConfig:
    """All tunable thresholds and coefficients used across yuragi.

    Frozen so instances are hashable and safe to share across threads.
    """

    # ---- Dissociation (core.py) ----
    # Minimum answer similarity to consider "same answer"
    dissociation_similarity_threshold: float = 0.6
    # Confidence delta below this is treated as noise
    dissociation_noise_floor: float = 0.06
    # Scaling factor: severity = similarity * |delta| * this
    dissociation_scaling_factor: float = 3.0

    # ---- Fragility score (core.py) ----
    # Std-dev at which fragility saturates to 1.0
    fragility_normalization_std: float = 0.3

    # ---- Fragility profile (fragility_profile.py) ----
    # Confidence-per-character at which CCI = 1.0
    cci_normalization: float = 0.05
    # Minimum |delta| to count as a meaningful drop/boost
    recovery_threshold: float = 0.05
    # Std-dev-of-efficiency at which NLS = 1.0
    nls_normalization: float = 0.03

    # ---- Volatility (metrics/volatility.py) ----
    vix_baseline_mean: float = 0.15
    vix_baseline_std: float = 0.10
    regime_stable: float = 0.10
    regime_transitional: float = 0.30
    regime_volatile: float = 0.50

    # ---- Statistics (analysis/statistics.py) ----
    cohens_d_small: float = 0.2
    cohens_d_medium: float = 0.5
    cohens_d_large: float = 0.8

    # ---- Adapter (providers/adapter.py) ----
    # Entropy value at which logprob confidence = 0.0
    entropy_max: float = 3.0

    # ---- Linguistics (analysis/linguistics.py) ----
    hedge_penalty_multiplier: float = 80.0
    hedge_penalty_cap: float = 0.45
    assertion_boost_multiplier: float = 60.0
    assertion_boost_cap: float = 0.35
    linguistic_gap_threshold: float = 0.15

    # ---- Phase transition (analysis/phase_transition.py) ----
    phase_sharpness_threshold: float = 0.05
    phase_transition_delta_min: float = 0.02
    phase_band_width: float = 0.15

    # ---- CLI defaults ----
    default_model: str = "ollama/llama3.2"

    # ---- Reproducibility ----
    seed: int | None = None

    # ---- Trilayer thresholds ----
    trilayer_internal_conflict_threshold: float = 0.2

    # ---- Trajectory thresholds ----
    trajectory_decline_threshold: float = -0.1
    trajectory_recovery_threshold: float = 0.05
    trajectory_volatility_threshold: float = 0.1

    # ---- Decay grid ----
    decay_grid_min: float = 0.01
    decay_grid_max: float = 5.0
    decay_grid_steps: int = 200

    # ---- Recovery ----
    recovery_baseline_ratio: float = 0.9

    # ---- Adversarial ----
    adversarial_sycophancy_threshold: float = 0.2
    adversarial_severe_threshold: float = 0.0

    # ---- Minimal edit ----
    minimal_edit_significance_threshold: float = -0.05

    # ---- Calibration ----
    calibration_n_bins: int = 10

    # ---- Fragility labels (4 boundaries → 5 labels) ----
    fragility_label_boundaries: tuple[float, ...] = (0.1, 0.25, 0.5, 0.75)

    # ---- Bootstrap ----
    bootstrap_iterations: int = 1000


DEFAULT_CONFIG = YuragiConfig()
