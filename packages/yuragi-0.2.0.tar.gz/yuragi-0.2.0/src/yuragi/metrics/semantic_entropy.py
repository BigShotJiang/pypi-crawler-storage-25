"""Semantic Entropy — inspired by Farquhar et al., *Nature* 2024.

This module implements a **two-path** semantic-entropy estimator:

1. **Embedding path** (requires ``yuragi[semantic]`` with
   ``sentence-transformers``): when the caller passes ``embedding_model``
   (e.g., ``"all-MiniLM-L6-v2"``), generations are clustered by cosine
   similarity over sentence-transformer embeddings. This path is the
   **closest approximation** of the method described in Farquhar et al.
   (Nature 2024) that yuragi supports, given that the original paper
   uses a natural-language inference (NLI) model for semantic
   equivalence clustering.
2. **Lightweight fallback path** (default, zero-dependency): when
   ``embedding_model`` is ``None``, clustering uses character-3-gram
   Jaccard similarity from :mod:`yuragi.utils`. This is **intentionally
   not** Farquhar's method — it is a fast offline approximation for
   CI / smoke tests / APU-only users. Papers reproducing the Farquhar
   2024 result should always pass ``embedding_model="all-MiniLM-L6-v2"``
   or another sentence-transformer model and install the optional
   dependency.

The module docstring cites Farquhar 2024 because the *entropy
formulation* (Shannon entropy over semantic clusters) is theirs; the
Jaccard fallback substitutes the clustering primitive and should not
be reported as "Semantic Entropy (Farquhar 2024)" in empirical claims
without disclosing the substitution.
"""
from __future__ import annotations

import math
from collections.abc import Sequence

try:
    from sentence_transformers import SentenceTransformer
except ImportError:
    SentenceTransformer = None  # type: ignore[assignment,misc]

from yuragi.utils import text_similarity


def semantic_entropy(
    samples: Sequence[str],
    *,
    similarity_threshold: float = 0.85,
    embedding_model: str | None = None,
) -> float:
    """Compute semantic entropy from a list of generated samples.

    Args:
        samples: Multiple generations from the same prompt.
        similarity_threshold: Cosine / Jaccard similarity threshold for
            clustering (default 0.85).
        embedding_model: sentence-transformers model name. If provided,
            uses embedding-based clustering (close to Farquhar 2024).
            If ``None`` (default), falls back to character-3-gram
            Jaccard similarity — an intentional offline approximation,
            **not** the published Farquhar 2024 method. Empirical
            claims citing Farquhar 2024 should always pass an
            ``embedding_model``.

    Returns:
        Semantic entropy in nats (natural log base).
    """
    if not samples:
        return 0.0
    clusters = _cluster_by_meaning(list(samples), similarity_threshold, embedding_model)
    n = len(samples)
    return -sum((len(c) / n) * math.log(len(c) / n) for c in clusters)


def _cluster_by_meaning(
    samples: list[str],
    threshold: float,
    embedding_model: str | None,
) -> list[list[str]]:
    """Cluster samples by semantic equivalence.

    If sentence-transformers is available and embedding_model is specified,
    uses cosine similarity in embedding space. Otherwise falls back to 3-gram
    Jaccard from yuragi.utils.
    """
    if embedding_model is not None and SentenceTransformer is not None:
        return _cluster_with_embeddings(samples, threshold, embedding_model)
    return _cluster_with_jaccard(samples, threshold)


def _cluster_with_jaccard(samples: list[str], threshold: float) -> list[list[str]]:
    """Greedy single-linkage clustering using 3-gram Jaccard similarity."""
    clusters: list[list[str]] = []
    for sample in samples:
        placed = False
        for cluster in clusters:
            if text_similarity(sample, cluster[0]) >= threshold:
                cluster.append(sample)
                placed = True
                break
        if not placed:
            clusters.append([sample])
    return clusters


def _cluster_with_embeddings(
    samples: list[str],
    threshold: float,
    model_name: str,
) -> list[list[str]]:
    """Greedy single-linkage clustering using cosine similarity in embedding space."""
    import numpy as np

    model = SentenceTransformer(model_name)
    embeddings = model.encode(samples, normalize_embeddings=True)

    clusters: list[list[str]] = []
    cluster_reps: list[int] = []

    for i, sample in enumerate(samples):
        placed = False
        for j, rep_idx in enumerate(cluster_reps):
            sim = float(np.dot(embeddings[i], embeddings[rep_idx]))
            if sim >= threshold:
                clusters[j].append(sample)
                placed = True
                break
        if not placed:
            clusters.append([sample])
            cluster_reps.append(i)

    return clusters
