"""Verbalized vs Logit confidence gap.

Measures the dissociation between a model's stated confidence and its
internal token probabilities. This provides quantitative evidence for
the Confidence Dissociation phenomenon yuragi defines.

References:
    - "Closing the Confidence-Faithfulness Gap in LLMs" (arXiv:2603.25052)
    - "Are LLM Decisions Faithful to Verbal Confidence?" (arXiv:2601.07767)
    - ACL 2024 "An Investigation into the Confidence-Probability Alignment"
"""
from __future__ import annotations

import math
import statistics
from collections.abc import Sequence


def verbalized_logit_gap(
    verbalized_confidence: float,
    token_logprobs: Sequence[float],
    *,
    aggregation: str = "mean",
) -> float:
    """Compute the gap between verbalized and logit-derived confidence.

    Args:
        verbalized_confidence: Model's stated confidence in [0, 1].
        token_logprobs: Per-token log probabilities from the response.
        aggregation: How to aggregate token logprobs. One of:
            - "mean": geometric mean (exp of mean logprob)
            - "min": minimum probability (worst-case)
            - "first_token": first token only

    Returns:
        Signed gap = verbalized - internal. Positive means overconfident.
    """
    if not token_logprobs:
        return 0.0
    lp_list = list(token_logprobs)
    if aggregation == "mean":
        internal = math.exp(sum(lp_list) / len(lp_list))
    elif aggregation == "min":
        internal = math.exp(min(lp_list))
    elif aggregation == "first_token":
        internal = math.exp(lp_list[0])
    else:
        raise ValueError(f"Unknown aggregation: {aggregation}")
    return verbalized_confidence - internal


def dissociation_score(
    verbalized_confidences: Sequence[float],
    token_logprobs_list: Sequence[Sequence[float]],
) -> dict:
    """Compute aggregate dissociation statistics over multiple samples.

    Args:
        verbalized_confidences: Sequence of model-stated confidences in [0, 1].
        token_logprobs_list: Sequence of per-token logprob sequences.

    Returns:
        Dict with mean_gap, median_gap, max_gap, std_gap,
        overconfidence_ratio, n_samples.
    """
    v_list = list(verbalized_confidences)
    lp_seqs = list(token_logprobs_list)
    if len(v_list) != len(lp_seqs):
        raise ValueError(
            "verbalized_confidences and token_logprobs_list must have the same length"
        )
    gaps = [verbalized_logit_gap(v, lp) for v, lp in zip(v_list, lp_seqs)]
    if not gaps:
        return {
            "mean_gap": 0.0,
            "median_gap": 0.0,
            "max_gap": 0.0,
            "std_gap": 0.0,
            "overconfidence_ratio": 0.0,
            "n_samples": 0,
        }
    return {
        "mean_gap": statistics.fmean(gaps),
        "median_gap": statistics.median(gaps),
        "max_gap": max(gaps),
        "std_gap": statistics.pstdev(gaps) if len(gaps) >= 2 else 0.0,
        "overconfidence_ratio": sum(1 for g in gaps if g > 0.1) / len(gaps),
        "n_samples": len(gaps),
    }
