"""Unified LLM adapter with automatic capability detection.

Supports three confidence measurement modes:
1. logprobs (GPT-4o, local models via ollama) — most accurate
2. multi-sample (all models) — measure variance across N responses
3. verbalized (all models) — ask the model to self-report confidence
"""

from __future__ import annotations

import logging
import math
import re
import statistics
from dataclasses import dataclass
from typing import TYPE_CHECKING, ClassVar

if TYPE_CHECKING:
    from yuragi.cache import ResponseCache

from yuragi.config import DEFAULT_CONFIG, YuragiConfig
from yuragi.utils import text_similarity as _text_similarity_fn

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Lazy litellm loader (v0.3.0 cold-start optimisation)
# ---------------------------------------------------------------------------
# ``import litellm`` is expensive (~2 seconds on cold start) because it
# eagerly pulls every provider (vertex_ai, anthropic, google_genai, ...).
# We postpone the import until the first LLM call so that
# ``from yuragi import Scanner`` / ``yuragi --help`` stay fast.
#
# Backwards-compat notes:
#   * ``_get_litellm()`` returns the module (importing on first call, caching
#     thereafter). It first consults ``globals().get("litellm")`` so tests
#     that ``monkeypatch.setattr(adapter_mod, "litellm", fake)`` keep working.
#   * ``_has_litellm()`` is the lazy equivalent of the old ``HAS_LITELLM``
#     module flag.
#   * A module-level ``__getattr__`` (PEP 562) exposes the names ``litellm``
#     and ``HAS_LITELLM`` lazily for any caller (including ``unittest.mock``)
#     that still looks them up as module attributes.

_litellm_cached: object | None = None
_litellm_probe_done: bool = False
_litellm_probe_result: bool = False


def _get_litellm():
    """Return the litellm module, importing it on first call.

    Raises ``MissingDependencyError`` if litellm is not installed. A
    monkey-patched ``litellm`` attribute on this module takes precedence
    so tests that inject a fake module keep working.
    """
    # Monkey-patched value always wins (test fake).
    mp = globals().get("litellm")
    if mp is not None and mp is not _MARKER:
        return mp

    global _litellm_cached, _litellm_probe_done, _litellm_probe_result
    if _litellm_cached is not None:
        return _litellm_cached
    try:
        import litellm as _lt  # heavy, one-shot

        _lt.suppress_debug_info = True
        _lt.set_verbose = False
        _lt.drop_params = True
        _litellm_cached = _lt
        _litellm_probe_done = True
        _litellm_probe_result = True
        return _lt
    except ImportError as err:
        _litellm_probe_done = True
        _litellm_probe_result = False
        from yuragi.exceptions import MissingDependencyError

        raise MissingDependencyError(
            "litellm is required. Install with: pip install yuragi"
        ) from err


def _has_litellm() -> bool:
    """True if litellm can be imported. Cached after first probe."""
    mp = globals().get("litellm")
    if mp is not None and mp is not _MARKER:
        return True
    global _litellm_probe_done, _litellm_probe_result
    if _litellm_probe_done:
        return _litellm_probe_result
    try:
        _get_litellm()
    except Exception:
        return False
    return _litellm_probe_result


# Sentinel so ``globals().get("litellm")`` can distinguish "not yet set" from
# "explicitly set to None by a test".
_MARKER = object()


def __getattr__(name: str):  # PEP 562
    """Expose ``litellm`` and ``HAS_LITELLM`` as lazy module attributes.

    Only triggered when the attribute is *not* already in ``globals()``.
    Tests that ``monkeypatch.setattr`` these names add a real entry to the
    module dict, which shadows this function per PEP 562 and the old test
    code keeps working unchanged.
    """
    if name == "litellm":
        return _get_litellm()
    if name == "HAS_LITELLM":
        return _has_litellm()
    raise AttributeError(f"module 'yuragi.providers.adapter' has no attribute {name!r}")


@dataclass
class ModelCapabilities:
    """What a model can do for confidence measurement."""

    supports_logprobs: bool = False
    supports_temperature: bool = True
    max_logprobs: int = 5
    provider: str = "unknown"


@dataclass
class CompletionResult:
    """A single LLM completion with confidence metadata."""

    text: str
    confidence: float  # 0.0 to 1.0
    confidence_method: str  # "logprob", "sampling", "verbalized"
    logprob_entropy: float | None = None
    raw_logprobs: list | None = None
    token_count: int = 0

    def to_json(self) -> dict:
        """Serialize to a JSON-safe dict.

        Converts ``raw_logprobs`` tuples to lists so that json.dumps
        round-trips cleanly.  Use ``from_json`` to restore.
        """
        raw = self.raw_logprobs
        if raw is not None:
            raw = [[list(pair) for pair in token_probs] for token_probs in raw]
        return {
            "text": self.text,
            "confidence": self.confidence,
            "confidence_method": self.confidence_method,
            "logprob_entropy": self.logprob_entropy,
            "raw_logprobs": raw,
            "token_count": self.token_count,
        }

    @classmethod
    def from_json(cls, data: dict) -> CompletionResult:
        """Deserialize from a dict produced by ``to_json``.

        Restores ``raw_logprobs`` inner pairs as tuples.
        """
        raw = data.get("raw_logprobs")
        if raw is not None:
            raw = [[tuple(pair) for pair in token_probs] for token_probs in raw]
        return cls(
            text=data["text"],
            confidence=data["confidence"],
            confidence_method=data["confidence_method"],
            logprob_entropy=data.get("logprob_entropy"),
            raw_logprobs=raw,
            token_count=data.get("token_count", 0),
        )


# Models known to support logprobs
_LOGPROB_MODELS = {
    "gpt-4o",
    "gpt-4o-mini",
    "gpt-4-turbo",
    "gpt-4",
    "gpt-3.5-turbo",
    "o1",
    "o1-mini",
    "o3-mini",
}

# Prefixes for providers that support logprobs on local models
_LOGPROB_PREFIXES = ("ollama/", "ollama_chat/", "huggingface/", "vllm/")


def detect_capabilities(model: str) -> ModelCapabilities:
    """Detect what confidence measurement methods a model supports."""
    model_lower = model.lower()

    # OpenAI models
    for m in _LOGPROB_MODELS:
        if m in model_lower:
            return ModelCapabilities(
                supports_logprobs=True, max_logprobs=20, provider="openai"
            )

    # Local model providers via ollama
    # Note: ollama supports logprobs natively but litellm blocks the param.
    # Use sampling mode for reliability. For logprobs, use ollama API directly.
    if any(model_lower.startswith(p) for p in _LOGPROB_PREFIXES):
        return ModelCapabilities(
            supports_logprobs=False, max_logprobs=10, provider="local"
        )

    # Anthropic — logprobs added Feb 2026, but litellm support may vary.
    # Default to sampling for reliability; set supports_logprobs=True to try.
    if "claude" in model_lower or model_lower.startswith("anthropic/"):
        return ModelCapabilities(
            supports_logprobs=False, provider="anthropic"
        )

    # Google
    if "gemini" in model_lower or model_lower.startswith("google/"):
        return ModelCapabilities(
            supports_logprobs=False, provider="google"
        )

    # Default: assume no logprobs
    return ModelCapabilities(supports_logprobs=False, provider="unknown")


class LLMAdapter:
    """Unified interface for querying LLMs with confidence measurement.

    Can be used as a context manager for automatic resource cleanup::

        with LLMAdapter(model="gpt-4o-mini") as adapter:
            result = adapter.complete("Hello")
    """

    def __init__(
        self,
        model: str,
        api_key: str | None = None,
        num_samples: int = 5,
        temperature: float = 0.7,
        max_tokens: int = 300,
        timeout: float = 300.0,
        use_cache: bool = True,
        parallel: int = 1,
        cache: ResponseCache | None = None,
        config: YuragiConfig | None = None,
    ):
        self.model = model
        self.api_key = api_key
        self.num_samples = num_samples
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.timeout = timeout
        self.use_cache = use_cache
        self.parallel = parallel
        self.capabilities = detect_capabilities(model)
        self.config = config or DEFAULT_CONFIG

        # Validate litellm availability (lazy import; sets drop_params=True
        # inside _get_litellm on first call).
        _get_litellm()

        # Cache setup
        if use_cache and cache is None:
            from yuragi.cache import ResponseCache

            self._cache: ResponseCache | None = ResponseCache()
        else:
            self._cache = cache if use_cache else None

    def __enter__(self) -> LLMAdapter:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def close(self) -> None:
        """Close the response cache (if owned by this adapter)."""
        if self._cache is not None:
            self._cache.close()
            self._cache = None

    async def acomplete(
        self, prompt: str, system: str | None = None, retries: int = 2
    ) -> CompletionResult:
        """Async version of complete() with the same retry and cache logic.

        Uses litellm.acompletion internally.  Retry/backoff mirrors complete().
        Cache lookup and write are performed just like the sync path.
        """
        import asyncio as _asyncio

        # Cache lookup
        if self._cache is not None:
            cached = self._cache.get(self.model, prompt, self.temperature, self.num_samples, system)
            if cached is not None:
                return cached

        messages: list[dict] = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        _ll = _get_litellm()
        # Hoist the exception tuple once per call instead of per-attempt so
        # the retry loop stays O(1) rather than re-building it each time.
        retryable_excs: tuple = (
            _ll.RateLimitError,
            _ll.Timeout,
            _ll.APIConnectionError,
        )
        last_error: Exception | None = None
        for attempt in range(retries + 1):
            try:
                logger.debug(
                    "async API call start model=%s method=%s attempt=%d",
                    self.model,
                    "logprobs" if self.capabilities.supports_logprobs else "sampling",
                    attempt,
                )
                if self.capabilities.supports_logprobs:
                    response = await _ll.acompletion(
                        model=self.model,
                        messages=messages,
                        temperature=0.0,
                        max_tokens=self.max_tokens,
                        timeout=self.timeout,
                        logprobs=True,
                        top_logprobs=self.capabilities.max_logprobs,
                        api_key=self.api_key,
                    )
                    text = response.choices[0].message.content or ""
                    logprobs_data = self._extract_logprobs(response)
                    if logprobs_data:
                        entropy = self._calculate_entropy(logprobs_data)
                        confidence = max(
                            0.0, min(1.0, 1.0 - (entropy / self.config.entropy_max))
                        )
                    else:
                        entropy = None
                        confidence = 0.5
                    result = CompletionResult(
                        text=text,
                        confidence=confidence,
                        confidence_method="logprob",
                        logprob_entropy=entropy if logprobs_data else None,
                        raw_logprobs=logprobs_data if logprobs_data else None,
                        token_count=response.usage.total_tokens if response.usage else 0,
                    )
                else:
                    # sampling mode: gather num_samples async calls
                    sample_tasks = [
                        _ll.acompletion(
                            model=self.model,
                            messages=messages,
                            temperature=self.temperature,
                            max_tokens=self.max_tokens,
                            timeout=self.timeout,
                            api_key=self.api_key,
                        )
                        for _ in range(self.num_samples)
                    ]
                    responses = await _asyncio.gather(*sample_tasks, return_exceptions=True)
                    texts: list[str] = []
                    total_tokens = 0
                    for r in responses:
                        if isinstance(r, Exception):
                            logger.debug("Async sample failed: %s", r)
                            continue
                        texts.append(r.choices[0].message.content or "")
                        if r.usage:
                            total_tokens += r.usage.total_tokens
                    if not texts:
                        from yuragi.exceptions import ScanError
                        raise ScanError(
                            f"All {self.num_samples} async sampling attempts failed for model={self.model}"
                        )
                    confidence = self._measure_agreement(texts)
                    result = CompletionResult(
                        text=texts[0],
                        confidence=confidence,
                        confidence_method="sampling",
                        token_count=total_tokens,
                    )

                logger.debug(
                    "async API call done model=%s confidence=%.3f method=%s",
                    self.model,
                    result.confidence,
                    result.confidence_method,
                )
                if self._cache is not None:
                    self._cache.set(
                        self.model, prompt, self.temperature, self.num_samples, result, system
                    )
                return result

            except (KeyboardInterrupt, SystemExit):
                raise
            except Exception as e:
                last_error = e
                retryable = isinstance(e, retryable_excs)
                if not retryable:
                    error_str = str(e).lower()
                    retryable = any(
                        k in error_str
                        for k in ("rate_limit", "rate limit", "timeout", "429", "503")
                    )
                if retryable:
                    wait = min(2 ** attempt * 2, 30)
                    logger.warning(
                        "Async retryable error (attempt %d/%d): %s",
                        attempt + 1,
                        retries + 1,
                        e,
                    )
                    await _asyncio.sleep(wait)
                    continue
                raise
        if last_error is not None:
            raise last_error
        raise RuntimeError("Async retry loop exited without result or error")

    def complete(
        self, prompt: str, system: str | None = None, retries: int = 2
    ) -> CompletionResult:
        """Get a completion with confidence score.

        Automatically selects the best measurement method available.
        Retries on transient errors (rate limits, timeouts).
        Cache lookup is performed before making any API call.
        """
        import time as _time

        # Cache lookup — the sync path previously forgot to pass ``system``
        # which made two calls with different system prompts collapse onto
        # the same cache entry. See Round 10 debugger C-1.
        if self._cache is not None:
            cached = self._cache.get(
                self.model, prompt, self.temperature, self.num_samples, system
            )
            if cached is not None:
                return cached

        _ll = _get_litellm()
        retryable_excs: tuple = (
            _ll.RateLimitError,
            _ll.Timeout,
            _ll.APIConnectionError,
        )
        last_error = None
        for attempt in range(retries + 1):
            try:
                logger.debug("API call start model=%s method=%s attempt=%d", self.model, "logprobs" if self.capabilities.supports_logprobs else "sampling", attempt)
                if self.capabilities.supports_logprobs:
                    result = self._complete_with_logprobs(prompt, system)
                else:
                    result = self._complete_with_sampling(prompt, system)
                logger.debug("API call done model=%s confidence=%.3f method=%s", self.model, result.confidence, result.confidence_method)
                if self._cache is not None:
                    self._cache.set(
                        self.model, prompt, self.temperature, self.num_samples, result, system
                    )
                return result
            except (KeyboardInterrupt, SystemExit):
                raise
            except Exception as e:
                last_error = e
                # Retry on litellm Exception hierarchy first, fall back to string match
                retryable = isinstance(e, retryable_excs)
                if not retryable:
                    error_str = str(e).lower()
                    retryable = any(
                        k in error_str for k in ("rate_limit", "rate limit", "timeout", "429", "503")
                    )
                if retryable:
                    wait = min(2 ** attempt * 2, 30)  # Exponential backoff, max 30s
                    logger.warning("Retryable error (attempt %d/%d): %s", attempt + 1, retries + 1, e)
                    _time.sleep(wait)
                    continue
                raise  # Non-retryable error
        if last_error is not None:
            raise last_error
        raise RuntimeError("Retry loop exited without result or error")

    def complete_verbalized(
        self, prompt: str, system: str | None = None
    ) -> CompletionResult:
        """Get completion with self-reported confidence (0-100)."""
        confidence_prompt = (
            f"{prompt}\n\n"
            "After your answer, on a new line write exactly "
            '"CONFIDENCE: X" where X is your confidence level from 0 to 100.'
        )

        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": confidence_prompt})

        response = _get_litellm().completion(
            model=self.model,
            messages=messages,
            temperature=0.0,  # Deterministic for verbalized
            max_tokens=self.max_tokens + 50,  # Extra for CONFIDENCE: line
            timeout=self.timeout,
            api_key=self.api_key,
        )

        text = response.choices[0].message.content or ""
        confidence, clean_text = self._parse_verbalized_confidence(text)

        return CompletionResult(
            text=clean_text,
            confidence=confidence,
            confidence_method="verbalized",
            token_count=response.usage.total_tokens if response.usage else 0,
        )

    def _complete_with_logprobs(
        self, prompt: str, system: str | None = None
    ) -> CompletionResult:
        """Measure confidence via token probability distribution entropy."""
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        response = _get_litellm().completion(
            model=self.model,
            messages=messages,
            temperature=0.0,
            max_tokens=self.max_tokens,
            timeout=self.timeout,
            logprobs=True,
            top_logprobs=self.capabilities.max_logprobs,
            api_key=self.api_key,
        )

        text = response.choices[0].message.content or ""
        logprobs_data = self._extract_logprobs(response)

        if logprobs_data:
            entropy = self._calculate_entropy(logprobs_data)
            # Convert entropy to confidence: low entropy = high confidence
            confidence = max(0.0, min(1.0, 1.0 - (entropy / self.config.entropy_max)))
        else:
            # Fallback to sampling if logprobs extraction fails
            return self._complete_with_sampling(prompt, system)

        return CompletionResult(
            text=text,
            confidence=confidence,
            confidence_method="logprob",
            logprob_entropy=entropy,
            raw_logprobs=logprobs_data,
            token_count=response.usage.total_tokens if response.usage else 0,
        )

    def _complete_with_sampling(
        self, prompt: str, system: str | None = None
    ) -> CompletionResult:
        """Measure confidence via multi-sample agreement."""
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        responses = []
        total_tokens = 0
        _ll = _get_litellm()

        for sample_idx in range(self.num_samples):
            try:
                response = _ll.completion(
                    model=self.model,
                    messages=messages,
                    temperature=self.temperature,
                    max_tokens=self.max_tokens,
                    timeout=self.timeout,
                    api_key=self.api_key,
                )
                text = response.choices[0].message.content or ""
                responses.append(text)
                if response.usage:
                    total_tokens += response.usage.total_tokens
            except (KeyboardInterrupt, SystemExit):
                raise
            except Exception as e:
                logger.debug("Sample %d/%d failed: %s", sample_idx + 1, self.num_samples, e)
                continue  # Skip failed samples, use what we have

        if not responses:
            from yuragi.exceptions import ScanError

            raise ScanError(
                f"All {self.num_samples} sampling attempts failed for model={self.model}"
            )

        # Measure agreement: how similar are the responses?
        confidence = self._measure_agreement(responses)

        return CompletionResult(
            text=responses[0],  # Use first response as canonical
            confidence=confidence,
            confidence_method="sampling",
            token_count=total_tokens,
        )

    def _extract_logprobs(self, response) -> list[list[tuple[str, float]]]:
        """Extract logprobs from litellm response."""
        try:
            choice = response.choices[0]
            if not hasattr(choice, "logprobs") or choice.logprobs is None:
                return []
            content = choice.logprobs.content
            if not content:
                return []
            result = []
            for token_info in content:
                top = []
                if hasattr(token_info, "top_logprobs") and token_info.top_logprobs:
                    for entry in token_info.top_logprobs:
                        top.append((entry.token, entry.logprob))
                result.append(top)
            return result
        except (AttributeError, IndexError, TypeError):
            return []

    def _calculate_entropy(
        self, logprobs_data: list[list[tuple[str, float]]]
    ) -> float:
        """Calculate average entropy across all tokens."""
        if not logprobs_data:
            return 0.0

        entropies = []
        for token_probs in logprobs_data:
            if not token_probs:
                continue
            # Convert logprobs to probabilities
            probs = [math.exp(lp) for _, lp in token_probs]
            # Normalize
            total = sum(probs)
            if total <= 0:
                continue
            probs = [p / total for p in probs]
            # Shannon entropy
            entropy = -sum(p * math.log2(p) for p in probs if p > 0)
            entropies.append(entropy)

        return statistics.mean(entropies) if entropies else 0.0

    def _measure_agreement(self, responses: list[str]) -> float:
        """Measure confidence as agreement ratio among multiple responses.

        Uses character-level similarity (simple but effective).
        Higher agreement = higher confidence.
        """
        if len(responses) <= 1:
            return 0.5  # Unknown

        n = len(responses)
        similarities = []

        for i in range(n):
            for j in range(i + 1, n):
                sim = self._text_similarity(responses[i], responses[j])
                similarities.append(sim)

        return statistics.mean(similarities) if similarities else 0.5

    @staticmethod
    def _text_similarity(a: str, b: str) -> float:
        """Character 3-gram Jaccard similarity (language-agnostic, works for CJK)."""
        return _text_similarity_fn(a, b)

    @staticmethod
    def _parse_verbalized_confidence(text: str) -> tuple[float, str]:
        """Parse 'CONFIDENCE: X' from response text."""
        match = re.search(r"CONFIDENCE:\s*(\d+(?:\.\d+)?)", text, re.IGNORECASE)
        if match:
            raw = float(match.group(1))
            confidence = max(0.0, min(1.0, raw / 100.0))
            clean = text[: match.start()].rstrip()
            return confidence, clean
        return 0.5, text  # Default if parsing fails


# ---------------------------------------------------------------------------
# ConfidenceEstimator
# ---------------------------------------------------------------------------


class ConfidenceEstimator:
    """Pluggable confidence estimation strategies.

    Each method returns a float in [0.0, 1.0].  Methods can be composed via
    ``estimate_hybrid`` which merges all available signals with a weighted
    average.
    """

    # Weight for each source when all three are present.
    # logprob is most accurate; sampling is reliable; verbalized is noisiest.
    _DEFAULT_WEIGHTS: ClassVar[dict[str, float]] = {
        "logprob": 0.5,
        "sampling": 0.35,
        "verbalized": 0.15,
    }

    def estimate_logprob(self, response: CompletionResult) -> float:
        """Return the confidence already extracted from logprobs.

        If the result was not produced with logprob measurement, returns 0.5
        (neutral, unknown) rather than raising.
        """
        if response.confidence_method == "logprob":
            return max(0.0, min(1.0, response.confidence))
        return 0.5

    def estimate_sampling(self, responses: list[CompletionResult]) -> float:
        """Estimate confidence from agreement across multiple sampled responses.

        Uses character 3-gram Jaccard similarity — same algorithm as
        ``LLMAdapter._text_similarity`` so results are consistent.

        Args:
            responses: Two or more CompletionResults generated at temperature > 0.

        Returns:
            Mean pairwise similarity in [0.0, 1.0]; 0.5 if fewer than 2 responses.
        """
        texts = [r.text for r in responses if r.text]
        if len(texts) < 2:
            return 0.5

        def _ngrams(text: str, n: int = 3) -> set[str]:
            text = text.lower()
            if len(text) < n:
                return {text} if text else set()
            return {text[i : i + n] for i in range(len(text) - n + 1)}

        def _jaccard(a: str, b: str) -> float:
            ng_a, ng_b = _ngrams(a), _ngrams(b)
            if not ng_a and not ng_b:
                return 1.0
            union = ng_a | ng_b
            return len(ng_a & ng_b) / len(union) if union else 0.0

        similarities = [
            _jaccard(texts[i], texts[j])
            for i in range(len(texts))
            for j in range(i + 1, len(texts))
        ]
        return statistics.mean(similarities)

    def estimate_verbalized(self, response: CompletionResult) -> float:
        """Return the verbalized confidence stored in the CompletionResult.

        If the result was not produced with verbalized measurement, returns 0.5.
        """
        if response.confidence_method == "verbalized":
            return max(0.0, min(1.0, response.confidence))
        return 0.5

    def estimate_hybrid(
        self,
        response: CompletionResult,
        sampled_responses: list[CompletionResult] | None = None,
        verbalized_response: CompletionResult | None = None,
        weights: dict[str, float] | None = None,
    ) -> float:
        """Combine all available confidence signals with a weighted average.

        Only signals where actual data is present are included in the blend:
        - logprob  — used when ``response.confidence_method == "logprob"``
        - sampling — used when ``sampled_responses`` contains >= 2 items
        - verbalized — used when ``verbalized_response.confidence_method == "verbalized"``

        Args:
            response: Primary CompletionResult (may be logprob or sampling mode).
            sampled_responses: Optional list of sampled results for agreement scoring.
            verbalized_response: Optional result obtained via verbalized prompting.
            weights: Override default weights ``{"logprob": 0.5, "sampling": 0.35,
                "verbalized": 0.15}``.

        Returns:
            Weighted-average confidence in [0.0, 1.0].
        """
        w = weights if weights is not None else self._DEFAULT_WEIGHTS

        signals: dict[str, float] = {}

        if response.confidence_method == "logprob":
            signals["logprob"] = self.estimate_logprob(response)

        if sampled_responses and len(sampled_responses) >= 2:
            signals["sampling"] = self.estimate_sampling(sampled_responses)

        if verbalized_response and verbalized_response.confidence_method == "verbalized":
            signals["verbalized"] = self.estimate_verbalized(verbalized_response)

        # Fall back to the raw confidence if no richer signals are available
        if not signals:
            return max(0.0, min(1.0, response.confidence))

        total_weight = sum(w.get(k, 1.0) for k in signals)
        if total_weight <= 0:
            return statistics.mean(signals.values())

        blended = sum(v * w.get(k, 1.0) for k, v in signals.items()) / total_weight
        return max(0.0, min(1.0, blended))
