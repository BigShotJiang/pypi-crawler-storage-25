"""Achievement Badge system for yuragi.

Gamification layer: earned badges are persisted to ~/.yuragi/badges.json
and displayed after each scan.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Callable

from rich.console import Console
from rich.text import Text

if TYPE_CHECKING:
    from yuragi.core import ScanResult

_BADGES_PATH = Path.home() / ".yuragi" / "badges.json"

console = Console()


@dataclass
class Badge:
    name: str
    icon: str  # Rich :name: emoji identifier (without colons)
    description: str
    condition: Callable  # takes ScanResult, returns bool


BADGES: list[Badge] = [
    Badge(
        name="Fragility Sleuth",
        icon="mag",
        description="Found a >75% confidence collapse",
        condition=lambda r: any(
            abs(p.confidence_delta) > 0.75 for p in r.perturbation_results
        ),
    ),
    Badge(
        name="Dissociation Master",
        icon="dart",
        description="Scan with >50% dissociation rate",
        condition=lambda r: r.dissociation_rate > 0.5,
    ),
    Badge(
        name="Steel Finder",
        icon="building_construction",
        description="Found a model with fragility < 0.1",
        condition=lambda r: r.fragility_score < 0.1,
    ),
    Badge(
        name="Catastrophe Detector",
        icon="collision",
        description="CCI > 0.8",
        condition=lambda r: _cci(r) > 0.8,
    ),
    Badge(
        name="Recovery Wizard",
        icon="sparkles",
        description="Found a recovery strategy with >80% effectiveness",
        condition=lambda r: _best_recovery(r) > 0.8,
    ),
    Badge(
        name="Pressure Proof",
        icon="muscle",
        description="Model resisted all 5 pressure levels",
        condition=lambda r: _all_small_deltas(r, n=5, threshold=0.05),
    ),
    Badge(
        name="Phase Shifter",
        icon="zap",
        description="Detected a confidence phase transition",
        condition=lambda r: _has_phase_transition(r),
    ),
    Badge(
        name="Polyglot Tester",
        icon="globe_with_meridians",
        description="Tested in 3+ languages",
        condition=lambda r: _multilingual(r, min_langs=3),
    ),
    Badge(
        name="Deep Analyzer",
        icon="microscope",
        description="Used all perturbations",
        condition=lambda r: len(r.perturbation_results) >= 10,
    ),
    Badge(
        name="First Blood",
        icon="drop_of_blood",
        description="Completed your first scan",
        condition=lambda r: r.baseline.confidence >= 0.0,
    ),
]


# ---------------------------------------------------------------------------
# Condition helpers (keep conditions out of lambdas for complexity)
# ---------------------------------------------------------------------------

def _cci(result: ScanResult) -> float:
    """Try to get CCI from FragilityProfile; fall back to 0."""
    try:
        from yuragi.analysis.fragility_profile import build_profile

        return build_profile(result).catastrophic_collapse_index
    except Exception:
        return 0.0


def _best_recovery(result: ScanResult) -> float:
    """Proxy for recovery effectiveness: max upward confidence delta."""
    if not result.perturbation_results:
        return 0.0
    return max((p.confidence_delta for p in result.perturbation_results), default=0.0)


def _all_small_deltas(result: ScanResult, n: int, threshold: float) -> bool:
    """True if at least *n* perturbations all have |delta| < threshold."""
    small = [p for p in result.perturbation_results if abs(p.confidence_delta) < threshold]
    return len(small) >= n


def _has_phase_transition(result: ScanResult) -> bool:
    """Detect sharp transition: consecutive deltas change sign with |diff| > 0.3."""
    deltas = [p.confidence_delta for p in result.perturbation_results]
    for i in range(len(deltas) - 1):
        if deltas[i] * deltas[i + 1] < 0 and abs(deltas[i] - deltas[i + 1]) > 0.3:
            return True
    return False


def _multilingual(result: ScanResult, min_langs: int) -> bool:
    """Heuristic: detect CJK / Arabic / Cyrillic / Latin as distinct scripts."""
    import unicodedata

    text = " ".join(
        [result.prompt]
        + [p.perturbed_prompt for p in result.perturbation_results]
    )
    scripts: set[str] = set()
    for ch in text:
        try:
            name = unicodedata.name(ch, "")
        except (ValueError, TypeError):
            continue
        if name.startswith("CJK") or name.startswith("HIRAGANA") or name.startswith("KATAKANA"):
            scripts.add("cjk")
        elif name.startswith("ARABIC"):
            scripts.add("arabic")
        elif name.startswith("CYRILLIC"):
            scripts.add("cyrillic")
        elif name.startswith("LATIN"):
            scripts.add("latin")
    return len(scripts) >= min_langs


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def check_badges(result: ScanResult) -> list[Badge]:
    """Return badges earned from *result*."""
    earned = []
    for badge in BADGES:
        try:
            if badge.condition(result):
                earned.append(badge)
        except Exception:
            pass
    return earned


def load_badges() -> set[str]:
    """Load previously earned badge names from ~/.yuragi/badges.json."""
    if not _BADGES_PATH.exists():
        return set()
    try:
        data = json.loads(_BADGES_PATH.read_text(encoding="utf-8"))
        return set(data.get("earned", []))
    except Exception:
        return set()


def save_badges(earned_names: set[str]) -> None:
    """Persist earned badge names to ~/.yuragi/badges.json."""
    _BADGES_PATH.parent.mkdir(parents=True, exist_ok=True)
    _BADGES_PATH.write_text(
        json.dumps({"earned": sorted(earned_names)}, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )


def display_badges(newly_earned: list[Badge], total_earned: int) -> None:
    """Display newly earned badges and overall progress with Rich formatting."""
    if not newly_earned:
        return

    parts: list[str] = []
    for badge in newly_earned:
        parts.append(f":{badge.icon}: [bold]{badge.name}[/bold]")

    line = Text.from_markup(
        "[bold yellow]New badges earned:[/bold yellow] " + " [dim]|[/dim] ".join(parts)
    )
    console.print(line)
    console.print(
        f"[dim]Progress: {total_earned}/{len(BADGES)} badges unlocked[/dim]"
    )
    console.print()


def process_badges(result: ScanResult) -> None:
    """Check, persist and display badges for *result*.

    Call this at the end of a scan to handle the full badge lifecycle.
    """
    previously = load_badges()
    newly_earned = [b for b in check_badges(result) if b.name not in previously]

    if not newly_earned:
        total = len(previously)
        console.print(f"[dim]Progress: {total}/{len(BADGES)} badges unlocked[/dim]")
        console.print()
        return

    updated = previously | {b.name for b in newly_earned}
    save_badges(updated)
    display_badges(newly_earned, len(updated))
