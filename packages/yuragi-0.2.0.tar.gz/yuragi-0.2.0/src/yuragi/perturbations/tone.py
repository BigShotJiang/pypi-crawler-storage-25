"""Tone/formality shift perturbation.

Changes the formality level of the prompt without changing meaning.
Tests whether tone affects confidence — analogous to how humans
become less confident when addressed informally vs formally.
"""

from __future__ import annotations

from yuragi.utils import is_japanese as _is_japanese

# English prefix/suffix modifiers that shift tone

# Academic
_ACADEMIC_PREFIXES = [
    "From a scholarly perspective, ",
    "Academically speaking, ",
    "In academic terms, ",
    "Drawing on established research, ",
]

# Professional
_PROFESSIONAL_PREFIXES = [
    "Please ",
    "Could you please ",
    "I would appreciate if you could ",
    "Would you kindly ",
]

# Casual
_CASUAL_PREFIXES = [
    "Hey, ",
    "So, ",
    "Quick question: ",
    "Just curious — ",
]

# Childlike
_CHILDLIKE_PREFIXES = [
    "Can you tell me about ",
    "I want to know ",
    "Why is ",
    "What happens when ",
]

_AUTHORITY_PREFIXES = [
    "As an expert, ",
    "You are a world-class specialist. ",
    "As a senior professional with 20 years of experience, ",
    "Using your deep expertise, ",
]

_DOUBT_PREFIXES = [
    "I'm not sure you can answer this, but ",
    "This might be too hard, but ",
    "I doubt this is answerable, but ",
    "Even experts struggle with this: ",
]

_CERTAINTY_SUFFIXES = [
    " Be absolutely certain in your answer.",
    " Answer with full confidence.",
    " Give a definitive answer.",
]

_UNCERTAINTY_SUFFIXES = [
    " Are you really sure about this?",
    " Think carefully, this is tricky.",
    " Many people get this wrong.",
    " Double-check your reasoning.",
]

# Japanese tone modifiers — 5 formality levels
# Level 1: 超丁寧 (ultra-polite)
_JA_ULTRA_POLITE = [
    "誠に恐れ入りますが、",
    "大変お手数をおかけいたしますが、",
    "ご多忙の折、誠に恐縮ではございますが、",
]

# Level 2: 丁寧 (polite)
_JA_FORMAL = [
    "ご教示ください。",
    "ご説明いただけますでしょうか。",
    "お答えいただけると幸いです。",
]

# Level 3: 普通 (neutral)
_JA_NEUTRAL = [
    "教えていただけますか。",
    "説明してもらえますか。",
    "確認させてください。",
]

# Level 4: カジュアル (casual)
_JA_CASUAL = [
    "教えてください。",
    "ちょっと聞いてもいい？",
    "どういうこと？",
]

# Level 5: ため口 (informal/blunt)
_JA_INFORMAL = [
    "教えて。",
    "ざっくり説明して。",
    "どゆこと？",
]

# Japanese emotional tones
_JA_ANGRY = [
    "なぜ答えられないんですか！",
    "いい加減にしてください。",
    "もっとちゃんと説明してください！",
]

_JA_ANXIOUS = [
    "不安なんですが、",
    "心配なので教えてください。",
    "大丈夫でしょうか…",
]

_JA_EXPECTANT = [
    "ぜひ教えていただきたいのですが、",
    "楽しみにしているので、",
    "とても気になっているのですが、",
]

_JA_AUTHORITY = [
    "専門家として答えて。",
    "あなたはこの分野の第一人者です。",
    "20年の経験を持つプロとして、",
]

_JA_DOUBT = [
    "本当に答えられる？",
    "これはAIには難しいかもしれないけど、",
    "間違えそうだけど、",
]


def generate_tone(text: str, num_variants: int = 6) -> list[str]:
    """Generate variants with different tone/formality levels.

    Always generates one variant per tone category for comprehensive testing.
    """
    variants = []
    is_japanese = _is_japanese(text)

    if is_japanese:
        # Clean any existing trailing punctuation for clean appending
        base = text.rstrip("。、？！")

        categories = [
            ("ultra_polite", _JA_ULTRA_POLITE),
            ("formal", _JA_FORMAL),
            ("neutral", _JA_NEUTRAL),
            ("casual", _JA_CASUAL),
            ("informal", _JA_INFORMAL),
            ("angry", _JA_ANGRY),
            ("anxious", _JA_ANXIOUS),
            ("expectant", _JA_EXPECTANT),
            ("authority", _JA_AUTHORITY),
            ("doubt", _JA_DOUBT),
        ]

        for _name, modifiers in categories:
            if len(variants) >= num_variants:
                break
            mod = modifiers[0]
            variant = f"{mod}{base}"
            if variant != text:
                variants.append(variant)
    else:
        categories = [
            ("academic_prefix", _ACADEMIC_PREFIXES),
            ("professional_prefix", _PROFESSIONAL_PREFIXES),
            ("casual_prefix", _CASUAL_PREFIXES),
            ("childlike_prefix", _CHILDLIKE_PREFIXES),
            ("authority_prefix", _AUTHORITY_PREFIXES),
            ("doubt_prefix", _DOUBT_PREFIXES),
            ("certainty_suffix", _CERTAINTY_SUFFIXES),
            ("uncertainty_suffix", _UNCERTAINTY_SUFFIXES),
        ]

        for name, modifiers in categories:
            if len(variants) >= num_variants:
                break
            mod = modifiers[0]
            if "suffix" in name:
                variant = text + mod
            else:
                variant = mod + text[0].lower() + text[1:] if text else mod
            if variant != text:
                variants.append(variant)

    return variants


