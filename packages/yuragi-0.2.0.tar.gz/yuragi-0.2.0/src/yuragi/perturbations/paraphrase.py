"""Paraphrase perturbation.

Generates semantically equivalent rephrasings of the entire prompt.
Uses simple rule-based transformations (no LLM dependency for perturbation).
"""

from __future__ import annotations

from yuragi.utils import is_japanese as _is_japanese

# English transformation rules: (pattern, replacement)
_EN_TRANSFORMS: list[tuple[str, str]] = [
    ("What is ", "Can you tell me what "),
    ("What is ", "Explain what "),
    ("What are ", "Can you list "),
    ("How do ", "Can you explain how to "),
    ("How does ", "Can you explain the way "),
    ("Why is ", "What is the reason that "),
    ("Why do ", "What causes "),
    ("Is it true that ", "Would you say that "),
    ("Can you ", "Would you be able to "),
    ("Tell me ", "I'd like to know "),
    ("Explain ", "Provide an explanation of "),
    ("Describe ", "Give a description of "),
    ("List ", "Enumerate "),
    ("Compare ", "What are the differences between "),
]

# Japanese transformation rules
_JA_TRANSFORMS: list[tuple[str, str]] = [
    # Question transformations
    ("とは何ですか", "について説明してください"),
    ("とは何ですか？", "についてどのようなものか教えてください"),
    ("について教えて", "に関して解説して"),
    ("を説明して", "について述べて"),
    ("はどうですか", "についてどう思いますか"),
    # Formality level transformations
    ("ですか？", "でしょうか？"),
    ("ですか?", "なのでしょうか?"),
    ("ですか", "なのですか"),
    ("してください", "していただけますか"),
    ("を教えて", "について知りたい"),
    ("はなぜ", "が〜である理由は"),
    # Sentence-ending style transformations (です→である→だ→じゃん)
    ("です。", "である。"),
    ("です。", "だ。"),
    ("ます。", "る。"),
    ("でした。", "であった。"),
    # Question style conversions
    ("ですか？", "なの？"),
    ("でしょうか？", "かな？"),
    ("ますか？", "る？"),
    # Connector insertion
    ("。", "。ところで、"),
    ("です。", "です。ちなみに、"),
    ("ます。", "ます。実は、"),
]

# Sentence restructuring patterns
_RESTRUCTURE_PREFIXES = [
    "In your own words, ",
    "Briefly, ",
    "In detail, ",
    "To summarize, ",
]

_JA_RESTRUCTURE_PREFIXES = [
    "簡潔に言うと、",
    "要するに、",
    "詳しく言うと、",
    "分かりやすく、",
    "ところで、",
    "ちなみに、",
    "実は、",
    "率直に言うと、",
]

# Japanese sentence-ending conversion rules: (suffix_to_match, replacement)
_JA_SENTENCE_ENDING_RULES: list[tuple[str, str]] = [
    ("です。", "である。"),
    ("です。", "だ。"),
    ("です。", "だよ。"),
    ("です。", "じゃん。"),
    ("ます。", "る。"),
    ("ます。", "るよ。"),
    ("でした。", "であった。"),
    ("でした。", "だった。"),
    ("ました。", "た。"),
]

# Japanese question-ending conversion rules
_JA_QUESTION_RULES: list[tuple[str, str]] = [
    ("ですか？", "でしょうか？"),
    ("ですか？", "なの？"),
    ("ですか？", "かな？"),
    ("ますか？", "ますか？"),
    ("でしょうか？", "ですか？"),
    ("でしょうか？", "なの？"),
    ("でしょうか？", "かな？"),
]


def generate_paraphrase(text: str, num_variants: int = 3) -> list[str]:
    """Generate paraphrased variants using rule-based transformations."""
    if not text.strip():
        return []

    is_ja = _is_japanese(text)
    variants = []
    seen = set()

    transforms = _JA_TRANSFORMS if is_ja else _EN_TRANSFORMS
    prefixes = _JA_RESTRUCTURE_PREFIXES if is_ja else _RESTRUCTURE_PREFIXES

    # Try pattern-based transforms
    for pattern, replacement in transforms:
        if len(variants) >= num_variants:
            break
        if pattern in text:
            variant = text.replace(pattern, replacement, 1)
            if variant not in seen and variant != text:
                seen.add(variant)
                variants.append(variant)

    # Japanese: try sentence-ending and question-ending conversions
    if is_ja:
        for suffix, replacement in _JA_SENTENCE_ENDING_RULES:
            if len(variants) >= num_variants:
                break
            if text.endswith(suffix):
                variant = text[: -len(suffix)] + replacement
                if variant not in seen and variant != text:
                    seen.add(variant)
                    variants.append(variant)

        for suffix, replacement in _JA_QUESTION_RULES:
            if len(variants) >= num_variants:
                break
            if text.endswith(suffix):
                variant = text[: -len(suffix)] + replacement
                if variant not in seen and variant != text:
                    seen.add(variant)
                    variants.append(variant)

    # Add prefix-based restructuring
    for prefix in prefixes:
        if len(variants) >= num_variants:
            break
        variant = prefix + text
        if variant not in seen:
            seen.add(variant)
            variants.append(variant)

    return variants[:num_variants]


