"""Semantic-preserving perturbation.

Transforms text while preserving meaning:
- Active <-> passive voice (English)
- Affirmative <-> double negation
- Concrete <-> abstract expression
"""

from __future__ import annotations

import re

from yuragi.utils import is_japanese as _is_japanese

# Active -> passive patterns: (regex, replacement, description)
# Simplified subject-verb-object patterns
_EN_ACTIVE_TO_PASSIVE: list[tuple[str, str]] = [
    # "X verb(s) Y" -> "Y is/are verbed by X"  (simple SVO, past tense forms)
    (r"\bThe (\w+) ate the (\w+)\b", r"The \2 was eaten by the \1"),
    (r"\bThe (\w+) eats the (\w+)\b", r"The \2 is eaten by the \1"),
    (r"\bThe (\w+) wrote the (\w+)\b", r"The \2 was written by the \1"),
    (r"\bThe (\w+) writes the (\w+)\b", r"The \2 is written by the \1"),
    (r"\bThe (\w+) built the (\w+)\b", r"The \2 was built by the \1"),
    (r"\bThe (\w+) builds the (\w+)\b", r"The \2 is built by the \1"),
    (r"\bThe (\w+) created the (\w+)\b", r"The \2 was created by the \1"),
    (r"\bThe (\w+) creates the (\w+)\b", r"The \2 is created by the \1"),
    (r"\bThe (\w+) designed the (\w+)\b", r"The \2 was designed by the \1"),
    (r"\bThe (\w+) designs the (\w+)\b", r"The \2 is designed by the \1"),
    (r"\bThe (\w+) developed the (\w+)\b", r"The \2 was developed by the \1"),
    (r"\bThe (\w+) develops the (\w+)\b", r"The \2 is developed by the \1"),
    (r"\bThe (\w+) published the (\w+)\b", r"The \2 was published by the \1"),
    (r"\bThe (\w+) publishes the (\w+)\b", r"The \2 is published by the \1"),
    (r"\bThe (\w+) solved the (\w+)\b", r"The \2 was solved by the \1"),
    (r"\bThe (\w+) solves the (\w+)\b", r"The \2 is solved by the \1"),
]

# Passive -> active patterns
_EN_PASSIVE_TO_ACTIVE: list[tuple[str, str]] = [
    (r"\bThe (\w+) was eaten by the (\w+)\b", r"The \2 ate the \1"),
    (r"\bThe (\w+) is eaten by the (\w+)\b", r"The \2 eats the \1"),
    (r"\bThe (\w+) was written by the (\w+)\b", r"The \2 wrote the \1"),
    (r"\bThe (\w+) is written by the (\w+)\b", r"The \2 writes the \1"),
    (r"\bThe (\w+) was built by the (\w+)\b", r"The \2 built the \1"),
    (r"\bThe (\w+) is built by the (\w+)\b", r"The \2 builds the \1"),
    (r"\bThe (\w+) was created by the (\w+)\b", r"The \2 created the \1"),
    (r"\bThe (\w+) is created by the (\w+)\b", r"The \2 creates the \1"),
    (r"\bThe (\w+) was designed by the (\w+)\b", r"The \2 designed the \1"),
    (r"\bThe (\w+) is designed by the (\w+)\b", r"The \2 designs the \1"),
    (r"\bThe (\w+) was developed by the (\w+)\b", r"The \2 developed the \1"),
    (r"\bThe (\w+) is developed by the (\w+)\b", r"The \2 develops the \1"),
    (r"\bThe (\w+) was solved by the (\w+)\b", r"The \2 solved the \1"),
    (r"\bThe (\w+) is solved by the (\w+)\b", r"The \2 solves the \1"),
]

# Affirmative -> double negation: (pattern, replacement)
_EN_TO_DOUBLE_NEG: list[tuple[str, str]] = [
    ("It is possible", "It is not impossible"),
    ("It is impossible", "It is not possible"),
    ("It is easy", "It is not difficult"),
    ("It is difficult", "It is not easy"),
    ("It is certain", "It is not uncertain"),
    ("It is clear", "It is not unclear"),
    ("It is true", "It is not false"),
    ("It is false", "It is not true"),
    ("It is common", "It is not uncommon"),
    ("It is uncommon", "It is not common"),
    ("It is necessary", "It is not unnecessary"),
    ("It is unnecessary", "It is not necessary"),
    ("It is important", "It is not unimportant"),
    ("It is relevant", "It is not irrelevant"),
    ("I agree", "I do not disagree"),
    ("I disagree", "I do not agree"),
]

# Double negation -> affirmative
_EN_FROM_DOUBLE_NEG: list[tuple[str, str]] = [
    ("It is not impossible", "It is possible"),
    ("It is not possible", "It is impossible"),
    ("It is not difficult", "It is easy"),
    ("It is not easy", "It is difficult"),
    ("It is not uncertain", "It is certain"),
    ("It is not unclear", "It is clear"),
    ("It is not false", "It is true"),
    ("It is not true", "It is false"),
    ("It is not uncommon", "It is common"),
    ("It is not common", "It is uncommon"),
    ("It is not unnecessary", "It is necessary"),
    ("It is not necessary", "It is unnecessary"),
    ("It is not unimportant", "It is important"),
    ("It is not irrelevant", "It is relevant"),
    ("I do not disagree", "I agree"),
    ("I do not agree", "I disagree"),
]

# Concrete -> abstract: (concrete_term, abstract_form)
_EN_CONCRETE_TO_ABSTRACT: list[tuple[str, str]] = [
    ("Paris", "the capital of France"),
    ("Tokyo", "the capital of Japan"),
    ("London", "the capital of the United Kingdom"),
    ("New York", "the largest city in the United States"),
    ("Washington D.C.", "the capital of the United States"),
    ("Berlin", "the capital of Germany"),
    ("Beijing", "the capital of China"),
    ("Moscow", "the capital of Russia"),
    ("Rome", "the capital of Italy"),
    ("Madrid", "the capital of Spain"),
    ("the Sun", "the star at the center of the solar system"),
    ("the Moon", "Earth's natural satellite"),
    ("water", "the most common liquid on Earth"),
    ("DNA", "the molecule carrying genetic information"),
    ("oxygen", "the gas essential for human respiration"),
]

# Abstract -> concrete
_EN_ABSTRACT_TO_CONCRETE: list[tuple[str, str]] = [
    ("the capital of France", "Paris"),
    ("the capital of Japan", "Tokyo"),
    ("the capital of the United Kingdom", "London"),
    ("the capital of the United States", "Washington D.C."),
    ("the capital of Germany", "Berlin"),
    ("the capital of China", "Beijing"),
    ("the capital of Russia", "Moscow"),
    ("the capital of Italy", "Rome"),
    ("the capital of Spain", "Madrid"),
    ("Earth's natural satellite", "the Moon"),
    ("the star at the center of the solar system", "the Sun"),
    ("the molecule carrying genetic information", "DNA"),
    ("the gas essential for human respiration", "oxygen"),
]

# Japanese active -> passive (verb-form substitution)
_JA_ACTIVE_TO_PASSIVE: list[tuple[str, str]] = [
    ("食べた", "食べられた"),
    ("食べる", "食べられる"),
    ("書いた", "書かれた"),
    ("書く", "書かれる"),
    ("作った", "作られた"),
    ("作る", "作られる"),
    ("読んだ", "読まれた"),
    ("読む", "読まれる"),
    ("見た", "見られた"),
    ("見る", "見られる"),
    ("破壊した", "破壊された"),
    ("開発した", "開発された"),
    ("発表した", "発表された"),
    ("設計した", "設計された"),
    ("発明した", "発明された"),
]

# Japanese passive -> active (verb-form substitution)
_JA_PASSIVE_TO_ACTIVE: list[tuple[str, str]] = [
    ("食べられた", "食べた"),
    ("食べられる", "食べる"),
    ("書かれた", "書いた"),
    ("書かれる", "書く"),
    ("作られた", "作った"),
    ("作られる", "作る"),
    ("読まれた", "読んだ"),
    ("読まれる", "読む"),
    ("見られた", "見た"),
    ("見られる", "見る"),
    ("破壊された", "破壊した"),
    ("開発された", "開発した"),
    ("発表された", "発表した"),
    ("設計された", "設計した"),
    ("発明された", "発明した"),
]

# Japanese affirmative -> double negation
_JA_TO_DOUBLE_NEG: list[tuple[str, str]] = [
    ("可能です", "不可能ではありません"),
    ("不可能です", "可能ではありません"),
    ("簡単です", "難しくありません"),
    ("難しいです", "簡単ではありません"),
    ("正しいです", "間違っていません"),
    ("間違っています", "正しくありません"),
    ("重要です", "重要でないわけではありません"),
    ("明らかです", "不明瞭ではありません"),
    ("必要です", "不要ではありません"),
    ("できます", "できないわけではありません"),
]

# Japanese double negation -> affirmative
_JA_FROM_DOUBLE_NEG: list[tuple[str, str]] = [
    ("不可能ではありません", "可能です"),
    ("可能ではありません", "不可能です"),
    ("難しくありません", "簡単です"),
    ("簡単ではありません", "難しいです"),
    ("間違っていません", "正しいです"),
    ("正しくありません", "間違っています"),
    ("不明瞭ではありません", "明らかです"),
    ("不要ではありません", "必要です"),
    ("できないわけではありません", "できます"),
]

# Japanese concrete -> abstract
_JA_CONCRETE_TO_ABSTRACT: list[tuple[str, str]] = [
    ("東京", "日本の首都"),
    ("パリ", "フランスの首都"),
    ("ロンドン", "イギリスの首都"),
    ("北京", "中国の首都"),
    ("ワシントンD.C.", "アメリカの首都"),
    ("富士山", "日本最高峰の山"),
    ("琵琶湖", "日本最大の湖"),
    ("太陽", "太陽系の中心にある恒星"),
    ("月", "地球の衛星"),
    ("DNA", "遺伝情報を持つ分子"),
    ("水", "地球上で最も一般的な液体"),
    ("酸素", "人間の呼吸に不可欠な気体"),
]

# Japanese abstract -> concrete
_JA_ABSTRACT_TO_CONCRETE: list[tuple[str, str]] = [
    ("日本の首都", "東京"),
    ("フランスの首都", "パリ"),
    ("イギリスの首都", "ロンドン"),
    ("中国の首都", "北京"),
    ("アメリカの首都", "ワシントンD.C."),
    ("日本最高峰の山", "富士山"),
    ("日本最大の湖", "琵琶湖"),
    ("太陽系の中心にある恒星", "太陽"),
    ("地球の衛星", "月"),
    ("遺伝情報を持つ分子", "DNA"),
]


def generate_semantic(text: str, num_variants: int = 4) -> list[str]:
    """Generate semantically equivalent variants using meaning-preserving transformations.

    Applies active/passive voice conversion, affirmative/double-negation conversion,
    and concrete/abstract expression substitution.
    """
    if not text.strip():
        return []

    is_ja = _is_japanese(text)
    variants: list[str] = []
    seen: set[str] = set()

    def _add(v: str) -> bool:
        if v != text and v not in seen:
            seen.add(v)
            variants.append(v)
            return True
        return False

    if is_ja:
        rule_groups = [
            _JA_ACTIVE_TO_PASSIVE,
            _JA_PASSIVE_TO_ACTIVE,
            _JA_TO_DOUBLE_NEG,
            _JA_FROM_DOUBLE_NEG,
            _JA_CONCRETE_TO_ABSTRACT,
            _JA_ABSTRACT_TO_CONCRETE,
        ]
        for rules in rule_groups:
            if len(variants) >= num_variants:
                break
            for src, dst in rules:
                if src in text:
                    _add(text.replace(src, dst, 1))
                    if len(variants) >= num_variants:
                        break
    else:
        # Regex-based voice conversion
        for pattern, replacement in _EN_ACTIVE_TO_PASSIVE + _EN_PASSIVE_TO_ACTIVE:
            if len(variants) >= num_variants:
                break
            m = re.search(pattern, text, re.IGNORECASE)
            if m:
                variant = re.sub(pattern, replacement, text, count=1, flags=re.IGNORECASE)
                _add(variant)

        # String-based affirmation / double-negation
        for src, dst in _EN_TO_DOUBLE_NEG + _EN_FROM_DOUBLE_NEG:
            if len(variants) >= num_variants:
                break
            if src in text:
                _add(text.replace(src, dst, 1))

        # Concrete <-> abstract
        for src, dst in _EN_CONCRETE_TO_ABSTRACT + _EN_ABSTRACT_TO_CONCRETE:
            if len(variants) >= num_variants:
                break
            if src in text:
                _add(text.replace(src, dst, 1))

    return variants


