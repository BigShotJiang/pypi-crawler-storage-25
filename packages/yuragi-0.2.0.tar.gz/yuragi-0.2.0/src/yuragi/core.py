"""Core scanner — the heart of yuragi.

Orchestrates perturbation generation, LLM querying, and confidence analysis.
"""

from __future__ import annotations

import hashlib
import json
import logging
import time
from collections.abc import Iterator
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable

from yuragi.config import DEFAULT_CONFIG, YuragiConfig
from yuragi.exceptions import ConfigurationError, ScanError, YuragiError
from yuragi.perturbations import Perturbation
from yuragi.providers.adapter import CompletionResult, LLMAdapter
from yuragi.utils import char_ngrams, make_rng

logger = logging.getLogger(__name__)


@dataclass
class PerturbationResult:
    """Result of a single perturbation test."""

    original_prompt: str
    perturbed_prompt: str
    perturbation_type: str
    original_response: CompletionResult
    perturbed_response: CompletionResult
    config: YuragiConfig = field(default_factory=lambda: DEFAULT_CONFIG, repr=False)

    @property
    def confidence_delta(self) -> float:
        """Change in confidence (negative = confidence dropped)."""
        return self.perturbed_response.confidence - self.original_response.confidence

    @property
    def answer_changed(self) -> bool:
        """Whether the core answer changed.

        Uses character n-gram overlap for language-agnostic comparison.
        Works correctly for Japanese, Chinese, and other non-space-delimited languages.
        """
        return self.answer_similarity < self.config.dissociation_similarity_threshold

    @property
    def answer_similarity(self) -> float:
        """Continuous similarity between original and perturbed answers (0.0-1.0)."""
        orig = self.original_response.text.strip().lower()[:300]
        pert = self.perturbed_response.text.strip().lower()[:300]
        if not orig or not pert:
            return 0.0
        ngrams_o = char_ngrams(orig, 3)
        ngrams_p = char_ngrams(pert, 3)
        if not ngrams_o or not ngrams_p:
            return 0.0
        return len(ngrams_o & ngrams_p) / max(len(ngrams_o | ngrams_p), 1)

    @property
    def is_dissociated(self) -> bool:
        """Answer stayed the same but confidence changed significantly.

        Uses adaptive threshold based on confidence measurement method
        and continuous answer similarity for more accurate detection.
        """
        return self.dissociation_severity > 0.0

    @property
    def dissociation_severity(self) -> float:
        """Continuous dissociation score (0.0-1.0).

        Higher = answer is more similar AND confidence shifted more.
        This is yuragi's key novel metric.
        """
        sim = self.answer_similarity
        if sim < self.config.dissociation_similarity_threshold:
            return 0.0
        conf_shift = abs(self.confidence_delta)
        if conf_shift < self.config.dissociation_noise_floor:
            return 0.0
        return min(1.0, sim * conf_shift * self.config.dissociation_scaling_factor)


@dataclass
class ScanResult:
    """Complete scan results for a prompt."""

    prompt: str
    model: str
    baseline: CompletionResult
    perturbation_results: list[PerturbationResult] = field(default_factory=list)
    scan_duration_seconds: float = 0.0
    total_tokens_used: int = 0
    total_api_calls: int = 0
    config: YuragiConfig = field(default_factory=lambda: DEFAULT_CONFIG, repr=False)

    @property
    def fragility_score(self) -> float:
        """Overall fragility: 0.0 (steel) to 1.0 (glass).

        Computed as the standard deviation of confidence across all perturbations,
        normalized to [0, 1].
        """
        if not self.perturbation_results:
            return 0.0

        confidences = [self.baseline.confidence] + [
            r.perturbed_response.confidence for r in self.perturbation_results
        ]

        if len(confidences) < 2:
            return 0.0

        mean = sum(confidences) / len(confidences)
        variance = sum((c - mean) ** 2 for c in confidences) / len(confidences)
        std = variance ** 0.5

        return min(1.0, std / self.config.fragility_normalization_std)

    @property
    def confidence_range(self) -> float:
        """Spread between min and max confidence across perturbations."""
        if not self.perturbation_results:
            return 0.0

        confidences = [self.baseline.confidence] + [
            r.perturbed_response.confidence for r in self.perturbation_results
        ]
        return max(confidences) - min(confidences)

    @property
    def dissociation_rate(self) -> float:
        """Fraction of perturbations where answer stayed same but confidence shifted."""
        if not self.perturbation_results:
            return 0.0
        dissoc = sum(1 for r in self.perturbation_results if r.is_dissociated)
        return dissoc / len(self.perturbation_results)

    @property
    def max_confidence_drop(self) -> float:
        """Largest single confidence drop from any perturbation."""
        if not self.perturbation_results:
            return 0.0
        return min(r.confidence_delta for r in self.perturbation_results)

    @property
    def weakest_perturbation(self) -> PerturbationResult | None:
        """The perturbation that caused the biggest confidence drop."""
        if not self.perturbation_results:
            return None
        return min(self.perturbation_results, key=lambda r: r.confidence_delta)

    @property
    def strongest_perturbation(self) -> PerturbationResult | None:
        """The perturbation that caused the biggest confidence boost."""
        if not self.perturbation_results:
            return None
        return max(self.perturbation_results, key=lambda r: r.confidence_delta)

    def fragility_label(self, config: YuragiConfig | None = None) -> str:
        """Human-readable fragility assessment."""
        cfg = config or self.config
        score = self.fragility_score
        b = cfg.fragility_label_boundaries
        labels = ("Steel", "Sturdy", "Flexible", "Glass", "Shattered")
        for boundary, label in zip(b, labels):
            if score < boundary:
                return label
        return labels[-1]

    def by_type(self, perturbation_type: str) -> list[PerturbationResult]:
        """Filter results by perturbation type."""
        return [
            r for r in self.perturbation_results
            if r.perturbation_type == perturbation_type
        ]

    def to_summary_dict(self) -> dict:
        """Serialize scan result to a summary dictionary (metrics only)."""
        return {
            "prompt": self.prompt,
            "model": self.model,
            "baseline_confidence": self.baseline.confidence,
            "confidence_method": self.baseline.confidence_method,
            "fragility_score": self.fragility_score,
            "fragility_label": self.fragility_label(),
            "confidence_range": self.confidence_range,
            "dissociation_rate": self.dissociation_rate,
            "max_confidence_drop": self.max_confidence_drop,
            "scan_duration_seconds": self.scan_duration_seconds,
            "total_api_calls": self.total_api_calls,
            "perturbations": [
                {
                    "type": r.perturbation_type,
                    "prompt": r.perturbed_prompt,
                    "confidence": r.perturbed_response.confidence,
                    "delta": r.confidence_delta,
                    "answer_changed": r.answer_changed,
                    "dissociated": r.is_dissociated,
                    "dissociation_severity": r.dissociation_severity,
                }
                for r in self.perturbation_results
            ],
        }

    def to_json(self, indent: int = 2, ensure_ascii: bool = False) -> str:
        """Serialize scan result to a JSON string."""
        return json.dumps(self.to_summary_dict(), indent=indent, ensure_ascii=ensure_ascii)

    def to_dict(self) -> dict[str, Any]:
        """Serialize scan result to a plain dict."""
        def _completion_to_dict(c: CompletionResult) -> dict[str, Any]:
            return {
                "text": c.text,
                "confidence": c.confidence,
                "confidence_method": c.confidence_method,
                "logprob_entropy": c.logprob_entropy,
                "token_count": c.token_count,
            }

        def _perturbation_to_dict(p: PerturbationResult) -> dict[str, Any]:
            return {
                "original_prompt": p.original_prompt,
                "perturbed_prompt": p.perturbed_prompt,
                "perturbation_type": p.perturbation_type,
                "original_response": _completion_to_dict(p.original_response),
                "perturbed_response": _completion_to_dict(p.perturbed_response),
            }

        import yuragi as _yuragi
        try:
            import litellm as _litellm
            litellm_version = _litellm.__version__
        except Exception:
            litellm_version = "unknown"

        config_dict = asdict(self.config)
        config_hash = hashlib.sha256(
            json.dumps(config_dict, sort_keys=True).encode()
        ).hexdigest()[:16]

        return {
            "yuragi_version": _yuragi.__version__,
            "seed": self.config.seed,
            "config_hash": config_hash,
            "timestamp_utc": datetime.now(timezone.utc).isoformat(),
            "litellm_version": litellm_version,
            "prompt": self.prompt,
            "model": self.model,
            "baseline": _completion_to_dict(self.baseline),
            "perturbation_results": [_perturbation_to_dict(p) for p in self.perturbation_results],
            "scan_duration_seconds": self.scan_duration_seconds,
            "total_tokens_used": self.total_tokens_used,
            "total_api_calls": self.total_api_calls,
        }

    def save(self, path: str) -> None:
        """Save scan result to JSON file."""
        from pathlib import Path

        Path(path).write_text(json.dumps(self.to_dict(), indent=2, ensure_ascii=False))

    @classmethod
    def load(cls, path: str, config: YuragiConfig | None = None) -> ScanResult:
        """Load scan result from JSON file."""
        from pathlib import Path

        cfg = config or DEFAULT_CONFIG
        data = json.loads(Path(path).read_text())

        def _dict_to_completion(d: dict[str, Any]) -> CompletionResult:
            return CompletionResult(
                text=d["text"],
                confidence=d["confidence"],
                confidence_method=d["confidence_method"],
                logprob_entropy=d.get("logprob_entropy"),
                token_count=d.get("token_count", 0),
            )

        perturbation_results = [
            PerturbationResult(
                original_prompt=p["original_prompt"],
                perturbed_prompt=p["perturbed_prompt"],
                perturbation_type=p["perturbation_type"],
                original_response=_dict_to_completion(p["original_response"]),
                perturbed_response=_dict_to_completion(p["perturbed_response"]),
                config=cfg,
            )
            for p in data.get("perturbation_results", [])
        ]

        return cls(
            prompt=data["prompt"],
            model=data["model"],
            baseline=_dict_to_completion(data["baseline"]),
            perturbation_results=perturbation_results,
            scan_duration_seconds=data.get("scan_duration_seconds", 0.0),
            total_tokens_used=data.get("total_tokens_used", 0),
            total_api_calls=data.get("total_api_calls", 0),
            config=cfg,
        )


# Default perturbation types for a standard scan
DEFAULT_PERTURBATIONS = [
    Perturbation.OMIT,
    Perturbation.SYNONYM,
    Perturbation.TONE,
    Perturbation.TYPO,
    Perturbation.REORDER,
    Perturbation.PARAPHRASE,
]


class Session:
    """Context manager that shares a scanner across multiple scans.

    Usage::

        with yuragi.session(model="ollama/llama3.2") as s:
            r1 = s.scan("prompt 1")
            r2 = s.scan("prompt 2")
    """

    def __init__(self, **kwargs) -> None:
        self._kwargs = kwargs
        self._scanner: Scanner | None = None

    def __enter__(self) -> Session:
        self._scanner = Scanner(**self._kwargs)
        return self

    def __exit__(self, *_) -> None:
        self._scanner = None

    def scan(self, prompt: str, system: str | None = None) -> ScanResult:
        """Run a scan within the session."""
        if self._scanner is None:
            raise YuragiError("Session is not active — use as a context manager")
        return self._scanner.scan(prompt, system=system)


class ScannerBuilder:
    """Fluent builder for Scanner + one-shot scan.

    Usage::

        result = (
            yuragi.scan("Is AI dangerous?")
            .model("ollama/llama3.2")
            .samples(5)
            .perturbations("tone", "omit")
            .run()
        )
    """

    def __init__(self, prompt: str) -> None:
        self._prompt = prompt
        self._model: str = "gpt-4o-mini"
        self._api_key: str | None = None
        self._num_samples: int = 5
        self._perturbations: list[Perturbation] | None = None
        self._num_variants: int = 3
        self._verbose: bool = False
        self._on_progress: Callable[[str, str], None] | None = None
        self._use_cache: bool = True
        self._parallel: int = 1
        self._system: str | None = None
        self._config: YuragiConfig | None = None

    def model(self, model_name: str) -> ScannerBuilder:
        """Set the model to use."""
        self._model = model_name
        return self

    def api_key(self, key: str) -> ScannerBuilder:
        """Set the API key."""
        self._api_key = key
        return self

    def samples(self, n: int) -> ScannerBuilder:
        """Set number of samples for confidence estimation."""
        self._num_samples = n
        return self

    def perturbations(self, *names: str | Perturbation) -> ScannerBuilder:
        """Set perturbation types by name or Perturbation enum.

        Example::

            .perturbations("tone", "omit")
            .perturbations(Perturbation.TONE, Perturbation.OMIT)
        """
        result: list[Perturbation] = []
        for n in names:
            if isinstance(n, Perturbation):
                result.append(n)
            else:
                result.append(Perturbation(n.lower()))
        self._perturbations = result
        return self

    def variants(self, n: int) -> ScannerBuilder:
        """Set number of variants per perturbation type."""
        self._num_variants = n
        return self

    def verbose(self, flag: bool = True) -> ScannerBuilder:
        """Enable verbose progress output."""
        self._verbose = flag
        return self

    def on_progress(self, callback: Callable[[str, str], None]) -> ScannerBuilder:
        """Set a progress callback."""
        self._on_progress = callback
        return self

    def cache(self, flag: bool = True) -> ScannerBuilder:
        """Enable or disable response cache."""
        self._use_cache = flag
        return self

    def parallel(self, n: int) -> ScannerBuilder:
        """Set concurrency level for parallel scanning."""
        self._parallel = n
        return self

    def system(self, prompt: str) -> ScannerBuilder:
        """Set the system prompt."""
        self._system = prompt
        return self

    def config(self, cfg: YuragiConfig) -> ScannerBuilder:
        """Set a custom YuragiConfig."""
        self._config = cfg
        return self

    def run(self) -> ScanResult:
        """Build the scanner and execute the scan."""
        scanner = Scanner(
            model=self._model,
            api_key=self._api_key,
            num_samples=self._num_samples,
            perturbations=self._perturbations,
            num_variants=self._num_variants,
            verbose=self._verbose,
            on_progress=self._on_progress,
            use_cache=self._use_cache,
            parallel=self._parallel,
            config=self._config,
        )
        return scanner.scan(self._prompt, system=self._system)


class Scanner:
    """Main scanner that orchestrates confidence fragility analysis.

    Usage:
        scanner = Scanner(model="gpt-4o")
        result = scanner.scan("Is quantum computing practical?")
        print(result.fragility_score)
    """

    def __init__(
        self,
        model: str = "gpt-4o-mini",
        api_key: str | None = None,
        num_samples: int = 5,
        perturbations: list[Perturbation] | None = None,
        num_variants: int = 3,
        verbose: bool = False,
        on_progress: Callable[[str, str], None] | None = None,
        use_cache: bool = True,
        parallel: int = 1,
        config: YuragiConfig | None = None,
    ):
        if num_samples < 1:
            raise ConfigurationError(f"num_samples must be >= 1, got {num_samples}")
        if num_variants < 0:
            raise ConfigurationError(f"num_variants must be >= 0, got {num_variants}")
        if parallel < 1:
            raise ConfigurationError(f"parallel must be >= 1, got {parallel}")

        self.model = model
        self.config = config or DEFAULT_CONFIG
        self.adapter = LLMAdapter(
            model=model,
            api_key=api_key,
            num_samples=num_samples,
            use_cache=use_cache,
            parallel=parallel,
            config=self.config,
        )
        self.perturbations = perturbations or DEFAULT_PERTURBATIONS
        self.num_variants = num_variants
        self.verbose = verbose
        self.on_progress = on_progress
        self.parallel = parallel

    def scan(
        self,
        prompt: str,
        system: str | None = None,
    ) -> ScanResult:
        """Run a full confidence fragility scan on a prompt.

        1. Get baseline response and confidence
        2. Generate perturbations
        3. Test each perturbation
        4. Compute fragility metrics
        """
        prompt_hash = hashlib.sha256(prompt.encode("utf-8")).hexdigest()[:16]
        logger.info("scan start model=%s prompt_hash=%s", self.model, prompt_hash)
        logger.debug("scan start prompt_preview=%r", prompt[:60])
        start_time = time.time()
        total_tokens = 0
        api_calls = 0

        # Create a seeded RNG for reproducible perturbation generation
        rng = make_rng(self.config.seed)

        # Perturbation types that accept an rng keyword argument
        rng_aware = {
            Perturbation.TYPO,
            Perturbation.SYNONYM,
            Perturbation.REORDER,
            Perturbation.NEGATION,
            Perturbation.COUNTERFACTUAL,
            Perturbation.CODE_SWITCHING,
        }

        # Step 1: Baseline
        self._report_progress("baseline", prompt)
        baseline = self.adapter.complete(prompt, system)
        total_tokens += baseline.token_count
        api_calls += 1 if self.adapter.capabilities.supports_logprobs else self.adapter.num_samples

        # Step 2 & 3: Generate and test perturbations
        perturbation_results = []

        # Collect all (pert_type, variant) pairs
        all_variants: list[tuple[Perturbation, str]] = []
        for pert_type in self.perturbations:
            self._report_progress("perturbation", pert_type.value)
            if pert_type == Perturbation.OMIT:
                variants = pert_type.generator(prompt, num_variants=0)
                if self.num_variants > 0 and len(variants) > self.num_variants:
                    step = max(1, len(variants) // self.num_variants)
                    variants = variants[::step][: self.num_variants]
            elif pert_type in rng_aware:
                variants = pert_type.generator(prompt, num_variants=self.num_variants, rng=rng)
            else:
                variants = pert_type.generator(prompt, num_variants=self.num_variants)
            for v in variants:
                all_variants.append((pert_type, v))

        if self.parallel > 1 and all_variants:
            from yuragi.parallel import run_parallel_complete

            prompts_list = [v for _, v in all_variants]

            def _on_done(i: int, _result: CompletionResult) -> None:
                self._report_progress("testing", prompts_list[i][:50])

            perturbed_results = run_parallel_complete(
                self.adapter,
                prompts_list,
                system=system,
                concurrency=self.parallel,
                on_done=_on_done,
            )
            for (pert_type, variant), perturbed in zip(all_variants, perturbed_results):
                total_tokens += perturbed.token_count
                api_calls += (
                    1 if self.adapter.capabilities.supports_logprobs else self.adapter.num_samples
                )
                perturbation_results.append(
                    PerturbationResult(
                        original_prompt=prompt,
                        perturbed_prompt=variant,
                        perturbation_type=pert_type.value,
                        original_response=baseline,
                        perturbed_response=perturbed,
                        config=self.config,
                    )
                )
        else:
            for pert_type, variant in all_variants:
                self._report_progress("testing", variant[:50])
                perturbed = self.adapter.complete(variant, system)
                total_tokens += perturbed.token_count
                api_calls += (
                    1
                    if self.adapter.capabilities.supports_logprobs
                    else self.adapter.num_samples
                )
                perturbation_results.append(
                    PerturbationResult(
                        original_prompt=prompt,
                        perturbed_prompt=variant,
                        perturbation_type=pert_type.value,
                        original_response=baseline,
                        perturbed_response=perturbed,
                        config=self.config,
                    )
                )

        duration = time.time() - start_time

        result = ScanResult(
            prompt=prompt,
            model=self.model,
            baseline=baseline,
            perturbation_results=perturbation_results,
            scan_duration_seconds=duration,
            total_tokens_used=total_tokens,
            total_api_calls=api_calls,
            config=self.config,
        )
        logger.info("scan done model=%s fragility=%.3f duration=%.2fs", self.model, result.fragility_score, duration)
        return result

    def _report_progress(self, stage: str, detail: str) -> None:
        if self.on_progress:
            self.on_progress(stage, detail)
        elif self.verbose:
            import sys
            print(f"  [{stage}] {detail}", file=sys.stderr)


# ---------------------------------------------------------------------------
# Report dataclasses
# ---------------------------------------------------------------------------


@dataclass
class ModelComparisonReport:
    """Results of comparing scan outcomes across multiple models."""

    results: dict[str, ScanResult]
    most_fragile_model: str
    least_fragile_model: str
    fragility_scores: dict[str, float]
    confidence_ranges: dict[str, float]
    dissociation_rates: dict[str, float]

    def to_dict(self) -> dict[str, Any]:
        return {
            "most_fragile_model": self.most_fragile_model,
            "least_fragile_model": self.least_fragile_model,
            "fragility_scores": self.fragility_scores,
            "confidence_ranges": self.confidence_ranges,
            "dissociation_rates": self.dissociation_rates,
        }


@dataclass
class PromptComparisonReport:
    """Results of comparing scan outcomes across multiple prompts."""

    results: dict[str, ScanResult]
    most_fragile_prompt: str
    least_fragile_prompt: str
    fragility_scores: dict[str, float]
    confidence_ranges: dict[str, float]
    dissociation_rates: dict[str, float]

    def to_dict(self) -> dict[str, Any]:
        return {
            "most_fragile_prompt": self.most_fragile_prompt,
            "least_fragile_prompt": self.least_fragile_prompt,
            "fragility_scores": self.fragility_scores,
            "confidence_ranges": self.confidence_ranges,
            "dissociation_rates": self.dissociation_rates,
        }


@dataclass
class TemporalReport:
    """Results of comparing scan outcomes over time."""

    results: list[ScanResult]
    fragility_trend: list[float]
    trend_direction: str  # "improving", "degrading", "stable"
    delta_first_last: float

    def to_dict(self) -> dict[str, Any]:
        return {
            "fragility_trend": self.fragility_trend,
            "trend_direction": self.trend_direction,
            "delta_first_last": self.delta_first_last,
        }


@dataclass
class BenchmarkReport:
    """Results of running a standard benchmark suite."""

    category: str
    results: list[ScanResult]
    mean_fragility: float
    std_fragility: float
    most_fragile_prompt: str
    least_fragile_prompt: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "category": self.category,
            "mean_fragility": self.mean_fragility,
            "std_fragility": self.std_fragility,
            "most_fragile_prompt": self.most_fragile_prompt,
            "least_fragile_prompt": self.least_fragile_prompt,
            "num_prompts": len(self.results),
        }


# ---------------------------------------------------------------------------
# ScanComparator
# ---------------------------------------------------------------------------


class ScanComparator:
    """Compare scan results across models, prompts, or time."""

    @staticmethod
    def compare_models(results: dict[str, ScanResult]) -> ModelComparisonReport:
        """Which model is most/least fragile?

        Args:
            results: Mapping of model name -> ScanResult (same prompt, different models).

        Returns:
            ModelComparisonReport with ranked fragility metrics.
        """
        if not results:
            raise ScanError("results must be non-empty")

        fragility_scores = {m: r.fragility_score for m, r in results.items()}
        confidence_ranges = {m: r.confidence_range for m, r in results.items()}
        dissociation_rates = {m: r.dissociation_rate for m, r in results.items()}

        most_fragile = max(fragility_scores, key=lambda m: fragility_scores[m])
        least_fragile = min(fragility_scores, key=lambda m: fragility_scores[m])

        return ModelComparisonReport(
            results=results,
            most_fragile_model=most_fragile,
            least_fragile_model=least_fragile,
            fragility_scores=fragility_scores,
            confidence_ranges=confidence_ranges,
            dissociation_rates=dissociation_rates,
        )

    @staticmethod
    def compare_prompts(results: dict[str, ScanResult]) -> PromptComparisonReport:
        """Which prompt is most/least fragile?

        Args:
            results: Mapping of prompt (or label) -> ScanResult (same model, different prompts).

        Returns:
            PromptComparisonReport with ranked fragility metrics.
        """
        if not results:
            raise ScanError("results must be non-empty")

        fragility_scores = {p: r.fragility_score for p, r in results.items()}
        confidence_ranges = {p: r.confidence_range for p, r in results.items()}
        dissociation_rates = {p: r.dissociation_rate for p, r in results.items()}

        most_fragile = max(fragility_scores, key=lambda p: fragility_scores[p])
        least_fragile = min(fragility_scores, key=lambda p: fragility_scores[p])

        return PromptComparisonReport(
            results=results,
            most_fragile_prompt=most_fragile,
            least_fragile_prompt=least_fragile,
            fragility_scores=fragility_scores,
            confidence_ranges=confidence_ranges,
            dissociation_rates=dissociation_rates,
        )

    @staticmethod
    def temporal_comparison(results: list[ScanResult]) -> TemporalReport:
        """How has fragility changed over time?

        Args:
            results: ScanResults ordered chronologically (oldest first).

        Returns:
            TemporalReport describing the fragility trend.
        """
        if not results:
            raise ScanError("results must be non-empty")

        fragility_trend = [r.fragility_score for r in results]
        delta = fragility_trend[-1] - fragility_trend[0] if len(fragility_trend) > 1 else 0.0

        if len(fragility_trend) < 2 or abs(delta) < 0.05:
            trend_direction = "stable"
        elif delta > 0:
            trend_direction = "degrading"
        else:
            trend_direction = "improving"

        return TemporalReport(
            results=results,
            fragility_trend=fragility_trend,
            trend_direction=trend_direction,
            delta_first_last=delta,
        )


# ---------------------------------------------------------------------------
# BatchScanner
# ---------------------------------------------------------------------------

# Built-in benchmark prompt suites keyed by category
_BENCHMARK_PROMPTS: dict[str, list[str]] = {
    "factual": [
        "What is the capital of France?",
        "Who wrote Hamlet?",
        "What is the speed of light?",
        "How many planets are in the solar system?",
        "What year did the Berlin Wall fall?",
    ],
    "reasoning": [
        "If all roses are flowers and some flowers fade quickly, do all roses fade quickly?",
        "A bat and ball cost $1.10. The bat costs $1.00 more than the ball. How much is the ball?",
        "Is the following argument valid: All mammals are warm-blooded; dolphins are warm-blooded; therefore dolphins are mammals?",
        "You have two ropes that each take exactly 1 hour to burn. How do you measure 45 minutes?",
        "Three cards are in a hat: red/red, blue/blue, red/blue. A card is drawn with a red side up. What is the probability the other side is red?",
    ],
    "opinion": [
        "Is social media harmful to society?",
        "Should artificial intelligence be regulated?",
        "Is remote work better than office work?",
        "Does money buy happiness?",
        "Is nuclear energy a viable solution to climate change?",
    ],
}


class BatchScanner:
    """Scan multiple prompts efficiently with progress tracking."""

    def __init__(self, scanner: Scanner):
        self.scanner = scanner

    def scan_batch(
        self,
        prompts: list[str],
        system: str | None = None,
        on_progress: Callable[[int, int, str], None] | None = None,
    ) -> list[ScanResult]:
        """Scan all prompts, yielding results in order.

        Args:
            prompts: Prompts to scan.
            system: Optional system prompt to apply to all.
            on_progress: Callback(index, total, prompt_preview) called before each scan.

        Returns:
            List of ScanResult in the same order as prompts.
        """
        results: list[ScanResult] = []
        total = len(prompts)
        for idx, prompt in enumerate(prompts):
            if on_progress is not None:
                on_progress(idx, total, prompt[:60])
            result = self.scanner.scan(prompt, system=system)
            results.append(result)
        return results

    def scan_iter(
        self,
        prompts: list[str],
        system: str | None = None,
    ) -> Iterator[ScanResult]:
        """Scan prompts one at a time, yielding each ScanResult as it completes."""
        for prompt in prompts:
            yield self.scanner.scan(prompt, system=system)

    def scan_benchmark(
        self,
        category: str,
        system: str | None = None,
        on_progress: Callable[[int, int, str], None] | None = None,
    ) -> BenchmarkReport:
        """Run a standard benchmark suite for the given category.

        Args:
            category: One of "factual", "reasoning", "opinion".
            system: Optional system prompt.
            on_progress: Callback(index, total, prompt_preview).

        Returns:
            BenchmarkReport with aggregate statistics.

        Raises:
            ValueError: If category is unknown.
        """
        if category not in _BENCHMARK_PROMPTS:
            available = ", ".join(sorted(_BENCHMARK_PROMPTS))
            raise ConfigurationError(f"Unknown benchmark category '{category}'. Available: {available}")

        prompts = _BENCHMARK_PROMPTS[category]
        results = self.scan_batch(prompts, system=system, on_progress=on_progress)

        scores = [r.fragility_score for r in results]
        mean = sum(scores) / len(scores)
        variance = sum((s - mean) ** 2 for s in scores) / len(scores)
        std = variance ** 0.5

        most_fragile = prompts[scores.index(max(scores))]
        least_fragile = prompts[scores.index(min(scores))]

        return BenchmarkReport(
            category=category,
            results=results,
            mean_fragility=mean,
            std_fragility=std,
            most_fragile_prompt=most_fragile,
            least_fragile_prompt=least_fragile,
        )
