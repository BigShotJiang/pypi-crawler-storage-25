"""yuragi compare-models — fragility profile comparison across multiple LLMs.

Runs the same prompts through multiple models and produces a comparison
report with fragility scores, statistical tests, and an optional heatmap.

APU-safe defaults: parallel=1, mem-limit-gb=20, keep-alive='2m'.
"""

from __future__ import annotations

import json
import sys

import click
from rich import box
from rich.console import Console
from rich.table import Table

from yuragi.core import Scanner

console = Console()


def _check_memory(mem_limit_gb: float) -> bool:
    """Return True if available RAM >= mem_limit_gb, False otherwise."""
    try:
        import psutil

        available_gb = psutil.virtual_memory().available / (1024**3)
        return available_gb >= mem_limit_gb
    except ImportError:
        return True


def _load_prompts_from_file(path: str) -> list[str]:
    """Load prompts from a JSONL file (one JSON string or {"prompt": ...} per line)."""
    prompts = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
                if isinstance(obj, str):
                    prompts.append(obj)
                elif isinstance(obj, dict):
                    prompts.append(obj.get("prompt") or obj.get("question") or str(obj))
            except json.JSONDecodeError:
                prompts.append(line)
    return prompts


@click.command("compare-models")
@click.option("--models", required=True, help="Comma-separated model names")
@click.option("--prompts", "-p", multiple=True, help="Prompt(s) to test")
@click.option(
    "--prompts-file",
    type=click.Path(exists=True),
    default=None,
    help="JSONL file of prompts",
)
@click.option("--num-variants", default=3, type=int, help="Variants per perturbation type")
@click.option("--parallel", default=1, type=int, help="APU-safe default: 1")
@click.option("--keep-alive", default="2m", help="Ollama keep_alive setting")
@click.option(
    "--mem-limit-gb",
    default=20.0,
    type=float,
    help="Skip model if available RAM (GB) is below this",
)
@click.option("--output", default="compare_report.json", help="JSON report output path")
@click.option("--heatmap", default=None, help="Optional path to save heatmap PNG")
@click.option("--json-output", "-j", is_flag=True, help="Print report JSON to stdout")
@click.pass_context
def compare_models(
    ctx: click.Context,
    models: str,
    prompts: tuple[str, ...],
    prompts_file: str | None,
    num_variants: int,
    parallel: int,
    keep_alive: str,
    mem_limit_gb: float,
    output: str,
    heatmap: str | None,
    json_output: bool,
) -> None:
    """Compare fragility across multiple models.

    Example:
        yuragi compare-models --models qwen3:4b,phi4-mini,gemma3:4b -p "What is 2+2?"
    """
    quiet = ctx.obj.get("quiet", False) if ctx.obj else False

    model_list = [m.strip() for m in models.split(",") if m.strip()]
    if not model_list:
        console.print("[red]No models specified.[/red]")
        sys.exit(1)

    all_prompts: list[str] = list(prompts)
    if prompts_file:
        all_prompts.extend(_load_prompts_from_file(prompts_file))

    if not all_prompts:
        console.print("[red]No prompts specified. Use -p or --prompts-file.[/red]")
        sys.exit(1)

    if not quiet:
        console.print(
            f"[cyan]compare-models:[/cyan] {len(model_list)} models x {len(all_prompts)} prompt(s)"
        )

    # scores[model][prompt_label] = fragility_score
    scores: dict[str, dict[str, float]] = {}
    report: dict = {"models": {}, "prompts": all_prompts}

    for model_name in model_list:
        if not _check_memory(mem_limit_gb):
            console.print(
                f"[yellow]Skipping {model_name}: available RAM < {mem_limit_gb} GB[/yellow]"
            )
            continue

        if not quiet:
            console.print(f"\n[dim]Scanning model: {model_name}[/dim]")

        model_scores: dict[str, float] = {}
        model_results = []

        for prompt_idx, prompt_text in enumerate(all_prompts):
            # Use a unique label so two prompts that share the first 50 chars
            # do not overwrite each other in the scores dict / heatmap.
            prompt_label = f"[{prompt_idx}] {prompt_text[:50]}"
            scanner = Scanner(
                model=model_name,
                num_variants=num_variants,
                num_samples=3,
            )
            try:
                result = scanner.scan(prompt_text)
                model_scores[prompt_label] = result.fragility_score
                model_results.append(result)
                if not quiet:
                    console.print(
                        f"  [dim]{prompt_label[:40]}...[/dim] "
                        f"fragility=[cyan]{result.fragility_score:.3f}[/cyan]"
                    )
            except Exception as e:
                console.print(f"  [yellow]Skipped ({prompt_label[:30]}): {e}[/yellow]")

        if model_scores:
            scores[model_name] = model_scores
            avg = sum(model_scores.values()) / len(model_scores)
            report["models"][model_name] = {
                "fragility_scores": model_scores,
                "avg_fragility": avg,
            }

    if not scores:
        console.print("[red]No results obtained.[/red]")
        sys.exit(1)

    # Statistical comparison (if >= 2 models with >= 2 results)
    model_names = list(scores.keys())
    if len(model_names) >= 2:
        try:
            from yuragi.metrics.statistical_tests import cohens_d as _cohens_d

            deltas_a = list(scores[model_names[0]].values())
            deltas_b = list(scores[model_names[1]].values())
            if len(deltas_a) >= 2 and len(deltas_b) >= 2:
                eff = _cohens_d(deltas_a, deltas_b)
                report["cohens_d"] = {
                    "value": eff.cohens_d,
                    "interpretation": eff.interpretation,
                    "models": [model_names[0], model_names[1]],
                }
        except Exception:
            pass

    # Save JSON report
    with open(output, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)

    if not quiet:
        console.print(f"\n[green]Report saved to {output}[/green]")

    if json_output:
        print(json.dumps(report, indent=2, ensure_ascii=False))
        return

    if not quiet:
        table = Table(title="Multi-Model Fragility Comparison", box=box.ROUNDED)
        table.add_column("Model", style="cyan")
        table.add_column("Avg Fragility", width=14)
        table.add_column("Prompts Scored", width=15)

        for name, info in sorted(
            report["models"].items(), key=lambda x: x[1]["avg_fragility"], reverse=True
        ):
            table.add_row(
                name,
                f"{info['avg_fragility']:.3f}",
                str(len(info["fragility_scores"])),
            )
        console.print(table)

    # Optional heatmap
    if heatmap:
        try:
            from yuragi.visualize.multi_model_heatmap import plot_multi_model_heatmap

            plot_multi_model_heatmap(scores, save_path=heatmap)
            if not quiet:
                console.print(f"[green]Heatmap saved to {heatmap}[/green]")
        except Exception as e:
            console.print(f"[yellow]Heatmap generation failed: {e}[/yellow]")
