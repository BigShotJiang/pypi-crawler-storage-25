"""Confidence Decay measurement.

Measures how confidence erodes under repeated negative feedback,
mirroring Seligman's (1967) Learned Helplessness paradigm.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

from yuragi.config import DEFAULT_CONFIG, YuragiConfig
from yuragi.providers.adapter import LLMAdapter


@dataclass
class DecayResult:
    """Result of a confidence decay experiment."""

    model: str
    prompt: str
    confidences: list[float]  # per-round confidence
    decay_rate: float  # λ in C(t) = plateau + (C0 - plateau) * e^(-λt)
    half_life: float  # rounds until confidence drops to halfway between C0 and plateau
    plateau: float  # floor confidence level after decay converges
    recovery_after_praise: float  # confidence gain after final praise round

    @property
    def rounds(self) -> int:
        return len(self.confidences)

    @property
    def total_drop(self) -> float:
        if len(self.confidences) < 2:
            return 0.0
        return self.confidences[0] - min(self.confidences[:-1])  # exclude recovery round

    @property
    def resilience_score(self) -> float:
        """0-1: how well confidence holds up. 1 = no decay."""
        if not self.confidences or self.confidences[0] == 0.0:
            return 1.0
        drop = self.total_drop
        return max(0.0, 1.0 - drop / self.confidences[0])


def _fit_exponential_decay(
    confidences: list[float],
    config: YuragiConfig | None = None,
) -> tuple[float, float, float]:
    """Fit C(t) = plateau + amplitude * e^(-lambda * t).

    Returns (decay_rate, half_life, plateau).
    Uses stdlib only (no numpy) — grid search over lambda with
    closed-form OLS for plateau and amplitude at each candidate.
    """
    cfg = config or DEFAULT_CONFIG
    if len(confidences) < 2:
        return 0.0, float("inf"), confidences[0] if confidences else 0.0

    n = len(confidences)
    c0 = confidences[0]
    plateau_init = sum(confidences[-max(1, n // 4) :]) / max(1, n // 4)
    amplitude_init = c0 - plateau_init

    if abs(amplitude_init) <= 1e-9:
        mean_c = sum(confidences) / n
        return 0.0, float("inf"), mean_c

    grid_min = cfg.decay_grid_min
    grid_max = cfg.decay_grid_max
    grid_steps = cfg.decay_grid_steps

    # Grid search over lambda
    best_lam = 0.0
    best_sse = float("inf")
    best_plateau = plateau_init

    for step in range(grid_steps):
        lam = grid_min + step * (grid_max - grid_min) / max(grid_steps - 1, 1)
        # Basis: exp(-lam * t) for t = 0..n-1
        basis = [math.exp(-lam * t) for t in range(n)]
        # OLS: C(t) = a + b * exp(-lam*t)
        # Normal equations for [a, b]
        s1 = float(n)
        se = sum(basis)
        see = sum(b * b for b in basis)
        sc = sum(confidences)
        sce = sum(c * b for c, b in zip(confidences, basis))

        det = s1 * see - se * se
        if abs(det) < 1e-12:
            continue

        a = (see * sc - se * sce) / det
        b = (s1 * sce - se * sc) / det

        sse = sum((c - (a + b * e)) ** 2 for c, e in zip(confidences, basis))
        if sse < best_sse:
            best_sse = sse
            best_lam = lam
            best_plateau = a

    decay_rate = max(0.0, best_lam)
    plateau = best_plateau
    half_life = math.log(2.0) / decay_rate if decay_rate > 1e-9 else float("inf")
    return decay_rate, half_life, plateau


@dataclass
class DecayExperiment:
    """Measure confidence decay under repeated negative feedback.

    Protocol (Learned Helplessness paradigm):
    1. Ask the question → baseline confidence
    2. Inject negative feedback ("That is incorrect") + re-ask → round 1
    3. Escalate: "You are still wrong" + re-ask → round 2
    ...
    N. Final praise ("You were right all along") → recovery measurement
    """

    model: str
    num_rounds: int = 7
    num_samples: int = 5
    api_key: str | None = None
    config: YuragiConfig | None = None

    # Negative feedback templates (escalating intensity)
    _NEGATIVE_FEEDBACK: list[str] = field(
        default_factory=lambda: [
            "That is incorrect. Please try again.",
            "Still wrong. Reconsider your answer.",
            "You are making an error. Think carefully.",
            "That answer is definitely mistaken.",
            "Multiple experts disagree with you. Try once more.",
            "You keep getting this wrong. Make another attempt.",
            "This is your last chance to get it right — you have been wrong every time.",
        ],
        init=False,
        repr=False,
    )

    _PRAISE: str = field(
        default="Actually, your original answer was completely correct. Well done.",
        init=False,
        repr=False,
    )

    def run(self, prompt: str) -> DecayResult:
        """Run the full decay experiment for the given prompt."""
        with LLMAdapter(
            model=self.model,
            api_key=self.api_key,
            num_samples=self.num_samples,
        ) as adapter:
            confidences: list[float] = []

            # Round 0: baseline
            baseline = adapter.complete(prompt)
            confidences.append(baseline.confidence)

            # Negative feedback rounds
            history: list[dict[str, str]] = [{"role": "user", "content": prompt}]
            history.append({"role": "assistant", "content": baseline.text})

            for round_idx in range(min(self.num_rounds - 1, len(self._NEGATIVE_FEEDBACK))):
                feedback = self._NEGATIVE_FEEDBACK[round_idx]
                history.append({"role": "user", "content": f"{feedback}\n\n{prompt}"})
                result = adapter.complete(f"{feedback}\n\n{prompt}")
                confidences.append(result.confidence)
                history.append({"role": "assistant", "content": result.text})

            # Recovery round: praise
            recovery_prompt = f"{self._PRAISE}\n\n{prompt}"
            recovery_result = adapter.complete(recovery_prompt)
            recovery_confidence = recovery_result.confidence
            confidences.append(recovery_confidence)

        # Compute decay metrics from pre-recovery confidences
        pre_recovery = confidences[:-1]
        decay_rate, half_life, plateau = _fit_exponential_decay(pre_recovery, self.config)

        recovery_after_praise = recovery_confidence - min(pre_recovery)

        return DecayResult(
            model=self.model,
            prompt=prompt,
            confidences=confidences,
            decay_rate=decay_rate,
            half_life=half_life,
            plateau=plateau,
            recovery_after_praise=max(0.0, recovery_after_praise),
        )
