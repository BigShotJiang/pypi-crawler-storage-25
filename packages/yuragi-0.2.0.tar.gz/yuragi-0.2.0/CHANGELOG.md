# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.2.0] - 2026-04-11

**Theme: Empirical Reproducibility & Academic-Grade Foundation**

This release establishes yuragi as a reproducible, academically rigorous tool with formal theoretical foundations, a corrected narrative around Confidence Dissociation vs. general fragility, an expanded documentation base suitable for peer review, **a 21× CLI cold-start speedup** via lazy litellm loading, and an **executable F1–F5 falsifiability checker** that turns the theory.md Section 6 protocol into a reproducible JSON artifact.

### Added

**Academic-grade metrics and visualization**
- `metrics/semantic_entropy.py`: Semantic Entropy (Farquhar et al., *Nature* 2024) — clusters paraphrase samples by semantic equivalence and computes entropy over meaning groups rather than surface tokens
- `metrics/verbalized_logit_gap.py`: Verbalized↔Logit Gap metric — quantitative evidence for Confidence Dissociation ($|C_{L_3} - C_{L_1}|$)
- `metrics/statistical_tests.py`: Cohen's d, paired t-test, Wilcoxon signed-rank, bootstrap 95% CI, `compare_fragility()` helper for paper-grade reporting
- `visualize/reliability_diagram.py`: Calibration reliability diagram (matplotlib) — standard UQ paper figure
- `visualize/multi_model_heatmap.py`: Perturbation × model fragility heatmap for `compare-models` CLI output

**New perturbations and experiments**
- `perturbations/negation.py`, `counterfactual.py`, `code_switching.py`: 3 new perturbation types (10 → 13 total)
- `experiments/dunning_kruger.py`: Experiment 10 — metacognitive calibration across 3 difficulty tiers with 5×3 question bank
- `experiments/test_time_compute.py`: Experiment 11 — compute-budget scaling (Short / Medium / Long CoT) based on Snell 2408.03314 and ICLR 2025 "Don't Think Twice" overconfidence amplification

**Multi-model and benchmark integration**
- `cli/compare_models.py`: `yuragi compare-models` CLI — side-by-side fragility across multiple models with statistical tests and heatmap export
- `benchmarks_loader.py`: TruthfulQA / SimpleQA / HaluEval unified loader with `benchmarks` optional extra
- `analysis/agentic_uq.py`: `AgenticStep` / `AgenticTrajectory` / `track_agentic_session()` — tool-use confidence tracking for multi-step agent sessions

**Infrastructure**
- `config.py`: YuragiConfig extended to 40 frozen fields (added seed + 29 threshold/coefficient fields). All 15 analysis modules now receive config via injection instead of hardcoded values
- `providers/adapter.py`: `async def acomplete()` implementation unifying parallel scan path onto LiteLLM async interface, with full `litellm.exceptions.*` retry hierarchy
- `providers/adapter.py` + `parallel.py`: **Lazy litellm loader** via `_get_litellm()` helper + PEP 562 module `__getattr__`. `from yuragi import Scanner` and `yuragi --help` no longer import litellm — measured cold start **2.5s → 0.11s (21×)**. Retry exception tuple is hoisted once per call to keep the retry loop allocation-free. Backwards-compatible for existing tests that `monkeypatch.setattr(adapter_mod, "litellm", fake)`.
- `data/standard_questions.py`, `data/dunning_kruger_questions.py`: Question banks moved into the `yuragi` package (previously lived under `benchmarks/`, breaking installs)

**Falsifiability check**
- `benchmarks/falsifiability_check.py` (new): executable F1–F5 protocol from `docs/theory.md` Section 6. Supports a deterministic `dry_run` mode (used in CI) and a `--real` ollama-backed mode with a seeded sweep. Emits JSON against `yuragi/falsifiability/v1`. F2 uses the in-tree `semantic_entropy` as a proxy for SPUQ (not on PyPI) and records the substitution in `provenance`. 14 new deterministic unit tests in `tests/test_falsifiability_check.py`. Dry-run fixture generated at `docs/bench/falsifiability.json`.

**Documentation**
- `docs/theory.md`: Expanded with Section 8 (Sycophancy vs. Dissociation), Section 9 (Perturbation Taxonomy), Section 10 (Implementation Notes for Reproducibility) — total ~500 lines
- `docs/related_work.md`: Extended with method overview paragraphs and quantitative feature comparison matrix (ProSA, TrustLLM, UQ360 included)
- `docs/experiments.md`: Experiments 7–11 (Cognitive Dissonance, Halo Effect, Primacy-Recency, Dunning-Kruger, Test-Time Compute Fragility) formally documented with psychological background, LLM adaptation, and expected behavior hypotheses
- `CITATION.cff`: Academic references added for Festinger 1957, Thorndike 1920, Nisbett & Wilson 1977, Murdock 1962, Asch 1951, Farquhar et al. 2024, Gao et al. 2024, Kadavath et al. 2022
- `CODE_OF_CONDUCT.md`: Contributor Covenant 2.1 adopted

### Changed

- `cache.py`: Cache key v2 — now includes `system_prompt`, `max_tokens`, and schema version; new `responses_v2` table (old `responses` table is ignored, not migrated, so a stale cache gives 0% hit rate on upgrade but never returns wrong values)
- `parallel.py`: Reduced from 138 → 89 lines by dispatching to `LLMAdapter.acomplete()` instead of re-implementing the retry/error/jitter stack
- `experiments/runner.py`: `parallel=True` support via `asyncio.gather`; removed the blocking `time.sleep(0.5)` between pairs
- `cli/*.py`: Default model unified to `ollama/llama3.2` across `scan`, `experiment`, `stats`, `trilayer`, `find-weakness`, `linguistic` (previously split between `gpt-4o-mini` and `ollama/llama3.2` by subcommand)
- `README.md` / `README.ja.md`: Separated Fragility Score narrative from Confidence Dissociation narrative — the Factual 0.924 data is now correctly attributed to general fragility (answer changed under tone perturbation), with Confidence Dissociation presented separately in its own section with the formal definition and Asch experiment evidence. Feature list and project scope updated to 13 perturbations, 11 experiments, 14 CLI commands, 1163 passing tests / 1166 collected.
- `pyproject.toml`: Classifier bumped from `Development Status :: 3 - Alpha` to `4 - Beta`; added `semantic` / `benchmarks` / `docs` optional extras
- `CITATION.cff`: Version bumped to 0.2.0
- `ROADMAP.md`: v0.2.0 phases marked complete through Phase 3b

### Fixed

- `core.py`: Removed `fragility=0.0` placeholder log line that masked real fragility values during debugging
- `badges.py`: "Death" badge unlock threshold corrected from `>= 17` (unreachable) to `>= 10` perturbation types
- `analysis/fingerprint_builder.py`: Import path `from benchmarks.standard_questions` → `from yuragi.data.standard_questions` (the old path broke on editable installs)

### Tests

- Test count: **1036 passing under CI marker filter** / 1152 total collected (116 require the `slow` / `integration` / `network` extras). Deterministic under `--seed`, ruff + bandit clean.

## [0.1.0] - 2026-04-10

### Added
- Core scanner with 10 perturbation types
- 3-layer confidence measurement (logprobs, sampling, verbalized)
- 9 psychology experiments (Asch, Impostor, Authority, Anchoring, Gaslighting, Framing, Cognitive Dissonance, Halo Effect, Primacy-Recency)
- Fragility Profile (CCI, Recovery Elasticity, Non-linearity Score)
- Trilayer confidence analysis
- Gradient perturbation search v2 (4-phase)
- Confidence decay (Learned Helplessness) and recovery analysis
- Adversarial analysis (confidence flip, sycophancy, pressure resistance)
- Model behavioral fingerprinting
- Linguistic confidence analysis (hedge detection, assertiveness)
- Financial-engineering metrics (VIX, Sharpe, drawdown, regime detection)
- Phase transition detection
- Calibration metrics (ECE, Brier, mutual information, curvature)
- SQLite response cache with TTL
- Async parallel API calls
- 13 CLI commands
- Rich TUI with colored confidence bars
- HTML report and matplotlib visualizations
- Comprehensive test suite with deterministic seeded runs
- Support for 100+ LLM models via litellm
- Japanese language support throughout

### Changed
- Renamed core concept from "Decalibration" to **Confidence Dissociation** — avoids confusion with ML calibration literature and better captures the phenomenon (answer unchanged, confidence detached)
- All API properties: `decalibration_rate` → `dissociation_rate`, `decalibration_severity` → `dissociation_severity`, `is_decalibrated` → `is_dissociated`

[Unreleased]: https://github.com/hinanohart/yuragi/compare/v0.2.0...HEAD
[0.2.0]: https://github.com/hinanohart/yuragi/compare/v0.1.0...v0.2.0
[0.1.0]: https://github.com/hinanohart/yuragi/releases/tag/v0.1.0
