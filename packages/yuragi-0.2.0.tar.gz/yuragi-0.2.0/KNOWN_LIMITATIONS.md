# Known Limitations

This document lists known limitations and unresolved issues in yuragi v0.2.0. Resolved items are removed; items in progress include a milestone reference.

---

## Measurement Limitations

### L1: Logprob Unavailability for Closed-Source Models

The logprob confidence layer ($C_{L_1}$) requires the model API to expose token-level log-probabilities. Several major providers (Anthropic Claude, Google Gemini) do not provide this. For these models, yuragi falls back to the sampling layer ($C_{L_2}$) only. The trilayer divergence signal and internal conflict detection are unavailable.

**Impact**: Reduced diagnostic depth for Claude and Gemini models. The dissociation measure still works via $C_{L_2}$ and $C_{L_3}$.

**Mitigation planned**: Investigate proxy methods for logprob estimation via sampling entropy. No milestone assigned.

---

### L2: Similarity Threshold Not Human-Validated

The dissociation threshold $\tau_{\text{sim}} = 0.8$ (character 3-gram Jaccard) used to determine whether the answer changed was chosen empirically, not validated against human annotations.

**Impact**: The dissociation rate metric may over- or under-count depending on the prompt type. Short answers (single words) have high Jaccard sensitivity; long answers have low sensitivity to partial changes.

**Mitigation planned**: Human-validated threshold study is a Phase 1 milestone.

---

### L3: Verbalized Confidence Parsing Fallback

When the model does not produce a parseable integer in [0, 100] in response to the verbalized confidence elicitation, yuragi falls back to 50 (unknown). This fallback conflates "model refused to report confidence" with "model is 50% confident."

**Impact**: Edge cases in verbalized confidence measurement may produce misleading Layer 3 readings.

**Status**: Logged. A future version will distinguish `None` (refused to report) from `50` (reported 50).

---

### L4: Single-Prompt Fragility Measurement

`yuragi scan` measures fragility for a single prompt at a time. Fragility scores are not normalized against a baseline population of prompts from the same category, so a score of 0.6 for one prompt cannot be directly compared to a score of 0.6 from a different prompt without context.

**Impact**: Cross-prompt comparisons require running the same model on a standardized prompt set (use `benchmarks/` for this).

---

## Empirical Limitations

### L5: No Controlled Dissociation Benchmark (Pending Phase 1)

The Confidence Dissociation metric is theoretically defined and demonstrable in individual experiments, but a controlled, reproducible benchmark measuring dissociation rates across multiple models on a standardized prompt set does not yet exist.

**Milestone**: `benchmarks/dissociation_reproducibility.py` — Phase 1 deliverable.

---

### L6: Psychology Experiments Use Small Sample Sizes

The default experiment runs 5 control/treatment pairs per experiment. This is sufficient for qualitative demonstration but underpowered for statistical inference (Cohen's d confidence intervals are wide at n=5).

**Recommendation**: Use `--num-samples 20` or higher for publication-quality measurements. The `yuragi stats` command reports bootstrap confidence intervals.

---

### L7: Anchoring Experiment Answer Similarity Metric Is Approximate

For the anchoring experiment (Experiment 4), the primary effect of interest is the *magnitude* of numerical shift toward the anchor, not binary answer change. The character n-gram Jaccard similarity metric does not capture this magnitude — "54" and "55" would score as low-similarity despite being close numerically.

**Workaround**: Export raw responses with `--json-output` and parse numerical values manually for anchoring magnitude analysis.

---

## Infrastructure Limitations

### L8: No Multi-Turn Session Support

yuragi measures single-turn prompt-response pairs. Multi-turn confidence dynamics (how confidence evolves across a conversation) are partially supported via `yuragi trajectory challenge`, but full session-level confidence tracking is not implemented.

**Milestone**: Considered for v0.3.0.

---

### L9: Local Model Behavior Depends on Ollama Version

Confidence measurements using local models via Ollama depend on Ollama's logprob implementation, which has changed across versions. Results may not be reproducible across Ollama version upgrades.

**Recommendation**: Pin Ollama version in your environment when collecting reproducible results.

---

## Open Research Questions

The following are not implementation limitations but unresolved empirical questions:

1. **Does dissociation scale with model size?** Larger models may have stronger self-models ($C_{L_3}$ accuracy), but logprob-level fragility may be unchanged or worse.
2. **Can dissociation be reduced by training?** RLHF and instruction tuning may address sycophancy but leave dissociation untouched. This is an open question.
3. **Cross-lingual dissociation**: Does the same factual question in different languages produce different dissociation profiles? Preliminary observations suggest yes; systematic study is needed.
4. **Is high dissociation a hallucination risk signal?** A model that answers correctly but with highly variable confidence may be near a knowledge boundary where hallucination is more likely. This connection is hypothesized but not empirically confirmed.
