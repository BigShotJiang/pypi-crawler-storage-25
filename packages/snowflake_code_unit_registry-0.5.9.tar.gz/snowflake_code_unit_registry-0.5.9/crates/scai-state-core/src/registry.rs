//! Code Unit Registry – file operations for the code unit registry
//!
//! CodeUnit files are stored flat in `./registry/{id}.json` where id is a UUID v4.

use fs2::FileExt;
use std::fs::{self, File};
use std::io::{Read, Write};
use std::path::{Path, PathBuf};

use rayon::prelude::*;
use serde_json::Value;

use crate::checksum::{
    apply_checksums, find_sql_file_changes, validate_checksum_report, ChecksumMode,
    ChecksumValidationReport, SourceCodeChanges,
};
use crate::error::*;
use crate::filter::Filter;
use crate::generated::types::CodeUnit;
use snafu::IntoError;

mod graph;
mod in_memory;
mod loader;
pub(crate) mod paths;
mod query;
#[cfg(test)]
pub(crate) mod test_helpers;
use in_memory::InMemoryRegistry;

/// ID placeholder used in batch operations when a code unit has no ID.
pub const UNKNOWN_ID: &str = "unknown";

/// Subdirectory name where code unit JSON files are stored.
const REGISTRY_DIR: &str = "registry";

/// The kind of write operation that triggered a lifecycle hook.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum ChangeType {
    Create,
    Update,
    Upsert,
    Delete,
}

/// A pending write operation with before/after snapshots.
///
/// Hooks receive a mutable slice of these and may transform the `after`
/// field before the data is persisted:
/// - `Some(unit)` in `after` → write this unit to disk
/// - `None` in `after` → no unit should exist on disk for this ID
///   (delete the file if it existed, or skip the create)
#[derive(Debug, Clone)]
pub(crate) struct CodeUnitChange {
    pub(crate) id: String,
    /// Snapshot of the unit before this operation (`None` for creates).
    pub(crate) before: Option<CodeUnit>,
    /// The intended new disk state. Hooks may modify this.
    pub(crate) after: Option<CodeUnit>,
}

/// Options passed to every write operation and forwarded to hooks.
#[derive(Debug, Clone, Copy, Default)]
pub struct WriteOptions {
    pub checksum_mode: ChecksumMode,
}

/// Before-persist hook for registry write operations.
///
/// Hooks are chained: each receives the previous hook's output. They may
/// transform, filter, or append [`CodeUnitChange`] entries. If a hook
/// returns `Err`, the operation is aborted and nothing is written to disk.
pub(crate) trait RegistryHook {
    fn before_persist(
        &self,
        _kind: ChangeType,
        changes: Vec<CodeUnitChange>,
        _registry: &CodeUnitRegistry,
        _options: &WriteOptions,
    ) -> Result<Vec<CodeUnitChange>> {
        Ok(changes)
    }
}

/// Built-in hook that recomputes file checksums based on [`WriteOptions::checksum_mode`].
/// Runs first so downstream hooks see the final checksum values.
pub(crate) struct ChecksumHook;

impl RegistryHook for ChecksumHook {
    fn before_persist(
        &self,
        _kind: ChangeType,
        changes: Vec<CodeUnitChange>,
        registry: &CodeUnitRegistry,
        options: &WriteOptions,
    ) -> Result<Vec<CodeUnitChange>> {
        if options.checksum_mode.is_none() {
            return Ok(changes);
        }
        let mut result = changes;
        for change in &mut result {
            if let Some(unit) = &mut change.after {
                apply_checksums(unit, &options.checksum_mode, &registry.root)?;
            }
        }
        Ok(result)
    }
}

/// Built-in hook that recomputes dependency-derived fields (topological
/// rank, `requiredBy`, `isMissing`, `hasTransitiveMissingDependencies`)
/// purely in-memory, appending extra [`CodeUnitChange`] entries for any
/// units whose derived fields changed.
///
/// Uses **scoped refresh** when possible: only nodes reachable from the
/// changed units' dependency edges are recomputed. Falls back to a full
/// refresh when any seed unit has `planning == None` (meaning `requiredBy`
/// is not populated yet and upward traversal cannot be trusted).
pub(crate) struct DependencyRefreshHook;

impl DependencyRefreshHook {
    /// Extract dependency edge IDs from a unit for seeding the graph refresh.
    fn dependency_seeds(unit: &CodeUnit) -> Vec<String> {
        let Some(deps) = &unit.dependencies else {
            return vec![];
        };
        let depends_on = deps.depends_on.iter().filter_map(|dep| dep.id.clone());
        let required_by = deps.required_by.iter().cloned();
        depends_on.chain(required_by).collect()
    }

    /// Apply incoming changes to the in-memory store and collect seed IDs
    /// for the graph refresh. Returns a position index mapping change IDs
    /// to their slot in the result vec.
    fn apply_changes(
        changes: &[CodeUnitChange],
        in_memory: &mut InMemoryRegistry,
    ) -> (std::collections::HashMap<String, usize>, Vec<String>) {
        let mut id_to_pos = std::collections::HashMap::new();
        let mut seed_ids = Vec::new();

        for (i, c) in changes.iter().enumerate() {
            seed_ids.push(c.id.clone());

            if let Some(before) = &c.before {
                seed_ids.extend(Self::dependency_seeds(before));
            }
            if let Some(after) = &c.after {
                seed_ids.extend(Self::dependency_seeds(after));
            }

            if let Some(mem_idx) = in_memory.id_to_index(&c.id) {
                match &c.after {
                    Some(unit) => *in_memory.unit_mut(mem_idx) = unit.clone(),
                    None => in_memory.remove_unit(&c.id),
                }
            } else if let Some(unit) = &c.after {
                in_memory.add_unit(unit.clone());
            }
            id_to_pos.insert(c.id.clone(), i);
        }

        (id_to_pos, seed_ids)
    }

    /// Run a scoped or full graph refresh depending on whether all seed
    /// units have `planning` populated.
    fn refresh_graph(seed_ids: &[String], in_memory: &mut InMemoryRegistry) -> Result<Vec<usize>> {
        let needs_full = seed_ids
            .iter()
            .filter_map(|id| in_memory.id_to_index(id))
            .any(|i| in_memory.unit(i).planning.is_none());

        if needs_full {
            in_memory.graph().refresh(false)
        } else {
            let seeds: Vec<usize> = seed_ids
                .iter()
                .filter_map(|id| in_memory.id_to_index(id))
                .collect();
            in_memory.graph().refresh_scoped(&seeds, false)
        }
    }

    /// Merge graph-refreshed units back into the change set.
    ///
    /// Units already in the change set get their `after` updated in place.
    /// Transitively dirtied units are appended with `before` from the
    /// pre-refresh snapshot so downstream hooks see an accurate diff.
    fn merge_refreshed(
        mut result: Vec<CodeUnitChange>,
        id_to_pos: &mut std::collections::HashMap<String, usize>,
        dirty: &[usize],
        in_memory: &InMemoryRegistry,
        pre_refresh: &[CodeUnit],
    ) -> Vec<CodeUnitChange> {
        for &i in dirty {
            let refreshed = in_memory.unit(i);
            let Some(id) = refreshed.id.clone() else {
                continue;
            };
            match id_to_pos.get(&id) {
                Some(&pos) => {
                    if let Some(ref mut after) = result[pos].after {
                        *after = refreshed.clone();
                    }
                }
                None => {
                    let before = pre_refresh.get(i).cloned();
                    id_to_pos.insert(id.clone(), result.len());
                    result.push(CodeUnitChange {
                        id,
                        before,
                        after: Some(refreshed.clone()),
                    });
                }
            }
        }
        result
    }
}

impl RegistryHook for DependencyRefreshHook {
    fn before_persist(
        &self,
        _kind: ChangeType,
        changes: Vec<CodeUnitChange>,
        registry: &CodeUnitRegistry,
        _options: &WriteOptions,
    ) -> Result<Vec<CodeUnitChange>> {
        let mut in_memory = InMemoryRegistry::build(registry)?;
        let (mut id_to_pos, seed_ids) = Self::apply_changes(&changes, &mut in_memory);

        let pre_refresh = in_memory.snapshot_units();
        let dirty = Self::refresh_graph(&seed_ids, &mut in_memory)?;

        Ok(Self::merge_refreshed(
            changes,
            &mut id_to_pos,
            &dirty,
            &in_memory,
            &pre_refresh,
        ))
    }
}

/// Built-in hook that sets `updatedAt` timestamps on parent objects
/// whose sibling fields have changed.
///
/// Parent paths are discovered at build time from the JSON Schema
/// (see `generated::updated_at_paths::UPDATED_AT_PARENT_PATHS`).
/// For each path, if any sibling field (excluding `updatedAt` itself)
/// differs between `before` and `after`, the hook writes the current
/// UTC time in ISO 8601 Zulu format (e.g. `2026-03-09T04:58:19Z`).
pub(crate) struct UpdatedAtHook;

impl UpdatedAtHook {
    /// Compare two parent objects excluding the `updatedAt` key.
    /// Returns `true` if any sibling field differs.
    fn siblings_changed(before_parent: Option<&Value>, after_parent: &Value) -> bool {
        let Some(before) = before_parent else {
            return true;
        };

        let (Some(before_obj), Some(after_obj)) = (before.as_object(), after_parent.as_object())
        else {
            return before != after_parent;
        };

        let all_keys: std::collections::HashSet<&String> = before_obj
            .keys()
            .chain(after_obj.keys())
            .filter(|k| k.as_str() != "updatedAt")
            .collect();

        for key in all_keys {
            if before_obj.get(key) != after_obj.get(key) {
                return true;
            }
        }
        false
    }

    fn now_zulu() -> String {
        chrono::Utc::now().to_rfc3339_opts(chrono::SecondsFormat::Secs, true)
    }
}

impl RegistryHook for UpdatedAtHook {
    fn before_persist(
        &self,
        _kind: ChangeType,
        changes: Vec<CodeUnitChange>,
        _registry: &CodeUnitRegistry,
        _options: &WriteOptions,
    ) -> Result<Vec<CodeUnitChange>> {
        use crate::generated::updated_at_paths::UPDATED_AT_PARENT_PATHS;

        let mut result = changes;
        let now = Self::now_zulu();

        for change in &mut result {
            let Some(after) = &change.after else {
                continue;
            };

            let before_json = change
                .before
                .as_ref()
                .map(serde_json::to_value)
                .transpose()?;
            let mut after_json = serde_json::to_value(after)?;

            let mut modified = false;
            for path in UPDATED_AT_PARENT_PATHS {
                let after_parent = paths::navigate_path(&after_json, path);

                let parent_exists_in_after = after_parent
                    .is_some_and(|v| v.is_object() && !v.as_object().unwrap().is_empty());

                if !parent_exists_in_after {
                    continue;
                }

                let before_parent = before_json
                    .as_ref()
                    .and_then(|bj| paths::navigate_path(bj, path));

                if Self::siblings_changed(before_parent, after_parent.unwrap()) {
                    if let Some(parent_mut) = paths::ensure_path(&mut after_json, path) {
                        if let Some(obj) = parent_mut.as_object_mut() {
                            obj.insert("updatedAt".to_string(), Value::String(now.clone()));
                            modified = true;
                        }
                    }
                }
            }

            if modified {
                change.after = Some(serde_json::from_value(after_json)?);
            }
        }

        Ok(result)
    }
}

/// Built-in hook that normalizes file path fields to UNIX-style forward
/// slashes. Runs first in the chain so downstream hooks (checksums, etc.)
/// see canonical paths.
pub(crate) struct PathNormalizationHook;

impl RegistryHook for PathNormalizationHook {
    fn before_persist(
        &self,
        _kind: ChangeType,
        changes: Vec<CodeUnitChange>,
        _registry: &CodeUnitRegistry,
        _options: &WriteOptions,
    ) -> Result<Vec<CodeUnitChange>> {
        let mut result = changes;
        for change in &mut result {
            if let Some(unit) = &mut change.after {
                paths::normalize_code_unit_paths(unit);
            }
        }
        Ok(result)
    }
}

/// Options for `find_all` queries.
#[derive(Debug, Clone, Copy, Default)]
pub struct FindOptions<'a> {
    /// Optional SQL-like filter expression.
    pub filter: Option<&'a str>,
    /// Optional field projection list.
    pub fields: Option<&'a [&'a str]>,
    /// When true and a filter is active, include transitive dependencies
    /// of matching units even if they do not match the filter.
    pub include_dependencies: bool,
}

/// Convert dot-notation path to JSON Pointer (RFC 6901)
/// e.g., "source.name" -> "/source/name"
fn to_json_pointer(dot_path: &str) -> String {
    format!("/{}", dot_path.replace('.', "/"))
}

/// Set a value at a dot-notation path, creating intermediate objects as needed.
/// Returns Err if an intermediate segment exists but is not an object.
fn set_path(root: &mut Value, path: &str, val: Value) -> Result<()> {
    let parts: Vec<&str> = path.split('.').collect();
    let mut current = root;

    for part in &parts[..parts.len() - 1] {
        if !current.is_object() {
            return ValidationSnafu {
                message: format!(
                    "Cannot set path '{}': intermediate value is not an object",
                    path
                ),
            }
            .fail();
        }
        current = current
            .as_object_mut()
            .unwrap()
            .entry(*part)
            .or_insert_with(|| Value::Object(serde_json::Map::new()));
    }

    let leaf = parts.last().unwrap();
    match current.as_object_mut() {
        Some(obj) => {
            obj.insert(leaf.to_string(), val);
            Ok(())
        }
        None => ValidationSnafu {
            message: format!("Cannot set path '{}': parent is not an object", path),
        }
        .fail(),
    }
}

/// Project specified fields from a JSON value into a new object.
/// Supports nested paths like "source.name".
fn project_fields(value: &Value, fields: &[&str]) -> Result<Value> {
    let mut result = Value::Object(serde_json::Map::new());

    for field in fields {
        if let Some(v) = value.pointer(&to_json_pointer(field)) {
            set_path(&mut result, field, v.clone())?;
        }
    }

    Ok(result)
}

/// Check if all fields present in `partial` match the corresponding fields in `target`.
/// For objects, recurse into nested keys. For all other types, require exact equality.
fn matches_partial(partial: &Value, target: &Value) -> bool {
    match (partial, target) {
        (Value::Object(partial_map), Value::Object(target_map)) => {
            for (key, partial_val) in partial_map {
                match target_map.get(key) {
                    Some(target_val) => {
                        if !matches_partial(partial_val, target_val) {
                            return false;
                        }
                    }
                    None => return false,
                }
            }
            true
        }
        _ => partial == target,
    }
}

/// Deep-merge `patch` into `base`.
/// For objects, recursively merge keys. For all other types, `patch` wins.
fn deep_merge(base: &mut Value, patch: &Value) {
    match (base, patch) {
        (Value::Object(base_map), Value::Object(patch_map)) => {
            for (key, patch_val) in patch_map {
                let entry = base_map.entry(key.clone()).or_insert_with(|| Value::Null);
                deep_merge(entry, patch_val);
            }
        }
        (base, patch) => {
            *base = patch.clone();
        }
    }
}

/// Always use LF line endings in registry JSON files for cross-platform consistency.
const LINE_ENDING: &str = "\n";

/// Lock guard that releases the lock when dropped
pub struct LockGuard {
    _file: File,
}

impl LockGuard {
    fn new(file: File) -> Self {
        Self { _file: file }
    }
}

/// RAII guard that sets an [`AtomicBool`] to `true` on creation and
/// restores it to `false` on drop — even if the guarded scope panics.
struct HookGuard<'a>(&'a std::sync::atomic::AtomicBool);

impl<'a> HookGuard<'a> {
    fn enter(flag: &'a std::sync::atomic::AtomicBool) -> Self {
        flag.store(true, std::sync::atomic::Ordering::Relaxed);
        Self(flag)
    }
}

impl Drop for HookGuard<'_> {
    fn drop(&mut self) {
        self.0.store(false, std::sync::atomic::Ordering::Relaxed);
    }
}

/// The ordered set of built-in hooks that run on every write operation.
///
/// Order matters: PathNormalizationHook first (so downstream hooks see
/// canonical paths), ChecksumHook second (so checksums are based on
/// resolved paths), then DependencyRefreshHook, then UpdatedAtHook last.
fn builtin_hooks() -> Vec<Box<dyn RegistryHook + Send + Sync>> {
    vec![
        Box::new(PathNormalizationHook),
        Box::new(ChecksumHook),
        Box::new(DependencyRefreshHook),
        Box::new(UpdatedAtHook),
    ]
}

/// A code-unit registry backed by a directory of JSON files.
pub struct CodeUnitRegistry {
    /// Root path of the registry (contains registry/)
    root: PathBuf,
    /// Before-write hooks that fire before data is persisted.
    hooks: Vec<Box<dyn RegistryHook + Send + Sync>>,
    /// Re-entrancy guard: prevents write methods from being called inside hooks.
    in_hook: std::sync::atomic::AtomicBool,
}

impl CodeUnitRegistry {
    /// Returns `true` if a registry directory structure exists at the given path.
    pub fn exists(path: impl AsRef<Path>) -> bool {
        path.as_ref().join(REGISTRY_DIR).exists()
    }

    /// Initialize a new registry at the given path.
    /// Creates the registry directory structure.
    pub fn init(path: impl AsRef<Path>) -> Result<Self> {
        let root = path.as_ref().to_path_buf();

        if Self::exists(&root) {
            return RegistryAlreadyExistsSnafu {
                path: root.display().to_string(),
            }
            .fail();
        }

        let registry_dir = root.join(REGISTRY_DIR);
        fs::create_dir_all(&registry_dir)?;
        fs::create_dir_all(registry_dir.join(".locks"))?;

        let gitignore = registry_dir.join(".gitignore");
        let gitignore_content = format!(".locks/{}", LINE_ENDING);
        fs::write(&gitignore, gitignore_content)?;

        Ok(Self::with_root(root))
    }

    /// Open an existing registry at the given path.
    pub fn open(path: impl AsRef<Path>) -> Result<Self> {
        let root = path.as_ref().to_path_buf();

        if !Self::exists(&root) {
            return RegistryNotFoundSnafu {
                path: root.display().to_string(),
            }
            .fail();
        }

        Ok(Self::with_root(root))
    }

    fn with_root(root: PathBuf) -> Self {
        Self {
            root,
            hooks: builtin_hooks(),
            in_hook: std::sync::atomic::AtomicBool::new(false),
        }
    }

    /// Get the root path of the registry
    pub fn root(&self) -> &Path {
        &self.root
    }

    /// Get the source directory path (`root/source`).
    pub fn source_dir(&self) -> PathBuf {
        self.root.join("source")
    }

    /// Get the snowflake (converted output) directory path (`root/snowflake`).
    pub fn snowflake_dir(&self) -> PathBuf {
        self.root.join("snowflake")
    }

    /// Get the registry directory path
    fn registry_dir(&self) -> PathBuf {
        self.root.join(REGISTRY_DIR)
    }

    /// Acquire an exclusive lock for write operations.
    pub fn acquire_lock(&self) -> Result<LockGuard> {
        let lock_path = self.registry_dir().join(".locks").join("registry.lock");

        if let Some(parent) = lock_path.parent() {
            fs::create_dir_all(parent)?;
        }

        let file = File::create(&lock_path)?;
        file.lock_exclusive().map_err(|e| {
            LockSnafu {
                message: e.to_string(),
            }
            .build()
        })?;

        Ok(LockGuard::new(file))
    }

    /// Compute file path from ID.
    /// Returns `registry/{id}.json`
    fn id_to_path(&self, id: &str) -> PathBuf {
        self.registry_dir().join(format!("{}.json", id))
    }

    // ── Hooks ────────────────────────────────────────────────────────────

    #[cfg(test)]
    fn add_hook(&mut self, hook: impl RegistryHook + Send + Sync + 'static) {
        self.hooks.push(Box::new(hook));
    }

    fn guard_reentrant(&self) -> Result<()> {
        if self.in_hook.load(std::sync::atomic::Ordering::Relaxed) {
            return HookReentrantSnafu.fail();
        }
        Ok(())
    }

    /// Run all registered hooks in order, allowing each to inspect and
    /// transform the change set. Hooks may append additional changes for
    /// units affected by side effects (e.g. transitive dependency updates),
    /// so the returned vec can be larger than the input.
    fn fire_before_persist(
        &self,
        kind: ChangeType,
        changes: Vec<CodeUnitChange>,
        options: Option<&WriteOptions>,
    ) -> Result<Vec<CodeUnitChange>> {
        let default_opts = WriteOptions::default();
        let options = options.unwrap_or(&default_opts);
        let _guard = HookGuard::enter(&self.in_hook);
        self.hooks.iter().try_fold(changes, |acc, hook| {
            hook.before_persist(kind, acc, self, options)
        })
    }

    fn persist_changes(&self, changes: &[CodeUnitChange]) -> Result<()> {
        changes
            .par_iter()
            .try_for_each(|change| match &change.after {
                Some(unit) => self.write_json(&self.id_to_path(&change.id), unit, false),
                None => {
                    let path = self.id_to_path(&change.id);
                    if path.exists() {
                        fs::remove_file(path)?;
                    }
                    Ok(())
                }
            })?;
        self.sync()
    }

    fn persist_changes_batch(&self, changes: &[CodeUnitChange], result: &mut BatchResult) {
        let outcomes: Vec<(String, std::result::Result<(), crate::error::Error>)> = changes
            .par_iter()
            .map(|change| {
                let outcome = match &change.after {
                    Some(unit) => self.write_json(&self.id_to_path(&change.id), unit, false),
                    None => {
                        let path = self.id_to_path(&change.id);
                        if path.exists() {
                            fs::remove_file(&path).map_err(Into::into)
                        } else {
                            Ok(())
                        }
                    }
                };
                (change.id.clone(), outcome)
            })
            .collect();

        for (id, outcome) in outcomes {
            match outcome {
                Ok(()) => result.success(id),
                Err(e) => result.failure(id, &e),
            }
        }
        if let Err(e) = self.sync() {
            result.failure("_sync".to_string(), &e);
        }
    }

    // ── Write pipeline helpers ────────────────────────────────────────────

    fn write_protected<T>(
        &self,
        kind: ChangeType,
        options: Option<&WriteOptions>,
        prepare: impl FnOnce() -> Result<(Vec<CodeUnitChange>, T)>,
    ) -> Result<T> {
        let _lock = self.acquire_lock()?;
        self.guard_reentrant()?;
        let (changes, value) = prepare()?;
        let changes = self.fire_before_persist(kind, changes, options)?;
        self.persist_changes(&changes)?;
        Ok(value)
    }

    fn write_protected_batch(
        &self,
        kind: ChangeType,
        options: Option<&WriteOptions>,
        prepare: impl FnOnce(&mut BatchResult) -> Result<Vec<CodeUnitChange>>,
    ) -> Result<BatchResult> {
        self.guard_reentrant()?;
        let _lock = self.acquire_lock()?;
        let mut result = BatchResult::new();
        let changes = prepare(&mut result)?;
        let input_ids = Self::check_duplicate_ids(&changes)?;
        let changes = self.fire_before_persist(kind, changes, options)?;

        result.side_effect_ids = changes
            .iter()
            .filter(|c| !input_ids.contains(&c.id))
            .map(|c| c.id.clone())
            .collect();

        self.persist_changes_batch(&changes, &mut result);
        Ok(result)
    }

    /// Reject batches containing the same ID more than once.
    /// On success returns the set of input IDs for downstream side-effect detection.
    fn check_duplicate_ids(
        changes: &[CodeUnitChange],
    ) -> Result<std::collections::HashSet<String>> {
        let mut seen = std::collections::HashMap::with_capacity(changes.len());
        for (idx, change) in changes.iter().enumerate() {
            if let Some(&first_index) = seen.get(&change.id) {
                return DuplicateBatchIdSnafu {
                    id: change.id.clone(),
                    first_index,
                    duplicate_index: idx,
                    batch_size: changes.len(),
                }
                .fail();
            }
            seen.insert(change.id.clone(), idx);
        }
        Ok(seen.into_keys().collect())
    }

    // ── Create ───────────────────────────────────────────────────────────

    /// Create a new code unit on disk.
    /// If code_unit.id is None, generates a new ID.
    /// Returns the ID of the created code unit.
    /// Errors if the code unit already exists.
    pub fn create(
        &self,
        code_unit: &mut CodeUnit,
        options: Option<&WriteOptions>,
    ) -> Result<String> {
        self.write_protected(ChangeType::Create, options, || {
            let id = self.prepare_create(code_unit)?;
            let changes = vec![CodeUnitChange {
                id: id.clone(),
                before: None,
                after: Some(code_unit.clone()),
            }];
            Ok((changes, id))
        })
    }

    /// Batch create multiple code units efficiently.
    /// All creates are written without sync, then a single sync at the end.
    /// If a code_unit.id is None, generates a new ID for it.
    /// Skips entries that fail (e.g., duplicate IDs) and continues with the rest.
    ///
    /// The returned `BatchResult` may include IDs beyond those in `batch`
    /// when lifecycle hooks trigger side effects (e.g. dependency graph updates).
    pub fn create_batch(
        &self,
        batch: &mut [CodeUnit],
        options: Option<&WriteOptions>,
    ) -> Result<BatchResult> {
        self.write_protected_batch(ChangeType::Create, options, |result| {
            let mut changes = Vec::new();
            for code_unit in batch.iter_mut() {
                match self.prepare_create(code_unit) {
                    Ok(id) => {
                        changes.push(CodeUnitChange {
                            id,
                            before: None,
                            after: Some(code_unit.clone()),
                        });
                    }
                    Err(e) => {
                        let id = code_unit
                            .id
                            .clone()
                            .unwrap_or_else(|| UNKNOWN_ID.to_string());
                        result.failure(id, &e);
                    }
                }
            }
            Ok(changes)
        })
    }

    /// Prepare a code unit for creation: assign ID if needed, validate no conflict.
    /// Does NOT write to disk.
    fn prepare_create(&self, code_unit: &mut CodeUnit) -> Result<String> {
        let id = match &code_unit.id {
            Some(id) => id.clone(),
            None => {
                let new_id = crate::generate_id();
                code_unit.id = Some(new_id.clone());
                new_id
            }
        };

        let file_path = self.id_to_path(&id);
        if file_path.exists() {
            return CodeUnitAlreadyExistsSnafu { id }.fail();
        }

        Ok(id)
    }

    // ── Read ─────────────────────────────────────────────────────────────

    /// Load a code unit from disk by ID.
    pub fn get_by_id(&self, id: &str, fields: Option<&[&str]>) -> Result<CodeUnit> {
        let file_path = self.id_to_path(id);

        if !file_path.exists() {
            return CodeUnitNotFoundSnafu { id }.fail();
        }

        let code_unit = self.read_json(&file_path)?;
        match fields {
            Some(f) => {
                let json_value = serde_json::to_value(&code_unit)?;
                let projected = project_fields(&json_value, f)?;
                Ok(serde_json::from_value(projected)?)
            }
            None => Ok(code_unit),
        }
    }

    /// List code units, optionally filtered and with field projection.
    ///
    /// If `options.filter` is `None`, returns all code units.
    /// If `options.filter` is `Some`, only returns code units matching the expression.
    /// If `options.fields` is `Some`, returns only the specified fields.
    ///
    /// Uses strict loading and returns an error if any registry JSON is malformed
    /// or has an ID/filename mismatch.
    pub fn find_all(&self, options: FindOptions<'_>) -> Result<Vec<CodeUnit>> {
        let in_memory = InMemoryRegistry::build(self)?;
        match options.filter {
            None => in_memory.all_units(options.fields),
            Some(filter) => {
                let parsed_filter = Filter::parse(filter)?;
                let selected = {
                    let query = in_memory.query();
                    let mut selected =
                        query.matching_indices(|json| parsed_filter.matches(json))?;
                    if options.include_dependencies {
                        query.include_transitive_dependencies(&mut selected);
                    }
                    selected
                };
                in_memory.selected_units(selected, options.fields)
            }
        }
    }

    /// Find code units matching all non-null fields of a partial code unit.
    ///
    /// `partial` is a JSON value representing a partial code unit – only the
    /// keys present in the object are compared. For nested objects, the
    /// comparison recurses: a stored code unit matches when every key in
    /// `partial` exists in the stored document and carries the same value.
    ///
    /// If `fields` is `Some`, only the specified fields are returned
    /// (field projection).
    ///
    /// Uses strict loading and returns an error if any registry JSON is malformed
    /// or has an ID/filename mismatch.
    pub fn find_by_object(
        &self,
        partial: &Value,
        fields: Option<&[&str]>,
    ) -> Result<Vec<CodeUnit>> {
        let in_memory = InMemoryRegistry::build(self)?;
        let selected = {
            let query = in_memory.query();
            query.matching_indices(|json| matches_partial(partial, json))?
        };
        in_memory.selected_units(selected, fields)
    }

    // ── Update (PATCH) ───────────────────────────────────────────────────

    /// Update specific fields in a code unit by dot-notation paths.
    /// Always syncs to disk after the update.
    pub fn update(
        &self,
        id: &str,
        updates: &[(&str, Value)],
        options: Option<&WriteOptions>,
    ) -> Result<()> {
        self.write_protected(ChangeType::Update, options, || {
            let existing = self.load_existing(id)?;
            let patched = self.prepare_update(&existing, updates)?;
            let changes = vec![CodeUnitChange {
                id: id.to_string(),
                before: Some(existing),
                after: Some(patched),
            }];
            Ok((changes, ()))
        })
    }

    /// Update all code units matching a filter with the same updates.
    ///
    /// Matching uses strict loading: if any registry JSON is malformed or has an
    /// ID/filename mismatch, this method returns an error before applying updates.
    ///
    /// After the match set is loaded, per-item update failures are recorded in
    /// `BatchResult.failed` and processing continues for the remaining matches.
    ///
    /// The returned `BatchResult` may include IDs beyond the matched set
    /// when lifecycle hooks trigger side effects (e.g. dependency graph updates).
    pub fn update_where(
        &self,
        filter: &str,
        updates: &[(&str, Value)],
        options: Option<&WriteOptions>,
    ) -> Result<BatchResult> {
        self.write_protected_batch(ChangeType::Update, options, |result| {
            let matches = self.find_all(FindOptions {
                filter: Some(filter),
                ..FindOptions::default()
            })?;
            let mut changes = Vec::new();
            for existing in matches {
                if let Some(id) = existing.id.clone() {
                    match self.prepare_update(&existing, updates) {
                        Ok(patched) => {
                            changes.push(CodeUnitChange {
                                id,
                                before: Some(existing),
                                after: Some(patched),
                            });
                        }
                        Err(e) => result.failure(id, &e),
                    }
                }
            }
            Ok(changes)
        })
    }

    /// Batch update multiple code units efficiently.
    /// All updates are written to temp files first, then renamed, with a single sync at the end.
    /// Skips entries that fail (e.g., not found) and continues with the rest.
    ///
    /// The returned `BatchResult` may include IDs beyond those in `batch`
    /// when lifecycle hooks trigger side effects (e.g. dependency graph updates).
    pub fn update_batch(
        &self,
        batch: &[(&str, Vec<(&str, Value)>)],
        options: Option<&WriteOptions>,
    ) -> Result<BatchResult> {
        self.write_protected_batch(ChangeType::Update, options, |result| {
            let mut changes = Vec::new();
            for (id, updates) in batch {
                match self.load_existing(id).and_then(|existing| {
                    let patched = self.prepare_update(&existing, updates)?;
                    Ok((existing, patched))
                }) {
                    Ok((existing, patched)) => {
                        changes.push(CodeUnitChange {
                            id: id.to_string(),
                            before: Some(existing),
                            after: Some(patched),
                        });
                    }
                    Err(e) => result.failure(id.to_string(), &e),
                }
            }
            Ok(changes)
        })
    }

    /// Produce the patched CodeUnit from applying updates to an existing unit.
    /// Does NOT write to disk or apply checksums.
    fn prepare_update(&self, existing: &CodeUnit, updates: &[(&str, Value)]) -> Result<CodeUnit> {
        let mut json_value = serde_json::to_value(existing)?;
        for (path, value) in updates {
            set_path(&mut json_value, path, value.clone())?;
        }
        Ok(serde_json::from_value(json_value)?)
    }

    // ── Upsert (merge) ──────────────────────────────────────────────────

    /// Create-or-merge a single code unit.
    ///
    /// * If the code unit does **not** exist on disk, it is created (like `create`).
    /// * If it **does** exist, the incoming fields are deep-merged into the
    ///   existing document -- fields present in `code_unit` overwrite the
    ///   corresponding fields on disk, but fields **not** present in `code_unit`
    ///   (i.e. serialised as `None` / absent) are left untouched.
    ///
    /// Returns the ID of the upserted code unit.
    pub fn upsert(
        &self,
        code_unit: &mut CodeUnit,
        options: Option<&WriteOptions>,
    ) -> Result<String> {
        self.write_protected(ChangeType::Upsert, options, || {
            let file_path = self.id_to_path(code_unit.id.as_deref().unwrap_or(""));
            let existing = if file_path.exists() {
                Some(self.read_json(&file_path)?)
            } else {
                None
            };
            let (id, merged) = self.prepare_upsert(code_unit, existing.as_ref())?;
            let changes = vec![CodeUnitChange {
                id: id.clone(),
                before: existing,
                after: Some(merged),
            }];
            Ok((changes, id))
        })
    }

    /// Batch upsert multiple code units.
    ///
    /// The returned `BatchResult` may include IDs beyond those in `batch`
    /// when lifecycle hooks trigger side effects (e.g. dependency graph updates).
    pub fn upsert_batch(
        &self,
        batch: &mut [CodeUnit],
        options: Option<&WriteOptions>,
    ) -> Result<BatchResult> {
        self.write_protected_batch(ChangeType::Upsert, options, |result| {
            let mut changes = Vec::new();
            for code_unit in batch.iter_mut() {
                let existing = code_unit
                    .id
                    .as_deref()
                    .map(|id| self.id_to_path(id))
                    .filter(|p| p.exists())
                    .map(|p| self.read_json(&p))
                    .transpose()?;
                match self.prepare_upsert(code_unit, existing.as_ref()) {
                    Ok((id, merged)) => {
                        changes.push(CodeUnitChange {
                            id,
                            before: existing,
                            after: Some(merged),
                        });
                    }
                    Err(e) => {
                        let id = code_unit
                            .id
                            .clone()
                            .unwrap_or_else(|| UNKNOWN_ID.to_string());
                        result.failure(id, &e);
                    }
                }
            }
            Ok(changes)
        })
    }

    /// Prepare an upsert: merge incoming into existing (or use as-is for create).
    /// Returns (id, merged_unit). Does NOT write to disk.
    fn prepare_upsert(
        &self,
        code_unit: &mut CodeUnit,
        existing: Option<&CodeUnit>,
    ) -> Result<(String, CodeUnit)> {
        let id = match &code_unit.id {
            Some(id) => id.clone(),
            None => {
                let new_id = crate::generate_id();
                code_unit.id = Some(new_id.clone());
                new_id
            }
        };

        if let Some(existing) = existing {
            let mut base_value = serde_json::to_value(existing)?;
            let patch_value = serde_json::to_value(&*code_unit)?;
            deep_merge(&mut base_value, &patch_value);
            let merged: CodeUnit = serde_json::from_value(base_value)?;
            Ok((id, merged))
        } else {
            Ok((id, code_unit.clone()))
        }
    }

    /// Recompute checksums for file entries selected by `mode` on an
    /// existing code unit.
    ///
    /// Reads the unit from disk, re-hashes selected file entries
    /// (compare-then-update), and persists through the standard changes
    /// pipeline (before-persist hooks fire with `ChangeType::Update`).
    pub fn update_checksum(&self, id: &str, mode: ChecksumMode) -> Result<()> {
        self.write_protected(ChangeType::Update, None, || {
            let existing = self.load_existing(id)?;
            let mut updated = existing.clone();
            apply_checksums(&mut updated, &mode, &self.root)?;
            let changes = vec![CodeUnitChange {
                id: id.to_string(),
                before: Some(existing),
                after: Some(updated),
            }];
            Ok((changes, ()))
        })
    }

    /// Validate checksums for an existing code unit using the explicit mode.
    pub fn validate_checksum(
        &self,
        id: &str,
        mode: ChecksumMode,
    ) -> Result<ChecksumValidationReport> {
        let file_path = self.id_to_path(id);
        if !file_path.exists() {
            return CodeUnitNotFoundSnafu { id }.fail();
        }
        let code_unit = self.read_json(&file_path)?;
        Ok(validate_checksum_report(&code_unit, &mode, &self.root))
    }

    // ── Change detection ─────────────────────────────────────────────────

    /// Detect source-code changes across the project.
    ///
    /// Returns a [`SourceCodeChanges`] report containing:
    /// * **code_unit_changes** — code units whose tracked files have been
    ///   modified or removed from disk.
    /// * **untracked_files** — files found under `source/` or `snowflake/`
    ///   that are not referenced by any code unit.
    ///
    /// `mode` selects which file entries to check (`source`, `converted`,
    /// or both). `filter` optionally restricts the scan to code units
    /// matching a SQL WHERE expression.
    pub fn find_sql_file_changes(
        &self,
        mode: ChecksumMode,
        filter: Option<&str>,
    ) -> Result<SourceCodeChanges> {
        let in_memory = InMemoryRegistry::build(self)?;
        let units = match filter {
            None => in_memory.all_units(None)?,
            Some(filter_str) => {
                let parsed_filter = Filter::parse(filter_str)?;
                let selected = {
                    let query = in_memory.query();
                    query.matching_indices(|json| parsed_filter.matches(json))?
                };
                in_memory.selected_units(selected, None)?
            }
        };
        Ok(find_sql_file_changes(
            &units,
            &mode,
            &self.root,
            &self.source_dir(),
            &self.snowflake_dir(),
        ))
    }

    // ── Delete ───────────────────────────────────────────────────────────

    /// Delete a code unit by ID.
    ///
    /// Before-write hooks fire with `before` = existing unit and `after` = `None`.
    /// If a hook sets `after` to `Some(unit)`, the delete is cancelled and the
    /// unit is written instead.
    pub fn delete(&self, id: &str) -> Result<()> {
        self.write_protected(ChangeType::Delete, None, || {
            let existing = self.load_existing(id)?;
            let changes = vec![CodeUnitChange {
                id: id.to_string(),
                before: Some(existing),
                after: None,
            }];
            Ok((changes, ()))
        })
    }

    // ── Refresh ──────────────────────────────────────────────────────────

    /// Recompute dependency-derived fields across the entire registry.
    ///
    /// Uses strict cycle detection: returns `CycleDetected(1014)` if any
    /// dependency cycle is found.
    pub fn refresh_dependencies(&self) -> Result<()> {
        let _lock = self.acquire_lock()?;
        self.refresh_and_sync(true)
    }

    // ── Validation ────────────────────────────────────────────────────────

    /// Migrate all registry documents on disk to the current schema version.
    ///
    /// Acquires the lock internally — callers must **not** already hold it.
    /// Best-effort: per-file failures are recorded in [`BatchResult::failed`]
    /// and processing continues. Already-current documents are skipped.
    /// Successfully migrated files persist even if later files fail (not
    /// transactional).
    ///
    /// Returns `Err` only for batch-level failures (lock, enumeration, sync).
    /// Partial progress may already have occurred before an `Err` is returned.
    pub fn migrate_schema_all(&self) -> Result<BatchResult> {
        let _lock = self.acquire_lock()?;

        let registry_dir = self.registry_dir();
        if !registry_dir.exists() {
            return Ok(BatchResult::new());
        }

        let paths = paths::json_file_paths(&registry_dir)?;

        let outcomes: Vec<(String, std::result::Result<bool, Error>)> = paths
            .par_iter()
            .map(|path| {
                let id = paths::filename_stem(path).unwrap_or_default().to_string();
                (id, self.migrate_schema_file(path))
            })
            .collect();

        let mut result = BatchResult::new();
        for (id, outcome) in outcomes {
            match outcome {
                Ok(true) => result.success(id),
                Ok(false) => {}
                Err(e) => result.failure(id, &e),
            }
        }

        if !result.succeeded.is_empty() {
            self.sync()?;
        }
        Ok(result)
    }

    fn migrate_schema_file(&self, path: &Path) -> Result<bool> {
        let mut file = File::open(path)?;
        let mut contents = String::new();
        file.read_to_string(&mut contents)?;

        let value: serde_json::Value = serde_json::from_str(&contents)?;
        let migrated = crate::migration::migrate(value.clone())?;

        if migrated == value {
            return Ok(false);
        }

        let doc: CodeUnit = serde_json::from_value(migrated)?;
        self.write_json(path, &doc, false)?;
        Ok(true)
    }

    /// Validate all code units in the registry.
    ///
    /// Performs JSON syntax checks, JSON Schema validation, serde
    /// deserialization, ID/filename consistency, duplicate ID detection,
    /// referential integrity, and checksum validation (controlled by
    /// `checksum_mode`).
    ///
    /// Returns a [`ValidationReport`] with `is_valid == true` when no
    /// issues are found. All issues are collected (no fail-fast) so callers
    /// get a complete picture in a single invocation — ideal for CI/build
    /// pipelines.
    pub fn validate(
        &self,
        checksum_mode: ChecksumMode,
    ) -> Result<crate::validation::ValidationReport> {
        crate::validation::validate_registry(&self.registry_dir(), &checksum_mode, &self.root)
    }

    /// Validate a single code unit by ID.
    ///
    /// Performs per-file checks (JSON, schema, deserialization, ID/filename,
    /// checksums) but not cross-unit checks (duplicates, referential
    /// integrity).
    pub fn validate_unit(
        &self,
        id: &str,
        checksum_mode: ChecksumMode,
    ) -> Result<crate::validation::ValidationReport> {
        let file_path = self.id_to_path(id);
        crate::validation::validate_single(&file_path, &checksum_mode, &self.root)
    }

    /// Full refresh: recompute dependency-derived fields for all units,
    /// then sync to disk (assumes lock held).
    ///
    /// Loads all units, runs the graph refresh algorithm, and writes back
    /// only the units whose dependency-derived fields changed. Always syncs
    /// even if refresh fails, so any preceding writes are durable. The refresh
    /// error (if any) is returned after the sync succeeds.
    ///
    /// In best-effort mode (`strict=false`), cycles silently receive
    /// `topological_rank = -1`.
    fn refresh_and_sync(&self, strict: bool) -> Result<()> {
        let mut wrote_any = false;
        let refresh_result = (|| {
            let mut in_memory = InMemoryRegistry::build(self)?;
            let dirty = in_memory.graph().refresh(strict)?;
            for i in dirty {
                let unit = in_memory.unit(i);
                let id = unit.id.as_ref().expect("loader guarantees id");
                self.write_json(&self.id_to_path(id), unit, false)?;
                wrote_any = true;
            }
            Ok(())
        })();
        self.sync()?;
        match refresh_result {
            Ok(()) => Ok(()),
            Err(err) if wrote_any => {
                Err(WriteSucceededRefreshFailedSnafu.into_error(Box::new(err)))
            }
            Err(err) => Err(err),
        }
    }

    // ── Internal helpers ─────────────────────────────────────────────────

    /// Sync all pending writes to disk (internal use only).
    fn sync(&self) -> Result<()> {
        let registry_dir = self.registry_dir();
        if registry_dir.exists() {
            let dir = File::open(&registry_dir)?;
            dir.sync_all()?;
        }
        Ok(())
    }

    /// Load an existing code unit by ID, returning `CodeUnitNotFound` if absent.
    fn load_existing(&self, id: &str) -> Result<CodeUnit> {
        let file_path = self.id_to_path(id);
        if !file_path.exists() {
            return CodeUnitNotFoundSnafu { id }.fail();
        }
        self.read_json(&file_path)
    }

    /// Read JSON from file as CodeUnit, migrating to the current schema
    /// version and normalizing paths to UNIX-style.
    fn read_json(&self, path: &Path) -> Result<CodeUnit> {
        let mut file = File::open(path)?;
        let mut contents = String::new();
        file.read_to_string(&mut contents)?;
        let value: serde_json::Value = serde_json::from_str(&contents)?;
        let value = crate::migration::migrate(value)?;
        let mut doc: CodeUnit = serde_json::from_value(value)?;
        paths::normalize_code_unit_paths(&mut doc);
        Ok(doc)
    }

    /// Write JSON to file atomically.
    /// If `sync` is true, ensures data is flushed to disk.
    fn write_json(&self, path: &Path, doc: &CodeUnit, sync: bool) -> Result<()> {
        let json = serde_json::to_string_pretty(doc)?;
        let temp_path = path.with_extension("json.tmp");
        {
            let mut file = File::create(&temp_path)?;
            file.write_all(json.as_bytes())?;
            file.write_all(LINE_ENDING.as_bytes())?;
            if sync {
                file.sync_all()?;
            }
        }
        fs::rename(&temp_path, path)?;
        Ok(())
    }
}

#[cfg(test)]
mod tests;
