//! Individual migration functions, one per schema version transition.
//!
//! Each migration lives in its own file named `v{N}_to_v{N+1}.rs` and
//! exports a single public function:
//!
//! ```ignore
//! pub fn migrate(doc: &mut Value) -> Result<()> { ... }
//! ```
//!
//! ## Adding a new migration
//!
//! 1. Freeze the current schema to `schemas/history/code-unit.v{N}.schema.json` (**before** editing).
//! 2. Create `migration/versions/v{N}_to_v{N+1}.rs`.
//! 3. Implement `pub fn migrate(doc: &mut Value) -> Result<()>`.
//! 4. Add `mod v{N}_to_v{N+1};` below.
//! 5. Add `(N, v{N}_to_v{N+1}::migrate)` to [`MIGRATIONS`].
//! 6. Bump [`CURRENT_SCHEMA_VERSION`](super::CURRENT_SCHEMA_VERSION).

use serde_json::Value;

use crate::error::*;

pub(crate) type MigrationFn = fn(&mut Value) -> Result<()>;

// ── Migration modules ──────────────────────────────────────────────────
// mod v1_to_v2;

/// Ordered migration chain. Each entry is `(from_version, migration_fn)`.
/// A migration from version N always produces version N+1.
pub(crate) const MIGRATIONS: &[(i64, MigrationFn)] = &[
    // (1, v1_to_v2::migrate),
];
