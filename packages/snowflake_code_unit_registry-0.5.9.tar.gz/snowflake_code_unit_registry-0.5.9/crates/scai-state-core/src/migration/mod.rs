//! Schema version detection and document migration.
//!
//! Each code unit JSON file carries a `schemaVersion` integer. This module
//! provides the migration pipeline that upgrades old documents to the current
//! schema version using `serde_json::Value`-level transforms.
//!
//! ## Adding a new migration
//!
//! 1. Freeze `schemas/code-unit.schema.json` to `schemas/history/code-unit.vN.schema.json` (**before** editing the schema)
//! 2. Edit the schema — make structural changes and set `schemaVersion.const` to N+1
//! 3. Create `src/migration/versions/v{N}_to_v{N+1}.rs` with a `pub fn migrate(&mut Value) -> Result<()>`
//! 4. Register the module and function in `src/migration/versions/mod.rs`
//! 5. Update [`CURRENT_SCHEMA_VERSION`] to N+1
//! 6. Add migration tests with sample documents and both schema files

mod versions;

use serde_json::Value;

use crate::error::*;
use versions::{MigrationFn, MIGRATIONS};

/// JSON field name for the schema version indicator on every code unit document.
pub const SCHEMA_VERSION_FIELD: &str = "schemaVersion";

/// Current schema version supported by this library.
///
/// Must match the `schemaVersion.const` value in `schemas/code-unit.schema.json`.
/// Guarded by `test_version_constant_matches_schema` — CI will fail if this
/// drifts from the schema file.
pub const CURRENT_SCHEMA_VERSION: i64 = 1;

/// Extract the schema version from a raw JSON document.
///
/// - Returns `Ok(version)` when `schemaVersion` is a valid integer >= 1.
/// - Returns `Ok(1)` when `schemaVersion` is absent (missing = v1).
/// - Returns `Err(SchemaMigrationError)` when `schemaVersion` is present but not
///   a positive integer.
pub fn extract_version(doc: &Value) -> Result<i64> {
    match doc.get(SCHEMA_VERSION_FIELD) {
        None => Ok(1),
        Some(v) => {
            let version = v.as_i64().ok_or_else(|| {
                SchemaMigrationSnafu {
                    message: format!(
                        "schemaVersion must be a positive integer, got: {}",
                        truncated_display(v),
                    ),
                }
                .build()
            })?;
            if version < 1 {
                return SchemaMigrationSnafu {
                    message: format!("schemaVersion must be >= 1, got: {version}",),
                }
                .fail();
            }
            Ok(version)
        }
    }
}

/// Migrate a document from its current version to [`CURRENT_SCHEMA_VERSION`].
///
/// - If the document is already at the current version, returns it unchanged.
/// - If the document version is newer than supported, returns
///   [`SchemaVersionNewerThanSupported`](Error::SchemaVersionNewerThanSupported).
/// - If a migration step fails, returns [`SchemaMigrationError`](Error::SchemaMigrationError).
/// - If the migration chain is incomplete (no path from old to current),
///   returns [`SchemaMigrationError`](Error::SchemaMigrationError).
pub fn migrate(doc: Value) -> Result<Value> {
    migrate_with(doc, CURRENT_SCHEMA_VERSION, MIGRATIONS)
}

fn migrate_with(
    mut doc: Value,
    target_version: i64,
    migrations: &[(i64, MigrationFn)],
) -> Result<Value> {
    let version = extract_version(&doc)?;

    if version > target_version {
        return SchemaVersionNewerThanSupportedSnafu {
            document_version: version,
            supported_version: target_version,
        }
        .fail();
    }

    if version == target_version {
        return Ok(doc);
    }

    for &(from_ver, migrate_fn) in migrations {
        if extract_version(&doc)? == from_ver {
            migrate_fn(&mut doc).map_err(|e| {
                SchemaMigrationSnafu {
                    message: format!("v{} to v{}: {e}", from_ver, from_ver + 1),
                }
                .build()
            })?;
            set_version(&mut doc, from_ver + 1)?;
        }
    }

    let final_version = extract_version(&doc)?;
    if final_version != target_version {
        return SchemaMigrationSnafu {
            message: format!(
                "Migration chain incomplete: document at v{version}, reached v{final_version}, \
                 expected v{target_version}. Add missing migration functions.",
            ),
        }
        .fail();
    }

    Ok(doc)
}

fn set_version(doc: &mut Value, version: i64) -> Result<()> {
    let obj = doc.as_object_mut().ok_or_else(|| {
        SchemaMigrationSnafu {
            message: "document root must be a JSON object".to_string(),
        }
        .build()
    })?;
    obj.insert(SCHEMA_VERSION_FIELD.to_string(), Value::from(version));
    Ok(())
}

fn truncated_display(v: &Value) -> String {
    let s = v.to_string();
    if s.len() > 50 {
        format!("{}...", &s[..50])
    } else {
        s
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_version_constant_matches_schema() {
        let schema_str = include_str!("../../schemas/code-unit.schema.json");
        let schema: Value = serde_json::from_str(schema_str).unwrap();
        let schema_version = schema["properties"][SCHEMA_VERSION_FIELD]["const"]
            .as_i64()
            .expect("schemaVersion.const must be an integer in the schema");
        assert_eq!(
            CURRENT_SCHEMA_VERSION, schema_version,
            "CURRENT_SCHEMA_VERSION ({CURRENT_SCHEMA_VERSION}) does not match \
             schema's schemaVersion.const ({schema_version}). Update the constant.",
        );
    }

    #[test]
    fn test_extract_version_present() {
        let doc: Value = serde_json::json!({(SCHEMA_VERSION_FIELD): 2});
        assert_eq!(extract_version(&doc).unwrap(), 2);
    }

    #[test]
    fn test_extract_version_missing_defaults_to_1() {
        let doc: Value = serde_json::json!({"id": "test"});
        assert_eq!(extract_version(&doc).unwrap(), 1);
    }

    #[test]
    fn test_extract_version_non_integer_rejects_with_error() {
        let doc: Value = serde_json::json!({(SCHEMA_VERSION_FIELD): "not_a_number"});
        let err = extract_version(&doc).unwrap_err();
        assert_eq!(err.error_code_i32(), 1021);
        assert!(err.to_string().contains("must be a positive integer"));
    }

    #[test]
    fn test_extract_version_float_rejects_with_error() {
        let doc: Value = serde_json::json!({(SCHEMA_VERSION_FIELD): 1.5});
        let err = extract_version(&doc).unwrap_err();
        assert_eq!(err.error_code_i32(), 1021);
    }

    #[test]
    fn test_extract_version_non_positive_rejects_with_error() {
        for &v in &[0, -5] {
            let doc: Value = serde_json::json!({(SCHEMA_VERSION_FIELD): v});
            let err = extract_version(&doc).unwrap_err();
            assert_eq!(err.error_code_i32(), 1021, "schemaVersion={v}");
            assert!(
                err.to_string().contains("must be >= 1"),
                "schemaVersion={v}"
            );
        }
    }

    #[test]
    fn test_migrate_current_version_is_noop() {
        let doc: Value =
            serde_json::json!({(SCHEMA_VERSION_FIELD): CURRENT_SCHEMA_VERSION, "id": "test"});
        let result = migrate(doc.clone()).unwrap();
        assert_eq!(result, doc);
    }

    #[test]
    fn test_migrate_future_version_rejected() {
        let doc: Value = serde_json::json!({(SCHEMA_VERSION_FIELD): CURRENT_SCHEMA_VERSION + 1});
        let err = migrate(doc).unwrap_err();
        assert_eq!(err.error_code_i32(), 1020);
        let msg = err.to_string();
        assert!(
            msg.contains("newer"),
            "error message should mention 'newer': {msg}"
        );
    }

    #[test]
    fn test_migrate_non_integer_version_rejected() {
        let doc: Value = serde_json::json!({(SCHEMA_VERSION_FIELD): "bad"});
        let err = migrate(doc).unwrap_err();
        assert_eq!(err.error_code_i32(), 1021);
    }

    #[test]
    fn test_migrate_non_positive_version_rejected() {
        for &v in &[0, -3] {
            let doc: Value = serde_json::json!({(SCHEMA_VERSION_FIELD): v});
            let err = migrate(doc).unwrap_err();
            assert_eq!(err.error_code_i32(), 1021, "schemaVersion={v}");
            assert!(
                err.to_string().contains("must be >= 1"),
                "schemaVersion={v}"
            );
        }
    }

    // ── Pipeline tests using test-only migration functions ─────────────
    //
    // Test schema versions:
    //   v1 → v2: adds "addedInV2": "hello"
    //   v2 → v3: renames "legacyField" → "renamedField"

    /// v1→v2: adds a new field.
    fn fake_v1_to_v2(doc: &mut Value) -> Result<()> {
        if let Some(obj) = doc.as_object_mut() {
            obj.insert("addedInV2".to_string(), Value::from("hello"));
        }
        Ok(())
    }

    /// v2→v3: renames a field.
    fn fake_v2_to_v3(doc: &mut Value) -> Result<()> {
        if let Some(obj) = doc.as_object_mut() {
            if let Some(old) = obj.remove("legacyField") {
                obj.insert("renamedField".to_string(), old);
            }
        }
        Ok(())
    }

    /// Always fails — used to test error propagation.
    fn fake_failing_migration(doc: &mut Value) -> Result<()> {
        let _ = doc;
        SchemaMigrationSnafu {
            message: "simulated failure".to_string(),
        }
        .fail()
    }

    /// Full v1→v2→v3 chain.
    fn full_chain() -> &'static [(i64, MigrationFn)] {
        &[(1, fake_v1_to_v2), (2, fake_v2_to_v3)]
    }

    /// Minimal document at a given schema version.
    fn doc_at_version(version: i64) -> Value {
        serde_json::json!({
            (SCHEMA_VERSION_FIELD): version,
            "id": "unit-1"
        })
    }

    /// v1 document with a field that v2→v3 will rename.
    fn v1_doc_with_legacy_field() -> Value {
        serde_json::json!({
            (SCHEMA_VERSION_FIELD): 1,
            "id": "unit-1",
            "legacyField": "keep-me"
        })
    }

    /// v1 document with extra fields to verify they survive migration.
    fn v1_doc_with_extra_fields() -> Value {
        serde_json::json!({
            (SCHEMA_VERSION_FIELD): 1,
            "id": "unit-1",
            "customData": {"nested": true},
            "tags": ["a", "b"]
        })
    }

    #[test]
    fn test_pipeline_single_step_v1_to_v2() {
        let doc = doc_at_version(1);

        let result = migrate_with(doc, 2, &[(1, fake_v1_to_v2)]).unwrap();

        assert_eq!(result[SCHEMA_VERSION_FIELD], 2);
        assert_eq!(result["addedInV2"], "hello");
        assert_eq!(result["id"], "unit-1");
    }

    #[test]
    fn test_pipeline_two_steps_v1_to_v3() {
        let doc = v1_doc_with_legacy_field();

        let result = migrate_with(doc, 3, full_chain()).unwrap();

        assert_eq!(result[SCHEMA_VERSION_FIELD], 3);
        assert_eq!(result["addedInV2"], "hello");
        assert_eq!(result["renamedField"], "keep-me");
        assert!(result.get("legacyField").is_none());
    }

    #[test]
    fn test_pipeline_starts_from_middle_version() {
        let doc = doc_at_version(2);

        let result = migrate_with(doc, 3, full_chain()).unwrap();

        assert_eq!(result[SCHEMA_VERSION_FIELD], 3);
        assert!(
            result.get("addedInV2").is_none(),
            "v1→v2 should not have run"
        );
    }

    #[test]
    fn test_pipeline_incomplete_chain_reports_error() {
        let doc = doc_at_version(1);

        let err = migrate_with(doc, 3, &[(1, fake_v1_to_v2)]).unwrap_err();

        assert_eq!(err.error_code_i32(), 1021);
        assert!(err.to_string().contains("Migration chain incomplete"));
        assert!(err.to_string().contains("reached v2"));
        assert!(err.to_string().contains("expected v3"));
    }

    #[test]
    fn test_pipeline_migration_failure_stops_chain() {
        let chain: &[(i64, MigrationFn)] = &[(1, fake_failing_migration), (2, fake_v2_to_v3)];
        let doc = doc_at_version(1);

        let err = migrate_with(doc, 3, chain).unwrap_err();

        assert_eq!(err.error_code_i32(), 1021);
        assert!(err.to_string().contains("v1 to v2"));
        assert!(err.to_string().contains("simulated failure"));
    }

    #[test]
    fn test_pipeline_already_at_target_is_noop() {
        let doc = doc_at_version(2);

        let result = migrate_with(doc.clone(), 2, &[(1, fake_v1_to_v2)]).unwrap();

        assert_eq!(result, doc);
    }

    #[test]
    fn test_set_version_rejects_non_object_root() {
        let mut doc = Value::from("not-an-object");
        let err = set_version(&mut doc, 2).unwrap_err();
        assert_eq!(err.error_code_i32(), 1021);
        assert!(err.to_string().contains("must be a JSON object"));
    }

    #[test]
    fn test_pipeline_preserves_unrelated_fields() {
        let doc = v1_doc_with_extra_fields();

        let result = migrate_with(doc, 3, full_chain()).unwrap();

        assert_eq!(result["customData"]["nested"], true);
        assert_eq!(result["tags"][0], "a");
        assert_eq!(result["tags"][1], "b");
    }
}
