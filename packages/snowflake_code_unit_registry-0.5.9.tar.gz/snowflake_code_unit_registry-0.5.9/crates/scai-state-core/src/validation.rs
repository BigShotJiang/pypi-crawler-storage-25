//! Registry validation — JSON syntax, schema conformance, structural
//! integrity, and optional checksum verification.
//!
//! Each file is automatically migrated to [`CURRENT_SCHEMA_VERSION`](crate::migration::CURRENT_SCHEMA_VERSION)
//! before schema validation runs. If migration fails (e.g. future or
//! malformed `schemaVersion`), a [`SchemaMigrationError`](ValidationIssueKind::SchemaMigrationError)
//! issue is recorded with the originating error code.
//!
//! The JSON Schema is embedded at compile time and the compiled validator
//! is cached in an [`OnceLock`] so repeated calls avoid recompilation.

use std::collections::HashSet;
use std::fs;
use std::path::{Path, PathBuf};
use std::sync::OnceLock;

use serde::{Deserialize, Serialize};
use serde_json::Value;

use crate::checksum::{validate_checksum_report, ChecksumMode, ChecksumValidationStatus};
use crate::error::*;
use crate::generated::types::CodeUnit;
use crate::registry::paths::{filename_of, filename_stem};

const SCHEMA_JSON: &str = include_str!("../schemas/code-unit.schema.json");

fn schema_validator() -> &'static jsonschema::Validator {
    static VALIDATOR: OnceLock<jsonschema::Validator> = OnceLock::new();
    VALIDATOR.get_or_init(|| {
        let schema: Value =
            serde_json::from_str(SCHEMA_JSON).expect("embedded schema is valid JSON");
        jsonschema::validator_for(&schema).expect("embedded schema compiles")
    })
}

// ── Types ────────────────────────────────────────────────────────────────

/// Category of a validation issue.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ValidationIssueKind {
    IoError,
    InvalidJson,
    SchemaViolation,
    DeserializationError,
    MissingId,
    IdFilenameMismatch,
    DuplicateId,
    UnresolvedDependency,
    ChecksumMismatch,
    NonCanonicalPath,
    SchemaMigrationError,
}

/// A single validation issue tied to a specific file.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ValidationIssue {
    pub file: String,
    pub kind: ValidationIssueKind,
    pub message: String,
    /// Stable error code from the core `Error` enum, when the issue
    /// originates from a core operation (e.g. migration). `None` for
    /// issues that are purely validation-layer concerns (e.g. duplicate ID).
    #[serde(skip_serializing_if = "Option::is_none")]
    pub error_code: Option<i32>,
}

impl ValidationIssue {
    fn new(file: &str, kind: ValidationIssueKind, message: impl Into<String>) -> Self {
        Self {
            file: file.to_string(),
            kind,
            message: message.into(),
            error_code: None,
        }
    }

    fn with_error_code(mut self, code: i32) -> Self {
        self.error_code = Some(code);
        self
    }
}

/// Result of a registry validation run.
///
/// `is_valid` is `true` only when `issues` is empty.
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct ValidationReport {
    pub is_valid: bool,
    pub files_checked: usize,
    pub issues: Vec<ValidationIssue>,
}

impl ValidationReport {
    fn from_issues(files_checked: usize, issues: Vec<ValidationIssue>) -> Self {
        Self {
            is_valid: issues.is_empty(),
            files_checked,
            issues,
        }
    }
}

// ── Helpers ──────────────────────────────────────────────────────────────

/// On `Ok`, returns `Some(value)`. On `Err`, records a validation issue and
/// returns `None` so the caller can short-circuit with `?`.
fn try_or_issue<T, E: std::fmt::Display>(
    result: std::result::Result<T, E>,
    issues: &mut Vec<ValidationIssue>,
    file: &str,
    kind: ValidationIssueKind,
    context: &str,
) -> Option<T> {
    match result {
        Ok(v) => Some(v),
        Err(e) => {
            issues.push(ValidationIssue::new(file, kind, format!("{context}: {e}")));
            None
        }
    }
}

/// Like [`try_or_issue`], but for core `Error` results — extracts the stable
/// error code and attaches it to the validation issue.
fn try_or_issue_with_code<T>(
    result: Result<T>,
    issues: &mut Vec<ValidationIssue>,
    file: &str,
    kind: ValidationIssueKind,
    context: &str,
) -> Option<T> {
    match result {
        Ok(v) => Some(v),
        Err(e) => {
            let code = e.error_code_i32();
            issues.push(
                ValidationIssue::new(file, kind, format!("{context}: {e}")).with_error_code(code),
            );
            None
        }
    }
}

/// Collect all `.json` file paths and their filenames from a directory.
fn list_json_files(dir: &Path) -> Result<Vec<(PathBuf, String)>> {
    Ok(crate::registry::paths::json_file_paths(dir)?
        .into_iter()
        .map(|p| {
            let name = filename_of(&p);
            (p, name)
        })
        .collect())
}

// ── Per-file validation ──────────────────────────────────────────────────

/// Validate a single JSON file against the schema and structural rules.
///
/// Issues are accumulated into `issues` as they are found. Returns
/// `Some(CodeUnit)` when parsing succeeds (even if issues were recorded),
/// or `None` when the file is too broken to parse.
fn validate_file(
    path: &Path,
    filename: &str,
    checksum_mode: &ChecksumMode,
    root: &Path,
    issues: &mut Vec<ValidationIssue>,
) -> Option<CodeUnit> {
    let contents = try_or_issue(
        fs::read_to_string(path),
        issues,
        filename,
        ValidationIssueKind::IoError,
        "Failed to read file",
    )?;

    let value: Value = try_or_issue(
        serde_json::from_str(&contents),
        issues,
        filename,
        ValidationIssueKind::InvalidJson,
        "Invalid JSON",
    )?;

    let value: Value = try_or_issue_with_code(
        crate::migration::migrate(value),
        issues,
        filename,
        ValidationIssueKind::SchemaMigrationError,
        "Schema migration failed",
    )?;

    // Schema validation — collects multiple errors, doesn't short-circuit.
    let validator = schema_validator();
    for error in validator.iter_errors(&value) {
        issues.push(ValidationIssue::new(
            filename,
            ValidationIssueKind::SchemaViolation,
            format!("{error} (at {})", error.instance_path()),
        ));
    }

    // Non-canonical path detection — runs before from_value consumes the Value.
    check_non_canonical_paths(&value, filename, issues);

    // Deserialization — collects multiple errors, doesn't short-circuit.
    let code_unit: CodeUnit = try_or_issue(
        serde_json::from_value(value),
        issues,
        filename,
        ValidationIssueKind::DeserializationError,
        "Failed to deserialize",
    )?;

    // ID / filename consistency
    if let (Ok(stem), Some(ref id)) = (filename_stem(path), &code_unit.id) {
        if id != stem {
            issues.push(ValidationIssue::new(
                filename,
                ValidationIssueKind::IdFilenameMismatch,
                format!("ID '{id}' does not match filename stem '{stem}'"),
            ));
        }
    }

    // Checksum validation (skipped when mode is none)
    if !checksum_mode.is_none() {
        let report = validate_checksum_report(&code_unit, checksum_mode, root);
        for entry in &report.entries {
            let msg = match entry.status {
                ChecksumValidationStatus::Mismatch => format!(
                    "Checksum mismatch on field '{}': stored={}, computed={}",
                    entry.field,
                    entry.stored_checksum.as_deref().unwrap_or("none"),
                    entry.computed_checksum.as_deref().unwrap_or("none"),
                ),
                ChecksumValidationStatus::MissingFile => format!(
                    "File not found for field '{}': path is set but file does not exist on disk",
                    entry.field,
                ),
                ChecksumValidationStatus::IoError => format!(
                    "I/O error reading file for field '{}': unable to compute checksum",
                    entry.field,
                ),
                _ => continue,
            };
            issues.push(ValidationIssue::new(
                filename,
                ValidationIssueKind::ChecksumMismatch,
                msg,
            ));
        }
    }

    Some(code_unit)
}

fn check_non_canonical_paths(value: &Value, filename: &str, issues: &mut Vec<ValidationIssue>) {
    use crate::generated::file_path_fields::FILE_PATH_FIELDS;
    use crate::registry::paths::navigate_path;

    for segments in FILE_PATH_FIELDS {
        let Some(s) = navigate_path(value, segments).and_then(|v| v.as_str()) else {
            continue;
        };
        if s.contains('\\') {
            issues.push(ValidationIssue::new(
                filename,
                ValidationIssueKind::NonCanonicalPath,
                format!(
                    "Field '{}' contains backslash separators: '{s}'. \
                     Paths will be normalized to forward slashes on next write.",
                    segments.join("."),
                ),
            ));
        }
    }
}

// ── Cross-unit checks ────────────────────────────────────────────────────

/// Check that all dependency references point to existing units. Please note that the
/// existing units might not have a corresponding source code file, but the CodeUnit file
/// is still expected to exist (this is the case of missing dependencies).
fn check_referential_integrity(
    units: &[(String, String, CodeUnit)],
    known_ids: &HashSet<String>,
    issues: &mut Vec<ValidationIssue>,
) {
    for (_, filename, unit) in units {
        let unresolved = unit
            .dependencies
            .iter()
            .flat_map(|deps| deps.depends_on.iter())
            .filter_map(|dep| dep.id.as_deref())
            .filter(|dep_id| !known_ids.contains(*dep_id));

        for dep_id in unresolved {
            issues.push(ValidationIssue::new(
                filename,
                ValidationIssueKind::UnresolvedDependency,
                format!("Depends on '{dep_id}' which does not exist in the registry"),
            ));
        }
    }
}

// ── Entry points ─────────────────────────────────────────────────────────

/// Validate all code units in the registry.
pub(crate) fn validate_registry(
    registry_dir: &Path,
    checksum_mode: &ChecksumMode,
    root: &Path,
) -> Result<ValidationReport> {
    if !registry_dir.exists() {
        return Ok(ValidationReport::from_issues(0, vec![]));
    }

    let json_files = list_json_files(registry_dir)?;
    let mut issues = Vec::new();
    let mut seen_ids: HashSet<String> = HashSet::new();
    let mut parsed_units: Vec<(String, String, CodeUnit)> = Vec::new();

    for (path, filename) in &json_files {
        if let Some(unit) = validate_file(path, filename, checksum_mode, root, &mut issues) {
            let id = match &unit.id {
                Some(id) => id.clone(),
                None => {
                    issues.push(ValidationIssue::new(
                        filename,
                        ValidationIssueKind::MissingId,
                        "Code unit has no 'id' field",
                    ));
                    filename_stem(path).unwrap_or_default().to_string()
                }
            };
            if !seen_ids.insert(id.clone()) {
                issues.push(ValidationIssue::new(
                    filename,
                    ValidationIssueKind::DuplicateId,
                    format!("Duplicate ID '{id}'"),
                ));
            }
            parsed_units.push((id, filename.clone(), unit));
        }
    }

    check_referential_integrity(&parsed_units, &seen_ids, &mut issues);

    Ok(ValidationReport::from_issues(json_files.len(), issues))
}

/// Validate a single code unit file.
pub(crate) fn validate_single(
    path: &Path,
    checksum_mode: &ChecksumMode,
    root: &Path,
) -> Result<ValidationReport> {
    if !path.exists() {
        let id = filename_stem(path).unwrap_or_default();
        return CodeUnitNotFoundSnafu { id }.fail();
    }

    let filename = filename_of(path);
    let mut issues = Vec::new();

    validate_file(path, &filename, checksum_mode, root, &mut issues);

    Ok(ValidationReport::from_issues(1, issues))
}
