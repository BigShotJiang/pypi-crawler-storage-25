// AUTO-GENERATED FROM JSON SCHEMA - DO NOT EDIT MANUALLY
// Segment paths of all file path properties in code-unit.schema.json

pub const FILE_PATH_FIELDS: &[&[&str]] = &[
    &["files", "artifacts", "path"],
    &["files", "converted", "path"],
    &["files", "snapshot", "path"],
    &["files", "source", "path"],
];
