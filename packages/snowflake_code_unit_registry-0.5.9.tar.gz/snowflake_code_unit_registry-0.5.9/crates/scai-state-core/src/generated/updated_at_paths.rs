// AUTO-GENERATED FROM JSON SCHEMA - DO NOT EDIT MANUALLY
// Parent paths of all `updatedAt` properties in code-unit.schema.json

pub const UPDATED_AT_PARENT_PATHS: &[&[&str]] = &[
    &[],
    &["cloudStatus", "dataMigration"],
    &["cloudStatus", "dataValidation"],
    &["cloudStatus", "deployment"],
    &["cloudStatus", "testing"],
    &["codeStatus", "registration"],
];
