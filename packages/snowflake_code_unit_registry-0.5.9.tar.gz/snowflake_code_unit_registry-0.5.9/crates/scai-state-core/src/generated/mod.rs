//! Auto-generated types from JSON Schema

pub mod file_path_fields;
pub mod query_reference;
pub mod types;
pub mod updated_at_paths;
