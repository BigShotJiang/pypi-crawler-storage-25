use super::*;
use crate::generated::types::{
    Kind as CodeUnitKind, ObjectType as CodeUnitObjectType, SourceMetadata, TargetMetadata,
};
use crate::migration::SCHEMA_VERSION_FIELD;

fn temp_dir() -> tempfile::TempDir {
    tempfile::tempdir().unwrap()
}

/// Create a registry with no built-in hooks (no checksum, no dependency
/// refresh). Use this in tests that don't need hook side-effects.
fn init_bare(path: &std::path::Path) -> CodeUnitRegistry {
    let root = path.to_path_buf();
    let registry_dir = root.join("registry");
    fs::create_dir_all(registry_dir.join(".locks")).unwrap();
    CodeUnitRegistry {
        root,
        hooks: vec![],
        in_hook: std::sync::atomic::AtomicBool::new(false),
    }
}

fn make_code_unit(id: &str, name: &str, object_type: CodeUnitObjectType) -> CodeUnit {
    CodeUnit {
        id: Some(id.to_string()),
        kind: Some(CodeUnitKind::DatabaseObject),
        source: Some(SourceMetadata {
            object_type: Some(object_type),
            database: Some("DB".to_string()),
            schema: Some("dbo".to_string()),
            name: Some(name.to_string()),
        }),
        target: Some(TargetMetadata {
            object_type: Some(object_type),
            database: Some("DB".to_string()),
            schema: Some("DBO".to_string()),
            name: Some(name.to_uppercase()),
        }),
        ..Default::default()
    }
}

fn sorted_ids(units: Vec<CodeUnit>) -> Vec<String> {
    let mut ids: Vec<String> = units.into_iter().filter_map(|unit| unit.id).collect();
    ids.sort_unstable();
    ids
}

fn set_dependencies(unit: &mut CodeUnit, deps: &[(&str, Option<bool>)]) {
    use crate::generated::types::{Dependencies, Dependency};

    if deps.is_empty() {
        unit.dependencies = None;
        return;
    }

    unit.dependencies = Some(Dependencies {
        depends_on: deps
            .iter()
            .map(|(id, is_missing)| Dependency {
                id: Some((*id).to_string()),
                is_missing: *is_missing,
                relation_types: vec!["SELECT".to_string()],
            })
            .collect(),
        ..Default::default()
    });
}

fn set_dependency_ids(unit: &mut CodeUnit, dep_ids: &[&str]) {
    let deps: Vec<(&str, Option<bool>)> = dep_ids.iter().map(|dep_id| (*dep_id, None)).collect();
    set_dependencies(unit, &deps);
}

#[test]
fn test_exists_before_and_after_init() {
    let dir = temp_dir();
    assert!(!CodeUnitRegistry::exists(dir.path()));
    CodeUnitRegistry::init(dir.path()).unwrap();
    assert!(CodeUnitRegistry::exists(dir.path()));
}

#[test]
fn test_init_registry() {
    let dir = temp_dir();
    let _registry = CodeUnitRegistry::init(dir.path()).unwrap();
    assert!(dir.path().join("registry").exists());
    assert!(dir.path().join("registry").join(".locks").exists());
}

#[test]
fn test_open_registry() {
    let dir = temp_dir();
    let _registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let registry2 = CodeUnitRegistry::open(dir.path()).unwrap();
    assert_eq!(registry2.root(), dir.path().to_path_buf());
}

#[test]
fn test_id_to_path() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let id = "abcdef12-3456-7890-abcd-ef1234567890";
    let expected = dir.path().join("registry").join(format!("{}.json", id));
    assert_eq!(registry.id_to_path(id), expected);
}

#[test]
fn test_create_batch_success() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let mut batch = vec![
        make_code_unit("id1", "Table1", CodeUnitObjectType::Table),
        make_code_unit("id2", "Table2", CodeUnitObjectType::Table),
        make_code_unit("id3", "Proc1", CodeUnitObjectType::Procedure),
    ];

    let result = registry.create_batch(&mut batch, None).unwrap();
    assert_eq!(result.succeeded.len(), 3);
    assert!(result.succeeded.contains(&"id1".to_string()));
    assert!(result.succeeded.contains(&"id2".to_string()));
    assert!(result.succeeded.contains(&"id3".to_string()));
    assert_eq!(result.failed.len(), 0);
    assert_eq!(result.total(), 3);

    // Verify all were created
    let all = registry.find_all(FindOptions::default()).unwrap();
    assert_eq!(all.len(), 3);
}

#[test]
fn test_create_batch_partial_failure_duplicate_ids() {
    let dir = temp_dir();
    let registry = init_bare(dir.path());

    let mut cu1 = make_code_unit("id1", "Table1", CodeUnitObjectType::Table);

    // First create one
    registry.create(&mut cu1, None).unwrap();

    // Now batch create with duplicate
    let mut batch = vec![
        make_code_unit("id1", "Table1", CodeUnitObjectType::Table), // duplicate - should fail
        make_code_unit("id2", "Table2", CodeUnitObjectType::Table), // new - should succeed
    ];

    let result = registry.create_batch(&mut batch, None).unwrap();
    assert_eq!(result.succeeded.len(), 1);
    assert!(result.succeeded.contains(&"id2".to_string()));
    assert_eq!(result.failed.len(), 1);
    assert_eq!(result.failed[0].id, "id1");
    assert_eq!(result.failed[0].error.code, 1004); // CodeUnitAlreadyExists
    assert!(result.failed[0].error.message.contains("already exists"));
}

#[test]
fn test_update_batch_success() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let mut cu1 = make_code_unit("id1", "Table1", CodeUnitObjectType::Table);
    let mut cu2 = make_code_unit("id2", "Table2", CodeUnitObjectType::Table);

    registry.create(&mut cu1, None).unwrap();
    registry.create(&mut cu2, None).unwrap();

    let batch: Vec<(&str, Vec<(&str, Value)>)> = vec![
        (
            "id1",
            vec![("source.name", Value::String("UpdatedTable1".to_string()))],
        ),
        (
            "id2",
            vec![("source.name", Value::String("UpdatedTable2".to_string()))],
        ),
    ];

    let result = registry.update_batch(&batch, None).unwrap();
    assert_eq!(result.succeeded.len(), 2);
    assert!(result.succeeded.contains(&"id1".to_string()));
    assert!(result.succeeded.contains(&"id2".to_string()));
    assert_eq!(result.failed.len(), 0);

    // Verify updates
    let loaded1 = registry.get_by_id("id1", None).unwrap();
    assert_eq!(loaded1.source.unwrap().name.unwrap(), "UpdatedTable1");
}

#[test]
fn test_update_batch_partial_failure_not_found() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let mut cu1 = make_code_unit("id1", "Table1", CodeUnitObjectType::Table);
    registry.create(&mut cu1, None).unwrap();

    let batch: Vec<(&str, Vec<(&str, Value)>)> = vec![
        (
            "id1",
            vec![("source.name", Value::String("Updated".to_string()))],
        ),
        (
            "nonexistent",
            vec![("source.name", Value::String("X".to_string()))],
        ),
    ];

    let result = registry.update_batch(&batch, None).unwrap();
    assert_eq!(result.succeeded.len(), 1);
    assert!(result.succeeded.contains(&"id1".to_string()));
    assert_eq!(result.failed.len(), 1);
    assert_eq!(result.failed[0].id, "nonexistent");
    assert_eq!(result.failed[0].error.code, 1003); // CodeUnitNotFound
    assert!(result.failed[0].error.message.contains("not found"));
}

#[test]
fn test_update_where_success() {
    let dir = temp_dir();
    let registry = init_bare(dir.path());

    let mut cu1 = make_code_unit("id1", "Table1", CodeUnitObjectType::Table);
    let mut cu2 = make_code_unit("id2", "Table2", CodeUnitObjectType::Table);
    let mut cu3 = make_code_unit("id3", "Proc1", CodeUnitObjectType::Procedure);

    registry.create(&mut cu1, None).unwrap();
    registry.create(&mut cu2, None).unwrap();
    registry.create(&mut cu3, None).unwrap();

    let updates: Vec<(&str, Value)> = vec![("source.database", Value::String("NEWDB".to_string()))];

    let result = registry
        .update_where("source.objectType = 'table'", &updates, None)
        .unwrap();
    assert_eq!(result.succeeded.len(), 2);
    assert!(result.succeeded.contains(&"id1".to_string()));
    assert!(result.succeeded.contains(&"id2".to_string()));
    assert_eq!(result.failed.len(), 0);

    // Verify only tables were updated
    let loaded1 = registry.get_by_id("id1", None).unwrap();
    assert_eq!(loaded1.source.unwrap().database.unwrap(), "NEWDB");

    let loaded3 = registry.get_by_id("id3", None).unwrap();
    assert_eq!(loaded3.source.unwrap().database.unwrap(), "DB"); // unchanged
}

#[test]
fn test_update_where_no_matches() {
    let dir = temp_dir();
    let registry = init_bare(dir.path());

    let mut cu1 = make_code_unit("id1", "Table1", CodeUnitObjectType::Table);
    registry.create(&mut cu1, None).unwrap();

    let updates: Vec<(&str, Value)> = vec![("source.database", Value::String("NEWDB".to_string()))];

    let result = registry
        .update_where("objectType = 'view'", &updates, None)
        .unwrap();
    assert_eq!(result.succeeded.len(), 0);
    assert_eq!(result.failed.len(), 0);
}

#[test]
fn test_find_all_include_dependencies_expands_transitive_matches() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let mut root = make_code_unit("root", "RootProc", CodeUnitObjectType::Procedure);
    let mut mid = make_code_unit("mid", "MidTable", CodeUnitObjectType::Table);
    let mut leaf = make_code_unit("leaf", "LeafView", CodeUnitObjectType::View);

    set_dependencies(&mut root, &[("mid", Some(false))]);
    set_dependencies(&mut mid, &[("leaf", Some(false))]);

    registry.create(&mut root, None).unwrap();
    registry.create(&mut mid, None).unwrap();
    registry.create(&mut leaf, None).unwrap();

    let filtered = registry
        .find_all(FindOptions {
            filter: Some("source.name = 'RootProc'"),
            ..FindOptions::default()
        })
        .unwrap();
    let filtered_ids = sorted_ids(filtered);
    assert_eq!(filtered_ids, vec!["root".to_string()]);

    let expanded = registry
        .find_all(FindOptions {
            filter: Some("source.name = 'RootProc'"),
            include_dependencies: true,
            ..FindOptions::default()
        })
        .unwrap();
    let expanded_ids = sorted_ids(expanded);
    assert_eq!(
        expanded_ids,
        vec!["leaf".to_string(), "mid".to_string(), "root".to_string()]
    );
}

#[test]
fn test_find_all_include_dependencies_noop_without_filter() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let mut root = make_code_unit("root", "RootProc", CodeUnitObjectType::Procedure);
    let mut dep = make_code_unit("dep", "DepTable", CodeUnitObjectType::Table);
    set_dependencies(&mut root, &[("dep", Some(false))]);

    registry.create(&mut root, None).unwrap();
    registry.create(&mut dep, None).unwrap();

    let all_default = registry.find_all(FindOptions::default()).unwrap();
    let all_include = registry
        .find_all(FindOptions {
            include_dependencies: true,
            ..FindOptions::default()
        })
        .unwrap();

    let default_ids = sorted_ids(all_default);
    let include_ids = sorted_ids(all_include);
    assert_eq!(default_ids, include_ids);
}

#[test]
fn test_batch_result_default() {
    let result = BatchResult::default();
    assert_eq!(result.succeeded.len(), 0);
    assert_eq!(result.failed.len(), 0);
    assert_eq!(result.total(), 0);
}

#[test]
fn test_create_generates_id_when_missing() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let mut cu = CodeUnit {
        id: None,
        kind: Some(CodeUnitKind::DatabaseObject),
        source: Some(SourceMetadata {
            object_type: Some(CodeUnitObjectType::Table),
            database: None,
            schema: None,
            name: None,
        }),
        ..Default::default()
    };

    let id = registry.create(&mut cu, None).unwrap();
    assert_eq!(id.len(), 36); // UUID v4 without dashes
    assert_eq!(cu.id, Some(id.clone())); // ID was set on the code unit

    // Verify it was created
    let loaded = registry.get_by_id(&id, None).unwrap();
    assert_eq!(loaded.id, Some(id));
}

#[test]
fn test_create_uses_existing_id() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let mut cu = make_code_unit("my_custom_id", "Table1", CodeUnitObjectType::Table);

    let id = registry.create(&mut cu, None).unwrap();
    assert_eq!(id, "my_custom_id");

    // Verify it was created with the provided ID
    let loaded = registry.get_by_id("my_custom_id", None).unwrap();
    assert_eq!(loaded.id, Some("my_custom_id".to_string()));
}

#[test]
fn test_delete_syncs() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();
    let mut cu = make_code_unit("id_del", "T", CodeUnitObjectType::Table);
    registry.create(&mut cu, None).unwrap();

    registry.delete("id_del").unwrap();
    assert!(!registry.id_to_path("id_del").exists());
}

#[test]
fn test_upsert_creates_new() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let mut cu = make_code_unit("upsert1", "Table1", CodeUnitObjectType::Table);
    let id = registry.upsert(&mut cu, None).unwrap();
    assert_eq!(id, "upsert1");

    let loaded = registry.get_by_id("upsert1", None).unwrap();
    assert_eq!(
        loaded.source.as_ref().unwrap().name.as_deref(),
        Some("Table1")
    );
}

#[test]
fn test_upsert_merges_existing() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    use crate::generated::types::{ArtifactsEntry, Files};
    // Create initial — include an artifacts path to verify merge preserves it
    let mut cu = make_code_unit("upsert2", "Table1", CodeUnitObjectType::Table);
    cu.files = Some(Files {
        artifacts: Some(ArtifactsEntry {
            path: Some("artifacts/dbo/Tables/Table1".to_string()),
        }),
        ..Default::default()
    });
    registry.create(&mut cu, None).unwrap();

    // Upsert with updated source name but no target
    let mut patch = CodeUnit {
        id: Some("upsert2".to_string()),
        source: Some(SourceMetadata {
            name: Some("UpdatedTable1".to_string()),
            ..Default::default()
        }),
        ..Default::default()
    };

    let id = registry.upsert(&mut patch, None).unwrap();
    assert_eq!(id, "upsert2");

    let loaded = registry.get_by_id("upsert2", None).unwrap();
    // Source name should be updated
    assert_eq!(
        loaded.source.as_ref().unwrap().name.as_deref(),
        Some("UpdatedTable1")
    );
    // Target should still be present from original create
    assert!(loaded.target.is_some());
    assert_eq!(
        loaded.target.as_ref().unwrap().name.as_deref(),
        Some("TABLE1")
    );
    // Artifacts should be preserved from original create
    assert_eq!(
        loaded.files.unwrap().artifacts.unwrap().path.as_deref(),
        Some("artifacts/dbo/Tables/Table1")
    );

    fs::remove_dir_all(&dir).unwrap();
}

#[test]
fn test_upsert_generates_id_when_missing() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let mut cu = CodeUnit {
        kind: Some(CodeUnitKind::DatabaseObject),
        source: Some(SourceMetadata {
            object_type: Some(CodeUnitObjectType::Table),
            ..Default::default()
        }),
        ..Default::default()
    };

    let id = registry.upsert(&mut cu, None).unwrap();
    assert_eq!(id.len(), 36); // UUID v4 with hyphens (8-4-4-4-12)
    assert_eq!(cu.id, Some(id.clone()));
}

#[test]
fn test_upsert_batch() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    // Create one existing
    let mut existing = make_code_unit("ub1", "Table1", CodeUnitObjectType::Table);
    registry.create(&mut existing, None).unwrap();

    // Batch upsert: one existing (merge) + one new (create)
    let mut batch = vec![
        {
            let mut cu = make_code_unit("ub1", "UpdatedTable1", CodeUnitObjectType::Table);
            cu.target = None; // don't touch target
            cu
        },
        make_code_unit("ub2", "Table2", CodeUnitObjectType::Table),
    ];

    let result = registry.upsert_batch(&mut batch, None).unwrap();
    assert_eq!(result.succeeded.len(), 2);
    assert_eq!(result.failed.len(), 0);

    // ub1 should have merged source name but kept original target
    let loaded = registry.get_by_id("ub1", None).unwrap();
    assert_eq!(
        loaded.source.as_ref().unwrap().name.as_deref(),
        Some("UpdatedTable1")
    );
    assert!(loaded.target.is_some());

    // ub2 should be brand new
    let loaded2 = registry.get_by_id("ub2", None).unwrap();
    assert_eq!(
        loaded2.source.as_ref().unwrap().name.as_deref(),
        Some("Table2")
    );
}

#[test]
fn test_error_codes() {
    let err = RegistryNotFoundSnafu { path: "/tmp/x" }.build();
    assert_eq!(err.error_code_i32(), 1001);

    let err = CodeUnitNotFoundSnafu { id: "abc" }.build();
    assert_eq!(err.error_code_i32(), 1003);

    let err = FilterSnafu { message: "bad" }.build();
    assert_eq!(err.error_code_i32(), 1011);
}

// ── find_by_object tests ─────────────────────────────────────────────

#[test]
fn test_find_by_object_match_by_object_type() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let mut cu1 = make_code_unit("id1", "Table1", CodeUnitObjectType::Table);
    let mut cu2 = make_code_unit("id2", "Table2", CodeUnitObjectType::Table);
    let mut cu3 = make_code_unit("id3", "Proc1", CodeUnitObjectType::Procedure);

    registry.create(&mut cu1, None).unwrap();
    registry.create(&mut cu2, None).unwrap();
    registry.create(&mut cu3, None).unwrap();

    // Match by source.objectType = table
    let partial = serde_json::json!({ "source": { "objectType": "table" } });
    let results = registry.find_by_object(&partial, None).unwrap();
    assert_eq!(results.len(), 2);
    assert_eq!(
        sorted_ids(results),
        vec!["id1".to_string(), "id2".to_string()]
    );

    // Match by source.objectType = procedure
    let partial = serde_json::json!({ "source": { "objectType": "procedure" } });
    let results = registry.find_by_object(&partial, None).unwrap();
    assert_eq!(results.len(), 1);
    assert_eq!(results[0].id, Some("id3".to_string()));
}

#[test]
fn test_find_by_object_match_nested_fields() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let mut cu1 = make_code_unit("id1", "Table1", CodeUnitObjectType::Table);
    let mut cu2 = make_code_unit("id2", "Table2", CodeUnitObjectType::Table);

    // cu2 has a different schema
    cu2.source = Some(SourceMetadata {
        object_type: Some(CodeUnitObjectType::Table),
        database: Some("DB".to_string()),
        schema: Some("sales".to_string()),
        name: Some("Table2".to_string()),
    });

    registry.create(&mut cu1, None).unwrap();
    registry.create(&mut cu2, None).unwrap();

    // Match by source.schema = "dbo"
    let partial = serde_json::json!({ "source": { "schema": "dbo" } });
    let results = registry.find_by_object(&partial, None).unwrap();
    assert_eq!(results.len(), 1);
    assert_eq!(results[0].id, Some("id1".to_string()));

    // Match by source.schema = "sales"
    let partial = serde_json::json!({ "source": { "schema": "sales" } });
    let results = registry.find_by_object(&partial, None).unwrap();
    assert_eq!(results.len(), 1);
    assert_eq!(results[0].id, Some("id2".to_string()));
}

#[test]
fn test_find_by_object_multiple_fields() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let mut cu1 = make_code_unit("id1", "Table1", CodeUnitObjectType::Table);
    let mut cu2 = make_code_unit("id2", "Proc1", CodeUnitObjectType::Procedure);
    let mut cu3 = make_code_unit("id3", "Table2", CodeUnitObjectType::Table);

    // cu3 has a different schema
    cu3.source = Some(SourceMetadata {
        object_type: Some(CodeUnitObjectType::Table),
        database: Some("DB".to_string()),
        schema: Some("sales".to_string()),
        name: Some("Table2".to_string()),
    });

    registry.create(&mut cu1, None).unwrap();
    registry.create(&mut cu2, None).unwrap();
    registry.create(&mut cu3, None).unwrap();

    // Match source.objectType = table AND source.schema = dbo
    let partial = serde_json::json!({
        "source": { "objectType": "table", "schema": "dbo" }
    });
    let results = registry.find_by_object(&partial, None).unwrap();
    assert_eq!(results.len(), 1);
    assert_eq!(results[0].id, Some("id1".to_string()));
}

#[test]
fn test_find_by_object_no_matches() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let mut cu1 = make_code_unit("id1", "Table1", CodeUnitObjectType::Table);
    registry.create(&mut cu1, None).unwrap();

    // Match source.objectType = view (no views exist)
    let partial = serde_json::json!({ "source": { "objectType": "view" } });
    let results = registry.find_by_object(&partial, None).unwrap();
    assert_eq!(results.len(), 0);
}

#[test]
fn test_find_by_object_empty_registry() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let partial = serde_json::json!({ "objectType": "table" });
    let results = registry.find_by_object(&partial, None).unwrap();
    assert_eq!(results.len(), 0);
}

#[test]
fn test_find_by_object_empty_partial_matches_all() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let mut cu1 = make_code_unit("id1", "Table1", CodeUnitObjectType::Table);
    let mut cu2 = make_code_unit("id2", "Proc1", CodeUnitObjectType::Procedure);

    registry.create(&mut cu1, None).unwrap();
    registry.create(&mut cu2, None).unwrap();

    // Empty partial matches all code units
    let partial = serde_json::json!({});
    let results = registry.find_by_object(&partial, None).unwrap();
    assert_eq!(results.len(), 2);
}

#[test]
fn test_find_by_object_with_field_projection() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let mut cu1 = make_code_unit("id1", "Table1", CodeUnitObjectType::Table);
    let mut cu2 = make_code_unit("id2", "Table2", CodeUnitObjectType::Table);
    let mut cu3 = make_code_unit("id3", "Proc1", CodeUnitObjectType::Procedure);

    registry.create(&mut cu1, None).unwrap();
    registry.create(&mut cu2, None).unwrap();
    registry.create(&mut cu3, None).unwrap();

    // Match tables, project only id and source
    let partial = serde_json::json!({ "source": { "objectType": "table" } });
    let fields = vec!["id", "source"];
    let results = registry.find_by_object(&partial, Some(&fields)).unwrap();
    assert_eq!(results.len(), 2);

    // Projected results should have source but NOT target
    for cu in &results {
        assert!(cu.id.is_some());
        assert!(cu.source.is_some());
        assert!(cu.target.is_none());
        assert!(cu.kind.is_none());
    }
}

#[test]
fn test_find_by_object_match_by_kind() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let mut cu1 = make_code_unit("id1", "Table1", CodeUnitObjectType::Table);
    registry.create(&mut cu1, None).unwrap();

    let partial = serde_json::json!({ "kind": "databaseObject" });
    let results = registry.find_by_object(&partial, None).unwrap();
    assert_eq!(results.len(), 1);

    let partial = serde_json::json!({ "kind": "script" });
    let results = registry.find_by_object(&partial, None).unwrap();
    assert_eq!(results.len(), 0);
}

#[test]
fn test_find_by_object_match_by_boolean_field() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let mut cu1 = make_code_unit("id1", "Table1", CodeUnitObjectType::Table);
    let mut cu2 = make_code_unit("id2", "Table2", CodeUnitObjectType::Table);
    cu2.is_missing = true;

    registry.create(&mut cu1, None).unwrap();
    registry.create(&mut cu2, None).unwrap();

    // Match isMissing = true
    let partial = serde_json::json!({ "isMissing": true });
    let results = registry.find_by_object(&partial, None).unwrap();
    assert_eq!(results.len(), 1);
    assert_eq!(results[0].id, Some("id2".to_string()));

    // Match isMissing = false
    let partial = serde_json::json!({ "isMissing": false });
    let results = registry.find_by_object(&partial, None).unwrap();
    assert_eq!(results.len(), 1);
    assert_eq!(results[0].id, Some("id1".to_string()));
}

#[test]
fn test_find_by_object_match_by_source_database_and_name() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let mut cu1 = make_code_unit("id1", "Table1", CodeUnitObjectType::Table);
    let mut cu2 = make_code_unit("id2", "Table2", CodeUnitObjectType::Table);

    cu2.source = Some(SourceMetadata {
        object_type: Some(CodeUnitObjectType::Table),
        database: Some("OTHER_DB".to_string()),
        schema: Some("dbo".to_string()),
        name: Some("Table2".to_string()),
    });

    registry.create(&mut cu1, None).unwrap();
    registry.create(&mut cu2, None).unwrap();

    // Match by source database
    let partial = serde_json::json!({ "source": { "database": "DB" } });
    let results = registry.find_by_object(&partial, None).unwrap();
    assert_eq!(results.len(), 1);
    assert_eq!(results[0].id, Some("id1".to_string()));

    // Match by source database AND name
    let partial = serde_json::json!({
        "source": { "database": "OTHER_DB", "name": "Table2" }
    });
    let results = registry.find_by_object(&partial, None).unwrap();
    assert_eq!(results.len(), 1);
    assert_eq!(results[0].id, Some("id2".to_string()));

    // Match by source name that doesn't exist
    let partial = serde_json::json!({
        "source": { "database": "DB", "name": "NonExistent" }
    });
    let results = registry.find_by_object(&partial, None).unwrap();
    assert_eq!(results.len(), 0);
}

#[test]
fn test_find_by_object_match_by_target() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let mut cu1 = make_code_unit("id1", "Table1", CodeUnitObjectType::Table);
    let mut cu2 = make_code_unit("id2", "Table2", CodeUnitObjectType::Table);

    registry.create(&mut cu1, None).unwrap();
    registry.create(&mut cu2, None).unwrap();

    // Match by target name
    let partial = serde_json::json!({ "target": { "name": "TABLE1" } });
    let results = registry.find_by_object(&partial, None).unwrap();
    assert_eq!(results.len(), 1);
    assert_eq!(results[0].id, Some("id1".to_string()));
}

#[test]
fn test_find_by_object_match_by_id() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let mut cu1 = make_code_unit("id1", "Table1", CodeUnitObjectType::Table);
    let mut cu2 = make_code_unit("id2", "Table2", CodeUnitObjectType::Table);

    registry.create(&mut cu1, None).unwrap();
    registry.create(&mut cu2, None).unwrap();

    // Match by id directly
    let partial = serde_json::json!({ "id": "id1" });
    let results = registry.find_by_object(&partial, None).unwrap();
    assert_eq!(results.len(), 1);
    assert_eq!(results[0].id, Some("id1".to_string()));
}

#[test]
fn test_example_json_roundtrip_fidelity() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let example = include_str!("../../examples/code-unit.example.json");
    let original: serde_json::Value = serde_json::from_str(example).unwrap();

    let mut code_unit: CodeUnit = serde_json::from_str(example).unwrap();
    let id = registry.create(&mut code_unit, None).unwrap();

    let file_path = registry.id_to_path(&id);
    let on_disk = fs::read_to_string(&file_path).unwrap();
    let roundtripped: serde_json::Value = serde_json::from_str(&on_disk).unwrap();

    let mut original_norm = original.clone();
    let mut roundtripped_norm = roundtripped.clone();

    // Datetime fields may have different but semantically equivalent formats
    // (e.g. "+00:00" vs "Z") after chrono round-trip, so normalize those.
    for val in [&mut original_norm, &mut roundtripped_norm] {
        if let Some(v) = val.pointer_mut("/updatedAt") {
            *v = serde_json::Value::String("<datetime>".to_string());
        }
        if let Some(v) = val.pointer_mut("/codeStatus/registration/updatedAt") {
            *v = serde_json::Value::String("<datetime>".to_string());
        }
        if let Some(v) = val.pointer_mut("/cloudStatus/testing/updatedAt") {
            *v = serde_json::Value::String("<datetime>".to_string());
        }
        if let Some(v) = val.pointer_mut("/cloudStatus/deployment/updatedAt") {
            *v = serde_json::Value::String("<datetime>".to_string());
        }
        if let Some(v) = val.pointer_mut("/cloudStatus/dataMigration/updatedAt") {
            *v = serde_json::Value::String("<datetime>".to_string());
        }
        if let Some(v) = val.pointer_mut("/cloudStatus/dataValidation/updatedAt") {
            *v = serde_json::Value::String("<datetime>".to_string());
        }
    }

    // Auto-refresh reconciles dependency-derived fields. The example's
    // dependencies reference IDs absent from this test registry, so:
    if let Some(v) = original_norm.pointer_mut("/planning/topologicalRank") {
        *v = serde_json::Value::Number(0.into());
    }
    if let Some(v) = original_norm.pointer_mut("/dependencies/hasTransitiveMissingDependencies") {
        *v = serde_json::Value::Bool(true);
    }
    if let Some(deps) = original_norm.pointer_mut("/dependencies/dependsOn") {
        if let Some(arr) = deps.as_array_mut() {
            for dep in arr {
                if let Some(v) = dep.pointer_mut("/isMissing") {
                    *v = serde_json::Value::Bool(true);
                }
            }
        }
    }
    for val in [&mut original_norm, &mut roundtripped_norm] {
        if let Some(deps) = val.pointer_mut("/dependencies") {
            deps.as_object_mut().unwrap().remove("requiredBy");
        }
    }

    assert_eq!(
        original_norm, roundtripped_norm,
        "Schema round-trip lost or renamed fields"
    );
}

/// Recursively inject `"required": [all property keys]` into every
/// JSON Schema object that has `"properties"`, including nested objects,
/// `definitions`, and array `items`.  This turns an all-optional schema
/// into one where every property must be present.
fn make_all_properties_required(value: &mut serde_json::Value) {
    let obj = match value.as_object_mut() {
        Some(o) => o,
        None => return,
    };

    if let Some(keys) = obj
        .get("properties")
        .and_then(|p| p.as_object())
        .map(|p| p.keys().cloned().collect::<Vec<_>>())
    {
        obj.insert("required".to_string(), serde_json::json!(keys));
    }

    if let Some(props) = obj.get_mut("properties").and_then(|p| p.as_object_mut()) {
        for prop_schema in props.values_mut() {
            make_all_properties_required(prop_schema);
        }
    }
    if let Some(defs) = obj.get_mut("definitions").and_then(|d| d.as_object_mut()) {
        for def_schema in defs.values_mut() {
            make_all_properties_required(def_schema);
        }
    }
    if let Some(items) = obj.get_mut("items") {
        make_all_properties_required(items);
    }
}

#[test]
fn test_example_json_covers_all_schema_fields() {
    let mut schema: serde_json::Value =
        serde_json::from_str(include_str!("../../schemas/code-unit.schema.json")).unwrap();
    let example: serde_json::Value =
        serde_json::from_str(include_str!("../../examples/code-unit.example.json")).unwrap();

    make_all_properties_required(&mut schema);

    let validator = jsonschema::validator_for(&schema).expect("Failed to compile modified schema");

    let errors: Vec<String> = validator
        .iter_errors(&example)
        .map(|e| format!("  {e} (at {})", e.instance_path()))
        .collect();

    assert!(
        errors.is_empty(),
        "code-unit.example.json is missing values for schema properties:\n{}\n\
         Run './scripts/generate-types.sh' to update the example JSON to include realistic sample values for all fields.\n",
        errors.join("\n")
    );
}

// ── Checksum tests ────────────────────────────────────────────────────

/// Write a temp file in the registry's root and return its repo-relative path.
fn write_temp_source(dir: &Path, name: &str, content: &[u8]) -> String {
    let path = dir.join(name);
    fs::write(&path, content).unwrap();
    name.to_string()
}

fn make_code_unit_with_files(
    id: &str,
    source_path: Option<String>,
    converted_path: Option<String>,
    snapshot_path: Option<String>,
) -> CodeUnit {
    use crate::generated::types::{FileEntry, Files};
    let make_entry = |path: Option<String>| {
        path.map(|p| FileEntry {
            path: Some(p),
            checksum: None,
        })
    };
    CodeUnit {
        id: Some(id.to_string()),
        kind: Some(crate::generated::types::Kind::DatabaseObject),
        source: Some(SourceMetadata {
            object_type: Some(crate::generated::types::ObjectType::Table),
            database: None,
            schema: None,
            name: None,
        }),
        target: Some(TargetMetadata {
            object_type: Some(crate::generated::types::ObjectType::Table),
            ..Default::default()
        }),
        files: Some(Files {
            source: make_entry(source_path),
            converted: make_entry(converted_path),
            snapshot: make_entry(snapshot_path),
            ..Default::default()
        }),
        ..Default::default()
    }
}

#[test]
fn update_checksum_refreshes_all_changed_files() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();
    write_temp_source(dir.path(), "src.sql", b"src v1");
    write_temp_source(dir.path(), "snap.sql", b"snap v1");
    let mut cu =
        make_code_unit_with_files("cs5", Some("src.sql".into()), None, Some("snap.sql".into()));
    registry.create(&mut cu, None).unwrap();
    registry.update_checksum("cs5", ChecksumMode::ALL).unwrap();

    let before = registry.get_by_id("cs5", None).unwrap().files.unwrap();
    let source_before = before.source.unwrap().checksum.unwrap();
    let snapshot_before = before.snapshot.unwrap().checksum.unwrap();

    fs::write(dir.path().join("src.sql"), b"src v2").unwrap();
    fs::write(dir.path().join("snap.sql"), b"snap v2").unwrap();
    registry.update_checksum("cs5", ChecksumMode::ALL).unwrap();

    let after = registry.get_by_id("cs5", None).unwrap().files.unwrap();
    assert_ne!(source_before, after.source.unwrap().checksum.unwrap());
    assert_ne!(snapshot_before, after.snapshot.unwrap().checksum.unwrap());
}

#[test]
fn update_checksum_skips_unchanged_files() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();
    write_temp_source(dir.path(), "src.sql", b"src v1");
    write_temp_source(dir.path(), "snap.sql", b"snap v1");
    let mut cu = make_code_unit_with_files(
        "cs5b",
        Some("src.sql".into()),
        None,
        Some("snap.sql".into()),
    );
    registry.create(&mut cu, None).unwrap();
    registry.update_checksum("cs5b", ChecksumMode::ALL).unwrap();

    let before = registry.get_by_id("cs5b", None).unwrap().files.unwrap();
    let source_before = before.source.unwrap().checksum.unwrap();
    let snapshot_before = before.snapshot.unwrap().checksum.unwrap();

    fs::write(dir.path().join("src.sql"), b"src v2").unwrap();
    registry.update_checksum("cs5b", ChecksumMode::ALL).unwrap();

    let after = registry.get_by_id("cs5b", None).unwrap().files.unwrap();
    assert_ne!(source_before, after.source.unwrap().checksum.unwrap());
    assert_eq!(snapshot_before, after.snapshot.unwrap().checksum.unwrap());
}

#[test]
fn validate_checksum_reports_mismatch() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();
    let path = write_temp_source(dir.path(), "mismatch.sql", b"version 1");
    let mut cu = make_code_unit_with_files("cs6", Some(path.clone()), None, None);
    registry.create(&mut cu, None).unwrap();
    registry.update_checksum("cs6", ChecksumMode::ALL).unwrap();

    fs::write(dir.path().join(path), b"version 2").unwrap();
    let report = registry
        .validate_checksum("cs6", ChecksumMode::SOURCE)
        .unwrap();
    let source = report
        .entries
        .iter()
        .find(|e| e.field == "files.source")
        .unwrap();
    assert_eq!(
        source.status,
        crate::checksum::ChecksumValidationStatus::Mismatch
    );
}

#[test]
fn validate_checksum_reports_missing_file() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();
    let path = write_temp_source(dir.path(), "missing.sql", b"payload");
    let mut cu = make_code_unit_with_files("cs7", Some(path.clone()), None, None);
    registry.create(&mut cu, None).unwrap();
    registry.update_checksum("cs7", ChecksumMode::ALL).unwrap();

    fs::remove_file(dir.path().join(path)).unwrap();
    let report = registry
        .validate_checksum("cs7", ChecksumMode::SOURCE)
        .unwrap();
    let source = report
        .entries
        .iter()
        .find(|e| e.field == "files.source")
        .unwrap();
    assert_eq!(
        source.status,
        crate::checksum::ChecksumValidationStatus::MissingFile
    );
}

#[test]
fn test_matches_partial_helper() {
    // Exact match
    assert!(matches_partial(
        &serde_json::json!({"a": 1}),
        &serde_json::json!({"a": 1, "b": 2})
    ));

    // Nested match
    assert!(matches_partial(
        &serde_json::json!({"a": {"x": 1}}),
        &serde_json::json!({"a": {"x": 1, "y": 2}, "b": 3})
    ));

    // Mismatch value
    assert!(!matches_partial(
        &serde_json::json!({"a": 1}),
        &serde_json::json!({"a": 2})
    ));

    // Missing key in target
    assert!(!matches_partial(
        &serde_json::json!({"a": 1}),
        &serde_json::json!({"b": 1})
    ));

    // Empty partial matches everything
    assert!(matches_partial(
        &serde_json::json!({}),
        &serde_json::json!({"a": 1, "b": 2})
    ));

    // Scalar vs object mismatch
    assert!(!matches_partial(
        &serde_json::json!({"a": {"x": 1}}),
        &serde_json::json!({"a": 1})
    ));

    // Array match (exact)
    assert!(matches_partial(
        &serde_json::json!({"a": [1, 2]}),
        &serde_json::json!({"a": [1, 2]})
    ));

    // Array mismatch
    assert!(!matches_partial(
        &serde_json::json!({"a": [1, 2]}),
        &serde_json::json!({"a": [1, 3]})
    ));
}

// ── Refresh tests ────────────────────────────────────────────────────

fn make_unit_with_deps(id: &str, dep_ids: &[&str]) -> CodeUnit {
    let mut unit = make_code_unit(id, id, CodeUnitObjectType::Table);
    set_dependency_ids(&mut unit, dep_ids);
    unit
}

fn read_unit(registry: &CodeUnitRegistry, id: &str) -> CodeUnit {
    let path = registry.root().join("registry").join(format!("{id}.json"));
    registry.read_json(&path).unwrap()
}

#[test]
fn create_auto_refreshes_ranks() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    registry
        .create(&mut make_unit_with_deps("c", &[]), None)
        .unwrap();
    registry
        .create(&mut make_unit_with_deps("b", &["c"]), None)
        .unwrap();
    registry
        .create(&mut make_unit_with_deps("a", &["b"]), None)
        .unwrap();

    assert_eq!(
        read_unit(&registry, "c").planning.unwrap().topological_rank,
        Some(0)
    );
    assert_eq!(
        read_unit(&registry, "b").planning.unwrap().topological_rank,
        Some(1)
    );
    assert_eq!(
        read_unit(&registry, "a").planning.unwrap().topological_rank,
        Some(2)
    );
}

#[test]
fn create_auto_refresh_best_effort_on_cycle() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let id_x = registry
        .create(&mut make_unit_with_deps("x", &["y"]), None)
        .unwrap();
    let id_y = registry
        .create(&mut make_unit_with_deps("y", &["x"]), None)
        .unwrap();

    assert_eq!(id_x, "x");
    assert_eq!(id_y, "y");

    let x = read_unit(&registry, "x");
    assert_eq!(x.planning.unwrap().topological_rank, Some(-1));
    assert!(
        x.dependencies
            .as_ref()
            .unwrap()
            .has_transitive_missing_dependencies
    );

    let y = read_unit(&registry, "y");
    assert_eq!(y.planning.unwrap().topological_rank, Some(-1));
    assert!(
        y.dependencies
            .as_ref()
            .unwrap()
            .has_transitive_missing_dependencies
    );
}

#[test]
fn create_with_corrupt_sibling_succeeds_without_hooks() {
    let dir = temp_dir();
    let registry = init_bare(dir.path());

    registry
        .create(&mut make_unit_with_deps("good", &[]), None)
        .unwrap();

    let corrupt_path = registry.root().join("registry").join("corrupt.json");
    std::fs::write(&corrupt_path, "NOT VALID JSON").unwrap();

    registry
        .create(&mut make_unit_with_deps("new_unit", &[]), None)
        .unwrap();

    assert!(registry.id_to_path("new_unit").exists());
}

#[test]
fn create_batch_with_corrupt_sibling_succeeds_without_hooks() {
    let dir = temp_dir();
    let registry = init_bare(dir.path());

    let corrupt_path = registry.root().join("registry").join("corrupt.json");
    std::fs::write(&corrupt_path, "NOT VALID JSON").unwrap();

    let mut batch = vec![
        make_unit_with_deps("b1", &[]),
        make_unit_with_deps("b2", &[]),
    ];
    let result = registry.create_batch(&mut batch, None).unwrap();

    assert_eq!(result.succeeded.len(), 2);
    assert_eq!(result.failed.len(), 0);
}

#[test]
fn refresh_reconciles_dependency_is_missing() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let mut a = make_code_unit("a", "A", CodeUnitObjectType::Table);
    set_dependencies(&mut a, &[("b", Some(true))]);
    registry.create(&mut a, None).unwrap();
    registry
        .create(&mut make_unit_with_deps("b", &[]), None)
        .unwrap();

    registry.refresh_dependencies().unwrap();

    let a_after = read_unit(&registry, "a");
    let dep = &a_after.dependencies.unwrap().depends_on[0];
    assert_eq!(dep.is_missing, Some(false));
}

#[test]
fn refresh_strict_returns_cycle_error() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    registry
        .create(&mut make_unit_with_deps("x", &["y"]), None)
        .unwrap();
    registry
        .create(&mut make_unit_with_deps("y", &["x"]), None)
        .unwrap();

    let err = registry.refresh_dependencies().unwrap_err();
    assert_eq!(err.error_code_i32(), 1014);
}

#[test]
fn refresh_empty_registry_is_noop() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();
    registry.refresh_dependencies().unwrap();
}

#[test]
fn refresh_propagates_transitive_missing() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    registry
        .create(&mut make_unit_with_deps("a", &["b"]), None)
        .unwrap();
    registry
        .create(&mut make_unit_with_deps("b", &["missing"]), None)
        .unwrap();

    registry.refresh_dependencies().unwrap();

    let b = read_unit(&registry, "b");
    assert!(
        b.dependencies
            .as_ref()
            .unwrap()
            .has_transitive_missing_dependencies
    );

    let a = read_unit(&registry, "a");
    assert!(
        a.dependencies
            .as_ref()
            .unwrap()
            .has_transitive_missing_dependencies
    );
}

#[test]
fn refresh_is_idempotent() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    registry
        .create(&mut make_unit_with_deps("a", &["b"]), None)
        .unwrap();
    registry
        .create(&mut make_unit_with_deps("b", &["missing"]), None)
        .unwrap();

    registry.refresh_dependencies().unwrap();
    let a_first = serde_json::to_value(read_unit(&registry, "a")).unwrap();
    let b_first = serde_json::to_value(read_unit(&registry, "b")).unwrap();

    registry.refresh_dependencies().unwrap();
    let a_second = serde_json::to_value(read_unit(&registry, "a")).unwrap();
    let b_second = serde_json::to_value(read_unit(&registry, "b")).unwrap();

    assert_eq!(a_first, a_second);
    assert_eq!(b_first, b_second);
}

// ── Scoped refresh integration tests ─────────────────────────────────

#[test]
fn test_create_populates_required_by_on_deps() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    registry
        .create(&mut make_unit_with_deps("b", &[]), None)
        .unwrap();
    registry
        .create(&mut make_unit_with_deps("a", &["b"]), None)
        .unwrap();

    let b = read_unit(&registry, "b");
    assert_eq!(b.dependencies.as_ref().unwrap().required_by, vec!["a"]);

    let a = read_unit(&registry, "a");
    assert_eq!(
        a.dependencies.as_ref().unwrap().depends_on[0].is_missing,
        Some(false)
    );
    assert!(
        a.planning.unwrap().topological_rank.unwrap()
            > b.planning.unwrap().topological_rank.unwrap()
    );
}

#[test]
fn test_update_add_dep_refreshes_target() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    registry
        .create(&mut make_unit_with_deps("a", &[]), None)
        .unwrap();
    registry
        .create(&mut make_unit_with_deps("b", &[]), None)
        .unwrap();

    let b_before = read_unit(&registry, "b");
    assert!(b_before
        .dependencies
        .as_ref()
        .is_none_or(|d| d.required_by.is_empty()));

    registry
        .update(
            "a",
            &[(
                "dependencies",
                serde_json::json!({
                    "dependsOn": [{ "id": "b", "relationTypes": ["SELECT"] }]
                }),
            )],
            None,
        )
        .unwrap();

    let b_after = read_unit(&registry, "b");
    assert_eq!(
        b_after.dependencies.as_ref().unwrap().required_by,
        vec!["a"]
    );

    let a_after = read_unit(&registry, "a");
    assert!(
        a_after.planning.unwrap().topological_rank.unwrap()
            > b_after.planning.unwrap().topological_rank.unwrap()
    );
}

#[test]
fn test_update_remove_dep_clears_required_by() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    registry
        .create(&mut make_unit_with_deps("a", &["b"]), None)
        .unwrap();
    registry
        .create(&mut make_unit_with_deps("b", &[]), None)
        .unwrap();

    let b_before = read_unit(&registry, "b");
    assert_eq!(
        b_before.dependencies.as_ref().unwrap().required_by,
        vec!["a"]
    );

    registry
        .update(
            "a",
            &[(
                "dependencies",
                serde_json::json!({
                    "dependsOn": []
                }),
            )],
            None,
        )
        .unwrap();

    let b_after = read_unit(&registry, "b");
    assert!(b_after
        .dependencies
        .as_ref()
        .unwrap()
        .required_by
        .is_empty());

    let a_after = read_unit(&registry, "a");
    assert_eq!(a_after.planning.unwrap().topological_rank, Some(0));
}

#[test]
fn test_update_swap_dep_refreshes_old_and_new() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    registry
        .create(&mut make_unit_with_deps("a", &["b"]), None)
        .unwrap();
    registry
        .create(&mut make_unit_with_deps("b", &[]), None)
        .unwrap();
    registry
        .create(&mut make_unit_with_deps("c", &[]), None)
        .unwrap();

    assert_eq!(
        read_unit(&registry, "b")
            .dependencies
            .as_ref()
            .unwrap()
            .required_by,
        vec!["a"]
    );

    registry
        .update(
            "a",
            &[(
                "dependencies",
                serde_json::json!({
                    "dependsOn": [{ "id": "c", "relationTypes": ["SELECT"] }]
                }),
            )],
            None,
        )
        .unwrap();

    let b_after = read_unit(&registry, "b");
    assert!(b_after
        .dependencies
        .as_ref()
        .unwrap()
        .required_by
        .is_empty());

    let c_after = read_unit(&registry, "c");
    assert_eq!(
        c_after.dependencies.as_ref().unwrap().required_by,
        vec!["a"]
    );
}

#[test]
fn test_update_middle_node_propagates_via_stored_required_by() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    // A -> B -> C
    registry
        .create(&mut make_unit_with_deps("c", &[]), None)
        .unwrap();
    registry
        .create(&mut make_unit_with_deps("b", &["c"]), None)
        .unwrap();
    registry
        .create(&mut make_unit_with_deps("a", &["b"]), None)
        .unwrap();

    let a_before = read_unit(&registry, "a");
    assert!(
        !a_before
            .dependencies
            .as_ref()
            .unwrap()
            .has_transitive_missing_dependencies
    );

    // Update B: swap its dep from C to D (D doesn't exist).
    // Seeds will be ["b", "c"] — A is NOT explicitly seeded.
    // A is only reachable via B's stored requiredBy = ["a"].
    registry
        .update(
            "b",
            &[(
                "dependencies",
                serde_json::json!({
                    "dependsOn": [{ "id": "d", "relationTypes": ["SELECT"] }]
                }),
            )],
            None,
        )
        .unwrap();

    let b_after = read_unit(&registry, "b");
    assert_eq!(
        b_after.dependencies.as_ref().unwrap().depends_on[0].is_missing,
        Some(true)
    );
    assert!(
        b_after
            .dependencies
            .as_ref()
            .unwrap()
            .has_transitive_missing_dependencies
    );

    let a_after = read_unit(&registry, "a");
    assert!(
        a_after
            .dependencies
            .as_ref()
            .unwrap()
            .has_transitive_missing_dependencies
    );

    let c_after = read_unit(&registry, "c");
    assert!(c_after
        .dependencies
        .as_ref()
        .unwrap()
        .required_by
        .is_empty());
}

#[test]
fn test_delete_refreshes_deps_and_successors() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    registry
        .create(&mut make_unit_with_deps("a", &["b"]), None)
        .unwrap();
    registry
        .create(&mut make_unit_with_deps("b", &["c"]), None)
        .unwrap();
    registry
        .create(&mut make_unit_with_deps("c", &[]), None)
        .unwrap();

    let a_before = read_unit(&registry, "a");
    assert_eq!(
        a_before.dependencies.as_ref().unwrap().depends_on[0].is_missing,
        Some(false)
    );
    assert!(
        !a_before
            .dependencies
            .as_ref()
            .unwrap()
            .has_transitive_missing_dependencies
    );

    registry.delete("b").unwrap();

    let a_after = read_unit(&registry, "a");
    assert_eq!(
        a_after.dependencies.as_ref().unwrap().depends_on[0].is_missing,
        Some(true)
    );
    assert!(
        a_after
            .dependencies
            .as_ref()
            .unwrap()
            .has_transitive_missing_dependencies
    );

    let c_after = read_unit(&registry, "c");
    assert!(c_after
        .dependencies
        .as_ref()
        .unwrap()
        .required_by
        .is_empty());
}

#[test]
fn test_upsert_merge_changing_deps() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    registry
        .create(&mut make_unit_with_deps("a", &["b"]), None)
        .unwrap();
    registry
        .create(&mut make_unit_with_deps("b", &[]), None)
        .unwrap();
    registry
        .create(&mut make_unit_with_deps("c", &[]), None)
        .unwrap();

    assert_eq!(
        read_unit(&registry, "b")
            .dependencies
            .as_ref()
            .unwrap()
            .required_by,
        vec!["a"]
    );

    let mut patch = make_unit_with_deps("a", &["c"]);
    registry.upsert(&mut patch, None).unwrap();

    let b_after = read_unit(&registry, "b");
    assert!(b_after
        .dependencies
        .as_ref()
        .unwrap()
        .required_by
        .is_empty());

    let c_after = read_unit(&registry, "c");
    assert_eq!(
        c_after.dependencies.as_ref().unwrap().required_by,
        vec!["a"]
    );
}

#[test]
fn test_upsert_middle_node_propagates_via_stored_required_by() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    // A -> B -> C
    registry
        .create(&mut make_unit_with_deps("c", &[]), None)
        .unwrap();
    registry
        .create(&mut make_unit_with_deps("b", &["c"]), None)
        .unwrap();
    registry
        .create(&mut make_unit_with_deps("a", &["b"]), None)
        .unwrap();

    let a_before = read_unit(&registry, "a");
    assert!(
        !a_before
            .dependencies
            .as_ref()
            .unwrap()
            .has_transitive_missing_dependencies
    );

    // Upsert B: swap its dep from C to D (D doesn't exist).
    // A is NOT explicitly seeded — only reachable via B's stored requiredBy.
    let mut patch = make_unit_with_deps("b", &["d"]);
    registry.upsert(&mut patch, None).unwrap();

    let b_after = read_unit(&registry, "b");
    assert_eq!(
        b_after.dependencies.as_ref().unwrap().depends_on[0].is_missing,
        Some(true)
    );
    assert!(
        b_after
            .dependencies
            .as_ref()
            .unwrap()
            .has_transitive_missing_dependencies
    );

    let a_after = read_unit(&registry, "a");
    assert!(
        a_after
            .dependencies
            .as_ref()
            .unwrap()
            .has_transitive_missing_dependencies
    );

    let c_after = read_unit(&registry, "c");
    assert!(c_after
        .dependencies
        .as_ref()
        .unwrap()
        .required_by
        .is_empty());
}

#[test]
fn test_first_create_triggers_full_refresh_fallback() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    registry
        .create(&mut make_unit_with_deps("c", &[]), None)
        .unwrap();
    registry
        .create(&mut make_unit_with_deps("b", &["c"]), None)
        .unwrap();
    registry
        .create(&mut make_unit_with_deps("a", &["b"]), None)
        .unwrap();

    let a = read_unit(&registry, "a");
    let b = read_unit(&registry, "b");
    let c = read_unit(&registry, "c");

    assert_eq!(a.planning.unwrap().topological_rank, Some(2));
    assert_eq!(b.planning.unwrap().topological_rank, Some(1));
    assert_eq!(c.planning.unwrap().topological_rank, Some(0));

    assert_eq!(b.dependencies.as_ref().unwrap().required_by, vec!["a"]);
    assert_eq!(c.dependencies.as_ref().unwrap().required_by, vec!["b"]);
}

// ── Testing status tests ───────────────────────────────────────────

fn make_code_unit_with_testing(id: &str, name: &str, testing_status: &str) -> CodeUnit {
    use crate::generated::types::{CloudStatus, OperationStatus, TestingStatus};

    let status = testing_status.parse::<OperationStatus>().ok();
    let mut cu = make_code_unit(id, name, CodeUnitObjectType::Table);
    cu.cloud_status = Some(CloudStatus {
        testing: Some(TestingStatus {
            status,
            updated_at: Some(
                chrono::DateTime::parse_from_rfc3339("2025-06-15T14:30:00Z")
                    .unwrap()
                    .with_timezone(&chrono::Utc),
            ),
            details: {
                let mut m = serde_json::Map::new();
                m.insert(
                    "runner".to_string(),
                    serde_json::Value::String("pytest".to_string()),
                );
                m
            },
        }),
        ..Default::default()
    });
    cu
}

#[test]
fn test_create_with_testing_status_roundtrips() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let mut cu = make_code_unit_with_testing("ts-001", "T1", "completed");
    registry.create(&mut cu, None).unwrap();

    let loaded = registry.get_by_id("ts-001", None).unwrap();
    let testing = loaded.cloud_status.unwrap().testing.unwrap();

    assert_eq!(
        testing.status,
        Some(crate::generated::types::OperationStatus::Completed)
    );
    assert!(testing.updated_at.is_some());
    assert_eq!(
        testing.details.get("runner").and_then(|v| v.as_str()),
        Some("pytest")
    );
}

#[test]
fn test_filter_by_testing_status() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let mut cu1 = make_code_unit_with_testing("ft-001", "T1", "completed");
    let mut cu2 = make_code_unit_with_testing("ft-002", "T2", "failed");
    let mut cu3 = make_code_unit("ft-003", "T3", CodeUnitObjectType::Table);

    registry.create(&mut cu1, None).unwrap();
    registry.create(&mut cu2, None).unwrap();
    registry.create(&mut cu3, None).unwrap();

    let completed = registry
        .find_all(FindOptions {
            filter: Some("cloudStatus.testing.status = 'completed'"),
            ..FindOptions::default()
        })
        .unwrap();
    assert_eq!(sorted_ids(completed), vec!["ft-001"]);

    let failed = registry
        .find_all(FindOptions {
            filter: Some("cloudStatus.testing.status = 'failed'"),
            ..FindOptions::default()
        })
        .unwrap();
    assert_eq!(sorted_ids(failed), vec!["ft-002"]);

    let testing_null = registry
        .find_all(FindOptions {
            filter: Some("cloudStatus.testing IS NULL"),
            ..FindOptions::default()
        })
        .unwrap();
    assert_eq!(sorted_ids(testing_null), vec!["ft-003"]);
}

#[test]
fn test_update_where_sets_testing_status() {
    let dir = temp_dir();
    let registry = init_bare(dir.path());

    let mut cu1 = make_code_unit_with_testing("uw-001", "T1", "pending");
    let mut cu2 = make_code_unit_with_testing("uw-002", "T2", "pending");
    let mut cu3 = make_code_unit_with_testing("uw-003", "T3", "completed");

    registry.create(&mut cu1, None).unwrap();
    registry.create(&mut cu2, None).unwrap();
    registry.create(&mut cu3, None).unwrap();

    let updates: Vec<(&str, Value)> = vec![(
        "cloudStatus.testing.status",
        Value::String("completed".to_string()),
    )];

    let result = registry
        .update_where("cloudStatus.testing.status = 'pending'", &updates, None)
        .unwrap();
    assert_eq!(result.succeeded.len(), 2);

    let loaded1 = registry.get_by_id("uw-001", None).unwrap();
    assert_eq!(
        loaded1.cloud_status.unwrap().testing.unwrap().status,
        Some(crate::generated::types::OperationStatus::Completed)
    );

    let loaded3 = registry.get_by_id("uw-003", None).unwrap();
    assert_eq!(
        loaded3.cloud_status.unwrap().testing.unwrap().status,
        Some(crate::generated::types::OperationStatus::Completed)
    );
}

// ── Custom codeStatus phases (additionalProperties) ────────────────

#[test]
fn test_custom_code_status_phase_roundtrip() {
    use crate::generated::types::{CodeStatus, OperationStatus, RegistrationStatus};

    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let mut cu = make_code_unit("custom-001", "T1", CodeUnitObjectType::Table);
    let mut status = CodeStatus::default();
    status.registration = Some(RegistrationStatus {
        status: Some(OperationStatus::Completed),
        ..Default::default()
    });
    status.extra.insert(
        "dataQuality".to_string(),
        serde_json::json!({
            "status": "completed",
            "score": 95,
            "checkedAt": "2025-01-15T11:00:00Z"
        }),
    );
    cu.code_status = Some(status);
    registry.create(&mut cu, None).unwrap();

    let loaded = registry.get_by_id("custom-001", None).unwrap();
    let cs = loaded.code_status.unwrap();

    assert_eq!(
        cs.registration.unwrap().status,
        Some(OperationStatus::Completed)
    );
    let dq = cs
        .extra
        .get("dataQuality")
        .expect("custom phase must survive roundtrip");
    assert_eq!(dq["status"], "completed");
    assert_eq!(dq["score"], 95);
    assert_eq!(dq["checkedAt"], "2025-01-15T11:00:00Z");
}

#[test]
fn test_custom_code_status_phase_upsert_merge() {
    use crate::generated::types::{CodeStatus, OperationStatus, RegistrationStatus};

    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let mut cu = make_code_unit("custom-002", "T2", CodeUnitObjectType::Table);
    let mut status = CodeStatus::default();
    status.registration = Some(RegistrationStatus {
        status: Some(OperationStatus::Completed),
        ..Default::default()
    });
    status.extra.insert(
        "dataQuality".to_string(),
        serde_json::json!({"status": "pending"}),
    );
    cu.code_status = Some(status);
    registry.create(&mut cu, None).unwrap();

    let mut merge = CodeUnit {
        id: Some("custom-002".to_string()),
        ..Default::default()
    };
    let mut merge_status = CodeStatus::default();
    merge_status.extra.insert(
        "dataQuality".to_string(),
        serde_json::json!({"status": "completed", "score": 88}),
    );
    merge.code_status = Some(merge_status);
    registry.upsert(&mut merge, None).unwrap();

    let loaded = registry.get_by_id("custom-002", None).unwrap();
    let cs = loaded.code_status.unwrap();
    let dq = cs
        .extra
        .get("dataQuality")
        .expect("custom phase must survive upsert");
    assert_eq!(dq["status"], "completed");
    assert_eq!(dq["score"], 88);
}

// ── find_sql_file_changes integration tests ─────────────────────────

fn make_unit_with_source_file(id: &str, source_path: &str) -> CodeUnit {
    use crate::generated::types::{FileEntry, Files};
    CodeUnit {
        id: Some(id.to_string()),
        kind: Some(CodeUnitKind::DatabaseObject),
        source: Some(SourceMetadata {
            object_type: Some(CodeUnitObjectType::Table),
            ..Default::default()
        }),
        target: Some(TargetMetadata {
            object_type: Some(CodeUnitObjectType::Table),
            ..Default::default()
        }),
        files: Some(Files {
            source: Some(FileEntry {
                path: Some(source_path.to_string()),
                ..Default::default()
            }),
            ..Default::default()
        }),
        ..Default::default()
    }
}

fn make_unit_with_source_and_converted(
    id: &str,
    source_path: &str,
    converted_path: &str,
) -> CodeUnit {
    use crate::generated::types::{FileEntry, Files};
    CodeUnit {
        id: Some(id.to_string()),
        kind: Some(CodeUnitKind::DatabaseObject),
        source: Some(SourceMetadata {
            object_type: Some(CodeUnitObjectType::Table),
            ..Default::default()
        }),
        target: Some(TargetMetadata {
            object_type: Some(CodeUnitObjectType::Table),
            ..Default::default()
        }),
        files: Some(Files {
            source: Some(FileEntry {
                path: Some(source_path.to_string()),
                ..Default::default()
            }),
            converted: Some(FileEntry {
                path: Some(converted_path.to_string()),
                ..Default::default()
            }),
            ..Default::default()
        }),
        ..Default::default()
    }
}

#[test]
fn find_sql_file_changes_empty_registry() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();
    let result = registry
        .find_sql_file_changes(ChecksumMode::ALL, None)
        .unwrap();
    assert!(result.code_unit_changes.is_empty());
    assert!(result.untracked_files.is_empty());
    assert!(result.errors.is_empty());
}

#[test]
fn find_sql_file_changes_no_changes_when_files_match() {
    let dir = temp_dir();
    let root = dir.path();
    std::fs::write(root.join("src.sql"), b"SELECT 1").unwrap();
    std::fs::write(root.join("cvt.sql"), b"SELECT 1 AS col").unwrap();

    let registry = CodeUnitRegistry::init(root).unwrap();
    registry
        .create(
            &mut make_unit_with_source_and_converted("u1", "src.sql", "cvt.sql"),
            None,
        )
        .unwrap();
    registry.update_checksum("u1", ChecksumMode::ALL).unwrap();

    let result = registry
        .find_sql_file_changes(ChecksumMode::ALL, None)
        .unwrap();
    assert!(result.code_unit_changes.is_empty());
}

#[test]
fn find_sql_file_changes_detects_modified_source() {
    let dir = temp_dir();
    let root = dir.path();
    std::fs::write(root.join("src.sql"), b"SELECT 1").unwrap();

    let registry = CodeUnitRegistry::init(root).unwrap();
    registry
        .create(&mut make_unit_with_source_file("u1", "src.sql"), None)
        .unwrap();
    registry.update_checksum("u1", ChecksumMode::ALL).unwrap();

    std::fs::write(root.join("src.sql"), b"SELECT 2 -- modified").unwrap();

    let result = registry
        .find_sql_file_changes(ChecksumMode::SOURCE, None)
        .unwrap();
    assert!(result.code_unit_changes.contains_key("u1"));
    let changes = &result.code_unit_changes["u1"];
    assert_eq!(changes.len(), 1);
    assert_eq!(
        changes[0].change_type,
        crate::checksum::ChangeType::Modified
    );
}

#[test]
fn find_sql_file_changes_detects_removed_source() {
    let dir = temp_dir();
    let root = dir.path();
    std::fs::write(root.join("src.sql"), b"SELECT 1").unwrap();

    let registry = CodeUnitRegistry::init(root).unwrap();
    registry
        .create(&mut make_unit_with_source_file("u1", "src.sql"), None)
        .unwrap();
    registry.update_checksum("u1", ChecksumMode::ALL).unwrap();

    std::fs::remove_file(root.join("src.sql")).unwrap();

    let result = registry
        .find_sql_file_changes(ChecksumMode::SOURCE, None)
        .unwrap();
    assert!(result.code_unit_changes.contains_key("u1"));
    assert_eq!(
        result.code_unit_changes["u1"][0].change_type,
        crate::checksum::ChangeType::Removed
    );
}

#[test]
fn find_sql_file_changes_detects_untracked_source_files() {
    let dir = temp_dir();
    let root = dir.path();
    std::fs::write(root.join("tracked.sql"), b"ok").unwrap();

    let registry = CodeUnitRegistry::init(root).unwrap();
    registry
        .create(&mut make_unit_with_source_file("u1", "tracked.sql"), None)
        .unwrap();
    registry.update_checksum("u1", ChecksumMode::ALL).unwrap();

    let source_dir = root.join("source");
    std::fs::create_dir_all(&source_dir).unwrap();
    std::fs::write(source_dir.join("orphan.sql"), b"surprise").unwrap();

    let result = registry
        .find_sql_file_changes(ChecksumMode::SOURCE, None)
        .unwrap();
    assert!(result.code_unit_changes.is_empty());
    assert!(!result.untracked_files.is_empty());
    assert!(result
        .untracked_files
        .iter()
        .any(|f| f.path.contains("orphan.sql")));
}

#[test]
fn find_sql_file_changes_mode_source_ignores_converted() {
    let dir = temp_dir();
    let root = dir.path();
    std::fs::write(root.join("src.sql"), b"SELECT 1").unwrap();
    std::fs::write(root.join("cvt.sql"), b"SELECT 1 AS col").unwrap();

    let registry = CodeUnitRegistry::init(root).unwrap();
    registry
        .create(
            &mut make_unit_with_source_and_converted("u1", "src.sql", "cvt.sql"),
            None,
        )
        .unwrap();
    registry.update_checksum("u1", ChecksumMode::ALL).unwrap();

    std::fs::write(root.join("cvt.sql"), b"modified converted!").unwrap();

    let result = registry
        .find_sql_file_changes(ChecksumMode::SOURCE, None)
        .unwrap();
    assert!(result.code_unit_changes.is_empty());
}

#[test]
fn find_sql_file_changes_with_filter() {
    let dir = temp_dir();
    let root = dir.path();
    std::fs::write(root.join("a.sql"), b"SELECT 1").unwrap();
    std::fs::write(root.join("b.sql"), b"SELECT 2").unwrap();

    let registry = CodeUnitRegistry::init(root).unwrap();
    let mut u1 = make_unit_with_source_file("u1", "a.sql");
    u1.source.as_mut().unwrap().name = Some("Alpha".to_string());
    registry.create(&mut u1, None).unwrap();
    registry.update_checksum("u1", ChecksumMode::ALL).unwrap();

    let mut u2 = make_unit_with_source_file("u2", "b.sql");
    u2.source.as_mut().unwrap().name = Some("Beta".to_string());
    registry.create(&mut u2, None).unwrap();
    registry.update_checksum("u2", ChecksumMode::ALL).unwrap();

    std::fs::write(root.join("a.sql"), b"modified a").unwrap();
    std::fs::write(root.join("b.sql"), b"modified b").unwrap();

    let result = registry
        .find_sql_file_changes(ChecksumMode::SOURCE, Some("source.name = 'Alpha'"))
        .unwrap();
    assert_eq!(result.code_unit_changes.len(), 1);
    assert!(result.code_unit_changes.contains_key("u1"));
    assert!(!result.code_unit_changes.contains_key("u2"));
}

#[test]
fn find_sql_file_changes_multiple_units_mixed() {
    let dir = temp_dir();
    let root = dir.path();
    std::fs::write(root.join("a.sql"), b"file a").unwrap();
    std::fs::write(root.join("b.sql"), b"file b").unwrap();
    std::fs::write(root.join("c.sql"), b"file c").unwrap();

    let registry = CodeUnitRegistry::init(root).unwrap();
    registry
        .create(&mut make_unit_with_source_file("u1", "a.sql"), None)
        .unwrap();
    registry.update_checksum("u1", ChecksumMode::ALL).unwrap();
    registry
        .create(&mut make_unit_with_source_file("u2", "b.sql"), None)
        .unwrap();
    registry.update_checksum("u2", ChecksumMode::ALL).unwrap();
    registry
        .create(&mut make_unit_with_source_file("u3", "c.sql"), None)
        .unwrap();
    registry.update_checksum("u3", ChecksumMode::ALL).unwrap();

    std::fs::write(root.join("a.sql"), b"modified a").unwrap();
    std::fs::remove_file(root.join("b.sql")).unwrap();
    // c.sql unchanged

    let result = registry
        .find_sql_file_changes(ChecksumMode::SOURCE, None)
        .unwrap();
    assert_eq!(result.code_unit_changes.len(), 2);
    assert_eq!(
        result.code_unit_changes["u1"][0].change_type,
        crate::checksum::ChangeType::Modified
    );
    assert_eq!(
        result.code_unit_changes["u2"][0].change_type,
        crate::checksum::ChangeType::Removed
    );
    assert!(!result.code_unit_changes.contains_key("u3"));
}

#[test]
fn find_sql_file_changes_errors_field_is_empty_on_success() {
    let dir = temp_dir();
    let root = dir.path();
    std::fs::write(root.join("src.sql"), b"content").unwrap();

    let registry = CodeUnitRegistry::init(root).unwrap();
    registry
        .create(&mut make_unit_with_source_file("u1", "src.sql"), None)
        .unwrap();
    registry.update_checksum("u1", ChecksumMode::ALL).unwrap();

    let result = registry
        .find_sql_file_changes(ChecksumMode::ALL, None)
        .unwrap();
    assert!(result.errors.is_empty());
}

// ── Before-write hook tests ─────────────────────────────────────────

use std::sync::{Arc, Mutex};

type HookCallLog = Arc<Mutex<Vec<(ChangeType, Vec<String>)>>>;

#[derive(Clone, Default)]
struct TrackingHook {
    calls: HookCallLog,
}

impl RegistryHook for TrackingHook {
    fn before_persist(
        &self,
        kind: ChangeType,
        changes: Vec<CodeUnitChange>,
        _registry: &CodeUnitRegistry,
        _options: &WriteOptions,
    ) -> Result<Vec<CodeUnitChange>> {
        let ids: Vec<String> = changes.iter().map(|c| c.id.clone()).collect();
        self.calls.lock().unwrap().push((kind, ids));
        Ok(changes)
    }
}

struct FailingHook;

impl RegistryHook for FailingHook {
    fn before_persist(
        &self,
        _kind: ChangeType,
        _changes: Vec<CodeUnitChange>,
        _registry: &CodeUnitRegistry,
        _options: &WriteOptions,
    ) -> Result<Vec<CodeUnitChange>> {
        Err(ValidationSnafu {
            message: "hook rejected",
        }
        .build())
    }
}

#[test]
fn hook_fires_on_create() {
    let dir = temp_dir();
    let hook = TrackingHook::default();
    let calls = hook.calls.clone();
    let mut registry = CodeUnitRegistry::init(dir.path()).unwrap();
    registry.add_hook(hook);

    let mut cu = make_code_unit("h1", "T1", CodeUnitObjectType::Table);
    registry.create(&mut cu, None).unwrap();

    let log = calls.lock().unwrap();
    assert_eq!(log.len(), 1);
    assert_eq!(log[0].0, ChangeType::Create);
    assert_eq!(log[0].1, vec!["h1"]);
}

#[test]
fn hook_fires_on_update() {
    let dir = temp_dir();
    let hook = TrackingHook::default();
    let calls = hook.calls.clone();
    let mut registry = CodeUnitRegistry::init(dir.path()).unwrap();
    registry.add_hook(hook);

    let mut cu = make_code_unit("h2", "T2", CodeUnitObjectType::Table);
    registry.create(&mut cu, None).unwrap();
    registry
        .update(
            "h2",
            &[("source.name", Value::String("Updated".into()))],
            None,
        )
        .unwrap();

    let log = calls.lock().unwrap();
    assert_eq!(log.len(), 2);
    assert_eq!(log[0].0, ChangeType::Create);
    assert_eq!(log[1].0, ChangeType::Update);
    assert_eq!(log[1].1, vec!["h2"]);
}

#[test]
fn hook_fires_on_upsert() {
    let dir = temp_dir();
    let hook = TrackingHook::default();
    let calls = hook.calls.clone();
    let mut registry = CodeUnitRegistry::init(dir.path()).unwrap();
    registry.add_hook(hook);

    let mut cu = make_code_unit("h3", "T3", CodeUnitObjectType::Table);
    registry.upsert(&mut cu, None).unwrap();

    let log = calls.lock().unwrap();
    assert_eq!(log.len(), 1);
    assert_eq!(log[0].0, ChangeType::Upsert);
    assert_eq!(log[0].1, vec!["h3"]);
}

#[test]
fn hook_fires_on_delete() {
    let dir = temp_dir();
    let hook = TrackingHook::default();
    let calls = hook.calls.clone();
    let mut registry = CodeUnitRegistry::init(dir.path()).unwrap();
    registry.add_hook(hook);

    let mut cu = make_code_unit("h4", "T4", CodeUnitObjectType::Table);
    registry.create(&mut cu, None).unwrap();
    registry.delete("h4").unwrap();

    let log = calls.lock().unwrap();
    assert_eq!(log.len(), 2);
    assert_eq!(log[1].0, ChangeType::Delete);
    assert_eq!(log[1].1, vec!["h4"]);
}

#[test]
fn hook_can_transform_unit() {
    let dir = temp_dir();

    struct TransformHook;
    impl RegistryHook for TransformHook {
        fn before_persist(
            &self,
            _kind: ChangeType,
            changes: Vec<CodeUnitChange>,
            _registry: &CodeUnitRegistry,
            _options: &WriteOptions,
        ) -> Result<Vec<CodeUnitChange>> {
            Ok(changes
                .into_iter()
                .map(|mut change| {
                    if let Some(ref mut unit) = change.after {
                        if let Some(ref mut source) = unit.source {
                            source.name = Some("TransformedByHook".to_string());
                        }
                    }
                    change
                })
                .collect())
        }
    }

    let mut registry = CodeUnitRegistry::init(dir.path()).unwrap();
    registry.add_hook(TransformHook);

    let mut cu = make_code_unit("ht1", "Original", CodeUnitObjectType::Table);
    registry.create(&mut cu, None).unwrap();

    let unit = registry.get_by_id("ht1", None).unwrap();
    assert_eq!(
        unit.source.as_ref().unwrap().name.as_deref(),
        Some("TransformedByHook"),
        "hook should have transformed the unit before it was written"
    );
}

#[test]
fn hook_receives_before_and_after() {
    let dir = temp_dir();
    let captured_before = Arc::new(Mutex::new(None::<Option<CodeUnit>>));
    let captured_after = Arc::new(Mutex::new(None::<Option<CodeUnit>>));
    let cb = captured_before.clone();
    let ca = captured_after.clone();

    struct CaptureHook {
        before: Arc<Mutex<Option<Option<CodeUnit>>>>,
        after: Arc<Mutex<Option<Option<CodeUnit>>>>,
    }
    impl RegistryHook for CaptureHook {
        fn before_persist(
            &self,
            _kind: ChangeType,
            changes: Vec<CodeUnitChange>,
            _registry: &CodeUnitRegistry,
            _options: &WriteOptions,
        ) -> Result<Vec<CodeUnitChange>> {
            if let Some(change) = changes.first() {
                *self.before.lock().unwrap() = Some(change.before.clone());
                *self.after.lock().unwrap() = Some(change.after.clone());
            }
            Ok(changes)
        }
    }

    let mut registry = CodeUnitRegistry::init(dir.path()).unwrap();
    registry.add_hook(CaptureHook {
        before: cb,
        after: ca,
    });

    let mut cu = make_code_unit("hba1", "T1", CodeUnitObjectType::Table);
    registry.create(&mut cu, None).unwrap();

    let before = captured_before.lock().unwrap().take().unwrap();
    assert!(before.is_none(), "before should be None for creates");
    let after = captured_after.lock().unwrap().take().unwrap();
    assert!(after.is_some(), "after should be Some for creates");
}

#[test]
fn hook_fires_on_create_batch() {
    let dir = temp_dir();
    let hook = TrackingHook::default();
    let calls = hook.calls.clone();
    let mut registry = CodeUnitRegistry::init(dir.path()).unwrap();
    registry.add_hook(hook);

    let mut batch = vec![
        make_code_unit("hb1", "T1", CodeUnitObjectType::Table),
        make_code_unit("hb2", "T2", CodeUnitObjectType::Table),
    ];
    let result = registry.create_batch(&mut batch, None).unwrap();
    assert_eq!(result.succeeded.len(), 2);

    let log = calls.lock().unwrap();
    assert_eq!(log.len(), 1);
    assert_eq!(log[0].0, ChangeType::Create);
    assert_eq!(log[0].1.len(), 2);
}

#[test]
fn hook_fires_on_update_batch() {
    let dir = temp_dir();
    let hook = TrackingHook::default();
    let calls = hook.calls.clone();
    let mut registry = CodeUnitRegistry::init(dir.path()).unwrap();
    registry.add_hook(hook);

    let mut cu1 = make_code_unit("hub1", "T1", CodeUnitObjectType::Table);
    let mut cu2 = make_code_unit("hub2", "T2", CodeUnitObjectType::Table);
    registry.create(&mut cu1, None).unwrap();
    registry.create(&mut cu2, None).unwrap();

    let batch: Vec<(&str, Vec<(&str, Value)>)> = vec![
        ("hub1", vec![("source.name", Value::String("U1".into()))]),
        ("hub2", vec![("source.name", Value::String("U2".into()))]),
    ];
    registry.update_batch(&batch, None).unwrap();

    let log = calls.lock().unwrap();
    assert!(log
        .iter()
        .any(|(k, ids)| *k == ChangeType::Update && ids.len() == 2));
}

#[test]
fn hook_fires_on_update_where() {
    let dir = temp_dir();
    let hook = TrackingHook::default();
    let calls = hook.calls.clone();
    let mut registry = CodeUnitRegistry::init(dir.path()).unwrap();
    registry.add_hook(hook);

    let mut cu1 = make_code_unit("huw1", "T1", CodeUnitObjectType::Table);
    let mut cu2 = make_code_unit("huw2", "T2", CodeUnitObjectType::Procedure);
    registry.create(&mut cu1, None).unwrap();
    registry.create(&mut cu2, None).unwrap();

    let updates: Vec<(&str, Value)> = vec![("source.database", Value::String("NEWDB".into()))];
    registry
        .update_where("source.objectType = 'table'", &updates, None)
        .unwrap();

    let log = calls.lock().unwrap();
    let update_entry = log.iter().find(|(k, _)| *k == ChangeType::Update).unwrap();
    assert_eq!(update_entry.1, vec!["huw1".to_string()]);
}

#[test]
fn hook_fires_on_upsert_batch() {
    let dir = temp_dir();
    let hook = TrackingHook::default();
    let calls = hook.calls.clone();
    let mut registry = CodeUnitRegistry::init(dir.path()).unwrap();
    registry.add_hook(hook);

    let mut batch = vec![
        make_code_unit("husb1", "T1", CodeUnitObjectType::Table),
        make_code_unit("husb2", "T2", CodeUnitObjectType::Table),
    ];
    registry.upsert_batch(&mut batch, None).unwrap();

    let log = calls.lock().unwrap();
    assert!(log
        .iter()
        .any(|(k, ids)| *k == ChangeType::Upsert && ids.len() == 2));
}

#[test]
fn hook_error_aborts_create() {
    let dir = temp_dir();
    let mut registry = CodeUnitRegistry::init(dir.path()).unwrap();
    registry.add_hook(FailingHook);

    let mut cu = make_code_unit("hf1", "T1", CodeUnitObjectType::Table);
    let err = registry.create(&mut cu, None).unwrap_err();
    assert_eq!(err.error_code_i32(), 1007);

    assert!(
        !registry.id_to_path("hf1").exists(),
        "unit should NOT be written when hook aborts"
    );
}

#[test]
fn multiple_hooks_fire_in_order() {
    let dir = temp_dir();
    let log = Arc::new(Mutex::new(Vec::<String>::new()));

    struct OrderedHook(String, Arc<Mutex<Vec<String>>>);
    impl RegistryHook for OrderedHook {
        fn before_persist(
            &self,
            _kind: ChangeType,
            changes: Vec<CodeUnitChange>,
            _registry: &CodeUnitRegistry,
            _options: &WriteOptions,
        ) -> Result<Vec<CodeUnitChange>> {
            self.1.lock().unwrap().push(self.0.clone());
            Ok(changes)
        }
    }

    let mut registry = CodeUnitRegistry::init(dir.path()).unwrap();
    registry.add_hook(OrderedHook("first".into(), log.clone()));
    registry.add_hook(OrderedHook("second".into(), log.clone()));

    let mut cu = make_code_unit("ord1", "T1", CodeUnitObjectType::Table);
    registry.create(&mut cu, None).unwrap();

    let entries = log.lock().unwrap();
    assert_eq!(*entries, vec!["first", "second"]);
}

#[test]
fn no_hooks_operations_work() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let mut cu = make_code_unit("nh1", "T1", CodeUnitObjectType::Table);
    registry.create(&mut cu, None).unwrap();
    registry
        .update("nh1", &[("source.name", Value::String("U".into()))], None)
        .unwrap();
    registry.delete("nh1").unwrap();
}

#[test]
fn add_hook_after_construction() {
    let dir = temp_dir();
    let hook = TrackingHook::default();
    let calls = hook.calls.clone();
    let mut registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let mut cu = make_code_unit("ah1", "T1", CodeUnitObjectType::Table);
    registry.create(&mut cu, None).unwrap();
    assert!(calls.lock().unwrap().is_empty(), "no hook yet");

    registry.add_hook(hook);

    registry
        .update(
            "ah1",
            &[("source.name", Value::String("After".into()))],
            None,
        )
        .unwrap();

    let log = calls.lock().unwrap();
    assert_eq!(log.len(), 1);
    assert_eq!(log[0].0, ChangeType::Update);
}

#[test]
fn delete_hook_can_cancel_delete() {
    let dir = temp_dir();

    struct CancelDeleteHook;
    impl RegistryHook for CancelDeleteHook {
        fn before_persist(
            &self,
            kind: ChangeType,
            changes: Vec<CodeUnitChange>,
            _registry: &CodeUnitRegistry,
            _options: &WriteOptions,
        ) -> Result<Vec<CodeUnitChange>> {
            if kind == ChangeType::Delete {
                Ok(changes
                    .into_iter()
                    .map(|mut change| {
                        if let Some(ref before) = change.before {
                            change.after = Some(before.clone());
                        }
                        change
                    })
                    .collect())
            } else {
                Ok(changes)
            }
        }
    }

    let mut registry = CodeUnitRegistry::init(dir.path()).unwrap();
    registry.add_hook(CancelDeleteHook);

    let mut cu = make_code_unit("cd1", "T1", CodeUnitObjectType::Table);
    registry.create(&mut cu, None).unwrap();
    registry.delete("cd1").unwrap();

    assert!(
        registry.id_to_path("cd1").exists(),
        "unit should still exist after hook cancelled delete"
    );
}

// ── UpdatedAtHook tests ──────────────────────────────────────────────────

#[test]
fn test_create_with_testing_status_populates_updated_at() {
    use crate::generated::types::{CloudStatus, OperationStatus, TestingStatus};

    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let mut cu = make_code_unit("ua1", "T1", CodeUnitObjectType::Table);
    cu.cloud_status = Some(CloudStatus {
        testing: Some(TestingStatus {
            status: Some(OperationStatus::Pending),
            ..Default::default()
        }),
        ..Default::default()
    });

    registry.create(&mut cu, None).unwrap();

    let stored = registry.get_by_id("ua1", None).unwrap();
    let testing = stored
        .cloud_status
        .as_ref()
        .and_then(|cs| cs.testing.as_ref())
        .expect("testing should exist");
    assert!(
        testing.updated_at.is_some(),
        "updatedAt should be set after create with testing status"
    );
}

#[test]
fn test_update_sibling_triggers_updated_at() {
    use crate::generated::types::{CloudStatus, OperationStatus, TestingStatus};

    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let mut cu = make_code_unit("ua2", "T2", CodeUnitObjectType::Table);
    cu.cloud_status = Some(CloudStatus {
        testing: Some(TestingStatus {
            status: Some(OperationStatus::Pending),
            ..Default::default()
        }),
        ..Default::default()
    });
    registry.create(&mut cu, None).unwrap();

    let stored_before = registry.get_by_id("ua2", None).unwrap();
    let ts_before = stored_before
        .cloud_status
        .as_ref()
        .unwrap()
        .testing
        .as_ref()
        .unwrap()
        .updated_at
        .unwrap();

    std::thread::sleep(std::time::Duration::from_secs(1));

    registry
        .update(
            "ua2",
            &[("cloudStatus.testing.status", serde_json::json!("completed"))],
            None,
        )
        .unwrap();

    let stored_after = registry.get_by_id("ua2", None).unwrap();
    let ts_after = stored_after
        .cloud_status
        .as_ref()
        .unwrap()
        .testing
        .as_ref()
        .unwrap()
        .updated_at
        .unwrap();

    assert!(
        ts_after > ts_before,
        "updatedAt should advance when a sibling changes"
    );
}

#[test]
fn test_update_unrelated_field_preserves_updated_at() {
    use crate::generated::types::{CloudStatus, OperationStatus, TestingStatus};

    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let mut cu = make_code_unit("ua3", "T3", CodeUnitObjectType::Table);
    cu.cloud_status = Some(CloudStatus {
        testing: Some(TestingStatus {
            status: Some(OperationStatus::Pending),
            ..Default::default()
        }),
        ..Default::default()
    });
    registry.create(&mut cu, None).unwrap();

    let stored_before = registry.get_by_id("ua3", None).unwrap();
    let ts_before = stored_before
        .cloud_status
        .as_ref()
        .unwrap()
        .testing
        .as_ref()
        .unwrap()
        .updated_at
        .unwrap();

    std::thread::sleep(std::time::Duration::from_secs(1));

    registry
        .update(
            "ua3",
            &[("source.name", serde_json::json!("Renamed"))],
            None,
        )
        .unwrap();

    let stored_after = registry.get_by_id("ua3", None).unwrap();
    let ts_after = stored_after
        .cloud_status
        .as_ref()
        .unwrap()
        .testing
        .as_ref()
        .unwrap()
        .updated_at
        .unwrap();

    assert_eq!(
        ts_before, ts_after,
        "updatedAt should NOT change when only unrelated fields are modified"
    );
}

#[test]
fn test_upsert_creates_updated_at_when_testing_added() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let mut cu = make_code_unit("ua4", "T4", CodeUnitObjectType::Table);
    registry.create(&mut cu, None).unwrap();

    let stored = registry.get_by_id("ua4", None).unwrap();
    assert!(stored.code_status.is_none(), "no codeStatus initially");

    let mut patch = CodeUnit {
        id: Some("ua4".to_string()),
        cloud_status: Some(crate::generated::types::CloudStatus {
            testing: Some(crate::generated::types::TestingStatus {
                status: Some(crate::generated::types::OperationStatus::Pending),
                details: {
                    let mut m = serde_json::Map::new();
                    m.insert("note".to_string(), serde_json::json!("first run"));
                    m
                },
                ..Default::default()
            }),
            ..Default::default()
        }),
        ..Default::default()
    };
    registry.upsert(&mut patch, None).unwrap();

    let stored = registry.get_by_id("ua4", None).unwrap();
    let testing = stored
        .cloud_status
        .as_ref()
        .and_then(|cs| cs.testing.as_ref())
        .expect("testing should exist after upsert");
    assert!(
        testing.updated_at.is_some(),
        "updatedAt should be created when testing is added via upsert"
    );
}

// ── Root-level updatedAt tests ───────────────────────────────────────────

#[test]
fn test_create_sets_root_updated_at() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let mut cu = make_code_unit("root-ua1", "T1", CodeUnitObjectType::Table);
    registry.create(&mut cu, None).unwrap();

    let stored = registry.get_by_id("root-ua1", None).unwrap();
    assert!(
        stored.updated_at.is_some(),
        "root updatedAt should be set on create"
    );
}

#[test]
fn test_update_advances_root_updated_at() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let mut cu = make_code_unit("root-ua2", "T2", CodeUnitObjectType::Table);
    registry.create(&mut cu, None).unwrap();

    let before = registry.get_by_id("root-ua2", None).unwrap();
    let ts_before = before.updated_at.unwrap();

    std::thread::sleep(std::time::Duration::from_secs(1));

    registry
        .update(
            "root-ua2",
            &[("source.name", serde_json::json!("Renamed"))],
            None,
        )
        .unwrap();

    let after = registry.get_by_id("root-ua2", None).unwrap();
    let ts_after = after.updated_at.unwrap();

    assert!(
        ts_after > ts_before,
        "root updatedAt should advance on any update"
    );
}

#[test]
fn test_upsert_advances_root_updated_at() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let mut cu = make_code_unit("root-ua3", "T3", CodeUnitObjectType::Table);
    registry.create(&mut cu, None).unwrap();

    let before = registry.get_by_id("root-ua3", None).unwrap();
    let ts_before = before.updated_at.unwrap();

    std::thread::sleep(std::time::Duration::from_secs(1));

    let mut patch = CodeUnit {
        id: Some("root-ua3".to_string()),
        source: Some(SourceMetadata {
            name: Some("Updated".to_string()),
            ..Default::default()
        }),
        ..Default::default()
    };
    registry.upsert(&mut patch, None).unwrap();

    let after = registry.get_by_id("root-ua3", None).unwrap();
    let ts_after = after.updated_at.unwrap();

    assert!(
        ts_after > ts_before,
        "root updatedAt should advance on upsert"
    );
}

// ── WriteOptions / ChecksumHook tests ──────────────────────────────────

#[test]
fn create_with_checksum_source_populates_source_checksum() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();
    write_temp_source(dir.path(), "hw.sql", b"SELECT 1");

    let mut cu = make_code_unit_with_files("woc1", Some("hw.sql".into()), None, None);
    let opts = WriteOptions {
        checksum_mode: ChecksumMode::SOURCE,
    };
    registry.create(&mut cu, Some(&opts)).unwrap();

    let stored = registry.get_by_id("woc1", None).unwrap();
    let checksum = stored.files.unwrap().source.unwrap().checksum;
    assert!(checksum.is_some(), "source checksum should be populated");
    assert!(!checksum.unwrap().is_empty());
}

#[test]
fn upsert_with_checksum_all_populates_all_checksums() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();
    write_temp_source(dir.path(), "s.sql", b"SELECT 1");
    write_temp_source(dir.path(), "c.sql", b"SELECT 2");
    write_temp_source(dir.path(), "snap.sql", b"SELECT 3");

    let mut cu = make_code_unit_with_files(
        "woc2",
        Some("s.sql".into()),
        Some("c.sql".into()),
        Some("snap.sql".into()),
    );
    let opts = WriteOptions {
        checksum_mode: ChecksumMode::ALL,
    };
    registry.upsert(&mut cu, Some(&opts)).unwrap();

    let stored = registry.get_by_id("woc2", None).unwrap();
    let files = stored.files.unwrap();
    assert!(
        files.source.as_ref().unwrap().checksum.is_some(),
        "source checksum should be populated"
    );
    assert!(
        files.converted.as_ref().unwrap().checksum.is_some(),
        "converted checksum should be populated"
    );
    assert!(
        files.snapshot.as_ref().unwrap().checksum.is_some(),
        "snapshot checksum should be populated"
    );
}

#[test]
fn create_with_none_options_leaves_checksum_empty() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();
    write_temp_source(dir.path(), "noop.sql", b"SELECT 1");

    let mut cu = make_code_unit_with_files("woc3", Some("noop.sql".into()), None, None);
    registry.create(&mut cu, None).unwrap();

    let stored = registry.get_by_id("woc3", None).unwrap();
    let checksum = stored.files.unwrap().source.unwrap().checksum;
    assert!(
        checksum.is_none(),
        "checksum should remain empty when options is None"
    );
}

#[test]
fn update_with_checksum_source_refreshes_checksum() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();
    write_temp_source(dir.path(), "upd.sql", b"v1");

    let mut cu = make_code_unit_with_files("woc4", Some("upd.sql".into()), None, None);
    let opts_src = WriteOptions {
        checksum_mode: ChecksumMode::SOURCE,
    };
    registry.create(&mut cu, Some(&opts_src)).unwrap();

    let before = registry
        .get_by_id("woc4", None)
        .unwrap()
        .files
        .unwrap()
        .source
        .unwrap()
        .checksum
        .unwrap();

    fs::write(dir.path().join("upd.sql"), b"v2").unwrap();
    registry
        .update(
            "woc4",
            &[("source.name", serde_json::json!("Renamed"))],
            Some(&opts_src),
        )
        .unwrap();

    let after = registry
        .get_by_id("woc4", None)
        .unwrap()
        .files
        .unwrap()
        .source
        .unwrap()
        .checksum
        .unwrap();

    assert_ne!(
        before, after,
        "checksum should change after file modification"
    );
}

// ── Validation ───────────────────────────────────────────────────────────

use crate::checksum::ChecksumMode;
use crate::validation::ValidationIssueKind;

#[test]
fn validate_empty_registry() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();
    let report = registry.validate(ChecksumMode::NONE).unwrap();
    assert!(report.is_valid);
    assert_eq!(report.files_checked, 0);
    assert!(report.issues.is_empty());
}

#[test]
fn validate_valid_registry() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();
    let mut unit = make_code_unit("v1", "my_table", CodeUnitObjectType::Table);
    registry.create(&mut unit, None).unwrap();
    let report = registry.validate(ChecksumMode::NONE).unwrap();
    assert!(report.is_valid);
    assert_eq!(report.files_checked, 1);
}

#[test]
fn validate_detects_invalid_json() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();
    fs::write(dir.path().join("registry/bad.json"), "not json{{{").unwrap();
    let report = registry.validate(ChecksumMode::NONE).unwrap();
    assert!(!report.is_valid);
    assert_eq!(report.files_checked, 1);
    assert_eq!(report.issues.len(), 1);
    assert_eq!(report.issues[0].kind, ValidationIssueKind::InvalidJson);
    assert_eq!(report.issues[0].file, "bad.json");
}

// ── migrate_schema_all / migrate_schema_file ─────────────────────────────

#[test]
fn migrate_schema_all_empty_registry() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();
    let result = registry.migrate_schema_all().unwrap();
    assert!(result.succeeded.is_empty());
    assert!(result.failed.is_empty());
}

#[test]
fn migrate_schema_all_current_version_is_noop() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let cu = make_code_unit("msa-1", "tbl1", CodeUnitObjectType::Table);
    registry.create(&mut cu.clone(), None).unwrap();

    let result = registry.migrate_schema_all().unwrap();
    assert!(
        result.succeeded.is_empty(),
        "current-version files should be skipped"
    );
    assert!(result.failed.is_empty());
}

#[test]
fn migrate_schema_all_future_version_reports_failure() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let doc = serde_json::json!({(SCHEMA_VERSION_FIELD): 999, "id": "future"});
    fs::write(
        dir.path().join("registry/future.json"),
        serde_json::to_string_pretty(&doc).unwrap(),
    )
    .unwrap();

    let result = registry.migrate_schema_all().unwrap();
    assert!(result.succeeded.is_empty());
    assert_eq!(result.failed.len(), 1);
    assert_eq!(result.failed[0].id, "future");
    assert_eq!(result.failed[0].error.code, 1020);
}

#[test]
fn migrate_schema_all_malformed_version_reports_failure() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let doc = serde_json::json!({(SCHEMA_VERSION_FIELD): "bad", "id": "broken"});
    fs::write(
        dir.path().join("registry/broken.json"),
        serde_json::to_string_pretty(&doc).unwrap(),
    )
    .unwrap();

    let result = registry.migrate_schema_all().unwrap();
    assert!(result.succeeded.is_empty());
    assert_eq!(result.failed.len(), 1);
    assert_eq!(result.failed[0].id, "broken");
    assert_eq!(result.failed[0].error.code, 1021);
}

#[test]
fn migrate_schema_all_invalid_json_reports_failure() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    fs::write(dir.path().join("registry/garbage.json"), "not json{{{").unwrap();

    let result = registry.migrate_schema_all().unwrap();
    assert!(result.succeeded.is_empty());
    assert_eq!(result.failed.len(), 1);
    assert_eq!(result.failed[0].id, "garbage");
    assert_eq!(result.failed[0].error.code, 1009);
}

#[test]
fn migrate_schema_all_partial_failure_isolates_errors() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let mut good = make_code_unit("good-1", "tbl1", CodeUnitObjectType::Table);
    registry.create(&mut good, None).unwrap();

    let bad_doc = serde_json::json!({(SCHEMA_VERSION_FIELD): 999, "id": "bad-1"});
    fs::write(
        dir.path().join("registry/bad-1.json"),
        serde_json::to_string_pretty(&bad_doc).unwrap(),
    )
    .unwrap();

    let result = registry.migrate_schema_all().unwrap();
    assert_eq!(result.failed.len(), 1);
    assert_eq!(result.failed[0].id, "bad-1");
    assert_eq!(result.failed[0].error.code, 1020);
    assert!(
        !result.failed.iter().any(|f| f.id == "good-1"),
        "valid file should not appear in failures"
    );
}

#[test]
fn validate_rejects_future_schema_version() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let doc = serde_json::json!({ (SCHEMA_VERSION_FIELD): 9999 });
    fs::write(
        dir.path().join("registry/future.json"),
        serde_json::to_string_pretty(&doc).unwrap(),
    )
    .unwrap();

    let report = registry.validate(ChecksumMode::NONE).unwrap();
    assert!(!report.is_valid);
    assert_eq!(report.issues.len(), 1);
    assert_eq!(
        report.issues[0].kind,
        ValidationIssueKind::SchemaMigrationError
    );
    assert_eq!(report.issues[0].error_code, Some(1020));
}

#[test]
fn validate_rejects_malformed_schema_version() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let doc = serde_json::json!({ (SCHEMA_VERSION_FIELD): "bad" });
    fs::write(
        dir.path().join("registry/bad-version.json"),
        serde_json::to_string_pretty(&doc).unwrap(),
    )
    .unwrap();

    let report = registry.validate(ChecksumMode::NONE).unwrap();
    assert!(!report.is_valid);
    assert_eq!(report.issues.len(), 1);
    assert_eq!(
        report.issues[0].kind,
        ValidationIssueKind::SchemaMigrationError
    );
    assert_eq!(report.issues[0].error_code, Some(1021));
}

#[test]
fn validate_detects_schema_violation() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();

    let doc = serde_json::json!({ (SCHEMA_VERSION_FIELD): 1, "isMissing": "not-a-bool" });
    fs::write(
        dir.path().join("registry/bad-type.json"),
        serde_json::to_string_pretty(&doc).unwrap(),
    )
    .unwrap();

    let report = registry.validate(ChecksumMode::NONE).unwrap();
    assert!(!report.is_valid);
    assert!(
        report
            .issues
            .iter()
            .any(|i| i.kind == ValidationIssueKind::SchemaViolation),
        "expected a schema violation, got: {:?}",
        report.issues
    );
}

#[test]
fn validate_detects_id_filename_mismatch() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();
    let unit = serde_json::json!({ "id": "wrong-id" });
    fs::write(
        dir.path().join("registry/correct-name.json"),
        serde_json::to_string_pretty(&unit).unwrap(),
    )
    .unwrap();
    let report = registry.validate(ChecksumMode::NONE).unwrap();
    assert!(!report.is_valid);
    assert!(report
        .issues
        .iter()
        .any(|i| i.kind == ValidationIssueKind::IdFilenameMismatch));
}

#[test]
fn validate_detects_duplicate_ids() {
    let dir = temp_dir();
    let registry = init_bare(dir.path());
    let unit_a = serde_json::json!({ "id": "dup" });
    let unit_b = serde_json::json!({ "id": "dup" });
    fs::write(
        dir.path().join("registry/dup.json"),
        serde_json::to_string_pretty(&unit_a).unwrap(),
    )
    .unwrap();
    fs::write(
        dir.path().join("registry/dup2.json"),
        serde_json::to_string_pretty(&unit_b).unwrap(),
    )
    .unwrap();
    let report = registry.validate(ChecksumMode::NONE).unwrap();
    assert!(!report.is_valid);
    let dup_issues: Vec<_> = report
        .issues
        .iter()
        .filter(|i| i.kind == ValidationIssueKind::DuplicateId)
        .collect();
    assert!(
        !dup_issues.is_empty(),
        "expected duplicate ID issues, got: {:?}",
        report.issues
    );
}

#[test]
fn validate_detects_unresolved_dependency() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();
    let mut unit = make_code_unit("dep-src", "t1", CodeUnitObjectType::Table);
    set_dependency_ids(&mut unit, &["nonexistent-id"]);
    registry.create(&mut unit, None).unwrap();
    let report = registry.validate(ChecksumMode::NONE).unwrap();
    assert!(!report.is_valid);
    assert!(report
        .issues
        .iter()
        .any(|i| i.kind == ValidationIssueKind::UnresolvedDependency));
}

#[test]
fn validate_unit_single_valid_file() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();
    let mut unit = make_code_unit("vu1", "my_proc", CodeUnitObjectType::Procedure);
    registry.create(&mut unit, None).unwrap();
    let report = registry.validate_unit("vu1", ChecksumMode::NONE).unwrap();
    assert!(report.is_valid);
    assert_eq!(report.files_checked, 1);
}

#[test]
fn validate_unit_not_found() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();
    let err = registry
        .validate_unit("nonexistent", ChecksumMode::NONE)
        .unwrap_err();
    assert_eq!(err.error_code_i32(), 1003);
}

#[test]
fn validate_collects_multiple_issues() {
    let dir = temp_dir();
    let registry = init_bare(dir.path());
    fs::write(dir.path().join("registry/bad1.json"), "not-json").unwrap();
    fs::write(dir.path().join("registry/bad2.json"), "also-bad").unwrap();
    let report = registry.validate(ChecksumMode::NONE).unwrap();
    assert!(!report.is_valid);
    assert_eq!(report.files_checked, 2);
    let json_issues: Vec<_> = report
        .issues
        .iter()
        .filter(|i| i.kind == ValidationIssueKind::InvalidJson)
        .collect();
    assert_eq!(json_issues.len(), 2);
}

#[test]
fn validate_detects_missing_id() {
    let dir = temp_dir();
    let registry = init_bare(dir.path());
    let unit_without_id = serde_json::json!({
        "kind": "databaseObject",
        "source": { "objectType": "table", "database": "DB", "schema": "dbo", "name": "T" },
        "target": { "objectType": "table", "database": "DB", "schema": "DBO", "name": "T" }
    });
    fs::write(
        dir.path().join("registry/no-id-unit.json"),
        serde_json::to_string_pretty(&unit_without_id).unwrap(),
    )
    .unwrap();
    let report = registry.validate(ChecksumMode::NONE).unwrap();
    assert!(!report.is_valid);
    assert!(
        report
            .issues
            .iter()
            .any(|i| i.kind == ValidationIssueKind::MissingId),
        "expected a MissingId issue, got: {:?}",
        report.issues
    );
}

#[test]
fn validate_checksum_detects_missing_file() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();
    let path = write_temp_source(dir.path(), "gone.sql", b"content");
    let mut cu = make_code_unit_with_files("vc1", Some(path.clone()), None, None);
    registry.create(&mut cu, None).unwrap();
    registry
        .update_checksum("vc1", ChecksumMode::SOURCE)
        .unwrap();

    fs::remove_file(dir.path().join(path)).unwrap();

    let report = registry.validate(ChecksumMode::SOURCE).unwrap();
    assert!(!report.is_valid);
    assert!(
        report
            .issues
            .iter()
            .any(|i| i.kind == ValidationIssueKind::ChecksumMismatch
                && i.message.contains("File not found")),
        "expected a ChecksumMismatch for missing file, got: {:?}",
        report.issues
    );
}

#[test]
fn validate_checksum_detects_mismatch() {
    let dir = temp_dir();
    let registry = CodeUnitRegistry::init(dir.path()).unwrap();
    let path = write_temp_source(dir.path(), "drift.sql", b"v1");
    let mut cu = make_code_unit_with_files("vc2", Some(path.clone()), None, None);
    registry.create(&mut cu, None).unwrap();
    registry
        .update_checksum("vc2", ChecksumMode::SOURCE)
        .unwrap();

    fs::write(dir.path().join(path), b"v2").unwrap();

    let report = registry.validate(ChecksumMode::SOURCE).unwrap();
    assert!(!report.is_valid);
    assert!(
        report
            .issues
            .iter()
            .any(|i| i.kind == ValidationIssueKind::ChecksumMismatch
                && i.message.contains("Checksum mismatch")),
        "expected a ChecksumMismatch for content drift, got: {:?}",
        report.issues
    );
}

// ── Path normalization tests ──────────────────────────────────────────

#[test]
fn create_normalizes_backslash_paths() {
    let dir = temp_dir();
    let registry = init_bare(dir.path());
    let mut cu = make_code_unit_with_files(
        "pn1",
        Some(r"source\Sales\tbl1.sql".to_string()),
        None,
        None,
    );
    registry.create(&mut cu, None).unwrap();

    let loaded = registry.get_by_id("pn1", None).unwrap();
    assert_eq!(
        loaded.files.unwrap().source.unwrap().path.unwrap(),
        "source/Sales/tbl1.sql"
    );
}

#[test]
fn read_normalizes_backslash_paths_on_disk() {
    let dir = temp_dir();
    let registry = init_bare(dir.path());

    let raw_json = serde_json::json!({
        "id": "pn2",
        "kind": "databaseObject",
        "files": {
            "source": { "path": "source\\Sales\\file.sql" }
        }
    });
    let registry_dir = dir.path().join("registry");
    fs::write(
        registry_dir.join("pn2.json"),
        serde_json::to_string_pretty(&raw_json).unwrap(),
    )
    .unwrap();

    let loaded = registry.get_by_id("pn2", None).unwrap();
    assert_eq!(
        loaded.files.unwrap().source.unwrap().path.unwrap(),
        "source/Sales/file.sql"
    );
}

#[test]
fn upsert_normalizes_dot_prefix_paths() {
    let dir = temp_dir();
    let registry = init_bare(dir.path());
    let mut cu =
        make_code_unit_with_files("pn3", Some(r".\source\file.sql".to_string()), None, None);
    registry.upsert(&mut cu, None).unwrap();

    let loaded = registry.get_by_id("pn3", None).unwrap();
    assert_eq!(
        loaded.files.unwrap().source.unwrap().path.unwrap(),
        "source/file.sql"
    );
}

#[test]
fn validate_reports_non_canonical_paths() {
    use crate::checksum::ChecksumMode;

    let dir = temp_dir();
    let registry = init_bare(dir.path());

    let raw_json = serde_json::json!({
        "id": "pn4",
        "kind": "databaseObject",
        "files": {
            "source": { "path": "source\\Sales\\file.sql" }
        }
    });
    let registry_dir = dir.path().join("registry");
    fs::write(
        registry_dir.join("pn4.json"),
        serde_json::to_string_pretty(&raw_json).unwrap(),
    )
    .unwrap();

    let report = registry.validate(ChecksumMode::NONE).unwrap();
    assert!(
        !report.is_valid,
        "NonCanonicalPath should make is_valid false"
    );
    assert!(
        report
            .issues
            .iter()
            .any(|i| i.kind == ValidationIssueKind::NonCanonicalPath),
        "expected a NonCanonicalPath issue, got: {:?}",
        report.issues
    );
}
