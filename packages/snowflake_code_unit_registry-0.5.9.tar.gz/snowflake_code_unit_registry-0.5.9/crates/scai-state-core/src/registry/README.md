# Registry Module Architecture

The `registry` module implements CRUD operations, dependency-graph refresh, and query traversal for `CodeUnit` documents stored as flat JSON files in `./registry/{id}.json`.

## Module Map

| Module | Responsibility |
|---|---|
| `registry.rs` | Public API (`CodeUnitRegistry`): CRUD, checksums, locking, refresh orchestration |
| `loader.rs` | Strict file-system loader with ID/filename validation |
| `in_memory.rs` | Short-lived in-memory state (`InMemoryRegistry`): owns loaded units + ID index, creates `RegistryGraph` and `RegistryQuery` views |
| `graph.rs` | Dependency-graph refresh engine: traversal utilities, `RefreshState` computation, full and scoped refresh |
| `query.rs` | Read-only query view: filter matching, transitive dependency expansion |
| `test_helpers.rs` | Shared `CodeUnit` fixtures for unit tests |

## Data Flow

```mermaid
flowchart TD
    subgraph publicAPI ["CodeUnitRegistry (registry.rs)"]
        CRUD["create / update / upsert / delete"]
        Batch["create_batch / update_batch / upsert_batch"]
        Query["find_all / find_by_object / get_by_id"]
        Refresh["refresh_dependencies"]
    end

    Loader["RegistryLoader (loader.rs): strict scan + parse + ID validation"]
    InMemory["InMemoryRegistry (in_memory.rs): units Vec + id_to_index HashMap"]
    Graph["RegistryGraph (graph.rs): traversal utilities + RefreshState"]
    QueryView["RegistryQuery (query.rs): filter matching + transitive expansion"]
    Disk["registry/*.json"]

    CRUD -->|"load_existing / write_json"| Disk
    CRUD -->|"scoped refresh"| InMemory
    Batch -->|"full refresh"| InMemory
    Refresh -->|"full refresh (strict)"| InMemory
    Query --> InMemory

    InMemory -->|"build()"| Loader
    Loader -->|"read_all_units()"| Disk
    InMemory -->|"graph()"| Graph
    InMemory -->|"query()"| QueryView

    Graph -->|"dirty indices"| InMemory
```

## Refresh Modes

- **Full refresh** (`graph.refresh`): recomputes all derived fields for every unit. Used by batch operations and `refresh_dependencies()`.
- **Scoped refresh** (`graph.refresh_scoped`): bidirectional BFS from seed nodes via `expand_scope`, then recomputes only the affected subgraph. Used by single-write operations (`create`, `update`, `upsert`, `delete`).
- A `planning.is_none()` guard in `refresh_scoped_and_sync` falls back to full refresh when any seed has never been refreshed (since `requiredBy` is not yet populated for successor traversal).

## Graph Terminology

If A depends on B (edge A -> B): B is A's **predecessor** (must be deployed first), A is B's **successor**.
- `predecessors(A)` yields B (follows `dependsOn`)
- `successors(B)` yields A (follows stored `requiredBy`)

## Adding a New Derived Field

1. Add a storage array to `RefreshState`
2. Compute it in `visit_unit` (order-independent) or `visit_topo` (needs topological order)
3. Add a `set_*` field setter function
4. Add one `set_*` call in `RefreshState::apply`

## Future: Unified In-Memory Write Path [SNOW-3176123](https://snowflakecomputing.atlassian.net/browse/SNOW-3176123)

`InMemoryRegistry` is currently read-only -- it loads all units for refresh and query but never writes to disk. Writes happen directly in `registry.rs` via `load_existing` / `write_json`, which means units are loaded from disk twice per write operation: once for the CRUD mutation, and once when `InMemoryRegistry::build()` reloads everything for the refresh pass.

A future optimization would route all writes through `InMemoryRegistry`, mirroring the existing `RegistryLoader` (disk -> memory) with a `RegistryPersister` (memory -> disk):

```
Current:    CRUD reads file  ->  mutates  ->  writes file  ->  InMemory loads ALL files  ->  refresh
Future:     InMemory loads ALL files  ->  CRUD mutates in-memory  ->  refresh  ->  Persister flushes dirty
```

This would eliminate the redundant disk reads and let CRUD operations, refresh, and persistence share a single in-memory dataset per lock scope.
