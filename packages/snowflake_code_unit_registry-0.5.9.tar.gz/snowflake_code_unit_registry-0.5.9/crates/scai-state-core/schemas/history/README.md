# Schema History

Frozen snapshots of previous schema versions. Each snapshot captures the
schema as it was *before* bumping to the next version, providing a reference
for migration correctness and regression testing.

This directory is currently empty — it will contain its first snapshot when
`CURRENT_SCHEMA_VERSION` is bumped from 1 to 2.

**Rules:**

- Files are IMMUTABLE — never modify a frozen schema after it has been committed.
- Naming: `code-unit.v{N}.schema.json` (snapshot of the schema that was current for version N).
- See `schema-workflow.mdc` step 1 for when to create a snapshot.
