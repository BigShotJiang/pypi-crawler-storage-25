"""FFI serialization fidelity tests.

Validates that the Python -> Rust -> disk -> Rust -> Python round-trip
preserves all fields, including aliases, enums, nested objects, and
empty containers like extensions.
"""

from __future__ import annotations

import os

from snowflake_code_unit_registry import CodeUnitRegistry
from snowflake_code_unit_registry.types import (
    ArtifactsEntry,
    CloudStatus,
    CodeStatus,
    CodeUnit,
    ColumnDef,
    ConversionStatus,
    Dependencies,
    Dependency,
    RegistrationStatus,
    FileEntry,
    Files,
    Issue,
    Kind,
    ObjectType,
    ParameterDef,
    Parameters,
    Planning,
    ReturnDef,
    Signature,
    SourceMetadata,
    TargetMetadata,
    TestingStatus,
)


def test_roundtrip_full_document(registry_dir: str):
    """Create a CodeUnit with every major section populated, persist it,
    read it back, and verify all fields survived the
    Python -> Rust -> disk -> Rust -> Python round-trip."""

    registry = CodeUnitRegistry.init(registry_dir)

    # Use model_validate for Source/TargetMetadata because the 'schema' alias
    # conflicts with Pydantic internals when passed via constructor kwargs
    # combined with extra='allow'.  model_validate uses alias resolution and
    # works correctly.
    original = CodeUnit(
        id="roundtrip-001",
        kind=Kind.databaseObject,
        source=SourceMetadata.model_validate(
            {
                "objectType": ObjectType.procedure,
                "database": "AdventureWorks",
                "schema": "Sales",
                "name": "usp_GetRevenue",
            }
        ),
        target=TargetMetadata.model_validate(
            {
                "objectType": ObjectType.procedure,
                "database": "ADVENTUREWORKS",
                "schema": "SALES",
                "name": "USP_GET_REVENUE",
            }
        ),
        codeStatus=CodeStatus(
            registration=RegistrationStatus(status="completed", extractorVersion="2.4.1", sourceId="primary"),
            conversion=ConversionStatus(status="completed", converterVersion="3.1.0"),
        ),
        cloudStatus=CloudStatus(
            testing=TestingStatus(
                status="completed",
                updatedAt="2025-06-15T14:30:00Z",
                details={"runner": "pytest", "passedCount": 12},
            ),
        ),
        files=Files(
            source=FileEntry(
                path="source/Sales/usp_GetRevenue.sql",
                checksum="db97ea0a2998433d5e51367e6d118414",
            ),
            converted=FileEntry(
                path="converted/Sales/usp_GetRevenue.sql",
                checksum="695f088194f33ab6b670703746c00ec2",
            ),
            artifacts=ArtifactsEntry(path="artifacts/Sales/Procedures/usp_GetRevenue"),
        ),
        dependencies=Dependencies(
            dependsOn=[
                Dependency(
                    id="dep-001",
                    isMissing=False,
                    relationTypes=["SELECT"],
                )
            ],
            requiredBy=["dep-002"],
        ),
        planning=Planning(
            wave=2, topologicalRank=1, generatedBy="test-harness"
        ),
        issues=[
            Issue(code="SC0001", count=1),
            Issue(code="SC0042", count=2),
        ],
        signature=Signature(
            columns=[
                ColumnDef(
                    name="Revenue",
                    type="DECIMAL(18,2)",
                    nullable=False,
                    targetName="REVENUE",
                    targetType="NUMBER(18,2)",
                )
            ],
            parameters=Parameters(
                arguments=[
                    ParameterDef(
                        name="@StartDate",
                        type="DATETIME",
                        required=True,
                        defaultValue="",
                        targetName="START_DATE",
                        targetType="TIMESTAMP_NTZ",
                    )
                ],
                returns=[
                    ReturnDef(
                        name="Revenue",
                        type="DECIMAL(18,2)",
                        targetName="REVENUE",
                        targetType="NUMBER(18,2)",
                    )
                ],
            ),
        ),
    )

    created_id = registry.create(original)
    assert created_id == "roundtrip-001"

    loaded = registry.get_by_id("roundtrip-001")

    # Identity
    assert loaded.id == original.id
    assert loaded.kind == original.kind
    assert loaded.source.objectType == original.source.objectType
    assert loaded.schemaVersion == 1
    assert loaded.isMissing is False
    assert loaded.inScope is True

    # Source / Target
    assert loaded.source.database == "AdventureWorks"
    assert loaded.source.name == "usp_GetRevenue"
    assert loaded.target.name == "USP_GET_REVENUE"

    # The 'schema' field uses a Pydantic alias (schema_ -> "schema").
    # Verify via model_dump which correctly resolves aliases across the FFI.
    loaded_dict = loaded.model_dump(mode="json", by_alias=True)
    assert loaded_dict["source"]["schema"] == "Sales"
    assert loaded_dict["target"]["schema"] == "SALES"
    # Files
    assert loaded.files.source.path == "source/Sales/usp_GetRevenue.sql"
    assert loaded.files.converted.checksum is not None
    assert loaded.files.artifacts.path == "artifacts/Sales/Procedures/usp_GetRevenue"

    # Code Status
    assert loaded.codeStatus.registration.status.value == "completed"
    assert loaded.codeStatus.registration.extractorVersion == "2.4.1"
    assert loaded.codeStatus.registration.sourceId == "primary"
    assert loaded.codeStatus.conversion.status.value == "completed"
    assert loaded.codeStatus.conversion.converterVersion == "3.1.0"
    assert loaded.cloudStatus.testing.status.value == "completed"
    assert loaded.cloudStatus.testing.updatedAt is not None
    assert loaded.cloudStatus.testing.details["runner"] == "pytest"
    assert loaded.cloudStatus.testing.details["passedCount"] == 12

    # Dependencies -- auto-refresh reconciles isMissing (dep-001 is absent
    # from the registry) and computes hasTransitiveMissingDependencies.
    assert len(loaded.dependencies.dependsOn) == 1
    assert loaded.dependencies.dependsOn[0].id == "dep-001"
    assert loaded.dependencies.dependsOn[0].isMissing is True
    assert loaded.dependencies.hasTransitiveMissingDependencies is True
    # requiredBy is a derived field recomputed from other units' dependsOn
    # edges — user-supplied values don't survive refresh.
    assert loaded.dependencies.requiredBy == []

    # Planning -- auto-refresh recomputes topologicalRank (0 because the
    # only dependency is missing and therefore not a graph edge).
    assert loaded.planning.wave == 2
    assert loaded.planning.topologicalRank == 0
    assert loaded.planning.generatedBy == "test-harness"

    # Issues
    assert len(loaded.issues.root) == 2
    assert loaded.issues.root[0].code == "SC0001"
    assert loaded.issues.root[0].count == 1

    # Signature
    assert len(loaded.signature.columns) == 1
    assert loaded.signature.columns[0].name == "Revenue"
    assert len(loaded.signature.parameters.arguments) == 1
    assert loaded.signature.parameters.arguments[0].name == "@StartDate"
    assert len(loaded.signature.parameters.returns) == 1


def test_custom_code_status_phase_roundtrip(registry_dir: str):
    """Verify that user-defined codeStatus phases (additionalProperties)
    survive the full Python -> Rust -> disk -> Rust -> Python round-trip."""

    registry = CodeUnitRegistry.init(registry_dir)

    cu = CodeUnit(
        id="custom-phase-001",
        kind=Kind.databaseObject,
        source=SourceMetadata.model_validate(
            {"objectType": ObjectType.table, "database": "DB", "schema": "dbo", "name": "T1"}
        ),
        target=TargetMetadata.model_validate(
            {"objectType": ObjectType.table, "database": "DB", "schema": "DBO", "name": "T1"}
        ),
        codeStatus=CodeStatus(
            registration=RegistrationStatus(status="completed"),
            dataQuality={"status": "completed", "score": 95, "checkedAt": "2025-01-15T11:00:00Z"},
        ),
    )
    registry.create(cu)

    loaded = registry.get_by_id("custom-phase-001")

    # Known typed field still works
    assert loaded.codeStatus.registration.status.value == "completed"

    # Custom phase survives via Pydantic extra='allow'
    assert loaded.codeStatus.dataQuality is not None
    assert loaded.codeStatus.dataQuality["status"] == "completed"
    assert loaded.codeStatus.dataQuality["score"] == 95
    assert loaded.codeStatus.dataQuality["checkedAt"] == "2025-01-15T11:00:00Z"

    # Verify via model_dump as well
    dumped = loaded.model_dump(mode="json", by_alias=True)
    dq = dumped["codeStatus"]["dataQuality"]
    assert dq["status"] == "completed"
    assert dq["score"] == 95


def test_extensions_roundtrip(registry_dir: str):
    """Verify that the extensions field (empty map by default) survives the
    full round-trip.  This is a regression guard for the build.rs fix that
    strips skip_serializing_if on empty maps."""

    registry = CodeUnitRegistry.init(registry_dir)

    cu = CodeUnit(
        id="ext-001",
        kind=Kind.databaseObject,
        source=SourceMetadata.model_validate(
            {"objectType": ObjectType.table, "database": "DB", "schema": "dbo", "name": "T1"}
        ),
        target=TargetMetadata.model_validate(
            {"objectType": ObjectType.table, "database": "DB", "schema": "DBO", "name": "T1"}
        ),
    )
    registry.create(cu)

    loaded = registry.get_by_id("ext-001")
    loaded_dict = loaded.model_dump(mode="json", by_alias=True)

    # The extensions key must be present and be an empty dict, not missing/None.
    assert "extensions" in loaded_dict
    assert loaded_dict["extensions"] == {}

    # Also verify via attribute access on the Pydantic model.
    assert loaded.extensions == {}
