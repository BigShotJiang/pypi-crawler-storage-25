//! Python bindings for SCAI state management
//!
//! This crate provides Python bindings using the generated Rust types
//! from the JSON schema. Data crosses the FFI boundary as native Python
//! objects (dicts/lists) using the `pythonize` crate for direct
//! serde ↔ Python conversion – no JSON string intermediary.

use pyo3::create_exception;
use pyo3::prelude::*;
use pythonize::{depythonize, pythonize};
use scai_state_core::{
    ChecksumMode, CodeUnit, CodeUnitRegistry as RustRegistry, FindOptions, WriteOptions,
};
use serde::Deserialize;

// Custom exception with error_code attribute
create_exception!(scai_state, ScaiError, pyo3::exceptions::PyException);

/// Convert a core error into a Python ScaiError with error_code and info.
fn to_py_error(py: Python<'_>, e: scai_state_core::Error) -> PyErr {
    let info = e.info();
    let code = info.code;
    let message = info.message.clone();
    let err = PyErr::new::<ScaiError, _>(message);
    let _ = err.value(py).setattr("error_code", code);
    if let Ok(info_dict) = pythonize(py, &info) {
        let _ = err.value(py).setattr("info", info_dict);
    }
    err
}

/// Parse a checksum_mode string into a core `ChecksumMode`.
/// Maps binding-layer parse errors to PyValueError so callers get a clear message.
fn parse_checksum(py: Python<'_>, s: &str) -> PyResult<ChecksumMode> {
    s.parse::<ChecksumMode>().map_err(|e| to_py_error(py, e))
}

/// Intermediate struct for deserializing Python-side `WriteOptions`.
#[derive(Debug, Default, serde::Deserialize)]
#[serde(default)]
struct PyWriteOptions {
    checksum_mode: Option<String>,
}

fn parse_write_options(
    py: Python<'_>,
    opts: Option<&Bound<'_, PyAny>>,
) -> PyResult<Option<WriteOptions>> {
    let obj = match opts {
        None => return Ok(None),
        Some(o) => o,
    };
    let input: PyWriteOptions = depythonize(obj)
        .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;
    match input.checksum_mode {
        None => Ok(None),
        Some(s) => {
            let mode = parse_checksum(py, &s)?;
            Ok(Some(WriteOptions {
                checksum_mode: mode,
            }))
        }
    }
}

/// Python-side payload for `find_all` options.
#[derive(Debug, Default, Deserialize)]
#[serde(default)]
struct PyFindOptions {
    filter: Option<String>,
    fields: Option<Vec<String>>,
    include_dependencies: bool,
}

/// Python wrapper for CodeUnitRegistry
#[pyclass]
pub struct CodeUnitRegistry {
    inner: RustRegistry,
}

#[pymethods]
impl CodeUnitRegistry {
    /// Initialize a new registry at the given path
    #[staticmethod]
    fn exists(path: &str) -> bool {
        RustRegistry::exists(path)
    }

    #[staticmethod]
    fn init(py: Python<'_>, path: &str) -> PyResult<Self> {
        let inner = RustRegistry::init(path).map_err(|e| to_py_error(py, e))?;
        Ok(Self { inner })
    }

    /// Open an existing registry at the given path
    #[staticmethod]
    fn open(py: Python<'_>, path: &str) -> PyResult<Self> {
        let inner = RustRegistry::open(path).map_err(|e| to_py_error(py, e))?;
        Ok(Self { inner })
    }

    // ── Create ───────────────────────────────────────────────────────────

    /// Create a new code unit on disk. Returns the ID.
    #[pyo3(signature = (code_unit, options=None))]
    fn create(
        &self,
        py: Python<'_>,
        code_unit: Bound<'_, PyAny>,
        options: Option<Bound<'_, PyAny>>,
    ) -> PyResult<String> {
        let mut cu: CodeUnit = depythonize(&code_unit)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;
        let opts = parse_write_options(py, options.as_ref())?;
        self.inner
            .create(&mut cu, opts.as_ref())
            .map_err(|e| to_py_error(py, e))
    }

    /// Batch create multiple code units efficiently.
    /// Returns a dict: {"succeeded": [id, ...], "failed": [{"id": ..., "error": {...}}, ...], "sideEffectIds": [...]}
    #[pyo3(signature = (batch, options=None))]
    fn create_batch(
        &self,
        py: Python<'_>,
        batch: Bound<'_, PyAny>,
        options: Option<Bound<'_, PyAny>>,
    ) -> PyResult<Py<PyAny>> {
        let mut batch: Vec<CodeUnit> = depythonize(&batch)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;
        let opts = parse_write_options(py, options.as_ref())?;
        let result = self
            .inner
            .create_batch(&mut batch, opts.as_ref())
            .map_err(|e| to_py_error(py, e))?;
        batch_result_to_py(py, &result)
    }

    // ── Load / List ──────────────────────────────────────────────────────

    /// Load a code unit by ID. Returns CodeUnit as a Python dict.
    /// Get a code unit by ID. Returns a Python dict.
    #[pyo3(name = "get_by_id", signature = (id, include=None))]
    fn get_by_id(
        &self,
        py: Python<'_>,
        id: &str,
        include: Option<Vec<String>>,
    ) -> PyResult<Py<PyAny>> {
        let include_refs: Option<Vec<&str>> = include
            .as_ref()
            .map(|v| v.iter().map(|s| s.as_str()).collect());
        let doc = self
            .inner
            .get_by_id(id, include_refs.as_deref())
            .map_err(|e| to_py_error(py, e))?;
        pythonize(py, &doc)
            .map(|b| b.unbind())
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))
    }

    /// Find all code units using a single options object.
    /// Returns a Python list of dicts.
    #[pyo3(name = "find_all", signature = (options=None))]
    fn find_all(&self, py: Python<'_>, options: Option<Bound<'_, PyAny>>) -> PyResult<Py<PyAny>> {
        let options = match options {
            Some(options) => depythonize::<PyFindOptions>(&options)
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?,
            None => PyFindOptions::default(),
        };

        let include_refs: Option<Vec<&str>> = options
            .fields
            .as_ref()
            .map(|v| v.iter().map(|s| s.as_str()).collect());
        let docs = self
            .inner
            .find_all(FindOptions {
                filter: options.filter.as_deref(),
                fields: include_refs.as_deref(),
                include_dependencies: options.include_dependencies,
            })
            .map_err(|e| to_py_error(py, e))?;
        pythonize(py, &docs)
            .map(|b| b.unbind())
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))
    }

    /// Find code units matching all fields present in a partial code unit object.
    /// Returns a Python list of dicts.
    #[pyo3(name = "find_by_object", signature = (partial, include=None))]
    fn find_by_object(
        &self,
        py: Python<'_>,
        partial: Bound<'_, PyAny>,
        include: Option<Vec<String>>,
    ) -> PyResult<Py<PyAny>> {
        let partial_value: serde_json::Value = depythonize(&partial)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;
        let include_refs: Option<Vec<&str>> = include
            .as_ref()
            .map(|v| v.iter().map(|s| s.as_str()).collect());
        let docs = self
            .inner
            .find_by_object(&partial_value, include_refs.as_deref())
            .map_err(|e| to_py_error(py, e))?;
        pythonize(py, &docs)
            .map(|b| b.unbind())
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))
    }

    // ── Update (PATCH) ───────────────────────────────────────────────────

    /// Update specific fields in a code unit by dot-notation paths.
    #[pyo3(signature = (id, updates, options=None))]
    fn update(
        &self,
        py: Python<'_>,
        id: &str,
        updates: Bound<'_, PyAny>,
        options: Option<Bound<'_, PyAny>>,
    ) -> PyResult<()> {
        let updates_map: serde_json::Map<String, serde_json::Value> = depythonize(&updates)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;
        let updates_vec: Vec<(&str, serde_json::Value)> = updates_map
            .iter()
            .map(|(k, v)| (k.as_str(), v.clone()))
            .collect();
        let opts = parse_write_options(py, options.as_ref())?;
        self.inner
            .update(id, &updates_vec, opts.as_ref())
            .map_err(|e| to_py_error(py, e))
    }

    /// Update all code units matching a filter with the same updates.
    #[pyo3(signature = (filter, updates, options=None))]
    fn update_where(
        &self,
        py: Python<'_>,
        filter: &str,
        updates: Bound<'_, PyAny>,
        options: Option<Bound<'_, PyAny>>,
    ) -> PyResult<Py<PyAny>> {
        let updates_map: serde_json::Map<String, serde_json::Value> = depythonize(&updates)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;
        let updates_vec: Vec<(&str, serde_json::Value)> = updates_map
            .iter()
            .map(|(k, v)| (k.as_str(), v.clone()))
            .collect();
        let opts = parse_write_options(py, options.as_ref())?;
        let result = self
            .inner
            .update_where(filter, &updates_vec, opts.as_ref())
            .map_err(|e| to_py_error(py, e))?;
        batch_result_to_py(py, &result)
    }

    /// Batch update multiple code units efficiently.
    #[pyo3(signature = (batch, options=None))]
    fn update_batch(
        &self,
        py: Python<'_>,
        batch: Bound<'_, PyAny>,
        options: Option<Bound<'_, PyAny>>,
    ) -> PyResult<Py<PyAny>> {
        let batch_raw: Vec<(String, serde_json::Map<String, serde_json::Value>)> =
            depythonize(&batch)
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;
        let batch_vec: Vec<(&str, Vec<(&str, serde_json::Value)>)> = batch_raw
            .iter()
            .map(|(id, updates_map)| {
                let updates: Vec<(&str, serde_json::Value)> = updates_map
                    .iter()
                    .map(|(k, v)| (k.as_str(), v.clone()))
                    .collect();
                (id.as_str(), updates)
            })
            .collect();
        let opts = parse_write_options(py, options.as_ref())?;
        let result = self
            .inner
            .update_batch(&batch_vec, opts.as_ref())
            .map_err(|e| to_py_error(py, e))?;
        batch_result_to_py(py, &result)
    }

    // ── Upsert (merge) ──────────────────────────────────────────────────

    /// Create-or-merge a single code unit. Returns the ID.
    #[pyo3(signature = (code_unit, options=None))]
    fn upsert(
        &self,
        py: Python<'_>,
        code_unit: Bound<'_, PyAny>,
        options: Option<Bound<'_, PyAny>>,
    ) -> PyResult<String> {
        let mut cu: CodeUnit = depythonize(&code_unit)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;
        let opts = parse_write_options(py, options.as_ref())?;
        self.inner
            .upsert(&mut cu, opts.as_ref())
            .map_err(|e| to_py_error(py, e))
    }

    /// Batch upsert multiple code units.
    #[pyo3(signature = (batch, options=None))]
    fn upsert_batch(
        &self,
        py: Python<'_>,
        batch: Bound<'_, PyAny>,
        options: Option<Bound<'_, PyAny>>,
    ) -> PyResult<Py<PyAny>> {
        let mut batch: Vec<CodeUnit> = depythonize(&batch)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;
        let opts = parse_write_options(py, options.as_ref())?;
        let result = self
            .inner
            .upsert_batch(&mut batch, opts.as_ref())
            .map_err(|e| to_py_error(py, e))?;
        batch_result_to_py(py, &result)
    }

    /// Recompute checksums for selected file entries on an existing code unit.
    /// `checksum_mode`: "none" | "source" | "converted" | "snapshot" | "all"
    fn update_checksum(&self, py: Python<'_>, id: &str, checksum_mode: &str) -> PyResult<()> {
        let mode = parse_checksum(py, checksum_mode)?;
        self.inner
            .update_checksum(id, mode)
            .map_err(|e| to_py_error(py, e))
    }

    /// Validate checksums for an existing code unit.
    fn validate_checksum(
        &self,
        py: Python<'_>,
        id: &str,
        checksum_mode: &str,
    ) -> PyResult<Py<PyAny>> {
        let checksum = parse_checksum(py, checksum_mode)?;
        let report = self
            .inner
            .validate_checksum(id, checksum)
            .map_err(|e| to_py_error(py, e))?;
        pythonize(py, &report)
            .map(|b| b.unbind())
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))
    }

    // ── Validation ────────────────────────────────────────────────────────

    /// Validate all code units in the registry.
    #[pyo3(signature = (checksum_mode="all"))]
    fn validate(&self, py: Python<'_>, checksum_mode: &str) -> PyResult<Py<PyAny>> {
        let mode = parse_checksum(py, checksum_mode)?;
        let report = self.inner.validate(mode).map_err(|e| to_py_error(py, e))?;
        pythonize(py, &report)
            .map(|b| b.unbind())
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))
    }

    /// Validate a single code unit by ID.
    #[pyo3(signature = (id, checksum_mode="all"))]
    fn validate_unit(&self, py: Python<'_>, id: &str, checksum_mode: &str) -> PyResult<Py<PyAny>> {
        let mode = parse_checksum(py, checksum_mode)?;
        let report = self
            .inner
            .validate_unit(id, mode)
            .map_err(|e| to_py_error(py, e))?;
        pythonize(py, &report)
            .map(|b| b.unbind())
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))
    }

    // ── Change detection ─────────────────────────────────────────────────

    /// Detect source-code changes (modified, removed, untracked files).
    #[pyo3(signature = (checksum_mode="all", filter=None))]
    fn find_sql_file_changes(
        &self,
        py: Python<'_>,
        checksum_mode: &str,
        filter: Option<&str>,
    ) -> PyResult<Py<PyAny>> {
        let mode = parse_checksum(py, checksum_mode)?;
        let changes = self
            .inner
            .find_sql_file_changes(mode, filter)
            .map_err(|e| to_py_error(py, e))?;
        pythonize(py, &changes)
            .map(|b| b.unbind())
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))
    }

    // ── Delete ───────────────────────────────────────────────────────────

    /// Delete a code unit by ID.
    fn delete(&self, py: Python<'_>, id: &str) -> PyResult<()> {
        self.inner.delete(id).map_err(|e| to_py_error(py, e))
    }

    // ── Refresh ─────────────────────────────────────────────────────────

    /// Recompute dependency-derived fields across the entire registry.
    /// Uses strict cycle detection: raises ScaiError with error_code 1014 on cycles.
    fn refresh_dependencies(&self, py: Python<'_>) -> PyResult<()> {
        self.inner
            .refresh_dependencies()
            .map_err(|e| to_py_error(py, e))
    }

    // ── Migration ─────────────────────────────────────────────────────

    /// Migrate all registry documents to the current schema version.
    ///
    /// Best-effort: per-file failures are returned in `BatchResult.failed`.
    /// Raises only on batch-level failures; partial progress may have occurred.
    fn migrate_schema_all(&self, py: Python<'_>) -> PyResult<Py<PyAny>> {
        let result = self
            .inner
            .migrate_schema_all()
            .map_err(|e| to_py_error(py, e))?;
        batch_result_to_py(py, &result)
    }
}

/// Generate a new code unit ID (32-character UUID v4).
#[pyfunction]
fn generate_id() -> String {
    scai_state_core::generate_id()
}

/// Hash a file with xxHash3-128 and return the 32-character lowercase hex digest.
///
/// The path must be absolute. File-not-found raises ScaiError (code 1008).
#[pyfunction]
fn compute_file_checksum(py: Python<'_>, path: &str) -> PyResult<String> {
    scai_state_core::compute_file_checksum(path).map_err(|e| to_py_error(py, e))
}

/// Returns a list of [name, code] pairs for every error variant.
///
/// Used by the Python contract test to verify the `ErrorCode` IntEnum
/// stays in sync with the Rust `Error` enum.
#[pyfunction]
fn list_error_codes(py: Python<'_>) -> PyResult<Py<PyAny>> {
    let codes = scai_state_core::Error::all_codes();
    let pairs: Vec<(String, i32)> = codes
        .into_iter()
        .map(|(name, code)| (name.to_string(), code))
        .collect();
    pythonize(py, &pairs)
        .map(|b| b.unbind())
        .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))
}

/// Return the current schema version supported by this library.
#[pyfunction]
fn current_schema_version() -> i32 {
    scai_state_core::CURRENT_SCHEMA_VERSION as i32
}

/// Return the auto-generated query reference for CodeUnit fields.
///
/// Lists every queryable field path, type, allowed values, and supported
/// SQL WHERE operators. Useful for LLM/agent tool descriptions.
#[pyfunction]
fn query_reference() -> String {
    scai_state_core::QUERY_REFERENCE.to_string()
}

/// Convert a BatchResult into a Python dict.
fn batch_result_to_py(
    py: Python<'_>,
    result: &scai_state_core::BatchResult,
) -> PyResult<Py<PyAny>> {
    pythonize(py, result)
        .map(|b| b.unbind())
        .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))
}

/// Python module definition
#[pymodule]
fn _native(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<CodeUnitRegistry>()?;
    m.add_function(wrap_pyfunction!(generate_id, m)?)?;
    m.add_function(wrap_pyfunction!(compute_file_checksum, m)?)?;
    m.add_function(wrap_pyfunction!(list_error_codes, m)?)?;
    m.add_function(wrap_pyfunction!(query_reference, m)?)?;
    m.add_function(wrap_pyfunction!(current_schema_version, m)?)?;
    m.add("ScaiError", m.py().get_type::<ScaiError>())?;
    Ok(())
}
