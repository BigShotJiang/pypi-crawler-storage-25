# pragma/storage
