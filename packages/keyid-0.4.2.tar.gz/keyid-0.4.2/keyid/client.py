"""KeyID API client — full-featured agent email SDK."""

from __future__ import annotations

import platform as _platform
import socket
import sys
import time
from datetime import datetime
from typing import Any
from urllib.parse import quote

import httpx

from .crypto import generate_keypair, sign

__version__ = "0.4.2"


def _encode_content_b64(content: str | bytes) -> str:
    """Encode arbitrary file content as base64.

    Strings are treated as UTF-8 text and base64-encoded as bytes.
    Bytes are base64-encoded directly.
    """
    import base64

    if isinstance(content, str):
        content = content.encode("utf-8")
    return base64.b64encode(content).decode("ascii")


class KeyID:
    """KeyID agent client.

    Usage::

        agent = KeyID()
        result = agent.provision()
        print(result["email"])

        inbox = agent.get_inbox()
        agent.send("user@example.com", "Hello", "Body text")

        # Threads
        threads = agent.list_threads()
        thread = agent.get_thread(thread_id)

        # Drafts
        draft_id = agent.create_draft(to="x@y.com", subject="Hi")["draftId"]
        agent.send_draft(draft_id)

        # Webhooks
        wh = agent.create_webhook("https://example.com/hook", events=["message.received"])

        # Lists
        agent.add_to_list("inbound", "block", "spammer@evil.com")

        # Metrics
        metrics = agent.get_metrics(event="message.received", period="day")
    """

    def __init__(
        self,
        *,
        base_url: str = "https://keyid.ai",
        public_key: str | None = None,
        private_key: str | None = None,
        storage_type: str = "memory",
    ):
        self.base_url = base_url.rstrip("/")
        self.storage_type = storage_type
        self._token: str | None = None
        self._token_expires_at: float = 0

        if public_key and private_key:
            self.public_key = public_key
            self._private_key = private_key
        else:
            self.public_key, self._private_key = generate_keypair()

        self._client = httpx.Client(base_url=self.base_url, timeout=30)

    # -- Identity & Auth ------------------------------------------

    def provision(self) -> dict[str, Any]:
        """Register agent and get an email address."""
        meta: dict[str, str] = {
            "sdk": "keyid-py",
            "sdkVersion": __version__,
            "runtime": "python",
            "runtimeVersion": _platform.python_version(),
            "platform": sys.platform,
        }
        try:
            meta["hostname"] = socket.gethostname()
        except Exception:
            pass
        return self._request(
            "POST",
            "/api/provision",
            json={"pubkey": self.public_key, "storageType": self.storage_type, **meta},
        )

    def authenticate(self) -> str:
        """Authenticate via challenge-response. Returns JWT token."""
        data = self._request(
            "POST", "/api/auth/challenge", json={"pubkey": self.public_key}
        )
        nonce = data["nonce"]
        signature = sign(nonce, self._private_key)

        result = self._request(
            "POST",
            "/api/auth/verify",
            json={"pubkey": self.public_key, "nonce": nonce, "signature": signature},
        )

        self._token = result["token"]
        self._token_expires_at = datetime.fromisoformat(
            result["expiresAt"].replace("Z", "+00:00")
        ).timestamp()
        return self._token

    def get_identity(self) -> dict[str, Any]:
        """Get current agent identity info."""
        self._ensure_auth()
        return self._request("GET", "/api/identity", auth=True)

    def update_identity(self, display_name: str | None = None) -> dict[str, Any]:
        """Update agent identity fields (e.g. displayName)."""
        self._ensure_auth()
        return self._request("PATCH", "/api/identity", json={"displayName": display_name}, auth=True)

    def get_email(self) -> str:
        """Get current active email address."""
        return self.get_identity()["email"]

    def get_addresses(self) -> list[dict[str, Any]]:
        """Get all email addresses (current and historical)."""
        self._ensure_auth()
        return self._request("GET", "/api/addresses", auth=True)["addresses"]

    def recover(
        self,
        recovery_token: str,
        new_public_key: str | None = None,
        new_private_key: str | None = None,
    ) -> dict[str, Any]:
        """Rotate keypair using recovery token. Returns new token + new recovery token.

        If new_public_key/new_private_key are not provided, generates a fresh keypair.
        """
        if new_public_key and new_private_key:
            pub, priv = new_public_key, new_private_key
        else:
            pub, priv = generate_keypair()

        result = self._request(
            "POST",
            "/api/auth/recover",
            json={"recoveryToken": recovery_token, "newPubkey": pub},
        )

        # Update local state to use new keypair and token
        self.public_key = pub
        self._private_key = priv
        self._token = result["token"]
        self._token_expires_at = datetime.fromisoformat(
            result["expiresAt"].replace("Z", "+00:00")
        ).timestamp()
        return result

    # -- Phone / SMS ----------------------------------------------

    def request_phone(self) -> dict[str, Any]:
        """Request a long-lived phone number for this agent. Idempotent — repeat
        calls return the existing assignment.

        Returns ``{"phone": "+1...", "phoneId": "uuid"}``.

        The number receives SMS via the unified inbox
        (``get_inbox(channel="sms")``) and via ``sms.received`` webhooks.

        For one-shot SMS verification on a third-party signup form, prefer
        ``start_registration_session(use_sms_lease=True)`` instead — it leases
        a fresh number that's released back to the pool when the session
        completes.
        """
        self._ensure_auth()
        return self._request("POST", "/api/phone", json={}, auth=True)

    # -- Reputation -----------------------------------------------

    def get_reputation(self) -> dict[str, Any]:
        """Get this agent's current reputation score (0-100), tier, and factor breakdown."""
        self._ensure_auth()
        return self._request("GET", "/api/reputation", auth=True)

    # -- Public profiles ------------------------------------------

    def get_public_profile(self, agent_id: str) -> dict[str, Any]:
        """Look up another agent's public profile by ID. Unauthenticated — works
        for any agent that has set ``profile_public=True`` via ``update_identity``.
        """
        return self._request("GET", f"/api/agents/{quote(agent_id, safe='')}/profile")

    # -- Inbox / Messages -----------------------------------------

    def get_inbox(
        self,
        *,
        page: int = 1,
        limit: int = 50,
        direction: str | None = None,
        since: str | None = None,
        labels: list[str] | None = None,
        search: str | None = None,
        channel: str | None = None,
    ) -> dict[str, Any]:
        """Fetch inbox messages with optional full-text search.

        Pass ``channel="sms"`` or ``channel="email"`` to filter by source channel.
        Omit to return both.
        """
        self._ensure_auth()
        params: dict[str, Any] = {"page": page, "limit": limit}
        if direction:
            params["direction"] = direction
        if since:
            params["since"] = since
        if labels:
            params["labels"] = ",".join(labels)
        if search:
            params["search"] = search
        if channel:
            params["channel"] = channel
        return self._request("GET", "/api/inbox", params=params, auth=True)

    def get_message(self, message_id: str) -> dict[str, Any]:
        """Get a single message by ID."""
        self._ensure_auth()
        return self._request("GET", f"/api/inbox/{message_id}", auth=True)

    def update_message(
        self, message_id: str, *, labels: list[str] | None = None, status: str | None = None,
        is_read: bool | None = None, is_starred: bool | None = None,
    ) -> dict[str, Any]:
        """Update message labels, status, read/starred state."""
        self._ensure_auth()
        body: dict[str, Any] = {}
        if labels is not None:
            body["labels"] = labels
        if status is not None:
            body["status"] = status
        if is_read is not None:
            body["isRead"] = is_read
        if is_starred is not None:
            body["isStarred"] = is_starred
        return self._request("PATCH", f"/api/inbox/{message_id}", json=body, auth=True)

    def send(
        self,
        to: str,
        subject: str,
        body: str,
        *,
        html: str | None = None,
        cc: list[str] | None = None,
        bcc: list[str] | None = None,
        reply_to: str | None = None,
        thread_id: str | None = None,
        labels: list[str] | None = None,
        attachments: list[dict[str, Any]] | None = None,
        display_name: str | None = None,
        scheduled_at: str | None = None,
    ) -> dict[str, Any]:
        """Send an email with optional HTML, CC, BCC, attachments, scheduling."""
        self._ensure_auth()
        payload: dict[str, Any] = {"to": to, "subject": subject, "body": body}
        if html:
            payload["html"] = html
        if cc:
            payload["cc"] = cc
        if bcc:
            payload["bcc"] = bcc
        if reply_to:
            payload["replyTo"] = reply_to
        if thread_id:
            payload["threadId"] = thread_id
        if labels:
            payload["labels"] = labels
        if attachments:
            payload["attachments"] = attachments
        if display_name:
            payload["displayName"] = display_name
        if scheduled_at:
            payload["scheduledAt"] = scheduled_at
        return self._request("POST", "/api/send", json=payload, auth=True)

    def reply(self, message_id: str, body: str, *, html: str | None = None) -> dict[str, Any]:
        """Reply to a message."""
        self._ensure_auth()
        payload: dict[str, Any] = {"body": body}
        if html:
            payload["html"] = html
        return self._request("POST", f"/api/inbox/{message_id}/reply", json=payload, auth=True)

    def reply_all(self, message_id: str, body: str, *, html: str | None = None) -> dict[str, Any]:
        """Reply-all to a message."""
        self._ensure_auth()
        payload: dict[str, Any] = {"body": body}
        if html:
            payload["html"] = html
        return self._request("POST", f"/api/inbox/{message_id}/reply-all", json=payload, auth=True)

    def forward(self, message_id: str, to: str, *, body: str | None = None, html: str | None = None) -> dict[str, Any]:
        """Forward a message to another recipient."""
        self._ensure_auth()
        payload: dict[str, Any] = {"to": to}
        if body:
            payload["body"] = body
        if html:
            payload["html"] = html
        return self._request("POST", f"/api/inbox/{message_id}/forward", json=payload, auth=True)

    # -- Threads --------------------------------------------------

    def list_threads(
        self,
        *,
        page: int = 1,
        limit: int = 50,
        labels: list[str] | None = None,
        before: str | None = None,
        after: str | None = None,
        ascending: bool = False,
    ) -> dict[str, Any]:
        """List conversation threads."""
        self._ensure_auth()
        params: dict[str, Any] = {"page": page, "limit": limit}
        if labels:
            params["labels"] = ",".join(labels)
        if before:
            params["before"] = before
        if after:
            params["after"] = after
        if ascending:
            params["ascending"] = "true"
        return self._request("GET", "/api/threads", params=params, auth=True)

    def get_thread(self, thread_id: str) -> dict[str, Any]:
        """Get a thread with all its messages."""
        self._ensure_auth()
        return self._request("GET", f"/api/threads/{thread_id}", auth=True)

    def delete_thread(self, thread_id: str, *, permanent: bool = False) -> dict[str, Any]:
        """Delete a thread (soft by default, permanent if specified)."""
        self._ensure_auth()
        params = {"permanent": "true"} if permanent else None
        return self._request("DELETE", f"/api/threads/{thread_id}", params=params, auth=True)

    # -- Drafts ---------------------------------------------------

    def list_drafts(self, *, page: int = 1, limit: int = 50) -> dict[str, Any]:
        """List all drafts."""
        self._ensure_auth()
        return self._request("GET", "/api/drafts", params={"page": page, "limit": limit}, auth=True)

    def create_draft(
        self,
        *,
        to: str | None = None,
        cc: list[str] | None = None,
        bcc: list[str] | None = None,
        reply_to: str | None = None,
        subject: str | None = None,
        body: str | None = None,
        html_body: str | None = None,
        thread_id: str | None = None,
        labels: list[str] | None = None,
    ) -> dict[str, Any]:
        """Create a new draft."""
        self._ensure_auth()
        payload: dict[str, Any] = {}
        if to is not None: payload["to"] = to
        if cc is not None: payload["cc"] = cc
        if bcc is not None: payload["bcc"] = bcc
        if reply_to is not None: payload["replyTo"] = reply_to
        if subject is not None: payload["subject"] = subject
        if body is not None: payload["body"] = body
        if html_body is not None: payload["htmlBody"] = html_body
        if thread_id is not None: payload["threadId"] = thread_id
        if labels is not None: payload["labels"] = labels
        return self._request("POST", "/api/drafts", json=payload, auth=True)

    def get_draft(self, draft_id: str) -> dict[str, Any]:
        """Get a draft by ID."""
        self._ensure_auth()
        return self._request("GET", f"/api/drafts/{draft_id}", auth=True)

    def update_draft(self, draft_id: str, **fields: Any) -> dict[str, Any]:
        """Update a draft. Pass any fields: to, cc, bcc, subject, body, htmlBody, labels."""
        self._ensure_auth()
        return self._request("PATCH", f"/api/drafts/{draft_id}", json=fields, auth=True)

    def delete_draft(self, draft_id: str) -> dict[str, Any]:
        """Delete a draft."""
        self._ensure_auth()
        return self._request("DELETE", f"/api/drafts/{draft_id}", auth=True)

    def send_draft(self, draft_id: str) -> dict[str, Any]:
        """Send a draft."""
        self._ensure_auth()
        return self._request("POST", f"/api/drafts/{draft_id}/send", auth=True)

    # -- Webhooks -------------------------------------------------

    def list_webhooks(self) -> dict[str, Any]:
        """List all webhooks."""
        self._ensure_auth()
        return self._request("GET", "/api/webhooks", auth=True)

    def create_webhook(self, url: str, *, events: list[str] | None = None) -> dict[str, Any]:
        """Create a webhook. Returns webhookId and secret."""
        self._ensure_auth()
        payload: dict[str, Any] = {"url": url}
        if events:
            payload["events"] = events
        return self._request("POST", "/api/webhooks", json=payload, auth=True)

    def get_webhook(self, webhook_id: str) -> dict[str, Any]:
        """Get a webhook by ID."""
        self._ensure_auth()
        return self._request("GET", f"/api/webhooks/{webhook_id}", auth=True)

    def update_webhook(
        self, webhook_id: str, *, url: str | None = None, events: list[str] | None = None, active: bool | None = None
    ) -> dict[str, Any]:
        """Update a webhook."""
        self._ensure_auth()
        payload: dict[str, Any] = {}
        if url is not None: payload["url"] = url
        if events is not None: payload["events"] = events
        if active is not None: payload["active"] = active
        return self._request("PATCH", f"/api/webhooks/{webhook_id}", json=payload, auth=True)

    def delete_webhook(self, webhook_id: str) -> dict[str, Any]:
        """Delete a webhook."""
        self._ensure_auth()
        return self._request("DELETE", f"/api/webhooks/{webhook_id}", auth=True)

    # -- Lists (allowlist/blocklist) ------------------------------

    def get_list(
        self, direction: str, type: str, *, page: int = 1, limit: int = 50
    ) -> dict[str, Any]:
        """Get entries from a list. direction: inbound|outbound, type: allow|block."""
        self._ensure_auth()
        return self._request(
            "GET", f"/api/lists/{direction}/{type}",
            params={"page": page, "limit": limit}, auth=True,
        )

    def add_to_list(self, direction: str, type: str, entry: str) -> dict[str, Any]:
        """Add an entry (email or domain) to a list."""
        self._ensure_auth()
        return self._request(
            "POST", f"/api/lists/{direction}/{type}",
            json={"entry": entry}, auth=True,
        )

    def remove_from_list(self, direction: str, type: str, entry: str) -> dict[str, Any]:
        """Remove an entry from a list."""
        self._ensure_auth()
        return self._request(
            "DELETE", f"/api/lists/{direction}/{type}/{quote(entry, safe='')}",
            auth=True,
        )

    # -- Metrics --------------------------------------------------

    def get_metrics(
        self,
        *,
        event: str | None = None,
        period: str | None = None,
        since: str | None = None,
        until: str | None = None,
    ) -> dict[str, Any]:
        """Get metrics. period: hour|day|week|month."""
        self._ensure_auth()
        params: dict[str, Any] = {}
        if event: params["event_types"] = event
        if period: params["period"] = period
        if since: params["start"] = since
        if until: params["end"] = until
        return self._request("GET", "/api/metrics", params=params, auth=True)

    # -- Settings -------------------------------------------------

    def get_signature(self) -> dict[str, Any]:
        """Get email signature setting."""
        self._ensure_auth()
        return self._request("GET", "/api/settings/signature", auth=True)

    def set_signature(self, signature: str | None) -> dict[str, Any]:
        """Set email signature."""
        self._ensure_auth()
        return self._request("PUT", "/api/settings/signature", json={"signature": signature}, auth=True)

    def get_forwarding(self) -> dict[str, Any]:
        """Get auto-forwarding setting."""
        self._ensure_auth()
        return self._request("GET", "/api/settings/forwarding", auth=True)

    def set_forwarding(self, forwarding_address: str | None) -> dict[str, Any]:
        """Set auto-forwarding address."""
        self._ensure_auth()
        return self._request("PUT", "/api/settings/forwarding", json={"forwardingAddress": forwarding_address}, auth=True)

    def get_auto_reply(self) -> dict[str, Any]:
        """Get auto-reply / vacation responder settings."""
        self._ensure_auth()
        return self._request("GET", "/api/settings/auto-reply", auth=True)

    def set_auto_reply(
        self,
        *,
        enabled: bool | None = None,
        subject: str | None = None,
        body: str | None = None,
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> dict[str, Any]:
        """Configure auto-reply / vacation responder."""
        self._ensure_auth()
        payload: dict[str, Any] = {}
        if enabled is not None: payload["enabled"] = enabled
        if subject is not None: payload["subject"] = subject
        if body is not None: payload["body"] = body
        if start_date is not None: payload["startDate"] = start_date
        if end_date is not None: payload["endDate"] = end_date
        return self._request("PUT", "/api/settings/auto-reply", json=payload, auth=True)

    # -- Unread Count ---------------------------------------------

    def get_unread_count(self) -> dict[str, Any]:
        """Get count of unread inbound messages."""
        self._ensure_auth()
        return self._request("GET", "/api/inbox/unread-count", auth=True)

    # -- Contacts -------------------------------------------------

    def list_contacts(self) -> dict[str, Any]:
        """List all contacts."""
        self._ensure_auth()
        return self._request("GET", "/api/contacts", auth=True)

    def create_contact(self, email: str, *, name: str | None = None, notes: str | None = None) -> dict[str, Any]:
        """Create or upsert a contact."""
        self._ensure_auth()
        payload: dict[str, Any] = {"email": email}
        if name: payload["name"] = name
        if notes: payload["notes"] = notes
        return self._request("POST", "/api/contacts", json=payload, auth=True)

    def get_contact(self, contact_id: str) -> dict[str, Any]:
        """Get a contact by ID."""
        self._ensure_auth()
        return self._request("GET", f"/api/contacts/{contact_id}", auth=True)

    def update_contact(self, contact_id: str, **fields: Any) -> dict[str, Any]:
        """Update a contact. Fields: name, email, notes."""
        self._ensure_auth()
        return self._request("PATCH", f"/api/contacts/{contact_id}", json=fields, auth=True)

    def delete_contact(self, contact_id: str) -> dict[str, Any]:
        """Delete a contact."""
        self._ensure_auth()
        return self._request("DELETE", f"/api/contacts/{contact_id}", auth=True)

    # -- Webhook Deliveries ---------------------------------------

    def get_webhook_deliveries(self, *, page: int = 1, limit: int = 50) -> dict[str, Any]:
        """Get paginated webhook delivery logs."""
        self._ensure_auth()
        return self._request("GET", "/api/webhooks/deliveries", params={"page": page, "limit": limit}, auth=True)

    # -- Verification ---------------------------------------------

    def get_links(self, message_id: str) -> dict[str, Any]:
        """Extract links from a message."""
        self._ensure_auth()
        return self._request("GET", f"/api/inbox/{message_id}/links", auth=True)

    def get_codes(self, message_id: str) -> dict[str, Any]:
        """Extract verification codes from a message."""
        self._ensure_auth()
        return self._request("GET", f"/api/inbox/{message_id}/codes", auth=True)

    def follow_link(
        self,
        *,
        message_id: str | None = None,
        link_index: int | None = None,
        url: str | None = None,
    ) -> dict[str, Any]:
        """Follow a verification link. Provide message_id+link_index or url."""
        self._ensure_auth()
        payload: dict[str, Any] = {}
        if message_id is not None:
            payload["messageId"] = message_id
        if link_index is not None:
            payload["linkIndex"] = link_index
        if url is not None:
            payload["url"] = url
        return self._request("POST", "/api/verification/follow", json=payload, auth=True)

    # -- TOTP / 2FA -----------------------------------------------

    def register_totp(
        self,
        *,
        service_name: str | None = None,
        secret: str | None = None,
        issuer: str | None = None,
        account_name: str | None = None,
        algorithm: str | None = None,
        digits: int | None = None,
        period: int | None = None,
        uri: str | None = None,
    ) -> dict[str, Any]:
        """Register a TOTP secret for a service.

        Two ways to call this::

            agent.register_totp(service_name="GitHub", secret="JBSWY3DPEHPK3PXP")
            agent.register_totp(uri="otpauth://totp/GitHub:me?secret=JBSWY3DPEHPK3PXP&issuer=GitHub")
        """
        self._ensure_auth()
        if uri is not None:
            payload: dict[str, Any] = {"uri": uri}
        else:
            if not service_name or not secret:
                raise ValueError("Provide either uri=, or both service_name= and secret=")
            payload = {"serviceName": service_name, "secret": secret}
            if issuer is not None:
                payload["issuer"] = issuer
            if account_name is not None:
                payload["accountName"] = account_name
            if algorithm is not None:
                payload["algorithm"] = algorithm
            if digits is not None:
                payload["digits"] = digits
            if period is not None:
                payload["period"] = period
        return self._request("POST", "/api/totp", json=payload, auth=True)

    def list_totp(self) -> dict[str, Any]:
        """List all stored TOTP entries. Secrets are never returned."""
        self._ensure_auth()
        return self._request("GET", "/api/totp", auth=True)

    def get_totp_code(self, totp_id: str) -> dict[str, Any]:
        """Generate the current 6-digit code for a TOTP entry, plus seconds remaining."""
        self._ensure_auth()
        return self._request("GET", f"/api/totp/{quote(totp_id, safe='')}/code", auth=True)

    def delete_totp(self, totp_id: str) -> dict[str, Any]:
        """Remove a TOTP entry."""
        self._ensure_auth()
        return self._request("DELETE", f"/api/totp/{quote(totp_id, safe='')}", auth=True)

    # -- Persona --------------------------------------------------

    def get_persona(self) -> dict[str, Any]:
        """Get the agent's persona profile."""
        self._ensure_auth()
        return self._request("GET", "/api/persona", auth=True)

    def create_persona(self, **kwargs: Any) -> dict[str, Any]:
        """Create a persona profile."""
        self._ensure_auth()
        return self._request("POST", "/api/persona", json=kwargs, auth=True)

    def update_persona(self, **kwargs: Any) -> dict[str, Any]:
        """Update the agent's persona profile."""
        self._ensure_auth()
        return self._request("PATCH", "/api/persona", json=kwargs, auth=True)

    # -- Registration Log -----------------------------------------

    def list_registrations(
        self,
        *,
        service: str | None = None,
        status: str | None = None,
        page: int = 1,
        limit: int = 50,
    ) -> dict[str, Any]:
        """List service registrations."""
        self._ensure_auth()
        params: dict[str, Any] = {"page": page, "limit": limit}
        if service:
            params["service"] = service
        if status:
            params["status"] = status
        return self._request("GET", "/api/persona/registrations", params=params, auth=True)

    def add_registration(
        self,
        *,
        service_name: str,
        service_url: str | None = None,
        username: str | None = None,
        email_used: str | None = None,
        phone_used: str | None = None,
        status: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Log a new service registration."""
        self._ensure_auth()
        payload: dict[str, Any] = {"serviceName": service_name}
        if service_url is not None:
            payload["serviceUrl"] = service_url
        if username is not None:
            payload["username"] = username
        if email_used is not None:
            payload["emailUsed"] = email_used
        if phone_used is not None:
            payload["phoneUsed"] = phone_used
        if status is not None:
            payload["status"] = status
        if metadata is not None:
            payload["metadata"] = metadata
        return self._request("POST", "/api/persona/registrations", json=payload, auth=True)

    def get_registration(self, id: str) -> dict[str, Any]:
        """Get a registration by ID."""
        self._ensure_auth()
        return self._request("GET", f"/api/persona/registrations/{id}", auth=True)

    def update_registration(self, id: str, **kwargs: Any) -> dict[str, Any]:
        """Update a registration."""
        self._ensure_auth()
        return self._request("PATCH", f"/api/persona/registrations/{id}", json=kwargs, auth=True)

    def delete_registration(self, id: str) -> dict[str, Any]:
        """Delete a registration."""
        self._ensure_auth()
        return self._request("DELETE", f"/api/persona/registrations/{id}", auth=True)

    # -- Signup Sessions -----------------------------------------

    def start_registration_session(
        self,
        *,
        service_name: str,
        service_domain: str | None = None,
        expected_channels: list[str] | None = None,
        expected_senders: list[str] | None = None,
        expected_artifact_types: list[str] | None = None,
        sender_pattern: str | None = None,
        subject_pattern: str | None = None,
        body_pattern: str | None = None,
        expires_at: str | None = None,
        use_sms_lease: bool | None = None,
        browser_state_key: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Create a signup session that correlates verification artifacts."""
        self._ensure_auth()
        payload: dict[str, Any] = {"serviceName": service_name}
        if service_domain is not None:
          payload["serviceDomain"] = service_domain
        if expected_channels is not None:
          payload["expectedChannels"] = expected_channels
        if expected_senders is not None:
          payload["expectedSenders"] = expected_senders
        if expected_artifact_types is not None:
          payload["expectedArtifactTypes"] = expected_artifact_types
        if sender_pattern is not None:
          payload["senderPattern"] = sender_pattern
        if subject_pattern is not None:
          payload["subjectPattern"] = subject_pattern
        if body_pattern is not None:
          payload["bodyPattern"] = body_pattern
        if expires_at is not None:
          payload["expiresAt"] = expires_at
        if use_sms_lease is not None:
          payload["useSmsLease"] = use_sms_lease
        if browser_state_key is not None:
          payload["browserStateKey"] = browser_state_key
        if metadata is not None:
          payload["metadata"] = metadata
        return self._request("POST", "/api/registration-sessions", json=payload, auth=True)

    def list_registration_sessions(
        self,
        *,
        status: str | None = None,
        service: str | None = None,
        page: int = 1,
        limit: int = 50,
    ) -> dict[str, Any]:
        """List signup sessions for the current agent."""
        self._ensure_auth()
        params: dict[str, Any] = {"page": page, "limit": limit}
        if status is not None:
          params["status"] = status
        if service is not None:
          params["service"] = service
        return self._request("GET", "/api/registration-sessions", params=params, auth=True)

    def get_registration_session(self, session_id: str) -> dict[str, Any]:
        """Get a signup session by ID."""
        self._ensure_auth()
        return self._request("GET", f"/api/registration-sessions/{session_id}", auth=True)

    def get_registration_artifacts(self, session_id: str) -> dict[str, Any]:
        """Get normalized artifacts attached to a signup session."""
        self._ensure_auth()
        return self._request("GET", f"/api/registration-sessions/{session_id}/artifacts", auth=True)

    def save_browser_state(
        self,
        session_id: str,
        state: dict[str, Any],
        *,
        expires_at: str | None = None,
    ) -> dict[str, Any]:
        """Persist browser continuity state for a signup session."""
        self._ensure_auth()
        payload: dict[str, Any] = {"state": state}
        if expires_at is not None:
          payload["expiresAt"] = expires_at
        return self._request("PUT", f"/api/registration-sessions/{session_id}/browser-state", json=payload, auth=True)

    def load_browser_state(self, session_id: str) -> dict[str, Any]:
        """Load saved browser continuity state for a signup session."""
        self._ensure_auth()
        return self._request("GET", f"/api/registration-sessions/{session_id}/browser-state", auth=True)

    def complete_registration_session(
        self,
        session_id: str,
        *,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Mark a signup session as completed."""
        self._ensure_auth()
        payload: dict[str, Any] = {}
        if metadata is not None:
          payload["metadata"] = metadata
        return self._request("POST", f"/api/registration-sessions/{session_id}/complete", json=payload, auth=True)

    def block_registration_session(
        self,
        session_id: str,
        *,
        reason: str,
        code: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Mark a signup session as blocked with a reason."""
        self._ensure_auth()
        payload: dict[str, Any] = {"reason": reason}
        if code is not None:
          payload["code"] = code
        if metadata is not None:
          payload["metadata"] = metadata
        return self._request("POST", f"/api/registration-sessions/{session_id}/block", json=payload, auth=True)

    # -- Vault ----------------------------------------------------

    def list_vault(self) -> dict[str, Any]:
        """List all vault entries (alias for vault_list)."""
        return self.vault_list()

    def get_vault_entry(self, key: str) -> dict[str, Any]:
        """Get a vault entry by key (alias for vault_get)."""
        return self.vault_get(key)

    def put_vault_entry(
        self,
        key: str,
        value: str,
        *,
        content_type: str | None = None,
        expires_at: str | None = None,
    ) -> dict[str, Any]:
        """Store a value in the vault (alias for vault_put)."""
        return self.vault_put(key, value, content_type=content_type, expires_at=expires_at)

    def delete_vault_entry(self, key: str) -> dict[str, Any]:
        """Delete a vault entry (alias for vault_delete)."""
        return self.vault_delete(key)

    def vault_list(self) -> dict[str, Any]:
        """List all vault entries."""
        self._ensure_auth()
        return self._request("GET", "/api/vault", auth=True)

    def vault_get(self, key: str) -> dict[str, Any]:
        """Get a vault entry by key."""
        self._ensure_auth()
        return self._request("GET", f"/api/vault/{quote(key, safe='')}", auth=True)

    def vault_put(
        self,
        key: str,
        value: str,
        *,
        content_type: str | None = None,
        expires_at: str | None = None,
    ) -> dict[str, Any]:
        """Store a value in the vault."""
        self._ensure_auth()
        payload: dict[str, Any] = {"value": value}
        if content_type is not None:
            payload["contentType"] = content_type
        if expires_at is not None:
            payload["expiresAt"] = expires_at
        return self._request("PUT", f"/api/vault/{quote(key, safe='')}", json=payload, auth=True)

    def vault_delete(self, key: str) -> dict[str, Any]:
        """Delete a vault entry."""
        self._ensure_auth()
        return self._request("DELETE", f"/api/vault/{quote(key, safe='')}", auth=True)

    # -- Web Search -----------------------------------------------

    def search(
        self,
        query: str,
        *,
        num: int | None = None,
        country: str | None = None,
        time_range: str | None = None,
    ) -> dict[str, Any]:
        """Search the web via Google. Returns titles, URLs, and snippets."""
        self._ensure_auth()
        payload: dict[str, Any] = {"query": query}
        if num is not None:
            payload["num"] = num
        if country is not None:
            payload["country"] = country
        if time_range is not None:
            payload["timeRange"] = time_range
        return self._request("POST", "/api/search", json=payload, auth=True)

    def get_search_usage(self) -> dict[str, Any]:
        """Get today's search usage and remaining quota."""
        self._ensure_auth()
        return self._request("GET", "/api/search/usage", auth=True)

    # -- File Storage ---------------------------------------------

    def store_list(
        self,
        *,
        prefix: str | None = None,
        page: int = 1,
        limit: int = 50,
    ) -> dict[str, Any]:
        """List stored files."""
        self._ensure_auth()
        params: dict[str, Any] = {"page": page, "limit": limit}
        if prefix:
            params["prefix"] = prefix
        return self._request("GET", "/api/store", params=params, auth=True)

    def store_get(self, key: str) -> dict[str, Any]:
        """Get file metadata by key."""
        self._ensure_auth()
        return self._request("GET", f"/api/store/{quote(key, safe='')}", auth=True)

    def store_download(self, key: str) -> dict[str, Any]:
        """Download file content (base64-encoded)."""
        self._ensure_auth()
        return self._request(
            "GET", f"/api/store/{quote(key, safe='')}/download", auth=True
        )

    def store_put(
        self,
        key: str,
        content: str | bytes,
        *,
        content_type: str | None = None,
        is_public: bool | None = None,
    ) -> dict[str, Any]:
        """Upload or overwrite a file.

        Pass either a ``str`` (treated as UTF-8 text) or ``bytes`` (raw binary).
        The SDK handles base64 encoding for you.
        """
        self._ensure_auth()
        payload: dict[str, Any] = {"content": _encode_content_b64(content)}
        if content_type is not None:
            payload["contentType"] = content_type
        if is_public is not None:
            payload["isPublic"] = is_public
        return self._request(
            "PUT", f"/api/store/{quote(key, safe='')}", json=payload, auth=True
        )

    def store_delete(self, key: str) -> dict[str, Any]:
        """Delete a stored file."""
        self._ensure_auth()
        return self._request(
            "DELETE", f"/api/store/{quote(key, safe='')}", auth=True
        )

    def store_set_public(self, key: str, is_public: bool) -> dict[str, Any]:
        """Toggle public URL for a file."""
        self._ensure_auth()
        return self._request(
            "PATCH",
            f"/api/store/{quote(key, safe='')}",
            json={"isPublic": is_public},
            auth=True,
        )

    def get_store_usage(self) -> dict[str, Any]:
        """Get storage usage and quota."""
        self._ensure_auth()
        return self._request("GET", "/api/store/usage", auth=True)

    # -- Cron/Scheduling ------------------------------------------

    def list_crons(self) -> dict[str, Any]:
        """List scheduled webhooks."""
        self._ensure_auth()
        return self._request("GET", "/api/crons", auth=True)

    def create_cron(
        self,
        webhook_url: str,
        cron_expr: str,
        *,
        name: str | None = None,
        timezone: str | None = None,
    ) -> dict[str, Any]:
        """Schedule a webhook on a cron expression."""
        self._ensure_auth()
        payload: dict[str, Any] = {"webhookUrl": webhook_url, "cronExpr": cron_expr}
        if name is not None:
            payload["name"] = name
        if timezone is not None:
            payload["timezone"] = timezone
        return self._request("POST", "/api/crons", json=payload, auth=True)

    def get_cron(self, cron_id: str) -> dict[str, Any]:
        """Get a single cron job."""
        self._ensure_auth()
        return self._request("GET", f"/api/crons/{cron_id}", auth=True)

    def update_cron(
        self,
        cron_id: str,
        *,
        webhook_url: str | None = None,
        cron_expr: str | None = None,
        name: str | None = None,
        active: bool | None = None,
        timezone: str | None = None,
    ) -> dict[str, Any]:
        """Update a cron job."""
        self._ensure_auth()
        payload: dict[str, Any] = {}
        if webhook_url is not None:
            payload["webhookUrl"] = webhook_url
        if cron_expr is not None:
            payload["cronExpr"] = cron_expr
        if name is not None:
            payload["name"] = name
        if active is not None:
            payload["active"] = active
        if timezone is not None:
            payload["timezone"] = timezone
        return self._request(
            "PATCH", f"/api/crons/{cron_id}", json=payload, auth=True
        )

    def delete_cron(self, cron_id: str) -> dict[str, Any]:
        """Delete a cron job."""
        self._ensure_auth()
        return self._request("DELETE", f"/api/crons/{cron_id}", auth=True)

    # -- Agent Pages ----------------------------------------------

    def create_page(self, slug: str, *, title: str | None = None, description: str | None = None) -> dict[str, Any]:
        """Create an agent page with the given slug."""
        self._ensure_auth()
        payload: dict[str, Any] = {"slug": slug}
        if title is not None:
            payload["title"] = title
        if description is not None:
            payload["description"] = description
        return self._request("POST", "/api/pages", json=payload, auth=True)

    def list_pages(self) -> dict[str, Any]:
        """List agent's pages."""
        self._ensure_auth()
        return self._request("GET", "/api/pages", auth=True)

    def get_page(self, slug: str) -> dict[str, Any]:
        """Get page details by slug."""
        self._ensure_auth()
        return self._request("GET", f"/api/pages/{slug}", auth=True)

    def update_page(self, slug: str, **kwargs: Any) -> dict[str, Any]:
        """Update a page. Fields: title, description, published."""
        self._ensure_auth()
        return self._request("PATCH", f"/api/pages/{slug}", json=kwargs, auth=True)

    def delete_page(self, slug: str) -> dict[str, Any]:
        """Delete a page and all its files."""
        self._ensure_auth()
        return self._request("DELETE", f"/api/pages/{slug}", auth=True)

    def upload_page_file(
        self,
        slug: str,
        path: str,
        content: str | bytes,
        *,
        content_type: str = "text/html",
    ) -> dict[str, Any]:
        """Upload a file to a page.

        Pass either a ``str`` (treated as UTF-8 text) or ``bytes`` (raw binary).
        The SDK handles base64 encoding for you.
        """
        self._ensure_auth()
        return self._request(
            "PUT", f"/api/pages/{slug}/files/{path}",
            json={"content": _encode_content_b64(content), "contentType": content_type},
            auth=True,
        )

    def list_page_files(self, slug: str) -> dict[str, Any]:
        """List files in a page."""
        self._ensure_auth()
        return self._request("GET", f"/api/pages/{slug}/files", auth=True)

    def delete_page_file(self, slug: str, path: str) -> dict[str, Any]:
        """Delete a file from a page."""
        self._ensure_auth()
        return self._request("DELETE", f"/api/pages/{slug}/files/{path}", auth=True)

    # -- Internals ------------------------------------------------

    def _ensure_auth(self) -> None:
        if not self._token or time.time() >= self._token_expires_at - 60:
            self.authenticate()

    def _request(
        self,
        method: str,
        path: str,
        *,
        json: dict | None = None,
        params: dict | None = None,
        auth: bool = False,
    ) -> dict[str, Any]:
        headers: dict[str, str] = {}
        if auth and self._token:
            headers["Authorization"] = f"Bearer {self._token}"

        resp = self._client.request(
            method, path, json=json, params=params, headers=headers
        )

        if resp.status_code >= 400:
            data = resp.json()
            raise KeyIDError(data.get("error", f"HTTP {resp.status_code}"), resp.status_code)

        return resp.json()

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> KeyID:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()


class KeyIDError(Exception):
    def __init__(self, message: str, status: int):
        super().__init__(message)
        self.status = status
