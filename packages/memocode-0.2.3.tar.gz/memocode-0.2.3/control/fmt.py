"""
Terminal color helpers. ANSI only, zero dependencies.

3 accent colors:
  cyan   → info: [plan], [project], [tip], [cleanup], startup
  yellow → warning: [safety], [dry-run] prompt tag
  dim    → noise: [intent], [backup], secondary details

Semantic:
  green  → ✓ success
  red    → ✗ failure / BLOCKED
"""
import os
import sys

# Disable color if not a TTY or NO_COLOR is set
_USE_COLOR = sys.stdout.isatty() and os.environ.get("NO_COLOR") is None

_R   = "\033[0m"
_DIM = "\033[2m"
_CYN = "\033[38;2;90;200;250m"   # Apple Teal   #5AC8FA
_YLW = "\033[38;2;255;214;10m"   # Apple Yellow #FFD60A
_GRN = "\033[38;2;52;199;89m"    # Apple Green  #34C759
_RED = "\033[38;2;255;59;48m"    # Apple Red    #FF3B30
_BLD = "\033[1m"


def _c(code: str, text: str) -> str:
    return f"{code}{text}{_R}" if _USE_COLOR else text


def dim(text: str) -> str:   return _c(_DIM, text)
def cyan(text: str) -> str:  return _c(_CYN, text)
def yellow(text: str) -> str: return _c(_YLW, text)
def green(text: str) -> str: return _c(_GRN, text)
def red(text: str) -> str:   return _c(_RED, text)
def bold(text: str) -> str:  return _c(_BLD, text)


# ── Semantic print helpers ────────────────────────────────────────────────────

def p_dim(msg: str):
    """Dim: [intent], [backup], verbose secondary info."""
    print(dim(msg))


def p_info(msg: str):
    """Cyan: [plan], [project], [tip], [cleanup], startup."""
    print(cyan(msg))


def p_warn(msg: str):
    """Yellow: [safety], warnings."""
    print(yellow(msg))


def p_ok(msg: str):
    """Green: ✓ task success."""
    print(green(msg))


def p_err(msg: str):
    """Red: ✗ task failure, BLOCKED."""
    print(red(msg))


def fmt_task_line(icon: str, task_id: int, description: str, output: str) -> str:
    """Format a single task result line with color."""
    if icon == "✓":
        header = green(f"✓ Task {task_id}: {description}")
    else:
        header = red(f"✗ Task {task_id}: {description}")
    lines = [header]
    if output and output not in ("(no output)", ""):
        lines.append(dim(f"   {output[:400]}"))
    return "\n".join(lines)


def fmt_prompt_tag(project: str, work_dir: str | None, dry_run: bool) -> str:
    """Color the REPL prompt tag."""
    if work_dir:
        import os as _os
        home = _os.path.expanduser("~")
        short = work_dir.replace(home, "~", 1)
        tag = cyan(project) + dim(f" | {short}")
        tag = f"[{tag}]"
    else:
        tag = f"[{cyan(project)}]"
    if dry_run:
        tag += f" [{yellow('dry-run')}]"
    return tag
