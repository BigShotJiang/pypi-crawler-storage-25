"""
Two-path compression strategy:
1. LLM extreme summarization (1-3 sentences, conclusions only)
2. Classical Chinese (文言文) — variant for pure Chinese narrative content

Compatible with any OpenAI-compatible API.
"""

import re
from typing import Any

from openai import OpenAI


# ---------------------------------------------------------------------------
# Unified LLM completion (OpenAI-compatible or Anthropic native)
# ---------------------------------------------------------------------------

def _llm_complete(
    messages: list[dict],
    max_tokens: int,
    api_key: str,
    model: str,
    base_url: str | None = None,
    extra_body: dict | None = None,
    provider: str = "openai",
) -> str:
    if provider == "anthropic":
        import anthropic
        system = None
        filtered = []
        for m in messages:
            if m["role"] == "system":
                system = m["content"]
            else:
                filtered.append(m)
        kwargs: dict = dict(model=model, max_tokens=max_tokens, messages=filtered)
        if system:
            kwargs["system"] = system
        client = anthropic.Anthropic(api_key=api_key, base_url=base_url)
        response = client.messages.create(**kwargs)
        return "".join(b.text for b in response.content if b.type == "text").strip()
    else:
        client = OpenAI(api_key=api_key, base_url=base_url)
        kwargs = dict(model=model, messages=messages, max_tokens=max_tokens)
        if extra_body:
            kwargs["extra_body"] = extra_body
        response = client.chat.completions.create(**kwargs)
        return (response.choices[0].message.content or "").strip()


# ---------------------------------------------------------------------------
# Language detection
# ---------------------------------------------------------------------------

def _is_chinese(text: str, threshold: float = 0.3) -> bool:
    """
    Return True if Chinese characters make up >= threshold of non-whitespace chars.
    threshold=0.3 catches mixed Chinese+code conversations while excluding pure English.
    """
    chinese_chars = len(re.findall(r"[\u4e00-\u9fff]", text))
    total_chars = len(text.replace(" ", "").replace("\n", ""))
    return total_chars > 0 and (chinese_chars / total_chars) >= threshold


def _is_chinese_narrative(text: str) -> bool:
    """
    Stricter check: primarily Chinese narrative content with no technical markers.
    Used to route to 文言文 compression path.
    """
    chinese_chars = len(re.findall(r"[\u4e00-\u9fff]", text))
    total_chars = len(text.replace(" ", "").replace("\n", ""))
    if total_chars == 0:
        return False
    chinese_ratio = chinese_chars / total_chars

    technical_markers = [
        r"```", r"\{.*\}", r"def ", r"import ", r"http", r"API", r"JSON",
        r"\bclass\b", r"function", r"<[^>]+>",
    ]
    has_technical = any(re.search(p, text, re.IGNORECASE) for p in technical_markers)

    return chinese_ratio > 0.6 and not has_technical


# ---------------------------------------------------------------------------
# Path 1: LLM extreme summarization (conclusions only, 1-3 sentences)
# ---------------------------------------------------------------------------

_SUMMARY_PROMPT = """You are a conversation summarization assistant. Compress the following conversation into 1-3 sentences.
Rules:
- Output only conclusions, decisions, preferences, and key facts
- Omit reasoning processes and explanations
- Omit small talk and transitional content
- Use concise declarative sentences
- Do not add prefixes like "Summary:"

Conversation:
{text}

Summary (1-3 sentences):"""

_SUMMARY_PROMPT_ZH = """你是一个对话摘要助手。请将以下对话内容压缩为1-3句话。
规则：
- 只输出结论、决策、偏好、关键事实
- 忽略推理过程和解释
- 忽略闲聊和过渡性内容
- 用简洁的陈述句
- 不要加前缀如"总结："

对话内容：
{text}

摘要（1-3句）："""


_SESSION_CONTEXT_PROMPT = """You are a conversation summarization assistant. Compress the following conversation into a structured summary for restoring context in subsequent conversations.

Rules:
- Preserve all important details: topics, decisions, code/technical solutions, user preferences, specific data
- Use concise bullet points, no long paragraphs
- Output only the following structure, omit sections with no content:
  [Topics] Main topics and tasks covered
  [Decisions/Conclusions] Confirmed plans, choices, conclusions
  [Progress] What was completed, current stage
  [Pending] Unresolved issues, next steps
  [Key Details] Important technical details, code snippets, specific values, specific information mentioned by the user
- Omit small talk and transitional content
- Goal: allow the model to seamlessly continue the conversation after reading the summary

Conversation:
{text}

Structured summary:"""

_SESSION_CONTEXT_PROMPT_ZH = """你是一个对话摘要助手。请将以下对话内容压缩为结构化摘要，用于后续对话的上下文恢复。

规则：
- 保留所有重要细节：话题、决策、代码/技术方案、用户偏好、具体数据
- 用简洁要点，不要长段落
- 只输出以下结构，没有内容的section直接省略：
  【话题】涉及的主要话题和任务
  【决策/结论】已确定的方案、选择、结论
  【进展】完成了什么、进行到哪一步
  【待解决】未解决的问题、下一步计划
  【关键细节】重要的技术细节、代码片段、具体数值、用户提到的特定信息
- 忽略闲聊和过渡性内容
- 目标：让模型读完摘要后能无缝继续对话，不感到失忆

对话内容：
{text}

结构化摘要："""


def compress_llm_summary(
    text: str,
    api_key: str,
    model: str = "gpt-4o-mini",
    base_url: str | None = None,
    extra_body: dict | None = None,
    provider: str = "openai",
) -> str:
    """
    LLM extreme summarization.
    Returns 1-3 sentences capturing only conclusions/decisions/preferences.
    Prompt language is auto-selected based on content language.
    """
    if not text.strip():
        return text

    prompt = _SUMMARY_PROMPT_ZH if _is_chinese(text) else _SUMMARY_PROMPT
    return _llm_complete(
        [{"role": "user", "content": prompt.format(text=text)}],
        200, api_key, model, base_url, extra_body, provider,
    )


# ---------------------------------------------------------------------------
# Path 2: Classical Chinese (文言文) compression for pure Chinese narrative
# ---------------------------------------------------------------------------

_WENYAN_PROMPT = """请将以下现代中文对话内容转写为简洁的文言文。
规则：
- 保留核心信息，去除冗余
- 使用文言文语法和词汇
- 不超过原文字数的50%
- 只输出文言文，不要解释

原文：
{text}

文言文："""


def compress_wenyan(
    text: str,
    api_key: str,
    model: str = "gpt-4o-mini",
    base_url: str | None = None,
    extra_body: dict | None = None,
    provider: str = "openai",
) -> str:
    """
    Classical Chinese compression for pure Chinese narrative.
    ~50% token reduction. Only use when _is_chinese_narrative() returns True.
    """
    if not text.strip():
        return text

    return _llm_complete(
        [{"role": "user", "content": _WENYAN_PROMPT.format(text=text)}],
        500, api_key, model, base_url, extra_body, provider,
    )


# ---------------------------------------------------------------------------
# Unified compressor interface
# ---------------------------------------------------------------------------

def compress_session_context(
    text: str,
    api_key: str,
    model: str = "gpt-4o-mini",
    base_url: str | None = None,
    extra_body: dict | None = None,
    provider: str = "openai",
) -> str:
    """
    Structured summary for in-session compression events.
    Preserves topics, decisions, progress, pending issues, key details.
    Used by _compress_old_turns — must be rich enough to restore continuity.
    Prompt language is auto-selected based on content language.

    max_tokens=800 scales well for typical compression inputs.
    """
    if not text.strip():
        return text

    prompt = _SESSION_CONTEXT_PROMPT_ZH if _is_chinese(text) else _SESSION_CONTEXT_PROMPT
    return _llm_complete(
        [{"role": "user", "content": prompt.format(text=text)}],
        800, api_key, model, base_url, extra_body, provider,
    )


class Compressor:
    """
    Compression interface. Two paths:
      - compress_for_session_context(): structured summary for in-session history (rich, ~800 tokens)
      - compress_for_recent_memory(): extreme summary for cross-session injection (1-3 sentences)
      - compress_async(): auto-selects LLM summary or 文言文 by content type
    Prompt language is automatically selected based on content language.
    """

    def __init__(
        self,
        api_key: str,
        model: str = "gpt-4o-mini",
        base_url: str | None = None,
        extra_body: dict | None = None,
        provider: str = "openai",
    ):
        self.api_key = api_key
        self.model = model
        self.base_url = base_url
        self.extra_body = extra_body
        self.provider = provider

    def compress_async(self, text: str) -> str:
        """Choose between 文言文 and LLM summary based on content type."""
        if _is_chinese_narrative(text):
            return compress_wenyan(text, self.api_key, self.model, self.base_url, self.extra_body, self.provider)
        return compress_llm_summary(text, self.api_key, self.model, self.base_url, self.extra_body, self.provider)

    def compress_for_recent_memory(self, text: str) -> str:
        """
        Aggressive compression for cross-session recent_memory injection.
        Returns 1-3 sentence conclusion only (target ~30% of original size).
        """
        return compress_llm_summary(text, self.api_key, self.model, self.base_url, self.extra_body, self.provider)

    def compress_for_session_context(self, text: str) -> str:
        """
        Structured compression for in-session _compress_old_turns events.
        Preserves enough detail for seamless same-session continuity.
        """
        return compress_session_context(text, self.api_key, self.model, self.base_url, self.extra_body, self.provider)
