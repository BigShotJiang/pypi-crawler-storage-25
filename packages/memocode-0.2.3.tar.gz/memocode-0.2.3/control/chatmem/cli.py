"""
chatmem CLI

Usage:
    chatmem init               # generate config template in current directory
    chatmem init --global      # generate config in ~/.chatmem/config.json
    chatmem config             # show resolved config path and content
    chatmem serve              # start OpenAI-compatible proxy server (default: 127.0.0.1:12434)
    chatmem serve --port 8080
"""

import argparse
import json
import os
import sys
from pathlib import Path

_TEMPLATE = {
    "llm": {
        "model": "gpt-4o-mini",
        "base_url": None,
        "context_window": 128000,
        "compress_model": None,
        "extra_body": None,
        "api_key": None,
        "api_key_env": "OPENAI_API_KEY",
    },
    "dimensions": {
        "identity":      {"label": "Who I am",           "stability": 50.0},
        "values":        {"label": "What I believe",     "stability": 40.0},
        "goals":         {"label": "What I want",        "stability": 30.0},
        "preferences":   {"label": "Likes / dislikes",   "stability": 25.0},
        "capabilities":  {"label": "What I can do",      "stability": 30.0},
        "emotional":     {"label": "How I react",        "stability": 20.0},
        "autobiography": {"label": "Key experiences",    "stability": 35.0},
    },
}

_GLOBAL_CONFIG = Path.home() / ".chatmem" / "config.json"
_LOCAL_CONFIG = Path("chatmem.json")


def _write_config(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        print(f"Already exists: {path}  (not overwritten)")
        return
    path.write_text(json.dumps(_TEMPLATE, indent=2, ensure_ascii=False))
    print(f"Created: {path}")
    print("Edit it, then load with:  ContextConfig.from_json(str(path))")
    print("Or set env var:           CHATMEM_CONFIG=/path/to/config.json")


def cmd_init(args):
    path = _GLOBAL_CONFIG if args.global_ else _LOCAL_CONFIG
    _write_config(path)


def cmd_config(_args):
    resolved = resolve_config_path()
    if resolved is None:
        print("No config file found.")
        print(f"  Local:  {_LOCAL_CONFIG}")
        print(f"  Global: {_GLOBAL_CONFIG}")
        print("Run `chatmem init` to create one.")
        return
    print(f"Config: {resolved}")
    print(resolved.read_text())


def resolve_config_path() -> Path | None:
    """
    Search order:
      1. $CHATMEM_CONFIG env var
      2. ./chatmem.json  (local project config)
      3. ~/.chatmem/config.json  (global user config)
    """
    env = os.environ.get("CHATMEM_CONFIG")
    if env:
        p = Path(env)
        if p.exists():
            return p
    if _LOCAL_CONFIG.exists():
        return _LOCAL_CONFIG
    if _GLOBAL_CONFIG.exists():
        return _GLOBAL_CONFIG
    return None


def cmd_serve(args):
    from chatmem.server import run_server
    run_server(
        config_path=args.config,
        db_path=args.db,
        host=args.host,
        port=args.port,
        log_level=args.log_level.lower(),
    )


def main():
    parser = argparse.ArgumentParser(prog="chatmem")
    sub = parser.add_subparsers(dest="command")

    p_init = sub.add_parser("init", help="Create a config template")
    p_init.add_argument("--global", dest="global_", action="store_true",
                        help=f"Write to {_GLOBAL_CONFIG} instead of ./chatmem.json")

    sub.add_parser("config", help="Show resolved config path and content")

    p_serve = sub.add_parser("serve", help="Start OpenAI-compatible proxy server")
    p_serve.add_argument("--config", metavar="PATH", default=None,
                         help="Path to chatmem config JSON (auto-discovers if omitted)")
    p_serve.add_argument("--db", metavar="PATH", default="chatmem.db",
                         help="SQLite DB path (default: chatmem.db)")
    p_serve.add_argument("--host", default="127.0.0.1",
                         help="Bind host (default: 127.0.0.1)")
    p_serve.add_argument("--port", type=int, default=12434,
                         help="Bind port (default: 12434)")
    p_serve.add_argument("--log-level", default="WARNING",
                         choices=["DEBUG", "INFO", "WARNING", "ERROR"])

    args = parser.parse_args()
    if args.command == "init":
        cmd_init(args)
    elif args.command == "config":
        cmd_config(args)
    elif args.command == "serve":
        cmd_serve(args)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
