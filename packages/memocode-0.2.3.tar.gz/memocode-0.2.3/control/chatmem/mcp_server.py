"""
chatmem MCP server

Exposes chatmem as an MCP tool server for agents (OpenClaw, etc.).
The ContextManager is initialized once and lives for the server process lifetime.

Tools:
  chat(message, system?)  — send a user message, get assistant reply with persistent memory
  remember(key, value, dimension?)  — manually write to core memory
  end_session()  — save session summary and reset history

Usage:
  chatmem-mcp                        # auto-discovers config
  chatmem-mcp --config path/to.json  # explicit config path
  chatmem-mcp --db chatmem.db        # explicit DB path

OpenClaw / MCP client config:
  {
    "mcpServers": {
      "chatmem": {
        "command": "chatmem-mcp",
        "args": []
      }
    }
  }
"""

import argparse
import logging
import sys

from mcp.server.fastmcp import FastMCP

logger = logging.getLogger("chatmem.mcp")

mcp = FastMCP(
    "chatmem",
    instructions=(
        "Persistent memory layer for conversations. "
        "Call `chat` for every user-facing exchange to maintain memory across sessions. "
        "Call `end_session` when the conversation ends."
    ),
)

# ContextManager is initialized lazily on first tool call
_cm = None


def _get_cm():
    global _cm
    if _cm is None:
        raise RuntimeError(
            "ContextManager not initialized. "
            "This is a bug — _init_cm() should have been called at startup."
        )
    return _cm


def _init_cm(config_path: str | None, db_path: str):
    global _cm
    from chatmem import ContextManager, ContextConfig

    config = ContextConfig.from_json(config_path)
    _cm = ContextManager.create(config=config, db_path=db_path)
    logger.info("[mcp] ContextManager ready  model=%s  db=%s", _cm.model, db_path)


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------

@mcp.tool()
def chat(message: str, system: str = "") -> str:
    """
    Send a user message and get an assistant reply.
    Memory (core memory, recent sessions, current history) is managed automatically.

    Args:
        message: The user's message.
        system:  Optional system prompt. If omitted, uses the previous session's prompt.
    """
    cm = _get_cm()
    messages = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": message})

    response = cm.chat(messages)
    return response.choices[0].message.content or ""


@mcp.tool()
def remember(key: str, value: str, dimension: str = "preferences") -> str:
    """
    Manually write a fact to core memory.

    Args:
        key:       A short identifier (e.g. "preferred_language").
        value:     The value to store (e.g. "Python").
        dimension: Memory dimension — one of: identity, values, goals,
                   preferences, capabilities, emotional, autobiography.
    """
    _get_cm().remember(key, value, dimension=dimension)
    return f"Remembered: {key} = {value!r} (dimension={dimension})"


@mcp.tool()
def end_session() -> str:
    """
    End the current session: saves a summary to recent memory and resets history.
    Call this when the user's conversation is finished.
    """
    _get_cm().end_session()
    return "Session ended. Summary saved to recent memory."


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        prog="chatmem-mcp",
        description="chatmem MCP server — exposes persistent memory as MCP tools",
    )
    parser.add_argument(
        "--config", metavar="PATH", default=None,
        help="Path to chatmem config JSON. Auto-discovers if omitted.",
    )
    parser.add_argument(
        "--db", metavar="PATH", default="chatmem.db",
        help="SQLite DB path (default: chatmem.db in working directory)",
    )
    parser.add_argument(
        "--log-level", default="WARNING",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
    )
    args = parser.parse_args()

    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s %(name)s %(levelname)s %(message)s",
        stream=sys.stderr,
    )

    try:
        _init_cm(args.config, args.db)
    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
