"""
chatmem HTTP proxy server

Implements an OpenAI-compatible /v1/chat/completions endpoint.
All requests are enriched with chatmem memory before being forwarded to the real API.

Usage:
    chatmem serve                        # default: 127.0.0.1:12434
    chatmem serve --port 8080
    chatmem serve --host 0.0.0.0 --port 8080
    chatmem serve --config path/to.json --db chatmem.db

Agent configuration (any OpenAI-compatible client):
    base_url = "http://127.0.0.1:12434/v1"
    api_key  = "any-value"   # not checked, forwarded to real API

Tool calls:
    Requests with tools/function_calling are forwarded correctly.
    Tool call turns (finish_reason=tool_calls) are not recorded to history
    to avoid orphaned messages; only complete user→assistant exchanges are recorded.
"""

import json
import logging
import sys
from typing import Any

logger = logging.getLogger("chatmem.server")

_cm = None


def _get_cm():
    if _cm is None:
        raise RuntimeError("ContextManager not initialized.")
    return _cm


def _init_cm(config_path: str | None, db_path: str):
    global _cm
    from chatmem import ContextManager, ContextConfig
    config = ContextConfig.from_json(config_path)
    _cm = ContextManager.create(config=config, db_path=db_path)
    logger.info("[serve] ready  model=%s  db=%s", _cm.model, db_path)


def _is_tool_call_response(response_data: dict) -> bool:
    """Returns True if the response is a tool_calls turn (not a final text reply)."""
    try:
        return response_data["choices"][0].get("finish_reason") == "tool_calls"
    except (KeyError, IndexError):
        return False


def create_app(config_path: str | None = None, db_path: str = "chatmem.db"):
    try:
        from fastapi import FastAPI, Request
        from fastapi.responses import JSONResponse, StreamingResponse
    except ImportError:
        print(
            "Error: 'serve' requires fastapi and uvicorn.\n"
            "Install with:  pip install 'chatmem[serve]'",
            file=sys.stderr,
        )
        sys.exit(1)

    _init_cm(config_path, db_path)
    cm = _get_cm()

    app = FastAPI(title="chatmem proxy", version="1.0")

    @app.get("/v1/models")
    async def list_models():
        """Minimal models endpoint so clients don't error on discovery."""
        return JSONResponse({
            "object": "list",
            "data": [{"id": cm.model, "object": "model", "owned_by": "chatmem"}],
        })

    @app.post("/v1/chat/completions")
    async def chat_completions(request: Request):
        body = await request.json()
        messages: list[dict] = body.get("messages", [])

        # Standard OpenAI chat/completions params — everything else is dropped
        # (provider-specific params like 'thinking' belong in chatmem config extra_body)
        _OPENAI_PARAMS = {
            "stream", "temperature", "top_p", "max_tokens", "max_completion_tokens",
            "n", "stop", "presence_penalty", "frequency_penalty", "logit_bias",
            "user", "seed", "tools", "tool_choice", "parallel_tool_calls",
            "response_format", "logprobs", "top_logprobs", "extra_body",
        }
        excluded = set(cm._excluded_params or [])
        kwargs: dict[str, Any] = {
            k: v for k, v in body.items()
            if k in _OPENAI_PARAMS and k not in excluded
        }

        stream = kwargs.get("stream", False)

        if stream:
            # Stream: yield SSE chunks, collect assistant text for _post_turn
            def _generate():
                collected = []
                is_tool_call = False
                try:
                    for chunk in cm.chat(messages, **kwargs):
                        chunk_dict = chunk.model_dump()
                        # Detect tool_call finish
                        if chunk_dict.get("choices"):
                            finish = chunk_dict["choices"][0].get("finish_reason")
                            if finish == "tool_calls":
                                is_tool_call = True
                            delta_content = chunk_dict["choices"][0].get("delta", {}).get("content")
                            if delta_content:
                                collected.append(delta_content)
                        yield f"data: {json.dumps(chunk_dict)}\n\n"
                except Exception as e:
                    logger.error("[serve] stream error: %s", e)
                    yield f"data: {json.dumps({'error': str(e)})}\n\n"
                finally:
                    yield "data: [DONE]\n\n"

            return StreamingResponse(_generate(), media_type="text/event-stream")

        else:
            # Non-streaming
            response = cm.chat(messages, **kwargs)
            response_dict = response.model_dump()

            # If this was a tool_call turn, undo the _post_turn history entry
            # to prevent an orphaned user message without a matching assistant reply
            if _is_tool_call_response(response_dict):
                _undo_last_user_entry(cm)

            return JSONResponse(response_dict)

    return app


def _undo_last_user_entry(cm):
    """
    Remove the last user message from history when the LLM responded with tool_calls
    (content=None). The assistant entry was not added (content was empty), so only
    the user entry needs to be removed to keep history consistent.
    """
    try:
        if cm._history and cm._history[-1]["role"] == "user":
            cm._history.pop()
            cm._turn_count = max(0, cm._turn_count - 1)
            cm._persisted_seq = min(cm._persisted_seq, len(cm._history))
    except Exception:
        pass


def run_server(
    config_path: str | None = None,
    db_path: str = "chatmem.db",
    host: str = "127.0.0.1",
    port: int = 12434,
    log_level: str = "warning",
):
    try:
        import uvicorn
    except ImportError:
        print(
            "Error: 'serve' requires uvicorn.\n"
            "Install with:  pip install 'chatmem[serve]'",
            file=sys.stderr,
        )
        sys.exit(1)

    app = create_app(config_path=config_path, db_path=db_path)
    print(f"chatmem proxy → http://{host}:{port}/v1", file=sys.stderr)
    print(f"Set agent base_url = \"http://{host}:{port}/v1\"", file=sys.stderr)
    uvicorn.run(app, host=host, port=port, log_level=log_level)
