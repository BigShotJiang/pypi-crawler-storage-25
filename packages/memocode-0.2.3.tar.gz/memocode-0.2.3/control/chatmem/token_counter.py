"""
Token counting for LLM messages.
Used internally to measure context size and trigger compression.
"""

import tiktoken
from typing import Any


# Model to tiktoken encoding mapping.
# Unknown models fall back to cl100k_base.
_ENCODING_MAP = {
    # OpenAI
    "gpt-4o":              "o200k_base",
    "gpt-4o-mini":         "o200k_base",
    "gpt-4-turbo":         "cl100k_base",
    "gpt-4":               "cl100k_base",
    "gpt-3.5-turbo":       "cl100k_base",
    # DeepSeek (cl100k_base compatible)
    "deepseek-chat":       "cl100k_base",
    "deepseek-reasoner":   "cl100k_base",
    # Moonshot / Kimi (cl100k_base compatible)
    "kimi-k2.5":           "cl100k_base",
    "moonshot-v1-8k":      "cl100k_base",
    "moonshot-v1-32k":     "cl100k_base",
    "moonshot-v1-128k":    "cl100k_base",
}

_DEFAULT_ENCODING = "cl100k_base"


def _get_encoding(model: str) -> tiktoken.Encoding:
    encoding_name = _ENCODING_MAP.get(model, _DEFAULT_ENCODING)
    return tiktoken.get_encoding(encoding_name)


def count_tokens(text: str, model: str = "gpt-4o-mini") -> int:
    """Count tokens in a plain text string."""
    enc = _get_encoding(model)
    return len(enc.encode(text))


def count_message_tokens(message: dict[str, Any], model: str = "gpt-4o-mini") -> int:
    """Count tokens for a single message dict. Includes per-message overhead (~4 tokens)."""
    enc = _get_encoding(model)
    content = message.get("content", "")
    if isinstance(content, list):
        text = " ".join(
            part.get("text", "") for part in content if isinstance(part, dict)
        )
    else:
        text = str(content)
    return len(enc.encode(text)) + 4  # role + content separators


def count_messages_tokens(
    messages: list[dict[str, Any]], model: str = "gpt-4o-mini"
) -> int:
    """Count total tokens for a list of messages (full conversation)."""
    total = sum(count_message_tokens(m, model) for m in messages)
    total += 3  # conversation-level overhead
    return total
