"""
Core memory: persistent personality/role/user traits.
Structure: 7-dimension key-value store, each dimension has its own stability profile.
Hot-loaded + Prompt Cache eligible (static prefix).
Updated via: (1) user explicit trigger, (2) async LLM judge (every 5 turns).
Conflicts resolved by forgetting mechanism (interference + decay).

Dimensions and default stability:
  identity      → Who I am         (stability=50, rarely changes)
  values        → What I believe   (stability=40)
  goals         → What I want      (stability=30)
  preferences   → Likes/Dislikes   (stability=25)
  capabilities  → What I can do    (stability=30)
  emotional     → How I react      (stability=20)
  autobiography → Key experiences  (stability=35)
"""

import json
import sqlite3
import time
from typing import Any

from ..config import ContextConfig, DEFAULT_DIMENSIONS, DimensionConfig
from ..compressor import _is_chinese, _llm_complete


def _build_judge_prompt(dimensions: dict[str, DimensionConfig]) -> str:
    dim_lines = "\n".join(
        f"- {name}: {cfg.label}" for name, cfg in dimensions.items()
    )
    dim_names = ", ".join(f'"{name}"' for name in dimensions)
    return f"""You are a memory assistant. Analyze the following conversation and determine if there is core information worth remembering long-term.

Core memory dimensions:
{dim_lines}

Exclude: one-time questions, temporary states, reasoning processes.

Conversation:
{{text}}

If there is information worth remembering, return a JSON array (each item contains key, value, dimension; dimension must be one of {dim_names}):
[{{"key": "...", "value": "...", "dimension": "..."}}]
If nothing found, return an empty array: []

Output JSON only, no explanations:"""


def _build_judge_prompt_zh(dimensions: dict[str, DimensionConfig]) -> str:
    dim_lines = "\n".join(
        f"- {name}: {cfg.label}" for name, cfg in dimensions.items()
    )
    dim_names = ", ".join(f'"{name}"' for name in dimensions)
    return f"""你是一个记忆助手。分析以下对话，判断是否有值得长期记住的核心信息。

核心信息维度：
{dim_lines}

不包括：一次性问题、临时状态、推理过程。

对话内容：
{{text}}

如果有值得记住的信息，以JSON数组格式返回（每项包含key、value、dimension，dimension必须是 {dim_names} 之一）：
[{{"key": "...", "value": "...", "dimension": "..."}}]
如果没有，返回空数组：[]

只输出JSON，不要解释："""


class CoreMemory:
    """
    Key-value store for persistent user traits and agent persona.
    Entries: [{key, value, stability, score, created_at}]
    """

    def __init__(
        self,
        db_path: str,
        api_key: str,
        model: str,
        base_url: str | None = None,
        dimensions: dict[str, DimensionConfig] | None = None,
        extra_body: dict | None = None,
        provider: str = "openai",
    ):
        self.db_path = db_path
        self.api_key = api_key
        self.model = model
        self.base_url = base_url
        self.extra_body = extra_body
        self.provider = provider
        self.dimensions = dimensions or dict(DEFAULT_DIMENSIONS)
        self._judge_prompt_en = _build_judge_prompt(self.dimensions)
        self._judge_prompt_zh = _build_judge_prompt_zh(self.dimensions)
        self._init_db()

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self):
        with self._conn() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS core_memory (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    key TEXT NOT NULL UNIQUE,
                    value TEXT NOT NULL,
                    dimension TEXT NOT NULL DEFAULT 'preferences',
                    stability REAL DEFAULT 25.0,
                    score REAL DEFAULT 1.0,
                    created_at REAL NOT NULL,
                    updated_at REAL NOT NULL
                )
            """)
            try:
                conn.execute("ALTER TABLE core_memory ADD COLUMN dimension TEXT NOT NULL DEFAULT 'preferences'")
            except Exception:
                pass

    # ------------------------------------------------------------------
    # Write
    # ------------------------------------------------------------------

    def set(self, key: str, value: str, dimension: str = "preferences", stability: float | None = None):
        """
        Write or update a core memory entry.
        Stability defaults to the dimension's profile if not specified.
        """
        dim_stability = self.dimensions[dimension].stability if dimension in self.dimensions else 25.0
        effective_stability = stability if stability is not None else dim_stability
        now = time.time()
        with self._conn() as conn:
            conn.execute(
                """INSERT INTO core_memory (key, value, dimension, stability, score, created_at, updated_at)
                   VALUES (?, ?, ?, ?, 1.0, ?, ?)
                   ON CONFLICT(key) DO UPDATE SET
                       value = excluded.value,
                       dimension = excluded.dimension,
                       stability = excluded.stability,
                       score = 1.0,
                       updated_at = excluded.updated_at""",
                (key, value, dimension, effective_stability, now, now),
            )

    def judge_and_update(self, conversation_text: str) -> list[dict]:
        """
        Async LLM judge: extract core memory candidates from recent conversation.
        Returns list of {key, value} dicts that were written.
        """
        judge_prompt = self._judge_prompt_zh if _is_chinese(conversation_text) else self._judge_prompt_en
        raw = _llm_complete(
            [{"role": "user", "content": judge_prompt.replace("{text}", conversation_text)}],
            300, self.api_key, self.model, self.base_url, self.extra_body, self.provider,
        )
        try:
            entries = json.loads(raw)
        except json.JSONDecodeError:
            return []

        written = []
        for entry in entries:
            if "key" in entry and "value" in entry:
                self.set(
                    entry["key"], entry["value"],
                    dimension=entry.get("dimension", "preferences"),
                )
                written.append(entry)
        return written

    # ------------------------------------------------------------------
    # Read
    # ------------------------------------------------------------------

    def get(self, key: str) -> str | None:
        with self._conn() as conn:
            row = conn.execute(
                "SELECT value FROM core_memory WHERE key = ? AND score > 0.1",
                (key,),
            ).fetchone()
        return row["value"] if row else None

    def get_all(self) -> list[dict]:
        """Return all active core memory entries (score > 0.1)."""
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT * FROM core_memory WHERE score > 0.1 ORDER BY stability DESC"
            ).fetchall()
        return [dict(r) for r in rows]

    def to_context_string(self) -> str:
        """
        Format core memory grouped by dimension for context injection.
        Used as static prefix eligible for Prompt Cache.
        """
        entries = self.get_all()
        if not entries:
            return ""

        fallback = next(iter(self.dimensions))
        by_dim: dict[str, list] = {d: [] for d in self.dimensions}
        for e in entries:
            dim = e.get("dimension", fallback)
            if dim not in by_dim:
                dim = fallback
            by_dim[dim].append(e)

        lines = ["[Core Memory]"]
        for dim, dim_entries in by_dim.items():
            if not dim_entries:
                continue
            label = self.dimensions[dim].label
            lines.append(f"  [{label}]")
            for e in dim_entries:
                lines.append(f"    - {e['key']}: {e['value']}")
        return "\n".join(lines)

    def delete(self, key: str) -> bool:
        """Remove a core memory entry by key. Returns True if deleted."""
        with self._conn() as conn:
            cur = conn.execute("DELETE FROM core_memory WHERE key = ?", (key,))
        return cur.rowcount > 0

    # ------------------------------------------------------------------
    # Score management (called by ForgettingManager)
    # ------------------------------------------------------------------

    def update_score(self, key: str, new_score: float):
        with self._conn() as conn:
            conn.execute(
                "UPDATE core_memory SET score = ? WHERE key = ?",
                (new_score, key),
            )

    def get_all_with_scores(self) -> list[dict]:
        with self._conn() as conn:
            rows = conn.execute("SELECT * FROM core_memory").fetchall()
        return [dict(r) for r in rows]
