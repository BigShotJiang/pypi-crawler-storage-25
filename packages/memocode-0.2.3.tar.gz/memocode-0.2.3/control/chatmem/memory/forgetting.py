"""
Forgetting mechanism (Ebbinghaus-inspired) for core memory.
Manages decay scores so stale/unused core memory entries fade over time.
"""

import math
import time
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .core_memory import CoreMemory


def compute_score(
    access_count: int,
    created_at: float,
    stability: float,
    last_accessed_at: float | None = None,
) -> float:
    now = time.time()
    reference_time = last_accessed_at if last_accessed_at else created_at
    days_elapsed = (now - reference_time) / 86400.0
    score = (access_count + 1) * math.exp(-days_elapsed / stability)
    return min(score, 1.0)


class ForgettingManager:
    """
    Runs decay updates for core memory.
    Call run_decay() periodically (every N turns).
    """

    def __init__(self, core_memory: "CoreMemory"):
        self.core = core_memory

    def run_decay(self):
        entries = self.core.get_all_with_scores()
        for entry in entries:
            new_score = compute_score(
                access_count=0,
                created_at=entry["created_at"],
                stability=entry["stability"],
                last_accessed_at=entry.get("updated_at"),
            )
            self.core.update_score(entry["key"], new_score)
