"""
Brain: control layer entry point.
Agentic tool-use loop — LLM decides when/which tools to call.
"""
from __future__ import annotations
import sys
import os
import json
import threading
import time

# Insert paths first so control/chatmem/ (bundled) takes priority
_ROOT = os.path.dirname(os.path.dirname(__file__))
_CONTROL = os.path.dirname(__file__)
_DATA_DIR = os.path.expanduser("~/.mcode")
sys.path.insert(0, _ROOT)
sys.path.insert(0, _CONTROL)

from prompt_toolkit import prompt as _pt_prompt
from chatmem import ContextManager, ContextConfig
from .llm import make_adapter, ToolCall
from .planner import Task  # Task dataclass used for safety interface
from .audit import AuditLog
from .project_manager import ProjectManager
from .fmt import p_dim, p_info, p_warn, p_ok, p_err, dim, cyan, yellow, green, red
from tools.registry import ToolRegistry
from tools.shell import SHELL_TOOL
from tools.file import FILE_READ_TOOL, FILE_WRITE_TOOL, FILE_EDIT_TOOL, GLOB_TOOL, GREP_TOOL
from tools.web import WEB_FETCH_TOOL
from tools.loader import load_external_tools
import safety.safety as _safety


_CODE_BLOCK_RE = __import__("re").compile(r"```[^\n]*\n(.*?)```", __import__("re").DOTALL)
_THINK_RE = __import__("re").compile(r"<think>.*?</think>", __import__("re").DOTALL)
_MAX_CODE_LINES = 20


def _truncate_code_blocks(text: str) -> str:
    """Replace code blocks exceeding _MAX_CODE_LINES with a truncation notice."""
    def _replace(m):
        lang_line = m.group(0).split("\n", 1)[0]  # e.g. ```python
        body = m.group(1)
        lines = body.splitlines()
        if len(lines) <= _MAX_CODE_LINES:
            return m.group(0)
        return (
            f"{lang_line}\n"
            + "\n".join(lines[:_MAX_CODE_LINES])
            + f"\n```\n> ⚠️  代码已截断（共 {len(lines)} 行）。请让我用 file_write 写入文件。"
        )
    return _CODE_BLOCK_RE.sub(_replace, text)


def _tool_hint(name: str, args: dict) -> str:
    """Return a one-line dim hint shown after the tool name."""
    if name == "shell_exec":
        cmd = args.get("command", "")
        first = next((l for l in cmd.splitlines() if l.strip()), cmd)
        return dim(f"$ {first}")
    if name in ("file_read", "file_write", "file_edit"):
        return dim(args.get("path", ""))
    if name == "grep":
        pattern = args.get("pattern", "")
        path = args.get("path", "") or args.get("directory", "")
        return dim(f'"{pattern}"' + (f"  {path}" if path else ""))
    if name == "glob":
        return dim(args.get("pattern", ""))
    if name == "web_fetch":
        return dim(args.get("url", ""))
    return ""


def _print_tool_header(call: ToolCall):
    """Print tool call header + full multiline command if applicable."""
    hint = _tool_hint(call.name, call.args)
    print(cyan(f"▶  {call.name}") + (f"  {hint}" if hint else ""))
    if call.name == "shell_exec":
        lines = call.args.get("command", "").splitlines()
        if len(lines) > 1:
            for extra in lines[1:]:
                print(dim(f"   {extra}"))


def _print_tool_header_simple(name: str, args: dict):
    """Print tool call header for parsed tool calls (non-ToolCall object)."""
    hint = _tool_hint(name, args)
    print(cyan(f"▶  {name}") + (f"  {hint}" if hint else ""))
    if name == "shell_exec":
        lines = args.get("command", "").splitlines()
        if len(lines) > 1:
            for extra in lines[1:]:
                print(dim(f"   {extra}"))


def _resolve_task_paths(tasks: list, work_dir: str) -> list:
    """Legacy helper kept for any remaining callers."""
    result = []
    for t in tasks:
        path_args = {
            "file_read": ["path"], "file_write": ["path"],
        }.get(t.tool, [])
        if not path_args:
            result.append(t)
            continue
        args = dict(t.args)
        for arg_name in path_args:
            p = args.get(arg_name, "")
            if (isinstance(p, str) and p
                    and not os.path.isabs(p)
                    and not p.startswith("~")
                    and "task_" not in p):   # skip {{task_N_output}} placeholders
                args[arg_name] = os.path.join(work_dir, p)
        result.append(Task(
            id=t.id, tool=t.tool, args=args,
            description=t.description, depends_on=t.depends_on,
            reversible=t.reversible, backup_paths=t.backup_paths,
        ))
    return result


_DEFAULT_CHATMEM = {
    "llm": {},
    "dimensions": {
        "identity":      {"label": "Who I am",         "stability": 50.0},
        "values":        {"label": "What I believe",   "stability": 40.0},
        "goals":         {"label": "What I want",      "stability": 30.0},
        "preferences":   {"label": "Likes / dislikes", "stability": 25.0},
        "capabilities":  {"label": "What I can do",    "stability": 30.0},
        "emotional":     {"label": "How I react",      "stability": 20.0},
        "autobiography": {"label": "Key experiences",  "stability": 35.0},
    },
}

_DEFAULT_AGENT = {
    "auto_mode": False,
    "verbose": False,
    "parallel_tasks": True,
    "llm_timeout": 30,
    "max_tool_iter": 40,
    "auto_max_tool_iter": 100,
    "max_tool_output": 20000,
    "require_confirm_on_irreversible": True,
    "active_model": "",
    "models": {
        "minimax": {
            "provider": "openai",
            "model": "MiniMax-M2.7",
            "base_url": "https://api.minimaxi.com/v1",
            "api_key_env": "MINIMAX_API_KEY",
            "context_window": 1000000,
            "extra_body": {
                "reasoning_split": True
            }
        },
        "kimi": {
            "provider": "openai",
            "model": "moonshot-v1-8k",
            "base_url": "https://api.moonshot.cn/v1",
            "api_key_env": "MOONSHOT_API_KEY",
            "context_window": 128000,
            "compress_model": "moonshot-v1-32k",
            "extra_body": {
                "thinking": {
                    "type": "disabled"
                }
            }
        }
    },
}


def _init_data_dir() -> tuple[str, str]:
    """
    Ensure ~/.mcode/ exists with agent.json and chatmem.json.
    Migrates from control/ if old files exist and new ones don't.
    Returns (agent_json_path, chatmem_json_path).
    """
    import json as _json
    import shutil as _shutil

    os.makedirs(_DATA_DIR, exist_ok=True)
    os.makedirs(os.path.join(_DATA_DIR, "tools"), exist_ok=True)

    agent_path = os.path.join(_DATA_DIR, "agent.json")
    chatmem_path = os.path.join(_DATA_DIR, "chatmem.json")

    # Migrate agent.json from old location
    old_agent = os.path.join(_CONTROL, "agent.json")
    if not os.path.exists(agent_path):
        if os.path.exists(old_agent):
            _shutil.copy2(old_agent, agent_path)
        else:
            with open(agent_path, "w") as f:
                _json.dump(_DEFAULT_AGENT, f, indent=2, ensure_ascii=False)
                f.write("\n")

    # Migrate chatmem.json from old location (only dimensions, llm is auto-managed)
    old_chatmem = os.path.join(_CONTROL, "chatmem.json")
    if not os.path.exists(chatmem_path):
        if os.path.exists(old_chatmem):
            _shutil.copy2(old_chatmem, chatmem_path)
        else:
            with open(chatmem_path, "w") as f:
                _json.dump(_DEFAULT_CHATMEM, f, indent=2, ensure_ascii=False)
                f.write("\n")

    return agent_path, chatmem_path


def _sync_active_model(agent_cfg: dict, chatmem_json_path: str | None):
    """Write the active model profile into chatmem.json's llm section."""
    import os as _os

    if not chatmem_json_path or not os.path.exists(chatmem_json_path):
        return
    models = agent_cfg.get("models", {})
    active = agent_cfg.get("active_model", "")
    profile = models.get(active)

    # Auto-detect: if active_model is empty, find the first model with a valid API key
    if not active or not profile:
        for model_name, model_cfg in models.items():
            api_key_env = model_cfg.get("api_key_env", "")
            if api_key_env and _os.environ.get(api_key_env):
                active = model_name
                profile = model_cfg
                agent_cfg["active_model"] = active
                # Save the updated active_model back to agent.json
                agent_path, _ = _init_data_dir()
                with open(agent_path) as f:
                    import json as _json
                    data = _json.load(f)
                data["active_model"] = active
                with open(agent_path, "w") as f:
                    _json.dump(data, f, indent=2, ensure_ascii=False)
                    f.write("\n")
                break

    if not profile:
        return

    import json as _json
    with open(chatmem_json_path) as f:
        data = _json.load(f)
    # Replace llm section with profile entirely (don't merge — avoids stale keys from previous model)
    # Preserve non-LLM keys in existing llm section that aren't model-specific (none currently)
    data["llm"] = dict(profile)
    with open(chatmem_json_path, "w") as f:
        _json.dump(data, f, indent=2, ensure_ascii=False)
        f.write("\n")


class Brain:
    def __init__(
        self,
        config_path: str | None = None,
        verbose: bool | None = None,
        project: str | None = None,
        no_lock: bool = False,
    ):
        # Ensure ~/.mcode/ exists; migrate old files if needed
        agent_path, chatmem_path = _init_data_dir()

        self._agent_cfg_path = agent_path
        self._config_path = config_path or chatmem_path

        import json as _json
        agent_cfg: dict = {}
        if os.path.exists(self._agent_cfg_path):
            with open(self._agent_cfg_path) as f:
                agent_cfg = _json.load(f)

        # Sync active model profile → chatmem.json before loading ContextConfig
        _sync_active_model(agent_cfg, chatmem_path)

        cfg = ContextConfig.from_json(chatmem_path)

        # Agent-level config (CLI args override chatmem.json)
        self.auto_mode: bool = agent_cfg.get("auto_mode", False)
        self.bypass_safety: bool = False  # session-only, never persisted
        self.tool_choice: str = "auto"  # "auto" | "required"; first-iteration only, session-only
        self.verbose = verbose if verbose is not None else agent_cfg.get("verbose", False)
        llm_timeout: int = agent_cfg.get("llm_timeout", 30)
        self._agent_cfg = agent_cfg

        # Inject api_key_env from agent_cfg into cfg.llm so make_adapter can resolve it
        active = agent_cfg.get("active_model", "")
        profile = agent_cfg.get("models", {}).get(active, {})
        if profile.get("api_key_env"):
            cfg.llm.api_key_env = profile["api_key_env"]
        if profile.get("api_key"):
            cfg.llm.api_key = profile["api_key"]
        if profile.get("base_url"):
            cfg.llm.base_url = profile["base_url"]

        # Validate API key is resolvable (fail fast with a clear message)
        _api_key = cfg.llm.resolve_api_key()
        if not _api_key:
            if not active:
                raise RuntimeError(
                    "Your agent.json is missing 'active_model' configuration.\n"
                    "Please configure your LLM model in ~/.mcode/agent.json:\n"
                    "  1. Set 'active_model' to your desired model name (e.g., 'minimax')\n"
                    "  2. Configure the corresponding model in 'models' section\n"
                    "  3. Set the required API key environment variable"
                )
            env_var = profile.get("api_key_env", "")
            msg = f"API key not found for model '{active}'."
            if env_var:
                msg += f" Set the {env_var} environment variable."
            raise RuntimeError(msg)

        self.llm = make_adapter(cfg, timeout=llm_timeout)

        # Project/session management
        self.projects = ProjectManager()
        if project:
            self.projects.switch_project(project)
        else:
            self.projects.find_or_create_for_cwd()

        # Memory layer — one DB per project, core DB shared
        self.memory = ContextManager.create(
            config=cfg,
            api_key=_api_key,
            db_path=self.projects.project_db_path,
            core_db_path=self.projects.core_db_path,
            no_lock=no_lock,
        )

        # Audit log
        self.audit = AuditLog(os.path.join(_DATA_DIR, "audit.db"))

        # Tool registry — built-ins + auto-discovered externals
        self.registry = ToolRegistry()
        self.registry.register(SHELL_TOOL)
        self.registry.register(FILE_READ_TOOL)
        self.registry.register(FILE_WRITE_TOOL)
        self.registry.register(FILE_EDIT_TOOL)
        self.registry.register(GLOB_TOOL)
        self.registry.register(GREP_TOOL)
        self.registry.register(WEB_FETCH_TOOL)
        load_external_tools(self.registry)

        self._max_tool_iter: int = agent_cfg.get("max_tool_iter", 40)
        self._auto_max_tool_iter: int = agent_cfg.get("auto_max_tool_iter", 100)
        self._max_tool_output: int = agent_cfg.get("max_tool_output", 20000)

        # Interrupt support
        self._stop_event = threading.Event()
        self._last_was_action = False
        self._spinner_stop: threading.Event | None = None  # set by run.py before each turn

    # ------------------------------------------------------------------
    # Main entry point
    # ------------------------------------------------------------------

    def run(self, user_input: str) -> str:
        """Process one user turn. Returns response string."""
        return "".join(self.stream_run(user_input))

    def stream_run(self, user_input: str):
        """Generator for the REPL. Yields text chunks."""
        self._stop_event.clear()
        yield from self._agent_loop(user_input)


    def _agent_loop(self, user_input: str):
        """
        Tool-use agentic loop using native function calling (OpenAI / Anthropic).
        Generator — yields text chunks for the final response.
        """
        from .llm import LLMResponse
        from safety.backup import backup_file as _backup_file
        if self.auto_mode:
            _system = (
                "You are an autonomous coding agent. Complete the user's task fully and independently.\n\n"
                "EXECUTION RULES:\n"
                "- Use tools to do everything: read files, write files, run commands, search code, fetch URLs.\n"
                "- NEVER guess, fabricate, or recall information that must come from a tool. "
                "If the task requires fetching a URL, reading a file, or running a command — call the tool. "
                "Do not invent the result.\n"
                "- To fetch any URL or HTTP endpoint, always call web_fetch. Never guess the response.\n"
                "- Do NOT output text mid-task. Keep calling tools until the task is 100% done.\n"
                "- Before editing a file, always read it first with file_read.\n"
                "- For targeted changes use file_edit; for new files use file_write.\n"
                "- If a tool fails, diagnose the error from the output and retry with a corrected approach.\n"
                "- Verify your work: run tests, check command output, re-read files after editing.\n"
                "- Only output text ONCE at the very end: a concise summary of what was done. "
                "Do not output diffs, patch format, or full file contents — describe changes in plain text.\n\n"
                "DECISION RULES:\n"
                "- When multiple approaches exist, pick the most direct one and execute it.\n"
                "- Do not ask for clarification. Make a reasonable assumption and proceed.\n"
                "- If genuinely blocked (missing credentials, hardware dependency, etc.), "
                "stop and explain clearly why."
            )
        else:
            _system = (
                "You are a coding assistant with access to tools. "
                "ALWAYS use tools to perform actions — never describe, simulate, or guess the result of an operation. "
                "If the user asks you to run a command, call shell_exec. "
                "If the user asks you to read a file, call file_read. "
                "If the user asks you to write or create a file, call file_write. "
                "If the user asks you to edit a file, call file_edit. "
                "If the user asks you to fetch a URL or HTTP endpoint, call web_fetch — never fabricate the response. "
                "Before editing a file, always read it first with file_read, then proceed to make the edit without stopping. "
                "For targeted changes use file_edit; for new files use file_write. "
                "If a task requires multiple tool calls, keep calling tools until the task is fully done — do not report completion until all actions have been executed via tools."
            )
        user_msg = [
            {"role": "system", "content": _system},
            {"role": "user", "content": user_input},
        ]
        enriched = self.memory._build_context(user_msg)
        loop_msgs = list(enriched)
        tools = self.registry.to_openai_tools()

        any_tool_called = False
        final_text = ""
        tool_log = []
        _interrupted = False

        max_iter = self._auto_max_tool_iter if self.auto_mode else self._max_tool_iter
        # Stuck detection: track last seen (tool, args_repr) per iteration
        _stuck_streak = 0
        _last_call_sig: str | None = None
        _STUCK_THRESHOLD = 3  # abort if same call repeated this many times
        for iteration in range(max_iter):
            if self._stop_event.is_set():
                break

            # Stream with native function calling; collect text, capture final LLMResponse
            text_chunks: list[str] = []
            llm_response: LLMResponse | None = None
            try:
                # Enforce tool_choice only on the first iteration.
                # Subsequent iterations must stay "auto" so the model can
                # give a final text response after completing multi-step tasks.
                tc = self.tool_choice if iteration == 0 else "auto"
                for item in self.llm.stream_with_tools(loop_msgs, tools,
                                                       tool_choice=tc):
                    if self._stop_event.is_set():
                        break
                    if isinstance(item, str):
                        text_chunks.append(item)
                    else:
                        llm_response = item
            except KeyboardInterrupt:
                self._stop_event.set()
                _interrupted = True
                print()
                break

            if self._stop_event.is_set():
                break

            if llm_response is None:
                # Unexpected — treat accumulated text as final response
                full_text = "".join(text_chunks)
                if full_text.strip():
                    clean = _THINK_RE.sub("", full_text).strip()
                    final_text = _truncate_code_blocks(clean)
                    yield final_text
                break

            calls = llm_response.tool_calls

            if not calls:
                # No tool calls — final text response
                self._last_was_action = any_tool_called
                text = llm_response.text or "".join(text_chunks)
                clean = _THINK_RE.sub("", text).strip()
                final_text = _truncate_code_blocks(clean)
                yield final_text
                break

            # Stuck detection: if all calls in this iteration are identical to last, count streak
            call_sig = "|".join(f"{tc.name}:{json.dumps(tc.args, sort_keys=True)}" for tc in calls)
            if call_sig == _last_call_sig:
                _stuck_streak += 1
            else:
                _stuck_streak = 0
            _last_call_sig = call_sig

            if _stuck_streak >= _STUCK_THRESHOLD:
                final_text = (
                    f"(agent stuck: same tool call repeated {_stuck_streak + 1} times — "
                    f"aborting to prevent infinite loop)"
                )
                yield red(final_text)
                break

            # Append the assistant message (contains tool_calls in OpenAI format)
            if llm_response.assistant_msg:
                loop_msgs.append(llm_response.assistant_msg)
            any_tool_called = True

            tool_results = []
            _aborted = False
            for i, tc in enumerate(calls):
                if self._stop_event.is_set():
                    _aborted = True
                    break

                print()  # blank line before each tool call

                # Build Task for safety interface
                task = Task(
                    id=iteration * 100 + i,
                    tool=tc.name,
                    args=tc.args,
                    description=f"{tc.name}({tc.args})",
                    depends_on=[],
                )
                # Inject work_dir for path resolution
                exec_args = dict(tc.args)
                work_dir = self.projects.work_dir
                if work_dir:
                    if tc.name == "shell_exec" and "cwd" not in exec_args:
                        exec_args["cwd"] = work_dir
                    elif tc.name in ("file_read", "file_write", "file_edit", "grep"):
                        p = exec_args.get("path", "")
                        if p and not os.path.isabs(p) and not p.startswith("~"):
                            exec_args["path"] = os.path.join(work_dir, p)
                    elif tc.name == "glob":
                        if "base_dir" not in exec_args:
                            exec_args["base_dir"] = work_dir

                # Stop spinner before any user-visible output or confirmation prompt
                if self._spinner_stop and not self._spinner_stop.is_set():
                    self._spinner_stop.set()
                    time.sleep(0.05)

                if not self._confirm_tool_call(task):
                    # User said no — stop the loop
                    self._stop_event.set()
                    _aborted = True
                    yield "\n" + yellow("Operation cancelled. What would you like to do instead?")
                    break

                # Backup file before destructive edits (enables /undo)
                _backup_map: dict[str, str] = {}
                if tc.name in ("file_write", "file_edit"):
                    _target = exec_args.get("path", "")
                    if _target:
                        _bp = _backup_file(_target, self.projects.backup_dir)
                        if _bp:
                            _backup_map[_target] = _bp

                # Show file_write/file_edit diff before executing
                if tc.name == "file_write":
                    self._show_write_diff(tc.args)
                elif tc.name == "file_edit":
                    self._show_edit_diff(exec_args)

                _print_tool_header_simple(tc.name, tc.args)

                try:
                    result = self.registry.call(
                        tc.name, exec_args,
                        output_cb=lambda line: print(f"  {line}"),
                    )
                except KeyboardInterrupt:
                    self._stop_event.set()
                    _aborted = True
                    print(red("\n🚫  interrupted"))
                    break

                icon = green("✓") if result.success else red("✗")
                summary = (result.output if result.success else result.error)[:120].splitlines()[0]
                backup_hint = dim(f"  💾 backup saved") if _backup_map else ""
                print(f"{icon}  {dim(summary)}{backup_hint}")
                content = result.output if result.success else f"ERROR: {result.error}"

                if len(content) > self._max_tool_output:
                    omitted = len(content) - self._max_tool_output
                    content = content[:self._max_tool_output] + f"\n... [truncated, {omitted} chars omitted]"
                entry: dict = {
                    "tool": tc.name, "args": tc.args,
                    "success": result.success, "output": content[:500],
                }
                if _backup_map:
                    entry["backups"] = _backup_map
                tool_log.append(entry)
                tool_results.append({
                    "role": "tool",
                    "tool_call_id": tc.id,
                    "content": content,
                })

            if _aborted:
                # Remove the assistant message we already appended — loop_msgs stays consistent
                if llm_response.assistant_msg and loop_msgs and loop_msgs[-1] is llm_response.assistant_msg:
                    loop_msgs.pop()
            else:
                loop_msgs.extend(tool_results)
        else:
            # Hit max iterations
            final_text = f"(stopped after {max_iter} iterations)"
            yield final_text

        # Capture turn count before _post_turn adds the current turn
        _turn_idx = len(self.memory.list_turns())

        # Save to memory — skip if interrupted (avoid empty/partial turn polluting context)
        if not _interrupted:
            self.memory._post_turn(user_input, final_text, user_msg)

        if any_tool_called:
            self.audit.record(user_input, user_input, [], True, tool_log,
                              project=self.projects.current_project,
                              turn_idx=_turn_idx)

    # ------------------------------------------------------------------
    # Per-tool safety + confirmation
    # ------------------------------------------------------------------

    def _confirm_tool_call(self, task: Task) -> bool:
        from safety.backup import backup_files

        work_dir = self.projects.work_dir

        # ── Auto mode: hard boundaries, zero prompts ───────────────────────────
        # ── Bypass safety: skip all checks ────────────────────────────────────
        if self.bypass_safety:
            return True

        if self.auto_mode:
            whitelist = self._agent_cfg.get("auto_whitelist", None)
            result = _safety.check_auto(task, work_dir=work_dir, whitelist=whitelist)
            if result.violation:
                print(red(f"\n🛑  AUTO-BLOCKED  {result.reason}"))
                return False
            if result.backup_paths:
                backed_up = backup_files(result.backup_paths, backup_dir=self.projects.backup_dir)
                for orig, bp in backed_up.items():
                    print(dim(f"💾  backup → {bp}"))
            return True

        # ── Human mode: zone checks + confirmation prompts ─────────────────────
        from safety.policy import is_always_allowed, remember_always, get_allowed_paths

        result = _safety.check(task, work_dir=work_dir, allowed_paths=get_allowed_paths())

        if result.violation:
            print(red(f"\n🛑  BLOCKED  {task.description}"))
            print(dim(f"   {result.reason}"))
            return False

        if result.backup_paths:
            backed_up = backup_files(result.backup_paths, backup_dir=self.projects.backup_dir)
            for orig, bp in backed_up.items():
                print(dim(f"💾  backup → {bp}"))

        if result.requires_confirmation:
            op = result.operation_class
            if op and is_always_allowed(op):
                return True

            if result.script_path and os.path.isfile(result.script_path):
                try:
                    content = open(result.script_path).read()
                    print(yellow(f"\n📄  Script: {result.script_path}"))
                    print(dim("─" * 60))
                    for line in content.splitlines()[:40]:
                        print(dim(f"   {line}"))
                    print(dim("─" * 60))
                except OSError:
                    pass

            print(yellow(f"\n⚠️   {result.reason}"))
            print(dim(f"    {task.description}"))

            if result.can_always:
                raw = _pt_prompt("    Proceed? [y]es  [n]o  [a]lways ❯ ").strip().lower()
            else:
                raw = _pt_prompt("    Proceed? [y]es  [n]o ❯ ").strip().lower()

            if raw in ("a", "always") and result.can_always:
                remember_always(op)
                print(cyan(f"📌  policy saved: always allow [{op}]"))
            elif raw not in ("y", "yes"):
                print(red("🚫  cancelled"))
                return False
            return True

        return True

    # ------------------------------------------------------------------
    # File write/edit diff
    # ------------------------------------------------------------------

    def _print_diff(self, old_content: str, new_content: str, path: str):
        import difflib
        if old_content == new_content:
            print(dim("  (no changes)"))
            return
        diff = list(difflib.unified_diff(
            old_content.splitlines(keepends=True),
            new_content.splitlines(keepends=True),
            fromfile=f"a/{path}",
            tofile=f"b/{path}",
            lineterm="",
        ))
        print()
        for line in diff[:60]:
            if line.startswith("+"):
                print(green(f"  {line}"))
            elif line.startswith("-"):
                print(red(f"  {line}"))
            else:
                print(dim(f"  {line}"))
        if len(diff) > 60:
            print(dim(f"  ... ({len(diff)-60} more lines)"))
        print()

    def _resolve_full_path(self, path: str) -> str | None:
        full = os.path.expanduser(path)
        if not os.path.isabs(full):
            full = os.path.join(self.projects.work_dir, full)
        return full if os.path.isfile(full) else None

    def _show_write_diff(self, args: dict):
        path = args.get("path", "")
        new_content = args.get("content", "")
        if not path:
            return
        full_path = self._resolve_full_path(path)
        if not full_path:
            return  # new file, no diff needed
        try:
            old_content = open(full_path).read()
        except OSError:
            return
        self._print_diff(old_content, new_content, path)

    def _show_edit_diff(self, args: dict):
        path = args.get("path", "")
        old_str = args.get("old_str", "")
        if not path or not old_str:
            return
        full_path = self._resolve_full_path(path)
        if not full_path:
            return
        try:
            old_content = open(full_path).read()
        except OSError:
            return
        new_content = old_content.replace(old_str, args.get("new_str", ""), 1)
        self._print_diff(old_content, new_content, path)

    # ------------------------------------------------------------------
    # Model switching
    # ------------------------------------------------------------------

    def list_models(self) -> dict:
        """Return the models dict from agent.json."""
        return self._agent_cfg.get("models", {})

    def switch_model(self, name: str):
        """Switch to a named model profile. Updates agent.json + chatmem.json + live adapters."""
        import json as _json
        models = self._agent_cfg.get("models", {})
        if name not in models:
            raise KeyError(f"Model '{name}' not found in agent.json models")
        # Update agent.json
        self._agent_cfg["active_model"] = name
        with open(self._agent_cfg_path, "w") as f:
            _json.dump(self._agent_cfg, f, indent=2, ensure_ascii=False)
            f.write("\n")
        # Sync to chatmem.json and rebuild adapters
        _sync_active_model(self._agent_cfg, self._config_path)
        cfg = ContextConfig.from_json(self._config_path) if self._config_path else ContextConfig()
        key = cfg.llm.resolve_api_key()
        if not key:
            profile = models.get(name, {})
            env_var = profile.get("api_key_env", "")
            msg = f"API key not found for model '{name}'."
            if env_var:
                msg += f" Set the {env_var} environment variable."
            raise RuntimeError(msg)
        timeout = self._agent_cfg.get("llm_timeout", 30)
        self.llm = make_adapter(cfg, timeout=timeout)
        self._reinit_memory()

    # ------------------------------------------------------------------
    # Project / session switching
    # ------------------------------------------------------------------

    def switch_project(self, name: str):
        self.memory.end_session()
        self.projects.switch_project(name)
        self._reinit_memory()

    def _reinit_memory(self):
        if getattr(self, "memory", None) is not None:
            self.memory.close()
        cfg = ContextConfig.from_json(self._config_path) if self._config_path else ContextConfig()
        self.memory = ContextManager.create(
            config=cfg,
            api_key=cfg.llm.resolve_api_key(),
            db_path=self.projects.project_db_path,
            core_db_path=self.projects.core_db_path,
        )

    def _save_agent_cfg(self):
        """Persist current _agent_cfg to agent.json."""
        import json as _json
        with open(self._agent_cfg_path, "w") as f:
            _json.dump(self._agent_cfg, f, indent=2, ensure_ascii=False)
            f.write("\n")

    # ------------------------------------------------------------------
    # Session lifecycle
    # ------------------------------------------------------------------

    def end_session(self):
        self.memory.end_session()
