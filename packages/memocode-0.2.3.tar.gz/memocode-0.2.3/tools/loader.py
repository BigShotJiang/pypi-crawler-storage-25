"""
Tool auto-discovery: scans tools/*.py for *_TOOL variables or TOOLS lists.
Skips registry.py, shell.py (built-in), loader.py itself, and file.py (built-in).

Adding a custom tool:
  1. Copy tools/example_tool.py.template → ~/.mcode/tools/mytool.py
  2. Implement your function and fill in the ToolSchema
  3. Restart the agent — it loads automatically, verify with /tools
"""
from __future__ import annotations
import importlib
import os
import sys
from .registry import Tool, ToolRegistry

_BUILTIN = {"registry", "loader", "shell", "file"}


def _scan_dir(registry: ToolRegistry, tools_dir: str, package_prefix: str):
    """Scan a single directory for tool modules."""
    if not os.path.isdir(tools_dir):
        return
    if tools_dir not in sys.path:
        sys.path.insert(0, os.path.dirname(tools_dir))

    for filename in sorted(os.listdir(tools_dir)):
        if not filename.endswith(".py") or filename.startswith("_"):
            continue
        module_name = filename[:-3]
        if module_name in _BUILTIN:
            continue

        try:
            mod = importlib.import_module(f"{package_prefix}.{module_name}")
        except Exception as e:
            print(f"[tools] failed to load {module_name}: {e}")
            continue

        registered = 0
        # Check for TOOLS list
        tools_list = getattr(mod, "TOOLS", None)
        if isinstance(tools_list, list):
            for tool in tools_list:
                if isinstance(tool, Tool):
                    registry.register(tool)
                    registered += 1

        # Check for *_TOOL variables
        for attr in dir(mod):
            if attr.endswith("_TOOL") and not attr.startswith("_"):
                obj = getattr(mod, attr)
                if isinstance(obj, Tool) and not registry.has(obj.schema.name):
                    registry.register(obj)
                    registered += 1

        if registered:
            print(f"[tools] loaded {registered} tool(s) from {filename}")


def load_external_tools(registry: ToolRegistry, tools_dir: str | None = None):
    """
    Scan tools/ directory and ~/.mcode/tools/ for external tool modules.
    Looks for module-level variables named *_TOOL (Tool instance) or TOOLS (list of Tool).
    """
    # Built-in tools dir (package)
    builtin_dir = tools_dir or os.path.dirname(__file__)
    _scan_dir(registry, builtin_dir, "tools")

    # User tools dir (~/.mcode/tools/)
    user_tools_dir = os.path.join(os.path.expanduser("~/.mcode"), "tools")
    if os.path.isdir(user_tools_dir):
        if user_tools_dir not in sys.path:
            sys.path.insert(0, user_tools_dir)
        _scan_dir(registry, user_tools_dir, "mcode_tools")
