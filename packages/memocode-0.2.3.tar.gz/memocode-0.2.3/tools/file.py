"""
Built-in tools: file_read, file_write, file_edit, glob
Safe file I/O without shell — cleaner output, no injection risk.
"""
import os
import re as _re
import glob as _glob
from .registry import Tool, ToolSchema


_MAX_READ_LINES = 2000
_MAX_READ_BYTES = 200_000


def _file_read(path: str, offset: int = 0, limit: int | None = None) -> str:
    """Read file contents. offset/limit are line numbers (1-based start, count)."""
    path = os.path.expanduser(path)
    if not os.path.exists(path):
        raise FileNotFoundError(f"File not found: {path}")
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        lines = f.readlines()
    total = len(lines)
    start = max(0, offset - 1) if offset > 0 else 0
    end = min(total, start + (limit or _MAX_READ_LINES))
    chunk = lines[start:end]
    # Byte cap as secondary guard
    result = "".join(chunk)
    if len(result) > _MAX_READ_BYTES:
        result = result[:_MAX_READ_BYTES]
        result += f"\n... [truncated at {_MAX_READ_BYTES} bytes]"
    header = ""
    if start > 0 or end < total:
        header = f"[lines {start+1}–{end} of {total}]\n"
    if end < total and not header.endswith("truncated"):
        result += f"\n... [{total - end} more lines — use offset={end+1} to continue]"
    return header + result


def _file_write(path: str, content: str, append: bool = False) -> str:
    path = os.path.expanduser(path)
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    mode = "a" if append else "w"
    with open(path, mode, encoding="utf-8") as f:
        f.write(content)
    action = "Appended to" if append else "Written"
    return f"{action}: {path} ({len(content)} chars)"


def _file_edit(path: str, old_str: str, new_str: str) -> str:
    """Replace exact string in file. Raises if old_str not found or ambiguous."""
    path = os.path.expanduser(path)
    if not os.path.exists(path):
        raise FileNotFoundError(f"File not found: {path}")
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        content = f.read()
    count = content.count(old_str)
    if count == 0:
        raise ValueError(f"String not found in {path}")
    if count > 1:
        raise ValueError(f"Ambiguous: found {count} occurrences. Add more context to make it unique.")
    new_content = content.replace(old_str, new_str, 1)
    with open(path, "w", encoding="utf-8") as f:
        f.write(new_content)
    return f"Edited: {path} (replaced 1 occurrence)"


def _glob_files(pattern: str, base_dir: str | None = None) -> str:
    """Expand a glob pattern and return matching paths, one per line."""
    if base_dir and not os.path.isabs(pattern):
        pattern = os.path.join(base_dir, pattern)
    matches = _glob.glob(pattern, recursive=True)
    if not matches:
        return "(no matches)"
    return "\n".join(sorted(matches))


FILE_READ_TOOL = Tool(
    schema=ToolSchema(
        name="file_read",
        description=(
            f"Read the contents of a file. Returns up to {_MAX_READ_LINES} lines by default. "
            "Use offset and limit to paginate large files."
        ),
        parameters={
            "type": "object",
            "properties": {
                "path":   {"type": "string",  "description": "Absolute or ~ path to the file"},
                "offset": {"type": "integer", "description": "Start from this line number (1-based, default: 1)"},
                "limit":  {"type": "integer", "description": f"Max lines to return (default: {_MAX_READ_LINES})"},
            },
            "required": ["path"],
        },
    ),
    fn=_file_read,
)

FILE_WRITE_TOOL = Tool(
    schema=ToolSchema(
        name="file_write",
        description="Write (or append) text content to a file. Creates parent directories if needed.",
        parameters={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Absolute or ~ path to the file"},
                "content": {"type": "string", "description": "Text content to write"},
                "append": {"type": "boolean", "description": "If true, append instead of overwrite (default: false)"},
            },
            "required": ["path", "content"],
        },
    ),
    fn=_file_write,
)

FILE_EDIT_TOOL = Tool(
    schema=ToolSchema(
        name="file_edit",
        description=(
            "Replace an exact string in a file. "
            "Use this for targeted edits instead of rewriting the whole file. "
            "old_str must match exactly (including whitespace/indentation) and be unique in the file."
        ),
        parameters={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Path to the file"},
                "old_str": {"type": "string", "description": "Exact string to find and replace"},
                "new_str": {"type": "string", "description": "Replacement string"},
            },
            "required": ["path", "old_str", "new_str"],
        },
    ),
    fn=_file_edit,
)

def _grep(pattern: str, path: str, recursive: bool = False,
          ignore_case: bool = False, context_lines: int = 0) -> str:
    """Search for pattern in file(s). Returns matching lines with file:line context."""
    flags = _re.IGNORECASE if ignore_case else 0
    try:
        regex = _re.compile(pattern, flags)
    except _re.error as e:
        raise ValueError(f"Invalid regex pattern: {e}")

    path = os.path.expanduser(path)
    results: list[str] = []

    def _search_file(filepath: str):
        try:
            with open(filepath, "r", encoding="utf-8", errors="replace") as f:
                lines = f.readlines()
        except OSError:
            return
        matched_indices = [i for i, line in enumerate(lines) if regex.search(line)]
        if not matched_indices:
            return
        # Collect line ranges to print (with context)
        shown: set[int] = set()
        for idx in matched_indices:
            for j in range(max(0, idx - context_lines), min(len(lines), idx + context_lines + 1)):
                shown.add(j)
        prev = -2
        for i in sorted(shown):
            if i > prev + 1 and prev >= 0:
                results.append("--")
            marker = ":" if i in set(matched_indices) else "-"
            results.append(f"{filepath}:{i+1}{marker}{lines[i].rstrip()}")
            prev = i

    if os.path.isfile(path):
        _search_file(path)
    elif os.path.isdir(path):
        if not recursive:
            raise ValueError(f"{path} is a directory — set recursive=true to search recursively")
        for root, dirs, files in os.walk(path):
            dirs[:] = [d for d in sorted(dirs) if not d.startswith(".")]
            for fname in sorted(files):
                _search_file(os.path.join(root, fname))
    else:
        raise FileNotFoundError(f"Path not found: {path}")

    if not results:
        return "(no matches)"
    MAX = 500
    if len(results) > MAX:
        omitted = len(results) - MAX
        return "\n".join(results[:MAX]) + f"\n... [{omitted} more lines omitted]"
    return "\n".join(results)


GREP_TOOL = Tool(
    schema=ToolSchema(
        name="grep",
        description=(
            "Search for a regex pattern in a file or directory. "
            "Returns matching lines with file path and line number. "
            "Use recursive=true to search all files in a directory."
        ),
        parameters={
            "type": "object",
            "properties": {
                "pattern":      {"type": "string", "description": "Regex pattern to search for"},
                "path":         {"type": "string", "description": "File or directory path to search"},
                "recursive":    {"type": "boolean", "description": "Search directory recursively (default: false)"},
                "ignore_case":  {"type": "boolean", "description": "Case-insensitive search (default: false)"},
                "context_lines":{"type": "integer", "description": "Lines of context around each match (default: 0)"},
            },
            "required": ["pattern", "path"],
        },
    ),
    fn=_grep,
)

GLOB_TOOL = Tool(
    schema=ToolSchema(
        name="glob",
        description=(
            "Find files matching a glob pattern. Supports ** for recursive search. "
            "Examples: '**/*.py', 'src/*.swift', '*.json'"
        ),
        parameters={
            "type": "object",
            "properties": {
                "pattern": {"type": "string", "description": "Glob pattern to match"},
            },
            "required": ["pattern"],
        },
    ),
    fn=_glob_files,
)
