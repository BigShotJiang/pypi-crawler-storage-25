"""
Built-in tool: shell_exec
Executes a shell command and returns stdout/stderr.
Supports line-by-line streaming via optional _line_cb callback.
"""
import subprocess
from typing import Callable
from .registry import Tool, ToolSchema


def _shell_exec(
    command: str,
    cwd: str | None = None,
    timeout: int = 30,
    _line_cb: Callable[[str], None] | None = None,
) -> str:
    if _line_cb:
        # Streaming mode: read output line by line as it arrives
        proc = subprocess.Popen(
            command,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,  # merge stderr into stdout
            text=True,
            cwd=cwd,
        )
        lines: list[str] = []
        try:
            for raw in iter(proc.stdout.readline, ""):
                line = raw.rstrip()
                lines.append(line)
                _line_cb(line)
            proc.wait(timeout=timeout)
        except KeyboardInterrupt:
            proc.kill()
            proc.wait()
            raise
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()
            raise RuntimeError(f"Command timed out after {timeout}s")

        output = "\n".join(lines)
        if proc.returncode != 0:
            return f"[exit {proc.returncode}]\n{output}" if output else f"[exit {proc.returncode}]"
        return output or "(no output)"
    else:
        try:
            result = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=timeout,
                cwd=cwd,
            )
        except KeyboardInterrupt:
            raise
        output = result.stdout
        if result.stderr:
            output += f"\n[stderr]: {result.stderr}"
        if result.returncode != 0:
            return f"[exit {result.returncode}]\n{output}" if output else f"[exit {result.returncode}]"
        return output or "(no output)"


SHELL_TOOL = Tool(
    schema=ToolSchema(
        name="shell_exec",
        description="Execute a shell command on the local machine. Returns stdout. Raises on non-zero exit code.",
        parameters={
            "type": "object",
            "properties": {
                "command": {"type": "string", "description": "The shell command to execute"},
                "cwd": {"type": "string", "description": "Working directory to run the command in (optional, defaults to project work_dir)"},
            },
            "required": ["command"],
        },
    ),
    fn=_shell_exec,
    supports_streaming=True,
)
