"""
Built-in tool: web_fetch
Fetch a URL and return readable text content.
HTML is stripped to plain text; JSON/plain text returned as-is.
"""
from .registry import Tool, ToolSchema

_MAX_CHARS = 30_000


def _make_ssl_context():
    """Return an SSL context. Uses certifi bundle if available, else system default."""
    import ssl
    try:
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except ImportError:
        pass
    return ssl.create_default_context()


def _web_fetch(url: str, max_chars: int = _MAX_CHARS) -> str:
    import urllib.request
    import urllib.error
    import ssl

    req = urllib.request.Request(
        url,
        headers={"User-Agent": "Mozilla/5.0 (compatible; mcode-agent/1.0)"},
    )

    def _fetch(ctx=None):
        kwargs = {"timeout": 15}
        if ctx is not None:
            kwargs["context"] = ctx
        with urllib.request.urlopen(req, **kwargs) as resp:
            return resp.headers.get("Content-Type", ""), resp.read()

    def _is_ssl_error(exc) -> bool:
        """URLError often wraps SSLError as its .reason."""
        if isinstance(exc, ssl.SSLError):
            return True
        reason = getattr(exc, "reason", None)
        return isinstance(reason, ssl.SSLError)

    def _fallback_no_verify() -> tuple[str, bytes]:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        return _fetch(ctx)

    content_type, raw = "", b""
    try:
        content_type, raw = _fetch(_make_ssl_context())
    except (ssl.SSLError, urllib.error.URLError) as e:
        if _is_ssl_error(e):
            try:
                content_type, raw = _fallback_no_verify()
                raw = b"[SSL verification skipped]\n" + raw
            except Exception as e2:
                return f"[Error] {e2}"
        else:
            return f"[URL Error] {getattr(e, 'reason', e)}: {url}"
    except urllib.error.HTTPError as e:
        return f"[HTTP {e.code}] {e.reason}: {url}"
    except Exception as e:
        return f"[Error] {e}"

    # Decode
    charset = "utf-8"
    if "charset=" in content_type:
        charset = content_type.split("charset=")[-1].split(";")[0].strip()
    try:
        text = raw.decode(charset, errors="replace")
    except (LookupError, UnicodeDecodeError):
        text = raw.decode("utf-8", errors="replace")

    # Strip HTML → plain text
    if "html" in content_type.lower():
        text = _html_to_text(text)
    elif "json" in content_type.lower():
        pass  # return as-is
    # else: plain text, xml, etc. — return as-is

    text = text.strip()
    if len(text) > max_chars:
        text = text[:max_chars] + f"\n\n... [truncated — {len(text) - max_chars} chars omitted]"
    return text or "(empty response)"


def _html_to_text(html: str) -> str:
    """Minimal HTML → readable text conversion without external dependencies."""
    import re

    # Remove <script>, <style>, <head> blocks entirely
    html = re.sub(r"<(script|style|head)[^>]*>.*?</\1>", " ", html,
                  flags=re.DOTALL | re.IGNORECASE)
    # Replace block-level tags with newlines
    html = re.sub(r"<(br|p|div|h[1-6]|li|tr|blockquote)[^>]*>", "\n", html,
                  flags=re.IGNORECASE)
    # Replace links: keep text + URL
    html = re.sub(r'<a\s[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',
                  lambda m: f"{m.group(2).strip()} ({m.group(1)})" if m.group(2).strip() else m.group(1),
                  html, flags=re.DOTALL | re.IGNORECASE)
    # Strip all remaining tags
    html = re.sub(r"<[^>]+>", "", html)
    # Decode common HTML entities
    for ent, ch in (("&amp;", "&"), ("&lt;", "<"), ("&gt;", ">"),
                    ("&quot;", '"'), ("&#39;", "'"), ("&nbsp;", " ")):
        html = html.replace(ent, ch)
    # Collapse excessive blank lines
    html = re.sub(r"\n{3,}", "\n\n", html)
    return html.strip()


WEB_FETCH_TOOL = Tool(
    schema=ToolSchema(
        name="web_fetch",
        description=(
            "Fetch a URL and return its text content. "
            "HTML pages are converted to readable plain text. "
            "JSON and plain text are returned as-is. "
            "Use this to read documentation, API specs, README files, or any web page."
        ),
        parameters={
            "type": "object",
            "properties": {
                "url": {
                    "type": "string",
                    "description": "The URL to fetch (http or https)",
                },
                "max_chars": {
                    "type": "integer",
                    "description": f"Maximum characters to return (default: {_MAX_CHARS})",
                },
            },
            "required": ["url"],
        },
    ),
    fn=_web_fetch,
)
