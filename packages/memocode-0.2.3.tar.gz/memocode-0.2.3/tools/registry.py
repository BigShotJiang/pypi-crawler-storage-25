"""
Tool registry: plugin-based tool management.
Tools register themselves; Brain queries available tools and dispatches calls.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Callable


@dataclass
class ToolSchema:
    name: str
    description: str
    parameters: dict  # JSON Schema style


@dataclass
class ToolResult:
    success: bool
    output: str
    error: str = ""


class Tool:
    def __init__(self, schema: ToolSchema, fn: Callable, supports_streaming: bool = False):
        self.schema = schema
        self.fn = fn
        self.supports_streaming = supports_streaming

    def call(self, output_cb: Callable[[str], None] | None = None, **kwargs) -> ToolResult:
        try:
            if output_cb and self.supports_streaming:
                kwargs["_line_cb"] = output_cb
            output = self.fn(**kwargs)
            return ToolResult(success=True, output=str(output))
        except Exception as e:
            return ToolResult(success=False, output="", error=str(e))


class ToolRegistry:
    def __init__(self):
        self._tools: dict[str, Tool] = {}

    def register(self, tool: Tool):
        self._tools[tool.schema.name] = tool

    def has(self, name: str) -> bool:
        return name in self._tools

    def list(self) -> list[ToolSchema]:
        return [t.schema for t in self._tools.values()]

    def call(self, name: str, args: dict, output_cb: Callable[[str], None] | None = None) -> ToolResult:
        if name not in self._tools:
            return ToolResult(success=False, output="", error=f"Tool '{name}' not found")
        return self._tools[name].call(output_cb=output_cb, **args)

    def to_openai_tools(self) -> list[dict]:
        return [
            {"type": "function", "function": {
                "name": s.name,
                "description": s.description,
                "parameters": s.parameters,
            }}
            for s in self.list()
        ]

    def to_anthropic_tools(self) -> list[dict]:
        return [
            {"name": s.name, "description": s.description, "input_schema": s.parameters}
            for s in self.list()
        ]
