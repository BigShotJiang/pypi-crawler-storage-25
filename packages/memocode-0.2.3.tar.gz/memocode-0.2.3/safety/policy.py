"""
Policy memory: persists "always allow" decisions for operation classes.
Stored in safety/safety.json under "always_allow".
"""
from __future__ import annotations
import json
import os

_CONFIG_PATH = os.path.join(os.path.dirname(__file__), "safety.json")


def _load() -> dict:
    if os.path.exists(_CONFIG_PATH):
        try:
            with open(_CONFIG_PATH) as f:
                return json.load(f)
        except Exception:
            pass
    return {}


def _save(cfg: dict):
    with open(_CONFIG_PATH, "w") as f:
        json.dump(cfg, f, indent=2)


def is_always_allowed(operation_class: str) -> bool:
    return operation_class in _load().get("always_allow", [])


def remember_always(operation_class: str):
    cfg = _load()
    always = set(cfg.get("always_allow", []))
    always.add(operation_class)
    cfg["always_allow"] = sorted(always)
    _save(cfg)


def get_allowed_paths() -> list[str]:
    return [os.path.expanduser(p) for p in _load().get("allowed_paths", [])]
