"""
Zero-trust safety layer.

Decision engine (linear, no enumeration):
  DENY  — write to critical system path, or fork bomb structural pattern
  ALLOW — read-only operation (file_read; shell with no write indicators and no critical paths)
  SCOPE — paths found → check trusted zone:
             any critical path            → DENY
             all in trusted zone          → ALLOW (backup writes)
             any outside trusted zone     → ASK, no "always" (cross-boundary)
          no paths + write indicators     → ASK, "always" ok (uncertain write)
          no paths + no write indicators  → ALLOW (ps, echo, date, ls…)

Trusted zone = work_dir + config allowed_paths
Write indicators (structural syntax, not command names): >  >>  -i  --in-place
"""
from __future__ import annotations
import os
import re
from dataclasses import dataclass, field

# Paths where any write is catastrophic — hard deny
_CRITICAL = frozenset([
    "/", "/etc", "/bin", "/sbin", "/usr",
    "/lib", "/lib64", "/boot", "/root", "/dev",
])

# Structural write syntax (not command names)
_WRITE_RE = re.compile(r"(>{1,2}(?!=)|(?<!\w)-i\b|--in-place\b)")

# Backup triggers: destructive file ops without write syntax markers
_BACKUP_RE = re.compile(r"\b(rm|mv)\b")

# Script/interpreter execution detection
_INTERPRETER_RE = re.compile(
    r"\b(python3?|bash|sh|zsh|node|ruby|perl)\s+([\./~]\S+\.(?:py|sh|js|rb|pl|zsh|bash)|(?!-)\S+\.(?:py|sh|js|rb|pl))\b"
)

# Fork bomb structural pattern
_FORK_BOMB_RE = re.compile(r":\(\)\s*\{.*?:\s*\|\s*:.*?\}", re.DOTALL)


@dataclass
class SafetyResult:
    violation: bool
    reason: str = ""
    requires_confirmation: bool = False
    reversible: bool = True
    backup_paths: list[str] = field(default_factory=list)
    operation_class: str = ""   # key for policy memory
    can_always: bool = True     # False for cross-boundary ops
    script_path: str = ""       # set when interpreter execution detected


def _is_critical(path: str) -> bool:
    p = os.path.normpath(path)
    # Must be exact critical path OR subdirectory of critical path
    # "/" alone means root, not subdirectory
    if p in _CRITICAL and p != "/":
        return True
    return any(p.startswith(c + "/") for c in _CRITICAL if c != "/")


def _in_zone(path: str, zone: list[str]) -> bool:
    p = os.path.normpath(path)
    for z in zone:
        if z == "/":
            return True  # root zone means everything is trusted
        if p == z or p.startswith(z + "/"):
            return True
    return False


def _extract_paths(command: str, work_dir: str | None = None) -> list[str]:
    """Extract absolute, ~, and relative (./ ../) paths from a shell command."""
    raw = re.findall(r"(?<!\w)(~?/[^\s\"'\\;|&><*?{}]+|\.\.?/[^\s\"'\\;|&><*?{}]+)", command)
    result = []
    for p in raw:
        if p.startswith("~") or os.path.isabs(p):
            ep = os.path.normpath(os.path.expanduser(p))
        else:
            # relative path (./foo, ../foo) — resolve against work_dir or cwd
            base = work_dir or os.getcwd()
            ep = os.path.normpath(os.path.join(base, p))
        if not ep.startswith(("/proc/", "/sys/")) and ep not in ("/dev/null", "/dev/stdout", "/dev/stderr"):
            result.append(ep)
    return result


def check(task, work_dir: str | None = None,
          allowed_paths: list[str] | None = None) -> SafetyResult:
    tool: str = getattr(task, "tool", "")
    command: str = task.args.get("command", "")
    
    # Build trusted zone
    zone: list[str] = []
    if work_dir:
        zone.append(os.path.normpath(work_dir))
    for p in (allowed_paths or []):
        zone.append(os.path.normpath(p))

    # ── read-only tools: always allow, no confirmation needed ────────
    if tool in ("file_read", "grep", "glob", "web_fetch"):
        return SafetyResult(violation=False, reversible=True,
                            operation_class=tool)

    # ── file_edit ──────────────────────────────────────────────────────
    if tool == "file_edit":
        raw = task.args.get("path", "")
        if raw:
            expanded = os.path.expanduser(raw)
            if not os.path.isabs(expanded):
                expanded = os.path.join(work_dir or os.getcwd(), expanded)
            path = os.path.normpath(expanded)
        else:
            path = ""
        backup = [path] if path and os.path.isfile(path) else []
        if zone and path and not _in_zone(path, zone):
            # Outside trusted zone — warn regardless of critical status
            if _is_critical(path):
                return SafetyResult(
                    violation=False, requires_confirmation=True,
                    reversible=False, can_always=True,
                    reason=f"Edit to critical system path outside work_dir: {path}",
                    operation_class="file_edit:critical",
                )
            return SafetyResult(
                violation=False, requires_confirmation=True,
                reversible=False, can_always=True,
                reason=f"Edit outside trusted zone: {path}",
                operation_class="file_edit:outside",
            )
        # Inside zone (or no zone set) — critical check still warns but zone takes precedence
        if path and not zone and _is_critical(path):
            return SafetyResult(violation=False, requires_confirmation=True,
                                reversible=False, can_always=False,
                                reason=f"Edit to critical path: {path}",
                                operation_class="file_edit:critical")
        return SafetyResult(violation=False, reversible=True,
                            backup_paths=backup,
                            operation_class="file_edit:zone")

    # ── file_write ─────────────────────────────────────────────────────
    if tool == "file_write":
        raw = task.args.get("path", "")
        if raw:
            expanded = os.path.expanduser(raw)
            if not os.path.isabs(expanded):
                expanded = os.path.join(work_dir or os.getcwd(), expanded)
            path = os.path.normpath(expanded)
        else:
            path = ""
        backup = [path] if path and os.path.isfile(path) else []
        if zone and path and not _in_zone(path, zone):
            if _is_critical(path):
                return SafetyResult(
                    violation=False, requires_confirmation=True,
                    reversible=False, can_always=True,
                    reason=f"Write to critical system path outside work_dir: {path}",
                    operation_class="file_write:critical",
                )
            return SafetyResult(
                violation=False, requires_confirmation=True,
                reversible=False, can_always=True,
                reason=f"Write outside trusted zone: {path}",
                operation_class="file_write:outside",
            )
        if path and not zone and _is_critical(path):
            return SafetyResult(violation=False, requires_confirmation=True,
                                reversible=False, can_always=False,
                                reason=f"Write to critical path: {path}",
                                operation_class="file_write:critical")
        return SafetyResult(violation=False, reversible=True,
                            backup_paths=backup,
                            operation_class="file_write:zone")

    # ── shell_exec ─────────────────────────────────────────────────────
    if not command:
        return SafetyResult(violation=False, operation_class="shell:empty")

    # Fork bomb
    if _FORK_BOMB_RE.search(command):
        return SafetyResult(violation=True, reversible=False,
                            reason="Fork bomb pattern detected")

    paths = _extract_paths(command, work_dir=work_dir)
    has_write = bool(_WRITE_RE.search(command))
    is_destructive = has_write or bool(_BACKUP_RE.search(command))

    # Write/destructive op on critical path outside zone → warn, require confirmation
    # Paths inside the trusted zone are exempt (e.g. work_dir under /root)
    critical_outside_zone = [
        p for p in paths
        if _is_critical(p) and (not zone or not _in_zone(p, zone))
    ]
    if is_destructive and critical_outside_zone:
        return SafetyResult(violation=False, requires_confirmation=True,
                            reversible=False, can_always=True,
                            reason=f"Destructive operation on critical system path: {', '.join(critical_outside_zone)}",
                            operation_class="shell:critical")

    # Glob/brace expansion in command — paths are unresolvable at check time
    if re.search(r"[*?\[\]{]", command) and is_destructive:
        return SafetyResult(
            violation=False, requires_confirmation=True,
            reversible=False, can_always=True,
            reason="Destructive operation with glob/pattern expansion (target unknown until runtime)",
            operation_class="shell:destructive:glob",
        )

    # No paths extracted
    if not paths:
        if has_write:
            return SafetyResult(
                violation=False, requires_confirmation=True,
                reversible=False, can_always=True,
                reason="Write operation with unresolvable target path",
                operation_class="shell:write:no_path",
            )
        if _BACKUP_RE.search(command):
            # rm/mv with glob or variable — can't extract target, ask
            return SafetyResult(
                violation=False, requires_confirmation=True,
                reversible=False, can_always=True,
                reason="Destructive operation with unresolvable target (glob/variable)",
                operation_class="shell:destructive:no_path",
            )
        # Reads/status commands (ps, ls, echo, date, …) — allow
        return SafetyResult(violation=False, reversible=True,
                            operation_class="shell:read")

    # Paths found — check trusted zone
    if zone:
        outside = [p for p in paths if not _in_zone(p, zone)]
        if outside:
            return SafetyResult(
                violation=False, requires_confirmation=True,
                reversible=False, can_always=True,
                reason=f"Paths outside trusted zone: {', '.join(outside)}",
                operation_class="shell:outside",
            )

    # Script/interpreter execution — show content before allowing
    m = _INTERPRETER_RE.search(command)
    if m:
        script = os.path.normpath(os.path.expanduser(m.group(2)))
        if not os.path.isabs(script) and work_dir:
            script = os.path.normpath(os.path.join(work_dir, script))
        return SafetyResult(
            violation=False, requires_confirmation=True,
            reversible=True, can_always=True,
            reason=f"Script execution: {script}",
            operation_class="shell:script",
            script_path=script,
        )

    # All paths in trusted zone (or no zone configured)
    backup_paths = paths if is_destructive else []
    op_class = "shell:write:zone" if is_destructive else "shell:read"
    return SafetyResult(violation=False, reversible=True,
                        backup_paths=backup_paths, operation_class=op_class)


# ── Auto mode ─────────────────────────────────────────────────────────────────

# Command injection patterns
_INJECTION_RE = re.compile(r'\$\(|`')

# Leading KEY=value env-var assignments (e.g. PYTHONPATH=... FOO=bar cmd ...)
_ENV_PREFIX_RE = re.compile(r'^(\w+=\S*\s*)+')

DEFAULT_AUTO_WHITELIST: list[str] = [
    # ── Navigation ───────────────────────────────────────────────────────────
    "cd", "pwd", "pushd", "popd", "dirs",

    # ── File inspection ──────────────────────────────────────────────────────
    "ls", "ll", "la", "find", "locate", "which", "type", "file",
    "stat", "du", "df", "realpath", "basename", "dirname", "readlink",
    "lsblk", "lscpu", "lshw", "lsof",

    # ── File read ────────────────────────────────────────────────────────────
    "cat", "head", "tail", "less", "more", "bat",
    "wc", "od", "xxd", "hexdump", "strings",

    # ── File create / copy / move ─────────────────────────────────────────────
    "mkdir", "touch", "cp", "mv", "ln", "mktemp", "tee", "split", "install",

    # ── Archive ──────────────────────────────────────────────────────────────
    "tar", "zip", "unzip", "gzip", "gunzip", "bzip2", "bunzip2",
    "xz", "unxz", "zcat", "7z", "7za",

    # ── Text processing ──────────────────────────────────────────────────────
    "grep", "rg", "ag", "awk", "sed", "cut", "sort", "uniq",
    "diff", "patch", "tr", "xargs",
    "paste", "join", "expand", "unexpand", "nl", "fold", "column",
    "echo", "printf", "iconv",

    # ── Encoding / hashing ───────────────────────────────────────────────────
    "base64", "md5sum", "sha1sum", "sha256sum", "sha512sum", "shasum", "cksum",
    "openssl",

    # ── Search ───────────────────────────────────────────────────────────────
    "fd", "fzf",

    # ── Environment / system info ─────────────────────────────────────────────
    "env", "printenv", "date", "uname", "hostname", "uptime",
    "whoami", "id", "groups",
    "ps", "pgrep", "pidof", "top", "htop", "free", "vmstat", "iostat",
    "ulimit", "time", "bc",

    # ── Process control ───────────────────────────────────────────────────────
    "sleep", "wait", "timeout", "watch", "nohup",
    "true", "false", "test", "seq", "kill", "pkill",

    # ── Network (read / fetch) ─────────────────────────────────────────────────
    "curl", "wget", "http",
    "ping", "traceroute", "nslookup", "dig", "host",
    "netstat", "ss", "ifconfig", "ip",
    "ssh", "scp", "rsync",

    # ── Permissions ──────────────────────────────────────────────────────────
    "chmod", "chown", "chgrp", "umask",

    # ── Git ──────────────────────────────────────────────────────────────────
    "git",

    # ── Python ───────────────────────────────────────────────────────────────
    "python", "python3", "python3.10", "python3.11", "python3.12", "python3.13",
    "pip", "pip3", "pipenv", "poetry", "uv",
    "pytest", "mypy", "pyright", "ruff", "flake8", "pylint",
    "black", "isort", "autopep8",
    "ipython", "jupyter",
    "pyenv",

    # ── Node / JS ────────────────────────────────────────────────────────────
    "node", "npm", "npx", "yarn", "pnpm", "bun", "deno",
    "jest", "mocha", "vitest", "eslint", "prettier", "tsc",
    "nvm",

    # ── Compiled languages ────────────────────────────────────────────────────
    "gcc", "g++", "clang", "clang++", "cc", "c++",
    "make", "cmake", "ninja", "meson", "bear",
    "cargo", "rustc", "rustfmt",
    "go", "gofmt",
    "java", "javac", "jar", "mvn", "gradle",
    "dotnet",
    "swift", "swiftc",
    "ruby", "gem", "bundle", "rspec",
    "perl", "php", "composer",
    "lua", "Rscript",

    # ── Shell scripting ───────────────────────────────────────────────────────
    "bash", "sh", "zsh", "shellcheck",
    "source",

    # ── Data / serialisation ──────────────────────────────────────────────────
    "jq", "yq",

    # ── Containers / orchestration ────────────────────────────────────────────
    "docker", "docker-compose", "docker compose", "podman",
    "kubectl", "helm", "minikube", "kind",

    # ── Cloud CLIs ────────────────────────────────────────────────────────────
    "aws", "gcloud", "az",

    # ── Database clients ──────────────────────────────────────────────────────
    "mysql", "mysqldump", "psql", "pg_dump", "sqlite3",
    "redis-cli",

    # ── Misc ─────────────────────────────────────────────────────────────────
    "man", "tput", "stty", "locale",
    "systemctl", "service",
]


def _split_shell_ops(command: str) -> list[str]:
    """Split on && || | ; but NOT inside single- or double-quoted strings."""
    segments: list[str] = []
    current: list[str] = []
    in_single = False
    in_double = False
    i = 0
    while i < len(command):
        c = command[i]
        if c == "'" and not in_double:
            in_single = not in_single
            current.append(c)
        elif c == '"' and not in_single:
            in_double = not in_double
            current.append(c)
        elif not in_single and not in_double:
            two = command[i:i + 2]
            if two in ("&&", "||"):
                segments.append("".join(current))
                current = []
                i += 2
                continue
            elif c in ("|", ";"):
                segments.append("".join(current))
                current = []
            else:
                current.append(c)
        else:
            current.append(c)
        i += 1
    segments.append("".join(current))
    return segments


def _matches_whitelist(segment: str, whitelist: list[str]) -> bool:
    """Return True if the command segment (after stripping env-var prefixes) starts with a whitelist entry."""
    seg = _ENV_PREFIX_RE.sub("", segment).lower().strip()
    for entry in whitelist:
        e = entry.lower().strip()
        if seg == e or seg.startswith(e + " "):
            return True
    return False


def check_auto(task, work_dir: str | None = None,
               whitelist: list[str] | None = None) -> SafetyResult:
    """
    Auto mode safety check — no confirmations, hard boundaries only.

    Rules:
      file_read / grep / glob  → always allow
      file_write / file_edit   → allow only within work_dir, else hard deny
      shell_exec               → command injection → hard deny
                                 any segment not in whitelist → hard deny
                                 write/destructive op outside work_dir → hard deny
    """
    tool: str = getattr(task, "tool", "")
    command: str = task.args.get("command", "")
    wl: list[str] = whitelist if whitelist is not None else DEFAULT_AUTO_WHITELIST

    # ── read-only tools ────────────────────────────────────────────────────────
    if tool in ("file_read", "grep", "glob", "web_fetch"):
        return SafetyResult(violation=False, reversible=True, operation_class=tool)

    # ── file_write / file_edit ─────────────────────────────────────────────────
    if tool in ("file_write", "file_edit"):
        raw = task.args.get("path", "")
        if raw:
            expanded = os.path.expanduser(raw)
            if not os.path.isabs(expanded):
                expanded = os.path.join(work_dir or os.getcwd(), expanded)
            path = os.path.normpath(expanded)
        else:
            path = ""
        if work_dir and path:
            if not _in_zone(path, [os.path.normpath(work_dir)]):
                return SafetyResult(violation=True, reversible=False,
                                    reason=f"Auto mode: write outside work_dir blocked: {path}",
                                    operation_class=f"{tool}:outside")
        backup = [path] if path and os.path.isfile(path) else []
        return SafetyResult(violation=False, reversible=True,
                            backup_paths=backup, operation_class=f"{tool}:zone")

    # ── shell_exec ─────────────────────────────────────────────────────────────
    if not command:
        return SafetyResult(violation=False, operation_class="shell:empty")

    # Fork bomb
    if _FORK_BOMB_RE.search(command):
        return SafetyResult(violation=True, reversible=False,
                            reason="Fork bomb pattern detected")

    # Command injection
    if _INJECTION_RE.search(command):
        return SafetyResult(violation=True, reversible=False,
                            reason="Auto mode: command injection pattern blocked")

    # Whitelist check — every pipe/chain segment must be in whitelist
    for seg in _split_shell_ops(command):
        seg = seg.strip()
        if not seg:
            continue
        if not _matches_whitelist(seg, wl):
            first = seg.split()[0] if seg.split() else seg
            return SafetyResult(violation=True, reversible=False,
                                reason=f"Auto mode: '{first}' not in whitelist",
                                operation_class="shell:not_whitelisted")

    # Write/destructive outside work_dir
    has_write = bool(_WRITE_RE.search(command))
    is_destructive = has_write or bool(_BACKUP_RE.search(command))
    if is_destructive and work_dir:
        paths = _extract_paths(command, work_dir=work_dir)
        zone = [os.path.normpath(work_dir)]
        outside = [p for p in paths if not _in_zone(p, zone)]
        if outside:
            return SafetyResult(violation=True, reversible=False,
                                reason=f"Auto mode: write outside work_dir blocked: {', '.join(outside)}",
                                operation_class="shell:write:outside")

    backup_paths = _extract_paths(command, work_dir=work_dir) if is_destructive else []
    return SafetyResult(violation=False, reversible=True,
                        backup_paths=backup_paths, operation_class="shell:auto")
