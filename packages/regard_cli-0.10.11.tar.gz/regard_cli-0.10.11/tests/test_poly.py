"""Polymarket venue tests — contract + error paths.

Mocks the CLOB client, Gamma client, and web3 to test all 14 poly commands
without requiring py_clob_client to be installed.
"""

import json
from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

from hl_cli.main import app

runner = CliRunner()


# ---------------------------------------------------------------------------
# Mock data
# ---------------------------------------------------------------------------

MOCK_BALANCE = {"balance": "500.00", "allowances": {"USDC": "1000000"}}

MOCK_ORDERS = [
    {
        "id": "order-001",
        "market": "0xmarket1",
        "asset_id": "token-yes-001",
        "side": "BUY",
        "price": "0.55",
        "original_size": "100",
        "size_matched": "50",
        "status": "LIVE",
        "created_at": "2026-03-30T10:00:00Z",
    },
]

MOCK_POSITIONS = [
    {
        "asset_id": "token-yes-001",
        "market": "0xmarket1",
        "side": "BUY",
        "size": "100",
        "avg_price": "0.55",
        "cur_price": "0.60",
        "pnl": "5.00",
    },
]

MOCK_TRADES = [
    {
        "id": "trade-001",
        "market": "0xmarket1",
        "asset_id": "token-yes-001",
        "side": "BUY",
        "price": "0.55",
        "size": "100",
        "fee": "0.50",
        "created_at": "2026-03-30T10:00:00Z",
    },
]

MOCK_GAMMA_MARKET = {
    "id": "12345",
    "conditionId": "0xcondition",
    "question": "Will BTC hit $100k by 2027?",
    "slug": "btc-100k-2027",
    "clobTokenIds": '["token-yes-001", "token-no-001"]',
    "outcomePrices": '["0.55", "0.45"]',
    "active": True,
    "closed": False,
    "acceptingOrders": "true",
    "negRisk": "false",
    "volume24hr": "50000",
    "volumeNum": "1000000",
    "liquidityNum": "200000",
    "endDateIso": "2027-01-01T00:00:00Z",
    "bestBid": "0.54",
    "bestAsk": "0.56",
    "orderMinSize": "5",
    "orderPriceMinTickSize": "0.01",
}

MOCK_GAMMA_MARKETS = [MOCK_GAMMA_MARKET]

MOCK_ORDER_BOOK = MagicMock()
MOCK_ORDER_BOOK.bids = [MagicMock(price="0.54", size="200"), MagicMock(price="0.53", size="150")]
MOCK_ORDER_BOOK.asks = [MagicMock(price="0.56", size="180"), MagicMock(price="0.57", size="120")]

MOCK_EVENT = {
    "id": "event-001",
    "title": "US Presidential Election 2028",
    "slug": "us-presidential-election-2028",
    "markets": [
        {
            "id": "m1",
            "question": "Will Democrat win?",
            "clobTokenIds": ["t1", "t2"],
            "outcomePrices": ["0.45", "0.55"],
            "volume24hr": "10000",
            "active": True,
            "acceptingOrders": True,
        },
    ],
}

MOCK_WALLET = {"usdc_e": "0.00", "usdc": "5.00", "pol": "2.94", "rpc_ok": True}
MOCK_COLLATERAL = {"name": "USDC.e", "address": "0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174", "source": "on-chain"}


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def mock_clob():
    clob = MagicMock()
    clob.get_balance_allowance.return_value = MOCK_BALANCE
    clob.get_orders.return_value = list(MOCK_ORDERS)
    clob.get_positions.return_value = list(MOCK_POSITIONS)
    clob.get_trades.return_value = list(MOCK_TRADES)
    clob.get_order_book.return_value = MOCK_ORDER_BOOK
    clob.cancel.return_value = {"status": "ok"}
    clob.cancel_all.return_value = {"status": "ok"}
    return clob


@pytest.fixture
def mock_gamma():
    gamma = MagicMock()

    def _mock_get(path, params=None):
        resp = MagicMock()
        resp.status_code = 200
        if "/markets" in path:
            resp.json.return_value = list(MOCK_GAMMA_MARKETS)
        elif "/events" in path:
            resp.json.return_value = [MOCK_EVENT]
        else:
            resp.json.return_value = {}
        resp.raise_for_status = MagicMock()
        return resp

    gamma.get.side_effect = _mock_get
    return gamma


@pytest.fixture
def poly_patched(mock_clob, mock_gamma):
    patches = [
        patch("poly_cli.commands.orient.get_clob_client", return_value=mock_clob),
        patch("poly_cli.commands.orient._get_balance", return_value=dict(MOCK_BALANCE)),
        patch("poly_cli.commands.orient.get_wallet_balances", return_value=dict(MOCK_WALLET)),
        patch("poly_cli.commands.orient.get_collateral_token", return_value=dict(MOCK_COLLATERAL)),
        patch("poly_cli.commands.research.get_clob_client", return_value=mock_clob),
        patch("poly_cli.commands.research.get_gamma_client", return_value=mock_gamma),
        patch("poly_cli.commands.review.get_clob_client", return_value=mock_clob),
        patch("poly_cli.commands.act.get_clob_client", return_value=mock_clob),
        patch("poly_cli.commands.act.get_gamma_client", return_value=mock_gamma),
        patch("poly_cli.commands.act.get_web3", return_value=MagicMock()),
        patch("poly_cli.commands.act.check_geo_block"),
    ]
    for p in patches:
        p.start()
    yield {"clob": mock_clob, "gamma": mock_gamma}
    for p in patches:
        p.stop()


def parse(result) -> dict:
    stdout = result.stdout.strip()
    assert "Traceback" not in stdout, f"Traceback leaked: {stdout[:300]}"
    return json.loads(stdout)


# ---------------------------------------------------------------------------
# Orient commands
# ---------------------------------------------------------------------------

class TestPolyStatus:
    def test_basic(self, poly_patched):
        result = runner.invoke(app, ["poly", "status"])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["collateral_token"] == "USDC.e"
        assert d["data"]["open_order_count"] == 1

    def test_clob_failure_produces_json(self, poly_patched):
        poly_patched["clob"].get_orders.side_effect = Exception("CLOB down")
        result = runner.invoke(app, ["poly", "status"])
        d = parse(result)
        # Should still succeed — orders gracefully degrade to []
        assert d["ok"] is True
        assert d["data"]["open_order_count"] == 0


class TestPolyBalance:
    def test_basic(self, poly_patched):
        result = runner.invoke(app, ["poly", "balance"])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["clob_balance"] == "500.00"


class TestPolyPositions:
    def test_basic(self, poly_patched):
        result = runner.invoke(app, ["poly", "positions"])
        d = parse(result)
        assert d["ok"] is True
        assert len(d["data"]) == 1
        assert d["data"][0]["pnl"] == "5.00"

    def test_empty(self, poly_patched):
        poly_patched["clob"].get_positions.return_value = []
        result = runner.invoke(app, ["poly", "positions"])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"] == []


class TestPolyOrders:
    def test_basic(self, poly_patched):
        result = runner.invoke(app, ["poly", "orders"])
        d = parse(result)
        assert d["ok"] is True
        assert len(d["data"]) == 1
        assert d["data"][0]["order_id"] == "order-001"


# ---------------------------------------------------------------------------
# Research commands
# ---------------------------------------------------------------------------

class TestPolyMarkets:
    def test_basic(self, poly_patched):
        result = runner.invoke(app, ["poly", "markets"])
        d = parse(result)
        assert d["ok"] is True
        assert len(d["data"]) >= 1
        assert "question" in d["data"][0]


class TestPolyMarket:
    def test_by_slug(self, poly_patched):
        result = runner.invoke(app, ["poly", "market", "btc-100k-2027"])
        d = parse(result)
        assert d["ok"] is True
        assert "question" in d["data"]

    def test_not_found(self, poly_patched):
        poly_patched["gamma"].get.side_effect = lambda *a, **kw: MagicMock(
            json=MagicMock(return_value=[]), status_code=200
        )
        result = runner.invoke(app, ["poly", "market", "nonexistent-market"])
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "UNKNOWN_MARKET"


class TestPolyEvent:
    def test_by_slug(self, poly_patched):
        result = runner.invoke(app, ["poly", "event", "us-presidential-election-2028"])
        d = parse(result)
        assert d["ok"] is True
        assert "markets" in d["data"]
        assert d["data"]["market_count"] >= 1


class TestPolyPrices:
    def test_basic(self, poly_patched):
        result = runner.invoke(app, ["poly", "prices", "btc-100k-2027"])
        d = parse(result)
        assert d["ok"] is True
        assert "yes_price" in d["data"]


class TestPolyBook:
    def test_basic(self, poly_patched):
        result = runner.invoke(app, ["poly", "book", "btc-100k-2027"])
        d = parse(result)
        assert d["ok"] is True
        assert "bids" in d["data"]
        assert "asks" in d["data"]


# ---------------------------------------------------------------------------
# Review commands
# ---------------------------------------------------------------------------

class TestPolyTrades:
    def test_basic(self, poly_patched):
        result = runner.invoke(app, ["poly", "trades"])
        d = parse(result)
        assert d["ok"] is True
        assert len(d["data"]) == 1


# ---------------------------------------------------------------------------
# Act commands
# ---------------------------------------------------------------------------

class TestPolyOrder:
    def test_limit_order(self, poly_patched):
        """Limit buy on yes outcome — the full order placement path."""
        clob = poly_patched["clob"]
        clob.create_order.return_value = {"signed": True}
        clob.post_order.return_value = {"orderID": "ord-123", "status": "LIVE"}

        # Mock the py_clob_client.clob_types imports
        mock_types = MagicMock()
        mock_types.OrderArgs = MagicMock
        mock_types.MarketOrderArgs = MagicMock
        mock_types.OrderType.GTC = "GTC"
        mock_types.OrderType.FOK = "FOK"

        import sys
        sys.modules["py_clob_client"] = MagicMock()
        sys.modules["py_clob_client.clob_types"] = mock_types
        try:
            result = runner.invoke(app, ["poly", "order", "btc-100k-2027", "yes", "buy", "100", "0.55"])
            d = parse(result)
            assert d["ok"] is True
            assert d["data"]["order_id"] == "ord-123"
            assert d["data"]["outcome"] == "yes"
            assert d["data"]["side"] == "BUY"
        finally:
            sys.modules.pop("py_clob_client", None)
            sys.modules.pop("py_clob_client.clob_types", None)

    def test_market_order(self, poly_patched):
        """Market buy — FOK."""
        clob = poly_patched["clob"]
        clob.create_market_order.return_value = {"signed": True}
        clob.post_order.return_value = {"orderID": "ord-456"}

        mock_types = MagicMock()
        mock_types.OrderArgs = MagicMock
        mock_types.MarketOrderArgs = MagicMock
        mock_types.OrderType.GTC = "GTC"
        mock_types.OrderType.FOK = "FOK"

        import sys
        sys.modules["py_clob_client"] = MagicMock()
        sys.modules["py_clob_client.clob_types"] = mock_types
        try:
            result = runner.invoke(app, ["poly", "order", "btc-100k-2027", "no", "buy", "50", "--market"])
            d = parse(result)
            assert d["ok"] is True
            assert d["data"]["outcome"] == "no"
            assert d["data"]["type"] == "FOK"
        finally:
            sys.modules.pop("py_clob_client", None)
            sys.modules.pop("py_clob_client.clob_types", None)

    def test_invalid_outcome(self, poly_patched):
        result = runner.invoke(app, ["poly", "order", "btc-100k-2027", "maybe", "buy", "100", "0.55"])
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "INVALID_OUTCOME"

    def test_invalid_side(self, poly_patched):
        result = runner.invoke(app, ["poly", "order", "btc-100k-2027", "yes", "hold", "100", "0.55"])
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "INVALID_SIDE"

    def test_missing_price_no_market(self, poly_patched):
        result = runner.invoke(app, ["poly", "order", "btc-100k-2027", "yes", "buy", "100"])
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "MISSING_PRICE"

    def test_price_out_of_range(self, poly_patched):
        result = runner.invoke(app, ["poly", "order", "btc-100k-2027", "yes", "buy", "100", "1.5"])
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "INVALID_PRICE"

    def test_clob_error_produces_json(self, poly_patched):
        """CLOB failure during order placement → JSON error, not traceback."""
        mock_types = MagicMock()
        mock_types.OrderArgs = MagicMock
        mock_types.MarketOrderArgs = MagicMock
        mock_types.OrderType.GTC = "GTC"
        mock_types.OrderType.FOK = "FOK"

        clob = poly_patched["clob"]
        clob.create_order.side_effect = Exception("not enough balance for order")
        clob.post_order.side_effect = Exception("not enough balance for order")

        import sys
        sys.modules["py_clob_client"] = MagicMock()
        sys.modules["py_clob_client.clob_types"] = mock_types
        try:
            result = runner.invoke(app, ["poly", "order", "btc-100k-2027", "yes", "buy", "100", "0.55"])
            d = parse(result)
            assert d["ok"] is False
            assert d["error"]["code"] == "INSUFFICIENT_BALANCE"
        finally:
            sys.modules.pop("py_clob_client", None)
            sys.modules.pop("py_clob_client.clob_types", None)


class TestPolyCancel:
    def test_cancel(self, poly_patched):
        result = runner.invoke(app, ["poly", "cancel", "order-001"])
        d = parse(result)
        assert d["ok"] is True

    def test_cancel_all(self, poly_patched):
        result = runner.invoke(app, ["poly", "cancel-all"])
        d = parse(result)
        assert d["ok"] is True


# ---------------------------------------------------------------------------
# Contract: all poly commands produce valid JSON
# ---------------------------------------------------------------------------

POLY_COMMANDS = [
    ["poly", "status"],
    ["poly", "balance"],
    ["poly", "positions"],
    ["poly", "orders"],
    ["poly", "markets"],
    ["poly", "market", "btc-100k-2027"],
    ["poly", "event", "us-presidential-election-2028"],
    ["poly", "prices", "btc-100k-2027"],
    ["poly", "book", "btc-100k-2027"],
    ["poly", "trades"],
    ["poly", "cancel", "order-001"],
    ["poly", "cancel-all"],
]


@pytest.mark.parametrize("args", POLY_COMMANDS, ids=lambda a: " ".join(a))
def test_poly_contract(poly_patched, args):
    """Every poly command must produce valid JSON."""
    result = runner.invoke(app, args)
    d = parse(result)
    assert "ok" in d
