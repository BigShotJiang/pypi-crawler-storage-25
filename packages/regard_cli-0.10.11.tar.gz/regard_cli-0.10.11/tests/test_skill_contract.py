"""SKILL.md contract tests — verify documented commands match CLI reality.

Extracts CLI examples from SKILL.md and verifies:
1. Every documented command produces valid JSON (not tracebacks)
2. Every CLI command is documented in SKILL.md (no drift)
"""

import json
import re
from pathlib import Path

import pytest

from hl_cli.main import app


# ---------------------------------------------------------------------------
# Extract documented commands from SKILL.md
# ---------------------------------------------------------------------------

SKILL_PATH = Path(__file__).parent.parent.parent / "tabtabtabTABtab" / "regard-computer" / "skills" / "regard-computer" / "SKILL.md"


def _extract_hl_commands() -> list[str]:
    """Extract `regard hl <cmd>` examples from SKILL.md CLI reference section."""
    if not SKILL_PATH.exists():
        return []
    content = SKILL_PATH.read_text()
    # Match lines like: - `regard hl status` or - `regard hl order BTC buy 0.1 95000`
    pattern = r"`regard hl ([a-z][a-z0-9-]*)"
    return sorted(set(re.findall(pattern, content)))


def _extract_poly_commands() -> list[str]:
    """Extract `regard poly <cmd>` examples from SKILL.md."""
    if not SKILL_PATH.exists():
        return []
    content = SKILL_PATH.read_text()
    pattern = r"`regard poly ([a-z][a-z0-9-]*)"
    return sorted(set(re.findall(pattern, content)))


def _get_actual_hl_commands() -> set[str]:
    """Get actual registered HL command names from Typer app."""
    from hl_cli.main import hl_app
    commands = set()
    # Typer registers commands on the underlying Click group
    if hasattr(hl_app, "registered_commands"):
        for cmd in hl_app.registered_commands:
            if hasattr(cmd, "name") and cmd.name:
                commands.add(cmd.name)
    # Also check the Click group directly
    info = hl_app.info
    if hasattr(hl_app, "info") and hasattr(info, "name"):
        # Walk the Typer internals
        pass
    # Simpler: invoke --help and parse
    from typer.testing import CliRunner
    runner = CliRunner()
    result = runner.invoke(app, ["hl", "--help"])
    for line in result.output.split("\n"):
        line = line.strip()
        # Typer help format: "  command-name   Description"
        match = re.match(r"^([a-z][a-z0-9-]+)\s", line)
        if match:
            commands.add(match.group(1))
    return commands


def _get_actual_poly_commands() -> set[str]:
    """Get actual registered poly command names from Typer app."""
    from typer.testing import CliRunner
    runner = CliRunner()
    result = runner.invoke(app, ["poly", "--help"])
    commands = set()
    for line in result.output.split("\n"):
        line = line.strip()
        match = re.match(r"^([a-z][a-z0-9-]+)\s", line)
        if match:
            commands.add(match.group(1))
    return commands


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

DOCUMENTED_HL = _extract_hl_commands()
DOCUMENTED_POLY = _extract_poly_commands()


@pytest.mark.skipif(not SKILL_PATH.exists(), reason="SKILL.md not found")
def test_all_hl_commands_documented():
    """Every actual HL command must appear in SKILL.md."""
    actual = _get_actual_hl_commands()
    documented = set(DOCUMENTED_HL)
    undocumented = actual - documented
    assert not undocumented, f"HL commands exist but not in SKILL.md: {undocumented}"


@pytest.mark.skipif(not SKILL_PATH.exists(), reason="SKILL.md not found")
def test_all_poly_commands_documented():
    """Every actual poly command must appear in SKILL.md."""
    actual = _get_actual_poly_commands()
    documented = set(DOCUMENTED_POLY)
    undocumented = actual - documented
    assert not undocumented, f"Poly commands exist but not in SKILL.md: {undocumented}"


@pytest.mark.skipif(not SKILL_PATH.exists(), reason="SKILL.md not found")
def test_no_stale_hl_docs():
    """Every documented HL command must still exist in the CLI."""
    actual = _get_actual_hl_commands()
    documented = set(DOCUMENTED_HL)
    stale = documented - actual
    assert not stale, f"SKILL.md references non-existent HL commands: {stale}"


@pytest.mark.skipif(not SKILL_PATH.exists(), reason="SKILL.md not found")
def test_no_stale_poly_docs():
    """Every documented poly command must still exist in the CLI."""
    actual = _get_actual_poly_commands()
    documented = set(DOCUMENTED_POLY)
    stale = documented - actual
    assert not stale, f"SKILL.md references non-existent poly commands: {stale}"


@pytest.mark.skipif(not SKILL_PATH.exists(), reason="SKILL.md not found")
def test_documented_command_count():
    """Sanity check — SKILL.md should document a reasonable number of commands."""
    assert len(DOCUMENTED_HL) >= 15, f"Only {len(DOCUMENTED_HL)} HL commands documented"
    assert len(DOCUMENTED_POLY) >= 8, f"Only {len(DOCUMENTED_POLY)} poly commands documented"
