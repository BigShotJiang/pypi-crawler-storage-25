"""Session command tests — transcript parsing, trade extraction, tilt.

Creates mock JSONL transcripts and tests that session commands
correctly parse trades, research chains, and session context.
"""

import json
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch

import pytest
from typer.testing import CliRunner

from hl_cli.main import app
from hl_cli.commands.session import (
    _extract_entries,
    _extract_trades,
    _extract_research,
    _parse_hl_order,
    _parse_time_modifier,
    _get_session_base_path,
)

runner = CliRunner()


# ---------------------------------------------------------------------------
# Mock transcript data
# ---------------------------------------------------------------------------

def _ts(hour=10, minute=0):
    return datetime(2026, 3, 31, hour, minute, 0, tzinfo=timezone.utc).isoformat()


def _user_entry(text, hour=10, minute=0):
    return json.dumps({
        "type": "user",
        "timestamp": _ts(hour, minute),
        "message": {"content": text},
    })


def _assistant_entry(text, hour=10, minute=1):
    return json.dumps({
        "type": "assistant",
        "timestamp": _ts(hour, minute),
        "message": {"content": [{"type": "text", "text": text}]},
    })


def _tool_use_entry(name, inp, hour=10, minute=2):
    return json.dumps({
        "type": "assistant",
        "timestamp": _ts(hour, minute),
        "message": {"content": [{"type": "tool_use", "name": name, "input": inp}]},
    })


def _tool_result_entry(content, hour=10, minute=3):
    return json.dumps({
        "type": "user",
        "timestamp": _ts(hour, minute),
        "message": {"content": [{"type": "tool_result", "content": content}]},
    })


MOCK_TRANSCRIPT = "\n".join([
    _user_entry("let's look at BTC", 10, 0),
    _assistant_entry("Looking at BTC. Let me check the market.", 10, 1),
    _tool_use_entry("Bash", {"command": "regard hl order BTC buy 0.1 65000"}, 10, 5),
    _tool_result_entry(json.dumps({"ok": True, "data": {"status": "filled", "oid": 12345, "avg_price": "65000.0"}}), 10, 6),
    _assistant_entry("Order filled at 65000.", 10, 7),
    _user_entry("now check ETH funding", 10, 10),
    _tool_use_entry("Skill", {"skill": "chans-research"}, 10, 15),
    _tool_result_entry("Some 4chan research results", 10, 16),
    _tool_use_entry("WebSearch", {"query": "ETH funding rate"}, 10, 20),
    _tool_result_entry("Search results", 10, 21),
    _tool_use_entry("Bash", {"command": "regard hl order ETH sell 1.0 --market --reduce-only"}, 11, 0),
    _tool_result_entry(json.dumps({"ok": True, "data": {"status": "filled", "oid": 12346, "avg_price": "3250.0"}}), 11, 1),
]) + "\n"


@pytest.fixture
def mock_session_dir(tmp_path):
    """Create a mock session directory with a transcript file."""
    session_dir = tmp_path / ".claude" / "projects" / "-test-cwd"
    session_dir.mkdir(parents=True)
    transcript = session_dir / "a1b2c3d4-e5f6-7890-abcd-ef1234567890.jsonl"
    transcript.write_text(MOCK_TRANSCRIPT)
    return session_dir


# ---------------------------------------------------------------------------
# Unit tests — parsing functions
# ---------------------------------------------------------------------------

class TestExtractEntries:
    def test_basic(self, mock_session_dir):
        files = list(mock_session_dir.glob("*.jsonl"))
        entries = _extract_entries(str(files[0]))
        assert len(entries) > 0
        # Should have user, assistant, tool_use, and tool_result entries
        roles = {r for _, r, _ in entries}
        assert "U" in roles
        assert "A" in roles
        assert "T" in roles
        assert "R" in roles

    def test_malformed_lines_skipped(self, tmp_path):
        f = tmp_path / "test.jsonl"
        f.write_text("not json\n{}\n" + _user_entry("hello") + "\n")
        entries = _extract_entries(str(f))
        assert len(entries) == 1
        assert entries[0][2] == "hello"

    def test_empty_file(self, tmp_path):
        f = tmp_path / "empty.jsonl"
        f.write_text("")
        entries = _extract_entries(str(f))
        assert entries == []


class TestExtractTrades:
    def test_finds_trades(self, mock_session_dir):
        files = list(mock_session_dir.glob("*.jsonl"))
        entries = _extract_entries(str(files[0]))
        trades = _extract_trades(entries)
        assert len(trades) == 2
        assert trades[0]["asset"] == "BTC"
        assert trades[0]["side"] == "buy"
        assert trades[0]["size"] == "0.1"
        assert trades[1]["asset"] == "ETH"
        assert trades[1]["side"] == "sell"
        assert trades[1]["reduce_only"] is True

    def test_trade_result_parsed(self, mock_session_dir):
        files = list(mock_session_dir.glob("*.jsonl"))
        entries = _extract_entries(str(files[0]))
        trades = _extract_trades(entries)
        assert trades[0].get("result", {}).get("status") == "filled"
        assert trades[0]["result"]["avg_price"] == "65000.0"


class TestExtractResearch:
    def test_finds_research_skills(self, mock_session_dir):
        files = list(mock_session_dir.glob("*.jsonl"))
        entries = _extract_entries(str(files[0]))
        research = _extract_research(entries)
        assert len(research) >= 2
        skills = [r["skill"] for r in research]
        assert "chans-research" in skills
        assert "WebSearch" in skills


class TestParseHlOrder:
    def test_limit_order(self):
        result = _parse_hl_order("regard hl order BTC buy 0.1 65000")
        assert result["asset"] == "BTC"
        assert result["side"] == "buy"
        assert result["size"] == "0.1"
        assert result["price"] == "65000"
        assert result["market"] is False

    def test_market_order(self):
        result = _parse_hl_order("regard hl order ETH sell 1.0 --market")
        assert result["asset"] == "ETH"
        assert result["side"] == "sell"
        assert result["market"] is True
        assert result["price"] is None

    def test_reduce_only(self):
        result = _parse_hl_order("regard hl order ETH sell 1.0 --market --reduce-only")
        assert result["reduce_only"] is True

    def test_too_short(self):
        result = _parse_hl_order("regard hl order BTC")
        assert result is None

    def test_hip3_asset(self):
        result = _parse_hl_order("regard hl order xyz:NATGAS sell 12 2.85")
        assert result["asset"] == "xyz:NATGAS"
        assert result["price"] == "2.85"


class TestParseTimeModifier:
    def test_default(self):
        start, end = _parse_time_modifier(None)
        assert start.hour == 0
        assert end > start

    def test_days(self):
        start, end = _parse_time_modifier("5d")
        assert (end - start).days >= 4

    def test_weeks(self):
        start, end = _parse_time_modifier("2w")
        assert (end - start).days >= 13

    def test_max(self):
        start, end = _parse_time_modifier("max")
        assert start.year == 1  # datetime.min

    def test_ytd(self):
        start, end = _parse_time_modifier("ytd")
        assert start.month == 1
        assert start.day == 1

    def test_date_range(self):
        start, end = _parse_time_modifier("03/10-03/17")
        assert start.month == 3
        assert start.day == 10
        assert end.day == 17


# ---------------------------------------------------------------------------
# Integration tests — CLI invocation with mocked session dir
# ---------------------------------------------------------------------------

@pytest.fixture
def session_env(mock_session_dir):
    """Patch session discovery to use mock dir."""
    cwd = "/test-cwd"
    with patch("hl_cli.commands.session._get_session_base_path", return_value=str(mock_session_dir)):
        yield


class TestSessionCLI:
    def test_ctx_produces_json(self, session_env):
        result = runner.invoke(app, ["session", "ctx"])
        stdout = result.stdout.strip()
        assert "Traceback" not in stdout
        # ctx outputs JSON
        assert result.exit_code == 0

    def test_no_session_produces_json_error(self):
        with patch("hl_cli.commands.session._get_session_base_path", return_value=None):
            result = runner.invoke(app, ["session", "ctx"])
            stdout = result.stdout.strip()
            data = json.loads(stdout)
            assert data["ok"] is False
            assert data["error"]["code"] == "NO_SESSION_DIR"

    def test_gm_no_session_produces_json(self):
        with patch("hl_cli.commands.session._get_session_base_path", return_value=None):
            result = runner.invoke(app, ["session", "gm"])
            stdout = result.stdout.strip()
            data = json.loads(stdout)
            assert data["ok"] is False

    def test_gg_no_session_produces_json(self):
        with patch("hl_cli.commands.session._get_session_base_path", return_value=None):
            result = runner.invoke(app, ["session", "gg"])
            stdout = result.stdout.strip()
            data = json.loads(stdout)
            assert data["ok"] is False
