"""Act commands — approve, order, cancel, cancel-all."""

from typing import Annotated, Optional

import typer

from hl_cli.output import die, output
from poly_cli.client import (
    CONTRACTS,
    CTF_ABI,
    ERC20_ABI,
    check_geo_block,
    get_clob_client,
    get_collateral_token,
    get_gamma_client,
    get_web3,
)
from poly_cli.main import poly_app
from poly_cli.market import resolve_market

SIDE_MAP = {"buy": "BUY", "sell": "SELL"}
MAX_UINT256 = 2**256 - 1


@poly_app.command()
def approve(ctx: typer.Context):
    """Approve USDC and CTF tokens for Polymarket contracts.

    Sends 7 on-chain transactions on Polygon:
    - 4 USDC.e approvals (CTF, Exchange, Neg Risk Exchange, Neg Risk Adapter)
    - 3 CTF setApprovalForAll (Exchange, Neg Risk Exchange, Neg Risk Adapter)

    Requires POL for gas. Only needed once per wallet.
    """
    opts = ctx.obj
    from poly_cli.client import _get_key, get_address

    key = _get_key()
    if not key.startswith("0x"):
        key = f"0x{key}"
    address = get_address()

    w3 = get_web3()
    if not w3.is_connected():
        die("network_error", "RPC_UNREACHABLE", "Cannot connect to Polygon RPC",
            hint="Set POLYGON_RPC env var to a working RPC URL", exit_code=6)

    account = w3.eth.account.from_key(key)
    checksummed = w3.to_checksum_address(address)

    # Discover collateral token from on-chain (not hardcoded)
    collateral = get_collateral_token(w3)
    collateral_addr = collateral["address"]
    collateral_name = collateral["name"]

    usdc = w3.eth.contract(address=w3.to_checksum_address(collateral_addr), abi=ERC20_ABI)
    ctf = w3.eth.contract(address=w3.to_checksum_address(CONTRACTS["CTF"]), abi=CTF_ABI)

    # Check existing allowances — skip what's already approved (idempotent)
    erc20_approvals = [
        (f"{collateral_name}→CTF", CONTRACTS["CTF"]),
        (f"{collateral_name}→Exchange", CONTRACTS["CTF_EXCHANGE"]),
        (f"{collateral_name}→NegRiskExchange", CONTRACTS["NEG_RISK_CTF_EXCHANGE"]),
        (f"{collateral_name}→NegRiskAdapter", CONTRACTS["NEG_RISK_ADAPTER"]),
    ]
    ctf_approvals = [
        ("CTF→Exchange", CONTRACTS["CTF_EXCHANGE"]),
        ("CTF→NegRiskExchange", CONTRACTS["NEG_RISK_CTF_EXCHANGE"]),
        ("CTF→NegRiskAdapter", CONTRACTS["NEG_RISK_ADAPTER"]),
    ]

    pending = []
    for label, spender in erc20_approvals:
        try:
            allowance = usdc.functions.allowance(checksummed, w3.to_checksum_address(spender)).call()
            if allowance < 10**18:  # less than 1T USDC equivalent
                pending.append((label, usdc, "approve", spender, MAX_UINT256))
        except Exception:
            pending.append((label, usdc, "approve", spender, MAX_UINT256))

    for label, spender in ctf_approvals:
        try:
            approved = ctf.functions.isApprovedForAll(checksummed, w3.to_checksum_address(spender)).call()
            if not approved:
                pending.append((label, ctf, "setApprovalForAll", spender, True))
        except Exception:
            pending.append((label, ctf, "setApprovalForAll", spender, True))

    if not pending:
        output({"approvals": [], "count": 0, "message": "All approvals already set"}, opts["fields"])
        return

    tx_hashes = []
    nonce = w3.eth.get_transaction_count(checksummed)

    import time
    for label, contract, method, spender, value in pending:
        try:
            fn = getattr(contract.functions, method)
            tx = fn(w3.to_checksum_address(spender), value).build_transaction({
                "from": checksummed,
                "nonce": nonce,
                "gas": 100_000,
                "gasPrice": w3.eth.gas_price,
                "chainId": 137,
            })
            signed = account.sign_transaction(tx)
            tx_hash = w3.eth.send_raw_transaction(signed.raw_transaction)
            receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=120)

            if receipt["status"] != 1:
                die("venue_error", "APPROVAL_FAILED", f"{label} tx reverted: {tx_hash.hex()}", exit_code=4)

            tx_hashes.append({"label": label, "tx_hash": tx_hash.hex()})
            nonce += 1
            time.sleep(5)  # avoid rate limits on public RPCs
        except SystemExit:
            raise
        except Exception as e:
            die("venue_error", "APPROVAL_FAILED", f"{label}: {e}", exit_code=4)

    output({"approvals": tx_hashes, "count": len(tx_hashes)}, opts["fields"])


@poly_app.command()
def order(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Market ID, condition ID, or slug")],
    outcome: Annotated[str, typer.Argument(help="yes or no")],
    side: Annotated[str, typer.Argument(help="buy or sell")],
    size: Annotated[float, typer.Argument(help="Number of shares")],
    price: Annotated[Optional[float], typer.Argument(help="Limit price (probability 0.01-0.99)")] = None,
    market_order: Annotated[bool, typer.Option("--market", help="Market order (fill or kill)")] = False,
):
    """Place an order on a prediction market outcome."""
    opts = ctx.obj

    # Validate inputs
    outcome_lower = outcome.lower()
    if outcome_lower not in ("yes", "no"):
        die("validation_error", "INVALID_OUTCOME", f"Outcome must be 'yes' or 'no', got '{outcome}'", exit_code=2)

    side_upper = SIDE_MAP.get(side.lower())
    if not side_upper:
        die("validation_error", "INVALID_SIDE", f"Side must be 'buy' or 'sell', got '{side}'", exit_code=2)

    if not market_order and price is None:
        die("validation_error", "MISSING_PRICE", "Specify a price or use --market", exit_code=2)

    if price is not None and (price < 0.01 or price > 0.99):
        die("validation_error", "INVALID_PRICE", f"Price must be between 0.01 and 0.99, got {price}", exit_code=2)

    # Check geo-restriction before any CLOB call
    check_geo_block()

    # Resolve market
    gamma = get_gamma_client()
    m = resolve_market(identifier, gamma)
    if not m:
        die("validation_error", "UNKNOWN_MARKET", f"No market found for '{identifier}'", exit_code=2)
    if not m["accepting_orders"]:
        die("venue_error", "MARKET_CLOSED", f"Market is not accepting orders: {m['question']}", exit_code=4)

    token_id = m["yes_token_id"] if outcome_lower == "yes" else m["no_token_id"]
    if not token_id:
        die("validation_error", "NO_TOKEN", f"No {outcome} token found", exit_code=2)

    # Place order
    clob = get_clob_client()

    try:
        from py_clob_client.clob_types import MarketOrderArgs, OrderArgs, OrderType

        if market_order:
            order_args = MarketOrderArgs(
                token_id=token_id,
                amount=size,
                fee_rate_bps=0,
            )
            signed = clob.create_market_order(order_args)
            resp = clob.post_order(signed, OrderType.FOK)
        else:
            # Round price to tick size
            tick = m["tick_size"]
            rounded_price = round(round(price / tick) * tick, 4)

            order_args = OrderArgs(
                price=rounded_price,
                size=size,
                side=side_upper,
                token_id=token_id,
            )
            signed = clob.create_order(order_args)
            resp = clob.post_order(signed, OrderType.GTC)

    except Exception as e:
        err_str = str(e)
        if "not enough balance" in err_str.lower():
            die("venue_error", "INSUFFICIENT_BALANCE", err_str,
                hint="Check balance with: regard poly balance",
                exit_code=4)
        if "restricted" in err_str.lower() or "403" in err_str:
            die("geo_error", "GEO_BLOCKED", err_str,
                hint="Polymarket trading requires a non-US/non-SG IP (e.g. Ireland VPN)",
                exit_code=4)
        die("venue_error", "ORDER_REJECTED", err_str, exit_code=4)

    order_id = ""
    if isinstance(resp, dict):
        order_id = resp.get("orderID", resp.get("id", ""))

    output({
        "order_id": order_id,
        "market": m["question"],
        "outcome": outcome_lower,
        "side": side_upper,
        "size": str(size),
        "price": str(price) if price else "market",
        "type": "FOK" if market_order else "GTC",
        "response": resp,
    }, opts["fields"])


@poly_app.command()
def cancel(
    ctx: typer.Context,
    order_id: Annotated[str, typer.Argument(help="Order ID to cancel")],
):
    """Cancel an open order."""
    opts = ctx.obj
    check_geo_block()
    clob = get_clob_client()

    try:
        resp = clob.cancel(order_id)
    except Exception as e:
        die("venue_error", "CANCEL_FAILED", str(e), exit_code=4)

    output({"order_id": order_id, "response": resp}, opts["fields"])


@poly_app.command(name="cancel-all")
def cancel_all(ctx: typer.Context):
    """Cancel all open orders."""
    opts = ctx.obj
    check_geo_block()
    clob = get_clob_client()

    try:
        resp = clob.cancel_all()
    except Exception as e:
        die("venue_error", "CANCEL_FAILED", str(e), exit_code=4)

    output({"response": resp}, opts["fields"])
