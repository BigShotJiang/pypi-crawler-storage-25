"""Market resolution — resolve identifiers to Polymarket market data."""

import json

import httpx


def resolve_market(identifier: str, gamma: httpx.Client) -> dict | None:
    """Resolve a market by condition ID, market ID, slug, or question substring.

    Returns a normalized MarketInfo dict or None if not found.
    """
    # Try by condition ID (0x...)
    if identifier.startswith("0x"):
        resp = gamma.get("/markets", params={"condition_id": identifier})
        markets = resp.json()
        if markets:
            return _normalize(markets[0] if isinstance(markets, list) else markets)

    # Try by numeric market ID
    if identifier.isdigit():
        try:
            resp = gamma.get(f"/markets/{identifier}")
            if resp.status_code == 200:
                return _normalize(resp.json())
        except Exception:
            pass

    # Try by slug
    resp = gamma.get("/markets", params={"slug": identifier})
    markets = resp.json()
    if markets:
        return _normalize(markets[0] if isinstance(markets, list) else markets)

    # Fallback: search by question text
    resp = gamma.get("/markets", params={"q": identifier, "limit": 1, "active": "true"})
    markets = resp.json()
    if markets:
        return _normalize(markets[0])

    return None


def _normalize(m: dict) -> dict:
    """Normalize a Gamma API market response to a standard shape."""
    raw_clob = m.get("clobTokenIds", "[]")
    clob_ids = json.loads(raw_clob) if isinstance(raw_clob, str) else (raw_clob or [])
    raw_prices = m.get("outcomePrices", "[]")
    outcome_prices = json.loads(raw_prices) if isinstance(raw_prices, str) else (raw_prices or [])

    return {
        "market_id": m.get("id", ""),
        "condition_id": m.get("conditionId", ""),
        "question": m.get("question", ""),
        "slug": m.get("slug", ""),
        "yes_token_id": clob_ids[0] if len(clob_ids) > 0 else "",
        "no_token_id": clob_ids[1] if len(clob_ids) > 1 else "",
        "yes_price": float(outcome_prices[0]) if len(outcome_prices) > 0 else 0.0,
        "no_price": float(outcome_prices[1]) if len(outcome_prices) > 1 else 0.0,
        "active": m.get("active", False),
        "closed": m.get("closed", False),
        "accepting_orders": m.get("acceptingOrders", "false").lower() == "true" if isinstance(m.get("acceptingOrders"), str) else bool(m.get("acceptingOrders", False)),
        "neg_risk": m.get("negRisk", "false").lower() == "true" if isinstance(m.get("negRisk"), str) else bool(m.get("negRisk", False)),
        "volume_24h": float(m.get("volume24hr", 0) or 0),
        "volume": float(m.get("volumeNum", 0) or 0),
        "liquidity": float(m.get("liquidityNum", 0) or 0),
        "end_date": m.get("endDateIso", ""),
        "best_bid": m.get("bestBid", ""),
        "best_ask": m.get("bestAsk", ""),
        "min_order_size": float(m.get("orderMinSize", 5) or 5),
        "tick_size": float(m.get("orderPriceMinTickSize", 0.01) or 0.01),
    }
