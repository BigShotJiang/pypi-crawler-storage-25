"""regard — AI trading partner for the unified speculator."""

import json
import sys
from importlib.metadata import version as pkg_version
from typing import Optional

import click
import typer


def _version_callback(value: bool):
    if value:
        print(pkg_version("regard-cli"))
        raise typer.Exit()


app = typer.Typer(
    name="regard",
    add_completion=False,
    no_args_is_help=True,
    help="AI trading partner for the unified speculator.",
    pretty_exceptions_enable=False,
    pretty_exceptions_show_locals=False,
    rich_markup_mode=None,
)

hl_app = typer.Typer(
    name="hl",
    no_args_is_help=True,
    help="Hyperliquid perp trading. JSON output by default.",
    pretty_exceptions_enable=False,
)


# ---------------------------------------------------------------------------
# Global safety net — every exit path must produce valid JSON on stdout.
# Monkey-patch Click exception classes so even Typer parse errors (missing
# args, unknown flags, bad types) produce JSON instead of Rich formatting.
# ---------------------------------------------------------------------------

def _json_show(self, file=None):
    err = {
        "ok": False,
        "error": {
            "type": "validation_error",
            "code": "USAGE_ERROR",
            "message": self.format_message(),
            "retryable": False,
        },
        "meta": {"exit_code": 2},
    }
    print(json.dumps(err, separators=(",", ":")), file=file or sys.stdout, flush=True)

click.ClickException.show = _json_show
click.UsageError.show = _json_show
click.BadParameter.show = _json_show


@app.callback()
def main(
    ctx: typer.Context,
    version: bool = typer.Option(False, "--version", callback=_version_callback, is_eager=True, help="Show version and exit"),
    fields: Optional[str] = typer.Option(None, "--fields", help="Comma-separated field projection"),
    verbose: bool = typer.Option(False, "--verbose", help="Debug info to stderr"),
):
    """Regard CLI — multi-venue trading."""
    ctx.ensure_object(dict)
    ctx.obj["fields"] = fields
    ctx.obj["verbose"] = verbose


@hl_app.callback()
def hl_main(
    ctx: typer.Context,
    testnet: bool = typer.Option(False, "--testnet", help="Use testnet endpoints"),
):
    """Hyperliquid perp trading CLI."""
    ctx.ensure_object(dict)
    ctx.obj["testnet"] = testnet


app.add_typer(hl_app)

# Session commands (top-level, not venue-specific)
from hl_cli.commands.session import session_app  # noqa: E402
app.add_typer(session_app)

# Update check (top-level)
from hl_cli.commands.update import update_app  # noqa: E402
app.add_typer(update_app)

# Auth setup (top-level)
from hl_cli.commands.auth import auth_app  # noqa: E402
app.add_typer(auth_app)

# Register all hl venue commands — must be after hl_app is defined
from hl_cli.commands import orient, research, act, review  # noqa: E402, F401

# Polymarket venue
from poly_cli.main import poly_app  # noqa: E402
app.add_typer(poly_app)

# Cross-venue portfolio
from hl_cli.commands.portfolio import portfolio_app  # noqa: E402
app.add_typer(portfolio_app)


# ---------------------------------------------------------------------------
# Wrapped entry point — last-resort catch for any exception that escapes
# all command-level handlers. Ensures stdout is always valid JSON.
# ---------------------------------------------------------------------------

def run():
    """Entry point with global exception safety net."""
    try:
        app()
    except SystemExit:
        raise
    except Exception as e:
        error = {
            "ok": False,
            "error": {
                "type": "internal_error",
                "code": type(e).__name__,
                "message": str(e),
                "retryable": False,
            },
            "meta": {"exit_code": 7},
        }
        print(json.dumps(error, separators=(",", ":")), flush=True)
        sys.exit(7)
