"""Output formatting, errors, and time utilities."""

import json
import sys
from datetime import datetime, timezone


def output(data, fields=None, display=None):
    """Write data to stdout as envelope JSON."""
    if fields:
        data = _project(data, fields)
    now_utc = datetime.now(timezone.utc)
    now_local = now_utc.astimezone()
    envelope = {
        "ok": True,
        "data": data,
        "meta": {
            "timestamp": now_utc.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "local_time": now_local.strftime("%Y-%m-%d %H:%M %Z"),
            "day": now_local.strftime("%A"),
        },
    }
    if display is not None:
        envelope["display"] = display
    sys.stdout.write(json.dumps(envelope, separators=(",", ":")) + "\n")


def die(
    error_type: str,
    code: str,
    message: str,
    *,
    hint: str | None = None,
    retryable: bool = False,
    param: str | None = None,
    extra: dict | None = None,
    exit_code: int = 2,
):
    """Write structured error envelope to stdout and exit."""
    error = {"type": error_type, "code": code, "message": message, "retryable": retryable}
    if hint:
        error["hint"] = hint
    if param:
        error["param"] = param
    if extra:
        error.update(extra)
    envelope = {
        "ok": False,
        "error": error,
        "meta": {"exit_code": exit_code},
    }
    sys.stdout.write(json.dumps(envelope, separators=(",", ":")) + "\n")
    raise SystemExit(exit_code)


def debug(message: str, verbose: bool = False):
    """Write debug info to stderr."""
    if verbose:
        sys.stderr.write(f"[debug] {message}\n")


def _project(data, fields_str: str):
    """Filter data to only include specified fields."""
    fields = {f.strip() for f in fields_str.split(",")}
    if isinstance(data, list):
        return [
            {k: v for k, v in item.items() if k in fields}
            for item in data
            if isinstance(item, dict)
        ]
    elif isinstance(data, dict):
        return {k: v for k, v in data.items() if k in fields}
    return data


def parse_time(s: str) -> int:
    """Parse time string to unix milliseconds."""
    dt = datetime.fromisoformat(s)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return int(dt.timestamp() * 1000)


def format_timestamp(ms) -> str:
    """Format unix milliseconds to ISO 8601."""
    if isinstance(ms, (int, float)) and ms > 0:
        dt = datetime.fromtimestamp(ms / 1000, tz=timezone.utc)
        return dt.strftime("%Y-%m-%dT%H:%M:%SZ")
    return str(ms)


INTERVAL_MS = {
    "1m": 60_000,
    "3m": 180_000,
    "5m": 300_000,
    "15m": 900_000,
    "30m": 1_800_000,
    "1h": 3_600_000,
    "2h": 7_200_000,
    "4h": 14_400_000,
    "8h": 28_800_000,
    "12h": 43_200_000,
    "1d": 86_400_000,
    "3d": 259_200_000,
    "1w": 604_800_000,
    "1M": 2_592_000_000,
}


def interval_to_ms(interval: str) -> int:
    """Convert candle interval string to milliseconds."""
    ms = INTERVAL_MS.get(interval)
    if ms is None:
        valid = ", ".join(INTERVAL_MS.keys())
        die("validation_error", "INVALID_INTERVAL", f"Invalid interval: {interval}", hint=f"Valid intervals: {valid}", param="interval")
    return ms


# ---------------------------------------------------------------------------
# Visual primitives — pre-rendered Unicode for universal display
# Works on: terminal, Claude Code desktop/web, Telegram, iMessage
# ---------------------------------------------------------------------------

_SPARK_CHARS = "▁▂▃▄▅▆▇█"


def sparkline(values: list[float | int]) -> str:
    """Render a sparkline from numeric values. Returns empty string if <2 values."""
    nums = [v for v in values if v is not None]
    if len(nums) < 2:
        return ""
    lo, hi = min(nums), max(nums)
    spread = hi - lo
    if spread == 0:
        return _SPARK_CHARS[3] * len(nums)
    return "".join(_SPARK_CHARS[min(int((v - lo) / spread * 7), 7)] for v in nums)


def bar(value: float, max_value: float, width: int = 20) -> str:
    """Render a horizontal bar. Full blocks + optional half block."""
    if max_value <= 0 or value <= 0:
        return ""
    ratio = min(value / max_value, 1.0)
    full = ratio * width
    n_full = int(full)
    frac = full - n_full
    s = "█" * n_full
    if frac >= 0.5 and n_full < width:
        s += "▌"
    return s


def make_table(rows: list[dict], columns: list[tuple[str, str, str]]) -> str:
    """Render a monospace-aligned table.

    columns: list of (key, header, align) where align is '<' or '>'.
    Returns the complete table string with header + separator + data rows.
    """
    if not rows:
        return ""

    # Compute column widths
    widths = []
    for key, header, _ in columns:
        col_vals = [_fmt_cell(r.get(key, "")) for r in rows]
        widths.append(max(len(header), max((len(v) for v in col_vals), default=0)))

    # Header
    hdr_parts = []
    for (_, header, align), w in zip(columns, widths):
        hdr_parts.append(f"{header:{'<' if align == '<' else '>'}{w}}")
    lines = ["  ".join(hdr_parts)]

    # Separator
    lines.append("  ".join("─" * w for w in widths))

    # Data rows
    for r in rows:
        parts = []
        for (key, _, align), w in zip(columns, widths):
            val = _fmt_cell(r.get(key, ""))
            parts.append(f"{val:{'<' if align == '<' else '>'}{w}}")
        lines.append("  ".join(parts))

    return "\n".join(lines)


def _fmt_cell(v) -> str:
    """Format a value for table display."""
    if v is None:
        return ""
    if isinstance(v, bool):
        return "yes" if v else ""
    return str(v)
