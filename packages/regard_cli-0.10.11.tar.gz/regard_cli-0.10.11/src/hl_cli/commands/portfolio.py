"""Portfolio — cross-venue aggregate view."""

import typer

from hl_cli.output import output

portfolio_app = typer.Typer(
    name="port",
    invoke_without_command=True,
    no_args_is_help=False,
    help="Cross-venue portfolio overview.",
    pretty_exceptions_enable=False,
)


@portfolio_app.callback(invoke_without_command=True)
def portfolio(ctx: typer.Context):
    """Aggregate portfolio across all venues — total equity, positions, P&L."""
    opts = ctx.ensure_object(dict)

    venues = []
    total_equity = 0.0
    total_unrealized = 0.0
    all_positions = []

    # --- Hyperliquid ---
    try:
        from hl_cli.client import get_address, get_all_mids, get_all_positions, get_dex_balances, get_info

        info = get_info()
        addr = get_address()
        dex_balances = get_dex_balances(info, addr)
        hl_equity = sum(float(d.get("account_value", 0)) for d in dex_balances)
        total_equity += hl_equity

        all_pos = get_all_positions(info, addr)
        mids = get_all_mids(info)
        hl_unrealized = 0.0
        for pos in all_pos:
            size = float(pos["szi"])
            upnl = float(pos["unrealizedPnl"])
            hl_unrealized += upnl
            coin = pos["coin"]
            lev = pos["leverage"]
            all_positions.append({
                "venue": "hyperliquid",
                "asset": coin,
                "side": "long" if size > 0 else "short",
                "size": str(abs(size)),
                "entry_price": pos["entryPx"],
                "mark_price": mids.get(coin, ""),
                "unrealized_pnl": pos["unrealizedPnl"],
                "leverage": str(lev["value"]) if isinstance(lev, dict) else str(lev),
            })
        total_unrealized += hl_unrealized

        venues.append({
            "venue": "hyperliquid",
            "equity": f"{hl_equity:.6f}",
            "unrealized_pnl": f"{hl_unrealized:.6f}",
            "positions": len(all_pos),
            "dexes": len(dex_balances),
        })
    except SystemExit:
        pass  # no HL credentials — skip
    except Exception:
        venues.append({"venue": "hyperliquid", "error": "unavailable"})

    # --- Polymarket ---
    try:
        from poly_cli.client import get_clob_client, get_wallet_balances

        clob = get_clob_client()
        wallet = get_wallet_balances()

        # CLOB balance
        try:
            from py_clob_client.clob_types import AssetType, BalanceAllowanceParams
            bal = clob.get_balance_allowance(BalanceAllowanceParams(asset_type=AssetType.COLLATERAL))
            clob_balance = float(bal.get("balance", 0)) if isinstance(bal, dict) else 0.0
        except Exception:
            clob_balance = 0.0

        # On-chain wallet
        usdc_e = float(wallet.get("usdc_e", 0))
        usdc = float(wallet.get("usdc", 0))
        poly_equity = clob_balance + usdc_e + usdc
        total_equity += poly_equity

        # Positions
        try:
            pos_resp = clob.get_positions()
            pos_list = pos_resp if isinstance(pos_resp, list) else []
            poly_unrealized = 0.0
            for p in pos_list:
                sz = float(p.get("size", 0) or 0)
                if sz == 0:
                    continue
                pnl = float(p.get("pnl", 0) or 0)
                poly_unrealized += pnl
                all_positions.append({
                    "venue": "polymarket",
                    "asset": p.get("market", p.get("asset_id", "")),
                    "side": p.get("side", ""),
                    "size": p.get("size", ""),
                    "entry_price": p.get("avg_price", ""),
                    "mark_price": p.get("cur_price", ""),
                    "unrealized_pnl": p.get("pnl", ""),
                })
            total_unrealized += poly_unrealized
        except Exception:
            poly_unrealized = 0.0

        venues.append({
            "venue": "polymarket",
            "equity": f"{poly_equity:.2f}",
            "clob_balance": f"{clob_balance:.2f}",
            "wallet_usdc_e": wallet.get("usdc_e", "0"),
            "wallet_usdc": wallet.get("usdc", "0"),
            "unrealized_pnl": f"{poly_unrealized:.2f}",
            "positions": len([p for p in all_positions if p.get("venue") == "polymarket"]),
        })
    except SystemExit:
        pass  # no Poly credentials — skip
    except Exception:
        venues.append({"venue": "polymarket", "error": "unavailable"})

    result = {
        "total_equity": f"{total_equity:.6f}",
        "total_unrealized_pnl": f"{total_unrealized:.6f}",
        "venues": venues,
        "positions": all_positions,
        "position_count": len(all_positions),
    }
    output(result, opts.get("fields"), display=_display_portfolio(result))


def _display_portfolio(data: dict) -> str:
    lines = [f"Total equity  ${data['total_equity']}"]
    if float(data.get("total_unrealized_pnl", 0)):
        lines.append(f"Unrealized    ${data['total_unrealized_pnl']}")
    lines.append("")

    for v in data.get("venues", []):
        if "error" in v:
            lines.append(f"  {v['venue']:<14} {v['error']}")
        else:
            lines.append(f"  {v['venue']:<14} ${v['equity']}  ({v.get('positions', 0)} positions)")

    positions = data.get("positions", [])
    if positions:
        lines.append("")
        lines.append("Positions")
        for p in positions:
            venue_tag = "HL" if p["venue"] == "hyperliquid" else "PM"
            pnl = p.get("unrealized_pnl", "")
            lines.append(f"  [{venue_tag}] {p['asset']:<16} {p['side']:<5} {p['size']:>8} @ {p.get('entry_price', '?'):>10}  PnL {pnl}")

    return "\n".join(lines)
