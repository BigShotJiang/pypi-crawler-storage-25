"""Bundled SQL migrations."""
