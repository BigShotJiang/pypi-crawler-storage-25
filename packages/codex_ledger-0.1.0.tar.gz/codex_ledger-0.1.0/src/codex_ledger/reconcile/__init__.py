"""Reference reconciliation diagnostics."""
