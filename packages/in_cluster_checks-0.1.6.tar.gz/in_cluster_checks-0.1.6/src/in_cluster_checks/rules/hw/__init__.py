"""Hardware validation implementations."""
