#!/usr/bin/env python3
"""
brain_marketplace.py — Brain Marketplace Infrastructure

The marketplace where trained agent brains are packaged, validated,
listed, discovered, purchased, and installed.

Architecture:
- BrainPackager: export brain → .brain file (JSON + metadata + validation)
- BrainValidator: quality gates before listing (min principles, min episodes, etc.)
- BrainMarketplace: local catalog + remote index for discovery
- BrainInstaller: download .brain → import into local aibrain
- RevenueTracker: sales, commissions, payout tracking

Revenue model: 30% platform cut. Seller gets 70%.
Pricing tiers: $4.95 (starter), $9.95-$19.95 (professional), $29.95-$99.95 (enterprise/swarm)

Payment: Stripe handles transactions. Marketplace generates license keys
via Stripe Checkout. Brain files delivered after Stripe payment verification.
Revenue split: 70% seller / 30% platform via Stripe Connect.

Usage:
    aibrain marketplace package --name "Security Recon Brain" --price 19.95
    aibrain marketplace validate my_brain.brain
    aibrain marketplace list
    aibrain marketplace publish my_brain.brain
    aibrain marketplace search "pentesting"
    aibrain marketplace install <brain_id>
    aibrain marketplace revenue
"""

import hashlib
import json
import logging
import os
import re
import sqlite3
import time
import uuid
import urllib.request
import urllib.error
import urllib.parse
from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

log = logging.getLogger("aibrain.marketplace")

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

BRAIN_FORMAT_VERSION = "1.0"
PLATFORM_CUT = 0.30  # 30% platform fee
MIN_PRINCIPLES_TO_LIST = 10
MIN_EPISODES_TO_LIST = 20
MIN_MEMORIES_TO_LIST = 50
BRAIN_FILE_EXTENSION = ".brain"

PRICE_TIERS = {
    "starter": {"min": 2.95, "max": 9.95, "label": "Starter Brain"},
    "professional": {"min": 9.95, "max": 29.95, "label": "Professional Brain"},
    "enterprise": {"min": 29.95, "max": 299.95, "label": "Enterprise / Swarm-Trained Brain"},
    "free": {"min": 0, "max": 0, "label": "Community Brain"},
}

BRAIN_CATEGORIES = [
    "security", "pentesting", "code_review", "architecture",
    "devops", "data_science", "machine_learning", "writing",
    "project_management", "research", "compliance", "general",
]


# ---------------------------------------------------------------------------
# Data Structures
# ---------------------------------------------------------------------------

@dataclass
class BrainMetadata:
    """Metadata embedded in every .brain file."""
    brain_id: str = ""
    name: str = ""
    description: str = ""
    version: str = "1.0.0"
    author: str = ""
    author_id: str = ""
    category: str = "general"
    tags: List[str] = field(default_factory=list)
    price: float = 0.0
    currency: str = "USD"
    license_type: str = "single_user"  # single_user, team, unlimited
    format_version: str = BRAIN_FORMAT_VERSION

    # Training provenance
    training_method: str = "single_agent"  # single_agent, multi_agent, swarm
    agents_used: int = 1
    training_episodes: int = 0
    training_duration_days: int = 0
    consensus_validated: bool = False  # True if swarm-trained with consensus merge

    # Quality metrics
    total_memories: int = 0
    total_principles: int = 0
    total_episodes: int = 0
    avg_principle_confidence: float = 0.0
    skill_domains: List[str] = field(default_factory=list)
    top_principles: List[str] = field(default_factory=list)  # preview of best principles

    # Marketplace
    created_at: str = ""
    updated_at: str = ""
    downloads: int = 0
    rating: float = 0.0
    review_count: int = 0
    stripe_product_id: str = ""
    stripe_price_id: str = ""


@dataclass
class BrainReview:
    """User review of a purchased brain."""
    review_id: str = ""
    brain_id: str = ""
    reviewer: str = ""
    rating: int = 5  # 1-5 stars
    review_text: str = ""
    helpful_votes: int = 0
    created_at: str = ""


@dataclass
class ValidationResult:
    """Result of brain validation checks."""
    passed: bool = False
    score: float = 0.0  # 0-100 quality score
    checks: Dict[str, bool] = field(default_factory=dict)
    warnings: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    recommendations: List[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Brain Packager
# ---------------------------------------------------------------------------

class BrainPackager:
    """Package a brain database into a distributable .brain file.

    The .brain format is JSON containing:
    - metadata: BrainMetadata (provenance, pricing, quality metrics)
    - memories: list of non-personal memories (filtered)
    - principles: all active skill principles
    - episodes: anonymized skill episodes (task patterns, not raw data)

    Personal data is STRIPPED:
    - Memories tagged 'personal', 'private', 'secret' are excluded
    - Memory content is hashed to detect but not reveal personal patterns
    - User names, paths, and identifiers are scrubbed
    """

    def __init__(self, db_path: str):
        self.db_path = db_path

    def package(self, name: str, description: str, category: str,
                author: str, price: float, tags: List[str] = None,
                domains: List[str] = None,
                include_memories: bool = True,
                include_episodes: bool = True,
                training_method: str = "single_agent",
                agents_used: int = 1) -> Tuple[str, BrainMetadata]:
        """Package the brain into a .brain file.

        Returns: (file_path, metadata)
        """
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row

        brain_id = f"brain_{uuid.uuid4().hex[:12]}"
        metadata = BrainMetadata(
            brain_id=brain_id,
            name=name,
            description=description,
            category=category,
            author=author,
            tags=tags or [],
            price=price,
            training_method=training_method,
            agents_used=agents_used,
            created_at=datetime.now().isoformat(),
            updated_at=datetime.now().isoformat(),
        )

        # --- Collect principles ---
        principles = []
        try:
            query = "SELECT task_type, principle, confidence FROM skill_principles WHERE status='active'"
            params = []
            if domains:
                clauses = " OR ".join(["task_type LIKE ?" for _ in domains])
                query += f" AND ({clauses})"
                params = [f"%{d}%" for d in domains]
            query += " ORDER BY confidence DESC"

            rows = conn.execute(query, params).fetchall()
            for r in rows:
                principles.append({
                    "task_type": r["task_type"],
                    "principle": r["principle"],
                    "confidence": round(r["confidence"], 3),
                })
        except Exception:
            pass

        metadata.total_principles = len(principles)
        if principles:
            metadata.avg_principle_confidence = round(
                sum(p["confidence"] for p in principles) / len(principles), 3
            )
            metadata.top_principles = [p["principle"][:100] for p in principles[:5]]
            metadata.skill_domains = list(set(p["task_type"] for p in principles))

        # --- Collect memories (filtered) ---
        memories = []
        if include_memories:
            try:
                excluded_tags = ("personal", "private", "secret", "credential", "password")
                excluded_types = ("preference",)  # don't share user preferences

                query = "SELECT name, type, tags, content, importance FROM memories WHERE active=1"
                params = []
                if domains:
                    clauses = " OR ".join(["tags LIKE ?" for _ in domains])
                    query += f" AND ({clauses})"
                    params = [f"%{d}%" for d in domains]

                rows = conn.execute(query, params).fetchall()
                for r in rows:
                    # Filter out personal/private memories
                    row_tags = (r["tags"] or "").lower()
                    if any(t in row_tags for t in excluded_tags):
                        continue
                    if r["type"] in excluded_types:
                        continue

                    # Scrub content of common personal patterns
                    content = self._scrub_personal(r["content"])

                    memories.append({
                        "name": r["name"],
                        "type": r["type"],
                        "tags": r["tags"],
                        "content": content,
                        "importance": round(r["importance"], 2),
                    })
            except Exception:
                pass

        metadata.total_memories = len(memories)

        # --- Collect episodes (anonymized) ---
        episodes = []
        if include_episodes:
            try:
                query = "SELECT task_type, task_description, approach_taken, outcome_quality, duration_seconds FROM skill_episodes"
                params = []
                if domains:
                    clauses = " OR ".join(["task_type LIKE ?" for _ in domains])
                    query += f" WHERE ({clauses})"
                    params = [f"%{d}%" for d in domains]
                query += " ORDER BY created_at DESC LIMIT 1000"

                rows = conn.execute(query, params).fetchall()
                for r in rows:
                    episodes.append({
                        "task_type": r["task_type"],
                        "description": self._scrub_personal(r["task_description"] or ""),
                        "approach": self._scrub_personal(r["approach_taken"] or ""),
                        "quality": round(r["outcome_quality"], 2),
                        "duration": r["duration_seconds"],
                    })
            except Exception:
                pass

        metadata.total_episodes = len(episodes)
        metadata.training_episodes = len(episodes)

        conn.close()

        # --- Determine consensus validation ---
        if training_method == "swarm" and agents_used >= 3:
            high_conf = sum(1 for p in principles if p["confidence"] >= 0.8)
            metadata.consensus_validated = high_conf > len(principles) * 0.5

        # --- Build .brain file ---
        brain_data = {
            "format": "aibrain",
            "format_version": BRAIN_FORMAT_VERSION,
            "metadata": asdict(metadata),
            "principles": principles,
            "memories": memories,
            "episodes": episodes,
            "checksum": "",  # filled below
        }

        # Compute checksum
        content_str = json.dumps(principles) + json.dumps(memories)
        brain_data["checksum"] = hashlib.sha256(content_str.encode()).hexdigest()[:16]

        # Write file
        safe_name = re.sub(r'[^\w\-]', '_', name.lower())[:50]
        filename = f"{safe_name}_{brain_id}{BRAIN_FILE_EXTENSION}"
        filepath = Path(self.db_path).parent / filename

        filepath.write_text(json.dumps(brain_data, indent=2))

        log.info("Packaged brain: %s (%d principles, %d memories, %d episodes)",
                 name, len(principles), len(memories), len(episodes))

        return str(filepath), metadata

    def _scrub_personal(self, text: str) -> str:
        """Remove common personal identifiers from text."""
        if not text:
            return text

        # Remove file paths
        text = re.sub(r'[A-Z]:\\Users\\[^\s]+', '[PATH]', text)
        text = re.sub(r'/home/[^\s]+', '[PATH]', text)
        text = re.sub(r'/root/[^\s]+', '[PATH]', text)
        text = re.sub(r'/Users/[^\s]+', '[PATH]', text)

        # Remove IP addresses
        text = re.sub(r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b', '[IP]', text)

        # Remove email addresses
        text = re.sub(r'\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\b', '[EMAIL]', text)

        # Remove API keys / tokens (long hex/base64 strings)
        text = re.sub(r'\b[a-fA-F0-9]{32,}\b', '[TOKEN]', text)
        text = re.sub(r'\b[a-zA-Z0-9+/]{40,}={0,2}\b', '[TOKEN]', text)

        return text


# ---------------------------------------------------------------------------
# Brain Validator
# ---------------------------------------------------------------------------

class BrainValidator:
    """Quality gates for marketplace listing."""

    def validate(self, brain_path: str) -> ValidationResult:
        """Validate a .brain file for marketplace listing."""
        result = ValidationResult()

        # Check file exists and is valid JSON
        try:
            data = json.loads(Path(brain_path).read_text())
        except (FileNotFoundError, json.JSONDecodeError) as e:
            result.errors.append(f"Invalid brain file: {e}")
            return result

        result.checks["valid_json"] = True

        # Check format
        if data.get("format") != "aibrain":
            result.errors.append("Not an aibrain brain file")
            return result
        result.checks["format_valid"] = True

        # Check metadata
        meta = data.get("metadata", {})
        if not meta.get("name"):
            result.errors.append("Missing brain name")
        if not meta.get("description"):
            result.errors.append("Missing description")
        if not meta.get("category"):
            result.warnings.append("No category set — defaults to 'general'")
        if not meta.get("author"):
            result.errors.append("Missing author name")
        result.checks["metadata_complete"] = len(result.errors) == 0

        # Check content quality
        principles = data.get("principles", [])
        memories = data.get("memories", [])
        episodes = data.get("episodes", [])

        result.checks["min_principles"] = len(principles) >= MIN_PRINCIPLES_TO_LIST
        if not result.checks["min_principles"]:
            result.errors.append(
                f"Need at least {MIN_PRINCIPLES_TO_LIST} principles (got {len(principles)})")

        result.checks["min_episodes"] = len(episodes) >= MIN_EPISODES_TO_LIST
        if not result.checks["min_episodes"]:
            result.errors.append(
                f"Need at least {MIN_EPISODES_TO_LIST} episodes (got {len(episodes)})")

        result.checks["min_memories"] = len(memories) >= MIN_MEMORIES_TO_LIST
        if not result.checks["min_memories"]:
            result.warnings.append(
                f"Only {len(memories)} memories — consider adding more for value")

        # Check principle quality
        if principles:
            avg_conf = sum(p.get("confidence", 0) for p in principles) / len(principles)
            result.checks["avg_confidence"] = avg_conf >= 0.5
            if not result.checks["avg_confidence"]:
                result.warnings.append(
                    f"Average principle confidence is {avg_conf:.0%} — aim for 50%+")

            # Check for domain diversity
            domains = set(p.get("task_type", "") for p in principles)
            result.checks["domain_diversity"] = len(domains) >= 3
            if not result.checks["domain_diversity"]:
                result.warnings.append(
                    f"Only {len(domains)} skill domains — more diversity increases value")

        # Check for leaked personal data
        all_content = json.dumps(data)
        personal_patterns = [
            (r'\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\b', "email address"),
            (r'[A-Z]:\\Users\\[a-zA-Z]+', "Windows user path"),
            (r'/home/[a-zA-Z]+', "Linux home path"),
            (r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b', "IP address"),
            (r'\b[a-fA-F0-9]{32,}\b', "potential API key/token"),
        ]
        for pattern, name in personal_patterns:
            if re.search(pattern, all_content):
                result.warnings.append(f"Possible {name} detected — verify scrubbing")

        result.checks["no_personal_data"] = not any(
            "Possible" in w for w in result.warnings
        )

        # Check checksum
        content_str = json.dumps(principles) + json.dumps(memories)
        expected = hashlib.sha256(content_str.encode()).hexdigest()[:16]
        result.checks["checksum_valid"] = data.get("checksum") == expected
        if not result.checks["checksum_valid"]:
            result.warnings.append("Checksum mismatch — file may have been modified")

        # Calculate quality score
        checks_passed = sum(1 for v in result.checks.values() if v)
        total_checks = max(len(result.checks), 1)
        result.score = round((checks_passed / total_checks) * 100)
        result.passed = len(result.errors) == 0 and result.score >= 60

        # Pricing recommendations
        if meta.get("price", 0) > 0:
            if len(principles) < 25:
                result.recommendations.append(
                    f"With {len(principles)} principles, consider pricing under $9.95")
            if meta.get("consensus_validated"):
                result.recommendations.append(
                    "Consensus-validated brain — premium pricing ($29.95+) is justified")

        return result


# ---------------------------------------------------------------------------
# Brain Marketplace (local catalog + remote index)
# ---------------------------------------------------------------------------

class BrainMarketplace:
    """Local marketplace catalog with optional remote index sync."""

    def __init__(self, db_path: str):
        self.db_path = db_path
        self.marketplace_dir = Path(db_path).parent / ".brain_marketplace"
        self.marketplace_dir.mkdir(parents=True, exist_ok=True)
        self.catalog_path = self.marketplace_dir / "catalog.json"
        self.installed_path = self.marketplace_dir / "installed.json"
        self._catalog = self._load_json(self.catalog_path)
        self._installed = self._load_json(self.installed_path)

    def _load_json(self, path: Path) -> Dict:
        if path.exists():
            try:
                return json.loads(path.read_text())
            except json.JSONDecodeError:
                pass
        return {"brains": {}, "updated": ""}

    def _save_catalog(self):
        self._catalog["updated"] = datetime.now().isoformat()
        self.catalog_path.write_text(json.dumps(self._catalog, indent=2))

    def _save_installed(self):
        self.installed_path.write_text(json.dumps(self._installed, indent=2))

    # ------------------------------------------------------------------
    # Publishing
    # ------------------------------------------------------------------

    def publish(self, brain_path: str, stripe_price_id: str = "") -> Dict:
        """Publish a brain to the marketplace catalog."""
        # Validate first
        validator = BrainValidator()
        validation = validator.validate(brain_path)

        if not validation.passed:
            return {
                "status": "rejected",
                "errors": validation.errors,
                "score": validation.score,
            }

        # Load brain data
        data = json.loads(Path(brain_path).read_text())
        meta = data.get("metadata", {})
        brain_id = meta.get("brain_id", f"brain_{uuid.uuid4().hex[:12]}")

        # Add to catalog
        listing = {
            "brain_id": brain_id,
            "name": meta.get("name", "Untitled"),
            "description": meta.get("description", ""),
            "category": meta.get("category", "general"),
            "tags": meta.get("tags", []),
            "author": meta.get("author", ""),
            "price": meta.get("price", 0),
            "currency": meta.get("currency", "USD"),
            "training_method": meta.get("training_method", "single_agent"),
            "agents_used": meta.get("agents_used", 1),
            "consensus_validated": meta.get("consensus_validated", False),
            "total_principles": meta.get("total_principles", 0),
            "total_memories": meta.get("total_memories", 0),
            "total_episodes": meta.get("total_episodes", 0),
            "avg_confidence": meta.get("avg_principle_confidence", 0),
            "skill_domains": meta.get("skill_domains", []),
            "top_principles": meta.get("top_principles", []),
            "stripe_price_id": stripe_price_id,
            "brain_file": str(brain_path),
            "published_at": datetime.now().isoformat(),
            "downloads": 0,
            "rating": 0,
            "reviews": [],
            "validation_score": validation.score,
        }

        self._catalog["brains"][brain_id] = listing
        self._save_catalog()

        # Copy brain file to marketplace directory
        dest = self.marketplace_dir / Path(brain_path).name
        if not dest.exists():
            import shutil
            shutil.copy2(brain_path, dest)
            listing["brain_file"] = str(dest)
            self._save_catalog()

        log.info("Published brain: %s (%s) at $%.2f",
                 meta.get("name"), brain_id, meta.get("price", 0))

        return {
            "status": "published",
            "brain_id": brain_id,
            "validation_score": validation.score,
            "stripe_price_id": stripe_price_id,
        }

    # ------------------------------------------------------------------
    # Discovery
    # ------------------------------------------------------------------

    def search(self, query: str = "", category: str = "",
               min_price: float = 0, max_price: float = 999,
               consensus_only: bool = False,
               sort_by: str = "rating") -> List[Dict]:
        """Search the marketplace catalog."""
        results = []

        for brain_id, listing in self._catalog.get("brains", {}).items():
            # Filter by query
            if query:
                searchable = f"{listing['name']} {listing['description']} {' '.join(listing.get('tags', []))}".lower()
                if query.lower() not in searchable:
                    continue

            # Filter by category
            if category and listing.get("category") != category:
                continue

            # Filter by price
            price = listing.get("price", 0)
            if price < min_price or price > max_price:
                continue

            # Filter by consensus
            if consensus_only and not listing.get("consensus_validated"):
                continue

            results.append(listing)

        # Sort
        if sort_by == "rating":
            results.sort(key=lambda x: x.get("rating", 0), reverse=True)
        elif sort_by == "price_low":
            results.sort(key=lambda x: x.get("price", 0))
        elif sort_by == "price_high":
            results.sort(key=lambda x: x.get("price", 0), reverse=True)
        elif sort_by == "downloads":
            results.sort(key=lambda x: x.get("downloads", 0), reverse=True)
        elif sort_by == "newest":
            results.sort(key=lambda x: x.get("published_at", ""), reverse=True)
        elif sort_by == "principles":
            results.sort(key=lambda x: x.get("total_principles", 0), reverse=True)

        return results

    def get_brain(self, brain_id: str) -> Optional[Dict]:
        """Get details for a specific brain."""
        return self._catalog.get("brains", {}).get(brain_id)

    def list_categories(self) -> Dict[str, int]:
        """List categories with counts."""
        counts = {}
        for listing in self._catalog.get("brains", {}).values():
            cat = listing.get("category", "general")
            counts[cat] = counts.get(cat, 0) + 1
        return dict(sorted(counts.items(), key=lambda x: x[1], reverse=True))

    # ------------------------------------------------------------------
    # Installation
    # ------------------------------------------------------------------

    def install(self, brain_id: str, license_key: str = "") -> Dict:
        """Install a brain into the local aibrain database."""
        listing = self.get_brain(brain_id)
        if not listing:
            return {"status": "error", "message": f"Brain not found: {brain_id}"}

        brain_file = listing.get("brain_file")
        if not brain_file or not Path(brain_file).exists():
            return {"status": "error", "message": "Brain file not found"}

        # Verify license key for paid brains via Stripe
        if listing.get("price", 0) > 0:
            if not license_key:
                return {
                    "status": "error",
                    "message": f"This brain costs ${listing['price']:.2f}. "
                               f"Purchase at: https://myaibrain.org/marketplace",
                    "purchase_url": "https://myaibrain.org/marketplace",
                }

            # Verify the license key against local license store
            license_file = self.marketplace_dir / "licenses.json"
            valid = False
            if license_file.exists():
                licenses = json.loads(license_file.read_text())
                license_entry = licenses.get(license_key, {})
                if license_entry.get("brain_id") == brain_id:
                    valid = True
                    uses = license_entry.get("uses", 0) + 1
                    license_entry["uses"] = uses
                    licenses[license_key] = license_entry
                    license_file.write_text(json.dumps(licenses, indent=2))
                    if uses > 3:
                        log.warning("License key for brain %s has %d uses", brain_id, uses)

            if not valid:
                return {
                    "status": "error",
                    "message": "Invalid license key. Please check your purchase confirmation.",
                }

        # Load brain data
        data = json.loads(Path(brain_file).read_text())

        # Import into local database
        conn = sqlite3.connect(self.db_path)
        imported = {"principles": 0, "memories": 0, "episodes": 0}

        # Import principles
        for p in data.get("principles", []):
            try:
                existing = conn.execute(
                    "SELECT id FROM skill_principles WHERE task_type=? AND principle=? AND status='active'",
                    (p["task_type"], p["principle"])
                ).fetchone()

                if existing:
                    # Boost confidence if imported principle is higher
                    conn.execute(
                        "UPDATE skill_principles SET confidence=MAX(confidence, ?) WHERE id=?",
                        (p["confidence"], existing[0])
                    )
                else:
                    conn.execute(
                        "INSERT INTO skill_principles (task_type, principle, confidence, "
                        "status, created_at) VALUES (?, ?, ?, 'active', datetime('now'))",
                        (p["task_type"], p["principle"], p["confidence"])
                    )
                imported["principles"] += 1
            except Exception:
                pass

        # Import memories
        for m in data.get("memories", []):
            try:
                existing = conn.execute(
                    "SELECT id FROM memories WHERE name=? AND active=1", (m["name"],)
                ).fetchone()
                if not existing:
                    conn.execute(
                        "INSERT INTO memories (name, type, tags, content, importance, "
                        "created, updated, active) VALUES (?, ?, ?, ?, ?, datetime('now'), "
                        "datetime('now'), 1)",
                        (m["name"], m.get("type", "reference"),
                         m.get("tags", "") + f",marketplace:{brain_id}",
                         m["content"], m.get("importance", 0.5))
                    )
                    imported["memories"] += 1
            except Exception:
                pass

        # Import episodes
        for e in data.get("episodes", []):
            try:
                conn.execute(
                    "INSERT INTO skill_episodes (task_type, task_description, "
                    "approach_taken, outcome_quality, duration_seconds, created_at) "
                    "VALUES (?, ?, ?, ?, ?, datetime('now'))",
                    (e.get("task_type", ""), e.get("description", ""),
                     e.get("approach", ""), e.get("quality", 0),
                     e.get("duration", 0))
                )
                imported["episodes"] += 1
            except Exception:
                pass

        conn.commit()
        conn.close()

        # Track installation
        self._installed["brains"][brain_id] = {
            "name": listing["name"],
            "installed_at": datetime.now().isoformat(),
            "imported": imported,
            "license_key": license_key[:8] + "..." if license_key else "",
        }
        self._save_installed()

        # Increment download count
        listing["downloads"] = listing.get("downloads", 0) + 1
        self._save_catalog()

        log.info("Installed brain: %s — %d principles, %d memories, %d episodes",
                 listing["name"], imported["principles"],
                 imported["memories"], imported["episodes"])

        return {
            "status": "installed",
            "brain_id": brain_id,
            "name": listing["name"],
            "imported": imported,
        }

    def list_installed(self) -> List[Dict]:
        """List installed marketplace brains."""
        return [
            {"brain_id": k, **v}
            for k, v in self._installed.get("brains", {}).items()
        ]

    # ------------------------------------------------------------------
    # Reviews
    # ------------------------------------------------------------------

    def review(self, brain_id: str, rating: int, review_text: str,
               reviewer: str = "anonymous") -> Dict:
        """Submit a review for an installed brain."""
        listing = self.get_brain(brain_id)
        if not listing:
            return {"status": "error", "message": "Brain not found"}

        # Check if installed
        if brain_id not in self._installed.get("brains", {}):
            return {"status": "error", "message": "You must install a brain before reviewing"}

        review = {
            "review_id": f"rev_{uuid.uuid4().hex[:8]}",
            "brain_id": brain_id,
            "reviewer": reviewer,
            "rating": max(1, min(5, rating)),
            "review_text": review_text,
            "created_at": datetime.now().isoformat(),
        }

        reviews = listing.get("reviews", [])
        reviews.append(review)
        listing["reviews"] = reviews

        # Recalculate average rating
        if reviews:
            listing["rating"] = round(
                sum(r["rating"] for r in reviews) / len(reviews), 1
            )
            listing["review_count"] = len(reviews)

        self._save_catalog()
        return {"status": "ok", "review_id": review["review_id"]}


# ---------------------------------------------------------------------------
# Revenue Tracker
# ---------------------------------------------------------------------------

class RevenueTracker:
    """Track marketplace sales and revenue."""

    def __init__(self, db_path: str):
        self.db_path = db_path
        self.revenue_path = Path(db_path).parent / ".brain_marketplace" / "revenue.json"
        self._data = self._load()

    def _load(self) -> Dict:
        if self.revenue_path.exists():
            try:
                return json.loads(self.revenue_path.read_text())
            except json.JSONDecodeError:
                pass
        return {"sales": [], "total_gross": 0, "total_net": 0, "total_platform_fee": 0}

    def _save(self):
        self.revenue_path.write_text(json.dumps(self._data, indent=2))

    def record_sale(self, brain_id: str, brain_name: str, price: float,
                    buyer: str = "", stripe_session_id: str = "") -> Dict:
        """Record a brain sale."""
        platform_fee = round(price * PLATFORM_CUT, 2)
        seller_revenue = round(price - platform_fee, 2)

        sale = {
            "sale_id": f"sale_{uuid.uuid4().hex[:8]}",
            "brain_id": brain_id,
            "brain_name": brain_name,
            "price": price,
            "platform_fee": platform_fee,
            "seller_revenue": seller_revenue,
            "buyer": buyer,
            "stripe_session_id": stripe_session_id,
            "timestamp": datetime.now().isoformat(),
        }

        self._data["sales"].append(sale)
        self._data["total_gross"] = round(self._data["total_gross"] + price, 2)
        self._data["total_net"] = round(self._data["total_net"] + seller_revenue, 2)
        self._data["total_platform_fee"] = round(
            self._data["total_platform_fee"] + platform_fee, 2)
        self._save()

        return sale

    def summary(self) -> Dict:
        """Revenue summary."""
        sales = self._data.get("sales", [])

        # Monthly breakdown
        monthly = {}
        for sale in sales:
            month = sale["timestamp"][:7]
            if month not in monthly:
                monthly[month] = {"sales": 0, "gross": 0, "net": 0}
            monthly[month]["sales"] += 1
            monthly[month]["gross"] = round(monthly[month]["gross"] + sale["price"], 2)
            monthly[month]["net"] = round(monthly[month]["net"] + sale["seller_revenue"], 2)

        # Top sellers
        brain_sales = {}
        for sale in sales:
            bid = sale["brain_id"]
            if bid not in brain_sales:
                brain_sales[bid] = {"name": sale["brain_name"], "count": 0, "revenue": 0}
            brain_sales[bid]["count"] += 1
            brain_sales[bid]["revenue"] = round(
                brain_sales[bid]["revenue"] + sale["seller_revenue"], 2)

        top_sellers = sorted(brain_sales.values(), key=lambda x: x["revenue"], reverse=True)

        return {
            "total_sales": len(sales),
            "total_gross": self._data["total_gross"],
            "total_net": self._data["total_net"],
            "platform_fees": self._data["total_platform_fee"],
            "monthly": monthly,
            "top_sellers": top_sellers[:10],
        }


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def cli_marketplace(args: List[str], db_path: str) -> int:
    """Handle `aibrain marketplace <subcommand>` CLI."""
    if not args:
        print("Usage: aibrain marketplace <package|validate|publish|search|install|installed|review|revenue>")
        return 1

    subcmd = args[0]

    # Tier enforcement — marketplace requires Pro+
    try:
        from aibrain_licensing import check_tier, upgrade_message
        paid_cmds = {"package", "publish", "install", "review", "revenue"}
        if subcmd in paid_cmds and not check_tier("pro"):
            print(upgrade_message("pro"))
            return 1
    except ImportError:
        pass

    marketplace = BrainMarketplace(db_path)

    if subcmd == "package":
        name = ""
        desc = ""
        category = "general"
        author = ""
        price = 0.0
        tags = []
        domains = None

        i = 1
        while i < len(args):
            if args[i] == "--name" and i + 1 < len(args):
                name = args[i + 1]; i += 2
            elif args[i] == "--desc" and i + 1 < len(args):
                desc = args[i + 1]; i += 2
            elif args[i] == "--category" and i + 1 < len(args):
                category = args[i + 1]; i += 2
            elif args[i] == "--author" and i + 1 < len(args):
                author = args[i + 1]; i += 2
            elif args[i] == "--price" and i + 1 < len(args):
                price = float(args[i + 1]); i += 2
            elif args[i] == "--tags" and i + 1 < len(args):
                tags = args[i + 1].split(","); i += 2
            elif args[i] == "--domains" and i + 1 < len(args):
                domains = args[i + 1].split(","); i += 2
            else:
                i += 1

        if not name:
            print("Required: --name 'Brain Name'")
            return 1

        packager = BrainPackager(db_path)
        filepath, meta = packager.package(name, desc, category, author, price, tags, domains)
        print(f"Packaged: {filepath}")
        print(f"  Brain ID: {meta.brain_id}")
        print(f"  Principles: {meta.total_principles}")
        print(f"  Memories: {meta.total_memories}")
        print(f"  Episodes: {meta.total_episodes}")
        print(f"  Avg confidence: {meta.avg_principle_confidence:.0%}")

    elif subcmd == "validate":
        if len(args) > 1:
            validator = BrainValidator()
            result = validator.validate(args[1])
            status = "[PASS] PASSED" if result.passed else "[FAIL] FAILED"
            print(f"\n  Validation: {status} (score: {result.score}/100)\n")
            for check, passed in result.checks.items():
                print(f"  {'[x]' if passed else '[ ]'} {check}")
            if result.errors:
                print(f"\n  Errors:")
                for e in result.errors:
                    print(f"    [!] {e}")
            if result.warnings:
                print(f"\n  Warnings:")
                for w in result.warnings:
                    print(f"    [?] {w}")
            if result.recommendations:
                print(f"\n  Recommendations:")
                for r in result.recommendations:
                    print(f"    [*] {r}")
        else:
            print("Usage: aibrain marketplace validate <brain_file>")

    elif subcmd == "publish":
        if len(args) > 1:
            stripe_price = ""
            if "--stripe-price" in args:
                idx = args.index("--stripe-price") + 1
                if idx < len(args):
                    stripe_price = args[idx]
            result = marketplace.publish(args[1], stripe_price_id=stripe_price)
            if result["status"] == "published":
                print(f"Published: {result['brain_id']} (validation: {result['validation_score']}/100)")
            else:
                print(f"Rejected: {', '.join(result.get('errors', []))}")
        else:
            print("Usage: aibrain marketplace publish <brain_file> [--stripe-price <price_id>]")

    elif subcmd == "search":
        query = args[1] if len(args) > 1 else ""
        category = ""
        consensus = False
        if "--category" in args:
            idx = args.index("--category") + 1
            category = args[idx] if idx < len(args) else ""
        if "--consensus" in args:
            consensus = True

        results = marketplace.search(query, category=category, consensus_only=consensus)
        if results:
            print(f"\n  {len(results)} brains found:\n")
            for r in results:
                consensus_badge = " [CONSENSUS]" if r.get("consensus_validated") else ""
                print(f"  [{r['brain_id']}] {r['name']}{consensus_badge}")
                print(f"    ${r['price']:.2f} | {r.get('rating', 0):.1f} stars | "
                      f"{r['total_principles']} principles | "
                      f"{r.get('downloads', 0)} downloads")
                print(f"    {r['description'][:80]}")
                print()
        else:
            print("No brains found matching your search.")

    elif subcmd == "install":
        if len(args) > 1:
            brain_id = args[1]
            key = ""
            if "--key" in args:
                idx = args.index("--key") + 1
                key = args[idx] if idx < len(args) else ""

            result = marketplace.install(brain_id, license_key=key)
            if result["status"] == "installed":
                imp = result["imported"]
                print(f"Installed: {result['name']}")
                print(f"  +{imp['principles']} principles")
                print(f"  +{imp['memories']} memories")
                print(f"  +{imp['episodes']} episodes")
            else:
                print(f"Error: {result['message']}")
                if result.get("purchase_url"):
                    print(f"Purchase: {result['purchase_url']}")
        else:
            print("Usage: aibrain marketplace install <brain_id> [--key <license_key>]")

    elif subcmd == "installed":
        installed = marketplace.list_installed()
        if installed:
            for b in installed:
                print(f"  {b['brain_id']}: {b.get('name', '?')} (installed {b.get('installed_at', '')[:10]})")
        else:
            print("No marketplace brains installed.")

    elif subcmd == "review":
        if len(args) >= 4:
            brain_id = args[1]
            rating = int(args[2])
            text = " ".join(args[3:])
            result = marketplace.review(brain_id, rating, text)
            if result["status"] == "ok":
                print(f"Review submitted: {result['review_id']}")
            else:
                print(f"Error: {result['message']}")
        else:
            print("Usage: aibrain marketplace review <brain_id> <1-5> <review text>")

    elif subcmd == "revenue":
        tracker = RevenueTracker(db_path)
        summary = tracker.summary()
        print(f"\n  Marketplace Revenue\n")
        print(f"  Total sales: {summary['total_sales']}")
        print(f"  Gross: ${summary['total_gross']:.2f}")
        print(f"  Platform fees: ${summary['platform_fees']:.2f}")
        print(f"  Net revenue: ${summary['total_net']:.2f}")

        if summary["monthly"]:
            print(f"\n  Monthly:")
            for month, data in sorted(summary["monthly"].items()):
                print(f"    {month}: {data['sales']} sales, ${data['net']:.2f} net")

        if summary["top_sellers"]:
            print(f"\n  Top sellers:")
            for ts in summary["top_sellers"][:5]:
                print(f"    {ts['name']}: {ts['count']} sales, ${ts['revenue']:.2f}")

    elif subcmd == "categories":
        cats = marketplace.list_categories()
        for cat, count in cats.items():
            print(f"  {cat}: {count} brains")

    else:
        print(f"Unknown subcommand: {subcmd}")
        return 1

    return 0


if __name__ == "__main__":
    import sys
    db = os.environ.get("AIBRAIN_DB", str(Path.home() / "aibrain" / "aibrain.db"))
    sys.exit(cli_marketplace(sys.argv[1:], db))
