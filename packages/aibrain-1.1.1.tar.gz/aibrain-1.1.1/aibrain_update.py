#!/usr/bin/env python3
"""
AIBrain Updater — safe self-update for git and pip installations.

Handles both update paths:
  - Git users (devs): pulls latest from configured remote
  - pip users (public): upgrades aibrain-core package + syncs workflows

Safety guarantees:
  - Backs up DB and config before any changes
  - Never overwrites config.json or .env files
  - Validates update before finalising
  - Can roll back on failure

Usage:
    python aibrain_update.py                # Auto-detect and update
    python aibrain_update.py --check        # Check for updates without applying
    python aibrain_update.py --backup-only  # Just create a backup
    python aibrain_update.py --rollback     # Restore from last backup
    python aibrain_update.py --switch-remote owner/repo  # Switch git remote
"""

import argparse
import datetime
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

AIBRAIN_ROOT = Path(__file__).parent.resolve()
BACKUP_DIR = AIBRAIN_ROOT / "backups" / "updates"
VERSION_FILE = AIBRAIN_ROOT / "VERSION"
CONFIG_PATH = AIBRAIN_ROOT / "config.json"

# Canonical repo — resolved at runtime from git remote or config
CANONICAL_REPO = os.environ.get("AIBRAIN_REPO", "aibrain/aibrain")
CANONICAL_URL = f"https://github.com/{CANONICAL_REPO}.git"

# Files that are NEVER overwritten by updates (user data)
PROTECTED_FILES = {
    "config.json", ".env", ".aibrain_env",
    "aibrain.db", "agentos.db", "memory/memory.db",
    "scheduled_jobs.json", "aibrain_custom_workflows.py",
}

# Files to always ignore in git operations
PROTECTED_PATTERNS = {"*.db", "*.db-wal", "*.db-shm", "config.json", ".env*"}

COLORS = {
    "reset": "\033[0m",
    "teal": "\033[38;2;0;245;212m",
    "bold": "\033[1m",
    "red": "\033[91m",
    "green": "\033[92m",
    "yellow": "\033[93m",
    "dim": "\033[90m",
}


def c(color, text):
    return f"{COLORS.get(color, '')}{text}{COLORS['reset']}"


def get_current_version():
    """Read current version from VERSION file or pyproject.toml."""
    if VERSION_FILE.exists():
        return VERSION_FILE.read_text().strip()
    pyproject = AIBRAIN_ROOT / "pyproject.toml"
    if pyproject.exists():
        for line in pyproject.read_text().splitlines():
            if line.strip().startswith("version"):
                return line.split("=")[1].strip().strip('"').strip("'")
    return "unknown"


def is_git_install():
    """Check if this is a git-based installation."""
    return (AIBRAIN_ROOT / ".git").exists()


def is_pip_install():
    """Check if aibrain-core is installed via pip."""
    try:
        r = subprocess.run(
            [sys.executable, "-m", "pip", "show", "aibrain-core"],
            capture_output=True, text=True, timeout=15,
        )
        return r.returncode == 0
    except Exception:
        return False


def get_git_remote():
    """Get the current git remote URL and name."""
    try:
        r = subprocess.run(
            ["git", "remote", "-v"],
            capture_output=True, text=True, cwd=str(AIBRAIN_ROOT), timeout=10,
        )
        remotes = {}
        for line in r.stdout.strip().splitlines():
            parts = line.split()
            if len(parts) >= 2 and "(fetch)" in line:
                remotes[parts[0]] = parts[1]
        # Prefer 'origin', then first available
        for name in ["origin"]:
            if name in remotes:
                return name, remotes[name]
        if remotes:
            name = list(remotes.keys())[0]
            return name, remotes[name]
    except Exception:
        pass
    return None, None


def get_git_current_sha():
    """Get current HEAD SHA."""
    try:
        r = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            capture_output=True, text=True, cwd=str(AIBRAIN_ROOT), timeout=10,
        )
        return r.stdout.strip()[:12] if r.returncode == 0 else None
    except Exception:
        return None


def get_git_remote_sha(remote_name="origin", branch="main"):
    """Fetch and get the latest remote SHA."""
    try:
        subprocess.run(
            ["git", "fetch", remote_name, branch],
            capture_output=True, text=True, cwd=str(AIBRAIN_ROOT), timeout=30,
        )
        r = subprocess.run(
            ["git", "rev-parse", f"{remote_name}/{branch}"],
            capture_output=True, text=True, cwd=str(AIBRAIN_ROOT), timeout=10,
        )
        return r.stdout.strip()[:12] if r.returncode == 0 else None
    except Exception:
        return None


def get_pip_latest_version():
    """Check PyPI for the latest aibrain-core version."""
    try:
        import urllib.request
        req = urllib.request.Request(
            "https://pypi.org/pypi/aibrain-core/json",
            headers={"User-Agent": "AIBrain-Updater/1.0"},
        )
        resp = urllib.request.urlopen(req, timeout=10)
        data = json.loads(resp.read())
        return data.get("info", {}).get("version", "unknown")
    except Exception:
        return None


def get_pip_installed_version():
    """Get currently installed pip version."""
    try:
        r = subprocess.run(
            [sys.executable, "-m", "pip", "show", "aibrain-core"],
            capture_output=True, text=True, timeout=15,
        )
        for line in r.stdout.splitlines():
            if line.startswith("Version:"):
                return line.split(":")[1].strip()
    except Exception:
        pass
    return None


# ---- Backup & Restore ----

def create_backup(label="pre-update"):
    """Back up DB files and config before updating."""
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = BACKUP_DIR / f"{label}_{ts}"
    backup_path.mkdir(parents=True, exist_ok=True)

    backed_up = []

    # Back up all DB files
    for pattern in ["*.db", "*.db-wal", "*.db-shm"]:
        for db_file in AIBRAIN_ROOT.glob(pattern):
            dest = backup_path / db_file.name
            shutil.copy2(str(db_file), str(dest))
            backed_up.append(db_file.name)

    # Memory subdirectory DBs
    mem_dir = AIBRAIN_ROOT / "memory"
    if mem_dir.exists():
        (backup_path / "memory").mkdir(exist_ok=True)
        for db_file in mem_dir.glob("*.db*"):
            shutil.copy2(str(db_file), str(backup_path / "memory" / db_file.name))
            backed_up.append(f"memory/{db_file.name}")

    # Back up config
    if CONFIG_PATH.exists():
        shutil.copy2(str(CONFIG_PATH), str(backup_path / "config.json"))
        backed_up.append("config.json")

    # Back up env files
    for env_name in [".env", ".aibrain_env"]:
        env_file = AIBRAIN_ROOT / env_name
        if env_file.exists():
            shutil.copy2(str(env_file), str(backup_path / env_name))
            backed_up.append(env_name)

    # Save current version/SHA for rollback
    meta = {
        "timestamp": ts,
        "version": get_current_version(),
        "git_sha": get_git_current_sha() if is_git_install() else None,
        "files_backed_up": backed_up,
    }
    (backup_path / "backup_meta.json").write_text(json.dumps(meta, indent=2))

    return backup_path, backed_up


def find_latest_backup():
    """Find the most recent backup directory."""
    if not BACKUP_DIR.exists():
        return None
    backups = sorted(BACKUP_DIR.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True)
    for b in backups:
        if b.is_dir() and (b / "backup_meta.json").exists():
            return b
    return None


def restore_backup(backup_path):
    """Restore DB and config from a backup."""
    meta_file = backup_path / "backup_meta.json"
    if not meta_file.exists():
        print(f"  {c('red', 'ERROR')}: No backup_meta.json found in {backup_path}")
        return False

    meta = json.loads(meta_file.read_text())
    restored = []

    for fname in meta.get("files_backed_up", []):
        src = backup_path / fname
        dest = AIBRAIN_ROOT / fname
        if src.exists():
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(str(src), str(dest))
            restored.append(fname)

    print(f"  Restored {len(restored)} files from backup ({meta.get('timestamp', 'unknown')})")
    return True


# ---- Git Update ----

def git_update(remote_name, branch="main", dry_run=False):
    """Pull latest changes from git remote."""
    print(f"\n{c('teal', '[2/4]')} {c('bold', 'Pulling latest changes')}")

    if dry_run:
        print(f"  Would pull from {remote_name}/{branch}")
        return True

    # Stash any local changes
    r = subprocess.run(
        ["git", "stash", "list"],
        capture_output=True, text=True, cwd=str(AIBRAIN_ROOT), timeout=10,
    )
    stash_count = len(r.stdout.strip().splitlines()) if r.stdout.strip() else 0

    # Drop existing stashes per workflow rules
    if stash_count > 0:
        subprocess.run(
            ["git", "stash", "drop"],
            capture_output=True, text=True, cwd=str(AIBRAIN_ROOT), timeout=10,
        )

    # Stash current work
    subprocess.run(
        ["git", "stash"],
        capture_output=True, text=True, cwd=str(AIBRAIN_ROOT), timeout=10,
    )

    # Pull with rebase
    r = subprocess.run(
        ["git", "pull", "--rebase", remote_name, branch],
        capture_output=True, text=True, cwd=str(AIBRAIN_ROOT), timeout=60,
    )

    if r.returncode != 0:
        print(f"  {c('red', 'Pull failed')}:")
        print(f"  {r.stderr.strip()}")

        # Abort rebase if in progress
        subprocess.run(
            ["git", "rebase", "--abort"],
            capture_output=True, text=True, cwd=str(AIBRAIN_ROOT), timeout=10,
        )

        # Restore stash
        subprocess.run(
            ["git", "stash", "pop"],
            capture_output=True, text=True, cwd=str(AIBRAIN_ROOT), timeout=10,
        )
        return False

    # Pop stash if we had one
    subprocess.run(
        ["git", "stash", "pop"],
        capture_output=True, text=True, cwd=str(AIBRAIN_ROOT), timeout=10,
    )

    # Show what changed
    new_sha = get_git_current_sha()
    r = subprocess.run(
        ["git", "log", "--oneline", f"HEAD~10..HEAD"],
        capture_output=True, text=True, cwd=str(AIBRAIN_ROOT), timeout=10,
    )
    if r.stdout.strip():
        print(f"  {c('green', 'Updated')} to {new_sha}")
        for line in r.stdout.strip().splitlines()[:5]:
            print(f"    {line}")
        total = len(r.stdout.strip().splitlines())
        if total > 5:
            print(f"    ... and {total - 5} more commits")

    # Clean stale build artifacts — prevents importing old pre-rename code
    for stale_dir in ["build", "dist"]:
        stale_path = AIBRAIN_ROOT / stale_dir
        if stale_path.exists():
            shutil.rmtree(stale_path, ignore_errors=True)
            print(f"  Cleaned stale {stale_dir}/ directory")
    for egg in AIBRAIN_ROOT.glob("*.egg-info"):
        shutil.rmtree(egg, ignore_errors=True)
        print(f"  Cleaned {egg.name}")

    return True


def switch_remote(new_repo):
    """Switch the git remote to a new repository."""
    print(f"\n{c('teal', 'Switching remote')} to {new_repo}")

    # Parse owner/repo format
    if "/" in new_repo and "://" not in new_repo:
        url = f"https://github.com/{new_repo}.git"
    else:
        url = new_repo

    # Check if origin exists
    remote_name, current_url = get_git_remote()

    if remote_name == "origin":
        # Update existing origin
        r = subprocess.run(
            ["git", "remote", "set-url", "origin", url],
            capture_output=True, text=True, cwd=str(AIBRAIN_ROOT), timeout=10,
        )
    else:
        # Add origin pointing to new repo
        r = subprocess.run(
            ["git", "remote", "add", "origin", url],
            capture_output=True, text=True, cwd=str(AIBRAIN_ROOT), timeout=10,
        )

    if r.returncode == 0:
        print(f"  {c('green', 'Remote set')}: origin -> {url}")
        # Fetch from new remote
        subprocess.run(
            ["git", "fetch", "origin"],
            capture_output=True, text=True, cwd=str(AIBRAIN_ROOT), timeout=30,
        )
        return True
    else:
        print(f"  {c('red', 'Failed')}: {r.stderr.strip()}")
        return False


# ---- Pip Update ----

def pip_update(dry_run=False):
    """Upgrade aibrain-core via pip."""
    print(f"\n{c('teal', '[2/4]')} {c('bold', 'Upgrading aibrain-core package')}")

    if dry_run:
        latest = get_pip_latest_version()
        current = get_pip_installed_version()
        print(f"  Current: {current}")
        print(f"  Latest:  {latest}")
        if current == latest:
            print(f"  {c('green', 'Already up to date')}")
        else:
            print(f"  Would upgrade {current} -> {latest}")
        return True

    r = subprocess.run(
        [sys.executable, "-m", "pip", "install", "--upgrade", "aibrain-core"],
        capture_output=True, text=True, timeout=120,
    )

    if r.returncode == 0:
        new_ver = get_pip_installed_version()
        print(f"  {c('green', 'Upgraded')} to {new_ver}")
        return True
    else:
        print(f"  {c('red', 'Upgrade failed')}: {r.stderr.strip()[:200]}")
        return False


# ---- Post-Update Validation ----

def validate_update():
    """Run basic checks after update to verify nothing is broken."""
    print(f"\n{c('teal', '[3/4]')} {c('bold', 'Validating update')}")
    checks = []

    # 1. Python files parse
    import py_compile
    errors = 0
    total = 0
    for py_file in AIBRAIN_ROOT.glob("**/*.py"):
        if any(skip in str(py_file) for skip in [
            "__pycache__", ".venv", "node_modules", "benchmarks",
            ".git", "runtime",
        ]):
            continue
        total += 1
        try:
            py_compile.compile(str(py_file), doraise=True)
        except py_compile.PyCompileError:
            errors += 1
    status = "PASS" if errors == 0 else "FAIL"
    checks.append((f"Syntax check ({total} files)", status, f"{errors} errors"))
    print(f"  {'OK' if status == 'PASS' else 'FAIL'}: {total} Python files, {errors} errors")

    # 2. DB accessible
    db_found = False
    for name in ["aibrain.db", "agentos.db"]:
        if (AIBRAIN_ROOT / name).exists():
            db_found = True
            db_size = (AIBRAIN_ROOT / name).stat().st_size
            print(f"  OK: {name} ({db_size // 1024}KB)")
            break
    if not db_found:
        print(f"  {c('yellow', 'WARN')}: No database found (will be created on first run)")
    checks.append(("Database", "PASS" if db_found else "WARN", ""))

    # 3. Config preserved
    config_ok = CONFIG_PATH.exists()
    print(f"  {'OK' if config_ok else 'WARN'}: config.json {'preserved' if config_ok else 'missing (using defaults)'}")
    checks.append(("Config", "PASS" if config_ok else "WARN", ""))

    # 4. Key scripts importable
    key_scripts = ["mcp_server.py", "aibrain_db.py", "task_router.py"]
    for script in key_scripts:
        script_path = AIBRAIN_ROOT / script
        if script_path.exists():
            r = subprocess.run(
                [sys.executable, "-c", f"import importlib.util; s=importlib.util.spec_from_file_location('t','{script_path}'); m=importlib.util.module_from_spec(s); s.loader.exec_module(m)"],
                capture_output=True, text=True, timeout=15,
            )
            ok = r.returncode == 0
            print(f"  {'OK' if ok else 'FAIL'}: {script}")
            checks.append((script, "PASS" if ok else "FAIL", ""))

    all_pass = all(s in ("PASS", "WARN") for _, s, _ in checks)
    return all_pass


def install_new_deps():
    """Check for and install any new dependencies."""
    print(f"\n{c('teal', '[4/4]')} {c('bold', 'Checking dependencies')}")
    req_file = AIBRAIN_ROOT / "requirements.txt"
    if req_file.exists():
        r = subprocess.run(
            [sys.executable, "-m", "pip", "install", "-r", str(req_file), "--quiet"],
            capture_output=True, text=True, timeout=120,
        )
        if r.returncode == 0:
            print(f"  {c('green', 'Dependencies OK')}")
        else:
            print(f"  {c('yellow', 'Some deps may need manual install')}")
            if r.stderr:
                print(f"  {r.stderr.strip()[:200]}")
    else:
        print(f"  No requirements.txt found, skipping")


# ---- Main ----

# ---- Auto-Config Free Tier ----

# Default job definitions for free-tier workflows. If a user's scheduled_jobs.json
# is missing any of these, they get added automatically on install/update.
FREE_TIER_JOB_DEFAULTS = {
    "memory_consolidation": {
        "script": "workflows/memory_consolidation.py",
        "cron": "0 3 * * 0",
        "group": "system",
        "description": "Weekly memory consolidation (Sunday 3am)",
    },
    "contradiction_detector": {
        "script": "workflows/contradiction_detector.py",
        "cron": "0 4 * * 3",
        "group": "intelligence",
        "description": "Scan memories for contradictions (Wednesday 4am)",
    },
    "learning_extractor": {
        "script": "workflows/learning_extractor.py",
        "cron": "0 */4 * * *",
        "group": "system",
        "description": "Learning extraction every 4h — error->fix patterns, corrections, decisions.",
    },
    "realtime_learner": {
        "script": "realtime_learner.py --once",
        "cron": "0 */4 * * *",
        "group": "system",
        "description": "Conversation log watcher every 4h — scans AI session logs for learnings.",
    },
    "memory_md_sync": {
        "script": "workflows/memory_md_sync.py --stats-only --all",
        "cron": "0 */4 * * *",
        "group": "system",
        "description": "Sync MEMORY.md files with live DB stats every 4h.",
    },
    "evolution_experiment": {
        "script": "workflows/evolution_experiment.py",
        "cron": "30 8 * * 1-5",
        "group": "evolution",
        "description": "Evolution experiment iteration (weekdays 8:30am)",
    },
    "correction_learner": {
        "script": "run_workflow.py correction_learner",
        "cron": "0 22 * * *",
        "group": "self_learning",
        "description": "Extract lessons from user corrections into permanent skill principles.",
    },
    "memory_hygiene": {
        "script": "run_workflow.py memory_hygiene",
        "cron": "0 4 * * 0",
        "group": "self_learning",
        "description": "Dedup exact duplicates, archive stale low-importance memories.",
    },
    "self_model_refresh": {
        "script": "run_workflow.py self_model_refresh",
        "cron": "0 5 * * 0",
        "group": "self_learning",
        "description": "Rebuild agent self-model from accumulated memories and preferences.",
    },
    "cross_domain_questions": {
        "script": "workflows/cross_domain_questions.py --scan",
        "cron": "0 2 * * 3",
        "group": "self_learning",
        "description": "Find correlations across domains, generate insight questions.",
    },
    "knowledge_gap_detector": {
        "script": "run_workflow.py knowledge_gap_detector",
        "cron": "0 4 * * 1",
        "group": "self_learning",
        "description": "Identify topics the user asks about where the brain has no stored knowledge.",
    },
    "knowledge_decay_alert": {
        "script": "run_workflow.py knowledge_decay",
        "cron": "0 3 1 * *",
        "group": "self_learning",
        "description": "Flag expertise areas not practiced in 30+ days.",
    },
    "goal_drift_detector": {
        "script": "run_workflow.py goal_drift",
        "cron": "0 4 * * 5",
        "group": "self_learning",
        "description": "Compare daily task patterns against stated goals.",
    },
    "session_continuity": {
        "script": "run_workflow.py session_continuity",
        "cron": "0 */2 * * *",
        "group": "self_learning",
        "description": "Verify key memories and context survived compaction or restart.",
    },
    "cron_health": {
        "script": "run_workflow.py cron_health",
        "cron": "0 6 * * *",
        "group": "self_learning",
        "description": "Monitor scheduled workflow execution — find stale or failing jobs.",
    },
    "db_backup": {
        "script": "workflows/db_backup.py",
        "cron": "0 3,15 * * *",
        "group": "system",
        "description": "DB backup twice daily (3am, 3pm)",
    },
    "morning_briefing": {
        "script": "workflows/morning_check_email_summarize.py",
        "cron": "0 7 * * *",
        "group": "productivity",
        "description": "Morning briefing digest — weather, email triage, system status.",
    },
    "weekly_report": {
        "script": "workflows/weekly_report.py",
        "cron": "0 18 * * 5",
        "group": "system",
        "description": "Friday evening weekly report",
    },
    "session_prep": {
        "script": "run_workflow.py session_prep",
        "cron": "0 */4 * * *",
        "group": "self_learning",
        "description": "Prepare session context every 4h — load priorities, recent activity, pending items.",
    },
    "life_dashboard": {
        "script": "run_workflow.py life_dashboard",
        "cron": "0 6 * * *",
        "group": "productivity",
        "description": "Daily life dashboard at 6am — goals, habits, projects, upcoming deadlines.",
    },
    "knowledge_graph_builder": {
        "script": "workflows/knowledge_graph_builder.py",
        "cron": "0 */6 * * *",
        "group": "self_learning",
        "description": "Extract entities and relationships from memories, build knowledge graph. Every 6h.",
    },
    "evolution_auto_loop": {
        "script": "workflows/evolution_auto_loop.py",
        "cron": "0 */12 * * *",
        "group": "self_learning",
        "description": "Auto-improvement cycle: graph insights → hypotheses → experiments → applied principles. Every 12h.",
    },
    "risk_analyst": {
        "script": "workflows/risk_analyst.py --retrospective --hours 24",
        "cron": "0 20 * * *",
        "group": "security",
        "description": "Daily retrospective risk scan — reviews recent actions for things that should have been flagged.",
    },
}


def auto_config_free_tier():
    """Ensure all free-tier workflows exist and are enabled in scheduled_jobs.json.

    Reads workflow_tiers.json for the canonical free tier list. For each workflow:
    - If it exists in scheduled_jobs.json: enable it
    - If it doesn't exist: add it with defaults from FREE_TIER_JOB_DEFAULTS

    Users can turn OFF what they don't want — but on install/update, everything
    free-tier starts ON. This is the "zero config" promise.
    """
    tiers_path = AIBRAIN_ROOT / "workflow_tiers.json"
    jobs_path = AIBRAIN_ROOT / "scheduled_jobs.json"

    # Load free tier list
    if tiers_path.exists():
        try:
            tiers = json.loads(tiers_path.read_text(encoding="utf-8"))
            free_workflows = set(tiers.get("tiers", {}).get("free", {}).get("workflows", []))
        except (json.JSONDecodeError, OSError):
            free_workflows = set(FREE_TIER_JOB_DEFAULTS.keys())
    else:
        # Fallback to hardcoded defaults if tiers file missing
        free_workflows = set(FREE_TIER_JOB_DEFAULTS.keys())

    if not free_workflows:
        return 0, 0

    # Load or create scheduled_jobs.json
    if jobs_path.exists():
        try:
            data = json.loads(jobs_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            data = {"_description": "AIBrain scheduled jobs registry.", "jobs": []}
    else:
        data = {"_description": "AIBrain scheduled jobs registry.", "jobs": []}

    jobs = data.get("jobs", [])
    existing_names = {j["name"] for j in jobs}

    enabled_count = 0
    added_count = 0

    # Enable existing free-tier jobs
    for job in jobs:
        if job["name"] in free_workflows and not job.get("enabled", False):
            job["enabled"] = True
            job["tier"] = "free"
            enabled_count += 1

    # Add missing free-tier jobs
    for wf_name in sorted(free_workflows):
        if wf_name not in existing_names and wf_name in FREE_TIER_JOB_DEFAULTS:
            defaults = FREE_TIER_JOB_DEFAULTS[wf_name]
            new_job = {
                "name": wf_name,
                "script": defaults["script"],
                "cron": defaults["cron"],
                "enabled": True,
                "group": defaults.get("group", "system"),
                "tier": "free",
                "description": defaults["description"],
            }
            jobs.append(new_job)
            added_count += 1

    data["jobs"] = jobs
    data["_updated"] = datetime.datetime.now().strftime("%Y-%m-%d")
    jobs_path.write_text(json.dumps(data, indent=2), encoding="utf-8")

    return enabled_count, added_count


def sync_agent_hooks():
    """Add any new hooks introduced by this update to Claude Code settings."""
    claude_settings = Path.home() / ".claude" / "settings.json"
    if not claude_settings.exists():
        return  # Not using Claude Code

    print(f"\n  {c('bold', 'Syncing agent hooks')}")
    try:
        settings = json.loads(claude_settings.read_text(encoding="utf-8"))
    except Exception:
        return

    hooks = settings.get("hooks", {})
    python = sys.executable
    aibrain_root = str(AIBRAIN_ROOT)
    changed = False

    # All hooks that should exist — add missing ones without touching existing
    required_hooks = {
        "UserPromptSubmit": [{
            "matcher": "*",
            "hooks": [{
                "type": "command",
                "command": f"{python} {aibrain_root}/broker_hook.py",
                "timeout": 5,
                "statusMessage": "Checking broker..."
            }]
        }],
        "PreCompact": [{
            "matcher": "*",
            "hooks": [
                {
                    "type": "command",
                    "command": f"{python} {aibrain_root}/realtime_learner.py",
                    "timeout": 15,
                    "statusMessage": "Extracting learnings before compaction..."
                },
                {
                    "type": "command",
                    "command": f"{python} {aibrain_root}/workflows/memory_md_sync.py --stats-only --all",
                    "timeout": 10,
                    "statusMessage": "Syncing MEMORY.md with DB..."
                }
            ]
        }],
        "PostCompact": [{
            "matcher": "*",
            "hooks": [{
                "type": "command",
                "command": f"{python} {aibrain_root}/workflows/memory_md_sync.py --stats-only --all",
                "timeout": 10,
                "statusMessage": "Syncing MEMORY.md after compaction..."
            }]
        }],
        "Stop": [{
            "matcher": "*",
            "hooks": [{
                "type": "command",
                "command": f"{python} {aibrain_root}/realtime_learner.py",
                "timeout": 10
            }]
        }],
    }

    for hook_name, hook_config in required_hooks.items():
        if hook_name not in hooks:
            hooks[hook_name] = hook_config
            changed = True
            print(f"    Added {hook_name} hook")

    if changed:
        settings["hooks"] = hooks
        claude_settings.write_text(json.dumps(settings, indent=2), encoding="utf-8")
        print(f"  {c('green', 'Hooks updated')}")
    else:
        print(f"  {c('dim', 'All hooks already configured')}")


def sync_mcp_servers():
    """Register any new MCP servers introduced by this update."""
    project_mcp = AIBRAIN_ROOT / ".mcp.json"
    python = sys.executable
    aibrain_root = str(AIBRAIN_ROOT)

    print(f"\n  {c('bold', 'Syncing MCP servers')}")
    try:
        if project_mcp.exists():
            mcp = json.loads(project_mcp.read_text(encoding="utf-8"))
        else:
            mcp = {"mcpServers": {}}
    except Exception:
        mcp = {"mcpServers": {}}

    required_servers = {
        "aibrain-memory": f"{aibrain_root}/mcp_server.py",
        "peer-discovery": f"{aibrain_root}/mcp_peer_discovery.py",
    }

    changed = False
    for name, script in required_servers.items():
        if name not in mcp.get("mcpServers", {}):
            mcp.setdefault("mcpServers", {})[name] = {
                "command": python,
                "args": [script]
            }
            changed = True
            print(f"    Added MCP server: {name}")

    if changed:
        project_mcp.write_text(json.dumps(mcp, indent=2), encoding="utf-8")
        print(f"  {c('green', 'MCP servers updated')}")
    else:
        print(f"  {c('dim', 'All MCP servers already registered')}")


def sync_peer_daemon():
    """Ensure peer daemon autostart is installed for the current platform."""
    try:
        from aibrain_licensing import check_tier
        if not check_tier("pro"):
            print(f"  {c('dim', 'Peer daemon autostart requires Pro tier')}")
            return
    except ImportError:
        pass  # No licensing — development mode

    import platform as _platform
    system = _platform.system()
    print(f"\n  {c('bold', 'Checking peer daemon autostart')}")

    if system == "Linux":
        service = Path.home() / ".config" / "systemd" / "user" / "aibrain-peer-daemon.service"
        if service.exists():
            print(f"  {c('dim', 'systemd service already installed')}")
        else:
            print(f"  {c('yellow', 'Peer daemon service not installed')}")
            print(f"  Run setup wizard to install: python setup_wizard.py")
    elif system == "Darwin":
        plist = Path.home() / "Library" / "LaunchAgents" / "org.aibrain.peer-daemon.plist"
        if plist.exists():
            print(f"  {c('dim', 'launchd agent already installed')}")
        else:
            print(f"  {c('yellow', 'Peer daemon agent not installed')}")
            print(f"  Run setup wizard to install: python setup_wizard.py")
    elif system == "Windows":
        result = subprocess.run(
            ["schtasks", "/Query", "/TN", "AIBrain Peer Daemon"],
            capture_output=True, timeout=5
        )
        if result.returncode == 0:
            print(f"  {c('dim', 'Windows scheduled task already installed')}")
        else:
            print(f"  {c('yellow', 'Peer daemon task not installed')}")
            print(f"  Run setup wizard to install: python setup_wizard.py")
    else:
        print(f"  {c('dim', f'Unknown platform: {system}')}")


def sync_telegram_poller():
    """Check if Telegram poller autostart is installed (if Telegram configured)."""
    # Check if Telegram is configured
    token = os.environ.get("TELEGRAM_TOKEN", "")
    if not token:
        cfg_path = AIBRAIN_ROOT / "config.json"
        if cfg_path.exists():
            try:
                cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
                token = cfg.get("telegram_token", "")
            except Exception:
                pass
    if not token:
        return  # Not configured

    import platform as _platform
    system = _platform.system()
    print(f"\n  {c('bold', 'Checking Telegram poller autostart')}")

    if system == "Linux":
        service = Path.home() / ".config" / "systemd" / "user" / "aibrain-telegram-poller.service"
        if service.exists():
            print(f"  {c('dim', 'systemd service already installed')}")
        else:
            print(f"  {c('yellow', 'Telegram poller service not installed')}")
            print(f"  Run setup wizard to install: python setup_wizard.py")
    elif system == "Darwin":
        plist = Path.home() / "Library" / "LaunchAgents" / "org.aibrain.telegram-poller.plist"
        if plist.exists():
            print(f"  {c('dim', 'launchd agent already installed')}")
        else:
            print(f"  {c('yellow', 'Telegram poller agent not installed')}")
            print(f"  Run setup wizard to install: python setup_wizard.py")
    elif system == "Windows":
        result = subprocess.run(
            ["schtasks", "/Query", "/TN", "AIBrain Telegram Poller"],
            capture_output=True, timeout=5
        )
        if result.returncode == 0:
            print(f"  {c('dim', 'Windows scheduled task already installed')}")
        else:
            print(f"  {c('yellow', 'Telegram poller task not installed')}")
            print(f"  Run setup wizard to install: python setup_wizard.py")


def check_for_updates():
    """Check if updates are available without applying them."""
    print(f"\n{c('bold', 'AIBrain Update Check')}")
    print(f"{'=' * 50}")
    print(f"  Current version: {get_current_version()}")
    print(f"  Install type:    {'git' if is_git_install() else 'pip' if is_pip_install() else 'manual'}")

    if is_git_install():
        remote_name, remote_url = get_git_remote()
        print(f"  Git remote:      {remote_name} ({remote_url})")
        local_sha = get_git_current_sha()
        remote_sha = get_git_remote_sha(remote_name)
        print(f"  Local SHA:       {local_sha}")
        print(f"  Remote SHA:      {remote_sha}")
        if local_sha == remote_sha:
            print(f"\n  {c('green', 'Up to date!')} No new commits.")
        else:
            # Count commits behind
            r = subprocess.run(
                ["git", "rev-list", "--count", f"HEAD..{remote_name}/main"],
                capture_output=True, text=True, cwd=str(AIBRAIN_ROOT), timeout=10,
            )
            behind = r.stdout.strip() if r.returncode == 0 else "?"
            print(f"\n  {c('yellow', f'Update available!')} {behind} commits behind.")
            print(f"  Run: python aibrain_update.py")

    elif is_pip_install():
        current = get_pip_installed_version()
        latest = get_pip_latest_version()
        print(f"  Installed:       {current}")
        print(f"  Latest on PyPI:  {latest}")
        if current == latest:
            print(f"\n  {c('green', 'Up to date!')}")
        else:
            print(f"\n  {c('yellow', f'Update available!')} {current} -> {latest}")
            print(f"  Run: python aibrain_update.py")
    else:
        print(f"  {c('yellow', 'Manual installation detected')}")
        print(f"  Download latest from: https://github.com/{CANONICAL_REPO}")


def _migrate_legacy_db():
    """Migrate any existing brain/memory database to aibrain.db.
    Handles agentos.db, brain.db, memory.db, agent.db, or any *.db with a memories table."""
    import shutil
    import sqlite3

    new_db = AIBRAIN_ROOT / "aibrain.db"

    # If we already have a substantial aibrain.db, skip
    if new_db.exists() and new_db.stat().st_size > 100_000:
        return

    current_size = new_db.stat().st_size if new_db.exists() else 0

    def _is_memory_db(path):
        try:
            conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
            cur = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='memories'")
            has = cur.fetchone() is not None
            conn.close()
            return has
        except Exception:
            return False

    # Check known legacy names + scan for any .db with memories table
    legacy_names = ["agentos.db", "brain.db", "memory.db", "agent.db"]
    search_dirs = [AIBRAIN_ROOT, Path.home() / "agentos", Path.home() / "projects" / "agentos"]
    best_db, best_size = None, current_size

    for d in search_dirs:
        if not d.exists():
            continue
        for name in legacy_names:
            candidate = d / name
            if candidate.exists() and candidate != new_db:
                if _is_memory_db(candidate) and candidate.stat().st_size > best_size:
                    best_db, best_size = candidate, candidate.stat().st_size

    # Also scan install dir for any .db with memories table
    if not best_db:
        for candidate in AIBRAIN_ROOT.glob("*.db"):
            if candidate == new_db or candidate.name.startswith("."):
                continue
            if _is_memory_db(candidate) and candidate.stat().st_size > best_size:
                best_db, best_size = candidate, candidate.stat().st_size

    if best_db:
        print(f"\n  {c('bold', 'Migrating existing brain database')}")
        print(f"  {best_db.name} ({best_size // 1024}KB) -> aibrain.db")
        shutil.copy2(str(best_db), str(new_db))
        for suffix in ["-shm", "-wal"]:
            wal = best_db.parent / (best_db.name + suffix)
            if wal.exists():
                shutil.copy2(str(wal), str(new_db.parent / (new_db.name + suffix)))
        try:
            best_db.rename(best_db.parent / f"{best_db.name}.migrated")
            print(f"  {c('green', 'Migrated')} — old DB backed up as {best_db.name}.migrated")
        except OSError:
            print(f"  {c('green', 'Migrated')} — old DB still at {best_db.name} (in use)")


def run_update(dry_run=False):
    """Execute the full update process."""
    print(f"\n{c('bold', 'AIBrain Updater')}")
    print(f"{'=' * 50}")
    version = get_current_version()
    print(f"  Current version: {version}")

    install_type = "git" if is_git_install() else "pip" if is_pip_install() else "manual"
    print(f"  Install type:    {install_type}")

    if install_type == "manual":
        print(f"\n  {c('yellow', 'Manual installation')} — cannot auto-update.")
        print(f"  Clone the repo: git clone https://github.com/{CANONICAL_REPO}.git")
        return

    # Step 1: Backup
    print(f"\n{c('teal', '[1/4]')} {c('bold', 'Creating backup')}")
    if not dry_run:
        backup_path, backed_up = create_backup("pre-update")
        print(f"  Backed up {len(backed_up)} files to {backup_path.name}")
        for f in backed_up[:5]:
            print(f"    {f}")
        if len(backed_up) > 5:
            print(f"    ... and {len(backed_up) - 5} more")
    else:
        print(f"  Would create backup (dry-run)")

    # Step 2: Update
    if install_type == "git":
        remote_name, remote_url = get_git_remote()
        if not remote_name:
            print(f"  {c('red', 'No git remote configured')}")
            print(f"  Run: python aibrain_update.py --switch-remote {CANONICAL_REPO}")
            return
        success = git_update(remote_name, dry_run=dry_run)
    else:
        success = pip_update(dry_run=dry_run)

    if not success:
        print(f"\n  {c('red', 'Update failed.')} Your data is safe.")
        if not dry_run:
            print(f"  Backup at: {backup_path}")
            print(f"  To restore: python aibrain_update.py --rollback")
        return

    if dry_run:
        print(f"\n  {c('dim', 'Dry run complete. No changes made.')}")
        return

    # Step 2.5: Migrate legacy DB if needed (agentos.db → aibrain.db)
    _migrate_legacy_db()

    # Step 3: Validate
    valid = validate_update()

    # Step 3.5: Sync agent hooks (add any new hooks from this update)
    sync_agent_hooks()

    # Step 3.55: Sync MCP servers (add any new ones from this update)
    sync_mcp_servers()

    # Step 3.57: Ensure peer daemon autostart is installed (Pro tier)
    sync_peer_daemon()

    # Step 3.58: Ensure Telegram poller autostart is installed
    sync_telegram_poller()

    # Step 3.6: Auto-configure free-tier workflows
    print(f"\n  {c('bold', 'Auto-configuring free-tier workflows')}")
    enabled, added = auto_config_free_tier()
    if enabled or added:
        parts = []
        if enabled:
            parts.append(f"enabled {enabled}")
        if added:
            parts.append(f"added {added}")
        print(f"  {c('green', 'Free tier configured')}: {', '.join(parts)} workflows")
    else:
        print(f"  {c('dim', 'All free-tier workflows already configured')}")

    # Step 4: Dependencies
    install_new_deps()

    # Summary
    new_version = get_current_version()
    print(f"\n{'=' * 50}")
    if valid:
        print(f"  {c('green', 'Update successful!')} {version} -> {new_version}")
    else:
        print(f"  {c('yellow', 'Update applied with warnings.')}")
        print(f"  Run: python aibrain_update.py --rollback  to revert")

    print(f"  Backup: {backup_path.name}")
    print()


def main():
    parser = argparse.ArgumentParser(description="AIBrain Updater")
    parser.add_argument("--check", action="store_true",
                        help="Check for updates without applying")
    parser.add_argument("--dry-run", action="store_true",
                        help="Show what would be done without making changes")
    parser.add_argument("--backup-only", action="store_true",
                        help="Just create a backup, no update")
    parser.add_argument("--rollback", action="store_true",
                        help="Restore from most recent backup")
    parser.add_argument("--switch-remote", metavar="OWNER/REPO",
                        help="Switch git remote (e.g. owner/repo)")
    args = parser.parse_args()

    if args.check:
        check_for_updates()
    elif args.backup_only:
        print(f"{c('bold', 'Creating backup...')}")
        path, files = create_backup("manual")
        print(f"  Backed up {len(files)} files to {path}")
    elif args.rollback:
        backup = find_latest_backup()
        if backup:
            print(f"{c('bold', 'Rolling back')} from {backup.name}")
            restore_backup(backup)
        else:
            print(f"{c('red', 'No backups found')} in {BACKUP_DIR}")
    elif args.switch_remote:
        switch_remote(args.switch_remote)
    else:
        run_update(dry_run=args.dry_run)


if __name__ == "__main__":
    main()
