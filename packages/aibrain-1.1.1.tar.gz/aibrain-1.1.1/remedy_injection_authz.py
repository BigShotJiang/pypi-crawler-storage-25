#!/usr/bin/env python3
"""
remedy_injection.py — Remediation chains for injection vulnerabilities.

Covers: SQLi, Command Injection, SSTI, XSS, XXE, NoSQL Injection, LDAP Injection.
Takes a finding from the SARIF parser and generates + optionally applies the fix.

Part of the remediation pipeline: sarif_parser.py → remedy_dispatcher.py → THIS FILE

Each chain returns a RemedyResult with the fix description, code diff, and verification steps.
"""

import json
import logging
import re
from dataclasses import dataclass, field
from typing import Optional, List, Dict

log = logging.getLogger("remediate.injection")


@dataclass
class RemedyResult:
    """Result of a remediation attempt."""
    finding_id: str
    category: str
    status: str = "proposed"  # proposed, applied, verified, failed
    fix_description: str = ""
    code_before: str = ""
    code_after: str = ""
    verification_steps: List[str] = field(default_factory=list)
    compliance_refs: List[str] = field(default_factory=list)
    confidence: float = 0.5
    effort_hours: float = 1.0
    risk: str = "low"  # risk of the fix itself breaking something


# ---------------------------------------------------------------------------
# SQLi Remediation
# ---------------------------------------------------------------------------

def remedy_sqli(finding: Dict) -> RemedyResult:
    """Remediate SQL injection vulnerabilities."""
    endpoint = finding.get("endpoint", "")
    param = finding.get("param", "")
    evidence = finding.get("evidence", "")

    # Detect the injection pattern
    is_union = "union" in evidence.lower() if evidence else False
    is_blind = "sleep" in evidence.lower() or "benchmark" in evidence.lower() if evidence else False
    is_error = "sql" in evidence.lower() and "error" in evidence.lower() if evidence else False

    result = RemedyResult(
        finding_id=finding.get("id", ""),
        category="sqli",
        confidence=0.95,
        effort_hours=2.0,
        compliance_refs=["OWASP A03:2021", "CWE-89", "PCI-DSS 6.2.4"],
    )

    result.fix_description = f"""SQL Injection at {endpoint} via parameter '{param}'

ROOT CAUSE: User input is concatenated directly into SQL query strings
instead of using parameterized queries/prepared statements.

FIX (by framework):

Python (SQLite/psycopg2):
  BEFORE: cursor.execute(f"SELECT * FROM users WHERE id = '{{user_input}}'")
  AFTER:  cursor.execute("SELECT * FROM users WHERE id = ?", (user_input,))

Python (SQLAlchemy):
  BEFORE: db.execute(f"SELECT * FROM users WHERE id = '{{user_input}}'")
  AFTER:  db.execute(text("SELECT * FROM users WHERE id = :id"), {{"id": user_input}})

Node.js (mysql2):
  BEFORE: connection.query(`SELECT * FROM users WHERE id = '${{req.params.id}}'`)
  AFTER:  connection.query('SELECT * FROM users WHERE id = ?', [req.params.id])

PHP (PDO):
  BEFORE: $stmt = $pdo->query("SELECT * FROM users WHERE id = '$id'");
  AFTER:  $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
          $stmt->execute([$id]);

ADDITIONAL HARDENING:
1. Input validation: whitelist expected characters for the parameter
2. Least privilege: database user should have minimum required permissions
3. WAF rule: block common SQLi patterns as defense-in-depth (not primary fix)
"""

    result.verification_steps = [
        f"1. Replay the original payload against {endpoint} with param '{param}'",
        "2. Confirm the response no longer contains SQL error messages",
        "3. Confirm the original UNION/blind/error-based technique no longer works",
        "4. Test with sqlmap --risk=3 --level=5 to verify no bypass exists",
        "5. Verify application functionality is preserved (no false breakage)",
    ]

    return result


# ---------------------------------------------------------------------------
# Command Injection Remediation
# ---------------------------------------------------------------------------

def remedy_cmdi(finding: Dict) -> RemedyResult:
    result = RemedyResult(
        finding_id=finding.get("id", ""),
        category="cmdi",
        confidence=0.95,
        effort_hours=3.0,
        risk="medium",  # shell command changes can break functionality
        compliance_refs=["OWASP A03:2021", "CWE-78"],
    )

    endpoint = finding.get("endpoint", "")
    param = finding.get("param", "")

    result.fix_description = f"""Command Injection at {endpoint} via parameter '{param}'

ROOT CAUSE: User input is passed to shell commands without sanitization.
This typically occurs with os.system(), subprocess.call(shell=True), or
backtick execution.

FIX:
1. ELIMINATE shell=True:
   BEFORE: subprocess.call(f"ping {{host}}", shell=True)
   AFTER:  subprocess.call(["ping", "-c", "1", host])  # no shell interpretation

2. If shell is unavoidable, use shlex.quote():
   import shlex
   subprocess.call(f"ping {{shlex.quote(host)}}", shell=True)

3. INPUT VALIDATION (defense-in-depth):
   - Whitelist: only allow alphanumeric + dots for hostnames
   - Reject: any input containing ; | & $ ` \\ ( ) {{ }}

4. USE LIBRARY FUNCTIONS instead of shell commands:
   - ping → socket.connect() or icmplib
   - curl → requests.get()
   - grep → re.search()
   - ls → os.listdir()
"""

    result.verification_steps = [
        f"1. Replay original payload: {param}=;id or {param}=|whoami",
        "2. Confirm command is no longer executed (no uid= or username in response)",
        "3. Test with chained commands: ;, |, &&, ||, $(), ``",
        "4. Verify legitimate functionality still works",
    ]

    return result


# ---------------------------------------------------------------------------
# XSS Remediation
# ---------------------------------------------------------------------------

def remedy_xss(finding: Dict) -> RemedyResult:
    endpoint = finding.get("endpoint", "")
    param = finding.get("param", "")
    evidence = finding.get("evidence", "")

    # Detect XSS type
    is_stored = "stored" in finding.get("title", "").lower()
    is_dom = "dom" in finding.get("title", "").lower()
    xss_type = "Stored" if is_stored else "DOM-based" if is_dom else "Reflected"

    result = RemedyResult(
        finding_id=finding.get("id", ""),
        category="xss",
        confidence=0.9,
        effort_hours=2.0 if not is_stored else 4.0,
        compliance_refs=["OWASP A03:2021", "CWE-79"],
    )

    result.fix_description = f"""{xss_type} XSS at {endpoint} via parameter '{param}'

ROOT CAUSE: User input is reflected in HTML output without encoding.

FIX (CONTEXT-DEPENDENT — the encoding depends on WHERE the output appears):

1. HTML BODY context:
   Python: from markupsafe import escape; escape(user_input)
   Node:   const he = require('he'); he.encode(userInput)
   PHP:    htmlspecialchars($input, ENT_QUOTES, 'UTF-8')

2. HTML ATTRIBUTE context:
   Always quote attributes AND encode: <div title="{{escape(input)}}">

3. JAVASCRIPT context:
   JSON.stringify() for data, NEVER concatenate into JS strings

4. URL context:
   Python: urllib.parse.quote(input)
   Node:   encodeURIComponent(input)

5. CSS context:
   Whitelist values. Never inject user input into style attributes.

ADDITIONAL HARDENING:
- Content-Security-Policy header: default-src 'self'
- X-Content-Type-Options: nosniff
- HttpOnly + Secure flags on cookies

{"STORED XSS ADDITIONAL: sanitize on INPUT as well as OUTPUT. Review all database writes that accept this parameter." if is_stored else ""}
{"DOM XSS ADDITIONAL: review client-side JavaScript using innerHTML, document.write(), eval(). Use textContent instead of innerHTML." if is_dom else ""}
"""

    result.verification_steps = [
        f"1. Replay: {param}=<script>alert(1)</script>",
        "2. Confirm script tags are encoded in response (&lt;script&gt;)",
        "3. Test event handlers: {param}=\" onmouseover=\"alert(1)",
        "4. Test encoding bypass: {param}=<img/src/onerror=alert(1)>",
        "5. Verify CSP header is present and blocks inline scripts",
    ]

    return result


# ---------------------------------------------------------------------------
# SSTI Remediation
# ---------------------------------------------------------------------------

def remedy_ssti(finding: Dict) -> RemedyResult:
    result = RemedyResult(
        finding_id=finding.get("id", ""),
        category="ssti",
        confidence=0.95,
        effort_hours=3.0,
        risk="medium",
        compliance_refs=["OWASP A03:2021", "CWE-1336"],
    )

    result.fix_description = f"""Server-Side Template Injection at {finding.get('endpoint', '')}

ROOT CAUSE: User input is passed directly into a template engine's render
function, allowing arbitrary code execution on the server.

FIX:
1. NEVER pass user input to template.render() or similar functions
2. Use templates with auto-escaping enabled:
   Jinja2: Environment(autoescape=True)
   Django: auto-escaping is ON by default (don't use |safe on user input)

3. If user-defined templates are required:
   - Use a sandboxed template engine (Jinja2 SandboxedEnvironment)
   - Whitelist allowed template functions
   - Run template rendering in a restricted subprocess

4. INPUT VALIDATION:
   - Reject: {{ }} {{% %}} ${{ }} #{{ }}
   - Whitelist: only allow expected format characters
"""

    result.verification_steps = [
        "1. Replay: {{7*7}} — confirm response does NOT contain 49",
        "2. Test Jinja2: {{config.__class__.__init__.__globals__['os'].popen('id').read()}}",
        "3. Verify template auto-escaping is enabled in framework config",
        "4. Confirm user input is treated as data, not template code",
    ]

    return result


# ---------------------------------------------------------------------------
# XXE Remediation
# ---------------------------------------------------------------------------

def remedy_xxe(finding: Dict) -> RemedyResult:
    result = RemedyResult(
        finding_id=finding.get("id", ""),
        category="xxe",
        confidence=0.95,
        effort_hours=1.0,
        compliance_refs=["OWASP A05:2021", "CWE-611"],
    )

    result.fix_description = f"""XML External Entity (XXE) Injection

ROOT CAUSE: XML parser allows external entity resolution, enabling
file read, SSRF, and potentially RCE via DTD processing.

FIX (by language):

Python (lxml):
  from lxml import etree
  parser = etree.XMLParser(resolve_entities=False, no_network=True)

Python (defusedxml — RECOMMENDED):
  import defusedxml.ElementTree as ET
  tree = ET.parse(input_file)

Java:
  factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
  factory.setFeature("http://xml.org/sax/features/external-general-entities", false);

PHP:
  libxml_disable_entity_loader(true);

Node.js:
  Use a parser that disables DTD by default (fast-xml-parser)

GENERAL: If your API accepts XML, consider switching to JSON.
"""

    result.verification_steps = [
        "1. Send XXE payload: <!DOCTYPE foo [<!ENTITY xxe SYSTEM 'file:///etc/passwd'>]>",
        "2. Confirm /etc/passwd contents do NOT appear in response",
        "3. Test blind XXE with out-of-band callback",
        "4. Verify DTD processing is disabled in parser configuration",
    ]

    return result


# ---------------------------------------------------------------------------
# Authorization Remediation (the second TODO chain)
# ---------------------------------------------------------------------------

def remedy_idor(finding: Dict) -> RemedyResult:
    """Remediate Insecure Direct Object Reference (IDOR)."""
    result = RemedyResult(
        finding_id=finding.get("id", ""),
        category="idor",
        confidence=0.85,
        effort_hours=4.0,
        risk="medium",
        compliance_refs=["OWASP A01:2021", "CWE-639"],
    )

    result.fix_description = f"""IDOR at {finding.get('endpoint', '')}

ROOT CAUSE: The application uses user-supplied object identifiers (IDs)
to access resources without verifying the requesting user has permission
to access that specific resource.

FIX:
1. SERVER-SIDE AUTHORIZATION CHECK on every resource access:
   # BEFORE (vulnerable):
   @app.get("/api/users/{{user_id}}/profile")
   def get_profile(user_id):
       return db.get_user(user_id)  # any user can access any profile

   # AFTER (fixed):
   @app.get("/api/users/{{user_id}}/profile")
   def get_profile(user_id, current_user=Depends(get_current_user)):
       if current_user.id != user_id and not current_user.is_admin:
           raise HTTPException(403, "Access denied")
       return db.get_user(user_id)

2. USE INDIRECT REFERENCES:
   Instead of /api/orders/12345, use /api/my/orders (scoped to session)

3. USE UUIDs instead of sequential integers (defense-in-depth, not primary fix)

4. IMPLEMENT ROW-LEVEL SECURITY in the database:
   CREATE POLICY user_access ON orders FOR SELECT
   USING (user_id = current_setting('app.current_user')::int);
"""

    result.verification_steps = [
        "1. Authenticate as User A, note resource IDs",
        "2. Authenticate as User B, attempt to access User A's resources",
        "3. Confirm 403 Forbidden (not 200 OK with wrong data)",
        "4. Test with admin endpoints — verify admin-only access is enforced",
        "5. Check that error messages don't leak resource existence",
    ]

    return result


def remedy_bfla(finding: Dict) -> RemedyResult:
    """Remediate Broken Function Level Authorization."""
    result = RemedyResult(
        finding_id=finding.get("id", ""),
        category="bfla",
        confidence=0.85,
        effort_hours=6.0,
        risk="medium",
        compliance_refs=["OWASP A01:2021", "CWE-285"],
    )

    result.fix_description = f"""Broken Function Level Authorization at {finding.get('endpoint', '')}

ROOT CAUSE: Administrative or privileged functions are accessible to
regular users because authorization is only checked at the UI level,
not at the API level.

FIX:
1. IMPLEMENT ROLE-BASED ACCESS CONTROL (RBAC) at the API layer:
   @app.delete("/api/admin/users/{{user_id}}")
   @require_role("admin")  # decorator checks JWT/session role
   def delete_user(user_id):
       ...

2. DENY BY DEFAULT — all endpoints require authentication unless
   explicitly marked as public:
   # Middleware approach:
   if not endpoint.is_public and not current_user.has_permission(endpoint.required_role):
       return 403

3. SEPARATE ADMIN ROUTES from user routes:
   /api/v1/users/...   → user endpoints (user role)
   /api/v1/admin/...   → admin endpoints (admin role)

4. AUDIT ALL ENDPOINTS — list every route and its required permission level.
   Any endpoint without an explicit permission check is a vulnerability.
"""

    result.verification_steps = [
        "1. Authenticate as regular user",
        "2. Attempt to call admin endpoints (DELETE, PUT on admin routes)",
        "3. Confirm 403 Forbidden on all privileged operations",
        "4. Verify the response doesn't leak admin-only data",
        "5. Check that HTTP method isn't the only access control (POST vs GET)",
    ]

    return result


def remedy_csrf(finding: Dict) -> RemedyResult:
    """Remediate Cross-Site Request Forgery."""
    result = RemedyResult(
        finding_id=finding.get("id", ""),
        category="csrf",
        confidence=0.9,
        effort_hours=2.0,
        compliance_refs=["OWASP A01:2021", "CWE-352"],
    )

    result.fix_description = f"""CSRF at {finding.get('endpoint', '')}

ROOT CAUSE: State-changing requests don't verify that the request
originated from the application itself.

FIX:
1. CSRF TOKENS — include a unique token in every form/request:
   Python (Flask-WTF): form.csrf_token (automatic)
   Django: {{% csrf_token %}} in templates (automatic)
   Node: csurf middleware

2. SAMESITE COOKIES:
   Set-Cookie: session=abc; SameSite=Strict; Secure; HttpOnly

3. VERIFY ORIGIN/REFERER HEADERS:
   if request.headers.get('Origin') != 'https://yourapp.com':
       return 403

4. For APIs: use Authorization headers (Bearer tokens) instead of cookies.
   Bearer tokens are not automatically sent by browsers, preventing CSRF.
"""

    result.verification_steps = [
        "1. Create an HTML page on a different origin with a form targeting the endpoint",
        "2. Submit the form — confirm the request is rejected (403 or CSRF error)",
        "3. Verify SameSite attribute is set on session cookies",
        "4. Confirm CSRF token is present and validated on all state-changing endpoints",
    ]

    return result


def remedy_mass_assignment(finding: Dict) -> RemedyResult:
    """Remediate mass assignment / over-posting vulnerabilities."""
    result = RemedyResult(
        finding_id=finding.get("id", ""),
        category="mass_assignment",
        confidence=0.9,
        effort_hours=2.0,
        compliance_refs=["OWASP A04:2021", "CWE-915"],
    )

    result.fix_description = f"""Mass Assignment at {finding.get('endpoint', '')}

ROOT CAUSE: The API accepts and processes all fields from the request body,
including fields the user shouldn't be able to modify (is_admin, role, etc.).

FIX:
1. WHITELIST allowed fields explicitly:
   ALLOWED_FIELDS = {{"name", "email", "bio"}}
   data = {{k: v for k, v in request.json.items() if k in ALLOWED_FIELDS}}

2. Use Pydantic models (Python) or DTOs (Java) to define accepted shapes:
   class UserUpdate(BaseModel):
       name: str
       email: str
       # is_admin is NOT here — cannot be set via API

3. NEVER pass request body directly to ORM update:
   # VULNERABLE:
   user.update(**request.json)
   # SAFE:
   user.name = validated_data.name
   user.email = validated_data.email
"""

    result.verification_steps = [
        "1. Send request with extra fields: {\"name\": \"test\", \"is_admin\": true, \"role\": \"admin\"}",
        "2. Confirm is_admin and role are NOT changed in the database",
        "3. Verify only whitelisted fields are accepted",
    ]

    return result


# ---------------------------------------------------------------------------
# Dispatcher — maps finding category to remedy function
# ---------------------------------------------------------------------------

REMEDY_CHAINS = {
    "sqli": remedy_sqli,
    "cmdi": remedy_cmdi,
    "xss": remedy_xss,
    "ssti": remedy_ssti,
    "xxe": remedy_xxe,
    "idor": remedy_idor,
    "bfla": remedy_bfla,
    "csrf": remedy_csrf,
    "mass_assignment": remedy_mass_assignment,
    # Aliases
    "sql_injection": remedy_sqli,
    "command_injection": remedy_cmdi,
    "cross_site_scripting": remedy_xss,
    "template_injection": remedy_ssti,
}


def get_remedy(finding: Dict) -> Optional[RemedyResult]:
    """Look up and execute the appropriate remedy chain for a finding."""
    category = finding.get("category", "").lower()
    chain_fn = REMEDY_CHAINS.get(category)
    if chain_fn:
        return chain_fn(finding)
    return None


def get_all_remedies(findings: List[Dict]) -> List[RemedyResult]:
    """Generate remediation results for all findings that have chains."""
    results = []
    seen_categories = set()

    for f in findings:
        cat = f.get("category", "").lower()
        # One remedy per category (they're class-level fixes, not per-finding)
        if cat in seen_categories:
            continue
        remedy = get_remedy(f)
        if remedy:
            results.append(remedy)
            seen_categories.add(cat)

    return results


def remediation_report(findings: List[Dict]) -> Dict:
    """Generate a complete remediation report with prioritized fixes."""
    remedies = get_all_remedies(findings)

    # Prioritize by confidence × effort (quick wins first)
    remedies.sort(key=lambda r: r.confidence / max(r.effort_hours, 0.5), reverse=True)

    total_effort = sum(r.effort_hours for r in remedies)

    return {
        "total_remediation_chains": len(remedies),
        "total_effort_hours": round(total_effort, 1),
        "categories_covered": [r.category for r in remedies],
        "remedies": [
            {
                "category": r.category,
                "status": r.status,
                "confidence": r.confidence,
                "effort_hours": r.effort_hours,
                "risk": r.risk,
                "fix_description": r.fix_description,
                "verification_steps": r.verification_steps,
                "compliance_refs": r.compliance_refs,
            }
            for r in remedies
        ],
    }
