#!/usr/bin/env python3
"""
Storage-Time Enrichment Pipeline for AIBrain Memory

The psycho-cybernetics insight: do the heavy lifting at encoding time,
not retrieval time. If FTS5 can't find the document at query time, it's
already too late. Bridge the vocabulary gap BEFORE the query arrives.

Extracted from the Claude.ai deep-dive consultation codebase.
"""

import re
import logging
from collections import defaultdict
from dataclasses import dataclass, field
from typing import List, Dict, Set, Tuple

log = logging.getLogger("storage_enricher")


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 1. HYPERNYM / VOCABULARY BRIDGE DICTIONARIES
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

HYPERNYM_MAP = {
    # Food & Dining
    "italian": ["restaurant", "dining", "food", "cuisine"],
    "chinese": ["restaurant", "dining", "food", "cuisine"],
    "thai": ["restaurant", "dining", "food", "cuisine"],
    "mexican": ["restaurant", "dining", "food", "cuisine"],
    "japanese": ["restaurant", "dining", "food", "cuisine"],
    "sushi": ["restaurant", "dining", "food", "japanese"],
    "pizza": ["restaurant", "dining", "food", "italian"],
    "burger": ["restaurant", "dining", "food", "fast_food"],
    "cafe": ["restaurant", "dining", "coffee", "food"],
    "bistro": ["restaurant", "dining", "food"],
    "diner": ["restaurant", "dining", "food"],
    "brunch": ["dining", "food", "meal", "restaurant"],
    "takeout": ["dining", "food", "restaurant", "delivery"],
    "delivery": ["dining", "food", "restaurant", "takeout", "order"],
    "cocktail": ["drink", "beverage", "recipe", "alcohol", "mix", "bar", "class", "making", "course"],
    "beer": ["drink", "beverage", "alcohol", "bar", "pub"],
    "wine": ["drink", "beverage", "alcohol", "bar", "dining"],
    "coffee": ["drink", "beverage", "cafe", "morning"],
    "tea": ["drink", "beverage", "hot_drink"],
    "recipe": ["cooking", "food", "meal", "prepare", "ingredients", "make"],
    "cooking": ["recipe", "food", "meal", "kitchen", "prepare"],
    "baking": ["cooking", "recipe", "food", "kitchen"],
    "ingredients": ["recipe", "cooking", "food", "grocery"],
    # Travel & Places
    "hotel": ["accommodation", "travel", "lodging", "stay"],
    "airbnb": ["accommodation", "travel", "lodging", "stay", "rental"],
    "hostel": ["accommodation", "travel", "lodging", "stay"],
    "flight": ["travel", "transportation", "trip"],
    "train": ["travel", "transportation", "commute"],
    "uber": ["travel", "transportation", "ride"],
    "taxi": ["travel", "transportation", "ride"],
    "beach": ["vacation", "travel", "destination", "holiday"],
    "mountain": ["hiking", "outdoor", "nature", "travel"],
    "trail": ["hiking", "outdoor", "nature", "walk"],
    "park": ["outdoor", "nature", "recreation"],
    "museum": ["culture", "attraction", "visit", "tourism"],
    "concert": ["entertainment", "music", "event", "show", "performance", "gig", "live_music"],
    "theater": ["entertainment", "culture", "event", "show", "performance"],
    "cinema": ["entertainment", "movie", "film", "show"],
    "gig": ["concert", "music", "event", "show", "performance", "live_music"],
    "show": ["concert", "event", "performance", "entertainment"],
    "performance": ["concert", "show", "event", "entertainment", "music"],
    "festival": ["event", "music", "concert", "entertainment", "outdoor"],
    # Work & Career
    "interview": ["job", "career", "employment", "work"],
    "resume": ["job", "career", "employment", "application"],
    "salary": ["job", "career", "compensation", "income", "pay"],
    "promotion": ["job", "career", "advancement", "work"],
    "manager": ["boss", "supervisor", "work", "colleague"],
    "coworker": ["colleague", "work", "team"],
    "meeting": ["work", "schedule", "appointment"],
    "deadline": ["work", "schedule", "task", "due"],
    "project": ["work", "task", "assignment"],
    "presentation": ["work", "meeting", "talk"],
    "startup": ["company", "business", "work", "entrepreneurship"],
    "freelance": ["work", "job", "self_employed", "career"],
    # Health & Wellness
    "gym": ["exercise", "fitness", "workout", "health"],
    "yoga": ["exercise", "fitness", "wellness", "health"],
    "running": ["exercise", "fitness", "cardio", "sport"],
    "swimming": ["exercise", "fitness", "sport", "pool"],
    "doctor": ["health", "medical", "appointment", "healthcare"],
    "dentist": ["health", "medical", "appointment", "dental"],
    "therapy": ["health", "mental_health", "wellness", "counseling"],
    "medication": ["health", "medical", "prescription", "treatment"],
    "diet": ["health", "nutrition", "food", "weight"],
    "allergy": ["health", "medical", "food", "condition"],
    "headache": ["health", "pain", "symptom"],
    "insomnia": ["health", "sleep", "condition"],
    # Education
    "course": ["education", "learning", "class", "study", "lesson", "training", "certification"],
    "lecture": ["education", "learning", "class", "university", "lesson"],
    "class": ["course", "education", "learning", "lesson", "training"],
    "lesson": ["class", "course", "education", "learning", "training"],
    "certification": ["course", "education", "qualification", "training", "credential"],
    "workshop": ["class", "course", "training", "education", "learning"],
    "tutorial": ["class", "course", "lesson", "education", "learning"],
    "homework": ["education", "assignment", "study", "school"],
    "exam": ["education", "test", "assessment", "study"],
    "professor": ["teacher", "education", "university", "instructor"],
    "textbook": ["book", "education", "study", "reading"],
    "thesis": ["education", "research", "writing", "academic"],
    "degree": ["education", "qualification", "university"],
    "scholarship": ["education", "funding", "financial_aid"],
    # Technology
    "laptop": ["computer", "device", "technology"],
    "phone": ["device", "mobile", "technology", "smartphone"],
    "tablet": ["device", "technology", "ipad"],
    "app": ["software", "application", "technology"],
    "website": ["internet", "online", "technology", "web"],
    "password": ["security", "account", "login", "credential"],
    "update": ["software", "technology", "upgrade"],
    "bug": ["software", "issue", "problem", "error"],
    # Home & Living
    "apartment": ["home", "housing", "residence", "living"],
    "house": ["home", "housing", "residence", "property"],
    "rent": ["housing", "expense", "monthly", "cost"],
    "mortgage": ["housing", "finance", "loan", "property"],
    "landlord": ["housing", "rental", "property"],
    "furniture": ["home", "decor", "interior"],
    "kitchen": ["home", "cooking", "room"],
    "bedroom": ["home", "sleep", "room"],
    "garden": ["home", "outdoor", "plants"],
    # Finance
    "savings": ["money", "finance", "bank", "budget"],
    "investment": ["money", "finance", "stock", "portfolio"],
    "credit_card": ["money", "finance", "payment", "debt"],
    "loan": ["money", "finance", "debt", "borrowing"],
    "budget": ["money", "finance", "planning", "expense"],
    "tax": ["money", "finance", "government", "annual"],
    "insurance": ["finance", "protection", "policy", "coverage"],
    # Relationships
    "boyfriend": ["partner", "relationship", "dating", "significant_other"],
    "girlfriend": ["partner", "relationship", "dating", "significant_other"],
    "spouse": ["partner", "relationship", "marriage", "family"],
    "husband": ["partner", "relationship", "marriage", "family"],
    "wife": ["partner", "relationship", "marriage", "family"],
    "friend": ["relationship", "social", "companion"],
    "roommate": ["living", "companion", "housing", "shared"],
    "parent": ["family", "relationship", "mother", "father"],
    "sibling": ["family", "relationship", "brother", "sister"],
    # Pets
    "dog": ["pet", "animal", "companion"],
    "cat": ["pet", "animal", "companion"],
    "puppy": ["pet", "animal", "dog", "companion"],
    "kitten": ["pet", "animal", "cat", "companion"],
    "vet": ["pet", "animal", "health", "medical"],
    # Entertainment
    "netflix": ["streaming", "entertainment", "movie", "show", "watching"],
    "spotify": ["music", "streaming", "entertainment", "listening"],
    "podcast": ["audio", "entertainment", "listening", "show"],
    "book": ["reading", "entertainment", "literature"],
    "novel": ["book", "reading", "fiction", "literature"],
    "game": ["entertainment", "gaming", "play", "recreation"],
    "series": ["show", "entertainment", "watching", "television"],
    # Social & Events
    "party": ["event", "gathering", "celebration", "social", "get_together"],
    "gathering": ["event", "party", "social", "get_together", "meetup"],
    "reunion": ["event", "gathering", "family", "social", "meetup"],
    "meetup": ["event", "gathering", "social", "group"],
    "ceremony": ["event", "graduation", "wedding", "celebration", "formal"],
    "graduation": ["ceremony", "event", "education", "milestone", "achievement"],
    "wedding": ["ceremony", "event", "celebration", "marriage"],
    # Aquarium & Hobbies
    "aquarium": ["fish", "tank", "pet", "hobby", "aquatic"],
    "fish": ["aquarium", "pet", "tank", "aquatic"],
    "tank": ["aquarium", "fish", "container"],
    # Online & Digital
    "social_media": ["online", "internet", "platform", "digital", "screen_time"],
    "screen_time": ["social_media", "phone", "digital", "online", "usage"],
    "instagram": ["social_media", "platform", "online", "photo"],
    "facebook": ["social_media", "platform", "online"],
    "twitter": ["social_media", "platform", "online"],
    "tiktok": ["social_media", "platform", "online", "video"],
    # Charity & Community
    "charity": ["donation", "fundraising", "volunteer", "community", "giving"],
    "donation": ["charity", "giving", "money", "fundraising"],
    "volunteer": ["charity", "community", "help", "service"],
    "fundraising": ["charity", "event", "money", "donation", "community"],
    # Research & Academic
    "publication": ["research", "academic", "paper", "journal", "conference"],
    "conference": ["event", "academic", "research", "publication", "professional", "meeting"],
    "journal": ["publication", "research", "academic", "paper"],
    "paper": ["publication", "research", "academic", "writing"],
    "research": ["academic", "study", "publication", "investigation"],
    # Transportation
    "car": ["vehicle", "driving", "transportation", "automobile"],
    "vehicle": ["car", "transportation", "driving"],
    "driving": ["car", "vehicle", "transportation", "commute"],
    "service": ["maintenance", "repair", "appointment", "car"],
    "mechanic": ["car", "repair", "service", "maintenance"],
    # Groups & Clubs
    "club": ["group", "organization", "membership", "social", "joined"],
    "group": ["club", "organization", "community", "team", "joined"],
    "membership": ["club", "group", "joined", "subscription"],
    "joined": ["signed_up", "member", "enrolled", "group", "club"],
    # Music & Performance (expanded for "music event" gap)
    "jazz": ["music", "concert", "performance", "live_music", "genre"],
    "rock": ["music", "concert", "genre", "band"],
    "classical": ["music", "concert", "orchestra", "genre"],
    "band": ["music", "group", "concert", "performance"],
    "singer": ["music", "artist", "performer", "concert"],
    "DJ": ["music", "event", "party", "dance", "club"],
    "live": ["concert", "performance", "event", "music", "show"],
    # Expanded compound activity terms
    "making": ["creating", "crafting", "building", "class", "workshop", "course"],
    "experimenting": ["trying", "testing", "exploring", "learning"],
    "practicing": ["training", "learning", "exercise", "rehearsal"],
    # Writing & Creative
    "writing": ["creative", "story", "poem", "author", "composition"],
    "story": ["writing", "narrative", "fiction", "creative"],
    "poem": ["writing", "poetry", "creative", "verse"],
    "poetry": ["writing", "poem", "creative", "literature"],
    "novel": ["book", "writing", "fiction", "story", "reading"],
    "challenge": ["competition", "contest", "goal", "task"],
    # Data & Learning (for courses gap)
    "coursera": ["course", "online_learning", "education", "certification"],
    "udemy": ["course", "online_learning", "education"],
    "certification": ["course", "education", "qualification", "training", "credential"],
    "data_analysis": ["analytics", "data_science", "statistics", "course"],
    "programming": ["coding", "software", "development", "course", "technology"],
    # Car & Vehicle (for service/issue gap)
    "serviced": ["maintenance", "repair", "car", "service", "mechanic", "checkup"],
    "detailing": ["car", "cleaning", "maintenance", "service"],
    "issue": ["problem", "trouble", "fault", "concern", "repair"],
    "problem": ["issue", "trouble", "fault", "concern", "fix"],
    # Breaks & Pauses
    "hiatus": ["break", "pause", "time_off", "stopped"],
    "detox": ["break", "cleanse", "health", "digital_detox"],
    # Food delivery (expanded)
    "dominos": ["pizza", "delivery", "food_delivery", "ordering", "takeout"],
    "pizza_hut": ["pizza", "delivery", "food_delivery", "ordering"],
    # Medical & Academic domains
    "deep_learning": ["AI", "machine_learning", "research", "technology", "neural_network"],
    "medical": ["health", "doctor", "hospital", "clinical", "patient"],
    "analysis": ["research", "study", "examination", "investigation"],
    # Industry & Manufacturing
    "manufacturing": ["industry", "production", "factory", "business", "employment"],
    "factory": ["manufacturing", "industry", "production", "work", "employment"],
    "industry": ["business", "manufacturing", "sector", "employment"],
    "employs": ["hires", "employment", "workers", "staff", "jobs"],
    # Gin specific (for cocktail preference gap)
    "gin": ["cocktail", "drink", "alcohol", "beverage", "spirit"],
    "tequila": ["cocktail", "drink", "alcohol", "beverage", "spirit"],
    "vodka": ["cocktail", "drink", "alcohol", "beverage", "spirit"],
    "rum": ["cocktail", "drink", "alcohol", "beverage", "spirit"],
    "whiskey": ["cocktail", "drink", "alcohol", "beverage", "spirit"],
}

ACTION_BRIDGES = {
    "suggest": ["recommend", "recommendation", "advice"],
    "recommend": ["suggest", "recommendation", "advice"],
    "try": ["recommend", "suggestion", "experience"],
    "check out": ["recommend", "suggestion", "visit"],
    "should go": ["recommend", "suggestion", "visit"],
    "you'd like": ["recommend", "preference", "suggestion"],
    "you might enjoy": ["recommend", "preference", "suggestion"],
    "love": ["prefer", "favorite", "preference", "enjoy"],
    "enjoy": ["prefer", "like", "preference", "favorite"],
    "prefer": ["favorite", "preference", "like", "choose"],
    "favorite": ["prefer", "best", "preference", "top"],
    "can't stand": ["dislike", "hate", "preference", "avoid"],
    "not a fan": ["dislike", "preference", "avoid"],
    "hate": ["dislike", "preference", "avoid", "negative"],
    "obsessed with": ["love", "favorite", "preference", "passion"],
    "decided": ["decision", "choice", "plan", "chose"],
    "planning": ["plan", "schedule", "future", "intention"],
    "going to": ["plan", "intention", "future", "schedule"],
    "thinking about": ["considering", "plan", "possibility"],
    "want to": ["desire", "goal", "intention", "plan"],
    "need to": ["requirement", "task", "obligation"],
    "booked": ["reservation", "plan", "scheduled", "appointment"],
    "signed up": ["registered", "joined", "enrollment"],
    "went to": ["visited", "experience", "trip", "outing"],
    "visited": ["went", "experience", "trip", "travel"],
    "tried": ["experienced", "tasted", "sampled", "attempt"],
    "bought": ["purchased", "acquired", "shopping", "expense"],
    "moved to": ["relocated", "move", "housing", "new_home"],
    "started": ["began", "new", "beginning", "commenced"],
    "finished": ["completed", "done", "ended"],
    "quit": ["stopped", "left", "resigned", "ended"],
    "told me": ["said", "mentioned", "information", "stated"],
    "mentioned": ["said", "told", "brought_up", "noted"],
    "explained": ["described", "told", "information", "taught"],
    "asked about": ["inquired", "question", "curious"],
    "learned": ["discovered", "found_out", "education", "knowledge"],
    "found out": ["discovered", "learned", "information"],
    "heard": ["learned", "told", "information", "news"],
    # Multi-session bridges (aggregation queries)
    "how many": ["count", "total", "number", "quantity"],
    "in total": ["count", "sum", "combined", "altogether"],
    "all the": ["every", "each", "complete", "all"],
    "both": ["two", "pair", "combined", "together"],
    # Temporal action bridges
    "first": ["initial", "earliest", "before", "beginning", "original"],
    "last": ["most_recent", "final", "latest", "previous"],
    "recently": ["lately", "just", "new", "current"],
    "just got": ["recently", "new", "acquired", "obtained"],
    # Delivery/ordering bridges
    "ordered": ["delivery", "purchased", "bought", "food_delivery"],
    "uber eats": ["food_delivery", "delivery", "ordering", "restaurant"],
    "doordash": ["food_delivery", "delivery", "ordering", "restaurant"],
    "grubhub": ["food_delivery", "delivery", "ordering", "restaurant"],
    # Break/pause bridges
    "break": ["pause", "stop", "hiatus", "time_off", "rest"],
    "took a break": ["paused", "stopped", "hiatus", "rested"],
    # Participation bridges
    "participated": ["attended", "joined", "took_part", "involved"],
    "attended": ["went_to", "participated", "present", "visited"],
    "raised": ["collected", "fundraised", "gathered", "earned"],
    "completed": ["finished", "done", "accomplished", "passed"],
    # Aggregation/counting bridges (multi-session queries)
    "three times": ["multiple", "repeated", "frequently", "often"],
    "twice": ["two_times", "again", "repeated"],
    "every week": ["weekly", "regular", "routine", "recurring"],
    "every day": ["daily", "routine", "regular", "recurring"],
    # Creative/hobby action bridges
    "wrote": ["writing", "composed", "created", "authored"],
    "reading": ["book", "novel", "literature", "studying"],
    "experimenting": ["trying", "testing", "exploring", "new"],
    # Car action bridges
    "got serviced": ["maintenance", "repair", "car_service", "checkup"],
    "broke down": ["malfunction", "issue", "problem", "repair"],
    "took it in": ["service", "repair", "mechanic", "appointment"],
    # Social/community action bridges
    "donated": ["charity", "gave", "contributed", "fundraising"],
    "raised money": ["fundraising", "charity", "donation", "event"],
    "participated in": ["attended", "joined", "took_part", "involved_in"],
    # Week/day references (temporal)
    "on fridays": ["weekly", "schedule", "routine", "friday", "day_of_week"],
    "on saturdays": ["weekly", "schedule", "routine", "saturday", "day_of_week"],
    "last saturday": ["recent", "weekend", "past", "event"],
    "last weekend": ["recent", "saturday", "sunday", "past"],
    "this week": ["current", "recent", "ongoing"],
    "three weeks ago": ["past", "recent", "time_reference"],
    "mid-january": ["january", "date", "time_reference", "winter"],
}

MEMORY_TYPE_PATTERNS = {
    "preference": [
        r"\b(?:love|hate|prefer|favorite|enjoy|like|dislike|can't stand|obsessed)\b",
        r"\b(?:best|worst|always|never)\b.*\b(?:choose|pick|go with|order)\b",
        r"\bmy (?:go-to|usual|regular|typical)\b",
        r"\b(?:rather|instead of|over)\b",
    ],
    "factual": [
        r"\b(?:is|are|was|were|has|have|had)\b.*\b(?:a|an|the)\b",
        r"\b(?:name|address|number|birthday|born|age|live|work)\b",
        r"\b(?:located|situated|found) (?:at|in|on)\b",
    ],
    "temporal": [
        r"\b(?:yesterday|today|tomorrow|last|next|ago|since|until|before|after)\b",
        r"\b(?:january|february|march|april|may|june|july|august|september|october|november|december)\b",
        r"\b(?:monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b",
        r"\b\d{4}\b",
        r"\b(?:morning|afternoon|evening|night|noon)\b",
        r"\b(?:week|month|year|day|hour|minute)\b",
    ],
    "event": [
        r"\b(?:went|visited|attended|saw|met|came|arrived|left|departed)\b",
        r"\b(?:happened|occurred|took place)\b",
        r"\b(?:party|wedding|birthday|celebration|ceremony|meeting|conference)\b",
        r"\b(?:trip|vacation|holiday|journey|travel)\b",
    ],
    "decision": [
        r"\b(?:decided|chose|picked|selected|opted|went with)\b",
        r"\b(?:going to|plan to|will|intend to|want to)\b",
        r"\b(?:signed up|enrolled|registered|booked|reserved)\b",
    ],
}

TOPIC_ROOMS = {
    "food_dining": ["restaurant", "food", "eat", "cook", "recipe", "meal", "dinner", "lunch",
                     "breakfast", "snack", "drink", "coffee", "tea", "bar", "pub", "wine", "beer",
                     "cocktail", "cooking", "baking", "ingredients", "delivery", "takeout", "order"],
    "work_career": ["job", "work", "office", "career", "salary", "boss", "meeting", "project",
                     "deadline", "interview", "resume", "promotion", "colleague", "client"],
    "health_fitness": ["health", "doctor", "exercise", "gym", "yoga", "diet", "sleep", "medical",
                       "sick", "pain", "therapy", "wellness", "weight", "nutrition"],
    "travel": ["travel", "trip", "flight", "hotel", "vacation", "visit", "destination", "airport",
               "beach", "mountain", "country", "city", "tour"],
    "education": ["school", "university", "course", "study", "class", "exam", "teacher", "learn",
                  "homework", "degree", "student", "research"],
    "finance": ["money", "bank", "budget", "savings", "investment", "expense", "cost", "price",
                "salary", "rent", "mortgage", "tax", "insurance"],
    "relationships": ["friend", "family", "partner", "dating", "relationship", "marriage", "love",
                      "boyfriend", "girlfriend", "parent", "child", "sibling"],
    "entertainment": ["movie", "music", "book", "game", "show", "concert", "netflix", "read",
                      "watch", "play", "hobby", "fun", "gig", "performance", "festival", "event"],
    "social_community": ["charity", "volunteer", "fundraising", "community", "group", "club",
                         "membership", "joined", "participated", "event", "gathering", "party"],
    "pets_animals": ["dog", "cat", "pet", "fish", "aquarium", "tank", "vet", "animal",
                     "puppy", "kitten", "breed", "walk"],
    "digital_online": ["social_media", "screen_time", "app", "online", "digital", "instagram",
                       "facebook", "twitter", "tiktok", "youtube", "streaming"],
    "home_living": ["home", "apartment", "house", "room", "furniture", "move", "rent", "neighbor",
                    "clean", "garden", "decor", "repair"],
    "technology": ["computer", "phone", "app", "software", "internet", "device", "code",
                   "programming", "website", "update", "tech"],
}


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 2. ENRICHMENT RESULT
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@dataclass
class EnrichmentResult:
    session_id: str
    original_content: str
    retrieval_tags: Set[str] = field(default_factory=set)
    entities: Dict[str, Set[str]] = field(default_factory=lambda: defaultdict(set))
    memory_type: str = "general"
    memory_type_confidence: float = 0.0
    topic_rooms: Set[str] = field(default_factory=set)
    search_phrases: List[str] = field(default_factory=list)
    enriched_content: str = ""

    def get_fts_content(self) -> str:
        tag_string = " ".join(sorted(self.retrieval_tags))
        room_string = " ".join(sorted(self.topic_rooms))
        type_string = self.memory_type
        phrase_string = " ".join(self.search_phrases)
        parts = [self.original_content]
        if tag_string:
            parts.append(tag_string)
        if room_string:
            parts.append(room_string)
        if type_string != "general":
            parts.append(type_string)
        if phrase_string:
            parts.append(phrase_string)
        return " ".join(parts)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 3. ENRICHMENT NODES
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def extract_entities(text: str) -> Dict[str, Set[str]]:
    entities = defaultdict(set)
    text_lower = text.lower()

    sentences = re.split(r'[.!?]\s+', text)
    for sentence in sentences:
        words = sentence.split()
        for i, word in enumerate(words):
            if i == 0:
                continue
            cleaned = re.sub(r'[^a-zA-Z\'-]', '', word)
            if cleaned and cleaned[0].isupper() and len(cleaned) > 1:
                if cleaned.lower() not in {'i', 'the', 'a', 'an', 'is', 'are', 'was', 'were',
                                            'and', 'or', 'but', 'so', 'my', 'your', 'their',
                                            'he', 'she', 'it', 'we', 'they', 'this', 'that',
                                            'just', 'really', 'very', 'also', 'well', 'now',
                                            'then', 'here', 'there', 'oh', 'yeah', 'yes', 'no'}:
                    entities["named_entity"].add(cleaned)

    for match in re.finditer(r'\$[\d,]+(?:\.\d{2})?|\d+\s*(?:dollars|euros|pounds|bucks)', text_lower):
        entities["money"].add(match.group())

    for match in re.finditer(r'(?:in|at|to|from|near|on)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)', text):
        entities["location"].add(match.group(1))

    return dict(entities)


def generate_retrieval_tags(text: str, entities: Dict[str, Set[str]]) -> Set[str]:
    tags = set()
    text_lower = text.lower()
    words = set(re.findall(r'\b[a-z]+\b', text_lower))

    # Strategy 1: Hypernym expansion
    for word in words:
        if word in HYPERNYM_MAP:
            tags.update(HYPERNYM_MAP[word])

    # Strategy 2: Action bridges
    for action, bridges in ACTION_BRIDGES.items():
        if action in text_lower:
            tags.update(bridges)

    # Strategy 3: Role-based inference
    preference_indicators = [
        (r'\b(?:i|my|we)\b.*\b(?:love|enjoy|prefer|like|adore)\b', ["preference", "favorite", "opinion"]),
        (r'\b(?:i|my|we)\b.*\b(?:hate|dislike|can\'t stand|avoid)\b', ["preference", "dislike", "opinion"]),
        (r'\bmy (?:favorite|preferred|go-to|usual)\b', ["preference", "favorite", "top_choice"]),
        (r'\b(?:always|usually|typically)\b.*\b(?:go|get|order|choose|pick)\b', ["preference", "habit", "routine"]),
        (r'\b(?:best|worst)\b.*\b(?:ever|i\'ve)\b', ["preference", "opinion", "superlative"]),
    ]
    for pattern, bridge_tags in preference_indicators:
        if re.search(pattern, text_lower):
            tags.update(bridge_tags)

    # Strategy 4: Temporal bridges
    temporal_bridges = [
        (r'\blast\s+(?:week|month|year|summer|winter|spring|fall|autumn)\b', ["past", "time_reference", "history"]),
        (r'\bnext\s+(?:week|month|year|summer|winter|spring|fall|autumn)\b', ["future", "plan", "upcoming"]),
        (r'\b(?:every|each)\s+(?:week|month|year|day|morning|evening)\b', ["routine", "recurring", "schedule", "habit"]),
        (r'\b(?:recently|lately|these days)\b', ["recent", "current", "ongoing"]),
        (r'\b(?:used to|back when|years ago|long ago)\b', ["past", "history", "previous"]),
    ]
    for pattern, bridge_tags in temporal_bridges:
        if re.search(pattern, text_lower):
            tags.update(bridge_tags)

    # Strategy 5: Event type detection
    event_bridges = [
        (r'\b(?:birthday|anniversary|graduation|wedding|funeral)\b', ["celebration", "event", "milestone"]),
        (r'\b(?:meeting|appointment|interview|consultation)\b', ["scheduled", "event", "calendar"]),
        (r'\b(?:vacation|trip|holiday|travel|journey)\b', ["travel", "experience", "away"]),
        (r'\b(?:moved|relocat|new (?:home|apartment|house|place))\b', ["moving", "housing", "relocation", "change"]),
    ]
    for pattern, bridge_tags in event_bridges:
        if re.search(pattern, text_lower):
            tags.update(bridge_tags)

    # Strategy 6: Entity-derived tags
    if entities.get("money"):
        tags.update(["expense", "cost", "financial", "price"])
    if entities.get("location"):
        tags.update(["place", "location", "where"])

    return tags


def classify_memory_type(text: str) -> Tuple[str, float]:
    scores = {}
    for mem_type, patterns in MEMORY_TYPE_PATTERNS.items():
        score = 0
        for pattern in patterns:
            matches = len(re.findall(pattern, text, re.IGNORECASE))
            score += matches
        scores[mem_type] = score / len(patterns) if patterns else 0

    if not scores or max(scores.values()) == 0:
        return "general", 0.0

    best_type = max(scores, key=scores.get)
    best_score = scores[best_type]
    second_best = sorted(scores.values(), reverse=True)[1] if len(scores) > 1 else 0
    confidence = min(1.0, (best_score - second_best) / max(best_score, 0.001))
    return best_type, round(confidence, 3)


def assign_topic_rooms(text: str) -> Set[str]:
    text_lower = text.lower()
    words = set(re.findall(r'\b[a-z]+\b', text_lower))

    room_scores = {}
    for room, keywords in TOPIC_ROOMS.items():
        overlap = len(words.intersection(keywords))
        if overlap > 0:
            room_scores[room] = overlap

    if not room_scores:
        return set()

    threshold = max(1, min(room_scores.values()))
    rooms = {room for room, score in room_scores.items() if score >= threshold}
    if len(rooms) > 3:
        rooms = set(sorted(room_scores, key=room_scores.get, reverse=True)[:3])
    return rooms


def generate_search_phrases(text: str, memory_type: str, entities: Dict[str, Set[str]]) -> List[str]:
    phrases = []
    text_lower = text.lower()

    for entity_type, entity_set in entities.items():
        for entity in entity_set:
            if entity_type == "named_entity":
                phrases.append(f"about {entity}")
                phrases.append(f"mentioned {entity}")
            elif entity_type == "location":
                phrases.append(f"place {entity}")

    if memory_type == "preference":
        phrases.extend(["what do I like", "what do I prefer", "my favorite", "preference"])
    elif memory_type == "temporal":
        phrases.extend(["when did", "how long ago", "what time"])
    elif memory_type == "event":
        phrases.extend(["what happened", "tell me about when", "experience"])
    elif memory_type == "decision":
        phrases.extend(["what did I decide", "what did I choose", "my plan", "decision"])

    for match in re.finditer(r'\b([a-z]+)\s+(place|restaurant|store|shop|hotel|app|book|movie|show|game|course|class|club|group|service|event|concert|break|trip)\b', text_lower):
        phrases.append(f"{match.group(1)} {match.group(2)}")
        phrases.append(match.group(2))

    # Activity-based phrases (for "how many X" aggregation queries)
    activity_patterns = [
        (r'\b(?:took|take|taking)\s+(?:a\s+)?(\w+(?:\s+\w+)?)\s+(?:class|course|lesson)\b', "class"),
        (r'\b(?:attended|went to|visited)\s+(?:a\s+)?(\w+)\b', "attended"),
        (r'\b(?:completed|finished)\s+(?:a\s+)?(\w+(?:\s+\w+)?)\s+(?:course|program|certification)\b', "completed course"),
        (r'\b(\w+)\s+delivery\b', "delivery service"),
        (r'\btook\s+a\s+(?:\w+\s+)?break\b', "took break"),
        (r'\b(?:raised|donated)\s+\$?[\d,]+', "raised money charity"),
        (r'\b(\d+)\s+(?:neon\s+)?(?:tetra|guppy|gourami|fish|catfish|pleco)\b', "fish aquarium"),
    ]
    for pattern, label in activity_patterns:
        if re.search(pattern, text_lower):
            phrases.append(label)

    # Day-of-week anchors (for "what day" queries)
    for day in ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]:
        if day in text_lower:
            phrases.append(f"on {day}")
            phrases.append(f"day {day}")
            phrases.append("day_of_week schedule")

    return phrases[:20]  # Increased from 10 to 20


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 5. MAIN ENRICHER CLASS
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

class StorageEnricher:
    def enrich(self, content: str, session_id: str = "") -> EnrichmentResult:
        result = EnrichmentResult(session_id=session_id, original_content=content)
        result.entities = extract_entities(content)
        result.memory_type, result.memory_type_confidence = classify_memory_type(content)
        result.topic_rooms = assign_topic_rooms(content)
        result.retrieval_tags = generate_retrieval_tags(content, result.entities)
        result.search_phrases = generate_search_phrases(content, result.memory_type, result.entities)
        result.enriched_content = result.get_fts_content()
        return result
