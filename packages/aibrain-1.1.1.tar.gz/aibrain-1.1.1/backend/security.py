"""
AIBrain Security Utilities — SSRF protection, URL validation, rate limiting, auth.
Phase 2 security hardening. No external dependencies.
"""

import base64
import hashlib
import hmac
import ipaddress
import json
import logging
import os
import secrets
import threading
import time
from collections import defaultdict
from urllib.parse import urlparse

logger = logging.getLogger(__name__)

from fastapi import Request
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware


# ---------------------------------------------------------------------------
# SSRF Protection — block internal/dangerous URLs
# ---------------------------------------------------------------------------

# Private/reserved IP ranges that should never be hit from user-supplied URLs
_BLOCKED_NETWORKS = [
    ipaddress.ip_network("127.0.0.0/8"),       # Loopback
    ipaddress.ip_network("10.0.0.0/8"),         # RFC1918
    ipaddress.ip_network("172.16.0.0/12"),      # RFC1918
    ipaddress.ip_network("192.168.0.0/16"),     # RFC1918
    ipaddress.ip_network("169.254.0.0/16"),     # Link-local
    ipaddress.ip_network("0.0.0.0/8"),          # "This" network
    ipaddress.ip_network("::1/128"),            # IPv6 loopback
    ipaddress.ip_network("fc00::/7"),           # IPv6 private
    ipaddress.ip_network("fe80::/10"),          # IPv6 link-local
]

_ALLOWED_SCHEMES = {"http", "https"}


def validate_url(url: str) -> tuple[bool, str]:
    """Validate a URL for SSRF safety.

    Returns (is_safe, reason). If is_safe is False, reason explains why.
    """
    if not url or not isinstance(url, str):
        return False, "Empty or invalid URL"

    try:
        parsed = urlparse(url.strip())
    except Exception as e:
        logger.warning("Malformed URL rejected: %s", e)
        return False, "Malformed URL"

    # Block dangerous schemes
    if parsed.scheme.lower() not in _ALLOWED_SCHEMES:
        return False, f"Blocked scheme: {parsed.scheme}. Only http/https allowed"

    hostname = parsed.hostname
    if not hostname:
        return False, "No hostname in URL"

    # Resolve hostname to IP and check against blocked ranges
    try:
        import socket
        # Resolve all addresses for the hostname
        addr_infos = socket.getaddrinfo(hostname, parsed.port or 80, proto=socket.IPPROTO_TCP)
        for family, _, _, _, sockaddr in addr_infos:
            ip = ipaddress.ip_address(sockaddr[0])
            for network in _BLOCKED_NETWORKS:
                if ip in network:
                    return False, f"Blocked: {hostname} resolves to internal IP ({ip})"
    except socket.gaierror:
        return False, f"Cannot resolve hostname: {hostname}"
    except Exception as e:
        return False, f"URL validation error: {str(e)[:100]}"

    return True, "ok"


def require_safe_url(url: str) -> str:
    """Validate URL and raise ValueError if unsafe. Returns the URL if safe."""
    is_safe, reason = validate_url(url)
    if not is_safe:
        raise ValueError(reason)
    return url


# ---------------------------------------------------------------------------
# Rate Limiting Middleware — simple in-memory token bucket per IP
# ---------------------------------------------------------------------------

class RateLimitMiddleware(BaseHTTPMiddleware):
    """Per-IP rate limiting with configurable limits per path prefix.

    Default: 60 req/min for API endpoints, 10 req/min for auth endpoints.
    Uses a sliding window counter (resets each minute).
    """

    def __init__(self, app, general_rpm: int = 60, auth_rpm: int = 10):
        super().__init__(app)
        self.general_rpm = general_rpm
        self.auth_rpm = auth_rpm
        # {ip: {"count": int, "window_start": float}}
        self._general: dict[str, dict] = defaultdict(lambda: {"count": 0, "window_start": 0.0})
        self._auth: dict[str, dict] = defaultdict(lambda: {"count": 0, "window_start": 0.0})
        # Paths that get stricter rate limits
        self._auth_prefixes = ("/api/agent/approvals/", "/api/auth", "/api/setup")
        # Cleanup tracking — prune stale IP entries every 5 minutes
        self._last_cleanup: float = 0.0

    # IPs of trusted reverse proxies — only trust X-Forwarded-For from these
    _TRUSTED_PROXIES = frozenset({"127.0.0.1", "::1"})

    def _get_client_ip(self, request: Request) -> str:
        """Extract client IP. Only trusts X-Forwarded-For from known proxies."""
        client_ip = request.client.host if request.client else "unknown"
        if client_ip in self._TRUSTED_PROXIES:
            forwarded = request.headers.get("x-forwarded-for")
            if forwarded:
                return forwarded.split(",")[0].strip()
        return client_ip

    def _check_limit(self, bucket: dict, rpm: int) -> tuple[bool, int]:
        """Check if request is within rate limit. Returns (allowed, remaining)."""
        now = time.time()
        # Reset window if expired (60-second sliding window)
        if now - bucket["window_start"] >= 60:
            bucket["count"] = 0
            bucket["window_start"] = now

        bucket["count"] += 1
        remaining = max(0, rpm - bucket["count"])
        return bucket["count"] <= rpm, remaining

    def _prune_stale_entries(self):
        """Remove IP entries whose rate window expired >120s ago to prevent unbounded growth."""
        now = time.time()
        if now - self._last_cleanup < 300:  # Only run every 5 minutes
            return
        self._last_cleanup = now
        cutoff = now - 120
        stale = [ip for ip, b in self._general.items() if b["window_start"] < cutoff]
        for ip in stale:
            del self._general[ip]
        stale = [ip for ip, b in self._auth.items() if b["window_start"] < cutoff]
        for ip in stale:
            del self._auth[ip]

    async def dispatch(self, request: Request, call_next):
        # Skip rate limiting for WebSocket upgrades and health checks
        path = request.url.path
        if path.startswith("/ws/") or path in ("/health", "/health/deep"):  # noqa:PATH-STARTSWITH-BYPASS
            return await call_next(request)

        # Only rate-limit API paths
        if not path.startswith("/api"):  # noqa:PATH-STARTSWITH-BYPASS
            return await call_next(request)

        self._prune_stale_entries()

        client_ip = self._get_client_ip(request)

        # Skip rate limiting for localhost (local-first product)
        if client_ip in ("127.0.0.1", "::1", "localhost"):
            return await call_next(request)

        # Determine which bucket to use
        is_auth_path = any(path.startswith(p) for p in self._auth_prefixes)  # noqa:PATH-STARTSWITH-BYPASS
        if is_auth_path:
            allowed, remaining = self._check_limit(self._auth[client_ip], self.auth_rpm)
            limit = self.auth_rpm
        else:
            allowed, remaining = self._check_limit(self._general[client_ip], self.general_rpm)
            limit = self.general_rpm

        if not allowed:
            return JSONResponse(
                {"error": "Rate limit exceeded. Try again in 60 seconds."},
                status_code=429,
                headers={
                    "X-RateLimit-Limit": str(limit),
                    "X-RateLimit-Remaining": "0",
                    "Retry-After": "60",
                },
            )

        response = await call_next(request)
        response.headers["X-RateLimit-Limit"] = str(limit)
        response.headers["X-RateLimit-Remaining"] = str(remaining)
        return response


# ---------------------------------------------------------------------------
# Authentication Middleware — API key (local) + JWT (remote)
# ---------------------------------------------------------------------------
# Auth modes (set via aibrain_db.config_set("auth_mode", mode)):
#   "none"    — no auth required (dev/local only)
#   "api_key" — require X-API-Key header (single-user local)
#   "jwt"     — require Bearer token (multi-user/remote)
#
# API keys are stored hashed (SHA-256) in config as "api_keys" list.
# JWT uses HS256 with a server-generated secret stored in config as "jwt_secret".
# ---------------------------------------------------------------------------

# Paths that never require auth
_AUTH_BYPASS_PATHS = frozenset({
    "/health", "/api/health", "/api/ready",
    "/docs", "/openapi.json", "/redoc",
    # /api/health/deep is intentionally NOT here — it requires auth
})
# WebSocket auth: first-message token validation.
# On connect, client must send {"type": "auth", "token": "<api_key_or_jwt>"}
# within 5 seconds or the connection is closed.
# Only token verify is unauthenticated — all other auth mgmt requires auth.
# NOTE: prefix matching uses exact path or path+/ to prevent traversal bypass
_AUTH_BYPASS_PREFIXES = ("/api/auth/verify",)


def _hash_key(key: str) -> str:
    """SHA-256 hash of an API key for safe storage."""
    return hashlib.sha256(key.encode()).hexdigest()


def generate_api_key() -> str:
    """Generate a new 48-char URL-safe API key."""
    return secrets.token_urlsafe(36)


# --------------- Minimal JWT (HS256, no PyJWT dep) ---------------

def _b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()


def _b64url_decode(s: str) -> bytes:
    padding = 4 - len(s) % 4
    if padding != 4:
        s += "=" * padding
    return base64.urlsafe_b64decode(s)


_JWT_ISSUER = "aibrain"
_JWT_AUDIENCE = "aibrain-client"


def jwt_encode(payload: dict, secret: str, ttl: int = 86400) -> str:
    """Create a HS256 JWT. ttl in seconds (default 24h)."""
    header = {"alg": "HS256", "typ": "JWT"}
    now = int(time.time())
    payload = {**payload, "iat": now, "exp": now + ttl,
               "iss": _JWT_ISSUER, "aud": _JWT_AUDIENCE}

    segments = [
        _b64url_encode(json.dumps(header, separators=(",", ":")).encode()),
        _b64url_encode(json.dumps(payload, separators=(",", ":")).encode()),
    ]
    signing_input = f"{segments[0]}.{segments[1]}".encode()
    sig = hmac.new(secret.encode(), signing_input, hashlib.sha256).digest()
    segments.append(_b64url_encode(sig))
    return ".".join(segments)


def jwt_decode(token: str, secret: str) -> dict | None:
    """Decode and verify a HS256 JWT. Returns payload or None if invalid/expired."""
    try:
        parts = token.split(".")
        if len(parts) != 3:
            return None

        signing_input = f"{parts[0]}.{parts[1]}".encode()
        expected_sig = hmac.new(secret.encode(), signing_input, hashlib.sha256).digest()
        actual_sig = _b64url_decode(parts[2])

        if not hmac.compare_digest(expected_sig, actual_sig):
            return None

        payload = json.loads(_b64url_decode(parts[1]))

        # Check expiration
        if payload.get("exp", 0) < int(time.time()):
            return None

        # Validate issuer and audience (skip for legacy tokens that lack these fields)
        if "iss" in payload and payload["iss"] != _JWT_ISSUER:
            return None
        if "aud" in payload and payload["aud"] != _JWT_AUDIENCE:
            return None

        return payload
    except Exception as e:
        logger.warning("JWT decode failed: %s", e)
        return None


_jwt_secret_lock = threading.Lock()


class AuthMiddleware(BaseHTTPMiddleware):
    """Authentication middleware supporting API key and JWT modes.

    Auth mode is read from aibrain_db config on each request so it can be
    changed at runtime without restart. Lazy-imports aibrain_db to avoid
    circular imports at module load time.
    """

    def __init__(self, app):
        super().__init__(app)
        self._db = None

    def _get_db(self):
        """Lazy import to avoid circular dependency with main.py."""
        if self._db is None:
            import aibrain_db
            self._db = aibrain_db
        return self._db

    def _get_auth_mode(self) -> str:
        db = self._get_db()
        return db.config_get("auth_mode", "api_key")

    def _get_jwt_secret(self) -> str:
        db = self._get_db()
        secret = db.config_get("jwt_secret")
        if secret:
            return secret
        # Double-checked locking — prevents two requests racing to write different secrets
        with _jwt_secret_lock:
            secret = db.config_get("jwt_secret")
            if not secret:
                secret = secrets.token_hex(32)
                db.config_set("jwt_secret", secret)
        return secret

    def _verify_api_key(self, key: str) -> bool:
        db = self._get_db()
        stored_keys = db.config_get("api_keys", [])
        if not stored_keys:
            return False
        hashed = _hash_key(key)
        return any(hmac.compare_digest(hashed, sk) for sk in stored_keys)

    def _verify_jwt(self, token: str) -> dict | None:
        secret = self._get_jwt_secret()
        return jwt_decode(token, secret)

    def _should_bypass(self, path: str) -> bool:
        import posixpath
        # Normalize first — prevents ../  traversal bypass like /api/auth/verify/../agent/approvals
        normalized = posixpath.normpath(path)
        if normalized in _AUTH_BYPASS_PATHS:
            return True
        # Match prefix exactly or with trailing slash — prevents /api/auth/verify-evil bypass
        return any(normalized == p or normalized.startswith(p + "/") for p in _AUTH_BYPASS_PREFIXES)

    async def dispatch(self, request: Request, call_next):
        path = request.url.path

        # Always bypass auth for health, docs, websockets, and auth endpoints
        if self._should_bypass(path):
            return await call_next(request)

        # Only protect API paths
        if not path.startswith("/api"):
            return await call_next(request)

        auth_mode = self._get_auth_mode()

        # No auth configured — pass through (dev mode)
        if auth_mode == "none":
            return await call_next(request)

        # API Key mode
        if auth_mode == "api_key":
            key = request.headers.get("x-api-key")
            if not key:
                return JSONResponse(
                    {"error": "Missing API key. Provide X-API-Key header."},
                    status_code=401,
                )
            if not self._verify_api_key(key):
                return JSONResponse(
                    {"error": "Invalid API key."},
                    status_code=403,
                )
            return await call_next(request)

        # JWT mode
        if auth_mode == "jwt":
            auth_header = request.headers.get("authorization", "")
            if not auth_header.lower().startswith("bearer "):
                return JSONResponse(
                    {"error": "Missing or malformed Authorization header. Use: Bearer <token>"},
                    status_code=401,
                )
            token = auth_header[7:].strip()
            payload = self._verify_jwt(token)
            if payload is None:
                return JSONResponse(
                    {"error": "Invalid or expired JWT token."},
                    status_code=403,
                )
            # Attach user info to request state for downstream handlers
            request.state.user = payload.get("sub", "anonymous")
            request.state.jwt_payload = payload
            return await call_next(request)

        # Unknown auth mode — fail closed
        return JSONResponse(
            {"error": f"Unknown auth mode: {auth_mode}. Set auth_mode to none/api_key/jwt."},
            status_code=500,
        )


# ---------------------------------------------------------------------------
# Auth API helpers — called by auth endpoints in main.py
# ---------------------------------------------------------------------------

def create_api_key() -> tuple[str, str]:
    """Generate a new API key. Returns (plaintext_key, hashed_key).
    Caller must store the hash and give the plaintext to the user ONCE."""
    key = generate_api_key()
    return key, _hash_key(key)


def register_api_key(db_module) -> str:
    """Generate, hash, and store a new API key. Returns the plaintext key."""
    key, hashed = create_api_key()
    existing = db_module.config_get("api_keys", [])
    existing.append(hashed)
    db_module.config_set("api_keys", existing)
    return key


def revoke_api_key(db_module, key_prefix: str) -> bool:
    """Revoke an API key by its first 8 chars (prefix match on hash). Returns success."""
    existing = db_module.config_get("api_keys", [])
    before = len(existing)
    existing = [k for k in existing if not k.startswith(key_prefix)]
    if len(existing) == before:
        return False
    db_module.config_set("api_keys", existing)
    return True


def issue_jwt(db_module, subject: str, ttl: int = 86400) -> str:
    """Issue a JWT token for the given subject. ttl in seconds (default 24h)."""
    secret = db_module.config_get("jwt_secret")
    if not secret:
        secret = secrets.token_hex(32)
        db_module.config_set("jwt_secret", secret)
    return jwt_encode({"sub": subject}, secret, ttl)


# ---------------------------------------------------------------------------
# Request ID Middleware — trace requests across logs
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# WebSocket Auth — first-message token validation
# ---------------------------------------------------------------------------

async def ws_authenticate(websocket, timeout: float = 5.0) -> bool:
    """Require first message to be an auth token. Returns True if valid.

    Expected message: {"type": "auth", "token": "<api_key_or_jwt>"}
    On auth_mode "none", always returns True (dev/local).
    On localhost (127.0.0.1), always returns True (local-first product).
    """
    # Local connections skip auth (local-first product)
    client_ip = websocket.client.host if websocket.client else "unknown"
    if client_ip in ("127.0.0.1", "::1"):
        return True

    import aibrain_db
    auth_mode = aibrain_db.config_get("auth_mode", "api_key")
    if auth_mode == "none":
        return True

    import asyncio
    try:
        data = await asyncio.wait_for(websocket.receive_json(), timeout=timeout)
    except (asyncio.TimeoutError, Exception):
        await websocket.close(code=4001, reason="Auth timeout — send auth message within 5s")
        return False

    if data.get("type") != "auth" or not data.get("token"):
        await websocket.close(code=4002, reason="First message must be {type: auth, token: ...}")
        return False

    token = data["token"]

    if auth_mode == "api_key":
        hashed = _hash_key(token)
        stored_keys = aibrain_db.config_get("api_keys", [])
        if stored_keys and any(hmac.compare_digest(hashed, sk) for sk in stored_keys):
            return True
        await websocket.close(code=4003, reason="Invalid API key")
        return False

    if auth_mode == "jwt":
        secret = aibrain_db.config_get("jwt_secret", "")
        if secret and jwt_decode(token, secret) is not None:
            return True
        await websocket.close(code=4003, reason="Invalid or expired JWT")
        return False

    await websocket.close(code=4003, reason=f"Unknown auth mode: {auth_mode}")
    return False


class RequestIdMiddleware(BaseHTTPMiddleware):
    """Add a unique request ID to every response for tracing.

    Generates X-Request-ID if not provided by client/proxy.
    Stores on request.state for downstream handlers to use in logs.
    """

    async def dispatch(self, request: Request, call_next):
        import re
        req_id = request.headers.get("x-request-id") or secrets.token_hex(8)
        req_id = re.sub(r'[^a-zA-Z0-9\-]', '', req_id)[:64]
        request.state.request_id = req_id
        response = await call_next(request)
        response.headers["X-Request-ID"] = req_id
        return response


# ---------------------------------------------------------------------------
# Input Sanitization helpers
# ---------------------------------------------------------------------------

def safe_limit(value: int, max_val: int = 500, min_val: int = 1) -> int:
    """Clamp a LIMIT value to safe bounds."""
    return min(max(min_val, value), max_val)
