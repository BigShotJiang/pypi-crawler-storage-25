"""
critic_generator.py — Reusable generate→critique→iterate pattern.

Two-node loop that produces progressively refined outputs. The generator
creates content, the critic scores and suggests improvements, then the
generator incorporates feedback. Stops when quality threshold is met or
max iterations reached.

Works with any LLM provider via chat_responder.get_response().

Usage:
    from critic_generator import run_critic_loop, CriticConfig

    result = run_critic_loop(
        task="Write a technical blog post about reactive engines",
        context="AIBrain uses a Rete-inspired reactive engine...",
        config=CriticConfig(quality_threshold=8, max_iterations=3),
    )
    # result.final_output — the refined text
    # result.iterations — list of all generate/critique rounds
    # result.converged — True if quality threshold was met
"""

import json
import logging
import time
from dataclasses import dataclass, field
from typing import Optional

log = logging.getLogger("critic_generator")


@dataclass
class CriticConfig:
    """Configuration for the critic-generator loop."""
    quality_threshold: int = 7          # 1-10, stop if critic scores >= this
    max_iterations: int = 3             # hard cap on rounds
    generator_model: str = "auto"       # model hint for generator
    critic_model: str = "auto"          # model hint for critic (can differ)
    generator_system: str = ""          # custom system prompt for generator
    critic_system: str = ""             # custom system prompt for critic
    domain: str = "general"             # task domain for model cascade routing
    temperature: float = 0.7            # creativity level


@dataclass
class Iteration:
    """Record of a single generate→critique round."""
    round: int
    generated: str
    critique: str
    score: int
    suggestions: list[str]
    duration_s: float


@dataclass
class CriticResult:
    """Final result from the critic-generator loop."""
    final_output: str
    iterations: list[Iteration]
    converged: bool
    total_duration_s: float
    task: str
    config: CriticConfig


def _build_generator_prompt(task: str, context: str, feedback: str = "",
                             config: CriticConfig = None) -> str:
    """Build the prompt for the generator node."""
    parts = []
    if config and config.generator_system:
        parts.append(config.generator_system)
    else:
        parts.append(
            "You are an expert content generator. Produce high-quality, "
            "well-structured output for the given task. Be thorough but concise."
        )

    parts.append(f"\n## Task\n{task}")

    if context:
        parts.append(f"\n## Context\n{context}")

    if feedback:
        parts.append(
            f"\n## Feedback from Previous Round\n"
            f"Incorporate ALL of the following improvements:\n{feedback}"
        )

    parts.append(
        "\nProduce your best output now. Do not include meta-commentary "
        "about the task — just produce the deliverable."
    )
    return "\n".join(parts)


def _build_critic_prompt(task: str, output: str, iteration: int,
                          config: CriticConfig = None) -> str:
    """Build the prompt for the critic node."""
    system = ""
    if config and config.critic_system:
        system = config.critic_system
    else:
        system = (
            "You are a rigorous quality reviewer. Score the output 1-10 and "
            "provide specific, actionable improvements. Be honest — a score of "
            "7+ means genuinely good work, not participation trophy grading."
        )

    return f"""{system}

## Original Task
{task}

## Output to Review (iteration {iteration})
{output}

## Instructions
Respond in EXACTLY this JSON format (no markdown fences, no extra text):
{{"score": <1-10>, "strengths": ["..."], "weaknesses": ["..."], "suggestions": ["specific improvement 1", "specific improvement 2"]}}

Score meaning: 1-3 = poor, 4-6 = adequate, 7-8 = good, 9-10 = excellent.
Be calibrated: most first drafts are 4-6. A score of 8+ should be rare."""


def _parse_critique(raw: str) -> tuple[int, list[str], str]:
    """Parse the critic's JSON response into (score, suggestions, raw_critique).

    Tolerant of common LLM formatting issues (markdown fences, extra text).
    """
    # Strip markdown code fences if present
    text = raw.strip()
    if text.startswith("```"):
        lines = text.split("\n")
        # Remove first and last fence lines
        lines = [l for l in lines if not l.strip().startswith("```")]
        text = "\n".join(lines).strip()

    # Try to find JSON object in the text
    start = text.find("{")
    end = text.rfind("}") + 1
    if start >= 0 and end > start:
        try:
            data = json.loads(text[start:end])
            score = int(data.get("score", 5))
            score = max(1, min(10, score))
            suggestions = data.get("suggestions", [])
            weaknesses = data.get("weaknesses", [])
            # Combine suggestions and weaknesses for feedback
            all_feedback = suggestions + [f"Fix: {w}" for w in weaknesses]
            return score, all_feedback, raw
        except (json.JSONDecodeError, ValueError, TypeError):
            pass

    # Fallback: try to extract score from text
    import re
    score_match = re.search(r'(?:score|rating)\s*(?:is|[=:])\s*(\d+)', text, re.IGNORECASE)
    if not score_match:
        score_match = re.search(r'(\d+)\s*(?:out of|/)\s*10', text)
    score = int(score_match.group(1)) if score_match else 5
    return max(1, min(10, score)), [], raw


def run_critic_loop(
    task: str,
    context: str = "",
    config: Optional[CriticConfig] = None,
    llm_fn=None,
) -> CriticResult:
    """Execute the generate→critique→iterate loop.

    Args:
        task: What to generate (the assignment)
        context: Background info, source material, constraints
        config: Loop configuration (thresholds, iterations, models)
        llm_fn: LLM callable (str → str). Defaults to chat_responder.get_response

    Returns:
        CriticResult with final output, all iterations, and convergence status
    """
    config = config or CriticConfig()

    if llm_fn is None:
        from chat_responder import get_response
        llm_fn = get_response

    iterations = []
    feedback = ""
    best_output = ""
    best_score = 0
    converged = False
    start = time.monotonic()

    for i in range(1, config.max_iterations + 1):
        round_start = time.monotonic()

        # --- Generate ---
        gen_prompt = _build_generator_prompt(task, context, feedback, config)
        generated = llm_fn(gen_prompt)

        if not generated or not generated.strip():
            log.warning("Generator produced empty output on round %d", i)
            generated = best_output or "(empty)"

        # --- Critique ---
        crit_prompt = _build_critic_prompt(task, generated, i, config)
        raw_critique = llm_fn(crit_prompt)

        score, suggestions, critique_text = _parse_critique(raw_critique or "")

        round_time = time.monotonic() - round_start

        iteration = Iteration(
            round=i,
            generated=generated,
            critique=critique_text,
            score=score,
            suggestions=suggestions,
            duration_s=round(round_time, 2),
        )
        iterations.append(iteration)

        log.info("Round %d: score=%d/%d threshold=%d (%d suggestions)",
                 i, score, 10, config.quality_threshold, len(suggestions))

        # Track best output
        if score > best_score:
            best_score = score
            best_output = generated

        # Check convergence
        if score >= config.quality_threshold:
            converged = True
            best_output = generated
            log.info("Converged at round %d with score %d", i, score)
            break

        # Build feedback for next round
        if suggestions:
            feedback = "\n".join(f"- {s}" for s in suggestions)
        elif critique_text:
            feedback = critique_text

    total_time = time.monotonic() - start

    return CriticResult(
        final_output=best_output,
        iterations=iterations,
        converged=converged,
        total_duration_s=round(total_time, 2),
        task=task,
        config=config,
    )


# ---------------------------------------------------------------------------
# Specialized loops for common AIBrain tasks
# ---------------------------------------------------------------------------

def refine_email_draft(subject: str, body: str, tone: str = "professional") -> CriticResult:
    """Refine an email draft through critic loop."""
    return run_critic_loop(
        task=f"Write an email with subject: {subject}",
        context=f"Draft to refine:\n{body}\n\nTone: {tone}",
        config=CriticConfig(
            quality_threshold=8,
            max_iterations=2,
            critic_system=(
                "You are an email quality reviewer. Score 1-10 on: clarity, "
                "professionalism, conciseness, and whether it achieves the sender's goal. "
                "Respond in JSON format: {\"score\": N, \"strengths\": [...], \"weaknesses\": [...], \"suggestions\": [...]}"
            ),
        ),
    )


def refine_report_section(title: str, content: str, audience: str = "technical") -> CriticResult:
    """Refine a report section through critic loop."""
    return run_critic_loop(
        task=f"Write a report section titled: {title}",
        context=f"Content to refine:\n{content}\n\nAudience: {audience}",
        config=CriticConfig(
            quality_threshold=8,
            max_iterations=3,
            critic_system=(
                "You are a technical writing reviewer. Score 1-10 on: accuracy, "
                "structure, completeness, and clarity for the target audience. "
                "Respond in JSON format: {\"score\": N, \"strengths\": [...], \"weaknesses\": [...], \"suggestions\": [...]}"
            ),
        ),
    )


def refine_code_output(task_description: str, code: str, language: str = "python") -> CriticResult:
    """Refine generated code through critic loop."""
    return run_critic_loop(
        task=f"Write {language} code: {task_description}",
        context=f"Code to refine:\n```{language}\n{code}\n```",
        config=CriticConfig(
            quality_threshold=8,
            max_iterations=3,
            critic_system=(
                "You are a senior code reviewer. Score 1-10 on: correctness, "
                "readability, efficiency, error handling, and security. "
                "Respond in JSON format: {\"score\": N, \"strengths\": [...], \"weaknesses\": [...], \"suggestions\": [...]}"
            ),
        ),
    )


# ---------------------------------------------------------------------------
# API router for integration with AIBrain backend
# ---------------------------------------------------------------------------

def create_router():
    """Create FastAPI router for critic-generator endpoints."""
    from fastapi import APIRouter
    from models import CriticRunRequest, EmailRefineRequest, ReportRefineRequest, CodeRefineRequest

    router = APIRouter(prefix="/api/agent/critic", tags=["critic-generator"])

    @router.post("/run")
    async def run_loop(body: CriticRunRequest):
        """Run a critic-generator loop."""
        config = CriticConfig(
            quality_threshold=body.config.get("quality_threshold", 7),
            max_iterations=body.config.get("max_iterations", 3),
            generator_system=body.config.get("generator_system", ""),
            critic_system=body.config.get("critic_system", ""),
            domain=body.config.get("domain", "general"),
        )

        result = run_critic_loop(task=body.task, context=body.context, config=config)

        return {
            "final_output": result.final_output,
            "converged": result.converged,
            "iterations": [
                {
                    "round": it.round,
                    "score": it.score,
                    "suggestions": it.suggestions,
                    "duration_s": it.duration_s,
                    "output_preview": it.generated[:500],
                }
                for it in result.iterations
            ],
            "total_duration_s": result.total_duration_s,
            "best_score": max((it.score for it in result.iterations), default=0),
        }

    @router.post("/refine/email")
    async def refine_email(body: EmailRefineRequest):
        """Refine an email draft."""
        result = refine_email_draft(body.subject, body.body, body.tone)
        return {
            "refined": result.final_output,
            "score": result.iterations[-1].score if result.iterations else 0,
            "converged": result.converged,
            "rounds": len(result.iterations),
        }

    @router.post("/refine/report")
    async def refine_report(body: ReportRefineRequest):
        """Refine a report section."""
        result = refine_report_section(body.title, body.content, body.audience)
        return {
            "refined": result.final_output,
            "score": result.iterations[-1].score if result.iterations else 0,
            "converged": result.converged,
            "rounds": len(result.iterations),
        }

    @router.post("/refine/code")
    async def refine_code(body: CodeRefineRequest):
        """Refine generated code."""
        result = refine_code_output(body.task, body.code, body.language)
        return {
            "refined": result.final_output,
            "score": result.iterations[-1].score if result.iterations else 0,
            "converged": result.converged,
            "rounds": len(result.iterations),
        }

    return router
