"""
AIBrain Action Executor — runs the action behind an approved item.
Called by main.py after an approval is marked approved.
"""

import json
import os
import shlex
import smtplib
import sqlite3
import subprocess
import sys
from datetime import datetime
from email.mime.text import MIMEText
from pathlib import Path


AIBRAIN_ROOT = Path(__file__).parent.parent
ACTIVITY_DB_PATH = AIBRAIN_ROOT / "activity.db"
APPROVAL_DB_PATH = AIBRAIN_ROOT / "approval.db"
CONFIG_PATH = AIBRAIN_ROOT / "config.json"


def _get_activity_db():
    db = sqlite3.connect(str(ACTIVITY_DB_PATH))
    db.execute("PRAGMA journal_mode=wal")
    db.row_factory = sqlite3.Row
    db.execute("""
        CREATE TABLE IF NOT EXISTS activity (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            agent TEXT NOT NULL DEFAULT 'agent',
            action TEXT NOT NULL,
            category TEXT DEFAULT 'general',
            detail TEXT DEFAULT '',
            status TEXT DEFAULT 'ok'
        )
    """)
    db.commit()
    return db


def _log_activity(action: str, category: str, detail: str = "", status: str = "ok"):
    """Log an entry to activity.db."""
    db = _get_activity_db()
    db.execute(
        "INSERT INTO activity (timestamp, agent, action, category, detail, status) VALUES (?, ?, ?, ?, ?, ?)",
        (datetime.now().isoformat(), os.getenv("AGENT_ID", "agent"), action, category, detail, status),
    )
    db.commit()
    db.close()


def _update_approval_note(item_id: int, note: str):
    """Append execution result to the approval's decision_note."""
    db = sqlite3.connect(str(APPROVAL_DB_PATH))
    db.execute("PRAGMA journal_mode=wal")
    row = db.execute("SELECT decision_note FROM approval_queue WHERE id = ?", (item_id,)).fetchone()
    existing = row[0] if row and row[0] else ""
    updated = f"{existing}\n[exec] {note}".strip()
    db.execute(
        "UPDATE approval_queue SET decision_note = ?, updated = ? WHERE id = ?",
        (updated, datetime.now().isoformat(), item_id),
    )
    db.commit()
    db.close()


def _load_config() -> dict:
    if CONFIG_PATH.exists():
        try:
            return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            pass
    return {}


def _send_email(to: str, subject: str, body: str) -> str:
    """Send email via SMTP using config.json credentials."""
    cfg = _load_config()
    smtp_host = cfg.get("smtp_host", "smtp.gmail.com")
    smtp_port = int(cfg.get("smtp_port", 587))
    smtp_user = cfg.get("smtp_user") or cfg.get("email_from")
    smtp_pass = cfg.get("smtp_pass") or cfg.get("email_password")

    if not smtp_user or not smtp_pass:
        return "SMTP credentials not configured in config.json (need smtp_user + smtp_pass)"

    msg = MIMEText(body, "plain")
    msg["Subject"] = subject
    msg["From"] = smtp_user
    msg["To"] = to

    server = smtplib.SMTP(smtp_host, smtp_port)
    server.starttls()
    server.login(smtp_user, smtp_pass)
    server.sendmail(smtp_user, [to], msg.as_string())
    server.quit()
    return "sent"


# ---------------------------------------------------------------------------
# Category handlers
# ---------------------------------------------------------------------------

def _handle_trade(item: dict, payload: dict) -> str:
    """Trades are logged only — no auto-trading without Alpaca integration."""
    detail = payload.get("summary", payload.get("symbol", json.dumps(payload)[:200]))
    _log_activity(
        action=f"trade approved: {item['title']}",
        category="trade",
        detail=detail,
    )
    return f"Trade logged (no auto-execution): {detail}"


def _handle_email(item: dict, payload: dict) -> str:
    """Send email if payload has to/subject/body."""
    to = payload.get("to")
    subject = payload.get("subject", "")
    body = payload.get("body", "")

    if not to:
        return "Email payload missing 'to' field — skipped"

    result = _send_email(to, subject, body)
    _log_activity(
        action=f"email sent: {subject}",
        category="email",
        detail=f"to={to}, result={result}",
        status="ok" if result == "sent" else "error",
    )
    return f"Email to {to}: {result}"


def _handle_social(item: dict, payload: dict) -> str:
    """Log the social post and create a follow-up approval for actual publishing."""
    from approval_queue import add_item as aq_add

    platform = payload.get("platform", "unknown")
    content_preview = payload.get("content", item["title"])[:100]

    _log_activity(
        action=f"social approved: {platform}",
        category="social",
        detail=content_preview,
    )

    # Create a follow-up approval for the actual post
    aq_add(
        APPROVAL_DB_PATH,
        category="social",
        title=f"PUBLISH to {platform}: {content_preview[:60]}",
        detail=f"Auto-created after approval of item #{item['id']}. Ready to publish.",
        payload={"action": "publish", "original_id": item["id"], **payload},
    )
    return f"Social post logged. Follow-up approval created for publishing to {platform}."


def _handle_deploy(item: dict, payload: dict) -> str:
    """Run a deploy command via subprocess."""
    command = payload.get("command", "")
    if not command:
        return "Deploy payload missing 'command' field — skipped"

    # Safety: only allow commands starting with known prefixes
    allowed_prefixes = ("docker", "git", "python", "npm", "pip")
    cmd_lower = command.strip().lower()
    if not any(cmd_lower.startswith(p) for p in allowed_prefixes):
        msg = f"Blocked: command '{command[:50]}' not in allowed prefixes {allowed_prefixes}"
        _log_activity(action="deploy blocked", category="deploy", detail=msg, status="error")
        return msg

    # Block shell metacharacters that could allow command injection
    dangerous_chars = {";", "&", "|", "`", "$", "(", ")", "{", "}", "<", ">", "\n", "\r"}
    if any(c in command for c in dangerous_chars):
        msg = f"Blocked: command contains shell metacharacters"
        _log_activity(action="deploy blocked", category="deploy", detail=msg, status="error")
        return msg

    # Parse into args list — no shell=True
    try:
        cmd_args = shlex.split(command)
    except ValueError as e:
        return f"Deploy blocked: malformed command ({e})"

    # Block python -c/-m and other flags that allow arbitrary code execution
    if cmd_args[0] in ('python', 'python3') and len(cmd_args) > 1 and cmd_args[1].startswith('-'):
        return f"Blocked: python flags not allowed in deploy commands. Only script execution permitted."

    try:
        cwd = str(payload.get("cwd", AIBRAIN_ROOT))
        # Validate cwd is under AIBRAIN_ROOT to prevent directory traversal
        cwd_resolved = Path(cwd).resolve()
        if not str(cwd_resolved).startswith(str(AIBRAIN_ROOT.resolve())):
            return f"Deploy blocked: cwd must be under AIBrain root"

        result = subprocess.run(
            cmd_args, shell=False,
            capture_output=True, text=True, timeout=60,
            cwd=cwd,
        )
        detail = f"exit={result.returncode} stdout={result.stdout[-500:]}" if result.stdout else f"exit={result.returncode}"
        _log_activity(
            action=f"deploy: {command[:80]}",
            category="deploy",
            detail=detail,
            status="ok" if result.returncode == 0 else "error",
        )
        if result.returncode != 0 and result.stderr:
            return f"Deploy failed (exit {result.returncode}): {result.stderr[-300:]}"
        return f"Deploy completed (exit {result.returncode})"
    except subprocess.TimeoutExpired:
        _log_activity(action=f"deploy timeout: {command[:80]}", category="deploy", status="error")
        return "Deploy timed out (60s limit)"
    except Exception as e:
        _log_activity(action=f"deploy error: {command[:80]}", category="deploy", detail=str(e), status="error")
        return f"Deploy error: {e}"


def _handle_workflow(item: dict, payload: dict) -> str:
    """Run a workflow script via subprocess."""
    script_name = payload.get("script", payload.get("workflow", ""))
    if not script_name:
        return "Workflow payload missing 'script' field — skipped"

    # Resolve script path
    script_path = (AIBRAIN_ROOT / "workflows" / script_name).resolve()
    if not str(script_path).startswith(str((AIBRAIN_ROOT / "workflows").resolve())):
        return "Blocked: path traversal detected in workflow name"

    if not script_path.suffix:
        script_path = script_path.with_suffix(".py")

    if not script_path.exists():
        msg = f"Workflow script not found: {script_path}"
        _log_activity(action="workflow missing", category="workflow", detail=msg, status="error")
        return msg

    args = [str(a) for a in payload.get("args", []) if isinstance(a, (str, int, float))]
    cmd = [sys.executable, str(script_path)] + args

    try:
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=120,
            cwd=str(AIBRAIN_ROOT),
        )
        detail = f"exit={result.returncode}"
        if result.stdout:
            detail += f" stdout={result.stdout[-500:]}"
        _log_activity(
            action=f"workflow: {script_name}",
            category="workflow",
            detail=detail,
            status="ok" if result.returncode == 0 else "error",
        )
        if result.returncode != 0 and result.stderr:
            return f"Workflow failed (exit {result.returncode}): {result.stderr[-300:]}"
        return f"Workflow completed (exit {result.returncode})"
    except subprocess.TimeoutExpired:
        _log_activity(action=f"workflow timeout: {script_name}", category="workflow", status="error")
        return "Workflow timed out (120s limit)"
    except Exception as e:
        _log_activity(action=f"workflow error: {script_name}", category="workflow", detail=str(e), status="error")
        return f"Workflow error: {e}"


def _handle_general(item: dict, payload: dict) -> str:
    """General category — just log to activity."""
    _log_activity(
        action=f"approved: {item['title']}",
        category="general",
        detail=json.dumps(payload)[:300] if payload else "",
    )
    return "Logged to activity."


# ---------------------------------------------------------------------------
# Main dispatch
# ---------------------------------------------------------------------------

def _handle_content(item: dict, payload: dict) -> str:
    """Mark content pipeline item as published when approved."""
    content_id = payload.get("content_id")
    if not content_id:
        return "Content payload missing 'content_id' — skipped"

    content_db_path = AIBRAIN_ROOT / "content.db"
    if not content_db_path.exists():
        return f"Content DB not found — skipped"

    db = sqlite3.connect(str(content_db_path))
    now = datetime.now().isoformat()
    db.execute(
        "UPDATE content SET status = 'published', published_at = ?, updated_at = ? WHERE id = ?",
        (now, now, content_id),
    )
    db.commit()
    db.close()

    platforms = payload.get("platforms", [])
    _log_activity(
        action=f"content published: #{content_id}",
        category="content",
        detail=f"Published to {', '.join(platforms) if platforms else 'queue'}",
    )
    return f"Content #{content_id} marked as published"


def _handle_file_management(item: dict, payload: dict) -> str:
    """Move/rename files as proposed by the smart file organizer."""
    action = payload.get("action", "move")
    source = payload.get("source_path", "")
    dest = payload.get("dest_path", "")

    if not source or not dest:
        return "File management payload missing source_path or dest_path"

    source_path = Path(source)
    dest_path = Path(dest)

    if not source_path.exists():
        return f"Source file not found: {source}"

    # Safety: only allow moves within user home
    home = Path.home().resolve()
    if not str(source_path.resolve()).startswith(str(home)):
        return f"Blocked: source must be under user home ({home})"
    if not str(dest_path.resolve()).startswith(str(home)):
        return f"Blocked: destination must be under user home ({home})"

    if action == "move":
        dest_path.parent.mkdir(parents=True, exist_ok=True)
        import shutil
        shutil.move(str(source_path), str(dest_path))
        _log_activity(
            action=f"file moved: {source_path.name}",
            category="file_management",
            detail=f"{source} → {dest}",
        )
        return f"Moved: {source_path.name} → {dest_path}"
    elif action == "rename":
        source_path.rename(dest_path)
        _log_activity(
            action=f"file renamed: {source_path.name}",
            category="file_management",
            detail=f"{source} → {dest_path.name}",
        )
        return f"Renamed: {source_path.name} → {dest_path.name}"
    else:
        return f"Unknown file action: {action}"


_HANDLERS = {
    "trade": _handle_trade,
    "email": _handle_email,
    "social": _handle_social,
    "content": _handle_content,
    "deploy": _handle_deploy,
    "workflow": _handle_workflow,
    "file_management": _handle_file_management,
    "job": _handle_general,
    "job_application": _handle_general,
    "general": _handle_general,
}


def execute_approved_action(item: dict) -> str:
    """
    Execute the action for an approved item.
    `item` is a dict from approval_queue (must have id, category, title, payload).
    Returns a result message string.
    """
    item_id = item["id"]
    category = item.get("category", "general")
    title = item.get("title", "")

    # Parse payload
    payload_raw = item.get("payload", "{}")
    if isinstance(payload_raw, str):
        try:
            payload = json.loads(payload_raw)
        except json.JSONDecodeError:
            payload = {}
    else:
        payload = payload_raw or {}

    handler = _HANDLERS.get(category, _handle_general)

    try:
        result = handler(item, payload)
        _update_approval_note(item_id, result)
        return result
    except Exception as e:
        error_msg = f"Execution failed: {e}"
        _log_activity(
            action=f"exec error: {title[:80]}",
            category=category,
            detail=error_msg,
            status="error",
        )
        _update_approval_note(item_id, error_msg)
        return error_msg
