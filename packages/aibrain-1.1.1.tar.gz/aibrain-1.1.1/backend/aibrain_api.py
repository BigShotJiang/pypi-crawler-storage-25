"""
AIBrain API — FastAPI router for the portable AI brain.
Memory DB, cron registry, skills browser, agent status, workflow groups.
"""

import json
import logging
import os
import re
import sqlite3
import sys
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

from fastapi import APIRouter, Query
from fastapi.responses import JSONResponse

# Import consolidated DB — single source of truth
sys.path.insert(0, str(Path(__file__).parent.parent))
sys.path.insert(0, str(Path(__file__).parent))
import aibrain_db
import evolution_engine
import permissions
import trace_logger

# Notification callback — set by main.py to broadcast real-time events
_notify_callback = None

def set_notify_callback(fn):
    global _notify_callback
    _notify_callback = fn

# ---------------------------------------------------------------------------
# Paths — configurable via env vars, config file, or sensible defaults
# ---------------------------------------------------------------------------

AIBRAIN_ROOT = Path(os.environ.get("AIBRAIN_ROOT", Path(__file__).parent.parent))
_config_file = AIBRAIN_ROOT / "config.json"

def _load_config():
    """Load paths from config.json if it exists, else use defaults."""
    defaults = {
        "memory_db": str(AIBRAIN_ROOT / "memory" / "memory.db"),
        "cron_jobs": str(AIBRAIN_ROOT / "scheduled_jobs.json"),
        "skills_dir": str(Path.home() / ".claude" / "skills"),
        "skills_agents_dir": str(Path.home() / ".agents" / "skills"),
        "subagents_dir": str(AIBRAIN_ROOT / "subagents"),
        "last_evolution": str(AIBRAIN_ROOT / ".tmp" / "last_evolution.txt"),
        "inbox": str(AIBRAIN_ROOT / ".tmp" / "inbox.jsonl"),
    }
    if _config_file.exists():
        try:
            overrides = json.loads(_config_file.read_text(encoding="utf-8"))
            defaults.update({k: v for k, v in overrides.items() if v})
        except (json.JSONDecodeError, OSError):
            pass
    # Env vars override everything (AIBRAIN_MEMORY_DB, AIBRAIN_CRON_JOBS, etc.)
    for key in defaults:
        env_key = f"AIBRAIN_{key.upper()}"
        if os.environ.get(env_key):
            defaults[key] = os.environ[env_key]
    return defaults

_cfg = _load_config()

MEMORY_DB_PATH = Path(_cfg["memory_db"])
CRON_JOBS_PATH = Path(_cfg["cron_jobs"])
SKILLS_DIR = Path(_cfg["skills_dir"])
SKILLS_AGENTS_DIR = Path(_cfg["skills_agents_dir"])
SUBAGENTS_DIR = Path(_cfg["subagents_dir"])
LAST_EVOLUTION = Path(_cfg["last_evolution"])
AGENT_INBOX = Path(_cfg["inbox"])

router = APIRouter(prefix="/api/agent", tags=["AIBrain"])

# Skill search paths
_SKILLS_PATHS = [SKILLS_DIR, SKILLS_AGENTS_DIR]

# ---------------------------------------------------------------------------
# Mobile Pairing — QR code based device pairing (like WhatsApp Web)
# ---------------------------------------------------------------------------

PAIRING_DB_PATH = AIBRAIN_ROOT / "pairing.db"


def get_pairing_db():
    db = sqlite3.connect(str(PAIRING_DB_PATH))
    db.execute("PRAGMA journal_mode=wal")
    db.row_factory = sqlite3.Row
    db.execute("""
        CREATE TABLE IF NOT EXISTS pairings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            token TEXT UNIQUE NOT NULL,
            created_at TEXT NOT NULL,
            expires_at TEXT NOT NULL,
            confirmed INTEGER DEFAULT 0,
            device_info TEXT DEFAULT '',
            session_token TEXT DEFAULT '',
            last_seen TEXT DEFAULT ''
        )
    """)
    db.commit()
    return db


@router.post("/pair/generate")
async def pair_generate():
    """Generate a pairing token for QR code display on desktop."""
    import secrets as _secrets
    token = _secrets.token_urlsafe(32)
    now = datetime.now()
    expires = now + timedelta(minutes=5)

    db = get_pairing_db()
    # Clean up expired tokens
    db.execute("DELETE FROM pairings WHERE expires_at < ?", (now.isoformat(),))
    db.execute(
        "INSERT INTO pairings (token, created_at, expires_at) VALUES (?, ?, ?)",
        (token, now.isoformat(), expires.isoformat()),
    )
    db.commit()
    db.close()

    return {"token": token, "expires_at": expires.isoformat()}


@router.post("/pair/confirm")
async def pair_confirm(body: dict):
    """Mobile sends scanned token to confirm pairing."""
    import secrets as _secrets
    token = body.get("token")
    device_info = body.get("device_info", "Unknown device")

    if not token:
        return JSONResponse({"error": "token required"}, status_code=400)

    db = get_pairing_db()
    now = datetime.now()

    import hmac
    # Fetch all unexpired unconfirmed pairings and compare with constant-time check
    rows = db.execute(
        "SELECT * FROM pairings WHERE expires_at > ? AND confirmed = 0",
        (now.isoformat(),),
    ).fetchall()
    row = None
    for r in rows:
        if hmac.compare_digest(r["token"], token):
            row = r
            break

    if not row:
        db.close()
        return JSONResponse({"error": "Invalid or expired token"}, status_code=404)

    session_token = _secrets.token_urlsafe(32)
    db.execute(
        "UPDATE pairings SET confirmed = 1, device_info = ?, session_token = ?, last_seen = ? WHERE token = ?",
        (device_info, session_token, now.isoformat(), token),
    )
    db.commit()
    db.close()

    return {"status": "paired", "session_token": session_token, "device_info": device_info}


@router.get("/pair/status")
async def pair_status(token: str = Query(None)):
    """Check if a pairing token has been confirmed. Desktop polls this."""
    if not token:
        # Return all active pairings
        db = get_pairing_db()
        rows = db.execute(
            "SELECT token, confirmed, device_info, last_seen, created_at FROM pairings WHERE confirmed = 1 ORDER BY last_seen DESC"
        ).fetchall()
        db.close()
        return {"paired_devices": [dict(r) for r in rows], "count": len(rows)}

    db = get_pairing_db()
    now = datetime.now()
    row = db.execute(
        "SELECT confirmed, device_info, session_token FROM pairings WHERE token = ? AND expires_at > ?",
        (token, now.isoformat()),
    ).fetchone()
    db.close()

    if not row:
        return {"status": "expired"}

    if row["confirmed"]:
        return {"status": "paired", "device_info": row["device_info"], "session_token": row["session_token"]}

    return {"status": "waiting"}


@router.delete("/pair/{token}")
async def pair_revoke(token: str):
    """Revoke a pairing / disconnect a device."""
    db = get_pairing_db()
    db.execute("DELETE FROM pairings WHERE token = ? OR session_token = ?", (token, token))
    db.commit()
    db.close()
    return {"status": "revoked"}

# ---------------------------------------------------------------------------
# Memory DB helpers — now backed by consolidated aibrain_db
# ---------------------------------------------------------------------------

def get_db():
    """Return a NEW connection to the consolidated DB (caller-managed lifecycle).
    Endpoints that call db.close() need their own connection — not the singleton.
    """
    import sqlite3 as _sql
    db = _sql.connect(str(aibrain_db.DB_PATH))
    db.row_factory = _sql.Row
    db.execute("PRAGMA journal_mode=WAL")
    return db


# ---------------------------------------------------------------------------
# Memory endpoints
# ---------------------------------------------------------------------------

@router.get("/memories")
async def list_memories(
    type: Optional[str] = Query(None),
    tag: Optional[str] = Query(None),
    sort: Optional[str] = Query("updated"),
    order: Optional[str] = Query("desc"),
    page: int = Query(1),
    per_page: int = Query(50),
):
    db = get_db()
    query = "SELECT id, name, type, tags, substr(content, 1, 200) as preview, created, updated FROM memories WHERE active = 1"
    count_query = "SELECT COUNT(*) as total FROM memories WHERE active = 1"
    params = []
    count_params = []
    if type:
        query += " AND type = ?"
        count_query += " AND type = ?"
        params.append(type)
        count_params.append(type)
    if tag:
        query += " AND tags LIKE ?"
        count_query += " AND tags LIKE ?"
        params.append(f"%{tag}%")
        count_params.append(f"%{tag}%")

    # Validate sort column
    allowed_sorts = {"name", "type", "created", "updated", "id"}
    sort_col = sort if sort in allowed_sorts else "updated"
    sort_dir = "ASC" if order.lower() == "asc" else "DESC"
    query += f" ORDER BY {sort_col} {sort_dir}"

    # Pagination
    total = db.execute(count_query, count_params).fetchone()["total"]
    offset = (max(1, page) - 1) * per_page
    query += " LIMIT ? OFFSET ?"
    params.extend([per_page, offset])

    rows = db.execute(query, params).fetchall()
    db.close()
    return {
        "count": len(rows),
        "total": total,
        "page": page,
        "per_page": per_page,
        "pages": (total + per_page - 1) // per_page,
        "memories": [dict(r) for r in rows],
    }


@router.get("/memories/search")
async def search_memories(q: str = Query(...), limit: int = Query(20)):
    from security import safe_limit
    limit = safe_limit(limit, 200)

    # ENHANCED PATH: hybrid search (FTS5 + semantic embeddings + RRF fusion)
    # Falls back to DIRECT PATH (FTS5 only) if hybrid search unavailable
    try:
        sys.path.insert(0, str(Path(__file__).parent.parent))
        from mcp_server import _search as hybrid_search
        results = hybrid_search(q, limit=limit)
        return {
            "query": q, "count": len(results),
            "search_mode": "hybrid",
            "results": [
                {k: v for k, v in r.items() if k not in ("embedding",)}
                for r in results
            ],
        }
    except Exception as e:
        logger.info("Hybrid search unavailable, falling back to FTS5: %s", e)

    # DIRECT PATH: basic FTS5 keyword search (always works)
    db = get_db()
    safe_q = aibrain_db._sanitize_fts5(q)
    try:
        rows = db.execute("""
            SELECT m.id, m.name, m.type, m.tags, m.content, m.created, m.updated, rank
            FROM memories_fts fts
            JOIN memories m ON m.id = fts.rowid
            WHERE memories_fts MATCH ? AND m.active = 1
            ORDER BY rank
            LIMIT ?
        """, (safe_q, limit)).fetchall()
    except sqlite3.OperationalError:
        rows = []
    db.close()
    return {"query": q, "count": len(rows), "search_mode": "fts5", "results": [dict(r) for r in rows]}


@router.get("/search")
async def unified_search(q: str = Query(...), limit: int = Query(10)):
    """Search across memories, workflows, and skills in one call."""
    results = {"query": q, "memories": [], "workflows": [], "skills": []}
    ql = q.lower()

    # 1) Memory search — try hybrid first, fall back to FTS5
    try:
        sys.path.insert(0, str(Path(__file__).parent.parent))
        from mcp_server import _search as hybrid_search
        hybrid_results = hybrid_search(q, limit=limit)
        results["memories"] = [
            {"id": r["id"], "name": r["name"], "type": r.get("type", ""),
             "tags": r.get("tags", ""), "preview": (r.get("content") or "")[:150]}
            for r in hybrid_results
        ]
        results["search_mode"] = "hybrid"
    except Exception:
        db = get_db()
        safe_q = aibrain_db._sanitize_fts5(q)
        try:
            mem_rows = db.execute("""
                SELECT m.id, m.name, m.type, m.tags, substr(m.content, 1, 150) as preview, rank
                FROM memories_fts fts
                JOIN memories m ON m.id = fts.rowid
                WHERE memories_fts MATCH ? AND m.active = 1
                ORDER BY rank LIMIT ?
            """, (safe_q, limit)).fetchall()
            results["memories"] = [dict(r) for r in mem_rows]
        except sqlite3.OperationalError:
            pass
        db.close()
        results["search_mode"] = "fts5"

    # 2) Workflow search from consolidated DB
    try:
        for job in aibrain_db.list_scheduled_jobs():
            name = (job.get("name") or "").lower()
            desc = (job.get("notes") or "").lower()
            prompt = (job.get("prompt") or "").lower()
            if ql in name or ql in desc or ql in prompt:
                results["workflows"].append({
                    "name": job.get("name"),
                    "display_name": job.get("name", "").replace("_", " ").title(),
                    "cron": job.get("cron"),
                    "description": job.get("notes"),
                })
                if len(results["workflows"]) >= limit:
                    break
    except (sqlite3.OperationalError, KeyError, TypeError) as e:
        logger.warning("Workflow search failed: %s", e)

    # 3) Skill search (name, description)
    for p in _SKILLS_PATHS:
        if not p.exists():
            continue
        for f in sorted(p.iterdir()):
            if not f.suffix == ".md":
                continue
            name = f.stem.replace("_", " ").replace("-", " ").lower()
            if ql in name:
                results["skills"].append({"name": f.stem, "path": str(f)})
                if len(results["skills"]) >= limit:
                    break

    results["total"] = len(results["memories"]) + len(results["workflows"]) + len(results["skills"])
    return results


@router.get("/memories/summary")
async def memory_summary():
    db = get_db()
    counts = db.execute(
        "SELECT type, COUNT(*) as cnt FROM memories WHERE active = 1 GROUP BY type ORDER BY type"
    ).fetchall()
    total = sum(r["cnt"] for r in counts)
    recent = db.execute(
        "SELECT id, name, type, tags, substr(content, 1, 120) as preview, updated FROM memories WHERE active = 1 ORDER BY updated DESC LIMIT 10"
    ).fetchall()
    db.close()
    return {
        "total": total,
        "by_type": {r["type"]: r["cnt"] for r in counts},
        "recent": [dict(r) for r in recent],
    }


@router.get("/memories/graph")
async def memory_graph():
    """Return nodes + edges for graph visualization with auto-extracted relationships."""
    db = get_db()
    rows = db.execute(
        "SELECT id, name, type, tags, content FROM memories WHERE active = 1"
    ).fetchall()
    db.close()

    nodes = []
    edge_set: set[tuple[int, int, str]] = set()  # (source, target, label) deduped
    name_to_id = {}
    id_to_tags: dict[int, set[str]] = {}
    id_to_keywords: dict[int, set[str]] = {}

    # Stopwords for keyword extraction
    stopwords = {
        "the", "a", "an", "is", "are", "was", "were", "be", "been", "being",
        "have", "has", "had", "do", "does", "did", "will", "would", "could",
        "should", "may", "might", "shall", "can", "to", "of", "in", "for",
        "on", "with", "at", "by", "from", "as", "into", "through", "during",
        "before", "after", "above", "below", "between", "out", "off", "over",
        "under", "again", "further", "then", "once", "here", "there", "when",
        "where", "why", "how", "all", "each", "every", "both", "few", "more",
        "most", "other", "some", "such", "no", "nor", "not", "only", "own",
        "same", "so", "than", "too", "very", "just", "because", "but", "and",
        "or", "if", "while", "about", "up", "it", "its", "this", "that",
        "these", "those", "i", "me", "my", "we", "our", "you", "your", "he",
        "him", "his", "she", "her", "they", "them", "their", "what", "which",
        "who", "whom", "use", "used", "using", "also", "get", "set", "new",
    }

    def extract_keywords(text: str) -> set[str]:
        words = re.findall(r"[a-z][a-z0-9_-]{2,}", text.lower())
        return {w for w in words if w not in stopwords and len(w) > 2}

    for r in rows:
        tags_raw = r["tags"] or ""
        tag_set = {t.strip().lower() for t in tags_raw.split(",") if t.strip()}
        id_to_tags[r["id"]] = tag_set
        content = (r["content"] or "") + " " + (r["name"] or "")
        id_to_keywords[r["id"]] = extract_keywords(content)
        nodes.append({"id": r["id"], "name": r["name"], "type": r["type"], "tags": r["tags"]})
        name_to_id[r["name"].lower()] = r["id"]

    valid_ids = {n["id"] for n in nodes}

    def add_edge(src: int, tgt: int, label: str):
        if src != tgt and src in valid_ids and tgt in valid_ids:
            key = (min(src, tgt), max(src, tgt), label)
            edge_set.add(key)

    # 1) Explicit references: #ID and name mentions in content
    for r in rows:
        content = r["content"] or ""
        ref_ids = set(int(m) for m in re.findall(r"#(\d+)", content))
        for tid in ref_ids:
            add_edge(r["id"], tid, "references")
        for name, mid in name_to_id.items():
            if mid != r["id"] and len(name) > 3 and name in content.lower():
                add_edge(r["id"], mid, "mentions")

    # 2) Shared tags — memories with overlapping tags are related
    ids = [r["id"] for r in rows]
    for i in range(len(ids)):
        for j in range(i + 1, len(ids)):
            shared = id_to_tags[ids[i]] & id_to_tags[ids[j]]
            if shared:
                add_edge(ids[i], ids[j], f"tag:{next(iter(shared))}")

    # 3) Keyword overlap — memories sharing significant keywords
    for i in range(len(ids)):
        for j in range(i + 1, len(ids)):
            kw_i = id_to_keywords[ids[i]]
            kw_j = id_to_keywords[ids[j]]
            if not kw_i or not kw_j:
                continue
            overlap = kw_i & kw_j
            # Jaccard similarity — need meaningful overlap
            union = kw_i | kw_j
            similarity = len(overlap) / len(union) if union else 0
            if similarity > 0.15 and len(overlap) >= 3:
                top_word = max(overlap, key=len)
                add_edge(ids[i], ids[j], f"topic:{top_word}")

    # 4) Entity-based connections — memories sharing extracted entities
    try:
        from entity_extractor import get_entity_graph, init_entity_tables
        init_entity_tables(aibrain_db.DB_PATH)
        eg = get_entity_graph(aibrain_db.DB_PATH)
        for link in eg.get("entity_links", []):
            ent = next((e for e in eg["entities"] if e["id"] == link["entity_id"]), None)
            label = f"entity:{ent['name']}" if ent else "entity"
            add_edge(link["memory_1"], link["memory_2"], label)
    except (ImportError, sqlite3.OperationalError, KeyError) as e:
        logger.warning("Entity graph edge loading failed: %s", e)

    edges = [{"source": s, "target": t, "label": l} for s, t, l in edge_set]

    # Include entity nodes for enriched graph view
    entity_nodes = []
    try:
        from entity_extractor import get_entity_graph, init_entity_tables
        init_entity_tables(aibrain_db.DB_PATH)
        eg = get_entity_graph(aibrain_db.DB_PATH)
        entity_nodes = eg.get("entities", [])
    except (ImportError, sqlite3.OperationalError, KeyError) as e:
        logger.warning("Entity node loading failed: %s", e)

    return {"nodes": nodes, "edges": edges, "entities": entity_nodes}


@router.post("/memories/extract-entities")
async def extract_all_entities():
    """Backfill entity extraction on all existing memories."""
    try:
        from entity_extractor import init_entity_tables, index_memory_entities
        init_entity_tables(aibrain_db.DB_PATH)
    except ImportError:
        return JSONResponse({"error": "Entity extractor not available"}, status_code=500)

    db = get_db()
    rows = db.execute("SELECT id, name, content FROM memories WHERE active = 1").fetchall()
    db.close()

    total_entities = 0
    for r in rows:
        entities = index_memory_entities(aibrain_db.DB_PATH, r["id"], r["content"] or "", r["name"] or "")
        total_entities += len(entities)

    return {"memories_processed": len(rows), "entities_extracted": total_entities}


# ---------------------------------------------------------------------------
# Memory Import/Export — portable agent brain transfer
# ---------------------------------------------------------------------------

@router.get("/memories/export")
async def export_memories():
    """Export all active memories as portable JSON. The full agent brain in one file."""
    db = get_db()
    rows = db.execute(
        "SELECT id, name, type, tags, content, created, updated FROM memories WHERE active = 1 ORDER BY id"
    ).fetchall()
    db.close()

    crons = aibrain_db.list_scheduled_jobs()

    return {
        "format": "aibrain-brain-v1",
        "exported_at": datetime.now().isoformat(),
        "memories": [dict(r) for r in rows],
        "crons": crons,
        "stats": {
            "memory_count": len(rows),
            "cron_count": len(crons),
        }
    }


@router.post("/memories/import")
async def import_memories(body: dict):
    """Import memories from an AIBrain brain export or other formats."""
    memories = body.get("memories", [])
    crons = body.get("crons", [])

    if not memories and not crons:
        return JSONResponse({"error": "No data to import"}, status_code=400)

    db = get_db()
    now = datetime.now().isoformat()
    imported = 0
    skipped = 0

    for mem in memories:
        name = mem.get("name", "")
        if not name:
            skipped += 1
            continue
        existing = db.execute(
            "SELECT id FROM memories WHERE name = ? AND active = 1", (name,)
        ).fetchone()
        if existing:
            skipped += 1
            continue
        db.execute(
            "INSERT INTO memories (name, type, tags, content, created, updated) VALUES (?, ?, ?, ?, ?, ?)",
            (name, mem.get("type", "reference"), mem.get("tags", ""),
             mem.get("content", ""), mem.get("created", now), now)
        )
        imported += 1

    db.commit()
    db.close()

    crons_imported = 0
    if crons:
        result = aibrain_db.import_memories_and_crons([], crons)
        crons_imported = result.get("crons_imported", 0)

    return {
        "status": "imported",
        "memories_imported": imported,
        "memories_skipped": skipped,
        "crons_imported": crons_imported,
    }


@router.get("/memories/{memory_id}")
async def get_memory(memory_id: int):
    db = get_db()
    row = db.execute("SELECT * FROM memories WHERE id = ? AND active = 1", (memory_id,)).fetchone()
    db.close()
    if not row:
        return JSONResponse({"error": "Not found"}, status_code=404)
    return dict(row)


@router.post("/memories")
async def create_memory(body: dict):
    name = body.get("name")
    mem_type = body.get("type", "reference")
    content = body.get("content", "")
    tags = body.get("tags", "")
    importance = body.get("importance", 0.5)
    if not name or not content:
        return JSONResponse({"error": "name and content required"}, status_code=400)
    if mem_type not in ("user", "feedback", "project", "reference", "pattern", "decision"):
        return JSONResponse({"error": f"Invalid type: {mem_type}"}, status_code=400)

    # ENHANCED PATH: MCP store (dedup + auto-embed + entity extraction)
    try:
        sys.path.insert(0, str(Path(__file__).parent.parent))
        from mcp_server import _store as enhanced_store
        result = enhanced_store(name, content, mem_type, tags, importance)
        mid = result["id"]
        # Entity extraction on new memories
        if result["action"] == "added":
            try:
                from entity_extractor import init_entity_tables, index_memory_entities
                init_entity_tables(aibrain_db.DB_PATH)
                index_memory_entities(aibrain_db.DB_PATH, mid, content, name)
            except Exception as e:
                logger.warning("Entity extraction failed for memory %s: %s", mid, e)
        return {"id": mid, "name": name, "type": mem_type,
                "action": result["action"], "store_mode": "enhanced"}
    except Exception as e:
        logger.info("Enhanced store unavailable, falling back to direct: %s", e)

    # DIRECT PATH: basic insert (always works)
    db = get_db()
    now = datetime.now().isoformat()
    cursor = db.execute(
        "INSERT INTO memories (name, type, tags, content, created, updated) VALUES (?, ?, ?, ?, ?, ?)",
        (name, mem_type, tags, content, now, now)
    )
    db.commit()
    mid = cursor.lastrowid
    db.close()

    try:
        from entity_extractor import init_entity_tables, index_memory_entities
        init_entity_tables(aibrain_db.DB_PATH)
        index_memory_entities(aibrain_db.DB_PATH, mid, content, name)
    except Exception as e:
        logger.warning("Entity extraction failed for memory %s: %s", mid, e)

    return {"id": mid, "name": name, "type": mem_type, "store_mode": "direct"}


@router.put("/memories/{memory_id}")
async def update_memory(memory_id: int, body: dict):
    db = get_db()
    existing = db.execute("SELECT id FROM memories WHERE id = ? AND active = 1", (memory_id,)).fetchone()
    if not existing:
        db.close()
        return JSONResponse({"error": "Not found"}, status_code=404)

    updates = []
    params = []
    for field in ("name", "content", "tags", "type"):
        if field in body:
            updates.append(f"{field} = ?")
            params.append(body[field])
    updates.append("updated = ?")
    params.append(datetime.now().isoformat())
    params.append(memory_id)

    db.execute(f"UPDATE memories SET {', '.join(updates)} WHERE id = ?", params)  # noqa:SQL F-STRING — updates is from frozenset whitelist above
    db.commit()
    db.close()

    # Re-index entities on update
    if "content" in body or "name" in body:
        try:
            from entity_extractor import init_entity_tables, index_memory_entities
            init_entity_tables(aibrain_db.DB_PATH)
            content = body.get("content", "")
            name = body.get("name", "")
            index_memory_entities(aibrain_db.DB_PATH, memory_id, content, name)
        except (ImportError, sqlite3.OperationalError) as e:
            logger.warning("Entity re-indexing failed for memory %s: %s", memory_id, e)

    return {"id": memory_id, "status": "updated"}


@router.delete("/memories/{memory_id}")
async def delete_memory(memory_id: int):
    db = get_db()
    db.execute(
        "UPDATE memories SET active = 0, updated = ? WHERE id = ?",
        (datetime.now().isoformat(), memory_id)
    )
    db.commit()
    db.close()
    return {"id": memory_id, "status": "deactivated"}


# ---------------------------------------------------------------------------
# Cron / Scheduled Jobs
# ---------------------------------------------------------------------------

@router.get("/crons")
async def list_crons():
    jobs = aibrain_db.list_scheduled_jobs()
    return {"jobs": jobs}


@router.post("/crons")
async def create_cron(body: dict):
    """Create a new scheduled job."""
    name = body.get("name")
    cron_expr = body.get("cron")
    if not name or not cron_expr:
        return JSONResponse({"error": "name and cron required"}, status_code=400)

    if aibrain_db.get_scheduled_job(name):
        return JSONResponse({"error": f"Job '{name}' already exists"}, status_code=409)

    aibrain_db.create_scheduled_job(
        name=name, cron=cron_expr,
        prompt=body.get("prompt", ""),
        enabled=body.get("enabled", True),
        notes=body.get("notes", ""),
        group=body.get("group", "general"),
    )
    return {"name": name, "status": "created"}


@router.put("/crons/{job_name}")
async def update_cron(job_name: str, body: dict):
    if not aibrain_db.get_scheduled_job(job_name):
        return JSONResponse({"error": f"Job '{job_name}' not found"}, status_code=404)

    aibrain_db.update_scheduled_job(job_name, **{
        k: v for k, v in body.items() if k in ("enabled", "cron", "prompt", "notes", "job_group")
    })
    return {"name": job_name, "status": "updated"}


WORKFLOWS_REGISTRY = AIBRAIN_ROOT / "workflows" / "registry.json"  # Legacy path

# Category display info (was in registry.json, now static config)
_CATEGORY_COLORS = {
    "job_hunting": {"display": "Job Hunting", "color": "#10B981"},
    "social_media": {"display": "Social Media", "color": "#8B5CF6"},
    "trading": {"display": "Trading", "color": "#F59E0B"},
    "security": {"display": "Security", "color": "#EF4444"},
    "content": {"display": "Content", "color": "#3B82F6"},
    "research": {"display": "Research", "color": "#06B6D4"},
    "communication": {"display": "Communication", "color": "#EC4899"},
    "maintenance": {"display": "Maintenance", "color": "#64748B"},
    "automation": {"display": "Automation", "color": "#14B8A6"},
    "general": {"display": "General", "color": "#64748B"},
}


def _load_workflow_groups():
    """Load workflow groups from consolidated DB."""
    workflows = aibrain_db.list_workflows()
    groups = {}
    for wf in workflows:
        cat = wf.get("category", "general")
        if cat not in groups:
            cat_info = _CATEGORY_COLORS.get(cat, {"display": cat.title(), "color": "#64748B"})
            groups[cat] = {
                "name": cat_info["display"],
                "color": cat_info["color"],
                "jobs": [],
                "flow": [],
                "edges": [],
                "workflows": [],
            }

        groups[cat]["jobs"].append(wf["name"])
        groups[cat]["workflows"].append({
            "name": wf["name"],
            "display_name": wf.get("display_name", wf["name"]),
            "description": wf.get("description", ""),
            "cron_schedule": wf.get("cron_schedule", ""),
            "required_services": wf.get("required_services", []),
            "enabled_by_default": bool(wf.get("enabled", 0)),
            "config_keys": wf.get("config_keys", []),
        })
        flow = wf.get("flow", [])
        edges = wf.get("edges", [])
        wf_prefix = wf["name"]
        if isinstance(flow, list):
            # Prefix node IDs with workflow name to avoid collisions within a group
            for node in flow:
                node["id"] = f"{wf_prefix}_{node.get('id', '')}"
            groups[cat]["flow"].extend(flow)
        if isinstance(edges, list):
            for edge in edges:
                edge["from"] = f"{wf_prefix}_{edge.get('from', '')}"
                edge["to"] = f"{wf_prefix}_{edge.get('to', '')}"
            groups[cat]["edges"].extend(edges)

    return groups


@router.get("/crons/upcoming")
async def upcoming_crons():
    """Return next scheduled runs for all enabled jobs, sorted by next run time."""
    jobs = aibrain_db.list_scheduled_jobs(enabled_only=True)
    now = datetime.now()

    upcoming = []
    for job in jobs:
        cron_expr = job.get("cron", "")
        next_run = parse_next_cron_run(cron_expr, now)
        if next_run:
            upcoming.append({
                "name": job["name"],
                "cron": cron_expr,
                "group": job.get("job_group", "general"),
                "prompt": job.get("prompt", ""),
                "next_run": next_run.isoformat(),
                "in_minutes": int((next_run - now).total_seconds() / 60),
            })

    upcoming.sort(key=lambda x: x["next_run"])
    return {"upcoming": upcoming}


def parse_next_cron_run(expr: str, now: datetime) -> datetime | None:
    """Simple cron parser for common patterns. Returns next run datetime."""
    parts = expr.strip().split()
    if len(parts) != 5:
        return None

    minute, hour, dom, month, dow = parts

    try:
        # Handle */N patterns
        def parse_field(field, current, max_val):
            if field == '*':
                return list(range(max_val))
            if field.startswith('*/'):
                step = int(field[2:])
                return list(range(0, max_val, step))
            if ',' in field:
                return [int(x) for x in field.split(',')]
            if '-' in field:
                start, end = field.split('-')
                return list(range(int(start), int(end) + 1))
            return [int(field)]

        minutes = parse_field(minute, now.minute, 60)
        hours = parse_field(hour, now.hour, 24)
        dows = parse_field(dow, 0, 7)  # dow range is always 0-6 (cron: 0=Sun)

        # Check next 7 days
        for day_offset in range(8):
            check_date = now.replace(hour=0, minute=0, second=0, microsecond=0)
            check_date = check_date.replace(
                day=check_date.day + day_offset
            ) if day_offset == 0 else datetime(
                check_date.year, check_date.month, check_date.day + day_offset
            )

            try:
                # Cron: 0=Sun, 1=Mon... Python: 0=Mon, 1=Tue...
                cron_dow = (check_date.weekday() + 1) % 7
                if dow != '*' and cron_dow not in dows:
                    continue

                for h in sorted(hours):
                    for m in sorted(minutes):
                        candidate = check_date.replace(hour=h, minute=m, second=0, microsecond=0)
                        if candidate > now:
                            return candidate
            except (ValueError, OverflowError):
                continue

    except (ValueError, IndexError):
        return None

    return None


@router.get("/crons/groups")
async def cron_groups():
    return {"groups": _load_workflow_groups()}


@router.get("/workflows")
async def list_workflows_endpoint():
    """List all pre-built workflows with full metadata."""
    workflows = aibrain_db.list_workflows()
    return {
        "workflows": workflows,
        "categories": _CATEGORY_COLORS,
        "count": len(workflows),
    }


@router.get("/workflows/builder")
async def list_builder_workflows():
    """List all saved visual workflow graphs."""
    if not BUILDER_DIR.exists():
        return {"workflows": []}
    results = []
    for f in sorted(BUILDER_DIR.glob("*.json")):
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
            results.append({
                "id": f.stem,
                "name": data.get("name", f.stem),
                "node_count": len(data.get("nodes", [])),
                "edge_count": len(data.get("edges", [])),
                "updated": data.get("updated", ""),
            })
        except (json.JSONDecodeError, OSError) as e:
            logger.warning("Skipping corrupt workflow file %s: %s", f.name, e)
    return {"workflows": results}


@router.get("/workflows/builder/{workflow_id}")
async def get_builder_workflow(workflow_id: str):
    """Get a specific visual workflow graph."""
    path = BUILDER_DIR / f"{workflow_id}.json"
    if not path.exists():
        return JSONResponse({"error": "Not found"}, status_code=404)
    return json.loads(path.read_text(encoding="utf-8"))


@router.get("/workflows/runs")
async def list_workflow_runs(
    workflow_id: Optional[str] = Query(None),
    status: Optional[str] = Query(None),
    limit: int = Query(50, le=200),
):
    """Get workflow execution history."""
    db_path = str(AIBRAIN_ROOT / "aibrain.db")
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    query = "SELECT * FROM workflow_runs WHERE 1=1"
    params = []
    if workflow_id:
        query += " AND workflow_id=?"
        params.append(workflow_id)
    if status:
        query += " AND status=?"
        params.append(status)
    query += " ORDER BY started_at DESC LIMIT ?"
    params.append(limit)
    rows = conn.execute(query, params).fetchall()
    conn.close()
    return {"runs": [dict(r) for r in rows], "count": len(rows)}


@router.get("/workflows/runs/stats")
async def workflow_run_stats():
    """Get workflow execution statistics."""
    db_path = str(AIBRAIN_ROOT / "aibrain.db")
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    total = conn.execute("SELECT COUNT(*) as c FROM workflow_runs").fetchone()["c"]
    by_status = conn.execute(
        "SELECT status, COUNT(*) as c FROM workflow_runs GROUP BY status"
    ).fetchall()
    recent = conn.execute(
        "SELECT workflow_name, status, started_at, duration_s FROM workflow_runs ORDER BY started_at DESC LIMIT 10"
    ).fetchall()
    conn.close()
    return {
        "total_runs": total,
        "by_status": {r["status"]: r["c"] for r in by_status},
        "recent": [dict(r) for r in recent],
    }


@router.get("/workflows/{workflow_name}")
async def get_workflow_endpoint(workflow_name: str):
    """Get full details for a specific workflow."""
    wf = aibrain_db.get_workflow(workflow_name)
    if not wf:
        return JSONResponse({"error": f"Workflow '{workflow_name}' not found"}, status_code=404)
    return wf


@router.put("/workflows/{workflow_name}")
async def update_workflow_endpoint(workflow_name: str, body: dict):
    """Update a workflow's editable fields."""
    allowed = {k: v for k, v in body.items() if k in ("display_name", "description", "cron_schedule", "category", "prompt")}
    if not aibrain_db.update_workflow(workflow_name, **allowed):
        return JSONResponse({"error": f"Workflow '{workflow_name}' not found"}, status_code=404)
    return {"name": workflow_name, "status": "updated"}


@router.post("/workflows/{workflow_name}/enable")
async def enable_workflow_endpoint(workflow_name: str, body: dict = None):
    """Enable or disable a workflow. Body: {enabled: bool} (default true)."""
    body = body or {}
    should_enable = body.get("enabled", True)

    wf = aibrain_db.get_workflow(workflow_name)
    if not wf:
        return JSONResponse({"error": "Workflow not found"}, status_code=404)

    if should_enable:
        aibrain_db.enable_workflow(workflow_name)
        # Also create a corresponding scheduled job if not exists
        if not aibrain_db.get_scheduled_job(workflow_name):
            aibrain_db.create_scheduled_job(
                name=workflow_name,
                cron=wf.get("cron_schedule", "0 9 * * *"),
                prompt=f"Run {wf.get('display_name', workflow_name)} workflow: python workflows/{workflow_name}.py",
                enabled=True,
                notes=wf.get("description", ""),
                group=wf.get("category", "general"),
            )
    else:
        aibrain_db.disable_workflow(workflow_name)
        aibrain_db.delete_scheduled_job(workflow_name)

    return {"name": workflow_name, "status": "enabled" if should_enable else "disabled"}


@router.post("/workflows/{workflow_name}/disable")
async def disable_workflow_endpoint(workflow_name: str):
    """Disable a workflow."""
    aibrain_db.disable_workflow(workflow_name)
    aibrain_db.delete_scheduled_job(workflow_name)
    return {"name": workflow_name, "status": "disabled"}


@router.post("/workflows/{workflow_name}/run")
async def run_workflow(workflow_name: str):
    """Run a workflow script immediately with --dry-run."""
    import subprocess
    import time as _time

    script = (AIBRAIN_ROOT / "workflows" / f"{workflow_name}.py").resolve()
    if not str(script).startswith(str((AIBRAIN_ROOT / "workflows").resolve())):
        return JSONResponse({"error": "Invalid workflow name"}, status_code=403)
    if not script.exists():
        return JSONResponse({"error": f"Script not found: {workflow_name}.py"}, status_code=404)

    # Log run start
    run_id = None
    start_time = _time.time()
    run_conn = None
    try:
        db_path = str(AIBRAIN_ROOT / "aibrain.db")
        run_conn = sqlite3.connect(db_path)
        cur = run_conn.execute(
            "INSERT INTO workflow_runs (workflow_id, workflow_name, trigger_type, status) VALUES (?, ?, 'manual', 'running')",
            (workflow_name, workflow_name)
        )
        run_id = cur.lastrowid
        run_conn.commit()
    except Exception as e:
        logger.warning("Failed to create workflow_runs record for %s: %s", workflow_name, e)
    finally:
        if run_conn:
            run_conn.close()

    try:
        result = subprocess.run(
            [sys.executable, str(script), "--dry-run"],
            capture_output=True, text=True, timeout=90,
            cwd=str(AIBRAIN_ROOT),
        )
        duration = _time.time() - start_time
        run_status = "completed" if result.returncode == 0 else "failed"

        # Update run record
        if run_id:
            run_conn = None
            try:
                run_conn = sqlite3.connect(db_path)
                run_conn.execute(
                    "UPDATE workflow_runs SET status=?, completed_at=CURRENT_TIMESTAMP, duration_s=?, output_summary=?, error=? WHERE id=?",
                    (run_status, round(duration, 2),
                     (result.stdout[-500:] if result.stdout else ""),
                     (result.stderr[-500:] if result.stderr and result.returncode != 0 else ""),
                     run_id)
                )
                run_conn.commit()
            except Exception as e:
                logger.warning("Failed to update workflow_runs record %s: %s", run_id, e)
            finally:
                if run_conn:
                    run_conn.close()

        # Log activity
        try:
            aibrain_db.create_activity(
                agent=os.getenv("AGENT_ID", "agent"), action=f"ran {workflow_name}",
                category="workflow", detail=f"exit_code={result.returncode}",
                status="ok" if result.returncode == 0 else "error",
            )
        except (sqlite3.OperationalError, TypeError) as e:
            logger.warning("Activity logging failed for workflow %s: %s", workflow_name, e)

        # Log trace for observability
        try:
            trace_logger.log_workflow_run(
                workflow_id=workflow_name,
                status="ok" if result.returncode == 0 else "error",
                detail=result.stdout[-500:] if result.stdout else "",
                latency_ms=int(duration * 1000),
            )
        except (OSError, TypeError, ValueError) as e:
            logger.warning("Trace logging failed for workflow %s: %s", workflow_name, e)

        # Emit to pattern bus
        try:
            from event_schema import DomainEvent, PatternBus
            pb = PatternBus(db_path=db_path)
            pb.emit(DomainEvent(
                domain="aibrain", source_agent=os.getenv("AGENT_ID", "agent"),
                event_type="workflow_complete",
                key=f"workflow:{workflow_name}",
                value={"status": run_status, "duration_s": round(duration, 2), "exit_code": result.returncode},
            ))
        except Exception as e:
            logger.warning("Failed to emit workflow_complete event for %s: %s", workflow_name, e)

        response = {
            "workflow": workflow_name,
            "run_id": run_id,
            "exit_code": result.returncode,
            "duration_s": round(duration, 2),
            "stdout": result.stdout[-5000:] if result.stdout else "",
        }
        # Only include stderr on failure to avoid leaking internal paths on success
        if result.returncode != 0:
            response["stderr"] = result.stderr[-2000:] if result.stderr else ""
        return response
    except subprocess.TimeoutExpired:
        return JSONResponse({"error": "Workflow timed out (90s limit)"}, status_code=504)
    except Exception as e:
        logger.error("Workflow execution failed: %s", e, exc_info=True)
        return JSONResponse({"error": "Internal server error"}, status_code=500)


# ---------------------------------------------------------------------------
# Skills
# ---------------------------------------------------------------------------

@router.get("/skills")
async def list_skills():
    skills = []

    # Local custom skills
    if SKILLS_DIR.exists():
        for f in SKILLS_DIR.glob("*.md"):
            name = f.stem
            desc = ""
            source = "local"
            text = f.read_text(encoding="utf-8", errors="replace")[:500]
            for line in text.split("\n"):
                if line.startswith("description:"):
                    desc = line.split(":", 1)[1].strip()
                    break
            skills.append({"name": name, "description": desc, "source": source})

    # Symlinked agent skills
    if SKILLS_AGENTS_DIR.exists():
        for d in SKILLS_AGENTS_DIR.iterdir():
            if d.is_dir():
                skill_file = d / "SKILL.md"
                if not skill_file.exists():
                    skill_file = next(d.glob("*.md"), None)
                desc = ""
                if skill_file and skill_file.exists():
                    text = skill_file.read_text(encoding="utf-8", errors="replace")[:500]
                    for line in text.split("\n"):
                        if line.startswith("description:"):
                            desc = line.split(":", 1)[1].strip()
                            break
                skills.append({"name": d.name, "description": desc, "source": "agents"})

    return {"count": len(skills), "skills": skills}


@router.get("/skills/{skill_name}")
async def get_skill(skill_name: str):
    # Check local first
    local = SKILLS_DIR / f"{skill_name}.md"
    if local.exists():
        return {"name": skill_name, "source": "local", "content": local.read_text(encoding="utf-8", errors="replace")}

    # Check agents dir
    agent_dir = SKILLS_AGENTS_DIR / skill_name
    if agent_dir.exists():
        skill_file = agent_dir / "SKILL.md"
        if not skill_file.exists():
            skill_file = next(agent_dir.glob("*.md"), None)
        if skill_file:
            return {"name": skill_name, "source": "agents", "content": skill_file.read_text(encoding="utf-8", errors="replace")}

    return JSONResponse({"error": "Skill not found"}, status_code=404)


@router.post("/skills/install")
async def install_skill(body: dict):
    """Install a skill from raw content or a URL.
    Body: { name: str, content?: str, url?: str }
    """
    name = body.get("name", "").strip()
    content = body.get("content", "")
    url = body.get("url", "")

    if not name:
        return JSONResponse({"error": "name required"}, status_code=400)

    # Sanitize name
    safe_name = re.sub(r"[^a-zA-Z0-9_-]", "_", name)

    if url and not content:
        # SSRF protection — block internal IPs and dangerous schemes
        from security import validate_url
        is_safe, reason = validate_url(url)
        if not is_safe:
            return JSONResponse({"error": f"Blocked URL: {reason}"}, status_code=400)
        # Fetch from URL (async — doesn't block event loop)
        try:
            import httpx
            async with httpx.AsyncClient(timeout=15, follow_redirects=True) as client:
                resp = await client.get(url, headers={"User-Agent": "AIBrain/0.3"})
                resp.raise_for_status()
                content = resp.text
        except Exception as e:
            return JSONResponse({"error": f"Failed to fetch URL: {str(e)[:100]}"}, status_code=400)

    if not content:
        return JSONResponse({"error": "content or url required"}, status_code=400)

    # Write to local skills dir
    SKILLS_DIR.mkdir(parents=True, exist_ok=True)
    skill_path = SKILLS_DIR / f"{safe_name}.md"
    skill_path.write_text(content, encoding="utf-8")

    return {"name": safe_name, "path": str(skill_path), "size": len(content), "status": "installed"}


@router.delete("/skills/{skill_name}")
async def delete_skill(skill_name: str):
    """Delete a locally installed skill."""
    local = SKILLS_DIR / f"{skill_name}.md"
    if local.exists():
        local.unlink()
        return {"name": skill_name, "status": "deleted"}
    return JSONResponse({"error": "Skill not found or not a local skill"}, status_code=404)


# ---------------------------------------------------------------------------
# Agent Status
# ---------------------------------------------------------------------------

@router.get("/status")
async def agent_status():
    import platform as _platform
    _agent_id = os.getenv("AGENT_ID", "agent")
    local_agent = {"name": _agent_id, "platform": f"{_platform.system()} {_platform.release()}", "status": "online"}

    # Last evolution
    if LAST_EVOLUTION.exists():
        try:
            ts = int(LAST_EVOLUTION.read_text().strip())
            local_agent["last_evolution"] = datetime.fromtimestamp(ts).isoformat()
        except (ValueError, OSError):
            local_agent["last_evolution"] = None

    # Memory count
    try:
        ms = aibrain_db.memory_summary()
        local_agent["memory_count"] = ms["total"]
    except Exception as e:
        logger.warning("Failed to get memory count for status: %s", e)
        local_agent["memory_count"] = 0

    # Cron count
    local_agent["active_crons"] = len(aibrain_db.list_scheduled_jobs(enabled_only=True))

    # Recent Telegram
    recent_messages = []
    if AGENT_INBOX.exists():
        lines = AGENT_INBOX.read_text(encoding="utf-8", errors="replace").strip().split("\n")
        for line in lines[-5:]:
            try:
                recent_messages.append(json.loads(line))
            except json.JSONDecodeError:
                pass
    local_agent["recent_telegram"] = recent_messages

    # Peer agents (dynamic from env vars)
    agents = [local_agent]
    peer_name = os.getenv("PEER_NAME")
    peer_url = os.getenv("PEER_URL")
    if peer_name and peer_url:
        agents.append({
            "name": peer_name,
            "url": peer_url,
            "status": "unknown",
            "note": "Query broker for live status",
        })

    return {"agents": agents}


@router.get("/status/time")
async def agent_time():
    """Current date/time in both UTC and user's configured timezone.
    AIBrain must always know what time it is relative to the user."""
    from zoneinfo import ZoneInfo
    cfg = _load_config()
    user_tz_name = cfg.get("timezone", "UTC")
    utc_now = datetime.now(ZoneInfo("UTC"))
    try:
        user_tz = ZoneInfo(user_tz_name)
        local_now = utc_now.astimezone(user_tz)
    except Exception as e:
        logger.warning("Failed to resolve timezone %s: %s", user_tz_name, e)
        local_now = utc_now
        user_tz_name = "UTC (fallback)"
    return {
        "utc": utc_now.isoformat(),
        "local": local_now.isoformat(),
        "timezone": user_tz_name,
        "date": local_now.strftime("%A, %B %d, %Y"),
        "time": local_now.strftime("%I:%M %p"),
        "day_of_week": local_now.strftime("%A"),
        "epoch": int(utc_now.timestamp()),
    }


@router.get("/status/report")
async def status_report():
    """Generate a formatted text summary suitable for email updates."""
    lines = []
    now = datetime.now()
    lines.append(f"AIBRAIN STATUS — {now.strftime('%Y-%m-%d %H:%M')}")
    lines.append("=" * 50)

    # Memory count
    mem_count = 0
    try:
        db = get_db()
        mem_count = db.execute("SELECT COUNT(*) FROM memories WHERE active = 1").fetchone()[0]
        # Recent memories (last 2h)
        cutoff = (now - timedelta(hours=2)).isoformat()
        recent_mems = db.execute(
            "SELECT name FROM memories WHERE active = 1 AND created > ? ORDER BY created DESC LIMIT 5",
            (cutoff,),
        ).fetchall()
        db.close()
        lines.append(f"\nMEMORIES: {mem_count} total")
        if recent_mems:
            lines.append(f"  New (last 2h): {len(recent_mems)}")
            for m in recent_mems:
                lines.append(f"    + {m[0]}")
    except Exception as e:
        logger.warning("Failed to query memories for status report: %s", e)
        lines.append(f"\nMEMORIES: {mem_count} total")

    # Scheduler
    cron_active = len(aibrain_db.list_scheduled_jobs(enabled_only=True))
    lines.append(f"\nSCHEDULER: {cron_active} active jobs")

    # Approvals
    try:
        pending = aibrain_db.pending_approvals()
        lines.append(f"\nAPPROVALS: {pending} pending")
    except Exception as e:
        logger.warning("Failed to query approvals for status report: %s", e)
        lines.append("\nAPPROVALS: unavailable")

    # Costs
    try:
        from trace_logger import get_cost_summary
        cost_today = get_cost_summary(1)
        cost_total = cost_today.get("total_cost_usd", cost_today.get("total_cost", 0))
        lines.append(f"\nCOSTS: ${cost_total:.4f} today")
    except Exception as e:
        logger.warning("Failed to query costs for status report: %s", e)
        lines.append("\nCOSTS: no data")

    # Recent activity
    try:
        recent = aibrain_db.list_activity(limit=10)
        cutoff = (now - timedelta(hours=2)).isoformat()
        recent = [r for r in recent if r.get("timestamp", "") > cutoff]
        if recent:
            lines.append(f"\nACTIVITY (last 2h): {len(recent)} events")
            for r in recent:
                lines.append(f"  [{r.get('status', 'ok')}] {r.get('action', '')}")
    except (sqlite3.OperationalError, TypeError) as e:
        logger.warning("Failed to fetch recent activity for report: %s", e)

    lines.append(f"\n{'=' * 50}")
    lines.append(f"AIBrain v0.6.0 | {now.strftime('%I:%M %p')}")

    report_text = "\n".join(lines)
    return {"report": report_text, "timestamp": now.isoformat(), "memory_count": mem_count, "active_jobs": cron_active}


# ---------------------------------------------------------------------------
# Activity Log — lightweight observability
# ---------------------------------------------------------------------------

ACTIVITY_DB_PATH = AIBRAIN_ROOT / "activity.db"  # Legacy path, kept for reference


def get_activity_db():
    """Return a NEW connection to the consolidated DB for activity queries."""
    return get_db()


@router.get("/activity")
async def list_activity(
    limit: int = Query(50),
    agent: Optional[str] = Query(None),
    category: Optional[str] = Query(None),
):
    db = get_activity_db()
    query = "SELECT * FROM activity WHERE 1=1"
    params = []
    if agent:
        query += " AND agent = ?"
        params.append(agent)
    if category:
        query += " AND category = ?"
        params.append(category)
    from security import safe_limit
    limit = safe_limit(limit, 500)
    query += " ORDER BY timestamp DESC LIMIT ?"
    params.append(limit)
    rows = db.execute(query, params).fetchall()
    db.close()
    return {"count": len(rows), "entries": [dict(r) for r in rows]}


@router.post("/activity")
async def log_activity(body: dict):
    action = body.get("action")
    if not action:
        return JSONResponse({"error": "action required"}, status_code=400)
    db = get_activity_db()
    now = datetime.now().isoformat()
    agent = body.get("agent", os.getenv("AGENT_ID", "agent"))
    category = body.get("category", "general")
    detail = body.get("detail", "")
    status = body.get("status", "ok")
    db.execute(
        "INSERT INTO activity (timestamp, agent, action, category, detail, status) VALUES (?, ?, ?, ?, ?, ?)",
        (now, agent, action, category, detail, status)
    )
    entry_id = db.execute("SELECT last_insert_rowid()").fetchone()[0]
    db.commit()
    db.close()

    # Broadcast real-time notification
    if _notify_callback:
        import asyncio
        entry = {"id": entry_id, "timestamp": now, "agent": agent, "action": action,
                 "category": category, "detail": detail, "status": status}
        asyncio.ensure_future(_notify_callback({"type": "activity", "entry": entry}))

    return {"status": "logged", "timestamp": now, "id": entry_id}


@router.delete("/activity")
async def clear_activity():
    """Delete all activity log entries."""
    db = get_activity_db()
    db.execute("DELETE FROM activity")
    db.commit()
    db.close()
    return {"status": "cleared"}


# ---------------------------------------------------------------------------
# Traces / Observability / Cost Tracking
# ---------------------------------------------------------------------------

@router.get("/traces")
async def list_traces(
    limit: int = Query(50),
    trace_type: Optional[str] = Query(None),
):
    """Get recent traces for the observability timeline."""
    from trace_logger import get_recent_traces
    return {"traces": get_recent_traces(limit=limit, trace_type=trace_type)}


@router.get("/traces/stats")
async def trace_stats():
    """Overall trace statistics."""
    from trace_logger import get_trace_stats
    return get_trace_stats()


@router.get("/costs/summary")
async def cost_summary(days: int = Query(30)):
    """Total LLM spend, token counts, and call stats."""
    from llm_router import get_cost_summary
    return get_cost_summary(days)


@router.get("/costs/by-model")
async def cost_by_model(days: int = Query(30)):
    """LLM cost breakdown per model."""
    from llm_router import get_cost_by_model
    return {"models": get_cost_by_model(days), "period_days": days}


@router.get("/costs/by-workflow")
async def cost_by_workflow(days: int = Query(30)):
    """LLM cost breakdown per workflow."""
    from llm_router import get_cost_by_workflow
    return {"workflows": get_cost_by_workflow(days), "period_days": days}


@router.get("/costs/daily")
async def cost_daily(days: int = Query(30)):
    """Daily LLM spend for charting."""
    from llm_router import get_daily_costs
    return {"daily": get_daily_costs(days), "period_days": days}


@router.get("/models")
async def list_models():
    """List all configured LLM models and their status."""
    from llm_router import list_models as _list_models, LITELLM_AVAILABLE
    return {
        "models": _list_models(),
        "litellm_available": LITELLM_AVAILABLE,
    }


@router.post("/models/test")
async def test_model_endpoint(body: dict):
    """Test connectivity to a specific model. Body: {model: "claude-sonnet-4-20250514"}"""
    model = body.get("model")
    if not model:
        return JSONResponse({"error": "model required"}, status_code=400)
    from llm_router import test_model
    return test_model(model)


# ---------------------------------------------------------------------------
# NL Workflow Creation
# ---------------------------------------------------------------------------

@router.post("/workflows/create-from-nl")
async def create_workflow_from_nl(body: dict):
    """Create a new workflow from a natural language description.
    Body: {description: "Every morning check my email and summarize it"}
    """
    description = body.get("description", "").strip()
    if not description:
        return JSONResponse({"error": "description required"}, status_code=400)

    from workflow_generator import generate_workflow
    result = generate_workflow(description)
    if result.get("error"):
        return JSONResponse({"error": result["error"]}, status_code=500)
    return result


# ---------------------------------------------------------------------------
# Content Pipeline
# ---------------------------------------------------------------------------

@router.post("/content/generate")
async def generate_content(body: dict):
    """Generate content posts and add to approval queue.
    Body: {count: 5} — generates N posts and creates approval items for each.
    """
    import sys as _sys
    _sys.path.insert(0, str(AIBRAIN_ROOT / "workflows"))
    from content_calendar import generate_posts, save_state

    count = body.get("count", 5)
    state, new_posts = generate_posts(count=count)
    save_state(state)

    # Create approval items for each generated post
    approval_db = AIBRAIN_ROOT / "approval.db"
    from approval_queue import add_item as aq_add
    approval_ids = []
    for post in new_posts:
        aid = aq_add(
            approval_db,
            category="social",
            title=f"Post to {post['platform']}: {post['text'][:60]}...",
            detail=post["text"],
            payload={
                "action": "publish",
                "platform": post["platform"],
                "content": post["text"],
                "category": post["category"],
                "post_id": post["id"],
                "scheduled": post["scheduled"],
            },
        )
        approval_ids.append(aid)

    return {
        "generated": len(new_posts),
        "posts": new_posts,
        "approval_ids": approval_ids,
        "message": f"Created {len(new_posts)} posts. Approve them in the Approval Queue to publish.",
    }


@router.get("/content/queue")
async def content_queue():
    """Get the current content queue."""
    import sys as _sys
    _sys.path.insert(0, str(AIBRAIN_ROOT / "workflows"))
    from content_calendar import load_state
    state = load_state()
    queued = [p for p in state.get("queue", []) if p.get("status") == "queued"]
    queued.sort(key=lambda p: p.get("scheduled", ""))
    return {
        "queued": len(queued),
        "posted": len(state.get("posted", [])),
        "posts": queued,
    }


@router.get("/content/stats")
async def content_stats():
    """Content posting statistics."""
    import sys as _sys
    _sys.path.insert(0, str(AIBRAIN_ROOT / "workflows"))
    from content_calendar import load_state
    state = load_state()
    posted = state.get("posted", [])
    by_platform = {}
    by_category = {}
    for p in posted:
        plat = p.get("platform", "unknown")
        cat = p.get("category", "unknown")
        by_platform[plat] = by_platform.get(plat, 0) + 1
        by_category[cat] = by_category.get(cat, 0) + 1
    return {
        "total_posted": len(posted),
        "queued": len([p for p in state.get("queue", []) if p.get("status") == "queued"]),
        "by_platform": by_platform,
        "by_category": by_category,
    }


@router.delete("/approvals/all")
async def clear_all_approvals():
    """Delete all approval queue entries."""
    approval_db = AIBRAIN_ROOT / "approval.db"
    if approval_db.exists():
        import sqlite3 as _sq
        db = _sq.connect(str(approval_db))
        db.execute("DELETE FROM approval_queue")
        db.commit()
        db.close()
    return {"status": "cleared"}


# ---------------------------------------------------------------------------
# Broker — lightweight message relay for multi-agent communication
# ---------------------------------------------------------------------------

_broker_queues: dict = {}  # in-memory: {agent_name: [messages]}


@router.post("/broker/send")
async def broker_send(body: dict):
    """Send a message to another agent's queue."""
    to = body.get("to")
    msg = body.get("message")
    if not to or not msg:
        return JSONResponse({"error": "to and message required"}, status_code=400)

    if to not in _broker_queues:
        _broker_queues[to] = []

    entry = {
        "from": body.get("from", "unknown"),
        "to": to,
        "message": msg,
        "timestamp": datetime.now().isoformat(),
        "type": body.get("type", "text"),
    }
    _broker_queues[to].append(entry)

    # Keep max 100 messages per queue
    if len(_broker_queues[to]) > 100:
        _broker_queues[to] = _broker_queues[to][-100:]

    return {"status": "queued", "queue_depth": len(_broker_queues[to])}


@router.get("/broker/recv")
async def broker_recv(
    agent: str = Query(..., alias="for"),
    peek: bool = Query(False),
):
    """Receive messages for an agent. Pops by default, peek=true to leave in queue."""
    queue = _broker_queues.get(agent, [])
    if not queue:
        return {"messages": [], "count": 0}

    if peek:
        return {"messages": queue, "count": len(queue)}

    # Pop all messages
    messages = list(queue)
    _broker_queues[agent] = []
    return {"messages": messages, "count": len(messages)}


@router.get("/broker/status")
async def broker_status():
    """Show all agent queues and depths."""
    return {
        "queues": {name: len(msgs) for name, msgs in _broker_queues.items()},
        "total_messages": sum(len(msgs) for msgs in _broker_queues.values()),
    }


# ---------------------------------------------------------------------------
# Workflow Builder — visual node/edge graph persistence
# ---------------------------------------------------------------------------

BUILDER_DIR = AIBRAIN_ROOT / "builder_workflows"


@router.post("/workflows/builder")
async def save_builder_workflow(body: dict):
    """Save a visual workflow graph. Body: {name, nodes, edges}."""
    BUILDER_DIR.mkdir(exist_ok=True)
    name = body.get("name", "untitled").strip()
    wf_id = body.get("id") or name.lower().replace(" ", "_").replace("-", "_")
    # Sanitize
    wf_id = "".join(c for c in wf_id if c.isalnum() or c == "_")[:64]

    data = {
        "id": wf_id,
        "name": name,
        "nodes": body.get("nodes", []),
        "edges": body.get("edges", []),
        "updated": datetime.now().isoformat(),
    }
    path = BUILDER_DIR / f"{wf_id}.json"
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return {"id": wf_id, "status": "saved"}


@router.delete("/workflows/builder/{workflow_id}")
async def delete_builder_workflow(workflow_id: str):
    """Delete a visual workflow graph."""
    path = BUILDER_DIR / f"{workflow_id}.json"
    if path.exists():
        path.unlink()
    return {"id": workflow_id, "status": "deleted"}


# ---------------------------------------------------------------------------
# Content Pipeline — multi-platform content creation, scheduling, publishing
# ---------------------------------------------------------------------------

CONTENT_DB = AIBRAIN_ROOT / "content.db"


def _content_db():
    """Get or create content pipeline database."""
    db = sqlite3.connect(str(CONTENT_DB))
    db.row_factory = sqlite3.Row
    db.execute("""
        CREATE TABLE IF NOT EXISTS content (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            body TEXT NOT NULL DEFAULT '',
            content_type TEXT DEFAULT 'text',
            platforms TEXT DEFAULT '[]',
            status TEXT DEFAULT 'draft',
            scheduled_at TEXT,
            published_at TEXT,
            ai_prompt TEXT,
            tags TEXT DEFAULT '[]',
            created_at TEXT DEFAULT (datetime('now')),
            updated_at TEXT DEFAULT (datetime('now'))
        )
    """)
    db.commit()
    return db


@router.get("/content")
async def list_content(status: Optional[str] = None, platform: Optional[str] = None, limit: int = 50):
    """List content items with optional filters."""
    from security import safe_limit
    limit = safe_limit(limit, 200)
    db = _content_db()
    query = "SELECT * FROM content"
    params = []
    wheres = []
    if status:
        wheres.append("status = ?")
        params.append(status)
    if platform:
        wheres.append("platforms LIKE ?")
        params.append(f'%"{platform}"%')
    if wheres:
        query += " WHERE " + " AND ".join(wheres)
    query += " ORDER BY CASE status WHEN 'scheduled' THEN 0 WHEN 'draft' THEN 1 WHEN 'pending_approval' THEN 2 WHEN 'published' THEN 3 ELSE 4 END, created_at DESC"
    query += " LIMIT ?"
    params.append(limit)
    rows = db.execute(query, params).fetchall()
    items = []
    for r in rows:
        item = dict(r)
        item["platforms"] = json.loads(item["platforms"]) if item["platforms"] else []
        item["tags"] = json.loads(item["tags"]) if item["tags"] else []
        items.append(item)
    db.close()
    return {"items": items}



@router.get("/content/{content_id}")
async def get_content(content_id: int):
    """Get a single content item."""
    db = _content_db()
    row = db.execute("SELECT * FROM content WHERE id = ?", (content_id,)).fetchone()
    db.close()
    if not row:
        return JSONResponse({"error": "Not found"}, status_code=404)
    item = dict(row)
    item["platforms"] = json.loads(item["platforms"]) if item["platforms"] else []
    item["tags"] = json.loads(item["tags"]) if item["tags"] else []
    return item


@router.post("/content")
async def create_content(body: dict):
    """Create a new content item."""
    db = _content_db()
    now = datetime.utcnow().isoformat()
    db.execute(
        "INSERT INTO content (body, content_type, platforms, status, scheduled_at, ai_prompt, tags, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (
            body.get("body", ""),
            body.get("content_type", "text"),
            json.dumps(body.get("platforms", [])),
            body.get("status", "draft"),
            body.get("scheduled_at"),
            body.get("ai_prompt"),
            json.dumps(body.get("tags", [])),
            now, now,
        ),
    )
    db.commit()
    content_id = db.execute("SELECT last_insert_rowid()").fetchone()[0]
    db.close()

    # If posting now, create approval request
    if body.get("status") == "pending_approval":
        try:
            from approval_queue import add_item as aq_add
            platforms = body.get("platforms", [])
            preview = body.get("body", "")[:120]
            aq_add(
                AIBRAIN_ROOT / "approval.db",
                category="content",
                title=f"Publish content to {', '.join(platforms)}",
                detail=preview,
                payload={"content_id": content_id, "platforms": platforms, "action": "publish"},
            )
        except (ImportError, sqlite3.OperationalError, TypeError) as e:
            logger.warning("Approval queue creation failed for content %s: %s", content_id, e)

    return {"id": content_id, "status": "created"}


@router.put("/content/{content_id}")
async def update_content(content_id: int, body: dict):
    """Update a content item."""
    db = _content_db()
    fields = []
    params = []
    for key in ["body", "content_type", "status", "scheduled_at", "ai_prompt"]:
        if key in body:
            fields.append(f"{key} = ?")
            params.append(body[key])
    if "platforms" in body:
        fields.append("platforms = ?")
        params.append(json.dumps(body["platforms"]))
    if "tags" in body:
        fields.append("tags = ?")
        params.append(json.dumps(body["tags"]))
    fields.append("updated_at = ?")
    params.append(datetime.utcnow().isoformat())
    params.append(content_id)
    db.execute(f"UPDATE content SET {', '.join(fields)} WHERE id = ?", params)  # noqa:SQL F-STRING — fields is from validated whitelist
    db.commit()
    db.close()
    return {"id": content_id, "status": "updated"}


@router.delete("/content/{content_id}")
async def delete_content(content_id: int):
    """Delete a content item."""
    db = _content_db()
    db.execute("DELETE FROM content WHERE id = ?", (content_id,))
    db.commit()
    db.close()
    return {"id": content_id, "status": "deleted"}


@router.post("/content/{content_id}/publish")
async def publish_content(content_id: int):
    """Mark content as published (actual publishing handled by workflow engine)."""
    db = _content_db()
    now = datetime.utcnow().isoformat()
    db.execute("UPDATE content SET status = 'published', published_at = ?, updated_at = ? WHERE id = ?", (now, now, content_id))
    db.commit()
    db.close()
    if _notify_callback:
        import asyncio
        asyncio.ensure_future(_notify_callback({"type": "content", "action": "published", "content_id": content_id}))
    return {"id": content_id, "status": "published"}



# ---------------------------------------------------------------------------
# Peers — multi-agent mesh registry (works with Tailscale or direct IP)
# ---------------------------------------------------------------------------

PEERS_FILE = AIBRAIN_ROOT / "peers.json"


def _load_peers():
    if PEERS_FILE.exists():
        try:
            return json.loads(PEERS_FILE.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            pass
    return {"peers": []}


def _save_peers(data):
    PEERS_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")


@router.get("/peers")
async def list_peers():
    """List all known agent peers in the mesh."""
    from security import validate_url
    data = _load_peers()
    # Check health of each peer (async, with SSRF protection)
    import httpx
    async with httpx.AsyncClient(timeout=3) as client:
        for peer in data.get("peers", []):
            health_url = f"{peer['url']}/health"
            is_safe, _ = validate_url(health_url)
            if not is_safe:
                peer["status"] = "blocked"
                continue
            try:
                resp = await client.get(health_url)
                peer["status"] = "online" if resp.status_code == 200 else "error"
            except Exception as e:
                logger.warning("Peer health check failed for %s: %s", peer.get("name", "unknown"), e)
                peer["status"] = "offline"
    return data


@router.post("/peers")
async def add_peer(body: dict):
    """Register a new agent peer. Body: {name, url, ?description}"""
    from security import validate_url
    name = body.get("name")
    url = body.get("url")
    if not name or not url:
        return JSONResponse({"error": "name and url required"}, status_code=400)
    is_safe, reason = validate_url(url)
    if not is_safe:
        return JSONResponse({"error": f"Blocked URL: {reason}"}, status_code=400)

    data = _load_peers()
    # Update existing or add new
    existing = next((p for p in data["peers"] if p["name"] == name), None)
    if existing:
        existing["url"] = url
        existing["description"] = body.get("description", existing.get("description", ""))
        existing["updated"] = datetime.now().isoformat()
    else:
        data["peers"].append({
            "name": name,
            "url": url.rstrip("/"),
            "description": body.get("description", ""),
            "added": datetime.now().isoformat(),
            "updated": datetime.now().isoformat(),
        })
    _save_peers(data)
    return {"status": "registered", "peer": name, "total_peers": len(data["peers"])}


@router.delete("/peers/{peer_name}")
async def remove_peer(peer_name: str):
    """Remove a peer from the mesh."""
    data = _load_peers()
    data["peers"] = [p for p in data["peers"] if p["name"] != peer_name]
    _save_peers(data)
    return {"status": "removed", "peer": peer_name}


# ---------------------------------------------------------------------------
# Networking API — Tailscale mesh status and management
# ---------------------------------------------------------------------------

@router.get("/networking/status")
async def networking_status():
    """Get full networking status including Tailscale mesh."""
    try:
        from aibrain_networking import get_status
        return get_status()
    except ImportError:
        return {"installed": False, "connected": False, "error": "aibrain_networking not available"}


@router.get("/networking/peers")
async def networking_peers():
    """Get Tailscale peers on the mesh."""
    try:
        from aibrain_networking import get_peers, is_tailscale_ready
        if not is_tailscale_ready():
            return {"peers": [], "tailscale_connected": False}
        return {"peers": get_peers(), "tailscale_connected": True}
    except ImportError:
        return {"peers": [], "tailscale_connected": False}


# ---------------------------------------------------------------------------
# Config API — read/write config.json (LLM provider, theme, preferences)
# ---------------------------------------------------------------------------

# Settings that are safe to read/write via the UI
_ALLOWED_SETTINGS = {
    "llm_provider", "anthropic_api_key", "openai_api_key",
    "anthropic_model", "openai_model", "ollama_model", "ollama_url",
    "llm_routing",
    "theme", "auto_refresh", "refresh_interval",
    "notify_approvals", "notify_chat",
    "setup_complete", "user_name", "user_email", "timezone",
    "smtp_user", "smtp_pass", "smtp_host", "smtp_port",
    "github_token", "telegram_bot_token", "weather_api_key",
    "budget_daily", "budget_monthly",
}

# Keys whose values should be masked when reading
_MASKED_KEYS = {"anthropic_api_key", "openai_api_key", "smtp_pass", "github_token", "telegram_bot_token"}


@router.get("/config")
async def get_config():
    """Get user-facing config (API keys masked)."""
    cfg = _load_config()
    safe = {}
    for k in _ALLOWED_SETTINGS:
        val = cfg.get(k)
        if val is None:
            continue
        if k in _MASKED_KEYS and val:
            safe[k] = val[:4] + "..." + val[-4:] if len(val) > 8 else "****"
        else:
            safe[k] = val
    # Report which providers are available
    providers = []
    if cfg.get("anthropic_api_key"):
        providers.append("claude")
    if cfg.get("openai_api_key"):
        providers.append("openai")
    providers.append("ollama")  # always available if user runs it
    providers.append("claude_cli")  # always available if CLI installed
    safe["available_providers"] = providers
    safe["active_provider"] = cfg.get("llm_provider", "auto")
    return safe


@router.put("/config")
async def update_config(body: dict):
    """Update config settings. Only allowed keys are written."""
    cfg = _load_config()
    updated = []
    for k, v in body.items():
        if k not in _ALLOWED_SETTINGS:
            continue
        # Don't overwrite a real key with a masked version
        if k in _MASKED_KEYS and isinstance(v, str) and "..." in v:
            continue
        cfg[k] = v
        updated.append(k)
    _config_file.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    return {"status": "updated", "keys": updated}


# ---------------------------------------------------------------------------
# Provider connection test
# ---------------------------------------------------------------------------

@router.post("/config/test-provider")
async def test_provider(body: dict):
    """Test if an AI provider is reachable and the API key works."""
    provider = body.get("provider", "auto")
    cfg = _load_config()

    results = {}

    import httpx
    async with httpx.AsyncClient(timeout=10) as client:
        if provider in ("claude", "auto"):
            key = cfg.get("anthropic_api_key", "")
            if key:
                try:
                    resp = await client.post(
                        "https://api.anthropic.com/v1/messages",
                        headers={
                            "x-api-key": key,
                            "anthropic-version": "2023-06-01",
                            "content-type": "application/json",
                        },
                        json={
                            "model": "claude-haiku-4-5-20251001",
                            "max_tokens": 1,
                            "messages": [{"role": "user", "content": "hi"}],
                        },
                    )
                    if resp.status_code == 401:
                        results["claude"] = {"ok": False, "message": "Invalid API key"}
                    elif resp.status_code == 429:
                        results["claude"] = {"ok": True, "message": "Connected (rate limited)"}
                    else:
                        results["claude"] = {"ok": True, "message": "Connected"}
                except Exception as e:
                    results["claude"] = {"ok": False, "message": str(e)[:100]}
            else:
                results["claude"] = {"ok": False, "message": "No API key configured"}

        if provider in ("openai", "auto"):
            key = cfg.get("openai_api_key", "")
            if key:
                try:
                    resp = await client.get(
                        "https://api.openai.com/v1/models",
                        headers={"Authorization": f"Bearer {key}"},
                    )
                    if resp.status_code == 401:
                        results["openai"] = {"ok": False, "message": "Invalid API key"}
                    else:
                        results["openai"] = {"ok": True, "message": "Connected"}
                except Exception as e:
                    results["openai"] = {"ok": False, "message": str(e)[:100]}
            else:
                results["openai"] = {"ok": False, "message": "No API key configured"}

        if provider in ("ollama", "auto"):
            url = cfg.get("ollama_url", "http://localhost:11434")
            from security import validate_url
            is_safe, reason = validate_url(f"{url}/api/tags")
            if not is_safe:
                results["ollama"] = {"ok": False, "message": f"Blocked URL: {reason}"}
            else:
                try:
                    resp = await client.get(f"{url}/api/tags", timeout=5)
                    results["ollama"] = {"ok": True, "message": "Connected"}
                except Exception as e:
                    logger.warning("Ollama connection failed at %s: %s", url, e)
                    results["ollama"] = {"ok": False, "message": f"Not reachable at {url}"}

    return {"results": results}


# ---------------------------------------------------------------------------
# MCP Servers — detect installed from ~/.claude.json
# ---------------------------------------------------------------------------

@router.get("/mcp/installed")
async def mcp_installed():
    """Detect which MCP servers are configured in ~/.claude.json."""
    claude_config = Path.home() / ".claude.json"
    if not claude_config.exists():
        return {"installed": {}, "config_path": str(claude_config), "exists": False}

    try:
        data = json.loads(claude_config.read_text(encoding="utf-8"))
        servers = data.get("mcpServers", {})
        installed = {}
        for name, config in servers.items():
            installed[name] = {
                "command": config.get("command", ""),
                "args": config.get("args", []),
                "enabled": not config.get("disabled", False),
            }
        return {"installed": installed, "config_path": str(claude_config), "exists": True}
    except (json.JSONDecodeError, OSError) as e:
        return {"installed": {}, "config_path": str(claude_config), "exists": True, "error": str(e)}



# ---------------------------------------------------------------------------
# Tasks — simple task queue backed by SQLite
# ---------------------------------------------------------------------------
_TASKS_DB = AIBRAIN_ROOT / "tasks.db"

def _init_tasks_db():
    db = sqlite3.connect(str(_TASKS_DB))
    db.execute("""
        CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT DEFAULT '',
            agent TEXT DEFAULT 'system',
            status TEXT DEFAULT 'pending',
            progress REAL DEFAULT -1,
            output TEXT DEFAULT '',
            error TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            started_at TEXT,
            completed_at TEXT
        )
    """)
    db.commit()
    return db

@router.get("/tasks")
async def list_tasks(status: Optional[str] = Query(None), limit: int = Query(50)):
    db = _init_tasks_db()
    cur = db.cursor()
    if status:
        cur.execute(
            "SELECT * FROM tasks WHERE status = ? ORDER BY created_at DESC LIMIT ?",
            (status, limit)
        )
    else:
        cur.execute(
            "SELECT * FROM tasks ORDER BY created_at DESC LIMIT ?", (limit,)
        )
    rows = cur.fetchall()
    cols = [d[0] for d in cur.description]
    db.close()
    return {"tasks": [dict(zip(cols, r)) for r in rows]}

@router.post("/tasks")
async def create_task(data: dict):
    db = _init_tasks_db()
    now = datetime.utcnow().isoformat()
    db.execute(
        "INSERT INTO tasks (name, description, agent, status, created_at) VALUES (?, ?, ?, 'pending', ?)",
        (data.get("name", "Unnamed"), data.get("description", ""), data.get("agent", "system"), now)
    )
    db.commit()
    task_id = db.execute("SELECT last_insert_rowid()").fetchone()[0]
    db.close()
    return {"id": task_id, "status": "pending"}

@router.post("/tasks/{task_id}/cancel")
async def cancel_task(task_id: int):
    db = _init_tasks_db()
    db.execute("UPDATE tasks SET status = 'cancelled', completed_at = ? WHERE id = ?",
               (datetime.utcnow().isoformat(), task_id))
    db.commit()
    db.close()
    return {"status": "cancelled"}

@router.post("/tasks/{task_id}/retry")
async def retry_task(task_id: int):
    db = _init_tasks_db()
    db.execute("UPDATE tasks SET status = 'pending', error = '', output = '', started_at = NULL, completed_at = NULL WHERE id = ?",
               (task_id,))
    db.commit()
    db.close()
    return {"status": "pending"}


# ---------------------------------------------------------------------------
# Backups — snapshot memory DB to file
# ---------------------------------------------------------------------------
_BACKUPS_DIR = AIBRAIN_ROOT / "backups"

@router.get("/backups")
async def list_backups():
    _BACKUPS_DIR.mkdir(exist_ok=True)
    backups = []
    for f in sorted(_BACKUPS_DIR.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True):
        stat = f.stat()
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
            memory_count = len(data.get("memories", []))
        except Exception as e:
            logger.warning("Failed to parse backup file %s: %s", f.name, e)
            memory_count = 0
        backups.append({
            "filename": f.name,
            "name": f.stem,
            "size": stat.st_size,
            "memory_count": memory_count,
            "created_at": datetime.fromtimestamp(stat.st_mtime).isoformat(),
        })
    return {"backups": backups}

@router.post("/backups")
async def create_backup(data: dict = {}):
    _BACKUPS_DIR.mkdir(exist_ok=True)
    name = data.get("name", f"backup-{datetime.utcnow().strftime('%Y%m%d-%H%M%S')}")

    # Export memories
    db = get_db()
    try:
        rows = db.execute(
            "SELECT id, name, type, content, tags, created, updated FROM memories WHERE active = 1"
        ).fetchall()
        memories = [
            {"id": r[0], "name": r[1], "type": r[2], "content": r[3], "tags": r[4], "created": r[5], "updated": r[6]}
            for r in rows
        ]
    finally:
        db.close()

    backup_data = {
        "version": "1.0",
        "created_at": datetime.utcnow().isoformat(),
        "name": name,
        "memories": memories,
    }

    # Include cron jobs if available
    if CRON_JOBS_PATH.exists():
        try:
            backup_data["crons"] = json.loads(CRON_JOBS_PATH.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError) as e:
            logger.warning("Failed to include cron jobs in backup: %s", e)

    backup_path = _BACKUPS_DIR / f"{name}.json"
    backup_path.write_text(json.dumps(backup_data, indent=2), encoding="utf-8")

    return {"name": name, "path": str(backup_path), "memory_count": len(memories)}

@router.post("/backups/{filename}/restore")
async def restore_backup(filename: str):
    path = _safe_backup_path(filename)
    if not path or not path.exists():
        return JSONResponse({"error": "Backup not found"}, status_code=404)

    data = json.loads(path.read_text(encoding="utf-8"))
    db = get_db()
    try:
        restored = 0
        for mem in data.get("memories", []):
            existing = db.execute("SELECT id FROM memories WHERE name = ?", (mem["name"],)).fetchone()
            if not existing:
                db.execute(
                    "INSERT INTO memories (name, type, content, tags, created, updated, active) VALUES (?, ?, ?, ?, ?, ?, 1)",
                    (mem["name"], mem.get("type", "reference"), mem.get("content", ""),
                     mem.get("tags", ""), mem.get("created", mem.get("created_at", datetime.utcnow().isoformat())),
                     mem.get("updated", mem.get("updated_at", datetime.utcnow().isoformat())))
                )
                restored += 1
        db.commit()
    finally:
        db.close()
    return {"memories_restored": restored}

def _safe_backup_path(filename: str) -> Path:
    """Resolve backup path and guard against path traversal."""
    path = (_BACKUPS_DIR / filename).resolve()
    if not path.suffix:
        path = path.with_suffix(".json")
    if not str(path).startswith(str(_BACKUPS_DIR.resolve())):  # noqa:PATH STARTSWITH BYPASS — path already sanitized and resolved
        return None
    return path

@router.get("/backups/{filename}/download")
async def download_backup(filename: str):
    path = _safe_backup_path(filename)
    if not path or not path.exists():
        return JSONResponse({"error": "Backup not found"}, status_code=404)
    data = json.loads(path.read_text(encoding="utf-8"))
    return data

@router.delete("/backups/{filename}")
async def delete_backup(filename: str):
    path = _safe_backup_path(filename)
    if not path:
        return JSONResponse({"error": "Invalid filename"}, status_code=400)
    if path.exists():
        path.unlink()
    return {"status": "deleted"}


# ---------------------------------------------------------------------------
# Logs — return recent activity as structured logs
# ---------------------------------------------------------------------------
@router.get("/logs")
async def get_logs(limit: int = Query(200)):
    """Return recent activity entries formatted as log lines from the activity DB."""
    from security import safe_limit
    limit = safe_limit(limit, 1000)

    try:
        db = get_activity_db()
        rows = db.execute(
            "SELECT * FROM activity ORDER BY timestamp DESC LIMIT ?", (limit,)
        ).fetchall()
        db.close()

        logs = []
        for entry in reversed(rows):  # chronological order
            entry = dict(entry)
            ts = entry.get("timestamp", "")
            if ts and "T" in ts:
                ts = ts.replace("T", " ")[:19]
            level = "ERROR" if entry.get("status") == "error" else "INFO"
            if entry.get("status") == "warning":
                level = "WARN"
            agent = entry.get("agent", "system")
            action = entry.get("action", "")
            detail = entry.get("detail", "")
            logs.append(f"[{ts}] {level} [{agent}] {action}" + (f" — {detail}" if detail else ""))

        return {"logs": logs}
    except Exception as e:
        logger.warning("Failed to query activity log: %s", e)
        return {"logs": []}


# ---------------------------------------------------------------------------
# Cost History — daily cost breakdown
# ---------------------------------------------------------------------------
@router.get("/costs/history")
async def cost_history(days: int = Query(7)):
    """Return daily cost breakdown for sparkline charts."""
    traces_dir = AIBRAIN_ROOT / "traces"
    daily = []

    for i in range(days):
        date = (datetime.utcnow() - timedelta(days=i)).strftime("%Y-%m-%d")
        day_cost = 0.0

        if traces_dir.exists():
            for f in traces_dir.glob(f"{date}*.json"):
                try:
                    trace = json.loads(f.read_text(encoding="utf-8"))
                    day_cost += trace.get("cost", 0) or 0
                except (json.JSONDecodeError, OSError) as e:
                    logger.warning("Skipping unreadable trace file %s: %s", f.name, e)

        daily.append({"date": date, "cost": round(day_cost, 4)})

    daily.reverse()  # oldest first for sparkline
    return {"daily": daily}


# ---------------------------------------------------------------------------
# Applications — job application tracker with priority levels
# ---------------------------------------------------------------------------

def _apps_db():
    """Return a connection to the consolidated DB for applications queries."""
    db = sqlite3.connect(str(aibrain_db.DB_PATH))
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA journal_mode=WAL")
    # Ensure priority column exists (idempotent)
    cols = [r[1] for r in db.execute("PRAGMA table_info(applications)").fetchall()]
    if "priority" not in cols:
        db.execute("ALTER TABLE applications ADD COLUMN priority TEXT DEFAULT 'medium'")
        db.commit()
    return db


@router.get("/applications")
async def list_applications(
    status: Optional[str] = Query(None),
    priority: Optional[str] = Query(None),
    sort: str = Query("date_applied"),
    order: str = Query("desc"),
    limit: int = Query(100),
):
    """List job applications with optional filtering and sorting."""
    db = _apps_db()
    where_clauses = []
    params = []

    if status:
        where_clauses.append("status = ?")
        params.append(status)
    if priority:
        where_clauses.append("priority = ?")
        params.append(priority)

    where_sql = (" WHERE " + " AND ".join(where_clauses)) if where_clauses else ""

    # Whitelist sortable columns
    allowed_sorts = {"date_applied", "company", "priority", "status", "role", "created_at", "updated_at"}
    sort_col = sort if sort in allowed_sorts else "date_applied"
    sort_order = "ASC" if order.lower() == "asc" else "DESC"

    # For priority sorting, use a CASE expression for logical order
    if sort_col == "priority":
        order_sql = f"""ORDER BY CASE priority
            WHEN 'critical' THEN 1
            WHEN 'high' THEN 2
            WHEN 'medium' THEN 3
            WHEN 'low' THEN 4
            WHEN 'skip' THEN 5
            ELSE 3 END {sort_order}"""
    else:
        order_sql = f"ORDER BY {sort_col} {sort_order}"

    safe_limit = min(max(1, limit), 500)
    query = f"SELECT * FROM applications {where_sql} {order_sql} LIMIT ?"  # noqa:SQL F-STRING — where_sql built from validated params
    params.append(safe_limit)

    rows = db.execute(query, params).fetchall()
    cols = [d[0] for d in db.execute("PRAGMA table_info(applications)").fetchall()]
    col_names = [c[1] for c in db.execute("PRAGMA table_info(applications)").fetchall()]

    apps = [dict(row) for row in rows]

    # Get summary counts
    total = db.execute("SELECT COUNT(*) FROM applications").fetchone()[0]
    by_status = {}
    for r in db.execute("SELECT status, COUNT(*) as cnt FROM applications GROUP BY status"):
        by_status[r[0]] = r[1]
    by_priority = {}
    for r in db.execute("SELECT COALESCE(priority, 'medium') as p, COUNT(*) as cnt FROM applications GROUP BY p"):
        by_priority[r[0]] = r[1]

    db.close()
    return {
        "applications": apps,
        "total": total,
        "filtered": len(apps),
        "summary": {"by_status": by_status, "by_priority": by_priority},
    }


@router.patch("/applications/{app_id}")
async def update_application(app_id: int, body: dict):
    """Update a job application (priority, status, notes, etc.)."""
    db = _apps_db()

    # Only allow updating safe fields
    allowed_fields = {"priority", "status", "notes", "tags", "salary", "location"}
    fields = []
    params = []
    for key in allowed_fields:
        if key in body:
            fields.append(f"{key} = ?")
            params.append(body[key])

    if not fields:
        db.close()
        return JSONResponse({"error": "No valid fields to update"}, status_code=400)

    fields.append("updated_at = ?")
    params.append(datetime.utcnow().isoformat())
    params.append(app_id)

    db.execute(f"UPDATE applications SET {', '.join(fields)} WHERE id = ?", params)
    db.commit()

    # Return updated row
    row = db.execute("SELECT * FROM applications WHERE id = ?", (app_id,)).fetchone()
    db.close()
    if not row:
        return JSONResponse({"error": "Application not found"}, status_code=404)

    app = dict(row)

    # Auto-promote: when status moves to a reply/conversation state, create a project
    promote_statuses = {"replied", "active_conversation", "interview_scheduled"}
    if body.get("status") in promote_statuses:
        try:
            result = await _promote_application(app_id)
            app["promoted_project_id"] = result.get("project_id")
        except Exception as e:
            logger.warning("Auto-promote failed for application %s: %s", app_id, e)

    return {"status": "updated", "application": app}


async def _promote_application(app_id: int):
    """Promote a job application into its own project with interview pipeline phases."""
    apps_db = _apps_db()
    row = apps_db.execute("SELECT * FROM applications WHERE id = ?", (app_id,)).fetchone()
    if not row:
        apps_db.close()
        raise ValueError(f"Application {app_id} not found")
    app = dict(row)
    apps_db.close()

    db = _projects_db()

    # Check if already promoted (avoid duplicates)
    existing = db.execute(
        "SELECT id FROM projects WHERE category = 'job_opportunity' AND description LIKE ?",
        (f"%app_id:{app_id}%",)
    ).fetchone()
    if existing:
        db.close()
        return {"project_id": existing[0], "already_existed": True}

    company = app.get("company", "Unknown")
    role = app.get("role", "Unknown Role")
    now = datetime.utcnow().isoformat()

    # Create the project
    cur = db.execute(
        """INSERT INTO projects (name, description, status, priority, category, created_at, updated_at)
           VALUES (?, ?, 'active', ?, 'job_opportunity', ?, ?)""",
        (
            f"{company} — {role}",
            f"Promoted from application app_id:{app_id}. Platform: {app.get('platform', 'N/A')}. "
            f"Applied: {app.get('date_applied', 'N/A')}. Portal: {app.get('portal_url', 'N/A')}",
            app.get("priority", "medium"),
            now, now,
        )
    )
    project_id = cur.lastrowid

    # Standard interview pipeline phases and steps
    phases = [
        ("Initial Contact", "Company replied, conversation started", [
            ("Review company reply email", "Read their response, note key details"),
            ("Send acknowledgment/reply", "Professional response within 24h"),
            ("Research company deeply", "Glassdoor, LinkedIn, recent news, tech stack"),
            ("Review job requirements against resume", "Gap analysis, talking points"),
        ]),
        ("Interview Prep", "Preparing for scheduled interview", [
            ("Confirm interview date/time/format", "Calendar block, test video if remote"),
            ("Research interviewers on LinkedIn", "Find common ground, understand their role"),
            ("Prepare STAR stories", "5 relevant scenarios mapped to job requirements"),
            ("Technical prep", "Review relevant tools, frameworks, certifications"),
            ("Prepare questions to ask", "3-5 thoughtful questions showing research"),
        ]),
        ("Interview", "Active interview process", [
            ("Complete interview", "Notes during/after on questions asked"),
            ("Send thank-you email within 24h", "Reference specific conversation points"),
            ("Debrief — what went well, what didn't", "Honest self-assessment for next time"),
        ]),
        ("Follow-up", "Post-interview tracking", [
            ("Follow up if no response in 5 business days", "Polite check-in email"),
            ("Evaluate offer if received", "Salary, benefits, growth, culture fit"),
            ("Negotiate if appropriate", "Research market rates, prepare counter"),
            ("Accept or decline", "Professional response either way"),
        ]),
    ]

    for phase_order, (phase_name, phase_desc, steps) in enumerate(phases, 1):
        phase_cur = db.execute(
            """INSERT INTO project_phases (project_id, name, description, phase_order, status, created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (project_id, phase_name, phase_desc, phase_order,
             "in_progress" if phase_order == 1 else "pending", now, now)
        )
        phase_id = phase_cur.lastrowid
        for step_order, (step_title, step_desc) in enumerate(steps, 1):
            db.execute(
                """INSERT INTO project_steps (phase_id, project_id, title, description, step_order, status, created_at, updated_at)
                   VALUES (?, ?, ?, ?, ?, 'pending', ?, ?)""",
                (phase_id, project_id, step_title, step_desc, step_order, now, now)
            )

    db.commit()

    # Update application status to active_conversation if not already
    apps_db2 = _apps_db()
    apps_db2.execute(
        "UPDATE applications SET status = 'active_conversation', updated_at = ? WHERE id = ?",
        (now, app_id)
    )
    apps_db2.commit()
    apps_db2.close()
    db.close()

    return {"project_id": project_id, "company": company, "role": role, "phases": len(phases)}


@router.post("/applications/{app_id}/promote")
async def promote_application(app_id: int):
    """Manually promote a job application into its own project with interview pipeline."""
    try:
        result = await _promote_application(app_id)
        return {"status": "promoted", **result}
    except ValueError as e:
        return JSONResponse({"error": str(e)}, status_code=404)


@router.get("/applications/{app_id}")
async def get_application(app_id: int):
    """Get a single application by ID."""
    db = _apps_db()
    row = db.execute("SELECT * FROM applications WHERE id = ?", (app_id,)).fetchone()
    db.close()
    if not row:
        return JSONResponse({"error": "Not found"}, status_code=404)
    return dict(row)


# ---------------------------------------------------------------------------
# Project Tracker — full project/phase/step management
# ---------------------------------------------------------------------------

def _projects_db():
    """Return a connection to the consolidated DB with project tables ensured."""
    import sqlite3 as _sql
    db = _sql.connect(str(aibrain_db.DB_PATH))
    db.row_factory = _sql.Row
    db.execute("PRAGMA journal_mode=WAL")
    db.executescript("""
        CREATE TABLE IF NOT EXISTS projects (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT,
            status TEXT DEFAULT 'active',
            priority TEXT DEFAULT 'medium',
            category TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS project_phases (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            description TEXT,
            phase_order INTEGER NOT NULL,
            status TEXT DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (project_id) REFERENCES projects(id)
        );
        CREATE TABLE IF NOT EXISTS project_steps (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            phase_id INTEGER NOT NULL,
            project_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            description TEXT,
            step_order INTEGER NOT NULL,
            status TEXT DEFAULT 'pending',
            blocker TEXT,
            notes TEXT,
            completed_at TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (phase_id) REFERENCES project_phases(id),
            FOREIGN KEY (project_id) REFERENCES projects(id)
        );
    """)
    return db


def _project_with_details(db, project_id):
    """Load a project with all phases and steps nested."""
    proj = db.execute("SELECT * FROM projects WHERE id = ?", (project_id,)).fetchone()
    if not proj:
        return None
    result = dict(proj)
    phases = db.execute(
        "SELECT * FROM project_phases WHERE project_id = ? ORDER BY phase_order",
        (project_id,),
    ).fetchall()
    result["phases"] = []
    total_steps = 0
    completed_steps = 0
    for ph in phases:
        phase_dict = dict(ph)
        steps = db.execute(
            "SELECT * FROM project_steps WHERE phase_id = ? ORDER BY step_order",
            (ph["id"],),
        ).fetchall()
        phase_dict["steps"] = [dict(s) for s in steps]
        total_steps += len(steps)
        completed_steps += sum(1 for s in steps if s["status"] == "completed")
        result["phases"].append(phase_dict)
    result["total_steps"] = total_steps
    result["completed_steps"] = completed_steps
    return result


@router.get("/projects/dashboard")
async def projects_dashboard():
    """Dashboard: summary stats, next actions, blocked items, recent completions."""
    db = _projects_db()
    now = datetime.utcnow()

    # Counts by status
    status_rows = db.execute(
        "SELECT status, COUNT(*) as cnt FROM projects GROUP BY status"
    ).fetchall()
    by_status = {r["status"]: r["cnt"] for r in status_rows}

    # Total steps done today
    today_start = now.replace(hour=0, minute=0, second=0, microsecond=0).isoformat()
    completed_today = db.execute(
        "SELECT COUNT(*) as cnt FROM project_steps WHERE status = 'completed' AND completed_at >= ?",
        (today_start,),
    ).fetchone()["cnt"]

    # Blocked items
    blocked = db.execute(
        """SELECT s.*, p.name as project_name, ph.name as phase_name
           FROM project_steps s
           JOIN projects p ON s.project_id = p.id
           JOIN project_phases ph ON s.phase_id = ph.id
           WHERE s.status = 'blocked' AND p.status = 'active'
           ORDER BY s.updated_at DESC LIMIT 20""",
    ).fetchall()

    # Next actionable step per active project (first incomplete step)
    next_actions = db.execute(
        """SELECT s.*, p.name as project_name, p.priority as project_priority,
                  p.category as project_category, ph.name as phase_name
           FROM project_steps s
           JOIN projects p ON s.project_id = p.id
           JOIN project_phases ph ON s.phase_id = ph.id
           WHERE s.status IN ('pending', 'in_progress') AND p.status = 'active'
           AND s.id = (
               SELECT MIN(s2.id) FROM project_steps s2
               JOIN project_phases ph2 ON s2.phase_id = ph2.id
               WHERE s2.project_id = p.id AND s2.status IN ('pending', 'in_progress')
               ORDER BY ph2.phase_order, s2.step_order LIMIT 1
           )
           ORDER BY
               CASE p.priority WHEN 'critical' THEN 0 WHEN 'high' THEN 1 WHEN 'medium' THEN 2 ELSE 3 END,
               ph.phase_order, s.step_order
           LIMIT 10""",
    ).fetchall()

    # Recently completed (last 24h)
    yesterday = (now - timedelta(hours=24)).isoformat()
    recent = db.execute(
        """SELECT s.*, p.name as project_name, ph.name as phase_name
           FROM project_steps s
           JOIN projects p ON s.project_id = p.id
           JOIN project_phases ph ON s.phase_id = ph.id
           WHERE s.status = 'completed' AND s.completed_at >= ?
           ORDER BY s.completed_at DESC LIMIT 20""",
        (yesterday,),
    ).fetchall()

    db.close()
    return {
        "by_status": by_status,
        "completed_today": completed_today,
        "blocked": [dict(r) for r in blocked],
        "next_actions": [dict(r) for r in next_actions],
        "recent_completions": [dict(r) for r in recent],
    }


@router.get("/projects")
async def list_projects(
    status: Optional[str] = Query(None),
    priority: Optional[str] = Query(None),
    category: Optional[str] = Query(None),
    search: Optional[str] = Query(None),
):
    """List all projects with summary stats."""
    db = _projects_db()
    query = "SELECT * FROM projects WHERE 1=1"
    params = []
    if status:
        query += " AND status = ?"
        params.append(status)
    else:
        # By default, exclude archived projects and job_opportunity category
        query += " AND status != 'archived' AND category != 'job_opportunity'"
    if priority:
        query += " AND priority = ?"
        params.append(priority)
    if category:
        query += " AND category = ?"
        params.append(category)
    if search:
        query += " AND (name LIKE ? OR description LIKE ?)"
        params.extend([f"%{search}%", f"%{search}%"])
    query += " ORDER BY CASE priority WHEN 'critical' THEN 0 WHEN 'high' THEN 1 WHEN 'medium' THEN 2 ELSE 3 END, updated_at DESC"

    rows = db.execute(query, params).fetchall()
    projects = []
    for row in rows:
        p = dict(row)
        # Attach step counts
        stats = db.execute(
            """SELECT COUNT(*) as total,
                      SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed
               FROM project_steps WHERE project_id = ?""",
            (row["id"],),
        ).fetchone()
        p["total_steps"] = stats["total"]
        p["completed_steps"] = stats["completed"] or 0
        # Next step preview
        nxt = db.execute(
            """SELECT s.title, ph.name as phase_name FROM project_steps s
               JOIN project_phases ph ON s.phase_id = ph.id
               WHERE s.project_id = ? AND s.status IN ('pending', 'in_progress')
               ORDER BY ph.phase_order, s.step_order LIMIT 1""",
            (row["id"],),
        ).fetchone()
        p["next_step"] = dict(nxt) if nxt else None
        projects.append(p)
    db.close()
    return {"projects": projects, "total": len(projects)}


@router.post("/projects")
async def create_project(body: dict):
    """Create a new project, optionally with phases and steps."""
    db = _projects_db()
    name = body.get("name")
    if not name:
        db.close()
        return JSONResponse({"error": "name is required"}, status_code=400)

    now = datetime.utcnow().isoformat()
    cur = db.execute(
        "INSERT INTO projects (name, description, status, priority, category, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
        (name, body.get("description", ""), body.get("status", "active"),
         body.get("priority", "medium"), body.get("category", ""), now, now),
    )
    project_id = cur.lastrowid

    # Bulk-create phases and steps if provided
    phases = body.get("phases", [])
    for i, phase in enumerate(phases):
        phase_cur = db.execute(
            "INSERT INTO project_phases (project_id, name, description, phase_order, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (project_id, phase.get("name", f"Phase {i+1}"), phase.get("description", ""),
             i + 1, phase.get("status", "pending"), now, now),
        )
        phase_id = phase_cur.lastrowid
        for j, step in enumerate(phase.get("steps", [])):
            step_title = step if isinstance(step, str) else step.get("title", f"Step {j+1}")
            step_desc = "" if isinstance(step, str) else step.get("description", "")
            step_status = "pending" if isinstance(step, str) else step.get("status", "pending")
            db.execute(
                "INSERT INTO project_steps (phase_id, project_id, title, description, step_order, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (phase_id, project_id, step_title, step_desc, j + 1, step_status, now, now),
            )

    db.commit()
    result = _project_with_details(db, project_id)
    db.close()

    if _notify_callback:
        import asyncio
        asyncio.ensure_future(_notify_callback("project", "created", {"id": project_id, "name": name}))

    return {"status": "created", "project": result}


@router.get("/projects/templates")
async def list_templates():
    """Return pre-built project templates."""
    templates = [
        {
            "id": "web-application",
            "name": "Web Application",
            "category": "product",
            "phases": [
                {"name": "Planning", "steps": ["Define requirements and scope", "Create wireframes/mockups", "Set up project repository", "Choose tech stack", "Define API contracts"]},
                {"name": "Frontend", "steps": ["Set up build tooling", "Build layout and navigation", "Implement core pages/views", "Add forms and validation", "Style and responsive design"]},
                {"name": "Backend", "steps": ["Set up server framework", "Design database schema", "Build API endpoints", "Add authentication", "Write data validation"]},
                {"name": "Testing", "steps": ["Write unit tests", "Integration testing", "End-to-end testing", "Performance testing"]},
                {"name": "Deployment", "steps": ["Set up CI/CD pipeline", "Configure hosting/infrastructure", "Deploy to staging", "Production deploy", "Post-launch monitoring"]},
            ],
        },
        {
            "id": "content-creation",
            "name": "Content Creation",
            "category": "content",
            "phases": [
                {"name": "Research", "steps": ["Identify target audience", "Research topic depth", "Competitive analysis", "Gather source material"]},
                {"name": "Outline", "steps": ["Define key points", "Structure sections", "Draft headlines/hooks", "Review outline"]},
                {"name": "Draft", "steps": ["Write first draft", "Add examples and data", "Create supporting visuals", "Internal review"]},
                {"name": "Edit", "steps": ["Content review and revision", "Proofread for grammar", "Fact-check all claims", "Get external feedback"]},
                {"name": "Publish", "steps": ["Format for platform", "Create promotional assets", "Schedule publication", "Promote across channels", "Monitor engagement"]},
            ],
        },
        {
            "id": "security-assessment",
            "name": "Security Assessment",
            "category": "infrastructure",
            "phases": [
                {"name": "Reconnaissance", "steps": ["Passive information gathering", "DNS enumeration", "Technology fingerprinting", "Social engineering research"]},
                {"name": "Scanning", "steps": ["Port scanning", "Service enumeration", "Vulnerability scanning", "Web application scanning"]},
                {"name": "Exploitation", "steps": ["Vulnerability validation", "Exploit development", "Privilege escalation", "Lateral movement"]},
                {"name": "Reporting", "steps": ["Document all findings", "Risk-rate vulnerabilities", "Create executive summary", "Prepare technical details"]},
                {"name": "Remediation", "steps": ["Prioritize fixes by risk", "Implement patches", "Validate remediation", "Update security policies"]},
            ],
        },
        {
            "id": "job-application",
            "name": "Job Application",
            "category": "job",
            "phases": [
                {"name": "Research", "steps": ["Research the company", "Understand role requirements", "Identify key contacts", "Review company culture"]},
                {"name": "Resume Tailoring", "steps": ["Update resume for role", "Write custom cover letter", "Prepare portfolio/samples", "Get resume reviewed"]},
                {"name": "Apply", "steps": ["Submit application", "Connect on LinkedIn", "Send follow-up email"]},
                {"name": "Follow Up", "steps": ["Week 1 follow-up", "Week 2 check-in", "Track application status"]},
                {"name": "Interview", "steps": ["Research interviewers", "Prepare STAR answers", "Technical prep", "Mock interview", "Send thank-you note"]},
            ],
        },
        {
            "id": "product-launch",
            "name": "Product Launch",
            "category": "product",
            "phases": [
                {"name": "MVP Build", "steps": ["Define core features", "Build minimum viable product", "Internal dogfooding", "Iterate on feedback"]},
                {"name": "Testing", "steps": ["Beta testing with users", "Bug fixes and polish", "Performance optimization", "Security review"]},
                {"name": "Docs", "steps": ["Write user documentation", "Create API reference", "Build getting-started guide", "Record tutorial videos"]},
                {"name": "Marketing", "steps": ["Create landing page", "Write launch announcement", "Prepare social media content", "Set up analytics"]},
                {"name": "Launch", "steps": ["Soft launch to beta users", "Public launch", "Monitor metrics", "Gather user feedback", "Plan next iteration"]},
            ],
        },
    ]
    return {"templates": templates}


@router.get("/projects/steps/all")
async def list_all_steps(status: Optional[str] = Query(None)):
    """Get ALL project steps across all projects, with project/phase names."""
    db = _projects_db()
    query = """
        SELECT ps.*, pp.name as phase_name, p.name as project_name, p.id as project_id
        FROM project_steps ps
        JOIN project_phases pp ON ps.phase_id = pp.id
        JOIN projects p ON pp.project_id = p.id
        WHERE p.status != 'archived'
    """
    params = []
    if status:
        query += " AND ps.status = ?"
        params.append(status)
    query += " ORDER BY CASE ps.status WHEN 'blocked' THEN 0 WHEN 'in_progress' THEN 1 WHEN 'pending' THEN 2 WHEN 'completed' THEN 3 END, p.name, pp.name, ps.id"
    rows = db.execute(query, params).fetchall()
    db.close()
    return {"steps": [dict(r) for r in rows], "total": len(rows)}


@router.get("/projects/{project_id}")
async def get_project(project_id: int):
    """Get a project with all phases and steps."""
    db = _projects_db()
    result = _project_with_details(db, project_id)
    db.close()
    if not result:
        return JSONResponse({"error": "Project not found"}, status_code=404)
    return result


@router.put("/projects/{project_id}")
async def update_project(project_id: int, body: dict):
    """Update project metadata."""
    db = _projects_db()
    allowed = {"name", "description", "status", "priority", "category"}
    fields = []
    params = []
    for key in allowed:
        if key in body:
            fields.append(f"{key} = ?")
            params.append(body[key])
    if not fields:
        db.close()
        return JSONResponse({"error": "No valid fields"}, status_code=400)
    fields.append("updated_at = ?")
    params.append(datetime.utcnow().isoformat())
    params.append(project_id)
    db.execute(f"UPDATE projects SET {', '.join(fields)} WHERE id = ?", params)
    db.commit()
    result = _project_with_details(db, project_id)
    db.close()
    if not result:
        return JSONResponse({"error": "Project not found"}, status_code=404)
    return {"status": "updated", "project": result}


@router.delete("/projects/{project_id}")
async def delete_project(project_id: int):
    """Soft delete — set status to archived."""
    db = _projects_db()
    now = datetime.utcnow().isoformat()
    db.execute("UPDATE projects SET status = 'archived', updated_at = ? WHERE id = ?", (now, project_id))
    db.commit()
    db.close()
    return {"status": "archived", "id": project_id}


@router.post("/projects/{project_id}/phases")
async def add_phase(project_id: int, body: dict):
    """Add a phase to a project."""
    db = _projects_db()
    proj = db.execute("SELECT id FROM projects WHERE id = ?", (project_id,)).fetchone()
    if not proj:
        db.close()
        return JSONResponse({"error": "Project not found"}, status_code=404)

    # Get next phase_order
    max_order = db.execute(
        "SELECT COALESCE(MAX(phase_order), 0) as mx FROM project_phases WHERE project_id = ?",
        (project_id,),
    ).fetchone()["mx"]

    now = datetime.utcnow().isoformat()
    cur = db.execute(
        "INSERT INTO project_phases (project_id, name, description, phase_order, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
        (project_id, body.get("name", "New Phase"), body.get("description", ""),
         body.get("phase_order", max_order + 1), body.get("status", "pending"), now, now),
    )
    phase_id = cur.lastrowid

    # Bulk-create steps if provided
    for j, step in enumerate(body.get("steps", [])):
        step_title = step if isinstance(step, str) else step.get("title", f"Step {j+1}")
        step_desc = "" if isinstance(step, str) else step.get("description", "")
        db.execute(
            "INSERT INTO project_steps (phase_id, project_id, title, description, step_order, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (phase_id, project_id, step_title, step_desc, j + 1, "pending", now, now),
        )

    db.commit()
    db.execute("UPDATE projects SET updated_at = ? WHERE id = ?", (now, project_id))
    db.commit()

    phase = db.execute("SELECT * FROM project_phases WHERE id = ?", (phase_id,)).fetchone()
    steps = db.execute("SELECT * FROM project_steps WHERE phase_id = ? ORDER BY step_order", (phase_id,)).fetchall()
    result = dict(phase)
    result["steps"] = [dict(s) for s in steps]
    db.close()
    return {"status": "created", "phase": result}


@router.put("/projects/phases/{phase_id}")
async def update_phase(phase_id: int, body: dict):
    """Update a phase."""
    db = _projects_db()
    allowed = {"name", "description", "status", "phase_order"}
    fields = []
    params = []
    for key in allowed:
        if key in body:
            fields.append(f"{key} = ?")
            params.append(body[key])
    if not fields:
        db.close()
        return JSONResponse({"error": "No valid fields"}, status_code=400)
    fields.append("updated_at = ?")
    params.append(datetime.utcnow().isoformat())
    params.append(phase_id)
    db.execute(f"UPDATE project_phases SET {', '.join(fields)} WHERE id = ?", params)
    db.commit()
    phase = db.execute("SELECT * FROM project_phases WHERE id = ?", (phase_id,)).fetchone()
    db.close()
    if not phase:
        return JSONResponse({"error": "Phase not found"}, status_code=404)
    return {"status": "updated", "phase": dict(phase)}


@router.post("/projects/phases/{phase_id}/steps")
async def add_step(phase_id: int, body: dict):
    """Add a step to a phase."""
    db = _projects_db()
    phase = db.execute("SELECT * FROM project_phases WHERE id = ?", (phase_id,)).fetchone()
    if not phase:
        db.close()
        return JSONResponse({"error": "Phase not found"}, status_code=404)

    max_order = db.execute(
        "SELECT COALESCE(MAX(step_order), 0) as mx FROM project_steps WHERE phase_id = ?",
        (phase_id,),
    ).fetchone()["mx"]

    now = datetime.utcnow().isoformat()
    cur = db.execute(
        "INSERT INTO project_steps (phase_id, project_id, title, description, step_order, status, blocker, notes, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (phase_id, phase["project_id"], body.get("title", "New Step"),
         body.get("description", ""), body.get("step_order", max_order + 1),
         body.get("status", "pending"), body.get("blocker", ""), body.get("notes", ""), now, now),
    )
    db.commit()
    db.execute("UPDATE projects SET updated_at = ? WHERE id = ?", (now, phase["project_id"]))
    db.commit()
    step = db.execute("SELECT * FROM project_steps WHERE id = ?", (cur.lastrowid,)).fetchone()
    db.close()
    return {"status": "created", "step": dict(step)}


@router.put("/projects/steps/{step_id}")
async def update_step(step_id: int, body: dict):
    """Update a step (status, notes, blocker, etc.)."""
    db = _projects_db()
    allowed = {"title", "description", "status", "step_order", "blocker", "notes"}
    fields = []
    params = []
    for key in allowed:
        if key in body:
            fields.append(f"{key} = ?")
            params.append(body[key])
    if not fields:
        db.close()
        return JSONResponse({"error": "No valid fields"}, status_code=400)

    now = datetime.utcnow().isoformat()
    # Auto-set completed_at
    if body.get("status") == "completed":
        fields.append("completed_at = ?")
        params.append(now)
    elif body.get("status") and body["status"] != "completed":
        fields.append("completed_at = NULL")

    fields.append("updated_at = ?")
    params.append(now)
    params.append(step_id)
    db.execute(f"UPDATE project_steps SET {', '.join(fields)} WHERE id = ?", params)
    db.commit()

    step = db.execute("SELECT * FROM project_steps WHERE id = ?", (step_id,)).fetchone()
    if step:
        db.execute("UPDATE projects SET updated_at = ? WHERE id = ?", (now, step["project_id"]))
        db.commit()

        # Auto-update phase status
        phase_id = step["phase_id"]
        phase_steps = db.execute(
            "SELECT status FROM project_steps WHERE phase_id = ?", (phase_id,)
        ).fetchall()
        statuses = [s["status"] for s in phase_steps]
        if all(s == "completed" for s in statuses):
            db.execute("UPDATE project_phases SET status = 'completed', updated_at = ? WHERE id = ?", (now, phase_id))
        elif any(s in ("in_progress", "completed") for s in statuses):
            db.execute("UPDATE project_phases SET status = 'in_progress', updated_at = ? WHERE id = ?", (now, phase_id))
        db.commit()

    db.close()
    if not step:
        return JSONResponse({"error": "Step not found"}, status_code=404)
    return {"status": "updated", "step": dict(step)}


@router.patch("/projects/steps/{step_id}")
async def update_step(step_id: int, body: dict):
    """Update a step's status, notes, or other fields."""
    db = _projects_db()
    step = db.execute("SELECT * FROM project_steps WHERE id = ?", (step_id,)).fetchone()
    if not step:
        db.close()
        return JSONResponse({"error": "Step not found"}, status_code=404)

    now = datetime.utcnow().isoformat()
    updates = []
    params = []

    for field in ("status", "notes", "title", "blocker"):
        if field in body:
            updates.append(f"{field} = ?")
            params.append(body[field])

    if body.get("status") == "completed":
        updates.append("completed_at = ?")
        params.append(now)
    elif body.get("status") in ("pending", "in_progress", "blocked"):
        updates.append("completed_at = NULL")

    if not updates:
        db.close()
        return {"status": "no_changes"}

    updates.append("updated_at = ?")
    params.append(now)
    params.append(step_id)

    db.execute(f"UPDATE project_steps SET {', '.join(updates)} WHERE id = ?", params)
    db.commit()
    db.close()
    return {"status": "updated", "step_id": step_id}


@router.delete("/projects/steps/{step_id}")
async def delete_step(step_id: int):
    """Delete a project step."""
    db = _projects_db()
    step = db.execute("SELECT id FROM project_steps WHERE id = ?", (step_id,)).fetchone()
    if not step:
        db.close()
        return JSONResponse({"error": "Step not found"}, status_code=404)

    db.execute("DELETE FROM project_steps WHERE id = ?", (step_id,))
    # Clean up entity_links
    db.execute("DELETE FROM entity_links WHERE (source_type = 'project_step' AND source_id = ?) OR (target_type = 'project_step' AND target_id = ?)", (step_id, step_id))
    db.commit()
    db.close()
    return {"status": "deleted", "step_id": step_id}


@router.patch("/projects/steps/{step_id}/toggle")
async def toggle_step(step_id: int):
    """Quick toggle step between completed and pending."""
    db = _projects_db()
    step = db.execute("SELECT * FROM project_steps WHERE id = ?", (step_id,)).fetchone()
    if not step:
        db.close()
        return JSONResponse({"error": "Step not found"}, status_code=404)

    now = datetime.utcnow().isoformat()
    new_status = "pending" if step["status"] == "completed" else "completed"
    completed_at = now if new_status == "completed" else None

    db.execute(
        "UPDATE project_steps SET status = ?, completed_at = ?, updated_at = ? WHERE id = ?",
        (new_status, completed_at, now, step_id),
    )
    db.commit()

    # Auto-update phase status
    phase_steps = db.execute(
        "SELECT status FROM project_steps WHERE phase_id = ?", (step["phase_id"],)
    ).fetchall()
    statuses = [s["status"] for s in phase_steps]
    if all(s == "completed" for s in statuses):
        db.execute("UPDATE project_phases SET status = 'completed', updated_at = ? WHERE id = ?", (now, step["phase_id"]))
    elif any(s in ("in_progress", "completed") for s in statuses):
        db.execute("UPDATE project_phases SET status = 'in_progress', updated_at = ? WHERE id = ?", (now, step["phase_id"]))
    else:
        db.execute("UPDATE project_phases SET status = 'pending', updated_at = ? WHERE id = ?", (now, step["phase_id"]))
    db.commit()

    db.execute("UPDATE projects SET updated_at = ? WHERE id = ?", (now, step["project_id"]))
    db.commit()
    db.close()

    return {"status": "toggled", "step_id": step_id, "new_status": new_status}


@router.post("/projects/{project_id}/import")
async def import_project_template(project_id: int, body: dict):
    """Import phases/steps from a markdown or JSON template into an existing project."""
    db = _projects_db()
    proj = db.execute("SELECT id FROM projects WHERE id = ?", (project_id,)).fetchone()
    if not proj:
        db.close()
        return JSONResponse({"error": "Project not found"}, status_code=404)

    now = datetime.utcnow().isoformat()
    phases = body.get("phases", [])
    max_order = db.execute(
        "SELECT COALESCE(MAX(phase_order), 0) as mx FROM project_phases WHERE project_id = ?",
        (project_id,),
    ).fetchone()["mx"]

    created_phases = 0
    created_steps = 0
    for i, phase in enumerate(phases):
        phase_cur = db.execute(
            "INSERT INTO project_phases (project_id, name, description, phase_order, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (project_id, phase.get("name", f"Phase {i+1}"), phase.get("description", ""),
             max_order + i + 1, "pending", now, now),
        )
        created_phases += 1
        phase_id = phase_cur.lastrowid
        for j, step in enumerate(phase.get("steps", [])):
            step_title = step if isinstance(step, str) else step.get("title", f"Step {j+1}")
            step_desc = "" if isinstance(step, str) else step.get("description", "")
            db.execute(
                "INSERT INTO project_steps (phase_id, project_id, title, description, step_order, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (phase_id, project_id, step_title, step_desc, j + 1, "pending", now, now),
            )
            created_steps += 1

    db.commit()
    db.execute("UPDATE projects SET updated_at = ? WHERE id = ?", (now, project_id))
    db.commit()
    result = _project_with_details(db, project_id)
    db.close()
    return {"status": "imported", "created_phases": created_phases, "created_steps": created_steps, "project": result}


@router.post("/projects/seed")
async def seed_projects_from_action_plan():
    """Import projects from project_action_plan.md. Only runs if no projects exist."""
    db = _projects_db()
    count = db.execute("SELECT COUNT(*) as cnt FROM projects").fetchone()["cnt"]
    if count > 0:
        db.close()
        return {"status": "skipped", "message": f"Already have {count} projects"}

    now = datetime.utcnow().isoformat()

    # Example seed projects — users can customize these
    seed_projects = [
        {
            "name": "AIBrain Setup",
            "description": "Get your brain configured, workflows enabled, and integrations connected",
            "status": "active",
            "priority": "critical",
            "category": "product",
            "phases": [
                {"name": "Phase 1 — Core Setup", "status": "in_progress", "steps": [
                    {"title": "Run setup wizard and configure API keys", "status": "pending"},
                    {"title": "Enable desired workflows", "status": "pending"},
                    {"title": "Connect email integration (optional)", "status": "pending"},
                    {"title": "Connect Telegram notifications (optional)", "status": "pending"},
                ]},
                {"name": "Phase 2 — Brain Training", "steps": [
                    {"title": "Import existing knowledge (brain import)", "status": "pending"},
                    {"title": "Install brain packs for your domains", "status": "pending"},
                    {"title": "Verify memory consolidation is running", "status": "pending"},
                ]},
            ],
        },
        {
            "name": "Workflow Automation",
            "description": "Set up automated workflows for your daily needs",
            "status": "active",
            "priority": "medium",
            "category": "product",
            "phases": [
                {"name": "Productivity", "steps": [
                    {"title": "Configure morning briefing schedule", "status": "pending"},
                    {"title": "Set up email-to-task workflow", "status": "pending"},
                    {"title": "Enable daily planner", "status": "pending"},
                ]},
                {"name": "Monitoring", "steps": [
                    {"title": "Enable cron health checks", "status": "pending"},
                    {"title": "Set up database backups", "status": "pending"},
                ]},
            ],
        },
    ]

    for p in seed_projects:
        cur = db.execute(
            "INSERT INTO projects (name, description, status, priority, category, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (p["name"], p.get("description", ""), p.get("status", "active"),
             p.get("priority", "medium"), p.get("category", ""), now, now),
        )
        pid = cur.lastrowid
        for i, phase in enumerate(p.get("phases", [])):
            pcur = db.execute(
                "INSERT INTO project_phases (project_id, name, description, phase_order, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (pid, phase["name"], phase.get("description", ""), i + 1,
                 phase.get("status", "pending"), now, now),
            )
            phid = pcur.lastrowid
            for j, step in enumerate(phase.get("steps", [])):
                st = step if isinstance(step, str) else step.get("title", "")
                ss = "pending" if isinstance(step, str) else step.get("status", "pending")
                db.execute(
                    "INSERT INTO project_steps (phase_id, project_id, title, description, step_order, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    (phid, pid, st, "", j + 1, ss, now, now),
                )

    db.commit()
    total_projects = db.execute("SELECT COUNT(*) as cnt FROM projects").fetchone()["cnt"]
    total_steps = db.execute("SELECT COUNT(*) as cnt FROM project_steps").fetchone()["cnt"]
    db.close()
    return {"status": "seeded", "projects": total_projects, "steps": total_steps}


# ---------------------------------------------------------------------------
# Entity Links — universal relationship graph (Agent Mind architecture)
# Connects projects, workflows, tasks, memories, skills, agents, integrations
# ---------------------------------------------------------------------------

VALID_ENTITY_TYPES = {"project", "workflow", "task", "memory", "skill", "agent", "integration", "approval"}
VALID_RELATIONSHIPS = {"contains", "uses", "generates", "belongs_to", "relates_to", "depends_on", "triggers", "owned_by"}


@router.get("/links")
async def get_entity_links(
    source_type: Optional[str] = Query(None),
    source_id: Optional[int] = Query(None),
    target_type: Optional[str] = Query(None),
    target_id: Optional[int] = Query(None),
    relationship: Optional[str] = Query(None),
    entity_type: Optional[str] = Query(None, description="Get all links for this entity type+id"),
    entity_id: Optional[int] = Query(None),
):
    """Query entity links. Use entity_type+entity_id to get all links for an entity (both directions)."""
    db = _projects_db()

    if entity_type and entity_id:
        # Get all links where this entity is source OR target
        rows = db.execute(
            """SELECT * FROM entity_links
               WHERE (source_type = ? AND source_id = ?) OR (target_type = ? AND target_id = ?)
               ORDER BY relationship, created_at DESC""",
            (entity_type, entity_id, entity_type, entity_id),
        ).fetchall()
    else:
        query = "SELECT * FROM entity_links WHERE 1=1"
        params = []
        if source_type:
            query += " AND source_type = ?"
            params.append(source_type)
        if source_id is not None:
            query += " AND source_id = ?"
            params.append(source_id)
        if target_type:
            query += " AND target_type = ?"
            params.append(target_type)
        if target_id is not None:
            query += " AND target_id = ?"
            params.append(target_id)
        if relationship:
            query += " AND relationship = ?"
            params.append(relationship)
        query += " ORDER BY created_at DESC LIMIT 500"
        rows = db.execute(query, params).fetchall()

    links = [dict(r) for r in rows]
    db.close()
    return {"links": links, "count": len(links)}


@router.post("/links")
async def create_entity_link(body: dict):
    """Create a link between two entities."""
    source_type = body.get("source_type", "")
    source_id = body.get("source_id")
    target_type = body.get("target_type", "")
    target_id = body.get("target_id")
    relationship = body.get("relationship", "relates_to")

    if source_type not in VALID_ENTITY_TYPES or target_type not in VALID_ENTITY_TYPES:
        return JSONResponse({"error": f"Invalid entity type. Valid: {sorted(VALID_ENTITY_TYPES)}"}, status_code=400)
    if relationship not in VALID_RELATIONSHIPS:
        return JSONResponse({"error": f"Invalid relationship. Valid: {sorted(VALID_RELATIONSHIPS)}"}, status_code=400)
    if source_id is None or target_id is None:
        return JSONResponse({"error": "source_id and target_id required"}, status_code=400)

    db = _projects_db()
    try:
        db.execute(
            """INSERT OR IGNORE INTO entity_links (source_type, source_id, target_type, target_id, relationship, metadata)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (source_type, source_id, target_type, target_id, relationship, body.get("metadata")),
        )
        db.commit()
    except Exception as e:
        db.close()
        logger.error("Entity link creation failed: %s", e, exc_info=True)
        return JSONResponse({"error": "Internal server error"}, status_code=500)
    db.close()
    return {"status": "created"}


@router.delete("/links/{link_id}")
async def delete_entity_link(link_id: int):
    """Remove a link."""
    db = _projects_db()
    db.execute("DELETE FROM entity_links WHERE id = ?", (link_id,))
    db.commit()
    db.close()
    return {"status": "deleted"}


@router.get("/links/graph")
async def entity_link_graph(
    center_type: Optional[str] = Query(None),
    center_id: Optional[int] = Query(None),
    depth: int = Query(1, ge=1, le=3),
):
    """Get a graph of connected entities, optionally centered on one entity.
    Returns nodes and edges for visualization."""
    db = _projects_db()

    if center_type and center_id is not None:
        # BFS from center entity
        visited = set()
        queue = [(center_type, center_id, 0)]
        edges = []
        while queue:
            etype, eid, d = queue.pop(0)
            key = (etype, eid)
            if key in visited:
                continue
            visited.add(key)
            if d >= depth:
                continue
            rows = db.execute(
                """SELECT * FROM entity_links
                   WHERE (source_type = ? AND source_id = ?) OR (target_type = ? AND target_id = ?)""",
                (etype, eid, etype, eid),
            ).fetchall()
            for r in rows:
                edge = dict(r)
                edges.append(edge)
                # Queue the other end
                if (r["source_type"], r["source_id"]) == key:  # noqa:PLAIN SECRET COMPARISON — tuple comparison, not secret
                    queue.append((r["target_type"], r["target_id"], d + 1))
                else:
                    queue.append((r["source_type"], r["source_id"], d + 1))
    else:
        # All links (limited)
        rows = db.execute("SELECT * FROM entity_links LIMIT 1000").fetchall()
        edges = [dict(r) for r in rows]
        visited = set()
        for e in edges:
            visited.add((e["source_type"], e["source_id"]))
            visited.add((e["target_type"], e["target_id"]))

    # Build nodes with names
    nodes = []
    for etype, eid in visited:
        name = _resolve_entity_name(db, etype, eid)
        nodes.append({"type": etype, "id": eid, "name": name})

    db.close()

    # Dedupe edges
    seen_edges = set()
    unique_edges = []
    for e in edges:
        key = (e["source_type"], e["source_id"], e["target_type"], e["target_id"], e["relationship"])
        if key not in seen_edges:
            seen_edges.add(key)
            unique_edges.append(e)

    return {"nodes": nodes, "edges": unique_edges}


def _resolve_entity_name(db, entity_type, entity_id):
    """Look up a human-readable name for an entity."""
    table_map = {
        "project": ("projects", "name"),
        "workflow": ("project_phases", "name"),
        "task": ("project_steps", "title"),
        "memory": ("memories", "name"),
        "skill": ("skills", "name"),
        "approval": ("approvals", "title"),
    }
    if entity_type in table_map:
        table, col = table_map[entity_type]
        row = db.execute(f"SELECT {col} FROM {table} WHERE id = ?", (entity_id,)).fetchone()
        if row:
            return row[0]
    return f"{entity_type}:{entity_id}"


@router.get("/links/context/{entity_type}/{entity_id}")
async def get_entity_context(entity_type: str, entity_id: int):
    """Get full context for an entity — all its connections grouped by type and relationship.
    This is the 'drill-down' view: what project does this task belong to? What workflows use this skill?"""
    db = _projects_db()

    rows = db.execute(
        """SELECT * FROM entity_links
           WHERE (source_type = ? AND source_id = ?) OR (target_type = ? AND target_id = ?)
           ORDER BY relationship""",
        (entity_type, entity_id, entity_type, entity_id),
    ).fetchall()

    # Group connections
    connections = {}
    for r in rows:
        if r["source_type"] == entity_type and r["source_id"] == entity_id:
            # This entity is the source
            other_type = r["target_type"]
            other_id = r["target_id"]
            rel = r["relationship"]
        else:
            # This entity is the target — reverse the relationship
            other_type = r["source_type"]
            other_id = r["source_id"]
            rel = _reverse_relationship(r["relationship"])

        name = _resolve_entity_name(db, other_type, other_id)
        key = f"{rel}:{other_type}"
        if key not in connections:
            connections[key] = {"relationship": rel, "entity_type": other_type, "items": []}
        connections[key]["items"].append({"id": other_id, "name": name})

    # Also get self info
    self_name = _resolve_entity_name(db, entity_type, entity_id)
    db.close()

    return {
        "entity": {"type": entity_type, "id": entity_id, "name": self_name},
        "connections": list(connections.values()),
        "total_links": len(rows),
    }


def _reverse_relationship(rel):
    """Reverse a relationship for when traversing from target to source."""
    reverses = {
        "contains": "part_of",
        "uses": "used_by",
        "generates": "generated_by",
        "belongs_to": "owns",
        "triggers": "triggered_by",
        "owned_by": "owns",
        "depends_on": "depended_on_by",
    }
    return reverses.get(rel, rel)


# ---------------------------------------------------------------------------
# Evolution Engine — M2.7-inspired self-improvement loop
# ---------------------------------------------------------------------------

@router.get("/evolution/dashboard")
async def evolution_dashboard():
    """Get evolution system overview — patterns, experiments, success trends."""
    return evolution_engine.get_evolution_dashboard(aibrain_db.DB_PATH)


@router.post("/evolution/cycle")
async def run_evolution_cycle(body: dict = None):
    """Run a full evolution cycle: analyze → detect → hypothesize → decide."""
    body = body or {}
    agent = body.get("agent", os.getenv("AGENT_ID", "agent"))
    result = evolution_engine.run_evolution_cycle(aibrain_db.DB_PATH, agent=agent)
    return {"status": "cycle_complete", **result}


@router.post("/evolution/outcomes")
async def record_evolution_outcome(body: dict):
    """Record an action outcome for evolution tracking."""
    required = ["source", "action", "result"]
    for field in required:
        if field not in body:
            return JSONResponse({"error": f"Missing required field: {field}"}, status_code=400)
    if body["result"] not in ("success", "failure", "partial"):
        return JSONResponse({"error": "result must be success/failure/partial"}, status_code=400)

    outcome_id = evolution_engine.record_outcome(
        aibrain_db.DB_PATH,
        source=body["source"],
        action=body["action"],
        result=body["result"],
        source_id=body.get("source_id"),
        details=body.get("details"),
        failure_reason=body.get("failure_reason"),
        duration_seconds=body.get("duration_seconds"),
    )
    return {"status": "recorded", "outcome_id": outcome_id}


@router.get("/evolution/outcomes")
async def list_evolution_outcomes(
    source: Optional[str] = Query(None),
    result: Optional[str] = Query(None),
    hours: int = Query(24),
    limit: int = Query(50),
):
    """List recent evolution outcomes."""
    db = evolution_engine.get_evolution_db(aibrain_db.DB_PATH)
    cutoff = (datetime.utcnow() - timedelta(hours=hours)).isoformat()
    where = ["created_at > ?"]
    params = [cutoff]
    if source:
        where.append("source = ?")
        params.append(source)
    if result:
        where.append("result = ?")
        params.append(result)
    safe_limit = min(max(1, limit), 200)
    params.append(safe_limit)
    rows = db.execute(
        f"SELECT * FROM evolution_outcomes WHERE {' AND '.join(where)} ORDER BY created_at DESC LIMIT ?",
        params
    ).fetchall()
    db.close()
    return {"outcomes": [dict(r) for r in rows]}


@router.get("/evolution/patterns")
async def list_evolution_patterns(status: str = Query("active")):
    """List detected failure patterns."""
    db = evolution_engine.get_evolution_db(aibrain_db.DB_PATH)
    rows = db.execute(
        "SELECT * FROM evolution_patterns WHERE status = ? ORDER BY frequency DESC, severity DESC",
        (status,)
    ).fetchall()
    db.close()
    return {"patterns": [dict(r) for r in rows]}


@router.post("/evolution/hypotheses")
async def create_evolution_hypothesis(body: dict):
    """Propose an improvement hypothesis."""
    required = ["hypothesis", "change_type"]
    for field in required:
        if field not in body:
            return JSONResponse({"error": f"Missing required field: {field}"}, status_code=400)

    hyp_id = evolution_engine.propose_hypothesis(
        aibrain_db.DB_PATH,
        pattern_id=body.get("pattern_id"),
        hypothesis=body["hypothesis"],
        change_type=body["change_type"],
        target=body.get("target"),
        proposed_change=body.get("proposed_change"),
        impact_score=body.get("impact_score", 0.5),
        confidence=body.get("confidence", 0.5),
    )
    return {"status": "proposed", "hypothesis_id": hyp_id}


@router.get("/evolution/hypotheses")
async def list_evolution_hypotheses(status: str = Query("proposed"), limit: int = Query(10)):
    """List hypotheses, sorted by priority."""
    if status == "top":
        return {"hypotheses": evolution_engine.get_top_hypotheses(aibrain_db.DB_PATH, limit=limit)}
    db = evolution_engine.get_evolution_db(aibrain_db.DB_PATH)
    safe_limit = min(max(1, limit), 50)
    rows = db.execute(
        """SELECT h.*, p.pattern, p.frequency
           FROM evolution_hypotheses h
           LEFT JOIN evolution_patterns p ON h.pattern_id = p.id
           WHERE h.status = ?
           ORDER BY h.priority DESC LIMIT ?""",
        (status, safe_limit)
    ).fetchall()
    db.close()
    return {"hypotheses": [dict(r) for r in rows]}


@router.post("/evolution/experiments")
async def start_evolution_experiment(body: dict):
    """Start an experiment for a hypothesis."""
    hypothesis_id = body.get("hypothesis_id")
    if not hypothesis_id:
        return JSONResponse({"error": "hypothesis_id required"}, status_code=400)

    exp_id = evolution_engine.start_experiment(
        aibrain_db.DB_PATH,
        hypothesis_id=hypothesis_id,
        baseline_metrics=body.get("baseline_metrics", {}),
        runs_target=body.get("runs_target", 5),
    )
    return {"status": "started", "experiment_id": exp_id}


@router.post("/evolution/experiments/{exp_id}/run")
async def record_experiment_run(exp_id: int):
    """Record a completed run for an experiment."""
    result = evolution_engine.record_experiment_run(aibrain_db.DB_PATH, exp_id)
    if not result:
        return JSONResponse({"error": "Experiment not found"}, status_code=404)
    return result


@router.post("/evolution/experiments/{exp_id}/decide")
async def decide_evolution_experiment(exp_id: int, body: dict):
    """Decide whether to keep or revert an experiment."""
    decision = body.get("decision")
    if decision not in ("keep", "revert", "extend"):
        return JSONResponse({"error": "decision must be keep/revert/extend"}, status_code=400)

    result = evolution_engine.decide_experiment(
        aibrain_db.DB_PATH,
        experiment_id=exp_id,
        experiment_metrics=body.get("experiment_metrics", {}),
        decision=decision,
        reason=body.get("reason"),
    )
    return result


@router.get("/evolution/experiments")
async def list_evolution_experiments(active_only: bool = Query(True)):
    """List experiments."""
    db = evolution_engine.get_evolution_db(aibrain_db.DB_PATH)
    if active_only:
        rows = db.execute(
            """SELECT e.*, h.hypothesis, h.change_type, h.target
               FROM evolution_experiments e
               JOIN evolution_hypotheses h ON e.hypothesis_id = h.id
               WHERE e.decision IS NULL
               ORDER BY e.started_at DESC"""
        ).fetchall()
    else:
        rows = db.execute(
            """SELECT e.*, h.hypothesis, h.change_type, h.target
               FROM evolution_experiments e
               JOIN evolution_hypotheses h ON e.hypothesis_id = h.id
               ORDER BY e.started_at DESC LIMIT 50"""
        ).fetchall()
    db.close()
    return {"experiments": [dict(r) for r in rows]}


# --- Self-Criticism endpoints ---

@router.post("/evolution/critiques")
async def create_evolution_critique(body: dict):
    """Record a self-criticism entry."""
    required = ["scope", "subject", "observation", "criticism"]
    for field in required:
        if field not in body:
            return JSONResponse({"error": f"Missing: {field}"}, status_code=400)
    cid = evolution_engine.record_critique(
        aibrain_db.DB_PATH,
        scope=body["scope"], subject=body["subject"],
        observation=body["observation"], criticism=body["criticism"],
        suggested_fix=body.get("suggested_fix"),
        severity=body.get("severity", "medium"),
        cycle_id=body.get("cycle_id"),
    )
    return {"status": "recorded", "critique_id": cid}


@router.get("/evolution/critiques")
async def list_evolution_critiques(addressed: bool = Query(False), limit: int = Query(20)):
    """List critiques, default unaddressed."""
    if not addressed:
        return {"critiques": evolution_engine.get_unaddressed_critiques(aibrain_db.DB_PATH, limit)}
    db = evolution_engine.get_evolution_db(aibrain_db.DB_PATH)
    rows = db.execute(
        "SELECT * FROM evolution_critiques ORDER BY created_at DESC LIMIT ?",
        (min(limit, 100),)
    ).fetchall()
    db.close()
    return {"critiques": [dict(r) for r in rows]}


@router.patch("/evolution/critiques/{critique_id}/address")
async def address_evolution_critique(critique_id: int, body: dict):
    """Mark a critique as addressed."""
    addressed_by = body.get("addressed_by", "manual")
    evolution_engine.address_critique(aibrain_db.DB_PATH, critique_id, addressed_by)
    return {"status": "addressed", "critique_id": critique_id}


# --- Metric Tracking endpoints ---

@router.post("/evolution/metrics")
async def record_evolution_metric(body: dict):
    """Record a metric data point."""
    if "metric_name" not in body or "metric_value" not in body:
        return JSONResponse({"error": "metric_name and metric_value required"}, status_code=400)
    evolution_engine.record_metric(
        aibrain_db.DB_PATH,
        metric_name=body["metric_name"],
        metric_value=body["metric_value"],
        source=body.get("source"),
        period=body.get("period", "snapshot"),
    )
    return {"status": "recorded"}


@router.get("/evolution/metrics/{metric_name}")
async def get_evolution_metric_trend(metric_name: str, days: int = Query(7)):
    """Get trend data for a specific metric."""
    return {"metric": metric_name, "trend": evolution_engine.get_metric_trend(aibrain_db.DB_PATH, metric_name, days)}


# --- Parameter Search endpoints ---

@router.post("/evolution/parameters")
async def start_parameter_search(body: dict):
    """Start a systematic parameter optimization search."""
    required = ["parameter_name", "system", "current_value", "tested_value"]
    for field in required:
        if field not in body:
            return JSONResponse({"error": f"Missing: {field}"}, status_code=400)
    sid = evolution_engine.start_parameter_search(
        aibrain_db.DB_PATH,
        parameter_name=body["parameter_name"],
        system=body["system"],
        current_value=body["current_value"],
        tested_value=body["tested_value"],
        baseline_result=body.get("baseline_result"),
    )
    return {"status": "started", "search_id": sid}


@router.get("/evolution/parameters")
async def list_parameter_searches(system: Optional[str] = Query(None), active_only: bool = Query(True)):
    """List parameter optimization searches."""
    return {"searches": evolution_engine.get_parameter_searches(aibrain_db.DB_PATH, system, active_only)}


@router.patch("/evolution/parameters/{search_id}")
async def update_parameter_search_endpoint(search_id: int, body: dict):
    """Update a parameter search with test results."""
    if "test_result" not in body:
        return JSONResponse({"error": "test_result required"}, status_code=400)
    evolution_engine.update_parameter_search(
        aibrain_db.DB_PATH, search_id,
        test_result=body["test_result"],
        runs=body.get("runs"),
        decision=body.get("decision"),
    )
    return {"status": "updated"}


# --- Loop Detection endpoint ---

@router.get("/evolution/loops")
async def detect_evolution_loops(window_minutes: int = Query(30), threshold: int = Query(3)):
    """Detect if any actions are stuck in repetition loops."""
    loops = evolution_engine.detect_loops(aibrain_db.DB_PATH, window_minutes, threshold)
    return {"loops": loops, "stuck": len(loops) > 0}


# --- Positive Pattern endpoints ---

@router.get("/evolution/positive-patterns")
async def list_positive_patterns(
    strength: Optional[str] = Query(None),
    scale: Optional[str] = Query(None),
    limit: int = Query(20),
):
    """List positive patterns — what's working and why."""
    return {"patterns": evolution_engine.get_positive_patterns(
        aibrain_db.DB_PATH, strength, scale, limit)}


@router.post("/evolution/positive-patterns")
async def create_positive_pattern(body: dict):
    """Manually record a positive pattern / principle."""
    required = ["pattern", "principle", "source_domain"]
    for f in required:
        if f not in body:
            return JSONResponse({"error": f"Missing: {f}"}, status_code=400)
    pid = evolution_engine.record_positive_pattern(
        aibrain_db.DB_PATH,
        pattern=body["pattern"], principle=body["principle"],
        source_domain=body["source_domain"],
        scale=body.get("scale", "micro"),
        strength=body.get("strength", "emerging"),
    )
    return {"status": "recorded", "pattern_id": pid}


@router.patch("/evolution/positive-patterns/{pattern_id}")
async def update_positive_pattern_endpoint(pattern_id: int, body: dict):
    """Update a positive pattern's principle, scale, or strength."""
    evolution_engine.update_positive_pattern(
        aibrain_db.DB_PATH, pattern_id,
        principle=body.get("principle"),
        scale=body.get("scale"),
        strength=body.get("strength"),
    )
    return {"status": "updated", "pattern_id": pattern_id}


@router.post("/evolution/positive-patterns/detect")
async def detect_positive_patterns_endpoint(body: dict = None):
    """Run positive pattern detection on recent outcomes."""
    body = body or {}
    result = evolution_engine.detect_positive_patterns(
        aibrain_db.DB_PATH, lookback_hours=body.get("lookback_hours", 168))
    return result


# --- Replication endpoints ---

@router.post("/evolution/replications")
async def propose_replication(body: dict):
    """Propose replicating a positive pattern into a new domain."""
    required = ["pattern_id", "target_domain", "adaptation"]
    for f in required:
        if f not in body:
            return JSONResponse({"error": f"Missing: {f}"}, status_code=400)
    rid = evolution_engine.propose_replication(
        aibrain_db.DB_PATH,
        pattern_id=body["pattern_id"],
        target_domain=body["target_domain"],
        adaptation=body["adaptation"],
        target_scale=body.get("target_scale"),
        implementation=body.get("implementation"),
    )
    return {"status": "proposed", "replication_id": rid}


@router.get("/evolution/replications")
async def list_replications(
    pattern_id: Optional[int] = Query(None),
    status: Optional[str] = Query(None),
    limit: int = Query(20),
):
    """List pattern replications."""
    return {"replications": evolution_engine.get_replications(
        aibrain_db.DB_PATH, pattern_id, status, limit)}


@router.patch("/evolution/replications/{replication_id}")
async def update_replication_endpoint(replication_id: int, body: dict):
    """Update a replication's status and results."""
    evolution_engine.update_replication(
        aibrain_db.DB_PATH, replication_id,
        status=body.get("status"),
        implementation=body.get("implementation"),
        outcome_before=body.get("outcome_before"),
        outcome_after=body.get("outcome_after"),
    )
    return {"status": "updated", "replication_id": replication_id}


# --- Feedback Loop endpoints ---

@router.post("/evolution/feedback-loops")
async def create_feedback_loop(body: dict):
    """Register an explicit feedback loop in the system."""
    required = ["name", "loop_type", "description", "components"]
    for f in required:
        if f not in body:
            return JSONResponse({"error": f"Missing: {f}"}, status_code=400)
    lid = evolution_engine.create_feedback_loop(
        aibrain_db.DB_PATH,
        name=body["name"], loop_type=body["loop_type"],
        description=body["description"], components=body["components"],
        trigger=body.get("trigger"), output=body.get("output"),
        input_source=body.get("input_source"),
        scale=body.get("scale", "micro"),
    )
    return {"status": "created", "loop_id": lid}


@router.get("/evolution/feedback-loops")
async def list_feedback_loops(
    loop_type: Optional[str] = Query(None),
    status: str = Query("active"),
    scale: Optional[str] = Query(None),
):
    """List feedback loops, optionally filtered."""
    return {"loops": evolution_engine.get_feedback_loops(
        aibrain_db.DB_PATH, loop_type, status, scale)}


@router.post("/evolution/feedback-loops/{loop_id}/trigger")
async def trigger_loop(loop_id: int):
    """Record that a feedback loop completed a cycle."""
    evolution_engine.trigger_feedback_loop(aibrain_db.DB_PATH, loop_id)
    return {"status": "triggered", "loop_id": loop_id}


@router.patch("/evolution/feedback-loops/{loop_id}")
async def update_loop(loop_id: int, body: dict):
    """Update a feedback loop."""
    evolution_engine.update_feedback_loop(
        aibrain_db.DB_PATH, loop_id,
        status=body.get("status"),
        strength=body.get("strength"),
        description=body.get("description"),
        components=body.get("components"),
    )
    return {"status": "updated", "loop_id": loop_id}


# --- Cross-Scale Analysis endpoint ---

@router.get("/evolution/cross-scale")
async def cross_scale_analysis():
    """Find patterns that exist at one scale but haven't been applied at others.
    The micro/macro perspective engine."""
    return evolution_engine.analyze_cross_scale(aibrain_db.DB_PATH)


# ---------------------------------------------------------------------------
# Agent Actions — drive next steps from projects/applications
# ---------------------------------------------------------------------------

@router.get("/applications/{app_id}/actions")
async def get_application_actions(app_id: int):
    """Get available agent actions for a job application.
    Returns action buttons the UI can render: reply, follow-up, research, etc."""
    db = _apps_db()
    row = db.execute("SELECT * FROM applications WHERE id = ?", (app_id,)).fetchone()
    db.close()
    if not row:
        return JSONResponse({"error": "Not found"}, status_code=404)
    app = dict(row)

    actions = []
    status = app.get("status", "applied")

    # Always available
    actions.append({
        "id": "research_company",
        "label": "Research Company",
        "description": f"Deep research {app['company']}: Glassdoor, LinkedIn, tech stack, news",
        "type": "agent_task",
        "requires_approval": False,
    })

    # Status-dependent actions
    if status in ("applied", "under-review", "viewed"):
        actions.append({
            "id": "check_for_reply",
            "label": "Check for Reply",
            "description": f"Scan inbox for emails from {app['company']}",
            "type": "agent_task",
            "requires_approval": False,
        })
        actions.append({
            "id": "follow_up",
            "label": "Send Follow-up",
            "description": f"Draft a follow-up email to {app['company']} about {app['role']}",
            "type": "email_draft",
            "requires_approval": True,
        })

    if status in ("replied", "active_conversation"):
        actions.append({
            "id": "reply_to_email",
            "label": "Reply to Email",
            "description": f"Draft reply to {app['company']}'s latest email",
            "type": "email_draft",
            "requires_approval": True,
        })
        actions.append({
            "id": "schedule_interview",
            "label": "Schedule Interview",
            "description": "Parse their email for interview details and confirm",
            "type": "agent_task",
            "requires_approval": True,
        })

    if status == "interview_scheduled":
        actions.append({
            "id": "interview_prep",
            "label": "Interview Prep",
            "description": f"Research {app['company']}, prepare STAR stories, draft questions",
            "type": "agent_task",
            "requires_approval": False,
        })

    if app.get("portal_url"):
        actions.append({
            "id": "check_portal",
            "label": "Check Portal",
            "description": f"Login to {app.get('platform', 'portal')} and check application status",
            "type": "browser_task",
            "requires_approval": False,
            "portal_url": app["portal_url"],
        })

    # Promote to project (if not already)
    proj_db = _projects_db()
    existing_project = proj_db.execute(
        "SELECT id FROM projects WHERE category = 'job_opportunity' AND description LIKE ?",
        (f"%app_id:{app_id}%",)
    ).fetchone()
    proj_db.close()

    if not existing_project:
        actions.append({
            "id": "promote_to_project",
            "label": "Promote to Project",
            "description": "Create a dedicated project with interview pipeline tracking",
            "type": "system_action",
            "requires_approval": False,
        })

    return {
        "application": app,
        "actions": actions,
        "project_id": existing_project["id"] if existing_project else None,
    }


@router.post("/applications/{app_id}/actions/{action_id}")
async def execute_application_action(app_id: int, action_id: str, body: dict = None):
    """Execute an agent action on a job application.
    Actions requiring approval go to the approval queue.
    Actions not requiring approval execute immediately."""
    body = body or {}
    db = _apps_db()
    row = db.execute("SELECT * FROM applications WHERE id = ?", (app_id,)).fetchone()
    db.close()
    if not row:
        return JSONResponse({"error": "Application not found"}, status_code=404)
    app = dict(row)

    # Actions that need the approval queue
    approval_actions = {"follow_up", "reply_to_email", "schedule_interview"}

    if action_id == "promote_to_project":
        result = await _promote_application(app_id)
        return {"status": "executed", "action": action_id, "result": result}

    if action_id in approval_actions:
        # Queue for operator approval
        from approval_queue import add_item as _aq_add
        APPROVAL_DB = Path(os.environ.get("AIBRAIN_ROOT", Path(__file__).parent.parent)) / "approval.db"
        item_id = _aq_add(
            APPROVAL_DB,
            category="job_action",
            title=f"{action_id.replace('_', ' ').title()}: {app['company']} — {app['role']}",
            detail=body.get("detail", f"Agent action for {app['company']}"),
            payload={
                "action": action_id,
                "app_id": app_id,
                "company": app["company"],
                "role": app["role"],
                "mode": body.get("mode", "approval"),  # 'approval' or 'autonomous'
                "context": body.get("context", ""),
            },
        )
        return {
            "status": "queued_for_approval",
            "action": action_id,
            "approval_id": item_id,
            "message": f"Action queued. Waiting for operator approval.",
        }

    # Non-approval actions — return task spec for the agent to execute
    return {
        "status": "ready",
        "action": action_id,
        "task": {
            "type": action_id,
            "company": app["company"],
            "role": app["role"],
            "portal_url": app.get("portal_url"),
            "platform": app.get("platform"),
            "notes": app.get("notes"),
        },
        "message": f"Task spec ready for agent execution.",
    }


@router.get("/projects/{project_id}/actions")
async def get_project_actions(project_id: int):
    """Get available agent actions for a project.
    Determines next step and offers action buttons."""
    db = _projects_db()
    project = db.execute("SELECT * FROM projects WHERE id = ?", (project_id,)).fetchone()
    if not project:
        db.close()
        return JSONResponse({"error": "Not found"}, status_code=404)
    project = dict(project)

    # Find next pending step
    next_step = db.execute(
        """SELECT s.*, p.name as phase_name
           FROM project_steps s
           JOIN project_phases p ON s.phase_id = p.id
           WHERE s.project_id = ? AND s.status = 'pending'
           ORDER BY p.phase_order ASC, s.step_order ASC
           LIMIT 1""",
        (project_id,)
    ).fetchone()

    # Find in-progress steps
    in_progress = db.execute(
        """SELECT s.*, p.name as phase_name
           FROM project_steps s
           JOIN project_phases p ON s.phase_id = p.id
           WHERE s.project_id = ? AND s.status = 'in_progress'
           ORDER BY p.phase_order ASC, s.step_order ASC""",
        (project_id,)
    ).fetchall()

    # Count completed vs total
    stats = db.execute(
        """SELECT
             COUNT(*) as total,
             SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
             SUM(CASE WHEN status = 'blocked' THEN 1 ELSE 0 END) as blocked
           FROM project_steps WHERE project_id = ?""",
        (project_id,)
    ).fetchone()
    db.close()

    actions = []

    # Next step action
    if next_step:
        step = dict(next_step)
        actions.append({
            "id": "execute_next_step",
            "label": f"Do: {step['title']}",
            "description": step.get("description", ""),
            "phase": step["phase_name"],
            "step_id": step["id"],
            "type": "agent_task",
            "requires_approval": _step_needs_approval(step["title"]),
        })

    # Autonomous mode
    actions.append({
        "id": "go_autonomous",
        "label": "Go Autonomous",
        "description": "Agent works through all steps until hitting a blocker or needing human input",
        "type": "autonomous_mode",
        "requires_approval": True,  # Must approve entering autonomous mode
    })

    # If job_opportunity project, add email actions
    if project.get("category") == "job_opportunity":
        desc = project.get("description", "")
        actions.append({
            "id": "reply_to_latest",
            "label": "Reply to Latest Email",
            "description": "Draft reply to the most recent email in this conversation",
            "type": "email_draft",
            "requires_approval": True,
        })
        actions.append({
            "id": "check_inbox",
            "label": "Check for New Emails",
            "description": "Scan inbox for new messages related to this opportunity",
            "type": "agent_task",
            "requires_approval": False,
        })

    return {
        "project": project,
        "next_step": dict(next_step) if next_step else None,
        "in_progress": [dict(s) for s in in_progress],
        "progress": {
            "total": stats["total"],
            "completed": stats["completed"],
            "blocked": stats["blocked"],
            "percent": round(stats["completed"] / stats["total"] * 100) if stats["total"] > 0 else 0,
        },
        "actions": actions,
    }


def _step_needs_approval(title: str) -> bool:
    """Determine if a step requires human approval.
    Uses the permissions system first, falls back to keyword detection."""
    # Map step title keywords to action types
    keyword_to_action = {
        "send": "send_email", "reply": "reply_email", "email": "send_email",
        "submit": "browser_submit", "publish": "post_social",
        "accept": "send_email", "decline": "send_email",
        "negotiate": "send_email", "contact": "send_email",
        "schedule": "send_email", "confirm": "send_email",
    }
    title_lower = title.lower()
    for keyword, action_type in keyword_to_action.items():
        if keyword in title_lower:
            # Check permissions system
            result = permissions.check_permission(
                aibrain_db.DB_PATH, action_type=action_type,
                context={"step_title": title}
            )
            if result["decision"] == "allowed":
                return False  # Permission granted, no approval needed
            elif result["decision"] == "denied":
                return True  # Explicitly denied
            else:
                return True  # "queued" = needs approval
    return False  # No matching keywords = no approval needed


@router.post("/projects/{project_id}/actions/{action_id}")
async def execute_project_action(project_id: int, action_id: str, body: dict = None):
    """Execute an agent action on a project."""
    body = body or {}
    db = _projects_db()
    project = db.execute("SELECT * FROM projects WHERE id = ?", (project_id,)).fetchone()
    if not project:
        db.close()
        return JSONResponse({"error": "Not found"}, status_code=404)
    project = dict(project)

    if action_id == "go_autonomous":
        # Queue autonomous mode request for approval
        from approval_queue import add_item as _aq_add
        APPROVAL_DB = Path(os.environ.get("AIBRAIN_ROOT", Path(__file__).parent.parent)) / "approval.db"
        item_id = _aq_add(
            APPROVAL_DB,
            category="autonomous_mode",
            title=f"Autonomous mode: {project['name']}",
            detail=f"Agent will work through remaining steps until hitting a blocker. "
                   f"Project: {project['name']}. Category: {project.get('category', 'N/A')}.",
            payload={
                "action": "go_autonomous",
                "project_id": project_id,
                "project_name": project["name"],
            },
        )
        db.close()
        return {
            "status": "queued_for_approval",
            "action": action_id,
            "approval_id": item_id,
            "message": "Autonomous mode request queued. Waiting for operator approval.",
        }

    if action_id == "execute_next_step":
        step_id = body.get("step_id")
        if not step_id:
            # Find next pending step
            next_step = db.execute(
                """SELECT s.id FROM project_steps s
                   JOIN project_phases p ON s.phase_id = p.id
                   WHERE s.project_id = ? AND s.status = 'pending'
                   ORDER BY p.phase_order ASC, s.step_order ASC LIMIT 1""",
                (project_id,)
            ).fetchone()
            step_id = next_step["id"] if next_step else None
        if not step_id:
            db.close()
            return {"status": "complete", "message": "No more pending steps."}

        step = db.execute("SELECT * FROM project_steps WHERE id = ?", (step_id,)).fetchone()
        if not step:
            db.close()
            return JSONResponse({"error": "Step not found"}, status_code=404)
        step = dict(step)

        if _step_needs_approval(step["title"]):
            from approval_queue import add_item as _aq_add
            APPROVAL_DB = Path(os.environ.get("AIBRAIN_ROOT", Path(__file__).parent.parent)) / "approval.db"
            item_id = _aq_add(
                APPROVAL_DB,
                category="project_step",
                title=f"{step['title']} — {project['name']}",
                detail=step.get("description", ""),
                payload={
                    "action": "execute_step",
                    "project_id": project_id,
                    "step_id": step_id,
                    "step_title": step["title"],
                },
            )
            db.close()
            return {
                "status": "queued_for_approval",
                "action": action_id,
                "step": step,
                "approval_id": item_id,
            }

        # Mark step as in_progress
        db.execute(
            "UPDATE project_steps SET status = 'in_progress', updated_at = ? WHERE id = ?",
            (datetime.utcnow().isoformat(), step_id)
        )
        db.commit()
        db.close()
        return {
            "status": "started",
            "action": action_id,
            "step": step,
            "message": f"Step '{step['title']}' is now in progress.",
        }

    db.close()
    return {"status": "ready", "action": action_id, "project": project}


# ---------------------------------------------------------------------------
# Permissions — Playwright-style allow_once / allow_always / deny / ask
# ---------------------------------------------------------------------------

@router.get("/permissions")
async def list_agent_permissions(
    category: Optional[str] = Query(None),
    action_type: Optional[str] = Query(None),
):
    """List all active permission rules."""
    perms = permissions.list_permissions(aibrain_db.DB_PATH, category, action_type)
    return {"permissions": perms}


@router.get("/permissions/summary")
async def permission_summary():
    """Get permission overview — categories, defaults, recent activity."""
    return permissions.get_permission_summary(aibrain_db.DB_PATH)


@router.get("/permissions/types")
async def list_action_types():
    """List all known action types with their defaults and risk levels."""
    return {"action_types": permissions.ACTION_TYPES}


@router.post("/permissions")
async def set_agent_permission(body: dict):
    """Set a permission rule.
    Body: {action_type, permission, target?, notes?}
    permission: 'allow_always' | 'allow_once' | 'deny' | 'ask'
    """
    action_type = body.get("action_type")
    perm = body.get("permission")
    if not action_type or not perm:
        return JSONResponse({"error": "action_type and permission required"}, status_code=400)
    if perm not in ("allow_always", "allow_once", "deny", "ask"):
        return JSONResponse({"error": "permission must be allow_always/allow_once/deny/ask"}, status_code=400)

    perm_id = permissions.set_permission(
        aibrain_db.DB_PATH,
        action_type=action_type,
        permission=perm,
        target=body.get("target", "*"),
        granted_by=body.get("granted_by", "user"),
        notes=body.get("notes"),
        expires_at=body.get("expires_at"),
    )
    return {"status": "set", "permission_id": perm_id, "action_type": action_type, "permission": perm}


@router.delete("/permissions/{permission_id}")
async def delete_agent_permission(permission_id: int):
    """Delete a permission rule (reverts to default)."""
    permissions.delete_permission(aibrain_db.DB_PATH, permission_id)
    return {"status": "deleted", "permission_id": permission_id}


@router.post("/permissions/check")
async def check_agent_permission(body: dict):
    """Check if an action is permitted without executing it.
    Body: {action_type, target?, context?}"""
    action_type = body.get("action_type")
    if not action_type:
        return JSONResponse({"error": "action_type required"}, status_code=400)
    result = permissions.check_permission(
        aibrain_db.DB_PATH,
        action_type=action_type,
        target=body.get("target", "*"),
        context=body.get("context"),
    )
    return result


@router.get("/permissions/audit")
async def permission_audit_log(
    action_type: Optional[str] = Query(None),
    limit: int = Query(50),
):
    """Get permission audit trail."""
    return {"audit": permissions.get_audit_log(aibrain_db.DB_PATH, action_type, min(limit, 200))}


@router.post("/permissions/bulk")
async def set_bulk_permissions(body: dict):
    """Set multiple permissions at once.
    Body: {permissions: [{action_type, permission, target?, notes?}, ...]}"""
    perms_list = body.get("permissions", [])
    if not perms_list:
        return JSONResponse({"error": "permissions array required"}, status_code=400)
    results = []
    for p in perms_list:
        if not p.get("action_type") or not p.get("permission"):
            continue
        perm_id = permissions.set_permission(
            aibrain_db.DB_PATH,
            action_type=p["action_type"],
            permission=p["permission"],
            target=p.get("target", "*"),
            granted_by=p.get("granted_by", "user"),
            notes=p.get("notes"),
        )
        results.append({"action_type": p["action_type"], "permission_id": perm_id})
    return {"status": "set", "count": len(results), "results": results}


# ============================================================================
# BRAIN SCANNER — Filesystem & Git discovery for onboarding
# ============================================================================

@router.post("/brain/scan")
async def brain_scan(body: dict):
    """Scan directories and/or GitHub repos to discover and link entities.
    Body: {
        directories: ["/path/to/projects", ...],
        github_username: "optional",
        github_token: "optional",
        claude_memory_dir: "optional"
    }"""
    dirs = body.get("directories", [])
    gh_user = body.get("github_username")
    gh_token = body.get("github_token")
    mem_dir = body.get("claude_memory_dir")

    if not dirs and not gh_user:
        return JSONResponse({"error": "Provide directories and/or github_username"}, status_code=400)

    try:
        import brain_scanner
        report = brain_scanner.build_brain_from_filesystem(
            db_path=str(aibrain_db.DB_PATH),
            project_dirs=dirs,
            github_username=gh_user,
            github_token=gh_token,
            claude_memory_dir=mem_dir,
        )
        return {"status": "ok", "report": report}
    except Exception as e:
        logger.error("Brain scan failed: %s", e, exc_info=True)
        return JSONResponse({"error": "Internal server error"}, status_code=500)


def _is_safe_directory(directory: str) -> bool:
    """Validate directory is under user home — prevents path traversal."""
    from pathlib import Path
    try:
        resolved = Path(directory).resolve()
        home = Path.home().resolve()
        return resolved.is_relative_to(home) and resolved.is_dir()
    except (ValueError, OSError):
        return False


@router.post("/brain/scan-directory")
async def brain_scan_single(body: dict):
    """Scan a single directory and return classified files.
    Body: {directory: "/path/to/project", max_depth: 3}"""
    directory = body.get("directory", "")
    if not directory or not _is_safe_directory(directory):
        return JSONResponse({"error": "Access denied or invalid directory"}, status_code=403)

    try:
        import brain_scanner
        result = brain_scanner.scan_directory(
            directory,
            max_depth=body.get("max_depth", 3),
            read_content=body.get("read_content", True),
        )
        return {"status": "ok", "scan": result}
    except Exception as e:
        logger.error("Directory scan failed: %s", e, exc_info=True)
        return JSONResponse({"error": "Internal server error"}, status_code=500)


@router.get("/brain/git-repos")
async def brain_git_repos(directory: str = Query(...)):
    """Find all git repos under a directory."""
    if not _is_safe_directory(directory):
        return JSONResponse({"error": "Access denied or invalid directory"}, status_code=403)

    try:
        import brain_scanner
        repos = brain_scanner.find_local_git_repos([directory])
        return {"status": "ok", "repos": repos, "count": len(repos)}
    except Exception as e:
        logger.error("Git repo scan failed: %s", e, exc_info=True)
        return JSONResponse({"error": "Internal server error"}, status_code=500)


# ============================================================================
# PHILOSOPHY — Accessible collection of philosophical discussions & insights
# ============================================================================

@router.get("/philosophy")
async def list_philosophy():
    """Get all philosophy entries — insights, paradigms, and discussions."""
    db = aibrain_db._db()
    rows = db.execute("""
        SELECT id, name, type, tags, content, created, updated
        FROM memories
        WHERE (tags LIKE '%philosophy%' OR tags LIKE '%paradigm%' OR tags LIKE '%insight%'  # noqa:LIKE WILDCARD INJECTION — static search patterns
               OR type = 'philosophy'
               OR name LIKE '%philosophy%' OR name LIKE '%paradigm%'  # noqa:LIKE WILDCARD INJECTION — static search patterns
               OR name LIKE '%pixel_moment%' OR name LIKE '%connectome%'  # noqa:LIKE WILDCARD INJECTION — static search patterns
               OR name LIKE '%north_star%')
        AND active = 1
        ORDER BY created DESC
    """).fetchall()
    db.close()

    entries = []
    for r in rows:
        entries.append({
            "id": r[0], "name": r[1], "type": r[2], "tags": r[3],
            "content": r[4], "created": r[5], "updated": r[6],
        })
    return {"entries": entries, "count": len(entries)}


@router.post("/philosophy")
async def add_philosophy(body: dict):
    """Add a philosophy entry — an insight, paradigm, or discussion point.
    Body: {name, content, tags?}"""
    name = body.get("name", "")
    content = body.get("content", "")
    if not name or not content:
        return JSONResponse({"error": "name and content required"}, status_code=400)

    tags = body.get("tags", "philosophy")
    if "philosophy" not in tags:
        tags = f"philosophy,{tags}" if tags else "philosophy"

    now = datetime.now().isoformat()
    db = aibrain_db._db()
    db.execute(
        "INSERT INTO memories (name, type, tags, content, created, updated) VALUES (?, ?, ?, ?, ?, ?)",
        (name, "philosophy", tags, content, now, now)
    )
    db.commit()
    mem_id = db.execute("SELECT last_insert_rowid()").fetchone()[0]
    db.close()

    return {"status": "created", "id": mem_id, "name": name}
