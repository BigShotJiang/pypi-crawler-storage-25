"""
event_schema.py — Pattern bus event infrastructure for cross-domain reactive intelligence.

Every state change across connected domains emits a
DomainEvent. The PatternBus records these in SQLite for downstream pattern
detection, cross-domain correlation, and reactive triggering.

Architecture:
  - DomainEvent: immutable dataclass describing a single state change
  - PatternBus: SQLite-backed event store with emit/query/stats
  - API router: REST endpoints for event inspection

The bus is fire-and-forget — emission failures never break domain logic.
"""

import json
import logging
import sqlite3
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any
from uuid import uuid4

logger = logging.getLogger(__name__)


@dataclass
class DomainEvent:
    """Every state change across every product emits one of these."""
    event_id: str = field(default_factory=lambda: str(uuid4()))
    domain: str = ""           # "security_scanner" | "analytics" | "aibrain"
    source_agent: str = ""     # agent name from AGENT_ID env var
    event_type: str = ""       # "state_change" | "workflow_complete" | "finding" | "signal"
    key: str = ""              # State key that changed
    value: Any = None
    previous_value: Any = None
    metadata: dict = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.utcnow)

    @property
    def delta(self):
        if isinstance(self.value, (int, float)) and isinstance(self.previous_value, (int, float)):
            return self.value - self.previous_value
        return None

    def to_dict(self):
        return {
            "event_id": self.event_id,
            "domain": self.domain,
            "source_agent": self.source_agent,
            "event_type": self.event_type,
            "key": self.key,
            "value": self.value,
            "previous_value": self.previous_value,
            "metadata": self.metadata,
            "timestamp": self.timestamp.isoformat() if isinstance(self.timestamp, datetime) else self.timestamp,
        }


class PatternBus:
    """Event bus backed by SQLite. Records all state changes across all domains."""

    def __init__(self, db_path: str = "aibrain.db"):
        self.db_path = db_path
        self._ensure_table()

    def _ensure_table(self):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS pattern_bus_events (
                    event_id TEXT PRIMARY KEY,
                    domain TEXT NOT NULL,
                    source_agent TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    key TEXT NOT NULL,
                    value TEXT,
                    previous_value TEXT,
                    metadata TEXT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    processed BOOLEAN DEFAULT FALSE
                )
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_pbe_domain_ts ON pattern_bus_events(domain, timestamp)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_pbe_unprocessed ON pattern_bus_events(processed, timestamp)")

    def emit(self, event: DomainEvent):
        """Record an event. Fire-and-forget — must never break domain logic."""
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute(
                    "INSERT INTO pattern_bus_events "
                    "(event_id, domain, source_agent, event_type, key, value, previous_value, metadata, timestamp) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (event.event_id, event.domain, event.source_agent, event.event_type, event.key,
                     json.dumps(event.value), json.dumps(event.previous_value),
                     json.dumps(event.metadata), event.timestamp.isoformat() if isinstance(event.timestamp, datetime) else event.timestamp)
                )
        except Exception as e:
            logger.warning("Pattern bus emission failed: %s", e)

    def get_unprocessed(self, domain: str = None, limit: int = 100):
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            if domain:
                rows = conn.execute(
                    "SELECT * FROM pattern_bus_events WHERE processed=FALSE AND domain=? ORDER BY timestamp LIMIT ?",
                    (domain, limit)
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM pattern_bus_events WHERE processed=FALSE ORDER BY timestamp LIMIT ?",
                    (limit,)
                ).fetchall()
            return [dict(r) for r in rows]

    def mark_processed(self, event_ids: list):
        if not event_ids:
            return
        with sqlite3.connect(self.db_path) as conn:
            placeholders = ",".join("?" * len(event_ids))
            conn.execute(f"UPDATE pattern_bus_events SET processed=TRUE WHERE event_id IN ({placeholders})", event_ids)  # noqa:SQL F-STRING -- placeholders is safe ?,?,? pattern

    def get_recent(self, limit: int = 50, domain: str = None):
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            if domain:
                rows = conn.execute(
                    "SELECT * FROM pattern_bus_events WHERE domain=? ORDER BY timestamp DESC LIMIT ?",
                    (domain, limit)
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM pattern_bus_events ORDER BY timestamp DESC LIMIT ?",
                    (limit,)
                ).fetchall()
            return [dict(r) for r in rows]

    def get_stats(self):
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            total = conn.execute("SELECT COUNT(*) as c FROM pattern_bus_events").fetchone()["c"]
            unprocessed = conn.execute("SELECT COUNT(*) as c FROM pattern_bus_events WHERE processed=FALSE").fetchone()["c"]
            by_domain = conn.execute(
                "SELECT domain, COUNT(*) as c FROM pattern_bus_events GROUP BY domain"
            ).fetchall()
            by_type = conn.execute(
                "SELECT event_type, COUNT(*) as c FROM pattern_bus_events GROUP BY event_type"
            ).fetchall()
            return {
                "total_events": total,
                "unprocessed": unprocessed,
                "by_domain": {r["domain"]: r["c"] for r in by_domain},
                "by_type": {r["event_type"]: r["c"] for r in by_type},
            }
