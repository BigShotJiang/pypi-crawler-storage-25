"""
pattern_bus_api.py — REST endpoints for the pattern bus event store.

Exposes recent events, unprocessed queue, and statistics for cross-domain
reactive intelligence monitoring.
"""

import os
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, Query
from fastapi.responses import JSONResponse

from event_schema import PatternBus

AIBRAIN_ROOT = Path(os.environ.get("AIBRAIN_ROOT", Path(__file__).parent.parent))
_bus = PatternBus(str(AIBRAIN_ROOT / "aibrain.db"))

router = APIRouter(prefix="/api/agent/pattern-bus", tags=["Pattern Bus"])


@router.get("/events")
async def get_events(
    domain: Optional[str] = Query(None, description="Filter by domain (security_scanner, analytics, aibrain)"),
    limit: int = Query(50, ge=1, le=500),
):
    """Get recent pattern bus events, optionally filtered by domain."""
    events = _bus.get_recent(limit=limit, domain=domain)
    return {"events": events, "count": len(events)}


@router.get("/stats")
async def get_stats():
    """Get pattern bus event statistics — totals, unprocessed count, breakdown by domain and type."""
    return _bus.get_stats()


@router.get("/unprocessed")
async def get_unprocessed(
    domain: Optional[str] = Query(None, description="Filter by domain"),
    limit: int = Query(100, ge=1, le=500),
):
    """Get unprocessed events waiting for downstream consumption."""
    events = _bus.get_unprocessed(domain=domain, limit=limit)
    return {"events": events, "count": len(events)}
