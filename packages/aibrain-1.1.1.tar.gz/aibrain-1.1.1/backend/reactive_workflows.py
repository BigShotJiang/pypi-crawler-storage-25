"""
reactive_workflows.py — Reactive graph definitions and runner for AIBrain.

Wires the domain-agnostic ReactiveEngine into AIBrain's automation chains.
Each graph defines nodes with prerequisites, productions, and real
implementations that call workflow modules (job_search_apply, email_triage,
job_response_checker, evolution_engine). Falls back to mock data when
integrations are not configured (e.g. no email password).

Graphs:
  - job_pipeline: scan HN/Reddit -> filter local/Remote -> track -> check responses -> Telegram alert
  - email_triage: IMAP scan -> classify urgent/action/fyi -> draft replies -> approval queue -> log
  - evolution_cycle: review activity -> skills -> git pull -> analytics -> patterns -> digest -> Telegram -> timestamp
  - content_pipeline: check calendar DB -> generate drafts -> approval queue -> publish (requires operator approval)
"""

import asyncio
import json
import logging
import os
import sys
import time
from datetime import datetime
from pathlib import Path

logger = logging.getLogger(__name__)
from typing import Optional

from fastapi import APIRouter, Query
from fastapi.responses import JSONResponse

# Import consolidated DB
AIBRAIN_ROOT = Path(os.environ.get("AIBRAIN_ROOT", Path(__file__).parent.parent))
sys.path.insert(0, str(AIBRAIN_ROOT))
sys.path.insert(0, str(Path(__file__).parent))
import aibrain_db
from reactive_engine import ReactiveEngine, CheckpointStore, PlanCache, QuestionGenerator
from event_schema import PatternBus, DomainEvent

log = logging.getLogger("reactive_workflows")

router = APIRouter(prefix="/api/agent/reactive", tags=["Reactive Workflows"])

# Shared infrastructure — checkpoint store, plan cache, question generator, pattern bus
_checkpoint_db = AIBRAIN_ROOT / "checkpoints.db"
_checkpoint_store = CheckpointStore(_checkpoint_db)
_plan_cache = PlanCache(_checkpoint_db)
_question_generator = QuestionGenerator()
_pattern_bus = PatternBus(str(AIBRAIN_ROOT / "aibrain.db"))

# Notification callback — set by main.py via set_notify_callback
_notify_callback = None


def set_notify_callback(fn):
    global _notify_callback
    _notify_callback = fn


# ---------------------------------------------------------------------------
# Config & workflow module imports
# ---------------------------------------------------------------------------

_cfg_path = AIBRAIN_ROOT / "config.json"
_CONFIG = json.loads(_cfg_path.read_text()) if _cfg_path.exists() else {}

# Import workflow modules (all in workflows/ directory)
_workflows_dir = AIBRAIN_ROOT / "workflows"
if str(_workflows_dir) not in sys.path:
    sys.path.insert(0, str(_workflows_dir))

try:
    import job_search_apply as _job_mod
except ImportError:
    _job_mod = None
    log.warning("job_search_apply not importable — job pipeline will use stubs")

try:
    import job_response_checker as _job_resp_mod
except ImportError:
    _job_resp_mod = None
    log.warning("job_response_checker not importable — response checker will use stubs")

try:
    import email_triage as _email_mod
except ImportError:
    _email_mod = None
    log.warning("email_triage not importable — email pipeline will use stubs")


def _tg_send(text: str):
    """Send a Telegram message to operator's group chat."""
    import httpx
    token = _CONFIG.get("telegram_token", os.environ.get("TELEGRAM_TOKEN", ""))
    chat_id = _CONFIG.get("telegram_group_id", int(os.environ.get("TELEGRAM_GROUP_ID", "0")))
    try:
        httpx.post(
            f"https://api.telegram.org/bot{token}/sendMessage",
            json={"chat_id": chat_id, "text": text, "parse_mode": "HTML"},
            timeout=15,
        )
    except Exception as e:
        log.warning("Telegram send failed: %s", e)


# ---------------------------------------------------------------------------
# Node functions — real implementations with stub fallback
# ---------------------------------------------------------------------------

# --- Job Pipeline ---

async def scan_job_boards(state: dict) -> dict:
    """Scan HN + Reddit job boards for new listings matching configured keywords."""
    log.info("[job_pipeline] Scanning job boards...")
    keywords = _CONFIG.get("job_keywords", ["security", "pentester", "devops", "python", "remote"])
    jobs = []
    if _job_mod:
        try:
            hn_jobs = await asyncio.to_thread(_job_mod.search_hn_hiring, keywords)
            jobs.extend(hn_jobs)
        except Exception as e:
            log.warning("[job_pipeline] HN scan failed: %s", e)
        try:
            reddit_jobs = await asyncio.to_thread(_job_mod.search_reddit_jobs, keywords)
            jobs.extend(reddit_jobs)
        except Exception as e:
            log.warning("[job_pipeline] Reddit scan failed: %s", e)
    if not jobs:
        log.info("[job_pipeline] No real results — returning mock data")
        jobs = [
            {"id": "mock_001", "title": "Security Engineer", "source": "mock", "url": "", "preview": "Mock listing"},
            {"id": "mock_002", "title": "Pentester", "source": "mock", "url": "", "preview": "Mock listing"},
        ]
    log.info("[job_pipeline] Found %d jobs", len(jobs))
    return {"new_jobs": jobs}


async def filter_by_criteria(state: dict) -> dict:
    """Filter jobs by location (local/Remote) and keyword relevance."""
    raw_jobs = state.get("new_jobs", [])
    log.info("[job_pipeline] Filtering %d jobs by criteria...", len(raw_jobs))
    location_keywords = {"remote", "work from home", "wfh", "anywhere"}
    filtered = []
    for j in raw_jobs:
        text = f"{j.get('title', '')} {j.get('preview', '')} {j.get('location', '')}".lower()
        if any(loc in text for loc in location_keywords):
            filtered.append(j)
    log.info("[job_pipeline] %d jobs passed filters", len(filtered))
    return {"filtered_jobs": filtered}


async def apply_to_filtered(state: dict) -> dict:
    """Record filtered jobs as applications in the tracker (actual apply is manual)."""
    filtered = state.get("filtered_jobs", [])
    log.info("[job_pipeline] Recording %d jobs for application...", len(filtered))
    applications = []
    for job in filtered:
        app = {
            "job_id": job.get("id", ""),
            "title": job.get("title", "Unknown"),
            "company": job.get("title", "").split("|")[0].strip()[:60] if "|" in job.get("title", "") else job.get("source", ""),
            "source": job.get("source", ""),
            "url": job.get("url", ""),
            "applied_at": datetime.now().isoformat(),
            "status": "queued",
        }
        # Track in job_tracker DB if available
        if _job_resp_mod:
            try:
                app_id = await asyncio.to_thread(
                    _job_resp_mod.track_application,
                    app["company"], app["title"], app["source"], app["url"],
                )
                app["tracker_id"] = app_id
                app["status"] = "tracked"
            except Exception as e:
                log.warning("[job_pipeline] Track application failed: %s", e)
        applications.append(app)
    log.info("[job_pipeline] Recorded %d applications", len(applications))
    return {"applications": applications}


async def check_responses(state: dict) -> dict:
    """Check email inbox for job application responses."""
    log.info("[job_pipeline] Checking inbox for job responses...")
    updates = []
    if _job_resp_mod:
        try:
            responses = await asyncio.to_thread(_job_resp_mod.check_inbox_for_responses, True)
            for resp in responses:
                updates.append({
                    "from": resp.get("from", ""),
                    "subject": resp.get("subject", ""),
                    "status": resp.get("type", "info"),
                    "checked_at": datetime.now().isoformat(),
                })
        except Exception as e:
            log.warning("[job_pipeline] Inbox check failed: %s", e)
    if not updates:
        log.info("[job_pipeline] No responses found (or not configured)")
    log.info("[job_pipeline] %d status updates", len(updates))
    return {"status_updates": updates}


async def send_interview_alert(state: dict) -> dict:
    """Send Telegram alert for interview invitations."""
    interviews = [u for u in state.get("status_updates", []) if u.get("status") == "positive"]
    log.info("[job_pipeline] Sending alerts for %d interviews", len(interviews))
    alerts = []
    for inv in interviews:
        msg = f"<b>Interview Alert</b>\nFrom: {inv.get('from', 'unknown')}\nSubject: {inv.get('subject', '')}"
        await asyncio.to_thread(_tg_send, msg)
        alerts.append({
            "from": inv.get("from", ""),
            "subject": inv.get("subject", ""),
            "alerted_at": datetime.now().isoformat(),
            "channel": "telegram",
        })
    return {"alerts_sent": alerts}


# --- Email Triage ---

async def scan_inbox(state: dict) -> dict:
    """Scan email inbox for unread messages via IMAP."""
    log.info("[email_triage] Scanning inbox...")
    emails = []
    if _email_mod:
        imap_host = _CONFIG.get("email_imap_host", "imap.gmail.com")
        email_addr = _CONFIG.get("agent_email", _CONFIG.get("email_to", ""))
        password = _CONFIG.get("email_app_password", _CONFIG.get("agent_email_password", ""))
        if email_addr and password:
            try:
                raw = await asyncio.to_thread(
                    _email_mod.fetch_unread, imap_host, email_addr, password, 50,
                )
                for e in raw:
                    if "note" in e:
                        continue  # skip retry-fallback entries
                    emails.append({
                        "id": e.get("uid", ""),
                        "from": e.get("sender_email", e.get("sender", "")),
                        "subject": e.get("subject", ""),
                        "body_preview": e.get("body_preview", ""),
                        "category": e.get("category"),
                        "date": e.get("date", ""),
                        "urgent": e.get("category") == "urgent",
                    })
            except Exception as e:
                log.warning("[email_triage] IMAP scan failed: %s", e)
        else:
            log.info("[email_triage] Email not configured — using mock data")
    if not emails:
        emails = [
            {"id": "mock_em1", "from": "recruiter@example.com", "subject": "Interview Invitation",
             "category": None, "urgent": True, "body_preview": "", "date": ""},
            {"id": "mock_em2", "from": "newsletter@tech.io", "subject": "Weekly Digest",
             "category": None, "urgent": False, "body_preview": "", "date": ""},
        ]
    log.info("[email_triage] Found %d emails", len(emails))
    return {"inbox_emails": emails}


async def categorize_emails(state: dict) -> dict:
    """Categorize emails using email_triage classifier."""
    raw = state.get("inbox_emails", [])
    log.info("[email_triage] Categorizing %d emails...", len(raw))
    categorized = []
    for em in raw:
        if em.get("category"):
            categorized.append(em)
            continue
        # Use real classifier if available
        if _email_mod:
            cat = _email_mod.classify_email(
                em.get("from", ""), em.get("subject", ""), em.get("body_preview", ""),
            )
            em["category"] = cat
            em["urgent"] = cat == "urgent"
        else:
            em["category"] = "fyi"
        categorized.append(em)
    return {"categorized_emails": categorized}


async def draft_replies(state: dict) -> dict:
    """Draft replies for urgent/action emails."""
    needs_reply = [e for e in state.get("categorized_emails", [])
                   if e.get("category") in ("urgent", "action", "job")]
    log.info("[email_triage] Drafting %d replies...", len(needs_reply))
    drafts = []
    for em in needs_reply:
        body = f"Received — responding to: {em['subject']}"
        if _job_resp_mod and em.get("category") == "job":
            try:
                resp_obj = {"type": "info", "from": em["from"], "subject": em["subject"],
                            "body": em.get("body_preview", "")}
                reply = _job_resp_mod.draft_reply(resp_obj)
                if reply:
                    body = reply
            except Exception as e:
                log.warning("Failed to draft job reply for '%s': %s", em.get("subject", "?"), e)
        drafts.append({
            "email_id": em.get("id", ""),
            "to": em["from"],
            "subject": f"Re: {em['subject']}",
            "body": body,
            "drafted_at": datetime.now().isoformat(),
        })
    return {"drafted_replies": drafts}


async def send_urgent(state: dict) -> dict:
    """Submit urgent replies to approval queue (never auto-send)."""
    urgent_drafts = [d for d in state.get("drafted_replies", [])
                     if any(e.get("urgent") and e.get("id") == d["email_id"]
                            for e in state.get("categorized_emails", []))]
    log.info("[email_triage] Queuing %d urgent replies for approval...", len(urgent_drafts))
    sent = []
    for draft in urgent_drafts:
        # Create approval instead of auto-sending
        try:
            aibrain_db.create_activity(
                agent=os.getenv("AGENT_ID", "agent"), action="email_draft:urgent",
                category="email", status="pending",
                detail=json.dumps({"to": draft["to"], "subject": draft["subject"],
                                   "body_preview": draft["body"][:200]}),
            )
        except Exception as e:
            log.warning("Failed to log urgent draft: %s", e)
        sent.append({
            "email_id": draft["email_id"],
            "to": draft["to"],
            "queued_at": datetime.now().isoformat(),
            "status": "approval_required",
        })
    return {"urgent_sent": sent}


async def log_all_emails(state: dict) -> dict:
    """Log all processed emails to activity DB."""
    total = len(state.get("categorized_emails", []))
    urgent_count = len(state.get("urgent_sent", []))
    draft_count = len(state.get("drafted_replies", []))
    log.info("[email_triage] Logging: %d emails, %d drafts, %d urgent queued", total, draft_count, urgent_count)
    try:
        aibrain_db.create_activity(
            agent=os.getenv("AGENT_ID", "agent"), action="email_triage",
            category="email", status="ok",
            detail=json.dumps({"total": total, "drafts": draft_count,
                               "urgent_queued": urgent_count,
                               "timestamp": datetime.now().isoformat()}),
        )
    except Exception as e:
        log.warning("Failed to log email triage: %s", e)
    return {"email_log": {
        "total_processed": total,
        "drafts_created": draft_count,
        "urgent_sent": urgent_count,
        "logged_at": datetime.now().isoformat(),
    }}


# --- Evolution Cycle ---

async def review_tasks(state: dict) -> dict:
    """Review pending tasks and completed work from activity DB."""
    log.info("[evolution] Reviewing tasks...")
    try:
        recent = aibrain_db.list_activity(limit=100, category=None)
        now = datetime.now()
        today = now.strftime("%Y-%m-%d")
        completed = sum(1 for a in recent if a.get("status") == "ok" and str(a.get("timestamp", "")).startswith(today))
        pending = sum(1 for a in recent if a.get("status") == "pending")
        blocked = sum(1 for a in recent if a.get("status") in ("error", "blocked"))
        return {"task_review": {
            "pending": pending, "completed_today": completed, "blocked": blocked,
            "total_recent": len(recent),
            "reviewed_at": now.isoformat(),
        }}
    except Exception as e:
        log.warning("[evolution] Task review failed: %s", e)
        return {"task_review": {"pending": 0, "completed_today": 0, "blocked": 0,
                                "reviewed_at": datetime.now().isoformat()}}


async def update_skills(state: dict) -> dict:
    """Check installed skills count from DB."""
    log.info("[evolution] Checking skill count...")
    try:
        skills = aibrain_db.list_skills()
        return {"skill_updates": {
            "total_installed": len(skills),
            "checked_at": datetime.now().isoformat(),
        }}
    except Exception as e:
        log.warning("[evolution] Skill check failed: %s", e)
        return {"skill_updates": {"total_installed": 0, "checked_at": datetime.now().isoformat()}}


async def pull_github(state: dict) -> dict:
    """Pull latest from tracked repos via git."""
    import subprocess
    log.info("[evolution] Pulling GitHub repos...")
    repos = [
        AIBRAIN_ROOT,
    ]
    # Discover sibling project directories dynamically
    for p in AIBRAIN_ROOT.parent.iterdir():
        if p.is_dir() and (p / ".git").exists() and p != AIBRAIN_ROOT:
            repos.append(p)
    pulled = 0
    conflicts = 0
    stashed = 0
    for repo in repos:
        if not (repo / ".git").exists():
            continue
        try:
            # Stash before pulling (operator's rule: always stash first)
            stash_result = await asyncio.to_thread(
                subprocess.run,
                ["git", "-C", str(repo), "stash"],
                capture_output=True, text=True, timeout=10,
            )
            did_stash = "Saved working directory" in stash_result.stdout
            if did_stash:
                stashed += 1

            result = await asyncio.to_thread(
                subprocess.run,
                ["git", "-C", str(repo), "pull", "--rebase"],
                capture_output=True, text=True, timeout=30,
            )
            if result.returncode == 0:
                pulled += 1
            else:
                if "conflict" in result.stderr.lower():
                    conflicts += 1
                    # Abort the rebase to leave clean state
                    await asyncio.to_thread(
                        subprocess.run,
                        ["git", "-C", str(repo), "rebase", "--abort"],
                        capture_output=True, timeout=10,
                    )
                log.warning("[evolution] Git pull failed for %s: %s", repo.name, result.stderr[:200])

            # Pop stash if we stashed
            if did_stash:
                await asyncio.to_thread(
                    subprocess.run,
                    ["git", "-C", str(repo), "stash", "pop"],
                    capture_output=True, text=True, timeout=10,
                )
        except Exception as e:
            log.warning("[evolution] Git pull error for %s: %s", repo.name, e)
    return {"github_pull": {
        "repos_pulled": pulled, "repos_checked": len([r for r in repos if (r / ".git").exists()]),
        "conflicts": conflicts, "stashed": stashed, "pulled_at": datetime.now().isoformat(),
    }}


async def review_analytics(state: dict) -> dict:
    """Review system analytics from activity DB."""
    log.info("[evolution] Reviewing analytics...")
    try:
        recent = aibrain_db.list_activity(limit=500, category=None)
        now = datetime.now()
        errors_24h = sum(1 for a in recent
                         if a.get("status") in ("error", "failed"))
        tasks_ok = sum(1 for a in recent if a.get("status") == "ok")
        return {"analytics": {
            "tasks_completed": tasks_ok,
            "errors_24h": errors_24h,
            "total_activity": len(recent),
            "reviewed_at": now.isoformat(),
        }}
    except Exception as e:
        log.warning("[evolution] Analytics review failed: %s", e)
        return {"analytics": {"tasks_completed": 0, "errors_24h": 0,
                              "reviewed_at": datetime.now().isoformat()}}


async def pattern_review(state: dict) -> dict:
    """Review evolution patterns from the evolution engine."""
    log.info("[evolution] Reviewing patterns...")
    try:
        import evolution_engine
        db = evolution_engine.get_evolution_db(aibrain_db.DB_PATH)
        active = db.execute(
            "SELECT COUNT(*) as cnt FROM evolution_patterns WHERE status='active'"
        ).fetchone()["cnt"]
        total = db.execute("SELECT COUNT(*) as cnt FROM evolution_patterns").fetchone()["cnt"]
        db.close()
        return {"pattern_review": {
            "patterns_active": active, "patterns_total": total,
            "reviewed_at": datetime.now().isoformat(),
        }}
    except Exception as e:
        log.warning("[evolution] Pattern review failed: %s", e)
        return {"pattern_review": {"patterns_active": 0, "patterns_total": 0,
                                   "reviewed_at": datetime.now().isoformat()}}


async def generate_digest(state: dict) -> dict:
    """Generate evolution digest from all collected data."""
    log.info("[evolution] Generating digest...")
    parts = []
    if state.get("task_review"):
        tr = state["task_review"]
        parts.append(f"Tasks: {tr.get('completed_today', 0)} done, {tr.get('pending', 0)} pending, {tr.get('blocked', 0)} blocked")
    if state.get("skill_updates"):
        parts.append(f"Skills: {state['skill_updates'].get('total_installed', 0)} installed")
    if state.get("github_pull"):
        gp = state["github_pull"]
        parts.append(f"Git: {gp.get('repos_pulled', 0)}/{gp.get('repos_checked', 0)} repos pulled")
    if state.get("analytics"):
        parts.append(f"Errors (24h): {state['analytics'].get('errors_24h', 0)}")
    if state.get("pattern_review"):
        parts.append(f"Patterns: {state['pattern_review'].get('patterns_active', 0)} active")
    return {"digest": {
        "summary": " | ".join(parts) or "No data collected",
        "generated_at": datetime.now().isoformat(),
    }}


async def send_digest(state: dict) -> dict:
    """Send the evolution digest via Telegram."""
    summary = state.get("digest", {}).get("summary", "No digest")
    log.info("[evolution] Sending digest via Telegram...")
    msg = f"<b>Evolution Digest</b>\n{summary}"
    await asyncio.to_thread(_tg_send, msg)
    return {"digest_sent": {
        "channel": "telegram",
        "summary_length": len(summary),
        "sent_at": datetime.now().isoformat(),
    }}


async def update_timestamp(state: dict) -> dict:
    """Update the last evolution timestamp file."""
    log.info("[evolution] Updating evolution timestamp...")
    ts_file = AIBRAIN_ROOT / ".tmp" / "last_evolution.txt"
    try:
        ts_file.parent.mkdir(parents=True, exist_ok=True)
        ts_file.write_text(str(time.time()))
    except Exception as e:
        log.warning("[evolution] Failed to write timestamp: %s", e)
    return {"evolution_timestamp": datetime.now().isoformat()}


async def write_session_handoff(state: dict) -> dict:
    """Write a session handoff memory so next session can pick up cold.

    This is the CRITICAL continuity fix — without this, every new session
    starts blind and operator has to manually re-orient the agent.
    """
    log.info("[evolution] Writing session handoff memory...")
    now = datetime.now()
    parts = []

    # Collect what happened this cycle
    if state.get("task_review"):
        tr = state["task_review"]
        parts.append(f"Tasks: {tr.get('completed_today', 0)} done, {tr.get('pending', 0)} pending, {tr.get('blocked', 0)} blocked")
    if state.get("github_pull"):
        gp = state["github_pull"]
        parts.append(f"Git: {gp.get('repos_pulled', 0)}/{gp.get('repos_checked', 0)} repos pulled, {gp.get('conflicts', 0)} conflicts")
    if state.get("analytics"):
        parts.append(f"Errors (24h): {state['analytics'].get('errors_24h', 0)}, Tasks OK: {state['analytics'].get('tasks_completed', 0)}")
    if state.get("pattern_review"):
        parts.append(f"Patterns: {state['pattern_review'].get('patterns_active', 0)} active")
    if state.get("digest"):
        parts.append(f"Digest: {state['digest'].get('summary', 'none')}")

    # Get recent git commits for context
    import subprocess
    recent_commits = []
    try:
        result = await asyncio.to_thread(
            subprocess.run,
            ["git", "-C", str(AIBRAIN_ROOT), "log", "--oneline", "-5"],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0:
            recent_commits = result.stdout.strip().split("\n")
    except Exception:
        pass

    # Get pending approvals count
    pending_approvals = 0
    try:
        import sqlite3 as _sq
        db = _sq.connect(str(aibrain_db.DB_PATH))
        pending_approvals = db.execute(
            "SELECT COUNT(*) FROM approvals WHERE status='pending'"
        ).fetchone()[0]
        db.close()
    except Exception:
        pass

    handoff_content = f"""SESSION HANDOFF — {now.strftime('%Y-%m-%d %H:%M')} ACST (auto-generated by evolution cycle)

## System State:
{chr(10).join('- ' + p for p in parts) if parts else '- No data collected'}

## Recent Commits (aibrain):
{chr(10).join('- ' + c for c in recent_commits) if recent_commits else '- None'}

## Pending Approvals: {pending_approvals}

## Next Session Should:
1. Recall this handoff via MCP memory_search("session handoff")
2. Pull git on all repos (stash first)
3. Check pending approvals
4. Continue from last commit above
"""

    try:
        db = aibrain_db.get_db()
        existing = db.execute(
            "SELECT id FROM memories WHERE name='session_handoff_latest' AND active=1"
        ).fetchone()
        if existing:
            aibrain_db.update_memory(existing[0], content=handoff_content)
        else:
            aibrain_db.create_memory(
                name="session_handoff_latest",
                mem_type="project",
                content=handoff_content,
                tags="session,handoff,continuity",
                importance=1.0,
            )
        log.info("[evolution] Session handoff memory written successfully")
    except Exception as e:
        log.warning("[evolution] Failed to write session handoff: %s", e)

    return {"session_handoff": {
        "written": True,
        "timestamp": now.isoformat(),
    }}


# --- Content Pipeline ---

async def check_calendar(state: dict) -> dict:
    """Check content pipeline DB for posts due today."""
    log.info("[content] Checking content calendar...")
    items = []
    try:
        db_path = aibrain_db.DB_PATH
        import sqlite3 as _sqlite3
        db = _sqlite3.connect(str(db_path))
        db.row_factory = _sqlite3.Row
        today = datetime.now().strftime("%Y-%m-%d")
        rows = db.execute(
            "SELECT * FROM content_queue WHERE status IN ('draft','scheduled') AND scheduled_date <= ? ORDER BY scheduled_date",
            (today + " 23:59:59",),
        ).fetchall()
        for r in rows:
            items.append(dict(r))
        db.close()
    except Exception as e:
        log.info("[content] Content calendar query failed (table may not exist): %s", e)
    if not items:
        items = [
            {"platform": "linkedin", "topic": "Agentic Security in 2026", "due": datetime.now().isoformat()},
            {"platform": "twitter", "topic": "Quick tip: Claude Code skills", "due": datetime.now().isoformat()},
        ]
    log.info("[content] %d items due", len(items))
    return {"calendar_items": items}


async def generate_content(state: dict) -> dict:
    """Generate content drafts for calendar items (placeholder — needs LLM)."""
    items = state.get("calendar_items", [])
    log.info("[content] Generating %d content drafts...", len(items))
    drafts = []
    for item in items:
        platform = item.get("platform", "unknown")
        topic = item.get("topic", item.get("title", ""))
        drafts.append({
            "platform": platform,
            "topic": topic,
            "draft": f"[DRAFT] {topic} — needs communications_agent review before publish",
            "generated_at": datetime.now().isoformat(),
        })
    return {"content_drafts": drafts}


async def request_approval(state: dict) -> dict:
    """Submit content drafts to the approval queue."""
    drafts = state.get("content_drafts", [])
    log.info("[content] Requesting approval for %d drafts...", len(drafts))
    approval_ids = []
    for i, draft in enumerate(drafts):
        approval_id = f"content_{int(time.time())}_{i}"
        try:
            aibrain_db.create_activity(
                agent=os.getenv("AGENT_ID", "agent"), action="content_approval",
                category="content", status="pending",
                detail=json.dumps({
                    "platform": draft["platform"], "topic": draft["topic"],
                    "draft_preview": draft["draft"][:200],
                    "approval_id": approval_id,
                }),
            )
        except Exception as e:
            log.warning("Failed to create approval activity: %s", e)
        approval_ids.append({
            "draft_index": i,
            "platform": draft["platform"],
            "approval_id": approval_id,
            "status": "pending",
            "submitted_at": datetime.now().isoformat(),
        })
    return {"approval_requests": approval_ids}


async def publish_content(state: dict) -> dict:
    """Check approval status — only publish if operator approved."""
    approvals = state.get("approval_requests", [])
    log.info("[content] %d items awaiting operator approval before publish", len(approvals))
    # Never auto-publish — communications rules require operator approval
    return {"publish_status": {
        "items_queued": len(approvals),
        "published": 0,
        "awaiting_approval": len(approvals),
        "checked_at": datetime.now().isoformat(),
    }}


# --- Metacognition (Pixel Moment) ---

async def gather_memory_snapshot(state: dict) -> dict:
    """Pull all memories for pattern analysis."""
    log.info("[metacognition] Gathering memory snapshot...")
    try:
        memories = aibrain_db.list_memories(limit=500)
        return {"memory_snapshot": memories, "memory_count": len(memories)}
    except Exception as e:
        log.warning("[metacognition] Memory gather failed: %s", e)
        return {"memory_snapshot": [], "memory_count": 0}


async def gather_workflow_history(state: dict) -> dict:
    """Pull recent workflow execution history."""
    log.info("[metacognition] Gathering workflow history...")
    try:
        entries = aibrain_db.list_activity(limit=100, category="reactive")
        return {"workflow_history": entries, "workflow_count": len(entries)}
    except Exception as e:
        log.warning("[metacognition] Workflow history failed: %s", e)
        return {"workflow_history": [], "workflow_count": 0}


async def generate_questions(state: dict) -> dict:
    """Run QuestionGenerator on memory + workflow data — the pixel moment."""
    log.info("[metacognition] Generating questions...")
    memories = state.get("memory_snapshot", [])
    workflows = state.get("workflow_history", [])

    # Analyze memory patterns
    mem_questions = _question_generator.analyze_memory(memories)

    # Extract workflow categories for coverage analysis
    wf_categories = []
    for w in workflows:
        action = w.get("action", "")
        if ":" in action:
            wf_categories.append({"category": action.split(":")[1]})

    if wf_categories:
        _question_generator.analyze_memory([], wf_categories)

    top = _question_generator.get_top_questions(10)
    log.info("[metacognition] Generated %d questions (%d top)", len(mem_questions), len(top))
    return {
        "questions_generated": len(mem_questions),
        "top_questions": top,
    }


async def store_questions(state: dict) -> dict:
    """Store generated questions in activity DB and optionally alert."""
    questions = state.get("top_questions", [])
    log.info("[metacognition] Storing %d questions...", len(questions))
    stored = 0
    for q in questions[:5]:  # Top 5 only
        try:
            aibrain_db.create_activity(
                agent=os.getenv("AGENT_ID", "agent"), action="metacognition:question",
                category="metacognition", status="new",
                detail=json.dumps({
                    "type": q["type"],
                    "question": q["question"],
                    "priority": q["priority"],
                    "source": q.get("source", ""),
                }),
            )
            stored += 1
        except Exception as e:
            log.warning("[metacognition] Failed to store question: %s", e)

    # Send top 3 to Telegram if any are high priority
    high_priority = [q for q in questions[:3] if q["priority"] >= 0.7]
    if high_priority:
        lines = ["<b>Pixel Moment — Agent Questions</b>"]
        for q in high_priority:
            lines.append(f"[{q['type']}] {q['question'][:120]}")
        await asyncio.to_thread(_tg_send, "\n".join(lines))

    return {"questions_stored": stored, "questions_alerted": len(high_priority)}


# ---------------------------------------------------------------------------
# Graph Definitions
# ---------------------------------------------------------------------------

GRAPHS = {
    "job_pipeline": {
        "description": "Scan job boards, filter, apply, track responses, alert on interviews",
        "nodes": {
            "scan_boards": {
                "requires": lambda s: True,
                "produces": ["new_jobs"],
                "fn": scan_job_boards,
                "priority": 100,
            },
            "filter_jobs": {
                "requires": lambda s: len(s.get("new_jobs", [])) > 0,
                "produces": ["filtered_jobs"],
                "fn": filter_by_criteria,
                "priority": 90,
            },
            "apply_to_jobs": {
                "requires": lambda s: len(s.get("filtered_jobs", [])) > 0,
                "produces": ["applications"],
                "fn": apply_to_filtered,
                "priority": 80,
            },
            "track_responses": {
                "requires": lambda s: len(s.get("applications", [])) > 0,
                "produces": ["status_updates"],
                "fn": check_responses,
                "priority": 70,
                "refire_on": ["applications"],
            },
            "alert_interviews": {
                "requires": lambda s: any(u.get("status") == "interview" for u in s.get("status_updates", [])),
                "produces": ["alerts_sent"],
                "fn": send_interview_alert,
                "priority": 60,
            },
        },
    },

    "email_triage": {
        "description": "Scan inbox, categorize, draft replies, send urgent, log all",
        "nodes": {
            "scan_inbox": {
                "requires": lambda s: True,
                "produces": ["inbox_emails"],
                "fn": scan_inbox,
                "priority": 100,
            },
            "categorize": {
                "requires": lambda s: len(s.get("inbox_emails", [])) > 0,
                "produces": ["categorized_emails"],
                "fn": categorize_emails,
                "priority": 90,
            },
            "draft_replies": {
                "requires": lambda s: len(s.get("categorized_emails", [])) > 0,
                "produces": ["drafted_replies"],
                "fn": draft_replies,
                "priority": 80,
            },
            "send_urgent": {
                "requires": lambda s: len(s.get("drafted_replies", [])) > 0,
                "produces": ["urgent_sent"],
                "fn": send_urgent,
                "priority": 70,
            },
            "log_all": {
                "requires": lambda s: s.get("categorized_emails") is not None,
                "produces": ["email_log"],
                "fn": log_all_emails,
                "priority": 60,
            },
        },
    },

    "evolution_cycle": {
        "description": "Full evolution cycle: review, update, pull, analyze, digest, notify",
        "nodes": {
            "review_tasks": {
                "requires": lambda s: True,
                "produces": ["task_review"],
                "fn": review_tasks,
                "priority": 100,
            },
            "update_skills": {
                "requires": lambda s: True,
                "produces": ["skill_updates"],
                "fn": update_skills,
                "priority": 100,
            },
            "pull_github": {
                "requires": lambda s: True,
                "produces": ["github_pull"],
                "fn": pull_github,
                "priority": 100,
            },
            "review_analytics": {
                "requires": lambda s: True,
                "produces": ["analytics"],
                "fn": review_analytics,
                "priority": 100,
            },
            "pattern_review": {
                "requires": lambda s: True,
                "produces": ["pattern_review"],
                "fn": pattern_review,
                "priority": 100,
            },
            "generate_digest": {
                "requires": lambda s: (
                    s.get("task_review") is not None
                    and s.get("skill_updates") is not None
                    and s.get("github_pull") is not None
                    and s.get("analytics") is not None
                    and s.get("pattern_review") is not None
                ),
                "produces": ["digest"],
                "fn": generate_digest,
                "priority": 50,
            },
            "send_digest": {
                "requires": lambda s: s.get("digest") is not None,
                "produces": ["digest_sent"],
                "fn": send_digest,
                "priority": 40,
            },
            "update_timestamp": {
                "requires": lambda s: s.get("digest_sent") is not None,
                "produces": ["evolution_timestamp"],
                "fn": update_timestamp,
                "priority": 30,
            },
            "write_session_handoff": {
                "requires": lambda s: s.get("evolution_timestamp") is not None,
                "produces": ["session_handoff"],
                "fn": write_session_handoff,
                "priority": 20,
            },
        },
    },

    "metacognition": {
        "description": "Pixel moment — analyze memory + workflows, generate breakthrough questions",
        "nodes": {
            "gather_memories": {
                "requires": lambda s: True,
                "produces": ["memory_snapshot", "memory_count"],
                "fn": gather_memory_snapshot,
                "priority": 100,
            },
            "gather_workflows": {
                "requires": lambda s: True,
                "produces": ["workflow_history", "workflow_count"],
                "fn": gather_workflow_history,
                "priority": 100,
            },
            "generate_questions": {
                "requires": lambda s: s.get("memory_snapshot") is not None and s.get("workflow_history") is not None,
                "produces": ["questions_generated", "top_questions"],
                "fn": generate_questions,
                "priority": 50,
            },
            "store_questions": {
                "requires": lambda s: s.get("top_questions") is not None,
                "produces": ["questions_stored", "questions_alerted"],
                "fn": store_questions,
                "priority": 40,
            },
        },
    },

    "content_pipeline": {
        "description": "Check calendar, generate content, request approval, publish when approved",
        "nodes": {
            "check_calendar": {
                "requires": lambda s: True,
                "produces": ["calendar_items"],
                "fn": check_calendar,
                "priority": 100,
            },
            "generate_content": {
                "requires": lambda s: len(s.get("calendar_items", [])) > 0,
                "produces": ["content_drafts"],
                "fn": generate_content,
                "priority": 90,
            },
            "request_approval": {
                "requires": lambda s: len(s.get("content_drafts", [])) > 0,
                "produces": ["approval_requests"],
                "fn": request_approval,
                "priority": 80,
            },
            "publish": {
                "requires": lambda s: len(s.get("approval_requests", [])) > 0,
                "produces": ["publish_status"],
                "fn": publish_content,
                "priority": 70,
                "refire_on": ["approval_requests"],
            },
        },
    },
}


# ---------------------------------------------------------------------------
# ReactiveWorkflowRunner
# ---------------------------------------------------------------------------

class ReactiveWorkflowRunner:
    """Runs a named reactive graph with logging, DB persistence, and notifications."""

    def __init__(self, graph_name: str, initial_state: Optional[dict] = None):
        if graph_name not in GRAPHS:
            raise ValueError(f"Unknown graph: {graph_name}. Available: {list(GRAPHS.keys())}")

        self.graph_name = graph_name
        self.graph_def = GRAPHS[graph_name]
        self.initial_state = initial_state or {}
        self.engine: Optional[ReactiveEngine] = None
        self.start_time: Optional[float] = None
        self.end_time: Optional[float] = None
        self.final_state: Optional[dict] = None

    def _on_node_start(self, node_name: str, state: dict):
        """Callback: node started firing."""
        log.info("[%s] Node started: %s", self.graph_name, node_name)
        if _notify_callback:
            asyncio.ensure_future(_notify_callback({
                "type": "reactive",
                "action": "node_start",
                "graph": self.graph_name,
                "node": node_name,
            }))

    def _on_node_complete(self, node_name: str, result: dict | None, state: dict):
        """Callback: node finished firing."""
        status = "ok" if result is not None else "error"
        log.info("[%s] Node complete: %s (%s)", self.graph_name, node_name, status)
        if _notify_callback:
            asyncio.ensure_future(_notify_callback({
                "type": "reactive",
                "action": "node_complete",
                "graph": self.graph_name,
                "node": node_name,
                "status": status,
            }))

    def _on_state_change(self, node_name: str, changed_keys: list[str], state: dict):
        """Callback: state keys changed after node fired. Emits to pattern bus."""
        log.debug("[%s] State changed by %s: %s", self.graph_name, node_name, changed_keys)
        for key in changed_keys:
            _pattern_bus.emit(DomainEvent(
                domain="aibrain",
                source_agent=os.getenv("AGENT_ID", "agent"),
                event_type="state_change",
                key=key,
                value=state.get(key),
                previous_value=None,  # previous value not available in callback
                metadata={"graph": self.graph_name, "node": node_name},
            ))

    async def run(self) -> dict:
        """Execute the reactive graph. Returns execution summary."""
        self.start_time = time.time()
        nodes = self.graph_def["nodes"]

        self.engine = ReactiveEngine(
            state=dict(self.initial_state),
            graph=nodes,
            on_node_start=self._on_node_start,
            on_node_complete=self._on_node_complete,
            on_state_change=self._on_state_change,
            checkpoint_store=_checkpoint_store,
            enable_confidence_gate=True,
        )

        # Broadcast graph start
        if _notify_callback:
            asyncio.ensure_future(_notify_callback({
                "type": "reactive",
                "action": "graph_start",
                "graph": self.graph_name,
                "total_nodes": len(nodes),
            }))

        try:
            self.final_state = await self.engine.run()
            status = "completed"
        except Exception as e:
            log.error("[%s] Graph execution failed: %s", self.graph_name, e)
            self.final_state = self.engine.state if self.engine else {}
            status = "error"

        self.end_time = time.time()
        duration = round(self.end_time - self.start_time, 2)

        stats = self.engine.stats
        blocked = self.engine.blocked_nodes()

        # Persist execution to activity DB
        try:
            aibrain_db.create_activity(
                agent=os.getenv("AGENT_ID", "agent"),
                action=f"reactive:{self.graph_name}",
                category="reactive",
                detail=json.dumps({
                    "status": status,
                    "duration_s": duration,
                    "nodes_fired": stats["fired_count"],
                    "nodes_total": stats["total_nodes"],
                    "completed": stats["completed"],
                    "failed": stats["failed"],
                    "blocked": blocked,
                }),
                status=status,
            )
        except Exception as e:
            log.warning("Failed to persist reactive execution: %s", e)

        # Emit workflow_complete event to pattern bus
        _pattern_bus.emit(DomainEvent(
            domain="aibrain",
            source_agent=os.getenv("AGENT_ID", "agent"),
            event_type="workflow_complete",
            key=self.graph_name,
            value=status,
            metadata={
                "duration_s": duration,
                "nodes_fired": stats["fired_count"],
                "nodes_total": stats["total_nodes"],
                "failed": stats["failed"],
            },
        ))

        # Broadcast graph complete
        if _notify_callback:
            asyncio.ensure_future(_notify_callback({
                "type": "reactive",
                "action": "graph_complete",
                "graph": self.graph_name,
                "status": status,
                "duration_s": duration,
                "nodes_fired": stats["fired_count"],
                "nodes_total": stats["total_nodes"],
            }))

        summary = {
            "graph": self.graph_name,
            "status": status,
            "duration_s": duration,
            "started_at": datetime.fromtimestamp(self.start_time).isoformat(),
            "ended_at": datetime.fromtimestamp(self.end_time).isoformat(),
            "stats": stats,
            "blocked": blocked,
            "execution_log": self.engine.execution_log,
        }

        return summary


# ---------------------------------------------------------------------------
# FastAPI Router — /api/agent/reactive/*
# ---------------------------------------------------------------------------

@router.get("/graphs")
async def list_graphs():
    """List all available reactive graphs."""
    graphs = []
    for name, gdef in GRAPHS.items():
        node_names = list(gdef["nodes"].keys())
        graphs.append({
            "name": name,
            "description": gdef["description"],
            "node_count": len(node_names),
            "nodes": node_names,
        })
    return {"graphs": graphs, "total": len(graphs)}


@router.post("/run/{graph_name}")
async def run_graph(graph_name: str, body: dict = None):
    """Run a reactive graph by name. Optional body: {initial_state: {...}}"""
    body = body or {}
    initial_state = body.get("initial_state", {})

    try:
        runner = ReactiveWorkflowRunner(graph_name, initial_state=initial_state)
    except ValueError as e:
        return JSONResponse({"error": str(e)}, status_code=404)

    try:
        result = await runner.run()
    except Exception as e:
        return JSONResponse({"error": f"Execution failed: {str(e)[:200]}"}, status_code=500)

    return result


@router.get("/history")
async def execution_history(
    limit: int = Query(50),
    graph: Optional[str] = Query(None),
):
    """Get execution history for reactive graphs from the activity DB."""
    from security import safe_limit
    limit = safe_limit(limit, 200)

    try:
        entries = aibrain_db.list_activity(limit=limit, category="reactive")
    except Exception as e:
        return JSONResponse({"error": f"Failed to query history: {str(e)[:200]}"}, status_code=500)

    # Filter by graph name if specified
    if graph:
        filtered = []
        for entry in entries:
            detail = entry.get("detail", "")
            try:
                detail_data = json.loads(detail) if isinstance(detail, str) else detail
                if entry.get("action", "") == f"reactive:{graph}":
                    entry["detail_parsed"] = detail_data
                    filtered.append(entry)
            except (json.JSONDecodeError, TypeError):
                if graph in entry.get("action", ""):
                    filtered.append(entry)
        entries = filtered
    else:
        # Parse detail JSON for all entries
        for entry in entries:
            try:
                if isinstance(entry.get("detail"), str):
                    entry["detail_parsed"] = json.loads(entry["detail"])
            except (json.JSONDecodeError, TypeError):
                pass

    return {"entries": entries, "count": len(entries)}


@router.get("/questions")
async def get_questions(limit: int = Query(10)):
    """Get top questions from the QuestionGenerator (pixel moment)."""
    questions = _question_generator.get_top_questions(limit)
    return {
        "questions": questions,
        "total_generated": len(_question_generator.questions),
        "count": len(questions),
    }


@router.get("/checkpoints")
async def list_checkpoints(limit: int = Query(20)):
    """List recent checkpoint runs."""
    runs = _checkpoint_store.list_runs(limit)
    return {"runs": runs, "count": len(runs)}
