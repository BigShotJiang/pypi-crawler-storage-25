"""
AIBrain Approval Queue — items that need human sign-off before execution.
Covers: email drafts, social posts, trades, deployments, any agent action needing approval.
"""

import json
import sqlite3
from datetime import datetime
from pathlib import Path


def get_approval_db(db_path: Path):
    db = sqlite3.connect(str(db_path))
    db.execute("PRAGMA journal_mode=wal")
    db.row_factory = sqlite3.Row
    db.execute("""
        CREATE TABLE IF NOT EXISTS approval_queue (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created TEXT NOT NULL,
            updated TEXT NOT NULL,
            category TEXT NOT NULL DEFAULT 'general',
            title TEXT NOT NULL,
            detail TEXT DEFAULT '',
            payload TEXT DEFAULT '{}',
            status TEXT NOT NULL DEFAULT 'pending',
            decided_at TEXT,
            decision_note TEXT DEFAULT ''
        )
    """)
    db.commit()
    return db


def add_item(db_path: Path, category: str, title: str, detail: str = "", payload: dict = None):
    """Add an item to the approval queue. Returns the new item ID."""
    db = get_approval_db(db_path)
    now = datetime.now().isoformat()
    cursor = db.execute(
        "INSERT INTO approval_queue (created, updated, category, title, detail, payload, status) VALUES (?, ?, ?, ?, ?, ?, 'pending')",
        (now, now, category, title, detail, json.dumps(payload or {})),
    )
    db.commit()
    item_id = cursor.lastrowid
    db.close()
    return item_id


def list_items(db_path: Path, status: str = None, category: str = None, limit: int = 50):
    """List approval queue items."""
    db = get_approval_db(db_path)
    query = "SELECT * FROM approval_queue WHERE 1=1"
    params = []
    if status:
        query += " AND status = ?"
        params.append(status)
    if category:
        query += " AND category = ?"
        params.append(category)
    query += " ORDER BY created DESC LIMIT ?"
    params.append(limit)
    rows = db.execute(query, params).fetchall()
    db.close()
    return [dict(r) for r in rows]


def get_item(db_path: Path, item_id: int):
    db = get_approval_db(db_path)
    row = db.execute("SELECT * FROM approval_queue WHERE id = ?", (item_id,)).fetchone()
    db.close()
    return dict(row) if row else None


def decide(db_path: Path, item_id: int, approved: bool, note: str = ""):
    """Approve or reject an item. Only transitions from pending — prevents double-decide race."""
    db = get_approval_db(db_path)
    now = datetime.now().isoformat()
    status = "approved" if approved else "rejected"
    cursor = db.execute(
        "UPDATE approval_queue SET status = ?, decided_at = ?, decision_note = ?, updated = ? WHERE id = ? AND status = 'pending'",
        (status, now, note, now, item_id),
    )
    db.commit()
    if cursor.rowcount == 0:
        db.close()
        # Either already decided or doesn't exist
        row = db.execute("SELECT status FROM approval_queue WHERE id = ?", (item_id,)).fetchone()
        db.close()
        already = row["status"] if row else "not_found"
        return {"id": item_id, "status": already, "error": "already_decided"}
    db.close()
    return {"id": item_id, "status": status, "decided_at": now}


def feedback(db_path: Path, item_id: int, note: str):
    """Return an item with feedback — keeps it pending but records operator's instructions."""
    db = get_approval_db(db_path)
    now = datetime.now().isoformat()
    db.execute(
        "UPDATE approval_queue SET status = 'feedback', decision_note = ?, updated = ? WHERE id = ?",
        (note, now, item_id),
    )
    db.commit()
    db.close()
    return {"id": item_id, "status": "feedback", "note": note, "updated_at": now}


def pending_count(db_path: Path):
    db = get_approval_db(db_path)
    row = db.execute("SELECT COUNT(*) as cnt FROM approval_queue WHERE status = 'pending'").fetchone()
    db.close()
    return row["cnt"] if row else 0


def summary(db_path: Path):
    db = get_approval_db(db_path)
    rows = db.execute(
        "SELECT status, COUNT(*) as cnt FROM approval_queue GROUP BY status"
    ).fetchall()
    db.close()
    return {r["status"]: r["cnt"] for r in rows}
