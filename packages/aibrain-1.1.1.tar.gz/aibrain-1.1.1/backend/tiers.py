"""
AIBrain Feature Tiers — Free/Pro/Team gating with license validation.

Usage:
    from tiers import require_tier, get_tier, is_feature_allowed, TierFeature

    # As a decorator on FastAPI routes
    @app.get("/api/agent/cloud-sync")
    @require_tier("pro")
    async def cloud_sync():
        ...

    # As a check in workflow code
    if is_feature_allowed(TierFeature.CLOUD_SYNC):
        sync_to_cloud()

    # In MCP servers — check before executing pro tools
    if not is_feature_allowed(TierFeature.IT_SUPPORT):
        return {"error": "Requires Pro tier", "upgrade_url": "https://myaibrain.org/pro"}

Tier is determined by:
    1. Valid license key (aibrain_licensing.py — cryptographic validation)
    2. Environment variable AIBRAIN_TIER (fallback for dev/testing)
    3. Config key "tier" in aibrain_db
    4. Default: "free"
"""

import functools
import logging
import os
from enum import Enum

logger = logging.getLogger(__name__)


class Tier(str, Enum):
    FREE = "free"
    PRO = "pro"
    TEAM = "team"
    ENTERPRISE = "enterprise"


class TierFeature(str, Enum):
    """Features gated by tier."""
    # ── Free tier ──
    LOCAL_MEMORY = "local_memory"
    BASIC_WORKFLOWS = "basic_workflows"
    MCP_MEMORY = "mcp_memory"
    DASHBOARD = "dashboard"
    APPROVAL_QUEUE = "approval_queue"
    WEB_SEARCH = "web_search"
    FILES_BASIC = "files_basic"
    CALENDAR_LOCAL = "calendar_local"

    # ── Pro tier ──
    PREMIUM_WORKFLOWS = "premium_workflows"
    IT_SUPPORT = "it_support"
    DESIGN = "design"
    CALENDAR_FULL = "calendar_full"
    DESKTOP_AUTOMATION = "desktop_automation"
    FILES_FULL = "files_full"
    PEER_DISCOVERY = "peer_discovery"
    SKILL_EVOLUTION = "skill_evolution"
    AUTO_EXPERIMENT = "auto_experiment"
    CLI_ANYTHING = "cli_anything"
    CLOUD_SYNC = "cloud_sync"
    ADVANCED_ANALYTICS = "advanced_analytics"
    CONTENT_GENERATION = "content_generation"
    MULTI_AGENT_OPS = "multi_agent_ops"
    MARKETPLACE_ACCESS = "marketplace_access"

    # ── Team tier ──
    TEAM_BRAINS = "team_brains"
    MESH_MERGE = "mesh_merge"
    MULTI_USER = "multi_user"
    TEAM_WORKFLOWS = "team_workflows"


# Map features to minimum required tier
_FEATURE_TIERS: dict[TierFeature, Tier] = {
    # Free
    TierFeature.LOCAL_MEMORY: Tier.FREE,
    TierFeature.BASIC_WORKFLOWS: Tier.FREE,
    TierFeature.MCP_MEMORY: Tier.FREE,
    TierFeature.DASHBOARD: Tier.FREE,
    TierFeature.APPROVAL_QUEUE: Tier.FREE,
    TierFeature.WEB_SEARCH: Tier.FREE,
    TierFeature.FILES_BASIC: Tier.FREE,
    TierFeature.CALENDAR_LOCAL: Tier.FREE,
    # Pro
    TierFeature.PREMIUM_WORKFLOWS: Tier.PRO,
    TierFeature.IT_SUPPORT: Tier.PRO,
    TierFeature.DESIGN: Tier.PRO,
    TierFeature.CALENDAR_FULL: Tier.PRO,
    TierFeature.DESKTOP_AUTOMATION: Tier.PRO,
    TierFeature.FILES_FULL: Tier.PRO,
    TierFeature.PEER_DISCOVERY: Tier.PRO,
    TierFeature.SKILL_EVOLUTION: Tier.PRO,
    TierFeature.AUTO_EXPERIMENT: Tier.PRO,
    TierFeature.CLI_ANYTHING: Tier.PRO,
    TierFeature.CLOUD_SYNC: Tier.PRO,
    TierFeature.ADVANCED_ANALYTICS: Tier.PRO,
    TierFeature.CONTENT_GENERATION: Tier.PRO,
    TierFeature.MULTI_AGENT_OPS: Tier.PRO,
    TierFeature.MARKETPLACE_ACCESS: Tier.PRO,
    # Team
    TierFeature.TEAM_BRAINS: Tier.TEAM,
    TierFeature.MESH_MERGE: Tier.TEAM,
    TierFeature.MULTI_USER: Tier.TEAM,
    TierFeature.TEAM_WORKFLOWS: Tier.TEAM,
}

# Tier hierarchy for comparison
_TIER_RANK: dict[Tier, int] = {
    Tier.FREE: 0,
    Tier.PRO: 1,
    Tier.TEAM: 2,
    Tier.ENTERPRISE: 3,
}

# Cache to avoid re-validating license on every call
_tier_cache: dict = {"tier": None, "checked_at": 0}
_CACHE_TTL = 300  # re-validate every 5 minutes


def get_tier() -> Tier:
    """Get the current tier with license validation."""
    import time
    now = time.time()

    # Return cached tier if fresh
    if _tier_cache["tier"] and (now - _tier_cache["checked_at"]) < _CACHE_TTL:
        return _tier_cache["tier"]

    tier = _resolve_tier()
    _tier_cache["tier"] = tier
    _tier_cache["checked_at"] = now
    return tier


def _resolve_tier() -> Tier:
    """Resolve tier from license key, env, or config."""
    # 1. License key validation (cryptographic — can't be faked)
    try:
        from aibrain_licensing import get_license
        license_info = get_license()
        if license_info and license_info.tier in ("pro", "team", "enterprise"):
            if license_info.valid and not license_info.is_expired:
                return Tier(license_info.tier)
            else:
                logger.warning("License key expired or invalid — falling back to free")
    except ImportError:
        pass
    except Exception as e:
        logger.debug("License check error: %s", e)

    # 2. Environment variable (dev/testing only)
    env_tier = os.environ.get("AIBRAIN_TIER", "").lower().strip()
    if env_tier in ("free", "pro", "team", "enterprise"):
        return Tier(env_tier)

    # 3. Config DB
    try:
        import aibrain_db
        db_tier = aibrain_db.config_get("tier", "free")
        if db_tier in ("free", "pro", "team", "enterprise"):
            return Tier(db_tier)
    except Exception:
        pass

    # 4. Default
    return Tier.FREE


def invalidate_cache():
    """Force re-check on next get_tier() call (after license key change)."""
    _tier_cache["tier"] = None
    _tier_cache["checked_at"] = 0


def is_feature_allowed(feature: TierFeature) -> bool:
    """Check if a feature is allowed under the current tier."""
    current = get_tier()
    required = _FEATURE_TIERS.get(feature, Tier.PRO)
    return _TIER_RANK[current] >= _TIER_RANK[required]


def require_tier(tier: str):
    """Decorator that gates a FastAPI route by tier.

    Returns 403 with upgrade message if tier is insufficient.
    """
    required = Tier(tier.lower())

    def decorator(func):
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            current = get_tier()
            if _TIER_RANK[current] < _TIER_RANK[required]:
                from fastapi.responses import JSONResponse
                return JSONResponse(
                    {
                        "error": f"Feature requires {required.value.title()} tier",
                        "current_tier": current.value,
                        "required_tier": required.value,
                        "upgrade_url": "https://myaibrain.org/pricing",
                    },
                    status_code=403,
                )
            return await func(*args, **kwargs)
        return wrapper
    return decorator


def check_tier(tier: str) -> bool:
    """Simple boolean check — is current tier >= required?"""
    required = Tier(tier.lower())
    current = get_tier()
    return _TIER_RANK[current] >= _TIER_RANK[required]


def tier_info() -> dict:
    """Return current tier info for the settings/status API."""
    current = get_tier()
    return {
        "current_tier": current.value,
        "features": {
            f.value: is_feature_allowed(f)
            for f in TierFeature
        },
        "free_features": [
            f.value for f, t in _FEATURE_TIERS.items() if t == Tier.FREE
        ],
        "pro_features": [
            f.value for f, t in _FEATURE_TIERS.items() if t == Tier.PRO
        ],
        "team_features": [
            f.value for f, t in _FEATURE_TIERS.items() if t == Tier.TEAM
        ],
        "pricing": {
            "pro": {"monthly": 9.95, "url": "https://myaibrain.org/pricing"},
            "team": {"monthly": 29.95, "url": "https://myaibrain.org/pricing"},
        },
    }
