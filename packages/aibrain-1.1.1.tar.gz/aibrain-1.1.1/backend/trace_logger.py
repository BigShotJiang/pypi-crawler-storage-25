"""
AIBrain Trace Logger — lightweight observability for agent actions.
Logs every LLM call, tool use, workflow run, and decision to SQLite.
Provides cost tracking, latency metrics, and trace timeline.
"""

import json
import os
import sqlite3
import time
from contextlib import contextmanager
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

AIBRAIN_ROOT = Path(os.environ.get("AIBRAIN_ROOT", Path(__file__).parent.parent))
TRACE_DB_PATH = AIBRAIN_ROOT / "trace.db"

# Model cost per 1M tokens (input/output) in USD — updated March 2026
MODEL_COSTS = {
    # Claude
    "claude-opus-4-6": (15.0, 75.0),
    "claude-sonnet-4-6": (3.0, 15.0),
    "claude-haiku-4-5-20251001": (0.80, 4.0),
    "claude-sonnet-4-20250514": (3.0, 15.0),
    # OpenAI
    "gpt-4o": (2.50, 10.0),
    "gpt-4o-mini": (0.15, 0.60),
    "gpt-4-turbo": (10.0, 30.0),
    "o1": (15.0, 60.0),
    "o1-mini": (3.0, 12.0),
    "o3-mini": (1.10, 4.40),
    # Ollama/local — free
    "llama3.2": (0, 0),
    "llama3.1": (0, 0),
    "mistral": (0, 0),
    "mixtral": (0, 0),
    "codellama": (0, 0),
    "phi3": (0, 0),
    "gemma2": (0, 0),
    "qwen2.5": (0, 0),
    "deepseek-r1": (0, 0),
}


def _get_db():
    db = sqlite3.connect(str(TRACE_DB_PATH))
    db.execute("PRAGMA journal_mode=wal")
    db.row_factory = sqlite3.Row
    db.execute("""
        CREATE TABLE IF NOT EXISTS traces (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            trace_type TEXT NOT NULL,
            model TEXT DEFAULT '',
            provider TEXT DEFAULT '',
            tokens_in INTEGER DEFAULT 0,
            tokens_out INTEGER DEFAULT 0,
            cost_usd REAL DEFAULT 0.0,
            latency_ms INTEGER DEFAULT 0,
            workflow_id TEXT DEFAULT '',
            action TEXT DEFAULT '',
            detail TEXT DEFAULT '',
            status TEXT DEFAULT 'ok',
            metadata TEXT DEFAULT '{}'
        )
    """)
    db.execute("""
        CREATE INDEX IF NOT EXISTS idx_traces_timestamp ON traces(timestamp)
    """)
    db.execute("""
        CREATE INDEX IF NOT EXISTS idx_traces_type ON traces(trace_type)
    """)
    db.commit()
    return db


def estimate_cost(model: str, tokens_in: int, tokens_out: int) -> float:
    """Estimate USD cost for a model call."""
    costs = MODEL_COSTS.get(model)
    if not costs:
        # Try partial match
        for key, val in MODEL_COSTS.items():
            if key in model or model in key:
                costs = val
                break
    if not costs:
        return 0.0
    input_cost = (tokens_in / 1_000_000) * costs[0]
    output_cost = (tokens_out / 1_000_000) * costs[1]
    return round(input_cost + output_cost, 6)


def log_trace(
    trace_type: str,
    model: str = "",
    provider: str = "",
    tokens_in: int = 0,
    tokens_out: int = 0,
    latency_ms: int = 0,
    workflow_id: str = "",
    action: str = "",
    detail: str = "",
    status: str = "ok",
    metadata: dict = None,
):
    """Log a trace entry."""
    cost = estimate_cost(model, tokens_in, tokens_out) if model else 0.0
    db = _get_db()
    db.execute(
        """INSERT INTO traces
        (timestamp, trace_type, model, provider, tokens_in, tokens_out, cost_usd,
         latency_ms, workflow_id, action, detail, status, metadata)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            datetime.now().isoformat(),
            trace_type,
            model,
            provider,
            tokens_in,
            tokens_out,
            cost,
            latency_ms,
            workflow_id,
            action,
            detail[:2000],
            status,
            json.dumps(metadata or {}),
        ),
    )
    db.commit()
    db.close()
    return cost


@contextmanager
def trace_llm_call(model: str, provider: str, workflow_id: str = "", action: str = ""):
    """Context manager that auto-logs an LLM call with timing."""
    start = time.time()
    result = {"tokens_in": 0, "tokens_out": 0, "status": "ok", "detail": ""}
    try:
        yield result
    except Exception as e:
        result["status"] = "error"
        result["detail"] = str(e)[:500]
        raise
    finally:
        latency = int((time.time() - start) * 1000)
        log_trace(
            trace_type="llm_call",
            model=model,
            provider=provider,
            tokens_in=result.get("tokens_in", 0),
            tokens_out=result.get("tokens_out", 0),
            latency_ms=latency,
            workflow_id=workflow_id,
            action=action,
            detail=result.get("detail", ""),
            status=result["status"],
        )


def log_workflow_run(workflow_id: str, status: str = "ok", detail: str = "", latency_ms: int = 0):
    """Log a workflow execution."""
    log_trace(
        trace_type="workflow_run",
        workflow_id=workflow_id,
        action=f"run:{workflow_id}",
        detail=detail,
        status=status,
        latency_ms=latency_ms,
    )


def log_tool_use(tool_name: str, detail: str = "", status: str = "ok", latency_ms: int = 0):
    """Log a tool/skill invocation."""
    log_trace(
        trace_type="tool_use",
        action=tool_name,
        detail=detail,
        status=status,
        latency_ms=latency_ms,
    )


# ---------------------------------------------------------------------------
# Query functions for the dashboard
# ---------------------------------------------------------------------------

def get_cost_summary(days: int = 30) -> dict:
    """Total costs over the last N days."""
    db = _get_db()
    cutoff = (datetime.now() - timedelta(days=days)).isoformat()

    total = db.execute(
        "SELECT COALESCE(SUM(cost_usd), 0) as total FROM traces WHERE timestamp > ?", (cutoff,)
    ).fetchone()["total"]

    by_model = db.execute(
        """SELECT model, SUM(cost_usd) as cost, SUM(tokens_in) as tin, SUM(tokens_out) as tout, COUNT(*) as calls
        FROM traces WHERE timestamp > ? AND model != '' GROUP BY model ORDER BY cost DESC""",
        (cutoff,)
    ).fetchall()

    by_provider = db.execute(
        """SELECT provider, SUM(cost_usd) as cost, COUNT(*) as calls
        FROM traces WHERE timestamp > ? AND provider != '' GROUP BY provider ORDER BY cost DESC""",
        (cutoff,)
    ).fetchall()

    db.close()
    return {
        "total_cost_usd": round(total, 4),
        "period_days": days,
        "by_model": [dict(r) for r in by_model],
        "by_provider": [dict(r) for r in by_provider],
    }


def get_cost_daily(days: int = 30) -> list:
    """Daily cost breakdown for charting."""
    db = _get_db()
    cutoff = (datetime.now() - timedelta(days=days)).isoformat()

    rows = db.execute(
        """SELECT DATE(timestamp) as day, SUM(cost_usd) as cost, COUNT(*) as calls,
           SUM(tokens_in) as tokens_in, SUM(tokens_out) as tokens_out
        FROM traces WHERE timestamp > ? GROUP BY DATE(timestamp) ORDER BY day""",
        (cutoff,)
    ).fetchall()
    db.close()
    return [dict(r) for r in rows]


def get_cost_by_workflow(days: int = 30) -> list:
    """Cost breakdown by workflow."""
    db = _get_db()
    cutoff = (datetime.now() - timedelta(days=days)).isoformat()

    rows = db.execute(
        """SELECT workflow_id, SUM(cost_usd) as cost, COUNT(*) as calls,
           SUM(tokens_in) as tokens_in, SUM(tokens_out) as tokens_out
        FROM traces WHERE timestamp > ? AND workflow_id != '' GROUP BY workflow_id ORDER BY cost DESC""",
        (cutoff,)
    ).fetchall()
    db.close()
    return [dict(r) for r in rows]


def get_recent_traces(limit: int = 50, trace_type: Optional[str] = None) -> list:
    """Get recent traces for the timeline view."""
    db = _get_db()
    if trace_type:
        rows = db.execute(
            "SELECT * FROM traces WHERE trace_type = ? ORDER BY timestamp DESC LIMIT ?",
            (trace_type, limit)
        ).fetchall()
    else:
        rows = db.execute(
            "SELECT * FROM traces ORDER BY timestamp DESC LIMIT ?", (limit,)
        ).fetchall()
    db.close()
    return [dict(r) for r in rows]


def get_trace_stats() -> dict:
    """Overall trace statistics."""
    db = _get_db()

    total = db.execute("SELECT COUNT(*) as c FROM traces").fetchone()["c"]
    total_cost = db.execute("SELECT COALESCE(SUM(cost_usd), 0) as c FROM traces").fetchone()["c"]
    avg_latency = db.execute(
        "SELECT COALESCE(AVG(latency_ms), 0) as avg FROM traces WHERE trace_type = 'llm_call'"
    ).fetchone()["avg"]

    by_type = db.execute(
        "SELECT trace_type, COUNT(*) as c FROM traces GROUP BY trace_type"
    ).fetchall()

    errors = db.execute(
        "SELECT COUNT(*) as c FROM traces WHERE status = 'error'"
    ).fetchone()["c"]

    db.close()
    return {
        "total_traces": total,
        "total_cost_usd": round(total_cost, 4),
        "avg_latency_ms": round(avg_latency),
        "error_count": errors,
        "error_rate": round(errors / max(total, 1) * 100, 1),
        "by_type": {r["trace_type"]: r["c"] for r in by_type},
    }
