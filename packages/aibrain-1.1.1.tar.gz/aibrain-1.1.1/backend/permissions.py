"""
AIBrain Permissions — Playwright-style three-tier permission system.

Every agent action checks permissions before executing:
  - allow_once:  execute this time, ask again next time
  - allow_always: auto-approve this action type forever
  - deny:        block, don't ask again (until changed in settings)
  - ask:         (default) route to approval queue, user decides

Permissions are scoped by:
  - action_type: the category of action (e.g., 'send_email', 'browser_navigate', 'file_delete')
  - target:      optional qualifier (e.g., 'indeed.com', 'user@example.com')
  - context:     optional extra scope (e.g., project_id, application_id)

Users configure permissions via the UI settings page or API.
"""

import json
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Optional


def get_permissions_db(db_path: Path):
    """Open or create the permissions tables in the consolidated DB."""
    db = sqlite3.connect(str(db_path))
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA journal_mode=WAL")
    db.executescript("""
        CREATE TABLE IF NOT EXISTS agent_permissions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            action_type TEXT NOT NULL,       -- 'send_email', 'browser_navigate', 'execute_script', etc.
            target TEXT DEFAULT '*',         -- specific target or '*' for all
            permission TEXT NOT NULL,        -- 'allow_always', 'allow_once', 'deny', 'ask'
            granted_by TEXT DEFAULT 'user',  -- who set this permission
            expires_at TIMESTAMP,            -- NULL = never expires, set for allow_once
            use_count INTEGER DEFAULT 0,     -- how many times this permission has been used
            last_used_at TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            notes TEXT                       -- why this permission was set
        );

        CREATE TABLE IF NOT EXISTS permission_audit_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            action_type TEXT NOT NULL,
            target TEXT,
            permission_id INTEGER,           -- which permission rule matched
            decision TEXT NOT NULL,           -- 'allowed', 'denied', 'queued'
            reason TEXT,                     -- why this decision was made
            context TEXT,                    -- JSON with extra context
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE UNIQUE INDEX IF NOT EXISTS idx_perm_action_target
            ON agent_permissions(action_type, target)
            WHERE permission != 'allow_once';  -- allow uniqueness except for one-time grants

        CREATE INDEX IF NOT EXISTS idx_perm_action ON agent_permissions(action_type);
        CREATE INDEX IF NOT EXISTS idx_audit_action ON permission_audit_log(action_type, created_at);
    """)
    return db


# ---------------------------------------------------------------------------
# Standard action types — the taxonomy of things agents can do
# ---------------------------------------------------------------------------

ACTION_TYPES = {
    # Communication
    "send_email":        {"category": "communication", "risk": "high",   "default": "ask",    "description": "Send an email to an external party"},
    "reply_email":       {"category": "communication", "risk": "high",   "default": "ask",    "description": "Reply to an email thread"},
    "send_telegram":     {"category": "communication", "risk": "medium", "default": "allow_always", "description": "Send a Telegram message"},
    "post_social":       {"category": "communication", "risk": "high",   "default": "ask",    "description": "Post to social media (LinkedIn, X, etc.)"},

    # Browser
    "browser_navigate":  {"category": "browser",       "risk": "low",    "default": "allow_always", "description": "Navigate to a URL in the browser"},
    "browser_login":     {"category": "browser",       "risk": "medium", "default": "ask",    "description": "Log into a website"},
    "browser_submit":    {"category": "browser",       "risk": "high",   "default": "ask",    "description": "Submit a form on a website"},
    "browser_click":     {"category": "browser",       "risk": "low",    "default": "allow_always", "description": "Click an element on a page"},

    # Files
    "file_read":         {"category": "filesystem",    "risk": "low",    "default": "allow_always", "description": "Read a file"},
    "file_write":        {"category": "filesystem",    "risk": "medium", "default": "allow_always", "description": "Write or create a file"},
    "file_delete":       {"category": "filesystem",    "risk": "high",   "default": "ask",    "description": "Delete a file"},

    # System
    "execute_script":    {"category": "system",        "risk": "medium", "default": "ask",    "description": "Execute a script or command"},
    "install_package":   {"category": "system",        "risk": "medium", "default": "ask",    "description": "Install a package or dependency"},
    "git_push":          {"category": "system",        "risk": "medium", "default": "allow_always", "description": "Push to a git remote"},
    "docker_action":     {"category": "system",        "risk": "medium", "default": "ask",    "description": "Start/stop/manage Docker containers"},

    # Financial
    "spend_money":       {"category": "financial",     "risk": "critical","default": "deny",   "description": "Commit any expenditure"},
    "execute_trade":     {"category": "financial",     "risk": "critical","default": "ask",    "description": "Execute a financial trade"},

    # Job actions
    "apply_job":         {"category": "job",           "risk": "high",   "default": "ask",    "description": "Submit a job application"},
    "follow_up_job":     {"category": "job",           "risk": "high",   "default": "ask",    "description": "Send a follow-up email about a job"},
    "research_company":  {"category": "job",           "risk": "low",    "default": "allow_always", "description": "Research a company online"},
    "check_portal":      {"category": "job",           "risk": "low",    "default": "allow_always", "description": "Check a job portal for status updates"},

    # Agent
    "go_autonomous":     {"category": "agent",         "risk": "high",   "default": "ask",    "description": "Enter autonomous mode on a project"},
    "spawn_subagent":    {"category": "agent",         "risk": "low",    "default": "allow_always", "description": "Spawn a background subagent"},
    "modify_workflow":   {"category": "agent",         "risk": "medium", "default": "ask",    "description": "Modify a workflow or cron job"},
    "modify_memory":     {"category": "agent",         "risk": "low",    "default": "allow_always", "description": "Create or update a memory entry"},

    # Scanning
    "scan_internal":     {"category": "security",      "risk": "low",    "default": "allow_always", "description": "Scan an internal/owned target"},
    "scan_external":     {"category": "security",      "risk": "high",   "default": "ask",    "description": "Scan an external target"},
}


# ---------------------------------------------------------------------------
# Permission Checking — the core function
# ---------------------------------------------------------------------------

def check_permission(db_path: Path, action_type: str, target: str = "*",
                     context: dict = None) -> dict:
    """Check if an action is permitted.

    Returns:
        {
            "allowed": bool,
            "decision": "allowed" | "denied" | "queued",
            "reason": str,
            "permission_id": int | None,
        }
    """
    db = get_permissions_db(db_path)
    now = datetime.utcnow().isoformat()

    # 1. Check for specific target permission first
    rule = db.execute(
        """SELECT * FROM agent_permissions
           WHERE action_type = ? AND target = ?
           AND (expires_at IS NULL OR expires_at > ?)
           ORDER BY created_at DESC LIMIT 1""",
        (action_type, target, now)
    ).fetchone()

    # 2. Fall back to wildcard permission
    if not rule:
        rule = db.execute(
            """SELECT * FROM agent_permissions
               WHERE action_type = ? AND target = '*'
               AND (expires_at IS NULL OR expires_at > ?)
               ORDER BY created_at DESC LIMIT 1""",
            (action_type, now)
        ).fetchone()

    # 3. Fall back to action type default
    if not rule:
        default = ACTION_TYPES.get(action_type, {}).get("default", "ask")
        result = _decide(default, action_type, "default_policy")
        _log_audit(db, action_type, target, None, result["decision"],
                   result["reason"], context)
        db.commit()
        db.close()
        return result

    # Apply the permission rule
    perm = rule["permission"]
    perm_id = rule["id"]

    if perm == "allow_always":
        # Update use count
        db.execute(
            "UPDATE agent_permissions SET use_count = use_count + 1, last_used_at = ? WHERE id = ?",
            (now, perm_id)
        )
        result = {"allowed": True, "decision": "allowed",
                  "reason": f"Allowed by rule #{perm_id} (allow_always)", "permission_id": perm_id}

    elif perm == "allow_once":
        # Use it and expire it
        db.execute(
            "UPDATE agent_permissions SET use_count = use_count + 1, last_used_at = ?, expires_at = ? WHERE id = ?",
            (now, now, perm_id)
        )
        result = {"allowed": True, "decision": "allowed",
                  "reason": f"Allowed by rule #{perm_id} (allow_once, now expired)", "permission_id": perm_id}

    elif perm == "deny":
        result = {"allowed": False, "decision": "denied",
                  "reason": f"Denied by rule #{perm_id}", "permission_id": perm_id}

    else:  # "ask"
        result = {"allowed": False, "decision": "queued",
                  "reason": f"Requires approval (rule #{perm_id})", "permission_id": perm_id}

    _log_audit(db, action_type, target, perm_id, result["decision"],
               result["reason"], context)
    db.commit()
    db.close()
    return result


def _decide(default: str, action_type: str, source: str) -> dict:
    """Convert a default policy to a decision result."""
    if default == "allow_always":
        return {"allowed": True, "decision": "allowed",
                "reason": f"Default policy for {action_type}: allow_always ({source})",
                "permission_id": None}
    elif default == "deny":
        return {"allowed": False, "decision": "denied",
                "reason": f"Default policy for {action_type}: deny ({source})",
                "permission_id": None}
    else:  # "ask"
        return {"allowed": False, "decision": "queued",
                "reason": f"Default policy for {action_type}: ask ({source})",
                "permission_id": None}


def _log_audit(db, action_type, target, permission_id, decision, reason, context):
    """Log a permission decision to the audit trail."""
    db.execute(
        """INSERT INTO permission_audit_log
           (action_type, target, permission_id, decision, reason, context)
           VALUES (?, ?, ?, ?, ?, ?)""",
        (action_type, target, permission_id, decision, reason,
         json.dumps(context) if context else None)
    )


# ---------------------------------------------------------------------------
# Permission Management
# ---------------------------------------------------------------------------

def set_permission(db_path: Path, action_type: str, permission: str,
                   target: str = "*", granted_by: str = "user",
                   notes: str = None, expires_at: str = None) -> int:
    """Set a permission rule. Upserts for the same action_type+target combo."""
    if permission not in ("allow_always", "allow_once", "deny", "ask"):
        raise ValueError(f"Invalid permission: {permission}")

    db = get_permissions_db(db_path)
    now = datetime.utcnow().isoformat()

    # For allow_once, always insert a new row (don't upsert)
    if permission == "allow_once":
        cur = db.execute(
            """INSERT INTO agent_permissions
               (action_type, target, permission, granted_by, notes, expires_at, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (action_type, target, permission, granted_by, notes, expires_at, now)
        )
    else:
        # Upsert — update if exists, insert if not
        existing = db.execute(
            "SELECT id FROM agent_permissions WHERE action_type = ? AND target = ? AND permission != 'allow_once'",
            (action_type, target)
        ).fetchone()

        if existing:
            db.execute(
                """UPDATE agent_permissions
                   SET permission = ?, granted_by = ?, notes = ?, expires_at = ?, updated_at = ?
                   WHERE id = ?""",
                (permission, granted_by, notes, expires_at, now, existing["id"])
            )
            cur = existing
        else:
            cur = db.execute(
                """INSERT INTO agent_permissions
                   (action_type, target, permission, granted_by, notes, expires_at, updated_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (action_type, target, permission, granted_by, notes, expires_at, now)
            )

    db.commit()
    perm_id = cur.lastrowid if hasattr(cur, 'lastrowid') else cur["id"]
    db.close()
    return perm_id


def list_permissions(db_path: Path, category: str = None,
                     action_type: str = None) -> list:
    """List all active permission rules."""
    db = get_permissions_db(db_path)
    where = ["(expires_at IS NULL OR expires_at > ?)"]
    params = [datetime.utcnow().isoformat()]

    if action_type:
        where.append("action_type = ?")
        params.append(action_type)

    rows = db.execute(
        f"SELECT * FROM agent_permissions WHERE {' AND '.join(where)} ORDER BY action_type, target",
        params
    ).fetchall()
    db.close()

    results = [dict(r) for r in rows]

    # Filter by category if requested
    if category:
        results = [r for r in results
                   if ACTION_TYPES.get(r["action_type"], {}).get("category") == category]

    return results


def delete_permission(db_path: Path, permission_id: int):
    """Delete a permission rule."""
    db = get_permissions_db(db_path)
    db.execute("DELETE FROM agent_permissions WHERE id = ?", (permission_id,))
    db.commit()
    db.close()


def get_audit_log(db_path: Path, action_type: str = None,
                  limit: int = 50) -> list:
    """Get recent permission audit entries."""
    db = get_permissions_db(db_path)
    if action_type:
        rows = db.execute(
            "SELECT * FROM permission_audit_log WHERE action_type = ? ORDER BY created_at DESC LIMIT ?",
            (action_type, limit)
        ).fetchall()
    else:
        rows = db.execute(
            "SELECT * FROM permission_audit_log ORDER BY created_at DESC LIMIT ?",
            (limit,)
        ).fetchall()
    db.close()
    return [dict(r) for r in rows]


def get_permission_summary(db_path: Path) -> dict:
    """Get a summary of all permissions grouped by category."""
    db = get_permissions_db(db_path)
    now = datetime.utcnow().isoformat()

    # Active rules
    rules = db.execute(
        """SELECT action_type, target, permission
           FROM agent_permissions
           WHERE expires_at IS NULL OR expires_at > ?""",
        (now,)
    ).fetchall()

    # Recent audit
    recent_denied = db.execute(
        "SELECT COUNT(*) as cnt FROM permission_audit_log WHERE decision = 'denied' AND created_at > ?",
        ((datetime.utcnow() - __import__('datetime').timedelta(hours=24)).isoformat(),)
    ).fetchone()["cnt"]

    recent_queued = db.execute(
        "SELECT COUNT(*) as cnt FROM permission_audit_log WHERE decision = 'queued' AND created_at > ?",
        ((datetime.utcnow() - __import__('datetime').timedelta(hours=24)).isoformat(),)
    ).fetchone()["cnt"]

    db.close()

    # Group by category
    by_category = {}
    for r in rules:
        cat = ACTION_TYPES.get(r["action_type"], {}).get("category", "other")
        if cat not in by_category:
            by_category[cat] = {"allow_always": 0, "allow_once": 0, "deny": 0, "ask": 0}
        by_category[cat][r["permission"]] += 1

    # Build default permissions map for action types without explicit rules
    configured = {r["action_type"] for r in rules}
    defaults = {}
    for action, info in ACTION_TYPES.items():
        if action not in configured:
            defaults[action] = info["default"]

    return {
        "active_rules": len(rules),
        "by_category": by_category,
        "unconfigured_defaults": defaults,
        "recent_denied_24h": recent_denied,
        "recent_queued_24h": recent_queued,
    }
