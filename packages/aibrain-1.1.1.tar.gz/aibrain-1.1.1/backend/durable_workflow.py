"""
DurableWorkflow — step-level retry with SQLite persistence.
Each workflow run tracks individual steps so that on failure/restart,
completed steps are skipped and only pending/failed steps re-execute.
"""

import asyncio
import inspect
import json
import sqlite3
from datetime import datetime
from uuid import uuid4


class DurableWorkflow:
    def __init__(self, workflow_id: str, db_path: str = "aibrain.db"):
        self.workflow_id = workflow_id
        self.db_path = db_path
        self._ensure_table()

    def _ensure_table(self):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS workflow_steps (
                    workflow_id TEXT,
                    step_name TEXT,
                    result TEXT,
                    error TEXT,
                    status TEXT DEFAULT 'pending',
                    attempt INTEGER DEFAULT 0,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    completed_at DATETIME,
                    PRIMARY KEY (workflow_id, step_name)
                )
            """)

    async def step(self, step_name: str, fn, max_retries: int = 3):
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            existing = conn.execute(
                "SELECT result, status, attempt FROM workflow_steps WHERE workflow_id=? AND step_name=?",
                (self.workflow_id, step_name)
            ).fetchone()

            if existing and existing["status"] == "completed":
                return json.loads(existing["result"])

            attempt = existing["attempt"] if existing else 0
            while attempt < max_retries:
                try:
                    result = await fn() if inspect.iscoroutinefunction(fn) else fn()
                    conn.execute(
                        "INSERT OR REPLACE INTO workflow_steps "
                        "(workflow_id, step_name, result, status, attempt, completed_at) "
                        "VALUES (?, ?, ?, 'completed', ?, CURRENT_TIMESTAMP)",
                        (self.workflow_id, step_name, json.dumps(result), attempt + 1)
                    )
                    conn.commit()
                    return result
                except Exception as e:
                    attempt += 1
                    conn.execute(
                        "INSERT OR REPLACE INTO workflow_steps "
                        "(workflow_id, step_name, error, status, attempt) "
                        "VALUES (?, ?, ?, 'failed', ?)",
                        (self.workflow_id, step_name, str(e), attempt)
                    )
                    conn.commit()
                    if attempt >= max_retries:
                        raise

    @staticmethod
    def get_run_history(db_path: str = "aibrain.db", workflow_id: str = None, limit: int = 50):
        with sqlite3.connect(db_path) as conn:
            conn.row_factory = sqlite3.Row
            if workflow_id:
                rows = conn.execute(
                    "SELECT * FROM workflow_steps WHERE workflow_id=? ORDER BY created_at DESC LIMIT ?",
                    (workflow_id, limit)
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM workflow_steps ORDER BY created_at DESC LIMIT ?",
                    (limit,)
                ).fetchall()
            return [dict(r) for r in rows]
