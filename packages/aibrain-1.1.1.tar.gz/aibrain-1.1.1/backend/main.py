"""
AIBrain Backend — FastAPI server for the portable AI brain.
Serves memory DB, cron registry, skills, agent status, workflow groups,
built-in scheduler, approval queue, and chat WebSocket.
"""

import asyncio
import json
import logging
import os
import sys
from contextlib import asynccontextmanager
from datetime import datetime
from pathlib import Path
from typing import Optional

import time as _time

from fastapi import FastAPI, Query, Request, UploadFile, WebSocket, WebSocketDisconnect

logger = logging.getLogger(__name__)

# Track server start time for uptime calculation
_server_start_time = _time.monotonic()

# Structured logging — JSON for production, readable for dev
_log_format = os.environ.get("LOG_FORMAT", "text")
if _log_format == "json":
    import json as _json_mod
    class _JsonFormatter(logging.Formatter):
        def format(self, record):
            return _json_mod.dumps({
                "ts": self.formatTime(record), "level": record.levelname,
                "logger": record.name, "msg": record.getMessage(),
            }, default=str)
    _handler = logging.StreamHandler()
    _handler.setFormatter(_JsonFormatter())
    logging.root.handlers = [_handler]
    logging.root.setLevel(logging.INFO)
else:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )

from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

# ---------------------------------------------------------------------------
# Consolidated DB + Scheduler imports
# ---------------------------------------------------------------------------
AIBRAIN_ROOT = Path(os.environ.get("AIBRAIN_ROOT", Path(__file__).parent.parent))
sys.path.insert(0, str(AIBRAIN_ROOT))
sys.path.insert(0, str(Path(__file__).parent))
import aibrain_db

from scheduler import init_scheduler, reload_jobs, get_scheduler_status, shutdown_scheduler
from action_executor import execute_approved_action

# Legacy — kept for backward compat with approval_queue module
from approval_queue import (
    add_item as aq_add, list_items as aq_list, get_item as aq_get,
    decide as aq_decide, pending_count as aq_pending, summary as aq_summary,
    feedback as aq_feedback,
)
APPROVAL_DB = AIBRAIN_ROOT / "approval.db"
CRON_JOBS_PATH = AIBRAIN_ROOT / "scheduled_jobs.json"


# ---------------------------------------------------------------------------
# Lifespan — start/stop scheduler with the server
# ---------------------------------------------------------------------------
_broker_poll_task = None

async def _poll_broker_for_chat():
    """Background task: poll broker for messages and push to chat."""
    if not _BROKER_URL:
        return
    while True:
        try:
            await asyncio.sleep(3)
            replies = await asyncio.to_thread(_check_broker_replies, _CHAT_AGENT_ID)
            for r in replies:
                from_agent = r.get("from_agent", "unknown")
                content = r.get("content", "")
                if content and from_agent != _CHAT_AGENT_ID:
                    agent_msg = {
                        "type": "message",
                        "role": "agent",
                        "from": from_agent,
                        "content": content,
                        "timestamp": datetime.now().isoformat(),
                    }
                    _chat_history.append(agent_msg)
                    if len(_chat_history) > _MAX_HISTORY:
                        _chat_history[:] = _chat_history[-_MAX_HISTORY:]
                    await _broadcast_chat(agent_msg)
        except asyncio.CancelledError:
            break
        except Exception as e:
            logger.warning("Broker poll error: %s", e)
            await asyncio.sleep(10)


@asynccontextmanager
async def lifespan(app):
    global _broker_poll_task
    # Startup: launch the built-in scheduler
    if CRON_JOBS_PATH.exists():
        init_scheduler(AIBRAIN_ROOT, CRON_JOBS_PATH)
        logger.info("Scheduler started — reading %s", CRON_JOBS_PATH)
    # Start broker poll for chat messages
    _broker_poll_task = asyncio.create_task(_poll_broker_for_chat())
    logger.info("Broker chat poll started — checking every 3s for messages")
    yield
    # Shutdown
    if _broker_poll_task:
        _broker_poll_task.cancel()
    shutdown_scheduler()
    logger.info("Scheduler stopped")


app = FastAPI(title="AIBrain API", version="0.9.0", lifespan=lifespan)

_cors_origins = os.environ.get("AIBRAIN_CORS_ORIGINS", "").strip()
if _cors_origins == "*":
    # Wildcard CORS with credentials is insecure — fall back to localhost
    import logging as _log
    _log.getLogger(__name__).warning("AIBRAIN_CORS_ORIGINS=* is insecure with credentials. Using localhost only.")
    _allowed = ["http://localhost:5173", "http://localhost:5174", "http://localhost:3000", "http://localhost:8001"]
elif _cors_origins:
    _allowed = [o.strip() for o in _cors_origins.split(",")]
else:
    _allowed = ["http://localhost:5173", "http://localhost:5174", "http://localhost:3000", "http://localhost:8001"]

app.add_middleware(
    CORSMiddleware,
    allow_origins=_allowed,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["Content-Type", "Authorization", "X-API-Key", "X-Request-ID"],
)

# Request ID for tracing, then auth, then rate limiting (outermost → innermost)
from security import RateLimitMiddleware, AuthMiddleware, RequestIdMiddleware
app.add_middleware(RequestIdMiddleware)
app.add_middleware(AuthMiddleware)

# Rate limiting — 60 req/min general, 10 req/min for auth/approval endpoints
app.add_middleware(RateLimitMiddleware, general_rpm=60, auth_rpm=10)

from aibrain_api import router as aibrain_router, set_notify_callback
app.include_router(aibrain_router)

from reactive_workflows import router as reactive_router, set_notify_callback as set_reactive_notify
app.include_router(reactive_router)

from pattern_bus_api import router as pattern_bus_router
app.include_router(pattern_bus_router)

from setup_api import router as setup_router
app.include_router(setup_router)

# Memory REST API — no-MCP mode (mirrors MCP memory tools as plain REST endpoints)
try:
    from memory_api import router as memory_api_router
    app.include_router(memory_api_router)
    logger.info("Memory REST API loaded (no-MCP mode: /api/memory/*)")
except Exception as _mae:
    logger.error("Memory REST API FAILED: %s", _mae)

# Cross-domain question generator (Pixel Moment substrate)
import sys as _sys
_wf_path = str(Path(__file__).resolve().parent.parent / "workflows")
if _wf_path not in _sys.path:
    _sys.path.insert(0, _wf_path)
try:
    from cross_domain_questions import create_router as create_questions_router
    _qr = create_questions_router()
    app.include_router(_qr)
    logger.info("Cross-domain questions router loaded (%d routes)", len(_qr.routes))
except Exception as _qe:
    logger.error("Cross-domain questions router FAILED: %s", _qe)

from chat_responder import get_response as llm_respond
from webhooks import router as webhooks_router
app.include_router(webhooks_router, prefix="/api/agent")

try:
    from critic_generator import create_router as create_critic_router
    app.include_router(create_critic_router())
    logger.info("Critic-generator router loaded")
except Exception as _cge:
    logger.error("Critic-generator router FAILED: %s", _cge)


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------
@app.get("/health")
async def health():
    pending = aq_pending(APPROVAL_DB)
    sched = get_scheduler_status()

    # Check memory DB accessibility
    db_path = AIBRAIN_ROOT / "aibrain.db"
    memory_db_ok = False
    try:
        if db_path.exists():
            import sqlite3 as _sqlite3
            conn = _sqlite3.connect(str(db_path), timeout=2)
            conn.execute("SELECT 1")
            conn.close()
            memory_db_ok = True
    except Exception:
        pass

    return {
        "status": "ok",
        "service": "aibrain-backend",
        "version": "1.0.1",
        "timestamp": datetime.now().isoformat(),
        "uptime_seconds": round(_time.monotonic() - _server_start_time, 1),
        "memory_db": {"accessible": memory_db_ok, "path": str(db_path)},
        "scheduler": {"running": sched["running"], "jobs": sched["job_count"]},
        "pending_approvals": pending,
    }


@app.get("/api/health")
async def api_health():
    """Lightweight health probe — always returns 200 if the process is alive."""
    return {"status": "healthy", "timestamp": datetime.now().isoformat()}


@app.get("/api/ready")
async def api_ready():
    """Readiness probe — checks SQLite connectivity and scheduler status."""
    checks = {}

    # Check 1: SQLite connection
    try:
        import sqlite3 as _sqlite3
        db_path = str(AIBRAIN_ROOT / "aibrain.db")
        conn = _sqlite3.connect(db_path, timeout=2)
        conn.execute("SELECT 1")
        conn.close()
        checks["sqlite"] = True
    except Exception as e:
        checks["sqlite"] = False

    # Check 2: Scheduler running
    try:
        sched = get_scheduler_status()
        checks["scheduler"] = sched.get("running", False)
    except Exception as e:
        logger.warning("Scheduler health check failed: %s", e)
        checks["scheduler"] = False

    ready = all(checks.values())
    return {"ready": ready, "checks": checks}


@app.get("/api/health/deep")
async def deep_health():
    """Comprehensive health check — tests all subsystems."""
    checks = {}

    # Memory DB
    try:
        from aibrain_api import get_db
        db = get_db()
        count = db.execute("SELECT COUNT(*) FROM memories WHERE active = 1").fetchone()[0]
        db.close()
        checks["memory_db"] = {"ok": True, "memories": count}
    except Exception as e:
        checks["memory_db"] = {"ok": False, "error": str(e)[:100]}

    # Scheduler
    try:
        sched = get_scheduler_status()
        checks["scheduler"] = {"ok": sched["running"], "jobs": sched["job_count"]}
    except Exception as e:
        checks["scheduler"] = {"ok": False, "error": str(e)[:100]}

    # Approval queue
    try:
        pending = aq_pending(APPROVAL_DB)
        checks["approvals"] = {"ok": True, "pending": pending}
    except Exception as e:
        checks["approvals"] = {"ok": False, "error": str(e)[:100]}

    # LLM provider
    try:
        from chat_responder import get_provider_status
        checks["llm"] = get_provider_status()
    except Exception as e:
        logger.warning("LLM provider health check failed: %s", e)
        checks["llm"] = {"ok": False, "error": "Chat responder not available"}

    # Entity extraction
    try:
        from entity_extractor import extract_entities
        test = extract_entities("test python docker")
        checks["entity_extractor"] = {"ok": True, "test_entities": len(test)}
    except Exception as e:
        checks["entity_extractor"] = {"ok": False, "error": str(e)[:100]}

    # Trace DB
    try:
        from trace_logger import get_cost_summary
        s = get_cost_summary(1)
        checks["trace_db"] = {"ok": True, "total_cost": s.get("total_cost_usd", 0)}
    except Exception as e:
        logger.warning("Trace DB health check failed: %s", e)
        checks["trace_db"] = {"ok": False, "error": "Not initialized"}

    # WebSocket connections
    checks["websocket"] = {
        "ok": True,
        "chat_connections": len(_chat_connections),
        "notify_connections": len(_notify_connections),
    }

    all_ok = all(c.get("ok", False) for c in checks.values())
    return {
        "status": "healthy" if all_ok else "degraded",
        "checks": checks,
    }


# ---------------------------------------------------------------------------
# Auth API — /api/auth/* (bypasses AuthMiddleware)
# ---------------------------------------------------------------------------
from security import (
    register_api_key, revoke_api_key, issue_jwt,
    create_api_key, _hash_key, ws_authenticate,
)
from models import AuthModeRequest, TokenRequest, TokenVerifyRequest, KeyRevokeRequest

def _require_localhost(request: Request) -> bool:
    """Check if request comes from localhost. Auth mgmt is localhost-only."""
    client_ip = request.client.host if request.client else "unknown"
    return client_ip in ("127.0.0.1", "::1")


@app.get("/api/auth/mode")
async def get_auth_mode():
    """Get current auth mode."""
    mode = aibrain_db.config_get("auth_mode", "none")
    key_count = len(aibrain_db.config_get("api_keys", []))
    return {"auth_mode": mode, "api_key_count": key_count}


@app.post("/api/auth/mode")
async def set_auth_mode(body: AuthModeRequest, request: Request):
    """Set auth mode: none, api_key, or jwt. Localhost only."""
    if not _require_localhost(request):
        return JSONResponse({"error": "Auth mode changes are restricted to localhost."}, status_code=403)
    aibrain_db.config_set("auth_mode", body.mode)
    return {"auth_mode": body.mode, "message": f"Auth mode set to {body.mode}"}


@app.post("/api/auth/keys")
async def create_key(request: Request):
    """Generate a new API key. Localhost only. Returns the plaintext key ONCE."""
    if not _require_localhost(request):
        return JSONResponse({"error": "Key management is restricted to localhost."}, status_code=403)
    key = register_api_key(aibrain_db)
    return {
        "api_key": key,
        "message": "Store this key — it cannot be retrieved later.",
    }


@app.delete("/api/auth/keys")
async def delete_key(body: KeyRevokeRequest, request: Request):
    """Revoke an API key by hash prefix. Localhost only."""
    if not _require_localhost(request):
        return JSONResponse({"error": "Key management is restricted to localhost."}, status_code=403)
    ok = revoke_api_key(aibrain_db, body.hash_prefix)
    if not ok:
        return JSONResponse({"error": "No key matched that prefix"}, status_code=404)
    return {"revoked": True}


@app.get("/api/auth/keys")
async def list_keys(request: Request):
    """List API key hash prefixes (for identification). Localhost only."""
    if not _require_localhost(request):
        return JSONResponse({"error": "Key management is restricted to localhost."}, status_code=403)
    keys = aibrain_db.config_get("api_keys", [])
    return {"keys": [{"hash_prefix": k[:12]} for k in keys]}


@app.post("/api/auth/token")
async def create_token(body: TokenRequest, request: Request):
    """Issue a JWT token. Localhost only."""
    if not _require_localhost(request):
        return JSONResponse({"error": "Token issuance is restricted to localhost."}, status_code=403)
    token = issue_jwt(aibrain_db, body.subject, body.ttl)
    return {"token": token, "subject": body.subject, "ttl": body.ttl}


@app.post("/api/auth/verify")
async def verify_token(body: TokenVerifyRequest):
    """Verify a JWT token. Body: {token: str}."""
    from security import jwt_decode
    secret = aibrain_db.config_get("jwt_secret")
    if not secret:
        return JSONResponse({"error": "No JWT secret configured"}, status_code=400)
    payload = jwt_decode(body.token, secret)
    if payload is None:
        return JSONResponse({"error": "Invalid or expired token"}, status_code=403)
    return {"valid": True, "payload": payload}


# ---------------------------------------------------------------------------
# Scheduler API
# ---------------------------------------------------------------------------
@app.get("/api/agent/scheduler/status")
async def scheduler_status():
    return get_scheduler_status()


@app.post("/api/agent/scheduler/reload")
async def scheduler_reload():
    """Reload all jobs from scheduled_jobs.json."""
    reload_jobs(AIBRAIN_ROOT, CRON_JOBS_PATH)
    status = get_scheduler_status()
    return {"status": "reloaded", "jobs": status["job_count"]}


# ---------------------------------------------------------------------------
# Approval Queue API
# ---------------------------------------------------------------------------
@app.get("/api/agent/approvals")
async def list_approvals(
    status: Optional[str] = Query(None),
    category: Optional[str] = Query(None),
    limit: int = Query(50),
):
    from security import safe_limit
    limit = safe_limit(limit, 200)
    items = aq_list(APPROVAL_DB, status=status, category=category, limit=limit)
    pending = aq_pending(APPROVAL_DB)
    return {"items": items, "pending": pending, "total": len(items)}


@app.get("/api/agent/approvals/summary")
async def approval_summary():
    return aq_summary(APPROVAL_DB)


@app.get("/api/agent/approvals/{item_id}")
async def get_approval(item_id: int):
    item = aq_get(APPROVAL_DB, item_id)
    if not item:
        return JSONResponse({"error": "Not found"}, status_code=404)
    return item


@app.post("/api/agent/approvals")
async def create_approval(body: dict):
    """Create a new approval request. Body: {category, title, detail?, payload?}"""
    title = body.get("title")
    if not title:
        return JSONResponse({"error": "title required"}, status_code=400)
    payload = body.get("payload")
    # Normalize: if payload arrives as a JSON string, parse it to dict
    if isinstance(payload, str):
        try:
            payload = json.loads(payload)
        except (json.JSONDecodeError, TypeError):
            payload = {"raw": payload}
    category = body.get("category", "general")
    item_id = aq_add(
        APPROVAL_DB,
        category=category,
        title=title,
        detail=body.get("detail", ""),
        payload=payload,
    )
    # Push real-time notification
    asyncio.ensure_future(broadcast_notification({
        "type": "approval",
        "action": "new",
        "id": item_id,
        "title": title,
        "category": category,
        "pending_count": aq_pending(APPROVAL_DB),
    }))
    return {"id": item_id, "status": "pending"}


@app.post("/api/agent/approvals/{item_id}/approve")
async def approve_item(item_id: int, body: dict = None):
    body = body or {}
    result = aq_decide(APPROVAL_DB, item_id, approved=True, note=body.get("note", ""))

    # Execute the action behind the approval
    item = aq_get(APPROVAL_DB, item_id)
    exec_result = None
    if item:
        try:
            exec_result = execute_approved_action(item)
        except Exception as e:
            exec_result = f"Execution error: {e}"
    result["execution"] = exec_result

    # Notify connected chat clients
    await _broadcast_chat({
        "type": "approval_decided",
        "item_id": item_id,
        "decision": "approved",
        "execution": exec_result,
        "timestamp": result["decided_at"],
    })
    return result


@app.post("/api/agent/approvals/{item_id}/reject")
async def reject_item(item_id: int, body: dict = None):
    body = body or {}
    result = aq_decide(APPROVAL_DB, item_id, approved=False, note=body.get("note", ""))
    await _broadcast_chat({
        "type": "approval_decided",
        "item_id": item_id,
        "decision": "rejected",
        "timestamp": result["decided_at"],
    })
    return result


@app.post("/api/agent/approvals/{item_id}/feedback")
async def feedback_item(item_id: int, body: dict = None):
    """Return an item with feedback instead of just approve/reject.
    Operator can provide instructions like 'follow up on the jobs in this email'
    or 'this is not a job offer, it's a notification'."""
    body = body or {}
    note = body.get("note", "")
    if not note:
        return {"error": "Feedback requires a note"}, 400
    result = aq_feedback(APPROVAL_DB, item_id, note=note)
    await _broadcast_chat({
        "type": "approval_decided",
        "item_id": item_id,
        "decision": "feedback",
        "note": note,
        "timestamp": result["updated_at"],
    })
    return result


# ---------------------------------------------------------------------------
# Chat WebSocket — real-time agent communication
# Messages route through the peer discovery broker so active agents
# can pick them up and respond. Falls back to Claude CLI if no agent responds.
# ---------------------------------------------------------------------------
_chat_connections: list[WebSocket] = []
_chat_lock = asyncio.Lock()
_chat_history: list[dict] = []
_MAX_HISTORY = 200


_MAX_MSG_SIZE = 10_000  # Max characters per chat message

# Broker integration for chat
_BROKER_URL = os.environ.get("PEER_BROKER_URL", "")
_CHAT_AGENT_ID = os.environ.get("CHAT_AGENT_ID", "user")
_CHAT_TARGET = os.environ.get("CHAT_TARGET", "agent")
_KNOWN_PEERS = set(filter(None, os.environ.get("KNOWN_PEERS", "").split(",")))


def _send_to_broker(from_agent: str, to_agent: str, content: str) -> bool:
    """Send a message via the peer discovery broker. Returns True on success."""
    if not _BROKER_URL:
        return False
    import urllib.request
    try:
        data = json.dumps({
            "from_agent": from_agent,
            "to_agent": to_agent,
            "content": content,
        }).encode()
        req = urllib.request.Request(
            f"{_BROKER_URL}/messages/send",
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        resp = urllib.request.urlopen(req, timeout=5)
        return resp.status == 200
    except Exception as e:
        logger.warning("Broker send failed: %s", e)
        return False


def _check_broker_replies(agent_id: str = "agent") -> list:
    """Check broker for new messages addressed to this agent. Marks them read."""
    if not _BROKER_URL:
        return []
    import urllib.request
    try:
        url = f"{_BROKER_URL}/messages?agent_id={agent_id}&mark_read=true"
        req = urllib.request.Request(url, method="GET")
        resp = urllib.request.urlopen(req, timeout=5)
        data = json.loads(resp.read())
        return data.get("messages", [])
    except Exception:
        return []


async def _broadcast_chat(message: dict):
    """Send a message to all connected chat clients."""
    async with _chat_lock:
        stale = []
        for ws in list(_chat_connections):
            try:
                await ws.send_json(message)
            except Exception:
                stale.append(ws)
        for ws in stale:
            try:
                _chat_connections.remove(ws)
            except ValueError:
                pass


async def _add_chat_connection(ws: WebSocket):
    async with _chat_lock:
        _chat_connections.append(ws)


async def _remove_chat_connection(ws: WebSocket):
    """Safely remove a WebSocket from the connections list."""
    async with _chat_lock:
        try:
            _chat_connections.remove(ws)
        except ValueError:
            pass


def _validate_ws_origin(websocket: WebSocket) -> bool:
    """Reject WebSocket connections from untrusted origins."""
    origin = (websocket.headers.get("origin") or "").lower()
    if not origin:
        return True  # No origin = non-browser client (CLI, etc.)
    from urllib.parse import urlparse
    parsed = urlparse(origin)
    host = parsed.hostname or ""
    if host in ("localhost", "127.0.0.1", "::1"):
        return True
    # Allow Tailscale IPs (100.64.0.0/10 range only — RFC 6598 shared address space)
    # Note: only reachable from authenticated Tailscale peers, so this is safe
    if host.startswith("100.") and host not in ("100.0.0.0",):
        return True
    # Check configured CORS origins
    allowed = os.environ.get("AIBRAIN_CORS_ORIGINS", "").lower()
    if allowed and origin in [o.strip() for o in allowed.split(",")]:
        return True
    return False


@app.websocket("/ws/chat")
async def chat_websocket(websocket: WebSocket):
    if not _validate_ws_origin(websocket):
        await websocket.close(code=4004, reason="Origin not allowed")
        return
    await websocket.accept()

    # Require auth before any data exchange
    if not await ws_authenticate(websocket):
        return

    await _add_chat_connection(websocket)

    try:
        # Send chat history on connect
        await websocket.send_json({
            "type": "history",
            "messages": _chat_history[-50:],
            "pending_approvals": aq_pending(APPROVAL_DB),
        })

        while True:
            try:
                data = await websocket.receive_json()
            except (json.JSONDecodeError, ValueError):
                await websocket.send_json({
                    "type": "error",
                    "content": "Invalid message format — expected JSON.",
                })
                continue

            msg_type = data.get("type", "message")

            if msg_type == "message":
                content = (data.get("content") or "").strip()
                if not content:
                    await websocket.send_json({
                        "type": "error",
                        "content": "Empty message.",
                    })
                    continue
                if len(content) > _MAX_MSG_SIZE:
                    await websocket.send_json({
                        "type": "error",
                        "content": f"Message too long ({len(content)} chars, max {_MAX_MSG_SIZE}).",
                    })
                    continue

                target = data.get("to", _CHAT_TARGET)

                chat_msg = {
                    "type": "message",
                    "role": "user",
                    "content": content,
                    "target": target,
                    "timestamp": datetime.now().isoformat(),
                }
                _chat_history.append(chat_msg)
                if len(_chat_history) > _MAX_HISTORY:
                    _chat_history[:] = _chat_history[-_MAX_HISTORY:]

                await _broadcast_chat(chat_msg)

                # Send to broker for active agents
                broker_sent = await asyncio.to_thread(
                    _send_to_broker, _CHAT_AGENT_ID, target, content
                )

                # Wait for agent reply via broker
                agent_reply = None
                if broker_sent:
                    for _ in range(6):
                        await asyncio.sleep(1)
                        replies = await asyncio.to_thread(
                            _check_broker_replies, _CHAT_AGENT_ID
                        )
                        for r in replies:
                            peer = r.get("from_agent", "")
                            if not _KNOWN_PEERS or peer in _KNOWN_PEERS:
                                agent_reply = r.get("content", "")
                                break
                        if agent_reply:
                            break

                if agent_reply:
                    agent_msg = {
                        "type": "message",
                        "role": "agent",
                        "from": target,
                        "content": agent_reply,
                        "timestamp": datetime.now().isoformat(),
                    }
                    _chat_history.append(agent_msg)
                    await _broadcast_chat(agent_msg)
                else:
                    # No agent responded — fall back to commands then CLI
                    response = _handle_chat_command(content)
                    if not response:
                        try:
                            response = await asyncio.to_thread(
                                llm_respond, content, _chat_history[-20:]
                            )
                        except Exception as e:
                            logger.error("LLM respond failed: %s", e, exc_info=True)
                            response = f"Agent error: {str(e)[:200]}"

                    if response:
                        agent_msg = {
                            "type": "message",
                            "role": "agent",
                            "content": f"[auto] {response}",
                            "timestamp": datetime.now().isoformat(),
                        }
                        _chat_history.append(agent_msg)
                        await _broadcast_chat(agent_msg)

            elif msg_type == "ping":
                await websocket.send_json({"type": "pong"})

    except WebSocketDisconnect:
        pass
    except Exception as e:
        logger.warning("Chat WebSocket error: %s", e)
    finally:
        await _remove_chat_connection(websocket)


# ---------------------------------------------------------------------------
# Notification WebSocket — real-time events for Activity, Approvals, etc.
# ---------------------------------------------------------------------------
_notify_connections: list[WebSocket] = []
_notify_lock = asyncio.Lock()


async def broadcast_notification(event: dict):
    """Send a real-time notification to all connected notification clients.
    Call this from anywhere to push events to the frontend.
    event should have at minimum: {"type": "activity|approval|system", ...}
    """
    event.setdefault("timestamp", datetime.now().isoformat())
    async with _notify_lock:
        stale = []
        for ws in list(_notify_connections):
            try:
                await ws.send_json(event)
            except Exception:
                stale.append(ws)
        for ws in stale:
            try:
                _notify_connections.remove(ws)
            except ValueError:
                pass

# Wire up notification callback so aibrain_api can broadcast events
set_notify_callback(broadcast_notification)
set_reactive_notify(broadcast_notification)


@app.websocket("/ws/notifications")
async def notification_websocket(websocket: WebSocket):
    if not _validate_ws_origin(websocket):
        await websocket.close(code=4004, reason="Origin not allowed")
        return
    await websocket.accept()

    # Require auth before any data exchange
    if not await ws_authenticate(websocket):
        return

    async with _notify_lock:
        _notify_connections.append(websocket)
    try:
        # Send initial state
        await websocket.send_json({
            "type": "connected",
            "pending_approvals": aq_pending(APPROVAL_DB),
            "timestamp": datetime.now().isoformat(),
        })
        while True:
            try:
                data = await websocket.receive_json()
            except (json.JSONDecodeError, ValueError):
                continue
            if data.get("type") == "ping":
                await websocket.send_json({"type": "pong"})
    except WebSocketDisconnect:
        pass
    except Exception as e:
        logger.warning("Notification WebSocket error: %s", e)
    finally:
        async with _notify_lock:
            try:
                _notify_connections.remove(websocket)
            except ValueError:
                pass


@app.get("/api/agent/chat/history")
async def chat_history(limit: int = Query(50)):
    """Get recent chat history via REST (for non-WebSocket clients)."""
    return {"messages": _chat_history[-limit:], "total": len(_chat_history)}


@app.post("/api/agent/chat/send")
async def chat_send(body: dict):
    """Send a chat message — routes through peer broker so active agents can respond."""
    content = (body.get("content") or "").strip()
    if not content:
        return JSONResponse({"error": "content required"}, status_code=400)
    if len(content) > _MAX_MSG_SIZE:
        return JSONResponse({"error": f"message too long ({len(content)} chars, max {_MAX_MSG_SIZE})"}, status_code=400)

    target = body.get("to", _CHAT_TARGET)  # Allow targeting specific peer agents

    chat_msg = {
        "type": "message",
        "role": "user",
        "content": content,
        "target": target,
        "timestamp": datetime.now().isoformat(),
    }
    _chat_history.append(chat_msg)
    if len(_chat_history) > _MAX_HISTORY:
        _chat_history[:] = _chat_history[-_MAX_HISTORY:]

    await _broadcast_chat(chat_msg)

    # Send to broker so the actual agent can pick it up
    broker_sent = await asyncio.to_thread(_send_to_broker, _CHAT_AGENT_ID, target, content)

    if broker_sent:
        # Wait a few seconds for an agent reply via broker
        agent_reply = None
        for _ in range(6):  # Poll for up to 6 seconds
            await asyncio.sleep(1)
            replies = await asyncio.to_thread(_check_broker_replies, _CHAT_AGENT_ID)
            for r in replies:
                peer = r.get("from_agent", "")
                if not _KNOWN_PEERS or peer in _KNOWN_PEERS:
                    agent_reply = r.get("content", "")
                    break
            if agent_reply:
                break

        if agent_reply:
            agent_msg = {
                "type": "message",
                "role": "agent",
                "from": target,
                "content": agent_reply,
                "timestamp": datetime.now().isoformat(),
            }
            _chat_history.append(agent_msg)
            await _broadcast_chat(agent_msg)
            return {"sent": chat_msg, "response": agent_msg}

    # No agent responded — fall back to commands then CLI
    response = _handle_chat_command(content)
    if not response:
        try:
            response = await asyncio.to_thread(llm_respond, content, _chat_history[-20:])
        except Exception as e:
            logger.error("REST chat LLM error: %s", e, exc_info=True)
            response = f"Agent error: {str(e)[:200]}"

    if response:
        agent_msg = {
            "type": "message",
            "role": "agent",
            "content": f"[auto] {response}",
            "timestamp": datetime.now().isoformat(),
        }
        _chat_history.append(agent_msg)
        await _broadcast_chat(agent_msg)
        return {"sent": chat_msg, "response": agent_msg}

    return {"sent": chat_msg, "response": None}


@app.post("/api/agent/chat/upload")
async def chat_upload(file: UploadFile):
    """Upload a file and return its content for chat context."""
    UPLOAD_DIR = AIBRAIN_ROOT / "uploads"
    UPLOAD_DIR.mkdir(exist_ok=True)

    ALLOWED_EXTENSIONS = {
        ".txt", ".md", ".py", ".js", ".ts", ".jsx", ".tsx", ".json",
        ".yaml", ".yml", ".toml", ".csv", ".log", ".sh", ".bash",
        ".html", ".css", ".xml", ".rst", ".ini", ".cfg", ".conf",
        ".sql", ".r", ".go", ".rs", ".java", ".c", ".cpp", ".h",
    }
    import os as _os
    _, ext = _os.path.splitext((file.filename or "").lower())
    if ext not in ALLOWED_EXTENSIONS:
        return JSONResponse(
            {"error": f"File type '{ext or 'unknown'}' not allowed. Upload text-based files only."},
            status_code=415,
        )

    max_size = 5 * 1024 * 1024  # 5MB
    chunks = []
    total = 0
    while True:
        chunk = await file.read(65536)
        if not chunk:
            break
        total += len(chunk)
        if total > max_size:
            return JSONResponse({"error": f"File too large. Maximum size: {max_size // 1024 // 1024}MB"}, status_code=413)
        chunks.append(chunk)
    content = b"".join(chunks)

    # Save file
    import re as _re
    safe_name = _re.sub(r'[^a-zA-Z0-9._-]', '_', file.filename)[:100]
    save_path = (UPLOAD_DIR / safe_name).resolve()
    if not str(save_path).startswith(str(UPLOAD_DIR.resolve())):  # noqa:PATH STARTSWITH BYPASS
        return JSONResponse({"error": "Invalid filename"}, status_code=400)
    save_path.write_bytes(content)

    # Try to extract text content
    text_content = None
    try:
        text_content = content.decode("utf-8")
    except (UnicodeDecodeError, ValueError):
        text_content = f"[Binary file: {safe_name}, {len(content)} bytes]"

    # Truncate very large text
    if text_content and len(text_content) > 50000:
        text_content = text_content[:50000] + f"\n... [truncated, {len(content)} bytes total]"

    return {
        "filename": safe_name,
        "size": len(content),
        "path": safe_name,
        "text_preview": text_content[:2000] if text_content else None,
        "text_content": text_content,
    }


def _handle_chat_command(content: str) -> str | None:
    """Handle built-in chat commands. Returns response or None."""
    cmd = content.strip().lower()

    if cmd in ("status", "/status"):
        sched = get_scheduler_status()
        pending = aq_pending(APPROVAL_DB)
        return (
            f"Scheduler: {'running' if sched['running'] else 'stopped'} ({sched['job_count']} jobs)\n"
            f"Pending approvals: {pending}\n"
            f"Recent runs: {len(sched['run_log'])}"
        )

    if cmd in ("approvals", "/approvals", "pending"):
        items = aq_list(APPROVAL_DB, status="pending", limit=10)
        if not items:
            return "No pending approvals."
        lines = [f"Pending approvals ({len(items)}):"]
        for item in items:
            lines.append(f"  [{item['id']}] [{item['category']}] {item['title']}")
        return "\n".join(lines)

    if cmd in ("schedule", "/schedule", "jobs"):
        sched = get_scheduler_status()
        if not sched["jobs"]:
            return "No scheduled jobs."
        lines = [f"Scheduled jobs ({sched['job_count']}):"]
        for job in sched["jobs"][:15]:
            lines.append(f"  {job['name']:25s} next: {job['next_run'] or 'paused'}")
        return "\n".join(lines)

    if cmd in ("help", "/help"):
        return (
            "Available commands:\n"
            "  /status     — scheduler + approval summary\n"
            "  /approvals  — list pending approval items\n"
            "  /schedule   — list scheduled jobs\n"
            "  /costs      — LLM cost summary\n"
            "  /content    — generate content posts\n"
            "  /create     — create a workflow from description\n"
            "  /help       — show this help\n"
            "\nOr type anything — your message goes to the AI agent."
        )

    # /costs — show LLM cost summary
    if cmd in ("costs", "/costs", "spending"):
        try:
            from trace_logger import get_cost_summary
            summary = get_cost_summary(30)
            lines = [f"LLM Costs (last 30 days): ${summary['total_cost_usd']:.4f}"]
            for m in summary.get("by_model", [])[:5]:
                lines.append(f"  {m['model']}: ${m['cost']:.4f} ({m['calls']} calls)")
            if not summary.get("by_model"):
                lines.append("  No LLM calls tracked yet.")
            return "\n".join(lines)
        except Exception as e:
            logger.warning("Cost tracking query failed: %s", e)
            return "Cost tracking not initialized yet. Make an LLM call first."

    # /content — generate content posts
    if cmd in ("content", "/content", "generate content"):
        try:
            import sys
            sys.path.insert(0, str(AIBRAIN_ROOT / "workflows"))
            from content_calendar import generate_posts, save_state
            from approval_queue import add_item as _aq_add

            state, posts = generate_posts(count=5)
            save_state(state)
            for post in posts:
                _aq_add(
                    APPROVAL_DB,
                    category="social",
                    title=f"Post to {post['platform']}: {post['text'][:60]}...",
                    detail=post["text"],
                    payload={"action": "publish", "platform": post["platform"], "content": post["text"]},
                )
            return f"Generated {len(posts)} content posts. Check the Approval Queue to review and publish."
        except Exception as e:
            return f"Content generation error: {str(e)[:200]}"

    # /create <description> — create workflow from natural language
    if cmd.startswith("/create ") or cmd.startswith("create workflow "):
        description = content.strip()
        if cmd.startswith("/create"):
            description = content.strip()[8:].strip()
        elif cmd.startswith("create workflow"):
            description = content.strip()[16:].strip()
        if not description:
            return "Usage: /create <description>\nExample: /create Every morning check my email and summarize it"
        try:
            from workflow_generator import generate_workflow
            result = generate_workflow(description)
            return f"Workflow created: {result['name']}\nSchedule: {result['cron']}\nCategory: {result['category']}\nEdit: workflows/{result['name']}.py"
        except Exception as e:
            return f"Workflow creation error: {str(e)[:200]}"

    # Not a command — just a message. Agent will pick it up.
    return None


# ---------------------------------------------------------------------------
# Stripe Webhook Endpoint
# ---------------------------------------------------------------------------

@app.post("/webhooks/stripe")
async def stripe_webhook(request: Request):
    """Process Stripe webhook events for subscriptions and marketplace."""
    try:
        from aibrain_payments import PaymentManager
    except ImportError:
        return {"error": "Payments not configured"}

    pm = PaymentManager()
    if not pm.available:
        return {"error": "Stripe not configured"}

    payload = await request.body()
    sig = request.headers.get("stripe-signature", "")

    result = pm.handle_webhook(payload, sig)

    if result.get("action") == "subscription_activated":
        logger.info("New subscription: %s for %s",
                     result["data"].get("tier"), result["data"].get("email"))

    elif result.get("action") == "brain_purchased":
        logger.info("Brain purchased: %s by %s",
                     result["data"].get("brain_id"), result["data"].get("buyer_email"))

    elif result.get("action") == "subscription_cancelled":
        logger.info("Subscription cancelled: %s", result["data"].get("subscription_id"))

    return {"status": "ok", "action": result.get("action", "ignored")}
