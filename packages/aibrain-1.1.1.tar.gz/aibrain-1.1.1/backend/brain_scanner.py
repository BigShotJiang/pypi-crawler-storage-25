"""
AIBrain Brain Scanner — Filesystem & Git discovery for onboarding.

Scans a user's project directories and git repos to auto-discover:
- Projects (directories with code/config)
- Workflows (executable scripts with scheduling patterns)
- Tools (standalone utility scripts)
- Integrations (API keys, config files, service references)
- References (docs, data files, configs)

Creates entity_links between discovered entities so the brain graph
is pre-wired on first boot. This is what makes the "connected experience"
work for new users without manual setup.

Usage:
    # Scan local directories
    results = scan_directories(["/home/user/projects", "/home/user/scripts"])

    # Scan git repos (requires GitHub token)
    repos = scan_github_repos("username", "ghp_token123")

    # Full onboarding: scan everything and populate DB
    report = build_brain_from_filesystem(db_path, dirs, github_user, github_token)
"""

import json
import logging
import os
import re
import sqlite3
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# File classification rules
# ---------------------------------------------------------------------------

# Extension → category mapping
FILE_CATEGORIES = {
    # Workflows (executable automation scripts)
    "workflow": {
        "patterns": [
            r"(cron|schedule|job|task|automation|pipeline|daily|weekly|hourly)",
            r"(workflow|flow|process|routine)",
        ],
        "extensions": [".py", ".sh", ".bash", ".js", ".ts"],
        "indicators": ["schedule", "cron", "apscheduler", "celery", "airflow"],
    },
    # Tools (standalone utility scripts)
    "tool": {
        "patterns": [
            r"(scan|check|test|validate|lint|format|build|deploy|backup)",
            r"(tool|util|helper|script|cli|cmd)",
            r"(scrape|crawl|fetch|download|upload|sync|export|import)",
        ],
        "extensions": [".py", ".sh", ".bash", ".js", ".ts", ".go", ".rs"],
        "indicators": ["argparse", "click", "typer", "sys.argv", "if __name__"],
    },
    # Config (configuration files)
    "config": {
        "patterns": [r"(config|settings|env|\.env|\.ini|\.toml|\.yaml|\.yml)"],
        "extensions": [".json", ".yaml", ".yml", ".toml", ".ini", ".env", ".cfg"],
        "indicators": [],
    },
    # Data (data files, databases, datasets)
    "data": {
        "patterns": [r"(data|dataset|seed|fixture|migration|schema)"],
        "extensions": [".csv", ".json", ".sqlite", ".db", ".sql", ".parquet"],
        "indicators": [],
    },
    # Documentation
    "reference": {
        "patterns": [r"(readme|doc|guide|manual|spec|design|architecture|plan)"],
        "extensions": [".md", ".txt", ".rst", ".pdf", ".docx"],
        "indicators": [],
    },
    # Frontend components
    "component": {
        "patterns": [r"(component|page|view|layout|widget|modal|dialog)"],
        "extensions": [".jsx", ".tsx", ".vue", ".svelte"],
        "indicators": ["import React", "export default", "defineComponent"],
    },
    # API endpoints / routes
    "api": {
        "patterns": [r"(api|route|endpoint|controller|handler|middleware)"],
        "extensions": [".py", ".js", ".ts", ".go"],
        "indicators": ["@app.", "@router.", "app.get", "app.post", "router.get"],
    },
}

# Directories to skip during scanning
SKIP_DIRS = {
    "node_modules", ".git", "__pycache__", ".venv", "venv", "env",
    ".next", ".nuxt", "dist", "build", ".cache", ".tox",
    ".mypy_cache", ".pytest_cache", ".ruff_cache", "coverage",
    ".idea", ".vscode", ".DS_Store", "vendor", "target",
}

# Files to skip
SKIP_FILES = {
    ".gitignore", ".gitkeep", ".eslintrc", ".prettierrc",
    "package-lock.json", "yarn.lock", "pnpm-lock.yaml",
    "Thumbs.db", ".DS_Store",
}

# Integration detection patterns
INTEGRATION_PATTERNS = {
    "gmail": [r"smtp\.gmail", r"imap\.gmail", r"google.*oauth", r"app.?password"],
    "github": [r"github\.com/api", r"github_token", r"GITHUB_TOKEN", r"gh_token"],
    "telegram": [r"telegram", r"bot.*token", r"chat_id", r"@.*bot"],
    "discord": [r"discord", r"DISCORD_TOKEN", r"discord\.gg"],
    "slack": [r"slack", r"SLACK_TOKEN", r"slack\.com/api"],
    "openai": [r"openai", r"OPENAI_API_KEY", r"gpt-4", r"gpt-3"],
    "anthropic": [r"anthropic", r"ANTHROPIC_API_KEY", r"claude"],
    "aws": [r"AWS_ACCESS_KEY", r"boto3", r"s3://", r"amazonaws"],
    "docker": [r"docker-compose", r"Dockerfile", r"docker\.sock"],
    "alpaca": [r"alpaca", r"ALPACA_API_KEY", r"alpaca-trade"],
    "noaa": [r"noaa\.gov", r"NOAA_API"],
    "redis": [r"redis://", r"REDIS_URL", r"import redis"],
    "postgres": [r"postgresql://", r"psycopg2", r"asyncpg"],
    "ollama": [r"ollama", r"localhost:11434"],
}


# ---------------------------------------------------------------------------
# File scanning
# ---------------------------------------------------------------------------

def classify_file(file_path: Path, content: Optional[str] = None) -> dict:
    """Classify a single file by its name, extension, and optionally content."""
    name = file_path.name.lower()
    ext = file_path.suffix.lower()
    stem = file_path.stem.lower()

    result = {
        "path": str(file_path),
        "name": file_path.name,
        "extension": ext,
        "category": "unknown",
        "confidence": 0.0,
        "integrations": [],
        "size_bytes": 0,
    }

    try:
        result["size_bytes"] = file_path.stat().st_size
    except OSError:
        pass

    # Try each category
    best_category = "unknown"
    best_score = 0.0

    for category, rules in FILE_CATEGORIES.items():
        score = 0.0

        # Extension match
        if ext in rules["extensions"]:
            score += 0.3

        # Name pattern match
        for pattern in rules["patterns"]:
            if re.search(pattern, stem, re.IGNORECASE):
                score += 0.4
                break

        # Content indicator match (if content available)
        if content and rules["indicators"]:
            for indicator in rules["indicators"]:
                if indicator in content:
                    score += 0.3
                    break

        if score > best_score:
            best_score = score
            best_category = category

    result["category"] = best_category
    result["confidence"] = min(best_score, 1.0)

    # Detect integrations from content
    if content:
        for integration, patterns in INTEGRATION_PATTERNS.items():
            for pat in patterns:
                if re.search(pat, content, re.IGNORECASE):
                    result["integrations"].append(integration)
                    break

    return result


def scan_directory(dir_path: str, max_depth: int = 4, read_content: bool = True,
                   max_file_size: int = 500_000) -> dict:
    """
    Scan a directory tree and classify all files.

    Returns:
        {
            "root": str,
            "is_project": bool,
            "project_name": str,
            "has_git": bool,
            "language": str,
            "files": [classified file dicts],
            "integrations": [detected integrations],
            "stats": {category: count}
        }
    """
    root = Path(dir_path).resolve()
    if not root.is_dir():
        return {"error": f"Not a directory: {dir_path}"}

    result = {
        "root": str(root),
        "project_name": root.name,
        "is_project": False,
        "has_git": (root / ".git").is_dir(),
        "language": "unknown",
        "files": [],
        "integrations": set(),
        "stats": {},
    }

    # Detect project type
    project_indicators = {
        "package.json": "javascript",
        "setup.py": "python",
        "pyproject.toml": "python",
        "requirements.txt": "python",
        "Cargo.toml": "rust",
        "go.mod": "go",
        "Gemfile": "ruby",
        "pom.xml": "java",
        "build.gradle": "java",
        "Makefile": "multi",
        "docker-compose.yml": "multi",
        "docker-compose.yaml": "multi",
    }

    for indicator, lang in project_indicators.items():
        if (root / indicator).exists():
            result["is_project"] = True
            result["language"] = lang
            break

    # Walk the tree
    for dirpath, dirnames, filenames in os.walk(str(root)):
        # Calculate depth
        rel = Path(dirpath).relative_to(root)
        depth = len(rel.parts)
        if depth > max_depth:
            dirnames.clear()
            continue

        # Skip unwanted directories
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]

        for fname in filenames:
            if fname in SKIP_FILES:
                continue

            fpath = Path(dirpath) / fname

            # Read content for classification (small files only)
            content = None
            if read_content:
                try:
                    size = fpath.stat().st_size
                    if size < max_file_size and fpath.suffix.lower() in {
                        ".py", ".js", ".ts", ".jsx", ".tsx", ".sh", ".bash",
                        ".json", ".yaml", ".yml", ".toml", ".md", ".txt",
                        ".env", ".cfg", ".ini", ".go", ".rs", ".rb",
                    }:
                        content = fpath.read_text(encoding="utf-8", errors="ignore")
                except (OSError, UnicodeDecodeError):
                    pass

            classified = classify_file(fpath, content)
            result["files"].append(classified)

            # Aggregate integrations
            for intg in classified.get("integrations", []):
                result["integrations"].add(intg)

    # Convert set to list for JSON serialization
    result["integrations"] = sorted(result["integrations"])

    # Stats
    stats = {}
    for f in result["files"]:
        cat = f["category"]
        stats[cat] = stats.get(cat, 0) + 1
    result["stats"] = stats

    return result


def scan_directories(dir_paths: list[str], **kwargs) -> list[dict]:
    """Scan multiple directories and return results for each."""
    results = []
    for path in dir_paths:
        p = Path(path)
        if not p.is_dir():
            continue
        # Scan each subdirectory as a potential project
        for sub in sorted(p.iterdir()):
            if sub.is_dir() and sub.name not in SKIP_DIRS and not sub.name.startswith("."):
                results.append(scan_directory(str(sub), **kwargs))
    return results


# ---------------------------------------------------------------------------
# Git repo scanning
# ---------------------------------------------------------------------------

def scan_github_repos(username: str, token: str) -> list[dict]:
    """
    List all repos for a GitHub user (works for both user and org accounts).
    Returns list of repo metadata dicts.
    """
    import urllib.request

    repos = []
    page = 1

    while True:
        url = f"https://api.github.com/users/{username}/repos?per_page=100&page={page}&sort=updated"
        req = urllib.request.Request(url, headers={
            "Authorization": f"token {token}",
            "User-Agent": "AIBrain-BrainScanner/1.0",
            "Accept": "application/vnd.github.v3+json",
        })

        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                data = json.loads(resp.read().decode())
                if not data:
                    break
                for repo in data:
                    repos.append({
                        "name": repo["name"],
                        "full_name": repo["full_name"],
                        "description": repo.get("description", ""),
                        "language": repo.get("language", "unknown"),
                        "url": repo["html_url"],
                        "clone_url": repo["clone_url"],
                        "default_branch": repo.get("default_branch", "main"),
                        "private": repo["private"],
                        "fork": repo["fork"],
                        "stars": repo.get("stargazers_count", 0),
                        "updated_at": repo.get("updated_at", ""),
                        "topics": repo.get("topics", []),
                    })
                page += 1
        except Exception as e:
            break

    return repos


def find_local_git_repos(search_dirs: list[str], max_depth: int = 3) -> list[dict]:
    """Find all git repos under the given directories."""
    repos = []
    seen = set()

    for search_dir in search_dirs:
        root = Path(search_dir)
        if not root.is_dir():
            continue

        for dirpath, dirnames, filenames in os.walk(str(root)):
            depth = len(Path(dirpath).relative_to(root).parts)
            if depth > max_depth:
                dirnames.clear()
                continue

            dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]

            if ".git" in os.listdir(dirpath):
                repo_path = Path(dirpath).resolve()
                if str(repo_path) not in seen:
                    seen.add(str(repo_path))

                    # Get remote URL
                    remote_url = ""
                    try:
                        result = subprocess.run(
                            ["git", "remote", "get-url", "origin"],
                            cwd=str(repo_path), capture_output=True, text=True, timeout=5
                        )
                        if result.returncode == 0:
                            remote_url = result.stdout.strip()
                    except Exception as e:
                        logger.warning("Failed to get git remote for %s: %s", repo_path, e)

                    repos.append({
                        "path": str(repo_path),
                        "name": repo_path.name,
                        "remote_url": remote_url,
                    })
                # Don't recurse into git repos
                dirnames.clear()

    return repos


# ---------------------------------------------------------------------------
# Brain building — populate DB from scan results
# ---------------------------------------------------------------------------

def build_brain_from_filesystem(
    db_path: str,
    project_dirs: list[str],
    github_username: Optional[str] = None,
    github_token: Optional[str] = None,
    claude_memory_dir: Optional[str] = None,
) -> dict:
    """
    Full onboarding scan: discover all projects, classify files, build entity_links.

    This is the main entry point for the "scan my stuff and wire it up" flow.

    Args:
        db_path: Path to aibrain.db
        project_dirs: Directories to scan for projects (e.g., ~/projects, ~/scripts)
        github_username: GitHub username for repo discovery
        github_token: GitHub token for API access
        claude_memory_dir: Path to .claude/projects/*/memory/ for importing existing memories

    Returns:
        Report dict with counts of everything created.
    """
    db = sqlite3.connect(db_path)
    now = datetime.now().isoformat()

    report = {
        "projects_created": 0,
        "workflows_discovered": 0,
        "tools_discovered": 0,
        "integrations_discovered": 0,
        "references_discovered": 0,
        "entity_links_created": 0,
        "memories_imported": 0,
        "git_repos_found": 0,
        "github_repos_found": 0,
        "errors": [],
        "projects": [],
    }

    # Ensure tables exist
    _ensure_tables(db)

    # --- Step 1: Scan local directories ---
    all_scans = []
    for dir_path in project_dirs:
        p = Path(dir_path)
        if not p.is_dir():
            continue
        for sub in sorted(p.iterdir()):
            if sub.is_dir() and sub.name not in SKIP_DIRS and not sub.name.startswith("."):
                try:
                    scan = scan_directory(str(sub), max_depth=3, read_content=True)
                    if scan.get("is_project") or scan.get("has_git") or len(scan.get("files", [])) > 3:
                        all_scans.append(scan)
                except Exception as e:
                    report["errors"].append(f"Scan error for {sub}: {e}")

    # --- Step 2: Find local git repos ---
    local_repos = find_local_git_repos(project_dirs)
    report["git_repos_found"] = len(local_repos)

    # --- Step 3: Scan GitHub repos (if credentials provided) ---
    github_repos = []
    if github_username and github_token:
        try:
            github_repos = scan_github_repos(github_username, github_token)
            report["github_repos_found"] = len(github_repos)
        except Exception as e:
            report["errors"].append(f"GitHub scan error: {e}")

    # --- Step 4: Create projects from discovered dirs ---
    for scan in all_scans:
        project_name = scan["project_name"]

        # Check if project already exists
        existing = db.execute(
            "SELECT id FROM projects WHERE name = ? OR name LIKE ?",
            (project_name, f"%{project_name}%")
        ).fetchone()

        if existing:
            project_id = existing[0]
        else:
            # Create new project
            description = f"Auto-discovered from {scan['root']}"
            if scan.get("language") != "unknown":
                description += f" ({scan['language']})"
            if scan.get("integrations"):
                description += f". Integrations: {', '.join(scan['integrations'])}"

            db.execute(
                "INSERT INTO projects (name, description, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?)",
                (project_name, description, "active", now, now)
            )
            project_id = db.execute("SELECT last_insert_rowid()").fetchone()[0]
            report["projects_created"] += 1

        report["projects"].append({
            "name": project_name,
            "id": project_id,
            "files": len(scan.get("files", [])),
            "integrations": scan.get("integrations", []),
            "language": scan.get("language", "unknown"),
            "new": not bool(existing),
        })

        # --- Step 5: Create entity_links for files → project ---
        for f in scan.get("files", []):
            cat = f["category"]

            if cat == "workflow":
                report["workflows_discovered"] += 1
                # Check if workflow exists
                wf_name = Path(f["path"]).stem
                wf_existing = db.execute(
                    "SELECT id FROM workflows WHERE name = ?", (wf_name,)
                ).fetchone()
                if wf_existing:
                    # Link workflow → project
                    _create_link(db, "workflow", wf_existing[0], "project", project_id, "belongs_to", now)
                    report["entity_links_created"] += 1

            elif cat == "tool":
                report["tools_discovered"] += 1

            elif cat == "reference":
                report["references_discovered"] += 1

        # Link integrations
        for intg in scan.get("integrations", []):
            report["integrations_discovered"] += 1
            # Create integration entity_link
            _create_link(db, "integration", _get_or_create_integration(db, intg, now),
                        "project", project_id, "used_by", now)
            report["entity_links_created"] += 1

    # --- Step 6: Link GitHub repos to local projects ---
    for gh_repo in github_repos:
        # Find matching local project
        local_match = db.execute(
            "SELECT id FROM projects WHERE LOWER(name) = LOWER(?)",
            (gh_repo["name"],)
        ).fetchone()

        if local_match:
            # Store repo URL as reference
            _create_link(db, "project", local_match[0], "integration",
                        _get_or_create_integration(db, "github", now),
                        "uses", now)
            report["entity_links_created"] += 1

    # --- Step 7: Import Claude memories if directory provided ---
    if claude_memory_dir:
        memory_dir = Path(claude_memory_dir)
        if memory_dir.is_dir():
            for md_file in sorted(memory_dir.glob("*.md")):
                if md_file.name == "MEMORY.md":
                    continue
                try:
                    content = md_file.read_text(encoding="utf-8", errors="ignore")
                    # Parse frontmatter
                    mem_data = _parse_memory_file(content, md_file.name)
                    if mem_data:
                        # Check duplicate
                        existing = db.execute(
                            "SELECT id FROM memories WHERE name = ?", (mem_data["name"],)
                        ).fetchone()
                        if not existing:
                            db.execute(
                                "INSERT INTO memories (name, type, tags, content, created, updated) "
                                "VALUES (?, ?, ?, ?, ?, ?)",
                                (mem_data["name"], mem_data["type"], mem_data.get("tags", ""),
                                 mem_data["content"], now, now)
                            )
                            report["memories_imported"] += 1
                except Exception as e:
                    report["errors"].append(f"Memory import error {md_file.name}: {e}")

    # --- Step 8: Auto-link related projects ---
    _auto_link_projects(db, now)

    db.commit()
    db.close()

    return report


def _ensure_tables(db: sqlite3.Connection):
    """Ensure all required tables exist."""
    db.executescript("""
        CREATE TABLE IF NOT EXISTS projects (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT DEFAULT '',
            status TEXT DEFAULT 'active',
            created_at TEXT,
            updated_at TEXT
        );
        CREATE TABLE IF NOT EXISTS workflows (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT DEFAULT '',
            category TEXT DEFAULT '',
            status TEXT DEFAULT 'active',
            created_at TEXT,
            updated_at TEXT
        );
        CREATE TABLE IF NOT EXISTS entity_links (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source_type TEXT NOT NULL,
            source_id INTEGER NOT NULL,
            target_type TEXT NOT NULL,
            target_id INTEGER NOT NULL,
            relationship TEXT NOT NULL,
            metadata TEXT DEFAULT '',
            created_at TEXT,
            UNIQUE(source_type, source_id, target_type, target_id, relationship)
        );
        CREATE TABLE IF NOT EXISTS integrations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            type TEXT DEFAULT 'service',
            status TEXT DEFAULT 'detected',
            config TEXT DEFAULT '{}',
            created_at TEXT
        );
        CREATE TABLE IF NOT EXISTS memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            type TEXT NOT NULL DEFAULT 'reference',
            tags TEXT DEFAULT '',
            content TEXT DEFAULT '',
            file_path TEXT DEFAULT '',
            active INTEGER DEFAULT 1,
            created TEXT NOT NULL,
            updated TEXT NOT NULL
        );
    """)


def _create_link(db, src_type, src_id, tgt_type, tgt_id, relationship, now):
    """Create an entity link, ignoring duplicates."""
    try:
        db.execute(
            "INSERT OR IGNORE INTO entity_links "
            "(source_type, source_id, target_type, target_id, relationship, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (src_type, src_id, tgt_type, tgt_id, relationship, now)
        )
    except Exception as e:
        logger.warning("Failed to create entity link %s/%s -> %s/%s: %s", src_type, src_id, tgt_type, tgt_id, e)


def _get_or_create_integration(db, name: str, now: str) -> int:
    """Get or create an integration record, return its ID."""
    existing = db.execute("SELECT id FROM integrations WHERE name = ?", (name,)).fetchone()
    if existing:
        return existing[0]
    db.execute(
        "INSERT INTO integrations (name, type, status, created_at) VALUES (?, ?, ?, ?)",
        (name, "service", "detected", now)
    )
    return db.execute("SELECT last_insert_rowid()").fetchone()[0]


def _parse_memory_file(content: str, filename: str) -> Optional[dict]:
    """Parse a memory .md file with YAML frontmatter."""
    if not content.startswith("---"):
        return None

    parts = content.split("---", 2)
    if len(parts) < 3:
        return None

    frontmatter = parts[1].strip()
    body = parts[2].strip()

    # Simple YAML parsing (no dependency)
    meta = {}
    for line in frontmatter.split("\n"):
        if ":" in line:
            key, _, value = line.partition(":")
            meta[key.strip()] = value.strip()

    if not meta.get("name"):
        meta["name"] = filename.replace(".md", "")

    return {
        "name": meta.get("name", ""),
        "type": meta.get("type", "reference"),
        "description": meta.get("description", ""),
        "tags": meta.get("tags", ""),
        "content": body,
    }


def _auto_link_projects(db: sqlite3.Connection, now: str):
    """Auto-detect relationships between projects based on name/content overlap."""
    projects = db.execute("SELECT id, name, description FROM projects WHERE status != 'archived'").fetchall()

    for pid, pname, pdesc in projects:
        pname_lower = pname.lower()
        pdesc_lower = (pdesc or "").lower()

        for oid, oname, odesc in projects:
            if pid >= oid:  # Avoid self-links and duplicates
                continue

            oname_lower = oname.lower()
            odesc_lower = (odesc or "").lower()

            # Check if one project mentions the other
            if oname_lower in pdesc_lower or pname_lower in odesc_lower:
                _create_link(db, "project", pid, "project", oid, "relates_to", now)

            # Check for common integration mentions
            if "security_scanner" in pname_lower and ("entity" in oname_lower or "remediate" in oname_lower):
                _create_link(db, "project", pid, "project", oid, "relates_to", now)


# ---------------------------------------------------------------------------
# CLI interface
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("Usage:")
        print("  brain_scanner.py scan <directory>        — Scan and classify files")
        print("  brain_scanner.py repos <dir1> [dir2...]  — Find local git repos")
        print("  brain_scanner.py github <user> <token>   — List GitHub repos")
        print("  brain_scanner.py build <db> <dir1> [dir2...] — Full brain build")
        sys.exit(1)

    cmd = sys.argv[1]

    if cmd == "scan" and len(sys.argv) >= 3:
        result = scan_directory(sys.argv[2])
        print(json.dumps(result, indent=2, default=str))

    elif cmd == "repos" and len(sys.argv) >= 3:
        repos = find_local_git_repos(sys.argv[2:])
        for r in repos:
            print(f"  {r['name']:30s} {r['remote_url']}")
        print(f"\nTotal: {len(repos)} repos")

    elif cmd == "github" and len(sys.argv) >= 4:
        repos = scan_github_repos(sys.argv[2], sys.argv[3])
        for r in repos:
            lang = r.get("language") or "?"
            stars = r.get("stars", 0)
            print(f"  {r['name']:30s} {lang:12s} {stars:3d}* {r.get('description', '')[:50]}")
        print(f"\nTotal: {len(repos)} repos")

    elif cmd == "build" and len(sys.argv) >= 4:
        db_path = sys.argv[2]
        dirs = sys.argv[3:]
        report = build_brain_from_filesystem(db_path, dirs)
        print(json.dumps(report, indent=2, default=str))

    else:
        print(f"Unknown command: {cmd}")
        sys.exit(1)
