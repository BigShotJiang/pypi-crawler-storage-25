"""
Agent-to-agent communication protocol over Redis pub/sub.

Supports: publish/subscribe events, request-response between agents.
Supports reactive mesh coordination between agents on different platforms.
"""

import json
import logging
import os
import threading
from datetime import datetime, timezone
from uuid import uuid4
from typing import Callable, Optional

logger = logging.getLogger(__name__)


class AgentBroker:
    """Redis-backed inter-agent message broker."""

    def __init__(self, agent_id: str = None, redis_url: str = None):
        self.agent_id = agent_id or os.getenv("AGENT_ID", "agent")
        self.redis_url = redis_url or os.getenv("REDIS_URL", "redis://localhost:6379")
        self._redis = None
        self._pubsub = None
        self._thread = None

    @property
    def redis(self):
        if self._redis is None:
            try:
                import redis
                self._redis = redis.from_url(self.redis_url, decode_responses=True)
            except ImportError:
                return None
        return self._redis

    def available(self) -> bool:
        """Check if Redis is reachable."""
        try:
            if self.redis is None:
                return False
            self.redis.ping()
            return True
        except Exception as e:
            logger.warning("Redis availability check failed: %s", e)
            return False

    def publish(self, channel: str, payload: dict):
        """Publish an event to a channel."""
        if not self.available():
            return False
        msg = {
            "from": self.agent_id,
            "message_id": str(uuid4()),
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "payload": payload,
        }
        self.redis.publish(channel, json.dumps(msg))
        return True

    def subscribe(self, channels: list, handler: Callable):
        """Subscribe to channels with a callback. Runs in background thread."""
        if not self.available():
            return False
        self._pubsub = self.redis.pubsub()
        self._pubsub.subscribe(**{ch: handler for ch in channels})
        self._thread = self._pubsub.run_in_thread(sleep_time=0.1)
        return True

    def request(self, target_agent: str, action: str,
                params: dict = None, timeout: int = 30) -> Optional[dict]:
        """Synchronous request-response to another agent."""
        if not self.available():
            return None

        request_id = f"{self.agent_id}:{uuid4()}"
        reply_channel = f"reply:{request_id}"

        self.redis.publish(f"requests:{target_agent}", json.dumps({
            "from": self.agent_id,
            "request_id": request_id,
            "action": action,
            "params": params or {},
            "reply_to": reply_channel,
        }))

        # Block until reply or timeout
        ps = self.redis.pubsub()
        ps.subscribe(reply_channel)
        ps.connection.set_socket_timeout(timeout)
        try:
            for msg in ps.listen():
                if msg["type"] == "message":
                    ps.unsubscribe(reply_channel)
                    return json.loads(msg["data"])
        except Exception as e:
            logger.warning("Agent request to %s/%s failed: %s", target_agent, action, e)
        finally:
            ps.close()
        return None

    def send_to_agent(self, target: str, message_type: str, data: dict):
        """Send a direct message to a specific agent."""
        return self.publish(f"agent:{target}", {
            "type": message_type,
            **data,
        })

    def broadcast(self, message_type: str, data: dict):
        """Broadcast to all agents."""
        return self.publish("broadcast", {
            "type": message_type,
            **data,
        })

    def close(self):
        """Clean up."""
        if self._thread:
            self._thread.stop()
        if self._pubsub:
            self._pubsub.close()


# Singleton for easy import
_broker = None

def get_broker() -> AgentBroker:
    global _broker
    if _broker is None:
        _broker = AgentBroker()
    return _broker
