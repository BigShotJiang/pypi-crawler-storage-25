"""
Evolution Engine — M2.7-inspired self-improvement loop for AIBrain.

Instead of passive review-and-report, this runs an active optimization cycle:
  analyze failure trajectories → plan changes → modify scaffold → evaluate → compare → keep/revert

The engine tracks:
  - Workflow outcomes (success/failure/partial)
  - Failure patterns (what breaks, why, how often)
  - Improvement hypotheses (proposed changes)
  - Experiments (changes applied + measured results)
  - Decisions (keep or revert, with evidence)

Each evolution cycle:
  1. Pull recent outcomes from all systems (jobs, crons, workflows, approvals)
  2. Identify failure trajectories — what failed and what led to it
  3. Generate improvement hypotheses (rule changes, workflow tweaks, new patterns)
  4. Score hypotheses by impact × confidence
  5. Apply top hypothesis as an experiment
  6. After N runs, compare before/after metrics
  7. Keep if improved, revert if not, log either way
"""

import json
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional


def get_evolution_db(db_path: Path):
    """Open or create the evolution tables in the consolidated DB."""
    db = sqlite3.connect(str(db_path))
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA journal_mode=WAL")
    db.executescript("""
        CREATE TABLE IF NOT EXISTS evolution_outcomes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source TEXT NOT NULL,          -- 'workflow', 'cron', 'approval', 'job_app', 'manual'
            source_id TEXT,                -- ID in the source system
            action TEXT NOT NULL,          -- what was attempted
            result TEXT NOT NULL,          -- 'success', 'failure', 'partial'
            details TEXT,                  -- what happened
            failure_reason TEXT,           -- if failed, why
            duration_seconds REAL,         -- how long it took
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS evolution_patterns (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            pattern TEXT NOT NULL,         -- description of the recurring pattern
            frequency INTEGER DEFAULT 1,  -- how many times observed
            severity TEXT DEFAULT 'medium', -- 'low', 'medium', 'high', 'critical'
            first_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            status TEXT DEFAULT 'active',  -- 'active', 'resolved', 'accepted_risk'
            related_outcomes TEXT,         -- JSON array of outcome IDs
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS evolution_hypotheses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            pattern_id INTEGER,            -- which pattern this addresses
            hypothesis TEXT NOT NULL,       -- what change to make
            change_type TEXT NOT NULL,      -- 'rule', 'workflow', 'config', 'code', 'prompt', 'schedule'
            target TEXT,                   -- what file/system to modify
            impact_score REAL DEFAULT 0.5, -- 0-1, estimated impact
            confidence REAL DEFAULT 0.5,   -- 0-1, how sure we are
            priority REAL GENERATED ALWAYS AS (impact_score * confidence) STORED,
            status TEXT DEFAULT 'proposed', -- 'proposed', 'testing', 'accepted', 'rejected', 'deferred'
            proposed_change TEXT,           -- the actual change (diff, config, rule text)
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (pattern_id) REFERENCES evolution_patterns(id)
        );

        CREATE TABLE IF NOT EXISTS evolution_experiments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            hypothesis_id INTEGER NOT NULL,
            started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            ended_at TIMESTAMP,
            baseline_metrics TEXT,          -- JSON: metrics before change
            experiment_metrics TEXT,        -- JSON: metrics after change
            runs_completed INTEGER DEFAULT 0,
            runs_target INTEGER DEFAULT 5,  -- how many runs before we decide
            decision TEXT,                 -- 'keep', 'revert', 'extend', NULL
            decision_reason TEXT,
            reverted_at TIMESTAMP,
            FOREIGN KEY (hypothesis_id) REFERENCES evolution_hypotheses(id)
        );

        CREATE TABLE IF NOT EXISTS evolution_cycles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            completed_at TIMESTAMP,
            outcomes_analyzed INTEGER DEFAULT 0,
            patterns_found INTEGER DEFAULT 0,
            hypotheses_generated INTEGER DEFAULT 0,
            experiments_started INTEGER DEFAULT 0,
            experiments_decided INTEGER DEFAULT 0,
            summary TEXT,
            agent TEXT DEFAULT 'agent'     -- which agent ran this cycle
        );

        CREATE TABLE IF NOT EXISTS evolution_critiques (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            cycle_id INTEGER,              -- which evolution cycle produced this
            scope TEXT NOT NULL,            -- 'session', 'workflow', 'subagent', 'system'
            subject TEXT NOT NULL,          -- what is being critiqued
            observation TEXT NOT NULL,      -- what happened (factual)
            criticism TEXT NOT NULL,        -- what was wrong (judgment)
            suggested_fix TEXT,            -- proposed improvement
            severity TEXT DEFAULT 'medium', -- 'low', 'medium', 'high', 'critical'
            addressed BOOLEAN DEFAULT 0,   -- has this been acted on
            addressed_by TEXT,             -- hypothesis_id or manual note
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (cycle_id) REFERENCES evolution_cycles(id)
        );

        CREATE TABLE IF NOT EXISTS evolution_metrics (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            metric_name TEXT NOT NULL,      -- 'success_rate', 'avg_duration', 'skill_adherence', etc.
            metric_value REAL NOT NULL,
            source TEXT,                   -- which system produced this metric
            period TEXT,                   -- 'hourly', 'daily', 'weekly'
            recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS evolution_parameter_search (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            parameter_name TEXT NOT NULL,   -- e.g. 'scan_timeout', 'retry_count', 'batch_size'
            system TEXT NOT NULL,           -- which system this parameter belongs to
            current_value TEXT,
            tested_value TEXT,
            baseline_result REAL,          -- metric with current_value
            test_result REAL,              -- metric with tested_value
            runs INTEGER DEFAULT 0,
            decision TEXT,                 -- 'adopt', 'reject', 'testing'
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE INDEX IF NOT EXISTS idx_outcomes_source ON evolution_outcomes(source, created_at);
        CREATE INDEX IF NOT EXISTS idx_outcomes_result ON evolution_outcomes(result, created_at);
        CREATE INDEX IF NOT EXISTS idx_patterns_status ON evolution_patterns(status);
        CREATE INDEX IF NOT EXISTS idx_hypotheses_status ON evolution_hypotheses(status);
        CREATE INDEX IF NOT EXISTS idx_experiments_decision ON evolution_experiments(decision);
        CREATE INDEX IF NOT EXISTS idx_critiques_addressed ON evolution_critiques(addressed);
        CREATE INDEX IF NOT EXISTS idx_metrics_name ON evolution_metrics(metric_name, recorded_at);

        CREATE TABLE IF NOT EXISTS evolution_positive_patterns (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            pattern TEXT NOT NULL,              -- what's working
            principle TEXT NOT NULL,            -- WHY it works (the transferable insight)
            source_domain TEXT NOT NULL,        -- where it was first observed
            frequency INTEGER DEFAULT 1,       -- how many times this pattern succeeded
            strength TEXT DEFAULT 'emerging',   -- 'emerging', 'confirmed', 'core'
            scale TEXT DEFAULT 'micro',         -- 'micro', 'meso', 'macro' (pattern operates at which level)
            related_outcomes TEXT,              -- JSON array of outcome IDs
            first_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS evolution_replications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            pattern_id INTEGER NOT NULL,       -- which positive pattern to replicate
            target_domain TEXT NOT NULL,        -- where to apply it
            target_scale TEXT,                 -- micro/meso/macro in the target domain
            adaptation TEXT NOT NULL,          -- how the pattern adapts to the new domain
            status TEXT DEFAULT 'proposed',    -- 'proposed', 'testing', 'active', 'failed', 'superseded'
            implementation TEXT,              -- what was actually built/changed
            outcome_before TEXT,              -- JSON: metrics before replication
            outcome_after TEXT,               -- JSON: metrics after replication
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (pattern_id) REFERENCES evolution_positive_patterns(id)
        );

        CREATE TABLE IF NOT EXISTS evolution_feedback_loops (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,                -- descriptive name
            loop_type TEXT NOT NULL,           -- 'positive' (reinforcing) or 'negative' (balancing)
            description TEXT NOT NULL,         -- full description of the loop
            components TEXT NOT NULL,          -- JSON array: ordered list of components in the loop
            trigger TEXT,                      -- what initiates the loop
            output TEXT,                       -- what the loop produces
            input_source TEXT,                 -- where the output feeds back as input
            scale TEXT DEFAULT 'micro',        -- 'micro', 'meso', 'macro'
            status TEXT DEFAULT 'active',      -- 'active', 'broken', 'dormant', 'proposed'
            strength REAL DEFAULT 0.5,         -- 0-1, how strong/reliable this loop is
            last_triggered TIMESTAMP,
            times_completed INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE INDEX IF NOT EXISTS idx_positive_patterns_strength ON evolution_positive_patterns(strength);
        CREATE INDEX IF NOT EXISTS idx_replications_status ON evolution_replications(status);
        CREATE INDEX IF NOT EXISTS idx_loops_status ON evolution_feedback_loops(status, loop_type);
    """)
    return db


# ---------------------------------------------------------------------------
# Outcome Recording
# ---------------------------------------------------------------------------

def record_outcome(db_path: Path, source: str, action: str, result: str,
                   source_id: str = None, details: str = None,
                   failure_reason: str = None, duration_seconds: float = None):
    """Record the outcome of an action for evolution analysis."""
    db = get_evolution_db(db_path)
    cur = db.execute(
        """INSERT INTO evolution_outcomes
           (source, source_id, action, result, details, failure_reason, duration_seconds)
           VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (source, source_id, action, result, details, failure_reason, duration_seconds)
    )
    db.commit()
    outcome_id = cur.lastrowid
    db.close()
    return outcome_id


# ---------------------------------------------------------------------------
# Pattern Detection
# ---------------------------------------------------------------------------

def detect_patterns(db_path: Path, lookback_hours: int = 48):
    """Analyze recent outcomes and detect recurring failure patterns."""
    db = get_evolution_db(db_path)
    cutoff = (datetime.utcnow() - timedelta(hours=lookback_hours)).isoformat()

    # Get recent failures
    failures = db.execute(
        """SELECT * FROM evolution_outcomes
           WHERE result IN ('failure', 'partial')
           AND created_at > ?
           ORDER BY created_at DESC""",
        (cutoff,)
    ).fetchall()

    if not failures:
        db.close()
        return {"patterns_found": 0, "failures_analyzed": 0}

    # Group failures by failure_reason similarity
    reason_groups = {}
    for f in failures:
        reason = f["failure_reason"] or f["action"]
        # Simple grouping — normalize the reason
        key = reason.lower().strip()[:100]
        if key not in reason_groups:
            reason_groups[key] = []
        reason_groups[key].append(dict(f))

    patterns_found = 0
    for key, group in reason_groups.items():
        if len(group) < 2:
            continue  # Need at least 2 occurrences to be a pattern

        outcome_ids = [g["id"] for g in group]
        pattern_text = f"Recurring failure ({len(group)}x): {key}"

        # Check if this pattern already exists
        existing = db.execute(
            "SELECT id, frequency FROM evolution_patterns WHERE pattern LIKE ? AND status = 'active'",
            (f"%{key[:50]}%",)
        ).fetchone()

        if existing:
            db.execute(
                """UPDATE evolution_patterns
                   SET frequency = ?, last_seen = CURRENT_TIMESTAMP,
                       related_outcomes = ?
                   WHERE id = ?""",
                (existing["frequency"] + len(group),
                 json.dumps(outcome_ids), existing["id"])
            )
        else:
            severity = "high" if len(group) >= 5 else "medium" if len(group) >= 3 else "low"
            db.execute(
                """INSERT INTO evolution_patterns
                   (pattern, frequency, severity, related_outcomes)
                   VALUES (?, ?, ?, ?)""",
                (pattern_text, len(group), severity, json.dumps(outcome_ids))
            )
            patterns_found += 1

    db.commit()
    db.close()
    return {"patterns_found": patterns_found, "failures_analyzed": len(failures)}


# ---------------------------------------------------------------------------
# Hypothesis Management
# ---------------------------------------------------------------------------

def propose_hypothesis(db_path: Path, pattern_id: int, hypothesis: str,
                       change_type: str, target: str = None,
                       proposed_change: str = None,
                       impact_score: float = 0.5, confidence: float = 0.5):
    """Propose an improvement hypothesis for a detected pattern."""
    db = get_evolution_db(db_path)
    cur = db.execute(
        """INSERT INTO evolution_hypotheses
           (pattern_id, hypothesis, change_type, target, impact_score, confidence, proposed_change)
           VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (pattern_id, hypothesis, change_type, target,
         min(1.0, max(0.0, impact_score)),
         min(1.0, max(0.0, confidence)),
         proposed_change)
    )
    db.commit()
    hyp_id = cur.lastrowid
    db.close()
    return hyp_id


def get_top_hypotheses(db_path: Path, limit: int = 5):
    """Get highest-priority untested hypotheses."""
    db = get_evolution_db(db_path)
    rows = db.execute(
        """SELECT h.*, p.pattern, p.frequency, p.severity
           FROM evolution_hypotheses h
           LEFT JOIN evolution_patterns p ON h.pattern_id = p.id
           WHERE h.status = 'proposed'
           ORDER BY h.priority DESC
           LIMIT ?""",
        (limit,)
    ).fetchall()
    db.close()
    return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# Experiment Lifecycle
# ---------------------------------------------------------------------------

def start_experiment(db_path: Path, hypothesis_id: int,
                     baseline_metrics: dict, runs_target: int = 5):
    """Start an experiment for a hypothesis."""
    db = get_evolution_db(db_path)
    # Mark hypothesis as testing
    db.execute(
        "UPDATE evolution_hypotheses SET status = 'testing' WHERE id = ?",
        (hypothesis_id,)
    )
    cur = db.execute(
        """INSERT INTO evolution_experiments
           (hypothesis_id, baseline_metrics, runs_target)
           VALUES (?, ?, ?)""",
        (hypothesis_id, json.dumps(baseline_metrics), runs_target)
    )
    db.commit()
    exp_id = cur.lastrowid
    db.close()
    return exp_id


def record_experiment_run(db_path: Path, experiment_id: int):
    """Increment the run count for an active experiment."""
    db = get_evolution_db(db_path)
    db.execute(
        "UPDATE evolution_experiments SET runs_completed = runs_completed + 1 WHERE id = ?",
        (experiment_id,)
    )
    db.commit()
    row = db.execute(
        "SELECT runs_completed, runs_target FROM evolution_experiments WHERE id = ?",
        (experiment_id,)
    ).fetchone()
    db.close()
    if row:
        return {"runs_completed": row[0], "runs_target": row[1],
                "ready_to_decide": row[0] >= row[1]}
    return None


def decide_experiment(db_path: Path, experiment_id: int,
                      experiment_metrics: dict, decision: str,
                      reason: str = None):
    """Decide whether to keep or revert an experiment."""
    db = get_evolution_db(db_path)
    now = datetime.utcnow().isoformat()

    db.execute(
        """UPDATE evolution_experiments
           SET ended_at = ?, experiment_metrics = ?, decision = ?, decision_reason = ?
           WHERE id = ?""",
        (now, json.dumps(experiment_metrics), decision, reason, experiment_id)
    )

    # Update hypothesis status based on decision
    exp = db.execute(
        "SELECT hypothesis_id FROM evolution_experiments WHERE id = ?",
        (experiment_id,)
    ).fetchone()
    if exp:
        hyp_status = {
            "keep": "accepted",
            "revert": "rejected",
            "extend": "testing",
        }.get(decision, "proposed")
        db.execute(
            "UPDATE evolution_hypotheses SET status = ? WHERE id = ?",
            (hyp_status, exp["hypothesis_id"])
        )

        # If reverted, mark the revert timestamp
        if decision == "revert":
            db.execute(
                "UPDATE evolution_experiments SET reverted_at = ? WHERE id = ?",
                (now, experiment_id)
            )

        # If accepted, resolve the pattern
        if decision == "keep":
            hyp = db.execute(
                "SELECT pattern_id FROM evolution_hypotheses WHERE id = ?",
                (exp["hypothesis_id"],)
            ).fetchone()
            if hyp and hyp["pattern_id"]:
                db.execute(
                    "UPDATE evolution_patterns SET status = 'resolved' WHERE id = ?",
                    (hyp["pattern_id"],)
                )

    db.commit()
    db.close()
    return {"experiment_id": experiment_id, "decision": decision}


# ---------------------------------------------------------------------------
# Evolution Cycle — the main loop
# ---------------------------------------------------------------------------

def run_evolution_cycle(db_path: Path, agent: str = None):
    agent = agent or os.environ.get("AGENT_ID", "agent")
    """Run a full evolution cycle: analyze → detect → hypothesize → experiment → decide."""
    db = get_evolution_db(db_path)

    # Start cycle record
    cycle_cur = db.execute(
        "INSERT INTO evolution_cycles (agent) VALUES (?)", (agent,)
    )
    cycle_id = cycle_cur.lastrowid
    db.commit()

    # 1. Count recent outcomes
    cutoff_24h = (datetime.utcnow() - timedelta(hours=24)).isoformat()
    outcomes = db.execute(
        "SELECT result, COUNT(*) as cnt FROM evolution_outcomes WHERE created_at > ? GROUP BY result",
        (cutoff_24h,)
    ).fetchall()
    outcomes_analyzed = sum(r["cnt"] for r in outcomes)
    outcomes_summary = {r["result"]: r["cnt"] for r in outcomes}

    # 2. Detect patterns
    db.close()
    pattern_result = detect_patterns(db_path, lookback_hours=48)

    # 3. Check active experiments that are ready to decide
    db = get_evolution_db(db_path)
    ready_experiments = db.execute(
        """SELECT e.*, h.hypothesis, h.change_type
           FROM evolution_experiments e
           JOIN evolution_hypotheses h ON e.hypothesis_id = h.id
           WHERE e.decision IS NULL AND e.runs_completed >= e.runs_target"""
    ).fetchall()

    # 4. Get active patterns without hypotheses
    unaddressed_patterns = db.execute(
        """SELECT p.* FROM evolution_patterns p
           WHERE p.status = 'active'
           AND NOT EXISTS (
               SELECT 1 FROM evolution_hypotheses h
               WHERE h.pattern_id = p.id AND h.status IN ('proposed', 'testing', 'accepted')
           )
           ORDER BY p.frequency DESC, p.severity DESC
           LIMIT 5"""
    ).fetchall()

    # 5. Compile summary
    summary = {
        "cycle_id": cycle_id,
        "outcomes_24h": outcomes_summary,
        "outcomes_analyzed": outcomes_analyzed,
        "patterns_found": pattern_result["patterns_found"],
        "experiments_ready_to_decide": len(ready_experiments),
        "unaddressed_patterns": [dict(p) for p in unaddressed_patterns],
        "ready_experiments": [dict(e) for e in ready_experiments],
    }

    # Update cycle record
    db.execute(
        """UPDATE evolution_cycles
           SET completed_at = CURRENT_TIMESTAMP,
               outcomes_analyzed = ?,
               patterns_found = ?,
               experiments_decided = ?,
               summary = ?
           WHERE id = ?""",
        (outcomes_analyzed, pattern_result["patterns_found"],
         len(ready_experiments), json.dumps(summary), cycle_id)
    )
    db.commit()
    db.close()

    return summary


# ---------------------------------------------------------------------------
# Dashboard / Reporting
# ---------------------------------------------------------------------------

def get_evolution_dashboard(db_path: Path):
    """Get a high-level view of the evolution system state."""
    db = get_evolution_db(db_path)

    # Recent outcomes
    cutoff = (datetime.utcnow() - timedelta(hours=24)).isoformat()
    outcome_counts = {}
    for r in db.execute(
        "SELECT result, COUNT(*) as cnt FROM evolution_outcomes WHERE created_at > ? GROUP BY result",
        (cutoff,)
    ).fetchall():
        outcome_counts[r["result"]] = r["cnt"]

    # Active patterns
    active_patterns = db.execute(
        "SELECT COUNT(*) as cnt FROM evolution_patterns WHERE status = 'active'"
    ).fetchone()["cnt"]

    # Hypotheses by status
    hyp_counts = {}
    for r in db.execute(
        "SELECT status, COUNT(*) as cnt FROM evolution_hypotheses GROUP BY status"
    ).fetchall():
        hyp_counts[r["status"]] = r["cnt"]

    # Active experiments
    active_experiments = db.execute(
        "SELECT COUNT(*) as cnt FROM evolution_experiments WHERE decision IS NULL"
    ).fetchone()["cnt"]

    # Win/loss rate
    accepted = db.execute(
        "SELECT COUNT(*) as cnt FROM evolution_experiments WHERE decision = 'keep'"
    ).fetchone()["cnt"]
    rejected = db.execute(
        "SELECT COUNT(*) as cnt FROM evolution_experiments WHERE decision = 'revert'"
    ).fetchone()["cnt"]
    total_decided = accepted + rejected

    # Last cycle
    last_cycle = db.execute(
        "SELECT * FROM evolution_cycles ORDER BY id DESC LIMIT 1"
    ).fetchone()

    # Success rate trend (last 7 days, daily)
    trend = []
    for i in range(7):
        day_start = (datetime.utcnow() - timedelta(days=i+1)).isoformat()
        day_end = (datetime.utcnow() - timedelta(days=i)).isoformat()
        day_data = db.execute(
            """SELECT
                COUNT(CASE WHEN result = 'success' THEN 1 END) as successes,
                COUNT(*) as total
               FROM evolution_outcomes
               WHERE created_at BETWEEN ? AND ?""",
            (day_start, day_end)
        ).fetchone()
        if day_data["total"] > 0:
            trend.append({
                "date": (datetime.utcnow() - timedelta(days=i)).strftime("%Y-%m-%d"),
                "success_rate": round(day_data["successes"] / day_data["total"], 3),
                "total": day_data["total"],
            })

    # Unaddressed critiques
    unaddressed_critiques = db.execute(
        "SELECT COUNT(*) as cnt FROM evolution_critiques WHERE addressed = 0"
    ).fetchone()["cnt"]

    # Parameter searches in progress
    active_searches = db.execute(
        "SELECT COUNT(*) as cnt FROM evolution_parameter_search WHERE decision = 'testing'"
    ).fetchone()["cnt"]

    db.close()

    return {
        "outcomes_24h": outcome_counts,
        "active_patterns": active_patterns,
        "hypotheses": hyp_counts,
        "active_experiments": active_experiments,
        "improvement_rate": round(accepted / total_decided, 3) if total_decided > 0 else None,
        "total_experiments_decided": total_decided,
        "last_cycle": dict(last_cycle) if last_cycle else None,
        "success_rate_trend": trend,
        "unaddressed_critiques": unaddressed_critiques,
        "active_parameter_searches": active_searches,
    }


# ---------------------------------------------------------------------------
# Self-Criticism — M2.7's key insight: critique every cycle's results
# ---------------------------------------------------------------------------

def record_critique(db_path: Path, scope: str, subject: str,
                    observation: str, criticism: str,
                    suggested_fix: str = None, severity: str = "medium",
                    cycle_id: int = None):
    """Record a self-criticism entry. Called after each evolution cycle or session."""
    db = get_evolution_db(db_path)
    cur = db.execute(
        """INSERT INTO evolution_critiques
           (cycle_id, scope, subject, observation, criticism, suggested_fix, severity)
           VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (cycle_id, scope, subject, observation, criticism, suggested_fix, severity)
    )
    db.commit()
    critique_id = cur.lastrowid
    db.close()
    return critique_id


def get_unaddressed_critiques(db_path: Path, limit: int = 20):
    """Get critiques that haven't been addressed yet."""
    db = get_evolution_db(db_path)
    rows = db.execute(
        """SELECT * FROM evolution_critiques
           WHERE addressed = 0
           ORDER BY
             CASE severity WHEN 'critical' THEN 1 WHEN 'high' THEN 2
                           WHEN 'medium' THEN 3 WHEN 'low' THEN 4 END,
             created_at DESC
           LIMIT ?""",
        (limit,)
    ).fetchall()
    db.close()
    return [dict(r) for r in rows]


def address_critique(db_path: Path, critique_id: int, addressed_by: str):
    """Mark a critique as addressed."""
    db = get_evolution_db(db_path)
    db.execute(
        "UPDATE evolution_critiques SET addressed = 1, addressed_by = ? WHERE id = ?",
        (addressed_by, critique_id)
    )
    db.commit()
    db.close()


# ---------------------------------------------------------------------------
# Metric Tracking — measure what matters
# ---------------------------------------------------------------------------

def record_metric(db_path: Path, metric_name: str, metric_value: float,
                  source: str = None, period: str = "snapshot"):
    """Record a metric for trend analysis."""
    db = get_evolution_db(db_path)
    db.execute(
        "INSERT INTO evolution_metrics (metric_name, metric_value, source, period) VALUES (?, ?, ?, ?)",
        (metric_name, metric_value, source, period)
    )
    db.commit()
    db.close()


def get_metric_trend(db_path: Path, metric_name: str, days: int = 7):
    """Get trend data for a metric."""
    db = get_evolution_db(db_path)
    cutoff = (datetime.utcnow() - timedelta(days=days)).isoformat()
    rows = db.execute(
        """SELECT metric_value, source, period, recorded_at
           FROM evolution_metrics
           WHERE metric_name = ? AND recorded_at > ?
           ORDER BY recorded_at ASC""",
        (metric_name, cutoff)
    ).fetchall()
    db.close()
    return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# Parameter Search — systematic optimization of workflow parameters
# ---------------------------------------------------------------------------

def start_parameter_search(db_path: Path, parameter_name: str, system: str,
                           current_value: str, tested_value: str,
                           baseline_result: float = None):
    """Start a parameter optimization search."""
    db = get_evolution_db(db_path)
    cur = db.execute(
        """INSERT INTO evolution_parameter_search
           (parameter_name, system, current_value, tested_value, baseline_result, decision)
           VALUES (?, ?, ?, ?, ?, 'testing')""",
        (parameter_name, system, current_value, tested_value, baseline_result)
    )
    db.commit()
    search_id = cur.lastrowid
    db.close()
    return search_id


def update_parameter_search(db_path: Path, search_id: int,
                            test_result: float, runs: int = None,
                            decision: str = None):
    """Update a parameter search with results."""
    db = get_evolution_db(db_path)
    fields = ["test_result = ?"]
    params = [test_result]
    if runs is not None:
        fields.append("runs = ?")
        params.append(runs)
    if decision:
        fields.append("decision = ?")
        params.append(decision)
    params.append(search_id)
    db.execute(
        f"UPDATE evolution_parameter_search SET {', '.join(fields)} WHERE id = ?",
        params
    )
    db.commit()
    db.close()


def get_parameter_searches(db_path: Path, system: str = None, active_only: bool = True):
    """Get parameter searches, optionally filtered by system."""
    db = get_evolution_db(db_path)
    where = []
    params = []
    if system:
        where.append("system = ?")
        params.append(system)
    if active_only:
        where.append("decision = 'testing'")
    where_sql = (" WHERE " + " AND ".join(where)) if where else ""
    rows = db.execute(
        f"SELECT * FROM evolution_parameter_search {where_sql} ORDER BY created_at DESC",
        params
    ).fetchall()
    db.close()
    return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# Loop Detection — catch when agents are stuck repeating
# ---------------------------------------------------------------------------

def detect_loops(db_path: Path, window_minutes: int = 30, threshold: int = 3):
    """Detect if the same action is being repeated without progress."""
    db = get_evolution_db(db_path)
    cutoff = (datetime.utcnow() - timedelta(minutes=window_minutes)).isoformat()

    # Find actions that have been attempted multiple times recently
    repeated = db.execute(
        """SELECT action, source, COUNT(*) as attempts,
                  SUM(CASE WHEN result = 'failure' THEN 1 ELSE 0 END) as failures
           FROM evolution_outcomes
           WHERE created_at > ?
           GROUP BY action, source
           HAVING COUNT(*) >= ?
           ORDER BY attempts DESC""",
        (cutoff, threshold)
    ).fetchall()

    loops = []
    for r in repeated:
        row = dict(r)
        if row["failures"] >= threshold:
            loops.append({
                **row,
                "type": "stuck_loop",
                "recommendation": f"Action '{row['action']}' has failed {row['failures']}/{row['attempts']} times in {window_minutes}min. Stop and investigate root cause.",
            })
        elif row["attempts"] >= threshold * 2:
            loops.append({
                **row,
                "type": "repetition_loop",
                "recommendation": f"Action '{row['action']}' attempted {row['attempts']} times in {window_minutes}min. May be spinning without progress.",
            })

    db.close()
    return loops


# ---------------------------------------------------------------------------
# Positive Pattern Detection — what's working and why
# ---------------------------------------------------------------------------

def detect_positive_patterns(db_path: Path, lookback_hours: int = 168):
    """Analyze recent outcomes and detect recurring SUCCESS patterns.
    Default lookback is 7 days — positive patterns take longer to emerge."""
    db = get_evolution_db(db_path)
    cutoff = (datetime.utcnow() - timedelta(hours=lookback_hours)).isoformat()

    successes = db.execute(
        """SELECT * FROM evolution_outcomes
           WHERE result = 'success'
           AND created_at > ?
           ORDER BY created_at DESC""",
        (cutoff,)
    ).fetchall()

    if not successes:
        db.close()
        return {"positive_patterns_found": 0, "successes_analyzed": 0}

    # Group successes by action type
    action_groups = {}
    for s in successes:
        action = s["action"]
        if action not in action_groups:
            action_groups[action] = []
        action_groups[action].append(dict(s))

    patterns_found = 0
    for action, group in action_groups.items():
        if len(group) < 2:
            continue  # Need at least 2 successes to be a pattern

        outcome_ids = [g["id"] for g in group]

        # Calculate consistency — is it always succeeding?
        total_for_action = db.execute(
            "SELECT COUNT(*) as cnt FROM evolution_outcomes WHERE action = ? AND created_at > ?",
            (action, cutoff)
        ).fetchone()["cnt"]
        success_rate = len(group) / total_for_action if total_for_action > 0 else 0

        if success_rate < 0.7:
            continue  # Less than 70% success rate — not a reliable pattern

        # Determine strength
        if len(group) >= 10 and success_rate >= 0.95:
            strength = "core"
        elif len(group) >= 5 and success_rate >= 0.8:
            strength = "confirmed"
        else:
            strength = "emerging"

        pattern_text = f"Consistent success ({len(group)}x, {success_rate:.0%} rate): {action}"

        # Check if already tracked
        existing = db.execute(
            "SELECT id, frequency FROM evolution_positive_patterns WHERE pattern LIKE ?",
            (f"%{action}%",)
        ).fetchone()

        if existing:
            db.execute(
                """UPDATE evolution_positive_patterns
                   SET frequency = ?, strength = ?, last_seen = CURRENT_TIMESTAMP,
                       related_outcomes = ?
                   WHERE id = ?""",
                (len(group), strength, json.dumps(outcome_ids), existing["id"])
            )
        else:
            db.execute(
                """INSERT INTO evolution_positive_patterns
                   (pattern, principle, source_domain, frequency, strength, related_outcomes)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (pattern_text,
                 f"Action '{action}' succeeds reliably ({success_rate:.0%}). Analyze what makes it work and apply elsewhere.",
                 group[0].get("source", "unknown"),
                 len(group), strength, json.dumps(outcome_ids))
            )
            patterns_found += 1

    db.commit()
    db.close()
    return {"positive_patterns_found": patterns_found, "successes_analyzed": len(successes)}


def record_positive_pattern(db_path: Path, pattern: str, principle: str,
                            source_domain: str, scale: str = "micro",
                            strength: str = "emerging"):
    """Manually record a positive pattern — for principles like 'all outputs become inputs'."""
    db = get_evolution_db(db_path)
    cur = db.execute(
        """INSERT INTO evolution_positive_patterns
           (pattern, principle, source_domain, scale, strength)
           VALUES (?, ?, ?, ?, ?)""",
        (pattern, principle, source_domain, scale, strength)
    )
    db.commit()
    pid = cur.lastrowid
    db.close()
    return pid


def get_positive_patterns(db_path: Path, strength: str = None,
                          scale: str = None, limit: int = 20):
    """Get positive patterns, optionally filtered."""
    db = get_evolution_db(db_path)
    where = []
    params = []
    if strength:
        where.append("strength = ?")
        params.append(strength)
    if scale:
        where.append("scale = ?")
        params.append(scale)
    where_sql = (" WHERE " + " AND ".join(where)) if where else ""
    params.append(limit)
    rows = db.execute(
        f"""SELECT * FROM evolution_positive_patterns {where_sql}
            ORDER BY CASE strength WHEN 'core' THEN 1 WHEN 'confirmed' THEN 2 ELSE 3 END,
                     frequency DESC
            LIMIT ?""",
        params
    ).fetchall()
    db.close()
    return [dict(r) for r in rows]


def update_positive_pattern(db_path: Path, pattern_id: int,
                            principle: str = None, scale: str = None,
                            strength: str = None):
    """Update a positive pattern's principle, scale, or strength."""
    db = get_evolution_db(db_path)
    fields = []
    params = []
    if principle:
        fields.append("principle = ?")
        params.append(principle)
    if scale:
        fields.append("scale = ?")
        params.append(scale)
    if strength:
        fields.append("strength = ?")
        params.append(strength)
    if not fields:
        db.close()
        return
    params.append(pattern_id)
    db.execute(
        f"UPDATE evolution_positive_patterns SET {', '.join(fields)} WHERE id = ?",
        params
    )
    db.commit()
    db.close()


# ---------------------------------------------------------------------------
# Pattern Replication — apply what works in one domain to another
# ---------------------------------------------------------------------------

def propose_replication(db_path: Path, pattern_id: int, target_domain: str,
                        adaptation: str, target_scale: str = None,
                        implementation: str = None):
    """Propose replicating a positive pattern into a new domain."""
    db = get_evolution_db(db_path)
    cur = db.execute(
        """INSERT INTO evolution_replications
           (pattern_id, target_domain, target_scale, adaptation, implementation)
           VALUES (?, ?, ?, ?, ?)""",
        (pattern_id, target_domain, target_scale, adaptation, implementation)
    )
    db.commit()
    rid = cur.lastrowid
    db.close()
    return rid


def update_replication(db_path: Path, replication_id: int,
                       status: str = None, implementation: str = None,
                       outcome_before: dict = None, outcome_after: dict = None):
    """Update a replication's status and results."""
    db = get_evolution_db(db_path)
    fields = ["updated_at = CURRENT_TIMESTAMP"]
    params = []
    if status:
        fields.append("status = ?")
        params.append(status)
    if implementation:
        fields.append("implementation = ?")
        params.append(implementation)
    if outcome_before is not None:
        fields.append("outcome_before = ?")
        params.append(json.dumps(outcome_before))
    if outcome_after is not None:
        fields.append("outcome_after = ?")
        params.append(json.dumps(outcome_after))
    params.append(replication_id)
    db.execute(
        f"UPDATE evolution_replications SET {', '.join(fields)} WHERE id = ?",
        params
    )
    db.commit()
    db.close()


def get_replications(db_path: Path, pattern_id: int = None,
                     status: str = None, limit: int = 20):
    """Get pattern replications."""
    db = get_evolution_db(db_path)
    where = []
    params = []
    if pattern_id:
        where.append("r.pattern_id = ?")
        params.append(pattern_id)
    if status:
        where.append("r.status = ?")
        params.append(status)
    where_sql = (" WHERE " + " AND ".join(where)) if where else ""
    params.append(limit)
    rows = db.execute(
        f"""SELECT r.*, p.pattern, p.principle, p.source_domain, p.scale as source_scale
            FROM evolution_replications r
            JOIN evolution_positive_patterns p ON r.pattern_id = p.id
            {where_sql}
            ORDER BY r.created_at DESC LIMIT ?""",
        params
    ).fetchall()
    db.close()
    return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# Feedback Loops — explicit tracking of reinforcing and balancing loops
# ---------------------------------------------------------------------------

def create_feedback_loop(db_path: Path, name: str, loop_type: str,
                         description: str, components: list,
                         trigger: str = None, output: str = None,
                         input_source: str = None, scale: str = "micro"):
    """Register a feedback loop in the system."""
    if loop_type not in ("positive", "negative"):
        raise ValueError("loop_type must be 'positive' or 'negative'")
    db = get_evolution_db(db_path)
    cur = db.execute(
        """INSERT INTO evolution_feedback_loops
           (name, loop_type, description, components, trigger, output, input_source, scale)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
        (name, loop_type, description, json.dumps(components),
         trigger, output, input_source, scale)
    )
    db.commit()
    lid = cur.lastrowid
    db.close()
    return lid


def trigger_feedback_loop(db_path: Path, loop_id: int):
    """Record that a feedback loop was triggered/completed."""
    db = get_evolution_db(db_path)
    db.execute(
        """UPDATE evolution_feedback_loops
           SET times_completed = times_completed + 1,
               last_triggered = CURRENT_TIMESTAMP,
               strength = MIN(1.0, strength + 0.05),
               updated_at = CURRENT_TIMESTAMP
           WHERE id = ?""",
        (loop_id,)
    )
    db.commit()
    db.close()


def get_feedback_loops(db_path: Path, loop_type: str = None,
                       status: str = "active", scale: str = None):
    """Get feedback loops."""
    db = get_evolution_db(db_path)
    where = []
    params = []
    if loop_type:
        where.append("loop_type = ?")
        params.append(loop_type)
    if status:
        where.append("status = ?")
        params.append(status)
    if scale:
        where.append("scale = ?")
        params.append(scale)
    where_sql = (" WHERE " + " AND ".join(where)) if where else ""
    rows = db.execute(
        f"""SELECT * FROM evolution_feedback_loops {where_sql}
            ORDER BY strength DESC, times_completed DESC""",
        params
    ).fetchall()
    db.close()
    return [dict(r) for r in rows]


def update_feedback_loop(db_path: Path, loop_id: int,
                         status: str = None, strength: float = None,
                         description: str = None, components: list = None):
    """Update a feedback loop."""
    db = get_evolution_db(db_path)
    fields = ["updated_at = CURRENT_TIMESTAMP"]
    params = []
    if status:
        fields.append("status = ?")
        params.append(status)
    if strength is not None:
        fields.append("strength = ?")
        params.append(min(1.0, max(0.0, strength)))
    if description:
        fields.append("description = ?")
        params.append(description)
    if components is not None:
        fields.append("components = ?")
        params.append(json.dumps(components))
    params.append(loop_id)
    db.execute(
        f"UPDATE evolution_feedback_loops SET {', '.join(fields)} WHERE id = ?",
        params
    )
    db.commit()
    db.close()


# ---------------------------------------------------------------------------
# Cross-Scale Analysis — micro/meso/macro perspective matching
# ---------------------------------------------------------------------------

def analyze_cross_scale(db_path: Path):
    """Find patterns that exist at one scale but haven't been applied at others.
    This is the micro/macro perspective engine."""
    db = get_evolution_db(db_path)

    patterns = db.execute(
        "SELECT * FROM evolution_positive_patterns WHERE strength IN ('confirmed', 'core')"
    ).fetchall()

    # Check which scales each pattern has been replicated to
    opportunities = []
    scales = ["micro", "meso", "macro"]

    for p in patterns:
        p = dict(p)
        current_scale = p.get("scale", "micro")

        # Find existing replications for this pattern
        reps = db.execute(
            "SELECT target_scale FROM evolution_replications WHERE pattern_id = ? AND status IN ('active', 'testing')",
            (p["id"],)
        ).fetchall()
        covered_scales = {current_scale} | {r["target_scale"] for r in reps if r["target_scale"]}

        # Find uncovered scales
        uncovered = [s for s in scales if s not in covered_scales]
        if uncovered:
            opportunities.append({
                "pattern_id": p["id"],
                "pattern": p["pattern"],
                "principle": p["principle"],
                "current_scale": current_scale,
                "covered_scales": list(covered_scales),
                "opportunity_scales": uncovered,
                "strength": p["strength"],
            })

    # Also check feedback loops for scale gaps
    loops = db.execute(
        "SELECT * FROM evolution_feedback_loops WHERE status = 'active'"
    ).fetchall()

    loop_scale_counts = {"micro": 0, "meso": 0, "macro": 0}
    for loop in loops:
        s = loop["scale"] or "micro"
        if s in loop_scale_counts:
            loop_scale_counts[s] += 1

    db.close()

    return {
        "replication_opportunities": opportunities,
        "loop_scale_distribution": loop_scale_counts,
        "total_patterns_analyzed": len(patterns),
        "patterns_with_gaps": len(opportunities),
    }
