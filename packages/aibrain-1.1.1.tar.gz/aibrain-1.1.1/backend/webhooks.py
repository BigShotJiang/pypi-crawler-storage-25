"""
AIBrain Webhooks — event-driven workflow triggers as an alternative to cron.
Accepts incoming webhooks, validates signatures, triggers workflows, logs history.
"""

import hashlib
import hmac
import json
import logging
import secrets
import sqlite3
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, Query, Request
from fastapi.responses import JSONResponse

import os

logger = logging.getLogger(__name__)

AIBRAIN_ROOT = Path(os.environ.get("AIBRAIN_ROOT", Path(__file__).parent.parent))
WEBHOOKS_CONFIG = AIBRAIN_ROOT / "webhooks.json"
ACTIVITY_DB_PATH = AIBRAIN_ROOT / "activity.db"
WEBHOOKS_DB_PATH = AIBRAIN_ROOT / "webhooks.db"

router = APIRouter(tags=["Webhooks"])


# ---------------------------------------------------------------------------
# DB — webhook invocation history
# ---------------------------------------------------------------------------

def _get_webhooks_db():
    db = sqlite3.connect(str(WEBHOOKS_DB_PATH))
    db.execute("PRAGMA journal_mode=wal")
    db.row_factory = sqlite3.Row
    db.execute("""
        CREATE TABLE IF NOT EXISTS webhook_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            hook_name TEXT NOT NULL,
            timestamp TEXT NOT NULL,
            source_ip TEXT DEFAULT '',
            payload_preview TEXT DEFAULT '',
            workflow TEXT DEFAULT '',
            exit_code INTEGER DEFAULT -1,
            duration_ms INTEGER DEFAULT 0,
            status TEXT DEFAULT 'ok',
            error TEXT DEFAULT ''
        )
    """)
    db.commit()
    return db


def _log_activity(action: str, category: str, detail: str, status: str = "ok"):
    """Log to the shared activity DB (same pattern as scheduler.py)."""
    db = None
    try:
        db = sqlite3.connect(str(ACTIVITY_DB_PATH))
        db.execute("PRAGMA journal_mode=wal")
        db.execute(
            "CREATE TABLE IF NOT EXISTS activity (id INTEGER PRIMARY KEY AUTOINCREMENT, "
            "timestamp TEXT NOT NULL, agent TEXT NOT NULL DEFAULT 'agent', "
            "action TEXT NOT NULL, category TEXT DEFAULT 'general', "
            "detail TEXT DEFAULT '', status TEXT DEFAULT 'ok')"
        )
        db.execute(
            "INSERT INTO activity (timestamp, agent, action, category, detail, status) VALUES (?, ?, ?, ?, ?, ?)",
            (datetime.now().isoformat(), "webhooks", action, category, detail, status),
        )
        db.commit()
    except Exception as e:
        logger.warning("Failed to log activity: %s", e)
    finally:
        if db:
            db.close()


# ---------------------------------------------------------------------------
# Config helpers
# ---------------------------------------------------------------------------

def _load_config() -> dict:
    if WEBHOOKS_CONFIG.exists():
        try:
            return json.loads(WEBHOOKS_CONFIG.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            pass
    return {}


def _save_config(config: dict):
    WEBHOOKS_CONFIG.write_text(json.dumps(config, indent=2), encoding="utf-8")


# ---------------------------------------------------------------------------
# Signature validation
# ---------------------------------------------------------------------------

def _validate_signature(hook_cfg: dict, body: bytes, headers: dict) -> bool:
    """
    Validate webhook signature. Supports:
    - GitHub-style HMAC-SHA256 (X-Hub-Signature-256 header)
    - Simple token match (X-Webhook-Token header)
    If no secret is configured, skip validation.
    """
    secret = hook_cfg.get("secret", "")
    if not secret:
        return True

    # GitHub-style: X-Hub-Signature-256: sha256=<hex>
    gh_sig = headers.get("x-hub-signature-256", "")
    if gh_sig:
        expected = "sha256=" + hmac.new(
            secret.encode(), body, hashlib.sha256
        ).hexdigest()
        return hmac.compare_digest(expected, gh_sig)

    # Simple token: X-Webhook-Token: <token>
    token = headers.get("x-webhook-token", "")
    if token:
        return hmac.compare_digest(secret, token)

    # No recognized auth header — reject if secret is configured
    return False


# ---------------------------------------------------------------------------
# Workflow execution (mirrors scheduler._run_workflow)
# ---------------------------------------------------------------------------

def _run_workflow(workflow_name: str) -> dict:
    """Execute a workflow script and return result dict."""
    script = (AIBRAIN_ROOT / "workflows" / f"{workflow_name}.py").resolve()
    if not str(script).startswith(str((AIBRAIN_ROOT / "workflows").resolve())):
        return {"exit_code": -3, "error": "Invalid workflow name", "duration_ms": 0}
    if not script.exists():
        return {"exit_code": -3, "error": f"Script not found: {workflow_name}.py", "duration_ms": 0}

    start = datetime.now()
    try:
        result = subprocess.run(
            [sys.executable, str(script)],
            capture_output=True, text=True, timeout=120,
            cwd=str(AIBRAIN_ROOT),
        )
        return {
            "exit_code": result.returncode,
            "stdout_preview": (result.stdout or "")[-500:],
            "stderr_preview": (result.stderr or "")[-200:],
            "duration_ms": int((datetime.now() - start).total_seconds() * 1000),
            "error": "",
        }
    except subprocess.TimeoutExpired:
        return {"exit_code": -1, "error": "TIMEOUT after 120s", "duration_ms": 120000}
    except Exception as e:
        return {
            "exit_code": -2,
            "error": str(e),
            "duration_ms": int((datetime.now() - start).total_seconds() * 1000),
        }


# ---------------------------------------------------------------------------
# Incoming webhook endpoint
# ---------------------------------------------------------------------------

@router.post("/webhooks/{hook_name}")
async def receive_webhook(hook_name: str, request: Request):
    """Accept an incoming webhook, validate it, and trigger the associated workflow."""
    config = _load_config()
    hook_cfg = config.get(hook_name)

    if not hook_cfg:
        return JSONResponse({"error": f"Unknown webhook: {hook_name}"}, status_code=404)

    if not hook_cfg.get("enabled", False):
        return JSONResponse({"error": f"Webhook '{hook_name}' is disabled"}, status_code=403)

    # Read raw body for signature validation
    body = await request.body()
    headers = {k.lower(): v for k, v in request.headers.items()}

    if not _validate_signature(hook_cfg, body, headers):
        _log_activity(f"webhook/{hook_name}", "webhook", "signature validation failed", "error")
        return JSONResponse({"error": "Invalid signature"}, status_code=401)

    # Parse payload for logging
    try:
        payload = json.loads(body) if body else {}
    except (json.JSONDecodeError, UnicodeDecodeError):
        payload = {"_raw_length": len(body)}

    payload_preview = json.dumps(payload, default=str)[:500]
    source_ip = request.client.host if request.client else "unknown"
    now = datetime.now().isoformat()

    # Run the associated workflow
    workflow = hook_cfg.get("workflow", "")
    if workflow:
        result = _run_workflow(workflow)
    else:
        result = {"exit_code": 0, "error": "No workflow configured — event logged only", "duration_ms": 0}

    status = "ok" if result["exit_code"] == 0 else "error"

    # Log to webhook history DB
    try:
        db = _get_webhooks_db()
        db.execute(
            "INSERT INTO webhook_history (hook_name, timestamp, source_ip, payload_preview, "
            "workflow, exit_code, duration_ms, status, error) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (hook_name, now, source_ip, payload_preview, workflow,
             result["exit_code"], result["duration_ms"], status, result.get("error", "")),
        )
        db.commit()
        db.close()
    except Exception as e:
        logger.warning("Failed to write webhook history: %s", e)

    # Log to shared activity DB
    _log_activity(
        f"webhook/{hook_name}",
        "webhook",
        f"workflow={workflow} exit={result['exit_code']} duration={result['duration_ms']}ms",
        status,
    )

    return {
        "hook": hook_name,
        "workflow": workflow,
        "status": status,
        "exit_code": result["exit_code"],
        "duration_ms": result["duration_ms"],
        "error": result.get("error", ""),
        "timestamp": now,
    }


# ---------------------------------------------------------------------------
# Webhook management endpoints
# ---------------------------------------------------------------------------

@router.get("/webhooks")
async def list_webhooks():
    """List all configured webhooks (secrets redacted)."""
    config = _load_config()
    hooks = []
    for name, cfg in config.items():
        hooks.append({
            "name": name,
            "workflow": cfg.get("workflow", ""),
            "enabled": cfg.get("enabled", False),
            "has_secret": bool(cfg.get("secret", "")),
        })
    return {"count": len(hooks), "webhooks": hooks}


@router.post("/webhooks")
async def create_webhook(body: dict):
    """Create a new webhook config. Body: {name, workflow, ?secret, ?enabled}"""
    name = body.get("name")
    workflow = body.get("workflow", "")
    if not name:
        return JSONResponse({"error": "name required"}, status_code=400)

    # Sanitize name: alphanumeric + underscores only
    if not all(c.isalnum() or c == '_' for c in name):
        return JSONResponse({"error": "name must be alphanumeric/underscores only"}, status_code=400)

    config = _load_config()
    if name in config:
        return JSONResponse({"error": f"Webhook '{name}' already exists"}, status_code=409)

    # Generate a secret if none provided
    secret = body.get("secret", "")
    if not secret:
        secret = secrets.token_hex(32)

    config[name] = {
        "secret": secret,
        "workflow": workflow,
        "enabled": body.get("enabled", False),
        "created": datetime.now().isoformat(),
    }
    _save_config(config)

    _log_activity(f"webhook/{name}", "webhook", f"created — workflow={workflow}", "ok")

    return {
        "name": name,
        "workflow": workflow,
        "enabled": config[name]["enabled"],
        "secret": secret,
        "url": f"/webhooks/{name}",
    }


@router.delete("/webhooks/{name}")
async def delete_webhook(name: str):
    """Remove a webhook configuration."""
    config = _load_config()
    if name not in config:
        return JSONResponse({"error": f"Webhook '{name}' not found"}, status_code=404)

    del config[name]
    _save_config(config)

    _log_activity(f"webhook/{name}", "webhook", "deleted", "ok")
    return {"name": name, "status": "deleted"}


@router.put("/webhooks/{name}")
async def update_webhook(name: str, body: dict):
    """Update a webhook config. Body: {?workflow, ?secret, ?enabled}"""
    config = _load_config()
    if name not in config:
        return JSONResponse({"error": f"Webhook '{name}' not found"}, status_code=404)

    hook = config[name]
    if "workflow" in body:
        hook["workflow"] = body["workflow"]
    if "secret" in body:
        hook["secret"] = body["secret"]
    if "enabled" in body:
        hook["enabled"] = body["enabled"]

    _save_config(config)
    _log_activity(f"webhook/{name}", "webhook", "updated", "ok")

    return {
        "name": name,
        "workflow": hook.get("workflow", ""),
        "enabled": hook.get("enabled", False),
        "has_secret": bool(hook.get("secret", "")),
        "status": "updated",
    }


@router.get("/webhooks/{name}/history")
async def webhook_history(
    name: str,
    limit: int = Query(20),
):
    """Get recent invocation history for a webhook."""
    config = _load_config()
    if name not in config:
        return JSONResponse({"error": f"Webhook '{name}' not found"}, status_code=404)

    db = _get_webhooks_db()
    rows = db.execute(
        "SELECT * FROM webhook_history WHERE hook_name = ? ORDER BY timestamp DESC LIMIT ?",
        (name, limit),
    ).fetchall()
    db.close()

    return {
        "hook": name,
        "count": len(rows),
        "invocations": [dict(r) for r in rows],
    }
