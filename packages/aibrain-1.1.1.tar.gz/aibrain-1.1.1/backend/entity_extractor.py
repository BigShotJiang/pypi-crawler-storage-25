"""
Entity extraction for AIBrain memory graph.

Extracts named entities (people, tools, projects, URLs, technologies) from
memory content using pattern matching. No ML dependencies — runs fast on any machine.

Entities are stored in the entities table and linked to memories via memory_entities.
This powers the knowledge graph's auto-discovered relationships.
"""

import logging
import re
import sqlite3
from pathlib import Path

logger = logging.getLogger(__name__)


# Technical terms and categories that should be recognized as entities
TECH_PATTERNS = {
    "language": [
        "python", "javascript", "typescript", "rust", "go", "java", "ruby",
        "swift", "kotlin", "c\\+\\+", "c#", "php", "sql", "bash", "shell",
    ],
    "framework": [
        "react", "vue", "angular", "fastapi", "flask", "django", "express",
        "next\\.js", "nuxt", "svelte", "tailwind", "vite", "webpack",
        "langchain", "crewai", "autogen", "langgraph",
    ],
    "tool": [
        "docker", "kubernetes", "nginx", "redis", "postgresql", "sqlite",
        "mongodb", "elasticsearch", "git", "github", "gitlab", "npm",
        "pip", "ollama", "playwright", "puppeteer", "selenium",
        "terraform", "ansible", "grafana", "prometheus",
    ],
    "ai_model": [
        "claude", "gpt-4", "gpt-4o", "gpt-3\\.5", "llama", "mistral",
        "gemini", "codex", "whisper", "dall-e", "stable diffusion",
        "midjourney", "copilot",
    ],
    "platform": [
        "aws", "gcp", "azure", "vercel", "netlify", "heroku",
        "digitalocean", "cloudflare", "supabase", "firebase",
        "telegram", "discord", "slack", "linkedin", "twitter",
        "youtube", "instagram", "tiktok", "gumroad",
    ],
}

# Compile patterns
_COMPILED_PATTERNS: dict[str, list[tuple[re.Pattern, str]]] = {}
for category, terms in TECH_PATTERNS.items():
    _COMPILED_PATTERNS[category] = [
        (re.compile(rf"\b{t}\b", re.IGNORECASE), t) for t in terms
    ]

# Patterns for extracting other entity types
_URL_PATTERN = re.compile(r"https?://[^\s\)\"'>]+")
_EMAIL_PATTERN = re.compile(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}")
_IP_PATTERN = re.compile(r"\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b")
_CAPITALIZED_PATTERN = re.compile(r"\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)+\b")  # "John Smith", "New York"


def extract_entities(text: str) -> list[dict]:
    """Extract entities from text. Returns list of {name, type, category}."""
    entities = []
    seen = set()

    # Tech entities
    for category, patterns in _COMPILED_PATTERNS.items():
        for pattern, canonical in patterns:
            if pattern.search(text):
                key = (canonical.lower(), category)
                if key not in seen:
                    seen.add(key)
                    entities.append({
                        "name": canonical.replace("\\", ""),
                        "type": "technology",
                        "category": category,
                    })

    # URLs (extract domain as entity)
    for match in _URL_PATTERN.finditer(text):
        url = match.group()
        try:
            from urllib.parse import urlparse
            domain = urlparse(url).hostname
            if domain and (domain, "url") not in seen:
                seen.add((domain, "url"))
                entities.append({"name": domain, "type": "url", "category": "reference"})
        except Exception as e:
            logger.warning("Failed to parse URL entity: %s", e)

    # Emails
    for match in _EMAIL_PATTERN.finditer(text):
        email = match.group()
        if (email.lower(), "email") not in seen:
            seen.add((email.lower(), "email"))
            entities.append({"name": email, "type": "email", "category": "contact"})

    # IP addresses
    for match in _IP_PATTERN.finditer(text):
        ip = match.group()
        if (ip, "ip") not in seen:
            seen.add((ip, "ip"))
            entities.append({"name": ip, "type": "ip_address", "category": "infrastructure"})

    # Capitalized multi-word phrases (potential names/places)
    _skip_starts = {"the", "this", "that", "using", "after", "before", "with", "from",
                    "into", "about", "when", "where", "each", "every", "some", "here"}
    for match in _CAPITALIZED_PATTERN.finditer(text):
        phrase = match.group()
        words = phrase.split()
        if words[0].lower() in _skip_starts:
            continue
        if phrase.lower() in {"the first", "the last", "the next", "the best", "the most"}:
            continue
        if len(phrase) > 4 and len(words) >= 2 and (phrase.lower(), "name") not in seen:
            seen.add((phrase.lower(), "name"))
            entities.append({"name": phrase, "type": "name", "category": "entity"})

    return entities


def init_entity_tables(db_path: Path):
    """Create entity tables if they don't exist."""
    db = sqlite3.connect(str(db_path))
    db.execute("""
        CREATE TABLE IF NOT EXISTS entities (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            type TEXT NOT NULL,
            category TEXT DEFAULT '',
            mention_count INTEGER DEFAULT 1,
            first_seen TEXT NOT NULL,
            last_seen TEXT NOT NULL,
            UNIQUE(name, type)
        )
    """)
    db.execute("""
        CREATE TABLE IF NOT EXISTS memory_entities (
            memory_id INTEGER NOT NULL,
            entity_id INTEGER NOT NULL,
            PRIMARY KEY (memory_id, entity_id),
            FOREIGN KEY (memory_id) REFERENCES memories(id),
            FOREIGN KEY (entity_id) REFERENCES entities(id)
        )
    """)
    db.commit()
    db.close()


def index_memory_entities(db_path: Path, memory_id: int, content: str, name: str = ""):
    """Extract entities from memory content and store relationships."""
    from datetime import datetime
    now = datetime.now().isoformat()
    full_text = f"{name} {content}"
    entities = extract_entities(full_text)

    if not entities:
        return []

    db = sqlite3.connect(str(db_path))

    stored = []
    for ent in entities:
        # Upsert entity
        existing = db.execute(
            "SELECT id FROM entities WHERE name = ? AND type = ?",
            (ent["name"], ent["type"])
        ).fetchone()

        if existing:
            entity_id = existing[0]
            db.execute(
                "UPDATE entities SET mention_count = mention_count + 1, last_seen = ? WHERE id = ?",
                (now, entity_id)
            )
        else:
            cursor = db.execute(
                "INSERT INTO entities (name, type, category, first_seen, last_seen) VALUES (?, ?, ?, ?, ?)",
                (ent["name"], ent["type"], ent["category"], now, now)
            )
            entity_id = cursor.lastrowid

        # Link to memory
        db.execute(
            "INSERT OR IGNORE INTO memory_entities (memory_id, entity_id) VALUES (?, ?)",
            (memory_id, entity_id)
        )
        stored.append({**ent, "id": entity_id})

    db.commit()
    db.close()
    return stored


def get_entity_graph(db_path: Path) -> dict:
    """Get entities and their connections to memories for graph visualization."""
    db = sqlite3.connect(str(db_path))
    db.row_factory = sqlite3.Row

    entities = db.execute(
        "SELECT id, name, type, category, mention_count FROM entities ORDER BY mention_count DESC LIMIT 100"
    ).fetchall()

    links = db.execute("""
        SELECT me1.entity_id, me1.memory_id as mem1, me2.memory_id as mem2
        FROM memory_entities me1
        JOIN memory_entities me2 ON me1.entity_id = me2.entity_id AND me1.memory_id < me2.memory_id
    """).fetchall()

    db.close()

    return {
        "entities": [dict(e) for e in entities],
        "entity_links": [{"entity_id": l["entity_id"], "memory_1": l["mem1"], "memory_2": l["mem2"]} for l in links],
    }
