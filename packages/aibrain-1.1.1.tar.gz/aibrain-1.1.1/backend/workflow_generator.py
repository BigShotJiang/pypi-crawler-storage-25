"""
AIBrain Workflow Generator — create workflows from natural language descriptions.
Parses user intent into a workflow script + cron schedule.
"""

import json
import logging
import os
import re
from datetime import datetime
from pathlib import Path

logger = logging.getLogger(__name__)

AIBRAIN_ROOT = Path(os.environ.get("AIBRAIN_ROOT", Path(__file__).parent.parent))
WORKFLOWS_DIR = AIBRAIN_ROOT / "workflows"
REGISTRY_PATH = WORKFLOWS_DIR / "registry.json"
CRON_JOBS_PATH = AIBRAIN_ROOT / "scheduled_jobs.json"

# Common schedule patterns mapped to cron expressions
SCHEDULE_PATTERNS = {
    r"every\s+morning|each\s+morning|daily\s+morning": "0 8 * * *",
    r"every\s+evening|each\s+evening|daily\s+evening|every\s+night": "0 20 * * *",
    r"every\s+day|daily|once\s+a\s+day": "0 9 * * *",
    r"every\s+hour|hourly": "7 * * * *",
    r"every\s+(\d+)\s+minutes?": "*/\\1 * * * *",
    r"every\s+(\d+)\s+hours?": "0 */\\1 * * *",
    r"every\s+week|weekly|once\s+a\s+week": "0 9 * * 1",
    r"every\s+monday": "0 9 * * 1",
    r"every\s+tuesday": "0 9 * * 2",
    r"every\s+wednesday": "0 9 * * 3",
    r"every\s+thursday": "0 9 * * 4",
    r"every\s+friday": "0 9 * * 5",
    r"weekdays|every\s+weekday|monday\s+to\s+friday": "0 9 * * 1-5",
    r"twice\s+a\s+day": "0 9,17 * * *",
    r"every\s+(\d+)\s+min": "*/\\1 * * * *",
}

# Action keyword patterns for workflow categorization
ACTION_KEYWORDS = {
    "email": ["email", "inbox", "mail", "message", "gmail", "outlook", "smtp", "imap"],
    "social_media": ["post", "tweet", "linkedin", "instagram", "social", "share", "publish"],
    "research": ["research", "search", "find", "look up", "google", "arxiv", "news", "article"],
    "finance": ["price", "stock", "crypto", "bitcoin", "portfolio", "expense", "budget", "trading"],
    "productivity": ["task", "todo", "plan", "organize", "clean", "declutter", "remind", "calendar"],
    "devops": ["deploy", "github", "git", "monitor", "uptime", "dependency", "build", "ci"],
    "health": ["exercise", "workout", "habit", "water", "sleep", "meditation", "health"],
    "comms": ["notify", "alert", "telegram", "slack", "discord", "webhook", "sms"],
}


def _parse_schedule(description: str) -> str:
    """Extract a cron schedule from natural language."""
    desc_lower = description.lower()

    for pattern, cron in SCHEDULE_PATTERNS.items():
        match = re.search(pattern, desc_lower)
        if match:
            # Handle capture groups (e.g., "every 5 minutes" → "*/5 * * * *")
            if match.groups():
                return cron.replace("\\1", match.group(1))
            return cron

    # Default: daily at 9am
    return "0 9 * * *"


def _categorize(description: str) -> str:
    """Determine workflow category from description."""
    desc_lower = description.lower()
    scores = {}
    for category, keywords in ACTION_KEYWORDS.items():
        score = sum(1 for kw in keywords if kw in desc_lower)
        if score > 0:
            scores[category] = score

    if scores:
        return max(scores, key=scores.get)
    return "productivity"


def _sanitize_name(description: str) -> str:
    """Generate a clean filename from description."""
    # Take first few meaningful words
    words = re.sub(r'[^a-z0-9\s]', '', description.lower()).split()
    # Remove common filler words
    stop = {"every", "the", "a", "an", "my", "me", "i", "and", "or", "to", "for", "in", "on", "at", "each", "all"}
    meaningful = [w for w in words if w not in stop][:4]
    name = "_".join(meaningful) if meaningful else "custom_workflow"
    return name


def _generate_script(name: str, description: str, category: str) -> str:
    """Generate a self-contained workflow Python script."""
    return f'''#!/usr/bin/env python3
"""AIBrain Workflow: {name} — {description}"""

import argparse
import json
import logging
import os
import sys
import urllib.request
from datetime import datetime
from pathlib import Path

_logger = logging.getLogger(__name__)

AIBRAIN_ROOT = Path(os.environ.get("AIBRAIN_ROOT", Path(__file__).parent.parent))
API_BASE = os.environ.get("AIBRAIN_API", "http://localhost:8001/api/agent")


def log_activity(action, detail="", status="ok"):
    """Log to AIBrain activity feed."""
    try:
        data = json.dumps({{
            "action": action,
            "category": "{category}",
            "detail": detail,
            "status": status,
        }}).encode()
        req = urllib.request.Request(
            f"{{API_BASE}}/activity",
            data=data,
            headers={{"Content-Type": "application/json"}},
        )
        urllib.request.urlopen(req, timeout=5)
    except Exception as e:
        _logger.warning("Failed to log activity: %s", e)


def request_approval(title, detail="", payload=None):
    """Submit to approval queue."""
    try:
        data = json.dumps({{
            "category": "{category}",
            "title": title,
            "detail": detail,
            "payload": payload or {{}},
        }}).encode()
        req = urllib.request.Request(
            f"{{API_BASE.replace('/api/agent', '')}}/api/agent/approvals",
            data=data,
            headers={{"Content-Type": "application/json"}},
        )
        resp = urllib.request.urlopen(req, timeout=5)
        return json.loads(resp.read())
    except Exception as e:
        print(f"Approval request failed: {{e}}")
        return None


def run(dry_run=False):
    """Main workflow logic.

    Description: {description}

    TODO: Customize this workflow to match your needs.
    The scaffold is ready — add your logic below.
    """
    print(f"[{{datetime.now().strftime('%H:%M:%S')}}] Running: {name}")

    # === YOUR WORKFLOW LOGIC HERE ===
    # Example: Fetch data, process it, take action
    result = f"Workflow '{name}' executed successfully"

    if dry_run:
        print(f"[dry-run] {{result}}")
        return

    # Log the run
    log_activity(f"workflow:{name}", result)
    print(result)


def main():
    parser = argparse.ArgumentParser(description="{description}")
    parser.add_argument("--dry-run", action="store_true", help="Preview without side effects")
    args = parser.parse_args()
    run(dry_run=args.dry_run)


if __name__ == "__main__":
    main()
'''


def generate_workflow(description: str) -> dict:
    """Generate a complete workflow from natural language description."""
    name = _sanitize_name(description)
    category = _categorize(description)
    cron = _parse_schedule(description)

    # Check for name collision
    script_path = WORKFLOWS_DIR / f"{name}.py"
    if script_path.exists():
        name = f"{name}_{int(datetime.now().timestamp()) % 10000}"
        script_path = WORKFLOWS_DIR / f"{name}.py"

    # Generate and write the script
    script_content = _generate_script(name, description, category)
    script_path.write_text(script_content, encoding="utf-8")

    # Add to registry
    if REGISTRY_PATH.exists():
        try:
            registry = json.loads(REGISTRY_PATH.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            registry = {"categories": {}, "workflows": []}
    else:
        registry = {"categories": {}, "workflows": []}

    workflow_entry = {
        "name": name,
        "display_name": description[:60],
        "description": description,
        "category": category,
        "cron_schedule": cron,
        "required_services": [],
        "enabled_by_default": True,
        "config_keys": [],
        "created": datetime.now().isoformat(),
        "source": "nl_generated",
    }
    registry["workflows"].append(workflow_entry)
    REGISTRY_PATH.write_text(json.dumps(registry, indent=2), encoding="utf-8")

    # Add to scheduled_jobs.json
    if CRON_JOBS_PATH.exists():
        try:
            jobs_data = json.loads(CRON_JOBS_PATH.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            jobs_data = {"jobs": []}
    else:
        jobs_data = {"jobs": []}

    jobs_data["jobs"].append({
        "name": name,
        "cron": cron,
        "prompt": f"Run custom workflow: python workflows/{name}.py",
        "enabled": True,
        "group": category,
        "notes": description,
    })
    jobs_data["_updated"] = datetime.now().strftime("%Y-%m-%d")
    CRON_JOBS_PATH.write_text(json.dumps(jobs_data, indent=2), encoding="utf-8")

    return {
        "status": "created",
        "name": name,
        "category": category,
        "cron": cron,
        "script_path": str(script_path),
        "description": description,
        "message": f"Workflow '{name}' created. Schedule: {cron}. Edit the script at workflows/{name}.py to add your logic.",
    }
