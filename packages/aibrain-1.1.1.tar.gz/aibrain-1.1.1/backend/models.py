"""
AIBrain API Models — Pydantic v2 request/response validation.
Replaces raw request.json() with typed, validated inputs.
"""

from pydantic import BaseModel, Field, field_validator
from typing import Optional


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------

class AuthModeRequest(BaseModel):
    mode: str = Field(..., pattern=r'^(none|api_key|jwt)$')

class TokenRequest(BaseModel):
    subject: str = Field(..., min_length=1, max_length=200)
    ttl: int = Field(default=86400, ge=60, le=2592000)

class TokenVerifyRequest(BaseModel):
    token: str = Field(..., min_length=10)

class KeyRevokeRequest(BaseModel):
    hash_prefix: str = Field(..., min_length=8, max_length=64)


# ---------------------------------------------------------------------------
# Memories
# ---------------------------------------------------------------------------

class MemoryCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=500)
    content: str = Field(..., min_length=1, max_length=100000)
    type: str = Field(default='reference', pattern=r'^(user|feedback|project|reference|pattern|decision)$')
    tags: str = Field(default='', max_length=2000)
    source: str = Field(default='api', max_length=200)

class MemoryUpdate(BaseModel):
    name: Optional[str] = Field(default=None, min_length=1, max_length=500)
    content: Optional[str] = Field(default=None, min_length=1, max_length=100000)
    type: Optional[str] = Field(default=None, pattern=r'^(user|feedback|project|reference|pattern|decision)$')
    tags: Optional[str] = Field(default=None, max_length=2000)


# ---------------------------------------------------------------------------
# Approvals
# ---------------------------------------------------------------------------

class ApprovalDecision(BaseModel):
    decision: str = Field(..., pattern=r'^(approved|rejected)$')
    reason: str = Field(default='', max_length=2000)

class ApprovalCreate(BaseModel):
    category: str = Field(..., min_length=1, max_length=100)
    title: str = Field(..., min_length=1, max_length=500)
    description: str = Field(default='', max_length=10000)
    payload: dict = Field(default_factory=dict)
    priority: str = Field(default='normal', pattern=r'^(low|normal|high|urgent)$')


# ---------------------------------------------------------------------------
# Critic-Generator
# ---------------------------------------------------------------------------

class CriticRunRequest(BaseModel):
    task: str = Field(..., min_length=1, max_length=10000)
    context: str = Field(default='', max_length=50000)
    config: dict = Field(default_factory=dict)

class EmailRefineRequest(BaseModel):
    subject: str = Field(..., min_length=1, max_length=500)
    body: str = Field(..., min_length=1, max_length=50000)
    tone: str = Field(default='professional', max_length=50)

class ReportRefineRequest(BaseModel):
    title: str = Field(..., min_length=1, max_length=500)
    content: str = Field(..., min_length=1, max_length=50000)
    audience: str = Field(default='technical', max_length=50)

class CodeRefineRequest(BaseModel):
    task: str = Field(..., min_length=1, max_length=5000)
    code: str = Field(..., min_length=1, max_length=100000)
    language: str = Field(default='python', max_length=30)


# ---------------------------------------------------------------------------
# Cron Jobs
# ---------------------------------------------------------------------------

class CronUpdate(BaseModel):
    enabled: Optional[bool] = None
    cron: Optional[str] = Field(default=None, max_length=100)
    description: Optional[str] = Field(default=None, max_length=500)

    @field_validator('cron')
    @classmethod
    def validate_cron(cls, v):
        if v is not None:
            parts = v.strip().split()
            if len(parts) not in (5, 6):
                raise ValueError('cron must have 5 or 6 fields (minute hour day month weekday [year])')
        return v


# ---------------------------------------------------------------------------
# Chat
# ---------------------------------------------------------------------------

class ChatMessage(BaseModel):
    message: str = Field(..., min_length=1, max_length=50000)
    history: list = Field(default_factory=list)
