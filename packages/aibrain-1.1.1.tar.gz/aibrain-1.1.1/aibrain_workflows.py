#!/usr/bin/env python3
"""
aibrain_workflows.py — 40 Production Workflow Templates

Drop-in workflow bundle for aibrain. Each workflow is a complete Python class
with __init__, run(), and schedule property. All workflows:
- Use only stdlib + requests + python-dateutil (already in pyproject.toml)
- Handle their own errors gracefully
- Log results to aibrain memory via store/search
- Work on first run with sensible defaults
- Are config-driven via aibrain config system

Usage:
    from aibrain_workflows import WORKFLOW_REGISTRY
    for name, cls in WORKFLOW_REGISTRY.items():
        wf = cls(db, config)
        if wf.should_run():
            result = wf.run()

Seed all workflows on `aibrain init`:
    from aibrain_workflows import seed_workflows
    seed_workflows(db)
"""

import hashlib
import json
import logging
import os
import re
import sqlite3
import time
import urllib.request
import urllib.error
import urllib.parse
from abc import ABC, abstractmethod
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, List, Optional, Any

log = logging.getLogger("aibrain.workflows")


# ---------------------------------------------------------------------------
# Base class
# ---------------------------------------------------------------------------

class Workflow(ABC):
    """Base class for all aibrain workflows."""

    name: str = "base_workflow"
    display_name: str = "Base Workflow"
    description: str = ""
    category: str = "general"
    schedule_cron: str = "0 9 * * *"  # daily at 9am
    config_keys: List[str] = []
    requires: List[str] = []  # optional deps like "aibrain[api]"

    def __init__(self, db_path: str, config: Dict = None):
        self.db_path = db_path
        self.config = config or {}
        self._conn = None

    def _db(self):
        if self._conn is None:
            self._conn = sqlite3.connect(self.db_path, check_same_thread=False)
            self._conn.row_factory = sqlite3.Row
        return self._conn

    def store_memory(self, name: str, content: str, mem_type: str = "reference",
                     tags: str = "", importance: float = 0.5):
        """Store a result in aibrain memory."""
        db = self._db()
        try:
            existing = db.execute(
                "SELECT id FROM memories WHERE name=? AND active=1", (name,)
            ).fetchone()
            if existing:
                db.execute(
                    "UPDATE memories SET content=?, tags=?, importance=?, updated=datetime('now') WHERE id=?",
                    (content, tags, importance, existing[0])
                )
            else:
                db.execute(
                    "INSERT INTO memories (name, type, tags, content, importance, created, updated, active) "
                    "VALUES (?, ?, ?, ?, ?, datetime('now'), datetime('now'), 1)",
                    (name, mem_type, tags, content, importance)
                )
            db.commit()
        except Exception as e:
            log.error("[%s] Failed to store memory: %s", self.name, e)

    def get_config(self, key: str, default=None):
        """Get a config value."""
        return self.config.get(key, default)

    def http_get(self, url: str, timeout: int = 15) -> Optional[str]:
        """Simple HTTP GET with error handling."""
        try:
            req = urllib.request.Request(url, headers={
                "User-Agent": "aibrain/0.9 (+https://aibrain.dev)"
            })
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return resp.read().decode("utf-8", errors="replace")
        except Exception as e:
            log.warning("[%s] HTTP GET failed for %s: %s", self.name, url, e)
            return None

    @abstractmethod
    def run(self) -> Dict:
        """Execute the workflow. Returns results dict."""
        pass

    @property
    def schedule(self) -> str:
        return self.schedule_cron

    def should_run(self) -> bool:
        """Check if this workflow should run (enabled in config)."""
        return self.config.get(f"workflow_{self.name}_enabled", True)


# =========================================================================
# CATEGORY 1: PERSONAL PRODUCTIVITY (10)
# =========================================================================

class DailyPlanner(Workflow):
    """Generate a daily plan from calendar, tasks, and priorities.

    Config keys:
        planner_priorities: comma-separated priority items
        planner_timezone: timezone name (default: local)
    """
    name = "daily_planner"
    display_name = "Daily Planner"
    description = "Generate a structured daily plan with priorities and time blocks"
    category = "productivity"
    schedule_cron = "0 6 * * *"  # 6am daily

    def run(self) -> Dict:
        now = datetime.now()
        day_name = now.strftime("%A, %B %d, %Y")
        priorities = self.get_config("planner_priorities", "").split(",")
        priorities = [p.strip() for p in priorities if p.strip()]

        # Pull recent project memories for context
        db = self._db()
        recent_projects = []
        try:
            rows = db.execute(
                "SELECT name, content FROM memories WHERE type='project' AND active=1 "
                "ORDER BY updated DESC LIMIT 5"
            ).fetchall()
            recent_projects = [{"name": r["name"], "preview": r["content"][:100]} for r in rows]
        except Exception:
            pass

        # Pull pending decisions/approvals
        pending = []
        try:
            rows = db.execute(
                "SELECT title FROM approvals WHERE status='pending' LIMIT 5"
            ).fetchall()
            pending = [r["title"] for r in rows]
        except Exception:
            pass

        plan = f"# Daily Plan — {day_name}\n\n"
        plan += "## Top Priorities\n"
        if priorities:
            for i, p in enumerate(priorities, 1):
                plan += f"{i}. {p}\n"
        else:
            plan += "- No priorities set. Use: aibrain config set planner_priorities 'item1,item2'\n"

        if recent_projects:
            plan += "\n## Active Projects\n"
            for proj in recent_projects:
                plan += f"- **{proj['name']}**: {proj['preview']}\n"

        if pending:
            plan += "\n## Pending Decisions\n"
            for p in pending:
                plan += f"- ⏳ {p}\n"

        plan += f"\n## Time Blocks\n"
        plan += "- 06:00-08:00 — Deep work (highest priority task)\n"
        plan += "- 08:00-09:00 — Communications (email, messages)\n"
        plan += "- 09:00-12:00 — Project work\n"
        plan += "- 12:00-13:00 — Break\n"
        plan += "- 13:00-15:00 — Meetings / collaboration\n"
        plan += "- 15:00-17:00 — Secondary tasks\n"
        plan += "- 17:00-17:30 — Review & plan tomorrow\n"

        self.store_memory(
            f"daily_plan_{now.strftime('%Y%m%d')}",
            plan, "project", "daily_plan,productivity,auto", 0.6
        )

        return {"status": "ok", "date": day_name, "priorities": len(priorities),
                "projects": len(recent_projects), "pending": len(pending)}


class HabitTracker(Workflow):
    """Track daily habits and streaks.

    Config keys:
        habits: comma-separated habit names
        habit_log_method: 'memory' (default) or 'config'
    """
    name = "habit_tracker"
    display_name = "Habit Tracker"
    description = "Track daily habits, calculate streaks, and identify patterns"
    category = "productivity"
    schedule_cron = "0 21 * * *"  # 9pm daily review

    def run(self) -> Dict:
        habits = self.get_config("habits", "exercise,reading,coding,meditation").split(",")
        habits = [h.strip() for h in habits if h.strip()]
        today = datetime.now().strftime("%Y-%m-%d")

        db = self._db()
        report = f"# Habit Check — {today}\n\n"

        streaks = {}
        for habit in habits:
            # Count recent streak from memory
            try:
                rows = db.execute(
                    "SELECT content FROM memories WHERE name LIKE ? AND active=1 "
                    "ORDER BY created DESC LIMIT 30",
                    (f"habit_{habit}_%",)
                ).fetchall()
                streak = 0
                for r in rows:
                    if "completed" in r["content"].lower():
                        streak += 1
                    else:
                        break
                streaks[habit] = streak
            except Exception:
                streaks[habit] = 0

            status = "🔥" if streaks[habit] >= 7 else "✅" if streaks[habit] >= 3 else "⬜"
            report += f"- {status} **{habit}**: {streaks[habit]} day streak\n"

        # Store today's check-in (mark as pending — user confirms via memory update)
        for habit in habits:
            self.store_memory(
                f"habit_{habit}_{today}",
                f"Habit: {habit} | Date: {today} | Status: pending",
                "project", f"habit,{habit},tracking", 0.3
            )

        report += f"\n*Mark habits complete: update the habit memory with 'completed'*"

        self.store_memory(
            f"habit_report_{today}", report,
            "reference", "habit_report,productivity,auto", 0.5
        )

        return {"status": "ok", "habits": len(habits), "streaks": streaks}


class ExpenseTracker(Workflow):
    """Track and categorize expenses from memory entries.

    Config keys:
        expense_currency: currency symbol (default: $)
        expense_budget_monthly: monthly budget amount
        expense_categories: comma-separated categories
    """
    name = "expense_tracker"
    display_name = "Expense Tracker"
    description = "Track expenses, categorize spending, and monitor budget"
    category = "productivity"
    schedule_cron = "0 20 * * 0"  # Sunday 8pm weekly

    def run(self) -> Dict:
        currency = self.get_config("expense_currency", "$")
        budget = float(self.get_config("expense_budget_monthly", "0"))
        now = datetime.now()
        month_start = now.replace(day=1).strftime("%Y-%m-%d")

        db = self._db()
        expenses = []
        try:
            rows = db.execute(
                "SELECT name, content, created FROM memories "
                "WHERE type='reference' AND tags LIKE '%expense%' AND active=1 "
                "AND created >= ? ORDER BY created DESC",
                (month_start,)
            ).fetchall()
            for r in rows:
                # Parse amount from content (look for currency patterns)
                amount_match = re.search(r'[\$€£]\s*([\d,]+\.?\d*)', r["content"])
                if amount_match:
                    amount = float(amount_match.group(1).replace(",", ""))
                    expenses.append({
                        "name": r["name"],
                        "amount": amount,
                        "date": r["created"][:10],
                    })
        except Exception:
            pass

        total = sum(e["amount"] for e in expenses)
        report = f"# Expense Report — {now.strftime('%B %Y')}\n\n"
        report += f"**Total spent:** {currency}{total:,.2f}\n"
        if budget > 0:
            remaining = budget - total
            pct = (total / budget) * 100
            report += f"**Budget:** {currency}{budget:,.2f} | **Remaining:** {currency}{remaining:,.2f} ({pct:.0f}% used)\n"

        if expenses:
            report += f"\n## Recent Expenses ({len(expenses)})\n"
            for e in expenses[:20]:
                report += f"- {e['date']}: {currency}{e['amount']:,.2f} — {e['name']}\n"
        else:
            report += "\nNo expenses tracked this month. Store expenses with tag 'expense'.\n"

        self.store_memory(
            f"expense_report_{now.strftime('%Y%m')}",
            report, "reference", "expense,report,finance,auto", 0.6
        )

        return {"status": "ok", "expenses": len(expenses), "total": total}


class BookmarkOrganizer(Workflow):
    """Organize and categorize stored bookmarks/links.

    Config keys: (none required)
    Reads memories tagged with 'bookmark' or 'link'.
    """
    name = "bookmark_organizer"
    display_name = "Bookmark Organizer"
    description = "Organize stored bookmarks by category and check for duplicates"
    category = "productivity"
    schedule_cron = "0 10 * * 6"  # Saturday 10am

    def run(self) -> Dict:
        db = self._db()
        bookmarks = []
        try:
            rows = db.execute(
                "SELECT id, name, content, tags FROM memories "
                "WHERE (tags LIKE '%bookmark%' OR tags LIKE '%link%') AND active=1 "
                "ORDER BY created DESC"
            ).fetchall()
            bookmarks = [dict(r) for r in rows]
        except Exception:
            pass

        if not bookmarks:
            return {"status": "ok", "bookmarks": 0, "message": "No bookmarks found"}

        # Extract URLs and categorize
        categories = defaultdict(list)
        url_pattern = re.compile(r'https?://[^\s<>"]+')
        seen_urls = set()
        duplicates = 0

        for bm in bookmarks:
            urls = url_pattern.findall(bm.get("content", ""))
            for url in urls:
                domain = urllib.parse.urlparse(url).netloc
                if url in seen_urls:
                    duplicates += 1
                    continue
                seen_urls.add(url)

                # Auto-categorize by domain
                if "github.com" in domain:
                    cat = "Development"
                elif any(x in domain for x in ("arxiv", "scholar", "papers")):
                    cat = "Research"
                elif any(x in domain for x in ("youtube", "video")):
                    cat = "Video"
                elif any(x in domain for x in ("news", "bbc", "cnn", "reuters")):
                    cat = "News"
                else:
                    cat = "General"

                categories[cat].append({"url": url, "name": bm.get("name", ""), "domain": domain})

        report = f"# Bookmark Library — {len(seen_urls)} links, {duplicates} duplicates\n\n"
        for cat, links in sorted(categories.items()):
            report += f"## {cat} ({len(links)})\n"
            for link in links[:20]:
                report += f"- [{link['domain']}]({link['url']}) — {link['name'][:50]}\n"
            report += "\n"

        self.store_memory(
            "bookmark_index", report,
            "reference", "bookmarks,index,organized,auto", 0.5
        )

        return {"status": "ok", "bookmarks": len(seen_urls), "categories": len(categories),
                "duplicates": duplicates}


class FileDeclutter(Workflow):
    """Scan directories for large, old, or duplicate files.

    Config keys:
        declutter_paths: comma-separated paths to scan
        declutter_days_old: files older than this (default: 90)
        declutter_min_size_mb: minimum size to flag (default: 50)
    """
    name = "file_declutter"
    display_name = "File Declutter"
    description = "Find large, old, or duplicate files that could be cleaned up"
    category = "productivity"
    schedule_cron = "0 11 * * 0"  # Sunday 11am

    def run(self) -> Dict:
        scan_paths = self.get_config("declutter_paths", str(Path.home() / "Downloads")).split(",")
        days_old = int(self.get_config("declutter_days_old", "90"))
        min_size_mb = float(self.get_config("declutter_min_size_mb", "50"))
        cutoff = time.time() - (days_old * 86400)
        min_size = min_size_mb * 1024 * 1024

        large_files = []
        old_files = []
        total_reclaimable = 0

        for scan_path in scan_paths:
            scan_path = scan_path.strip()
            p = Path(scan_path)
            if not p.exists():
                continue
            try:
                for f in p.rglob("*"):
                    if not f.is_file():
                        continue
                    try:
                        stat = f.stat()
                        if stat.st_size >= min_size:
                            large_files.append({
                                "path": str(f),
                                "size_mb": round(stat.st_size / (1024*1024), 1),
                                "modified": datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d"),
                            })
                            total_reclaimable += stat.st_size
                        if stat.st_mtime < cutoff:
                            old_files.append({
                                "path": str(f),
                                "size_mb": round(stat.st_size / (1024*1024), 1),
                                "modified": datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d"),
                            })
                    except (PermissionError, OSError):
                        continue
            except (PermissionError, OSError):
                continue

        large_files.sort(key=lambda x: x["size_mb"], reverse=True)
        report = f"# Declutter Report — {datetime.now().strftime('%Y-%m-%d')}\n\n"
        report += f"**Scanned:** {', '.join(scan_paths)}\n"
        report += f"**Reclaimable:** {total_reclaimable / (1024*1024*1024):.1f} GB\n\n"

        if large_files:
            report += f"## Large Files (>{min_size_mb}MB) — {len(large_files)} found\n"
            for f in large_files[:20]:
                report += f"- {f['size_mb']}MB — {f['path']} (modified: {f['modified']})\n"

        if old_files:
            report += f"\n## Old Files (>{days_old} days) — {len(old_files)} found\n"
            for f in old_files[:20]:
                report += f"- {f['modified']} — {f['path']} ({f['size_mb']}MB)\n"

        self.store_memory(
            f"declutter_{datetime.now().strftime('%Y%m%d')}",
            report, "reference", "declutter,files,cleanup,auto", 0.4
        )

        return {"status": "ok", "large_files": len(large_files),
                "old_files": len(old_files),
                "reclaimable_gb": round(total_reclaimable / (1024**3), 1)}


class ReadingListManager(Workflow):
    """Manage a reading list — track what to read, what's in progress, what's done.

    Config keys: (none — reads from memories tagged 'reading')
    """
    name = "reading_list"
    display_name = "Reading List Manager"
    description = "Organize and track your reading list with status updates"
    category = "productivity"
    schedule_cron = "0 8 * * 1"  # Monday 8am

    def run(self) -> Dict:
        db = self._db()
        items = []
        try:
            rows = db.execute(
                "SELECT name, content, tags FROM memories "
                "WHERE tags LIKE '%reading%' AND active=1 ORDER BY updated DESC"
            ).fetchall()
            items = [dict(r) for r in rows]
        except Exception:
            pass

        to_read = [i for i in items if "to_read" in i.get("tags", "")]
        in_progress = [i for i in items if "in_progress" in i.get("tags", "")]
        completed = [i for i in items if "completed" in i.get("tags", "")]

        report = f"# Reading List — {datetime.now().strftime('%Y-%m-%d')}\n\n"
        report += f"📚 To Read: {len(to_read)} | 📖 In Progress: {len(in_progress)} | ✅ Completed: {len(completed)}\n\n"

        if in_progress:
            report += "## Currently Reading\n"
            for item in in_progress:
                report += f"- {item['name']}: {item['content'][:80]}\n"

        if to_read:
            report += "\n## To Read\n"
            for item in to_read[:10]:
                report += f"- {item['name']}\n"

        if completed:
            report += f"\n## Recently Completed ({len(completed)})\n"
            for item in completed[:5]:
                report += f"- ✅ {item['name']}\n"

        self.store_memory(
            "reading_list_current", report,
            "reference", "reading,list,auto", 0.4
        )
        return {"status": "ok", "to_read": len(to_read),
                "in_progress": len(in_progress), "completed": len(completed)}


class NoteTaker(Workflow):
    """Consolidate recent notes and create a searchable index.

    Reads memories tagged 'note' and builds a structured index.
    """
    name = "note_taker"
    display_name = "Note Consolidator"
    description = "Index and consolidate scattered notes into organized collections"
    category = "productivity"
    schedule_cron = "0 18 * * 5"  # Friday 6pm

    def run(self) -> Dict:
        db = self._db()
        notes = []
        try:
            rows = db.execute(
                "SELECT name, content, tags, created FROM memories "
                "WHERE (tags LIKE '%note%' OR type='reference') AND active=1 "
                "AND created >= datetime('now', '-7 days') "
                "ORDER BY created DESC LIMIT 50"
            ).fetchall()
            notes = [dict(r) for r in rows]
        except Exception:
            pass

        if not notes:
            return {"status": "ok", "notes": 0}

        # Group by tag
        by_tag = defaultdict(list)
        for n in notes:
            tags = [t.strip() for t in n.get("tags", "").split(",") if t.strip() and t.strip() != "note"]
            if tags:
                for tag in tags[:3]:
                    by_tag[tag].append(n)
            else:
                by_tag["uncategorized"].append(n)

        report = f"# Weekly Notes Index — {datetime.now().strftime('%Y-%m-%d')}\n"
        report += f"**{len(notes)} notes this week**\n\n"

        for tag, tag_notes in sorted(by_tag.items()):
            report += f"## {tag.title()} ({len(tag_notes)})\n"
            for n in tag_notes[:10]:
                preview = n["content"][:100].replace("\n", " ")
                report += f"- **{n['name']}** ({n['created'][:10]}): {preview}\n"
            report += "\n"

        self.store_memory(
            f"notes_index_{datetime.now().strftime('%Y_W%W')}",
            report, "reference", "notes,index,weekly,auto", 0.5
        )
        return {"status": "ok", "notes": len(notes), "categories": len(by_tag)}


class TimeTracker(Workflow):
    """Analyze time spent based on activity logs and session data.

    Reads from activity table and session narratives.
    """
    name = "time_tracker"
    display_name = "Time Tracker"
    description = "Analyze time distribution across activities and projects"
    category = "productivity"
    schedule_cron = "0 17 * * 5"  # Friday 5pm

    def run(self) -> Dict:
        db = self._db()
        activities = []
        try:
            rows = db.execute(
                "SELECT category, action, COUNT(*) as count, "
                "MIN(timestamp) as first_at, MAX(timestamp) as last_at "
                "FROM activity WHERE timestamp >= datetime('now', '-7 days') "
                "GROUP BY category, action ORDER BY count DESC LIMIT 30"
            ).fetchall()
            activities = [dict(r) for r in rows]
        except Exception:
            pass

        report = f"# Time Report — Week of {datetime.now().strftime('%Y-%m-%d')}\n\n"
        if activities:
            report += "## Activity Breakdown\n"
            total = sum(a["count"] for a in activities)
            for a in activities:
                pct = (a["count"] / total) * 100
                report += f"- **{a['category']}/{a['action']}**: {a['count']} events ({pct:.0f}%)\n"
        else:
            report += "No activity data this week.\n"

        self.store_memory(
            f"time_report_{datetime.now().strftime('%Y_W%W')}",
            report, "reference", "time,report,weekly,auto", 0.4
        )
        return {"status": "ok", "activities": len(activities)}


class GoalTracker(Workflow):
    """Track progress toward defined goals.

    Config keys:
        goals: JSON array of {name, target, metric, deadline}
    """
    name = "goal_tracker"
    display_name = "Goal Tracker"
    description = "Track and report progress on defined goals"
    category = "productivity"
    schedule_cron = "0 9 * * 1"  # Monday 9am

    def run(self) -> Dict:
        goals_json = self.get_config("goals", "[]")
        try:
            goals = json.loads(goals_json) if isinstance(goals_json, str) else goals_json
        except json.JSONDecodeError:
            goals = []

        report = f"# Goal Progress — {datetime.now().strftime('%Y-%m-%d')}\n\n"

        if not goals:
            report += "No goals defined. Set goals:\n"
            report += '`aibrain config set goals \'[{"name":"Launch product","target":"PyPI release","deadline":"2026-04-25"}]\'`\n'
        else:
            for g in goals:
                name = g.get("name", "Unnamed")
                target = g.get("target", "")
                deadline = g.get("deadline", "")
                report += f"## {name}\n"
                report += f"- Target: {target}\n"
                if deadline:
                    try:
                        dl = datetime.strptime(deadline, "%Y-%m-%d")
                        days_left = (dl - datetime.now()).days
                        report += f"- Deadline: {deadline} ({days_left} days remaining)\n"
                    except ValueError:
                        report += f"- Deadline: {deadline}\n"
                report += "\n"

        self.store_memory(
            f"goals_{datetime.now().strftime('%Y%m%d')}",
            report, "project", "goals,tracking,auto", 0.6
        )
        return {"status": "ok", "goals": len(goals)}


class WeeklyReview(Workflow):
    """Generate a comprehensive weekly review from all brain data.

    Combines: activity, memories created, skills learned, goals progress.
    """
    name = "weekly_review"
    display_name = "Weekly Review Generator"
    description = "Comprehensive weekly review of activity, progress, and learnings"
    category = "productivity"
    schedule_cron = "0 18 * * 0"  # Sunday 6pm

    def run(self) -> Dict:
        db = self._db()
        now = datetime.now()
        week_ago = (now - timedelta(days=7)).strftime("%Y-%m-%d")

        # Memories created this week
        new_memories = 0
        try:
            row = db.execute(
                "SELECT COUNT(*) as c FROM memories WHERE created >= ? AND active=1",
                (week_ago,)
            ).fetchone()
            new_memories = row["c"] if row else 0
        except Exception:
            pass

        # Activities this week
        activity_count = 0
        try:
            row = db.execute(
                "SELECT COUNT(*) as c FROM activity WHERE timestamp >= ?",
                (week_ago,)
            ).fetchone()
            activity_count = row["c"] if row else 0
        except Exception:
            pass

        # Skill episodes this week
        skill_episodes = 0
        try:
            row = db.execute(
                "SELECT COUNT(*) as c FROM skill_episodes WHERE created_at >= ?",
                (week_ago,)
            ).fetchone()
            skill_episodes = row["c"] if row else 0
        except Exception:
            pass

        report = f"# Weekly Review — {now.strftime('%B %d, %Y')}\n\n"
        report += f"## This Week's Numbers\n"
        report += f"- 🧠 Memories created: {new_memories}\n"
        report += f"- ⚡ Activities logged: {activity_count}\n"
        report += f"- 🎯 Skill episodes: {skill_episodes}\n"
        report += f"\n## Reflection Prompts\n"
        report += "- What went well this week?\n"
        report += "- What didn't go as planned?\n"
        report += "- What's the one thing to focus on next week?\n"
        report += "- What did I learn that changes how I'll approach things?\n"

        self.store_memory(
            f"weekly_review_{now.strftime('%Y_W%W')}",
            report, "reference", "review,weekly,reflection,auto", 0.7
        )

        return {"status": "ok", "new_memories": new_memories,
                "activities": activity_count, "skill_episodes": skill_episodes}


# =========================================================================
# CATEGORY 2: INFORMATION & RESEARCH (10)
# =========================================================================

class RSSDigest(Workflow):
    """Fetch and summarize RSS feeds.

    Config keys:
        rss_feeds: comma-separated feed URLs
        rss_max_items: max items per feed (default: 5)
    """
    name = "rss_digest"
    display_name = "RSS Digest"
    description = "Fetch and summarize subscribed RSS feeds"
    category = "research"
    schedule_cron = "0 7 * * *"  # daily 7am

    def run(self) -> Dict:
        feeds = self.get_config("rss_feeds", "").split(",")
        feeds = [f.strip() for f in feeds if f.strip()]
        max_items = int(self.get_config("rss_max_items", "5"))

        if not feeds:
            return {"status": "ok", "message": "No RSS feeds configured. Use: aibrain config set rss_feeds 'url1,url2'"}

        all_items = []
        for feed_url in feeds:
            xml = self.http_get(feed_url)
            if not xml:
                continue
            # Simple RSS/Atom parsing without feedparser
            items = self._parse_feed(xml, max_items)
            all_items.extend(items)

        report = f"# RSS Digest — {datetime.now().strftime('%Y-%m-%d')}\n\n"
        report += f"**{len(all_items)} items from {len(feeds)} feeds**\n\n"

        for item in all_items:
            report += f"- **{item.get('title', 'Untitled')}**\n"
            if item.get("link"):
                report += f"  {item['link']}\n"
            if item.get("description"):
                desc = re.sub(r'<[^>]+>', '', item['description'])[:150]
                report += f"  {desc}\n"
            report += "\n"

        self.store_memory(
            f"rss_digest_{datetime.now().strftime('%Y%m%d')}",
            report, "reference", "rss,digest,news,auto", 0.5
        )

        return {"status": "ok", "items": len(all_items), "feeds": len(feeds)}

    def _parse_feed(self, xml: str, max_items: int) -> List[Dict]:
        """Basic RSS/Atom XML parser using regex (no external deps)."""
        items = []
        # Try RSS <item> format
        item_blocks = re.findall(r'<item>(.*?)</item>', xml, re.DOTALL)
        if not item_blocks:
            # Try Atom <entry> format
            item_blocks = re.findall(r'<entry>(.*?)</entry>', xml, re.DOTALL)

        for block in item_blocks[:max_items]:
            title = re.search(r'<title[^>]*>(.*?)</title>', block, re.DOTALL)
            link = re.search(r'<link[^>]*href=["\']([^"\']+)', block) or \
                   re.search(r'<link[^>]*>(.*?)</link>', block, re.DOTALL)
            desc = re.search(r'<description[^>]*>(.*?)</description>', block, re.DOTALL) or \
                   re.search(r'<summary[^>]*>(.*?)</summary>', block, re.DOTALL)

            items.append({
                "title": re.sub(r'<!\[CDATA\[(.*?)\]\]>', r'\1', title.group(1)).strip() if title else "Untitled",
                "link": (link.group(1) if link else "").strip(),
                "description": re.sub(r'<!\[CDATA\[(.*?)\]\]>', r'\1', desc.group(1)).strip() if desc else "",
            })
        return items


class ArxivTracker(Workflow):
    """Track new papers on arXiv by keyword.

    Config keys:
        arxiv_keywords: comma-separated search terms
        arxiv_categories: comma-separated arXiv categories (e.g., cs.AI,cs.CL)
        arxiv_max_results: max papers per query (default: 5)
    """
    name = "arxiv_tracker"
    display_name = "arXiv Paper Tracker"
    description = "Monitor arXiv for new papers matching your research interests"
    category = "research"
    schedule_cron = "0 8 * * 1,3,5"  # Mon/Wed/Fri 8am

    def run(self) -> Dict:
        keywords = self.get_config("arxiv_keywords", "AI agent memory,retrieval augmented generation").split(",")
        keywords = [k.strip() for k in keywords if k.strip()]
        max_results = int(self.get_config("arxiv_max_results", "5"))

        all_papers = []
        for kw in keywords:
            query = urllib.parse.quote(kw)
            url = f"http://export.arxiv.org/api/query?search_query=all:{query}&start=0&max_results={max_results}&sortBy=submittedDate&sortOrder=descending"
            xml = self.http_get(url, timeout=20)
            if not xml:
                continue

            entries = re.findall(r'<entry>(.*?)</entry>', xml, re.DOTALL)
            for entry in entries:
                title = re.search(r'<title>(.*?)</title>', entry, re.DOTALL)
                summary = re.search(r'<summary>(.*?)</summary>', entry, re.DOTALL)
                link = re.search(r'<id>(.*?)</id>', entry)
                published = re.search(r'<published>(.*?)</published>', entry)

                if title:
                    all_papers.append({
                        "title": title.group(1).strip().replace("\n", " "),
                        "summary": summary.group(1).strip()[:200] if summary else "",
                        "link": link.group(1).strip() if link else "",
                        "published": published.group(1)[:10] if published else "",
                        "keyword": kw,
                    })

        report = f"# arXiv Papers — {datetime.now().strftime('%Y-%m-%d')}\n\n"
        report += f"**{len(all_papers)} papers across {len(keywords)} keywords**\n\n"

        for paper in all_papers:
            report += f"### {paper['title']}\n"
            report += f"*{paper['published']}* | Keyword: {paper['keyword']}\n"
            report += f"{paper['summary']}\n"
            report += f"[Link]({paper['link']})\n\n"

        self.store_memory(
            f"arxiv_{datetime.now().strftime('%Y%m%d')}",
            report, "reference", "arxiv,research,papers,auto", 0.6
        )

        return {"status": "ok", "papers": len(all_papers), "keywords": len(keywords)}


class HNRedditMonitor(Workflow):
    """Monitor Hacker News and Reddit for relevant discussions.

    Config keys:
        hn_keywords: keywords to search HN for
        reddit_subreddits: subreddits to monitor (e.g., netsec,LocalLLaMA)
    """
    name = "hn_reddit_monitor"
    display_name = "HN/Reddit Monitor"
    description = "Track relevant discussions on Hacker News and Reddit"
    category = "research"
    schedule_cron = "0 12 * * *"  # daily noon

    def run(self) -> Dict:
        hn_keywords = self.get_config("hn_keywords", "AI agent,MCP,memory system").split(",")
        hn_keywords = [k.strip() for k in hn_keywords if k.strip()]

        items = []
        # HN Search API (Algolia)
        for kw in hn_keywords[:5]:
            query = urllib.parse.quote(kw)
            url = f"https://hn.algolia.com/api/v1/search_by_date?query={query}&tags=story&hitsPerPage=3"
            raw = self.http_get(url)
            if raw:
                try:
                    data = json.loads(raw)
                    for hit in data.get("hits", []):
                        items.append({
                            "source": "HN",
                            "title": hit.get("title", ""),
                            "url": hit.get("url", f"https://news.ycombinator.com/item?id={hit.get('objectID', '')}"),
                            "points": hit.get("points", 0),
                            "comments": hit.get("num_comments", 0),
                            "keyword": kw,
                        })
                except json.JSONDecodeError:
                    pass

        # Reddit (public JSON API, no auth needed)
        subreddits = self.get_config("reddit_subreddits", "LocalLLaMA,netsec,selfhosted").split(",")
        for sub in [s.strip() for s in subreddits if s.strip()][:5]:
            url = f"https://www.reddit.com/r/{sub}/new.json?limit=5"
            raw = self.http_get(url)
            if raw:
                try:
                    data = json.loads(raw)
                    for post in data.get("data", {}).get("children", []):
                        d = post.get("data", {})
                        items.append({
                            "source": f"r/{sub}",
                            "title": d.get("title", ""),
                            "url": f"https://reddit.com{d.get('permalink', '')}",
                            "points": d.get("score", 0),
                            "comments": d.get("num_comments", 0),
                            "keyword": sub,
                        })
                except json.JSONDecodeError:
                    pass

        # Sort by engagement
        items.sort(key=lambda x: x.get("points", 0) + x.get("comments", 0), reverse=True)

        report = f"# Discussion Monitor — {datetime.now().strftime('%Y-%m-%d')}\n\n"
        for item in items[:20]:
            report += f"- **[{item['source']}]** {item['title']} ({item['points']}↑ {item['comments']}💬)\n"
            report += f"  {item['url']}\n"

        self.store_memory(
            f"discussions_{datetime.now().strftime('%Y%m%d')}",
            report, "reference", "hn,reddit,discussions,auto", 0.5
        )
        return {"status": "ok", "items": len(items)}


class NewsSummarizer(Workflow):
    """Summarize top headlines from news APIs.

    Config keys:
        news_topics: comma-separated topics
    """
    name = "news_summarizer"
    display_name = "News Summarizer"
    description = "Collect and organize top headlines by topic"
    category = "research"
    schedule_cron = "0 7 * * *"

    def run(self) -> Dict:
        topics = self.get_config("news_topics", "artificial intelligence,cybersecurity").split(",")
        topics = [t.strip() for t in topics if t.strip()]

        # Use HN Algolia as a free news source
        all_stories = []
        for topic in topics:
            query = urllib.parse.quote(topic)
            url = f"https://hn.algolia.com/api/v1/search?query={query}&tags=story&hitsPerPage=5"
            raw = self.http_get(url)
            if raw:
                try:
                    data = json.loads(raw)
                    for hit in data.get("hits", [])[:5]:
                        all_stories.append({
                            "title": hit.get("title", ""),
                            "url": hit.get("url", ""),
                            "points": hit.get("points", 0),
                            "topic": topic,
                        })
                except json.JSONDecodeError:
                    pass

        report = f"# News Briefing — {datetime.now().strftime('%Y-%m-%d')}\n\n"
        for topic in topics:
            stories = [s for s in all_stories if s["topic"] == topic]
            if stories:
                report += f"## {topic.title()}\n"
                for s in stories:
                    report += f"- {s['title']} ({s['points']}↑)\n"
                    if s["url"]:
                        report += f"  {s['url']}\n"
                report += "\n"

        self.store_memory(
            f"news_{datetime.now().strftime('%Y%m%d')}",
            report, "reference", "news,briefing,auto", 0.5
        )
        return {"status": "ok", "stories": len(all_stories), "topics": len(topics)}


class CompetitorTracker(Workflow):
    """Track competitor activity via GitHub stars, releases, and HN mentions.

    Config keys:
        competitors: comma-separated "name:github_repo" pairs
    """
    name = "competitor_tracker"
    display_name = "Competitor Tracker"
    description = "Monitor competitor repos for stars, releases, and community activity"
    category = "research"
    schedule_cron = "0 9 * * 1"  # Monday 9am

    def run(self) -> Dict:
        competitors_raw = self.get_config("competitors",
            "mem0:mem0ai/mem0,aios:aios-labs/aios").split(",")

        results = []
        for entry in competitors_raw:
            entry = entry.strip()
            if ":" not in entry:
                continue
            name, repo = entry.split(":", 1)

            # GitHub API (unauthenticated, 60 req/hr)
            url = f"https://api.github.com/repos/{repo.strip()}"
            raw = self.http_get(url)
            if raw:
                try:
                    data = json.loads(raw)
                    results.append({
                        "name": name.strip(),
                        "repo": repo.strip(),
                        "stars": data.get("stargazers_count", 0),
                        "forks": data.get("forks_count", 0),
                        "open_issues": data.get("open_issues_count", 0),
                        "updated": data.get("pushed_at", "")[:10],
                        "description": data.get("description", "")[:100],
                    })
                except json.JSONDecodeError:
                    pass

        report = f"# Competitor Report — {datetime.now().strftime('%Y-%m-%d')}\n\n"
        for r in results:
            report += f"## {r['name']} ({r['repo']})\n"
            report += f"⭐ {r['stars']:,} | 🍴 {r['forks']:,} | 🐛 {r['open_issues']} | Updated: {r['updated']}\n"
            report += f"{r['description']}\n\n"

        self.store_memory(
            f"competitors_{datetime.now().strftime('%Y%m%d')}",
            report, "reference", "competitors,research,auto", 0.6
        )
        return {"status": "ok", "competitors": len(results)}


class PriceWatcher(Workflow):
    """Monitor prices of items from URLs and alert on changes.

    Config keys:
        price_watch_items: JSON array of {name, url, target_price}
    """
    name = "price_watcher"
    display_name = "Price Watcher"
    description = "Monitor product prices and alert on drops"
    category = "research"
    schedule_cron = "0 10 * * *"

    def run(self) -> Dict:
        items_json = self.get_config("price_watch_items", "[]")
        try:
            items = json.loads(items_json) if isinstance(items_json, str) else items_json
        except json.JSONDecodeError:
            items = []

        if not items:
            return {"status": "ok", "message": "No items configured"}

        results = []
        for item in items:
            name = item.get("name", "Unknown")
            url = item.get("url", "")
            target = float(item.get("target_price", 0))

            if url:
                html = self.http_get(url)
                if html:
                    # Try to find price patterns
                    price_match = re.search(r'[\$€£]([\d,]+\.?\d*)', html)
                    if price_match:
                        current = float(price_match.group(1).replace(",", ""))
                        alert = current <= target if target > 0 else False
                        results.append({
                            "name": name, "current": current,
                            "target": target, "alert": alert,
                        })

        report = f"# Price Watch — {datetime.now().strftime('%Y-%m-%d')}\n\n"
        for r in results:
            marker = "🔔 ALERT" if r["alert"] else "📊"
            report += f"- {marker} **{r['name']}**: ${r['current']:.2f}"
            if r["target"] > 0:
                report += f" (target: ${r['target']:.2f})"
            report += "\n"

        self.store_memory(
            f"prices_{datetime.now().strftime('%Y%m%d')}",
            report, "reference", "prices,monitoring,auto", 0.4
        )
        return {"status": "ok", "items_checked": len(results),
                "alerts": sum(1 for r in results if r["alert"])}


class WeatherBriefing(Workflow):
    """Get weather forecast for configured location.

    Config keys:
        weather_location: city name or "lat,lon"
        weather_units: metric or imperial (default: metric)
    """
    name = "weather_briefing"
    display_name = "Weather Briefing"
    description = "Daily weather forecast for your location"
    category = "research"
    schedule_cron = "0 6 * * *"

    def run(self) -> Dict:
        location = self.get_config("weather_location", "")
        if not location:
            return {"status": "ok", "message": "No location configured. Use: aibrain config set weather_location 'YourCity'"}

        # Use open-meteo (free, no API key)
        # First geocode the location
        geo_url = f"https://geocoding-api.open-meteo.com/v1/search?name={urllib.parse.quote(location)}&count=1"
        geo_raw = self.http_get(geo_url)
        if not geo_raw:
            return {"status": "error", "message": "Geocoding failed"}

        try:
            geo = json.loads(geo_raw)
            result = geo.get("results", [{}])[0]
            lat = result.get("latitude", 0)
            lon = result.get("longitude", 0)
            place = result.get("name", location)
        except (json.JSONDecodeError, IndexError):
            return {"status": "error", "message": "Location not found"}

        # Get forecast
        units = self.get_config("weather_units", "metric")
        temp_unit = "celsius" if units == "metric" else "fahrenheit"
        wx_url = (f"https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}"
                  f"&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,weathercode"
                  f"&temperature_unit={temp_unit}&timezone=auto&forecast_days=3")
        wx_raw = self.http_get(wx_url)
        if not wx_raw:
            return {"status": "error", "message": "Weather API failed"}

        try:
            wx = json.loads(wx_raw)
            daily = wx.get("daily", {})
        except json.JSONDecodeError:
            return {"status": "error", "message": "Weather parse failed"}

        unit_symbol = "°C" if units == "metric" else "°F"
        report = f"# Weather — {place}\n\n"

        dates = daily.get("time", [])
        maxs = daily.get("temperature_2m_max", [])
        mins = daily.get("temperature_2m_min", [])
        precip = daily.get("precipitation_sum", [])

        for i in range(min(3, len(dates))):
            d = dates[i] if i < len(dates) else "?"
            hi = maxs[i] if i < len(maxs) else "?"
            lo = mins[i] if i < len(mins) else "?"
            rain = precip[i] if i < len(precip) else 0
            report += f"**{d}**: {hi}{unit_symbol} / {lo}{unit_symbol}"
            if rain and rain > 0:
                report += f" | Rain: {rain}mm"
            report += "\n"

        self.store_memory(
            f"weather_{datetime.now().strftime('%Y%m%d')}",
            report, "reference", "weather,daily,auto", 0.3
        )
        return {"status": "ok", "location": place, "days": min(3, len(dates))}


class StockWatchlist(Workflow):
    """Track stock prices for a watchlist (requires yfinance for real data).

    Config keys:
        stock_symbols: comma-separated ticker symbols
    Falls back to basic price display if yfinance not available.
    """
    name = "stock_watchlist"
    display_name = "Stock Watchlist"
    description = "Track stock prices and daily changes"
    category = "research"
    schedule_cron = "0 16 * * 1-5"  # weekdays 4pm
    requires = ["yfinance"]

    def run(self) -> Dict:
        symbols = self.get_config("stock_symbols", "AAPL,GOOGL,MSFT").split(",")
        symbols = [s.strip().upper() for s in symbols if s.strip()]

        results = []
        try:
            import yfinance as yf
            for sym in symbols:
                try:
                    ticker = yf.Ticker(sym)
                    info = ticker.info
                    results.append({
                        "symbol": sym,
                        "price": info.get("currentPrice", info.get("regularMarketPrice", 0)),
                        "change": info.get("regularMarketChangePercent", 0),
                        "name": info.get("shortName", sym),
                    })
                except Exception:
                    results.append({"symbol": sym, "price": 0, "change": 0, "name": sym})
        except ImportError:
            return {"status": "ok", "message": "yfinance not installed. pip install aibrain[finance]"}

        report = f"# Market Watch — {datetime.now().strftime('%Y-%m-%d %H:%M')}\n\n"
        for r in results:
            arrow = "📈" if r["change"] >= 0 else "📉"
            report += f"- {arrow} **{r['symbol']}** ({r['name']}): ${r['price']:.2f} ({r['change']:+.1f}%)\n"

        self.store_memory(
            f"stocks_{datetime.now().strftime('%Y%m%d')}",
            report, "reference", "stocks,finance,auto", 0.4
        )
        return {"status": "ok", "symbols": len(results)}


class DocMonitor(Workflow):
    """Monitor documentation pages for changes.

    Config keys:
        doc_urls: comma-separated URLs to monitor
    """
    name = "doc_monitor"
    display_name = "Documentation Monitor"
    description = "Detect changes in monitored documentation pages"
    category = "research"
    schedule_cron = "0 9 * * *"

    def run(self) -> Dict:
        urls = self.get_config("doc_urls", "").split(",")
        urls = [u.strip() for u in urls if u.strip()]

        if not urls:
            return {"status": "ok", "message": "No doc URLs configured"}

        changes = []
        db = self._db()

        for url in urls:
            content = self.http_get(url)
            if not content:
                continue

            # Hash the content
            content_hash = hashlib.sha256(content.encode()).hexdigest()[:16]
            url_key = f"doc_hash_{hashlib.sha256(url.encode()).hexdigest()[:12]}"

            # Check against stored hash
            try:
                row = db.execute(
                    "SELECT value FROM config WHERE key=?", (url_key,)
                ).fetchone()
                old_hash = row["value"] if row else None

                if old_hash and old_hash != content_hash:
                    changes.append({"url": url, "status": "changed"})
                elif not old_hash:
                    changes.append({"url": url, "status": "new"})

                # Update hash
                db.execute(
                    "INSERT OR REPLACE INTO config (key, value, updated) VALUES (?, ?, datetime('now'))",
                    (url_key, content_hash)
                )
                db.commit()
            except Exception:
                pass

        if changes:
            report = f"# Doc Changes — {datetime.now().strftime('%Y-%m-%d')}\n\n"
            for c in changes:
                report += f"- {'🔄 Changed' if c['status'] == 'changed' else '🆕 New'}: {c['url']}\n"

            self.store_memory(
                f"doc_changes_{datetime.now().strftime('%Y%m%d')}",
                report, "reference", "documentation,changes,monitoring,auto", 0.6
            )

        return {"status": "ok", "monitored": len(urls), "changes": len(changes)}


class PodcastSummarizer(Workflow):
    """Track and organize podcast episodes from RSS feeds.

    Config keys:
        podcast_feeds: comma-separated podcast RSS feed URLs
        podcast_max_episodes: max episodes per feed (default: 3)
    """
    name = "podcast_summarizer"
    display_name = "Podcast Summarizer"
    description = "Track new podcast episodes and organize listening queue"
    category = "research"
    schedule_cron = "0 7 * * 1,4"  # Monday and Thursday 7am

    def run(self) -> Dict:
        feeds = self.get_config("podcast_feeds", "").split(",")
        feeds = [f.strip() for f in feeds if f.strip()]
        max_eps = int(self.get_config("podcast_max_episodes", "3"))

        if not feeds:
            return {"status": "ok",
                    "message": "No podcast feeds configured. Use: aibrain config set podcast_feeds 'feed_url1,feed_url2'"}

        all_episodes = []
        for feed_url in feeds:
            xml = self.http_get(feed_url, timeout=20)
            if not xml:
                continue

            # Extract podcast title
            show_match = re.search(r'<title[^>]*>(.*?)</title>', xml, re.DOTALL)
            show_name = show_match.group(1).strip() if show_match else "Unknown"
            show_name = re.sub(r'<!\[CDATA\[(.*?)\]\]>', r'\1', show_name)

            # Extract episodes
            items = re.findall(r'<item>(.*?)</item>', xml, re.DOTALL)
            for item in items[:max_eps]:
                title = re.search(r'<title[^>]*>(.*?)</title>', item, re.DOTALL)
                desc = re.search(r'<description[^>]*>(.*?)</description>', item, re.DOTALL) or \
                       re.search(r'<itunes:summary[^>]*>(.*?)</itunes:summary>', item, re.DOTALL)
                pub = re.search(r'<pubDate[^>]*>(.*?)</pubDate>', item)
                duration = re.search(r'<itunes:duration[^>]*>(.*?)</itunes:duration>', item)
                enclosure = re.search(r'<enclosure[^>]*url=["\']([^"\']+)', item)

                ep_title = ""
                if title:
                    ep_title = re.sub(r'<!\[CDATA\[(.*?)\]\]>', r'\1', title.group(1)).strip()

                ep_desc = ""
                if desc:
                    ep_desc = re.sub(r'<!\[CDATA\[(.*?)\]\]>', r'\1', desc.group(1)).strip()
                    ep_desc = re.sub(r'<[^>]+>', '', ep_desc)[:200]

                all_episodes.append({
                    "show": show_name,
                    "title": ep_title,
                    "description": ep_desc,
                    "published": pub.group(1).strip()[:25] if pub else "",
                    "duration": duration.group(1).strip() if duration else "",
                    "url": enclosure.group(1) if enclosure else "",
                })

        report = f"# Podcast Queue — {datetime.now().strftime('%Y-%m-%d')}\n\n"
        report += f"**{len(all_episodes)} episodes from {len(feeds)} feeds**\n\n"

        current_show = ""
        for ep in all_episodes:
            if ep["show"] != current_show:
                current_show = ep["show"]
                report += f"## {current_show}\n"
            report += f"- **{ep['title']}**"
            if ep["duration"]:
                report += f" ({ep['duration']})"
            report += f"\n"
            if ep["published"]:
                report += f"  Published: {ep['published']}\n"
            if ep["description"]:
                report += f"  {ep['description'][:150]}\n"
            report += "\n"

        self.store_memory(
            f"podcasts_{datetime.now().strftime('%Y%m%d')}",
            report, "reference", "podcast,queue,listening,auto", 0.4
        )
        return {"status": "ok", "episodes": len(all_episodes), "feeds": len(feeds)}


# =========================================================================
# CATEGORY 3: COMMUNICATION & OUTREACH (10)
# =========================================================================

class EmailTriage(Workflow):
    """Categorize and prioritize emails from memory entries.

    Reads memories tagged 'email' and categorizes by urgency/action needed.
    """
    name = "email_triage"
    display_name = "Email Triage"
    description = "Categorize emails by urgency and required action"
    category = "communication"
    schedule_cron = "0 8 * * *"

    def run(self) -> Dict:
        db = self._db()
        emails = []
        try:
            rows = db.execute(
                "SELECT name, content, tags, created FROM memories "
                "WHERE tags LIKE '%email%' AND active=1 "
                "AND created >= datetime('now', '-1 days') "
                "ORDER BY created DESC LIMIT 50"
            ).fetchall()
            emails = [dict(r) for r in rows]
        except Exception:
            pass

        urgent = []
        action_needed = []
        informational = []

        urgent_keywords = ["urgent", "asap", "deadline", "overdue", "critical", "immediately"]
        action_keywords = ["please", "could you", "can you", "request", "review", "approve", "confirm"]

        for email in emails:
            content_lower = email.get("content", "").lower()
            if any(kw in content_lower for kw in urgent_keywords):
                urgent.append(email)
            elif any(kw in content_lower for kw in action_keywords):
                action_needed.append(email)
            else:
                informational.append(email)

        report = f"# Email Triage — {datetime.now().strftime('%Y-%m-%d')}\n\n"
        report += f"🔴 Urgent: {len(urgent)} | 🟡 Action needed: {len(action_needed)} | 🟢 Informational: {len(informational)}\n\n"

        if urgent:
            report += "## 🔴 Urgent\n"
            for e in urgent:
                report += f"- {e['name']}: {e['content'][:80]}\n"

        if action_needed:
            report += "\n## 🟡 Action Needed\n"
            for e in action_needed:
                report += f"- {e['name']}: {e['content'][:80]}\n"

        self.store_memory(
            f"email_triage_{datetime.now().strftime('%Y%m%d')}",
            report, "reference", "email,triage,auto", 0.6
        )
        return {"status": "ok", "total": len(emails), "urgent": len(urgent),
                "action_needed": len(action_needed)}


class FollowUpReminder(Workflow):
    """Track items that need follow-up and remind when due.

    Reads memories tagged 'follow_up' with dates.
    """
    name = "follow_up_reminder"
    display_name = "Follow-Up Reminder"
    description = "Track and remind about pending follow-ups"
    category = "communication"
    schedule_cron = "0 9 * * *"

    def run(self) -> Dict:
        db = self._db()
        follow_ups = []
        try:
            rows = db.execute(
                "SELECT name, content, tags, created FROM memories "
                "WHERE tags LIKE '%follow_up%' AND active=1 "
                "ORDER BY created ASC"
            ).fetchall()
            follow_ups = [dict(r) for r in rows]
        except Exception:
            pass

        overdue = []
        upcoming = []
        today = datetime.now().strftime("%Y-%m-%d")

        for fu in follow_ups:
            # Try to extract a due date from content
            date_match = re.search(r'(\d{4}-\d{2}-\d{2})', fu.get("content", ""))
            if date_match:
                due = date_match.group(1)
                if due <= today:
                    overdue.append({**fu, "due": due})
                else:
                    upcoming.append({**fu, "due": due})
            else:
                # No date — check age
                created = fu.get("created", "")[:10]
                try:
                    age = (datetime.now() - datetime.strptime(created, "%Y-%m-%d")).days
                    if age >= 3:
                        overdue.append({**fu, "due": f"{age} days old"})
                    else:
                        upcoming.append({**fu, "due": f"created {created}"})
                except ValueError:
                    upcoming.append(fu)

        report = f"# Follow-Up Tracker — {today}\n\n"
        if overdue:
            report += f"## ⚠️ Overdue ({len(overdue)})\n"
            for fu in overdue:
                report += f"- **{fu['name']}**: {fu.get('due', '?')} — {fu['content'][:60]}\n"
        if upcoming:
            report += f"\n## 📅 Upcoming ({len(upcoming)})\n"
            for fu in upcoming[:10]:
                report += f"- {fu['name']}: {fu.get('due', '?')} — {fu['content'][:60]}\n"

        if overdue:
            self.store_memory(
                f"follow_ups_{today}", report,
                "reference", "follow_up,reminders,auto", 0.7
            )

        return {"status": "ok", "overdue": len(overdue), "upcoming": len(upcoming)}


class MeetingNotesExtractor(Workflow):
    """Process raw meeting notes into structured summaries.

    Reads memories tagged 'meeting_raw' and produces structured output.
    """
    name = "meeting_notes"
    display_name = "Meeting Notes Extractor"
    description = "Extract action items and decisions from raw meeting notes"
    category = "communication"
    schedule_cron = "0 17 * * 1-5"  # weekdays 5pm

    def run(self) -> Dict:
        db = self._db()
        raw_notes = []
        try:
            rows = db.execute(
                "SELECT id, name, content, created FROM memories "
                "WHERE tags LIKE '%meeting%' AND active=1 "
                "AND created >= datetime('now', '-1 days') "
                "ORDER BY created DESC LIMIT 5"
            ).fetchall()
            raw_notes = [dict(r) for r in rows]
        except Exception:
            pass

        processed = 0
        for note in raw_notes:
            content = note.get("content", "")

            # Extract action items (lines starting with TODO, ACTION, -, [ ])
            actions = re.findall(r'(?:TODO|ACTION|TASK)[:.]?\s*(.+)', content, re.IGNORECASE)
            checkbox_actions = re.findall(r'\[\s*\]\s*(.+)', content)
            all_actions = actions + checkbox_actions

            # Extract decisions
            decisions = re.findall(r'(?:DECIDED|DECISION|AGREED)[:.]?\s*(.+)', content, re.IGNORECASE)

            # Build structured summary
            structured = f"# Meeting: {note['name']}\n"
            structured += f"**Date:** {note['created'][:16]}\n\n"

            if decisions:
                structured += "## Decisions\n"
                for d in decisions:
                    structured += f"- ✅ {d.strip()}\n"

            if all_actions:
                structured += "\n## Action Items\n"
                for a in all_actions:
                    structured += f"- [ ] {a.strip()}\n"

            # Store processed version
            self.store_memory(
                f"meeting_processed_{note['id']}",
                structured, "reference",
                "meeting,processed,actions,decisions,auto", 0.6
            )
            processed += 1

        return {"status": "ok", "notes_processed": processed}


class ContactEnricher(Workflow):
    """Enrich contact information from stored contacts.

    Reads memories tagged 'contact' and builds a contact index.
    """
    name = "contact_enricher"
    display_name = "Contact Enricher"
    description = "Organize and index stored contacts"
    category = "communication"
    schedule_cron = "0 10 * * 6"  # Saturday 10am

    def run(self) -> Dict:
        db = self._db()
        contacts = []
        try:
            rows = db.execute(
                "SELECT name, content, tags FROM memories "
                "WHERE tags LIKE '%contact%' AND active=1 ORDER BY name"
            ).fetchall()
            contacts = [dict(r) for r in rows]
        except Exception:
            pass

        # Extract emails and phone numbers
        enriched = []
        for c in contacts:
            content = c.get("content", "")
            emails = re.findall(r'[\w.+-]+@[\w-]+\.[\w.]+', content)
            phones = re.findall(r'[\+]?[\d\s\-\(\)]{7,}', content)
            enriched.append({
                "name": c["name"],
                "emails": emails,
                "phones": [p.strip() for p in phones],
                "tags": c.get("tags", ""),
            })

        report = f"# Contact Directory — {len(enriched)} contacts\n\n"
        for c in enriched:
            report += f"- **{c['name']}**"
            if c["emails"]:
                report += f" | {', '.join(c['emails'])}"
            if c["phones"]:
                report += f" | {', '.join(c['phones'][:2])}"
            report += "\n"

        self.store_memory(
            "contact_directory", report,
            "reference", "contacts,directory,auto", 0.5
        )
        return {"status": "ok", "contacts": len(enriched)}


class NewsletterDigest(Workflow):
    """Summarize newsletter emails into a digest."""
    name = "newsletter_digest"
    display_name = "Newsletter Digest"
    description = "Consolidate newsletter content into a weekly digest"
    category = "communication"
    schedule_cron = "0 8 * * 0"

    def run(self) -> Dict:
        db = self._db()
        newsletters = []
        try:
            rows = db.execute(
                "SELECT name, content, created FROM memories "
                "WHERE tags LIKE '%newsletter%' AND active=1 "
                "AND created >= datetime('now', '-7 days') "
                "ORDER BY created DESC LIMIT 20"
            ).fetchall()
            newsletters = [dict(r) for r in rows]
        except Exception:
            pass

        report = f"# Newsletter Digest — Week of {datetime.now().strftime('%Y-%m-%d')}\n\n"
        report += f"**{len(newsletters)} newsletters this week**\n\n"

        for nl in newsletters:
            report += f"### {nl['name']}\n"
            report += f"*{nl['created'][:10]}*\n"
            report += f"{nl['content'][:200]}...\n\n"

        self.store_memory(
            f"newsletter_digest_{datetime.now().strftime('%Y_W%W')}",
            report, "reference", "newsletter,digest,weekly,auto", 0.4
        )
        return {"status": "ok", "newsletters": len(newsletters)}


class SocialMediaScheduler(Workflow):
    """Manage and track social media post schedule."""
    name = "social_scheduler"
    display_name = "Social Media Scheduler"
    description = "Track scheduled social media posts and posting cadence"
    category = "communication"
    schedule_cron = "0 7 * * *"

    def run(self) -> Dict:
        db = self._db()
        posts = []
        try:
            rows = db.execute(
                "SELECT name, content, tags, created FROM memories "
                "WHERE tags LIKE '%social_post%' AND active=1 "
                "ORDER BY created DESC LIMIT 20"
            ).fetchall()
            posts = [dict(r) for r in rows]
        except Exception:
            pass

        # Count by platform
        platforms = Counter()
        for p in posts:
            for tag in p.get("tags", "").split(","):
                tag = tag.strip()
                if tag in ("linkedin", "twitter", "x", "reddit", "tiktok", "instagram", "medium", "facebook"):
                    platforms[tag] += 1

        report = f"# Social Media Status — {datetime.now().strftime('%Y-%m-%d')}\n\n"
        report += f"**{len(posts)} posts tracked**\n\n"
        if platforms:
            report += "## Posts by Platform\n"
            for platform, count in platforms.most_common():
                report += f"- {platform}: {count} posts\n"

        self.store_memory(
            f"social_status_{datetime.now().strftime('%Y%m%d')}",
            report, "reference", "social_media,status,auto", 0.4
        )
        return {"status": "ok", "posts": len(posts), "platforms": dict(platforms)}


class ColdOutreachTracker(Workflow):
    """Track cold outreach campaigns — sent, responses, follow-ups."""
    name = "cold_outreach"
    display_name = "Cold Outreach Tracker"
    description = "Track outreach campaigns with response rates"
    category = "communication"
    schedule_cron = "0 10 * * 1"

    def run(self) -> Dict:
        db = self._db()
        outreach = []
        try:
            rows = db.execute(
                "SELECT name, content, tags FROM memories "
                "WHERE tags LIKE '%outreach%' AND active=1 ORDER BY created DESC"
            ).fetchall()
            outreach = [dict(r) for r in rows]
        except Exception:
            pass

        sent = [o for o in outreach if "sent" in o.get("tags", "")]
        responded = [o for o in outreach if "responded" in o.get("tags", "")]
        response_rate = (len(responded) / max(len(sent), 1)) * 100

        report = f"# Outreach Report — {datetime.now().strftime('%Y-%m-%d')}\n\n"
        report += f"📤 Sent: {len(sent)} | 📥 Responded: {len(responded)} | Rate: {response_rate:.0f}%\n"

        self.store_memory(
            f"outreach_report_{datetime.now().strftime('%Y%m%d')}",
            report, "reference", "outreach,report,auto", 0.5
        )
        return {"status": "ok", "sent": len(sent), "responded": len(responded),
                "rate": round(response_rate, 1)}


class ThankYouAutomator(Workflow):
    """Remind about thank-you notes for recent meetings/interactions."""
    name = "thank_you"
    display_name = "Thank You Automator"
    description = "Remind to send thank-you notes after meetings and interactions"
    category = "communication"
    schedule_cron = "0 17 * * *"

    def run(self) -> Dict:
        db = self._db()
        recent_meetings = []
        try:
            rows = db.execute(
                "SELECT name, content FROM memories "
                "WHERE tags LIKE '%meeting%' AND active=1 "
                "AND created >= datetime('now', '-1 days') "
                "ORDER BY created DESC LIMIT 10"
            ).fetchall()
            recent_meetings = [dict(r) for r in rows]
        except Exception:
            pass

        if recent_meetings:
            report = f"# Thank You Reminders — {datetime.now().strftime('%Y-%m-%d')}\n\n"
            for m in recent_meetings:
                report += f"- 📝 Send thank you for: {m['name']}\n"
            self.store_memory(
                f"thank_you_{datetime.now().strftime('%Y%m%d')}",
                report, "reference", "thank_you,reminders,auto", 0.5
            )

        return {"status": "ok", "reminders": len(recent_meetings)}


class NetworkingCRM(Workflow):
    """Track professional relationships and interaction frequency."""
    name = "networking_crm"
    display_name = "Networking CRM"
    description = "Track professional relationships and suggest reconnections"
    category = "communication"
    schedule_cron = "0 9 * * 1"

    def run(self) -> Dict:
        db = self._db()
        contacts = []
        try:
            rows = db.execute(
                "SELECT name, content, tags, updated FROM memories "
                "WHERE tags LIKE '%networking%' AND active=1 "
                "ORDER BY updated ASC"
            ).fetchall()
            contacts = [dict(r) for r in rows]
        except Exception:
            pass

        stale = []
        for c in contacts:
            last_updated = c.get("updated", "")[:10]
            try:
                days_ago = (datetime.now() - datetime.strptime(last_updated, "%Y-%m-%d")).days
                if days_ago >= 30:
                    stale.append({**c, "days_since": days_ago})
            except ValueError:
                pass

        report = f"# Networking — {datetime.now().strftime('%Y-%m-%d')}\n\n"
        report += f"**{len(contacts)} contacts** | {len(stale)} need reconnection\n\n"

        if stale:
            report += "## Reconnect With\n"
            for s in sorted(stale, key=lambda x: x["days_since"], reverse=True)[:10]:
                report += f"- **{s['name']}** — {s['days_since']} days since last contact\n"

        self.store_memory(
            f"networking_{datetime.now().strftime('%Y%m%d')}",
            report, "reference", "networking,crm,auto", 0.5
        )
        return {"status": "ok", "contacts": len(contacts), "stale": len(stale)}


class EmailAutoReply(Workflow):
    """Draft auto-reply suggestions for incoming emails based on patterns.

    Reads memories tagged 'email' and 'inbox', matches against reply
    templates stored in config, and drafts suggested responses. Does NOT
    send anything — stores drafts in memory for human review.

    Config keys:
        email_reply_rules: JSON array of {pattern, template, priority}
        email_default_reply: default reply template for unmatched emails
    """
    name = "email_auto_reply"
    display_name = "Email Auto-Reply Drafter"
    description = "Draft reply suggestions for incoming emails based on pattern matching"
    category = "communication"
    schedule_cron = "0 8,13 * * 1-5"  # twice daily on weekdays

    def run(self) -> Dict:
        rules_json = self.get_config("email_reply_rules", "[]")
        try:
            rules = json.loads(rules_json) if isinstance(rules_json, str) else rules_json
        except json.JSONDecodeError:
            rules = []

        default_reply = self.get_config("email_default_reply",
            "Thanks for reaching out. I'll review this and get back to you within 24 hours.")

        # Default rules if none configured
        if not rules:
            rules = [
                {"pattern": "meeting|schedule|calendar|call", "priority": "medium",
                 "template": "Thanks for the invite. Let me check my availability and confirm shortly."},
                {"pattern": "invoice|payment|billing", "priority": "high",
                 "template": "Received, thank you. I'll review and process this within 48 hours."},
                {"pattern": "question|help|support|issue", "priority": "medium",
                 "template": "Thanks for reaching out. I'll look into this and follow up with an answer."},
                {"pattern": "opportunity|partnership|collaborate|sponsor", "priority": "low",
                 "template": "Appreciate the interest. Let me review the details and I'll be in touch if it's a fit."},
                {"pattern": "urgent|asap|critical|emergency", "priority": "high",
                 "template": "Noted — I'm looking at this now and will respond as soon as possible."},
            ]

        db = self._db()
        emails = []
        try:
            rows = db.execute(
                "SELECT id, name, content, tags, created FROM memories "
                "WHERE tags LIKE '%email%' AND tags LIKE '%inbox%' AND active=1 "
                "AND created >= datetime('now', '-1 days') "
                "AND name NOT LIKE 'reply_draft_%' "
                "ORDER BY created DESC LIMIT 20"
            ).fetchall()
            emails = [dict(r) for r in rows]
        except Exception:
            pass

        if not emails:
            return {"status": "ok", "emails": 0, "drafts": 0,
                    "message": "No unprocessed emails. Tag incoming emails with 'email,inbox'."}

        drafts_created = 0
        high_priority = 0

        report = f"# Email Reply Drafts — {datetime.now().strftime('%Y-%m-%d %H:%M')}\n\n"

        for email in emails:
            content_lower = email.get("content", "").lower()
            subject = email.get("name", "Untitled")

            # Match against rules
            matched_rule = None
            for rule in rules:
                pattern = rule.get("pattern", "")
                if pattern and re.search(pattern, content_lower):
                    matched_rule = rule
                    break

            # Determine reply template and priority
            if matched_rule:
                reply_template = matched_rule.get("template", default_reply)
                priority = matched_rule.get("priority", "medium")
            else:
                reply_template = default_reply
                priority = "low"

            if priority == "high":
                high_priority += 1

            # Build the draft
            priority_icon = {"high": "🔴", "medium": "🟡", "low": "🟢"}.get(priority, "⚪")
            draft_content = (
                f"Re: {subject}\n"
                f"Priority: {priority}\n"
                f"Matched: {matched_rule.get('pattern', 'default') if matched_rule else 'none'}\n\n"
                f"--- DRAFT REPLY ---\n"
                f"{reply_template}\n"
                f"--- END DRAFT ---\n\n"
                f"Original preview: {email.get('content', '')[:200]}"
            )

            # Store draft for human review
            self.store_memory(
                f"reply_draft_{email.get('id', '')}_{datetime.now().strftime('%Y%m%d')}",
                draft_content, "reference",
                f"email,reply_draft,{priority},auto", 0.5 if priority == "low" else 0.7
            )
            drafts_created += 1

            report += f"{priority_icon} **{subject}** — {priority} priority\n"
            report += f"  Draft: {reply_template[:80]}...\n\n"

        report += f"\n*{drafts_created} drafts created. Review and edit before sending.*"

        self.store_memory(
            f"reply_drafts_batch_{datetime.now().strftime('%Y%m%d_%H%M')}",
            report, "reference", "email,reply_drafts,batch,auto", 0.6
        )

        return {"status": "ok", "emails": len(emails), "drafts": drafts_created,
                "high_priority": high_priority}


# =========================================================================
# CATEGORY 4: DEVELOPER & TECHNICAL (10)
# =========================================================================

class GitHubDigest(Workflow):
    """Track activity across GitHub repos.

    Config keys:
        github_repos: comma-separated owner/repo pairs
    """
    name = "github_digest"
    display_name = "GitHub Digest"
    description = "Track commits, issues, and releases across GitHub repos"
    category = "developer"
    schedule_cron = "0 9 * * 1-5"

    def run(self) -> Dict:
        repos = self.get_config("github_repos", "").split(",")
        repos = [r.strip() for r in repos if r.strip()]

        if not repos:
            return {"status": "ok", "message": "No repos configured. Use: aibrain config set github_repos 'owner/repo1,owner/repo2'"}

        all_events = []
        for repo in repos[:10]:
            url = f"https://api.github.com/repos/{repo}/events?per_page=5"
            raw = self.http_get(url)
            if raw:
                try:
                    events = json.loads(raw)
                    for e in events[:5]:
                        all_events.append({
                            "repo": repo,
                            "type": e.get("type", ""),
                            "actor": e.get("actor", {}).get("login", ""),
                            "created": e.get("created_at", "")[:16],
                        })
                except json.JSONDecodeError:
                    pass

        report = f"# GitHub Digest — {datetime.now().strftime('%Y-%m-%d')}\n\n"
        for repo in repos:
            events = [e for e in all_events if e["repo"] == repo]
            if events:
                report += f"## {repo}\n"
                for e in events:
                    report += f"- {e['type']} by {e['actor']} ({e['created']})\n"
                report += "\n"

        self.store_memory(
            f"github_{datetime.now().strftime('%Y%m%d')}",
            report, "reference", "github,development,auto", 0.5
        )
        return {"status": "ok", "repos": len(repos), "events": len(all_events)}


class DependencyAuditor(Workflow):
    """Check Python dependencies for known vulnerabilities.

    Config keys:
        audit_requirements_path: path to requirements.txt
    """
    name = "dependency_auditor"
    display_name = "Dependency Auditor"
    description = "Check project dependencies for known vulnerabilities"
    category = "developer"
    schedule_cron = "0 10 * * 1"  # Monday 10am

    def run(self) -> Dict:
        req_path = self.get_config("audit_requirements_path", "requirements.txt")
        path = Path(req_path)

        if not path.exists():
            return {"status": "ok", "message": f"requirements.txt not found at {req_path}"}

        deps = []
        for line in path.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#") and not line.startswith("-"):
                # Extract package name
                name = re.split(r'[>=<!\[]', line)[0].strip()
                if name:
                    deps.append({"name": name, "spec": line})

        report = f"# Dependency Audit — {datetime.now().strftime('%Y-%m-%d')}\n\n"
        report += f"**{len(deps)} dependencies found in {req_path}**\n\n"

        # Check PyPI for latest versions
        outdated = []
        for dep in deps[:20]:
            url = f"https://pypi.org/pypi/{dep['name']}/json"
            raw = self.http_get(url, timeout=5)
            if raw:
                try:
                    data = json.loads(raw)
                    latest = data.get("info", {}).get("version", "?")
                    dep["latest"] = latest
                except json.JSONDecodeError:
                    dep["latest"] = "?"

        report += "| Package | Specified | Latest |\n|---------|----------|--------|\n"
        for dep in deps[:20]:
            report += f"| {dep['name']} | {dep['spec']} | {dep.get('latest', '?')} |\n"

        self.store_memory(
            f"dep_audit_{datetime.now().strftime('%Y%m%d')}",
            report, "reference", "dependencies,audit,security,auto", 0.6
        )
        return {"status": "ok", "dependencies": len(deps)}


class UptimeMonitor(Workflow):
    """Check if configured services/URLs are responding.

    Config keys:
        uptime_urls: comma-separated URLs to monitor
        uptime_timeout: request timeout in seconds (default: 10)
    """
    name = "uptime_monitor"
    display_name = "Uptime Monitor"
    description = "Monitor service availability and response times"
    category = "developer"
    schedule_cron = "*/15 * * * *"  # every 15 minutes

    def run(self) -> Dict:
        urls = self.get_config("uptime_urls", "").split(",")
        urls = [u.strip() for u in urls if u.strip()]
        timeout = int(self.get_config("uptime_timeout", "10"))

        if not urls:
            return {"status": "ok", "message": "No URLs configured"}

        results = []
        for url in urls:
            start = time.time()
            try:
                req = urllib.request.Request(url, headers={"User-Agent": "aibrain-uptime/0.9"})
                with urllib.request.urlopen(req, timeout=timeout) as resp:
                    status = resp.status
                    elapsed = round((time.time() - start) * 1000)
                    results.append({"url": url, "status": status, "ms": elapsed, "ok": True})
            except Exception as e:
                elapsed = round((time.time() - start) * 1000)
                results.append({"url": url, "status": str(e)[:50], "ms": elapsed, "ok": False})

        down = [r for r in results if not r["ok"]]

        if down:
            alert = f"⚠️ DOWNTIME ALERT — {datetime.now().strftime('%Y-%m-%d %H:%M')}\n\n"
            for r in down:
                alert += f"🔴 {r['url']}: {r['status']}\n"
            self.store_memory(
                f"uptime_alert_{datetime.now().strftime('%Y%m%d_%H%M')}",
                alert, "reference", "uptime,alert,critical,auto", 0.9
            )

        return {"status": "ok", "checked": len(results), "up": len(results) - len(down),
                "down": len(down)}


class LogAnalyzer(Workflow):
    """Analyze log files for errors and patterns.

    Config keys:
        log_paths: comma-separated log file paths
        log_error_patterns: comma-separated regex patterns to flag
    """
    name = "log_analyzer"
    display_name = "Log Analyzer"
    description = "Analyze log files for errors, warnings, and patterns"
    category = "developer"
    schedule_cron = "0 8 * * *"

    def run(self) -> Dict:
        log_paths = self.get_config("log_paths", "").split(",")
        log_paths = [p.strip() for p in log_paths if p.strip()]

        error_patterns = self.get_config("log_error_patterns",
            "ERROR,CRITICAL,Exception,Traceback,FATAL").split(",")

        if not log_paths:
            return {"status": "ok", "message": "No log paths configured"}

        total_errors = 0
        findings = []

        for log_path in log_paths:
            p = Path(log_path)
            if not p.exists():
                continue
            try:
                # Read last 1000 lines
                lines = p.read_text(errors="replace").splitlines()[-1000:]
                errors = []
                for i, line in enumerate(lines):
                    for pattern in error_patterns:
                        if pattern.strip() in line:
                            errors.append(line[:200])
                            break

                total_errors += len(errors)
                if errors:
                    findings.append({
                        "path": log_path,
                        "errors": len(errors),
                        "last_error": errors[-1],
                    })
            except (PermissionError, OSError):
                continue

        if findings:
            report = f"# Log Analysis — {datetime.now().strftime('%Y-%m-%d')}\n\n"
            report += f"**{total_errors} errors found across {len(findings)} files**\n\n"
            for f in findings:
                report += f"## {f['path']} ({f['errors']} errors)\n"
                report += f"Last: `{f['last_error']}`\n\n"

            self.store_memory(
                f"log_analysis_{datetime.now().strftime('%Y%m%d')}",
                report, "reference", "logs,analysis,errors,auto", 0.6
            )

        return {"status": "ok", "files_checked": len(log_paths), "errors": total_errors}


class APIHealthChecker(Workflow):
    """Health check configured API endpoints.

    Config keys:
        api_endpoints: JSON array of {name, url, method, expected_status}
    """
    name = "api_health"
    display_name = "API Health Checker"
    description = "Verify API endpoints are responding correctly"
    category = "developer"
    schedule_cron = "*/30 * * * *"  # every 30 minutes

    def run(self) -> Dict:
        endpoints_json = self.get_config("api_endpoints", "[]")
        try:
            endpoints = json.loads(endpoints_json) if isinstance(endpoints_json, str) else endpoints_json
        except json.JSONDecodeError:
            endpoints = []

        if not endpoints:
            return {"status": "ok", "message": "No API endpoints configured"}

        results = []
        for ep in endpoints:
            url = ep.get("url", "")
            expected = ep.get("expected_status", 200)
            start = time.time()
            try:
                req = urllib.request.Request(url)
                with urllib.request.urlopen(req, timeout=10) as resp:
                    actual = resp.status
                    ms = round((time.time() - start) * 1000)
                    ok = actual == expected
                    results.append({"name": ep.get("name", url), "status": actual,
                                   "expected": expected, "ms": ms, "ok": ok})
            except Exception as e:
                results.append({"name": ep.get("name", url), "status": str(e)[:50],
                               "expected": expected, "ms": 0, "ok": False})

        failures = [r for r in results if not r["ok"]]
        if failures:
            alert = f"# API Health Issues — {datetime.now().strftime('%H:%M')}\n\n"
            for f in failures:
                alert += f"- ❌ {f['name']}: got {f['status']}, expected {f['expected']}\n"
            self.store_memory(
                f"api_health_{datetime.now().strftime('%Y%m%d_%H%M')}",
                alert, "reference", "api,health,alert,auto", 0.8
            )

        return {"status": "ok", "checked": len(results), "healthy": len(results) - len(failures),
                "failures": len(failures)}


class DatabaseBackupReminder(Workflow):
    """Remind about database backups and track backup status."""
    name = "db_backup"
    display_name = "Database Backup Reminder"
    description = "Track database backup status and remind when overdue"
    category = "developer"
    schedule_cron = "0 3 * * *"  # daily 3am

    def run(self) -> Dict:
        # Check aibrain DB size and last backup
        db_path = Path(self.db_path)
        db_size = 0
        if db_path.exists():
            db_size = db_path.stat().st_size

        # Check for recent backup memories
        db = self._db()
        last_backup = None
        try:
            row = db.execute(
                "SELECT created FROM memories WHERE tags LIKE '%backup%' "
                "AND active=1 ORDER BY created DESC LIMIT 1"
            ).fetchone()
            if row:
                last_backup = row["created"]
        except Exception:
            pass

        days_since = 999
        if last_backup:
            try:
                last_dt = datetime.strptime(last_backup[:10], "%Y-%m-%d")
                days_since = (datetime.now() - last_dt).days
            except ValueError:
                pass

        overdue = days_since > 7

        if overdue:
            alert = (f"⚠️ Database backup overdue! Last backup: "
                     f"{'Never' if days_since > 100 else f'{days_since} days ago'}\n"
                     f"DB size: {db_size / 1024:.0f} KB\n"
                     f"Run: aibrain brain export --output backup_$(date +%Y%m%d).json")
            self.store_memory(
                f"backup_reminder_{datetime.now().strftime('%Y%m%d')}",
                alert, "reference", "backup,reminder,auto", 0.7
            )

        return {"status": "ok", "db_size_kb": round(db_size / 1024),
                "days_since_backup": days_since, "overdue": overdue}


class CodeReviewPrep(Workflow):
    """Prepare for code review by analyzing recent git changes."""
    name = "code_review_prep"
    display_name = "Code Review Prep"
    description = "Analyze recent git changes to prepare for code review"
    category = "developer"
    schedule_cron = "0 9 * * 1-5"

    def run(self) -> Dict:
        # Get recent skill principles for code review
        db = self._db()
        principles = []
        try:
            rows = db.execute(
                "SELECT principle, confidence FROM skill_principles "
                "WHERE task_type='code_review' AND status='active' "
                "ORDER BY confidence DESC LIMIT 10"
            ).fetchall()
            principles = [dict(r) for r in rows]
        except Exception:
            pass

        report = f"# Code Review Prep — {datetime.now().strftime('%Y-%m-%d')}\n\n"

        if principles:
            report += "## Learned Review Principles\n"
            for p in principles:
                report += f"- ({p['confidence']:.0%}) {p['principle']}\n"
        else:
            report += "## Default Review Checklist\n"
            report += "- [ ] Tests exist and pass\n"
            report += "- [ ] Error handling is present\n"
            report += "- [ ] No security issues (injection, auth bypass, secrets)\n"
            report += "- [ ] Code is readable and well-named\n"
            report += "- [ ] No unnecessary complexity\n"

        self.store_memory(
            f"review_prep_{datetime.now().strftime('%Y%m%d')}",
            report, "reference", "code_review,prep,auto", 0.4
        )
        return {"status": "ok", "principles": len(principles)}


class ChangelogGenerator(Workflow):
    """Generate changelog from recent memories tagged as changes/releases."""
    name = "changelog_gen"
    display_name = "Changelog Generator"
    description = "Generate changelog from recent changes and releases"
    category = "developer"
    schedule_cron = "0 16 * * 5"  # Friday 4pm

    def run(self) -> Dict:
        db = self._db()
        changes = []
        try:
            rows = db.execute(
                "SELECT name, content, tags, created FROM memories "
                "WHERE (tags LIKE '%change%' OR tags LIKE '%release%' OR tags LIKE '%feat%' OR tags LIKE '%fix%') "
                "AND active=1 AND created >= datetime('now', '-7 days') "
                "ORDER BY created DESC"
            ).fetchall()
            changes = [dict(r) for r in rows]
        except Exception:
            pass

        features = [c for c in changes if any(t in c.get("tags", "") for t in ("feat", "feature"))]
        fixes = [c for c in changes if "fix" in c.get("tags", "")]
        other = [c for c in changes if c not in features and c not in fixes]

        report = f"# Changelog — Week of {datetime.now().strftime('%Y-%m-%d')}\n\n"

        if features:
            report += "## ✨ Features\n"
            for f in features:
                report += f"- {f['name']}: {f['content'][:80]}\n"

        if fixes:
            report += "\n## 🐛 Bug Fixes\n"
            for f in fixes:
                report += f"- {f['name']}: {f['content'][:80]}\n"

        if other:
            report += "\n## 📝 Other Changes\n"
            for f in other:
                report += f"- {f['name']}: {f['content'][:80]}\n"

        self.store_memory(
            f"changelog_{datetime.now().strftime('%Y_W%W')}",
            report, "reference", "changelog,weekly,auto", 0.5
        )
        return {"status": "ok", "features": len(features), "fixes": len(fixes), "other": len(other)}


class EnvDriftDetector(Workflow):
    """Detect configuration drift between environments."""
    name = "env_drift"
    display_name = "Environment Drift Detector"
    description = "Compare configuration across environments and detect drift"
    category = "developer"
    schedule_cron = "0 10 * * 1"

    def run(self) -> Dict:
        # Compare config keys that should be consistent
        db = self._db()
        config_keys = []
        try:
            rows = db.execute("SELECT key, value, updated FROM config ORDER BY key").fetchall()
            config_keys = [dict(r) for r in rows]
        except Exception:
            pass

        report = f"# Config Snapshot — {datetime.now().strftime('%Y-%m-%d')}\n\n"
        report += f"**{len(config_keys)} configuration keys**\n\n"

        for ck in config_keys:
            val = ck["value"]
            if any(s in ck["key"].lower() for s in ("key", "secret", "password", "token")):
                val = "[REDACTED]"
            elif len(val) > 50:
                val = val[:50] + "..."
            report += f"- `{ck['key']}` = {val} (updated: {ck.get('updated', '?')[:10]})\n"

        self.store_memory(
            f"config_snapshot_{datetime.now().strftime('%Y%m%d')}",
            report, "reference", "config,snapshot,drift,auto", 0.4
        )
        return {"status": "ok", "config_keys": len(config_keys)}


class SecurityAdvisoryMonitor(Workflow):
    """Monitor security advisories for relevant technologies.

    Config keys:
        security_tech_stack: comma-separated technologies to monitor
    """
    name = "security_advisories"
    display_name = "Security Advisory Monitor"
    description = "Monitor for security advisories affecting your tech stack"
    category = "developer"
    schedule_cron = "0 9 * * *"

    def run(self) -> Dict:
        tech_stack = self.get_config("security_tech_stack",
            "python,flask,sqlite,fastapi,react").split(",")
        tech_stack = [t.strip().lower() for t in tech_stack if t.strip()]

        # Search GitHub Advisory Database (public API)
        advisories = []
        for tech in tech_stack[:5]:
            url = f"https://api.github.com/advisories?ecosystem=pip&severity=high,critical&per_page=3"
            raw = self.http_get(url)
            if raw:
                try:
                    data = json.loads(raw)
                    for adv in data[:3]:
                        pkg_name = ""
                        vulns = adv.get("vulnerabilities", [])
                        if vulns:
                            pkg_name = vulns[0].get("package", {}).get("name", "")
                        if tech in (pkg_name or "").lower() or tech in adv.get("summary", "").lower():
                            advisories.append({
                                "id": adv.get("ghsa_id", ""),
                                "severity": adv.get("severity", ""),
                                "summary": adv.get("summary", "")[:100],
                                "package": pkg_name,
                                "published": adv.get("published_at", "")[:10],
                            })
                except json.JSONDecodeError:
                    pass

        if advisories:
            report = f"# Security Advisories — {datetime.now().strftime('%Y-%m-%d')}\n\n"
            for adv in advisories:
                report += f"- **{adv['severity'].upper()}** [{adv['id']}] {adv['package']}: {adv['summary']}\n"

            self.store_memory(
                f"security_advisories_{datetime.now().strftime('%Y%m%d')}",
                report, "reference", "security,advisories,critical,auto", 0.8
            )

        return {"status": "ok", "tech_stack": len(tech_stack), "advisories": len(advisories)}


# =========================================================================
# WORKFLOW REGISTRY
# =========================================================================

WORKFLOW_REGISTRY: Dict[str, type] = {
    # Productivity
    "daily_planner": DailyPlanner,
    "habit_tracker": HabitTracker,
    "expense_tracker": ExpenseTracker,
    "bookmark_organizer": BookmarkOrganizer,
    "file_declutter": FileDeclutter,
    "reading_list": ReadingListManager,
    "note_taker": NoteTaker,
    "time_tracker": TimeTracker,
    "goal_tracker": GoalTracker,
    "weekly_review": WeeklyReview,
    # Research
    "rss_digest": RSSDigest,
    "arxiv_tracker": ArxivTracker,
    "hn_reddit_monitor": HNRedditMonitor,
    "news_summarizer": NewsSummarizer,
    "competitor_tracker": CompetitorTracker,
    "price_watcher": PriceWatcher,
    "weather_briefing": WeatherBriefing,
    "stock_watchlist": StockWatchlist,
    "doc_monitor": DocMonitor,
    "podcast_summarizer": PodcastSummarizer,
    # Communication
    "email_triage": EmailTriage,
    "email_auto_reply": EmailAutoReply,
    "follow_up_reminder": FollowUpReminder,
    "meeting_notes": MeetingNotesExtractor,
    "contact_enricher": ContactEnricher,
    "newsletter_digest": NewsletterDigest,
    "social_scheduler": SocialMediaScheduler,
    "cold_outreach": ColdOutreachTracker,
    "thank_you": ThankYouAutomator,
    "networking_crm": NetworkingCRM,
    # Developer
    "github_digest": GitHubDigest,
    "dependency_auditor": DependencyAuditor,
    "uptime_monitor": UptimeMonitor,
    "log_analyzer": LogAnalyzer,
    "api_health": APIHealthChecker,
    "db_backup": DatabaseBackupReminder,
    "code_review_prep": CodeReviewPrep,
    "changelog_gen": ChangelogGenerator,
    "env_drift": EnvDriftDetector,
    "security_advisories": SecurityAdvisoryMonitor,
}


def seed_workflows(db_path: str):
    """Register all workflows in the aibrain database. Called by `aibrain init`."""
    conn = sqlite3.connect(db_path, check_same_thread=False)
    conn.row_factory = sqlite3.Row

    count = 0
    for name, cls in WORKFLOW_REGISTRY.items():
        try:
            conn.execute("""
                INSERT OR REPLACE INTO workflows
                (name, display_name, category, description, cron_schedule, enabled, source)
                VALUES (?, ?, ?, ?, ?, 0, 'builtin')
            """, (cls.name, cls.display_name, cls.category, cls.description, cls.schedule_cron))
            count += 1
        except Exception as e:
            log.error("Failed to seed workflow %s: %s", name, e)

    conn.commit()
    conn.close()
    return count


def run_workflow(name: str, db_path: str, config: Dict = None) -> Dict:
    """Run a workflow by name."""
    cls = WORKFLOW_REGISTRY.get(name)
    if not cls:
        return {"status": "error", "message": f"Unknown workflow: {name}"}

    wf = cls(db_path, config or {})
    try:
        return wf.run()
    except Exception as e:
        log.error("Workflow %s failed: %s", name, e)
        return {"status": "error", "message": str(e)}


if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print(f"Available workflows ({len(WORKFLOW_REGISTRY)}):")
        for name, cls in sorted(WORKFLOW_REGISTRY.items()):
            print(f"  {name:25s} — {cls.description}")
        print(f"\nUsage: python aibrain_workflows.py <workflow_name> [--db path]")
    else:
        wf_name = sys.argv[1]
        db = sys.argv[3] if "--db" in sys.argv else str(Path.home() / "aibrain" / "aibrain.db")
        result = run_workflow(wf_name, db)
        print(json.dumps(result, indent=2))
