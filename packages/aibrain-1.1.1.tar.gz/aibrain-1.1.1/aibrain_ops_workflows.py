#!/usr/bin/env python3
"""
aibrain_ops_workflows.py — Operations & Multi-Agent workflows for aibrain Pro

25 reusable operational workflows covering multi-agent coordination,
infrastructure monitoring, business tracking, and security operations.
All workflows are generic — no hardcoded paths, IPs, or personal data.
Configuration via self.cfg() with sensible defaults.

Seeded via: seed_ops_workflows(db_path)
"""

import json
import logging
import os
import re
import sqlite3
import time
import urllib.request
import urllib.error
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional

log = logging.getLogger("aibrain.ops")


class OpsWorkflow:
    """Base class for all aibrain Pro operational workflows."""
    name = "base"
    display_name = "Base"
    description = ""
    category = "ops"
    schedule_cron = "0 9 * * *"

    def __init__(self, db_path: str, config: Dict = None):
        self.db_path = db_path
        self.config = config or {}
        self._conn = None

    def _db(self):
        if self._conn is None:
            self._conn = sqlite3.connect(self.db_path, check_same_thread=False)
            self._conn.row_factory = sqlite3.Row
        return self._conn

    def store(self, name, content, mem_type="reference", tags="", importance=0.5):
        db = self._db()
        try:
            existing = db.execute("SELECT id FROM memories WHERE name=? AND active=1", (name,)).fetchone()
            if existing:
                db.execute("UPDATE memories SET content=?, tags=?, importance=?, updated=datetime('now') WHERE id=?",
                           (content, tags, importance, existing[0]))
            else:
                db.execute("INSERT INTO memories (name, type, tags, content, importance, created, updated, active) "
                           "VALUES (?, ?, ?, ?, ?, datetime('now'), datetime('now'), 1)",
                           (name, mem_type, tags, content, importance))
            db.commit()
        except Exception as e:
            log.error("[%s] store: %s", self.name, e)

    def search(self, query, limit=10):
        db = self._db()
        try:
            rows = db.execute("SELECT name, content, tags, created, updated FROM memories "
                              "WHERE active=1 AND content LIKE ? ORDER BY updated DESC LIMIT ?",
                              (f"%{query}%", limit)).fetchall()
            return [dict(r) for r in rows]
        except Exception:
            return []

    def cfg(self, key, default=None):
        return self.config.get(key, default)

    def http_get(self, url, timeout=15):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "aibrain-ops/0.9"})
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return resp.read().decode("utf-8", errors="replace")
        except Exception:
            return None

    def run(self) -> Dict:
        return {"status": "not_implemented"}

    @property
    def schedule(self):
        return self.schedule_cron


# =========================================================================
# MULTI-AGENT (7)
# =========================================================================

class BrainSyncChecker(OpsWorkflow):
    """Verify two or more agent brain databases are consistent."""
    name = "brain_sync_checker"
    display_name = "Brain Sync Checker"
    description = "Verify two or more agent brain databases are consistent"
    category = "multi_agent"
    schedule_cron = "0 */4 * * *"

    def run(self) -> Dict:
        raw_paths = self.cfg("brain_paths", "")
        if not raw_paths:
            return {"status": "ok", "message": "No brain_paths configured (comma-separated DB paths)"}

        paths = [p.strip() for p in raw_paths.split(",") if p.strip()]
        if len(paths) < 2:
            return {"status": "ok", "message": "Need at least 2 brain_paths to compare"}

        report = f"# Brain Sync -- {datetime.now().strftime('%Y-%m-%d %H:%M')}\n\n"
        stats = {}

        for i, path in enumerate(paths):
            label = f"Brain {i+1}"
            p = Path(path)
            if p.exists():
                try:
                    conn = sqlite3.connect(path)
                    row = conn.execute("SELECT COUNT(*) as c FROM memories WHERE active=1").fetchone()
                    stats[label] = {"memories": row[0] if row else 0, "size_kb": round(p.stat().st_size / 1024),
                                    "modified": datetime.fromtimestamp(p.stat().st_mtime).strftime("%Y-%m-%d %H:%M"),
                                    "path": path}
                    conn.close()
                except Exception as e:
                    stats[label] = {"error": str(e)}
            else:
                stats[label] = {"error": f"DB not found at {path}"}

        for label, data in stats.items():
            if "error" in data:
                report += f"[FAIL] {label}: {data['error']}\n"
            else:
                report += f"[OK] {label}: {data['memories']} memories, {data['size_kb']}KB, modified {data['modified']}\n"

        # Compare all pairs for sync gaps
        valid = {k: v for k, v in stats.items() if "memories" in v}
        labels = list(valid.keys())
        for i in range(len(labels)):
            for j in range(i + 1, len(labels)):
                a, b = labels[i], labels[j]
                delta = abs(valid[a]["memories"] - valid[b]["memories"])
                if delta > 50:
                    report += f"\n[!] Sync gap between {a} and {b}: {delta} memories difference\n"

        self.store(f"brain_sync_{datetime.now().strftime('%Y%m%d_%H%M')}",
                   report, "reference", "brain_sync,ops,auto", 0.6 if "[!]" in report else 0.3)
        return {"status": "ok", "brains": stats}


class TaskHandoffMonitor(OpsWorkflow):
    """Find tasks assigned to agents that have stalled."""
    name = "task_handoff_monitor"
    display_name = "Task Handoff Monitor"
    description = "Find tasks assigned to agents that have stalled -- needs handoff or intervention"
    category = "multi_agent"
    schedule_cron = "0 9 * * *"

    def run(self) -> Dict:
        tasks = self.search("task", limit=30)
        tasks += self.search("assigned", limit=20)

        stalled = []
        for t in tasks:
            last = t.get("updated", t.get("created", ""))[:10]
            try:
                days = (datetime.now() - datetime.strptime(last, "%Y-%m-%d")).days
                if days >= 3 and "completed" not in t.get("tags", ""):
                    # Detect agent name from tags generically
                    agent = "unknown"
                    tags_str = t.get("tags", "").lower()
                    content_str = t.get("content", "").lower()
                    for tag_word in tags_str.split(","):
                        tag_word = tag_word.strip()
                        if tag_word and tag_word not in ("task", "assigned", "auto", "ops"):
                            agent = tag_word
                            break
                    stalled.append({"name": t["name"], "agent": agent, "days": days,
                                   "preview": t["content"][:80]})
            except ValueError:
                pass

        if stalled:
            report = f"# Stalled Tasks -- {datetime.now().strftime('%Y-%m-%d')}\n\n"
            for s in sorted(stalled, key=lambda x: x["days"], reverse=True):
                report += f"- [!] {s['name']} ({s['agent']}, {s['days']}d stalled): {s['preview']}\n"
            self.store(f"stalled_tasks_{datetime.now().strftime('%Y%m%d')}",
                       report, "reference", "tasks,stalled,handoff,auto", 0.7)

        return {"status": "ok", "stalled": len(stalled)}


class AgentInfrastructureMonitor(OpsWorkflow):
    """Check remote agent service endpoints for health and availability."""
    name = "agent_infra_monitor"
    display_name = "Agent Infrastructure Monitor"
    description = "Check remote agent service endpoints for health and availability"
    category = "multi_agent"
    schedule_cron = "*/30 * * * *"

    def run(self) -> Dict:
        raw_endpoints = self.cfg("service_endpoints", "")
        if not raw_endpoints:
            return {"status": "ok", "message": "No service_endpoints configured (JSON dict of name->URL)"}

        try:
            services = json.loads(raw_endpoints) if isinstance(raw_endpoints, str) else raw_endpoints
        except json.JSONDecodeError:
            return {"status": "error", "message": "service_endpoints is not valid JSON"}

        results = {}
        for svc_name, url in services.items():
            start = time.time()
            try:
                req = urllib.request.Request(url)
                with urllib.request.urlopen(req, timeout=10) as resp:
                    results[svc_name] = {"status": resp.status, "ms": round((time.time()-start)*1000), "ok": True}
            except Exception as e:
                results[svc_name] = {"status": str(e)[:60], "ms": 0, "ok": False}

        down = {k: v for k, v in results.items() if not v["ok"]}
        if down:
            alert = f"SERVICE DOWN -- {datetime.now().strftime('%H:%M')}\n"
            for svc_name, data in down.items():
                alert += f"- {svc_name}: {data['status']}\n"
            self.store(f"infra_alert_{datetime.now().strftime('%Y%m%d_%H%M')}",
                       alert, "reference", "infrastructure,alert,critical,auto", 0.9)

        return {"status": "ok", "services": results, "down": len(down)}


class AgentEvolutionTracker(OpsWorkflow):
    """Track how agent capabilities evolve across weeks based on skill episodes."""
    name = "agent_evolution_tracker"
    display_name = "Agent Evolution Tracker"
    description = "Track how agent capabilities evolve across weeks based on skill episodes"
    category = "multi_agent"
    schedule_cron = "0 22 * * 0"

    def run(self) -> Dict:
        db = self._db()
        report = f"# Agent Evolution -- {datetime.now().strftime('%Y-%m-%d')}\n\n"

        try:
            rows = db.execute(
                "SELECT strftime('%Y-W%W', created_at) as week, task_type, "
                "COUNT(*) as episodes, AVG(outcome_quality) as avg "
                "FROM skill_episodes GROUP BY week, task_type ORDER BY week DESC LIMIT 50"
            ).fetchall()

            weekly = defaultdict(list)
            for r in rows:
                weekly[r["week"]].append({"task": r["task_type"], "episodes": r["episodes"],
                                          "avg": round(r["avg"], 2)})

            for week, tasks in list(weekly.items())[:4]:
                report += f"## {week}\n"
                for t in sorted(tasks, key=lambda x: x["avg"], reverse=True)[:5]:
                    report += f"- {t['task']}: {t['avg']:.0%} ({t['episodes']} episodes)\n"
                report += "\n"
        except Exception:
            report += "No evolution data yet.\n"

        self.store(f"evolution_{datetime.now().strftime('%Y_W%W')}",
                   report, "reference", "evolution,agents,auto", 0.5)
        return {"status": "ok"}


class BrainDiff(OpsWorkflow):
    """Compare memory contents between any two agent brains."""
    name = "brain_diff"
    display_name = "Brain Diff"
    description = "Compare memory contents between any two agent brains -- find knowledge gaps"
    category = "multi_agent"
    schedule_cron = "0 22 * * 0"

    def run(self) -> Dict:
        brain_a_path = self.cfg("brain_a_path", "")
        brain_b_path = self.cfg("brain_b_path", "")
        brain_a_label = self.cfg("brain_a_label", "Brain A")
        brain_b_label = self.cfg("brain_b_label", "Brain B")

        if not brain_a_path or not brain_b_path:
            return {"status": "ok", "message": "Configure brain_a_path and brain_b_path to compare"}

        def get_names(path):
            try:
                conn = sqlite3.connect(path)
                rows = conn.execute("SELECT name FROM memories WHERE active=1").fetchall()
                conn.close()
                return {r[0] for r in rows}
            except Exception:
                return set()

        a_names = get_names(brain_a_path)
        b_names = get_names(brain_b_path)

        a_only = a_names - b_names
        b_only = b_names - a_names

        report = f"# Brain Diff -- {datetime.now().strftime('%Y-%m-%d')}\n\n"
        report += f"{brain_a_label}: {len(a_names)} | {brain_b_label}: {len(b_names)} | Shared: {len(a_names & b_names)}\n\n"

        if a_only:
            report += f"## {brain_a_label} Only ({len(a_only)})\n"
            for n in list(a_only)[:15]:
                report += f"- {n}\n"
        if b_only:
            report += f"\n## {brain_b_label} Only ({len(b_only)})\n"
            for n in list(b_only)[:15]:
                report += f"- {n}\n"

        self.store(f"brain_diff_{datetime.now().strftime('%Y%m%d')}",
                   report, "reference", "brain_diff,agents,auto", 0.5)
        return {"status": "ok", "a_only": len(a_only), "b_only": len(b_only)}


class MessageChannelDigest(OpsWorkflow):
    """Summarize messages from a Telegram bot API channel since last check."""
    name = "message_digest"
    display_name = "Message Channel Digest"
    description = "Summarize messages from a Telegram bot API channel since last check"
    category = "multi_agent"
    schedule_cron = "0 */2 * * *"

    def run(self) -> Dict:
        bot_token = self.cfg("bot_token", "")
        if not bot_token:
            return {"status": "ok", "message": "No bot_token configured"}

        url = f"https://api.telegram.org/bot{bot_token}/getUpdates?offset=-20"
        raw = self.http_get(url)
        if not raw:
            return {"status": "error", "message": "Telegram API failed"}

        try:
            data = json.loads(raw)
            messages = []
            for update in data.get("result", []):
                msg = update.get("message", {})
                text = msg.get("text", "")
                sender = msg.get("from", {}).get("first_name", "Unknown")
                date = datetime.fromtimestamp(msg.get("date", 0)).strftime("%H:%M") if msg.get("date") else ""
                if text:
                    messages.append(f"[{date}] {sender}: {text[:100]}")

            if messages:
                digest = f"# Message Digest -- {datetime.now().strftime('%Y-%m-%d %H:%M')}\n\n"
                for m in messages[-20:]:
                    digest += f"- {m}\n"
                self.store(f"msg_digest_{datetime.now().strftime('%Y%m%d_%H%M')}",
                           digest, "reference", "messages,digest,auto", 0.4)

            return {"status": "ok", "messages": len(messages)}
        except json.JSONDecodeError:
            return {"status": "error", "message": "Parse failed"}


class CapabilityMatrix(OpsWorkflow):
    """Map capabilities across all agents in your fleet."""
    name = "capability_matrix"
    display_name = "Capability Matrix"
    description = "Map capabilities across all agents in your fleet -- find coverage gaps"
    category = "multi_agent"
    schedule_cron = "0 10 * * 1"

    def run(self) -> Dict:
        raw_agents = self.cfg("agents", "")

        if raw_agents:
            try:
                agents = json.loads(raw_agents) if isinstance(raw_agents, str) else raw_agents
            except json.JSONDecodeError:
                agents = []
        else:
            agents = []

        report = f"# Capability Matrix -- {datetime.now().strftime('%Y-%m-%d')}\n\n"

        if agents:
            for agent in agents:
                name = agent.get("name", "Unknown")
                report += f"## {name}\n"
                for k in ("os", "role", "tools"):
                    if k in agent:
                        report += f"- **{k}**: {agent[k]}\n"
                report += "\n"
        else:
            # Generate from brain data
            db = self._db()
            try:
                rows = db.execute(
                    "SELECT DISTINCT task_type FROM skill_episodes ORDER BY task_type"
                ).fetchall()
                if rows:
                    report += "## Capabilities (from skill episodes)\n"
                    for r in rows:
                        report += f"- {r['task_type']}\n"
                else:
                    report += "No agents configured and no skill episode data found.\n"
                    report += "Set config key 'agents' (JSON list of dicts with name, os, role, tools).\n"
            except Exception:
                report += "No agents configured. Set config key 'agents' (JSON list).\n"

        report += "\n## Coverage Gaps\n"
        report += "- [ ] Review agent capabilities for overlap\n"
        report += "- [ ] Identify tasks with no assigned agent\n"
        report += "- [ ] Check for single points of failure\n"

        self.store("capability_matrix", report, "reference",
                   "agents,capabilities,matrix,auto", 0.5)
        return {"status": "ok"}


# =========================================================================
# OPS (18)
# =========================================================================

class SessionHandover(OpsWorkflow):
    """Generate session handover document with decisions, changes, and open items."""
    name = "session_handover"
    display_name = "Session Handover"
    description = "Generate session handover document with decisions, changes, and open items"
    category = "ops"
    schedule_cron = "0 23 * * *"

    def run(self) -> Dict:
        db = self._db()
        today = datetime.now().strftime("%Y-%m-%d")

        todays = []
        try:
            rows = db.execute(
                "SELECT name, content, tags FROM memories WHERE active=1 "
                "AND created >= ? ORDER BY created DESC LIMIT 30", (today,)
            ).fetchall()
            todays = [dict(r) for r in rows]
        except Exception:
            pass

        decisions = [m for m in todays if "decision" in m.get("tags", "")]
        changes = [m for m in todays if any(t in m.get("tags", "") for t in ("change", "fix", "feat"))]
        open_items = [m for m in todays if any(t in m.get("tags", "") for t in ("todo", "blocked", "follow_up"))]

        handover = f"# Session Handover -- {today}\n\n"
        handover += f"**Memories created today:** {len(todays)}\n\n"

        if decisions:
            handover += "## Decisions Made\n"
            for d in decisions:
                handover += f"- {d['content'][:100]}\n"

        if changes:
            handover += "\n## Changes Made\n"
            for c in changes:
                handover += f"- {c['content'][:100]}\n"

        if open_items:
            handover += "\n## Open Items (carry forward)\n"
            for o in open_items:
                handover += f"- [ ] {o['content'][:100]}\n"

        handover += "\n## For Next Session\n"
        handover += "- Review open items above\n"
        handover += "- Review any overnight alerts\n"

        self.store(f"handover_{today}", handover, "project",
                   "handover,session,continuity,auto", 0.8)
        return {"status": "ok", "decisions": len(decisions), "changes": len(changes),
                "open": len(open_items)}


class MemoryContinuityChecker(OpsWorkflow):
    """Verify critical memories survived context compaction or session restart."""
    name = "memory_continuity"
    display_name = "Memory Continuity Checker"
    description = "Verify critical memories survived context compaction or session restart"
    category = "ops"
    schedule_cron = "0 * * * *"

    def run(self) -> Dict:
        db = self._db()
        raw_keys = self.cfg("critical_memories", "self_model,session_briefing,life_dashboard")
        critical_keys = [k.strip() for k in raw_keys.split(",") if k.strip()]

        missing = []
        for key in critical_keys:
            try:
                row = db.execute("SELECT id FROM memories WHERE name=? AND active=1", (key,)).fetchone()
                if not row:
                    missing.append(key)
            except Exception:
                missing.append(key)

        if missing:
            alert = f"[!] Critical memories missing after compaction: {', '.join(missing)}\n"
            alert += "Run affected workflows to regenerate."
            self.store(f"continuity_alert_{datetime.now().strftime('%Y%m%d_%H%M')}",
                       alert, "reference", "continuity,alert,auto", 0.9)

        return {"status": "ok", "missing": missing}


class WorkflowHealthMonitor(OpsWorkflow):
    """Monitor scheduled workflow execution -- find stale or failing jobs."""
    name = "workflow_health"
    display_name = "Workflow Health Monitor"
    description = "Monitor scheduled workflow execution -- find stale or failing jobs"
    category = "ops"
    schedule_cron = "0 9 * * *"

    def run(self) -> Dict:
        db = self._db()
        stale = []
        try:
            rows = db.execute(
                "SELECT name, cron_schedule, enabled FROM workflows WHERE enabled=1"
            ).fetchall()
            for r in rows:
                last = db.execute(
                    "SELECT MAX(created) as last FROM memories WHERE name LIKE ? AND tags LIKE '%auto%'",
                    (f"%{r['name']}%",)
                ).fetchone()
                if last and last["last"]:
                    try:
                        days = (datetime.now() - datetime.strptime(last["last"][:10], "%Y-%m-%d")).days
                        if days >= 7:
                            stale.append({"name": r["name"], "days_since": days})
                    except ValueError:
                        pass
                else:
                    stale.append({"name": r["name"], "days_since": 999})
        except Exception:
            pass

        if stale:
            report = f"# Stale Workflows -- {datetime.now().strftime('%Y-%m-%d')}\n\n"
            for s in sorted(stale, key=lambda x: x["days_since"], reverse=True)[:15]:
                days = s["days_since"]
                status = "never ran" if days > 100 else f"{days}d since last run"
                report += f"- **{s['name']}**: {status}\n"
            self.store(f"workflow_health_{datetime.now().strftime('%Y%m%d')}",
                       report, "reference", "workflow,health,ops,auto", 0.6)

        return {"status": "ok", "stale_jobs": len(stale)}


class CredentialRotationReminder(OpsWorkflow):
    """Remind when stored credentials are old enough to rotate."""
    name = "credential_rotation"
    display_name = "Credential Rotation Reminder"
    description = "Remind when stored credentials are old enough to rotate"
    category = "security"
    schedule_cron = "0 9 * * 1"

    def run(self) -> Dict:
        creds = self.search("credential", limit=20)
        creds += self.search("password", limit=10)

        old_creds = []
        for c in creds:
            last = c.get("updated", c.get("created", ""))[:10]
            try:
                days = (datetime.now() - datetime.strptime(last, "%Y-%m-%d")).days
                if days >= 90:
                    old_creds.append({"name": c["name"], "days": days})
            except ValueError:
                pass

        if old_creds:
            report = f"# Credential Rotation -- {datetime.now().strftime('%Y-%m-%d')}\n\n"
            for c in old_creds:
                report += f"- [!] **{c['name']}**: {c['days']} days old\n"
            self.store(f"cred_rotation_{datetime.now().strftime('%Y%m%d')}",
                       report, "reference", "credentials,rotation,security,auto", 0.7)

        return {"status": "ok", "old_credentials": len(old_creds)}


class FixSuccessTracker(OpsWorkflow):
    """Track which fixes and remediations work."""
    name = "fix_success_tracker"
    display_name = "Fix Success Tracker"
    description = "Track which fixes and remediations work -- build a success rate database"
    category = "ops"
    schedule_cron = "0 10 * * 1"

    def run(self) -> Dict:
        db = self._db()
        remediation_episodes = []
        try:
            rows = db.execute(
                "SELECT task_type, AVG(outcome_quality) as avg, COUNT(*) as episodes "
                "FROM skill_episodes WHERE task_type LIKE 'remediate_%' "
                "GROUP BY task_type ORDER BY avg DESC"
            ).fetchall()
            remediation_episodes = [dict(r) for r in rows]
        except Exception:
            pass

        report = f"# Fix Success Rates -- {datetime.now().strftime('%Y-%m-%d')}\n\n"
        if remediation_episodes:
            for r in remediation_episodes:
                report += f"- **{r['task_type']}**: {r['avg']:.0%} success ({r['episodes']} attempts)\n"
        else:
            report += "No remediation data yet. Run fix/remediate tasks with aibrain integration.\n"

        self.store(f"fix_success_{datetime.now().strftime('%Y%m%d')}",
                   report, "reference", "fix,success,tracking,auto", 0.6)
        return {"status": "ok", "categories": len(remediation_episodes)}


class ComplianceGapReporter(OpsWorkflow):
    """Identify compliance frameworks with unresolved findings."""
    name = "compliance_gap_reporter"
    display_name = "Compliance Gap Reporter"
    description = "Identify compliance frameworks with unresolved findings"
    category = "security"
    schedule_cron = "0 10 * * 1"

    def run(self) -> Dict:
        findings = self.search("compliance", limit=30)
        report = f"# Compliance Gaps -- {datetime.now().strftime('%Y-%m-%d')}\n\n"
        report += "## Frameworks to Check\n"
        frameworks = ["OWASP Top 10", "PCI-DSS 4.0", "NIST 800-53", "Essential Eight",
                     "ISO 27001", "SOC 2", "CWE Top 25"]
        for fw in frameworks:
            relevant = [f for f in findings if fw.lower().replace(" ", "") in f.get("content", "").lower().replace(" ", "")]
            status = f"{len(relevant)} findings" if relevant else "No data"
            report += f"- **{fw}**: {status}\n"

        self.store(f"compliance_gaps_{datetime.now().strftime('%Y%m%d')}",
                   report, "reference", "compliance,gaps,auto", 0.6)
        return {"status": "ok"}


class BudgetBalanceMonitor(OpsWorkflow):
    """Alert when a tracked budget or balance drops below a configured threshold."""
    name = "budget_monitor"
    display_name = "Budget Balance Monitor"
    description = "Alert when a tracked budget or balance drops below a configured threshold"
    category = "finance"
    schedule_cron = "0 */4 * * *"

    def run(self) -> Dict:
        threshold = float(self.cfg("balance_threshold", "100"))
        search_term = self.cfg("balance_search_term", "balance")
        records = self.search(search_term, limit=5)
        current = 0
        if records:
            match = re.search(r'[\$]?([\d.]+)', records[0].get("content", ""))
            if match:
                current = float(match.group(1))

        if current > 0 and current < threshold:
            alert = f"BALANCE ALERT: ${current:.2f} below ${threshold:.2f} threshold"
            self.store(f"balance_alert_{datetime.now().strftime('%Y%m%d')}",
                       alert, "reference", "balance,alert,auto", 0.9)

        return {"status": "ok", "current": current, "threshold": threshold}


class ConcentrationAlert(OpsWorkflow):
    """Alert when too many items are concentrated in one category or sector."""
    name = "concentration_alert"
    display_name = "Concentration Alert"
    description = "Alert when too many items are concentrated in one category or sector"
    category = "finance"
    schedule_cron = "0 */2 * * 1-5"

    def run(self) -> Dict:
        items = self.search("position", limit=30)
        items += self.search("allocation", limit=20)
        categories = Counter()
        for item in items:
            # Extract uppercase identifiers as category proxies
            match = re.search(r'\b([A-Z]{1,5})\b', item.get("content", ""))
            if match:
                categories[match.group(1)] += 1

        concentrated = {t: c for t, c in categories.items() if c >= 3}
        if concentrated:
            alert = f"[!] Concentration detected: {', '.join(f'{t}={c}' for t, c in concentrated.items())}"
            self.store(f"concentration_{datetime.now().strftime('%Y%m%d_%H%M')}",
                       alert, "reference", "concentration,alert,auto", 0.7)

        return {"status": "ok", "concentrated": concentrated}


class ActivityJournal(OpsWorkflow):
    """Weekly summary of tracked activities with outcomes, lessons, and patterns."""
    name = "activity_journal"
    display_name = "Activity Journal"
    description = "Weekly summary of tracked activities with outcomes, lessons, and patterns"
    category = "ops"
    schedule_cron = "0 18 * * 5"

    def run(self) -> Dict:
        activities = self.search("activity", limit=30)
        lessons = self.search("lesson", limit=10)

        journal = f"# Activity Journal -- {datetime.now().strftime('%Y-%m-%d')}\n\n"
        journal += f"**Activities this period:** {len(activities)}\n\n"

        if activities:
            journal += "## Recent Activities\n"
            for a in activities[:15]:
                journal += f"- {a['content'][:100]}\n"

        if lessons:
            journal += "\n## Lessons Learned\n"
            for l in lessons[:5]:
                journal += f"- {l['content'][:100]}\n"

        self.store(f"activity_journal_{datetime.now().strftime('%Y_W%W')}",
                   journal, "reference", "activity,journal,weekly,auto", 0.5)
        return {"status": "ok", "activities": len(activities)}


class PackageDownloadTracker(OpsWorkflow):
    """Track PyPI package install counts over time."""
    name = "package_downloads"
    display_name = "Package Download Tracker"
    description = "Track PyPI package install counts over time"
    category = "business"
    schedule_cron = "0 9 * * *"

    def run(self) -> Dict:
        packages = self.cfg("packages", "aibrain").split(",")
        results = {}
        for pkg in packages:
            url = f"https://pypistats.org/api/packages/{pkg.strip()}/recent"
            raw = self.http_get(url)
            if raw:
                try:
                    data = json.loads(raw)
                    results[pkg.strip()] = data.get("data", {})
                except json.JSONDecodeError:
                    pass

        report = f"# Package Downloads -- {datetime.now().strftime('%Y-%m-%d')}\n\n"
        for pkg, data in results.items():
            last_day = data.get("last_day", 0)
            last_week = data.get("last_week", 0)
            last_month = data.get("last_month", 0)
            report += f"**{pkg}**: {last_day}/day | {last_week}/week | {last_month}/month\n"

        self.store(f"pkg_downloads_{datetime.now().strftime('%Y%m%d')}", report, "reference",
                   "packages,downloads,metrics,auto", 0.5)
        return {"status": "ok", "packages": results}


class RepoActivityTracker(OpsWorkflow):
    """Track stars, forks, and issues across GitHub repositories."""
    name = "repo_activity"
    display_name = "Repo Activity Tracker"
    description = "Track stars, forks, and issues across GitHub repositories"
    category = "business"
    schedule_cron = "0 9 * * *"

    def run(self) -> Dict:
        user = self.cfg("github_user", "")
        if not user:
            return {"status": "ok", "message": "No github_user configured"}

        # Try /users/ endpoint (works for both users and orgs with public repos)
        url = f"https://api.github.com/users/{user}/repos?per_page=30"
        raw = self.http_get(url)

        repos = []
        if raw:
            try:
                data = json.loads(raw)
                if isinstance(data, list):
                    for repo in data:
                        repos.append({
                            "name": repo["name"], "stars": repo.get("stargazers_count", 0),
                            "forks": repo.get("forks_count", 0), "issues": repo.get("open_issues_count", 0),
                        })
            except json.JSONDecodeError:
                pass

        report = f"# Repo Activity -- {datetime.now().strftime('%Y-%m-%d')}\n\n"
        total_stars = sum(r["stars"] for r in repos)
        report += f"**Total stars:** {total_stars}\n\n"
        for r in sorted(repos, key=lambda x: x["stars"], reverse=True):
            report += f"- **{r['name']}**: stars={r['stars']} forks={r['forks']} issues={r['issues']}\n"

        self.store(f"repo_activity_{datetime.now().strftime('%Y%m%d')}", report, "reference",
                   "github,metrics,auto", 0.5)
        return {"status": "ok", "repos": len(repos), "total_stars": total_stars}


class DomainHealthMonitor(OpsWorkflow):
    """Verify DNS resolution for configured domains."""
    name = "domain_health"
    display_name = "Domain Health Monitor"
    description = "Verify DNS resolution for configured domains"
    category = "business"
    schedule_cron = "0 9 * * *"

    def run(self) -> Dict:
        raw_domains = self.cfg("domains", "")
        if not raw_domains:
            return {"status": "ok", "message": "No domains configured (comma-separated)"}

        import socket

        domains = [d.strip() for d in raw_domains.split(",") if d.strip()]
        results = {}
        for domain in domains:
            try:
                ip = socket.gethostbyname(domain)
                results[domain] = {"ip": ip, "ok": True}
            except socket.gaierror:
                results[domain] = {"ip": None, "ok": False}

        down = {d: v for d, v in results.items() if not v["ok"]}
        if down:
            alert = f"DNS FAILURE: {', '.join(down.keys())}"
            self.store(f"dns_alert_{datetime.now().strftime('%Y%m%d')}",
                       alert, "reference", "dns,alert,critical,auto", 0.9)

        return {"status": "ok", "domains": results, "down": len(down)}


class ContentCalendar(OpsWorkflow):
    """Flag which posts or tasks are due today from your content plan."""
    name = "content_calendar"
    display_name = "Content Calendar"
    description = "Flag which posts or tasks are due today from your content plan"
    category = "business"
    schedule_cron = "0 7 * * *"

    def run(self) -> Dict:
        today = datetime.now().strftime("%Y-%m-%d")
        day_of_week = datetime.now().strftime("%A")

        content = self.search(today, limit=10)
        content += self.search(day_of_week, limit=5)
        content += self.search("content calendar", limit=5)

        report = f"# Content Due -- {today} ({day_of_week})\n\n"
        if content:
            for c in content:
                report += f"- {c['content'][:100]}\n"
        else:
            report += "No specific content scheduled for today.\n"

        self.store(f"content_due_{today}", report, "reference",
                   "content,calendar,daily,auto", 0.6)
        return {"status": "ok", "items_due": len(content)}


class RevenueTracker(OpsWorkflow):
    """Track revenue and MRR from configured payment sources."""
    name = "revenue_tracker"
    display_name = "Revenue Tracker"
    description = "Track revenue and MRR from configured payment sources"
    category = "business"
    schedule_cron = "0 9 * * 1"

    def run(self) -> Dict:
        revenue = self.search("revenue", limit=20)
        revenue += self.search("sale", limit=10)
        revenue += self.search("MRR", limit=5)

        report = f"# Revenue -- {datetime.now().strftime('%Y-%m-%d')}\n\n"
        if revenue:
            for r in revenue[:10]:
                report += f"- {r['content'][:100]}\n"
        else:
            report += "No revenue data. Store sales with tag 'revenue' or 'sale'.\n"

        # Use configurable targets if provided
        raw_targets = self.cfg("revenue_targets", "")
        if raw_targets:
            try:
                targets = json.loads(raw_targets) if isinstance(raw_targets, str) else raw_targets
                report += "\n## Targets\n"
                for label, amount in targets.items():
                    report += f"- {label}: ${amount}\n"
            except (json.JSONDecodeError, AttributeError):
                pass

        self.store(f"revenue_{datetime.now().strftime('%Y%m%d')}", report, "reference",
                   "revenue,mrr,business,auto", 0.6)
        return {"status": "ok"}


class OutreachTracker(OpsWorkflow):
    """Track outreach campaigns -- who was contacted and their responses."""
    name = "outreach_tracker"
    display_name = "Outreach Tracker"
    description = "Track outreach campaigns -- who was contacted and their responses"
    category = "business"
    schedule_cron = "0 9 * * *"

    def run(self) -> Dict:
        outreach = self.search("outreach", limit=30)
        outreach += self.search("contacted", limit=20)

        sent = [o for o in outreach if "sent" in o.get("tags", "")]
        responded = [o for o in outreach if "responded" in o.get("tags", "")]

        rate = (len(responded) / max(len(sent), 1)) * 100

        report = f"# Outreach -- {datetime.now().strftime('%Y-%m-%d')}\n\n"
        report += f"Sent: {len(sent)} | Responded: {len(responded)} | Rate: {rate:.0f}%\n\n"

        if sent:
            for s in sent[:10]:
                status = "[x] Responded" if s in responded else "[ ] Waiting"
                report += f"- {status} {s['name']}: {s['content'][:60]}\n"

        self.store(f"outreach_{datetime.now().strftime('%Y%m%d')}", report, "reference",
                   "outreach,tracking,auto", 0.5)
        return {"status": "ok", "sent": len(sent), "responded": len(responded)}


class LaunchReadinessChecklist(OpsWorkflow):
    """Master checklist for product launch -- track what's blocking ship."""
    name = "launch_readiness"
    display_name = "Launch Readiness Checklist"
    description = "Master checklist for product launch -- track what's blocking ship"
    category = "business"
    schedule_cron = "0 8 * * *"

    def run(self) -> Dict:
        report = f"# Launch Readiness -- {datetime.now().strftime('%Y-%m-%d')}\n\n"

        # Use configurable checklist if provided
        raw_checklist = self.cfg("launch_checklist", "")
        launch_date_str = self.cfg("launch_date", "")

        if raw_checklist:
            try:
                checklist = json.loads(raw_checklist) if isinstance(raw_checklist, str) else raw_checklist
                report += "## Checklist\n"
                for item in checklist:
                    report += f"- [ ] {item}\n"
            except (json.JSONDecodeError, TypeError):
                report += "## Checklist\n"
                report += "- [ ] (launch_checklist config is not valid JSON list)\n"
        else:
            report += "## Checklist\n"
            report += "Configure 'launch_checklist' (JSON list of strings) for your launch items.\n"

        if launch_date_str:
            try:
                launch_date = datetime.strptime(launch_date_str, "%Y-%m-%d")
                days_remaining = (launch_date - datetime.now()).days
                report += f"\n**Launch date: {launch_date_str}** | **Days remaining: {days_remaining}**\n"
            except ValueError:
                report += f"\n**Launch date: {launch_date_str}** (could not parse)\n"

        self.store("launch_readiness", report, "project",
                   "launch,readiness,checklist,auto", 0.8)
        return {"status": "ok"}


class JobApplicationTracker(OpsWorkflow):
    """Track job applications, responses, and interview dates."""
    name = "job_application_tracker"
    display_name = "Job Application Tracker"
    description = "Track job applications, responses, and interview dates"
    category = "business"
    schedule_cron = "0 9 * * *"

    def run(self) -> Dict:
        apps = self.search("application", limit=20)
        apps += self.search("interview", limit=10)
        apps += self.search("job", limit=10)

        report = f"# Job Applications -- {datetime.now().strftime('%Y-%m-%d')}\n\n"
        applied = [a for a in apps if "applied" in a.get("tags", "")]
        interviews = [a for a in apps if "interview" in a.get("tags", "")]

        report += f"Applied: {len(applied)} | Interviews: {len(interviews)}\n\n"
        for a in apps[:10]:
            report += f"- {a['name']}: {a['content'][:80]}\n"

        self.store(f"jobs_{datetime.now().strftime('%Y%m%d')}", report, "reference",
                   "jobs,applications,tracking,auto", 0.5)
        return {"status": "ok", "applied": len(applied), "interviews": len(interviews)}


class CompetitorMonitor(OpsWorkflow):
    """Track changes to competing products via GitHub API."""
    name = "competitor_monitor"
    display_name = "Competitor Monitor"
    description = "Track changes to competing products via GitHub API"
    category = "business"
    schedule_cron = "0 9 * * 1"

    def run(self) -> Dict:
        raw_repos = self.cfg("competitor_repos", "")
        if not raw_repos:
            return {"status": "ok", "message": "No competitor_repos configured (JSON dict of repo->name)"}

        try:
            competitors = json.loads(raw_repos) if isinstance(raw_repos, str) else raw_repos
        except json.JSONDecodeError:
            return {"status": "error", "message": "competitor_repos is not valid JSON"}

        results = []
        for repo, name in competitors.items():
            url = f"https://api.github.com/repos/{repo}"
            raw = self.http_get(url)
            if raw:
                try:
                    data = json.loads(raw)
                    results.append({
                        "name": name, "stars": data.get("stargazers_count", 0),
                        "forks": data.get("forks_count", 0),
                        "updated": data.get("pushed_at", "")[:10],
                        "issues": data.get("open_issues_count", 0),
                    })
                except json.JSONDecodeError:
                    pass

        report = f"# Competitor Watch -- {datetime.now().strftime('%Y-%m-%d')}\n\n"
        for r in results:
            report += f"## {r['name']}\n"
            report += f"Stars: {r['stars']:,} | Forks: {r['forks']} | Issues: {r['issues']} | Updated: {r['updated']}\n\n"

        self.store(f"competitors_{datetime.now().strftime('%Y%m%d')}", report, "reference",
                   "competitors,monitoring,auto", 0.6)
        return {"status": "ok", "competitors": len(results)}


# =========================================================================
# REGISTRY
# =========================================================================

OPS_WORKFLOW_REGISTRY: Dict[str, type] = {
    # Multi-Agent (7)
    "brain_sync_checker": BrainSyncChecker,
    "task_handoff_monitor": TaskHandoffMonitor,
    "agent_infra_monitor": AgentInfrastructureMonitor,
    "agent_evolution_tracker": AgentEvolutionTracker,
    "brain_diff": BrainDiff,
    "message_digest": MessageChannelDigest,
    "capability_matrix": CapabilityMatrix,
    # Ops (5)
    "session_handover": SessionHandover,
    "memory_continuity": MemoryContinuityChecker,
    "workflow_health": WorkflowHealthMonitor,
    "fix_success_tracker": FixSuccessTracker,
    "activity_journal": ActivityJournal,
    # Security (3)
    "credential_rotation": CredentialRotationReminder,
    "compliance_gap_reporter": ComplianceGapReporter,
    # Finance (2)
    "budget_monitor": BudgetBalanceMonitor,
    "concentration_alert": ConcentrationAlert,
    # Business (8)
    "package_downloads": PackageDownloadTracker,
    "repo_activity": RepoActivityTracker,
    "domain_health": DomainHealthMonitor,
    "content_calendar": ContentCalendar,
    "revenue_tracker": RevenueTracker,
    "outreach_tracker": OutreachTracker,
    "launch_readiness": LaunchReadinessChecklist,
    "job_application_tracker": JobApplicationTracker,
    "competitor_monitor": CompetitorMonitor,
}


def seed_ops_workflows(db_path: str) -> int:
    """Insert all ops workflows into the database with enabled=0, source='ops_pro'."""
    conn = sqlite3.connect(db_path, check_same_thread=False)
    count = 0
    for name, cls in OPS_WORKFLOW_REGISTRY.items():
        try:
            conn.execute("""
                INSERT OR REPLACE INTO workflows
                (name, display_name, category, description, cron_schedule, enabled, source)
                VALUES (?, ?, ?, ?, ?, 0, 'ops_pro')
            """, (cls.name, cls.display_name, cls.category, cls.description, cls.schedule_cron))
            count += 1
        except Exception as e:
            log.error("Failed to seed %s: %s", name, e)
    conn.commit()
    conn.close()
    return count
