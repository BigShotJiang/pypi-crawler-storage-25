"""
reactive_engine.py — Domain-agnostic reactive execution engine.

Inspired by FlyWire connectome (Princeton/Cambridge 2024) and the Rete
algorithm (Forgy 1979). Replaces sequential task-list execution with
state-dependent, event-driven chain firing.

Architecture:
  - State object: dict of current facts (auth, rce, keys, etc.)
  - Graph: dict of nodes, each with requires(state)->bool, produces list, fn
  - Engine: async event loop — fires nodes whose prerequisites are met,
    merges produced state, re-evaluates. Converges when no more nodes can fire.

Key concepts from Rete:
  - Refraction: a node+state_hash fires at most once. Only re-fires if
    prerequisite-relevant state keys changed since last execution.
  - Forward chaining: state changes propagate to affected nodes only.
  - Conflict resolution: priority ordering (higher fires first).

Key concepts from FlyWire:
  - Sparse connectivity: most nodes don't fire (prerequisites not met).
  - Attractor states: stable flags (RCE_CONFIRMED) reshape downstream selection.
  - Recurrent feedback: new findings update state, re-evaluate all blocked nodes.
  - Inhibitory neurons: refraction tracker prevents infinite loops.

Usage:
    from reactive_engine import ReactiveEngine

    graph = {
        "recon": {
            "requires": lambda s: True,
            "produces": ["tech_stack"],
            "fn": do_recon,
            "priority": 0,
        },
        "exploit_ssti": {
            "requires": lambda s: s.get("ssti_confirmed"),
            "produces": ["rce", "rce_vector"],
            "fn": do_ssti_exploit,
            "priority": 10,
        },
    }

    engine = ReactiveEngine(initial_state, graph)
    final_state = await engine.run()
"""

import asyncio
import hashlib
import json
import logging
import sqlite3
import time
from pathlib import Path
from typing import Any, Callable, Optional

log = logging.getLogger("reactive_engine")


# ---------------------------------------------------------------------------
# Checkpoint store — event sourcing for crash recovery
# ---------------------------------------------------------------------------

class CheckpointStore:
    """SQLite-backed checkpoint store for ReactiveEngine state persistence.

    Stores event log + state snapshots so engine can resume after crash.
    Each run gets a unique run_id. Events are appended immutably.
    """

    def __init__(self, db_path: str | Path | None = None):
        if db_path is None:
            self.conn = None
            return
        self.conn = sqlite3.connect(str(db_path))
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.executescript("""
            CREATE TABLE IF NOT EXISTS checkpoints (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                run_id TEXT NOT NULL,
                tick INTEGER NOT NULL,
                event_type TEXT NOT NULL,
                node_name TEXT,
                state_json TEXT,
                metadata TEXT,
                created_at TEXT DEFAULT (datetime('now'))
            );
            CREATE INDEX IF NOT EXISTS idx_cp_run ON checkpoints(run_id);
        """)
        self.conn.commit()

    def save_event(self, run_id: str, tick: int, event_type: str,
                   node_name: str = "", state: dict = None, metadata: dict = None):
        if not self.conn:
            return
        self.conn.execute(
            "INSERT INTO checkpoints (run_id, tick, event_type, node_name, state_json, metadata) VALUES (?,?,?,?,?,?)",
            (run_id, tick, event_type, node_name,
             json.dumps(state, default=str) if state else None,
             json.dumps(metadata, default=str) if metadata else None)
        )
        self.conn.commit()

    def load_last_run(self, run_id: str) -> dict | None:
        """Load the last state snapshot for a given run_id."""
        if not self.conn:
            return None
        row = self.conn.execute(
            "SELECT state_json FROM checkpoints WHERE run_id=? AND event_type='state_snapshot' ORDER BY id DESC LIMIT 1",
            (run_id,)
        ).fetchone()
        if row and row[0]:
            return json.loads(row[0])
        return None

    def get_completed_nodes(self, run_id: str) -> set[str]:
        """Get set of node names that completed in a given run."""
        if not self.conn:
            return set()
        rows = self.conn.execute(
            "SELECT DISTINCT node_name FROM checkpoints WHERE run_id=? AND event_type='node_complete'",
            (run_id,)
        ).fetchall()
        return {r[0] for r in rows if r[0]}

    def list_runs(self, limit: int = 20) -> list[dict]:
        """List recent runs with their status."""
        if not self.conn:
            return []
        rows = self.conn.execute("""
            SELECT run_id, MIN(created_at) as started, MAX(created_at) as ended,
                   COUNT(*) as events,
                   SUM(CASE WHEN event_type='node_complete' THEN 1 ELSE 0 END) as completed_nodes
            FROM checkpoints GROUP BY run_id ORDER BY started DESC LIMIT ?
        """, (limit,)).fetchall()
        return [{"run_id": r[0], "started": r[1], "ended": r[2],
                 "events": r[3], "completed_nodes": r[4]} for r in rows]


# ---------------------------------------------------------------------------
# Observability — per-node timing, token budgets, tracing
# ---------------------------------------------------------------------------

class EngineTracer:
    """Lightweight observability for reactive engine runs."""

    def __init__(self):
        self.node_timings: dict[str, float] = {}
        self.node_retries: dict[str, int] = {}
        self.total_start: float = 0
        self.total_end: float = 0
        self.state_changes: list[dict] = []

    def record_node_timing(self, node_name: str, duration: float):
        self.node_timings[node_name] = duration

    def record_state_change(self, node_name: str, keys: list[str]):
        self.state_changes.append({
            "node": node_name, "keys": keys, "at": time.time()
        })

    @property
    def summary(self) -> dict:
        total = self.total_end - self.total_start if self.total_end else 0
        return {
            "total_duration_s": round(total, 2),
            "nodes_timed": len(self.node_timings),
            "slowest_node": max(self.node_timings, key=self.node_timings.get) if self.node_timings else None,
            "slowest_time_s": round(max(self.node_timings.values()), 2) if self.node_timings else 0,
            "state_changes": len(self.state_changes),
            "node_timings": {k: round(v, 3) for k, v in sorted(self.node_timings.items(), key=lambda x: -x[1])},
        }


# ---------------------------------------------------------------------------
# Confidence gateway — route uncertain results to escalation
# ---------------------------------------------------------------------------

CONFIDENCE_THRESHOLD_IRREVERSIBLE = 0.85
CONFIDENCE_THRESHOLD_REVERSIBLE = 0.70


def confidence_gate(result: dict, irreversible: bool = False) -> dict:
    """Check if a node result has sufficient confidence to proceed.

    Nodes can include a '_confidence' key (0.0-1.0) in their result.
    If below threshold, the result is tagged with '_needs_escalation': True.
    The engine or downstream nodes can use this to route to human review.

    Args:
        result: Node output dict
        irreversible: If True, use stricter threshold (0.85 vs 0.70)
    Returns:
        result dict with '_needs_escalation' and '_confidence_status' added
    """
    if not isinstance(result, dict):
        return result

    confidence = result.get("_confidence")
    if confidence is None:
        return result  # no confidence declared — pass through

    threshold = CONFIDENCE_THRESHOLD_IRREVERSIBLE if irreversible else CONFIDENCE_THRESHOLD_REVERSIBLE

    if confidence < threshold:
        result["_needs_escalation"] = True
        result["_confidence_status"] = f"below_threshold ({confidence:.2f} < {threshold:.2f})"
        log.info("Confidence gate: %s needs escalation (%.2f < %.2f)",
                 result.get("_node_name", "unknown"), confidence, threshold)
    else:
        result["_needs_escalation"] = False
        result["_confidence_status"] = f"passed ({confidence:.2f} >= {threshold:.2f})"

    return result


class ReactiveEngine:
    """
    Async reactive execution engine with checkpointing, confidence gating,
    and observability.

    Nodes fire when prerequisites are met. Outputs merge into shared state.
    Convergence when no more nodes can fire. Refraction prevents re-fire
    unless prerequisite-relevant state keys have changed.
    """

    def __init__(
        self,
        state: dict,
        graph: dict,
        *,
        max_concurrent: int = 10,
        max_ticks: int = 100,
        on_node_start: Optional[Callable] = None,
        on_node_complete: Optional[Callable] = None,
        on_state_change: Optional[Callable] = None,
        checkpoint_store: Optional[CheckpointStore] = None,
        run_id: Optional[str] = None,
        resume: bool = False,
        enable_confidence_gate: bool = True,
    ):
        self.state = state
        self.graph = graph
        self.max_concurrent = max_concurrent
        self.max_ticks = max_ticks

        # Callbacks
        self.on_node_start = on_node_start
        self.on_node_complete = on_node_complete
        self.on_state_change = on_state_change

        # Checkpointing
        self._checkpoint = checkpoint_store
        self._run_id = run_id or f"run_{int(time.time())}_{id(self):x}"
        self._enable_confidence = enable_confidence_gate

        # Observability
        self.tracer = EngineTracer()

        # Refraction: {node_name: snapshot_of_refire_on_keys_at_last_fire}
        self._fire_history: dict[str, dict] = {}
        self._fire_count: dict[str, int] = {}  # feedback loop decay tracking

        # Execution tracking
        self._active: set[str] = set()
        self._completed: set[str] = set()
        self._failed: dict[str, str] = {}
        self._escalated: dict[str, dict] = {}  # nodes that need human review
        self._event_queue: asyncio.Queue = asyncio.Queue()
        self._state_lock: asyncio.Lock = asyncio.Lock()
        self._tick_count: int = 0

        # Resume from checkpoint if requested
        if resume and self._checkpoint:
            saved_state = self._checkpoint.load_last_run(self._run_id)
            if saved_state:
                self.state.update(saved_state)
                self._completed = self._checkpoint.get_completed_nodes(self._run_id)
                log.info("Resumed run %s — %d nodes already completed",
                         self._run_id, len(self._completed))

        # Build dependency index: fact_key -> set of node names that *might*
        # be unblocked when that key changes. A node is a potential consumer
        # of key K if it does NOT produce K itself (producers are co-writers,
        # not consumers). On state change, only these nodes need re-checking.
        all_node_names = set(graph.keys())
        producers_of: dict[str, set[str]] = {}
        for name, node in graph.items():
            for key in node.get("produces", []):
                producers_of.setdefault(key, set()).add(name)
        self._dep_index: dict[str, set[str]] = {}
        for key, producers in producers_of.items():
            self._dep_index[key] = all_node_names - producers

        # Audit log
        self.execution_log: list[dict] = []

    def _should_fire(self, node_name: str) -> bool:
        """Refraction check: should this node fire given current state?

        Rete refraction: a node fires AT MOST ONCE by default.
        Re-fire only if the node declares `refire_on: ["key1", "key2"]`
        AND one of those state keys has changed since last fire.

        This prevents the cascade problem where node B's output changes
        global state, causing unrelated node A to re-fire.
        """
        if node_name not in self._fire_history:
            return True  # never fired

        node = self.graph[node_name]
        refire_on = node.get("refire_on")

        if not refire_on:
            return False  # default: fire once only

        # Feedback loop decay: stop refiring after max_refire (default 4)
        max_refire = node.get("max_refire", 4)
        fire_count = self._fire_count.get(node_name, 0)
        if fire_count >= max_refire:
            log.info("Feedback decay: %s hit max refire limit (%d)", node_name, max_refire)
            return False

        # Check if any refire_on keys have changed since last fire
        last_snapshot = self._fire_history[node_name]
        for key in refire_on:
            current_val = _serializable(self.state.get(key))
            if current_val != last_snapshot.get(key):
                return True

        return False

    def _record_fire(self, node_name: str):
        """Snapshot the refire_on keys for refraction tracking."""
        node = self.graph[node_name]
        refire_on = node.get("refire_on", [])
        self._fire_history[node_name] = {
            k: _serializable(self.state.get(k)) for k in refire_on
        }
        self._fire_count[node_name] = self._fire_count.get(node_name, 0) + 1

    def _prerequisites_met(self, node_name: str) -> bool:
        """Check if a node's prerequisites are satisfied by current state."""
        node = self.graph[node_name]
        requires = node.get("requires")
        if requires is None:
            return True
        try:
            return bool(requires(self.state))
        except Exception as e:
            log.warning("Prerequisites check failed for %s: %s", node_name, e)
            return False

    def _get_ready_nodes(self, changed_keys: list[str] | None = None) -> list[str]:
        """Find all nodes ready to fire, sorted by priority (highest first).

        When changed_keys is provided (after a state merge), only nodes that
        could potentially be affected by those keys are checked — using the
        _dep_index built at init. On first tick (no changes yet), all nodes
        are checked.
        """
        if changed_keys is not None:
            # Only check nodes that might consume one of the changed keys,
            # plus nodes that have never been evaluated (not completed/failed/active)
            candidates = set()
            for key in changed_keys:
                candidates.update(self._dep_index.get(key, set()))
            # Also include nodes that have never fired (first-pass candidates)
            for name in self.graph:
                if name not in self._completed and name not in self._failed and name not in self._active:
                    if name not in self._fire_history:
                        candidates.add(name)
        else:
            candidates = set(self.graph.keys())

        ready = []
        for name in candidates:
            if name in self._active:
                continue  # already running
            if not self._prerequisites_met(name):
                continue  # prerequisites not met
            if not self._should_fire(name):
                continue  # refraction — already fired with this state
            ready.append(name)

        # Sort by priority (higher = fires first), then alphabetical for determinism
        ready.sort(key=lambda n: (-self.graph[n].get("priority", 0), n))
        return ready

    async def _run_node(self, node_name: str):
        """Execute a single node and emit its results to the event queue."""
        node = self.graph[node_name]
        fn = node["fn"]
        start = time.monotonic()

        log_entry = {
            "node": node_name,
            "started_at": time.time(),
            "state_snapshot": {k: _serializable(v) for k, v in self.state.items()},
        }

        # Checkpoint: node started
        if self._checkpoint:
            self._checkpoint.save_event(
                self._run_id, self._tick_count, "node_start",
                node_name=node_name)

        if self.on_node_start:
            try:
                self.on_node_start(node_name, self.state)
            except Exception:
                pass

        try:
            # Support both sync and async node functions
            if asyncio.iscoroutinefunction(fn):
                result = await fn(self.state)
            else:
                result = fn(self.state)

            elapsed = time.monotonic() - start
            log_entry["duration_s"] = round(elapsed, 2)
            log_entry["status"] = "ok"
            log_entry["produced"] = result if isinstance(result, dict) else {}

            # Confidence gate: check if result needs escalation
            if self._enable_confidence and isinstance(result, dict):
                is_irreversible = node.get("irreversible", False)
                result["_node_name"] = node_name
                result = confidence_gate(result, irreversible=is_irreversible)
                if result.get("_needs_escalation"):
                    self._escalated[node_name] = {
                        "confidence": result.get("_confidence", 0),
                        "status": result.get("_confidence_status", ""),
                        "result_keys": list(result.keys()),
                    }
                    log_entry["escalated"] = True

        except Exception as e:
            elapsed = time.monotonic() - start
            log_entry["duration_s"] = round(elapsed, 2)
            log_entry["status"] = "error"
            log_entry["error"] = str(e)
            log.error("Node %s failed after %.1fs: %s", node_name, elapsed, e)
            result = None

            # Compensating actions: if node defines a rollback, queue it
            rollback = node.get("on_failure")
            if rollback:
                log.info("Running compensating action for %s", node_name)
                try:
                    if asyncio.iscoroutinefunction(rollback):
                        await rollback(self.state, str(e))
                    else:
                        rollback(self.state, str(e))
                except Exception as re:
                    log.error("Compensating action for %s also failed: %s", node_name, re)

        # Observability: record timing
        self.tracer.record_node_timing(node_name, time.monotonic() - start)

        self.execution_log.append(log_entry)
        await self._event_queue.put((node_name, result))

    async def _merge_state(self, node_name: str, result: dict | None) -> list[str]:
        """Merge a node's output into shared state. Thread-safe via lock.

        Returns list of state keys that actually changed (used by _dep_index
        to limit which nodes get re-evaluated).
        """
        if not result or not isinstance(result, dict):
            return []

        async with self._state_lock:
            changed_keys = []
            for key, value in result.items():
                old = self.state.get(key)

                # Smart merge: lists append, sets union, dicts update, scalars replace
                if isinstance(old, list) and isinstance(value, list):
                    for item in value:
                        if item not in old:
                            old.append(item)
                    if old != self.state.get(key):
                        changed_keys.append(key)
                elif isinstance(old, set) and isinstance(value, set):
                    before = len(old)
                    old.update(value)
                    if len(old) != before:
                        changed_keys.append(key)
                elif isinstance(old, dict) and isinstance(value, dict):
                    old.update(value)
                    changed_keys.append(key)
                else:
                    if old != value:
                        self.state[key] = value
                        changed_keys.append(key)

            if changed_keys and self.on_state_change:
                try:
                    self.on_state_change(node_name, changed_keys, self.state)
                except Exception:
                    pass

            return changed_keys

    async def run(self) -> dict:
        """Main execution loop. Returns final state when converged.

        Flow:
          1. Find ready nodes (prerequisites met, not refracted)
          2. Launch up to max_concurrent
          3. Wait for any completion event
          4. Merge produced state (with confidence gating)
          5. Checkpoint state for crash recovery
          6. Re-evaluate ready nodes (recurrent feedback)
          7. Repeat until convergence or max_ticks
        """
        log.info("ReactiveEngine starting — %d nodes in graph, run_id=%s",
                 len(self.graph), self._run_id)
        self.tracer.total_start = time.time()

        # Checkpoint: run started
        if self._checkpoint:
            self._checkpoint.save_event(
                self._run_id, 0, "run_start",
                state=self.state,
                metadata={"graph_nodes": list(self.graph.keys()),
                          "resumed_nodes": list(self._completed)})

        # Accumulate changed keys between launch rounds. None = first tick,
        # check all nodes. Reset to empty after each launch round.
        _pending_changes: list[str] | None = None

        while self._tick_count < self.max_ticks:
            ready = self._get_ready_nodes(changed_keys=_pending_changes)

            # Respect concurrency limit
            slots = self.max_concurrent - len(self._active)
            to_launch = ready[:slots]

            # Launch new nodes
            for name in to_launch:
                self._active.add(name)
                self._record_fire(name)
                asyncio.create_task(self._run_node(name))
                log.info("Fired: %s (tick %d)", name, self._tick_count)

            # Reset pending changes after evaluating them
            if to_launch:
                _pending_changes = []

            # If nothing active and nothing to launch — converged
            if not self._active and not to_launch:
                log.info(
                    "Converged after %d ticks. %d nodes fired, %d failed, %d escalated.",
                    self._tick_count,
                    len(self._completed),
                    len(self._failed),
                    len(self._escalated),
                )
                break

            # Wait for next completion event
            if self._active:
                node_name, result = await self._event_queue.get()
                self._active.discard(node_name)

                if result is not None:
                    merged_keys = await self._merge_state(node_name, result)
                    self._completed.add(node_name)

                    # Observability: track state changes
                    if merged_keys:
                        self.tracer.record_state_change(node_name, merged_keys)

                    # Checkpoint: node complete + state snapshot
                    if self._checkpoint:
                        self._checkpoint.save_event(
                            self._run_id, self._tick_count, "node_complete",
                            node_name=node_name,
                            metadata={"changed_keys": merged_keys})
                        # Snapshot state every 5 ticks or after significant changes
                        if self._tick_count % 5 == 0 or len(merged_keys) > 3:
                            self._checkpoint.save_event(
                                self._run_id, self._tick_count, "state_snapshot",
                                state=self.state)

                    # Accumulate changed keys so the next _get_ready_nodes
                    # considers all state changes since last launch round
                    if _pending_changes is not None:
                        _pending_changes.extend(merged_keys)
                    else:
                        _pending_changes = merged_keys
                else:
                    self._failed[node_name] = "execution error"
                    if self._checkpoint:
                        self._checkpoint.save_event(
                            self._run_id, self._tick_count, "node_failed",
                            node_name=node_name)

                if self.on_node_complete:
                    try:
                        self.on_node_complete(node_name, result, self.state)
                    except Exception:
                        pass

                self._tick_count += 1
        else:
            log.warning("Max ticks (%d) reached — possible cycle", self.max_ticks)

        # Finalize
        self.tracer.total_end = time.time()
        if self._checkpoint:
            self._checkpoint.save_event(
                self._run_id, self._tick_count, "run_complete",
                state=self.state,
                metadata=self.stats)

        return self.state

    # --- Inspection ---

    @property
    def stats(self) -> dict:
        return {
            "run_id": self._run_id,
            "ticks": self._tick_count,
            "completed": sorted(self._completed),
            "failed": dict(self._failed),
            "escalated": dict(self._escalated),
            "active": sorted(self._active),
            "total_nodes": len(self.graph),
            "fired_count": len(self._completed) + len(self._failed),
            "escalated_count": len(self._escalated),
            "tracer": self.tracer.summary,
        }

    def blocked_nodes(self) -> dict[str, str]:
        """Return nodes that haven't fired and why."""
        blocked = {}
        for name in self.graph:
            if name in self._completed or name in self._failed or name in self._active:
                continue
            if not self._prerequisites_met(name):
                blocked[name] = "prerequisites not met"
            elif not self._should_fire(name):
                blocked[name] = "refracted (already fired with this state)"
        return blocked


def _serializable(v: Any) -> Any:
    """Convert sets and other non-JSON types for hashing."""
    if isinstance(v, set):
        return sorted(str(x) for x in v)
    if isinstance(v, bytes):
        return v.hex()
    return v


# ---------------------------------------------------------------------------
# Plan Cache — reuse successful execution plans (50% cost reduction)
# ---------------------------------------------------------------------------

class PlanCache:
    """Cache successful execution plans for reuse on similar inputs.

    Based on Agentic Plan Caching (NeurIPS 2025): extract plan templates
    from completed executions, match new queries via keywords, adapt via
    lightweight model. 50% cost reduction, 27% latency reduction.
    """

    def __init__(self, db_path: str | Path | None = None):
        if db_path is None:
            self._cache: dict[str, dict] = {}
            self._db = None
            return
        self._db = sqlite3.connect(str(db_path))
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.executescript("""
            CREATE TABLE IF NOT EXISTS plan_cache (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                cache_key TEXT UNIQUE NOT NULL,
                graph_name TEXT NOT NULL,
                input_signature TEXT NOT NULL,
                execution_order TEXT NOT NULL,
                state_transitions TEXT,
                hit_count INTEGER DEFAULT 0,
                success_rate REAL DEFAULT 1.0,
                created_at TEXT DEFAULT (datetime('now')),
                last_used TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_pc_graph ON plan_cache(graph_name);
        """)
        self._db.commit()
        self._cache = {}

    def _make_key(self, graph_name: str, input_keys: list[str]) -> str:
        """Generate cache key from graph name + sorted input key names."""
        sig = f"{graph_name}:{','.join(sorted(input_keys))}"
        return hashlib.sha256(sig.encode()).hexdigest()[:16]

    def get(self, graph_name: str, input_keys: list[str]) -> list[str] | None:
        """Look up a cached execution order for this graph + input shape."""
        key = self._make_key(graph_name, input_keys)
        # Check memory cache first
        if key in self._cache:
            self._cache[key]["hits"] = self._cache[key].get("hits", 0) + 1
            return self._cache[key]["order"]
        # Check DB
        if self._db:
            row = self._db.execute(
                "SELECT execution_order FROM plan_cache WHERE cache_key=? AND success_rate >= 0.7",
                (key,)
            ).fetchone()
            if row:
                order = json.loads(row[0])
                self._db.execute(
                    "UPDATE plan_cache SET hit_count = hit_count + 1, last_used = datetime('now') WHERE cache_key=?",
                    (key,))
                self._db.commit()
                self._cache[key] = {"order": order, "hits": 1}
                return order
        return None

    def store(self, graph_name: str, input_keys: list[str],
              execution_order: list[str], state_transitions: dict = None):
        """Store a successful execution plan."""
        key = self._make_key(graph_name, input_keys)
        self._cache[key] = {"order": execution_order, "hits": 0}
        if self._db:
            self._db.execute("""
                INSERT OR REPLACE INTO plan_cache
                (cache_key, graph_name, input_signature, execution_order, state_transitions, last_used)
                VALUES (?, ?, ?, ?, ?, datetime('now'))
            """, (key, graph_name, json.dumps(sorted(input_keys)),
                  json.dumps(execution_order),
                  json.dumps(state_transitions, default=str) if state_transitions else None))
            self._db.commit()

    def record_failure(self, graph_name: str, input_keys: list[str]):
        """Reduce success rate for a cached plan that failed."""
        key = self._make_key(graph_name, input_keys)
        self._cache.pop(key, None)
        if self._db:
            self._db.execute(
                "UPDATE plan_cache SET success_rate = success_rate * 0.8 WHERE cache_key=?",
                (key,))
            self._db.commit()


# ---------------------------------------------------------------------------
# Question Generator — the Pixel Moment implementation
# ---------------------------------------------------------------------------

class QuestionGenerator:
    """Generates breakthrough questions from memory patterns and workflow outcomes.

    Inspired by Voyager's curriculum module (NVIDIA 2023). The agent proposes
    what to explore next based on observed gaps, anomalies, and untried combinations.

    Five question types:
    1. Step-Back abstraction: "What general pattern does X instantiate?"
    2. Counterfactual: "What would happen if we did X differently?"
    3. Frontier detection: "What capabilities exist that we haven't combined?"
    4. Meta-question: "What am I systematically not asking about?"
    5. Anomaly: "Why does X keep failing/succeeding?"
    """

    def __init__(self):
        self.questions: list[dict] = []
        self.patterns_seen: list[str] = []

    def analyze_execution(self, engine: ReactiveEngine) -> list[dict]:
        """Generate questions from a completed engine run."""
        questions = []

        # 1. Anomaly detection — nodes that always fail or always succeed
        if engine._failed:
            for name, reason in engine._failed.items():
                questions.append({
                    "type": "anomaly",
                    "question": f"Why does '{name}' keep failing? Root cause: {reason}",
                    "priority": 0.9,
                    "source": "execution_failure",
                })

        # 2. Escalated nodes — confidence was too low
        if engine._escalated:
            for name, info in engine._escalated.items():
                questions.append({
                    "type": "confidence",
                    "question": f"'{name}' had low confidence ({info.get('confidence', 0):.2f}). Can we improve the data/model/approach?",
                    "priority": 0.7,
                    "source": "confidence_gate",
                })

        # 3. Blocked nodes — prerequisites never met
        blocked = engine.blocked_nodes()
        if blocked:
            for name, reason in blocked.items():
                questions.append({
                    "type": "frontier",
                    "question": f"'{name}' was blocked ({reason}). What would unblock it? Is there an alternative path?",
                    "priority": 0.6,
                    "source": "blocked_node",
                })

        # 4. Timing anomalies — nodes that took much longer than others
        timings = engine.tracer.node_timings
        if len(timings) >= 3:
            avg = sum(timings.values()) / len(timings)
            for name, t in timings.items():
                if t > avg * 3:
                    questions.append({
                        "type": "anomaly",
                        "question": f"'{name}' took {t:.1f}s (avg {avg:.1f}s). Bottleneck or expected?",
                        "priority": 0.5,
                        "source": "timing_anomaly",
                    })

        # 5. Meta-question — what's not in the graph?
        if len(engine.graph) < 5:
            questions.append({
                "type": "meta",
                "question": "This graph has very few nodes. Are there steps being done manually that should be automated?",
                "priority": 0.4,
                "source": "graph_sparsity",
            })

        # Sort by priority
        questions.sort(key=lambda q: -q["priority"])
        self.questions.extend(questions)
        return questions

    def analyze_memory(self, memories: list[dict], workflows: list[dict] = None) -> list[dict]:
        """Generate questions from memory patterns and workflow inventory.

        This is the cross-domain pattern matching — looking for structural
        similarities and untried combinations.
        """
        questions = []

        # Group memories by type
        by_type: dict[str, int] = {}
        for m in memories:
            t = m.get("type", "unknown")
            by_type[t] = by_type.get(t, 0) + 1

        # 1. Type imbalance — too much of one type suggests blind spots
        total = sum(by_type.values())
        if total > 20:
            for t, count in by_type.items():
                ratio = count / total
                if ratio > 0.4:
                    questions.append({
                        "type": "meta",
                        "question": f"{ratio:.0%} of memories are type '{t}'. What types are underrepresented? What are we not capturing?",
                        "priority": 0.6,
                        "source": "memory_imbalance",
                    })

        # 2. Stale memories — high access count but old
        for m in memories:
            ac = m.get("access_count", 0)
            if ac > 10:
                questions.append({
                    "type": "counterfactual",
                    "question": f"Memory '{m.get('name', '?')}' accessed {ac} times. Is it still accurate? What changed since it was written?",
                    "priority": 0.5,
                    "source": "frequently_accessed",
                })

        # 3. Workflow coverage — what domains lack automation?
        if workflows:
            categories = {w.get("category", "unknown") for w in workflows}
            known_domains = {"security", "content", "finance", "jobs", "research",
                            "monitoring", "communication", "trading", "devops"}
            missing = known_domains - categories
            if missing:
                questions.append({
                    "type": "frontier",
                    "question": f"No workflows for domains: {', '.join(sorted(missing))}. Should any be automated?",
                    "priority": 0.7,
                    "source": "workflow_coverage",
                })

        questions.sort(key=lambda q: -q["priority"])
        self.questions.extend(questions)
        return questions

    def get_top_questions(self, n: int = 5) -> list[dict]:
        """Return top N unique questions by priority."""
        seen = set()
        unique = []
        for q in sorted(self.questions, key=lambda x: -x["priority"]):
            key = q["question"][:80]
            if key not in seen:
                seen.add(key)
                unique.append(q)
            if len(unique) >= n:
                break
        return unique


# ---------------------------------------------------------------------------
# Model Cascade — route simple tasks to cheap models, complex to expensive
# ---------------------------------------------------------------------------

class ModelCascade:
    """Route LLM tasks to appropriate model tier based on complexity.

    Research finding: 35% cost savings by cascading simple→cheap, complex→expensive.
    Complexity is estimated from input length, tool count, and domain.

    Usage:
        cascade = ModelCascade()
        model = cascade.select("Summarize this paragraph", tools=0)
        # → "haiku" (simple task)
        model = cascade.select("Analyze this 5000-line codebase for vulnerabilities", tools=5)
        # → "opus" (complex task)
    """

    # Model tiers: name → (max_complexity, cost_weight)
    TIERS = {
        "haiku": {"max_complexity": 0.3, "cost_weight": 1},
        "sonnet": {"max_complexity": 0.7, "cost_weight": 5},
        "opus": {"max_complexity": 1.0, "cost_weight": 25},
    }

    # Domain complexity multipliers
    DOMAIN_WEIGHTS = {
        "security": 0.8,    # needs careful analysis
        "code_review": 0.7,
        "research": 0.6,
        "content": 0.4,
        "triage": 0.3,
        "notification": 0.1,
        "formatting": 0.1,
    }

    def __init__(self, override: str | None = None):
        """Initialize. Set override to force a specific model for all calls."""
        self.override = override
        self.call_log: list[dict] = []

    def estimate_complexity(self, prompt: str, tools: int = 0,
                            domain: str = "general") -> float:
        """Estimate task complexity from 0.0 to 1.0."""
        score = 0.0

        # Input length factor (0-0.3)
        length = len(prompt)
        if length > 5000:
            score += 0.3
        elif length > 1000:
            score += 0.2
        elif length > 200:
            score += 0.1

        # Tool usage factor (0-0.3)
        if tools > 3:
            score += 0.3
        elif tools > 0:
            score += 0.15

        # Domain factor (0-0.4)
        domain_weight = self.DOMAIN_WEIGHTS.get(domain, 0.4)
        score += domain_weight * 0.5

        return min(score, 1.0)

    def select(self, prompt: str, tools: int = 0,
               domain: str = "general") -> str:
        """Select the appropriate model tier for this task."""
        if self.override:
            return self.override

        complexity = self.estimate_complexity(prompt, tools, domain)

        for tier_name, tier in sorted(self.TIERS.items(),
                                       key=lambda x: x[1]["max_complexity"]):
            if complexity <= tier["max_complexity"]:
                selected = tier_name
                break
        else:
            selected = "opus"

        self.call_log.append({
            "complexity": round(complexity, 2),
            "model": selected,
            "domain": domain,
            "prompt_len": len(prompt),
            "tools": tools,
        })
        return selected

    @property
    def savings_estimate(self) -> dict:
        """Estimate cost savings from cascading vs always using opus."""
        if not self.call_log:
            return {"calls": 0, "savings_pct": 0}
        total_opus_cost = sum(self.TIERS["opus"]["cost_weight"] for _ in self.call_log)
        actual_cost = sum(self.TIERS[c["model"]]["cost_weight"] for c in self.call_log)
        savings = (1 - actual_cost / total_opus_cost) * 100 if total_opus_cost > 0 else 0
        return {
            "calls": len(self.call_log),
            "actual_cost_units": actual_cost,
            "opus_equivalent": total_opus_cost,
            "savings_pct": round(savings, 1),
        }
