#!/usr/bin/env python3
"""
test_boss.py — Integration test for Boss Agent Orchestrator.

Requires Docker running with `docker compose -f docker-compose.boss.yml up -d`.
Tests: task assignment, worker execution, result collection, plan execution.
"""

import json
import sys
import time

from boss import Boss


def test_workers_online(boss: Boss, expected: int = 2, timeout: int = 30):
    """Wait for workers to register."""
    print(f"Waiting for {expected} workers to come online...")
    deadline = time.time() + timeout
    while time.time() < deadline:
        workers = boss.workers()
        alive = [w for w in workers.values() if w.get("status") in ("ready", "alive")]
        if len(alive) >= expected:
            print(f"  OK: {len(alive)} workers online")
            for wid, info in workers.items():
                print(f"    {wid}: {info.get('status')}")
            return True
        time.sleep(1)
    workers = boss.workers()
    print(f"  FAIL: only {len(workers)} workers after {timeout}s")
    return False


def test_shell_task(boss: Boss):
    """Assign a shell task and verify output."""
    print("\nTest: shell task (echo + hostname)...")
    tid = boss.assign_shell("echo 'hello from worker' && hostname")
    result = boss.wait_for(tid, timeout=30)

    if result["status"] == "completed":
        stdout = result["result"]["stdout"].strip()
        print(f"  OK: {stdout}")
        return True
    else:
        print(f"  FAIL: {result}")
        return False


def test_python_task(boss: Boss):
    """Assign a Python task (using builtins)."""
    print("\nTest: python task (platform.node)...")
    tid = boss.assign_python("platform", "node")
    result = boss.wait_for(tid, timeout=30)

    if result["status"] == "completed":
        print(f"  OK: node={result['result']['result']}")
        return True
    else:
        print(f"  FAIL: {result}")
        return False


def test_parallel_tasks(boss: Boss):
    """Assign 4 tasks simultaneously to test parallel execution."""
    print("\nTest: 4 parallel shell tasks...")
    task_ids = []
    for i in range(4):
        tid = boss.assign_shell(f"echo 'task-{i}' && sleep 2 && date")
        task_ids.append(tid)

    start = time.time()
    results = {}
    for tid in task_ids:
        results[tid] = boss.wait_for(tid, timeout=60)
    elapsed = time.time() - start

    ok = all(r["status"] == "completed" for r in results.values())
    workers_used = set(r.get("worker") for r in results.values())
    print(f"  {'OK' if ok else 'FAIL'}: {len(results)} tasks in {elapsed:.1f}s across {len(workers_used)} workers")
    for tid, r in results.items():
        print(f"    {tid}: {r['status']} worker={r.get('worker')} ({r.get('elapsed_seconds', '?')}s)")
    return ok


def test_plan(boss: Boss):
    """Run a multi-step plan with dependencies."""
    print("\nTest: plan execution with dependencies...")
    plan = [
        {
            "name": "step1-info",
            "task_type": "shell",
            "cmd": "uname -a",
        },
        {
            "name": "step2-disk",
            "task_type": "shell",
            "cmd": "df -h /",
        },
        {
            "name": "step3-summary",
            "task_type": "shell",
            "cmd": "echo 'All info gathered'",
            "depends_on": ["step1-info", "step2-disk"],
        },
    ]

    results = boss.run_plan(plan)
    ok = all(r.get("status") == "completed" for r in results.values())
    print(f"  {'OK' if ok else 'FAIL'}: {len(results)} plan steps completed")
    for name, r in results.items():
        status = r.get("status")
        print(f"    {name}: {status}")
    return ok


def test_playwright_task(boss: Boss):
    """Test browser automation — take a screenshot of example.com."""
    print("\nTest: playwright task (screenshot example.com)...")
    tid = boss.assign_playwright(
        "https://example.com",
        actions=[
            {"action": "text", "selector": "h1"},
            {"action": "screenshot"},
        ]
    )
    result = boss.wait_for(tid, timeout=60)

    if result["status"] == "completed":
        results = result["result"].get("results", [])
        h1_text = next((r.get("content", "") for r in results if r.get("action") == "text"), "")
        print(f"  OK: h1='{h1_text.strip()}'")
        return True
    else:
        error = result.get("result", {}).get("error", result.get("status"))
        print(f"  FAIL: {error}")
        return False


def main():
    print("=" * 60)
    print("Boss Agent Orchestrator — Integration Test")
    print("=" * 60)

    boss = Boss(redis_url="redis://localhost:6379/0")
    passed = 0
    failed = 0

    tests = [
        ("Workers Online", lambda: test_workers_online(boss, expected=2)),
        ("Shell Task", lambda: test_shell_task(boss)),
        ("Python Task", lambda: test_python_task(boss)),
        ("Parallel Tasks", lambda: test_parallel_tasks(boss)),
        ("Plan Execution", lambda: test_plan(boss)),
        ("Playwright Browser", lambda: test_playwright_task(boss)),
    ]

    for name, test_fn in tests:
        try:
            if test_fn():
                passed += 1
            else:
                failed += 1
        except Exception as e:
            print(f"  ERROR: {e}")
            failed += 1

    print(f"\n{'=' * 60}")
    print(f"Results: {passed} passed, {failed} failed out of {passed + failed}")
    print("=" * 60)
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
