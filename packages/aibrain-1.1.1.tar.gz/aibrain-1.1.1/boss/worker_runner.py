#!/usr/bin/env python3
"""
worker_runner.py — Runs inside a Docker worker container.

Connects to Redis broker, pulls task assignments from the boss,
executes them, and reports results back.

Tasks are Python callables serialized as module:function references
with JSON-serializable kwargs, or shell commands.
"""

import json
import logging
import os
import signal
import subprocess
import sys
import time
import traceback
from datetime import datetime, timezone

import redis

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s %(message)s",
)
log = logging.getLogger(f"worker-{os.environ.get('WORKER_ID', 'unknown')}")

REDIS_URL = os.environ.get("REDIS_URL", "redis://broker:6379/0")
import socket
WORKER_ID = os.environ.get("WORKER_ID", f"worker-{socket.gethostname()}")
HEARTBEAT_INTERVAL = int(os.environ.get("HEARTBEAT_INTERVAL", "5"))

# Graceful shutdown
_shutdown = False


def _handle_signal(sig, frame):
    global _shutdown
    log.info("Shutdown signal received")
    _shutdown = True


signal.signal(signal.SIGTERM, _handle_signal)
signal.signal(signal.SIGINT, _handle_signal)


def connect_redis() -> redis.Redis:
    """Connect to Redis with retries."""
    for attempt in range(10):
        try:
            r = redis.from_url(REDIS_URL, decode_responses=True)
            r.ping()
            log.info(f"Connected to Redis at {REDIS_URL}")
            return r
        except redis.ConnectionError:
            wait = min(2 ** attempt, 30)
            log.warning(f"Redis not ready, retry in {wait}s (attempt {attempt + 1}/10)")
            time.sleep(wait)
    raise RuntimeError("Could not connect to Redis after 10 attempts")


def execute_shell_task(cmd: str, timeout: int = 300) -> dict:
    """Execute a shell command and return stdout/stderr/returncode."""
    try:
        result = subprocess.run(
            cmd, shell=True, capture_output=True, text=True, timeout=timeout
        )
        return {
            "type": "shell",
            "stdout": result.stdout[-10000:],  # cap output size
            "stderr": result.stderr[-5000:],
            "returncode": result.returncode,
        }
    except subprocess.TimeoutExpired:
        return {"type": "shell", "error": f"Command timed out after {timeout}s"}


def execute_python_task(module: str, function: str, kwargs: dict, timeout: int = 300) -> dict:
    """Execute a Python function by importing module:function with kwargs."""
    import importlib

    try:
        mod = importlib.import_module(module)
        func = getattr(mod, function)
        result = func(**kwargs)
        # Ensure result is JSON-serializable
        return {"type": "python", "result": json.loads(json.dumps(result, default=str))}
    except Exception as e:
        return {"type": "python", "error": str(e), "traceback": traceback.format_exc()[-3000:]}


def execute_playwright_task(url: str, actions: list, timeout: int = 60) -> dict:
    """Execute a Playwright browser automation task."""
    try:
        from playwright.sync_api import sync_playwright

        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            page = browser.new_page()
            page.goto(url, timeout=timeout * 1000)

            results = []
            for action in actions:
                act_type = action.get("action")
                if act_type == "screenshot":
                    path = f"/tmp/screenshot_{WORKER_ID}_{len(results)}.png"
                    page.screenshot(path=path)
                    results.append({"action": "screenshot", "path": path})
                elif act_type == "click":
                    page.click(action["selector"])
                    results.append({"action": "click", "selector": action["selector"]})
                elif act_type == "fill":
                    page.fill(action["selector"], action["value"])
                    results.append({"action": "fill", "selector": action["selector"]})
                elif act_type == "text":
                    text = page.text_content(action.get("selector", "body"))
                    results.append({"action": "text", "content": text[:5000]})
                elif act_type == "wait":
                    page.wait_for_timeout(action.get("ms", 1000))
                    results.append({"action": "wait"})

            browser.close()
            return {"type": "playwright", "results": results}
    except Exception as e:
        return {"type": "playwright", "error": str(e), "traceback": traceback.format_exc()[-3000:]}


def process_task(task: dict) -> dict:
    """Route task to the appropriate executor."""
    task_type = task.get("task_type", "shell")
    timeout = task.get("timeout", 300)

    if task_type == "shell":
        return execute_shell_task(task["cmd"], timeout=timeout)
    elif task_type == "python":
        return execute_python_task(
            task["module"], task["function"],
            task.get("kwargs", {}), timeout=timeout
        )
    elif task_type == "playwright":
        return execute_playwright_task(
            task["url"], task.get("actions", []), timeout=timeout
        )
    else:
        return {"error": f"Unknown task_type: {task_type}"}


def send_heartbeat(r: redis.Redis):
    """Update worker heartbeat in Redis."""
    r.hset("boss:workers", WORKER_ID, json.dumps({
        "status": "alive",
        "last_heartbeat": datetime.now(timezone.utc).isoformat(),
        "pid": os.getpid(),
    }))
    r.expire("boss:workers", 60)


def main():
    r = connect_redis()
    log.info(f"Worker {WORKER_ID} starting — waiting for tasks on boss:tasks:{WORKER_ID}")

    # Initialize comms, budget guard, and evolution reporting
    try:
        from boss.comms import WorkerComms
        from boss.budget_guard import WorkerBudget
        from boss.evolution_bridge import report_execution
        comms = WorkerComms(REDIS_URL, WORKER_ID)
        budget = WorkerBudget(REDIS_URL, WORKER_ID,
                              token_limit=int(os.environ.get("TOKEN_LIMIT", "50000")),
                              iteration_limit=int(os.environ.get("ITERATION_LIMIT", "50")))
        has_extensions = True
        log.info("Loaded comms, budget guard, and evolution bridge")
    except ImportError:
        has_extensions = False
        comms = None
        budget = None
        log.warning("Running without comms/budget extensions (standalone mode)")

    # Register with boss
    r.hset("boss:workers", WORKER_ID, json.dumps({
        "status": "ready",
        "started": datetime.now(timezone.utc).isoformat(),
        "pid": os.getpid(),
    }))

    last_heartbeat = 0
    task_queue = f"boss:tasks:{WORKER_ID}"
    broadcast_queue = "boss:tasks:any"

    while not _shutdown:
        # Heartbeat
        now = time.time()
        if now - last_heartbeat > HEARTBEAT_INTERVAL:
            send_heartbeat(r)
            last_heartbeat = now

        # Check for broadcast messages (abort, redirect, etc.)
        if comms:
            broadcasts = comms.check_broadcast()
            for msg in broadcasts:
                if msg.get("action") == "abort":
                    log.warning(f"Abort broadcast received: {msg.get('detail')}")
                    _handle_signal(None, None)
                    break

        # Budget check — stop if over budget
        if budget and not budget.is_within_budget():
            log.warning("Over budget — stopping task pickup")
            time.sleep(5)
            continue

        # Check for directed task first, then broadcast queue
        raw = r.lpop(task_queue) or r.lpop(broadcast_queue)
        if not raw:
            time.sleep(0.5)
            continue

        try:
            task = json.loads(raw)
        except json.JSONDecodeError:
            log.error(f"Invalid task JSON: {raw[:200]}")
            continue

        task_id = task.get("task_id", "unknown")
        skill_name = task.get("skill", task.get("task_type", "unknown"))
        log.info(f"Executing task {task_id}: {task.get('task_type', 'shell')}")

        # Track iteration
        if budget:
            if not budget.track_iteration():
                log.warning(f"Iteration limit reached — rejecting task {task_id}")
                r.rpush(broadcast_queue, raw)  # put it back for another worker
                continue

        # Send progress: starting
        if comms:
            comms.send_progress(task_id, 0.0, "Starting task")

        # Mark in-progress
        r.hset("boss:results", task_id, json.dumps({
            "status": "running",
            "worker": WORKER_ID,
            "started": datetime.now(timezone.utc).isoformat(),
        }))

        # Check for checkpoint to resume from
        resume_from = task.get("resume_from")
        if resume_from:
            log.info(f"Resuming task {task_id} from phase {resume_from.get('phase')}")

        # Execute
        start = time.time()
        result = process_task(task)
        elapsed = time.time() - start

        # Track tokens (estimate from result size if not explicitly provided)
        if budget:
            est_tokens = len(json.dumps(result, default=str)) // 4  # rough estimate
            budget.track_tokens(est_tokens)

        # Report skill execution metrics for evolution
        if has_extensions:
            try:
                report_execution(
                    r, WORKER_ID, skill_name,
                    success="error" not in result,
                    tokens_used=len(json.dumps(result, default=str)) // 4,
                    duration_seconds=elapsed,
                    error_message=result.get("error", ""),
                )
            except Exception as e:
                log.debug(f"Evolution reporting failed (non-critical): {e}")

        # Checkpoint completed task
        if budget:
            budget.checkpoint(task_id, phase=99, state={"status": "completed"})

        # Report result
        result_payload = {
            "status": "completed",
            "skill": skill_name,
            "worker": WORKER_ID,
            "task_id": task_id,
            "task_type": task.get("task_type"),
            "result": result,
            "elapsed_seconds": round(elapsed, 2),
            "completed": datetime.now(timezone.utc).isoformat(),
        }

        if "error" in result:
            result_payload["status"] = "failed"

        r.hset("boss:results", task_id, json.dumps(result_payload))
        r.rpush("boss:completed", json.dumps(result_payload))

        # Send progress: done
        if comms:
            comms.send_progress(task_id, 1.0, f"Completed in {elapsed:.1f}s")

        log.info(f"Task {task_id} {result_payload['status']} in {elapsed:.1f}s")

    # Deregister
    log.info(f"Worker {WORKER_ID} shutting down")
    r.hdel("boss:workers", WORKER_ID)


if __name__ == "__main__":
    main()
