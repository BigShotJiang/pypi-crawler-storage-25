#!/usr/bin/env python3
"""
boss.py — Boss Agent Orchestrator

Runs on the host machine. Assigns tasks to Docker worker containers via Redis,
monitors their health, collects results, and merges session outputs.

Usage:
    python -m boss.boss assign --worker worker-1 --type shell --cmd "echo hello"
    python -m boss.boss assign --type python --module my_mod --function my_func
    python -m boss.boss status
    python -m boss.boss results
    python -m boss.boss run-plan plan.json
"""

import argparse
import json
import logging
import os
import subprocess
import sys
import time
import secrets
from datetime import datetime, timezone
from pathlib import Path

import redis

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [boss] %(levelname)s %(message)s",
)
log = logging.getLogger("boss")

REDIS_URL = os.environ.get("REDIS_URL", "redis://localhost:6379/0")


class Boss:
    """Orchestrator that manages Docker worker containers via Redis."""

    def __init__(self, redis_url: str = REDIS_URL):
        self.r = redis.from_url(redis_url, decode_responses=True)
        self.r.ping()
        log.info("Boss connected to Redis")

    # ------------------------------------------------------------------
    # Task assignment
    # ------------------------------------------------------------------

    def assign(self, task: dict, worker: str = None) -> str:
        """
        Assign a task to a specific worker or broadcast to any available worker.

        task dict must contain:
            task_type: "shell" | "python" | "playwright"
            + type-specific fields (cmd, module/function/kwargs, url/actions)

        Returns task_id.
        """
        task_id = task.get("task_id") or f"task-{secrets.token_hex(4)}"
        task["task_id"] = task_id
        task["assigned"] = datetime.now(timezone.utc).isoformat()
        task["assigned_to"] = worker or "any"

        if worker:
            queue = f"boss:tasks:{worker}"
        else:
            queue = "boss:tasks:any"

        self.r.rpush(queue, json.dumps(task))
        log.info(f"Assigned {task_id} ({task.get('task_type')}) -> {worker or 'any'}")
        return task_id

    def assign_shell(self, cmd: str, worker: str = None, timeout: int = 300) -> str:
        return self.assign({"task_type": "shell", "cmd": cmd, "timeout": timeout}, worker)

    def assign_python(self, module: str, function: str, kwargs: dict = None,
                      worker: str = None, timeout: int = 300) -> str:
        return self.assign({
            "task_type": "python", "module": module,
            "function": function, "kwargs": kwargs or {},
            "timeout": timeout,
        }, worker)

    def assign_playwright(self, url: str, actions: list = None,
                          worker: str = None, timeout: int = 60) -> str:
        return self.assign({
            "task_type": "playwright", "url": url,
            "actions": actions or [{"action": "screenshot"}],
            "timeout": timeout,
        }, worker)

    # ------------------------------------------------------------------
    # Monitoring
    # ------------------------------------------------------------------

    def workers(self) -> dict:
        """Get all registered workers and their status."""
        raw = self.r.hgetall("boss:workers")
        return {k: json.loads(v) for k, v in raw.items()}

    def results(self) -> dict:
        """Get all task results."""
        raw = self.r.hgetall("boss:results")
        return {k: json.loads(v) for k, v in raw.items()}

    def get_result(self, task_id: str) -> dict | None:
        """Get result for a specific task."""
        raw = self.r.hget("boss:results", task_id)
        return json.loads(raw) if raw else None

    def wait_for(self, task_id: str, timeout: int = 120, poll: float = 1.0) -> dict:
        """Block until a task completes or times out."""
        deadline = time.time() + timeout
        while time.time() < deadline:
            result = self.get_result(task_id)
            if result and result.get("status") in ("completed", "failed"):
                return result
            time.sleep(poll)
        return {"status": "timeout", "task_id": task_id}

    def collect_completed(self, max_items: int = 100) -> list:
        """Pop completed task results from the stream."""
        results = []
        for _ in range(max_items):
            raw = self.r.lpop("boss:completed")
            if not raw:
                break
            results.append(json.loads(raw))
        return results

    # ------------------------------------------------------------------
    # Plan execution — run multiple tasks with dependencies
    # ------------------------------------------------------------------

    def run_plan(self, plan: list) -> dict:
        """
        Execute a plan — list of tasks with optional dependencies.

        Each entry:
            {
                "name": "task name",
                "task_type": "shell",
                "cmd": "...",
                "worker": "worker-1",    # optional
                "depends_on": ["other"],  # optional — wait for these first
            }

        Returns dict of {name: result}.
        """
        completed = {}
        task_ids = {}
        pending = list(plan)

        while pending:
            # Find tasks whose dependencies are satisfied
            ready = []
            still_pending = []
            for task in pending:
                deps = task.get("depends_on", [])
                if all(d in completed for d in deps):
                    ready.append(task)
                else:
                    still_pending.append(task)
            pending = still_pending

            if not ready and pending:
                log.error(f"Deadlock: {len(pending)} tasks waiting on unresolvable deps")
                break

            # Assign all ready tasks
            for task in ready:
                name = task.pop("name", task.get("task_id", "unnamed"))
                worker = task.pop("worker", None)
                task.pop("depends_on", None)
                tid = self.assign(task, worker=worker)
                task_ids[name] = tid
                log.info(f"Plan: dispatched '{name}' as {tid}")

            # Wait for all dispatched tasks in this wave
            for name, tid in list(task_ids.items()):
                if name not in completed:
                    result = self.wait_for(tid, timeout=600)
                    completed[name] = result
                    log.info(f"Plan: '{name}' -> {result.get('status')}")

        return completed

    # ------------------------------------------------------------------
    # Docker management
    # ------------------------------------------------------------------

    def scale_workers(self, count: int, compose_file: str = None):
        """Scale worker containers via docker compose."""
        compose = compose_file or str(
            Path(__file__).parent.parent / "docker-compose.boss.yml"
        )
        cmd = ["docker", "compose", "-f", compose, "up", "-d", "--scale", f"worker={count}"]
        log.info(f"Scaling to {count} workers")
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            log.error(f"Scale failed: {result.stderr}")
        return result.returncode == 0

    def teardown(self, compose_file: str = None):
        """Stop and remove all worker containers."""
        compose = compose_file or str(
            Path(__file__).parent.parent / "docker-compose.boss.yml"
        )
        cmd = ["docker", "compose", "-f", compose, "down"]
        log.info("Tearing down workers")
        subprocess.run(cmd)
        # Clean Redis state
        self.r.delete("boss:workers", "boss:results", "boss:completed",
                       "boss:tasks:any")


def cli():
    parser = argparse.ArgumentParser(description="Boss Agent Orchestrator")
    sub = parser.add_subparsers(dest="command")

    # assign
    assign_p = sub.add_parser("assign", help="Assign a task to a worker")
    assign_p.add_argument("--worker", "-w", help="Target worker ID (omit for any)")
    assign_p.add_argument("--type", "-t", default="shell", choices=["shell", "python", "playwright"])
    assign_p.add_argument("--cmd", "-c", help="Shell command")
    assign_p.add_argument("--module", "-m", help="Python module")
    assign_p.add_argument("--function", "-f", help="Python function")
    assign_p.add_argument("--kwargs", help="JSON kwargs for python task")
    assign_p.add_argument("--url", help="URL for playwright task")
    assign_p.add_argument("--timeout", type=int, default=300)

    # status
    sub.add_parser("status", help="Show worker status")

    # results
    sub.add_parser("results", help="Show all task results")

    # wait
    wait_p = sub.add_parser("wait", help="Wait for a task to complete")
    wait_p.add_argument("task_id")
    wait_p.add_argument("--timeout", type=int, default=120)

    # scale
    scale_p = sub.add_parser("scale", help="Scale worker count")
    scale_p.add_argument("count", type=int)
    scale_p.add_argument("--compose", help="Path to compose file")

    # plan
    plan_p = sub.add_parser("run-plan", help="Execute a task plan from JSON file")
    plan_p.add_argument("plan_file")

    # teardown
    sub.add_parser("teardown", help="Stop all workers and clean up")

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        return

    boss = Boss()

    if args.command == "assign":
        if args.type == "shell":
            tid = boss.assign_shell(args.cmd, worker=args.worker, timeout=args.timeout)
        elif args.type == "python":
            kwargs = json.loads(args.kwargs) if args.kwargs else {}
            tid = boss.assign_python(args.module, args.function, kwargs,
                                     worker=args.worker, timeout=args.timeout)
        elif args.type == "playwright":
            tid = boss.assign_playwright(args.url, worker=args.worker, timeout=args.timeout)
        print(f"Assigned: {tid}")

    elif args.command == "status":
        workers = boss.workers()
        if not workers:
            print("No workers registered")
        for wid, info in workers.items():
            print(f"  {wid}: {info.get('status')} (heartbeat: {info.get('last_heartbeat', 'n/a')})")

    elif args.command == "results":
        results = boss.results()
        if not results:
            print("No results yet")
        for tid, info in results.items():
            status = info.get("status")
            elapsed = info.get("elapsed_seconds", "?")
            print(f"  {tid}: {status} ({elapsed}s) worker={info.get('worker', '?')}")

    elif args.command == "wait":
        result = boss.wait_for(args.task_id, timeout=args.timeout)
        print(json.dumps(result, indent=2))

    elif args.command == "scale":
        boss.scale_workers(args.count, compose_file=args.compose)

    elif args.command == "run-plan":
        with open(args.plan_file) as f:
            plan = json.load(f)
        results = boss.run_plan(plan)
        print(json.dumps(results, indent=2, default=str))

    elif args.command == "teardown":
        boss.teardown()
        print("Torn down")


if __name__ == "__main__":
    cli()
