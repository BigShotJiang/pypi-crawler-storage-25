#!/usr/bin/env python3
"""
session_merge.py — Scoped session writes + dedup merge into master brain.

Workers write results to their own scoped session files. Boss collects all
worker outputs, deduplicates by content hash, scores by relevance + recency,
and merges the best results into the master aibrain.db.

Architecture (inspired by CrewAI MemoryScope + LangGraph reducers):
- Each worker writes to: /sessions/{session_id}/{worker_id}/{task_id}.json
- Workers NEVER write to master brain directly
- Boss reads all worker scopes after tasks complete
- Merge: collect → deduplicate → score → insert into brain

Usage:
    merger = SessionMerger(brain_db_path="aibrain.db", sessions_dir="boss/sessions")
    merger.collect_session("boss-20260404-143022")
    merger.merge_to_brain(dry_run=True)  # preview what would be inserted
    merger.merge_to_brain(dry_run=False) # actually merge
"""

import hashlib
import json
import logging
import os
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

log = logging.getLogger("boss.session_merge")


class SessionRecord:
    """A single finding/memory from a worker session."""

    def __init__(self, worker_id: str, task_id: str, content: dict):
        self.worker_id = worker_id
        self.task_id = task_id
        self.skill = content.get("skill", "unknown")
        self.status = content.get("status", "unknown")
        self.summary = content.get("summary", "")
        self.findings = content.get("findings", [])
        self.errors = content.get("errors", [])
        self.elapsed = content.get("elapsed_seconds", 0)
        self.timestamp = content.get("completed", datetime.now(timezone.utc).isoformat())
        self.raw = content

        # Content hash for dedup — based on skill + summary + sorted findings
        hash_input = json.dumps({
            "skill": self.skill,
            "summary": self.summary,
            "findings": sorted([f.get("item", "") for f in self.findings]),
        }, sort_keys=True)
        self.content_hash = hashlib.sha256(hash_input.encode()).hexdigest()[:16]

    @property
    def score(self) -> float:
        """Relevance score: more findings + successful + recent = higher score."""
        s = 0.0
        # Base score for completion
        if self.status == "completed":
            s += 1.0
        elif self.status == "escalated":
            s += 0.5  # escalations are still valuable intel

        # Finding count (diminishing returns)
        s += min(len(self.findings) * 0.3, 3.0)

        # Severity bonus
        severity_weights = {"critical": 1.0, "high": 0.7, "medium": 0.4, "low": 0.1}
        for f in self.findings:
            s += severity_weights.get(f.get("severity", ""), 0.1)

        return round(s, 2)

    def to_memory(self) -> dict:
        """Convert to a brain memory record for insertion."""
        finding_text = "\n".join(
            f"- [{f.get('severity', '?')}] {f.get('item', '?')}: {f.get('detail', '')}"
            for f in self.findings
        )
        return {
            "name": f"{self.skill} — {self.summary[:80]}",
            "type": "reference",
            "tags": f"{self.skill},worker-{self.worker_id},{self.task_id}",
            "content": f"Source: worker-{self.worker_id}, task {self.task_id}\n"
                       f"Skill: {self.skill}\n"
                       f"Status: {self.status}\n"
                       f"Summary: {self.summary}\n"
                       f"Findings:\n{finding_text}\n"
                       f"Elapsed: {self.elapsed}s",
        }


class SessionMerger:
    """Collects worker session outputs and merges into the master brain."""

    def __init__(self, brain_db_path: str, sessions_dir: str = "boss/sessions"):
        self.brain_db_path = Path(brain_db_path)
        self.sessions_dir = Path(sessions_dir)
        self.records: list[SessionRecord] = []
        self.deduped: list[SessionRecord] = []

    def write_worker_output(self, session_id: str, worker_id: str,
                            task_id: str, result: dict):
        """Write a worker's task result to its scoped session directory.

        Called by the boss after receiving a result from Redis.
        Creates: sessions/{session_id}/{worker_id}/{task_id}.json
        """
        scope_dir = self.sessions_dir / session_id / worker_id
        scope_dir.mkdir(parents=True, exist_ok=True)

        output_path = scope_dir / f"{task_id}.json"
        with open(output_path, "w") as f:
            json.dump(result, f, indent=2, default=str)

        log.info(f"Wrote worker output: {output_path}")
        return output_path

    def collect_session(self, session_id: str) -> list[SessionRecord]:
        """Collect all worker outputs from a session into records."""
        session_dir = self.sessions_dir / session_id
        if not session_dir.exists():
            log.warning(f"Session dir not found: {session_dir}")
            return []

        self.records = []
        for worker_dir in sorted(session_dir.iterdir()):
            if not worker_dir.is_dir():
                continue
            worker_id = worker_dir.name
            for task_file in sorted(worker_dir.glob("*.json")):
                task_id = task_file.stem
                try:
                    with open(task_file) as f:
                        content = json.load(f)
                    record = SessionRecord(worker_id, task_id, content)
                    self.records.append(record)
                    log.debug(f"Collected: {worker_id}/{task_id} "
                              f"(score={record.score}, hash={record.content_hash})")
                except (json.JSONDecodeError, KeyError) as e:
                    log.error(f"Bad session file {task_file}: {e}")

        log.info(f"Collected {len(self.records)} records from session {session_id}")
        return self.records

    def deduplicate(self) -> list[SessionRecord]:
        """Deduplicate records by content hash. Keep highest-scoring version."""
        seen: dict[str, SessionRecord] = {}
        for record in self.records:
            key = record.content_hash
            if key not in seen or record.score > seen[key].score:
                seen[key] = record

        self.deduped = sorted(seen.values(), key=lambda r: r.score, reverse=True)
        removed = len(self.records) - len(self.deduped)
        if removed > 0:
            log.info(f"Deduplicated: {len(self.records)} → {len(self.deduped)} "
                     f"({removed} duplicates removed)")
        return self.deduped

    def detect_conflicts(self) -> list[dict]:
        """Find records from different workers that cover the same skill+target
        but reached different conclusions. These need human review or synthesis."""
        conflicts = []
        by_skill: dict[str, list[SessionRecord]] = {}

        for record in self.deduped:
            by_skill.setdefault(record.skill, []).append(record)

        for skill, records in by_skill.items():
            if len(records) < 2:
                continue

            # Check if findings differ significantly
            finding_sets = []
            for r in records:
                items = frozenset(f.get("item", "") for f in r.findings)
                finding_sets.append((r, items))

            for i, (r1, s1) in enumerate(finding_sets):
                for r2, s2 in finding_sets[i + 1:]:
                    # If one worker found things the other didn't
                    only_in_1 = s1 - s2
                    only_in_2 = s2 - s1
                    if only_in_1 or only_in_2:
                        conflicts.append({
                            "skill": skill,
                            "worker_a": r1.worker_id,
                            "worker_b": r2.worker_id,
                            "only_in_a": list(only_in_1),
                            "only_in_b": list(only_in_2),
                            "common": list(s1 & s2),
                        })

        if conflicts:
            log.warning(f"Found {len(conflicts)} conflicts needing review")
        return conflicts

    def merge_to_brain(self, dry_run: bool = True,
                       min_score: float = 0.5) -> dict:
        """Merge deduped session records into the master brain.

        Args:
            dry_run: If True, preview what would be inserted without writing.
            min_score: Minimum score threshold for insertion.

        Returns:
            Summary dict with counts and any conflicts.
        """
        if not self.deduped:
            self.deduplicate()

        # Filter by score
        worthy = [r for r in self.deduped if r.score >= min_score]
        skipped = [r for r in self.deduped if r.score < min_score]
        conflicts = self.detect_conflicts()

        summary = {
            "total_collected": len(self.records),
            "after_dedup": len(self.deduped),
            "worthy_of_merge": len(worthy),
            "below_threshold": len(skipped),
            "conflicts": len(conflicts),
            "conflict_details": conflicts,
            "inserted": 0,
            "dry_run": dry_run,
        }

        if dry_run:
            log.info(f"DRY RUN: would merge {len(worthy)} records into brain")
            for r in worthy:
                log.info(f"  [{r.score}] {r.skill}: {r.summary[:60]}")
            summary["preview"] = [
                {"skill": r.skill, "score": r.score, "summary": r.summary[:80]}
                for r in worthy
            ]
            return summary

        # Actual merge
        if not self.brain_db_path.exists():
            log.error(f"Brain DB not found: {self.brain_db_path}")
            summary["error"] = "Brain DB not found"
            return summary

        now = datetime.now(timezone.utc).isoformat()
        inserted = 0

        db = sqlite3.connect(str(self.brain_db_path))
        db.execute("PRAGMA journal_mode=WAL")
        try:
            for record in worthy:
                mem = record.to_memory()
                # Check for existing memory with same name (avoid true duplicates)
                existing = db.execute(
                    "SELECT id FROM memories WHERE name = ? AND active = 1",
                    (mem["name"],)
                ).fetchone()

                if existing:
                    log.debug(f"Skipping existing memory: {mem['name'][:50]}")
                    continue

                db.execute(
                    "INSERT INTO memories (name, type, tags, content, created, updated, active) "
                    "VALUES (?, ?, ?, ?, ?, ?, 1)",
                    (mem["name"], mem["type"], mem["tags"], mem["content"], now, now)
                )
                inserted += 1

            db.commit()
            log.info(f"Merged {inserted} new records into brain")
        except sqlite3.Error as e:
            log.error(f"Brain merge failed: {e}")
            db.rollback()
            summary["error"] = str(e)
        finally:
            db.close()

        summary["inserted"] = inserted
        return summary

    def generate_session_report(self, session_id: str) -> dict:
        """Generate a complete session report for the boss."""
        conflicts = self.detect_conflicts()
        escalations = [r for r in self.records if r.status == "escalated"]
        failures = [r for r in self.records if r.status == "failed"]

        return {
            "session_id": session_id,
            "total_records": len(self.records),
            "unique_records": len(self.deduped) if self.deduped else "not yet deduped",
            "by_worker": {
                wid: len([r for r in self.records if r.worker_id == wid])
                for wid in set(r.worker_id for r in self.records)
            },
            "by_skill": {
                skill: len([r for r in self.records if r.skill == skill])
                for skill in set(r.skill for r in self.records)
            },
            "escalations": [
                {"worker": r.worker_id, "task": r.task_id, "summary": r.summary}
                for r in escalations
            ],
            "failures": [
                {"worker": r.worker_id, "task": r.task_id, "errors": r.errors}
                for r in failures
            ],
            "conflicts": conflicts,
            "top_findings": [
                {"score": r.score, "skill": r.skill, "summary": r.summary[:80]}
                for r in sorted(self.records, key=lambda r: r.score, reverse=True)[:10]
            ],
        }
