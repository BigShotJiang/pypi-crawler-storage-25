#!/usr/bin/env python3
"""
evolution_bridge.py — Bridge between Docker workers and skill evolution system.

Workers report skill execution metrics via Redis. Boss collects and feeds
them into SkillManager.record_execution() so the brain learns from
parallel worker runs.

The key insight: 4 workers running skills for 8 hours = 32 hours of execution
data feeding one brain. Skills evolve 4x faster.

Usage (worker side — add to worker_runner.py):
    from boss.evolution_bridge import report_execution
    report_execution(redis_client, worker_id, skill_name, success, tokens, duration)

Usage (boss side — run after session):
    bridge = EvolutionBridge(redis_url, brain_db_path)
    stats = bridge.collect_and_apply()
"""

import json
import logging
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

import redis

# Add project root to path for aibrain imports
_project_root = Path(__file__).parent.parent
if str(_project_root) not in sys.path:
    sys.path.insert(0, str(_project_root))

log = logging.getLogger("boss.evolution_bridge")

EVOLUTION_QUEUE = "boss:evolution"


def report_execution(r: redis.Redis, worker_id: str, skill_name: str,
                     success: bool, tokens_used: int = 0,
                     duration_seconds: float = 0.0, error_message: str = "",
                     execution_context: str = ""):
    """Called by workers to report skill execution metrics to Redis.

    This is the worker-side function. It pushes execution data to a Redis
    list that the boss consumes after the session.
    """
    record = {
        "worker_id": worker_id,
        "skill_name": skill_name,
        "success": success,
        "tokens_used": tokens_used,
        "duration_seconds": round(duration_seconds, 2),
        "error_message": error_message,
        "execution_context": execution_context,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }
    r.rpush(EVOLUTION_QUEUE, json.dumps(record))
    log.debug(f"Reported execution: {skill_name} ({'OK' if success else 'FAIL'}) "
              f"by {worker_id} in {duration_seconds:.1f}s")


class EvolutionBridge:
    """Boss-side bridge that feeds worker execution data into SkillManager."""

    def __init__(self, redis_url: str, brain_db_path: str):
        self.r = redis.from_url(redis_url, decode_responses=True)
        self.brain_db_path = brain_db_path
        self._manager = None

    @property
    def manager(self):
        """Lazy-load SkillManager to avoid import issues in workers."""
        if self._manager is None:
            from aibrain_skill_evolution import SkillManager
            self._manager = SkillManager(self.brain_db_path)
        return self._manager

    def collect_pending(self) -> list[dict]:
        """Collect all pending execution reports from Redis."""
        records = []
        while True:
            raw = self.r.lpop(EVOLUTION_QUEUE)
            if not raw:
                break
            try:
                records.append(json.loads(raw))
            except json.JSONDecodeError as e:
                log.error(f"Bad evolution record: {e}")
        return records

    def apply_to_brain(self, records: list[dict]) -> dict:
        """Feed collected execution records into SkillManager.

        Returns stats about what was applied.
        """
        stats = {
            "total": len(records),
            "applied": 0,
            "failed": 0,
            "by_skill": {},
            "by_worker": {},
        }

        for record in records:
            skill = record.get("skill_name", "unknown")
            worker = record.get("worker_id", "unknown")

            try:
                self.manager.record_execution(
                    skill_name=skill,
                    success=record.get("success", False),
                    tokens_used=record.get("tokens_used", 0),
                    duration=record.get("duration_seconds", 0.0),
                    error_message=record.get("error_message", ""),
                    context=record.get("execution_context", ""),
                )
                stats["applied"] += 1

                # Track per-skill stats
                if skill not in stats["by_skill"]:
                    stats["by_skill"][skill] = {"runs": 0, "success": 0, "fail": 0}
                stats["by_skill"][skill]["runs"] += 1
                if record.get("success"):
                    stats["by_skill"][skill]["success"] += 1
                else:
                    stats["by_skill"][skill]["fail"] += 1

                # Track per-worker stats
                if worker not in stats["by_worker"]:
                    stats["by_worker"][worker] = {"runs": 0, "total_tokens": 0}
                stats["by_worker"][worker]["runs"] += 1
                stats["by_worker"][worker]["total_tokens"] += record.get("tokens_used", 0)

            except Exception as e:
                log.error(f"Failed to apply execution record for {skill}: {e}")
                stats["failed"] += 1

        log.info(f"Evolution bridge: applied {stats['applied']}/{stats['total']} "
                 f"records across {len(stats['by_skill'])} skills")
        return stats

    def collect_and_apply(self) -> dict:
        """One-shot: collect all pending records and apply to brain."""
        records = self.collect_pending()
        if not records:
            log.info("No pending evolution records")
            return {"total": 0, "applied": 0}
        return self.apply_to_brain(records)

    def get_skill_health_summary(self) -> dict:
        """Get health summary for all skills that have execution data."""
        try:
            # Query skill_executions table directly for aggregate stats
            import sqlite3
            db = sqlite3.connect(self.brain_db_path)
            db.row_factory = sqlite3.Row

            rows = db.execute("""
                SELECT skill_name,
                       COUNT(*) as total_runs,
                       SUM(CASE WHEN success = 1 THEN 1 ELSE 0 END) as successes,
                       AVG(duration_seconds) as avg_duration,
                       SUM(tokens_used) as total_tokens,
                       MAX(created) as last_run
                FROM skill_executions
                GROUP BY skill_name
                ORDER BY total_runs DESC
            """).fetchall()
            db.close()

            return {
                row["skill_name"]: {
                    "total_runs": row["total_runs"],
                    "success_rate": round(row["successes"] / row["total_runs"], 2)
                        if row["total_runs"] > 0 else 0,
                    "avg_duration": round(row["avg_duration"], 1)
                        if row["avg_duration"] else 0,
                    "total_tokens": row["total_tokens"] or 0,
                    "last_run": row["last_run"],
                }
                for row in rows
            }
        except Exception as e:
            log.error(f"Failed to get skill health: {e}")
            return {}
