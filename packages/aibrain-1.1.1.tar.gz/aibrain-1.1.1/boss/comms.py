#!/usr/bin/env python3
"""
comms.py — Central message thread for boss-worker communication.

Pattern: AutoGen-inspired central thread. All comms go through the boss.
No peer-to-peer. Workers publish to a shared stream, boss routes and responds.

Message types:
    progress  — worker reporting task progress (e.g., "50% done, 3/6 files scanned")
    question  — worker asking boss for guidance (blocks until boss responds)
    alert     — worker flagging something urgent (doesn't block)
    broadcast — boss sending to all workers (abort, redirect, config change)
    response  — boss answering a worker question

Usage (worker side):
    comms = WorkerComms(redis_url, worker_id)
    comms.send_progress(task_id, 0.5, "Scanned 3/6 files")
    answer = comms.ask_boss(task_id, "Found credentials — escalate or continue?")
    comms.send_alert(task_id, "OOM warning — 85% memory usage")

Usage (boss side):
    comms = BossComms(redis_url)
    messages = comms.read_messages(count=10)
    comms.respond_to_worker(worker_id, msg_id, "Escalate — stop immediately")
    comms.broadcast("abort", "Session cancelled by user")
"""

import json
import logging
import time
import secrets
from datetime import datetime, timezone

import redis

log = logging.getLogger("boss.comms")

# Redis keys
STREAM_KEY = "boss:comms:stream"      # main message thread (workers → boss)
BROADCAST_KEY = "boss:comms:broadcast"  # boss → all workers
RESPONSE_PREFIX = "boss:comms:response:"  # boss → specific worker (per-worker channel)


class WorkerComms:
    """Communication channel for workers to talk to the boss."""

    def __init__(self, redis_url: str, worker_id: str):
        self.r = redis.from_url(redis_url, decode_responses=True)
        self.worker_id = worker_id
        self._response_key = f"{RESPONSE_PREFIX}{worker_id}"

    def _publish(self, msg_type: str, task_id: str, payload: dict) -> str:
        """Publish a message to the central thread."""
        msg_id = f"msg-{secrets.token_hex(4)}"
        message = {
            "msg_id": msg_id,
            "type": msg_type,
            "worker_id": self.worker_id,
            "task_id": task_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "payload": json.dumps(payload),
        }
        self.r.xadd(STREAM_KEY, message)
        return msg_id

    def send_progress(self, task_id: str, pct: float, detail: str = ""):
        """Report task progress. Non-blocking."""
        self._publish("progress", task_id, {
            "percent": round(pct, 2),
            "detail": detail,
        })

    def send_alert(self, task_id: str, message: str, severity: str = "warning"):
        """Flag something urgent. Non-blocking."""
        self._publish("alert", task_id, {
            "message": message,
            "severity": severity,
        })

    def ask_boss(self, task_id: str, question: str, timeout: int = 120) -> str | None:
        """Ask the boss a question and BLOCK until response or timeout.

        Returns the boss's response string, or None on timeout.
        """
        msg_id = self._publish("question", task_id, {"question": question})

        # Wait for response on our dedicated channel
        deadline = time.time() + timeout
        while time.time() < deadline:
            raw = self.r.lpop(self._response_key)
            if raw:
                response = json.loads(raw)
                if response.get("in_reply_to") == msg_id:
                    return response.get("answer")
                # Not our response — push it back (rare race condition)
                self.r.rpush(self._response_key, raw)
            time.sleep(0.5)

        log.warning(f"Question timed out after {timeout}s: {question[:50]}")
        return None

    def check_broadcast(self) -> list[dict]:
        """Check for broadcast messages from boss. Non-blocking."""
        messages = []
        while True:
            raw = self.r.lpop(f"{BROADCAST_KEY}:{self.worker_id}")
            if not raw:
                break
            messages.append(json.loads(raw))
        return messages


class BossComms:
    """Communication channel for the boss to manage workers."""

    def __init__(self, redis_url: str):
        self.r = redis.from_url(redis_url, decode_responses=True)
        self._last_id = "0-0"  # stream cursor for reading messages

    def read_messages(self, count: int = 50, block_ms: int = 0) -> list[dict]:
        """Read new messages from the central thread.

        Args:
            count: Max messages to read.
            block_ms: Block for this many ms waiting for messages (0 = don't block).

        Returns list of message dicts.
        """
        results = self.r.xread(
            {STREAM_KEY: self._last_id},
            count=count,
            block=block_ms if block_ms > 0 else None,
        )

        messages = []
        if results:
            for stream_name, entries in results:
                for entry_id, fields in entries:
                    self._last_id = entry_id
                    msg = dict(fields)
                    if "payload" in msg:
                        msg["payload"] = json.loads(msg["payload"])
                    msg["stream_id"] = entry_id
                    messages.append(msg)

        return messages

    def read_questions(self, count: int = 50) -> list[dict]:
        """Read only unanswered questions from the stream."""
        all_msgs = self.read_messages(count=count)
        return [m for m in all_msgs if m.get("type") == "question"]

    def respond_to_worker(self, worker_id: str, msg_id: str, answer: str):
        """Send a response to a specific worker's question."""
        response = {
            "in_reply_to": msg_id,
            "answer": answer,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        self.r.rpush(f"{RESPONSE_PREFIX}{worker_id}", json.dumps(response))
        log.info(f"Responded to {worker_id} (msg {msg_id}): {answer[:50]}")

    def broadcast(self, action: str, detail: str = "", workers: list[str] = None):
        """Send a message to all workers (or specific workers).

        Actions: abort, redirect, config_update, pause, resume
        """
        message = {
            "action": action,
            "detail": detail,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        payload = json.dumps(message)

        if workers:
            for wid in workers:
                self.r.rpush(f"{BROADCAST_KEY}:{wid}", payload)
            log.info(f"Broadcast '{action}' to {len(workers)} workers")
        else:
            # Get all registered workers
            all_workers = self.r.hkeys("boss:workers")
            for wid in all_workers:
                self.r.rpush(f"{BROADCAST_KEY}:{wid}", payload)
            log.info(f"Broadcast '{action}' to all {len(all_workers)} workers")

    def get_progress_summary(self) -> dict:
        """Get latest progress from all workers by reading the stream tail."""
        # Read last 200 messages
        entries = self.r.xrevrange(STREAM_KEY, count=200)
        latest_progress: dict[str, dict] = {}

        for entry_id, fields in entries:
            if fields.get("type") == "progress":
                wid = fields.get("worker_id", "unknown")
                if wid not in latest_progress:
                    payload = json.loads(fields.get("payload", "{}"))
                    latest_progress[wid] = {
                        "worker_id": wid,
                        "task_id": fields.get("task_id"),
                        "percent": payload.get("percent", 0),
                        "detail": payload.get("detail", ""),
                        "timestamp": fields.get("timestamp"),
                    }

        return latest_progress

    def get_alerts(self, since_id: str = "0-0") -> list[dict]:
        """Get all alerts since a given stream ID."""
        entries = self.r.xrange(STREAM_KEY, min=since_id)
        alerts = []
        for entry_id, fields in entries:
            if fields.get("type") == "alert":
                payload = json.loads(fields.get("payload", "{}"))
                alerts.append({
                    "stream_id": entry_id,
                    "worker_id": fields.get("worker_id"),
                    "task_id": fields.get("task_id"),
                    "message": payload.get("message"),
                    "severity": payload.get("severity"),
                    "timestamp": fields.get("timestamp"),
                })
        return alerts
