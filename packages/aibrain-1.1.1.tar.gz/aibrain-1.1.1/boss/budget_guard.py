#!/usr/bin/env python3
"""
budget_guard.py — Token limits, iteration guards, checkpoints, and dead-letter queue.

Every worker gets a budget. Exceed it → hard kill. Fail 3x → dead-letter.
Checkpoints save state after each phase so crashed workers can resume.

Inspired by: Temporal.io (retry + dead-letter), LangGraph (checkpoint/replay).

Usage (worker side):
    guard = WorkerBudget(redis_url, worker_id, token_limit=50000, iteration_limit=20)
    guard.track_tokens(1200)        # returns False if over budget
    guard.track_iteration()          # returns False if over limit
    guard.checkpoint(task_id, phase, state_dict)  # save progress
    state = guard.restore(task_id)   # get last checkpoint

Usage (boss side):
    budget = BossBudgetManager(redis_url)
    budget.set_worker_budget(worker_id, token_limit=50000, iteration_limit=20)
    overages = budget.check_overages()  # which workers exceeded budget
    dead = budget.get_dead_letters()    # tasks that failed 3x
    budget.requeue_dead_letter(task_id) # manual retry after investigation
"""

import json
import logging
import time
from datetime import datetime, timezone

import redis

log = logging.getLogger("boss.budget_guard")

BUDGET_PREFIX = "boss:budget:"
CHECKPOINT_PREFIX = "boss:checkpoint:"
DEAD_LETTER_KEY = "boss:dead_letters"
FAIL_COUNT_PREFIX = "boss:fail_count:"

MAX_FAILURES = 3  # dead-letter threshold


class WorkerBudget:
    """Worker-side budget tracking and checkpointing."""

    def __init__(self, redis_url: str, worker_id: str,
                 token_limit: int = 50000, iteration_limit: int = 50):
        self.r = redis.from_url(redis_url, decode_responses=True)
        self.worker_id = worker_id
        self.token_limit = token_limit
        self.iteration_limit = iteration_limit
        self._budget_key = f"{BUDGET_PREFIX}{worker_id}"

        # Initialize counters if not present
        if not self.r.exists(self._budget_key):
            self.r.hset(self._budget_key, mapping={
                "tokens_used": 0,
                "iterations": 0,
                "token_limit": token_limit,
                "iteration_limit": iteration_limit,
                "status": "active",
                "started": datetime.now(timezone.utc).isoformat(),
            })
            self.r.expire(self._budget_key, 86400)  # 24hr TTL

    def track_tokens(self, tokens: int) -> bool:
        """Track token usage. Returns False if over budget (worker should stop)."""
        new_total = self.r.hincrby(self._budget_key, "tokens_used", tokens)
        limit = int(self.r.hget(self._budget_key, "token_limit") or self.token_limit)

        if new_total > limit:
            self.r.hset(self._budget_key, "status", "over_budget")
            log.warning(f"Worker {self.worker_id} OVER TOKEN BUDGET: "
                        f"{new_total}/{limit}")
            return False
        return True

    def track_iteration(self) -> bool:
        """Track iteration count. Returns False if over limit (worker should stop)."""
        new_count = self.r.hincrby(self._budget_key, "iterations", 1)
        limit = int(self.r.hget(self._budget_key, "iteration_limit") or self.iteration_limit)

        if new_count > limit:
            self.r.hset(self._budget_key, "status", "over_iterations")
            log.warning(f"Worker {self.worker_id} OVER ITERATION LIMIT: "
                        f"{new_count}/{limit}")
            return False
        return True

    def get_usage(self) -> dict:
        """Get current budget usage."""
        raw = self.r.hgetall(self._budget_key)
        return {
            "tokens_used": int(raw.get("tokens_used", 0)),
            "token_limit": int(raw.get("token_limit", self.token_limit)),
            "iterations": int(raw.get("iterations", 0)),
            "iteration_limit": int(raw.get("iteration_limit", self.iteration_limit)),
            "status": raw.get("status", "unknown"),
        }

    def is_within_budget(self) -> bool:
        """Quick check: is this worker still within budget?"""
        status = self.r.hget(self._budget_key, "status")
        return status == "active"

    # ------------------------------------------------------------------
    # Checkpointing
    # ------------------------------------------------------------------

    def checkpoint(self, task_id: str, phase: int, state: dict):
        """Save a checkpoint for the current task phase.

        Workers should call this after completing each phase so that
        if they crash, the boss can reassign with the last known state.
        """
        checkpoint_data = {
            "worker_id": self.worker_id,
            "task_id": task_id,
            "phase": phase,
            "state": json.dumps(state, default=str),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        key = f"{CHECKPOINT_PREFIX}{task_id}"
        self.r.hset(key, mapping=checkpoint_data)
        self.r.expire(key, 86400)  # 24hr TTL
        log.debug(f"Checkpoint saved: {task_id} phase {phase}")

    def restore(self, task_id: str) -> dict | None:
        """Restore the last checkpoint for a task.

        Returns dict with phase + state, or None if no checkpoint exists.
        """
        key = f"{CHECKPOINT_PREFIX}{task_id}"
        raw = self.r.hgetall(key)
        if not raw:
            return None

        return {
            "phase": int(raw.get("phase", 0)),
            "state": json.loads(raw.get("state", "{}")),
            "worker_id": raw.get("worker_id"),
            "timestamp": raw.get("timestamp"),
        }


class BossBudgetManager:
    """Boss-side budget management, dead-letter queue, and checkpoint handling."""

    def __init__(self, redis_url: str):
        self.r = redis.from_url(redis_url, decode_responses=True)

    def set_worker_budget(self, worker_id: str, token_limit: int = 50000,
                          iteration_limit: int = 50):
        """Set or update a worker's budget limits."""
        key = f"{BUDGET_PREFIX}{worker_id}"
        self.r.hset(key, mapping={
            "token_limit": token_limit,
            "iteration_limit": iteration_limit,
        })
        log.info(f"Set budget for {worker_id}: {token_limit} tokens, "
                 f"{iteration_limit} iterations")

    def get_all_budgets(self) -> dict:
        """Get budget status for all workers."""
        budgets = {}
        for key in self.r.scan_iter(f"{BUDGET_PREFIX}*"):
            worker_id = key.replace(BUDGET_PREFIX, "")
            raw = self.r.hgetall(key)
            budgets[worker_id] = {
                "tokens_used": int(raw.get("tokens_used", 0)),
                "token_limit": int(raw.get("token_limit", 50000)),
                "iterations": int(raw.get("iterations", 0)),
                "iteration_limit": int(raw.get("iteration_limit", 50)),
                "status": raw.get("status", "unknown"),
            }
        return budgets

    def check_overages(self) -> list[str]:
        """Return list of worker IDs that exceeded their budget."""
        overages = []
        for worker_id, budget in self.get_all_budgets().items():
            if budget["status"] in ("over_budget", "over_iterations"):
                overages.append(worker_id)
        return overages

    # ------------------------------------------------------------------
    # Dead-letter queue
    # ------------------------------------------------------------------

    def record_failure(self, task_id: str, worker_id: str, error: str) -> int:
        """Record a task failure. Returns current failure count.

        If count reaches MAX_FAILURES, task is moved to dead-letter queue.
        """
        fail_key = f"{FAIL_COUNT_PREFIX}{task_id}"
        count = self.r.incr(fail_key)
        self.r.expire(fail_key, 86400)

        if count >= MAX_FAILURES:
            dead_entry = {
                "task_id": task_id,
                "last_worker": worker_id,
                "failure_count": count,
                "last_error": error,
                "dead_lettered": datetime.now(timezone.utc).isoformat(),
            }
            self.r.rpush(DEAD_LETTER_KEY, json.dumps(dead_entry))
            log.warning(f"Task {task_id} dead-lettered after {count} failures: {error[:100]}")
        else:
            log.info(f"Task {task_id} failure {count}/{MAX_FAILURES}: {error[:100]}")

        return count

    def get_dead_letters(self) -> list[dict]:
        """Get all dead-lettered tasks."""
        dead = []
        items = self.r.lrange(DEAD_LETTER_KEY, 0, -1)
        for item in items:
            dead.append(json.loads(item))
        return dead

    def requeue_dead_letter(self, task_id: str, task_payload: dict,
                            worker: str = None) -> bool:
        """Manually requeue a dead-lettered task after investigation.

        Resets the failure counter and pushes the task back to the queue.
        """
        # Reset failure count
        self.r.delete(f"{FAIL_COUNT_PREFIX}{task_id}")

        # Remove from dead-letter list
        items = self.r.lrange(DEAD_LETTER_KEY, 0, -1)
        for item in items:
            entry = json.loads(item)
            if entry.get("task_id") == task_id:
                self.r.lrem(DEAD_LETTER_KEY, 1, item)
                break

        # Requeue
        queue = f"boss:tasks:{worker}" if worker else "boss:tasks:any"
        task_payload["task_id"] = task_id
        task_payload["requeued"] = True
        self.r.rpush(queue, json.dumps(task_payload))
        log.info(f"Requeued dead-lettered task {task_id}")
        return True

    # ------------------------------------------------------------------
    # Checkpoint management
    # ------------------------------------------------------------------

    def get_checkpoint(self, task_id: str) -> dict | None:
        """Get the last checkpoint for a task (for reassignment after crash)."""
        key = f"{CHECKPOINT_PREFIX}{task_id}"
        raw = self.r.hgetall(key)
        if not raw:
            return None
        return {
            "phase": int(raw.get("phase", 0)),
            "state": json.loads(raw.get("state", "{}")),
            "worker_id": raw.get("worker_id"),
            "timestamp": raw.get("timestamp"),
        }

    def reassign_with_checkpoint(self, task_id: str, original_task: dict,
                                 new_worker: str = None) -> str | None:
        """Reassign a task to a new worker, including last checkpoint data.

        The new worker can resume from the checkpoint phase instead of starting over.
        """
        checkpoint = self.get_checkpoint(task_id)
        if checkpoint:
            original_task["resume_from"] = checkpoint
            log.info(f"Reassigning {task_id} with checkpoint at phase {checkpoint['phase']}")

        queue = f"boss:tasks:{new_worker}" if new_worker else "boss:tasks:any"
        original_task["task_id"] = task_id
        original_task["reassigned"] = True
        self.r.rpush(queue, json.dumps(original_task, default=str))
        return task_id

    def get_session_cost_estimate(self) -> dict:
        """Estimate total token cost across all workers this session."""
        budgets = self.get_all_budgets()
        total_tokens = sum(b["tokens_used"] for b in budgets.values())

        # Rough cost estimates (per 1K tokens, blended input+output)
        tier_costs = {
            "opus": 0.045,    # ~$15 + $75 per 1M, blended
            "sonnet": 0.009,  # ~$3 + $15 per 1M, blended
            "haiku": 0.0008,  # ~$0.25 + $1.25 per 1M, blended
        }

        return {
            "total_tokens": total_tokens,
            "by_worker": {
                wid: b["tokens_used"] for wid, b in budgets.items()
            },
            "est_cost_sonnet": round(total_tokens / 1000 * tier_costs["sonnet"], 4),
            "est_cost_haiku": round(total_tokens / 1000 * tier_costs["haiku"], 4),
            "est_cost_opus": round(total_tokens / 1000 * tier_costs["opus"], 4),
        }
