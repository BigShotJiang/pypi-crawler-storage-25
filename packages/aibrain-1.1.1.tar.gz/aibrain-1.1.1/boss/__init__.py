"""Boss Agent Orchestrator — multi-instance coordination with shared brain."""
__version__ = "0.1.0"
