#!/usr/bin/env python3
"""
memory_lifecycle.py — Intelligent Forgetting: Decay, Archival, Consolidation

Prevents memory systems from degrading over time by:
1. Decay — reduce effective importance of unaccessed memories
2. Archival — move stale memories out of active retrieval
3. Consolidation — merge related memories into authoritative summaries

Also provides cascading purge ("forget everything about X") for privacy
compliance (Privacy Act 1988, GDPR Article 17).

Usage:
    from memory_lifecycle import MemoryLifecycle
    ml = MemoryLifecycle(db_path)
    ml.decay_pass()                    # run daily
    ml.archive_stale(threshold=0.05)   # archive low-importance
    ml.forget("job search at Acme")    # cascading purge
    ml.forget_before("2026-01-01")     # time-based purge
"""

import json
import math
import sqlite3
import threading
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Optional


def _get_db(db_path) -> sqlite3.Connection:
    conn = sqlite3.connect(str(db_path), check_same_thread=False, timeout=10)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=5000")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.row_factory = sqlite3.Row
    return conn


# ---------------------------------------------------------------------------
# Decay model — half-life based importance decay
# ---------------------------------------------------------------------------

# Default half-life: 60 days. After 60 days without access, effective
# importance drops to 50% of stored importance. After 120 days, 25%.
DEFAULT_HALF_LIFE_DAYS = 60.0


def effective_importance(
    stored_importance: float,
    days_since_access: float,
    half_life: float = DEFAULT_HALF_LIFE_DAYS,
) -> float:
    """Calculate decayed importance using half-life model.

    importance_eff = importance * (0.5 ^ (days_since_access / half_life))

    Memories accessed recently retain full importance.
    Memories not accessed in 60 days have half importance.
    Memories not accessed in 180 days have ~12.5% importance.
    """
    if days_since_access <= 0:
        return stored_importance
    decay_factor = math.pow(0.5, days_since_access / half_life)
    return stored_importance * decay_factor


class MemoryLifecycle:
    """Memory lifecycle management — decay, archive, consolidate, forget."""

    def __init__(self, db_path: str | Path, half_life: float = DEFAULT_HALF_LIFE_DAYS):
        self.db_path = Path(db_path)
        self.half_life = half_life
        self._db = None

    def _get_db(self):
        if self._db is None:
            self._db = _get_db(self.db_path)
            self._ensure_columns()
        return self._db

    def _ensure_columns(self):
        """Add lifecycle columns if they don't exist."""
        db = self._db
        cols = {r[1] for r in db.execute("PRAGMA table_info(memories)").fetchall()}
        if "archived" not in cols:
            db.execute("ALTER TABLE memories ADD COLUMN archived INTEGER DEFAULT 0")
        if "effective_importance" not in cols:
            db.execute("ALTER TABLE memories ADD COLUMN effective_importance REAL DEFAULT 0.5")
        if "sensitivity" not in cols:
            db.execute("ALTER TABLE memories ADD COLUMN sensitivity TEXT DEFAULT 'standard'")
        db.commit()

    # ------------------------------------------------------------------
    # Decay Pass — recalculate effective importance for all active memories
    # ------------------------------------------------------------------

    def decay_pass(self) -> dict:
        """Recalculate effective_importance for all active memories.

        Run daily via cron. Updates effective_importance based on
        days since last access using half-life decay model.
        """
        db = self._get_db()

        rows = db.execute("""
            SELECT id, importance, last_accessed, updated
            FROM memories
            WHERE active=1 AND archived=0
        """).fetchall()

        now = datetime.now()
        updated_count = 0
        total_decay = 0.0

        for row in rows:
            last_access = row["last_accessed"] or row["updated"]
            if not last_access:
                days_since = 999
            else:
                try:
                    last_dt = datetime.fromisoformat(last_access.replace("Z", "+00:00"))
                    if last_dt.tzinfo:
                        last_dt = last_dt.replace(tzinfo=None)
                    days_since = (now - last_dt).total_seconds() / 86400
                except (ValueError, TypeError):
                    days_since = 999

            stored = row["importance"] or 0.5
            eff = effective_importance(stored, days_since, self.half_life)
            eff = round(eff, 4)

            db.execute(
                "UPDATE memories SET effective_importance=? WHERE id=?",
                (eff, row["id"])
            )
            updated_count += 1
            total_decay += (stored - eff)

        db.commit()

        return {
            "memories_updated": updated_count,
            "total_decay": round(total_decay, 2),
            "avg_decay": round(total_decay / max(updated_count, 1), 4),
        }

    # ------------------------------------------------------------------
    # Archival — move stale memories out of active retrieval
    # ------------------------------------------------------------------

    def archive_stale(self, threshold: float = 0.05) -> dict:
        """Archive memories with effective_importance below threshold.

        Archived memories remain in DB, searchable with include_archived=True,
        but excluded from default retrieval.
        """
        db = self._get_db()

        candidates = db.execute("""
            SELECT id, name, effective_importance
            FROM memories
            WHERE active=1 AND archived=0 AND effective_importance < ?
        """, (threshold,)).fetchall()

        archived = 0
        for row in candidates:
            db.execute(
                "UPDATE memories SET archived=1 WHERE id=?",
                (row["id"],)
            )
            archived += 1

        db.commit()
        return {
            "archived": archived,
            "threshold": threshold,
        }

    def unarchive(self, memory_id: int) -> bool:
        """Restore an archived memory to active status."""
        db = self._get_db()
        c = db.execute(
            "UPDATE memories SET archived=0, effective_importance=importance WHERE id=?",
            (memory_id,)
        )
        db.commit()
        return c.rowcount > 0

    # ------------------------------------------------------------------
    # Cascading Purge — "Forget Everything About X"
    # ------------------------------------------------------------------

    def forget(
        self,
        query: str,
        dry_run: bool = False,
    ) -> dict:
        """Cascading purge: find and permanently delete all traces of a topic.

        Searches across memories, then cascades to: FTS index, embedding vectors,
        passages, semantic facts + evidence, entity links. Hard delete — not recoverable.

        Args:
            query: search terms for content to forget
            dry_run: if True, report what would be deleted without deleting

        Returns dict with counts of affected records per table.
        """
        db = self._get_db()

        # Find matching memories via FTS
        matching_ids = set()
        try:
            # FTS search
            fts_words = " OR ".join(query.lower().split())
            rows = db.execute("""
                SELECT m.id FROM memories m
                JOIN memories_fts f ON m.id=f.rowid
                WHERE memories_fts MATCH ?
            """, (fts_words,)).fetchall()
            matching_ids.update(r[0] for r in rows)
        except sqlite3.OperationalError:
            pass

        # Also LIKE search for FTS edge cases
        for word in query.split():
            if len(word) >= 3:
                rows = db.execute(
                    "SELECT id FROM memories WHERE content LIKE ? OR name LIKE ? OR tags LIKE ?",
                    (f"%{word}%", f"%{word}%", f"%{word}%")
                ).fetchall()
                matching_ids.update(r[0] for r in rows)

        if not matching_ids:
            return {"found": 0, "deleted": False, "message": "No memories matched."}

        ids = list(matching_ids)

        # Preview what will be deleted
        preview = {
            "memories": len(ids),
            "passages": 0,
            "facts": 0,
            "fact_evidence": 0,
            "entity_links": 0,
            "embeddings": 0,
            "skill_episodes": 0,
        }

        ph = ",".join("?" * len(ids))

        # Count cascading records
        try:
            preview["passages"] = db.execute(
                f"SELECT COUNT(*) FROM memory_passages WHERE memory_id IN ({ph})", ids
            ).fetchone()[0]
        except sqlite3.OperationalError:
            pass

        try:
            # Find facts linked via evidence
            fact_ids = [r[0] for r in db.execute(f"""
                SELECT DISTINCT fact_id FROM fact_evidence
                WHERE source_memory_id IN ({ph})
            """, ids).fetchall()]
            preview["fact_evidence"] = len(fact_ids)

            if fact_ids:
                fph = ",".join("?" * len(fact_ids))
                preview["facts"] = db.execute(
                    f"SELECT COUNT(*) FROM semantic_facts WHERE fact_id IN ({fph})",
                    fact_ids
                ).fetchone()[0]
        except sqlite3.OperationalError:
            fact_ids = []

        try:
            preview["entity_links"] = db.execute(f"""
                SELECT COUNT(*) FROM entity_links
                WHERE (source_type='memory' AND source_id IN ({ph}))
                   OR (target_type='memory' AND target_id IN ({ph}))
            """, ids + ids).fetchone()[0]
        except sqlite3.OperationalError:
            pass

        try:
            preview["embeddings"] = db.execute(
                f"SELECT COUNT(*) FROM memories_vec WHERE memory_id IN ({ph})", ids
            ).fetchone()[0]
        except sqlite3.OperationalError:
            pass

        if dry_run:
            preview["dry_run"] = True
            preview["memory_names"] = [r[0] for r in db.execute(
                f"SELECT name FROM memories WHERE id IN ({ph})", ids
            ).fetchall()]
            return preview

        # --- Execute cascading delete ---

        # 1. Delete passages
        try:
            db.execute(f"DELETE FROM memory_passages WHERE memory_id IN ({ph})", ids)
        except sqlite3.OperationalError:
            pass

        # 2. Delete fact evidence and orphaned facts
        if fact_ids:
            fph = ",".join("?" * len(fact_ids))
            try:
                db.execute(f"DELETE FROM fact_evidence WHERE fact_id IN ({fph})", fact_ids)
                db.execute(f"DELETE FROM semantic_facts WHERE fact_id IN ({fph})", fact_ids)
            except sqlite3.OperationalError:
                pass

        # 3. Delete entity links
        try:
            db.execute(f"""
                DELETE FROM entity_links
                WHERE (source_type='memory' AND source_id IN ({ph}))
                   OR (target_type='memory' AND target_id IN ({ph}))
            """, ids + ids)
        except sqlite3.OperationalError:
            pass

        # 4. Delete embeddings
        try:
            db.execute(f"DELETE FROM memories_vec WHERE memory_id IN ({ph})", ids)
        except sqlite3.OperationalError:
            pass

        # 5. Delete FTS entries (trigger should handle this, but be explicit)
        try:
            for mid in ids:
                row = db.execute(
                    "SELECT name, tags, content FROM memories WHERE id=?", (mid,)
                ).fetchone()
                if row:
                    db.execute(
                        "INSERT INTO memories_fts(memories_fts, rowid, name, tags, content) "
                        "VALUES ('delete', ?, ?, ?, ?)",
                        (mid, row["name"], row["tags"] or "", row["content"])
                    )
        except sqlite3.OperationalError:
            pass

        # 6. Delete the memories themselves (HARD delete)
        db.execute(f"DELETE FROM memories WHERE id IN ({ph})", ids)

        db.commit()

        preview["deleted"] = True
        preview["dry_run"] = False
        return preview

    def forget_before(self, date_str: str, dry_run: bool = False) -> dict:
        """Purge all memories created before a date. ISO format: 2026-01-01."""
        db = self._get_db()

        ids = [r[0] for r in db.execute(
            "SELECT id FROM memories WHERE created < ?", (date_str,)
        ).fetchall()]

        if not ids:
            return {"found": 0, "message": "No memories found before that date."}

        if dry_run:
            return {"found": len(ids), "dry_run": True, "date": date_str}

        # Reuse the cascading delete
        ph = ",".join("?" * len(ids))
        # Same cascade as forget() but with pre-identified IDs
        return self._cascade_delete(db, ids)

    def forget_type(self, mem_type: str, dry_run: bool = False) -> dict:
        """Purge all memories of a specific type."""
        db = self._get_db()

        ids = [r[0] for r in db.execute(
            "SELECT id FROM memories WHERE type=?", (mem_type,)
        ).fetchall()]

        if not ids:
            return {"found": 0, "message": f"No memories of type '{mem_type}'."}

        if dry_run:
            return {"found": len(ids), "dry_run": True, "type": mem_type}

        return self._cascade_delete(db, ids)

    def _cascade_delete(self, db, ids: list[int]) -> dict:
        """Execute cascading delete for a list of memory IDs."""
        ph = ",".join("?" * len(ids))
        counts = {"memories": len(ids)}

        try:
            c = db.execute(f"DELETE FROM memory_passages WHERE memory_id IN ({ph})", ids)
            counts["passages"] = c.rowcount
        except sqlite3.OperationalError:
            counts["passages"] = 0

        try:
            fact_ids = [r[0] for r in db.execute(f"""
                SELECT DISTINCT fact_id FROM fact_evidence
                WHERE source_memory_id IN ({ph})
            """, ids).fetchall()]
            if fact_ids:
                fph = ",".join("?" * len(fact_ids))
                db.execute(f"DELETE FROM fact_evidence WHERE fact_id IN ({fph})", fact_ids)
                c = db.execute(f"DELETE FROM semantic_facts WHERE fact_id IN ({fph})", fact_ids)
                counts["facts"] = c.rowcount
        except sqlite3.OperationalError:
            counts["facts"] = 0

        try:
            c = db.execute(f"""
                DELETE FROM entity_links
                WHERE (source_type='memory' AND source_id IN ({ph}))
                   OR (target_type='memory' AND target_id IN ({ph}))
            """, ids + ids)
            counts["entity_links"] = c.rowcount
        except sqlite3.OperationalError:
            counts["entity_links"] = 0

        try:
            db.execute(f"DELETE FROM memories_vec WHERE memory_id IN ({ph})", ids)
        except sqlite3.OperationalError:
            pass

        # FTS cleanup
        for mid in ids:
            try:
                row = db.execute(
                    "SELECT name, tags, content FROM memories WHERE id=?", (mid,)
                ).fetchone()
                if row:
                    db.execute(
                        "INSERT INTO memories_fts(memories_fts, rowid, name, tags, content) "
                        "VALUES ('delete', ?, ?, ?, ?)",
                        (mid, row["name"], row["tags"] or "", row["content"])
                    )
            except sqlite3.OperationalError:
                pass

        db.execute(f"DELETE FROM memories WHERE id IN ({ph})", ids)
        db.commit()

        counts["deleted"] = True
        return counts

    # ------------------------------------------------------------------
    # Guardian — sensitivity classification
    # ------------------------------------------------------------------

    _SENSITIVE_KEYWORDS = {
        "vulnerable": [
            "depression", "anxiety", "therapy", "therapist", "medication",
            "diagnosis", "suicide", "self-harm", "abuse", "addiction",
            "rehab", "mental health", "eating disorder", "panic attack",
            "trauma", "ptsd", "grief", "mourning", "crying", "desperate",
        ],
        "personal": [
            "salary", "debt", "mortgage", "divorce", "separation",
            "pregnant", "fertility", "dating", "breakup", "cheating",
            "fired", "terminated", "bankruptcy", "foreclosure",
            "arrest", "conviction", "lawsuit",
        ],
        "confidential": [
            "ssn", "social security", "credit card", "bank account",
            "password", "api key", "secret", "classified", "nda",
            "trade secret", "proprietary", "confidential",
        ],
    }

    def classify_sensitivity(self, content: str, name: str = "") -> str:
        """Classify memory sensitivity level.

        Returns: 'standard', 'personal', 'vulnerable', or 'confidential'
        """
        text = f"{name} {content}".lower()

        for level in ("confidential", "vulnerable", "personal"):
            keywords = self._SENSITIVE_KEYWORDS[level]
            if any(kw in text for kw in keywords):
                return level

        return "standard"

    def apply_sensitivity(self, memory_id: int, content: str, name: str = "") -> str:
        """Classify and store sensitivity for a memory."""
        level = self.classify_sensitivity(content, name)
        db = self._get_db()
        db.execute(
            "UPDATE memories SET sensitivity=? WHERE id=?",
            (level, memory_id)
        )
        db.commit()
        return level

    def sensitive_memories(self, level: str = None) -> list[dict]:
        """List memories with non-standard sensitivity."""
        db = self._get_db()
        if level:
            rows = db.execute(
                "SELECT id, name, sensitivity, type FROM memories WHERE sensitivity=? AND active=1",
                (level,)
            ).fetchall()
        else:
            rows = db.execute(
                "SELECT id, name, sensitivity, type FROM memories WHERE sensitivity != 'standard' AND active=1"
            ).fetchall()
        return [dict(r) for r in rows]

    def export_excluding(
        self,
        exclude_topics: list[str] = None,
        exclude_sensitivity: list[str] = None,
    ) -> dict:
        """Export brain excluding specific topics or sensitivity levels.

        For brain marketplace — sell your expertise without personal data.
        """
        db = self._get_db()
        exclude_sensitivity = exclude_sensitivity or ["vulnerable", "confidential"]

        # Get all active, non-archived memories
        rows = db.execute(
            "SELECT * FROM memories WHERE active=1 AND archived=0"
        ).fetchall()

        filtered = []
        for row in rows:
            r = dict(row)

            # Skip sensitive
            if r.get("sensitivity", "standard") in exclude_sensitivity:
                continue

            # Skip excluded topics
            if exclude_topics:
                skip = False
                text = f"{r.get('name', '')} {r.get('content', '')}".lower()
                for topic in exclude_topics:
                    if topic.lower() in text:
                        skip = True
                        break
                if skip:
                    continue

            filtered.append(r)

        return {
            "metadata": {
                "export_date": datetime.now(timezone.utc).isoformat(),
                "total_memories": len(filtered),
                "excluded_sensitivity": exclude_sensitivity,
                "excluded_topics": exclude_topics or [],
                "selective_export": True,
            },
            "memories": filtered,
        }

    # ------------------------------------------------------------------
    # Stats
    # ------------------------------------------------------------------

    def stats(self) -> dict:
        db = self._get_db()
        total = db.execute("SELECT COUNT(*) FROM memories WHERE active=1").fetchone()[0]
        archived = db.execute("SELECT COUNT(*) FROM memories WHERE archived=1").fetchone()[0]

        avg_eff = db.execute(
            "SELECT AVG(effective_importance) FROM memories WHERE active=1 AND archived=0"
        ).fetchone()[0]

        sensitivity_counts = {}
        for row in db.execute("""
            SELECT COALESCE(sensitivity, 'standard') as s, COUNT(*) as c
            FROM memories WHERE active=1
            GROUP BY s
        """).fetchall():
            sensitivity_counts[row["s"]] = row["c"]

        return {
            "active_memories": total,
            "archived_memories": archived,
            "avg_effective_importance": round(avg_eff or 0, 3),
            "half_life_days": self.half_life,
            "sensitivity_distribution": sensitivity_counts,
        }
