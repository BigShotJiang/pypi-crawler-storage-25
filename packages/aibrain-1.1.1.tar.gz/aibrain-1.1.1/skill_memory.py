#!/usr/bin/env python3
"""
skill_memory.py — Skill Memory: Your Agent Gets Better At Its Job Over Time

Captures how tasks are performed, what feedback was given, and distills
reusable principles that improve future performance. Integrates with
the MCP server via memory_prepare tool.

Tables:
    skill_episodes    — records of task execution with outcomes
    skill_principles  — distilled rules learned from episodes
    skill_profiles    — aggregated skill stats per task type

Usage:
    from skill_memory import SkillMemory
    sm = SkillMemory(db_path)
    sm.record_episode("code_review", approach="check tests first", outcome=0.9)
    briefing = sm.prepare("code_review", context="auth service PR")
"""

import json
import re
import sqlite3
import threading
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Optional


_lock = threading.Lock()


def _get_db(db_path) -> sqlite3.Connection:
    conn = sqlite3.connect(str(db_path), check_same_thread=False, timeout=10)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=5000")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.row_factory = sqlite3.Row
    _ensure_schema(conn)
    return conn


def _ensure_schema(db: sqlite3.Connection):
    db.executescript("""
        CREATE TABLE IF NOT EXISTS skill_episodes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            task_type TEXT NOT NULL,
            task_description TEXT DEFAULT '',
            approach_taken TEXT DEFAULT '',
            tools_used TEXT DEFAULT '[]',
            outcome_quality REAL DEFAULT 0.5,
            corrections TEXT DEFAULT '',
            context_keys TEXT DEFAULT '[]',
            user_feedback TEXT DEFAULT '',
            duration_s REAL DEFAULT 0,
            session_id TEXT DEFAULT '',
            created_at TEXT DEFAULT (datetime('now'))
        );

        CREATE INDEX IF NOT EXISTS idx_episodes_type
            ON skill_episodes(task_type);
        CREATE INDEX IF NOT EXISTS idx_episodes_created
            ON skill_episodes(created_at);

        CREATE TABLE IF NOT EXISTS skill_principles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            task_type TEXT NOT NULL,
            principle TEXT NOT NULL,
            principle_type TEXT DEFAULT 'procedural',
            source_episode_id INTEGER,
            confidence REAL DEFAULT 0.45,
            times_applied INTEGER DEFAULT 0,
            times_reinforced INTEGER DEFAULT 0,
            times_contradicted INTEGER DEFAULT 0,
            last_applied TEXT,
            status TEXT DEFAULT 'active',
            created_at TEXT DEFAULT (datetime('now')),
            updated_at TEXT DEFAULT (datetime('now')),
            FOREIGN KEY (source_episode_id) REFERENCES skill_episodes(id)
        );

        CREATE INDEX IF NOT EXISTS idx_principles_type
            ON skill_principles(task_type, status);

        CREATE TABLE IF NOT EXISTS skill_profiles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            task_type TEXT UNIQUE NOT NULL,
            total_episodes INTEGER DEFAULT 0,
            avg_outcome REAL DEFAULT 0.0,
            best_approach TEXT DEFAULT '',
            common_corrections TEXT DEFAULT '[]',
            last_performed TEXT,
            trend TEXT DEFAULT 'stable',
            updated_at TEXT DEFAULT (datetime('now'))
        );
    """)
    db.commit()


# ---------------------------------------------------------------------------
# Feedback extraction — detect user corrections and satisfaction signals
# ---------------------------------------------------------------------------

_POSITIVE_SIGNALS = [
    "perfect", "great", "exactly", "good job", "nice", "well done",
    "that's right", "correct", "keep it", "love it", "nailed it",
    "thanks", "thank you", "awesome", "excellent", "spot on",
]

_NEGATIVE_SIGNALS = [
    "wrong", "incorrect", "no that's not", "not what i asked",
    "try again", "redo", "fix this", "missed", "you forgot",
    "don't do that", "stop doing", "never do", "always do",
    "i told you", "i said", "format it as", "use a table",
    "not bullets", "too long", "too short", "too verbose",
]

_CORRECTION_PATTERNS = [
    # "always X" / "never Y" — procedural principles
    (re.compile(r'always\s+(.{5,80})(?:[.,!]|$)', re.IGNORECASE), 'do'),
    (re.compile(r'never\s+(.{5,80})(?:[.,!]|$)', re.IGNORECASE), 'dont'),
    # "format as X" / "use X format"
    (re.compile(r'(?:format|write|present)\s+(?:it\s+)?(?:as|in|like)\s+(.{3,50})', re.IGNORECASE), 'format'),
    # "check for X" / "look for X"
    (re.compile(r'(?:check|look|watch|scan)\s+(?:for|at)\s+(.{3,80})', re.IGNORECASE), 'check'),
    # "next time X"
    (re.compile(r'next\s+time\s+(.{5,80})(?:[.,!]|$)', re.IGNORECASE), 'do'),
    # "don't forget to X"
    (re.compile(r"don'?t\s+forget\s+(?:to\s+)?(.{5,80})(?:[.,!]|$)", re.IGNORECASE), 'do'),
]


def _estimate_outcome(user_feedback: str) -> float:
    """Estimate outcome quality from user feedback text. 0.0-1.0."""
    if not user_feedback:
        return 0.5  # no signal — neutral

    fb_lower = user_feedback.lower()

    pos_count = sum(1 for s in _POSITIVE_SIGNALS if s in fb_lower)
    neg_count = sum(1 for s in _NEGATIVE_SIGNALS if s in fb_lower)

    if pos_count + neg_count == 0:
        return 0.5

    return min(max(0.5 + (pos_count - neg_count) * 0.15, 0.0), 1.0)


def _extract_corrections(feedback: str) -> list[dict]:
    """Extract actionable corrections from user feedback."""
    corrections = []

    for pattern, correction_type in _CORRECTION_PATTERNS:
        for match in pattern.finditer(feedback):
            text = match.group(1).strip()
            if len(text) > 2:
                corrections.append({
                    "type": correction_type,
                    "text": text,
                    "raw": match.group(0).strip(),
                })

    return corrections


# ---------------------------------------------------------------------------
# Core API
# ---------------------------------------------------------------------------

class SkillMemory:
    """Skill memory system — learns from task execution and user feedback."""

    def __init__(self, db_path: str | Path):
        self.db_path = Path(db_path)
        self._db = None

    def _get_db(self):
        if self._db is None:
            self._db = _get_db(self.db_path)
        return self._db

    def record_episode(
        self,
        task_type: str,
        task_description: str = "",
        approach_taken: str = "",
        tools_used: list[str] = None,
        user_feedback: str = "",
        corrections: str = "",
        context_keys: list[str] = None,
        duration_s: float = 0,
        session_id: str = "",
        outcome_quality: float = None,
    ) -> dict:
        """Record a skill episode after task completion.

        If outcome_quality is not provided, estimates it from user_feedback.
        Automatically extracts corrections and generates/reinforces principles.
        """
        db = self._get_db()

        if outcome_quality is None:
            outcome_quality = _estimate_outcome(user_feedback)

        # Extract corrections from feedback if not provided
        extracted_corrections = _extract_corrections(user_feedback) if user_feedback else []
        if extracted_corrections and not corrections:
            corrections = json.dumps(extracted_corrections, default=str)

        # Store episode
        cursor = db.execute("""
            INSERT INTO skill_episodes
            (task_type, task_description, approach_taken, tools_used,
             outcome_quality, corrections, context_keys, user_feedback,
             duration_s, session_id, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
        """, (
            task_type, task_description, approach_taken,
            json.dumps(tools_used or []),
            outcome_quality, corrections,
            json.dumps(context_keys or []),
            user_feedback, duration_s, session_id,
        ))
        episode_id = cursor.lastrowid
        db.commit()

        # Generate or reinforce principles from this episode
        new_principles = self._learn_from_episode(episode_id, task_type,
            approach_taken, user_feedback, outcome_quality, extracted_corrections)

        # Update skill profile
        self._update_profile(task_type)

        return {
            "episode_id": episode_id,
            "task_type": task_type,
            "outcome_quality": outcome_quality,
            "corrections_found": len(extracted_corrections),
            "principles_updated": len(new_principles),
        }

    def _learn_from_episode(
        self, episode_id: int, task_type: str,
        approach: str, feedback: str, outcome: float,
        corrections: list[dict],
    ) -> list[dict]:
        """Extract or reinforce principles from an episode."""
        db = self._get_db()
        updated = []

        # 1. Create principles from explicit corrections
        for correction in corrections:
            principle_text = self._correction_to_principle(correction)
            if principle_text:
                self._upsert_principle(db, task_type, principle_text,
                    'procedural', episode_id)
                updated.append({"type": "correction", "principle": principle_text})

        # 2. If high outcome, reinforce the approach as a principle
        if outcome >= 0.8 and approach:
            approach_principle = f"Effective approach: {approach[:200]}"
            existing = db.execute("""
                SELECT id, confidence, times_reinforced FROM skill_principles
                WHERE task_type=? AND principle LIKE ? AND status='active'
            """, (task_type, f"%{approach[:50]}%")).fetchone()

            if existing:
                new_conf = min(existing["confidence"] + 0.1, 0.95)
                db.execute("""
                    UPDATE skill_principles
                    SET confidence=?, times_reinforced=times_reinforced+1,
                        updated_at=datetime('now')
                    WHERE id=?
                """, (new_conf, existing["id"]))
                updated.append({"type": "reinforced", "principle": approach_principle})
            else:
                self._upsert_principle(db, task_type, approach_principle,
                    'approach', episode_id)
                updated.append({"type": "new_approach", "principle": approach_principle})

        # 3. If low outcome, note what didn't work
        if outcome <= 0.3 and approach:
            anti_principle = f"Avoid: {approach[:200]} (poor outcome)"
            self._upsert_principle(db, task_type, anti_principle,
                'anti_pattern', episode_id)
            updated.append({"type": "anti_pattern", "principle": anti_principle})

        db.commit()
        return updated

    def _correction_to_principle(self, correction: dict) -> str:
        """Convert a correction extraction into a principle statement."""
        ctype = correction.get("type", "do")
        text = correction.get("text", "").strip()
        if not text:
            return ""

        if ctype == "dont":
            return f"Never: {text}"
        elif ctype == "format":
            return f"Format preference: {text}"
        elif ctype == "check":
            return f"Always check: {text}"
        else:
            return f"Always: {text}"

    def _upsert_principle(
        self, db, task_type: str, principle: str,
        principle_type: str, episode_id: int,
    ):
        """Insert or reinforce a principle. Deduplicates by similarity."""
        # Check for existing similar principle
        existing = db.execute("""
            SELECT id, confidence, times_reinforced FROM skill_principles
            WHERE task_type=? AND status='active'
              AND (principle=? OR principle LIKE ?)
        """, (task_type, principle, f"%{principle[:40]}%")).fetchone()

        if existing:
            new_conf = min(existing["confidence"] + 0.1, 0.95)
            db.execute("""
                UPDATE skill_principles
                SET confidence=?, times_reinforced=times_reinforced+1,
                    updated_at=datetime('now')
                WHERE id=?
            """, (new_conf, existing["id"]))
        else:
            db.execute("""
                INSERT INTO skill_principles
                (task_type, principle, principle_type, source_episode_id,
                 confidence, status, created_at, updated_at)
                VALUES (?, ?, ?, ?, 0.45, 'active', datetime('now'), datetime('now'))
            """, (task_type, principle, principle_type, episode_id))

    def _update_profile(self, task_type: str):
        """Update the aggregated skill profile for a task type."""
        db = self._get_db()

        stats = db.execute("""
            SELECT COUNT(*) as total, AVG(outcome_quality) as avg_outcome,
                   MAX(created_at) as last_performed
            FROM skill_episodes WHERE task_type=?
        """, (task_type,)).fetchone()

        # Find best approach (highest avg outcome)
        best = db.execute("""
            SELECT approach_taken, AVG(outcome_quality) as avg_q
            FROM skill_episodes
            WHERE task_type=? AND approach_taken != ''
            GROUP BY approach_taken
            ORDER BY avg_q DESC LIMIT 1
        """, (task_type,)).fetchone()

        # Common corrections
        recent_corrections = db.execute("""
            SELECT corrections FROM skill_episodes
            WHERE task_type=? AND corrections != '' AND corrections != '[]'
            ORDER BY created_at DESC LIMIT 10
        """, (task_type,)).fetchall()

        all_corrections = []
        for row in recent_corrections:
            try:
                all_corrections.extend(json.loads(row["corrections"]))
            except (json.JSONDecodeError, TypeError):
                pass

        # Calculate trend (comparing last 5 vs previous 5)
        recent_5 = db.execute("""
            SELECT outcome_quality FROM skill_episodes
            WHERE task_type=? ORDER BY created_at DESC LIMIT 5
        """, (task_type,)).fetchall()
        prev_5 = db.execute("""
            SELECT outcome_quality FROM skill_episodes
            WHERE task_type=? ORDER BY created_at DESC LIMIT 5 OFFSET 5
        """, (task_type,)).fetchall()

        trend = "stable"
        if len(recent_5) >= 3 and len(prev_5) >= 3:
            recent_avg = sum(r["outcome_quality"] for r in recent_5) / len(recent_5)
            prev_avg = sum(r["outcome_quality"] for r in prev_5) / len(prev_5)
            if recent_avg > prev_avg + 0.1:
                trend = "improving"
            elif recent_avg < prev_avg - 0.1:
                trend = "declining"

        db.execute("""
            INSERT INTO skill_profiles (task_type, total_episodes, avg_outcome,
                best_approach, common_corrections, last_performed, trend, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
            ON CONFLICT(task_type) DO UPDATE SET
                total_episodes=?, avg_outcome=?, best_approach=?,
                common_corrections=?, last_performed=?, trend=?, updated_at=datetime('now')
        """, (
            task_type, stats["total"], round(stats["avg_outcome"] or 0, 3),
            best["approach_taken"] if best else "",
            json.dumps(all_corrections[:10], default=str),
            stats["last_performed"], trend,
            # ON CONFLICT values:
            stats["total"], round(stats["avg_outcome"] or 0, 3),
            best["approach_taken"] if best else "",
            json.dumps(all_corrections[:10], default=str),
            stats["last_performed"], trend,
        ))
        db.commit()

    def prepare(self, task_type: str, context: str = "", limit: int = 10) -> dict:
        """Prepare a skill briefing before starting a task.

        This is the memory_prepare MCP tool — returns everything the agent
        needs to do this task type well, learned from past experience.
        """
        db = self._get_db()

        # 1. Skill profile
        profile = db.execute(
            "SELECT * FROM skill_profiles WHERE task_type=?",
            (task_type,)
        ).fetchone()
        profile_dict = dict(profile) if profile else None

        # 2. Active principles, highest confidence first
        principles = [dict(r) for r in db.execute("""
            SELECT principle, principle_type, confidence, times_reinforced
            FROM skill_principles
            WHERE task_type=? AND status='active'
            ORDER BY confidence DESC, times_reinforced DESC
            LIMIT ?
        """, (task_type, limit)).fetchall()]

        # 3. Also get cross-task principles (task_type='_universal')
        universal = [dict(r) for r in db.execute("""
            SELECT principle, principle_type, confidence
            FROM skill_principles
            WHERE task_type='_universal' AND status='active'
            ORDER BY confidence DESC LIMIT 5
        """).fetchall()]

        # 4. Recent relevant episodes (for context)
        recent = [dict(r) for r in db.execute("""
            SELECT task_description, approach_taken, outcome_quality,
                   user_feedback, created_at
            FROM skill_episodes
            WHERE task_type=?
            ORDER BY created_at DESC LIMIT 5
        """, (task_type,)).fetchall()]

        # 5. Build the briefing
        briefing_lines = []

        if profile_dict:
            briefing_lines.append(
                f"Task type: {task_type} ({profile_dict['total_episodes']} prior episodes, "
                f"avg quality: {profile_dict['avg_outcome']:.0%}, trend: {profile_dict['trend']})"
            )
            if profile_dict.get("best_approach"):
                briefing_lines.append(f"Best approach: {profile_dict['best_approach']}")

        if principles:
            briefing_lines.append("\nLearned principles:")
            for p in principles:
                conf = p["confidence"]
                marker = "***" if conf >= 0.8 else "**" if conf >= 0.6 else "*"
                briefing_lines.append(f"  {marker} {p['principle']} (confidence: {conf:.0%})")

        if universal:
            briefing_lines.append("\nUniversal principles:")
            for p in universal:
                briefing_lines.append(f"  - {p['principle']}")

        if recent:
            briefing_lines.append(f"\nLast {len(recent)} episodes:")
            for ep in recent:
                quality = "good" if ep["outcome_quality"] >= 0.7 else "ok" if ep["outcome_quality"] >= 0.4 else "poor"
                briefing_lines.append(
                    f"  - {ep['task_description'][:60]} ({quality}, {ep['created_at'][:10]})"
                )
                if ep.get("user_feedback"):
                    briefing_lines.append(f"    Feedback: {ep['user_feedback'][:100]}")

        briefing_text = "\n".join(briefing_lines) if briefing_lines else f"No prior experience with '{task_type}'. This is the first time."

        return {
            "task_type": task_type,
            "briefing": briefing_text,
            "profile": profile_dict,
            "principles": principles,
            "universal_principles": universal,
            "recent_episodes": recent,
            "experience_level": self._experience_level(profile_dict),
        }

    def _experience_level(self, profile: dict | None) -> str:
        if not profile:
            return "novice"
        total = profile.get("total_episodes", 0)
        avg = profile.get("avg_outcome", 0)
        if total >= 20 and avg >= 0.8:
            return "expert"
        elif total >= 10 and avg >= 0.6:
            return "proficient"
        elif total >= 5:
            return "intermediate"
        elif total >= 1:
            return "beginner"
        return "novice"

    def contradict_principle(self, principle_id: int, reason: str = ""):
        """Record that a principle was contradicted by new evidence."""
        db = self._get_db()
        row = db.execute(
            "SELECT confidence, times_contradicted FROM skill_principles WHERE id=?",
            (principle_id,)
        ).fetchone()
        if not row:
            return

        new_conf = max(row["confidence"] - 0.15, 0.0)
        contradictions = row["times_contradicted"] + 1

        if new_conf <= 0.1 or contradictions >= 5:
            db.execute("""
                UPDATE skill_principles
                SET status='archived', confidence=?, times_contradicted=?,
                    updated_at=datetime('now')
                WHERE id=?
            """, (new_conf, contradictions, principle_id))
        else:
            db.execute("""
                UPDATE skill_principles
                SET confidence=?, times_contradicted=?,
                    updated_at=datetime('now')
                WHERE id=?
            """, (new_conf, contradictions, principle_id))
        db.commit()

    def get_all_profiles(self) -> list[dict]:
        """List all skill profiles — the agent's skill inventory."""
        db = self._get_db()
        return [dict(r) for r in db.execute(
            "SELECT * FROM skill_profiles ORDER BY total_episodes DESC"
        ).fetchall()]

    def stats(self) -> dict:
        db = self._get_db()
        return {
            "total_episodes": db.execute("SELECT COUNT(*) FROM skill_episodes").fetchone()[0],
            "total_principles": db.execute(
                "SELECT COUNT(*) FROM skill_principles WHERE status='active'"
            ).fetchone()[0],
            "task_types": db.execute(
                "SELECT COUNT(DISTINCT task_type) FROM skill_episodes"
            ).fetchone()[0],
            "archived_principles": db.execute(
                "SELECT COUNT(*) FROM skill_principles WHERE status='archived'"
            ).fetchone()[0],
        }
