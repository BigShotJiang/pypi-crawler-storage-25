#!/usr/bin/env python3
"""
self_model.py — Agent Self-Model: Wake Up Knowing Who You Are

A living document the system maintains — the agent's understanding of itself.
Regenerated periodically from evidence in the memory system. Loads first
every session as orientation and continuity.

Tables:
    self_model          — the current self-model (single active row)
    self_model_history  — historical snapshots for drift detection

Usage:
    from self_model import SelfModel
    sm = SelfModel(db_path)
    model = sm.load()              # returns current self-model text
    sm.regenerate(memories, facts, skills, corrections)  # rebuild from evidence
"""

import json
import sqlite3
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional


def _get_db(db_path) -> sqlite3.Connection:
    conn = sqlite3.connect(str(db_path), check_same_thread=False, timeout=10)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=5000")
    conn.row_factory = sqlite3.Row
    _ensure_schema(conn)
    return conn


def _ensure_schema(db: sqlite3.Connection):
    db.executescript("""
        CREATE TABLE IF NOT EXISTS self_model (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            model_text TEXT NOT NULL,
            structured_data TEXT DEFAULT '{}',
            generated_from TEXT DEFAULT '{}',
            active INTEGER DEFAULT 1,
            created_at TEXT DEFAULT (datetime('now')),
            session_count INTEGER DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS self_model_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            model_text TEXT NOT NULL,
            structured_data TEXT DEFAULT '{}',
            reason TEXT DEFAULT 'scheduled',
            created_at TEXT DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS session_narratives (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT DEFAULT '',
            narrative TEXT NOT NULL,
            topics_covered TEXT DEFAULT '[]',
            emotional_tone TEXT DEFAULT 'neutral',
            relationship_note TEXT DEFAULT '',
            key_decisions TEXT DEFAULT '[]',
            created_at TEXT DEFAULT (datetime('now'))
        );

        CREATE INDEX IF NOT EXISTS idx_narratives_created
            ON session_narratives(created_at);

        CREATE TABLE IF NOT EXISTS topic_registry (
            topic_hash TEXT PRIMARY KEY,
            topic TEXT NOT NULL,
            first_discussed TEXT DEFAULT (datetime('now')),
            last_discussed TEXT DEFAULT (datetime('now')),
            discussion_count INTEGER DEFAULT 1,
            resolution TEXT DEFAULT 'open',
            resolution_summary TEXT DEFAULT '',
            current_memory_id INTEGER,
            updated_at TEXT DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS correction_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            original_advice TEXT NOT NULL,
            correction TEXT NOT NULL,
            reasoning_flaw TEXT DEFAULT '',
            context_type TEXT DEFAULT '',
            corrected_by TEXT DEFAULT 'user_pushback',
            confidence_in_correction REAL DEFAULT 0.7,
            created_at TEXT DEFAULT (datetime('now'))
        );

        CREATE INDEX IF NOT EXISTS idx_corrections_context
            ON correction_log(context_type);

        CREATE TABLE IF NOT EXISTS relational_state (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            observed_at TEXT DEFAULT (datetime('now')),
            engagement_level REAL DEFAULT 0.5,
            emotional_indicators TEXT DEFAULT '[]',
            session_pattern TEXT DEFAULT 'normal',
            context_notes TEXT DEFAULT '',
            needs_detected TEXT DEFAULT '[]'
        );
    """)
    db.commit()


class SelfModel:
    """Agent self-model — identity, capabilities, working context."""

    def __init__(self, db_path: str | Path):
        self.db_path = Path(db_path)
        self._db = None

    def _get_db(self):
        if self._db is None:
            self._db = _get_db(self.db_path)
        return self._db

    # ------------------------------------------------------------------
    # Self-Model
    # ------------------------------------------------------------------

    def load(self) -> dict:
        """Load the current self-model. Returns model text + structured data.
        This should be the FIRST thing loaded at session start."""
        db = self._get_db()

        model = db.execute(
            "SELECT * FROM self_model WHERE active=1 ORDER BY id DESC LIMIT 1"
        ).fetchone()

        if not model:
            return {
                "model_text": "No self-model generated yet. I'm starting fresh.",
                "structured": {},
                "exists": False,
            }

        # Increment session count
        db.execute(
            "UPDATE self_model SET session_count=session_count+1 WHERE id=?",
            (model["id"],)
        )
        db.commit()

        structured = {}
        try:
            structured = json.loads(model["structured_data"])
        except (json.JSONDecodeError, TypeError):
            pass

        return {
            "model_text": model["model_text"],
            "structured": structured,
            "sessions": model["session_count"] + 1,
            "generated_at": model["created_at"],
            "exists": True,
        }

    def regenerate(
        self,
        user_memories: list[dict] = None,
        semantic_facts: list[dict] = None,
        skill_profiles: list[dict] = None,
        correction_log: list[dict] = None,
        recent_narratives: list[dict] = None,
        relational_history: list[dict] = None,
        agent_name: str = "agent",
    ) -> str:
        """Regenerate the self-model from accumulated evidence.

        Call this periodically (daily, or after significant changes).
        Does NOT require an LLM — builds the model from structured data.
        """
        db = self._get_db()

        sections = []
        structured = {}

        # --- Who I work with ---
        user_section, user_data = self._build_user_section(user_memories, semantic_facts)
        if user_section:
            sections.append(user_section)
            structured["user"] = user_data

        # --- What I'm good at / learning ---
        skills_section, skills_data = self._build_skills_section(skill_profiles)
        if skills_section:
            sections.append(skills_section)
            structured["skills"] = skills_data

        # --- What I get wrong ---
        corrections_section, corrections_data = self._build_corrections_section(correction_log)
        if corrections_section:
            sections.append(corrections_section)
            structured["known_biases"] = corrections_data

        # --- Current working context ---
        context_section = self._build_context_section(user_memories)
        if context_section:
            sections.append(context_section)

        # --- Relationship state ---
        relational_section = self._build_relational_section(
            recent_narratives, relational_history)
        if relational_section:
            sections.append(relational_section)

        model_text = "\n\n".join(sections)

        if not model_text.strip():
            model_text = f"I am {agent_name}. No accumulated context yet — this is early."

        # Archive current model
        current = db.execute(
            "SELECT id, model_text FROM self_model WHERE active=1"
        ).fetchone()
        if current:
            db.execute("""
                INSERT INTO self_model_history (model_text, structured_data, reason)
                VALUES (?, ?, 'regeneration')
            """, (current["model_text"], json.dumps(structured, default=str)))
            db.execute("UPDATE self_model SET active=0 WHERE active=1")

        # Store new model
        db.execute("""
            INSERT INTO self_model (model_text, structured_data, active, session_count)
            VALUES (?, ?, 1, 0)
        """, (model_text, json.dumps(structured, default=str)))
        db.commit()

        return model_text

    def _build_user_section(self, memories, facts) -> tuple[str, dict]:
        if not memories and not facts:
            return "", {}

        data = {}
        lines = ["Who I work with:"]

        # Extract user facts from semantic facts
        if facts:
            user_facts = [f for f in facts
                          if f.get("subject") == "user" and f.get("status") == "ACTIVE"]
            for f in user_facts[:15]:
                pred = f.get("predicate", "").replace("_", " ")
                obj = f.get("object", "")
                lines.append(f"  - User {pred}: {obj}")
                data[f.get("predicate", "")] = obj

        # Extract user-type memories for preferences
        if memories:
            user_mems = [m for m in memories if m.get("type") == "user"]
            if user_mems:
                lines.append(f"  ({len(user_mems)} user-context memories stored)")

        return "\n".join(lines), data

    def _build_skills_section(self, profiles) -> tuple[str, dict]:
        if not profiles:
            return "", {}

        data = {}
        lines = ["What I'm good at:"]

        for p in sorted(profiles, key=lambda x: x.get("avg_outcome", 0), reverse=True):
            task = p.get("task_type", "unknown")
            avg = p.get("avg_outcome", 0)
            total = p.get("total_episodes", 0)
            trend = p.get("trend", "stable")

            if avg >= 0.8 and total >= 5:
                level = "strong"
            elif avg >= 0.6:
                level = "developing"
            else:
                level = "needs work"

            lines.append(f"  - {task}: {level} ({total} episodes, {avg:.0%} avg, {trend})")
            data[task] = {"level": level, "episodes": total, "avg": avg, "trend": trend}

        return "\n".join(lines), data

    def _build_corrections_section(self, corrections) -> tuple[str, dict]:
        if not corrections:
            return "", {}

        data = []
        lines = ["Where I get it wrong:"]

        for c in corrections[:10]:
            flaw = c.get("reasoning_flaw", "unknown")
            lines.append(f"  - {flaw}: {c.get('correction', '')[:100]}")
            data.append({"flaw": flaw, "context": c.get("context_type", "")})

        return "\n".join(lines), data

    def _build_context_section(self, memories) -> str:
        if not memories:
            return ""

        # Find recent project-type memories for current context
        project_mems = [m for m in memories
                        if m.get("type") == "project" and m.get("active", 1)]
        if not project_mems:
            return ""

        lines = ["Current working context:"]
        for m in sorted(project_mems, key=lambda x: x.get("updated", ""), reverse=True)[:5]:
            name = m.get("name", "?")
            content_preview = m.get("content", "")[:80]
            lines.append(f"  - {name}: {content_preview}")

        return "\n".join(lines)

    def _build_relational_section(self, narratives, relational) -> str:
        lines = []

        if narratives:
            lines.append("Recent session memory:")
            for n in narratives[:3]:
                lines.append(f"  {n.get('narrative', '')[:150]}")

        if relational:
            latest = relational[0] if relational else None
            if latest:
                pattern = latest.get("session_pattern", "normal")
                needs = latest.get("needs_detected", "[]")
                if isinstance(needs, str):
                    try: needs = json.loads(needs)
                    except: needs = []
                if needs:
                    lines.append(f"Last session pattern: {pattern}. Detected needs: {', '.join(needs)}")

        return "\n".join(lines) if lines else ""

    # ------------------------------------------------------------------
    # Session Narratives
    # ------------------------------------------------------------------

    def record_narrative(
        self,
        narrative: str,
        session_id: str = "",
        topics_covered: list[str] = None,
        emotional_tone: str = "neutral",
        relationship_note: str = "",
        key_decisions: list[str] = None,
    ) -> int:
        """Record a first-person session narrative."""
        db = self._get_db()
        cursor = db.execute("""
            INSERT INTO session_narratives
            (session_id, narrative, topics_covered, emotional_tone,
             relationship_note, key_decisions)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (
            session_id, narrative,
            json.dumps(topics_covered or []),
            emotional_tone, relationship_note,
            json.dumps(key_decisions or []),
        ))
        db.commit()

        # Update topic registry for covered topics
        for topic in (topics_covered or []):
            self.register_topic(topic)

        return cursor.lastrowid

    def recent_narratives(self, limit: int = 5) -> list[dict]:
        db = self._get_db()
        return [dict(r) for r in db.execute("""
            SELECT * FROM session_narratives ORDER BY created_at DESC LIMIT ?
        """, (limit,)).fetchall()]

    # ------------------------------------------------------------------
    # Topic Registry
    # ------------------------------------------------------------------

    def register_topic(
        self,
        topic: str,
        resolution: str = None,
        resolution_summary: str = None,
        memory_id: int = None,
    ):
        """Register or update a topic in the episodic index."""
        import hashlib
        db = self._get_db()

        topic_hash = hashlib.sha256(topic.lower().strip().encode()).hexdigest()[:16]

        existing = db.execute(
            "SELECT topic_hash, discussion_count FROM topic_registry WHERE topic_hash=?",
            (topic_hash,)
        ).fetchone()

        if existing:
            updates = ["discussion_count=discussion_count+1",
                       "last_discussed=datetime('now')",
                       "updated_at=datetime('now')"]
            params = []
            if resolution:
                updates.append("resolution=?")
                params.append(resolution)
            if resolution_summary:
                updates.append("resolution_summary=?")
                params.append(resolution_summary)
            if memory_id:
                updates.append("current_memory_id=?")
                params.append(memory_id)
            params.append(topic_hash)
            db.execute(
                f"UPDATE topic_registry SET {', '.join(updates)} WHERE topic_hash=?",
                params
            )
        else:
            db.execute("""
                INSERT INTO topic_registry
                (topic_hash, topic, resolution, resolution_summary, current_memory_id)
                VALUES (?, ?, ?, ?, ?)
            """, (topic_hash, topic, resolution or "open",
                  resolution_summary or "", memory_id))
        db.commit()

    def check_topic(self, topic: str) -> dict | None:
        """Check if a topic has been discussed before."""
        import hashlib
        db = self._get_db()
        topic_hash = hashlib.sha256(topic.lower().strip().encode()).hexdigest()[:16]
        row = db.execute(
            "SELECT * FROM topic_registry WHERE topic_hash=?",
            (topic_hash,)
        ).fetchone()
        return dict(row) if row else None

    def decided_topics(self) -> list[dict]:
        """Return all topics with 'decided' resolution."""
        db = self._get_db()
        return [dict(r) for r in db.execute("""
            SELECT * FROM topic_registry WHERE resolution='decided'
            ORDER BY last_discussed DESC
        """).fetchall()]

    # ------------------------------------------------------------------
    # Correction Log
    # ------------------------------------------------------------------

    def record_correction(
        self,
        original_advice: str,
        correction: str,
        reasoning_flaw: str = "",
        context_type: str = "",
        corrected_by: str = "user_pushback",
        confidence: float = 0.7,
    ) -> int:
        db = self._get_db()
        cursor = db.execute("""
            INSERT INTO correction_log
            (original_advice, correction, reasoning_flaw, context_type,
             corrected_by, confidence_in_correction)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (original_advice, correction, reasoning_flaw,
              context_type, corrected_by, confidence))
        db.commit()
        return cursor.lastrowid

    def relevant_corrections(self, context_type: str, limit: int = 5) -> list[dict]:
        """Get corrections relevant to a context type."""
        db = self._get_db()
        return [dict(r) for r in db.execute("""
            SELECT * FROM correction_log
            WHERE context_type=? OR context_type=''
            ORDER BY confidence_in_correction DESC, created_at DESC
            LIMIT ?
        """, (context_type, limit)).fetchall()]

    # ------------------------------------------------------------------
    # Relational State
    # ------------------------------------------------------------------

    def record_relational_state(
        self,
        engagement_level: float = 0.5,
        emotional_indicators: list[str] = None,
        session_pattern: str = "normal",
        context_notes: str = "",
        needs_detected: list[str] = None,
    ) -> int:
        db = self._get_db()
        cursor = db.execute("""
            INSERT INTO relational_state
            (engagement_level, emotional_indicators, session_pattern,
             context_notes, needs_detected)
            VALUES (?, ?, ?, ?, ?)
        """, (
            engagement_level,
            json.dumps(emotional_indicators or []),
            session_pattern, context_notes,
            json.dumps(needs_detected or []),
        ))
        db.commit()
        return cursor.lastrowid

    def relational_history(self, limit: int = 10) -> list[dict]:
        db = self._get_db()
        return [dict(r) for r in db.execute("""
            SELECT * FROM relational_state ORDER BY observed_at DESC LIMIT ?
        """, (limit,)).fetchall()]

    def relational_trend(self, days: int = 14) -> dict:
        """Analyze relational trends over a period."""
        db = self._get_db()
        rows = db.execute("""
            SELECT engagement_level, session_pattern, needs_detected
            FROM relational_state
            WHERE observed_at >= datetime('now', ?)
            ORDER BY observed_at
        """, (f"-{days} days",)).fetchall()

        if not rows:
            return {"trend": "no_data", "sessions": 0}

        avg_engagement = sum(r["engagement_level"] for r in rows) / len(rows)
        patterns = {}
        for r in rows:
            p = r["session_pattern"]
            patterns[p] = patterns.get(p, 0) + 1

        dominant_pattern = max(patterns, key=patterns.get) if patterns else "unknown"

        return {
            "sessions": len(rows),
            "avg_engagement": round(avg_engagement, 2),
            "dominant_pattern": dominant_pattern,
            "pattern_distribution": patterns,
        }
