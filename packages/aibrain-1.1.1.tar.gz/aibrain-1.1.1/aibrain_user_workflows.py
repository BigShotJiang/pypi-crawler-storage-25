#!/usr/bin/env python3
"""
aibrain_user_workflows.py — 40 User-Value Workflows

These are the "wow" workflows — features that are ONLY possible because
aibrain has persistent memory across sessions. No other AI tool can do these
because no other tool remembers what you said, decided, learned, or built
over weeks and months.

Four categories:
1. Personal Intelligence (10) — your brain working FOR you
2. Professional Acceleration (10) — career and work value
3. Knowledge Synthesis (10) — turning information into wisdom
4. Proactive Intelligence (10) — the brain that thinks ahead

Each workflow leverages aibrain's unique capabilities:
- Cross-session memory (remembers everything)
- Skill episodes (tracks what you've done)
- Semantic facts (knows relationships between concepts)
- Temporal awareness (understands when things happened)
"""

import json
import logging
import re
import sqlite3
import time
from abc import ABC, abstractmethod
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional

log = logging.getLogger("aibrain.user_workflows")


class UserWorkflow(ABC):
    name: str = "base"
    display_name: str = "Base"
    description: str = ""
    category: str = "general"
    schedule_cron: str = "0 9 * * *"
    wow_factor: str = ""  # one line explaining why this is only possible with persistent memory

    def __init__(self, db_path: str, config: Dict = None):
        self.db_path = db_path
        self.config = config or {}
        self._conn = None

    def _db(self):
        if self._conn is None:
            self._conn = sqlite3.connect(self.db_path, check_same_thread=False)
            self._conn.row_factory = sqlite3.Row
        return self._conn

    def store(self, name, content, mem_type="reference", tags="", importance=0.5):
        db = self._db()
        try:
            existing = db.execute("SELECT id FROM memories WHERE name=? AND active=1", (name,)).fetchone()
            if existing:
                db.execute("UPDATE memories SET content=?, tags=?, importance=?, updated=datetime('now') WHERE id=?",
                           (content, tags, importance, existing[0]))
            else:
                db.execute("INSERT INTO memories (name, type, tags, content, importance, created, updated, active) "
                           "VALUES (?, ?, ?, ?, ?, datetime('now'), datetime('now'), 1)",
                           (name, mem_type, tags, content, importance))
            db.commit()
        except Exception as e:
            log.error("[%s] store failed: %s", self.name, e)

    def search(self, query, limit=10):
        db = self._db()
        try:
            rows = db.execute(
                "SELECT name, content, tags, type, created, updated FROM memories "
                "WHERE active=1 AND content LIKE ? ORDER BY updated DESC LIMIT ?",
                (f"%{query}%", limit)).fetchall()
            return [dict(r) for r in rows]
        except Exception:
            return []

    def get_config(self, key, default=None):
        return self.config.get(key, default)

    @abstractmethod
    def run(self) -> Dict:
        pass

    @property
    def schedule(self):
        return self.schedule_cron


# =========================================================================
# CATEGORY 1: PERSONAL INTELLIGENCE (10)
# Your brain working FOR you
# =========================================================================

class DecisionJournal(UserWorkflow):
    """Track decisions and their outcomes over time.

    When you make a decision, record it. Months later, this workflow
    checks: was the outcome what you expected? What can you learn?

    Only possible with persistent memory — requires linking a decision
    made in March to its outcome observed in June.
    """
    name = "decision_journal"
    display_name = "Decision Journal"
    description = "Track decisions, predict outcomes, then verify months later — learn what your judgment actually looks like over time"
    category = "personal_intelligence"
    schedule_cron = "0 9 * * 1"
    wow_factor = "Links decisions to outcomes across months — impossible without persistent memory"

    def run(self) -> Dict:
        db = self._db()

        # Find decisions
        decisions = []
        try:
            rows = db.execute(
                "SELECT id, name, content, tags, created FROM memories "
                "WHERE (tags LIKE '%decision%' OR tags LIKE '%chose%' OR tags LIKE '%decided%') "
                "AND active=1 ORDER BY created DESC LIMIT 30"
            ).fetchall()
            decisions = [dict(r) for r in rows]
        except Exception:
            pass

        # Separate: pending review (>30 days old) vs recent
        pending_review = []
        recent = []
        for d in decisions:
            try:
                created = datetime.strptime(d["created"][:10], "%Y-%m-%d")
                age_days = (datetime.now() - created).days
                d["age_days"] = age_days
                if age_days >= 30 and "reviewed" not in d.get("tags", ""):
                    pending_review.append(d)
                elif age_days < 30:
                    recent.append(d)
            except ValueError:
                recent.append(d)

        # Find decisions that have outcome tags
        outcomes_tracked = 0
        try:
            row = db.execute(
                "SELECT COUNT(*) as c FROM memories WHERE tags LIKE '%decision%' "
                "AND tags LIKE '%outcome%' AND active=1"
            ).fetchone()
            outcomes_tracked = row["c"] if row else 0
        except Exception:
            pass

        report = f"# Decision Journal — {datetime.now().strftime('%Y-%m-%d')}\n\n"
        report += f"**Decisions tracked:** {len(decisions)} | **Outcomes recorded:** {outcomes_tracked}\n\n"

        if pending_review:
            report += "## 🔍 Ready for Review (30+ days old — check outcomes)\n"
            for d in pending_review[:10]:
                report += f"- **{d['name']}** ({d['age_days']} days ago): {d['content'][:80]}\n"
                report += f"  → *What actually happened? Update this memory with tag 'outcome'*\n"

        if recent:
            report += "\n## 📝 Recent Decisions\n"
            for d in recent[:10]:
                report += f"- {d['name']} ({d['age_days']}d ago): {d['content'][:80]}\n"

        report += "\n## How to Use\n"
        report += "1. When you decide something: store with tag 'decision'\n"
        report += "2. Include your expected outcome in the content\n"
        report += "3. After 30+ days, this workflow flags it for review\n"
        report += "4. Record what actually happened with tag 'outcome'\n"
        report += "5. Over time: see if your judgment improves\n"

        self.store(f"decision_journal_{datetime.now().strftime('%Y%m%d')}",
                   report, "reference", "decision_journal,reflection,auto", 0.7)

        return {"status": "ok", "decisions": len(decisions),
                "pending_review": len(pending_review), "outcomes": outcomes_tracked}


class ContradictionDetector(UserWorkflow):
    """Find contradictions in your stated beliefs, decisions, and preferences.

    Scans all memories for conflicting statements. "I prefer Python" vs
    "I'm switching everything to Rust." Only works with months of accumulated memory.
    """
    name = "contradiction_detector"
    display_name = "Contradiction Detector"
    description = "Find when you've said or decided contradictory things — the mirror your brain needs"
    category = "personal_intelligence"
    schedule_cron = "0 21 * * 0"
    wow_factor = "Requires months of memory to find contradictions across time"

    def run(self) -> Dict:
        db = self._db()
        contradictions = []

        # Load preferences and decisions
        statements = []
        try:
            rows = db.execute(
                "SELECT name, content, created FROM memories "
                "WHERE (type='preference' OR tags LIKE '%decision%' OR tags LIKE '%belief%' "
                "OR tags LIKE '%preference%' OR tags LIKE '%principle%') "
                "AND active=1 ORDER BY created DESC LIMIT 100"
            ).fetchall()
            statements = [dict(r) for r in rows]
        except Exception:
            pass

        # Look for opposing sentiment patterns
        opposition_pairs = [
            (r'\b(?:always|prefer|love|best)\b', r'\b(?:never|avoid|hate|worst)\b'),
            (r'\b(?:will|should|must|need to)\b', r'\b(?:won\'t|shouldn\'t|can\'t|refuse)\b'),
            (r'\b(?:increase|more|grow|expand)\b', r'\b(?:decrease|less|shrink|reduce)\b'),
        ]

        # Group by topic (using name similarity)
        by_topic = defaultdict(list)
        for s in statements:
            # Extract topic from name
            topic = re.sub(r'[_\d]+', ' ', s["name"]).strip().lower()[:30]
            by_topic[topic].append(s)

        # Find topics with potentially contradictory entries
        for topic, items in by_topic.items():
            if len(items) < 2:
                continue
            # Compare oldest vs newest
            oldest = items[-1]
            newest = items[0]
            if oldest["content"] != newest["content"]:
                # Check if sentiment shifted
                for pos_pattern, neg_pattern in opposition_pairs:
                    old_pos = bool(re.search(pos_pattern, oldest["content"], re.IGNORECASE))
                    new_neg = bool(re.search(neg_pattern, newest["content"], re.IGNORECASE))
                    old_neg = bool(re.search(neg_pattern, oldest["content"], re.IGNORECASE))
                    new_pos = bool(re.search(pos_pattern, newest["content"], re.IGNORECASE))

                    if (old_pos and new_neg) or (old_neg and new_pos):
                        contradictions.append({
                            "topic": topic,
                            "then": {"date": oldest["created"][:10], "said": oldest["content"][:100]},
                            "now": {"date": newest["created"][:10], "said": newest["content"][:100]},
                        })
                        break

        report = f"# Contradiction Check — {datetime.now().strftime('%Y-%m-%d')}\n\n"

        if contradictions:
            report += f"**{len(contradictions)} potential contradictions found**\n\n"
            for c in contradictions[:10]:
                report += f"### {c['topic']}\n"
                report += f"**Then** ({c['then']['date']}): {c['then']['said']}\n"
                report += f"**Now** ({c['now']['date']}): {c['now']['said']}\n"
                report += f"*Did your thinking change, or is this an inconsistency to resolve?*\n\n"
        else:
            report += "No contradictions detected. Either you're remarkably consistent, "
            report += "or the brain needs more preference/decision data.\n"

        self.store(f"contradictions_{datetime.now().strftime('%Y%m%d')}",
                   report, "reference", "contradictions,reflection,auto", 0.6)

        return {"status": "ok", "statements_analyzed": len(statements),
                "contradictions": len(contradictions)}


class IdeaIncubator(UserWorkflow):
    """Collect scattered ideas, find connections, surface when relevant.

    Ideas stored months apart might connect in ways you didn't see.
    This workflow finds those connections.
    """
    name = "idea_incubator"
    display_name = "Idea Incubator"
    description = "Connect scattered ideas across time — find patterns between thoughts you had months apart"
    category = "personal_intelligence"
    schedule_cron = "0 20 * * 3"
    wow_factor = "Connects ideas stored months apart — requires long-term memory"

    def run(self) -> Dict:
        db = self._db()
        ideas = []
        try:
            rows = db.execute(
                "SELECT name, content, tags, created FROM memories "
                "WHERE (tags LIKE '%idea%' OR tags LIKE '%thought%' OR tags LIKE '%concept%') "
                "AND active=1 ORDER BY created DESC LIMIT 50"
            ).fetchall()
            ideas = [dict(r) for r in rows]
        except Exception:
            pass

        # Find word overlap between ideas (potential connections)
        connections = []
        for i, idea_a in enumerate(ideas):
            words_a = set(re.findall(r'\b\w{4,}\b', idea_a["content"].lower()))
            for idea_b in ideas[i+1:]:
                words_b = set(re.findall(r'\b\w{4,}\b', idea_b["content"].lower()))
                overlap = words_a & words_b - {"this", "that", "with", "from", "have", "been", "about"}
                if len(overlap) >= 3:
                    connections.append({
                        "idea_a": idea_a["name"],
                        "idea_b": idea_b["name"],
                        "shared_concepts": list(overlap)[:5],
                        "a_date": idea_a["created"][:10],
                        "b_date": idea_b["created"][:10],
                    })

        report = f"# Idea Incubator — {datetime.now().strftime('%Y-%m-%d')}\n\n"
        report += f"**{len(ideas)} ideas stored** | **{len(connections)} connections found**\n\n"

        if connections:
            report += "## Connected Ideas\n"
            for c in connections[:10]:
                report += f"- **{c['idea_a']}** ({c['a_date']}) ↔ **{c['idea_b']}** ({c['b_date']})\n"
                report += f"  Shared: {', '.join(c['shared_concepts'])}\n"
                report += f"  *Could these combine into something?*\n\n"

        # Surface oldest unconnected ideas
        connected_names = set()
        for c in connections:
            connected_names.add(c["idea_a"])
            connected_names.add(c["idea_b"])
        orphans = [i for i in ideas if i["name"] not in connected_names]

        if orphans:
            report += "## Orphan Ideas (no connections found yet)\n"
            for o in orphans[:10]:
                report += f"- {o['name']} ({o['created'][:10]}): {o['content'][:80]}\n"

        self.store(f"incubator_{datetime.now().strftime('%Y%m%d')}",
                   report, "reference", "ideas,incubator,connections,auto", 0.6)

        return {"status": "ok", "ideas": len(ideas), "connections": len(connections)}


class PersonalKnowledgeWiki(UserWorkflow):
    """Auto-generate a searchable wiki from all your memories.

    Organizes everything you know into a browsable structure.
    """
    name = "knowledge_wiki"
    display_name = "Personal Knowledge Wiki"
    description = "Auto-generate an organized wiki from everything your brain knows"
    category = "personal_intelligence"
    schedule_cron = "0 22 * * 0"
    wow_factor = "Builds a personal encyclopedia from accumulated memories"

    def run(self) -> Dict:
        db = self._db()

        # Get all active memories grouped by type
        by_type = defaultdict(list)
        total = 0
        try:
            rows = db.execute(
                "SELECT name, content, type, tags, created, updated FROM memories "
                "WHERE active=1 ORDER BY type, updated DESC"
            ).fetchall()
            for r in rows:
                by_type[r["type"]].append(dict(r))
                total += 1
        except Exception:
            pass

        # Get all unique tags
        all_tags = Counter()
        for memories in by_type.values():
            for m in memories:
                for tag in (m.get("tags", "") or "").split(","):
                    tag = tag.strip()
                    if tag and tag != "auto":
                        all_tags[tag] += 1

        wiki = f"# Personal Knowledge Wiki\n"
        wiki += f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M')}\n"
        wiki += f"**Total entries:** {total}\n"
        wiki += f"**Categories:** {len(by_type)}\n"
        wiki += f"**Tags:** {len(all_tags)}\n\n"

        wiki += "## Table of Contents\n"
        for mem_type, memories in sorted(by_type.items()):
            wiki += f"- [{mem_type.title()}] ({len(memories)} entries)\n"

        for mem_type, memories in sorted(by_type.items()):
            wiki += f"\n---\n## {mem_type.title()} ({len(memories)})\n\n"
            for m in memories[:20]:
                wiki += f"### {m['name']}\n"
                wiki += f"*{m['created'][:10]}* | Tags: {m.get('tags', 'none')}\n\n"
                wiki += f"{m['content'][:200]}\n\n"

        wiki += "---\n## Tag Index\n"
        for tag, count in all_tags.most_common(30):
            wiki += f"- **{tag}** ({count} entries)\n"

        self.store("knowledge_wiki", wiki, "reference",
                   "wiki,knowledge,index,auto", 0.6)

        return {"status": "ok", "entries": total, "categories": len(by_type),
                "tags": len(all_tags)}


class LifeDashboard(UserWorkflow):
    """Single-view dashboard of everything that matters."""
    name = "life_dashboard"
    display_name = "Life Dashboard"
    description = "One view showing projects, goals, habits, decisions, and what needs attention"
    category = "personal_intelligence"
    schedule_cron = "0 6 * * *"
    wow_factor = "Aggregates everything across all brain systems into one actionable view"

    def run(self) -> Dict:
        db = self._db()

        # Gather all status data
        stats = {}
        queries = {
            "active_projects": "SELECT COUNT(*) as c FROM memories WHERE type='project' AND active=1",
            "total_memories": "SELECT COUNT(*) as c FROM memories WHERE active=1",
            "decisions_pending": "SELECT COUNT(*) as c FROM memories WHERE tags LIKE '%decision%' AND tags NOT LIKE '%outcome%' AND active=1",
            "follow_ups": "SELECT COUNT(*) as c FROM memories WHERE tags LIKE '%follow_up%' AND active=1",
            "ideas": "SELECT COUNT(*) as c FROM memories WHERE tags LIKE '%idea%' AND active=1",
        }
        for key, query in queries.items():
            try:
                row = db.execute(query).fetchone()
                stats[key] = row["c"] if row else 0
            except Exception:
                stats[key] = 0

        # Skill health
        try:
            row = db.execute(
                "SELECT COUNT(DISTINCT task_type) as types, AVG(outcome_quality) as avg "
                "FROM skill_episodes WHERE created_at >= datetime('now', '-30 days')"
            ).fetchone()
            stats["skill_types"] = row["types"] if row else 0
            stats["avg_quality"] = round(row["avg"], 2) if row and row["avg"] else 0
        except Exception:
            stats["skill_types"] = 0
            stats["avg_quality"] = 0

        dashboard = f"# Life Dashboard — {datetime.now().strftime('%A, %B %d, %Y')}\n\n"
        dashboard += f"🧠 **{stats['total_memories']}** memories | "
        dashboard += f"📁 **{stats['active_projects']}** projects | "
        dashboard += f"💡 **{stats['ideas']}** ideas\n"
        dashboard += f"⚖️ **{stats['decisions_pending']}** decisions awaiting outcome review\n"
        dashboard += f"📋 **{stats['follow_ups']}** pending follow-ups\n"
        dashboard += f"🎯 **{stats['skill_types']}** skill types practiced (avg quality: {stats['avg_quality']:.0%})\n"

        # What needs attention
        dashboard += "\n## Needs Attention\n"
        if stats["decisions_pending"] > 5:
            dashboard += f"- ⚠️ {stats['decisions_pending']} decisions with no outcome tracked\n"
        if stats["follow_ups"] > 3:
            dashboard += f"- ⚠️ {stats['follow_ups']} follow-ups pending\n"
        if stats["avg_quality"] < 0.6 and stats["skill_types"] > 0:
            dashboard += f"- ⚠️ Average task quality below 60% — review skill principles\n"

        self.store("life_dashboard", dashboard, "reference",
                   "dashboard,overview,daily,auto", 0.7)

        return {"status": "ok", **stats}


class LearningPathGenerator(UserWorkflow):
    """Identify what you're learning and suggest next steps."""
    name = "learning_path"
    display_name = "Learning Path Generator"
    description = "Map your learning trajectory and suggest what to study next based on gaps and interests"
    category = "personal_intelligence"
    schedule_cron = "0 9 * * 1"
    wow_factor = "Maps learning trajectory across months of accumulated skill data"

    def run(self) -> Dict:
        db = self._db()

        # What skills have you been practicing?
        skills_practiced = []
        try:
            rows = db.execute(
                "SELECT task_type, COUNT(*) as episodes, AVG(outcome_quality) as avg, "
                "MIN(created_at) as first, MAX(created_at) as last "
                "FROM skill_episodes GROUP BY task_type ORDER BY episodes DESC"
            ).fetchall()
            skills_practiced = [dict(r) for r in rows]
        except Exception:
            pass

        # What topics keep appearing in your memories?
        topic_frequency = Counter()
        try:
            rows = db.execute(
                "SELECT tags FROM memories WHERE active=1 AND created >= datetime('now', '-30 days')"
            ).fetchall()
            for r in rows:
                for tag in (r["tags"] or "").split(","):
                    tag = tag.strip()
                    if tag and tag not in ("auto", "reference"):
                        topic_frequency[tag] += 1
        except Exception:
            pass

        report = f"# Learning Path — {datetime.now().strftime('%Y-%m-%d')}\n\n"

        if skills_practiced:
            report += "## Skills You're Building\n"
            for s in skills_practiced[:10]:
                level = "🟢 Proficient" if s["avg"] > 0.7 else "🟡 Developing" if s["avg"] > 0.4 else "🔴 Beginner"
                report += f"- {level} **{s['task_type']}**: {s['episodes']} episodes, {s['avg']:.0%} avg\n"

            # Suggest what to focus on
            weakest = [s for s in skills_practiced if s["avg"] < 0.6]
            if weakest:
                report += "\n## Suggested Focus Areas\n"
                for w in weakest[:5]:
                    report += f"- **{w['task_type']}** — {w['avg']:.0%} quality, needs practice\n"

        if topic_frequency:
            report += "\n## Your Interest Map (last 30 days)\n"
            for topic, count in topic_frequency.most_common(15):
                report += f"- {topic}: {count} touches\n"

        self.store(f"learning_path_{datetime.now().strftime('%Y%m%d')}",
                   report, "reference", "learning,path,growth,auto", 0.6)

        return {"status": "ok", "skills": len(skills_practiced),
                "topics": len(topic_frequency)}


class CommitmentTracker(UserWorkflow):
    """Track promises and commitments with deadlines."""
    name = "commitment_tracker"
    display_name = "Commitment Tracker"
    description = "Never forget a promise — tracks commitments you've made and reminds before deadlines"
    category = "personal_intelligence"
    schedule_cron = "0 8 * * *"
    wow_factor = "Remembers every commitment across all conversations — nothing falls through cracks"

    def run(self) -> Dict:
        db = self._db()
        commitments = []
        try:
            rows = db.execute(
                "SELECT name, content, tags, created FROM memories "
                "WHERE (tags LIKE '%commitment%' OR tags LIKE '%promise%' OR tags LIKE '%deliverable%') "
                "AND active=1 ORDER BY created ASC"
            ).fetchall()
            commitments = [dict(r) for r in rows]
        except Exception:
            pass

        today = datetime.now().strftime("%Y-%m-%d")
        overdue = []
        upcoming = []
        completed = []

        for c in commitments:
            if "completed" in c.get("tags", ""):
                completed.append(c)
                continue
            date_match = re.search(r'(\d{4}-\d{2}-\d{2})', c.get("content", ""))
            if date_match:
                due = date_match.group(1)
                if due < today:
                    overdue.append({**c, "due": due})
                else:
                    upcoming.append({**c, "due": due})
            else:
                upcoming.append({**c, "due": "no date"})

        report = f"# Commitments — {today}\n\n"
        report += f"📊 Active: {len(upcoming)} | ⚠️ Overdue: {len(overdue)} | ✅ Completed: {len(completed)}\n\n"

        if overdue:
            report += "## ⚠️ OVERDUE\n"
            for o in overdue:
                report += f"- **{o['name']}** (due {o['due']}): {o['content'][:80]}\n"

        if upcoming:
            report += "\n## 📅 Upcoming\n"
            for u in sorted(upcoming, key=lambda x: x.get("due", "9999"))[:10]:
                report += f"- {u['name']} (due {u.get('due', '?')}): {u['content'][:80]}\n"

        self.store(f"commitments_{today}", report, "reference",
                   "commitments,tracking,auto", 0.8 if overdue else 0.5)

        return {"status": "ok", "active": len(upcoming), "overdue": len(overdue),
                "completed": len(completed)}


class ContextSwitcher(UserWorkflow):
    """Prepare briefings when switching between projects."""
    name = "context_switcher"
    display_name = "Context Switcher"
    description = "Instant context reload — pick up any project exactly where you left off"
    category = "personal_intelligence"
    schedule_cron = "0 8 * * *"
    wow_factor = "Restores complete project context from memory — like you never left"

    def run(self) -> Dict:
        db = self._db()
        projects = []
        try:
            rows = db.execute(
                "SELECT DISTINCT name, content, updated FROM memories "
                "WHERE type='project' AND active=1 ORDER BY updated DESC LIMIT 10"
            ).fetchall()
            projects = [dict(r) for r in rows]
        except Exception:
            pass

        for proj in projects:
            name = proj["name"]
            # Gather all context for this project
            related = self.search(name, limit=15)
            decisions = [r for r in related if "decision" in r.get("tags", "")]
            todos = [r for r in related if any(t in r.get("tags", "") for t in ("todo", "task", "action"))]

            briefing = f"# Context: {name}\n"
            briefing += f"**Last touched:** {proj['updated'][:16]}\n\n"
            briefing += f"**Status:** {proj['content'][:200]}\n\n"

            if decisions:
                briefing += "## Key Decisions\n"
                for d in decisions[:5]:
                    briefing += f"- {d['content'][:80]}\n"

            if todos:
                briefing += "\n## Open Tasks\n"
                for t in todos[:5]:
                    briefing += f"- [ ] {t['content'][:80]}\n"

            self.store(f"context_{name}", briefing, "reference",
                       f"context,{name},briefing,auto", 0.5)

        return {"status": "ok", "projects": len(projects)}


class WeeklyWinsCollector(UserWorkflow):
    """Find accomplishments you forgot about."""
    name = "weekly_wins"
    display_name = "Weekly Wins Collector"
    description = "Surface your accomplishments from the week — the achievements you already forgot"
    category = "personal_intelligence"
    schedule_cron = "0 18 * * 5"
    wow_factor = "Finds accomplishments buried in memory that you already forgot about"

    def run(self) -> Dict:
        db = self._db()

        # Search for win indicators in recent memories
        win_keywords = ["completed", "shipped", "launched", "fixed", "built", "achieved",
                       "resolved", "delivered", "published", "released", "improved", "automated"]

        wins = []
        for keyword in win_keywords:
            results = self.search(keyword, limit=5)
            for r in results:
                try:
                    created = r.get("created", "")[:10]
                    age = (datetime.now() - datetime.strptime(created, "%Y-%m-%d")).days
                    if age <= 7:
                        wins.append({**r, "keyword": keyword})
                except ValueError:
                    pass

        # Deduplicate
        seen = set()
        unique_wins = []
        for w in wins:
            if w["name"] not in seen:
                unique_wins.append(w)
                seen.add(w["name"])

        # Also check skill episodes with high outcomes
        try:
            rows = db.execute(
                "SELECT task_type, task_description, outcome_quality FROM skill_episodes "
                "WHERE outcome_quality >= 0.8 AND created_at >= datetime('now', '-7 days') "
                "ORDER BY outcome_quality DESC LIMIT 10"
            ).fetchall()
            for r in rows:
                unique_wins.append({
                    "name": f"High-quality {r['task_type']}",
                    "content": r["task_description"],
                    "keyword": f"{r['outcome_quality']:.0%} quality",
                })
        except Exception:
            pass

        report = f"# Weekly Wins — {datetime.now().strftime('%Y-%m-%d')}\n\n"
        report += f"**{len(unique_wins)} wins this week!**\n\n"

        if unique_wins:
            for w in unique_wins:
                report += f"- 🏆 **{w['name']}**: {w['content'][:80]}\n"
        else:
            report += "No explicit wins detected. That doesn't mean nothing happened — "
            report += "try tagging achievements with 'completed' or 'shipped'.\n"

        report += "\n*Share these with your manager, your partner, or just yourself. "
        report += "You did more than you think.*\n"

        self.store(f"wins_{datetime.now().strftime('%Y_W%W')}",
                   report, "reference", "wins,weekly,celebration,auto", 0.7)

        return {"status": "ok", "wins": len(unique_wins)}


# =========================================================================
# CATEGORY 2: PROFESSIONAL ACCELERATION (10)
# =========================================================================

class ResumeAutoUpdater(UserWorkflow):
    """Maintain a live resume from achievements as they happen."""
    name = "resume_updater"
    display_name = "Resume Auto-Updater"
    description = "Your resume updates itself — captures achievements in real-time as you work"
    category = "professional"
    schedule_cron = "0 18 * * 5"
    wow_factor = "Resume builds itself from months of tracked accomplishments"

    def run(self) -> Dict:
        db = self._db()

        # Gather achievements
        achievements = []
        try:
            rows = db.execute(
                "SELECT name, content, tags, created FROM memories "
                "WHERE (tags LIKE '%achievement%' OR tags LIKE '%shipped%' OR tags LIKE '%completed%' "
                "OR tags LIKE '%built%' OR tags LIKE '%launched%') "
                "AND active=1 ORDER BY created DESC LIMIT 30"
            ).fetchall()
            achievements = [dict(r) for r in rows]
        except Exception:
            pass

        # Gather skill proficiencies
        skills = []
        try:
            rows = db.execute(
                "SELECT task_type, COUNT(*) as episodes, AVG(outcome_quality) as avg "
                "FROM skill_episodes GROUP BY task_type HAVING episodes >= 5 "
                "ORDER BY avg DESC LIMIT 15"
            ).fetchall()
            skills = [dict(r) for r in rows]
        except Exception:
            pass

        resume = f"# Live Resume (Auto-Generated)\n"
        resume += f"**Updated:** {datetime.now().strftime('%Y-%m-%d')}\n\n"

        if skills:
            resume += "## Demonstrated Skills\n"
            for s in skills:
                level = "Expert" if s["avg"] > 0.8 else "Proficient" if s["avg"] > 0.6 else "Competent"
                resume += f"- **{s['task_type']}** — {level} ({s['episodes']} demonstrated instances)\n"

        if achievements:
            resume += "\n## Recent Achievements\n"
            for a in achievements[:15]:
                resume += f"- {a['content'][:100]} ({a['created'][:10]})\n"

        resume += "\n*This resume updates automatically from your aibrain data. "
        resume += "Tag achievements with 'achievement' or 'shipped' to include them.*\n"

        self.store("live_resume", resume, "reference",
                   "resume,career,auto", 0.6)

        return {"status": "ok", "achievements": len(achievements), "skills": len(skills)}


class MeetingPrepAutomator(UserWorkflow):
    """Pull all context about meeting attendees and topics before meetings."""
    name = "meeting_prep"
    display_name = "Meeting Prep Automator"
    description = "Auto-generate meeting prep with everything you know about each attendee and topic"
    category = "professional"
    schedule_cron = "0 7 * * 1-5"
    wow_factor = "Pulls everything you've ever discussed with each attendee — impossible without persistent memory"

    def run(self) -> Dict:
        # Find upcoming meetings
        meetings = self.search("meeting", limit=10)

        preps = 0
        for meeting in meetings:
            content = meeting.get("content", "")
            # Extract person names (capitalized words that might be names)
            names = re.findall(r'\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)\b', content)
            names = [n for n in names if len(n) > 3 and n not in
                    ("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Meeting", "Review")]

            if names:
                prep = f"# Meeting Prep: {meeting['name']}\n\n"
                for name in set(names[:5]):
                    context = self.search(name, limit=5)
                    if context:
                        prep += f"## {name}\n"
                        for c in context[:3]:
                            prep += f"- {c['content'][:80]}\n"
                        prep += "\n"

                self.store(f"meeting_prep_{meeting['name'][:30]}",
                           prep, "reference", "meeting,prep,auto", 0.6)
                preps += 1

        return {"status": "ok", "meetings_prepped": preps}


class OneOnOnePrepRunner(UserWorkflow):
    """Prepare talking points for 1-on-1 meetings from accumulated context."""
    name = "one_on_one_prep"
    display_name = "1-on-1 Prep"
    description = "Generate talking points for 1-on-1s from everything you know about each person"
    category = "professional"
    schedule_cron = "0 8 * * 1"
    wow_factor = "Accumulates context about each person across all interactions"

    def run(self) -> Dict:
        people = self.get_config("one_on_one_people", "").split(",")
        people = [p.strip() for p in people if p.strip()]

        if not people:
            return {"status": "ok", "message": "Set one_on_one_people config with comma-separated names"}

        for person in people:
            context = self.search(person, limit=15)
            decisions = [c for c in context if "decision" in c.get("tags", "")]
            tasks = [c for c in context if any(t in c.get("tags", "") for t in ("task", "project", "work"))]

            prep = f"# 1-on-1 Prep: {person}\n"
            prep += f"**Date:** {datetime.now().strftime('%Y-%m-%d')}\n\n"

            if tasks:
                prep += "## Their Active Work\n"
                for t in tasks[:5]:
                    prep += f"- {t['content'][:80]}\n"

            if decisions:
                prep += "\n## Recent Decisions\n"
                for d in decisions[:3]:
                    prep += f"- {d['content'][:80]}\n"

            prep += "\n## Talking Points\n"
            prep += "- What's going well?\n"
            prep += "- What's blocking them?\n"
            prep += "- How can I help?\n"
            prep += "- Feedback to give:\n"
            prep += "- Feedback to ask for:\n"

            self.store(f"1on1_{person.replace(' ', '_')}", prep, "reference",
                       f"1on1,{person},prep,auto", 0.6)

        return {"status": "ok", "people_prepped": len(people)}


class ClientIntelligenceBrief(UserWorkflow):
    """Everything you know about a client, refreshed before meetings."""
    name = "client_intelligence"
    display_name = "Client Intelligence Brief"
    description = "Instant recall of every interaction, decision, and preference for each client"
    category = "professional"
    schedule_cron = "0 7 * * 1-5"
    wow_factor = "Total client recall across months of interactions"

    def run(self) -> Dict:
        clients = self.get_config("clients", "").split(",")
        clients = [c.strip() for c in clients if c.strip()]

        if not clients:
            return {"status": "ok", "message": "Set clients config"}

        for client in clients:
            context = self.search(client, limit=20)

            brief = f"# Client Brief: {client}\n\n"
            brief += f"**Knowledge depth:** {len(context)} memories\n\n"

            if context:
                # Chronological summary
                brief += "## Key Information\n"
                for c in context[:10]:
                    brief += f"- ({c.get('created', '')[:10]}) {c['content'][:80]}\n"

            self.store(f"client_brief_{client.replace(' ', '_')}", brief,
                       "reference", f"client,{client},brief,auto", 0.7)

        return {"status": "ok", "clients": len(clients)}


class SkillGapAnalyzer(UserWorkflow):
    """Compare your skills to what the market demands."""
    name = "skill_gap_analyzer"
    display_name = "Skill Gap Analyzer"
    description = "Compare your demonstrated skills against market demands and identify growth opportunities"
    category = "professional"
    schedule_cron = "0 9 * * 1"
    wow_factor = "Compares actual demonstrated competence (from episodes) to market requirements"

    def run(self) -> Dict:
        db = self._db()

        target_skills = self.get_config("target_skills",
            "python,security,cloud,kubernetes,api_design,system_design").split(",")
        target_skills = [s.strip() for s in target_skills if s.strip()]

        # Get actual skill levels
        actual = {}
        try:
            rows = db.execute(
                "SELECT task_type, AVG(outcome_quality) as avg, COUNT(*) as episodes "
                "FROM skill_episodes GROUP BY task_type"
            ).fetchall()
            for r in rows:
                actual[r["task_type"]] = {"avg": round(r["avg"], 2), "episodes": r["episodes"]}
        except Exception:
            pass

        report = f"# Skill Gap Analysis — {datetime.now().strftime('%Y-%m-%d')}\n\n"
        report += "| Skill | Level | Episodes | Gap |\n"
        report += "|-------|-------|----------|-----|\n"

        gaps = []
        for skill in target_skills:
            data = actual.get(skill, {"avg": 0, "episodes": 0})
            if data["episodes"] == 0:
                level = "No data"
                gap = "🔴 Not practiced"
            elif data["avg"] >= 0.8:
                level = f"{data['avg']:.0%}"
                gap = "🟢 Strong"
            elif data["avg"] >= 0.5:
                level = f"{data['avg']:.0%}"
                gap = "🟡 Developing"
            else:
                level = f"{data['avg']:.0%}"
                gap = "🔴 Needs work"
                gaps.append(skill)

            report += f"| {skill} | {level} | {data['episodes']} | {gap} |\n"

        if gaps:
            report += f"\n## Priority Development Areas\n"
            for g in gaps:
                report += f"- **{g}** — practice this skill to build demonstrated competence\n"

        self.store(f"skill_gaps_{datetime.now().strftime('%Y%m%d')}",
                   report, "reference", "skills,gaps,career,auto", 0.6)

        return {"status": "ok", "target_skills": len(target_skills), "gaps": len(gaps)}


class PortfolioBuilder(UserWorkflow):
    """Collect completed work into showcase format."""
    name = "portfolio_builder"
    display_name = "Portfolio Builder"
    description = "Auto-curate a portfolio from your shipped work and high-quality task completions"
    category = "professional"
    schedule_cron = "0 10 * * 6"
    wow_factor = "Portfolio builds itself from months of tracked project completions"

    def run(self) -> Dict:
        shipped = self.search("shipped", limit=20)
        shipped += self.search("launched", limit=10)
        shipped += self.search("published", limit=10)
        shipped += self.search("released", limit=10)

        # Deduplicate
        seen = set()
        portfolio_items = []
        for item in shipped:
            if item["name"] not in seen:
                portfolio_items.append(item)
                seen.add(item["name"])

        portfolio = f"# Portfolio\n"
        portfolio += f"**Updated:** {datetime.now().strftime('%Y-%m-%d')}\n"
        portfolio += f"**Items:** {len(portfolio_items)}\n\n"

        for item in portfolio_items[:20]:
            portfolio += f"### {item['name']}\n"
            portfolio += f"*{item.get('created', '')[:10]}*\n"
            portfolio += f"{item['content'][:200]}\n\n"

        self.store("portfolio", portfolio, "reference", "portfolio,showcase,auto", 0.5)

        return {"status": "ok", "items": len(portfolio_items)}


class CareerTrajectoryAnalyzer(UserWorkflow):
    """Map career progression from accumulated data."""
    name = "career_trajectory"
    display_name = "Career Trajectory Analyzer"
    description = "Visualize your career arc — skills gained, projects completed, growth over time"
    category = "professional"
    schedule_cron = "0 10 * * 1"
    wow_factor = "Plots career growth from months of accumulated skill and project data"

    def run(self) -> Dict:
        db = self._db()

        # Monthly skill progression
        monthly = []
        try:
            rows = db.execute(
                "SELECT strftime('%Y-%m', created_at) as month, "
                "COUNT(*) as episodes, AVG(outcome_quality) as avg "
                "FROM skill_episodes GROUP BY month ORDER BY month"
            ).fetchall()
            monthly = [dict(r) for r in rows]
        except Exception:
            pass

        report = f"# Career Trajectory — {datetime.now().strftime('%Y-%m-%d')}\n\n"

        if monthly:
            report += "## Monthly Progression\n"
            for m in monthly:
                bar = "█" * int(m["avg"] * 20) if m["avg"] else ""
                report += f"- {m['month']}: {m['episodes']} tasks, {m['avg']:.0%} avg {bar}\n"

        # Total growth stats
        try:
            first = db.execute("SELECT MIN(created_at) as first FROM skill_episodes").fetchone()
            total = db.execute("SELECT COUNT(*) as c FROM skill_episodes").fetchone()
            if first and total:
                report += f"\n## Summary\n"
                report += f"- Tracking since: {first['first'][:10] if first['first'] else 'N/A'}\n"
                report += f"- Total episodes: {total['c']}\n"
        except Exception:
            pass

        self.store(f"trajectory_{datetime.now().strftime('%Y%m%d')}",
                   report, "reference", "career,trajectory,growth,auto", 0.5)

        return {"status": "ok", "months_tracked": len(monthly)}


class ProfessionalDevPlanner(UserWorkflow):
    """Identify growth areas from task performance data."""
    name = "professional_dev"
    display_name = "Professional Development Planner"
    description = "Data-driven development plan based on your actual task performance patterns"
    category = "professional"
    schedule_cron = "0 9 * * 1"
    wow_factor = "Development plan built from real performance data, not self-assessment"

    def run(self) -> Dict:
        db = self._db()

        # Find skills with most room for improvement
        growth_areas = []
        try:
            rows = db.execute(
                "SELECT task_type, AVG(outcome_quality) as avg, COUNT(*) as episodes "
                "FROM skill_episodes GROUP BY task_type HAVING episodes >= 3 "
                "ORDER BY avg ASC LIMIT 10"
            ).fetchall()
            growth_areas = [dict(r) for r in rows]
        except Exception:
            pass

        plan = f"# Development Plan — {datetime.now().strftime('%Y-%m-%d')}\n\n"

        if growth_areas:
            plan += "## Growth Opportunities (by demonstrated performance)\n"
            for g in growth_areas:
                plan += f"- **{g['task_type']}**: {g['avg']:.0%} average over {g['episodes']} episodes\n"
                plan += f"  → Practice deliberately. Review principles. Seek feedback.\n"
        else:
            plan += "Not enough task data yet. Complete more tasks with skill tracking enabled.\n"

        self.store(f"dev_plan_{datetime.now().strftime('%Y%m%d')}",
                   plan, "reference", "development,career,growth,auto", 0.6)

        return {"status": "ok", "growth_areas": len(growth_areas)}


class SalaryIntelligence(UserWorkflow):
    """Track your value based on accumulated project history."""
    name = "salary_intelligence"
    display_name = "Salary/Rate Intelligence"
    description = "Calculate your demonstrated value from project outcomes and skill proficiency"
    category = "professional"
    schedule_cron = "0 10 * * 1"
    wow_factor = "Objective value assessment from accumulated skill data and project outcomes"

    def run(self) -> Dict:
        db = self._db()

        expert_skills = 0
        proficient_skills = 0
        total_episodes = 0

        try:
            rows = db.execute(
                "SELECT task_type, AVG(outcome_quality) as avg, COUNT(*) as episodes "
                "FROM skill_episodes GROUP BY task_type"
            ).fetchall()
            for r in rows:
                total_episodes += r["episodes"]
                if r["avg"] >= 0.8:
                    expert_skills += 1
                elif r["avg"] >= 0.6:
                    proficient_skills += 1
        except Exception:
            pass

        report = f"# Value Assessment — {datetime.now().strftime('%Y-%m-%d')}\n\n"
        report += f"**Expert skills:** {expert_skills}\n"
        report += f"**Proficient skills:** {proficient_skills}\n"
        report += f"**Total demonstrated tasks:** {total_episodes}\n\n"
        report += "## Rate Justification\n"
        report += "When negotiating, reference:\n"
        report += f"- {expert_skills} areas of demonstrated expertise\n"
        report += f"- {total_episodes} documented task completions\n"
        report += "- Specific project outcomes and metrics from your portfolio\n"

        self.store(f"value_assessment_{datetime.now().strftime('%Y%m%d')}",
                   report, "reference", "salary,value,career,auto", 0.5)

        return {"status": "ok", "expert": expert_skills, "proficient": proficient_skills}


# =========================================================================
# CATEGORY 3: KNOWLEDGE SYNTHESIS (10)
# =========================================================================

class InsightCrystallizer(UserWorkflow):
    """Distill scattered notes into core insights."""
    name = "insight_crystallizer"
    display_name = "Insight Crystallizer"
    description = "Distill hundreds of scattered memories into the 10 core insights that matter most"
    category = "knowledge"
    schedule_cron = "0 21 * * 0"
    wow_factor = "Distills months of accumulated knowledge into actionable core insights"

    def run(self) -> Dict:
        db = self._db()

        # Find the most-referenced and highest-importance memories
        key_memories = []
        try:
            rows = db.execute(
                "SELECT name, content, importance, tags FROM memories "
                "WHERE active=1 AND importance >= 0.7 ORDER BY importance DESC LIMIT 20"
            ).fetchall()
            key_memories = [dict(r) for r in rows]
        except Exception:
            pass

        # Find most-active principles
        principles = []
        try:
            rows = db.execute(
                "SELECT task_type, principle, confidence FROM skill_principles "
                "WHERE status='active' ORDER BY confidence DESC LIMIT 10"
            ).fetchall()
            principles = [dict(r) for r in rows]
        except Exception:
            pass

        report = f"# Core Insights — {datetime.now().strftime('%Y-%m-%d')}\n\n"

        if principles:
            report += "## Highest-Confidence Principles\n"
            report += "*These are the things you've proven work through repeated practice:*\n\n"
            for p in principles:
                report += f"- ({p['confidence']:.0%}) **{p['task_type']}**: {p['principle'][:100]}\n"

        if key_memories:
            report += "\n## Most Important Knowledge\n"
            for m in key_memories[:10]:
                report += f"- **{m['name']}** (importance: {m['importance']:.0%}): {m['content'][:80]}\n"

        self.store(f"insights_{datetime.now().strftime('%Y%m%d')}",
                   report, "reference", "insights,crystallized,auto", 0.8)

        return {"status": "ok", "principles": len(principles), "key_memories": len(key_memories)}


class CrossDomainConnector(UserWorkflow):
    """Find unexpected connections between different knowledge areas."""
    name = "cross_domain"
    display_name = "Cross-Domain Connector"
    description = "Find surprising connections between unrelated topics in your knowledge base"
    category = "knowledge"
    schedule_cron = "0 20 * * 3"
    wow_factor = "Finds connections between knowledge areas you never thought to link"

    def run(self) -> Dict:
        db = self._db()

        # Group memories by primary tag
        domains = defaultdict(list)
        try:
            rows = db.execute(
                "SELECT name, content, tags FROM memories WHERE active=1 "
                "AND importance >= 0.5 LIMIT 200"
            ).fetchall()
            for r in rows:
                primary_tag = (r["tags"] or "general").split(",")[0].strip()
                domains[primary_tag].append(dict(r))
        except Exception:
            pass

        # Find cross-domain word overlap
        connections = []
        domain_list = list(domains.items())
        for i, (domain_a, memories_a) in enumerate(domain_list):
            words_a = set()
            for m in memories_a:
                words_a.update(re.findall(r'\b\w{5,}\b', m["content"].lower()))

            for domain_b, memories_b in domain_list[i+1:]:
                words_b = set()
                for m in memories_b:
                    words_b.update(re.findall(r'\b\w{5,}\b', m["content"].lower()))

                overlap = words_a & words_b - {"about", "which", "their", "would", "should", "could", "there"}
                if len(overlap) >= 5:
                    connections.append({
                        "domain_a": domain_a,
                        "domain_b": domain_b,
                        "shared": list(overlap)[:8],
                    })

        report = f"# Cross-Domain Connections — {datetime.now().strftime('%Y-%m-%d')}\n\n"

        if connections:
            for c in connections[:10]:
                report += f"### {c['domain_a']} ↔ {c['domain_b']}\n"
                report += f"Shared concepts: {', '.join(c['shared'])}\n\n"
        else:
            report += "No significant cross-domain connections found yet. "
            report += "More diverse knowledge areas will produce connections.\n"

        self.store(f"cross_domain_{datetime.now().strftime('%Y%m%d')}",
                   report, "reference", "cross_domain,connections,auto", 0.6)

        return {"status": "ok", "domains": len(domains), "connections": len(connections)}


class QuestionGenerator(UserWorkflow):
    """Generate questions you should be asking based on knowledge gaps."""
    name = "question_generator"
    display_name = "Question Generator"
    description = "Generate the questions you should be asking but aren't — based on what you know and don't know"
    category = "knowledge"
    schedule_cron = "0 9 * * 1"
    wow_factor = "Identifies what you don't know by analyzing gaps in what you do know"

    def run(self) -> Dict:
        db = self._db()

        # Find topics with few memories (knowledge gaps)
        tag_counts = Counter()
        try:
            rows = db.execute("SELECT tags FROM memories WHERE active=1").fetchall()
            for r in rows:
                for tag in (r["tags"] or "").split(","):
                    tag = tag.strip()
                    if tag and tag != "auto":
                        tag_counts[tag] += 1
        except Exception:
            pass

        # Find thin topics (mentioned but not deeply explored)
        thin = [(tag, count) for tag, count in tag_counts.items() if 1 <= count <= 3]

        report = f"# Questions to Ask — {datetime.now().strftime('%Y-%m-%d')}\n\n"

        if thin:
            report += "## Topics You've Touched But Not Explored\n"
            report += "*These appear in your memories but lack depth:*\n\n"
            for tag, count in sorted(thin, key=lambda x: x[1])[:15]:
                report += f"- **{tag}** ({count} memories) — What else should you know about this?\n"

        report += "\n## Reflection Questions\n"
        report += "- What assumption am I making that I haven't tested?\n"
        report += "- What would I need to know to make my next big decision with confidence?\n"
        report += "- Who knows something I need to learn?\n"
        report += "- What's the question I keep avoiding?\n"

        self.store(f"questions_{datetime.now().strftime('%Y%m%d')}",
                   report, "reference", "questions,gaps,reflection,auto", 0.6)

        return {"status": "ok", "thin_topics": len(thin)}


class ArgumentBuilder(UserWorkflow):
    """Assemble evidence for/against positions from stored knowledge."""
    name = "argument_builder"
    display_name = "Argument Builder"
    description = "Build evidence-backed arguments from everything in your knowledge base"
    category = "knowledge"
    schedule_cron = "0 14 * * *"
    wow_factor = "Assembles arguments from months of accumulated evidence"

    def run(self) -> Dict:
        # Search for evidence-type memories
        evidence = self.search("evidence", limit=20)
        evidence += self.search("data", limit=10)
        evidence += self.search("result", limit=10)
        evidence += self.search("benchmark", limit=10)

        report = f"# Evidence Library — {datetime.now().strftime('%Y-%m-%d')}\n\n"
        report += f"**{len(evidence)} evidence items available**\n\n"

        # Group by topic
        by_topic = defaultdict(list)
        for e in evidence:
            topic = (e.get("tags", "") or "general").split(",")[0].strip()
            by_topic[topic].append(e)

        for topic, items in sorted(by_topic.items()):
            report += f"## {topic.title()}\n"
            for item in items[:5]:
                report += f"- {item['content'][:100]}\n"
            report += "\n"

        self.store(f"evidence_{datetime.now().strftime('%Y%m%d')}",
                   report, "reference", "evidence,arguments,auto", 0.5)

        return {"status": "ok", "evidence_items": len(evidence)}


class WisdomExtractor(UserWorkflow):
    """Distill principles from accumulated experience."""
    name = "wisdom_extractor"
    display_name = "Wisdom Extractor"
    description = "Distill your most proven principles — the wisdom that comes from months of tracked experience"
    category = "knowledge"
    schedule_cron = "0 21 * * 0"
    wow_factor = "Extracts wisdom from the full history of your skill episodes"

    def run(self) -> Dict:
        db = self._db()

        # Get highest-confidence principles across all domains
        wisdom = []
        try:
            rows = db.execute(
                "SELECT task_type, principle, confidence FROM skill_principles "
                "WHERE status='active' AND confidence >= 0.7 "
                "ORDER BY confidence DESC LIMIT 20"
            ).fetchall()
            wisdom = [dict(r) for r in rows]
        except Exception:
            pass

        report = f"# Accumulated Wisdom — {datetime.now().strftime('%Y-%m-%d')}\n\n"
        report += "*Principles proven through repeated practice and validated by outcomes:*\n\n"

        if wisdom:
            for w in wisdom:
                report += f"- ({w['confidence']:.0%}) **{w['task_type']}**: {w['principle']}\n"
        else:
            report += "Not enough validated principles yet. Keep working and recording episodes.\n"

        self.store("wisdom", report, "reference", "wisdom,principles,proven,auto", 0.8)

        return {"status": "ok", "wisdom_items": len(wisdom)}


class PatternMatcher(UserWorkflow):
    """Find recurring patterns across different projects and contexts."""
    name = "pattern_matcher"
    display_name = "Pattern Matcher"
    description = "Spot recurring patterns in your work — the things that keep happening that you don't notice"
    category = "knowledge"
    schedule_cron = "0 20 * * 0"
    wow_factor = "Detects patterns across months of project data that are invisible day-to-day"

    def run(self) -> Dict:
        db = self._db()

        # Find recurring words in task descriptions
        word_freq = Counter()
        try:
            rows = db.execute(
                "SELECT task_description FROM skill_episodes "
                "WHERE created_at >= datetime('now', '-90 days')"
            ).fetchall()
            for r in rows:
                words = re.findall(r'\b\w{4,}\b', (r["task_description"] or "").lower())
                word_freq.update(words)
        except Exception:
            pass

        # Find recurring themes in findings/issues
        issue_patterns = Counter()
        issues = self.search("error", limit=30)
        issues += self.search("bug", limit=20)
        issues += self.search("issue", limit=20)
        for issue in issues:
            words = re.findall(r'\b\w{4,}\b', issue["content"].lower())
            issue_patterns.update(words)

        report = f"# Pattern Analysis — {datetime.now().strftime('%Y-%m-%d')}\n\n"

        common_words = {"with", "that", "this", "from", "have", "been", "what", "your", "some"}

        if word_freq:
            report += "## Most Common Task Themes\n"
            for word, count in word_freq.most_common(15):
                if word not in common_words:
                    report += f"- **{word}** — appears in {count} tasks\n"

        if issue_patterns:
            report += "\n## Recurring Issue Patterns\n"
            for word, count in issue_patterns.most_common(10):
                if word not in common_words and count >= 3:
                    report += f"- **{word}** — appears in {count} issues\n"

        self.store(f"patterns_{datetime.now().strftime('%Y%m%d')}",
                   report, "reference", "patterns,analysis,auto", 0.5)

        return {"status": "ok", "task_themes": len(word_freq),
                "issue_patterns": len(issue_patterns)}


class ExpertiseMapper(UserWorkflow):
    """Visualize what you know and how deep."""
    name = "expertise_mapper"
    display_name = "Expertise Mapper"
    description = "Map your knowledge landscape — see exactly what you know and where the edges are"
    category = "knowledge"
    schedule_cron = "0 21 * * 0"
    wow_factor = "Objective expertise map from accumulated skill episodes and memory depth"

    def run(self) -> Dict:
        db = self._db()

        # Map expertise by domain
        domains = {}
        try:
            rows = db.execute(
                "SELECT task_type, COUNT(*) as episodes, AVG(outcome_quality) as avg, "
                "MAX(created_at) as last_practiced "
                "FROM skill_episodes GROUP BY task_type ORDER BY avg DESC"
            ).fetchall()
            for r in rows:
                domains[r["task_type"]] = {
                    "episodes": r["episodes"],
                    "proficiency": round(r["avg"], 2),
                    "last_practiced": r["last_practiced"][:10] if r["last_practiced"] else "never",
                }
        except Exception:
            pass

        # Memory depth per tag
        tag_depth = Counter()
        try:
            rows = db.execute("SELECT tags FROM memories WHERE active=1").fetchall()
            for r in rows:
                for tag in (r["tags"] or "").split(","):
                    if tag.strip() and tag.strip() != "auto":
                        tag_depth[tag.strip()] += 1
        except Exception:
            pass

        report = f"# Expertise Map — {datetime.now().strftime('%Y-%m-%d')}\n\n"

        if domains:
            report += "## Skill Proficiency\n"
            for domain, data in sorted(domains.items(), key=lambda x: x[1]["proficiency"], reverse=True):
                bar = "█" * int(data["proficiency"] * 10)
                report += f"- {bar} {data['proficiency']:.0%} **{domain}** ({data['episodes']} episodes, last: {data['last_practiced']})\n"

        if tag_depth:
            report += "\n## Knowledge Depth by Topic\n"
            for tag, count in tag_depth.most_common(20):
                bar = "█" * min(count, 20)
                report += f"- {bar} **{tag}** ({count} memories)\n"

        self.store("expertise_map", report, "reference",
                   "expertise,map,knowledge,auto", 0.6)

        return {"status": "ok", "skill_domains": len(domains), "knowledge_topics": len(tag_depth)}


class TeachingMaterialGenerator(UserWorkflow):
    """Convert your expertise into teachable content."""
    name = "teaching_material"
    display_name = "Teaching Material Generator"
    description = "Convert your proven expertise into structured teaching materials and tutorials"
    category = "knowledge"
    schedule_cron = "0 10 * * 6"
    wow_factor = "Creates teaching content from your highest-confidence principles"

    def run(self) -> Dict:
        db = self._db()

        # Find expert-level skills
        expert_skills = []
        try:
            rows = db.execute(
                "SELECT task_type, AVG(outcome_quality) as avg, COUNT(*) as episodes "
                "FROM skill_episodes GROUP BY task_type HAVING avg >= 0.75 AND episodes >= 10 "
                "ORDER BY avg DESC LIMIT 5"
            ).fetchall()
            expert_skills = [dict(r) for r in rows]
        except Exception:
            pass

        for skill in expert_skills:
            # Get principles for this skill
            principles = []
            try:
                rows = db.execute(
                    "SELECT principle, confidence FROM skill_principles "
                    "WHERE task_type=? AND status='active' ORDER BY confidence DESC LIMIT 10",
                    (skill["task_type"],)
                ).fetchall()
                principles = [dict(r) for r in rows]
            except Exception:
                pass

            lesson = f"# Teaching: {skill['task_type']}\n"
            lesson += f"*Based on {skill['episodes']} episodes at {skill['avg']:.0%} proficiency*\n\n"

            if principles:
                lesson += "## Key Principles\n"
                for p in principles:
                    lesson += f"1. **{p['principle']}** (proven {p['confidence']:.0%} reliable)\n"

            lesson += "\n## Lesson Structure\n"
            lesson += "1. Why this matters\n"
            lesson += "2. The core principles (above)\n"
            lesson += "3. Worked example\n"
            lesson += "4. Common mistakes to avoid\n"
            lesson += "5. Practice exercise\n"

            self.store(f"teaching_{skill['task_type']}", lesson,
                       "reference", f"teaching,{skill['task_type']},auto", 0.5)

        return {"status": "ok", "teachable_skills": len(expert_skills)}


class MentalModelBuilder(UserWorkflow):
    """Identify and document your mental models."""
    name = "mental_models"
    display_name = "Mental Model Builder"
    description = "Document the mental models you actually use — not textbook models, YOUR models"
    category = "knowledge"
    schedule_cron = "0 21 * * 0"
    wow_factor = "Extracts YOUR mental models from how you actually approach problems"

    def run(self) -> Dict:
        db = self._db()

        # Analyze approach patterns from skill episodes
        approaches = Counter()
        try:
            rows = db.execute(
                "SELECT approach_taken FROM skill_episodes WHERE outcome_quality >= 0.7 "
                "ORDER BY created_at DESC LIMIT 100"
            ).fetchall()
            for r in rows:
                approach = r["approach_taken"] or ""
                # Extract key phrases
                phrases = re.findall(r'\b(?:first|then|always|never|before|after|check|verify|start with)\s+\w+(?:\s+\w+)?', approach.lower())
                approaches.update(phrases)
        except Exception:
            pass

        report = f"# Mental Models — {datetime.now().strftime('%Y-%m-%d')}\n\n"
        report += "*These are the patterns in how you approach problems successfully:*\n\n"

        if approaches:
            for phrase, count in approaches.most_common(15):
                if count >= 2:
                    report += f"- **\"{phrase}\"** — used in {count} successful tasks\n"
        else:
            report += "Not enough episode data yet to extract mental models.\n"

        self.store("mental_models", report, "reference",
                   "mental_models,thinking,patterns,auto", 0.6)

        return {"status": "ok", "patterns": len(approaches)}


# =========================================================================
# CATEGORY 4: PROACTIVE INTELLIGENCE (10)
# =========================================================================

class OpportunityDetector(UserWorkflow):
    """Spot opportunities based on skills + market signals."""
    name = "opportunity_detector"
    display_name = "Opportunity Detector"
    description = "Spot opportunities that match your skills and interests — before you think to look"
    category = "proactive"
    schedule_cron = "0 9 * * 1"
    wow_factor = "Matches your demonstrated skills against opportunities — requires deep skill knowledge"

    def run(self) -> Dict:
        db = self._db()

        # What are you good at?
        strengths = []
        try:
            rows = db.execute(
                "SELECT task_type, AVG(outcome_quality) as avg "
                "FROM skill_episodes GROUP BY task_type HAVING avg >= 0.7 "
                "ORDER BY avg DESC LIMIT 10"
            ).fetchall()
            strengths = [r["task_type"] for r in rows]
        except Exception:
            pass

        # What opportunities exist in memory?
        opportunities = self.search("opportunity", limit=10)
        opportunities += self.search("job", limit=5)
        opportunities += self.search("freelance", limit=5)

        report = f"# Opportunity Scan — {datetime.now().strftime('%Y-%m-%d')}\n\n"
        report += f"**Your strengths:** {', '.join(strengths[:5]) if strengths else 'Build more skill data'}\n\n"

        if opportunities:
            report += "## Stored Opportunities\n"
            for o in opportunities:
                report += f"- {o['content'][:100]}\n"

        report += "\n## Where to Look\n"
        if strengths:
            for s in strengths[:5]:
                report += f"- Search for {s} freelance/contract opportunities\n"

        self.store(f"opportunities_{datetime.now().strftime('%Y%m%d')}",
                   report, "reference", "opportunities,proactive,auto", 0.5)

        return {"status": "ok", "strengths": len(strengths),
                "stored_opportunities": len(opportunities)}


class RiskEarlyWarning(UserWorkflow):
    """Identify risks before they materialize."""
    name = "risk_early_warning"
    display_name = "Risk Early Warning"
    description = "Detect emerging risks based on patterns — the problems you can still prevent"
    category = "proactive"
    schedule_cron = "0 9 * * 1"
    wow_factor = "Pattern-matches risk indicators across months of project data"

    def run(self) -> Dict:
        # Check for risk indicators
        risk_keywords = ["delay", "blocked", "stuck", "overdue", "risk", "concern",
                        "problem", "issue", "failing", "behind"]

        risk_indicators = []
        for kw in risk_keywords:
            results = self.search(kw, limit=5)
            for r in results:
                try:
                    age = (datetime.now() - datetime.strptime(r.get("created", "")[:10], "%Y-%m-%d")).days
                    if age <= 14:  # Recent
                        risk_indicators.append({**r, "keyword": kw, "age": age})
                except ValueError:
                    pass

        report = f"# Risk Early Warning — {datetime.now().strftime('%Y-%m-%d')}\n\n"

        if risk_indicators:
            report += f"**{len(risk_indicators)} risk indicators detected:**\n\n"
            for r in risk_indicators[:10]:
                report += f"- ⚠️ [{r['keyword']}] {r['name']}: {r['content'][:80]}\n"
        else:
            report += "No risk indicators detected. Keep monitoring.\n"

        if risk_indicators:
            self.store(f"risk_warning_{datetime.now().strftime('%Y%m%d')}",
                       report, "reference", "risk,warning,proactive,auto", 0.7)

        return {"status": "ok", "risk_indicators": len(risk_indicators)}


class DeadlinePredictor(UserWorkflow):
    """Estimate realistic deadlines from past project data."""
    name = "deadline_predictor"
    display_name = "Deadline Predictor"
    description = "Predict realistic deadlines based on how long similar tasks actually took you"
    category = "proactive"
    schedule_cron = "0 9 * * 1"
    wow_factor = "Estimates from YOUR actual historical task durations, not generic benchmarks"

    def run(self) -> Dict:
        db = self._db()

        # Historical task durations
        duration_data = {}
        try:
            rows = db.execute(
                "SELECT task_type, AVG(duration_seconds) as avg_duration, "
                "COUNT(*) as episodes "
                "FROM skill_episodes WHERE duration_seconds > 0 "
                "GROUP BY task_type ORDER BY avg_duration DESC"
            ).fetchall()
            for r in rows:
                if r["avg_duration"] and r["avg_duration"] > 0:
                    duration_data[r["task_type"]] = {
                        "avg_hours": round(r["avg_duration"] / 3600, 1),
                        "episodes": r["episodes"],
                    }
        except Exception:
            pass

        report = f"# Deadline Intelligence — {datetime.now().strftime('%Y-%m-%d')}\n\n"

        if duration_data:
            report += "## Your Actual Task Durations\n"
            report += "*Use these for realistic estimates, not optimistic guesses:*\n\n"
            for task, data in sorted(duration_data.items(), key=lambda x: x[1]["avg_hours"], reverse=True):
                report += f"- **{task}**: ~{data['avg_hours']} hours avg ({data['episodes']} episodes)\n"

            report += "\n## Planning Factor\n"
            report += "Multiply estimates by 1.5x for unknown complexity.\n"
            report += "Your data is based on tasks you've done before — new tasks take longer.\n"
        else:
            report += "No duration data yet. Tasks need duration_seconds recorded in episodes.\n"

        self.store(f"deadline_intel_{datetime.now().strftime('%Y%m%d')}",
                   report, "reference", "deadlines,prediction,auto", 0.5)

        return {"status": "ok", "task_types_with_timing": len(duration_data)}


class BurnoutDetector(UserWorkflow):
    """Identify overwork patterns before they become problems."""
    name = "burnout_detector"
    display_name = "Burnout Detector"
    description = "Spot overwork patterns before they become burnout — tracks pace, quality trends, and variety"
    category = "proactive"
    schedule_cron = "0 21 * * 0"
    wow_factor = "Tracks your pace, quality degradation, and work patterns across weeks"

    def run(self) -> Dict:
        db = self._db()

        # Task volume by week
        weekly_volume = []
        try:
            rows = db.execute(
                "SELECT strftime('%Y-W%W', created_at) as week, COUNT(*) as tasks, "
                "AVG(outcome_quality) as avg "
                "FROM skill_episodes WHERE created_at >= datetime('now', '-28 days') "
                "GROUP BY week ORDER BY week"
            ).fetchall()
            weekly_volume = [dict(r) for r in rows]
        except Exception:
            pass

        # Memory creation rate (proxy for cognitive load)
        memory_rate = 0
        try:
            row = db.execute(
                "SELECT COUNT(*) as c FROM memories WHERE created >= datetime('now', '-7 days')"
            ).fetchone()
            memory_rate = row["c"] if row else 0
        except Exception:
            pass

        report = f"# Wellbeing Check — {datetime.now().strftime('%Y-%m-%d')}\n\n"

        warning_signs = []

        if weekly_volume:
            volumes = [w["tasks"] for w in weekly_volume]
            if len(volumes) >= 2 and volumes[-1] > volumes[-2] * 1.5:
                warning_signs.append(f"Task volume jumped {volumes[-1]} vs {volumes[-2]} last week")

            qualities = [w["avg"] for w in weekly_volume]
            if len(qualities) >= 2 and qualities[-1] < qualities[-2] * 0.85:
                warning_signs.append(f"Quality dropped from {qualities[-2]:.0%} to {qualities[-1]:.0%}")

        if memory_rate > 50:
            warning_signs.append(f"High cognitive load: {memory_rate} memories created this week")

        if warning_signs:
            report += "## ⚠️ Warning Signs\n"
            for w in warning_signs:
                report += f"- {w}\n"
            report += "\n*Consider: Are you pushing too hard? When did you last take a real break?*\n"
        else:
            report += "## ✅ Pace Looks Healthy\n"
            report += "No burnout indicators detected this week.\n"

        if weekly_volume:
            report += "\n## Weekly Pace\n"
            for w in weekly_volume:
                report += f"- {w['week']}: {w['tasks']} tasks, {w['avg']:.0%} quality\n"

        self.store(f"wellbeing_{datetime.now().strftime('%Y%m%d')}",
                   report, "reference", "wellbeing,burnout,proactive,auto",
                   0.8 if warning_signs else 0.4)

        return {"status": "ok", "warning_signs": len(warning_signs)}


class RelationshipDecayAlert(UserWorkflow):
    """Flag important relationships going cold."""
    name = "relationship_decay"
    display_name = "Relationship Decay Alert"
    description = "Never let an important relationship go cold — flags contacts you haven't engaged with"
    category = "proactive"
    schedule_cron = "0 9 * * 1"
    wow_factor = "Tracks relationship frequency across all interactions over months"

    def run(self) -> Dict:
        contacts = self.search("contact", limit=30)
        contacts += self.search("person", limit=20)

        decaying = []
        for c in contacts:
            last = c.get("updated", c.get("created", ""))[:10]
            try:
                days = (datetime.now() - datetime.strptime(last, "%Y-%m-%d")).days
                if days >= 30:
                    decaying.append({"name": c["name"], "days": days})
            except ValueError:
                pass

        decaying.sort(key=lambda x: x["days"], reverse=True)

        if decaying:
            report = f"# Relationship Alerts — {datetime.now().strftime('%Y-%m-%d')}\n\n"
            for d in decaying[:10]:
                urgency = "🔴" if d["days"] > 90 else "🟡" if d["days"] > 60 else "🟢"
                report += f"- {urgency} **{d['name']}** — {d['days']} days since last interaction\n"

            self.store(f"relationship_alerts_{datetime.now().strftime('%Y%m%d')}",
                       report, "reference", "relationships,decay,proactive,auto", 0.6)

        return {"status": "ok", "decaying": len(decaying)}


class KnowledgeDecayAlert(UserWorkflow):
    """Flag expertise areas you haven't practiced."""
    name = "knowledge_decay"
    display_name = "Knowledge Decay Alert"
    description = "Catch skills that are rusting — flags expertise you haven't practiced recently"
    category = "proactive"
    schedule_cron = "0 9 * * 1"
    wow_factor = "Tracks skill practice frequency — catches expertise decay before it matters"

    def run(self) -> Dict:
        db = self._db()

        decaying_skills = []
        try:
            rows = db.execute(
                "SELECT task_type, MAX(created_at) as last_practiced, "
                "AVG(outcome_quality) as avg, COUNT(*) as episodes "
                "FROM skill_episodes GROUP BY task_type HAVING episodes >= 5"
            ).fetchall()
            for r in rows:
                if r["last_practiced"]:
                    try:
                        days = (datetime.now() - datetime.strptime(
                            r["last_practiced"][:10], "%Y-%m-%d")).days
                        if days >= 30 and r["avg"] >= 0.6:
                            decaying_skills.append({
                                "skill": r["task_type"],
                                "days_idle": days,
                                "proficiency": round(r["avg"], 2),
                            })
                    except ValueError:
                        pass
        except Exception:
            pass

        if decaying_skills:
            report = f"# Skill Decay Alert — {datetime.now().strftime('%Y-%m-%d')}\n\n"
            for s in sorted(decaying_skills, key=lambda x: x["days_idle"], reverse=True):
                report += (f"- ⚠️ **{s['skill']}** — {s['proficiency']:.0%} proficient but "
                          f"{s['days_idle']} days since last practice\n")

            self.store(f"skill_decay_{datetime.now().strftime('%Y%m%d')}",
                       report, "reference", "skill_decay,proactive,auto", 0.6)

        return {"status": "ok", "decaying_skills": len(decaying_skills)}


class GoalDriftDetector(UserWorkflow):
    """Identify when daily actions diverge from stated goals."""
    name = "goal_drift"
    display_name = "Goal Drift Detector"
    description = "Are your daily actions aligned with your goals? This finds the drift you don't notice"
    category = "proactive"
    schedule_cron = "0 18 * * 5"
    wow_factor = "Compares daily task patterns against stated goals across weeks"

    def run(self) -> Dict:
        # Load goals
        goals = self.search("goal", limit=10)

        # Load recent task types
        db = self._db()
        recent_tasks = Counter()
        try:
            rows = db.execute(
                "SELECT task_type FROM skill_episodes "
                "WHERE created_at >= datetime('now', '-7 days')"
            ).fetchall()
            for r in rows:
                recent_tasks[r["task_type"]] += 1
        except Exception:
            pass

        report = f"# Goal Alignment Check — {datetime.now().strftime('%Y-%m-%d')}\n\n"

        if goals:
            report += "## Stated Goals\n"
            for g in goals[:5]:
                report += f"- {g['content'][:80]}\n"

        if recent_tasks:
            report += "\n## Where Your Time Actually Went\n"
            for task, count in recent_tasks.most_common(10):
                report += f"- {task}: {count} tasks\n"

        report += "\n## Alignment Check\n"
        report += "- Are the top task types serving your goals?\n"
        report += "- What goal-related work is missing from the task list?\n"
        report += "- What tasks are consuming time without advancing any goal?\n"

        self.store(f"goal_drift_{datetime.now().strftime('%Y_W%W')}",
                   report, "reference", "goals,alignment,drift,auto", 0.6)

        return {"status": "ok", "goals": len(goals), "task_types": len(recent_tasks)}


class DependencyAlert(UserWorkflow):
    """Flag over-dependence on tools, people, or processes."""
    name = "dependency_alert"
    display_name = "Dependency Alert"
    description = "Detect when you're over-reliant on a single tool, person, or process"
    category = "proactive"
    schedule_cron = "0 21 * * 0"
    wow_factor = "Identifies single-points-of-failure in your workflow from usage patterns"

    def run(self) -> Dict:
        db = self._db()

        # Find dominant tools/approaches
        tool_usage = Counter()
        try:
            rows = db.execute(
                "SELECT tools_used FROM skill_episodes "
                "WHERE created_at >= datetime('now', '-30 days')"
            ).fetchall()
            for r in rows:
                try:
                    tools = json.loads(r["tools_used"]) if r["tools_used"] else []
                    tool_usage.update(tools)
                except (json.JSONDecodeError, TypeError):
                    pass
        except Exception:
            pass

        report = f"# Dependency Analysis — {datetime.now().strftime('%Y-%m-%d')}\n\n"

        if tool_usage:
            total = sum(tool_usage.values())
            report += "## Tool Usage Distribution\n"
            for tool, count in tool_usage.most_common(10):
                pct = (count / total) * 100
                flag = " ⚠️ CONCENTRATION RISK" if pct > 50 else ""
                report += f"- **{tool}**: {count} uses ({pct:.0f}%){flag}\n"

        self.store(f"dependencies_{datetime.now().strftime('%Y%m%d')}",
                   report, "reference", "dependencies,risk,proactive,auto", 0.5)

        return {"status": "ok", "tools_tracked": len(tool_usage)}


class FutureSelfLetter(UserWorkflow):
    """Generate insights about where you're heading based on trajectory."""
    name = "future_self"
    display_name = "Future Self Letter"
    description = "A letter from your data to your future self — where are you heading based on current trajectory?"
    category = "proactive"
    schedule_cron = "0 21 * * 0"
    wow_factor = "Projects your trajectory from months of accumulated data — truly personal"

    def run(self) -> Dict:
        db = self._db()

        # Gather trajectory data
        total_memories = 0
        total_episodes = 0
        top_skills = []
        try:
            row = db.execute("SELECT COUNT(*) as c FROM memories WHERE active=1").fetchone()
            total_memories = row["c"] if row else 0

            row = db.execute("SELECT COUNT(*) as c FROM skill_episodes").fetchone()
            total_episodes = row["c"] if row else 0

            rows = db.execute(
                "SELECT task_type, AVG(outcome_quality) as avg "
                "FROM skill_episodes GROUP BY task_type ORDER BY avg DESC LIMIT 5"
            ).fetchall()
            top_skills = [f"{r['task_type']} ({r['avg']:.0%})" for r in rows]
        except Exception:
            pass

        letter = f"# Letter to Future Self\n"
        letter += f"**Written:** {datetime.now().strftime('%Y-%m-%d')}\n\n"
        letter += f"Hey future me,\n\n"
        letter += f"Right now you have {total_memories} memories and {total_episodes} skill episodes. "
        letter += f"Your strongest areas are: {', '.join(top_skills) if top_skills else 'still building'}.\n\n"
        letter += f"The questions on your mind right now:\n"

        # Pull recent questions/concerns
        concerns = self.search("concern", limit=3)
        concerns += self.search("worry", limit=3)
        concerns += self.search("question", limit=3)

        if concerns:
            for c in concerns[:5]:
                letter += f"- {c['content'][:80]}\n"
        else:
            letter += "- (none captured — store concerns with tag 'concern')\n"

        letter += f"\nRemember: you're building something real. Keep shipping.\n"
        letter += f"\n— Past you ({datetime.now().strftime('%B %Y')})\n"

        self.store(f"future_letter_{datetime.now().strftime('%Y%m%d')}",
                   letter, "reference", "future_self,reflection,proactive,auto", 0.7)

        return {"status": "ok", "memories": total_memories, "episodes": total_episodes}


# =========================================================================
# REGISTRY
# =========================================================================

USER_WORKFLOW_REGISTRY: Dict[str, type] = {
    # Personal Intelligence
    "decision_journal": DecisionJournal,
    "contradiction_detector": ContradictionDetector,
    "idea_incubator": IdeaIncubator,
    "knowledge_wiki": PersonalKnowledgeWiki,
    "life_dashboard": LifeDashboard,
    "learning_path": LearningPathGenerator,
    "commitment_tracker": CommitmentTracker,
    "context_switcher": ContextSwitcher,
    "weekly_wins": WeeklyWinsCollector,
    # Professional
    "resume_updater": ResumeAutoUpdater,
    "meeting_prep": MeetingPrepAutomator,
    "one_on_one_prep": OneOnOnePrepRunner,
    "client_intelligence": ClientIntelligenceBrief,
    "skill_gap_analyzer": SkillGapAnalyzer,
    "portfolio_builder": PortfolioBuilder,
    "career_trajectory": CareerTrajectoryAnalyzer,
    "professional_dev": ProfessionalDevPlanner,
    "salary_intelligence": SalaryIntelligence,
    # Knowledge
    "insight_crystallizer": InsightCrystallizer,
    "cross_domain": CrossDomainConnector,
    "question_generator": QuestionGenerator,
    "argument_builder": ArgumentBuilder,
    "wisdom_extractor": WisdomExtractor,
    "pattern_matcher": PatternMatcher,
    "expertise_mapper": ExpertiseMapper,
    "teaching_material": TeachingMaterialGenerator,
    "mental_models": MentalModelBuilder,
    # Proactive
    "opportunity_detector": OpportunityDetector,
    "risk_early_warning": RiskEarlyWarning,
    "deadline_predictor": DeadlinePredictor,
    "burnout_detector": BurnoutDetector,
    "relationship_decay": RelationshipDecayAlert,
    "knowledge_decay": KnowledgeDecayAlert,
    "goal_drift": GoalDriftDetector,
    "dependency_alert": DependencyAlert,
    "future_self": FutureSelfLetter,
}


def seed_user_workflows(db_path: str) -> int:
    conn = sqlite3.connect(db_path, check_same_thread=False)
    count = 0
    for name, cls in USER_WORKFLOW_REGISTRY.items():
        try:
            conn.execute("""
                INSERT OR REPLACE INTO workflows
                (name, display_name, category, description, cron_schedule, enabled, source)
                VALUES (?, ?, ?, ?, ?, 0, 'builtin_user')
            """, (cls.name, cls.display_name, cls.category, cls.description, cls.schedule_cron))
            count += 1
        except Exception as e:
            log.error("Failed to seed %s: %s", name, e)
    conn.commit()
    conn.close()
    return count


# =========================================================================
# MISSING 4 — ONE PER CATEGORY
# =========================================================================

class EnergyPatternAnalyzer(UserWorkflow):
    """Track when you do your best work based on task quality by time of day."""
    name = "energy_patterns"
    display_name = "Energy Pattern Analyzer"
    description = "Discover when you do your best work — maps task quality to time of day and day of week"
    category = "personal_intelligence"
    schedule_cron = "0 21 * * 0"
    wow_factor = "Maps YOUR personal peak performance times from actual task data"

    def run(self) -> Dict:
        db = self._db()
        by_hour = defaultdict(list)
        by_day = defaultdict(list)
        try:
            rows = db.execute(
                "SELECT strftime('%H', created_at) as hour, strftime('%w', created_at) as dow, "
                "outcome_quality FROM skill_episodes WHERE outcome_quality > 0"
            ).fetchall()
            for r in rows:
                by_hour[int(r["hour"])].append(r["outcome_quality"])
                by_day[int(r["dow"])].append(r["outcome_quality"])
        except Exception:
            pass

        day_names = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
        report = f"# Energy Patterns — {datetime.now().strftime('%Y-%m-%d')}\n\n"

        if by_hour:
            report += "## Best Hours (by average task quality)\n"
            hour_avgs = {h: sum(v)/len(v) for h, v in by_hour.items() if len(v) >= 2}
            for h in sorted(hour_avgs, key=hour_avgs.get, reverse=True)[:5]:
                report += f"- {h:02d}:00 — {hour_avgs[h]:.0%} average ({len(by_hour[h])} tasks)\n"

        if by_day:
            report += "\n## Best Days\n"
            day_avgs = {d: sum(v)/len(v) for d, v in by_day.items() if len(v) >= 2}
            for d in sorted(day_avgs, key=day_avgs.get, reverse=True):
                report += f"- {day_names[d]}: {day_avgs[d]:.0%} average ({len(by_day[d])} tasks)\n"

        self.store(f"energy_{datetime.now().strftime('%Y%m%d')}",
                   report, "reference", "energy,patterns,productivity,auto", 0.5)
        return {"status": "ok", "hours_tracked": len(by_hour), "days_tracked": len(by_day)}


class NetworkingIntelligence(UserWorkflow):
    """Smart reconnection suggestions with context for each relationship."""
    name = "networking_intelligence"
    display_name = "Networking Intelligence"
    description = "Smart reconnection suggestions — who to reach out to and exactly what to mention"
    category = "professional"
    schedule_cron = "0 9 * * 1"
    wow_factor = "Suggests reconnections WITH context from past interactions — personal, not generic"

    def run(self) -> Dict:
        contacts = self.search("contact", limit=30)
        contacts += self.search("networking", limit=20)

        reconnections = []
        seen = set()
        for c in contacts:
            if c["name"] in seen:
                continue
            seen.add(c["name"])
            last = c.get("updated", c.get("created", ""))[:10]
            try:
                days = (datetime.now() - datetime.strptime(last, "%Y-%m-%d")).days
                if days >= 30:
                    reconnections.append({
                        "name": c["name"], "days": days,
                        "context": c["content"][:100],
                    })
            except ValueError:
                pass

        reconnections.sort(key=lambda x: x["days"], reverse=True)

        report = f"# Networking Intelligence — {datetime.now().strftime('%Y-%m-%d')}\n\n"
        if reconnections:
            for r in reconnections[:10]:
                report += f"### {r['name']} ({r['days']} days)\n"
                report += f"Context: {r['context']}\n"
                report += f"*Reach out and mention something from your last interaction.*\n\n"

        self.store(f"networking_intel_{datetime.now().strftime('%Y%m%d')}",
                   report, "reference", "networking,intelligence,proactive,auto", 0.6)
        return {"status": "ok", "reconnections": len(reconnections)}


class ResearchSynthesizer(UserWorkflow):
    """Combine multiple research threads into coherent narrative."""
    name = "research_synthesizer"
    display_name = "Research Synthesizer"
    description = "Weave separate research threads into a coherent picture — find the story in your data"
    category = "knowledge"
    schedule_cron = "0 10 * * 6"
    wow_factor = "Synthesizes research conducted across multiple sessions into unified insights"

    def run(self) -> Dict:
        research = self.search("research", limit=30)
        research += self.search("finding", limit=20)
        research += self.search("paper", limit=10)

        # Group by topic
        topics = defaultdict(list)
        for r in research:
            primary = (r.get("tags", "") or "general").split(",")[0].strip()
            topics[primary].append(r)

        report = f"# Research Synthesis — {datetime.now().strftime('%Y-%m-%d')}\n\n"
        report += f"**{len(research)} research items across {len(topics)} topics**\n\n"

        for topic, items in sorted(topics.items(), key=lambda x: len(x[1]), reverse=True)[:10]:
            report += f"## {topic.title()} ({len(items)} items)\n"
            for item in items[:5]:
                report += f"- {item['content'][:100]}\n"
            report += "\n"

        self.store(f"synthesis_{datetime.now().strftime('%Y%m%d')}",
                   report, "reference", "research,synthesis,auto", 0.6)
        return {"status": "ok", "items": len(research), "topics": len(topics)}


class DecisionFatigueMonitor(UserWorkflow):
    """Track decision quality degradation over time."""
    name = "decision_fatigue"
    display_name = "Decision Fatigue Monitor"
    description = "Detect when your decision quality drops — the sign you need to stop and recharge"
    category = "proactive"
    schedule_cron = "0 18 * * 5"
    wow_factor = "Measures actual decision quality degradation from tracked outcomes"

    def run(self) -> Dict:
        db = self._db()

        # Decisions with outcomes
        decisions_with_outcomes = []
        try:
            rows = db.execute(
                "SELECT name, content, created FROM memories "
                "WHERE tags LIKE '%decision%' AND tags LIKE '%outcome%' AND active=1 "
                "ORDER BY created DESC LIMIT 30"
            ).fetchall()
            decisions_with_outcomes = [dict(r) for r in rows]
        except Exception:
            pass

        # Task quality trend (proxy for decision quality)
        quality_trend = []
        try:
            rows = db.execute(
                "SELECT date(created_at) as day, AVG(outcome_quality) as avg, COUNT(*) as tasks "
                "FROM skill_episodes WHERE created_at >= datetime('now', '-14 days') "
                "GROUP BY day ORDER BY day"
            ).fetchall()
            quality_trend = [dict(r) for r in rows]
        except Exception:
            pass

        report = f"# Decision Quality — {datetime.now().strftime('%Y-%m-%d')}\n\n"

        if quality_trend:
            report += "## Quality Trend (last 14 days)\n"
            declining = False
            for i, day in enumerate(quality_trend):
                marker = "📈" if i > 0 and day["avg"] > quality_trend[i-1]["avg"] else "📉" if i > 0 and day["avg"] < quality_trend[i-1]["avg"] else "➡️"
                report += f"- {marker} {day['day']}: {day['avg']:.0%} ({day['tasks']} tasks)\n"
                if i >= 2 and day["avg"] < quality_trend[i-1]["avg"] < quality_trend[i-2]["avg"]:
                    declining = True

            if declining:
                report += "\n⚠️ **Three consecutive days of declining quality detected.**\n"
                report += "Consider: take a break, sleep on decisions, delegate low-stakes choices.\n"

        self.store(f"decision_quality_{datetime.now().strftime('%Y%m%d')}",
                   report, "reference", "decisions,fatigue,quality,auto", 0.6)
        return {"status": "ok", "tracked_outcomes": len(decisions_with_outcomes),
                "trend_days": len(quality_trend)}


# Update registry with the 4 additions
USER_WORKFLOW_REGISTRY["energy_patterns"] = EnergyPatternAnalyzer
USER_WORKFLOW_REGISTRY["networking_intelligence"] = NetworkingIntelligence
USER_WORKFLOW_REGISTRY["research_synthesizer"] = ResearchSynthesizer
USER_WORKFLOW_REGISTRY["decision_fatigue"] = DecisionFatigueMonitor
