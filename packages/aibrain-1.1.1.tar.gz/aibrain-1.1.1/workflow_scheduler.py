#!/usr/bin/env python3
"""
workflow_scheduler.py — Workflow Dependency Map, OS Scheduler Sync, Onboarding

The architecture:
- Set 2 (skill workflows) runs silently, making the agent smarter
- Set 3 (user workflows) uses that intelligence to deliver wow moments
- When a user enables a Set 3 workflow, its Set 2 dependencies auto-enable
- `aibrain workflows sync` creates OS-native scheduled tasks

Usage:
    aibrain workflows list                    # show all workflows and status
    aibrain workflows enable <name>           # enable a workflow (+ dependencies)
    aibrain workflows disable <name>          # disable a workflow
    aibrain workflows enable --recommended    # enable starter set
    aibrain workflows sync                    # sync enabled workflows to OS scheduler
    aibrain workflows sync --dry-run          # show what would change
    aibrain workflows run <name>              # run a workflow immediately
"""

import json
import logging
import os
import platform
import re
import sqlite3
import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

log = logging.getLogger("aibrain.scheduler")

# ---------------------------------------------------------------------------
# Dependency Map: Set 3 (user) → Set 2 (skill) workflows
# ---------------------------------------------------------------------------

WORKFLOW_DEPENDENCIES: Dict[str, List[str]] = {
    # Personal Intelligence (Set 3) → Agent Self-Improvement (Set 2)
    "decision_journal":        ["correction_learner", "memory_hygiene"],
    "contradiction_detector":  ["correction_learner", "memory_hygiene", "user_model"],
    "idea_incubator":          ["memory_hygiene", "knowledge_gap_detector"],
    "knowledge_wiki":          ["memory_hygiene", "self_model_refresh"],
    "life_dashboard":          ["self_model_refresh", "task_retrospective", "session_prep"],
    "learning_path":           ["skill_sharpener", "task_retrospective"],
    "commitment_tracker":      ["memory_hygiene", "session_prep"],
    "context_switcher":        ["session_prep", "task_briefing"],
    "weekly_wins":             ["task_retrospective"],
    "energy_patterns":         ["task_retrospective", "skill_sharpener"],

    # Professional (Set 3) → Agent Self-Improvement (Set 2)
    "resume_updater":          ["task_retrospective", "skill_sharpener"],
    "meeting_prep":            ["session_prep", "user_model"],
    "one_on_one_prep":         ["user_model", "session_prep"],
    "client_intelligence":     ["user_model", "memory_hygiene"],
    "skill_gap_analyzer":      ["skill_sharpener", "task_retrospective"],
    "portfolio_builder":       ["task_retrospective"],
    "career_trajectory":       ["skill_sharpener", "task_retrospective"],
    "professional_dev":        ["skill_sharpener", "principle_validator"],
    "salary_intelligence":     ["skill_sharpener", "task_retrospective"],
    "networking_intelligence": ["user_model", "memory_hygiene"],

    # Knowledge (Set 3) → Agent Self-Improvement (Set 2)
    "insight_crystallizer":    ["skill_sharpener", "principle_validator"],
    "cross_domain":            ["knowledge_gap_detector", "memory_hygiene"],
    "question_generator":      ["knowledge_gap_detector"],
    "argument_builder":        ["memory_hygiene"],
    "wisdom_extractor":        ["principle_validator", "skill_sharpener"],
    "pattern_matcher":         ["skill_sharpener", "knowledge_gap_detector"],
    "expertise_mapper":        ["skill_sharpener", "self_model_refresh"],
    "teaching_material":       ["skill_sharpener", "principle_validator"],
    "mental_models":           ["task_retrospective", "skill_sharpener"],
    "research_synthesizer":    ["memory_hygiene", "knowledge_gap_detector"],

    # Proactive (Set 3) → Agent Self-Improvement (Set 2)
    "opportunity_detector":    ["skill_sharpener", "user_model"],
    "risk_early_warning":      ["memory_hygiene", "task_retrospective"],
    "deadline_predictor":      ["task_retrospective"],
    "burnout_detector":        ["task_retrospective", "self_model_refresh"],
    "relationship_decay":      ["user_model", "memory_hygiene"],
    "knowledge_decay":         ["skill_sharpener"],
    "goal_drift":              ["task_retrospective", "session_prep"],
    "dependency_alert":        ["task_retrospective"],
    "future_self":             ["self_model_refresh", "task_retrospective", "skill_sharpener"],
    "decision_fatigue":        ["task_retrospective", "correction_learner"],
}

# ---------------------------------------------------------------------------
# Recommended Starter Sets
# ---------------------------------------------------------------------------

RECOMMENDED_ALWAYS_ON = [
    # Set 2: Agent improvement — these run silently and make everything better
    "correction_learner",
    "memory_hygiene",
    "self_model_refresh",
    "session_prep",
    "task_retrospective",
    "skill_sharpener",
    "principle_validator",
]

RECOMMENDED_USER = [
    # Set 3: The features users will love immediately
    "decision_journal",
    "weekly_wins",
    "life_dashboard",
    "commitment_tracker",
    "learning_path",
]

RECOMMENDED_GENERIC = [
    # Set 1: Useful utility workflows
    "daily_planner",
    "weekly_review",
]

RECOMMENDED_ALL = RECOMMENDED_ALWAYS_ON + RECOMMENDED_USER + RECOMMENDED_GENERIC

# ---------------------------------------------------------------------------
# Cron Expression Parser
# ---------------------------------------------------------------------------

def cron_to_schtasks(cron: str) -> Tuple[str, str]:
    """Convert cron expression to Windows schtasks /sc and /st parameters.

    Handles common patterns:
        "0 9 * * *"     → /sc DAILY /st 09:00
        "0 9 * * 1"     → /sc WEEKLY /d MON /st 09:00
        "0 9 * * 1-5"   → /sc WEEKLY /d MON,TUE,WED,THU,FRI /st 09:00
        "*/30 * * * *"   → /sc MINUTE /mo 30
        "0 */4 * * *"    → /sc HOURLY /mo 4
    """
    parts = cron.split()
    if len(parts) != 5:
        return "DAILY", "09:00"

    minute, hour, dom, month, dow = parts
    day_map = {"0": "SUN", "1": "MON", "2": "TUE", "3": "WED",
               "4": "THU", "5": "FRI", "6": "SAT", "7": "SUN"}

    # Every N minutes
    if minute.startswith("*/"):
        interval = minute[2:]
        return f"MINUTE /mo {interval}", ""

    # Every N hours
    if hour.startswith("*/"):
        interval = hour[2:]
        return f"HOURLY /mo {interval}", ""

    # Specific time
    time_str = f"{int(hour):02d}:{int(minute):02d}" if hour != "*" and minute != "*" else "09:00"

    # Daily
    if dow == "*" and dom == "*":
        return f"DAILY /st {time_str}", time_str

    # Specific weekdays
    if dow != "*":
        if "-" in dow:
            start, end = dow.split("-")
            days = []
            for d in range(int(start), int(end) + 1):
                days.append(day_map.get(str(d), "MON"))
            return f"WEEKLY /d {','.join(days)} /st {time_str}", time_str
        elif "," in dow:
            days = [day_map.get(d.strip(), "MON") for d in dow.split(",")]
            return f"WEEKLY /d {','.join(days)} /st {time_str}", time_str
        else:
            day = day_map.get(dow, "MON")
            return f"WEEKLY /d {day} /st {time_str}", time_str

    return f"DAILY /st {time_str}", time_str


def cron_to_launchctl_interval(cron: str) -> int:
    """Convert cron to launchctl StartInterval in seconds (approximate)."""
    parts = cron.split()
    if len(parts) != 5:
        return 86400

    minute, hour, dom, month, dow = parts

    if minute.startswith("*/"):
        return int(minute[2:]) * 60
    if hour.startswith("*/"):
        return int(hour[2:]) * 3600
    if dow != "*":
        return 604800  # weekly
    return 86400  # daily


# ---------------------------------------------------------------------------
# Scheduler Sync Engine
# ---------------------------------------------------------------------------

class WorkflowScheduler:
    """Sync enabled workflows to OS-native scheduled tasks."""

    TASK_PREFIX = "aibrain_wf_"

    def __init__(self, db_path: str):
        self.db_path = db_path
        self.system = platform.system().lower()

    def _db(self):
        conn = sqlite3.connect(self.db_path, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        return conn

    # ------------------------------------------------------------------
    # Workflow management
    # ------------------------------------------------------------------

    def list_workflows(self, category: str = None, enabled_only: bool = False) -> List[Dict]:
        """List all workflows with status."""
        conn = self._db()
        query = "SELECT name, display_name, category, description, cron_schedule, enabled, source FROM workflows"
        conditions = []
        params = []

        if category:
            conditions.append("category=?")
            params.append(category)
        if enabled_only:
            conditions.append("enabled=1")

        if conditions:
            query += " WHERE " + " AND ".join(conditions)
        query += " ORDER BY category, name"

        rows = conn.execute(query, params).fetchall()
        conn.close()
        return [dict(r) for r in rows]

    def enable_workflow(self, name: str, auto_deps: bool = True) -> Dict:
        """Enable a workflow. Auto-enables Set 2 dependencies if it's a Set 3 workflow."""
        conn = self._db()
        enabled = []

        # Check if workflow requires a paid tier
        FREE_SOURCES = {"builtin", "registry", "generic"}
        row = conn.execute("SELECT source FROM workflows WHERE name=?", (name,)).fetchone()
        if row and row[0] not in FREE_SOURCES:
            try:
                from aibrain_licensing import check_tier
                if not check_tier("pro"):
                    conn.close()
                    from aibrain_licensing import upgrade_message
                    return {"error": upgrade_message("pro"), "enabled": []}
            except ImportError:
                pass

        # Enable the requested workflow
        conn.execute("UPDATE workflows SET enabled=1 WHERE name=?", (name,))
        enabled.append(name)

        # Auto-enable dependencies
        if auto_deps and name in WORKFLOW_DEPENDENCIES:
            deps = WORKFLOW_DEPENDENCIES[name]
            for dep in deps:
                conn.execute("UPDATE workflows SET enabled=1 WHERE name=?", (dep,))
                enabled.append(dep)

        conn.commit()
        conn.close()
        return {"enabled": enabled, "dependencies_auto_enabled": enabled[1:]}

    def disable_workflow(self, name: str) -> Dict:
        """Disable a workflow. Does NOT auto-disable dependencies (other workflows may need them)."""
        conn = self._db()
        conn.execute("UPDATE workflows SET enabled=0 WHERE name=?", (name,))
        conn.commit()
        conn.close()
        return {"disabled": name}

    def enable_recommended(self) -> Dict:
        """Enable the recommended starter set."""
        conn = self._db()
        all_enabled = []

        for name in RECOMMENDED_ALL:
            conn.execute("UPDATE workflows SET enabled=1 WHERE name=?", (name,))
            all_enabled.append(name)

            # Also enable dependencies of recommended Set 3 workflows
            if name in WORKFLOW_DEPENDENCIES:
                for dep in WORKFLOW_DEPENDENCIES[name]:
                    conn.execute("UPDATE workflows SET enabled=1 WHERE name=?", (dep,))
                    if dep not in all_enabled:
                        all_enabled.append(dep)

        conn.commit()
        conn.close()
        return {"enabled": all_enabled, "count": len(all_enabled)}

    def get_dependencies(self, name: str) -> List[str]:
        """Get Set 2 dependencies for a Set 3 workflow."""
        return WORKFLOW_DEPENDENCIES.get(name, [])

    def get_dependents(self, name: str) -> List[str]:
        """Get which Set 3 workflows depend on a Set 2 workflow."""
        dependents = []
        for wf, deps in WORKFLOW_DEPENDENCIES.items():
            if name in deps:
                dependents.append(wf)
        return dependents

    # ------------------------------------------------------------------
    # OS Scheduler Sync
    # ------------------------------------------------------------------

    def sync(self, dry_run: bool = False) -> Dict:
        """Sync enabled workflows to OS scheduler."""
        enabled = self.list_workflows(enabled_only=True)
        existing = self._get_existing_tasks()

        to_create = []
        to_remove = []

        enabled_names = {w["name"] for w in enabled}
        existing_names = set(existing.keys())

        # Tasks to create (enabled but not scheduled)
        for wf in enabled:
            task_name = f"{self.TASK_PREFIX}{wf['name']}"
            if task_name not in existing_names:
                to_create.append(wf)

        # Tasks to remove (scheduled but not enabled)
        for task_name in existing_names:
            wf_name = task_name.replace(self.TASK_PREFIX, "")
            if wf_name not in enabled_names:
                to_remove.append(task_name)

        result = {
            "system": self.system,
            "enabled": len(enabled),
            "existing_tasks": len(existing),
            "to_create": [w["name"] for w in to_create],
            "to_remove": to_remove,
            "dry_run": dry_run,
        }

        if dry_run:
            return result

        # Apply changes
        created = 0
        removed = 0

        for wf in to_create:
            if self._create_task(wf):
                created += 1

        for task_name in to_remove:
            if self._remove_task(task_name):
                removed += 1

        result["created"] = created
        result["removed"] = removed
        return result

    def _get_existing_tasks(self) -> Dict[str, str]:
        """Get existing aibrain scheduled tasks from the OS."""
        tasks = {}

        if self.system == "windows":
            try:
                output = subprocess.check_output(
                    ["schtasks", "/query", "/fo", "CSV", "/nh"],
                    capture_output=False, text=True, stderr=subprocess.DEVNULL
                )
                for line in output.splitlines():
                    if self.TASK_PREFIX in line:
                        parts = line.strip('"').split('","')
                        if parts:
                            name = parts[0].strip('"').split("\\")[-1]
                            tasks[name] = "scheduled"
            except (subprocess.CalledProcessError, FileNotFoundError):
                pass

        elif self.system == "linux" or self.system == "darwin":
            try:
                output = subprocess.check_output(
                    ["crontab", "-l"], text=True, stderr=subprocess.DEVNULL
                )
                for line in output.splitlines():
                    if self.TASK_PREFIX in line:
                        # Extract task name from comment
                        match = re.search(r'# (aibrain_wf_\w+)', line)
                        if match:
                            tasks[match.group(1)] = "scheduled"
            except (subprocess.CalledProcessError, FileNotFoundError):
                pass

        return tasks

    def _create_task(self, workflow: Dict) -> bool:
        """Create an OS scheduled task for a workflow."""
        name = workflow["name"]
        cron = workflow.get("cron_schedule", "0 9 * * *")
        task_name = f"{self.TASK_PREFIX}{name}"
        aibrain_cmd = f"aibrain workflows run {name}"

        try:
            if self.system == "windows":
                sc_params, st = cron_to_schtasks(cron)
                cmd_args = ["schtasks", "/create", "/tn", task_name, "/tr", aibrain_cmd, "/sc"] + sc_params.split() + ["/f"]
                subprocess.run(cmd_args, shell=False, check=True,
                              capture_output=True, text=True)
                log.info("Created Windows task: %s", task_name)
                return True

            elif self.system == "linux":
                # Append to user crontab
                try:
                    existing = subprocess.check_output(
                        ["crontab", "-l"], text=True, stderr=subprocess.DEVNULL
                    )
                except subprocess.CalledProcessError:
                    existing = ""

                if task_name not in existing:
                    new_entry = f"{cron} {aibrain_cmd} # {task_name}\n"
                    new_crontab = existing.rstrip("\n") + "\n" + new_entry
                    proc = subprocess.Popen(["crontab", "-"], stdin=subprocess.PIPE, text=True)
                    proc.communicate(input=new_crontab)
                    log.info("Created cron entry: %s", task_name)
                    return True

            elif self.system == "darwin":
                # Create launchctl plist
                plist_dir = Path.home() / "Library" / "LaunchAgents"
                plist_dir.mkdir(parents=True, exist_ok=True)
                plist_path = plist_dir / f"com.aibrain.{name}.plist"

                interval = cron_to_launchctl_interval(cron)
                plist = f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.aibrain.{name}</string>
    <key>ProgramArguments</key>
    <array>
        <string>aibrain</string>
        <string>workflows</string>
        <string>run</string>
        <string>{name}</string>
    </array>
    <key>StartInterval</key>
    <integer>{interval}</integer>
    <key>StandardOutPath</key>
    <string>{Path.home() / '.aibrain' / 'logs' / f'{name}.log'}</string>
    <key>StandardErrorPath</key>
    <string>{Path.home() / '.aibrain' / 'logs' / f'{name}.err'}</string>
</dict>
</plist>"""
                plist_path.write_text(plist)
                subprocess.run(["launchctl", "load", str(plist_path)],
                              capture_output=True, text=True)
                log.info("Created launchctl plist: %s", task_name)
                return True

        except Exception as e:
            log.error("Failed to create task %s: %s", task_name, e)
            return False

        return False

    def _remove_task(self, task_name: str) -> bool:
        """Remove an OS scheduled task."""
        try:
            if self.system == "windows":
                subprocess.run(
                    ["schtasks", "/delete", "/tn", task_name, "/f"],
                    shell=False, check=True, capture_output=True, text=True
                )
                return True

            elif self.system == "linux":
                try:
                    existing = subprocess.check_output(
                        ["crontab", "-l"], text=True, stderr=subprocess.DEVNULL
                    )
                    lines = [l for l in existing.splitlines() if task_name not in l]
                    proc = subprocess.Popen(["crontab", "-"], stdin=subprocess.PIPE, text=True)
                    proc.communicate(input="\n".join(lines) + "\n")
                    return True
                except subprocess.CalledProcessError:
                    return False

            elif self.system == "darwin":
                wf_name = task_name.replace(self.TASK_PREFIX, "")
                plist_path = Path.home() / "Library" / "LaunchAgents" / f"com.aibrain.{wf_name}.plist"
                if plist_path.exists():
                    subprocess.run(["launchctl", "unload", str(plist_path)],
                                  capture_output=True, text=True)
                    plist_path.unlink()
                    return True

        except Exception as e:
            log.error("Failed to remove task %s: %s", task_name, e)

        return False


# ---------------------------------------------------------------------------
# Onboarding
# ---------------------------------------------------------------------------

def onboarding_message(db_path: str) -> str:
    """Generate the onboarding message shown after `aibrain init`."""
    conn = sqlite3.connect(db_path, check_same_thread=False)

    # Count workflows by source
    counts = {}
    try:
        rows = conn.execute(
            "SELECT source, COUNT(*) as c FROM workflows GROUP BY source"
        ).fetchall()
        counts = {r[0]: r[1] for r in rows}
    except Exception:
        pass

    total = sum(counts.values())
    conn.close()

    msg = f"""
╔══════════════════════════════════════════════════════════╗
║                 aibrain v0.9.0 initialized               ║
╚══════════════════════════════════════════════════════════╝

  🧠 Brain database created
  📦 {total} workflows available across 5 categories

  ┌─────────────────────────────────────────────────────┐
  │  RECOMMENDED STARTER SET                            │
  │                                                     │
  │  AGENT IMPROVEMENT (always-on, runs quietly):       │
  │    [x] correction_learner   — learns from feedback  │
  │    [x] memory_hygiene       — keeps brain clean     │
  │    [x] self_model_refresh   — knows its strengths   │
  │    [x] session_prep         — ready every session   │
  │    [x] task_retrospective   — learns from outcomes  │
  │    [x] skill_sharpener      — finds weak areas      │
  │    [x] principle_validator  — tests what it knows    │
  │                                                     │
  │  PERSONAL INTELLIGENCE (the features you'll love):  │
  │    [ ] decision_journal     — track decisions +     │
  │                               outcomes over months  │
  │    [ ] weekly_wins          — your wins, surfaced   │
  │    [ ] life_dashboard       — everything at a       │
  │                               glance                │
  │    [ ] commitment_tracker   — never forget a        │
  │                               promise               │
  │    [ ] learning_path        — see your growth       │
  └─────────────────────────────────────────────────────┘

  Quick start:
    aibrain workflows enable --recommended   Enable starter set
    aibrain workflows list                   See all workflows
    aibrain workflows sync                   Create OS scheduled tasks
    aibrain workflows run <name>             Run one now

  The agent improvement workflows power the personal intelligence
  ones. When you enable a personal workflow, its dependencies
  auto-enable. The brain gets smarter in the background so the
  features you see get better over time.

  Learn more: aibrain help workflows
"""
    return msg


# ---------------------------------------------------------------------------
# CLI Integration
# ---------------------------------------------------------------------------

def cli_workflows(args: List[str], db_path: str) -> int:
    """Handle `aibrain workflows <subcommand>` CLI calls."""
    if not args:
        print("Usage: aibrain workflows <list|enable|disable|sync|run|deps>")
        return 1

    scheduler = WorkflowScheduler(db_path)
    subcmd = args[0]

    if subcmd == "list":
        category = args[1] if len(args) > 1 else None
        enabled_only = "--enabled" in args
        workflows = scheduler.list_workflows(category=category, enabled_only=enabled_only)

        current_cat = ""
        for wf in workflows:
            if wf["category"] != current_cat:
                current_cat = wf["category"]
                print(f"\n  [{current_cat.upper()}]")
            status = "[x]" if wf["enabled"] else "[ ]"
            deps_count = len(WORKFLOW_DEPENDENCIES.get(wf["name"], []))
            deps_note = f" (needs {deps_count} deps)" if deps_count > 0 else ""
            print(f"    {status} {wf['name']:35s} {wf['description'][:50]}{deps_note}")

        print(f"\n  Total: {len(workflows)} workflows")
        enabled = sum(1 for w in workflows if w["enabled"])
        print(f"  Enabled: {enabled}")

    elif subcmd == "enable":
        if "--recommended" in args:
            result = scheduler.enable_recommended()
            print(f"Enabled {result['count']} workflows (recommended set):")
            for name in result["enabled"]:
                print(f"  [x] {name}")
            print(f"\nRun 'aibrain workflows sync' to create OS scheduled tasks.")
        elif len(args) > 1 and not args[1].startswith("-"):
            name = args[1]
            result = scheduler.enable_workflow(name)
            print(f"Enabled: {name}")
            if result.get("dependencies_auto_enabled"):
                print(f"Auto-enabled dependencies:")
                for dep in result["dependencies_auto_enabled"]:
                    print(f"  [x] {dep}")
        else:
            print("Usage: aibrain workflows enable <name> | --recommended")

    elif subcmd == "disable":
        if len(args) > 1:
            name = args[1]
            # Check if other enabled workflows depend on this one
            dependents = scheduler.get_dependents(name)
            enabled_dependents = []
            for dep in dependents:
                wfs = scheduler.list_workflows(enabled_only=True)
                if any(w["name"] == dep for w in wfs):
                    enabled_dependents.append(dep)

            if enabled_dependents:
                print(f"⚠️  Warning: these enabled workflows depend on {name}:")
                for ed in enabled_dependents:
                    print(f"    - {ed}")
                print(f"Disabling anyway? They may produce less accurate results.")

            result = scheduler.disable_workflow(name)
            print(f"Disabled: {result['disabled']}")
        else:
            print("Usage: aibrain workflows disable <name>")

    elif subcmd == "sync":
        dry_run = "--dry-run" in args
        result = scheduler.sync(dry_run=dry_run)

        if dry_run:
            print(f"DRY RUN — {result['system']} scheduler")
            print(f"  Enabled workflows: {result['enabled']}")
            print(f"  Existing OS tasks: {result['existing_tasks']}")
            if result["to_create"]:
                print(f"  Would CREATE {len(result['to_create'])} tasks:")
                for name in result["to_create"]:
                    print(f"    + {name}")
            if result["to_remove"]:
                print(f"  Would REMOVE {len(result['to_remove'])} tasks:")
                for name in result["to_remove"]:
                    print(f"    - {name}")
            if not result["to_create"] and not result["to_remove"]:
                print(f"  No changes needed — scheduler is in sync.")
        else:
            print(f"Synced to {result['system']} scheduler:")
            print(f"  Created: {result.get('created', 0)} tasks")
            print(f"  Removed: {result.get('removed', 0)} tasks")

    elif subcmd == "run":
        if len(args) > 1:
            name = args[1]
            # Dynamically load and run the workflow
            from aibrain_workflows import WORKFLOW_REGISTRY
            from aibrain_skill_workflows import SKILL_WORKFLOW_REGISTRY
            from aibrain_user_workflows import USER_WORKFLOW_REGISTRY

            all_registries = {**WORKFLOW_REGISTRY, **SKILL_WORKFLOW_REGISTRY, **USER_WORKFLOW_REGISTRY}

            try:
                from aibrain_content_workflows import CONTENT_WORKFLOW_REGISTRY
                all_registries.update(CONTENT_WORKFLOW_REGISTRY)
            except ImportError:
                pass

            try:
                from aibrain_ops_workflows import OPS_WORKFLOW_REGISTRY
                all_registries.update(OPS_WORKFLOW_REGISTRY)
            except ImportError:
                pass

            # Load user's custom workflow registry if it exists
            # Checks: 1) AIBRAIN_ROOT/aibrain_custom_workflows.py
            #          2) config.json "custom_workflows_dir" path
            #          3) Python path (standard import)
            custom_loaded = False
            _cfg_path = Path(db_path).parent / "config.json"
            _cfg = {}
            if _cfg_path.exists():
                try:
                    _cfg = json.loads(_cfg_path.read_text(encoding="utf-8"))
                except Exception:
                    pass
            search_dirs = [Path(db_path).parent,
                           Path(os.environ.get("AIBRAIN_ROOT", Path.home() / "aibrain"))]
            if _cfg.get("custom_workflows_dir"):
                _custom_dir = Path(_cfg["custom_workflows_dir"]).resolve()
                _allowed_roots = [
                    Path.home().resolve(),
                    Path(os.environ.get("AIBRAIN_ROOT", Path.home() / "aibrain")).resolve(),
                ]
                # Use relative_to() — immune to startswith() prefix collisions and symlinks
                _in_allowed = False
                for _r in _allowed_roots:
                    try:
                        _custom_dir.relative_to(_r)
                        _in_allowed = True
                        break
                    except ValueError:
                        pass
                if _in_allowed:
                    search_dirs.insert(0, _custom_dir)
                else:
                    log.warning("Ignoring custom_workflows_dir outside allowed paths: %s", _custom_dir)
            for custom_dir in search_dirs:
                custom_path = custom_dir / "aibrain_custom_workflows.py"
                if custom_path.exists():
                    import importlib.util
                    spec = importlib.util.spec_from_file_location("aibrain_custom_workflows", str(custom_path))
                    mod = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(mod)
                    if hasattr(mod, "CUSTOM_WORKFLOW_REGISTRY"):
                        all_registries.update(mod.CUSTOM_WORKFLOW_REGISTRY)
                        custom_loaded = True
                    break
            if not custom_loaded:
                try:
                    from aibrain_custom_workflows import CUSTOM_WORKFLOW_REGISTRY
                    all_registries.update(CUSTOM_WORKFLOW_REGISTRY)
                except ImportError:
                    pass

            cls = all_registries.get(name)
            if cls:
                wf = cls(db_path)
                print(f"Running {name}...")
                result = wf.run()
                print(json.dumps(result, indent=2))
            else:
                # Fallback: check for standalone script in workflows/
                script_path = Path(db_path).parent / "workflows" / f"{name}.py"
                if not script_path.exists():
                    # Also check relative to AIBRAIN_ROOT
                    aibrain_root = Path(os.environ.get("AIBRAIN_ROOT", Path.home() / "aibrain"))
                    script_path = aibrain_root / "workflows" / f"{name}.py"
                if not script_path.exists():
                    # Check scheduled_jobs.json for script path mapping
                    aibrain_root = Path(os.environ.get("AIBRAIN_ROOT", Path.home() / "aibrain"))
                    search_roots = [Path(db_path).parent, aibrain_root, Path.cwd()]
                    for root in search_roots:
                        sj_path = root / "scheduled_jobs.json"
                        if sj_path.exists():
                            sj = json.loads(sj_path.read_text(encoding="utf-8"))
                            for job in sj.get("jobs", []):
                                if job.get("name") == name and job.get("script"):
                                    candidate = (root / job["script"]).resolve()
                                    # Guard against path traversal in script field
                                    try:
                                        candidate.relative_to(root.resolve())
                                    except ValueError:
                                        log.warning("Blocked path traversal in scheduled_jobs.json script: %s", job["script"])
                                        continue
                                    if candidate.exists():
                                        script_path = candidate
                                        break
                            if script_path.exists():
                                break
                if script_path.exists():
                    import subprocess
                    print(f"Running {name} (standalone script: {script_path})...")
                    cmd = [sys.executable, str(script_path)]
                    if "--dry-run" in sys.argv:
                        cmd.append("--dry-run")
                    result = subprocess.run(cmd, cwd=str(script_path.parent.parent))
                    return result.returncode
                else:
                    print(f"Unknown workflow: {name}")
                    print(f"  Not found in registries or workflows/ directory")
                    return 1
        else:
            print("Usage: aibrain workflows run <name>")

    elif subcmd == "deps":
        if len(args) > 1:
            name = args[1]
            deps = scheduler.get_dependencies(name)
            dependents = scheduler.get_dependents(name)

            if deps:
                print(f"{name} DEPENDS ON:")
                for d in deps:
                    print(f"  → {d}")
            if dependents:
                print(f"{name} IS NEEDED BY:")
                for d in dependents:
                    print(f"  ← {d}")
            if not deps and not dependents:
                print(f"{name} has no dependencies and no dependents.")
        else:
            # Show full dependency tree
            print("Workflow Dependency Map:\n")
            for wf, deps in sorted(WORKFLOW_DEPENDENCIES.items()):
                print(f"  {wf}")
                for d in deps:
                    print(f"    → {d}")

    else:
        print(f"Unknown subcommand: {subcmd}")
        print("Usage: aibrain workflows <list|enable|disable|sync|run|deps>")
        return 1

    return 0


if __name__ == "__main__":
    db = os.environ.get("AIBRAIN_DB", str(Path.home() / "aibrain" / "aibrain.db"))
    sys.exit(cli_workflows(sys.argv[1:], db))
