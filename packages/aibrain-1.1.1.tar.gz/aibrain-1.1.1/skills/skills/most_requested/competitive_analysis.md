---
name: competitive-analysis
description: >-
  Analyzes competitive landscape for a product or market.
  Use when comparing products, evaluating market positioning,
  identifying feature gaps, or mining competitor reviews.
  NOT for internal product planning or pricing decisions.
allowed-tools: [Read, Grep, Glob, Bash, WebSearch, WebFetch]
---

## Identity & Scope
**Executor:** either | **Model tier:** sonnet
**Scope:** Public competitor data — websites, reviews, job postings, repos, pricing pages.
**Off-limits:** Internal pricing decisions, revenue projections, confidential data.

### Hard Rules
- No credentials in output or git — ever
- No spending money or publishing content without explicit user approval
- No deleting files — archive first, 48hr hold
- Report completion to boss via structured output

## Essential Principles
1. **Source every claim** — Attach a URL or reference to every assertion. Guards against: fabricated competitor data.
2. **Compare on axes that matter** — Choose dimensions based on actual customers, not generic features. Guards against: irrelevant feature matrices.
3. **Include competitor strengths honestly** — Report where competitors are genuinely better. Guards against: confirmation bias.
4. **Separate facts from inferences** — Label review sentiment as inference. Guards against: treating opinions as verified data.

## When to Use
- User asks "who are our competitors?" or "compare us to X"
- Market positioning or go-to-market strategy work
- Feature gap analysis before a product roadmap session
- Pricing research against named competitors
- "What are people saying about [competitor]?" review mining

## When NOT to Use
- Internal product roadmap planning — use `project-planning` instead
- Marketing copy positioning — use `social-media-content` instead
- Technical architecture comparison — use `research-synthesis` instead
- Single product question without comparison — answer directly

## Rationalizations to Reject
| Shortcut | Why it's wrong |
|----------|----------------|
| "I'll list features from memory" | Competitor data changes constantly; stale claims mislead strategy |
| "Reviews are subjective, skip them" | Review mining reveals pain points pricing pages hide |
| "Only compare the top 3" | Emerging competitors are the biggest strategic blind spot |
| "Pricing page is enough" | Hidden costs, usage limits, and enterprise tiers require deeper digging |

## Workflow
### Phase 1: Scope Definition
**Entry:** User has named a product/market and at least one competitor.
**Actions:**
1. Extract user's product name and market category.
2. Identify all named competitors; if fewer than 3, search for more in the category.
3. Define 4-6 comparison axes relevant to the market.
**Exit:** Competitor list (3-6) and comparison axes documented.

### Phase 2: Data Collection
**Entry:** Phase 1 complete.
**Actions:**
1. Gather pricing data from each competitor's pricing page.
2. Collect feature lists from product pages and documentation.
3. Mine reviews (G2, Capterra, Reddit, HN) for top 3 complaints and praises per competitor.
4. Check GitHub repos (if OSS) for stars, commit frequency, open issues.
5. Scan job postings for tech stack and growth signals.
**Exit:** Raw data with source URLs for all competitors across all axes.

### Phase 3: Analysis & Synthesis
**Entry:** Phase 2 complete.
**Actions:**
1. Build feature comparison matrix across all axes.
2. Create positioning map on the two most differentiating axes.
3. Summarize review sentiment per competitor (strengths and weaknesses).
4. Write differentiation statement per competitor.
5. Identify risks: where competitors are stronger or could erode positioning.
**Exit:** Complete analysis with all sections populated.

### Phase 4: Verification
**Entry:** All prior phases complete.
**Actions:**
1. Verify every claim has a source reference.
2. Confirm both strengths AND weaknesses reported for each competitor.
3. Check no placeholder text remains. Validate JSON output format.
**Exit:** All checks pass — report results to boss/user.

## Output Format
```json
{
  "skill": "competitive-analysis",
  "status": "completed",
  "worker": "worker-id",
  "summary": "Analyzed 4 competitors in API monitoring against 5 axes",
  "findings": [
    {"item": "Datadog leads on integrations (600+) but users report pricing opacity", "severity": "high", "detail": "G2 (4.3/5, 847 reviews): unexpected bills #1 complaint. Source: g2.com/products/datadog/reviews"},
    {"item": "New Relic free tier undercuts all on entry pricing", "severity": "medium", "detail": "100GB/mo free ingestion launched Q1 2025. Source: newrelic.com/pricing"}
  ],
  "positioning_map": {"x_axis": "Ease of setup", "y_axis": "Enterprise depth", "positions": {"Datadog": [0.6, 0.9], "New Relic": [0.7, 0.7]}},
  "differentiation": "Wins on transparent pricing and dev UX; loses on enterprise integration count.",
  "risks": ["Datadog shipping simplified onboarding in Q3 could erode setup-speed advantage."],
  "errors": [], "elapsed_seconds": 45.2
}
```
### Bad Example
```json
{"skill": "competitive-analysis", "status": "completed", "summary": "Did competitive analysis", "findings": [{"item": "Competitor A is not as good as us", "severity": "info", "detail": "They have fewer features"}]}
```
Wrong: No sources, vague claims, no positioning map, no risks, no competitor strengths.

## Escalation Triggers
STOP and report to boss when:
- A competitor's data is behind a login wall
- The product category is ambiguous across multiple markets
- You've failed to find pricing data for a key competitor after 3 attempts
- Scope exceeds 6 competitors (confirm before proceeding)

Report as: `{"status": "escalated", "reason": "...", "context": "...", "recommendation": "..."}`

## Success Criteria
- [ ] At least 3 competitors analyzed across all defined axes
- [ ] Every factual claim has a source URL or reference
- [ ] Both strengths and weaknesses reported per competitor
- [ ] Positioning map with meaningful axes included
- [ ] Risks section identifies at least one genuine threat
- [ ] Output matches JSON format above
- [ ] Results reported to boss via structured output
