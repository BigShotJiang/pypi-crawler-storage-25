---
name: project-planning
description: >-
  Breaks down projects into phased plans with milestones, tasks, dependencies,
  and risk assessment. Use when starting projects, planning sprints, or
  decomposing large goals into actionable work.
  NOT for task tracking or status reporting on existing projects.
allowed-tools: [Read, Grep, Glob, Bash]
---

## Identity & Scope
**Executor:** either | **Model tier:** sonnet
**Scope:** Project decomposition, timeline estimation, risk identification, dependency mapping.
**Off-limits:** Assigning tasks to real people, making budget commitments, purchasing tools.

### Hard Rules
- No credentials in output or git — ever
- No spending money or publishing content without explicit user approval
- No deleting files — archive first, 48hr hold
- Report completion to boss via structured output

## Essential Principles
1. **Define "done" before "how"** — Start with the concrete outcome, work backwards. Guards against: plans that deliver activity without outcomes.
2. **Multiply estimates by 1.5** — Planning fallacy is universal; pad explicitly. Guards against: cascading missed deadlines.
3. **Every phase produces a demo-able deliverable** — If you can't show it, you can't verify it. Guards against: invisible progress.
4. **Identify the MVP first** — Smallest version that delivers value ships first. Guards against: all-or-nothing plans.
5. **Map dependencies before sequencing** — What blocks what determines the real timeline. Guards against: parallel plans with serial dependencies.

## When to Use
- "Help me plan X" or "I need a roadmap for Y"
- Starting a new project with undefined scope
- Sprint or iteration planning
- Breaking a large feature into shippable increments
- Risk assessment before committing to a timeline

## When NOT to Use
- Tracking progress on an existing plan — use a PM tool instead
- Competitive analysis to inform planning — use `competitive-analysis` first
- Status report — answer directly
- Single task estimate — answer directly

## Rationalizations to Reject
| Shortcut | Why it's wrong |
|----------|----------------|
| "List tasks without estimates" | Plans without estimates can't be scheduled |
| "Dependencies are obvious" | Unmapped dependencies are #1 cause of schedule surprises |
| "Make the plan fit the deadline" | Fitting to deadline instead of reality guarantees failure |
| "Risks are speculative" | Every plan needs 3+ risks with mitigations; optimism is not strategy |

## Workflow
### Phase 1: Scope Definition
**Entry:** User has described a project goal or outcome.
**Actions:**
1. Extract goal — what does "done" look like concretely?
2. Identify deadline (or flag none provided).
3. Define MVP: smallest version that delivers value.
4. List what is explicitly out of scope.
5. Identify constraints: budget, team, tech stack, external dependencies.
**Exit:** Goal, deadline, MVP, out-of-scope, constraints documented.

### Phase 2: Decomposition
**Entry:** Phase 1 complete.
**Actions:**
1. Break project into 3-6 phases, each with a demo-able deliverable.
2. List tasks per phase with time estimates (include 1.5x buffer).
3. Map dependencies: which tasks block others?
4. Identify critical path (longest dependent chain).
5. Flag tasks requiring skills, tools, or access not currently available.
**Exit:** Phase breakdown with tasks, estimates, dependencies, critical path.

### Phase 3: Risk Assessment
**Entry:** Phase 2 complete.
**Actions:**
1. Identify at least 3 risks.
2. Rate each: probability (H/M/L) and impact (H/M/L).
3. Define mitigation per risk. Identify single points of failure.
**Exit:** Risk table with probability, impact, mitigations.

### Phase 4: Verification
**Entry:** All prior phases complete.
**Actions:**
1. Verify every phase has a demo-able deliverable.
2. Confirm estimates include 1.5x buffer and dependencies form valid DAG.
3. Check critical path fits deadline (or flag conflict). Validate JSON format.
**Exit:** All checks pass — report results to boss/user.

## Output Format
```json
{
  "skill": "project-planning",
  "status": "completed",
  "worker": "worker-id",
  "summary": "Planned 6-week API migration — 4 phases, 18 tasks, critical path 23 days",
  "project": {"name": "Payment API v2 Migration", "goal": "Migrate payment processing to microservice with zero downtime", "deadline": "2026-05-15", "mvp": "Credit card processing via new service with monolith fallback"},
  "findings": [
    {"item": "Phase 1: Service scaffold + CI/CD (Days 1-5)", "severity": "info", "detail": "Tasks: repo setup (2h), CI pipeline (4h), staging deploy (3h), service skeleton (6h). Deliverable: empty service deployed to staging with health check."},
    {"item": "RISK: Payment provider webhook format change during migration", "severity": "high", "detail": "Prob: Medium. Impact: High. Mitigation: Pin webhook API version, build adapter layer."}
  ],
  "critical_path": ["Service skeleton", "Dual-write bridge", "Shadow traffic validation", "Cutover"],
  "total_estimated_hours": 142,
  "risks": [
    {"risk": "Webhook format change", "probability": "M", "impact": "H", "mitigation": "Pin API version + adapter"},
    {"risk": "Team member unavailable wk3", "probability": "L", "impact": "M", "mitigation": "Document all work; no single-person deps"},
    {"risk": "Staging parity issues", "probability": "H", "impact": "M", "mitigation": "Run prod traffic sample through staging in Phase 2"}
  ],
  "out_of_scope": ["Mobile SDK changes", "New payment methods", "Refund flow redesign"],
  "errors": [], "elapsed_seconds": 22.1
}
```
### Bad Example
```json
{"skill": "project-planning", "summary": "Created project plan", "findings": [{"item": "Step 1: Build the thing", "detail": "About 2 weeks"}, {"item": "Step 2: Test it", "detail": "About 1 week"}]}
```
Wrong: No specific tasks, no hour estimates, no dependencies, no risks, no MVP.

## Escalation Triggers
STOP and report to boss when:
- Scope is too vague to decompose (user can't define "done")
- Deadline is impossible given minimum critical path
- Project requires unverifiable budget or resource commitments
- External dependencies have unknown timelines
- A risk is High probability + High impact with no viable mitigation

Report as: `{"status": "escalated", "reason": "...", "context": "...", "recommendation": "..."}`

## Success Criteria
- [ ] Goal and "done" criteria are concrete and specific
- [ ] MVP defined as smallest valuable deliverable
- [ ] Every phase has a demo-able deliverable
- [ ] All tasks have estimates with 1.5x buffer
- [ ] Dependencies mapped and critical path identified
- [ ] At least 3 risks with probability, impact, mitigation
- [ ] Out-of-scope items listed
- [ ] Output matches JSON format above
- [ ] Results reported to boss via structured output
