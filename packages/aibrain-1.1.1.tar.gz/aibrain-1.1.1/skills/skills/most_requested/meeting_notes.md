---
name: meeting-notes
description: >-
  Transforms meeting transcripts or raw notes into structured summaries
  with decisions, action items, and owners.
  Use when summarizing meetings, extracting action items, or converting
  raw notes into distributable format.
  NOT for scheduling meetings or taking live notes.
allowed-tools: [Read, Grep, Glob]
---

## Identity & Scope
**Executor:** either | **Model tier:** haiku
**Scope:** Text processing of meeting transcripts and notes. Read-only.
**Off-limits:** Recording meetings, accessing calendars, sending summaries, scheduling.

### Hard Rules
- No credentials in output or git — ever
- No spending money or publishing content without explicit user approval
- No deleting files — archive first, 48hr hold
- Report completion to boss via structured output

## Essential Principles
1. **Decisions and action items first** — Lead with what was decided and who owes what. Guards against: burying actionable items in narrative.
2. **Every action item has an owner and deadline** — Unassigned actions don't get done. Guards against: orphaned tasks.
3. **Attribute statements to speakers** — "Alex proposed X" not "it was proposed." Guards against: accountability gaps.

## When to Use
- User provides a meeting transcript and asks for a summary
- Action item extraction from raw notes
- Converting rambling notes into structured format
- Post-meeting distribution to attendees

## When NOT to Use
- Scheduling a meeting — use a calendar tool instead
- Live transcription — use a transcription service instead
- Meeting agenda creation — use `project-planning` instead
- Input is already well-structured — answer directly

## Rationalizations to Reject
| Shortcut | Why it's wrong |
|----------|----------------|
| "Summarize chronologically" | Chronological order buries decisions; lead with actions |
| "Leave action item unassigned" | Flag as [UNASSIGNED] — that's a finding, not something to ignore |
| "Deadline wasn't mentioned, skip it" | Default to "by next meeting" and flag — every action needs a deadline |

## Workflow
### Phase 1: Input Processing
**Entry:** User has provided transcript, raw notes, or audio-to-text output.
**Actions:**
1. Read full input; identify meeting topic, date, and attendees.
2. Identify format: structured transcript (with speaker labels) vs raw notes.
3. Flag unclear, garbled, or contradictory sections.
**Exit:** Meeting metadata extracted; format identified.

### Phase 2: Extraction
**Entry:** Phase 1 complete.
**Actions:**
1. Extract all decisions — who decided, what, any conditions.
2. Extract all action items — owner, description, deadline (or flag as unspecified).
3. Extract open questions needing follow-up.
4. Identify scheduled next meeting date/time.
**Exit:** Decisions, action items, open questions documented.

### Phase 3: Summary Composition
**Entry:** Phase 2 complete.
**Actions:**
1. Write 3-5 sentence discussion summary (main topics + conclusions).
2. Organize action items in table: Owner | Action | Deadline.
3. List open questions. Flag unassigned items as "[UNASSIGNED]."
**Exit:** Complete structured summary.

### Phase 4: Verification
**Entry:** All prior phases complete.
**Actions:**
1. Cross-check every action item against source transcript.
2. Verify every action has owner or explicit [UNASSIGNED] flag.
3. Confirm no key decisions omitted. Validate JSON format.
**Exit:** All checks pass — report results to boss/user.

## Output Format
```json
{
  "skill": "meeting-notes",
  "status": "completed",
  "worker": "worker-id",
  "summary": "Summarized 45-min product roadmap meeting — 3 decisions, 5 action items, 2 open questions",
  "meeting": {"title": "Q2 Product Roadmap Review", "date": "2026-04-03", "duration": "45 min", "attendees": ["Sarah (PM)", "Alex (Eng Lead)", "Jordan (Design)"]},
  "findings": [
    {"item": "DECISION: Push billing v2 to April 15 — payment provider delay", "severity": "high", "detail": "Alex: Stripe webhook migration needs 5 more days. Sarah approved."},
    {"item": "ACTION: Alex — Complete Stripe webhook migration", "severity": "high", "detail": "Deadline: April 10. Blocks billing v2 launch."},
    {"item": "OPEN: PayPal support in v2 or defer to v3?", "severity": "medium", "detail": "Sarah to bring usage data to next meeting."}
  ],
  "action_items": [
    {"owner": "Alex", "action": "Complete Stripe webhook migration", "deadline": "2026-04-10"},
    {"owner": "[UNASSIGNED]", "action": "Pull PayPal usage data", "deadline": "2026-04-10"}
  ],
  "next_meeting": "2026-04-10 2pm EST",
  "errors": [], "elapsed_seconds": 8.4
}
```
### Bad Example
```json
{"skill": "meeting-notes", "summary": "Team discussed product roadmap", "findings": [{"item": "Various topics were covered", "detail": "The team talked about billing and design."}]}
```
Wrong: No decisions, no action items, no owners, no deadlines.

## Escalation Triggers
STOP and report to boss when:
- Transcript contains confidential HR, legal, or personnel discussions
- Audio/transcript is too garbled to extract reliable action items (>30% unclear)
- Contradictory decisions appear (different speakers agree to different things)
- Meeting references documents you don't have access to

Report as: `{"status": "escalated", "reason": "...", "context": "...", "recommendation": "..."}`

## Success Criteria
- [ ] All decisions captured with attribution
- [ ] All action items have owner or explicit [UNASSIGNED] flag
- [ ] All action items have deadline or explicit "not specified" flag
- [ ] Discussion summary is 3-5 sentences, not a transcript rehash
- [ ] Open questions listed separately from decisions
- [ ] Output matches JSON format above
- [ ] Results reported to boss via structured output
