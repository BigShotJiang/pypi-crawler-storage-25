---
name: email-drafting
description: >-
  Drafts clear, professional, action-oriented emails.
  Use when composing emails, follow-ups, introductions, proposals,
  or any correspondence requiring a specific tone and clear ask.
  NOT for bulk email campaigns or newsletter generation.
allowed-tools: [Read, Grep, Glob]
---

## Identity & Scope
**Executor:** either | **Model tier:** haiku
**Scope:** Drafting email text for user review. Does NOT send emails.
**Off-limits:** Sending emails, accessing email accounts, writing bulk marketing campaigns.

### Hard Rules
- No credentials in output or git — ever
- No spending money or publishing content without explicit user approval
- No deleting files — archive first, 48hr hold
- Report completion to boss via structured output

## Essential Principles
1. **Put the ask in the first sentence** — State what you need before providing context. Guards against: buried requests that get ignored.
2. **One email, one topic** — Two distinct requests become two drafts. Guards against: multi-topic emails where the second ask gets lost.
3. **Match the recipient's tone** — Never more casual than the recipient. Guards against: tone mismatches that damage relationships.

## When to Use
- User says "draft an email to X about Y"
- Follow-up emails after meetings or deadlines
- Introduction or networking emails
- Proposal or request emails requiring clear structure
- Apology or sensitive communication requiring careful tone

## When NOT to Use
- Bulk marketing emails — use an email marketing tool instead
- Newsletters — use `social-media-content` or newsletter skill instead
- Analyzing received emails — use `data-analysis` instead
- Quick one-line reply — answer directly

## Rationalizations to Reject
| Shortcut | Why it's wrong |
|----------|----------------|
| "Write a friendly generic email" | Generic emails get ignored; must be specific to recipient and context |
| "Subject line can just be the topic" | Must include action: "Review needed: Q2 report by Friday" not "Report" |
| "Add pleasantries to fill space" | Every sentence must earn its place; length kills read-completion |

## Workflow
### Phase 1: Context Extraction
**Entry:** User has specified recipient, topic, and purpose (or enough to infer).
**Actions:**
1. Identify recipient, relationship, and appropriate tone.
2. Extract the core ask — what does the user need the recipient to do?
3. Identify deadline, context, or constraints.
4. Determine if prior conversation context exists.
**Exit:** Recipient, tone, core ask, deadline, and context documented.

### Phase 2: Draft Composition
**Entry:** Phase 1 complete.
**Actions:**
1. Write subject line: [Action] — [Topic] [Deadline if applicable].
2. Write opening sentence containing the core ask.
3. Add 2-3 sentences of supporting context.
4. Use bullets if there are multiple items.
5. Close with specific next step and deadline.
6. Add appropriate sign-off matching tone.
**Exit:** Complete email draft with subject, body, sign-off.

### Phase 3: Tone & Quality Check
**Entry:** Phase 2 complete.
**Actions:**
1. Read from recipient's perspective — is the ask clear within 5 seconds?
2. Check for passive-aggressive or ambiguous phrasing.
3. Verify under 150 words unless complexity requires more.
**Exit:** Polished draft ready for user review.

### Phase 4: Verification
**Entry:** All prior phases complete.
**Actions:**
1. Confirm draft has: subject, clear ask, context, next step, sign-off.
2. Verify no unintentional placeholder text remains.
3. Validate JSON output format.
**Exit:** All checks pass — report results to boss/user.

## Output Format
```json
{
  "skill": "email-drafting",
  "status": "completed",
  "worker": "worker-id",
  "summary": "Drafted follow-up email to hiring manager re: interview next steps",
  "drafts": [
    {"subject": "Next steps — Senior Engineer interview follow-up", "to": "Jane Smith, Engineering Director", "tone": "professional-warm", "body": "Hi Jane,\n\nThank you for the conversation on Tuesday — I'm writing to confirm my availability for the technical round.\n\nI'm open any day next week between 10am-4pm EST. Happy to adjust if those times don't work.\n\nLooking forward to it.\n\nBest,\nAlex", "word_count": 47}
  ],
  "errors": [], "elapsed_seconds": 3.1
}
```
### Bad Example
```json
{"skill": "email-drafting", "status": "completed", "drafts": [{"subject": "Follow up", "body": "Hi,\n\nI wanted to touch base regarding our previous conversation. I hope this email finds you well. Please let me know at your earliest convenience.\n\nThanks, Alex"}]}
```
Wrong: No action in subject, opening is filler, no specific ask, "earliest convenience" is not a deadline.

## Escalation Triggers
STOP and report to boss when:
- Email involves legal, HR, or regulatory compliance matters
- User asks to send the email (this skill drafts only)
- Recipient or context is ambiguous, risking misdirected email
- Email requires confidential information you don't have

Report as: `{"status": "escalated", "reason": "...", "context": "...", "recommendation": "..."}`

## Success Criteria
- [ ] Subject line includes action word and topic
- [ ] Core ask in the first sentence
- [ ] Specific next step with deadline (or explicit reason for omitting)
- [ ] Tone matches relationship with recipient
- [ ] Under 150 words unless complexity justifies more
- [ ] Output matches JSON format above
- [ ] Results reported to boss via structured output
