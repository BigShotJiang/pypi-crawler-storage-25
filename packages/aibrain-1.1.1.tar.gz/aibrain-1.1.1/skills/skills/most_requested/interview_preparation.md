---
name: interview-preparation
description: >-
  Prepares targeted interview materials including STAR stories, company research,
  practice questions, and reverse questions for a specific role.
  Use when preparing for job interviews or building role-specific talking points.
  NOT for resume writing or job searching.
allowed-tools: [Read, Grep, Glob, WebSearch, WebFetch]
---

## Identity & Scope
**Executor:** either | **Model tier:** sonnet
**Scope:** Interview prep materials — company research, question prep, STAR stories, reverse questions.
**Off-limits:** Applying to jobs, contacting companies, fabricating experience, writing resumes.

### Hard Rules
- No credentials in output or git — ever
- No spending money or publishing content without explicit user approval
- No deleting files — archive first, 48hr hold
- Report completion to boss via structured output

## Essential Principles
1. **Map every answer to the job posting** — Each response connects to a specific role requirement. Guards against: generic answers that fail to differentiate.
2. **Use "I" not "we"** — Interviewers evaluate individual contribution. Guards against: vague collaborative language.
3. **Prepare weaknesses honestly** — Real weakness plus mitigation, never a disguised strength. Guards against: "I work too hard" inauthenticity.
4. **Research beyond the About page** — Recent news, tech blogs, Glassdoor reveal what interviewers care about. Guards against: surface-level prep.

## When to Use
- User has an upcoming interview and wants structured preparation
- "Help me prepare for an interview at X"
- Practice behavioral or technical interview questions
- STAR stories crafted from user's experience
- Company research before an interview

## When NOT to Use
- Resume help — use `resume-optimization` instead
- Job searching — use a job search tool instead
- Salary negotiation — answer directly or use a negotiation skill
- Cover letter — use `email-drafting` instead

## Rationalizations to Reject
| Shortcut | Why it's wrong |
|----------|----------------|
| "Generate generic behavioral questions" | Questions must be tailored to the specific role and company |
| "Company website has enough info" | Glassdoor, news, tech blogs, GitHub reveal what the website hides |
| "Skip reverse questions" | Reverse questions are the strongest signal of genuine interest |
| "One STAR story per category" | Interviewers probe with follow-ups; prepare 2-3 variants per competency |

## Workflow
### Phase 1: Context Gathering
**Entry:** User has provided company name, role title, or job posting.
**Actions:**
1. Extract company name, role title, and key requirements from job posting.
2. Research company: recent news (last 6 months), tech stack, culture, growth stage.
3. Identify interview format if known (phone, technical, behavioral, panel).
4. Gather user's relevant experience if provided.
**Exit:** Company profile, role requirements, user experience documented.

### Phase 2: Question Preparation
**Entry:** Phase 1 complete.
**Actions:**
1. Generate 5-8 behavioral questions mapped to the role's key competencies.
2. Generate 3-5 technical questions based on tech stack and seniority.
3. Draft STAR story skeletons for each behavioral question using user's experience.
4. Prepare 2-3 "weakness" answers: real weakness + mitigation + progress.
5. Generate 5-7 reverse questions that demonstrate research and evaluate fit.
**Exit:** Complete question bank with drafted answers.

### Phase 3: Story Refinement
**Entry:** Phase 2 complete.
**Actions:**
1. Replace vague language with concrete numbers in each STAR story.
2. Ensure every story uses "I" for actions, not "we."
3. Add a "Learning" line to each story.
4. Rank stories by relevance to this role. Prepare bridge phrases back to the posting.
**Exit:** Polished STAR stories ranked by relevance.

### Phase 4: Verification
**Entry:** All prior phases complete.
**Actions:**
1. Verify every STAR story maps to at least one job posting requirement.
2. Confirm reverse questions require insider knowledge (not answerable from website).
3. Check company research includes data from last 6 months. Validate JSON format.
**Exit:** All checks pass — report results to boss/user.

## Output Format
```json
{
  "skill": "interview-preparation",
  "status": "completed",
  "worker": "worker-id",
  "summary": "Prepared for Senior Backend Engineer at Stripe — 6 STAR stories, 12 questions, 7 reverse questions",
  "company_research": {"company": "Stripe", "recent_news": "Launched Billing v3 March 2026; opened Sydney office", "tech_stack": "Ruby, Go, React, AWS, K8s", "culture_signals": "Strong writing culture, high code review bar", "glassdoor_themes": "Intense but rewarding"},
  "findings": [
    {"item": "STAR: Led payment processing migration from monolith to microservices", "severity": "high", "detail": "SITUATION: Legacy monolith at 50K TPS hitting scaling limits. TASK: Owned migration plan. ACTION: I designed service boundary, built dual-write bridge, ran 3-week shadow traffic validation. RESULT: Zero-downtime, 40% latency reduction, 3x faster shipping. LEARNING: Start shadow traffic earlier."}
  ],
  "reverse_questions": ["What does the first 90 days look like?", "How does the team prioritize tech debt vs features?", "Biggest engineering challenge this year?"],
  "errors": [], "elapsed_seconds": 32.5
}
```
### Bad Example
```json
{"skill": "interview-preparation", "summary": "Prepared for interview", "findings": [{"item": "Tell me about yourself", "detail": "Talk about your background"}]}
```
Wrong: No company research, no STAR format, no specific answers, no reverse questions.

## Escalation Triggers
STOP and report to boss when:
- User asks to fabricate experience they don't have
- Role requires credentials you can't verify the user holds
- Company has no public information (stealth startup)
- User asks for help during a live interview

Report as: `{"status": "escalated", "reason": "...", "context": "...", "recommendation": "..."}`

## Success Criteria
- [ ] Company research includes data from last 6 months
- [ ] At least 5 behavioral questions with STAR-formatted answers
- [ ] Every STAR story uses "I" and includes quantified results
- [ ] At least 5 reverse questions requiring insider knowledge
- [ ] Weakness answers include real weakness + mitigation + progress
- [ ] All answers map to specific job posting requirements
- [ ] Output matches JSON format above
- [ ] Results reported to boss via structured output
