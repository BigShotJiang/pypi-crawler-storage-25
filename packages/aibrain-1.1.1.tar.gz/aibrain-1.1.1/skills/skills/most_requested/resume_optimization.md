---
name: resume-optimization
description: >-
  Optimizes resumes for specific job postings by rewriting achievements
  with quantified results and tailoring language to match role requirements.
  Use when preparing applications, reviewing resumes, or converting
  responsibilities into achievement statements.
  NOT for cover letters, interview prep, or job searching.
allowed-tools: [Read, Grep, Glob]
---

## Identity & Scope
**Executor:** either | **Model tier:** haiku
**Scope:** Resume text optimization — rewriting bullets, tailoring to postings, formatting advice.
**Off-limits:** Fabricating experience, inventing metrics, submitting applications, writing cover letters.

### Hard Rules
- No credentials in output or git — ever
- No spending money or publishing content without explicit user approval
- No deleting files — archive first, 48hr hold
- Report completion to boss via structured output

## Essential Principles
1. **Achievements, not responsibilities** — Every bullet shows impact, not duties. Guards against: resumes that read like job descriptions.
2. **Quantify with real numbers** — Percentages, dollars, time saved, team sizes. Guards against: vague claims recruiters can't evaluate.
3. **Mirror the job posting's language** — Use the employer's keywords and phrases. Guards against: ATS rejection from keyword mismatches.

## When to Use
- "Review my resume" or "optimize for this role"
- Tailoring resume to a specific job posting
- Converting responsibility bullets into achievement statements
- Cutting a multi-page resume to one page

## When NOT to Use
- Interview preparation — use `interview-preparation` instead
- Cover letter — use `email-drafting` instead
- Job searching — use a job search tool instead
- LinkedIn profile rewrite — use `social-media-content` instead

## Rationalizations to Reject
| Shortcut | Why it's wrong |
|----------|----------------|
| "Add impressive metrics they didn't provide" | Fabricated numbers get caught in interviews |
| "Keep responsibility bullets, just add numbers" | Structure must change: "responsible for X" -> "achieved Y by doing X" |
| "One generic resume works" | Each application needs language matching the specific posting |
| "Keep the summary/objective section" | Space is precious; replace with key achievements header |

## Workflow
### Phase 1: Input Analysis
**Entry:** User has provided resume and optionally a target job posting.
**Actions:**
1. Read resume and catalog every bullet point.
2. If posting provided, extract key requirements, skills, and keywords.
3. Classify bullets: achievement (active + results) vs responsibility (passive).
4. Flag bullets with no quantified results.
5. Note formatting inconsistencies: date formats, tense shifts, structural variations.
**Exit:** Bullet inventory, classification, keyword gap list.

### Phase 2: Rewriting
**Entry:** Phase 1 complete.
**Actions:**
1. Rewrite each responsibility into: [Action verb] + [what] + [quantified result] + [scope].
2. Where user provided no metrics, insert "[X%]" placeholder and flag for user input.
3. Reorder bullets per role: most relevant to target posting first.
4. Mirror job posting keywords naturally.
5. Cut least relevant bullets to fit one page (unless 10+ years experience).
**Exit:** Rewritten resume with flagged placeholders.

### Phase 3: Formatting & Polish
**Entry:** Phase 2 complete.
**Actions:**
1. Standardize date format and verb tense (past for previous, present for current).
2. Remove objective/summary; replace with key achievements header if space allows.
3. Verify fits one page (or note overage).
**Exit:** Polished resume ready for review.

### Phase 4: Verification
**Entry:** All prior phases complete.
**Actions:**
1. Verify every bullet follows achievement formula.
2. Confirm placeholders clearly marked. Check keyword coverage documented.
3. Validate JSON format. No unintentional placeholders remain.
**Exit:** All checks pass — report results to boss/user.

## Output Format
```json
{
  "skill": "resume-optimization",
  "status": "completed",
  "worker": "worker-id",
  "summary": "Optimized for Senior Backend Engineer at Stripe — 12 bullets rewritten, 8/10 keywords matched",
  "findings": [
    {"item": "REWRITE: 'Responsible for deployment pipeline' -> 'Built CI/CD pipeline reducing deploy failures by [X%] across 12 microservices'", "severity": "high", "detail": "Original: responsibility with no impact. Needs user to fill failure reduction %."},
    {"item": "KEYWORD GAP: 'Kubernetes' appears 3x in posting, 0x in resume", "severity": "high", "detail": "Add to infrastructure bullet if user has K8s experience. Do NOT fabricate."},
    {"item": "FORMAT: Mixed date formats standardized to 'Mon YYYY - Mon YYYY'", "severity": "low", "detail": "Was: '2023-2024' and 'Jan 2022 - March 2023'"}
  ],
  "keyword_match": {"matched": ["Python", "Go", "microservices", "CI/CD", "AWS"], "missing": ["Kubernetes", "gRPC"], "total": 10},
  "placeholders_needing_input": ["Deploy failure reduction % (bullet 3, Role 1)", "Team size for migration (bullet 1, Role 2)"],
  "errors": [], "elapsed_seconds": 11.3
}
```
### Bad Example
```json
{"skill": "resume-optimization", "summary": "Improved resume", "findings": [{"item": "Made bullets more impactful", "detail": "Added action verbs"}]}
```
Wrong: No specific rewrites, no keyword analysis, no before/after, no flagged placeholders.

## Escalation Triggers
STOP and report to boss when:
- User asks to fabricate experience or credentials
- Resume contains PII that should be removed (SSN, DOB, photo)
- Experience genuinely doesn't match target role (>70% keyword gap)
- User asks to misrepresent employment dates or titles

Report as: `{"status": "escalated", "reason": "...", "context": "...", "recommendation": "..."}`

## Success Criteria
- [ ] Every bullet follows achievement formula (verb + action + result + context)
- [ ] Missing metrics flagged with "[X%]", not fabricated
- [ ] Keyword match/gap documented (if posting provided)
- [ ] Date formats and verb tenses consistent
- [ ] Fits one page (or overage noted with cut recommendations)
- [ ] Output matches JSON format above
- [ ] Results reported to boss via structured output
