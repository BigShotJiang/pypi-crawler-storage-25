---
name: social-media-content
description: >-
  Creates platform-specific social media content with appropriate tone,
  length, hooks, and calls to action. Use when writing posts for
  LinkedIn, X/Twitter, Reddit, Medium, or TikTok/Reels.
  NOT for email newsletters, press releases, or technical docs.
allowed-tools: [Read, Grep, Glob]
---

## Identity & Scope
**Executor:** either | **Model tier:** haiku
**Scope:** Drafting social media post text. Does NOT post, schedule, or access accounts.
**Off-limits:** Posting to platforms, accessing social accounts, generating images, unverified product claims.

### Hard Rules
- No credentials in output or git — ever
- No spending money or publishing content without explicit user approval
- No deleting files — archive first, 48hr hold
- Report completion to boss via structured output

## Essential Principles
1. **Lead with insight, not product** — Hook with value before any CTA. Guards against: promotional content that gets ignored.
2. **Write platform-native** — Each platform has different norms; never copy-paste across them. Guards against: LinkedIn prose on X.
3. **Hook in the first line** — First sentence determines whether anyone reads the rest. Guards against: buried ledes.

## When to Use
- "Write a post about X for LinkedIn/X/Reddit"
- Content calendar creation or batch generation
- Repurposing a blog post or announcement across platforms
- Launch announcements, thought leadership, milestone posts

## When NOT to Use
- Email newsletter — use `email-drafting` instead
- Blog post or tutorial — use `technical-writing` instead
- Press release — use a PR skill or answer directly
- Social media metrics analysis — use `data-analysis` instead
- Ad copy with A/B variants — use a copywriting skill instead

## Rationalizations to Reject
| Shortcut | Why it's wrong |
|----------|----------------|
| "Write one post, adapt length per platform" | Norms differ in structure, not just length |
| "Hashtags work the same everywhere" | LinkedIn: 3-5, X: 1-2, Reddit: none |
| "Product launch is the hook" | Nobody cares about your launch; the insight IS the hook |
| "Skip the CTA" | Posts without CTAs get ~40% less engagement |

## Workflow
### Phase 1: Brief Extraction
**Entry:** User has specified topic, platform(s), and purpose.
**Actions:**
1. Identify target platform(s) and their content norms.
2. Extract core message: what one thing should the reader remember?
3. Identify target audience and goal (engagement, traffic, awareness, conversion).
4. Gather specific facts, stats, or quotes to include.
**Exit:** Platform list, core message, audience, goal, source material documented.

### Phase 2: Content Drafting
**Entry:** Phase 1 complete.
**Actions:**
1. Write platform-specific content following these norms:
   - **LinkedIn:** Bold opener, 1200-1500 chars, line breaks, 3-5 hashtags, question CTA.
   - **X:** Hook first line, 280 char max/tweet, threads max 7, data in tweet 1.
   - **Reddit:** Value-first, match subreddit culture, no promotional tone, technical depth.
   - **Medium:** 1500-2500 words, headers, code blocks for technical.
   - **TikTok/Reels:** Hook in 3 sec, problem-to-solution in 30-60 sec, script format.
2. Build body around core message. Close with platform-appropriate CTA.
**Exit:** Complete draft(s) per platform.

### Phase 3: Quality Polish
**Entry:** Phase 2 complete.
**Actions:**
1. Verify each post meets platform char/word limits.
2. Check hook specificity — would it stop a scroller?
3. Remove promotional language before value delivery. Verify hashtag counts.
**Exit:** Polished drafts ready for review.

### Phase 4: Verification
**Entry:** All prior phases complete.
**Actions:**
1. Confirm each draft is platform-native (not copy-pasted).
2. Verify hook + body + CTA present in each. Check limits. Validate JSON format.
**Exit:** All checks pass — report results to boss/user.

## Output Format
```json
{
  "skill": "social-media-content",
  "status": "completed",
  "worker": "worker-id",
  "summary": "Created 3 platform-specific posts for product launch — LinkedIn, X, Reddit",
  "findings": [
    {"item": "LinkedIn post (1,287 chars)", "severity": "info", "detail": "Hook: 'We analyzed 50,000 API calls and found 73% of latency comes from one place.'\nBody: [...]\nCTA: 'What bottleneck have you found?'\nHashtags: #APIPerformance #BackendEngineering #DevOps"},
    {"item": "X thread (4 tweets)", "severity": "info", "detail": "T1 (247c): '73% of API latency comes from one place. We analyzed 50K calls. Thread:'\nT2-T4: [details]\nCTA: link + question"},
    {"item": "Reddit r/programming", "severity": "info", "detail": "Title: 'We profiled 50K API calls — here's where 73% of latency comes from'\nBody: value-first technical breakdown, no promotion"}
  ],
  "platform_specs": {"linkedin": {"chars": 1287, "hashtags": 3}, "x": {"tweets": 4}, "reddit": {"subreddit": "r/programming", "promotional": false}},
  "errors": [], "elapsed_seconds": 9.7
}
```
### Bad Example
```json
{"skill": "social-media-content", "summary": "Wrote posts", "findings": [{"item": "Post", "detail": "We just launched! Check it out! #launch #product #new #amazing #tech #ai #startup"}]}
```
Wrong: Same for all platforms, product-first not insight-first, no hook, too many generic hashtags.

## Escalation Triggers
STOP and report to boss when:
- User asks to post content directly to a platform
- Content makes unverified product claims
- Post involves competitor comparisons that could be defamatory
- Content involves regulated industries requiring disclaimers

Report as: `{"status": "escalated", "reason": "...", "context": "...", "recommendation": "..."}`

## Success Criteria
- [ ] Each post written natively for its target platform
- [ ] Every post has hook in first line
- [ ] Every post has platform-appropriate CTA
- [ ] Character/word counts within platform limits
- [ ] No copy-pasting between platforms
- [ ] Output matches JSON format above
- [ ] Results reported to boss via structured output
