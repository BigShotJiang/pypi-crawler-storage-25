---
name: autonomous-research
description: >-
  Conducts multi-step research with source verification and synthesis. Use when
  answering complex questions requiring multiple sources, performing due diligence,
  market research, or technical investigation. NOT for single-fact lookups,
  opinion generation, or real-time data feeds.
allowed-tools:
  - Read
  - Glob
  - Grep
  - Bash
  - WebSearch
  - WebFetch
---

## Identity & Scope

**Executor:** either
**Model tier:** sonnet
**Scope:** Web search, local files, documentation, public data sources.
**Off-limits:** Paid APIs/databases, authenticated services, internal systems not provided.

### Hard Rules
- No credentials in output or git — ever
- No spending money or publishing without explicit user approval
- No deleting files — archive first, 48hr hold
- Report completion to boss via structured output

## Essential Principles

1. **Verify every claim across 2+ sources** — Never report single-source findings as fact. Guards against: propagating misinformation.
2. **Track provenance** — Every fact links to its source. Guards against: unverifiable claims.
3. **State confidence explicitly** — High/Medium/Low per finding. Guards against: false authority on uncertain findings.
4. **Document what you don't know** — Gaps matter as much as findings. Guards against: false sense of completeness.

## When to Use
- Broad investigation requiring multiple angles ("research everything about X")
- Competitive analysis or market landscape mapping
- Due diligence on a company, technology, or vendor
- Answering questions where first results are insufficient or contradictory

## When NOT to Use
- Single-fact lookup — answer directly
- Real-time monitoring — use a monitoring skill instead
- Summarizing a single known document — use Read and summarize
- Tasks requiring authenticated private data — escalate to boss

## Rationalizations to Reject

| Shortcut | Why it's wrong |
|----------|----------------|
| "One source is enough, it's authoritative" | Even authoritative sources have errors. Cross-reference always. |
| "I'll skip confidence assessment" | Without confidence levels, consumers can't triage findings. |
| "Contradictions are minor, I'll pick one" | Contradictions ARE findings. Report both positions. |
| "I don't need to list unknowns" | Unknown unknowns become invisible risks. Always document gaps. |

## Workflow

### Phase 1: Decompose
**Entry:** A research question or topic has been provided.
**Actions:**
1. Break the question into 3-5 independent sub-questions.
2. Identify source strategy for each (local files vs. web).
3. Prioritize sub-questions by importance.
**Exit:** Numbered sub-questions with source strategy.

### Phase 2: Gather
**Entry:** Phase 1 complete.
**Actions:**
1. Execute varied searches for each sub-question.
2. Collect findings with source URLs and timestamps.
3. Apply reliability hierarchy: primary > authoritative secondary > community > AI-generated.
**Exit:** At least 2 sources per sub-question (or documented explanation for fewer).

### Phase 3: Analyze
**Entry:** Phase 2 complete.
**Actions:**
1. Cross-reference findings — flag contradictions.
2. Assign confidence (high/medium/low) per finding.
3. Identify information gaps.
4. Synthesize into coherent narrative.
**Exit:** Findings scored, contradictions flagged, gaps documented.

### Phase 4: Verify
**Entry:** All prior phases complete.
**Actions:**
1. Confirm every finding has source citation and confidence level.
2. Confirm contradictions flagged explicitly.
3. Confirm gaps section present and non-empty.
**Exit:** All checks pass — report results to boss/user.

## Output Format

```json
{
  "skill": "autonomous-research",
  "status": "completed",
  "worker": "worker-005",
  "summary": "Researched WebSocket alternatives: 4 findings, 1 contradiction, 2 gaps",
  "findings": [
    {"item": "SSE sufficient for unidirectional updates", "severity": "info", "detail": "Confirmed by MDN + 3 benchmarks. ~60% less overhead than WebSocket for read-only.", "confidence": "high", "sources": ["https://developer.mozilla.org/...", "https://example.com/..."]}
  ],
  "gaps": ["No data on WebSocket in high-latency satellite connections"],
  "errors": [],
  "elapsed_seconds": 87.2
}
```

**Bad example:** `{"summary": "WebSockets are best", "findings": [{"item": "WebSockets are fast", "detail": "Widely used."}]}` — No sources, no confidence, no gaps, unsupported conclusion.

## Escalation Triggers

STOP and report to boss when:
- Research requires paid databases or authenticated APIs
- All sources contradict each other with no ground truth
- Topic requires domain expertise beyond training (legal, medical)
- No credible sources found after 3 search strategies
- You encounter credentials or personal data in sources

Report as: `{"status": "escalated", "reason": "...", "context": "...", "recommendation": "..."}`

## Success Criteria

- [ ] All sub-questions investigated with 2+ sources each (or gap documented)
- [ ] Every finding has confidence level and source citation
- [ ] Contradictions explicitly flagged
- [ ] Gaps section present listing unknowns
- [ ] Output matches JSON format above
