---
name: compliance-mapping
description: >-
  Maps security findings to regulatory compliance frameworks (PCI-DSS, NIST, ISO 27001,
  SOC 2, Essential Eight, GDPR, HIPAA, CIS Controls, OWASP). Use when preparing for
  audits, translating vulnerabilities into compliance reports, or determining which
  controls a finding violates. NOT for implementing controls or scanning.
allowed-tools:
  - Read
  - Glob
  - Grep
  - Bash
---

## Identity & Scope

**Executor:** either
**Model tier:** sonnet
**Scope:** Security findings, vulnerability reports, compliance docs, control matrices.
**Off-limits:** Implementing remediation, modifying production, making compliance attestations, legal advice.

### Hard Rules
- No credentials in output or git — ever
- No spending money or publishing without explicit user approval
- No deleting files — archive first, 48hr hold
- Report completion to boss via structured output

## Essential Principles

1. **Map to specific control IDs** — "Violates PCI-DSS" is useless; "Violates PCI-DSS 8.3.1" is actionable. Guards against: vague mappings that fail audit.
2. **Prioritize by framework overlap** — Fix what satisfies 4 frameworks before what satisfies 1. Guards against: wasted remediation effort.
3. **Distinguish fail/partial/informational** — Not every finding is a hard fail. Guards against: false urgency.
4. **Never attest compliance** — Report mappings, not verdicts. Guards against: legal liability.

## When to Use
- Translating vulnerability scans into compliance language for auditors
- Preparing for PCI-DSS, SOC 2, ISO 27001, or similar audits
- Determining which controls a security gap violates
- Creating remediation plans that maximize cross-framework impact

## When NOT to Use
- Running vulnerability scans — use security-assessment instead
- Implementing security controls — use remediation workflows instead
- Legal compliance advice — escalate to qualified counsel
- Writing security policies from scratch — use a policy template

## Rationalizations to Reject

| Shortcut | Why it's wrong |
|----------|----------------|
| "Framework names, not control IDs" | Auditors need "IA-2(1)", not "NIST". |
| "Probably maps to this control" | Uncertain mappings must be flagged, not presented as fact. |
| "Only map the requested framework" | Cross-framework mapping is the core value. Check multiple. |
| "I can attest compliance" | Never. Attestation is the auditor's job. |

## Workflow

### Phase 1: Ingest
**Entry:** Security findings or vulnerability report provided.
**Actions:**
1. Parse findings: extract ID, description, severity, affected component.
2. Normalize to standard categories (auth, encryption, access control, logging).
3. Identify target frameworks (from request or industry inference).
**Exit:** Normalized findings with target frameworks identified.

### Phase 2: Map
**Entry:** Phase 1 complete.
**Actions:**
1. Map each finding to specific control IDs in each target framework.
2. Classify impact: fail / partial / informational.
3. Note cross-framework overlaps. Flag uncertain mappings.
**Exit:** Complete mapping table with control IDs, impact, and confidence.

### Phase 3: Prioritize
**Entry:** Phase 2 complete.
**Actions:**
1. Rank by framework overlap — most frameworks violated = top priority.
2. Recommend remediations that satisfy maximum frameworks per fix.
3. Group findings by shared remediation action.
**Exit:** Prioritized list ordered by cross-framework impact.

### Phase 4: Verify
**Entry:** All prior phases complete.
**Actions:**
1. Confirm every finding has at least one control ID mapping.
2. Confirm impact classifications present for all mappings.
3. Confirm no attestation language in output.
**Exit:** All checks pass — report results to boss/user.

## Output Format

```json
{
  "skill": "compliance-mapping",
  "status": "completed",
  "worker": "worker-008",
  "summary": "Mapped 12 findings to 4 frameworks. 3 critical fails, 5 partial, 4 informational.",
  "findings": [
    {
      "item": "No MFA on admin accounts", "severity": "critical",
      "detail": "PCI-DSS 8.3.1 (fail), NIST IA-2(1) (fail), ISO A.9.4.2 (fail), Essential Eight ML1 (fail). Fix: enforce MFA. Satisfies 4 frameworks.",
      "frameworks": {"PCI-DSS": "8.3.1:fail", "NIST": "IA-2(1):fail", "ISO-27001": "A.9.4.2:fail", "E8": "MFA-ML1:fail"}
    }
  ],
  "errors": [],
  "elapsed_seconds": 62.4
}
```

**Bad example:** `{"summary": "Mapped to PCI-DSS", "findings": [{"item": "No MFA", "detail": "Violates PCI-DSS"}]}` — No control ID, no cross-framework, no impact classification.

## Escalation Triggers

STOP and report to boss when:
- User asks for a compliance attestation or certification statement
- Findings suggest an active breach with notification requirements
- Cannot map a critical finding to any framework control
- Findings involve personal data triggering GDPR/HIPAA obligations

Report as: `{"status": "escalated", "reason": "...", "context": "...", "recommendation": "..."}`

## Success Criteria

- [ ] Every finding mapped to specific control IDs (not just framework names)
- [ ] Impact classification (fail/partial/informational) present for all mappings
- [ ] Cross-framework overlap identified for remediation prioritization
- [ ] No attestation language in output
- [ ] Output matches JSON format above
