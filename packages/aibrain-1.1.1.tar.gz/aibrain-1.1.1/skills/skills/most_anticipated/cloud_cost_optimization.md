---
name: cloud-cost-optimization
description: >-
  Analyzes cloud infrastructure for cost reduction without sacrificing performance.
  Use when reviewing monthly cloud bills, investigating cost spikes, right-sizing
  instances, or auditing unused resources on AWS/GCP/Azure.
  NOT for initial provisioning or architecture design.
allowed-tools:
  - Read
  - Glob
  - Grep
  - Bash
---

## Identity & Scope

**Executor:** either
**Model tier:** haiku
**Scope:** Cloud config files (Terraform, CloudFormation, Pulumi, docker-compose), billing exports, resource inventories.
**Off-limits:** Live infrastructure changes, modifying cloud resources, billing API calls without approval.

### Hard Rules
- No credentials in output or git — ever
- No spending money or publishing without explicit user approval
- No deleting files — archive first, 48hr hold
- Report completion to boss via structured output

## Essential Principles

1. **Analyze before recommending** — Review utilization data, not just resource lists. Guards against: downsizes that cause outages.
2. **Quantify every recommendation in dollars** — "Switch to spot" means nothing without savings estimate. Guards against: unprioritizable advice.
3. **Flag reliability trade-offs** — Spot instances save money but interrupt. Say so. Guards against: hidden risk from cost cuts.

## When to Use
- Monthly cloud bill review reveals cost increase
- "Why is our cloud bill so high?"
- Auditing for unused or orphaned resources
- Right-sizing instances based on utilization
- Evaluating reserved instance commitments

## When NOT to Use
- Designing new infrastructure — use an architecture skill instead
- Debugging performance issues — use performance-optimization instead
- Security audit of cloud config — use security-assessment instead
- Real-time cost alerting — use monitoring systems instead

## Rationalizations to Reject

| Shortcut | Why it's wrong |
|----------|----------------|
| "Just delete all unused resources" | Some 'unused' resources are DR or standby. Verify purpose first. |
| "Switch everything to spot" | Stateful workloads can't tolerate interruption. |
| "Savings estimates don't need precision" | Imprecise estimates cause wrong prioritization. |
| "Reserved instances always save money" | Only with predictable utilization. Over-committing wastes more. |

## Workflow

### Phase 1: Inventory
**Entry:** Cloud config files or billing data identified.
**Actions:**
1. Scan for IaC files (Terraform, CloudFormation, Pulumi, docker-compose).
2. Catalog all resources: compute, storage, database, network.
3. Classify by environment (prod/dev/staging).
**Exit:** Complete resource inventory with environment tags.

### Phase 2: Analyze
**Entry:** Phase 1 complete.
**Actions:**
1. Map resources to pricing tiers. Identify top 10 most expensive.
2. Find unused resources: unattached volumes, idle LBs, stopped instances with storage, orphaned snapshots.
3. Find over-provisioned resources: <20% avg CPU or <30% memory utilization.
4. Check for missing optimizations: no auto-scaling, no lifecycle policies, no reserved pricing.
**Exit:** Prioritized cost issues with estimated monthly waste per item.

### Phase 3: Recommend
**Entry:** Phase 2 complete.
**Actions:**
1. Generate specific recommendations ordered by savings potential.
2. Estimate dollar savings (monthly + annual) per recommendation.
3. Flag risk level (safe/moderate/risky) and complexity (quick win vs. strategic).
**Exit:** Recommendations with dollars, risk, and complexity.

### Phase 4: Verify
**Entry:** All prior phases complete.
**Actions:**
1. Confirm every recommendation has a dollar estimate and risk level.
2. Confirm no recommendations require live changes (report only).
3. Validate output matches required JSON structure.
**Exit:** All checks pass — report results to boss/user.

## Output Format

```json
{
  "skill": "cloud-cost-optimization",
  "status": "completed",
  "worker": "worker-003",
  "summary": "Found $2,340/mo savings across 8 recommendations. 3 quick wins, 5 strategic.",
  "findings": [
    {"item": "Delete 12 unattached EBS volumes (us-east-1)", "severity": "high", "detail": "2.4TB unattached gp3. Est. $192/mo. Risk: safe."},
    {"item": "Right-size prod-api-01 m5.2xl->m5.large", "severity": "medium", "detail": "Avg CPU 8%. Est. $540/mo savings. Risk: moderate — load test first."}
  ],
  "errors": [],
  "elapsed_seconds": 45.1
}
```

**Bad example:** `{"summary": "Several savings found", "findings": [{"item": "Use smaller instances", "detail": "Some are too big."}]}` — No dollars, no names, no risk. Not actionable.

## Escalation Triggers

STOP and report to boss when:
- Recommendations require live API calls to cloud providers
- You find credentials in configuration files
- A recommendation could cause data loss
- Billing data doesn't match IaC (shadow IT)
- Total savings exceed 50% of spend (likely missing context)

Report as: `{"status": "escalated", "reason": "...", "context": "...", "recommendation": "..."}`

## Success Criteria

- [ ] Complete resource inventory compiled
- [ ] Every recommendation has dollar estimate and risk level
- [ ] Quick wins separated from strategic changes
- [ ] No recommendations require direct infrastructure changes
- [ ] Output matches JSON format above
