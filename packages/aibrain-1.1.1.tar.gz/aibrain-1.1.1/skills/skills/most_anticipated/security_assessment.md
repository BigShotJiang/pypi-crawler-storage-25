---
name: security-assessment
description: >-
  Performs systematic security vulnerability assessment using OWASP Top 10, data flow
  analysis, and dependency auditing. Use when reviewing code for security issues,
  preparing for deployment, or auditing attack surfaces. NOT for compliance mapping,
  incident response, or threat modeling of future architectures.
allowed-tools:
  - Read
  - Glob
  - Grep
  - Bash
---

## Identity & Scope

**Executor:** either
**Model tier:** opus
**Scope:** Source code, config files, dependency manifests, API definitions, infrastructure-as-code.
**Off-limits:** Exploiting vulns against live systems without approval, modifying production, accessing out-of-scope systems.

### Hard Rules
- No credentials in output or git — ever
- No spending money or publishing without explicit user approval
- No deleting files — archive first, 48hr hold
- NEVER include actual credential values — reference location only
- Report completion to boss via structured output

## Essential Principles

1. **Map attack surface first** — All entry points, trust boundaries, data flows before code review. Guards against: missing entire vulnerability classes.
2. **Check every OWASP Top 10 systematically** — Use the checklist, not intuition. Guards against: tunnel vision on familiar vuln types.
3. **Trace data flows end-to-end** — Follow input from entry to storage/output. Guards against: missed sanitization gaps.
4. **Verify with evidence** — Every vuln needs code location, input vector, impact. Guards against: false positives wasting effort.
5. **Check dependencies** — Known CVEs in your tree are real vulnerabilities. Guards against: ignoring the #1 source of production vulns.

## When to Use
- Code security review before merge or deployment
- "Check this for security issues" — explicit audit request
- New API endpoint or service being deployed
- Periodic security audit of existing codebase

## When NOT to Use
- Compliance framework mapping — use compliance-mapping instead
- Active incident — use incident-response instead
- Future architecture threats — use threat-modeling instead
- Fixing vulnerabilities — report them, then use remediation workflows

## Rationalizations to Reject

| Shortcut | Why it's wrong |
|----------|----------------|
| "Framework handles sanitization" | Frameworks have bypasses. Verify at every boundary. |
| "Internal service, auth doesn't matter" | Internal services get compromised. Zero-trust. |
| "Dependencies are probably fine" | Dependencies are #1 source of production CVEs. |
| "Found 3 issues, that's enough" | Incomplete assessments create false confidence. Check every category. |
| "Low severity not worth reporting" | Low issues chain into high exploits. Report everything. |

## Workflow

### Phase 1: Attack Surface
**Entry:** Target codebase or system identified.
**Actions:**
1. Identify all entry points: API endpoints, forms, file uploads, WebSocket, CLI args, env vars.
2. Map trust boundaries and auth mechanisms.
3. Catalog data stores and where sensitive data lives.
**Exit:** Attack surface map with entry points, boundaries, stores, auth.

### Phase 2: Systematic Check
**Entry:** Phase 1 complete.
**Actions:**
1. Check each OWASP Top 10: A01 Broken Access Control, A02 Crypto Failures, A03 Injection, A04 Insecure Design, A05 Misconfiguration, A06 Vulnerable Components, A07 Auth Failures, A08 Data Integrity, A09 Logging Failures, A10 SSRF.
2. Trace data flows for each input type: entry -> validation -> processing -> storage/output.
3. Check for hardcoded secrets in source and config.
4. Audit dependency manifests for known CVEs.
**Exit:** Findings with code locations, input vectors, impact descriptions.

### Phase 3: Classify
**Entry:** Phase 2 complete.
**Actions:**
1. Assign CVSS severity: Critical (9-10: RCE, auth bypass), High (7-8.9: privesc, stored XSS), Medium (4-6.9: reflected XSS, CSRF), Low (0.1-3.9: missing headers).
2. Write remediation for each finding.
3. Identify finding chains (low+low = high).
**Exit:** All findings classified with severity, remediation, chain analysis.

### Phase 4: Verify
**Entry:** All prior phases complete.
**Actions:**
1. Confirm every OWASP category checked (findings or "checked, clean").
2. Confirm every finding has: location, severity, vector, impact, remediation.
3. Confirm no credential values in output. Validate JSON structure.
**Exit:** All checks pass — report results to boss/user.

## Output Format

```json
{
  "skill": "security-assessment",
  "status": "completed",
  "worker": "worker-004",
  "summary": "14 endpoints assessed. 2 critical, 3 high, 5 medium, 4 low. 1 dependency CVE.",
  "findings": [
    {"item": "SQLi in /api/users/search", "severity": "critical", "detail": "String interpolation at users.py:45. Param 'q' unsanitized. CVSS 9.8.", "location": "api/routes/users.py:45", "category": "A03", "remediation": "Use parameterized queries."},
    {"item": "IDOR in /api/orders/{id}", "severity": "high", "detail": "No ownership check. User A reads User B orders. CVSS 7.5.", "location": "api/routes/orders.py:82", "category": "A01", "remediation": "Verify order.user_id == auth user."}
  ],
  "coverage": {"owasp_checked": ["A01","A02","A03","A04","A05","A06","A07","A08","A09","A10"], "endpoints": 14, "deps_checked": true},
  "errors": [],
  "elapsed_seconds": 124.7
}
```

**Bad example:** `{"summary": "Found some issues", "findings": [{"item": "Possible SQLi", "detail": "Might be somewhere in search."}]}` — No location, no CVSS, no category, not verified, no coverage.

## Escalation Triggers

STOP and report to boss when:
- Actively exploited vulnerability discovered (evidence of compromise)
- Credentials or secrets found in codebase
- Critical vuln requires immediate production changes
- Scope requires testing against live systems
- Dependency has known exploit with no patch

Report as: `{"status": "escalated", "reason": "...", "context": "...", "recommendation": "..."}`

## Success Criteria

- [ ] All OWASP Top 10 categories checked (findings or "clean")
- [ ] Every finding has: location, CVSS severity, category, remediation
- [ ] Data flow tracing performed for all inputs
- [ ] Dependency audit performed
- [ ] No credential values in output
- [ ] Finding chains identified
- [ ] Output matches JSON format above
