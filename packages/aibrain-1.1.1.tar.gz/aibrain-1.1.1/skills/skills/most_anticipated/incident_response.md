---
name: incident-response
description: >-
  Provides structured incident response for security breaches and system outages.
  Use when a system is down, a breach is detected, an active attack is underway,
  or a blameless postmortem is needed. NOT for routine maintenance, planned
  downtime, or non-urgent bug reports.
allowed-tools:
  - Read
  - Glob
  - Grep
  - Bash
---

## Identity & Scope

**Executor:** either
**Model tier:** opus
**Scope:** Log files, system configs, monitoring data, network captures, incident timelines.
**Off-limits:** Deleting evidence, modifying production without approval, external communications, legal determinations.

### Hard Rules
- No credentials in output or git — ever
- No spending money or publishing without explicit user approval
- No deleting files — archive first, 48hr hold
- PRESERVE ALL EVIDENCE — never overwrite or truncate logs
- Report completion to boss via structured output

## Essential Principles

1. **Contain before investigating** — Stop bleeding first, then analyze. Guards against: extended damage during analysis.
2. **Preserve evidence before acting** — Copy logs before remediation alters state. Guards against: destroyed forensics.
3. **Facts, never speculation** — Report what you know and don't know. Guards against: panic from unverified claims.
4. **Fix root cause, not symptoms** — Restarting a service is not remediation. Guards against: recurring incidents.

## When to Use
- Production system down with user impact
- Security breach — unauthorized access or data exfiltration
- Active attack — DDoS, credential stuffing, exploitation
- Blameless postmortem needed within 48 hours

## When NOT to Use
- Planned maintenance — use a runbook instead
- Routine security scanning — use security-assessment instead
- Performance issues without security implications — use performance-optimization instead
- Compliance reporting — use compliance-mapping instead

## Rationalizations to Reject

| Shortcut | Why it's wrong |
|----------|----------------|
| "Investigate first, then contain" | Every minute without containment is ongoing damage. |
| "Restart the service to fix it" | Destroys in-memory evidence, may not fix root cause. |
| "I think it might be X" in comms | Speculation causes panic. Facts only. |
| "Postmortem can wait" | Context fades in 48 hours. Write it now. |

## Workflow

### Phase 1: Detect & Classify
**Entry:** Incident or anomaly reported.
**Actions:**
1. Gather facts: what, when, which systems.
2. Classify: SEV-1 (down/breach, immediate) | SEV-2 (degraded, <1hr) | SEV-3 (minor, <4hr) | SEV-4 (cosmetic, next day).
3. Estimate blast radius. Start timeline.
**Exit:** Severity assigned, timeline started.

### Phase 2: Contain
**Entry:** Phase 1 complete.
**Actions:**
1. Preserve evidence: copy logs, snapshot disk.
2. Execute containment (isolate, revoke creds, block IP) or recommend if approval needed.
3. Verify damage has stopped. Log all actions with timestamps.
**Exit:** Damage stopped, evidence preserved.

### Phase 3: Investigate
**Entry:** Phase 2 complete.
**Actions:**
1. Analyze evidence to build attack/failure chain.
2. Identify root cause and full impact scope.
**Exit:** Root cause identified, impact determined.

### Phase 4: Remediate & Recover
**Entry:** Phase 3 complete.
**Actions:**
1. Address root cause. Execute/recommend recovery.
2. Verify services functioning normally.
**Exit:** Root cause fixed, services restored.

### Phase 5: Verify
**Entry:** All prior phases complete.
**Actions:**
1. Compile complete timeline. Draft blameless postmortem with action items.
2. Validate output matches required JSON structure.
**Exit:** Postmortem complete — report to boss/user.

## Output Format

```json
{
  "skill": "incident-response",
  "status": "completed",
  "worker": "worker-001",
  "summary": "SEV-2: unauthorized API access via leaked token. Contained 12min, root cause fixed.",
  "findings": [
    {"item": "Leaked API token in public repo", "severity": "critical", "detail": "Attacker read 2,340 records 14:02-14:14 UTC."},
    {"item": "Root cause: no token rotation", "severity": "high", "detail": "Tokens have no expiration. Compromised token was 14 months old."}
  ],
  "timeline": [
    {"time": "14:02 UTC", "event": "First unauthorized call"},
    {"time": "14:14 UTC", "event": "Token revoked, IP blocked"},
    {"time": "14:30 UTC", "event": "New token issued, restored"}
  ],
  "errors": [],
  "elapsed_seconds": 156.3
}
```

**Bad example:** `{"summary": "Fixed the breach", "findings": [{"item": "Revoked token"}]}` — No timeline, root cause, blast radius, or postmortem.

## Escalation Triggers

STOP and report to boss when:
- Evidence of personal/customer data exfiltration
- Containment not working after 3 attempts
- Must shut down production services
- Insider threat discovered or law enforcement may be needed
- External communication required (customers, regulators)

Report as: `{"status": "escalated", "reason": "...", "context": "...", "recommendation": "..."}`

## Success Criteria

- [ ] Severity assigned and justified
- [ ] Containment actions documented with timestamps
- [ ] Root cause identified (not just symptoms)
- [ ] Full impact scope determined
- [ ] Evidence preserved and referenced
- [ ] Timeline covers all phases
- [ ] Postmortem drafted with action items
- [ ] Output matches JSON format above
