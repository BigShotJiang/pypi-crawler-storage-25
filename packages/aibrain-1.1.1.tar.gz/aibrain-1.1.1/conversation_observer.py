#!/usr/bin/env python3
"""
conversation_observer.py — Automatic Memory Extraction

Receives conversation transcripts and automatically extracts memories,
facts, preferences, decisions, and skill episodes. The system learns
without the user or LLM explicitly calling memory_store.

Works as:
1. MCP tool (memory_ingest) — called at session end with transcript
2. File watcher — monitors a transcript directory
3. API endpoint — POST /api/memory/ingest

Usage:
    from conversation_observer import ConversationObserver
    observer = ConversationObserver(db_path)
    result = observer.ingest_transcript(transcript_text, session_id="...")
"""

import hashlib
import json
import re
import sqlite3
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional


# ---------------------------------------------------------------------------
# Extraction patterns — what to automatically remember
# ---------------------------------------------------------------------------

# Decision patterns — "we decided", "the decision is", "let's go with"
_DECISION_PATTERNS = [
    re.compile(r"(?:we|i)\s+(?:decided|chose|picked|went with|selected|agreed)\s+(?:to\s+)?(.{10,150})", re.IGNORECASE),
    re.compile(r"(?:the\s+)?decision\s+(?:is|was)\s+(?:to\s+)?(.{10,150})", re.IGNORECASE),
    re.compile(r"let'?s\s+go\s+with\s+(.{5,100})", re.IGNORECASE),
    re.compile(r"(?:final\s+)?(?:answer|choice|plan)\s*:\s*(.{10,150})", re.IGNORECASE),
]

# Preference patterns — "I prefer", "I like", "I hate"
_PREFERENCE_PATTERNS = [
    re.compile(r"(?:i|we)\s+(?:prefer|like|love|enjoy|always use)\s+(.{3,100})", re.IGNORECASE),
    re.compile(r"(?:i|we)\s+(?:hate|dislike|avoid|never use|don't like)\s+(.{3,100})", re.IGNORECASE),
    re.compile(r"(?:my|our)\s+(?:favorite|preferred|go-to)\s+\w+\s+(?:is|are)\s+(.{3,80})", re.IGNORECASE),
]

# Context patterns — project names, technologies, people
_CONTEXT_PATTERNS = [
    re.compile(r"(?:working on|building|developing)\s+(.{5,80})", re.IGNORECASE),
    re.compile(r"(?:the|my|our)\s+project\s+(?:is\s+)?(?:called\s+)?(.{3,60})", re.IGNORECASE),
    re.compile(r"(?:using|switched to|migrated to)\s+(.{3,60})", re.IGNORECASE),
]

# Feedback patterns — corrections the user gave to the agent
_FEEDBACK_PATTERNS = [
    re.compile(r"(?:no,?\s+)?(?:that's\s+)?(?:wrong|incorrect|not right|not what i)", re.IGNORECASE),
    re.compile(r"(?:actually|correction|to clarify|let me correct)", re.IGNORECASE),
    re.compile(r"(?:don't|never|stop|quit)\s+(?:do|doing|say|suggesting)\s+(.{5,80})", re.IGNORECASE),
    re.compile(r"(?:always|remember to|make sure you|next time)\s+(.{5,80})", re.IGNORECASE),
]

# Task completion patterns — what was accomplished
_TASK_PATTERNS = [
    re.compile(r"(?:done|finished|completed|shipped|deployed|submitted|merged|published)\s+(.{5,100})", re.IGNORECASE),
    re.compile(r"(?:successfully|finally)\s+(.{5,100})", re.IGNORECASE),
]


def _split_into_turns(transcript: str) -> list[dict]:
    """Split a conversation transcript into turns.

    Handles common formats:
    - "User: ...\nAssistant: ..."
    - "Human: ...\nClaude: ..."
    - Generic paragraph splitting
    """
    turns = []
    current_role = "unknown"
    current_text = []

    for line in transcript.split("\n"):
        stripped = line.strip()
        if not stripped:
            continue

        # Detect role markers
        role_match = re.match(
            r'^(user|human|assistant|claude|agent|system)\s*:\s*(.*)',
            stripped, re.IGNORECASE
        )
        if role_match:
            # Save previous turn
            if current_text:
                turns.append({
                    "role": current_role,
                    "text": "\n".join(current_text).strip()
                })
            current_role = role_match.group(1).lower()
            if current_role in ("human",):
                current_role = "user"
            elif current_role in ("claude", "agent"):
                current_role = "assistant"
            current_text = [role_match.group(2)] if role_match.group(2) else []
        else:
            current_text.append(stripped)

    # Save last turn
    if current_text:
        turns.append({
            "role": current_role,
            "text": "\n".join(current_text).strip()
        })

    return turns


def _extract_decisions(text: str) -> list[str]:
    decisions = []
    for pattern in _DECISION_PATTERNS:
        for match in pattern.finditer(text):
            decision = match.group(1).strip().rstrip(".,!;")
            if len(decision) > 5:
                decisions.append(decision)
    return decisions


def _extract_preferences(text: str) -> list[dict]:
    prefs = []
    for pattern in _PREFERENCE_PATTERNS:
        for match in pattern.finditer(text):
            obj = match.group(1).strip().rstrip(".,!;")
            if len(obj) > 2:
                sentiment = "NEGATIVE" if any(w in match.group(0).lower()
                    for w in ("hate", "dislike", "avoid", "never", "don't")) else "POSITIVE"
                prefs.append({"object": obj, "sentiment": sentiment, "raw": match.group(0)[:100]})
    return prefs


def _extract_context(text: str) -> list[str]:
    contexts = []
    for pattern in _CONTEXT_PATTERNS:
        for match in pattern.finditer(text):
            ctx = match.group(1).strip().rstrip(".,!;")
            if len(ctx) > 3:
                contexts.append(ctx)
    return contexts


def _extract_tasks(text: str) -> list[str]:
    tasks = []
    for pattern in _TASK_PATTERNS:
        for match in pattern.finditer(text):
            task = match.group(1).strip().rstrip(".,!;")
            if len(task) > 5:
                tasks.append(task)
    return tasks


def _detect_feedback(user_text: str) -> list[dict]:
    feedbacks = []
    for pattern in _FEEDBACK_PATTERNS:
        for match in pattern.finditer(user_text):
            fb = {"type": "correction", "raw": match.group(0)[:120]}
            if match.lastindex and match.group(1):
                fb["instruction"] = match.group(1).strip()
            feedbacks.append(fb)
    return feedbacks


class ConversationObserver:
    """Automatic memory extraction from conversation transcripts."""

    def __init__(self, db_path: str | Path):
        self.db_path = Path(db_path)

    def ingest_transcript(
        self,
        transcript: str,
        session_id: str = "",
        agent_name: str = "agent",
    ) -> dict:
        """Process a conversation transcript and extract memories.

        This is the primary ingestion endpoint. Call at session end
        with the full conversation text.

        Returns summary of what was extracted and stored.
        """
        if not transcript or len(transcript.strip()) < 20:
            return {"status": "skipped", "reason": "transcript too short"}

        turns = _split_into_turns(transcript)
        if not turns:
            return {"status": "skipped", "reason": "no turns detected"}

        # Generate session hash for dedup
        session_hash = hashlib.sha256(transcript[:500].encode()).hexdigest()[:12]
        if not session_id:
            session_id = f"session_{session_hash}"

        results = {
            "session_id": session_id,
            "turns": len(turns),
            "decisions": [],
            "preferences": [],
            "context": [],
            "tasks": [],
            "feedback": [],
            "memories_created": 0,
        }

        # Extract from user turns (preferences, feedback, decisions)
        user_text = "\n".join(t["text"] for t in turns if t["role"] == "user")
        all_text = "\n".join(t["text"] for t in turns)

        # Decisions (from full conversation)
        results["decisions"] = _extract_decisions(all_text)

        # Preferences (from user turns)
        results["preferences"] = _extract_preferences(user_text)

        # Context (from full conversation)
        results["context"] = _extract_context(all_text)

        # Completed tasks
        results["tasks"] = _extract_tasks(all_text)

        # User feedback/corrections
        results["feedback"] = _detect_feedback(user_text)

        # --- Store extracted items as memories ---
        conn = sqlite3.connect(str(self.db_path), check_same_thread=False, timeout=10)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.row_factory = sqlite3.Row

        stored = 0

        # Store decisions
        for decision in results["decisions"][:5]:
            if self._store_if_new(conn, f"decision_{session_hash}_{stored}",
                                  f"Decision: {decision}", "decision",
                                  f"session:{session_id},auto_extracted", 0.7):
                stored += 1

        # Store preferences
        for pref in results["preferences"][:5]:
            if self._store_if_new(conn, f"preference_{pref['object'][:30]}",
                                  f"User {pref['sentiment'].lower()}: {pref['object']}",
                                  "user", f"preference,{pref['sentiment'].lower()},auto_extracted", 0.6):
                stored += 1

        # Store context
        for ctx in results["context"][:3]:
            if self._store_if_new(conn, f"context_{ctx[:30]}",
                                  f"Working context: {ctx}", "project",
                                  f"context,auto_extracted", 0.5):
                stored += 1

        # Store task completions
        for task in results["tasks"][:3]:
            if self._store_if_new(conn, f"completed_{task[:30]}",
                                  f"Completed: {task}", "project",
                                  f"completed,auto_extracted", 0.4):
                stored += 1

        # Store a session summary memory
        summary = self._generate_session_summary(turns, results)
        if summary:
            self._store_if_new(conn, f"session_{session_id}",
                              summary, "reference",
                              f"session_summary,{session_id},auto_extracted", 0.5)
            stored += 1

        conn.commit()
        conn.close()

        results["memories_created"] = stored
        results["status"] = "ingested"
        return results

    def _store_if_new(
        self, conn, name: str, content: str, mem_type: str,
        tags: str, importance: float
    ) -> bool:
        """Store memory if it doesn't already exist (by name)."""
        existing = conn.execute(
            "SELECT id FROM memories WHERE name=? AND active=1",
            (name,)
        ).fetchone()
        if existing:
            return False

        try:
            conn.execute("""
                INSERT INTO memories (name, type, tags, content, importance,
                    created, updated, active)
                VALUES (?, ?, ?, ?, ?, datetime('now'), datetime('now'), 1)
            """, (name, mem_type, tags, content, importance))
            return True
        except sqlite3.IntegrityError:
            return False

    def _generate_session_summary(self, turns: list[dict], results: dict) -> str:
        """Generate a brief session summary from extraction results."""
        parts = []

        if results["decisions"]:
            parts.append(f"Decisions made: {'; '.join(results['decisions'][:3])}")
        if results["tasks"]:
            parts.append(f"Completed: {'; '.join(results['tasks'][:3])}")
        if results["context"]:
            parts.append(f"Context: {'; '.join(results['context'][:3])}")
        if results["feedback"]:
            parts.append(f"Feedback given: {len(results['feedback'])} corrections")

        user_turn_count = sum(1 for t in turns if t["role"] == "user")
        parts.append(f"Session: {len(turns)} turns ({user_turn_count} user)")

        return " | ".join(parts) if parts else ""

    def generate_narrative(
        self,
        transcript: str,
        session_id: str = "",
        results: dict = None,
    ) -> str:
        """Generate a first-person session narrative.

        This is the diary entry from the agent's perspective.
        Called after ingest_transcript to produce the experiential record.
        """
        if results is None:
            results = self.ingest_transcript(transcript, session_id)

        turns = _split_into_turns(transcript)
        user_turns = [t for t in turns if t["role"] == "user"]
        assistant_turns = [t for t in turns if t["role"] == "assistant"]

        # Build narrative from what happened
        narrative_parts = []

        # Opening — what was the session about?
        if user_turns:
            first_user = user_turns[0]["text"][:100]
            narrative_parts.append(f"Session opened with: \"{first_user}...\"")

        # Decisions
        if results.get("decisions"):
            decs = results["decisions"][:3]
            narrative_parts.append(
                f"We decided: {'; '.join(decs)}."
            )

        # Tasks
        if results.get("tasks"):
            tasks = results["tasks"][:3]
            narrative_parts.append(f"Accomplished: {'; '.join(tasks)}.")

        # Feedback / corrections
        if results.get("feedback"):
            count = len(results["feedback"])
            narrative_parts.append(
                f"Received {count} correction{'s' if count > 1 else ''} — "
                "should review what I got wrong."
            )

        # Tone
        if len(turns) > 20:
            narrative_parts.append("Extended session — deep work together.")
        elif len(turns) <= 4:
            narrative_parts.append("Brief interaction.")

        return " ".join(narrative_parts)
