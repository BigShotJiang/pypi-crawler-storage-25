#!/usr/bin/env python3
"""AIBrain Workflow: Friday GitHub Check — new repos, stars, and activity since last run."""

import argparse
import datetime
import json
import os
import smtplib
import sqlite3
import sys
from email.mime.text import MIMEText
from pathlib import Path

import requests

AIBRAIN_ROOT = Path(os.environ.get("AIBRAIN_ROOT",
                    os.environ.get("AIBRAIN_ROOT",
                    Path(__file__).parent.parent)))
_cfg_path = AIBRAIN_ROOT / "config.json"
CONFIG = json.loads(_cfg_path.read_text()) if _cfg_path.exists() else {}
def _find_db():
    """Find best DB path, checking both new and legacy names."""
    for name in ["aibrain.db"]:
        p = AIBRAIN_ROOT / name
        if p.exists():
            return str(p)
    configured = CONFIG.get("db_path")
    if configured and Path(configured).exists():
        return configured
    mem_db = AIBRAIN_ROOT / "memory" / "memory.db"
    if mem_db.exists():
        return str(mem_db)
    return str(AIBRAIN_ROOT / "aibrain.db")

MEMORY_DB = CONFIG.get("db_path", _find_db())

HEADERS = {"User-Agent": "AIBrain/1.0", "Accept": "application/vnd.github.v3+json"}


def get_db():
    db = sqlite3.connect(MEMORY_DB)
    db.execute("PRAGMA journal_mode=wal")
    db.row_factory = sqlite3.Row
    return db


def load_state(name):
    try:
        db = get_db()
        row = db.execute(
            "SELECT content FROM memories WHERE name=? AND active=1",
            (f"workflow_state:{name}",),
        ).fetchone()
        db.close()
        return json.loads(row["content"]) if row else {}
    except Exception:
        return {}


def save_state(name, state):
    db = get_db()
    try:
        now = datetime.datetime.now().isoformat()
        existing = db.execute(
            "SELECT id FROM memories WHERE name=? AND active=1",
            (f"workflow_state:{name}",),
        ).fetchone()
        if existing:
            db.execute(
                "UPDATE memories SET content=?, updated=? WHERE id=?",
                (json.dumps(state), now, existing["id"]),
            )
        else:
            db.execute(
                "INSERT INTO memories (name,type,tags,content,created,updated,active) "
                "VALUES (?,?,?,?,?,?,1)",
                (f"workflow_state:{name}", "reference", "workflow,state", json.dumps(state), now, now),
            )
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def send_email(to, subject, body, dry_run=False):
    if dry_run:
        print(f"TO: {to}\nSUBJECT: {subject}\n\n{body}")
        return
    agent_email = CONFIG.get("agent_email", "aibrain@localhost")
    agent_password = CONFIG.get("agent_email_password", CONFIG.get("email_app_password", ""))
    msg = MIMEText(body, "plain")
    msg["From"] = agent_email
    msg["To"] = to
    msg["Subject"] = subject
    smtp_host = CONFIG.get("agent_smtp_host", CONFIG.get("email_smtp_host", "smtp.gmail.com"))
    with smtplib.SMTP_SSL(smtp_host, 465) as s:
        s.login(agent_email, agent_password)
        s.send_message(msg)


def get_headers():
    h = dict(HEADERS)
    token = CONFIG.get("github_token", "")
    if token:
        h["Authorization"] = f"token {token}"
    return h


def fetch_user_repos(username):
    """Fetch all repos for a user, return list of repo dicts."""
    repos = []
    page = 1
    while True:
        try:
            resp = requests.get(
                f"https://api.github.com/users/{username}/repos",
                headers=get_headers(),
                params={"per_page": 100, "page": page, "sort": "created", "direction": "desc"},
                timeout=15,
            )
            if resp.status_code != 200:
                break
            batch = resp.json()
            if not batch:
                break
            repos.extend(batch)
            page += 1
        except Exception as e:
            print(f"  Error fetching repos page {page}: {e}", file=sys.stderr)
            break
    return repos


def fetch_starred(username):
    """Fetch recently starred repos for a user."""
    try:
        resp = requests.get(
            f"https://api.github.com/users/{username}/starred",
            headers=get_headers(),
            params={"per_page": 30, "sort": "created", "direction": "desc"},
            timeout=15,
        )
        if resp.status_code == 200:
            return resp.json()
    except Exception:
        pass
    return []


def fetch_events(username):
    """Fetch recent public events for a user."""
    try:
        resp = requests.get(
            f"https://api.github.com/users/{username}/events/public",
            headers=get_headers(),
            params={"per_page": 30},
            timeout=15,
        )
        if resp.status_code == 200:
            return resp.json()
    except Exception:
        pass
    return []


def format_report(username, new_repos, new_stars, recent_events, prev_state):
    lines = [
        f"FRIDAY GITHUB CHECK — {datetime.datetime.now().strftime('%A %B %d, %Y')}",
        f"User: {username}",
        "=" * 50,
        "",
    ]

    # New repos since last check
    if new_repos:
        lines.append(f"NEW REPOS ({len(new_repos)})")
        for r in new_repos:
            lines.append(f"  {r['full_name']}")
            if r.get("description"):
                lines.append(f"    {r['description'][:100]}")
            lines.append(f"    Created: {r['created_at'][:10]}  Stars: {r.get('stargazers_count', 0)}")
            lines.append("")
    else:
        lines.append("No new repos since last check.")
        lines.append("")

    # New stars
    if new_stars:
        lines.append(f"NEW STARS ({len(new_stars)})")
        for s in new_stars:
            lines.append(f"  {s['full_name']}")
            if s.get("description"):
                lines.append(f"    {s['description'][:100]}")
            lines.append(f"    Stars: {s.get('stargazers_count', 0)}")
        lines.append("")
    else:
        lines.append("No new starred repos since last check.")
        lines.append("")

    # Recent activity summary
    if recent_events:
        event_types = {}
        for ev in recent_events:
            t = ev.get("type", "Unknown")
            event_types[t] = event_types.get(t, 0) + 1
        lines.append("ACTIVITY SUMMARY")
        for t, count in sorted(event_types.items(), key=lambda x: -x[1]):
            lines.append(f"  {t}: {count}")
        lines.append("")

    lines.append("--\nPowered by AIBrain")
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="AIBrain Friday GitHub Check")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    usernames = CONFIG.get("github_usernames", CONFIG.get("github_users", []))
    if isinstance(usernames, str):
        usernames = [usernames]
    email_to = CONFIG.get("email_to", CONFIG.get("agent_email", ""))
    state = load_state("friday_check_github_new")
    prev_repo_names = set(state.get("repo_names", []))
    prev_star_names = set(state.get("star_names", []))

    all_reports = []
    new_state = {"last_run": datetime.datetime.now().isoformat(), "repo_names": [], "star_names": []}

    for username in usernames:
        print(f"Checking GitHub user: {username}")

        # Fetch current repos
        repos = fetch_user_repos(username)
        current_repo_names = {r["full_name"] for r in repos}
        new_repos = [r for r in repos if r["full_name"] not in prev_repo_names]

        # Fetch starred repos
        starred = fetch_starred(username)
        current_star_names = {s["full_name"] for s in starred}
        new_stars = [s for s in starred if s["full_name"] not in prev_star_names]

        # Fetch recent events
        events = fetch_events(username)

        report = format_report(username, new_repos, new_stars, events, state)
        all_reports.append(report)

        new_state["repo_names"].extend(current_repo_names)
        new_state["star_names"].extend(current_star_names)

    full_report = "\n\n".join(all_reports)

    if not email_to or args.dry_run:
        print(full_report)
    else:
        send_email(
            email_to,
            f"Friday GitHub Check — {len(usernames)} user(s)",
            full_report,
        )
        print(f"Sent Friday GitHub check to {email_to}")

    save_state("friday_check_github_new", new_state)


if __name__ == "__main__":
    main()
