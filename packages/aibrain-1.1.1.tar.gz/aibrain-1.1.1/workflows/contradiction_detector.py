#!/usr/bin/env python3
"""AIBrain Workflow: Memory Contradiction Detector — find conflicting memories.

Scans active memories for contradictions, temporal supersessions, and precision overlaps.
Uses Jaccard similarity to find related pairs, then applies heuristic checks for conflicts.

Usage:
    python contradiction_detector.py --dry-run       # Report only, no DB changes
    python contradiction_detector.py --scan          # Full scan, save conflicts to DB
    python contradiction_detector.py --resolve 5     # Mark conflict #5 as resolved
    python contradiction_detector.py --show          # Show all unresolved conflicts
    python contradiction_detector.py --threshold 0.5 # Custom similarity threshold
"""

import argparse
import json
import os
import re
import sqlite3
import sys
from collections import defaultdict
from datetime import datetime
from pathlib import Path
import urllib.request

# Import shared utilities from memory_consolidation (same package)
sys.path.insert(0, str(Path(__file__).parent))
from memory_consolidation import tokenize, jaccard_similarity, STOPWORDS  # noqa: E402

AIBRAIN_ROOT = Path(os.environ.get("AIBRAIN_ROOT",
                    os.environ.get("AIBRAIN_ROOT",
                    Path(__file__).parent.parent)))
API_BASE = os.environ.get("AIBRAIN_API", os.environ.get("AIBRAIN_API", "http://localhost:8001/api/agent"))
CONFIG = json.loads((AIBRAIN_ROOT / "config.json").read_text()) if (AIBRAIN_ROOT / "config.json").exists() else {}
def _find_db():
    for name in ["aibrain.db"]:
        p = AIBRAIN_ROOT / name
        if p.exists():
            return str(p)
    configured = CONFIG.get("db_path")
    if configured and Path(configured).exists():
        return configured
    mem_db = AIBRAIN_ROOT / "memory" / "memory.db"
    if mem_db.exists():
        return str(mem_db)
    return str(AIBRAIN_ROOT / "aibrain.db")


DB_PATH = CONFIG.get("db_path", _find_db())

DEFAULT_THRESHOLD = 0.4

NEGATION_WORDS = frozenset({
    "not", "never", "dont", "don't", "doesn't", "doesnt", "wasn't", "wasnt",
    "isn't", "isnt", "aren't", "arent", "won't", "wont", "can't", "cant",
    "shouldn't", "shouldnt", "wouldn't", "wouldnt", "no longer", "removed",
    "deprecated", "replaced", "instead", "obsolete", "disabled", "dropped",
})

SUPERSESSION_PHRASES = [
    r"replaced\s+by", r"instead\s+of", r"no\s+longer", r"migrated\s+to",
    r"switched\s+to", r"moved\s+to", r"upgraded\s+to", r"now\s+uses?",
    r"formerly", r"previously", r"was\s+\w+,?\s+now",
]

CONFLICTS_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS memory_conflicts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    memory_a_id INTEGER,
    memory_b_id INTEGER,
    conflict_type TEXT,
    description TEXT,
    similarity REAL,
    resolved INTEGER DEFAULT 0,
    resolution_note TEXT DEFAULT '',
    created TEXT,
    resolved_at TEXT
)
"""


def log_activity(action, detail="", status="ok"):
    """Log activity to AIBrain API."""
    try:
        data = json.dumps({
            "action": action, "category": "system",
            "detail": detail, "status": status,
        }).encode()
        req = urllib.request.Request(
            f"{API_BASE}/activity", data=data,
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        pass


def get_db():
    """Open connection to aibrain.db with Row factory."""
    db = sqlite3.connect(DB_PATH)
    db.execute("PRAGMA journal_mode=wal")
    db.row_factory = sqlite3.Row
    db.execute(CONFLICTS_TABLE_SQL)
    db.commit()
    return db


def load_active_memories(db):
    """Load all active memories from the database."""
    rows = db.execute(
        "SELECT id, name, type, tags, content, created, updated, active, "
        "memory_class, importance, access_count, last_accessed, source_agent "
        "FROM memories WHERE active = 1"
    ).fetchall()
    return [dict(r) for r in rows]



def get_full_text(mem):
    """Get concatenated name + content for a memory."""
    return ((mem.get("name", "") or "") + " " + (mem.get("content", "") or "")).strip()


def extract_ports(text):
    """Extract port numbers from text."""
    return set(re.findall(r'(?:port\s+|:)(\d{2,5})\b', text.lower()))


def extract_urls(text):
    """Extract URLs from text."""
    return set(re.findall(r'https?://[^\s,)]+', text.lower()))


def extract_dates(text):
    """Extract dates in YYYY-MM-DD format from text."""
    return re.findall(r'(\d{4}-\d{2}-\d{2})', text)


def extract_ips(text):
    """Extract IP addresses from text."""
    return set(re.findall(r'\b(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\b', text))


def has_negation(text):
    """Check if text contains negation patterns."""
    lower = text.lower()
    for word in NEGATION_WORDS:
        if word in lower:
            return True
    return False


def has_supersession(text):
    """Check if text contains supersession phrases."""
    lower = text.lower()
    for pattern in SUPERSESSION_PHRASES:
        if re.search(pattern, lower):
            return True
    return False


def classify_conflict(mem_a, mem_b, similarity):
    """Classify the type of conflict between two memories.

    Returns (conflict_type, description) or None if no conflict detected.
    """
    text_a = get_full_text(mem_a)
    text_b = get_full_text(mem_b)
    name_a = mem_a.get("name", "?")
    name_b = mem_b.get("name", "?")

    reasons = []

    # --- Check for temporal supersession ---
    dates_a = extract_dates(text_a)
    dates_b = extract_dates(text_b)
    if dates_a and dates_b:
        max_a = max(dates_a)
        max_b = max(dates_b)
        if max_a != max_b:
            newer = name_a if max_a > max_b else name_b
            older = name_b if max_a > max_b else name_a
            reasons.append(f"Temporal: '{newer}' ({max(max_a, max_b)}) may supersede '{older}' ({min(max_a, max_b)})")
            return ("TEMPORAL", "; ".join(reasons))

    # --- Check for conflicting concrete values ---
    # Port conflicts
    ports_a = extract_ports(text_a)
    ports_b = extract_ports(text_b)
    if ports_a and ports_b and ports_a != ports_b:
        shared_context = _shared_topic(text_a, text_b)
        if shared_context:
            reasons.append(f"Port mismatch: {ports_a} vs {ports_b} (shared topic: {shared_context})")

    # URL conflicts for same service
    urls_a = extract_urls(text_a)
    urls_b = extract_urls(text_b)
    if urls_a and urls_b:
        # Only flag if URLs differ but topic is the same
        diff_urls = urls_a.symmetric_difference(urls_b)
        if diff_urls and _shared_topic(text_a, text_b):
            reasons.append(f"URL difference: {diff_urls}")

    # IP conflicts
    ips_a = extract_ips(text_a)
    ips_b = extract_ips(text_b)
    if ips_a and ips_b and ips_a != ips_b and _shared_topic(text_a, text_b):
        reasons.append(f"IP mismatch: {ips_a} vs {ips_b}")

    # --- Check for negation-based contradiction ---
    neg_a = has_negation(text_a)
    neg_b = has_negation(text_b)
    sup_a = has_supersession(text_a)
    sup_b = has_supersession(text_b)

    if (neg_a or neg_b) and not (neg_a and neg_b):
        # One has negation, the other doesn't — potential contradiction
        reasons.append("Negation asymmetry: one memory negates what the other asserts")

    if sup_a or sup_b:
        reasons.append("Supersession language detected")
        if not reasons or reasons == ["Supersession language detected"]:
            return ("TEMPORAL", "Supersession language detected — one memory may replace the other")

    if reasons:
        # Determine if this is a full contradiction or just a precision difference
        if any("mismatch" in r or "Negation asymmetry" in r for r in reasons):
            return ("CONTRADICTION", "; ".join(reasons))
        return ("PRECISION", "; ".join(reasons))

    # --- Check for precision (one is subset of the other) ---
    tokens_a = tokenize(text_a)
    tokens_b = tokenize(text_b)
    if tokens_a and tokens_b:
        a_in_b = len(tokens_a & tokens_b) / len(tokens_a) if tokens_a else 0
        b_in_a = len(tokens_a & tokens_b) / len(tokens_b) if tokens_b else 0
        # If one memory's tokens are largely contained in the other, it's a precision issue
        if (a_in_b > 0.8 and b_in_a < 0.5) or (b_in_a > 0.8 and a_in_b < 0.5):
            broader = name_a if len(tokens_a) > len(tokens_b) else name_b
            narrower = name_b if len(tokens_a) > len(tokens_b) else name_a
            return ("PRECISION", f"'{broader}' is broader; '{narrower}' is more specific — possible redundancy")

    # --- Check for different source agents (perspective) ---
    agent_a = mem_a.get("source_agent", "") or ""
    agent_b = mem_b.get("source_agent", "") or ""
    if agent_a and agent_b and agent_a != agent_b:
        return ("PERSPECTIVE", f"Same topic from different agents: {agent_a} vs {agent_b}")

    return None


def _shared_topic(text_a, text_b):
    """Find shared significant tokens between two texts. Returns top shared tokens or empty string."""
    tokens_a = tokenize(text_a)
    tokens_b = tokenize(text_b)
    shared = tokens_a & tokens_b
    # Filter to meaningful topic words (not too common)
    if len(shared) >= 3:
        return ", ".join(sorted(shared)[:5])
    return ""


def find_conflicts(memories, threshold=DEFAULT_THRESHOLD):
    """Find all conflicting memory pairs.

    Returns list of (mem_a, mem_b, similarity, conflict_type, description).
    """
    conflicts = []

    # Group by type — only compare within same type
    by_type = defaultdict(list)
    for mem in memories:
        by_type[mem.get("type", "unknown")].append(mem)

    # Pre-compute token sets
    token_cache = {}
    for mem in memories:
        token_cache[mem["id"]] = tokenize(get_full_text(mem))

    for mem_type, type_mems in by_type.items():
        n = len(type_mems)
        for i in range(n):
            for j in range(i + 1, n):
                ma = type_mems[i]
                mb = type_mems[j]

                # Jaccard on tokens
                sim = jaccard_similarity(token_cache[ma["id"]], token_cache[mb["id"]])
                if sim < threshold:
                    continue

                # High similarity — check for actual conflict
                result = classify_conflict(ma, mb, sim)
                if result:
                    ctype, desc = result
                    conflicts.append((ma, mb, sim, ctype, desc))

    # Sort by similarity descending (most likely conflicts first)
    conflicts.sort(key=lambda x: x[2], reverse=True)
    return conflicts


def run_scan(dry_run=False, threshold=DEFAULT_THRESHOLD):
    """Run a full contradiction scan."""
    db = get_db()
    now = datetime.now()
    report_lines = []

    def report(line=""):
        report_lines.append(line)
        print(line)

    report(f"MEMORY CONTRADICTION SCAN — {now.strftime('%Y-%m-%d %H:%M')}")
    report("=" * 60)

    memories = load_active_memories(db)
    report(f"Active memories: {len(memories)}")
    report(f"Similarity threshold: {threshold}")
    report("")

    if len(memories) < 2:
        report("Not enough memories to compare. Done.")
        db.close()
        return "\n".join(report_lines)

    conflicts = find_conflicts(memories, threshold)
    report(f"Conflicts detected: {len(conflicts)}")
    report("")

    # Check for already-known conflicts to avoid duplicates
    existing = set()
    if not dry_run:
        rows = db.execute(
            "SELECT memory_a_id, memory_b_id FROM memory_conflicts WHERE resolved = 0"
        ).fetchall()
        for r in rows:
            existing.add((r[0], r[1]))
            existing.add((r[1], r[0]))

    new_count = 0
    for idx, (ma, mb, sim, ctype, desc) in enumerate(conflicts, 1):
        marker = ""
        pair = (ma["id"], mb["id"])
        is_known = pair in existing or (mb["id"], ma["id"]) in existing

        if is_known:
            marker = " [KNOWN]"

        report(f"  [{ctype}]{marker} sim={sim:.3f}")
        report(f"    A: #{ma['id']} {ma.get('name', '?')}")
        report(f"    B: #{mb['id']} {mb.get('name', '?')}")
        report(f"    {desc}")
        report("")

        if not dry_run and not is_known:
            db.execute(
                "INSERT INTO memory_conflicts "
                "(memory_a_id, memory_b_id, conflict_type, description, similarity, resolved, created) "
                "VALUES (?, ?, ?, ?, ?, 0, ?)",
                (ma["id"], mb["id"], ctype, desc, sim, now.isoformat()),
            )
            new_count += 1

    report("=" * 60)
    if dry_run:
        report(f"[DRY RUN] {len(conflicts)} conflicts found. No changes made.")
    else:
        db.commit()
        report(f"{new_count} new conflicts saved to DB ({len(conflicts) - new_count} already known).")
        if new_count:
            log_activity(
                "contradiction_scan",
                f"Found {new_count} new conflicts from {len(memories)} memories",
            )

    db.close()

    # Save report
    reports_dir = AIBRAIN_ROOT / "reports"
    reports_dir.mkdir(exist_ok=True)
    report_path = reports_dir / f"contradiction_scan_{now.strftime('%Y%m%d_%H%M%S')}.txt"
    report_path.write_text("\n".join(report_lines), encoding="utf-8")
    print(f"\nReport saved: {report_path}")

    return "\n".join(report_lines)


def show_conflicts():
    """Show all unresolved conflicts."""
    db = get_db()
    rows = db.execute(
        "SELECT c.id, c.memory_a_id, c.memory_b_id, c.conflict_type, c.description, "
        "c.similarity, c.created, ma.name AS name_a, mb.name AS name_b "
        "FROM memory_conflicts c "
        "LEFT JOIN memories ma ON c.memory_a_id = ma.id "
        "LEFT JOIN memories mb ON c.memory_b_id = mb.id "
        "WHERE c.resolved = 0 "
        "ORDER BY c.similarity DESC"
    ).fetchall()

    if not rows:
        print("No unresolved conflicts.")
        db.close()
        return

    print(f"UNRESOLVED CONFLICTS: {len(rows)}")
    print("=" * 60)
    for r in rows:
        r = dict(r)
        print(f"  #{r['id']} [{r['conflict_type']}] sim={r['similarity']:.3f} ({r['created']})")
        print(f"    A: #{r['memory_a_id']} {r.get('name_a', '?')}")
        print(f"    B: #{r['memory_b_id']} {r.get('name_b', '?')}")
        print(f"    {r['description']}")
        print()

    db.close()


def resolve_conflict(conflict_id, note=""):
    """Mark a conflict as resolved."""
    db = get_db()
    now = datetime.now().isoformat()

    row = db.execute("SELECT id, resolved FROM memory_conflicts WHERE id = ?", (conflict_id,)).fetchone()
    if not row:
        print(f"Conflict #{conflict_id} not found.")
        db.close()
        return False

    if row["resolved"]:
        print(f"Conflict #{conflict_id} is already resolved.")
        db.close()
        return False

    db.execute(
        "UPDATE memory_conflicts SET resolved = 1, resolution_note = ?, resolved_at = ? WHERE id = ?",
        (note, now, conflict_id),
    )
    db.commit()
    print(f"Conflict #{conflict_id} marked as resolved.")
    db.close()
    return True


def main():
    parser = argparse.ArgumentParser(
        description="Memory Contradiction Detector — find conflicting memories in AIBrain."
    )
    parser.add_argument("--dry-run", action="store_true", help="Report only, no DB changes")
    parser.add_argument("--scan", action="store_true", help="Full scan, save conflicts to DB")
    parser.add_argument("--show", action="store_true", help="Show all unresolved conflicts")
    parser.add_argument("--resolve", type=int, metavar="ID", help="Mark a conflict as resolved")
    parser.add_argument("--note", type=str, default="", help="Resolution note (use with --resolve)")
    parser.add_argument(
        "--threshold", type=float, default=DEFAULT_THRESHOLD,
        help=f"Similarity threshold for conflict detection (default: {DEFAULT_THRESHOLD})",
    )

    args = parser.parse_args()

    if args.resolve is not None:
        resolve_conflict(args.resolve, note=args.note)
    elif args.show:
        show_conflicts()
    elif args.scan:
        run_scan(dry_run=False, threshold=args.threshold)
    elif args.dry_run:
        run_scan(dry_run=True, threshold=args.threshold)
    else:
        # Default: dry run
        print("No action specified. Running dry-run scan (use --scan to save results).\n")
        run_scan(dry_run=True, threshold=args.threshold)


if __name__ == "__main__":
    main()
