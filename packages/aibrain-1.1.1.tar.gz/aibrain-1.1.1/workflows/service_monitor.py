"""
Service Health Monitor — standalone or importable.

Checks endpoints, double-verifies failures, alerts on state changes via Telegram.
State persisted in last_status.json next to this script.

Usage:
    python service_monitor.py              # single check
    python service_monitor.py --loop       # continuous (every 5 min)
    python service_monitor.py --loop 120   # custom interval in seconds
"""

import json
import os
import time
import sys
import urllib.request
import urllib.error
import urllib.parse
from pathlib import Path
from datetime import datetime, timezone

# --- Env loader (reads ~/.env or ~/.aibrain_env) ---

def _load_env_file() -> dict:
    vals = {}
    for env_name in [".env", ".aibrain_env"]:
        env_file = Path.home() / env_name
        if env_file.exists():
            for line in env_file.read_text().splitlines():
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, _, val = line.partition("=")
                    key = key.replace("export ", "").strip()
                    vals[key] = val.strip().strip('"').strip("'")
    return vals

_env_file_vals = _load_env_file()

def _env(key: str, default: str = "") -> str:
    return os.environ.get(key, _env_file_vals.get(key, default))

# --- Config ---

ENDPOINTS = [
    {"name": "AIBrain (Local)", "url": "http://localhost:8001/api/health"},
]

# Add custom endpoints via env vars
_broker_url = _env("BROKER_URL")
if _broker_url:
    ENDPOINTS.append({"name": "Broker", "url": f"{_broker_url}/send",
                       "method": "POST", "headers": {"X-Token": _env("BROKER_TOKEN"),
                                                      "Content-Type": "application/json"},
                       "body": b'{"from":"local","to":"local","msg":"healthcheck"}',
                       "expect_codes": [200]})

_peer_url = _env("PEER_URL")
if _peer_url:
    ENDPOINTS.append({"name": "Peer", "url": f"{_peer_url}/api/health"})

TELEGRAM_BOT_TOKEN = _env("TELEGRAM_TOKEN")
TELEGRAM_CHAT_ID = _env("TELEGRAM_CHAT_ID", "")
CHECK_TIMEOUT = 10  # seconds
VERIFY_DELAY = 30   # seconds before re-check
DEFAULT_INTERVAL = 300  # 5 minutes

STATE_FILE = Path(__file__).parent / "last_status.json"


# --- Core functions ---

def check_endpoint(ep: dict, timeout: int = CHECK_TIMEOUT) -> bool:
    """Return True if endpoint responds with expected status within timeout."""
    url = ep if isinstance(ep, str) else ep["url"]
    method = ep.get("method", "GET") if isinstance(ep, dict) else "GET"
    headers = ep.get("headers", {}) if isinstance(ep, dict) else {}
    body = ep.get("body") if isinstance(ep, dict) else None
    expect = ep.get("expect_codes", [200]) if isinstance(ep, dict) else [200]
    try:
        req = urllib.request.Request(url, data=body, method=method)
        for k, v in headers.items():
            if v:  # skip empty header values
                req.add_header(k, v)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status in expect
    except Exception:
        return False


def load_state() -> dict:
    """Load last known states from disk. Returns {name: 'up'|'down'}."""
    if STATE_FILE.exists():
        try:
            return json.loads(STATE_FILE.read_text())
        except (json.JSONDecodeError, OSError):
            pass
    return {}


def save_state(state: dict) -> None:
    """Persist state to disk."""
    STATE_FILE.write_text(json.dumps(state, indent=2))


def send_telegram(message: str) -> bool:
    """Send a Telegram message. Returns True on success."""
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    payload = json.dumps({
        "chat_id": TELEGRAM_CHAT_ID,
        "text": message,
    }).encode("utf-8")
    req = urllib.request.Request(url, data=payload, method="POST")
    req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return resp.status == 200
    except Exception as e:
        print(f"[!] Telegram send failed: {e}")
        return False


def run_checks(endpoints: list[dict] | None = None) -> list[dict]:
    """
    Run a full check cycle with double-verification.

    Returns list of dicts with keys: name, url, status, transition, alerted.
    Only sends Telegram on state changes.
    """
    if endpoints is None:
        endpoints = ENDPOINTS

    state = load_state()
    results = []
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")

    for ep in endpoints:
        name, url = ep["name"], ep["url"]
        previous = state.get(name, "up")

        alive = check_endpoint(ep)

        # Double-verify on failure
        if not alive:
            print(f"[~] {name} failed first check, re-checking in {VERIFY_DELAY}s...")
            time.sleep(VERIFY_DELAY)
            alive = check_endpoint(ep)

        current = "up" if alive else "down"
        transition = None
        alerted = False

        if previous == "up" and current == "down":
            transition = "DOWN"
            msg = (
                f"SERVICE DOWN: {name}\n"
                f"URL: {url}\n"
                f"Time: {now}\n"
                f"Double-verified after {VERIFY_DELAY}s retry."
            )
            alerted = send_telegram(msg)
            print(f"[!] {name} is DOWN (alerted: {alerted})")

        elif previous == "down" and current == "up":
            transition = "UP"
            msg = (
                f"SERVICE RECOVERED: {name}\n"
                f"URL: {url}\n"
                f"Time: {now}"
            )
            alerted = send_telegram(msg)
            print(f"[+] {name} is back UP (alerted: {alerted})")

        else:
            print(f"[=] {name} is {current} (no change)")

        state[name] = current
        results.append({
            "name": name,
            "url": url,
            "status": current,
            "transition": transition,
            "alerted": alerted,
        })

    save_state(state)
    return results


def run_loop(interval: int = DEFAULT_INTERVAL) -> None:
    """Run checks in a loop forever."""
    print(f"Service monitor starting — interval {interval}s, checking {len(ENDPOINTS)} endpoints")
    while True:
        try:
            run_checks()
        except KeyboardInterrupt:
            raise
        except Exception as e:
            print(f"[!] Check cycle error: {e}")
        time.sleep(interval)


# --- CLI ---

if __name__ == "__main__":
    if "--loop" in sys.argv:
        idx = sys.argv.index("--loop")
        interval = int(sys.argv[idx + 1]) if idx + 1 < len(sys.argv) else DEFAULT_INTERVAL
        run_loop(interval)
    else:
        results = run_checks()
        for r in results:
            print(f"  {r['name']}: {r['status']}" + (f" ({r['transition']})" if r['transition'] else ""))
