#!/usr/bin/env python3
"""
SEO Monitoring Workflow Template — aibrain workflow library

Reusable SEO rank tracker with pluggable configuration. Replace the
placeholders below with your product's details and run.

Configuration:
    TARGET_SITE      — Your domain (e.g. "example.com")
    BRAND_NAME       — Product/brand name for report headers
    TARGET_KEYWORDS  — List of keywords to track in Google SERPs
    SITEMAP_URL      — Full URL to your sitemap.xml
    DB_PATH          — Path to SQLite database (or set SEO_DB env var)
    SERPAPI_KEY       — Set via environment variable SERPAPI_KEY

CLI:
    python seo_workflow_template.py check   — daily rank check
    python seo_workflow_template.py report  — weekly comparison report
    python seo_workflow_template.py ping    — ping sitemap to search engines

Dependencies: None beyond stdlib (requests-free). SerpAPI key optional.
"""

import json
import os
import sqlite3
import sys
import urllib.request
import urllib.parse
from datetime import datetime, timedelta

# ─── CONFIGURE THESE ──────────────────────────────────────────────────
TARGET_SITE = "{{TARGET_SITE}}"           # e.g. "myproduct.com"
BRAND_NAME = "{{BRAND_NAME}}"             # e.g. "MyProduct"
TARGET_KEYWORDS = [                       # Replace with your keywords
    "{{keyword_1}}", "{{keyword_2}}", "{{keyword_3}}",
    "{{keyword_4}}", "{{keyword_5}}", "{{keyword_6}}",
]
SITEMAP_URL = "{{SITEMAP_URL}}"           # e.g. "https://myproduct.com/sitemap.xml"
DB_PATH = os.environ.get("SEO_DB", os.path.join(os.path.dirname(__file__), "seo.db"))
SERPAPI_KEY = os.environ.get("SERPAPI_KEY", "")
# ─── END CONFIG ───────────────────────────────────────────────────────


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS seo_rankings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            site TEXT NOT NULL,
            keyword TEXT NOT NULL,
            position INTEGER,
            url TEXT,
            checked_at TEXT NOT NULL
        )
    """)
    conn.commit()
    return conn


def check_ranking(keyword: str) -> dict:
    """Query SerpAPI for keyword ranking. Returns {position, url} or None values."""
    if not SERPAPI_KEY:
        return {"position": None, "url": None, "error": "no_api_key"}
    params = urllib.parse.urlencode({
        "q": keyword, "api_key": SERPAPI_KEY, "engine": "google", "num": 100
    })
    url = f"https://serpapi.com/search.json?{params}"
    try:
        with urllib.request.urlopen(url, timeout=15) as resp:
            data = json.loads(resp.read())
    except Exception as e:
        return {"position": None, "url": None, "error": str(e)}

    for result in data.get("organic_results", []):
        link = result.get("link", "")
        if TARGET_SITE in link:
            return {"position": result.get("position"), "url": link}
    return {"position": None, "url": None}


def cmd_check():
    """Run daily rank check for all keywords."""
    db = get_db()
    now = datetime.utcnow().isoformat()
    results = []

    if not SERPAPI_KEY:
        print(f"[WARN] SERPAPI_KEY not set — storing null positions for tracking.")

    for kw in TARGET_KEYWORDS:
        r = check_ranking(kw)
        db.execute(
            "INSERT INTO seo_rankings (site, keyword, position, url, checked_at) VALUES (?,?,?,?,?)",
            (TARGET_SITE, kw, r.get("position"), r.get("url"), now),
        )
        pos = r.get("position") or "—"
        results.append(f"  {kw}: #{pos}")
        print(f"  [{kw}] position={pos}")

    db.commit()
    db.close()

    summary = f"SEO check ({BRAND_NAME} / {TARGET_SITE}) — {datetime.utcnow():%Y-%m-%d}\n"
    summary += "\n".join(results)
    print(f"\n{summary}")
    return summary


def cmd_report():
    """Generate weekly report comparing current vs 7-day-ago positions."""
    db = get_db()
    now = datetime.utcnow()
    week_ago = (now - timedelta(days=7)).isoformat()

    lines = [f"{BRAND_NAME} SEO Weekly Report — {TARGET_SITE} ({now:%Y-%m-%d})", "=" * 55]
    has_data = False

    for kw in TARGET_KEYWORDS:
        row = db.execute(
            "SELECT position, checked_at FROM seo_rankings WHERE site=? AND keyword=? ORDER BY checked_at DESC LIMIT 1",
            (TARGET_SITE, kw),
        ).fetchone()
        old = db.execute(
            "SELECT position FROM seo_rankings WHERE site=? AND keyword=? AND checked_at <= ? ORDER BY checked_at DESC LIMIT 1",
            (TARGET_SITE, kw, week_ago),
        ).fetchone()

        cur_pos = row[0] if row and row[0] else None
        old_pos = old[0] if old and old[0] else None

        if cur_pos is not None:
            has_data = True
            delta = ""
            if old_pos is not None:
                diff = old_pos - cur_pos
                if diff > 0:
                    delta = f" (+{diff})"
                elif diff < 0:
                    delta = f" ({diff})"
            lines.append(f"  {kw}: #{cur_pos}{delta}")
        else:
            lines.append(f"  {kw}: not ranked")

    db.close()

    if not has_data:
        lines.append(f"\n  No ranking data yet. Run `python {sys.argv[0]} check` first.")

    report = "\n".join(lines)
    print(report)
    return report


def cmd_ping():
    """Ping sitemap to Google and Bing."""
    engines = {
        "Google": f"https://www.google.com/ping?sitemap={urllib.parse.quote(SITEMAP_URL, safe='')}",
        "Bing": f"https://www.bing.com/indexnow?url={urllib.parse.quote(SITEMAP_URL, safe='')}",
    }
    results = []
    for name, url in engines.items():
        try:
            with urllib.request.urlopen(url, timeout=10) as resp:
                status = resp.status
            msg = f"  {name}: {status} OK"
        except Exception as e:
            msg = f"  {name}: FAILED ({e})"
        results.append(msg)
        print(msg)

    summary = f"Sitemap ping ({SITEMAP_URL}):\n" + "\n".join(results)
    return summary


if __name__ == "__main__":
    # Validate configuration
    if "{{" in TARGET_SITE:
        print("ERROR: Replace placeholders in config section before running.")
        print("  TARGET_SITE, BRAND_NAME, TARGET_KEYWORDS, SITEMAP_URL")
        sys.exit(1)

    commands = {"check": cmd_check, "report": cmd_report, "ping": cmd_ping}
    if len(sys.argv) < 2 or sys.argv[1] not in commands:
        print(f"Usage: python {sys.argv[0]} <{'|'.join(commands)}>")
        sys.exit(1)
    commands[sys.argv[1]]()
