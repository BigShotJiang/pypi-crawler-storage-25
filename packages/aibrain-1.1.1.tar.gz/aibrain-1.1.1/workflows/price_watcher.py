#!/usr/bin/env python3
"""AIBrain Workflow: Price Watcher — track prices via CoinGecko + web scraping."""

import argparse
import datetime
import json
import os
import smtplib
import sqlite3
import sys
import urllib.request
from email.mime.text import MIMEText
from pathlib import Path

import requests
from bs4 import BeautifulSoup

DEFAULT_CURRENCY_PAIRS = [
    {"from": "USD", "to": "EUR"},
    {"from": "USD", "to": "GBP"},
    {"from": "USD", "to": "JPY"},
]

AIBRAIN_ROOT = Path(os.environ.get("AIBRAIN_ROOT",
                    os.environ.get("AIBRAIN_ROOT",
                    Path(__file__).parent.parent)))
_cfg_path = AIBRAIN_ROOT / "config.json"
CONFIG = json.loads(_cfg_path.read_text()) if _cfg_path.exists() else {}
def _find_db():
    """Find best DB path, checking both new and legacy names."""
    for name in ["aibrain.db"]:
        p = AIBRAIN_ROOT / name
        if p.exists():
            return str(p)
    configured = CONFIG.get("db_path")
    if configured and Path(configured).exists():
        return configured
    mem_db = AIBRAIN_ROOT / "memory" / "memory.db"
    if mem_db.exists():
        return str(mem_db)
    return str(AIBRAIN_ROOT / "aibrain.db")

MEMORY_DB = CONFIG.get("db_path", _find_db())
API_BASE = os.environ.get("AIBRAIN_API", os.environ.get("AIBRAIN_API", "http://localhost:8001/api/agent"))


def log_activity(action, detail="", status="ok"):
    try:
        data = json.dumps({
            "action": action, "category": "finance",
            "detail": detail, "status": status,
        }).encode()
        req = urllib.request.Request(
            f"{API_BASE}/activity", data=data,
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        pass


DEFAULT_WATCHLIST = [
    {"type": "crypto", "id": "bitcoin", "name": "Bitcoin"},
    {"type": "crypto", "id": "ethereum", "name": "Ethereum"},
    {"type": "crypto", "id": "solana", "name": "Solana"},
]


def get_db():
    db = sqlite3.connect(MEMORY_DB)
    db.execute("PRAGMA journal_mode=wal")
    db.row_factory = sqlite3.Row
    return db


def load_state(name):
    try:
        db = get_db()
        row = db.execute("SELECT content FROM memories WHERE name=? AND active=1",
                         (f"workflow_state:{name}",)).fetchone()
        db.close()
        return json.loads(row["content"]) if row else {}
    except Exception:
        return {}


def save_state(name, state):
    db = get_db()
    try:
        now = datetime.datetime.now().isoformat()
        existing = db.execute("SELECT id FROM memories WHERE name=? AND active=1",
                             (f"workflow_state:{name}",)).fetchone()
        if existing:
            db.execute("UPDATE memories SET content=?, updated=? WHERE id=?",
                       (json.dumps(state), now, existing["id"]))
        else:
            db.execute("INSERT INTO memories (name,type,tags,content,created,updated,active) VALUES (?,?,?,?,?,?,1)",
                       (f"workflow_state:{name}", "reference", "workflow,state", json.dumps(state), now, now))
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def send_email(to, subject, body, dry_run=False):
    if dry_run:
        print(f"TO: {to}\nSUBJECT: {subject}\n\n{body}")
        return
    agent_email = CONFIG.get("agent_email", "aibrain@localhost")
    agent_password = CONFIG.get("agent_email_password", CONFIG.get("email_app_password", ""))
    msg = MIMEText(body, "plain")
    msg["From"] = agent_email
    msg["To"] = to
    msg["Subject"] = subject
    with smtplib.SMTP_SSL(CONFIG.get("agent_smtp_host", CONFIG.get("email_smtp_host", "smtp.gmail.com")), 465) as s:
        s.login(agent_email, agent_password)
        s.send_message(msg)


def fetch_crypto_prices(ids):
    """Fetch prices from CoinGecko (free, no API key)."""
    prices = {}
    try:
        id_str = ",".join(ids)
        resp = requests.get(
            f"https://api.coingecko.com/api/v3/simple/price?ids={id_str}&vs_currencies=usd&include_24hr_change=true",
            headers={"User-Agent": "AIBrain/1.0"}, timeout=10,
        )
        data = resp.json()
        for cid, info in data.items():
            prices[cid] = {
                "price": info.get("usd", 0),
                "change_24h": info.get("usd_24h_change", 0),
            }
    except Exception as e:
        print(f"CoinGecko error: {e}", file=sys.stderr)
    return prices


def fetch_exchange_rates(base="USD"):
    """Fetch exchange rates from open.er-api.com (free, no key required)."""
    rates = {}
    try:
        url = f"https://open.er-api.com/v6/latest/{base}"
        req = urllib.request.Request(url, headers={"User-Agent": "AIBrain/1.0"})
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read().decode())
        if data.get("result") == "success":
            rates = data.get("rates", {})
    except Exception as e:
        print(f"Exchange rate API error: {e}", file=sys.stderr)
    return rates


def format_report(watchlist, prices, prev_prices, fx_rates=None, fx_pairs=None, prev_fx=None):
    lines = [
        f"PRICE WATCHER — {datetime.datetime.now().strftime('%A %B %d, %Y %I:%M %p')}",
        "=" * 50,
        "",
    ]

    alerts = []
    for item in watchlist:
        if item["type"] == "crypto":
            cid = item["id"]
            name = item["name"]
            if cid in prices:
                price = prices[cid]["price"]
                change = prices[cid]["change_24h"]
                direction = "+" if change >= 0 else ""
                prev = prev_prices.get(cid, {}).get("price", 0)
                since_last = ""
                if prev:
                    diff = ((price - prev) / prev) * 100
                    since_last = f"  (since last check: {'+' if diff >= 0 else ''}{diff:.1f}%)"

                lines.append(f"  {name:15s} ${price:>12,.2f}  {direction}{change:.1f}% (24h){since_last}")

                if abs(change) > 10:
                    alerts.append(f"{name}: {direction}{change:.1f}% in 24h!")

    lines.append("")

    # Currency exchange rates section
    if fx_rates and fx_pairs:
        if prev_fx is None:
            prev_fx = {}
        lines.append("EXCHANGE RATES")
        for pair in fx_pairs:
            target = pair["to"]
            rate = fx_rates.get(target)
            if rate is not None:
                prev_rate = prev_fx.get(target)
                change_str = ""
                if prev_rate:
                    diff = ((rate - prev_rate) / prev_rate) * 100
                    change_str = f"  ({'+' if diff >= 0 else ''}{diff:.2f}% since last check)"
                lines.append(f"  {pair['from']}/{target:5s} {rate:>12.4f}{change_str}")
        lines.append("")

    if alerts:
        lines.append("ALERTS")
        for a in alerts:
            lines.append(f"  !! {a}")
        lines.append("")

    lines.append("—\nPowered by AIBrain + CoinGecko (free) + ExchangeRate-API")
    return "\n".join(lines), len(alerts) > 0


def main():
    parser = argparse.ArgumentParser(description="AIBrain Price Watcher")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    watchlist = CONFIG.get("price_watchlist", DEFAULT_WATCHLIST)
    email_to = CONFIG.get("email_to", CONFIG.get("agent_email", ""))

    state = load_state("price_watcher")
    prev_prices = state.get("prices", {})

    crypto_ids = [w["id"] for w in watchlist if w["type"] == "crypto"]
    prices = fetch_crypto_prices(crypto_ids)

    # Fetch currency exchange rates
    fx_pairs = CONFIG.get("currency_pairs", DEFAULT_CURRENCY_PAIRS)
    fx_base = fx_pairs[0]["from"] if fx_pairs else "USD"
    fx_rates = fetch_exchange_rates(fx_base)
    prev_fx = state.get("fx_rates", {})

    report, has_alerts = format_report(watchlist, prices, prev_prices,
                                       fx_rates=fx_rates, fx_pairs=fx_pairs,
                                       prev_fx=prev_fx)

    if not email_to or args.dry_run:
        print(report)
    else:
        prefix = "[ALERT] " if has_alerts else ""
        send_email(email_to, f"{prefix}Price Watch — {len(prices)} assets tracked", report)
        print(f"Sent price watch to {email_to}")

    save_state("price_watcher", {
        "last_run": datetime.datetime.now().isoformat(),
        "prices": prices,
        "fx_rates": {pair["to"]: fx_rates.get(pair["to"]) for pair in fx_pairs} if fx_rates else {},
    })

    alert_str = " with alerts" if has_alerts else ""
    log_activity("price_watcher", f"{len(prices)} assets tracked{alert_str}", "warning" if has_alerts else "ok")


if __name__ == "__main__":
    main()
