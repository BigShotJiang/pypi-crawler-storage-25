# Workflow Review Queue

Scripts moved here are candidates for consolidation or removal.
The operator reviews before final decision. Nothing is deleted — just staged for review.

## friday_check_github_new.py
**Reason:** Overlaps with `github_digest.py` — both monitor GitHub activity.
- `friday_check_github_new.py`: Weekly Friday scan for new stars (simpler)
- `github_digest.py`: Daily digest of repos, stars, issues, PRs (more comprehensive)
- **Recommendation:** Merge Friday check logic into github_digest.py as a weekly summary option, retire this script.

## contradiction_detector.py
**Reason:** Niche utility — detects contradictions in memory entries.
- Useful concept but not a standalone workflow. Could be a function in memory_consolidation.py instead.
- **Recommendation:** Keep as-is for now, but consider merging into memory_consolidation.
