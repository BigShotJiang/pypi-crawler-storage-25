#!/usr/bin/env python3
"""
risk_analyst.py — Pre-action risk assessment workflow for AIBrain.

Evaluates proposed actions against a 4-dimension risk framework before execution.
Can run as:
  - Standalone: python risk_analyst.py --action "push to public repo" --details "contains API keys"
  - Workflow: python run_workflow.py risk_analyst
  - Imported: from workflows.risk_analyst import assess_risk

The workflow also does periodic retrospective scans of recent actions to find
patterns that should have been flagged but weren't.
"""

import json
import os
import re
import sqlite3
import sys
from datetime import datetime, timezone
from pathlib import Path

# --- DB setup (same pattern as all AIBrain workflows) ---
AIBRAIN_ROOT = Path(__file__).parent.parent.resolve()
sys.path.insert(0, str(AIBRAIN_ROOT))


def _find_db():
    if "AIBRAIN_DB" in os.environ:
        return os.environ["AIBRAIN_DB"]
    for name in ["aibrain.db"]:
        p = AIBRAIN_ROOT / name
        if p.exists():
            return str(p)
    return str(AIBRAIN_ROOT / "aibrain.db")


DB_PATH = _find_db()

# --- Risk classification patterns ---

# Tier 1: ALWAYS PAUSE — patterns that indicate high-risk actions
TIER1_PATTERNS = {
    "credential_exposure": {
        "patterns": [
            r"(api[_-]?key|secret|token|password|credential|auth)\s*[=:]",
            r"(AWS|AZURE|GCP|STRIPE|GITHUB|TELEGRAM)_",
            r"Bearer\s+[A-Za-z0-9\-._~+/]+=*",
            r"sk-[a-zA-Z0-9]{20,}",
            r"ghp_[a-zA-Z0-9]{36}",
        ],
        "risk": "CRITICAL",
        "description": "Potential credential or secret in content",
    },
    "public_publish": {
        "patterns": [
            r"git\s+push.*public",
            r"--visibility\s+public",
            r"npm\s+publish",
            r"twine\s+upload",
            r"pypi.*upload",
        ],
        "risk": "HIGH",
        "description": "Publishing to public registry or repository",
    },
    "file_deletion": {
        "patterns": [
            r"rm\s+-rf?\s",
            r"\.unlink\(",
            r"shutil\.rmtree",
            r"os\.remove",
            r"git\s+rm\s",
        ],
        "risk": "HIGH",
        "description": "File or directory deletion",
    },
    "force_push": {
        "patterns": [
            r"git\s+push\s+--force",
            r"git\s+push\s+-f\s",
            r"git\s+reset\s+--hard",
            r"git\s+rebase.*--force",
        ],
        "risk": "HIGH",
        "description": "Destructive git operation",
    },
    "external_comms": {
        "patterns": [
            r"smtp.*send",
            r"send_?mail",
            r"sendMessage.*chat_id",
            r"requests\.post.*external",
        ],
        "risk": "MEDIUM",
        "description": "Sending external communication",
    },
    "financial": {
        "patterns": [
            r"stripe.*charge",
            r"payment.*create",
            r"transfer.*amount",
            r"withdraw",
        ],
        "risk": "CRITICAL",
        "description": "Financial transaction",
    },
}

# Sensitive content patterns (things that should never appear in public code)
SENSITIVE_CONTENT = [
    r"internal[_\s]tool[_\s]name",
    r"internal_tool|internal_pipeline|internal_platform",  # Internal product names in public code
    r"internal_system",
    r"76\.13\.198\.228",  # VPS IP
    r"user@example\.com",  # Replace with your actual sensitive email pattern
    r"\.secret_env",
]


def assess_risk(action: str, details: str = "", content: str = "") -> dict:
    """Assess the risk of a proposed action.

    Args:
        action: Short description of the action (e.g., "push to public repo")
        details: Additional context (e.g., "contains config files")
        content: The actual content being acted on (for pattern scanning)

    Returns:
        dict with risk assessment results
    """
    combined = f"{action} {details} {content}"
    findings = []

    # Check Tier 1 patterns
    for category, config in TIER1_PATTERNS.items():
        for pattern in config["patterns"]:
            if re.search(pattern, combined, re.IGNORECASE):
                findings.append({
                    "category": category,
                    "risk": config["risk"],
                    "description": config["description"],
                    "matched_pattern": pattern,
                })
                break  # One match per category is enough

    # Check for sensitive content in the payload
    if content:
        for pattern in SENSITIVE_CONTENT:
            if re.search(pattern, content, re.IGNORECASE):
                findings.append({
                    "category": "sensitive_content",
                    "risk": "HIGH",
                    "description": f"Sensitive content detected: {pattern}",
                    "matched_pattern": pattern,
                })

    # Calculate dimensions
    reversibility = "LOW"
    blast_radius = "LOW"
    data_sensitivity = "LOW"
    precedent = "MEDIUM"  # Default — we don't have history yet

    for f in findings:
        if f["risk"] == "CRITICAL":
            data_sensitivity = "HIGH"
        if f["category"] in ("public_publish", "external_comms"):
            blast_radius = "HIGH"
        if f["category"] in ("file_deletion", "force_push"):
            reversibility = "HIGH"
        if f["category"] == "financial":
            reversibility = "HIGH"
            blast_radius = "HIGH"

    # Overall risk
    high_count = sum(1 for d in [reversibility, blast_radius, data_sensitivity]
                     if d == "HIGH")
    has_critical = any(f["risk"] == "CRITICAL" for f in findings)

    if has_critical:
        overall = "CRITICAL"
        recommendation = "ESCALATE"
    elif high_count >= 2:
        overall = "HIGH"
        recommendation = "PAUSE_FOR_APPROVAL"
    elif high_count == 1:
        overall = "MEDIUM"
        recommendation = "PROCEED_WITH_CAUTION"
    elif findings:
        overall = "LOW"
        recommendation = "PROCEED"
    else:
        overall = "NONE"
        recommendation = "PROCEED"

    result = {
        "action": action,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "findings": findings,
        "dimensions": {
            "reversibility": reversibility,
            "blast_radius": blast_radius,
            "data_sensitivity": data_sensitivity,
            "precedent": precedent,
        },
        "overall_risk": overall,
        "recommendation": recommendation,
        "finding_count": len(findings),
    }

    # Log to DB
    _log_assessment(result)

    return result


def _log_assessment(result: dict):
    """Log risk assessment to the AIBrain database."""
    try:
        db = sqlite3.connect(DB_PATH)
        db.execute("""CREATE TABLE IF NOT EXISTS risk_assessments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            action TEXT NOT NULL,
            overall_risk TEXT NOT NULL,
            recommendation TEXT NOT NULL,
            finding_count INTEGER DEFAULT 0,
            details TEXT DEFAULT '',
            created TEXT DEFAULT (datetime('now'))
        )""")
        db.execute(
            "INSERT INTO risk_assessments (timestamp, action, overall_risk, recommendation, finding_count, details) VALUES (?, ?, ?, ?, ?, ?)",
            (result["timestamp"], result["action"], result["overall_risk"],
             result["recommendation"], result["finding_count"],
             json.dumps(result["findings"], default=str)),
        )
        db.commit()
        db.close()
    except Exception:
        pass  # Don't let logging failures block the assessment


def scan_recent_actions(hours: int = 24) -> list:
    """Retrospective scan — check recent git commits for things that should
    have been flagged. Returns list of concerning items."""
    concerns = []

    # Scan recent commits across known repos
    import subprocess
    repos = [
        str(AIBRAIN_ROOT),
        str(Path(os.environ.get("AIBRAIN_SYSTEM_DIR", str(Path.home() / "aibrain_system")))),
    ]

    for repo in repos:
        if not Path(repo).exists():
            continue
        try:
            result = subprocess.run(
                ["git", "log", f"--since={hours} hours ago", "--format=%H %s", "--name-only"],
                capture_output=True, text=True, cwd=repo, timeout=10,
            )
            if not result.stdout:
                continue

            # Check commit messages and changed files for risk patterns
            for line in result.stdout.splitlines():
                combined = line.lower()
                for category, config in TIER1_PATTERNS.items():
                    for pattern in config["patterns"]:
                        if re.search(pattern, combined, re.IGNORECASE):
                            concerns.append({
                                "repo": repo,
                                "line": line.strip(),
                                "category": category,
                                "risk": config["risk"],
                            })
                            break
        except Exception:
            continue

    return concerns


def format_assessment(result: dict) -> str:
    """Format a risk assessment result as human-readable text."""
    lines = [
        f"RISK ASSESSMENT: {result['action']}",
        "",
        f"Reversibility:    {result['dimensions']['reversibility']}",
        f"Blast radius:     {result['dimensions']['blast_radius']}",
        f"Data sensitivity: {result['dimensions']['data_sensitivity']}",
        f"Precedent:        {result['dimensions']['precedent']}",
        "",
        f"Overall risk: {result['overall_risk']}",
        f"Recommendation: {result['recommendation']}",
    ]

    if result["findings"]:
        lines.append("")
        lines.append("Findings:")
        for f in result["findings"]:
            lines.append(f"  [{f['risk']}] {f['description']}")

    return "\n".join(lines)


def main():
    import argparse
    parser = argparse.ArgumentParser(description="AIBrain Risk Analyst")
    parser.add_argument("--action", type=str, help="Action to assess")
    parser.add_argument("--details", type=str, default="", help="Additional context")
    parser.add_argument("--content", type=str, default="", help="Content to scan")
    parser.add_argument("--content-file", type=str, help="File containing content to scan")
    parser.add_argument("--retrospective", action="store_true",
                        help="Run retrospective scan of recent actions")
    parser.add_argument("--hours", type=int, default=24,
                        help="Hours to look back for retrospective scan")
    args = parser.parse_args()

    if args.retrospective:
        concerns = scan_recent_actions(args.hours)
        if concerns:
            print(f"Found {len(concerns)} concerns in last {args.hours}h:")
            for c in concerns:
                print(f"  [{c['risk']}] {c['category']}: {c['line'][:80]}")
        else:
            print(f"No concerns found in last {args.hours}h.")
        return

    if not args.action:
        parser.print_help()
        return

    content = args.content
    if args.content_file and Path(args.content_file).exists():
        content = Path(args.content_file).read_text(encoding="utf-8", errors="replace")

    result = assess_risk(args.action, args.details, content)
    print(format_assessment(result))


if __name__ == "__main__":
    main()
