#!/usr/bin/env python3
"""
job_tracker_db.py — Job Application Tracker (SQLite + FTS5)

Tracks all job applications, associated emails, status changes, and portal credentials.
Designed for AIBrain bundling — standalone, zero dependencies beyond stdlib.

Usage:
    python job_tracker_db.py add --company "Fivecast" --role "GRC Analyst" --location "Adelaide" --status applied
    python job_tracker_db.py list [--status applied|interview|offer|rejected|withdrawn]
    python job_tracker_db.py update <id> --status interview --notes "Phone screen scheduled March 25"
    python job_tracker_db.py email <app_id> --direction inbound --subject "Interview invitation" --body "..."
    python job_tracker_db.py search "cyber security adelaide"
    python job_tracker_db.py summary
    python job_tracker_db.py scan-inbox  # Scan Gmail IMAP for job-related emails
    python job_tracker_db.py export [--format json|csv]
"""

import sqlite3
import json
import sys
import os
import re
import threading
from datetime import datetime, timezone
from pathlib import Path
from argparse import ArgumentParser

# ---------------------------------------------------------------------------
# Database location — next to this script by default, overridable via env
# ---------------------------------------------------------------------------
_DB_PATH = Path(os.environ.get("JOB_TRACKER_DB", Path(__file__).parent / "job_tracker.db"))
_lock = threading.Lock()
_conn = None


def _get_db() -> sqlite3.Connection:
    global _conn
    if _conn is not None:
        return _conn
    with _lock:
        if _conn is not None:
            return _conn
        _conn = sqlite3.connect(str(_DB_PATH), check_same_thread=False)
        _conn.execute("PRAGMA journal_mode=WAL")
        _conn.execute("PRAGMA foreign_keys=ON")
        _conn.row_factory = sqlite3.Row
        _init_schema(_conn)
        return _conn


def _init_schema(conn: sqlite3.Connection):
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS applications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            company TEXT NOT NULL,
            role TEXT NOT NULL,
            location TEXT DEFAULT '',
            salary TEXT DEFAULT '',
            status TEXT DEFAULT 'applied',
            platform TEXT DEFAULT '',
            portal_url TEXT DEFAULT '',
            job_id TEXT DEFAULT '',
            credentials TEXT DEFAULT '',
            date_applied TEXT DEFAULT '',
            date_updated TEXT DEFAULT '',
            notes TEXT DEFAULT '',
            tags TEXT DEFAULT '',
            created_at TEXT DEFAULT (datetime('now')),
            updated_at TEXT DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS emails (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            app_id INTEGER,
            direction TEXT DEFAULT 'inbound',
            subject TEXT DEFAULT '',
            sender TEXT DEFAULT '',
            recipient TEXT DEFAULT '',
            body TEXT DEFAULT '',
            email_date TEXT DEFAULT '',
            classification TEXT DEFAULT '',
            gmail_msg_id TEXT DEFAULT '',
            needs_reply INTEGER DEFAULT 0,
            reply_sent INTEGER DEFAULT 0,
            created_at TEXT DEFAULT (datetime('now')),
            FOREIGN KEY (app_id) REFERENCES applications(id)
        );

        CREATE TABLE IF NOT EXISTS status_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            app_id INTEGER NOT NULL,
            old_status TEXT,
            new_status TEXT NOT NULL,
            changed_at TEXT DEFAULT (datetime('now')),
            notes TEXT DEFAULT '',
            FOREIGN KEY (app_id) REFERENCES applications(id)
        );

        CREATE VIRTUAL TABLE IF NOT EXISTS applications_fts USING fts5(
            company, role, location, notes, tags,
            content=applications, content_rowid=id
        );

        CREATE VIRTUAL TABLE IF NOT EXISTS emails_fts USING fts5(
            subject, body, sender,
            content=emails, content_rowid=id
        );

        -- Triggers to keep FTS in sync
        CREATE TRIGGER IF NOT EXISTS applications_ai AFTER INSERT ON applications BEGIN
            INSERT INTO applications_fts(rowid, company, role, location, notes, tags)
            VALUES (new.id, new.company, new.role, new.location, new.notes, new.tags);
        END;

        CREATE TRIGGER IF NOT EXISTS applications_au AFTER UPDATE ON applications BEGIN
            INSERT INTO applications_fts(applications_fts, rowid, company, role, location, notes, tags)
            VALUES ('delete', old.id, old.company, old.role, old.location, old.notes, old.tags);
            INSERT INTO applications_fts(rowid, company, role, location, notes, tags)
            VALUES (new.id, new.company, new.role, new.location, new.notes, new.tags);
        END;

        CREATE TRIGGER IF NOT EXISTS emails_ai AFTER INSERT ON emails BEGIN
            INSERT INTO emails_fts(rowid, subject, body, sender)
            VALUES (new.id, new.subject, new.body, new.sender);
        END;
    """)
    conn.commit()


# ---------------------------------------------------------------------------
# Application CRUD
# ---------------------------------------------------------------------------

def add_application(company, role, location="", salary="", status="applied",
                    platform="", portal_url="", job_id="", credentials="",
                    date_applied="", notes="", tags="") -> int:
    db = _get_db()
    now = datetime.now(timezone.utc).isoformat()
    if not date_applied:
        date_applied = now[:10]
    cur = db.execute("""
        INSERT INTO applications (company, role, location, salary, status, platform,
            portal_url, job_id, credentials, date_applied, date_updated, notes, tags,
            created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (company, role, location, salary, status, platform,
          portal_url, job_id, credentials, date_applied, now, notes, tags, now, now))
    db.execute("""
        INSERT INTO status_history (app_id, old_status, new_status, notes)
        VALUES (?, NULL, ?, 'Initial application')
    """, (cur.lastrowid, status))
    db.commit()
    return cur.lastrowid


def update_application(app_id, **kwargs) -> bool:
    db = _get_db()
    row = db.execute("SELECT * FROM applications WHERE id = ?", (app_id,)).fetchone()
    if not row:
        return False

    # Track status change
    if "status" in kwargs and kwargs["status"] != row["status"]:
        db.execute("""
            INSERT INTO status_history (app_id, old_status, new_status, notes)
            VALUES (?, ?, ?, ?)
        """, (app_id, row["status"], kwargs["status"], kwargs.get("notes", "")))

    allowed = {"company", "role", "location", "salary", "status", "platform",
               "portal_url", "job_id", "credentials", "date_applied", "notes", "tags"}
    updates = {k: v for k, v in kwargs.items() if k in allowed}
    if not updates:
        return False

    updates["updated_at"] = datetime.now(timezone.utc).isoformat()
    updates["date_updated"] = updates["updated_at"]
    sets = ", ".join(f"{k} = ?" for k in updates)
    vals = list(updates.values()) + [app_id]
    db.execute(f"UPDATE applications SET {sets} WHERE id = ?", vals)
    db.commit()
    return True


def list_applications(status=None, tag=None) -> list:
    db = _get_db()
    q = "SELECT * FROM applications WHERE 1=1"
    params = []
    if status:
        q += " AND status = ?"
        params.append(status)
    if tag:
        # Escape LIKE wildcards in user input to prevent wildcard injection
        safe_tag = tag.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
        q += " AND tags LIKE ? ESCAPE '\\'"
        params.append(f"%{safe_tag}%")
    q += " ORDER BY date_applied DESC"
    return [dict(r) for r in db.execute(q, params).fetchall()]


def get_application(app_id) -> dict | None:
    db = _get_db()
    row = db.execute("SELECT * FROM applications WHERE id = ?", (app_id,)).fetchone()
    if row:
        result = dict(row)
        result["emails"] = [dict(e) for e in db.execute(
            "SELECT * FROM emails WHERE app_id = ? ORDER BY email_date DESC", (app_id,)
        ).fetchall()]
        result["history"] = [dict(h) for h in db.execute(
            "SELECT * FROM status_history WHERE app_id = ? ORDER BY changed_at", (app_id,)
        ).fetchall()]
        return result
    return None


def search_applications(query: str) -> list:
    db = _get_db()
    rows = db.execute("""
        SELECT a.* FROM applications a
        JOIN applications_fts f ON a.id = f.rowid
        WHERE applications_fts MATCH ?
        ORDER BY rank
    """, (query,)).fetchall()
    return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# Email tracking
# ---------------------------------------------------------------------------

def add_email(app_id, direction, subject, sender="", recipient="", body="",
              email_date="", classification="", gmail_msg_id="",
              needs_reply=False) -> int:
    db = _get_db()
    if not email_date:
        email_date = datetime.now(timezone.utc).isoformat()
    cur = db.execute("""
        INSERT INTO emails (app_id, direction, subject, sender, recipient, body,
            email_date, classification, gmail_msg_id, needs_reply)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (app_id, direction, subject, sender, recipient, body,
          email_date, classification, gmail_msg_id, int(needs_reply)))
    db.commit()
    return cur.lastrowid


def get_emails_needing_reply() -> list:
    db = _get_db()
    rows = db.execute("""
        SELECT e.*, a.company, a.role FROM emails e
        JOIN applications a ON e.app_id = a.id
        WHERE e.needs_reply = 1 AND e.reply_sent = 0
        ORDER BY e.email_date DESC
    """).fetchall()
    return [dict(r) for r in rows]


def mark_replied(email_id) -> bool:
    db = _get_db()
    db.execute("UPDATE emails SET reply_sent = 1 WHERE id = ?", (email_id,))
    db.commit()
    return True


# ---------------------------------------------------------------------------
# Email classification
# ---------------------------------------------------------------------------

_JOB_PATTERNS = {
    "application_confirm": [
        r"application.*received", r"thank.*for.*appl", r"application.*submitted",
        r"we.*received.*your.*application", r"your.*application.*has been",
        r"candidate.*profile", r"application.*status"
    ],
    "interview_invite": [
        r"interview", r"phone\s*screen", r"schedule.*call", r"meet.*team",
        r"next\s*step", r"assessment", r"technical.*test", r"coding.*challenge"
    ],
    "rejection": [
        r"unfortunately", r"not.*progressing", r"other.*candidates",
        r"not.*successful", r"position.*filled", r"regret.*to inform",
        r"decided.*not.*to.*proceed", r"not.*shortlisted"
    ],
    "action_required": [
        r"verify.*email", r"confirm.*account", r"complete.*profile",
        r"one.time.*password", r"reset.*password", r"click.*link",
        r"OTP", r"verification.*code", r"set.*up.*password"
    ],
    "job_alert": [
        r"new.*job.*match", r"jobs.*for you", r"job.*alert", r"new.*position",
        r"recommended.*job", r"similar.*job", r"based.*on.*your.*search"
    ],
    "portal_update": [
        r"workday", r"successfactors", r"candidate.*home", r"application.*portal",
        r"sign.*in.*to.*view", r"login.*to.*check"
    ]
}

_JOB_SENDER_DOMAINS = {
    "indeed.com", "indeedemail.com", "seek.com.au", "linkedin.com",
    "jobadder.com", "workday.com", "myworkdayjobs.com", "successfactors.com",
    "glassdoor.com", "ziprecruiter.com", "careers.rtx.com", "baesystems.com",
    "crowdstrike.com", "arcticwolf.com", "thalesgroup.com", "deloitte.com",
    "paradox.ai", "elmotalent.com.au", "dataannotation.tech", "jobright.com",
    "bugcrowd.com", "fivecast.com", "babcock.com", "novasystems.com",
    "github.com",  # CI notifications for job-related repos
}


def classify_email(subject: str, sender: str, body: str = "") -> str:
    """Classify an email as job-related and return its type."""
    text = f"{subject} {body}".lower()
    sender_lower = sender.lower()

    # Check sender domain
    sender_domain = ""
    match = re.search(r"@([\w.-]+)", sender_lower)
    if match:
        sender_domain = match.group(1)

    is_job_sender = any(d in sender_domain for d in _JOB_SENDER_DOMAINS)

    for classification, patterns in _JOB_PATTERNS.items():
        for pat in patterns:
            if re.search(pat, text, re.IGNORECASE):
                return classification

    if is_job_sender:
        return "job_related"

    return "unrelated"


def match_email_to_application(subject: str, sender: str, body: str = "") -> int | None:
    """Try to match an email to an existing application by company name."""
    db = _get_db()
    apps = db.execute("SELECT id, company, role, platform FROM applications").fetchall()
    text = f"{subject} {sender} {body}".lower()
    for app in apps:
        company_words = app["company"].lower().split()
        if any(w in text for w in company_words if len(w) > 2):
            return app["id"]
    return None


# ---------------------------------------------------------------------------
# Gmail IMAP scanner
# ---------------------------------------------------------------------------

def scan_inbox(email_addr=None, days=30, dry_run=False):
    """Scan Gmail IMAP for job-related emails and add them to the tracker."""
    import imaplib
    import email as email_lib
    from email.header import decode_header
    from datetime import timedelta

    # Load credentials from config or environment
    app_password = os.environ.get("EMAIL_APP_PASSWORD", "")
    if not app_password:
        # Try config.json
        app_password = CONFIG.get("email_app_password", "")
    if not app_password:
        # Try .env file in aibrain root
        for env_name in [".env", ".aibrain_env"]:
            env_path = Path.home() / env_name
            if env_path.exists():
                for line in env_path.read_text().splitlines():
                    for key in ["EMAIL_APP_PASSWORD=", "IMAP_APP_PASSWORD="]:
                        if line.startswith(key):
                            app_password = line.split("=", 1)[1].strip().strip('"').strip("'")
                            break
                if app_password:
                    break

    if not app_password:
        print("ERROR: No EMAIL_APP_PASSWORD found. Set via env var, config.json, or ~/.env")
        return

    print(f"Connecting to Gmail IMAP as {email_addr}...")
    imap = imaplib.IMAP4_SSL("imap.gmail.com")
    imap.login(email_addr, app_password)
    imap.select("INBOX")

    since = (datetime.now() - timedelta(days=days)).strftime("%d-%b-%Y")
    _, msg_ids = imap.search(None, f'(SINCE {since})')
    all_ids = msg_ids[0].split()
    print(f"Found {len(all_ids)} emails in last {days} days")

    stats = {"total": 0, "job_related": 0, "added": 0, "matched": 0, "skipped": 0}
    db = _get_db()

    for i, msg_id in enumerate(all_ids):
        try:
            _, data = imap.fetch(msg_id, "(RFC822)")
            if not data or not data[0] or not isinstance(data[0], tuple):
                continue

            msg = email_lib.message_from_bytes(data[0][1])

            # Decode subject
            raw_subject = msg.get("Subject", "")
            decoded_parts = decode_header(raw_subject)
            subject = ""
            for part, enc in decoded_parts:
                if isinstance(part, bytes):
                    subject += part.decode(enc or "utf-8", errors="replace")
                else:
                    subject += str(part)

            sender = msg.get("From", "")
            date_str = msg.get("Date", "")
            msg_id_header = msg.get("Message-ID", "")

            # Get body (first text part)
            body_text = ""
            if msg.is_multipart():
                for part in msg.walk():
                    if part.get_content_type() == "text/plain":
                        payload = part.get_payload(decode=True)
                        if payload:
                            body_text = payload.decode("utf-8", errors="replace")[:2000]
                        break
            else:
                payload = msg.get_payload(decode=True)
                if payload:
                    body_text = payload.decode("utf-8", errors="replace")[:2000]

            # Classify
            classification = classify_email(subject, sender, body_text)
            stats["total"] += 1

            if classification == "unrelated":
                stats["skipped"] += 1
                continue

            stats["job_related"] += 1

            # Check if already tracked
            existing = db.execute(
                "SELECT id FROM emails WHERE gmail_msg_id = ?", (msg_id_header,)
            ).fetchone()
            if existing:
                continue

            # Try to match to application
            app_id = match_email_to_application(subject, sender, body_text)
            if app_id:
                stats["matched"] += 1

            needs_reply = classification in ("interview_invite", "action_required")

            if not dry_run:
                add_email(
                    app_id=app_id,
                    direction="inbound",
                    subject=subject,
                    sender=sender,
                    body=body_text[:2000],
                    email_date=date_str,
                    classification=classification,
                    gmail_msg_id=msg_id_header,
                    needs_reply=needs_reply
                )
                stats["added"] += 1

            if (i + 1) % 50 == 0:
                print(f"  Processed {i+1}/{len(all_ids)}...")

        except Exception as e:
            continue

    imap.close()
    imap.logout()

    print(f"\n=== Scan Results ===")
    print(f"Total emails scanned: {stats['total']}")
    print(f"Job-related found: {stats['job_related']}")
    print(f"Added to tracker: {stats['added']}")
    print(f"Matched to applications: {stats['matched']}")
    print(f"Skipped (unrelated): {stats['skipped']}")
    return stats


# ---------------------------------------------------------------------------
# Summary / reporting
# ---------------------------------------------------------------------------

def summary() -> dict:
    db = _get_db()
    total = db.execute("SELECT COUNT(*) FROM applications").fetchone()[0]
    by_status = {}
    for row in db.execute("SELECT status, COUNT(*) as c FROM applications GROUP BY status"):
        by_status[row["status"]] = row["c"]
    email_count = db.execute("SELECT COUNT(*) FROM emails").fetchone()[0]
    needs_reply = db.execute("SELECT COUNT(*) FROM emails WHERE needs_reply=1 AND reply_sent=0").fetchone()[0]
    recent = [dict(r) for r in db.execute(
        "SELECT id, company, role, status, date_applied FROM applications ORDER BY date_applied DESC LIMIT 5"
    ).fetchall()]
    return {
        "total_applications": total,
        "by_status": by_status,
        "total_emails": email_count,
        "needs_reply": needs_reply,
        "recent": recent
    }


def export_data(fmt="json") -> str:
    db = _get_db()
    apps = [dict(r) for r in db.execute("SELECT * FROM applications ORDER BY date_applied DESC").fetchall()]
    if fmt == "csv":
        import csv
        import io
        output = io.StringIO()
        if apps:
            writer = csv.DictWriter(output, fieldnames=apps[0].keys())
            writer.writeheader()
            writer.writerows(apps)
        return output.getvalue()
    return json.dumps(apps, indent=2)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = ArgumentParser(description="Job Application Tracker")
    sub = parser.add_subparsers(dest="cmd")

    # add
    p_add = sub.add_parser("add")
    p_add.add_argument("--company", required=True)
    p_add.add_argument("--role", required=True)
    p_add.add_argument("--location", default="")
    p_add.add_argument("--salary", default="")
    p_add.add_argument("--status", default="applied")
    p_add.add_argument("--platform", default="")
    p_add.add_argument("--portal-url", default="")
    p_add.add_argument("--job-id", default="")
    p_add.add_argument("--credentials", default="")
    p_add.add_argument("--date-applied", default="")
    p_add.add_argument("--notes", default="")
    p_add.add_argument("--tags", default="")

    # update
    p_upd = sub.add_parser("update")
    p_upd.add_argument("id", type=int)
    p_upd.add_argument("--company", default=None)
    p_upd.add_argument("--role", default=None)
    p_upd.add_argument("--location", default=None)
    p_upd.add_argument("--salary", default=None)
    p_upd.add_argument("--status", default=None)
    p_upd.add_argument("--notes", default=None)
    p_upd.add_argument("--tags", default=None)

    # list
    p_list = sub.add_parser("list")
    p_list.add_argument("--status", default=None)
    p_list.add_argument("--tag", default=None)

    # get
    p_get = sub.add_parser("get")
    p_get.add_argument("id", type=int)

    # search
    p_search = sub.add_parser("search")
    p_search.add_argument("query")

    # email
    p_email = sub.add_parser("email")
    p_email.add_argument("app_id", type=int)
    p_email.add_argument("--direction", default="inbound")
    p_email.add_argument("--subject", required=True)
    p_email.add_argument("--sender", default="")
    p_email.add_argument("--body", default="")
    p_email.add_argument("--classification", default="")

    # summary
    sub.add_parser("summary")

    # scan-inbox
    p_scan = sub.add_parser("scan-inbox")
    p_scan.add_argument("--days", type=int, default=30)
    p_scan.add_argument("--dry-run", action="store_true")

    # export
    p_export = sub.add_parser("export")
    p_export.add_argument("--format", default="json", choices=["json", "csv"])

    # needs-reply
    sub.add_parser("needs-reply")

    args = parser.parse_args()

    if args.cmd == "add":
        aid = add_application(
            company=args.company, role=args.role, location=args.location,
            salary=args.salary, status=args.status, platform=args.platform,
            portal_url=args.portal_url, job_id=args.job_id,
            credentials=args.credentials, date_applied=args.date_applied,
            notes=args.notes, tags=args.tags
        )
        print(f"Added application #{aid}: {args.company} — {args.role} [{args.status}]")

    elif args.cmd == "update":
        updates = {k: v for k, v in vars(args).items()
                   if k not in ("cmd", "id") and v is not None}
        if update_application(args.id, **updates):
            print(f"Updated application #{args.id}")
        else:
            print(f"Application #{args.id} not found")

    elif args.cmd == "list":
        apps = list_applications(status=args.status, tag=args.tag)
        if not apps:
            print("No applications found.")
            return
        for a in apps:
            print(f"  #{a['id']:3d}  {a['status']:15s}  {a['company']:20s}  {a['role']:30s}  {a['location']:20s}  {a['date_applied']}")

    elif args.cmd == "get":
        app = get_application(args.id)
        if app:
            print(json.dumps(app, indent=2))
        else:
            print(f"Application #{args.id} not found")

    elif args.cmd == "search":
        results = search_applications(args.query)
        for r in results:
            print(f"  #{r['id']:3d}  {r['status']:15s}  {r['company']:20s}  {r['role']}")

    elif args.cmd == "email":
        eid = add_email(
            app_id=args.app_id, direction=args.direction,
            subject=args.subject, sender=args.sender,
            body=args.body, classification=args.classification
        )
        print(f"Added email #{eid} to application #{args.app_id}")

    elif args.cmd == "summary":
        s = summary()
        print(f"Total applications: {s['total_applications']}")
        print(f"By status: {json.dumps(s['by_status'], indent=2)}")
        print(f"Total tracked emails: {s['total_emails']}")
        print(f"Needs reply: {s['needs_reply']}")
        if s["recent"]:
            print("\nRecent:")
            for r in s["recent"]:
                print(f"  #{r['id']}  {r['company']} — {r['role']} [{r['status']}]")

    elif args.cmd == "scan-inbox":
        scan_inbox(days=args.days, dry_run=args.dry_run)

    elif args.cmd == "export":
        print(export_data(fmt=args.format))

    elif args.cmd == "needs-reply":
        emails = get_emails_needing_reply()
        if not emails:
            print("No emails needing reply.")
            return
        for e in emails:
            print(f"  #{e['id']}  [{e['classification']}]  {e['company']} — {e['role']}")
            print(f"         Subject: {e['subject']}")
            print(f"         From: {e['sender']}")
            print()

    else:
        parser.print_help()


if __name__ == "__main__":
    main()
