#!/usr/bin/env python3
"""AIBrain Workflow: GitHub Digest — track repos, stars, issues, PRs."""

import argparse
import datetime
import json
import os
import smtplib
import sqlite3
import sys
from email.mime.text import MIMEText
from pathlib import Path

import urllib.request

import requests

AIBRAIN_ROOT = Path(os.environ.get("AIBRAIN_ROOT",
                    os.environ.get("AIBRAIN_ROOT",
                    Path(__file__).parent.parent)))
API_BASE = os.environ.get("AIBRAIN_API", os.environ.get("AIBRAIN_API", "http://localhost:8001/api/agent"))


def log_activity(action, detail="", status="ok"):
    """Log activity to AIBrain API."""
    try:
        data = json.dumps({
            "action": action, "category": "devops",
            "detail": detail, "status": status,
        }).encode()
        req = urllib.request.Request(
            f"{API_BASE}/activity", data=data,
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        pass
_cfg_path = AIBRAIN_ROOT / "config.json"
CONFIG = json.loads(_cfg_path.read_text()) if _cfg_path.exists() else {}
def _find_db():
    """Find best DB path, checking both new and legacy names."""
    for name in ["aibrain.db"]:
        p = AIBRAIN_ROOT / name
        if p.exists():
            return str(p)
    configured = CONFIG.get("db_path")
    if configured and Path(configured).exists():
        return configured
    mem_db = AIBRAIN_ROOT / "memory" / "memory.db"
    if mem_db.exists():
        return str(mem_db)
    return str(AIBRAIN_ROOT / "aibrain.db")

MEMORY_DB = CONFIG.get("db_path", _find_db())

HEADERS = {"User-Agent": "AIBrain/1.0", "Accept": "application/vnd.github.v3+json"}


def get_db():
    db = sqlite3.connect(MEMORY_DB)
    db.execute("PRAGMA journal_mode=wal")
    db.row_factory = sqlite3.Row
    return db

def load_state(name):
    try:
        db = get_db()
        row = db.execute("SELECT content FROM memories WHERE name=? AND active=1",
                         (f"workflow_state:{name}",)).fetchone()
        db.close()
        return json.loads(row["content"]) if row else {}
    except Exception:
        return {}

def save_state(name, state):
    db = get_db()
    try:
        now = datetime.datetime.now().isoformat()
        existing = db.execute("SELECT id FROM memories WHERE name=? AND active=1",
                             (f"workflow_state:{name}",)).fetchone()
        if existing:
            db.execute("UPDATE memories SET content=?, updated=? WHERE id=?",
                       (json.dumps(state), now, existing["id"]))
        else:
            db.execute("INSERT INTO memories (name,type,tags,content,created,updated,active) VALUES (?,?,?,?,?,?,1)",
                       (f"workflow_state:{name}", "reference", "workflow,state", json.dumps(state), now, now))
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()

def send_email(to, subject, body, dry_run=False):
    if dry_run:
        print(f"TO: {to}\nSUBJECT: {subject}\n\n{body}")
        return
    agent_email = CONFIG.get("agent_email", "aibrain@localhost")
    agent_password = CONFIG.get("agent_email_password", CONFIG.get("email_app_password", ""))
    msg = MIMEText(body, "plain")
    msg["From"] = agent_email
    msg["To"] = to
    msg["Subject"] = subject
    with smtplib.SMTP_SSL(CONFIG.get("agent_smtp_host", CONFIG.get("email_smtp_host", "smtp.gmail.com")), 465) as s:
        s.login(agent_email, agent_password)
        s.send_message(msg)


def get_headers():
    h = dict(HEADERS)
    token = CONFIG.get("github_token", "")
    if token:
        h["Authorization"] = f"token {token}"
    return h


def fetch_repo_info(repos):
    """Fetch repo stats from GitHub API."""
    results = []
    for repo in repos:
        try:
            resp = requests.get(f"https://api.github.com/repos/{repo}", headers=get_headers(), timeout=10)
            if resp.status_code == 200:
                data = resp.json()
                results.append({
                    "repo": repo,
                    "stars": data.get("stargazers_count", 0),
                    "forks": data.get("forks_count", 0),
                    "open_issues": data.get("open_issues_count", 0),
                    "pushed_at": data.get("pushed_at", ""),
                    "description": data.get("description", ""),
                })
        except Exception as e:
            print(f"  Error fetching {repo}: {e}", file=sys.stderr)
    return results


def fetch_notifications():
    """Fetch GitHub notifications (requires token)."""
    token = CONFIG.get("github_token", "")
    if not token:
        return []
    try:
        resp = requests.get("https://api.github.com/notifications?per_page=10",
                          headers=get_headers(), timeout=10)
        if resp.status_code == 200:
            return [{"title": n["subject"]["title"],
                     "repo": n["repository"]["full_name"],
                     "type": n["subject"]["type"],
                     "reason": n["reason"]}
                    for n in resp.json()[:10]]
    except Exception:
        pass
    return []


def fetch_trending():
    """Fetch trending repos (scrape GitHub trending page)."""
    trending = []
    try:
        resp = requests.get("https://github.com/trending?since=daily",
                          headers={"User-Agent": "AIBrain/1.0"}, timeout=10)
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(resp.text, "html.parser")
        for article in soup.select("article.Box-row")[:10]:
            h2 = article.select_one("h2 a")
            if h2:
                name = h2.get("href", "").strip("/")
                desc_p = article.select_one("p")
                desc = desc_p.text.strip() if desc_p else ""
                stars_span = article.select_one("span.d-inline-block.float-sm-right")
                stars = stars_span.text.strip() if stars_span else ""
                trending.append({"repo": name, "description": desc[:100], "stars_today": stars})
    except Exception:
        pass
    return trending


def format_digest(repos, notifications, trending, prev_state):
    lines = [
        f"GITHUB DIGEST — {datetime.datetime.now().strftime('%A %B %d, %Y')}",
        "=" * 50,
        "",
    ]

    if repos:
        lines.append("YOUR REPOS")
        for r in repos:
            prev = prev_state.get("repos", {}).get(r["repo"], {})
            star_diff = r["stars"] - prev.get("stars", r["stars"])
            star_indicator = f" (+{star_diff})" if star_diff > 0 else ""
            lines.append(f"  {r['repo']}")
            lines.append(f"    Stars: {r['stars']}{star_indicator}  Forks: {r['forks']}  Issues: {r['open_issues']}")
            lines.append(f"    Last push: {r['pushed_at'][:10] if r['pushed_at'] else 'unknown'}")
            lines.append("")

    if notifications:
        lines.append(f"NOTIFICATIONS ({len(notifications)})")
        for n in notifications:
            lines.append(f"  [{n['type']}] {n['repo']}: {n['title']}")
        lines.append("")

    if trending:
        lines.append("TRENDING TODAY")
        for t in trending[:5]:
            lines.append(f"  {t['repo']}")
            if t.get("description"):
                lines.append(f"    {t['description']}")
            if t.get("stars_today"):
                lines.append(f"    {t['stars_today']} stars today")
        lines.append("")

    lines.append("—\nPowered by AIBrain")
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="AIBrain GitHub Digest")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    watched_repos = CONFIG.get("github_repos", [])
    email_to = CONFIG.get("email_to", CONFIG.get("agent_email", ""))
    state = load_state("github_digest")

    repos = fetch_repo_info(watched_repos)
    notifications = fetch_notifications()
    trending = fetch_trending()

    digest = format_digest(repos, notifications, trending, state)

    if not email_to or args.dry_run:
        print(digest)
    else:
        send_email(email_to, f"GitHub Digest — {len(repos)} repos", digest)
        print(f"Sent GitHub digest to {email_to}")

    # Save current state for diff next time
    repo_state = {r["repo"]: {"stars": r["stars"], "forks": r["forks"]} for r in repos}
    save_state("github_digest", {
        "last_run": datetime.datetime.now().isoformat(),
        "repos": repo_state,
    })

    log_activity(
        "github_digest",
        f"{len(repos)} repos, {len(notifications)} notifications, {len(trending)} trending",
    )


if __name__ == "__main__":
    main()
