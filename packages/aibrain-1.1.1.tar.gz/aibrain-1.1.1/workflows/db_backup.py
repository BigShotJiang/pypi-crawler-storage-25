#!/usr/bin/env python3
"""AIBrain SQLite backup workflow — safe online backups with retention."""

import argparse
import json
import logging
import os
import sqlite3
import sys
import urllib.request
from datetime import datetime, timedelta
from pathlib import Path

AIBRAIN_ROOT = Path(__file__).resolve().parent.parent
BACKUP_DIR = AIBRAIN_ROOT / "backups"
DB_NAMES = ["aibrain.db", "approval.db", "activity.db", "checkpoints.db",
            "content.db", "cost_tracking.db", "job_tracker.db", "pairing.db",
            "tasks.db", "trace.db", "webhooks.db"]

logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(message)s",
                    datefmt="%Y-%m-%d %H:%M:%S")
log = logging.getLogger("db_backup")
API_BASE = os.environ.get("AIBRAIN_API", os.environ.get("AIBRAIN_API", "http://localhost:8001/api/agent"))


def log_activity(action, detail="", status="ok"):
    try:
        data = json.dumps({
            "action": action, "category": "system",
            "detail": detail, "status": status,
        }).encode()
        req = urllib.request.Request(
            f"{API_BASE}/activity", data=data,
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        pass


def backup_db(src: Path, dst: Path, dry_run: bool = False) -> bool:
    """Use SQLite online backup API to copy src -> dst. Returns True on success."""
    if not src.exists():
        return False
    if dry_run:
        log.info("DRY RUN: would back up %s -> %s", src.name, dst.name)
        return True
    try:
        src_conn = sqlite3.connect(str(src))
        dst_conn = sqlite3.connect(str(dst))
        src_conn.backup(dst_conn)
        dst_conn.close()
        src_conn.close()
        log.info("Backed up %s -> %s (%.1f KB)",
                 src.name, dst.name, dst.stat().st_size / 1024)
        return True
    except Exception as e:
        log.error("Failed to back up %s: %s", src.name, e)
        if dst.exists():
            dst.unlink()
        return False


def verify_backup(path: Path) -> bool:
    """Open backup and run integrity check."""
    try:
        conn = sqlite3.connect(str(path))
        result = conn.execute("PRAGMA integrity_check").fetchone()
        tables = conn.execute(
            "SELECT count(*) FROM sqlite_master WHERE type='table'"
        ).fetchone()[0]
        conn.close()
        ok = result[0] == "ok"
        if ok:
            log.info("VERIFIED: %s — integrity ok, %d tables", path.name, tables)
        else:
            log.error("CORRUPT: %s — %s", path.name, result[0])
        return ok
    except Exception as e:
        log.error("VERIFY FAILED: %s — %s", path.name, e)
        return False


def prune_old(prune_days: int, dry_run: bool = False) -> int:
    """Delete backups older than prune_days. Returns count deleted."""
    if not BACKUP_DIR.exists():
        return 0
    cutoff = datetime.now() - timedelta(days=prune_days)
    deleted = 0
    for f in sorted(BACKUP_DIR.glob("*_backup_*.db")):
        # Parse timestamp from filename: name_backup_YYYYMMDD_HHMMSS.db
        parts = f.stem.split("_backup_")
        if len(parts) != 2:
            continue
        try:
            ts = datetime.strptime(parts[1], "%Y%m%d_%H%M%S")
        except ValueError:
            continue
        if ts < cutoff:
            if dry_run:
                log.info("DRY RUN: would delete %s", f.name)
            else:
                f.unlink()
                log.info("Pruned %s", f.name)
            deleted += 1
    return deleted


def run_backup(dry_run: bool = False) -> tuple[int, int]:
    """Back up all databases. Returns (success_count, fail_count)."""
    BACKUP_DIR.mkdir(exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    ok, fail = 0, 0
    for name in DB_NAMES:
        src = AIBRAIN_ROOT / name
        if not src.exists():
            continue
        stem = name.replace(".db", "")
        dst = BACKUP_DIR / f"{stem}_backup_{stamp}.db"
        if backup_db(src, dst, dry_run):
            if not dry_run and not verify_backup(dst):
                fail += 1
                continue
            ok += 1
        else:
            fail += 1
    return ok, fail


def verify_all() -> tuple[int, int]:
    """Verify every backup in the backups directory."""
    if not BACKUP_DIR.exists():
        log.info("No backups directory found.")
        return 0, 0
    ok, fail = 0, 0
    for f in sorted(BACKUP_DIR.glob("*_backup_*.db")):
        if verify_backup(f):
            ok += 1
        else:
            fail += 1
    return ok, fail


def main():
    parser = argparse.ArgumentParser(description="AIBrain SQLite backup")
    parser.add_argument("--dry-run", action="store_true",
                        help="Show what would happen without doing it")
    parser.add_argument("--verify", action="store_true",
                        help="Verify all existing backups")
    parser.add_argument("--prune-days", type=int, default=7,
                        help="Delete backups older than N days (default: 7)")
    args = parser.parse_args()

    if args.verify:
        ok, fail = verify_all()
        log.info("Verification complete: %d ok, %d failed", ok, fail)
        sys.exit(1 if fail else 0)

    ok, fail = run_backup(dry_run=args.dry_run)
    pruned = prune_old(args.prune_days, dry_run=args.dry_run)
    log.info("Backup complete: %d ok, %d failed, %d pruned", ok, fail, pruned)
    log_activity("db_backup", f"{ok} ok, {fail} failed, {pruned} pruned",
                 status="ok" if fail == 0 else "error")
    sys.exit(1 if fail else 0)


if __name__ == "__main__":
    main()
