#!/usr/bin/env python3
import sys
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
"""Smart message inbox check — only shows unactioned messages.

Generic AIBrain workflow. Reads an inbox file (JSONL), compares against
an actioned log. Outputs nothing if all messages have been handled.
Prevents post-compaction re-reads of already-actioned messages.

Paths are resolved from config.json or environment, falling back to
sensible defaults under the AIBrain data directory.

Usage:
    python telegram_check.py          # Show unactioned messages (if any)
    python telegram_check.py --action "2026-04-01 12:06:35" "summary"
    python telegram_check.py --action-all   # Mark all current as actioned
"""

import json
import os
import sys
from datetime import datetime
from pathlib import Path

# Resolve AIBrain root
AIBRAIN_ROOT = Path(os.environ.get("AIBRAIN_ROOT",
                    os.environ.get("AIBRAIN_ROOT",
                    Path(__file__).parent.parent)))

# Load config
_config_path = AIBRAIN_ROOT / "config.json"
CONFIG = json.loads(_config_path.read_text(encoding="utf-8")) if _config_path.exists() else {}

# Resolve paths from config, env, or defaults
_data_dir = Path(CONFIG.get("data_dir", os.environ.get("AIBRAIN_DATA_DIR", str(AIBRAIN_ROOT / "data"))))
_data_dir.mkdir(parents=True, exist_ok=True)

INBOX = Path(CONFIG.get("inbox",
             CONFIG.get("telegram_inbox",
             os.environ.get("AIBRAIN_INBOX_FILE",
             str(_data_dir / "inbox.jsonl")))))

ACTIONED = Path(CONFIG.get("inbox_actioned",
                CONFIG.get("telegram_actioned",
                os.environ.get("AIBRAIN_ACTIONED_FILE",
                str(_data_dir / "inbox_actioned.jsonl")))))


def load_actioned_timestamps():
    """Load set of timestamps that have been actioned."""
    timestamps = set()
    if ACTIONED.exists():
        for line in ACTIONED.read_text(encoding="utf-8").splitlines():
            if line.strip():
                try:
                    entry = json.loads(line)
                    timestamps.add(entry.get("ts", ""))
                except json.JSONDecodeError:
                    continue
    return timestamps


def get_inbox_messages(limit=10):
    """Get recent inbox messages."""
    if not INBOX.exists():
        return []
    msgs = []
    for line in INBOX.read_text(encoding="utf-8").splitlines():
        if line.strip():
            try:
                msgs.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    return msgs[-limit:]


def check():
    """Check for unactioned messages. Print them if found, else print nothing."""
    msgs = get_inbox_messages(20)
    if not msgs:
        return

    actioned_ts = load_actioned_timestamps()
    unactioned = [m for m in msgs if m.get("ts", "") not in actioned_ts]

    if not unactioned:
        return

    print(f"[INBOX] {len(unactioned)} UNACTIONED message(s):")
    for m in unactioned:
        text = m.get('text', '').encode('utf-8', errors='replace').decode('utf-8')
        print(f"  [{m.get('ts', '')}] {m.get('from', '?')}: {text}")


def action_message(ts, summary):
    """Mark a specific message as actioned."""
    entry = {
        "ts": ts,
        "summary": summary,
        "actioned_at": datetime.now().isoformat()
    }
    ACTIONED.parent.mkdir(parents=True, exist_ok=True)
    with open(ACTIONED, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry) + "\n")
    print(f"Marked as actioned: {ts}")


def action_all():
    """Mark all current inbox messages as actioned."""
    msgs = get_inbox_messages(50)
    actioned_ts = load_actioned_timestamps()
    count = 0
    for m in msgs:
        ts = m.get("ts", "")
        if ts and ts not in actioned_ts:
            action_message(ts, "bulk-actioned")
            count += 1
    if count == 0:
        print("All messages already actioned.")
    else:
        print(f"Marked {count} messages as actioned.")


if __name__ == "__main__":
    if len(sys.argv) >= 2 and sys.argv[1] == "--action-all":
        action_all()
    elif len(sys.argv) >= 4 and sys.argv[1] == "--action":
        action_message(sys.argv[2], " ".join(sys.argv[3:]))
    else:
        check()
