#!/usr/bin/env python3
"""
AIBrain Workflow: CLI-Anything Bridge — auto-discover, register, and run
CLI wrappers for desktop applications.

Scans for installed `cli-anything-*` packages, reads their SKILL.md
manifests, registers each as an AIBrain workflow in aibrain.db, and
provides a unified interface to invoke any registered CLI tool.

Usage:
    python cli_anything_bridge.py discover          # scan + register installed CLIs
    python cli_anything_bridge.py list               # show registered CLIs
    python cli_anything_bridge.py run <cli> <cmd> [args...]  # execute a CLI command
    python cli_anything_bridge.py install <app>      # pip install cli-anything-<app>

Fallback: If no CLI wrapper exists for a given application, consider using
computer-use MCP (mcp__desktop-control__computer) as an alternative — it
can drive any GUI application via screen coordinates and keyboard input.

Requires: stdlib only (importlib.metadata, subprocess, json, sqlite3, argparse, shutil).
"""

import argparse
import importlib.metadata
import json
import os
import shutil
import sqlite3
import subprocess
import sys
import textwrap
from datetime import datetime, timezone
from pathlib import Path

# ---------------------------------------------------------------------------
# Config & DB helpers (matches existing workflow conventions)
# ---------------------------------------------------------------------------

AIBRAIN_ROOT = Path(os.environ.get(
    "AIBRAIN_ROOT",
    Path(__file__).parent.parent
))

_cfg_path = AIBRAIN_ROOT / "config.json"
CONFIG = json.loads(_cfg_path.read_text()) if _cfg_path.exists() else {}


def _find_db() -> str:
    """Find best DB path, checking env var then both new and legacy names."""
    env_db = os.environ.get("AIBRAIN_DB")
    if env_db and Path(env_db).exists():
        return env_db
    for name in ["aibrain.db"]:
        p = AIBRAIN_ROOT / name
        if p.exists():
            return str(p)
    configured = CONFIG.get("db_path")
    if configured and Path(configured).exists():
        return configured
    # Default — will be created on first write if needed
    return str(AIBRAIN_ROOT / "aibrain.db")


DB_PATH = _find_db()

# Tag prefix used for all CLI-Anything registrations
TAG_PREFIX = "workflow,cli_anything"

# ---------------------------------------------------------------------------
# Database operations
# ---------------------------------------------------------------------------


def _get_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def _ensure_table(conn: sqlite3.Connection) -> None:
    """Ensure the memories table exists (safe no-op if it already does)."""
    conn.execute("""
        CREATE TABLE IF NOT EXISTS memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            type TEXT DEFAULT 'reference',
            memory_class TEXT DEFAULT 'semantic',
            tags TEXT DEFAULT '',
            content TEXT DEFAULT '',
            importance REAL DEFAULT 0.5,
            access_count INTEGER DEFAULT 0,
            last_accessed TEXT,
            created TEXT DEFAULT (datetime('now')),
            updated TEXT DEFAULT (datetime('now')),
            active INTEGER DEFAULT 1
        )
    """)
    conn.commit()


def _upsert_workflow(conn: sqlite3.Connection, app_name: str,
                     entry_point: str, capabilities: str,
                     binary_path: str) -> int:
    """Insert or update a CLI-Anything workflow registration."""
    tags = f"{TAG_PREFIX},{app_name}"
    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    content = json.dumps({
        "app_name": app_name,
        "entry_point": entry_point,
        "binary_path": binary_path,
        "capabilities": capabilities,
        "registered": now,
        "bridge_version": "1.0.0",
    }, indent=2)

    name = f"cli_anything:{app_name}"

    # Check for existing registration
    row = conn.execute(
        "SELECT id FROM memories WHERE name = ? AND type = 'reference' AND active = 1",
        (name,)
    ).fetchone()

    if row:
        conn.execute(
            "UPDATE memories SET content = ?, tags = ?, updated = ? WHERE id = ?",
            (content, tags, now, row["id"])
        )
        return row["id"]
    else:
        cur = conn.execute(
            """INSERT INTO memories (name, type, memory_class, tags, content,
                                    importance, created, updated, active)
               VALUES (?, 'reference', 'procedural', ?, ?, 0.6, ?, ?, 1)""",
            (name, tags, content, now, now)
        )
        return cur.lastrowid


def _get_registered(conn: sqlite3.Connection) -> list:
    """Return all active CLI-Anything registrations."""
    rows = conn.execute(
        "SELECT * FROM memories WHERE type = 'reference' AND tags LIKE ? AND active = 1",
        (f"%{TAG_PREFIX}%",)
    ).fetchall()
    return rows


def _get_registration(conn: sqlite3.Connection, app_name: str) -> dict | None:
    """Return a single registration by app name."""
    name = f"cli_anything:{app_name}"
    row = conn.execute(
        "SELECT * FROM memories WHERE name = ? AND type = 'reference' AND active = 1",
        (name,)
    ).fetchone()
    if row:
        return dict(row)
    return None


# ---------------------------------------------------------------------------
# Discovery engine
# ---------------------------------------------------------------------------


def _discover_packages() -> list[dict]:
    """Scan installed packages for cli-anything-* distributions.

    Looks for:
      1. Packages named cli-anything-<app> or cli_anything_<app>
      2. Namespace packages under cli_anything.*
      3. Packages with cli_anything entry_points group
    """
    discovered = []
    seen_names = set()

    for dist in importlib.metadata.distributions():
        dist_name = dist.metadata["Name"] or ""
        normalized = dist_name.lower().replace("-", "_")

        # Match cli-anything-<app> or cli_anything_<app>
        is_cli_anything = False
        app_name = None

        if normalized.startswith("cli_anything_"):
            app_name = normalized[len("cli_anything_"):]
            is_cli_anything = True
        elif normalized.startswith("cli_anything."):
            app_name = normalized[len("cli_anything."):]
            is_cli_anything = True

        if not is_cli_anything:
            # Check entry_points for cli_anything group
            try:
                eps = dist.entry_points
                for ep in eps:
                    if ep.group == "cli_anything":
                        app_name = ep.name
                        is_cli_anything = True
                        break
            except Exception:
                pass

        if not is_cli_anything or not app_name:
            continue

        if app_name in seen_names:
            continue
        seen_names.add(app_name)

        # Resolve entry point (console_scripts)
        entry_point = None
        try:
            for ep in dist.entry_points:
                if ep.group == "console_scripts":
                    entry_point = ep.name
                    break
        except Exception:
            pass

        if not entry_point:
            entry_point = f"cli-anything-{app_name}"

        # Read SKILL.md if present
        capabilities = _read_skill_md(dist)

        # Check if the target application binary is installed
        binary_path = shutil.which(app_name)

        discovered.append({
            "app_name": app_name,
            "dist_name": dist_name,
            "version": dist.metadata.get("Version", "unknown"),
            "entry_point": entry_point,
            "capabilities": capabilities,
            "binary_path": binary_path or "",
            "binary_installed": binary_path is not None,
        })

    return discovered


def _read_skill_md(dist) -> str:
    """Read SKILL.md from a distribution's installed files."""
    try:
        files = dist.files or []
        for f in files:
            if f.name == "SKILL.md" or str(f).endswith("/SKILL.md"):
                located = f.locate()
                if located.exists():
                    return located.read_text(encoding="utf-8")
    except Exception:
        pass

    # Fallback: check package directory directly
    try:
        top_level = dist.read_text("top_level.txt")
        if top_level:
            pkg_name = top_level.strip().split("\n")[0]
            pkg_spec = importlib.util.find_spec(pkg_name)
            if pkg_spec and pkg_spec.origin:
                skill_path = Path(pkg_spec.origin).parent / "SKILL.md"
                if skill_path.exists():
                    return skill_path.read_text(encoding="utf-8")
    except Exception:
        pass

    return ""


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------


def cmd_discover(args: argparse.Namespace) -> int:
    """Scan for installed CLI-Anything packages and register them."""
    packages = _discover_packages()

    if not packages:
        print("No CLI-Anything packages found.")
        print()
        print("Install one with:")
        print("  python cli_anything_bridge.py install <app_name>")
        print()
        print("Or use computer-use MCP as a fallback for any GUI application:")
        print("  mcp__desktop-control__computer")
        return 0

    conn = _get_conn()
    _ensure_table(conn)

    registered = 0
    skipped = 0

    for pkg in packages:
        if not pkg["binary_installed"]:
            print(f"  SKIP  {pkg['app_name']:<20} "
                  f"(binary not found on PATH — install {pkg['app_name']} first)")
            skipped += 1
            continue

        row_id = _upsert_workflow(
            conn,
            app_name=pkg["app_name"],
            entry_point=pkg["entry_point"],
            capabilities=pkg["capabilities"],
            binary_path=pkg["binary_path"],
        )
        conn.commit()

        print(f"  REG   {pkg['app_name']:<20} "
              f"v{pkg['version']:<10} "
              f"binary={pkg['binary_path']}  "
              f"(id={row_id})")
        registered += 1

    conn.close()

    print()
    print(f"Registered: {registered}  |  Skipped: {skipped}  |  Total scanned: {len(packages)}")

    if skipped:
        print()
        print("Skipped packages have CLI wrappers installed but the target "
              "application binary is not on PATH.")
        print("Install the desktop application or add it to PATH, then re-run discover.")

    return 0


def cmd_list(args: argparse.Namespace) -> int:
    """Show all registered CLI-Anything tools."""
    conn = _get_conn()
    _ensure_table(conn)
    rows = _get_registered(conn)
    conn.close()

    if not rows:
        print("No CLI-Anything tools registered.")
        print()
        print("Run 'discover' to scan for installed packages:")
        print("  python cli_anything_bridge.py discover")
        print()
        print("Fallback: Use computer-use MCP to control any GUI application:")
        print("  mcp__desktop-control__computer")
        return 0

    print(f"{'Name':<22} {'Entry Point':<28} {'Binary':<40} {'Registered'}")
    print("-" * 110)

    for row in rows:
        try:
            data = json.loads(row["content"])
        except (json.JSONDecodeError, TypeError):
            continue

        app = data.get("app_name", "?")
        ep = data.get("entry_point", "?")
        binary = data.get("binary_path", "?")
        registered = data.get("registered", "?")

        # Re-check binary availability
        still_available = shutil.which(app) is not None
        status = "" if still_available else " [MISSING]"

        print(f"{app:<22} {ep:<28} {binary}{status:<40} {registered}")

        caps = data.get("capabilities", "")
        if caps and args.verbose:
            # Show first 3 lines of SKILL.md
            lines = caps.strip().splitlines()[:3]
            for line in lines:
                print(f"  | {line}")
            if len(caps.strip().splitlines()) > 3:
                print(f"  | ... ({len(caps.strip().splitlines())} lines total)")
            print()

    print()
    print(f"Total: {len(rows)} registered CLI-Anything tools")
    return 0


def cmd_run(args: argparse.Namespace) -> int:
    """Execute a registered CLI-Anything tool."""
    cli_name = args.cli_name
    command = args.command
    extra_args = args.extra_args or []

    conn = _get_conn()
    _ensure_table(conn)
    reg = _get_registration(conn, cli_name)
    conn.close()

    if not reg:
        print(f"Error: '{cli_name}' is not registered.", file=sys.stderr)
        print(f"Run 'discover' first, or install with:", file=sys.stderr)
        print(f"  python cli_anything_bridge.py install {cli_name}", file=sys.stderr)
        print(file=sys.stderr)
        print("Fallback: Use computer-use MCP for GUI control:", file=sys.stderr)
        print("  mcp__desktop-control__computer", file=sys.stderr)
        return 1

    try:
        data = json.loads(reg["content"])
    except (json.JSONDecodeError, TypeError):
        print(f"Error: corrupt registration for '{cli_name}'.", file=sys.stderr)
        return 1

    entry_point = data.get("entry_point", f"cli-anything-{cli_name}")
    binary_path = data.get("binary_path", "")

    # Verify binary is still available
    if not shutil.which(cli_name):
        print(f"Warning: '{cli_name}' binary not found on PATH. "
              f"Last known: {binary_path}", file=sys.stderr)
        print("The command may still work if the CLI wrapper handles "
              "this gracefully.", file=sys.stderr)

    # Build command: entry_point <command> [args...] --json
    cmd_parts = [entry_point, command] + extra_args
    if "--json" not in extra_args and "-j" not in extra_args:
        cmd_parts.append("--json")

    try:
        result = subprocess.run(
            cmd_parts,
            capture_output=True,
            text=True,
            timeout=300,
        )
    except FileNotFoundError:
        print(f"Error: command '{entry_point}' not found.", file=sys.stderr)
        print(f"Is the cli-anything-{cli_name} package installed?", file=sys.stderr)
        return 1
    except subprocess.TimeoutExpired:
        print(f"Error: command timed out after 300 seconds.", file=sys.stderr)
        return 1

    # Attempt to parse JSON output
    stdout = result.stdout.strip()
    stderr = result.stderr.strip()

    if result.returncode != 0:
        print(json.dumps({
            "success": False,
            "cli": cli_name,
            "command": command,
            "exit_code": result.returncode,
            "stderr": stderr,
            "stdout": stdout,
        }, indent=2))
        return result.returncode

    # Try structured JSON parse
    try:
        parsed = json.loads(stdout)
        output = {
            "success": True,
            "cli": cli_name,
            "command": command,
            "data": parsed,
        }
    except json.JSONDecodeError:
        # Return raw output if not valid JSON
        output = {
            "success": True,
            "cli": cli_name,
            "command": command,
            "raw_output": stdout,
        }

    if stderr:
        output["warnings"] = stderr

    print(json.dumps(output, indent=2))
    return 0


def cmd_install(args: argparse.Namespace) -> int:
    """Install a CLI-Anything package via pip."""
    app_name = args.app_name.lower().strip()

    # Sanitize — only allow alphanumeric and hyphens
    safe_name = "".join(c for c in app_name if c.isalnum() or c == "-")
    if safe_name != app_name:
        print(f"Error: invalid app name '{app_name}'.", file=sys.stderr)
        return 1

    package = f"cli-anything-{safe_name}"
    print(f"Installing {package}...")

    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", package],
            capture_output=True,
            text=True,
            timeout=120,
        )
    except subprocess.TimeoutExpired:
        print("Error: pip install timed out.", file=sys.stderr)
        return 1

    if result.returncode != 0:
        stderr = result.stderr.strip()
        if "No matching distribution" in stderr or "not find" in stderr.lower():
            print(f"Package '{package}' not found on PyPI.", file=sys.stderr)
            print(file=sys.stderr)
            print("No CLI wrapper exists for this application yet.", file=sys.stderr)
            print("Fallback: Use computer-use MCP to control the GUI directly:",
                  file=sys.stderr)
            print("  mcp__desktop-control__computer", file=sys.stderr)
        else:
            print(f"pip install failed (exit {result.returncode}):", file=sys.stderr)
            print(stderr, file=sys.stderr)
        return 1

    print(result.stdout)
    print(f"Installed. Run 'discover' to register:")
    print(f"  python cli_anything_bridge.py discover")
    return 0


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------


def main() -> int:
    parser = argparse.ArgumentParser(
        prog="cli_anything_bridge",
        description="AIBrain CLI-Anything Bridge — auto-discover and run CLI wrappers for desktop apps.",
        epilog=textwrap.dedent("""\
            Fallback: If no CLI wrapper exists for an application, use
            computer-use MCP (mcp__desktop-control__computer) as an
            alternative to drive any GUI application via screen
            coordinates and keyboard/mouse input.
        """),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    sub = parser.add_subparsers(dest="command", required=True)

    # discover
    p_discover = sub.add_parser(
        "discover",
        help="Scan for installed CLI-Anything packages and register them in AIBrain",
    )
    p_discover.set_defaults(func=cmd_discover)

    # list
    p_list = sub.add_parser(
        "list",
        help="Show all registered CLI-Anything tools",
    )
    p_list.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Show SKILL.md capabilities for each tool",
    )
    p_list.set_defaults(func=cmd_list)

    # run
    p_run = sub.add_parser(
        "run",
        help="Execute a registered CLI-Anything tool (appends --json automatically)",
    )
    p_run.add_argument("cli_name", help="Name of the CLI tool (e.g., blender, obs)")
    p_run.add_argument("command", help="Sub-command to execute")
    p_run.add_argument(
        "extra_args",
        nargs="*",
        help="Additional arguments passed to the CLI tool",
    )
    p_run.set_defaults(func=cmd_run)

    # install
    p_install = sub.add_parser(
        "install",
        help="Install a CLI-Anything package via pip (cli-anything-<app>)",
    )
    p_install.add_argument("app_name", help="Application name (e.g., blender, obs)")
    p_install.set_defaults(func=cmd_install)

    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
