#!/usr/bin/env python3
"""AIBrain Workflow: Email-to-Task — extract action items from emails, queue via approval API."""

import argparse
import datetime
import json
import re
import sys
import urllib.request
import urllib.error
from pathlib import Path

# Sibling imports
from email_triage import (
    fetch_unread,
    classify_email,
    decode_mime_header,
    get_body,
    CONFIG,
    AIBRAIN_ROOT,
    MEMORY_DB,
    load_state,
    save_state,
)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

API_BASE = CONFIG.get("api_base", "http://localhost:8001")
MAX_TRACKED_UIDS = 500

# Keyword → action_type mapping (checked in order, first match wins)
ACTION_PATTERNS = [
    (re.compile(r"\breview\b", re.IGNORECASE), "review"),
    (re.compile(r"\b(?:approve|confirm)\b", re.IGNORECASE), "approval"),
    (re.compile(r"\b(?:deadline|due\b|by\s+\w+\s+\d)", re.IGNORECASE), "deadline"),
    (re.compile(r"\b(?:respond|reply)\b", re.IGNORECASE), "respond"),
    (re.compile(r"\b(?:schedule|meeting|call)\b", re.IGNORECASE), "meeting"),
]


# ---------------------------------------------------------------------------
# Action extraction
# ---------------------------------------------------------------------------

def extract_action_type(subject, body, category):
    """Determine action_type from email content using keyword matching."""
    if category == "urgent":
        return "urgent_action"

    text = f"{subject} {body}"

    # Question mark in subject → respond
    if "?" in subject:
        return "respond"

    for pattern, action_type in ACTION_PATTERNS:
        if pattern.search(text):
            return action_type

    # Default for action-classified emails
    return "follow_up"


# ---------------------------------------------------------------------------
# API helpers
# ---------------------------------------------------------------------------

def api_post(endpoint, payload, dry_run=False):
    """POST JSON to the AIBrain API. Returns response dict or None."""
    url = f"{API_BASE}{endpoint}"
    data = json.dumps(payload).encode("utf-8")

    if dry_run:
        return {"status": "dry_run", "url": url}

    req = urllib.request.Request(
        url,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read().decode())
    except (urllib.error.URLError, urllib.error.HTTPError, OSError) as e:
        print(f"  API error ({endpoint}): {e}", file=sys.stderr)
        return None


def create_approval(email_info, action_type, dry_run=False):
    """Submit an approval request for a single action email."""
    payload = {
        "category": "email",
        "title": email_info["subject"][:200] or "(no subject)",
        "detail": (
            f"Action: {action_type}\n"
            f"From: {email_info['sender_email']}\n"
            f"Preview: {email_info.get('body_preview', '')[:200]}"
        ),
        "payload": {
            "email_uid": email_info["uid"],
            "sender": email_info["sender_email"],
            "subject": email_info["subject"],
            "action_type": action_type,
        },
    }
    return api_post("/api/agent/approvals", payload, dry_run=dry_run)


def log_activity(action, detail, status="ok", dry_run=False):
    """Log workflow activity via the AIBrain API."""
    payload = {
        "action": action,
        "category": "email",
        "detail": detail,
        "status": status,
    }
    return api_post("/api/agent/activity", payload, dry_run=dry_run)


# ---------------------------------------------------------------------------
# Main pipeline
# ---------------------------------------------------------------------------

def run_pipeline(dry_run=False):
    now = datetime.datetime.now()

    # --- Load previous state ---
    state = load_state("email_to_task")
    processed_uids = set(state.get("processed_uids", []))

    # --- Build account list (same logic as email_triage) ---
    accounts = []
    agent_email = CONFIG.get("agent_email", "")
    agent_password = CONFIG.get("agent_email_password", CONFIG.get("email_app_password", ""))
    agent_imap = CONFIG.get("agent_imap_host", CONFIG.get("email_imap_host", "imap.gmail.com"))
    if agent_email and agent_password:
        accounts.append({
            "label": "agent",
            "email": agent_email,
            "password": agent_password,
            "imap_host": agent_imap,
        })

    for acct in CONFIG.get("email_accounts", []):
        if acct.get("monitor") and acct.get("email") and acct.get("app_password"):
            accounts.append({
                "label": acct.get("label", acct["email"].split("@")[0]),
                "email": acct["email"],
                "password": acct["app_password"],
                "imap_host": acct.get("imap_host", "imap.gmail.com"),
            })

    if not accounts:
        print("Error: no email accounts configured.", file=sys.stderr)
        sys.exit(1)

    # --- Fetch unread emails from all accounts ---
    all_emails = []
    for acct in accounts:
        emails = fetch_unread(acct["imap_host"], acct["email"], acct["password"])
        for e in emails:
            if "category" in e:
                e["_account"] = acct["label"]
                all_emails.append(e)

    total_scanned = len(all_emails)

    # --- Filter for actionable emails ---
    actionable = [
        e for e in all_emails
        if e.get("category") in ("urgent", "action")
    ]

    # --- Separate new vs already-processed ---
    new_emails = []
    skipped = 0
    for e in actionable:
        uid = e.get("uid", "")
        if uid in processed_uids:
            skipped += 1
        else:
            new_emails.append(e)

    # --- Extract actions and queue approvals ---
    tasks_created = []
    for e in new_emails:
        action_type = extract_action_type(
            e.get("subject", ""),
            e.get("body_preview", ""),
            e.get("category", "action"),
        )
        result = create_approval(e, action_type, dry_run=dry_run)
        tasks_created.append({
            "action_type": action_type,
            "subject": e.get("subject", "(no subject)"),
            "sender": e.get("sender_email", "unknown"),
            "uid": e.get("uid", ""),
            "api_result": result,
        })
        # Track UID
        processed_uids.add(e.get("uid", ""))

    # --- Rolling window: keep only last N UIDs ---
    uid_list = list(processed_uids)
    if len(uid_list) > MAX_TRACKED_UIDS:
        uid_list = uid_list[-MAX_TRACKED_UIDS:]

    # --- Save state ---
    new_state = {
        "last_run": now.isoformat(),
        "processed_uids": uid_list,
        "tasks_created": len(tasks_created),
        "total_scanned": total_scanned,
        "skipped": skipped,
    }
    if not dry_run:
        save_state("email_to_task", new_state)

    # --- Log activity ---
    log_detail = (
        f"Scanned {total_scanned} emails from {len(accounts)} accounts. "
        f"Created {len(tasks_created)} tasks, skipped {skipped} already processed."
    )
    log_activity("email_to_task_run", log_detail, dry_run=dry_run)

    # --- Format output ---
    output = format_output(
        now=now,
        accounts_count=len(accounts),
        total_scanned=total_scanned,
        tasks=tasks_created,
        skipped=skipped,
    )
    print(output)

    return {
        "tasks_created": len(tasks_created),
        "skipped": skipped,
        "total_scanned": total_scanned,
    }


def format_output(now, accounts_count, total_scanned, tasks, skipped):
    """Format human-readable run summary."""
    lines = [
        f"EMAIL-TO-TASK — {now.strftime('%A %B %d, %Y')}",
        "=" * 42,
        f"Scanned: {accounts_count} account{'s' if accounts_count != 1 else ''}, {total_scanned} unread emails",
        f"Action emails found: {len(tasks) + skipped}",
        "",
    ]

    if tasks:
        lines.append("TASKS CREATED:")
        for t in tasks:
            lines.append(f"  [{t['action_type']}] \"{t['subject']}\" from {t['sender']}")
            lines.append("    -> Queued for approval")
        lines.append("")

    if skipped:
        lines.append(f"Already processed: {skipped} (skipped)")

    if not tasks and not skipped:
        lines.append("No action emails found this run.")

    lines.append("=" * 42)
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="AIBrain Email-to-Task — extract actions from email, queue via approval API",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Print results without calling APIs or saving state",
    )
    args = parser.parse_args()
    run_pipeline(dry_run=args.dry_run)


if __name__ == "__main__":
    main()
