"""
AIBrain Workflow: Claude Deep-Dive Interview Pipeline

Conducts structured multi-round consultations with Claude on claude.ai
via Playwright MCP browser automation. Automates: navigate, paste prompts,
wait for responses, extract text, compile transcripts.

Usage:
    python claude_interview.py --rounds rounds.json --output transcript.md
    python claude_interview.py --topic "Architecture Review" --context context.md

Requires:
    - Chrome running with --remote-debugging-port=9222
    - Logged into claude.ai in that Chrome session
    - Playwright MCP connected

Pipeline stages:
    1. PREPARE: Load rounds/context, verify Chrome debug port, check login state
    2. EXECUTE: For each round — paste prompt, send, wait, extract response
    3. COMPILE: Format all rounds into timestamped markdown transcript
    4. EXTRACT: Pull key decisions, action items, grades from responses
"""

import json
import sys
import os
import time
import subprocess
from datetime import datetime
from pathlib import Path

# -- Config --
CHROME_DEBUG_PORT = 9222
CLAUDE_AI_URL = "https://claude.ai/new"
POLL_INTERVAL_SECONDS = 10
MAX_WAIT_SECONDS = 300  # 5 min max per response (extended thinking)
OUTPUT_DIR = Path(__file__).parent.parent / "docs" / "consultations"


def check_chrome_debug():
    """Verify Chrome is running with remote debugging."""
    import urllib.request
    try:
        resp = urllib.request.urlopen(f"http://localhost:{CHROME_DEBUG_PORT}/json/version", timeout=3)
        data = json.loads(resp.read())
        return {"ok": True, "browser": data.get("Browser", "unknown")}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def launch_chrome_debug():
    """Launch Chrome with remote debugging if not already running."""
    status = check_chrome_debug()
    if status["ok"]:
        return status

    chrome_path = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
    if not os.path.exists(chrome_path):
        return {"ok": False, "error": f"Chrome not found at {chrome_path}"}

    subprocess.Popen([
        chrome_path,
        f"--remote-debugging-port={CHROME_DEBUG_PORT}",
        r"--user-data-dir=C:\temp\chrome-debug"
    ])
    time.sleep(5)
    return check_chrome_debug()


def prepare_round_prompt(round_config: dict, context: str = "") -> str:
    """Build the full prompt for a round, injecting context if Round 1."""
    prompt = round_config.get("prompt", "")
    if context and round_config.get("include_context", False):
        prompt = f"{context}\n\n---\n\n{prompt}"
    return prompt


def format_transcript(rounds_data: list, metadata: dict) -> str:
    """Format all rounds into a markdown transcript."""
    lines = [
        f"# {metadata.get('title', 'Claude Consultation')} — {metadata.get('date', datetime.now().strftime('%Y-%m-%d'))}",
        f"**Model:** {metadata.get('model', 'Claude Opus 4.6')}",
        f"**Rounds:** {len(rounds_data)}",
        f"**Chat URL:** {metadata.get('chat_url', 'N/A')}",
        "",
        "---",
        "",
    ]

    for i, rd in enumerate(rounds_data, 1):
        lines.extend([
            f"## Round {i} — {rd.get('topic', 'Untitled')}",
            "",
            "### Prompt",
            "",
            rd.get("prompt_summary", rd.get("prompt", "")[:500] + "..."),
            "",
            "### Response",
            "",
            rd.get("response", "*No response captured*"),
            "",
            "---",
            "",
        ])

    return "\n".join(lines)


def extract_key_findings(transcript: str) -> dict:
    """Extract structured findings from transcript (grades, action items, decisions)."""
    findings = {
        "grades": [],
        "action_items": [],
        "decisions": [],
        "warnings": [],
    }

    for line in transcript.split("\n"):
        line_lower = line.lower().strip()
        # Look for grade patterns (A-F)
        if any(f"grade: {g}" in line_lower or f"grade {g}" in line_lower
               for g in "abcdef"):
            findings["grades"].append(line.strip())
        # Action items
        if line.strip().startswith("- [ ]") or "action item" in line_lower:
            findings["action_items"].append(line.strip())
        # Decisions
        if "decision:" in line_lower or "recommend:" in line_lower:
            findings["decisions"].append(line.strip())
        # Warnings
        if "warning:" in line_lower or "critical:" in line_lower or "risk:" in line_lower:
            findings["warnings"].append(line.strip())

    return findings


# -- Interview Round Templates --

ARCHITECTURE_REVIEW_ROUNDS = [
    {
        "topic": "System Context + Architecture Review",
        "include_context": True,
        "prompt": """You are conducting an architecture review of AIBrain — a portable agent operating system.

I'm providing you with:
1. The complete system architecture (codebase overview, database schema, API surface, component inventory)
2. Competitive research on 8 agent memory frameworks (Hindsight, Letta/MemGPT, SuperMemory, Zep/Graphiti, Cognee, Mem0, LangMem, ContextKeep)
3. Our "Bruce Lee" integration plan — absorbing the best patterns from all competitors

Please review everything carefully. In your response:

1. **Grade each major subsystem A-F** with brief rationale:
   - Backend API architecture
   - Database schema / data model
   - Reactive Engine
   - Entity Links / Knowledge Graph
   - Frontend component architecture
   - Workflow system
   - Security posture
   - Memory system (current)

2. **Identify the top 5 blind spots** — things we're missing that will bite us

3. **What's over-engineered?** What complexity can we remove?

4. **What's under-built?** What needs more depth before shipping?

5. **Grade the Bruce Lee memory integration plan A-F** — is our priority order right? What would you change?

Be direct and critical. We want honest feedback, not encouragement."""
    },
    {
        "topic": "Memory Integration Deep Dive",
        "include_context": False,
        "prompt": """Based on the architecture you just reviewed, let's go deeper on the memory integration plan.

Our current memory: 197 records in flat SQLite with FTS5, entity_links table, typed memories (user/feedback/project/reference/pattern/decision). Estimated ~40-55% on LongMemEval.

Our plan absorbs patterns from 8 competitors into 3 tiers:
- Tier 1 (Week 1): Three-tier memory (Letta), bi-temporal facts (Graphiti), relational versioning (SuperMemory), self-editing tools
- Tier 2 (Week 2): 4-way parallel retrieval + RRF (Hindsight), write-time links, observation consolidation, feedback weights (Cognee)
- Tier 3 (Week 3): Procedural memory (LangMem), reactive triggers (ours), MCP server, memory pressure/eviction

Questions:
1. Is the 3-tier priority order correct? What would you reorder and why?
2. What's the minimum viable memory system that beats 80% on LongMemEval?
3. How do we implement 4-way parallel retrieval in SQLite without PostgreSQL? Specific technical approach.
4. The reactive memory triggers (memory events → ReactiveEngine) — is this genuinely novel or are we fooling ourselves?
5. What's the single highest-risk technical decision in this plan?
6. If you could only build 5 of the 15 features, which 5 and why?"""
    },
    {
        "topic": "Competitive Positioning + Go-to-Market",
        "include_context": False,
        "prompt": """Final round. Given everything you've reviewed:

The competitive landscape:
- Hindsight: 5.7K stars, 91.4% benchmark, MIT, PostgreSQL-only
- Letta: 21.7K stars, $10M funded, full runtime lock-in
- Mem0: 50.7K stars, $24M funded, 49% benchmark but great ecosystem
- SuperMemory: 17.2K stars, 81.6% benchmark, closed-source core
- Our pitch: "Single SQLite file. Zero dependencies. Works without internet. Works without AI. Works better with both."

Questions:
1. Is our positioning defensible? Can Mem0/Letta just add SQLite support and eat our lunch?
2. What's our actual moat — what can't they copy easily?
3. Should we benchmark on LongMemEval before shipping, or ship first and benchmark later?
4. MCP server as ecosystem play (following Mem0's 48K-star playbook) — right move?
5. AIBrain free + premium paid — does this business model work? Who's our actual customer?
6. Top 3 things to ship THIS WEEK for maximum impact
7. What would you do differently if you were building this from scratch?

Give me your honest assessment. Don't sugarcoat it."""
    },
]


if __name__ == "__main__":
    # CLI usage for manual testing
    status = check_chrome_debug()
    if status["ok"]:
        print(f"Chrome debug port active: {status['browser']}")
    else:
        print(f"Chrome not available: {status['error']}")
        print("Launching Chrome...")
        status = launch_chrome_debug()
        print(f"Result: {status}")

    print(f"\nInterview rounds prepared: {len(ARCHITECTURE_REVIEW_ROUNDS)}")
    for i, r in enumerate(ARCHITECTURE_REVIEW_ROUNDS, 1):
        print(f"  Round {i}: {r['topic']}")

    print(f"\nOutput directory: {OUTPUT_DIR}")
