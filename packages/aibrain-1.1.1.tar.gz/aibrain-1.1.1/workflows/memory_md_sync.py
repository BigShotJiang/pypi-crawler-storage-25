#!/usr/bin/env python3
"""AIBrain Workflow: MEMORY.md Sync — keeps agent memory files current with aibrain DB.

Problem: AI agents (Claude Code, Cursor, etc.) use MEMORY.md files for persistence
between sessions. These go stale quickly and cause agents to cite outdated information.
This workflow regenerates MEMORY.md from the live aibrain DB so the agent always
starts with current data.

Usage:
    python memory_md_sync.py                # Auto-detect and sync
    python memory_md_sync.py --dry-run      # Show what would change
    python memory_md_sync.py --output FILE  # Write to specific path
    python memory_md_sync.py --stats-only   # Just update stats section
"""

import argparse
import json
import os
import re
import sqlite3
import sys
from datetime import datetime
from pathlib import Path

AIBRAIN_ROOT = Path(os.environ.get("AIBRAIN_ROOT",
                    os.environ.get("AIBRAIN_ROOT",
                    Path(__file__).parent.parent)))
CONFIG = json.loads((AIBRAIN_ROOT / "config.json").read_text()) if (AIBRAIN_ROOT / "config.json").exists() else {}


def _find_db():
    # Pick the largest DB file (most data = correct one during migration)
    candidates = []
    for name in ["aibrain.db"]:
        p = AIBRAIN_ROOT / name
        if p.exists():
            candidates.append((p.stat().st_size, str(p)))
    if candidates:
        candidates.sort(reverse=True)
        return candidates[0][1]
    configured = CONFIG.get("db_path")
    if configured and Path(configured).exists():
        return configured
    mem_db = AIBRAIN_ROOT / "memory" / "memory.db"
    if mem_db.exists():
        return str(mem_db)
    return str(AIBRAIN_ROOT / "aibrain.db")


DB_PATH = CONFIG.get("db_path", _find_db())


def get_db():
    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row
    return db


def get_memory_stats(db):
    """Get live memory statistics from the database."""
    stats = {}
    try:
        stats["total_active"] = db.execute(
            "SELECT COUNT(*) FROM memories WHERE active=1"
        ).fetchone()[0]
    except Exception:
        stats["total_active"] = 0

    try:
        rows = db.execute(
            "SELECT type, COUNT(*) as cnt FROM memories WHERE active=1 GROUP BY type ORDER BY cnt DESC"
        ).fetchall()
        stats["by_type"] = {r["type"]: r["cnt"] for r in rows}
    except Exception:
        stats["by_type"] = {}

    try:
        stats["db_size_kb"] = round(Path(DB_PATH).stat().st_size / 1024)
    except Exception:
        stats["db_size_kb"] = 0

    return stats


def get_high_importance_memories(db, limit=20):
    """Get the most important active memories for the bootstrap section."""
    try:
        rows = db.execute("""
            SELECT name, type, content, importance
            FROM memories
            WHERE active=1
            ORDER BY
                CASE WHEN importance IS NOT NULL THEN importance ELSE 0.5 END DESC,
                updated DESC
            LIMIT ?
        """, (limit,)).fetchall()
        return [dict(r) for r in rows]
    except Exception:
        return []


def get_recent_feedback(db, limit=10):
    """Get recent feedback-type memories."""
    try:
        rows = db.execute("""
            SELECT name, content
            FROM memories
            WHERE active=1 AND type='feedback'
            ORDER BY updated DESC
            LIMIT ?
        """, (limit,)).fetchall()
        return [dict(r) for r in rows]
    except Exception:
        return []


def find_memory_md_paths():
    """Auto-discover MEMORY.md locations for various AI agents."""
    paths = []

    # Claude Code project memory
    home = Path.home()
    claude_dir = home / ".claude" / "projects"
    if claude_dir.exists():
        for project_dir in claude_dir.iterdir():
            if project_dir.is_dir():
                mem_dir = project_dir / "memory"
                if mem_dir.exists():
                    md_file = mem_dir / "MEMORY.md"
                    if md_file.exists():
                        paths.append(md_file)

    # Config-specified path
    custom_path = CONFIG.get("memory_md_path")
    if custom_path:
        p = Path(custom_path)
        if p.exists():
            paths.append(p)

    return paths


def update_stats_in_memory_md(md_path, stats):
    """Update just the stats section in an existing MEMORY.md without rewriting the whole file."""
    if not md_path.exists():
        return False

    content = md_path.read_text(encoding="utf-8")
    now = datetime.now().strftime("%Y-%m-%d")

    # Update "Last updated" line
    content = re.sub(
        r"Last updated:.*",
        f"Last updated: {now}",
        content,
    )

    # Update memory count if present (various formats)
    content = re.sub(
        r"\((\d+) memories",
        f"({stats['total_active']} memories",
        content,
    )

    # Update DB size if present
    content = re.sub(
        r"(\d+) memories, fully embedded",
        f"{stats['total_active']} memories, fully embedded",
        content,
    )

    md_path.write_text(content, encoding="utf-8")
    return True


def build_session_context() -> str:
    """Build current session context from git log and recent DB activity.

    This is the critical function that preserves context across compaction.
    Called by PostCompact hook to update LAST SESSION in MEMORY.md.
    """
    import subprocess
    lines = []
    now = datetime.now()

    lines.append(f"Date: {now.strftime('%Y-%m-%d')} (session continued)")
    agent_id = os.environ.get("AGENT_ID", "agent")
    lines.append(f"Agent: {agent_id}")
    lines.append("")

    # Recent git commits (last 2 hours = likely this session)
    try:
        result = subprocess.run(
            ["git", "log", "--oneline", "--since=2 hours ago", "--no-merges"],
            capture_output=True, text=True, timeout=5,
            cwd=str(AIBRAIN_ROOT),
        )
        commits = result.stdout.strip().split("\n") if result.stdout.strip() else []
        if commits:
            lines.append(f"### Commits this session ({len(commits)}):")
            for c in commits[:15]:
                lines.append(f"- {c}")
            lines.append("")
    except Exception:
        pass

    # Recent learnings from DB (auto-extracted in this session)
    try:
        db = get_db()
        recent = db.execute(
            "SELECT name, type, content FROM memories "
            "WHERE active=1 AND tags LIKE '%auto-extracted%' "  # noqa:LIKE WILDCARD INJECTION
            "AND created > datetime('now', '-2 hours') "
            "ORDER BY created DESC LIMIT 10"
        ).fetchall()

        if recent:
            lines.append(f"### Key learnings extracted ({len(recent)}):")
            for name, mtype, content in recent:
                preview = content[:120].replace("\n", " ") if content else ""
                lines.append(f"- [{mtype}] {preview}")
            lines.append("")

        # Recent activity log entries
        activity = db.execute(
            "SELECT action, detail FROM activity "
            "WHERE timestamp > datetime('now', '-2 hours') "
            "AND agent IN (?, 'chrome-extension', 'system') "
            "ORDER BY timestamp DESC LIMIT 10",
            (agent_id,)
        ).fetchall()

        if activity:
            lines.append("### Recent activity:")
            for action, detail in activity:
                detail_preview = detail[:100] if detail else ""
                lines.append(f"- {action}: {detail_preview}")
            lines.append("")

        # Git status — uncommitted work
        try:
            result = subprocess.run(
                ["git", "status", "--short"],
                capture_output=True, text=True, timeout=5,
                cwd=str(AIBRAIN_ROOT),
            )
            uncommitted = [l for l in result.stdout.strip().split("\n") if l.strip()]
            if uncommitted:
                lines.append(f"### Uncommitted changes ({len(uncommitted)} files):")
                for u in uncommitted[:10]:
                    lines.append(f"- {u}")
                lines.append("")
        except Exception:
            pass

        db.close()
    except Exception as e:
        lines.append(f"(DB query failed: {e})")

    return "\n".join(lines)


def update_last_session(md_path, session_block: str):
    """Replace the LAST SESSION section in MEMORY.md with current session context."""
    if not md_path.exists():
        return False

    content = md_path.read_text(encoding="utf-8")

    # Find and replace the LAST SESSION block using string operations (not regex)
    # to avoid backslash escape issues with Windows paths in session content
    marker = "## LAST SESSION"
    marker_pos = content.find(marker)

    if marker_pos != -1:
        # Find the next ## heading after LAST SESSION
        rest = content[marker_pos + len(marker):]
        next_heading = rest.find("\n## ")
        if next_heading != -1:
            # Replace everything between LAST SESSION and next heading
            content = (content[:marker_pos] + marker + "\n" +
                       session_block + rest[next_heading:])
        else:
            # LAST SESSION is the last section — replace to end
            content = content[:marker_pos] + marker + "\n" + session_block + "\n"
    else:
        # No LAST SESSION section — append it
        content += f"\n\n{marker}\n{session_block}\n"

    md_path.write_text(content, encoding="utf-8")
    return True


def generate_sync_section(stats, feedbacks):
    """Generate a sync status section that can be appended or used standalone."""
    lines = [
        "",
        "## AIBrain DB Sync",
        f"Last synced: {datetime.now().strftime('%Y-%m-%d %H:%M')}",
        f"DB: {DB_PATH}",
        f"Active memories: {stats['total_active']}",
        f"DB size: {stats['db_size_kb']}KB",
    ]

    if stats["by_type"]:
        lines.append("Types: " + ", ".join(
            f"{t}={c}" for t, c in sorted(stats["by_type"].items(), key=lambda x: -x[1])
        ))

    if feedbacks:
        lines.append("")
        lines.append("## Recent Feedback (from DB)")
        for fb in feedbacks[:5]:
            name = fb.get("name", "unnamed")
            # First line of content as summary
            content = fb.get("content", "")
            summary = content.split("\n")[0][:100] if content else ""
            lines.append(f"- **{name}**: {summary}")

    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(
        description="AIBrain MEMORY.md Sync -- keeps agent memory files current with DB"
    )
    parser.add_argument("--dry-run", action="store_true",
                        help="Show what would change without writing")
    parser.add_argument("--output", metavar="FILE",
                        help="Write sync section to specific file")
    parser.add_argument("--stats-only", action="store_true",
                        help="Only update stats (memory count, date) in existing files")
    parser.add_argument("--all", action="store_true",
                        help="Update all discovered MEMORY.md files")
    args = parser.parse_args()

    db = get_db()
    stats = get_memory_stats(db)
    feedbacks = get_recent_feedback(db)
    db.close()

    print(f"AIBrain MEMORY.md Sync")
    print(f"  DB: {DB_PATH}")
    print(f"  Active memories: {stats['total_active']}")
    print(f"  Types: {stats['by_type']}")

    # Satellite health check — suggest splitting if main DB is large
    try:
        import importlib.util
        spec = importlib.util.spec_from_file_location("aibrain_db", AIBRAIN_ROOT / "aibrain_db.py")
        if spec and spec.loader:
            aibrain_db = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(aibrain_db)
            check = aibrain_db.satellite_health_check()
            if check:
                print(f"\n  [SATELLITE SUGGESTION] {check['message']}")
                for s in check["suggestions"]:
                    print(f"    Type '{s['type']}': {s['count']} memories ({s['pct']}%)")
                print(f"    Run: python aibrain_db.py satellite health")
    except Exception:
        pass

    # Find MEMORY.md files
    if args.output:
        targets = [Path(args.output)]
    elif args.all:
        targets = find_memory_md_paths()
    else:
        targets = find_memory_md_paths()

    if not targets:
        print("  No MEMORY.md files found.")
        print("  Specify --output FILE or configure memory_md_path in config.json")
        # Still generate the section for stdout
        section = generate_sync_section(stats, feedbacks)
        print("\nGenerated sync section:")
        print(section)
        return

    for md_path in targets:
        print(f"\n  Target: {md_path}")

        if args.stats_only:
            if args.dry_run:
                print(f"    Would update stats + session context in {md_path}")
            else:
                updated = update_stats_in_memory_md(md_path, stats)
                # Also update LAST SESSION block with current session context
                session_ctx = build_session_context()
                session_updated = update_last_session(md_path, session_ctx)
                print(f"    Stats {'updated' if updated else 'no change'}, "
                      f"session {'updated' if session_updated else 'no change'}")
        else:
            section = generate_sync_section(stats, feedbacks)
            if args.dry_run:
                print(f"    Would update stats + append sync section")
                print(section)
            else:
                # Update stats inline
                update_stats_in_memory_md(md_path, stats)
                print(f"    Stats updated")


if __name__ == "__main__":
    main()
