#!/usr/bin/env python3
"""AIBrain Workflow: Morning Briefing — daily digest aggregating weather, email,
tasks, approvals, activity, and system status into one scannable report.

Scheduled 7am daily.  Reuses logic from email_triage.py and weather_briefing.py
so there's exactly one implementation of each capability.
"""

import argparse
import datetime
import json
import os
import smtplib
import sqlite3
import sys
import urllib.request
from email.mime.text import MIMEText
from pathlib import Path

# ---------------------------------------------------------------------------
# Sibling workflow imports
# ---------------------------------------------------------------------------
# Add workflows dir to path so we can import siblings
_workflows_dir = str(Path(__file__).parent)
if _workflows_dir not in sys.path:
    sys.path.insert(0, _workflows_dir)

from email_triage import fetch_unread, classify_email, decode_mime_header, get_body
from weather_briefing import fetch_weather, format_briefing, WMO_CODES, outfit_tip

# ---------------------------------------------------------------------------
# Config & DB helpers (same patterns as sibling workflows)
# ---------------------------------------------------------------------------

AIBRAIN_ROOT = Path(os.environ.get("AIBRAIN_ROOT",
                    os.environ.get("AIBRAIN_ROOT",
                    Path(__file__).parent.parent)))
_cfg_path = AIBRAIN_ROOT / "config.json"
CONFIG = json.loads(_cfg_path.read_text()) if _cfg_path.exists() else {}
def _find_db():
    """Find best DB path, checking both new and legacy names."""
    for name in ["aibrain.db"]:
        p = AIBRAIN_ROOT / name
        if p.exists():
            return str(p)
    configured = CONFIG.get("db_path")
    if configured and Path(configured).exists():
        return configured
    mem_db = AIBRAIN_ROOT / "memory" / "memory.db"
    if mem_db.exists():
        return str(mem_db)
    return str(AIBRAIN_ROOT / "aibrain.db")

MEMORY_DB = CONFIG.get("db_path", _find_db())
API_BASE = os.environ.get("AIBRAIN_API", os.environ.get("AIBRAIN_API", "http://localhost:8001/api/agent"))

STATE_NAME = "morning_briefing"


def get_db():
    db = sqlite3.connect(MEMORY_DB)
    db.execute("PRAGMA journal_mode=wal")
    db.row_factory = sqlite3.Row
    return db


def load_state(name):
    try:
        db = get_db()
        row = db.execute(
            "SELECT content FROM memories WHERE name=? AND active=1",
            (f"workflow_state:{name}",),
        ).fetchone()
        db.close()
        return json.loads(row["content"]) if row else {}
    except Exception:
        return {}


def save_state(name, state):
    db = get_db()
    try:
        now = datetime.datetime.now().isoformat()
        existing = db.execute(
            "SELECT id FROM memories WHERE name=? AND active=1",
            (f"workflow_state:{name}",),
        ).fetchone()
        if existing:
            db.execute("UPDATE memories SET content=?, updated=? WHERE id=?",
                       (json.dumps(state), now, existing["id"]))
        else:
            db.execute(
                "INSERT INTO memories (name,type,tags,content,created,updated,active) VALUES (?,?,?,?,?,?,1)",
                (f"workflow_state:{name}", "reference", "workflow,state",
                 json.dumps(state), now, now),
            )
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def send_email(to, subject, body, dry_run=False):
    if dry_run:
        print(f"TO: {to}\nSUBJECT: {subject}\n\n{body}")
        return
    agent_email = CONFIG.get("agent_email", "aibrain@localhost")
    agent_password = CONFIG.get("agent_email_password", CONFIG.get("email_app_password", ""))
    msg = MIMEText(body, "plain")
    msg["From"] = agent_email
    msg["To"] = to
    msg["Subject"] = subject
    with smtplib.SMTP_SSL(
        CONFIG.get("agent_smtp_host", CONFIG.get("email_smtp_host", "smtp.gmail.com")), 465
    ) as s:
        s.login(agent_email, agent_password)
        s.send_message(msg)


def log_activity(action, detail="", status="ok"):
    """Log to AIBrain activity feed."""
    try:
        data = json.dumps({
            "action": action,
            "category": "briefing",
            "detail": detail,
            "status": status,
        }).encode()
        req = urllib.request.Request(
            f"{API_BASE}/activity",
            data=data,
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# API helpers — each returns data or a sensible fallback on failure
# ---------------------------------------------------------------------------

def _api_get(endpoint, params=""):
    """GET from AIBrain API, returns parsed JSON or None."""
    url = f"{API_BASE}/{endpoint}"
    if params:
        url = f"{url}?{params}"
    try:
        req = urllib.request.Request(url, headers={"Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read().decode())
    except Exception:
        return None


def fetch_pending_approvals():
    """GET /api/agent/approvals?status=pending"""
    data = _api_get("approvals", "status=pending")
    if data is None:
        return []
    # API may return list directly or wrapped in {"approvals": [...]}
    if isinstance(data, list):
        return data
    return data.get("approvals", data.get("items", []))


def fetch_recent_activity(limit=20):
    """GET /api/agent/activity?limit=20"""
    data = _api_get("activity", f"limit={limit}")
    if data is None:
        return []
    if isinstance(data, list):
        return data
    return data.get("activity", data.get("items", []))


def fetch_workflow_runs(limit=10):
    """GET /api/agent/workflows/runs?limit=10"""
    data = _api_get("workflows/runs", f"limit={limit}")
    if data is None:
        return []
    if isinstance(data, list):
        return data
    return data.get("runs", data.get("items", []))


def fetch_cron_status():
    """GET /api/agent/crons"""
    data = _api_get("crons")
    if data is None:
        return []
    if isinstance(data, list):
        return data
    return data.get("crons", data.get("jobs", []))


def fetch_memory_summary():
    """GET /api/agent/memories/summary"""
    data = _api_get("memories/summary")
    if data is None:
        return {}
    return data


# ---------------------------------------------------------------------------
# Email aggregation (multi-account, reuses email_triage functions)
# ---------------------------------------------------------------------------

def collect_email_accounts():
    """Build list of IMAP accounts from config."""
    accounts = []

    agent_email = CONFIG.get("agent_email", "")
    agent_password = CONFIG.get("agent_email_password", CONFIG.get("email_app_password", ""))
    agent_imap = CONFIG.get("agent_imap_host", CONFIG.get("email_imap_host", "imap.gmail.com"))
    if agent_email and agent_password:
        accounts.append({
            "label": "agent",
            "email": agent_email,
            "password": agent_password,
            "imap_host": agent_imap,
        })

    for acct in CONFIG.get("email_accounts", []):
        if acct.get("monitor") and acct.get("email") and acct.get("app_password"):
            accounts.append({
                "label": acct.get("label", acct["email"].split("@")[0]),
                "email": acct["email"],
                "password": acct["app_password"],
                "imap_host": acct.get("imap_host", "imap.gmail.com"),
            })

    return accounts


def fetch_all_emails(accounts):
    """Fetch unread from every configured account. Returns (all_results, stats)."""
    all_results = []
    for acct in accounts:
        try:
            emails = fetch_unread(acct["imap_host"], acct["email"], acct["password"])
        except Exception as e:
            emails = [{"_error": str(e)}]
        all_results.append({
            "label": acct["label"],
            "email": acct["email"],
            "emails": [e for e in emails if "_error" not in e],
            "errors": [e["_error"] for e in emails if "_error" in e],
        })

    # Compute stats across accounts
    all_emails = [e for r in all_results for e in r["emails"]]
    stats = {
        "total": len(all_emails),
        "urgent": len([e for e in all_emails if e.get("category") == "urgent"]),
        "action": len([e for e in all_emails if e.get("category") == "action"]),
        "fyi": len([e for e in all_emails if e.get("category") == "fyi"]),
        "accounts": len(accounts),
    }
    return all_results, stats


# ---------------------------------------------------------------------------
# Weather section (reuses weather_briefing functions)
# ---------------------------------------------------------------------------

def collect_weather():
    """Fetch weather and return (section_lines, raw_data)."""
    lat = CONFIG.get("location_lat", -34.93)
    lon = CONFIG.get("location_lon", 138.60)
    location = CONFIG.get("location_name", "Your Location")

    try:
        data = fetch_weather(lat, lon)
    except Exception as e:
        return [f"WEATHER ({location})", f"  Unavailable: {e}", ""], None

    current = data.get("current_weather", {})
    daily = data.get("daily", {})

    lines = [f"WEATHER ({location})"]

    # Current conditions
    temp = current.get("temperature", "?")
    code = current.get("weathercode", -1)
    wind = current.get("windspeed", "?")
    lines.append(f"  Current: {temp}C, {WMO_CODES.get(code, 'Unknown')}")

    # Today's forecast
    if daily.get("time"):
        t_max = daily["temperature_2m_max"][0]
        t_min = daily["temperature_2m_min"][0]
        precip = daily["precipitation_sum"][0]
        wind_max = daily["windspeed_10m_max"][0]
        lines.append(f"  Today: High {t_max}C / Low {t_min}C -- {outfit_tip(t_max)}")
        lines.append(f"  Rain: {precip}mm | Wind: {wind_max} km/h")
        day_code = daily["weathercode"][0]
        if day_code >= 95:
            lines.append("  WARNING: Thunderstorms expected")
        if 71 <= day_code <= 77:
            lines.append("  WARNING: Snow -- check road conditions")
        if precip > 1:
            lines.append("  Reminder: Bring an umbrella")

    lines.append("")
    return lines, data


# ---------------------------------------------------------------------------
# Compose the full digest
# ---------------------------------------------------------------------------

def compose_briefing(weather_lines, email_results, email_stats,
                     approvals, activity, workflow_runs, crons, memory_summary):
    """Build the final formatted morning briefing string."""
    now = datetime.datetime.now()
    divider = "=" * 50

    lines = [
        f"MORNING BRIEFING -- {now.strftime('%A %B %d, %Y')}",
        divider,
        "",
    ]

    # --- WEATHER ---
    lines.extend(weather_lines)

    # --- EMAIL SUMMARY ---
    acct_label = f" ({email_stats['accounts']} accounts)" if email_stats["accounts"] > 1 else ""
    lines.append(f"EMAIL SUMMARY{acct_label}")
    lines.append(
        f"  {email_stats['urgent']} urgent | "
        f"{email_stats['action']} action required | "
        f"{email_stats['fyi']} FYI"
    )

    # Top urgent emails
    urgent_emails = [
        e for r in email_results for e in r["emails"]
        if e.get("category") == "urgent"
    ]
    if urgent_emails:
        lines.append("  Top urgent:")
        for e in urgent_emails[:5]:
            sender = e.get("sender_email", e.get("sender", "unknown"))
            subject = e.get("subject", "(no subject)")[:60]
            lines.append(f'    {sender} -- "{subject}"')

    # Top action-required emails
    action_emails = [
        e for r in email_results for e in r["emails"]
        if e.get("category") == "action"
    ]
    if action_emails:
        lines.append("  Top action required:")
        for e in action_emails[:5]:
            sender = e.get("sender_email", e.get("sender", "unknown"))
            subject = e.get("subject", "(no subject)")[:60]
            lines.append(f'    {sender} -- "{subject}"')

    if email_stats["total"] == 0:
        lines.append("  Inbox zero across all accounts!")

    # Per-account breakdown if multiple
    if email_stats["accounts"] > 1:
        lines.append("  Per account:")
        for r in email_results:
            lines.append(f"    {r['label']:20s} {len(r['emails']):3d} unread")

    lines.append("")

    # --- PENDING APPROVALS ---
    lines.append(f"PENDING APPROVALS ({len(approvals)})")
    if approvals:
        for a in approvals[:10]:
            cat = a.get("category", "general")
            title = a.get("title", a.get("detail", "Untitled"))[:60]
            lines.append(f"  [{cat}] {title}")
    else:
        lines.append("  None pending")
    lines.append("")

    # --- RECENT ACTIVITY ---
    # Filter to last 24h
    cutoff = (now - datetime.timedelta(hours=24)).isoformat()
    recent = [a for a in activity if a.get("timestamp", a.get("created", "")) >= cutoff]
    if not recent:
        recent = activity  # fallback: show whatever we got

    # Count categories
    wf_runs_24h = len([a for a in recent if "workflow" in a.get("action", "").lower()])
    memory_adds = len([a for a in recent if "memory" in a.get("action", "").lower()])
    approval_acts = len([a for a in recent if "approval" in a.get("action", "").lower()])

    lines.append(f"RECENT ACTIVITY (last 24h)")
    lines.append(
        f"  {wf_runs_24h} workflow actions | "
        f"{memory_adds} memory updates | "
        f"{approval_acts} approval actions"
    )
    if len(recent) > 0:
        lines.append("  Latest:")
        for a in recent[:5]:
            action = a.get("action", "unknown")
            detail = a.get("detail", "")[:50]
            ts = a.get("timestamp", a.get("created", ""))
            # Show just the time portion if today
            time_str = ts[11:16] if len(ts) > 16 else ts
            lines.append(f"    [{time_str}] {action}: {detail}")
    else:
        lines.append("  No activity recorded")
    lines.append("")

    # --- SYSTEM STATUS ---
    lines.append("SYSTEM STATUS")

    # Scheduler
    active_jobs = [j for j in crons if j.get("active", j.get("enabled", True))]
    lines.append(f"  Scheduler: {'Running' if crons else 'Unknown'} ({len(active_jobs)} active jobs)")

    # Workflow runs
    if workflow_runs:
        ok_runs = len([r for r in workflow_runs if r.get("status", "") in ("ok", "success", "completed")])
        fail_runs = len([r for r in workflow_runs if r.get("status", "") in ("error", "failed")])
        lines.append(f"  Recent runs: {len(workflow_runs)} total, {ok_runs} ok, {fail_runs} failed")

    # Memory
    if memory_summary:
        total_mem = memory_summary.get("total", memory_summary.get("count", "?"))
        lines.append(f"  Memories: {total_mem} total")
    else:
        lines.append("  Memories: unavailable")

    lines.append("")
    lines.append(divider)
    lines.append("Generated by AIBrain")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Main workflow
# ---------------------------------------------------------------------------

def run(dry_run=False):
    """Execute the full Morning Briefing pipeline."""
    now = datetime.datetime.now()
    print(f"[{now.strftime('%H:%M:%S')}] Running: morning_briefing")

    errors = []

    # 1. Weather
    print("  Fetching weather...")
    weather_lines, weather_data = collect_weather()

    # 2. Email triage
    print("  Checking email...")
    accounts = collect_email_accounts()
    if accounts:
        email_results, email_stats = fetch_all_emails(accounts)
    else:
        email_results = []
        email_stats = {"total": 0, "urgent": 0, "action": 0, "fyi": 0, "accounts": 0}
        errors.append("No email accounts configured")
        print("  (no email accounts configured)")

    # 3. Pending approvals
    print("  Checking approvals...")
    approvals = fetch_pending_approvals()

    # 4. Recent activity
    print("  Fetching activity...")
    activity = fetch_recent_activity(limit=20)

    # 5. Workflow run stats
    print("  Fetching workflow runs...")
    workflow_runs = fetch_workflow_runs(limit=10)

    # 6. Cron / scheduler status
    print("  Checking scheduler...")
    crons = fetch_cron_status()

    # 7. Memory summary
    print("  Fetching memory stats...")
    memory_summary = fetch_memory_summary()

    # 8. Compose digest
    briefing = compose_briefing(
        weather_lines=weather_lines,
        email_results=email_results,
        email_stats=email_stats,
        approvals=approvals,
        activity=activity,
        workflow_runs=workflow_runs,
        crons=crons,
        memory_summary=memory_summary,
    )

    # 9. Output
    if dry_run:
        print()
        print(briefing)
    else:
        # Send email
        email_to = CONFIG.get("email_to", CONFIG.get("agent_email", ""))
        if email_to:
            subject_parts = [f"Morning Briefing -- {now.strftime('%b %d')}"]
            if email_stats["urgent"]:
                subject_parts.insert(0, f"[{email_stats['urgent']} URGENT]")
            subject = " ".join(subject_parts)
            try:
                send_email(email_to, subject, briefing)
                print(f"  Sent briefing to {email_to}")
            except Exception as e:
                errors.append(f"Email send failed: {e}")
                print(f"  Email send failed: {e}")
                # Fall back to printing
                print()
                print(briefing)
        else:
            print()
            print(briefing)

        # Log activity
        log_activity(
            "workflow:morning_briefing",
            f"Briefing generated: {email_stats['total']} emails, "
            f"{len(approvals)} approvals, "
            f"{len(activity)} activities",
        )

    # 10. Save state
    state = {
        "last_run": now.isoformat(),
        "email_stats": email_stats,
        "approvals_pending": len(approvals),
        "activity_count": len(activity),
        "workflow_runs_count": len(workflow_runs),
        "crons_active": len([j for j in crons if j.get("active", j.get("enabled", True))]),
        "memory_summary": memory_summary if memory_summary else {},
        "weather_available": weather_data is not None,
        "errors": errors,
    }
    try:
        save_state(STATE_NAME, state)
    except Exception as e:
        print(f"  Warning: could not save state: {e}")

    if errors:
        print(f"  Completed with {len(errors)} warning(s): {'; '.join(errors)}")
    else:
        print("  Morning briefing complete.")


def main():
    parser = argparse.ArgumentParser(
        description="AIBrain Morning Briefing — daily digest of weather, email, tasks, and system status"
    )
    parser.add_argument("--dry-run", action="store_true", help="Print digest only, do not send email")
    args = parser.parse_args()
    run(dry_run=args.dry_run)


if __name__ == "__main__":
    main()
