#!/usr/bin/env python3
"""AIBrain Workflow: Memory Consolidation — cluster related memories, create summaries, flag stale entries.

Runs weekly (Sunday). Implements episodic-to-semantic memory consolidation:
1. Groups memories by type
2. Finds clusters via Jaccard similarity on tokenized content
3. Consolidates clusters of 5+ into summary memories
4. Flags stale memories (unaccessed for 30+ days with access_count=0)

Usage:
    python memory_consolidation.py              # Full consolidation run
    python memory_consolidation.py --dry-run    # Report only, no DB changes
    python memory_consolidation.py --report     # Stats and cluster preview only
    python memory_consolidation.py --threshold 0.25  # Custom similarity threshold
"""

import argparse
import json
import os
import re
import sqlite3
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path
import urllib.request

AIBRAIN_ROOT = Path(os.environ.get("AIBRAIN_ROOT",
                    os.environ.get("AIBRAIN_ROOT",
                    Path(__file__).parent.parent)))
API_BASE = os.environ.get("AIBRAIN_API", os.environ.get("AIBRAIN_API", "http://localhost:8001/api/agent"))
CONFIG = json.loads((AIBRAIN_ROOT / "config.json").read_text()) if (AIBRAIN_ROOT / "config.json").exists() else {}
def _find_db():
    for name in ["aibrain.db"]:
        p = AIBRAIN_ROOT / name
        if p.exists():
            return str(p)
    configured = CONFIG.get("db_path")
    if configured and Path(configured).exists():
        return configured
    mem_db = AIBRAIN_ROOT / "memory" / "memory.db"
    if mem_db.exists():
        return str(mem_db)
    return str(AIBRAIN_ROOT / "aibrain.db")


DB_PATH = CONFIG.get("db_path", _find_db())

# Similarity threshold — memories must share this fraction of tokens to cluster together.
# 0.3 is conservative; lower catches more but risks false groupings.
DEFAULT_THRESHOLD = 0.3

# Minimum cluster size to trigger consolidation
MIN_CLUSTER_SIZE = 5

# Days without access before a memory is considered stale
STALE_DAYS = 30

# Stopwords to exclude from tokenization (common English + technical boilerplate)
STOPWORDS = frozenset({
    "the", "and", "for", "that", "this", "with", "from", "are", "was", "were",
    "been", "being", "have", "has", "had", "does", "did", "will", "would",
    "could", "should", "may", "might", "shall", "can", "need", "must",
    "into", "through", "during", "before", "after", "above", "below",
    "between", "under", "again", "further", "then", "once", "here", "there",
    "when", "where", "which", "while", "about", "against", "each", "every",
    "both", "more", "most", "other", "some", "such", "than", "very",
    "also", "just", "only", "same", "than", "them", "they", "their",
    "what", "your", "yours", "these", "those", "because", "like", "over",
    "still", "well", "back", "even", "much", "many", "make", "made",
    "used", "using", "use", "uses", "none", "true", "false", "null",
    "http", "https", "www", "com", "org", "default", "value", "values",
    "file", "files", "path", "paths", "line", "lines", "text",
    "data", "type", "name", "list", "item", "items", "note", "notes",
})


def log_activity(action, detail="", status="ok"):
    """Log activity to AIBrain API."""
    try:
        data = json.dumps({
            "action": action, "category": "system",
            "detail": detail, "status": status,
        }).encode()
        req = urllib.request.Request(
            f"{API_BASE}/activity", data=data,
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        pass


def get_db():
    """Open connection to aibrain.db with Row factory."""
    db = sqlite3.connect(DB_PATH)
    db.execute("PRAGMA journal_mode=wal")
    db.row_factory = sqlite3.Row
    return db


def load_active_memories(db):
    """Load all active memories from the database."""
    rows = db.execute(
        "SELECT id, name, type, tags, content, created, updated, active, "
        "memory_class, importance, access_count, last_accessed, source_agent, consolidated_from "
        "FROM memories WHERE active = 1"
    ).fetchall()
    return [dict(r) for r in rows]


def tokenize(text):
    """Extract significant tokens from text. Returns a set of lowercase words (4+ chars), minus stopwords."""
    if not text:
        return set()
    words = re.findall(r'[a-z][a-z0-9_]{3,}', text.lower())
    return set(words) - STOPWORDS


def get_tags_set(mem):
    """Parse comma-separated tags into a set."""
    tags = mem.get("tags", "") or ""
    return set(t.strip().lower() for t in tags.split(",") if t.strip())


def get_name_prefix(name):
    """Extract prefix from a memory name, e.g., 'project_aibrain' from 'project_aibrain_vision'."""
    if not name:
        return ""
    parts = name.split("_")
    if len(parts) >= 2:
        return "_".join(parts[:2])
    return parts[0]


def jaccard_similarity(set_a, set_b):
    """Compute Jaccard similarity between two sets."""
    if not set_a or not set_b:
        return 0.0
    intersection = len(set_a & set_b)
    union = len(set_a | set_b)
    return intersection / union if union > 0 else 0.0


def compute_similarity(mem_a, mem_b):
    """Compute composite similarity between two memories using three signals."""
    text_a = (mem_a.get("name", "") or "") + " " + (mem_a.get("content", "") or "")
    text_b = (mem_b.get("name", "") or "") + " " + (mem_b.get("content", "") or "")

    tokens_a = tokenize(text_a)
    tokens_b = tokenize(text_b)

    # Signal 1: Token-level Jaccard similarity (primary)
    token_sim = jaccard_similarity(tokens_a, tokens_b)

    # Signal 2: Tag overlap bonus
    tags_a = get_tags_set(mem_a)
    tags_b = get_tags_set(mem_b)
    tag_sim = jaccard_similarity(tags_a, tags_b) if tags_a and tags_b else 0.0

    # Signal 3: Name prefix match bonus
    prefix_a = get_name_prefix(mem_a.get("name", ""))
    prefix_b = get_name_prefix(mem_b.get("name", ""))
    prefix_bonus = 0.15 if (prefix_a and prefix_b and prefix_a == prefix_b) else 0.0

    # Weighted composite: tokens are primary, tags and prefix are boosters
    score = token_sim * 0.7 + tag_sim * 0.15 + prefix_bonus
    return min(score, 1.0)


def greedy_cluster(memories, threshold):
    """Greedy agglomerative clustering. Returns list of clusters (each a list of memory dicts).

    Algorithm:
    - For each unclustered memory, find all unclustered memories above threshold
    - If the group (including seed) has 2+ members, form a cluster
    - Conservative: a memory can only belong to one cluster
    """
    clustered_ids = set()
    clusters = []

    # Pre-compute token sets for speed
    token_cache = {}
    for mem in memories:
        text = (mem.get("name", "") or "") + " " + (mem.get("content", "") or "")
        token_cache[mem["id"]] = tokenize(text)

    # Sort by importance descending so high-importance memories seed clusters first
    sorted_mems = sorted(memories, key=lambda m: m.get("importance", 0.5), reverse=True)

    for seed in sorted_mems:
        if seed["id"] in clustered_ids:
            continue

        cluster = [seed]
        for candidate in sorted_mems:
            if candidate["id"] == seed["id"] or candidate["id"] in clustered_ids:
                continue
            sim = compute_similarity(seed, candidate)
            if sim >= threshold:
                cluster.append(candidate)

        if len(cluster) >= 2:
            # Only keep the cluster if it could eventually reach MIN_CLUSTER_SIZE
            # But always record clusters >= 2 for reporting
            for mem in cluster:
                clustered_ids.add(mem["id"])
            clusters.append(cluster)

    return clusters


def generate_cluster_label(cluster):
    """Generate a human-readable label for a cluster based on shared tokens."""
    all_tokens = []
    for mem in cluster:
        text = (mem.get("name", "") or "") + " " + (mem.get("content", "") or "")
        all_tokens.extend(tokenize(text))

    # Count token frequency across cluster members
    freq = defaultdict(int)
    for mem in cluster:
        text = (mem.get("name", "") or "") + " " + (mem.get("content", "") or "")
        for token in tokenize(text):
            freq[token] += 1

    # Tokens that appear in most cluster members are the shared theme
    threshold = max(2, len(cluster) // 2)
    shared = sorted(
        [t for t, c in freq.items() if c >= threshold],
        key=lambda t: freq[t],
        reverse=True,
    )

    # Build a label from top shared tokens
    label_tokens = shared[:4]
    if label_tokens:
        return " ".join(t.title() for t in label_tokens)
    # Fallback: use most common name prefix
    prefixes = defaultdict(int)
    for mem in cluster:
        prefix = get_name_prefix(mem.get("name", ""))
        if prefix:
            prefixes[prefix] += 1
    if prefixes:
        best_prefix = max(prefixes, key=prefixes.get)
        return best_prefix.replace("_", " ").title()
    return "Unnamed Cluster"


def generate_consolidation_content(cluster, label):
    """Generate consolidated content from a cluster of memories."""
    lines = []
    lines.append(f"# Consolidated: {label}")
    lines.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    lines.append(f"Source memories: {len(cluster)}")
    lines.append("")

    # Collect unique key points from all memories
    seen_points = set()
    for mem in cluster:
        content = (mem.get("content", "") or "").strip()
        name = mem.get("name", "unknown")
        if content:
            # Take first 3 meaningful lines from each memory's content
            content_lines = [ln.strip() for ln in content.split("\n") if ln.strip() and not ln.strip().startswith("#")]
            for ln in content_lines[:3]:
                # Deduplicate by normalized form
                normalized = re.sub(r'\s+', ' ', ln.lower().strip())
                if normalized not in seen_points and len(normalized) > 10:
                    seen_points.add(normalized)
                    lines.append(f"- [{name}] {ln}")

    if not seen_points:
        # If no content, at least list the memory names
        lines.append("## Member memories:")
        for mem in cluster:
            lines.append(f"- {mem.get('name', 'unknown')} (type: {mem.get('type', '?')})")

    return "\n".join(lines)


def collect_tags_from_cluster(cluster):
    """Merge all tags from cluster members, add consolidation markers."""
    all_tags = set()
    for mem in cluster:
        all_tags |= get_tags_set(mem)
    # Remove any previous stale/consolidated markers
    all_tags -= {"stale", "auto-generated", "consolidated"}
    all_tags.add("consolidated")
    all_tags.add("auto-generated")
    return ",".join(sorted(all_tags))


def find_stale_memories(memories, stale_days):
    """Find memories that haven't been accessed in stale_days and have access_count=0."""
    cutoff = datetime.now() - timedelta(days=stale_days)
    stale = []
    for mem in memories:
        access_count = mem.get("access_count", 0) or 0
        if access_count > 0:
            continue
        # Check last_accessed
        last_accessed = mem.get("last_accessed")
        if last_accessed:
            try:
                la_dt = datetime.fromisoformat(last_accessed)
                if la_dt > cutoff:
                    continue
            except (ValueError, TypeError):
                pass
        # If never accessed, check created date
        created = mem.get("created", "")
        if created:
            try:
                cr_dt = datetime.fromisoformat(created)
                if cr_dt > cutoff:
                    continue  # Too new to call stale
            except (ValueError, TypeError):
                pass

        # Skip already-tagged stale or consolidated memories
        tags = get_tags_set(mem)
        if "stale" in tags or "consolidated" in tags or "auto-generated" in tags:
            continue

        stale.append(mem)
    return stale


def run_consolidation(dry_run=False, report_only=False, threshold=DEFAULT_THRESHOLD,
                      min_cluster=MIN_CLUSTER_SIZE, stale_days=STALE_DAYS):
    """Main consolidation workflow."""
    db = get_db()
    now = datetime.now()
    report_lines = []

    def report(line=""):
        report_lines.append(line)
        print(line)

    report(f"MEMORY CONSOLIDATION REPORT — {now.strftime('%Y-%m-%d')}")
    report("=" * 50)

    # Load memories
    memories = load_active_memories(db)
    report(f"Total active memories: {len(memories)}")

    if not memories:
        report("No active memories found. Nothing to do.")
        db.close()
        return "\n".join(report_lines)

    # Group by type
    by_type = defaultdict(list)
    for mem in memories:
        by_type[mem.get("type", "unknown")].append(mem)

    type_summary = ", ".join(f"{t}({len(mems)})" for t, mems in sorted(by_type.items()))
    report(f"By type: {type_summary}")
    report(f"Similarity threshold: {threshold}")
    report(f"Min cluster size for consolidation: {min_cluster}")
    report("")

    # Find clusters within each type
    all_clusters = []
    for mem_type, type_memories in sorted(by_type.items()):
        if len(type_memories) < 2:
            continue
        clusters = greedy_cluster(type_memories, threshold)
        for cluster in clusters:
            all_clusters.append((mem_type, cluster))

    # Sort clusters by size descending
    all_clusters.sort(key=lambda x: len(x[1]), reverse=True)

    # Report clusters
    consolidatable = [(t, c) for t, c in all_clusters if len(c) >= min_cluster]
    small_clusters = [(t, c) for t, c in all_clusters if len(c) < min_cluster]

    report(f"CLUSTERS FOUND: {len(all_clusters)} total ({len(consolidatable)} consolidatable, {len(small_clusters)} below threshold)")
    report("")

    consolidations_created = 0

    for idx, (mem_type, cluster) in enumerate(consolidatable, 1):
        label = generate_cluster_label(cluster)
        report(f"  Cluster {idx}: \"{label}\" ({len(cluster)} memories, type: {mem_type})")
        for mem in cluster:
            report(f"    - {mem['name']} (id: {mem['id']})")

        if report_only:
            report(f"    -> Would create consolidation: \"{label} Summary\"")
        elif dry_run:
            report(f"    -> [DRY RUN] Would create consolidation: \"{label} Summary\"")
        else:
            # Create the consolidation memory
            content = generate_consolidation_content(cluster, label)
            tags = collect_tags_from_cluster(cluster)
            source_ids = ",".join(str(m["id"]) for m in cluster)
            cons_name = f"consolidated_{mem_type}_{label.lower().replace(' ', '_')}"
            # Truncate name if too long
            if len(cons_name) > 80:
                cons_name = cons_name[:80]

            db.execute(
                "INSERT INTO memories (name, type, tags, content, created, updated, active, "
                "memory_class, importance, access_count, source_agent, consolidated_from) "
                "VALUES (?, 'reference', ?, ?, ?, ?, 1, 'semantic', 0.6, 0, 'memory_consolidation', ?)",
                (cons_name, tags, content, now.isoformat(), now.isoformat(), source_ids),
            )
            new_id = db.execute("SELECT last_insert_rowid()").fetchone()[0]

            # Mark originals with consolidated_into reference via tags
            for mem in cluster:
                existing_tags = mem.get("tags", "") or ""
                marker = f"consolidated_into:{new_id}"
                if marker not in existing_tags:
                    new_tags = f"{existing_tags},{marker}" if existing_tags else marker
                    db.execute(
                        "UPDATE memories SET tags = ?, updated = ? WHERE id = ?",
                        (new_tags, now.isoformat(), mem["id"]),
                    )

            consolidations_created += 1
            report(f"    -> Created consolidation: \"{cons_name}\" (id: {new_id})")
        report("")

    # Show small clusters for reference
    if small_clusters:
        report(f"SMALL CLUSTERS (below {min_cluster} threshold): {len(small_clusters)}")
        for mem_type, cluster in small_clusters[:10]:  # Cap at 10 for readability
            label = generate_cluster_label(cluster)
            names = ", ".join(m["name"] for m in cluster[:3])
            suffix = f" + {len(cluster) - 3} more" if len(cluster) > 3 else ""
            report(f"  - \"{label}\" ({len(cluster)}, {mem_type}): {names}{suffix}")
        if len(small_clusters) > 10:
            report(f"  ... and {len(small_clusters) - 10} more small clusters")
        report("")

    # Find stale memories
    stale = find_stale_memories(memories, stale_days)
    stale_flagged = 0

    report(f"STALE MEMORIES: {len(stale)}")
    if stale:
        for mem in stale[:20]:  # Cap display at 20
            created = mem.get("created", "unknown")
            last_acc = mem.get("last_accessed", "never")
            report(f"  - {mem['name']} (id: {mem['id']}, created: {created}, last accessed: {last_acc})")

            if not report_only and not dry_run:
                existing_tags = mem.get("tags", "") or ""
                if "stale" not in existing_tags:
                    new_tags = f"{existing_tags},stale" if existing_tags else "stale"
                    db.execute(
                        "UPDATE memories SET tags = ?, updated = ? WHERE id = ?",
                        (new_tags, now.isoformat(), mem["id"]),
                    )
                    stale_flagged += 1
            elif dry_run:
                stale_flagged += 1  # Count for dry-run report

        if len(stale) > 20:
            report(f"  ... and {len(stale) - 20} more stale memories")
    report("")

    # Summary
    report("=" * 50)
    mode = "[DRY RUN] " if dry_run else "[REPORT ONLY] " if report_only else ""
    report(f"{mode}Summary: {consolidations_created} consolidations created, {len(stale)} memories flagged stale")

    if not report_only and not dry_run:
        db.commit()
        report("Changes committed to database.")
        log_activity(
            "memory_consolidation",
            f"Consolidated {consolidations_created} clusters, flagged {stale_flagged} stale from {len(memories)} active memories",
        )
    elif dry_run:
        report("No changes made (dry run).")
    else:
        report("No changes made (report only).")

    report("=" * 50)
    db.close()

    full_report = "\n".join(report_lines)

    # Save report to file
    reports_dir = AIBRAIN_ROOT / "reports"
    reports_dir.mkdir(exist_ok=True)
    report_path = reports_dir / f"memory_consolidation_{now.strftime('%Y%m%d_%H%M%S')}.txt"
    report_path.write_text(full_report, encoding="utf-8")
    print(f"\nReport saved: {report_path}")

    return full_report


def main():
    parser = argparse.ArgumentParser(
        description="Memory Consolidation — cluster related memories, create summaries, flag stale entries."
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help="Report what would be done without making changes",
    )
    parser.add_argument(
        "--report", action="store_true",
        help="Show memory stats and cluster preview only",
    )
    parser.add_argument(
        "--threshold", type=float, default=DEFAULT_THRESHOLD,
        help=f"Similarity threshold for clustering (default: {DEFAULT_THRESHOLD})",
    )
    parser.add_argument(
        "--min-cluster", type=int, default=MIN_CLUSTER_SIZE,
        help=f"Minimum cluster size for consolidation (default: {MIN_CLUSTER_SIZE})",
    )
    parser.add_argument(
        "--stale-days", type=int, default=STALE_DAYS,
        help=f"Days without access to flag as stale (default: {STALE_DAYS})",
    )

    args = parser.parse_args()

    run_consolidation(
        dry_run=args.dry_run,
        report_only=args.report,
        threshold=args.threshold,
        min_cluster=args.min_cluster,
        stale_days=args.stale_days,
    )


if __name__ == "__main__":
    main()
