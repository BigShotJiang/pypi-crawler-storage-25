"""
Tests for the REST memory API endpoints (no-MCP mode).

Covers: POST /api/memory/store, /search, /recall, GET /stats
These mirror the MCP memory_store, memory_search, memory_recall, memory_stats tools.
"""

import pytest


class TestMemoryStore:
    """POST /api/memory/store — store, update, and dedup memories."""

    def test_store_new_memory(self, test_client, clean_db):
        """Storing a new memory returns action=added with an id."""
        resp = test_client.post("/api/memory/store", json={
            "name": "test_timezone",
            "content": "User timezone is Australia/Adelaide (UTC+9:30)",
            "type": "user",
            "tags": "preference,timezone",
            "importance": 0.8,
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["action"] == "added"
        assert "id" in data
        assert data["id"] > 0

    def test_store_duplicate_noop(self, test_client, clean_db):
        """Storing identical content under the same name is a no-op."""
        payload = {
            "name": "dedup_test",
            "content": "Exact same content",
            "type": "reference",
        }
        r1 = test_client.post("/api/memory/store", json=payload)
        assert r1.status_code == 200
        assert r1.json()["action"] == "added"

        r2 = test_client.post("/api/memory/store", json=payload)
        assert r2.status_code == 200
        assert r2.json()["action"] == "none"

    def test_store_update_on_content_change(self, test_client, clean_db):
        """Storing different content under the same name triggers an update."""
        name = "update_test"
        r1 = test_client.post("/api/memory/store", json={
            "name": name,
            "content": "Version 1",
        })
        assert r1.json()["action"] == "added"
        first_id = r1.json()["id"]

        r2 = test_client.post("/api/memory/store", json={
            "name": name,
            "content": "Version 2 — updated",
        })
        assert r2.json()["action"] == "updated"
        assert r2.json()["id"] == first_id  # Same ID, content replaced

    def test_store_validation_missing_name(self, test_client):
        """Missing required 'name' field returns 422."""
        resp = test_client.post("/api/memory/store", json={
            "content": "No name provided",
        })
        assert resp.status_code == 422

    def test_store_validation_missing_content(self, test_client):
        """Missing required 'content' field returns 422."""
        resp = test_client.post("/api/memory/store", json={
            "name": "no_content",
        })
        assert resp.status_code == 422

    def test_store_validation_invalid_type(self, test_client):
        """Invalid memory type returns 422."""
        resp = test_client.post("/api/memory/store", json={
            "name": "bad_type",
            "content": "Some content",
            "type": "invalid_type",
        })
        assert resp.status_code == 422

    def test_store_validation_importance_range(self, test_client):
        """Importance outside [0.0, 1.0] returns 422."""
        resp = test_client.post("/api/memory/store", json={
            "name": "bad_importance",
            "content": "Some content",
            "importance": 2.0,
        })
        assert resp.status_code == 422

    def test_store_defaults(self, test_client, clean_db):
        """Defaults are applied: type=reference, importance=0.5, tags=''."""
        resp = test_client.post("/api/memory/store", json={
            "name": "defaults_test",
            "content": "Minimal input",
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["action"] == "added"


class TestMemorySearch:
    """POST /api/memory/search — full-text + semantic search."""

    def test_search_finds_stored_memory(self, test_client, clean_db):
        """Search returns a previously stored memory."""
        test_client.post("/api/memory/store", json={
            "name": "python_preference",
            "content": "User prefers Python 3.11 for all new projects",
            "type": "user",
            "tags": "python,preference",
        })

        resp = test_client.post("/api/memory/search", json={
            "query": "Python projects",
            "limit": 5,
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["count"] >= 1
        assert any("python" in r["name"].lower() or "python" in r["content"].lower()
                    for r in data["results"])

    def test_search_empty_results(self, test_client, clean_db):
        """Search with no matches returns empty results list."""
        resp = test_client.post("/api/memory/search", json={
            "query": "xyznonexistent12345",
            "limit": 5,
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["count"] == 0
        assert data["results"] == []

    def test_search_with_type_hint(self, test_client, clean_db):
        """Search with explicit search_type routing hint."""
        test_client.post("/api/memory/store", json={
            "name": "fav_editor",
            "content": "User prefers VSCode over Vim",
            "type": "user",
        })

        resp = test_client.post("/api/memory/search", json={
            "query": "prefer VSCode",
            "search_type": "preference",
            "limit": 5,
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["search_type"] == "preference"

    def test_search_validation_missing_query(self, test_client):
        """Missing 'query' field returns 422."""
        resp = test_client.post("/api/memory/search", json={
            "limit": 5,
        })
        assert resp.status_code == 422

    def test_search_validation_invalid_search_type(self, test_client):
        """Invalid search_type returns 422."""
        resp = test_client.post("/api/memory/search", json={
            "query": "test",
            "search_type": "bogus",
        })
        assert resp.status_code == 422

    def test_search_respects_limit(self, test_client, clean_db):
        """Search respects the limit parameter."""
        # Store several memories
        for i in range(5):
            test_client.post("/api/memory/store", json={
                "name": f"bulk_item_{i}",
                "content": f"Bulk test content number {i} about AIBrain memory",
            })

        resp = test_client.post("/api/memory/search", json={
            "query": "bulk test AIBrain memory",
            "limit": 2,
        })
        assert resp.status_code == 200
        assert resp.json()["count"] <= 2


class TestMemoryRecall:
    """POST /api/memory/recall — recall by importance."""

    def test_recall_returns_memories(self, test_client, clean_db):
        """Recall returns stored memories ordered by importance."""
        test_client.post("/api/memory/store", json={
            "name": "high_importance_mem",
            "content": "Critical system rule",
            "type": "feedback",
            "importance": 0.95,
        })
        test_client.post("/api/memory/store", json={
            "name": "low_importance_mem",
            "content": "Minor note",
            "type": "reference",
            "importance": 0.1,
        })

        resp = test_client.post("/api/memory/recall", json={"limit": 10})
        assert resp.status_code == 200
        data = resp.json()
        assert data["count"] >= 2

        # Higher importance should come first
        results = data["results"]
        if len(results) >= 2:
            assert results[0]["importance"] >= results[-1]["importance"]

    def test_recall_filter_by_type(self, test_client, clean_db):
        """Recall with type filter returns only memories of that type."""
        test_client.post("/api/memory/store", json={
            "name": "user_mem",
            "content": "User info",
            "type": "user",
        })
        test_client.post("/api/memory/store", json={
            "name": "project_mem",
            "content": "Project info",
            "type": "project",
        })

        resp = test_client.post("/api/memory/recall", json={
            "type": "user",
            "limit": 50,
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["type_filter"] == "user"
        assert all(r["type"] == "user" for r in data["results"])

    def test_recall_empty(self, test_client, clean_db):
        """Recall with no memories returns empty results."""
        resp = test_client.post("/api/memory/recall", json={
            "type": "decision",
            "limit": 5,
        })
        assert resp.status_code == 200
        assert resp.json()["count"] == 0

    def test_recall_default_params(self, test_client, clean_db):
        """Recall with empty body uses defaults (no type filter, limit=10)."""
        test_client.post("/api/memory/store", json={
            "name": "any_mem",
            "content": "Some content",
        })

        resp = test_client.post("/api/memory/recall", json={})
        assert resp.status_code == 200
        data = resp.json()
        assert data["type_filter"] is None
        assert data["count"] >= 1

    def test_recall_validation_invalid_type(self, test_client):
        """Invalid type filter returns 422."""
        resp = test_client.post("/api/memory/recall", json={
            "type": "bogus_type",
        })
        assert resp.status_code == 422


class TestMemoryStats:
    """GET /api/memory/stats — system statistics."""

    def test_stats_returns_structure(self, test_client, clean_db):
        """Stats returns expected fields."""
        resp = test_client.get("/api/memory/stats")
        assert resp.status_code == 200
        data = resp.json()
        assert "total_memories" in data
        assert "by_type" in data
        assert "db_path" in data
        assert "embeddings_enabled" in data
        assert isinstance(data["total_memories"], int)
        assert isinstance(data["by_type"], dict)

    def test_stats_counts_match(self, test_client, clean_db):
        """Stats total matches actual stored memories."""
        # Store a few memories
        for i in range(3):
            test_client.post("/api/memory/store", json={
                "name": f"stats_test_{i}",
                "content": f"Content {i}",
                "type": "reference",
            })

        resp = test_client.get("/api/memory/stats")
        data = resp.json()
        assert data["total_memories"] >= 3

    def test_stats_by_type_breakdown(self, test_client, clean_db):
        """Stats by_type shows correct type breakdown."""
        test_client.post("/api/memory/store", json={
            "name": "type_count_user",
            "content": "User data",
            "type": "user",
        })
        test_client.post("/api/memory/store", json={
            "name": "type_count_project",
            "content": "Project data",
            "type": "project",
        })

        resp = test_client.get("/api/memory/stats")
        data = resp.json()
        assert "user" in data["by_type"]
        assert "project" in data["by_type"]
        assert data["by_type"]["user"] >= 1
        assert data["by_type"]["project"] >= 1
