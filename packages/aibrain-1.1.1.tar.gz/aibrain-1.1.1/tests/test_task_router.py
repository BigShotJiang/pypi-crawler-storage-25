"""
Tests for task_router.py — classify() and route() functions.

Covers domain classification, action classification, routing table lookups,
and TaskRouter orchestration.
"""

import pytest
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from task_router import (
    classify, route, TaskType, ExecutionStrategy, TaskRouter,
    DirectBackend, CLIBackend,
)


class TestClassify:
    """classify() — keyword-based domain and action classification."""

    def test_classify_security_scan(self):
        """Security scan keywords -> domain=security, action=scan."""
        result = classify("scan target_app for SQL injection vulnerabilities")
        assert result.domain == "security"
        assert result.action == "scan"
        assert result.confidence > 0

    def test_classify_jobs_search(self):
        """Job search keywords -> domain=jobs, action=search."""
        result = classify("search for Python developer jobs in Remote")
        assert result.domain == "jobs"
        assert result.action == "search"

    def test_classify_memory_search(self):
        """Memory keywords -> domain=memory."""
        result = classify("search memories for timezone preference")
        assert result.domain == "memory"
        assert result.action == "search"

    def test_classify_content_publish(self):
        """Content/publish keywords -> domain=content, action=publish."""
        result = classify("publish a LinkedIn post about AIBrain")
        assert result.domain == "content"
        assert result.action == "publish"

    def test_classify_email_respond(self):
        """Email reply keywords -> domain=email, action=respond."""
        result = classify("reply to the recruiter email from Acme Corp")
        assert result.domain == "email"
        assert result.action == "respond"

    def test_classify_general_fallback(self):
        """Unrecognized input -> domain=general, low confidence."""
        result = classify("what is the weather today")
        assert result.domain in ("general", "health")  # might match health
        assert result.confidence <= 1.0

    def test_classify_dict_input(self):
        """Dict input is treated as pre-classified."""
        result = classify({
            "domain": "trading",
            "action": "trade",
            "complexity": "complex",
        })
        assert result.domain == "trading"
        assert result.action == "trade"
        assert result.complexity == "complex"
        assert result.confidence == 1.0

    def test_classify_complexity_reactive(self):
        """Reactive keywords set complexity=reactive."""
        result = classify("monitor and watch for new CVEs continuously")
        assert result.complexity == "reactive"

    def test_classify_complexity_complex(self):
        """Comprehensive/full keywords set complexity=complex."""
        result = classify("run a comprehensive full security audit")
        assert result.complexity == "complex"

    def test_classify_task_type_key(self):
        """TaskType.key is domain.action."""
        result = classify("scan for vulnerabilities")
        assert result.key == f"{result.domain}.{result.action}"  # noqa:PLAIN SECRET COMPARISON -- test assertion not secret

    def test_classify_trading_domain(self):
        """Trading keywords -> domain=trading."""
        result = classify("check my portfolio PnL and drawdown")
        assert result.domain == "trading"

    def test_classify_automation_domain(self):
        """Automation keywords -> domain=automation."""
        result = classify("create a cron schedule for the workflow")
        assert result.domain == "automation"


class TestRoute:
    """route() — execution strategy lookup from routing table."""

    def test_route_known_key(self):
        """Known (domain, action) returns matching strategy."""
        task_type = TaskType(domain="memory", action="search")
        strategy = route(task_type)
        assert strategy.name == "mem_search"
        assert strategy.backend == "mcp_tool"

    def test_route_fallback_to_domain_execute(self):
        """Unknown action falls back to (domain, 'execute')."""
        task_type = TaskType(domain="memory", action="unknown_action")
        strategy = route(task_type)
        # Should fall back to ("memory", "execute") which is mem_recall
        assert strategy.name in ("mem_recall", "noop")

    def test_route_general_fallback(self):
        """Unknown domain falls back to general strategy."""
        task_type = TaskType(domain="nonexistent_domain", action="execute")
        strategy = route(task_type)
        # Falls through to general fallback
        assert isinstance(strategy, ExecutionStrategy)

    def test_route_custom_table(self):
        """Custom routing table overrides defaults."""
        custom_strategy = ExecutionStrategy(name="custom_test", backend="direct")
        custom_table = {
            ("custom", "action"): custom_strategy,
        }
        task_type = TaskType(domain="custom", action="action")
        result = route(task_type, routing_table=custom_table)
        assert result.name == "custom_test"

    def test_route_security_scan(self):
        """Security scan routes to reactive engine."""
        task_type = TaskType(domain="security", action="scan")
        strategy = route(task_type)
        assert strategy.name == "sec_scan"
        assert strategy.backend == "reactive_engine"


class TestTaskRouter:
    """TaskRouter — the orchestrator class."""

    def test_router_classify(self):
        """TaskRouter.classify() delegates to module-level classify()."""
        router = TaskRouter()
        result = router.classify("scan for vulnerabilities")
        assert isinstance(result, TaskType)
        assert result.domain == "security"

    def test_router_route(self):
        """TaskRouter.route() returns a strategy."""
        router = TaskRouter()
        task_type = TaskType(domain="memory", action="search")
        strategy = router.route(task_type)
        assert isinstance(strategy, ExecutionStrategy)

    def test_router_register_handler(self):
        """Registering a direct handler makes it callable."""
        router = TaskRouter()
        called = {"count": 0}

        def my_handler(task, params):
            called["count"] += 1
            return {"result": "ok"}

        router.register_handler("test_tool", my_handler)
        assert "test_tool" in router._direct._handlers

    def test_router_register_route(self):
        """Registering a custom route adds it to the routing table."""
        router = TaskRouter()
        strategy = ExecutionStrategy(name="test_route", backend="direct",
                                     tool_chain=["test_tool"])
        router.register_route("test_domain", "test_action", strategy)
        assert ("test_domain", "test_action") in router._routing_table

    def test_router_register_backend(self):
        """Registering a custom backend makes it available."""
        router = TaskRouter()
        router.register_backend("custom_backend", DirectBackend())
        assert "custom_backend" in router._backends


class TestExecutionStrategy:
    """ExecutionStrategy data class."""

    def test_strategy_key_with_name(self):
        """Strategy key uses name if set."""
        s = ExecutionStrategy(name="my_strategy")
        assert s.key == "my_strategy"  # noqa:PLAIN SECRET COMPARISON -- test assertion not secret

    def test_strategy_key_without_name(self):
        """Strategy key falls back to backend:tool_chain."""
        s = ExecutionStrategy(backend="cli", tool_chain=["cmd1", "cmd2"])
        assert s.key == "cli:cmd1,cmd2"  # noqa:PLAIN SECRET COMPARISON -- test assertion not secret

    def test_strategy_defaults(self):
        """Strategy has sensible defaults."""
        s = ExecutionStrategy()
        assert s.backend == "direct"
        assert s.timeout_s == 300.0
        assert s.tool_chain == []
        assert s.fallback == ""
