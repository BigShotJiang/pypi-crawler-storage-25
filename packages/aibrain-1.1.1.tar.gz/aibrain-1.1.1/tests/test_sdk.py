"""
Tests for aibrain_sdk.py — the Python SDK for AIBrain.

Covers: SDK initialization, HTTP helpers, memory methods, health check,
chat, and approval methods. Uses mocking since the SDK makes HTTP calls.
"""

import json
import sys
from pathlib import Path
from unittest.mock import patch, MagicMock
from urllib.error import HTTPError, URLError

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from aibrain_sdk import AIBrain, AIBrainError


class TestSDKInit:
    """SDK initialization and configuration."""

    def test_default_url(self):
        """Default base URL is localhost:8001."""
        aos = AIBrain()
        assert aos.base_url == "http://localhost:8001"

    def test_custom_url(self):
        """Custom URL is stored without trailing slash."""
        aos = AIBrain("https://example.com:9000/")
        assert aos.base_url == "https://example.com:9000"

    def test_agent_name_default(self):
        """Default agent name is 'agent'."""
        aos = AIBrain()
        assert aos.agent_name == "agent"

    def test_agent_name_custom(self):
        """Custom agent name is stored."""
        aos = AIBrain(agent_name="test_agent")
        assert aos.agent_name == "test_agent"

    def test_api_path(self):
        """API path is base_url + /api/agent."""
        aos = AIBrain("http://localhost:8001")
        assert aos.api == "http://localhost:8001/api/agent"

    def test_repr(self):
        """repr shows URL and agent name."""
        aos = AIBrain("http://localhost:8001", agent_name="test_agent")
        assert "localhost:8001" in repr(aos)
        assert "test_agent" in repr(aos)


class TestSDKMemoryMethods:
    """Memory methods: remember, recall, list, update, delete."""

    @patch.object(AIBrain, "_post")
    def test_remember(self, mock_post):
        """remember() calls POST with correct payload."""
        mock_post.return_value = {"id": 1, "name": "test"}
        aos = AIBrain()
        result = aos.remember("dark mode preferred", type="user", tags=["preference"])

        mock_post.assert_called_once_with("memories", {
            "name": "dark mode preferred",
            "content": "dark mode preferred",
            "type": "user",
            "tags": "preference",
        })

    @patch.object(AIBrain, "_post")
    def test_remember_custom_name(self, mock_post):
        """remember() with explicit name uses it instead of content."""
        mock_post.return_value = {"id": 1}
        aos = AIBrain()
        aos.remember("User prefers dark mode", name="dark_mode_pref")

        call_args = mock_post.call_args[0]
        assert call_args[1]["name"] == "dark_mode_pref"

    @patch.object(AIBrain, "_get")
    def test_recall(self, mock_get):
        """recall() calls search endpoint and returns results."""
        mock_get.return_value = {"results": [{"id": 1, "content": "dark mode"}]}
        aos = AIBrain()
        results = aos.recall("dark mode")

        mock_get.assert_called_once_with("memories/search", q="dark mode", limit=10)
        assert len(results) == 1

    @patch.object(AIBrain, "_get")
    def test_recall_empty(self, mock_get):
        """recall() with no matches returns empty list."""
        mock_get.return_value = {"results": []}
        aos = AIBrain()
        results = aos.recall("nonexistent")
        assert results == []

    @patch.object(AIBrain, "_get")
    def test_list_memories(self, mock_get):
        """list_memories() returns memories list."""
        mock_get.return_value = {"memories": [{"id": 1}, {"id": 2}]}
        aos = AIBrain()
        results = aos.list_memories(type="user", limit=20)
        assert len(results) == 2

    @patch.object(AIBrain, "_get")
    def test_memory_summary(self, mock_get):
        """memory_summary() returns counts."""
        mock_get.return_value = {"user": 5, "project": 10}
        aos = AIBrain()
        result = aos.memory_summary()
        assert result["user"] == 5

    @patch.object(AIBrain, "_delete")
    def test_delete_memory(self, mock_delete):
        """delete_memory() calls DELETE endpoint."""
        mock_delete.return_value = {"status": "deactivated"}
        aos = AIBrain()
        result = aos.delete_memory(42)
        mock_delete.assert_called_once_with("memories/42")


class TestSDKHealth:
    """Health check methods."""

    @patch.object(AIBrain, "_request")
    def test_health(self, mock_req):
        """health() calls GET /health."""
        mock_req.return_value = {"status": "ok"}
        aos = AIBrain()
        result = aos.health()
        assert result["status"] == "ok"

    @patch.object(AIBrain, "_request")
    def test_is_alive_true(self, mock_req):
        """is_alive() returns True when server responds ok."""
        mock_req.return_value = {"status": "ok"}
        aos = AIBrain()
        assert aos.is_alive() is True

    @patch.object(AIBrain, "_request")
    def test_is_alive_false(self, mock_req):
        """is_alive() returns False when server is unreachable."""
        mock_req.side_effect = AIBrainError("Cannot reach")
        aos = AIBrain()
        assert aos.is_alive() is False


class TestSDKErrorHandling:
    """Error handling in HTTP requests."""

    def test_http_error_raises(self):
        """HTTP 4xx/5xx raises AIBrainError."""
        aos = AIBrain("http://localhost:99999")
        with pytest.raises(AIBrainError):
            aos.health()

    @patch("urllib.request.urlopen")
    def test_http_error_includes_status(self, mock_urlopen):
        """AIBrainError includes the HTTP status code."""
        mock_response = MagicMock()
        mock_urlopen.side_effect = HTTPError(
            "http://test", 404, "Not Found", {}, None
        )
        aos = AIBrain()
        with pytest.raises(AIBrainError, match="404"):
            aos._request("GET", "/health")


class TestSDKConvenience:
    """Convenience methods: think, learn, decide."""

    @patch.object(AIBrain, "remember")
    def test_think(self, mock_remember):
        """think() stores as pattern type with thought tags."""
        mock_remember.return_value = {"id": 1}
        aos = AIBrain()
        aos.think("The user seems to prefer async code")
        mock_remember.assert_called_once()
        call_kwargs = mock_remember.call_args
        assert call_kwargs[1]["type"] == "pattern"
        assert "thought" in call_kwargs[1]["tags"]

    @patch.object(AIBrain, "remember")
    def test_learn(self, mock_remember):
        """learn() stores as feedback type with lesson tag."""
        mock_remember.return_value = {"id": 1}
        aos = AIBrain()
        aos.learn("Always verify before declaring done")
        call_kwargs = mock_remember.call_args
        assert call_kwargs[1]["type"] == "feedback"

    @patch.object(AIBrain, "remember")
    def test_decide(self, mock_remember):
        """decide() stores as decision type with reasoning."""
        mock_remember.return_value = {"id": 1}
        aos = AIBrain()
        aos.decide("Use MiniLM over bge-small", reasoning="Faster and competitive accuracy")
        content = mock_remember.call_args[0][0]
        assert "MiniLM" in content
        assert "Reasoning:" in content
