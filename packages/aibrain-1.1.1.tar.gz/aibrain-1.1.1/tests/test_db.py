"""
Tests for aibrain_db.py — the consolidated database layer.

Covers: schema init, memory CRUD, config get/set, FTS search, activity log.
"""

import os
import sqlite3
import sys
import tempfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


@pytest.fixture()
def db_conn():
    """Create a fresh, isolated SQLite DB with the full AIBrain schema."""
    fd, path = tempfile.mkstemp(suffix=".db", prefix="aibrain_dbtest_")
    os.close(fd)

    # Patch the module to use our temp DB
    import aibrain_db
    original_path = aibrain_db.DB_PATH
    original_conn = aibrain_db._conn

    aibrain_db.DB_PATH = Path(path)
    aibrain_db._conn = None  # Force fresh connection

    conn = aibrain_db.get_db()

    yield conn

    # Restore original state
    try:
        conn.close()
    except Exception:
        pass
    aibrain_db._conn = original_conn
    aibrain_db.DB_PATH = original_path

    try:
        os.unlink(path)
    except OSError:
        pass
    for ext in ("-wal", "-shm"):
        try:
            os.unlink(path + ext)
        except OSError:
            pass


class TestSchemaInit:
    """Schema initialization creates all expected tables."""

    def test_memories_table_exists(self, db_conn):
        """memories table is created."""
        tables = {r[0] for r in db_conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()}
        assert "memories" in tables

    def test_workflows_table_exists(self, db_conn):
        """workflows table is created."""
        tables = {r[0] for r in db_conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()}
        assert "workflows" in tables

    def test_config_table_exists(self, db_conn):
        """config table is created."""
        tables = {r[0] for r in db_conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()}
        assert "config" in tables

    def test_activity_table_exists(self, db_conn):
        """activity table is created."""
        tables = {r[0] for r in db_conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()}
        assert "activity" in tables

    def test_fts_tables_exist(self, db_conn):
        """FTS5 virtual tables are created."""
        tables = {r[0] for r in db_conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()}
        assert "memories_fts" in tables


class TestMemoryCRUD:
    """Memory create, read, update, soft-delete via raw SQL."""

    def test_insert_memory(self, db_conn):
        """Insert a memory and read it back."""
        db_conn.execute(
            "INSERT INTO memories (name, type, content, importance) VALUES (?, ?, ?, ?)",
            ("test_mem", "reference", "Test content", 0.7)
        )
        db_conn.commit()
        row = db_conn.execute(
            "SELECT * FROM memories WHERE name = ?", ("test_mem",)
        ).fetchone()
        assert row is not None
        assert row["content"] == "Test content"
        assert row["importance"] == 0.7

    def test_update_memory(self, db_conn):
        """Update a memory's content."""
        db_conn.execute(
            "INSERT INTO memories (name, type, content) VALUES (?, ?, ?)",
            ("upd_mem", "reference", "Original")
        )
        db_conn.commit()

        db_conn.execute(
            "UPDATE memories SET content = ?, updated = datetime('now') WHERE name = ?",
            ("Updated content", "upd_mem")
        )
        db_conn.commit()

        row = db_conn.execute(
            "SELECT content FROM memories WHERE name = ?", ("upd_mem",)
        ).fetchone()
        assert row["content"] == "Updated content"

    def test_soft_delete(self, db_conn):
        """Soft-delete sets active=0, row still exists."""
        db_conn.execute(
            "INSERT INTO memories (name, type, content) VALUES (?, ?, ?)",
            ("del_mem", "reference", "To be deleted")
        )
        db_conn.commit()

        db_conn.execute("UPDATE memories SET active = 0 WHERE name = ?", ("del_mem",))
        db_conn.commit()

        # Row exists but not active
        row = db_conn.execute(
            "SELECT active FROM memories WHERE name = ?", ("del_mem",)
        ).fetchone()
        assert row["active"] == 0

        # Active-only query misses it
        active = db_conn.execute(
            "SELECT * FROM memories WHERE name = ? AND active = 1", ("del_mem",)
        ).fetchone()
        assert active is None

    def test_fts_search(self, db_conn):
        """FTS5 search finds memories by content keywords."""
        db_conn.execute(
            "INSERT INTO memories (name, type, content) VALUES (?, ?, ?)",
            ("fts_test", "reference", "AIBrain is a portable agent operating system")
        )
        db_conn.commit()

        results = db_conn.execute(
            "SELECT m.* FROM memories m JOIN memories_fts f ON m.id=f.rowid "
            "WHERE memories_fts MATCH ? AND m.active=1",
            ("agent operating system",)
        ).fetchall()
        assert len(results) >= 1
        assert results[0]["name"] == "fts_test"

    def test_memory_types(self, db_conn):
        """All valid memory types can be stored."""
        valid_types = ["user", "feedback", "project", "reference", "pattern", "decision"]
        for t in valid_types:
            db_conn.execute(
                "INSERT INTO memories (name, type, content) VALUES (?, ?, ?)",
                (f"type_{t}", t, f"Content for {t}")
            )
        db_conn.commit()

        count = db_conn.execute("SELECT COUNT(*) FROM memories WHERE active=1").fetchone()[0]
        assert count >= len(valid_types)


class TestConfigKV:
    """Config key-value store via aibrain_db helper functions."""

    def test_config_set_and_get(self, db_conn):
        """config_set stores and config_get retrieves values."""
        import aibrain_db
        aibrain_db.config_set("test_key", "test_value")
        result = aibrain_db.config_get("test_key")
        assert result == "test_value"

    def test_config_get_default(self, db_conn):
        """config_get returns default for missing keys."""
        import aibrain_db
        result = aibrain_db.config_get("nonexistent_key_12345", "default_val")
        assert result == "default_val"

    def test_config_set_overwrite(self, db_conn):
        """config_set overwrites existing values."""
        import aibrain_db
        aibrain_db.config_set("overwrite_key", "first")
        aibrain_db.config_set("overwrite_key", "second")
        assert aibrain_db.config_get("overwrite_key") == "second"

    def test_config_set_json_value(self, db_conn):
        """config_set handles JSON-serializable values (lists, dicts)."""
        import aibrain_db
        aibrain_db.config_set("json_key", ["a", "b", "c"])
        result = aibrain_db.config_get("json_key")
        assert result == ["a", "b", "c"]


class TestActivityLog:
    """Activity table for agent event logging."""

    def test_insert_activity(self, db_conn):
        """Insert an activity event and read it back."""
        db_conn.execute(
            "INSERT INTO activity (agent, action, detail, status) VALUES (?, ?, ?, ?)",
            ("test_agent", "test_action", "Test detail", "ok")
        )
        db_conn.commit()

        row = db_conn.execute(
            "SELECT * FROM activity WHERE agent = ? ORDER BY id DESC LIMIT 1",
            ("test_agent",)
        ).fetchone()
        assert row is not None
        assert row["action"] == "test_action"
        assert row["status"] == "ok"
