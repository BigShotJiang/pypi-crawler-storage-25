#!/usr/bin/env python3
"""
brain_versioning.py — Brain Version Control + Scale Management

Two modules that close the final gaps in the multi-agent mesh:

1. BrainVersioning — git-like history for brain merges
   - Every merge creates a snapshot with hash
   - Roll back to any previous version
   - Branch a brain, experiment, merge back
   - Full audit trail of how knowledge evolved

2. BrainScale — tiered storage for large-scale deployments
   - Hot tier: active memories in primary DB (fast FTS5 queries)
   - Archive tier: old/low-importance memories in separate DB
   - Auto-promotion: archived memories resurface when queried
   - Compaction: periodic move from hot → archive based on decay score
   - Stats: track DB size, query latency, memory distribution

Usage:
    from brain_versioning import BrainVersioning
    v = BrainVersioning(db_path)
    v.snapshot("pre-merge with 100 swarm agents")
    # ... do merge ...
    v.snapshot("post-merge: 500 consensus principles")
    v.rollback("pre-merge with 100 swarm agents")  # undo if bad
    v.branch("experiment_aggressive_merge")
    v.list_versions()

    from brain_versioning import BrainScale
    s = BrainScale(db_path)
    s.compact()  # move stale memories to archive
    s.stats()    # DB health report
"""

import hashlib
import json
import logging
import os
import shutil
import sqlite3
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Tuple

log = logging.getLogger("aibrain.versioning")


# =========================================================================
# BRAIN VERSIONING
# =========================================================================

class BrainVersioning:
    """Git-like version control for brain databases.

    Every snapshot captures: memory count, principle count, episode count,
    content hash, and a full backup of the DB file. You can roll back to
    any snapshot, branch for experiments, and merge branches back.

    Storage: .brain_mesh/versions/ directory alongside the brain DB.
    """

    def __init__(self, db_path: str):
        self.db_path = db_path
        self.versions_dir = Path(db_path).parent / ".brain_mesh" / "versions"
        self.versions_dir.mkdir(parents=True, exist_ok=True)
        self._manifest_path = self.versions_dir / "manifest.json"
        self._manifest = self._load_manifest()

    def _load_manifest(self) -> Dict:
        if self._manifest_path.exists():
            try:
                return json.loads(self._manifest_path.read_text())
            except json.JSONDecodeError:
                pass
        return {"versions": [], "branches": {}, "current_branch": "main"}

    def _save_manifest(self):
        self._manifest_path.write_text(json.dumps(self._manifest, indent=2))

    def _compute_brain_hash(self) -> str:
        """Compute a content hash of the brain's current state."""
        if not Path(self.db_path).exists():
            return "empty"

        conn = sqlite3.connect(self.db_path)
        hasher = hashlib.sha256()

        try:
            # Hash memory contents
            rows = conn.execute(
                "SELECT name, content FROM memories WHERE active=1 ORDER BY name"
            ).fetchall()
            for row in rows:
                hasher.update(f"{row[0]}:{row[1]}".encode())

            # Hash principles
            rows = conn.execute(
                "SELECT task_type, principle, confidence FROM skill_principles "
                "WHERE status='active' ORDER BY task_type, principle"
            ).fetchall()
            for row in rows:
                hasher.update(f"{row[0]}:{row[1]}:{row[2]}".encode())

        except Exception:
            pass
        finally:
            conn.close()

        return hasher.hexdigest()[:16]

    def _get_brain_stats(self) -> Dict:
        """Get current brain statistics."""
        stats = {"memories": 0, "principles": 0, "episodes": 0, "size_kb": 0}

        p = Path(self.db_path)
        if p.exists():
            stats["size_kb"] = round(p.stat().st_size / 1024)

        try:
            conn = sqlite3.connect(self.db_path)
            row = conn.execute("SELECT COUNT(*) FROM memories WHERE active=1").fetchone()
            stats["memories"] = row[0] if row else 0
            row = conn.execute("SELECT COUNT(*) FROM skill_principles WHERE status='active'").fetchone()
            stats["principles"] = row[0] if row else 0
            row = conn.execute("SELECT COUNT(*) FROM skill_episodes").fetchone()
            stats["episodes"] = row[0] if row else 0
            conn.close()
        except Exception:
            pass

        return stats

    # ------------------------------------------------------------------
    # Snapshots
    # ------------------------------------------------------------------

    def snapshot(self, message: str = "", tag: str = "") -> Dict:
        """Create a snapshot of the current brain state.

        Like `git commit` — saves a backup with metadata.
        """
        brain_hash = self._compute_brain_hash()
        stats = self._get_brain_stats()
        timestamp = datetime.now().isoformat()
        version_id = f"v_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{brain_hash[:8]}"

        # Copy the DB file
        backup_path = self.versions_dir / f"{version_id}.db"
        shutil.copy2(self.db_path, backup_path)

        version = {
            "id": version_id,
            "timestamp": timestamp,
            "message": message,
            "tag": tag,
            "hash": brain_hash,
            "branch": self._manifest.get("current_branch", "main"),
            "stats": stats,
            "backup_path": str(backup_path),
        }

        self._manifest["versions"].append(version)
        self._save_manifest()

        log.info("Snapshot created: %s (%s) — %d memories, %d principles",
                 version_id, message, stats["memories"], stats["principles"])

        return version

    def list_versions(self, branch: str = None, limit: int = 20) -> List[Dict]:
        """List all snapshots, optionally filtered by branch."""
        versions = self._manifest.get("versions", [])
        if branch:
            versions = [v for v in versions if v.get("branch") == branch]
        return versions[-limit:]

    def get_version(self, version_id: str) -> Optional[Dict]:
        """Get a specific version by ID or tag."""
        for v in self._manifest.get("versions", []):
            if v["id"] == version_id or v.get("tag") == version_id:
                return v
        return None

    def rollback(self, version_id: str) -> Dict:
        """Roll back the brain to a previous snapshot.

        Like `git checkout` — replaces current DB with the backup.
        Creates a safety snapshot of current state first.
        """
        version = self.get_version(version_id)
        if not version:
            return {"status": "error", "message": f"Version not found: {version_id}"}

        backup_path = Path(version["backup_path"])
        if not backup_path.exists():
            return {"status": "error", "message": f"Backup file missing: {backup_path}"}

        # Safety snapshot before rollback
        self.snapshot(f"auto-save before rollback to {version_id}", tag="pre_rollback")

        # Replace current DB with backup
        shutil.copy2(backup_path, self.db_path)

        log.info("Rolled back to: %s (%s)", version_id, version.get("message", ""))

        return {
            "status": "ok",
            "rolled_back_to": version_id,
            "message": version.get("message", ""),
            "stats": version.get("stats", {}),
        }

    def diff(self, version_a: str, version_b: str = None) -> Dict:
        """Compare two versions (or a version vs current state).

        Returns: what changed between them.
        """
        va = self.get_version(version_a)
        if not va:
            return {"error": f"Version not found: {version_a}"}

        stats_a = va.get("stats", {})

        if version_b:
            vb = self.get_version(version_b)
            if not vb:
                return {"error": f"Version not found: {version_b}"}
            stats_b = vb.get("stats", {})
        else:
            stats_b = self._get_brain_stats()

        delta = {}
        for key in ("memories", "principles", "episodes", "size_kb"):
            a_val = stats_a.get(key, 0)
            b_val = stats_b.get(key, 0)
            delta[key] = {"before": a_val, "after": b_val, "change": b_val - a_val}

        return {
            "from": version_a,
            "to": version_b or "current",
            "hash_changed": va.get("hash") != (self.get_version(version_b) or {}).get("hash", self._compute_brain_hash()),
            "delta": delta,
        }

    # ------------------------------------------------------------------
    # Branching
    # ------------------------------------------------------------------

    def branch(self, name: str) -> Dict:
        """Create a new branch from current state.

        Like `git branch` — creates a named copy you can experiment with.
        """
        # Snapshot current state on the current branch first
        self.snapshot(f"branch point for '{name}'")

        # Create branch directory
        branch_dir = self.versions_dir / "branches" / name
        branch_dir.mkdir(parents=True, exist_ok=True)

        # Copy current DB to branch
        branch_db = branch_dir / "aibrain.db"
        shutil.copy2(self.db_path, branch_db)

        self._manifest["branches"][name] = {
            "created": datetime.now().isoformat(),
            "db_path": str(branch_db),
            "parent_branch": self._manifest.get("current_branch", "main"),
            "parent_hash": self._compute_brain_hash(),
        }
        self._save_manifest()

        log.info("Branch created: %s", name)
        return {"status": "ok", "branch": name, "db_path": str(branch_db)}

    def checkout(self, branch_name: str) -> Dict:
        """Switch to a different branch.

        Saves current state, then loads the branch's DB.
        """
        if branch_name not in self._manifest["branches"] and branch_name != "main":
            return {"status": "error", "message": f"Branch not found: {branch_name}"}

        # Save current branch state
        current = self._manifest.get("current_branch", "main")
        if current != "main":
            branch_info = self._manifest["branches"].get(current, {})
            if branch_info.get("db_path"):
                shutil.copy2(self.db_path, branch_info["db_path"])

        # Load target branch
        if branch_name == "main":
            # Restore from latest main snapshot
            main_versions = [v for v in self._manifest["versions"]
                           if v.get("branch") == "main"]
            if main_versions:
                latest = main_versions[-1]
                if Path(latest["backup_path"]).exists():
                    shutil.copy2(latest["backup_path"], self.db_path)
        else:
            branch_info = self._manifest["branches"][branch_name]
            branch_db = branch_info.get("db_path")
            if branch_db and Path(branch_db).exists():
                shutil.copy2(branch_db, self.db_path)

        self._manifest["current_branch"] = branch_name
        self._save_manifest()

        return {"status": "ok", "branch": branch_name}

    def merge_branch(self, source_branch: str) -> Dict:
        """Merge a branch back into the current branch.

        Uses the brain_mesh consensus merge between the two DB files.
        """
        if source_branch not in self._manifest["branches"]:
            return {"status": "error", "message": f"Branch not found: {source_branch}"}

        branch_info = self._manifest["branches"][source_branch]
        branch_db = branch_info.get("db_path")

        if not branch_db or not Path(branch_db).exists():
            return {"status": "error", "message": "Branch DB not found"}

        # Snapshot before merge
        self.snapshot(f"pre-merge with branch '{source_branch}'")

        # Import branch data into current DB
        try:
            from brain_mesh import BrainMesh
            mesh = BrainMesh(self.db_path)
            mesh.register_agent("current", self.db_path, trust_score=1.0)
            mesh.register_agent(source_branch, branch_db, trust_score=1.0)
            result = mesh.merge_pair("current", source_branch, strategy="consensus",
                                      target_db=self.db_path)

            self.snapshot(f"post-merge with branch '{source_branch}'")

            return {
                "status": "ok",
                "merged_from": source_branch,
                "memories_added": result.memories_added,
                "principles_boosted": result.principles_boosted,
            }
        except ImportError:
            return {"status": "error", "message": "brain_mesh not available for merge"}

    def delete_branch(self, name: str) -> Dict:
        """Delete a branch."""
        if name == "main":
            return {"status": "error", "message": "Cannot delete main branch"}

        if name in self._manifest["branches"]:
            branch_info = self._manifest["branches"][name]
            branch_db = branch_info.get("db_path")
            if branch_db and Path(branch_db).exists():
                Path(branch_db).unlink()
            del self._manifest["branches"][name]
            self._save_manifest()
            return {"status": "ok", "deleted": name}

        return {"status": "error", "message": f"Branch not found: {name}"}

    def list_branches(self) -> Dict:
        """List all branches with metadata."""
        current = self._manifest.get("current_branch", "main")
        branches = {"main": {"current": current == "main"}}

        for name, info in self._manifest.get("branches", {}).items():
            branches[name] = {
                "created": info.get("created", ""),
                "parent": info.get("parent_branch", "main"),
                "current": current == name,
                "db_exists": Path(info.get("db_path", "")).exists(),
            }

        return branches

    # ------------------------------------------------------------------
    # Cleanup
    # ------------------------------------------------------------------

    def prune(self, keep_last: int = 10) -> Dict:
        """Remove old snapshots, keeping the most recent N."""
        versions = self._manifest.get("versions", [])
        if len(versions) <= keep_last:
            return {"status": "ok", "pruned": 0}

        to_remove = versions[:-keep_last]
        kept = versions[-keep_last:]

        removed = 0
        for v in to_remove:
            backup = Path(v.get("backup_path", ""))
            if backup.exists():
                backup.unlink()
                removed += 1

        self._manifest["versions"] = kept
        self._save_manifest()

        return {"status": "ok", "pruned": removed, "remaining": len(kept)}

    def storage_used(self) -> Dict:
        """Calculate total storage used by version history."""
        total = 0
        count = 0
        for v in self._manifest.get("versions", []):
            p = Path(v.get("backup_path", ""))
            if p.exists():
                total += p.stat().st_size
                count += 1

        for name, info in self._manifest.get("branches", {}).items():
            p = Path(info.get("db_path", ""))
            if p.exists():
                total += p.stat().st_size

        return {
            "snapshots": count,
            "branches": len(self._manifest.get("branches", {})),
            "total_bytes": total,
            "total_mb": round(total / (1024 * 1024), 1),
        }


# =========================================================================
# BRAIN SCALE MANAGEMENT
# =========================================================================

class BrainScale:
    """Tiered storage and scale management for large brain deployments.

    Hot tier: primary DB with active memories (fast FTS5 queries)
    Archive tier: separate DB with old/low-importance memories
    Auto-promotion: archived memories resurface when searched
    Compaction: periodic hot → archive migration based on decay score

    Thresholds (configurable):
    - Max hot memories: 50,000 (above this, compact aggressively)
    - Archive age: memories untouched for 90+ days with importance < 0.3
    - Max DB size: 500MB (trigger warning)
    """

    def __init__(self, db_path: str, config: Dict = None):
        self.db_path = db_path
        self.config = config or {}
        self.archive_path = str(Path(db_path).parent / "aibrain_archive.db")

        # Configurable thresholds
        self.max_hot = int(self.config.get("max_hot_memories", 50000))
        self.archive_days = int(self.config.get("archive_days", 90))
        self.archive_importance = float(self.config.get("archive_importance_threshold", 0.3))
        self.max_db_mb = int(self.config.get("max_db_size_mb", 500))

    def _ensure_archive(self):
        """Create archive DB with same schema as primary."""
        if Path(self.archive_path).exists():
            return

        # Copy schema from primary
        conn = sqlite3.connect(self.db_path)
        try:
            schema = conn.execute(
                "SELECT sql FROM sqlite_master WHERE type='table' AND name='memories'"
            ).fetchone()
            if schema:
                archive_conn = sqlite3.connect(self.archive_path)
                archive_conn.execute(schema[0])

                # Also create FTS5 table if it exists
                try:
                    fts_schema = conn.execute(
                        "SELECT sql FROM sqlite_master WHERE type='table' AND name='memories_fts'"
                    ).fetchone()
                    if fts_schema:
                        archive_conn.execute(fts_schema[0])
                except Exception:
                    pass

                archive_conn.commit()
                archive_conn.close()
        except Exception as e:
            log.error("Failed to create archive: %s", e)
        finally:
            conn.close()

    # ------------------------------------------------------------------
    # Stats & Health
    # ------------------------------------------------------------------

    def stats(self) -> Dict:
        """Comprehensive brain health report."""
        primary = Path(self.db_path)
        archive = Path(self.archive_path)

        report = {
            "primary": {"path": self.db_path, "exists": primary.exists()},
            "archive": {"path": self.archive_path, "exists": archive.exists()},
            "health": "healthy",
            "warnings": [],
        }

        if primary.exists():
            report["primary"]["size_mb"] = round(primary.stat().st_size / (1024*1024), 1)

            conn = sqlite3.connect(self.db_path)
            try:
                # Memory counts
                row = conn.execute("SELECT COUNT(*) FROM memories WHERE active=1").fetchone()
                report["primary"]["active_memories"] = row[0] if row else 0

                row = conn.execute("SELECT COUNT(*) FROM memories WHERE active=0").fetchone()
                report["primary"]["inactive_memories"] = row[0] if row else 0

                # Principle counts
                row = conn.execute("SELECT COUNT(*) FROM skill_principles WHERE status='active'").fetchone()
                report["primary"]["active_principles"] = row[0] if row else 0

                # Episode count
                row = conn.execute("SELECT COUNT(*) FROM skill_episodes").fetchone()
                report["primary"]["episodes"] = row[0] if row else 0

                # Age distribution
                row = conn.execute(
                    "SELECT COUNT(*) FROM memories WHERE active=1 "
                    "AND updated < datetime('now', '-90 days')"
                ).fetchone()
                report["primary"]["stale_memories"] = row[0] if row else 0

                # FTS5 health
                try:
                    row = conn.execute("SELECT COUNT(*) FROM memories_fts").fetchone()
                    report["primary"]["fts_entries"] = row[0] if row else 0
                except Exception:
                    report["primary"]["fts_entries"] = "N/A (no FTS5 table)"

                conn.close()
            except Exception as e:
                report["warnings"].append(f"Stats query failed: {e}")

            # Health checks
            if report["primary"].get("active_memories", 0) > self.max_hot:
                report["warnings"].append(
                    f"Memory count ({report['primary']['active_memories']}) exceeds "
                    f"recommended max ({self.max_hot}). Run: aibrain scale compact"
                )
                report["health"] = "warning"

            if report["primary"].get("size_mb", 0) > self.max_db_mb:
                report["warnings"].append(
                    f"DB size ({report['primary']['size_mb']}MB) exceeds "
                    f"limit ({self.max_db_mb}MB). Run: aibrain scale compact"
                )
                report["health"] = "critical"

            stale = report["primary"].get("stale_memories", 0)
            total = report["primary"].get("active_memories", 1)
            if total > 0 and stale / total > 0.3:
                report["warnings"].append(
                    f"{stale} stale memories ({stale/total*100:.0f}% of total). "
                    f"Run: aibrain scale compact"
                )

        if archive.exists():
            report["archive"]["size_mb"] = round(archive.stat().st_size / (1024*1024), 1)
            try:
                conn = sqlite3.connect(self.archive_path)
                row = conn.execute("SELECT COUNT(*) FROM memories WHERE active=1").fetchone()
                report["archive"]["memories"] = row[0] if row else 0
                conn.close()
            except Exception:
                report["archive"]["memories"] = 0

        return report

    # ------------------------------------------------------------------
    # Compaction (hot → archive)
    # ------------------------------------------------------------------

    def compact(self, dry_run: bool = False) -> Dict:
        """Move stale, low-importance memories from primary to archive.

        Criteria for archival:
        - Not updated in archive_days (default 90)
        - Importance below archive_importance_threshold (default 0.3)
        - Not tagged with 'permanent' or 'pin'
        - Not of type 'agent' or 'project' (these are always hot)
        """
        self._ensure_archive()

        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row

        # Find candidates for archival
        cutoff = (datetime.now() - timedelta(days=self.archive_days)).strftime("%Y-%m-%d")

        candidates = conn.execute(
            "SELECT id, name, type, tags, content, importance, created, updated "
            "FROM memories WHERE active=1 "
            "AND updated < ? "
            "AND importance < ? "
            "AND type NOT IN ('agent', 'project') "
            "AND tags NOT LIKE '%permanent%' "
            "AND tags NOT LIKE '%pin%' "
            "ORDER BY importance ASC, updated ASC",
            (cutoff, self.archive_importance)
        ).fetchall()

        result = {
            "candidates": len(candidates),
            "archived": 0,
            "freed_bytes": 0,
            "dry_run": dry_run,
        }

        if dry_run:
            # Report what would happen
            if candidates:
                result["preview"] = [
                    {"name": c["name"], "importance": c["importance"],
                     "last_updated": c["updated"][:10]}
                    for c in candidates[:20]
                ]
            conn.close()
            return result

        if not candidates:
            conn.close()
            return result

        # Move to archive
        archive_conn = sqlite3.connect(self.archive_path)

        for c in candidates:
            try:
                # Insert into archive
                archive_conn.execute(
                    "INSERT INTO memories (name, type, tags, content, importance, "
                    "created, updated, active) VALUES (?, ?, ?, ?, ?, ?, ?, 1)",
                    (c["name"], c["type"], c["tags"] + ",archived",
                     c["content"], c["importance"], c["created"], c["updated"])
                )

                # Deactivate in primary
                conn.execute("UPDATE memories SET active=0 WHERE id=?", (c["id"],))
                result["archived"] += 1

            except Exception as e:
                log.warning("Failed to archive memory %s: %s", c["name"], e)

        archive_conn.commit()
        archive_conn.close()
        conn.commit()
        conn.close()

        # Vacuum primary DB to reclaim space
        try:
            conn = sqlite3.connect(self.db_path)
            size_before = Path(self.db_path).stat().st_size
            conn.execute("VACUUM")
            conn.close()
            size_after = Path(self.db_path).stat().st_size
            result["freed_bytes"] = size_before - size_after
            result["freed_mb"] = round(result["freed_bytes"] / (1024*1024), 1)
        except Exception:
            pass

        log.info("Compacted: %d memories archived, %.1fMB freed",
                 result["archived"], result.get("freed_mb", 0))

        return result

    # ------------------------------------------------------------------
    # Archive Search (auto-promotion)
    # ------------------------------------------------------------------

    def search_archive(self, query: str, limit: int = 10) -> List[Dict]:
        """Search the archive for memories matching the query.

        Found memories are promoted back to hot tier with a temporary
        importance boost so they stay hot for the current task context.
        """
        if not Path(self.archive_path).exists():
            return []

        archive_conn = sqlite3.connect(self.archive_path)
        archive_conn.row_factory = sqlite3.Row

        try:
            rows = archive_conn.execute(
                "SELECT name, type, tags, content, importance, created, updated "
                "FROM memories WHERE active=1 AND content LIKE ? "
                "ORDER BY importance DESC LIMIT ?",
                (f"%{query}%", limit)
            ).fetchall()
            results = [dict(r) for r in rows]
        except Exception:
            results = []
        finally:
            archive_conn.close()

        return results

    def promote(self, memory_names: List[str]) -> Dict:
        """Promote specific memories from archive back to hot tier."""
        if not Path(self.archive_path).exists():
            return {"promoted": 0}

        archive_conn = sqlite3.connect(self.archive_path)
        archive_conn.row_factory = sqlite3.Row
        primary_conn = sqlite3.connect(self.db_path)

        promoted = 0
        for name in memory_names:
            try:
                row = archive_conn.execute(
                    "SELECT name, type, tags, content, importance, created, updated "
                    "FROM memories WHERE name=? AND active=1", (name,)
                ).fetchone()

                if row:
                    # Insert into primary with importance boost
                    boosted_importance = min(row["importance"] + 0.2, 0.8)
                    tags = row["tags"].replace(",archived", "") + ",promoted"

                    primary_conn.execute(
                        "INSERT OR REPLACE INTO memories (name, type, tags, content, "
                        "importance, created, updated, active) VALUES "
                        "(?, ?, ?, ?, ?, ?, datetime('now'), 1)",
                        (row["name"], row["type"], tags, row["content"],
                         boosted_importance, row["created"])
                    )

                    # Remove from archive
                    archive_conn.execute(
                        "UPDATE memories SET active=0 WHERE name=?", (name,)
                    )
                    promoted += 1
            except Exception as e:
                log.warning("Failed to promote %s: %s", name, e)

        primary_conn.commit()
        primary_conn.close()
        archive_conn.commit()
        archive_conn.close()

        return {"promoted": promoted}

    # ------------------------------------------------------------------
    # FTS5 Maintenance
    # ------------------------------------------------------------------

    def rebuild_fts(self) -> Dict:
        """Rebuild the FTS5 index. Run after large merges or compactions."""
        start = time.time()
        conn = sqlite3.connect(self.db_path)

        try:
            # Check if FTS5 table exists
            conn.execute("SELECT * FROM memories_fts LIMIT 1")

            # Rebuild
            conn.execute("INSERT INTO memories_fts(memories_fts) VALUES('rebuild')")
            conn.commit()

            elapsed = round(time.time() - start, 2)
            log.info("FTS5 index rebuilt in %.2fs", elapsed)
            return {"status": "ok", "duration_seconds": elapsed}

        except sqlite3.OperationalError:
            return {"status": "ok", "message": "No FTS5 table to rebuild"}
        finally:
            conn.close()

    def optimize_fts(self) -> Dict:
        """Optimize the FTS5 index for faster queries."""
        conn = sqlite3.connect(self.db_path)
        try:
            conn.execute("INSERT INTO memories_fts(memories_fts) VALUES('optimize')")
            conn.commit()
            return {"status": "ok"}
        except sqlite3.OperationalError:
            return {"status": "ok", "message": "No FTS5 table"}
        finally:
            conn.close()

    # ------------------------------------------------------------------
    # Shard Recommendations
    # ------------------------------------------------------------------

    def shard_analysis(self) -> Dict:
        """Analyze whether the brain should be sharded and how.

        Returns recommendations based on current scale.
        """
        s = self.stats()
        primary = s.get("primary", {})
        memories = primary.get("active_memories", 0)
        size_mb = primary.get("size_mb", 0)

        analysis = {
            "current_memories": memories,
            "current_size_mb": size_mb,
            "recommendation": "no_action",
            "details": "",
        }

        if memories < 10000 and size_mb < 100:
            analysis["recommendation"] = "no_action"
            analysis["details"] = "Brain is well within single-DB limits. No sharding needed."

        elif memories < 50000 and size_mb < 300:
            analysis["recommendation"] = "compact_only"
            analysis["details"] = (
                "Brain is growing. Run periodic compaction to archive stale memories. "
                "No sharding needed yet. Command: aibrain scale compact"
            )

        elif memories < 200000 and size_mb < 500:
            analysis["recommendation"] = "archive_tier"
            analysis["details"] = (
                "Brain is large. Implement two-tier storage: hot (primary) + cold (archive). "
                "Compact aggressively. Rebuild FTS5 index after compaction. "
                "Commands: aibrain scale compact && aibrain scale rebuild-fts"
            )

        else:
            analysis["recommendation"] = "domain_sharding"
            analysis["details"] = (
                "Brain exceeds recommended single-DB limits. Consider domain-based sharding: "
                "security memories in one DB, development in another, personal in a third. "
                "Use brain_mesh with domain-filtered merges to recombine when needed. "
                "This is an architectural change — plan it carefully."
            )

            # Suggest shard split
            try:
                conn = sqlite3.connect(self.db_path)
                rows = conn.execute(
                    "SELECT type, COUNT(*) as c FROM memories WHERE active=1 "
                    "GROUP BY type ORDER BY c DESC"
                ).fetchall()
                analysis["type_distribution"] = {r[0]: r[1] for r in rows}

                # Tag-based distribution
                tag_counts = {}
                rows = conn.execute("SELECT tags FROM memories WHERE active=1").fetchall()
                for r in rows:
                    for tag in (r[0] or "").split(","):
                        tag = tag.strip()
                        if tag and tag != "auto":
                            tag_counts[tag] = tag_counts.get(tag, 0) + 1

                top_tags = sorted(tag_counts.items(), key=lambda x: x[1], reverse=True)[:10]
                analysis["suggested_shards"] = [t[0] for t in top_tags[:5]]
                conn.close()
            except Exception:
                pass

        return analysis


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def cli_versioning(args: List[str], db_path: str) -> int:
    """Handle `aibrain version <subcommand>` CLI."""
    v = BrainVersioning(db_path)

    if not args:
        print("Usage: aibrain version <snapshot|list|rollback|diff|branch|checkout|merge|prune>")
        return 1

    subcmd = args[0]

    # Tier enforcement — branching/merging requires Pro+
    try:
        from aibrain_licensing import check_tier, upgrade_message
        pro_cmds = {"branch", "checkout", "merge", "prune"}
        if subcmd in pro_cmds and not check_tier("pro"):
            print(upgrade_message("pro"))
            return 1
    except ImportError:
        pass

    if subcmd == "snapshot":
        msg = " ".join(args[1:]) if len(args) > 1 else ""
        result = v.snapshot(msg)
        print(f"Snapshot created: {result['id']}")
        print(f"  {result['stats']['memories']} memories, "
              f"{result['stats']['principles']} principles, "
              f"{result['stats']['size_kb']}KB")

    elif subcmd == "list":
        versions = v.list_versions()
        print(f"\n  Brain Version History ({len(versions)} snapshots)\n")
        for ver in versions:
            stats = ver.get("stats", {})
            print(f"  {ver['id']} [{ver.get('branch', 'main')}]")
            print(f"    {ver.get('message', '(no message)')}")
            print(f"    {stats.get('memories', 0)} mem, {stats.get('principles', 0)} prin, "
                  f"{stats.get('size_kb', 0)}KB")

    elif subcmd == "rollback":
        if len(args) > 1:
            result = v.rollback(args[1])
            if result["status"] == "ok":
                print(f"Rolled back to: {result['rolled_back_to']}")
            else:
                print(f"Error: {result['message']}")
        else:
            print("Usage: aibrain version rollback <version_id>")

    elif subcmd == "diff":
        if len(args) > 1:
            version_b = args[2] if len(args) > 2 else None
            result = v.diff(args[1], version_b)
            if "error" in result:
                print(f"Error: {result['error']}")
            else:
                print(f"\n  Diff: {result['from']} → {result['to']}\n")
                for key, delta in result["delta"].items():
                    change = delta["change"]
                    arrow = "↑" if change > 0 else "↓" if change < 0 else "="
                    print(f"  {key:15s}: {delta['before']} → {delta['after']} ({arrow}{abs(change)})")
        else:
            print("Usage: aibrain version diff <version_a> [version_b]")

    elif subcmd == "branch":
        if len(args) > 1:
            result = v.branch(args[1])
            print(f"Branch created: {args[1]}")
            print(f"  DB: {result['db_path']}")
        else:
            branches = v.list_branches()
            for name, info in branches.items():
                current = " ← current" if info.get("current") else ""
                print(f"  {'*' if info.get('current') else ' '} {name}{current}")

    elif subcmd == "checkout":
        if len(args) > 1:
            result = v.checkout(args[1])
            if result["status"] == "ok":
                print(f"Switched to branch: {result['branch']}")
            else:
                print(f"Error: {result['message']}")
        else:
            print("Usage: aibrain version checkout <branch>")

    elif subcmd == "merge":
        if len(args) > 1:
            result = v.merge_branch(args[1])
            if result["status"] == "ok":
                print(f"Merged branch '{result['merged_from']}':")
                print(f"  +{result['memories_added']} memories, "
                      f"+{result['principles_boosted']} principles boosted")
            else:
                print(f"Error: {result['message']}")
        else:
            print("Usage: aibrain version merge <branch>")

    elif subcmd == "prune":
        keep = int(args[2]) if len(args) > 2 and args[1] == "--keep" else 10
        result = v.prune(keep_last=keep)
        print(f"Pruned {result['pruned']} old snapshots, {result['remaining']} remaining")

    elif subcmd == "storage":
        usage = v.storage_used()
        print(f"  Snapshots: {usage['snapshots']}")
        print(f"  Branches: {usage['branches']}")
        print(f"  Total: {usage['total_mb']}MB")

    return 0


def cli_scale(args: List[str], db_path: str) -> int:
    """Handle `aibrain scale <subcommand>` CLI."""
    s = BrainScale(db_path)

    if not args:
        print("Usage: aibrain scale <stats|compact|search-archive|promote|rebuild-fts|analyze>")
        return 1

    subcmd = args[0]

    # Tier enforcement — scale management requires Pro+
    try:
        from aibrain_licensing import check_tier, upgrade_message
        pro_cmds = {"compact", "analyze"}
        if subcmd in pro_cmds and not check_tier("pro"):
            print(upgrade_message("pro"))
            return 1
    except ImportError:
        pass

    if subcmd == "stats":
        report = s.stats()
        primary = report["primary"]
        print(f"\n  Brain Health: {report['health'].upper()}\n")
        print(f"  Primary DB: {primary.get('size_mb', 0)}MB")
        print(f"    Active memories: {primary.get('active_memories', 0)}")
        print(f"    Inactive: {primary.get('inactive_memories', 0)}")
        print(f"    Stale (90d+): {primary.get('stale_memories', 0)}")
        print(f"    Principles: {primary.get('active_principles', 0)}")
        print(f"    Episodes: {primary.get('episodes', 0)}")
        print(f"    FTS entries: {primary.get('fts_entries', 'N/A')}")

        if report["archive"]["exists"]:
            print(f"\n  Archive: {report['archive'].get('size_mb', 0)}MB, "
                  f"{report['archive'].get('memories', 0)} memories")

        if report["warnings"]:
            print(f"\n  ⚠️ Warnings:")
            for w in report["warnings"]:
                print(f"    - {w}")

    elif subcmd == "compact":
        dry_run = "--dry-run" in args
        result = s.compact(dry_run=dry_run)
        if dry_run:
            print(f"DRY RUN — would archive {result['candidates']} memories")
            for item in result.get("preview", []):
                print(f"  - {item['name']} (importance={item['importance']}, last={item['last_updated']})")
        else:
            print(f"Compacted: {result['archived']} memories archived, "
                  f"{result.get('freed_mb', 0)}MB freed")

    elif subcmd == "search-archive":
        if len(args) > 1:
            query = " ".join(args[1:])
            results = s.search_archive(query)
            if results:
                print(f"Found {len(results)} archived memories:")
                for r in results:
                    print(f"  - {r['name']}: {r['content'][:80]}")
                print(f"\nPromote with: aibrain scale promote <name>")
            else:
                print("No archived memories match that query.")
        else:
            print("Usage: aibrain scale search-archive <query>")

    elif subcmd == "promote":
        if len(args) > 1:
            result = s.promote(args[1:])
            print(f"Promoted {result['promoted']} memories back to hot tier")
        else:
            print("Usage: aibrain scale promote <name1> [name2] ...")

    elif subcmd == "rebuild-fts":
        result = s.rebuild_fts()
        print(f"FTS5 index rebuilt in {result.get('duration_seconds', 0)}s")

    elif subcmd == "analyze":
        analysis = s.shard_analysis()
        print(f"\n  Scale Analysis")
        print(f"  Current: {analysis['current_memories']} memories, {analysis['current_size_mb']}MB")
        print(f"  Recommendation: {analysis['recommendation']}")
        print(f"  {analysis['details']}")

        if "suggested_shards" in analysis:
            print(f"\n  Suggested shard domains: {', '.join(analysis['suggested_shards'])}")
        if "type_distribution" in analysis:
            print(f"\n  Memory type distribution:")
            for t, c in analysis["type_distribution"].items():
                print(f"    {t}: {c}")

    return 0
