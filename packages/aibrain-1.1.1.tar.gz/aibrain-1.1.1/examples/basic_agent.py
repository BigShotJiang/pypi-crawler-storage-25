"""
Example: Connect any AI agent to AIBrain in under 10 lines.

This shows the minimal pattern — call your LLM, use AIBrain for memory.
Replace the LLM call with your preferred provider.
"""

import os
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from aibrain_sdk import AIBrain

# Connect to AIBrain
aos = AIBrain("http://localhost:8001", agent_name="my-agent")

# Verify connection
if not aos.is_alive():
    print("AIBrain is not running. Start it with: cd backend && python -m uvicorn main:app --port 8001")
    sys.exit(1)

print(f"Connected to AIBrain: {aos.health()}")

# --- Your agent loop goes here ---

# 1. Recall relevant context
context = aos.recall("project goals")
print(f"Found {len(context)} relevant memories")

# 2. Call your LLM (replace with your provider)
# response = openai.chat(messages=[...])
# response = anthropic.messages.create(...)
# response = ollama.chat(model="llama3", messages=[...])
user_input = input("\nYou: ")

# 3. Store what you learned
aos.remember(f"User said: {user_input}", tags=["conversation"])

# 4. Communicate via chat panel
aos.say(f"Processed user input: {user_input[:50]}...")

# 5. Log activity
aos.log_activity("chat", f"Handled user message: {user_input[:50]}...")

print("\nDone. Check the AIBrain dashboard at http://localhost:5173")
