"""
Example: Local LLM agent (Ollama) with AIBrain memory.

Requires: Ollama running locally (https://ollama.ai)
No API key needed — fully local and private.
"""

import json
import os
import sys
import urllib.request
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from aibrain_sdk import AIBrain

OLLAMA_URL = os.environ.get("OLLAMA_URL", "http://localhost:11434")
OLLAMA_MODEL = os.environ.get("OLLAMA_MODEL", "llama3")

aos = AIBrain("http://localhost:8001", agent_name="ollama-agent")

summary = aos.memory_summary()
print(f"AIBrain connected — {summary['total']} memories loaded")
print(f"Using Ollama model: {OLLAMA_MODEL}")

while True:
    user_input = input("\nYou: ").strip()
    if not user_input or user_input.lower() in ("exit", "quit"):
        break

    memories = aos.recall(user_input, limit=5)
    memory_context = "\n".join(f"- {m.get('name', '')}: {m.get('content', m.get('preview', ''))}" for m in memories)

    # Call Ollama API (stdlib only)
    payload = json.dumps({
        "model": OLLAMA_MODEL,
        "prompt": f"Context from memory:\n{memory_context}\n\nUser: {user_input}\nAssistant:",
        "stream": False,
    }).encode()

    req = urllib.request.Request(f"{OLLAMA_URL}/api/generate", data=payload,
                                 headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            result = json.loads(resp.read().decode())
            reply = result["response"]
    except Exception as e:
        print(f"Ollama error: {e}")
        print(f"Is Ollama running? Try: ollama serve")
        continue

    print(f"\nAgent: {reply}")

    aos.remember(f"User: {user_input}\nAgent: {reply[:200]}", tags=["conversation"])
    aos.say(reply[:200])
