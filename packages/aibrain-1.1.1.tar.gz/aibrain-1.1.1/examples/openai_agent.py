"""
Example: OpenAI GPT agent with AIBrain memory and tools.

Requires: pip install openai
Set OPENAI_API_KEY env var.
"""

import os
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from aibrain_sdk import AIBrain

try:
    from openai import OpenAI
except ImportError:
    print("Install openai: pip install openai")
    sys.exit(1)

aos = AIBrain("http://localhost:8001", agent_name="gpt-agent")
client = OpenAI()

summary = aos.memory_summary()
print(f"AIBrain connected — {summary['total']} memories loaded")

while True:
    user_input = input("\nYou: ").strip()
    if not user_input or user_input.lower() in ("exit", "quit"):
        break

    memories = aos.recall(user_input, limit=5)
    memory_context = "\n".join(f"- {m.get('name', '')}: {m.get('content', m.get('preview', ''))}" for m in memories)

    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[
            {"role": "system", "content": f"You are an AI assistant with AIBrain memory.\n\nRelevant memories:\n{memory_context}"},
            {"role": "user", "content": user_input},
        ],
    )

    reply = response.choices[0].message.content
    print(f"\nAgent: {reply}")

    aos.remember(f"User: {user_input}\nAgent: {reply[:200]}", tags=["conversation"])
    aos.say(reply[:200])
