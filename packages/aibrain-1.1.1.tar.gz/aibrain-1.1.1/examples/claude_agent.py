"""
Example: Claude-powered agent with AIBrain memory and tools.

Requires: pip install anthropic
Set ANTHROPIC_API_KEY env var or pass to constructor.
"""

import os
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from aibrain_sdk import AIBrain

try:
    import anthropic
except ImportError:
    print("Install anthropic: pip install anthropic")
    sys.exit(1)

aos = AIBrain("http://localhost:8001", agent_name="claude-agent")
client = anthropic.Anthropic()

# Build context from AIBrain memory
summary = aos.memory_summary()
print(f"AIBrain connected — {summary['total']} memories loaded")

# Agent loop
while True:
    user_input = input("\nYou: ").strip()
    if not user_input or user_input.lower() in ("exit", "quit"):
        break

    # Recall relevant memories
    memories = aos.recall(user_input, limit=5)
    memory_context = "\n".join(f"- {m.get('name', '')}: {m.get('content', m.get('preview', ''))}" for m in memories)

    # Call Claude with memory context
    system_prompt = f"""You are an AI assistant powered by AIBrain.
You have access to persistent memory. Here are relevant memories for this conversation:

{memory_context if memory_context else "No relevant memories found."}

Be helpful, concise, and direct."""

    response = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=1024,
        system=system_prompt,
        messages=[{"role": "user", "content": user_input}],
    )

    reply = response.content[0].text
    print(f"\nAgent: {reply}")

    # Store conversation in AIBrain memory
    aos.remember(
        f"User: {user_input}\nAgent: {reply[:200]}",
        name=f"chat:{user_input[:50]}",
        type="reference",
        tags=["conversation", "chat"],
    )

    # Show in dashboard chat
    aos.say(reply[:200])
