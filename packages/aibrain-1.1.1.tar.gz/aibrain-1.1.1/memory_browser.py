#!/usr/bin/env python3
"""
memory_browser.py — See What Your Agent Knows

Generates a searchable, filterable HTML view of all memories, facts,
skills, and entity relationships. Opens in the default browser.
No server required — generates a static HTML file.

Usage:
    python memory_browser.py                    # opens browser
    python memory_browser.py --output brain.html  # save to file
    aibrain browse                               # via CLI entry point
"""

import json
import os
import sqlite3
import sys
import tempfile
import webbrowser
from datetime import datetime
from pathlib import Path
from html import escape


def _load_brain_data(db_path: str) -> dict:
    """Load all relevant data from the aibrain database."""
    conn = sqlite3.connect(db_path, check_same_thread=False)
    conn.row_factory = sqlite3.Row

    data = {
        "memories": [],
        "facts": [],
        "skills": [],
        "topics": [],
        "narratives": [],
        "stats": {},
    }

    # Memories
    try:
        rows = conn.execute("""
            SELECT id, name, type, memory_class, tags, content, importance,
                   COALESCE(effective_importance, importance) as eff_importance,
                   access_count, last_accessed, created, updated, active,
                   COALESCE(archived, 0) as archived,
                   COALESCE(sensitivity, 'standard') as sensitivity
            FROM memories WHERE active=1
            ORDER BY updated DESC
        """).fetchall()
        data["memories"] = [dict(r) for r in rows]
    except sqlite3.OperationalError:
        try:
            rows = conn.execute("""
                SELECT id, name, type, tags, content, importance,
                       access_count, last_accessed, created, updated, active
                FROM memories WHERE active=1
                ORDER BY updated DESC
            """).fetchall()
            data["memories"] = [dict(r) for r in rows]
        except sqlite3.OperationalError:
            pass

    # Semantic facts
    try:
        rows = conn.execute("""
            SELECT subject, predicate, object, fact_type, sentiment, confidence, status
            FROM semantic_facts WHERE status='ACTIVE'
            ORDER BY confidence DESC
        """).fetchall()
        data["facts"] = [dict(r) for r in rows]
    except sqlite3.OperationalError:
        pass

    # Skill profiles
    try:
        rows = conn.execute("SELECT * FROM skill_profiles ORDER BY total_episodes DESC").fetchall()
        data["skills"] = [dict(r) for r in rows]
    except sqlite3.OperationalError:
        pass

    # Topic registry
    try:
        rows = conn.execute("SELECT * FROM topic_registry ORDER BY last_discussed DESC").fetchall()
        data["topics"] = [dict(r) for r in rows]
    except sqlite3.OperationalError:
        pass

    # Session narratives
    try:
        rows = conn.execute("SELECT * FROM session_narratives ORDER BY created_at DESC LIMIT 20").fetchall()
        data["narratives"] = [dict(r) for r in rows]
    except sqlite3.OperationalError:
        pass

    # Stats
    data["stats"] = {
        "total_memories": len(data["memories"]),
        "total_facts": len(data["facts"]),
        "total_skills": len(data["skills"]),
        "total_topics": len(data["topics"]),
        "db_path": db_path,
        "generated_at": datetime.now().isoformat(),
    }

    conn.close()
    return data


def _generate_html(data: dict) -> str:
    """Generate a complete, self-contained HTML page for brain browsing."""

    memories_json = json.dumps(data["memories"], default=str)
    facts_json = json.dumps(data["facts"], default=str)
    skills_json = json.dumps(data["skills"], default=str)
    topics_json = json.dumps(data["topics"], default=str)
    narratives_json = json.dumps(data["narratives"], default=str)
    stats = data["stats"]

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>aibrain — Memory Browser</title>
<style>
:root {{
  --bg: #0a0a0f; --surface: #12121a; --border: #1e1e2e;
  --text: #e0e0e8; --dim: #8888aa; --accent: #00f5d4;
  --warn: #ff6b6b; --info: #4dabf7;
}}
* {{ margin:0; padding:0; box-sizing:border-box; }}
body {{ background:var(--bg); color:var(--text); font-family:'SF Mono',Consolas,monospace; font-size:13px; }}
.container {{ max-width:1200px; margin:0 auto; padding:20px; }}
h1 {{ color:var(--accent); font-size:18px; margin-bottom:4px; }}
.subtitle {{ color:var(--dim); font-size:12px; margin-bottom:20px; }}
.stats {{ display:flex; gap:20px; margin-bottom:20px; flex-wrap:wrap; }}
.stat {{ background:var(--surface); border:1px solid var(--border); border-radius:6px; padding:12px 16px; min-width:120px; }}
.stat-value {{ font-size:24px; color:var(--accent); font-weight:bold; }}
.stat-label {{ font-size:11px; color:var(--dim); margin-top:2px; }}
.tabs {{ display:flex; gap:4px; margin-bottom:16px; border-bottom:1px solid var(--border); padding-bottom:8px; }}
.tab {{ padding:6px 14px; cursor:pointer; border-radius:4px 4px 0 0; color:var(--dim); transition:all 0.2s; }}
.tab:hover {{ color:var(--text); background:var(--surface); }}
.tab.active {{ color:var(--accent); border-bottom:2px solid var(--accent); }}
.search {{ width:100%; padding:10px 14px; background:var(--surface); border:1px solid var(--border); border-radius:6px; color:var(--text); font-family:inherit; font-size:13px; margin-bottom:16px; outline:none; }}
.search:focus {{ border-color:var(--accent); }}
.filters {{ display:flex; gap:8px; margin-bottom:12px; flex-wrap:wrap; }}
.filter-btn {{ padding:4px 10px; background:var(--surface); border:1px solid var(--border); border-radius:12px; cursor:pointer; color:var(--dim); font-size:11px; }}
.filter-btn.active {{ border-color:var(--accent); color:var(--accent); }}
.panel {{ display:none; }}
.panel.active {{ display:block; }}
.memory-card {{ background:var(--surface); border:1px solid var(--border); border-radius:6px; padding:12px; margin-bottom:8px; cursor:pointer; transition:border-color 0.2s; }}
.memory-card:hover {{ border-color:var(--accent); }}
.memory-header {{ display:flex; justify-content:space-between; align-items:center; margin-bottom:4px; }}
.memory-name {{ color:var(--accent); font-weight:bold; font-size:13px; }}
.memory-meta {{ color:var(--dim); font-size:11px; }}
.memory-type {{ display:inline-block; padding:1px 6px; border-radius:3px; font-size:10px; background:var(--border); color:var(--dim); margin-right:6px; }}
.memory-content {{ color:var(--text); font-size:12px; line-height:1.5; white-space:pre-wrap; max-height:100px; overflow:hidden; transition:max-height 0.3s; }}
.memory-card.expanded .memory-content {{ max-height:none; }}
.importance-bar {{ width:60px; height:4px; background:var(--border); border-radius:2px; display:inline-block; vertical-align:middle; }}
.importance-fill {{ height:100%; border-radius:2px; background:var(--accent); }}
.fact-row {{ display:grid; grid-template-columns:120px 100px 1fr 60px; gap:8px; padding:8px; border-bottom:1px solid var(--border); font-size:12px; align-items:center; }}
.fact-subject {{ color:var(--info); }}
.fact-predicate {{ color:var(--dim); }}
.fact-object {{ color:var(--text); }}
.fact-confidence {{ color:var(--accent); text-align:right; }}
.skill-card {{ background:var(--surface); border:1px solid var(--border); border-radius:6px; padding:12px; margin-bottom:8px; }}
.skill-name {{ color:var(--accent); font-weight:bold; }}
.skill-trend {{ font-size:11px; }}
.trend-improving {{ color:#51cf66; }}
.trend-declining {{ color:var(--warn); }}
.trend-stable {{ color:var(--dim); }}
.narrative {{ background:var(--surface); border-left:3px solid var(--accent); padding:12px; margin-bottom:8px; font-style:italic; color:var(--dim); font-size:12px; line-height:1.5; }}
.empty {{ text-align:center; padding:40px; color:var(--dim); }}
.count {{ color:var(--dim); font-size:12px; margin-bottom:8px; }}
.sensitivity-vulnerable {{ border-left:3px solid var(--warn); }}
.sensitivity-personal {{ border-left:3px solid #ffd43b; }}
.sensitivity-confidential {{ border-left:3px solid #ff6b6b; }}
</style>
</head>
<body>
<div class="container">
<h1>aibrain</h1>
<p class="subtitle">Memory Browser — {escape(stats['db_path'])} — {stats['generated_at'][:19]}</p>

<div class="stats">
  <div class="stat"><div class="stat-value">{stats['total_memories']}</div><div class="stat-label">Memories</div></div>
  <div class="stat"><div class="stat-value">{stats['total_facts']}</div><div class="stat-label">Facts</div></div>
  <div class="stat"><div class="stat-value">{stats['total_skills']}</div><div class="stat-label">Skills</div></div>
  <div class="stat"><div class="stat-value">{stats['total_topics']}</div><div class="stat-label">Topics</div></div>
</div>

<div class="tabs">
  <div class="tab active" onclick="showPanel('memories')">Memories</div>
  <div class="tab" onclick="showPanel('facts')">Facts</div>
  <div class="tab" onclick="showPanel('skills')">Skills</div>
  <div class="tab" onclick="showPanel('topics')">Topics</div>
  <div class="tab" onclick="showPanel('narratives')">Sessions</div>
</div>

<input class="search" type="text" id="search" placeholder="Search memories, facts, skills..." oninput="filterAll()">

<div id="memories-panel" class="panel active">
  <div class="filters" id="type-filters"></div>
  <div class="count" id="memory-count"></div>
  <div id="memory-list"></div>
</div>

<div id="facts-panel" class="panel">
  <div class="count" id="fact-count"></div>
  <div id="fact-list"></div>
</div>

<div id="skills-panel" class="panel">
  <div id="skill-list"></div>
</div>

<div id="topics-panel" class="panel">
  <div id="topic-list"></div>
</div>

<div id="narratives-panel" class="panel">
  <div id="narrative-list"></div>
</div>
</div>

<script>
const memories = {memories_json};
const facts = {facts_json};
const skills = {skills_json};
const topics = {topics_json};
const narratives = {narratives_json};

let activeType = 'all';

function showPanel(name) {{
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.getElementById(name + '-panel').classList.add('active');
  event.target.classList.add('active');
  filterAll();
}}

function filterAll() {{
  const q = document.getElementById('search').value.toLowerCase();
  renderMemories(q);
  renderFacts(q);
  renderSkills(q);
  renderTopics(q);
  renderNarratives(q);
}}

function renderMemories(q) {{
  const types = [...new Set(memories.map(m => m.type || 'unknown'))];
  const filtersDiv = document.getElementById('type-filters');
  filtersDiv.innerHTML = '<div class="filter-btn ' + (activeType==='all'?'active':'') + '" onclick="setType(\\'all\\')">All</div>' +
    types.map(t => '<div class="filter-btn ' + (activeType===t?'active':'') + '" onclick="setType(\\'' + t + '\\')">' + t + '</div>').join('');

  let filtered = memories.filter(m => {{
    if (activeType !== 'all' && m.type !== activeType) return false;
    if (!q) return true;
    return (m.name||'').toLowerCase().includes(q) || (m.content||'').toLowerCase().includes(q) || (m.tags||'').toLowerCase().includes(q);
  }});

  document.getElementById('memory-count').textContent = filtered.length + ' of ' + memories.length + ' memories';

  const list = document.getElementById('memory-list');
  if (!filtered.length) {{ list.innerHTML = '<div class="empty">No memories match.</div>'; return; }}

  list.innerHTML = filtered.slice(0, 200).map(m => {{
    const imp = m.eff_importance || m.importance || 0.5;
    const sens = m.sensitivity || 'standard';
    const sensClass = sens !== 'standard' ? ' sensitivity-' + sens : '';
    return '<div class="memory-card' + sensClass + '" onclick="this.classList.toggle(\\'expanded\\')">' +
      '<div class="memory-header">' +
        '<span class="memory-name">' + esc(m.name) + '</span>' +
        '<span class="memory-meta">#' + m.id + ' &middot; ' + (m.updated||'').slice(0,10) + '</span>' +
      '</div>' +
      '<span class="memory-type">' + (m.type||'?') + '</span>' +
      (m.tags ? '<span class="memory-type">' + esc(m.tags).slice(0,40) + '</span>' : '') +
      (sens !== 'standard' ? '<span class="memory-type">' + sens + '</span>' : '') +
      ' <span class="importance-bar"><span class="importance-fill" style="width:' + Math.round(imp*100) + '%"></span></span>' +
      ' <span class="memory-meta">' + (imp*100).toFixed(0) + '%</span>' +
      '<div class="memory-content">' + esc(m.content||'') + '</div>' +
    '</div>';
  }}).join('');
}}

function renderFacts(q) {{
  let filtered = facts.filter(f => {{
    if (!q) return true;
    return (f.subject||'').toLowerCase().includes(q) || (f.predicate||'').toLowerCase().includes(q) || (f.object||'').toLowerCase().includes(q);
  }});
  document.getElementById('fact-count').textContent = filtered.length + ' of ' + facts.length + ' facts';
  const list = document.getElementById('fact-list');
  if (!filtered.length) {{ list.innerHTML = '<div class="empty">No facts match.</div>'; return; }}
  list.innerHTML = filtered.slice(0, 200).map(f =>
    '<div class="fact-row">' +
      '<span class="fact-subject">' + esc(f.subject) + '</span>' +
      '<span class="fact-predicate">' + esc(f.predicate) + '</span>' +
      '<span class="fact-object">' + esc(f.object) + '</span>' +
      '<span class="fact-confidence">' + ((f.confidence||0)*100).toFixed(0) + '%</span>' +
    '</div>'
  ).join('');
}}

function renderSkills(q) {{
  const list = document.getElementById('skill-list');
  if (!skills.length) {{ list.innerHTML = '<div class="empty">No skills tracked yet.</div>'; return; }}
  list.innerHTML = skills.filter(s => !q || (s.task_type||'').toLowerCase().includes(q)).map(s => {{
    const trendClass = s.trend === 'improving' ? 'trend-improving' : s.trend === 'declining' ? 'trend-declining' : 'trend-stable';
    return '<div class="skill-card">' +
      '<span class="skill-name">' + esc(s.task_type) + '</span>' +
      ' &middot; ' + (s.total_episodes||0) + ' episodes' +
      ' &middot; ' + ((s.avg_outcome||0)*100).toFixed(0) + '% avg' +
      ' &middot; <span class="skill-trend ' + trendClass + '">' + (s.trend||'stable') + '</span>' +
      (s.best_approach ? '<div class="memory-meta" style="margin-top:4px">Best approach: ' + esc(s.best_approach).slice(0,100) + '</div>' : '') +
    '</div>';
  }}).join('');
}}

function renderTopics(q) {{
  const list = document.getElementById('topic-list');
  if (!topics.length) {{ list.innerHTML = '<div class="empty">No topics registered.</div>'; return; }}
  list.innerHTML = topics.filter(t => !q || (t.topic||'').toLowerCase().includes(q)).map(t =>
    '<div class="memory-card">' +
      '<div class="memory-header">' +
        '<span class="memory-name">' + esc(t.topic) + '</span>' +
        '<span class="memory-meta">' + (t.resolution||'open') + '</span>' +
      '</div>' +
      '<span class="memory-type">' + (t.discussion_count||1) + 'x discussed</span>' +
      (t.resolution_summary ? '<div class="memory-content">' + esc(t.resolution_summary) + '</div>' : '') +
    '</div>'
  ).join('');
}}

function renderNarratives(q) {{
  const list = document.getElementById('narrative-list');
  if (!narratives.length) {{ list.innerHTML = '<div class="empty">No session narratives yet.</div>'; return; }}
  list.innerHTML = narratives.filter(n => !q || (n.narrative||'').toLowerCase().includes(q)).map(n =>
    '<div class="narrative">' +
      '<div class="memory-meta" style="margin-bottom:4px">' + (n.created_at||'').slice(0,16) + '</div>' +
      esc(n.narrative) +
    '</div>'
  ).join('');
}}

function setType(t) {{ activeType = t; filterAll(); }}
function esc(s) {{ const d = document.createElement('div'); d.textContent = s||''; return d.innerHTML; }}

// Initial render
filterAll();
</script>
</body>
</html>"""


def browse(db_path: str = None, output: str = None):
    """Generate and open the memory browser."""
    if db_path is None:
        db_path = str(Path.home() / "aibrain" / "aibrain.db")
        # Also check AIBRAIN_ROOT
        root = os.environ.get("AIBRAIN_ROOT", "")
        if root:
            candidate = Path(root) / "aibrain.db"
            if candidate.exists():
                db_path = str(candidate)

    if not Path(db_path).exists():
        print(f"Database not found: {db_path}")
        print("Run 'aibrain init' first or set AIBRAIN_ROOT")
        return

    print(f"Loading brain from {db_path}...")
    data = _load_brain_data(db_path)
    html = _generate_html(data)

    if output:
        out_path = Path(output)
    else:
        out_path = Path(tempfile.mktemp(suffix=".html", prefix="aibrain_"))

    out_path.write_text(html, encoding="utf-8")
    print(f"Brain browser saved to: {out_path}")

    if not output:
        webbrowser.open(f"file://{out_path.resolve()}")
        print("Opened in browser.")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="aibrain Memory Browser")
    parser.add_argument("--db", type=str, default=None, help="Path to aibrain.db")
    parser.add_argument("--output", type=str, default=None, help="Save HTML to file instead of opening")
    args = parser.parse_args()
    browse(args.db, args.output)
