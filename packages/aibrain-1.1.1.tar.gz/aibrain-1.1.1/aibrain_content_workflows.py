#!/usr/bin/env python3
"""
aibrain_content_workflows.py — Platform-Specific Content Creation

Each platform gets its own workflow that understands:
- Character/word limits
- Content format requirements (text, image specs, video specs)
- Platform culture and posting norms
- Hashtag/tagging conventions
- Optimal posting times

Plus orchestration workflows for batch scheduling and repurposing.

Platforms: LinkedIn, X/Twitter, Reddit, Medium, TikTok, Instagram, Facebook, YouTube
"""

import json
import logging
import re
import sqlite3
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List

log = logging.getLogger("aibrain.content")


class ContentWorkflow:
    name = "base"
    display_name = "Base"
    description = ""
    category = "content"
    schedule_cron = "0 7 * * *"

    def __init__(self, db_path: str, config: Dict = None):
        self.db_path = db_path
        self.config = config or {}
        self._conn = None

    def _db(self):
        if self._conn is None:
            self._conn = sqlite3.connect(self.db_path, check_same_thread=False)
            self._conn.row_factory = sqlite3.Row
        return self._conn

    def store(self, name, content, mem_type="reference", tags="", importance=0.5):
        db = self._db()
        try:
            existing = db.execute("SELECT id FROM memories WHERE name=? AND active=1", (name,)).fetchone()
            if existing:
                db.execute("UPDATE memories SET content=?, tags=?, importance=?, updated=datetime('now') WHERE id=?",
                           (content, tags, importance, existing[0]))
            else:
                db.execute("INSERT INTO memories (name, type, tags, content, importance, created, updated, active) "
                           "VALUES (?, ?, ?, ?, ?, datetime('now'), datetime('now'), 1)",
                           (name, mem_type, tags, content, importance))
            db.commit()
        except Exception as e:
            log.error("[%s] store: %s", self.name, e)

    def search(self, query, limit=10):
        db = self._db()
        try:
            rows = db.execute("SELECT name, content, tags, created FROM memories "
                              "WHERE active=1 AND content LIKE ? ORDER BY updated DESC LIMIT ?",
                              (f"%{query}%", limit)).fetchall()
            return [dict(r) for r in rows]
        except Exception:
            return []

    def cfg(self, key, default=None):
        return self.config.get(key, default)

    def _get_content_pillars(self) -> List[str]:
        """Load content pillars from config or defaults."""
        pillars = self.cfg("content_pillars",
            "The Science (SelRoute benchmarks),"
            "The Build (solo builder story),"
            "The Problem (AI amnesia),"
            "The Vision (agent identity),"
            "The How (tutorials),"
            "The Market (brain marketplace)"
        ).split(",")
        return [p.strip() for p in pillars if p.strip()]

    def _get_week_theme(self) -> str:
        """Rotate through content pillars by week."""
        pillars = self._get_content_pillars()
        if not pillars:
            return "general"
        week_num = int(datetime.now().strftime("%W"))
        return pillars[week_num % len(pillars)]

    def run(self) -> Dict:
        return {"status": "not_implemented"}

    @property
    def schedule(self):
        return self.schedule_cron


# =========================================================================
# PLATFORM-SPECIFIC GENERATORS (8)
# =========================================================================

class LinkedInGenerator(ContentWorkflow):
    """Generate LinkedIn-specific content.

    LinkedIn specs:
    - Post: 3,000 chars max (700-1,300 optimal)
    - Hook in first 2 lines (before "see more")
    - Line breaks liberally — wall of text = scroll past
    - 3-5 hashtags at bottom
    - Image: 1200x627px (landscape) or 1080x1080 (square)
    - Carousel: PDF upload, 1080x1350px per slide, max 10 slides
    - Video: 3 sec - 10 min, 1920x1080 or 1080x1080, MP4
    - Best times: Tue-Thu 7-8am, 12pm, 5-6pm local
    """
    name = "linkedin_content"
    display_name = "LinkedIn Content Generator"
    description = "Generate LinkedIn posts with hooks, formatting, hashtags, and image/carousel specs"
    category = "content"
    schedule_cron = "0 6 * * 1"  # Monday 6am — plan week's LinkedIn

    def run(self) -> Dict:
        theme = self._get_week_theme()
        today = datetime.now()
        week_start = today - timedelta(days=today.weekday())

        # Get recent achievements/insights for content
        recent = self.search("shipped", limit=5)
        recent += self.search("learned", limit=5)
        recent += self.search("insight", limit=5)

        days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
        post_times = ["7:30 AM", "12:00 PM", "7:30 AM", "5:30 PM", "8:00 AM"]

        plan = f"# LinkedIn Content — Week of {week_start.strftime('%Y-%m-%d')}\n"
        plan += f"**Theme:** {theme}\n\n"

        plan += "## Platform Specs\n"
        plan += "- **Max chars:** 3,000 (aim 700-1,300)\n"
        plan += "- **Hook:** first 2 lines visible before fold — MUST stop the scroll\n"
        plan += "- **Format:** short paragraphs, line breaks, no walls of text\n"
        plan += "- **Hashtags:** 3-5 at bottom (#AIAgents #SecurityAutomation #BuildInPublic)\n"
        plan += "- **Image:** 1200x627px landscape OR 1080x1080px square\n"
        plan += "- **Carousel:** PDF, 1080x1350px per slide, max 10\n"
        plan += "- **Video:** MP4, 1920x1080 or 1080x1080, 3sec-10min\n\n"

        for i, (day, time) in enumerate(zip(days, post_times)):
            date = (week_start + timedelta(days=i)).strftime("%Y-%m-%d")
            plan += f"### {day} {date} — Post at {time} ACST\n"
            plan += f"**Type:** {'Text + Image' if i % 2 == 0 else 'Carousel (PDF)'}\n"
            plan += f"**Hook:** [Write a 2-line hook related to: {theme}]\n"
            plan += f"**Body:** [700-1300 chars, short paragraphs, line breaks]\n"
            plan += f"**CTA:** [Question or 'DM me for...']\n"
            plan += f"**Image spec:** {'1200x627px landscape' if i % 2 == 0 else '1080x1350px x5 slides'}\n"
            plan += f"**Hashtags:** #AIAgents #aibrain #SecurityAutomation #BuildInPublic #SoloFounder\n\n"

        plan += "## Hook Templates\n"
        plan += "- \"Most [professionals] think [common belief]. They're wrong.\"\n"
        plan += "- \"I [did surprising thing]. Here's what happened.\"\n"
        plan += "- \"[Specific number] that should concern every [role]:\"\n"
        plan += "- \"The difference between [good] and [great] is [insight].\"\n"
        plan += "- \"Stop [common mistake]. Start [better approach]. Here's why:\"\n"

        self.store(f"linkedin_plan_{week_start.strftime('%Y_W%W')}",
                   plan, "project", "linkedin,content,plan,weekly,auto", 0.6)
        return {"status": "ok", "posts_planned": 5}


class XTwitterGenerator(ContentWorkflow):
    """Generate X/Twitter-specific content.

    X specs:
    - Tweet: 280 chars max
    - Thread: max ~25 tweets, number them, hook in tweet 1
    - Image: 1600x900px (16:9) or 1080x1080 (1:1), max 4 per tweet
    - Video: MP4, max 2:20 (regular) or 10min (premium), 1920x1080
    - Best times: 8-10am, 12-1pm, 7-9pm
    - Quote tweets > plain retweets for engagement
    """
    name = "x_twitter_content"
    display_name = "X/Twitter Content Generator"
    description = "Generate tweets and threads with hooks, character counting, and image specs"
    category = "content"
    schedule_cron = "0 6 * * 1"

    def run(self) -> Dict:
        theme = self._get_week_theme()
        week_start = datetime.now() - timedelta(days=datetime.now().weekday())

        plan = f"# X/Twitter Content — Week of {week_start.strftime('%Y-%m-%d')}\n"
        plan += f"**Theme:** {theme}\n\n"

        plan += "## Platform Specs\n"
        plan += "- **Tweet:** 280 chars MAX (aim 200-240 for engagement room)\n"
        plan += "- **Thread:** 7-12 tweets, number them (1/7, 2/7...), hook in tweet 1\n"
        plan += "- **Image:** 1600x900px (16:9) optimal, max 4 per tweet\n"
        plan += "- **Video:** MP4, 1920x1080, max 2:20\n"
        plan += "- **Best times:** 8am, 12pm, 8pm ACST\n\n"

        # Daily schedule: 2 tweets + 1 thread per week
        days_content = [
            ("Mon", "standalone", "8:00 AM", "Technical insight tweet + image"),
            ("Tue", "thread", "8:00 AM", "Weekly thread (7-10 tweets) on theme"),
            ("Wed", "standalone", "12:00 PM", "Build update / behind the scenes"),
            ("Thu", "standalone", "8:00 PM", "Industry observation or hot take"),
            ("Fri", "standalone", "12:00 PM", "Weekly win or metric"),
            ("Sat", "engagement", "10:00 AM", "Quote-tweet 3 relevant posts with insight"),
            ("Sun", "standalone", "8:00 PM", "Teaser for next week"),
        ]

        for day, content_type, time, desc in days_content:
            plan += f"### {day} — {time} ACST\n"
            plan += f"**Type:** {content_type}\n"
            plan += f"**Content:** {desc}\n"
            if content_type == "thread":
                plan += f"**Thread structure:**\n"
                plan += f"  1/ Hook (the most provocative claim) [<280 chars]\n"
                plan += f"  2/ Context (why this matters) [<280 chars]\n"
                plan += f"  3-6/ Evidence/examples [<280 chars each]\n"
                plan += f"  7/ Conclusion + CTA [<280 chars]\n"
            plan += f"**Image:** 1600x900px with key stat or code snippet\n\n"

        plan += "## Hook Formulas (under 280 chars)\n"
        plan += "- \"Your AI starts from scratch every conversation. That's not a feature.\"\n"
        plan += "- \"22MB. That's all it takes to beat models 70x larger. Here's how 🧵\"\n"
        plan += "- \"I ran 15 blind test cycles. 38,190 findings. Here's what I learned:\"\n"
        plan += "- \"pip install aibrain. 60 seconds. Your agent remembers everything.\"\n"

        self.store(f"x_plan_{week_start.strftime('%Y_W%W')}",
                   plan, "project", "x,twitter,content,plan,weekly,auto", 0.6)
        return {"status": "ok", "posts_planned": 7}


class RedditGenerator(ContentWorkflow):
    """Generate Reddit-specific content.

    Reddit specs:
    - Title: 300 chars max (aim 60-100 for readability)
    - Body: no hard limit but 500-2000 words optimal for technical
    - NO self-promotion in first 80% of posts — value first
    - Match subreddit culture exactly or get downvoted to oblivion
    - Flair required in most subs
    - Images: varies by sub, usually link posts
    - Video: hosted on Reddit, or link to YouTube
    - Key subs: r/netsec, r/cybersecurity, r/LocalLLaMA, r/selfhosted, r/artificial
    """
    name = "reddit_content"
    display_name = "Reddit Content Generator"
    description = "Generate Reddit posts per subreddit with culture-matched tone and 80/20 value-first ratio"
    category = "content"
    schedule_cron = "0 6 * * 1"

    def run(self) -> Dict:
        theme = self._get_week_theme()
        week_start = datetime.now() - timedelta(days=datetime.now().weekday())

        subreddits = {
            "r/netsec": {
                "tone": "Deeply technical, no hype, cite sources",
                "topics": "Vulnerability research, pentesting methodology, tool architecture",
                "rules": "No promotional posts. Technical depth required. Self-posts preferred.",
                "day": "Tuesday",
            },
            "r/cybersecurity": {
                "tone": "Professional, accessible, practical",
                "topics": "Compliance, automation, career, tool comparisons",
                "rules": "Beginner-friendly OK. Link posts allowed. Flair required.",
                "day": "Wednesday",
            },
            "r/LocalLLaMA": {
                "tone": "Technical, benchmark-focused, model comparisons",
                "topics": "SelRoute results, small model performance, local inference",
                "rules": "Benchmarks expected. Show your work. Code/paper links appreciated.",
                "day": "Thursday",
            },
            "r/selfhosted": {
                "tone": "Practical, Docker-first, privacy-conscious",
                "topics": "Air-gapped tools, SQLite-based, local-first architecture",
                "rules": "Must be self-hostable. Docker Compose preferred. No SaaS pitches.",
                "day": "Friday",
            },
            "r/artificial": {
                "tone": "Conversational, forward-looking, philosophical OK",
                "topics": "Agent memory, AI identity, skill acquisition, brain marketplace concept",
                "rules": "Discussion posts do well. Hot takes welcome if backed up.",
                "day": "Saturday",
            },
        }

        plan = f"# Reddit Content — Week of {week_start.strftime('%Y-%m-%d')}\n"
        plan += f"**Theme:** {theme}\n\n"

        plan += "## Platform Specs\n"
        plan += "- **Title:** 60-100 chars, specific and intriguing\n"
        plan += "- **Body:** 500-2000 words for technical posts\n"
        plan += "- **Rule:** 80% of your Reddit activity is engaging on OTHERS' posts. 20% is your own content.\n"
        plan += "- **NEVER:** sound promotional. Lead with value. Product is in the last 10% if at all.\n"
        plan += "- **Comments:** engage for 2 hours after posting. Answer every question.\n\n"

        for sub, info in subreddits.items():
            plan += f"### {sub} — {info['day']}\n"
            plan += f"**Tone:** {info['tone']}\n"
            plan += f"**Topics:** {info['topics']}\n"
            plan += f"**Rules:** {info['rules']}\n"
            plan += f"**Title template:** [Specific claim or question about {theme}]\n"
            plan += f"**Body template:** \n"
            plan += f"  1. Hook paragraph (the insight)\n"
            plan += f"  2. Technical detail (the evidence)\n"
            plan += f"  3. What you learned (the takeaway)\n"
            plan += f"  4. Discussion question (engagement driver)\n\n"

        plan += "## Daily Engagement Tasks (non-posting)\n"
        plan += "- Comment on 3 posts across target subreddits with genuine insight\n"
        plan += "- Answer 1 question where your expertise is relevant\n"
        plan += "- Upvote quality content in your space\n"

        self.store(f"reddit_plan_{week_start.strftime('%Y_W%W')}",
                   plan, "project", "reddit,content,plan,weekly,auto", 0.6)
        return {"status": "ok", "subreddits": len(subreddits)}


class MediumGenerator(ContentWorkflow):
    """Generate Medium article plans.

    Medium specs:
    - Title: 60 chars optimal (100 max)
    - Subtitle: 140 chars max
    - Body: 1,500-2,500 words optimal (7 min read)
    - Feature image: 1400x788px (16:9)
    - Inline images: same ratio, alt text required
    - Tags: max 5, choose from existing popular tags
    - Submit to publications for distribution (Towards AI, Better Programming, etc.)
    """
    name = "medium_content"
    display_name = "Medium Content Generator"
    description = "Generate Medium article outlines with SEO titles, word targets, and publication submission plans"
    category = "content"
    schedule_cron = "0 6 * * 1"

    def run(self) -> Dict:
        theme = self._get_week_theme()
        week_start = datetime.now() - timedelta(days=datetime.now().weekday())

        plan = f"# Medium Content — Week of {week_start.strftime('%Y-%m-%d')}\n"
        plan += f"**Theme:** {theme}\n\n"

        plan += "## Platform Specs\n"
        plan += "- **Title:** 60 chars optimal, clear + specific\n"
        plan += "- **Subtitle:** 140 chars, expand on title\n"
        plan += "- **Body:** 1,500-2,500 words (7 min read sweet spot)\n"
        plan += "- **Feature image:** 1400x788px (16:9)\n"
        plan += "- **Tags:** max 5 (AI, Machine-Learning, Security, Python, Programming)\n"
        plan += "- **Frequency:** 1 article per week\n"
        plan += "- **Publish:** Thursday 10am ACST\n\n"

        plan += "## Target Publications\n"
        plan += "- Towards AI (100K+ followers)\n"
        plan += "- Better Programming (500K+ followers)\n"
        plan += "- Towards Data Science\n"
        plan += "- InfoSec Write-ups\n\n"

        plan += "## This Week's Article\n"
        plan += f"**Title:** [Related to: {theme}]\n"
        plan += "**Structure:**\n"
        plan += "1. Hook paragraph — surprising stat or bold claim (100 words)\n"
        plan += "2. Context — why this matters to the reader (200 words)\n"
        plan += "3. The approach — what you did and why (400 words)\n"
        plan += "4. Results — with data, benchmarks, screenshots (500 words)\n"
        plan += "5. Honest limitations — what didn't work (200 words)\n"
        plan += "6. Conclusion + CTA (100 words)\n"
        plan += "7. Total: ~1,500 words\n\n"

        plan += "## Article Ideas Bank\n"
        plan += "- 'How a 22MB Model Beats 70x Larger Systems at Memory Retrieval'\n"
        plan += "- 'Building an AI Agent That Actually Remembers: A Technical Deep Dive'\n"
        plan += "- 'Why Your AI Scanner Misses 60% of Vulnerabilities (And How to Fix It)'\n"
        plan += "- 'The Architecture Behind SelRoute: Query-Aware Retrieval Routing'\n"
        plan += "- 'I Built a Security Scanner With Two AI Agents. Here Are the Numbers.'\n"

        self.store(f"medium_plan_{week_start.strftime('%Y_W%W')}",
                   plan, "project", "medium,content,plan,weekly,auto", 0.6)
        return {"status": "ok"}


class TikTokGenerator(ContentWorkflow):
    """Generate TikTok-specific content.

    TikTok specs:
    - Video: 9:16 vertical (1080x1920), 15sec-10min (60-90sec optimal)
    - Caption: 2,200 chars max (front-load first 2 lines)
    - Hook: first 3 seconds or lose them
    - Hashtags: 3-5 relevant, 1-2 trending
    - Audio: trending sounds boost reach, original audio for authority
    - Best times: 7-9am, 12-3pm, 7-11pm
    """
    name = "tiktok_content"
    display_name = "TikTok Content Generator"
    description = "Generate TikTok video concepts with hooks, scripts, and caption templates"
    category = "content"
    schedule_cron = "0 6 * * 1"

    def run(self) -> Dict:
        theme = self._get_week_theme()
        week_start = datetime.now() - timedelta(days=datetime.now().weekday())

        plan = f"# TikTok Content — Week of {week_start.strftime('%Y-%m-%d')}\n"
        plan += f"**Theme:** {theme}\n\n"

        plan += "## Platform Specs\n"
        plan += "- **Video:** 1080x1920 (9:16 vertical), 60-90 seconds optimal\n"
        plan += "- **Hook:** first 3 SECONDS must stop the scroll\n"
        plan += "- **Caption:** 2,200 chars max, front-load value\n"
        plan += "- **Hashtags:** 3-5 (#AIAgents #TechTok #CodeTok #SecurityTips #BuildInPublic)\n"
        plan += "- **Frequency:** 3-5 per week\n"
        plan += "- **Best times:** 7am, 12pm, 8pm ACST\n\n"

        videos = [
            ("Mon", "talking_head", "Bold claim + proof",
             "Open with 'Everyone says [X]. They're wrong.' then show screen recording of proof."),
            ("Wed", "screen_recording", "Tutorial / demo",
             "60-sec pip install → first result. No intro, no filler, just the demo."),
            ("Fri", "trend_remix", "Trending sound + tech content",
             "Use trending audio, overlay tech insight. Visual: terminal screen or code."),
        ]

        for day, style, concept, script_note in videos:
            plan += f"### {day} — {style}\n"
            plan += f"**Concept:** {concept}\n"
            plan += f"**Script note:** {script_note}\n"
            plan += f"**Hook (3 sec):** [Single provocative sentence on screen]\n"
            plan += f"**Body (50-80 sec):** [Problem → Solution → Proof]\n"
            plan += f"**CTA (5 sec):** 'Link in bio' or 'Follow for more'\n"
            plan += f"**Caption:** [2 lines of value] + hashtags\n\n"

        plan += "## TikTok Hook Templates\n"
        plan += "- \"POV: your AI agent remembers everything\" [show terminal]\n"
        plan += "- \"I found 38,190 vulnerabilities in 14 targets. Here's how.\" [screen recording]\n"
        plan += "- \"This 22MB file beats models 70x larger\" [benchmark on screen]\n"
        plan += "- \"pip install aibrain\" [60-second speedrun from install to working memory]\n"

        self.store(f"tiktok_plan_{week_start.strftime('%Y_W%W')}",
                   plan, "project", "tiktok,content,plan,weekly,auto", 0.6)
        return {"status": "ok", "videos_planned": len(videos)}


class InstagramGenerator(ContentWorkflow):
    """Generate Instagram-specific content.

    Instagram specs:
    - Feed post image: 1080x1080 (square) or 1080x1350 (4:5 portrait)
    - Carousel: up to 10 slides, 1080x1350 each
    - Reels: 1080x1920 (9:16), 15-90sec (30-60 optimal)
    - Caption: 2,200 chars max, first 2 lines before fold
    - Hashtags: 20-30 in first comment (not caption), or 3-5 in caption
    - Stories: 1080x1920, 24hr duration, use polls/questions for engagement
    - Best times: 11am-1pm, 7-9pm
    """
    name = "instagram_content"
    display_name = "Instagram Content Generator"
    description = "Generate Instagram posts, carousels, reels, and stories with visual specs"
    category = "content"
    schedule_cron = "0 6 * * 1"

    def run(self) -> Dict:
        theme = self._get_week_theme()
        week_start = datetime.now() - timedelta(days=datetime.now().weekday())

        plan = f"# Instagram Content — Week of {week_start.strftime('%Y-%m-%d')}\n"
        plan += f"**Theme:** {theme}\n\n"

        plan += "## Platform Specs\n"
        plan += "- **Feed image:** 1080x1350px (4:5 portrait preferred) or 1080x1080 square\n"
        plan += "- **Carousel:** 1080x1350px per slide, max 10 slides\n"
        plan += "- **Reels:** 1080x1920 (9:16), 30-60 seconds\n"
        plan += "- **Stories:** 1080x1920, disappears in 24h, use interactive elements\n"
        plan += "- **Caption:** 2,200 chars, hook in first 2 lines\n"
        plan += "- **Hashtags:** 3-5 in caption OR 20-30 in first comment\n"
        plan += "- **Best times:** 11am, 7pm ACST\n\n"

        content = [
            ("Mon", "carousel", "1080x1350 x5-7 slides", "Educational carousel — break down a concept from the theme"),
            ("Wed", "reel", "1080x1920, 30-60sec", "Behind-the-scenes or quick demo — terminal screen recording with captions"),
            ("Fri", "feed_image", "1080x1350", "Quote graphic or stat visual — dark theme, cyberpunk aesthetic"),
            ("Sun", "story", "1080x1920", "Poll or question — 'What feature should we build next?' or 'How do you handle AI memory?'"),
        ]

        for day, format_type, specs, desc in content:
            plan += f"### {day} — {format_type}\n"
            plan += f"**Specs:** {specs}\n"
            plan += f"**Content:** {desc}\n"
            plan += f"**Caption:** [Hook line] + [2-3 lines of value] + CTA + hashtags\n"
            plan += f"**Visual style:** Dark bg (#0a0a0f), accent (#00f5d4), monospace code font\n\n"

        self.store(f"instagram_plan_{week_start.strftime('%Y_W%W')}",
                   plan, "project", "instagram,content,plan,weekly,auto", 0.6)
        return {"status": "ok", "posts_planned": len(content)}


class FacebookGenerator(ContentWorkflow):
    """Generate Facebook-specific content.

    Facebook specs:
    - Post: 63,206 chars max (but 40-80 words optimal for engagement)
    - Image: 1200x630px (landscape), 1080x1080 (square)
    - Video: 1280x720 minimum, max 240min, MP4
    - Link previews: auto-generated from URL
    - Groups: higher reach than pages for niche content
    - Best times: 1-4pm weekdays
    """
    name = "facebook_content"
    display_name = "Facebook Content Generator"
    description = "Generate Facebook posts optimized for groups and pages with link preview strategy"
    category = "content"
    schedule_cron = "0 6 * * 1"

    def run(self) -> Dict:
        theme = self._get_week_theme()
        week_start = datetime.now() - timedelta(days=datetime.now().weekday())

        plan = f"# Facebook Content — Week of {week_start.strftime('%Y-%m-%d')}\n"
        plan += f"**Theme:** {theme}\n\n"

        plan += "## Platform Specs\n"
        plan += "- **Post text:** 40-80 words optimal (short and punchy)\n"
        plan += "- **Image:** 1200x630px landscape\n"
        plan += "- **Video:** MP4, 1280x720+, max 240min\n"
        plan += "- **Strategy:** Groups > Page for niche reach\n"
        plan += "- **Best times:** 1-4pm ACST weekdays\n\n"

        plan += "## Target Groups\n"
        plan += "- AI/ML Developer groups\n"
        plan += "- Cybersecurity professional groups\n"
        plan += "- Australian tech/startup groups\n"
        plan += "- Python developer groups\n\n"

        plan += "## Weekly Posts (3x)\n"
        for day, desc in [("Tue", "Share blog/article with 2-line insight"),
                          ("Thu", "Behind-the-scenes build update with image"),
                          ("Sat", "Discussion question related to theme")]:
            plan += f"### {day}\n**Content:** {desc}\n"
            plan += f"**Format:** Short text (40-80 words) + image (1200x630px)\n\n"

        self.store(f"facebook_plan_{week_start.strftime('%Y_W%W')}",
                   plan, "project", "facebook,content,plan,weekly,auto", 0.5)
        return {"status": "ok"}


class YouTubeGenerator(ContentWorkflow):
    """Generate YouTube-specific content.

    YouTube specs:
    - Video: 1920x1080 (16:9) minimum, 4K preferred
    - Shorts: 1080x1920 (9:16), max 60sec
    - Thumbnail: 1280x720px, <2MB, faces + text + contrast
    - Title: 60 chars optimal (100 max), front-load keywords
    - Description: 5,000 chars max, first 2 lines visible, links + timestamps
    - Tags: 500 char limit total, 10-15 tags
    - End screen: last 20 seconds, link to next video + subscribe
    - Best upload: Thu-Sat, 2-4pm local (publish when audience is about to be online)
    - Long-form: 8-15 minutes optimal for ad revenue + retention
    - Chapters: use timestamps in description (0:00 Intro, 1:30 Setup, etc.)
    """
    name = "youtube_content"
    display_name = "YouTube Content Generator"
    description = "Generate YouTube video plans with thumbnails, descriptions, SEO tags, and chapter timestamps"
    category = "content"
    schedule_cron = "0 6 * * 1"

    def run(self) -> Dict:
        theme = self._get_week_theme()
        week_start = datetime.now() - timedelta(days=datetime.now().weekday())

        plan = f"# YouTube Content — Week of {week_start.strftime('%Y-%m-%d')}\n"
        plan += f"**Theme:** {theme}\n\n"

        plan += "## Platform Specs\n"
        plan += "- **Long-form:** 1920x1080 (16:9), 8-15 min optimal for retention + ads\n"
        plan += "- **Shorts:** 1080x1920 (9:16), max 60sec\n"
        plan += "- **Thumbnail:** 1280x720px, <2MB — face + big text + contrast\n"
        plan += "- **Title:** 60 chars, front-load keywords, emotional hook\n"
        plan += "- **Description:** first 2 lines = hook (visible before fold)\n"
        plan += "  Include: timestamps, links (aibrain, social), 2-3 line summary\n"
        plan += "- **Tags:** 10-15 tags, 500 char limit total\n"
        plan += "- **End screen:** last 20 sec — 'subscribe' + 'next video'\n"
        plan += "- **Upload day:** Thursday or Saturday, 2pm ACST\n\n"

        plan += "## This Week's Long-Form Video\n"
        plan += f"**Topic:** [Related to: {theme}]\n"
        plan += "**Structure (10-12 min):**\n"
        plan += "```\n"
        plan += "0:00 — Hook (15 sec — the most surprising result/claim)\n"
        plan += "0:15 — Intro (30 sec — what we're covering and why it matters)\n"
        plan += "0:45 — Context (2 min — the problem space)\n"
        plan += "2:45 — The Approach (3 min — what I built and how)\n"
        plan += "5:45 — Demo (3 min — live screen recording showing it working)\n"
        plan += "8:45 — Results (1.5 min — benchmarks, numbers, honest assessment)\n"
        plan += "10:15 — What's Next (30 sec — tease upcoming content)\n"
        plan += "10:45 — CTA (15 sec — subscribe, link in description)\n"
        plan += "11:00 — End screen (20 sec)\n"
        plan += "```\n\n"

        plan += "**Title options:**\n"
        plan += "- 'I Built an AI That Gets Smarter Every Day (Here's How)'\n"
        plan += "- 'This 22MB File Beats Models 70x Larger — SelRoute Explained'\n"
        plan += "- 'I Found 38,190 Vulnerabilities With an AI Scanner'\n"
        plan += "- 'pip install aibrain — Give Your AI Agent a Real Brain'\n\n"

        plan += "**Thumbnail spec:** 1280x720px\n"
        plan += "- Background: dark with terminal/code aesthetic\n"
        plan += "- Big text: 3-5 words max, white or accent (#00f5d4)\n"
        plan += "- Optional: your face with surprised/focused expression\n"
        plan += "- Contrast: bright elements on dark background\n\n"

        plan += "## Shorts (2-3 per week)\n"
        for day, concept in [("Tue", "60-sec pip install speedrun"),
                             ("Thu", "One surprising finding from BT results"),
                             ("Sat", "Quick tip or 'did you know' about AI memory")]:
            plan += f"### {day} Short\n"
            plan += f"**Concept:** {concept}\n"
            plan += f"**Format:** 1080x1920, 30-60sec, captions ON (85% watch muted)\n"
            plan += f"**Hook:** first frame must have text overlay stating the payoff\n\n"

        plan += "## Tags Template\n"
        plan += "aibrain, AI agent memory, persistent memory AI, SelRoute, AI security scanner, "
        plan += "security scanner, automated pentesting, Claude Code, MCP server, AI tools 2026, "
        plan += "solo founder, build in public, Python AI, cybersecurity automation\n"

        self.store(f"youtube_plan_{week_start.strftime('%Y_W%W')}",
                   plan, "project", "youtube,content,plan,weekly,auto", 0.7)
        return {"status": "ok"}


# =========================================================================
# ORCHESTRATION (2)
# =========================================================================

class WeeklyContentBatchScheduler(ContentWorkflow):
    """Generate the full week's content plan across all 8 platforms."""
    name = "content_batch_scheduler"
    display_name = "Weekly Content Batch Scheduler"
    description = "Master scheduler — generates all platform content plans for the week in one run"
    category = "content"
    schedule_cron = "0 5 * * 1"  # Monday 5am — before all platform generators

    def run(self) -> Dict:
        theme = self._get_week_theme()
        week_start = datetime.now() - timedelta(days=datetime.now().weekday())
        pillars = self._get_content_pillars()

        master = f"# Content Master Plan — Week of {week_start.strftime('%Y-%m-%d')}\n\n"
        master += f"**Theme:** {theme}\n"
        master += f"**All pillars:** {', '.join(pillars)}\n\n"

        master += "## Weekly Asset Requirements\n\n"
        master += "### Images Needed\n"
        master += "| Asset | Dimensions | Platform | Count |\n"
        master += "|-------|-----------|----------|-------|\n"
        master += "| LinkedIn landscape | 1200x627px | LinkedIn | 3 |\n"
        master += "| LinkedIn carousel | 1080x1350px | LinkedIn | 2 (x5 slides each) |\n"
        master += "| X/Twitter card | 1600x900px | X | 5 |\n"
        master += "| Instagram portrait | 1080x1350px | Instagram | 2 |\n"
        master += "| Instagram carousel | 1080x1350px | Instagram | 1 (x7 slides) |\n"
        master += "| Facebook landscape | 1200x630px | Facebook | 3 |\n"
        master += "| YouTube thumbnail | 1280x720px | YouTube | 1 long + 3 shorts |\n"
        master += "| Medium feature | 1400x788px | Medium | 1 |\n\n"

        master += "### Videos Needed\n"
        master += "| Asset | Dimensions | Duration | Platform |\n"
        master += "|-------|-----------|----------|----------|\n"
        master += "| Long-form | 1920x1080 | 8-15 min | YouTube |\n"
        master += "| YT Shorts | 1080x1920 | 30-60 sec | YouTube |\n"
        master += "| Reels | 1080x1920 | 30-60 sec | Instagram |\n"
        master += "| TikToks | 1080x1920 | 60-90 sec | TikTok |\n\n"

        master += "### Written Content Needed\n"
        master += "| Content | Word Count | Platform |\n"
        master += "|---------|-----------|----------|\n"
        master += "| Medium article | 1,500-2,500 | Medium |\n"
        master += "| LinkedIn posts | 700-1,300 chars x5 | LinkedIn |\n"
        master += "| X thread | 280 chars x 7-10 tweets | X |\n"
        master += "| Reddit posts | 500-2,000 words x2 | Reddit |\n"
        master += "| FB posts | 40-80 words x3 | Facebook |\n"
        master += "| Video scripts | 200-300 words each | YouTube, TikTok |\n\n"

        master += "## Daily Publishing Schedule\n"
        schedule = {
            "Mon": ["LinkedIn (7:30am)", "X tweet (8am)", "TikTok (7am)"],
            "Tue": ["Reddit r/netsec (10am)", "X tweet (12pm)", "YT Short (2pm)", "IG carousel (7pm)"],
            "Wed": ["LinkedIn (12pm)", "X tweet (8am)", "TikTok demo (12pm)", "FB post (2pm)"],
            "Thu": ["Reddit r/LocalLLaMA (10am)", "Medium article (10am)", "X thread (8am)",
                    "YouTube long-form (2pm)", "YT Short (4pm)"],
            "Fri": ["LinkedIn (5:30pm)", "X tweet (12pm)", "IG reel (7pm)", "Reddit r/selfhosted (10am)"],
            "Sat": ["X engagement (10am)", "Reddit r/artificial (10am)", "YT Short (2pm)",
                    "FB discussion (2pm)", "TikTok trend (8pm)"],
            "Sun": ["IG story/poll (11am)", "X teaser (8pm)"],
        }

        for day, posts in schedule.items():
            master += f"\n**{day}:**\n"
            for post in posts:
                master += f"  - [ ] {post}\n"

        master += "\n## Content Repurposing Flow\n"
        master += "1. **Thursday YouTube video** → extract 3 Shorts from best moments\n"
        master += "2. **Thursday Medium article** → adapt key points for LinkedIn + X thread\n"
        master += "3. **YouTube thumbnail** → resize for IG post (1080x1350)\n"
        master += "4. **TikTok demos** → cross-post as IG Reels and YT Shorts\n"
        master += "5. **Reddit technical post** → adapt lighter version for Facebook group\n"

        self.store(f"content_master_{week_start.strftime('%Y_W%W')}",
                   master, "project", "content,master,schedule,weekly,auto", 0.8)
        return {"status": "ok", "platforms": 8}


class ContentPerformanceAnalyzer(ContentWorkflow):
    """Track which content performs best across platforms."""
    name = "content_performance"
    display_name = "Content Performance Analyzer"
    description = "Track engagement, reach, and conversion across all platforms — double down on what works"
    category = "content"
    schedule_cron = "0 9 * * 1"

    def run(self) -> Dict:
        # Search for performance data stored in brain
        performance = self.search("engagement", limit=20)
        performance += self.search("views", limit=10)
        performance += self.search("likes", limit=10)

        platforms = ["linkedin", "x", "reddit", "medium", "tiktok", "instagram", "facebook", "youtube"]

        report = f"# Content Performance — {datetime.now().strftime('%Y-%m-%d')}\n\n"

        for platform in platforms:
            platform_data = [p for p in performance if platform in p.get("tags", "").lower()]
            if platform_data:
                report += f"## {platform.title()}\n"
                for d in platform_data[:3]:
                    report += f"- {d['content'][:80]}\n"
                report += "\n"

        report += "## Tracking Checklist\n"
        report += "Store performance data with platform tag + 'engagement':\n"
        report += "- LinkedIn: impressions, reactions, comments, reposts\n"
        report += "- X: impressions, likes, retweets, replies, profile visits\n"
        report += "- Reddit: upvotes, comments, cross-posts\n"
        report += "- Medium: reads, claps, responses, read ratio\n"
        report += "- TikTok: views, likes, shares, comments, watch time %\n"
        report += "- Instagram: reach, likes, saves, shares, profile visits\n"
        report += "- Facebook: reach, reactions, comments, shares\n"
        report += "- YouTube: views, watch time, CTR, subs gained, likes\n"

        self.store(f"content_perf_{datetime.now().strftime('%Y%m%d')}",
                   report, "reference", "content,performance,analytics,auto", 0.6)
        return {"status": "ok"}


# =========================================================================
# REGISTRY
# =========================================================================

CONTENT_WORKFLOW_REGISTRY: Dict[str, type] = {
    # Platform generators
    "linkedin_content": LinkedInGenerator,
    "x_twitter_content": XTwitterGenerator,
    "reddit_content": RedditGenerator,
    "medium_content": MediumGenerator,
    "tiktok_content": TikTokGenerator,
    "instagram_content": InstagramGenerator,
    "facebook_content": FacebookGenerator,
    "youtube_content": YouTubeGenerator,
    # Orchestration
    "content_batch_scheduler": WeeklyContentBatchScheduler,
    "content_performance": ContentPerformanceAnalyzer,
}


def seed_content_workflows(db_path: str) -> int:
    conn = sqlite3.connect(db_path, check_same_thread=False)
    count = 0
    for name, cls in CONTENT_WORKFLOW_REGISTRY.items():
        try:
            conn.execute("""
                INSERT OR REPLACE INTO workflows
                (name, display_name, category, description, cron_schedule, enabled, source)
                VALUES (?, ?, ?, ?, ?, 0, 'content_pro')
            """, (cls.name, cls.display_name, cls.category, cls.description, cls.schedule_cron))
            count += 1
        except Exception as e:
            log.error("Failed to seed %s: %s", name, e)
    conn.commit()
    conn.close()
    return count
