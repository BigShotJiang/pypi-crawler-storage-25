#!/usr/bin/env python3
"""
brain_mesh.py — Multi-Agent Brain Mesh Infrastructure

Transforms aibrain from single-agent memory into distributed intelligence.
Enables N agents to learn independently, then merge brains with
consensus-weighted principles and conflict resolution.

The hive mind architecture:
- Each agent runs independently on its own hardware (VPS, Docker, local)
- Each maintains its own aibrain.db with memories, skills, principles
- Periodically, brains sync through the mesh: export → merge → reimport
- Principles validated by multiple agents get confidence boosts
- Contradictory principles are resolved by consensus or recency
- The merged brain is smarter than any individual agent

Usage:
    from brain_mesh import BrainMesh
    mesh = BrainMesh(local_db_path)
    mesh.register_agent("agent_a", "/opt/aibrain/aibrain.db")
    mesh.register_agent("agent_b", "~/aibrain/aibrain.db")
    result = mesh.merge_all(strategy="consensus")
    mesh.distribute()  # push merged brain back to all agents
"""

import hashlib
import json
import logging
import os
import sqlite3
import shutil
from abc import ABC, abstractmethod
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Set

log = logging.getLogger("aibrain.mesh")


# ---------------------------------------------------------------------------
# Google/MIT Scaling Laws (Kim et al. 2025, arXiv:2512.08296)
# Multi-agent error amplification factors relative to single-agent baseline.
# ---------------------------------------------------------------------------

INDEPENDENT_ERROR_AMPLIFICATION = 17.2  # bag-of-agents (no coordinator)
CENTRALIZED_ERROR_AMPLIFICATION = 4.4   # with orchestrator
MULTI_AGENT_THRESHOLD = 0.45  # above this single-agent accuracy, multi-agent hurts

# Task types where multi-agent topology degrades performance (-39% to -70%)
SEQUENTIAL_REASONING_TASKS = frozenset({
    "math", "logic", "reasoning", "proof", "step_by_step",
    "sequential", "chain_of_thought", "planning",
})


def validate_mesh_topology(mesh_config: Dict) -> List[str]:
    """Validate mesh topology against Google/MIT scaling laws.

    Checks:
    1. Mesh uses centralized orchestrator (not bag-of-agents).
    2. Sequential reasoning tasks are not assigned to multi-agent topology.
    3. Agent count warnings based on error amplification research.

    Args:
        mesh_config: dict with optional keys:
            - topology: "centralized" | "independent" | "swarm" (default: "centralized")
            - task_types: list of task type strings being assigned
            - agent_count: number of agents in the mesh
            - single_agent_accuracy: estimated baseline accuracy (0-1)

    Returns:
        List of warning strings. Empty list = topology is valid.

    Raises:
        ValueError: if topology is "independent" (bag-of-agents), which has
            17.2x error amplification and should never be used.
    """
    warnings = []
    topology = mesh_config.get("topology", "centralized")
    task_types = mesh_config.get("task_types", [])
    agent_count = mesh_config.get("agent_count", 1)
    baseline_acc = mesh_config.get("single_agent_accuracy")

    # 1. Reject bag-of-agents topology outright
    if topology == "independent":
        raise ValueError(
            f"Independent (bag-of-agents) topology has {INDEPENDENT_ERROR_AMPLIFICATION}x "
            f"error amplification (Kim et al. 2025). Use 'centralized' topology with an "
            f"orchestrator agent ({CENTRALIZED_ERROR_AMPLIFICATION}x) instead."
        )

    # 2. Warn about sequential reasoning tasks in multi-agent setup
    if agent_count > 1:
        sequential_overlap = SEQUENTIAL_REASONING_TASKS.intersection(
            t.lower() for t in task_types
        )
        if sequential_overlap:
            warnings.append(
                f"Sequential reasoning tasks {sorted(sequential_overlap)} assigned to "
                f"multi-agent topology. Research shows -39% to -70% performance "
                f"degradation on sequential reasoning with multiple agents. "
                f"Consider single-agent execution for these tasks."
            )

    # 3. Warn if baseline accuracy exceeds threshold
    if baseline_acc is not None and baseline_acc > MULTI_AGENT_THRESHOLD and agent_count > 1:
        warnings.append(
            f"Single-agent baseline accuracy ({baseline_acc:.0%}) exceeds "
            f"{MULTI_AGENT_THRESHOLD:.0%} threshold. Above this level, "
            f"multi-agent yields diminishing or negative returns."
        )

    # 4. Log error amplification for awareness
    if agent_count > 1 and topology == "centralized":
        warnings.append(
            f"Centralized topology: expect ~{CENTRALIZED_ERROR_AMPLIFICATION}x error "
            f"amplification with {agent_count} agents. Ensure orchestrator quality is high."
        )

    for w in warnings:
        log.warning("Mesh topology: %s", w)

    return warnings


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class AgentNode:
    """Represents one agent in the mesh."""
    name: str
    db_path: str
    trust_score: float = 1.0     # 0-1, how reliable is this agent's intelligence
    specializations: List[str] = field(default_factory=list)  # what this agent is good at
    last_sync: str = ""
    memory_count: int = 0
    principle_count: int = 0
    episode_count: int = 0


@dataclass
class MergeConflict:
    """A conflict found during brain merge."""
    type: str             # "principle_contradiction", "memory_duplicate", "fact_conflict"
    source_agents: List[str]
    content_a: str
    content_b: str
    resolution: str = ""  # how it was resolved
    resolved_by: str = "" # "consensus", "trust_weight", "recency", "manual"


@dataclass
class MergeResult:
    """Results of a brain merge operation."""
    agents_merged: int
    memories_added: int
    memories_deduplicated: int
    principles_merged: int
    principles_boosted: int    # existing principles confirmed by another agent
    principles_conflicted: int
    conflicts: List[MergeConflict] = field(default_factory=list)
    consensus_principles: int = 0  # principles validated by 2+ agents
    duration_seconds: float = 0


# ---------------------------------------------------------------------------
# Merge Strategies
# ---------------------------------------------------------------------------

class MergeStrategy(ABC):
    """Abstract base class for merge strategies.

    Subclasses must implement both methods:
    - resolve_principle_conflict: decide which principle wins when two agents disagree
    - calculate_merged_confidence: compute a single confidence from multiple agents
    """

    @abstractmethod
    def resolve_principle_conflict(self, principle_a: Dict, principle_b: Dict,
                                     agent_a: AgentNode, agent_b: AgentNode) -> Dict:
        """Resolve conflicting principles from two agents.

        Args:
            principle_a: principle dict from agent_a (keys: task_type, principle, confidence)
            principle_b: principle dict from agent_b (same keys)
            agent_a: the AgentNode that produced principle_a
            agent_b: the AgentNode that produced principle_b

        Returns:
            The winning principle dict, optionally annotated with _resolution or _source.
        """

    @abstractmethod
    def calculate_merged_confidence(self, confidences: List[float],
                                      agent_trusts: List[float]) -> float:
        """Calculate merged confidence from multiple agents.

        Args:
            confidences: list of confidence values (0-1) from each agent
            agent_trusts: list of trust scores (0-1) for each agent, parallel to confidences

        Returns:
            A single merged confidence value (0-1).
        """


class ConsensusStrategy(MergeStrategy):
    """Consensus merge: principles validated by multiple agents get boosted.

    - Same principle from 2 agents: confidence = max(a, b) + 0.1
    - Same principle from 3+ agents: confidence = max(all) + 0.15
    - Contradictory principles: higher confidence wins, loser gets flagged
    - Trust-weighted: high-trust agent's principles weighted 2x
    """

    def resolve_principle_conflict(self, principle_a, principle_b, agent_a, agent_b):
        # Weight by trust score
        score_a = principle_a.get("confidence", 0.5) * agent_a.trust_score
        score_b = principle_b.get("confidence", 0.5) * agent_b.trust_score

        if score_a >= score_b:
            winner = {**principle_a}
            winner["_resolution"] = f"consensus: {agent_a.name} ({score_a:.2f}) > {agent_b.name} ({score_b:.2f})"
        else:
            winner = {**principle_b}
            winner["_resolution"] = f"consensus: {agent_b.name} ({score_b:.2f}) > {agent_a.name} ({score_a:.2f})"

        return winner

    def calculate_merged_confidence(self, confidences, agent_trusts):
        if not confidences:
            return 0.5

        # Weighted average + consensus bonus
        weighted = sum(c * t for c, t in zip(confidences, agent_trusts)) / max(sum(agent_trusts), 0.01)
        consensus_bonus = min(len(confidences) * 0.05, 0.15)  # max +0.15 for 3+ agents
        return min(weighted + consensus_bonus, 0.99)


class UnionStrategy(MergeStrategy):
    """Union merge: keep everything from all agents. No conflict resolution.
    Useful for combining brains from agents with non-overlapping specializations.
    """

    def resolve_principle_conflict(self, principle_a, principle_b, agent_a, agent_b):
        # Keep both — tag with source
        principle_a["_source"] = agent_a.name
        principle_b["_source"] = agent_b.name
        return principle_a  # caller should also add principle_b

    def calculate_merged_confidence(self, confidences, agent_trusts):
        return max(confidences) if confidences else 0.5


class DomainStrategy(MergeStrategy):
    """Domain-specific merge: each agent is authoritative for its specialization.
    Agent A is the security expert → its security principles always win.
    Agent B is the code review expert → its code review principles always win.
    """

    def __init__(self, domain_authorities: Dict[str, str]):
        """domain_authorities: {domain: agent_name}"""
        self.authorities = domain_authorities

    def resolve_principle_conflict(self, principle_a, principle_b, agent_a, agent_b):
        task_type = principle_a.get("task_type", "")

        # Check if either agent is the domain authority
        authority = self.authorities.get(task_type)
        if authority == agent_a.name:
            return principle_a
        elif authority == agent_b.name:
            return principle_b

        # No authority defined — fall back to confidence
        if principle_a.get("confidence", 0) >= principle_b.get("confidence", 0):
            return principle_a
        return principle_b

    def calculate_merged_confidence(self, confidences, agent_trusts):
        return max(confidences) if confidences else 0.5


STRATEGIES = {
    "consensus": ConsensusStrategy,
    "union": UnionStrategy,
    "domain": DomainStrategy,
}


# ---------------------------------------------------------------------------
# Brain Mesh
# ---------------------------------------------------------------------------

class BrainMesh:
    """Multi-agent brain mesh coordinator."""

    def __init__(self, local_db_path: str):
        self.local_db = local_db_path
        self.agents: Dict[str, AgentNode] = {}
        self._mesh_dir = Path(local_db_path).parent / ".brain_mesh"
        self._mesh_dir.mkdir(parents=True, exist_ok=True)

        # Load agent registry
        self._load_registry()

    def _load_registry(self):
        """Load registered agents from mesh config."""
        registry_path = self._mesh_dir / "agents.json"
        if registry_path.exists():
            try:
                data = json.loads(registry_path.read_text())
                for name, info in data.items():
                    self.agents[name] = AgentNode(name=name, **info)
            except (json.JSONDecodeError, TypeError):
                pass

    def _save_registry(self):
        """Persist agent registry."""
        registry_path = self._mesh_dir / "agents.json"
        data = {}
        for name, agent in self.agents.items():
            data[name] = {
                "db_path": agent.db_path,
                "trust_score": agent.trust_score,
                "specializations": agent.specializations,
                "last_sync": agent.last_sync,
                "memory_count": agent.memory_count,
                "principle_count": agent.principle_count,
                "episode_count": agent.episode_count,
            }
        registry_path.write_text(json.dumps(data, indent=2))

    # ------------------------------------------------------------------
    # Agent Management
    # ------------------------------------------------------------------

    def register_agent(self, name: str, db_path: str,
                       trust_score: float = 1.0,
                       specializations: List[str] = None) -> AgentNode:
        """Register an agent in the mesh."""
        try:
            from aibrain_licensing import check_agent_limit
            if not check_agent_limit(len(self.agents)):
                from aibrain_licensing import get_license, upgrade_message
                lic = get_license()
                raise PermissionError(
                    f"Agent limit reached ({lic.limits['max_agents']} on {lic.tier} tier). "
                    + upgrade_message("team" if lic.tier in ("free", "pro") else "enterprise")
                )
        except ImportError:
            pass

        agent = AgentNode(
            name=name,
            db_path=db_path,
            trust_score=trust_score,
            specializations=specializations or [],
        )

        # Get stats from agent's DB if accessible
        if Path(db_path).exists():
            try:
                conn = sqlite3.connect(db_path)
                row = conn.execute("SELECT COUNT(*) FROM memories WHERE active=1").fetchone()
                agent.memory_count = row[0] if row else 0
                row = conn.execute("SELECT COUNT(*) FROM skill_principles WHERE status='active'").fetchone()
                agent.principle_count = row[0] if row else 0
                row = conn.execute("SELECT COUNT(*) FROM skill_episodes").fetchone()
                agent.episode_count = row[0] if row else 0
                conn.close()
            except Exception:
                pass

        self.agents[name] = agent
        self._save_registry()
        log.info("Registered agent: %s (%s) trust=%.2f", name, db_path, trust_score)
        return agent

    def remove_agent(self, name: str):
        """Remove an agent from the mesh."""
        if name in self.agents:
            del self.agents[name]
            self._save_registry()

    def list_agents(self) -> List[AgentNode]:
        """List all registered agents."""
        return list(self.agents.values())

    def update_trust(self, name: str, trust_score: float):
        """Update an agent's trust score."""
        if name in self.agents:
            self.agents[name].trust_score = max(0.0, min(1.0, trust_score))
            self._save_registry()

    # ------------------------------------------------------------------
    # Brain Export (privacy-preserving)
    # ------------------------------------------------------------------

    def export_brain(self, agent_name: str, include_memories: bool = True,
                     include_principles: bool = True,
                     include_episodes: bool = True,
                     domains: List[str] = None) -> Dict:
        """Export a brain for merge. Optionally filter by domain."""
        agent = self.agents.get(agent_name)
        if not agent:
            return {"error": f"Agent {agent_name} not registered"}

        db_path = agent.db_path
        if not Path(db_path).exists():
            return {"error": f"DB not found: {db_path}"}

        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        export = {
            "agent": agent_name,
            "exported_at": datetime.now().isoformat(),
            "trust_score": agent.trust_score,
            "memories": [],
            "principles": [],
            "episodes": [],
        }

        if include_memories:
            query = "SELECT name, type, tags, content, importance FROM memories WHERE active=1"
            params = []
            if domains:
                domain_clauses = " OR ".join(["tags LIKE ?" for _ in domains])
                query += f" AND ({domain_clauses})"
                params = [f"%{d}%" for d in domains]
            rows = conn.execute(query, params).fetchall()
            export["memories"] = [dict(r) for r in rows]

        if include_principles:
            query = "SELECT task_type, principle, confidence FROM skill_principles WHERE status='active'"
            params = []
            if domains:
                domain_clauses = " OR ".join(["task_type LIKE ?" for _ in domains])
                query += f" AND ({domain_clauses})"
                params = [f"%{d}%" for d in domains]
            rows = conn.execute(query, params).fetchall()
            export["principles"] = [dict(r) for r in rows]

        if include_episodes:
            query = "SELECT task_type, task_description, approach_taken, outcome_quality, tools_used, duration_seconds FROM skill_episodes"
            params = []
            if domains:
                domain_clauses = " OR ".join(["task_type LIKE ?" for _ in domains])
                query += f" WHERE ({domain_clauses})"
                params = [f"%{d}%" for d in domains]
            query += " ORDER BY created_at DESC LIMIT 500"
            rows = conn.execute(query, params).fetchall()
            export["episodes"] = [dict(r) for r in rows]

        conn.close()
        return export

    def export_principles_only(self, agent_name: str) -> Dict:
        """Privacy-preserving export: principles only, no raw memories.
        This is how you share intelligence without sharing data."""
        return self.export_brain(agent_name, include_memories=False,
                                 include_episodes=False)

    # ------------------------------------------------------------------
    # Brain Merge
    # ------------------------------------------------------------------

    def merge_all(self, strategy: str = "consensus",
                  target_db: str = None,
                  domains: List[str] = None,
                  dry_run: bool = False) -> MergeResult:
        """Merge all registered agents' brains into a single brain.
        Requires Team tier or above.

        Args:
            strategy: "consensus", "union", or "domain"
            target_db: path for merged brain (default: local_db)
            domains: optional domain filter (e.g., ["security", "code_review"])
            dry_run: if True, report what would happen without changing anything
        """
        import time
        start = time.time()

        target = target_db or self.local_db
        result = MergeResult(agents_merged=0, memories_added=0,
                            memories_deduplicated=0, principles_merged=0,
                            principles_boosted=0, principles_conflicted=0)

        # Validate topology against scaling laws before proceeding
        mesh_config = {
            "topology": "centralized",  # BrainMesh always uses orchestrator pattern
            "task_types": domains or [],
            "agent_count": len(self.agents),
        }
        topology_warnings = validate_mesh_topology(mesh_config)
        if topology_warnings:
            log.info("Topology validation: %d warning(s) — proceeding with centralized orchestrator",
                     len(topology_warnings))

        if strategy == "domain":
            # Build authority map from specializations
            authorities = {}
            for agent in self.agents.values():
                for spec in agent.specializations:
                    authorities[spec] = agent.name
            merger = DomainStrategy(authorities)
        else:
            merger = STRATEGIES.get(strategy, ConsensusStrategy)()

        # Export all agents' brains
        exports = {}
        for name, agent in self.agents.items():
            export = self.export_brain(name, domains=domains)
            if "error" not in export:
                exports[name] = export
                result.agents_merged += 1

        if result.agents_merged < 2:
            log.warning("Need at least 2 agents for merge, got %d", result.agents_merged)
            result.duration_seconds = time.time() - start
            return result

        if dry_run:
            # Analyze without writing
            result = self._analyze_merge(exports, merger, result)
            result.duration_seconds = time.time() - start
            return result

        # Open target database
        conn = sqlite3.connect(target)
        conn.row_factory = sqlite3.Row

        # 1. Merge memories (deduplicate by content hash)
        seen_hashes: Set[str] = set()

        # First, hash existing memories in target
        try:
            existing = conn.execute("SELECT content FROM memories WHERE active=1").fetchall()
            for row in existing:
                h = hashlib.sha256(row["content"].encode()).hexdigest()[:16]
                seen_hashes.add(h)
        except Exception:
            pass

        for agent_name, export in exports.items():
            for memory in export.get("memories", []):
                content_hash = hashlib.sha256(memory["content"].encode()).hexdigest()[:16]
                if content_hash in seen_hashes:
                    result.memories_deduplicated += 1
                    continue

                seen_hashes.add(content_hash)
                try:
                    conn.execute(
                        "INSERT INTO memories (name, type, tags, content, importance, "
                        "created, updated, active) VALUES (?, ?, ?, ?, ?, datetime('now'), "
                        "datetime('now'), 1)",
                        (memory["name"], memory.get("type", "reference"),
                         memory.get("tags", "") + f",merged_from:{agent_name}",
                         memory["content"], memory.get("importance", 0.5))
                    )
                    result.memories_added += 1
                except Exception:
                    pass

        # 2. Merge principles (consensus scoring)
        all_principles = defaultdict(list)  # key: (task_type, principle_text_hash) → [(agent, data)]

        for agent_name, export in exports.items():
            agent = self.agents[agent_name]
            for p in export.get("principles", []):
                # Hash principle for matching (fuzzy: lowercase, strip whitespace)
                p_hash = hashlib.sha256(
                    p["principle"].lower().strip().encode()
                ).hexdigest()[:16]
                key = (p.get("task_type", ""), p_hash)
                all_principles[key].append((agent, p))

        for (task_type, p_hash), agent_principles in all_principles.items():
            if len(agent_principles) == 1:
                # Only one agent has this principle — import as-is
                agent, p = agent_principles[0]
                try:
                    conn.execute(
                        "INSERT INTO skill_principles (task_type, principle, confidence, "
                        "status, created_at) VALUES (?, ?, ?, 'active', datetime('now'))",
                        (task_type, p["principle"], p.get("confidence", 0.5))
                    )
                    result.principles_merged += 1
                except Exception:
                    pass

            elif len(agent_principles) >= 2:
                # Multiple agents have this principle — consensus boost!
                confidences = [p["confidence"] for _, p in agent_principles]
                trusts = [a.trust_score for a, _ in agent_principles]
                merged_confidence = merger.calculate_merged_confidence(confidences, trusts)

                # Use the principle text from the highest-trust agent
                best_agent, best_principle = max(agent_principles,
                                                  key=lambda x: x[0].trust_score)

                try:
                    conn.execute(
                        "INSERT INTO skill_principles (task_type, principle, confidence, "
                        "status, created_at) VALUES (?, ?, ?, 'active', datetime('now'))",
                        (task_type, best_principle["principle"], merged_confidence)
                    )
                    result.principles_boosted += 1
                    result.consensus_principles += 1
                except Exception:
                    pass

                sources = [a.name for a, _ in agent_principles]
                log.info("Consensus principle (%s): '%s' validated by %s → confidence %.2f",
                         task_type, best_principle["principle"][:50],
                         ", ".join(sources), merged_confidence)

        # 3. Merge episodes (keep all, tag with source agent)
        for agent_name, export in exports.items():
            for ep in export.get("episodes", []):
                try:
                    tools = ep.get("tools_used", "[]")
                    if isinstance(tools, list):
                        tools = json.dumps(tools)
                    conn.execute(
                        "INSERT INTO skill_episodes (task_type, task_description, "
                        "approach_taken, outcome_quality, tools_used, duration_seconds, "
                        "created_at) VALUES (?, ?, ?, ?, ?, ?, datetime('now'))",
                        (ep.get("task_type", ""),
                         f"[merged:{agent_name}] {ep.get('task_description', '')}",
                         ep.get("approach_taken", ""), ep.get("outcome_quality", 0),
                         tools, ep.get("duration_seconds", 0))
                    )
                except Exception:
                    pass

        conn.commit()
        conn.close()

        # Update sync timestamps
        for name in exports:
            self.agents[name].last_sync = datetime.now().isoformat()
        self._save_registry()

        result.duration_seconds = time.time() - start
        log.info("Merge complete: %d agents, %d memories (+%d deduped), "
                 "%d principles (%d consensus-boosted), %.1fs",
                 result.agents_merged, result.memories_added,
                 result.memories_deduplicated, result.principles_merged,
                 result.consensus_principles, result.duration_seconds)

        return result

    def _analyze_merge(self, exports, merger, result) -> MergeResult:
        """Analyze what a merge would do without writing."""
        seen_hashes = set()
        all_principles = defaultdict(list)

        for agent_name, export in exports.items():
            for memory in export.get("memories", []):
                h = hashlib.sha256(memory["content"].encode()).hexdigest()[:16]
                if h in seen_hashes:
                    result.memories_deduplicated += 1
                else:
                    seen_hashes.add(h)
                    result.memories_added += 1

            agent = self.agents[agent_name]
            for p in export.get("principles", []):
                p_hash = hashlib.sha256(p["principle"].lower().strip().encode()).hexdigest()[:16]
                key = (p.get("task_type", ""), p_hash)
                all_principles[key].append((agent, p))

        for key, agent_principles in all_principles.items():
            if len(agent_principles) >= 2:
                result.consensus_principles += 1
                result.principles_boosted += 1
            result.principles_merged += 1

        return result

    # ------------------------------------------------------------------
    # Selective Merge
    # ------------------------------------------------------------------

    def merge_domains(self, domains: List[str], strategy: str = "consensus",
                      target_db: str = None) -> MergeResult:
        """Merge only specific domains across all agents.
        e.g., merge_domains(["security", "scan"]) merges only security intelligence.
        """
        return self.merge_all(strategy=strategy, target_db=target_db, domains=domains)

    def merge_pair(self, agent_a: str, agent_b: str,
                   strategy: str = "consensus",
                   target_db: str = None) -> MergeResult:
        """Merge two specific agents' brains."""
        # Temporarily filter to just these two agents
        original = self.agents.copy()
        self.agents = {k: v for k, v in self.agents.items() if k in (agent_a, agent_b)}
        result = self.merge_all(strategy=strategy, target_db=target_db)
        self.agents = original
        return result

    # ------------------------------------------------------------------
    # Distribution (push merged brain back to agents)
    # ------------------------------------------------------------------

    def distribute(self, source_db: str = None, agents: List[str] = None,
                   principles_only: bool = False) -> Dict:
        """Push merged brain (or just principles) back to all agents."""
        source = source_db or self.local_db
        target_agents = agents or list(self.agents.keys())
        results = {}

        conn = sqlite3.connect(source)
        conn.row_factory = sqlite3.Row

        # Export from source
        principles = []
        memories = []

        try:
            rows = conn.execute(
                "SELECT task_type, principle, confidence FROM skill_principles "
                "WHERE status='active'"
            ).fetchall()
            principles = [dict(r) for r in rows]
        except Exception:
            pass

        if not principles_only:
            try:
                rows = conn.execute(
                    "SELECT name, type, tags, content, importance FROM memories WHERE active=1"
                ).fetchall()
                memories = [dict(r) for r in rows]
            except Exception:
                pass

        conn.close()

        # Push to each agent
        for agent_name in target_agents:
            agent = self.agents.get(agent_name)
            if not agent or not Path(agent.db_path).exists():
                results[agent_name] = {"status": "error", "message": "DB not found"}
                continue

            try:
                agent_conn = sqlite3.connect(agent.db_path)
                added_principles = 0
                added_memories = 0

                # Merge principles
                for p in principles:
                    existing = agent_conn.execute(
                        "SELECT id, confidence FROM skill_principles "
                        "WHERE task_type=? AND principle=? AND status='active'",
                        (p["task_type"], p["principle"])
                    ).fetchone()

                    if existing:
                        # Update confidence if merged is higher
                        if p["confidence"] > existing[1]:
                            agent_conn.execute(
                                "UPDATE skill_principles SET confidence=? WHERE id=?",
                                (p["confidence"], existing[0])
                            )
                            added_principles += 1
                    else:
                        agent_conn.execute(
                            "INSERT INTO skill_principles (task_type, principle, confidence, "
                            "status, created_at) VALUES (?, ?, ?, 'active', datetime('now'))",
                            (p["task_type"], p["principle"], p["confidence"])
                        )
                        added_principles += 1

                # Merge memories (if not principles_only)
                if not principles_only:
                    for m in memories:
                        existing = agent_conn.execute(
                            "SELECT id FROM memories WHERE name=? AND active=1",
                            (m["name"],)
                        ).fetchone()
                        if not existing:
                            agent_conn.execute(
                                "INSERT INTO memories (name, type, tags, content, importance, "
                                "created, updated, active) VALUES "
                                "(?, ?, ?, ?, ?, datetime('now'), datetime('now'), 1)",
                                (m["name"], m.get("type", "reference"),
                                 m.get("tags", ""), m["content"],
                                 m.get("importance", 0.5))
                            )
                            added_memories += 1

                agent_conn.commit()
                agent_conn.close()

                results[agent_name] = {
                    "status": "ok",
                    "principles_updated": added_principles,
                    "memories_added": added_memories,
                }

            except Exception as e:
                results[agent_name] = {"status": "error", "message": str(e)}

        return results

    # ------------------------------------------------------------------
    # Swarm Training
    # ------------------------------------------------------------------

    def create_training_swarm(self, task_type: str, num_agents: int,
                               base_db: str = None) -> List[str]:
        """Create N agent instances for parallel brain training.

        Each agent gets a copy of the base brain and runs independently.
        After training, merge all back with consensus scoring.
        """
        base = base_db or self.local_db

        # Validate topology — swarm uses centralized orchestrator (harvest merges back)
        mesh_config = {
            "topology": "centralized",
            "task_types": [task_type],
            "agent_count": num_agents,
        }
        topology_warnings = validate_mesh_topology(mesh_config)
        if topology_warnings:
            log.info("Swarm topology validation for '%s': %d warning(s)",
                     task_type, len(topology_warnings))

        swarm_dir = self._mesh_dir / f"swarm_{task_type}_{datetime.now().strftime('%Y%m%d_%H%M')}"
        swarm_dir.mkdir(parents=True, exist_ok=True)

        agent_paths = []
        for i in range(num_agents):
            agent_name = f"swarm_{task_type}_{i:03d}"
            agent_db = swarm_dir / f"{agent_name}.db"

            # Copy base brain
            shutil.copy2(base, agent_db)

            # Register in mesh
            self.register_agent(agent_name, str(agent_db),
                               trust_score=0.8,  # swarm agents start at 0.8 trust
                               specializations=[task_type])

            agent_paths.append(str(agent_db))
            log.info("Created swarm agent: %s at %s", agent_name, agent_db)

        self._save_registry()
        return agent_paths

    def harvest_swarm(self, task_type: str, strategy: str = "consensus",
                       target_db: str = None) -> MergeResult:
        """Merge all swarm agents for a task type back into one brain."""
        swarm_agents = {name: agent for name, agent in self.agents.items()
                       if name.startswith(f"swarm_{task_type}_")}

        if not swarm_agents:
            log.warning("No swarm agents found for task type: %s", task_type)
            return MergeResult(agents_merged=0, memories_added=0,
                             memories_deduplicated=0, principles_merged=0,
                             principles_boosted=0, principles_conflicted=0)

        # Temporarily set mesh to swarm agents only
        original = self.agents.copy()
        self.agents = swarm_agents
        result = self.merge_all(strategy=strategy, target_db=target_db,
                                domains=[task_type])
        self.agents = original

        log.info("Harvested swarm: %d agents, %d consensus principles",
                 result.agents_merged, result.consensus_principles)

        return result

    # ------------------------------------------------------------------
    # Mesh Status
    # ------------------------------------------------------------------

    def status(self) -> Dict:
        """Get mesh status overview."""
        total_memories = 0
        total_principles = 0
        total_episodes = 0
        agents_online = 0

        for name, agent in self.agents.items():
            if Path(agent.db_path).exists():
                agents_online += 1
                try:
                    conn = sqlite3.connect(agent.db_path)
                    row = conn.execute("SELECT COUNT(*) FROM memories WHERE active=1").fetchone()
                    agent.memory_count = row[0] if row else 0
                    row = conn.execute("SELECT COUNT(*) FROM skill_principles WHERE status='active'").fetchone()
                    agent.principle_count = row[0] if row else 0
                    row = conn.execute("SELECT COUNT(*) FROM skill_episodes").fetchone()
                    agent.episode_count = row[0] if row else 0
                    conn.close()

                    total_memories += agent.memory_count
                    total_principles += agent.principle_count
                    total_episodes += agent.episode_count
                except Exception:
                    pass

        return {
            "agents_registered": len(self.agents),
            "agents_online": agents_online,
            "total_memories": total_memories,
            "total_principles": total_principles,
            "total_episodes": total_episodes,
            "agents": {
                name: {
                    "db_path": a.db_path,
                    "online": Path(a.db_path).exists(),
                    "trust": a.trust_score,
                    "specializations": a.specializations,
                    "memories": a.memory_count,
                    "principles": a.principle_count,
                    "episodes": a.episode_count,
                    "last_sync": a.last_sync,
                }
                for name, a in self.agents.items()
            }
        }


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def cli_mesh(args: List[str], db_path: str) -> int:
    """Handle `aibrain mesh <subcommand>` CLI calls."""
    mesh = BrainMesh(db_path)

    if not args:
        print("Usage: aibrain mesh <status|register|merge|distribute|swarm>")
        return 1

    subcmd = args[0]

    # Tier enforcement
    try:
        from aibrain_licensing import check_tier, upgrade_message
        tier_map = {
            "register": "pro", "merge": "team", "distribute": "team",
            "swarm": "enterprise",
        }
        required = tier_map.get(subcmd)
        if required and not check_tier(required):
            print(upgrade_message(required))
            return 1
    except ImportError:
        pass

    if subcmd == "status":
        status = mesh.status()
        print(f"\n  Brain Mesh — {status['agents_online']}/{status['agents_registered']} agents online")
        print(f"  Total: {status['total_memories']} memories, {status['total_principles']} principles, "
              f"{status['total_episodes']} episodes\n")
        for name, info in status["agents"].items():
            online = "🟢" if info["online"] else "🔴"
            print(f"  {online} {name:20s} trust={info['trust']:.1f}  "
                  f"mem={info['memories']}  prin={info['principles']}  "
                  f"ep={info['episodes']}  spec={','.join(info['specializations']) or '-'}")

    elif subcmd == "register":
        if len(args) >= 3:
            name = args[1]
            path = args[2]
            trust = float(args[4]) if len(args) > 4 and args[3] == "--trust" else 1.0
            specs = args[args.index("--spec") + 1].split(",") if "--spec" in args else []
            agent = mesh.register_agent(name, path, trust, specs)
            print(f"Registered: {agent.name} ({agent.db_path}) trust={agent.trust_score}")
        else:
            print("Usage: aibrain mesh register <name> <db_path> [--trust 0.9] [--spec security,scanning]")

    elif subcmd == "merge":
        strategy = args[2] if len(args) > 2 and args[1] == "--strategy" else "consensus"
        dry_run = "--dry-run" in args
        domains = None
        if "--domains" in args:
            idx = args.index("--domains") + 1
            if idx < len(args):
                domains = args[idx].split(",")

        result = mesh.merge_all(strategy=strategy, dry_run=dry_run, domains=domains)

        if dry_run:
            print(f"DRY RUN — {result.agents_merged} agents would be merged:")
        else:
            print(f"Merged {result.agents_merged} agents:")

        print(f"  Memories: +{result.memories_added} new, {result.memories_deduplicated} deduplicated")
        print(f"  Principles: {result.principles_merged} total, {result.consensus_principles} consensus-boosted")
        print(f"  Duration: {result.duration_seconds:.1f}s")

    elif subcmd == "distribute":
        principles_only = "--principles-only" in args
        results = mesh.distribute(principles_only=principles_only)
        for agent, r in results.items():
            if r["status"] == "ok":
                print(f"  ✅ {agent}: +{r['principles_updated']} principles, +{r.get('memories_added', 0)} memories")
            else:
                print(f"  🔴 {agent}: {r['message']}")

    elif subcmd == "swarm":
        if len(args) >= 3 and args[1] == "create":
            task_type = args[2]
            num = int(args[4]) if len(args) > 4 and args[3] == "-n" else 10
            paths = mesh.create_training_swarm(task_type, num)
            print(f"Created {len(paths)} swarm agents for '{task_type}':")
            for p in paths:
                print(f"  {p}")
        elif len(args) >= 3 and args[1] == "harvest":
            task_type = args[2]
            result = mesh.harvest_swarm(task_type)
            print(f"Harvested {result.agents_merged} swarm agents:")
            print(f"  Consensus principles: {result.consensus_principles}")
            print(f"  Memories added: {result.memories_added}")
        else:
            print("Usage: aibrain mesh swarm <create|harvest> <task_type> [-n 10]")

    else:
        print(f"Unknown subcommand: {subcmd}")
        return 1

    return 0


if __name__ == "__main__":
    import sys
    db = os.environ.get("AIBRAIN_DB", str(Path.home() / "aibrain" / "aibrain.db"))
    sys.exit(cli_mesh(sys.argv[1:], db))
