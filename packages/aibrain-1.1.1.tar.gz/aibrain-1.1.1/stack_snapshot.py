#!/usr/bin/env python3
"""AIBrain Stack Snapshot — capture and restore agent running state.

Problem: When an agent crashes, reboots, or starts a new session, it loses
its running state — cron jobs, hooks, background processes, active services.
Users have to manually set everything up again.

Solution: Periodic snapshots of the full "stack" (everything the agent is running)
that auto-restore on next session start.

Features:
  1. stack save [name]     — manual named snapshot (e.g. "trading", "security")
  2. stack restore [name]  — restore a named snapshot
  3. stack auto            — passive hourly auto-snapshot (cron-driven)
  4. stack list            — show all saved snapshots
  5. stack diff [a] [b]    — compare two snapshots
  6. stack current         — show what's running now

The "last" snapshot is always auto-saved and is what gets restored on startup.

Usage:
    python stack_snapshot.py save trading      # Save current state as "trading"
    python stack_snapshot.py restore trading   # Restore the "trading" stack
    python stack_snapshot.py auto              # Auto-snapshot (for cron)
    python stack_snapshot.py restore           # Restore last auto-snapshot
    python stack_snapshot.py current           # Show current running state
    python stack_snapshot.py list              # List all snapshots
"""

import argparse
import json
import os
import platform
import subprocess
import sys
from datetime import datetime
from pathlib import Path

# ---------------------------------------------------------------------------
# Root / config resolution
# ---------------------------------------------------------------------------

def _resolve_root():
    if "AIBRAIN_ROOT" in os.environ:
        return Path(os.environ["AIBRAIN_ROOT"])
    if "AIBRAIN_ROOT" in os.environ:
        return Path(os.environ["AIBRAIN_ROOT"])
    return Path(__file__).parent


AIBRAIN_ROOT = _resolve_root()
SNAPSHOT_DIR = AIBRAIN_ROOT / "data" / "stack_snapshots"
SNAPSHOT_DIR.mkdir(parents=True, exist_ok=True)

CONFIG_PATH = AIBRAIN_ROOT / "config.json"


def _load_config():
    if CONFIG_PATH.exists():
        try:
            return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {}


# ---------------------------------------------------------------------------
# Stack capture — what's running right now
# ---------------------------------------------------------------------------

def capture_current_stack() -> dict:
    """Capture a full snapshot of current agent running state."""
    stack = {
        "timestamp": datetime.now().isoformat(),
        "platform": platform.system(),
        "hostname": platform.node(),
        "aibrain_root": str(AIBRAIN_ROOT),
    }

    # 1. Cron jobs (from scheduled_jobs.json)
    stack["cron_jobs"] = _capture_cron_jobs()

    # 2. Hooks (from Claude Code settings.json)
    stack["hooks"] = _capture_hooks()

    # 3. Background processes (python, node, etc.)
    stack["processes"] = _capture_processes()

    # 3.5. MCP server configs (from .mcp.json)
    stack["mcp_servers"] = _capture_mcp_servers()

    # 4. Active services (API server, MCP server, dashboard)
    stack["services"] = _capture_services()

    # 5. Config snapshot (non-sensitive fields)
    stack["config"] = _capture_config()

    # 6. Git state
    stack["git"] = _capture_git_state()

    # 7. DB stats
    stack["db"] = _capture_db_stats()

    return stack


def _capture_cron_jobs() -> list:
    """Read scheduled_jobs.json to capture cron state."""
    config = _load_config()
    cron_path = config.get("cron_jobs")
    if cron_path:
        cron_path = Path(cron_path)
    else:
        cron_path = AIBRAIN_ROOT / "scheduled_jobs.json"

    if not cron_path.exists():
        # Try common locations
        for candidate in [
            AIBRAIN_ROOT / "data" / "scheduled_jobs.json",
        ]:
            if candidate.exists():
                cron_path = candidate
                break

    if not cron_path.exists():
        return []

    try:
        data = json.loads(cron_path.read_text(encoding="utf-8"))
        jobs = data.get("jobs", data) if isinstance(data, dict) else data
        if isinstance(jobs, list):
            return [{"name": j.get("name", f"job_{i}"),
                      "cron": j.get("cron", ""),
                      "enabled": j.get("enabled", True),
                      "prompt": j.get("prompt", "")[:200]}
                     for i, j in enumerate(jobs)]
    except Exception:
        pass
    return []


def _capture_hooks() -> dict:
    """Read Claude Code settings.json for hook configuration."""
    settings_paths = [
        Path.home() / ".claude" / "settings.json",
        Path.home() / ".claude" / "settings.local.json",
    ]
    for sp in settings_paths:
        if sp.exists():
            try:
                settings = json.loads(sp.read_text(encoding="utf-8"))
                hooks = settings.get("hooks", {})
                # Capture hook structure without full command paths (portable)
                result = {}
                for event, hook_list in hooks.items():
                    result[event] = []
                    if isinstance(hook_list, list):
                        for entry in hook_list:
                            matcher = entry.get("matcher", "*")
                            inner_hooks = entry.get("hooks", [])
                            for h in inner_hooks:
                                cmd = h.get("command", "")
                                # Extract just the script name for portability
                                script = Path(cmd.split()[-1]).name if cmd else ""
                                result[event].append({
                                    "matcher": matcher,
                                    "script": script,
                                    "command": cmd,
                                    "timeout": h.get("timeout"),
                                    "statusMessage": h.get("statusMessage"),
                                })
                return result
            except Exception:
                pass
    return {}


def _capture_mcp_servers() -> dict:
    """Capture MCP server configuration from .mcp.json."""
    mcp_config = {}
    try:
        mcp_path = AIBRAIN_ROOT / ".mcp.json"
        if mcp_path.exists():
            mcp_config = json.loads(mcp_path.read_text(encoding="utf-8"))
    except Exception:
        pass
    return mcp_config


def _capture_processes() -> list:
    """Capture relevant background processes."""
    processes = []
    try:
        if platform.system() == "Windows":
            result = subprocess.run(
                ["tasklist", "/FO", "CSV", "/FI", "IMAGENAME eq python.exe"],
                capture_output=True, text=True, timeout=5
            )
            # Also check pythonw, node
            for proc_name in ["pythonw.exe", "node.exe"]:
                r2 = subprocess.run(
                    ["tasklist", "/FO", "CSV", "/FI", f"IMAGENAME eq {proc_name}"],
                    capture_output=True, text=True, timeout=5
                )
                result.stdout += r2.stdout
        else:
            result = subprocess.run(
                ["ps", "aux"], capture_output=True, text=True, timeout=5
            )

        for line in result.stdout.strip().split("\n"):
            line_lower = line.lower()
            # Filter for aibrain-related processes
            if any(kw in line_lower for kw in [
                "aibrain", "aibrain", "mcp_server", "realtime_learner",
                "memory_md_sync", "broker", "dashboard", "uvicorn",
                "next", "stack_snapshot"
            ]):
                processes.append(line.strip()[:200])
    except Exception:
        pass
    return processes


def _capture_services() -> list:
    """Check which AIBrain services are responding."""
    services = []
    service_checks = [
        ("API Server", "http://localhost:8001/health"),
        ("MCP Server", "http://localhost:8002/health"),
        ("Dashboard", "http://localhost:3000"),
    ]

    import urllib.request
    for name, url in service_checks:
        try:
            req = urllib.request.Request(url, method="GET")
            with urllib.request.urlopen(req, timeout=2) as resp:
                services.append({"name": name, "url": url, "status": "running",
                                 "code": resp.status})
        except Exception:
            services.append({"name": name, "url": url, "status": "stopped"})

    return services


def _capture_config() -> dict:
    """Capture non-sensitive config fields."""
    config = _load_config()
    # Strip sensitive fields
    safe_keys = [
        "llm_provider", "theme", "setup_complete", "timezone",
        "location_name", "watched_repos", "git_scan_repos",
        "training_data_dirs",
    ]
    return {k: config[k] for k in safe_keys if k in config}


def _capture_git_state() -> dict:
    """Capture current git branch and status."""
    try:
        branch = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True, text=True, timeout=5, cwd=str(AIBRAIN_ROOT)
        ).stdout.strip()

        status = subprocess.run(
            ["git", "status", "--short"],
            capture_output=True, text=True, timeout=5, cwd=str(AIBRAIN_ROOT)
        ).stdout.strip()

        last_commit = subprocess.run(
            ["git", "log", "--oneline", "-1"],
            capture_output=True, text=True, timeout=5, cwd=str(AIBRAIN_ROOT)
        ).stdout.strip()

        uncommitted = len([l for l in status.split("\n") if l.strip()]) if status else 0

        return {"branch": branch, "last_commit": last_commit,
                "uncommitted_files": uncommitted}
    except Exception:
        return {}


def _capture_db_stats() -> dict:
    """Quick DB stats."""
    import sqlite3
    for db_name in ["aibrain.db"]:
        db_path = AIBRAIN_ROOT / db_name
        if db_path.exists():
            try:
                conn = sqlite3.connect(str(db_path), timeout=3)
                total = conn.execute(
                    "SELECT COUNT(*) FROM memories WHERE active=1"
                ).fetchone()[0]
                conn.close()
                return {"path": str(db_path),
                        "size_kb": round(db_path.stat().st_size / 1024),
                        "active_memories": total}
            except Exception:
                pass
    return {}


# ---------------------------------------------------------------------------
# Save / restore / list
# ---------------------------------------------------------------------------

def _rotate_auto_snapshots():
    """Keep last 3 auto-snapshots for rollback: last.json → last_1.json → last_2.json."""
    last_2 = SNAPSHOT_DIR / "last_2.json"
    last_1 = SNAPSHOT_DIR / "last_1.json"
    last_0 = SNAPSHOT_DIR / "last.json"

    # Rotate: drop oldest, shift others
    if last_2.exists():
        last_2.unlink()
    if last_1.exists():
        last_1.rename(last_2)
    if last_0.exists():
        last_0.rename(last_1)


def save_snapshot(name: str = "last") -> Path:
    """Save current stack to a named snapshot file."""
    stack = capture_current_stack()
    stack["snapshot_name"] = name

    # Rotate auto-snapshots before overwriting "last"
    if name == "last":
        _rotate_auto_snapshots()

    filename = f"{name}.json"
    filepath = SNAPSHOT_DIR / filename
    filepath.write_text(json.dumps(stack, indent=2, default=str), encoding="utf-8")

    # Also always update "last" if this isn't already "last"
    if name != "last":
        _rotate_auto_snapshots()
        last_path = SNAPSHOT_DIR / "last.json"
        last_path.write_text(json.dumps(stack, indent=2, default=str), encoding="utf-8")

    print(f"Stack snapshot saved: {name}")
    print(f"  Crons: {len(stack['cron_jobs'])} jobs")
    print(f"  Hooks: {sum(len(v) for v in stack['hooks'].values())} hooks across {len(stack['hooks'])} events")
    print(f"  MCP: {len(stack.get('mcp_servers', {}).get('mcpServers', {}))} servers")
    print(f"  Services: {sum(1 for s in stack['services'] if s['status'] == 'running')}/{len(stack['services'])} running")
    print(f"  DB: {stack['db'].get('active_memories', '?')} memories")
    print(f"  File: {filepath}")

    return filepath


def load_snapshot(name: str = "last") -> dict:
    """Load a named snapshot."""
    filepath = SNAPSHOT_DIR / f"{name}.json"
    if not filepath.exists():
        print(f"Snapshot '{name}' not found at {filepath}")
        return {}
    return json.loads(filepath.read_text(encoding="utf-8"))


def restore_snapshot(name: str = "last", dry_run: bool = False) -> dict:
    """Restore a stack snapshot — recreate crons, install hooks, start services.

    This is the real restore: it writes scheduled_jobs.json and settings.json
    so the agent comes back to its last known working state on startup.
    """
    snapshot = load_snapshot(name)
    if not snapshot:
        return {"error": f"Snapshot '{name}' not found"}

    current = capture_current_stack()
    report = {"snapshot": name, "timestamp": snapshot.get("timestamp"),
              "restored": [], "diffs": [], "skipped": []}

    print(f"\nStack Restore: '{name}'")
    print(f"  Snapshot from: {snapshot.get('timestamp', 'unknown')}")
    print(f"  Platform: {snapshot.get('platform', '?')} / {snapshot.get('hostname', '?')}")

    # 1. Restore cron jobs → write scheduled_jobs.json
    snap_crons = snapshot.get("cron_jobs", [])
    if snap_crons:
        enabled_crons = [j for j in snap_crons if j.get("enabled", True)]
        if dry_run:
            report["diffs"].append(f"Would restore {len(enabled_crons)} cron jobs to scheduled_jobs.json")
        else:
            restored_count = _write_scheduled_jobs(snap_crons)
            report["restored"].append(f"Restored {restored_count} cron jobs")
            print(f"  + Restored {restored_count} cron jobs to scheduled_jobs.json")

    # 2. Restore hooks → write to ~/.claude/settings.json
    snap_hooks = snapshot.get("hooks", {})
    if snap_hooks:
        if dry_run:
            hook_count = sum(len(v) for v in snap_hooks.values())
            report["diffs"].append(f"Would restore {hook_count} hooks across {len(snap_hooks)} events")
        else:
            installed = _install_hooks(snap_hooks)
            report["restored"].append(f"Installed {installed} hooks")
            print(f"  + Installed {installed} hooks into Claude Code settings")

    # 2.5. Restore MCP servers → write to .mcp.json
    snap_mcp = snapshot.get("mcp_servers", {})
    if snap_mcp:
        mcp_path = AIBRAIN_ROOT / ".mcp.json"
        if dry_run:
            server_count = len(snap_mcp.get("mcpServers", {}))
            report["diffs"].append(f"Would restore {server_count} MCP servers to .mcp.json")
        else:
            try:
                mcp_path.write_text(json.dumps(snap_mcp, indent=2) + "\n", encoding="utf-8")
                server_count = len(snap_mcp.get("mcpServers", {}))
                report["restored"].append(f"Restored {server_count} MCP servers")
                print(f"  + Restored {server_count} MCP servers to .mcp.json")
            except Exception as e:
                report["diffs"].append(f"Failed to restore MCP servers: {e}")

    # 3. Report service state (don't auto-start — aibrain start handles that)
    snap_services = {s["name"]: s for s in snapshot.get("services", [])}
    curr_services = {s["name"]: s for s in current.get("services", [])}
    for svc_name, svc in snap_services.items():
        if svc.get("status") in ("running", "required"):
            curr = curr_services.get(svc_name, {})
            if curr.get("status") != "running":
                report["diffs"].append(f"Service '{svc_name}' needs starting")

    # 4. DB comparison (informational only)
    snap_db = snapshot.get("db", {})
    curr_db = current.get("db", {})
    if snap_db.get("active_memories") and curr_db.get("active_memories"):
        diff = curr_db["active_memories"] - snap_db["active_memories"]
        if diff != 0:
            report["diffs"].append(
                f"DB: {snap_db['active_memories']} → {curr_db['active_memories']} "
                f"({'+' if diff > 0 else ''}{diff})")

    # 5. Memory staleness check — auto-recover from transcripts if needed
    try:
        from transcript_recovery import check_staleness, auto_recover
        staleness = check_staleness()
        if staleness.get("stale"):
            print(f"\n  ⚠ Memory stale ({staleness['last_memory_age_hours']}h since last real memory)")
            if not dry_run:
                recovery = auto_recover(hours=48)
                if recovery["recovered"] > 0:
                    report["restored"].append(
                        f"Auto-recovered {recovery['recovered']} memories from "
                        f"{recovery['transcripts_processed']} transcripts"
                    )
                    print(f"  + Auto-recovered {recovery['recovered']} memories from transcripts")
                else:
                    report["diffs"].append("Memory stale but no new context found in transcripts")
        else:
            report["diffs"].append(
                f"Memory OK ({staleness['last_memory_age_hours']}h, "
                f"{staleness.get('recent_conv_memories', 0)} recent)"
            )
    except Exception as e:
        report["diffs"].append(f"Transcript recovery check failed: {e}")

    # Summary
    if report["restored"]:
        print(f"\n  Restored:")
        for r in report["restored"]:
            print(f"    + {r}")
    if report["diffs"]:
        print(f"\n  Notes:")
        for d in report["diffs"]:
            print(f"    - {d}")
    if not report["restored"] and not report["diffs"]:
        print("\n  Stack matches snapshot — nothing to restore.")

    return report


def _write_scheduled_jobs(cron_jobs: list) -> int:
    """Write cron jobs from snapshot into scheduled_jobs.json.

    Merges with existing jobs: snapshot jobs override by name,
    existing jobs not in snapshot are preserved.
    """
    config = _load_config()
    cron_path = config.get("cron_jobs")
    if cron_path:
        cron_path = Path(cron_path)
    else:
        cron_path = AIBRAIN_ROOT / "scheduled_jobs.json"

    # Load existing scheduled_jobs.json if it exists
    existing_jobs = {}
    existing_meta = {}
    if cron_path.exists():
        try:
            data = json.loads(cron_path.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                existing_meta = {k: v for k, v in data.items() if k.startswith("_")}
                for j in data.get("jobs", []):
                    existing_jobs[j.get("name")] = j
            elif isinstance(data, list):
                for j in data:
                    existing_jobs[j.get("name")] = j
        except Exception:
            pass

    # Merge: snapshot jobs take priority
    for snap_job in cron_jobs:
        name = snap_job.get("name")
        if not name:
            continue
        # Build a proper job entry from snapshot data
        job_entry = existing_jobs.get(name, {})
        job_entry["name"] = name
        job_entry["cron"] = snap_job.get("cron", job_entry.get("cron", ""))
        job_entry["enabled"] = snap_job.get("enabled", True)
        if snap_job.get("script"):
            job_entry["script"] = snap_job["script"]
        if snap_job.get("description"):
            job_entry["description"] = snap_job["description"]
        if snap_job.get("group"):
            job_entry["group"] = snap_job["group"]
        if snap_job.get("pack"):
            job_entry["pack"] = snap_job["pack"]
        if snap_job.get("prompt"):
            job_entry["prompt"] = snap_job["prompt"]
        existing_jobs[name] = job_entry

    # Write back
    output = dict(existing_meta)
    if not output.get("_description"):
        output["_description"] = "AIBrain scheduled jobs — restored from stack snapshot"
    output["_restored_from"] = datetime.now().isoformat()
    output["jobs"] = list(existing_jobs.values())

    cron_path.write_text(json.dumps(output, indent=2, ensure_ascii=False), encoding="utf-8")
    return len([j for j in cron_jobs if j.get("enabled", True)])


def _install_hooks(hooks: dict) -> int:
    """Install hooks from snapshot into Claude Code settings.json.

    Merges with existing hooks: adds missing events/scripts without
    removing hooks that aren't in the snapshot.
    """
    settings_paths = [
        Path.home() / ".claude" / "settings.json",
        Path.home() / ".claude" / "settings.local.json",
    ]
    settings_path = None
    settings = {}
    for sp in settings_paths:
        if sp.exists():
            settings_path = sp
            try:
                settings = json.loads(sp.read_text(encoding="utf-8"))
            except Exception:
                settings = {}
            break

    if settings_path is None:
        # Create settings.json if it doesn't exist
        settings_path = Path.home() / ".claude" / "settings.json"
        settings_path.parent.mkdir(parents=True, exist_ok=True)
        settings = {}

    existing_hooks = settings.get("hooks", {})
    installed = 0

    for event, hook_list in hooks.items():
        if event not in existing_hooks:
            # Add entire event with all its hooks
            existing_hooks[event] = []

        # Get existing scripts for this event to avoid duplicates
        existing_scripts = set()
        for entry in existing_hooks[event]:
            for h in entry.get("hooks", []):
                cmd = h.get("command", "")
                # Extract script name for comparison
                if cmd:
                    existing_scripts.add(Path(cmd.split()[-1]).name)

        for snap_hook in hook_list:
            script_name = snap_hook.get("script", "")
            if script_name and script_name not in existing_scripts:
                # Build the hook entry in Claude Code format
                command = snap_hook.get("command", "")
                if not command and script_name:
                    # Build command from script name + aibrain root
                    command = f"{sys.executable} {AIBRAIN_ROOT / script_name}"

                hook_entry = {
                    "matcher": snap_hook.get("matcher", "*"),
                    "hooks": [{
                        "type": "command",
                        "command": command,
                    }]
                }
                if snap_hook.get("timeout"):
                    hook_entry["hooks"][0]["timeout"] = snap_hook["timeout"]
                if snap_hook.get("statusMessage"):
                    hook_entry["hooks"][0]["statusMessage"] = snap_hook["statusMessage"]

                existing_hooks[event].append(hook_entry)
                installed += 1

    settings["hooks"] = existing_hooks
    settings_path.write_text(json.dumps(settings, indent=2), encoding="utf-8")
    return installed


def save_default(name: str = "default") -> Path:
    """Save current stack as the user's default stack.

    The default stack is what gets offered at startup if the last known
    stack was something different (e.g. a named pack stack).
    """
    stack = capture_current_stack()
    stack["snapshot_name"] = name
    stack["is_default"] = True
    filepath = SNAPSHOT_DIR / f"{name}.json"
    filepath.write_text(json.dumps(stack, indent=2, default=str), encoding="utf-8")
    print(f"Default stack saved: {filepath}")
    print(f"  On restart, you'll be asked: restore last stack or default?")
    return filepath


def get_startup_choice() -> str:
    """At startup, compare last vs default stack and return which to restore.

    Returns the snapshot name to restore: 'last', 'default', or a named stack.
    If no default exists, silently returns 'last'.
    """
    default_path = SNAPSHOT_DIR / "default.json"
    last_path = SNAPSHOT_DIR / "last.json"

    if not last_path.exists():
        return "default" if default_path.exists() else ""
    if not default_path.exists():
        return "last"

    # Both exist — compare them
    try:
        last = json.loads(last_path.read_text(encoding="utf-8"))
        default = json.loads(default_path.read_text(encoding="utf-8"))
    except Exception:
        return "last"

    # Compare cron job names to detect if stacks differ
    last_crons = {j["name"] for j in last.get("cron_jobs", []) if j.get("enabled", True)}
    default_crons = {j["name"] for j in default.get("cron_jobs", []) if j.get("enabled", True)}

    if last_crons == default_crons:
        return "last"  # Same stack, no prompt needed

    # They differ — format info for the caller
    last_name = last.get("snapshot_name", "last")
    last_ts = last.get("timestamp", "unknown")[:19]
    added = last_crons - default_crons
    removed = default_crons - last_crons

    print(f"\n  Last known stack differs from your default:")
    print(f"    Last stack: '{last_name}' (from {last_ts})")
    print(f"      {len(last_crons)} cron jobs")
    if added:
        print(f"      Extra vs default: {', '.join(sorted(added)[:5])}"
              f"{'...' if len(added) > 5 else ''}")
    if removed:
        print(f"      Missing vs default: {', '.join(sorted(removed)[:5])}"
              f"{'...' if len(removed) > 5 else ''}")
    print(f"    Default stack: {len(default_crons)} cron jobs")

    # Return special marker so caller knows to prompt
    return "prompt_user"


def rollback_snapshot(steps: int = 1) -> dict:
    """Roll back to a previous auto-snapshot.

    steps=1 → last_1.json (previous), steps=2 → last_2.json (two back)
    """
    if steps < 1 or steps > 2:
        print("Can roll back 1 or 2 steps (last 3 snapshots kept)")
        return {"error": "Invalid rollback steps"}

    rollback_name = f"last_{steps}"
    rollback_path = SNAPSHOT_DIR / f"{rollback_name}.json"

    if not rollback_path.exists():
        print(f"No snapshot '{rollback_name}' found — not enough history yet")
        return {"error": f"Snapshot '{rollback_name}' not found"}

    print(f"Rolling back to {rollback_name}...")

    # Load the rollback snapshot
    snapshot = json.loads(rollback_path.read_text(encoding="utf-8"))

    # Save current state as a safety backup before rollback
    save_snapshot(f"pre_rollback_{datetime.now().strftime('%Y%m%d_%H%M')}")

    # Copy rollback snapshot to last.json
    last_path = SNAPSHOT_DIR / "last.json"
    last_path.write_text(json.dumps(snapshot, indent=2, default=str), encoding="utf-8")

    # Now restore from it
    return restore_snapshot("last")


def list_snapshots():
    """List all saved snapshots."""
    snapshots = sorted(SNAPSHOT_DIR.glob("*.json"))
    if not snapshots:
        print("No snapshots saved yet.")
        print(f"  Run: python stack_snapshot.py save <name>")
        return

    print(f"Stack Snapshots ({len(snapshots)}):")
    print(f"  Directory: {SNAPSHOT_DIR}")
    print()

    for sp in snapshots:
        try:
            data = json.loads(sp.read_text(encoding="utf-8"))
            name = sp.stem
            ts = data.get("timestamp", "?")
            crons = len(data.get("cron_jobs", []))
            hooks = sum(len(v) for v in data.get("hooks", {}).values())
            services_up = sum(1 for s in data.get("services", [])
                              if s.get("status") == "running")
            db_mems = data.get("db", {}).get("active_memories", "?")
            host = data.get("hostname", "?")

            marker = " <-- latest" if name == "last" else ""
            print(f"  {name:20s}  {ts[:19]}  host={host}  "
                  f"crons={crons} hooks={hooks} svcs={services_up} "
                  f"memories={db_mems}{marker}")
        except Exception:
            print(f"  {sp.stem:20s}  (corrupt)")


def show_current():
    """Show current running stack."""
    stack = capture_current_stack()
    print("Current Stack:")
    print(f"  Platform: {stack['platform']} / {stack['hostname']}")
    print(f"  AIBrain root: {stack['aibrain_root']}")

    # Crons
    crons = stack["cron_jobs"]
    enabled = [j for j in crons if j.get("enabled", True)]
    print(f"\n  Cron Jobs: {len(enabled)} enabled / {len(crons)} total")
    for j in enabled[:10]:
        print(f"    [{j['cron']:15s}] {j['name']}")
    if len(enabled) > 10:
        print(f"    ... and {len(enabled) - 10} more")

    # Hooks
    hooks = stack["hooks"]
    print(f"\n  Hooks: {sum(len(v) for v in hooks.values())} across {len(hooks)} events")
    for event, hook_list in hooks.items():
        scripts = [h["script"] for h in hook_list]
        print(f"    {event}: {', '.join(scripts)}")

    # Services
    print(f"\n  Services:")
    for s in stack["services"]:
        status = "UP" if s["status"] == "running" else "--"
        print(f"    {status} {s['name']} ({s['url']})")

    # Git
    git = stack["git"]
    if git:
        print(f"\n  Git: {git.get('branch', '?')} @ {git.get('last_commit', '?')}")
        if git.get("uncommitted_files"):
            print(f"    {git['uncommitted_files']} uncommitted files")

    # DB
    db = stack["db"]
    if db:
        print(f"\n  DB: {db.get('active_memories', '?')} memories "
              f"({db.get('size_kb', '?')}KB)")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="AIBrain Stack Snapshot — capture and restore agent state"
    )
    parser.add_argument("command", nargs="?", default="current",
                        choices=["save", "restore", "auto", "list", "current",
                                 "diff", "rollback", "set-default", "startup"],
                        help="Command to run")
    parser.add_argument("name", nargs="?", default=None,
                        help="Snapshot name (default: 'last' for auto)")
    parser.add_argument("--dry-run", action="store_true",
                        help="Show what would change without restoring")
    parser.add_argument("--json", action="store_true", dest="json_output",
                        help="Output as JSON")
    args = parser.parse_args()

    if args.command == "save":
        name = args.name or datetime.now().strftime("snap_%Y%m%d_%H%M")
        save_snapshot(name)

    elif args.command == "restore":
        name = args.name or "last"
        result = restore_snapshot(name, dry_run=args.dry_run)
        if args.json_output:
            print(json.dumps(result, indent=2, default=str))

    elif args.command == "auto":
        # Auto-snapshot — saves as "last" (called by hourly cron)
        save_snapshot("last")

    elif args.command == "list":
        list_snapshots()

    elif args.command == "current":
        if args.json_output:
            print(json.dumps(capture_current_stack(), indent=2, default=str))
        else:
            show_current()

    elif args.command == "diff":
        name = args.name or "last"
        restore_snapshot(name, dry_run=True)

    elif args.command == "rollback":
        steps = int(args.name) if args.name and args.name.isdigit() else 1
        if args.dry_run:
            rollback_name = f"last_{steps}"
            snap = load_snapshot(rollback_name)
            if snap:
                print(f"Would roll back to {rollback_name} from {snap.get('timestamp', '?')}")
                print(f"  Crons: {len(snap.get('cron_jobs', []))}")
                print(f"  Hooks: {sum(len(v) for v in snap.get('hooks', {}).values())}")
        else:
            rollback_snapshot(steps)

    elif args.command == "set-default":
        save_default()

    elif args.command == "startup":
        # Called by `aibrain start` — decide which stack to restore
        choice = get_startup_choice()
        if choice == "prompt_user":
            # Output the choice prompt — aibrain start reads this
            try:
                answer = input("\n  Restore [L]ast stack or [D]efault? (L/d): ").strip().lower()
            except (EOFError, KeyboardInterrupt):
                answer = "l"
            if answer in ("d", "default"):
                restore_snapshot("default")
            else:
                restore_snapshot("last")
        elif choice:
            restore_snapshot(choice)
        else:
            print("  No snapshots found — starting fresh")


if __name__ == "__main__":
    main()
