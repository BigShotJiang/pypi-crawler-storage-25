#!/usr/bin/env python3
"""AIBrain Workflow Runner — invoke any workflow class by name.

Unified entry point for running skill, user, ops, and content workflows.
Used by scheduled_jobs.json and hooks to trigger class-based workflows.

Usage:
    python run_workflow.py correction_learner
    python run_workflow.py memory_hygiene
    python run_workflow.py knowledge_decay
    python run_workflow.py goal_drift
    python run_workflow.py --list              # Show all available workflows
    python run_workflow.py --list-category self_improvement
"""

import json
import os
import re
import sys
from pathlib import Path

# Resolve DB
def _resolve_db():
    if "AIBRAIN_DB" in os.environ:
        return os.environ["AIBRAIN_DB"]
    root = Path(os.environ.get("AIBRAIN_ROOT",
                os.environ.get("AIBRAIN_ROOT",
                Path(__file__).parent)))
    for name in ["aibrain.db"]:
        p = root / name
        if p.exists():
            return str(p)
    return str(root / "aibrain.db")


def _load_registries():
    """Load all workflow registries."""
    registries = {}

    try:
        from aibrain_workflows import WORKFLOW_REGISTRY
        registries.update(WORKFLOW_REGISTRY)
    except ImportError:
        pass

    try:
        from aibrain_skill_workflows import SKILL_WORKFLOW_REGISTRY
        registries.update(SKILL_WORKFLOW_REGISTRY)
    except ImportError:
        pass

    try:
        from aibrain_user_workflows import USER_WORKFLOW_REGISTRY
        registries.update(USER_WORKFLOW_REGISTRY)
    except ImportError:
        pass

    try:
        from aibrain_ops_workflows import OPS_WORKFLOW_REGISTRY
        registries.update(OPS_WORKFLOW_REGISTRY)
    except ImportError:
        pass

    try:
        from aibrain_content_workflows import CONTENT_WORKFLOW_REGISTRY
        registries.update(CONTENT_WORKFLOW_REGISTRY)
    except ImportError:
        pass

    try:
        from aibrain_custom_workflows import CUSTOM_WORKFLOW_REGISTRY
        registries.update(CUSTOM_WORKFLOW_REGISTRY)
    except ImportError:
        pass

    try:
        from aibrain_it_support_workflows import IT_SUPPORT_WORKFLOW_REGISTRY
        registries.update(IT_SUPPORT_WORKFLOW_REGISTRY)
    except ImportError:
        pass

    try:
        from aibrain_skill_evolution import SKILL_EVOLUTION_REGISTRY
        registries.update(SKILL_EVOLUTION_REGISTRY)
    except ImportError:
        pass

    return registries


def main():
    if len(sys.argv) < 2 or sys.argv[1] == "--list":
        registries = _load_registries()
        category_filter = None
        if "--list-category" in sys.argv:
            idx = sys.argv.index("--list-category")
            if idx + 1 < len(sys.argv):
                category_filter = sys.argv[idx + 1]

        print(f"AIBrain Workflows ({len(registries)} available):\n")

        # Group by category
        by_cat = {}
        for name, cls in sorted(registries.items()):
            cat = getattr(cls, "category", "uncategorized")
            if category_filter and cat != category_filter:
                continue
            by_cat.setdefault(cat, []).append((name, cls))

        for cat, items in sorted(by_cat.items()):
            print(f"  [{cat}] ({len(items)})")
            for name, cls in items:
                cron = getattr(cls, "schedule_cron", "—")
                desc = getattr(cls, "description", "")[:60]
                print(f"    {name:35s} {cron:20s} {desc}")
            print()
        return

    wf_name = sys.argv[1]
    db_path = _resolve_db()

    # Override DB if --db flag provided
    if "--db" in sys.argv:
        idx = sys.argv.index("--db")
        if idx + 1 < len(sys.argv):
            db_path = sys.argv[idx + 1]

    registries = _load_registries()
    cls = registries.get(wf_name)

    if not cls:
        # Fallback: try running a standalone script from workflows/
        # Validate name is safe before using in path construction
        if not re.match(r'^[a-zA-Z0-9_]+$', wf_name):
            print(f"Invalid workflow name: {wf_name!r} (only letters, digits, underscores allowed)")
            sys.exit(1)
        workflows_dir = (Path(__file__).parent / "workflows").resolve()
        script = workflows_dir / f"{wf_name}.py"
        # Verify resolved path stays within workflows/ directory (traversal guard)
        try:
            script.resolve().relative_to(workflows_dir)
        except ValueError:
            print(f"Invalid workflow name: {wf_name!r}")
            sys.exit(1)
        if script.exists():
            import subprocess
            result = subprocess.run([sys.executable, str(script)], cwd=str(Path(__file__).parent))
            sys.exit(result.returncode)
        print(f"Unknown workflow: {wf_name}")
        print(f"Available: {', '.join(sorted(registries.keys()))}")
        sys.exit(1)

    print(f"[AIBrain] Running {cls.display_name}...")
    wf = cls(db_path)
    result = wf.run()
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
