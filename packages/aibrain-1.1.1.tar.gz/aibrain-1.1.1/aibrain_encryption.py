#!/usr/bin/env python3
"""
aibrain_encryption.py — Application-level field encryption for AIBrain DB.

Encrypts sensitive fields (content, tags) at rest using Fernet (AES-128-CBC + HMAC).
Key is derived from a user password via PBKDF2 with 480,000 iterations.

Usage:
    python aibrain_encryption.py enable          # Set password & encrypt existing data
    python aibrain_encryption.py disable         # Decrypt all data & remove encryption
    python aibrain_encryption.py status          # Check encryption status
    python aibrain_encryption.py rotate          # Rotate encryption key (new password)

Opt-in: encryption is off by default. Enable via CLI or config.
"""
import base64
import json
import os
import sqlite3
import sys
from pathlib import Path

# Encrypted fields are prefixed with this marker so we can tell encrypted from plain
ENC_PREFIX = "enc:v1:"

# Fields that get encrypted
ENCRYPTED_FIELDS = ("content", "tags")


def _get_fernet(password: str, salt: bytes):
    """Derive a Fernet key from password + salt."""
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    from cryptography.hazmat.primitives import hashes
    from cryptography.fernet import Fernet

    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=480_000,
    )
    key = base64.urlsafe_b64encode(kdf.derive(password.encode()))
    return Fernet(key)


def _salt_path() -> Path:
    """Where to store the encryption salt (next to DB)."""
    from aibrain_db import AIBRAIN_ROOT
    return AIBRAIN_ROOT / ".encryption_salt"


def _load_salt() -> bytes:
    """Load existing salt or raise if not found."""
    sp = _salt_path()
    if not sp.exists():
        raise FileNotFoundError("No encryption salt found — encryption not enabled")
    return sp.read_bytes()


def _create_salt() -> bytes:
    """Generate and save a new random salt."""
    salt = os.urandom(16)
    sp = _salt_path()
    sp.write_bytes(salt)
    return salt


def get_encryptor(password: str = None):
    """Get the Fernet encryptor using password from env or argument.

    Password source priority:
    1. Explicit argument
    2. AIBRAIN_DB_PASSWORD env var
    3. None (encryption disabled)
    """
    pw = password or os.environ.get("AIBRAIN_DB_PASSWORD")
    if not pw:
        return None
    try:
        salt = _load_salt()
    except FileNotFoundError:
        # CRITICAL: password is set but salt is missing — fail loud
        print("WARNING: AIBRAIN_DB_PASSWORD is set but encryption salt file not found!",
              file=sys.stderr)
        print(f"  Expected at: {_salt_path()}", file=sys.stderr)
        print("  Data will be read/written WITHOUT encryption.", file=sys.stderr)
        print("  To fix: run 'python aibrain_encryption.py enable' or unset AIBRAIN_DB_PASSWORD",
              file=sys.stderr)
        return None
    return _get_fernet(pw, salt)


def encrypt_field(value: str, fernet) -> str:
    """Encrypt a string field. Returns prefixed ciphertext."""
    if not value or not fernet:
        return value
    if value.startswith(ENC_PREFIX):
        return value  # already encrypted
    encrypted = fernet.encrypt(value.encode()).decode()
    return f"{ENC_PREFIX}{encrypted}"


def decrypt_field(value: str, fernet) -> str:
    """Decrypt a field. Returns plaintext. Passes through unencrypted values."""
    if not value or not fernet:
        return value
    if not value.startswith(ENC_PREFIX):
        return value  # not encrypted, return as-is
    try:
        ciphertext = value[len(ENC_PREFIX):]
        return fernet.decrypt(ciphertext.encode()).decode()
    except Exception:
        return value  # decryption failed, return raw


def is_encrypted(value: str) -> bool:
    """Check if a field value is encrypted."""
    return bool(value and value.startswith(ENC_PREFIX))


def encryption_status() -> dict:
    """Check current encryption status."""
    from aibrain_db import get_db
    salt_exists = _salt_path().exists()
    has_password = bool(os.environ.get("AIBRAIN_DB_PASSWORD"))

    # Check if any records are encrypted
    db = get_db()
    total = db.execute("SELECT COUNT(*) FROM memories WHERE active=1").fetchone()[0]
    encrypted = db.execute(
        "SELECT COUNT(*) FROM memories WHERE active=1 AND content LIKE ?",
        (f"{ENC_PREFIX}%",)
    ).fetchone()[0]

    return {
        "enabled": salt_exists and has_password,
        "salt_exists": salt_exists,
        "password_set": has_password,
        "total_memories": total,
        "encrypted_memories": encrypted,
        "unencrypted_memories": total - encrypted,
        "percent_encrypted": round(encrypted / total * 100, 1) if total else 0,
    }


def enable_encryption(password: str) -> dict:
    """Enable encryption: create salt, encrypt all existing content and tags."""
    from aibrain_db import get_db

    # Create salt (or reuse if already exists)
    try:
        salt = _load_salt()
        print("  Using existing encryption salt")
    except FileNotFoundError:
        salt = _create_salt()
        print("  Generated new encryption salt")

    fernet = _get_fernet(password, salt)
    db = get_db()

    # Safety check: verify roundtrip on a sample before bulk encrypt
    sample = db.execute(
        "SELECT id, content FROM memories WHERE active=1 AND content NOT LIKE ? LIMIT 1",
        (f"{ENC_PREFIX}%",)
    ).fetchone()
    if sample:
        test_content = sample["content"]
        encrypted = encrypt_field(test_content, fernet)
        decrypted = decrypt_field(encrypted, fernet)
        if decrypted != test_content:
            raise RuntimeError(
                "SAFETY ABORT: encrypt→decrypt roundtrip failed on sample record. "
                "No data was modified. Check your password and try again."
            )
        print("  Roundtrip verification passed")

    # Encrypt all unencrypted content and tags
    rows = db.execute(
        "SELECT id, content, tags FROM memories WHERE active=1 AND content NOT LIKE ?",
        (f"{ENC_PREFIX}%",)
    ).fetchall()

    encrypted = 0
    for row in rows:
        mid, content, tags = row["id"], row["content"], row["tags"]
        enc_content = encrypt_field(content, fernet) if content else content
        enc_tags = encrypt_field(tags, fernet) if tags else tags
        db.execute(
            "UPDATE memories SET content=?, tags=? WHERE id=?",
            (enc_content, enc_tags, mid)
        )
        encrypted += 1
        if encrypted % 500 == 0:
            db.commit()
            print(f"  Encrypted {encrypted} memories...")

    db.commit()
    print(f"  Encrypted {encrypted} memories total")

    # Also encrypt satellite DBs
    sat_encrypted = _encrypt_satellites(password, salt)

    return {"encrypted": encrypted, "satellite_encrypted": sat_encrypted}


def disable_encryption(password: str) -> dict:
    """Disable encryption: decrypt all data and remove salt."""
    from aibrain_db import get_db

    salt = _load_salt()
    fernet = _get_fernet(password, salt)
    db = get_db()

    rows = db.execute(
        "SELECT id, content, tags FROM memories WHERE active=1 AND content LIKE ?",
        (f"{ENC_PREFIX}%",)
    ).fetchall()

    decrypted = 0
    for row in rows:
        mid, content, tags = row["id"], row["content"], row["tags"]
        dec_content = decrypt_field(content, fernet)
        dec_tags = decrypt_field(tags, fernet)
        db.execute(
            "UPDATE memories SET content=?, tags=? WHERE id=?",
            (dec_content, dec_tags, mid)
        )
        decrypted += 1
        if decrypted % 500 == 0:
            db.commit()
            print(f"  Decrypted {decrypted} memories...")

    db.commit()

    # Also decrypt satellites
    sat_decrypted = _decrypt_satellites(password, salt)

    # Remove salt file
    _salt_path().unlink(missing_ok=True)
    print(f"  Decrypted {decrypted} memories, removed encryption salt")

    return {"decrypted": decrypted, "satellite_decrypted": sat_decrypted}


def rotate_key(old_password: str, new_password: str) -> dict:
    """Rotate encryption key: decrypt with old, re-encrypt with new."""
    from aibrain_db import get_db

    old_salt = _load_salt()
    old_fernet = _get_fernet(old_password, old_salt)

    # Create new salt
    new_salt = _create_salt()
    new_fernet = _get_fernet(new_password, new_salt)

    db = get_db()
    rows = db.execute(
        "SELECT id, content, tags FROM memories WHERE active=1 AND content LIKE ?",
        (f"{ENC_PREFIX}%",)
    ).fetchall()

    rotated = 0
    for row in rows:
        mid, content, tags = row["id"], row["content"], row["tags"]
        # Decrypt with old key
        dec_content = decrypt_field(content, old_fernet)
        dec_tags = decrypt_field(tags, old_fernet)
        # Re-encrypt with new key
        enc_content = encrypt_field(dec_content, new_fernet)
        enc_tags = encrypt_field(dec_tags, new_fernet)
        db.execute(
            "UPDATE memories SET content=?, tags=? WHERE id=?",
            (enc_content, enc_tags, mid)
        )
        rotated += 1

    db.commit()
    print(f"  Rotated encryption key for {rotated} main memories")

    # Rotate satellite DBs too
    sat_rotated = _rotate_satellites(old_password, old_salt, new_password, new_salt)

    return {"rotated": rotated, "satellite_rotated": sat_rotated}


def _rotate_satellites(old_password: str, old_salt: bytes,
                       new_password: str, new_salt: bytes) -> int:
    """Rotate encryption key on all satellite DBs."""
    from aibrain_db import satellite_list, _get_satellite_db
    old_fernet = _get_fernet(old_password, old_salt)
    new_fernet = _get_fernet(new_password, new_salt)
    total = 0
    for sat in satellite_list():
        try:
            db = _get_satellite_db(sat["name"])
            rows = db.execute(
                "SELECT id, content, tags FROM memories WHERE active=1 AND content LIKE ?",
                (f"{ENC_PREFIX}%",)
            ).fetchall()
            for row in rows:
                mid = row["id"]
                dec_content = decrypt_field(row["content"], old_fernet)
                dec_tags = decrypt_field(row["tags"], old_fernet)
                enc_content = encrypt_field(dec_content, new_fernet)
                enc_tags = encrypt_field(dec_tags, new_fernet)
                db.execute("UPDATE memories SET content=?, tags=? WHERE id=?",
                           (enc_content, enc_tags, mid))
                total += 1
            db.commit()
        except Exception as e:
            print(f"  Warning: could not rotate satellite {sat['name']}: {e}")
    return total


def _encrypt_satellites(password: str, salt: bytes) -> int:
    """Encrypt all satellite DBs."""
    from aibrain_db import satellite_list, _get_satellite_db
    fernet = _get_fernet(password, salt)
    total = 0
    for sat in satellite_list():
        try:
            db = _get_satellite_db(sat["name"])
            rows = db.execute(
                "SELECT id, content, tags FROM memories WHERE active=1 AND content NOT LIKE ?",
                (f"{ENC_PREFIX}%",)
            ).fetchall()
            for row in rows:
                mid = row["id"]
                enc_content = encrypt_field(row["content"], fernet) if row["content"] else row["content"]
                enc_tags = encrypt_field(row["tags"], fernet) if row["tags"] else row["tags"]
                db.execute("UPDATE memories SET content=?, tags=? WHERE id=?", (enc_content, enc_tags, mid))
                total += 1
            db.commit()
        except Exception as e:
            print(f"  Warning: could not encrypt satellite {sat['name']}: {e}")
    return total


def _decrypt_satellites(password: str, salt: bytes) -> int:
    """Decrypt all satellite DBs."""
    from aibrain_db import satellite_list, _get_satellite_db
    fernet = _get_fernet(password, salt)
    total = 0
    for sat in satellite_list():
        try:
            db = _get_satellite_db(sat["name"])
            rows = db.execute(
                "SELECT id, content, tags FROM memories WHERE active=1 AND content LIKE ?",
                (f"{ENC_PREFIX}%",)
            ).fetchall()
            for row in rows:
                mid = row["id"]
                dec_content = decrypt_field(row["content"], fernet)
                dec_tags = decrypt_field(row["tags"], fernet)
                db.execute("UPDATE memories SET content=?, tags=? WHERE id=?", (dec_content, dec_tags, mid))
                total += 1
            db.commit()
        except Exception as e:
            print(f"  Warning: could not decrypt satellite {sat['name']}: {e}")
    return total


# ---------------------------------------------------------------------------
# Transparent read/write hooks for aibrain_db
# ---------------------------------------------------------------------------
_cached_fernet = None
_fernet_loaded = False


def auto_fernet():
    """Get Fernet from env, cached. Returns None if encryption not configured."""
    global _cached_fernet, _fernet_loaded
    if _fernet_loaded:
        return _cached_fernet
    _fernet_loaded = True
    _cached_fernet = get_encryptor()
    return _cached_fernet


def encrypt_on_write(content: str, tags: str) -> tuple:
    """Encrypt fields before DB write if encryption is enabled."""
    f = auto_fernet()
    if not f:
        return content, tags
    return encrypt_field(content, f), encrypt_field(tags, f)


def decrypt_on_read(content: str, tags: str) -> tuple:
    """Decrypt fields after DB read if encryption is enabled."""
    f = auto_fernet()
    if not f:
        return content, tags
    return decrypt_field(content, f), decrypt_field(tags, f)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def main():
    if len(sys.argv) < 2:
        print("Usage: python aibrain_encryption.py <enable|disable|status|rotate>")
        return

    cmd = sys.argv[1]

    if cmd == "status":
        s = encryption_status()
        print(f"  Encryption enabled: {s['enabled']}")
        print(f"  Salt file exists:   {s['salt_exists']}")
        print(f"  Password in env:    {s['password_set']}")
        print(f"  Total memories:     {s['total_memories']}")
        print(f"  Encrypted:          {s['encrypted_memories']} ({s['percent_encrypted']}%)")
        print(f"  Unencrypted:        {s['unencrypted_memories']}")

    elif cmd == "enable":
        pw = os.environ.get("AIBRAIN_DB_PASSWORD")
        if not pw:
            print("  Set AIBRAIN_DB_PASSWORD env var first")
            print("  Example: export AIBRAIN_DB_PASSWORD='your-strong-password'")
            return
        print("  Enabling encryption...")
        stats = enable_encryption(pw)
        print(f"  Done! {stats['encrypted']} main + {stats['satellite_encrypted']} satellite records encrypted")
        print("  IMPORTANT: Keep AIBRAIN_DB_PASSWORD set in your environment")

    elif cmd == "disable":
        pw = os.environ.get("AIBRAIN_DB_PASSWORD")
        if not pw:
            print("  Set AIBRAIN_DB_PASSWORD to your current password to decrypt")
            return
        print("  Disabling encryption...")
        stats = disable_encryption(pw)
        print(f"  Done! {stats['decrypted']} main + {stats['satellite_decrypted']} satellite records decrypted")

    elif cmd == "rotate":
        old_pw = os.environ.get("AIBRAIN_DB_PASSWORD")
        new_pw = os.environ.get("AIBRAIN_DB_NEW_PASSWORD")
        if not old_pw or not new_pw:
            print("  Set both AIBRAIN_DB_PASSWORD (old) and AIBRAIN_DB_NEW_PASSWORD (new)")
            return
        print("  Rotating encryption key...")
        stats = rotate_key(old_pw, new_pw)
        print(f"  Done! Rotated {stats['rotated']} records")
        print("  Update AIBRAIN_DB_PASSWORD to the new password")

    else:
        print(f"  Unknown command: {cmd}")


if __name__ == "__main__":
    main()
