# validation-and-gates Specification

## Purpose
TBD - created by archiving change build-best-in-class-generator-core. Update Purpose after archive.
## Requirements
### Requirement: Publish proves deterministic runtime publication

Foundational publication MUST prove that identical inputs produce the same materialized runtime
tree.

#### Scenario: Repeated publish yields the same tree revision
- **WHEN** the same foundational family is published twice with the same sources and patches
- **THEN** the materialized publication tree revision is identical

### Requirement: Publish fails on missing semantic completeness

Foundational publication MUST fail when the runtime contract is semantically incomplete.

#### Scenario: Missing system-control coverage blocks publish
- **WHEN** a foundational family lacks required runtime interrupt, reset, clock, or power facts
- **THEN** publish fails

#### Scenario: Missing capability coverage blocks publish
- **WHEN** a runtime-supported foundational peripheral lacks formal capability coverage
- **THEN** publish fails

### Requirement: Consumer verification compiles the semantic moat

Consumer verification MUST compile the new runtime semantic layers directly.

#### Scenario: Consumer smoke covers system-control and capability contracts
- **WHEN** consumer verification runs for a foundational device
- **THEN** it compiles the typed runtime contracts for system-control and capability surfaces
- **AND** it does not substitute handwritten assumptions for those contracts

### Requirement: Validation SHALL Ban Semantic Strings In Runtime C++ Headers

Validation SHALL fail when a runtime-consumed generated C++ header exposes a semantic string
field.

#### Scenario: Runtime header still exposes textual schema or signal information
- **WHEN** validation detects fields such as `const char* schema_id`, `const char* signal`,
  `const char* kind`, `const char* package_name`, or similar semantic labels in a runtime
  header
- **THEN** validation fails
- **AND** publication is blocked

### Requirement: Foundational Publication SHALL Require Zero-String Runtime Headers

Foundational families SHALL not publish unless every runtime-consumed generated C++ artifact
obeys the zero-string rule.

#### Scenario: Foundational family still leaks semantic labels into C++
- **WHEN** a foundational family emits a runtime-facing C++ artifact with semantic strings
- **THEN** publish fails for that family
- **AND** no artifact publication record is materialized

### Requirement: Foundational Publish SHALL Fail Without Runtime-Lite Coverage

Foundational family publication SHALL fail when runtime-lite artifacts do not provide the data
needed for foundational runtime-owned drivers.

#### Scenario: Missing runtime-lite route lowering blocks publication

- **WHEN** a foundational family lacks runtime-lite route data for a published UART or GPIO path
- **THEN** the publish stage fails before publication

### Requirement: Foundational Publish SHALL Fail When Runtime-Lite Depends On Reflection Lookup

Foundational family publication SHALL fail when the emitted runtime-lite contract still requires
reflection-style family table lookup as the normal runtime usage model.

#### Scenario: Family emits only reflective connector graph

- **WHEN** the generated output exposes only reflection connector tables for a foundational
  runtime-owned use case
- **THEN** validation marks the runtime-lite contract incomplete
- **AND** publication is blocked

### Requirement: Publication fails when capability manifest is incomplete for runtime peripherals

Foundational publication MUST fail when a runtime-supported peripheral is present in the
device IR but has no capability facts documented in the manifest.

#### Scenario: Missing capability entry blocks publish for known peripheral class

- **WHEN** a foundational device has a peripheral of class `uart`, `spi`, `i2c`, `adc`,
  `dma`, `timer`, or `pwm` in its canonical IR
- **THEN** publish fails if that peripheral has zero `CapabilityDescriptor` entries
- **AND** the failure message names the peripheral and the required minimum capability IDs

#### Scenario: Capability manifest completeness is a CI gate, not a warning

- **WHEN** the quality CI workflow runs for a foundational family
- **THEN** a missing or empty `capabilities.json` fails the workflow
- **AND** an incomplete capability entry (e.g., `kMaxBaudRate` absent for a UART)
  emits a warning but does not block publish at initial rollout

### Requirement: Consumer verification compiles and links the full generated artifact set

Consumer verification MUST demonstrate that the complete generated artifact set —
linker script, startup, runtime headers, connector tables, clock config, capability
manifest, and interrupt stubs — compiles and links into a valid object file.

#### Scenario: Smoke build links against the generated linker script

- **WHEN** consumer verification runs for a foundational device
- **THEN** it validates or links a smoke object against `generated/devices/<device>/device.ld`
- **AND** the link succeeds with correct section placement (`.text` in flash,
  `.data` load-from-flash, `.bss` zeroed, `__stack_top` defined)

#### Scenario: Smoke build compiles the full runtime header set

- **WHEN** consumer verification runs for a foundational device
- **THEN** it compiles a single translation unit that includes all runtime headers:
  `peripheral_instances.hpp`, `interrupts.hpp`, `clock_graph.hpp`, `connectors.hpp`,
  `clock_config.hpp`, `capabilities.hpp`, and `interrupt_stubs.hpp`
- **AND** it does not require any hand-written header or macro to bridge the gap
  between generated headers

#### Scenario: Smoke build includes at least one capability `static_assert`

- **WHEN** consumer verification runs for a foundational device
- **THEN** the smoke translation unit contains at least one
  `static_assert(alloy::<device>::<peripheral>::kHas<Feature>)` check
- **AND** that assertion passes for all currently published devices

### Requirement: Cross-vendor capability parity is machine-checkable

The pipeline MUST be able to compare capability manifests across two devices and report
structural differences, enabling portability analysis and cross-vendor regression detection.

#### Scenario: `alloy diff` reports capability delta between two devices

- **WHEN** the `alloy diff --from <device1> --to <device2>` command runs for two
  devices with the same peripheral class
- **THEN** it outputs a table of capability changes: added, removed, and modified
  capability entries
- **AND** the output cites the patch or SVD source for each changed entry

#### Scenario: CI detects capability regression across publications

- **WHEN** a new publication for a previously admitted device has fewer capability
  entries than the prior publication
- **THEN** the CI workflow reports a capability regression and fails
- **AND** it identifies which capability IDs were removed and which device is affected

### Requirement: Expanded peripheral coverage follows the same validation standard

New peripheral families MUST not bypass the generator's semantic and validation moat.

#### Scenario: New runtime peripheral families require capability and verification coverage
- **WHEN** a new runtime peripheral family is added
- **THEN** publication requires formal capability coverage and consumer verification coverage
- **AND** the family is not considered complete with schema-only or parser-only support

### Requirement: Publication SHALL Require Fully Typed Foundational Runtime Schemas

Publication SHALL fail for a foundational family when any runtime-owned backend schema still
depends on string parsing or handwritten register-field knowledge in Alloy.

#### Scenario: Foundational family remains partially textual
- **WHEN** validation detects that a foundational runtime-owned schema lacks typed field
  descriptors or executable typed operation targets
- **THEN** the family fails validation
- **AND** publication is blocked

### Requirement: Validation SHALL Verify Typed Binding Completeness

Validation SHALL verify that interrupt, DMA, clock, reset, selector, register, and field
bindings are complete and internally consistent for foundational families.

#### Scenario: Peripheral binding is incomplete
- **WHEN** a foundational peripheral instance is missing a required typed binding or field
  descriptor for its runtime schema
- **THEN** validation reports the missing domain as an error
- **AND** the family is not publishable

### Requirement: No String Glue in Foundational Runtime Headers
Validation SHALL fail for a foundational family when its runtime-facing headers still depend on
CSV payloads or textual signal fields as primary executable contract.

#### Scenario: Foundational family still emits CSV payload
- **WHEN** a foundational family emits CSV capability or interrupt payloads in a primary
  runtime struct
- **THEN** validation fails
- **AND** publish is blocked

### Requirement: No Text Parsing Required for Runtime Route Execution
Validation SHALL fail when a foundational route requirement or route operation still requires
text parsing to determine target or value semantics.

#### Scenario: Route operation only identifies its target textually
- **WHEN** a route operation lacks sufficient typed ids or typed refs
- **THEN** validation fails
- **AND** the family is not publishable

### Requirement: Admitted families SHALL pass a GPIO-semantic coverage gate

Every admitted MCU family SHALL emit a `driver_semantics/gpio.hpp` that
contains at least one `GpioSemanticTraits<PinId::...>` specialization with
`kPresent = true` once this change is applied to the family in question.
A repository-level CI gate SHALL fail PRs that admit a new family without
populated GPIO semantics, or that regress an existing family back to a
zero-specialization state.

The gate is rolled out per-family alongside the implementation phase that
populates that family. The gate becomes mandatory for every admitted family
once the final implementation phase lands. **As of `complete-rp2040-semantics`
Phase A, the gate is mandatory for RP2040 — the previous `xfail` marker
on the RP2040 case is removed and the family is expected to emit at
least one populated `GpioSemanticTraits` specialization.**

#### Scenario: GPIO coverage gate accepts a populated family

- **WHEN** a family that has been wired through the GPIO-semantic emitter
  emits its `gpio.hpp`
- **THEN** the file contains at least one specialization where
  `kPresent = true`
- **AND** the coverage gate passes for that family

#### Scenario: GPIO coverage gate blocks a regression

- **WHEN** a family that previously emitted populated `GpioSemanticTraits`
  specializations is changed in a way that drops all specializations
- **THEN** the coverage gate flags the family as regressed and the CI job
  fails

#### Scenario: RP2040 is included in the mandatory gate

- **WHEN** `tests/test_gpio_semantic_coverage.py` runs
- **THEN** the rp2040 device emits at least one `GpioSemanticTraits`
  specialization with `kPresent = true`
- **AND** the test does NOT carry an `xfail` marker for RP2040

### Requirement: I2C-bearing families MUST pass the I2C semantic coverage gate

I2C-bearing admitted families MUST emit at least one populated `I2cPeripheralTraits` specialization. Every admitted MCU family that ships at least one I2C / TWI controller in its admitted device set is covered by this gate; the gate fails the build when a family has zero `kPresent = true` specializations on its emitted `driver_semantics/i2c.hpp`.

The gate is rolled out per-family alongside the implementation phase
that populates that family.

#### Scenario: I2C coverage gate accepts a populated family

- **WHEN** a family that has been wired through the I2C-semantic
  emitter emits its `i2c.hpp`
- **THEN** the file contains at least one specialization where
  `kPresent = true`
- **AND** the coverage gate passes for that family

#### Scenario: I2C coverage gate ignores devices without I2C hardware

- **WHEN** an admitted family has no I2C / TWI controller on any
  device in its registered device list
- **THEN** the I2C coverage gate is treated as N/A for that family
  (it neither passes nor fails — the assertion does not run)

### Requirement: PWM-bearing families MUST pass the PWM semantic coverage gate

Every admitted MCU family that ships at least one PWM-capable peripheral MUST emit a `driver_semantics/pwm.hpp` containing at least one populated specialization of one of the family-shaped trait templates (`StmTimerPwmTraits`, `FlexPwmTraits`, `McpwmTraits`, `LedcTraits`, `AvrDaTcaPwmTraits`, `Same70PwmTraits`, or the existing `Rp2040PwmSliceHwTraits`). A repository-level CI gate MUST fail PRs that admit a new PWM-bearing family without populated traits, or that regress an existing family back to a zero-specialization state.

The gate is rolled out per-family alongside the implementation phase that populates that family. The gate becomes mandatory for every admitted family once Phase F (the final phase) lands.

#### Scenario: PWM coverage gate accepts a populated family

- **WHEN** a family that has been wired through the PWM-semantic emitter (any of the six family-shape templates) emits its `pwm.hpp`
- **THEN** the file contains at least one specialization where `kPresent = true`
- **AND** the coverage gate passes for that family

#### Scenario: PWM coverage gate flags a regression

- **WHEN** a family that previously emitted populated PWM specializations is changed in a way that drops all of them
- **THEN** the coverage gate flags the family as regressed and the CI job fails

#### Scenario: ESP32-C3 satisfies the gate via LEDC alone

- **WHEN** the ESP32-C3 device is emitted
- **THEN** `LedcTraits<RuntimeLedcId::LEDC>::kPresent` is `true`
- **AND** the gate passes for ESP32-C3 even though `McpwmTraits` carries no specializations on that variant

### Requirement: Test goldens MUST be regeneratable through an opt-in flag

The test harness SHALL support an opt-in mode that rewrites
golden fixtures from the current pipeline output instead of
asserting equality.  The mode SHALL be activated either by
setting the `ALLOY_UPDATE_GOLDENS=1` environment variable or by
passing the `--update-goldens` flag to pytest.  When the flag is
**not** set (the default, including CI), every golden assertion
SHALL still fail the build on mismatch — the flag MUST NOT relax
the default contract.  When the flag IS set, the harness SHALL
refuse to run if `git status` reports dirty non-fixture files,
to prevent accidental source changes from being baked into
goldens.

#### Scenario: Default mode fails on golden mismatch

- **WHEN** `pytest` is run without the update flag
- **AND** an emitted artifact differs from its golden fixture
- **THEN** the test SHALL fail with the existing equality
  assertion message — behaviour unchanged from today

#### Scenario: Update mode rewrites goldens to match pipeline output

- **WHEN** `ALLOY_UPDATE_GOLDENS=1 pytest` is run
- **AND** the working tree has no dirty non-fixture files
- **THEN** every golden-mismatch assertion SHALL instead write
  the new content to the fixture path
- **AND** the resulting `git diff` SHALL be limited to
  `tests/fixtures/` paths so the change is reviewable

#### Scenario: Update mode aborts when source files are dirty

- **WHEN** `ALLOY_UPDATE_GOLDENS=1 pytest` is run
- **AND** `git status --porcelain` reports modified files outside
  `tests/fixtures/`
- **THEN** the harness SHALL abort with an error explaining that
  source changes must be committed first to prevent baking them
  into goldens silently

### Requirement: Emitted runtime C++ headers MUST pass a freestanding smoke compile in CI

CI SHALL run a smoke-compile step over every device the pipeline
admits.  The step SHALL compile a per-device `smoke.cpp` that
includes the device's runtime headers and exercises at least one
`static_assert` per typed C++20 concept the headers declare
(e.g. `ValidPinAssignment<Pin, PeripheralSignal::...>`) using
`clang++ -std=c++20 -ffreestanding -nostdlib -c`.  The step SHALL
fail the build on any compile error, with a failure message that
identifies the device, the offending header, and the compiler
stderr.  Locally, the gate SHALL be skipped (not failed) when
`clang++` is not on PATH so contributors without a clang
toolchain are not blocked from running unrelated tests.

#### Scenario: Every admitted device passes a freestanding smoke compile

- **WHEN** CI runs `pytest --runtime-cpp-smoke -q`
- **THEN** every admitted device SHALL produce a per-device
  `smoke.cpp` that compiles cleanly with
  `clang++ -std=c++20 -ffreestanding -nostdlib -c`
- **AND** the smoke `.cpp` SHALL include every runtime header the
  pipeline emitted for that device

#### Scenario: A regression in template metaprogramming fails the gate

- **WHEN** an emitter change introduces a malformed
  specialization or a missing include
- **AND** the smoke compile is run
- **THEN** the gate SHALL fail with a message identifying the
  device, the header, and the compiler stderr — sufficient
  context for the reviewer to fix without reproducing locally

#### Scenario: Local pytest is not blocked when clang is absent

- **WHEN** a contributor runs `pytest -q` locally and `clang++`
  is not on PATH
- **THEN** smoke-compile tests SHALL be skipped (not failed)
- **AND** the rest of the test suite SHALL run normally

### Requirement: Emitted artifacts MUST stay within declared per-class footprint budgets

The publish stage SHALL measure every emitted artifact's UTF-8
byte size and compare it against a budget declared in
`data/artifact_footprint_budget.toml`.  Each artifact name SHALL
have a `warn` budget (surfaced in the validation report on
exceedance) and a `fail` budget (aborts the build on exceedance).
A per-device override file
`data/artifact_footprint_overrides.toml` SHALL allow opting a
specific `(vendor, family, device, artifact_name)` tuple into a
larger budget without relaxing the global default.  Default
budgets SHALL be set from the largest currently admitted output
plus 50% headroom so the gate is non-disruptive on day one.

#### Scenario: No currently admitted device exceeds its warn budget on day one

- **WHEN** the gate is evaluated against every device the
  pipeline currently admits
- **THEN** zero artifacts SHALL exceed their `warn` budget
- **AND** the validation report SHALL contain no
  footprint warnings

#### Scenario: An oversized artifact aborts the build

- **WHEN** an emitter regression produces an artifact larger than
  its declared `fail` budget
- **AND** no override entry covers the offending device
- **THEN** the publish stage SHALL fail the build with a message
  identifying the artifact path, the actual size, the budget, and
  the override file path so a reviewer knows exactly how to
  proceed

#### Scenario: A per-device override permits a known-large artifact

- **WHEN** an entry in `data/artifact_footprint_overrides.toml`
  covers `(vendor=nxp, family=imxrt1060, device=mimxrt1062,
  artifact=pin_validation.hpp)` with a budget higher than the
  default
- **AND** the artifact's actual size sits within the override
  budget
- **THEN** the gate SHALL pass for that device
- **AND** the override SHALL NOT relax the budget for any other
  device sharing the same artifact name

### Requirement: Emitter modules SHALL stay under a maintainability size cap

No single emitter Python module SHALL exceed 5.000 lines of
code (LOC).  When a module crosses the threshold, the
contributor SHALL split it into a sub-package along the
natural boundary — per peripheral class, per artifact
category, or per vendor adapter family — whichever fits
the module's responsibility surface.  The rationale is to
prevent the change-blast-radius problems that monolithic
files create (any modification potentially touches dozens of
unrelated builders), to keep IDE navigation responsive, and
to localise type-checker and lint noise.  The cap is a
forcing function against future drift back into a monolith.

#### Scenario: CI rejects an oversized emitter module

- **WHEN** a contributor submits a PR that pushes any file
  under `src/alloy_codegen/runtime_*` or
  `src/alloy_codegen/runtime_driver/` past 5.000 LOC
- **THEN** CI SHALL fail with a message naming the
  offending file, its LOC count, and the suggested split
  boundary
- **AND** the PR SHALL be unmergeable until the file is
  split

#### Scenario: Refactor of runtime_driver_semantics.py validates the rule

- **WHEN** the `refactor-runtime-driver-semantics-per-class`
  change ships
- **THEN** `runtime_driver_semantics.py` SHALL shrink to a
  re-export shim around 50 lines and 17 per-class modules
  SHALL exist under `src/alloy_codegen/runtime_driver/`
- **AND** every emitted artifact SHALL be byte-identical to
  the pre-refactor output (golden-byte-stability gate)

### Requirement: Refactor changes SHALL preserve byte-stability of all emitted artifacts

Refactor changes SHALL pass a golden-byte-stability gate when
they are tagged in OpenSpec as a `refactor-*` (no intentional
behaviour change).  Every emitted artifact — every `.hpp`, `.cpp`, `.json`,
`.cmake`, and `.ld` file under `tests/fixtures/emitted/` —
SHALL match byte-for-byte before and after the refactor.  The
gate SHALL apply to all admitted devices, not just the ones
with golden fixtures today.  Devices without golden fixtures
SHALL get them generated as part of the refactor's CI prep,
so the byte-stability check covers the full admitted set
once the refactor lands.

#### Scenario: Byte-drift detection on a refactor PR

- **WHEN** a contributor submits a `refactor-*` PR that
  inadvertently introduces whitespace drift in one emitted
  header
- **THEN** the byte-stability gate SHALL flag the affected
  device + artifact
- **AND** CI SHALL block the merge with a diff snippet
  showing exactly which bytes drifted
- **AND** the contributor SHALL either fix the regression or
  re-tag the change as a non-refactor (which then requires
  a proposal explaining the behaviour change)

