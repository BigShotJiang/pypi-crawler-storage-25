# codegen-alloy-boundary Specification

## Purpose
TBD - created by archiving change eliminate-runtime-strings-from-cpp-contract. Update Purpose after archive.
## Requirements
### Requirement: Alloy Boundary SHALL Depend On Typed Runtime C++ Only

The contract between `alloy-devices` and Alloy SHALL allow the runtime to execute entirely
from typed generated C++ descriptors.

#### Scenario: Alloy backend executes a schema without string glue
- **WHEN** Alloy resolves pins, routes, clocks, resets, interrupts, DMA, memories, startup
  actions, or register-field operations
- **THEN** it can do so using generated typed C++ ids and refs alone
- **AND** no string comparison, string parsing, or handwritten semantic lookup is required

### Requirement: Human Labels SHALL Live Outside The Runtime C++ Boundary

Human-readable labels SHALL not be part of the runtime C++ boundary between `alloy-devices`
and Alloy.

#### Scenario: Developer wants diagnostics or inspection data
- **WHEN** generated artifacts need human-readable labels
- **THEN** those labels are published in JSON metadata or reports
- **AND** the runtime C++ contract remains fully typed

### Requirement: Alloy Runtime SHALL Target Runtime-Lite Artifacts

The documented boundary between `alloy-codegen` and `alloy` SHALL state that normal runtime
consumption targets the runtime-lite contract, while reflection artifacts remain available for
tooling, validation, smoke compilation, and debugging.

#### Scenario: Boundary doc describes runtime-lite as the hot-path contract

- **WHEN** the boundary documentation is updated for this change
- **THEN** it explicitly identifies runtime-lite artifacts as the intended hot-path contract for
  `alloy`
- **AND** it identifies reflection artifacts as non-hot-path support products

### Requirement: User-facing configuration layers build on the runtime contract

Any higher-level generator UX or configuration surface MUST build on the same typed runtime device
model used by Alloy.

#### Scenario: Recipes and configurator outputs do not create a second device model
- **WHEN** the generator emits configuration recipes, examples, or configurator outputs
- **THEN** those outputs are derived from the typed runtime contract
- **AND** they do not introduce a parallel handwritten or reflection-only device model

### Requirement: Alloy Boundary SHALL Be Schema-Dispatched and Typed

The generated contract between `alloy-devices` and Alloy SHALL be consumable through backend
schema dispatch and typed descriptor execution, not through vendor or family name inference.

#### Scenario: Alloy adds a new family that reuses an existing schema
- **WHEN** a newly supported family reuses an already published runtime backend schema
- **THEN** Alloy can consume the generated descriptors without adding family-specific parsing
  or handwritten offsets

### Requirement: Generated Contract SHALL Be Sufficient for MMIO Addressing

The generated contract SHALL provide enough typed information for Alloy to resolve runtime
MMIO register and field addressing without handwritten offsets or bit definitions.

#### Scenario: Alloy backend performs a runtime-owned register write
- **WHEN** an Alloy backend needs to write a runtime-owned register field
- **THEN** it can obtain the register base, register offset, field offset, and width from the
  generated descriptors alone
- **AND** it does not need handwritten register or field constants

### Requirement: alloy_codegen SHALL expose a top-level generate(config, out_dir) callable

`alloy_codegen.generate(config, out_dir)` SHALL be the stable
Python entrypoint downstream tools (alloy-cli, future agents,
LSPs) consume.  The function SHALL accept any object exposing
`chip.vendor / chip.family / chip.device` (or, when chip is
``None``, `board.id`), call `load_with_synthesis` to build the
canonical + synthesised IRs, run every registered emitter, and
write the artifacts directly under ``out_dir``.  The return
value SHALL be a sorted ``tuple[Path, ...]`` of the written
files so callers can log them or feed a cache.  Failures SHALL
raise a typed exception (``ConfigError`` for missing /
unresolvable target, ``StageExecutionError`` for parse +
synthesis errors).

#### Scenario: chip-driven config emits the four artifacts

- **WHEN** the caller passes a config with
  `chip.vendor="st"`, `chip.family="stm32g0"`,
  `chip.device="stm32g071rb"` and `out_dir=tmp_path`
- **THEN** ``generate`` SHALL write
  ``peripheral_traits.h``, ``runtime_init.c``,
  ``linker.ld``, and ``vector_table.c`` directly under
  ``tmp_path``
- **AND** the returned tuple SHALL list those four paths in
  sorted order

#### Scenario: board-driven config without resolved chip raises ConfigError

- **WHEN** the config has `chip=None` and
  `board.id="nucleo_g071rb"`
- **THEN** ``generate`` SHALL raise ``ConfigError`` because
  alloy-codegen does NOT host a board catalogue
- **AND** the message SHALL tell the caller to resolve the
  board to a `(vendor, family, device)` triple in their own
  layer before re-invoking

#### Scenario: a config without chip or board raises ConfigError

- **WHEN** the config exposes both `chip=None` and
  `board=None`
- **THEN** ``generate`` SHALL raise
  ``alloy_codegen.errors.ConfigError`` with a message
  naming the missing field

#### Scenario: unknown device raises ConfigError

- **WHEN** the config points at a chip that isn't in
  ``DEVICE_REGISTRY``
- **THEN** ``generate`` SHALL raise ``ConfigError`` listing
  the closest known vendor / family triple

