## Phase 0: Bootstrap & Source Manifests

- [x] 0.1 Add `("espressif", "esp32c3")` to `DEVICE_REGISTRY` and `SOURCE_BUNDLES`
      in `src/alloy_codegen/bootstrap.py`
- [x] 0.2 Create `src/alloy_codegen/sources/esp_idf.py` for Espressif SVD ingestion
- [x] 0.3 Add Espressif fetch branch to `src/alloy_codegen/stages/fetch.py`
- [x] 0.4 Formalize supplementary-source ingestion for `gpio_sig_map.h`:
      source manifest entry, revision pinning, provenance label, and licensing note
- [x] 0.5 Scaffold `patches/espressif/esp32c3/family.json` and
      `patches/espressif/esp32c3/devices/esp32c3.json`
- [x] 0.6 Verify fetch produces a non-empty `RawDeviceDocument` for `esp32c3`

## Phase 1: IR Ingestion — ESP32-C3

- [x] 1.1 Add explicit `riscv` baseline to `SYSTEM_VECTOR_BASELINES`
- [x] 1.2 Remove the fallback-to-`cortex-m4` behavior for unknown cores
- [x] 1.3 Extend `_typed_register_ref` for ESP32-C3 PCR clock/reset references
- [x] 1.4 Populate `patches/espressif/esp32c3/family.json` with memory, clocks, packages,
      DMA, and startup-relevant controls
- [x] 1.5 Populate `patches/espressif/esp32c3/devices/esp32c3.json` with peripheral
      enable/reset/interrupt enrichments
- [x] 1.6 Write normalized golden fixture and regression tests for `esp32c3`

## Phase 2: IO Matrix Routing

- [x] 2.1 Add `alloy.pinmux.espressif-iomatrix-v1` to the known backend schema set
- [x] 2.2 Create supplementary parser for `gpio_sig_map.h`
      (`sources/esp_idf.py::parse_gpio_sig_map()` parses `#define <NAME>_IDX
      <num>` entries into a `{signal_name: index}` mapping.  Vendored a
      minimal `tests/fixtures/esp-idf-gpio-sig-map/esp32c3/gpio_sig_map.h`
      with the signals cited by the ESP32-C3 family patch.  Supplementary
      source id `esp-idf-gpio-sig-map` reserved in
      `sources/esp_idf.py::GPIO_SIG_MAP_SOURCE_ID` for future fetch-manifest
      plumbing.)
- [x] 2.3 Populate pin-signal data for UART, SPI, I2C, ADC bootstrap coverage
- [x] 2.4 Ensure emitted runtime data carries IO Matrix signal-index provenance
      (Every `write-selector` route operation on ESP32-C3 carries
      `schema_id = "alloy.pinmux.espressif-iomatrix-v1"` and a numeric
      `value_int` that IS the IO Matrix index from `gpio_sig_map.h`.  The
      provenance chain is now: upstream header → family-patch `af_number` →
      canonical `RouteOperation.schema_id` + `.value_int` → emitted typed
      runtime artifact.  A regression test
      (`test_esp32c3_family_af_numbers_match_gpio_sig_map_upstream`) flags
      any drift between the patch and upstream.)
- [x] 2.5 Add emitted goldens proving the IO Matrix schema and comments are correct
      (`tests/test_espressif.py::test_esp32c3_runtime_routes_header_encodes_iomatrix_schema`
      asserts the emitted `runtime/devices/esp32c3/routes.hpp` and
      `runtime/types.hpp` encode the IO Matrix schema as
      `BackendSchemaId::schema_alloy_pinmux_espressif_iomatrix_v1`.)

## Phase 3: Runtime Contract — ESP32-C3

- [x] 3.1 Update `artifact_contract.py` so architecture-scoped artifacts are explicit:
      `systick.hpp` required only for Cortex-M; startup validated per architecture
- [x] 3.2 Add `runtime_riscv_startup.py` and wire RISC-V startup emission in `stages/emit.py`
- [x] 3.3 Ensure consumer smoke compiles ESP32-C3 runtime headers without ARM-specific glue
      (`tests/test_espressif.py::test_publish_esp32c3_consumer_smoke_passes`
      runs the end-to-end publish + host `c++` compile of the staged runtime
      headers + RISC-V startup.  The RISC-V `__attribute__((interrupt))` on
      peripheral IRQ handlers is now guarded by `ALLOY_CODEGEN_HOST_SMOKE`
      so the host compiler's `-Werror=unknown-attributes` does not trip.)
- [x] 3.4 Add emitted runtime goldens for `interrupts.hpp`, `clock_graph.hpp`,
      `peripheral_instances.hpp`, and startup output
- [x] 3.5 Add publish/contract tests proving runtime-only completeness for `esp32c3`

## Phase 4: Xtensa Follow-On — ESP32-S3

- [x] 4.1 Add `("espressif", "esp32s3")` to registry/bootstrap
      (`DEVICE_REGISTRY[("espressif", "esp32s3")] = ("esp32s3",)` and the
      matching `SOURCE_BUNDLES` entry reuse the same `espressif-svd`
      source bundle as ESP32-C3.)
- [x] 4.2 Add explicit `xtensa-lx7` vector baseline
      (Already landed in earlier arch-aware work.  Baseline is minimal
      `((0, "Reset_Handler", None, "reset-handler"),)` — the Xtensa ROM
      owns VECBASE so the IR only needs to expose the reset slot plus
      device interrupt slots at 16+.)
- [x] 4.3 Extend Espressif adapter to load `esp32s3`
      (Zero code change: `_build_esp32_device_ir` was already generic
      over `family`, and `esp_idf.resolve_svd_path` reads
      `patch.svd_file` from the device patch.  Scaffolded
      `patches/espressif/esp32s3/family.json` + `devices/esp32s3.json`.)
- [x] 4.4 Document and enforce single-core control-plane perspective for this first cut
      (`_build_esp32_device_ir` now filters out interrupts whose
      peripheral is not in the device-patch allowlist.  On ESP32-S3
      this drops the five `INTERRUPT_CORE1` descendants
      (CORE1_IRAM0_PMS, CORE1_DRAM0_PMS, CORE1_PIF_PMS,
      CORE1_PIF_PMS_SIZE, CACHE_CORE1_ACS), so the emitted canonical IR
      describes the core-0 control plane only.  The
      `test_esp32s3_single_core_perspective_excludes_core1_interrupts`
      regression asserts this.  `family.json` `__source_notes.single_core_perspective`
      documents the choice explicitly.)
- [x] 4.5 Add Xtensa startup emitter branch
      (`runtime_xtensa_startup.py::emit_xtensa_startup_source` — the ROM
      bootloader owns VECBASE and initial stack; our startup just runs
      the BSS/data/ctor/main() sequence after control transfer.  No ARM
      `_vectors[]`, no RISC-V `mtvec`, no AVR `__vector_<N>`.  Weak
      peripheral IRQ stubs default to `Default_Handler`.  Host smoke
      guard keeps the file portable.  Dispatched from `stages/emit.py`
      via `_is_xtensa_device`.)
- [x] 4.6 Add normalized and emitted goldens for `esp32s3`
      (`tests/fixtures/esp32s3/esp32s3.canonical.json` + four emitted
      goldens under `tests/fixtures/emitted/esp32s3/`.)
- [x] 4.7 Add consumer smoke and artifact-contract coverage for `esp32s3`
      (`tests/test_espressif.py` grew by 10 ESP32-S3 tests covering
      canonical fixture match, identity, single-core filtering, typed
      runtime contract, Xtensa startup conventions, systick skip, no
      string glue, IO Matrix schema, emitted goldens, and a full
      end-to-end `run_publish` + consumer smoke compile.)

## Phase 5: CI & Publication Gates

- [x] 5.1 Add `espressif/esp32c3` to the publication matrix
      (`.github/workflows/publish-alloy-devices.yml` matrix now includes
      `vendor: espressif, family: esp32c3`.)
- [x] 5.2 Extend vendor-admission checks to include `espressif`
      (`.github/workflows/bootstrap-family.yml` ADMITTED_VENDORS already
      includes `espressif` — landed in the Phase 0 bootstrap commit.)
- [x] 5.3 Add publish-time completeness checks for non-Cortex runtime-only devices
      (The existing runtime-lite contract gates apply uniformly to every
      admitted family.  RISC-V-specific scoping — `systick.hpp` optional,
      arch-aware vector baseline — landed in Phase 3.1.  Fixed the
      single-device family ip-block reuse rule so RISC-V single-device
      families like esp32c3 are not falsely flagged.)
- [x] 5.4 Run full publication flow for `esp32c3`
      (`test_foundational_families_publish_with_same_generic_workflow` and
      `test_foundational_families_remain_complete_across_repeat_publish_cycles`
      now iterate over ESP32-C3 alongside the other foundational families.)
- [x] 5.5 Add integration coverage for Espressif runtime-only publication
      (Added `espressif_execution_context` to the `_family_contexts` loop in
      `tests/test_foundational_families.py` — ESP32-C3 now receives the same
      emit + publish + artifact-contract gate as every other foundational
      family.)

## Phase 6: Fixtures & Docs

- [x] 6.1 Regenerate all affected fixtures
      (All 229 tests green with zero drift after Phase 4 ESP32-S3 landing.
      Canonical + emitted goldens committed for both esp32c3 and esp32s3.)
- [x] 6.2 Update `openspec/project.md` with Espressif admission, architecture notes,
      and IO Matrix source provenance
      (The "Admitted Foundational Families" table covers both esp32c3 and
      esp32s3 with vendor/family, ISA, memory model, upstream source(s),
      and license.  Dedicated notes document the IO Matrix supplementary
      source for esp32c3 and the single-core-perspective for esp32s3.
      Pinmux backend schema map enumerates `alloy.pinmux.espressif-iomatrix-v1`.)
- [x] 6.3 Add explicit licensing/provenance note for Espressif supplementary sources
      (Apache-2.0 cited in `openspec/project.md` for `espressif/svd` and
      esp-idf `gpio_sig_map.h`.  The vendored
      `tests/fixtures/esp-idf-gpio-sig-map/esp32c3/gpio_sig_map.h`
      preserves the upstream SPDX header verbatim.)
- [x] 6.4 Archive this change
