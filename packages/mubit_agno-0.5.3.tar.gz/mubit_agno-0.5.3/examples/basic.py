"""
MuBit + Agno Basic Example: Agent with Persistent Memory

A simple Agno agent that uses MuBit as its memory backend.
Memories persist across sessions, enabling cross-conversation learning.

Requirements:
    pip install mubit-agno[agno] agno

Environment variables:
    OPENAI_API_KEY   - OpenAI API key (required)
    MUBIT_ENDPOINT   - MuBit server URL (default: http://127.0.0.1:3000)
    MUBIT_API_KEY    - MuBit API key (default: empty for local dev)
"""

import os

from agno.agent import Agent
from agno.models.openai import OpenAIChat
from agno.memory.v2.memory import Memory
from mubit_agno import MubitAgnoMemory


def main():
    endpoint = os.environ.get("MUBIT_ENDPOINT", "http://127.0.0.1:3000")
    api_key = os.environ.get("MUBIT_API_KEY", "")

    mubit = MubitAgnoMemory(
        endpoint=endpoint,
        api_key=api_key,
        session_id="basic-example",
        user_id="demo-user",
    )

    agent = Agent(
        name="Assistant",
        model=OpenAIChat(id="gpt-4o"),
        memory=Memory(db=mubit.as_memory_db()),
        tools=[mubit.as_toolkit()],
        enable_agentic_memory=True,
        instructions=[
            "You have access to MuBit memory tools.",
            "Use mubit_remember to store important information.",
            "Use mubit_recall to search for relevant memories.",
        ],
    )

    # Run 1: Store some knowledge
    print("=== Run 1: Learning ===")
    response = agent.run(
        "Remember that our production database is PostgreSQL 16 "
        "running on AWS RDS in us-east-1, and we use Redis for caching.",
        session_id="session-1",
    )
    print(f"Agent: {response.content}\n")

    # Checkpoint after learning
    mubit.checkpoint("Initial learning", "Stored infrastructure facts")

    # Run 2: Recall knowledge
    print("=== Run 2: Recall ===")
    response = agent.run(
        "What database do we use in production?",
        session_id="session-2",
    )
    print(f"Agent: {response.content}\n")

    # Record success
    mubit.record_outcome(
        "infrastructure-recall",
        "success",
        rationale="Agent correctly recalled database details from memory",
    )

    # Check memory health
    health = mubit.memory_health()
    print(f"Memory health: {health}")


if __name__ == "__main__":
    main()
