"""
Ashr Labs API Client.

This module provides the main client for interacting with the Ashr Labs API.
"""

import copy
import json
import time
from typing import Any
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

from .exceptions import (
    AshrLabsError,
    AuthenticationError,
    AuthorizationError,
    NotFoundError,
    ValidationError,
    RateLimitError,
    ServerError,
)
from .models import Dataset, Run, Request as RequestModel, APIKey, Session, Agent as AgentModel, SdkNote


_DEFAULT_BASE_URL = "https://api.ashr.io/testing-platform-api"


class AshrLabsClient:
    """
    Client for interacting with the Ashr Labs API.

    This client supports all API key accessible endpoints:
    - Datasets: get, list
    - Runs: create, get, list, delete
    - Requests: create, get, list
    - API Keys: list, revoke

    The client automatically resolves your ``tenant_id`` and ``user_id``
    from the API key on first use, so you never need to pass them manually.

    Example:
        ```python
        from ashr_labs import AshrLabsClient

        client = AshrLabsClient(api_key="tp_your_api_key_here")

        # No tenant_id needed — auto-resolved from your API key
        datasets = client.list_datasets()

        # Create a run
        run = client.create_run(
            dataset_id=42,
            result={"score": 0.95, "status": "passed"}
        )
        ```
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: int = 30,
    ):
        """
        Initialize the Ashr Labs client.

        Args:
            api_key: Your Ashr Labs API key (starts with 'tp_').
            base_url: The base URL of the API (default: production URL).
            timeout: Request timeout in seconds (default: 30).

        Raises:
            ValueError: If the API key format is invalid.
        """
        if not api_key or not api_key.startswith("tp_"):
            raise ValueError("Invalid API key format. API keys must start with 'tp_'")

        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

        # Lazy-loaded session context (populated on first call that needs it)
        self._tenant_id: int | None = None
        self._user_id: int | None = None
        self._session: dict | None = None
        self._notes: list[SdkNote] = []

    @classmethod
    def from_env(cls, timeout: int = 30) -> "AshrLabsClient":
        """
        Create a client from environment variables.

        Reads ``ASHR_LABS_API_KEY`` (required) and ``ASHR_LABS_BASE_URL``
        (optional, defaults to production) from the environment.

        Returns:
            An authenticated AshrLabsClient.

        Raises:
            RuntimeError: If ASHR_LABS_API_KEY is not set.
        """
        import os

        api_key = os.environ.get("ASHR_LABS_API_KEY")
        if not api_key:
            raise RuntimeError(
                "ASHR_LABS_API_KEY environment variable is not set. "
                "Create an API key at https://lab.ashr.io → API Keys."
            )
        base_url = os.environ.get("ASHR_LABS_BASE_URL", _DEFAULT_BASE_URL)
        return cls(api_key=api_key, base_url=base_url, timeout=timeout)

    def _ensure_session(self) -> None:
        """Lazily call init() and cache tenant_id / user_id / notes."""
        if self._session is not None:
            return
        self._session = self._make_request("init")
        self._tenant_id = self._session["tenant"]["id"]
        self._user_id = self._session["user"]["id"]
        self._notes = self._session.get("notes", [])

    def _resolve_tenant_id(self, tenant_id: int | None) -> int:
        """Return the explicit tenant_id, or auto-resolve from session."""
        if tenant_id is not None:
            return tenant_id
        self._ensure_session()
        return self._tenant_id  # type: ignore[return-value]

    def _resolve_user_id(self, user_id: int | None) -> int:
        """Return the explicit user_id, or auto-resolve from session."""
        if user_id is not None:
            return user_id
        self._ensure_session()
        return self._user_id  # type: ignore[return-value]

    def _make_request(self, function: str, **params: Any) -> dict:
        """
        Make an authenticated request to the API.

        Args:
            function: The API function to call.
            **params: Additional parameters for the function.

        Returns:
            The JSON response from the API.

        Raises:
            AshrLabsError: If the request fails.
        """
        payload = {"function": function, **params}

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}",
        }

        data = json.dumps(payload).encode("utf-8")
        request = Request(self.base_url, data=data, headers=headers, method="POST")

        try:
            with urlopen(request, timeout=self.timeout) as response:
                response_data = json.loads(response.read().decode("utf-8"))
        except HTTPError as e:
            status_code = e.code
            try:
                error_body = json.loads(e.read().decode("utf-8"))
                message = error_body.get("message", str(e))
            except (json.JSONDecodeError, AttributeError):
                message = str(e)

            self._raise_for_status(status_code, message, error_body if "error_body" in dir() else None)
        except URLError as e:
            raise AshrLabsError(f"Network error: {e.reason}")
        except TimeoutError:
            raise AshrLabsError("Request timed out")

        # Check for API-level errors
        if response_data.get("status") == "error":
            message = response_data.get("message", "Unknown error")
            self._raise_for_status(400, message, response_data)

        return response_data

    def _raise_for_status(
        self, status_code: int, message: str, response: dict | None = None
    ) -> None:
        """Raise the appropriate exception based on status code."""
        if status_code == 401:
            raise AuthenticationError(message, status_code, response)
        elif status_code == 403:
            raise AuthorizationError(message, status_code, response)
        elif status_code == 404:
            raise NotFoundError(message, status_code, response)
        elif status_code == 422:
            raise ValidationError(message, status_code, response)
        elif status_code == 429:
            raise RateLimitError(message, status_code, response)
        elif status_code >= 500:
            raise ServerError(message, status_code, response)
        else:
            raise AshrLabsError(message, status_code, response)

    # =========================================================================
    # Dataset Operations
    # =========================================================================

    def get_dataset(
        self,
        dataset_id: int,
        include_signed_urls: bool = False,
        url_expires_seconds: int = 3600,
    ) -> Dataset:
        """
        Retrieve a dataset by ID.

        Args:
            dataset_id: The ID of the dataset to retrieve.
            include_signed_urls: Whether to include signed S3 URLs for media files.
            url_expires_seconds: Expiration time for signed URLs in seconds.

        Returns:
            The dataset object.

        Raises:
            NotFoundError: If the dataset is not found.
            AuthorizationError: If you don't have access to this dataset.
        """
        response = self._make_request(
            "get_dataset",
            dataset_id=dataset_id,
            include_signed_urls=include_signed_urls,
            url_expires_seconds=url_expires_seconds,
        )
        return response["dataset"]

    def list_datasets(
        self,
        tenant_id: int | None = None,
        limit: int = 50,
        cursor: int | None = None,
        include_signed_urls: bool = False,
        url_expires_seconds: int = 3600,
    ) -> dict:
        """
        List datasets for a tenant.

        Args:
            tenant_id: The ID of the tenant (auto-resolved if omitted).
            limit: Maximum number of datasets to return (default: 50).
            cursor: ID of last item from previous page for cursor-based pagination.
                Pass the ``next_cursor`` value from the previous response.
            include_signed_urls: Whether to include signed S3 URLs for media files.
            url_expires_seconds: Expiration time for signed URLs in seconds.

        Returns:
            A dict containing 'datasets' list and 'next_cursor' for pagination.
        """
        params: dict[str, Any] = {
            "tenant_id": self._resolve_tenant_id(tenant_id),
            "limit": limit,
            "include_signed_urls": include_signed_urls,
            "url_expires_seconds": url_expires_seconds,
        }
        if cursor is not None:
            params["cursor"] = cursor
        return self._make_request("list_datasets", **params)

    def get_lightberry_scenario(
        self,
        dataset_id: int,
        run_id: str | None = None,
        url_expires_seconds: int = 3600,
    ) -> dict:
        """
        Fetch a Lightberry robot-session scenario plus a presigned MCAP URL.

        Works for both lightberry dataset shapes:

        - ``lightberry_mcap_synthetic`` — single-scenario row (one Dataset = one
          ``scenario.json`` + one ``session.mcap``).
        - ``multi_run_3d`` — bundled row (one Dataset = ``runs[]`` array of N
          scenarios). Pass ``run_id`` to pick a specific run; defaults to the
          first run.

        Requires the ``lightberry_viewer`` feature flag on the tenant.

        Args:
            dataset_id: The dataset to fetch.
            run_id: For ``multi_run_3d`` bundles, the specific run to return.
                Ignored for single-scenario rows.
            url_expires_seconds: Lifetime of the presigned MCAP URL.

        Returns:
            Dict with keys ``scenario`` (parsed scenario.json), ``mcap_url``
            (presigned GET URL — may be absent if no MCAP was registered),
            ``manifest`` (topic counts, duration, tool calls), ``critic_scores``,
            ``critic_issues``, ``category``, ``premise``, and ``runs`` (only
            present for bundles, with ``run_id``/``session_id``/``category``
            entries for picking a specific run on a follow-up call).
        """
        return self._make_request(
            "get_lightberry_scenario",
            dataset_id=dataset_id,
            run_id=run_id,
            url_expires_seconds=url_expires_seconds,
        )

    # =========================================================================
    # Run Operations
    # =========================================================================

    def create_run(
        self,
        dataset_id: int,
        result: dict[str, Any],
        tenant_id: int | None = None,
        runner_id: int | None = None,
    ) -> Run:
        """
        Create a new test run.

        Args:
            dataset_id: The ID of the dataset this run is for.
            result: The run result data (metrics, status, etc.).
            tenant_id: The ID of the tenant (auto-resolved if omitted).
            runner_id: Optional ID of the user who ran the test.

        Returns:
            The created run object.

        Example:
            ```python
            run = client.create_run(
                dataset_id=42,
                result={
                    "score": 0.95,
                    "status": "passed",
                    "metrics": {"accuracy": 0.98, "latency_ms": 150}
                }
            )
            ```
        """
        params: dict[str, Any] = {
            "tenant_id": self._resolve_tenant_id(tenant_id),
            "dataset_id": dataset_id,
            "result": result,
        }
        if runner_id is not None:
            params["runner_id"] = runner_id

        response = self._make_request("create_run", **params)
        return response["run"]

    def delete_run(self, run_id: int) -> dict:
        """
        Delete a test run.

        Args:
            run_id: The ID of the run to delete.

        Returns:
            Confirmation of deletion.

        Raises:
            NotFoundError: If the run is not found.
        """
        return self._make_request("delete_run", run_id=run_id)

    def get_run(self, run_id: int) -> Run:
        """
        Retrieve a run by ID.

        Args:
            run_id: The ID of the run to retrieve.

        Returns:
            The run object.

        Raises:
            NotFoundError: If the run is not found.
        """
        response = self._make_request("get_run", run_id=run_id)
        return response["run"]

    def list_runs(
        self,
        dataset_id: int | None = None,
        tenant_id: int | None = None,
        limit: int = 50,
    ) -> dict:
        """
        List runs for a tenant or dataset.

        Args:
            dataset_id: Filter by dataset ID.
            tenant_id: Filter by tenant ID (auto-resolved if omitted).
            limit: Maximum number of runs to return.

        Returns:
            A dict containing 'runs' list.
        """
        params: dict[str, Any] = {
            "tenant_id": self._resolve_tenant_id(tenant_id),
            "limit": limit,
        }
        if dataset_id is not None:
            params["dataset_id"] = dataset_id

        return self._make_request("list_runs", **params)

    # =========================================================================
    # Observability — Production Agent Tracing
    # =========================================================================

    def trace(
        self,
        name: str,
        *,
        user_id: str | None = None,
        session_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        tags: list[str] | None = None,
    ):
        """
        Start a new observability trace for a production agent interaction.

        Returns a ``Trace`` object. Add spans, generations, and events to it,
        then call ``trace.end()`` to flush everything to the Ashr Labs backend.

        Requires the ``observability`` feature flag to be enabled for the tenant.

        Args:
            name: Name for this trace (e.g. "handle-support-ticket").
            user_id: End-user identifier for grouping.
            session_id: Session/conversation ID for grouping.
            metadata: Arbitrary metadata dict.
            tags: Additional tags for filtering.

        Returns:
            A ``Trace`` instance.

        Example::

            trace = client.trace("support-chat", user_id="user_42")
            gen = trace.generation("respond", model="claude-sonnet-4-6",
                                   input=[{"role": "user", "content": "Help me"}])
            gen.end(output={"content": "Sure!"}, usage={"input_tokens": 10, "output_tokens": 5})
            trace.end(output={"resolution": "helped"})
        """
        from .tracing import Trace
        return Trace(
            self, name,
            user_id=user_id,
            session_id=session_id,
            metadata=metadata,
            tags=tags,
        )

    def list_observability_traces(
        self,
        user_id: str | None = None,
        session_id: str | None = None,
        limit: int = 50,
        page: int = 1,
    ) -> dict:
        """
        List observability traces for the current tenant.

        Requires the ``observability`` feature flag to be enabled.

        Args:
            user_id: Filter by end-user ID.
            session_id: Filter by session/conversation ID.
            limit: Maximum number of traces per page (max 100).
            page: Page number (1-indexed).

        Returns:
            A dict with ``traces`` list and ``total`` count.

        Raises:
            AuthorizationError: If observability is not enabled for the tenant.

        Example::

            response = client.list_observability_traces(user_id="user_42")
            for trace in response["traces"]:
                print(trace["name"], trace["created_at"])
        """
        params: dict[str, Any] = {"limit": limit, "page": page}
        if user_id is not None:
            params["user_id"] = user_id
        if session_id is not None:
            params["session_id"] = session_id
        return self._make_request("list_observability_traces", **params)

    def get_observability_trace(self, trace_id: str) -> dict:
        """
        Get a single observability trace with full span/generation detail.

        Requires the ``observability`` feature flag to be enabled.

        Args:
            trace_id: The Langfuse trace ID.

        Returns:
            A dict with trace metadata and ``observations`` list containing
            all spans, generations, and events.

        Raises:
            NotFoundError: If the trace is not found.
            AuthorizationError: If observability is not enabled for the tenant.

        Example::

            trace = client.get_observability_trace("abc-123")
            for obs in trace["trace"]["observations"]:
                print(obs["name"], obs["type"])
        """
        return self._make_request("get_observability_trace", trace_id=trace_id)

    def get_observability_analytics(self, days: int = 7) -> dict:
        """
        Get observability analytics: overview metrics, tool performance, model usage.

        Args:
            days: Lookback period in days (default 7).

        Returns:
            A dict with ``overview``, ``tool_performance``, and ``model_usage``.
        """
        return self._make_request("get_observability_analytics", days=days)

    def get_observability_errors(self, days: int = 7, limit: int = 50, page: int = 1) -> dict:
        """
        Get traces with errors.

        Args:
            days: Lookback period in days.
            limit: Max results per page.
            page: Page number.

        Returns:
            A dict with ``traces`` list and ``total`` count.
        """
        return self._make_request("get_observability_errors", days=days, limit=limit, page=page)

    def get_observability_tool_errors(self, days: int = 7, limit: int = 50, page: int = 1) -> dict:
        """
        Get traces with tool call failures.

        Args:
            days: Lookback period in days.
            limit: Max results per page.
            page: Page number.

        Returns:
            A dict with ``traces`` list and ``total`` count.
        """
        return self._make_request("get_observability_tool_errors", days=days, limit=limit, page=page)

    # =========================================================================
    # Request Operations
    # =========================================================================

    def create_request(
        self,
        request_name: str,
        request: dict[str, Any],
        request_input_schema: dict[str, Any] | None = None,
        tenant_id: int | None = None,
        requestor_id: int | None = None,
    ) -> RequestModel:
        """
        Create a new dataset generation request.

        The ``request`` dict contains the generation config that describes
        your agent and the test scenarios to generate.  The
        ``request_input_schema`` is a JSON Schema that the backend uses to
        validate that config; if you include agent tools, put them in
        ``request_input_schema["tools"]`` so they're auto-saved as skill
        templates.

        Args:
            request_name: A name/title for the request.
            request: The generation config (see full schema below).
            request_input_schema: JSON Schema for validating ``request``.
                If omitted a permissive default schema is sent and tools
                are auto-populated from ``request["agent"]["tools"]``.
            tenant_id: The ID of the tenant (auto-resolved if omitted).
            requestor_id: The ID of the user making the request (auto-resolved if omitted).

        Returns:
            The created request object.

        **Generation config structure** (the ``request`` dict)::

            {
                # ── agent (required) ─────────────────────────────────
                # At least one of name, description, or system_prompt is required.
                "agent": {
                    "name": str,               # Agent name
                    "description": str,        # What the agent does
                    "system_prompt": str,      # System prompt given to the agent

                    # Tools the agent can call — MUST be here for scenario
                    # generation to include tool call expectations.
                    "tools": [
                        {
                            "name": str,           # Tool name (snake_case)
                            "description": str,    # What the tool does
                            "parameters": {        # JSON Schema for tool params
                                "type": "object",
                                "properties": {
                                    "param_name": {"type": str, "description": str},
                                },
                                "required": [str, ...],
                            },
                        },
                    ],

                    # What input modalities the agent accepts (required)
                    # Values: bool or {"enabled": bool}
                    # Allowed keys: text, audio, file, image, video, conversation
                    "accepted_inputs": {
                        "text": True,
                        "audio": False,
                        "file": False,
                        "image": False,
                        "video": False,
                        "conversation": False,
                    },

                    # Output format (optional)
                    "output_format": {"type": "text"},

                    # Custom structured input schema (optional)
                    "input_schema": {
                        "name": str,
                        "description": str,
                        "fields": [{"name": str, "type": str, "description": str}],
                    },
                },

                # ── context (required) ───────────────────────────────
                # At least one of domain, use_case, or scenario_context is required.
                "context": {
                    "domain": str,             # e.g. "healthcare", "financial services", "e-commerce"
                    "use_case": str,           # What users do with the agent
                    "scenario_context": str,   # Additional context about the environment
                    "user_persona": {          # (optional)
                        "type": str,
                        "description": str,
                    },
                    "sample_data": {           # (optional)
                        "examples": [{...}],
                    },
                },

                # ── generation_options (required) ────────────────────
                "generation_options": {
                    "scenario_count": 5,           # Number of scenarios to generate
                    "generate_audio": False,       # Generate audio test inputs
                    "generate_files": False,       # Generate file test inputs
                    "generate_images": False,      # Generate image test inputs
                    "generate_videos": False,      # Generate video test inputs
                    "generate_simulations": False,  # Generate website simulations
                },

                # ── test_config (optional, defaults provided) ────────
                "test_config": {
                    "num_variations": 5,           # 1-50, number of test scenarios
                    "strategy": "balanced",        # "focused", "diverse", or "balanced"
                    "coverage": {
                        "happy_path": True,
                        "edge_cases": True,
                        "error_handling": True,
                    },
                    "complexity_distribution": {   # (optional) Must sum to ~1.0
                        "simple": 0.3,
                        "moderate": 0.5,
                        "complex": 0.2,
                    },
                },

                # ── metadata (optional) ──────────────────────────────
                "metadata": {
                    "dataset_name": str,
                    "description": str,
                },
            }

        Example:
            ```python
            req = client.create_request(
                request_name="Loan Agent Eval",
                request={
                    "agent": {
                        "name": "QuickLend Loan Officer",
                        "description": "Helps applicants check credit, verify employment, calculate loan terms, and submit applications",
                        "system_prompt": "You are a professional loan officer at QuickLend Financial.",
                        "tools": [
                            {
                                "name": "check_credit_score",
                                "description": "Pull applicant credit score and history",
                                "parameters": {
                                    "type": "object",
                                    "required": ["applicant_id"],
                                    "properties": {
                                        "applicant_id": {"type": "string"}
                                    },
                                },
                            },
                            {
                                "name": "calculate_loan_terms",
                                "description": "Calculate interest rate, monthly payment, and total cost",
                                "parameters": {
                                    "type": "object",
                                    "required": ["loan_amount", "loan_type", "credit_score"],
                                    "properties": {
                                        "loan_amount": {"type": "number"},
                                        "loan_type": {"type": "string"},
                                        "term_months": {"type": "number"},
                                        "credit_score": {"type": "number"},
                                    },
                                },
                            },
                        ],
                        "accepted_inputs": {"text": True, "audio": False, "file": False, "image": False, "video": False},
                    },
                    "context": {
                        "domain": "financial services",
                        "use_case": "Applicants inquiring about loan eligibility, rates, and submitting applications",
                        "scenario_context": "A digital lending platform called QuickLend Financial",
                    },
                    "generation_options": {
                        "scenario_count": 5,
                        "generate_audio": False,
                        "generate_files": False,
                        "generate_simulations": False,
                    },
                    "test_config": {
                        "num_variations": 5,
                        "coverage": {"happy_path": True, "edge_cases": True, "error_handling": True},
                    },
                },
            )
            ```
        """
        self._validate_config_structure(request)

        # The backend requires request_input_schema; send a permissive
        # default so callers aren't forced to build one manually.
        if request_input_schema is None:
            request_input_schema = {
                "type": "object",
                "properties": {},
            }
            # Auto-populate tools from the request's agent config
            tools = (request.get("agent") or {}).get("tools")
            if tools:
                request_input_schema["tools"] = tools

        params: dict[str, Any] = {
            "tenant_id": self._resolve_tenant_id(tenant_id),
            "requestor_id": self._resolve_user_id(requestor_id),
            "request_name": request_name,
            "request": request,
            "request_input_schema": request_input_schema,
        }

        response = self._make_request("create_request", **params)
        return response["request"]

    def create_lightberry_request(
        self,
        request_name: str,
        *,
        categories: list[str] | None = None,
        n_per_category: int = 2,
        freeform: list[dict[str, str]] | None = None,
        target_duration_ms: int = 60_000,
        author_model: str | None = None,
        critic_model: str | None = None,
        workers: int | None = None,
        description: str = "",
        tenant_id: int | None = None,
        requestor_id: int | None = None,
    ) -> RequestModel:
        """
        Create a Lightberry 3D / robot-session dataset generation request.

        Builds the ``{"3d": {"protocol": "lightberry", ...}}`` payload and
        submits it via the standard ``create_request`` endpoint. The backend
        recognizes the ``"3d"`` discriminator and routes to the lightberry
        synthesis pipeline (author → critic → MCAP renderer), persisting the
        keepers as a single bundled Dataset row of type ``multi_run_3d``.

        Either ``categories`` (drawn from the bundled premises catalog) or
        ``freeform`` (caller-authored) must be non-empty.

        Requires the ``lightberry_generator`` feature flag on the tenant.
        Server-side caps: max 50 premises per submission;
        ``target_duration_ms`` between 30_000 and 600_000.

        Args:
            request_name: Becomes the dataset name on the resulting bundle.
            categories: Premise categories to draw from the bundled catalog
                (e.g. ``["nav", "manipulation"]``).
            n_per_category: How many premises to pull per catalog category.
            freeform: Caller-authored premises, each ``{"category", "premise"}``.
            target_duration_ms: Target session length in milliseconds.
            author_model: Override the default scenario-author model.
            critic_model: Override the default scenario-critic model.
            workers: Parallelism for the synthesis pipeline.
            description: Description stored on the resulting dataset.
            tenant_id: Auto-resolved if omitted.
            requestor_id: Auto-resolved if omitted.

        Returns:
            The created request object. Poll with :meth:`get_request` or
            :meth:`wait_for_request` to follow status; the resulting dataset
            will have ``dataset_source.dataset_type == "multi_run_3d"``. Use
            :meth:`get_lightberry_scenario` to fetch individual runs from it.

        Example:
            ```python
            req = client.create_lightberry_request(
                "kitchen-nav pack",
                categories=["nav"],
                n_per_category=3,
                freeform=[{"category": "nav", "premise": "find mug, return to dock"}],
                target_duration_ms=90_000,
            )
            ```
        """
        catalog = (categories or [])
        freeform = freeform or []
        if not catalog and not freeform:
            raise ValueError(
                "create_lightberry_request needs at least one of "
                "`categories` or `freeform`"
            )
        for i, p in enumerate(freeform):
            if not isinstance(p, dict) or "category" not in p or "premise" not in p:
                raise ValueError(
                    f"freeform[{i}] must be a dict with 'category' and 'premise' keys"
                )

        block: dict[str, Any] = {
            "protocol": "lightberry",
            "premises": {
                "from_catalog": {
                    "categories": list(catalog),
                    "n_per_category": int(n_per_category),
                },
                "freeform": list(freeform),
            },
            "target_duration_ms": int(target_duration_ms),
        }
        models: dict[str, str] = {}
        if author_model:
            models["author"] = author_model
        if critic_model:
            models["critic"] = critic_model
        if models:
            block["models"] = models
        if workers is not None:
            block["workers"] = int(workers)

        request_body: dict[str, Any] = {"3d": block}
        if description:
            request_body["description"] = description

        params: dict[str, Any] = {
            "tenant_id": self._resolve_tenant_id(tenant_id),
            "requestor_id": self._resolve_user_id(requestor_id),
            "request_name": request_name,
            "request": request_body,
            "request_input_schema": {"type": "object", "properties": {}},
        }
        response = self._make_request("create_request", **params)
        return response["request"]

    def get_request(self, request_id: int) -> RequestModel:
        """
        Retrieve a request by ID.

        Args:
            request_id: The ID of the request to retrieve.

        Returns:
            The request object.

        Raises:
            NotFoundError: If the request is not found.
        """
        response = self._make_request("get_request", request_id=request_id)
        return response["request"]

    def list_requests(
        self,
        tenant_id: int | None = None,
        status: str | None = None,
        limit: int = 50,
        cursor: int | None = None,
    ) -> dict:
        """
        List requests for a tenant.

        Args:
            tenant_id: The ID of the tenant (auto-resolved if omitted).
            status: Filter by request status (e.g., 'pending', 'completed').
            limit: Maximum number of requests to return.
            cursor: ID of last item from previous page for cursor-based pagination.
                Pass the ``next_cursor`` value from the previous response.

        Returns:
            A dict containing 'requests' list and 'next_cursor' for pagination.
        """
        params: dict[str, Any] = {
            "tenant_id": self._resolve_tenant_id(tenant_id),
            "limit": limit,
        }
        if status is not None:
            params["status"] = status
        if cursor is not None:
            params["cursor"] = cursor

        return self._make_request("list_requests", **params)

    # =========================================================================
    # API Key Operations
    # =========================================================================

    def list_api_keys(self, include_inactive: bool = False) -> list[APIKey]:
        """
        List API keys for your tenant.

        Note: For security, only the key prefix is returned, not the full key.

        Args:
            include_inactive: Whether to include revoked/inactive keys.

        Returns:
            A list of API key objects.
        """
        response = self._make_request(
            "list_api_keys",
            include_inactive=include_inactive,
        )
        return response["api_keys"]

    def revoke_api_key(self, api_key_id: int) -> dict:
        """
        Revoke an API key.

        Args:
            api_key_id: The ID of the API key to revoke.

        Returns:
            Confirmation of revocation.

        Raises:
            NotFoundError: If the API key is not found.
        """
        return self._make_request("revoke_api_key", api_key_id=api_key_id)

    # =========================================================================
    # Agent Operations
    # =========================================================================

    def list_agents(self) -> list:
        """
        List all agents for your tenant with dataset counts.

        Returns:
            A list of agent objects.
        """
        response = self._make_request("list_agents")
        return response["agents"]

    def create_agent(
        self,
        name: str,
        description: str | None = None,
        config: dict | None = None,
    ) -> dict:
        """
        Create a new agent.

        Args:
            name: Agent name (must be unique within your tenant).
            description: Optional description of what this agent does.
            config: Optional config dict with ``tool_definitions``,
                ``behavior_rules``, and ``grading_config``.

        Returns:
            The created agent object.

        Example:
            ```python
            agent = client.create_agent(
                name="Support Bot",
                description="Spanish-language healthcare scheduling agent",
                config={
                    "tool_definitions": [
                        {"name": "fetch_kareo_data", "required": True},
                        {"name": "end_session", "required": False},
                    ],
                    "behavior_rules": [
                        {"rule": "Always fetch before quoting availability", "strictness": "required"},
                    ],
                    "grading_config": {
                        "tool_strictness": {
                            "fetch_kareo_data": "required",
                            "end_session": "optional",
                        },
                    },
                },
            )
            ```
        """
        params: dict = {"name": name}
        if description is not None:
            params["description"] = description
        if config is not None:
            params["config"] = config
        response = self._make_request("create_agent", **params)
        return response["agent"]

    def update_agent(
        self,
        agent_id: int,
        name: str | None = None,
        description: str | None = None,
        config: dict | None = None,
    ) -> dict:
        """
        Update an agent's name, description, or config.

        Args:
            agent_id: The agent to update.
            name: New name (optional).
            description: New description (optional).
            config: New config dict (optional). Replaces the entire config.

        Returns:
            The updated agent object.
        """
        params: dict = {"agent_id": agent_id}
        if name is not None:
            params["name"] = name
        if description is not None:
            params["description"] = description
        if config is not None:
            params["config"] = config
        response = self._make_request("update_agent", **params)
        return response["agent"]

    def delete_agent(self, agent_id: int) -> dict:
        """
        Delete an agent (soft-delete). Datasets are unlinked but not deleted.

        Args:
            agent_id: The agent to delete.

        Returns:
            Confirmation dict.
        """
        return self._make_request("delete_agent", agent_id=agent_id)

    def get_agent_datasets(self, agent_id: int, **kwargs) -> dict:
        """
        Get all datasets linked to an agent.

        Args:
            agent_id: The agent to query.
            **kwargs: Additional params (include_signed_urls, etc.)

        Returns:
            Dict with ``agent`` and ``datasets`` keys.
        """
        return self._make_request("get_agent_datasets", agent_id=agent_id, **kwargs)

    def set_dataset_agent(self, dataset_id: int, agent_id: int | None) -> dict:
        """
        Assign or unassign an agent to a dataset.

        Args:
            dataset_id: The dataset to update.
            agent_id: The agent to assign, or None to unlink.

        Returns:
            Confirmation dict.
        """
        return self._make_request(
            "set_dataset_agent", dataset_id=dataset_id, agent_id=agent_id
        )

    # =========================================================================
    # Session Operations
    # =========================================================================

    def init(self) -> Session:
        """
        Initialize a session and validate authentication.

        This method validates the API key and returns information about
        the authenticated user and tenant. Use this to verify credentials
        and retrieve user/tenant context at the start of a session.

        Returns:
            A dict containing:
            - status: "ok" if successful
            - user: User information (id, email, name, etc.)
            - tenant: Tenant information (id, tenant_name, etc.)

        Raises:
            AuthenticationError: If the API key is invalid or expired.

        Example:
            ```python
            client = AshrLabsClient(api_key="tp_...")

            # Validate credentials and get user info
            session = client.init()
            print(f"Logged in as: {session['user']['email']}")
            print(f"Tenant: {session['tenant']['tenant_name']}")
            ```
        """
        return self._make_request("init")

    # =========================================================================
    # SDK Notes
    # =========================================================================

    @property
    def notes(self) -> list[SdkNote]:
        """
        Get cached SDK notes from the last init() or get_notes() call.

        Notes are platform advisories that may affect how you configure
        or run your agent. They're automatically fetched on first use.

        Returns:
            List of active notes for your tenant.
        """
        self._ensure_session()
        return self._notes

    def get_notes(self, agent_id: int | None = None) -> list[SdkNote]:
        """
        Fetch fresh SDK notes from the platform.

        Use this to refresh notes on-demand or to filter by a specific agent.

        Args:
            agent_id: Optional agent ID to also include agent-targeted notes.

        Returns:
            List of active notes for your tenant (global + tenant-specific,
            plus agent-specific if agent_id is provided).

        Example:
            ```python
            notes = client.get_notes()
            for note in notes:
                print(f"[{note['severity']}] {note['title']}: {note['content']}")
            ```
        """
        params: dict[str, Any] = {}
        if agent_id is not None:
            params["agent_id"] = agent_id
        response = self._make_request("get_sdk_notes", **params)
        self._notes = response.get("notes", [])
        return self._notes

    # =========================================================================
    # Utility Methods
    # =========================================================================

    def health_check(self) -> dict:
        """
        Check if the API is reachable and responding.

        Returns:
            A dict with status information.
        """
        return self._make_request("keep_alive")

    # =========================================================================
    # Convenience / Workflow Methods
    # =========================================================================

    def wait_for_request(
        self,
        request_id: int,
        timeout: int = 600,
        poll_interval: int = 5,
    ) -> RequestModel:
        """Block until a request reaches a terminal state (completed/failed).

        Args:
            request_id: The ID of the request to poll.
            timeout: Maximum seconds to wait before raising TimeoutError.
            poll_interval: Seconds between polls.

        Returns:
            The final request object.

        Raises:
            TimeoutError: If the request doesn't finish within ``timeout`` seconds.
            AshrLabsError: If the request fails.
        """
        start = time.time()
        while time.time() - start < timeout:
            req = self.get_request(request_id=request_id)
            status = req.get("request_status", "")
            if status == "completed":
                return req
            if status == "failed":
                error_msg = req.get("error", "Request failed")
                raise AshrLabsError(f"Request {request_id} failed: {error_msg}")
            time.sleep(poll_interval)
        raise TimeoutError(
            f"Request {request_id} did not complete within {timeout}s"
        )

    def poll_run(
        self,
        run_id: int,
        timeout: int = 300,
        poll_interval: int = 20,
        on_poll: Any | None = None,
    ) -> Run:
        """Block until backend grading completes for a run.

        After ``deploy()``, the backend grades tool arguments and text
        responses asynchronously (typically 1-3 minutes). This method
        polls ``get_run()`` until ``aggregate_metrics.tests_passed`` is
        populated, meaning grading is finished.

        Args:
            run_id: The ID of the run to poll.
            timeout: Maximum seconds to wait (default: 300).
            poll_interval: Seconds between polls (default: 20).
            on_poll: Optional callback ``(elapsed_seconds, run_dict) -> None``
                called after each poll.

        Returns:
            The fully graded run object.

        Raises:
            TimeoutError: If grading doesn't finish within ``timeout`` seconds.
        """
        start = time.time()
        while True:
            run = self.get_run(run_id)
            metrics = run.get("result", {}).get("aggregate_metrics", {})
            if metrics.get("tests_passed") is not None:
                return run
            elapsed = time.time() - start
            if on_poll:
                on_poll(int(elapsed), run)
            if elapsed >= timeout:
                raise TimeoutError(
                    f"Run {run_id} grading did not complete within {timeout}s"
                )
            time.sleep(poll_interval)

    @staticmethod
    def _enrich_config(config: dict[str, Any]) -> dict[str, Any]:
        """Fill in missing context fields so the backend has enough to generate.

        If ``context.use_case`` and ``context.scenario_context`` are both
        missing, synthesize them from the agent's name and description so
        the generation prompt is meaningful.
        """
        config = copy.deepcopy(config)
        agent = config.get("agent", {})
        context = config.get("context", {})

        has_use_case = bool(context.get("use_case"))
        has_scenario = bool(context.get("scenario_context"))

        if not has_use_case and not has_scenario:
            name = agent.get("name", "")
            desc = agent.get("description", "")
            domain = context.get("domain", "")

            if desc:
                context["use_case"] = desc
            elif name:
                context["use_case"] = f"Testing the {name} agent"

            if name and desc:
                parts = [f"A user interacting with {name}"]
                if domain and domain != "general":
                    parts.append(f"in the {domain} domain")
                parts.append(f"— {desc}")
                context["scenario_context"] = " ".join(parts)

            config["context"] = context

        # Default test_config if missing
        if "test_config" not in config:
            config["test_config"] = {
                "num_variations": 5,
                "coverage": {
                    "happy_path": True,
                    "edge_cases": True,
                    "error_handling": True,
                },
            }

        return config

    def generate_dataset(
        self,
        request_name: str,
        config: dict[str, Any],
        request_input_schema: dict[str, Any] | None = None,
        timeout: int = 600,
        poll_interval: int = 5,
    ) -> tuple[int, dict]:
        """Create a dataset generation request, wait for it, and fetch the result.

        **Prefer reusing existing datasets** with ``EvalRunner.from_dataset()``
        instead of generating new ones each time. Only generate a new dataset
        when the agent's tools, inputs, or domain have changed. Reusing
        datasets lets you compare agent performance across code changes
        against the same scenarios.

        This is a high-level convenience method that combines
        ``create_request`` + ``wait_for_request`` + ``get_dataset``.

        Missing context fields (``use_case``, ``scenario_context``) are
        auto-filled from the agent's name and description so the backend
        always has enough information to generate meaningful scenarios.
        A default ``test_config`` is added if not provided.

        Args:
            request_name: A name/title for the request.
            config: The generation config dict — same structure as
                ``create_request``'s ``request`` parameter. See
                ``create_request`` for the full schema reference.

                Required sections:
                    - **agent**: At least one of ``name``, ``description``, or ``system_prompt``.
                      Optionally include ``tools``, ``accepted_inputs``, ``output_format``,
                      ``input_schema``, ``system_prompt``.
                    - **context**: At least one of ``domain``, ``use_case``, or ``scenario_context``.
                      Optionally include ``user_persona``, ``sample_data``.

                Optional sections:
                    - **metadata**: ``dataset_name``, ``description``
                    - **test_config**: ``num_variations`` (1-50), ``strategy`` (focused/diverse/balanced),
                      ``coverage`` (happy_path, edge_cases, error_handling, boundary_values),
                      ``complexity_distribution`` (simple, moderate, complex), ``focus_areas``, ``exclude``
                    - **expected_behaviors**: ``must_include``, ``must_not_include``, ``expected_tools``
                    - **generation_options**: ``generate_audio``, ``generate_files``, ``generate_images``,
                      ``generate_videos``, ``generate_simulations``
                    - **website_simulation**: ``enabled``, ``url``, ``domain``, ``simulation_config``

            request_input_schema: Optional JSON Schema for validation.
                If omitted, auto-populated from ``config["agent"]["tools"]``.
            timeout: Maximum seconds to wait for generation (default: 600).
            poll_interval: Seconds between status polls (default: 5).

        Returns:
            A tuple of ``(dataset_id, dataset_source)`` where
            ``dataset_source`` is the dict containing ``"runs"``.

        Raises:
            TimeoutError: If generation doesn't finish in time.
            AshrLabsError: If generation fails.

        Example:
            ```python
            dataset_id, source = client.generate_dataset(
                "My Agent Eval",
                {
                    "agent": {
                        "name": "Support Bot",
                        "description": "Handles customer orders and refunds",
                        "tools": [
                            {"name": "lookup_order", "description": "Look up an order",
                             "parameters": {"type": "object", "properties": {"order_id": {"type": "string"}}, "required": ["order_id"]}},
                        ],
                    },
                    "context": {
                        "domain": "e-commerce",
                        "use_case": "Customer support for online retail",
                    },
                    "test_config": {"num_variations": 10, "strategy": "diverse"},
                },
            )
            ```
        """
        config = self._enrich_config(config)
        req = self.create_request(
            request_name=request_name,
            request=config,
            request_input_schema=request_input_schema,
        )
        request_id = req["id"]

        self.wait_for_request(
            request_id, timeout=timeout, poll_interval=poll_interval
        )

        # Find the dataset created by this request
        resp = self.list_datasets(limit=10)
        datasets = resp.get("datasets", [])
        match = next(
            (d for d in datasets if d.get("request_id") == request_id),
            None,
        )
        if not match:
            raise AshrLabsError(
                f"No dataset found for request {request_id}"
            )

        dataset_id = match["id"]
        full_ds = self.get_dataset(dataset_id=dataset_id, include_signed_urls=False)
        source = full_ds.get("dataset_source", {})
        return dataset_id, source

    # =========================================================================
    # Pentest Dataset Operations
    # =========================================================================

    def request_pentest_dataset(
        self,
        agent_name: str,
        agent_description: str = "",
        system_prompt: str = "",
        tools: list[dict[str, Any]] | None = None,
        categories: list[str] | None = None,
        num_scenarios_per_category: int = 3,
        difficulty: str = "mixed",
        include_multi_turn: bool = True,
        tenant_id: int | None = None,
        requestor_id: int | None = None,
    ) -> RequestModel:
        """Create a pentest dataset generation request.

        Submits a request to generate a security evaluation dataset
        tailored to your agent. The generated dataset will contain
        adversarial attack scenarios across the specified security
        categories.

        To wait for the dataset to be generated and fetch it, use
        :meth:`generate_pentest_dataset` instead.

        Args:
            agent_name: Name of the agent being tested.
            agent_description: Description of what the agent does.
            system_prompt: The agent's system prompt (helps generate
                targeted attacks).
            tools: Tool definitions the agent has access to.
            categories: Security categories to test. Defaults to all 7:
                prompt_injection, privilege_escalation, data_exfiltration,
                jailbreak, tool_abuse, denial_of_service, social_engineering.
            num_scenarios_per_category: Scenarios per category (default: 3).
            difficulty: "easy", "medium", "hard", or "mixed" (default).
            include_multi_turn: Include multi-turn attacks (default: True).
            tenant_id: Tenant ID (auto-resolved if omitted).
            requestor_id: Requestor user ID (auto-resolved if omitted).

        Returns:
            The created request object. Use ``request["id"]`` to poll
            status with :meth:`get_request` or :meth:`wait_for_request`.

        Example:
            ```python
            req = client.request_pentest_dataset(
                agent_name="Support Bot",
                agent_description="Answers customer support questions",
                system_prompt="You are a helpful support agent.",
                tools=[{"name": "lookup_order", "description": "Look up an order"}],
                categories=["prompt_injection", "data_exfiltration"],
            )
            print(f"Request created: {req['id']}")

            # Poll until complete
            finished = client.wait_for_request(req["id"])
            ```
        """
        from .pentest import build_pentest_request_config

        config = build_pentest_request_config(
            agent_name=agent_name,
            agent_description=agent_description,
            system_prompt=system_prompt,
            tools=tools,
            categories=categories,
            num_scenarios_per_category=num_scenarios_per_category,
            difficulty=difficulty,
            include_multi_turn=include_multi_turn,
        )

        # Build schema with tools for auto-saving as skill templates
        request_input_schema: dict[str, Any] = {
            "type": "object",
            "properties": {
                "agent": {"type": "object"},
                "context": {"type": "object"},
                "pentest_config": {"type": "object"},
            },
            "required": ["agent", "context", "pentest_config"],
        }
        if tools:
            request_input_schema["tools"] = tools

        return self.create_request(
            request_name=f"Pentest: {agent_name}",
            request=config,
            request_input_schema=request_input_schema,
            tenant_id=tenant_id,
            requestor_id=requestor_id,
        )

    def generate_pentest_dataset(
        self,
        agent_name: str,
        agent_description: str = "",
        system_prompt: str = "",
        tools: list[dict[str, Any]] | None = None,
        categories: list[str] | None = None,
        num_scenarios_per_category: int = 3,
        difficulty: str = "mixed",
        include_multi_turn: bool = True,
        timeout: int = 600,
        poll_interval: int = 5,
    ) -> tuple[int, dict]:
        """Request a pentest dataset, wait for generation, and return it.

        This is the high-level convenience method that combines
        :meth:`request_pentest_dataset` + :meth:`wait_for_request` +
        :meth:`get_dataset`.

        Args:
            agent_name: Name of the agent being tested.
            agent_description: Description of what the agent does.
            system_prompt: The agent's system prompt.
            tools: Tool definitions the agent has access to.
            categories: Security categories to test (default: all 7).
            num_scenarios_per_category: Scenarios per category (default: 3).
            difficulty: "easy", "medium", "hard", or "mixed" (default).
            include_multi_turn: Include multi-turn attacks (default: True).
            timeout: Max seconds to wait for generation (default: 600).
            poll_interval: Seconds between polls (default: 5).

        Returns:
            A tuple of ``(dataset_id, dataset_source)`` where
            ``dataset_source`` contains the pentest scenarios in the
            ``multi_run_storyboard`` format with ``"runs"``.

        Raises:
            TimeoutError: If generation doesn't finish in time.
            AshrLabsError: If generation fails.

        Example:
            ```python
            dataset_id, source = client.generate_pentest_dataset(
                agent_name="Support Bot",
                agent_description="Answers customer support questions",
                system_prompt="You are a helpful support agent.",
                tools=[{"name": "lookup_order", "description": "Look up an order"}],
                categories=["prompt_injection", "data_exfiltration"],
                num_scenarios_per_category=5,
            )

            print(f"Dataset {dataset_id} with {len(source['runs'])} scenarios")

            # Run the dataset against your agent
            from ashr_labs import EvalRunner
            runner = EvalRunner(dataset_source=source)
            result = runner.run(my_agent)
            result.deploy(client, dataset_id=dataset_id)
            ```
        """
        req = self.request_pentest_dataset(
            agent_name=agent_name,
            agent_description=agent_description,
            system_prompt=system_prompt,
            tools=tools,
            categories=categories,
            num_scenarios_per_category=num_scenarios_per_category,
            difficulty=difficulty,
            include_multi_turn=include_multi_turn,
        )
        request_id = req["id"]

        self.wait_for_request(
            request_id, timeout=timeout, poll_interval=poll_interval
        )

        # Find the dataset created by this request
        resp = self.list_datasets(limit=10)
        datasets = resp.get("datasets", [])
        match = next(
            (d for d in datasets if d.get("request_id") == request_id),
            None,
        )
        if not match:
            raise AshrLabsError(
                f"No dataset found for request {request_id}"
            )

        dataset_id = match["id"]
        full_ds = self.get_dataset(dataset_id=dataset_id, include_signed_urls=False)
        source = full_ds.get("dataset_source", {})
        return dataset_id, source

    # Allowed keys at each level of the config
    _ALLOWED_TOP_KEYS = {
        "agent", "context", "generation_options", "test_config", "metadata",
        "pentest_config",
    }
    _ALLOWED_AGENT_KEYS = {
        "name", "description", "system_prompt", "tools", "accepted_inputs",
        "output_format", "input_schema",
    }
    _ALLOWED_ACCEPTED_INPUTS = {
        "text", "audio", "file", "image", "video", "conversation",
    }
    _ALLOWED_CONTEXT_KEYS = {
        "domain", "use_case", "scenario_context", "user_persona", "sample_data",
    }
    _ALLOWED_GENERATION_OPTIONS_KEYS = {
        "scenario_count", "generate_audio", "generate_files", "generate_images",
        "generate_videos", "generate_simulations",
    }

    @staticmethod
    def _check_unknown_keys(
        data: dict, allowed: set, section_name: str
    ) -> None:
        """Raise ValueError if data contains keys not in the allowed set."""
        unknown = set(data.keys()) - allowed
        if unknown:
            raise ValueError(
                f"Unknown key(s) in '{section_name}': {sorted(unknown)}. "
                f"Allowed keys: {sorted(allowed)}"
            )

    @classmethod
    def _validate_config_structure(cls, config: dict) -> None:
        """Validate that the request config conforms to the expected schema.

        Checks:
        - Only allowed keys at each level (rejects unknown attributes)
        - Required sections are present
        - accepted_inputs values are bool or {"enabled": bool}
        - accepted_inputs keys are from the allowed set
        - Tools have name and parameters with valid structure

        Raises ValueError with a clear message on any violation.
        """
        if not isinstance(config, dict):
            raise ValueError("request config must be a dict")

        # --- Top-level keys ---
        cls._check_unknown_keys(config, cls._ALLOWED_TOP_KEYS, "config")

        # --- agent ---
        agent = config.get("agent")
        if not agent or not isinstance(agent, dict):
            raise ValueError(
                "request config must include an 'agent' section"
            )
        cls._check_unknown_keys(agent, cls._ALLOWED_AGENT_KEYS, "agent")

        if not any(agent.get(k) for k in ("name", "description", "system_prompt")):
            raise ValueError(
                "agent must have at least one of: name, description, system_prompt"
            )

        # --- accepted_inputs ---
        accepted_inputs = agent.get("accepted_inputs")
        if not accepted_inputs or not isinstance(accepted_inputs, dict):
            raise ValueError(
                "agent must include 'accepted_inputs' specifying which input types "
                "your agent supports (e.g. text, audio, file, image, video, conversation). "
                "Example: {'accepted_inputs': {'text': True, 'audio': True}}"
            )

        unknown_inputs = set(accepted_inputs.keys()) - cls._ALLOWED_ACCEPTED_INPUTS
        if unknown_inputs:
            raise ValueError(
                f"Unknown accepted_inputs key(s): {sorted(unknown_inputs)}. "
                f"Allowed: {sorted(cls._ALLOWED_ACCEPTED_INPUTS)}"
            )

        for key, val in accepted_inputs.items():
            if isinstance(val, bool):
                continue
            if isinstance(val, dict) and "enabled" in val and isinstance(val["enabled"], bool):
                continue
            raise ValueError(
                f"accepted_inputs['{key}'] must be a bool or {{'enabled': bool}}, "
                f"got: {type(val).__name__} = {val!r}"
            )

        # --- tools (optional, validated if present) ---
        tools = agent.get("tools")
        if tools is not None:
            if not isinstance(tools, list):
                raise ValueError("agent.tools must be a list of tool definitions")
            for i, tool in enumerate(tools):
                if not isinstance(tool, dict):
                    raise ValueError(f"agent.tools[{i}] must be a dict")
                if not tool.get("name"):
                    raise ValueError(f"agent.tools[{i}] must have a 'name'")
                params = tool.get("parameters")
                if params is not None and not isinstance(params, dict):
                    raise ValueError(
                        f"agent.tools[{i}] ('{ tool['name'] }') parameters must be a dict "
                        f"with JSON Schema structure, got: {type(params).__name__}"
                    )

        # --- context ---
        context = config.get("context")
        if not context or not isinstance(context, dict):
            raise ValueError(
                "request config must include a 'context' section"
            )
        cls._check_unknown_keys(context, cls._ALLOWED_CONTEXT_KEYS, "context")

        if not any(context.get(k) for k in ("domain", "use_case", "scenario_context")):
            raise ValueError(
                "context must have at least one of: domain, use_case, scenario_context"
            )

        # --- generation_options ---
        generation_options = config.get("generation_options")
        if not generation_options or not isinstance(generation_options, dict):
            raise ValueError(
                "request config must include 'generation_options' specifying what assets "
                "to generate (e.g. generate_audio, generate_files, generate_images, "
                "generate_videos, generate_simulations). "
                "Example: {'generation_options': {'generate_audio': False, 'generate_files': False}}"
            )
        cls._check_unknown_keys(
            generation_options, cls._ALLOWED_GENERATION_OPTIONS_KEYS, "generation_options"
        )

        # --- pentest_config (optional, for pentest datasets) ---
        metadata = config.get("metadata", {})
        if metadata.get("dataset_type") == "pentest":
            from .models import PENTEST_CATEGORIES

            pentest_config = config.get("pentest_config")
            if not pentest_config or not isinstance(pentest_config, dict):
                raise ValueError(
                    "pentest dataset config must include a 'pentest_config' section"
                )
            cats = pentest_config.get("categories", [])
            invalid = set(cats) - set(PENTEST_CATEGORIES)
            if invalid:
                raise ValueError(
                    f"Invalid pentest categories: {invalid}. "
                    f"Valid: {PENTEST_CATEGORIES}"
                )

    def __repr__(self) -> str:
        return f"AshrLabsClient(base_url='{self.base_url}', api_key='{self.api_key[:8]}...')"
