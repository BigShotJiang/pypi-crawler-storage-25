"""
Production agent tracing for Ashr Labs Observability.

Provides a lightweight tracing API that agents call in production to record
their execution — LLM calls, tool invocations, retrieval steps, etc.
Traces are flushed to the Ashr Labs backend, which stores them in Postgres
and renders them in the Observability panel of the Ashr Labs dashboard.

**Production-safe:** tracing never raises exceptions or interferes with your
agent. If the backend is unreachable, ``trace.end()`` returns an error dict
instead of throwing.

Example — manual instrumentation::

    trace = client.trace("handle-ticket", user_id="user_42")

    gen = trace.generation("classify", model="claude-sonnet-4-6",
                           input=[{"role": "user", "content": "help"}])
    gen.end(output={"intent": "reset"}, usage={"input_tokens": 50, "output_tokens": 12})

    tool = trace.span("tool:reset_password", input={"user_id": "42"})
    tool.end(output={"success": True})

    trace.end(output={"resolution": "password_reset"})

Example — context managers (auto-end, auto-capture errors)::

    with client.trace("handle-ticket", user_id="user_42") as trace:
        with trace.generation("classify", model="claude-sonnet-4-6") as gen:
            result = call_llm(...)
            gen.end(output=result, usage={...})

        with trace.span("tool:reset_password", input={"user_id": "42"}) as tool:
            output = reset_password(...)
            tool.end(output=output)
            # If reset_password() throws, the span auto-ends with level="ERROR"
"""

from __future__ import annotations

import logging
import uuid
from datetime import datetime, timezone
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from .client import AshrLabsClient

_log = logging.getLogger("ashr_labs.tracing")


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def _make_id() -> str:
    return uuid.uuid4().hex[:16]


class Span:
    """A unit of work within a trace (tool call, retrieval step, etc.).

    Supports context manager usage::

        with trace.span("tool:search", input={"q": "..."}) as s:
            result = search(...)
            s.end(output=result)

    If the body raises, the span is auto-ended with ``level="ERROR"``
    and the exception is re-raised (tracing never swallows errors).
    """

    def __init__(
        self,
        trace: Trace,
        name: str,
        *,
        parent_id: str | None = None,
        input: Any = None,
        metadata: dict[str, Any] | None = None,
        level: str | None = None,
    ) -> None:
        self.id = _make_id()
        self._trace = trace
        self._ended = False
        self._data: dict[str, Any] = {
            "id": self.id,
            "type": "span",
            "name": name,
            "parent_observation_id": parent_id,
            "start_time": _now(),
            "input": input,
            "metadata": metadata,
            "level": level,
        }
        trace._observations.append(self._data)

    # -- Context manager --

    def __enter__(self) -> Span:
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> bool:
        if not self._ended:
            if exc_type is not None:
                self.end(
                    status_message=f"{exc_type.__name__}: {exc_val}",
                    level="ERROR",
                )
            else:
                self.end()
        return False  # never swallow exceptions

    # -- Child observations --

    def span(
        self,
        name: str,
        *,
        input: Any = None,
        metadata: dict[str, Any] | None = None,
    ) -> Span:
        """Create a child span nested under this span."""
        return Span(self._trace, name, parent_id=self.id, input=input, metadata=metadata)

    def generation(
        self,
        name: str,
        *,
        model: str | None = None,
        input: Any = None,
        metadata: dict[str, Any] | None = None,
    ) -> Generation:
        """Create a child generation nested under this span."""
        return Generation(
            self._trace, name, parent_id=self.id, model=model, input=input, metadata=metadata,
        )

    def event(
        self,
        name: str,
        *,
        input: Any = None,
        metadata: dict[str, Any] | None = None,
        level: str | None = None,
    ) -> None:
        """Record a point-in-time event under this span."""
        self._trace._observations.append({
            "id": _make_id(),
            "type": "event",
            "name": name,
            "parent_observation_id": self.id,
            "start_time": _now(),
            "input": input,
            "metadata": metadata,
            "level": level,
        })

    def end(
        self,
        *,
        output: Any = None,
        status_message: str | None = None,
        level: str | None = None,
    ) -> None:
        """Mark this span as complete."""
        self._data["end_time"] = _now()
        if output is not None:
            self._data["output"] = output
        if status_message is not None:
            self._data["status_message"] = status_message
        if level is not None:
            self._data["level"] = level
        self._ended = True


class Generation(Span):
    """An LLM call within a trace.

    Supports context manager usage::

        with trace.generation("respond", model="claude-sonnet-4-6") as gen:
            response = client.messages.create(...)
            gen.end(output=response, usage={"input_tokens": 100, "output_tokens": 50})
    """

    def __init__(
        self,
        trace: Trace,
        name: str,
        *,
        parent_id: str | None = None,
        model: str | None = None,
        input: Any = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(trace, name, parent_id=parent_id, input=input, metadata=metadata)
        self._data["type"] = "generation"
        if model is not None:
            self._data["model"] = model

    def end(
        self,
        *,
        output: Any = None,
        usage: dict[str, int] | None = None,
        status_message: str | None = None,
        level: str | None = None,
    ) -> None:
        """Mark this generation as complete.

        Args:
            output: The LLM response.
            usage: Token usage, e.g. ``{"input_tokens": 100, "output_tokens": 50}``.
            status_message: Optional status/error message.
            level: Log level override.
        """
        self._data["end_time"] = _now()
        if output is not None:
            self._data["output"] = output
        if usage is not None:
            self._data["usage"] = usage
        if status_message is not None:
            self._data["status_message"] = status_message
        if level is not None:
            self._data["level"] = level
        self._ended = True


class Trace:
    """A production agent trace — the top-level container for observations.

    Create via ``client.trace(...)`` rather than instantiating directly.

    **Production-safe:** ``end()`` never raises. If the backend is
    unreachable, the error is logged and an error dict is returned.

    Supports context manager usage::

        with client.trace("handle-ticket", user_id="user_42") as trace:
            # ... instrument your agent ...
            pass
        # trace.end() is called automatically
    """

    def __init__(
        self,
        client: AshrLabsClient,
        name: str,
        *,
        user_id: str | None = None,
        session_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        tags: list[str] | None = None,
    ) -> None:
        self._client = client
        self._name = name
        self._user_id = user_id
        self._session_id = session_id
        self._metadata = metadata
        self._tags = list(tags) if tags else []
        self._observations: list[dict[str, Any]] = []
        self._output: Any = None
        self._trace_id: str | None = None  # set after flush
        self._flushed = False

    # -- Context manager --

    def __enter__(self) -> Trace:
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> bool:
        if not self._flushed:
            if exc_type is not None:
                self.end(output={"error": f"{exc_type.__name__}: {exc_val}"})
            else:
                self.end()
        return False  # never swallow exceptions

    @property
    def trace_id(self) -> str | None:
        """The server-assigned trace ID (available after ``end()`` is called)."""
        return self._trace_id

    def span(
        self,
        name: str,
        *,
        input: Any = None,
        metadata: dict[str, Any] | None = None,
    ) -> Span:
        """Create a top-level span in this trace."""
        return Span(self, name, input=input, metadata=metadata)

    def generation(
        self,
        name: str,
        *,
        model: str | None = None,
        input: Any = None,
        metadata: dict[str, Any] | None = None,
    ) -> Generation:
        """Create a top-level generation (LLM call) in this trace."""
        return Generation(self, name, model=model, input=input, metadata=metadata)

    def event(
        self,
        name: str,
        *,
        input: Any = None,
        metadata: dict[str, Any] | None = None,
        level: str | None = None,
    ) -> None:
        """Record a point-in-time event in this trace."""
        self._observations.append({
            "id": _make_id(),
            "type": "event",
            "name": name,
            "parent_observation_id": None,
            "start_time": _now(),
            "input": input,
            "metadata": metadata,
            "level": level,
        })

    def end(self, *, output: Any = None) -> dict[str, Any]:
        """Flush the trace to the Ashr Labs backend.

        **Never raises.** If the backend is unreachable, logs the error
        and returns ``{"status": "error", "message": "..."}``.

        Args:
            output: Optional final output for the trace (e.g. resolution summary).

        Returns:
            The API response containing ``trace_id``, or an error dict.
        """
        self._flushed = True
        payload = {
            "trace": {
                "name": self._name,
                "user_id": self._user_id,
                "session_id": self._session_id,
                "metadata": self._metadata,
                "tags": self._tags,
                "observations": self._observations,
            }
        }
        if output is not None:
            payload["trace"]["output"] = output

        try:
            response = self._client._make_request("ingest_observability_trace", **payload)
            self._trace_id = response.get("trace_id")
            return response
        except Exception as e:
            _log.warning("Failed to flush trace %r: %s", self._name, e)
            return {"status": "error", "message": str(e)}
