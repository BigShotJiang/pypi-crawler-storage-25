"""
Data models for the Ashr Labs SDK.

These are TypedDict definitions for better IDE support and documentation.
"""

from typing import TypedDict, Any
from datetime import datetime


class User(TypedDict, total=False):
    """Represents a user."""
    id: int
    created_at: str
    email: str
    name: str | None
    tenant: int
    is_active: bool


class Tenant(TypedDict, total=False):
    """Represents a tenant."""
    id: int
    created_at: str
    tenant_name: str
    is_active: bool


class SdkNote(TypedDict, total=False):
    """An advisory note from the Ashr Labs platform.

    Notes are platform advisories delivered to customer SDKs to communicate
    context changes, best practices, deprecations, or breaking changes.
    """
    id: int
    created_at: str
    updated_at: str
    title: str
    content: str
    category: str        # "info", "warning", "breaking_change", "best_practice", "deprecation"
    severity: str        # "info", "warning", "critical"
    tenant_id: int | None
    agent_id: int | None
    active_from: str
    expires_at: str | None
    is_archived: bool
    note_metadata: dict[str, Any]


class Session(TypedDict):
    """Response from init() containing session information."""
    status: str
    user: User
    tenant: Tenant


class APIKey(TypedDict, total=False):
    """Represents an API key."""
    id: int
    key: str  # Only present on creation
    key_prefix: str
    name: str
    scopes: list[str]
    user_id: int
    tenant_id: int
    created_at: str
    last_used_at: str | None
    expires_at: str | None
    is_active: bool


class ToolDefinition(TypedDict, total=False):
    """A tool definition within an agent's config."""
    name: str
    description: str
    required: bool  # True = must be called, False = optional


class BehaviorRule(TypedDict, total=False):
    """A behavior rule for an agent."""
    rule: str
    strictness: str  # "required", "expected", "optional"


class GradingConfig(TypedDict, total=False):
    """Per-agent grading overrides."""
    tool_strictness: dict[str, str]  # tool_name -> "required" | "expected" | "optional"
    text_similarity_threshold: float


class AgentConfig(TypedDict, total=False):
    """Agent configuration stored in the config JSONB field."""
    form_data: dict[str, Any]
    tool_definitions: list[ToolDefinition]
    behavior_rules: list[BehaviorRule]
    grading_config: GradingConfig


class Agent(TypedDict, total=False):
    """Represents an AI agent for grouping and configuring datasets.

    Agents are tenant-scoped entities that define how datasets should be
    generated and graded. Each dataset can belong to one agent.

    The ``config`` field stores:
      - ``form_data``: Dataset generation preset (auto-fills CreateRequest)
      - ``tool_definitions``: Canonical tool schemas with required/optional flags
      - ``behavior_rules``: What the agent MUST/SHOULD/MAY do
      - ``grading_config``: Per-tool strictness overrides for the grader
    """
    id: int
    created_at: str
    tenant_id: int
    creator_id: int | None
    name: str
    description: str | None
    config: AgentConfig
    is_active: bool
    dataset_count: int


class Dataset(TypedDict, total=False):
    """Represents a dataset."""
    id: int
    created_at: str
    tenant: int
    creator: int
    name: str
    description: str | None
    agent_id: int | None
    agent_details: dict[str, Any] | None
    dataset_source: dict[str, Any]


class Run(TypedDict, total=False):
    """Represents a test run."""
    id: int
    created_at: str
    dataset: int
    tenant: int
    runner: int
    result: dict[str, Any]


# =========================================================================
# Observability types
# =========================================================================

class ObservabilityObservation(TypedDict, total=False):
    """A single observation (span, generation, or event) within a trace."""
    id: str
    name: str
    type: str  # "span", "generation", "event"
    parent_observation_id: str | None
    input: dict[str, Any] | None
    output: dict[str, Any] | None
    metadata: dict[str, Any] | None
    model: str | None  # LLM model name (generations only)
    usage: dict[str, int] | None  # {"input_tokens": ..., "output_tokens": ...}
    level: str | None  # "DEBUG", "DEFAULT", "WARNING", "ERROR"
    status_message: str | None
    start_time: str | None
    end_time: str | None


class ObservabilityTrace(TypedDict, total=False):
    """An observability trace representing a production agent interaction."""
    id: str
    name: str
    user_id: str | None  # End-user identifier
    session_id: str | None  # Conversation/session grouping
    metadata: dict[str, Any] | None
    tags: list[str]
    created_at: str | None
    output: dict[str, Any] | None
    observations: list[ObservabilityObservation]


class Request(TypedDict, total=False):
    """Represents a request."""
    id: int
    created_at: str
    requestor_id: int
    requestor_tenant: int
    request_name: str
    request_status: str
    request_input_schema: dict[str, Any] | None
    request: dict[str, Any]


class ListResponse(TypedDict):
    """Generic list response structure."""
    status: str
    total: int


class DatasetsListResponse(ListResponse):
    """Response from list_datasets."""
    datasets: list[Dataset]


class RunsListResponse(ListResponse):
    """Response from list_runs."""
    runs: list[Run]


class RequestsListResponse(ListResponse):
    """Response from list_requests."""
    requests: list[Request]


class APIKeysListResponse(ListResponse):
    """Response from list_api_keys."""
    api_keys: list[APIKey]


# =========================================================================
# Dataset structure types (used by EvalRunner)
# =========================================================================

class ToolCall(TypedDict, total=False):
    """A tool call within an expected response."""
    name: str
    arguments_json: str


class ExpectedResponse(TypedDict, total=False):
    """The expected agent response for a dataset action."""
    tool_calls: list[ToolCall]
    text: str


class Action(TypedDict, total=False):
    """A single action within a dataset scenario."""
    actor: str  # "user" or "agent"
    content: str
    name: str
    expected_response: ExpectedResponse


class Scenario(TypedDict, total=False):
    """A test scenario containing a sequence of actions."""
    title: str
    actions: list[Action]


# =========================================================================
# Pentest dataset types
# =========================================================================

PENTEST_CATEGORIES = [
    "prompt_injection",
    "privilege_escalation",
    "data_exfiltration",
    "jailbreak",
    "tool_abuse",
    "denial_of_service",
    "social_engineering",
]


# =========================================================================
# VM stream types
# =========================================================================

class VmLogEntry(TypedDict, total=False):
    """A single timestamped event from a VM session."""
    ts: int  # milliseconds offset from session start
    type: str  # event type (provider-specific)
    data: dict[str, Any]


class KernelViewport(TypedDict, total=False):
    """Browser viewport dimensions from a Kernel session."""
    width: int
    height: int


# ---- Kernel action types (computer control API) ----
# These map to POST /browsers/{id}/computer/* endpoints.

KERNEL_ACTION_TYPES = [
    "click_mouse",   # {x, y, button?, click_type?, num_clicks?}
    "move_mouse",    # {x, y, duration_ms?, smooth?}
    "drag_mouse",    # {path: [[x,y],...], button?, smooth?, duration_ms?}
    "type_text",     # {text, delay?}
    "press_key",     # {keys: str[], duration?, hold_keys?}
    "scroll",        # {x, y, delta_x?, delta_y?}
    "screenshot",    # {format?} — result may include s3_key or base64
]

# ---- Kernel event types (SSE streams + navigation) ----

KERNEL_EVENT_TYPES = [
    "navigation",         # {url} — page navigation
    "log",                # {message} — from GET /browsers/{id}/logs SSE
    "error",              # {code, message, details?} — ErrorEvent
    "invocation_state",   # {invocation_id, status, action_name, output?}
    "console",            # {level, message} — browser console output
    "network",            # {method, url, status} — HTTP request observed
]


class KernelActionData(TypedDict, total=False):
    """Data payload for a Kernel computer control action.

    Which fields are present depends on the action type.
    """
    # click_mouse / move_mouse / scroll
    x: int
    y: int
    button: str       # "left", "right", "middle"
    click_type: str   # "single", "double", "triple"
    num_clicks: int
    smooth: bool
    # drag_mouse
    path: list[list[int]]  # [[x, y], ...]
    # type_text
    text: str
    delay: int        # ms between keystrokes
    # press_key
    keys: list[str]   # e.g. ["Enter"], ["Control", "c"]
    duration: int     # ms to hold
    hold_keys: list[str]
    # scroll
    delta_x: int
    delta_y: int
    # screenshot
    format: str       # "png", "jpeg"
    s3_key: str       # where the screenshot was stored
    # duration_ms (move_mouse, drag_mouse)
    duration_ms: int


class KernelEventData(TypedDict, total=False):
    """Data payload for a Kernel event.

    Which fields are present depends on the event type.
    """
    # navigation
    url: str
    # log / console
    message: str
    level: str        # "log", "warn", "error"
    # error
    code: str
    details: list[dict[str, Any]]
    # network
    method: str       # "GET", "POST", etc.
    status: int       # HTTP status code
    # invocation_state
    invocation_id: str
    action_name: str
    status_reason: str  # "queued", "running", "succeeded", "failed"
    output: str       # JSON-encoded output


class KernelVmMetadata(TypedDict, total=False):
    """Kernel-specific browser session metadata.

    Fields map to Kernel's browser API response
    (see https://www.kernel.sh/docs).
    """
    live_view_url: str  # browser_live_view_url — remote live-view URL
    cdp_ws_url: str  # Chrome DevTools Protocol WebSocket URL
    replay_id: str  # ID of the session recording
    replay_view_url: str  # URL to view the session replay
    headless: bool  # Whether the session ran in headless mode
    stealth: bool  # Whether anti-bot stealth mode was enabled
    viewport: KernelViewport  # Browser viewport dimensions


class KernelVmStream(TypedDict, total=False):
    """VM stream data from a Kernel browser session.

    Kernel provides cloud browser environments for computer-use agents.
    This structure captures the session replay data and action/event logs.

    Log entries use ``type`` values from :data:`KERNEL_ACTION_TYPES`
    (computer control: click_mouse, type_text, scroll, etc.) and
    :data:`KERNEL_EVENT_TYPES` (navigation, log, error, etc.).
    The ``data`` field shape depends on the type — see
    :class:`KernelActionData` and :class:`KernelEventData`.
    """
    provider: str  # Always "kernel"
    session_id: str  # Kernel browser session ID
    duration_ms: int  # Total session duration
    logs: list[VmLogEntry]
    metadata: KernelVmMetadata


class PentestDatasetConfig(TypedDict, total=False):
    """Configuration for requesting a pentest dataset from the API."""
    agent_name: str
    agent_description: str
    system_prompt: str
    tools: list[dict[str, Any]]
    categories: list[str]
    num_scenarios_per_category: int
    difficulty: str  # "easy", "medium", "hard", "mixed"
    include_multi_turn: bool
