"""Bounded in-process span buffer with async flush worker.

Design properties (non-negotiable):
- Bounded memory: hard cap on buffered items.
- Never blocks the agent's hot path: enqueue is non-blocking.
- Background flusher: time-based (every 5s) OR size-based (>= 10 items).
- Graceful drain on stop() with a configurable timeout.
"""
from __future__ import annotations

import logging
import threading
import time
from typing import Any, Callable, List, Optional

logger = logging.getLogger(__name__)


class SpanBuffer:
    """Thread-safe bounded buffer.

    enqueue() never blocks; if the buffer is full, the oldest item is dropped
    and a counter is incremented. Drops are visible via dropped_count().
    """

    def __init__(self, max_size: int = 10_000):
        self._max_size = max_size
        self._items: List[Any] = []
        self._lock = threading.Lock()
        self._cond = threading.Condition(self._lock)
        self._dropped = 0

    def enqueue(self, item: Any) -> None:
        with self._cond:
            if len(self._items) >= self._max_size:
                # Drop oldest. Important: never block.
                self._items.pop(0)
                self._dropped += 1
            self._items.append(item)
            self._cond.notify()

    def drain(self, max_items: Optional[int] = None) -> List[Any]:
        with self._lock:
            if max_items is None or max_items >= len(self._items):
                drained = self._items
                self._items = []
            else:
                drained = self._items[:max_items]
                self._items = self._items[max_items:]
        return drained

    def size(self) -> int:
        with self._lock:
            return len(self._items)

    def dropped_count(self) -> int:
        with self._lock:
            return self._dropped

    def wait_for_items(self, timeout: float) -> bool:
        """Block until at least one item is present or timeout elapses."""
        with self._cond:
            if self._items:
                return True
            return self._cond.wait(timeout=timeout)


class FlushWorker:
    """Drains a SpanBuffer in a background thread.

    Flushes when EITHER:
      - flush_interval_seconds elapses, OR
      - buffer reaches flush_threshold items.
    """

    def __init__(
        self,
        buffer: SpanBuffer,
        flush_fn: Callable[[List[Any]], None],
        flush_interval_seconds: float = 5.0,
        flush_threshold: int = 10,
    ):
        self._buffer = buffer
        self._flush_fn = flush_fn
        self._interval = flush_interval_seconds
        self._threshold = flush_threshold
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None

    def start(self) -> None:
        if self._thread is not None and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, name="ashr-voice-obs-flush", daemon=True)
        self._thread.start()

    def stop(self, drain_timeout_seconds: float = 5.0) -> None:
        self._stop.set()
        thread = self._thread
        if thread is not None:
            thread.join(timeout=drain_timeout_seconds)
        # Final drain of anything left in the buffer.
        self._flush_once()

    def _run(self) -> None:
        deadline = time.monotonic() + self._interval
        while not self._stop.is_set():
            now = time.monotonic()
            wait_for = max(0.0, deadline - now)
            triggered = self._buffer.wait_for_items(timeout=wait_for)
            should_flush = (
                self._buffer.size() >= self._threshold
                or time.monotonic() >= deadline
                or self._stop.is_set()
            )
            if should_flush:
                self._flush_once()
                deadline = time.monotonic() + self._interval

    def _flush_once(self) -> None:
        items = self._buffer.drain()
        if not items:
            return
        try:
            self._flush_fn(items)
        except Exception:
            # Per safety contract, never let the flusher's failures escape into the host app.
            logger.warning("ashr_voice_obs flush failed", exc_info=True)
