"""Ashr support voice agent — runnable LiveKit worker for the demo.

Run with:

    python -m ashr_labs.voice_obs.examples.ashr_support_agent dev

Required environment:
  - LIVEKIT_URL
  - LIVEKIT_API_KEY
  - LIVEKIT_API_SECRET
  - ASHR_VOICE_OBS_API_KEY      (voice ingest key minted via create_ingest_key)
  - ASHR_VOICE_OBS_TENANT_ID    (integer tenant id matching the ingest key)

Optional environment:
  - ASHR_VOICE_OBS_BASE_URL          (default: https://api.ashr.io)
  - ASHR_VOICE_OBS_AGENT_ID          (default: ashr-support)
  - ASHR_VOICE_OBS_AGENT_VERSION
  - LIVEKIT_AGENT_NAME               (set only for explicit dispatch)

After hanging up, the session lands in the dashboard at /observability.
"""
from __future__ import annotations

import asyncio
import inspect
import logging
import os
from dataclasses import dataclass
from typing import Mapping, TYPE_CHECKING

from ..livekit import VoiceObservability
from ..livekit._recorder import CallRecorder

if TYPE_CHECKING:
    from livekit.agents import Agent, AgentSession, JobContext, WorkerOptions

try:
    from livekit.agents import (
        Agent,
        AgentSession,
        AutoSubscribe,
        JobContext,
        WorkerOptions,
        cli,
    )
except ImportError as exc:  # pragma: no cover
    Agent = AgentSession = AutoSubscribe = JobContext = WorkerOptions = cli = None  # type: ignore[assignment]
    _LIVEKIT_IMPORT_ERROR: Exception | None = exc
else:
    _LIVEKIT_IMPORT_ERROR = None


logger = logging.getLogger(__name__)


SYSTEM_PROMPT = """\
You are the Ashr voice observability support agent. You help engineers
understand and improve their voice AI deployments. Be concise and friendly.

You can answer questions about:
- Voice observability concepts: TTFA (time to first audio), TTFT (time to
  first token), turn structure, stage breakdown (STT/LLM/TTS/VAD/NLU),
  session rollups, interrupt latency, MOS, packet loss, jitter.
- How to read the Ashr dashboard: sessions list, session detail, stage strip,
  payload drawer.
- How to improve agent latency, reduce cost, and handle interruptions well.

If a user asks something outside this scope, briefly redirect them.
Keep replies under 40 words unless they explicitly ask for detail.
"""

GREETING = (
    "Hey, I'm your Ashr voice observability support agent. "
    "Ask me anything about voice metrics or your dashboard."
)


@dataclass(frozen=True)
class AgentConfig:
    ashr_api_key: str
    ashr_tenant_id: int
    ashr_base_url: str
    ashr_agent_id: str
    ashr_agent_version: str | None
    livekit_agent_name: str
    instructions: str
    greeting: str


def load_config(env: Mapping[str, str] | None = None) -> AgentConfig:
    values = os.environ if env is None else env
    tenant_text = _required(values, "ASHR_VOICE_OBS_TENANT_ID", fallback="ASHR_TENANT_ID")
    try:
        tenant_id = int(tenant_text)
    except ValueError as exc:
        raise RuntimeError("ASHR_VOICE_OBS_TENANT_ID must be an integer") from exc
    return AgentConfig(
        ashr_api_key=_required(values, "ASHR_VOICE_OBS_API_KEY", fallback="ASHR_API_KEY"),
        ashr_tenant_id=tenant_id,
        ashr_base_url=values.get("ASHR_VOICE_OBS_BASE_URL", "https://api.ashr.io"),
        ashr_agent_id=values.get("ASHR_VOICE_OBS_AGENT_ID", "ashr-support"),
        ashr_agent_version=values.get("ASHR_VOICE_OBS_AGENT_VERSION") or None,
        livekit_agent_name=values.get("LIVEKIT_AGENT_NAME", ""),
        instructions=values.get("ASHR_SUPPORT_INSTRUCTIONS", SYSTEM_PROMPT),
        greeting=values.get("ASHR_SUPPORT_GREETING", GREETING),
    )


async def entrypoint(ctx: JobContext) -> None:
    _require_livekit()
    cfg = load_config()

    await ctx.connect(auto_subscribe=AutoSubscribe.AUDIO_ONLY)
    participant = await ctx.wait_for_participant()
    room_sid = await _resolve_optional(getattr(ctx.room, "sid", None))

    stt_model = "deepgram/nova-3:en"
    llm_model = "openai/gpt-4.1-mini"
    tts_model = "cartesia/sonic-2"
    session = AgentSession(stt=stt_model, llm=llm_model, tts=tts_model)
    obs = VoiceObservability(api_key=cfg.ashr_api_key, base_url=cfg.ashr_base_url)
    adapter = obs.attach(
        session,
        agent_id=cfg.ashr_agent_id,
        agent_version=cfg.ashr_agent_version,
        tenant_id=cfg.ashr_tenant_id,
        room_id=getattr(ctx.room, "name", None),
        user_id=participant.identity,
        external_session_id=room_sid,
        # LiveKit metric classes carry only `label`, never provider/model.
        # Without these hints the cost-pricing table can't look anything up
        # and every cost lands as 0.
        stt_model=stt_model,
        llm_model=llm_model,
        tts_model=tts_model,
    )

    # Local audio capture: mix the agent's TTS frames + every remote
    # participant's mic into a single PCM stream and upload at end-of-call
    # so the dashboard's AudioPlayer can replay the conversation.
    recorder = CallRecorder()
    await recorder.start()

    def _on_track_subscribed(track, *_args):
        try:
            recorder.add_remote_track(track)
        except Exception:
            logger.warning("recorder add_remote_track failed", exc_info=True)

    ctx.room.on("track_subscribed", _on_track_subscribed)

    stop_event = asyncio.Event()
    ctx.room.on("disconnected", lambda *_: stop_event.set())

    async def _on_shutdown(reason: str) -> None:
        logger.info("ashr_support_agent shutting down: %s", reason or "unknown")
        stop_event.set()

    ctx.add_shutdown_callback(_on_shutdown)

    obs_session = adapter.session()
    session_id = obs_session.session_id if obs_session is not None else None

    try:
        await session.start(agent=Agent(instructions=cfg.instructions), room=ctx.room)
        # Tee the agent's TTS output AFTER session.start populates output.audio.
        recorder.attach_to_session(session)
        await session.say(cfg.greeting, add_to_chat_ctx=False).wait_for_playout()
        await stop_event.wait()
    finally:
        # Upload audio BEFORE obs.shutdown so the SDK's HTTP client is still
        # alive for the presign + PUT + commit round trip.
        if session_id:
            try:
                await recorder.stop_and_upload(client=obs._client, session_id=session_id)
            except Exception:
                logger.warning("recorder stop_and_upload failed", exc_info=True)
        obs.shutdown(drain_timeout_seconds=5.0)


def build_worker_options(env: Mapping[str, str] | None = None) -> WorkerOptions:
    _require_livekit()
    values = os.environ if env is None else env
    return WorkerOptions(
        entrypoint_fnc=entrypoint,
        agent_name=values.get("LIVEKIT_AGENT_NAME", ""),
    )


def main() -> None:
    _require_livekit()
    cli.run_app(build_worker_options())


def _required(env: Mapping[str, str], name: str, *, fallback: str | None = None) -> str:
    value = env.get(name) or (env.get(fallback) if fallback else None)
    if value:
        return value
    names = [name] + ([fallback] if fallback else [])
    raise RuntimeError(f"missing required environment variable: {' or '.join(names)}")


def _require_livekit() -> None:
    if _LIVEKIT_IMPORT_ERROR is not None:
        raise RuntimeError(
            "livekit-agents is not installed. Install with: pip install ashr-voice-obs[livekit]"
        ) from _LIVEKIT_IMPORT_ERROR


async def _resolve_optional(value: object) -> object:
    if inspect.isawaitable(value):
        return await value
    return value


if __name__ == "__main__":
    main()
