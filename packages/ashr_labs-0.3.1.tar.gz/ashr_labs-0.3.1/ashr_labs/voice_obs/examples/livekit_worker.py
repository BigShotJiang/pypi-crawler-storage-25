"""Minimal runnable LiveKit worker instrumented with ASHR voice observability.

Run it with:

    python -m ashr_labs.voice_obs.examples.livekit_worker dev

Required environment:
  - LIVEKIT_URL
  - LIVEKIT_API_KEY
  - LIVEKIT_API_SECRET
  - ASHR_VOICE_OBS_API_KEY (or ASHR_API_KEY)
  - ASHR_VOICE_OBS_TENANT_ID (or ASHR_TENANT_ID)

Optional environment:
  - ASHR_VOICE_OBS_BASE_URL / ASHR_BASE_URL
  - ASHR_VOICE_OBS_AGENT_ID / ASHR_VOICE_OBS_AGENT_VERSION
  - LIVEKIT_AGENT_NAME (optional; enables explicit dispatch)
  - LIVEKIT_EXAMPLE_INSTRUCTIONS
  - LIVEKIT_EXAMPLE_GREETING
  - LIVEKIT_EXAMPLE_STT_MODEL
  - LIVEKIT_EXAMPLE_LLM_MODEL
  - LIVEKIT_EXAMPLE_TTS_MODEL
"""
from __future__ import annotations

import asyncio
import inspect
import logging
import os
from dataclasses import dataclass
from typing import Mapping, TYPE_CHECKING

from ..livekit import VoiceObservability

if TYPE_CHECKING:
    from livekit.agents import Agent, AgentSession, JobContext, WorkerOptions

try:
    from livekit.agents import (
        Agent,
        AgentSession,
        AutoSubscribe,
        JobContext,
        WorkerOptions,
        cli,
    )
except ImportError as exc:  # pragma: no cover - exercised only without livekit extra
    Agent = AgentSession = AutoSubscribe = JobContext = WorkerOptions = cli = None  # type: ignore[assignment]
    _LIVEKIT_IMPORT_ERROR: Exception | None = exc
else:
    _LIVEKIT_IMPORT_ERROR = None


logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class ExampleConfig:
    ashr_api_key: str
    ashr_tenant_id: int
    ashr_base_url: str
    ashr_agent_id: str
    ashr_agent_version: str | None
    livekit_agent_name: str
    instructions: str
    greeting_template: str
    stt_model: str
    llm_model: str
    tts_model: str


def load_config_from_env(env: Mapping[str, str] | None = None) -> ExampleConfig:
    values = os.environ if env is None else env
    tenant_text = _required_env(
        values,
        "ASHR_VOICE_OBS_TENANT_ID",
        fallback="ASHR_TENANT_ID",
    )
    try:
        tenant_id = int(tenant_text)
    except ValueError as exc:
        raise RuntimeError(
            "ASHR_VOICE_OBS_TENANT_ID must be an integer tenant id"
        ) from exc

    return ExampleConfig(
        ashr_api_key=_required_env(
            values,
            "ASHR_VOICE_OBS_API_KEY",
            fallback="ASHR_API_KEY",
        ),
        ashr_tenant_id=tenant_id,
        ashr_base_url=values.get(
            "ASHR_VOICE_OBS_BASE_URL",
            values.get("ASHR_BASE_URL", "https://api.ashr.io"),
        ),
        ashr_agent_id=values.get("ASHR_VOICE_OBS_AGENT_ID", "livekit-example"),
        ashr_agent_version=values.get("ASHR_VOICE_OBS_AGENT_VERSION") or None,
        livekit_agent_name=values.get("LIVEKIT_AGENT_NAME", ""),
        instructions=values.get(
            "LIVEKIT_EXAMPLE_INSTRUCTIONS",
            "You are a concise, helpful realtime voice assistant.",
        ),
        greeting_template=values.get(
            "LIVEKIT_EXAMPLE_GREETING",
            "Hi {participant_identity}, I'm the ASHR voice observability demo. Ask me anything.",
        ),
        stt_model=values.get("LIVEKIT_EXAMPLE_STT_MODEL", "deepgram/nova-3:en"),
        llm_model=values.get("LIVEKIT_EXAMPLE_LLM_MODEL", "openai/gpt-4.1-mini"),
        tts_model=values.get("LIVEKIT_EXAMPLE_TTS_MODEL", "cartesia/sonic-2"),
    )


async def entrypoint(ctx: JobContext) -> None:
    _require_livekit()
    config = load_config_from_env()

    await ctx.connect(auto_subscribe=AutoSubscribe.AUDIO_ONLY)
    participant = await ctx.wait_for_participant()
    room_sid = await _resolve_optional_value(getattr(ctx.room, "sid", None))

    session = AgentSession(
        stt=config.stt_model,
        llm=config.llm_model,
        tts=config.tts_model,
    )
    obs = VoiceObservability(
        api_key=config.ashr_api_key,
        base_url=config.ashr_base_url,
    )
    obs.attach(
        session,
        agent_id=config.ashr_agent_id,
        agent_version=config.ashr_agent_version,
        tenant_id=config.ashr_tenant_id,
        room_id=getattr(ctx.room, "name", None),
        user_id=participant.identity,
        external_session_id=room_sid,
    )

    stop_event = asyncio.Event()

    def _on_disconnected(*_: object) -> None:
        stop_event.set()

    async def _on_shutdown(reason: str) -> None:
        logger.info("livekit example worker shutting down: %s", reason or "unknown")
        stop_event.set()

    ctx.room.on("disconnected", _on_disconnected)
    ctx.add_shutdown_callback(_on_shutdown)

    try:
        await session.start(
            agent=Agent(instructions=config.instructions),
            room=ctx.room,
        )
        greeting = _format_greeting(config.greeting_template, participant.identity)
        await session.say(greeting, add_to_chat_ctx=False).wait_for_playout()
        await stop_event.wait()
    finally:
        obs.shutdown(drain_timeout_seconds=5.0)


def build_worker_options(env: Mapping[str, str] | None = None) -> WorkerOptions:
    _require_livekit()
    values = os.environ if env is None else env
    return WorkerOptions(
        entrypoint_fnc=entrypoint,
        # Empty string keeps room dispatch automatic for local demos.
        # Set LIVEKIT_AGENT_NAME only when you intentionally want explicit dispatch.
        agent_name=values.get("LIVEKIT_AGENT_NAME", ""),
    )


def main() -> None:
    _require_livekit()
    cli.run_app(build_worker_options())


def _format_greeting(template: str, participant_identity: str) -> str:
    try:
        return template.format(participant_identity=participant_identity)
    except Exception:
        logger.warning(
            "livekit example greeting template is invalid; using raw string",
            exc_info=True,
        )
        return template


def _required_env(
    env: Mapping[str, str],
    name: str,
    *,
    fallback: str | None = None,
) -> str:
    value = env.get(name) or (env.get(fallback) if fallback else None)
    if value:
        return value
    names = [name]
    if fallback:
        names.append(fallback)
    raise RuntimeError(f"missing required environment variable: {' or '.join(names)}")


def _require_livekit() -> None:
    if _LIVEKIT_IMPORT_ERROR is not None:
        raise RuntimeError(
            "livekit-agents is not installed. Install the SDK with the livekit extra: "
            "pip install ashr-voice-obs[livekit]"
        ) from _LIVEKIT_IMPORT_ERROR


async def _resolve_optional_value(value: object) -> object:
    if inspect.isawaitable(value):
        return await value
    return value


if __name__ == "__main__":
    main()
