"""Provider-agnostic cost estimation for voice stages.

LiveKit metric payloads do NOT carry cost — they expose token, character,
and audio-duration counts only. We compute USD cost here from a small
built-in pricing table so the dashboard shows real dollars instead of
zeros.

# Anchoring

All rates below are the providers' on-demand / overage / pay-as-you-go
rates as of April 2026, sourced from each provider's public pricing page.
We deliberately use overage rates (not effective in-plan rates) because:

1. Overage is what every plan eventually charges past included credits,
   so it's the marginal cost the customer actually feels at scale.
2. In-plan rates depend on the customer's plan tier (Free / Pro / Scale)
   which the SDK doesn't know.
3. Overestimating cost is the safer default — under-counting hides
   spend. The pricing table can be overridden per-tenant later.

Sources:
- OpenAI:    https://openai.com/api/pricing/
- Anthropic: https://platform.claude.com/docs/en/about-claude/pricing
- Deepgram:  https://deepgram.com/pricing
- Cartesia:  https://cartesia.ai/pricing
- ElevenLabs: https://elevenlabs.io/pricing/api

# What's NOT included

These rates cover the *AI provider* cost only. They do NOT include:

- LiveKit Agent Session Minutes ($0.01/min runtime fee on top of model
  rates). Use infra_cost_usd("livekit", session_duration_seconds).
- LiveKit Cloud bandwidth, recording egress, or session report storage.

Adapters can layer infra cost in via Session.add_infra_cost() (not yet
exposed) or callers can sum it themselves at session close.

# Updating

When providers change prices, edit the dicts below. The unit tests pin
specific calculations (test_livekit_pricing.py); update those alongside.
"""
from __future__ import annotations

import re
from typing import Optional


# (provider, model) -> (input_per_1m_tokens_usd,
#                       output_per_1m_tokens_usd,
#                       cached_input_per_1m_tokens_usd)
_LLM_PRICES: dict[tuple[str, str], tuple[float, float, float]] = {
    # OpenAI 4.1 family (cache hits = 25% of input per OpenAI docs)
    ("openai", "gpt-4.1"):       (2.00, 8.00, 0.50),
    ("openai", "gpt-4.1-mini"):  (0.40, 1.60, 0.10),
    ("openai", "gpt-4.1-nano"):  (0.10, 0.40, 0.025),
    # OpenAI 4o family (legacy but still used)
    ("openai", "gpt-4o"):        (2.50, 10.00, 1.25),
    ("openai", "gpt-4o-mini"):   (0.15, 0.60, 0.075),
    # Anthropic Claude (Anthropic.com docs as of April 2026; cache reads
    # are 10% of base input per their prompt-caching pricing).
    ("anthropic", "claude-opus-4-7"):    (5.00, 25.00, 0.50),
    ("anthropic", "claude-opus-4-6"):    (5.00, 25.00, 0.50),
    ("anthropic", "claude-opus-4-5"):    (5.00, 25.00, 0.50),
    ("anthropic", "claude-opus-4-1"):    (15.00, 75.00, 1.50),
    ("anthropic", "claude-opus-4"):      (15.00, 75.00, 1.50),
    ("anthropic", "claude-sonnet-4-6"):  (3.00, 15.00, 0.30),
    ("anthropic", "claude-sonnet-4-5"):  (3.00, 15.00, 0.30),
    ("anthropic", "claude-sonnet-4"):    (3.00, 15.00, 0.30),
    ("anthropic", "claude-haiku-4-5"):   (1.00,  5.00, 0.10),
    ("anthropic", "claude-haiku-3-5"):   (0.80,  4.00, 0.08),
}


# (provider, model) -> USD per second of audio
_STT_PRICES_PER_SEC: dict[tuple[str, str], float] = {
    # Deepgram pay-as-you-go: Nova-3 monolingual $0.0077/min
    ("deepgram", "nova-3"):              0.0077 / 60,
    ("deepgram", "nova-3:en"):           0.0077 / 60,
    ("deepgram", "nova-3-general"):      0.0077 / 60,
    ("deepgram", "nova-3-multilingual"): 0.0092 / 60,
    ("deepgram", "nova-3-medical"):      0.0145 / 60,
    ("deepgram", "nova-2"):              0.0043 / 60,
    # OpenAI Whisper hosted: $0.006/min
    ("openai", "whisper-1"):             0.006 / 60,
    ("openai", "gpt-4o-transcribe"):     0.006 / 60,
}


# (provider, model) -> USD per character synthesized.
# Anchored on each provider's overage / on-demand rate. These are the
# marginal rates a customer pays past included plan credits.
_TTS_PRICES_PER_CHAR: dict[tuple[str, str], float] = {
    # Cartesia: Pro plan ($50/mo for 1M chars) ≈ $0.05/1k chars; Scale plan
    # ($299/mo for 8M chars) ≈ $0.037/1k. Anchoring on Pro overage as the
    # mid-market default since Scale is enterprise-tier.
    ("cartesia", "sonic-2"):              0.05 / 1000,
    ("cartesia", "sonic-3"):              0.05 / 1000,
    ("cartesia", "sonic-turbo"):          0.05 / 1000,
    # ElevenLabs Creator overage: $0.30/1k chars on Multilingual v2;
    # Flash and Turbo charge 0.5 credits per character → $0.15/1k.
    ("elevenlabs", "eleven-multilingual-v2"): 0.30 / 1000,
    ("elevenlabs", "eleven-flash-v2"):        0.15 / 1000,
    ("elevenlabs", "eleven-turbo-v2"):        0.15 / 1000,
    ("elevenlabs", "eleven-turbo-v2-5"):      0.15 / 1000,
}


# Stack-level infrastructure cost (per second of session duration).
# These ride OUTSIDE the model-pricing table because they're charged per
# session-minute by the voice infra provider, not per token/character.
_INFRA_PRICES_PER_SEC: dict[str, float] = {
    # LiveKit Agent Session Minutes: $0.01/min runtime
    "livekit":  0.01 / 60,
}


# Match dated model suffixes like "-2024-11-20" or "-20241120" so providers
# that return concrete versioned IDs still hit the pricing table.
_DATE_SUFFIX = re.compile(r"-\d{4}-?\d{2}-?\d{2}$")


def _normalize(name: Optional[str]) -> str:
    return (name or "").strip().lower()


def _strip_date_suffix(model: str) -> str:
    """Drop dated version suffixes so concrete API IDs hit the table.

    "gpt-4o-2024-11-20"  -> "gpt-4o"
    "gpt-4o-20241120"    -> "gpt-4o"
    "claude-sonnet-4-6"  -> "claude-sonnet-4-6"  (NOT a date; keep as-is)
    "claude-sonnet-4-6-20251001" -> "claude-sonnet-4-6"
    """
    return _DATE_SUFFIX.sub("", model)


def _split_combined(provider: Optional[str], model: Optional[str]) -> tuple[str, str]:
    """Some agents pass `model="openai/gpt-4.1-mini"` with provider unset.
    Split on the first `/` so the lookup still works either way; also
    drop dated version suffixes so e.g. "openai/gpt-4o-2024-11-20" still
    resolves to "openai/gpt-4o".
    """
    p = _normalize(provider)
    m = _normalize(model)
    if not p and "/" in m:
        p, _, m = m.partition("/")
    m = _strip_date_suffix(m)
    return p, m


def llm_cost_usd(
    provider: Optional[str],
    model: Optional[str],
    *,
    prompt_tokens: int = 0,
    completion_tokens: int = 0,
    cached_tokens: int = 0,
) -> float:
    """Return the estimated USD cost of one LLM call, or 0.0 if unknown."""
    p, m = _split_combined(provider, model)
    price = _LLM_PRICES.get((p, m))
    if not price:
        return 0.0
    in_per_m, out_per_m, cached_per_m = price
    cached = max(0, int(cached_tokens or 0))
    uncached_input = max(0, int(prompt_tokens or 0) - cached)
    return (
        uncached_input * in_per_m / 1_000_000
        + cached * cached_per_m / 1_000_000
        + max(0, int(completion_tokens or 0)) * out_per_m / 1_000_000
    )


def stt_cost_usd(
    provider: Optional[str],
    model: Optional[str],
    *,
    audio_duration_seconds: float,
) -> float:
    """Return the estimated USD cost of one STT call, or 0.0 if unknown."""
    p, m = _split_combined(provider, model)
    rate = _STT_PRICES_PER_SEC.get((p, m))
    if not rate:
        return 0.0
    return max(0.0, float(audio_duration_seconds or 0.0)) * rate


def tts_cost_usd(
    provider: Optional[str],
    model: Optional[str],
    *,
    characters: int = 0,
    audio_duration_seconds: float = 0.0,  # reserved for per-second-only providers
) -> float:
    """Return the estimated USD cost of one TTS call, or 0.0 if unknown.

    Prefers per-character pricing (most accurate). Per-second TTS pricing is
    not currently used by the table, but the parameter is accepted so callers
    don't have to special-case it.
    """
    del audio_duration_seconds  # unused for now; here for future per-sec models
    p, m = _split_combined(provider, model)
    per_char = _TTS_PRICES_PER_CHAR.get((p, m))
    if per_char is None:
        return 0.0
    return max(0, int(characters or 0)) * per_char


def infra_cost_usd(stack: Optional[str], session_duration_seconds: float) -> float:
    """Return the estimated USD cost of the underlying voice-infra stack
    for this session's duration. Returns 0.0 for unknown stacks.

    NOT a substitute for the model-rate sum — adapters/callers should
    add this on top of the per-stage cost roll-up to get total session
    spend. Keeps model and infra cost separate so per-tenant overrides
    of one don't accidentally clobber the other.

    Known stacks: "livekit" ($0.01/min Agent Session Minutes).
    """
    rate = _INFRA_PRICES_PER_SEC.get(_normalize(stack))
    if rate is None:
        return 0.0
    return max(0.0, float(session_duration_seconds or 0.0)) * rate


__all__ = ["llm_cost_usd", "stt_cost_usd", "tts_cost_usd", "infra_cost_usd"]
