"""Local audio capture for LiveKit-driven voice agents.

Mixes the agent's TTS output (intercepted by inserting a tee AudioOutput
into AgentSession's output chain) with each remote participant's
microphone track (subscribed via livekit.rtc.AudioStream) into a single
PCM buffer using livekit.rtc.AudioMixer. At end-of-call, encodes the
buffer as WAV and uploads it through the SDK's existing presign +
commit path.

This module is the only piece of the SDK that imports livekit.rtc and
livekit.agents.voice.io. Both are guarded behind the same lazy-import
pattern as the rest of the LiveKit plugin so installing without the
livekit extra still works.
"""
from __future__ import annotations

import asyncio
import io
import logging
import wave
from typing import Any, AsyncIterator, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from livekit.rtc import AudioFrame as _AF

logger = logging.getLogger(__name__)


# AgentSession's default audio output sample rate. Both the TTS-side tee
# and the mic-side AudioStream are pinned to this so the AudioMixer doesn't
# have to resample.
TARGET_SAMPLE_RATE = 24000
TARGET_CHANNELS = 1


# Lazy-import marker. Real imports happen inside CallRecorder.__init__ so
# `import ashr_labs.voice_obs` keeps working in environments without the
# livekit extra installed.
_LK_IMPORT_ERROR: Optional[Exception] = None
try:  # pragma: no cover - imported when livekit extra is installed
    from livekit.rtc import (  # noqa: F401
        AudioFrame,
        AudioMixer,
        AudioStream,
        TrackKind,
    )
    from livekit.agents.voice.io import AudioOutput, AudioOutputCapabilities
except Exception as exc:  # pragma: no cover
    _LK_IMPORT_ERROR = exc


class _FrameQueue:
    """Asyncio-backed queue exposed as an AsyncIterator[AudioFrame] so
    the AudioMixer can pull from it. A single producer pushes frames via
    push(); end_input() closes the iterator."""

    def __init__(self) -> None:
        self._q: asyncio.Queue = asyncio.Queue(maxsize=2048)
        self._closed = False

    def push(self, frame: "_AF") -> None:
        if self._closed:
            return
        try:
            self._q.put_nowait(frame)
        except asyncio.QueueFull:
            logger.warning("CallRecorder: tee queue full, dropping frame")

    def end_input(self) -> None:
        if self._closed:
            return
        self._closed = True
        try:
            self._q.put_nowait(None)
        except asyncio.QueueFull:
            pass

    def __aiter__(self) -> "AsyncIterator[_AF]":
        return self

    async def __anext__(self) -> "_AF":
        item = await self._q.get()
        if item is None:
            raise StopAsyncIteration
        return item


class _RemoteFrameAdapter:
    """Adapter that turns livekit.rtc.AudioStream (which yields
    AudioFrameEvent) into an async iterator of plain AudioFrame, which
    is what AudioMixer's add_stream() expects."""

    def __init__(self, audio_stream: Any) -> None:
        self._stream = audio_stream
        self._inner = aiter(audio_stream)

    def __aiter__(self) -> "AsyncIterator[_AF]":
        return self

    async def __anext__(self) -> "_AF":
        event = await self._inner.__anext__()
        # AudioStream yields AudioFrameEvent which has a `.frame` attribute.
        return getattr(event, "frame", event)


def _make_tee_output(sink: Any, frame_queue: _FrameQueue) -> Any:
    """Build a TeeAudioOutput that wraps `sink`, forwarding all
    capture_frame / flush / clear_buffer calls down the chain while
    teeing each frame into `frame_queue` for the recorder.

    Defined here as a function (not a top-level class) so it picks up
    the lazily-imported AudioOutput base only when livekit-agents is
    installed."""
    if _LK_IMPORT_ERROR is not None:
        raise RuntimeError("livekit-agents not installed") from _LK_IMPORT_ERROR

    class _TeeAudioOutput(AudioOutput):  # type: ignore[misc, valid-type]
        def __init__(self, *, next_sink: Any, queue: _FrameQueue) -> None:
            super().__init__(
                label="ashr-recorder-tee",
                capabilities=AudioOutputCapabilities(pause=False),
                next_in_chain=next_sink,
                sample_rate=getattr(next_sink, "sample_rate", TARGET_SAMPLE_RATE),
            )
            self._queue = queue

        async def capture_frame(self, frame: Any) -> None:
            await super().capture_frame(frame)
            try:
                self._queue.push(frame)
            except Exception:
                logger.warning("CallRecorder: failed to tee TTS frame", exc_info=True)
            if self.next_in_chain:
                await self.next_in_chain.capture_frame(frame)

        def flush(self) -> None:
            super().flush()
            if self.next_in_chain:
                self.next_in_chain.flush()

        def clear_buffer(self) -> None:
            if self.next_in_chain:
                self.next_in_chain.clear_buffer()

    return _TeeAudioOutput(next_sink=sink, queue=frame_queue)


class CallRecorder:
    """Records mixed call audio and uploads it to ashr at end-of-call.

    Lifecycle:
        rec = CallRecorder()
        await rec.start()
        # before session.say(...)
        rec.attach_to_session(agent_session)
        # whenever a remote audio track is subscribed
        rec.add_remote_track(track)
        ...
        await rec.stop_and_upload(client=obs_client, session_id=session_id)
    """

    def __init__(
        self,
        *,
        sample_rate: int = TARGET_SAMPLE_RATE,
        channels: int = TARGET_CHANNELS,
    ) -> None:
        if _LK_IMPORT_ERROR is not None:
            raise RuntimeError(
                "livekit-agents/livekit-rtc not installed; install with "
                "pip install ashr-voice-obs[livekit]"
            ) from _LK_IMPORT_ERROR
        self._sample_rate = sample_rate
        self._channels = channels
        self._mixer = AudioMixer(sample_rate=sample_rate, num_channels=channels)
        self._tts_queue = _FrameQueue()
        self._mixer.add_stream(self._tts_queue)
        self._remote_streams: list[Any] = []
        self._pcm = bytearray()
        self._consume_task: Optional[asyncio.Task] = None
        self._started = False
        self._stopped = False

    async def start(self) -> None:
        if self._started:
            return
        self._started = True
        loop = asyncio.get_event_loop()
        self._consume_task = loop.create_task(self._consume_mixer())

    def attach_to_session(self, session: Any) -> None:
        """Insert a tee AudioOutput into the AgentSession's output chain
        so we capture every TTS frame before it's sent to the room."""
        existing = session.output.audio
        if existing is None:
            logger.warning(
                "CallRecorder.attach_to_session: session.output.audio is None; "
                "TTS frames won't be captured. Make sure attach_to_session is "
                "called AFTER session.start()."
            )
            return
        session.output.audio = _make_tee_output(existing, self._tts_queue)

    def add_remote_track(self, track: Any) -> None:
        """Subscribe a remote audio track and feed its frames into the mixer.

        Caller is responsible for filtering — typically you call this from a
        room.on('track_subscribed') handler when track.kind == KIND_AUDIO."""
        kind = getattr(track, "kind", None)
        if kind is not None and kind != TrackKind.KIND_AUDIO:
            return
        try:
            stream = AudioStream(
                track,
                sample_rate=self._sample_rate,
                num_channels=self._channels,
            )
            adapter = _RemoteFrameAdapter(stream)
            self._remote_streams.append(stream)
            self._mixer.add_stream(adapter)
            logger.info("CallRecorder: subscribed remote audio track")
        except Exception:
            logger.warning(
                "CallRecorder: failed to subscribe track %s",
                getattr(track, "sid", "?"),
                exc_info=True,
            )

    async def _consume_mixer(self) -> None:
        try:
            async for frame in self._mixer:
                data = frame.data
                if hasattr(data, "tobytes"):
                    self._pcm.extend(bytes(data.tobytes()))
                else:
                    self._pcm.extend(bytes(data))
        except asyncio.CancelledError:
            pass
        except Exception:
            logger.warning("CallRecorder: mixer consumer aborted", exc_info=True)

    async def stop_and_upload(
        self, *, client: Any, session_id: str
    ) -> bool:
        """Finalize the recording and upload it via client.upload_audio.

        Returns True if upload succeeded (which implies the session row's
        audio_object_key now points at the uploaded WAV)."""
        if self._stopped:
            return False
        self._stopped = True
        # Stop the TTS tee. The mixer drains until all streams report
        # exhausted, then yields no more frames.
        self._tts_queue.end_input()
        # Closing remote AudioStreams ends their iterators so the mixer
        # can finalize.
        for stream in self._remote_streams:
            close = getattr(stream, "aclose", None)
            if close is not None:
                try:
                    await close()
                except Exception:
                    logger.debug("CallRecorder: remote stream aclose error", exc_info=True)
        try:
            await asyncio.wait_for(self._mixer.aclose(), timeout=2.0)
        except Exception:
            logger.debug("CallRecorder: mixer aclose timed out", exc_info=True)
        if self._consume_task is not None:
            try:
                await asyncio.wait_for(self._consume_task, timeout=2.0)
            except Exception:
                self._consume_task.cancel()

        if not self._pcm:
            logger.info("CallRecorder: no audio captured, skipping upload")
            return False

        sample_width = 2  # int16
        duration_ms = int(
            len(self._pcm) / sample_width / self._channels / self._sample_rate * 1000
        )
        wav_bytes = _encode_wav(self._pcm, self._sample_rate, self._channels, sample_width)

        try:
            ok = client.upload_audio(
                session_id=session_id,
                audio=wav_bytes,
                duration_ms=duration_ms,
                codec="wav",
            )
        except Exception:
            logger.warning("CallRecorder: upload_audio raised", exc_info=True)
            return False
        if not ok:
            logger.warning("CallRecorder: upload_audio returned False")
        else:
            logger.info(
                "CallRecorder: uploaded %d ms of audio (%d KB) for session %s",
                duration_ms, len(wav_bytes) // 1024, session_id,
            )
        return bool(ok)


def _encode_wav(pcm: bytes, sample_rate: int, channels: int, sample_width: int) -> bytes:
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(channels)
        w.setsampwidth(sample_width)
        w.setframerate(sample_rate)
        w.writeframes(bytes(pcm))
    return buf.getvalue()


__all__ = ["CallRecorder"]
