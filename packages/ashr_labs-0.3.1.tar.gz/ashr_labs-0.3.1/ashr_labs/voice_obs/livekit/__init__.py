"""LiveKit plugin for ASHR voice observability.

Two-line setup:

    from ashr_labs.voice_obs.livekit import VoiceObservability
    obs = VoiceObservability(api_key=os.environ["ASHR_API_KEY"])
    obs.attach(session, agent_id="support_v3", agent_version="v42")

The plugin subscribes to LiveKit's AgentSession event bus and maps native
events to ASHR Turn / Stage / TurnEvent spans. It does NOT require livekit
to be installed at SDK import time — the import is lazy at attach() time.

Event mapping (LiveKit AgentSession events -> ASHR spans), based on
livekit-agents 1.5.x event shapes with compatibility for the older test
event payloads used in this repo:
  user_state_changed.new_state:speaking      -> open user turn, user_speech_start event
  user_state_changed.new_state:listening     -> close user turn, user_speech_end event
  agent_state_changed.new_state:speaking     -> open agent turn, agent_speech_start
  agent_state_changed.new_state:listening    -> close agent turn, agent_speech_end
  user_input_transcribed (is_final=True)     -> set transcript on user turn
  metrics_collected.metrics: STTMetrics      -> stt stage on user turn
  metrics_collected.metrics: LLMMetrics      -> llm stage on agent turn
  metrics_collected.metrics: TTSMetrics      -> tts stage on agent turn
  metrics_collected.metrics: EOUMetrics      -> ttfa hint
  metrics_collected.metrics: InterruptionMetrics -> barge_in event w/ interrupt_latency_ms
  agent_false_interruption                   -> failed_interrupt event
  speech_interrupted                         -> older compatibility path for barge_in
"""
from __future__ import annotations

import logging
import time
from contextlib import ExitStack
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Optional

from .. import Client, Session as ObsSession
from ..schemas import (
    LLMPayload,
    Message,
    STTPartial,
    STTPayload,
    ToolCall,
    TTSPayload,
)
from ._pricing import llm_cost_usd, stt_cost_usd, tts_cost_usd

logger = logging.getLogger(__name__)


class VoiceObservability:
    """Top-level LiveKit plugin handle.

    Lifecycle:
      obs = VoiceObservability(api_key=...)
      obs.attach(lk_session, agent_id="bot", agent_version="v1")
      ... agent runs ...
      obs.shutdown()  # optional; recommended in graceful shutdown
    """

    def __init__(
        self,
        *,
        api_key: str,
        base_url: str = "https://api.ashr.io",
        client: Optional[Client] = None,
    ):
        self._client = client or Client(api_key=api_key, base_url=base_url)
        self._adapters: Dict[int, "_LiveKitAdapter"] = {}

    def attach(
        self,
        livekit_session: Any,
        *,
        agent_id: str,
        agent_version: Optional[str] = None,
        tenant_id: int = 0,
        room_id: Optional[str] = None,
        user_id: Optional[str] = None,
        external_session_id: Optional[str] = None,
        stt_model: Optional[str] = None,
        llm_model: Optional[str] = None,
        tts_model: Optional[str] = None,
    ) -> "_LiveKitAdapter":
        """Attach observability to a LiveKit AgentSession.

        Pass `stt_model` / `llm_model` / `tts_model` with the same strings
        used to construct AgentSession (e.g. "openai/gpt-4.1-mini"). LiveKit's
        STTMetrics / LLMMetrics / TTSMetrics expose only `label`, never
        `provider`/`model`, so without these hints the cost-pricing table
        can't look anything up and every cost lands as 0. Provider may be
        embedded in the model string ("provider/model"); we split on `/`.
        """
        adapter = _LiveKitAdapter(
            client=self._client,
            agent_id=agent_id,
            agent_version=agent_version,
            tenant_id=tenant_id,
            room_id=_stringify_optional(room_id),
            user_id=_stringify_optional(user_id),
            external_session_id=_stringify_optional(external_session_id),
            stt_model=stt_model,
            llm_model=llm_model,
            tts_model=tts_model,
        )
        adapter.bind(livekit_session)
        self._adapters[id(livekit_session)] = adapter
        return adapter

    def shutdown(self, drain_timeout_seconds: float = 5.0) -> None:
        for adapter in self._adapters.values():
            adapter.close()
        self._adapters.clear()
        self._client.shutdown(drain_timeout_seconds=drain_timeout_seconds)


class _LiveKitAdapter:
    """Maps a single LiveKit AgentSession to one ASHR Session.

    The adapter is event-driven: every LiveKit callback we care about funnels
    through `dispatch(event_name, data)`. That makes the adapter trivially
    testable without a real LiveKit runtime — you can call dispatch() with
    synthetic events.
    """

    def __init__(
        self,
        *,
        client: Client,
        agent_id: str,
        agent_version: Optional[str],
        tenant_id: int,
        room_id: Optional[str],
        user_id: Optional[str],
        external_session_id: Optional[str],
        stt_model: Optional[str] = None,
        llm_model: Optional[str] = None,
        tts_model: Optional[str] = None,
    ):
        self._client = client
        self._agent_id = agent_id
        self._agent_version = agent_version
        self._tenant_id = tenant_id
        self._room_id = room_id
        self._user_id = user_id
        self._external_session_id = external_session_id
        # Pricing-table fallbacks for when the LiveKit metric lacks
        # provider/model (it always does — those classes carry only `label`).
        self._stt_provider, self._stt_model = _split_provider_model(stt_model)
        self._llm_provider, self._llm_model = _split_provider_model(llm_model)
        self._tts_provider, self._tts_model = _split_provider_model(tts_model)

        self._session: Optional[ObsSession] = None
        self._stack = ExitStack()
        # Active turn handles + their __exit__ callables.
        self._user_turn = None
        self._user_turn_exit = None
        self._agent_turn = None
        self._agent_turn_exit = None

        # Latency bookkeeping (monotonic clock per safety contract).
        self._user_speech_end_monotonic: Optional[float] = None
        self._last_eou_ms: Optional[int] = None
        self._last_llm_ttft_ms: Optional[int] = None

    # ------------------------------------------------------------------ binding

    def bind(self, lk_session: Any) -> None:
        """Subscribe to LiveKit's event bus.

        LiveKit's AgentSession exposes a typical pyee-style `on(event, handler)`
        API. We register one handler per event we care about. If the API is
        absent (e.g. tests passing a fake), bind() is a no-op for that event.
        """
        self._open_session()

        def safe_handler(event_name: str):
            def _h(data=None):
                try:
                    self.dispatch(event_name, data)
                except Exception:
                    logger.warning("ashr_voice_obs livekit handler %s failed",
                                   event_name, exc_info=True)
            return _h

        if not hasattr(lk_session, "on"):
            return  # nothing to subscribe to; tests will dispatch directly.

        # Real livekit-agents 1.5.x emits exactly these events on AgentSession.
        # speech_committed / speech_interrupted from earlier docs do NOT exist;
        # interruption signals come via InterruptionMetrics + agent_false_interruption.
        # We still subscribe to speech_interrupted for backward compatibility with
        # our existing tests and any early adopters of the older event mapping.
        for event_name in (
            "user_state_changed",
            "agent_state_changed",
            "user_input_transcribed",
            "metrics_collected",
            "conversation_item_added",
            "speech_interrupted",
            "agent_false_interruption",
            "close",
        ):
            try:
                lk_session.on(event_name, safe_handler(event_name))
            except Exception:
                logger.warning("ashr_voice_obs failed to bind livekit event %s",
                               event_name, exc_info=True)

    def _open_session(self) -> None:
        if self._session is not None:
            return
        self._session = self._client.start_session(
            agent_id=self._agent_id,
            agent_version=self._agent_version,
            tenant_id=self._tenant_id,
            transport="webrtc",
            room_id=self._room_id,
            user_id=self._user_id,
            external_session_id=self._external_session_id,
        )

    # ------------------------------------------------------------------ public

    def session(self) -> Optional[ObsSession]:
        return self._session

    def close(self, *, reason: str = "agent_left") -> None:
        """Close any open turns and end the session."""
        try:
            if self._user_turn is not None:
                self._close_user_turn()
            if self._agent_turn is not None:
                self._close_agent_turn()
        finally:
            if self._session is not None:
                self._session.end(reason=reason)
                self._session = None

    # ------------------------------------------------------------------ dispatcher

    def dispatch(self, event_name: str, data: Any = None) -> None:
        if self._session is None:
            self._open_session()
        handler = _DISPATCH.get(event_name)
        if handler is None:
            return
        handler(self, data)

    # ------------------------------------------------------------------ event handlers

    def _on_user_state_changed(self, data: Any) -> None:
        state = _read(data, "new_state", "state")
        if state == "speaking" and self._user_turn is None:
            self._open_user_turn()
            if self._user_turn is not None:
                self._user_turn.event("user_speech_start")
        elif state in ("listening", "away") and self._user_turn is not None:
            self._user_speech_end_monotonic = time.monotonic()
            self._user_turn.event("user_speech_end")
            self._close_user_turn()

    def _on_agent_state_changed(self, data: Any) -> None:
        state = _read(data, "new_state", "state")
        if state == "speaking":
            if self._agent_turn is None:
                self._open_agent_turn()
            if self._agent_turn is not None:
                ttfa_ms = self._compute_ttfa_ms()
                self._agent_turn._ttfa_hint = ttfa_ms  # noqa: SLF001
                self._agent_turn.event("agent_speech_start")
        elif state in ("listening", "idle") and self._agent_turn is not None:
            self._agent_turn.event("agent_speech_end")
            self._close_agent_turn()

    def _on_agent_false_interruption(self, data: Any) -> None:
        """LiveKit fires this when the agent paused for what looked like a barge-in
        but the user wasn't actually interrupting. Record it as a failed_interrupt
        on whichever turn is currently open."""
        target = self._user_turn or self._agent_turn
        if target is None:
            return
        target.event("failed_interrupt", {"resumed": bool(_read(data, "resumed", default=True))})

    def _on_close(self, data: Any) -> None:
        # LiveKit session closing — flush whatever turns are open.
        reason = _read(data, "reason", default="agent_left")
        try:
            self.close(reason=str(reason) if reason else "agent_left")
        except Exception:
            logger.warning("ashr_voice_obs close handler failed", exc_info=True)

    def _on_user_input_transcribed(self, data: Any) -> None:
        if self._user_turn is None:
            self._open_user_turn()
        if self._user_turn is None:
            return
        text = _read(data, "transcript", default=_read(data, "text", default=""))
        is_final = bool(_read(data, "is_final", default=True))
        if is_final and text:
            self._user_turn.set_transcript(text)

    def _on_conversation_item_added(self, data: Any) -> None:
        """LiveKit fires this when a chat item (user or agent) is committed
        to the session's chat history. For the agent side this is the only
        path that exposes the spoken text — agent_state_changed never
        carries the transcript. We use it to populate the active turn's
        transcript in both directions."""
        item = _read(data, "item", default=data)
        text = _extract_chat_text(item)
        if not text:
            return
        role = (_read(item, "role") or "").lower()
        if role == "assistant" and self._agent_turn is not None:
            self._agent_turn.set_transcript(text)
        elif role == "user" and self._user_turn is not None:
            self._user_turn.set_transcript(text)

    def _on_metrics_collected(self, data: Any) -> None:
        metric = _unwrap_metrics(data)
        kind = _classify_metrics(metric)
        if kind == "stt":
            self._record_stt(metric)
        elif kind == "llm":
            self._record_llm(metric)
        elif kind == "tts":
            self._record_tts(metric)
        elif kind == "eou":
            self._last_eou_ms = int(_read(metric, "end_of_utterance_delay", default=0) * 1000) or None
        elif kind == "interruption":
            self._record_interruption(metric)

    def _on_speech_interrupted(self, data: Any) -> None:
        if self._agent_turn is None:
            return
        # If we have a user turn, mark it interrupting the agent.
        if self._user_turn is not None:
            interrupt_latency = int(_read(data, "interrupt_latency_ms", default=0)) or None
            self._user_turn.mark_interrupted(
                by_turn_id=self._agent_turn.turn_id,
                interrupt_latency_ms=interrupt_latency or 0,
            )
            self._user_turn.event("barge_in", {
                "agent_turn_id": self._agent_turn.turn_id,
                "interrupt_latency_ms": interrupt_latency,
            })
        self._close_agent_turn()

    def _record_interruption(self, data: Any) -> None:
        """Handle LiveKit's newer InterruptionMetrics shape."""
        if self._agent_turn is None or self._user_turn is None:
            return
        interrupt_latency_ms = _read(data, "interrupt_latency_ms")
        if interrupt_latency_ms is None:
            interrupt_latency_s = float(_read(data, "interrupt_latency", default=0.0) or 0.0)
            interrupt_latency = int(interrupt_latency_s * 1000)
        else:
            interrupt_latency = int(interrupt_latency_ms or 0)
        self._user_turn.mark_interrupted(
            by_turn_id=self._agent_turn.turn_id,
            interrupt_latency_ms=interrupt_latency,
        )
        self._user_turn.event("barge_in", {
            "agent_turn_id": self._agent_turn.turn_id,
            "interrupt_latency_ms": interrupt_latency or None,
        })
        self._close_agent_turn()

    # ------------------------------------------------------------------ stage recorders

    def _record_stt(self, data: Any) -> None:
        if self._user_turn is None:
            return
        provider = _read(data, "provider") or self._stt_provider
        model = _read(data, "model") or self._stt_model
        # LiveKit 1.5 STTMetrics expose seconds floats; older synthetic
        # tests in this repo use the field name `request_duration` instead
        # of `duration`. Read both for back-compat.
        request_dur_s = _seconds(data, "duration", "request_duration")
        audio_dur_s = _seconds(data, "audio_duration")
        with self._user_turn.stage("stt", provider=provider, model=model) as stage:
            _apply_metric_timing(stage, data, request_dur_s or audio_dur_s)
            cost = _read(data, "cost_usd")
            if cost is None:
                cost = stt_cost_usd(provider, model, audio_duration_seconds=audio_dur_s)
            payload = STTPayload(
                audio_duration_ms=int(audio_dur_s * 1000),
                request_duration_ms=int(request_dur_s * 1000),
                final_transcript=_read(data, "final_transcript", default=""),
                final_confidence=float(_read(data, "confidence", default=0.0)),
                language=_read(data, "language"),
                cost_usd=cost,
            )
            stage.set_payload(payload)

    def _record_llm(self, data: Any) -> None:
        if self._agent_turn is None:
            self._open_agent_turn()
        if self._agent_turn is None:
            return
        provider = _read(data, "provider") or self._llm_provider
        model = _read(data, "model") or self._llm_model
        ttft_ms = int(_seconds(data, "ttft") * 1000)
        self._last_llm_ttft_ms = ttft_ms or None
        prompt_tokens = int(_read(data, "prompt_tokens", default=0) or 0)
        completion_tokens = int(_read(data, "completion_tokens", default=0) or 0)
        cached_tokens = int(
            _read(data, "cached_tokens", "prompt_cached_tokens", default=0) or 0
        )
        with self._agent_turn.stage("llm", provider=provider, model=model) as stage:
            request_dur_s = _seconds(data, "duration")
            _apply_metric_timing(stage, data, request_dur_s)
            cost = _read(data, "cost_usd")
            if cost is None:
                cost = llm_cost_usd(
                    provider, model,
                    prompt_tokens=prompt_tokens,
                    completion_tokens=completion_tokens,
                    cached_tokens=cached_tokens,
                )
            payload = LLMPayload(
                prompt_tokens=prompt_tokens,
                completion_tokens=completion_tokens,
                cached_tokens=cached_tokens,
                ttft_ms=ttft_ms,
                tokens_per_second=float(_read(data, "tokens_per_second", default=0.0) or 0.0),
                cost_usd=float(cost or 0.0),
            )
            stage.set_payload(payload)

    def _record_tts(self, data: Any) -> None:
        if self._agent_turn is None:
            self._open_agent_turn()
        if self._agent_turn is None:
            return
        provider = _read(data, "provider") or self._tts_provider
        model = _read(data, "model") or self._tts_model
        request_dur_s = _seconds(data, "duration")
        audio_dur_s = _seconds(data, "audio_duration")
        # LiveKit emits the synthesized character count as `characters_count`;
        # older test payloads in this repo use `text` directly. Try both.
        text_input = _read(data, "text", "text_input", default="") or ""
        characters = int(
            _read(data, "characters_count", "characters", default=0) or 0
        )
        if not characters and text_input:
            characters = len(text_input)
        with self._agent_turn.stage("tts", provider=provider, model=model) as stage:
            _apply_metric_timing(stage, data, request_dur_s or audio_dur_s)
            cost = _read(data, "cost_usd")
            if cost is None:
                cost = tts_cost_usd(
                    provider, model,
                    characters=characters,
                    audio_duration_seconds=audio_dur_s,
                )
            payload = TTSPayload(
                text_input=text_input,
                audio_bytes=int(_read(data, "audio_bytes", default=0) or 0),
                audio_duration_ms=int(audio_dur_s * 1000),
                ttfb_ms=int(_seconds(data, "ttfb") * 1000),
                voice_id=_read(data, "voice_id", default="") or "",
                cost_usd=float(cost or 0.0),
            )
            stage.set_payload(payload)

    # ------------------------------------------------------------------ turn helpers

    def _open_user_turn(self) -> None:
        if self._user_turn is not None or self._session is None:
            return
        cm = self._session.user_turn()
        self._user_turn = cm.__enter__()
        self._user_turn_exit = cm.__exit__

    def _close_user_turn(self) -> None:
        if self._user_turn is None:
            return
        exit_fn = self._user_turn_exit
        self._user_turn = None
        self._user_turn_exit = None
        if exit_fn is not None:
            exit_fn(None, None, None)

    def _open_agent_turn(self) -> None:
        if self._agent_turn is not None or self._session is None:
            return
        cm = self._session.agent_turn()
        self._agent_turn = cm.__enter__()
        self._agent_turn_exit = cm.__exit__

    def _close_agent_turn(self) -> None:
        if self._agent_turn is None:
            return
        exit_fn = self._agent_turn_exit
        # Capture the TTFA hint we stashed on the agent turn (if any) and forward
        # it to the schema close-time so it lands on the wire row.
        ttfa = getattr(self._agent_turn, "_ttfa_hint", None)
        ttft = self._last_llm_ttft_ms
        self._agent_turn = None
        self._agent_turn_exit = None
        # Exit the context first to flush the turn span.
        if exit_fn is not None:
            exit_fn(None, None, None)
        # The Session._open_turn closer reads ttfa/ttft via instance attrs that
        # we don't expose; for now ttfa lives only as event-derived metadata in
        # the rollup. Future revision: extend Turn._close to accept hints.
        _ = (ttfa, ttft)

    def _compute_ttfa_ms(self) -> Optional[int]:
        """User-perceived TTFA = user-speech-end -> first TTS audio byte played.

        We approximate this with monotonic clock difference from the moment
        user_state_changed:listening fired to the moment agent_state_changed:speaking fires.
        """
        if self._user_speech_end_monotonic is None:
            return None
        delta_ms = int((time.monotonic() - self._user_speech_end_monotonic) * 1000)
        return max(0, delta_ms)


# ---------------------------------------------------------------------------- helpers

def _read(data: Any, *keys: str, default: Any = None) -> Any:
    """Read a field from a dict OR an arbitrary object; tries each key in turn."""
    if data is None:
        return default
    for key in keys:
        if isinstance(data, dict):
            if key in data:
                return data[key]
        elif hasattr(data, key):
            return getattr(data, key)
    return default


def _seconds(data: Any, *keys: str) -> float:
    """Read a duration field as a float of seconds, defaulting to 0.0."""
    val = _read(data, *keys, default=0.0)
    if val is None:
        return 0.0
    try:
        return float(val)
    except (TypeError, ValueError):
        return 0.0


def _apply_metric_timing(stage: Any, data: Any, duration_s: float) -> None:
    """If the LiveKit metric carries a wall-clock timestamp, pin the stage's
    start/end to it so duration_ms reflects the real elapsed time of the
    upstream operation (not the few microseconds we spent inside the
    `with stage(...)` block synthesizing the span)."""
    if duration_s <= 0:
        return
    timestamp = _read(data, "timestamp")
    try:
        ts = float(timestamp) if timestamp is not None else None
    except (TypeError, ValueError):
        ts = None
    # Sanity-check: livekit-agents emits Unix-epoch seconds. If we got
    # something tiny (e.g., a process-uptime float), fall back to "now"
    # so the dashboard doesn't display 1970-01-01.
    now = datetime.now(timezone.utc)
    if ts is None or ts < 1_000_000_000:
        end = now
    else:
        end = datetime.fromtimestamp(ts, tz=timezone.utc)
    start = end - timedelta(seconds=duration_s)
    stage.set_timing(start_time=start, end_time=end)


def _extract_chat_text(item: Any) -> str:
    """Pull the text out of a LiveKit ChatMessage-shaped object.

    `text_content` is a property on the real object; on dict-shaped fakes
    (and older payloads) it may live under `content`, which can be a
    string OR a list of `{type: "text", text: "..."}` parts."""
    if item is None:
        return ""
    val = getattr(item, "text_content", None) if not isinstance(item, dict) else item.get("text_content")
    if callable(val):
        try:
            val = val()
        except Exception:
            val = None
    if isinstance(val, str) and val:
        return val
    content = item.get("content") if isinstance(item, dict) else getattr(item, "content", None)
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for c in content:
            if isinstance(c, dict):
                parts.append(str(c.get("text") or ""))
            elif isinstance(c, str):
                parts.append(c)
        return "".join(parts).strip()
    return ""


def _stringify_optional(value: Any) -> Optional[str]:
    if value is None:
        return None
    if isinstance(value, str):
        return value
    return str(value)


def _split_provider_model(combined: Optional[str]) -> tuple[Optional[str], Optional[str]]:
    """Split an AgentSession-style "provider/model" hint into a (provider, model) tuple.

    "openai/gpt-4.1-mini"        -> ("openai", "gpt-4.1-mini")
    "deepgram/nova-3:en"         -> ("deepgram", "nova-3:en")
    "gpt-4.1-mini"               -> (None, "gpt-4.1-mini")
    None                         -> (None, None)
    """
    if not combined:
        return None, None
    if "/" in combined:
        provider, _, model = combined.partition("/")
        return provider or None, model or None
    return None, combined


def _unwrap_metrics(data: Any) -> Any:
    """MetricsCollectedEvent wraps the actual metrics object in `.metrics`."""
    inner = _read(data, "metrics")
    return inner if inner is not None else data


def _classify_metrics(data: Any) -> Optional[str]:
    """Identify which kind of LiveKit metrics object this is.

    LiveKit emits typed objects (STTMetrics, LLMMetrics, TTSMetrics, EOUMetrics).
    We accept either the object (using class name) or a dict with a 'type' field.
    """
    kind = str(_read(data, "type", "kind", default="") or "").lower()
    if "stt" in kind:
        return "stt"
    if "llm" in kind:
        return "llm"
    if "tts" in kind:
        return "tts"
    if "eou" in kind or "end_of_utterance" in kind:
        return "eou"
    if "interrupt" in kind:
        return "interruption"
    if isinstance(data, dict):
        # Heuristic by field shape:
        if "audio_duration" in data and "final_transcript" in data:
            return "stt"
        if "ttft" in data and ("prompt_tokens" in data or "tokens_per_second" in data):
            return "llm"
        if "ttfb" in data or "voice_id" in data:
            return "tts"
        if "end_of_utterance_delay" in data:
            return "eou"
        if "interrupt_latency" in data or "interrupt_latency_ms" in data:
            return "interruption"
        return None
    cls_name = type(data).__name__.lower()
    if "stt" in cls_name:
        return "stt"
    if "llm" in cls_name:
        return "llm"
    if "tts" in cls_name:
        return "tts"
    if "eou" in cls_name:
        return "eou"
    if "interrupt" in cls_name:
        return "interruption"
    return None


_DISPATCH = {
    "user_state_changed": _LiveKitAdapter._on_user_state_changed,
    "agent_state_changed": _LiveKitAdapter._on_agent_state_changed,
    "user_input_transcribed": _LiveKitAdapter._on_user_input_transcribed,
    "conversation_item_added": _LiveKitAdapter._on_conversation_item_added,
    "metrics_collected": _LiveKitAdapter._on_metrics_collected,
    "agent_false_interruption": _LiveKitAdapter._on_agent_false_interruption,
    "close": _LiveKitAdapter._on_close,
    "speech_interrupted": _LiveKitAdapter._on_speech_interrupted,
    # speech_created / speech_committed currently no-op; reserved for future
    # finer-grained TTS chunk tracking.
}


__all__ = ["VoiceObservability"]
