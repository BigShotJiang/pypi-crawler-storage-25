"""SDK-side PII masking. On by default; defense-in-depth alongside server-side
masking. Customers can register additional redactors via Client(masker=...)."""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Pattern


_EMAIL = re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b")
_SSN = re.compile(r"\b\d{3}-\d{2}-\d{4}\b")
_CC = re.compile(r"\b(?:\d[ -]?){13,19}\b")
_PHONE = re.compile(
    r"(?:\+?\d{1,3}[\s.-]?)?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}\b"
)


def _redact(pattern: Pattern[str], label: str, text: str) -> str:
    return pattern.sub(f"[REDACTED:{label}]", text)


def default_mask(text: str) -> str:
    if not text:
        return text
    text = _redact(_EMAIL, "email", text)
    text = _redact(_SSN, "ssn", text)
    text = _redact(_CC, "cc", text)
    text = _redact(_PHONE, "phone", text)
    return text


Masker = Callable[[str], str]


@dataclass
class MaskerRegistry:
    fns: List[Masker] = field(default_factory=lambda: [default_mask])

    def add(self, fn: Masker) -> None:
        self.fns.append(fn)

    def apply(self, text: str) -> str:
        if not isinstance(text, str):
            return text
        for fn in self.fns:
            try:
                text = fn(text)
            except Exception:
                # Never let a bad redactor crash the pipeline.
                continue
        return text

    def apply_to_payload(self, value: Any) -> Any:
        """Recursively mask string fields in dict/list payloads.

        The wire payload contains transcripts, prompts, completions — anywhere a
        string appears, it goes through every registered redactor.
        """
        if isinstance(value, str):
            return self.apply(value)
        if isinstance(value, dict):
            return {k: self.apply_to_payload(v) for k, v in value.items()}
        if isinstance(value, list):
            return [self.apply_to_payload(v) for v in value]
        if isinstance(value, tuple):
            return tuple(self.apply_to_payload(v) for v in value)
        return value


def make_default_registry() -> MaskerRegistry:
    return MaskerRegistry()
