"""Audio upload helpers.

The session-level mixed audio track is uploaded directly to blob storage via a
presigned URL — never through the backend. The SDK only:
  1) calls /v1/voice/audio/presign to obtain a PUT URL,
  2) PUTs the audio bytes there,
  3) calls /v1/voice/audio/committed to mark the session row.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional, Union

import httpx

from .transport import HttpTransport

logger = logging.getLogger(__name__)


class AudioUploader:
    def __init__(self, transport: HttpTransport):
        self._transport = transport

    def upload(
        self,
        session_id: str,
        audio: Union[bytes, str, Path],
        *,
        duration_ms: int,
        codec: str = "opus",
        timeout_seconds: float = 60.0,
    ) -> bool:
        presign = self._transport.presign_audio(session_id=session_id, codec=codec)
        if presign is None or not (presign.get("upload_url") or presign.get("url")):
            logger.warning("ashr_voice_obs presign failed for session=%s", session_id)
            return False

        try:
            data = audio if isinstance(audio, (bytes, bytearray)) else Path(audio).read_bytes()
        except Exception as exc:
            logger.warning("ashr_voice_obs failed to read audio file: %s", exc)
            return False

        # Honor headers the backend baked into the signature (e.g. Content-Type).
        # If our PUT doesn't echo them, S3 rejects with SignatureDoesNotMatch.
        upload_url = presign.get("upload_url") or presign.get("url")
        upload_headers = presign.get("headers") or {}
        try:
            with httpx.Client(timeout=timeout_seconds) as client:
                response = client.put(upload_url, content=data, headers=upload_headers)
        except httpx.HTTPError as exc:
            logger.warning("ashr_voice_obs audio PUT failed: %s", exc)
            return False

        if not response.is_success:
            logger.warning("ashr_voice_obs audio PUT non-2xx: %d", response.status_code)
            return False

        object_key = presign.get("object_key", presign.get("key", ""))
        return self._transport.commit_audio(
            session_id=session_id,
            object_key=object_key,
            duration_ms=duration_ms,
            codec=codec,
        )
