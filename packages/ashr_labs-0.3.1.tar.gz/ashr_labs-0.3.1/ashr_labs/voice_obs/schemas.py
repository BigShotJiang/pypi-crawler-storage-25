"""Wire-format schemas for ASHR voice observability.

These mirror backend/voice_observability/schemas.py field-for-field. They are
intentionally duplicated here so the SDK can ship without depending on the
backend repo.
"""
from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Literal, Optional, Tuple, Union

from pydantic import BaseModel, Field


class Message(BaseModel):
    role: Literal["system", "user", "assistant", "tool"]
    content: str


class ToolCall(BaseModel):
    name: str
    arguments: Dict[str, Any] = Field(default_factory=dict)
    result: Optional[str] = None


class STTPartial(BaseModel):
    seq: int
    timestamp_ms: int
    text: str
    confidence: float
    is_final: bool


class Session(BaseModel):
    session_id: str
    tenant_id: int
    external_session_id: Optional[str] = None
    room_id: str
    user_id: Optional[str] = None
    agent_id: str
    agent_version: Optional[str] = None
    start_time: datetime
    end_time: Optional[datetime] = None
    end_reason: Optional[Literal["user_left", "agent_left", "timeout", "error"]] = None
    transport: Literal["webrtc", "sip", "websocket"]
    status: Literal["active", "completed", "errored"]

    duration_ms: Optional[int] = None
    turn_count: Optional[int] = None
    user_turn_count: Optional[int] = None
    agent_turn_count: Optional[int] = None
    interrupt_count: Optional[int] = None
    total_cost_usd: Optional[float] = None
    p95_ttfa_ms: Optional[int] = None

    audio_object_key: Optional[str] = None
    audio_duration_ms: Optional[int] = None
    audio_codec: Optional[str] = None

    packet_loss_pct: Optional[float] = None
    jitter_ms: Optional[int] = None
    mos_score: Optional[float] = None

    metadata: Dict[str, Any] = Field(default_factory=dict)


class Turn(BaseModel):
    turn_id: str
    session_id: str
    tenant_id: int
    agent_id: str
    agent_version: Optional[str] = None
    user_id: Optional[str] = None
    turn_index: int
    speaker: Literal["user", "agent"]
    start_time: datetime
    end_time: Optional[datetime] = None
    transcript: str = ""
    ttfa_ms: Optional[int] = None
    ttft_ms: Optional[int] = None
    was_interrupting: bool = False
    interrupted_by_turn_id: Optional[str] = None
    interrupt_latency_ms: Optional[int] = None
    ended_with_error: bool = False
    cost_usd: float = 0.0


class STTPayload(BaseModel):
    audio_duration_ms: int = 0
    request_duration_ms: int = 0
    partials: List[STTPartial] = Field(default_factory=list)
    final_transcript: str = ""
    final_confidence: float = 0.0
    language: Optional[str] = None
    cost_usd: Optional[float] = None


class LLMPayload(BaseModel):
    prompt_tokens: int = 0
    completion_tokens: int = 0
    cached_tokens: int = 0
    ttft_ms: int = 0
    tokens_per_second: float = 0.0
    prompt: List[Message] = Field(default_factory=list)
    completion: str = ""
    tool_calls: List[ToolCall] = Field(default_factory=list)
    cost_usd: float = 0.0


class TTSPayload(BaseModel):
    text_input: str = ""
    audio_bytes: int = 0
    audio_duration_ms: int = 0
    ttfb_ms: int = 0
    voice_id: str = ""
    cost_usd: float = 0.0


class VADPayload(BaseModel):
    speech_started_at: datetime
    speech_ended_at: datetime
    confidence_series: List[Tuple[int, float]] = Field(default_factory=list)


class NLUEntity(BaseModel):
    name: str
    value: Any
    confidence: float


class NLUPayload(BaseModel):
    intent: str
    intent_confidence: float
    entities: List[NLUEntity] = Field(default_factory=list)


class DialogueManagementPayload(BaseModel):
    state_before: str
    state_after: str
    action_selected: str
    policy_name: Optional[str] = None


class APICallPayload(BaseModel):
    method: str
    url_path: str
    status_code: int
    request_duration_ms: int
    request_bytes: int = 0
    response_bytes: int = 0


StagePayload = Union[
    STTPayload,
    LLMPayload,
    TTSPayload,
    VADPayload,
    NLUPayload,
    DialogueManagementPayload,
    APICallPayload,
]


class Stage(BaseModel):
    stage_id: str
    turn_id: str
    session_id: str
    tenant_id: int
    kind: Literal["stt", "llm", "tts", "vad", "nlu", "dialogue_management", "api_call"]
    start_time: datetime
    end_time: Optional[datetime] = None
    duration_ms: int = 0
    provider: Optional[str] = None
    model: Optional[str] = None
    status: Literal["success", "failure"] = "success"
    error_message: Optional[str] = None
    payload: StagePayload


class TurnEvent(BaseModel):
    event_id: str
    turn_id: str
    session_id: str
    tenant_id: int
    event_type: Literal[
        "user_speech_start",
        "user_speech_end",
        "agent_speech_start",
        "agent_speech_end",
        "barge_in",
        "failed_interrupt",
        "gap_detected",
    ]
    timestamp: datetime
    payload: Dict[str, Any] = Field(default_factory=dict)


Stage.model_rebuild()
