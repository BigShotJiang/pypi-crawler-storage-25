"""ASHR voice agent observability — Python SDK.

Two ways to use:

1) LiveKit (the happy path):

    from ashr_labs.voice_obs.livekit import VoiceObservability
    obs = VoiceObservability(api_key=...)
    obs.attach(session, agent_id="bot", agent_version="v1")

2) Generic primitives (any stack):

    client = Client(api_key=...)
    session = client.start_session(agent_id="bot", transport="webrtc", ...)
    with session.user_turn() as turn:
        with turn.stage("stt", provider="deepgram") as s:
            s.set_payload({"final_transcript": "hi"})
        turn.set_transcript("hi")
    session.end(reason="user_left")
"""
from __future__ import annotations

import logging
import time
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Any, Dict, Iterator, List, Optional

from pydantic import BaseModel

from .audio import AudioUploader
from .buffer import FlushWorker, SpanBuffer
from .masking import MaskerRegistry, make_default_registry
from .schemas import (
    APICallPayload,
    DialogueManagementPayload,
    LLMPayload,
    Message,
    NLUPayload,
    Session as SessionSchema,
    Stage as StageSchema,
    STTPayload,
    Turn as TurnSchema,
    TurnEvent,
    TTSPayload,
    ToolCall,
    VADPayload,
)
from .transport import HttpTransport

logger = logging.getLogger(__name__)


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:16]}"


class Stage:
    """Context-managed stage span (STT/LLM/TTS/VAD/etc).

    Closing the context flushes the stage to the buffer with status='success'
    unless an exception occurred — then status='failure' and the error message
    is captured.
    """

    def __init__(
        self,
        *,
        session: "Session",
        turn: "Turn",
        kind: str,
        provider: Optional[str] = None,
        model: Optional[str] = None,
    ):
        self._session = session
        self._turn = turn
        self.stage_id = _new_id("st")
        self.kind = kind
        self.provider = provider
        self.model = model
        self._payload: Any = None
        self._partials: List[Any] = []
        self._status: str = "success"
        self._error_message: Optional[str] = None
        self._monotonic_start = time.monotonic()
        self._wall_start = _utcnow()
        self._wall_end: Optional[datetime] = None
        # Override hooks: when the stage reflects an upstream measurement
        # (e.g. LiveKit metrics_collected, where the operation already
        # happened), set_timing() lets the caller pin start/end explicitly
        # so duration_ms reflects the real elapsed time, not the time we
        # spent inside the with-block.
        self._wall_start_override: Optional[datetime] = None
        self._wall_end_override: Optional[datetime] = None

    # Public API ---------------------------------------------------------

    def set_payload(self, payload: Any) -> None:
        self._payload = payload

    def add_partial(self, partial: Any) -> None:
        self._partials.append(partial)

    def fail(self, message: str) -> None:
        self._status = "failure"
        self._error_message = message

    def set_timing(self, *, start_time: datetime, end_time: datetime) -> None:
        """Use explicit timestamps for this stage instead of the wall clock.

        Use this when the stage is reflecting an already-completed upstream
        operation (LiveKit metric, third-party API call) rather than wrapping
        a synchronous block of code. Affects start_time / end_time / duration_ms
        on the resulting wire row.
        """
        self._wall_start_override = start_time
        self._wall_end_override = end_time

    # Internal -----------------------------------------------------------

    def _close(self, exc: Optional[BaseException]) -> None:
        if exc is not None and self._status != "failure":
            self._status = "failure"
            self._error_message = self._error_message or f"{type(exc).__name__}: {exc}"
        if self._wall_end_override is not None:
            wall_start = self._wall_start_override or self._wall_start
            self._wall_end = self._wall_end_override
            duration_ms = max(0, int((self._wall_end - wall_start).total_seconds() * 1000))
        else:
            wall_start = self._wall_start
            self._wall_end = _utcnow()
            duration_ms = max(0, int((time.monotonic() - self._monotonic_start) * 1000))

        payload = self._build_payload()
        try:
            stage = StageSchema(
                stage_id=self.stage_id,
                turn_id=self._turn.turn_id,
                session_id=self._session.session_id,
                tenant_id=self._session.tenant_id,
                kind=self.kind,  # type: ignore[arg-type]
                start_time=wall_start,
                end_time=self._wall_end,
                duration_ms=duration_ms,
                provider=self.provider,
                model=self.model,
                status=self._status,  # type: ignore[arg-type]
                error_message=self._error_message,
                payload=payload,
            )
        except Exception:
            logger.warning("ashr_voice_obs failed to build Stage span", exc_info=True)
            return
        # Auto-rollup cost from the typed payload onto the parent turn so the
        # generic primitives behave the same as the LiveKit adapter.
        cost = getattr(payload, "cost_usd", None)
        if isinstance(cost, (int, float)):
            self._turn.add_cost(float(cost))
        self._session._enqueue_stage(stage)

    def _build_payload(self) -> Any:
        # If user passed a typed payload, keep it; else attempt to coerce.
        if isinstance(self._payload, BaseModel):
            return self._payload
        if isinstance(self._payload, dict):
            coercer = _PAYLOAD_COERCERS.get(self.kind)
            if coercer is not None:
                try:
                    return coercer(**self._payload)
                except Exception:
                    pass
            # Fall back to a permissive STT/api shape so we still ship something.
        # Use a minimal payload appropriate to kind.
        return _empty_payload_for(self.kind, self._partials)


_PAYLOAD_COERCERS = {
    "stt": STTPayload,
    "llm": LLMPayload,
    "tts": TTSPayload,
    "vad": VADPayload,
    "nlu": NLUPayload,
    "dialogue_management": DialogueManagementPayload,
    "api_call": APICallPayload,
}


def _empty_payload_for(kind: str, partials: List[Any]) -> Any:
    if kind == "stt":
        return STTPayload(partials=partials)
    if kind == "llm":
        return LLMPayload()
    if kind == "tts":
        return TTSPayload()
    if kind == "vad":
        now = _utcnow()
        return VADPayload(speech_started_at=now, speech_ended_at=now)
    if kind == "nlu":
        return NLUPayload(intent="", intent_confidence=0.0)
    if kind == "dialogue_management":
        return DialogueManagementPayload(state_before="", state_after="", action_selected="")
    if kind == "api_call":
        return APICallPayload(method="GET", url_path="", status_code=0, request_duration_ms=0)
    raise ValueError(f"unsupported stage kind: {kind}")


class Turn:
    def __init__(
        self,
        *,
        session: "Session",
        speaker: str,
        turn_index: int,
    ):
        self._session = session
        self.turn_id = _new_id("t")
        self.speaker = speaker
        self.turn_index = turn_index
        self._monotonic_start = time.monotonic()
        self._wall_start = _utcnow()
        self._transcript: str = ""
        self._was_interrupting = False
        self._interrupted_by: Optional[str] = None
        self._interrupt_latency_ms: Optional[int] = None
        self._cost_usd: float = 0.0
        self._ended_with_error = False

    # Public API ---------------------------------------------------------

    def set_transcript(self, text: str) -> None:
        self._transcript = text or ""

    def add_cost(self, usd: float) -> None:
        self._cost_usd += float(usd)

    def mark_interrupted(self, *, by_turn_id: str, interrupt_latency_ms: int) -> None:
        self._was_interrupting = True
        self._interrupted_by = by_turn_id
        self._interrupt_latency_ms = int(interrupt_latency_ms)

    @contextmanager
    def stage(
        self,
        kind: str,
        *,
        provider: Optional[str] = None,
        model: Optional[str] = None,
    ) -> Iterator[Stage]:
        st = Stage(session=self._session, turn=self, kind=kind, provider=provider, model=model)
        try:
            yield st
            st._close(None)
        except BaseException as exc:
            st._close(exc)
            raise

    def event(self, event_type: str, payload: Optional[Dict[str, Any]] = None) -> None:
        evt = TurnEvent(
            event_id=_new_id("e"),
            turn_id=self.turn_id,
            session_id=self._session.session_id,
            tenant_id=self._session.tenant_id,
            event_type=event_type,  # type: ignore[arg-type]
            timestamp=_utcnow(),
            payload=payload or {},
        )
        self._session._enqueue_event(evt)

    # Internal -----------------------------------------------------------

    def _close(self, *, ttfa_ms: Optional[int] = None, ttft_ms: Optional[int] = None,
               ended_with_error: bool = False) -> None:
        wall_end = _utcnow()
        try:
            row = TurnSchema(
                turn_id=self.turn_id,
                session_id=self._session.session_id,
                tenant_id=self._session.tenant_id,
                agent_id=self._session.agent_id,
                agent_version=self._session.agent_version,
                user_id=self._session.user_id,
                turn_index=self.turn_index,
                speaker=self.speaker,  # type: ignore[arg-type]
                start_time=self._wall_start,
                end_time=wall_end,
                transcript=self._session._mask(self._transcript),
                ttfa_ms=ttfa_ms,
                ttft_ms=ttft_ms,
                was_interrupting=self._was_interrupting,
                interrupted_by_turn_id=self._interrupted_by,
                interrupt_latency_ms=self._interrupt_latency_ms,
                ended_with_error=ended_with_error or self._ended_with_error,
                cost_usd=self._cost_usd,
            )
        except Exception:
            logger.warning("ashr_voice_obs failed to build Turn span", exc_info=True)
            return
        self._session._enqueue_turn(row)


class Session:
    def __init__(
        self,
        *,
        client: "Client",
        session_id: str,
        agent_id: str,
        transport: str,
        agent_version: Optional[str] = None,
        room_id: Optional[str] = None,
        user_id: Optional[str] = None,
        external_session_id: Optional[str] = None,
        tenant_id: int = 0,
        metadata: Optional[Dict[str, Any]] = None,
    ):
        self._client = client
        self.session_id = session_id
        self.agent_id = agent_id
        self.agent_version = agent_version
        self.user_id = user_id
        self.tenant_id = tenant_id
        self.transport = transport
        self.room_id = room_id or session_id
        self.external_session_id = external_session_id

        self._wall_start = _utcnow()
        self._monotonic_start = time.monotonic()
        self._turn_count = 0
        self._user_turn_count = 0
        self._agent_turn_count = 0
        self._interrupt_count = 0
        self._total_cost = 0.0
        self._ttfas: List[int] = []
        # Transport-quality stats (mos_score / packet_loss_pct / jitter_ms)
        # are published by adapters over the call. The SDK accumulates the
        # last reported values and forwards them at session close time via
        # the transport_quality rollup body.
        self._transport_quality: Dict[str, Any] = {}
        self._closed = False

        # Send initial session row so backend has the row to update on close.
        try:
            initial = SessionSchema(
                session_id=self.session_id,
                tenant_id=self.tenant_id,
                external_session_id=self.external_session_id,
                room_id=self.room_id,
                user_id=self.user_id,
                agent_id=self.agent_id,
                agent_version=self.agent_version,
                start_time=self._wall_start,
                transport=self.transport,  # type: ignore[arg-type]
                status="active",
                metadata=metadata or {},
            )
            self._client._enqueue_session(initial)
        except Exception:
            logger.warning("ashr_voice_obs failed to build initial Session", exc_info=True)

    # Public API ---------------------------------------------------------

    @contextmanager
    def user_turn(self) -> Iterator[Turn]:
        yield from self._open_turn("user")

    @contextmanager
    def agent_turn(self) -> Iterator[Turn]:
        yield from self._open_turn("agent")

    def set_transport_quality(
        self,
        *,
        mos_score: Optional[float] = None,
        packet_loss_pct: Optional[float] = None,
        jitter_ms: Optional[int] = None,
    ) -> None:
        """Update WebRTC transport quality stats. Only non-None values are
        recorded; the SDK forwards the last set of values at session close
        as part of the close PATCH's transport_quality body."""
        if mos_score is not None:
            self._transport_quality["mos_score"] = float(mos_score)
        if packet_loss_pct is not None:
            self._transport_quality["packet_loss_pct"] = float(packet_loss_pct)
        if jitter_ms is not None:
            self._transport_quality["jitter_ms"] = int(jitter_ms)

    def end(
        self,
        *,
        reason: str = "user_left",
        wall_clock_end: Optional[datetime] = None,
    ) -> None:
        if self._closed:
            return
        self._closed = True
        end = wall_clock_end or _utcnow()
        duration_ms = max(0, int((time.monotonic() - self._monotonic_start) * 1000))
        rollups = {
            "duration_ms": duration_ms,
            "turn_count": self._turn_count,
            "user_turn_count": self._user_turn_count,
            "agent_turn_count": self._agent_turn_count,
            "interrupt_count": self._interrupt_count,
            "total_cost_usd": self._total_cost,
            "p95_ttfa_ms": _p95(self._ttfas),
        }
        body = {
            "end_time": end.isoformat().replace("+00:00", "Z"),
            "end_reason": _normalize_end_reason(reason),
            "status": "completed",
            "rollups": rollups,
        }
        if self._transport_quality:
            body["transport_quality"] = dict(self._transport_quality)
        # Push final state through the buffer flow then send PATCH directly.
        self._client._flush()
        ok = self._client._transport.patch_session(self.session_id, body)
        if not ok:
            logger.warning("ashr_voice_obs end() PATCH failed for session=%s", self.session_id)

    # Internal -----------------------------------------------------------

    def _open_turn(self, speaker: str) -> Iterator[Turn]:
        idx = self._turn_count
        turn = Turn(session=self, speaker=speaker, turn_index=idx)
        self._turn_count += 1
        if speaker == "user":
            self._user_turn_count += 1
        else:
            self._agent_turn_count += 1
        try:
            yield turn
        except BaseException:
            turn._ended_with_error = True
            raise
        finally:
            turn._close()

    def _mask(self, text: str) -> str:
        return self._client._masker.apply(text)

    def _enqueue_turn(self, turn: TurnSchema) -> None:
        self._total_cost += turn.cost_usd
        if turn.ttfa_ms is not None:
            self._ttfas.append(turn.ttfa_ms)
        if turn.was_interrupting:
            self._interrupt_count += 1
        self._client._enqueue_turn(turn)

    def _enqueue_stage(self, stage: StageSchema) -> None:
        self._client._enqueue_stage(stage)

    def _enqueue_event(self, event: TurnEvent) -> None:
        self._client._enqueue_event(event)


def _p95(values: List[int]) -> Optional[int]:
    if not values:
        return None
    sorted_vals = sorted(values)
    idx = int(round(0.95 * (len(sorted_vals) - 1)))
    return int(sorted_vals[idx])


def _normalize_end_reason(reason: object) -> str:
    text = str(reason or "").strip().lower()
    if text in {"user_left", "agent_left", "timeout", "error"}:
        return text
    if any(token in text for token in ("participant_disconnected", "client_initiated", "user_initiated")):
        return "user_left"
    if any(token in text for token in ("job_shutdown", "task_completed", "agent_left")):
        return "agent_left"
    if "timeout" in text:
        return "timeout"
    if "error" in text:
        return "error"
    return "agent_left"


class Client:
    """Top-level SDK client. Holds the buffer, transport, and masker registry."""

    def __init__(
        self,
        *,
        api_key: str,
        base_url: str = "https://api.ashr.io",
        flush_interval_seconds: float = 5.0,
        flush_threshold: int = 10,
        max_buffer_size: int = 10_000,
        masker: Optional[MaskerRegistry] = None,
        transport: Optional[HttpTransport] = None,
    ):
        self._transport = transport or HttpTransport(base_url=base_url, api_key=api_key)
        self._buffer = SpanBuffer(max_size=max_buffer_size)
        self._masker = masker or make_default_registry()
        self._worker = FlushWorker(
            self._buffer,
            self._flush_batch,
            flush_interval_seconds=flush_interval_seconds,
            flush_threshold=flush_threshold,
        )
        self._worker.start()
        self._audio = AudioUploader(self._transport)
        self._pending_session: Optional[SessionSchema] = None

    # Public API ---------------------------------------------------------

    def start_session(
        self,
        *,
        agent_id: str,
        transport: str,
        tenant_id: int = 0,
        agent_version: Optional[str] = None,
        room_id: Optional[str] = None,
        user_id: Optional[str] = None,
        external_session_id: Optional[str] = None,
        session_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Session:
        return Session(
            client=self,
            session_id=session_id or _new_id("s"),
            agent_id=agent_id,
            agent_version=agent_version,
            user_id=user_id,
            tenant_id=tenant_id,
            transport=transport,
            room_id=room_id,
            external_session_id=external_session_id,
            metadata=metadata,
        )

    def upload_audio(self, session_id: str, audio: Any, *, duration_ms: int, codec: str = "opus") -> bool:
        return self._audio.upload(session_id=session_id, audio=audio, duration_ms=duration_ms, codec=codec)

    def shutdown(self, drain_timeout_seconds: float = 5.0) -> None:
        self._worker.stop(drain_timeout_seconds=drain_timeout_seconds)
        self._transport.close()

    # Internal -----------------------------------------------------------

    def _enqueue_session(self, session: SessionSchema) -> None:
        self._buffer.enqueue(("session", session))

    def _enqueue_turn(self, turn: TurnSchema) -> None:
        self._buffer.enqueue(("turn", turn))

    def _enqueue_stage(self, stage: StageSchema) -> None:
        self._buffer.enqueue(("stage", stage))

    def _enqueue_event(self, event: TurnEvent) -> None:
        self._buffer.enqueue(("event", event))

    def _flush(self) -> None:
        items = self._buffer.drain()
        if items:
            self._flush_batch(items)

    def _flush_batch(self, items: List[Any]) -> None:
        batch: Dict[str, Any] = {"turns": [], "stages": [], "turn_events": []}
        for kind, model in items:
            data = self._masker.apply_to_payload(model.model_dump(mode="json"))
            if kind == "session":
                batch["session"] = data
            elif kind == "turn":
                batch["turns"].append(data)
            elif kind == "stage":
                batch["stages"].append(data)
            elif kind == "event":
                batch["turn_events"].append(data)
        # Skip empty payloads.
        if not (batch.get("session") or batch["turns"] or batch["stages"] or batch["turn_events"]):
            return
        self._transport.post_spans(batch)


__all__ = [
    "Client",
    "Session",
    "Turn",
    "Stage",
    "MaskerRegistry",
    "make_default_registry",
    "Message",
    "STTPayload",
    "LLMPayload",
    "TTSPayload",
    "VADPayload",
    "NLUPayload",
    "DialogueManagementPayload",
    "APICallPayload",
    "ToolCall",
]
