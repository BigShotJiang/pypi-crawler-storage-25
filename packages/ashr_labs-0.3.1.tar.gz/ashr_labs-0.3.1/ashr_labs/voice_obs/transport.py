"""HTTP transport for the voice observability ingest API.

Retries: max 3 attempts, exponential backoff. No retry on 4xx (client error).
Failures after retries are logged and counters incremented; the SDK never
raises into the host app.
"""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any, Dict, Optional

import httpx

logger = logging.getLogger(__name__)


@dataclass
class TransportStats:
    requests: int = 0
    failures: int = 0
    dropped_batches: int = 0


@dataclass
class HttpTransport:
    base_url: str
    api_key: str
    timeout_seconds: float = 5.0
    max_retries: int = 3
    backoff_base_seconds: float = 0.25
    client: Optional[httpx.Client] = None
    stats: TransportStats = field(default_factory=TransportStats)

    def __post_init__(self) -> None:
        if self.client is None:
            self.client = httpx.Client(
                base_url=self.base_url.rstrip("/"),
                timeout=self.timeout_seconds,
                headers={"Authorization": f"Bearer {self.api_key}"},
            )

    def post_spans(self, batch: Dict[str, Any]) -> bool:
        return self._post("/v1/voice/spans", batch, expected_status=202)

    def patch_session(self, session_id: str, body: Dict[str, Any]) -> bool:
        return self._request(
            "PATCH",
            f"/v1/voice/sessions/{session_id}",
            json_body=body,
            expected_status=200,
        )

    def presign_audio(self, session_id: str, codec: str = "opus") -> Optional[Dict[str, Any]]:
        return self._json_request(
            "POST",
            "/v1/voice/audio/presign",
            json_body={"session_id": session_id, "codec": codec},
        )

    def commit_audio(self, session_id: str, object_key: str, duration_ms: int, codec: str) -> bool:
        return self._request(
            "POST",
            "/v1/voice/audio/committed",
            json_body={
                "session_id": session_id,
                "object_key": object_key,
                "duration_ms": duration_ms,
                "codec": codec,
            },
            expected_status=200,
        )

    def close(self) -> None:
        if self.client is not None:
            try:
                self.client.close()
            except Exception:
                pass

    # ------------------------------------------------------------------ helpers

    def _post(self, path: str, body: Dict[str, Any], *, expected_status: int) -> bool:
        return self._request("POST", path, json_body=body, expected_status=expected_status)

    def _request(
        self,
        method: str,
        path: str,
        *,
        json_body: Dict[str, Any],
        expected_status: int,
    ) -> bool:
        attempt = 0
        while True:
            attempt += 1
            self.stats.requests += 1
            try:
                response = self.client.request(method, path, json=json_body)
            except httpx.HTTPError as exc:
                if attempt >= self.max_retries:
                    self.stats.failures += 1
                    self.stats.dropped_batches += 1
                    logger.warning("ashr_voice_obs %s %s network error after %d attempts: %s",
                                   method, path, attempt, exc)
                    return False
                self._sleep_backoff(attempt)
                continue

            if response.status_code == expected_status:
                return True
            if 400 <= response.status_code < 500:
                # Client error: don't retry. Log and drop.
                self.stats.failures += 1
                self.stats.dropped_batches += 1
                logger.warning(
                    "ashr_voice_obs %s %s rejected (%d): %s",
                    method, path, response.status_code, response.text[:200],
                )
                return False
            if attempt >= self.max_retries:
                self.stats.failures += 1
                self.stats.dropped_batches += 1
                logger.warning(
                    "ashr_voice_obs %s %s server error after %d attempts (%d): %s",
                    method, path, attempt, response.status_code, response.text[:200],
                )
                return False
            self._sleep_backoff(attempt)

    def _json_request(
        self,
        method: str,
        path: str,
        *,
        json_body: Dict[str, Any],
    ) -> Optional[Dict[str, Any]]:
        attempt = 0
        while True:
            attempt += 1
            self.stats.requests += 1
            try:
                response = self.client.request(method, path, json=json_body)
            except httpx.HTTPError as exc:
                if attempt >= self.max_retries:
                    self.stats.failures += 1
                    logger.warning("ashr_voice_obs %s %s network error: %s", method, path, exc)
                    return None
                self._sleep_backoff(attempt)
                continue

            if response.is_success:
                try:
                    return response.json()
                except Exception:
                    return None
            if 400 <= response.status_code < 500:
                self.stats.failures += 1
                logger.warning("ashr_voice_obs %s %s rejected (%d): %s",
                               method, path, response.status_code, response.text[:200])
                return None
            if attempt >= self.max_retries:
                self.stats.failures += 1
                return None
            self._sleep_backoff(attempt)

    def _sleep_backoff(self, attempt: int) -> None:
        time.sleep(self.backoff_base_seconds * (2 ** (attempt - 1)))
