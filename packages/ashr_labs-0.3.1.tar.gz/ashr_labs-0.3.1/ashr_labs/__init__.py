"""
Ashr Labs Python SDK

A Python client library for interacting with the Ashr Labs API.
"""

from .client import AshrLabsClient
from .exceptions import (
    AshrLabsError,
    AuthenticationError,
    AuthorizationError,
    NotFoundError,
    ValidationError,
    RateLimitError,
    ServerError,
)
from .models import (
    User,
    Tenant,
    Session,
    SdkNote,
    Dataset,
    Run,
    Request,
    APIKey,
    Agent as AgentResponse,
    AgentConfig,
    ToolDefinition,
    BehaviorRule,
    GradingConfig,
    ToolCall,
    ExpectedResponse,
    Action,
    Scenario,
    PentestDatasetConfig,
    PENTEST_CATEGORIES,
    ObservabilityObservation,
    ObservabilityTrace,
    VmLogEntry,
    KernelViewport,
    KernelActionData,
    KernelEventData,
    KernelVmMetadata,
    KernelVmStream,
    KERNEL_ACTION_TYPES,
    KERNEL_EVENT_TYPES,
)
from .tracing import Trace, Span, Generation
from .run_builder import RunBuilder, TestBuilder
from .comparators import (
    strip_markdown,
    tokenize,
    fuzzy_str_match,
    extract_tool_args,
    compare_tool_args,
    compare_args_structural,
    text_similarity,
)
from .eval import EvalRunner, Agent
from .pentest import PentestRunner, PentestResult, build_pentest_request_config

__version__ = "0.2.2"
__all__ = [
    # Client
    "AshrLabsClient",
    # Exceptions
    "AshrLabsError",
    "AuthenticationError",
    "AuthorizationError",
    "NotFoundError",
    "ValidationError",
    "RateLimitError",
    "ServerError",
    # Models
    "User",
    "Tenant",
    "Session",
    "SdkNote",
    "Dataset",
    "Run",
    "Request",
    "APIKey",
    "AgentResponse",
    "AgentConfig",
    "ToolDefinition",
    "BehaviorRule",
    "GradingConfig",
    "ToolCall",
    "ExpectedResponse",
    "Action",
    "Scenario",
    "PentestDatasetConfig",
    "PENTEST_CATEGORIES",
    # Observability types
    "ObservabilityObservation",
    "ObservabilityTrace",
    # VM types
    "VmLogEntry",
    "KernelViewport",
    "KernelActionData",
    "KernelEventData",
    "KernelVmMetadata",
    "KernelVmStream",
    "KERNEL_ACTION_TYPES",
    "KERNEL_EVENT_TYPES",
    # Tracing (Observability)
    "Trace",
    "Span",
    "Generation",
    # Builders (Testing)
    "RunBuilder",
    "TestBuilder",
    # Comparators
    "strip_markdown",
    "tokenize",
    "fuzzy_str_match",
    "extract_tool_args",
    "compare_tool_args",
    "compare_args_structural",
    "text_similarity",
    # Eval
    "EvalRunner",
    "Agent",
    # Pentest
    "PentestRunner",
    "PentestResult",
    "build_pentest_request_config",
]
