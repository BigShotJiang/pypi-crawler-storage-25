"""
Tests for the Observability tracing module (Trace, Span, Generation)
and client observability methods.
"""

import json
from unittest.mock import MagicMock, patch

import pytest
from ashr_labs import AshrLabsClient
from ashr_labs.tracing import Trace, Span, Generation


class TestSpan:
    """Tests for Span creation and lifecycle."""

    def _make_trace(self):
        client = MagicMock()
        return Trace(client, "test-trace")

    def test_span_basic(self):
        trace = self._make_trace()
        span = trace.span("my-span")
        assert isinstance(span, Span)
        assert span.id
        assert len(trace._observations) == 1
        obs = trace._observations[0]
        assert obs["type"] == "span"
        assert obs["name"] == "my-span"
        assert obs["parent_observation_id"] is None
        assert obs["start_time"]

    def test_span_with_input_and_metadata(self):
        trace = self._make_trace()
        span = trace.span("step", input={"key": "val"}, metadata={"env": "prod"})
        obs = trace._observations[0]
        assert obs["input"] == {"key": "val"}
        assert obs["metadata"] == {"env": "prod"}

    def test_span_end_sets_fields(self):
        trace = self._make_trace()
        span = trace.span("step")
        span.end(output={"result": "ok"}, status_message="done", level="WARNING")
        obs = trace._observations[0]
        assert obs["end_time"]
        assert obs["output"] == {"result": "ok"}
        assert obs["status_message"] == "done"
        assert obs["level"] == "WARNING"

    def test_nested_spans(self):
        trace = self._make_trace()
        parent = trace.span("parent")
        child = parent.span("child", input="data")
        assert len(trace._observations) == 2
        child_obs = trace._observations[1]
        assert child_obs["parent_observation_id"] == parent.id
        assert child_obs["name"] == "child"

    def test_span_event(self):
        trace = self._make_trace()
        span = trace.span("parent")
        span.event("checkpoint", input={"step": 1}, level="DEBUG")
        assert len(trace._observations) == 2
        event = trace._observations[1]
        assert event["type"] == "event"
        assert event["name"] == "checkpoint"
        assert event["parent_observation_id"] == span.id

    def test_span_child_generation(self):
        trace = self._make_trace()
        span = trace.span("orchestrator")
        gen = span.generation("llm-call", model="claude-sonnet-4-6")
        assert isinstance(gen, Generation)
        gen_obs = trace._observations[1]
        assert gen_obs["type"] == "generation"
        assert gen_obs["parent_observation_id"] == span.id


class TestGeneration:
    """Tests for Generation creation and lifecycle."""

    def _make_trace(self):
        client = MagicMock()
        return Trace(client, "test-trace")

    def test_generation_basic(self):
        trace = self._make_trace()
        gen = trace.generation("classify", model="claude-sonnet-4-6")
        assert isinstance(gen, Generation)
        assert isinstance(gen, Span)  # inherits
        obs = trace._observations[0]
        assert obs["type"] == "generation"
        assert obs["name"] == "classify"
        assert obs["model"] == "claude-sonnet-4-6"

    def test_generation_end_with_usage(self):
        trace = self._make_trace()
        gen = trace.generation("respond", model="claude-sonnet-4-6",
                               input=[{"role": "user", "content": "hi"}])
        gen.end(
            output={"role": "assistant", "content": "hello"},
            usage={"input_tokens": 10, "output_tokens": 5},
        )
        obs = trace._observations[0]
        assert obs["end_time"]
        assert obs["output"]["role"] == "assistant"
        assert obs["usage"]["input_tokens"] == 10
        assert obs["usage"]["output_tokens"] == 5

    def test_generation_without_model(self):
        trace = self._make_trace()
        gen = trace.generation("step")
        obs = trace._observations[0]
        assert obs["type"] == "generation"
        assert "model" not in obs


class TestTrace:
    """Tests for Trace creation, observation collection, and flush."""

    def _make_client(self):
        client = MagicMock()
        client._make_request.return_value = {"status": "ok", "trace_id": "lf_abc123"}
        return client

    def test_trace_basic(self):
        client = self._make_client()
        trace = Trace(client, "my-agent", user_id="u1", session_id="s1",
                      metadata={"version": "1.0"}, tags=["prod"])
        assert trace._name == "my-agent"
        assert trace._user_id == "u1"
        assert trace._session_id == "s1"
        assert trace._tags == ["prod"]
        assert trace.trace_id is None

    def test_trace_end_flushes(self):
        client = self._make_client()
        trace = Trace(client, "agent", user_id="u1")
        trace.span("step1").end(output="done")
        trace.generation("llm", model="claude-sonnet-4-6").end(
            output="response", usage={"input_tokens": 1, "output_tokens": 1},
        )
        result = trace.end(output={"resolution": "ok"})

        assert result["trace_id"] == "lf_abc123"
        assert trace.trace_id == "lf_abc123"

        # Verify the payload sent to _make_request
        call_args = client._make_request.call_args
        assert call_args[0][0] == "ingest_observability_trace"
        payload = call_args[1]
        trace_data = payload["trace"]
        assert trace_data["name"] == "agent"
        assert trace_data["user_id"] == "u1"
        assert trace_data["output"] == {"resolution": "ok"}
        assert len(trace_data["observations"]) == 2

    def test_trace_no_output(self):
        client = self._make_client()
        trace = Trace(client, "agent")
        trace.end()

        payload = client._make_request.call_args[1]
        assert "output" not in payload["trace"]

    def test_trace_event(self):
        client = self._make_client()
        trace = Trace(client, "agent")
        trace.event("guardrail", input={"passed": True}, level="DEFAULT")
        assert len(trace._observations) == 1
        obs = trace._observations[0]
        assert obs["type"] == "event"
        assert obs["parent_observation_id"] is None

    def test_trace_complex_tree(self):
        """Build a realistic agent trace and verify the observation tree."""
        client = self._make_client()
        trace = Trace(client, "support-agent", user_id="user_42", session_id="conv_1")

        # LLM classifies intent
        gen1 = trace.generation("classify-intent", model="claude-haiku-4-5-20251001",
                                input=[{"role": "user", "content": "Reset password"}])
        gen1.end(output={"intent": "password_reset"}, usage={"input_tokens": 20, "output_tokens": 5})

        # Tool call to reset password
        tool = trace.span("tool:reset_password", input={"user_id": "user_42"})
        tool.end(output={"success": True})

        # LLM generates final response
        gen2 = trace.generation("respond", model="claude-sonnet-4-6",
                                input=[{"role": "user", "content": "Reset password"}])
        gen2.end(output={"content": "Done!"}, usage={"input_tokens": 30, "output_tokens": 10})

        # Guardrail check event
        trace.event("guardrail-pii", input={"detected": False})

        result = trace.end(output={"resolution": "password_reset"})

        assert result["trace_id"] == "lf_abc123"

        payload = client._make_request.call_args[1]["trace"]
        obs = payload["observations"]
        assert len(obs) == 4

        # Verify types
        types = [o["type"] for o in obs]
        assert types == ["generation", "span", "generation", "event"]

        # Verify none have parents (all top-level)
        assert all(o["parent_observation_id"] is None for o in obs)

        # Verify generation fields
        assert obs[0]["model"] == "claude-haiku-4-5-20251001"
        assert obs[2]["model"] == "claude-sonnet-4-6"

    def test_trace_nested_tree(self):
        """Verify parent-child relationships in nested spans."""
        client = self._make_client()
        trace = Trace(client, "agent")

        parent = trace.span("orchestrator")
        child1 = parent.span("step-1")
        child1.end()
        child2 = parent.generation("llm-call", model="claude-sonnet-4-6")
        child2.end(output="resp")
        parent.event("log", input={"msg": "done"})
        parent.end()

        trace.end()

        obs = client._make_request.call_args[1]["trace"]["observations"]
        assert len(obs) == 4

        # parent is top-level
        assert obs[0]["parent_observation_id"] is None
        # children point to parent
        assert obs[1]["parent_observation_id"] == parent.id
        assert obs[2]["parent_observation_id"] == parent.id
        assert obs[3]["parent_observation_id"] == parent.id

    def test_unique_ids(self):
        """All observations should have unique IDs."""
        client = self._make_client()
        trace = Trace(client, "agent")
        for i in range(20):
            trace.span(f"span-{i}")
        ids = [o["id"] for o in trace._observations]
        assert len(set(ids)) == 20

    def test_trace_default_tags_empty(self):
        """Tags should default to empty list when not provided."""
        client = self._make_client()
        trace = Trace(client, "agent")
        trace.end()
        payload = client._make_request.call_args[1]["trace"]
        assert payload["tags"] == []

    def test_trace_preserves_tags(self):
        """Custom tags should be preserved in the payload."""
        client = self._make_client()
        trace = Trace(client, "agent", tags=["env:prod", "team:backend"])
        trace.end()
        payload = client._make_request.call_args[1]["trace"]
        assert "env:prod" in payload["tags"]
        assert "team:backend" in payload["tags"]

    def test_trace_none_optional_fields(self):
        """Trace with no optional fields should serialize correctly."""
        client = self._make_client()
        trace = Trace(client, "minimal")
        trace.end()
        payload = client._make_request.call_args[1]["trace"]
        assert payload["name"] == "minimal"
        assert payload["user_id"] is None
        assert payload["session_id"] is None
        assert payload["metadata"] is None

    def test_span_end_without_args(self):
        """Calling end() with no args should just set end_time."""
        client = self._make_client()
        trace = Trace(client, "agent")
        span = trace.span("step")
        span.end()
        obs = trace._observations[0]
        assert obs["end_time"]
        assert obs.get("output") is None
        assert obs.get("status_message") is None

    def test_deeply_nested_tree(self):
        """Support 5+ levels of nesting."""
        client = self._make_client()
        trace = Trace(client, "deep")
        current = trace.span("level-0")
        for i in range(1, 6):
            current = current.span(f"level-{i}")
        current.end()
        assert len(trace._observations) == 6
        # Each child points to its parent
        for i in range(1, 6):
            assert trace._observations[i]["parent_observation_id"] == trace._observations[i - 1]["id"]

    def test_generation_inherits_span_methods(self):
        """Generation should support child spans and events (via Span inheritance)."""
        client = self._make_client()
        trace = Trace(client, "agent")
        gen = trace.generation("llm", model="claude-sonnet-4-6")
        child = gen.span("post-process")
        gen.event("log", input={"msg": "done"})
        child.end()
        gen.end(output="resp", usage={"input_tokens": 1, "output_tokens": 1})

        assert len(trace._observations) == 3
        assert trace._observations[1]["parent_observation_id"] == gen.id
        assert trace._observations[2]["parent_observation_id"] == gen.id

    def test_input_can_be_any_type(self):
        """Input/output should accept strings, lists, dicts, primitives."""
        client = self._make_client()
        trace = Trace(client, "agent")
        trace.span("str-input", input="hello").end(output="bye")
        trace.span("list-input", input=[1, 2, 3]).end(output=[4, 5])
        trace.span("int-input", input=42).end(output=0)
        trace.span("none-input").end()

        assert trace._observations[0]["input"] == "hello"
        assert trace._observations[1]["input"] == [1, 2, 3]
        assert trace._observations[2]["input"] == 42
        assert trace._observations[3]["input"] is None


class TestClientTraceMethod:
    """Tests for AshrLabsClient.trace() — the entrypoint for observability."""

    def test_trace_returns_trace_instance(self):
        client = AshrLabsClient(api_key="tp_test123", base_url="https://api.example.com")
        trace = client.trace("my-agent", user_id="u1")
        assert isinstance(trace, Trace)
        assert trace._name == "my-agent"
        assert trace._user_id == "u1"
        assert trace._client is client

    def test_trace_with_all_options(self):
        client = AshrLabsClient(api_key="tp_test123", base_url="https://api.example.com")
        trace = client.trace(
            "agent",
            user_id="u1",
            session_id="s1",
            metadata={"v": "2.0"},
            tags=["prod"],
        )
        assert trace._session_id == "s1"
        assert trace._metadata == {"v": "2.0"}
        assert trace._tags == ["prod"]

    def test_trace_minimal(self):
        client = AshrLabsClient(api_key="tp_test123", base_url="https://api.example.com")
        trace = client.trace("minimal")
        assert trace._user_id is None
        assert trace._session_id is None
        assert trace._tags == []

    @patch("ashr_labs.client.urlopen")
    def test_list_observability_traces(self, mock_urlopen):
        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps({
            "status": "ok",
            "traces": [{"id": "t1", "name": "agent"}],
            "total": 1,
        }).encode()
        mock_response.__enter__ = lambda s: s
        mock_response.__exit__ = MagicMock(return_value=False)
        mock_urlopen.return_value = mock_response

        client = AshrLabsClient(api_key="tp_test123", base_url="https://api.example.com")
        result = client.list_observability_traces(user_id="u1", limit=10)
        assert result["status"] == "ok"
        assert result["total"] == 1

    @patch("ashr_labs.client.urlopen")
    def test_get_observability_trace(self, mock_urlopen):
        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps({
            "status": "ok",
            "trace": {"id": "t1", "name": "agent", "observations": []},
        }).encode()
        mock_response.__enter__ = lambda s: s
        mock_response.__exit__ = MagicMock(return_value=False)
        mock_urlopen.return_value = mock_response

        client = AshrLabsClient(api_key="tp_test123", base_url="https://api.example.com")
        result = client.get_observability_trace("t1")
        assert result["status"] == "ok"
        assert result["trace"]["id"] == "t1"
