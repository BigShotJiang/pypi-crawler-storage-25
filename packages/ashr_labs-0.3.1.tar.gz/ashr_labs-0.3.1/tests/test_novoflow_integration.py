"""
Integration test: validates CDP log capture flows through novoflow's adapter
pattern into the Python SDK's TestBuilder → vm_stream.logs.
"""

import json
from ashr_labs import RunBuilder, TestBuilder


class TestNovoflowCdpLogIntegration:
    """End-to-end flow: CDP capture → captureVmMetadata → attachVmStreams → result."""

    def _simulate_cdp_logs(self):
        """Simulate what CDP event listeners would capture during a session."""
        return [
            {"ts": 0, "type": "navigation", "data": {"url": "https://app.novoflow.com/dashboard"}},
            {"ts": 120, "type": "console", "data": {"level": "log", "message": "Session initialized"}},
            {"ts": 450, "type": "network", "data": {"method": "POST", "url": "/api/employee/action", "status": 200}},
            {"ts": 800, "type": "network", "data": {"method": "GET", "url": "/api/employee/status", "status": 200}},
            {"ts": 1200, "type": "console", "data": {"level": "warn", "message": "Slow query detected"}},
            {"ts": 1500, "type": "navigation", "data": {"url": "https://app.novoflow.com/ticket/123"}},
            {"ts": 2000, "type": "network", "data": {"method": "POST", "url": "/api/ticket/update", "status": 503}},
            {"ts": 2100, "type": "error", "data": {"message": "TypeError: Cannot read property 'id' of undefined"}},
            {"ts": 3000, "type": "console", "data": {"level": "log", "message": "Agent completed task"}},
        ]

    def test_logs_flow_through_set_kernel_vm(self):
        """Logs passed to set_kernel_vm end up in vm_stream.logs."""
        logs = self._simulate_cdp_logs()

        run = RunBuilder()
        run.start()
        test = run.add_test("scenario_1")
        test.start()
        test.add_user_text("Update ticket 123", "User request")
        test.set_kernel_vm(
            session_id="w4przfb2h0uvln25f5x59dji",
            duration_ms=3000,
            logs=logs,
            live_view_url="https://proxy.iad.onkernel.com/live/abc",
            cdp_ws_url="wss://proxy.iad.onkernel.com/cdp?jwt=...",
            replay_id="replay_001",
            replay_view_url="https://www.kernel.sh/replays/replay_001",
            viewport={"width": 1024, "height": 768},
        )
        test.complete()
        run.complete()

        result = run.build()
        vm = result["tests"][0]["vm_stream"]

        # Core fields
        assert vm["provider"] == "kernel"
        assert vm["session_id"] == "w4przfb2h0uvln25f5x59dji"
        assert vm["duration_ms"] == 3000

        # Metadata
        assert vm["metadata"]["replay_id"] == "replay_001"
        assert vm["metadata"]["viewport"] == {"width": 1024, "height": 768}

        # CRITICAL: logs are populated
        assert "logs" in vm
        assert len(vm["logs"]) == 9

        # Verify structure
        assert vm["logs"][0] == {"ts": 0, "type": "navigation", "data": {"url": "https://app.novoflow.com/dashboard"}}
        assert vm["logs"][7]["type"] == "error"
        assert "TypeError" in vm["logs"][7]["data"]["message"]

    def test_no_logs_backwards_compatible(self):
        """Existing runs without logs still work."""
        test = TestBuilder("no_logs")
        test.set_kernel_vm(
            session_id="sess_abc",
            viewport={"width": 1024, "height": 768},
        )
        result = test.build()
        vm = result["vm_stream"]
        assert vm["provider"] == "kernel"
        assert "logs" not in vm

    def test_empty_logs(self):
        """Empty logs array is preserved."""
        test = TestBuilder("empty")
        test.set_kernel_vm(session_id="sess_abc", logs=[])
        result = test.build()
        assert result["vm_stream"]["logs"] == []

    def test_multiple_tests_independent_logs(self):
        """Each test gets its own log stream."""
        run = RunBuilder()
        run.start()

        t1 = run.add_test("s1")
        t1.start()
        t1.set_kernel_vm("sess_1", logs=[
            {"ts": 0, "type": "navigation", "data": {"url": "https://page1.com"}},
        ])
        t1.complete()

        t2 = run.add_test("s2")
        t2.start()
        t2.set_kernel_vm("sess_2", logs=[
            {"ts": 0, "type": "navigation", "data": {"url": "https://page2.com"}},
            {"ts": 100, "type": "error", "data": {"message": "crash"}},
        ])
        t2.complete()

        run.complete()
        result = run.build()

        assert len(result["tests"][0]["vm_stream"]["logs"]) == 1
        assert len(result["tests"][1]["vm_stream"]["logs"]) == 2
        assert result["tests"][0]["vm_stream"]["logs"][0]["data"]["url"] == "https://page1.com"
        assert result["tests"][1]["vm_stream"]["logs"][1]["type"] == "error"

    def test_json_round_trip(self):
        """Logs survive JSON serialization (what happens on API submission)."""
        test = TestBuilder("roundtrip")
        test.set_kernel_vm("kern_1", logs=[
            {"ts": 0, "type": "navigation", "data": {"url": "https://example.com"}},
            {"ts": 1000, "type": "network", "data": {"method": "POST", "url": "/api", "status": 200, "body": {"key": "value"}}},
        ])
        result = test.build()

        # Round-trip through JSON (simulates API submission)
        parsed = json.loads(json.dumps(result))
        vm = parsed["vm_stream"]

        assert len(vm["logs"]) == 2
        assert vm["logs"][0] == {"ts": 0, "type": "navigation", "data": {"url": "https://example.com"}}
        assert vm["logs"][1]["data"]["body"] == {"key": "value"}
