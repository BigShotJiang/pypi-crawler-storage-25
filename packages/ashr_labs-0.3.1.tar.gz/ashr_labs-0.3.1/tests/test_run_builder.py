"""
Tests for RunBuilder and TestBuilder, including VM stream support.
"""

import pytest
from ashr_labs import RunBuilder, TestBuilder


class TestTestBuilderVmStream:
    """Tests for TestBuilder.set_vm_stream and set_kernel_vm."""

    def test_set_vm_stream_all_fields(self):
        """set_vm_stream should store all fields."""
        test = TestBuilder("t1")
        test.start()
        test.set_vm_stream(
            provider="browserbase",
            session_id="sess_abc",
            duration_ms=5000,
            logs=[
                {"ts": 0, "type": "navigation", "data": {"url": "https://example.com"}},
                {"ts": 1000, "type": "action", "data": {"action": "click", "selector": "#btn"}},
            ],
            metadata={"browser": "chromium"},
        )
        test.complete()
        result = test.build()

        assert result["vm_stream"]["provider"] == "browserbase"
        assert result["vm_stream"]["session_id"] == "sess_abc"
        assert result["vm_stream"]["duration_ms"] == 5000
        assert len(result["vm_stream"]["logs"]) == 2
        assert result["vm_stream"]["metadata"]["browser"] == "chromium"

    def test_set_vm_stream_minimal(self):
        """set_vm_stream with only provider should work."""
        test = TestBuilder("t1")
        test.set_vm_stream(provider="steel")
        result = test.build()

        assert result["vm_stream"] == {"provider": "steel"}

    def test_set_vm_stream_provider_and_logs(self):
        """set_vm_stream with provider and logs only."""
        logs = [{"ts": 0, "type": "navigation", "data": {"url": "https://x.com"}}]
        test = TestBuilder("t1")
        test.set_vm_stream(provider="steel", logs=logs)
        result = test.build()

        assert result["vm_stream"]["provider"] == "steel"
        assert result["vm_stream"]["logs"] == logs
        assert "session_id" not in result["vm_stream"]
        assert "duration_ms" not in result["vm_stream"]
        assert "metadata" not in result["vm_stream"]

    def test_no_vm_stream_by_default(self):
        """build() should not include vm_stream when not set."""
        test = TestBuilder("t1")
        test.start()
        test.complete()
        result = test.build()

        assert "vm_stream" not in result

    def test_set_vm_stream_chaining(self):
        """set_vm_stream should return self for chaining."""
        test = TestBuilder("t1")
        ret = test.set_vm_stream(provider="kernel")
        assert ret is test

    def test_set_vm_stream_overwrites(self):
        """Calling set_vm_stream twice should overwrite the first."""
        test = TestBuilder("t1")
        test.set_vm_stream(provider="browserbase", session_id="old")
        test.set_vm_stream(provider="kernel", session_id="new")
        result = test.build()

        assert result["vm_stream"]["provider"] == "kernel"
        assert result["vm_stream"]["session_id"] == "new"


class TestTestBuilderKernelVm:
    """Tests for TestBuilder.set_kernel_vm."""

    def test_kernel_vm_basic(self):
        """set_kernel_vm should set provider to kernel."""
        test = TestBuilder("t1")
        test.set_kernel_vm(session_id="kern_123")
        result = test.build()

        assert result["vm_stream"]["provider"] == "kernel"
        assert result["vm_stream"]["session_id"] == "kern_123"

    def test_kernel_vm_all_metadata(self):
        """set_kernel_vm should pass all metadata fields."""
        test = TestBuilder("t1")
        test.set_kernel_vm(
            session_id="kern_123",
            duration_ms=15000,
            logs=[{"ts": 0, "type": "navigation", "data": {"url": "https://app.com"}}],
            live_view_url="https://www.kernel.sh/live/kern_123",
            cdp_ws_url="wss://connect.kernel.sh/kern_123",
            replay_id="replay_abc",
            replay_view_url="https://www.kernel.sh/replays/replay_abc",
            headless=False,
            stealth=True,
            viewport={"width": 1920, "height": 1080},
        )
        result = test.build()
        vm = result["vm_stream"]

        assert vm["provider"] == "kernel"
        assert vm["session_id"] == "kern_123"
        assert vm["duration_ms"] == 15000
        assert len(vm["logs"]) == 1
        assert vm["metadata"]["live_view_url"] == "https://www.kernel.sh/live/kern_123"
        assert vm["metadata"]["cdp_ws_url"] == "wss://connect.kernel.sh/kern_123"
        assert vm["metadata"]["replay_id"] == "replay_abc"
        assert vm["metadata"]["replay_view_url"] == "https://www.kernel.sh/replays/replay_abc"
        assert vm["metadata"]["headless"] is False
        assert vm["metadata"]["stealth"] is True
        assert vm["metadata"]["viewport"] == {"width": 1920, "height": 1080}

    def test_kernel_vm_no_metadata(self):
        """set_kernel_vm with no metadata kwargs should omit metadata."""
        test = TestBuilder("t1")
        test.set_kernel_vm(session_id="kern_123")
        result = test.build()

        assert "metadata" not in result["vm_stream"]

    def test_kernel_vm_partial_metadata(self):
        """set_kernel_vm with some metadata kwargs should include only those."""
        test = TestBuilder("t1")
        test.set_kernel_vm(
            session_id="kern_123",
            replay_id="replay_abc",
            stealth=True,
        )
        result = test.build()
        meta = result["vm_stream"]["metadata"]

        assert meta["replay_id"] == "replay_abc"
        assert meta["stealth"] is True
        assert "live_view_url" not in meta
        assert "cdp_ws_url" not in meta
        assert "viewport" not in meta

    def test_kernel_vm_chaining(self):
        """set_kernel_vm should return self for chaining."""
        test = TestBuilder("t1")
        ret = test.set_kernel_vm(session_id="kern_123")
        assert ret is test


class TestRunBuilderWithVmStream:
    """Tests for RunBuilder producing results with VM streams."""

    def test_run_with_vm_stream(self):
        """Full RunBuilder flow with VM stream should serialize correctly."""
        run = RunBuilder()
        run.start()

        test = run.add_test("scenario_1")
        test.start()
        test.add_user_text("Hello", "Greeting")
        test.set_kernel_vm(
            session_id="kern_sess_001",
            duration_ms=8000,
            logs=[
                {"ts": 0, "type": "navigation", "data": {"url": "https://app.com"}},
                {"ts": 2000, "type": "action", "data": {"action": "click", "selector": "#btn"}},
            ],
            replay_id="replay_001",
        )
        test.complete()
        run.complete()

        result = run.build()
        assert len(result["tests"]) == 1

        test_result = result["tests"][0]
        assert test_result["test_id"] == "scenario_1"
        assert test_result["vm_stream"]["provider"] == "kernel"
        assert test_result["vm_stream"]["session_id"] == "kern_sess_001"
        assert test_result["vm_stream"]["metadata"]["replay_id"] == "replay_001"

    def test_run_mixed_tests_with_and_without_vm(self):
        """RunBuilder with one VM test and one without."""
        run = RunBuilder()
        run.start()

        t1 = run.add_test("with_vm")
        t1.start()
        t1.set_kernel_vm(session_id="kern_1")
        t1.complete()

        t2 = run.add_test("without_vm")
        t2.start()
        t2.complete()

        run.complete()
        result = run.build()

        assert "vm_stream" in result["tests"][0]
        assert "vm_stream" not in result["tests"][1]
