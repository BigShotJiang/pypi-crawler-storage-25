"""
FindReplaceBar widget tests.

Tests the inline find/replace bar behaviour:
- Visibility and mode toggling
- Find next via button and Enter key
- Sequential finds (bar stays open)
- Replace current and replace all
- Close button and Escape key
- Focus restoration after close
"""

from pathlib import Path

from tests.conftest import make_app
from textual_code.widgets.find_replace_bar import FindReplaceBar

# ── helpers ───────────────────────────────────────────────────────────────────


async def _open_file(workspace: Path, content: str, name: str = "test.txt") -> Path:
    f = workspace / name
    f.write_text(content)
    return f


# ── visibility ────────────────────────────────────────────────────────────────


async def test_ctrl_f_shows_bar_find_mode(workspace: Path):
    """Ctrl+F: bar visible, replace_mode=False."""
    f = await _open_file(workspace, "hello world\n")
    app = make_app(workspace, open_file=f, light=True)
    async with app.run_test() as pilot:
        await pilot.wait_for_scheduled_animations()
        editor = app.main_view.get_active_code_editor()
        assert editor is not None
        await pilot.press("ctrl+f")
        await pilot.wait_for_scheduled_animations()
        bar = editor.query_one(FindReplaceBar)
        assert bar.display
        assert not bar.replace_mode


async def test_ctrl_h_shows_bar_replace_mode(workspace: Path):
    """Ctrl+H: bar visible, replace_mode=True."""
    f = await _open_file(workspace, "hello world\n")
    app = make_app(workspace, open_file=f, light=True)
    async with app.run_test() as pilot:
        await pilot.wait_for_scheduled_animations()
        editor = app.main_view.get_active_code_editor()
        assert editor is not None
        await pilot.press("ctrl+h")
        await pilot.wait_for_scheduled_animations()
        bar = editor.query_one(FindReplaceBar)
        assert bar.display
        assert bar.replace_mode


async def test_escape_closes_bar(workspace: Path):
    """Escape while bar is focused closes the bar."""
    f = await _open_file(workspace, "hello world\n")
    app = make_app(workspace, open_file=f, light=True)
    async with app.run_test() as pilot:
        await pilot.wait_for_scheduled_animations()
        editor = app.main_view.get_active_code_editor()
        assert editor is not None
        editor.action_find()
        await pilot.wait_for_scheduled_animations()
        # focus is on find_input
        await pilot.press("escape")
        await pilot.wait_for_scheduled_animations()
        bar = editor.query_one(FindReplaceBar)
        assert not bar.display


async def test_close_btn_hides_bar(workspace: Path):
    """Clicking ✕ hides the bar."""
    f = await _open_file(workspace, "hello world\n")
    app = make_app(workspace, open_file=f, light=True)
    async with app.run_test() as pilot:
        await pilot.wait_for_scheduled_animations()
        editor = app.main_view.get_active_code_editor()
        assert editor is not None
        editor.action_find()
        await pilot.wait_for_scheduled_animations()
        await pilot.click("#close_btn")
        await pilot.wait_for_scheduled_animations()
        bar = editor.query_one(FindReplaceBar)
        assert not bar.display


async def test_close_returns_focus_to_textarea(workspace: Path):
    """Closing the bar returns focus to the MultiCursorTextArea."""
    from textual_code.widgets.multi_cursor_text_area import MultiCursorTextArea

    f = await _open_file(workspace, "hello world\n")
    app = make_app(workspace, open_file=f, light=True)
    async with app.run_test() as pilot:
        await pilot.wait_for_scheduled_animations()
        editor = app.main_view.get_active_code_editor()
        assert editor is not None
        editor.action_find()
        await pilot.wait_for_scheduled_animations()
        await pilot.click("#close_btn")
        await pilot.wait_for_scheduled_animations()
        assert app.focused == editor.query_one(MultiCursorTextArea)


# ── mode switching ────────────────────────────────────────────────────────────


async def test_replace_row_hidden_in_find_mode(workspace: Path):
    """In find mode, the replace row is not displayed."""
    f = await _open_file(workspace, "hello world\n")
    app = make_app(workspace, open_file=f, light=True)
    async with app.run_test() as pilot:
        await pilot.wait_for_scheduled_animations()
        editor = app.main_view.get_active_code_editor()
        assert editor is not None
        editor.action_find()
        await pilot.wait_for_scheduled_animations()
        replace_row = editor.query_one("#replace_row")
        assert not replace_row.display


async def test_replace_row_visible_in_replace_mode(workspace: Path):
    """In replace mode, the replace row is displayed."""
    f = await _open_file(workspace, "hello world\n")
    app = make_app(workspace, open_file=f, light=True)
    async with app.run_test() as pilot:
        await pilot.wait_for_scheduled_animations()
        editor = app.main_view.get_active_code_editor()
        assert editor is not None
        editor.action_replace()
        await pilot.wait_for_scheduled_animations()
        replace_row = editor.query_one("#replace_row")
        assert replace_row.display


async def test_ctrl_h_after_ctrl_f_switches_to_replace_mode(workspace: Path):
    """Opening replace bar after find bar switches mode."""
    f = await _open_file(workspace, "hello world\n")
    app = make_app(workspace, open_file=f, light=True)
    async with app.run_test() as pilot:
        await pilot.wait_for_scheduled_animations()
        editor = app.main_view.get_active_code_editor()
        assert editor is not None
        await pilot.press("ctrl+f")
        await pilot.wait_for_scheduled_animations()
        bar = editor.query_one(FindReplaceBar)
        assert not bar.replace_mode
        await pilot.press("ctrl+h")
        await pilot.wait_for_scheduled_animations()
        assert bar.replace_mode


# ── Find Next via bar ─────────────────────────────────────────────────────────


async def test_find_next_button_selects_match(workspace: Path):
    """Clicking Next selects the first match."""
    f = await _open_file(workspace, "hello world\nhello again\n")
    app = make_app(workspace, open_file=f, light=True)
    async with app.run_test() as pilot:
        await pilot.wait_for_scheduled_animations()
        editor = app.main_view.get_active_code_editor()
        assert editor is not None
        editor.action_find()
        await pilot.wait_for_scheduled_animations()
        await pilot.click("#find_input")
        await pilot.press("h", "e", "l", "l", "o")
        await pilot.click("#next_match")
        await pilot.wait_for_scheduled_animations()
        sel = editor.editor.selection
        assert sel.start == (0, 0)
        assert sel.end == (0, 5)


async def test_find_next_enter_key_selects_match(workspace: Path):
    """Pressing Enter in find_input triggers find next."""
    f = await _open_file(workspace, "hello world\n")
    app = make_app(workspace, open_file=f, light=True)
    async with app.run_test() as pilot:
        await pilot.wait_for_scheduled_animations()
        editor = app.main_view.get_active_code_editor()
        assert editor is not None
        editor.action_find()
        await pilot.wait_for_scheduled_animations()
        await pilot.click("#find_input")
        await pilot.press("h", "e", "l", "l", "o")
        await pilot.press("enter")
        await pilot.wait_for_scheduled_animations()
        sel = editor.editor.selection
        assert sel.start == (0, 0)
        assert sel.end == (0, 5)


async def test_sequential_find_stays_open(workspace: Path):
    """Bar stays open across multiple Next clicks."""
    f = await _open_file(workspace, "aa bb aa cc aa\n")
    app = make_app(workspace, open_file=f, light=True)
    async with app.run_test() as pilot:
        await pilot.wait_for_scheduled_animations()
        editor = app.main_view.get_active_code_editor()
        assert editor is not None
        editor.action_find()
        await pilot.wait_for_scheduled_animations()
        await (
            pilot.wait_for_scheduled_animations()
        )  # Windows: extra pause for find bar rendering
        await pilot.click("#find_input")
        await (
            pilot.wait_for_scheduled_animations()
        )  # Windows: extra pause for focus to settle on find input
        await pilot.press("a", "a")
        await (
            pilot.wait_for_scheduled_animations()
        )  # Windows: extra pause for key presses

        await pilot.click("#next_match")
        await pilot.wait_for_scheduled_animations()
        await pilot.wait_for_scheduled_animations()
        bar = editor.query_one(FindReplaceBar)
        assert bar.display
        first_sel = editor.editor.selection.start

        await pilot.click("#next_match")
        await pilot.wait_for_scheduled_animations()
        await pilot.wait_for_scheduled_animations()
        assert bar.display
        second_sel = editor.editor.selection.start

        # successive finds moved the cursor forward
        assert second_sel > first_sel


async def test_find_next_empty_query_does_nothing(workspace: Path):
    """Empty query leaves cursor unchanged."""
    f = await _open_file(workspace, "hello world\n")
    app = make_app(workspace, open_file=f, light=True)
    async with app.run_test() as pilot:
        await pilot.wait_for_scheduled_animations()
        editor = app.main_view.get_active_code_editor()
        assert editor is not None
        original = editor.editor.cursor_location
        editor.action_find()
        await pilot.wait_for_scheduled_animations()
        await pilot.click("#next_match")
        await pilot.wait_for_scheduled_animations()
        assert editor.editor.cursor_location == original


# ── Replace via bar ───────────────────────────────────────────────────────────


async def test_replace_all_btn_replaces_all(workspace: Path):
    """Replace All button replaces every occurrence."""
    f = await _open_file(workspace, "foo bar foo baz\n")
    app = make_app(workspace, open_file=f, light=True)
    async with app.run_test() as pilot:
        await pilot.wait_for_scheduled_animations()
        editor = app.main_view.get_active_code_editor()
        assert editor is not None
        editor.action_replace()
        await pilot.wait_for_scheduled_animations()
        await pilot.click("#find_input")
        await pilot.press("f", "o", "o")
        await pilot.click("#replace_input")
        await pilot.press("X")
        await pilot.click("#replace_all_btn")
        await pilot.wait_for_scheduled_animations()
        assert "foo" not in editor.text
        assert editor.text.count("X") == 2


async def test_replace_btn_selection_matches_replaces_and_finds_next(workspace: Path):
    """Replace button: selection matches → replace and find next."""
    f = await _open_file(workspace, "hello hello\n")
    app = make_app(workspace, open_file=f, light=True)
    async with app.run_test() as pilot:
        await pilot.wait_for_scheduled_animations()
        editor = app.main_view.get_active_code_editor()
        assert editor is not None

        from textual.widgets.text_area import Selection

        editor.editor.selection = Selection(start=(0, 0), end=(0, 5))
        await pilot.wait_for_scheduled_animations()

        editor.action_replace()
        await pilot.wait_for_scheduled_animations()
        await pilot.click("#find_input")
        await pilot.press("h", "e", "l", "l", "o")
        await pilot.click("#replace_input")
        await pilot.press("h", "i")
        await pilot.click("#replace_btn")
        await pilot.wait_for_scheduled_animations()

        assert editor.text.startswith("hi")
        assert "hello" in editor.text  # second occurrence remains


async def test_replace_btn_no_selection_match_finds_next(workspace: Path):
    """Replace button: selection doesn't match → find next without replacing."""
    f = await _open_file(workspace, "hello world\nhello again\n")
    app = make_app(workspace, open_file=f, light=True)
    async with app.run_test() as pilot:
        await pilot.wait_for_scheduled_animations()
        editor = app.main_view.get_active_code_editor()
        assert editor is not None

        original_text = editor.text
        editor.editor.cursor_location = (0, 0)
        await pilot.wait_for_scheduled_animations()

        editor.action_replace()
        await pilot.wait_for_scheduled_animations()
        await pilot.click("#find_input")
        await pilot.press("h", "e", "l", "l", "o")
        await pilot.click("#replace_input")
        await pilot.press("h", "i")
        await pilot.click("#replace_btn")
        await pilot.wait_for_scheduled_animations()

        # text unchanged but 'hello' selected
        assert editor.text == original_text
        sel = editor.editor.selection
        assert sel.start == (0, 0)
        assert sel.end == (0, 5)


# ── Case-sensitive toggle ─────────────────────────────────────────────────────


async def test_case_insensitive_find_via_bar(workspace: Path):
    """Unchecking Aa checkbox causes case-insensitive find."""
    from textual.widgets import Checkbox

    f = await _open_file(workspace, "HELLO world\n")
    app = make_app(workspace, open_file=f, light=True)
    async with app.run_test() as pilot:
        await pilot.wait_for_scheduled_animations()
        editor = app.main_view.get_active_code_editor()
        assert editor is not None

        editor.action_find()
        await pilot.wait_for_scheduled_animations()
        bar = editor.query_one(FindReplaceBar)

        # Uncheck case_sensitive
        bar.query_one("#case_sensitive", Checkbox).value = False
        await pilot.wait_for_scheduled_animations()

        await pilot.click("#find_input")
        await pilot.press("h", "e", "l", "l", "o")
        await pilot.click("#next_match")
        await pilot.wait_for_scheduled_animations()

        sel = editor.editor.selection
        assert sel.start == (0, 0)
        assert sel.end == (0, 5)


async def test_regex_on_disables_case_sensitive_checkbox(workspace: Path):
    """Enabling regex disables the case_sensitive checkbox."""
    from textual.widgets import Checkbox

    f = await _open_file(workspace, "hello\n")
    app = make_app(workspace, open_file=f, light=True)
    async with app.run_test() as pilot:
        await pilot.wait_for_scheduled_animations()
        editor = app.main_view.get_active_code_editor()
        assert editor is not None

        editor.action_find()
        await pilot.wait_for_scheduled_animations()
        bar = editor.query_one(FindReplaceBar)

        await pilot.click("#use_regex")
        await pilot.wait_for_scheduled_animations()
        await (
            pilot.wait_for_scheduled_animations()
        )  # Windows: extra pause for checkbox click state propagation

        case_cb = bar.query_one("#case_sensitive", Checkbox)
        assert case_cb.disabled


async def test_replace_enter_key_triggers_replace(workspace: Path):
    """Pressing Enter in replace_input triggers single Replace."""
    f = await _open_file(workspace, "hello hello\n")
    app = make_app(workspace, open_file=f, light=True)
    async with app.run_test() as pilot:
        await pilot.wait_for_scheduled_animations()
        editor = app.main_view.get_active_code_editor()
        assert editor is not None

        # Open replace mode
        editor.action_replace()
        await pilot.wait_for_scheduled_animations()

        # Type find query and find next to select the first match
        await pilot.click("#find_input")
        await pilot.press("h", "e", "l", "l", "o")
        await pilot.click("#next_match")
        await pilot.wait_for_scheduled_animations()

        # Verify match is selected
        sel = editor.editor.selection
        assert sel.start == (0, 0)
        assert sel.end == (0, 5)

        # Type replacement and press Enter in replace input
        await pilot.click("#replace_input")
        await pilot.press("h", "i")
        await pilot.press("enter")
        await pilot.wait_for_scheduled_animations()

        # First "hello" should be replaced with "hi"
        assert editor.text.startswith("hi")
        assert "hello" in editor.text  # second occurrence remains


async def test_regex_on_get_case_sensitive_always_true(workspace: Path):
    """When regex is on, _get_case_sensitive() always returns True."""
    from textual.widgets import Checkbox

    f = await _open_file(workspace, "hello\n")
    app = make_app(workspace, open_file=f, light=True)
    async with app.run_test() as pilot:
        await pilot.wait_for_scheduled_animations()
        editor = app.main_view.get_active_code_editor()
        assert editor is not None

        editor.action_find()
        await pilot.wait_for_scheduled_animations()
        bar = editor.query_one(FindReplaceBar)

        # Uncheck case_sensitive, then turn regex on
        bar.query_one("#case_sensitive", Checkbox).value = False
        await pilot.wait_for_scheduled_animations()
        await pilot.click("#use_regex")
        await pilot.wait_for_scheduled_animations()

        assert bar._get_case_sensitive() is True


# ── Regex hint on replace input ──────────────────────────────────────────────


async def test_regex_hint_shown_on_replace_input(workspace: Path):
    """Toggling regex on updates replace input placeholder with \\1 hint."""
    from textual.widgets import Checkbox, Input

    f = await _open_file(workspace, "hello world\n")
    app = make_app(workspace, open_file=f, light=True)
    async with app.run_test() as pilot:
        await pilot.wait_for_scheduled_animations()
        editor = app.main_view.get_active_code_editor()
        assert editor is not None

        # Open replace mode
        await pilot.press("ctrl+h")
        await pilot.wait_for_scheduled_animations()
        bar = editor.query_one(FindReplaceBar)
        replace_input = bar.query_one("#replace_input", Input)

        # Default placeholder
        assert replace_input.placeholder == "Replace with..."

        # Toggle regex on
        bar.query_one("#use_regex", Checkbox).value = True
        await pilot.wait_for_scheduled_animations()

        assert replace_input.placeholder == "Replace with... (\\1 for groups)"


async def test_regex_hint_hidden_when_regex_off(workspace: Path):
    """Toggling regex off reverts replace input placeholder."""
    from textual.widgets import Checkbox, Input

    f = await _open_file(workspace, "hello world\n")
    app = make_app(workspace, open_file=f, light=True)
    async with app.run_test() as pilot:
        await pilot.wait_for_scheduled_animations()
        editor = app.main_view.get_active_code_editor()
        assert editor is not None

        await pilot.press("ctrl+h")
        await pilot.wait_for_scheduled_animations()
        bar = editor.query_one(FindReplaceBar)
        replace_input = bar.query_one("#replace_input", Input)

        # Toggle regex on then off
        bar.query_one("#use_regex", Checkbox).value = True
        await pilot.wait_for_scheduled_animations()
        bar.query_one("#use_regex", Checkbox).value = False
        await pilot.wait_for_scheduled_animations()

        assert replace_input.placeholder == "Replace with..."
