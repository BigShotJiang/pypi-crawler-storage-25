"""iTE installer - streamlined installer for the iTE AI coding assistant."""

__version__ = "0.0.1"
