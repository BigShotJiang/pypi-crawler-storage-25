"""Main entry point for ite-install."""

import argparse
import subprocess
import sys


def run(cmd: list[str], check: bool = True) -> subprocess.CompletedProcess:
    """Run a command and return the result."""
    return subprocess.run(cmd, check=check, capture_output=True, text=True)


def main() -> int:
    """Install or upgrade iTE using uv."""
    parser = argparse.ArgumentParser(
        description="Install iTE, the AI coding assistant"
    )
    parser.add_argument(
        "--upgrade",
        action="store_true",
        help="Upgrade iTE to the latest version",
    )
    parser.add_argument(
        "--python",
        default="python3.12",
        help="Python version to use (default: python3.12)",
    )
    args = parser.parse_args()

    package = "ite-agent"
    python_version = args.python

    try:
        if args.upgrade:
            print(f"Upgrading {package}...")
            run([sys.executable, "-m", "uv", "tool", "upgrade", package])
            print(f"✓ {package} upgraded successfully!")
        else:
            print(f"Installing {package}...")
            run([
                sys.executable, "-m", "uv", "tool", "install",
                "--python", python_version,
                package
            ])
            print(f"✓ {package} installed successfully!")

        print("Updating shell configuration...")
        result = run([sys.executable, "-m", "uv", "tool", "update-shell"], check=False)
        if result.returncode == 0:
            print("✓ Shell configuration updated.")
            print("\nYou may need to restart your terminal or run 'source ~/.bashrc'")
        else:
            print("Note: Could not auto-update shell config. Add this to your shell profile:")
            print("  export PATH=\"$HOME/.local/bin:$PATH\"")

        print("\nTry running: ite --help")
        return 0

    except subprocess.CalledProcessError as e:
        print(f"Error: {e}", file=sys.stderr)
        if e.stderr:
            print(e.stderr, file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
