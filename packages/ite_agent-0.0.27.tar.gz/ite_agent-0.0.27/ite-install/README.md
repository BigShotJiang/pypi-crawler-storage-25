# ⚠️ DEPRECATED

**This package is deprecated.**

Use one of these instead:

```bash
# Recommended:
pipx install ite-agent

# With uv:
uv tool install ite-agent
```

This bootstrapper is no longer maintained and may be removed from PyPI.
