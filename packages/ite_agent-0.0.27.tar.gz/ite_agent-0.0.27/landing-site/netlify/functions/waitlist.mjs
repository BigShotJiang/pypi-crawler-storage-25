import { createWaitlistService } from "../../server/waitlist-core.mjs";

function json(status, payload) {
  return new Response(JSON.stringify(payload), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store"
    }
  });
}

export default async function handler(req) {
  if (req.method !== "POST") {
    return json(405, { message: "Method not allowed" });
  }

  let payload;
  try {
    payload = await req.json();
  } catch {
    return json(400, { message: "Invalid JSON payload" });
  }

  const email = String(payload?.email || "").trim().toLowerCase();
  const company = String(payload?.company || "").trim();
  const startedAt = Number(payload?.startedAt || 0);

  if (company) {
    return json(200, { message: "Thanks. You're on the early access list." });
  }

  if (!Number.isFinite(startedAt) || Date.now() - startedAt < 1200) {
    return json(429, { message: "Please try again in a moment." });
  }

  try {
    const service = createWaitlistService(process.env);
    const result = await service.registerSignup(email, "landing-page");
    return json(result.status, { message: result.message });
  } catch (error) {
    console.error("waitlist signup failed", error);
    return json(500, {
      message: "Could not save your signup right now. Please try again."
    });
  }
}

export const config = {
  path: "/api/waitlist",
  rateLimit: {
    windowLimit: 8,
    windowSize: 60,
    aggregateBy: ["ip", "domain"]
  }
};
