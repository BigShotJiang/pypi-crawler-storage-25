# iTE Landing Site

Standalone Netlify-ready landing site for iTE.

## Deploy shape

- Static site root: `.`
- Netlify Functions: `netlify/functions`
- Waitlist logic: `server/waitlist-core.mjs`
- Database: Turso
- Abuse controls: Netlify function rate limiting + form honeypot

## Required environment variables

- `TURSO_DATABASE_URL`
- `TURSO_AUTH_TOKEN`

## Optional email variables

- `RESEND_API_KEY`
- `WAITLIST_FROM_EMAIL`

If `RESEND_API_KEY` and `WAITLIST_FROM_EMAIL` are set, the waitlist function sends a confirmation email after a successful signup. `WAITLIST_FROM_EMAIL` must be a verified sender/domain in Resend.

## Local dev

```bash
npm install
npx netlify dev
```
