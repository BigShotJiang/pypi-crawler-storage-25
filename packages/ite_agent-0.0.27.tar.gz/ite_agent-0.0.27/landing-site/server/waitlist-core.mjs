import { createClient } from "@libsql/client";
import { Resend } from "resend";

const TABLE_SQL = `
CREATE TABLE IF NOT EXISTS waitlist_signups (
  email TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  source TEXT NOT NULL DEFAULT 'landing-page',
  confirmation_sent_at TEXT
)
`;

export function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function buildConfirmationEmail(email) {
  const escapedEmail = email
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;");

  return {
    subject: "You're on the iTE early access list",
    text: [
      "You're on the iTE early access list.",
      "",
      `We saved ${email}.`,
      "We'll reach out when the next build is ready.",
      "",
      "Follow along on X: https://x.com/itetheagent",
      "",
      "iTE"
    ].join("\n"),
    html: `
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>You're on the iTE early access list</title>
  </head>
  <body style="margin:0;padding:0;background:#f3f5f7;color:#111827;font-family:Inter,Manrope,Arial,sans-serif;">
    <div style="display:none;max-height:0;overflow:hidden;opacity:0;">
      You're on the iTE early access list.
    </div>
    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background:#f3f5f7;padding:32px 16px;">
      <tr>
        <td align="center">
          <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="max-width:620px;background:#ffffff;border:1px solid #e5e7eb;border-radius:20px;overflow:hidden;box-shadow:0 12px 40px rgba(15,23,42,0.08);">
            <tr>
              <td style="padding:22px 28px;border-bottom:1px solid #eef1f4;background:#fbfcfd;">
                <div style="display:inline-block;padding:8px 12px;border-radius:10px;border:1px solid rgba(78,222,163,0.28);background:rgba(78,222,163,0.1);font-family:'JetBrains Mono','SFMono-Regular',Consolas,monospace;font-size:13px;font-weight:700;letter-spacing:0.08em;color:#178f67;text-transform:uppercase;">
                  iTE
                </div>
              </td>
            </tr>
            <tr>
              <td style="padding:38px 28px 18px;">
                <div style="font-size:40px;line-height:1.02;font-weight:800;letter-spacing:-0.05em;color:#111827;margin:0 0 18px;">
                  You’re on the iTE early access list.
                </div>
                <div style="font-size:17px;line-height:1.75;color:#4b5563;margin:0 0 14px;">
                  We saved <span style="color:#111827;font-weight:600;">${escapedEmail}</span> and we’ll reach out when the next build is ready.
                </div>
                <div style="font-size:17px;line-height:1.75;color:#4b5563;margin:0 0 28px;">
                  Thanks for joining early. iTE is being shaped into a faster, tighter coding workflow that lives where you already work.
                </div>
                <table role="presentation" cellspacing="0" cellpadding="0" style="margin:0 0 28px;">
                  <tr>
                    <td>
                      <a href="https://x.com/itetheagent" style="display:inline-block;padding:13px 18px;border-radius:12px;background:#111827;color:#ffffff;font-size:15px;font-weight:700;text-decoration:none;">
                        Follow iTE on X
                      </a>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
            <tr>
              <td style="padding:20px 28px 28px;border-top:1px solid #eef1f4;background:#fbfcfd;">
                <div style="font-size:12px;line-height:1.7;color:#6b7280;">
                  You received this because you signed up for iTE early access.
                </div>
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
  </body>
</html>`.trim()
  };
}

export function createWaitlistService(env = process.env) {
  function getClient() {
    const url = env.TURSO_DATABASE_URL;
    const authToken = env.TURSO_AUTH_TOKEN;
    if (!url || !authToken) {
      throw new Error("Missing Turso configuration");
    }
    return createClient({ url, authToken });
  }

  async function ensureTable(client) {
    await client.execute(TABLE_SQL);
  }

  function getEmailClient() {
    const apiKey = env.RESEND_API_KEY;
    const from = env.WAITLIST_FROM_EMAIL;
    if (!apiKey || !from) {
      return { resend: null, from: null };
    }

    return { resend: new Resend(apiKey), from };
  }

  async function sendConfirmationEmail(email) {
    const { resend, from } = getEmailClient();
    if (!resend || !from) {
      return false;
    }
    const message = buildConfirmationEmail(email);

    await resend.emails.send({
      from,
      to: email,
      subject: message.subject,
      text: message.text,
      html: message.html
    });

    return true;
  }

  async function registerSignup(email, source = "landing-page") {
    const normalizedEmail = String(email || "").trim().toLowerCase();
    if (!isValidEmail(normalizedEmail)) {
      return {
        ok: false,
        status: 400,
        message: "Please enter a valid email"
      };
    }

    const client = getClient();
    await ensureTable(client);

    const existing = await client.execute({
      sql: "SELECT email FROM waitlist_signups WHERE email = ?",
      args: [normalizedEmail]
    });

    if (existing.rows.length > 0) {
      return {
        ok: true,
        status: 200,
        message: "You're already on the early access list."
      };
    }

    const createdAt = new Date().toISOString();
    await client.execute({
      sql: "INSERT INTO waitlist_signups(email, created_at, source) VALUES (?, ?, ?)",
      args: [normalizedEmail, createdAt, source]
    });

    let confirmationSent = false;
    try {
      confirmationSent = await sendConfirmationEmail(normalizedEmail);
    } catch {
      confirmationSent = false;
    }

    if (confirmationSent) {
      await client.execute({
        sql: "UPDATE waitlist_signups SET confirmation_sent_at = ? WHERE email = ?",
        args: [new Date().toISOString(), normalizedEmail]
      });
    }

    return {
      ok: true,
      status: 200,
      message: confirmationSent
        ? "Congrats, you're on the early access list. Check your inbox for confirmation."
        : "Congrats, you're on the early access list."
    };
  }

  return {
    registerSignup
  };
}
