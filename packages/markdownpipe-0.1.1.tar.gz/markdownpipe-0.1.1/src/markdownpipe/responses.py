from __future__ import annotations

from typing import Any, Dict, List, Optional, Union

from pydantic import AliasChoices, BaseModel, Field

from .models import Article, Product, Serp
from .enums import PipeMode, ResponseStatus


class PipeUsageBreakdown(BaseModel):
    """Per-op credit breakdown (opt-in via X-Show-Billing-Breakdown: true header)."""

    base: float = Field(default=0.0, description="Base endpoint credit cost")
    total_dsl: float = Field(default=0.0, description="Total DSL execution cost")
    ops: Dict[str, Any] = Field(default_factory=dict, description="Per-op cost details")


class PipeUsage(BaseModel):
    """
    Statistics regarding a single API request's resource consumption.
    """

    latency: Optional[float] = Field(default=0.0, description="Latency in milliseconds")
    credits: float = Field(default=0.0, description="Total credits consumed")
    breakdown: Optional[PipeUsageBreakdown] = Field(
        default=None,
        description="Per-op credit breakdown (only present when X-Show-Billing-Breakdown: true header is sent)",
    )


class ValidationResponse(BaseModel):
    """
    Response model for DSL and Schema validation.
    """

    ast: Optional[Dict[str, Any]] = Field(None, description="The parsed AST object")
    dsl: Optional[str] = Field(None, description="The normalized DSL string")
    credits: Optional[float] = Field(
        None, description="The estimated credits cost for this query"
    )
    checksum: Optional[str] = Field(
        None, description="The unique cryptographic checksum for this schema"
    )
    version: Optional[str] = Field(
        None, description="The pinned logic version for this schema"
    )


class PipeResponse(BaseModel):
    """
    Standard envelope for structured content extraction.
    """

    status: ResponseStatus = Field(
        default=ResponseStatus.SUCCESS, description="Request status"
    )
    data: Union[Article, Product, Serp] = Field(
        ..., description="The highly-structured scraped content"
    )
    usage: PipeUsage = Field(
        default_factory=PipeUsage, description="Resource consumption metrics"
    )
    job_id: Optional[str] = Field(
        None,
        validation_alias=AliasChoices("job_id", "id"),
        description="Optional job identifier if content was stored",
    )
    storage_url: Optional[str] = Field(
        None, description="Direct URL to stored HTML (if stored)"
    )


class MarkdownResponse(BaseModel):
    """
    Response model for the /markdown endpoint (HTML → Markdown converter).
    """

    status: ResponseStatus = Field(
        default=ResponseStatus.SUCCESS, description="Request status"
    )
    data: Dict[str, Any] = Field(..., description="Contains 'markdown' key")
    job_id: Optional[str] = Field(
        None,
        validation_alias=AliasChoices("job_id", "id"),
        description="Storage identifier",
    )
    storage_url: Optional[str] = Field(
        None,
        description="Direct URL to stored raw HTML (gzip compressed). Use get_stored_html() to fetch.",
    )
    usage: Optional[PipeUsage] = Field(default_factory=PipeUsage)

    @property
    def markdown(self) -> str:
        """Convenience access to the markdown content."""
        return self.data.get("markdown", "")


class ExtractResponse(BaseModel):
    """
    Response model for custom schema extraction (/pipe and /extract endpoints).

    Both `/pipe` and `/extract` return this envelope. Use `data` to access
    extracted fields, `storage_url` to fetch the raw HTML, and `usage` for
    billing/performance metrics.
    """

    status: ResponseStatus = Field(
        default=ResponseStatus.SUCCESS, description="The status of the extraction"
    )
    data: Dict[str, Any] = Field(..., description="The extracted structured data")
    job_id: Optional[str] = Field(
        None,
        validation_alias=AliasChoices("job_id", "id"),
        description="Optional job identifier if content was stored",
    )
    storage_url: Optional[str] = Field(
        None,
        description="Direct URL to stored raw HTML (gzip compressed). Use get_stored_html() to fetch.",
    )
    usage: Optional[PipeUsage] = Field(
        default_factory=PipeUsage, description="Standardized usage metrics"
    )


class MapItem(BaseModel):
    """
    A single URL discovered during the Map phase.
    """

    url: str = Field(..., description="The absolute URL discovered")
    title: Optional[str] = Field(None, description="The title of the page if available")
    description: Optional[str] = Field(
        None,
        description="The description or summary of the content (from RSS/Atom feeds)",
    )
    type: PipeMode = Field(
        ..., description="The discovery source: sitemap, rss, or map"
    )
    metadata: Dict[str, Any] = Field(
        default_factory=dict, description="Additional context from discovery"
    )


class MapResponse(BaseModel):
    """
    Response model for domain mapping/discovery.

    The backend may return URLs in different formats:
    - str: Simple URL string
    - MapItem: Structured discovery data with metadata
    - Dict[str, Any]: Raw dictionary format

    This flexibility allows the backend to optimize response size based on
    discovery source (sitemap, RSS, or link crawling).
    """

    status: ResponseStatus = Field(
        default=ResponseStatus.SUCCESS, description="Request status"
    )
    urls: List[Union[str, MapItem, Dict[str, Any]]] = Field(
        ...,
        description="List of discovered URLs (may be strings or structured items)",
    )
    total: Optional[int] = Field(None, description="Total count of discovered URLs")
    usage: Optional[PipeUsage] = Field(
        default_factory=PipeUsage, description="Standardized usage metrics"
    )

    @property
    def count(self) -> int:
        """Return the number of discovered URLs."""
        return len(self.urls)

    def __iter__(self):
        """Iterate over discovery results."""
        return iter(self.urls)

    def __len__(self):
        """Return the number of results."""
        return len(self.urls)

    def __getitem__(self, index):
        """Get a specific result by index."""
        return self.urls[index]


class RawPipeResponse(BaseModel):
    """
    Response model for the initial acquisition layer (/fetch).

    Raw HTML is never returned directly. Use storage_url with
    get_stored_html() to retrieve the HTML content.

    ``job_id`` may be omitted when the backend does not persist HTML
    (e.g. ``STORAGE_SAVES_HTML`` off); cached hits include extra fields such as
    ``cached`` / ``cached_at`` which Pydantic ignores on this model.
    """

    job_id: Optional[str] = Field(
        default=None,
        validation_alias=AliasChoices("job_id", "id"),
        description="Storage identifier for the fetched content (if stored)",
    )
    url: str = Field(..., description="The actual URL fetched")
    storage_url: Optional[str] = Field(
        None,
        description="Direct URL to stored raw HTML (gzip compressed). Use get_stored_html() to fetch.",
    )
    usage: Optional[PipeUsage] = Field(default_factory=PipeUsage)

    @property
    def id(self) -> str:
        """Alias for job_id for backward compatibility."""
        if self.job_id is None:
            raise ValueError("job_id is not set on this response")
        return self.job_id


class EngineRequest(BaseModel):
    """
    Request model for the intelligence layer (/engine).
    """

    html: str = Field(..., description="Raw HTML content provided directly")
    url: Optional[str] = Field(None, description="Original URL for context/base_url")
    schema_config: Dict[str, Any] = Field(
        ...,
        alias="schema",
        description="Dictionary mapping field names to Chained DSL selectors",
    )


class EngineResponse(BaseModel):
    """
    Response model for the intelligence layer (/engine).
    """

    status: ResponseStatus = Field(
        default=ResponseStatus.SUCCESS, description="Request status"
    )
    data: Dict[str, Any] = Field(..., description="The extracted structured data")
    usage: Optional[PipeUsage] = Field(default_factory=PipeUsage)


class UsageRecord(BaseModel):
    """
    Represents a single usage record for billing/audit.
    """

    id: str
    url: Optional[str] = None
    status_code: int = 200
    credits_cost: float = 0.0
    response_time_ms: int = 0
    created_at: str


class UsageSummaryResponse(BaseModel):
    """
    Response model for /usage/summary.
    """

    total_credits_used: float
    recent_records: List[UsageRecord] = Field(default_factory=list)


class CsvResponseData(BaseModel):
    """Data envelope for /csv response."""

    markdown: str = Field(..., description="Resulting Markdown table")
    rows: int = Field(..., description="Number of data rows processed")


class CsvResponse(BaseModel):
    """Response model for the /markdown/csv endpoint."""

    status: ResponseStatus = Field(
        default=ResponseStatus.SUCCESS, description="Request status"
    )
    data: CsvResponseData = Field(..., description="Conversion result")
    usage: Optional[PipeUsage] = Field(default_factory=PipeUsage)

    @property
    def markdown(self) -> str:
        """Convenience access to the markdown table."""
        return self.data.markdown


class CsvBatchResponseData(BaseModel):
    """Data envelope for /csv/batch response."""

    results: List[str] = Field(..., description="List of Markdown tables")
    count: int = Field(..., description="Number of items processed")


class CsvBatchResponse(BaseModel):
    """Response model for the /markdown/csv/batch endpoint."""

    status: ResponseStatus = Field(
        default=ResponseStatus.SUCCESS, description="Request status"
    )
    data: CsvBatchResponseData = Field(..., description="Batch conversion results")
    usage: Optional[PipeUsage] = Field(default_factory=PipeUsage)


class PdfResponseData(BaseModel):
    """Data envelope for /pdf response."""

    markdown: str = Field(..., description="Resulting Markdown string.")
    pages: int = Field(default=1, description="Number of pages processed.")


class PdfResponse(BaseModel):
    """Response model for the /markdown/pdf endpoint."""

    status: ResponseStatus = Field(
        default=ResponseStatus.SUCCESS, description="Request status"
    )
    data: PdfResponseData = Field(..., description="Conversion result")
    usage: Optional[PipeUsage] = Field(default_factory=PipeUsage)

    @property
    def markdown(self) -> str:
        """Convenience access to the markdown content."""
        return self.data.markdown


class ExcelResponseData(BaseModel):
    """Data envelope for /excel response."""

    markdown: str = Field(..., description="Resulting Markdown table.")
    sheet_name: str = Field(default="First Sheet", description="Sheet name converted.")


class ExcelResponse(BaseModel):
    """Response model for the /markdown/excel endpoint."""

    status: ResponseStatus = Field(
        default=ResponseStatus.SUCCESS, description="Request status"
    )
    data: ExcelResponseData = Field(..., description="Conversion result")
    usage: Optional[PipeUsage] = Field(default_factory=PipeUsage)

    @property
    def markdown(self) -> str:
        """Convenience access to the markdown table."""
        return self.data.markdown
