from __future__ import annotations

from pydantic import BaseModel, Field

from .dsl import QueryAST


class PipeQuerySchema(BaseModel):
    """
    Standard API Schema for accepting and validating User DSL.
    When a user sends a DSL string, this schema parses it,
    calculates metadata, and returns the full AST.
    """

    dsl: str = Field(..., description="The Pseudo-DSL query string from user")

    def validate_and_process(self) -> PipeQueryResponse:
        """
        Parses the DSL into a validated QueryAST with checksum and metadata.
        """
        # 1. Parse (Raises ValueError/Pydantic errors if invalid)
        ast = QueryAST.from_dsl(self.dsl)

        return PipeQueryResponse(
            ast=ast,
            dsl=ast.serialize(include_meta=False),
            version=ast.version,
        )


class PipeQueryResponse(BaseModel):
    """
    Standard API Response for DSL Validation.
    """

    ast: QueryAST = Field(..., description="The full parsed AST object")
    dsl: str = Field(..., description="The DSL string in its standard format")
    version: str = Field(..., description="AST Schema version")
