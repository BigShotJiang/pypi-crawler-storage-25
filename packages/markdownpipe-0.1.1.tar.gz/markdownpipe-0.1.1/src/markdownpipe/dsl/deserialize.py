from __future__ import annotations

import re
from typing import List, Literal, Optional, Tuple, TYPE_CHECKING, Union

from .constants import FILTER_PSEUDOS_CLASSES

if TYPE_CHECKING:
    from .ast import QueryAST


def deserialize(text: str) -> QueryAST:
    """
    Parses a DSL string into a QueryAST object.
    """
    from .ast import Expr, FilterOp, RuleOp, QueryAST

    text = text.strip()
    engine: Literal["css", "xpath", "regex"] = "css"
    if text.startswith("@"):
        engine_match = re.match(r"^@([a-z]+):(.*)$", text)
        if engine_match:
            engine_val = engine_match.group(1).lower()
            if engine_val in ("css", "xpath", "regex"):
                engine = engine_val  # type: ignore[assignment]
                text = engine_match.group(2).strip()

    # Tokenize the rest of the DSL
    parts = _split_dsl_tokens(text)
    if not parts:
        raise ValueError("Empty DSL")

    # 1. Base Selector
    if parts[0].startswith(":") or parts[0].startswith("!"):
        parts.insert(0, "")

    selector_part = parts[0]
    if selector_part.startswith("(") and selector_part.endswith(")"):
        selector_part = selector_part[1:-1].strip()

    selector_expr: Union[str, List[str]]
    if "|" in selector_part:
        selector_expr = [p.strip() for p in selector_part.split("|")]
    else:
        selector_expr = selector_part

    # 2. Sequential components
    filters = []
    rules = []
    cleanup = []

    for p in parts[1:]:
        if p.startswith("!"):
            # Mutation (Cleanup)
            name, args = _parse_op_with_args(p[1:])
            if name == "cleanup" and args:
                cleanup.append(deserialize(args))
            else:
                # Other mutations mapped to rules for now
                rules.append(RuleOp(op=name, args=args))
        elif p.startswith("::"):
            # Action
            name, args = _parse_op_with_args(p[2:])
            rules.append(RuleOp(op=name, args=args))
        elif p.startswith(":"):
            # Filter
            name, args = _parse_op_with_args(p[1:])
            filters.append(FilterOp(op=name, expr=args))
        else:
            # Trailing CSS after a pseudo-class (e.g. :has(a) .link)
            val = p.strip()
            if val:
                filters.append(FilterOp(op="descendant", expr=val))

    return QueryAST(
        selector=Expr(engine=engine, expr=selector_expr),
        filters=filters,
        rules=rules,
        cleanup=cleanup if cleanup else None,
    )


def _split_dsl_tokens(text: str) -> List[str]:
    """Splits DSL into base selector and individual token segments (!, :, ::)."""
    parts = []
    depth = 0
    current = ""
    i = 0
    while i < len(text):
        char = text[i]
        next_char = text[i + 1] if i + 1 < len(text) else ""

        if char == "(":
            depth += 1
            current += char
        elif char == ")":
            depth -= 1
            current += char
        elif depth == 0:
            is_token = False
            token_len = 0

            # Mutations !
            if char == "!" and not current.endswith("\\"):
                is_token = True
                token_len = 1
            # Actions ::
            elif char == ":" and next_char == ":":
                is_token = True
                token_len = 2
            # Filters : (with lookahead check to avoid CSS pseudos)
            elif char == ":":
                name_end = i + 1
                while name_end < len(text) and (
                    text[name_end].isalnum() or text[name_end] == "-"
                ):
                    name_end += 1
                name = text[i + 1 : name_end].lower()

                if name in FILTER_PSEUDOS_CLASSES:
                    is_token = True
                    token_len = 1
            # Descendant transition
            elif char.isspace() or char in ".[#*>+~":
                if (
                    current.startswith(":")
                    or current.startswith("!")
                    or current.startswith("::")
                ):
                    is_token = True
                    token_len = 0

            if is_token:
                if current.strip():
                    parts.append(current.strip())
                if token_len > 0:
                    current = text[i : i + token_len]
                    i += token_len
                else:
                    current = ""
                continue
            else:
                current += char
        else:
            current += char
        i += 1

    if current.strip():
        parts.append(current.strip())
    return parts


def _parse_op_with_args(text: str) -> Tuple[str, Optional[str]]:
    """Parses 'name(args)' or just 'name'."""
    match = re.match(r"^([a-z0-9_-]+)(?:\((.*)\))?$", text.strip(), re.I)
    if not match:
        return text.strip(), None
    return match.group(1), match.group(2)
