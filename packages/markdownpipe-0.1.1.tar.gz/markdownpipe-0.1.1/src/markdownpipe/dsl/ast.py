"""
Selector AST models for Markdown Engine.
"""

from __future__ import annotations

from typing import Any, List, Literal, Optional, Union

from pydantic import BaseModel, ConfigDict, Field, field_validator

from .constants import (
    ACTION_PSEUDOS_CLASSES,
    FILTER_PSEUDOS_CLASSES,
)


class Expr(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    engine: Literal["css", "xpath", "regex"] = "css"
    expr: Union[str, List[str]]


class FilterOp(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    op: str
    expr: Optional[str] = None

    @field_validator("op")
    @classmethod
    def check_op(cls, v: str) -> str:
        if v not in FILTER_PSEUDOS_CLASSES:
            raise ValueError(
                f"Unknown filter op '{v}'. Allowed: {FILTER_PSEUDOS_CLASSES}"
            )
        return v


class RuleOp(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    op: str
    args: Optional[Any] = None

    @field_validator("op")
    @classmethod
    def check_op(cls, v: str) -> str:
        if v not in ACTION_PSEUDOS_CLASSES:
            raise ValueError(
                f"Unknown rule op '{v}'. Allowed: {ACTION_PSEUDOS_CLASSES}"
            )
        return v


class QueryAST(BaseModel):
    """Top-level AST for a single chained query.
    Standardized for Markdown Engine protocol.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    selector: Expr = Field(..., description="Base selector and engine selection")
    filters: List[FilterOp] = Field(
        default_factory=list, description="Ordered chain of filters"
    )
    rules: List[RuleOp] = Field(
        default_factory=list, description="Ordered chain of output actions"
    )

    # Metadata helpful for server-side validation and caching
    cleanup: Optional[List["QueryAST"]] = Field(
        None,
        description="Nested QueryASTs applied to remove nodes before main selection",
    )
    version: str = Field("1", description="AST Schema version")
    checksum: Optional[str] = Field(
        None, description="HMAC signature for integrity verification"
    )

    def serialize(self, include_meta: bool = True) -> str:
        """Helper to serialize this AST to DSL."""
        from .serialize import serialize

        return serialize(self, include_meta=include_meta)

    @classmethod
    def from_dsl(cls, dsl: str) -> "QueryAST":
        """Helper to create an AST from DSL string."""
        from .deserialize import deserialize

        return deserialize(dsl)


# Rebuild the model to resolve recursive string type 'QueryAST'
QueryAST.model_rebuild()
