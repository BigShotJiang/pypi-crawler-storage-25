from __future__ import annotations
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .ast import QueryAST


def serialize(ast: QueryAST, include_meta: bool = True) -> str:
    """
    Serializes a QueryAST object into a compact text DSL.
    Format: [checksum:][@engine:]<selector>[:filter...][ !mutation...][::rule...]
    """
    # 1. Engine
    engine_prefix = ""
    if ast.selector.engine != "css":
        engine_prefix = f"@{ast.selector.engine}:"

    # 2. Base Query
    if isinstance(ast.selector.expr, list):
        if (
            not ast.cleanup
            and not ast.filters
            and not ast.rules
            and all(" " not in x for x in ast.selector.expr)
        ):
            expr_str = "|".join(ast.selector.expr)
        else:
            expr_str = "(" + " | ".join(ast.selector.expr) + ")"
    else:
        expr_str = ast.selector.expr

    body = f"{engine_prefix}{expr_str}"

    # 3. Filters
    for f in ast.filters:
        if f.expr:
            body += f":{f.op}({f.expr})"
        else:
            body += f":{f.op}"

    # 4. Mutations (Cleanup)
    if ast.cleanup:
        for c in ast.cleanup:
            c_dsl = serialize(c, include_meta=False)
            body += f" !cleanup({c_dsl})"

    # 5. Rules (Actions)
    for r in ast.rules:
        if r.args:
            if isinstance(r.args, list):
                # Convert list args to comma separated quoted strings securely via repr
                args_str = ", ".join(
                    repr(a) if isinstance(a, str) else str(a) for a in r.args
                )
                body += f"::{r.op}({args_str})"
            else:
                body += (
                    f"::{r.op}({repr(r.args) if isinstance(r.args, str) else r.args})"
                )
        else:
            body += f"::{r.op}"

    return body
