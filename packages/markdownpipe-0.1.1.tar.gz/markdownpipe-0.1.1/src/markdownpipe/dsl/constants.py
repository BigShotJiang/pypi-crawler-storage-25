# Central list of pseudo-classes supported by the system
from __future__ import annotations

FILTER_PSEUDOS_CLASSES = [
    "icontains",
    "contains",
    "has",
    "not",
    "closest",
    "parent",
    "near",
    "matches",
    "semantic",
    "descendant",
    "children",
    "ancestor",
    "next",
    "prev",
]

ACTION_PSEUDOS_CLASSES = [
    "text",
    "html",
    "inner_html",
    "outer_html",
    "attr",
    "url",
    "strip",
    "split",
    "replace",
    "replace_regex",
    "table",
    "first",
    "last",
    "slice",
    "count",
    "join",
    "all",
    "redact",
    "json",
    "markdown",
    "csv",
]
