from __future__ import annotations

from typing import List, Literal, Optional, Union

from .ast import Expr, FilterOp, QueryAST, RuleOp
from .deserialize import deserialize
from .serialize import serialize


class Q:
    """
    Fluent builder for Markdown Scraper Query AST.

    The `Q` builder allows you to construct complex extraction chains locally
    using a natural, chained API. It compiles down to the high-performance
    Chained DSL Protocol.

    Example:
        ```python
        query = (
            Q(".main-content")
            .has("article")
            .cleanup(".ads")
            .html()
        )
        ```
    """

    def __init__(
        self,
        expr: Optional[Union[str, List[str]]] = None,
        engine: Literal["css", "xpath", "regex"] = "css",
    ):
        """
        Initialize a new query.

        Args:
            expr: The initial entry selector.
            engine: Engine to use for the entry selector ('css', 'xpath', 'regex').
        """
        self._selector = Expr(engine=engine, expr=expr or "")
        self._filters: List[FilterOp] = []
        self._rules: List[RuleOp] = []
        self._cleanup: List[QueryAST] = []

    def css(self, expr: Union[str, List[str]]) -> Q:
        """Switch entries to CSS engine."""
        self._selector = Expr(engine="css", expr=expr)
        return self

    def xpath(self, expr: Union[str, List[str]]) -> Q:
        """Switch entries to XPath engine."""
        self._selector = Expr(engine="xpath", expr=expr)
        return self

    def regex(self, expr: Union[str, List[str]]) -> Q:
        """Switch entries to Regex engine."""
        self._selector = Expr(engine="regex", expr=expr)
        return self

    # Filters
    def has(self, expr: str) -> Q:
        """Filter: Item must contain a child matching the selector."""
        self._filters.append(FilterOp(op="has", expr=expr))
        return self

    def not_(self, expr: str) -> Q:
        """Filter: Item must NOT match the selector."""
        self._filters.append(FilterOp(op="not", expr=expr))
        return self

    def contains(self, text: str) -> Q:
        """Filter: Item must contain the specific text."""
        self._filters.append(FilterOp(op="contains", expr=text))
        return self

    def icontains(self, text: str) -> Q:
        """Filter: Item must contain text (case-insensitive)."""
        self._filters.append(FilterOp(op="icontains", expr=text))
        return self

    def matches(self, regex: str) -> Q:
        """Filter: Item text must match a regex."""
        self._filters.append(FilterOp(op="matches", expr=regex))
        return self

    def near(self, query: str) -> Q:
        """Filter: Pivot context to find items near specific text."""
        self._filters.append(FilterOp(op="near", expr=query))
        return self

    def parent(self) -> Q:
        """Filter: Move scope to immediate parent."""
        self._filters.append(FilterOp(op="parent"))
        return self

    def children(self) -> Q:
        """Filter: Move scope to all immediate children."""
        self._filters.append(FilterOp(op="children"))
        return self

    def closest(self, expr: str) -> Q:
        """Filter: Move scope to the closest ancestor matching the selector."""
        self._filters.append(FilterOp(op="closest", expr=expr))
        return self

    def ancestor(self, n: int = 1) -> Q:
        """Filter: Move scope n levels up."""
        self._filters.append(FilterOp(op="ancestor", expr=str(n)))
        return self

    def next(self, n: int = 1) -> Q:
        """Filter: Move scope to the n-th next sibling."""
        self._filters.append(FilterOp(op="next", expr=str(n)))
        return self

    def prev(self, n: int = 1) -> Q:
        """Filter: Move scope to the n-th previous sibling."""
        self._filters.append(FilterOp(op="prev", expr=str(n)))
        return self

    def descendant(self, expr: str) -> Q:
        """Filter: Move scope to all descendants matching selector."""
        self._filters.append(FilterOp(op="descendant", expr=expr))
        return self

    def semantic(self, query: str) -> Q:
        """Filter: Deep semantic search for specific content context."""
        self._filters.append(FilterOp(op="semantic", expr=query))
        return self

    # Actions / Rules
    def text(self) -> Q:
        """Action: Extract plain text content."""
        self._rules.append(RuleOp(op="text"))
        return self

    def html(self) -> Q:
        """Action: Extract raw HTML content."""
        self._rules.append(RuleOp(op="html"))
        return self

    def markdown(self, commonmark: bool = True) -> Q:
        """Action: Convert selected HTML to clean Markdown.

        This action converts the selected HTML fragment into clean Markdown.

        When no explicit output action is specified (no `::text`, `::html`, or
        `::markdown`), the server default is Markdown output. Use this method
        when you need to explicitly request Markdown conversion, for example
        when combining with other actions or overriding a different default.

        Args:
            commonmark: If True (default), use CommonMark-compatible output.
                       If False, use a more relaxed Markdown dialect.

        Example:
            ```python
            # Explicit markdown conversion with cleanup
            Q("article").cleanup(".ads", ".nav").markdown()

            # CommonMark disabled
            Q(".content").markdown(commonmark=False)
            ```
        """
        if commonmark:
            self._rules.append(RuleOp(op="markdown"))
        else:
            self._rules.append(RuleOp(op="markdown", args="commonmark=false"))
        return self

    def inner_html(self) -> Q:
        """Action: Extract the inner HTML content of the element."""
        self._rules.append(RuleOp(op="inner_html"))
        return self

    def outer_html(self) -> Q:
        """Action: Extract the outer HTML content (including the tag itself)."""
        self._rules.append(RuleOp(op="outer_html"))
        return self

    def attr(self, name: str) -> Q:
        """Action: Extract a specific HTML attribute (e.g., 'src', 'href')."""
        self._rules.append(RuleOp(op="attr", args=name))
        return self

    def all(self) -> Q:
        """Action: Extract all matching nodes instead of just the first one."""
        self._rules.append(RuleOp(op="all"))
        return self

    def first(self) -> Q:
        """Action: Explicitly target the first match."""
        self._rules.append(RuleOp(op="first"))
        return self

    def last(self) -> Q:
        """Action: Explicitly target the last match."""
        self._rules.append(RuleOp(op="last"))
        return self

    def count(self) -> Q:
        """Action: Return the number of matching elements."""
        self._rules.append(RuleOp(op="count"))
        return self

    def table(self) -> Q:
        """Action: Extract HTML table as a structured JSON object or CSV."""
        self._rules.append(RuleOp(op="table"))
        return self

    def json(self) -> Q:
        """Action: Attempt to parse content as JSON (useful for LD+JSON)."""
        self._rules.append(RuleOp(op="json"))
        return self

    def strip(self) -> Q:
        """Action: Trim whitespace from extracted text."""
        self._rules.append(RuleOp(op="strip"))
        return self

    def url(self) -> Q:
        """Action: Resolve and extract the absolute URL of the element."""
        self._rules.append(RuleOp(op="url"))
        return self

    def slice(self, start: Union[int, str], end: Optional[int] = None) -> Q:
        """Action: Slice the resulting list of elements."""
        if isinstance(start, str) and ":" in start:
            # support .slice("1:5")
            self._rules.append(RuleOp(op="slice", args=start))
        else:
            self._rules.append(
                RuleOp(op="slice", args=[start, end] if end is not None else [start])
            )
        return self

    def join(self, sep: str = ", ") -> Q:
        """Action: Join multiple results into a single string."""
        self._rules.append(RuleOp(op="join", args=sep))
        return self

    def replace(self, old: str, new: str) -> Q:
        """Action: Perform literal string replacement on the result."""
        self._rules.append(RuleOp(op="replace", args=[old, new]))
        return self

    def replace_regex(self, pattern: str, repl: str, flags: str = "") -> Q:
        """Action: Perform regex replacement on the result.

        Args:
            pattern: Regex pattern.
            repl: Replacement string.
            flags: Optional flag string (e.g. 'i', 'm').
        """
        args = [pattern, repl]
        if flags:
            args.append(flags)
        self._rules.append(RuleOp(op="replace_regex", args=args))
        return self

    def split(self, sep: str, index: Optional[int] = None) -> Q:
        """Action: Split string and optionally pick a specific index."""
        if index is not None:
            self._rules.append(RuleOp(op="split", args=[sep, index]))
        else:
            self._rules.append(RuleOp(op="split", args=sep))
        return self

    def redact(self, type: Literal["email", "phone"] = "email") -> Q:
        """Action: Redact sensitive information like emails or phone numbers from the content."""
        self._rules.append(RuleOp(op="redact", args=type))
        return self

    def csv(self) -> Q:
        """Action: Convert HTML table to CSV format.

        Example:
            ```python
            Q("table.data").csv()
            ```
        """
        self._rules.append(RuleOp(op="csv"))
        return self

    def cleanup(self, *queries: Union[str, Q, QueryAST]) -> Q:
        """
        Action: Mutate the result by removing specific sub-elements (noise cleanup).

        Args:
            *queries: Selector strings, Q builders, or ASTs to remove.
        """
        for q in queries:
            if isinstance(q, str):
                self._cleanup.append(deserialize(q))
            elif isinstance(q, Q):
                self._cleanup.append(q.build())
            else:
                self._cleanup.append(q)
        return self

    def build(self) -> QueryAST:
        return QueryAST(
            selector=self._selector,
            filters=self._filters,
            rules=self._rules,
            cleanup=self._cleanup if self._cleanup else None,
            version="1",
        )

    def __or__(self, other: Union[str, Q]) -> Q:
        """
        Operator overload for Fallback (OR) logic on the Base Selector.
        Allows: (Q(".a") | ".b") or (Q(".a") | Q(".b"))
        """
        current_expr = self._selector.expr
        if isinstance(current_expr, str):
            expr_list = [current_expr] if current_expr else []
        else:
            expr_list = list(current_expr)

        if isinstance(other, str):
            if other not in expr_list:
                expr_list.append(other)
        elif isinstance(other, Q):
            other_expr = other._selector.expr
            if isinstance(other_expr, str):
                if other_expr and other_expr not in expr_list:
                    expr_list.append(other_expr)
            else:
                for ex in other_expr:
                    if ex not in expr_list:
                        expr_list.append(ex)

        self._selector = Expr(engine=self._selector.engine, expr=expr_list)
        return self

    def __str__(self) -> str:
        return serialize(self.build(), include_meta=False)
