from __future__ import annotations

import importlib.metadata

try:
    __version__ = importlib.metadata.version("markdownpipe")
except importlib.metadata.PackageNotFoundError:
    __version__ = "0.0.0"

__title__ = "markdownpipe"
__description__ = (
    "Markdown Pipe Python SDK (beta, pre-1.0): Python client for structured web scraping "
    "and fluent queries. APIs may change; initial PyPI release is intended as 0.1.0."
)

from .base import PipeHook, PipeStats
from .client import (
    AsyncClient,
    AsyncPipe,
    AsyncPipeClient,
    Client,
    MarkdownPipe,
    Pipe,
    PipeClient,
    SyncPipe,
)
from .dsl import Q, QueryAST
from .enums import JobStatus, PipeMode, PipeNamespace, PipeOutputFormat, ResponseStatus
from .exceptions import PipeError, PipeHTTPError, human_message_from_error_body, parse_pipe_api_error
from .models import Article, Product, Serp
from .responses import (
    CsvBatchResponse,
    CsvResponse,
    EngineRequest,
    EngineResponse,
    ExtractResponse,
    MapItem,
    MapResponse,
    MarkdownResponse,
    PipeResponse,
    PipeUsage,
    PipeUsageBreakdown,
    RawPipeResponse,
    ValidationResponse,
)
from .validator import PipeQueryResponse, PipeQuerySchema

__all__ = [
    "__version__",
    # Clients
    "MarkdownPipe",
    "SyncPipe",
    "Pipe",
    "AsyncPipe",
    "Client",
    "AsyncClient",
    "PipeClient",
    "AsyncPipeClient",
    # Hooks & Stats
    "PipeHook",
    "PipeStats",
    # Errors
    "PipeError",
    "PipeHTTPError",
    "human_message_from_error_body",
    "parse_pipe_api_error",
    # DSL
    "Q",
    "QueryAST",
    "PipeQuerySchema",
    "PipeQueryResponse",
    # Responses
    "ValidationResponse",
    "ExtractResponse",
    "EngineRequest",
    "EngineResponse",
    "MapResponse",
    "MapItem",
    "PipeResponse",
    "RawPipeResponse",
    "MarkdownResponse",
    "CsvResponse",
    "CsvBatchResponse",
    "PipeUsage",
    "PipeUsageBreakdown",
    # Enums
    "PipeMode",
    "JobStatus",
    "PipeNamespace",
    "PipeOutputFormat",
    "ResponseStatus",
    # Models
    "Article",
    "Product",
    "Serp",
]
