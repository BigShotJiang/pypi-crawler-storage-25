from __future__ import annotations

from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field, HttpUrl

from .base import CommonMetadata, ContentItem


class ProductAvailability(str, Enum):
    """Enumeration of product availability states."""

    IN_STOCK = "in_stock"
    OUT_OF_STOCK = "out_of_stock"
    PRE_ORDER = "pre_order"
    DISCONTINUED = "discontinued"
    UNKNOWN = "unknown"


class ProductPrice(BaseModel):
    """
    Schema for product pricing and availability.

    Attributes:
        currency: ISO 4217 currency code.
        amount: Current selling price.
        list_price: Original list price.
        availability: Current stock status.
        sku: Stock keeping unit.
        discount_percentage: Calculated discount between list_price and amount.
    """

    currency: Optional[str] = Field(
        default=None, description="ISO 4217 currency code (e.g., USD, VND)"
    )
    amount: Optional[float] = Field(default=None, ge=0, description="Price value")
    list_price: Optional[float] = Field(
        default=None, ge=0, description="Original/list price before discount"
    )
    availability: Optional[ProductAvailability] = Field(
        default=None, description="Availability status"
    )
    sku: Optional[str] = Field(default=None, description="Stock keeping unit")
    discount_percentage: Optional[float] = Field(
        default=None, description="Calculated discount percentage"
    )
    model_config = {"frozen": False}


class ProductReview(BaseModel):
    """
    Schema for product reviews and ratings.

    Attributes:
        rating: The primary rating value.
        count: Total number of reviews.
        avg_rating: Mean rating score.
    """

    rating: Optional[float] = Field(
        default=None, ge=0, le=5, description="Review rating 0..5 stars"
    )
    count: Optional[int] = Field(default=None, ge=0, description="Number of reviews")
    avg_rating: Optional[float] = Field(
        default=None, ge=0, le=5, description="Average rating"
    )
    model_config = {"frozen": False}


class ProductVariant(BaseModel):
    """
    Schema for product variants (sizes, colors, etc.).
    """

    id: Optional[str] = Field(default=None)
    name: Optional[str] = Field(
        default=None, description="Variant name (e.g. Color: Red, Size: XL)"
    )
    sku: Optional[str] = Field(default=None)
    price: Optional[ProductPrice] = Field(default=None)
    images: List[HttpUrl] = Field(default_factory=list)
    is_available: bool = Field(default=True)


class ProductSeller(BaseModel):
    """
    Schema for seller information.
    """

    name: Optional[str] = Field(
        default=None, description="Seller name (e.g. Amazon, 3rd party seller)"
    )
    id: Optional[str] = Field(default=None)
    rating: Optional[float] = Field(default=None)
    url: Optional[HttpUrl] = Field(default=None)


class ProductMetadata(CommonMetadata):
    """
    Rich metadata schema for e-commerce products.

    Attributes:
        brand: Manufacturer or brand name.
        category: Breadcrumb or category list.
        sku: Main product SKU.
        gtin: Global Trade Item Number.
        features: Key feature highlights.
        specs: Technical specifications.
        price: Pricing and availability details.
        review: Aggregate review data.
        images: Product gallery URLs.
        seller: Merchant information.
        variants: List of available product variations.
    """

    brand: Optional[str] = Field(default=None, description="Product brand/manufacturer")
    category: Optional[List[str]] = Field(
        default_factory=list, description="Product categories"
    )
    sku: Optional[str] = Field(default=None, description="Stock keeping unit")
    gtin: Optional[str] = Field(default=None, description="GTIN/EAN/UPC identifier")
    tags: Optional[List[str]] = Field(
        default_factory=list, description="Product tags/keywords"
    )
    features: List[str] = Field(
        default_factory=list, description="Product features/bullet points"
    )
    specs: Optional[Dict[str, Any]] = Field(
        default=None, description="Product specifications (key-value pairs)"
    )
    price: Optional[ProductPrice] = Field(default=None, description="Pricing information")
    review: Optional[ProductReview] = Field(
        default=None, description="Review and rating data"
    )
    images: Optional[List[HttpUrl]] = Field(
        default_factory=list, description="Product image URLs"
    )
    seller: Optional[ProductSeller] = Field(default=None)
    variants: List[ProductVariant] = Field(default_factory=list)


class Product(ContentItem):
    """
    Standardized container for product extraction results.

    Attributes:
        metadata: Detailed product metadata (price, reviews, variants, etc.).
        content: Inherited markdown description or details of the product.
    """

    metadata: ProductMetadata = Field(
        default_factory=ProductMetadata, description="Product-specific metadata"
    )

    @classmethod
    def from_html(
        cls,
        html: str,
        url: Optional[str] = None,
        **kwargs,
    ) -> "Product":
        """
        Create a Product from raw HTML.

        NOTE: In the SDK, this is a placeholder. For full extraction,
        use `scraper.product(url)`.
        """
        return cls(markdown="", raw=html, **kwargs)
