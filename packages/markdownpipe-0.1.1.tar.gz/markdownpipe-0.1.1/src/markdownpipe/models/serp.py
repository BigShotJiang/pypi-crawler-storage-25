from __future__ import annotations

from enum import Enum

from typing import List, Optional

from pydantic import BaseModel, Field, HttpUrl

from .base import CommonMetadata, ContentItem


class SerpResultType(str, Enum):
    """Enumeration of possible search result item types."""

    ORGANIC = "organic"
    AD = "ad"
    FEATURED_SNIPPET = "featured_snippet"
    VIDEO = "video"
    NEWS = "news"
    IMAGE = "image"
    UNKNOWN = "unknown"


class SearchEngine(str, Enum):
    """Supported search engines."""

    GOOGLE = "google"
    BING = "bing"
    BAIDU = "baidu"
    DUCKDUCKGO = "duckduckgo"
    YANDEX = "yandex"
    YAHOO = "yahoo"
    UNKNOWN = "unknown"


class SerpResultItem(BaseModel):
    """
    Individual search result item within a SERP.

    Attributes:
        title: Page title of the result.
        url: Destination URL.
        snippet: Meta description or result snippet.
        position: Weighted position in results.
        type: Result category (organic, ad, etc.).
        source: Display domain or source name.
    """

    title: Optional[str] = Field(default=None)
    url: HttpUrl = Field(description="The URL of the search result")
    snippet: Optional[str] = Field(
        default=None, description="Short description or snippet"
    )
    position: int = Field(default=0, description="Rank position in the SERP")
    type: SerpResultType = Field(
        default=SerpResultType.ORGANIC, description="Type of result"
    )
    source: Optional[str] = Field(
        default=None, description="Site name or domain of the result"
    )


class SerpMetadata(CommonMetadata):
    """
    Metadata schema for Search Engine Results Pages (SERP).

    Attributes:
        query: The search term used.
        engine: Which engine performed the search.
        total_results: Estimated total matches.
        search_time: Latency on engine side.
        location: Target geographic location for the crawl.
        page_number: Result page index.
    """

    query: Optional[str] = Field(default=None, description="The search query used")
    engine: SearchEngine = Field(
        default=SearchEngine.GOOGLE, description="Search engine name"
    )
    total_results: Optional[int] = Field(
        default=None, description="Approximate total results count"
    )
    search_time: Optional[float] = Field(
        default=None, description="Time taken by the engine to return results"
    )
    location: Optional[str] = Field(
        default=None, description="Geographical location for the search"
    )
    page_number: int = Field(default=1, description="Page number of the results")


class Serp(ContentItem):
    """
    Standardized container for Search Engine extraction results.

    Attributes:
        metadata: SERP-level metadata (query, engine, etc.).
        results: List of organic/sponsored results.
    """

    metadata: SerpMetadata = Field(default_factory=SerpMetadata)
    results: List[SerpResultItem] = Field(
        default_factory=list, description="List of search results"
    )

    model_config = {
        "title": "Serp",
    }

    @classmethod
    def from_html(
        cls,
        html: str,
        url: Optional[str] = None,
        **kwargs,
    ) -> "Serp":
        """
        Create a Serp from raw HTML.

        NOTE: In the SDK, this is a placeholder. For full extraction,
        use `scraper.serp(url)`.
        """
        return cls(markdown="", raw=html, **kwargs)
