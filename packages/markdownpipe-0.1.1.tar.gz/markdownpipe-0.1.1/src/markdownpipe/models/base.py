from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, Optional, Union

from pydantic import BaseModel, ConfigDict, Field, HttpUrl


class Provenance(BaseModel):
    """
    Tracking for source authenticity and origin.

    Attributes:
        source_url: The exact URL where the data was located.
        domain: Pre-parsed root domain.
    """

    source_url: Optional[HttpUrl] = Field(default=None, description="Canonical URL")
    domain: Optional[str] = Field(
        default=None, description="Root domain (e.g., example.com)"
    )


class CommonMetadata(BaseModel):
    """
    Shared metadata schema present across all content namespaces.

    Attributes:
        title: Content title or headline.
        description: Meta description or lead text.
        language: ISO-639-1 code (e.g., 'en', 'vi').
        canonical_url: The preferred version of the URL.
        word_count: Total estimated words in main content.
        reading_time_minutes: AI-estimated time to read.
        published_at: Original publishing timestamp.
        modified_at: Last known update timestamp.
        provenance: Source tracking details.
    """

    title: Optional[str] = Field(default=None, description="Title of the content")
    description: Optional[str] = Field(
        default=None, description="Brief summary or description"
    )
    language: Optional[str] = Field(
        default=None, description="ISO-639-1 (or BCP-47) language code"
    )
    canonical_url: Optional[HttpUrl] = Field(
        default=None, description="Canonical source URL"
    )
    word_count: Optional[int] = Field(
        default=None, description="Word count of the main content"
    )
    reading_time_minutes: Optional[float] = Field(
        default=None, description="Estimated reading time in minutes"
    )
    published_at: Optional[Union[datetime, str]] = Field(
        default=None, description="When content was published"
    )
    modified_at: Optional[Union[datetime, str]] = Field(
        default=None, description="When content was last modified"
    )
    inferred_source: Optional[str] = Field(
        default=None, description="Detected source/site name"
    )
    provenance: Provenance = Field(
        default_factory=Provenance, description="Source provenance information"
    )

    model_config = ConfigDict(
        populate_by_name=True,
        extra="forbid",
        frozen=False,
        arbitrary_types_allowed=True,
    )


class ContentItem(BaseModel):
    """
    Base class for all extraction payloads.

    This provides the basic structure for unique identification,
    timestamping, and markdown content storage.
    """

    id: Optional[str] = Field(None, description="Unique identifier.")
    markdown: Optional[str] = Field(
        None,
        description="Markdown content of the item.",
    )
    metadata: Union[Dict[str, Any], CommonMetadata] = Field(
        default_factory=dict, description="Associated metadata."
    )
    created_timestamp: Optional[float] = Field(
        default=None, description="Creation timestamp."
    )
    updated_timestamp: Optional[float] = Field(
        default=None, description="Last update timestamp."
    )
    raw: Optional[str] = Field(
        default=None, description="Raw HTML if explicitly requested/saved."
    )

    model_config = ConfigDict(
        populate_by_name=True,
        extra="allow",
        frozen=False,
        arbitrary_types_allowed=True,
    )

    @property
    def title(self) -> Optional[str]:
        if isinstance(self.metadata, dict):
            return self.metadata.get("title")
        return self.metadata.title

    @property
    def description(self) -> Optional[str]:
        if isinstance(self.metadata, dict):
            return self.metadata.get("description")
        return self.metadata.description
