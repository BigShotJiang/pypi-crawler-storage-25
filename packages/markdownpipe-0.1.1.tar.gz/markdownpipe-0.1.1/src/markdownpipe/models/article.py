from __future__ import annotations

from typing import List, Optional

from pydantic import Field

from .base import CommonMetadata, ContentItem


class ArticleMetadata(CommonMetadata):
    """
    Metadata schema for article-like content.

    Attributes:
        authors: List of article authors.
        tags: Taxonomy tags associated with the article.
        topics: High-level topics or categories.
        main_points: AI-generated or extracted key takeaways.
    """

    authors: Optional[List[str]] = Field(default_factory=list)
    tags: Optional[List[str]] = Field(default_factory=list)
    topics: Optional[List[str]] = Field(default_factory=list)
    main_points: Optional[List[str]] = Field(
        default_factory=list, description="Key takeaways or main points"
    )


class Article(ContentItem):
    """
    Standardized container for article extraction results.

    Attributes:
        metadata: Article-specific metadata (authors, tags, etc.).
        content: Inherited markdown content of the article.
    """

    metadata: ArticleMetadata = Field(default_factory=ArticleMetadata)

    model_config = {
        "title": "Article",
    }

    @classmethod
    def from_html(
        cls,
        html: str,
        url: Optional[str] = None,
        **kwargs,
    ) -> "Article":
        """
        Create an Article from raw HTML.

        NOTE: In the SDK, this is a placeholder. For full extraction,
        use `scraper.article(url)`.
        """
        return cls(markdown="", raw=html, **kwargs)
