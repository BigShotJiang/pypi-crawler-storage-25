from __future__ import annotations

import asyncio
import gzip
import logging
from collections.abc import AsyncIterator, Callable, Iterator
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, List, Optional

import httpx
from pydantic import TypeAdapter
from tenacity import (
    AsyncRetrying,
    Retrying,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)
from tqdm import tqdm

try:
    from tqdm.asyncio import tqdm as tqdm_async
except ImportError:
    tqdm_async: Any = tqdm

from .base import BasePipeClient, PipeHook
from .models import Article, Product, Serp
from .exceptions import PipeHTTPError, parse_pipe_api_error
from .responses import (
    CsvBatchResponse,
    CsvResponse,
    EngineResponse,
    ExtractResponse,
    MapItem,
    MapResponse,
    MarkdownResponse,
    RawPipeResponse,
    PipeResponse,
    PdfResponse,
    ExcelResponse,
    ValidationResponse,
    UsageSummaryResponse,
)

logger = logging.getLogger(__name__)

_validate_map_item_list = TypeAdapter(list[MapItem])


def _pipe_http_error_from_response(response: httpx.Response) -> PipeHTTPError:
    raw_text = response.text or ""
    message = raw_text or response.reason_phrase or "HTTP error"
    body: dict[str, Any] | None = None
    try:
        parsed = response.json()
    except Exception:
        parsed = None
    if isinstance(parsed, dict):
        message, body = parse_pipe_api_error(parsed)
    elif parsed is not None:
        message = str(parsed)
    return PipeHTTPError(
        response.status_code,
        message,
        body=body,
        raw_text=raw_text,
    )


def _parse_map_item_array_response(raw: Any) -> list[MapItem]:
    if not isinstance(raw, list):
        raise PipeHTTPError(
            500,
            f"Expected JSON array from discovery endpoint, got {type(raw).__name__}",
        )
    return _validate_map_item_list.validate_python(raw)


class AsyncPipeClient(BasePipeClient):
    """
    Asynchronous Python client for Markdown Pipe API.

    Transforms simple scraping into a Discovery-Driven Extraction pipeline.
    This client is designed for high-concurrency environments and asynchronous
    workloads using `async/await` syntax.

    Example:
        ```python
        async with AsyncPipeClient(api_key="sk-...") as client:
            result = await client.article("https://example.com/blog")
            print(result.markdown)
        ```
    """

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float = 30.0,
        hooks: Optional[List[PipeHook]] = None,
        max_retries: int = 3,
        **client_kwargs,
    ):
        """
        Initialize the AsyncPipeClient.

        Args:
            api_key: Your API key. Defaults to `MARKDOWN_PIPE_API_KEY` env var.
            base_url: Custom API endpoint. Defaults to production API.
            timeout: Request timeout in seconds.
            hooks: Optional list of `PipeHook` for observability.
            max_retries: Maximum number of exponential backoff retries for 429/5xx errors.
            **client_kwargs: Additional arguments passed to `httpx.AsyncClient`.
        """
        super().__init__(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            hooks=hooks,
            max_retries=max_retries,
        )
        self.client = httpx.AsyncClient(
            base_url=self.base_url,
            headers=self.headers,
            timeout=self.timeout,
            follow_redirects=True,
            **client_kwargs,
        )

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()

    async def close(self):
        await self.client.aclose()

    async def _request(self, method: str, endpoint: str, **kwargs) -> Any:
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        self._trigger_on_request(method, url, kwargs.get("json", {}))

        try:
            async for attempt in AsyncRetrying(
                stop=stop_after_attempt(self.max_retries),
                wait=wait_exponential(multiplier=1, min=2, max=10),
                retry=retry_if_exception_type(
                    (httpx.RequestError, httpx.HTTPStatusError)
                ),
                reraise=True,
            ):
                with attempt:
                    response = await self.client.request(
                        method, endpoint.lstrip("/"), **kwargs
                    )
                    # Only retry on 5xx or 429
                    if response.status_code >= 500 or response.status_code == 429:
                        response.raise_for_status()

                    # For other errors (4xx), don't retry, just raise
                    response.raise_for_status()
                    data = response.json()
                    if isinstance(data, dict):
                        # Inject core metadata from headers if missing in JSON body
                        if "credits" not in data and "X-Credits" in response.headers:
                            try:
                                data["credits"] = float(response.headers["X-Credits"])
                            except (ValueError, TypeError):
                                pass
                        if "checksum" not in data and "X-Checksum" in response.headers:
                            data["checksum"] = response.headers["X-Checksum"]
                        if "version" not in data and "X-Version" in response.headers:
                            data["version"] = response.headers["X-Version"]

                    self._trigger_on_response(url, data)
                    return data
            raise RuntimeError("Request failed to return data")
        except httpx.HTTPStatusError as e:
            logger.error(f"HTTP Error: {e.response.status_code} - {e.response.text}")
            self._trigger_on_error(url, e)
            raise _pipe_http_error_from_response(e.response) from e
        except Exception as e:
            logger.error(f"Request failed: {str(e)}")
            self._trigger_on_error(url, e)
            raise

    async def health(self) -> dict[str, Any]:
        """Check server health."""
        return await self._request("GET", "/health")

    async def fetch(
        self,
        url: str,
        **kwargs,
    ) -> RawPipeResponse:
        """
        Acquisition Phase: Fetches raw HTML and stores it.

        HTML is never returned directly. Use storage_url from the response
        with get_stored_html() to retrieve the raw HTML content.

        Args:
            url: The target URL to fetch.
            **kwargs: Extra parameters for the /fetch endpoint.

        Returns:
            RawPipeResponse with job_id and storage_url.
        """
        payload = {
            "url": url,
            **kwargs,
        }
        res = await self._request("POST", "/fetch/", json=payload)
        return RawPipeResponse.model_validate(res)

    async def engine(
        self,
        url: str,
        schema: dict[str, Any],
        html: str,
        **kwargs,
    ) -> EngineResponse:
        """
        Intelligence Phase: Direct DSL execution on raw HTML.

        This method processes raw HTML strings using the Chained DSL engine. This is a low-level operation compared to `pipe()`.

        Args:
            url: The source URL (required for context).
            schema: The extraction schema using Chained DSL.
            html: Raw HTML string to process.
            **kwargs: Extra parameters for the /engine endpoint.

        Returns:
            Validated EngineResponse object.
        """
        payload = {
            "url": url,
            "schema": self._serialize_schema(schema),
            "html": html,
            **kwargs,
        }
        res = await self._request("POST", "/engine/", json=payload)
        return EngineResponse.model_validate(res)

    async def pipe(
        self,
        url: str,
        schema: dict[str, Any],
        version: str | None = None,
        checksum: str | None = None,
        **kwargs,
    ) -> ExtractResponse:
        """
        Full Orchestration (The "Pipe"): fetch + engine + postprocess + validation.

        Args:
            url: The URL to scrape and extract.
            schema: The extraction schema (dict of Q builders or DSL strings).
            version: Optional pinned logic version.
            checksum: Optional pinned schema checksum for performance boost.
            **kwargs: Extra parameters.

        Returns:
            Validated ExtractResponse object.
        """
        payload = self._prepare_extract_payload(url, schema, **kwargs)
        headers = {}
        if version:
            headers["X-Version"] = version
        if checksum:
            headers["X-Checksum"] = checksum

        res = await self._request("POST", "/pipe/", json=payload, headers=headers)
        return ExtractResponse.model_validate(res)

    async def extract(
        self,
        url: str,
        schema: dict[str, Any],
        **kwargs,
    ) -> ExtractResponse:
        """
        Custom schema extraction.

        Extract specific fields from a URL using a custom Chained DSL schema.
        Unlike `pipe()`, this uses the dedicated `/extract` endpoint which has no
        namespace presets and is optimized for ad-hoc custom extraction.

        Args:
            url: The URL to scrape and extract.
            schema: The extraction schema (dict of Q builders or DSL strings).
            **kwargs: Extra parameters for the /extract endpoint.

        Returns:
            Validated ExtractResponse object.
        """
        payload = self._prepare_extract_payload(url, schema, **kwargs)
        headers = {}
        # Support checksum header for validation
        checksum = kwargs.pop("checksum", None)
        if checksum:
            headers["X-Checksum"] = checksum

        res = await self._request("POST", "/extract/", json=payload, headers=headers)
        return ExtractResponse.model_validate(res)

    async def map(
        self,
        url: str,
        depth: int = 1,
        ignore_sitemap: bool = False,
        selectors: list[str] | None = None,
        **kwargs,
    ) -> MapResponse:
        """
        Discovery Phase: URLs linked from **one fetched page**.

        Each call performs a single acquisition on the API (plus your SDK retries).
        Depth, feed mixing, and queuing belong in ``harvest()`` or your worker — not
        in repeated server-side crawling.
        """
        payload = self._prepare_map_payload(url, depth, ignore_sitemap, selectors)
        payload.update(kwargs)
        resp = await self._request("POST", "/map/", json=payload)
        return MapResponse.model_validate(resp)

    async def markdown(
        self,
        html: str,
        url: str | None = None,
        config: dict[str, Any] | None = None,
        **kwargs,
    ) -> MarkdownResponse:
        """
        Convert raw HTML to clean Markdown.

        This is a converter-only endpoint. For URL-based workflows,
        use fetch() first then pass the HTML here.

        Args:
            html: Raw HTML content to convert.
            url: Optional context URL for resolving relative links.
            config: Optional configuration (e.g. {"commonmark": True}).
            **kwargs: Extra parameters.

        Returns:
            MarkdownResponse with clean markdown and storage_url.
        """
        payload = {"html": html, **kwargs}
        if url:
            payload["url"] = url
        if config:
            payload["config"] = config
        res = await self._request("POST", "/markdown/", json=payload)
        return MarkdownResponse.model_validate(res)

    async def process(
        self, url: str, namespace: str = "article", **kwargs
    ) -> PipeResponse:
        """
        Intelligence Phase: Process content using a predefined namespace (article, product, serp).
        """
        payload = {"url": url, "namespace": namespace, **kwargs}
        res = await self._request("POST", "/pipe/", json=payload)
        return PipeResponse.model_validate(res)

    async def scrape_content(self, *args, **kwargs):
        """Deprecated alias for process()"""
        return await self.process(*args, **kwargs)

    async def article(self, url: str, **kwargs) -> Article:
        """
        Shortcut for piping a URL as an Article.

        Returns:
            Validated Article object.
        """
        res = await self.process(url, namespace="article", **kwargs)
        return Article.model_validate(res.data)

    async def product(self, url: str, **kwargs) -> Product:
        """Shortcut for piping a URL as a Product."""
        raise NotImplementedError(
            "Product extraction is not yet implemented. Use engine() with custom DSL."
        )

    async def serp(self, url: str, **kwargs) -> Serp:
        """Shortcut for piping Search Engine Results (SERP)."""
        raise NotImplementedError(
            "SERP extraction is not yet implemented. Use engine() with custom DSL."
        )

    async def validate(self, schema_or_dsl: dict[str, Any] | str) -> ValidationResponse:
        """
        Validates a Chained DSL string or a full extraction Schema.
        Returns the parsed AST, signature checksum, and estimated credits.
        """
        payload = {}
        if isinstance(schema_or_dsl, str):
            payload["dsl"] = schema_or_dsl
        else:
            payload["schema"] = self._serialize_schema(schema_or_dsl)

        res = await self._request("POST", "/validate/", json=payload)
        return ValidationResponse.model_validate(res)

    async def rss(self, url: str, **kwargs) -> list[MapItem]:
        """Fetch and parse an RSS/Atom feed URL; returns typed ``MapItem`` rows."""
        payload = {"url": url, **kwargs}
        raw = await self._request("POST", "/map/rss/", json=payload)
        return _parse_map_item_array_response(raw)

    async def sitemap(self, url: str, **kwargs) -> list[MapItem]:
        """Fetch and parse a sitemap URL; returns typed ``MapItem`` rows."""
        payload = {"url": url, **kwargs}
        raw = await self._request("POST", "/map/sitemap/", json=payload)
        return _parse_map_item_array_response(raw)

    async def csv(self, csv_text: str, delimiter: str = "auto") -> CsvResponse:
        """
        Convert a CSV string to a Markdown table.

        Args:
            csv_text: Raw CSV string to convert.
            delimiter: Column delimiter ('auto', ',', ';', '\t').

        Returns:
            CsvResponse with markdown table.
        """
        payload = {"csv": csv_text, "delimiter": delimiter}
        res = await self._request("POST", "/markdown/csv/", json=payload)
        return CsvResponse.model_validate(res)

    async def csv_batch(self, items: list[str]) -> CsvBatchResponse:
        """
        Convert multiple CSV strings to Markdown tables in batch.

        Args:
            items: List of CSV strings to convert (max 100).

        Returns:
            CsvBatchResponse with list of markdown tables.
        """
        payload = {"items": items}
        res = await self._request("POST", "/markdown/csv/batch/", json=payload)
        return CsvBatchResponse.model_validate(res)

    async def pdf(
        self,
        file: bytes | str | Any,
        pages: str | None = None,
    ) -> PdfResponse:
        """
        Convert a PDF file to Markdown.

        Args:
            file: PDF file content (bytes) or path to file (str).
            pages: Optional page range (e.g. '1-3').

        Returns:
            PdfResponse with markdown content.
        """
        if isinstance(file, (str, bytes)) and isinstance(file, str):
            from pathlib import Path

            with open(file, "rb") as f:
                filename = Path(file).name
                content = f.read()
        else:
            filename = "document.pdf"
            content = file

        files = {"file": (filename, content, "application/pdf")}
        data = {"pages": pages} if pages else {}
        res = await self._request("POST", "/markdown/pdf/", files=files, data=data)
        return PdfResponse.model_validate(res)

    async def excel(
        self,
        file: bytes | str | Any,
        sheet_name: str | None = None,
    ) -> ExcelResponse:
        """
        Convert an Excel file to Markdown table.

        Args:
            file: Excel file content (bytes) or path to file (str).
            sheet_name: Optional sheet name to convert.

        Returns:
            ExcelResponse with markdown table.
        """
        if isinstance(file, (str, bytes)) and isinstance(file, str):
            from pathlib import Path

            with open(file, "rb") as f:
                filename = Path(file).name
                content = f.read()
        else:
            filename = "spreadsheet.xlsx"
            content = file

        files = {
            "file": (
                filename,
                content,
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            )
        }
        data = {"sheet_name": sheet_name} if sheet_name else {}
        res = await self._request("POST", "/markdown/excel/", files=files, data=data)
        return ExcelResponse.model_validate(res)

    async def get_stored_html(self, storage_url: str) -> str:
        """
        Fetch and decompress stored HTML from a storage_url.

        Automatically handles gzip decompression if the content is compressed.

        Args:
            storage_url: The storage URL returned by fetch/pipe/markdown endpoints.

        Returns:
            Decompressed HTML string.
        """
        response = await self.client.get(storage_url)
        response.raise_for_status()
        content = response.content
        # Auto-detect gzip
        if content[:2] == b"\x1f\x8b":
            content = gzip.decompress(content)
        return content.decode("utf-8")

    async def get_job(self, job_id: str) -> dict[str, Any]:
        """Fetch a single persisted job result by its ID."""
        return await self._request("GET", f"/jobs/{job_id}/")

    async def usage(self) -> UsageSummaryResponse:
        """Fetch usage summary for the current billing period."""
        res = await self._request("GET", "/usage/summary/")
        return UsageSummaryResponse.model_validate(res)

    async def farm(
        self,
        items: list[str] | list[MapItem] | list[dict[str, Any]] | list[Any],
        concurrency: int = 5,
        namespace: str = "article",
        show_progress: bool = False,
        **kwargs,
    ) -> AsyncIterator[PipeResponse]:
        """
        Farm Phase: Concurrently pipes a list of targets.
        """
        queue: asyncio.Queue[str] = asyncio.Queue()
        total_items = 0
        for item in items:
            target_url: str | None = None
            if isinstance(item, str):
                target_url = item
            elif hasattr(item, "url"):
                target_url = getattr(item, "url")
            elif isinstance(item, dict):
                target_url = item.get("url")

            if target_url:
                await queue.put(target_url)
                total_items += 1

        if queue.empty():
            return

        results_queue: asyncio.Queue[PipeResponse | None] = asyncio.Queue()
        semaphore = asyncio.Semaphore(concurrency)
        processed_urls: set[str] = set()

        async def worker():
            while not queue.empty():
                target_url = await queue.get()
                if target_url in processed_urls:
                    queue.task_done()
                    continue

                async with semaphore:
                    try:
                        result = await self.process(
                            target_url, namespace=namespace, **kwargs
                        )
                        processed_urls.add(target_url)
                        if result:
                            await results_queue.put(result)
                    except Exception as e:
                        logger.error(f"Failed to farm {target_url}: {e}")
                    finally:
                        queue.task_done()
            await results_queue.put(None)

        num_workers = min(concurrency, total_items)
        tasks = [asyncio.create_task(worker()) for _ in range(num_workers)]

        pbar = None
        if show_progress:
            pbar = tqdm_async(total=total_items, desc=f"Farming {namespace}")

        workers_active = num_workers
        while workers_active > 0:
            res = await results_queue.get()
            if res is None:
                workers_active -= 1
            else:
                if pbar:
                    pbar.update(1)
                yield res

        if pbar:
            pbar.close()

        await asyncio.gather(*tasks)

    async def harvest(
        self,
        seed_url: str,
        filter_func: Callable[[MapItem], bool] | None = None,
        concurrency: int = 5,
        depth: int = 1,
        ignore_sitemap: bool = False,
        selectors: list[str] | None = None,
        namespace: str = "article",
        show_progress: bool = False,
        **kwargs,
    ) -> AsyncIterator[PipeResponse]:
        """
        Data Ingestion: Discovery -> Filter -> Farm.

        Builds the discovery frontier client-side when ``depth`` > 1: each additional
        level issues another ``map()`` for URLs found at the previous level (within
        the same domain normalization rules as the server). Merge with RSS/sitemap by
        calling those endpoints from your pipeline if needed.
        """

        def _item_url(entry: Any) -> str | None:
            if isinstance(entry, str):
                return entry
            if isinstance(entry, dict):
                u = entry.get("url")
                return str(u) if u else None
            u = getattr(entry, "url", None)
            return str(u) if u else None

        by_url: dict[str, Any] = {}
        seen_pages: set[str] = set()
        frontier: list[str] = [seed_url]
        remaining = max(1, depth)

        while frontier and remaining > 0:
            next_frontier: list[str] = []
            for page_url in frontier:
                if page_url in seen_pages:
                    continue
                seen_pages.add(page_url)
                response = await self.map(
                    page_url,
                    depth=1,
                    ignore_sitemap=ignore_sitemap,
                    selectors=selectors,
                )
                for item in response.urls:
                    u = _item_url(item)
                    if not u:
                        continue
                    if u not in by_url:
                        by_url[u] = item
                    if remaining > 1:
                        next_frontier.append(u)
            frontier = next_frontier
            remaining -= 1

        items = list(by_url.values())

        if filter_func:
            items = [
                item
                for item in items
                if isinstance(item, MapItem) and filter_func(item)
            ]

        async for result in self.farm(
            items,
            concurrency=concurrency,
            namespace=namespace,
            show_progress=show_progress,
            **kwargs,
        ):
            yield result

    async def run(self, *args, **kwargs):
        """Deprecated alias for harvest()"""
        async for item in self.harvest(*args, **kwargs):
            yield item


class PipeClient(BasePipeClient):
    """
    Synchronous Python client for Markdown Pipe API.
    """

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float = 30.0,
        hooks: Optional[List[PipeHook]] = None,
        max_retries: int = 3,
        **client_kwargs,
    ):
        super().__init__(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            hooks=hooks,
            max_retries=max_retries,
        )
        self.client = httpx.Client(
            base_url=self.base_url,
            headers=self.headers,
            timeout=self.timeout,
            follow_redirects=True,
            **client_kwargs,
        )

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def close(self):
        self.client.close()

    def _request(self, method: str, endpoint: str, **kwargs) -> Any:
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        self._trigger_on_request(method, url, kwargs.get("json", {}))

        try:
            for attempt in Retrying(
                stop=stop_after_attempt(self.max_retries),
                wait=wait_exponential(multiplier=1, min=2, max=10),
                retry=retry_if_exception_type(
                    (httpx.RequestError, httpx.HTTPStatusError)
                ),
                reraise=True,
            ):
                with attempt:
                    response = self.client.request(
                        method, endpoint.lstrip("/"), **kwargs
                    )
                    if response.status_code >= 500 or response.status_code == 429:
                        response.raise_for_status()

                    response.raise_for_status()
                    data = response.json()
                    if isinstance(data, dict):
                        # Inject core metadata from headers if missing in JSON body
                        if "credits" not in data and "X-Credits" in response.headers:
                            try:
                                data["credits"] = float(response.headers["X-Credits"])
                            except (ValueError, TypeError):
                                pass
                        if "checksum" not in data and "X-Checksum" in response.headers:
                            data["checksum"] = response.headers["X-Checksum"]
                        if "version" not in data and "X-Version" in response.headers:
                            data["version"] = response.headers["X-Version"]

                    self._trigger_on_response(url, data)
                    return data
            raise RuntimeError("Request failed to return data")
        except httpx.HTTPStatusError as e:
            logger.error(f"HTTP Error: {e.response.status_code} - {e.response.text}")
            self._trigger_on_error(url, e)
            raise _pipe_http_error_from_response(e.response) from e
        except Exception as e:
            logger.error(f"Request failed: {str(e)}")
            self._trigger_on_error(url, e)
            raise

    def health(self) -> dict[str, Any]:
        """Check server health."""
        return self._request("GET", "/health")

    def fetch(
        self,
        url: str,
        **kwargs,
    ) -> RawPipeResponse:
        """
        Acquisition Phase: Fetches raw HTML and stores it.

        HTML is never returned directly. Use storage_url from the response
        with get_stored_html() to retrieve the raw HTML content.
        """
        payload = {
            "url": url,
            **kwargs,
        }
        res = self._request("POST", "/fetch/", json=payload)
        return RawPipeResponse.model_validate(res)

    def engine(
        self,
        url: str,
        schema: dict[str, Any],
        html: str,
        **kwargs,
    ) -> EngineResponse:
        """
        Intelligence Phase: Direct DSL execution on raw HTML.
        """
        payload = {
            "url": url,
            "schema": self._serialize_schema(schema),
            "html": html,
            **kwargs,
        }
        res = self._request("POST", "/engine/", json=payload)
        return EngineResponse.model_validate(res)

    def pipe(
        self,
        url: str,
        schema: dict[str, Any],
        version: str | None = None,
        checksum: str | None = None,
        **kwargs,
    ) -> ExtractResponse:
        """
        Full Orchestration (The "Pipe"): fetch + engine + postprocess + validation.
        """
        payload = self._prepare_extract_payload(url, schema, **kwargs)
        headers = {}
        if version:
            headers["X-Version"] = version
        if checksum:
            headers["X-Checksum"] = checksum

        res = self._request("POST", "/pipe/", json=payload, headers=headers)
        return ExtractResponse.model_validate(res)

    def extract(
        self,
        url: str,
        schema: dict[str, Any],
        **kwargs,
    ) -> ExtractResponse:
        """
        Custom schema extraction.

        Extract specific fields from a URL using a custom Chained DSL schema.
        Unlike `pipe()`, this uses the dedicated `/extract` endpoint which has no
        namespace presets and is optimized for ad-hoc custom extraction.

        Args:
            url: The URL to scrape and extract.
            schema: The extraction schema (dict of Q builders or DSL strings).
            **kwargs: Extra parameters for the /extract endpoint.

        Returns:
            Validated ExtractResponse object.
        """
        payload = self._prepare_extract_payload(url, schema, **kwargs)
        headers = {}
        # Support checksum header for validation
        checksum = kwargs.pop("checksum", None)
        if checksum:
            headers["X-Checksum"] = checksum

        res = self._request("POST", "/extract/", json=payload, headers=headers)
        return ExtractResponse.model_validate(res)

    def map(
        self,
        url: str,
        depth: int = 1,
        ignore_sitemap: bool = False,
        selectors: list[str] | None = None,
        **kwargs,
    ) -> MapResponse:
        """Discovery Phase: anchors from one HTML response (single API acquisition)."""
        payload = self._prepare_map_payload(url, depth, ignore_sitemap, selectors)
        payload.update(kwargs)
        resp = self._request("POST", "/map/", json=payload)
        return MapResponse.model_validate(resp)

    def markdown(
        self,
        html: str,
        url: str | None = None,
        config: dict[str, Any] | None = None,
        **kwargs,
    ) -> MarkdownResponse:
        """
        Convert raw HTML to clean Markdown.

        This is a converter-only endpoint. For URL-based workflows,
        use fetch() first then pass the HTML here.

        Args:
            html: Raw HTML content to convert.
            url: Optional context URL for resolving relative links.
            config: Optional configuration (e.g. {"commonmark": True}).
            **kwargs: Extra parameters.

        Returns:
            MarkdownResponse with clean markdown and storage_url.
        """
        payload = {"html": html, **kwargs}
        if url:
            payload["url"] = url
        if config:
            payload["config"] = config
        res = self._request("POST", "/markdown/", json=payload)
        return MarkdownResponse.model_validate(res)

    def process(self, url: str, namespace: str = "article", **kwargs) -> PipeResponse:
        """Intelligence Phase: Process content using a predefined namespace."""
        payload = {"url": url, "namespace": namespace, **kwargs}
        res = self._request("POST", "/pipe/", json=payload)
        return PipeResponse.model_validate(res)

    def scrape_content(self, *args, **kwargs):
        """Deprecated alias for process()"""
        return self.process(*args, **kwargs)

    def article(self, url: str, **kwargs) -> Article:
        """Shortcut for Article piping."""
        res = self.process(url, namespace="article", **kwargs)
        return Article.model_validate(res.data)

    def product(self, url: str, **kwargs) -> Product:
        """Shortcut for Product piping."""
        raise NotImplementedError(
            "Product extraction is not yet implemented. Use engine() with custom DSL."
        )

    def serp(self, url: str, **kwargs) -> Serp:
        """Shortcut for SERP piping."""
        raise NotImplementedError(
            "SERP extraction is not yet implemented. Use engine() with custom DSL."
        )

    def validate(self, schema_or_dsl: dict[str, Any] | str) -> ValidationResponse:
        """
        Validates a Chained DSL string or a full extraction Schema.
        Returns the parsed AST, signature checksum, and estimated credits.
        """
        payload = {}
        if isinstance(schema_or_dsl, str):
            payload["dsl"] = schema_or_dsl
        else:
            payload["schema"] = self._serialize_schema(schema_or_dsl)

        res = self._request("POST", "/validate/", json=payload)
        return ValidationResponse.model_validate(res)

    def rss(self, url: str, **kwargs) -> list[MapItem]:
        """Fetch and parse an RSS/Atom feed URL; returns typed ``MapItem`` rows."""
        payload = {"url": url, **kwargs}
        raw = self._request("POST", "/map/rss/", json=payload)
        return _parse_map_item_array_response(raw)

    def sitemap(self, url: str, **kwargs) -> list[MapItem]:
        """Fetch and parse a sitemap URL; returns typed ``MapItem`` rows."""
        payload = {"url": url, **kwargs}
        raw = self._request("POST", "/map/sitemap/", json=payload)
        return _parse_map_item_array_response(raw)

    def csv(self, csv_text: str, delimiter: str = "auto") -> CsvResponse:
        """
        Convert a CSV string to a Markdown table.

        Args:
            csv_text: Raw CSV string to convert.
            delimiter: Column delimiter ('auto', ',', ';', '\t').

        Returns:
            CsvResponse with markdown table.
        """
        payload = {"csv": csv_text, "delimiter": delimiter}
        res = self._request("POST", "/markdown/csv/", json=payload)
        return CsvResponse.model_validate(res)

    def csv_batch(self, items: list[str]) -> CsvBatchResponse:
        """
        Convert multiple CSV strings to Markdown tables in batch.

        Args:
            items: List of CSV strings to convert (max 100).

        Returns:
            CsvBatchResponse with list of markdown tables.
        """
        payload = {"items": items}
        res = self._request("POST", "/markdown/csv/batch/", json=payload)
        return CsvBatchResponse.model_validate(res)

    def pdf(
        self,
        file: bytes | str | Any,
        pages: str | None = None,
    ) -> PdfResponse:
        """
        Convert a PDF file to Markdown.

        Args:
            file: PDF file content (bytes) or path to file (str).
            pages: Optional page range (e.g. '1-3').

        Returns:
            PdfResponse with markdown content.
        """
        if isinstance(file, (str, bytes)) and isinstance(file, str):
            from pathlib import Path

            with open(file, "rb") as f:
                filename = Path(file).name
                content = f.read()
        else:
            filename = "document.pdf"
            content = file

        files = {"file": (filename, content, "application/pdf")}
        data = {"pages": pages} if pages else {}
        res = self._request("POST", "/markdown/pdf/", files=files, data=data)
        return PdfResponse.model_validate(res)

    def excel(
        self,
        file: bytes | str | Any,
        sheet_name: str | None = None,
    ) -> ExcelResponse:
        """
        Convert an Excel file to Markdown table.

        Args:
            file: Excel file content (bytes) or path to file (str).
            sheet_name: Optional sheet name to convert.

        Returns:
            ExcelResponse with markdown table.
        """
        if isinstance(file, (str, bytes)) and isinstance(file, str):
            from pathlib import Path

            with open(file, "rb") as f:
                filename = Path(file).name
                content = f.read()
        else:
            filename = "spreadsheet.xlsx"
            content = file

        files = {
            "file": (
                filename,
                content,
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            )
        }
        data = {"sheet_name": sheet_name} if sheet_name else {}
        res = self._request("POST", "/markdown/excel/", files=files, data=data)
        return ExcelResponse.model_validate(res)

    def get_stored_html(self, storage_url: str) -> str:
        """
        Fetch and decompress stored HTML from a storage_url.

        Automatically handles gzip decompression if the content is compressed.

        Args:
            storage_url: The storage URL returned by fetch/pipe/markdown endpoints.

        Returns:
            Decompressed HTML string.
        """
        response = self.client.get(storage_url)
        response.raise_for_status()
        content = response.content
        # Auto-detect gzip
        if content[:2] == b"\x1f\x8b":
            content = gzip.decompress(content)
        return content.decode("utf-8")

    def get_job(self, job_id: str) -> dict[str, Any]:
        """Fetch a single persisted job result by its ID."""
        return self._request("GET", f"/jobs/{job_id}/")

    def usage(self) -> UsageSummaryResponse:
        """Fetch usage summary for the current billing period."""
        res = self._request("GET", "/usage/summary/")
        return UsageSummaryResponse.model_validate(res)

    def farm(
        self,
        items: list[str] | list[MapItem] | list[dict[str, Any]] | list[Any],
        concurrency: int = 5,
        namespace: str = "article",
        show_progress: bool = False,
        **kwargs,
    ) -> Iterator[PipeResponse]:
        """Concurrent piping of URLs."""
        urls = []
        for item in items:
            target_url: str | None = None
            if isinstance(item, str):
                target_url = item
            elif hasattr(item, "url"):
                target_url = getattr(item, "url")
            elif isinstance(item, dict):
                target_url = item.get("url")

            if target_url:
                urls.append(target_url)

        if not urls:
            return

        def _scrape_worker(u: str):
            try:
                return self.process(u, namespace=namespace, **kwargs)
            except Exception as e:
                logger.error(f"Failed to farm {u}: {e}")
                return None

        pbar = None
        if show_progress:
            pbar = tqdm(total=len(urls), desc=f"Farming {namespace}")

        with ThreadPoolExecutor(max_workers=concurrency) as executor:
            future_to_url = {executor.submit(_scrape_worker, u): u for u in urls}
            for future in as_completed(future_to_url):
                result = future.result()
                if pbar:
                    pbar.update(1)
                if result:
                    yield result

        if pbar:
            pbar.close()

    def harvest(
        self,
        seed_url: str,
        filter_func: Callable[[MapItem], bool] | None = None,
        concurrency: int = 5,
        depth: int = 1,
        ignore_sitemap: bool = False,
        selectors: list[str] | None = None,
        namespace: str = "article",
        show_progress: bool = False,
        **kwargs,
    ) -> Iterator[PipeResponse]:
        """Discovery -> Filter -> Farm; ``depth``>1 expands the frontier client-side with repeated ``map`` calls."""

        def _item_url(entry: Any) -> str | None:
            if isinstance(entry, str):
                return entry
            if isinstance(entry, dict):
                u = entry.get("url")
                return str(u) if u else None
            u = getattr(entry, "url", None)
            return str(u) if u else None

        by_url: dict[str, Any] = {}
        seen_pages: set[str] = set()
        frontier: list[str] = [seed_url]
        remaining = max(1, depth)

        while frontier and remaining > 0:
            next_frontier: list[str] = []
            for page_url in frontier:
                if page_url in seen_pages:
                    continue
                seen_pages.add(page_url)
                response = self.map(
                    page_url,
                    depth=1,
                    ignore_sitemap=ignore_sitemap,
                    selectors=selectors,
                )
                for item in response.urls:
                    u = _item_url(item)
                    if not u:
                        continue
                    if u not in by_url:
                        by_url[u] = item
                    if remaining > 1:
                        next_frontier.append(u)
            frontier = next_frontier
            remaining -= 1

        items = list(by_url.values())

        if filter_func:
            items = [
                item
                for item in items
                if isinstance(item, MapItem) and filter_func(item)
            ]

        yield from self.farm(
            items,
            concurrency=concurrency,
            namespace=namespace,
            show_progress=show_progress,
            **kwargs,
        )

    def run(self, *args, **kwargs):
        """Deprecated alias for harvest()"""
        yield from self.harvest(*args, **kwargs)


# Aliases for branding & convenience
Client = PipeClient
AsyncClient = AsyncPipeClient

# Backwards compatibility / Branding aliases
MarkdownPipe = AsyncPipeClient
SyncPipe = PipeClient
Pipe = PipeClient
AsyncPipe = AsyncPipeClient
