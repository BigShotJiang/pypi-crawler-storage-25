from __future__ import annotations

from typing import Any


class PipeError(Exception):
    """Base exception for Markdown Pipe client."""

    pass


def human_message_from_error_body(data: dict[str, Any]) -> str:
    """Turn common API JSON error envelopes into one log-friendly string.

    Supported shapes:
    - ``{ \"status\": \"error\", \"message\": \"...\" }`` (Ninja ``HttpError`` handler)
    - ``{ \"detail\": [...] }`` — list (Pydantic/Ninja validation) or string (CSV helper)
    - ``{ \"file\": \"...\" }``, ``{ \"pages\": \"...\" }`` — multipart validation
    """

    if data.get("status") == "error" and isinstance(data.get("message"), str):
        return data["message"]

    if "detail" in data:
        detail = data["detail"]
        if isinstance(detail, str):
            return detail
        if isinstance(detail, list):
            if not detail:
                return "Validation error"
            parts: list[str] = []
            for item in detail:
                parts.append(_stringify_detail_item(item))
            return "; ".join(parts)
        return str(detail)

    if isinstance(data.get("file"), str):
        return data["file"]
    if isinstance(data.get("pages"), str):
        return data["pages"]

    return str(data)


def _stringify_detail_item(item: Any) -> str:
    if isinstance(item, dict):
        msg = item.get("msg") or item.get("message") or ""
        loc = item.get("loc")
        if isinstance(loc, (list, tuple)) and loc:
            where = ".".join(str(x) for x in loc if x not in ("body", "query", "__root__"))
            return f"{where}: {msg}".strip(": ") if where else msg or str(item)
        return str(msg or item)
    return str(item)


def parse_pipe_api_error(payload: Any) -> tuple[str, dict[str, Any] | None]:
    """Return ``(human_message, body_dict_or_none)`` for a parsed JSON body.

    If ``payload`` is not a dict, message is ``str(payload)`` and body is None.
    """

    if not isinstance(payload, dict):
        return (str(payload), None)
    return (human_message_from_error_body(payload), payload)


class PipeHTTPError(PipeError):
    """Raised when the API returns a non-success HTTP status.

    Attributes:
        status_code: HTTP status code.
        message: Short human-readable summary (derived from JSON when possible).
        body: Parsed JSON dict when response was JSON, else ``None``.
        raw_text: Original response body string (truncate in logs if huge).
    """

    def __init__(
        self,
        status_code: int,
        message: str,
        *,
        body: dict[str, Any] | None = None,
        raw_text: str = "",
    ):
        self.status_code = status_code
        self.message = message
        self.body = body
        self.raw_text = raw_text
        super().__init__(f"HTTP {status_code}: {message}")
