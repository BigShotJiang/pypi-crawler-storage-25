from __future__ import annotations

import logging
import os
from typing import Any, Callable, Dict, List, Optional

from pydantic import BaseModel

logger = logging.getLogger(__name__)


class PipeStats(BaseModel):
    """
    Tracks aggregate usage statistics for the client session.

    Attributes:
        total_requests: Number of API calls made.
        total_credits: Aggregate credits consumed.
        total_latency_ms: Combined network and processing time.
        failed_requests: Number of requests that resulted in an error.
    """

    total_requests: int = 0
    total_credits: int = 0
    total_latency_ms: float = 0.0
    failed_requests: int = 0

    def add(self, latency: float = 0, units: int = 0, success: bool = True):
        self.total_requests += 1
        self.total_latency_ms += latency
        self.total_credits += units
        if not success:
            self.failed_requests += 1


class PipeHook:
    """
    Hooks for intercepting and syncing data.

    This class allows you to inject custom logic into the request/response lifecycle.
    Commonly used for logging, custom monitoring, or syncing data to a database.

    Example:
        ```python
        def my_logger(url, data):
            print(f"Scraped {url}")

        hook = PipeHook(on_response=my_logger)
        client = AsyncPipeClient(hooks=[hook])
        ```
    """

    def __init__(
        self,
        on_request: Optional[Callable[[str, str, Dict[str, Any]], None]] = None,
        on_response: Optional[Callable[[str, Dict[str, Any]], None]] = None,
        on_error: Optional[Callable[[str, Exception], None]] = None,
    ):
        """
        Initialize the hook with callback functions.

        Args:
            on_request: Called before sending a request. (method, url, payload)
            on_response: Called after receiving a successful response. (url, data)
            on_error: Called when a request fails. (url, exception)
        """
        self.on_request = on_request
        self.on_response = on_response
        self.on_error = on_error


class BasePipeClient:
    """
    Base shared configuration and logic for Markdown Pipe clients.

    When ``base_url`` is omitted, the client uses ``MARKDOWN_PIPE_BASE_URL`` if set,
    otherwise :data:`DEFAULT_BASE_URL` (production). Same variable name as MCP / local
    ``.env`` for dev.

    When ``api_key`` is omitted, ``MARKDOWN_PIPE_API_KEY`` is used if set.
    """

    _ENV_BASE_URL = "MARKDOWN_PIPE_BASE_URL"
    _ENV_API_KEY = "MARKDOWN_PIPE_API_KEY"
    DEFAULT_BASE_URL = "https://api.markdownpipe.com/v1"

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float = 30.0,
        hooks: Optional[List[PipeHook]] = None,
        max_retries: int = 3,
    ):
        resolved = (
            base_url or os.environ.get(self._ENV_BASE_URL) or self.DEFAULT_BASE_URL
        )
        self.base_url = resolved.rstrip("/")
        self.api_key = api_key or os.environ.get(self._ENV_API_KEY)
        self.timeout = timeout
        self.headers = {
            "Content-Type": "application/json",
            "User-Agent": "markdownpipe-python/1.0.0",
        }
        self.stats = PipeStats()
        self.hooks = hooks or []
        self.max_retries = max_retries

        if self.api_key:
            auth_header = (
                self.api_key
                if self.api_key.startswith("Bearer ")
                else f"Bearer {self.api_key}"
            )
            self.headers["Authorization"] = auth_header

    def add_hook(self, hook: PipeHook):
        """Add a new hook to the client."""
        self.hooks.append(hook)

    def _trigger_on_request(self, method: str, url: str, payload: Dict[str, Any]):
        for h in self.hooks:
            if h.on_request:
                try:
                    h.on_request(method, url, payload)
                except Exception as e:
                    logger.warning(f"Hook on_request failed: {e}")

    def _trigger_on_response(self, url: str, response_data: Any):
        # Update internal stats (dict envelopes carry ``usage``; bare JSON arrays do not).
        usage: Dict[str, Any]
        if isinstance(response_data, dict):
            usage = response_data.get("usage", {}) or {}
        else:
            usage = {}

        if not isinstance(usage, dict):
            usage = {}

        self.stats.add(
            latency=usage.get("latency", 0),
            units=usage.get("credits", 0),
            success=True,
        )

        for h in self.hooks:
            if h.on_response:
                try:
                    h.on_response(url, response_data)
                except Exception as e:
                    logger.warning(f"Hook on_response failed: {e}")

    def _trigger_on_error(self, url: str, error: Exception):
        self.stats.add(success=False)
        for h in self.hooks:
            if h.on_error:
                try:
                    h.on_error(url, error)
                except Exception as e:
                    logger.warning(f"Hook on_error failed: {e}")

    def _serialize_schema(self, schema: dict[str, Any]) -> dict[str, Any]:
        """Deeply serialize Q and QueryAST objects into DSL strings."""
        try:
            from .dsl import Q, QueryAST
        except ImportError:
            # Fallback for environments where dsl might not be available or during init
            return schema

        def _serialize_recursive(obj: Any) -> Any:
            if isinstance(obj, (Q, QueryAST)):
                return str(obj)
            if isinstance(obj, dict):
                return {k: _serialize_recursive(v) for k, v in obj.items()}
            if isinstance(obj, list):
                return [_serialize_recursive(i) for i in obj]
            return obj

        return _serialize_recursive(schema)

    def _prepare_extract_payload(
        self, url: str, schema: dict[str, Any], **kwargs
    ) -> dict[str, Any]:
        """Prepare payload for /pipe endpoint. Supports Q objects in schema."""
        return {"url": url, "schema": self._serialize_schema(schema), **kwargs}

    def _prepare_map_payload(
        self,
        url: str,
        depth: int = 1,
        ignore_sitemap: bool = False,
        selectors: list[str] | None = None,
    ) -> dict[str, Any]:
        """Prepare payload for /map endpoint."""
        return {
            "url": url,
            "depth": depth,
            "ignore_sitemap": ignore_sitemap,
            "selectors": selectors,
        }
