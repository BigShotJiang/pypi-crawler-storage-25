from __future__ import annotations

from enum import Enum


class PipeMode(str, Enum):
    AUTO = "auto"
    MAP = "map"
    RSS = "rss"
    SITEMAP = "sitemap"
    URL = "url"


class JobStatus(str, Enum):
    PENDING = "pending"
    PROGRESS = "progress"
    SUCCESS = "success"
    FAILURE = "failure"


class PipeOutputFormat(str, Enum):
    HTML = "html"
    MARKDOWN = "markdown"
    TEXT = "text"


class PipeNamespace(str, Enum):
    ARTICLE = "article"
    PRODUCT = "product"
    SERP = "serp"
    RAW = "raw"


class ResponseStatus(str, Enum):
    SUCCESS = "success"
    ERROR = "error"
    PARTIAL = "partial"
