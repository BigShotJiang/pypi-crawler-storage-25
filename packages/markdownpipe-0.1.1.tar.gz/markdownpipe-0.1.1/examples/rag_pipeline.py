"""
RAG Ingestion Pipeline Example.

This script demonstrates how to build a robust data ingestion pipeline for Retrieval Augmented Generation (RAG).
It focuses on:
1. Discovering URLs from a documentation site.
2. Extracting clean, structured Markdown content (skipping navigation, footers, etc.).
3. Preparing the data for an embedding model.
"""

from __future__ import annotations

import asyncio

from markdownpipe import AsyncPipeClient, Q

# Configuration
API_KEY = "sk-xxxxxxxx"  # Replace with your key
TARGET_SITE = "https://docs.python.org/3/library/json.html"


async def main():
    # 1. Initialize the Smart Client
    async with AsyncPipeClient(api_key=API_KEY) as client:
        print("🤖 Connected to Markdown Engine.")

        # 2. Define a RAG-optimized schema
        # We want strict content. No noise.
        rag_schema = {
            "title": Q("h1").text(),
            # :semantic('auto') finds the main content block
            # !cleanup removes visual noise that confuses embeddings (ads, buttons)
            "content": Q("body")
            .filter(":semantic('auto')")
            .cleanup(".navigation", ".footer", ".ad-container", "script")
            .text(),
            "metadata": {
                "source": Q("meta[property='og:url']").attr("content"),
                "last_updated": Q(".last-updated").text(),
            },
        }

        print(f"🚀 Extracting clean data from: {TARGET_SITE}...")

        # 3. Execute Extraction
        result = await client.extract(TARGET_SITE, schema=rag_schema)

        if result:
            print("\n✅ Extraction Successful!")
            print("-" * 40)
            print(f"Title: {result['title']}")
            print(f"Metadata: {result['metadata']}")
            print("-" * 40)
            print("Preview of clean content for LLM:")
            print(result["content"][:500] + "...\n")

            # 4. (Hypothetical) Embedding step
            # chunks = split_text(result['content'])
            # embeddings = openai.encode(chunks)
            # victor_db.upsert(embeddings)
            print("💾 Ready for Vector DB upsert.")
        else:
            print("❌ Extraction failed or returned empty.")


if __name__ == "__main__":
    asyncio.run(main())
