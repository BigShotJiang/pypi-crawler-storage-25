"""
Example: Progress Bar Integration.
The SDK supports 'tqdm' out of the box for long-running farming tasks.
Simply pass 'show_progress=True' to client.farm() or client.map().
"""

from __future__ import annotations

import asyncio

from markdownpipe import MarkdownPipe


async def main():
    async with MarkdownPipe(api_key="your-api-key") as client:
        print("Starting a large-scale discovery and farm task...")

        # This will show a professional progress bar in the terminal
        # detailing the status of the 'Farm' phase.
        async for result in client.map(
            "https://news.example.com",
            depth=1,
            concurrency=5,
            show_progress=True,  # Native progress bar support
        ):
            # Process results as they arrive
            _ = result.get("data", {}).get("metadata", {}).get("title", "Untitled")
            # print(f"Finished: {_[:50]}...")

        print("\nAll tasks completed!")
        print(f"Grand Total Time:    {client.stats.total_time:.2f}s")
        print(f"Grand Total Credits: {client.stats.total_credits}")


if __name__ == "__main__":
    asyncio.run(main())
