"""
Example: Tracking Usage and Query Units.
The SDK automatically tracks API consumption (latency and query units)
across the entire session.
"""

from __future__ import annotations

import asyncio

from markdownpipe import MarkdownPipe


async def main():
    async with MarkdownPipe(api_key="your-api-key") as client:
        print("Gathering data from multiple sources...")

        # Perform multiple operations
        await client.article("https://news.example.com")
        await client.article("https://example.com")

        # Discover links (minimal query units)
        await client.discover("https://example.com")

        # 3. Check aggregate stats
        print("\n" + "=" * 30)
        print("SESSION STATISTICS")
        print("=" * 30)
        print(f"Total Requests:      {client.stats.total_requests}")
        print(f"Total Credits:       {client.stats.total_credits}")
        print(f"Total Latency:       {client.stats.total_latency_ms:.2f}ms")
        print(
            f"Avg Latency/Req:     {client.stats.total_latency_ms / client.stats.total_requests:.2f}ms"
        )
        print(f"Failed Requests:     {client.stats.failed_requests}")
        print("=" * 30)


if __name__ == "__main__":
    asyncio.run(main())
