import asyncio
from markdownpipe import AsyncPipeClient


async def main():
    async with AsyncPipeClient() as client:
        url = "https://example.com"

        # 1. Fetch raw HTML
        print(f"Fetching raw HTML from {url}...")
        fetch_res = await client.fetch(url)
        print(f"Job ID: {fetch_res.job_id}")

        if fetch_res.storage_url:
            print(f"Stored at: {fetch_res.storage_url}")

            # 2. Retrieve HTML from storage
            html_content = await client.get_stored_html(fetch_res.storage_url)
            print(f"Retrieved {len(html_content)} bytes of HTML compress/decompressed.")

            # 3. Convert HTML to clean Markdown
            print("Converting HTML to Markdown...")
            md_res = await client.markdown(html_content, url=url)

            print("\n--- Converted Markdown Preview ---")
            print(md_res.data.markdown[:500] + "...")
            print("----------------------------------")
            print(
                f"Used {md_res.usage.credits} credits. Latency: {md_res.usage.latency}ms."
            )


if __name__ == "__main__":
    asyncio.run(main())
