"""
Example: Syncing data to a custom backend using Hooks.
This demonstrates how to use `PipeHook` to automatically send every successful
scrape result to your own internal database or API.
"""

from __future__ import annotations

import asyncio

from markdownpipe import MarkdownPipe, PipeHook


# 1. Define your sync logic
def my_backend_syncer(url, data):
    print(f"--- [HOOK] Syncing result for {url} to MyBackend ---")
    # In a real app, you would make an HTTP request to your backend here
    # e.g., requests.post("https://api.mycompany.com/ingest", json=data)
    print(f"Ingested {len(str(data))} bytes of data.")


# 2. Initialize the client with the hook
async def main():
    hook = PipeHook(on_response=my_backend_syncer)

    async with MarkdownPipe(api_key="your-api-key", hooks=[hook]) as client:
        print("Starting scrape...")

        # This will automatically trigger my_backend_syncer(...) when finished
        result = await client.article("https://example.com/some-news-article")

        print("\nFinal Result Title:", result.metadata.title)


if __name__ == "__main__":
    asyncio.run(main())
