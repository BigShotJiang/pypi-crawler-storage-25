"""
Example: Resilient Crawling with Automatic Retries.
The SDK uses 'tenacity' under the hood to handle temporary network blips,
502/504 errors, and 429 Rate Limits.
"""

from __future__ import annotations

import asyncio

from markdownpipe import MarkdownPipe


async def main():
    # Configure retries (default is 3)
    async with MarkdownPipe(
        api_key="your-api-key",
        max_retries=5,  # Be more aggressive for unstable sites
    ) as client:
        print("Scraping with auto-retry enabled...")

        try:
            # If the server returns a 429 or 503, the SDK will
            # exponentially backoff and try again.
            _ = await client.article("https://example.com/unstable-page")
            print("Successfully scraped after retries!")
        except Exception as e:
            print(f"Failed after all retry attempts: {e}")


if __name__ == "__main__":
    asyncio.run(main())
