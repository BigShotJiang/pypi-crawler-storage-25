# Framework Integrations

Markdown Pipe outputs **clean, structured Markdown** that works seamlessly with downstream systems. This guide shows integration with popular tools and frameworks.

---

## OpenAI / Compatible APIs

The simplest way to use the pipe is to feed the markdown output directly into a system prompt or user context.

```python
import os
from openai import AsyncOpenAI
from markdownpipe import AsyncPipeClient

# 1. Initialize Clients
ai_client = AsyncOpenAI(api_key=os.getenv("OPENAI_KEY"))
client = AsyncPipeClient(
  api_key=os.getenv("MARKDOWN_PIPE_KEY")
)

async def summarize_news(url: str):
  # 2. Extract clean markdown via Extraction Pipe
  # We use !cleanup to remove noise so we don't pay for useless tokens
  query = "article !cleanup(.ads, .nav)"

  results = await client.pipe(url, {"content": query})
  markdown_text = results.data["content"]

  # 3. Process with LLM or other tools
  response = await ai_client.chat.completions.create(
      model="gpt-4-turbo",
      messages=[
          {"role": "system", "content": "You are a helpful assistant. Summarize the following article."},
          {"role": "user", "content": markdown_text}
      ]
  )

  return response.choices[0].message.content
```

---

## LangChain Integration

You can easily wrap Markdown Pipe as a custom `DocumentLoader` in LangChain.

```python
from typing import List
from langchain_core.documents import Document
from langchain_community.document_loaders.base import BaseLoader
from markdownpipe import PipeClient

class MarkdownPipeLoader(BaseLoader):
  def __init__(self, urls: List[str], api_key: str):
      self.urls = urls
      self.client = PipeClient(api_key=api_key)

  def lazy_load(self):
      # Universal query for main content
      query = "body :semantic('auto') !cleanup(nav, footer)"

      for url in self.urls:
          try:
              data = self.client.pipe(url, {"text": query})
              content = data.data.get("text")

              yield Document(
                  page_content=content,
                  metadata={"source": url}
              )
          except Exception as e:
              print(f"Error piping {url}: {e}")

# Usage
loader = MarkdownPipeLoader(["https://example.com/post/1"], api_key="...")
docs = loader.load()

print(f"Loaded {len(docs)} documents for RAG.")
```

---

## LlamaIndex Integration

Use it as a data connector for your RAG pipelines.

```python
from llama_index.core import Document
from llama_index.core.readers.base import BaseReader
from markdownpipe import PipeClient

class MarkdownPipeReader(BaseReader):
  def __init__(self, api_key: str):
      self.client = PipeClient(api_key=api_key)

  def load_data(self, urls: list[str]):
      documents = []
      # Smart selector
      query = "main"

      for url in urls:
          data = self.client.pipe(url, {"text": query})
          text = data.data.get("text")

          if text:
              documents.append(Document(text=text, extra_info={"url": url}))

      return documents

# Usage
reader = MarkdownPipeReader(api_key="...")
documents = reader.load_data(urls=["https://news.example.com"])
index = VectorStoreIndex.from_documents(documents)
```

---

## Optimizing Data Efficiency

Use the Pipe's DSL to reduce noise and deliver only relevant content **before** processing downstream.

| Technique               | standard HTML              | Markdown Pipe         | Savings     |
| :---------------------- | :------------------------- | :-------------------- | :---------- |
| **Raw HTML**            | `<div class="x">...</div>` | `content`             | ~40% tokens |
| **Noise Removal**       | Ads, Nav, Footer included  | `!cleanup(.ads, nav)` | ~60% tokens |
| **Surgical Extraction** | Full Page                  | `article::text`       | ~90% tokens |

### The "Token-Saver" Query

Use this generic query to get the highest information density with the lowest token count:

```css
body: semantic("auto") !cleanup(script, style, .ads, footer, nav);
```

---

## High-Scale Extraction Pipeline (The Map-Farm Pattern)

For enterprise-scale extraction, don't pipe sequentially. Use the `map` and `farm` methods to build a high-throughput extraction pipeline.

```python
import asyncio
from markdownpipe import AsyncPipeClient, Q

async def ingest_site_to_vector_db(domain: str):
  async with AsyncPipeClient(api_key="...") as client:
      # 1. Map: Find all relevant content pages
      print(f"Mapping {domain}...")
      urls = await client.map(domain, depth=2)

      # 2. Verify: Pre-validate our high-fidelity schema
      schema = {
          "title": Q("h1").text(),
          "content": Q("article").cleanup(".sidebar", ".ads").html()
      }
      validation = await client.validate(schema)

      # 3. Farm: Parallel extraction with optimized Checksums
      print(f"Harvesting {len(urls.urls)} pages...")
      async for result in client.farm(
          urls.urls,
          concurrency=25,
          schema=schema,
          checksum=validation.checksum
      ):
          if result.status == JobStatus.SUCCESS:
              await vector_db.upsert(
                  id=result.url,
                  text=result.data["content"],
                  metadata=result.data["title"]
              )
```

---

## Key Benefits of Flow-based Extraction

1. **Concurrency**: Scale to huge domains without hitting local bottlenecks.
2. **Deterministic Output**: Systems receive perfectly structured, validated Markdown.
3. **Optimized Cost**: Using validated checksums ensures the server uses pre-parsed execution plans, minimizing latency and credit costs.
