# Troubleshooting & FAQ

Extracting data from the wild web is messy. Here is how to handle common issues when using Markdown Pipe.

---

## Debugging Selectors

### Why is my result empty? `[]`

If your query returns an empty list, follow this 3-step debug process:

1.  **Check Broad Scope**:
    Change your query to something very broad to verify the engine sees the page.

```css
/* Debug Query */
body ::count
```

_If this returns 0, the page might require JavaScript rendering or is blocking the bot._

2.  **Verify the Selector**:
    Remove all filters and actions. Just check the base selector.

```css
/* Instead of */
div.content:has(.title) ::text

/* Try */
div.content ::count
```

3.  **Check Dynamic Classes**:
    Modern sites (React/Next.js) often have dynamic classes like `.css-1x2y3z`.
    _Solution_: Use `@regex:` or relaxed matching.

```css
/* Instead of */
.css-1x2y3z

/* Try */
div[class*="css-"]
```

---

## Common Errors

### `403 Forbidden` / `401 Unauthorized`

- **Cause**: Invalid API Key.
- **Fix**: Check your headers or `api_key` parameter.

### `422 Unprocessable Entity`

- **Cause**: Your DSL Syntax is invalid.
- **Fix**: Use `client.validate()` to check your queries before execution.
- _Common mistake_: Forgetting quotes in filters like `:contains(hello)` → `:contains('hello')`.

### `504 Gateway Timeout`

- **Cause**: The value you are trying to extract is too large or the target site is slow.
- **Fix**:
- Narrow your selector (e.g., `body` → `article`).
- Use `!cleanup` to remove heavy nodes (like base64 images) early.

---

## Performance FAQ

### How do I make it faster?

1.  **Validate Schemas**: Always use the **Handshake Protocol**. Pre-validating your schema allows the server to cache the parsing logic (O(1) lookup).
2.  **Avoid `:near`**: This filter is computationally expensive (O(N²)). Use `:next` or `:has` instead.
3.  **Reduce Depth**: `html body div.main` is slower than just `.main`.

### Does this support JavaScript/SPA?

Yes, but it depends on the gateway configuration.

- **Default**: HTTP-only (Fast, Low cost). Good for 80% of sites.
- **JS-Rendering**: Required for sites that load content dynamically via API (e.g., Twitter, Infinite Scroll pages). _Note: This usually costs more credits._

### Why markdown?

Markdown is a universal interchange format for structured content.

- HTML = High Token Usage, Noisy.
- Text = Loss of structure (Headings, Links, Lists).
- **Markdown** = Structure + Low Tokens.

---

## Getting Help

If you are stuck on a difficult site structure:

1.  Use the browser's "Inspect Element".
2.  Copy the outer HTML of the component you want.
3.  Ask ChatGPT: _"Convert this HTML extraction to a Markdown Pipe DSL query"_ (Yes, it knows our syntax!).
