# 🍳 Markdown Pipe Cookbook

A collection of **battle-tested extraction recipes**
for producing high signal-to-noise structured data.

These patterns focus on **determinism, stability, and data quality** —
not brittle selectors or layout-dependent extraction.

---

## 🧱 Clean Content for Indexing & Retrieval

### 1. Clean Article Extraction

**Problem**
Raw HTML pollutes search indexes and embeddings with navigation, ads, and sidebars.

**Solution**
Use semantic targeting with cleanup rules to produce clean Markdown.

```python
results = await client.extract(url, {
    "title": "h1 ::text",
    "content": (
        "article :semantic('auto') "
        "!cleanup(.ads, .related, form, nav) "
        "::text"
    ),
    "metadata": {
        "author": ".author ::text",
        "date": "time ::attr(datetime)",
    },
})
```

**Result**
Deterministic Markdown suitable for indexing, chunking, or analytics.

---

## 📊 Structured Tables & Financial Data

### 2. Table-to-Markdown (Analyst Friendly)

**Problem**
HTML tables are verbose and inconsistent.

**Solution**
Convert targeted tables directly into compact Markdown.

```python
schema = {
    "financials": (
        "h2:icontains('Financial Results') "
        ":next(table) "
        "::table"
    )
}
```

**Output:**

```
| Metric   | Q4 2024 | YoY |
|---------|---------|-----|
| Revenue | $50M    | +10% |
```

---

## 🛒 E-Commerce & Retail Monitoring

### 3. Layout-Resilient Price Extraction

**Problem**
A/B tests break strict selectors.

**Solution**
Use fallback groups to maintain resilience.

```python
schema = {
    "product": "h1 ::text",
    "price": (
        "(.price-box | .offer-price | meta[itemprop='price']) "
        "::text ::strip"
    ),
    "availability": "(.stock | .inventory) ::text",
}
```

### 4. Review & Sentiment Mining

```python
schema = {
    "reviews": {
        "_root": ".review-card:not(.bot):has(.stars)",
        "user": ".user-name ::text",
        "rating": ".stars ::attr(data-val)",
        "text": ".review-body ::text",
        "verified": ".verified ::text",
    }
}
```

Filters noise while preserving structured output.

---

## 📰 News & Intelligence Pipelines

### 5. Keyword-Gated Extraction

Extract content only when it matters.

```python
async for item in client.map("https://news.example.com"):
    if "business" in item.url:
        data = await client.extract(item.url, {
            "snippet": (
                "body:icontains('acquisition') "
                ":semantic('auto') "
                "::slice(0, 500) "
                "::text"
            )
        })
        if data["snippet"]:
            trigger_alert(data)
```

---

## 🛡️ Compliance & Safety

### 6. PII Redaction (GDPR-Friendly)

Redact sensitive data before it leaves the engine.

```python
schema = {
    "content": (
        "body "
        "!redact(email) "
        "!redact(phone) "
        "::text"
    )
}
```

**Output:**

```
Contact us at [redacted]
```

---

## 🧠 Design Philosophy

- **No browser emulation**
- **No JavaScript execution**
- **No heuristic "guessing"**

Extraction is:

- **Declarative** — Your schema is explicit
- **Repeatable** — Same input = same output
- **Auditable** — Every step is visible

Your schema is the contract.
