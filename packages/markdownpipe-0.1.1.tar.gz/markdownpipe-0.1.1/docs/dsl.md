# Extraction DSL & Q Builder

The **Chained DSL** is the engine that powers Markdown Pipe's surgical extraction. It is designed to be deterministic, extremely fast, and highly expressive, allowing for complex tree transformations and filtering to be executed at the edge.

## The Pipeline Lifecycle

Every query in the DSL follows a 3-stage lifecycle:

1.  **Mutation (`!`)**: Modify the DOM (e.g., remove noise).
2.  **Filter (`:`)**: Narrow down the selection based on logic or content.
3.  **Action (`::`)**: Transform the final nodes into the desired format (Markdown, Text, HTML).

---

## Fluent Query Builder & Typed AST

The `Q` builder is the recommended way to construct these queries. It leverages a **typed AST (Abstract Syntax Tree)** backed by Pydantic to provide:

- **Full IntelliSense**: Your IDE will provide autocomplete for all possible filters (`:has`, `:near`) and actions (`::text`).
- **Client-Side Validation**: Mistakes are caught locally before sending a request to the API.
- **Type Safety**: Automatic casting of arguments (e.g., numbers for sibling hops) and strict schema enforcement.
- **Serialization Parity**: Seamlessly convert between `Q` objects, JSON-serializable dictionaries, and DSL strings.

```python
from markdownpipe import Q

# Build a sophisticated extraction pipeline with full IDE support
query = (
    (Q(".article-body") | ".post-content")  # Fallback Group
    .has("p")                               # Logic Filter: Only if it has paragraphs
    .cleanup(".ads", ".social-share")       # Surgical Cleanup
    .redact("email")                        # Integrated Protection
    .html()                                 # Extract cleaned HTML
)

# Insert into your schema - it's automatically serialized to a DSL string
schema = {"body": query}
```

### Advanced Filters

Filters allow you to find specific nodes based on their structure or text.

```python
Q(".card").has(".price")             # Only cards with prices
Q("a").icontains("Login")            # Case-insensitive text search
Q(".content").descendant("p")        # Move scope to child paragraphs
Q("span").parent().closest(".item")  # Walk up the tree
Q(".article").semantic("main topic") # Semantic clustering (AI-powered)
Q(".headline").near("breaking")      # Pivot near specific text context
```

### Powerful Actions

Actions transform your selected nodes into structured data.

```python
Q("table").table()             # Extract table as structured JSON
Q("script").json()            # Parse LD+JSON blocks automatically
Q("p").slice(0, 5)            # Capture only the first 5 paragraphs
Q(".tags").all().join(", ")   # Combine multiple nodes into one string
Q(".body").redact("phone")    # Mask sensitive phone numbers
```

---

## Performance Optimization: Credits

Markdown Pipe uses **credits** to measure extraction complexity.

### How to optimize for lower credit costs:

1. **Be Specific**: Use ID selectors instead of deep nesting (`#content` vs `div > div > div`).
2. **Reuse Checksums**: Validations return a Checksum. Use this in headers to skip server-side parsing.
3. **Flat Cleanups**: Combine cleanup selectors into one call where possible to reduce mutation cycles.
4. **Prefer CSS over Regex**: Native CSS engines are faster and cheaper in credits than Regex filters.
