# Advanced DSL Patterns

This guide provides concrete, real-world examples of high-level extraction strategies. Each pattern includes a raw HTML sample and the corresponding DSL query to demonstrate exactly how the engine processes complex structures.

---

## 1. The Container Slasher Pattern

**Scenario**: You want to remove an entire container (like a product card or ad box) based on a small internal indicator (e.g., a "Sponsored" label), while keeping the rest of the list.

**HTML:**

```html
<div class="product-list">
  <!-- Item 1: Real Product -->
  <div class="card">
    <h2 class="title">Gaming Mouse</h2>
    <span class="price">$50</span>
  </div>

  <!-- Item 2: Sponsored Ad -->
  <div class="card">
    <h2 class="title">Cheap Loans</h2>
    <span class="bad-label">Promoted</span>
  </div>
</div>
```

**DSL Query:**

```css
div.card:not(:has(.bad-label)) ::attr(class)
```

_Or to explicitly remove the bad ones:_

```css
.product-list !cleanup(div.card:has(.bad-label)) ::html
```

**Result:**

```html
<div class="card">
  <h2 class="title">Gaming Mouse</h2>
  <span class="price">$50</span>
</div>
```

---

## 2. Dynamic Fallback Groups

**Scenario**: A news site uses different layouts for "Standard" articles vs "Featured" stories. You need a single reliable query that works for both.

**HTML (Layout A - Standard):**

```html
<article class="standard-post">
  <p>Standard content...</p>
</article>
```

**HTML (Layout B - Featured):**

```html
<div id="featured-hero">
  <div class="hero-body">
    <p>Featured content...</p>
  </div>
</div>
```

**DSL Query:**

```css
(article.standard-post|#featured-hero.hero-body|.generic-content)::text;
```

**Result:**

```text
"Standard content..."
OR
"Featured content..."
```

The engine tries each selector left-to-right until one finds a match.

---

## 3. The Sibling Hop (Label-Value Pairs)

**Scenario**: Specifications are often laid out as flat siblings (dt/dd or div/div) rather than parent/child relationships.

**HTML:**

```html
<div class="specs">
  <span class="label">Brand:</span>
  <span class="value">ACME</span>

  <span class="label">Weight:</span>
  <span class="value">5kg</span>
</div>
```

**DSL Query:**

```css
span:icontains('Weight'):next ::text
```

**Result:**

```text
5kg
```

1. Find span with 'Weight'.
2. Hop to next element.
3. Extract text.

---

## 4. Content Density + Surgical Cleanup

**Scenario**: You need to extract the main article from a messy page full of popups, sidebars, and "read more" widgets. Class names are obfuscated.

**HTML:**

```html
<body>
  <nav>...</nav>
  <div class="x92-container">
    <div class="share-bar">...</div>
    <h1>Global News</h1>
    <p>The economy is growing...</p>
    <div class="read-more-widget">Read also: Local news...</div>
    <p>More analysis here...</p>
  </div>
  <footer>...</footer>
</body>
```

**DSL Query:**

```css
body: semantic("auto") !cleanup(.share-bar, .read-more-widget);
```

**Result:**

```markdown
# Global News

The economy is growing...

More analysis here...
```

`:semantic('auto')` correctly identified `.x92-container` as the main body, and `!cleanup` removed the noise inside it.

---

## 5. Regex-Based Node Discovery

**Scenario**: Extracting data from a React/Next.js app where class names are randomly generated hashes.

**HTML:**

```html
<div class="comment_Thread__a1b2c">
  <div class="comment_Body__x9y8z">First comment</div>
  <div class="comment_Body__f5g6h">Second comment</div>
</div>
```

**DSL Query:**

```css
@regex:div:class:^comment_body.* ::text::all;
```

**Result:**

```json
["First comment", "Second comment"]
```

Matches any div whose class starts with `comment_Body`.

---

## 6. Multi-Action Formatting Chains

**Scenario**: You extract a messy price string and need it as a clean float-compatible format.

**HTML:**

```html
<div class="price-tag">Price: $ 1,299.00 USD</div>
```

**DSL Query:**

```python
# Using the Q builder
Q(".price-tag").text().replace("Price:", "").strip(" $USD").replace(",", "")
```

**Raw Chained DSL:**

```css
.price-tag ::text ::replace('Price:', '') ::strip(' $USD') ::replace(',', '')
```

**Result:**

```text
1299.00
```

1. Literal `replace` to remove the exact prefix "Price:".
2. `strip` off all dollar signs, spaces, and the letters U, S, D from the edges.
3. Literal `replace` to remove comma separators.

---

## 6b. Advanced Regex Text Scrubbing

**Scenario**: You have a chaotic string containing arbitrary numbers mixed with text, and you want to extract just the words, converting the string into uppercase, but ignoring case during the match.

**HTML:**

```html
<div class="messy-data">StockLevel: IN-STOCK (124 items) / ref: X99a</div>
```

**DSL Query:**

```python
# Using the Q builder
Q(".messy-data").text().replace_regex(r"\(\d+ items\)", "").replace_regex("stocklevel:", "", "i").strip()
```

**Raw Chained DSL:**

```css
.messy-data ::text ::replace_regex('\(\d+ items\)', '') ::replace_regex('stocklevel:', '', 'i') ::strip
```

**Result:**

```text
IN-STOCK / ref: X99a
```

1. `replace_regex` removes the variable quantity string `(124 items)`.
2. `replace_regex` with the `i` flag performs a case-insensitive removal of "stocklevel:".
3. `strip` cleans up the dangling whitespace.

---

## 7. Complex Table Extraction

**Scenario**: A table follows a specific heading, and you want it as structured JSON data (requires `::table` which parses to Markdown/JSON-friendly string).

**HTML:**

```html
<h2>Technical Specs</h2>
<p>Some intro text...</p>
<table>
  <tr>
    <td>CPU</td>
    <td>3.5Ghz</td>
  </tr>
  <tr>
    <td>RAM</td>
    <td>16GB</td>
  </tr>
</table>
```

**DSL Query:**

```css
h2:icontains('Technical Specs') ~ table ::table
```

Note: `~` is the standard CSS general sibling combinator. For immediate sibling, you could use `:next` if they are adjacent.

**DSL Query (using :next logic if strict):**

```css
h2:icontains('Technical Specs'):next:next ::table
```

Jump h2 -> p -> table

**Result:**

```markdown
| CPU | 3.5Ghz |
| RAM | 16GB |
```

---

## 8. Deep Chaining Strategies

**Scenario**: You need to find a specific container that matches multiple complex criteria: it must have a heading, not contain any "archived" notice, must list an author, and you want the entire parent section.

**HTML:**

```html
<section class="post-item">
  <div class="content">
    <h2>Active Post</h2>
    <span class="author">By Jane</span>
  </div>
</section>

<section class="post-item">
  <div class="content">
    <h2>Old Post</h2>
    <div class="archived">This post is archived</div>
    <span class="author">By Bob</span>
  </div>
</section>
```

**DSL Query:**

```css
div.content:has(h2):not(:has(.archived)):has(.author):closest(section) ::html
```

**Result:**

```html
<section class="post-item">
  <div class="content">
    <h2>Active Post</h2>
    <span class="author">By Jane</span>
  </div>
</section>
```

Filters logic:

1. Has H2? Yes.
2. Has .archived? No.
3. Has .author? Yes.
4. Then climb up to `<section>`.

---

## 9. Dynamic CSS with `@regex` Engine

**Scenario**: A modern SPA (Single Page Application) generates random IDs for every build, but they always follow a pattern like `post-1234...`.

**HTML:**

```html
<div id="post-837482-xz" class="feed-item">
  <span class="data">Target Info</span>
</div>
<div id="ad-banner-99" class="feed-item">
  <span>Ad</span>
</div>
```

**DSL Query:**

```text
@regex:div:id:^post- \d+.* :has(.data) ::text;
```

**Result:**

```text
Target Info
```

_The `@regex` engine scans all `div` elements where the `id` attribute starts with `post-` followed by digits._

**Advanced Regex Pattern:**

```text
@regex:a:href:.* \/product\/[a-z0-9\-]+$ ::attr(href);
```

Matches any link ending in a product slug pattern.

---

## 10. XPath Power Queries

**Scenario**: You need to select elements based on complex attribute logic that CSS can't handle, such as "starts with X" OR "does not contain Y".

**HTML:**

```html
<div class="user-profile" data-role="admin">Admin User</div>
<div class="user-profile" data-role="guest">Guest User</div>
<div class="user-dashboard">Dashboard</div>
```

**DSL Query:**

```css
@xpath: //div[contains(@class, 'user-') and not(@data-role='guest')] ::text;
```

**Result:**

```json
["Admin User", "Dashboard"]
```

_XPath allows Boolean logic (`and`, `not`, `or`) directly in the selector string._

**XPath with Text Matching:**

```css
@xpath: //h2[contains(text(), 'Specifications')]/following-sibling::table[1] ::table;
```

_Finds the first table immediately following an H2 containing "Specifications"._

---

## 11. Dynamic Pagination Discovery

**Scenario**: You are building a discovery pipeline and need to find the "Next Page" URL, even if the button has no unique ID and the text is wrapped in multiple spans.

**HTML:**

```html
<div class="pagination-container">
  <a href="/search?page=1" class="btn">1</a>
  <a href="/search?page=2" class="btn">
    <span class="icon"></span>
    <span class="text">Next Page</span>
  </a>
</div>
```

**DSL Query:**

```css
.pagination-container a:has(span:icontains('Next')) ::attr(href) ::url
```

**Result:**

```text
"https://example.com/search?page=2"
```

---

## 12. The Semantic Pivot (Finding context)

**Scenario**: You want to extract the "Ingredients" list from a recipe site. The list is just a `<ul>`, but it's always preceded by an `<h3>` with specific text.

**HTML:**

```html
<h3>Preparation</h3>
<ol>
  <li>Boil water...</li>
</ol>

<h3>Ingredients</h3>
<ul>
  <li>2 eggs</li>
  <li>1 cup flour</li>
</ul>
```

**DSL Query:**

```css
h3:icontains('Ingredients'):next
```

**Advanced Alternative (using `near`):**

```css
ul: near(h3: icontains("Ingredients"));
```

---

## 13. Deep Formatting Cleanup (Financial Data)

**Scenario**: Extracting messy stock data from a terminal where values have mixed symbols, commas, and percentage signs.

**HTML:**

```text
<span class="ticker-price">
  + 1,245.50 % (High)
</span>
```

**DSL Query:**

```css
.ticker-price ::text ::strip(' +%()') ::replace(',', '') ::strip
```

**Result:**

```text
1245.50
```

---

## 14. The List Slasher (Complex item filtering)

**Scenario**: Extract all article links from a homepage, but ONLY if the article is from the "Tech" category and has a reading time of more than 5 minutes.

**HTML:**

```html
<div class="article-card">
  <a href="/a1">AMD vs Nvidia</a>
  <span class="meta">Tech</span>
  <span class="read-time">10 min</span>
</div>
<div class="article-card">
  <a href="/a2">Baking Cookies</a>
  <span class="meta">Food</span>
  <span class="read-time">2 min</span>
</div>
```

**DSL Query:**

```css
.article-card:has(.meta:icontains('Tech')):has(.read-time:matches('\d\d? min')):icontains('10 min') a ::attr(href) ::url
```

**Result:**

```text
https://example.com/a1
```

---

## 15. The Strict Integrity Filter (DOM Validation)

**Scenario**: You only want to extract product data if the DOM structure is "complete" (has title, price, and an available stock indicator). This acts as a client-side validator to avoid junk data.

**HTML:**

```html
<div class="product">
  <h2 class="name">Valid Phone</h2>
  <span class="price">$999</span>
  <button class="add-to-cart">Buy Now</button>
</div>

<div class="product">
  <h2 class="name">Broken Item</h2>
  <!-- Missing Price -->
  <button class="add-to-cart" disabled>Out of Stock</button>
</div>
```

**DSL Query:**

```python
# Q builder
Q(".product").has(".name").has(".price").has("button:not([disabled])").descendant(".name").text()
```

**Raw Chained DSL:**

```css
.product:has(.name):has(.price):has(button:not([disabled])) .name ::text
```

**Reasoning:**

- `:has(.name)`: Ensures title exists.
- `:has(.price)`: Ensures price exists.
- `:has(button:not([disabled]))`: Ensures the item is actually purchasable.
- If any condition fails, the entire `.product` node is ignored.

---

## 16. The Double-Negative Gate (Exclusion logic)

**Scenario**: Selecting content that is _neither_ an advertisement _nor_ a sponsored post, but must still be within a specific article body.

**HTML:**

```html
<div class="item">Real Content</div>
<div class="item ad-unit">Hidden Ad</div>
<div class="item sponsored-post">Paid Article</div>
```

**DSL Query:**

```css
.item:not(.ad-unit):not(.sponsored-post) ::text
```

**Advanced Variation (Nested):**

```css
.container :not(:has(.ad-label)):not(:has(iframe)) ::text
```

This filters out any child of `.container` that doesn't contain an ad label AND doesn't contain an iframe.

---

## 17. Multi-Hop Context Validation

**Scenario**: You need to find a value (e.g., a "Discount Code") but only if its parent section is marked as "Verified" and the section doesn't have an "Expired" stamp.

**HTML:**

```html
<section class="offer-box">
  <div class="header">
    <span class="verified-badge">Official</span>
  </div>
  <div class="body">
    <code>SAVE50</code>
  </div>
</section>

<section class="offer-box">
  <div class="header">
    <span class="expired">Expired</span>
  </div>
  <div class="body">
    <code>OFFER20</code>
  </div>
</section>
```

**DSL Query:**

```css
code:closest(.offer-box):has(.verified-badge):not(:has(.expired)) ::text
```

**Logic Flow:**

1. Start at `code`.
2. Climb up to the nearest `.offer-box`.
3. Check if that box has `.verified-badge`.
4. Check if that box does **not** have `.expired`.
5. Extract text from the code if all conditions are met.

---

## 18. The Ghost Sibling Pattern

**Scenario**: Extracting a description only when it is immediately preceded by a specific icon (like a "Warning" icon), validating that the text is indeed a warning and not standard text.

**HTML:**

```html
<i class="icon-warning"></i>
<p>DANGER: High Voltage</p>

<i class="icon-info"></i>
<p>Standard Info</p>
```

**DSL Query:**

```css
i.icon-warning + p ::text
```

_Or more robustly via parent validation:_

```css
p:prev(i.icon-warning) ::text
```

---

## 19. Advanced List Pruning (Recursive Cleanup)

**Scenario**: You want the full HTML of a comment thread, but you need to recursively remove "Deleted" comments and "Author Signature" blocks from every valid comment.

**DSL Query (Chained recursion):**

```css
.comment-thread !cleanup(.comment:has(.deleted), .signature) ::html
```

This demonstrates how `!cleanup` works as a negative selector that modifies the DOM tree before extraction begins.

---

## 20. The Logic Gate Chain (Multi-layered Validation)

**Scenario**: Extracting a user comment only if:

1. It is within a `.verified` thread.
2. It is **not** a "bot" comment (marked by `.bot-tag`).
3. The user has **not** been banned (checked by looking at its parent's state).

**HTML:**

```html
<div class="thread verified">
  <div class="post" data-user-status="active">
    <span class="content">Hello!</span>
  </div>
  <div class="post" data-user-status="active">
    <span class="bot-tag">BOT</span>
    <span class="content">I am a bot.</span>
  </div>
  <div class="post" data-user-status="banned">
    <span class="content">Oops I'm banned.</span>
  </div>
</div>
```

**DSL Query:**

```css
.thread.verified .post:not(:has(.bot-tag)):not([data-user-status='banned']) .content ::text
```

**Why this is powerful for DOM Validation:**

- This query defines a "Valid Post" contract.
- By chaining `:not(...)`, we create a **White-list** environment where only "clean" data passes through the filter.
- If you use this inside a JSON schema, it ensures your "comment" field only returns meaningful human content, effectively moving validation logic from your Python/C# code into the Processing Engine itself.
