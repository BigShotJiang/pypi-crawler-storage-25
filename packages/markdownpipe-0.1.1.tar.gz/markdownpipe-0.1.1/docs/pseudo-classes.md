# Pseudo-Classes & DSL Reference

> The most powerful feature of Markdown Pipe. A zero-overhead extraction language built on top of CSS selectors that runs natively on our high-performance engine — no LLM, no guessing.
>
> 🌐 **[markdownpipe.com](https://markdownpipe.com/)**

---

## The Pipeline Model

Every DSL query executes in a strict, deterministic order. Think of it as a data stream:

```
[@engine:]selector :filter !mutation ::action ::action
```

| Stage        | Prefix | Role            | Description                                               |
| :----------- | :----- | :-------------- | :-------------------------------------------------------- |
| **Engine**   | `@`    | **Discovery**   | Override selector engine (e.g. `@regex:` for dynamic IDs) |
| **Selector** | —      | **Targeting**   | Standard CSS selector to find candidate nodes             |
| **Filter**   | `:`    | **Logic**       | Reduce node set based on content or DOM relationships     |
| **Mutation** | `!`    | **Preparation** | Surgically modify the DOM before extraction               |
| **Action**   | `::`   | **Output**      | Convert the final node(s) into a value                    |

---

## 🔍 Filters (`:`)

Filters run **after** the base selector and **before** actions. They reduce the candidate node list. Multiple filters can be chained.

### Text & Content

| Filter               | Args     | Description                                                                                    |
| :------------------- | :------- | :--------------------------------------------------------------------------------------------- |
| `:contains('text')`  | `string` | Case-sensitive substring match on text content.                                                |
| `:icontains('text')` | `string` | **Case-insensitive** match. Preferred for robustness against web variations.                   |
| `:matches('regex')`  | `regex`  | Match text content against a Regular Expression. e.g. `:matches('\d{4}-\d{2}')` for ISO dates. |

### DOM Traversal

| Filter                  | Args  | Description                                                                                                    |
| :---------------------- | :---- | :------------------------------------------------------------------------------------------------------------- |
| `:parent`               | —     | Jump to the immediate parent element. Auto-deduplicates.                                                       |
| `:ancestor(n)`          | `int` | Jump exactly `N` levels up the DOM tree. `:ancestor(2)` = grandparent.                                         |
| `:closest(selector)`    | `css` | Climbs the DOM tree until it finds the first element matching the selector. Essential for container discovery. |
| `:children`             | —     | Select all **immediate** child elements of the current nodes.                                                  |
| `:descendant(selector)` | `css` | Move scope to all matching descendants. This chains standard CSS after pseudos.                                |
| `:next`                 | —     | Move to the **next sibling** element (skips text nodes).                                                       |
| `:next(n)`              | `int` | Jump `N` elements forward among siblings.                                                                      |
| `:prev`                 | —     | Move to the **previous sibling** element (skips text nodes).                                                   |
| `:prev(n)`              | `int` | Jump `N` elements backward among siblings.                                                                     |
| `:near(selector)`       | `css` | Matches nodes if **any sibling** matches the given selector.                                                   |

### Logic & Intelligence

| Filter              | Args     | Description                                                                                                      |
| :------------------ | :------- | :--------------------------------------------------------------------------------------------------------------- |
| `:has(selector)`    | `css`    | Keep only nodes that contain a matching **descendant**. e.g. `:has(img)`.                                        |
| `:not(selector)`    | `css`    | Exclude nodes matching the selector. e.g. `:not(.sponsored)`.                                                    |
| `:semantic('auto')` | `'auto'` | AI content-density heuristic that locates the "main content" cluster by ignoring nav, footer, ads automatically. |

---

## ⚡ Mutations (`!`)

Mutations **physically modify the DOM** branch being processed before the action stage runs. This is not filtering — the nodes are permanently removed from the working tree.

| Mutation             | Args  | Description                                                                                                                               |
| :------------------- | :---- | :---------------------------------------------------------------------------------------------------------------------------------------- |
| `!cleanup(selector)` | `css` | Permanently removes all matching children from the current node scope. Accepts comma-separated selectors: `!cleanup(.ads, script, .nav)`. |

---

## 🎯 Actions (`::`)

Actions take the final node list and produce output values. **Actions can be chained** — each action receives the output of the previous one.

### Extraction Actions

| Action           | Args                 | Description                                                                                                                                                        |
| :--------------- | :------------------- | :----------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `::text`         | —                    | Extract and normalize plain text content.                                                                                                                          |
| `::html`         | —                    | Extract the full **outer** HTML of the node (alias: `::outer_html`).                                                                                               |
| `::inner_html`   | —                    | Extract the **inner** HTML only (children, not the tag itself).                                                                                                    |
| `::outer_html`   | —                    | Explicit alias for `::html`.                                                                                                                                       |
| `::attr(name)`   | `string`             | Extract the value of the given HTML attribute. e.g. `::attr(href)`, `::attr(data-price)`.                                                                          |
| `::url`          | —                    | Resolve `src`, `href`, lazy-load attributes (`data-src`, `data-lazy-src`, `srcset`) to **absolute URLs**. Handles srcset automatically picking the best candidate. |
| `::markdown`     | —                    | Convert the selected HTML to clean **Markdown** .                                                                                                                  |
| `::table`        | —                    | Parse `<table>` nodes into structured **Markdown tables** (handles colspan, rowspan, alignment).                                                                   |
| `::csv`          | —                    | Parse the text content as **CSV** and convert to a Markdown table.                                                                                                 |
| `::json`         | —                    | Parse the text content as a **JSON object** (ideal for `<script type="application/ld+json">`).                                                                     |
| `::redact(type)` | `'email'`\|`'phone'` | Automatically remove sensitive information from text. Patterns: `email`, `phone`.                                                                                  |

### String Formatting Actions

| Action                                    | Args                    | Description                                                                                                                                                   |
| :---------------------------------------- | :---------------------- | :------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `::strip`                                 | `chars?`                | Trim whitespace (or specific characters) from both ends of string results.                                                                                    |
| `::split(sep, index)`                     | `sep, int`              | Split the string by `sep` and return the item at `index`. e.g. `::split(' ', 0)` returns first word.                                                          |
| `::replace('old', 'new')`                 | `string, string`        | Literal string substitution. No regex, no escaping required. e.g. `::replace('$', '')`.                                                                       |
| `::replace_regex('pat', 'new', 'flags?')` | `regex, string, flags?` | Regex substitution via `re.sub()`. Supported flags: `i` (case-insensitive), `m` (multiline), `s` (dotall), `x` (verbose). e.g. `::replace_regex('\d+', 'N')`. |

### Collection Operations

| Action                | Args       | Description                                                                                   |
| :-------------------- | :--------- | :-------------------------------------------------------------------------------------------- |
| `::all`               | —          | Ensure the result is always returned as a **list**, even for single matches.                  |
| `::first`             | —          | Keep only the **first** item from the result list.                                            |
| `::last`              | —          | Keep only the **last** item from the result list.                                             |
| `::slice(start, end)` | `int, int` | Select a slice from the result list. Supports both `::slice(1, 3)` and `::slice(1:3)` syntax. |
| `::count`             | —          | Return the **count** of matched nodes as an integer.                                          |
| `::join(sep)`         | `string`   | Flatten a list of strings into one using the given separator. e.g. `::join(', ')`.            |

---

## 🔬 Chaining Example: Full Pipeline

**Goal**: Extract article comment authors from a page, excluding moderator comments, normalize names, and join them.

```
.comment-section > .comment :not(.moderator) :has(.author) .author::text::strip::join(', ')
```

**Flow:**

1. `.comment-section > .comment` — Find all comment nodes.
2. `:not(.moderator)` — Exclude moderator comments.
3. `:has(.author)` — Keep only comments that contain an author element.
4. `.author` — Scope down to the author element (via standard CSS descendant).
5. `::text` — Extract the plain text.
6. `::strip` — Trim whitespace.
7. `::join(', ')` — Merge into a single comma-separated string.

---

## 🎓 Real-World Recipes

### Extract price, strip currency symbol

```
.product-price::text::replace('$', '')::replace(',', '')::strip
```

### Extract all article images, resolving relative URLs to absolute

```
article img::all::url
```

### Extract contents of a JSON-LD structured data block

```
script[type="application/ld+json"]::json
```

### Pull main article body, remove ads & nav clutter, convert to Markdown

```
article.main-content !cleanup(.ad-box, .sidebar, nav)::markdown
```

### Find a container by proximity, then get the next price element

```
h2:icontains('pricing'):next .price::text
```

### Locate the nearest section wrapper, then drill into a sub-table

```
.plan-card:closest(.section):descendant(table.features)::table
```

### Auto-detect main content, ignore boilerplate (semantic AI heuristic)

```
body:semantic('auto')::markdown
```

### Redact all emails from a contact page before storing

```
.contact-info::text::redact('email')
```

### Extract 3rd to 6th list items

```
ul.results li::all::slice(2, 6)::text
```

---

## ⚠️ Important Notes

- **Chain ordering matters**: Apply `:not()` and `:has()` early to reduce the working set before expensive traversal filters like `:closest()`.
- **Mutations are permanent** within the pipeline scope. `!cleanup()` modifies the DOM branch in memory — it does not affect the live page.
- **Deduplication**: `:parent`, `:closest`, and `:ancestor` automatically deduplicate result nodes by identity.
- **Native CSS first**: Standard CSS pseudo-classes like `:nth-child()`, `:first-of-type`, `:last-of-type` are passed directly to the underlying CSS engine for native performance.
- **`::markdown` and `::table`** produce high-quality structured output optimized for AI ingestion and data pipelines.
