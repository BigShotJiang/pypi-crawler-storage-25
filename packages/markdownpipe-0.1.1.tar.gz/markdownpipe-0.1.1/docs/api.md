# API Reference — Python SDK

The Markdown Pipe Python SDK provides both synchronous (`PipeClient`) and asynchronous (`AsyncPipeClient`) interfaces. All methods are available on both clients with identical signatures.

> **Import aliases:** `MarkdownPipe`, `AsyncPipe`, `AsyncClient` → `AsyncPipeClient` · `Pipe`, `SyncPipe`, `Client` → `PipeClient`

---

## Client Initialization

```python
from markdownpipe import AsyncPipeClient, PipeClient

# Async (recommended for production)
async with AsyncPipeClient(
    api_key="sk-...",            # or set MARKDOWN_PIPE_API_KEY env var
    base_url="https://api.markdownpipe.com/v1",  # default
    timeout=30.0,                # seconds
    max_retries=3,               # exponential backoff on 429/5xx
) as client:
    ...

# Sync (scripts, notebooks)
with PipeClient(api_key="sk-...") as client:
    result = client.article("https://example.com/blog-post")
```

### Constructor Parameters

| Parameter     | Type             | Default                           | Description                                                  |
| ------------- | ---------------- | --------------------------------- | ------------------------------------------------------------ |
| `api_key`     | `str`            | `MARKDOWN_PIPE_API_KEY` env       | API key for authentication                                   |
| `base_url`    | `str`            | `https://api.markdownpipe.com/v1` | Override for self-hosted/staging                             |
| `timeout`     | `float`          | `30.0`                            | Per-request timeout in seconds                               |
| `max_retries` | `int`            | `3`                               | Max retries with exponential backoff (triggers on 429 + 5xx) |
| `hooks`       | `list[PipeHook]` | `[]`                              | Lifecycle hooks for observability                            |

---

## Core Extraction Methods

### `pipe(url, schema, *, version=None, checksum=None) → ExtractResponse`

**Endpoint:** `POST /pipe`

Custom schema extraction with full pipeline orchestration (fetch → extract → store).

```python
from markdownpipe import Q, AsyncPipeClient

async with AsyncPipeClient(api_key="sk-...") as client:
    result = await client.pipe(
        "https://example.com/q4-earnings",
        schema={
            "title": Q("h1").text(),
            "revenue": Q("table").has(":contains('Revenue')").table(),
            "summary": Q(".exec-summary").cleanup(".footnotes").markdown(),
        }
    )
    print(result.data["title"])
    print(result.data["revenue"])   # Structured JSON table
    print(result.usage.credits)     # Credits consumed

# Use a pre-validated checksum for server-side caching
validation = await client.validate(my_schema)
result = await client.pipe(url, schema=my_schema, checksum=validation.checksum)
```

| Parameter  | Type                  | Description                                     |
| ---------- | --------------------- | ----------------------------------------------- |
| `url`      | `str`                 | Target URL                                      |
| `schema`   | `dict[str, Q | str]` | Field map using `Q` builders or raw DSL strings |
| `version`  | `str | None`         | Pin processing logic version                    |
| `checksum` | `str | None`         | Pre-validated schema checksum for caching       |

**Returns:** [`ExtractResponse`](#extractresponse)

---

### `extract(url, schema, *, checksum=None) → ExtractResponse`

**Endpoint:** `POST /extract`

Lightweight custom schema extraction — no namespace presets, direct DSL application. Slightly lower overhead than `/pipe` for purely custom schemas.

```python
result = await client.extract(
    "https://shop.example.com/product/123",
    schema={
        "name": "h1::text",
        "price": ".price-current::text",
        "sku": "[data-sku]::attr(data-sku)",
        "in_stock": ".stock-status::text",
        "images": "img.product-image::all::attr(src)",
    }
)
for field, value in result.data.items():
    print(f"{field}: {value}")
```

**Returns:** [`ExtractResponse`](#extractresponse)

---

### `engine(url, schema, html) → EngineResponse`

**Endpoint:** `POST /engine`

Raw DSL engine — apply a schema to HTML you already have. No fetching, no storage. The lowest-latency extraction method.

```python
# Pattern: fetch once → reprocess many times
fetch_result = await client.fetch("https://example.com/report")
html = await client.get_stored_html(fetch_result.storage_url)

# Apply different schemas to the same HTML
summary = await client.engine(
    url="https://example.com/report",
    html=html,
    schema={"title": "h1::text", "summary": ".abstract::markdown"}
)

tables = await client.engine(
    url="https://example.com/report",
    html=html,
    schema={"tables": "table::all::table"}
)
```

| Parameter | Type                  | Description                              |
| --------- | --------------------- | ---------------------------------------- |
| `url`     | `str`                 | Context URL for resolving relative links |
| `schema`  | `dict[str, Q | str]` | Extraction schema                        |
| `html`    | `str`                 | Raw HTML string to process               |

**Returns:** [`EngineResponse`](#engineresponse)

---

### `process(url, namespace="article") → PipeResponse`

**Endpoint:** `POST /pipe` (namespace mode)

Preset extraction using a built-in content profile (article, product, serp). Best for major publishers with known layouts.

```python
# Article extraction — optimized for 300+ global publishers
result = await client.process("https://techcrunch.com/2024/01/15/ai-news/")
print(result.data["title"])
print(result.data["author"])
print(result.data["markdown"])

# Shortcuts
article = await client.article("https://bbc.com/news/technology-12345")
print(article.title)      # Direct Article model access
print(article.markdown)   # Alias for markdown content
```

**Returns:** [`PipeResponse`](#piperesponse) / [`Article`](#article)

---

## Acquisition Methods

### `fetch(url) → RawPipeResponse`

**Endpoint:** `POST /fetch`

Fetch and store raw HTML. Returns a `storage_url` — **HTML is never returned directly** to keep payloads small.

```python
fetch_res = await client.fetch("https://docs.python.org/3/library/asyncio.html")

print(fetch_res.job_id)       # UUID for later retrieval
print(fetch_res.storage_url)  # Gzip-compressed HTML URL

# Retrieve actual HTML
html = await client.get_stored_html(fetch_res.storage_url)
print(f"Fetched {len(html):,} bytes of HTML")
```

**Returns:** [`RawPipeResponse`](#rawpiperesponse)

---

### `get_stored_html(storage_url) → str`

Fetch and auto-decompress gzip HTML from a `storage_url` returned by any endpoint.

```python
# Works with storage_url from fetch(), pipe(), extract(), markdown()
html = await client.get_stored_html(response.storage_url)
```

**Returns:** `str` (decompressed HTML)

---

## Discovery Methods

### `map(url, *, depth=1, ignore_sitemap=False, selectors=None) → MapResponse`

**Endpoint:** `POST /map`

Discover all available URLs from a seed URL using sitemap, RSS, and link graph traversal.

```python
# Discover all articles on a news site
urls = await client.map("https://techcrunch.com", depth=1)
print(f"Found {urls.total} URLs")

for item in urls:
    print(f"  {item.url} — {item.title}")

# Restrict to specific navigation areas
urls = await client.map(
    "https://docs.example.com",
    depth=2,
    selectors=[".sidebar a", "nav.docs-nav a"]
)
```

**Returns:** [`MapResponse`](#mapresponse)

---

### `rss(url) → MapResponse`

**Endpoint:** `POST /map/rss`

Parse an RSS or Atom feed and return all items as `MapItem` objects.

```python
feed = await client.rss("https://hnrss.org/frontpage")
for item in feed:
    print(f"  [{item.title}]({item.url})")
```

**Returns:** [`MapResponse`](#mapresponse)

---

### `sitemap(url) → MapResponse`

**Endpoint:** `POST /map/sitemap`

Parse an XML or text sitemap and return all URLs.

```python
urls = await client.sitemap("https://example.com/sitemap.xml")
print(f"Sitemap contains {urls.total} URLs")
```

**Returns:** [`MapResponse`](#mapresponse)

---

## Converter Methods

### `markdown(html, *, url=None, config=None) → MarkdownResponse`

**Endpoint:** `POST /markdown`

Convert raw HTML to clean Markdown. For URL → Markdown workflows, use `fetch()` first.

```python
# Standalone HTML conversion
result = await client.markdown(
    html="<article><h1>Title</h1><p>Content here.</p></article>",
    url="https://example.com/page",  # Optional, for link resolution
    config={"commonmark": True}
)
print(result.markdown)   # Property shortcut → result.data["markdown"]

# Common pattern: fetch → then convert to Markdown
fetch_res = await client.fetch("https://example.com/long-doc")
html = await client.get_stored_html(fetch_res.storage_url)
md_res = await client.markdown(html, url="https://example.com/long-doc")
print(md_res.markdown)
```

**Returns:** [`MarkdownResponse`](#markdownresponse)

---

### `csv(csv_text, *, delimiter="auto") → CsvResponse`

**Endpoint:** `POST /markdown/csv`

Convert a CSV string to a formatted Markdown table.

```python
csv_data = """Name,Price,In Stock
Widget Pro,$49.99,Yes
Widget Lite,$19.99,No"""

result = await client.csv(csv_data)
print(result.markdown)  # Property shortcut → result.data.markdown
# | Name | Price | In Stock |
# |---|---|---|
# | Widget Pro | $49.99 | Yes |
# | Widget Lite | $19.99 | No |
```

**Returns:** [`CsvResponse`](#csv-excel-pdf-responses)

---

### `csv_batch(items) → CsvBatchResponse`

**Endpoint:** `POST /markdown/csv/batch`

Convert multiple CSV strings to Markdown tables in a single call (max 100 items).

```python
tables = await client.csv_batch([
    "Product,Price\nAlpha,$10\nBeta,$20",
    "Region,Sales\nUSA,1000\nEU,750",
])
for i, table in enumerate(tables.data.results):
    print(f"--- Table {i+1} ---\n{table}")
```

**Returns:** [`CsvBatchResponse`](#csv-excel-pdf-responses)

---

### `pdf(file_path, *, pages=None) → PdfResponse`

**Endpoint:** `POST /markdown/pdf`

Convert a PDF file to clean Markdown.

```python
result = await client.pdf("report.pdf", pages="1-5")
print(result.markdown)
print(f"Processed {result.data['pages']} pages")
```

| Parameter   | Type          | Description                                     |
| ----------- | ------------- | ----------------------------------------------- |
| `file_path` | `str`         | Path to local PDF file                          |
| `pages`     | `str | None` | Page range (e.g., "1-3,5", "all"). Default: all |

**Returns:** [`PdfResponse`](#csv-excel-pdf-responses)

---

### `excel(file_path, *, sheet_name=None) → ExcelResponse`

**Endpoint:** `POST /markdown/excel`

Convert an Excel file (`.xlsx`, `.xls`, `.ods`) to Markdown tables.

```python
# Convert specific sheet
result = await client.excel("data.xlsx", sheet_name="Sheet1")
print(result.markdown)

# Or convert all sheets (they will be separated by secondary headings)
result = await client.excel("data.xlsx")
```

**Returns:** [`ExcelResponse`](#csv-excel-pdf-responses)

---

### `excel_sheets(file_path) → ExcelSheetsResponse`

**Endpoint:** `POST /markdown/excel/sheets`

List all sheet names available in an Excel file.

```python
sheets = await client.excel_sheets("data.xlsx")
print(f"Sheets: {', '.join(sheets.data.sheets)}")
```

**Returns:** [`ExcelSheetsResponse`](#csv-excel-pdf-responses)

---

## Orchestration Methods

### `farm(items, *, concurrency=5, namespace="article", show_progress=False) → AsyncIterator[PipeResponse]`

Concurrent batch extraction across a list of URLs. Results are yielded as they complete.

```python
urls = [
    "https://techcrunch.com/article-1",
    "https://techcrunch.com/article-2",
    "https://techcrunch.com/article-3",
]

async with AsyncPipeClient(api_key="sk-...") as client:
    async for result in client.farm(urls, concurrency=10, show_progress=True):
        print(f"✓ {result.data.get('title', '(no title)')}")
        print(f"  Credits: {result.usage.credits}")
```

With a `MapResponse` from `map()`:

```python
discovery = await client.map("https://blog.example.com")
async for result in client.farm(discovery.urls, concurrency=5):
    save_to_db(result.data)
```

---

### `harvest(seed_url, *, depth=1, namespace="article", filter_func=None, concurrency=5, show_progress=False) → AsyncIterator[PipeResponse]`

Full data ingestion pipeline: **discover → filter → extract** in a single call.

```python
from markdownpipe import MapItem

async with AsyncPipeClient(api_key="sk-...") as client:
    # Only harvest articles published in 2024
    async for result in client.harvest(
        "https://techcrunch.com",
        depth=1,
        concurrency=10,
        show_progress=True,
        filter_func=lambda item: "/2024/" in item.url,
    ):
        print(result.data.get("title"))
```

---

## Dev Tools

### `validate(schema_or_dsl) → ValidationResponse`

**Endpoint:** `OPTIONS /validate`

Validate a schema or DSL string server-side. Returns:

- `checksum` — use in `X-Checksum` header for server-side caching
- `credits` — estimated cost for this schema
- `ast` — the parsed AST (for DSL strings)

```python
# Validate a full schema
result = await client.validate({
    "title": "h1::text",
    "content": ".article-body !cleanup(.ads)::markdown"
})
print(f"Checksum: {result.checksum}")
print(f"Estimated cost: {result.credits} credits")

# Cache the checksum and reuse on every request
MY_CHECKSUM = result.checksum
response = await client.extract(url, schema=my_schema, checksum=MY_CHECKSUM)

# Validate a raw DSL string
dsl_result = await client.validate(".article .title::text")
print(dsl_result.ast)
```

**Billing:** Free ✅

---

### `get_job(job_id) → dict`

Retrieve a previously stored job result by its UUID.

```python
job = await client.get_job("550e8400-e29b-41d4-a716-446655440000")
print(job["storage_url"])
print(job["created_at"])
```

---

### `health() → dict`

Check API health status.

```python
status = await client.health()
print(status)  # {"status": "ok", "version": "..."}
```

---

## Response Models

### `ExtractResponse`

Returned by `pipe()` and `extract()`.

```python
class ExtractResponse:
    status: JobStatus          # "success" or "error"
    data: dict[str, Any]       # Extracted fields matching your schema
    job_id: str | None         # UUID if content was stored
    storage_url: str | None    # URL to gzip-compressed raw HTML
    usage: PipeUsage           # {"latency": ms, "credits": float}
```

---

### `PipeResponse`

Returned by `process()`.

```python
class PipeResponse:
    status: str
    data: Article | Product | Serp   # Structured content model
    job_id: str | None
    usage: PipeUsage
```

---

### `EngineResponse`

Returned by `engine()`.

```python
class EngineResponse:
    data: dict[str, Any]    # Extracted fields
    usage: PipeUsage
```

---

### `RawPipeResponse`

Returned by `fetch()`.

```python
class RawPipeResponse:
    job_id: str              # UUID for the stored content
    url: str                 # The actual URL fetched
    storage_url: str | None  # URL to gzip-compressed HTML
    usage: PipeUsage
```

---

### `MarkdownResponse`

Returned by `markdown()`.

```python
class MarkdownResponse:
    status: str
    data: dict               # {"markdown": "# Title\n\n..."}
    markdown: str            # Property shortcut for data["markdown"]
    job_id: str | None
    storage_url: str | None
    usage: PipeUsage
```

---

### `MapResponse`

Returned by `map()`, `rss()`, `sitemap()`.

```python
class MapResponse:
    urls: list[MapItem | str | dict]   # Discovered URLs
    total: int | None                  # Total count
    usage: PipeUsage

# Iterable: for item in response / len(response) / response[0]
```

**`MapItem` fields:** `url`, `title`, `description`, `type` (`discover`/`rss`/`sitemap`), `metadata`

---

### `ValidationResponse`

Returned by `validate()`.

```python
class ValidationResponse:
    checksum: str | None    # Schema signature
    credits: float | None   # Estimated cost
    ast: dict | None        # Parsed AST (DSL mode only)
    dsl: str | None         # Normalized DSL (DSL mode only)
    version: str | None     # Logic version
```

---

### `CsvResponse` / `CsvBatchResponse` / `PdfResponse` / `ExcelResponse`

```python
class CsvResponse:
    markdown: str            # Clean Markdown
    data: dict               # {"markdown": "...", "rows": n}

class PdfResponse:
    markdown: str
    data: dict               # {"markdown": "...", "pages": n}

class ExcelResponse:
    markdown: str
    data: dict               # {"markdown": "...", "sheet_name": "..."}

class ExcelSheetsResponse:
    data: dict               # {"sheets": ["Sheet1", ...]}
```

---

### `Article`

Returned by `article()` and `process(namespace="article").data`.

```python
class Article:
    title: str | None
    authors: list[str] | None
    published_at: str | None
    markdown: str | None   # Clean Markdown content
    url: str | None
    metadata: ArticleMetadata
```

---

### `PipeUsage`

Embedded in all responses.

```python
class PipeUsage:
    latency: float    # Milliseconds
    credits: float    # Credits consumed
    breakdown: dict | None  # Available if X-Show-Billing-Breakdown: true is passed
```

---

## Hooks & Observability

```python
from markdownpipe import AsyncPipeClient, PipeHook, PipeStats

def log_request(method: str, url: str, payload: dict):
    print(f"→ {method} {url}")

def log_response(url: str, data: dict):
    usage = data.get("usage", {})
    print(f"← {url} [{usage.get('credits', 0)} credits, {usage.get('latency', 0)}ms]")

def log_error(url: str, error: Exception):
    print(f"✗ {url}: {error}")

hook = PipeHook(
    on_request=log_request,
    on_response=log_response,
    on_error=log_error,
)

async with AsyncPipeClient(api_key="sk-...", hooks=[hook]) as client:
    result = await client.article("https://example.com/post")
    print(f"Session stats: {client.stats}")
    # PipeStats(total_requests=1, total_credits=1, total_latency_ms=720.0, failed_requests=0)
```

---

## Error Handling

```python
from markdownpipe import PipeHTTPError

try:
    result = await client.extract(url, schema=my_schema)
except PipeHTTPError as e:
    if e.status_code == 429:
        print("Rate limited — credits exhausted")
    elif e.status_code == 400:
        print(f"Bad request: {e.message}")
    elif e.status_code == 401:
        print("Invalid API key")
    else:
        print(f"HTTP {e.status_code}: {e.message}")
except Exception as e:
    print(f"Network error: {e}")
```

The client automatically retries `429` and `5xx` responses with exponential backoff (up to `max_retries` attempts).

(extractresponse)=
(engineresponse)=
(piperesponse)=
(article)=
(rawpiperesponse)=
(mapresponse)=
(markdownresponse)=
(csvresponse-csvbatchresponse)=
