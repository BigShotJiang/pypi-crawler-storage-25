# 🐍 Python SDK

Welcome to the professional Python documentation for the **Markdown Pipe SDK**. This library is engineered for deterministic, schema-safe extraction at scale — suitable for search indexing, analytics, and downstream systems.

---

## 🏗️ Architecture: Optimized Extraction Pattern

Most web extraction tools operate as centralized bottlenecks. Markdown Pipe shifts the paradigm by treating the SDK as an **Intelligent Processing Client**.

1. **Local Intelligence**: The SDK manages concurrency, retry logic, and URL discovery on the edge (your infrastructure).
2. **Deterministic DSL**: Our **V1 Chained Protocol** ensures that the server performs purely functional extraction, leading to sub-millisecond execution.
3. **State-Free Extraction**: Avoid complex browser session management. The SDK delivers raw, high-fidelity data ready for your vectors.

---

## 🚜 Enterprise Workflows

### 🗺️ Map-Farm Pattern

The cornerstone of high-scale extraction.

- **Map**: Use `client.map()` to map out the topology of a website via sitemaps and link graphs.
- **Farm**: Use `client.farm()` to concurrently harvest thousands of pages with managed rate-limiting.

### 🛡️ Optimized Handshake (Checksums)

In production environments, every millisecond counts. By using `client.validate()`, you generate a cryptographic **Checksum** of your extraction logic. The server uses this checksum as a header to skip DSL parsing and hit optimized execution paths.

---

## 🎯 Core Concepts

| Concept       | Description                                                            |
| :------------ | :--------------------------------------------------------------------- |
| **Q Builder** | A fluent API for creating surgical extraction rules.                   |
| **Mutations** | Actions like `!cleanup` that modify the DOM before extraction.         |
| **Filters**   | Logic like `:has` and `:icontains` to find "needles in the haystack."  |
| **Credits**   | A predictable pricing model based on the complexity of your selectors. |

---

## 🗺️ Next Steps

- **[⏱️ Quick Start](quickstart.md)**: Get up and running in 60 seconds.
- **[🎯 Fluent DSL Reference](dsl.md)**: Master the art of surgical extraction.
- **[🚜 Discovery & Scaling](advanced-patterns.md)**: Build massive data pipelines.
- **[⚙️ API Reference](api.md)**: Complete method documentation.

```{toctree}
:maxdepth: 1
:hidden:

quickstart
dsl
advanced-patterns
api
cookbook
integrations
troubleshooting
```
