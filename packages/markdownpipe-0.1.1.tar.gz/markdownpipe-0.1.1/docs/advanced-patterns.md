# Infrastructure & Advanced Patterns

This guide covers production-level strategies for high-volume orchestration, state management, and observability.

---

## 1. The Map-Farm Pattern (Mass Scale)

Enterprise extraction requires a systematic approach to "harvesting" entire domains.

- **Map**: Use `client.map()` to discover the topology (Sitemaps, RSS, Link Graph).
- **Farm**: Use `client.farm()` to concurrently harvest thousands of pages.

```python
from markdownpipe import AsyncPipeClient

async with AsyncPipeClient() as client:
    # 1. Discover
    urls = await client.map("https://example.com/blog", depth=1)

    # 2. Harvest concurrently
    async for result in client.farm(urls, concurrency=20):
        print(f"Piped: {result.url}")
```

---

## 2. Optimized Handshaking (Checksums)

To minimize latency and credit costs, pre-validate your logic. Checksum skips the server-side DSL parser entirely.

```python
# Validate once
validation = await client.validate(schema)
checksum = validation.checksum

# Use in production loops
async for result in client.farm(urls, schema=schema, checksum=checksum):
    process(result.data)
```

---

## 3. Observability & Telemetry

The SDK tracks usage metrics locally for real-time monitoring.

```python
stats = client.stats
print(f"Credits burned: {stats.total_credits}")
print(f"Total calls: {stats.total_requests}")
print(f"Average latency: {stats.total_latency_ms / stats.total_requests:.2f}ms")
```

---

## 4. Customizing HTTP Behavior

Markdown Pipe uses `httpx` internally. You can pass your own `httpx.AsyncClient` to share connection pools or configure custom proxy/TLS settings.

```python
import httpx
from markdownpipe import AsyncPipeClient

transport = httpx.AsyncHTTPTransport(retries=5)
async_client = httpx.AsyncClient(transport=transport, timeout=60)

client = AsyncPipeClient(api_key="...", http_client=async_client)
```

---

## 5. Graceful Retries & Resilience

The SDK integrates `tenacity` for robust retrying of network-level errors. By default, it retries 3 times on transient 5xx errors or timeouts.

```python
# Customizing retry behavior via client options
client = AsyncPipeClient(
    api_key="...",
    max_retries=5,
    timeout=10
)
```
