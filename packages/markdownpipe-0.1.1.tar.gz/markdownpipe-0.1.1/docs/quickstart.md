# Quickstart

Get from zero to structured data extraction in under 5 minutes.

---

## Installation

```bash
# Recommended
uv add markdownpipe

# pip
pip install markdownpipe
```

**Requirements:** Python 3.10+

---

## Step 1 — Set Your API Key

```bash
export MARKDOWN_PIPE_API_KEY="sk-..."
```

Or pass it directly: `AsyncPipeClient(api_key="sk-...")`

---

## Step 2 — Your First Extraction

### Preset Article Extraction

The fastest way to get clean Markdown from any news article or blog post.
Works out-of-the-box on 300+ major publishers (TechCrunch, BBC, Medium, etc.).

```python
import asyncio
from markdownpipe import AsyncPipeClient

async def main():
    async with AsyncPipeClient() as client:
        article = await client.article("https://techcrunch.com/2024/01/15/ai-news/")

        print(f"Title:   {article.title}")
        print(f"Author:  {article.author}")
        print(f"Content: {article.markdown[:300]}...")

asyncio.run(main())
```

---

## Step 3 — Custom Schema Extraction

Define exactly what data you want using the `Q` builder — a fluent, type-safe DSL.

```python
from markdownpipe import AsyncPipeClient, Q

PRODUCT_SCHEMA = {
    "name":        Q("h1").text(),
    "price":       Q(".price-current").text(),
    "sku":         Q("[data-sku]").attr("data-sku"),
    "images":      Q("img.product-photo").all().attr("src"),
    "description": Q(".product-desc").cleanup(".ads", ".promo").markdown(),
    "specs":       Q("table.specs-table").table(),       # → structured JSON
    "in_stock":    Q(".stock-status").text(),
}

async with AsyncPipeClient() as client:
    result = await client.extract(
        "https://shop.example.com/product/widget-pro",
        schema=PRODUCT_SCHEMA
    )

    print(result.data["name"])    # "Widget Pro"
    print(result.data["price"])   # "$49.99"
    print(result.data["specs"])   # [{"Feature": "Weight", "Value": "120g"}, ...]
    print(f"Used {result.usage.credits} credits in {result.usage.latency}ms")
```

---

## Step 4 — Scale with Discovery

Don't extract one page — harvest the whole site.

```python
import asyncio
from markdownpipe import AsyncPipeClient

ARTICLE_SCHEMA = {
    "title":     "h1::text",
    "author":    ".byline::text",
    "content":   "article::markdown",
    "published": "time[datetime]::attr(datetime)",
}

async def main():
    async with AsyncPipeClient() as client:
        # 1. Discover all article URLs
        discovery = await client.map("https://blog.example.com", depth=1)
        print(f"Found {discovery.total} URLs")

        # 2. Filter to articles only
        articles = [item for item in discovery if "/blog/" in item.url]

        # 3. Extract all concurrently (10 at a time)
        async for result in client.farm(articles, concurrency=10, show_progress=True):
            print(f"✓ {result.data.get('title')}")

asyncio.run(main())
```

Or use `harvest()` for a one-liner:

```python
async with AsyncPipeClient() as client:
    async for result in client.harvest(
        "https://blog.example.com",
        depth=1,
        concurrency=10,
        filter_func=lambda item: "/2024/" in item.url,
    ):
        print(result.data.get("title"))
```

---

## Step 5 — Fetch → Markdown Pipeline

Separate acquisition from processing. Ideal for async pipelines, retries, and cost efficiency.

```python
from markdownpipe import AsyncPipeClient

async with AsyncPipeClient() as client:
    # 1. Fetch and store raw HTML (1 credit)
    fetch_res = await client.fetch("https://docs.python.org/3/library/asyncio.html")
    print(f"Stored at: {fetch_res.storage_url}")

    # 2. Get the HTML later (from storage, auto-decompressed)
    html = await client.get_stored_html(fetch_res.storage_url)
    print(f"HTML size: {len(html):,} bytes")

    # 3. Convert to Markdown (1 credit)
    md_res = await client.markdown(html, url="https://docs.python.org")
    print(md_res.markdown[:500])
```

---

## Step 6 — Production Optimization (Schema Checksums)

Pre-validate your schema once to get a signature checksum. Send this on every subsequent request so the server can skip validation and use a pre-compiled extraction path.

```python
from markdownpipe import AsyncPipeClient, Q

MY_SCHEMA = {
    "title":   Q("h1").text(),
    "content": Q("article").cleanup(".ads", "script").markdown(),
    "links":   Q("article a").all().attr("href"),
}

async with AsyncPipeClient() as client:
    # Validate once (free — no credits consumed)
    validation = await client.validate(MY_SCHEMA)
    CHECKSUM = validation.checksum
    print(f"Schema checksum: {CHECKSUM}")
    print(f"Estimated cost:  {validation.credits} credits/request")

    # Use checksum on every subsequent request
    result = await client.extract(
        "https://example.com/article",
        schema=MY_SCHEMA,
        checksum=CHECKSUM,   # ← enables server-side caching
    )
```

---

## Step 7 — DSL Engine (Advanced)

Run the DSL engine directly on HTML you already have. No network round-trip for fetching.

```python
from markdownpipe import AsyncPipeClient

# Imagine you have HTML from your own fetcher or database
raw_html = """
<article>
  <h1>Q4 2024 Earnings Report</h1>
  <table class='financials'>
    <tr><th>Metric</th><th>Q4 2024</th><th>Q4 2023</th></tr>
    <tr><td>Revenue</td><td>$1.2B</td><td>$950M</td></tr>
    <tr><td>Net Income</td><td>$180M</td><td>$140M</td></tr>
  </table>
</article>
"""

async with AsyncPipeClient() as client:
    result = await client.engine(
        url="https://example.com/earnings",   # context URL
        html=raw_html,
        schema={
            "title":     "h1::text",
            "financials": ".financials::table",   # → structured JSON
        }
    )
    print(result.data["title"])
    print(result.data["financials"])
    # [{"Metric": "Revenue", "Q4 2024": "$1.2B", "Q4 2023": "$950M"}, ...]
```

---

## Synchronous Client

All methods are available synchronously for scripts, notebooks, or non-async environments.

```python
from markdownpipe import PipeClient, Q

with PipeClient(api_key="sk-...") as client:
    # Article extraction
    article = client.article("https://bbc.com/news/technology-67890")
    print(article.title)

    # Custom extraction
    result = client.extract(
        "https://example.com/product",
        schema={"name": Q("h1").text(), "price": Q(".price").text()}
    )
    print(result.data)

    # CSV conversion
    csv_result = client.csv("Name,Age\nAlice,30\nBob,25")
    print(csv_result.markdown)
```

---

## Next Steps

- **[API Reference](api.md)** — Full method signatures, all response models, error handling
- **[DSL Guide](dsl.md)** — Complete `Q` builder reference with selector syntax
- **[Cookbook](cookbook.md)** — Ready-to-use recipes (RAG pipelines, monitoring, news workflows)
- **[Advanced Patterns](advanced-patterns.md)** — Production strategies: caching, retry logic, cost optimization
- **[Integrations](integrations.md)** — FastAPI, LangChain, Qdrant, PostgreSQL, and more
