import pytest
import respx
from httpx import Response
from markdownpipe import AsyncClient, Client


@pytest.mark.asyncio
async def test_async_client_pdf():
    async with AsyncClient(api_key="sk-test") as client:
        with respx.mock:
            respx.post("https://api.markdownpipe.com/v1/markdown/pdf/").mock(
                return_value=Response(
                    200,
                    json={
                        "status": "success",
                        "data": {"markdown": "# PDF", "pages": 1},
                        "usage": {"credits": 2.0},
                    },
                )
            )

            res = await client.pdf(b"fake pdf content")
            assert res.markdown == "# PDF"
            assert res.data.pages == 1
            assert res.usage.credits == 2.0


@pytest.mark.asyncio
async def test_async_client_excel():
    async with AsyncClient(api_key="sk-test") as client:
        with respx.mock:
            respx.post("https://api.markdownpipe.com/v1/markdown/excel/").mock(
                return_value=Response(
                    200,
                    json={
                        "status": "success",
                        "data": {"markdown": "| Col |", "sheet_name": "Sheet1"},
                        "usage": {"credits": 1.0},
                    },
                )
            )

            res = await client.excel(b"fake excel content", sheet_name="Sheet1")
            assert "| Col |" in res.markdown
            assert res.data.sheet_name == "Sheet1"
            assert res.usage.credits == 1.0


def test_sync_client_pdf():
    client = Client(api_key="sk-test")
    with respx.mock:
        respx.post("https://api.markdownpipe.com/v1/markdown/pdf/").mock(
            return_value=Response(
                200,
                json={
                    "status": "success",
                    "data": {"markdown": "# PDF_SYNC", "pages": 2},
                    "usage": {"credits": 2.0},
                },
            )
        )

        res = client.pdf(b"fake pdf content")
        assert res.markdown == "# PDF_SYNC"
        assert res.data.pages == 2
