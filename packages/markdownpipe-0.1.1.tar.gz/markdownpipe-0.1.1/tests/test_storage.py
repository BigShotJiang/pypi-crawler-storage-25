from __future__ import annotations

import gzip


def test_gzip_magic_byte_detection():
    """Verify that the gzip magic bytes (0x1f 0x8b) are correctly detected."""
    html = "<h1>Hello World</h1>"
    compressed = gzip.compress(html.encode("utf-8"))

    # Magic byte check used in SDK's get_stored_html()
    assert compressed[:2] == b"\x1f\x8b", "gzip magic bytes not found"


def test_gzip_decompression_roundtrip():
    """Verify that gzip compress → decompress produces original content."""
    original = (
        "<html><body><h1>Test Article</h1><p>Some content here.</p></body></html>"
    )
    compressed = gzip.compress(original.encode("utf-8"))

    # Simulate SDK decompression logic
    if compressed[:2] == b"\x1f\x8b":
        result = gzip.decompress(compressed).decode("utf-8")
    else:
        result = compressed.decode("utf-8")

    assert result == original


def test_plain_content_passthrough():
    """Content that is NOT gzip-compressed should pass through unchanged."""
    plain = b"<h1>Not compressed</h1>"

    # Must NOT start with gzip magic bytes
    assert plain[:2] != b"\x1f\x8b"

    result = plain.decode("utf-8")
    assert "<h1>" in result
    assert "Not compressed" in result


def test_gzip_with_unicode_content():
    """gzip decompression should correctly handle UTF-8 content."""
    html = "<p>Tiếng Việt: Xin chào</p>"
    compressed = gzip.compress(html.encode("utf-8"))

    result = gzip.decompress(compressed).decode("utf-8")
    assert "Tiếng Việt" in result
    assert "Xin chào" in result


def test_empty_gzip_content():
    """Empty string should compress and decompress correctly."""
    compressed = gzip.compress(b"")
    assert compressed[:2] == b"\x1f\x8b"
    result = gzip.decompress(compressed)
    assert result == b""
