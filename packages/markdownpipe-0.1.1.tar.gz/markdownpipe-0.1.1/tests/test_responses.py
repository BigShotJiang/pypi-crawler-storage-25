from __future__ import annotations


from markdownpipe.enums import ResponseStatus
from markdownpipe.responses import (
    CsvBatchResponse,
    CsvResponse,
    EngineResponse,
    ExtractResponse,
    MapItem,
    MapResponse,
    MarkdownResponse,
    PipeUsage,
    PipeUsageBreakdown,
    RawPipeResponse,
    ValidationResponse,
)


# ── PipeUsage ──────────────────────────────────────────────────────────────────


def test_pipe_usage_minimal():
    usage = PipeUsage(credits=1.0, latency=None)
    assert usage.credits == 1.0
    assert usage.latency is None
    assert usage.breakdown is None


def test_pipe_usage_with_breakdown():
    breakdown_data = {"base": 1.0, "total_dsl": 0.25, "ops": {"text": 0.1}}
    usage = PipeUsage(
        credits=1.25, latency=150.0, breakdown=PipeUsageBreakdown(**breakdown_data)
    )
    assert usage.breakdown.base == 1.0
    assert usage.breakdown.total_dsl == 0.25


# ── ExtractResponse ────────────────────────────────────────────────────────────


def test_extract_response_success():
    data = {
        "status": "success",
        "data": {"title": "Test Article"},
        "job_id": "job_001",
        "storage_url": "https://storage.example.com/job_001.gz",
        "usage": {"credits": 1.0, "latency": 200.0},
    }
    resp = ExtractResponse(**data)
    assert resp.status == ResponseStatus.SUCCESS
    assert resp.data["title"] == "Test Article"
    assert resp.job_id == "job_001"
    assert resp.usage.credits == 1.0


def test_extract_response_error():
    data = {"status": "error", "data": {}}
    resp = ExtractResponse(**data)
    assert resp.status == ResponseStatus.ERROR
    assert resp.job_id is None
    # usage has a default_factory, so credits defaults to 0.0
    assert resp.usage.credits == 0.0


# ── MarkdownResponse ───────────────────────────────────────────────────────────


def test_markdown_response_accessor():
    data = {
        "status": "success",
        "data": {"markdown": "# Hello World", "storage_url": "https://s.com/abc.gz"},
        "usage": {"credits": 0.5, "latency": 80.0},
    }
    resp = MarkdownResponse(**data)
    assert resp.status == ResponseStatus.SUCCESS
    assert resp.markdown == "# Hello World"
    assert resp.usage.credits == 0.5


# ── CsvResponse ───────────────────────────────────────────────────────────────


def test_csv_response_parse():
    data = {
        "status": "success",
        "data": {"markdown": "| a | b |\n|---|---|\n| 1 | 2 |", "rows": 1},
        "usage": {"credits": 0.5, "latency": 40.0},
    }
    resp = CsvResponse(**data)
    assert resp.status == ResponseStatus.SUCCESS
    assert "| a | b |" in resp.data.markdown
    assert resp.data.rows == 1


def test_csv_batch_response_parse():
    data = {
        "status": "success",
        "data": {
            "results": ["| a |\n|---|", "| x |\n|---|"],
            "count": 2,
        },
        "usage": {"credits": 1.0, "latency": 90.0},
    }
    resp = CsvBatchResponse(**data)
    assert resp.data.count == 2
    assert len(resp.data.results) == 2


# ── RawPipeResponse ────────────────────────────────────────────────────────────


def test_raw_pipe_response_no_html_field():
    """RawPipeResponse must NOT contain a 'html' field (Phase 40 requirement)."""
    data = {
        "job_id": "job_abc",
        "url": "https://example.com",
        "storage_url": "https://storage.example.com/abc.gz",
        "usage": {"credits": 1.0, "latency": 300.0},
    }
    resp = RawPipeResponse(**data)
    assert resp.job_id == "job_abc"
    assert resp.storage_url is not None
    # html field must not exist on this response model
    assert not hasattr(resp, "html")


def test_raw_pipe_response_without_storage():
    data = {
        "job_id": "job_xyz",
        "url": "https://example.com",
    }
    resp = RawPipeResponse(**data)
    assert resp.storage_url is None
    # usage has a default_factory, so credits defaults to 0.0
    assert resp.usage.credits == 0.0


def test_raw_pipe_response_optional_job_id_matches_server_fetch():
    """Server may return fetch without persistence (job_id null)."""
    data = {
        "url": "https://example.com",
        "job_id": None,
        "storage_url": None,
        "usage": {"credits": 0.1, "latency": 12},
    }
    resp = RawPipeResponse(**data)
    assert resp.job_id is None
    assert resp.url == "https://example.com"


# ── EngineResponse ────────────────────────────────────────────────────────────


def test_engine_response_parse():
    data = {
        "data": {"price": "$42.00", "title": "Product"},
        "usage": {"credits": 1.5, "latency": 120.0},
    }
    resp = EngineResponse(**data)
    assert resp.data["price"] == "$42.00"
    assert resp.usage.credits == 1.5


# ── MapResponse & MapItem ─────────────────────────────────────────────────────


def test_map_response_parse():
    data = {
        "urls": [
            {"url": "https://a.com/page1", "type": "map", "metadata": {"depth": 1}},
            {"url": "https://a.com/page2", "type": "map", "metadata": {}},
        ],
        "total": 2,
        "usage": {"credits": 5.0},
    }
    resp = MapResponse(**data)
    assert resp.total == 2
    assert len(resp.urls) == 2


def test_map_item_parse():
    item = MapItem(
        url="https://example.com/page",
        title="Example Page",
        description="A test page",
        type="map",
        metadata={"depth": 2},
    )
    assert item.url == "https://example.com/page"
    assert item.title == "Example Page"


# ── ValidationResponse ────────────────────────────────────────────────────────


def test_validation_response_minimal():
    data = {"dsl": "div:has(p)", "credits": 3, "version": "1"}
    resp = ValidationResponse(**data)
    assert resp.credits == 3
    assert resp.version == "1"
    assert resp.dsl == "div:has(p)"


def test_validation_response_empty():
    resp = ValidationResponse()
    assert resp.credits is None
    assert resp.dsl is None
    assert resp.version is None


def test_usage_summary_response_parse():
    from markdownpipe.responses import UsageSummaryResponse

    data = {
        "total_credits_used": 150.5,
        "recent_records": [
            {
                "id": "rec_001",
                "url": "https://example.com/1",
                "status_code": 200,
                "credits_cost": 1.0,
                "response_time_ms": 100,
                "created_at": "2024-02-23T10:00:00Z",
            }
        ],
    }
    resp = UsageSummaryResponse(**data)
    assert resp.total_credits_used == 150.5
    assert len(resp.recent_records) == 1
    assert resp.recent_records[0].id == "rec_001"
    assert resp.recent_records[0].credits_cost == 1.0
