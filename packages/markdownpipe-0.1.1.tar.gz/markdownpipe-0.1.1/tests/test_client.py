from __future__ import annotations

from markdownpipe import QueryAST


def test_client_init():
    from markdownpipe import PipeClient

    client = PipeClient(base_url="http://localhost:8001", api_key="secret")
    assert client.base_url == "http://localhost:8001"
    assert client.headers["Authorization"] == "Bearer secret"


def test_client_header_normalization():
    from markdownpipe import PipeClient

    client = PipeClient(base_url="http://test", api_key="Bearer already-has")
    assert client.headers["Authorization"] == "Bearer already-has"


def test_async_client_init():
    from markdownpipe import AsyncPipeClient

    client = AsyncPipeClient(base_url="http://localhost:8001", api_key="secret")
    assert client.base_url == "http://localhost:8001"
    assert client.headers["Authorization"] == "Bearer secret"


def test_query_ast_conversion():
    dsl = "div:has(p)"
    ast = QueryAST.from_dsl(dsl)
    assert ast.selector.expr == "div"
    assert ast.filters[0].op == "has"
    assert len(ast.rules) == 0
    assert ast.serialize().strip() == dsl.strip()


def test_client_schema_serialization():
    from markdownpipe import Q, PipeClient

    client = PipeClient(api_key="test")
    schema = {
        "title": Q(".title").text(),
        "tags": Q(".tag").all().text(),
        "metadata": {"author": Q(".author").text()},
    }

    serialized = client._serialize_schema(schema)
    assert serialized["title"] == ".title::text"
    assert serialized["tags"] == ".tag::all::text"
    assert serialized["metadata"]["author"] == ".author::text"
