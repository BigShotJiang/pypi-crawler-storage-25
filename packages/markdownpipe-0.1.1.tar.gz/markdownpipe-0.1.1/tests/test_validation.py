from __future__ import annotations

from markdownpipe import PipeQuerySchema


def test_dsl_validation_flow():
    # User sends a DSL string
    user_dsl = "article:has(p)"

    # 1. API receives it via PipeQuerySchema
    schema = PipeQuerySchema(dsl=user_dsl)

    # 2. Process and Validate
    response = schema.validate_and_process()

    print(f"DSL: {response.dsl}")
    print(f"Version: {response.version}")

    assert response.version == "1"
    assert response.ast.selector.expr == "article"
    # Logic might normalize spaces during AST -> DSL Conversion
    assert response.dsl.replace(" ", "") == user_dsl.replace(" ", "")


if __name__ == "__main__":
    try:
        test_dsl_validation_flow()
        print("\nValidation Test Passed!")
    except Exception as e:
        print(f"\nValidation Test Failed: {e}")
        import traceback

        traceback.print_exc()
