import pytest
import httpx
import respx
import gzip
from markdownpipe import PipeClient, AsyncPipeClient, PipeHTTPError, PipeHook
from markdownpipe.responses import RawPipeResponse, EngineResponse


@respx.mock
def test_sync_client_request_flow():
    client = PipeClient(api_key="test_key", base_url="https://mock-api.com")
    url = "https://example.com"

    # Mock /health
    respx.get("https://mock-api.com/health").mock(
        return_value=httpx.Response(200, json={"status": "ok"})
    )
    assert client.health() == {"status": "ok"}

    # Mock /fetch
    respx.post("https://mock-api.com/fetch/").mock(
        return_value=httpx.Response(
            200,
            json={
                "status": "success",
                "job_id": "job1",
                "url": url,
                "storage_url": "s1",
                "usage": {"credits": 1, "latency": 100},
            },
        )
    )
    res = client.fetch(url)
    assert isinstance(res, RawPipeResponse)
    assert res.job_id == "job1"

    # Mock /engine
    respx.post("https://mock-api.com/engine/").mock(
        return_value=httpx.Response(
            200,
            json={
                "status": "success",
                "data": {"title": "Test"},
                "usage": {"credits": 1, "latency": 100},
            },
        )
    )
    res = client.engine(url, {"title": "title"}, "<html></html>")
    assert isinstance(res, EngineResponse)
    assert res.data["title"] == "Test"


@pytest.mark.asyncio
@respx.mock
async def test_async_client_request_flow():
    async with AsyncPipeClient(
        api_key="test_key", base_url="https://mock-api.com"
    ) as client:
        # Mock /health
        respx.get("https://mock-api.com/health").mock(
            return_value=httpx.Response(200, json={"status": "ok"})
        )
        assert await client.health() == {"status": "ok"}

        # Mock /pipe
        respx.post("https://mock-api.com/pipe/").mock(
            return_value=httpx.Response(
                200,
                json={
                    "status": "success",
                    "data": {"markdown": "# Test", "metadata": {"title": "Article"}},
                    "usage": {"credits": 1, "latency": 100},
                },
            )
        )
        res = await client.process("https://example.com")
        assert res.data.markdown == "# Test"


@respx.mock
def test_sync_extract_and_pipe_methods():
    client = PipeClient(api_key="test", base_url="https://mock-api.com")

    # Mock /extract
    respx.post("https://mock-api.com/extract/").mock(
        return_value=httpx.Response(
            200,
            json={"status": "success", "data": {"foo": "bar"}, "usage": {"credits": 1}},
        )
    )
    res = client.extract("https://x.com", {"foo": "foo"})
    assert res.data["foo"] == "bar"
    assert res.status.value == "success"


@respx.mock
def test_map_and_rss_methods():
    client = PipeClient(api_key="test", base_url="https://mock-api.com")

    respx.post("https://mock-api.com/map/").mock(
        return_value=httpx.Response(
            200,
            json={
                "urls": ["https://a.com", {"url": "https://b.com", "type": "sitemap"}],
                "total": 2,
            },
        )
    )
    res = client.map("https://seed.com")
    assert len(res) == 2
    assert res.urls[0] == "https://a.com"


@respx.mock
def test_markdown_and_csv_methods():
    client = PipeClient(api_key="test", base_url="https://mock-api.com")

    respx.post("https://mock-api.com/markdown/").mock(
        return_value=httpx.Response(200, json={"data": {"markdown": "# Hello"}})
    )
    res = client.markdown("<html></html>")
    assert res.markdown == "# Hello"

    respx.post("https://mock-api.com/markdown/csv/").mock(
        return_value=httpx.Response(
            200, json={"data": {"markdown": "| a |", "rows": 1}}
        )
    )
    res = client.csv("a,b")
    assert res.markdown == "| a |"


@respx.mock
def test_validation_method():
    client = PipeClient(api_key="test", base_url="https://mock-api.com")

    # Validation uses POST
    respx.post("https://mock-api.com/validate/").mock(
        return_value=httpx.Response(
            200,
            json={"ast": {"type": "root"}, "dsl": "div::text"},
            headers={"X-Credits": "2.5", "X-Checksum": "abc", "X-Version": "1.0"},
        )
    )

    res = client.validate("div::text")
    assert res.credits == 2.5
    assert res.checksum == "abc"


@respx.mock
def test_retry_logic():
    client = PipeClient(
        api_key="test_key", max_retries=2, base_url="https://mock-api.com"
    )
    route = respx.get("https://mock-api.com/health")
    route.side_effect = [
        httpx.Response(500),
        httpx.Response(200, json={"status": "ok"}),
    ]
    assert client.health() == {"status": "ok"}
    assert route.call_count == 2


@respx.mock
def test_error_handling():
    client = PipeClient(
        api_key="test_key", max_retries=1, base_url="https://mock-api.com"
    )
    respx.get("https://mock-api.com/health").mock(
        return_value=httpx.Response(400, text="Bad Request")
    )

    with pytest.raises(PipeHTTPError) as exc:
        client.health()
    assert exc.value.status_code == 400


def test_hooks():
    history = []

    def on_req(m, u, p):
        history.append("req")

    def on_res(u, d):
        history.append("res")

    hook = PipeHook(on_request=on_req, on_response=on_res)
    client = PipeClient(api_key="test", hooks=[hook], base_url="https://mock-api.com")

    with respx.mock:
        respx.get("https://mock-api.com/health").mock(
            return_value=httpx.Response(200, json={"status": "ok"})
        )
        client.health()

    assert "req" in history
    assert "res" in history


def test_stats():
    client = PipeClient(api_key="test", base_url="https://mock-api.com")
    assert client.stats.total_requests == 0

    with respx.mock:
        respx.get("https://mock-api.com/health").mock(
            return_value=httpx.Response(
                200, json={"status": "ok", "usage": {"credits": 5, "latency": 50}}
            )
        )
        client.health()

    assert client.stats.total_requests == 1
    assert client.stats.total_credits == 5


@respx.mock
def test_get_stored_html_decompression():
    client = PipeClient(api_key="test")
    content = b"<html>hello</html>"
    gzipped = gzip.compress(content)

    respx.get("https://storage.com/file.gz").mock(
        return_value=httpx.Response(200, content=gzipped)
    )

    html = client.get_stored_html("https://storage.com/file.gz")
    assert html == "<html>hello</html>"


@respx.mock
def test_sync_farm_and_harvest():
    client = PipeClient(api_key="test", base_url="https://mock-api.com")

    # Mock /map for harvest
    respx.post("https://mock-api.com/map/").mock(
        return_value=httpx.Response(
            200, json={"urls": ["https://a.com", "https://b.com"], "total": 2}
        )
    )

    # Mock /pipe for farm
    respx.post("https://mock-api.com/pipe/").mock(
        return_value=httpx.Response(
            200,
            json={
                "status": "success",
                "data": {"markdown": "# Content"},
                "usage": {"credits": 1},
            },
        )
    )

    # Test farm
    results = list(client.farm(["https://a.com", "https://b.com"], concurrency=2))
    assert len(results) == 2

    # Test harvest
    results = list(client.harvest("https://seed.com", concurrency=2))
    assert len(results) == 2


@pytest.mark.asyncio
@respx.mock
async def test_async_farm_and_harvest():
    async with AsyncPipeClient(
        api_key="test", base_url="https://mock-api.com"
    ) as client:
        # Mock /map
        respx.post("https://mock-api.com/map/").mock(
            return_value=httpx.Response(
                200, json={"urls": ["https://c.com"], "total": 1}
            )
        )

        # Mock /pipe
        respx.post("https://mock-api.com/pipe/").mock(
            return_value=httpx.Response(
                200,
                json={
                    "status": "success",
                    "data": {"markdown": "# Async"},
                    "usage": {"credits": 1},
                },
            )
        )

        # Test farm
        results = []
        async for res in client.farm(["https://c.com"]):
            results.append(res)
        assert len(results) == 1

        # Test harvest
        results = []
        async for res in client.harvest("https://seed2.com"):
            results.append(res)
        assert len(results) == 1


@respx.mock
def test_usage_summary_method():
    client = PipeClient(api_key="test", base_url="https://mock-api.com")
    respx.get("https://mock-api.com/usage/summary/").mock(
        return_value=httpx.Response(
            200, json={"total_credits_used": 10.0, "recent_records": []}
        )
    )
    res = client.usage()
    assert res.total_credits_used == 10.0


@respx.mock
def test_get_job_method():
    client = PipeClient(api_key="test", base_url="https://mock-api.com")
    respx.get("https://mock-api.com/jobs/job1/").mock(
        return_value=httpx.Response(200, json={"job_id": "job1", "status": "done"})
    )
    res = client.get_job("job1")
    assert res["job_id"] == "job1"


@pytest.mark.asyncio
@respx.mock
async def test_async_usage_summary_method():
    async with AsyncPipeClient(
        api_key="test", base_url="https://mock-api.com"
    ) as client:
        respx.get("https://mock-api.com/usage/summary/").mock(
            return_value=httpx.Response(
                200, json={"total_credits_used": 10.0, "recent_records": []}
            )
        )
        res = await client.usage()
        assert res.total_credits_used == 10.0


@pytest.mark.asyncio
@respx.mock
async def test_async_get_job_method():
    async with AsyncPipeClient(
        api_key="test", base_url="https://mock-api.com"
    ) as client:
        respx.get("https://mock-api.com/jobs/job1/").mock(
            return_value=httpx.Response(200, json={"job_id": "job1", "status": "done"})
        )
        res = await client.get_job("job1")
        assert res["job_id"] == "job1"


@respx.mock
def test_convenience_methods_sync():
    client = PipeClient(api_key="test", base_url="https://mock-api.com")
    # Mock /pipe for all
    respx.post("https://mock-api.com/pipe/").mock(
        return_value=httpx.Response(
            200, json={"status": "success", "data": {"title": "Title"}, "usage": {}}
        )
    )

    client.article("http://test.com")
    with pytest.raises(NotImplementedError):
        client.product("http://test.com")
    with pytest.raises(NotImplementedError):
        client.serp("http://test.com")


@pytest.mark.asyncio
@respx.mock
async def test_convenience_methods_async():
    async with AsyncPipeClient(
        api_key="test", base_url="https://mock-api.com"
    ) as client:
        respx.post("https://mock-api.com/pipe/").mock(
            return_value=httpx.Response(
                200, json={"status": "success", "data": {"title": "Title"}, "usage": {}}
            )
        )

        await client.article("http://test.com")
        with pytest.raises(NotImplementedError):
            await client.product("http://test.com")
        with pytest.raises(NotImplementedError):
            await client.serp("http://test.com")


@pytest.mark.asyncio
@respx.mock
async def test_async_get_stored_html_decompression():
    async with AsyncPipeClient(api_key="test") as client:
        content = b"<html>hello</html>"
        gzipped = gzip.compress(content)

        respx.get("https://storage.com/file.gz").mock(
            return_value=httpx.Response(200, content=gzipped)
        )

        html = await client.get_stored_html("https://storage.com/file.gz")
        assert html == "<html>hello</html>"


@respx.mock
def test_farm_harvest_with_progress():
    client = PipeClient(api_key="test", base_url="https://mock-api.com")
    respx.post("https://mock-api.com/map/").mock(
        return_value=httpx.Response(200, json={"urls": ["http://a.com"], "total": 1})
    )
    respx.post("https://mock-api.com/pipe/").mock(
        return_value=httpx.Response(
            200, json={"status": "success", "data": {}, "usage": {}}
        )
    )

    # Test with progress bar
    list(client.farm(["http://a.com"], show_progress=True))
    list(client.harvest("http://seed.com", show_progress=True))


@pytest.mark.asyncio
@respx.mock
async def test_async_client_methods_coverage():
    async with AsyncPipeClient(
        api_key="test", base_url="https://mock-api.com"
    ) as client:
        # fetch
        respx.post("https://mock-api.com/fetch/").mock(
            return_value=httpx.Response(
                200, json={"job_id": "j1", "url": "h://u", "usage": {}}
            )
        )
        await client.fetch("h://u")

        # engine
        respx.post("https://mock-api.com/engine/").mock(
            return_value=httpx.Response(200, json={"data": {}, "usage": {}})
        )
        await client.engine("h://u", {}, "<html></html>")

        # extract
        respx.post("https://mock-api.com/extract/").mock(
            return_value=httpx.Response(
                200, json={"status": "success", "data": {}, "usage": {}}
            )
        )
        await client.extract("h://u", {})

        # map/rss/sitemap
        respx.post("https://mock-api.com/map/").mock(
            return_value=httpx.Response(200, json={"urls": [], "total": 0})
        )
        respx.post("https://mock-api.com/map/rss/").mock(
            return_value=httpx.Response(200, json=[])
        )
        respx.post("https://mock-api.com/map/sitemap/").mock(
            return_value=httpx.Response(200, json=[])
        )
        await client.map("h://u")
        await client.rss("h://u")
        await client.sitemap("h://u")

        # markdown/csv/csv_batch
        respx.post("https://mock-api.com/markdown/").mock(
            return_value=httpx.Response(
                200, json={"data": {"markdown": ""}, "usage": {}}
            )
        )
        respx.post("https://mock-api.com/markdown/csv/").mock(
            return_value=httpx.Response(
                200, json={"data": {"markdown": "", "rows": 0}, "usage": {}}
            )
        )
        respx.post("https://mock-api.com/markdown/csv/batch/").mock(
            return_value=httpx.Response(
                200, json={"data": {"results": [], "count": 0}, "usage": {}}
            )
        )
        await client.markdown("<html></html>")
        await client.csv("a,b")
        await client.csv_batch(["a,b"])

        # validate
        respx.post("https://mock-api.com/validate/").mock(
            return_value=httpx.Response(200, json={}, headers={"X-Credits": "1"})
        )
        await client.validate("div")


@pytest.mark.asyncio
@respx.mock
async def test_async_farm_harvest_with_progress():
    async with AsyncPipeClient(
        api_key="test", base_url="https://mock-api.com"
    ) as client:
        respx.post("https://mock-api.com/map/").mock(
            return_value=httpx.Response(
                200, json={"urls": ["http://a.com"], "total": 1}
            )
        )
        respx.post("https://mock-api.com/pipe/").mock(
            return_value=httpx.Response(
                200, json={"status": "success", "data": {}, "usage": {}}
            )
        )

        results = []
        async for res in client.farm(["http://a.com"], show_progress=True):
            results.append(res)
        assert len(results) == 1

        results = []
        async for res in client.harvest("http://seed.com", show_progress=True):
            results.append(res)
        assert len(results) == 1


@pytest.mark.asyncio
@respx.mock
async def test_async_retry_logic():
    async with AsyncPipeClient(
        api_key="test_key", max_retries=2, base_url="https://mock-api.com"
    ) as client:
        route = respx.get("https://mock-api.com/health")
        route.side_effect = [
            httpx.Response(500),
            httpx.Response(200, json={"status": "ok"}),
        ]
        assert await client.health() == {"status": "ok"}
        assert route.call_count == 2


@pytest.mark.asyncio
@respx.mock
async def test_async_error_handling():
    async with AsyncPipeClient(
        api_key="test_key", max_retries=1, base_url="https://mock-api.com"
    ) as client:
        respx.get("https://mock-api.com/health").mock(
            return_value=httpx.Response(400, text="Bad Request")
        )

        with pytest.raises(PipeHTTPError) as exc:
            await client.health()
        assert exc.value.status_code == 400
