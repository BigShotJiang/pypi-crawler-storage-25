from __future__ import annotations


from markdownpipe.enums import (
    JobStatus,
    PipeMode,
    PipeNamespace,
    PipeOutputFormat,
    ResponseStatus,
)


def test_response_status_values():
    assert ResponseStatus.SUCCESS == "success"
    assert ResponseStatus.ERROR == "error"


def test_pipe_mode_values():
    assert PipeMode.MAP == "map"
    assert PipeMode.RSS == "rss"
    assert PipeMode.SITEMAP == "sitemap"


def test_job_status_values():
    assert JobStatus.PENDING == "pending"
    assert JobStatus.SUCCESS == "success"
    assert JobStatus.FAILURE == "failure"


def test_pipe_namespace_values():
    assert PipeNamespace.ARTICLE == "article"
    assert PipeNamespace.PRODUCT == "product"
    assert PipeNamespace.SERP == "serp"


def test_pipe_output_format_values():
    assert PipeOutputFormat.HTML == "html"
    assert PipeOutputFormat.MARKDOWN == "markdown"
    assert PipeOutputFormat.TEXT == "text"


def test_enum_string_comparison():
    """Enums as StrEnum should compare directly with plain strings."""
    status = "success"
    assert ResponseStatus.SUCCESS == status
    assert status == ResponseStatus.SUCCESS


def test_enum_membership():
    """Should be able to check membership using standard in operator."""
    assert (
        "success" in ResponseStatus.__members__.values()
        or ResponseStatus.SUCCESS == "success"
    )
    assert (
        "error" in ResponseStatus.__members__.values()
        or ResponseStatus.ERROR == "error"
    )
