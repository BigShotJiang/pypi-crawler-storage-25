"""Tests for API error envelope parsing."""

from __future__ import annotations

from markdownpipe.exceptions import (
    human_message_from_error_body,
    parse_pipe_api_error,
)


def test_http_error_envelope_message():
    assert (
        human_message_from_error_body(
            {"status": "error", "message": "Unsafe URL"}
        )
        == "Unsafe URL"
    )


def test_detail_string_like_csv():
    assert human_message_from_error_body({"detail": "bad csv"}) == "bad csv"


def test_detail_empty_list():
    msg = human_message_from_error_body({"detail": []})
    assert msg == "Validation error"


def test_detail_pydantic_style_list():
    body = {
        "detail": [
            {
                "type": "missing",
                "loc": ["body", "file"],
                "msg": "Field required",
            }
        ]
    }
    msg = human_message_from_error_body(body)
    assert "required" in msg.lower() or "file" in msg


def test_multipart_field_file():
    msg = human_message_from_error_body({"file": "Only PDF files are supported."})
    assert "PDF" in msg


def test_parse_pipe_api_error_returns_body():
    m, body = parse_pipe_api_error({"detail": [{"msg": "x"}], "extra": 1})
    assert body is not None
    assert "extra" in body
    assert m
