from markdownpipe import Q, QueryAST


def test_q_all_methods():
    # Test all filters and rules in Q for coverage
    q = (
        Q("div")
        .not_(".special")
        .contains("text")
        .icontains("Case")
        .matches(r"\d+")
        .near("header")
        .descendant("span")
        .semantic("price")
        .parent()
        .children()
        .closest("section")
        .ancestor(3)
        .next(2)
        .prev(1)
        .inner_html()
        .outer_html()
        .markdown(commonmark=False)
        .redact("email")
        .csv()
        .slice(1, 10)
        .split(",", 1)
        .replace_regex(r"\s+", " ")
        .build()
    )
    assert isinstance(q, QueryAST)


def test_q_fallback_edge_cases():
    # current_expr is list
    q = Q(["a", "b"]) | "c"
    assert q._selector.expr == ["a", "b", "c"]

    # other is Q with list expr
    q2 = Q("a") | Q(["b", "c"])
    assert q2._selector.expr == ["a", "b", "c"]


def test_q_init_default():
    q = Q()
    assert q._selector.expr == ""
