"""pytest plugin for mcp-assert."""

__version__ = "0.6.0"
