# phalanx

> **Namespace placeholder.**
> This package exists to reserve the `phalanx` name on PyPI.
> It is not installable or usable.

---

## Active package

Install the active development package instead:

```
pip install thephalanx  # this is the package
```

---

## About Phalanx

Phalanx is a forensic PDF analysis tool for Windows.
It detects fake files, metadata anomalies, creation tool fingerprints,
redaction failures, hidden content, and JavaScript payloads in PDF documents.
Produces s.147 Evidence Act 1995 (Cth) compliant certificates.
Available in a free public tier and a licensed forensic tier.

Developed by [Strategos](https://strategos.au).

---

*© 2026 Strategos. All rights reserved.*
*Aut Viam Inveniam Aut Faciam*
