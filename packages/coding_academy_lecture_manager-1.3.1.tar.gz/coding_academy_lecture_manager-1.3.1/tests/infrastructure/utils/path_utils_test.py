from pathlib import Path

from clm.core.course_spec import OutputTargetSpec
from clm.core.output_target import OutputTarget
from clm.infrastructure.utils.path_utils import (
    SKIP_DIRS_FOR_OUTPUT,
    SKIP_OUTPUT_FILE_GLOBS,
    SKIP_OUTPUT_FILE_PATTERNS,
    Format,
    Kind,
    Lang,
    ext_for,
    is_ignored_file_for_output,
    is_slides_file,
    output_path_for,
    output_specs,
    simplify_ordered_name,
)


def test_is_slides_file():
    assert is_slides_file(Path("slides_1.py"))
    assert is_slides_file(Path("slides_2.cpp"))
    assert is_slides_file(Path("slides_3.md"))
    assert not is_slides_file(Path("slides4.py"))
    assert not is_slides_file(Path("test.py"))


def test_is_slides_file_project_prefix():
    assert is_slides_file(Path("project_setup.md"))
    assert is_slides_file(Path("project_phase_01.py"))
    assert not is_slides_file(Path("project_readme.txt"))


def test_output_spec(course_1):
    unit = list(output_specs(course_1, Path("slides_1.py")))
    # 3 formats × 4 kinds × 2 languages = 24 outputs
    assert len(unit) == 24

    # Half the outputs should be in each language.
    assert len([os for os in unit if os.language == Lang.DE]) == 12
    assert len([os for os in unit if os.language == Lang.EN]) == 12

    # We generate HTML, notebook, and code files for each language and kind.
    assert len([os for os in unit if os.format == Format.HTML]) == 8
    assert len([os for os in unit if os.format == Format.NOTEBOOK]) == 8
    assert len([os for os in unit if os.format == Format.CODE]) == 8

    # Each kind has 3 formats × 2 languages = 6 outputs
    assert len([os for os in unit if os.kind == Kind.CODE_ALONG]) == 6
    assert len([os for os in unit if os.kind == Kind.COMPLETED]) == 6
    assert len([os for os in unit if os.kind == Kind.SPEAKER]) == 6
    assert len([os for os in unit if os.kind == Kind.PARTIAL]) == 6

    os1 = unit[0]
    assert os1.language == Lang.DE
    assert os1.format == Format.HTML
    assert os1.kind == Kind.CODE_ALONG


def test_simplify_ordered_name():
    assert simplify_ordered_name("topic_100_abc_def") == "abc_def"
    assert simplify_ordered_name("topic_100_abc_def.py") == "abc_def"


def test_ext_for_python():
    assert ext_for("html", "python") == ".html"
    assert ext_for("notebook", "python") == ".ipynb"
    assert ext_for("code", "python") == ".py"


def test_ext_for_cpp():
    assert ext_for("html", "cpp") == ".html"
    assert ext_for("notebook", "cpp") == ".ipynb"
    assert ext_for("code", "cpp") == ".cpp"


def test_ext_for_typescript():
    assert ext_for("html", "typescript") == ".html"
    assert ext_for("notebook", "typescript") == ".ipynb"
    assert ext_for("code", "typescript") == ".ts"


# Tests for output_specs filtering


def test_output_specs_single_language_de(course_1):
    """Test that output_specs filters to only German when languages=['de']."""
    unit = list(output_specs(course_1, Path("slides_1.py"), languages=["de"]))

    # Should have 12 outputs (3 formats × 4 kinds × 1 language)
    assert len(unit) == 12

    # All outputs should be in German
    assert all(os.language == Lang.DE for os in unit)
    assert len([os for os in unit if os.language == Lang.EN]) == 0

    # Should still have all formats and kinds for German
    assert len([os for os in unit if os.format == Format.HTML]) == 4
    assert len([os for os in unit if os.format == Format.NOTEBOOK]) == 4
    assert len([os for os in unit if os.format == Format.CODE]) == 4

    assert len([os for os in unit if os.kind == Kind.CODE_ALONG]) == 3
    assert len([os for os in unit if os.kind == Kind.COMPLETED]) == 3
    assert len([os for os in unit if os.kind == Kind.SPEAKER]) == 3
    assert len([os for os in unit if os.kind == Kind.PARTIAL]) == 3


def test_output_specs_single_language_en(course_1):
    """Test that output_specs filters to only English when languages=['en']."""
    unit = list(output_specs(course_1, Path("slides_1.py"), languages=["en"]))

    # Should have 12 outputs (3 formats × 4 kinds × 1 language)
    assert len(unit) == 12

    # All outputs should be in English
    assert all(os.language == Lang.EN for os in unit)
    assert len([os for os in unit if os.language == Lang.DE]) == 0


def test_output_specs_speaker_only(course_1):
    """Test that output_specs generates only speaker outputs when kinds=['speaker']."""
    unit = list(output_specs(course_1, Path("slides_1.py"), kinds=["speaker"]))

    # Should have 6 speaker outputs (3 formats × 2 languages)
    assert len(unit) == 6

    # All outputs should be speaker kind
    assert all(os.kind == Kind.SPEAKER for os in unit)

    # Should have both languages
    assert len([os for os in unit if os.language == Lang.DE]) == 3
    assert len([os for os in unit if os.language == Lang.EN]) == 3

    # Should have all formats including code
    assert len([os for os in unit if os.format == Format.HTML]) == 2
    assert len([os for os in unit if os.format == Format.NOTEBOOK]) == 2
    assert len([os for os in unit if os.format == Format.CODE]) == 2


def test_output_specs_speaker_only_single_language(course_1):
    """Test combining speaker-only with single language filter."""
    unit = list(output_specs(course_1, Path("slides_1.py"), languages=["en"], kinds=["speaker"]))

    # Should have 3 outputs (3 formats × 1 language)
    assert len(unit) == 3

    # All outputs should be English and speaker
    assert all(os.language == Lang.EN for os in unit)
    assert all(os.kind == Kind.SPEAKER for os in unit)

    # Should have all formats
    assert len([os for os in unit if os.format == Format.HTML]) == 1
    assert len([os for os in unit if os.format == Format.NOTEBOOK]) == 1
    assert len([os for os in unit if os.format == Format.CODE]) == 1


def test_output_specs_completed_only(course_1):
    """Test filtering to only completed outputs."""
    unit = list(output_specs(course_1, Path("slides_1.py"), kinds=["completed"]))

    # 2 languages x (2 HTML/notebook + 1 code) = 6 outputs
    assert len(unit) == 6

    # All outputs should be completed
    assert all(os.kind == Kind.COMPLETED for os in unit)

    # Should have code outputs
    assert len([os for os in unit if os.format == Format.CODE]) == 2


def test_output_specs_code_along_only(course_1):
    """Test filtering to only code-along outputs."""
    unit = list(output_specs(course_1, Path("slides_1.py"), kinds=["code-along"]))

    # 3 formats × 2 languages = 6 outputs
    assert len(unit) == 6

    # All outputs should be code-along
    assert all(os.kind == Kind.CODE_ALONG for os in unit)

    # Code format is now generated for all kinds
    assert len([os for os in unit if os.format == Format.CODE]) == 2


def test_output_specs_multiple_kinds(course_1):
    """Test filtering to multiple specific kinds."""
    unit = list(output_specs(course_1, Path("slides_1.py"), kinds=["code-along", "completed"]))

    # 3 formats × 2 kinds × 2 languages = 12 outputs
    assert len(unit) == 12

    # Should have code-along and completed but not speaker
    assert len([os for os in unit if os.kind == Kind.CODE_ALONG]) == 6
    assert len([os for os in unit if os.kind == Kind.COMPLETED]) == 6
    assert len([os for os in unit if os.kind == Kind.SPEAKER]) == 0


def test_output_specs_with_skip_html_and_filters(course_1):
    """Test that skip_html works together with language and kinds filters."""
    unit = list(
        output_specs(
            course_1,
            Path("slides_1.py"),
            skip_html=True,
            languages=["de"],
            kinds=["speaker"],
        )
    )

    # Should have 2 outputs (1 language × 2 formats: notebook and code)
    assert len(unit) == 2

    # All outputs should be German and speaker
    assert all(os.language == Lang.DE for os in unit)
    assert all(os.kind == Kind.SPEAKER for os in unit)

    # Should have notebook and code formats, but no HTML
    assert len([os for os in unit if os.format == Format.NOTEBOOK]) == 1
    assert len([os for os in unit if os.format == Format.CODE]) == 1
    assert len([os for os in unit if os.format == Format.HTML]) == 0


# Tests for output_path_for with skip_toplevel


class TestOutputPathFor:
    """Tests for output_path_for function and skip_toplevel parameter."""

    def test_output_path_for_default_includes_public(self, tmp_path):
        """Test that by default, public output includes 'public' in path."""
        path = output_path_for(tmp_path, is_speaker=False, lang="de", dir_name="my-course-de")

        assert "public" in path.parts
        assert "my-course-de" in path.parts
        assert path == tmp_path / "public" / "my-course-de"

    def test_output_path_for_default_includes_speaker(self, tmp_path):
        """Test that by default, speaker output includes 'speaker' in path."""
        path = output_path_for(tmp_path, is_speaker=True, lang="de", dir_name="my-course-de")

        assert "speaker" in path.parts
        assert "public" not in path.parts
        assert "my-course-de" in path.parts
        assert path == tmp_path / "speaker" / "my-course-de"

    def test_output_path_for_skip_toplevel_excludes_public(self, tmp_path):
        """Test that skip_toplevel=True excludes 'public' from path."""
        path = output_path_for(
            tmp_path, is_speaker=False, lang="de", dir_name="my-course-de", skip_toplevel=True
        )

        assert "public" not in path.parts
        assert "speaker" not in path.parts
        assert "my-course-de" in path.parts
        assert path == tmp_path / "my-course-de"

    def test_output_path_for_skip_toplevel_excludes_speaker(self, tmp_path):
        """Test that skip_toplevel=True excludes 'speaker' from path."""
        path = output_path_for(
            tmp_path, is_speaker=True, lang="de", dir_name="my-course-de", skip_toplevel=True
        )

        assert "speaker" not in path.parts
        assert "public" not in path.parts
        assert "my-course-de" in path.parts
        assert path == tmp_path / "my-course-de"

    def test_output_path_for_both_audiences_same_with_skip_toplevel(self, tmp_path):
        """Test that with skip_toplevel, both audiences produce the same path."""
        public_path = output_path_for(
            tmp_path, is_speaker=False, lang="de", dir_name="my-course-de", skip_toplevel=True
        )
        speaker_path = output_path_for(
            tmp_path, is_speaker=True, lang="de", dir_name="my-course-de", skip_toplevel=True
        )

        # Both paths should be identical when skip_toplevel=True
        assert public_path == speaker_path


class TestOutputSpecsWithExplicitTarget:
    """Tests for output_specs with explicit targets (skip_toplevel behavior)."""

    def test_output_specs_with_explicit_target_skips_toplevel(self, course_1, tmp_path):
        """Test that output_specs with explicit target skips public/speaker directories."""
        # Create an explicit target
        spec = OutputTargetSpec(name="test", path=str(tmp_path / "output"))
        target = OutputTarget.from_spec(spec, tmp_path)
        assert target.is_explicit is True

        # Get output specs with the target
        specs = list(
            output_specs(
                course_1,
                tmp_path / "output",
                languages=["en"],
                kinds=["completed"],
                target=target,
            )
        )

        # All specs should have paths without public/speaker
        for os in specs:
            assert "public" not in str(os.output_dir)
            assert "speaker" not in str(os.output_dir)

    def test_output_specs_with_default_target_includes_toplevel(self, course_1, tmp_path):
        """Test that output_specs with default target includes public/speaker directories."""
        # Create a default (non-explicit) target and apply filters to restrict to completed only
        target = OutputTarget.default_target(tmp_path / "output")
        assert target.is_explicit is False

        # Apply filters to restrict to completed kind only (which uses "public" directory)
        target = target.with_cli_filters(languages=["en"], kinds=["completed"])

        # Get output specs with the target
        specs = list(
            output_specs(
                course_1,
                tmp_path / "output",
                target=target,
            )
        )

        # All specs should have paths with public (completed is public, not speaker)
        for os in specs:
            assert "public" in str(os.output_dir)
            assert "speaker" not in str(os.output_dir)

    def test_output_specs_without_target_includes_toplevel(self, course_1, tmp_path):
        """Test that output_specs without target includes public/speaker directories."""
        # Get output specs without a target
        specs = list(
            output_specs(
                course_1,
                tmp_path / "output",
                languages=["en"],
                kinds=["speaker"],
            )
        )

        # All specs should have paths with speaker
        for os in specs:
            assert "speaker" in str(os.output_dir)


class TestOutputFilePatterns:
    """Ensure HTTP-replay cassettes are excluded from public/speaker output."""

    def test_cassette_dir_in_skip_dirs_for_output(self):
        assert "_cassettes" in SKIP_DIRS_FOR_OUTPUT

    def test_cassette_regex_matches_filename(self):
        names = ["slides_010v.http-cassette.yaml", "notebook.http-cassette.yaml"]
        for name in names:
            assert any(p.match(name) for p in SKIP_OUTPUT_FILE_PATTERNS), name

    def test_cassette_regex_rejects_unrelated_yaml(self):
        assert not any(p.match("config.yaml") for p in SKIP_OUTPUT_FILE_PATTERNS)
        assert not any(p.match("manifest.yml") for p in SKIP_OUTPUT_FILE_PATTERNS)

    def test_cassette_glob_parallels_regex(self):
        # Keep the glob form in sync with the regex form (same files filtered).
        assert "*.http-cassette.yaml" in SKIP_OUTPUT_FILE_GLOBS

    def test_is_ignored_file_for_output_sibling_cassette(self, tmp_path):
        cassette = tmp_path / "slides_010v.http-cassette.yaml"
        cassette.write_text("interactions: []")
        assert is_ignored_file_for_output(cassette)

    def test_is_ignored_file_for_output_nested_cassette(self, tmp_path):
        nested = tmp_path / "_cassettes"
        nested.mkdir()
        cassette = nested / "slides_010v.http-cassette.yaml"
        cassette.write_text("interactions: []")
        # Both the dir membership and the filename pattern catch it;
        # either is sufficient for the predicate.
        assert is_ignored_file_for_output(cassette)

    def test_is_ignored_file_for_output_normal_python_file(self, tmp_path):
        py = tmp_path / "slides_010v.py"
        py.write_text("# ...")
        assert not is_ignored_file_for_output(py)

    def test_is_ignored_file_for_output_keras_suffix(self, tmp_path):
        # SKIP_FILE_SUFFIXES still applies via is_ignored_file_for_course.
        model = tmp_path / "model.keras"
        model.write_text("")
        assert is_ignored_file_for_output(model)
