"""
The `OutputSpec` is passed to the data source/document when it is processed to determine the
output that should be generated.

## Classes

- `OutputSpec`: The abstract base class of all output types.
- `CompletedOutput`: The output type for artefacts that contain all public contents.
- `CodeAlongOutput`: The output type for artefacts meant for live coding or workshops.
- `SpeakerOutput`: Private outputs that are for the speaker/trainer.
- `EditScriptOutput`: Output type that generates an edit script to update from codealong to completed notebook.
"""

import logging
import re
from abc import ABC, abstractmethod
from collections.abc import Iterable

from attr import Factory, define

from .utils.jupyter_utils import (
    Cell,
    get_tags,
    is_cell_included_for_language,
    is_code_cell,
    set_tags,
)
from .utils.prog_lang_utils import jupytext_format_for, suffix_for

# Synthetic tag attached by PartialOutput.annotate_cells() to every cell
# at or after the first ``workshop`` heading. It drives per-cell filter
# decisions and is stripped from output metadata by the notebook processor.
POST_WORKSHOP_TAG = "_post_workshop"


def find_workshop_ranges(cells: Iterable[Cell]) -> list[tuple[int, int]]:
    """Return ``[(start_inclusive, end_exclusive), ...]`` for each workshop.

    A workshop starts at a markdown cell tagged ``workshop`` and ends —
    exclusively — at the next markdown cell tagged ``end-workshop`` or the
    next ``workshop`` markdown cell, or at end-of-notebook. Shared between
    the per-cell filter path (``PartialOutput.annotate_cells``) and the
    Partial HTML cache-reuse post-processor in the notebook processor.
    """
    cells_list = list(cells)
    ranges: list[tuple[int, int]] = []
    open_start: int | None = None
    for i, cell in enumerate(cells_list):
        if cell.get("cell_type") != "markdown":
            continue
        tags = cell.get("metadata", {}).get("tags", [])
        if "workshop" in tags:
            if open_start is not None:
                ranges.append((open_start, i))
            open_start = i
        elif "end-workshop" in tags and open_start is not None:
            ranges.append((open_start, i))
            open_start = None
    if open_start is not None:
        ranges.append((open_start, len(cells_list)))
    return ranges


def _is_in_workshop(idx: int, ranges: Iterable[tuple[int, int]]) -> bool:
    return any(start <= idx < end for start, end in ranges)


@define
class OutputSpec(ABC):
    """Description of the kind of output that should be created.

    Outputs can either be public or private.  In public data_sinks some data is not
    included, e.g., speaker notes. Private data_sinks can potentially contain all
    data.

    ## Methods:

    - `is_cell_included()`: Returns whether a cell should be included in the output.
    - `is_cell_contents_included()`: Returns whether the contents of a cell should be
      included or cleared.

    ## Properties:

    - `file_suffix`: The suffix of a file generated with this spec. Derived from the
      notebook format.

    ## Attributes:
    - `lang`: The language of the output document.
    - `format`: The format in which notebooks should be output.
    - `path_fragment`: A directory fragment that can be inserted into the output
      path.
    - `tags_to_delete_cell`: If any of these tags is on a cell it is completely deleted
      from the output.
    - `delete_tags`: If true, the tags of the cell are deleted in the output.

    ## Caching Attributes (for reducing redundant notebook execution):
    - `should_cache_execution`: If True, cache the executed notebook for reuse.
    - `can_reuse_execution`: If True, try to reuse a cached executed notebook.
    """

    language: str = "en"
    """The desired language of the output."""

    prog_lang: str = "python"
    """The programming language of the notebook."""

    format: str = "code"
    """The format for the generated notebooks."""

    tags_to_delete_cell = {"del", "start"}
    """Tags that cause the whole cell to be deleted."""

    delete_any_cell_contents = False
    """Whether we want to delete the contents of any cell."""

    tags_to_retain_code_cell_contents: set[str] = set()
    """Contents of cells with these tags is retained even if we delete cell contents."""

    tags_to_delete_markdown_cell_contents: set[str] = set()
    """Markdown cells with these tags are cleared if we delete cell contents."""

    delete_tags_in_output = False
    """Whether we want to delete the tags of the cell in the output."""

    evaluate_for_html = False
    """Whether we want to evaluate the notebook before generating HTML."""

    _suffix_re = re.compile(r"([^:]*)(:.*)?")
    """Regular expression to extract the file extension from a jupytext format."""

    @property
    def should_cache_execution(self) -> bool:
        """Whether this spec should cache its executed notebook for reuse by others.

        Only Speaker HTML should cache, since Completed HTML can reuse Speaker's
        executed notebook by filtering out "notes" cells.

        Returns:
            True if the executed notebook should be cached.
        """
        return False

    @property
    def can_reuse_execution(self) -> bool:
        """Whether this spec can reuse a cached executed notebook.

        Completed HTML reuses Speaker's cached notebook (same content minus
        ``notes``/``voiceover`` cells). Partial HTML also reuses it via a
        dedicated post-processing step that blanks post-workshop cells.

        Returns:
            True if a cached executed notebook can be reused.
        """
        return False

    @abstractmethod
    def get_target_subdir_fragment(self) -> str:
        """Return the subdirectory fragment for the target directory."""
        ...

    def annotate_cells(self, cells: Iterable[Cell]) -> None:
        """Optional pre-pass hook invoked before per-cell filtering.

        The default is a no-op. Specs that need to make filtering decisions
        based on a cell's position within the notebook (e.g. ``PartialOutput``)
        can override this to attach synthetic tags in a single pass. The
        notebook processor is responsible for stripping any synthetic tags
        from the output.
        """
        return None

    @property
    def path_fragment(self):
        return f"{self.language}/{self.format}/{self.get_target_subdir_fragment()}"

    @property
    def file_suffix(self):
        """Return the file suffix for the spec's notebook format.

        >>> os = SpeakerOutput(format="notebook")
        >>> os.file_suffix
        'ipynb'

        >>> os = SpeakerOutput(format="code")
        >>> os.file_suffix
        'py'

        >>> os = SpeakerOutput(format="html")
        >>> os.file_suffix
        'html'
        """
        match self.format:
            case "notebook":
                return ".ipynb"
            case "html":
                return ".html"
            case "code":
                return suffix_for(self.prog_lang)
            case "edit_script":
                return ".ahk"
            case _:
                raise ValueError(f"Could not extract file suffix from format {self.format}.")

    @property
    def jupytext_format(self):
        """Return the jupytext format for the spec's notebook format.

        >>> os = SpeakerOutput(format="notebook")
        >>> os.jupytext_format
        'ipynb'

        >>> os = SpeakerOutput(format="code")
        >>> os.jupytext_format
        'py:light'

        >>> os = SpeakerOutput(format="html")
        >>> os.jupytext_format
        'html'
        """
        match self.format:
            case "notebook":
                return "ipynb"
            case "html":
                return "html"
            case "code":
                return jupytext_format_for(self.prog_lang)
            case "edit_script":
                return "py:percent"
            case _:
                raise ValueError(f"Could not extract jupytext format from format {self.format}.")

    def is_cell_included(self, cell: Cell) -> bool:
        """Return whether the cell should be included or completely removed.

        If this method returns false the complete cell is removed from the
        output. This is used to, e.g., remove speaker notes or alternate
        solutions from public data_sinks.
        """
        tags_to_delete = self.tags_to_delete_cell.intersection(get_tags(cell))
        if tags_to_delete:
            # logging.debug(
            #     f"Deleting cell '{cell.source[:20]}' because of tags {tags_to_delete}"
            # )
            return False
        return is_cell_included_for_language(cell, self.language)

    def is_cell_contents_included(self, cell: Cell) -> bool:
        """Return whether the cell contents should be included or cleared.

        If this method returns false the contents of the cell is cleared, the
        cell itself is still included. This is used to, e.g., remove code from
        most code cells in codealong notebooks.
        """
        if self.delete_any_cell_contents:
            if is_code_cell(cell):
                tags_to_retain = self.tags_to_retain_code_cell_contents.intersection(get_tags(cell))
                if tags_to_retain:
                    logging.debug(
                        f"Retaining code cell '{cell.source[:20]}' because of tags {tags_to_retain}"
                    )
                    return True
                else:
                    return False
            else:
                tags_to_delete = self.tags_to_delete_markdown_cell_contents.intersection(
                    get_tags(cell)
                )
                if tags_to_delete:
                    logging.debug(
                        f"Deleting markdown cell '{cell.source[:20]}' because of tags {tags_to_delete}"
                    )
                    return False
                else:
                    return True
        else:
            return True


@define
class CompletedOutput(OutputSpec):
    """Output spec for data_sources containing all data shared with the public.

    This means they contain everything except speaker notes.
    """

    def get_target_subdir_fragment(self) -> str:
        return "completed"

    tags_to_delete_cell = {"del", "notes", "voiceover", "start"}
    """Tags that cause the whole cell to be deleted."""

    evaluate_for_html = True
    """We want to evaluate completed notebooks before generating HTML."""

    @property
    def can_reuse_execution(self) -> bool:
        """Completed HTML can reuse Speaker's cached executed notebook.

        Completed is a subset of Speaker (same content minus "notes" cells),
        so we can reuse the executed notebook by filtering out "notes" cells
        after execution.

        Only applies to HTML format where evaluation is needed.
        """
        return self.format == "html" and self.evaluate_for_html


@define
class CodeAlongOutput(OutputSpec):
    """Output spec for public data_sources that can be completed during the course.

    Only code cells marked with the "keep" tag have contents in them, all other
    code cells are empty.
    """

    def get_target_subdir_fragment(self) -> str:
        return "code_along"

    tags_to_delete_cell = {"alt", "completed", "del", "notes", "voiceover"}
    """Tags that cause the whole cell to be deleted."""

    delete_any_cell_contents = True

    tags_to_retain_code_cell_contents: set[str] = Factory(lambda: {"keep", "start"})
    """Contents of cells with these tags is retained even if we delete cell contents."""

    tags_to_delete_markdown_cell_contents: set[str] = Factory(lambda: {"answer"})
    """Markdown cells with these tags are cleared if we delete cell contents."""


@define
class SpeakerOutput(OutputSpec):
    """Output spec for data_sources containing all public and private data."""

    def get_target_subdir_fragment(self) -> str:
        return "speaker"

    tags_to_delete_cell = {"del", "start"}
    """Tags that cause the whole cell to be deleted."""

    evaluate_for_html = True
    """If we generate HTML for speakers we want to evaluate code cells."""

    @property
    def should_cache_execution(self) -> bool:
        """Speaker HTML should cache its executed notebook.

        The cached executed notebook can be reused by Completed HTML, which
        only needs to filter out "notes" cells from the Speaker's output.

        Only applies to HTML format where evaluation is needed.
        """
        return self.format == "html" and self.evaluate_for_html


@define
class PartialOutput(OutputSpec):
    """Output spec that is completed outside workshop ranges and
    code-along inside them.

    The kind is intended for students to follow demonstrations with the
    instructor's worked code in place, while workshop exercises remain
    blank for them to complete. A workshop range starts at a markdown
    cell tagged ``workshop`` and ends at the next ``end-workshop``
    markdown cell (exclusive), the next ``workshop`` heading, or
    end-of-notebook — whichever comes first. Cells inside any workshop
    range are treated as code-along; everything else is completed.
    """

    def get_target_subdir_fragment(self) -> str:
        return "partial"

    # Pre-workshop cell deletions mirror CompletedOutput.
    _pre_delete_cell: frozenset[str] = frozenset({"del", "notes", "voiceover", "start"})
    # Post-workshop cell deletions mirror CodeAlongOutput.
    _post_delete_cell: frozenset[str] = frozenset({"alt", "completed", "del", "notes", "voiceover"})
    # Post-workshop content retention mirrors CodeAlongOutput.
    _post_retain_code: frozenset[str] = frozenset({"keep", "start"})
    _post_delete_markdown: frozenset[str] = frozenset({"answer"})

    evaluate_for_html = False
    """Partial never executes on its own. Pre-workshop outputs come from
    Speaker's cached executed notebook (reused via :meth:`can_reuse_execution`),
    and post-workshop cells are blanked with outputs cleared in the
    post-processing step in
    :meth:`NotebookProcessor._filter_cached_notebook_for_partial`.

    Setting this to ``False`` also makes the cache-miss fallback safe:
    ``_create_using_nbconvert`` skips execution, so no workshop code can
    run and the NameErrors observed when ``keep`` post-workshop cells
    reference symbols defined in blanked non-``keep`` cells are impossible.
    """

    @property
    def can_reuse_execution(self) -> bool:
        """Partial HTML reuses Speaker's cached executed notebook.

        Pre-workshop cells of Partial match Completed (a subset of Speaker),
        so they can be taken verbatim from the cache. Post-workshop cells
        are filtered and blanked in a dedicated post-processing pass by
        :meth:`NotebookProcessor._filter_cached_notebook_for_partial`.

        Reuse is independent of :attr:`evaluate_for_html` because the
        post-processing step does not require execution.
        """
        return self.format == "html"

    def annotate_cells(self, cells: Iterable[Cell]) -> None:
        """Tag every cell that falls inside a workshop range."""
        cells_list = list(cells)
        ranges = find_workshop_ranges(cells_list)
        if not ranges:
            return
        for start, end in ranges:
            for cell in cells_list[start:end]:
                tags = list(get_tags(cell))
                if POST_WORKSHOP_TAG not in tags:
                    tags.append(POST_WORKSHOP_TAG)
                    set_tags(cell, tags)

    @staticmethod
    def _is_post_workshop(cell: Cell) -> bool:
        return POST_WORKSHOP_TAG in get_tags(cell)

    def is_cell_included(self, cell: Cell) -> bool:
        tags = get_tags(cell)
        tags_to_delete = (
            self._post_delete_cell if self._is_post_workshop(cell) else self._pre_delete_cell
        )
        if tags_to_delete.intersection(tags):
            return False
        return is_cell_included_for_language(cell, self.language)

    def is_cell_contents_included(self, cell: Cell) -> bool:
        if not self._is_post_workshop(cell):
            return True
        if is_code_cell(cell):
            return bool(self._post_retain_code.intersection(get_tags(cell)))
        return not self._post_delete_markdown.intersection(get_tags(cell))


def create_output_spec(kind: str, *args, **kwargs) -> OutputSpec:
    """Create a spec given a name and init data.

    >>> create_output_spec("completed", "de", "public", "De", "py")
    CompletedOutput(language='de', target_root_fragment='public',
                    get_target_subdir_fragment='De', format='py')
    >>> create_output_spec("CodeAlong")
    CodeAlongOutput(language='en', target_root_fragment='',
                    get_target_subdir_fragment='', format='ipynb')
    >>> create_output_spec('speaker')
    SpeakerOutput(language='en', target_root_fragment='',
                  get_target_subdir_fragment='', format='ipynb')
    >>> create_output_spec('MySpecialSpec')
    Traceback (most recent call last):
    ...
    ValueError: Unknown spec type: 'MySpecialSpec'.
    Valid spec types are 'completed', 'codealong' or 'speaker'.
    """
    spec_type: (
        type[CompletedOutput] | type[CodeAlongOutput] | type[SpeakerOutput] | type[PartialOutput]
    )
    match kind.lower():
        case "completed":
            spec_type = CompletedOutput
        case "code-along":
            spec_type = CodeAlongOutput
        case "speaker":
            spec_type = SpeakerOutput
        case "partial":
            spec_type = PartialOutput
        case _:
            raise ValueError(
                f"Unknown spec type: {kind!r}.\n"
                "Valid spec types are 'completed', 'code-along', 'speaker' or 'partial'."
            )
    spec = spec_type(*args, **kwargs)
    return spec


def create_output_specs(
    prog_lang="python",
    languages=("de", "en"),
    formats=("notebook", "code", "html"),
    kinds=("completed", "code-along", "speaker", "partial"),
):
    result = []
    for lang in languages:
        for format_ in formats:
            for kind in kinds:
                result.append(
                    create_output_spec(
                        kind=kind,
                        language=lang,
                        format=format_,
                        prog_lang=prog_lang,
                    )
                )
    return result
