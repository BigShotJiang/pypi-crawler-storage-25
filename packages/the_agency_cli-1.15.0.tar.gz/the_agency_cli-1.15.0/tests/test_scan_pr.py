from pathlib import Path
from unittest.mock import Mock

import importlib.util


def _load_scan_pr():
    module_path = Path(__file__).resolve().parents[1] / "scripts" / "scan_pr.py"
    spec = importlib.util.spec_from_file_location("scan_pr", module_path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


def test_scan_file_uses_detect_endpoint_first(tmp_path, monkeypatch):
    scan_pr = _load_scan_pr()
    target = tmp_path / "skills" / "demo" / "SKILL.md"
    target.parent.mkdir(parents=True)
    target.write_text("safe content", encoding="utf-8")

    response = Mock(status_code=200)
    response.json.return_value = {"status": "safe", "score": 0.1}

    post_calls = []

    def fake_post(url, timeout, **kwargs):
        post_calls.append((url, timeout, kwargs))
        return response

    monkeypatch.setattr(scan_pr.requests, "post", fake_post)

    assert scan_pr.scan_file(str(target)) is True
    assert post_calls[0][0] == "http://localhost:8000/detect"
    assert post_calls[0][2]["data"]["prompt"] == "safe content"
    assert post_calls[0][2]["data"]["enhanced"] == "true"


def test_scan_file_falls_back_to_legacy_endpoint(tmp_path, monkeypatch):
    scan_pr = _load_scan_pr()
    target = tmp_path / "skills" / "demo" / "SKILL.md"
    target.parent.mkdir(parents=True)
    target.write_text("fallback content", encoding="utf-8")

    detect_response = Mock(status_code=404, text="not found")
    legacy_response = Mock(status_code=200)
    legacy_response.json.return_value = {"is_malicious": False}
    responses = [detect_response, legacy_response]

    def fake_post(url, timeout, **kwargs):
        return responses.pop(0)

    monkeypatch.setattr(scan_pr.requests, "post", fake_post)

    assert scan_pr.scan_file(str(target)) is True


def test_scan_file_blocks_malicious_response(tmp_path, monkeypatch):
    scan_pr = _load_scan_pr()
    target = tmp_path / "skills" / "demo" / "SKILL.md"
    target.parent.mkdir(parents=True)
    target.write_text("bad content", encoding="utf-8")

    response = Mock(status_code=200)
    response.json.return_value = {
        "status": "blocked",
        "details": "Prompt injection detected in the submitted content.",
    }

    monkeypatch.setattr(scan_pr.requests, "post", lambda url, timeout, **kwargs: response)

    assert scan_pr.scan_file(str(target)) is False
