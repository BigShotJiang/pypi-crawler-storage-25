"""Tests for the M1 agency runtime: blueprint, registry, multiplexer, hire/fire."""

from __future__ import annotations

import json
import concurrent.futures
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

import agency
from blueprints import IT_BLUEPRINT, BLUEPRINTS, DEFAULT_BLUEPRINT, get_blueprint


# Pin the session name so tests don't depend on the test runner's cwd/git state,
# and so mocked subprocess.run calls don't accidentally swallow the internal
# `git rev-parse --git-common-dir` lookup (#73).
@pytest.fixture(autouse=True)
def _pin_session_name(monkeypatch):
    monkeypatch.setattr(agency, "_runtime_session_name", lambda: "agency-testproj")


# ---------------------------------------------------------------------------
# Blueprint
# ---------------------------------------------------------------------------

class TestBlueprint:
    def test_it_blueprint_is_registered_and_default(self):
        assert DEFAULT_BLUEPRINT == "it"
        assert "it" in BLUEPRINTS
        assert BLUEPRINTS["it"] is IT_BLUEPRINT

    def test_it_blueprint_has_expected_roles(self):
        expected = {"chief", "po", "architect", "security", "platform", "dev", "qa"}
        assert set(IT_BLUEPRINT["roles"].keys()) == expected

    def test_platform_role_can_install_collab_bus(self):
        platform = IT_BLUEPRINT["roles"]["platform"]
        assert any(
            "agency collab-bus" in p for p in platform["permissions"]
        ), "platform role must be able to run agency collab-bus"

    def test_every_role_has_required_fields(self):
        for role_name, spec in IT_BLUEPRINT["roles"].items():
            for key in ("skill", "caliber", "description", "reports_to",
                        "permissions", "name_pool", "do", "dont",
                        "refuse_examples"):
                assert key in spec, f"role '{role_name}' missing '{key}'"
            assert isinstance(spec["permissions"], list)
            assert len(spec["permissions"]) > 0
            assert isinstance(spec["name_pool"], list)
            assert len(spec["name_pool"]) >= 6, (
                f"role '{role_name}' name_pool too small for collision safety"
            )
            assert isinstance(spec["do"], list)
            assert isinstance(spec["dont"], list)
            assert len(spec["do"]) >= 2, f"role '{role_name}' has < 2 do rules"
            assert len(spec["dont"]) >= 2, f"role '{role_name}' has < 2 dont rules"
            assert isinstance(spec["refuse_examples"], list)

    def test_chief_has_refuse_examples(self):
        # Chief is the one role most prone to going off-script (reported in
        # real-world testing), so it gets concrete refusal few-shots.
        chief = IT_BLUEPRINT["roles"]["chief"]
        assert len(chief["refuse_examples"]) >= 2
        # Each example is a (request, response) tuple
        for request, response in chief["refuse_examples"]:
            assert isinstance(request, str) and len(request) > 0
            assert isinstance(response, str) and len(response) > 0

    def test_chief_reports_to_nobody(self):
        assert IT_BLUEPRINT["roles"]["chief"]["reports_to"] is None

    def test_non_chief_roles_have_a_manager(self):
        for role_name, spec in IT_BLUEPRINT["roles"].items():
            if role_name == "chief":
                continue
            assert spec["reports_to"] is not None

    def test_get_blueprint_unknown_raises(self):
        with pytest.raises(KeyError):
            get_blueprint("marketing")


# ---------------------------------------------------------------------------
# Platform permission translation
# ---------------------------------------------------------------------------

class TestPlatformPermission:
    def test_passthrough_on_unix(self, monkeypatch):
        monkeypatch.setattr(agency.sys, "platform", "linux")
        assert agency._runtime_platform_permission("Bash(agency hire*)") == "Bash(agency hire*)"

    def test_translates_bash_to_powershell_on_windows(self, monkeypatch):
        monkeypatch.setattr(agency.sys, "platform", "win32")
        assert (
            agency._runtime_platform_permission("Bash(agency hire*)")
            == "PowerShell(agency hire*)"
        )

    def test_passes_non_bash_entries_unchanged_on_windows(self, monkeypatch):
        monkeypatch.setattr(agency.sys, "platform", "win32")
        assert agency._runtime_platform_permission("Read(**)") == "Read(**)"


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

@pytest.fixture
def chdir_tmp(tmp_path, monkeypatch):
    """Run each test in an isolated CWD so .agency/ does not pollute the repo.

    Also initialises a git repo with one commit so that hire_agent() can
    create worktrees (#54).
    """
    monkeypatch.chdir(tmp_path)
    import subprocess
    subprocess.run(["git", "init"], cwd=str(tmp_path), capture_output=True, check=True)
    subprocess.run(
        ["git", "commit", "--allow-empty", "-m", "init"],
        cwd=str(tmp_path), capture_output=True, check=True,
    )
    return tmp_path


class TestRegistry:
    def test_load_empty_registry_when_missing(self, chdir_tmp):
        reg = agency._runtime_load_registry()
        assert reg == {"version": 1, "agents": []}

    def test_save_and_reload_registry(self, chdir_tmp):
        reg = {"version": 1, "agents": [{"id": "po-abc123", "role": "po", "status": "active"}]}
        agency._runtime_save_registry(reg)
        assert agency.RUNTIME_REGISTRY_PATH.exists()
        assert agency._runtime_load_registry() == reg

    def test_corrupt_registry_raises_and_prints_hint(self, chdir_tmp):
        agency.RUNTIME_REGISTRY_PATH.parent.mkdir(parents=True, exist_ok=True)
        agency.RUNTIME_REGISTRY_PATH.write_text("{not json", encoding="utf-8")
        with pytest.raises(json.JSONDecodeError):
            agency._runtime_load_registry()

    def test_find_agent_returns_match_or_none(self):
        reg = {"agents": [{"id": "po-abc"}, {"id": "dev-xyz"}]}
        assert agency._runtime_find_agent(reg, "dev-xyz")["id"] == "dev-xyz"
        assert agency._runtime_find_agent(reg, "missing") is None


class TestAgentId:
    def test_picks_name_from_pool_when_provided(self):
        reg = {"agents": []}
        agent_id, name = agency._runtime_generate_agent_id(
            "chief", reg, ["Margaret", "Victor"]
        )
        assert name in ("Margaret", "Victor")
        assert agent_id == f"chief-{name.lower()}"

    def test_skips_names_already_in_use(self, monkeypatch):
        # Force the shuffle to be deterministic so the assertion is stable.
        monkeypatch.setattr(
            agency.random, "shuffle", lambda lst: None  # no-op, preserves order
        )
        reg = {"agents": [{"id": "chief-margaret"}]}
        agent_id, name = agency._runtime_generate_agent_id(
            "chief", reg, ["Margaret", "Victor"]
        )
        # First name is taken, second should be picked.
        assert name == "Victor"
        assert agent_id == "chief-victor"

    def test_falls_back_to_hex_when_pool_exhausted(self, monkeypatch):
        monkeypatch.setattr(agency.random, "shuffle", lambda lst: None)
        monkeypatch.setattr(agency.secrets, "token_hex", lambda n: "abc123")
        reg = {"agents": [{"id": "chief-margaret"}, {"id": "chief-victor"}]}
        agent_id, name = agency._runtime_generate_agent_id(
            "chief", reg, ["Margaret", "Victor"]
        )
        assert name is None
        assert agent_id == "chief-abc123"

    def test_falls_back_to_hex_when_pool_omitted(self, monkeypatch):
        monkeypatch.setattr(agency.secrets, "token_hex", lambda n: "deadbe")
        agent_id, name = agency._runtime_generate_agent_id("po", {"agents": []})
        assert name is None
        assert agent_id == "po-deadbe"

    def test_hex_fallback_avoids_collisions(self, monkeypatch):
        reg = {"agents": [{"id": "po-aaaaaa"}]}
        values = iter(["aaaaaa", "bbbbbb"])
        monkeypatch.setattr(agency.secrets, "token_hex", lambda n: next(values))
        agent_id, name = agency._runtime_generate_agent_id("po", reg)
        assert agent_id == "po-bbbbbb"
        assert name is None


# ---------------------------------------------------------------------------
# Scaffolding
# ---------------------------------------------------------------------------

class TestScaffold:
    def test_scaffold_creates_expected_files(self, chdir_tmp):
        agent = {
            "id": "dev-abc123",
            "role": "dev",
            "caliber": "senior",
            "session": agency._runtime_session_name(),
            "window": "dev-abc123",
            "mux": "tmux",
            "tmux_window": "agency:dev-abc123",  # legacy display key, read by claude_md
            "hired_at": "2026-04-11T12:00:00Z",
            "hired_by": "human",
        }
        role_spec = IT_BLUEPRINT["roles"]["dev"]

        agent_dir = agency._runtime_scaffold_agent_dir(agent, role_spec, "backend_developer")

        assert (agent_dir / "CLAUDE.md").exists()
        assert (agent_dir / "onboarding.md").exists()
        assert (agent_dir / ".claude" / "settings.json").exists()

        claude_md = (agent_dir / "CLAUDE.md").read_text(encoding="utf-8")
        assert "dev-abc123" in claude_md
        assert "backend_developer" in claude_md
        assert "po" in claude_md  # reports_to

        settings = json.loads((agent_dir / ".claude" / "settings.json").read_text(encoding="utf-8"))
        assert "permissions" in settings
        assert settings["_agency_runtime"]["agent_id"] == "dev-abc123"
        assert any("git" in p for p in settings["permissions"]["allow"])


class TestProjectPermissionMerge:
    def test_creates_fresh_settings_file(self, chdir_tmp):
        agency._runtime_merge_project_permissions(["Bash(git*)"])
        settings = json.loads(Path(".claude/settings.json").read_text())
        assert "Bash(git*)" in settings["permissions"]["allow"]

    def test_merges_into_existing_settings(self, chdir_tmp):
        Path(".claude").mkdir()
        Path(".claude/settings.json").write_text(
            json.dumps({"permissions": {"allow": ["Bash(ls*)"]}})
        )
        agency._runtime_merge_project_permissions(["Bash(git*)"])
        settings = json.loads(Path(".claude/settings.json").read_text())
        assert "Bash(ls*)" in settings["permissions"]["allow"]
        assert "Bash(git*)" in settings["permissions"]["allow"]

    def test_is_idempotent(self, chdir_tmp):
        agency._runtime_merge_project_permissions(["Bash(git*)"])
        agency._runtime_merge_project_permissions(["Bash(git*)"])
        settings = json.loads(Path(".claude/settings.json").read_text())
        assert settings["permissions"]["allow"].count("Bash(git*)") == 1

    def test_bails_on_corrupt_settings_without_raising(self, chdir_tmp, capsys):
        Path(".claude").mkdir()
        Path(".claude/settings.json").write_text("{not json")
        agency._runtime_merge_project_permissions(["Bash(git*)"])
        assert "not valid JSON" in capsys.readouterr().out


# ---------------------------------------------------------------------------
# Multiplexer backend selection
# ---------------------------------------------------------------------------

class TestBackendSelection:
    def test_prefers_tmux_when_both_available(self, monkeypatch):
        monkeypatch.setattr(agency, "_runtime_tmux_available", lambda: True)
        monkeypatch.setattr(agency, "_runtime_screen_available", lambda: True)
        assert agency._runtime_mux_backend() == "tmux"

    def test_falls_back_to_screen_when_only_screen_available(self, monkeypatch):
        monkeypatch.setattr(agency, "_runtime_tmux_available", lambda: False)
        monkeypatch.setattr(agency, "_runtime_screen_available", lambda: True)
        assert agency._runtime_mux_backend() == "screen"

    def test_returns_none_when_neither_available(self, monkeypatch):
        monkeypatch.setattr(agency, "_runtime_tmux_available", lambda: False)
        monkeypatch.setattr(agency, "_runtime_screen_available", lambda: False)
        assert agency._runtime_mux_backend() is None

    def test_mux_available_mirrors_backend(self, monkeypatch):
        monkeypatch.setattr(agency, "_runtime_tmux_available", lambda: False)
        monkeypatch.setattr(agency, "_runtime_screen_available", lambda: False)
        assert agency._runtime_mux_available() is False
        monkeypatch.setattr(agency, "_runtime_screen_available", lambda: True)
        assert agency._runtime_mux_available() is True


# ---------------------------------------------------------------------------
# Screen backend command shape
# ---------------------------------------------------------------------------

class TestScreenBackend:
    def test_session_exists_parses_detached_line(self):
        session = agency._runtime_session_name()
        fake_run = MagicMock()
        fake_run.return_value = MagicMock(stdout=f"\t12345.{session}\t(Detached)\n")
        with patch.object(agency.subprocess, "run", fake_run):
            assert agency._runtime_screen_session_exists() is True

    def test_session_exists_returns_false_when_no_match(self):
        fake_run = MagicMock()
        fake_run.return_value = MagicMock(stdout="\t999.other\t(Detached)\n")
        with patch.object(agency.subprocess, "run", fake_run):
            assert agency._runtime_screen_session_exists() is False

    def test_ensure_session_creates_when_missing(self, tmp_path, monkeypatch):
        monkeypatch.setenv("SHELL", "/bin/zsh")
        calls = []

        def fake_run(args, **kwargs):
            calls.append(args)
            if args[:2] == ["screen", "-list"]:
                return MagicMock(stdout="")
            return MagicMock(returncode=0)

        with patch.object(agency.subprocess, "run", side_effect=fake_run):
            agency._runtime_screen_ensure_session(tmp_path)

        create_call = next(c for c in calls if "-dmS" in c)
        assert create_call[:4] == ["screen", "-dmS", agency._runtime_session_name(), "-t"]
        assert create_call[4] == agency.RUNTIME_SCREEN_CONTROL_WINDOW
        # The wrapper uses the user's shell (from $SHELL) in -c mode
        assert create_call[5] == "/bin/zsh"
        assert create_call[6] == "-c"
        assert "cd " in create_call[7] and str(tmp_path) in create_call[7]
        assert "exec /bin/zsh" in create_call[7]

    def test_ensure_session_skips_when_present(self, tmp_path):
        fake_run = MagicMock()
        fake_run.return_value = MagicMock(stdout=f"\t1.{agency._runtime_session_name()}\t(Detached)\n")
        with patch.object(agency.subprocess, "run", fake_run):
            agency._runtime_screen_ensure_session(tmp_path)
        # Only the list call should have happened — no create.
        assert all("-dmS" not in c.args[0] for c in fake_run.call_args_list)

    def test_spawn_window_wraps_command_with_cwd_and_exec(self, tmp_path, monkeypatch):
        monkeypatch.setenv("SHELL", "/bin/zsh")
        fake_run = MagicMock(return_value=MagicMock(returncode=0))
        with patch.object(agency.subprocess, "run", fake_run):
            agency._runtime_screen_spawn_window("dev-abc", tmp_path, "claude")

        call_args = fake_run.call_args[0][0]
        s = agency._runtime_session_name()
        assert call_args[:6] == ["screen", "-S", s, "-X", "screen", "-t"]
        assert call_args[6] == "dev-abc"
        # Wrapper shell = $SHELL, with -ic so the rc file (.zshrc/.bashrc) is
        # sourced before exec — this is what makes PATH additions (like
        # claude installed by a rc file) visible to the spawned command.
        assert call_args[7] == "/bin/zsh"
        assert call_args[8] == "-ic"
        wrapped = call_args[9]
        assert f"cd {tmp_path}" in wrapped
        assert "&& claude" in wrapped

    def test_user_shell_defaults_to_bash_when_unset(self, monkeypatch):
        monkeypatch.delenv("SHELL", raising=False)
        assert agency._runtime_user_shell() == "/bin/bash"

    def test_user_shell_honors_env(self, monkeypatch):
        monkeypatch.setenv("SHELL", "/usr/local/bin/fish")
        assert agency._runtime_user_shell() == "/usr/local/bin/fish"

    def test_send_keys_splits_text_and_carriage_return(self):
        """send-keys must stuff the text first, pause, then stuff `\\r` alone.
        The combined `text + \\r` form looks equivalent but claude-code v2.1.101
        buffers the blob and treats the embedded CR as part of the text rather
        than a submit keystroke, forcing the user to press Enter manually.
        Splitting into two calls reliably fires the submit.

        DO NOT combine these into a single call — it has been tried twice and
        regressed both times. See agency.py `_runtime_screen_send_keys` for
        history. If the behavior breaks again, bump the submit delay before
        changing the two-call shape.
        """
        fake_run = MagicMock(return_value=MagicMock(returncode=0))
        with patch.object(agency.subprocess, "run", fake_run):
            with patch.object(agency.time, "sleep"):
                agency._runtime_screen_send_keys("dev-abc", "hello")

        assert fake_run.call_count == 2, (
            "send_keys must make two subprocess calls: text, then submit."
        )
        first_call = fake_run.call_args_list[0][0][0]
        second_call = fake_run.call_args_list[1][0][0]
        assert first_call == [
            "screen", "-S", agency._runtime_session_name(), "-p", "dev-abc", "-X", "stuff", "hello"
        ]
        assert second_call == [
            "screen", "-S", agency._runtime_session_name(), "-p", "dev-abc", "-X", "stuff", "\r"
        ]

    def test_kill_window_uses_x_kill(self):
        fake_run = MagicMock(return_value=MagicMock(returncode=0))
        with patch.object(agency.subprocess, "run", fake_run):
            agency._runtime_screen_kill_window("dev-abc")

        call_args = fake_run.call_args[0][0]
        assert call_args == [
            "screen", "-S", agency._runtime_session_name(), "-p", "dev-abc", "-X", "kill"
        ]


# ---------------------------------------------------------------------------
# Attach hint
# ---------------------------------------------------------------------------

class TestAttachHint:
    def test_tmux_hint_uses_session_colon_window(self):
        hint = agency._runtime_mux_attach_hint("dev-abc", backend="tmux")
        s = agency._runtime_session_name()
        assert hint == f"tmux attach -t {s}:dev-abc"

    def test_screen_hint_mentions_ctrl_a(self):
        hint = agency._runtime_mux_attach_hint("dev-abc", backend="screen")
        assert f"screen -r {agency._runtime_session_name()}" in hint
        assert "Ctrl-A" in hint
        assert "dev-abc" in hint

    def test_unknown_backend_returns_fallback(self):
        hint = agency._runtime_mux_attach_hint("dev-abc", backend="zellij")
        assert "no multiplexer" in hint.lower()


# ---------------------------------------------------------------------------
# Hire / fire lifecycle (orchestration)
# ---------------------------------------------------------------------------

@pytest.fixture
def fake_mux(monkeypatch):
    """Stub the multiplexer dispatch layer so lifecycle tests never spawn real processes."""
    calls = {"ensure": 0, "spawn": 0, "send": 0, "kill": 0}

    def _count(key):
        def _f(*args, **kwargs):
            calls[key] += 1
        return _f

    monkeypatch.setattr(agency, "_runtime_mux_backend", lambda: "tmux")
    monkeypatch.setattr(agency, "_runtime_mux_available", lambda: True)
    monkeypatch.setattr(agency, "_runtime_mux_ensure_session", _count("ensure"))
    monkeypatch.setattr(agency, "_runtime_mux_spawn_window", _count("spawn"))
    monkeypatch.setattr(agency, "_runtime_mux_send_keys", _count("send"))
    monkeypatch.setattr(agency, "_runtime_mux_kill_window", _count("kill"))
    monkeypatch.setattr(agency.time, "sleep", lambda _s: None)
    return calls


class TestHireAgent:
    def test_hire_chief_records_backend_window_and_name(self, chdir_tmp, fake_mux):
        agent = agency.hire_agent(role="chief")

        assert agent is not None
        assert agent["role"] == "chief"
        assert agent["skill"] == "project_manager"
        assert agent["caliber"] == "architect"
        assert agent["status"] == "active"
        assert agent["reports_to"] is None
        assert agent["mux"] == "tmux"
        assert agent["session"] == agency._runtime_session_name()
        assert agent["window"].startswith("chief-")
        # A name was picked from the chief name_pool and the id reflects it.
        from blueprints import IT_BLUEPRINT
        assert agent["name"] in IT_BLUEPRINT["roles"]["chief"]["name_pool"]
        assert agent["id"] == f"chief-{agent['name'].lower()}"

        assert fake_mux["ensure"] == 1
        assert fake_mux["spawn"] == 1
        assert fake_mux["send"] == 2  # splash dismiss + onboarding prompt

        reg = agency._runtime_load_registry()
        assert len(reg["agents"]) == 1
        assert reg["agents"][0]["id"] == agent["id"]
        assert reg["agents"][0]["name"] == agent["name"]
        assert Path(agent["agent_dir"]).exists()

        # CLAUDE.md references the display name.
        claude_md = (Path(agent["agent_dir"]) / "CLAUDE.md").read_text()
        assert agent["name"] in claude_md
        assert "**Name:**" in claude_md

        # Onboarding uses the new natural-greeting format, not a status dump.
        onboarding = (Path(agent["agent_dir"]) / "onboarding.md").read_text()
        assert f"running as {agent['name']}" in onboarding
        assert "Greet the human" in onboarding
        # Good/bad examples are in there as few-shots
        assert "Bad first message" in onboarding
        assert "Good first message" in onboarding
        # Explicit "do NOT output a status readout" guard
        assert "ready report" in onboarding.lower() or "status readout" in onboarding.lower() or "status page" in onboarding.lower()
        # The greeting MUST instruct NOT to list allowlist / permissions / RoE
        assert "allowlist" in onboarding.lower()
        assert "internal" in onboarding.lower()

    def test_hire_records_screen_when_tmux_unavailable(self, chdir_tmp, monkeypatch):
        calls = {"ensure": 0, "spawn": 0, "send": 0}

        def _count(key):
            def _f(*args, **kwargs):
                calls[key] += 1
            return _f

        monkeypatch.setattr(agency, "_runtime_mux_backend", lambda: "screen")
        monkeypatch.setattr(agency, "_runtime_mux_available", lambda: True)
        monkeypatch.setattr(agency, "_runtime_mux_ensure_session", _count("ensure"))
        monkeypatch.setattr(agency, "_runtime_mux_spawn_window", _count("spawn"))
        monkeypatch.setattr(agency, "_runtime_mux_send_keys", _count("send"))
        monkeypatch.setattr(agency.time, "sleep", lambda _s: None)

        agent = agency.hire_agent(role="dev")
        assert agent is not None
        assert agent["mux"] == "screen"

    def test_hire_unknown_role_returns_none(self, chdir_tmp, fake_mux, capsys):
        result = agency.hire_agent(role="cto")
        assert result is None
        assert "Unknown role" in capsys.readouterr().out

    def test_hire_without_multiplexer_returns_none(self, chdir_tmp, monkeypatch, capsys):
        monkeypatch.setattr(agency, "_runtime_mux_backend", lambda: None)
        result = agency.hire_agent(role="dev")
        assert result is None
        assert "No terminal multiplexer" in capsys.readouterr().out

    def test_hire_with_skill_override(self, chdir_tmp, fake_mux):
        agent = agency.hire_agent(role="dev", skill_override="frontend_developer")
        assert agent is not None
        assert agent["skill"] == "frontend_developer"

    def test_hire_with_invalid_skill_override_returns_none(self, chdir_tmp, fake_mux, capsys):
        result = agency.hire_agent(role="dev", skill_override="nonexistent_skill_xyz")
        assert result is None
        assert "not found" in capsys.readouterr().out

    def test_hiring_three_agents_yields_unique_ids(self, chdir_tmp, fake_mux):
        a = agency.hire_agent(role="chief")
        b = agency.hire_agent(role="po")
        c = agency.hire_agent(role="dev")
        assert len({a["id"], b["id"], c["id"]}) == 3

    def test_hire_yolo_sets_flag_and_spawn_command(self, chdir_tmp, monkeypatch):
        # Capture the spawn command passed through the mux layer so we can
        # assert claude is invoked with the dangerous flag.
        captured = {}

        def _fake_spawn(window, cwd, command):
            captured["command"] = command

        monkeypatch.setattr(agency, "_runtime_mux_backend", lambda: "tmux")
        monkeypatch.setattr(agency, "_runtime_mux_available", lambda: True)
        monkeypatch.setattr(agency, "_runtime_mux_ensure_session", lambda cwd: None)
        monkeypatch.setattr(agency, "_runtime_mux_spawn_window", _fake_spawn)
        monkeypatch.setattr(agency, "_runtime_mux_send_keys", lambda w, t: None)
        monkeypatch.setattr(agency.time, "sleep", lambda _s: None)

        agent = agency.hire_agent(role="chief", yolo=True)
        assert agent is not None
        assert agent["yolo"] is True
        # Chief caliber is "architect" which auto-maps to sonnet via CALIBER_MODEL_MAP.
        # The spawn command includes both yolo and model flags.
        assert "--dangerously-skip-permissions" in captured["command"]
        assert "claude" in captured["command"]

    def test_hire_default_is_not_yolo(self, chdir_tmp, fake_mux):
        agent = agency.hire_agent(role="chief")
        assert agent["yolo"] is False

    def test_onboarding_contains_do_dont_and_refuse_examples(self, chdir_tmp, fake_mux):
        agent = agency.hire_agent(role="chief")
        onboarding = (Path(agent["agent_dir"]) / "onboarding.md").read_text()
        assert "What you DO" in onboarding
        assert "What you absolutely DO NOT do" in onboarding
        assert "refusal" in onboarding.lower() or "refuse" in onboarding.lower()
        assert "don't write code" in onboarding.lower() or "do not write code" in onboarding.lower() or "not a developer" in onboarding.lower()
        claude_md = (Path(agent["agent_dir"]) / "CLAUDE.md").read_text()
        assert "collab-bus" in claude_md.lower()

    def test_hire_with_task_bakes_task_into_onboarding(self, chdir_tmp, fake_mux):
        agent = agency.hire_agent(
            role="platform",
            task="Install collab-bus with agency collab-bus --yes. Report when done.",
        )
        assert agent is not None
        assert agent["task"] is not None
        assert "collab-bus" in agent["task"]

        onboarding = (Path(agent["agent_dir"]) / "onboarding.md").read_text()
        # Task section is present and contains the task text
        assert "first task" in onboarding.lower()
        assert "Install collab-bus" in onboarding
        # The "no task" stand-by branch should NOT be in the prompt
        assert "No task was set at hire time" not in onboarding

    def test_hire_without_task_shows_standby_branch(self, chdir_tmp, fake_mux):
        agent = agency.hire_agent(role="chief")
        assert agent["task"] is None
        onboarding = (Path(agent["agent_dir"]) / "onboarding.md").read_text()
        assert "No task was set at hire time" in onboarding
        # The task-execution branch should NOT be in the prompt
        assert "execute immediately after your greeting" not in onboarding

    def test_onboarding_biases_toward_action_on_clear_orders(self, chdir_tmp, fake_mux):
        """Onboarding must train the agent to execute clear in-scope orders
        instead of asking 'want me to proceed?' (regression from a real session
        where Margaret recommended the right command but asked for confirmation
        instead of running it)."""
        agent = agency.hire_agent(role="chief")
        onboarding = (Path(agent["agent_dir"]) / "onboarding.md").read_text()
        assert "Bias toward action" in onboarding
        # Explicit anti-pattern is spelled out and marked bad
        assert "want me to proceed" in onboarding.lower() or "want me to go ahead" in onboarding.lower()
        assert "just do it" in onboarding.lower()
        # Good example shows the agent running the command, not asking
        assert "On it." in onboarding

    def test_onboarding_instructs_html_deliverables(self, chdir_tmp, fake_mux):
        """Onboarding must teach agents to render substantial deliverables as
        HTML and open them, rather than dumping long tables into chat."""
        agent = agency.hire_agent(role="chief")
        onboarding = (Path(agent["agent_dir"]) / "onboarding.md").read_text()
        assert "render to HTML" in onboarding or "HTML" in onboarding
        assert ".agency/deliverables/" in onboarding
        # Both macOS and Linux open commands are mentioned
        assert "open " in onboarding
        assert "xdg-open" in onboarding
        # The rule is conditional on size/tables, not blanket
        assert "30 lines" in onboarding or "table" in onboarding.lower()
        # Good-example chat summary pattern appears
        assert "one-paragraph summary" in onboarding.lower() or "summary" in onboarding.lower()

    def test_claude_md_contains_blueprint_org_chart(self, chdir_tmp, fake_mux):
        """Every hired agent's briefing lists the other roles in the blueprint
        so it can answer 'what can I hire' without grepping the source."""
        agent = agency.hire_agent(role="chief")
        claude_md = (Path(agent["agent_dir"]) / "CLAUDE.md").read_text()
        assert "Blueprint org chart" in claude_md
        # Chief should see every role from the IT blueprint, including platform
        for role in ("chief", "po", "architect", "security", "platform", "dev", "qa"):
            assert f"**{role}**" in claude_md
        # The (you) marker should appear on the agent's own role
        assert "**chief** (you)" in claude_md


class TestFireAgent:
    def test_fire_marks_fired_and_archives(self, chdir_tmp, fake_mux):
        hired = agency.hire_agent(role="dev")
        assert hired is not None

        fired = agency.fire_agent(agent_id=hired["id"])
        assert fired is not None
        assert fired["status"] == "fired"
        assert "fired_at" in fired

        assert not Path(hired["agent_dir"]).exists()
        archive = agency.RUNTIME_ARCHIVE_DIR / hired["id"]
        assert archive.exists()
        assert (archive / "exit_interview.md").exists()

        assert fake_mux["kill"] == 1

    def test_fire_routes_kill_to_agents_recorded_backend(self, chdir_tmp, monkeypatch):
        # Simulate an agent spawned earlier under screen, fired later under tmux.
        reg = {
            "version": 1,
            "agents": [{
                "id": "dev-legacy",
                "role": "dev",
                "caliber": "senior",
                "mux": "screen",
                "session": agency._runtime_session_name(),
                "window": "dev-legacy",
                "status": "active",
                "hired_at": "2026-04-11T12:00:00Z",
                "hired_by": "human",
                "reports_to": "po",
                "agent_dir": str(agency.RUNTIME_AGENTS_DIR / "dev-legacy"),
            }],
        }
        agency.RUNTIME_REGISTRY_PATH.parent.mkdir(parents=True, exist_ok=True)
        agency._runtime_save_registry(reg)
        # current backend is tmux, but the agent says screen
        monkeypatch.setattr(agency, "_runtime_mux_backend", lambda: "tmux")
        monkeypatch.setattr(agency, "_runtime_mux_available", lambda: True)
        kill_calls = []
        monkeypatch.setattr(
            agency,
            "_runtime_mux_kill_window",
            lambda window, backend=None: kill_calls.append((window, backend)),
        )

        agency.fire_agent(agent_id="dev-legacy")

        assert kill_calls == [("dev-legacy", "screen")]

    def test_fire_unknown_id_returns_none(self, chdir_tmp, fake_mux, capsys):
        agency.hire_agent(role="dev")
        result = agency.fire_agent(agent_id="missing-xyz")
        assert result is None
        assert "No agent with id" in capsys.readouterr().out

    def test_fire_with_no_agents_returns_none(self, chdir_tmp, fake_mux, capsys):
        result = agency.fire_agent(agent_id="anything")
        assert result is None
        assert "No active agents" in capsys.readouterr().out

    def test_fire_already_fired_agent_is_idempotent(self, chdir_tmp, fake_mux):
        hired = agency.hire_agent(role="dev")
        agency.fire_agent(agent_id=hired["id"])
        result = agency.fire_agent(agent_id=hired["id"])
        # After the first fire there are no live agents, so fire_agent bails
        # on "no active" before even inspecting the target.
        assert result is None


# ---------------------------------------------------------------------------
# Worktree-per-agent (#54)
# ---------------------------------------------------------------------------

class TestWorktreePerAgent:
    """Verify that each agent gets an isolated git worktree on hire and that
    the worktree is cleaned up on fire."""

    def test_hire_creates_worktree(self, chdir_tmp, fake_mux):
        agent = agency.hire_agent(role="dev")
        assert agent is not None
        wt = Path(agent["worktree_dir"])
        assert wt.exists(), "worktree directory should exist after hire"
        assert (wt / ".git").exists(), "worktree should contain a .git entry"
        # Verify git knows about the worktree
        import subprocess
        result = subprocess.run(
            ["git", "worktree", "list", "--porcelain"],
            capture_output=True, text=True,
        )
        assert str(wt) in result.stdout

    def test_hire_records_worktree_dir_in_registry(self, chdir_tmp, fake_mux):
        agent = agency.hire_agent(role="dev")
        assert agent is not None
        reg = agency._runtime_load_registry()
        entry = reg["agents"][0]
        assert "worktree_dir" in entry
        assert entry["worktree_dir"] == str(agency.RUNTIME_WORKTREES_DIR / agent["id"])

    def test_fire_removes_worktree(self, chdir_tmp, fake_mux):
        agent = agency.hire_agent(role="dev")
        assert agent is not None
        wt = Path(agent["worktree_dir"])
        assert wt.exists()

        agency.fire_agent(agent_id=agent["id"])
        assert not wt.exists(), "worktree directory should be removed after fire"
        # Verify git no longer lists the worktree
        import subprocess
        result = subprocess.run(
            ["git", "worktree", "list", "--porcelain"],
            capture_output=True, text=True,
        )
        assert str(wt) not in result.stdout

    def test_agent_cwd_is_worktree(self, chdir_tmp, monkeypatch):
        """The multiplexer spawn should receive the worktree path as cwd,
        not the main repo root."""
        captured = {}

        def _fake_spawn(window, cwd, command):
            captured["cwd"] = cwd

        monkeypatch.setattr(agency, "_runtime_mux_backend", lambda: "tmux")
        monkeypatch.setattr(agency, "_runtime_mux_available", lambda: True)
        monkeypatch.setattr(agency, "_runtime_mux_ensure_session", lambda cwd: None)
        monkeypatch.setattr(agency, "_runtime_mux_spawn_window", _fake_spawn)
        monkeypatch.setattr(agency, "_runtime_mux_send_keys", lambda w, t: None)
        monkeypatch.setattr(agency.time, "sleep", lambda _s: None)

        agent = agency.hire_agent(role="dev")
        assert agent is not None
        expected_wt = Path(agent["worktree_dir"])
        assert captured["cwd"] == expected_wt

    def test_two_agents_get_separate_worktrees(self, chdir_tmp, fake_mux):
        a = agency.hire_agent(role="dev")
        b = agency.hire_agent(role="dev")
        assert a is not None and b is not None
        assert a["worktree_dir"] != b["worktree_dir"]
        assert Path(a["worktree_dir"]).exists()
        assert Path(b["worktree_dir"]).exists()


class TestShowStatus:
    def test_empty_registry_prints_hint(self, chdir_tmp, capsys):
        agency.show_status()
        assert "No agents have been hired yet" in capsys.readouterr().out

    def test_status_lists_active_and_archived_agents(self, chdir_tmp, fake_mux, capsys):
        a = agency.hire_agent(role="chief")
        b = agency.hire_agent(role="dev")
        agency.fire_agent(agent_id=b["id"])

        capsys.readouterr()  # clear
        agency.show_status()
        out = capsys.readouterr().out
        assert a["id"] in out
        assert b["id"] in out
        assert "1 active" in out
        assert "1 archived" in out


# ---------------------------------------------------------------------------
# Persistent roster — save on fire, load on hire
# ---------------------------------------------------------------------------

@pytest.fixture
def fake_roster(tmp_path, monkeypatch):
    """Point ROSTER_DIR at a temp directory so tests don't touch ~/.agency/."""
    roster = tmp_path / "roster"
    roster.mkdir()
    monkeypatch.setattr(agency, "ROSTER_DIR", roster)
    return roster


class TestRosterSaveOnFire:
    def test_fire_saves_learnings_and_history(self, chdir_tmp, fake_mux, fake_roster):
        agent = agency.hire_agent(role="dev")
        assert agent is not None
        name = agent["name"]
        assert name is not None  # devs have a name_pool

        agency.fire_agent(agent_id=agent["id"])

        roster_dir = fake_roster / name.lower()
        assert roster_dir.exists()

        # Learnings file exists and contains project info
        learnings = (roster_dir / "learnings.md").read_text(encoding="utf-8")
        assert f"# Learnings for {name}" in learnings
        assert agent["role"] in learnings
        assert agent["hired_at"] in learnings

        # History file exists and is valid JSON
        history = json.loads((roster_dir / "history.json").read_text(encoding="utf-8"))
        assert len(history) == 1
        assert history[0]["agent_id"] == agent["id"]
        assert history[0]["role"] == "dev"
        assert history[0]["hired_at"] == agent["hired_at"]
        assert history[0]["fired_at"] is not None

    def test_fire_appends_learnings_across_stints(self, chdir_tmp, fake_mux, fake_roster):
        """Firing the same named agent twice appends to learnings, not overwrites."""
        a1 = agency.hire_agent(role="dev")
        name = a1["name"]
        agency.fire_agent(agent_id=a1["id"])

        a2 = agency.hire_agent(role="dev", agent_name=name)
        agency.fire_agent(agent_id=a2["id"])

        learnings = (fake_roster / name.lower() / "learnings.md").read_text(encoding="utf-8")
        # Should have two stint headers (## <project> — <timestamp>)
        import re
        stint_headers = re.findall(r"^## .+ — \d{4}-", learnings, re.MULTILINE)
        assert len(stint_headers) == 2

        history = json.loads(
            (fake_roster / name.lower() / "history.json").read_text(encoding="utf-8")
        )
        assert len(history) == 2

    def test_fire_skips_roster_for_unnamed_agents(self, chdir_tmp, fake_mux, fake_roster, monkeypatch):
        """Agents with hex-fallback IDs (no name) should not create roster entries."""
        # Force no name_pool to get a hex-fallback agent
        monkeypatch.setattr(agency.secrets, "token_hex", lambda n: "abc123")
        agent = agency.hire_agent(role="dev")
        # Override the name to None to simulate hex-fallback
        agent["name"] = None
        agency._runtime_save_registry(agency._runtime_load_registry())
        # Manually call _roster_save_on_fire with no name
        agency._roster_save_on_fire(agent)
        # No roster dir should be created
        assert not (fake_roster / "abc123").exists()
        assert len(list(fake_roster.iterdir())) == 0


class TestRosterLoadOnHire:
    def test_hire_with_agent_name_loads_learnings(self, chdir_tmp, fake_mux, fake_roster):
        """When --agent <name> is used and learnings exist, they appear in onboarding."""
        # Pre-populate roster with learnings
        roster_dir = fake_roster / "alice"
        roster_dir.mkdir()
        (roster_dir / "learnings.md").write_text(
            "# Learnings for Alice\n\n"
            "## old-project — 2026-04-01\n\n"
            "Learned to always run migrations before tests.\n",
            encoding="utf-8",
        )

        agent = agency.hire_agent(role="dev", agent_name="Alice")
        assert agent is not None
        assert agent["name"] == "Alice"
        assert agent["id"] == "dev-alice"

        onboarding = (Path(agent["agent_dir"]) / "onboarding.md").read_text(encoding="utf-8")
        assert "Prior learnings from previous projects" in onboarding
        assert "always run migrations before tests" in onboarding

    def test_hire_with_agent_name_no_learnings(self, chdir_tmp, fake_mux, fake_roster):
        """When --agent <name> is used but no roster exists, onboarding has no learnings section."""
        agent = agency.hire_agent(role="dev", agent_name="Bob")
        assert agent is not None
        assert agent["name"] == "Bob"
        assert agent["id"] == "dev-bob"

        onboarding = (Path(agent["agent_dir"]) / "onboarding.md").read_text(encoding="utf-8")
        assert "Prior learnings" not in onboarding

    def test_hire_without_agent_name_still_works(self, chdir_tmp, fake_mux, fake_roster):
        """Normal hire (no --agent) still picks from name pool and works as before."""
        agent = agency.hire_agent(role="dev")
        assert agent is not None
        assert agent["name"] is not None
        # Without pre-populated roster, no learnings in onboarding
        onboarding = (Path(agent["agent_dir"]) / "onboarding.md").read_text(encoding="utf-8")
        assert "Prior learnings" not in onboarding

    def test_full_lifecycle_fire_then_rehire(self, chdir_tmp, fake_mux, fake_roster):
        """End-to-end: hire, fire (saves learnings), re-hire by name (loads learnings)."""
        a1 = agency.hire_agent(role="dev")
        name = a1["name"]
        agency.fire_agent(agent_id=a1["id"])

        # Re-hire the same agent by name
        a2 = agency.hire_agent(role="dev", agent_name=name)
        assert a2 is not None
        assert a2["name"] == name

        onboarding = (Path(a2["agent_dir"]) / "onboarding.md").read_text(encoding="utf-8")
        assert "Prior learnings from previous projects" in onboarding
        assert name in onboarding


# ---------------------------------------------------------------------------
# Persistent memory — standing rules carried across sessions
# ---------------------------------------------------------------------------


class TestRosterMemoryOnHire:
    def test_hire_loads_memory_when_exists(self, chdir_tmp, fake_mux, fake_roster):
        """When memory.md exists in the roster, it appears in onboarding."""
        roster_dir = fake_roster / "alice"
        roster_dir.mkdir()
        (roster_dir / "memory.md").write_text(
            "# Memory for Alice\n\n"
            "## old-project — 2026-04-01\n\n"
            "- Always run linters before committing.\n",
            encoding="utf-8",
        )

        agent = agency.hire_agent(role="dev", agent_name="Alice")
        assert agent is not None

        onboarding = (Path(agent["agent_dir"]) / "onboarding.md").read_text(encoding="utf-8")
        assert "Persistent memory" in onboarding
        assert "Always run linters before committing" in onboarding

    def test_hire_no_memory_no_section(self, chdir_tmp, fake_mux, fake_roster):
        """When no memory.md exists, onboarding has no persistent memory section."""
        agent = agency.hire_agent(role="dev", agent_name="Bob")
        assert agent is not None

        onboarding = (Path(agent["agent_dir"]) / "onboarding.md").read_text(encoding="utf-8")
        assert "Persistent memory" not in onboarding

    def test_hire_loads_both_learnings_and_memory(self, chdir_tmp, fake_mux, fake_roster):
        """Both learnings and memory appear in onboarding when both exist."""
        roster_dir = fake_roster / "alice"
        roster_dir.mkdir()
        (roster_dir / "learnings.md").write_text(
            "# Learnings for Alice\n\n## old-project — 2026-04-01\n\nLearned X.\n",
            encoding="utf-8",
        )
        (roster_dir / "memory.md").write_text(
            "# Memory for Alice\n\n- Rule Y applies.\n",
            encoding="utf-8",
        )

        agent = agency.hire_agent(role="dev", agent_name="Alice")
        onboarding = (Path(agent["agent_dir"]) / "onboarding.md").read_text(encoding="utf-8")
        assert "Prior learnings from previous projects" in onboarding
        assert "Persistent memory" in onboarding
        assert "Learned X" in onboarding
        assert "Rule Y applies" in onboarding


class TestRosterMemoryOnFire:
    def test_fire_saves_memory_from_agent_dir(self, chdir_tmp, fake_mux, fake_roster):
        """When the agent wrote memory.md in its dir, fire appends it to roster."""
        agent = agency.hire_agent(role="dev")
        name = agent["name"]

        # Simulate the agent writing a memory.md during its session
        agent_dir = Path(agent["agent_dir"])
        (agent_dir / "memory.md").write_text(
            "- Never use print() for logging, use the logger.\n",
            encoding="utf-8",
        )

        agency.fire_agent(agent_id=agent["id"])

        roster_memory = (fake_roster / name.lower() / "memory.md").read_text(encoding="utf-8")
        assert f"# Memory for {name}" in roster_memory
        assert "Never use print() for logging" in roster_memory

    def test_fire_no_memory_no_file(self, chdir_tmp, fake_mux, fake_roster):
        """When the agent did not write memory.md, no roster memory file is created."""
        agent = agency.hire_agent(role="dev")
        name = agent["name"]

        agency.fire_agent(agent_id=agent["id"])

        assert not (fake_roster / name.lower() / "memory.md").exists()

    def test_fire_appends_memory_across_stints(self, chdir_tmp, fake_mux, fake_roster):
        """Firing the same agent twice with memory appends, not overwrites."""
        a1 = agency.hire_agent(role="dev")
        name = a1["name"]

        (Path(a1["agent_dir"]) / "memory.md").write_text(
            "- Rule from first stint.\n", encoding="utf-8",
        )
        agency.fire_agent(agent_id=a1["id"])

        a2 = agency.hire_agent(role="dev", agent_name=name)
        (Path(a2["agent_dir"]) / "memory.md").write_text(
            "- Rule from second stint.\n", encoding="utf-8",
        )
        agency.fire_agent(agent_id=a2["id"])

        roster_memory = (fake_roster / name.lower() / "memory.md").read_text(encoding="utf-8")
        assert "Rule from first stint" in roster_memory
        assert "Rule from second stint" in roster_memory
        # Should have two stint sections
        import re
        stint_headers = re.findall(r"^## .+ — \d{4}-", roster_memory, re.MULTILINE)
        assert len(stint_headers) == 2

    def test_full_lifecycle_memory_persists(self, chdir_tmp, fake_mux, fake_roster):
        """End-to-end: hire, write memory, fire, re-hire — memory appears in onboarding."""
        a1 = agency.hire_agent(role="dev")
        name = a1["name"]

        (Path(a1["agent_dir"]) / "memory.md").write_text(
            "- Always validate input at API boundaries.\n", encoding="utf-8",
        )
        agency.fire_agent(agent_id=a1["id"])

        a2 = agency.hire_agent(role="dev", agent_name=name)
        onboarding = (Path(a2["agent_dir"]) / "onboarding.md").read_text(encoding="utf-8")
        assert "Persistent memory" in onboarding
        assert "Always validate input at API boundaries" in onboarding


# ---------------------------------------------------------------------------
# Registry race condition (issue #33)
# ---------------------------------------------------------------------------

class TestRegistryRaceCondition:
    """Parallel hire commands must not corrupt the registry.

    Before the fix, two concurrent hires would both read the same registry
    state, append their agent, and write — the second write would overwrite
    the first, losing an agent and potentially producing invalid JSON.
    """

    def test_parallel_hires_preserve_all_agents(self, chdir_tmp, monkeypatch):
        """Run N hire_agent calls in parallel threads and assert that every
        agent ends up in the registry with no duplicates or corruption."""
        # Stub the mux layer so we never spawn real processes.
        monkeypatch.setattr(agency, "_runtime_mux_backend", lambda: "tmux")
        monkeypatch.setattr(agency, "_runtime_mux_available", lambda: True)
        monkeypatch.setattr(agency, "_runtime_mux_ensure_session", lambda cwd: None)
        monkeypatch.setattr(agency, "_runtime_mux_spawn_window", lambda w, c, cmd: None)
        monkeypatch.setattr(agency, "_runtime_mux_send_keys", lambda w, t: None)
        monkeypatch.setattr(agency.time, "sleep", lambda _s: None)

        # Pre-create the skill directory so parallel copytree calls don't race.
        import shutil
        skill_name = IT_BLUEPRINT["roles"]["dev"]["skill"]
        src = Path(agency.__file__).parent / "skills" / skill_name
        dest = Path(".agency") / "skills" / skill_name
        dest.parent.mkdir(parents=True, exist_ok=True)
        if src.exists():
            shutil.copytree(src, dest)

        n_parallel = 5
        results = [None] * n_parallel

        def hire_one(idx):
            results[idx] = agency.hire_agent(role="dev")

        with concurrent.futures.ThreadPoolExecutor(max_workers=n_parallel) as pool:
            futures = [pool.submit(hire_one, i) for i in range(n_parallel)]
            concurrent.futures.wait(futures)
            # Re-raise any exceptions from threads.
            for f in futures:
                f.result()

        # Every hire must have succeeded.
        for i, agent in enumerate(results):
            assert agent is not None, f"hire #{i} returned None"

        # The registry must contain exactly n_parallel agents, all unique.
        registry = agency._runtime_load_registry()
        agent_ids = [a["id"] for a in registry["agents"]]
        assert len(agent_ids) == n_parallel, (
            f"Expected {n_parallel} agents in registry, got {len(agent_ids)}: {agent_ids}"
        )
        assert len(set(agent_ids)) == n_parallel, (
            f"Duplicate agent IDs in registry: {agent_ids}"
        )

        # Registry must be valid JSON (no concatenated objects).
        raw = agency.RUNTIME_REGISTRY_PATH.read_text(encoding="utf-8")
        parsed = json.loads(raw)  # would raise JSONDecodeError if corrupt
        assert isinstance(parsed, dict)
        assert "agents" in parsed
