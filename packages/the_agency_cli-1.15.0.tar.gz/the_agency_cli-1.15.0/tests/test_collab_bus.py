"""Tests for collab-bus scaffolding helpers and transport edge cases."""

from __future__ import annotations

import importlib.util
import json
from pathlib import Path
from unittest.mock import patch, MagicMock

import agency


def _load_post_outbound_module():
    script_path = Path(__file__).resolve().parents[1] / "skills" / "collab_bus" / "templates" / "post_outbound.py"
    spec = importlib.util.spec_from_file_location("collab_bus_post_outbound", script_path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


post_outbound = _load_post_outbound_module()


class TestCollabBusPlatformHelpers:
    def test_windows_defaults_use_py_and_powershell(self, monkeypatch):
        monkeypatch.setattr(agency.sys, "platform", "win32")

        assert agency._collab_bus_python_command() == "py"
        assert agency._collab_bus_supports_shell_watcher() is False
        assert agency._collab_bus_permission_entries() == [
            "PowerShell(py tmp/post_outbound.py*)",
            "PowerShell(python tmp/post_outbound.py*)",
        ]

    def test_unix_defaults_use_python3_and_bash(self, monkeypatch):
        monkeypatch.setattr(agency.sys, "platform", "linux")

        assert agency._collab_bus_python_command() == "python3"
        assert agency._collab_bus_supports_shell_watcher() is True
        assert agency._collab_bus_permission_entries() == [
            "Bash(python3 tmp/post_outbound.py*)"
        ]


class TestParseCommentPages:
    def test_returns_empty_list_for_empty_issue(self):
        assert post_outbound.parse_comment_pages("[]\n") == []

    def test_flattens_paginated_comment_arrays(self):
        raw = '[{"id": 1, "body": "first"}]\n[{"id": 2, "body": "second"}]\n'

        comments = post_outbound.parse_comment_pages(raw)

        assert [comment["id"] for comment in comments] == [1, 2]


class TestActionLatest:
    def test_handles_threads_with_no_comments(self, capsys):
        github = post_outbound.GitHubBackend()
        with patch.object(post_outbound, "gh", side_effect=["issue header", "[]\n"]):
            github.latest({"issue": "12"}, "")

        out = capsys.readouterr().out
        assert "issue header" in out
        assert "(no comments yet)" in out


class TestLoadConf:
    def test_returns_empty_for_missing_file(self, tmp_path):
        assert post_outbound.load_conf(tmp_path / "nope.conf") == {}

    def test_parses_key_value_conf(self, tmp_path):
        conf_file = tmp_path / "test.conf"
        conf_file.write_text("backend: gitlab\ngitlab_url: https://gl.example.com\n# comment\n")
        result = post_outbound.load_conf(conf_file)
        assert result["backend"] == "gitlab"
        assert result["gitlab_url"] == "https://gl.example.com"

    def test_skips_comments_and_blanks(self, tmp_path):
        conf_file = tmp_path / "test.conf"
        conf_file.write_text("# this is a comment\n\nbackend: github\n")
        result = post_outbound.load_conf(conf_file)
        assert result == {"backend": "github"}


class TestGetBackend:
    def test_github_backend(self):
        backend = post_outbound.get_backend("github", {})
        assert isinstance(backend, post_outbound.GitHubBackend)

    def test_github_backend_with_repo(self):
        backend = post_outbound.get_backend("github", {"github_repo": "owner/repo"})
        assert isinstance(backend, post_outbound.GitHubBackend)
        assert backend.repo == "owner/repo"

    def test_github_backend_without_repo(self):
        backend = post_outbound.get_backend("github", {})
        assert backend.repo is None

    def test_gitlab_backend(self, monkeypatch):
        monkeypatch.setenv("TEST_GL_TOKEN", "glpat-fake")
        conf = {
            "gitlab_url": "https://gl.example.com",
            "gitlab_project_id": "1",
            "gitlab_token_env": "TEST_GL_TOKEN",
        }
        backend = post_outbound.get_backend("gitlab", conf)
        assert isinstance(backend, post_outbound.GitLabBackend)
        assert backend.base_url == "https://gl.example.com"
        assert backend.project_id == "1"

    def test_unknown_backend_exits(self):
        import pytest
        with pytest.raises(SystemExit):
            post_outbound.get_backend("bitbucket", {})


class TestGitLabBackendTokenLoading:
    def test_loads_from_env(self, monkeypatch):
        monkeypatch.setenv("MY_TOKEN", "glpat-123")
        conf = {
            "gitlab_url": "https://gl.example.com",
            "gitlab_project_id": "1",
            "gitlab_token_env": "MY_TOKEN",
        }
        backend = post_outbound.GitLabBackend(conf)
        assert backend.token == "glpat-123"

    def test_loads_from_dotenv_file(self, tmp_path, monkeypatch):
        # Make sure the env var is NOT set
        monkeypatch.delenv("MY_GL_TOKEN", raising=False)
        dotenv = tmp_path / ".env.local"
        dotenv.write_text("OTHER=stuff\nMY_GL_TOKEN=glpat-from-file\n")
        conf = {
            "gitlab_url": "https://gl.example.com",
            "gitlab_project_id": "1",
            "gitlab_token_env": "MY_GL_TOKEN",
            "gitlab_token_file": str(dotenv),
        }
        backend = post_outbound.GitLabBackend(conf)
        assert backend.token == "glpat-from-file"

    def test_exits_if_no_token_found(self, monkeypatch):
        import pytest
        monkeypatch.delenv("MISSING_TOKEN", raising=False)
        conf = {
            "gitlab_url": "https://gl.example.com",
            "gitlab_project_id": "1",
            "gitlab_token_env": "MISSING_TOKEN",
        }
        with pytest.raises(SystemExit):
            post_outbound.GitLabBackend(conf)


class TestGitLabBackendFormat:
    def test_format_issue_basic(self, monkeypatch):
        monkeypatch.setenv("GL_TOK", "fake")
        conf = {
            "gitlab_url": "https://gl.example.com",
            "gitlab_project_id": "1",
            "gitlab_token_env": "GL_TOK",
        }
        backend = post_outbound.GitLabBackend(conf)
        issue = {
            "iid": 5,
            "title": "Test issue",
            "state": "opened",
            "labels": ["bug", "urgent"],
            "author": {"username": "bot"},
            "created_at": "2026-01-01T00:00:00Z",
            "description": "Some description",
        }
        output = backend._format_issue(issue)
        assert "#5" in output
        assert "Test issue" in output
        assert "bug, urgent" in output

    def test_format_issue_with_comments(self, monkeypatch):
        monkeypatch.setenv("GL_TOK", "fake")
        conf = {
            "gitlab_url": "https://gl.example.com",
            "gitlab_project_id": "1",
            "gitlab_token_env": "GL_TOK",
        }
        backend = post_outbound.GitLabBackend(conf)
        issue = {
            "iid": 1, "title": "T", "state": "opened", "labels": [],
            "author": {"username": "x"}, "created_at": "", "description": "",
        }
        comments = [
            {"author": {"username": "agent1"}, "created_at": "2026-01-01", "body": "hello"},
        ]
        output = backend._format_issue(issue, comments)
        assert "1 comment(s)" in output
        assert "agent1" in output
        assert "hello" in output


class TestGitHubRepoConfig:
    """Tests for the github_repo config option — ensures --repo is passed to gh."""

    def test_gh_helper_prepends_repo_flag(self):
        """When repo is set, gh() prepends --repo to the command."""
        fake_run = MagicMock(return_value=MagicMock(returncode=0, stdout="ok\n", stderr=""))
        with patch.object(post_outbound.subprocess, "run", fake_run):
            post_outbound.gh("issue", "view", "1", repo="owner/repo")

        cmd = fake_run.call_args[0][0]
        assert cmd == ["gh", "--repo", "owner/repo", "issue", "view", "1"]

    def test_gh_helper_omits_repo_when_none(self):
        """When repo is None, gh() does not add --repo."""
        fake_run = MagicMock(return_value=MagicMock(returncode=0, stdout="ok\n", stderr=""))
        with patch.object(post_outbound.subprocess, "run", fake_run):
            post_outbound.gh("issue", "view", "1", repo=None)

        cmd = fake_run.call_args[0][0]
        assert cmd == ["gh", "issue", "view", "1"]

    def test_github_backend_comment_passes_repo(self, capsys):
        """GitHubBackend.comment passes repo through to every gh call."""
        conf = {"github_repo": "flegare/the_agency"}
        backend = post_outbound.GitHubBackend(conf)
        calls = []

        def fake_run(cmd, **kwargs):
            calls.append(cmd)
            return MagicMock(returncode=0, stdout="posted\n", stderr="")

        with patch.object(post_outbound.subprocess, "run", fake_run):
            backend.comment({"issue": "31"}, "Hello from testbed")

        # Both the comment and the view-after-comment calls should have --repo
        for call in calls:
            assert call[1:3] == ["--repo", "flegare/the_agency"], f"Missing --repo in {call}"

    def test_github_backend_no_repo_in_default(self, capsys):
        """GitHubBackend without github_repo does not add --repo."""
        backend = post_outbound.GitHubBackend({})
        calls = []

        def fake_run(cmd, **kwargs):
            calls.append(cmd)
            return MagicMock(returncode=0, stdout="ok\n", stderr="")

        with patch.object(post_outbound.subprocess, "run", fake_run):
            backend.view({"issue": "1"}, "")

        for call in calls:
            assert "--repo" not in call

    def test_conf_parsing_picks_up_github_repo(self, tmp_path):
        """load_conf correctly parses github_repo from a conf file."""
        conf_file = tmp_path / "collab_bus.conf"
        conf_file.write_text("backend: github\ngithub_repo: flegare/the_agency\n")
        conf = post_outbound.load_conf(conf_file)
        assert conf["github_repo"] == "flegare/the_agency"

    def test_latest_expands_api_path_when_repo_set(self, capsys):
        """When repo is set, the API path for latest uses the concrete repo, not {owner}/{repo}."""
        conf = {"github_repo": "flegare/the_agency"}
        backend = post_outbound.GitHubBackend(conf)
        calls = []

        def fake_run(cmd, **kwargs):
            calls.append(cmd)
            return MagicMock(returncode=0, stdout="[]\n", stderr="")

        with patch.object(post_outbound.subprocess, "run", fake_run):
            backend.latest({"issue": "5"}, "")

        api_call = [c for c in calls if "api" in c]
        assert len(api_call) == 1
        # The API path should have the concrete repo, not the {owner}/{repo} template
        api_path = api_call[0][api_call[0].index("api") + 1]
        assert "flegare/the_agency" in api_path
        assert "{owner}" not in api_path


class TestParseOutbound:
    def test_parses_frontmatter_and_body(self, tmp_path):
        f = tmp_path / "out.md"
        f.write_text("---\naction: comment\nissue: 5\nbackend: gitlab\n---\n\nHello world\n")
        meta, body = post_outbound.parse_outbound(f)
        assert meta["action"] == "comment"
        assert meta["issue"] == "5"
        assert meta["backend"] == "gitlab"
        assert body == "Hello world"


# ---------------------------------------------------------------------------
# M2: Notify-on-handoff
# ---------------------------------------------------------------------------

class TestParseStatusPacket:
    def test_extracts_json_from_body(self):
        body = (
            "Done with the refactor.\n\n"
            '{"speaker":"Bob","next_owner":"Sarah","next_action":"Review PR","blocking":false,"waiting_on":null}'
        )
        packet = post_outbound._parse_status_packet(body)
        assert packet is not None
        assert packet["speaker"] == "Bob"
        assert packet["next_owner"] == "Sarah"
        assert packet["next_action"] == "Review PR"

    def test_returns_none_when_no_json(self):
        assert post_outbound._parse_status_packet("Just a plain comment.") is None

    def test_returns_none_for_malformed_json(self):
        assert post_outbound._parse_status_packet("text {not valid json}") is None

    def test_extracts_last_json_block(self):
        body = (
            'Config: {"key": "value"}\n\n'
            'Handoff\n\n'
            '{"speaker":"Alice","next_owner":"QA","next_action":"test it","blocking":false,"waiting_on":null}'
        )
        packet = post_outbound._parse_status_packet(body)
        assert packet["speaker"] == "Alice"
        assert packet["next_owner"] == "QA"


class TestLoadRegistry:
    def test_returns_empty_when_missing(self, tmp_path):
        reg = post_outbound._load_registry(tmp_path / "nope.json")
        assert reg == {"agents": []}

    def test_returns_empty_on_corrupt(self, tmp_path):
        f = tmp_path / "reg.json"
        f.write_text("{bad json")
        assert post_outbound._load_registry(f) == {"agents": []}

    def test_loads_valid_registry(self, tmp_path):
        f = tmp_path / "reg.json"
        f.write_text(json.dumps({"version": 1, "agents": [{"id": "po-sarah"}]}))
        reg = post_outbound._load_registry(f)
        assert len(reg["agents"]) == 1


class TestFindAgentByRef:
    REGISTRY = {
        "agents": [
            {"id": "po-sarah", "name": "Sarah", "role": "po", "status": "active"},
            {"id": "dev-bob", "name": "Bob", "role": "dev", "status": "active"},
            {"id": "qa-helen", "name": "Helen", "role": "qa", "status": "fired"},
        ]
    }

    def test_finds_by_name(self):
        assert post_outbound._find_agent_by_ref(self.REGISTRY, "Sarah")["id"] == "po-sarah"

    def test_finds_by_id(self):
        assert post_outbound._find_agent_by_ref(self.REGISTRY, "dev-bob")["id"] == "dev-bob"

    def test_finds_by_role(self):
        assert post_outbound._find_agent_by_ref(self.REGISTRY, "po")["id"] == "po-sarah"

    def test_case_insensitive(self):
        assert post_outbound._find_agent_by_ref(self.REGISTRY, "SARAH")["id"] == "po-sarah"

    def test_skips_fired_agents(self):
        assert post_outbound._find_agent_by_ref(self.REGISTRY, "Helen") is None

    def test_returns_none_for_unknown(self):
        assert post_outbound._find_agent_by_ref(self.REGISTRY, "nobody") is None


class TestNotifyAgent:
    def test_screen_notification_uses_split_send_keys(self):
        agent = {
            "id": "po-sarah", "name": "Sarah", "role": "po",
            "mux": "screen", "session": "agency", "window": "po-sarah",
        }
        fake_run = MagicMock(return_value=MagicMock(returncode=0))
        with patch.object(post_outbound.subprocess, "run", fake_run):
            with patch.object(post_outbound._time, "sleep"):
                post_outbound._notify_agent(agent, "Bob", "Review PR #19", "18")

        # Screen path must use the two-call split pattern (text then \r)
        assert fake_run.call_count == 2
        first_args = fake_run.call_args_list[0][0][0]
        second_args = fake_run.call_args_list[1][0][0]
        assert first_args[:6] == ["screen", "-S", "agency", "-p", "po-sarah", "-X"]
        assert "Bob" in first_args[-1]  # message contains the speaker
        assert second_args[-1] == "\r"  # second call is just Enter

    def test_tmux_notification_uses_send_keys_with_enter(self):
        agent = {
            "id": "dev-bob", "name": "Bob", "role": "dev",
            "mux": "tmux", "session": "agency", "window": "dev-bob",
        }
        fake_run = MagicMock(return_value=MagicMock(returncode=0))
        with patch.object(post_outbound.subprocess, "run", fake_run):
            post_outbound._notify_agent(agent, "Sarah", "Implement login", "42")

        assert fake_run.call_count == 1
        args = fake_run.call_args[0][0]
        assert args[0] == "tmux"
        assert "Sarah" in args[-2]  # message
        assert args[-1] == "Enter"  # tmux key name

    def test_silent_skip_on_unknown_mux(self):
        agent = {"id": "x", "mux": "zellij", "session": "a", "window": "x"}
        fake_run = MagicMock()
        with patch.object(post_outbound.subprocess, "run", fake_run):
            post_outbound._notify_agent(agent, "A", "B", "1")
        fake_run.assert_not_called()

    def test_handles_dead_window_gracefully(self):
        agent = {
            "id": "po-sarah", "name": "Sarah", "mux": "screen",
            "session": "agency", "window": "po-sarah",
        }
        fake_run = MagicMock(side_effect=post_outbound.subprocess.CalledProcessError(1, "screen"))
        with patch.object(post_outbound.subprocess, "run", fake_run):
            # Should not raise — just prints a warning
            post_outbound._notify_agent(agent, "Bob", "Review", "18")


class TestNextOwnerFallback:
    """Tests for the hired_by fallback when next_owner is unresolved."""

    REGISTRY = {
        "agents": [
            {
                "id": "po-sarah", "name": "Sarah", "role": "po",
                "status": "active", "hired_by": "human",
                "mux": "screen", "session": "agency", "window": "po-sarah",
            },
            {
                "id": "dev-bob", "name": "Bob", "role": "dev",
                "status": "active", "hired_by": "po-sarah",
                "mux": "screen", "session": "agency", "window": "dev-bob",
            },
        ]
    }

    def _make_body(self, next_owner, speaker="Bob", purpose_complete=False):
        packet = {
            "speaker": speaker,
            "next_owner": next_owner,
            "next_action": "Review my work",
            "blocking": False,
            "waiting_on": None,
        }
        if purpose_complete:
            packet["purpose_complete"] = True
        return f"Done.\n\n{json.dumps(packet)}"

    def test_fallback_to_hired_by_when_next_owner_not_found(self, capsys):
        """When next_owner doesn't resolve, notify the speaker's hired_by."""
        body = self._make_body(next_owner="nonexistent", speaker="Bob")
        meta = {"issue": "42"}

        with patch.object(post_outbound, "_load_registry", return_value=self.REGISTRY):
            with patch.object(post_outbound, "_notify_agent") as mock_notify:
                post_outbound._try_notify_next_owner(body, meta)

        # Should notify po-sarah (Bob's hired_by)
        mock_notify.assert_called_once()
        notified_agent = mock_notify.call_args[0][0]
        assert notified_agent["id"] == "po-sarah"
        # Message should mention unresolved next_owner
        action_str = mock_notify.call_args[0][2]
        assert "unresolved" in action_str

        # Should print a warning to stderr
        err = capsys.readouterr().err
        assert "next_owner 'nonexistent' not found" in err
        assert "falling back to hired_by" in err

    def test_fallback_includes_purpose_complete(self, capsys):
        """Fallback notification includes purpose_complete note."""
        body = self._make_body(
            next_owner="nonexistent", speaker="Bob", purpose_complete=True,
        )
        meta = {"issue": "42"}

        with patch.object(post_outbound, "_load_registry", return_value=self.REGISTRY):
            with patch.object(post_outbound, "_notify_agent") as mock_notify:
                post_outbound._try_notify_next_owner(body, meta)

        action_str = mock_notify.call_args[0][2]
        assert "purpose_complete" in action_str
        assert "unresolved" in action_str

    def test_fallback_skipped_when_hired_by_also_not_found(self, capsys):
        """When both next_owner and hired_by are unresolvable, warn and skip."""
        registry = {
            "agents": [
                {
                    "id": "dev-bob", "name": "Bob", "role": "dev",
                    "status": "active", "hired_by": "chief-gone",
                },
            ]
        }
        body = self._make_body(next_owner="nonexistent", speaker="Bob")
        meta = {"issue": "42"}

        with patch.object(post_outbound, "_load_registry", return_value=registry):
            with patch.object(post_outbound, "_notify_agent") as mock_notify:
                post_outbound._try_notify_next_owner(body, meta)

        mock_notify.assert_not_called()
        err = capsys.readouterr().err
        assert "hired_by fallback also not found" in err

    def test_fallback_skipped_when_speaker_not_in_registry(self, capsys):
        """When the speaker itself can't be found, can't look up hired_by."""
        registry = {"agents": []}
        body = self._make_body(next_owner="nonexistent", speaker="Ghost")
        meta = {"issue": "42"}

        with patch.object(post_outbound, "_load_registry", return_value=registry):
            with patch.object(post_outbound, "_notify_agent") as mock_notify:
                post_outbound._try_notify_next_owner(body, meta)

        mock_notify.assert_not_called()

    def test_fallback_skipped_when_no_hired_by_field(self, capsys):
        """When the speaker has no hired_by field, warn and skip."""
        registry = {
            "agents": [
                {
                    "id": "dev-bob", "name": "Bob", "role": "dev",
                    "status": "active",
                    # no hired_by field
                },
            ]
        }
        body = self._make_body(next_owner="nonexistent", speaker="Bob")
        meta = {"issue": "42"}

        with patch.object(post_outbound, "_load_registry", return_value=registry):
            with patch.object(post_outbound, "_notify_agent") as mock_notify:
                post_outbound._try_notify_next_owner(body, meta)

        mock_notify.assert_not_called()
        err = capsys.readouterr().err
        assert "hired_by fallback also not found" in err

    def test_normal_path_not_affected(self):
        """When next_owner resolves normally, no fallback is attempted."""
        body = self._make_body(next_owner="Sarah", speaker="Bob")
        meta = {"issue": "42"}

        with patch.object(post_outbound, "_load_registry", return_value=self.REGISTRY):
            with patch.object(post_outbound, "_notify_agent") as mock_notify:
                post_outbound._try_notify_next_owner(body, meta)

        # Should notify Sarah directly (normal path)
        mock_notify.assert_called_once()
        notified_agent = mock_notify.call_args[0][0]
        assert notified_agent["id"] == "po-sarah"
        # No fallback note in the action
        action_str = mock_notify.call_args[0][2]
        assert "unresolved" not in action_str


# ---------------------------------------------------------------------------
# _bump_last_seen
# ---------------------------------------------------------------------------

class TestBumpLastSeen:
    def test_bump_last_seen_updates_existing_agent(self, tmp_path):
        """_bump_last_seen sets last_seen to a valid ISO timestamp on a known agent."""
        registry_path = tmp_path / "registry.json"
        registry = {
            "agents": [
                {"id": "dev-alice", "name": "Alice", "role": "dev", "status": "active"}
            ]
        }
        registry_path.write_text(json.dumps(registry))

        post_outbound._bump_last_seen(registry_path, "dev-alice")

        updated = json.loads(registry_path.read_text())
        agent = updated["agents"][0]
        assert "last_seen" in agent
        # Must be a parseable ISO 8601 timestamp
        from datetime import datetime
        datetime.fromisoformat(agent["last_seen"])

    def test_bump_last_seen_noop_for_missing_agent(self, tmp_path):
        """_bump_last_seen does not raise and leaves the registry unchanged when agent_id is absent."""
        registry_path = tmp_path / "registry.json"
        registry = {
            "agents": [
                {"id": "dev-alice", "name": "Alice", "role": "dev", "status": "active"}
            ]
        }
        original = json.dumps(registry)
        registry_path.write_text(original)

        post_outbound._bump_last_seen(registry_path, "dev-bob")

        assert registry_path.read_text() == original

    def test_bump_last_seen_noop_for_missing_registry(self, tmp_path):
        """_bump_last_seen does not raise when the registry file does not exist."""
        missing = tmp_path / "no_registry.json"
        # Must not raise
        post_outbound._bump_last_seen(missing, "dev-alice")
