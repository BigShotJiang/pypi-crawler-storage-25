---
name: Root Cause Analysis
description: Systematic 4-phase investigation methodology -- detect, investigate, identify root cause, remediate and prevent.
---

# Root Cause Analysis Skill

You embed the Root Cause Analysis (RCA) methodology into your debugging and incident response workflow. This is a cross-cutting process skill: it applies whenever something breaks, behaves unexpectedly, or fails silently -- in code, infrastructure, pipelines, or processes. The core principle is **find the root cause before proposing any fix**. Band-aids that suppress symptoms without addressing causes create recurrence, erode trust, and accumulate technical debt.

## Discovery Protocol (Read Before Acting)

1. Read `docs/architecture.md` -- understand service boundaries, dependencies, and data flows so you can trace failures across components. Mark [MISSING] if absent.
2. Read monitoring and alerting configuration (e.g., Grafana dashboards, PagerDuty rules, CloudWatch alarms) -- know what observability exists. Mark [MISSING] if absent.
3. Read recent git history (`git log --oneline -20`) and deployment logs -- identify what changed in the window preceding the failure. Mark [MISSING] if absent.
4. Read any existing incident reports or postmortems (`docs/incidents/`) -- check for recurrence of known failure patterns. Mark [MISSING] if absent.

Never propose a root cause that is not substantiated by collected evidence. "Human error" is never a root cause -- it is always a symptom of a systemic gap.

## Core Responsibilities

### Phase 1: Detect -- Establish Ground Truth

**Goal:** Define exactly what is broken, where, when, and to what extent.

**Required evidence:**
- Exact error messages, stack traces, and exit codes
- First occurrence timestamp and affected scope (percentage of users, requests, services, or geographic region)
- Recent changes: deployments, config changes, dependency version bumps within the last 24-72 hours (`git log`, deployment logs, config diffs)
- Monitoring state: which alerts fired, which did not, which were suppressed

**Output:** A signed incident statement -- one to three sentences establishing the observable facts. Example: *"Service X is returning HTTP 503 for 40% of /checkout requests since 14:23 UTC. No alerts fired. Last deploy was at 13:55 UTC."*

**Escalation trigger:** Scope is expanding during observation, blast radius is unclear, or data loss is possible or confirmed.

### Phase 2: Investigate -- Generate and Rank Hypotheses

**Goal:** Produce a ranked list of candidate root causes without yet testing destructively.

**Methods to apply:**
- **IS / IS-NOT analysis** (Kepner-Tregoe): For each hypothesis, document what IS affected and what IS-NOT affected despite similar exposure. If the problem occurs on service A but not service B (which shares the same database), the database is excluded. This eliminates hypotheses efficiently.
- **Fishbone enumeration:** For each causal domain -- Code, Configuration, Infrastructure, Process, Tooling, External Dependencies -- generate candidate contributing factors. This prevents tunnel vision on a single domain.
- **Change correlation:** Cross-reference the failure window against recent changes. The most common root cause in software incidents is a recent change.

**Required evidence:**
- Logs correlated to the failure window (not just error logs -- access logs, dependency call logs, audit logs)
- Metrics: latency percentiles, error rates, saturation, traffic shape
- Dependency health: downstream service status, database query times, queue depths
- Infrastructure signals: CPU, memory, disk, network, pod restarts, OOM kills

**Output:** A ranked hypothesis list. For each hypothesis: the claim, supporting evidence, disconfirming evidence, and testability (cost and risk of the confirming test).

**Escalation trigger:** Top hypothesis requires production access or destructive testing beyond your authorization scope.

### Phase 3: Identify Root Cause -- Test and Confirm

**Goal:** Confirm one hypothesis as the root cause and eliminate the rest.

**Methods to apply:**
- **Targeted testing:** Design the cheapest test that produces a binary outcome for the top hypothesis. Prefer read-only or staging tests first. State the prediction before testing: *"If hypothesis H is true, then metric M will show pattern P."*
- **Five Whys:** Once the causal domain is isolated, apply iterative "why" questioning to drill from the proximate cause to the systemic cause. Stop when you reach a factor that is actionable and systemic -- not when you reach "someone made a mistake."
- **Fault tree decomposition:** For multi-condition failures, model the failure as a tree with AND-gates (all sub-conditions required) and OR-gates (any sub-condition sufficient). Evaluate each node against collected evidence.

**Required evidence:**
- Test execution log with timestamps
- Metrics and logs before and after any controlled change
- Confirmation that IS-NOT cases remain unaffected (Kepner-Tregoe verification)

**Stopping criterion:** The root cause is confirmed when: (a) it explains all IS evidence, (b) it is consistent with all IS-NOT evidence, and (c) a targeted fix exists that addresses the cause without side effects.

**Escalation trigger:** Two rounds of testing fail to confirm or eliminate the top two hypotheses -- this signals a missing observability gap requiring additional instrumentation or human domain expertise.

### Phase 4: Remediate and Prevent

**Goal:** Fix the immediate failure and close the systemic gap so it cannot recur.

**Immediate remediation:**
- Apply the minimal targeted fix that addresses the confirmed root cause
- Document the rollback plan before applying the fix
- Verify the fix using the same metrics and evidence criteria from Phase 3
- Do not combine the fix with unrelated improvements -- keep the remediation atomic

**Prevention -- close systemic gaps:**
- If the failure was not detected by monitoring: add the missing alert or check
- If the failure was caused by a process gap: propose the process change with specific ownership
- If the failure was caused by a missing test: write the test that would have caught it
- Every action item must have an owner, a priority, a tracking ID, and a verifiable done-state. Unowned action items are treated as non-existent.

## Output

**Deliverable:** `docs/incidents/rca_<incident-slug>.md` (or inline in a status packet for minor issues).

**Format:**

```
## Incident: <title>

**Detected:** <timestamp>
**Resolved:** <timestamp>
**Duration:** <minutes>

## Summary
<2-3 sentence description of failure, scope, and resolution.>

## Timeline
| Time (UTC) | Event |
|---|---|
| HH:MM | <what happened or was observed> |
| ... | ... |

## Root Cause
<Single, specific, falsifiable statement.>

## Contributing Factors
| Factor | Category | Evidence |
|---|---|---|
| <description> | code / config / infra / process / tooling / dependency | <pointer to log, metric, or test result> |

## Impact
- **Scope:** <% users, requests, or services affected>
- **Data loss:** yes / no
- **SLO breach:** yes / no

## Action Items
| ID | Description | Owner | Priority | Due | Prevents |
|---|---|---|---|---|---|
| <tracking-id> | <specific, verifiable action> | <team or agent> | P1/P2/P3 | <date> | recurrence / detection gap / response gap |

## Detection Gap
<What monitoring or alerting was absent that would have caught this earlier?>
```

## Workflow Integration

- **On any failure or unexpected behavior:** Enter Phase 1 before proposing any fix. Resist the urge to jump to a solution.
- **During debugging:** Follow the phases sequentially. Do not skip Phase 2 (hypothesis generation) -- jumping from detection to fix is the primary cause of misdiagnosis.
- **In handoff messages:** If an investigation is in progress, state the current phase, the top hypothesis, and what evidence is still needed.
- **In postmortems:** Use the output format above. Reject any postmortem that lists "human error" as the root cause -- rewrite it to identify the systemic gap that made the error possible.
- **Cross-role application:** SOC agents apply this to security incidents. Platform agents apply it to infrastructure failures. Dev agents apply it to bugs. SRE agents apply it to production incidents. QA agents apply it when test failures have unclear causes.
- **Consumers:** SOC (incident response), platform (infrastructure issues), dev (bug investigation), SRE (production incidents), QA (test failure triage).
