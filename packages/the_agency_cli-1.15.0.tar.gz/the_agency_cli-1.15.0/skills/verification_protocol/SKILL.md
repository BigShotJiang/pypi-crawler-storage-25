---
name: Verification Protocol
description: Enforce evidence-based verification on every deliverable -- no claim without proof.
---

# Verification Protocol Skill

You embed the Verification Protocol into your workflow. This is a cross-cutting process skill: it applies to every role that produces a deliverable, not just developers. The core principle is simple -- **no claim without evidence**. An agent cannot declare work done without running verification commands and capturing their output as proof. Assertions like "it works," "I tested it," or "looks good" are not evidence.

## Discovery Protocol (Read Before Acting)

1. Read the project's CI/CD configuration (e.g., `.github/workflows/`, `Makefile`, `Justfile`) -- understand what automated gates already exist. Mark [MISSING] if absent.
2. Read `docs/architecture.md` -- identify trust boundaries where verification is especially critical. Mark [MISSING] if absent.
3. Read any existing test configuration (`pytest.ini`, `jest.config.*`, `.mocharc.*`) -- know what test tooling is available. Mark [MISSING] if absent.
4. Read security scanner configuration (`.snyk`, `bandit.toml`, `.semgrep/`) -- know what security gates are in place. Mark [MISSING] if absent.

Never declare a verification step passed without captured output from the actual command.

## Core Responsibilities

1. **Verify Every Deliverable.** Verification is required on every handoff -- not just code. Documentation changes require link-checking or rendering confirmation. Configuration changes require a dry-run or plan output. Infrastructure changes require `terraform plan` or equivalent. Security reviews require scan output. There are no exemptions based on deliverable type.

2. **Collect Valid Evidence.** Evidence must be machine-generated, timestamped, and tied to a specific commit or artifact. The evidence hierarchy, from strongest to weakest:

   - **CI/CD job logs** with pass/fail exit codes and pipeline run ID
   - **Structured test reports** (JUnit XML, TAP, SARIF) stored as artifacts
   - **Command stdout/stderr** with the exact command, exit code, and timestamp captured inline
   - **Screenshots or exported logs** (weaker -- acceptable only when no structured alternative exists)
   - **Verbal assertion alone** -- this is NOT evidence and must never be accepted

3. **Embed Verification Into Handoffs.** Every handoff message that claims work is complete must include an evidence block. The block must contain:
   - The exact command(s) run
   - The captured output (or a summary with pointer to full output if lengthy)
   - The exit code
   - The commit SHA or artifact digest the evidence applies to

   Example evidence block:
   ```
   ### Verification Evidence
   **Commit:** abc1234
   **Command:** `pytest tests/ -v --tb=short`
   **Exit code:** 0
   **Result:** 47 passed, 0 failed, 0 skipped
   **Command:** `ruff check src/`
   **Exit code:** 0
   **Result:** All checks passed
   ```

4. **Reject Unverified Claims.** When reviewing or receiving a handoff, check for the evidence block. If evidence is missing, incomplete, or does not match the claim, reject the handoff and request re-verification. Do not accept "I ran it locally and it passed" without captured output.

5. **Handle Verification Failures.** When a verification step fails:
   - Capture the failure output in full -- do not summarize away the error
   - Do not retry silently hoping for a different result
   - Diagnose the failure before re-attempting
   - If the failure is in a flaky test or external dependency, document it explicitly rather than hiding it behind a retry
   - A deliverable with a known, documented failure and a justification is more honest than one with a silent retry that happened to pass

6. **No Gate May Be Skipped Silently.** If a verification gate must be bypassed (e.g., a known-flaky integration test unrelated to the change), the bypass must be:
   - Explicitly stated in the handoff message
   - Justified with a specific reason
   - Scoped to the exact gate being bypassed (not a blanket `--no-verify`)
   - Logged so reviewers can see it was intentional

## Output

**Deliverable:** An evidence block appended to every handoff message, PR description, or status update that claims completion.

**Format:**
- `### Verification Evidence` heading
- For each verification step: command, exit code, result summary, and the commit SHA or artifact it applies to
- If any step was bypassed: `### Bypassed Gates` section with justification per gate
- If any step failed and was accepted anyway: `### Known Failures` section with failure output and rationale

## Workflow Integration

- **Before any handoff:** Run all applicable verification commands (tests, linters, type-checkers, security scanners, build steps) and capture output.
- **In PR descriptions:** Include the evidence block so reviewers can confirm verification was performed against the PR's HEAD commit.
- **In status packets:** The JSON status packet should only carry `"blocking": false` if all verification steps passed or bypassed gates are documented.
- **At CI/CD gates:** Treat gate results as the authoritative evidence. If CI ran the same checks, reference the pipeline run ID rather than re-running locally.
- **Cross-role application:** Security agents must attach scan output. QA agents must attach test run output. IaC agents must attach plan output. Dev agents must attach build and test output. No role is exempt.
- **Consumers:** All roles -- especially security (prove the scan passed), IaC (prove the plan applies clean), QA (prove the tests ran), dev (prove the build succeeds and tests pass).
