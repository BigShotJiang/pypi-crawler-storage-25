---
# Multi-Agent Collab Bus — Outbound Message
# Fill in the fields below, then run your local Python launcher, for example:
#   python tmp/post_outbound.py
#   py tmp/post_outbound.py      (Windows)
#
# action: view | latest | list | comment | create | close
# issue:  (issue number — required for view, latest, comment, close)
# count:  (number of recent comments to fetch — used with 'latest', default 1)
# title:  (required for 'create' only)
# labels: (comma-separated labels for 'create', e.g. "DEC,collab")
action: comment
issue:
---
