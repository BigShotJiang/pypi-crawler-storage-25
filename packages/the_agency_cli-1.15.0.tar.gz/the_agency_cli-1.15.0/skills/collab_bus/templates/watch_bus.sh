#!/usr/bin/env bash
# ============================================================================
# Collab Bus — Filesystem Watcher
#
# Monitors tmp/outbound.md for changes and can optionally trigger the next
# agent's turn when a status packet is detected.
#
# Usage:
#   ./tmp/watch_bus.sh                    # Watch and log changes
#   ./tmp/watch_bus.sh --auto-dispatch    # Watch and auto-trigger next agent
#
# Requirements:
#   Linux:  sudo apt-get install inotify-tools
#   macOS:  brew install fswatch
#   Windows: Use Python watchdog instead:
#            pip install watchdog
#            watchmedo shell-command --pattern="outbound.md" --command='py tmp/post_outbound.py' tmp/
#
# ============================================================================

set -euo pipefail

WATCH_FILE="${COLLAB_BUS_WATCH_FILE:-tmp/outbound.md}"
AUTO_DISPATCH="${1:-}"
PYTHON_BIN="${COLLAB_BUS_PYTHON:-}"

if [ -z "$PYTHON_BIN" ]; then
    if command -v python3 >/dev/null 2>&1; then
        PYTHON_BIN="python3"
    elif command -v python >/dev/null 2>&1; then
        PYTHON_BIN="python"
    else
        echo "ERROR: No Python launcher found. Set COLLAB_BUS_PYTHON to a working command."
        exit 1
    fi
fi

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*"
}

dispatch() {
    log "Change detected in $WATCH_FILE"
    if [ "$AUTO_DISPATCH" = "--auto-dispatch" ]; then
        log "Auto-dispatching: $PYTHON_BIN tmp/post_outbound.py"
        "$PYTHON_BIN" tmp/post_outbound.py
    else
        log "Ready for manual dispatch: $PYTHON_BIN tmp/post_outbound.py"
    fi
}

# Detect platform and use appropriate watcher
if command -v inotifywait &>/dev/null; then
    # Linux: inotify-tools
    log "Using inotifywait (Linux)"
    log "Watching $WATCH_FILE for changes..."
    while true; do
        inotifywait -q -e modify,close_write "$WATCH_FILE" 2>/dev/null
        dispatch
    done

elif command -v fswatch &>/dev/null; then
    # macOS: fswatch
    log "Using fswatch (macOS)"
    log "Watching $WATCH_FILE for changes..."
    fswatch -0 "$WATCH_FILE" | while read -d "" _event; do
        dispatch
    done

else
    echo "ERROR: No filesystem watcher found."
    echo ""
    echo "Install one of:"
    echo "  Linux:   sudo apt-get install inotify-tools"
    echo "  macOS:   brew install fswatch"
    echo "  Windows: pip install watchdog"
    echo "           watchmedo shell-command --pattern='outbound.md' \\"
    echo "             --command='py tmp/post_outbound.py' tmp/"
    exit 1
fi
