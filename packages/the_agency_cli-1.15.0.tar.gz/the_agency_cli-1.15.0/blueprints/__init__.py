"""
Business blueprints for The Agency runtime.

A blueprint defines the roles available for hire in a given domain. The runtime
code is domain-agnostic: it handles spawning, registry, permissions, and lifecycle.
What roles exist, what skills they map to, and what they are allowed to do comes
entirely from a blueprint file.

The IT blueprint (`blueprints.it`) ships with the runtime. Other domains (marketing,
research, etc.) can be added as sibling modules without touching runtime code.
"""

from blueprints.it import IT_BLUEPRINT
from blueprints.startup import STARTUP_BLUEPRINT
from blueprints.enterprise import ENTERPRISE_BLUEPRINT

# Registry of available blueprints. New blueprints add themselves here.
BLUEPRINTS = {
    "it": IT_BLUEPRINT,
    "startup": STARTUP_BLUEPRINT,
    "enterprise": ENTERPRISE_BLUEPRINT,
}

DEFAULT_BLUEPRINT = "it"


def get_blueprint(name: str = DEFAULT_BLUEPRINT) -> dict:
    """Return a blueprint by name, or raise KeyError if unknown."""
    if name not in BLUEPRINTS:
        raise KeyError(
            f"Unknown blueprint: '{name}'. Available: {', '.join(sorted(BLUEPRINTS))}"
        )
    return BLUEPRINTS[name]
