"""Example: API provider with per-call billing — multi-rail (Tempo MPP + x402).

Scenario: you sell access to an HTTP API (search, scraping, RPC, etc.). Each call costs
a fixed price; agents pick whichever rail their wallet supports. No identity gate, no
compliance — purely pay-or-fail. Think Exa, QuickNode, anyone in the x402 Bazaar.

Rails advertised:
    - **Tempo MPP** (`tempo/charge` intent)
    - **x402 USDC on Base** (EIP-3009)
    - **x402 USDC on Solana** (SPL Token)

The 402 lists all rails neutrally — the agent picks based on what their wallet supports.

Python doesn't have `mppx` / `@x402/core` peer deps — verification + settlement run against
the facilitator HTTP API. Commerce helpers build the protocol-correct 402 body + headers;
your route does the post-payment settle against the facilitator.

Peer deps:
    pip install agentscore-commerce[fastapi]

Env vars:
    TEMPO_RECIPIENT       — your Tempo wallet for receiving USDC.e
    X402_BASE_RECIPIENT   — your Base wallet for receiving USDC
    X402_SOLANA_RECIPIENT — your Solana wallet for receiving USDC
    X402_BASE_NETWORK     — CAIP-2 (default eip155:8453 = Base mainnet;
                            override to eip155:84532 for Sepolia testnet)
    X402_SVM_NETWORK      — CAIP-2 (default solana mainnet; override to
                            solana:EtWTRABZaYq6iMfeYKouRu166VU2xqa1 for devnet)

Run: uvicorn examples.api_provider:app --port 3000
"""

import json
import os
from base64 import b64encode

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from agentscore_commerce.discovery import (
    DiscoveryProbeOptions,
    NoindexNonDiscoveryMiddleware,
    X402SampleProbe,
    build_discovery_probe_response,
    is_discovery_probe_request,
)
from agentscore_commerce.payment import (
    USDC,
    PaymentDirectiveInput,
    networks,
    payment_directive,
    www_authenticate_header,
)

PRICE_USDC = 0.01  # per-call price in USD
REALM = "api.example.com"

# Read network selection from env so the same example serves mainnet + testnet.
X402_BASE_NETWORK = os.environ.get("X402_BASE_NETWORK", networks.base.mainnet.caip2)
X402_SVM_NETWORK = os.environ.get("X402_SVM_NETWORK", networks.solana.mainnet.caip2)
_BASE_USDC = (
    USDC.base.sepolia.address if networks.base.sepolia.caip2 == X402_BASE_NETWORK else USDC.base.mainnet.address
)
_SVM_USDC = USDC.solana.devnet.mint if networks.solana.devnet.caip2 == X402_SVM_NETWORK else USDC.solana.mainnet.mint
_TEMPO_RAIL = "tempo-testnet" if networks.base.sepolia.caip2 == X402_BASE_NETWORK else "tempo-mainnet"

app = FastAPI()

# noindex non-discovery paths so /search doesn't end up in human-shaped SERPs.
# Defaults cover /openapi.json, /llms.txt, /.well-known/{mpp.json,agent-card.json,ucp},
# /favicon.{png,ico} — pass `custom_paths={"/sitemap.xml"}` to extend or
# `replace_paths=True` to swap the set entirely.
app.add_middleware(NoindexNonDiscoveryMiddleware)


@app.post("/search")
async def search(request: Request):
    body = await request.body()
    body_text = body.decode() if body else ""

    auth = request.headers.get("authorization")
    x402_header = request.headers.get("payment-signature") or request.headers.get("x-payment")

    # Discovery probe — empty-body POST without any payment header → return sample 402.
    if await is_discovery_probe_request(request.method, auth, body_text):
        probe = build_discovery_probe_response(
            DiscoveryProbeOptions(
                realm=REALM,
                sample_rail=_TEMPO_RAIL,
                sample_amount_usd=PRICE_USDC,
                sample_recipient=os.environ["TEMPO_RECIPIENT"],
                # Advertise x402 support so crawlers (e.g. ``awal x402 details``)
                # can find it on an empty-body POST. Commerce synthesizes USDC
                # sample accepts from the registry per CAIP-2 network passed.
                x402_sample=X402SampleProbe(
                    networks=[X402_BASE_NETWORK, X402_SVM_NETWORK],
                    resource_url=f"{REALM}/search",
                ),
            )
        )
        return JSONResponse(json.loads(probe.body), status_code=probe.status, headers=probe.headers)

    # No payment? Return a 402 with directives for all accepted rails (Tempo + x402).
    if not (auth and auth.startswith("Payment ")) and not x402_header:
        challenge_id = f"chg_{os.urandom(8).hex()}"
        x402_base_rail = (
            "x402-base-sepolia" if networks.base.sepolia.caip2 == X402_BASE_NETWORK else "x402-base-mainnet"
        )
        x402_svm_rail = (
            "x402-solana-devnet" if networks.solana.devnet.caip2 == X402_SVM_NETWORK else "x402-solana-mainnet"
        )
        directives = [
            payment_directive(
                PaymentDirectiveInput(rail=_TEMPO_RAIL, id=f"{challenge_id}_tempo", realm=REALM, request="")
            ),
            payment_directive(
                PaymentDirectiveInput(rail=x402_base_rail, id=f"{challenge_id}_base", realm=REALM, request="")
            ),
            payment_directive(
                PaymentDirectiveInput(rail=x402_svm_rail, id=f"{challenge_id}_solana", realm=REALM, request="")
            ),
        ]
        x402_solana_recipient = os.environ["X402_SOLANA_RECIPIENT"]
        accepts = [
            {
                "scheme": "exact",
                "network": X402_BASE_NETWORK,
                "amount": str(int(PRICE_USDC * 1_000_000)),
                "asset": _BASE_USDC,
                "payTo": os.environ["X402_BASE_RECIPIENT"],
                "maxTimeoutSeconds": 300,
                # EIP-712 domain — required by every x402 EVM client to sign
                # EIP-3009 TransferWithAuthorization.
                "extra": {"name": "USDC", "version": "2"},
            },
            {
                "scheme": "exact",
                "network": X402_SVM_NETWORK,
                "amount": str(int(PRICE_USDC * 1_000_000)),
                "asset": _SVM_USDC,
                "payTo": x402_solana_recipient,
                "maxTimeoutSeconds": 300,
                # SVM transactions require feePayer in extra. Default to the
                # recipient (round-trip safe for dev). Production merchants
                # typically point at the Coinbase facilitator's payer address.
                "extra": {"feePayer": x402_solana_recipient},
            },
        ]
        return JSONResponse(
            {"payment_required": True, "x402Version": 2, "accepts": accepts},
            status_code=402,
            headers={
                "www-authenticate": www_authenticate_header(directives),
                "PAYMENT-REQUIRED": b64encode(
                    json.dumps({"x402Version": 2, "accepts": accepts, "resource": {"url": str(request.url)}}).encode()
                ).decode(),
            },
        )

    # Payment present — branch on which header arrived:
    #   Authorization: Payment ... → MPP (tempo) — validate via your facilitator's MPP API
    #   payment-signature / x-payment → x402 (base or solana) — validate via x402 facilitator
    # Both shapes settle through the configured facilitator HTTP API, then run your operation.

    body_json = json.loads(body_text)
    results = await run_your_search(body_json.get("query", ""))
    return {"results": results}


async def run_your_search(_query: str) -> list:
    # Vendor's actual search implementation
    return []
