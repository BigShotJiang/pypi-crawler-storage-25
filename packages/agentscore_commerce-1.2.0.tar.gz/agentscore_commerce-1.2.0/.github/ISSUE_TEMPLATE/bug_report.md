---
name: Bug Report
about: Report a bug
title: ''
labels: bug
assignees: ''
---

**Describe the bug**
A clear description of what the bug is.

**To reproduce**
Steps to reproduce the behavior.

**Expected behavior**
What you expected to happen.

**Environment**
- Package version:
- Python version:
- OS:
- Submodule used (`agentscore_commerce.identity.fastapi`, `.payment`, `.discovery`, etc.):
