from typing import Protocol, TypedDict, runtime_checkable, cast
from dataclasses import dataclass

import numpy


class GridError(Exception):
    """ Base error type for `gridlock` """
    pass


def _coerce_scalar(name: str, value: object) -> float:
    arr = numpy.asarray(value)
    if arr.size != 1:
        raise GridError(f'{name} must be a scalar value')

    try:
        return float(arr.reshape(()))
    except (TypeError, ValueError) as exc:
        raise GridError(f'{name} must be a real scalar value') from exc


class ExtentDict(TypedDict, total=False):
    """
    Geometrical definition of an extent (1D bounded region)
    Must contain exactly two of `min`, `max`, `center`, or `span`.
    """
    min: float
    center: float
    max: float
    span: float


@runtime_checkable
class ExtentProtocol(Protocol):
    """
    Anything that looks like an `Extent`
    """
    center: float
    span: float

    @property
    def max(self) -> float: ...

    @property
    def min(self) -> float: ...


@dataclass(init=False, slots=True)
class Extent(ExtentProtocol):
    """
    Geometrical definition of an extent (1D bounded region)
    May be constructed with any two of `min`, `max`, `center`, or `span`.
    """
    center: float
    span: float

    @property
    def max(self) -> float:
        return self.center + self.span / 2

    @property
    def min(self) -> float:
        return self.center - self.span / 2

    def __init__(
            self,
            *,
            min: float | None = None,
            center: float | None = None,
            max: float | None = None,
            span: float | None = None,
            ) -> None:
        values = {
            'min': None if min is None else _coerce_scalar('min', min),
            'center': None if center is None else _coerce_scalar('center', center),
            'max': None if max is None else _coerce_scalar('max', max),
            'span': None if span is None else _coerce_scalar('span', span),
        }
        if sum(value is not None for value in values.values()) != 2:
            raise GridError('Exactly two of min, center, max, span must be provided')

        min_v = values['min']
        center_v = values['center']
        max_v = values['max']
        span_v = values['span']

        if span_v is not None and span_v < 0:
            raise GridError('span must be non-negative')

        if min_v is not None and max_v is not None:
            if max_v < min_v:
                raise GridError('max must be greater than or equal to min')
            center_v = 0.5 * (max_v + min_v)
            span_v = max_v - min_v
        elif center_v is not None and min_v is not None:
            span_v = 2 * (center_v - min_v)
            if span_v < 0:
                raise GridError('min must be less than or equal to center')
        elif center_v is not None and max_v is not None:
            span_v = 2 * (max_v - center_v)
            if span_v < 0:
                raise GridError('center must be less than or equal to max')
        elif min_v is not None and span_v is not None:
            center_v = min_v + 0.5 * span_v
        elif max_v is not None and span_v is not None:
            center_v = max_v - 0.5 * span_v

        if center_v is None or span_v is None:
            raise GridError('Unable to construct extent from the provided values')

        self.center = center_v
        self.span = span_v


class SlabDict(TypedDict, total=False):
    """
    Geometrical definition of a slab (3D region bounded on one axis only)
    Must contain `axis` plus any two of `min`, `max`, `center`, or `span`.
    """
    min: float
    center: float
    max: float
    span: float
    axis: int | str


@runtime_checkable
class SlabProtocol(ExtentProtocol, Protocol):
    """
    Anything that looks like a `Slab`
    """
    axis: int
    center: float
    span: float

    @property
    def max(self) -> float: ...

    @property
    def min(self) -> float: ...


@dataclass(init=False, slots=True)
class Slab(Extent, SlabProtocol):
    """
    Geometrical definition of a slab (3D region bounded on one axis only)
    May be constructed with `axis` (bounded axis) plus any two of `min`, `max`, `center`, or `span`.
    """
    axis: int

    def __init__(
            self,
            axis: int | str,
            *,
            min: float | None = None,
            center: float | None = None,
            max: float | None = None,
            span: float | None = None,
            ) -> None:
        Extent.__init__(self, min=min, center=center, max=max, span=span)

        if isinstance(axis, str):
            axis_int = 'xyz'.find(axis.lower())
        else:
            axis_int = axis
        if axis_int not in range(3):
            raise GridError(f'Invalid axis (slab normal direction): {axis}')
        self.axis = axis_int

    def as_plane(self, where: str) -> 'Plane':
        if where == 'center':
            return Plane(axis=self.axis, pos=self.center)
        if where == 'min':
            return Plane(axis=self.axis, pos=self.min)
        if where == 'max':
            return Plane(axis=self.axis, pos=self.max)
        raise GridError(f'Invalid {where=}')


class PlaneDict(TypedDict, total=False):
    """
    Geometrical definition of a plane (2D unbounded region in 3D space)
    Must contain exactly one of `x`, `y`, `z`, or both `axis` and `pos`
    """
    x: float
    y: float
    z: float
    axis: int
    pos: float


@runtime_checkable
class PlaneProtocol(Protocol):
    """
    Anything that looks like a `Plane`
    """
    axis: int
    pos: float


@dataclass(init=False, slots=True)
class Plane(PlaneProtocol):
    """
    Geometrical definition of a plane (2D unbounded region in 3D space)
    May be constructed with any of `x=4`, `y=5`, `z=-5`, or `axis=2, pos=-5`.
    """
    axis: int
    pos: float

    def __init__(
            self,
            *,
            axis: int | str | None = None,
            pos: float | None = None,
            x: float | None = None,
            y: float | None = None,
            z: float | None = None,
            ) -> None:
        xx = x
        yy = y
        zz = z

        if sum(aa is not None for aa in (pos, xx, yy, zz)) != 1:
            raise GridError('Exactly one of pos, x, y, z must be non-None!')
        if (axis is None) != (pos is None):
            raise GridError('Either both or neither of `axis` and `pos` must be defined.')

        if isinstance(axis, str):
            axis_int = 'xyz'.find(axis.lower())
        elif axis is None:
            axis_int = (xx is None, yy is None, zz is None).index(False)
        else:
            axis_int = axis

        if axis_int not in range(3):
            raise GridError(f'Invalid axis (slab normal direction): {axis=} {x=} {y=} {z=}')
        self.axis = axis_int

        if pos is not None:
            cpos = pos
        else:
            cpos = cast('float', (xx, yy, zz)[axis_int])
            assert cpos is not None

        if hasattr(cpos, '__len__'):
            assert len(cpos) == 1
        self.pos = cpos
