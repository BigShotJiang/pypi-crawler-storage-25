from setuptools import setup, find_packages

setup(
    name='ksaic-bio-programs',
    version='0.1.0',
    description='A collection of 10 bioinformatics programs with a CLI menu.',
    author='ksaic',
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        'biopython'
    ],
    entry_points={
        'console_scripts': [
            'bio-menu=bio_programs.main:run_menu',
        ],
    },
)
