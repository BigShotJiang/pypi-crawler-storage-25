from Bio import SeqIO

# Function to read sequences from a FASTA file and print description and sequence
def read_fasta(file_path):
    # Parse the FASTA file
    for record in SeqIO.parse(file_path, "fasta"):
        # Print the description (header) and sequence
        print(f"Description: {record.description}")
        print(f"Sequence: {record.seq}")
        print()  # Blank line between records

# Specify the path to your FASTA file
fasta_file = "example.fasta"  # Replace with your actual file path

# Call the function
read_fasta(fasta_file)