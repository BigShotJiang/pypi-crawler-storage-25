import subprocess
import os

muscle_exe = r"C:\tools\muscle.exe"
input_file = r"programs\aligned_sequences.fasta"

try:
    if not os.path.exists(muscle_exe):
        raise FileNotFoundError

    # Run MUSCLE and capture output
    result = subprocess.run(
        [muscle_exe, "-in", input_file],
        capture_output=True,
        text=True,
        check=True
    )

    # Print alignment directly
    print(result.stdout)

except FileNotFoundError:
    print("Error: MUSCLE executable not found:", muscle_exe)

except subprocess.CalledProcessError as e:
    print("Error running MUSCLE:", e)