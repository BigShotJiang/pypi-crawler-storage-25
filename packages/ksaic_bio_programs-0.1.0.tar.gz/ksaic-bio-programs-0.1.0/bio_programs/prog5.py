from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord
from Bio.SeqFeature import SeqFeature, FeatureLocation

# Step 1: Create a DNA sequence
dna_sequence = Seq("ATGCGTACGTAGCTAGCTAG")

# Step 2: Create a SeqRecord object
record = SeqRecord(
    dna_sequence,
    id="seq1",
    name="Example_Gene",
    description="An example DNA sequence for gene annotation."
)

# Step 3: Add annotations
record.annotations["molecule_type"] = "DNA"  # Required for GenBank
record.annotations["organism"] = "Synthetic organism"
record.annotations["gene"] = "ExampleGene"
record.annotations["function"] = "Hypothetical protein"

# Step 4: Add gene feature (correct length: 0 to 20)
gene_feature = SeqFeature(
    FeatureLocation(0, 20),  # end-exclusive
    type="gene",
    qualifiers={
        "gene": ["ExampleGene"],
        "note": ["Example gene annotation"]
    }
)

record.features.append(gene_feature)

# Step 5: Modify annotation
record.annotations["function"] = "Hypothetical protein with modified function"

# Step 6: Print details
print(f"ID: {record.id}")
print(f"Name: {record.name}")
print(f"Description: {record.description}")

print("\nAnnotations:")
for key, value in record.annotations.items():
    print(f"{key}: {value}")

print("\nFeatures:")
for feature in record.features:
    print(f"Type: {feature.type}")
    print(f"Location: {feature.location}")
    print(f"Qualifiers: {feature.qualifiers}")
    print()