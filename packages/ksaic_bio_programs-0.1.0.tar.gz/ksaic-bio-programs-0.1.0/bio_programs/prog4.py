from Bio import SeqIO
from Bio.SeqRecord import SeqRecord

# Function to convert FASTA file to GenBank format
def convert_fasta_to_genbank(fasta_file, genbank_file):
    records = []

    # Parse the FASTA file
    for record in SeqIO.parse(fasta_file, "fasta"):
        sequence = record.seq
        description = record.description

        # Create SeqRecord for GenBank
        genbank_record = SeqRecord(
            sequence,
            id=record.id,
            name=record.id,  # better than constant name
            description=description,
            annotations={
                "molecule_type": "DNA",  # Required
                "gene": "ExampleGene",
                "function": "Hypothetical protein"
            }
        )

        records.append(genbank_record)

    # Write all records at once
    with open(genbank_file, "w") as output_handle:
        SeqIO.write(records, output_handle, "genbank")

    print(f"All FASTA sequences converted to GenBank format and saved as {genbank_file}")


# File paths
fasta_file = "programs/fasta_1.fasta"   # safer relative path
genbank_file = "example_output.gb"

# Call function
convert_fasta_to_genbank(fasta_file, genbank_file)