from Bio.Align import PairwiseAligner

# Define two DNA sequences
seq1 = "AGTACACTGGT"
seq2 = "AGTACGCTGGT"

# Create a PairwiseAligner object and perform the alignment
aligner = PairwiseAligner()
alignment = aligner.align(seq1, seq2)

# Print the aligned sequences and the score
print("Aligned Sequences:")
print(alignment[0])
print(f"Alignment Score: {alignment[0].score}")