from Bio import Entrez, SeqIO

# Step 1: Provide your email (required by NCBI)
Entrez.email = "your_email@example.com"

# Step 2: Accession number
accession_number = "NM_001301717"

# Step 3: Fetch and parse directly
with Entrez.efetch(db="nucleotide",
                   id=accession_number,
                   rettype="gb",
                   retmode="text") as handle:
    
    seq_record = SeqIO.read(handle, "genbank")

# Step 4: Print details
print(f"Accession Number: {seq_record.id}")
print(f"Description: {seq_record.description}")
print(f"Organism: {seq_record.annotations['organism']}")
print(f"Sequence: {seq_record.seq}")
print(f"Length of Sequence: {len(seq_record.seq)}")

print("\nFeatures:")
for feature in seq_record.features[:5]:  # limit output
    print(f"Type: {feature.type}, Location: {feature.location}")