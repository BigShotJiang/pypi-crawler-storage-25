import os
import sys
import runpy
from pathlib import Path

def run_menu():
    base_dir = Path(__file__).parent.resolve()
    data_dir = base_dir / "data"
    
    programs = {
        "1": ("prog1.py", "Program 1"),
        "2": ("prog2.py", "Program 2"),
        "3": ("prog3.py", "Program 3"),
        "4": ("prog4.py", "Program 4"),
        "5": ("prog5.py", "Program 5"),
        "6": ("prog6.py", "Program 6"),
        "7": ("prog7.py", "Program 7"),
        "8": ("prog8.py", "Program 8"),
        "9": ("prog9.py", "Program 9"),
        "10": ("prog10.py", "Program 10"),
    }
    
    while True:
        print("\n" + "="*30)
        print("      Bio Programs Menu")
        print("="*30)
        for key in sorted(programs.keys(), key=int):
            print(f" {key:>2}. {programs[key][1]}")
        print("-" * 30)
        print("  0. Exit")
        print("="*30)
        
        choice = input("Select a program to run (0-10): ").strip()
        
        if choice == "0":
            print("Exiting...")
            break
        elif choice in programs:
            script_name = programs[choice][0]
            script_path = base_dir / script_name
            
            if script_path.exists():
                print(f"\n>>> Running {programs[choice][1]} ({script_name}) <<<\n")
                
                # Temporarily change directory so scripts can find data files in current directory
                original_dir = os.getcwd()
                os.chdir(data_dir)
                try:
                    # Run the script
                    runpy.run_path(str(script_path), run_name="__main__")
                except Exception as e:
                    print(f"\n[Error executing script]: {e}")
                finally:
                    os.chdir(original_dir)
                    
                print("\n>>> Finished executing <<<")
            else:
                print(f"\n[Error]: {script_name} not found at {script_path}")
        else:
            print("\n[Invalid choice]: Please enter a number between 0 and 10.")

if __name__ == "__main__":
    run_menu()
