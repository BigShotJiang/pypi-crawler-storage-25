"""
cvc.agent.subagent — Sub-agent architecture (Claude Code-style).

Enables the parent agent to spawn lightweight child agents with:
  - Isolated context windows (no shared history with parent)
  - Restricted tool sets (e.g. read-only for Explore)
  - Configurable max turns and model selection
  - Single-string result returned to the parent

Built-in agents:
  - Explore: Fast read-only codebase exploration (cheapest model, read-only tools)
  - Plan:    Analyze and propose without modifying (current model, read-only tools)

Custom agents can be defined in `.cvc/agents/<name>/agent.md` with YAML frontmatter.
"""

from __future__ import annotations

import logging
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger("cvc.agent.subagent")

# Read-only tools that sub-agents with restricted access can use
READ_ONLY_TOOLS = frozenset({
    "read_file", "multi_read", "grep", "semantic_grep", "glob", "list_dir",
    "cvc_status", "cvc_log", "cvc_search", "cvc_smart_search", "cvc_diff",
    "cvc_document_search", "cvc_list_documents",
    "think", "todo", "web_fetch",
})

# Full coding tools — read + write + execute
CODING_TOOLS = frozenset({
    "read_file", "multi_read", "write_file", "edit_file", "multi_edit", "patch_file",
    "bash", "grep", "semantic_grep", "glob", "list_dir",
    "cvc_status", "cvc_log", "cvc_commit", "cvc_branch",
    "cvc_search", "cvc_smart_search", "cvc_diff",
    "web_search", "web_fetch", "think", "todo", "git",
})

# Research tools — read + web
RESEARCH_TOOLS = frozenset({
    "read_file", "multi_read", "grep", "semantic_grep", "glob", "list_dir",
    "bash", "web_search", "web_fetch",
    "cvc_status", "cvc_log", "cvc_search", "cvc_smart_search", "cvc_diff",
    "cvc_document_search", "cvc_list_documents",
    "think", "todo",
})

# Orchestration tools — everything including sub-agents
ORCHESTRATION_TOOLS = frozenset({
    "read_file", "multi_read", "write_file", "edit_file", "multi_edit", "patch_file",
    "bash", "grep", "semantic_grep", "glob", "list_dir",
    "web_search", "web_fetch", "agent", "parallel_agents",
    "cvc_status", "cvc_log", "cvc_commit", "cvc_branch",
    "cvc_restore", "cvc_merge",
    "cvc_search", "cvc_smart_search", "cvc_diff",
    "cvc_ingest_document", "cvc_document_search", "cvc_list_documents",
    "think", "todo", "context_compact", "git",
})


@dataclass
class SubAgentConfig:
    """Configuration for a sub-agent."""
    name: str
    description: str = ""
    model: str = ""            # Empty = use parent's model
    tools: frozenset[str] = field(default_factory=lambda: READ_ONLY_TOOLS)
    max_turns: int = 10
    system_prompt: str = ""    # Additional instructions prepended to system prompt
    custom_instructions: str = ""  # From agent.md file


# ── Built-in agent configs ──────────────────────────────────────────────────

BUILTIN_AGENTS: dict[str, SubAgentConfig] = {
    "Explore": SubAgentConfig(
        name="Explore",
        description="Fast read-only codebase exploration. Cheapest model, read-only tools.",
        tools=READ_ONLY_TOOLS,
        max_turns=10,
        system_prompt=(
            "Read-only codebase explorer. Search and read files to answer the question. "
            "No file modifications. Be concise — return findings as a brief summary, "
            "not a narrative. Prefer tool calls over text."
        ),
    ),
    "Plan": SubAgentConfig(
        name="Plan",
        description="Read-only analysis and implementation planning.",
        tools=READ_ONLY_TOOLS,
        max_turns=15,
        system_prompt=(
            "Planning agent. Read-only access. Analyze codebase, return a structured "
            "plan: file paths, specific changes, ordering. No prose — just the plan."
        ),
    ),
    "Security": SubAgentConfig(
        name="Security",
        description="Security scanner: OWASP Top 10, CVEs, secrets, dependency audits.",
        tools=RESEARCH_TOOLS,
        max_turns=20,
        system_prompt=(
            "Security analyst. Scan for: OWASP Top 10, hardcoded secrets, CVEs, "
            "insecure crypto, access control flaws. Output: prioritized findings "
            "(CRITICAL→LOW) with file:line, description, fix. No filler text."
        ),
    ),
    "AI": SubAgentConfig(
        name="AI",
        description="AI/ML engineer: LLMs, RAG, embeddings, training, inference.",
        tools=CODING_TOOLS,
        max_turns=25,
        system_prompt=(
            "AI/ML engineer. Build production-grade AI systems in Python: LLM integrations, "
            "RAG pipelines, model training, inference optimization. Write clean async code "
            "with type hints. Use tools to implement — don't describe what you'd do."
        ),
    ),
    "UI": SubAgentConfig(
        name="UI",
        description="UI/UX and frontend: web, terminal TUI, CLI interfaces.",
        tools=CODING_TOOLS,
        max_turns=20,
        system_prompt=(
            "UI/UX developer. Build accessible, responsive interfaces: React, Vue, "
            "Tailwind, Rich/Textual TUI, CLI. Implement directly via tools. "
            "Prioritize UX. Keep explanations minimal."
        ),
    ),
    "Data": SubAgentConfig(
        name="Data",
        description="Data analytics/engineering: SQL, ETL, viz, statistics.",
        tools=CODING_TOOLS,
        max_turns=20,
        system_prompt=(
            "Data analyst/engineer. pandas, SQL, ETL, visualization. "
            "Validate data quality first. Implement via tools. "
            "Brief interpretations alongside code — no verbose explanations."
        ),
    ),
    "Orchestrator": SubAgentConfig(
        name="Orchestrator",
        description="Coordinates sub-agents for complex multi-domain tasks.",
        tools=ORCHESTRATION_TOOLS,
        max_turns=30,
        system_prompt=(
            "Orchestrator. Delegate to: Explore, Plan, Security, AI, UI, Data via "
            "'agent' tool. Decompose → delegate → integrate → verify. "
            "Can also directly edit files and run commands. Minimize narration."
        ),
    ),
}


def _get_cheap_model(provider: str, parent_model: str) -> str:
    """Pick the cheapest model for the given provider (for Explore agent)."""
    cheap_models = {
        "anthropic": "claude-haiku-4-5",
        "openai": "gpt-5-mini",
        "google": "gemini-3-flash-preview",
        "ollama": parent_model,  # Use whatever's loaded locally
        "lmstudio": parent_model,
    }
    return cheap_models.get(provider, parent_model)


def load_custom_agents(workspace: Path) -> dict[str, SubAgentConfig]:
    """Load custom agent definitions from .cvc/agents/<name>/agent.md."""
    agents_dir = workspace / ".cvc" / "agents"
    if not agents_dir.is_dir():
        return {}

    custom: dict[str, SubAgentConfig] = {}

    for agent_dir in agents_dir.iterdir():
        if not agent_dir.is_dir():
            continue

        agent_file = agent_dir / "agent.md"
        if not agent_file.exists():
            continue

        try:
            text = agent_file.read_text(encoding="utf-8")
            config = _parse_agent_md(agent_dir.name, text)
            if config:
                custom[config.name] = config
        except Exception as e:
            logger.warning("Failed to load agent %s: %s", agent_dir.name, e)

    return custom


def _parse_agent_md(name: str, text: str) -> SubAgentConfig | None:
    """Parse an agent.md file with optional YAML frontmatter."""
    frontmatter: dict[str, Any] = {}
    body = text

    # Extract YAML frontmatter (between --- markers)
    fm_match = re.match(r"^---\s*\n(.*?)\n---\s*\n", text, re.DOTALL)
    if fm_match:
        body = text[fm_match.end():]
        try:
            import yaml
            frontmatter = yaml.safe_load(fm_match.group(1)) or {}
        except ImportError:
            # Minimal YAML parsing fallback
            for line in fm_match.group(1).splitlines():
                if ":" in line:
                    k, v = line.split(":", 1)
                    k, v = k.strip(), v.strip()
                    if v.startswith("[") and v.endswith("]"):
                        v = [x.strip().strip("'\"") for x in v[1:-1].split(",")]
                    frontmatter[k] = v

    # Build tool set from frontmatter
    tools_list = frontmatter.get("tools", None)
    if isinstance(tools_list, list):
        tools = frozenset(tools_list)
    else:
        tools = READ_ONLY_TOOLS

    return SubAgentConfig(
        name=frontmatter.get("name", name),
        description=frontmatter.get("description", ""),
        model=frontmatter.get("model", ""),
        tools=tools,
        max_turns=int(frontmatter.get("max_turns", 10)),
        system_prompt=frontmatter.get("system_prompt", ""),
        custom_instructions=body.strip(),
    )


def get_available_agents(workspace: Path) -> dict[str, SubAgentConfig]:
    """Return all available agents (built-in + custom)."""
    agents = dict(BUILTIN_AGENTS)
    agents.update(load_custom_agents(workspace))
    return agents


class SubAgent:
    """
    Run an isolated sub-agent session and return its result.

    The sub-agent gets:
    - Its own context window (no shared history)
    - A restricted tool set
    - A configurable turn limit
    - A specialized system prompt
    """

    def __init__(
        self,
        config: SubAgentConfig,
        workspace: Path,
        provider: str,
        api_key: str,
        parent_model: str,
        base_url: str = "",
    ) -> None:
        self.config = config
        self.workspace = workspace
        self.provider = provider
        self.api_key = api_key
        self.parent_model = parent_model
        self.base_url = base_url

    async def run(self, prompt: str) -> str:
        """Execute the sub-agent and return its final response."""
        from cvc.agent.llm import AgentLLM
        from cvc.agent.tools import AGENT_TOOLS, get_tools_for_provider

        # Pick model
        model = self.config.model
        if not model:
            if self.config.name == "Explore":
                model = _get_cheap_model(self.provider, self.parent_model)
            else:
                model = self.parent_model

        # Build LLM client for this sub-agent
        llm = AgentLLM(
            provider=self.provider,
            api_key=self.api_key,
            model=model,
            base_url=self.base_url,
        )

        try:
            # Filter tools to only those allowed by the config
            allowed_tools = [
                t for t in AGENT_TOOLS
                if t["function"]["name"] in self.config.tools
            ]
            provider_tools = get_tools_for_provider(self.provider, allowed_tools)

            # Build system prompt
            sys_parts = []
            if self.config.system_prompt:
                sys_parts.append(self.config.system_prompt)
            if self.config.custom_instructions:
                sys_parts.append(self.config.custom_instructions)
            sys_parts.append(
                f"\nWorkspace: {self.workspace}\n"
                f"Sub-agent: {self.config.name}. "
                "Be terse. Use tools, not prose. Return only the essential answer."
            )

            messages: list[dict[str, Any]] = [
                {"role": "system", "content": "\n\n".join(sys_parts)},
                {"role": "user", "content": prompt},
            ]

            # Build a minimal executor for the sub-agent
            from cvc.core.models import CVCConfig
            from cvc.core.database import ContextDatabase
            from cvc.operations.engine import CVCEngine
            from cvc.agent.permissions import PermissionEngine

            config = CVCConfig.for_project(
                project_root=self.workspace,
                provider=self.provider,
                model=model,
                mode="cli",
            )
            config.ensure_dirs()
            db = ContextDatabase(config)
            engine = CVCEngine(config, db)

            # Sub-agent permission engine: only allow configured tools
            perm = PermissionEngine()
            from cvc.agent.permissions import PermissionRule
            for tool_name in self.config.tools:
                perm.add_rule(PermissionRule.parse(tool_name, "allow"))

            from cvc.agent.executor import ToolExecutor
            executor = ToolExecutor(self.workspace, engine, permission_engine=perm)

            # Agentic loop (simplified — no streaming, no commit)
            final_text = ""
            for turn in range(self.config.max_turns):
                response_text = ""
                tool_calls = []

                # Collect full response
                async for event in llm.stream_chat(
                    messages=messages,
                    tools=provider_tools,
                ):
                    if event.type == "text_delta":
                        response_text += event.text
                    elif event.type == "tool_call_start":
                        tool_calls.append(event.tool_call)
                    elif event.type == "tool_call_delta":
                        if tool_calls:
                            idx = event.tool_call_index
                            if idx < len(tool_calls):
                                tool_calls[idx].arguments += event.args_delta

                if not tool_calls:
                    final_text = response_text
                    break

                # Execute tool calls
                messages.append({
                    "role": "assistant",
                    "content": response_text,
                    "tool_calls": [tc.__dict__ for tc in tool_calls],
                })

                for tc in tool_calls:
                    try:
                        args = tc.arguments
                        if isinstance(args, str):
                            import json
                            args = json.loads(args)
                        result = executor.execute(tc.name, args)
                    except Exception as e:
                        result = f"Error: {e}"

                    messages.append({
                        "role": "tool",
                        "tool_call_id": tc.id,
                        "content": result,
                    })

            return final_text or "(Sub-agent completed without producing a response)"

        finally:
            await llm.close()
