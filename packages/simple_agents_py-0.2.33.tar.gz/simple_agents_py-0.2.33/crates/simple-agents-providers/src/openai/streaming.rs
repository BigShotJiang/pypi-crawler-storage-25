//! Streaming support for OpenAI API via Server-Sent Events (SSE).

use bytes::Bytes;
use futures_util::Stream;
use simple_agent_type::prelude::*;
use simple_agent_type::response::{ToolCallDelta, ToolCallFunctionDelta};
use simple_agent_type::tool::ToolType;
use std::pin::Pin;
use std::task::{Context, Poll};

use super::models::OpenAIStreamChunk;

/// Parse Server-Sent Events (SSE) stream from OpenAI.
///
/// OpenAI uses SSE format:
/// ```text
/// data: {"id":"chatcmpl-123",...}
/// data: {"id":"chatcmpl-123",...}
/// data: [DONE]
/// ```
///
/// This function:
/// 1. Splits by lines
/// 2. Extracts JSON from "data: " prefix
/// 3. Stops at "[DONE]" sentinel
pub fn parse_sse_line(line: &str) -> Option<Result<OpenAIStreamChunk>> {
    let line = line.trim();

    // Skip empty lines
    if line.is_empty() {
        return None;
    }

    // Skip non-data lines (comments, event types, etc.)
    if !line.starts_with("data: ") {
        return None;
    }

    // Extract JSON after "data: " prefix
    let json = &line[6..];

    // Check for stream termination
    if json == "[DONE]" {
        return None;
    }

    // Parse JSON chunk
    match serde_json::from_str::<OpenAIStreamChunk>(json) {
        Ok(chunk) => Some(Ok(chunk)),
        Err(e) => Some(Err(SimpleAgentsError::Provider(
            ProviderError::InvalidResponse(format!("Failed to parse SSE chunk: {}", e)),
        ))),
    }
}

/// Transform OpenAI stream chunk to unified format.
///
/// Maps OpenAI-specific fields to the standardized `CompletionChunk`.
pub fn transform_openai_chunk(chunk: OpenAIStreamChunk) -> Result<CompletionChunk> {
    let choices = chunk
        .choices
        .into_iter()
        .map(|choice| {
            let role = choice.delta.role.as_ref().and_then(|r| match r.as_str() {
                "assistant" => Some(Role::Assistant),
                "user" => Some(Role::User),
                "system" => Some(Role::System),
                _ => None,
            });

            ChoiceDelta {
                index: choice.index,
                delta: MessageDelta {
                    role,
                    content: choice.delta.content,
                    reasoning_content: choice.delta.reasoning_content,
                    tool_calls: choice.delta.tool_calls.map(|tool_calls| {
                        tool_calls
                            .into_iter()
                            .map(|tool_call| ToolCallDelta {
                                index: tool_call.index,
                                id: tool_call.id,
                                tool_type: tool_call.tool_type.as_deref().map(|kind| match kind {
                                    "function" => ToolType::Function,
                                    _ => ToolType::Function,
                                }),
                                function: tool_call.function.map(|function| {
                                    ToolCallFunctionDelta {
                                        name: function.name,
                                        arguments: function.arguments,
                                    }
                                }),
                            })
                            .collect()
                    }),
                },
                finish_reason: choice.finish_reason.as_ref().map(|s| match s.as_str() {
                    "stop" => FinishReason::Stop,
                    "length" => FinishReason::Length,
                    "content_filter" => FinishReason::ContentFilter,
                    "tool_calls" => FinishReason::ToolCalls,
                    _ => FinishReason::Stop,
                }),
            }
        })
        .collect();

    Ok(CompletionChunk {
        id: chunk.id,
        model: chunk.model,
        choices,
        created: Some(chunk.created as i64),
        usage: chunk.usage.map(|usage| Usage {
            prompt_tokens: usage.prompt_tokens,
            completion_tokens: usage.completion_tokens,
            total_tokens: usage.total_tokens,
            reasoning_tokens: usage.reasoning_tokens(),
        }),
    })
}

/// Stream wrapper for processing SSE chunks.
///
/// Converts raw bytes into parsed `CompletionChunk` objects.
pub struct SseStream {
    inner: Pin<Box<dyn Stream<Item = reqwest::Result<Bytes>> + Send>>,
    buffer: String,
}

impl SseStream {
    pub fn new(stream: impl Stream<Item = reqwest::Result<Bytes>> + Send + 'static) -> Self {
        Self {
            inner: Box::pin(stream),
            buffer: String::new(),
        }
    }
}

impl Stream for SseStream {
    type Item = Result<CompletionChunk>;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        loop {
            // Try to parse a complete line from buffer
            if let Some(newline_pos) = self.buffer.find('\n') {
                let line = self.buffer[..newline_pos].to_string();
                self.buffer.drain(..=newline_pos);

                // Parse SSE line
                if let Some(result) = parse_sse_line(&line) {
                    return Poll::Ready(Some(result.and_then(transform_openai_chunk)));
                }
                // If parse_sse_line returns None, continue to next line
                continue;
            }

            // Need more data - poll the inner stream
            match self.inner.as_mut().poll_next(cx) {
                Poll::Ready(Some(Ok(bytes))) => {
                    // Add new data to buffer
                    match std::str::from_utf8(&bytes) {
                        Ok(s) => self.buffer.push_str(s),
                        Err(e) => {
                            return Poll::Ready(Some(Err(SimpleAgentsError::Provider(
                                ProviderError::InvalidResponse(format!(
                                    "Invalid UTF-8 in stream: {}",
                                    e
                                )),
                            ))))
                        }
                    }
                    // Continue loop to try parsing again
                }
                Poll::Ready(Some(Err(e))) => {
                    return Poll::Ready(Some(Err(SimpleAgentsError::Network(format!(
                        "Stream error: {}",
                        e
                    )))))
                }
                Poll::Ready(None) => {
                    // Stream ended - check if there's a final line without newline
                    if !self.buffer.is_empty() {
                        let line = self.buffer.clone();
                        self.buffer.clear();
                        if let Some(result) = parse_sse_line(&line) {
                            return Poll::Ready(Some(result.and_then(transform_openai_chunk)));
                        }
                    }
                    return Poll::Ready(None);
                }
                Poll::Pending => return Poll::Pending,
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_parse_sse_line_valid() {
        let line = r#"data: {"id":"chatcmpl-123","object":"chat.completion.chunk","created":1677652288,"model":"gpt-4","choices":[{"index":0,"delta":{"content":"Hello"},"finish_reason":null}]}"#;

        let result = parse_sse_line(line);
        assert!(result.is_some());
        assert!(result.unwrap().is_ok());
    }

    #[test]
    fn test_parse_sse_line_done() {
        let line = "data: [DONE]";
        let result = parse_sse_line(line);
        assert!(result.is_none());
    }

    #[test]
    fn test_parse_sse_line_empty() {
        let line = "";
        let result = parse_sse_line(line);
        assert!(result.is_none());
    }

    #[test]
    fn test_parse_sse_line_comment() {
        let line = ": this is a comment";
        let result = parse_sse_line(line);
        assert!(result.is_none());
    }

    #[test]
    fn test_transform_chunk() {
        let chunk = OpenAIStreamChunk {
            id: "chatcmpl-123".to_string(),
            object: "chat.completion.chunk".to_string(),
            created: 1677652288,
            model: "gpt-4".to_string(),
            choices: vec![super::super::models::OpenAIStreamChoice {
                index: 0,
                delta: super::super::models::OpenAIDelta {
                    role: Some("assistant".to_string()),
                    content: Some("Hello".to_string()),
                    reasoning_content: None,
                    tool_calls: None,
                },
                finish_reason: None,
            }],
            system_fingerprint: None,
            usage: None,
        };

        let result = transform_openai_chunk(chunk);
        assert!(result.is_ok());

        let unified = result.unwrap();
        assert_eq!(unified.id, "chatcmpl-123");
        assert_eq!(unified.model, "gpt-4");
        assert_eq!(unified.choices.len(), 1);
        assert_eq!(unified.choices[0].delta.content, Some("Hello".to_string()));
    }

    #[test]
    fn test_transform_chunk_preserves_reasoning_content_separately() {
        let chunk = OpenAIStreamChunk {
            id: "chatcmpl-124".to_string(),
            object: "chat.completion.chunk".to_string(),
            created: 1677652289,
            model: "gpt-4".to_string(),
            choices: vec![super::super::models::OpenAIStreamChoice {
                index: 0,
                delta: super::super::models::OpenAIDelta {
                    role: Some("assistant".to_string()),
                    content: None,
                    reasoning_content: Some("thought token".to_string()),
                    tool_calls: None,
                },
                finish_reason: None,
            }],
            system_fingerprint: None,
            usage: None,
        };

        let unified = transform_openai_chunk(chunk).expect("chunk should transform");
        assert_eq!(unified.choices[0].delta.content, None);
        assert_eq!(
            unified.choices[0].delta.reasoning_content,
            Some("thought token".to_string())
        );
    }

    #[test]
    fn test_transform_chunk_preserves_usage_when_present() {
        let chunk = OpenAIStreamChunk {
            id: "chatcmpl-125".to_string(),
            object: "chat.completion.chunk".to_string(),
            created: 1677652290,
            model: "gpt-4".to_string(),
            choices: vec![super::super::models::OpenAIStreamChoice {
                index: 0,
                delta: super::super::models::OpenAIDelta {
                    role: None,
                    content: None,
                    reasoning_content: None,
                    tool_calls: None,
                },
                finish_reason: Some("stop".to_string()),
            }],
            system_fingerprint: None,
            usage: Some(super::super::models::OpenAIUsage {
                prompt_tokens: 21,
                completion_tokens: 669,
                total_tokens: 690,
                reasoning_tokens: None,
                completion_tokens_details: None,
                output_tokens_details: None,
            }),
        };

        let unified = transform_openai_chunk(chunk).expect("chunk should transform");
        assert_eq!(
            unified.usage,
            Some(Usage {
                prompt_tokens: 21,
                completion_tokens: 669,
                total_tokens: 690,
                reasoning_tokens: None,
            })
        );
    }

    #[test]
    fn test_transform_chunk_maps_reasoning_usage_from_details() {
        let chunk = OpenAIStreamChunk {
            id: "chatcmpl-126".to_string(),
            object: "chat.completion.chunk".to_string(),
            created: 1677652291,
            model: "gpt-4".to_string(),
            choices: vec![super::super::models::OpenAIStreamChoice {
                index: 0,
                delta: super::super::models::OpenAIDelta {
                    role: None,
                    content: None,
                    reasoning_content: None,
                    tool_calls: None,
                },
                finish_reason: Some("stop".to_string()),
            }],
            system_fingerprint: None,
            usage: Some(super::super::models::OpenAIUsage {
                prompt_tokens: 21,
                completion_tokens: 669,
                total_tokens: 690,
                reasoning_tokens: None,
                completion_tokens_details: Some(super::super::models::OpenAIUsageDetails {
                    reasoning_tokens: Some(9),
                }),
                output_tokens_details: None,
            }),
        };

        let unified = transform_openai_chunk(chunk).expect("chunk should transform");
        assert_eq!(
            unified.usage.and_then(|usage| usage.reasoning_tokens),
            Some(9)
        );
    }
}
