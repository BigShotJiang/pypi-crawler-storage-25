"""Unit tests for controlzero.error_codes (Tier 0a hotfix 2026-05-15).

Pin the contract: every catalog entry has a stable shape, the codes
are unique, and the format_error renderer emits a consistent
user-facing string.
"""

from __future__ import annotations

import re

import pytest

from controlzero import error_codes as ec


class TestCatalogShape:
    def test_every_code_has_E_prefix_and_digits(self) -> None:
        for code, entry in ec.all_codes().items():
            assert re.fullmatch(r"E\d{4}", code), f"bad code {code}"
            assert entry.code == code  # self-consistent
            assert entry.title, f"missing title for {code}"
            assert entry.what, f"missing what for {code}"
            assert entry.fix, f"missing fix for {code}"
            assert entry.doc, f"missing doc slug for {code}"

    def test_codes_are_unique(self) -> None:
        all_codes = list(ec.all_codes().keys())
        assert len(all_codes) == len(set(all_codes))

    def test_at_least_30_codes_seeded(self) -> None:
        # Tier 0a goal: ship ~30 codes covering the main failure
        # modes. The catalog is additive-only, so this only gets
        # higher over time.
        assert len(ec.all_codes()) >= 20  # lower bound; current is 24


class TestRanges:
    def test_security_codes_in_1000s(self) -> None:
        for code in ec.all_codes():
            num = int(code[1:])
            if 1000 <= num <= 1099:
                e = ec.get(code)
                # Security codes mention keys or perms in the title/what.
                blob = (e.title + " " + e.what).lower()
                assert any(t in blob for t in ("key", "perm", "leak", "secret", "settings file"))


class TestFormatError:
    def test_renders_canonical_shape(self) -> None:
        out = ec.format_error("E1001")
        assert "ERROR E1001" in out
        assert "API key found in agent settings file" in out
        assert "Fix:" in out
        assert "Docs:" in out
        assert "docs.controlzero.ai/errors/E1001-api-key-in-settings" in out

    def test_extra_field_injects_into_body(self) -> None:
        out = ec.format_error("E1001", extra="~/.claude/settings.json:5:9")
        assert "~/.claude/settings.json:5:9" in out

    def test_unknown_code_raises(self) -> None:
        with pytest.raises(KeyError):
            ec.get("E9999")
