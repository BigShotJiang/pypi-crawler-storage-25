"""Tests for controlzero.device -- device fingerprint and client detection."""

from __future__ import annotations

import os
import re
import subprocess
from unittest import mock

import pytest

from controlzero.device import (
    _reset_caches,
    detect_client_name,
    detect_client_version,
    get_device_fingerprint,
)


@pytest.fixture(autouse=True)
def _clear_caches():
    """Reset module-level caches before every test."""
    _reset_caches()
    yield
    _reset_caches()


# ---------------------------------------------------------------------------
# get_device_fingerprint
# ---------------------------------------------------------------------------


class TestGetDeviceFingerprint:
    def test_returns_all_expected_keys(self):
        fp = get_device_fingerprint()
        expected_keys = {
            "hostname",
            "ip_address",
            "mac_address",
            "serial_number",
            "os_name",
            "os_version",
            "arch",
        }
        assert set(fp.keys()) == expected_keys

    def test_all_values_are_strings(self):
        fp = get_device_fingerprint()
        for key, value in fp.items():
            assert isinstance(value, str), f"{key} should be a string, got {type(value)}"

    def test_hostname_is_non_empty(self):
        fp = get_device_fingerprint()
        assert fp["hostname"] != ""

    def test_mac_address_format(self):
        fp = get_device_fingerprint()
        mac = fp["mac_address"]
        # Must be either XX:XX:XX:XX:XX:XX or "unknown"
        if mac != "unknown":
            pattern = r"^[0-9a-f]{2}(:[0-9a-f]{2}){5}$"
            assert re.match(pattern, mac), f"MAC '{mac}' does not match expected format"

    def test_serial_number_returns_string(self):
        fp = get_device_fingerprint()
        assert isinstance(fp["serial_number"], str)
        # May be "unknown" on CI or containers -- that is acceptable
        assert len(fp["serial_number"]) > 0

    def test_os_name_is_non_empty(self):
        fp = get_device_fingerprint()
        assert fp["os_name"] != ""
        assert fp["os_name"] != "unknown" or True  # platform.system() may vary

    def test_result_is_cached(self):
        fp1 = get_device_fingerprint()
        fp2 = get_device_fingerprint()
        assert fp1 == fp2

    def test_returns_copy_not_reference(self):
        fp1 = get_device_fingerprint()
        fp1["hostname"] = "mutated"
        fp2 = get_device_fingerprint()
        assert fp2["hostname"] != "mutated"

    def test_graceful_on_hostname_failure(self):
        with mock.patch("controlzero.device.socket.gethostname", side_effect=OSError):
            _reset_caches()
            fp = get_device_fingerprint()
            assert fp["hostname"] == "unknown"

    def test_graceful_on_mac_failure(self):
        with mock.patch("controlzero.device.uuid.getnode", side_effect=RuntimeError):
            _reset_caches()
            fp = get_device_fingerprint()
            assert fp["mac_address"] == "unknown"

    def test_graceful_on_serial_subprocess_timeout(self):
        with mock.patch(
            "controlzero.device.subprocess.run",
            side_effect=subprocess.TimeoutExpired(cmd="ioreg", timeout=5),
        ):
            _reset_caches()
            fp = get_device_fingerprint()
            # Should not crash; serial_number falls back to "unknown"
            assert fp["serial_number"] in ("unknown", fp["serial_number"])


# ---------------------------------------------------------------------------
# detect_client_name
# ---------------------------------------------------------------------------


# T92 cleaned-env helper: strip every env var the detector sniffs so a
# single positive trigger stays singular. Pre-T92 the prefix scan let
# any GEMINI_* / CURSOR_* in the runtime environment silently leak in
# and made tests order-dependent.
def _isolated_env(extras: dict[str, str] | None = None) -> dict[str, str]:
    drop = {
        "CONTROLZERO_CLIENT",
        "CLAUDECODE",
        "CLAUDE_CODE",
        "CODEX_HOME",
        "CODEX_PROFILE",
        "CODEX_CLI",
        "CURSOR_TRACE_ID",
        "CURSOR_AGENT",
        "CURSOR_USER_AGENT",
        "TERM_PROGRAM",
        "WINDSURF_AGENT",
        "WINDSURF_SESSION_ID",
        "GEMINI_CLI",
        "GEMINI_SANDBOX",
        "GEMINI_SYSTEM_MD",
        "GEMINI_API_KEY",
    }
    base = {k: v for k, v in os.environ.items() if k not in drop}
    if extras:
        base.update(extras)
    return base


class TestDetectClientName:
    def test_default_is_python_sdk(self):
        # 1.5.2: default-emission fix. Previously returned "sdk", which
        # the backend NormalizeSource mapped to SourceUnknown and the
        # dashboard rendered as "--". "python-sdk" is the canonical
        # alias that maps to SourcePythonSDK on the backend.
        with mock.patch.dict(os.environ, _isolated_env(), clear=True):
            _reset_caches()
            assert detect_client_name() == "python-sdk"

    def test_reads_controlzero_client_env(self):
        with mock.patch.dict(os.environ, _isolated_env({"CONTROLZERO_CLIENT": "my-custom-client"}), clear=True):
            _reset_caches()
            assert detect_client_name() == "my-custom-client"

    def test_detects_claude_code_via_claudecode(self):
        # The Anthropic shell launcher exports CLAUDECODE=1 (no underscore).
        with mock.patch.dict(os.environ, _isolated_env({"CLAUDECODE": "1"}), clear=True):
            _reset_caches()
            assert detect_client_name() == "claude-code"

    def test_detects_claude_code_via_legacy_claude_code(self):
        # CLAUDE_CODE (with underscore) kept as a fallback for any
        # consumer that set the older name.
        with mock.patch.dict(os.environ, _isolated_env({"CLAUDE_CODE": "1"}), clear=True):
            _reset_caches()
            assert detect_client_name() == "claude-code"

    def test_detects_codex_cli(self):
        with mock.patch.dict(os.environ, _isolated_env({"CODEX_HOME": "/Users/x/.codex"}), clear=True):
            _reset_caches()
            assert detect_client_name() == "codex-cli"

    def test_detects_cursor_via_trace_id(self):
        with mock.patch.dict(os.environ, _isolated_env({"CURSOR_TRACE_ID": "abc"}), clear=True):
            _reset_caches()
            assert detect_client_name() == "cursor"

    def test_detects_cursor_via_term_program(self):
        with mock.patch.dict(os.environ, _isolated_env({"TERM_PROGRAM": "cursor"}), clear=True):
            _reset_caches()
            assert detect_client_name() == "cursor"

    def test_detects_windsurf(self):
        with mock.patch.dict(os.environ, _isolated_env({"WINDSURF_AGENT": "1"}), clear=True):
            _reset_caches()
            assert detect_client_name() == "windsurf"

    def test_detects_gemini_cli(self):
        # The CLI runtime exports GEMINI_CLI; that signal still wins.
        with mock.patch.dict(os.environ, _isolated_env({"GEMINI_CLI": "1"}), clear=True):
            _reset_caches()
            assert detect_client_name() == "gemini-cli"

    def test_gemini_api_key_does_NOT_trigger_gemini_cli(self):
        # T92 regression: pre-T92 a GEMINI_API_KEY export silently
        # mislabeled SDK-direct users (the deny-deny incident,
        # 2026-05-10) as "gemini-cli". GEMINI_API_KEY is a Google API
        # credential, not a Gemini CLI runtime signal. Must default
        # back to the python-sdk fallback (1.5.2 canonical alias).
        with mock.patch.dict(os.environ, _isolated_env({"GEMINI_API_KEY": "fake-google-key"}), clear=True):
            _reset_caches()
            assert detect_client_name() == "python-sdk"

    def test_cursor_with_gemini_api_key_resolves_to_cursor(self):
        # T92 regression: a Cursor user who also exports GEMINI_API_KEY
        # for direct Google API access must resolve to "cursor" (the
        # IDE signal), not "gemini-cli". Cursor is checked before
        # Gemini CLI in the priority order so legitimate IDE usage is
        # not stomped by an unrelated API key.
        env = _isolated_env({"CURSOR_TRACE_ID": "trace", "GEMINI_API_KEY": "fake"})
        with mock.patch.dict(os.environ, env, clear=True):
            _reset_caches()
            assert detect_client_name() == "cursor"

    def test_explicit_override_takes_priority_over_claude_code(self):
        env = _isolated_env({"CONTROLZERO_CLIENT": "override", "CLAUDECODE": "1"})
        with mock.patch.dict(os.environ, env, clear=True):
            _reset_caches()
            assert detect_client_name() == "override"

    def test_result_is_cached(self):
        with mock.patch.dict(os.environ, {"CONTROLZERO_CLIENT": "cached-test"}, clear=False):
            _reset_caches()
            name1 = detect_client_name()
        # Even after env changes, cache should hold
        name2 = detect_client_name()
        assert name1 == name2 == "cached-test"


# ---------------------------------------------------------------------------
# detect_client_version
# ---------------------------------------------------------------------------


class TestDetectClientVersion:
    def test_returns_string(self):
        _reset_caches()
        version = detect_client_version()
        assert isinstance(version, str)

    def test_default_returns_empty_string(self):
        cleaned = {
            k: v
            for k, v in os.environ.items()
            if k != "CONTROLZERO_CLIENT"
            and k != "CLAUDE_CODE"
            and not k.startswith("CURSOR_")
            and not k.startswith("GEMINI_")
        }
        with mock.patch.dict(os.environ, cleaned, clear=True):
            _reset_caches()
            version = detect_client_version()
            # "sdk" client has no version detection
            assert version == ""

    def test_claude_code_version_with_mock(self):
        cleaned = {
            k: v
            for k, v in os.environ.items()
            if k != "CONTROLZERO_CLIENT"
            and not k.startswith("CURSOR_")
            and not k.startswith("GEMINI_")
        }
        cleaned["CLAUDE_CODE"] = "1"
        with mock.patch.dict(os.environ, cleaned, clear=True):
            with mock.patch(
                "controlzero.device.subprocess.run",
                return_value=mock.Mock(returncode=0, stdout="1.2.3\n"),
            ):
                _reset_caches()
                version = detect_client_version()
                assert version == "1.2.3"

    def test_version_graceful_on_command_not_found(self):
        cleaned = {
            k: v
            for k, v in os.environ.items()
            if k != "CONTROLZERO_CLIENT"
            and not k.startswith("CURSOR_")
            and not k.startswith("GEMINI_")
        }
        cleaned["CLAUDE_CODE"] = "1"
        with mock.patch.dict(os.environ, cleaned, clear=True):
            with mock.patch(
                "controlzero.device.subprocess.run",
                side_effect=FileNotFoundError,
            ):
                _reset_caches()
                version = detect_client_version()
                assert version == ""

    def test_cursor_version_from_env(self):
        cleaned = {
            k: v
            for k, v in os.environ.items()
            if k != "CONTROLZERO_CLIENT"
            and k != "CLAUDE_CODE"
            and not k.startswith("GEMINI_")
        }
        # T92: CURSOR_SESSION is no longer a trigger (was a broad-prefix
        # match removed alongside the GEMINI_API_KEY mislabel fix). Use
        # CURSOR_TRACE_ID which Cursor IDE actually sets per terminal.
        cleaned["CURSOR_TRACE_ID"] = "trace-x"
        cleaned["CURSOR_VERSION"] = "0.45.2"
        with mock.patch.dict(os.environ, cleaned, clear=True):
            _reset_caches()
            version = detect_client_version()
            assert version == "0.45.2"

    def test_result_is_cached(self):
        _reset_caches()
        v1 = detect_client_version()
        v2 = detect_client_version()
        assert v1 == v2
