"""T103 regression tests: hosted-vs-local precedence.

Customer report 2026-05-12: a stale ~/.controlzero/policy.yaml
shadowed the dashboard policy with no warning. Local always won over
hosted when both were present. T103 reverses this so api_key implies
hosted unless CONTROLZERO_LOCAL_OVERRIDE=1.

These tests pin the new precedence and the explicit-override warning
that fires when a caller mixes api_key with a policy/policy_file arg.
"""

from __future__ import annotations


import pytest

from controlzero import Client
from controlzero.errors import HybridModeError


@pytest.fixture(autouse=True)
def _reset_warn_state():
    """Clear module-level one-shot warnings between tests."""
    from controlzero import client as _client_mod
    _client_mod._NO_POLICY_WARNED = False
    _client_mod._HYBRID_WARNED = False
    yield


def test_explicit_local_wins_over_api_key_with_warning(monkeypatch, capsys):
    """Caller-explicit policy beats api_key, but emits the override warning."""
    monkeypatch.setenv("CONTROLZERO_API_KEY", "cz_test_fakekey")
    cz = Client(
        policy={"rules": [{"deny": "delete_*"}]},
        log_path="/tmp/cz-t103-explicit.log",
    )
    err = capsys.readouterr().err
    assert "overrides the hosted bundle" in err
    assert cz.guard("delete_foo").denied
    cz.close()


def test_explicit_local_strict_raises(monkeypatch):
    """strict_hosted=True with explicit local + api_key raises."""
    monkeypatch.setenv("CONTROLZERO_API_KEY", "cz_test_fakekey")
    with pytest.raises(HybridModeError):
        Client(
            policy={"rules": [{"deny": "anything"}]},
            strict_hosted=True,
        )


def test_local_override_env_var_honors_local(monkeypatch, tmp_path, capsys):
    """CONTROLZERO_LOCAL_OVERRIDE=1 + api_key + cwd policy => use local."""
    pol = tmp_path / "controlzero.yaml"
    pol.write_text(
        "version: '1'\nrules:\n  - deny: send_email\n  - allow: '*'\n",
        encoding="utf-8",
    )
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("CONTROLZERO_API_KEY", "cz_test_fakekey")
    monkeypatch.setenv("CONTROLZERO_LOCAL_OVERRIDE", "1")

    cz = Client(log_path=str(tmp_path / "cz.log"))
    assert cz.guard("send_email").denied
    assert cz.guard("web_search").allowed
    err = capsys.readouterr().err
    assert "local-override" in err
    cz.close()


def test_no_api_key_falls_back_to_cwd_yaml(monkeypatch, tmp_path):
    """No api_key => resolve ./controlzero.yaml. Backwards-compatible."""
    pol = tmp_path / "controlzero.yaml"
    pol.write_text(
        "version: '1'\nrules:\n  - deny: dangerous\n  - allow: '*'\n",
        encoding="utf-8",
    )
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("CONTROLZERO_API_KEY", raising=False)
    monkeypatch.delenv("CONTROLZERO_LOCAL_OVERRIDE", raising=False)

    cz = Client(log_path=str(tmp_path / "cz.log"))
    assert cz.guard("dangerous").denied
    assert cz.guard("safe").allowed
    cz.close()


def test_no_api_key_accepts_json_policy(monkeypatch, tmp_path):
    """T97: SDK auto-detects policy.json by extension."""
    pol = tmp_path / "controlzero.json"
    pol.write_text(
        '{"version": "1", "rules": [{"deny": "dangerous"}, {"allow": "*"}]}',
        encoding="utf-8",
    )
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("CONTROLZERO_API_KEY", raising=False)

    cz = Client(log_path=str(tmp_path / "cz.log"))
    assert cz.guard("dangerous").denied
    cz.close()


def test_customer_2026_05_12_cwd_yaml_bypassed_when_api_key_set(
    monkeypatch, tmp_path
):
    """Customer report 2026-05-12 regression.

    Pre-T103: a stale ~/.controlzero/policy.yaml shadowed the hosted
    bundle for 25 days. Post-T103: api_key + cwd policy.yaml + no
    LOCAL_OVERRIDE => hosted wins, cwd file is NOT loaded.

    Mocks ``load_hosted_policy`` so we never hit a real backend. Asserts
    the Client's evaluator was constructed from the mocked hosted
    policy, not the cwd file.
    """
    from unittest.mock import MagicMock, patch

    # Drop a "stale" cwd file with rules that would silently disable
    # enforcement if it were used (allow-all). The hosted policy denies
    # send_email. If the cwd file leaked in, send_email would allow.
    stale = tmp_path / "controlzero.yaml"
    stale.write_text(
        "version: '1'\nrules:\n  - allow: '*'\n",
        encoding="utf-8",
    )
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("CONTROLZERO_API_KEY", "cz_live_synthetictest")
    monkeypatch.delenv("CONTROLZERO_LOCAL_OVERRIDE", raising=False)

    hosted_policy = {
        "version": "1",
        "rules": [
            {"effect": "deny", "action": "send_email", "reason": "hosted-deny"},
            {"effect": "allow", "action": "*"},
        ],
    }
    fake_parsed = MagicMock()

    with patch(
        "controlzero.hosted_policy.load_hosted_policy",
        return_value=(hosted_policy, fake_parsed),
    ) as mock_load, patch(
        "controlzero.hosted_policy.load_cached_bundle", return_value=None
    ):
        cz = Client(log_path=str(tmp_path / "cz.log"))
        assert mock_load.call_count == 1
        # Hosted deny rule must fire. If the cwd allow-all file had been
        # loaded instead, send_email would allow.
        assert cz.guard("send_email").denied
        cz.close()


def test_active_source_notification_quiet_suppresses(monkeypatch, tmp_path, capsys):
    """CONTROLZERO_QUIET=1 silences the active-source notification."""
    pol = tmp_path / "controlzero.yaml"
    pol.write_text("rules:\n  - allow: '*'\n", encoding="utf-8")
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("CONTROLZERO_API_KEY", raising=False)
    monkeypatch.setenv("CONTROLZERO_QUIET", "1")

    cz = Client(log_path=str(tmp_path / "cz.log"))
    err = capsys.readouterr().err
    assert "active policy source" not in err
    cz.close()
