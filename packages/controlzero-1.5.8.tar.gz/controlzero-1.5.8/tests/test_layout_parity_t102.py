"""Cross-SDK layout parity contract test (T102).

Greps each SDK source tree for the canonical filenames in
``tests/cross-sdk/layout-spec.json``. If any SDK forgets to reference
``audit.log`` or starts writing the deprecated ``events.log`` again,
this test fails before the drift ships.

The check is grep-based not behaviour-based because the three SDKs
target three different runtimes and we don't want to require Node and
Go to be installed inside the Python pytest container. The grep gives
us 90% of the protection at 5% of the cost: a string lookup proves the
SDK at least *names* the canonical file; combined with each SDK's own
unit tests we get end-to-end coverage of the layout spec.
"""

from __future__ import annotations

import json
import re
from pathlib import Path

import pytest


def _find_repo_root() -> Path | None:
    """Walk up from this test file until we see ``tests/cross-sdk``.

    The Python SDK lives 4 levels deep
    (``sdks/python/controlzero/tests/this.py``) when checked out at the
    repo root, but the file may be mounted at a different depth in
    isolated test containers. The walk lets the test self-locate
    regardless of mount layout, and lets us skip cleanly when the
    cross-SDK fixtures aren't present (e.g. an SDK consumer running
    tests from a sdist).
    """
    here = Path(__file__).resolve().parent
    for ancestor in [here, *here.parents]:
        if (ancestor / "tests" / "cross-sdk" / "layout-spec.json").exists():
            return ancestor
    return None


REPO_ROOT = _find_repo_root()
SPEC_PATH = REPO_ROOT / "tests" / "cross-sdk" / "layout-spec.json" if REPO_ROOT else None


pytestmark = pytest.mark.skipif(
    REPO_ROOT is None,
    reason="cross-SDK fixtures not visible from this test mount point",
)


@pytest.fixture(scope="module")
def spec() -> dict:
    return json.loads(SPEC_PATH.read_text(encoding="utf-8"))


# Each SDK's source directory. We grep these (and these only) for the
# canonical filename strings. Test fixtures and unrelated tooling are
# excluded so a stale fixture doesn't accidentally satisfy the check.
SDK_SOURCES = {
    "python": REPO_ROOT / "sdks" / "python" / "controlzero" / "controlzero",
    "node":   REPO_ROOT / "sdks" / "node" / "controlzero" / "src",
    "go":     REPO_ROOT / "sdks" / "go" / "controlzero",
} if REPO_ROOT else {}


def _grep_files(root: Path, needle: str) -> list[Path]:
    """Return source files under *root* that mention *needle*.

    Skips compiled/build artifacts. Pure source files only.
    """
    hits: list[Path] = []
    if not root.exists():
        return hits
    for p in root.rglob("*"):
        if not p.is_file():
            continue
        if any(part in {"__pycache__", "node_modules", "dist", "build", ".git"} for part in p.parts):
            continue
        if p.suffix not in {".py", ".ts", ".js", ".go"}:
            continue
        try:
            if needle in p.read_text(encoding="utf-8"):
                hits.append(p)
        except (OSError, UnicodeDecodeError):
            continue
    return hits


# Known gaps: the Go SDK predates the SDK_LOCAL_LAYOUT spec and still
# writes to `./controlzero.log` and has no `controlzero login` /
# `config.yaml` flow. Tracked in GH #445. The xfail markers stay until
# that issue lands. NEVER widen this list without filing a new issue
# -- a fresh xfail here is a silent regression.
_GO_KNOWN_GAPS = {"audit_filename", "config_filename"}


def _maybe_xfail_go(sdk_name: str, spec_key: str):
    if sdk_name == "go" and spec_key in _GO_KNOWN_GAPS:
        pytest.xfail(
            f"Go SDK does not yet reference spec['{spec_key}']; tracked in GH #445"
        )


@pytest.mark.parametrize("sdk_name", list(SDK_SOURCES.keys()))
def test_sdk_references_canonical_audit_filename(sdk_name: str, spec: dict):
    """Every SDK must mention the canonical ``audit.log`` filename."""
    sdk_root = SDK_SOURCES[sdk_name]
    if not sdk_root.exists():
        pytest.skip(f"{sdk_name} SDK source tree not present at {sdk_root}")
    hits = _grep_files(sdk_root, spec["audit_filename"])
    if not hits:
        _maybe_xfail_go(sdk_name, "audit_filename")
    assert hits, (
        f"{sdk_name} SDK has no source file referencing "
        f"{spec['audit_filename']!r}. SDK_LOCAL_LAYOUT spec requires "
        f"every SDK to write the single audit.log JSONL."
    )


@pytest.mark.parametrize("sdk_name", list(SDK_SOURCES.keys()))
def test_sdk_references_config_filename(sdk_name: str, spec: dict):
    sdk_root = SDK_SOURCES[sdk_name]
    if not sdk_root.exists():
        pytest.skip(f"{sdk_name} SDK source tree not present")
    hits = _grep_files(sdk_root, spec["config_filename"])
    if not hits:
        _maybe_xfail_go(sdk_name, "config_filename")
    assert hits, (
        f"{sdk_name} SDK does not reference {spec['config_filename']!r}; "
        f"controlzero login output must land in this file."
    )


@pytest.mark.parametrize("sdk_name", list(SDK_SOURCES.keys()))
def test_sdk_references_quarantine_filename(sdk_name: str, spec: dict):
    sdk_root = SDK_SOURCES[sdk_name]
    if not sdk_root.exists():
        pytest.skip(f"{sdk_name} SDK source tree not present")
    hits = _grep_files(sdk_root, spec["quarantine_filename"])
    assert hits, (
        f"{sdk_name} SDK does not reference {spec['quarantine_filename']!r}; "
        f"tamper quarantine state must persist to this file."
    )


@pytest.mark.parametrize("sdk_name", list(SDK_SOURCES.keys()))
def test_sdk_default_policy_filename(sdk_name: str, spec: dict):
    """Every SDK must mention the default policy filename
    (``policy.yaml``). This is the file ``controlzero init`` writes."""
    sdk_root = SDK_SOURCES[sdk_name]
    if not sdk_root.exists():
        pytest.skip(f"{sdk_name} SDK source tree not present")
    hits = _grep_files(sdk_root, "policy.yaml")
    assert hits, (
        f"{sdk_name} SDK has no source reference to policy.yaml. "
        f"This is the default file controlzero init writes."
    )


@pytest.mark.parametrize("sdk_name", list(SDK_SOURCES.keys()))
def test_sdk_accepts_json_policy_extension(sdk_name: str, spec: dict):
    """Every SDK must accept ``policy.json`` as an alternate format.

    Implementations differ: Python references the literal filename in
    its file resolver; Node uses ``extname(path) === '.json'`` so the
    literal string never appears. Either is acceptable -- the test
    accepts the literal filename OR a JSON-extension handler.
    """
    sdk_root = SDK_SOURCES[sdk_name]
    if not sdk_root.exists():
        pytest.skip(f"{sdk_name} SDK source tree not present")
    literal_hits = _grep_files(sdk_root, "policy.json")
    # Accept JSON via extension dispatch: e.g. `extname(path) === '.json'`
    # or `path.endswith('.json')` or Go `filepath.Ext(p) == ".json"`.
    ext_hits = _grep_files(sdk_root, "'.json'") + _grep_files(sdk_root, '".json"')
    if literal_hits or ext_hits:
        return
    if sdk_name == "go":
        pytest.xfail("Go SDK has no JSON policy path yet; tracked in GH #445")
    pytest.fail(
        f"{sdk_name} SDK has neither a literal policy.json reference "
        f"nor a .json extension handler. Spec requires JSON as an "
        f"acceptable alternate policy format."
    )


def test_python_sdk_does_not_actively_write_events_log(spec: dict):
    """Python SDK must NOT have any active write path to events.log
    after T96 (1.5.4). Only the T101 migration shim is allowed to
    touch the legacy filename, and only to read+delete. References in
    docstrings, comments, and the file-inventory diagnostic are fine.

    We look line-by-line for a write-shaped call right next to an
    events.log reference: ``GLOBAL_EVENTS_PATH.open("a"`` or
    ``"events.log").open("a"`` or ``.write_text(`` against an
    events-log-named variable. Anything that has to scan across the
    whole file is too loose -- we'd false-positive on unrelated
    audit.log writes elsewhere in the same module.
    """
    sdk_root = SDK_SOURCES["python"]
    # Match either:
    #   GLOBAL_EVENTS_PATH.open("a"       (uses module-level constant)
    #   "events.log"  ... .open("a"       on the same line
    # Limited to 80 chars of intervening text so we stay within one
    # statement -- not the whole file.
    bad_pattern = re.compile(
        r"(?:GLOBAL_EVENTS_PATH|EVENTS_LOG|events_log|events_path|[\"']events\.log[\"'])"
        r"[^\n]{0,80}?(?:\.open\s*\(\s*[\"']a|\.write_text\s*\(|\.write_bytes\s*\()"
    )
    offenders: list[tuple[Path, str]] = []
    for p in sdk_root.rglob("*.py"):
        if any(part in {"__pycache__"} for part in p.parts):
            continue
        # Whitelist: layout_migration.py reads and deletes events.log;
        # neither operation is a write.
        if p.name == "layout_migration.py":
            continue
        try:
            text = p.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        for m in bad_pattern.finditer(text):
            offenders.append((p, m.group(0)[:120]))
    assert not offenders, (
        "Active writes to events.log detected outside layout_migration.py:\n"
        + "\n".join(f"  {p}: {snippet}" for p, snippet in offenders)
    )
