"""Tests for PolicyDecision.reason_code (2026-04-19 P0).

The hosted dashboard + audit ingestion + CLI automation all need a
machine-readable label for "why did this call get denied?" that is
stable across SDK versions. Before 2026-04-19 the SDK only emitted a
human-readable ``reason`` string, so every consumer had to regex-match
English text, and the empty-bundle deny shipped a misleading copy
("No active policies. Define one in the Control Zero dashboard.")
that presumed the user had not defined any policies -- precisely the
wrong message when the user HAS defined them but the library-
attachments state was empty.

These tests pin down:

 1. The reason_code enum values and the codes emitted on each
    fail-closed code path.
 2. The one-to-many mapping: reason_code is the machine label, reason
    is the human label, and the two are distinct fields.
 3. The new empty-bundle copy: no mention of "Define one in the
    Control Zero dashboard."
"""

from __future__ import annotations

from controlzero._internal.bundle import translate_to_local_policy
from controlzero._internal.enforcer import (
    REASON_CODE_BUNDLE_MISSING,
    REASON_CODE_BUNDLE_TAMPERED,
    REASON_CODE_DLP_BLOCKED,
    REASON_CODE_MACHINE_QUARANTINED,
    REASON_CODE_NETWORK_ERROR,
    REASON_CODE_NO_ACTIVE_POLICIES,
    REASON_CODE_NO_RULE_MATCH,
    REASON_CODE_RULE_MATCH,
    VALID_REASON_CODES,
    PolicyDecision,
    PolicyEvaluator,
)
from controlzero.policy_loader import load_policy


# ---- enum surface ---------------------------------------------------------


def test_reason_code_enum_has_all_nine_values():
    """The fixed set of codes the SDK, backend, dashboard, and CLI
    coordinate on. Renames are API-breaking.

    Extended 2026-04-20 (#228 Phase 2) from 5 to 8. Adds
    RULE_MATCH, BUNDLE_MISSING, and DLP_BLOCKED so the CLI +
    dashboard can tell user-rule firings apart from no-match
    denies, and bundle-missing apart from bundle-tampered.
    Extended again 2026-05-12 (T108) from 8 to 9. Adds
    LOCAL_OVERRIDE_ACTIVE for the governance trail that fires
    when CONTROLZERO_LOCAL_OVERRIDE=1 bypasses the hosted bundle.
    The additions are strictly additive.
    """
    # Original five (frozen, rename = breaking).
    assert REASON_CODE_NO_ACTIVE_POLICIES == "NO_ACTIVE_POLICIES"
    assert REASON_CODE_NO_RULE_MATCH == "NO_RULE_MATCH"
    assert REASON_CODE_BUNDLE_TAMPERED == "BUNDLE_TAMPERED"
    assert REASON_CODE_MACHINE_QUARANTINED == "MACHINE_QUARANTINED"
    assert REASON_CODE_NETWORK_ERROR == "NETWORK_ERROR"
    # Three new in Phase 2.
    assert REASON_CODE_RULE_MATCH == "RULE_MATCH"
    assert REASON_CODE_BUNDLE_MISSING == "BUNDLE_MISSING"
    assert REASON_CODE_DLP_BLOCKED == "DLP_BLOCKED"
    # One new in T108 (governance lifecycle event).
    from controlzero._internal.enforcer import REASON_CODE_LOCAL_OVERRIDE_ACTIVE
    assert REASON_CODE_LOCAL_OVERRIDE_ACTIVE == "LOCAL_OVERRIDE_ACTIVE"

    # Subset check (not strict equality) so additive code expansions
    # (e.g. HITL-5a 1.5.8: 9 new HITL_* codes added 2026-05-16) do not
    # break this rename-guarantee test. The exact total is asserted by
    # test_hitl_reason_codes.py::test_valid_set_size_grew_by_exactly_9.
    assert frozenset({
        "RULE_MATCH",
        "NO_RULE_MATCH",
        "NO_ACTIVE_POLICIES",
        "BUNDLE_MISSING",
        "BUNDLE_TAMPERED",
        "MACHINE_QUARANTINED",
        "NETWORK_ERROR",
        "DLP_BLOCKED",
        "LOCAL_OVERRIDE_ACTIVE",
    }) <= VALID_REASON_CODES


# ---- NO_ACTIVE_POLICIES emission ------------------------------------------


def test_bundle_empty_emits_reason_code_NO_ACTIVE_POLICIES():
    """An empty policy list translated to the local shape MUST emit a
    single synthetic deny whose ``reason_code`` is NO_ACTIVE_POLICIES.

    This is the code that ran on the customer's project: the bundle was
    signed + verified + decrypted but carried zero policies because
    policy_attachments was empty. Prior to the fix, the SDK surfaced a
    generic English string; now it surfaces a stable machine label so
    the CLI can print a meaningful hint and the dashboard can bucket
    the failure into its own alert surface.
    """
    local = translate_to_local_policy({"policies": []})
    rules = local["rules"]
    assert len(rules) == 1
    rule = rules[0]
    assert rule["effect"] == "deny"
    assert rule.get("reason_code") == "NO_ACTIVE_POLICIES"


def test_bundle_empty_new_copy_does_not_presume_user_undefined_policies():
    """The pre-2026-04-19 copy told users to "Define one in the Control
    Zero dashboard." That message is the WRONG recovery action when the
    user has already defined policies but the attachment state is empty
    (the customer's case). This test fails if anyone restores that wording.
    """
    local = translate_to_local_policy({"policies": []})
    reason = local["rules"][0]["reason"].lower()
    # Exact strings from the old message must be gone.
    assert "define one in the control zero dashboard" not in reason
    # The new copy must steer the user toward the actual recovery.
    assert "regenerate" in reason or "attached policies" in reason


def test_bundle_empty_roundtrip_through_load_policy_preserves_reason_code():
    """End-to-end: the empty-bundle synthetic deny must survive the
    bundle -> load_policy -> PolicyEvaluator pipeline and produce a
    PolicyDecision whose reason_code is NO_ACTIVE_POLICIES. If any
    intermediate step strips the field, the dashboard sees
    reason_code="" and has to regex-match English text again.
    """
    local = translate_to_local_policy({"policies": []})
    parsed = load_policy(local)
    evaluator = PolicyEvaluator(parsed.rules)
    decision = evaluator.evaluate(tool="whatever", method="x")
    assert decision.effect == "deny"
    assert decision.reason_code == "NO_ACTIVE_POLICIES"


# ---- NO_RULE_MATCH emission -----------------------------------------------


def test_evaluator_no_rule_match_emits_NO_RULE_MATCH():
    """When a non-empty rule set fails to match the action, the
    evaluator's fail-closed default deny MUST be tagged NO_RULE_MATCH
    -- not NO_ACTIVE_POLICIES. The user configured rules; they just
    didn't cover this call, which is a different operator problem.
    """
    # A policy that only covers "safe_tool". Calls to "other_tool" fall
    # through to the fail-closed default.
    policy_dict = {
        "version": "1",
        "rules": [
            {"effect": "allow", "action": "safe_tool", "reason": "ok"},
        ],
    }
    parsed = load_policy(policy_dict)
    evaluator = PolicyEvaluator(parsed.rules)
    decision = evaluator.evaluate(tool="other_tool", method="*")
    assert decision.effect == "deny"
    assert decision.reason_code == "NO_RULE_MATCH"


# ---- reason_code is distinct from reason ---------------------------------


def test_reason_codes_distinct_from_reason_string():
    """Pin the invariant that reason_code and reason are independent
    fields. reason can be translated, re-worded, or localized without
    touching reason_code, and automation must branch on reason_code
    only.
    """
    d = PolicyDecision(
        effect="deny",
        reason="Anything the user wants to see here",
        reason_code=REASON_CODE_NO_ACTIVE_POLICIES,
    )
    assert d.reason == "Anything the user wants to see here"
    assert d.reason_code == "NO_ACTIVE_POLICIES"
    # And they are independent -- changing one does not change the
    # other.
    d.reason = "entirely different copy"
    assert d.reason_code == "NO_ACTIVE_POLICIES"


def test_policy_decision_reason_code_defaults_to_empty_string():
    """Existing constructors that predate reason_code (e.g. inside
    user-authored integrations) must keep working. The field defaults
    to an empty string, not to None, so consumers that do string
    comparison never see TypeError.
    """
    d = PolicyDecision(effect="allow")
    assert d.reason_code == ""
    assert isinstance(d.reason_code, str)


# ---- tamper + quarantine codes --------------------------------------------


def test_policy_decision_accepts_all_enum_values():
    """Every enum value must be constructable without special
    handling. A test will fail if a future refactor introduces a
    canonicalization step that rejects one of the codes.
    """
    for code in sorted(VALID_REASON_CODES):
        d = PolicyDecision(effect="deny", reason_code=code)
        assert d.reason_code == code


# ---- RULE_MATCH emission on user-rule firing -----------------------------


def test_evaluator_user_rule_match_emits_RULE_MATCH():
    """User-authored rules (both allow and deny) surface as
    reason_code=RULE_MATCH. Prior to #228 Phase 2 they had no code
    at all, which meant dashboards could not tell "user rule fired"
    apart from "no code emitted".
    """
    policy_dict = {
        "version": "1",
        "rules": [
            {"effect": "deny", "action": "Bash", "reason": "no shell"},
            {"effect": "allow", "action": "Read", "reason": "reads ok"},
        ],
    }
    parsed = load_policy(policy_dict)
    ev = PolicyEvaluator(parsed.rules)

    d_deny = ev.evaluate(tool="Bash", method="*")
    assert d_deny.effect == "deny"
    assert d_deny.reason_code == REASON_CODE_RULE_MATCH

    d_allow = ev.evaluate(tool="Read", method="*")
    assert d_allow.effect == "allow"
    assert d_allow.reason_code == REASON_CODE_RULE_MATCH


def test_evaluator_synthetic_rule_reason_code_wins_over_RULE_MATCH():
    """A rule that already carries a machine reason_code (e.g. the
    synthetic empty-bundle NO_ACTIVE_POLICIES deny) must NOT be
    overwritten with RULE_MATCH. Synthetic rules own their code.
    """
    local = translate_to_local_policy({"policies": []})
    parsed = load_policy(local)
    ev = PolicyEvaluator(parsed.rules)
    decision = ev.evaluate(tool="whatever", method="x")
    assert decision.reason_code == REASON_CODE_NO_ACTIVE_POLICIES
    assert decision.reason_code != REASON_CODE_RULE_MATCH


# ---- DLP_BLOCKED emission -------------------------------------------------


def test_evaluator_dlp_block_emits_DLP_BLOCKED():
    """A DLP-level block on an otherwise-allow decision must carry
    reason_code=DLP_BLOCKED so ops can separate "tool blocked" from
    "argument tripped DLP" in dashboards.
    """
    from controlzero._internal.dlp_scanner import DLPScanner
    scanner = DLPScanner(enable_builtins=False)
    scanner.add_rules([
        {
            "id": "card-numbers",
            "name": "card-numbers",
            "pattern": r"\d{16}",
            "category": "pii",
            "action": "block",
        },
    ])
    policy_dict = {
        "version": "1",
        "rules": [{"effect": "allow", "action": "write_memo", "reason": "memo ok"}],
    }
    parsed = load_policy(policy_dict)
    ev = PolicyEvaluator(parsed.rules, dlp_scanner=scanner)
    decision = ev.evaluate(
        tool="write_memo",
        method="*",
        args={"body": "card is 4242424242424242"},
    )
    assert decision.effect == "deny"
    assert decision.reason_code == REASON_CODE_DLP_BLOCKED


def test_evaluator_dlp_non_blocking_preserves_RULE_MATCH():
    """A DLP detect (non-blocking) match must NOT override the
    reason_code. Only a block does. detect/mask leave the allow
    intact and attach findings to the audit trail.
    """
    from controlzero._internal.dlp_scanner import DLPScanner
    scanner = DLPScanner(enable_builtins=False)
    scanner.add_rules([
        {
            "id": "card-numbers-detect",
            "name": "card-numbers-detect",
            "pattern": r"\d{16}",
            "category": "pii",
            "action": "detect",
        },
    ])
    policy_dict = {
        "version": "1",
        "rules": [{"effect": "allow", "action": "write_memo", "reason": "ok"}],
    }
    parsed = load_policy(policy_dict)
    ev = PolicyEvaluator(parsed.rules, dlp_scanner=scanner)
    decision = ev.evaluate(
        tool="write_memo",
        method="*",
        args={"body": "card is 4242424242424242"},
    )
    assert decision.effect == "allow"
    assert decision.reason_code == REASON_CODE_RULE_MATCH
    # Findings are attached for the audit trail.
    assert len(decision.dlp_findings) == 1


# ---- BUNDLE_MISSING emission ---------------------------------------------


def test_make_bundle_missing_policy_default_deny():
    """With no default supplied, the BUNDLE_MISSING synthetic
    policy must deny (canonical fail-closed default).
    """
    from controlzero._internal.bundle import make_bundle_missing_policy
    pol = make_bundle_missing_policy()
    assert len(pol["rules"]) == 1
    rule = pol["rules"][0]
    assert rule["effect"] == "deny"
    assert rule["reason_code"] == "BUNDLE_MISSING"


def test_make_bundle_missing_policy_allow_when_configured():
    """default_on_missing=allow must produce an allow rule (so
    bundle-missing honors the operator's configured posture).
    """
    from controlzero._internal.bundle import make_bundle_missing_policy
    pol = make_bundle_missing_policy(default_on_missing="allow")
    rule = pol["rules"][0]
    assert rule["effect"] == "allow"
    assert rule["reason_code"] == "BUNDLE_MISSING"


def test_make_bundle_missing_policy_rejects_invalid_value():
    """Unknown default_on_missing values coerce to the canonical
    deny. SDK fails closed, never raises on bad config.
    """
    from controlzero._internal.bundle import make_bundle_missing_policy
    pol = make_bundle_missing_policy(default_on_missing="nonsense")
    assert pol["rules"][0]["effect"] == "deny"


def test_bundle_missing_roundtrip_through_load_policy():
    """End-to-end: BUNDLE_MISSING synthetic policy must survive
    load_policy + evaluator and surface the code on every call.
    """
    from controlzero._internal.bundle import make_bundle_missing_policy
    pol_dict = make_bundle_missing_policy(default_on_missing="deny")
    parsed = load_policy(pol_dict)
    ev = PolicyEvaluator(parsed.rules)
    decision = ev.evaluate(tool="anything", method="*")
    assert decision.effect == "deny"
    assert decision.reason_code == "BUNDLE_MISSING"
