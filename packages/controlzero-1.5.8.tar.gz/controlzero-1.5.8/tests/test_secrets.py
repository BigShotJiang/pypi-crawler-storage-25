"""Unit tests for controlzero.cli._secrets (Tier 0a hotfix 2026-05-15).

These tests are load-bearing: the cross-SDK contract test that fails
the CI on any leak depends on find_key_leaks being correct. If we
miss a leak shape here, the contract test misses it everywhere.
"""

from __future__ import annotations


from controlzero.cli._secrets import (
    KeyMatch,
    find_key_leaks,
    redact_key,
    redact_text,
    scan_files,
)


# ---------------------------------------------------------------------------
# find_key_leaks: the load-bearing function. Every realistic key shape we
# ever shipped must match. Every realistic non-key shape must NOT match.
# ---------------------------------------------------------------------------


class TestFindKeyLeaks:
    def test_matches_full_64char_live_key(self) -> None:
        # The exact shape from the 2026-05-14 screenshot incident.
        text = "CONTROLZERO_API_KEY=cz_live_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa controlzero hook-check"
        matches = find_key_leaks(text)
        assert len(matches) == 1
        assert matches[0].key == "cz_live_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
        assert matches[0].line_number == 1

    def test_matches_test_key_localdev_shape(self) -> None:
        # The dev-mode key used in CI + local-dev mode per CLAUDE.md.
        text = "key: cz_test_localdev_000000000000000000000000"
        matches = find_key_leaks(text)
        assert len(matches) == 1
        assert matches[0].key == "cz_test_localdev_000000000000000000000000"

    def test_line_number_is_1_indexed(self) -> None:
        # doctor output prints `file.json:42:5` style; the line number
        # must be 1-indexed to match compiler / editor convention.
        text = "line1\nline2\ncz_live_abcd1234567890"
        matches = find_key_leaks(text)
        assert len(matches) == 1
        assert matches[0].line_number == 3

    def test_finds_multiple_keys_in_one_blob(self) -> None:
        # Worst case: a settings.json with two stale entries.
        text = """{
  "hooks": {
    "PreToolUse": [
      {"command": "CONTROLZERO_API_KEY=cz_live_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa controlzero hook-check"},
      {"command": "CONTROLZERO_API_KEY=cz_test_bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb controlzero hook-check"}
    ]
  }
}"""
        matches = find_key_leaks(text)
        assert len(matches) == 2
        assert matches[0].key.startswith("cz_live_")
        assert matches[1].key.startswith("cz_test_")
        # Both on different lines.
        assert matches[0].line_number != matches[1].line_number

    def test_does_not_match_non_key_strings_with_cz_prefix(self) -> None:
        # cz_ as a username or column name should NOT match.
        text = "cz_user = 'bob'\nCREATE TABLE cz_audit_logs (...)"
        assert find_key_leaks(text) == []

    def test_does_not_match_redacted_form(self) -> None:
        # We must NOT re-flag our own redacted output as a leak.
        # `cz_live_***aaaaa` should be safe to print without doctor
        # warning about it.
        text = "Active key: cz_live_***aaaaa"
        # The redaction contains *** which is not in [A-Za-z0-9_].
        # The pattern stops at the *. So the match would be too short
        # (cz_live_ alone is < 4 chars suffix). Asserting empty:
        assert find_key_leaks(text) == []

    def test_does_not_match_documentation_placeholders(self) -> None:
        # README + docs commonly use `cz_live_xxx` as a placeholder.
        # 3 chars is shorter than our 4-char minimum suffix.
        text = "Set CONTROLZERO_API_KEY=cz_live_xxx in your env"
        assert find_key_leaks(text) == []

    def test_handles_empty_string(self) -> None:
        assert find_key_leaks("") == []

    def test_handles_huge_input_without_backtracking_blowup(self) -> None:
        # Defense: the regex must be linear. A 1MB pathological string
        # should still return in under a second. Pytest timeout would
        # catch a regex-DoS.
        text = ("cz_" * 100000) + "live_aaaaaaaa"
        # Should complete and find at most ONE match (the only real
        # `cz_live_aaaaaaaa`).
        matches = find_key_leaks(text)
        # Could be 0 or 1; the point is "doesn't hang."
        assert len(matches) <= 1


# ---------------------------------------------------------------------------
# redact_key: never reveal more than the last 4 chars of any secret.
# ---------------------------------------------------------------------------


class TestRedactKey:
    def test_live_key_redacted_to_last_4(self) -> None:
        key = "cz_live_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
        assert redact_key(key) == "cz_live_***aaaaa"

    def test_test_key_redacted_to_last_5(self) -> None:
        key = "cz_test_localdev_000000000000000000000000"
        # last 5 chars of the full key.
        assert redact_key(key) == "cz_test_***00000"

    def test_non_key_input_returned_verbatim(self) -> None:
        # Caller-side `print(redact_key(maybe_thing))` must always be safe.
        assert redact_key("not a key") == "not a key"
        assert redact_key("") == ""
        assert redact_key("cz_user_bob") == "cz_user_bob"

    def test_whitespace_stripped_before_match(self) -> None:
        # Tolerant of leading / trailing whitespace.
        key = "  cz_live_abcd1234567890  "
        assert redact_key(key) == "cz_live_***67890"


# ---------------------------------------------------------------------------
# redact_text: scrub a whole string. Used to sanitize stderr / logs.
# ---------------------------------------------------------------------------


class TestRedactText:
    def test_replaces_all_occurrences_in_a_blob(self) -> None:
        text = "key1=cz_live_aaaaaaaaaaaaaa\nkey2=cz_test_bbbbbbbbbbbbbb"
        out = redact_text(text)
        assert "cz_live_aaaaaa" not in out
        assert "cz_test_bbbbbb" not in out
        assert "cz_live_***" in out
        assert "cz_test_***" in out

    def test_preserves_non_secret_content(self) -> None:
        text = "Hello world. The user is bob@example.com. cz_live_abcd1234567890 ."
        out = redact_text(text)
        assert "Hello world." in out
        assert "bob@example.com" in out
        assert "cz_live_abcd1234567890" not in out
        assert "cz_live_***67890" in out


# ---------------------------------------------------------------------------
# scan_files: doctor + migrate consume this. Test the filesystem boundary.
# ---------------------------------------------------------------------------


class TestScanFiles:
    def test_finds_leak_in_real_file(self, tmp_path) -> None:
        f = tmp_path / "settings.json"
        f.write_text('{"command": "cz_live_abcd1234567890 controlzero"}')
        results = scan_files([str(f)])
        assert len(results) == 1
        path, match = results[0]
        assert path == str(f)
        assert match.key == "cz_live_abcd1234567890"

    def test_silently_skips_missing_files(self, tmp_path) -> None:
        # doctor calls scan_files with a list of every known agent
        # settings path; most won't exist on any given machine. That
        # must not be an error.
        nonexistent = tmp_path / "does-not-exist.json"
        results = scan_files([str(nonexistent)])
        assert results == []

    def test_silently_skips_unreadable_files(self, tmp_path) -> None:
        # Permissions error on read should not crash doctor.
        f = tmp_path / "secret.json"
        f.write_text("cz_live_abcd1234567890")
        f.chmod(0o000)
        try:
            # On macOS as root or some FS layouts, chmod 0 may still be
            # readable. Test is best-effort.
            results = scan_files([str(f)])
            # Either we got an empty list (read failed -> skipped) or
            # a single match (read succeeded). Both are acceptable;
            # the absolute requirement is "did not raise".
            assert isinstance(results, list)
        finally:
            f.chmod(0o644)

    def test_clean_file_returns_empty(self, tmp_path) -> None:
        f = tmp_path / "clean.json"
        f.write_text('{"hooks": {"PreToolUse": [{"command": "controlzero hook-check"}]}}')
        results = scan_files([str(f)])
        assert results == []


# ---------------------------------------------------------------------------
# Regression guards. These tests fail loudly if someone refactors away
# the contract the cross-SDK CI check depends on.
# ---------------------------------------------------------------------------


def test_find_key_leaks_returns_keymatch_namedtuple() -> None:
    """The contract test uses `.key` and `.line_number` fields. If
    someone refactors this to a plain tuple or a dataclass with
    renamed fields, downstream consumers break. Pin the shape."""
    text = "cz_live_abcd1234567890"
    matches = find_key_leaks(text)
    assert len(matches) == 1
    m = matches[0]
    assert isinstance(m, KeyMatch)
    assert hasattr(m, "key")
    assert hasattr(m, "line_number")
    assert hasattr(m, "start")
    assert hasattr(m, "end")


def test_redacted_form_is_idempotent() -> None:
    """Running `redact_text(redact_text(x)) == redact_text(x)`. If
    someone changes the redaction to embed key chars, this catches
    it."""
    text = "key=cz_live_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
    once = redact_text(text)
    twice = redact_text(once)
    assert once == twice
