"""Shared pytest fixtures for the controlzero test suite."""


import pytest

# Reset module-level warning state before each test so order does not matter.
import controlzero.client as _client_mod


@pytest.fixture(autouse=True)
def reset_warning_state():
    _client_mod._NO_POLICY_WARNED = False
    _client_mod._HYBRID_WARNED = False
    yield


@pytest.fixture(autouse=True)
def clear_env(monkeypatch):
    """Make sure no env vars leak between tests.

    T103 (2026-05-12): the CLI hook-check calls ``os.environ.setdefault(
    "CONTROLZERO_QUIET", "1")`` to suppress per-tool-call stderr in the
    subprocess context. ``setdefault`` mutates os.environ directly,
    bypassing monkeypatch's tracking. Without explicit clearing here,
    one ``runner.invoke(cli_main.cli, ["hook-check"], ...)`` test
    permanently sets QUIET=1 for the rest of the pytest process and
    silently suppresses every subsequent ``_notify_active_source``
    call. Caught on CI Python 3.11 (build server 3.12 happened to run
    in a different order and pass).

    LOCAL_OVERRIDE and VERBOSE_HOOK can also leak via the same path.
    """
    monkeypatch.delenv("CONTROLZERO_API_KEY", raising=False)
    monkeypatch.delenv("CONTROLZERO_POLICY_FILE", raising=False)
    monkeypatch.delenv("CONTROLZERO_QUIET", raising=False)
    monkeypatch.delenv("CONTROLZERO_LOCAL_OVERRIDE", raising=False)
    monkeypatch.delenv("CONTROLZERO_VERBOSE_HOOK", raising=False)
    yield


@pytest.fixture
def tmp_log(tmp_path):
    """Provide a temp log file path."""
    return tmp_path / "test-controlzero.log"
